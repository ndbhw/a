/**
  ******************************************************************************
  * ������ � ���������
  * ���������� ������ ����� �� ���������������
  * ����� ILIASAM
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4_discovery_audio_codec.h"
#include "waverecorder.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
extern uint16_t AUDIO_SAMPLE[];

const int16_t sinebuf1[96] = {0,0, 4276,4276, 8480,8480, 12539,12539, 16383,16383, 19947,19947, 23169,23169, 25995,25995,
                             28377,28377, 30272,30272, 31650,31650, 32486,32486, 32767,32767, 32486,32486, 31650,31650, 30272,30272,
                             28377,28377, 25995,25995, 23169,23169, 19947,19947, 16383,16383, 12539,12539, 8480,8480, 4276,4276,
                             0,0, -4276,-4276, -8480,-8480, -12539,-12539, -16383,-16383, -19947,-19947, -23169,-23169, -25995,-25995,
                             -28377,-28377, -30272,-30272, -31650,-31650, -32486,-32486, -32767,-32767, -32486,-32486, -31650,-31650, -30272,-30272,
                             -28377,-28377, -25995,-25995, -23169,-23169, -19947,-19947, -16383,-16383, -12539,-12539, -8480,-8480, -4276,-4276
                             };

int16_t sinebuf2[] = {0,0, 4276,4276, 8480,8480, 12539,12539, 16383,16383, 19947,19947, 23169,23169, 25995,25995,
                             28377,28377, 30272,30272, 31650,31650, 32486,32486, 32767,32767, 32486,32486, 31650,31650, 30272,30272,
                             28377,28377, 25995,25995, 23169,23169, 19947,19947, 16383,16383, 12539,12539, 8480,8480, 4276,4276,
                             0,0, -4276,-4276, -8480,-8480, -12539,-12539, -16383,-16383, -19947,-19947, -23169,-23169, -25995,-25995,
                             -28377,-28377, -30272,-30272, -31650,-31650, -32486,-32486, -32767,-32767, -32486,-32486, -31650,-31650, -30272,-30272,
                             -28377,-28377, -25995,-25995, -23169,-23169, -19947,-19947, -16383,-16383, -12539,-12539, -8480,-8480, -4276,-4276,
                             0,0,32486,32486,0,0,32486,32486,0,0,32486,32486,0,0,32486,32486,0,0,32486,32486,0,0,32486,32486,0,0,32486,32486};


int16_t audiodata[64];

uint16_t PrescalerValue = 0;

__IO uint8_t UserButtonPressed = 0;

__IO uint32_t TimingDelay;
extern uint16_t RecBuf[PCM_OUT_SIZE];

/* Private function prototypes -----------------------------------------------*/
void Delay_ms(uint32_t ms);

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void)
{
  //����� - ����� #define AUDIO_MAL_MODE_NORMAL - AUDIO_MAL_DMA_IT_TC_EN - ��� DAC
  
  RCC_ClocksTypeDef RCC_Clocks;
  
  /* Initialize LEDs and User_Button on STM32F4-Discovery --------------------*/
  STM_EVAL_PBInit(BUTTON_USER, BUTTON_MODE_EXTI); 
  
  STM_EVAL_LEDInit(LED4);
  STM_EVAL_LEDInit(LED3);
  STM_EVAL_LEDInit(LED5);
  STM_EVAL_LEDInit(LED6);

  RCC_GetClocksFreq(&RCC_Clocks);
  
  EVAL_AUDIO_Init(OUTPUT_DEVICE_HEADPHONE, 80, I2S_AudioFreq_8k);//��������� ���������������
  
  
  STM_EVAL_LEDOff(LED6);
  Delay_ms(10);
  simple_rec_start();//������������� � ������ ������
  
  EVAL_AUDIO_Play((uint16_t*)(&audiodata[0]),16*2*2);//������ ���������������
  
  //������ ��� �� ����������� ��������������� � ������
  
  while(1)
  {
    asm("nop");
  }
  
}





/**
  * @brief  Calculates the remaining file size and new position of the pointer.
  * @param  None
  * @retval None
  */
void EVAL_AUDIO_TransferComplete_CallBack(uint32_t* pBuffer, uint32_t Size)
{
  uint8_t i;
  uint8_t b;
  /* Calculate the remaining audio data in the file and the new size 
     for the DMA transfer. If the Audio files size is less than the DMA max 
     data transfer size, so there is no calculation to be done, just restart 
     from the beginning of the file ... */
  /* Check if the end of file has been reached */
  //����������, ����� ���� ���� �������
  asm("nop");
#ifdef AUDIO_MAL_MODE_NORMAL  
  for (i=0;i<32;i++)
  {
    audiodata[i] = RecBuf[i>>1];//�� ���� ������ ������-������
  }  
  
  EVAL_AUDIO_Play((uint16_t*)(&audiodata[0]),16*2*2);
  STM_EVAL_LEDToggle(LED6);
  
#endif
}








///////////////////////////////////








void Delay_ms(uint32_t ms)
{
        volatile uint32_t nCount;
        RCC_ClocksTypeDef RCC_Clocks;
        RCC_GetClocksFreq (&RCC_Clocks);
        nCount=(RCC_Clocks.HCLK_Frequency/10000)*ms;
        for (; nCount!=0; nCount--);
}










void Delay(__IO uint32_t nTime)
{
  TimingDelay = nTime;

  while(TimingDelay != 0);
}

void TimingDelay_Decrement(void)
{
  if (TimingDelay != 0x00)
  { 
    TimingDelay--;
  }
}

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
