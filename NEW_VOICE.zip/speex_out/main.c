/**
  ******************************************************************************
  * ��������������� ����� �� FLASH ������� �����������
  * � �������������� SPEEX
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4_discovery_audio_codec.h"
#include "waveplayer.h"
#include <speex/speex.h>
#include "voice.h"



/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
__IO uint8_t UserButtonPressed = 0;
__IO uint32_t TimingDelay;


/* Private function prototypes -----------------------------------------------*/
void Delay_ms(uint32_t ms);


/* Private functions ---------------------------------------------------------*/

int main(void)
{
  //����� - ����� #define AUDIO_MAL_MODE_NORMAL - AUDIO_MAL_DMA_IT_TC_EN - ��� DAC
  
  RCC_ClocksTypeDef RCC_Clocks;
  
  /* Initialize LEDs and User_Button on STM32F4-Discovery --------------------*/
  STM_EVAL_PBInit(BUTTON_USER, BUTTON_MODE_EXTI); 
  
  STM_EVAL_LEDInit(LED4);
  STM_EVAL_LEDInit(LED3);
  STM_EVAL_LEDInit(LED5);
  STM_EVAL_LEDInit(LED6);

  RCC_GetClocksFreq(&RCC_Clocks);
  
  WavePlayerInit(I2S_AudioFreq_8k);
  Speex_Play_Init();
  
  
  while(1)
  {
    asm("nop");
    play_message(&male_voice[0],male_voice_frames);
  }
}


//////////////////////////////////////////////////////



void Delay_ms(uint32_t ms)
{
        volatile uint32_t nCount;
        RCC_ClocksTypeDef RCC_Clocks;
        RCC_GetClocksFreq (&RCC_Clocks);
        nCount=(RCC_Clocks.HCLK_Frequency/10000)*ms;
        for (; nCount!=0; nCount--);
}










void Delay(__IO uint32_t nTime)
{
  TimingDelay = nTime;

  while(TimingDelay != 0);
}

void TimingDelay_Decrement(void)
{
  if (TimingDelay != 0x00)
  { 
    TimingDelay--;
  }
}

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
