#ifndef _STRING_DEC_
#define _STRING_DEC_



void utf8Tocp1251(uint8_t string[],uint8_t output[],uint8_t maxlen,uint8_t length);
uint8_t str_search(uint8_t data[],uint16_t length);
void decode_str(uint8_t string[]);

#endif
