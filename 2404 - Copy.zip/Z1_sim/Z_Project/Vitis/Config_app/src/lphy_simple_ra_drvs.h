#ifndef LPHY_SIMPLE_RA_DRVS_H_
#define LPHY_SIMPLE_RA_DRVS_H_

#include "fpga_register_config.h"

#define LPHY_RA_IQ_SWAP_OFFSET				0x4080u
#define LPHY_RA_IN_TP_GEN_OFFSET			0x4084u
#define LPHY_RA_OUT_TP_GEN_OFFSET			0x4088u
#define LPHY_RA_FREQ_SHIFT_SEL_OFFSET		0x408Cu
#define LPHY_RA_RACH_FREQ_SHIFT_OFFSET		0x4090u
#define LPHY_RA_RACH_K_BAR_OFFSET			0x4094u

#define LPHY_RA_DEBUG_MODE_OFFSET			0x4098u
#define LPHY_RA_DEBUG_SUBFRM_OFFSET			0x409Cu
#define LPHY_RA_DEBUG_FILTER_IDX_OFFSET		0x40A0u
#define LPHY_RA_DEBUG_TIME_OFFSET			0x40A4u
#define LPHY_RA_DEBUG_FRAME_STRUCT_OFFSET	0x40A8u
#define LPHY_RA_DEBUG_CP_LENGTH_OFFSET		0x40ACu
#define LPHY_RA_DEBUG_NUM_PSYM_OFFSET		0x40B0u
#define LPHY_RA_DEBUG_FREQ_OFFSET			0x40B4u
#define LPHY_RA_DEBUG_NUM_RO_OFFSET			0x40B8u
#define LPHY_RA_DEBUG_PRBC_OFFSET			0x40BCu

#define LPHY_RA_ENABLE_OFFSET				0x4100u


#define LPHY_RA_SCS_IDX_OFFSET				0x410Cu
#define LPHY_RA_FFT_IDX_OFFSET				0x4110u
#define LPHY_RA_TYPE_OFFSET					0x4118u
#define LPHY_RA_FREQ_SHIFT_7P5K_OFFSET		0x4120u
#define LPHY_RA_SLOT_OFFSET					0x4304u

#define LPHY_RA_TAGC_BACKOFF_OFFSET			0x4388u
#define LPHY_RA_TAGC_MODE_OFFSET			0x438Cu
#define LPHY_RA_TA_ADVANCE_OFFSET			0x4138u

#define LPHY_RA_IQ_SWAP_OFF					0x0
#define LPHY_RA_IQ_SWAP_ON					0x1
#define lphy_simple_ra_IQ_swap_mode(BaseAddr, IQ_Mode) \
	fpga_write32_register(BaseAddr, LPHY_RA_IQ_SWAP_OFFSET, IQ_Mode)

#define LPHY_RA_INPUT_PATTERN_OFF			0x0
#define LPHY_RA_INPUT_PATTERN_ON			0x1
#define lphy_simple_ra_input_TestPattern_gen(BaseAddr, InputMode) \
	fpga_write32_register(BaseAddr, LPHY_RA_IN_TP_GEN_OFFSET, InputMode)

#define LPHY_RA_OUTPUT_PATTERN_OFF			0x0
#define LPHY_RA_OUTPUT_PATTERN_ON			0x1
#define lphy_simple_ra_output_TestPattern_gen(BaseAddr, OutputMode) \
	fpga_write32_register(BaseAddr, LPHY_RA_OUT_TP_GEN_OFFSET, OutputMode)

#define LPHY_RA_FREQ_SHIFT_OFF				0x0
#define LPHY_RA_FREQ_SHIFT_ON				0x1
#define lphy_simple_ra_FreqShift_mode(BaseAddr, FreqShift_Mode) \
	fpga_write32_register(BaseAddr, LPHY_RA_FREQ_SHIFT_SEL_OFFSET, FreqShift_Mode)

#define lphy_simple_ra_FreqShift(BaseAddr, FreqShift) \
	fpga_write32_register(BaseAddr, LPHY_RA_RACH_FREQ_SHIFT_OFFSET, FreqShift)

#define lphy_simple_ra_rach_k_bar(BaseAddr, RachKBar) \
	fpga_write32_register(BaseAddr, LPHY_RA_RACH_K_BAR_OFFSET, RachKBar)

#define LPHY_RA_DEBUG_NONE					0x0
#define LPHY_RA_DEBUG_ORAN					0x1
#define lphy_simple_ra_debug_mode(BaseAddr, DebugMode) \
	fpga_write32_register(BaseAddr, LPHY_RA_DEBUG_MODE_OFFSET, DebugMode)

#define lphy_simple_ra_debug_subfrm(BaseAddr, Debug_SubFrm) \
	fpga_write32_register(BaseAddr, LPHY_RA_DEBUG_SUBFRM_OFFSET, Debug_SubFrm)

#define lphy_simple_ra_debug_filter_index(BaseAddr, FilterIndex) \
	fpga_write32_register(BaseAddr, LPHY_RA_DEBUG_FILTER_IDX_OFFSET, FilterIndex)

#define lphy_simple_ra_debug_time_offset(BaseAddr, TimeOffset) \
	fpga_write32_register(BaseAddr, LPHY_RA_DEBUG_TIME_OFFSET, TimeOffset)

#define lphy_simple_ra_debug_time_offset(BaseAddr, TimeOffset) \
	fpga_write32_register(BaseAddr, LPHY_RA_DEBUG_TIME_OFFSET, TimeOffset)

#define lphy_simple_ra_debug_frame_struct(BaseAddr, FrameStruct) \
	fpga_write32_register(BaseAddr, LPHY_RA_DEBUG_FRAME_STRUCT_OFFSET, FrameStruct)

#define lphy_simple_ra_debug_CP_Length(BaseAddr, CP_Length) \
	fpga_write32_register(BaseAddr, LPHY_RA_DEBUG_CP_LENGTH_OFFSET, CP_Length)

#define lphy_simple_ra_debug_PSym(BaseAddr, PSym) \
	fpga_write32_register(BaseAddr, LPHY_RA_DEBUG_NUM_PSYM_OFFSET, PSym)

#define lphy_simple_ra_debug_FreqOffset(BaseAddr, FreqOffset) \
	fpga_write32_register(BaseAddr, LPHY_RA_DEBUG_FREQ_OFFSET, FreqOffset)

#define lphy_simple_ra_debug_NumRO(BaseAddr, NumRO) \
	fpga_write32_register(BaseAddr, LPHY_RA_DEBUG_NUM_RO_OFFSET, NumRO)

#define lphy_simple_ra_debug_PRBC(BaseAddr, PRBC) \
	fpga_write32_register(BaseAddr, LPHY_RA_DEBUG_PRBC_OFFSET, PRBC)


#define lphy_simple_ra_enable(BaseAddr) \
	fpga_write32_register(BaseAddr, LPHY_RA_ENABLE_OFFSET, 0); \
	fpga_write32_register(BaseAddr, LPHY_RA_ENABLE_OFFSET, 1)


#define LPHY_RA_SCS_15KHZ					0x0
#define LPHY_RA_SCS_30KHZ					0x1
#define LPHY_RA_SCS_60KHZ					0x2
#define lphy_simple_ra_SCS_idx(BaseAddr, SCS_Idx) \
	fpga_write32_register(BaseAddr, LPHY_RA_SCS_IDX_OFFSET, SCS_Idx)

#define LPHY_RA_FFT_512						0x0
#define LPHY_RA_FFT_1024					0x1
#define LPHY_RA_FFT_2048					0x2
#define LPHY_RA_FFT_4096					0x3
#define lphy_simple_ra_FFT_idx(BaseAddr, FFT_Idx) \
	fpga_write32_register(BaseAddr, LPHY_RA_FFT_IDX_OFFSET, FFT_Idx)

#define LPHY_RA_LTE_PRACH					0x0
#define LPHY_RA_NR_LONG_PRACH				0x2
#define LPHY_RA_NR_SHORT_PRACH				0x3
#define lphy_simple_ra_type(BaseAddr, PRACH_Type) \
	fpga_write32_register(BaseAddr, LPHY_RA_TYPE_OFFSET, PRACH_Type)

#define LPHY_RA_FREQ_7P5K_SHIFT_OFF			0x0
#define LPHY_RA_FREQ_7P5K_SHIFT_ON			0x1
#define lphy_simple_ra_freqShift7p5k(BaseAddr, Freq_7p5K_Mode) \
	fpga_write32_register(BaseAddr, LPHY_RA_FREQ_SHIFT_7P5K_OFFSET, Freq_7p5K_Mode)

#define lphy_simple_ra_SlotOffset(BaseAddr, SlotOffset) \
	fpga_write32_register(BaseAddr, LPHY_RA_SLOT_OFFSET, SlotOffset)

#define lphy_simple_ra_ta_advance(BaseAddr, ta_advance) \
	fpga_write32_register(BaseAddr, LPHY_RA_TA_ADVANCE_OFFSET, ta_advance)

#define lphy_simple_ra_tagc_backoff(BaseAddr, tagc_backoff) \
	fpga_write32_register(BaseAddr, LPHY_RA_TAGC_BACKOFF_OFFSET, tagc_backoff)

#define LPHY_RA_TAGC_OFF					0x0
#define LPHY_RA_TAGC_ON						0x1
#define lphy_simple_ra_tagc_mode(BaseAddr, tagc_mode) \
	fpga_write32_register(BaseAddr, LPHY_RA_TAGC_MODE_OFFSET, tagc_mode)

void lphy_simple_ra_LTE_20MHz(uint32_t BaseAddr);

void lphy_simple_ra_LTE_10MHz(uint32_t BaseAddr);
void lphy_simple_ra_LTE_3MHz(uint32_t BaseAddr);

#endif
