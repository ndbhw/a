#include "sysctrl_drvs.h"
#include "sleep.h"

void sysctrl_preset(u32 BaseAddr) {
	sysctrl_set_dl_cc0_advance(BaseAddr, 10000);
	sysctrl_set_dl_cc1_advance(BaseAddr, 10000);
	sysctrl_set_ul_cc0_retard(BaseAddr, 1000);
	sysctrl_set_ul_cc1_retard(BaseAddr, 1000);
	sysctrl_set_n_ta_offset_cc0(BaseAddr, 0x6400);
	sysctrl_set_n_ta_offset_cc1(BaseAddr, 0x6400);
}

void sysctrl_reset(u32 BaseAddr) {
	sysctrl_reset_inter_pll(BaseAddr);
	usleep(10);

	sysctrl_reset_dcif(BaseAddr);
	sysctrl_reset_misc(BaseAddr);

	sysctrl_reset_ecpri(BaseAddr);

	sysctrl_reset_oran_framer(BaseAddr);
	sysctrl_reset_oran_deframer(BaseAddr);
	sysctrl_reset_oran_switch(BaseAddr);

	sysctrl_reset_bbtop(BaseAddr);
	sysctrl_reset_dlfe(BaseAddr);
	sysctrl_reset_ulfe(BaseAddr);
	sysctrl_reset_rafe(BaseAddr);

	sysctrl_reset_bbctrl(BaseAddr);

	sysctrl_reset_ulfe(BaseAddr);

	sysctrl_reset_dsp_top(BaseAddr);
	sysctrl_reset_dduc(BaseAddr);
	sysctrl_reset_cfr(BaseAddr);
	sysctrl_reset_dpd(BaseAddr);
	sysctrl_reset_dpdcpu(BaseAddr);


	sysctrl_reset_serdes(BaseAddr);
	sysctrl_reset_cpri(BaseAddr);
	sysctrl_reset_iqcomp(BaseAddr);
	sysctrl_reset_ethmux(BaseAddr);

	sysctrl_reset_aurora(BaseAddr);

	sysctrl_reset_sbif(BaseAddr);
	sysctrl_reset_sbifphy(BaseAddr);
	sysctrl_reset_pim(BaseAddr);
	sysctrl_reset_pim_sbif(BaseAddr);
	sysctrl_reset_pim_sbifphy(BaseAddr);
}
