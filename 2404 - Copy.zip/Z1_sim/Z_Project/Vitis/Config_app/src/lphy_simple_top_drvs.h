#ifndef LPHY_SIMPLE_TOP_DRVS_H_
#define LPHY_SIMPLE_TOP_DRVS_H_

#include "fpga_register_config.h"

#define LPHY_TOP_UL_CC0_SYNC_RETARD_OFFSET			0x0010u

#define LPHY_TOP_UL_CC1_SYNC_RETARD_OFFSET			0x0020u
#define LPHY_TOP_UL_CC0_NB_SYNC_RETARD_OFFSET		0x0110u
#define LPHY_TOP_UL_CC0_DATA_DELAY_OFFSET			0x0050u

#define LPHY_TOP_DLFE_CC0_PROG_DLY_OFFSET			0x0010u
#define LPHY_TOP_ULFE_CC0_PROG_DLY_OFFSET			0x0014u
#define LPHY_TOP_RAFE_CC0_PROG_DLY_OFFSET			0x0018u
#define LPHY_TOP_ULDL_CC0_SYNC_DIFF_OFFSET			0x001Cu


#define lphy_simple_top_ul_cc0_sync_retard(BaseAddr, SyncRetard_Val) \
	fpga_write32_register(BaseAddr,LPHY_TOP_UL_CC0_SYNC_RETARD_OFFSET,SyncRetard_Val)

#define lphy_simple_top_ul_cc1_sync_retard(BaseAddr, SyncRetard_Val) \
	fpga_write32_register(BaseAddr,LPHY_TOP_UL_CC1_SYNC_RETARD_OFFSET,SyncRetard_Val)

#define lphy_simple_top_ul_cc0_nb_sync_retard(BaseAddr, SyncRetard_Val) \
	fpga_write32_register(BaseAddr,LPHY_TOP_UL_CC0_NB_SYNC_RETARD_OFFSET,SyncRetard_Val)


#define lphy_simple_top_ul_cc0_data_delay(BaseAddr, SyncRetard_Val) \
	fpga_write32_register(BaseAddr,LPHY_TOP_UL_CC0_DATA_DELAY_OFFSET,SyncRetard_Val)


#define lphy_simple_top_dlfe_cc0_prog_dly(BaseAddr) \
	fpga_read32_register(BaseAddr,LPHY_TOP_DLFE_CC0_PROG_DLY_OFFSET)

#define lphy_simple_top_ulfe_cc0_prog_dly(BaseAddr) \
	fpga_read32_register(BaseAddr,LPHY_TOP_ULFE_CC0_PROG_DLY_OFFSET)

#define lphy_simple_top_rafe_cc0_prog_dly(BaseAddr) \
	fpga_read32_register(BaseAddr,LPHY_TOP_RAFE_CC0_PROG_DLY_OFFSET)

#define lphy_simple_top_uldl_cc0_diff(BaseAddr) \
	fpga_read32_register(BaseAddr,LPHY_TOP_ULDL_CC0_SYNC_DIFF_OFFSET)

void lphy_simple_top_config(uint32_t BaseAddr);



#endif
