#ifndef FPGA_REGISTER_CONFIG_H
#define FPGA_REGISTER_CONFIG_H

#include "xil_io.h"
#include <stdio.h>
#include <stdlib.h>

#define fpga_read32_register(Core_BaseAddr,Register_Offset) \
	Xil_In32(Core_BaseAddr+Register_Offset)

#define fpga_write32_register(Core_BaseAddr,Register_Offset,Register_Value) \
	Xil_Out32(Core_BaseAddr+Register_Offset,Register_Value)

#define fpga_write8_register(Core_BaseAddr,Register_Offset,Register_Value) \
	Xil_Out8(Core_BaseAddr+Register_Offset,Register_Value)

#endif
