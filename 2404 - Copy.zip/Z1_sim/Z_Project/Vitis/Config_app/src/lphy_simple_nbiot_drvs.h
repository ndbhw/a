#ifndef LPHY_SIMPLE_NB_DRVS_H
#define LPHY_SIMPLE_NB_DRVS_H

#include "fpga_register_config.h"

#define LPHY_NB_SCS_IDX				0x0100u
#define LPHY_NB_TIME_OFFSET			0x0104u
#define LPHY_NB_N_SAMP				0x0108u
#define LPHY_NB_FREG_SHIFT			0x010Cu
#define LPHY_NB_INIT_REG			0x0110u
#define LPHY_NB_N_FFT				0x0114u
#define LPHY_NB_NUM_PSYM			0x0118u
#define LPHY_NB_NUM_RE				0x011Cu
#define LPHY_NB_CONFIG_EN			0x0120u
#define LPHY_NB_TIMING_INFO			0x0124u
#define LPHY_NB_REAL_TIMING_INFO	0x0128u
#define LPHY_NB_FREG_OFFSET_REG		0x012Cu
#define LPHY_NB_SEL_IN_PATH			0x0130u
#define LPHY_NB_ADV_OFFSET			0x0138u
#define LPHY_NB_CP_DELAY			0x0154u
#define LPHY_NB_CP_DELAY2			0x0158u
#define LPHY_NB_FSYNC_DLY_VAL		0x0150u
#define LPHY_NBIOT_TA_ADVANCE_OFFSET			0x4138u
#define LPHY_NBIOT_TA_FSYNC_DLY_OFFSET			0x0150u

#define initialValue				0x0

#define lphy_simple_nbiot_ta_advance(BaseAddr, ta_advance) \
	fpga_write32_register(BaseAddr, LPHY_NBIOT_TA_ADVANCE_OFFSET, ta_advance)

#define lphy_simple_nbiot_FSYNC_DLY(BaseAddr, FSYNC_DLY) \
	fpga_write32_register(BaseAddr, LPHY_NBIOT_TA_FSYNC_DLY_OFFSET, FSYNC_DLY)



#define lphy_simple_nb_scs_idx(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_SCS_IDX,initial_value)

#define lphy_simple_nb_time_offset(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_TIME_OFFSET,initial_value)

#define lphy_simple_nb_n_samp(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_N_SAMP,initial_value)

#define lphy_simple_nb_freg_shift(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_FREG_SHIFT,initial_value)

#define lphy_simple_nb_init_reg(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_INIT_REG,initial_value)

#define lphy_simple_nb_n_fft(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_N_FFT,initial_value)

#define lphy_simple_nb_num_psym(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_NUM_PSYM,initial_value)

#define lphy_simple_nb_num_re(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_NUM_RE,initial_value)

#define lphy_simple_nb_config_en(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_CONFIG_EN,initial_value)

#define lphy_simple_nb_timing_info(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_TIMING_INFO,initial_value)

#define lphy_simple_nb_real_timing_info(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_REAL_TIMING_INFO,initial_value)

#define lphy_simple_nb_freg_offset_reg(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_FREG_OFFSET_REG,initial_value)

#define lphy_simple_nb_sel_in_path(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_SEL_IN_PATH,initial_value)

#define lphy_simple_nb_adv_offset(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_ADV_OFFSET,initial_value)

#define lphy_simple_nb_cp_delay(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_CP_DELAY,initial_value)

#define lphy_simple_nb_cp_delay2(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_CP_DELAY2,initial_value)

#define lphy_simple_nb_fsync_dly_val(BaseAddr, initial_value) \
	fpga_write32_register(BaseAddr,LPHY_NB_FSYNC_DLY_VAL,initial_value)

void lphy_simple_nb_config(uint32_t BaseAddr);

#endif
