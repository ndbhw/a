#ifndef LPHY_SIMPLE_DL_DRVS_H_
#define LPHY_SIMPLE_DL_DRVS_H_

#include "fpga_register_config.h"

#define LPHY_DL_IQ_SWAP_OFFSET				0x0004u
#define LPHY_DL_FRM_STRUCT_OFFSET			0x0008u
#define LPHY_DL_CDDCP_BUF_RETARD_OFFSET		0x000Cu
#define LPHY_DL_DEBUG_MODE_OFFSET			0x0100u
#define LPHY_DL_DEBUG_REMASK_OFFSET			0x0104u
#define LPHY_DL_DEBUG_FRM_STRUCT_OFFSET		0x0108u
#define LPHY_DL_DEBUG_NLAYER_BEAM_OFFSET	0x010Cu
#define LPHY_DL_DEBUG_MON_SMP_OFFSET		0x0110u

#define LPHY_DL_SYSMODE_OFFSET				0x0200u
#define LPHY_DL_K0_OFFSET					0x0204u
#define LPHY_DL_SHIFT_A_OFFSET				0x0208u
#define LPHY_DL_NRE_OFFSET					0x020Cu
#define LPHY_DL_FFT_TYPE_OFFSET				0x0210u
#define LPHY_DL_CP_TYPE_OFFSET				0x0214u
#define LPHY_DL_SCALE_ANT_GAIN_OFFSET		0x0218u
#define LPHY_DL_ANT_GAIN_OFFSET				0x021Cu
#define LPHY_DL_SCS_TYPE_OFFSET				0x0240u
#define LPHY_DL_ANT_BITMAP_OFFSET			0x024Cu
#define LPHY_DL_DOWNSHIFT_OFFSET			0x0254u
#define LPHY_DL_CDD_VALUE0_OFFSET			0x0300u
#define LPHY_DL_CDD_VALUE1_OFFSET			0x0304u
#define LPHY_DL_CDD_VALUE2_OFFSET			0x0308u
#define LPHY_DL_CDD_VALUE3_OFFSET			0x030Cu

#define LPHY_DL_SIGSUS_CNT_RST_OFFSET			0x0670
#define LPHY_DL_SIGSUS_ENA_AND_TYPE_OFFSET		0x0674
#define LPHY_DL_SIGSUS_COMMON_THRESHOLD_OFFSET	0x0678

#define LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_0_OFFSET	0x067C
#define LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_1_OFFSET	0x0680
#define LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_2_OFFSET	0x0684
#define LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_3_OFFSET	0x0688
#define LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_4_OFFSET	0x068C
#define LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_5_OFFSET	0x0690
#define LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_6_OFFSET	0x0694
#define LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_7_OFFSET	0x0698
#define LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_8_OFFSET	0x069C
#define LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_9_OFFSET	0x06A0
#define LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_10_OFFSET	0x06A4
#define LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_11_OFFSET	0x06A8
#define LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_12_OFFSET	0x06AC
#define LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_13_OFFSET	0x06B0

#define LPHY_DL_SIGSUS_CNT_UPPER_THRESHOLD_SYMBOL_0_OFFSET	0x06C0
#define LPHY_DL_SIGSUS_CNT_UPPER_THRESHOLD_SYMBOL_1_OFFSET	0x06C4
#define LPHY_DL_SIGSUS_CNT_UPPER_THRESHOLD_SYMBOL_2_OFFSET	0x06C8
#define LPHY_DL_SIGSUS_CNT_UPPER_THRESHOLD_SYMBOL_3_OFFSET	0x06CC
#define LPHY_DL_SIGSUS_CNT_UPPER_THRESHOLD_SYMBOL_4_OFFSET	0x06D0
#define LPHY_DL_SIGSUS_CNT_UPPER_THRESHOLD_SYMBOL_5_OFFSET	0x06D4
#define LPHY_DL_SIGSUS_CNT_UPPER_THRESHOLD_SYMBOL_6_OFFSET	0x06D8
#define LPHY_DL_SIGSUS_CNT_UPPER_THRESHOLD_SYMBOL_7_OFFSET	0x06DC
#define LPHY_DL_SIGSUS_CNT_UPPER_THRESHOLD_SYMBOL_8_OFFSET	0x06E0
#define LPHY_DL_SIGSUS_CNT_UPPER_THRESHOLD_SYMBOL_9_OFFSET	0x06E4
#define LPHY_DL_SIGSUS_CNT_UPPER_THRESHOLD_SYMBOL_10_OFFSET	0x06E8
#define LPHY_DL_SIGSUS_CNT_UPPER_THRESHOLD_SYMBOL_11_OFFSET	0x06EC
#define LPHY_DL_SIGSUS_CNT_UPPER_THRESHOLD_SYMBOL_12_OFFSET	0x06F0
#define LPHY_DL_SIGSUS_CNT_UPPER_THRESHOLD_SYMBOL_13_OFFSET	0x06F4

#define LPHY_DL_SIGSUS_MAX_PWR_SYMBOL_0_OFFSET	0x0700 => ddooir addree from here
#define LPHY_DL_SIGSUS_MAX_PWR_SYMBOL_1_OFFSET	0x0704
#define LPHY_DL_SIGSUS_MAX_PWR_SYMBOL_2_OFFSET	0x0708
#define LPHY_DL_SIGSUS_MAX_PWR_SYMBOL_3_OFFSET	0x070C
#define LPHY_DL_SIGSUS_MAX_PWR_SYMBOL_4_OFFSET	0x0710
#define LPHY_DL_SIGSUS_MAX_PWR_SYMBOL_5_OFFSET	0x0714
#define LPHY_DL_SIGSUS_MAX_PWR_SYMBOL_6_OFFSET	0x0718
#define LPHY_DL_SIGSUS_MAX_PWR_SYMBOL_7_OFFSET	0x071C
#define LPHY_DL_SIGSUS_MAX_PWR_SYMBOL_8_OFFSET	0x0720
#define LPHY_DL_SIGSUS_MAX_PWR_SYMBOL_9_OFFSET	0x0724
#define LPHY_DL_SIGSUS_MAX_PWR_SYMBOL_10_OFFSET	0x0728
#define LPHY_DL_SIGSUS_MAX_PWR_SYMBOL_11_OFFSET	0x072C
#define LPHY_DL_SIGSUS_MAX_PWR_SYMBOL_12_OFFSET	0x0730
#define LPHY_DL_SIGSUS_MAX_PWR_SYMBOL_13_OFFSET	0x0734

#define RESET_ON	0x1
#define RESET_OFF   0x0
#define lphy_simple_dl_sigsus_cnt_reset(BaseAddr, CounterReset) \
	fpga_write32_register(BaseAddr,LPHY_DL_SIGSUS_CNT_RST_OFFSET,CounterReset)

#define SIGSUS_ENA_COMMON_THRES		0x1
#define SIGSUS_ENA_THRES_PER_SYM	0x2
#define SIGSUS_DISABLE				0x0
#define lphy_simple_dl_sigsus_enable_type(BaseAddr, SigsusEnaType) \
	fpga_write32_register(BaseAddr,LPHY_DL_SIGSUS_ENA_AND_TYPE_OFFSET,SigsusEnaType)

#define lphy_simple_dl_sigsus_common_thres(BaseAddr, CommonThres) \
	fpga_write32_register(BaseAddr,LPHY_DL_SIGSUS_COMMON_THRESHOLD_OFFSET,CommonThres)

#define lphy_simple_dl_sigsus_thres_per_sym(BaseAddr, SymbolAddres, SymbolThres) \
	fpga_write32_register(BaseAddr,SymbolAddres,SymbolThres)

#define LPHY_DL_IQ_SWAP_OFF					0x0
#define LPHY_DL_IQ_SWAP_ON					0x1
#define lphy_simple_dl_IQ_Swap(BaseAddr, IQ_SwapMode) \
	fpga_write32_register(BaseAddr,LPHY_DL_IQ_SWAP_OFFSET, IQ_SwapMode)

#define LPHY_DL_FRAME_SOURCE_MPLANE			0x0
#define LPHY_DL_FRAME_SOURCE_CPLANE			0x1
#define lphy_simple_dl_FrameSource(BaseAddr, FrameSource) \
	fpga_write32_register(BaseAddr,LPHY_DL_FRM_STRUCT_OFFSET, FrameSource)

#define lphy_simple_dl_CDD_CPBuffer(BaseAddr, CDD_CPBuffer) \
	fpga_write32_register(BaseAddr,LPHY_DL_CDDCP_BUF_RETARD_OFFSET, CDD_CPBuffer)

#define LPHY_DL_DEBUG_MODE_OFF				0x0
#define LPHY_DL_DEBUG_MODE_ON				0x1
#define lphy_simple_dl_DebugMode(BaseAddr, DebugMode) \
	fpga_write32_register(BaseAddr,LPHY_DL_DEBUG_MODE_OFFSET, DebugMode)

#define LPHY_DL_DEBUG_REMASK_OFF			0x0
#define LPHY_DL_DEBUG_REMASK_ON				0x1
#define lphy_simple_dl_DebugRemask(BaseAddr, DebugRemask) \
	fpga_write32_register(BaseAddr,LPHY_DL_DEBUG_REMASK_OFFSET, DebugRemask)

#define LPHY_DL_DEBUG_FFT_512 				0x9
#define LPHY_DL_DEBUG_FFT_1024				0xA
#define LPHY_DL_DEBUG_FFT_2048				0xB
#define LPHY_DL_DEBUG_FFT_4096				0xC
#define lphy_simple_dl_Debug_FrameStruct(BaseAddr, FFT_Size, SCS_Type) \
	fpga_write32_register(BaseAddr,LPHY_DL_DEBUG_FRM_STRUCT_OFFSET, (0xFFu & ((FFT_Size<<4) | SCS_Type)))

#define lphy_simple_dl_Debug_NLayer(BaseAddr, NLayer) \
	fpga_write32_register(BaseAddr,LPHY_DL_DEBUG_NLAYER_BEAM_OFFSET, (0x1F0000u & ((NLayer<<16))))

#define lphy_simple_dl_Debug_MonSMP(BaseAddr, PathIndex, FrameIndex, SubFramIndex, SymbIndex) \
	fpga_write32_register(BaseAddr,LPHY_DL_DEBUG_MON_SMP_OFFSET, (0x0FFFFFFFu & ((PathIndex<<24) | (FrameIndex<<16) | (SubFramIndex<<8) | SymbIndex)))

#define lphy_simple_dl_LTE_SysMode(BaseAddr, MaxTxLayer, NumTxAnt) \
	fpga_write32_register(BaseAddr,LPHY_DL_SYSMODE_OFFSET,(0x000F000Fu & ((MaxTxLayer<<16) | NumTxAnt)))

#define lphy_simple_dl_K0(BaseAddr, K0_Value) \
	fpga_write32_register(BaseAddr,LPHY_DL_K0_OFFSET, 0x0FFFu & K0_Value)

#define lphy_simple_dl_FreqShiftA(BaseAddr, FreqShiftA) \
	fpga_write32_register(BaseAddr,LPHY_DL_SHIFT_A_OFFSET, FreqShiftA)


#define LPHY_DL_LTE_1P4MHZ_RE						72
#define LPHY_DL_LTE_3MHZ_RE							180
#define LPHY_DL_LTE_5MHZ_RE							300
#define LPHY_DL_LTE_10MHZ_RE						600
#define LPHY_DL_NR_100MHZ_RE						3276
#define LPHY_DL_LTE_15MHZ_RE						900
#define LPHY_DL_LTE_20MHZ_RE						1200

#define lphy_simple_dl_NumRE(BaseAddr, NumRE) \
	fpga_write32_register(BaseAddr,LPHY_DL_NRE_OFFSET, NumRE)

#define LPHY_DL_FFT_512								0
#define LPHY_DL_FFT_1024							1
#define LPHY_DL_FFT_2048							2
#define LPHY_DL_FFT_4096							3
#define lphy_simple_dl_FFT_Size(BaseAddr, FFT_Size) \
	fpga_write32_register(BaseAddr,LPHY_DL_FFT_TYPE_OFFSET, FFT_Size)

#define LPHY_DL_CP_NORMAL							0
#define LPHY_DL_CP_EXTEND							1
#define lphy_simple_dl_cp_type(BaseAddr, CP_Type) \
	fpga_write32_register(BaseAddr,LPHY_DL_CP_TYPE_OFFSET,CP_Type)

#define lphy_simple_dl_ScaleAntGain(BaseAddr, ScaleAntGain) \
	fpga_write32_register(BaseAddr,LPHY_DL_SCALE_ANT_GAIN_OFFSET,ScaleAntGain)

#define lphy_simple_dl_AntGain(BaseAddr, AntGain) \
	fpga_write32_register(BaseAddr,LPHY_DL_ANT_GAIN_OFFSET,AntGain)

#define LPHY_DL_SCS_15KHZ							0
#define LPHY_DL_SCS_30KHZ							1
#define lphy_simple_dl_SCS_Type(BaseAddr, AntGain) \
	fpga_write32_register(BaseAddr,LPHY_DL_SCS_TYPE_OFFSET,AntGain)


#define LPHY_DL_4_ANT_ENABLE						0xFu
#define LPHY_DL_2_ANT_ENABLE						0x3u
#define lphy_simple_dl_AntBitMap(BaseAddr, AntBitMap) \
	fpga_write32_register(BaseAddr,LPHY_DL_ANT_BITMAP_OFFSET,AntBitMap)

#define lphy_simple_dl_DownShift(BaseAddr, DownShift) \
	fpga_write32_register(BaseAddr,LPHY_DL_DOWNSHIFT_OFFSET,DownShift)

#define lphy_simple_dl_CDD_Value0(BaseAddr, CddValue0) \
	fpga_write32_register(BaseAddr,LPHY_DL_CDD_VALUE0_OFFSET,CddValue0)

#define lphy_simple_dl_CDD_Value1(BaseAddr, CddValue1) \
	fpga_write32_register(BaseAddr,LPHY_DL_CDD_VALUE1_OFFSET,CddValue1)

#define lphy_simple_dl_CDD_Value2(BaseAddr, CddValue2) \
	fpga_write32_register(BaseAddr,LPHY_DL_CDD_VALUE2_OFFSET,CddValue2)

#define lphy_simple_dl_CDD_Value3(BaseAddr, CddValue3) \
	fpga_write32_register(BaseAddr,LPHY_DL_CDD_VALUE3_OFFSET,CddValue3)

void lphy_simple_dl_config_LTE_20MHz(uint32_t BaseAddr);

void lphy_simple_dl_config_LTE_10MHz(uint32_t BaseAddr);
void lphy_simple_dl_config_LTE_3MHz(uint32_t BaseAddr);



#endif
