#include "lphy_simple_ul_drvs.h"


void lphy_simple_ul_config_LTE_20MHz(uint32_t BaseAddr) {
//	lphy_simple_ul_freq_shift_mode(BaseAddr, LPHY_UL_FREQ_NONE_CARRIER_SHIFT);
	lphy_simple_ul_freq_shift_mode(BaseAddr, LPHY_UL_FREQ_HALF_CARRIER_SHIFT);
	lphy_simple_ul_cp_type(BaseAddr, LPHY_UL_CP_NORMAL);
	lphy_simple_ul_cp_remove(BaseAddr, 0);
	lphy_simple_ul_tagc_mode(BaseAddr, LPHY_UL_TAGC_OFF);
	lphy_simple_ul_tagc_BackOff(BaseAddr, 11);
	lphy_simple_ul_k0_size(BaseAddr, 0);
	lphy_simple_ul_RB_size(BaseAddr, LPHY_UL_LTE_20MHZ_RB);
	lphy_simple_ul_gain_comp_mode(BaseAddr, LPHY_UL_GAIN_COMPENSATION_OFF);
	lphy_simple_ul_CTS_mode(BaseAddr, LPHY_UL_CTS_SHIFT_OFF);
	lphy_simple_ul_CTS_Shift_Offset(BaseAddr, 0);
	lphy_simple_ul_Phase_Compensation_mode(BaseAddr, LPHY_UL_PHASE_COMPENSATION_OFF);
	lphy_simple_ul_FFT_SCS_Type(BaseAddr, LPHY_UL_SCS_15KHZ, LPHY_UL_FFT_2048);
	lphy_simple_ul_MDM_Num(BaseAddr, 2);
	lphy_simple_ul_Anten_Num(BaseAddr, 2);
}

void lphy_simple_ul_config_LTE_10MHz(uint32_t BaseAddr) {
	lphy_simple_ul_freq_shift_mode(BaseAddr, LPHY_UL_FREQ_NONE_CARRIER_SHIFT);
//	lphy_simple_ul_freq_shift_mode(BaseAddr, LPHY_UL_FREQ_HALF_CARRIER_SHIFT);
	lphy_simple_ul_cp_type(BaseAddr, LPHY_UL_CP_NORMAL);
	lphy_simple_ul_cp_remove(BaseAddr, 0);
	lphy_simple_ul_tagc_mode(BaseAddr, LPHY_UL_TAGC_OFF);
	lphy_simple_ul_tagc_BackOff(BaseAddr, 1);
	lphy_simple_ul_k0_size(BaseAddr, 0);
	lphy_simple_ul_RB_size(BaseAddr, LPHY_UL_LTE_10MHZ_RB);
	lphy_simple_ul_gain_comp_mode(BaseAddr, LPHY_UL_GAIN_COMPENSATION_OFF);
	lphy_simple_ul_CTS_mode(BaseAddr, LPHY_UL_CTS_SHIFT_OFF);
	lphy_simple_ul_CTS_Shift_Offset(BaseAddr, 0);
	lphy_simple_ul_Phase_Compensation_mode(BaseAddr, LPHY_UL_PHASE_COMPENSATION_OFF);
	lphy_simple_ul_FFT_SCS_Type(BaseAddr, LPHY_UL_SCS_15KHZ, LPHY_UL_FFT_1024);
	lphy_simple_ul_MDM_Num(BaseAddr, 2);
	lphy_simple_ul_Anten_Num(BaseAddr, 2);
}

void lphy_simple_ul_config_LTE_3MHz(uint32_t BaseAddr) {
	lphy_simple_ul_freq_shift_mode(BaseAddr, LPHY_UL_FREQ_NONE_CARRIER_SHIFT);
//	lphy_simple_ul_freq_shift_mode(BaseAddr, LPHY_UL_FREQ_HALF_CARRIER_SHIFT);
	lphy_simple_ul_cp_type(BaseAddr, LPHY_UL_CP_NORMAL);
	lphy_simple_ul_cp_remove(BaseAddr, 0);
	lphy_simple_ul_tagc_mode(BaseAddr, LPHY_UL_TAGC_OFF);
	lphy_simple_ul_tagc_BackOff(BaseAddr, 1);
	lphy_simple_ul_k0_size(BaseAddr, 0);
	lphy_simple_ul_RB_size(BaseAddr, LPHY_UL_LTE_3MHZ_RB);
	lphy_simple_ul_gain_comp_mode(BaseAddr, LPHY_UL_GAIN_COMPENSATION_OFF);
	lphy_simple_ul_CTS_mode(BaseAddr, LPHY_UL_CTS_SHIFT_OFF);
	lphy_simple_ul_CTS_Shift_Offset(BaseAddr, 0);
	lphy_simple_ul_Phase_Compensation_mode(BaseAddr, LPHY_UL_PHASE_COMPENSATION_OFF);
	lphy_simple_ul_FFT_SCS_Type(BaseAddr, LPHY_UL_SCS_15KHZ, LPHY_UL_FFT_512);
	lphy_simple_ul_MDM_Num(BaseAddr, 2);
	lphy_simple_ul_Anten_Num(BaseAddr, 2);
}
