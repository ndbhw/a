#include "oran_simple_drvs.h"
//#include "fpga_register_config.h"

void oran_26A_5g_20MHz_2cc_configure(u32 BaseAddr) {

	/*PEs config*/
	u8 RU_MAC[6] = {0x80, 0x09, 0x02, 0x03, 0x04, 0x05};
	u8 DU_MAC[6] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

	//	u8 max_pe_list = fpga_read_register(BaseAddr, ORAN_MAX_PE_LIST_OFFSET);

	for (int i = 0; i < 1; i++)
	{
		oran26a_set_pe_list_index(BaseAddr, i);
		oran26a_downlink_pe_set_DST_MAC(BaseAddr, RU_MAC);
		oran26a_downlink_pe_set_SRC_MAC(BaseAddr, DU_MAC);
		//		oran26a_downlink_pe_set_VLAN0_disable(BaseAddr);
		oran26a_downlink_pe_set_VLAN0_enable(BaseAddr, 0x064);
	}

	/*low level tx link setup*/
	oran26a_low_level_tx_link_set_tx_data_type(BaseAddr, TX_DATA_TYPE_PDXCH);
	//	u16 max_tx_link = fpga_read_register(BaseAddr, ORAN_MAX_TX_LINK_OFFSET);

	u16 icc = 0;
	u16 ilink = 0;
	/*link 0 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc, 0);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x01);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 1 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc, 1);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x02);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 3 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc, 2);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x03);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 4 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc, 3);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x04);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 5 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc+1, 0);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x05);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 6 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc+1, 1);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x06);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 7 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc+1, 2);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x07);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 8 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc+1, 3);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x08);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);


	/*low level rx links configs: PUxCH*/
	oran26a_low_level_rx_link_set_rx_data_type(BaseAddr, RX_DATA_TYPE_PUXCH);

	icc = 0;
	ilink = 0;
	/*link 0 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 0);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x01);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 1 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 1);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x02);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 3 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 2);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x03);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 4 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 3);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x04);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 5 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 0);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x05);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 6 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 1);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x06);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 7 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 2);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x07);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 8 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 3);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x08);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*low level rx links configs: PUxCH*/
	oran26a_low_level_rx_link_set_rx_data_type(BaseAddr, RX_DATA_TYPE_PRACH);

	icc = 0;
	ilink = 0;
	/*link 0 rafe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 0);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4040);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 1 rafe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 1);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4041);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 3 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 2);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4042);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 4 rafe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 3);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4043);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 5 rafe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 0);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4140);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 6 rafe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 1);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4141);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 7 rafe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 2);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4142);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 8 rafe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 3);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4143);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);


	/*low level rx links configs: NBIOT*/
	oran26a_low_level_rx_link_set_rx_data_type(BaseAddr, RX_DATA_TYPE_NBIOT_PUSCH);

	icc = 0;
	ilink = 0;
	/*link 0 nbiot*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 0);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4070);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 1 nbiot*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 1);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4071);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 3 nbiot*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 2);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4072);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 4 nbiot*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 3);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4073);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 5 nbiot*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 0);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4170);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 6 nbiot*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 1);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4171);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 7 nbiot*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 2);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4172);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 8 nbiot*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 3);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x4173);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_2048, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_20MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);
}


void oran_26A_5g_10MHz_2cc_configure(u32 BaseAddr) {

	/*PEs config*/
	u8 RU_MAC[6] = {0xda, 0x14, 0xde, 0xb0, 0x55, 0x63};
	u8 DU_MAC[6] = {0x56, 0x3b, 0xbe, 0xa9, 0x92, 0x4c};

	//	u8 max_pe_list = fpga_read_register(BaseAddr, ORAN_MAX_PE_LIST_OFFSET);

	for (int i = 0; i < 1; i++)
	{
		oran26a_set_pe_list_index(BaseAddr, i);
		oran26a_downlink_pe_set_DST_MAC(BaseAddr, RU_MAC);
		oran26a_downlink_pe_set_SRC_MAC(BaseAddr, DU_MAC);
		//		oran26a_downlink_pe_set_VLAN0_disable(BaseAddr);
		oran26a_downlink_pe_set_VLAN0_enable(BaseAddr, 0x01);
	}

	/*low level tx link setup*/
	oran26a_low_level_tx_link_set_tx_data_type(BaseAddr, TX_DATA_TYPE_PDXCH);
	//	u16 max_tx_link = fpga_read_register(BaseAddr, ORAN_MAX_TX_LINK_OFFSET);

	u16 icc = 0;
	u16 ilink = 0;
	/*link 0 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc, 0);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x00);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 1 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc, 1);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x01);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 3 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc, 2);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x02);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 4 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc, 3);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x03);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 5 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc+1, 0);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x05);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 6 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc+1, 1);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x06);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 7 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc+1, 2);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x07);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 8 dlfe*/
	oran26a_low_level_tx_link_set_index(BaseAddr, icc+1, 3);
	oran26a_low_level_tx_link_set_eaxc_id(BaseAddr, 0x08);
	oran26a_low_level_tx_link_set_up_only(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_tx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_tx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_tx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_tx_link_set_comp_exp_offset(BaseAddr, 0);


	/*low level rx links configs: PUxCH*/
	oran26a_low_level_rx_link_set_rx_data_type(BaseAddr, RX_DATA_TYPE_PUXCH);

	icc = 0;
	ilink = 0;
	/*link 0 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 0);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x01);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 1 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 1);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x02);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 3 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 2);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x03);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 4 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc, 3);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x04);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 5 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 0);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x05);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 6 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 1);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x06);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 7 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 2);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x07);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);

	/*link 8 ulfe*/
	oran26a_low_level_rx_link_set_index(BaseAddr, icc+1, 3);
	oran26a_low_level_rx_link_set_eaxc_id(BaseAddr, 0x08);
	oran26a_low_level_rx_link_set_comp_mode(BaseAddr, BFP_COMPRESSION_MODE, DATA_9_BIT_MODE);
	oran26a_low_level_rx_link_set_frame_struct(BaseAddr, ORAN_FFT_1024, ORAN_SCS_15KHZ);
	oran26a_low_level_rx_link_set_prb_num(BaseAddr, ORAN_15KHZ_10MHZ_PRB);
	oran26a_low_level_rx_link_set_pe_index(BaseAddr, 0);
	oran26a_low_level_rx_link_set_comp_exp_offset(BaseAddr, 0);
}



void oran_25A_5g_10MHz_2cc_configure(u32 BaseAddr) {
	u8 DL_DST_MAC[6] = {0x80, 0x09, 0x02, 0x03, 0x04, 0x05};
	u8 DL_SRC_MAC[6] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	u8 UL_DST_MAC[6] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	u8 UL_SRC_MAC[6] = {0x80, 0x09, 0x02, 0x03, 0x04, 0x05};

	oran_dl_path0_DST_MAC(BaseAddr, DL_DST_MAC);
	oran_dl_path0_SRC_MAC(BaseAddr, DL_SRC_MAC);
	oran_dl_path0_VLAN0_disable(BaseAddr);
	oran_dl_path0_VLAN1_disable(BaseAddr);

	oran_ul_path0_DST_MAC(BaseAddr, UL_DST_MAC);
	oran_ul_path0_SRC_MAC(BaseAddr, UL_SRC_MAC);
	oran_ul_path0_VLAN0_disable(BaseAddr);
	oran_ul_path0_VLAN1_disable(BaseAddr);

	oran_dl_path1_DST_MAC(BaseAddr, DL_DST_MAC);
	oran_dl_path1_SRC_MAC(BaseAddr, DL_SRC_MAC);
	oran_dl_path1_VLAN0_disable(BaseAddr);
	oran_dl_path1_VLAN1_disable(BaseAddr);

	oran_ul_path1_DST_MAC(BaseAddr, UL_DST_MAC);
	oran_ul_path1_SRC_MAC(BaseAddr, UL_SRC_MAC);
	oran_ul_path1_VLAN0_disable(BaseAddr);
	oran_ul_path1_VLAN1_disable(BaseAddr);

	// 1 2 3 4 5 6 7 8 for DLFE
	oran_dl_path0_ch0_id0(BaseAddr, 0x01);
	oran_dl_path0_ch1_id0(BaseAddr, 0x02);
	oran_dl_path0_ch2_id0(BaseAddr, 0x03);
	oran_dl_path0_ch3_id0(BaseAddr, 0x04);

	oran_dl_path1_ch0_id0(BaseAddr, 0x05);
	oran_dl_path1_ch1_id0(BaseAddr, 0x06);
	oran_dl_path1_ch2_id0(BaseAddr, 0x07);
	oran_dl_path1_ch3_id0(BaseAddr, 0x08);

	// 1 2 3 4 5 6 7 8 for ULFE
	// 41 42 43 44 45 46 47 48 for RAFE
	oran_dl_path0_ch0_id2(BaseAddr, 0x01);
	oran_dl_path0_ch1_id2(BaseAddr, 0x02);
	oran_dl_path0_ch2_id2(BaseAddr, 0x03);
	oran_dl_path0_ch3_id2(BaseAddr, 0x04);

	oran_dl_path1_ch0_id2(BaseAddr, 0x05);
	oran_dl_path1_ch1_id2(BaseAddr, 0x06);
	oran_dl_path1_ch2_id2(BaseAddr, 0x07);
	oran_dl_path1_ch3_id2(BaseAddr, 0x08);


	oran_dl_path0_ch0_id3(BaseAddr, 0x41);
	oran_dl_path0_ch1_id3(BaseAddr, 0x42);
	oran_dl_path0_ch2_id3(BaseAddr, 0x43);
	oran_dl_path0_ch3_id3(BaseAddr, 0x44);

	oran_dl_path1_ch0_id3(BaseAddr, 0x45);
	oran_dl_path1_ch1_id3(BaseAddr, 0x46);
	oran_dl_path1_ch2_id3(BaseAddr, 0x47);
	oran_dl_path1_ch3_id3(BaseAddr, 0x48);


	oran_dl_path0_compression_data_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran_dl_path0_sub_carrier_mode(BaseAddr,ORAN_SCS_15KHZ, ORAN_SCS_15KHZ);
	oran_dl_path0_fft_size(BaseAddr,ORAN_FFT_1024);
	oran_dl_path0_symbol_size(BaseAddr,ORAN_15KHZ_10MHZ_PRB);
	oran_dl_path0_exp_offset(BaseAddr, 0);

	oran_ul_path0_compression_data_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran_ul_path0_sub_carrier_mode(BaseAddr,ORAN_SCS_15KHZ, ORAN_SCS_15KHZ);
	oran_ul_path0_fft_size(BaseAddr,ORAN_FFT_1024);
	oran_ul_path0_symbol_size(BaseAddr,13, ORAN_15KHZ_10MHZ_PRB);
	oran_ul_path0_exp_offset(BaseAddr, 0);
	oran_ul_path0_gain_offset(BaseAddr, 0);
	oran_ul_path0_scale_offset(BaseAddr, 0);

	oran_dl_path1_compression_data_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran_dl_path1_sub_carrier_mode(BaseAddr,ORAN_SCS_15KHZ, ORAN_SCS_15KHZ);
	oran_dl_path1_fft_size(BaseAddr,ORAN_FFT_1024);
	oran_dl_path1_symbol_size(BaseAddr,ORAN_15KHZ_10MHZ_PRB);
	oran_dl_path1_exp_offset(BaseAddr, 0);

	oran_ul_path1_compression_data_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran_ul_path1_sub_carrier_mode(BaseAddr,ORAN_SCS_15KHZ, ORAN_SCS_15KHZ);
	oran_ul_path1_fft_size(BaseAddr,ORAN_FFT_1024);
	oran_ul_path1_symbol_size(BaseAddr,13, ORAN_15KHZ_10MHZ_PRB);
	oran_ul_path1_exp_offset(BaseAddr, 0);
	oran_ul_path1_gain_offset(BaseAddr, 0);
	oran_ul_path1_scale_offset(BaseAddr, 0);



}

void oran_25A_5g_3MHz_2cc_configure(u32 BaseAddr) {
	u8 DL_DST_MAC[6] = {0x80, 0x09, 0x02, 0x03, 0x04, 0x05};
	u8 DL_SRC_MAC[6] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	u8 UL_DST_MAC[6] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	u8 UL_SRC_MAC[6] = {0x80, 0x09, 0x02, 0x03, 0x04, 0x05};

	oran_dl_path0_DST_MAC(BaseAddr, DL_DST_MAC);
	oran_dl_path0_SRC_MAC(BaseAddr, DL_SRC_MAC);
	oran_dl_path0_VLAN0_disable(BaseAddr);
	oran_dl_path0_VLAN1_disable(BaseAddr);

	oran_ul_path0_DST_MAC(BaseAddr, UL_DST_MAC);
	oran_ul_path0_SRC_MAC(BaseAddr, UL_SRC_MAC);
	oran_ul_path0_VLAN0_disable(BaseAddr);
	oran_ul_path0_VLAN1_disable(BaseAddr);

	oran_dl_path1_DST_MAC(BaseAddr, DL_DST_MAC);
	oran_dl_path1_SRC_MAC(BaseAddr, DL_SRC_MAC);
	oran_dl_path1_VLAN0_disable(BaseAddr);
	oran_dl_path1_VLAN1_disable(BaseAddr);

	oran_ul_path1_DST_MAC(BaseAddr, UL_DST_MAC);
	oran_ul_path1_SRC_MAC(BaseAddr, UL_SRC_MAC);
	oran_ul_path1_VLAN0_disable(BaseAddr);
	oran_ul_path1_VLAN1_disable(BaseAddr);

	// 1 2 3 4 5 6 7 8 for DLFE
	oran_dl_path0_ch0_id0(BaseAddr, 0x01);
	oran_dl_path0_ch1_id0(BaseAddr, 0x02);
	oran_dl_path0_ch2_id0(BaseAddr, 0x03);
	oran_dl_path0_ch3_id0(BaseAddr, 0x04);

	oran_dl_path1_ch0_id0(BaseAddr, 0x05);
	oran_dl_path1_ch1_id0(BaseAddr, 0x06);
	oran_dl_path1_ch2_id0(BaseAddr, 0x07);
	oran_dl_path1_ch3_id0(BaseAddr, 0x08);

	// 1 2 3 4 5 6 7 8 for ULFE
	// 41 42 43 44 45 46 47 48 for RAFE
	oran_dl_path0_ch0_id2(BaseAddr, 0x01);
	oran_dl_path0_ch1_id2(BaseAddr, 0x02);
	oran_dl_path0_ch2_id2(BaseAddr, 0x03);
	oran_dl_path0_ch3_id2(BaseAddr, 0x04);

	oran_dl_path1_ch0_id2(BaseAddr, 0x05);
	oran_dl_path1_ch1_id2(BaseAddr, 0x06);
	oran_dl_path1_ch2_id2(BaseAddr, 0x07);
	oran_dl_path1_ch3_id2(BaseAddr, 0x08);


	oran_dl_path0_ch0_id3(BaseAddr, 0x41);
	oran_dl_path0_ch1_id3(BaseAddr, 0x42);
	oran_dl_path0_ch2_id3(BaseAddr, 0x43);
	oran_dl_path0_ch3_id3(BaseAddr, 0x44);

	oran_dl_path1_ch0_id3(BaseAddr, 0x45);
	oran_dl_path1_ch1_id3(BaseAddr, 0x46);
	oran_dl_path1_ch2_id3(BaseAddr, 0x47);
	oran_dl_path1_ch3_id3(BaseAddr, 0x48);


	oran_dl_path0_compression_data_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran_dl_path0_sub_carrier_mode(BaseAddr,ORAN_SCS_15KHZ, ORAN_SCS_15KHZ);
	oran_dl_path0_fft_size(BaseAddr,ORAN_FFT_512);
	oran_dl_path0_symbol_size(BaseAddr,ORAN_15KHZ_3MHZ_PRB);
	oran_dl_path0_exp_offset(BaseAddr, 0);

	oran_ul_path0_compression_data_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran_ul_path0_sub_carrier_mode(BaseAddr,ORAN_SCS_15KHZ, ORAN_SCS_15KHZ);
	oran_ul_path0_fft_size(BaseAddr,ORAN_FFT_512);
	oran_ul_path0_symbol_size(BaseAddr,13, ORAN_15KHZ_3MHZ_PRB);
	oran_ul_path0_exp_offset(BaseAddr, 0);
	oran_ul_path0_gain_offset(BaseAddr, 0);
	oran_ul_path0_scale_offset(BaseAddr, 0);

	oran_dl_path1_compression_data_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran_dl_path1_sub_carrier_mode(BaseAddr,ORAN_SCS_15KHZ, ORAN_SCS_15KHZ);
	oran_dl_path1_fft_size(BaseAddr,ORAN_FFT_512);
	oran_dl_path1_symbol_size(BaseAddr,ORAN_15KHZ_3MHZ_PRB);
	oran_dl_path1_exp_offset(BaseAddr, 0);

	oran_ul_path1_compression_data_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran_ul_path1_sub_carrier_mode(BaseAddr,ORAN_SCS_15KHZ, ORAN_SCS_15KHZ);
	oran_ul_path1_fft_size(BaseAddr,ORAN_FFT_512);
	oran_ul_path1_symbol_size(BaseAddr,13, ORAN_15KHZ_3MHZ_PRB);
	oran_ul_path1_exp_offset(BaseAddr, 0);
	oran_ul_path1_gain_offset(BaseAddr, 0);
	oran_ul_path1_scale_offset(BaseAddr, 0);



}
