#ifndef BBCTRL_SIMPLE_DRVS_H
#define BBCTRL_SIMPLE_DRVS_H

#include "fpga_register_config.h"

#define BBCTRL_BW_SEL0_OFFSET                    0x0400u
#define BBCTRL_MAPPER0_SPEED_OFFSET				 0x0600u
#define BBCTRL_MAPPER1_SPEED_OFFSET				 0x0604u


#define BBCTRL_AIR_TECH_OFFSET                   0x0500u
#define BBCTRL_SCALE_FACTOR0_OFFSET              0x0580u
#define BBCTRL_DL_AXC_ON0_OFFSET                 0x0C00u
#define BBCTRL_UP_AXC_ON0_OFFSET                 0x0C40u

#define BBCTRL_DL_ATT_AXC0_OFFSET                0x1400u
#define BBCTRL_DL_ATT_AXC1_OFFSET                0x1404u
#define BBCTRL_DL_ATT_AXC2_OFFSET                0x1408u
#define BBCTRL_DL_ATT_AXC3_OFFSET                0x140Cu
#define BBCTRL_DL_ATT_AXC4_OFFSET                0x1410u
#define BBCTRL_DL_ATT_AXC5_OFFSET                0x1414u
#define BBCTRL_DL_ATT_AXC6_OFFSET                0x1418u
#define BBCTRL_DL_ATT_AXC7_OFFSET                0x141Cu

#define BBCTRL_UL_ATTEN_AXC0_OFFSET				 0x1600u
#define BBCTRL_UL_ATTEN_AXC1_OFFSET				 0x1604u
#define BBCTRL_UL_ATTEN_AXC2_OFFSET				 0x1608u
#define BBCTRL_UL_ATTEN_AXC3_OFFSET				 0x160Cu
#define BBCTRL_UL_ATTEN_AXC4_OFFSET				 0x1610u
#define BBCTRL_UL_ATTEN_AXC5_OFFSET				 0x1614u
#define BBCTRL_UL_ATTEN_AXC6_OFFSET				 0x1618u
#define BBCTRL_UL_ATTEN_AXC7_OFFSET				 0x161Cu

#define BBCTRL_MAPPER_CONFIG_BUF_SEL_OFFSET      0x2000u
#define BBCTRL_MAPPER_CONFIG_BUF_ADDR_OFFSET     0x2004u
#define BBCTRL_MAPPER_CONFIG_BUF_DATA_OFFSET     0x2008u
#define BBCTRL_MAPPER_CONFIG_BUF_WREN_OFFSET     0x200Cu


#define BBCTRL_MAPPER_CONFIG_CPRI_SEL0_OFFSET    0x2200u
#define BBCTRL_MAPPER_CONFIG_CPRI_SEL1_OFFSET    0x2204u
#define BBCTRL_MAPPER_CONFIG_CPRI_SEL2_OFFSET    0x2208u
#define BBCTRL_MAPPER_CONFIG_CPRI_SEL3_OFFSET    0x220Cu
#define BBCTRL_MAPPER_CONFIG_CPRI_SEL4_OFFSET    0x2210u
#define BBCTRL_MAPPER_CONFIG_CPRI_SEL5_OFFSET    0x2214u
#define BBCTRL_MAPPER_CONFIG_CPRI_SEL6_OFFSET    0x2218u
#define BBCTRL_MAPPER_CONFIG_CPRI_SEL7_OFFSET    0x221Cu


#define BBCTRL_MAPPER0_UL_MAP_OFFSET             0x2400u
#define BBCTRL_MAPPER1_UL_MAP_OFFSET             0x2404u
#define BBCTRL_MAPPER2_UL_MAP_OFFSET             0x2408u
#define BBCTRL_MAPPER3_UL_MAP_OFFSET             0x240Cu
#define BBCTRL_MAPPER4_UL_MAP_OFFSET             0x2410u
#define BBCTRL_MAPPER5_UL_MAP_OFFSET             0x2414u
#define BBCTRL_MAPPER6_UL_MAP_OFFSET             0x2418u
#define BBCTRL_MAPPER7_UL_MAP_OFFSET             0x241Cu

#define BBCTRL_FORMATTER0_DL_MAP_OFFSET          0x2600u
#define BBCTRL_FORMATTER1_DL_MAP_OFFSET          0x2604u
#define BBCTRL_FORMATTER2_DL_MAP_OFFSET          0x2608u
#define BBCTRL_FORMATTER3_DL_MAP_OFFSET          0x260Cu
#define BBCTRL_FORMATTER4_DL_MAP_OFFSET          0x2610u
#define BBCTRL_FORMATTER5_DL_MAP_OFFSET          0x2614u
#define BBCTRL_FORMATTER6_DL_MAP_OFFSET          0x2618u
#define BBCTRL_FORMATTER7_DL_MAP_OFFSET          0x261Cu


// BBCTRL_BW_SEL0_OFFSET
#define BBCTRL_BADWIDTH_1P4M            0x0u
#define BBCTRL_BADWIDTH_3M              0x1u
#define BBCTRL_BADWIDTH_5M              0x2u
#define BBCTRL_BADWIDTH_10M             0x3u
#define BBCTRL_BADWIDTH_15M             0x4u
#define BBCTRL_BADWIDTH_20M             0x5u
#define BBCTRL_BADWIDTH_10M_NR          0xBu

#define BBCTRL_FORMATTER_0_BANDWIDTH    BBCTRL_BADWIDTH_10M
#define BBCTRL_FORMATTER_1_BANDWIDTH    BBCTRL_BADWIDTH_10M
#define BBCTRL_FORMATTER_2_BANDWIDTH    BBCTRL_BADWIDTH_10M
#define BBCTRL_FORMATTER_3_BANDWIDTH    BBCTRL_BADWIDTH_10M
#define BBCTRL_FORMATTER_4_BANDWIDTH    BBCTRL_BADWIDTH_10M
#define BBCTRL_FORMATTER_5_BANDWIDTH    BBCTRL_BADWIDTH_10M
#define BBCTRL_FORMATTER_6_BANDWIDTH    BBCTRL_BADWIDTH_10M
#define BBCTRL_FORMATTER_7_BANDWIDTH    BBCTRL_BADWIDTH_10M

#define BBCTRL_FORMATTER_BANDWIDTH      (BBCTRL_FORMATTER_0_BANDWIDTH <<  0)| \
                                        (BBCTRL_FORMATTER_1_BANDWIDTH <<  4)| \
                                        (BBCTRL_FORMATTER_2_BANDWIDTH <<  8)| \
                                        (BBCTRL_FORMATTER_3_BANDWIDTH << 12)| \
                                        (BBCTRL_FORMATTER_4_BANDWIDTH << 16)| \
                                        (BBCTRL_FORMATTER_5_BANDWIDTH << 20)| \
                                        (BBCTRL_FORMATTER_6_BANDWIDTH << 24)| \
                                        (BBCTRL_FORMATTER_7_BANDWIDTH << 28)

#define BBCTRL_MAPPER_DL_ACTIVE_WRITE       0x1
#define BBCTRL_MAPPER_UL_ACTIVE_WRITE       0x2
#define BBCTRL_MAPPER_DL_INACTIVE_WRITE     0x0
#define BBCTRL_MAPPER_UL_INACTIVE_WRITE     0x0

#define bbctrl_mapper_downlink_config(core_baseaddr, map_address, map_data) \
	fpga_write_register(core_baseaddr, BBCTRL_MAPPER_CONFIG_BUF_ADDR_OFFSET, map_address); \
	fpga_write_register(core_baseaddr, BBCTRL_MAPPER_CONFIG_BUF_DATA_OFFSET, map_data); \
	fpga_write_register(core_baseaddr, BBCTRL_MAPPER_CONFIG_BUF_WREN_OFFSET, BBCTRL_MAPPER_DL_ACTIVE_WRITE); \
	fpga_write_register(core_baseaddr, BBCTRL_MAPPER_CONFIG_BUF_WREN_OFFSET, BBCTRL_MAPPER_DL_INACTIVE_WRITE)

#define bbctrl_mapper_uplink_config(core_baseaddr, map_address, map_data) \
	fpga_write_register(core_baseaddr, BBCTRL_MAPPER_CONFIG_BUF_ADDR_OFFSET, map_address); \
	fpga_write_register(core_baseaddr, BBCTRL_MAPPER_CONFIG_BUF_DATA_OFFSET, map_data); \
	fpga_write_register(core_baseaddr, BBCTRL_MAPPER_CONFIG_BUF_WREN_OFFSET, BBCTRL_MAPPER_UL_ACTIVE_WRITE); \
	fpga_write_register(core_baseaddr, BBCTRL_MAPPER_CONFIG_BUF_WREN_OFFSET, BBCTRL_MAPPER_UL_INACTIVE_WRITE)

void bbctrl_3MHz(u32 core_baseaddr);

#endif
