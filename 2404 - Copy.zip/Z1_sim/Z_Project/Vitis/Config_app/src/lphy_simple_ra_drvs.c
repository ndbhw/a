#include "lphy_simple_ra_drvs.h"

void lphy_simple_ra_LTE_20MHz(uint32_t BaseAddr) {
	lphy_simple_ra_IQ_swap_mode(BaseAddr, LPHY_RA_IQ_SWAP_OFF);
	lphy_simple_ra_input_TestPattern_gen(BaseAddr, LPHY_RA_INPUT_PATTERN_OFF);
	lphy_simple_ra_output_TestPattern_gen(BaseAddr, LPHY_RA_OUTPUT_PATTERN_OFF);
	lphy_simple_ra_FreqShift_mode(BaseAddr, LPHY_RA_FREQ_SHIFT_OFF);
	lphy_simple_ra_FreqShift(BaseAddr, 0);
	lphy_simple_ra_rach_k_bar(BaseAddr, 0);
	lphy_simple_ra_debug_mode(BaseAddr, LPHY_RA_DEBUG_NONE);
	lphy_simple_ra_debug_subfrm(BaseAddr, 3); //1
	lphy_simple_ra_debug_filter_index(BaseAddr, 1);
	lphy_simple_ra_debug_time_offset(BaseAddr, 0);
	lphy_simple_ra_debug_frame_struct(BaseAddr, 0xAC);
	lphy_simple_ra_debug_CP_Length(BaseAddr, 0x80);
	lphy_simple_ra_debug_PSym(BaseAddr, 1);
	lphy_simple_ra_debug_FreqOffset(BaseAddr, 0xFFFFFF70);
	lphy_simple_ra_debug_NumRO(BaseAddr, 1);
	lphy_simple_ra_debug_PRBC(BaseAddr, 70);
	lphy_simple_ra_SCS_idx(BaseAddr, LPHY_RA_SCS_15KHZ);
	lphy_simple_ra_FFT_idx(BaseAddr, LPHY_RA_FFT_2048);
	lphy_simple_ra_type(BaseAddr,LPHY_RA_LTE_PRACH);
	lphy_simple_ra_freqShift7p5k(BaseAddr, LPHY_RA_FREQ_7P5K_SHIFT_OFF);
	lphy_simple_ra_SlotOffset(BaseAddr, 3);//1
	lphy_simple_ra_tagc_backoff(BaseAddr, 0);
	lphy_simple_ra_tagc_mode(BaseAddr, LPHY_RA_TAGC_OFF);

	lphy_simple_ra_ta_advance(BaseAddr, 150);
}


void lphy_simple_ra_LTE_10MHz(uint32_t BaseAddr) {
	lphy_simple_ra_IQ_swap_mode(BaseAddr, LPHY_RA_IQ_SWAP_OFF);
	lphy_simple_ra_input_TestPattern_gen(BaseAddr, LPHY_RA_INPUT_PATTERN_OFF);
	lphy_simple_ra_output_TestPattern_gen(BaseAddr, LPHY_RA_OUTPUT_PATTERN_OFF);
	lphy_simple_ra_FreqShift_mode(BaseAddr, LPHY_RA_FREQ_SHIFT_OFF);
	lphy_simple_ra_FreqShift(BaseAddr, 0);
	lphy_simple_ra_rach_k_bar(BaseAddr, 0);
	lphy_simple_ra_debug_mode(BaseAddr, LPHY_RA_DEBUG_NONE);
	lphy_simple_ra_debug_subfrm(BaseAddr, 3);
	lphy_simple_ra_debug_filter_index(BaseAddr, 1);
	lphy_simple_ra_debug_time_offset(BaseAddr, 0);
	lphy_simple_ra_debug_frame_struct(BaseAddr, 0xAC);
	lphy_simple_ra_debug_CP_Length(BaseAddr, 0x80);
	lphy_simple_ra_debug_PSym(BaseAddr, 1);
	lphy_simple_ra_debug_FreqOffset(BaseAddr, 0xFFFFFF70);
	lphy_simple_ra_debug_NumRO(BaseAddr, 1);
	lphy_simple_ra_debug_PRBC(BaseAddr, 70);
	lphy_simple_ra_SCS_idx(BaseAddr, LPHY_RA_SCS_15KHZ);
	lphy_simple_ra_FFT_idx(BaseAddr, LPHY_RA_FFT_1024);
	lphy_simple_ra_type(BaseAddr,LPHY_RA_LTE_PRACH);
	lphy_simple_ra_freqShift7p5k(BaseAddr, LPHY_RA_FREQ_7P5K_SHIFT_OFF);
	lphy_simple_ra_SlotOffset(BaseAddr, 3);
	lphy_simple_ra_tagc_backoff(BaseAddr, 0);
	lphy_simple_ra_tagc_mode(BaseAddr, LPHY_RA_TAGC_OFF);
	lphy_simple_ra_ta_advance(BaseAddr, 150);

	lphy_simple_ra_enable(BaseAddr);
}

void lphy_simple_ra_LTE_3MHz(uint32_t BaseAddr) {
	lphy_simple_ra_IQ_swap_mode(BaseAddr, LPHY_RA_IQ_SWAP_OFF);
	lphy_simple_ra_input_TestPattern_gen(BaseAddr, LPHY_RA_INPUT_PATTERN_OFF);
	lphy_simple_ra_output_TestPattern_gen(BaseAddr, LPHY_RA_OUTPUT_PATTERN_OFF);
	lphy_simple_ra_FreqShift_mode(BaseAddr, LPHY_RA_FREQ_SHIFT_OFF);
	lphy_simple_ra_FreqShift(BaseAddr, 0);
	lphy_simple_ra_rach_k_bar(BaseAddr, 0);
	lphy_simple_ra_debug_mode(BaseAddr, LPHY_RA_DEBUG_NONE);
	lphy_simple_ra_debug_subfrm(BaseAddr, 3);
	lphy_simple_ra_debug_filter_index(BaseAddr, 1);
	lphy_simple_ra_debug_time_offset(BaseAddr, 0);
	lphy_simple_ra_debug_frame_struct(BaseAddr, 0xAC);
	lphy_simple_ra_debug_CP_Length(BaseAddr, 0x80);
	lphy_simple_ra_debug_PSym(BaseAddr, 1);
	lphy_simple_ra_debug_FreqOffset(BaseAddr, 0xFFFFFF70);
	lphy_simple_ra_debug_NumRO(BaseAddr, 1);
	lphy_simple_ra_debug_PRBC(BaseAddr, 70);
	lphy_simple_ra_SCS_idx(BaseAddr, LPHY_RA_SCS_15KHZ);
	lphy_simple_ra_FFT_idx(BaseAddr, LPHY_RA_FFT_512);
	lphy_simple_ra_type(BaseAddr,LPHY_RA_LTE_PRACH);
	lphy_simple_ra_freqShift7p5k(BaseAddr, LPHY_RA_FREQ_7P5K_SHIFT_OFF);
	lphy_simple_ra_SlotOffset(BaseAddr, 3);
	lphy_simple_ra_tagc_backoff(BaseAddr, 0);
	lphy_simple_ra_tagc_mode(BaseAddr, LPHY_RA_TAGC_OFF);
	lphy_simple_ra_ta_advance(BaseAddr, 150);

	lphy_simple_ra_enable(BaseAddr);
}

