#include "lphy_simple_nbiot_drvs.h"

void lphy_simple_nb_config(uint32_t BaseAddr) {
//	lphy_simple_nb_scs_idx(BaseAddr, initialValue);
//	lphy_simple_nb_time_offset(BaseAddr, initialValue);
//	lphy_simple_nb_n_samp(BaseAddr, initialValue);
//	lphy_simple_nb_freg_shift(BaseAddr, initialValue);
//	lphy_simple_nb_init_reg(BaseAddr, initialValue);
//	lphy_simple_nb_n_fft(BaseAddr, initialValue);
//	lphy_simple_nb_num_psym(BaseAddr, initialValue);
//	lphy_simple_nb_num_re(BaseAddr, initialValue);
//	lphy_simple_nb_config_en(BaseAddr, initialValue);
//	lphy_simple_nb_timing_info(BaseAddr, initialValue);
//	lphy_simple_nb_real_timing_info(BaseAddr, initialValue);
//	lphy_simple_nb_freg_offset_reg(BaseAddr, initialValue);
//	lphy_simple_nb_sel_in_path(BaseAddr, initialValue);
	lphy_simple_nb_adv_offset(BaseAddr, 0);
	lphy_simple_nb_cp_delay(BaseAddr, 500);
//	lphy_simple_nb_cp_delay2(BaseAddr, 0);
//	lphy_simple_nb_fsync_dly_val(BaseAddr, 0);
	lphy_simple_nbiot_FSYNC_DLY(BaseAddr, 3);
}
