#ifndef LPHY_SIMPLE_UL_DRVS_H_
#define LPHY_SIMPLE_UL_DRVS_H_

#include "fpga_register_config.h"

#define LPHY_UL_FREQ_SHIFT_MODE_OFFSET			0x0200u
#define LPHY_UL_CP_TYPE_OFFSET					0x0204u
#define LPHY_UL_CP_REMOVE_OFFSET				0x0208u
#define LPHY_UL_TAGC_MODE_OFFSET				0x020Cu
#define LPHY_UL_TAGC_BACKOFF_OFFSET				0x0210u
#define LPHY_UL_K0_OFFSET						0x0214u
#define LPHY_UL_RB_SIZE_OFFSET					0x0218u
#define LPHY_UL_GAIN_COMP_ON_OFFSET				0x021Cu
#define LPHY_UL_CTS_ON_OFFSET					0x0220u
#define LPHY_UL_CTS_SHIFT_OFFSET				0x0224u
#define LPHY_UL_PHASE_COMP_ON_OFFSET			0x0228u
#define LPHY_UL_FFT_SCS_TYPE_OFFSET				0x022Cu

#define LPHY_UL_NUM_MDM_PATH_OFFSET				0x0800u
#define LPHY_UL_NUM_ANT_OFFSET					0x0804u

#define LPHY_UL_FREQ_NONE_CARRIER_SHIFT				0
#define LPHY_UL_FREQ_HALF_CARRIER_SHIFT				1
#define lphy_simple_ul_freq_shift_mode(BaseAddr, FreqShiftMode) \
	fpga_write32_register(BaseAddr,LPHY_UL_FREQ_SHIFT_MODE_OFFSET,FreqShiftMode)

#define LPHY_UL_CP_NORMAL							0
#define LPHY_UL_CP_EXTEND							1
#define lphy_simple_ul_cp_type(BaseAddr, CP_Type) \
	fpga_write32_register(BaseAddr,LPHY_UL_CP_TYPE_OFFSET,CP_Type)

#define LPHY_UL_TAGC_OFF						0
#define LPHY_UL_TAGC_ON							1
#define lphy_simple_ul_tagc_mode(BaseAddr, TagcMode) \
	fpga_write32_register(BaseAddr,LPHY_UL_TAGC_MODE_OFFSET,TagcMode)

#define lphy_simple_ul_tagc_BackOff(BaseAddr, TagcBackOff) \
	fpga_write32_register(BaseAddr,LPHY_UL_TAGC_BACKOFF_OFFSET,TagcBackOff)

#define lphy_simple_ul_cp_remove(BaseAddr, RemoveSize) \
	fpga_write32_register(BaseAddr,LPHY_UL_CP_REMOVE_OFFSET,RemoveSize)

#define lphy_simple_ul_k0_size(BaseAddr, K0_Size) \
	fpga_write32_register(BaseAddr,LPHY_UL_K0_OFFSET,K0_Size)

#define LPHY_UL_LTE_1P4MHZ_RB						6
#define LPHY_UL_LTE_3MHZ_RB							15
#define LPHY_UL_LTE_5MHZ_RB							25
#define LPHY_UL_LTE_10MHZ_RB						50
#define LPHY_UL_LTE_20MHZ_RB						100
#define LPHY_UL_NR_100MHZ_RB						3276
#define lphy_simple_ul_RB_size(BaseAddr, RB_Size) \
	fpga_write32_register(BaseAddr,LPHY_UL_RB_SIZE_OFFSET,RB_Size)

#define LPHY_UL_GAIN_COMPENSATION_OFF				0
#define LPHY_UL_GAIN_COMPENSATION_ON				1
#define lphy_simple_ul_gain_comp_mode(BaseAddr, GainCompMode) \
	fpga_write32_register(BaseAddr,LPHY_UL_GAIN_COMP_ON_OFFSET,GainCompMode)

#define LPHY_UL_CTS_SHIFT_OFF						0
#define LPHY_UL_CTS_SHIFT_ON						1
#define lphy_simple_ul_CTS_mode(BaseAddr, CTS_Mode) \
	fpga_write32_register(BaseAddr,LPHY_UL_CTS_ON_OFFSET,CTS_Mode)

#define lphy_simple_ul_CTS_Shift_Offset(BaseAddr, CTS_Offset) \
	fpga_write32_register(BaseAddr,LPHY_UL_CTS_SHIFT_OFFSET,CTS_Offset)

#define LPHY_UL_PHASE_COMPENSATION_OFF				0
#define LPHY_UL_PHASE_COMPENSATION_ON				1
#define lphy_simple_ul_Phase_Compensation_mode(BaseAddr, PhaseCompMode) \
	fpga_write32_register(BaseAddr,LPHY_UL_PHASE_COMP_ON_OFFSET,PhaseCompMode)

#define LPHY_UL_SCS_15KHZ							0
#define LPHY_UL_SCS_30KHZ							1
#define LPHY_UL_FFT_512								0
#define LPHY_UL_FFT_1024							1
#define LPHY_UL_FFT_2048							2
#define LPHY_UL_FFT_4096							3
#define lphy_simple_ul_FFT_SCS_Type(BaseAddr, SCS_Type, FFT_Type) \
	fpga_write32_register(BaseAddr,LPHY_UL_FFT_SCS_TYPE_OFFSET,((FFT_Type << 4) | SCS_Type))

#define lphy_simple_ul_MDM_Num(BaseAddr, MDM_Num) \
	fpga_write32_register(BaseAddr,LPHY_UL_NUM_MDM_PATH_OFFSET,MDM_Num)

#define lphy_simple_ul_Anten_Num(BaseAddr, Anten_Num) \
	fpga_write32_register(BaseAddr,LPHY_UL_NUM_ANT_OFFSET,Anten_Num)

void lphy_simple_ul_config_LTE_20MHz(uint32_t BaseAddr);
//void lphy_simple_ul_config_LTE_10MHz(uint32_t BaseAddr);
void lphy_simple_ul_config_LTE_3MHz(uint32_t BaseAddr);


#endif
