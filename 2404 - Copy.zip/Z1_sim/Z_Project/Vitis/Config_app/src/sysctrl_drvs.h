#ifndef SYSCTRL_DRVS_H
#define SYSCTRL_DRVS_H

#include <xil_io.h>

#define SYSCTRL_RST_INTER_PLL_OFFSET			0x0440u
#define SYSCTRL_RST_SERDES_OFFSET				0x0480u
#define SYSCTRL_RST_CPRI_OFFSET					0x04C0u
#define SYSCTRL_RST_IQCOMP_OFFSET				0x04C4u
#define SYSCTRL_RST_ETHMUX_OFFSET				0x04C8u
#define SYSCTRL_RST_BBCTRL_OFFSET				0x0500u
#define SYSCTRL_RST_DSP_OFFSET					0x0540u
#define SYSCTRL_RST_DDUC_OFFSET					0x0544u
#define SYSCTRL_RST_CFR_OFFSET					0x0548u
#define SYSCTRL_RST_DPD_OFFSET					0x054Cu
#define SYSCTRL_RST_DPDCPU_OFFSET				0x0560u
#define SYSCTRL_RST_DCIF_OFFSET					0x0580u
#define SYSCTRL_RST_MISC_OFFSET					0x05C0u
#define SYSCTRL_RST_ECPRIPHY_OFFSET				0x0600u
#define SYSCTRL_RST_ORAN_FRAMER_OFFSET			0x0640u
#define SYSCTRL_RST_ORAN_DEFRAMER_OFFSET		0x0644u
#define SYSCTRL_RST_ORAN_SWITCH_OFFSET			0x0660u
#define SYSCTRL_RST_BBTOP_OFFSET				0x0680u
#define SYSCTRL_RST_DLFE_OFFSET					0x0684u
#define SYSCTRL_RST_ULFE_OFFSET					0x0688u
#define SYSCTRL_RST_RAFE_OFFSET					0x068Cu
#define SYSCTRL_RST_AURORA_OFFSET				0x06C0u
#define SYSCTRL_RST_SBIF_OFFSET					0x0700u
#define SYSCTRL_RST_SBIFPHY_OFFSET				0x0704u
#define SYSCTRL_RST_PIM_OFFSET					0x0740u
#define SYSCTRL_RST_PIM_SBIF_OFFSET				0x0744u
#define SYSCTRL_RST_PIM_SBIFPHY_OFFSET			0x0748u


#define SYSCTRL_RST_ORAN_L0_DEFRAMER_OFFSET		0x07C0u
#define SYSCTRL_RST_ORAN_L0_FRAMER_OFFSET		0x07C4u
#define SYSCTRL_RST_ORAN_L1_DEFRAMER_OFFSET		0x07C8u
#define SYSCTRL_RST_ORAN_L1_FRAMER_OFFSET		0x07CCu

#define SYSCTRL_DL_CC0_SYNC_ADVANCE_OFFSET		0x2600u
#define SYSCTRL_DL_CC1_SYNC_ADVANCE_OFFSET		0x2604u
#define SYSCTRL_UL_CC0_SYNC_RETARD_OFFSET		0x2640u
#define SYSCTRL_UL_CC1_SYNC_RETARD_OFFSET		0x2644u
#define SYSCTRL_N_TA_OFFSET_CC0_OFFSET			0x2700u
#define SYSCTRL_N_TA_OFFSET_CC1_OFFSET			0x2704u


#define sysctrl_reset_inter_pll(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_INTER_PLL_OFFSET, 0xFFu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_INTER_PLL_OFFSET, 0x00u)

#define sysctrl_reset_serdes(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_SERDES_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_SERDES_OFFSET, 0x00u)

#define sysctrl_reset_cpri(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_CPRI_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_CPRI_OFFSET, 0x00u)

#define sysctrl_reset_iqcomp(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_IQCOMP_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_IQCOMP_OFFSET, 0x00u)

#define sysctrl_reset_ethmux(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_ETHMUX_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_ETHMUX_OFFSET, 0x00u)

#define sysctrl_reset_bbctrl(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_BBCTRL_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_BBCTRL_OFFSET, 0x00u)

#define sysctrl_reset_dsp_top(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_DSP_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_DSP_OFFSET, 0x00u)

#define sysctrl_reset_dduc(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_DDUC_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_DDUC_OFFSET, 0x00u)

#define sysctrl_reset_cfr(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_CFR_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_CFR_OFFSET, 0x00u)

#define sysctrl_reset_dpd(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_DPD_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_DPD_OFFSET, 0x00u)

#define sysctrl_reset_dpdcpu(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_DPDCPU_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_DPDCPU_OFFSET, 0x00u)

#define sysctrl_reset_dcif(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_DCIF_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_DCIF_OFFSET, 0x00u)

#define sysctrl_reset_misc(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_MISC_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_MISC_OFFSET, 0x00u)

#define sysctrl_reset_ecpri(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_ECPRIPHY_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_ECPRIPHY_OFFSET, 0x00u)

#define sysctrl_reset_oran_framer(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_ORAN_FRAMER_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_ORAN_FRAMER_OFFSET, 0x00u)

#define sysctrl_reset_oran_deframer(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_ORAN_DEFRAMER_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_ORAN_DEFRAMER_OFFSET, 0x00u)

#define sysctrl_reset_oran_switch(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_ORAN_SWITCH_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_ORAN_SWITCH_OFFSET, 0x00u)

#define sysctrl_reset_bbtop(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_BBTOP_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_BBTOP_OFFSET, 0x00u)

#define sysctrl_reset_dlfe(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_DLFE_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_DLFE_OFFSET, 0x00u)

#define sysctrl_reset_ulfe(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_ULFE_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_ULFE_OFFSET, 0x00u)

#define sysctrl_reset_rafe(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_RAFE_OFFSET, 0x0Fu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_RAFE_OFFSET, 0x00u)

#define sysctrl_reset_aurora(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_AURORA_OFFSET, 0xFFu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_AURORA_OFFSET, 0x00u)

#define sysctrl_reset_sbif(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_SBIF_OFFSET, 0xFFu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_SBIF_OFFSET, 0x00u)

#define sysctrl_reset_sbifphy(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_SBIFPHY_OFFSET, 0xFFu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_SBIFPHY_OFFSET, 0x00u)

#define sysctrl_reset_pim(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_PIM_OFFSET, 0xFFu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_PIM_OFFSET, 0x00u)

#define sysctrl_reset_pim_sbif(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_PIM_SBIF_OFFSET, 0xFFu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_PIM_SBIF_OFFSET, 0x00u)

#define sysctrl_reset_pim_sbifphy(BaseAddr) \
	Xil_Out32(BaseAddr+SYSCTRL_RST_PIM_SBIFPHY_OFFSET, 0xFFu); \
	Xil_Out32(BaseAddr+SYSCTRL_RST_PIM_SBIFPHY_OFFSET, 0x00u)

#define sysctrl_set_dl_cc0_advance(BaseAddr, dl_advance) \
	Xil_Out32(BaseAddr+SYSCTRL_DL_CC0_SYNC_ADVANCE_OFFSET, dl_advance)

#define sysctrl_set_dl_cc1_advance(BaseAddr, dl_advance) \
	Xil_Out32(BaseAddr+SYSCTRL_DL_CC1_SYNC_ADVANCE_OFFSET, dl_advance)


#define sysctrl_set_ul_cc0_retard(BaseAddr, ul_retard) \
	Xil_Out32(BaseAddr+SYSCTRL_UL_CC0_SYNC_RETARD_OFFSET, ul_retard)

#define sysctrl_set_ul_cc1_retard(BaseAddr, ul_retard) \
	Xil_Out32(BaseAddr+SYSCTRL_UL_CC0_SYNC_RETARD_OFFSET, ul_retard)


#define sysctrl_set_n_ta_offset_cc0(BaseAddr, n_ta_offset) \
	Xil_Out32(BaseAddr+SYSCTRL_N_TA_OFFSET_CC0_OFFSET, n_ta_offset)

#define sysctrl_set_n_ta_offset_cc1(BaseAddr, n_ta_offset) \
	Xil_Out32(BaseAddr+SYSCTRL_N_TA_OFFSET_CC1_OFFSET, n_ta_offset)


void sysctrl_preset(u32 BaseAddr);
void sysctrl_reset(u32 BaseAddr);

#endif
