#include "lphy_simple_dl_drvs.h"

void lphy_simple_dl_config_LTE_20MHz(uint32_t BaseAddr) {

	lphy_simple_dl_IQ_Swap(BaseAddr,LPHY_DL_IQ_SWAP_OFF);
	lphy_simple_dl_FrameSource(BaseAddr, LPHY_DL_FRAME_SOURCE_MPLANE);
	lphy_simple_dl_CDD_CPBuffer(BaseAddr, 19167); // relate with delay of output from frame sync of GPS. B_HDL/4_BB_TOP/lib/ref_vsync_gen.v
	lphy_simple_dl_DebugMode(BaseAddr, LPHY_DL_DEBUG_MODE_OFF);
	lphy_simple_dl_DebugRemask(BaseAddr, LPHY_DL_DEBUG_REMASK_OFF);
	lphy_simple_dl_Debug_FrameStruct(BaseAddr, LPHY_DL_FFT_2048, LPHY_DL_SCS_15KHZ);
	lphy_simple_dl_Debug_NLayer(BaseAddr, 4);
	lphy_simple_dl_Debug_MonSMP(BaseAddr, 0, 0, 0, 0);


	lphy_simple_dl_LTE_SysMode(BaseAddr, 4, 4);
	lphy_simple_dl_K0(BaseAddr, 0);
	lphy_simple_dl_FreqShiftA(BaseAddr, 0);
	lphy_simple_dl_NumRE(BaseAddr, LPHY_DL_LTE_20MHZ_RE);
	lphy_simple_dl_FFT_Size(BaseAddr, LPHY_DL_FFT_2048);
	lphy_simple_dl_cp_type(BaseAddr, LPHY_DL_CP_NORMAL);
	lphy_simple_dl_ScaleAntGain(BaseAddr, 4);
	lphy_simple_dl_AntGain(BaseAddr, 16); //256
	lphy_simple_dl_SCS_Type(BaseAddr, LPHY_DL_SCS_15KHZ);

	lphy_simple_dl_AntBitMap(BaseAddr, LPHY_DL_4_ANT_ENABLE);
	lphy_simple_dl_DownShift(BaseAddr, 0);
	lphy_simple_dl_CDD_Value0(BaseAddr, 0);
	lphy_simple_dl_CDD_Value1(BaseAddr, 0);
	lphy_simple_dl_CDD_Value2(BaseAddr, 0);
	lphy_simple_dl_CDD_Value3(BaseAddr, 0);

	lphy_simple_dl_sigsus_cnt_reset(BaseAddr, RESET_ON);
	lphy_simple_dl_sigsus_cnt_reset(BaseAddr, RESET_OFF);

	//	lphy_simple_dl_sigsus_enable_type(BaseAddr, SIGSUS_ENA_COMMON_THRES);
	lphy_simple_dl_sigsus_common_thres(BaseAddr, 0xffffffff);

//	lphy_simple_dl_sigsus_enable_type(BaseAddr, SIGSUS_ENA_THRES_PER_SYM);
//	lphy_simple_dl_sigsus_enable_type(BaseAddr, SIGSUS_ENA_COMMON_THRES);
	lphy_simple_dl_sigsus_enable_type(BaseAddr, SIGSUS_DISABLE);

	u32 symbol_add = LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_0_OFFSET;

	for (int i = 0; i < 2; i++)
	{
		lphy_simple_dl_sigsus_thres_per_sym(BaseAddr, symbol_add, 0xffffffff);
		symbol_add += 0x4;
	}

	for (int i = 2; i < 4; i++)
	{
		lphy_simple_dl_sigsus_thres_per_sym(BaseAddr, symbol_add, 0x00000100);
		symbol_add += 0x4;
	}

	for (int i = 4; i < 6; i++)
		{
			lphy_simple_dl_sigsus_thres_per_sym(BaseAddr, symbol_add, 0xffffffff);
			symbol_add += 0x4;
		}

	for (int i = 6; i < 8; i++)
		{
			lphy_simple_dl_sigsus_thres_per_sym(BaseAddr, symbol_add, 0x00000100);
			symbol_add += 0x4;
		}

	for (int i = 8; i < 10; i++)
	{
		lphy_simple_dl_sigsus_thres_per_sym(BaseAddr, symbol_add, 0xffffffff);
		symbol_add += 0x4;
	}

	for (int i = 10; i < 12; i++)
		{
			lphy_simple_dl_sigsus_thres_per_sym(BaseAddr, symbol_add, 0x00000100);
			symbol_add += 0x4;
		}

	for (int i = 12; i < 14; i++)
		{
			lphy_simple_dl_sigsus_thres_per_sym(BaseAddr, symbol_add, 0xffffffff);
			symbol_add += 0x4;
		}
}


void lphy_simple_dl_config_LTE_10MHz(uint32_t BaseAddr) {

	lphy_simple_dl_IQ_Swap(BaseAddr,LPHY_DL_IQ_SWAP_OFF);
	lphy_simple_dl_FrameSource(BaseAddr, LPHY_DL_FRAME_SOURCE_MPLANE);
	lphy_simple_dl_CDD_CPBuffer(BaseAddr, 17600); //10850); // relate with delay of output from frame sync of GPS. B_HDL/4_BB_TOP/lib/ref_vsync_gen.v
	lphy_simple_dl_DebugMode(BaseAddr, LPHY_DL_DEBUG_MODE_OFF);
	lphy_simple_dl_DebugRemask(BaseAddr, LPHY_DL_DEBUG_REMASK_OFF);
	lphy_simple_dl_Debug_FrameStruct(BaseAddr, LPHY_DL_FFT_1024, LPHY_DL_SCS_15KHZ);
	lphy_simple_dl_Debug_NLayer(BaseAddr, 4);
	lphy_simple_dl_Debug_MonSMP(BaseAddr, 0, 0, 0, 0);


	lphy_simple_dl_LTE_SysMode(BaseAddr, 4, 4);
	lphy_simple_dl_K0(BaseAddr, 0);
	lphy_simple_dl_FreqShiftA(BaseAddr, 0);
	lphy_simple_dl_NumRE(BaseAddr, LPHY_DL_LTE_10MHZ_RE);
	lphy_simple_dl_FFT_Size(BaseAddr, LPHY_DL_FFT_1024);
	lphy_simple_dl_cp_type(BaseAddr, LPHY_DL_CP_NORMAL);
	lphy_simple_dl_ScaleAntGain(BaseAddr, 4);
	lphy_simple_dl_AntGain(BaseAddr, 4);
	lphy_simple_dl_SCS_Type(BaseAddr, LPHY_DL_SCS_15KHZ);

	lphy_simple_dl_AntBitMap(BaseAddr, LPHY_DL_4_ANT_ENABLE);
	lphy_simple_dl_DownShift(BaseAddr, 0);
	lphy_simple_dl_CDD_Value0(BaseAddr, 0);
	lphy_simple_dl_CDD_Value1(BaseAddr, 0);
	lphy_simple_dl_CDD_Value2(BaseAddr, 0);
	lphy_simple_dl_CDD_Value3(BaseAddr, 0);
}


void lphy_simple_dl_config_LTE_3MHz(uint32_t BaseAddr) {

	lphy_simple_dl_IQ_Swap(BaseAddr,LPHY_DL_IQ_SWAP_OFF);
	lphy_simple_dl_FrameSource(BaseAddr, LPHY_DL_FRAME_SOURCE_MPLANE);
	lphy_simple_dl_CDD_CPBuffer(BaseAddr, 10850); // relate with delay of output from frame sync of GPS. B_HDL/4_BB_TOP/lib/ref_vsync_gen.v
	lphy_simple_dl_DebugMode(BaseAddr, LPHY_DL_DEBUG_MODE_OFF);
	lphy_simple_dl_DebugRemask(BaseAddr, LPHY_DL_DEBUG_REMASK_OFF);
	lphy_simple_dl_Debug_FrameStruct(BaseAddr, LPHY_DL_FFT_512, LPHY_DL_SCS_15KHZ);
	lphy_simple_dl_Debug_NLayer(BaseAddr, 4);
	lphy_simple_dl_Debug_MonSMP(BaseAddr, 0, 0, 0, 0);


	lphy_simple_dl_LTE_SysMode(BaseAddr, 4, 4);
	lphy_simple_dl_K0(BaseAddr, 0);
	lphy_simple_dl_FreqShiftA(BaseAddr, 0);
	lphy_simple_dl_NumRE(BaseAddr, LPHY_DL_LTE_3MHZ_RE);
	lphy_simple_dl_FFT_Size(BaseAddr, LPHY_DL_FFT_512);
	lphy_simple_dl_cp_type(BaseAddr, LPHY_DL_CP_NORMAL);
	lphy_simple_dl_ScaleAntGain(BaseAddr, 4);
	lphy_simple_dl_AntGain(BaseAddr, 4);
	lphy_simple_dl_SCS_Type(BaseAddr, LPHY_DL_SCS_15KHZ);

	lphy_simple_dl_AntBitMap(BaseAddr, LPHY_DL_4_ANT_ENABLE);
	lphy_simple_dl_DownShift(BaseAddr, 0);
	lphy_simple_dl_CDD_Value0(BaseAddr, 0);
	lphy_simple_dl_CDD_Value1(BaseAddr, 0);
	lphy_simple_dl_CDD_Value2(BaseAddr, 0);
	lphy_simple_dl_CDD_Value3(BaseAddr, 0);

	lphy_simple_dl_sigsus_cnt_reset(BaseAddr, RESET_ON);
	lphy_simple_dl_sigsus_cnt_reset(BaseAddr, RESET_OFF);

	//	lphy_simple_dl_sigsus_enable_type(BaseAddr, SIGSUS_ENA_COMMON_THRES);
	lphy_simple_dl_sigsus_common_thres(BaseAddr, 0x00000100);

	lphy_simple_dl_sigsus_enable_type(BaseAddr, SIGSUS_ENA_THRES_PER_SYM);
	u32 symbol_add = LPHY_DL_SIGSUS_THRESHOLD_SYMBOL_0_OFFSET;
	for (int i = 0; i < 2; i++)
	{
		lphy_simple_dl_sigsus_thres_per_sym(BaseAddr, symbol_add, 0xffffffff);
		symbol_add += 0x4;
	}

	for (int i = 2; i < 4; i++)
	{
		lphy_simple_dl_sigsus_thres_per_sym(BaseAddr, symbol_add, 0x00000100);
		symbol_add += 0x4;
	}

	for (int i = 4; i < 8; i++)
	{
		lphy_simple_dl_sigsus_thres_per_sym(BaseAddr, symbol_add, 0xffffffff);
		symbol_add += 0x4;
	}

	for (int i = 8; i < 14; i++)
	{
		lphy_simple_dl_sigsus_thres_per_sym(BaseAddr, symbol_add, 0x00000100);
		symbol_add += 0x4;
	}



}
