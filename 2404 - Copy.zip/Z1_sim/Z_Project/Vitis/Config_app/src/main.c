#include "xparameters.h"
#include "stdio.h"

#include "core_baseaddr.h"

#include "sysctrl_drvs.h"
#include "oran_simple_drvs.h"

#include "lphy_simple_top_drvs.h"
#include "lphy_simple_dl_drvs.h"
#include "lphy_simple_ul_drvs.h"
#include "lphy_simple_ra_drvs.h"
#include "lphy_simple_nbiot_drvs.h"

#include "bbctrl_simple_drvs.h"

int main() {

	sysctrl_preset(SYSCTRL_BASEADDR);

	sysctrl_reset(SYSCTRL_BASEADDR);

//	bbctrl_3MHz(RU_BBCTRL_BASEADDR);

//	lphy_simple_top_config(RU_LPHY_TOP_BASEADDR);

//	lphy_simple_dl_config_LTE_3MHz(RU_LPHY_DL_CC0_BASEADDR);
//	lphy_simple_ul_config_LTE_3MHz(RU_LPHY_UL_CC0_BASEADDR);
//	lphy_simple_ra_LTE_3MHz(RU_LPHY_RA_CC0_BASEADDR);
//
//	lphy_simple_dl_config_LTE_3MHz(RU_LPHY_DL_CC1_BASEADDR);
//	lphy_simple_ul_config_LTE_3MHz(RU_LPHY_UL_CC1_BASEADDR);
//	lphy_simple_ra_LTE_3MHz(RU_LPHY_RA_CC1_BASEADDR);
//
//
////	lphy_simple_dl_config_LTE_3MHz(RU_LPHY_DL_CC1_BASEADDR);
////	lphy_simple_ul_config_LTE_3MHz(RU_LPHY_UL_CC1_BASEADDR);
////	lphy_simple_ra_LTE_3MHz(RU_LPHY_RA_CC1_BASEADDR);

//	lphy_simple_dl_config_LTE_20MHz(RU_LPHY_DL_CC0_BASEADDR);
//	lphy_simple_ul_config_LTE_10MHz(RU_LPHY_UL_CC0_BASEADDR);
//	lphy_simple_ul_config_LTE_20MHz(RU_LPHY_UL_CC0_BASEADDR);

//	lphy_simple_ra_LTE_20MHz(RU_LPHY_RA_CC0_BASEADDR);

//	lphy_simple_dl_config_LTE_20MHz(RU_LPHY_DL_CC1_BASEADDR);
//	lphy_simple_ul_config_LTE_10MHz(RU_LPHY_UL_CC1_BASEADDR);
//	lphy_simple_ul_config_LTE_20MHz(RU_LPHY_UL_CC1_BASEADDR);

//	lphy_simple_dl_config_LTE_20MHz(RU_LPHY_DL_CC2_BASEADDR);
//	lphy_simple_dl_config_LTE_20MHz(RU_LPHY_DL_CC3_BASEADDR);

//	lphy_simple_ra_LTE_20MHz(RU_LPHY_RA_CC1_BASEADDR);
//	lphy_simple_ra_LTE_20MHz(RU_LPHY_RA_CC2_BASEADDR);
//	lphy_simple_ra_LTE_20MHz(RU_LPHY_RA_CC3_BASEADDR);

//	lphy_simple_nb_config(RU_LPHY_NBIOT_CC0_BASEADDR);
//	lphy_simple_nb_config(RU_LPHY_NBIOT_CC1_BASEADDR);

	oran_26A_5g_10MHz_2cc_configure(RU_ORAN_TOP_BASEADDR);
//	oran_26A_5g_20MHz_2cc_configure(RU_ORAN_TOP_BASEADDR);

//	oran_25A_5g_3MHz_2cc_configure(RU_ORAN_TOP_BASEADDR);
//	fpga_write32_register(RU_ORAN_TOP_BASEADDR, ORAN_UL_PATH0_IGNORE_FRAMEID_OFFSET, 0xFFFFFFFF);

	return 0;
}
