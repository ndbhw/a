#include "bbctrl_simple_drvs.h"

void bbctrl_3MHz(u32 core_baseaddr) {
	// BB Ctrl Bandwidth select
	fpga_write32_register(core_baseaddr, BBCTRL_BW_SEL0_OFFSET, BBCTRL_FORMATTER_BANDWIDTH);

//	// BB Ctrl setup CPRI switch
//	fpga_write32_register(core_baseaddr, BBCTRL_MAPPER_CONFIG_CPRI_SEL0_OFFSET, 0x0);
//	fpga_write32_register(core_baseaddr, BBCTRL_MAPPER_CONFIG_CPRI_SEL1_OFFSET, 0x1);
//
//	// BB Ctrl configure Formatter DL
//	fpga_write32_register(core_baseaddr, BBCTRL_FORMATTER0_DL_MAP_OFFSET, 0xC000);
//	fpga_write32_register(core_baseaddr, BBCTRL_FORMATTER1_DL_MAP_OFFSET, 0xC001);
//
//	// BB Ctrl configure Formatter UL
//	fpga_write32_register(core_baseaddr, BBCTRL_MAPPER0_UL_MAP_OFFSET, 0xF000);
//	fpga_write32_register(core_baseaddr, BBCTRL_MAPPER1_UL_MAP_OFFSET, 0xF001);

	fpga_write32_register(core_baseaddr, BBCTRL_DL_AXC_ON0_OFFSET, 0xFFFFFFFF);
	fpga_write32_register(core_baseaddr, BBCTRL_UP_AXC_ON0_OFFSET, 0xFFFFFFFF);

}
