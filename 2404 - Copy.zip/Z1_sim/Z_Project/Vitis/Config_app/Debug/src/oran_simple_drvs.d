src/oran_simple_drvs.o src/oran_simple_drvs.o: ../src/oran_simple_drvs.c \
 ../src/oran_simple_drvs.h ../src/fpga_register_config.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_io.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_types.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_printf.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xparameters.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/bspconfig.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xstatus.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_assert.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/mb_interface.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_exception.h
../src/oran_simple_drvs.h:
../src/fpga_register_config.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_io.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_types.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_printf.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xparameters.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/bspconfig.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xstatus.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_assert.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/mb_interface.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_exception.h:
