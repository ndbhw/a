src/main.o src/main.o: ../src/main.c \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xparameters.h \
 ../src/core_baseaddr.h ../src/sysctrl_drvs.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_io.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_types.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_printf.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xparameters.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/bspconfig.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xstatus.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_assert.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/mb_interface.h \
 C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_exception.h \
 ../src/oran_simple_drvs.h ../src/fpga_register_config.h \
 ../src/lphy_simple_top_drvs.h ../src/lphy_simple_dl_drvs.h \
 ../src/lphy_simple_ul_drvs.h ../src/lphy_simple_ra_drvs.h \
 ../src/lphy_simple_nbiot_drvs.h ../src/bbctrl_simple_drvs.h
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xparameters.h:
../src/core_baseaddr.h:
../src/sysctrl_drvs.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_io.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_types.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_printf.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xparameters.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/bspconfig.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xstatus.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_assert.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/mb_interface.h:
C\:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include/xil_exception.h:
../src/oran_simple_drvs.h:
../src/fpga_register_config.h:
../src/lphy_simple_top_drvs.h:
../src/lphy_simple_dl_drvs.h:
../src/lphy_simple_ul_drvs.h:
../src/lphy_simple_ra_drvs.h:
../src/lphy_simple_nbiot_drvs.h:
../src/bbctrl_simple_drvs.h:
