################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
LD_SRCS += \
../src/lscript.ld 

C_SRCS += \
../src/bbctrl_simple_drvs.c \
../src/lphy_simple_dl_drvs.c \
../src/lphy_simple_nbiot_drvs.c \
../src/lphy_simple_ra_drvs.c \
../src/lphy_simple_top_drvs.c \
../src/lphy_simple_ul_drvs.c \
../src/main.c \
../src/oran_simple_drvs.c \
../src/sysctrl_drvs.c 

OBJS += \
./src/bbctrl_simple_drvs.o \
./src/lphy_simple_dl_drvs.o \
./src/lphy_simple_nbiot_drvs.o \
./src/lphy_simple_ra_drvs.o \
./src/lphy_simple_top_drvs.o \
./src/lphy_simple_ul_drvs.o \
./src/main.o \
./src/oran_simple_drvs.o \
./src/sysctrl_drvs.o 

C_DEPS += \
./src/bbctrl_simple_drvs.d \
./src/lphy_simple_dl_drvs.d \
./src/lphy_simple_nbiot_drvs.d \
./src/lphy_simple_ra_drvs.d \
./src/lphy_simple_top_drvs.d \
./src/lphy_simple_ul_drvs.d \
./src/main.d \
./src/oran_simple_drvs.d \
./src/sysctrl_drvs.d 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: MicroBlaze gcc compiler'
	mb-gcc -Wall -O0 -g3 -c -fmessage-length=0 -MT"$@" -IC:/Users/binhn/Temp/test_fpga/ORAN_sim/2404/Z1_sim/Z_Project/Vitis/RU_Simulation/export/RU_Simulation/sw/RU_Simulation/standalone_microblaze_0/bspinclude/include -mlittle-endian -mcpu=v11.0 -mxl-soft-mul -Wl,--no-relax -ffunction-sections -fdata-sections -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


