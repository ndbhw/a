module pcap_load(
    input wire i_clk, // 156.25 MHz
    input wire i_rst,
    output wire [63:0] o_tdata,
    output wire [7:0]  o_tkeep,
    output wire        o_tlast,
    output wire        o_tvalid
    );

    localparam integer CLK_PER_US_LONG  = 156;
    localparam integer CLK_PER_US_SHORT = 155;
    // 157+156+156+156

    reg [7:0]  r_cnt_clk;
    reg [1:0]  r_phase_us;
    reg [63:0] r_time_us;
    wire [7:0] w_us_limit;

    wire [63:0] w_pcap_time_us;

    localparam S_RESET = 2'd0;
    localparam S_READ  = 2'd1;
    localparam S_WAIT  = 2'd2;

    reg [1:0] r_state;
    reg r_read_en;
    reg [63:0] r_pcap_time_d;
    wire w_pcap_time_new;

    wire [63:0] w_m_tdata;
    wire [7:0]  w_m_tkeep;
    wire        w_m_tlast;
    wire        w_m_valid;

    reg [63:0] r_tdata;
    reg [7:0]  r_tkeep;
    reg        r_tlast;
    reg        r_tvalid;

    reg [63:0] r_buf_tdata;
    reg [7:0]  r_buf_tkeep;
    reg        r_buf_tlast;
    reg        r_buf_tvalid;

    assign w_us_limit = (r_phase_us == 2'd0) ? CLK_PER_US_LONG[7:0]
                                             : CLK_PER_US_SHORT[7:0];

    always @(posedge i_clk) begin
        if(i_rst) begin
            r_cnt_clk  <= 'd0;
            r_phase_us <= 'd0;
            r_time_us  <= 'd0;
        end
        else begin
            if(r_cnt_clk == w_us_limit) begin
                r_cnt_clk  <= 'd0;
                r_phase_us <= r_phase_us + 2'd1;
                r_time_us  <= r_time_us + 64'd1;
            end else begin
                r_cnt_clk  <= r_cnt_clk + 8'd1;
            end
        end
    end

    assign w_pcap_time_new = (w_pcap_time_us != r_pcap_time_d);

    always @(posedge i_clk) begin
        if(i_rst)
            r_pcap_time_d <= 64'd0;
        else
            r_pcap_time_d <= w_pcap_time_us;
    end

    always @(posedge i_clk) begin
        if(i_rst) begin
            r_state   <= S_RESET;
            r_read_en <= 1'b0;
        end
        else begin
            case(r_state)
                S_RESET: begin
                    r_read_en <= 1'b1;
                    r_state   <= S_READ;
                end

                S_READ: begin
                    r_read_en <= 1'b1;
                    if(w_pcap_time_new && (w_pcap_time_us >= r_time_us)) begin
                        r_read_en <= 1'b0;
                        r_state   <= S_WAIT;
                    end
                end

                S_WAIT: begin
                    r_read_en <= 1'b0;
                    if(w_pcap_time_us <= r_time_us) begin
                        r_read_en <= 1'b1;
                        r_state   <= S_READ;
                    end
                end

                default: begin
                    r_state   <= S_RESET;
                    r_read_en <= 1'b0;
                end
            endcase
        end
    end

    always @(posedge i_clk) begin
        if(i_rst) begin
            r_buf_tdata  <= 64'd0;
            r_buf_tkeep  <= 8'd0;
            r_buf_tlast  <= 1'b0;
            r_buf_tvalid <= 1'b0;
        end
        else begin
            if(r_buf_tvalid & ~r_read_en) begin
                r_buf_tvalid <= r_buf_tvalid;
            end
            else begin
                r_buf_tvalid <= w_m_valid;
                r_buf_tlast  <= w_m_valid ? w_m_tlast : 1'b0;
                if(w_m_valid) begin
                    r_buf_tdata <= w_m_tdata;
                    r_buf_tkeep <= w_m_tkeep;
                end
            end
        end
    end

    always @(posedge i_clk) begin
        if(i_rst) begin
            r_tdata  <= 64'd0;
            r_tkeep  <= 8'd0;
            r_tlast  <= 1'b0;
            r_tvalid <= 1'b0;
        end
        else begin
            r_tvalid <= r_buf_tvalid & r_read_en;
            r_tlast  <= (r_buf_tvalid & r_read_en) ? r_buf_tlast : 1'b0;
            if(r_buf_tvalid & r_read_en) begin
                r_tdata <= r_buf_tdata;
                r_tkeep <= r_buf_tkeep;
            end
        end
    end

    assign o_tdata  = r_tdata;
    assign o_tkeep  = r_tkeep;
    assign o_tlast  = r_tlast;
    assign o_tvalid = r_tvalid;

pcap_reader  pcap_reader_inst(
   .clk            (i_clk),
   .rst            (i_rst),
   .ready          (r_read_en),
   .m_tdata        (w_m_tdata),
   .m_tkeep        (w_m_tkeep),
   .m_tlast        (w_m_tlast),
   .o_m_valid      (w_m_valid),
   .pcap_time      (w_pcap_time_us),
   .CU_check       ()
);

endmodule
