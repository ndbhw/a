module sim_read_top(
    );
 
    wire clk_156p25;
    wire rst;   
    
    bd_clk_wrapper clock_gen(
        .clk_156p25(clk_156p25),
        .rst       (rst)
    ); 
    
//pcap_reader  pcap_reader_inst(
//   .clk            (clk_156p25),
//   .rst            (rst),
//   .ready          (1'b1),
//   .m_tdata (),
//   .m_tkeep  (),
//   .m_tlast        (),
//   .o_m_valid        (),
//   .pcap_time      ()
//   //.CU_check ()
//);
    
    wire [63:0] w_tdata;
    wire [7:0]  w_tkeep;
    wire        w_tlast;
    wire        w_tvalid;

    pcap_load pcap_load_inst(
        .i_clk    (clk_156p25),
        .i_rst    (rst),
        .o_tdata  (w_tdata),
        .o_tkeep  (w_tkeep),
        .o_tlast  (w_tlast),
        .o_tvalid (w_tvalid)
    );

endmodule
