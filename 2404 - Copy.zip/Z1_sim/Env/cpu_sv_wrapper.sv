module cpu_ru_sv_wrapper(
    input  logic            lite_clk         ,
    input  logic            lite_resetn      ,
    
    
    input  logic [31:0]     ru_rdata_cpu_in  ,
    output logic [19:0]     ru_addr_cpu_out  ,    
    output logic [31:0]     ru_wdata_cpu_out ,
    output logic            ru_wren_cpu_out  ,
    output logic            ru_rden_cpu_out  ,
    output logic            ru_cs_cpu_out    
);

    cpu_emu_bd_wrapper cpu_emu_bd_wrapper_inst (
        .lite_clk         (lite_clk         ),
        .lite_resetn      (lite_resetn      ),
        
        .ru_rdata_cpu_in  (ru_rdata_cpu_in  ),
        .ru_addr_cpu_out  (ru_addr_cpu_out  ),
        .ru_wdata_cpu_out (ru_wdata_cpu_out ),
        .ru_wren_cpu_out  (ru_wren_cpu_out  ),
        .ru_rden_cpu_out  (ru_rden_cpu_out  ),
        .ru_cs_cpu_out    (ru_cs_cpu_out    )
    );
endmodule 
