module RU_Simulation();

    wire w_fpga_sysclk;
    wire w_156p25m;
    clock_emu_bd clock_emu_bd_inst (
        .w_fpga_sysclk   (w_fpga_sysclk),
        .w_156p25m       (w_156p25m)
    );

RU_FPGA_TOP_sim RU_SIM(

  .FPGA_REF_CLK (w_fpga_sysclk), // --: in    std_logic; -- 122.88MHz
  .sim_156p25m  (w_156p25m)

);


endmodule