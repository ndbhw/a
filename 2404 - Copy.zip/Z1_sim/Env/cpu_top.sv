module cpu_ru_top(
    output logic            lite_clk            ,
    output logic            lite_reset          ,
    
    input  logic [31:0]     ru_rdata_cpu_in     ,
    output logic [19:0]     ru_addr_cpu_out     ,    
    output logic [31:0]     ru_wdata_cpu_out    ,
    output logic            ru_wren_cpu_out     ,
    output logic            ru_rden_cpu_out     ,
    output logic            ru_cs_cpu_out       
);  

    logic lite_resetn;
    
    cpu_ru_sv_wrapper cpu_ru_sv_wrapper_inst(
        .lite_clk        (lite_clk        ),
        .lite_resetn     (lite_resetn     ),   
        
        .ru_addr_cpu_out (ru_addr_cpu_out ),
        .ru_rdata_cpu_in (ru_rdata_cpu_in ),
        .ru_wdata_cpu_out(ru_wdata_cpu_out),
        .ru_wren_cpu_out (ru_wren_cpu_out ),
        .ru_rden_cpu_out (ru_rden_cpu_out ),
        .ru_cs_cpu_out   (ru_cs_cpu_out   )
    );
    
    localparam LITE_PERIOD = 10;
    
    logic        tb_lite_clock        ;
    logic        tb_lite_resetn       ;
    logic        tb_lite_reset        ;
    
    
    always begin
        tb_lite_clock = 1; #(LITE_PERIOD / 2);
        tb_lite_clock = 0; #(LITE_PERIOD / 2);
    end

    initial begin
        tb_lite_resetn = 0;
        tb_lite_reset  = 1;
        #(LITE_PERIOD * 10)
        tb_lite_resetn = 1;
        tb_lite_reset  = 0;
    end

    BUFG bufg_lite_clk_inst (
        .I(tb_lite_clock  ),
        .O(lite_clk       )        
    );
    
    xpm_cdc_async_rst #(
        .DEST_SYNC_FF   (2), 
        .INIT_SYNC_FF   (0), 
        .RST_ACTIVE_HIGH(0) 
    )
    sync_lite_resetn_inst (
        .src_arst (tb_lite_resetn), 
        .dest_clk (lite_clk      ), 
        .dest_arst(lite_resetn   )        
    );
    
    xpm_cdc_async_rst #(
        .DEST_SYNC_FF   (2), 
        .INIT_SYNC_FF   (0), 
        .RST_ACTIVE_HIGH(1) 
    )
    sync_lite_reset_inst (
        .src_arst (tb_lite_reset), 
        .dest_clk (lite_clk     ), 
        .dest_arst(lite_reset   )        
    );
    
endmodule 
