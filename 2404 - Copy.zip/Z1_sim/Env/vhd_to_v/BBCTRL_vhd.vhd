--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : BBCTRL Top (Master FPGA)                                      --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2021.12.15                                                    --
-- Target     : RF4430                                                        --
--                                                                            --
--------------------------------------------------------------------------------
-- Feature (V3.0, 2017-05-17 based)                                           --
--------------------------------------------------------------------------------
--  1. Max CPRI port : 2                                                      --
--  2. Max mapper : 2                                                         --
--  3. Max formatter : 2                                                      --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;
use WORK.RU_FPGA_CONFIG.ALL;

entity BBCTRL_vhd is
    port (
        --------------------------------------------------------------------------------
        -- External System PLL
        --------------------------------------------------------------------------------

        EXT_SYSPLL_LOCK_IN : in std_logic;

        --------------------------------------------------------------------------------
        -- SYSCTRL_TOP
        --------------------------------------------------------------------------------

        RST_BBCTRL : in std_logic;

        CLK_CPRI : in std_logic_vector(CPRI_NUM-1 downto 0);

        CLK_SYS    : in std_logic;
        CLK_SYSX2  : in std_logic;
        CLK_SYSX3  : in std_logic;
        CLK_SYSX4  : in std_logic;
        CLK_SYSX5  : in std_logic;
        CLK_SYSX6  : in std_logic;
        CLK_SYSX8  : in std_logic;
        CLK_SYSX10 : in std_logic;
        CLK_SYSX12 : in std_logic;
        CLK_SYSX16 : in std_logic;
        CLK_SYSX20 : in std_logic;

        RX_BFN_STRB_IN : in std_logic_vector(CPRI_NUM-1 downto 0);
        RX_BFN_NR_IN   : in std_logic_vector(CPRI_NUM*12-1 downto 0);
        RX_TDD_IN      : in std_logic_vector(CPRI_NUM-1 downto 0);

        TX_BFN_STRB_IN  : in  std_logic_vector(CPRI_NUM-1 downto 0);
        TX_BFN_NR_IN    : in  std_logic_vector(CPRI_NUM*12-1 downto 0);
        TX_TDD_OUT      : out std_logic_vector(CPRI_NUM-1 downto 0);
        TX_BFN_STRB_OUT : out std_logic_vector(CPRI_NUM-1 downto 0);

        TDD_AND_CTRL_IN : in std_logic;
        TDD_OR_CTRL_IN  : in std_logic;
        TDD_CTRL_IN     : in std_logic_vector(31 downto 0);

        BCF_ENB_IN  : in  std_logic;
        BCF_ENB_OUT : out std_logic;

        SSB_OFFSET : in std_logic_vector(3 downto 0);

        --------------------------------------------------------------------------------
        -- CPU_TOP
        --------------------------------------------------------------------------------

        RST_CPUIF : in std_logic;
        CLK_CPUIF : in std_logic;

        I_1PPS_CPU                  : in  std_logic;
        I_BFN_STRB_CPU              : in  std_logic;
        I_BFN_CPU                   : in  std_logic_vector(10 downto 0);

        --------------------------------------------------------------------------------
        -- CPUIF_TOP
        --------------------------------------------------------------------------------

        WREN_CPUIF_IN   : in  std_logic;
        RDEN_CPUIF_IN   : in  std_logic;
        ADDR_CPUIF_IN   : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN  : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT : out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT : out std_logic;

        --------------------------------------------------------------------------------
-- BB_TOP
        --------------------------------------------------------------------------------

        I_DL_FSYNC                  :in  std_logic_vector(   DL_CC_NUM-1 downto 0);    -- 1 clock frame(10ms) sync  
        I_DL_TDD                    :in  std_logic_vector(   DL_CC_NUM-1 downto 0);       
        I_DL_VLD                    :in  std_logic_vector( DL_CC_NUM*4-1 downto 0);    -- valid signal for valid data.   
        I_DL_DATA_I                 :in  std_logic_vector(DL_CC_NUM*4*16-1 downto 0);    -- 16b idata path per one ant path.      
        I_DL_DATA_Q                 :in  std_logic_vector(DL_CC_NUM*4*16-1 downto 0);    -- 16b qdata path per one ant path.  

        O_UL_FSYNC                  :out std_logic_vector(   UL_CC_NUM-1 downto 0);    -- 1 clock frame(10ms) sync   
        O_UL_TDD                    :out std_logic_vector(   UL_CC_NUM-1 downto 0);       
        O_UL_VLD                    :out std_logic_vector( UL_CC_NUM*4-1 downto 0);    -- valid signal for valid data.   
        O_UL_DATA_I                 :out std_logic_vector(UL_CC_NUM*4*16-1 downto 0);    -- 16b idata path per one ant path.  
        O_UL_DATA_Q                 :out std_logic_vector(UL_CC_NUM*4*16-1 downto 0);    -- 16b qdata path per one ant path.  

        REFCLK_SEL_IN : in std_logic_vector(3 downto 0);

        --------------------------------------------------------------------------------
        -- CPRI_TOP
        --------------------------------------------------------------------------------
        CPRI_LOS_IN : in std_logic_vector(CPRI_NUM-1 downto 0);
        CPRI_LOF_IN : in std_logic_vector(CPRI_NUM-1 downto 0);

        IS_MASTER_CPRI_IN : in std_logic_vector(CPRI_NUM-1 downto 0);
        VSS_ACTIVE_SEL_IN : in std_logic_vector(CPRI_NUM-1 downto 0);

        LINE_RCF_START_IN   : in std_logic_vector(CPRI_NUM-1 downto 0);
        LINE_RCF_RATE_IN    : in std_logic_vector(CPRI_NUM*8-1 downto 0);
        LINE_RCF_CLKTYPE_IN : in std_logic_vector(CPRI_NUM*8-1 downto 0);
        LINE_RCF_WIDTH_IN   : in std_logic_vector(CPRI_NUM*8-1 downto 0);

        CPRI_RX_VLD_IN : in std_logic_vector(CPRI_NUM-1 downto 0);
        CPRI_RX_I_IN   : in std_logic_vector(CPRI_NUM*16-1 downto 0);
        CPRI_RX_Q_IN   : in std_logic_vector(CPRI_NUM*16-1 downto 0);

        CPRI_TX_ENB_IN : in  std_logic_vector(CPRI_NUM-1 downto 0);
        CPRI_TX_I_OUT  : out std_logic_vector(CPRI_NUM*16-1 downto 0);
        CPRI_TX_Q_OUT  : out std_logic_vector(CPRI_NUM*16-1 downto 0);

        --------------------------------------------------------------------------------
        -- DSP_TOP
        --------------------------------------------------------------------------------

        DL_BFN_OK : out std_logic;

        DL_AIRTECH_OUT  : out std_logic_vector(DL_BBIQARY_NUM*4-1 downto 0);
        DL_CHBW_OUT     : out std_logic_vector(DL_BBIQARY_NUM*4-1 downto 0);
        DL_TDD_OUT      : out std_logic;
        DL_40MS_OUT                 : out std_logic;
        DL_SSB_OUT      : out std_logic;
        DL_BFN_STRB_OUT : out std_logic;
        DL_BFN_OUT      : out std_logic_vector(11 downto 0);
        DL_SYNC_OUT     : out std_logic_vector(DL_BBIQARY_NUM-1 downto 0);
        DL_IQ_OUT       : out std_logic_vector(DL_BBIQARY_NUM*16-1 downto 0);

        UL_AIRTECH_OUT : out std_logic_vector(UL_BBIQARY_NUM*4-1 downto 0);
        UL_CHBW_OUT    : out std_logic_vector(UL_BBIQARY_NUM*4-1 downto 0);
        UL_TDD_IN      : in  std_logic;
        UL_BFN_STRB_IN : in  std_logic;
        UL_SYNC_IN     : in  std_logic_vector(UL_BBIQARY_NUM-1 downto 0);
        UL_IQ_IN       : in  std_logic_vector(UL_BBIQARY_NUM*16-1 downto 0);

        --------------------------------------------------------------------------------
        -- DBG_SIG_OUT
        --------------------------------------------------------------------------------

        DBG_SIG_OUT : out std_logic_vector(63 downto 0);

        --------------------------------------------------------------------------------
        -- MISC_TOP
        --------------------------------------------------------------------------------

        DUMP_BFN_STRB_OUT : out std_logic_vector(1 downto 0);
        DUMP_DATA_OUT     : out std_logic_vector(63 downto 0);
        DUMP_DVLD_OUT     : out std_logic_vector(1 downto 0);
        TEST_DATA_IN      : in  std_logic_vector(63 downto 0);
        TEST_ENB_OUT      : out std_logic_vector(1 downto 0);

        SIG_SUS_DLOFF_IN : in  std_logic_vector(CPRI_NUM-1 downto 0);
        SIG_SUS_FLAG_OUT : out std_logic_vector(DL_BBIQARY_NUM-1 downto 0);

    -- fb_sw_new
        FBSW_CNT                    : in  std_logic_vector(3 downto 0);
        FBSW_SSB_IND_FLAG           : in  std_logic; 
        FBSW_MEAS_UPDATE            : in  std_logic; 

        FBSW_START_TRIG_IN     : in std_logic;
        FBSW_CNT_IN            : in std_logic_vector(6 downto 0);
        FBSW_AUTO_MODE_DONE_IN : in std_logic_vector(FB_PATH_NUM-1 downto 0);
        FBSW_PWR_MSR_UDT_IN    : in std_logic;
        FBSW_MANUAL_MODE_IN    : in std_logic;

        PWR_UPT_TICK_IN : in std_logic_vector(FB_PATH_NUM-1 downto 0);
        FBSW_PATH_IN    : in std_logic_vector(FB_PATH_NUM*3-1 downto 0);

        SSB_EXIST_IN : in std_logic
    );
end BBCTRL_vhd;

architecture BEHAVE of BBCTRL_vhd is

component BBCTRL_TOP is
    port (
        --------------------------------------------------------------------------------
        -- External System PLL
        --------------------------------------------------------------------------------

        EXT_SYSPLL_LOCK_IN : in std_logic;

        --------------------------------------------------------------------------------
        -- SYSCTRL_TOP
        --------------------------------------------------------------------------------

        RST_BBCTRL : in std_logic;

        CLK_CPRI : in std_logic_vector(CPRI_NUM-1 downto 0);

        CLK_SYS    : in std_logic;
        CLK_SYSX2  : in std_logic;
        CLK_SYSX3  : in std_logic;
        CLK_SYSX4  : in std_logic;
        CLK_SYSX5  : in std_logic;
        CLK_SYSX6  : in std_logic;
        CLK_SYSX8  : in std_logic;
        CLK_SYSX10 : in std_logic;
        CLK_SYSX12 : in std_logic;
        CLK_SYSX16 : in std_logic;
        CLK_SYSX20 : in std_logic;

        RX_BFN_STRB_IN : in std_logic_vector(CPRI_NUM-1 downto 0);
        RX_BFN_NR_IN   : in std_logic_array12(CPRI_NUM-1 downto 0);
        RX_TDD_IN      : in std_logic_vector(CPRI_NUM-1 downto 0);

        TX_BFN_STRB_IN  : in  std_logic_vector(CPRI_NUM-1 downto 0);
        TX_BFN_NR_IN    : in  std_logic_array12(CPRI_NUM-1 downto 0);
        TX_TDD_OUT      : out std_logic_vector(CPRI_NUM-1 downto 0);
        TX_BFN_STRB_OUT : out std_logic_vector(CPRI_NUM-1 downto 0);

        TDD_AND_CTRL_IN : in std_logic;
        TDD_OR_CTRL_IN  : in std_logic;
        TDD_CTRL_IN     : in std_logic_vector(31 downto 0);

        BCF_ENB_IN  : in  std_logic;
        BCF_ENB_OUT : out std_logic;

        SSB_OFFSET : in std_logic_vector(3 downto 0);

        --------------------------------------------------------------------------------
        -- CPU_TOP
        --------------------------------------------------------------------------------

        RST_CPUIF : in std_logic;
        CLK_CPUIF : in std_logic;

        I_1PPS_CPU                  : in  std_logic;
        I_BFN_STRB_CPU              : in  std_logic;
        I_BFN_CPU                   : in  std_logic_vector(10 downto 0);

        --------------------------------------------------------------------------------
        -- CPUIF_TOP
        --------------------------------------------------------------------------------

        WREN_CPUIF_IN   : in  std_logic;
        RDEN_CPUIF_IN   : in  std_logic;
        ADDR_CPUIF_IN   : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN  : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT : out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT : out std_logic;

        --------------------------------------------------------------------------------
-- BB_TOP
        --------------------------------------------------------------------------------

        I_DL_FSYNC                  :in  std_logic_vector(   DL_CC_NUM-1 downto 0);    -- 1 clock frame(10ms) sync  
        I_DL_TDD                    :in  std_logic_vector(   DL_CC_NUM-1 downto 0);       
        I_DL_VLD                    :in  std_logic_vector( DL_CC_NUM*4-1 downto 0);    -- valid signal for valid data.   
        I_DL_DATA_I                 :in  std_logic_array16(DL_CC_NUM*4-1 downto 0);    -- 16b idata path per one ant path.      
        I_DL_DATA_Q                 :in  std_logic_array16(DL_CC_NUM*4-1 downto 0);    -- 16b qdata path per one ant path.  

        O_UL_FSYNC                  :out std_logic_vector(   UL_CC_NUM-1 downto 0);    -- 1 clock frame(10ms) sync   
        O_UL_TDD                    :out std_logic_vector(   UL_CC_NUM-1 downto 0);       
        O_UL_VLD                    :out std_logic_vector( UL_CC_NUM*4-1 downto 0);    -- valid signal for valid data.   
        O_UL_DATA_I                 :out std_logic_array16(UL_CC_NUM*4-1 downto 0);    -- 16b idata path per one ant path.  
        O_UL_DATA_Q                 :out std_logic_array16(UL_CC_NUM*4-1 downto 0);    -- 16b qdata path per one ant path.  

        REFCLK_SEL_IN : in std_logic_vector(3 downto 0);

        --------------------------------------------------------------------------------
        -- CPRI_TOP
        --------------------------------------------------------------------------------
        CPRI_LOS_IN : in std_logic_vector(CPRI_NUM-1 downto 0);
        CPRI_LOF_IN : in std_logic_vector(CPRI_NUM-1 downto 0);

        IS_MASTER_CPRI_IN : in std_logic_vector(CPRI_NUM-1 downto 0);
        VSS_ACTIVE_SEL_IN : in std_logic_vector(CPRI_NUM-1 downto 0);

        LINE_RCF_START_IN   : in std_logic_vector(CPRI_NUM-1 downto 0);
        LINE_RCF_RATE_IN    : in std_logic_array8(CPRI_NUM-1 downto 0);
        LINE_RCF_CLKTYPE_IN : in std_logic_array8(CPRI_NUM-1 downto 0);
        LINE_RCF_WIDTH_IN   : in std_logic_array8(CPRI_NUM-1 downto 0);

        CPRI_RX_VLD_IN : in std_logic_vector(CPRI_NUM-1 downto 0);
        CPRI_RX_I_IN   : in std_logic_array16(CPRI_NUM-1 downto 0);
        CPRI_RX_Q_IN   : in std_logic_array16(CPRI_NUM-1 downto 0);

        CPRI_TX_ENB_IN : in  std_logic_vector(CPRI_NUM-1 downto 0);
        CPRI_TX_I_OUT  : out std_logic_array16(CPRI_NUM-1 downto 0);
        CPRI_TX_Q_OUT  : out std_logic_array16(CPRI_NUM-1 downto 0);

        --------------------------------------------------------------------------------
        -- DSP_TOP
        --------------------------------------------------------------------------------

        DL_BFN_OK : out std_logic;

        DL_AIRTECH_OUT  : out std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
        DL_CHBW_OUT     : out std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
        DL_TDD_OUT      : out std_logic;
        DL_40MS_OUT                 : out std_logic;
        DL_SSB_OUT      : out std_logic;
        DL_BFN_STRB_OUT : out std_logic;
        DL_BFN_OUT      : out std_logic_vector(11 downto 0);
        DL_SYNC_OUT     : out std_logic_vector(DL_BBIQARY_NUM-1 downto 0);
        DL_IQ_OUT       : out std_logic_array16(DL_BBIQARY_NUM-1 downto 0);

        UL_AIRTECH_OUT : out std_logic_array4(UL_BBIQARY_NUM-1 downto 0);
        UL_CHBW_OUT    : out std_logic_array4(UL_BBIQARY_NUM-1 downto 0);
        UL_TDD_IN      : in  std_logic;
        UL_BFN_STRB_IN : in  std_logic;
        UL_SYNC_IN     : in  std_logic_vector(UL_BBIQARY_NUM-1 downto 0);
        UL_IQ_IN       : in  std_logic_array16(UL_BBIQARY_NUM-1 downto 0);

        --------------------------------------------------------------------------------
        -- DBG_SIG_OUT
        --------------------------------------------------------------------------------

        DBG_SIG_OUT : out std_logic_array32(1 downto 0);

        --------------------------------------------------------------------------------
        -- MISC_TOP
        --------------------------------------------------------------------------------

        DUMP_BFN_STRB_OUT : out std_logic_vector(1 downto 0);
        DUMP_DATA_OUT     : out std_logic_array32(1 downto 0);
        DUMP_DVLD_OUT     : out std_logic_vector(1 downto 0);
        TEST_DATA_IN      : in  std_logic_array32(1 downto 0);
        TEST_ENB_OUT      : out std_logic_vector(1 downto 0);

        SIG_SUS_DLOFF_IN : in  std_logic_vector(CPRI_NUM-1 downto 0);
        SIG_SUS_FLAG_OUT : out std_logic_vector(DL_BBIQARY_NUM-1 downto 0);

    -- fb_sw_new
        FBSW_CNT                    : in  std_logic_vector(3 downto 0);
        FBSW_SSB_IND_FLAG           : in  std_logic; 
        FBSW_MEAS_UPDATE            : in  std_logic; 

        FBSW_START_TRIG_IN     : in std_logic;
        FBSW_CNT_IN            : in std_logic_vector(6 downto 0);
        FBSW_AUTO_MODE_DONE_IN : in std_logic_vector(FB_PATH_NUM-1 downto 0);
        FBSW_PWR_MSR_UDT_IN    : in std_logic;
        FBSW_MANUAL_MODE_IN    : in std_logic;

        PWR_UPT_TICK_IN : in std_logic_vector(FB_PATH_NUM-1 downto 0);
        FBSW_PATH_IN    : in std_logic_array3(FB_PATH_NUM-1 downto 0);

        SSB_EXIST_IN : in std_logic
    );
end component;

signal arr_RX_BFN_NR_IN  		  : std_logic_array12(CPRI_NUM-1 downto 0);
signal arr_TX_BFN_NR_IN  		  : std_logic_array12(CPRI_NUM-1 downto 0);
signal arr_I_DL_DATA_I          : std_logic_array16(DL_CC_NUM*4-1 downto 0);    
signal arr_I_DL_DATA_Q          : std_logic_array16(DL_CC_NUM*4-1 downto 0); 
signal arr_O_UL_DATA_I          : std_logic_array16(UL_CC_NUM*4-1 downto 0);    
signal arr_O_UL_DATA_Q          : std_logic_array16(UL_CC_NUM*4-1 downto 0); 		
signal arr_LINE_RCF_RATE_IN	   : std_logic_array8(CPRI_NUM-1 downto 0);
signal arr_LINE_RCF_CLKTYPE_IN  : std_logic_array8(CPRI_NUM-1 downto 0);
signal arr_LINE_RCF_WIDTH_IN    : std_logic_array8(CPRI_NUM-1 downto 0);	
signal arr_CPRI_RX_I_IN   	  : std_logic_array16(CPRI_NUM-1 downto 0);
signal arr_CPRI_RX_Q_IN   	  : std_logic_array16(CPRI_NUM-1 downto 0);		
signal arr_DL_AIRTECH_OUT 	  : std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
signal arr_DL_CHBW_OUT    	  : std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
signal arr_DL_IQ_OUT      	  : std_logic_array16(DL_BBIQARY_NUM-1 downto 0);		
signal arr_UL_AIRTECH_OUT 	  : std_logic_array4(UL_BBIQARY_NUM-1 downto 0);
signal arr_UL_CHBW_OUT    	  : std_logic_array4(UL_BBIQARY_NUM-1 downto 0);		
signal arr_UL_IQ_IN       	  : std_logic_array16(UL_BBIQARY_NUM-1 downto 0);	
signal arr_DBG_SIG_OUT 		  : std_logic_array32(1 downto 0);				
signal arr_DUMP_DATA_OUT     	  : std_logic_array32(1 downto 0);			
signal arr_TEST_DATA_IN      	  : std_logic_array32(1 downto 0);
signal arr_FBSW_PATH_IN    	  : std_logic_array3(FB_PATH_NUM-1 downto 0); 

signal arr_CPRI_TX_I_OUT      : std_logic_array16(CPRI_NUM-1 downto 0);
signal arr_CPRI_TX_Q_OUT      : std_logic_array16(CPRI_NUM-1 downto 0);
	
begin

arr_RX_BFN_NR_IN(0)	<=	RX_BFN_NR_IN(11 downto 0);
arr_TX_BFN_NR_IN(0)	<=	TX_BFN_NR_IN(11 downto 0);

CPRI_TX_I_OUT (15 downto 0)<= arr_CPRI_TX_I_OUT(0);
CPRI_TX_Q_OUT (15 downto 0)<= arr_CPRI_TX_I_OUT(0);

gen_1: for i in 0 to 7 generate
begin
arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
arr_I_DL_DATA_Q(i)  <= I_DL_DATA_Q(16*i+15 downto 16*i);

O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
O_UL_DATA_Q(16*i+15 downto 16*i) <=	arr_O_UL_DATA_Q(i);

end generate;


arr_LINE_RCF_RATE_IN	(0) <= LINE_RCF_RATE_IN	(7 downto 0); -- std_logic_array8(CPRI_NUM-1 downto 0);
arr_LINE_RCF_CLKTYPE_IN (0) <= LINE_RCF_CLKTYPE_IN (7 downto 0); -- std_logic_array8(CPRI_NUM-1 downto 0);
arr_LINE_RCF_WIDTH_IN   (0) <= LINE_RCF_WIDTH_IN   (7 downto 0); -- std_logic_array8(CPRI_NUM-1 downto 0);	
arr_CPRI_RX_I_IN   	    (0) <= CPRI_RX_I_IN 		(15 downto 0); --std_logic_array16(CPRI_NUM-1 downto 0);
arr_CPRI_RX_Q_IN   	    (0) <= CPRI_RX_Q_IN 		(15 downto 0); --std_logic_array16(CPRI_NUM-1 downto 0);
		
		
gen_2: for i in 0 to 1 generate
begin		
DL_AIRTECH_OUT 		(4*i+3 	 downto  4*i)     <=  arr_DL_AIRTECH_OUT (i)  ; -- std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
DL_CHBW_OUT    		(4*i+3 	 downto  4*i)     <=  arr_DL_CHBW_OUT    (i)  ; -- std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
DL_IQ_OUT      		(16*i+15 downto 16*i)     <=  arr_DL_IQ_OUT      (i)  ; -- std_logic_array16(DL_BBIQARY_NUM-1 downto 0);		
UL_AIRTECH_OUT 		(4*i+3 	 downto  4*i)     <=  arr_UL_AIRTECH_OUT (i)  ; -- std_logic_array4(UL_BBIQARY_NUM-1 downto 0);
UL_CHBW_OUT    		(4*i+3 	 downto  4*i)	  <=  arr_UL_CHBW_OUT    (i)  ; -- std_logic_array4(UL_BBIQARY_NUM-1 downto 0);		
DBG_SIG_OUT 		(32*i+31 downto 32*i)	  <=  arr_DBG_SIG_OUT 	 (i)  ; -- std_logic_array32(1 downto 0);				
DUMP_DATA_OUT		(32*i+31 downto 32*i)	  <=  arr_DUMP_DATA_OUT	 (i)  ; -- std_logic_array32(1 downto 0);	


arr_UL_IQ_IN    (i)  <=  UL_IQ_IN(16*i+15 downto 16*i);  --std_logic_array16(UL_BBIQARY_NUM-1 downto 0);
arr_FBSW_PATH_IN(i)  <=  FBSW_PATH_IN(3*i+2 downto 3*i); --std_logic_array3(FB_PATH_NUM-1 downto 0); 

arr_TEST_DATA_IN (i) <= TEST_DATA_IN(31 downto 0) 	;	 --: std_logic_array32(1 downto 0);

end generate;
		

 u_bbctrl: BBCTRL_TOP
	port map(
 
        --------------------------------------------------------------------------------
        -- External System PLL
        --------------------------------------------------------------------------------

        EXT_SYSPLL_LOCK_IN => EXT_SYSPLL_LOCK_IN,-- std_logic;

        --------------------------------------------------------------------------------
        -- SYSCTRL_TOP
        --------------------------------------------------------------------------------

        RST_BBCTRL => RST_BBCTRL,-- std_logic;

        CLK_CPRI => CLK_CPRI,-- std_logic_vector(CPRI_NUM-1 downto 0);

        CLK_SYS    => CLK_SYS    ,--std_logic;
        CLK_SYSX2  => CLK_SYSX2  ,--std_logic;
        CLK_SYSX3  => CLK_SYSX3  ,--std_logic;
        CLK_SYSX4  => CLK_SYSX4  ,--std_logic;
        CLK_SYSX5  => CLK_SYSX5  ,--std_logic;
        CLK_SYSX6  => CLK_SYSX6  ,--std_logic;
        CLK_SYSX8  => CLK_SYSX8  ,--std_logic;
        CLK_SYSX10 => CLK_SYSX10 ,--std_logic;
        CLK_SYSX12 => CLK_SYSX12 ,--std_logic;
        CLK_SYSX16 => CLK_SYSX16 ,--std_logic;
        CLK_SYSX20 => CLK_SYSX20 ,--std_logic;

        RX_BFN_STRB_IN => RX_BFN_STRB_IN,-- std_logic_vector(CPRI_NUM-1 downto 0);
        RX_BFN_NR_IN   => arr_RX_BFN_NR_IN ,--: in std_logic_array12(CPRI_NUM-1 downto 0);
        RX_TDD_IN      => RX_TDD_IN,-- std_logic_vector(CPRI_NUM-1 downto 0);

        TX_BFN_STRB_IN  => TX_BFN_STRB_IN,--  std_logic_vector(CPRI_NUM-1 downto 0);
        TX_BFN_NR_IN    => arr_TX_BFN_NR_IN,--: in  std_logic_array12(CPRI_NUM-1 downto 0);
        TX_TDD_OUT      => TX_TDD_OUT      ,--std_logic_vector(CPRI_NUM-1 downto 0);
        TX_BFN_STRB_OUT => TX_BFN_STRB_OUT ,--std_logic_vector(CPRI_NUM-1 downto 0);

        TDD_AND_CTRL_IN => TDD_AND_CTRL_IN ,--std_logic;
        TDD_OR_CTRL_IN  => TDD_OR_CTRL_IN  ,--std_logic;
        TDD_CTRL_IN     => TDD_CTRL_IN     ,--std_logic_vector(31 downto 0);

        BCF_ENB_IN  => BCF_ENB_IN ,--std_logic;
        BCF_ENB_OUT => BCF_ENB_OUT,--std_logic;

        SSB_OFFSET => SSB_OFFSET,-- std_logic_vector(3 downto 0);

        --------------------------------------------------------------------------------
        -- CPU_TOP
        --------------------------------------------------------------------------------

        RST_CPUIF => RST_CPUIF ,-- std_logic;
        CLK_CPUIF => CLK_CPUIF ,-- std_logic;

        I_1PPS_CPU       => I_1PPS_CPU      ,-- std_logic;
        I_BFN_STRB_CPU   => I_BFN_STRB_CPU  ,-- std_logic;
        I_BFN_CPU        => I_BFN_CPU       ,-- std_logic_vector(10 downto 0);

        --------------------------------------------------------------------------------
        -- CPUIF_TOP
        --------------------------------------------------------------------------------

        WREN_CPUIF_IN   => WREN_CPUIF_IN   ,-- std_logic;
        RDEN_CPUIF_IN   => RDEN_CPUIF_IN   ,-- std_logic;
        ADDR_CPUIF_IN   => ADDR_CPUIF_IN   ,-- std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN  => WDATA_CPUIF_IN  ,-- std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT => RDATA_CPUIF_OUT ,-- std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT => RDVAL_CPUIF_OUT ,-- std_logic;

        --------------------------------------------------------------------------------
-- BB_TOP
        --------------------------------------------------------------------------------

        I_DL_FSYNC    => I_DL_FSYNC  ,--std_logic_vector(   DL_CC_NUM-1 downto 0);    -- 1 clock frame(10ms) sync  
        I_DL_TDD      => I_DL_TDD    ,--std_logic_vector(   DL_CC_NUM-1 downto 0);       
        I_DL_VLD      => I_DL_VLD    ,--std_logic_vector( DL_CC_NUM*4-1 downto 0);    -- valid signal for valid data.   
        I_DL_DATA_I  => arr_I_DL_DATA_I ,-- :in  std_logic_array16(DL_CC_NUM*4-1 downto 0);    -- 16b idata path per one ant path.      
        I_DL_DATA_Q  => arr_I_DL_DATA_Q ,-- :in  std_logic_array16(DL_CC_NUM*4-1 downto 0);    -- 16b qdata path per one ant path.  

        O_UL_FSYNC   => O_UL_FSYNC ,--std_logic_vector(   UL_CC_NUM-1 downto 0);    -- 1 clock frame(10ms) sync   
        O_UL_TDD     => O_UL_TDD   ,--std_logic_vector(   UL_CC_NUM-1 downto 0);       
        O_UL_VLD     => O_UL_VLD   ,--std_logic_vector( UL_CC_NUM*4-1 downto 0);    -- valid signal for valid data.   
        O_UL_DATA_I  => arr_O_UL_DATA_I  ,--             :out std_logic_array16(UL_CC_NUM*4-1 downto 0);    -- 16b idata path per one ant path.  
        O_UL_DATA_Q  => arr_O_UL_DATA_Q  ,--             :out std_logic_array16(UL_CC_NUM*4-1 downto 0);    -- 16b qdata path per one ant path.  

        REFCLK_SEL_IN => REFCLK_SEL_IN,-- std_logic_vector(3 downto 0);

        --------------------------------------------------------------------------------
        -- CPRI_TOP
        --------------------------------------------------------------------------------
        CPRI_LOS_IN 	  => CPRI_LOS_IN ,--std_logic_vector(CPRI_NUM-1 downto 0);
        CPRI_LOF_IN 	  => CPRI_LOF_IN ,--std_logic_vector(CPRI_NUM-1 downto 0);

        IS_MASTER_CPRI_IN => IS_MASTER_CPRI_IN,-- std_logic_vector(CPRI_NUM-1 downto 0);
        VSS_ACTIVE_SEL_IN => VSS_ACTIVE_SEL_IN,-- std_logic_vector(CPRI_NUM-1 downto 0);

        LINE_RCF_START_IN     => LINE_RCF_START_IN,-- std_logic_vector(CPRI_NUM-1 downto 0);
        LINE_RCF_RATE_IN      => arr_LINE_RCF_RATE_IN    ,--: in std_logic_array8(CPRI_NUM-1 downto 0);
        LINE_RCF_CLKTYPE_IN   => arr_LINE_RCF_CLKTYPE_IN ,--: in std_logic_array8(CPRI_NUM-1 downto 0);
        LINE_RCF_WIDTH_IN     => arr_LINE_RCF_WIDTH_IN   ,--: in std_logic_array8(CPRI_NUM-1 downto 0);

        CPRI_RX_VLD_IN => CPRI_RX_VLD_IN,-- std_logic_vector(CPRI_NUM-1 downto 0);
        CPRI_RX_I_IN   => arr_CPRI_RX_I_IN ,-- in std_logic_array16(CPRI_NUM-1 downto 0);
        CPRI_RX_Q_IN   => arr_CPRI_RX_Q_IN ,-- in std_logic_array16(CPRI_NUM-1 downto 0);

        CPRI_TX_ENB_IN => CPRI_TX_ENB_IN,--  std_logic_vector(CPRI_NUM-1 downto 0);
        CPRI_TX_I_OUT  => arr_CPRI_TX_I_OUT ,--out std_logic_array16(CPRI_NUM-1 downto 0);
        CPRI_TX_Q_OUT  => arr_CPRI_TX_Q_OUT ,--out std_logic_array16(CPRI_NUM-1 downto 0);

        --------------------------------------------------------------------------------
        -- DSP_TOP
        --------------------------------------------------------------------------------

        DL_BFN_OK => DL_BFN_OK,-- std_logic;

        DL_AIRTECH_OUT  => arr_DL_AIRTECH_OUT ,-- std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
        DL_CHBW_OUT     => arr_DL_CHBW_OUT    ,-- std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
        DL_TDD_OUT      => DL_TDD_OUT      ,--out std_logic;
        DL_40MS_OUT     => DL_40MS_OUT     ,--out std_logic;
        DL_SSB_OUT      => DL_SSB_OUT      ,--out std_logic;
        DL_BFN_STRB_OUT => DL_BFN_STRB_OUT ,--out std_logic;
        DL_BFN_OUT      => DL_BFN_OUT      ,--out std_logic_vector(11 downto 0);
        DL_SYNC_OUT     => DL_SYNC_OUT     ,--out std_logic_vector(DL_BBIQARY_NUM-1 downto 0);
        DL_IQ_OUT       => arr_DL_IQ_OUT,-- std_logic_array16(DL_BBIQARY_NUM-1 downto 0);

        UL_AIRTECH_OUT => arr_UL_AIRTECH_OUT ,--std_logic_array4(UL_BBIQARY_NUM-1 downto 0);
        UL_CHBW_OUT    => arr_UL_CHBW_OUT    ,--std_logic_array4(UL_BBIQARY_NUM-1 downto 0);
        UL_TDD_IN      => UL_TDD_IN      ,--std_logic;
        UL_BFN_STRB_IN => UL_BFN_STRB_IN ,--std_logic;
        UL_SYNC_IN     => UL_SYNC_IN     ,--std_logic_vector(UL_BBIQARY_NUM-1 downto 0);
        UL_IQ_IN       => arr_UL_IQ_IN,--  std_logic_array16(UL_BBIQARY_NUM-1 downto 0);

        --------------------------------------------------------------------------------
        -- DBG_SIG_OUT
        --------------------------------------------------------------------------------

        DBG_SIG_OUT => arr_DBG_SIG_OUT,-- std_logic_array32(1 downto 0);

        --------------------------------------------------------------------------------
        -- MISC_TOP
        --------------------------------------------------------------------------------

        DUMP_BFN_STRB_OUT => DUMP_BFN_STRB_OUT,-- std_logic_vector(1 downto 0);
        DUMP_DATA_OUT     => arr_DUMP_DATA_OUT,-- std_logic_array32(1 downto 0);
        DUMP_DVLD_OUT     => DUMP_DVLD_OUT,-- std_logic_vector(1 downto 0);
        TEST_DATA_IN      => arr_TEST_DATA_IN,--  std_logic_array32(1 downto 0);
        TEST_ENB_OUT      => TEST_ENB_OUT,-- std_logic_vector(1 downto 0);

        SIG_SUS_DLOFF_IN => SIG_SUS_DLOFF_IN ,--std_logic_vector(CPRI_NUM-1 downto 0);
        SIG_SUS_FLAG_OUT => SIG_SUS_FLAG_OUT ,--std_logic_vector(DL_BBIQARY_NUM-1 downto 0);

    -- fb_sw_new
        FBSW_CNT           => FBSW_CNT          ,--std_logic_vector(3 downto 0);
        FBSW_SSB_IND_FLAG  => FBSW_SSB_IND_FLAG ,--std_logic; 
        FBSW_MEAS_UPDATE   => FBSW_MEAS_UPDATE  ,--std_logic; 

        FBSW_START_TRIG_IN     => FBSW_START_TRIG_IN     ,--std_logic;
        FBSW_CNT_IN            => FBSW_CNT_IN            ,--std_logic_vector(6 downto 0);
        FBSW_AUTO_MODE_DONE_IN => FBSW_AUTO_MODE_DONE_IN ,--std_logic_vector(FB_PATH_NUM-1 downto 0);
        FBSW_PWR_MSR_UDT_IN    => FBSW_PWR_MSR_UDT_IN    ,--std_logic;
        FBSW_MANUAL_MODE_IN    => FBSW_MANUAL_MODE_IN    ,--std_logic;

        PWR_UPT_TICK_IN 	   => PWR_UPT_TICK_IN,-- std_logic_vector(FB_PATH_NUM-1 downto 0);
        FBSW_PATH_IN    => arr_FBSW_PATH_IN,-- std_logic_array3(FB_PATH_NUM-1 downto 0);

        SSB_EXIST_IN => SSB_EXIST_IN-- in std_logic

	);
 
 
end BEHAVE;
