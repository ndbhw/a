--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2018, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : SBIF Top (Master FPGA)                                        --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2018.04.24                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;
use WORK.RU_FPGA_CONFIG.ALL;

entity SBIF_M_TOP_vhd is
    generic (
        BASE_ADDR                   : std_logic_vector(19 downto 0)           := x"0E000";
        PORT_NUM                    : natural := 16
    );
    port (
--------------------------------------------------------------------------------
-- External System PLL
--------------------------------------------------------------------------------

        EXT_SYSPLL_LOCK_IN          : in  std_logic;

--------------------------------------------------------------------------------
-- DSP FPGA
--------------------------------------------------------------------------------

        FRAME_SYNC_10ms             : out std_logic_vector(1 downto 0);
        FRAME_SYNC_1sec             : out std_logic_vector(1 downto 0);

--------------------------------------------------------------------------------
-- SYSCTRL_TOP
--------------------------------------------------------------------------------

        RST_SBIF                    : in  std_logic_vector(PORT_NUM-1 downto 0);
        CLK_SYS                     : in  std_logic;
        CLK_SYSX2                   : in  std_logic;
        CLK_SYSX3                   : in  std_logic;
        CLK_SYSX4                   : in  std_logic;
        CLK_SYSX5                   : in  std_logic;
        CLK_SYSX6                   : in  std_logic;
        CLK_SYSX8                   : in  std_logic;
        CLK_SYSX10                  : in  std_logic;
        CLK_SYSX12                  : in  std_logic;
        CLK_SYSX16                  : in  std_logic;
        CLK_SYSX20                  : in  std_logic;

        TX_BFN_STRB_IN              : in  std_logic;
        TX_BFN_NR_IN                : in  std_logic_vector(11 downto 0);
        RX_BFN_STRB_OUT             : out std_logic_vector(PORT_NUM-1 downto 0);
        RX_BFN_NR_OUT               : out std_logic_vector(12*PORT_NUM-1 downto 0);

--------------------------------------------------------------------------------
-- CPU_TOP
--------------------------------------------------------------------------------

        RST_CPUIF                   : in  std_logic;
        CLK_CPUIF                   : in  std_logic;

--------------------------------------------------------------------------------
-- CPUIF_TOP
--------------------------------------------------------------------------------

        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        RDVAL_CPUIF_OUT             : out std_logic;

--------------------------------------------------------------------------------
-- User fabrics
--------------------------------------------------------------------------------

        RX_USER_SYNC0_OUT           : out std_logic_vector(PORT_NUM-1 downto 0);
        RX_USER_SYNC1_OUT           : out std_logic_vector(PORT_NUM-1 downto 0);
        RX_10MS_OUT                 : out std_logic_vector(PORT_NUM-1 downto 0);
        RX_VLD_OUT                  : out std_logic_vector(PORT_NUM-1 downto 0);
        RX_I_OUT                    : out std_logic_vector(16*PORT_NUM-1 downto 0);
        RX_Q_OUT                    : out std_logic_vector(16*PORT_NUM-1 downto 0);

        TX_USER_SYNC0_IN            : in  std_logic_vector(PORT_NUM-1 downto 0);
        TX_USER_SYNC1_IN            : in  std_logic_vector(PORT_NUM-1 downto 0);
        TX_10MS_IN                  : in  std_logic_vector(PORT_NUM-1 downto 0);
        TX_ENB_IN                   : in  std_logic_vector(PORT_NUM-1 downto 0);
        TX_I_IN                     : in  std_logic_vector(16*PORT_NUM-1 downto 0);
        TX_Q_IN                     : in  std_logic_vector(16*PORT_NUM-1 downto 0);

--------------------------------------------------------------------------------
-- DBG_SIG_OUT
--------------------------------------------------------------------------------

        DBG_SIG_OUT                 : out std_logic_vector(32*2-1 downto 0);

--------------------------------------------------------------------------------
-- MISC_TOP
--------------------------------------------------------------------------------

        DUMP_BFN_STRB_OUT           : out std_logic_vector(1 downto 0);
        DUMP_DATA_OUT               : out std_logic_vector(32*2-1 downto 0);
        DUMP_DVLD_OUT               : out std_logic_vector(1 downto 0);
        TEST_DATA_IN                : in  std_logic_vector(32*2-1 downto 0);
        TEST_ENB_OUT                : out std_logic_vector(1 downto 0);

        SIG_SUS_FLAG_OUT            : out std_logic_vector(PORT_NUM-1 downto 0);
        SIG_SUS_DLOFF_IN            : in  std_logic_vector(PORT_NUM-1 downto 0);

--------------------------------------------------------------------------------
-- SBIFPHY_TOP
--------------------------------------------------------------------------------

        SERDES_RXCOMMA_REALIGN_OUT  : out std_logic_vector(PORT_NUM-1 downto 0);
        SERDES_RXERR_IN             : in  std_logic_vector(8*PORT_NUM-1 downto 0);
        SERDES_RXISK_IN             : in  std_logic_vector(8*PORT_NUM-1 downto 0);
        SERDES_RXD_IN               : in  std_logic_vector(64*PORT_NUM-1 downto 0);
        SERDES_TXISK_OUT            : out std_logic_vector(8*PORT_NUM-1 downto 0);
        SERDES_TXD_OUT              : out std_logic_vector(64*PORT_NUM-1 downto 0)
    );
end SBIF_M_TOP_vhd;

architecture BEHAVE of SBIF_M_TOP_vhd is

signal arr_TX_I_IN            :   std_logic_array16(PORT_NUM-1 downto 0);   -- in
signal arr_TX_Q_IN            :   std_logic_array16(PORT_NUM-1 downto 0);	-- in	
signal arr_SERDES_RXERR_IN    :   std_logic_array8(PORT_NUM-1 downto 0);    -- in
signal arr_SERDES_RXISK_IN    :   std_logic_array8(PORT_NUM-1 downto 0);    -- in
signal arr_SERDES_RXD_IN      :   std_logic_array64(PORT_NUM-1 downto 0);   -- in

signal arr_RX_BFN_NR_OUT      :  std_logic_array12(PORT_NUM-1 downto 0);   -- out
signal arr_RX_I_OUT           :  std_logic_array16(PORT_NUM-1 downto 0);   -- out
signal arr_RX_Q_OUT           :  std_logic_array16(PORT_NUM-1 downto 0);   -- out
signal arr_SERDES_TXISK_OUT   :  std_logic_array8(PORT_NUM-1 downto 0);    -- out
signal arr_SERDES_TXD_OUT     :  std_logic_array64(PORT_NUM-1 downto 0);   -- out
																		 
signal arr_TEST_DATA_IN       :  std_logic_array32(1 downto 0);          -- in 

signal arr_DBG_SIG_OUT        :  std_logic_array32(1 downto 0);          -- out
signal arr_DUMP_DATA_OUT      :  std_logic_array32(1 downto 0);          -- out

begin

gen_vhd_to_v : if TRUE generate
    gen_1: for i in 0 to PORT_NUM-1 generate
    begin
    
        -- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
       
        arr_TX_I_IN         (i) <= TX_I_IN         (16*i+15 downto 16*i);
        arr_TX_Q_IN         (i) <= TX_Q_IN         (16*i+15 downto 16*i);
        arr_SERDES_RXERR_IN (i) <= SERDES_RXERR_IN (8*i+7 downto 8*i);
        arr_SERDES_RXISK_IN (i) <= SERDES_RXISK_IN (8*i+7 downto 8*i);
        arr_SERDES_RXD_IN   (i) <= SERDES_RXD_IN   (64*i+63 downto 64*i);
        
        -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
        
        RX_BFN_NR_OUT     (12*i+11 downto 12*i) <= arr_RX_BFN_NR_OUT   (i);
        RX_I_OUT          (16*i+15 downto 16*i) <= arr_RX_I_OUT        (i);
        RX_Q_OUT          (16*i+15 downto 16*i) <= arr_RX_Q_OUT        (i);
        SERDES_TXISK_OUT  (8*i+7 downto 8*i)    <= arr_SERDES_TXISK_OUT(i);
        SERDES_TXD_OUT    (64*i+63 downto 64*i) <= arr_SERDES_TXD_OUT  (i);
    
    end generate;
    
    
    gen_2: for i in 0 to 2-1 generate
    begin
    
        -- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
        arr_TEST_DATA_IN (i) <= TEST_DATA_IN (32*i+31 downto 32*i);
        
        -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
        DBG_SIG_OUT    (32*i+31 downto 32*i) <= arr_DBG_SIG_OUT  (i);
        DUMP_DATA_OUT  (32*i+31 downto 32*i) <= arr_DUMP_DATA_OUT(i);
        
    end generate;
    
end generate;
    
    SBIF_TOP : entity work.SBIF_M_TOP
    generic map(
        BASE_ADDR   => BASE_ADDR,
        PORT_NUM    => PORT_NUM

    )
    port map(
    

--------------------------------------------------------------------------------
-- External System PLL
--------------------------------------------------------------------------------

        EXT_SYSPLL_LOCK_IN          => EXT_SYSPLL_LOCK_IN ,

--------------------------------------------------------------------------------
-- DSP FPGA
--------------------------------------------------------------------------------

        FRAME_SYNC_10ms             => FRAME_SYNC_10ms ,
        FRAME_SYNC_1sec             => FRAME_SYNC_1sec ,

--------------------------------------------------------------------------------
-- SYSCTRL_TOP
--------------------------------------------------------------------------------

        RST_SBIF                    => RST_SBIF        ,
        CLK_SYS                     => CLK_SYS         ,
        CLK_SYSX2                   => CLK_SYSX2       ,
        CLK_SYSX3                   => CLK_SYSX3       ,
        CLK_SYSX4                   => CLK_SYSX4       ,
        CLK_SYSX5                   => CLK_SYSX5       ,
        CLK_SYSX6                   => CLK_SYSX6       ,
        CLK_SYSX8                   => CLK_SYSX8       ,
        CLK_SYSX10                  => CLK_SYSX10      ,
        CLK_SYSX12                  => CLK_SYSX12      ,
        CLK_SYSX16                  => CLK_SYSX16      ,
        CLK_SYSX20                  => CLK_SYSX20      ,
 
        TX_BFN_STRB_IN              => TX_BFN_STRB_IN  ,
        TX_BFN_NR_IN                => TX_BFN_NR_IN    ,
        RX_BFN_STRB_OUT             => RX_BFN_STRB_OUT ,
        RX_BFN_NR_OUT               => arr_RX_BFN_NR_OUT ,

--------------------------------------------------------------------------------
-- CPU_TOP
--------------------------------------------------------------------------------

        RST_CPUIF                   => RST_CPUIF  ,
        CLK_CPUIF                   => CLK_CPUIF  ,

--------------------------------------------------------------------------------
-- CPUIF_TOP
--------------------------------------------------------------------------------

        ADDR_CPUIF_IN               => ADDR_CPUIF_IN  ,
        WDATA_CPUIF_IN              => WDATA_CPUIF_IN ,
        RDATA_CPUIF_OUT             => RDATA_CPUIF_OUT,
        WREN_CPUIF_IN               => WREN_CPUIF_IN  ,
        RDEN_CPUIF_IN               => RDEN_CPUIF_IN  ,
        RDVAL_CPUIF_OUT             => RDVAL_CPUIF_OUT,

--------------------------------------------------------------------------------
-- User fabrics
--------------------------------------------------------------------------------

        RX_USER_SYNC0_OUT           => RX_USER_SYNC0_OUT ,
        RX_USER_SYNC1_OUT           => RX_USER_SYNC1_OUT ,
        RX_10MS_OUT                 => RX_10MS_OUT       ,
        RX_VLD_OUT                  => RX_VLD_OUT        ,
        RX_I_OUT                    => arr_RX_I_OUT	,
        RX_Q_OUT                    => arr_RX_Q_OUT	,

        TX_USER_SYNC0_IN            => TX_USER_SYNC0_IN  ,
        TX_USER_SYNC1_IN            => TX_USER_SYNC1_IN  ,
        TX_10MS_IN                  => TX_10MS_IN        ,
        TX_ENB_IN                   => TX_ENB_IN         ,
        TX_I_IN                     => arr_TX_I_IN ,
        TX_Q_IN                     => arr_TX_Q_IN ,

--------------------------------------------------------------------------------
-- DBG_SIG_OUT
--------------------------------------------------------------------------------

        DBG_SIG_OUT                 => arr_DBG_SIG_OUT ,

--------------------------------------------------------------------------------
-- MISC_TOP
--------------------------------------------------------------------------------

        DUMP_BFN_STRB_OUT           => DUMP_BFN_STRB_OUT ,
        DUMP_DATA_OUT               => arr_DUMP_DATA_OUT ,
        DUMP_DVLD_OUT               => DUMP_DVLD_OUT ,
        TEST_DATA_IN                => arr_TEST_DATA_IN ,
        TEST_ENB_OUT                => TEST_ENB_OUT ,

        SIG_SUS_FLAG_OUT            => SIG_SUS_FLAG_OUT ,
        SIG_SUS_DLOFF_IN            => SIG_SUS_DLOFF_IN ,

--------------------------------------------------------------------------------
-- SBIFPHY_TOP
--------------------------------------------------------------------------------

        SERDES_RXCOMMA_REALIGN_OUT  => SERDES_RXCOMMA_REALIGN_OUT ,
        SERDES_RXERR_IN             => arr_SERDES_RXERR_IN ,
        SERDES_RXISK_IN             => arr_SERDES_RXISK_IN ,
        SERDES_RXD_IN               => arr_SERDES_RXD_IN   ,
        SERDES_TXISK_OUT            => arr_SERDES_TXISK_OUT,
        SERDES_TXD_OUT              => arr_SERDES_TXD_OUT  

    );

end BEHAVE;