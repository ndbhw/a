
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;
use WORK.RU_FPGA_CONFIG.ALL;

entity DCIF_TOP_vhd is
    port (
 
        -- Clock
        RST_DCIF                : in std_logic;
        CLK_SYSX8               : in std_logic; -- 245.76 MHz
        CLK_SYSX4               : in std_logic; -- 122.88 MHz

        REFCLK_SERDES_IN        : in std_logic;

        --CPU Interface
        RST_CPUIF               : in  std_logic;
        CLK_CPUIF               : in  std_logic;
        ADDR_CPUIF_IN           : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN          : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT         : out std_logic_vector(31 downto 0);
        WREN_CPUIF_IN           : in  std_logic;
        RDEN_CPUIF_IN           : in  std_logic;
        RDVAL_CPUIF_OUT         : out std_logic;
        ------------------------------------------------------------------------------------------
        -- RFIC Interface
        ------------------------------------------------------------------------------------------
        JESD_SYSREF_IN          : in  std_logic; -- JESD SYSREF Input
        JESD_SERIAL_TX_OUT_P    : out std_logic_vector(3 downto 0);
        JESD_SERIAL_TX_OUT_N    : out std_logic_vector(3 downto 0);
        JESD_SERIAL_RX_IN_P     : in  std_logic_vector(3 downto 0);
        JESD_SERIAL_RX_IN_N     : in  std_logic_vector(3 downto 0);
        JESD_SERIAL_FB_IN_P     : in  std_logic_vector(3 downto 0);
        JESD_SERIAL_FB_IN_N     : in  std_logic_vector(3 downto 0);
        ------------------------------------------------------------------------------------------
        -- JESD IP AXI Interface
        ------------------------------------------------------------------------------------------
        JESD204C_AXI_ACLK       : in  std_logic;
        JESD204C_AXI_ARESETN    : in  std_logic;
        JESD204C_AXI_AWADDR     : in  std_logic_vector ( 31 downto 0 );
        JESD204C_AXI_AWLEN      : in  std_logic_vector ( 7 downto 0 );
        JESD204C_AXI_AWSIZE     : in  std_logic_vector ( 2 downto 0 );
        JESD204C_AXI_AWBURST    : in  std_logic_vector ( 1 downto 0 );
        JESD204C_AXI_AWLOCK     : in  std_logic_vector ( 0 downto 0 );
        JESD204C_AXI_AWCACHE    : in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_AWPROT     : in  std_logic_vector ( 2 downto 0 );
        JESD204C_AXI_AWREGION   : in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_AWQOS      : in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_AWVALID    : in  std_logic;
        JESD204C_AXI_AWREADY    : out std_logic;
        JESD204C_AXI_WDATA      : in  std_logic_vector ( 31 downto 0 );
        JESD204C_AXI_WSTRB      : in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_WLAST      : in  std_logic;
        JESD204C_AXI_WVALID     : in  std_logic;
        JESD204C_AXI_WREADY     : out std_logic;
        JESD204C_AXI_BRESP      : out std_logic_vector ( 1 downto 0 );
        JESD204C_AXI_BVALID     : out std_logic;
        JESD204C_AXI_BREADY     : in  std_logic;
        JESD204C_AXI_ARADDR     : in  std_logic_vector ( 31 downto 0 );
        JESD204C_AXI_ARLEN      : in  std_logic_vector ( 7 downto 0 );
        JESD204C_AXI_ARSIZE     : in  std_logic_vector ( 2 downto 0 );
        JESD204C_AXI_ARBURST    : in  std_logic_vector ( 1 downto 0 );
        JESD204C_AXI_ARLOCK     : in  std_logic_vector ( 0 downto 0 );
        JESD204C_AXI_ARCACHE    : in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_ARPROT     : in  std_logic_vector ( 2 downto 0 );
        JESD204C_AXI_ARREGION   : in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_ARQOS      : in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_ARVALID    : in  std_logic;
        JESD204C_AXI_ARREADY    : out std_logic;
        JESD204C_AXI_RDATA      : out std_logic_vector ( 31 downto 0 );
        JESD204C_AXI_RRESP      : out std_logic_vector ( 1 downto 0 );
        JESD204C_AXI_RLAST      : out std_logic;
        JESD204C_AXI_RVALID     : out std_logic;
        JESD204C_AXI_RREADY     : in  std_logic;
        ------------------------------------------------------------------------------------------
        -- SYNC
        ------------------------------------------------------------------------------------------
        DL_BFN_STRB_IN          : in  std_logic;
        UL_BFN_STRB_IN          : in  std_logic;
        SSB_STRB_IN             : in  std_logic;
        DL_BFN_STRB_OUT         : out std_logic;
        UL_BFN_STRB_OUT         : out std_logic;
        SSB_STRB_OUT            : out std_logic;     
        ------------------------------------------------------------------------------------------
        -- DUMP Interface
        ------------------------------------------------------------------------------------------
        DUMP_BFN_STRB_OUT       : out std_logic;                                 
        DUMP_DVLD_OUT           : out std_logic; -- Dump valid                   
        DUMP_DATA_OUT           : out std_logic_vector(31 downto 0); -- Dump data        
        ------------------------------------------------------------------------------------------
        -- DATA PATH IF
        ------------------------------------------------------------------------------------------
        PULSED_CW_10ms_IN       : in std_logic;
        ------------------------------------------------------------------------
        -- For test
        ------------------------------------------------------------------------
        O_DL_JESD_TREADY        : out std_logic;
        O_UL_JESD_TVALID        : out std_logic;
        ------------------------------------------------------------------------
        -- CC Interface
        ------------------------------------------------------------------------
        --DL data
        DL_I_IN                 : in std_logic_vector((TX_ANT_NUM*16-1) downto 0);
        DL_Q_IN                 : in std_logic_vector((TX_ANT_NUM*16-1) downto 0);
        --UL data               
        UL_I_OUT                : out std_logic_vector((RX_ANT_NUM*16-1) downto 0);
        UL_Q_OUT                : out std_logic_vector((RX_ANT_NUM*16-1) downto 0);
        --FB data                        
        FB_I_EVEN_OUT           : out std_logic_vector(FB_PATH_NUM*16-1 downto 0);
        FB_Q_EVEN_OUT           : out std_logic_vector(FB_PATH_NUM*16-1 downto 0);
        FB_I_ODD_OUT            : out std_logic_vector(FB_PATH_NUM*16-1 downto 0);
        FB_Q_ODD_OUT            : out std_logic_vector(FB_PATH_NUM*16-1 downto 0)
 
    );
end DCIF_TOP_vhd;

architecture BEHAVE of DCIF_TOP_vhd is

component DCIF_TOP is
    port (
	
        -- Clock
        RST_DCIF                : in std_logic;
        CLK_SYSX8               : in std_logic; -- 245.76 MHz
        CLK_SYSX4               : in std_logic; -- 122.88 MHz

        REFCLK_SERDES_IN        : in std_logic;

        --CPU Interface
        RST_CPUIF               : in  std_logic;
        CLK_CPUIF               : in  std_logic;
        ADDR_CPUIF_IN           : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN          : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT         : out std_logic_vector(31 downto 0);
        WREN_CPUIF_IN           : in  std_logic;
        RDEN_CPUIF_IN           : in  std_logic;
        RDVAL_CPUIF_OUT         : out std_logic;
        ------------------------------------------------------------------------------------------
        -- RFIC Interface
        ------------------------------------------------------------------------------------------
        JESD_SYSREF_IN          : in  std_logic; -- JESD SYSREF Input
        JESD_SERIAL_TX_OUT_P    : out std_logic_vector(3 downto 0);
        JESD_SERIAL_TX_OUT_N    : out std_logic_vector(3 downto 0);
        JESD_SERIAL_RX_IN_P     : in  std_logic_vector(3 downto 0);
        JESD_SERIAL_RX_IN_N     : in  std_logic_vector(3 downto 0);
        JESD_SERIAL_FB_IN_P     : in  std_logic_vector(3 downto 0);
        JESD_SERIAL_FB_IN_N     : in  std_logic_vector(3 downto 0);
        ------------------------------------------------------------------------------------------
        -- JESD IP AXI Interface
        ------------------------------------------------------------------------------------------
        JESD204C_AXI_ACLK       : in  std_logic;
        JESD204C_AXI_ARESETN    : in  std_logic;
        JESD204C_AXI_AWADDR     : in  std_logic_vector ( 31 downto 0 );
        JESD204C_AXI_AWLEN      : in  std_logic_vector ( 7 downto 0 );
        JESD204C_AXI_AWSIZE     : in  std_logic_vector ( 2 downto 0 );
        JESD204C_AXI_AWBURST    : in  std_logic_vector ( 1 downto 0 );
        JESD204C_AXI_AWLOCK     : in  std_logic_vector ( 0 downto 0 );
        JESD204C_AXI_AWCACHE    : in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_AWPROT     : in  std_logic_vector ( 2 downto 0 );
        JESD204C_AXI_AWREGION   : in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_AWQOS      : in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_AWVALID    : in  std_logic;
        JESD204C_AXI_AWREADY    : out std_logic;
        JESD204C_AXI_WDATA      : in  std_logic_vector ( 31 downto 0 );
        JESD204C_AXI_WSTRB      : in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_WLAST      : in  std_logic;
        JESD204C_AXI_WVALID     : in  std_logic;
        JESD204C_AXI_WREADY     : out std_logic;
        JESD204C_AXI_BRESP      : out std_logic_vector ( 1 downto 0 );
        JESD204C_AXI_BVALID     : out std_logic;
        JESD204C_AXI_BREADY     : in  std_logic;
        JESD204C_AXI_ARADDR     : in  std_logic_vector ( 31 downto 0 );
        JESD204C_AXI_ARLEN      : in  std_logic_vector ( 7 downto 0 );
        JESD204C_AXI_ARSIZE     : in  std_logic_vector ( 2 downto 0 );
        JESD204C_AXI_ARBURST    : in  std_logic_vector ( 1 downto 0 );
        JESD204C_AXI_ARLOCK     : in  std_logic_vector ( 0 downto 0 );
        JESD204C_AXI_ARCACHE    : in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_ARPROT     : in  std_logic_vector ( 2 downto 0 );
        JESD204C_AXI_ARREGION   : in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_ARQOS      : in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_ARVALID    : in  std_logic;
        JESD204C_AXI_ARREADY    : out std_logic;
        JESD204C_AXI_RDATA      : out std_logic_vector ( 31 downto 0 );
        JESD204C_AXI_RRESP      : out std_logic_vector ( 1 downto 0 );
        JESD204C_AXI_RLAST      : out std_logic;
        JESD204C_AXI_RVALID     : out std_logic;
        JESD204C_AXI_RREADY     : in  std_logic;
        ------------------------------------------------------------------------------------------
        -- SYNC
        ------------------------------------------------------------------------------------------
        DL_BFN_STRB_IN          : in  std_logic;
        UL_BFN_STRB_IN          : in  std_logic;
        SSB_STRB_IN             : in  std_logic;
        DL_BFN_STRB_OUT         : out std_logic;
        UL_BFN_STRB_OUT         : out std_logic;
        SSB_STRB_OUT            : out std_logic;     
        ------------------------------------------------------------------------------------------
        -- DUMP Interface
        ------------------------------------------------------------------------------------------
        DUMP_BFN_STRB_OUT       : out std_logic;                                 
        DUMP_DVLD_OUT           : out std_logic; -- Dump valid                   
        DUMP_DATA_OUT           : out std_logic_vector(31 downto 0); -- Dump data        
        ------------------------------------------------------------------------------------------
        -- DATA PATH IF
        ------------------------------------------------------------------------------------------
        PULSED_CW_10ms_IN       : in std_logic;
        ------------------------------------------------------------------------
        -- For test
        ------------------------------------------------------------------------
        O_DL_JESD_TREADY        : out std_logic;
        O_UL_JESD_TVALID        : out std_logic;
        ------------------------------------------------------------------------
        -- CC Interface
        ------------------------------------------------------------------------
        --DL data
        DL_I_IN                 : in std_logic_array16((TX_ANT_NUM-1) downto 0);
        DL_Q_IN                 : in std_logic_array16((TX_ANT_NUM-1) downto 0);
        --UL data               
        UL_I_OUT                : out std_logic_array16((RX_ANT_NUM-1) downto 0);
        UL_Q_OUT                : out std_logic_array16((RX_ANT_NUM-1) downto 0);
        --FB data                        
        FB_I_EVEN_OUT           : out std_logic_array16(FB_PATH_NUM-1 downto 0);
        FB_Q_EVEN_OUT           : out std_logic_array16(FB_PATH_NUM-1 downto 0);
        FB_I_ODD_OUT            : out std_logic_array16(FB_PATH_NUM-1 downto 0);
        FB_Q_ODD_OUT            : out std_logic_array16(FB_PATH_NUM-1 downto 0)
 
    );
end component;


signal arr_DL_I_IN        : std_logic_array16((TX_ANT_NUM-1) downto 0);
signal arr_DL_Q_IN        : std_logic_array16((TX_ANT_NUM-1) downto 0);
signal arr_UL_I_OUT       : std_logic_array16((RX_ANT_NUM-1) downto 0);
signal arr_UL_Q_OUT       : std_logic_array16((RX_ANT_NUM-1) downto 0);

signal arr_FB_I_EVEN_OUT  : std_logic_array16(FB_PATH_NUM-1 downto 0);
signal arr_FB_Q_EVEN_OUT  : std_logic_array16(FB_PATH_NUM-1 downto 0);
signal arr_FB_I_ODD_OUT   : std_logic_array16(FB_PATH_NUM-1 downto 0);
signal arr_FB_Q_ODD_OUT   : std_logic_array16(FB_PATH_NUM-1 downto 0);
 
	
begin

--arr_RX_BFN_NR_IN(0)	<=	RX_BFN_NR_IN(11 downto 0);
--CPRI_TX_Q_OUT (15 downto 0)<= arr_CPRI_TX_I_OUT(0);

gen_1: for i in 0 to 3 generate
begin
--arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
--O_UL_DATA_Q(16*i+15 downto 16*i) <=	arr_O_UL_DATA_Q(i);

arr_DL_I_IN  (i)  <= DL_I_IN  (16*i+15 downto 16*i); 
arr_DL_Q_IN  (i)  <= DL_Q_IN  (16*i+15 downto 16*i); 
UL_I_OUT (16*i+15 downto 16*i)  <= arr_UL_I_OUT (i); 
UL_Q_OUT (16*i+15 downto 16*i)  <= arr_UL_Q_OUT (i); 

end generate;


gen_2: for i in 0 to FB_PATH_NUM-1 generate
begin
FB_I_EVEN_OUT(16*i+15 downto 16*i) <=  arr_FB_I_EVEN_OUT (i);
FB_Q_EVEN_OUT(16*i+15 downto 16*i) <=  arr_FB_Q_EVEN_OUT (i);
FB_I_ODD_OUT (16*i+15 downto 16*i) <=  arr_FB_I_ODD_OUT  (i);
FB_Q_ODD_OUT (16*i+15 downto 16*i) <=  arr_FB_Q_ODD_OUT  (i);

end generate;

 u_DCIF_TOP: DCIF_TOP
	port map(
 
        -- Clock
        RST_DCIF                => RST_DCIF      ,-- in std_logic;
        CLK_SYSX8               => CLK_SYSX8     ,-- in std_logic; -- 245.76 MHz
        CLK_SYSX4               => CLK_SYSX4     ,-- in std_logic; -- 122.88 MHz

        REFCLK_SERDES_IN        => REFCLK_SERDES_IN     ,-- in std_logic;

        --CPU Interface
        RST_CPUIF               => RST_CPUIF           ,-- in  std_logic;
        CLK_CPUIF               => CLK_CPUIF           ,-- in  std_logic;
        ADDR_CPUIF_IN           => ADDR_CPUIF_IN       ,-- in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN          => WDATA_CPUIF_IN      ,-- in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT         => RDATA_CPUIF_OUT     ,-- out std_logic_vector(31 downto 0);
        WREN_CPUIF_IN           => WREN_CPUIF_IN       ,-- in  std_logic;
        RDEN_CPUIF_IN           => RDEN_CPUIF_IN       ,-- in  std_logic;
        RDVAL_CPUIF_OUT         => RDVAL_CPUIF_OUT     ,-- out std_logic;
        ------------------------------------------------------------------------------------------
        -- RFIC Interface
        ------------------------------------------------------------------------------------------
        JESD_SYSREF_IN          => JESD_SYSREF_IN           ,-- in  std_logic; -- JESD SYSREF Input
        JESD_SERIAL_TX_OUT_P    => JESD_SERIAL_TX_OUT_P     ,-- out std_logic_vector(3 downto 0);
        JESD_SERIAL_TX_OUT_N    => JESD_SERIAL_TX_OUT_N     ,-- out std_logic_vector(3 downto 0);
        JESD_SERIAL_RX_IN_P     => JESD_SERIAL_RX_IN_P      ,-- in  std_logic_vector(3 downto 0);
        JESD_SERIAL_RX_IN_N     => JESD_SERIAL_RX_IN_N      ,-- in  std_logic_vector(3 downto 0);
        JESD_SERIAL_FB_IN_P     => JESD_SERIAL_FB_IN_P      ,-- in  std_logic_vector(3 downto 0);
        JESD_SERIAL_FB_IN_N     => JESD_SERIAL_FB_IN_N      ,-- in  std_logic_vector(3 downto 0);
        ------------------------------------------------------------------------------------------
        -- JESD IP AXI Interface
        ------------------------------------------------------------------------------------------
        JESD204C_AXI_ACLK       => JESD204C_AXI_ACLK        ,-- in  std_logic;
        JESD204C_AXI_ARESETN    => JESD204C_AXI_ARESETN     ,-- in  std_logic;
        JESD204C_AXI_AWADDR     => JESD204C_AXI_AWADDR      ,-- in  std_logic_vector ( 31 downto 0 );
        JESD204C_AXI_AWLEN      => JESD204C_AXI_AWLEN       ,-- in  std_logic_vector ( 7 downto 0 );
        JESD204C_AXI_AWSIZE     => JESD204C_AXI_AWSIZE      ,-- in  std_logic_vector ( 2 downto 0 );
        JESD204C_AXI_AWBURST    => JESD204C_AXI_AWBURST     ,-- in  std_logic_vector ( 1 downto 0 );
        JESD204C_AXI_AWLOCK     => JESD204C_AXI_AWLOCK      ,-- in  std_logic_vector ( 0 downto 0 );
        JESD204C_AXI_AWCACHE    => JESD204C_AXI_AWCACHE     ,-- in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_AWPROT     => JESD204C_AXI_AWPROT      ,-- in  std_logic_vector ( 2 downto 0 );
        JESD204C_AXI_AWREGION   => JESD204C_AXI_AWREGION    ,-- in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_AWQOS      => JESD204C_AXI_AWQOS       ,-- in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_AWVALID    => JESD204C_AXI_AWVALID     ,-- in  std_logic;
        JESD204C_AXI_AWREADY    => JESD204C_AXI_AWREADY     ,-- out std_logic;
        JESD204C_AXI_WDATA      => JESD204C_AXI_WDATA       ,-- in  std_logic_vector ( 31 downto 0 );
        JESD204C_AXI_WSTRB      => JESD204C_AXI_WSTRB       ,-- in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_WLAST      => JESD204C_AXI_WLAST       ,-- in  std_logic;
        JESD204C_AXI_WVALID     => JESD204C_AXI_WVALID      ,-- in  std_logic;
        JESD204C_AXI_WREADY     => JESD204C_AXI_WREADY      ,-- out std_logic;
        JESD204C_AXI_BRESP      => JESD204C_AXI_BRESP       ,-- out std_logic_vector ( 1 downto 0 );
        JESD204C_AXI_BVALID     => JESD204C_AXI_BVALID      ,-- out std_logic;
        JESD204C_AXI_BREADY     => JESD204C_AXI_BREADY      ,-- in  std_logic;
        JESD204C_AXI_ARADDR     => JESD204C_AXI_ARADDR      ,-- in  std_logic_vector ( 31 downto 0 );
        JESD204C_AXI_ARLEN      => JESD204C_AXI_ARLEN       ,-- in  std_logic_vector ( 7 downto 0 );
        JESD204C_AXI_ARSIZE     => JESD204C_AXI_ARSIZE      ,-- in  std_logic_vector ( 2 downto 0 );
        JESD204C_AXI_ARBURST    => JESD204C_AXI_ARBURST     ,-- in  std_logic_vector ( 1 downto 0 );
        JESD204C_AXI_ARLOCK     => JESD204C_AXI_ARLOCK      ,-- in  std_logic_vector ( 0 downto 0 );
        JESD204C_AXI_ARCACHE    => JESD204C_AXI_ARCACHE     ,-- in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_ARPROT     => JESD204C_AXI_ARPROT      ,-- in  std_logic_vector ( 2 downto 0 );
        JESD204C_AXI_ARREGION   => JESD204C_AXI_ARREGION    ,-- in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_ARQOS      => JESD204C_AXI_ARQOS       ,-- in  std_logic_vector ( 3 downto 0 );
        JESD204C_AXI_ARVALID    => JESD204C_AXI_ARVALID     ,-- in  std_logic;
        JESD204C_AXI_ARREADY    => JESD204C_AXI_ARREADY     ,-- out std_logic;
        JESD204C_AXI_RDATA      => JESD204C_AXI_RDATA       ,-- out std_logic_vector ( 31 downto 0 );
        JESD204C_AXI_RRESP      => JESD204C_AXI_RRESP       ,-- out std_logic_vector ( 1 downto 0 );
        JESD204C_AXI_RLAST      => JESD204C_AXI_RLAST       ,-- out std_logic;
        JESD204C_AXI_RVALID     => JESD204C_AXI_RVALID      ,-- out std_logic;
        JESD204C_AXI_RREADY     => JESD204C_AXI_RREADY      ,-- in  std_logic;
        ------------------------------------------------------------------------------------------
        -- SYNC
        ------------------------------------------------------------------------------------------
        DL_BFN_STRB_IN          => DL_BFN_STRB_IN     ,-- in  std_logic;
        UL_BFN_STRB_IN          => UL_BFN_STRB_IN     ,-- in  std_logic;
        SSB_STRB_IN             => SSB_STRB_IN        ,-- in  std_logic;
        DL_BFN_STRB_OUT         => DL_BFN_STRB_OUT    ,-- out std_logic;
        UL_BFN_STRB_OUT         => UL_BFN_STRB_OUT    ,-- out std_logic;
        SSB_STRB_OUT            => SSB_STRB_OUT       ,-- out std_logic;     
        ------------------------------------------------------------------------------------------
        -- DUMP Interface
        ------------------------------------------------------------------------------------------
        DUMP_BFN_STRB_OUT       => DUMP_BFN_STRB_OUT     ,-- out std_logic;                                 
        DUMP_DVLD_OUT           => DUMP_DVLD_OUT         ,-- out std_logic; -- Dump valid                   
        DUMP_DATA_OUT           => DUMP_DATA_OUT         ,-- out std_logic_vector(31 downto 0); -- Dump data        
        ------------------------------------------------------------------------------------------
        -- DATA PATH IF
        ------------------------------------------------------------------------------------------
        PULSED_CW_10ms_IN       => PULSED_CW_10ms_IN     ,-- in std_logic;
        ------------------------------------------------------------------------
        -- For test
        ------------------------------------------------------------------------
        O_DL_JESD_TREADY        => O_DL_JESD_TREADY     ,-- out std_logic;
        O_UL_JESD_TVALID        => O_UL_JESD_TVALID     ,-- out std_logic;
        ------------------------------------------------------------------------
        -- CC Interface
        ------------------------------------------------------------------------
        --DL data
        DL_I_IN                 => arr_DL_I_IN     ,-- in std_logic_array16((TX_ANT_NUM-1) downto 0);
        DL_Q_IN                 => arr_DL_Q_IN     ,-- in std_logic_array16((TX_ANT_NUM-1) downto 0);
        --UL data               
        UL_I_OUT                => arr_UL_I_OUT     ,-- out std_logic_array16((RX_ANT_NUM-1) downto 0);
        UL_Q_OUT                => arr_UL_Q_OUT     ,-- out std_logic_array16((RX_ANT_NUM-1) downto 0);
        --FB data                        
        FB_I_EVEN_OUT           => arr_FB_I_EVEN_OUT     ,-- out std_logic_array16(FB_PATH_NUM-1 downto 0);
        FB_Q_EVEN_OUT           => arr_FB_Q_EVEN_OUT     ,-- out std_logic_array16(FB_PATH_NUM-1 downto 0);
        FB_I_ODD_OUT            => arr_FB_I_ODD_OUT      ,-- out std_logic_array16(FB_PATH_NUM-1 downto 0);
        FB_Q_ODD_OUT            => arr_FB_Q_ODD_OUT      -- out std_logic_array16(FB_PATH_NUM-1 downto 0)
							  
	);
 
 
end BEHAVE;
