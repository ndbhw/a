
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;
use WORK.RU_FPGA_CONFIG.ALL;

entity DSP_TOP_vhd is
    port (
        -- Internal PLL Lock
        INT_SYSPLL_LOCK_IN                      : in  std_logic;                                    -- Internal System PLL Lock

        -- System Reset & Clock
        RST_DDUC                                : in  std_logic;                                    -- DDUC_TOP Reset, '1': Reset
        RST_PIM                                 : in  std_logic;

        CLK_SYS                                 : in  std_logic;                                    -- System Clock :  30.72 MHz
        CLK_SYSX2                               : in  std_logic;                                    --  2x(CLK_SYS) :  61.44 MHz
        CLK_SYSX3                               : in  std_logic;                                    --  3x(CLK_SYS) :  92.16 MHz
        CLK_SYSX4                               : in  std_logic;                                    --  4x(CLK_SYS) : 122.88 MHz
        CLK_SYSX5                               : in  std_logic;                                    --  5x(CLK_SYS) : 153.60 MHz
        CLK_SYSX6                               : in  std_logic;                                    --  6x(CLK_SYS) : 184.32 MHz
        CLK_SYSX8                               : in  std_logic;                                    --  8x(CLK_SYS) : 245.76 MHz
        CLK_SYSX10                              : in  std_logic;                                    -- 10x(CLK_SYS) : 307.20 MHz
        CLK_SYSX12                              : in  std_logic;                                    -- 12x(CLK_SYS) : 368.64 MHz
        CLK_SYSX16                              : in  std_logic;                                    -- 16x(CLK_SYS) : 491.52 MHz
        CLK_SYSX20                              : in  std_logic;                                    -- 20x(CLK_SYS) : 614.40 MHz

        -- CPU Reset & Clock
        RST_CPUIF                               : in  std_logic;                                    -- CPUIF Reset, '1': Reset
        CLK_CPUIF                               : in  std_logic;                                    -- CPUIF Clock, Faster than iclk/oclk
        RST_DPDIF                               : in  std_logic;                                    -- CPUIF Reset, '1': Reset
        CLK_DPDIF                               : in  std_logic;                                    -- CPUIF Clock, Faster than iclk/oclk

        -- CPUIF_TOP  (Except DPD)
        ADDR_CPUIF_IN                           : in  std_logic_vector(ADDR_WIDTH-1 downto 0);      -- CPUIF Address Input, WORD Address
        WDATA_CPUIF_IN                          : in  std_logic_vector(WDATA_WIDTH-1 downto 0);     -- CPUIF Data Input
        RDATA_CPUIF_OUT                         : out std_logic_vector(RDATA_WIDTH-1 downto 0);     -- CPUIF DATA Output
        WREN_CPUIF_IN                           : in  std_logic;                                    -- CPUIF Write Enable,    '1': Active, Synchronous with iclk
        RDEN_CPUIF_IN                           : in  std_logic;                                    -- CPUIF Read Enable,     '1': Active,
        RDVLD_CPUIF_OUT                         : out std_logic;                                    -- CPUIF Read Data Valid, '1': Active, Synchronous with clk_cpu

        -- CPUIF DPD
        ADDR_DPDIF_IN                           : in  std_logic_vector( ADDR_WIDTH-1 downto 0);     -- CPUIF Address Input, WORD Address
        WDATA_DPDIF_IN                          : in  std_logic_vector(WDATA_WIDTH-1 downto 0);     -- CPUIF Data Input
        RDATA_DPDIF_OUT                         : out std_logic_vector(RDATA_WIDTH-1 downto 0);     -- CPUIF DATA Output
        WREN_DPDIF_IN                           : in  std_logic;                                    -- CPUIF Write Enable,    '1': Active, Synchronous with iclk
        RDEN_DPDIF_IN                           : in  std_logic;                                    -- CPUIF Read Enable,     '1': Active,
        RDVLD_DPDIF_OUT                         : out std_logic;                                    -- CPUIF Read Data Valid, '1': Active, Synchronous with clk_cpu

        -- FROM/TO BBCTRL      
        DL_CHBW_IN                              : in  std_logic_vector(DL_BBIQARY_NUM*4-1 downto 0);  -- 0x0: 5M,  0x1: 10M, 0x2: 15M, 0x3: 20M
        UL_CHBW_IN                              : in  std_logic_vector(UL_BBIQARY_NUM*4-1 downto 0);  -- 0x0: 5M,  0x1: 10M, 0x2: 15M, 0x3: 20M
        
        DL_BFN_STRB_IN                          : in  std_logic;                                    -- Downlink 10ms Frame Sync Strobe
        DL_SSB_STRB_IN                          : in  std_logic;                                    -- Downlink SSB Sync Strobe
        UL_BFN_STRB_OUT                         : out std_logic;                                    -- Delayed Uplink 10ms Frame Sync Strobe as UL Path Latency

        DL_SYNC_IN                              : in  std_logic_vector(DL_BBIQARY_NUM-1 downto 0);  -- DUC IQ Data Sync
        DL_IQ_IN                                : in  std_logic_vector(DL_BBIQARY_NUM*16-1 downto 0); -- DUC IQ Data

        UL_SYNC_OUT                             : out std_logic_vector(UL_BBIQARY_NUM-1 downto 0);  -- DDC IQ Data Sync
        UL_IQ_OUT                               : out std_logic_vector(UL_BBIQARY_NUM*16-1 downto 0); -- DDC IQ Data

        PWR_UPT_TICK_OUT                        : out std_logic_vector(FB_PATH_NUM-1 downto 0);
        FBSW_PATH_OUT                           : out std_logic_vector(FB_PATH_NUM*3-1 downto 0);

        -- FROM/TO DCIF
        DL_BFN_STRB_OUT                         : out std_logic;                                    -- Delayed Downlink 10ms Frame Sync Strobe as DL Path Latency
        DL_SSB_STRB_OUT                         : out std_logic;                                    -- Delayed Downlink SSB Strobe as DL Path Latency
        UL_BFN_STRB_IN                          : in  std_logic;                                    -- Uplink 10ms Frame Sync Strobe

        DL_SYNC_OUT                             : out std_logic;                                    -- DSP_TOP output IQ sample valid
        DL_I_OUT                                : out std_logic_vector(TX_ANT_NUM*16-1 downto 0);     -- DSP_TOP output I data
        DL_Q_OUT                                : out std_logic_vector(TX_ANT_NUM*16-1 downto 0);     -- DSP_TOP output Q data

        UL_SYNC_IN                              : in  std_logic;                                    -- DSP_TOP Input IQ sample valid
        UL_I_IN                                 : in  std_logic_vector(RX_ANT_NUM*16-1 downto 0);     -- DSP_TOP Input I data
        UL_Q_IN                                 : in  std_logic_vector(RX_ANT_NUM*16-1 downto 0);     -- DSP_TOP Input Q data

        FB_SYNC_IN                              : in  std_logic;                                    -- Feedback Path IQ sample valid
        FB_I_IN_EVEN                            : in  std_logic_vector(FB_PATH_NUM*16-1 downto 0);    -- Feedback Path I data
        FB_Q_IN_EVEN                            : in  std_logic_vector(FB_PATH_NUM*16-1 downto 0);    -- Feedback Path Q data
        FB_I_IN_ODD                             : in  std_logic_vector(FB_PATH_NUM*16-1 downto 0);    -- Feedback Path I data
        FB_Q_IN_ODD                             : in  std_logic_vector(FB_PATH_NUM*16-1 downto 0);    -- Feedback Path Q data
        
        -- FROM RFIC
        GPIO_4_IN                               : in  std_logic;                                    -- #0 FB path RVS A Tick
        GPIO_9_IN                               : in  std_logic;                                    -- #1 FB path RVS C Tick

        -- FROM/TO MISC
        SIG_SUS_DLOFF_IN                        : in  std_logic_vector(TX_ANT_NUM-1 downto 0);       -- Wave-Stop Flag
        
        DL_IQ_ISZERO_OUT                        : out std_logic_vector(TX_ANT_NUM-1 downto 0);       -- '1': IQ is Zero, '0': IQ is Non-Zero
        DL_CLK_ISZERO_OUT                       : out std_logic_vector(TX_ANT_NUM-1 downto 0);

        -- TO DUMP
        DUMP_BFN_STRB_OUT                       : out std_logic;
        DUMP_DVLD_OUT                           : out std_logic;
        DUMP_DATA_OUT                           : out std_logic_vector(32-1 downto 0)
    );
end DSP_TOP_vhd;

architecture BEHAVE of DSP_TOP_vhd is

component DSP_TOP is
    port (
        -- Internal PLL Lock
        INT_SYSPLL_LOCK_IN                      : in  std_logic;                                    -- Internal System PLL Lock

        -- System Reset & Clock
        RST_DDUC                                : in  std_logic;                                    -- DDUC_TOP Reset, '1': Reset
        RST_PIM                                 : in  std_logic;

        CLK_SYS                                 : in  std_logic;                                    -- System Clock :  30.72 MHz
        CLK_SYSX2                               : in  std_logic;                                    --  2x(CLK_SYS) :  61.44 MHz
        CLK_SYSX3                               : in  std_logic;                                    --  3x(CLK_SYS) :  92.16 MHz
        CLK_SYSX4                               : in  std_logic;                                    --  4x(CLK_SYS) : 122.88 MHz
        CLK_SYSX5                               : in  std_logic;                                    --  5x(CLK_SYS) : 153.60 MHz
        CLK_SYSX6                               : in  std_logic;                                    --  6x(CLK_SYS) : 184.32 MHz
        CLK_SYSX8                               : in  std_logic;                                    --  8x(CLK_SYS) : 245.76 MHz
        CLK_SYSX10                              : in  std_logic;                                    -- 10x(CLK_SYS) : 307.20 MHz
        CLK_SYSX12                              : in  std_logic;                                    -- 12x(CLK_SYS) : 368.64 MHz
        CLK_SYSX16                              : in  std_logic;                                    -- 16x(CLK_SYS) : 491.52 MHz
        CLK_SYSX20                              : in  std_logic;                                    -- 20x(CLK_SYS) : 614.40 MHz

        -- CPU Reset & Clock
        RST_CPUIF                               : in  std_logic;                                    -- CPUIF Reset, '1': Reset
        CLK_CPUIF                               : in  std_logic;                                    -- CPUIF Clock, Faster than iclk/oclk
        RST_DPDIF                               : in  std_logic;                                    -- CPUIF Reset, '1': Reset
        CLK_DPDIF                               : in  std_logic;                                    -- CPUIF Clock, Faster than iclk/oclk

        -- CPUIF_TOP  (Except DPD)
        ADDR_CPUIF_IN                           : in  std_logic_vector(ADDR_WIDTH-1 downto 0);      -- CPUIF Address Input, WORD Address
        WDATA_CPUIF_IN                          : in  std_logic_vector(WDATA_WIDTH-1 downto 0);     -- CPUIF Data Input
        RDATA_CPUIF_OUT                         : out std_logic_vector(RDATA_WIDTH-1 downto 0);     -- CPUIF DATA Output
        WREN_CPUIF_IN                           : in  std_logic;                                    -- CPUIF Write Enable,    '1': Active, Synchronous with iclk
        RDEN_CPUIF_IN                           : in  std_logic;                                    -- CPUIF Read Enable,     '1': Active,
        RDVLD_CPUIF_OUT                         : out std_logic;                                    -- CPUIF Read Data Valid, '1': Active, Synchronous with clk_cpu

        -- CPUIF DPD
        ADDR_DPDIF_IN                           : in  std_logic_vector( ADDR_WIDTH-1 downto 0);     -- CPUIF Address Input, WORD Address
        WDATA_DPDIF_IN                          : in  std_logic_vector(WDATA_WIDTH-1 downto 0);     -- CPUIF Data Input
        RDATA_DPDIF_OUT                         : out std_logic_vector(RDATA_WIDTH-1 downto 0);     -- CPUIF DATA Output
        WREN_DPDIF_IN                           : in  std_logic;                                    -- CPUIF Write Enable,    '1': Active, Synchronous with iclk
        RDEN_DPDIF_IN                           : in  std_logic;                                    -- CPUIF Read Enable,     '1': Active,
        RDVLD_DPDIF_OUT                         : out std_logic;                                    -- CPUIF Read Data Valid, '1': Active, Synchronous with clk_cpu

        -- FROM/TO BBCTRL      
        DL_CHBW_IN                              : in  std_logic_array4(DL_BBIQARY_NUM-1 downto 0);  -- 0x0: 5M,  0x1: 10M, 0x2: 15M, 0x3: 20M
        UL_CHBW_IN                              : in  std_logic_array4(UL_BBIQARY_NUM-1 downto 0);  -- 0x0: 5M,  0x1: 10M, 0x2: 15M, 0x3: 20M
        
        DL_BFN_STRB_IN                          : in  std_logic;                                    -- Downlink 10ms Frame Sync Strobe
        DL_SSB_STRB_IN                          : in  std_logic;                                    -- Downlink SSB Sync Strobe
        UL_BFN_STRB_OUT                         : out std_logic;                                    -- Delayed Uplink 10ms Frame Sync Strobe as UL Path Latency

        DL_SYNC_IN                              : in  std_logic_vector(DL_BBIQARY_NUM-1 downto 0);  -- DUC IQ Data Sync
        DL_IQ_IN                                : in  std_logic_array16(DL_BBIQARY_NUM-1 downto 0); -- DUC IQ Data

        UL_SYNC_OUT                             : out std_logic_vector(UL_BBIQARY_NUM-1 downto 0);  -- DDC IQ Data Sync
        UL_IQ_OUT                               : out std_logic_array16(UL_BBIQARY_NUM-1 downto 0); -- DDC IQ Data

        PWR_UPT_TICK_OUT                        : out std_logic_vector(FB_PATH_NUM-1 downto 0);
        FBSW_PATH_OUT                           : out std_logic_array3(FB_PATH_NUM-1 downto 0);

        -- FROM/TO DCIF
        DL_BFN_STRB_OUT                         : out std_logic;                                    -- Delayed Downlink 10ms Frame Sync Strobe as DL Path Latency
        DL_SSB_STRB_OUT                         : out std_logic;                                    -- Delayed Downlink SSB Strobe as DL Path Latency
        UL_BFN_STRB_IN                          : in  std_logic;                                    -- Uplink 10ms Frame Sync Strobe

        DL_SYNC_OUT                             : out std_logic;                                    -- DSP_TOP output IQ sample valid
        DL_I_OUT                                : out std_logic_array16(TX_ANT_NUM-1 downto 0);     -- DSP_TOP output I data
        DL_Q_OUT                                : out std_logic_array16(TX_ANT_NUM-1 downto 0);     -- DSP_TOP output Q data

        UL_SYNC_IN                              : in  std_logic;                                    -- DSP_TOP Input IQ sample valid
        UL_I_IN                                 : in  std_logic_array16(RX_ANT_NUM-1 downto 0);     -- DSP_TOP Input I data
        UL_Q_IN                                 : in  std_logic_array16(RX_ANT_NUM-1 downto 0);     -- DSP_TOP Input Q data

        FB_SYNC_IN                              : in  std_logic;                                    -- Feedback Path IQ sample valid
        FB_I_IN_EVEN                            : in  std_logic_array16(FB_PATH_NUM-1 downto 0);    -- Feedback Path I data
        FB_Q_IN_EVEN                            : in  std_logic_array16(FB_PATH_NUM-1 downto 0);    -- Feedback Path Q data
        FB_I_IN_ODD                             : in  std_logic_array16(FB_PATH_NUM-1 downto 0);    -- Feedback Path I data
        FB_Q_IN_ODD                             : in  std_logic_array16(FB_PATH_NUM-1 downto 0);    -- Feedback Path Q data
        
        -- FROM RFIC
        GPIO_4_IN                               : in  std_logic;                                    -- #0 FB path RVS A Tick
        GPIO_9_IN                               : in  std_logic;                                    -- #1 FB path RVS C Tick

        -- FROM/TO MISC
        SIG_SUS_DLOFF_IN                        : in  std_logic_vector(TX_ANT_NUM-1 downto 0);       -- Wave-Stop Flag
        
        DL_IQ_ISZERO_OUT                        : out std_logic_vector(TX_ANT_NUM-1 downto 0);       -- '1': IQ is Zero, '0': IQ is Non-Zero
        DL_CLK_ISZERO_OUT                       : out std_logic_vector(TX_ANT_NUM-1 downto 0);

        -- TO DUMP
        DUMP_BFN_STRB_OUT                       : out std_logic;
        DUMP_DVLD_OUT                           : out std_logic;
        DUMP_DATA_OUT                           : out std_logic_vector(32-1 downto 0)
    );
end component;

signal arr_DL_CHBW_IN     : std_logic_array4(DL_BBIQARY_NUM-1 downto 0);  -- 0x0: 5M,  0x1: 10M, 0x2: 15M, 0x3: 20M
signal arr_DL_IQ_IN       : std_logic_array16(DL_BBIQARY_NUM-1 downto 0); -- DUC IQ Data

signal arr_UL_CHBW_IN     : std_logic_array4(UL_BBIQARY_NUM-1 downto 0);  -- 0x0: 5M,  0x1: 10M, 0x2: 15M, 0x3: 20M
signal arr_UL_IQ_OUT      : std_logic_array16(UL_BBIQARY_NUM-1 downto 0); -- DDC IQ Data

signal arr_DL_I_OUT       : std_logic_array16(TX_ANT_NUM-1 downto 0);     -- DSP_TOP output I data
signal arr_DL_Q_OUT       : std_logic_array16(TX_ANT_NUM-1 downto 0);     -- DSP_TOP output Q data
signal arr_UL_I_IN        : std_logic_array16(RX_ANT_NUM-1 downto 0);     -- DSP_TOP Input I data
signal arr_UL_Q_IN        : std_logic_array16(RX_ANT_NUM-1 downto 0);     -- DSP_TOP Input Q data

signal arr_FBSW_PATH_OUT  : std_logic_array3(FB_PATH_NUM-1 downto 0);
signal arr_FB_I_IN_EVEN   : std_logic_array16(FB_PATH_NUM-1 downto 0);    -- Feedback Path I data
signal arr_FB_Q_IN_EVEN   : std_logic_array16(FB_PATH_NUM-1 downto 0);    -- Feedback Path Q data
signal arr_FB_I_IN_ODD    : std_logic_array16(FB_PATH_NUM-1 downto 0);    -- Feedback Path I data
signal arr_FB_Q_IN_ODD    : std_logic_array16(FB_PATH_NUM-1 downto 0);    -- Feedback Path Q data



	
begin

--arr_RX_BFN_NR_IN(0)	<=	RX_BFN_NR_IN(11 downto 0);
--CPRI_TX_Q_OUT (15 downto 0)<= arr_CPRI_TX_I_OUT(0);

gen_1: for i in 0 to DL_BBIQARY_NUM-1 generate
begin
--arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
--O_UL_DATA_Q(16*i+15 downto 16*i) <=	arr_O_UL_DATA_Q(i);
arr_DL_CHBW_IN(i) <= DL_CHBW_IN(4*i+3 downto 4*i   );
arr_DL_IQ_IN  (i) <= DL_IQ_IN  (16*i+15 downto 16*i);
end generate;


gen_2: for i in 0 to UL_BBIQARY_NUM-1 generate
begin
arr_UL_CHBW_IN(i) <= UL_CHBW_IN	(4*i+3 downto 4*i);
UL_IQ_OUT 	  (16*i+15 downto 16*i) <= arr_UL_IQ_OUT(i);
end generate;

gen_3: for i in 0 to 3 generate
begin

DL_I_OUT (16*i+15 downto 16*i)   <= arr_DL_I_OUT  (i);
DL_Q_OUT (16*i+15 downto 16*i)   <= arr_DL_Q_OUT  (i);
arr_UL_I_IN(i) <= UL_I_IN (16*i+15 downto 16*i);
arr_UL_Q_IN(i) <= UL_Q_IN (16*i+15 downto 16*i);

end generate;

gen_4: for i in 0 to FB_PATH_NUM-1 generate
begin

arr_FB_I_IN_EVEN(i) <= FB_I_IN_EVEN(16*i+15 downto 16*i);
arr_FB_Q_IN_EVEN(i) <= FB_Q_IN_EVEN(16*i+15 downto 16*i);
arr_FB_I_IN_ODD (i) <= FB_I_IN_ODD (16*i+15 downto 16*i);
arr_FB_Q_IN_ODD (i) <= FB_Q_IN_ODD (16*i+15 downto 16*i);
FBSW_PATH_OUT(3*i+2 downto 3*i)	<= arr_FBSW_PATH_OUT(i);

end generate;

	
				
 u_DSP_TOP: DSP_TOP
	port map(
 
        -- Internal PLL Lock
        INT_SYSPLL_LOCK_IN           => INT_SYSPLL_LOCK_IN,-- in  std_logic;                                    -- Internal System PLL Lock

        -- System Reset & Clock
        RST_DDUC                     => RST_DDUC ,--in  std_logic;                                    -- DDUC_TOP Reset, '1': Reset
        RST_PIM                      => RST_PIM  ,--in  std_logic;

        CLK_SYS                      => CLK_SYS    , --in  std_logic;                                    -- System Clock :  30.72 MHz
        CLK_SYSX2                    => CLK_SYSX2  , --in  std_logic;                                    --  2x(CLK_SYS) :  61.44 MHz
        CLK_SYSX3                    => CLK_SYSX3  , --in  std_logic;                                    --  3x(CLK_SYS) :  92.16 MHz
        CLK_SYSX4                    => CLK_SYSX4  , --in  std_logic;                                    --  4x(CLK_SYS) : 122.88 MHz
        CLK_SYSX5                    => CLK_SYSX5  , --in  std_logic;                                    --  5x(CLK_SYS) : 153.60 MHz
        CLK_SYSX6                    => CLK_SYSX6  , --in  std_logic;                                    --  6x(CLK_SYS) : 184.32 MHz
        CLK_SYSX8                    => CLK_SYSX8  , --in  std_logic;                                    --  8x(CLK_SYS) : 245.76 MHz
        CLK_SYSX10                   => CLK_SYSX10 , --in  std_logic;                                    -- 10x(CLK_SYS) : 307.20 MHz
        CLK_SYSX12                   => CLK_SYSX12 , --in  std_logic;                                    -- 12x(CLK_SYS) : 368.64 MHz
        CLK_SYSX16                   => CLK_SYSX16 , --in  std_logic;                                    -- 16x(CLK_SYS) : 491.52 MHz
        CLK_SYSX20                   => CLK_SYSX20 , --in  std_logic;                                    -- 20x(CLK_SYS) : 614.40 MHz

        -- CPU Reset & Clock
        RST_CPUIF                    => RST_CPUIF ,--in  std_logic;                                    -- CPUIF Reset, '1': Reset
        CLK_CPUIF                    => CLK_CPUIF ,--in  std_logic;                                    -- CPUIF Clock, Faster than iclk/oclk
        RST_DPDIF                    => RST_DPDIF ,--in  std_logic;                                    -- CPUIF Reset, '1': Reset
        CLK_DPDIF                    => CLK_DPDIF ,--in  std_logic;                                    -- CPUIF Clock, Faster than iclk/oclk

        -- CPUIF_TOP  (Except DPD)
        ADDR_CPUIF_IN                => ADDR_CPUIF_IN   ,--in  std_logic_vector(ADDR_WIDTH-1 downto 0);      -- CPUIF Address Input, WORD Address
        WDATA_CPUIF_IN               => WDATA_CPUIF_IN  ,--in  std_logic_vector(WDATA_WIDTH-1 downto 0);     -- CPUIF Data Input
        RDATA_CPUIF_OUT              => RDATA_CPUIF_OUT ,--out std_logic_vector(RDATA_WIDTH-1 downto 0);     -- CPUIF DATA Output
        WREN_CPUIF_IN                => WREN_CPUIF_IN   ,--in  std_logic;                                    -- CPUIF Write Enable,    '1': Active, Synchronous with iclk
        RDEN_CPUIF_IN                => RDEN_CPUIF_IN   ,--in  std_logic;                                    -- CPUIF Read Enable,     '1': Active,
        RDVLD_CPUIF_OUT              => RDVLD_CPUIF_OUT ,--out std_logic;                                    -- CPUIF Read Data Valid, '1': Active, Synchronous with clk_cpu
									  
        -- CPUIF DPD                  
        ADDR_DPDIF_IN                => ADDR_DPDIF_IN   ,--in  std_logic_vector( ADDR_WIDTH-1 downto 0);     -- CPUIF Address Input, WORD Address
        WDATA_DPDIF_IN               => WDATA_DPDIF_IN  ,--in  std_logic_vector(WDATA_WIDTH-1 downto 0);     -- CPUIF Data Input
        RDATA_DPDIF_OUT              => RDATA_DPDIF_OUT ,--out std_logic_vector(RDATA_WIDTH-1 downto 0);     -- CPUIF DATA Output
        WREN_DPDIF_IN                => WREN_DPDIF_IN   ,--in  std_logic;                                    -- CPUIF Write Enable,    '1': Active, Synchronous with iclk
        RDEN_DPDIF_IN                => RDEN_DPDIF_IN   ,--in  std_logic;                                    -- CPUIF Read Enable,     '1': Active,
        RDVLD_DPDIF_OUT              => RDVLD_DPDIF_OUT ,--out std_logic;                                    -- CPUIF Read Data Valid, '1': Active, Synchronous with clk_cpu
									  
        -- FROM/TO BBCTRL             
        DL_CHBW_IN                   => arr_DL_CHBW_IN ,--in  std_logic_array4(DL_BBIQARY_NUM-1 downto 0);  -- 0x0: 5M,  0x1: 10M, 0x2: 15M, 0x3: 20M
        UL_CHBW_IN                   => arr_UL_CHBW_IN ,--in  std_logic_array4(UL_BBIQARY_NUM-1 downto 0);  -- 0x0: 5M,  0x1: 10M, 0x2: 15M, 0x3: 20M
									  
        DL_BFN_STRB_IN               => DL_BFN_STRB_IN  ,--in  std_logic;                                    -- Downlink 10ms Frame Sync Strobe
        DL_SSB_STRB_IN               => DL_SSB_STRB_IN  ,--in  std_logic;                                    -- Downlink SSB Sync Strobe
        UL_BFN_STRB_OUT              => UL_BFN_STRB_OUT ,--out std_logic;                                    -- Delayed Uplink 10ms Frame Sync Strobe as UL Path Latency
									  
        DL_SYNC_IN                   => DL_SYNC_IN ,--in  std_logic_vector(DL_BBIQARY_NUM-1 downto 0);  -- DUC IQ Data Sync
        DL_IQ_IN                     => arr_DL_IQ_IN   ,--in  std_logic_array16(DL_BBIQARY_NUM-1 downto 0); -- DUC IQ Data
									  
        UL_SYNC_OUT                  => UL_SYNC_OUT ,--out std_logic_vector(UL_BBIQARY_NUM-1 downto 0);  -- DDC IQ Data Sync
        UL_IQ_OUT                    => arr_UL_IQ_OUT   ,--out std_logic_array16(UL_BBIQARY_NUM-1 downto 0); -- DDC IQ Data
									  
        PWR_UPT_TICK_OUT             => PWR_UPT_TICK_OUT ,-- out std_logic_vector(FB_PATH_NUM-1 downto 0);
        FBSW_PATH_OUT                => arr_FBSW_PATH_OUT    ,-- out std_logic_array3(FB_PATH_NUM-1 downto 0);
									  
        -- FROM/TO DCIF               
        DL_BFN_STRB_OUT              => DL_BFN_STRB_OUT ,--out std_logic;   -- Delayed Downlink 10ms Frame Sync Strobe as DL Path Latency
        DL_SSB_STRB_OUT              => DL_SSB_STRB_OUT ,--out std_logic;   -- Delayed Downlink SSB Strobe as DL Path Latency
        UL_BFN_STRB_IN               => UL_BFN_STRB_IN  ,--in  std_logic;   -- Uplink 10ms Frame Sync Strobe
									  
        DL_SYNC_OUT                  => DL_SYNC_OUT,--out std_logic;                                    -- DSP_TOP output IQ sample valid
        DL_I_OUT                     => arr_DL_I_OUT   ,--out std_logic_array16(TX_ANT_NUM-1 downto 0);     -- DSP_TOP output I data
        DL_Q_OUT                     => arr_DL_Q_OUT   ,--out std_logic_array16(TX_ANT_NUM-1 downto 0);     -- DSP_TOP output Q data
									  
        UL_SYNC_IN                   => UL_SYNC_IN ,--in  std_logic;                                    -- DSP_TOP Input IQ sample valid
        UL_I_IN                      => arr_UL_I_IN    ,--in  std_logic_array16(RX_ANT_NUM-1 downto 0);     -- DSP_TOP Input I data
        UL_Q_IN                      => arr_UL_Q_IN    ,--in  std_logic_array16(RX_ANT_NUM-1 downto 0);     -- DSP_TOP Input Q data
									  
        FB_SYNC_IN                   => FB_SYNC_IN   ,--in  std_logic;                                    -- Feedback Path IQ sample valid
        FB_I_IN_EVEN                 => arr_FB_I_IN_EVEN ,--in  std_logic_array16(FB_PATH_NUM-1 downto 0);    -- Feedback Path I data
        FB_Q_IN_EVEN                 => arr_FB_Q_IN_EVEN ,--in  std_logic_array16(FB_PATH_NUM-1 downto 0);    -- Feedback Path Q data
        FB_I_IN_ODD                  => arr_FB_I_IN_ODD  ,--in  std_logic_array16(FB_PATH_NUM-1 downto 0);    -- Feedback Path I data
        FB_Q_IN_ODD                  => arr_FB_Q_IN_ODD  ,--in  std_logic_array16(FB_PATH_NUM-1 downto 0);    -- Feedback Path Q data
									  
        -- FROM RFIC                  
        GPIO_4_IN                    => GPIO_4_IN ,--in  std_logic;                                    -- #0 FB path RVS A Tick
        GPIO_9_IN                    => GPIO_9_IN ,--in  std_logic;                                    -- #1 FB path RVS C Tick
									  
        -- FROM/TO MISC               
        SIG_SUS_DLOFF_IN             => SIG_SUS_DLOFF_IN,-- in  std_logic_vector(TX_ANT_NUM-1 downto 0);       -- Wave-Stop Flag
									  
        DL_IQ_ISZERO_OUT             => DL_IQ_ISZERO_OUT  ,--out std_logic_vector(TX_ANT_NUM-1 downto 0);       -- '1': IQ is Zero, '0': IQ is Non-Zero
        DL_CLK_ISZERO_OUT            => DL_CLK_ISZERO_OUT ,--out std_logic_vector(TX_ANT_NUM-1 downto 0);
									  
        -- TO DUMP                    
        DUMP_BFN_STRB_OUT            => DUMP_BFN_STRB_OUT ,--out std_logic;
        DUMP_DVLD_OUT                => DUMP_DVLD_OUT     ,--out std_logic;
        DUMP_DATA_OUT                => DUMP_DATA_OUT     --out std_logic_vector(32-1 downto 0)
									  
	);
 
 
end BEHAVE;
