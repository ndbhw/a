
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.D_ARRAY_TYPE.ALL;
use WORK.RU_DFPGA_CONFIG.ALL;

entity SBIF_TOP_S_vhd is
    generic (
        PORT_NUM                    : natural := 4
    );
    port (
	



--------------------------------------------------------------------------------
-- FPGA ID
--------------------------------------------------------------------------------

        FPGA_ID                     : in  std_logic_vector(2 downto 0);

--------------------------------------------------------------------------------
-- External System PLL
--------------------------------------------------------------------------------

        EXT_SYSPLL_LOCK_IN          : in  std_logic;

--------------------------------------------------------------------------------
-- Interface FPGA
--------------------------------------------------------------------------------

        FRAME_SYNC_1sec             : in  std_logic;
        FRAME_SYNC_10ms             : in  std_logic;

--------------------------------------------------------------------------------
-- SYSCTRL_TOP
--------------------------------------------------------------------------------

        RST_SBIF                    : in  std_logic_vector(PORT_NUM-1 downto 0);
        CLK_SBIF                    : in  std_logic;                             -- 245.76 Mhz

        CLK_1PPS                    : out std_logic;

--------------------------------------------------------------------------------
-- CPU_TOP
--------------------------------------------------------------------------------

        RST_CPUIF                   : in  std_logic;
        CLK_CPUIF                   : in  std_logic;

--------------------------------------------------------------------------------
-- CPUIF_TOP
--------------------------------------------------------------------------------

        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        RDVAL_CPUIF_OUT             : out std_logic;

--------------------------------------------------------------------------------
-- SBIFPHY_TOP
--------------------------------------------------------------------------------

        SERDES_RXCOMMA_REALIGN_OUT  : out std_logic_vector(PORT_NUM-1 downto 0);
        SERDES_RXERR_IN             : in  std_logic_vector(8*PORT_NUM-1 downto 0);
        SERDES_RXISK_IN             : in  std_logic_vector(8*PORT_NUM-1 downto 0);
        SERDES_RXD_IN               : in  std_logic_vector(64*PORT_NUM-1 downto 0);
        SERDES_TXISK_OUT            : out std_logic_vector(8*PORT_NUM-1 downto 0);
        SERDES_TXD_OUT              : out std_logic_vector(64*PORT_NUM-1 downto 0);

--------------------------------------------------------------------------------
-- DBG_SIG_OUT
--------------------------------------------------------------------------------

        DBG_SIG_OUT                 : out std_logic_vector(1 downto 0);

--------------------------------------------------------------------------------
-- MISC_TOP
--------------------------------------------------------------------------------

        DUMP_BFN_STRB_OUT           : out std_logic_vector(1 downto 0);
        DUMP_DATA_OUT               : out std_logic_vector(32*2-1 downto 0);
        DUMP_DVLD_OUT               : out std_logic_vector(1 downto 0);
        TEST_DATA_IN                : in  std_logic_vector(32*2-1 downto 0);
        TEST_ENB_OUT                : out std_logic_vector(1 downto 0);

        SIG_SUS_FLAG_OUT            : out std_logic_vector(PORT_NUM-1 downto 0);
        SIG_SUS_DLOFF_IN            : in  std_logic_vector(PORT_NUM-1 downto 0);

--------------------------------------------------------------------------------
-- SYSCTRL_TOP
--------------------------------------------------------------------------------

        RX_BFN_STRB_OUT             : out std_logic_vector(PORT_NUM-1 downto 0);
        RX_BFN_NR_OUT               : out std_logic_vector(12*PORT_NUM-1 downto 0);

--------------------------------------------------------------------------------
-- BBCTRL_TOP
--------------------------------------------------------------------------------

        RX_USER_SYNC0_OUT           : out std_logic_vector(PORT_NUM-1 downto 0);
        RX_USER_SYNC1_OUT           : out std_logic_vector(PORT_NUM-1 downto 0);
        RX_VLD_OUT                  : out std_logic_vector(PORT_NUM-1 downto 0);
        RX_I_OUT                    : out std_logic_vector(16*PORT_NUM-1 downto 0);
        RX_Q_OUT                    : out std_logic_vector(16*PORT_NUM-1 downto 0);

        TX_USER_SYNC0_IN            : in  std_logic_vector(PORT_NUM-1 downto 0);
        TX_USER_SYNC1_IN            : in  std_logic_vector(PORT_NUM-1 downto 0);
        TX_BFN_STRB_IN              : in  std_logic_vector(PORT_NUM-1 downto 0);
        TX_ENB_OUT                  : out std_logic_vector(PORT_NUM-1 downto 0);
        TX_I_IN                     : in  std_logic_vector(16*PORT_NUM-1 downto 0);
        TX_Q_IN                     : in  std_logic_vector(16*PORT_NUM-1 downto 0)





    );
end SBIF_TOP_S_vhd;

architecture BEHAVE of SBIF_TOP_S_vhd is

signal arr_SERDES_RXERR_IN             : std_logic_array8(PORT_NUM-1 downto 0);      -- in  
signal arr_SERDES_RXISK_IN             : std_logic_array8(PORT_NUM-1 downto 0);      -- in  
signal arr_SERDES_RXD_IN               : std_logic_array64(PORT_NUM-1 downto 0);    -- in  
signal arr_TX_I_IN                     : std_logic_array16(PORT_NUM-1 downto 0);    -- in  
signal arr_TX_Q_IN                     : std_logic_array16(PORT_NUM-1 downto 0);    -- in 
signal arr_SERDES_TXISK_OUT            : std_logic_array8(PORT_NUM-1 downto 0);      -- out 
signal arr_SERDES_TXD_OUT              : std_logic_array64(PORT_NUM-1 downto 0);    -- out
signal arr_RX_BFN_NR_OUT               : std_logic_array12(PORT_NUM-1 downto 0);    -- out 
signal arr_RX_I_OUT                    : std_logic_array16(PORT_NUM-1 downto 0);    -- out 
signal arr_RX_Q_OUT                    : std_logic_array16(PORT_NUM-1 downto 0);    -- out 
  
signal arr_TEST_DATA_IN                : std_logic_array32(2-1 downto 0);           -- in 
signal arr_DUMP_DATA_OUT               : std_logic_array32(2-1 downto 0);           -- out 



begin

	gen_vhd_to_v : if TRUE generate
			gen_1: for i in 0 to PORT_NUM-1 generate
			begin			
				-- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i);  
				arr_SERDES_RXERR_IN(i)  <= SERDES_RXERR_IN (8*i+7 downto 8*i); 
				arr_SERDES_RXISK_IN(i)  <= SERDES_RXISK_IN (8*i+7 downto 8*i);	   
				arr_SERDES_RXD_IN  (i)  <= SERDES_RXD_IN   (64*i+63 downto 64*i);	   
				arr_TX_I_IN        (i)  <= TX_I_IN         (16*i+15 downto 16*i);	   
				arr_TX_Q_IN        (i)  <= TX_Q_IN         (16*i+15 downto 16*i); 				
				-- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
				SERDES_TXISK_OUT (8*i+7 downto 8*i)    <=  arr_SERDES_TXISK_OUT (i) ;
				SERDES_TXD_OUT   (64*i+63 downto 64*i) <=  arr_SERDES_TXD_OUT   (i) ;
				RX_BFN_NR_OUT    (12*i+11 downto 12*i) <=  arr_RX_BFN_NR_OUT    (i) ;
				RX_I_OUT         (16*i+15 downto 16*i) <=  arr_RX_I_OUT         (i) ;
				RX_Q_OUT         (16*i+15 downto 16*i) <=  arr_RX_Q_OUT         (i) ;		
			end generate;	
			
			gen_2: for i in 0 to 2-1 generate
			begin		
				-- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
				arr_TEST_DATA_IN (i) <= TEST_DATA_IN(32*i+31 downto 32*i);

				-- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
				DUMP_DATA_OUT (32*i+31 downto 32*i) <= arr_DUMP_DATA_OUT(i);			
			end generate;

	 end generate;   
    
    
    SBIF_slave : entity work.SBIF_TOP_S
    generic map(
		PORT_NUM => PORT_NUM
    )
    port map(
    
--------------------------------------------------------------------------------
-- FPGA ID
--------------------------------------------------------------------------------

        FPGA_ID                     =>   FPGA_ID     ,

--------------------------------------------------------------------------------
-- External System PLL
--------------------------------------------------------------------------------

        EXT_SYSPLL_LOCK_IN          =>   EXT_SYSPLL_LOCK_IN     ,

--------------------------------------------------------------------------------
-- Interface FPGA
--------------------------------------------------------------------------------

        FRAME_SYNC_1sec             =>   FRAME_SYNC_1sec     ,
        FRAME_SYNC_10ms             =>   FRAME_SYNC_10ms     ,

--------------------------------------------------------------------------------
-- SYSCTRL_TOP
--------------------------------------------------------------------------------

        RST_SBIF                    =>   RST_SBIF , 
        CLK_SBIF                    =>   CLK_SBIF ,  -- 245.76 Mhz
												  
        CLK_1PPS                    =>   CLK_1PPS , 

--------------------------------------------------------------------------------
-- CPU_TOP
--------------------------------------------------------------------------------

        RST_CPUIF                   =>   RST_CPUIF     ,
        CLK_CPUIF                   =>   CLK_CPUIF     ,

--------------------------------------------------------------------------------
-- CPUIF_TOP
--------------------------------------------------------------------------------

        ADDR_CPUIF_IN               =>   ADDR_CPUIF_IN       ,
        WDATA_CPUIF_IN              =>   WDATA_CPUIF_IN      ,
        RDATA_CPUIF_OUT             =>   RDATA_CPUIF_OUT     ,
        WREN_CPUIF_IN               =>   WREN_CPUIF_IN       ,
        RDEN_CPUIF_IN               =>   RDEN_CPUIF_IN       ,
        RDVAL_CPUIF_OUT             =>   RDVAL_CPUIF_OUT     ,

--------------------------------------------------------------------------------
-- SBIFPHY_TOP
--------------------------------------------------------------------------------

        SERDES_RXCOMMA_REALIGN_OUT  =>   SERDES_RXCOMMA_REALIGN_OUT     ,
        SERDES_RXERR_IN             =>   arr_SERDES_RXERR_IN    ,
        SERDES_RXISK_IN             =>   arr_SERDES_RXISK_IN    ,
        SERDES_RXD_IN               =>   arr_SERDES_RXD_IN        ,
        SERDES_TXISK_OUT            =>   arr_SERDES_TXISK_OUT   ,
        SERDES_TXD_OUT              =>   arr_SERDES_TXD_OUT       ,

--------------------------------------------------------------------------------
-- DBG_SIG_OUT
--------------------------------------------------------------------------------

        DBG_SIG_OUT                 =>   DBG_SIG_OUT     ,

--------------------------------------------------------------------------------
-- MISC_TOP
--------------------------------------------------------------------------------

        DUMP_BFN_STRB_OUT           =>   DUMP_BFN_STRB_OUT     ,
        DUMP_DATA_OUT               =>   arr_DUMP_DATA_OUT     ,
        DUMP_DVLD_OUT               =>   DUMP_DVLD_OUT     ,
        TEST_DATA_IN                =>   arr_TEST_DATA_IN     ,
        TEST_ENB_OUT                =>   TEST_ENB_OUT     ,

        SIG_SUS_FLAG_OUT            =>   SIG_SUS_FLAG_OUT     ,
        SIG_SUS_DLOFF_IN            =>   SIG_SUS_DLOFF_IN     ,

--------------------------------------------------------------------------------
-- SYSCTRL_TOP
--------------------------------------------------------------------------------

        RX_BFN_STRB_OUT             =>   RX_BFN_STRB_OUT     ,
        RX_BFN_NR_OUT               =>   arr_RX_BFN_NR_OUT     ,

--------------------------------------------------------------------------------
-- BBCTRL_TOP
--------------------------------------------------------------------------------

        RX_USER_SYNC0_OUT           =>   RX_USER_SYNC0_OUT     ,
        RX_USER_SYNC1_OUT           =>   RX_USER_SYNC1_OUT     ,
        RX_VLD_OUT                  =>   RX_VLD_OUT            ,
        RX_I_OUT                    =>   arr_RX_I_OUT     ,
        RX_Q_OUT                    =>   arr_RX_Q_OUT     ,

        TX_USER_SYNC0_IN            =>   TX_USER_SYNC0_IN     ,
        TX_USER_SYNC1_IN            =>   TX_USER_SYNC1_IN     ,
        TX_BFN_STRB_IN              =>   TX_BFN_STRB_IN       ,
        TX_ENB_OUT                  =>   TX_ENB_OUT           ,
        TX_I_IN                     =>   arr_TX_I_IN	,
        TX_Q_IN                     =>   arr_TX_Q_IN

    );

end BEHAVE;