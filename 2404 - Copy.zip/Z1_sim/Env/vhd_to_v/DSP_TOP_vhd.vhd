library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.D_ARRAY_TYPE.ALL;
use WORK.RU_DFPGA_CONFIG.ALL;

entity DSP_TOP_vhd is
    generic(
        DUC_NUM                     : integer:=4;
        DDC_NUM                     : integer:=4;
        TX_ANT_NUM                  : integer:=2;
        RX_ANT_NUM                  : integer:=2
    
    );
    port (
    

    -- ***************************
    -- SYSCTRL_TOP Interface
    -- ***************************
    -- Internal PLL Lock
    INT_SYSPLL_LOCK_IN            : in  std_logic;                                    -- Internal System PLL Lock

    -- System Reset & Clock
    RST_DDUC                      : in  std_logic;                                    -- DDUC_TOP Reset, '1': Reset
    RST_CFR                       : in  std_logic;                                    -- CFR_TOP Reset,  '1': Reset
    RST_DPD                       : in  std_logic;                                    -- DPD_TOP Reset,  '1': Reset
    RST_PIM                       : in  std_logic;

    CLK_SYS                       : in  std_logic;                                    -- System Clock :  30.72 MHz
    CLK_SYSX2                     : in  std_logic;                                    --  2x(CLK_SYS) :  61.44 MHz
    CLK_SYSX3                     : in  std_logic;                                    --  3x(CLK_SYS) :  92.16 MHz
    CLK_SYSX4                     : in  std_logic;                                    --  4x(CLK_SYS) : 122.88 MHz
    CLK_SYSX5                     : in  std_logic;                                    --  5x(CLK_SYS) : 153.60 MHz
    CLK_SYSX6                     : in  std_logic;                                    --  6x(CLK_SYS) : 184.32 MHz
    CLK_SYSX8                     : in  std_logic;                                    --  8x(CLK_SYS) : 245.76 MHz
    CLK_SYSX10                    : in  std_logic;                                    -- 10x(CLK_SYS) : 307.20 MHz
    CLK_SYSX12                    : in  std_logic;                                    -- 12x(CLK_SYS) : 368.64 MHz
    CLK_SYSX16                    : in  std_logic;                                    -- 16x(CLK_SYS) : 491.52 MHz
    CLK_SYSX20                    : in  std_logic;                                    -- 20x(CLK_SYS) : 614.40 MHz

    -- ***************************
    -- CPU_TOP Interface
    -- ***************************
    -- CPU Reset & Clock
    RST_CPUIF                     : in  std_logic;                                    -- CPUIF Reset, '1': Reset
    CLK_CPUIF                     : in  std_logic;                                    -- CPUIF Clock, Faster than iclk/oclk

--    RST_DPDIF                     : in  std_logic;                                    -- CPUIF Reset, '1': Reset
--    CLK_DPDIF                     : in  std_logic;                                    -- CPUIF Clock, Faster than iclk/oclk

    -- ***************************
    -- CPUIF_TOP Interface
    -- ***************************
    -- CPUIF DSP Common
    ADDR_CPUIF_IN                 : in  std_logic_vector( ADDR_WIDTH-1 downto 0);     -- CPUIF Address Input, WORD Address
    WDATA_CPUIF_IN                : in  std_logic_vector(WDATA_WIDTH-1 downto 0);     -- CPUIF Data Input
    RDATA_CPUIF_OUT               : out std_logic_vector(RDATA_WIDTH-1 downto 0);     -- CPUIF DATA Output
    WREN_CPUIF_IN                 : in  std_logic;                                    -- CPUIF Write Enable,    '1': Active, Synchronous with iclk
    RDEN_CPUIF_IN                 : in  std_logic;                                    -- CPUIF Read Enable,     '1': Active,
    RDVLD_CPUIF_OUT               : out std_logic;                                    -- CPUIF Read Data Valid, '1': Active, Synchronous with clk_cpu

    -- CPUIF DPD
    ADDR_DPD0IF_IN                 : in  std_logic_vector( ADDR_WIDTH-1 downto 0);     -- CPUIF Address Input, WORD Address
    WDATA_DPD0IF_IN                : in  std_logic_vector(WDATA_WIDTH-1 downto 0);     -- CPUIF Data Input
    RDATA_DPD0IF_OUT               : out std_logic_vector(RDATA_WIDTH-1 downto 0);     -- CPUIF DATA Output
    WREN_DPD0IF_IN                 : in  std_logic;                                    -- CPUIF Write Enable,    '1': Active, Synchronous with iclk
    RDEN_DPD0IF_IN                 : in  std_logic;                                    -- CPUIF Read Enable,     '1': Active,
    RDVLD_DPD0IF_OUT               : out std_logic;                                    -- CPUIF Read Data Valid, '1': Active, Synchronous with clk_cpu

    ADDR_DPD1IF_IN                 : in  std_logic_vector( ADDR_WIDTH-1 downto 0);     -- CPUIF Address Input, WORD Address
    WDATA_DPD1IF_IN                : in  std_logic_vector(WDATA_WIDTH-1 downto 0);     -- CPUIF Data Input
    RDATA_DPD1IF_OUT               : out std_logic_vector(RDATA_WIDTH-1 downto 0);     -- CPUIF DATA Output
    WREN_DPD1IF_IN                 : in  std_logic;                                    -- CPUIF Write Enable,    '1': Active, Synchronous with iclk
    RDEN_DPD1IF_IN                 : in  std_logic;                                    -- CPUIF Read Enable,     '1': Active,
    RDVLD_DPD1IF_OUT               : out std_logic;                                    -- CPUIF Read Data Valid, '1': Active, Synchronous with clk_cpu

    -- ***************************
    -- BBCTRL_TOP Interface
    -- ***************************
    -- System Information
--    DL_AIRTECH_IN                 : in  std_logic_array4( DUC_NUM-1 downto 0); -- System Type, 0x0: LTE, 0x1:UMTS
    DL_CHBW_IN                    : in  std_logic_vector( 4*(DUC_NUM/2)-1 downto 0); -- Bandwidth,   0x0: 5M,  0x1: 10M, 0x2: 15M, 0x3: 20M

--    UL_AIRTECH_IN                 : in  std_logic_array4( DDC_NUM-1 downto 0); -- System Type, 0x0: LTE, 0x1:UMTS
    UL_CHBW_IN                    : in  std_logic_vector( 4*(DDC_NUM/2)-1 downto 0); -- Bandwidth,   0x0: 5M,  0x1: 10M, 0x2: 15M, 0x3: 20M

--    B8_DL_AIRTECH_IN              : in  std_logic_array4( DUC_NUM-1 downto 0); -- System Type, 0x0: LTE, 0x1:UMTS
    B8_DL_CHBW_IN                 : in  std_logic_vector( 4*(DUC_NUM/2)-1 downto 0); -- Bandwidth,   0x0: 5M,  0x1: 10M, 0x2: 15M, 0x3: 20M

--    B8_UL_AIRTECH_IN              : in  std_logic_array4( DDC_NUM-1 downto 0); -- System Type, 0x0: LTE, 0x1:UMTS
    B8_UL_CHBW_IN                 : in  std_logic_vector( 4*(DDC_NUM/2)-1 downto 0); -- Bandwidth,   0x0: 5M,  0x1: 10M, 0x2: 15M, 0x3: 20M

    -- TDD & BFN Strobe
    DL_BFN_STRB_IN                : in  std_logic;                                    -- Downlink 10ms Frame Sync Strobe
    DL_SSB_STRB_IN                : in  std_logic;                                    -- Downlink SSB period Strobe (20/40/80/160msec)
    DL_TDD_IN                     : in  std_logic;                                    -- Downlink TDD Strobe

    UL_BFN_STRB_OUT               : out std_logic;                                    -- Delayed Uplink 10ms Frame Sync Strobe as UL Path Latency
    UL_TDD_OUT                    : out std_logic;                                    -- Delayed Uplink TDD Strobe as UL Path Latency

    BCF_ENB_IN                    : in  std_logic;

    -- Traffic IQ
    DL_SYNC_IN                    : in  std_logic_vector( DUC_NUM/2-1 downto 0); -- DUC IQ Data Sync
    DL_IQ_IN                      : in  std_logic_vector(16*(DUC_NUM/2)-1 downto 0); -- DUC IQ Data

    B8_DL_SYNC_IN                 : in  std_logic_vector( DUC_NUM/2-1 downto 0); -- DUC IQ Data Sync
    B8_DL_IQ_IN                   : in  std_logic_vector(16*(DUC_NUM/2)-1 downto 0); -- DUC IQ Data

    UL_SYNC_OUT                   : out std_logic_vector( DDC_NUM/2-1 downto 0); -- DDC IQ Data Sync
    UL_IQ_OUT                     : out std_logic_vector(16*(DDC_NUM/2)-1 downto 0); -- DDC IQ Data

    B8_NR_UL_SYNC_OUT             : out std_logic_vector( DDC_NUM/2-1 downto 0); -- DDC IQ Data Sync
    B8_NR_UL_IQ_OUT               : out std_logic_vector(16*(DDC_NUM/2)-1 downto 0); -- DDC IQ Data

--    -- =======================================
--    -- ORAN SA NBIOT
--    -- =======================================
--    I_B20_NBIOT_NCO_VALID_CC0         : in  std_logic;
--    I_B20_NBIOT_NCO_VALID_CC1         : in  std_logic;
--    I_B20_NBIOT_ORAN_FR_STRUCT_CC0    : in  std_logic_vector(7 downto 0);
--    I_B20_NBIOT_ORAN_FR_STRUCT_CC1    : in  std_logic_vector(7 downto 0);
--    I_B20_NBIOT_FREQ_OFFSET_CC0       : in  std_logic_vector(23 downto 0);
--    I_B20_NBIOT_FREQ_OFFSET_CC1       : in  std_logic_vector(23 downto 0);
--
--    I_B8_NBIOT_NCO_VALID_CC0         : in  std_logic;
--    I_B8_NBIOT_NCO_VALID_CC1         : in  std_logic;
--    I_B8_NBIOT_ORAN_FR_STRUCT_CC0    : in  std_logic_vector(7 downto 0);
--    I_B8_NBIOT_ORAN_FR_STRUCT_CC1    : in  std_logic_vector(7 downto 0);
--    I_B8_NBIOT_FREQ_OFFSET_CC0       : in  std_logic_vector(23 downto 0);
--    I_B8_NBIOT_FREQ_OFFSET_CC1       : in  std_logic_vector(23 downto 0);

    -- ***************************
    -- DACIF_TOP Interface
    -- ***************************
    -- TDD & BFN Strobe
    DL_BFN_STRB_OUT               : out std_logic;                                    -- Delayed Downlink 10ms Frame Sync Strobe as DL Path Latency
    DL_SSB_STRB_OUT               : out std_logic;                                    -- Delayed Downlink 10ms Frame Sync Strobe as DL Path Latency
    DL_TDD_OUT                    : out std_logic;                                    -- Delayed Downlink TDD Strobe as DL Path Latency


    FB_BFN_STRB_IN                : in  std_logic;                                    -- Feedback 10ms Frame Sync Strobe
--    FB_TDD_IN                     : in  std_logic;                                    -- Feedback TDD Strobe
    FB_SSB_STRB_IN                : in  std_logic;                                    -- 40ms sync signal for SSB power measurment, 19.10.03

    UL_BFN_STRB_IN                : in  std_logic;                                    -- Uplink 10ms Frame Sync Strobe
--    UL_TDD_IN                     : in  std_logic;                                    -- Uplink TDD Strobe

    BCF_ENB_OUT                   : out std_logic;

    -- Traffic IQ
    DL_SYNC_OUT                   : out std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);     -- DSP_TOP output IQ sample valid
    DL_I_OUT                      : out std_logic_vector(16*TOTAL_TX_ANT_NUM-1 downto 0);     -- DSP_TOP output I data
    DL_Q_OUT                      : out std_logic_vector(16*TOTAL_TX_ANT_NUM-1 downto 0);     -- DSP_TOP output Q data

    FB_SYNC_IN                    : in  std_logic_vector( FB_PATH_NUM-1 downto 0);    -- Feedback Path IQ sample valid
    FB_I_IN                       : in  std_logic_vector(16*FB_PATH_NUM-1 downto 0);    -- Feedback Path I data
    FB_Q_IN                       : in  std_logic_vector(16*FB_PATH_NUM-1 downto 0);    -- Feedback Path Q data

    UL_SYNC_IN                    : in  std_logic_vector( TOTAL_RX_ANT_NUM-1 downto 0);     -- DSP_TOP Input IQ sample valid
    UL_I_IN                       : in  std_logic_vector(16*TOTAL_RX_ANT_NUM-1 downto 0);     -- DSP_TOP Input I data
    UL_Q_IN                       : in  std_logic_vector(16*TOTAL_RX_ANT_NUM-1 downto 0);     -- DSP_TOP Input Q data

    -- ***************************
    -- SBIF_TOP Interface for PIM
    -- ***************************
    PIM_SYNC_IN                   : in  std_logic_vector(PIM_SBIF_NUM-1 downto 0);
    PIM_I_IN                      : in  std_logic_vector(15*PIM_SBIF_NUM-1 downto 0);
    PIM_Q_IN                      : in  std_logic_vector(15*PIM_SBIF_NUM-1 downto 0);

    PIM_SYNC_OUT                  : out std_logic_vector(PIM_SBIF_NUM-1 downto 0);
    PIM_I_OUT                     : out std_logic_vector(15*PIM_SBIF_NUM-1 downto 0);
    PIM_Q_OUT                     : out std_logic_vector(15*PIM_SBIF_NUM-1 downto 0);

    -- ***************************
    -- MISC_TOP Interface
    -- ***************************
    FBSW_SSB_IND_FLAG_DSP         : in  std_logic;
    -- Feedback Switch
    FBSW_START_TRIG_IN            : in  std_logic;                                    -- Start Pulse of Feedback Switch Period
    FBSW_CNT_IN                   : in  std_logic_vector( 6 downto 0);                -- Feedback Switch Counter
    FBSW_AUTO_MODE_DONE_IN        : in  std_logic_vector( FB_PATH_NUM-1 downto 0);    -- Feedback Switch Automode Done Flag, '0': Auto Mode
    FBSW_PWR_MSR_UDT_IN           : in  std_logic;                                    -- Feedback Switch Measure Done, Feedback Power Measure Update Enable
    FBSW_MANUAL_MODE_IN           : in  std_logic;                                    -- Feedback Switch Manual Mode, '1': Manual Mode
    FBSW_SC_PATH_SEL_OUT          : out std_logic_vector(5*2-1 downto 0);
    PWR_MSR_FB_SYNC_IN            : in  std_logic;                                    -- Feedback Power Measure Feedback Sync / 20ms sync
    PWR_MSR_EN_IN                 : in  std_logic;                                    -- Feedback Power Measure Enable

    -- Signal Suspension
    SIG_SUS_FLAG_OUT              : out std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);     -- OPD Detect Flag
    SIG_SUS_DLOFF_IN              : in  std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);     -- Wave-Stop Flag

    -- IQ/Clock Status
    DL_IQ_ISZERO_OUT              : out std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);     -- '1': IQ is Zero, '0': IQ is Non-Zero
    DL_CLK_ISZERO_OUT             : out std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);     --

    -- Test Pattern (Reserved)
--    TEST_DATA_IN                  : in  std_logic_array32(1 downto 0);                -- ETM Generator of Fixed Pattern Generator, Test Data for Clock Domain#0/#1
--    TEST_DENB_OUT                 : out std_logic_vector( 1 downto 0);                -- Test Pattern Memory Read Enable

    -- Dump
    DUMP_BFN_STRB_OUT             : out std_logic_vector( 1 downto 0);                -- Delayed 10ms Frame Sync Strobe for DUMP
    DUMP_DVLD_OUT                 : out std_logic_vector( 1 downto 0);                -- Dump Sample Valid
    DUMP_DATA_OUT                 : out std_logic_vector(32*2-1 downto 0);                -- Dump Sample

    -- ***************************
    -- TOP Port Interface
    -- ***************************
    -- FPGA ID
--    FPGA_ID_IN                    : in  std_logic_vector( 2 downto 0);                -- FPGA HardWare ID

    -- Debugging Port(Reserved)
    DBG_SIG_OUT                   : out std_logic_vector(32*2-1 downto 0)--;                -- For Block Debugging, Reserved Output

    );

end DSP_TOP_vhd;

architecture BEHAVE of DSP_TOP_vhd is


signal arr_DL_CHBW_IN                :  std_logic_array4( DUC_NUM/2-1 downto 0);          --  in 
signal arr_DL_IQ_IN                  :  std_logic_array16(DUC_NUM/2-1 downto 0);          --  in 
signal arr_B8_DL_IQ_IN               :  std_logic_array16(DUC_NUM/2-1 downto 0);          --  in 
signal arr_B8_DL_CHBW_IN             :  std_logic_array4( DUC_NUM/2-1 downto 0);          --  in
 
signal arr_UL_CHBW_IN                :  std_logic_array4( DDC_NUM/2-1 downto 0);          --  in 
signal arr_B8_UL_CHBW_IN             :  std_logic_array4( DDC_NUM/2-1 downto 0);          --  in 
signal arr_UL_IQ_OUT                 :  std_logic_array16(DDC_NUM/2-1 downto 0);          --  out
signal arr_B8_NR_UL_IQ_OUT           :  std_logic_array16(DDC_NUM/2-1 downto 0);          --  out

signal arr_UL_I_IN                   :  std_logic_array16(TOTAL_RX_ANT_NUM-1 downto 0);   --  in 
signal arr_UL_Q_IN                   :  std_logic_array16(TOTAL_RX_ANT_NUM-1 downto 0);   --  in 

signal arr_DL_I_OUT                  :  std_logic_array16(TOTAL_TX_ANT_NUM-1 downto 0);   --  out
signal arr_DL_Q_OUT                  :  std_logic_array16(TOTAL_TX_ANT_NUM-1 downto 0);  

signal arr_FB_I_IN                   :  std_logic_array16(FB_PATH_NUM-1 downto 0);    	  --  in 
signal arr_FB_Q_IN                   :  std_logic_array16(FB_PATH_NUM-1 downto 0);    	  --  in 

signal arr_PIM_I_IN                  :  std_logic_array15(PIM_SBIF_NUM-1 downto 0);       --  in 
signal arr_PIM_Q_IN                  :  std_logic_array15(PIM_SBIF_NUM-1 downto 0);       --  in 
signal arr_PIM_I_OUT                 :  std_logic_array15(PIM_SBIF_NUM-1 downto 0);       --  out
signal arr_PIM_Q_OUT                 :  std_logic_array15(PIM_SBIF_NUM-1 downto 0);       --  out

signal arr_FBSW_SC_PATH_SEL_OUT      :  std_logic_array5( 1 downto 0);                    --  out
signal arr_DUMP_DATA_OUT             :  std_logic_array32(1 downto 0);                    --  out
signal arr_DBG_SIG_OUT               :  std_logic_array32(1 downto 0);	                  --  out


begin

gen_vhd_to_v : if TRUE generate

        gen_1: for i in 0 to DUC_NUM/2-1 generate
        begin    
            -- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
			arr_DL_CHBW_IN   (i)    <= DL_CHBW_IN    (4*i+3 downto 4*i);
			arr_DL_IQ_IN     (i)	<= DL_IQ_IN      (16*i+15 downto 16*i);		
			arr_B8_DL_IQ_IN  (i)	<= B8_DL_IQ_IN   (16*i+15 downto 16*i);		
			arr_B8_DL_CHBW_IN(i)	<= B8_DL_CHBW_IN (4*i+3 downto 4*i);		
            -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
        end generate;
		
        gen_2: for i in 0 to DDC_NUM/2-1 generate
        begin
            -- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
			arr_UL_CHBW_IN        (i)  <=   UL_CHBW_IN      (4*i+3 downto 4*i) ;
			arr_B8_UL_CHBW_IN     (i)  <=   B8_UL_CHBW_IN   (4*i+3 downto 4*i) ;
		
            -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
			UL_IQ_OUT         (16*i+15 downto 16*i)  <=   arr_UL_IQ_OUT       (i) ;
			B8_NR_UL_IQ_OUT   (16*i+15 downto 16*i)  <=   arr_B8_NR_UL_IQ_OUT (i) ;	
        end generate;
		
        gen_3: for i in 0 to TOTAL_RX_ANT_NUM-1 generate
        begin
        
            -- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
			arr_UL_I_IN (i) <=  UL_I_IN  (16*i+15 downto 16*i);
			arr_UL_Q_IN	(i) <=  UL_Q_IN  (16*i+15 downto 16*i);
            -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);

        end generate;	
		
        gen_4: for i in 0 to TOTAL_TX_ANT_NUM-1 generate
        begin
        
            -- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 

            -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
			DL_I_OUT (16*i+15 downto 16*i) <= arr_DL_I_OUT(i) ;
			DL_Q_OUT (16*i+15 downto 16*i) <= arr_DL_Q_OUT(i) ;

        end generate;	
		
        gen_5: for i in 0 to FB_PATH_NUM-1 generate
        begin 
            -- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
			arr_FB_I_IN  (i) <=  FB_I_IN (16*i+15 downto 16*i) ;
			arr_FB_Q_IN  (i) <=  FB_Q_IN (16*i+15 downto 16*i) ;
            -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
        end generate;
		
        gen_6: for i in 0 to PIM_SBIF_NUM-1 generate
        begin 
            -- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
			arr_PIM_I_IN (i) <= PIM_I_IN  (15*i+14 downto 15*i) ;
			arr_PIM_Q_IN (i) <= PIM_Q_IN  (15*i+14 downto 15*i) ;
            -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
			PIM_I_OUT (15*i+14 downto 15*i) <= arr_PIM_I_OUT (i); 
			PIM_Q_OUT (15*i+14 downto 15*i) <= arr_PIM_Q_OUT (i);	
        end generate;
		

        gen_7: for i in 0 to 2-1 generate
        begin 
            -- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
            -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);

			FBSW_SC_PATH_SEL_OUT (5*i+4 downto 5*i) <= arr_FBSW_SC_PATH_SEL_OUT (i) ;
			DUMP_DATA_OUT        (32*i+31 downto 32*i) <= arr_DUMP_DATA_OUT     (i) ;		
			DBG_SIG_OUT          (32*i+31 downto 32*i) <= arr_DBG_SIG_OUT       (i) ;
			
        end generate;
    
 end generate;   
        
    
    DSP_vhd : entity work.DSP_TOP

    port map(
    

    -- ***************************
    -- SYSCTRL_TOP Interface
    -- ***************************
    -- Internal PLL Lock
    INT_SYSPLL_LOCK_IN            =>  INT_SYSPLL_LOCK_IN     ,                                    -- Internal System PLL Lock

    -- System Reset & Clock
    RST_DDUC                      =>  RST_DDUC     ,                                    -- DDUC_TOP Reset, '1'=>  Reset
    RST_CFR                       =>  RST_CFR      ,                                    -- CFR_TOP Reset,  '1'=>  Reset
    RST_DPD                       =>  RST_DPD      ,                                    -- DPD_TOP Reset,  '1'=>  Reset
    RST_PIM                       =>  RST_PIM      ,

    CLK_SYS                       =>  CLK_SYS        ,                                    -- System Clock =>   30.72 MHz
    CLK_SYSX2                     =>  CLK_SYSX2      ,                                    --  2x(CLK_SYS) =>   61.44 MHz
    CLK_SYSX3                     =>  CLK_SYSX3      ,                                    --  3x(CLK_SYS) =>   92.16 MHz
    CLK_SYSX4                     =>  CLK_SYSX4      ,                                    --  4x(CLK_SYS) =>  122.88 MHz
    CLK_SYSX5                     =>  CLK_SYSX5      ,                                    --  5x(CLK_SYS) =>  153.60 MHz
    CLK_SYSX6                     =>  CLK_SYSX6      ,                                    --  6x(CLK_SYS) =>  184.32 MHz
    CLK_SYSX8                     =>  CLK_SYSX8      ,                                    --  8x(CLK_SYS) =>  245.76 MHz
    CLK_SYSX10                    =>  CLK_SYSX10     ,                                    -- 10x(CLK_SYS) =>  307.20 MHz
    CLK_SYSX12                    =>  CLK_SYSX12     ,                                    -- 12x(CLK_SYS) =>  368.64 MHz
    CLK_SYSX16                    =>  CLK_SYSX16     ,                                    -- 16x(CLK_SYS) =>  491.52 MHz
    CLK_SYSX20                    =>  CLK_SYSX20     ,                                    -- 20x(CLK_SYS) =>  614.40 MHz

    -- ***************************
    -- CPU_TOP Interface
    -- ***************************
    -- CPU Reset & Clock
    RST_CPUIF                     =>  RST_CPUIF     ,                                    -- CPUIF Reset, '1'=>  Reset
    CLK_CPUIF                     =>  CLK_CPUIF     ,                                    -- CPUIF Clock, Faster than iclk/oclk

--    RST_DPDIF                     =>  in  std_logic     ,                                    -- CPUIF Reset, '1'=>  Reset
--    CLK_DPDIF                     =>  in  std_logic     ,                                    -- CPUIF Clock, Faster than iclk/oclk

    -- ***************************
    -- CPUIF_TOP Interface
    -- ***************************
    -- CPUIF DSP Common
    ADDR_CPUIF_IN                 =>  ADDR_CPUIF_IN   ,    -- CPUIF Address Input, WORD Address
    WDATA_CPUIF_IN                =>  WDATA_CPUIF_IN  ,    -- CPUIF Data Input
    RDATA_CPUIF_OUT               =>  RDATA_CPUIF_OUT ,    -- CPUIF DATA Output
    WREN_CPUIF_IN                 =>  WREN_CPUIF_IN   ,    -- CPUIF Write Enable,    '1'=>  Active, Synchronous with iclk
    RDEN_CPUIF_IN                 =>  RDEN_CPUIF_IN   ,    -- CPUIF Read Enable,     '1'=>  Active,
    RDVLD_CPUIF_OUT               =>  RDVLD_CPUIF_OUT ,    -- CPUIF Read Data Valid, '1'=>  Active, Synchronous with clk_cpu

    -- CPUIF DPD
    ADDR_DPD0IF_IN                 =>  ADDR_DPD0IF_IN   ,   -- CPUIF Address Input, WORD Address
    WDATA_DPD0IF_IN                =>  WDATA_DPD0IF_IN  ,   -- CPUIF Data Input
    RDATA_DPD0IF_OUT               =>  RDATA_DPD0IF_OUT ,   -- CPUIF DATA Output
    WREN_DPD0IF_IN                 =>  WREN_DPD0IF_IN   ,   -- CPUIF Write Enable,    '1'=>  Active, Synchronous with iclk
    RDEN_DPD0IF_IN                 =>  RDEN_DPD0IF_IN   ,   -- CPUIF Read Enable,     '1'=>  Active,
    RDVLD_DPD0IF_OUT               =>  RDVLD_DPD0IF_OUT ,   -- CPUIF Read Data Valid, '1'=>  Active, Synchronous with clk_cpu

    ADDR_DPD1IF_IN                 =>  ADDR_DPD1IF_IN   ,     -- CPUIF Address Input, WORD Address
    WDATA_DPD1IF_IN                =>  WDATA_DPD1IF_IN  ,     -- CPUIF Data Input
    RDATA_DPD1IF_OUT               =>  RDATA_DPD1IF_OUT ,     -- CPUIF DATA Output
    WREN_DPD1IF_IN                 =>  WREN_DPD1IF_IN   ,     -- CPUIF Write Enable,    '1'=>  Active, Synchronous with iclk
    RDEN_DPD1IF_IN                 =>  RDEN_DPD1IF_IN   ,     -- CPUIF Read Enable,     '1'=>  Active,
    RDVLD_DPD1IF_OUT               =>  RDVLD_DPD1IF_OUT ,     -- CPUIF Read Data Valid, '1'=>  Active, Synchronous with clk_cpu

    -- ***************************
    -- BBCTRL_TOP Interface
    -- ***************************
    -- System Information
--    DL_AIRTECH_IN                 =>  in  std_logic_array4( DUC_NUM-1 downto 0)     , -- System Type, 0x0=>  LTE, 0x1=> UMTS
    DL_CHBW_IN                    =>  arr_DL_CHBW_IN     , -- Bandwidth,   0x0=>  5M,  0x1=>  10M, 0x2=>  15M, 0x3=>  20M

--    UL_AIRTECH_IN                 =>  in  std_logic_array4( DDC_NUM-1 downto 0)     , -- System Type, 0x0=>  LTE, 0x1=> UMTS
    UL_CHBW_IN                    =>  arr_UL_CHBW_IN     , -- Bandwidth,   0x0=>  5M,  0x1=>  10M, 0x2=>  15M, 0x3=>  20M

--    B8_DL_AIRTECH_IN              =>  in  std_logic_array4( DUC_NUM-1 downto 0)     , -- System Type, 0x0=>  LTE, 0x1=> UMTS
    B8_DL_CHBW_IN                 =>  arr_B8_DL_CHBW_IN     , -- Bandwidth,   0x0=>  5M,  0x1=>  10M, 0x2=>  15M, 0x3=>  20M

--    B8_UL_AIRTECH_IN              =>  in  std_logic_array4( DDC_NUM-1 downto 0)     , -- System Type, 0x0=>  LTE, 0x1=> UMTS
    B8_UL_CHBW_IN                 =>  arr_B8_UL_CHBW_IN     , -- Bandwidth,   0x0=>  5M,  0x1=>  10M, 0x2=>  15M, 0x3=>  20M

    -- TDD & BFN Strobe
    DL_BFN_STRB_IN                =>  DL_BFN_STRB_IN      ,                                    -- Downlink 10ms Frame Sync Strobe
    DL_SSB_STRB_IN                =>  DL_SSB_STRB_IN      ,                                    -- Downlink SSB period Strobe (20/40/80/160msec)
    DL_TDD_IN                     =>  DL_TDD_IN           ,                                    -- Downlink TDD Strobe
									  
    UL_BFN_STRB_OUT               =>  UL_BFN_STRB_OUT     ,                                    -- Delayed Uplink 10ms Frame Sync Strobe as UL Path Latency
    UL_TDD_OUT                    =>  UL_TDD_OUT          ,                                    -- Delayed Uplink TDD Strobe as UL Path Latency
									  
    BCF_ENB_IN                    =>  BCF_ENB_IN          ,

    -- Traffic IQ
    DL_SYNC_IN                    =>  DL_SYNC_IN     , -- DUC IQ Data Sync
    DL_IQ_IN                      =>  arr_DL_IQ_IN     , -- DUC IQ Data

    B8_DL_SYNC_IN                 =>  B8_DL_SYNC_IN     , -- DUC IQ Data Sync
    B8_DL_IQ_IN                   =>  arr_B8_DL_IQ_IN     , -- DUC IQ Data

    UL_SYNC_OUT                   =>  UL_SYNC_OUT     , -- DDC IQ Data Sync
    UL_IQ_OUT                     =>  arr_UL_IQ_OUT     , -- DDC IQ Data

    B8_NR_UL_SYNC_OUT             =>  B8_NR_UL_SYNC_OUT     , -- DDC IQ Data Sync
    B8_NR_UL_IQ_OUT               =>  arr_B8_NR_UL_IQ_OUT     , -- DDC IQ Data

--    -- =======================================
--    -- ORAN SA NBIOT
--    -- =======================================
--    I_B20_NBIOT_NCO_VALID_CC0         =>  in  std_logic     ,
--    I_B20_NBIOT_NCO_VALID_CC1         =>  in  std_logic     ,
--    I_B20_NBIOT_ORAN_FR_STRUCT_CC0    =>  in  std_logic_vector(7 downto 0)     ,
--    I_B20_NBIOT_ORAN_FR_STRUCT_CC1    =>  in  std_logic_vector(7 downto 0)     ,
--    I_B20_NBIOT_FREQ_OFFSET_CC0       =>  in  std_logic_vector(23 downto 0)     ,
--    I_B20_NBIOT_FREQ_OFFSET_CC1       =>  in  std_logic_vector(23 downto 0)     ,
--
--    I_B8_NBIOT_NCO_VALID_CC0         =>  in  std_logic     ,
--    I_B8_NBIOT_NCO_VALID_CC1         =>  in  std_logic     ,
--    I_B8_NBIOT_ORAN_FR_STRUCT_CC0    =>  in  std_logic_vector(7 downto 0)     ,
--    I_B8_NBIOT_ORAN_FR_STRUCT_CC1    =>  in  std_logic_vector(7 downto 0)     ,
--    I_B8_NBIOT_FREQ_OFFSET_CC0       =>  in  std_logic_vector(23 downto 0)     ,
--    I_B8_NBIOT_FREQ_OFFSET_CC1       =>  in  std_logic_vector(23 downto 0)     ,

    -- ***************************
    -- DACIF_TOP Interface
    -- ***************************
    -- TDD & BFN Strobe
    DL_BFN_STRB_OUT               =>  DL_BFN_STRB_OUT     ,                                    -- Delayed Downlink 10ms Frame Sync Strobe as DL Path Latency
    DL_SSB_STRB_OUT               =>  DL_SSB_STRB_OUT     ,                                    -- Delayed Downlink 10ms Frame Sync Strobe as DL Path Latency
    DL_TDD_OUT                    =>  DL_TDD_OUT          ,                                    -- Delayed Downlink TDD Strobe as DL Path Latency


    FB_BFN_STRB_IN                =>  FB_BFN_STRB_IN     ,                                    -- Feedback 10ms Frame Sync Strobe
--    FB_TDD_IN                     =>  in  std_logic     ,                                    -- Feedback TDD Strobe
    FB_SSB_STRB_IN                =>  FB_SSB_STRB_IN     ,                                    -- 40ms sync signal for SSB power measurment, 19.10.03

    UL_BFN_STRB_IN                =>  UL_BFN_STRB_IN     ,                                    -- Uplink 10ms Frame Sync Strobe
--    UL_TDD_IN                     =>  in  std_logic     ,                                    -- Uplink TDD Strobe

    BCF_ENB_OUT                   =>  BCF_ENB_OUT    ,

    -- Traffic IQ
    DL_SYNC_OUT                   =>  DL_SYNC_OUT     ,     -- DSP_TOP output IQ sample valid
    DL_I_OUT                      =>  arr_DL_I_OUT     ,     -- DSP_TOP output I data
    DL_Q_OUT                      =>  arr_DL_Q_OUT     ,     -- DSP_TOP output Q data

    FB_SYNC_IN                    =>  FB_SYNC_IN     ,    -- Feedback Path IQ sample valid
    FB_I_IN                       =>  arr_FB_I_IN    ,    -- Feedback Path I data
    FB_Q_IN                       =>  arr_FB_Q_IN    ,    -- Feedback Path Q data

    UL_SYNC_IN                    =>  UL_SYNC_IN    ,     -- DSP_TOP Input IQ sample valid
    UL_I_IN                       =>  arr_UL_I_IN     ,     -- DSP_TOP Input I data
    UL_Q_IN                       =>  arr_UL_Q_IN     ,     -- DSP_TOP Input Q data

    -- ***************************
    -- SBIF_TOP Interface for PIM
    -- ***************************
    PIM_SYNC_IN                   =>  PIM_SYNC_IN     ,
    PIM_I_IN                      =>  arr_PIM_I_IN     ,
    PIM_Q_IN                      =>  arr_PIM_Q_IN     ,

    PIM_SYNC_OUT                  =>  PIM_SYNC_OUT     ,
    PIM_I_OUT                     =>  arr_PIM_I_OUT    ,
    PIM_Q_OUT                     =>  arr_PIM_Q_OUT    ,

    -- ***************************
    -- MISC_TOP Interface
    -- ***************************
    FBSW_SSB_IND_FLAG_DSP         =>  FBSW_SSB_IND_FLAG_DSP    ,
    -- Feedback Switch
    FBSW_START_TRIG_IN            =>  FBSW_START_TRIG_IN     ,                                    -- Start Pulse of Feedback Switch Period
    FBSW_CNT_IN                   =>  FBSW_CNT_IN     ,                -- Feedback Switch Counter
    FBSW_AUTO_MODE_DONE_IN        => FBSW_AUTO_MODE_DONE_IN     ,    -- Feedback Switch Automode Done Flag, '0'=>  Auto Mode
    FBSW_PWR_MSR_UDT_IN           =>  FBSW_PWR_MSR_UDT_IN     ,                                    -- Feedback Switch Measure Done, Feedback Power Measure Update Enable
    FBSW_MANUAL_MODE_IN           =>  FBSW_MANUAL_MODE_IN    ,                                    -- Feedback Switch Manual Mode, '1'=>  Manual Mode
    FBSW_SC_PATH_SEL_OUT          =>  arr_FBSW_SC_PATH_SEL_OUT     ,
    PWR_MSR_FB_SYNC_IN            =>  PWR_MSR_FB_SYNC_IN    ,                                    -- Feedback Power Measure Feedback Sync / 20ms sync
    PWR_MSR_EN_IN                 => PWR_MSR_EN_IN    ,                                    -- Feedback Power Measure Enable

    -- Signal Suspension
    SIG_SUS_FLAG_OUT              =>  SIG_SUS_FLAG_OUT     ,     -- OPD Detect Flag
    SIG_SUS_DLOFF_IN              =>  SIG_SUS_DLOFF_IN     ,     -- Wave-Stop Flag

    -- IQ/Clock Status
    DL_IQ_ISZERO_OUT              =>  DL_IQ_ISZERO_OUT     ,     -- '1'=>  IQ is Zero, '0'=>  IQ is Non-Zero
    DL_CLK_ISZERO_OUT             =>  DL_CLK_ISZERO_OUT     ,     --

    -- Test Pattern (Reserved)
	--    TEST_DATA_IN                  =>  in  std_logic_array32(1 downto 0)     ,                -- ETM Generator of Fixed Pattern Generator, Test Data for Clock Domain#0/#1
	--    TEST_DENB_OUT                 =>  out std_logic_vector( 1 downto 0)     ,                -- Test Pattern Memory Read Enable

    -- Dump
    DUMP_BFN_STRB_OUT             =>  DUMP_BFN_STRB_OUT     ,                -- Delayed 10ms Frame Sync Strobe for DUMP
    DUMP_DVLD_OUT                 =>  DUMP_DVLD_OUT    ,                -- Dump Sample Valid
    DUMP_DATA_OUT                 =>  arr_DUMP_DATA_OUT     ,                -- Dump Sample

    -- ***************************
    -- TOP Port Interface
    -- ***************************
    -- FPGA ID	
	--    FPGA_ID_IN                    =>  in  std_logic_vector( 2 downto 0)     ,                -- FPGA HardWare ID

    -- Debugging Port(Reserved)
    DBG_SIG_OUT                   =>  arr_DBG_SIG_OUT                    -- For Block Debugging, Reserved Output

    );


end BEHAVE;