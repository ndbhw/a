library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.D_ARRAY_TYPE.ALL;
use WORK.RU_DFPGA_CONFIG.ALL;

entity BBCTRL_TOP_vhd is
    port (
    

--------------------------------------------------------------------------------
-- SYSCTRL_TOP
--------------------------------------------------------------------------------

        RST_BBCTRL                  : in  std_logic;

        CLK_CPRI                    : in  std_logic_vector(SBIF_NUM-1 downto 0);

        CLK_SYS                     : in  std_logic;
        CLK_SYSX2                   : in  std_logic;
        CLK_SYSX3                   : in  std_logic;
        CLK_SYSX4                   : in  std_logic;
        CLK_SYSX5                   : in  std_logic;
        CLK_SYSX6                   : in  std_logic;
        CLK_SYSX8                   : in  std_logic;
        CLK_SYSX10                  : in  std_logic;
        CLK_SYSX12                  : in  std_logic;
        CLK_SYSX16                  : in  std_logic;
        CLK_SYSX20                  : in  std_logic;

        RX_120MS_STRB_IN            : in  std_logic_vector(SBIF_NUM-1 downto 0);
        RX_BFN_STRB_IN              : in  std_logic_vector(SBIF_NUM-1 downto 0);
        RX_BFN_NR_IN                : in  std_logic_vector(12*SBIF_NUM-1 downto 0);
        RX_TDD_IN                   : in  std_logic_vector(SBIF_NUM-1 downto 0);

        TX_BFN_STRB_IN              : in  std_logic_vector(SBIF_NUM-1 downto 0);
        TX_BFN_NR_IN                : in  std_logic_vector(12*SBIF_NUM-1 downto 0);
        TX_TDD_OUT                  : out std_logic_vector(SBIF_NUM-1 downto 0);
        TX_BFN_STRB_OUT             : out std_logic_vector(SBIF_NUM-1 downto 0);

        SSB_OFFSET                  : in  std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- CPU_TOP
--------------------------------------------------------------------------------

        RST_CPUIF                   : in  std_logic;
        CLK_CPUIF                   : in  std_logic;

--------------------------------------------------------------------------------
-- CPUIF_TOP
--------------------------------------------------------------------------------

        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);    
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             : out std_logic;

--------------------------------------------------------------------------------
-- SBIF_TOP
--------------------------------------------------------------------------------

        SBIF_RX_VLD_IN              : in  std_logic_vector(SBIF_NUM-1 downto 0);
        SBIF_RX_I_IN                : in  std_logic_vector(16*SBIF_NUM-1 downto 0);
        SBIF_RX_Q_IN                : in  std_logic_vector(16*SBIF_NUM-1 downto 0);

        SBIF_TX_ENB_IN              : in  std_logic_vector(SBIF_NUM-1 downto 0);
        SBIF_TX_I_OUT               : out std_logic_vector(16*SBIF_NUM-1 downto 0);
        SBIF_TX_Q_OUT               : out std_logic_vector(16*SBIF_NUM-1 downto 0);

--------------------------------------------------------------------------------
-- DSP_TOP
--------------------------------------------------------------------------------

        DL_BFN_OK                   : out std_logic;

        DL_AIRTECH_OUT              : out std_logic_vector(4*DL_BBIQARY_NUM-1 downto 0);
        DL_CHBW_OUT                 : out std_logic_vector(4*DL_BBIQARY_NUM-1 downto 0);
        DL_TDD_OUT                  : out std_logic;
        DL_40MS_OUT                 : out std_logic;
        DL_BFN_STRB_OUT             : out std_logic;
        DL_BFN_OUT                  : out std_logic_vector(11 downto 0);
        DL_SYNC_OUT                 : out std_logic_vector(DL_BBIQARY_NUM-1 downto 0);
        DL_IQ_OUT                   : out std_logic_vector(16*DL_BBIQARY_NUM-1 downto 0);

        UL_AIRTECH_OUT              : out std_logic_vector(4*UL_BBIQARY_NUM-1 downto 0);
        UL_CHBW_OUT                 : out std_logic_vector(4*UL_BBIQARY_NUM-1 downto 0);
        UL_TDD_IN                   : in  std_logic;
        UL_BFN_STRB_IN              : in  std_logic;
        UL_SYNC_IN                  : in  std_logic_vector(UL_BBIQARY_NUM-1 downto 0);
        UL_IQ_IN                    : in  std_logic_vector(16*UL_BBIQARY_NUM-1 downto 0);

--------------------------------------------------------------------------------
-- MISC_TOP
--------------------------------------------------------------------------------

        DUMP_BFN_STRB_OUT           : out std_logic_vector(1 downto 0);
        DUMP_DATA_OUT               : out std_logic_vector(32*2-1 downto 0);
        DUMP_DVLD_OUT               : out std_logic_vector(1 downto 0);

     -- fb_sw_new
        FBSW_CNT                    : in  std_logic_vector(3 downto 0);
        FBSW_SSB_IND_FLAG           : in  std_logic; 
        FBSW_MEAS_UPDATE            : in  std_logic



    );

end BBCTRL_TOP_vhd;

architecture BEHAVE of BBCTRL_TOP_vhd is


signal arr_RX_BFN_NR_IN      : std_logic_array12(SBIF_NUM-1 downto 0);        -- in 
signal arr_TX_BFN_NR_IN      : std_logic_array12(SBIF_NUM-1 downto 0);        -- in 
signal arr_SBIF_RX_I_IN      : std_logic_array16(SBIF_NUM-1 downto 0);        -- in 
signal arr_SBIF_RX_Q_IN      : std_logic_array16(SBIF_NUM-1 downto 0);        -- in 
signal arr_SBIF_TX_I_OUT     : std_logic_array16(SBIF_NUM-1 downto 0);        -- out
signal arr_SBIF_TX_Q_OUT     : std_logic_array16(SBIF_NUM-1 downto 0);        -- out

signal arr_DL_AIRTECH_OUT    : std_logic_array4(DL_BBIQARY_NUM-1 downto 0);   -- out
signal arr_DL_CHBW_OUT       : std_logic_array4(DL_BBIQARY_NUM-1 downto 0);   -- out
signal arr_DL_IQ_OUT         : std_logic_array16(DL_BBIQARY_NUM-1 downto 0);  -- out

signal arr_UL_IQ_IN          : std_logic_array16(UL_BBIQARY_NUM-1 downto 0);  -- in 
signal arr_UL_AIRTECH_OUT    : std_logic_array4(UL_BBIQARY_NUM-1 downto 0);   -- out
signal arr_UL_CHBW_OUT       : std_logic_array4(UL_BBIQARY_NUM-1 downto 0);   -- out

signal arr_DUMP_DATA_OUT     : std_logic_array32(1 downto 0);                 -- out


begin

gen_vhd_to_v : if TRUE generate

        gen_1: for i in 0 to SBIF_NUM-1 generate
        begin
        
            -- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
           arr_RX_BFN_NR_IN (i) <= RX_BFN_NR_IN (12*i+11 downto 12*i);
           arr_TX_BFN_NR_IN (i) <= TX_BFN_NR_IN (12*i+11 downto 12*i);
           arr_SBIF_RX_I_IN (i) <= SBIF_RX_I_IN (16*i+15 downto 16*i);
           arr_SBIF_RX_Q_IN (i) <= SBIF_RX_Q_IN (16*i+15 downto 16*i);
           
    
            -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
            SBIF_TX_I_OUT (16*i+15 downto 16*i) <= arr_SBIF_TX_I_OUT(i) ;
            SBIF_TX_Q_OUT (16*i+15 downto 16*i) <= arr_SBIF_TX_Q_OUT(i) ;
            
        end generate;
        
        
        gen_2: for i in 0 to DL_BBIQARY_NUM-1 generate
        begin
        
            -- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
       
            -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
            
            DL_AIRTECH_OUT (4*i+3 downto 4*i) <= arr_DL_AIRTECH_OUT(i) ;
            DL_CHBW_OUT    (4*i+3 downto 4*i) <= arr_DL_CHBW_OUT   (i) ;
            DL_IQ_OUT      (16*i+15 downto 16*i) <= arr_DL_IQ_OUT     (i) ;
    
        end generate;
        
        
        gen_3: for i in 0 to UL_BBIQARY_NUM-1 generate
        begin
        
            -- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
            arr_UL_IQ_IN(i) <= UL_IQ_IN (16*i+15 downto 16*i);
       
            -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
            
            UL_AIRTECH_OUT(4*i+3 downto 4*i) <= arr_UL_AIRTECH_OUT(i);
            UL_CHBW_OUT   (4*i+3 downto 4*i) <= arr_UL_CHBW_OUT   (i);
            
    
        end generate;
        
        
        gen_4: for i in 0 to 2-1 generate
        begin
        
            -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
            DUMP_DATA_OUT (32*i+31 downto 32*i) <= arr_DUMP_DATA_OUT(i);
            
    
        end generate;
    
 end generate;   

   -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
        
    
    BBCTRL_vhd : entity work.BBCTRL_TOP

    port map(
    

--------------------------------------------------------------------------------
-- SYSCTRL_TOP
--------------------------------------------------------------------------------

        RST_BBCTRL                  =>   RST_BBCTRL  ,

        CLK_CPRI                    =>   CLK_CPRI  ,

        CLK_SYS                     =>   CLK_SYS     ,
        CLK_SYSX2                   =>   CLK_SYSX2   ,
        CLK_SYSX3                   =>   CLK_SYSX3   ,
        CLK_SYSX4                   =>   CLK_SYSX4   ,
        CLK_SYSX5                   =>   CLK_SYSX5   ,
        CLK_SYSX6                   =>   CLK_SYSX6   ,
        CLK_SYSX8                   =>   CLK_SYSX8   ,
        CLK_SYSX10                  =>   CLK_SYSX10  ,
        CLK_SYSX12                  =>   CLK_SYSX12  ,
        CLK_SYSX16                  =>   CLK_SYSX16  ,
        CLK_SYSX20                  =>   CLK_SYSX20  ,

        RX_120MS_STRB_IN            =>   RX_120MS_STRB_IN  ,
        RX_BFN_STRB_IN              =>   RX_BFN_STRB_IN    ,
        RX_BFN_NR_IN                =>   arr_RX_BFN_NR_IN ,
        RX_TDD_IN                   =>   RX_TDD_IN  ,

        TX_BFN_STRB_IN              =>   TX_BFN_STRB_IN  ,
        TX_BFN_NR_IN                =>   arr_TX_BFN_NR_IN ,
        TX_TDD_OUT                  =>   TX_TDD_OUT        ,
        TX_BFN_STRB_OUT             =>   TX_BFN_STRB_OUT   ,

        SSB_OFFSET                  =>   SSB_OFFSET  ,

--------------------------------------------------------------------------------
-- CPU_TOP
--------------------------------------------------------------------------------

        RST_CPUIF                   =>   RST_CPUIF ,
        CLK_CPUIF                   =>   CLK_CPUIF ,

--------------------------------------------------------------------------------
-- CPUIF_TOP
--------------------------------------------------------------------------------

        WREN_CPUIF_IN               =>   WREN_CPUIF_IN   ,
        RDEN_CPUIF_IN               =>   RDEN_CPUIF_IN   ,
        ADDR_CPUIF_IN               =>   ADDR_CPUIF_IN   ,
        WDATA_CPUIF_IN              =>   WDATA_CPUIF_IN  ,
        RDATA_CPUIF_OUT             =>   RDATA_CPUIF_OUT ,
        RDVAL_CPUIF_OUT             =>   RDVAL_CPUIF_OUT ,

--------------------------------------------------------------------------------
-- SBIF_TOP
--------------------------------------------------------------------------------

        SBIF_RX_VLD_IN              =>   SBIF_RX_VLD_IN  ,
        SBIF_RX_I_IN                =>   arr_SBIF_RX_I_IN ,
        SBIF_RX_Q_IN                =>   arr_SBIF_RX_Q_IN ,

        SBIF_TX_ENB_IN              =>   SBIF_TX_ENB_IN  ,
        SBIF_TX_I_OUT               =>   arr_SBIF_TX_I_OUT ,
        SBIF_TX_Q_OUT               =>   arr_SBIF_TX_Q_OUT ,

--------------------------------------------------------------------------------
-- DSP_TOP
--------------------------------------------------------------------------------

        DL_BFN_OK                   =>   DL_BFN_OK,

        DL_AIRTECH_OUT              =>   arr_DL_AIRTECH_OUT , 
        DL_CHBW_OUT                 =>   arr_DL_CHBW_OUT    , 
        DL_TDD_OUT                  =>   DL_TDD_OUT      ,
        DL_40MS_OUT                 =>   DL_40MS_OUT     ,
        DL_BFN_STRB_OUT             =>   DL_BFN_STRB_OUT ,
        DL_BFN_OUT                  =>   DL_BFN_OUT      ,
        DL_SYNC_OUT                 =>   DL_SYNC_OUT     ,
        DL_IQ_OUT                   =>   arr_DL_IQ_OUT ,

        UL_AIRTECH_OUT              =>   arr_UL_AIRTECH_OUT ,
        UL_CHBW_OUT                 =>   arr_UL_CHBW_OUT    ,
        UL_TDD_IN                   =>   UL_TDD_IN      ,
        UL_BFN_STRB_IN              =>   UL_BFN_STRB_IN ,
        UL_SYNC_IN                  =>   UL_SYNC_IN     ,
        UL_IQ_IN                    =>   arr_UL_IQ_IN ,

--------------------------------------------------------------------------------
-- MISC_TOP
--------------------------------------------------------------------------------

        DUMP_BFN_STRB_OUT           =>   DUMP_BFN_STRB_OUT  ,
        DUMP_DATA_OUT               =>   arr_DUMP_DATA_OUT ,
        DUMP_DVLD_OUT               =>   DUMP_DVLD_OUT  ,

     -- fb_sw_new
        FBSW_CNT                    =>   FBSW_CNT          ,
        FBSW_SSB_IND_FLAG           =>   FBSW_SSB_IND_FLAG ,
        FBSW_MEAS_UPDATE            =>   FBSW_MEAS_UPDATE  

    );

end BEHAVE;