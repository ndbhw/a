--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2018, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : SBIF Top (Master FPGA)                                        --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2018.04.24                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.D_ARRAY_TYPE.ALL;
use WORK.RU_DFPGA_CONFIG.ALL;

entity Slave_SBIFPHY_TOP_vhd is
    port (
        -- Reset
        RST_CPUIF                           : in    std_logic;                                  -- PS Block Reset.              Asynchronous.       Active High.
        RST_SBIFPHY                         : in    std_logic_vector  (SBIF_NUM-1 downto 0);    -- Transceiver Reset.           CLK_CPUIF Domain.   Active High.

        -- Clock
        CLK_CPUIF                           : in    std_logic;                                  -- 100    MHz. CPU Clk.
        CLK_SBIF                            : in    std_logic_vector  (SBIF_NUM-1 downto 0);    -- 245.76 MHz
        CLK_SBIFXH                          : in    std_logic_vector  (SBIF_NUM-1 downto 0);    -- 122.88 MHz
        CLK_SBIFX2                          : in    std_logic_vector  (SBIF_NUM-1 downto 0);    -- Not-used
        REFCLK_SERDES_IN                    : in    std_logic_vector  (SSREF_NUM-1 downto 0);   -- 122.88 MHz. SerDes Ref. Clk

        -- Connect Interface
        CON_DEL_IN                          : in    std_logic_vector  (        15 downto 0);

        -- Serial Interface
        SERIAL_TX_OUT_P                     : out   std_logic_vector  (SBIF_NUM-1 downto 0);    -- TX(Positive)
        SERIAL_TX_OUT_N                     : out   std_logic_vector  (SBIF_NUM-1 downto 0);    -- TX(Negative)
        SERIAL_RX_IN_P                      : in    std_logic_vector  (SBIF_NUM-1 downto 0);    -- RX(Positive)
        SERIAL_RX_IN_N                      : in    std_logic_vector  (SBIF_NUM-1 downto 0);    -- RX(Negative)

        -- Parallel Interface
        SERDES_TXISK_IN                     : in    std_logic_vector  (8*SBIF_NUM-1 downto 0);    -- TX Sync
        SERDES_TXD_IN                       : in    std_logic_vector  (64*SBIF_NUM-1 downto 0);    -- TX Data
        SERDES_RXISK_OUT                    : out   std_logic_vector  (8*SBIF_NUM-1 downto 0);    -- RX Sync
        SERDES_RXD_OUT                      : out   std_logic_vector  (64*SBIF_NUM-1 downto 0);    -- RX Data
        SERDES_RXERR_OUT                    : out   std_logic_vector  (8*SBIF_NUM-1 downto 0);    -- RX Error
        SBIF_LOF_IN                         : in    std_logic_vector  (SBIF_NUM-1 downto 0);

        -- CPU Interface
        ADDR_CPUIF_IN                       : in    std_logic_vector  (        15 downto 0);
        WDATA_CPUIF_IN                      : in    std_logic_vector  (        31 downto 0);
        RDATA_CPUIF_OUT                     : out   std_logic_vector  (        31 downto 0);
        WREN_CPUIF_IN                       : in    std_logic;
        RDEN_CPUIF_IN                       : in    std_logic;
        RDVAL_CPUIF_OUT                     : out   std_logic;

        -- Debug
        DBG_SIG_OUT                         : out   std_logic_vector (32*2-1 downto 0);

        -- Dump
        DUMP_BFN_STRB_OUT                   : out   std_logic_vector (         1 downto 0);
        DUMP_DATA_OUT                       : out   std_logic_vector (    32*2-1 downto 0);
        DUMP_DVLD_OUT                       : out   std_logic_vector (         1 downto 0);
        TEST_DATA_IN                        : in    std_logic_vector (    32*2-1 downto 0);
        TEST_DENB_OUT                       : out   std_logic_vector (         1 downto 0);

        -- SerDes QPLL Dedicated
        QPLLLOCK_OUT                        : out   std_logic;
        QPLLOUTCLK_OUT                      : out   std_logic;
        QPLLOUTREFCLK_OUT                   : out   std_logic;
        QPLLREFCLKLOST_OUT                  : out   std_logic;
        QPLLLOCK_IN                         : in    std_logic;
        QPLLOUTCLK_IN                       : in    std_logic;
        QPLLOUTREFCLK_IN                    : in    std_logic;
        QPLLREFCLKLOST_IN                   : in    std_logic;

        -- etc.
        PCB_VER_IN                          : in    std_logic_vector  (         2 downto 0);
        FPGA_ID_IN                          : in    std_logic_vector  (         2 downto 0);

        -- SIG_SUS Interface
        SIG_SUS_FLAG_OUT                    : out   std_logic_vector  (SBIF_NUM-1 downto 0);    -- Signal Suspension
        SIG_SUS_DLOFF_IN                    : in    std_logic_vector  (SBIF_NUM-1 downto 0)     -- Signal Suspension from SIG_SUS
    );
end Slave_SBIFPHY_TOP_vhd;

architecture BEHAVE of Slave_SBIFPHY_TOP_vhd is

signal arr_SERDES_TXISK_IN      :   std_logic_array8  (SBIF_NUM-1 downto 0);  -- in  
signal arr_SERDES_TXD_IN        :   std_logic_array64 (SBIF_NUM-1 downto 0);  -- in  
signal arr_SERDES_RXISK_OUT     :   std_logic_array8  (SBIF_NUM-1 downto 0);  -- out 
signal arr_SERDES_RXD_OUT       :   std_logic_array64 (SBIF_NUM-1 downto 0);  -- out 
signal arr_SERDES_RXERR_OUT     :   std_logic_array8  (SBIF_NUM-1 downto 0);  -- out  
																 
signal arr_TEST_DATA_IN         :   std_logic_array32 (1 downto 0);  -- in  
signal arr_DBG_SIG_OUT          :   std_logic_array32 (1 downto 0);  -- out 
signal arr_DUMP_DATA_OUT        :   std_logic_array32 (1 downto 0);  -- out 



begin

gen_vhd_to_v : if TRUE generate

    gen_1: for i in 0 to SBIF_NUM-1 generate
    begin
    
        -- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
		arr_SERDES_TXISK_IN  (i)  <= SERDES_TXISK_IN (8*i+7 downto 8*i);
        arr_SERDES_TXD_IN    (i)  <= SERDES_TXD_IN (64*i+63 downto 64*i);
		
        -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
		SERDES_RXISK_OUT (8*i+7 downto 8*i)      <= arr_SERDES_RXISK_OUT  (i);
		SERDES_RXD_OUT   (64*i+63 downto 64*i)   <= arr_SERDES_RXD_OUT    (i);
        SERDES_RXERR_OUT (8*i+7 downto 8*i)      <= arr_SERDES_RXERR_OUT  (i);
		
    end generate;
	
    gen_2: for i in 0 to 2-1 generate
    begin 
        -- IN   arr_I_DL_DATA_I(i)  <= I_DL_DATA_I(16*i+15 downto 16*i); 
		arr_TEST_DATA_IN(i) <= TEST_DATA_IN(32*i+31 downto 32*i);
       
        -- OUT    O_UL_DATA_I(16*i+15 downto 16*i) <=	arr_O_UL_DATA_I(i);
		
		DBG_SIG_OUT  (32*i+31 downto 32*i) <= arr_DBG_SIG_OUT    (i);
        DUMP_DATA_OUT(32*i+31 downto 32*i) <= arr_DUMP_DATA_OUT  (i);
         
		
    end generate;
    
end generate;   

    
    SBIFPHY :  entity work.D_SBIFPHY_TOP
    port map(
        -- Reset
        RST_CPUIF                           =>  RST_CPUIF   ,
        RST_SBIFPHY                         =>  RST_SBIFPHY ,

        -- Clock
        CLK_CPUIF                           =>  CLK_CPUIF        ,
        CLK_SBIF                            =>  CLK_SBIF         ,
        CLK_SBIFXH                          =>  CLK_SBIFXH       ,
        CLK_SBIFX2                          =>  CLK_SBIFX2       ,
        REFCLK_SERDES_IN                    =>  REFCLK_SERDES_IN ,

        -- Connect Interface
        CON_DEL_IN                          =>  CON_DEL_IN ,

        -- Serial Interface
        SERIAL_TX_OUT_P                     =>  SERIAL_TX_OUT_P      ,
        SERIAL_TX_OUT_N                     =>  SERIAL_TX_OUT_N      ,
        SERIAL_RX_IN_P                      =>  SERIAL_RX_IN_P       ,
        SERIAL_RX_IN_N                      =>  SERIAL_RX_IN_N       ,

        -- Parallel Interface
        SERDES_TXISK_IN                     =>  arr_SERDES_TXISK_IN  ,
        SERDES_TXD_IN                       =>  arr_SERDES_TXD_IN    ,
        SERDES_RXISK_OUT                    =>  arr_SERDES_RXISK_OUT ,
        SERDES_RXD_OUT                      =>  arr_SERDES_RXD_OUT   ,
        SERDES_RXERR_OUT                    =>  arr_SERDES_RXERR_OUT ,
        SBIF_LOF_IN                         =>  SBIF_LOF_IN    	 	 ,

        -- CPU Interface
        ADDR_CPUIF_IN                       =>  ADDR_CPUIF_IN      ,
        WDATA_CPUIF_IN                      =>  WDATA_CPUIF_IN     ,
        RDATA_CPUIF_OUT                     =>  RDATA_CPUIF_OUT    ,
        WREN_CPUIF_IN                       =>  WREN_CPUIF_IN      ,
        RDEN_CPUIF_IN                       =>  RDEN_CPUIF_IN      ,
        RDVAL_CPUIF_OUT                     =>  RDVAL_CPUIF_OUT    ,

        -- Debug
        DBG_SIG_OUT                         =>  arr_DBG_SIG_OUT    ,

        -- Dump
        DUMP_BFN_STRB_OUT                   =>  DUMP_BFN_STRB_OUT  ,
        DUMP_DATA_OUT                       =>  arr_DUMP_DATA_OUT  ,
        DUMP_DVLD_OUT                       =>  DUMP_DVLD_OUT      ,
        TEST_DATA_IN                        =>  arr_TEST_DATA_IN   ,
        TEST_DENB_OUT                       =>  TEST_DENB_OUT      ,

        -- SerDes QPLL Dedicated
        QPLLLOCK_OUT                        =>  QPLLLOCK_OUT         ,
        QPLLOUTCLK_OUT                      =>  QPLLOUTCLK_OUT       ,
        QPLLOUTREFCLK_OUT                   =>  QPLLOUTREFCLK_OUT    ,
        QPLLREFCLKLOST_OUT                  =>  QPLLREFCLKLOST_OUT   ,
        QPLLLOCK_IN                         =>  QPLLLOCK_IN          ,
        QPLLOUTCLK_IN                       =>  QPLLOUTCLK_IN        ,
        QPLLOUTREFCLK_IN                    =>  QPLLOUTREFCLK_IN     ,
        QPLLREFCLKLOST_IN                   =>  QPLLREFCLKLOST_IN    ,

        -- etc.
        PCB_VER_IN                          =>  PCB_VER_IN   ,
        FPGA_ID_IN                          =>  FPGA_ID_IN   ,

        -- SIG_SUS Interface
        SIG_SUS_FLAG_OUT                    =>  SIG_SUS_FLAG_OUT    ,    -- Signal Suspension
        SIG_SUS_DLOFF_IN                    =>  SIG_SUS_DLOFF_IN      -- Signal Suspension from SIG_SUS
    );

end BEHAVE;