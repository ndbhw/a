library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_signed.all;

entity intf_axi_lite is
generic
(
    TIMEOUT_CTRL   : integer := 10;
    AXI_DATA_WIDTH : integer := 32;
    AXI_ADDR_WIDTH : integer := 22
);
port
(
    axi_aclk    : in  std_logic;
    axi_aresetn : in  std_logic;
                      
    axi_awaddr  : in  std_logic_vector( AXI_ADDR_WIDTH   -1 downto 0);
    axi_awvalid : in  std_logic;
    axi_wdata   : in  std_logic_vector( AXI_DATA_WIDTH   -1 downto 0);
    axi_wstrb   : in  std_logic_vector((AXI_DATA_WIDTH/8)-1 downto 0);
    axi_wvalid  : in  std_logic;
    axi_bready  : in  std_logic;
    axi_araddr  : in  std_logic_vector( AXI_ADDR_WIDTH   -1 downto 0);
    axi_arvalid : in  std_logic;
    axi_rready  : in  std_logic;
    axi_arready : out std_logic;
    axi_rdata   : out std_logic_vector( AXI_DATA_WIDTH   -1 downto 0);
    axi_rresp   : out std_logic_vector(                   1 downto 0);
    axi_rvalid  : out std_logic;
    axi_wready  : out std_logic;
    axi_bresp   : out std_logic_vector(                   1 downto 0);
    axi_bvalid  : out std_logic;
    axi_awready : out std_logic;
    
    
    addr_cpu_out     : out std_logic_vector(                  19 downto 0);
    rdata_cpu_in     : in  std_logic_vector(AXI_DATA_WIDTH    -1 downto 0);
    wdata_cpu_out    : out std_logic_vector(AXI_DATA_WIDTH    -1 downto 0);
    wren_cpu_out     : out std_logic;
    rden_cpu_out     : out std_logic;
    cs_cpu_out       : out std_logic
);
end entity intf_axi_lite;

architecture Behavioral of intf_axi_lite is

    ATTRIBUTE X_INTERFACE_INFO : STRING;
    ATTRIBUTE X_INTERFACE_PARAMETER : STRING;
    
    ATTRIBUTE X_INTERFACE_INFO of axi_awaddr  : SIGNAL is "xilinx.com:interface:aximm:1.0 axi AWADDR";
    ATTRIBUTE X_INTERFACE_INFO of axi_awvalid : SIGNAL is "xilinx.com:interface:aximm:1.0 axi AWVALID";
    ATTRIBUTE X_INTERFACE_INFO of axi_wdata   : SIGNAL is "xilinx.com:interface:aximm:1.0 axi WDATA";
    ATTRIBUTE X_INTERFACE_INFO of axi_wstrb   : SIGNAL is "xilinx.com:interface:aximm:1.0 axi WSTRB";
    ATTRIBUTE X_INTERFACE_INFO of axi_wvalid  : SIGNAL is "xilinx.com:interface:aximm:1.0 axi WVALID";
    ATTRIBUTE X_INTERFACE_INFO of axi_bvalid  : SIGNAL is "xilinx.com:interface:aximm:1.0 axi BVALID";
    ATTRIBUTE X_INTERFACE_INFO of axi_bready  : SIGNAL is "xilinx.com:interface:aximm:1.0 axi BREADY";
    ATTRIBUTE X_INTERFACE_INFO of axi_awready : SIGNAL is "xilinx.com:interface:aximm:1.0 axi AWREADY";
    ATTRIBUTE X_INTERFACE_INFO of axi_wready  : SIGNAL is "xilinx.com:interface:aximm:1.0 axi WREADY";
    ATTRIBUTE X_INTERFACE_INFO of axi_bresp   : SIGNAL is "xilinx.com:interface:aximm:1.0 axi BRESP";
    ATTRIBUTE X_INTERFACE_INFO of axi_araddr  : SIGNAL is "xilinx.com:interface:aximm:1.0 axi ARADDR";
    ATTRIBUTE X_INTERFACE_INFO of axi_arvalid : SIGNAL is "xilinx.com:interface:aximm:1.0 axi ARVALID";
    ATTRIBUTE X_INTERFACE_INFO of axi_arready : SIGNAL is "xilinx.com:interface:aximm:1.0 axi ARREADY";
    ATTRIBUTE X_INTERFACE_INFO of axi_rdata   : SIGNAL is "xilinx.com:interface:aximm:1.0 axi RDATA";
    ATTRIBUTE X_INTERFACE_INFO of axi_rresp   : SIGNAL is "xilinx.com:interface:aximm:1.0 axi RRESP";
    ATTRIBUTE X_INTERFACE_INFO of axi_rvalid  : SIGNAL is "xilinx.com:interface:aximm:1.0 axi RVALID";
    ATTRIBUTE X_INTERFACE_INFO of axi_rready  : SIGNAL is "xilinx.com:interface:aximm:1.0 axi RREADY";
    
    ATTRIBUTE X_INTERFACE_INFO of axi_aresetn: SIGNAL is "xilinx.com:signal:reset:1.0 axi_aresetn RST";
    ATTRIBUTE X_INTERFACE_PARAMETER of axi_aresetn: SIGNAL is "POLARITY ACTIVE_LOW";

    ATTRIBUTE X_INTERFACE_INFO of axi_aclk: SIGNAL is "xilinx.com:signal:clock:1.0 axi_aclk CLK";    
    ATTRIBUTE X_INTERFACE_PARAMETER of axi_aclk: SIGNAL is "ASSOCIATED_BUSIF axi, ASSOCIATED_RESET axi_aresetn, FREQ_HZ 100000000";
        
    type state_type is (IDLE, PROG, RESP);
    signal rd_state : state_type;
    signal wr_state : state_type;
    
    signal rd_flag    : std_logic;
    signal rd_counter : std_logic_vector(7 downto 0);
    
    signal wr_flag    : std_logic;
    signal wr_counter : std_logic_vector(7 downto 0);
        
begin

    process (axi_aclk) begin
        if rising_edge(axi_aclk) then
            if axi_aresetn = '0' then
                rd_state <= IDLE;
            else
                case rd_state is
                    when IDLE =>
                        if axi_arvalid = '1' then
                            rd_state <= PROG;
                        else
                            rd_state <= IDLE;
                        end if;
            
                    when PROG =>
                        if rd_flag = '1' then
                            rd_state <= RESP;
                        else
                            rd_state <= PROG;
                        end if;
            
                    when RESP =>
                        if axi_rready = '1' then
                            rd_state <= IDLE;
                        else
                            rd_state <= RESP;
                        end if;

                    when others =>
                        rd_state <= IDLE;
                end case;
            end if;
        end if;
    end process;
    
    process (axi_aclk) begin
        if rising_edge(axi_aclk) then
            if axi_aresetn = '0' then
                rd_counter <= x"00";
            else
                if rd_state = PROG then
                    rd_counter <= rd_counter + x"01";
                else
                    rd_counter <= x"00";
                end if;
            end if;
        end if;
    end process;
    
    rd_flag <= '1' when rd_counter = std_logic_vector(to_unsigned(TIMEOUT_CTRL, rd_counter'length)) else '0'; 
    
    process (axi_aclk) begin
        if rising_edge(axi_aclk) then
            if axi_aresetn = '0' then
                wr_state <= IDLE;
            else
                case wr_state is
                    when IDLE =>
                        if axi_awvalid = '1' and axi_wvalid = '1' then
                            wr_state <= PROG;
                        else
                            wr_state <= IDLE;
                        end if;
                        
                    when PROG => 
                        if wr_flag = '1' then
                            wr_state <= RESP;
                        else
                            wr_state <= PROG;
                        end if;
                        
                    when RESP =>
                        if axi_bready = '1' then
                            wr_state <= IDLE;
                        else
                            wr_state <= RESP;
                        end if;
                        
                    when others => 
                        wr_state <= IDLE;
                end case;
            end if;
        end if;
    end process;
    
    process (axi_aclk) begin
        if rising_edge(axi_aclk) then
            if axi_aresetn = '0' then
                wr_counter <= x"00";
            else
                if wr_state = PROG then
                    wr_counter <= wr_counter + x"01";
                else
                    wr_counter <= x"00";
                end if;
            end if;
        end if;
    end process;
    
    wr_flag <= '1' when wr_counter = std_logic_vector(to_unsigned(TIMEOUT_CTRL-1, wr_counter'length)) else '0'; 
    
    
    axi_awready   <= wr_flag when wr_state = PROG else '0';
    axi_wready    <= wr_flag when wr_state = PROG else '0';    
    axi_bresp     <= "00";
    axi_bvalid    <= '1' when wr_state = RESP else '0';
                  
    axi_arready   <= '1' when rd_state = IDLE else '0';
    axi_rvalid    <= '1' when rd_state = RESP else '0';
    axi_rresp     <= "00";
                  
    rden_cpu_out  <= '1' when rd_state = PROG else '0';
    
    
    process (axi_aclk) begin
        if rising_edge(axi_aclk) then
            if axi_aresetn = '0' then
                axi_rdata <= (others => '0');
            else
                if rd_state = IDLE then 
                    axi_rdata <= (others => '0');
                elsif rd_state = PROG and rd_flag = '1' then
                    axi_rdata <= rdata_cpu_in;                     
                end if;
            end if;
        end if;
    end process;
    
       
    wren_cpu_out  <= '1' when wr_state = PROG else '0';
    wdata_cpu_out <= axi_wdata;
    
    addr_cpu_out  <= axi_awaddr(21 downto 2) when wr_state = PROG else
                     axi_araddr(21 downto 2) when rd_state = PROG else (others => '0');
                     
    cs_cpu_out    <= '1' when wr_state = PROG else
                     '1' when rd_state = PROG else '0';
    
end;