// ***************************************************************************
// File        : CPUIF_SYSCTRL_tpl.v
// Description : CPU I/F of SYSCTRL (replaces CPUIF_SYSCTRL.vhd) on the up bus.
//
//   Register           Offset (word)  Type  Output synchronous to
//   REG_SYS_1[31:0]    0x0            RW    up_clk    100 MHz (watchdog, LED, reset...)
//   REG_SYS_2[31:0]    0x1            RW    up_clk
//   REG_SYS_3[31:0]    0x2            RW    CLK_SYSX8 245.76 MHz (SYNC_RETARD / ADVANCE)
//   REG_SYS_4[31:0]    0x3            RW    CLK_SYSX8
//
//   up_req (1 clk) + up_wr: write up_reg_x or read to up_rdata; up_ack after 1 clk.
//   Write: REG_SYS_1/2 used directly @ up_clk; REG_SYS_3/4 via up_xfer_cntrl.
//   Extend: add up_reg_x, add write/read case, add output, widen xfer DATA_WIDTH.
// ***************************************************************************

`timescale 1ns/100ps

module CPUIF_SYSCTRL_tpl (
  // up bus from U02_CPUIF (up_clk = FCLK_CLK0 100 MHz)
  input             up_rstn,
  input             up_clk,
  input             up_req,               // strobe for SYSCTRL
  input             up_wr,                // 1: write, 0: read
  input      [11:0] up_addr,
  input      [31:0] up_wdata,
  output reg        up_ack,
  output reg [31:0] up_rdata,

  input             CLK_SYSX8,
  input             RST_SYSX8,            // active high, sync to CLK_SYSX8

  // configuration for core SYSCTRL
  output     [31:0] REG_SYS_1,            // @ up_clk
  output     [31:0] REG_SYS_2,            // @ up_clk
  output     [31:0] REG_SYS_3,            // @ CLK_SYSX8
  output     [31:0] REG_SYS_4             // @ CLK_SYSX8
);

  reg        [31:0] up_reg_1 = 32'd0;
  reg        [31:0] up_reg_2 = 32'd0;
  reg        [31:0] up_reg_3 = 32'd0;
  reg        [31:0] up_reg_4 = 32'd0;

  // write

  always @(posedge up_clk) begin
    if (up_rstn == 1'b0) begin
      up_ack   <= 1'b0;
      up_reg_1 <= 32'd0;
      up_reg_2 <= 32'd0;
      up_reg_3 <= 32'd0;
      up_reg_4 <= 32'd0;
    end else begin
      up_ack <= up_req;
      if ((up_req == 1'b1) && (up_wr == 1'b1)) begin
        case (up_addr[1:0])
          2'h0: up_reg_1 <= up_wdata;
          2'h1: up_reg_2 <= up_wdata;
          2'h2: up_reg_3 <= up_wdata;
          2'h3: up_reg_4 <= up_wdata;
          default: ;
        endcase
      end
    end
  end

  // read

  always @(posedge up_clk) begin
    if (up_rstn == 1'b0) begin
      up_rdata <= 32'd0;
    end else if ((up_req == 1'b1) && (up_wr == 1'b0)) begin
      case (up_addr[1:0])
        2'h0: up_rdata <= up_reg_1;
        2'h1: up_rdata <= up_reg_2;
        2'h2: up_rdata <= up_reg_3;
        2'h3: up_rdata <= up_reg_4;
        default: up_rdata <= 32'd0;
      endcase
    end
  end

  // up_clk: no CDC

  assign REG_SYS_1 = up_reg_1;
  assign REG_SYS_2 = up_reg_2;

  // CDC up_clk -> CLK_SYSX8

  up_xfer_cntrl #(
    .DATA_WIDTH (64)
  ) i_xfer_sysx8 (
    .up_rstn        (up_rstn),
    .up_clk         (up_clk),
    .up_data_cntrl  ({up_reg_4, up_reg_3}),
    .up_xfer_done   (),
    .d_rst          (RST_SYSX8),
    .d_clk          (CLK_SYSX8),
    .d_data_cntrl   ({REG_SYS_4, REG_SYS_3}));

endmodule
