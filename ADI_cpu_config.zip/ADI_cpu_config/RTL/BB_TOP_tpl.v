// ***************************************************************************
// File        : BB_TOP_tpl.v
// Description : Template U06_BB_TOP (replaces BB_TOP.v) on the up bus.
//
//   CPU I/F: u04_bb_top_cpu_if (bb_top_cpu_if_tpl), 4 registers REG_BB_1..4
//   @ i_core_clk 245.76 MHz, used inside BB_TOP.
// ***************************************************************************

`timescale 1ns/100ps

module BB_TOP_tpl (
  // clock / reset core
  input         i_core_clk,       // 245.76 MHz
  input         i_core_rst,       // active high, sync to i_core_clk

  // CPU I/F: up bus from U02_CPUIF (replaces i_bb_cpu_* / o_bb_cpu_*)
  input         up_rstn,
  input         up_clk,           // i_cpu_clk 100 MHz
  input         up_req,
  input         up_wr,            // 1: write, 0: read
  input  [11:0] up_addr,
  input  [31:0] up_wdata,
  output        up_ack,
  output [31:0] up_rdata

  // ... other ports unchanged from BB_TOP.v
);

  // ------------------------------------------------------------------------
  // CPU I/F
  // ------------------------------------------------------------------------

  wire [31:0]   reg_bb_1;         // @ i_core_clk
  wire [31:0]   reg_bb_2;         // @ i_core_clk
  wire [31:0]   reg_bb_3;         // @ i_core_clk
  wire [31:0]   reg_bb_4;         // @ i_core_clk

  bb_top_cpu_if_tpl u04_bb_top_cpu_if (
    .up_rstn   (up_rstn),
    .up_clk    (up_clk),
    .up_req    (up_req),
    .up_wr     (up_wr),
    .up_addr   (up_addr),
    .up_wdata  (up_wdata),
    .up_ack    (up_ack),
    .up_rdata  (up_rdata),
    .i_clk     (i_core_clk),
    .i_rst     (i_core_rst),
    .REG_BB_1  (reg_bb_1),
    .REG_BB_2  (reg_bb_2),
    .REG_BB_3  (reg_bb_3),
    .REG_BB_4  (reg_bb_4));

  // ------------------------------------------------------------------------
  // core BB_TOP (DLFE / ULFE / RAFE x 2 CC): uses reg_bb_1..4 @ i_core_clk
  // ------------------------------------------------------------------------

endmodule
