// ***************************************************************************
// File        : CPUIF_MISC_tpl.v
// Description : CPU I/F of MISC (replaces CPUIF_MISC.vhd) on the up bus.
//               Keeps the 4 clock domains that CPUIF_MISC.vhd writes registers into.
//
//   Register            Offset (word)  Type  Output synchronous to
//   REG_MISC_1[31:0]    0x0            RW    up_clk    100 MHz
//   REG_MISC_2[31:0]    0x1            RW    CLK_SYSX4 122.88 MHz
//   REG_MISC_3[31:0]    0x2            RW    CLK_SYSX8 245.76 MHz
//   REG_MISC_4[31:0]    0x3            RW    CLK_MISC3 200 MHz
//
//   up_req (1 clk) + up_wr: write up_reg_x or read to up_rdata; up_ack after 1 clk.
//   Write: up_reg_x @ up_clk -> up_xfer_cntrl (1 per domain) -> REG_MISC_x.
//   Extend: add up_reg_x, add write/read case, add output, widen xfer DATA_WIDTH.
// ***************************************************************************

`timescale 1ns/100ps

module CPUIF_MISC_tpl (
  // up bus from U02_CPUIF (up_clk = FCLK_CLK0 100 MHz)
  input             up_rstn,
  input             up_clk,
  input             up_req,               // strobe for MISC
  input             up_wr,                // 1: write, 0: read
  input      [11:0] up_addr,
  input      [31:0] up_wdata,
  output reg        up_ack,
  output reg [31:0] up_rdata,

  input             CLK_SYSX4,
  input             RST_SYSX4,            // active high, sync to CLK_SYSX4
  input             CLK_SYSX8,
  input             RST_SYSX8,            // active high, sync to CLK_SYSX8
  input             CLK_MISC3,
  input             RST_MISC3,            // active high, sync to CLK_MISC3

  // configuration for core MISC
  output     [31:0] REG_MISC_1,           // @ up_clk
  output     [31:0] REG_MISC_2,           // @ CLK_SYSX4
  output     [31:0] REG_MISC_3,           // @ CLK_SYSX8
  output     [31:0] REG_MISC_4            // @ CLK_MISC3
);

  reg        [31:0] up_reg_1 = 32'd0;
  reg        [31:0] up_reg_2 = 32'd0;
  reg        [31:0] up_reg_3 = 32'd0;
  reg        [31:0] up_reg_4 = 32'd0;

  // write

  always @(posedge up_clk) begin
    if (up_rstn == 1'b0) begin
      up_ack   <= 1'b0;
      up_reg_1 <= 32'd0;
      up_reg_2 <= 32'd0;
      up_reg_3 <= 32'd0;
      up_reg_4 <= 32'd0;
    end else begin
      up_ack <= up_req;
      if ((up_req == 1'b1) && (up_wr == 1'b1)) begin
        case (up_addr[1:0])
          2'h0: up_reg_1 <= up_wdata;
          2'h1: up_reg_2 <= up_wdata;
          2'h2: up_reg_3 <= up_wdata;
          2'h3: up_reg_4 <= up_wdata;
          default: ;
        endcase
      end
    end
  end

  // read

  always @(posedge up_clk) begin
    if (up_rstn == 1'b0) begin
      up_rdata <= 32'd0;
    end else if ((up_req == 1'b1) && (up_wr == 1'b0)) begin
      case (up_addr[1:0])
        2'h0: up_rdata <= up_reg_1;
        2'h1: up_rdata <= up_reg_2;
        2'h2: up_rdata <= up_reg_3;
        2'h3: up_rdata <= up_reg_4;
        default: up_rdata <= 32'd0;
      endcase
    end
  end

  // up_clk: no CDC

  assign REG_MISC_1 = up_reg_1;

  // CDC up_clk -> CLK_SYSX4

  up_xfer_cntrl #(
    .DATA_WIDTH (32)
  ) i_xfer_sysx4 (
    .up_rstn        (up_rstn),
    .up_clk         (up_clk),
    .up_data_cntrl  (up_reg_2),
    .up_xfer_done   (),
    .d_rst          (RST_SYSX4),
    .d_clk          (CLK_SYSX4),
    .d_data_cntrl   (REG_MISC_2));

  // CDC up_clk -> CLK_SYSX8

  up_xfer_cntrl #(
    .DATA_WIDTH (32)
  ) i_xfer_sysx8 (
    .up_rstn        (up_rstn),
    .up_clk         (up_clk),
    .up_data_cntrl  (up_reg_3),
    .up_xfer_done   (),
    .d_rst          (RST_SYSX8),
    .d_clk          (CLK_SYSX8),
    .d_data_cntrl   (REG_MISC_3));

  // CDC up_clk -> CLK_MISC3

  up_xfer_cntrl #(
    .DATA_WIDTH (32)
  ) i_xfer_misc3 (
    .up_rstn        (up_rstn),
    .up_clk         (up_clk),
    .up_data_cntrl  (up_reg_4),
    .up_xfer_done   (),
    .d_rst          (RST_MISC3),
    .d_clk          (CLK_MISC3),
    .d_data_cntrl   (REG_MISC_4));

endmodule
