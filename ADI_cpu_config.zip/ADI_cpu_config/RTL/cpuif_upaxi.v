// ***************************************************************************
// File        : cpuif_upaxi.v
// Description : U02_CPUIF - arbiter + decoder for the up_axi pcore bus
//               (up_axi is inside the U00_MPSoC_CPU block design).
//
//   - 1 transaction at a time (read OR write), write has priority.
//   - Shared bus to all slaves: up_wr (1 write / 0 read), up_addr[11:0], up_wdata.
//   - Decode ADDR[19:12] -> up_req_x (registered); rdata selected by up_ack_x.
//   - Address with no slave -> up_axi timeout, read returns 0xDEADDEAD.
//
//   Slave       ADDR[19:12]
//   SYSCTRL     0x00
//   MISC        0x0A - 0x0D
//   BBTOP       0x40 - 0x5F
// ***************************************************************************

`timescale 1ns/100ps

module cpuif_upaxi (
  input             up_clk,
  input             up_rstn,

  // up_axi pcore bus (in U00_MPSoC_CPU)
  input             axi_wreq,
  input      [19:0] axi_waddr,            // word address
  input      [31:0] axi_wdata,
  output reg        axi_wack,
  input             axi_rreq,
  input      [19:0] axi_raddr,            // word address
  output reg [31:0] axi_rdata,
  output reg        axi_rack,

  // shared bus -> all slaves
  output reg        up_wr,
  output reg [11:0] up_addr,
  output     [31:0] up_wdata,

  output reg        up_req_sysctrl,
  input             up_ack_sysctrl,
  input      [31:0] up_rdata_sysctrl,

  output reg        up_req_misc,
  input             up_ack_misc,
  input      [31:0] up_rdata_misc,

  output reg        up_req_bbtop,
  input             up_ack_bbtop,
  input      [31:0] up_rdata_bbtop
);

  reg               pend_w = 1'b0;
  reg               pend_r = 1'b0;
  reg               busy   = 1'b0;

  wire              start;
  wire              sel_wr;
  wire       [19:0] sel_addr;
  wire       [ 7:0] sel_addr_h;
  wire              dec_sysctrl;
  wire              dec_misc;
  wire              dec_bbtop;
  wire              dec_any;
  wire              ack_any;

  assign up_wdata = axi_wdata;  // up_axi holds it stable until bresp

  // select 1 transaction, write has priority

  assign start      = ~busy & (pend_w | pend_r);
  assign sel_wr     = pend_w;
  assign sel_addr   = (sel_wr == 1'b1) ? axi_waddr : axi_raddr;
  assign sel_addr_h = sel_addr[19:12];

  assign dec_sysctrl  = (sel_addr_h == 8'h00);
  assign dec_misc     = (sel_addr_h >= 8'h0A) & (sel_addr_h <= 8'h0D);
  assign dec_bbtop    = (sel_addr_h >= 8'h40) & (sel_addr_h <= 8'h5F);
  assign dec_any      = dec_sysctrl | dec_misc | dec_bbtop;

  assign ack_any = up_ack_sysctrl | up_ack_misc | up_ack_bbtop;

  always @(posedge up_clk) begin
    if (up_rstn == 1'b0) begin
      pend_w          <= 1'b0;
      pend_r          <= 1'b0;
      busy            <= 1'b0;
      up_wr           <= 1'b0;
      up_addr         <= 12'd0;
      up_req_sysctrl  <= 1'b0;
      up_req_misc     <= 1'b0;
      up_req_bbtop    <= 1'b0;
      axi_wack        <= 1'b0;
      axi_rack        <= 1'b0;
      axi_rdata       <= 32'd0;
    end else begin
      // pending requests (at most 1 per channel)
      pend_w <= axi_wreq | (pend_w & ~(start &  sel_wr));
      pend_r <= axi_rreq | (pend_r & ~(start & ~sel_wr));

      // issue request
      if (start == 1'b1) begin
        busy    <= dec_any;
        up_wr   <= sel_wr;
        up_addr <= sel_addr[11:0];
      end else if (ack_any == 1'b1) begin
        busy    <= 1'b0;
      end
      up_req_sysctrl  <= start & dec_sysctrl;
      up_req_misc     <= start & dec_misc;
      up_req_bbtop    <= start & dec_bbtop;

      // response
      axi_wack <= ack_any &  up_wr;
      axi_rack <= ack_any & ~up_wr;
      if      (up_ack_sysctrl  == 1'b1) axi_rdata <= up_rdata_sysctrl;
      else if (up_ack_misc     == 1'b1) axi_rdata <= up_rdata_misc;
      else if (up_ack_bbtop    == 1'b1) axi_rdata <= up_rdata_bbtop;
      else                              axi_rdata <= 32'd0;
    end
  end

endmodule
