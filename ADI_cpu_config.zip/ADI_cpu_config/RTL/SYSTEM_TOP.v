// ***************************************************************************
// File        : SYSTEM_TOP.v
// Description : TEMPLATE SYSTEM_TOP with a CPU I/F based on up_axi (ADI).
//
//   U00_MPSoC_CPU contains up_axi; the wrapper exports the up_axi pcore bus UP_*.
//   U02_CPUIF arbitrates + decodes ADDR[19:12] -> up_req_x, shared bus
//   up_wr / up_addr[11:0] / up_wdata to all modules.
//
//   Inst            Module              Sub CPU I/F           ADDR[19:12]
//   U00_MPSoC_CPU   mpsoc_ps_system     up_axi (in BD)        -
//   U01_SYSCTRL     SYSCTRL_TOP_tpl     CPUIF_SYSCTRL_tpl     0x00
//   U02_CPUIF       cpuif_upaxi         -                     -
//   U06_BB_TOP      BB_TOP_tpl          bb_top_cpu_if_tpl     0x40 - 0x5F
//   U10_MISC        MISC_TOP_tpl        CPUIF_MISC_tpl        0x0A - 0x0D
//
//   CPU-side byte address = 0x8800_0000 + (word << 2).
//
//   Block design (mpsoc_ps_system):
//     1. Add Module up_axi.v, AXI_ADDRESS_WIDTH = 22, AXI connected to the
//        peripheral interconnect; up_clk = FCLK_CLK0, up_rstn = FCLK_NRST reset.
//     2. Make External the pcore bus, rename to UP_WREQ/UP_WADDR/UP_WDATA/UP_WACK/
//        UP_RREQ/UP_RADDR/UP_RDATA/UP_RACK.
//     3. Address Editor: up_axi at 0x8800_0000 / 4 MB.
// ***************************************************************************

`timescale 1ns/100ps

module SYSTEM_TOP (
  input  wire       SI5386_FPGA_SYSCLK_122P88M    // 122.88 MHz -> DATA_PLL
);

  // U00_MPSoC_CPU
  wire        w_clk_cpuif      ;  // FCLK_CLK 100 MHz
  wire        w_fclk_nrst      ;

  wire        w_axi_wreq ;
  wire [29:0] w_axi_waddr;
  wire [31:0] w_axi_wdata;
  wire        w_axi_wack ;
  wire        w_axi_rreq ;
  wire [29:0] w_axi_raddr;
  wire [31:0] w_axi_rdata;
  wire        w_axi_rack ;

  // U01_SYSCTRL
  wire        w_clk_sysx4, w_clk_sysx8, w_clk_misc3;
  wire        w_rst_sysx4, w_rst_sysx8, w_rst_misc3;

  // U02_CPUIF
  wire        w_up_wr   ;
  wire [11:0] w_up_addr ;
  wire [31:0] w_up_wdata;

  wire        w_up_req_sysctrl , w_up_ack_sysctrl ;
  wire [31:0] w_up_rdata_sysctrl;
  wire        w_up_req_misc    , w_up_ack_misc    ;
  wire [31:0] w_up_rdata_misc;
  wire        w_up_req_bbtop   , w_up_ack_bbtop   ;
  wire [31:0] w_up_rdata_bbtop;

  bd_cpu_wrapper U0_CPU (
    .FCLK_CLK           (w_clk_cpuif       ), // output
    .FCLK_NRST          (w_fclk_nrst       ), // output [0:0]
    .up_wreq_0          (w_axi_wreq        ), // output
    .up_waddr_0         (w_axi_waddr       ), // output [29:0]
    .up_wdata_0         (w_axi_wdata       ), // output [31:0]
    .up_wack_0          (w_axi_wack        ), // input
    .up_rreq_0          (w_axi_rreq        ), // output
    .up_raddr_0         (w_axi_raddr       ), // output [29:0]
    .up_rdata_0         (w_axi_rdata       ), // input  [31:0]
    .up_rack_0          (w_axi_rack        )  // input
  );

  cpuif_upaxi U2_CPUIF (
    .up_clk             (w_clk_cpuif           ),
    .up_rstn            (w_fclk_nrst           ),
    .axi_wreq           (w_axi_wreq            ),
    .axi_waddr          (w_axi_waddr[19:0]     ),
    .axi_wdata          (w_axi_wdata           ),
    .axi_wack           (w_axi_wack            ),
    .axi_rreq           (w_axi_rreq            ),
    .axi_raddr          (w_axi_raddr[19:0]     ),
    .axi_rdata          (w_axi_rdata           ),
    .axi_rack           (w_axi_rack            ),
    .up_wr              (w_up_wr               ),
    .up_addr            (w_up_addr             ),
    .up_wdata           (w_up_wdata            ),
    .up_req_sysctrl     (w_up_req_sysctrl      ),
    .up_ack_sysctrl     (w_up_ack_sysctrl      ),
    .up_rdata_sysctrl   (w_up_rdata_sysctrl    ),
    .up_req_misc        (w_up_req_misc         ),
    .up_ack_misc        (w_up_ack_misc         ),
    .up_rdata_misc      (w_up_rdata_misc       ),
    .up_req_bbtop       (w_up_req_bbtop        ),
    .up_ack_bbtop       (w_up_ack_bbtop        ),
    .up_rdata_bbtop     (w_up_rdata_bbtop      )
  );

  SYSCTRL_TOP_tpl U2_SYSCTRL (
    .up_rstn        (w_fclk_nrst               ),
    .up_clk         (w_clk_cpuif               ),
    .up_req         (w_up_req_sysctrl          ),
    .up_wr          (w_up_wr                   ),
    .up_addr        (w_up_addr                 ),
    .up_wdata       (w_up_wdata                ),
    .up_ack         (w_up_ack_sysctrl          ),
    .up_rdata       (w_up_rdata_sysctrl        ),
    .EXT_SYSCLK_IN  (SI5386_FPGA_SYSCLK_122P88M),
    .CLK_SYSX4      (w_clk_sysx4               ),
    .CLK_SYSX6      (                          ),
    .CLK_SYSX8      (w_clk_sysx8               ),
    .CLK_MISC0      (                          ),
    .CLK_MISC3      (w_clk_misc3               ),
    .RST_SYSX4      (w_rst_sysx4               ),
    .RST_SYSX6      (                          ),
    .RST_SYSX8      (w_rst_sysx8               ),
    .RST_MISC0      (                          ),
    .RST_MISC3      (w_rst_misc3               )
  );


  BB_TOP_tpl U3_BB_TOP (
    .i_core_clk     (w_clk_sysx8               ),
    .i_core_rst     (w_rst_sysx8               ),
    .up_rstn        (w_fclk_nrst               ),
    .up_clk         (w_clk_cpuif               ),
    .up_req         (w_up_req_bbtop            ),
    .up_wr          (w_up_wr                   ),
    .up_addr        (w_up_addr                 ),
    .up_wdata       (w_up_wdata                ),
    .up_ack         (w_up_ack_bbtop            ),
    .up_rdata       (w_up_rdata_bbtop          )
  );

  MISC_TOP_tpl U10_MISC (
    .up_rstn        (w_fclk_nrst               ),
    .up_clk         (w_clk_cpuif               ),
    .up_req         (w_up_req_misc             ),
    .up_wr          (w_up_wr                   ),
    .up_addr        (w_up_addr                 ),
    .up_wdata       (w_up_wdata                ),
    .up_ack         (w_up_ack_misc             ),
    .up_rdata       (w_up_rdata_misc           ),
    .CLK_SYSX4      (w_clk_sysx4               ),
    .RST_SYSX4      (w_rst_sysx4               ),
    .CLK_SYSX8      (w_clk_sysx8               ),
    .RST_SYSX8      (w_rst_sysx8               ),
    .CLK_MISC3      (w_clk_misc3               ),
    .RST_MISC3      (w_rst_misc3               )
  );

endmodule
