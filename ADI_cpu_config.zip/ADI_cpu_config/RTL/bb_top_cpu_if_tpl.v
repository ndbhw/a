// ***************************************************************************
// File        : bb_top_cpu_if_tpl.v
// Description : CPU I/F of BB_TOP (replaces bb_top_cpu_if.v) on the up bus.
//
//   Register          Offset (word)  Type  Output synchronous to
//   REG_BB_1[31:0]    0x0            RW    i_clk 245.76 MHz
//   REG_BB_2[31:0]    0x1            RW    i_clk
//   REG_BB_3[31:0]    0x2            RW    i_clk
//   REG_BB_4[31:0]    0x3            RW    i_clk
//
//   up_req (1 clk) + up_wr: write up_reg_x or read to up_rdata; up_ack after 1 clk.
//   Write: up_reg_x @ up_clk -> up_xfer_cntrl -> REG_BB_x @ i_clk.
//   Extend: add up_reg_x, add write/read case, add output, widen xfer DATA_WIDTH.
// ***************************************************************************

`timescale 1ns/100ps

module bb_top_cpu_if_tpl (
  // up bus from U02_CPUIF (up_clk = FCLK_CLK0 100 MHz)
  input             up_rstn,
  input             up_clk,
  input             up_req,               // strobe for BBTOP
  input             up_wr,                // 1: write, 0: read
  input      [11:0] up_addr,
  input      [31:0] up_wdata,
  output reg        up_ack,
  output reg [31:0] up_rdata,

  input             i_clk,
  input             i_rst,                // active high, sync to i_clk

  // configuration for core DLFE/ULFE/RAFE (@ i_clk)
  output     [31:0] REG_BB_1,
  output     [31:0] REG_BB_2,
  output     [31:0] REG_BB_3,
  output     [31:0] REG_BB_4
);

  reg        [31:0] up_reg_1 = 32'd0;
  reg        [31:0] up_reg_2 = 32'd0;
  reg        [31:0] up_reg_3 = 32'd0;
  reg        [31:0] up_reg_4 = 32'd0;

  // write

  always @(posedge up_clk) begin
    if (up_rstn == 1'b0) begin
      up_ack   <= 1'b0;
      up_reg_1 <= 32'd0;
      up_reg_2 <= 32'd0;
      up_reg_3 <= 32'd0;
      up_reg_4 <= 32'd0;
    end else begin
      up_ack <= up_req;
      if ((up_req == 1'b1) && (up_wr == 1'b1)) begin
        case (up_addr[1:0])
          2'h0: up_reg_1 <= up_wdata;
          2'h1: up_reg_2 <= up_wdata;
          2'h2: up_reg_3 <= up_wdata;
          2'h3: up_reg_4 <= up_wdata;
          default: ;
        endcase
      end
    end
  end

  // read

  always @(posedge up_clk) begin
    if (up_rstn == 1'b0) begin
      up_rdata <= 32'd0;
    end else if ((up_req == 1'b1) && (up_wr == 1'b0)) begin
      case (up_addr[1:0])
        2'h0: up_rdata <= up_reg_1;
        2'h1: up_rdata <= up_reg_2;
        2'h2: up_rdata <= up_reg_3;
        2'h3: up_rdata <= up_reg_4;
        default: up_rdata <= 32'd0;
      endcase
    end
  end

  // CDC up_clk -> i_clk

  up_xfer_cntrl #(
    .DATA_WIDTH (128)
  ) i_xfer_core (
    .up_rstn        (up_rstn),
    .up_clk         (up_clk),
    .up_data_cntrl  ({up_reg_4, up_reg_3, up_reg_2, up_reg_1}),
    .up_xfer_done   (),
    .d_rst          (i_rst),
    .d_clk          (i_clk),
    .d_data_cntrl   ({REG_BB_4, REG_BB_3, REG_BB_2, REG_BB_1}));

endmodule
