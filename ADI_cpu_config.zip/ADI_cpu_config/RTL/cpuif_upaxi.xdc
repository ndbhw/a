################################################################################
# cpuif_upaxi.xdc - CDC constraints for up_xfer_cntrl in the sub CPU I/Fs
#
# - The clocks are already in set_clock_groups -asynchronous (RT4439_40A.xdc), so
#   no set_false_path / set_max_delay is needed for cross-domain paths.
# - Mark ASYNC_REG on the first 2 synchronizer stages (m1, m2) of the toggle handshake.
# - Multi-bit data (up_xfer_data -> d_data_cntrl_int) is held stable by the
#   handshake, no sync needed.
#
# up_xfer_cntrl: up_xfer_state_m1/m2 (up_clk side), d_xfer_toggle_m1/m2 (d_clk side)
# Instance: i_xfer_<domain> in CPUIF_SYSCTRL_tpl / bb_top_cpu_if_tpl / CPUIF_MISC_tpl
################################################################################

set_property ASYNC_REG TRUE [get_cells -quiet -hier -filter {NAME =~ *i_xfer_*/*xfer_*_m1_reg*}]
set_property ASYNC_REG TRUE [get_cells -quiet -hier -filter {NAME =~ *i_xfer_*/*xfer_*_m2_reg*}]
