// ***************************************************************************
// File        : SYSCTRL_TOP_tpl.v
// Description : Template U01_SYSCTRL (replaces SYSCTRL_TOP.vhd) on the up bus.
//
//   - Clock gen same as SYSCTRL_TOP.vhd (same IPs):
//       DATA_PLL    : EXT_SYSCLK_IN 122.88 -> 122.88 (BUFG), 245.76 (BUFG), 30.72, 184.32
//       CPU_MII_PLL : up_clk 100            -> 25, 200
//   - Per-domain reset: asynchronous assert (PS reset / PLL loss of lock),
//     synchronous deassert to the domain clock (xpm_cdc_async_rst).
//   - CPU I/F: inst_cpuif_sysctrl (CPUIF_SYSCTRL_tpl), 4 registers REG_SYS_1..4
//     used inside SYSCTRL.
// ***************************************************************************

`timescale 1ns/100ps

module SYSCTRL_TOP_tpl (
  // CPU I/F: up bus from U02_CPUIF (replaces ADDR/WDATA/RDATA/WREN/RDEN/RDVAL_CPUIF)
  input         up_rstn,
  input         up_clk,           // FCLK_CLK0 100 MHz
  input         up_req,
  input         up_wr,            // 1: write, 0: read
  input  [11:0] up_addr,
  input  [31:0] up_wdata,
  output        up_ack,
  output [31:0] up_rdata,

  // input clocks
  input         EXT_SYSCLK_IN,    // 122.88 MHz from SI5386

  // output clocks
  output        CLK_SYSX4,        // 122.88 MHz
  output        CLK_SYSX6,        // 184.32 MHz
  output        CLK_SYSX8,        // 245.76 MHz
  output        CLK_MISC0,        // 25 MHz
  output        CLK_MISC3,        // 200 MHz

  // output resets: active high, sync to the corresponding clock
  output        RST_SYSX4,
  output        RST_SYSX6,
  output        RST_SYSX8,
  output        RST_MISC0,
  output        RST_MISC3

  // ... other ports unchanged from SYSCTRL_TOP.vhd
);

  // ------------------------------------------------------------------------
  // clock gen
  // ------------------------------------------------------------------------

  wire          pll_rst;
  wire          data_pll_clk_out1;
  wire          data_pll_clk_out2;
  wire          data_pll_locked;
  wire          mii_pll_locked;

  assign pll_rst = ~up_rstn;

  DATA_PLL U_TRAFFIC_CLK_GEN (
    .clk_in1  (EXT_SYSCLK_IN),
    .clk_out1 (data_pll_clk_out1),    // 122.88
    .clk_out2 (data_pll_clk_out2),    // 245.76
    .clk_out3 (),                     // 30.72
    .clk_out4 (CLK_SYSX6),            // 184.32
    .reset    (pll_rst),
    .locked   (data_pll_locked));

  BUFG U_122P88M_CLK_BUFG (.I(data_pll_clk_out1), .O(CLK_SYSX4));
  BUFG U_245P76M_CLK_BUFG (.I(data_pll_clk_out2), .O(CLK_SYSX8));

  CPU_MII_PLL U_CPU_MII_CLK_GEN (
    .clk_in1  (up_clk),
    .clk_out1 (CLK_MISC0),            // 25
    .clk_out2 (CLK_MISC3),            // 200
    .reset    (pll_rst),
    .locked   (mii_pll_locked));

  // ------------------------------------------------------------------------
  // per-domain reset
  // ------------------------------------------------------------------------

  xpm_cdc_async_rst #(.DEST_SYNC_FF(4), .INIT_SYNC_FF(0), .RST_ACTIVE_HIGH(1)) U_RST_SYSX4 (
    .src_arst  (pll_rst | ~data_pll_locked),
    .dest_clk  (CLK_SYSX4),
    .dest_arst (RST_SYSX4));

  xpm_cdc_async_rst #(.DEST_SYNC_FF(4), .INIT_SYNC_FF(0), .RST_ACTIVE_HIGH(1)) U_RST_SYSX6 (
    .src_arst  (pll_rst | ~data_pll_locked),
    .dest_clk  (CLK_SYSX6),
    .dest_arst (RST_SYSX6));

  xpm_cdc_async_rst #(.DEST_SYNC_FF(4), .INIT_SYNC_FF(0), .RST_ACTIVE_HIGH(1)) U_RST_SYSX8 (
    .src_arst  (pll_rst | ~data_pll_locked),
    .dest_clk  (CLK_SYSX8),
    .dest_arst (RST_SYSX8));

  xpm_cdc_async_rst #(.DEST_SYNC_FF(4), .INIT_SYNC_FF(0), .RST_ACTIVE_HIGH(1)) U_RST_MISC0 (
    .src_arst  (pll_rst | ~mii_pll_locked),
    .dest_clk  (CLK_MISC0),
    .dest_arst (RST_MISC0));

  xpm_cdc_async_rst #(.DEST_SYNC_FF(4), .INIT_SYNC_FF(0), .RST_ACTIVE_HIGH(1)) U_RST_MISC3 (
    .src_arst  (pll_rst | ~mii_pll_locked),
    .dest_clk  (CLK_MISC3),
    .dest_arst (RST_MISC3));

  // ------------------------------------------------------------------------
  // CPU I/F
  // ------------------------------------------------------------------------

  wire [31:0]   reg_sys_1;        // @ up_clk
  wire [31:0]   reg_sys_2;        // @ up_clk
  wire [31:0]   reg_sys_3;        // @ CLK_SYSX8
  wire [31:0]   reg_sys_4;        // @ CLK_SYSX8

  CPUIF_SYSCTRL_tpl inst_cpuif_sysctrl (
    .up_rstn    (up_rstn),
    .up_clk     (up_clk),
    .up_req     (up_req),
    .up_wr      (up_wr),
    .up_addr    (up_addr),
    .up_wdata   (up_wdata),
    .up_ack     (up_ack),
    .up_rdata   (up_rdata),
    .CLK_SYSX8  (CLK_SYSX8),
    .RST_SYSX8  (RST_SYSX8),
    .REG_SYS_1  (reg_sys_1),
    .REG_SYS_2  (reg_sys_2),
    .REG_SYS_3  (reg_sys_3),
    .REG_SYS_4  (reg_sys_4));

  // ------------------------------------------------------------------------
  // core SYSCTRL: uses reg_sys_1..4
  //   reg_sys_1/2 @ up_clk    : watchdog, LED, reset control...
  //   reg_sys_3/4 @ CLK_SYSX8 : SYNC_RETARD / SYNC_ADVANCE...
  // ------------------------------------------------------------------------

endmodule
