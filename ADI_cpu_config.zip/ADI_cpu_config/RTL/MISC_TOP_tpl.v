// ***************************************************************************
// File        : MISC_TOP_tpl.v
// Description : Template U10_MISC (replaces MISC_TOP.vhd) on the up bus.
//
//   CPU I/F: U_CPUIF_MISC (CPUIF_MISC_tpl), 4 registers REG_MISC_1..4 used
//   inside MISC: REG_MISC_1 @ up_clk 100, REG_MISC_2 @ CLK_SYSX4 122.88,
//   REG_MISC_3 @ CLK_SYSX8 245.76, REG_MISC_4 @ CLK_MISC3 200.
// ***************************************************************************

`timescale 1ns/100ps

module MISC_TOP_tpl (
  // CPU I/F: up bus from U02_CPUIF (replaces ADDR/WDATA/RDATA/WREN/RDEN/RDVAL_CPUIF)
  input         up_rstn,
  input         up_clk,           // CLK_CPUIF 100 MHz
  input         up_req,
  input         up_wr,            // 1: write, 0: read
  input  [11:0] up_addr,
  input  [31:0] up_wdata,
  output        up_ack,
  output [31:0] up_rdata,

  // clock / reset
  input         CLK_SYSX4,        // 122.88 MHz
  input         RST_SYSX4,        // active high, sync to CLK_SYSX4
  input         CLK_SYSX8,        // 245.76 MHz
  input         RST_SYSX8,        // active high, sync to CLK_SYSX8
  input         CLK_MISC3,        // 200 MHz
  input         RST_MISC3         // active high, sync to CLK_MISC3

  // ... other ports unchanged from MISC_TOP.vhd
);

  // ------------------------------------------------------------------------
  // CPU I/F
  // ------------------------------------------------------------------------

  wire [31:0]   reg_misc_1;       // @ up_clk
  wire [31:0]   reg_misc_2;       // @ CLK_SYSX4
  wire [31:0]   reg_misc_3;       // @ CLK_SYSX8
  wire [31:0]   reg_misc_4;       // @ CLK_MISC3

  CPUIF_MISC_tpl U_CPUIF_MISC (
    .up_rstn     (up_rstn),
    .up_clk      (up_clk),
    .up_req      (up_req),
    .up_wr       (up_wr),
    .up_addr     (up_addr),
    .up_wdata    (up_wdata),
    .up_ack      (up_ack),
    .up_rdata    (up_rdata),
    .CLK_SYSX4   (CLK_SYSX4),
    .RST_SYSX4   (RST_SYSX4),
    .CLK_SYSX8   (CLK_SYSX8),
    .RST_SYSX8   (RST_SYSX8),
    .CLK_MISC3   (CLK_MISC3),
    .RST_MISC3   (RST_MISC3),
    .REG_MISC_1  (reg_misc_1),
    .REG_MISC_2  (reg_misc_2),
    .REG_MISC_3  (reg_misc_3),
    .REG_MISC_4  (reg_misc_4));

  // ------------------------------------------------------------------------
  // core MISC: uses reg_misc_1..4
  //   reg_misc_1 @ up_clk    : LED, UART, power control...
  //   reg_misc_2 @ CLK_SYSX4 / reg_misc_3 @ CLK_SYSX8 / reg_misc_4 @ CLK_MISC3
  // ------------------------------------------------------------------------

endmodule
