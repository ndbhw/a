//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
//Date        : Wed Sep 23 11:20:56 2026
//Host        : DESKTOP-QHFE1DR running 64-bit major release  (build 9200)
//Command     : generate_target bd_cpu_wrapper.bd
//Design      : bd_cpu_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module bd_cpu_wrapper
   (FCLK_CLK,
    FCLK_NRST,
    up_rack_0,
    up_raddr_0,
    up_rdata_0,
    up_rreq_0,
    up_wack_0,
    up_waddr_0,
    up_wdata_0,
    up_wreq_0);
  output FCLK_CLK;
  output [0:0]FCLK_NRST;
  input up_rack_0;
  output [29:0]up_raddr_0;
  input [31:0]up_rdata_0;
  output up_rreq_0;
  input up_wack_0;
  output [29:0]up_waddr_0;
  output [31:0]up_wdata_0;
  output up_wreq_0;

  wire FCLK_CLK;
  wire [0:0]FCLK_NRST;
  wire up_rack_0;
  wire [29:0]up_raddr_0;
  wire [31:0]up_rdata_0;
  wire up_rreq_0;
  wire up_wack_0;
  wire [29:0]up_waddr_0;
  wire [31:0]up_wdata_0;
  wire up_wreq_0;

  bd_cpu bd_cpu_i
       (.FCLK_CLK(FCLK_CLK),
        .FCLK_NRST(FCLK_NRST),
        .up_rack_0(up_rack_0),
        .up_raddr_0(up_raddr_0),
        .up_rdata_0(up_rdata_0),
        .up_rreq_0(up_rreq_0),
        .up_wack_0(up_wack_0),
        .up_waddr_0(up_waddr_0),
        .up_wdata_0(up_wdata_0),
        .up_wreq_0(up_wreq_0));
endmodule
