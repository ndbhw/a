--------------------------------------------------------------------------------
--
-- Copyright (C) 2025, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Author   : jaekyu.no (jaekyu.no@samsung.com)
-- Date     : 2025.03.18
-- Module   : O-RAN Top (RF2221/22/25 CFPGA)
--------------------------------------------------------------------------------
-- Change log
--   Rev 1 (2025.03.18) - initial release
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;
use WORK.PKG_ORAN.ALL;
use WORK.PKG_ORAN_ARRAY.ALL;
use work.RU_FPGA_CONFIG.all;

entity ORAN_TOP is
    generic (
        CELL_NUM_eMTC               : natural :=  1
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;                            -- 100MHz
        RST_CPUIF                   : in  std_logic;                            

        ARESET_RX                   : in  std_logic_vector(3 downto 0);         -- RX(DL) Reset per Cell
        ARESET_TX                   : in  std_logic_vector(3 downto 0);         -- TX(UL) Reset per Cell

        CLK_MAC_RX                  : in  std_logic;                            -- 156.25/390.625-MHz
        CLK_MAC_TX                  : in  std_logic;                            -- 156.25/390.625-MHz
        CLK_BUS                     : in  std_logic;                            -- 245.76-MHz

--------------------------------------------------------------------------------
-- Sync
--------------------------------------------------------------------------------

        TICK_1PPS                   : in  std_logic;                            -- 8-clocks@CLK_BUS
        FRAME_SYNC                  : in  std_logic;                            -- should be aligned with 1PPS 
        FRAME_NUM                   : in  std_logic_vector(11 downto 0);

--        SBIF_CHIPSYNC               : in  std_logic;
--        SBIF_DATA                   : out std_logic_vector(15 downto 0);

        DL_CC0_SYNC_ADVANCE         : in  std_logic_vector(21 downto 0);
        UL_CC0_SYNC_RETARD          : in  std_logic_vector(21 downto 0);
        DL_CC1_SYNC_ADVANCE         : in  std_logic_vector(21 downto 0);   -- MJANG added
        UL_CC1_SYNC_RETARD          : in  std_logic_vector(21 downto 0);   -- MJANG added
--        DL_CC2_SYNC_ADVANCE         : in  std_logic_vector(21 downto 0);   -- MJANG added
--        UL_CC2_SYNC_RETARD          : in  std_logic_vector(21 downto 0);   -- MJANG added
--        DL_CC3_SYNC_ADVANCE         : in  std_logic_vector(21 downto 0);   -- MJANG added
--        UL_CC3_SYNC_RETARD          : in  std_logic_vector(21 downto 0);   -- MJANG added
    
        TDD_CC0_SYMBOL_SYNC         : out std_logic;                       -- MJANG modified
        TDD_CC0_SYMBOL_INDEX        : out std_logic_vector(3 downto 0);    -- MJANG modified
        TDD_CC0_DL_EN               : out std_logic_vector(1 downto 0);    -- MJANG modified
        TDD_CC0_UL_EN               : out std_logic_vector(1 downto 0);    -- MJANG modified

        TDD_CC1_SYMBOL_SYNC         : out std_logic;                       -- MJANG added 
        TDD_CC1_SYMBOL_INDEX        : out std_logic_vector(3 downto 0);    -- MJANG added 
        TDD_CC1_DL_EN               : out std_logic_vector(1 downto 0);    -- MJANG added 
        TDD_CC1_UL_EN               : out std_logic_vector(1 downto 0);    -- MJANG added     

--        TDD_CC2_SYMBOL_SYNC         : out std_logic;                       -- MJANG added 
--        TDD_CC2_SYMBOL_INDEX        : out std_logic_vector(3 downto 0);    -- MJANG added 
--        TDD_CC2_DL_EN               : out std_logic_vector(1 downto 0);    -- MJANG added 
--        TDD_CC2_UL_EN               : out std_logic_vector(1 downto 0);    -- MJANG added         

--        TDD_CC3_SYMBOL_SYNC         : out std_logic;                       -- MJANG added 
--        TDD_CC3_SYMBOL_INDEX        : out std_logic_vector(3 downto 0);    -- MJANG added 
--        TDD_CC3_DL_EN               : out std_logic_vector(1 downto 0);    -- MJANG added 
--        TDD_CC3_UL_EN               : out std_logic_vector(1 downto 0);    -- MJANG added             

        N_TA_OFFSET_CC0             : in  std_logic_vector(15 downto 0);
        N_TA_OFFSET_CC1             : in  std_logic_vector(15 downto 0);
--        N_TA_OFFSET_CC2             : in  std_logic_vector(15 downto 0);
--        N_TA_OFFSET_CC3             : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- CPU interface
--------------------------------------------------------------------------------

        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        RDVAL_CPUIF_OUT             : out std_logic;

--------------------------------------------------------------------------------
-- MAC#0
--------------------------------------------------------------------------------

        MAC0_RX_VALID               : in  std_logic;
        MAC0_RX_LAST                : in  std_logic;
        MAC0_RX_KEEP                : in  std_logic_vector(7 downto 0);
        MAC0_RX_DATA                : in  std_logic_vector(63 downto 0);

        MAC0_TX_READY               : in  std_logic;
        MAC0_TX_VALID               : out std_logic;
        MAC0_TX_LAST                : out std_logic;
        MAC0_TX_KEEP                : out std_logic_vector(7 downto 0);
        MAC0_TX_DATA                : out std_logic_vector(63 downto 0);

--------------------------------------------------------------------------------
-- MAC#1
--------------------------------------------------------------------------------

        MAC1_RX_VALID               : in  std_logic;
        MAC1_RX_LAST                : in  std_logic;
        MAC1_RX_KEEP                : in  std_logic_vector(7 downto 0);
        MAC1_RX_DATA                : in  std_logic_vector(63 downto 0);

        MAC1_TX_READY               : in  std_logic;
        MAC1_TX_VALID               : out std_logic;
        MAC1_TX_LAST                : out std_logic;
        MAC1_TX_KEEP                : out std_logic_vector(7 downto 0);
        MAC1_TX_DATA                : out std_logic_vector(63 downto 0);

--------------------------------------------------------------------------------
-- DLFE
--------------------------------------------------------------------------------
        
        -- MJANG Modified
        DLFE_CC0_SYSTEM_MODE        : in  std_logic;  
        DLFE_CC0_K0                 : in  std_logic_vector(11 downto 0);
        DLFE_CC0_nRE                : in  std_logic_vector(11 downto 0);
        DLFE_CC0_nFFT               : in  std_logic_vector(1 downto 0); 
        DLFE_CC0_FRAME_SYNC         : out std_logic;
        DLFE_CC0_FRAME_INDEX        : out std_logic_vector(7 downto 0);
        DLFE_CC0_VALID              : out std_logic_vector(DL_NUM_ANT-1 downto 0);                       
        DLFE_CC0_RE_MASK            : out std_logic_vector(DL_NUM_ANT-1 downto 0);
        DLFE_CC0_DATA               : out std_logic_vector(DL_NUM_ANT*32-1 downto 0);   

        -- MJANG Added
        DLFE_CC1_SYSTEM_MODE        : in  std_logic;  
        DLFE_CC1_K0                 : in  std_logic_vector(11 downto 0);
        DLFE_CC1_nRE                : in  std_logic_vector(11 downto 0);
        DLFE_CC1_nFFT               : in  std_logic_vector(1 downto 0); 
        DLFE_CC1_FRAME_SYNC         : out std_logic;
        DLFE_CC1_FRAME_INDEX        : out std_logic_vector(7 downto 0);
        DLFE_CC1_VALID              : out std_logic_vector(DL_NUM_ANT-1 downto 0);                       
        DLFE_CC1_RE_MASK            : out std_logic_vector(DL_NUM_ANT-1 downto 0);
        DLFE_CC1_DATA               : out std_logic_vector(DL_NUM_ANT*32-1 downto 0);   

--        -- MJANG Added
--        DLFE_CC2_SYSTEM_MODE        : in  std_logic;  
--        DLFE_CC2_K0                 : in  std_logic_vector(11 downto 0);
--        DLFE_CC2_nRE                : in  std_logic_vector(11 downto 0);
--        DLFE_CC2_nFFT               : in  std_logic_vector(1 downto 0); 
--        DLFE_CC2_FRAME_SYNC         : out std_logic;
--        DLFE_CC2_FRAME_INDEX        : out std_logic_vector(7 downto 0);
--        DLFE_CC2_VALID              : out std_logic_vector(2-1 downto 0); 
--        DLFE_CC2_RE_MASK            : out std_logic_vector(2-1 downto 0);
--        DLFE_CC2_DATA               : out std_logic_vector(2*32-1 downto 0);   

--        -- MJANG Added
--        DLFE_CC3_SYSTEM_MODE        : in  std_logic;  
--        DLFE_CC3_K0                 : in  std_logic_vector(11 downto 0);
--        DLFE_CC3_nRE                : in  std_logic_vector(11 downto 0);
--        DLFE_CC3_nFFT               : in  std_logic_vector(1 downto 0); 
--        DLFE_CC3_FRAME_SYNC         : out std_logic;
--        DLFE_CC3_FRAME_INDEX        : out std_logic_vector(7 downto 0);
--        DLFE_CC3_VALID              : out std_logic_vector(2-1 downto 0);                       
--        DLFE_CC3_RE_MASK            : out std_logic_vector(2-1 downto 0);
--        DLFE_CC3_DATA               : out std_logic_vector(2*32-1 downto 0);   

--------------------------------------------------------------------------------
-- ULFE
--------------------------------------------------------------------------------

        -- MJANG Modified
        ULFE_CC0_FRAME_ID           : in  std_logic_vector(7 downto 0);
        ULFE_CC0_SUBFRAME_ID        : in  std_logic_vector(3 downto 0);
        ULFE_CC0_SLOT_ID            : in  std_logic_vector(5 downto 0);
        ULFE_CC0_SYMBOL_ID          : in  std_logic_vector(5 downto 0);
        ULFE_CC0_START_RE           : in  std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        ULFE_CC0_VALID              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        ULFE_CC0_START              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        ULFE_CC0_LAST               : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        ULFE_CC0_DATA               : in  std_logic_vector(UL_NUM_ANT*32-1 downto 0);

        -- MJANG Added
        ULFE_CC1_FRAME_ID           : in  std_logic_vector(7 downto 0);
        ULFE_CC1_SUBFRAME_ID        : in  std_logic_vector(3 downto 0);
        ULFE_CC1_SLOT_ID            : in  std_logic_vector(5 downto 0);
        ULFE_CC1_SYMBOL_ID          : in  std_logic_vector(5 downto 0);
        ULFE_CC1_START_RE           : in  std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        ULFE_CC1_VALID              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        ULFE_CC1_START              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        ULFE_CC1_LAST               : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        ULFE_CC1_DATA               : in  std_logic_vector(UL_NUM_ANT*32-1 downto 0);    

--        -- MJANG Added
--        ULFE_CC2_FRAME_ID           : in  std_logic_vector(7 downto 0);
--        ULFE_CC2_SUBFRAME_ID        : in  std_logic_vector(3 downto 0);
--        ULFE_CC2_SLOT_ID            : in  std_logic_vector(5 downto 0);
--        ULFE_CC2_SYMBOL_ID          : in  std_logic_vector(5 downto 0);
--        ULFE_CC2_START_RE           : in  std_logic_vector(2*16-1 downto 0);
--        ULFE_CC2_VALID              : in  std_logic_vector(2-1 downto 0);
--        ULFE_CC2_START              : in  std_logic_vector(2-1 downto 0);
--        ULFE_CC2_LAST               : in  std_logic_vector(2-1 downto 0);
--        ULFE_CC2_DATA               : in  std_logic_vector(2*32-1 downto 0);    

--        -- MJANG Added
--        ULFE_CC3_FRAME_ID           : in  std_logic_vector(7 downto 0);
--        ULFE_CC3_SUBFRAME_ID        : in  std_logic_vector(3 downto 0);
--        ULFE_CC3_SLOT_ID            : in  std_logic_vector(5 downto 0);
--        ULFE_CC3_SYMBOL_ID          : in  std_logic_vector(5 downto 0);
--        ULFE_CC3_START_RE           : in  std_logic_vector(2*16-1 downto 0);
--        ULFE_CC3_VALID              : in  std_logic_vector(2-1 downto 0);
--        ULFE_CC3_START              : in  std_logic_vector(2-1 downto 0);
--        ULFE_CC3_LAST               : in  std_logic_vector(2-1 downto 0);
--        ULFE_CC3_DATA               : in  std_logic_vector(2*32-1 downto 0);        

--------------------------------------------------------------------------------
-- RAFE
--------------------------------------------------------------------------------

        -- MJANG Modified
        RAFE_CC0_FRAMES_SYNC        : out std_logic;
        RAFE_CC0_FILTER_INDEX       : out std_logic_vector(UL_NUM_ANT*4-1 downto 0);
        RAFE_CC0_TIME_OFFSET        : out std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        RAFE_CC0_FRAME_STRUCTURE    : out std_logic_vector(UL_NUM_ANT*8-1 downto 0);
        RAFE_CC0_CPLENGTH           : out std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        RAFE_CC0_FREQ_OFFSET        : out std_logic_vector(UL_NUM_ANT*24-1 downto 0);
        RAFE_CC0_START_PRBC         : out std_logic_vector(UL_NUM_ANT*10-1 downto 0);
        RAFE_CC0_NUM_PRBC           : out std_logic_vector(UL_NUM_ANT*8-1 downto 0);
        RAFE_CC0_NUM_PSYMBOL        : out std_logic_vector(UL_NUM_ANT*4-1 downto 0);
        RAFE_CC0_NUM_RO             : out std_logic_vector(UL_NUM_ANT*3-1 downto 0);
        RAFE_CC0_FRAME_ID           : in  std_logic_vector(7 downto 0);
        RAFE_CC0_SUBFRAME_ID        : in  std_logic_vector(3 downto 0);
        RAFE_CC0_SLOT_ID            : in  std_logic_vector(5 downto 0);
        RAFE_CC0_SYMBOL_ID          : in  std_logic_vector(5 downto 0);
        RAFE_CC0_START_RE           : in  std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        RAFE_CC0_VALID              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        RAFE_CC0_START              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        RAFE_CC0_LAST               : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        RAFE_CC0_DATA               : in  std_logic_vector(UL_NUM_ANT*32-1 downto 0);

        -- MJANG Added   
        RAFE_CC1_FRAMES_SYNC        : out std_logic;
        RAFE_CC1_FILTER_INDEX       : out std_logic_vector(UL_NUM_ANT*4-1 downto 0);
        RAFE_CC1_TIME_OFFSET        : out std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        RAFE_CC1_FRAME_STRUCTURE    : out std_logic_vector(UL_NUM_ANT*8-1 downto 0);
        RAFE_CC1_CPLENGTH           : out std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        RAFE_CC1_FREQ_OFFSET        : out std_logic_vector(UL_NUM_ANT*24-1 downto 0);
        RAFE_CC1_START_PRBC         : out std_logic_vector(UL_NUM_ANT*10-1 downto 0);
        RAFE_CC1_NUM_PRBC           : out std_logic_vector(UL_NUM_ANT*8-1 downto 0);
        RAFE_CC1_NUM_PSYMBOL        : out std_logic_vector(UL_NUM_ANT*4-1 downto 0);
        RAFE_CC1_NUM_RO             : out std_logic_vector(UL_NUM_ANT*3-1 downto 0);
        RAFE_CC1_FRAME_ID           : in  std_logic_vector(7 downto 0);
        RAFE_CC1_SUBFRAME_ID        : in  std_logic_vector(3 downto 0);
        RAFE_CC1_SLOT_ID            : in  std_logic_vector(5 downto 0);
        RAFE_CC1_SYMBOL_ID          : in  std_logic_vector(5 downto 0);
        RAFE_CC1_START_RE           : in  std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        RAFE_CC1_VALID              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        RAFE_CC1_START              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        RAFE_CC1_LAST               : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        RAFE_CC1_DATA               : in  std_logic_vector(UL_NUM_ANT*32-1 downto 0)

--        -- MJANG Added   
--        RAFE_CC2_FRAMES_SYNC        : out std_logic;
--        RAFE_CC2_FILTER_INDEX       : out std_logic_vector(2*4-1 downto 0);
--        RAFE_CC2_TIME_OFFSET        : out std_logic_vector(2*16-1 downto 0);
--        RAFE_CC2_FRAME_STRUCTURE    : out std_logic_vector(2*8-1 downto 0);
--        RAFE_CC2_CPLENGTH           : out std_logic_vector(2*16-1 downto 0);
--        RAFE_CC2_FREQ_OFFSET        : out std_logic_vector(2*24-1 downto 0);
--        RAFE_CC2_START_PRBC         : out std_logic_vector(2*10-1 downto 0);
--        RAFE_CC2_NUM_PRBC           : out std_logic_vector(2*8-1 downto 0);
--        RAFE_CC2_NUM_PSYMBOL        : out std_logic_vector(2*4-1 downto 0);
--        RAFE_CC2_NUM_RO             : out std_logic_vector(2*3-1 downto 0);
--        RAFE_CC2_FRAME_ID           : in  std_logic_vector(7 downto 0);
--        RAFE_CC2_SUBFRAME_ID        : in  std_logic_vector(3 downto 0);
--        RAFE_CC2_SLOT_ID            : in  std_logic_vector(5 downto 0);
--        RAFE_CC2_SYMBOL_ID          : in  std_logic_vector(5 downto 0);
--        RAFE_CC2_START_RE           : in  std_logic_vector(2*16-1 downto 0);
--        RAFE_CC2_VALID              : in  std_logic_vector(2-1 downto 0);
--        RAFE_CC2_START              : in  std_logic_vector(2-1 downto 0);
--        RAFE_CC2_LAST               : in  std_logic_vector(2-1 downto 0);
--        RAFE_CC2_DATA               : in  std_logic_vector(2*32-1 downto 0);      

--        -- MJANG Added   
--        RAFE_CC3_FRAMES_SYNC        : out std_logic;
--        RAFE_CC3_FILTER_INDEX       : out std_logic_vector(2*4-1 downto 0);
--        RAFE_CC3_TIME_OFFSET        : out std_logic_vector(2*16-1 downto 0);
--        RAFE_CC3_FRAME_STRUCTURE    : out std_logic_vector(2*8-1 downto 0);
--        RAFE_CC3_CPLENGTH           : out std_logic_vector(2*16-1 downto 0);
--        RAFE_CC3_FREQ_OFFSET        : out std_logic_vector(2*24-1 downto 0);
--        RAFE_CC3_START_PRBC         : out std_logic_vector(2*10-1 downto 0);
--        RAFE_CC3_NUM_PRBC           : out std_logic_vector(2*8-1 downto 0);
--        RAFE_CC3_NUM_PSYMBOL        : out std_logic_vector(2*4-1 downto 0);
--        RAFE_CC3_NUM_RO             : out std_logic_vector(2*3-1 downto 0);
--        RAFE_CC3_FRAME_ID           : in  std_logic_vector(7 downto 0);
--        RAFE_CC3_SUBFRAME_ID        : in  std_logic_vector(3 downto 0);
--        RAFE_CC3_SLOT_ID            : in  std_logic_vector(5 downto 0);
--        RAFE_CC3_SYMBOL_ID          : in  std_logic_vector(5 downto 0);
--        RAFE_CC3_START_RE           : in  std_logic_vector(2*16-1 downto 0);
--        RAFE_CC3_VALID              : in  std_logic_vector(2-1 downto 0);
--        RAFE_CC3_START              : in  std_logic_vector(2-1 downto 0);
--        RAFE_CC3_LAST               : in  std_logic_vector(2-1 downto 0);
--        RAFE_CC3_DATA               : in  std_logic_vector(2*32-1 downto 0);

--------------------------------------------------------------------------------
-- eMTC PRACH
--------------------------------------------------------------------------------

--        eMTC_CC0_FRAME_SYNC          : out std_logic;                    
--        eMTC_CC0_FILTER_INDEX        : out std_logic_vector(2*4-1 downto 0); 
--        eMTC_CC0_TIME_OFFSET         : out std_logic_vector(2*16-1 downto 0); 
--        eMTC_CC0_FRAME_STRUCTURE     : out std_logic_vector(2*8-1 downto 0); 
--        eMTC_CC0_CPLENGTH            : out std_logic_vector(2*16-1 downto 0); 
--        eMTC_CC0_FREQ_OFFSET         : out std_logic_vector(2*24-1 downto 0); 
--        eMTC_CC0_START_PRBC          : out std_logic_vector(2*10-1 downto 0);
--        eMTC_CC0_NUM_PRBC            : out std_logic_vector(2*8-1 downto 0);
--        eMTC_CC0_NUM_PSYMBOL         : out std_logic_vector(2*4-1 downto 0); 
--        eMTC_CC0_NUM_RO              : out std_logic_vector(2*3-1 downto 0); 
--        eMTC_CC0_FRAME_ID            : in  std_logic_vector(8-1   downto 0);
--        eMTC_CC0_SUBFRAME_ID         : in  std_logic_vector(4-1   downto 0);
--        eMTC_CC0_SLOT_ID             : in  std_logic_vector(6-1   downto 0);
--        eMTC_CC0_SYMBOL_ID           : in  std_logic_vector(6-1   downto 0);
--        eMTC_CC0_START_RE            : in  std_logic_vector(2*16-1 downto 0);
--        eMTC_CC0_VALID               : in  std_logic_vector(2*1 -1 downto 0); 
--        eMTC_CC0_START               : in  std_logic_vector(2*1 -1 downto 0); 
--        eMTC_CC0_LAST                : in  std_logic_vector(2*1 -1 downto 0); 
--        eMTC_CC0_DATA                : in  std_logic_vector(2*32-1 downto 0);    

--        eMTC_CC1_FRAME_SYNC          : out std_logic;                    
--        eMTC_CC1_FILTER_INDEX        : out std_logic_vector(2*4-1 downto 0); 
--        eMTC_CC1_TIME_OFFSET         : out std_logic_vector(2*16-1 downto 0); 
--        eMTC_CC1_FRAME_STRUCTURE     : out std_logic_vector(2*8-1 downto 0); 
--        eMTC_CC1_CPLENGTH            : out std_logic_vector(2*16-1 downto 0); 
--        eMTC_CC1_FREQ_OFFSET         : out std_logic_vector(2*24-1 downto 0); 
--        eMTC_CC1_START_PRBC          : out std_logic_vector(2*10-1 downto 0);
--        eMTC_CC1_NUM_PRBC            : out std_logic_vector(2*8-1 downto 0);
--        eMTC_CC1_NUM_PSYMBOL         : out std_logic_vector(2*4-1 downto 0); 
--        eMTC_CC1_NUM_RO              : out std_logic_vector(2*3-1 downto 0); 
--        eMTC_CC1_FRAME_ID            : in  std_logic_vector(8-1   downto 0);
--        eMTC_CC1_SUBFRAME_ID         : in  std_logic_vector(4-1   downto 0);
--        eMTC_CC1_SLOT_ID             : in  std_logic_vector(6-1   downto 0);
--        eMTC_CC1_SYMBOL_ID           : in  std_logic_vector(6-1   downto 0);
--        eMTC_CC1_START_RE            : in  std_logic_vector(2*16-1 downto 0);
--        eMTC_CC1_VALID               : in  std_logic_vector(2*1 -1 downto 0); 
--        eMTC_CC1_START               : in  std_logic_vector(2*1 -1 downto 0); 
--        eMTC_CC1_LAST                : in  std_logic_vector(2*1 -1 downto 0); 
--        eMTC_CC1_DATA                : in  std_logic_vector(2*32-1 downto 0);    

--        eMTC_CC2_FRAME_SYNC          : out std_logic;                    
--        eMTC_CC2_FILTER_INDEX        : out std_logic_vector(2*4-1 downto 0); 
--        eMTC_CC2_TIME_OFFSET         : out std_logic_vector(2*16-1 downto 0); 
--        eMTC_CC2_FRAME_STRUCTURE     : out std_logic_vector(2*8-1 downto 0); 
--        eMTC_CC2_CPLENGTH            : out std_logic_vector(2*16-1 downto 0); 
--        eMTC_CC2_FREQ_OFFSET         : out std_logic_vector(2*24-1 downto 0); 
--        eMTC_CC2_START_PRBC          : out std_logic_vector(2*10-1 downto 0);
--        eMTC_CC2_NUM_PRBC            : out std_logic_vector(2*8-1 downto 0);
--        eMTC_CC2_NUM_PSYMBOL         : out std_logic_vector(2*4-1 downto 0); 
--        eMTC_CC2_NUM_RO              : out std_logic_vector(2*3-1 downto 0); 
--        eMTC_CC2_FRAME_ID            : in  std_logic_vector(8-1   downto 0);
--        eMTC_CC2_SUBFRAME_ID         : in  std_logic_vector(4-1   downto 0);
--        eMTC_CC2_SLOT_ID             : in  std_logic_vector(6-1   downto 0);
--        eMTC_CC2_SYMBOL_ID           : in  std_logic_vector(6-1   downto 0);
--        eMTC_CC2_START_RE            : in  std_logic_vector(2*16-1 downto 0);
--        eMTC_CC2_VALID               : in  std_logic_vector(2*1 -1 downto 0); 
--        eMTC_CC2_START               : in  std_logic_vector(2*1 -1 downto 0); 
--        eMTC_CC2_LAST                : in  std_logic_vector(2*1 -1 downto 0); 
--        eMTC_CC2_DATA                : in  std_logic_vector(2*32-1 downto 0);    

--        eMTC_CC3_FRAME_SYNC          : out std_logic;                    
--        eMTC_CC3_FILTER_INDEX        : out std_logic_vector(2*4-1 downto 0); 
--        eMTC_CC3_TIME_OFFSET         : out std_logic_vector(2*16-1 downto 0); 
--        eMTC_CC3_FRAME_STRUCTURE     : out std_logic_vector(2*8-1 downto 0); 
--        eMTC_CC3_CPLENGTH            : out std_logic_vector(2*16-1 downto 0); 
--        eMTC_CC3_FREQ_OFFSET         : out std_logic_vector(2*24-1 downto 0); 
--        eMTC_CC3_START_PRBC          : out std_logic_vector(2*10-1 downto 0);
--        eMTC_CC3_NUM_PRBC            : out std_logic_vector(2*8-1 downto 0);
--        eMTC_CC3_NUM_PSYMBOL         : out std_logic_vector(2*4-1 downto 0); 
--        eMTC_CC3_NUM_RO              : out std_logic_vector(2*3-1 downto 0); 
--        eMTC_CC3_FRAME_ID            : in  std_logic_vector(8-1   downto 0);
--        eMTC_CC3_SUBFRAME_ID         : in  std_logic_vector(4-1   downto 0);
--        eMTC_CC3_SLOT_ID             : in  std_logic_vector(6-1   downto 0);
--        eMTC_CC3_SYMBOL_ID           : in  std_logic_vector(6-1   downto 0);
--        eMTC_CC3_START_RE            : in  std_logic_vector(2*16-1 downto 0);
--        eMTC_CC3_VALID               : in  std_logic_vector(2*1 -1 downto 0); 
--        eMTC_CC3_START               : in  std_logic_vector(2*1 -1 downto 0); 
--        eMTC_CC3_LAST                : in  std_logic_vector(2*1 -1 downto 0); 
--        eMTC_CC3_DATA                : in  std_logic_vector(2*32-1 downto 0);        

    );
end ORAN_TOP;

architecture BEHAVE of ORAN_TOP is

    constant DL_ANT_LAYER           : natural := 4; --2;
    constant DL_ANT_PER_UNIT        : natural := 4; --2;
    constant UL_ANT_RX              : natural := 4; --2;
    constant UL_ANT_PER_UNIT        : natural := 4; --2;
                                                    --
    constant NUM_MUX_TX             : natural := 2; --5;                             -- Mux per CC
                                                    --
    constant MAX_CC_DL              : natural := 2; --4;
    constant MAX_CC_UL              : natural := 2; --4;
    constant MAX_PDxCH              : natural := 4; --2; --2;
    constant MAX_SSB                : natural := 0; --0;
    constant MAX_H_MATRIX           : natural := 0; --0;
    constant MAX_PUxCH              : natural := 4; --2; --2;
    constant MAX_PRACH              : natural := 4; --2; --2;
    constant MAX_SRS                : natural := 0; --0;
    constant MAX_RIM_RS             : natural := 0; --0;
    constant MAX_NB_IoT             : natural := 0; --2; --2;
    constant MAX_PE                 : natural := 4; --4;

    constant DL_UNIT                : natural := MAX_CC_DL*DL_ANT_LAYER/DL_ANT_PER_UNIT;
    constant UL_UNIT                : natural := MAX_CC_UL*UL_ANT_RX/UL_ANT_PER_UNIT;

    constant NUM_PORT_TX            : natural := UL_UNIT; --4;                       -- Mux per FH

    component eCPRI_PROC_SYS_RESET is
    port (
        SLOWEST_SYNC_CLK            : in  std_logic;
        EXT_RESET_IN                : in  std_logic;
        AUX_RESET_IN                : in  std_logic;
        MB_DEBUG_SYS_RST            : in  std_logic;
        DCM_LOCKED                  : in  std_logic;
        MB_RESET                    : out std_logic;
        BUS_STRUCT_RESET            : out std_logic_vector(0 downto 0);
        PERIPHERAL_RESET            : out std_logic_vector(0 downto 0);
        INTERCONNECT_ARESETN        : out std_logic_vector(0 downto 0);
        PERIPHERAL_ARESETN          : out std_logic_vector(0 downto 0)
    );
    end component;

    signal sreset_inter_rx          : std_logic_vector(0 downto 0);
    signal sreset_peri_rx           : std_logic_vector(0 downto 0);
    signal sreset_inter_n_rx        : std_logic_vector(0 downto 0);
    signal sreset_peri_n_rx         : std_logic_vector(0 downto 0);

    signal sreset_inter_tx          : std_logic_vector(0 downto 0);
    signal sreset_peri_tx           : std_logic_vector(0 downto 0);
    signal sreset_inter_n_tx        : std_logic_vector(0 downto 0);
    signal sreset_peri_n_tx         : std_logic_vector(0 downto 0);

    component FH_INTERCONNECT is
    generic (
        IMPL_PDxCH                  : boolean := true;
        IMPL_SSB                    : boolean := false;
        IMPL_H_MATRIX               : boolean := false;
        IMPL_PUxCH                  : boolean := true;
        IMPL_PRACH                  : boolean := true;
        IMPL_SRS                    : boolean := false;
        IMPL_RIM_RS                 : boolean := false;
        IMPL_NB_IoT                 : boolean := false;

        MAX_PDxCH                   : natural := 4;
        MAX_SSB                     : natural := 0;
        MAX_H_MATRIX                : natural := 0;
        MAX_PUxCH                   : natural := 4;
        MAX_PRACH                   : natural := 4;
        MAX_SRS                     : natural := 0;
        MAX_RIM_RS                  : natural := 0;
        MAX_NB_IoT                  : natural := 0;

        NUM_PORT_TX                 : natural := 2
    );
    port (
        CLK_MAC_RX                  : in  std_logic;
        CLK_MAC_TX                  : in  std_logic;
        CLK_BUS                     : in  std_logic;

        RST_RX                      : in  std_logic;
        RST_RX_n                    : in  std_logic;
        RST_TX                      : in  std_logic;
        RST_TX_n                    : in  std_logic;

        IGNORE_VLAN_VID             : in  std_logic;

        DL_PARAM_ID_EN              : in  std_logic_array64(7 downto 0);
        DL_PARAM_ID                 : in  std_logic_array64_array16(7 downto 0);
        DL_PE_INDEX                 : in  std_logic_array64_array8(7 downto 0);
        DL_SCS_CONFIG               : in  std_logic_array64_array4(7 downto 0);

        UL_PARAM_ID_EN              : in  std_logic_array64(7 downto 0);
        UL_PARAM_ID                 : in  std_logic_array64_array16(7 downto 0);
        UL_PE_INDEX                 : in  std_logic_array64_array8(7 downto 0);
        UL_SCS_CONFIG               : in  std_logic_array64_array4(7 downto 0);

        PARAM_DST_MAC               : in  std_logic_array48(7 downto 0);
        PARAM_SRC_MAC               : in  std_logic_array48(7 downto 0);
        PARAM_VLAN0_MODE            : in  std_logic_vector(7 downto 0);
        PARAM_VLAN0_VID             : in  std_logic_array12(7 downto 0);
        PARAM_VLAN1_MODE            : in  std_logic_vector(7 downto 0);
        PARAM_VLAN1_VID             : in  std_logic_array12(7 downto 0);

        RX_PE_VALID                 : out std_logic_array32(7 downto 0);
        RX_INVALID_DST_MAC          : out std_logic_array32(7 downto 0);
        RX_INVALID_SRC_MAC          : out std_logic_array32(7 downto 0);
        RX_INVALID_VLAN_VID         : out std_logic_array32(7 downto 0);

        RX_DISCONTINUE              : out std_logic_vector(31 downto 0);
        RX_BYTE_SIZE                : out std_logic_vector(31 downto 0);
        RX_BYTE_ALIGN               : out std_logic_vector(31 downto 0);

        RX_DL_CP_POSITION           : out std_logic_array64(7 downto 0);
        RX_DL_UP_POSITION           : out std_logic_array64(7 downto 0);
        RX_UL_CP_POSITION           : out std_logic_array64(7 downto 0);

        MAC_RX_VALID                : in  std_logic;
        MAC_RX_LAST                 : in  std_logic;
        MAC_RX_KEEP                 : in  std_logic_vector(7 downto 0);
        MAC_RX_DATA                 : in  std_logic_vector(63 downto 0);

        MAC_TX_READY                : in  std_logic;
        MAC_TX_VALID                : out std_logic;
        MAC_TX_LAST                 : out std_logic;
        MAC_TX_KEEP                 : out std_logic_vector(7 downto 0);
        MAC_TX_DATA                 : out std_logic_vector(63 downto 0);

        PACKET_IS_CP_DL             : out std_logic_vector(MAX_RU_ELEMENT-1 downto 0);
        PACKET_IS_CP_UL             : out std_logic_vector(MAX_RU_ELEMENT-1 downto 0);
        PACKET_IS_UP_DL             : out std_logic_vector(MAX_RU_ELEMENT-1 downto 0);
        PACKET_IS_NDM               : out std_logic;
        PACKET_SCS                  : out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             : out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              : out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            : out std_logic_vector(5 downto 0);

        ORAN_RX_C64_VALID           : out std_logic;
        ORAN_RX_C64_LAST            : out std_logic;
        ORAN_RX_C64_KEEP            : out std_logic_vector(7 downto 0);
        ORAN_RX_C64_DATA            : out std_logic_vector(63 downto 0);
        ORAN_RX_C64_DATA_INDEX      : out std_logic_vector(2 downto 0);
        ORAN_RX_C64_LINK_MAP        : out std_logic_vector(15 downto 0);

        ORAN_RX_U64_VALID           : out std_logic;
        ORAN_RX_U64_LAST            : out std_logic;
        ORAN_RX_U64_KEEP            : out std_logic_vector(7 downto 0);
        ORAN_RX_U64_DATA            : out std_logic_vector(63 downto 0);
        ORAN_RX_U64_DATA_INDEX      : out std_logic_vector(2 downto 0);
        ORAN_RX_U64_LINK_MAP        : out std_logic_vector(15 downto 0);

        MAC_IC_TX_READY             : out std_logic_vector(NUM_PORT_TX-1 downto 0);
        MAC_IC_TX_VALID             : in  std_logic_vector(NUM_PORT_TX-1 downto 0);
        MAC_IC_TX_LAST              : in  std_logic_vector(NUM_PORT_TX-1 downto 0);
        MAC_IC_TX_KEEP              : in  std_logic_array8(NUM_PORT_TX-1 downto 0);
        MAC_IC_TX_DATA              : in  std_logic_array64(NUM_PORT_TX-1 downto 0);
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

--------------------------------------------------------------------------------
-- Synchronization
--------------------------------------------------------------------------------

        N_TA_OFFSET                 : in  std_logic_vector(15 downto 0);
        RX_WINDOW_UPDATE_EN         : in  std_logic_vector(MAX_RU_ELEMENT-1 downto 0);
        REF_10msec                  : in  std_logic;                            -- Longer than 1-clocks@245.76-MHz
        REF_SFN                     : in  std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------        
        CAPTURE_PERIOD              : in std_logic_array8(7 downto 0);
                                      
        T2A_MAX_DL_CP_RX            : in std_logic_array5_array22(7 downto 0);
        T2A_MIN_DL_CP_RX            : in std_logic_array5_array22(7 downto 0);
        T2A_MAX_DL_UP_RX            : in std_logic_array5_array22(7 downto 0);
        T2A_MIN_DL_UP_RX            : in std_logic_array5_array22(7 downto 0);
        
        CNT_RX_CORRUPT                                          : out std_logic_array64(7 downto 0); 
        CNT_RX_SECTIONID                                        : out std_logic_array64(7 downto 0); 
        CNT_RX_PCID_eCPRIVERSION_PAYLOADVERSION                 : out std_logic_array64(7 downto 0); 
        CNT_RX_PCID                                             : out std_logic_array64(7 downto 0); 
        CNT_RX_eCPRIVERSION                                     : out std_logic_array64(7 downto 0); 
        CNT_RX_PAYLOADVERSION                                   : out std_logic_array64(7 downto 0)   
                        
    );
    end component;

    signal cnt_rx_corrupt                                   : std_logic_array64(7 downto 0);
    signal cnt_rx_corrupt_sectionid                         : std_logic_array64(7 downto 0);
    signal cnt_rx_corrupt_ecpriversion_payloadversion_pcid  : std_logic_array64(7 downto 0);
    signal cnt_rx_corrupt_ecpriversion                      : std_logic_array64(7 downto 0);
    signal cnt_rx_corrupt_pcid                              : std_logic_array64(7 downto 0);
    signal cnt_rx_corrupt_payloadversion                    : std_logic_array64(7 downto 0);
    

    signal packet_is_cp_dl          : std_logic_vector(MAX_RU_ELEMENT-1 downto 0);
    signal packet_is_cp_ul          : std_logic_vector(MAX_RU_ELEMENT-1 downto 0);
    signal packet_is_up_dl          : std_logic_vector(MAX_RU_ELEMENT-1 downto 0);
    signal packet_is_ndm            : std_logic;
    signal packet_scs               : std_logic_vector(3 downto 0);
    signal packet_frame_id          : std_logic_vector(7 downto 0);
    signal packet_subframe_id       : std_logic_vector(3 downto 0);
    signal packet_slot_id           : std_logic_vector(5 downto 0);
    signal packet_symbol_id         : std_logic_vector(5 downto 0);

    signal oran_rx_c64_valid        : std_logic;
    signal oran_rx_c64_last         : std_logic;
    signal oran_rx_c64_keep         : std_logic_vector(7 downto 0);
    signal oran_rx_c64_data         : std_logic_vector(63 downto 0);
    signal oran_rx_c64_data_index   : std_logic_vector(2 downto 0);
    signal oran_rx_c64_link_map     : std_logic_vector(15 downto 0);
    signal oran_rx_u64_valid        : std_logic;
    signal oran_rx_u64_last         : std_logic;
    signal oran_rx_u64_keep         : std_logic_vector(7 downto 0);
    signal oran_rx_u64_data         : std_logic_vector(63 downto 0);
    signal oran_rx_u64_data_index   : std_logic_vector(2 downto 0);
    signal oran_rx_u64_link_map     : std_logic_vector(15 downto 0);

    signal mac_ic_tx_ready          : std_logic_vector(NUM_PORT_TX-1 downto 0);
    signal mac_ic_tx_valid          : std_logic_vector(NUM_PORT_TX-1 downto 0);
    signal mac_ic_tx_last           : std_logic_vector(NUM_PORT_TX-1 downto 0);
    signal mac_ic_tx_keep           : std_logic_array8(NUM_PORT_TX-1 downto 0);
    signal mac_ic_tx_data           : std_logic_array64(NUM_PORT_TX-1 downto 0);

    component ORAN_RX is
    generic (
        LINK_MAP_MASK               : std_logic_vector(15 downto 0)
    );
    port (
        RST                         : in  std_logic;

        CLK_MAC                     : in  std_logic;
        CLK_BUS                     : in  std_logic;

        DL_COMP_MODE                : in  std_logic_array64(7 downto 0);
        DL_IQ_WIDTH                 : in  std_logic_array64_array4(7 downto 0);
        DL_COMP_METHOD              : in  std_logic_array64_array4(7 downto 0);
        DL_PRB_PER_SYMBOL           : in  std_logic_array64_array10(7 downto 0);
        DL_COMP_EXP_OFFSET          : in  std_logic_array64_array5(7 downto 0);

        USAGE_RX_CP_BUFFER          : out std_logic_vector(31 downto 0);
        USAGE_RX_UP_BUFFER          : out std_logic_vector(31 downto 0);

        CNT_RX_CP                   : out std_logic_vector(31 downto 0);
        CNT_RX_UP                   : out std_logic_vector(31 downto 0);
        CNT_RX_CP_LOST              : out std_logic_vector(31 downto 0);
        CNT_RX_UP_LOST              : out std_logic_vector(31 downto 0);

        DET_DL_CP0_FAULT_ID_31      : out std_logic_vector(15 downto 0);
        DET_DL_CP1_FAULT_ID_31      : out std_logic_vector(15 downto 0);
        DET_DL_CP2_FAULT_ID_31      : out std_logic_vector(15 downto 0);
        DET_DL_CP3_FAULT_ID_31      : out std_logic_vector(15 downto 0);
        DET_DL_CP4_FAULT_ID_31      : out std_logic_vector(15 downto 0);
        DET_DL_CP5_FAULT_ID_31      : out std_logic_vector(15 downto 0);
        DET_DL_CP6_FAULT_ID_31      : out std_logic_vector(15 downto 0);
        DET_DL_CP7_FAULT_ID_31      : out std_logic_vector(15 downto 0);
        DET_UL_CP0_FAULT_ID_31      : out std_logic_vector(15 downto 0);
        DET_UL_CP1_FAULT_ID_31      : out std_logic_vector(15 downto 0);
        DET_UL_CP2_FAULT_ID_31      : out std_logic_vector(15 downto 0);
        DET_UL_CP3_FAULT_ID_31      : out std_logic_vector(15 downto 0);
        DET_UL_CP4_FAULT_ID_31      : out std_logic_vector(15 downto 0);
        DET_UL_CP5_FAULT_ID_31      : out std_logic_vector(15 downto 0);
        DET_UL_CP6_FAULT_ID_31      : out std_logic_vector(15 downto 0);
        DET_UL_CP7_FAULT_ID_31      : out std_logic_vector(15 downto 0);

        ORAN_RX_C64_VALID           : in  std_logic;
        ORAN_RX_C64_LAST            : in  std_logic;
        ORAN_RX_C64_KEEP            : in  std_logic_vector(7 downto 0);
        ORAN_RX_C64_DATA            : in  std_logic_vector(63 downto 0);
        ORAN_RX_C64_DATA_INDEX      : in  std_logic_vector(2 downto 0);
        ORAN_RX_C64_LINK_MAP        : in  std_logic_vector(15 downto 0);

        ORAN_RX_U64_VALID           : in  std_logic;
        ORAN_RX_U64_LAST            : in  std_logic;
        ORAN_RX_U64_KEEP            : in  std_logic_vector(7 downto 0);
        ORAN_RX_U64_DATA            : in  std_logic_vector(63 downto 0);
        ORAN_RX_U64_DATA_INDEX      : in  std_logic_vector(2 downto 0);
        ORAN_RX_U64_LINK_MAP        : in  std_logic_vector(15 downto 0);

        xL_CP_VALID                 : out std_logic;
        xL_CP_LAST                  : out std_logic;
        xL_CP_DATA                  : out std_logic_vector(31 downto 0);
        xL_CP_DATA_INDEX            : out std_logic_vector(2 downto 0);
        xL_CP_LINK_INDEX            : out std_logic_vector(3 downto 0);

        DL_RB_eAxC_ID               : out std_logic_vector(15 downto 0);
        DL_RB_SEQUENCE_ID           : out std_logic_vector(15 downto 0);
        DL_RB_CHANNEL_ID            : out std_logic_vector(3 downto 0);
        DL_RB_FRAME_ID              : out std_logic_vector(7 downto 0);
        DL_RB_SUBFRAME_ID           : out std_logic_vector(3 downto 0);
        DL_RB_SLOT_ID               : out std_logic_vector(5 downto 0);
        DL_RB_SYMBOL_ID             : out std_logic_vector(5 downto 0);
        DL_RB_SECTION_ID            : out std_logic_vector(11 downto 0);
        DL_RB_NUMBER                : out std_logic_vector(9 downto 0);
        DL_RE_NUMBER                : out std_logic_vector(11 downto 0);

        DL_RB_VALID                 : out std_logic;
        DL_RB_START                 : out std_logic;
        DL_RB_TICK                  : out std_logic;
        DL_RB_LAST                  : out std_logic;
        DL_RB_DATA_I                : out std_logic_vector(15 downto 0);
        DL_RB_DATA_Q                : out std_logic_vector(15 downto 0)
    );
    end component;

    signal xl_cp_valid              : std_logic_vector(7 downto 0);
    signal xl_cp_last               : std_logic_vector(7 downto 0);
    signal xl_cp_data               : std_logic_array32(7 downto 0);
    signal xl_cp_data_index         : std_logic_array3(7 downto 0);
    signal xl_cp_link_index         : std_logic_array4(7 downto 0);
    signal xl_cp_link_index_mask    : std_logic_array4(7 downto 0);
--    signal dl_rb_eaxc_id            : std_logic_array16(7 downto 0);
--    signal dl_rb_sequence_id        : std_logic_array16(7 downto 0);
    signal dl_rb_channel_id         : std_logic_array4(7 downto 0);
    signal dl_rb_frame_id           : std_logic_array8(7 downto 0);
    signal dl_rb_subframe_id        : std_logic_array4(7 downto 0);
    signal dl_rb_slot_id            : std_logic_array6(7 downto 0);
    signal dl_rb_symbol_id          : std_logic_array6(7 downto 0);
    signal dl_rb_section_id         : std_logic_array12(7 downto 0);
--    signal dl_rb_number             : std_logic_array10(7 downto 0);
    signal dl_re_number             : std_logic_array12(7 downto 0);
    signal dl_rb_valid              : std_logic_vector(7 downto 0);
    signal dl_rb_start              : std_logic_vector(7 downto 0);
    signal dl_rb_tick               : std_logic_vector(7 downto 0);
    signal dl_rb_last               : std_logic_vector(7 downto 0);
    signal dl_rb_data_i             : std_logic_array16(7 downto 0);
    signal dl_rb_data_q             : std_logic_array16(7 downto 0);

    component CU_PE_TOP is
    generic (
        VENDOR                      : string  := "XILINX"; -- FSU10: XILINX, FSU20: INTEL
        Category                    : string  :=      "A";
        eCPRI_HDR                   : boolean :=     TRUE; -- FSU10: FALSE, FSU20: TRUE
        iFFT_k0_SHIFT               : boolean :=     TRUE;
        iFFT_ZERO_PADDING           : boolean :=     TRUE;
        SCS                         : natural :=       15;
        SECTION_NUM                 : natural :=      128;
        Max_RB_NUM                  : natural :=      106;
        iFFT_WIDTH                  : natural :=       11;
        SYMBOL_NUM                  : natural :=        7;
        CH_NUM                      : natural :=        8; -- Layer/Path @ module
        DL_LAYER_NUM                : natural :=        8;
        UL_RX_NUM                   : natural :=        8;
        CELL_NUM_eMTC               : natural :=        1;
        PATH_NUM                    : natural :=        4; -- Layer/Path @ cell
        Opt_BF_Support              : natural :=        0  -- Mandatory: 0, Optional: 1
    );
    port (
        CLK                         : in  std_logic;

        nRE                         : in  std_logic_vector(  12-1 downto 0);
        nFFT                        : in  std_logic_vector(   2-1 downto 0);

        FRAME_SYNC                  : in  std_logic;

        DL_SYNC_ADVANCE             : in  std_logic_vector(22  -1 downto 0);
        UL_SYNC_RETARD              : in  std_logic_vector(22  -1 downto 0);

        BFN_NUM_IN                  : in  std_logic_vector(11 downto 0);
        BFN_NUM_OUT                 : out std_logic_vector(11 downto 0);

        UP_ONLY_DL_MODE             : in  std_logic;

        ECPRI_RX_C_CH_IDX           : in  std_logic_vector( 3 downto 0);
        ECPRI_RX_C_VALID            : in  std_logic;
        ECPRI_RX_C_LAST             : in  std_logic;
        ECPRI_RX_C_KEEP             : in  std_logic_vector( 3 downto 0);
        ECPRI_RX_C_DATA             : in  std_logic_vector(31 downto 0);

        RB_CH_IDX                   : in  std_logic_vector( 3 downto 0);
        RB_FRAME_ID                 : in  std_logic_vector( 7 downto 0);
        RB_SUBFRAME_ID              : in  std_logic_vector( 3 downto 0);
        RB_SLOT_ID                  : in  std_logic_vector( 5 downto 0);
        RB_SYMBOL_ID                : in  std_logic_vector( 5 downto 0);
        RB_SECTION_ID               : in  std_logic_vector(11 downto 0);
        RE_NUMBER                   : in  std_logic_vector(11 downto 0);

        RB_VALID                    : in  std_logic;
        RB_START                    : in  std_logic;
        RB_LAST                     : in  std_logic;
        RB_TICK                     : in  std_logic;
        RB_DATA_I                   : in  std_logic_vector(15 downto 0);
        RB_DATA_Q                   : in  std_logic_vector(15 downto 0);

        SYSTEM_MODE                 : in  std_logic;
        K0                          : in  std_logic_vector(11 downto 0);
        DL_FRAME_SYNC               : out std_logic;
        DL_FRAME_INDEX              : out std_logic_vector( 7 downto 0);
        DL_FRAME_STRUCTURE          : out std_logic_vector( 7 downto 0);
        DL_MuSu_nLayer              : out std_logic_vector( 4 downto 0);
        DL_VALID                    : out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);
        DL_RE_MASK                  : out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);
        DL_BEAMID                   : out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*15 - 1 downto 0);                        
        DL_DATA                     : out std_logic_vector(CH_NUM*32 - 1 downto 0);

        UL_FRAME_SYNC               : out std_logic;
        UL_FILTER_INDEX             : out std_logic_vector( 4*CH_NUM-1 downto 0);
        UL_TIME_OFFSET              : out std_logic_vector(16*CH_NUM-1 downto 0);
        UL_FRAME_STRUCTURE          : out std_logic_vector( 8*CH_NUM-1 downto 0);
        UL_CPLENGTH                 : out std_logic_vector(16*CH_NUM-1 downto 0);
        UL_FREQ_OFFSET              : out std_logic_vector(24*CH_NUM-1 downto 0);
        UL_START_PRBC               : out std_logic_vector(10*CH_NUM-1 downto 0);
        UL_NUM_PRBC                 : out std_logic_vector( 8*CH_NUM-1 downto 0);
        UL_NUM_PSYMBOL              : out std_logic_vector( 4*CH_NUM-1 downto 0);
        UL_NUM_RO                   : out std_logic_vector( 3*CH_NUM-1 downto 0);

--        UL_eMTC_FILTER_INDEX        : out std_logic_vector( 4*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_TIME_OFFSET         : out std_logic_vector(16*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_FRAME_STRUCTURE     : out std_logic_vector( 8*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_CPLENGTH            : out std_logic_vector(16*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_FREQ_OFFSET         : out std_logic_vector(24*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_START_PRBC          : out std_logic_vector(10*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_NUM_PRBC            : out std_logic_vector( 8*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_NUM_PSYMBOL         : out std_logic_vector( 4*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_NUM_RO              : out std_logic_vector( 3*CELL_NUM_eMTC*PATH_NUM-1 downto 0);

        SYMBOL_SYNC                 : out std_logic;
        SYMBOL_INDEX                : out std_logic_vector(3 downto 0);
        TDD_DL_EN                   : out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);
        TDD_UL_EN                   : out std_logic_vector((Opt_BF_Support*(UL_RX_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);

        BLANKINGPATTERNID_VALID     : out std_logic;
        BLANKINGPATTERNID           : out std_logic_vector(7 downto 0)
    );
    end component;

    signal dl_sync_advance          : std_logic_array22(15 downto 0);
    signal ul_sync_retard           : std_logic_array22(15 downto 0);

    signal tdd_sym_sync             : std_logic_vector(15 downto 0);
    signal tdd_sym_index            : std_logic_array4(15 downto 0);
    signal tdd_dl_enable            : std_logic_array4(15 downto 0);
    signal tdd_ul_enable            : std_logic_array4(15 downto 0);

    signal dlfe_system_mode         : std_logic_vector(15 downto 0);
    signal dlfe_k0                  : std_logic_array12(15 downto 0);
    signal dlfe_nRE                 : std_logic_array12(15 downto 0);
    signal dlfe_nFFT                : std_logic_array2(15 downto 0);
    signal dlfe_bfn_num_out         : std_logic_array12(15 downto 0);
    signal dlfe_frame_sync          : std_logic_vector(15 downto 0);      -- Scope Candidate
    signal dlfe_frame_index         : std_logic_array8(15 downto 0);      -- Scope Candidate
    signal dlfe_subframe_index      : std_logic_array4(15 downto 0);
    signal dlfe_slot_index          : std_logic_array6(15 downto 0);
    signal dlfe_symbol_sync         : std_logic_vector(15 downto 0);
    signal dlfe_symbol_index        : std_logic_array4(15 downto 0);
    signal dlfe_valid               : std_logic_array4(15 downto 0);
    signal dlfe_frame_structure     : std_logic_array8(15 downto 0);
    signal dlfe_re_mask             : std_logic_array4(15 downto 0);
    signal dlfe_MuSu_nLayer         : std_logic_array5(15 downto 0);
    signal dlfe_beamId              : std_logic_array60(15 downto 0);
    signal dlfe_data                : std_logic_array128(15 downto 0);

    signal rafe_frame_sync          : std_logic_vector(15 downto 0);
    signal rafe_slot_sync           : std_logic_vector(15 downto 0);
    signal rafe_subframe_index      : std_logic_array4(15 downto 0);
    signal rafe_slot_index          : std_logic_array6(15 downto 0);
    signal rafe_filter_index        : std_logic_array16(15 downto 0);
    signal rafe_time_offset         : std_logic_array64(15 downto 0);
    signal rafe_frame_structure     : std_logic_array32(15 downto 0);
    signal rafe_cplength            : std_logic_array64(15 downto 0);
    signal rafe_freq_offset         : std_logic_array96(15 downto 0);
    signal rafe_start_prbc          : std_logic_array40(15 downto 0);
    signal rafe_num_prbc            : std_logic_array32(15 downto 0);
    signal rafe_num_psymbol         : std_logic_array16(15 downto 0);
    signal rafe_num_ro              : std_logic_array12(15 downto 0);

    signal blankingpatternid_valid   : std_logic_vector(15 downto 0);
    signal blankingpatternid         : std_logic_array8(15 downto 0);

    component ULFE_CONVERSION is
    port (
        CLK                         : in  std_logic;

        ULFE_RB_FRAME_ID_IN         : in  std_logic_vector(7 downto 0);
        ULFE_RB_SUBFRAME_ID_IN      : in  std_logic_vector(3 downto 0);
        ULFE_RB_SLOT_ID_IN          : in  std_logic_vector(5 downto 0);
        ULFE_RB_SYMBOL_ID_IN        : in  std_logic_vector(5 downto 0);
        ULFE_RB_START_RE_IN         : in  std_logic_vector(4*16-1 downto 0);

        ULFE_RB_VALID_IN            : in  std_logic_vector(4*1-1 downto 0);
        ULFE_RB_START_IN            : in  std_logic_vector(4*1-1 downto 0);
        ULFE_RB_LAST_IN             : in  std_logic_vector(4*1-1 downto 0);
        ULFE_RB_DATA_IN             : in  std_logic_vector(4*32-1 downto 0);

        ULFE_RB_FRAME_ID_OUT        : out std_logic_vector(7 downto 0);
        ULFE_RB_SUBFRAME_ID_OUT     : out std_logic_vector(3 downto 0);
        ULFE_RB_SLOT_ID_OUT         : out std_logic_vector(5 downto 0);
        ULFE_RB_SYMBOL_ID_OUT       : out std_logic_vector(5 downto 0);

        ULFE_RB_VALID_OUT           : out std_logic_vector(7 downto 0);
        ULFE_RB_START_OUT           : out std_logic_vector(7 downto 0);
        ULFE_RB_LAST_OUT            : out std_logic_vector(7 downto 0);
        ULFE_RB_DATA_I_OUT          : out std_logic_array16(7 downto 0);
        ULFE_RB_DATA_Q_OUT          : out std_logic_array16(7 downto 0)
    );
    end component;

    signal ulfe_rb_frame_id         : std_logic_array8(7 downto 0);
    signal ulfe_rb_subframe_id      : std_logic_array4(7 downto 0);
    signal ulfe_rb_slot_id          : std_logic_array6(7 downto 0);
    signal ulfe_rb_symbol_id        : std_logic_array6(7 downto 0);
    signal ulfe_rb_valid            : std_logic_array8(7 downto 0);
    signal ulfe_rb_start            : std_logic_array8(7 downto 0);
    signal ulfe_rb_last             : std_logic_array8(7 downto 0);
    signal ulfe_rb_data_i           : std_logic_array8_array16(7 downto 0);
    signal ulfe_rb_data_q           : std_logic_array8_array16(7 downto 0);

    component RAFE_CONVERSION is
    port (
        CLK                         : in  std_logic;

        RAFE_RB_FRAME_ID_IN         : in  std_logic_vector(7 downto 0);
        RAFE_RB_SUBFRAME_ID_IN      : in  std_logic_vector(3 downto 0);
        RAFE_RB_SLOT_ID_IN          : in  std_logic_vector(5 downto 0);
        RAFE_RB_SYMBOL_ID_IN        : in  std_logic_vector(5 downto 0);

        RAFE_RB_VALID_IN            : in  std_logic_vector(4*1-1 downto 0);
        RAFE_RB_START_IN            : in  std_logic_vector(4*1-1 downto 0);
        RAFE_RB_LAST_IN             : in  std_logic_vector(4*1-1 downto 0);
        RAFE_RB_DATA_IN             : in  std_logic_vector(4*32-1 downto 0);

        RAFE_RB_FRAME_ID_OUT        : out std_logic_vector(7 downto 0);
        RAFE_RB_SUBFRAME_ID_OUT     : out std_logic_vector(3 downto 0);
        RAFE_RB_SLOT_ID_OUT         : out std_logic_vector(5 downto 0);
        RAFE_RB_SYMBOL_ID_OUT       : out std_logic_vector(5 downto 0);
        RAFE_RB_ANT_ID_OUT          : out std_logic_vector(2 downto 0);

        RAFE_RB_VALID_OUT           : out std_logic;
        RAFE_RB_START_OUT           : out std_logic;
        RAFE_RB_LAST_OUT            : out std_logic;
        RAFE_RB_DATA_I_OUT          : out std_logic_vector(15 downto 0);
        RAFE_RB_DATA_Q_OUT          : out std_logic_vector(15 downto 0)
    );
    end component;

    signal rafe0_rb_frame_id        : std_logic_array8(7 downto 0);
    signal rafe0_rb_subframe_id     : std_logic_array4(7 downto 0);
    signal rafe0_rb_slot_id         : std_logic_array6(7 downto 0);
    signal rafe0_rb_symbol_id       : std_logic_array6(7 downto 0);
    signal rafe0_rb_ant_id          : std_logic_array3(7 downto 0);
    signal rafe0_rb_valid           : std_logic_vector(7 downto 0);
    signal rafe0_rb_start           : std_logic_vector(7 downto 0);
    signal rafe0_rb_last            : std_logic_vector(7 downto 0);
    signal rafe0_rb_data_i          : std_logic_array16(7 downto 0);
    signal rafe0_rb_data_q          : std_logic_array16(7 downto 0);

    component UP_GEN is
    generic (
        OFFSET                      : natural := 4;
        MAX_CH                      : natural := 4;
        MAX_NUM_PORTC               : natural := 4
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        IGNORE_FRAME_ID             : in  std_logic;
        IGNORE_FRAME_ID_PUxCH_RX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_TX   : out std_logic_vector(7 downto 0);

        UL_PARAM_ID_EN              : in  std_logic_array64(7 downto 0);
        UL_PARAM_ID                 : in  std_logic_array64_array16(7 downto 0);
        UL_PE_INDEX                 : in  std_logic_array64_array8(7 downto 0);

        UL_COMP_MODE                : in  std_logic_array64(7 downto 0);
        UL_IQ_WIDTH                 : in  std_logic_array64_array4(7 downto 0);
        UL_COMP_METHOD              : in  std_logic_array64_array4(7 downto 0);
        UL_PRB_PER_SYMBOL           : in  std_logic_array64_array10(7 downto 0);
        UL_PRB_PER_MTU              : in  std_logic_array64_array10(7 downto 0);

        FREQ_OFFSET_FOR_PRACH0      : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_PRACH1      : in  std_logic_array24(7 downto 0);

        STATUS_TX0_CQ_FSM           : out std_logic_vector(7 downto 0);
        CNT_TX0_CQ_FSM_BUSY         : out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_CONV_FULL        : out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL0       : out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL1       : out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL2       : out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL3       : out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL4       : out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL5       : out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL6       : out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL7       : out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL8       : out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL9       : out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL10      : out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL11      : out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL12      : out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL13      : out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL0       : out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL1       : out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL2       : out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL3       : out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL4       : out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL5       : out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL6       : out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL7       : out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL8       : out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL9       : out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL10      : out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL11      : out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL12      : out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL13      : out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL13    : out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL0        : out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL1        : out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL2        : out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL3        : out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL4        : out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL5        : out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL6        : out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL7        : out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL8        : out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL9        : out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL10       : out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL11       : out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL12       : out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL13       : out std_logic_vector(31 downto 0);

        STATUS_TX1_CQ_FSM           : out std_logic_vector(7 downto 0);
        CNT_TX1_CQ_FSM_BUSY         : out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_CONV_FULL        : out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL0       : out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL1       : out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL2       : out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL3       : out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL4       : out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL5       : out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL6       : out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL7       : out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL8       : out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL9       : out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL10      : out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL11      : out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL12      : out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL13      : out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL0       : out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL1       : out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL2       : out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL3       : out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL4       : out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL5       : out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL6       : out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL7       : out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL8       : out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL9       : out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL10      : out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL11      : out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL12      : out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL13      : out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL13    : out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL0        : out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL1        : out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL2        : out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL3        : out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL4        : out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL5        : out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL6        : out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL7        : out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL8        : out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL9        : out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL10       : out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL11       : out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL12       : out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL13       : out std_logic_vector(31 downto 0);

        STATUS_TX2_CQ_FSM           : out std_logic_vector(7 downto 0);
        CNT_TX2_CQ_FSM_BUSY         : out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_CONV_FULL        : out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL0       : out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL1       : out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL2       : out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL3       : out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL4       : out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL5       : out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL6       : out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL7       : out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL8       : out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL9       : out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL10      : out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL11      : out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL12      : out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL13      : out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL0       : out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL1       : out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL2       : out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL3       : out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL4       : out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL5       : out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL6       : out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL7       : out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL8       : out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL9       : out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL10      : out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL11      : out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL12      : out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL13      : out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL13    : out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL0        : out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL1        : out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL2        : out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL3        : out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL4        : out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL5        : out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL6        : out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL7        : out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL8        : out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL9        : out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL10       : out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL11       : out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL12       : out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL13       : out std_logic_vector(31 downto 0);

        C_PLANE_VALID               : in  std_logic;
        C_PLANE_LAST                : in  std_logic;
        C_PLANE_DATA                : in  std_logic_vector(31 downto 0);
        C_PLANE_DATA_INDEX          : in  std_logic_vector(2 downto 0);
        C_PLANE_LINK_INDEX          : in  std_logic_vector(3 downto 0);

        ULFE_FRAME_ID               : in  std_logic_vector(7 downto 0);
        ULFE_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        ULFE_SLOT_ID                : in  std_logic_vector(5 downto 0);
        ULFE_SYMBOL_ID              : in  std_logic_vector(5 downto 0);

        ULFE_VALID                  : in  std_logic_vector(7 downto 0);
        ULFE_START                  : in  std_logic_vector(7 downto 0);
        ULFE_LAST                   : in  std_logic_vector(7 downto 0);
        ULFE_DATA_I                 : in  std_logic_array16(7 downto 0);
        ULFE_DATA_Q                 : in  std_logic_array16(7 downto 0);

        RAFE0_FRAME_ID              : in  std_logic_vector(7 downto 0);
        RAFE0_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        RAFE0_SLOT_ID               : in  std_logic_vector(5 downto 0);
        RAFE0_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        RAFE0_ANT_ID                : in  std_logic_vector(2 downto 0);

        RAFE0_VALID                 : in  std_logic;
        RAFE0_START                 : in  std_logic;
        RAFE0_LAST                  : in  std_logic;
        RAFE0_DATA_I                : in  std_logic_vector(15 downto 0);
        RAFE0_DATA_Q                : in  std_logic_vector(15 downto 0);

        RAFE1_FRAME_ID              : in  std_logic_vector(7 downto 0);
        RAFE1_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        RAFE1_SLOT_ID               : in  std_logic_vector(5 downto 0);
        RAFE1_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        RAFE1_ANT_ID                : in  std_logic_vector(2 downto 0);

        RAFE1_VALID                 : in  std_logic;
        RAFE1_START                 : in  std_logic;
        RAFE1_LAST                  : in  std_logic;
        RAFE1_DATA_I                : in  std_logic_vector(15 downto 0);
        RAFE1_DATA_Q                : in  std_logic_vector(15 downto 0);

        TX0_RB_INIT                 : out std_logic;
        TX0_RB_PATH                 : out std_logic_vector(2 downto 0);
        TX0_RB_PE_INDEX             : out std_logic_vector(2 downto 0);
        TX0_RB_eAxC_ID              : out std_logic_vector(15 downto 0);
        TX0_RB_SEQUENCE_ID          : out std_logic_vector(15 downto 0);
        TX0_RB_HEADER_APP           : out std_logic_vector(31 downto 0);
        TX0_RB_HEADER_APP_ACK       : in  std_logic;
        TX0_RB_HEADER_SEC           : out std_logic_vector(31 downto 0);
        TX0_RB_HEADER_SEC_ACK       : in  std_logic;
        TX0_RB_COMP_HDR             : out std_logic_vector(8 downto 0);
        TX0_RB_VALID                : out std_logic;
        TX0_RB_TICK                 : out std_logic;
        TX0_RB_DATA_I               : out std_logic_vector(15 downto 0);
        TX0_RB_DATA_Q               : out std_logic_vector(15 downto 0);
        TX0_RB_USER                 : out std_logic_vector(15 downto 0);

        TX1_RB_INIT                 : out std_logic;
        TX1_RB_PATH                 : out std_logic_vector(2 downto 0);
        TX1_RB_PE_INDEX             : out std_logic_vector(2 downto 0);
        TX1_RB_eAxC_ID              : out std_logic_vector(15 downto 0);
        TX1_RB_SEQUENCE_ID          : out std_logic_vector(15 downto 0);
        TX1_RB_HEADER_APP           : out std_logic_vector(31 downto 0);
        TX1_RB_HEADER_APP_ACK       : in  std_logic;
        TX1_RB_HEADER_SEC           : out std_logic_vector(31 downto 0);
        TX1_RB_HEADER_SEC_ACK       : in  std_logic;
        TX1_RB_COMP_HDR             : out std_logic_vector(8 downto 0);
        TX1_RB_VALID                : out std_logic;
        TX1_RB_TICK                 : out std_logic;
        TX1_RB_DATA_I               : out std_logic_vector(15 downto 0);
        TX1_RB_DATA_Q               : out std_logic_vector(15 downto 0);
        TX1_RB_USER                 : out std_logic_vector(15 downto 0);

        TX2_RB_INIT                 : out std_logic;
        TX2_RB_PATH                 : out std_logic_vector(2 downto 0);
        TX2_RB_PE_INDEX             : out std_logic_vector(2 downto 0);
        TX2_RB_eAxC_ID              : out std_logic_vector(15 downto 0);
        TX2_RB_SEQUENCE_ID          : out std_logic_vector(15 downto 0);
        TX2_RB_HEADER_APP           : out std_logic_vector(31 downto 0);
        TX2_RB_HEADER_APP_ACK       : in  std_logic;
        TX2_RB_HEADER_SEC           : out std_logic_vector(31 downto 0);
        TX2_RB_HEADER_SEC_ACK       : in  std_logic;
        TX2_RB_COMP_HDR             : out std_logic_vector(8 downto 0);
        TX2_RB_VALID                : out std_logic;
        TX2_RB_TICK                 : out std_logic;
        TX2_RB_DATA_I               : out std_logic_vector(15 downto 0);
        TX2_RB_DATA_Q               : out std_logic_vector(15 downto 0);
        TX2_RB_USER                 : out std_logic_vector(15 downto 0)

    );
    end component;

    signal freq_offset_for_prach0   : std_logic_array8_array24(7 downto 0);
    signal freq_offset_for_prach1   : std_logic_array8_array24(7 downto 0);

    signal tx0_rb_init              : std_logic_vector(7 downto 0);
    signal tx0_rb_path              : std_logic_array3(7 downto 0);
    signal tx0_rb_pe_index          : std_logic_array3(7 downto 0);
    signal tx0_rb_eaxc_id           : std_logic_array16(7 downto 0);
    signal tx0_rb_sequence_id       : std_logic_array16(7 downto 0);
    signal tx0_rb_header_app        : std_logic_array32(7 downto 0);
    signal tx0_rb_header_app_ack    : std_logic_vector(7 downto 0);
    signal tx0_rb_header_sec        : std_logic_array32(7 downto 0);
    signal tx0_rb_header_sec_ack    : std_logic_vector(7 downto 0);
    signal tx0_rb_comp_hdr          : std_logic_array9(7 downto 0);
    signal tx0_rb_valid             : std_logic_vector(7 downto 0);
    signal tx0_rb_tick              : std_logic_vector(7 downto 0);
    signal tx0_rb_data_i            : std_logic_array16(7 downto 0);
    signal tx0_rb_data_q            : std_logic_array16(7 downto 0);
    signal tx0_rb_user              : std_logic_array16(7 downto 0);

    signal tx1_rb_init              : std_logic_vector(7 downto 0);
    signal tx1_rb_path              : std_logic_array3(7 downto 0);
    signal tx1_rb_pe_index          : std_logic_array3(7 downto 0);
    signal tx1_rb_eaxc_id           : std_logic_array16(7 downto 0);
    signal tx1_rb_sequence_id       : std_logic_array16(7 downto 0);
    signal tx1_rb_header_app        : std_logic_array32(7 downto 0);
    signal tx1_rb_header_app_ack    : std_logic_vector(7 downto 0);
    signal tx1_rb_header_sec        : std_logic_array32(7 downto 0);
    signal tx1_rb_header_sec_ack    : std_logic_vector(7 downto 0);
    signal tx1_rb_comp_hdr          : std_logic_array9(7 downto 0);
    signal tx1_rb_valid             : std_logic_vector(7 downto 0);
    signal tx1_rb_tick              : std_logic_vector(7 downto 0);
    signal tx1_rb_data_i            : std_logic_array16(7 downto 0);
    signal tx1_rb_data_q            : std_logic_array16(7 downto 0);
    signal tx1_rb_user              : std_logic_array16(7 downto 0);

    component ORAN_UP_TX is
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        CLK_UP                      : in  std_logic;

        PARAM_RU_MAC                : in  std_logic_array48(7 downto 0);
        PARAM_PORT_INDEX            : in  std_logic_array3(7 downto 0);
        PARAM_DU_MAC                : in  std_logic_array48(7 downto 0);
        PARAM_VLAN0_EN              : in  std_logic_vector(7 downto 0);
        PARAM_VLAN0_VID             : in  std_logic_array12(7 downto 0);
        PARAM_VLAN1_EN              : in  std_logic_vector(7 downto 0);
        PARAM_VLAN1_VID             : in  std_logic_array12(7 downto 0);

        TX_COMP_EXP_OFFSET          : in  std_logic_array5(7 downto 0);
        TX_COMP_GAIN_OFFSET         : in  std_logic_array11(7 downto 0);
        TX_COMP_SCALE_GAIN_OFFSET   : in  std_logic_array4(7 downto 0);

        USAGE_DATA_BUFFER           : out std_logic_vector(31 downto 0);

        CNT_TX                      : out std_logic_vector(31 downto 0);
        CNT_LOST                    : out std_logic_vector(31 downto 0);

        RB_INIT                     : in  std_logic;
        RB_PATH                     : in  std_logic_vector(2 downto 0);
        RB_PE_INDEX                 : in  std_logic_vector(2 downto 0);
        RB_eAxC_ID                  : in  std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              : in  std_logic_vector(15 downto 0);
        RB_HEADER_APP               : in  std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           : out std_logic;
        RB_HEADER_SEC               : in  std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           : out std_logic;

        RB_COMP_HDR                 : in  std_logic_vector(8 downto 0);

        RB_VALID                    : in  std_logic;
        RB_START                    : in  std_logic;
        RB_TICK                     : in  std_logic;
        RB_LAST                     : in  std_logic;
        RB_DATA_I                   : in  std_logic_vector(15 downto 0);
        RB_DATA_Q                   : in  std_logic_vector(15 downto 0);
        RB_USER                     : in  std_logic_vector(15 downto 0);

        PE_TRANSMITTED              : out std_logic_vector(MAX_RU_ELEMENT-1 downto 0);

        UP64_READY                  : in  std_logic;
        UP64_VALID                  : out std_logic;
        UP64_LAST                   : out std_logic;
        UP64_KEEP                   : out std_logic_vector(7 downto 0);
        UP64_DATA                   : out std_logic_vector(63 downto 0)
    );
    end component;

    signal tx0_pe_transmitted       : logic_array_pe(7 downto 0);
    signal tx1_pe_transmitted       : logic_array_pe(7 downto 0);

    signal tx0_up64_ready           : std_logic_vector(UL_UNIT-1 downto 0);
    signal tx0_up64_valid           : std_logic_vector(UL_UNIT-1 downto 0);
    signal tx0_up64_last            : std_logic_vector(UL_UNIT-1 downto 0);
    signal tx0_up64_keep            : std_logic_array8(UL_UNIT-1 downto 0);
    signal tx0_up64_data            : std_logic_array64(UL_UNIT-1 downto 0);
    signal tx1_up64_ready           : std_logic_vector(UL_UNIT-1 downto 0);
    signal tx1_up64_valid           : std_logic_vector(UL_UNIT-1 downto 0);
    signal tx1_up64_last            : std_logic_vector(UL_UNIT-1 downto 0);
    signal tx1_up64_keep            : std_logic_array8(UL_UNIT-1 downto 0);
    signal tx1_up64_data            : std_logic_array64(UL_UNIT-1 downto 0);

    component ORAN_TX_MUX is
    generic (
        TX_UNIT                     : natural := 6
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        IN0_READY                   : out std_logic;
        IN0_VALID                   : in  std_logic;
        IN0_LAST                    : in  std_logic;
        IN0_KEEP                    : in  std_logic_vector(7 downto 0);
        IN0_DATA                    : in  std_logic_vector(63 downto 0);

        IN1_READY                   : out std_logic;
        IN1_VALID                   : in  std_logic;
        IN1_LAST                    : in  std_logic;
        IN1_KEEP                    : in  std_logic_vector(7 downto 0);
        IN1_DATA                    : in  std_logic_vector(63 downto 0);

        IN2_READY                   : out std_logic;
        IN2_VALID                   : in  std_logic;
        IN2_LAST                    : in  std_logic;
        IN2_KEEP                    : in  std_logic_vector(7 downto 0);
        IN2_DATA                    : in  std_logic_vector(63 downto 0);

        IN3_READY                   : out std_logic;
        IN3_VALID                   : in  std_logic;
        IN3_LAST                    : in  std_logic;
        IN3_KEEP                    : in  std_logic_vector(7 downto 0);
        IN3_DATA                    : in  std_logic_vector(63 downto 0);

        IN4_READY                   : out std_logic;
        IN4_VALID                   : in  std_logic;
        IN4_LAST                    : in  std_logic;
        IN4_KEEP                    : in  std_logic_vector(7 downto 0);
        IN4_DATA                    : in  std_logic_vector(63 downto 0);

        IN5_READY                   : out std_logic;
        IN5_VALID                   : in  std_logic;
        IN5_LAST                    : in  std_logic;
        IN5_KEEP                    : in  std_logic_vector(7 downto 0);
        IN5_DATA                    : in  std_logic_vector(63 downto 0);

        IN6_READY                   : out std_logic;
        IN6_VALID                   : in  std_logic;
        IN6_LAST                    : in  std_logic;
        IN6_KEEP                    : in  std_logic_vector(7 downto 0);
        IN6_DATA                    : in  std_logic_vector(63 downto 0);

        IN7_READY                   : out std_logic;
        IN7_VALID                   : in  std_logic;
        IN7_LAST                    : in  std_logic;
        IN7_KEEP                    : in  std_logic_vector(7 downto 0);
        IN7_DATA                    : in  std_logic_vector(63 downto 0);

        OUT_READY                   : in  std_logic;
        OUT_VALID                   : out std_logic;
        OUT_LAST                    : out std_logic;
        OUT_KEEP                    : out std_logic_vector(7 downto 0);
        OUT_DATA                    : out std_logic_vector(63 downto 0)
    );
    end component;

    component MEASUREMENT is
    generic (
        NUM_TX                      : natural := 1
    );
    port (
        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK_245p76MHz               : in  std_logic;

        N_TA_OFFSET                 : in  std_logic_vector(15 downto 0);

        REF_10msec                  : in  std_logic;
        REF_SFN                     : in  std_logic_vector(7 downto 0);

        CAPTURE_PERIOD              : in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            : in  std_logic_array22(4 downto 0);
        T2A_MIN_DL_CP_RX            : in  std_logic_array22(4 downto 0);
        T2A_MAX_DL_UP_RX            : in  std_logic_array22(4 downto 0);
        T2A_MIN_DL_UP_RX            : in  std_logic_array22(4 downto 0);
        T2A_MAX_UL_CP_RX            : in  std_logic_array22(4 downto 0);
        T2A_MIN_UL_CP_RX            : in  std_logic_array22(4 downto 0);

        STAT_CNT_CLEAR              : in  std_logic;

        DL_CP_RX_ON_TIME            : out std_logic_array64(4 downto 0);
        DL_CP_RX_EARLY              : out std_logic_array64(4 downto 0);
        DL_CP_RX_LATE               : out std_logic_array64(4 downto 0);
        DL_CP_RX_NDM                : out std_logic_array64(4 downto 0);

        DL_UP_RX_ON_TIME            : out std_logic_array64(4 downto 0);
        DL_UP_RX_EARLY              : out std_logic_array64(4 downto 0);
        DL_UP_RX_LATE               : out std_logic_array64(4 downto 0);
        DL_UP_RX_NDM                : out std_logic_array64(4 downto 0);

        UL_CP_RX_ON_TIME            : out std_logic_array64(4 downto 0);
        UL_CP_RX_EARLY              : out std_logic_array64(4 downto 0);
        UL_CP_RX_LATE               : out std_logic_array64(4 downto 0);
        UL_CP_RX_NDM                : out std_logic_array64(4 downto 0);

        UL_CP_TX_TOTAL              : out std_logic_vector(63 downto 0);
        UL_UP_TX_TOTAL              : out std_logic_vector(63 downto 0);

        RX_PACKET_CLK               : in  std_logic;
        UPDATE_EN_OUT               : out std_logic;

        RX_PACKET_IS_CP_DL          : in  std_logic;
        RX_PACKET_IS_CP_UL          : in  std_logic;
        RX_PACKET_IS_UP_DL          : in  std_logic;
        RX_PACKET_IS_NDM            : in  std_logic;
        RX_PACKET_SCS               : in  std_logic_vector(3 downto 0);
        RX_PACKET_FRAME_ID          : in  std_logic_vector(7 downto 0);
        RX_PACKET_SUBFRAME_ID       : in  std_logic_vector(3 downto 0);
        RX_PACKET_SLOT_ID           : in  std_logic_vector(5 downto 0);
        RX_PACKET_SYMBOL_ID         : in  std_logic_vector(5 downto 0);

        TX_PACKET_CLK               : in  std_logic;

        TX0_PACKET_EXIST            : in  std_logic;
        TX1_PACKET_EXIST            : in  std_logic;
        TX2_PACKET_EXIST            : in  std_logic;
        TX3_PACKET_EXIST            : in  std_logic;
        TX4_PACKET_EXIST            : in  std_logic;
        TX5_PACKET_EXIST            : in  std_logic;
        TX6_PACKET_EXIST            : in  std_logic;
        TX7_PACKET_EXIST            : in  std_logic;
        TX8_PACKET_EXIST            : in  std_logic;
        TX9_PACKET_EXIST            : in  std_logic;
        TX10_PACKET_EXIST           : in  std_logic;
        TX11_PACKET_EXIST           : in  std_logic;
        TX12_PACKET_EXIST           : in  std_logic;
        TX13_PACKET_EXIST           : in  std_logic;
        TX14_PACKET_EXIST           : in  std_logic;
        TX15_PACKET_EXIST           : in  std_logic;
        TX16_PACKET_EXIST           : in  std_logic;
        TX17_PACKET_EXIST           : in  std_logic;
        TX18_PACKET_EXIST           : in  std_logic;
        TX19_PACKET_EXIST           : in  std_logic
    );
    end component;

    signal rx_window_update_en           : std_logic_vector(MAX_RU_ELEMENT-1 downto 0);

    signal dl_cp_rx_on_time         : std_logic_array5_array64(7 downto 0);
    signal dl_cp_rx_early           : std_logic_array5_array64(7 downto 0);
    signal dl_cp_rx_late            : std_logic_array5_array64(7 downto 0);
    signal dl_cp_rx_ndm             : std_logic_array5_array64(7 downto 0);
    signal dl_up_rx_on_time         : std_logic_array5_array64(7 downto 0);
    signal dl_up_rx_early           : std_logic_array5_array64(7 downto 0);
    signal dl_up_rx_late            : std_logic_array5_array64(7 downto 0);
    signal dl_up_rx_ndm             : std_logic_array5_array64(7 downto 0);
    signal ul_cp_rx_on_time         : std_logic_array5_array64(7 downto 0);
    signal ul_cp_rx_early           : std_logic_array5_array64(7 downto 0);
    signal ul_cp_rx_late            : std_logic_array5_array64(7 downto 0);
    signal ul_cp_rx_ndm             : std_logic_array5_array64(7 downto 0);

    component ORAN_MPI is
    generic (
        IMPL_PDxCH                  : boolean := true;
        IMPL_SSB                    : boolean := false;
        IMPL_H_MATRIX               : boolean := false;
        IMPL_PUxCH                  : boolean := true;
        IMPL_PRACH                  : boolean := true;
        IMPL_SRS                    : boolean := false;
        IMPL_RIM_RS                 : boolean := false;
        IMPL_NB_IoT                 : boolean := true;

        MAX_CC_DL                   : natural := 2;
        MAX_CC_UL                   : natural := 1;
        MAX_PDxCH                   : natural := 4;
        MAX_SSB                     : natural := 0;
        MAX_H_MATRIX                : natural := 0;
        MAX_PUxCH                   : natural := 4;
        MAX_PRACH                   : natural := 4;
        MAX_SRS                     : natural := 0;
        MAX_RIM_RS                  : natural := 0;
        MAX_NB_IoT                  : natural := 1;

        MAX_PE                      : natural := 4
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        USER_DEBUG0                 : out std_logic_vector(31 downto 0);
        USER_DEBUG1                 : out std_logic_vector(31 downto 0);
        USER_DEBUG2                 : out std_logic_vector(31 downto 0);
        USER_DEBUG3                 : out std_logic_vector(31 downto 0);

        IGNORE_FRAME_ID_PUxCH_RX    : in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    : in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_RX   : in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_TX   : in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_RX   : in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_TX   : in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_RX   : in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_TX   : in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_RX   : in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_TX   : in  std_logic_array8(7 downto 0);

        DL_UPLANE_ONLY_EN           : out std_logic;

        DL_PARAM_ID_EN              : out std_logic_array64(7 downto 0);
        DL_PARAM_ID                 : out std_logic_array64_array16(7 downto 0);
        DL_PE_INDEX                 : out std_logic_array64_array8(7 downto 0);
        DL_COMP_MODE                : out std_logic_array64(7 downto 0);
        DL_IQ_WIDTH                 : out std_logic_array64_array4(7 downto 0);
        DL_COMP_METHOD              : out std_logic_array64_array4(7 downto 0);
        DL_SCS_CONFIG               : out std_logic_array64_array4(7 downto 0);
        DL_FFT_SIZE                 : out std_logic_array64_array4(7 downto 0);
        DL_PRB_PER_SYMBOL           : out std_logic_array64_array10(7 downto 0);
        DL_COMP_EXP_OFFSET          : out std_logic_array64_array5(7 downto 0);

        UL_PARAM_ID_EN              : out std_logic_array64(7 downto 0);
        UL_PARAM_ID                 : out std_logic_array64_array16(7 downto 0);
        UL_PE_INDEX                 : out std_logic_array64_array8(7 downto 0);
        UL_COMP_MODE                : out std_logic_array64(7 downto 0);
        UL_IQ_WIDTH                 : out std_logic_array64_array4(7 downto 0);
        UL_COMP_METHOD              : out std_logic_array64_array4(7 downto 0);
        UL_SCS_CONFIG               : out std_logic_array64_array4(7 downto 0);
        UL_FFT_SIZE                 : out std_logic_array64_array4(7 downto 0);
        UL_PRB_PER_SYMBOL           : out std_logic_array64_array10(7 downto 0);
        UL_PRB_PER_MTU              : out std_logic_array64_array10(7 downto 0);
        UL_COMP_EXP_OFFSET          : out std_logic_array64_array5(7 downto 0);
        UL_COMP_GAIN_OFFSET         : out std_logic_array64_array11(7 downto 0);
        UL_COMP_SCALE_GAIN_OFFSET   : out std_logic_array64_array4(7 downto 0);

        PARAM_RU_MAC                : out std_logic_array48(7 downto 0);
        PARAM_PORT_INDEX            : out std_logic_array3(7 downto 0);
        PARAM_DU_MAC                : out std_logic_array48(7 downto 0);
        PARAM_VLAN0_EN              : out std_logic_vector(7 downto 0);
        PARAM_VLAN0_VID             : out std_logic_array12(7 downto 0);
        PARAM_VLAN1_EN              : out std_logic_vector(7 downto 0);
        PARAM_VLAN1_VID             : out std_logic_array12(7 downto 0);

        CAPTURE_PERIOD              : out std_logic_array8(7 downto 0);

        T2A_MAX_DL_CP_RX            : out std_logic_array5_array22(7 downto 0);
        T2A_MIN_DL_CP_RX            : out std_logic_array5_array22(7 downto 0);
        T2A_MAX_DL_UP_RX            : out std_logic_array5_array22(7 downto 0);
        T2A_MIN_DL_UP_RX            : out std_logic_array5_array22(7 downto 0);
        T2A_MAX_UL_CP_RX            : out std_logic_array5_array22(7 downto 0);
        T2A_MIN_UL_CP_RX            : out std_logic_array5_array22(7 downto 0);

        STAT_CNT_CLEAR              : out std_logic_vector(7 downto 0);

        CNT_RX_CORRUPT                                          : in std_logic_array64(7 downto 0); 
        CNT_RX_SECTIONID                                        : in std_logic_array64(7 downto 0); 
        CNT_RX_PCID_eCPRIVERSION_PAYLOADVERSION                 : in std_logic_array64(7 downto 0); 
        CNT_RX_PCID                                             : in std_logic_array64(7 downto 0); 
        CNT_RX_eCPRIVERSION                                     : in std_logic_array64(7 downto 0); 
        CNT_RX_PAYLOADVERSION                                   : in std_logic_array64(7 downto 0);  

        DL_CP_SCS0_RX_ON_TIME       : in  std_logic_array64(7 downto 0);
        DL_CP_SCS0_RX_EARLY         : in  std_logic_array64(7 downto 0);
        DL_CP_SCS0_RX_LATE          : in  std_logic_array64(7 downto 0);
        DL_CP_SCS0_RX_NDM           : in  std_logic_array64(7 downto 0);
        DL_CP_SCS1_RX_ON_TIME       : in  std_logic_array64(7 downto 0);
        DL_CP_SCS1_RX_EARLY         : in  std_logic_array64(7 downto 0);
        DL_CP_SCS1_RX_LATE          : in  std_logic_array64(7 downto 0);
        DL_CP_SCS1_RX_NDM           : in  std_logic_array64(7 downto 0);
        DL_CP_SCS2_RX_ON_TIME       : in  std_logic_array64(7 downto 0);
        DL_CP_SCS2_RX_EARLY         : in  std_logic_array64(7 downto 0);
        DL_CP_SCS2_RX_LATE          : in  std_logic_array64(7 downto 0);
        DL_CP_SCS2_RX_NDM           : in  std_logic_array64(7 downto 0);
        DL_CP_SCS3_RX_ON_TIME       : in  std_logic_array64(7 downto 0);
        DL_CP_SCS3_RX_EARLY         : in  std_logic_array64(7 downto 0);
        DL_CP_SCS3_RX_LATE          : in  std_logic_array64(7 downto 0);
        DL_CP_SCS3_RX_NDM           : in  std_logic_array64(7 downto 0);
        DL_CP_SCS4_RX_ON_TIME       : in  std_logic_array64(7 downto 0);
        DL_CP_SCS4_RX_EARLY         : in  std_logic_array64(7 downto 0);
        DL_CP_SCS4_RX_LATE          : in  std_logic_array64(7 downto 0);
        DL_CP_SCS4_RX_NDM           : in  std_logic_array64(7 downto 0);

        DL_UP_SCS0_RX_ON_TIME       : in  std_logic_array64(7 downto 0);
        DL_UP_SCS0_RX_EARLY         : in  std_logic_array64(7 downto 0);
        DL_UP_SCS0_RX_LATE          : in  std_logic_array64(7 downto 0);
        DL_UP_SCS0_RX_NDM           : in  std_logic_array64(7 downto 0);
        DL_UP_SCS1_RX_ON_TIME       : in  std_logic_array64(7 downto 0);
        DL_UP_SCS1_RX_EARLY         : in  std_logic_array64(7 downto 0);
        DL_UP_SCS1_RX_LATE          : in  std_logic_array64(7 downto 0);
        DL_UP_SCS1_RX_NDM           : in  std_logic_array64(7 downto 0);
        DL_UP_SCS2_RX_ON_TIME       : in  std_logic_array64(7 downto 0);
        DL_UP_SCS2_RX_EARLY         : in  std_logic_array64(7 downto 0);
        DL_UP_SCS2_RX_LATE          : in  std_logic_array64(7 downto 0);
        DL_UP_SCS2_RX_NDM           : in  std_logic_array64(7 downto 0);
        DL_UP_SCS3_RX_ON_TIME       : in  std_logic_array64(7 downto 0);
        DL_UP_SCS3_RX_EARLY         : in  std_logic_array64(7 downto 0);
        DL_UP_SCS3_RX_LATE          : in  std_logic_array64(7 downto 0);
        DL_UP_SCS3_RX_NDM           : in  std_logic_array64(7 downto 0);
        DL_UP_SCS4_RX_ON_TIME       : in  std_logic_array64(7 downto 0);
        DL_UP_SCS4_RX_EARLY         : in  std_logic_array64(7 downto 0);
        DL_UP_SCS4_RX_LATE          : in  std_logic_array64(7 downto 0);
        DL_UP_SCS4_RX_NDM           : in  std_logic_array64(7 downto 0);

        UL_CP_SCS0_RX_ON_TIME       : in  std_logic_array64(7 downto 0);
        UL_CP_SCS0_RX_EARLY         : in  std_logic_array64(7 downto 0);
        UL_CP_SCS0_RX_LATE          : in  std_logic_array64(7 downto 0);
        UL_CP_SCS0_RX_NDM           : in  std_logic_array64(7 downto 0);
        UL_CP_SCS1_RX_ON_TIME       : in  std_logic_array64(7 downto 0);
        UL_CP_SCS1_RX_EARLY         : in  std_logic_array64(7 downto 0);
        UL_CP_SCS1_RX_LATE          : in  std_logic_array64(7 downto 0);
        UL_CP_SCS1_RX_NDM           : in  std_logic_array64(7 downto 0);
        UL_CP_SCS2_RX_ON_TIME       : in  std_logic_array64(7 downto 0);
        UL_CP_SCS2_RX_EARLY         : in  std_logic_array64(7 downto 0);
        UL_CP_SCS2_RX_LATE          : in  std_logic_array64(7 downto 0);
        UL_CP_SCS2_RX_NDM           : in  std_logic_array64(7 downto 0);
        UL_CP_SCS3_RX_ON_TIME       : in  std_logic_array64(7 downto 0);
        UL_CP_SCS3_RX_EARLY         : in  std_logic_array64(7 downto 0);
        UL_CP_SCS3_RX_LATE          : in  std_logic_array64(7 downto 0);
        UL_CP_SCS3_RX_NDM           : in  std_logic_array64(7 downto 0);
        UL_CP_SCS4_RX_ON_TIME       : in  std_logic_array64(7 downto 0);
        UL_CP_SCS4_RX_EARLY         : in  std_logic_array64(7 downto 0);
        UL_CP_SCS4_RX_LATE          : in  std_logic_array64(7 downto 0);
        UL_CP_SCS4_RX_NDM           : in  std_logic_array64(7 downto 0);

        UL_CP_TX_TOTAL              : in  std_logic_array64(7 downto 0);
        UL_UP_TX_TOTAL              : in  std_logic_array64(7 downto 0);

        DSS_PARAM_TEST_PATTERN_EN   : out std_logic;

        I_CC0_COEFF_VLD_CNT         : in  std_logic_vector(31 downto 0);
        I_CC1_COEFF_VLD_CNT         : in  std_logic_vector(31 downto 0);

        I_CC0_COEFF_IDX_MON         : in  std_logic_vector(31 downto 0);
        I_CC1_COEFF_IDX_MON         : in  std_logic_vector(31 downto 0);

        RX_PE_VALID                 : in  std_logic_array32(7 downto 0);
        RX_INVALID_DST_MAC          : in  std_logic_array32(7 downto 0);
        RX_INVALID_SRC_MAC          : in  std_logic_array32(7 downto 0);
        RX_INVALID_VLAN_VID         : in  std_logic_array32(7 downto 0);
        RX_DISCONTINUE              : in  std_logic_array32(7 downto 0);
        RX_BYTE_SIZE                : in  std_logic_array32(7 downto 0);
        RX_BYTE_ALIGN               : in  std_logic_array32(7 downto 0);

        RX_DL_CP_POSITION           : in  std_logic_array64(7 downto 0);
        RX_DL_UP_POSITION           : in  std_logic_array64(7 downto 0);
        RX_UL_CP_POSITION           : in  std_logic_array64(7 downto 0);

        USAGE_RX_CP_BUFFER          : in  std_logic_array32(7 downto 0);
        USAGE_RX_UP_BUFFER          : in  std_logic_array32(7 downto 0);

        CNT_RX_CP                   : in  std_logic_array32(7 downto 0);
        CNT_RX_UP                   : in  std_logic_array32(7 downto 0);
        CNT_RX_CP_LOST              : in  std_logic_array32(7 downto 0);
        CNT_RX_UP_LOST              : in  std_logic_array32(7 downto 0);

        USAGE_TX0_UP_BUFFER         : in  std_logic_array32(7 downto 0);
        USAGE_TX1_UP_BUFFER         : in  std_logic_array32(7 downto 0);
        USAGE_TX2_UP_BUFFER         : in  std_logic_array32(7 downto 0);
        USAGE_TX3_UP_BUFFER         : in  std_logic_array32(7 downto 0);
        USAGE_TX4_UP_BUFFER         : in  std_logic_array32(7 downto 0);

        CNT_TX0                     : in  std_logic_array32(7 downto 0);
        CNT_TX1                     : in  std_logic_array32(7 downto 0);
        CNT_TX2                     : in  std_logic_array32(7 downto 0);
        CNT_TX3                     : in  std_logic_array32(7 downto 0);
        CNT_TX4                     : in  std_logic_array32(7 downto 0);
        CNT_TX0_LOST                : in  std_logic_array32(7 downto 0);
        CNT_TX1_LOST                : in  std_logic_array32(7 downto 0);
        CNT_TX2_LOST                : in  std_logic_array32(7 downto 0);
        CNT_TX3_LOST                : in  std_logic_array32(7 downto 0);
        CNT_TX4_LOST                : in  std_logic_array32(7 downto 0);

        DET_DL_CP0_FAULT_ID_31      : in  std_logic_array16(7 downto 0);
        DET_DL_CP1_FAULT_ID_31      : in  std_logic_array16(7 downto 0);
        DET_DL_CP2_FAULT_ID_31      : in  std_logic_array16(7 downto 0);
        DET_DL_CP3_FAULT_ID_31      : in  std_logic_array16(7 downto 0);
        DET_DL_CP4_FAULT_ID_31      : in  std_logic_array16(7 downto 0);
        DET_DL_CP5_FAULT_ID_31      : in  std_logic_array16(7 downto 0);
        DET_DL_CP6_FAULT_ID_31      : in  std_logic_array16(7 downto 0);
        DET_DL_CP7_FAULT_ID_31      : in  std_logic_array16(7 downto 0);
        DET_UL_CP0_FAULT_ID_31      : in  std_logic_array16(7 downto 0);
        DET_UL_CP1_FAULT_ID_31      : in  std_logic_array16(7 downto 0);
        DET_UL_CP2_FAULT_ID_31      : in  std_logic_array16(7 downto 0);
        DET_UL_CP3_FAULT_ID_31      : in  std_logic_array16(7 downto 0);
        DET_UL_CP4_FAULT_ID_31      : in  std_logic_array16(7 downto 0);
        DET_UL_CP5_FAULT_ID_31      : in  std_logic_array16(7 downto 0);
        DET_UL_CP6_FAULT_ID_31      : in  std_logic_array16(7 downto 0);
        DET_UL_CP7_FAULT_ID_31      : in  std_logic_array16(7 downto 0);

        STATUS_TX0_CQ_FSM           : in  std_logic_array8(7 downto 0);
        CNT_TX0_CQ_FSM_BUSY         : in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_CONV_FULL        : in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL0       : in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL1       : in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL2       : in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL3       : in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL4       : in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL5       : in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL6       : in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL7       : in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL8       : in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL9       : in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL10      : in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL11      : in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL12      : in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL13      : in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL0       : in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL1       : in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL2       : in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL3       : in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL4       : in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL5       : in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL6       : in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL7       : in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL8       : in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL9       : in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL10      : in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL11      : in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL12      : in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL13      : in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL0     : in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL1     : in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL2     : in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL3     : in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL4     : in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL5     : in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL6     : in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL7     : in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL8     : in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL9     : in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL10    : in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL11    : in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL12    : in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL13    : in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL0        : in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL1        : in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL2        : in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL3        : in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL4        : in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL5        : in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL6        : in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL7        : in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL8        : in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL9        : in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL10       : in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL11       : in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL12       : in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL13       : in  std_logic_array32(7 downto 0);

        STATUS_TX1_CQ_FSM           : in  std_logic_array8(7 downto 0);
        CNT_TX1_CQ_FSM_BUSY         : in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_CONV_FULL        : in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL0       : in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL1       : in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL2       : in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL3       : in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL4       : in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL5       : in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL6       : in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL7       : in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL8       : in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL9       : in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL10      : in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL11      : in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL12      : in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL13      : in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL0       : in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL1       : in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL2       : in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL3       : in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL4       : in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL5       : in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL6       : in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL7       : in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL8       : in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL9       : in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL10      : in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL11      : in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL12      : in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL13      : in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL0     : in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL1     : in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL2     : in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL3     : in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL4     : in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL5     : in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL6     : in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL7     : in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL8     : in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL9     : in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL10    : in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL11    : in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL12    : in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL13    : in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL0        : in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL1        : in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL2        : in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL3        : in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL4        : in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL5        : in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL6        : in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL7        : in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL8        : in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL9        : in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL10       : in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL11       : in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL12       : in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL13       : in  std_logic_array32(7 downto 0);

        STATUS_TX2_CQ_FSM           : in  std_logic_array8(7 downto 0);
        CNT_TX2_CQ_FSM_BUSY         : in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_CONV_FULL        : in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL0       : in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL1       : in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL2       : in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL3       : in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL4       : in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL5       : in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL6       : in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL7       : in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL8       : in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL9       : in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL10      : in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL11      : in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL12      : in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL13      : in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL0       : in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL1       : in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL2       : in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL3       : in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL4       : in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL5       : in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL6       : in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL7       : in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL8       : in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL9       : in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL10      : in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL11      : in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL12      : in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL13      : in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL0     : in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL1     : in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL2     : in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL3     : in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL4     : in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL5     : in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL6     : in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL7     : in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL8     : in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL9     : in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL10    : in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL11    : in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL12    : in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL13    : in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL0        : in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL1        : in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL2        : in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL3        : in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL4        : in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL5        : in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL6        : in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL7        : in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL8        : in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL9        : in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL10       : in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL11       : in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL12       : in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL13       : in  std_logic_array32(7 downto 0);

        STATUS_TX3_CQ_FSM           : in  std_logic_array8(7 downto 0);
        CNT_TX3_CQ_FSM_BUSY         : in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_CONV_FULL        : in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL0       : in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL1       : in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL2       : in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL3       : in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL4       : in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL5       : in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL6       : in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL7       : in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL8       : in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL9       : in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL10      : in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL11      : in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL12      : in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL13      : in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL0       : in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL1       : in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL2       : in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL3       : in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL4       : in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL5       : in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL6       : in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL7       : in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL8       : in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL9       : in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL10      : in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL11      : in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL12      : in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL13      : in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL0     : in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL1     : in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL2     : in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL3     : in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL4     : in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL5     : in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL6     : in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL7     : in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL8     : in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL9     : in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL10    : in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL11    : in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL12    : in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL13    : in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL0        : in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL1        : in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL2        : in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL3        : in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL4        : in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL5        : in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL6        : in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL7        : in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL8        : in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL9        : in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL10       : in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL11       : in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL12       : in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL13       : in  std_logic_array32(7 downto 0);

        STATUS_TX4_CQ_FSM           : in  std_logic_array8(7 downto 0);
        CNT_TX4_CQ_FSM_BUSY         : in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_CONV_FULL        : in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL0       : in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL1       : in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL2       : in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL3       : in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL4       : in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL5       : in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL6       : in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL7       : in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL8       : in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL9       : in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL10      : in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL11      : in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL12      : in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL13      : in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL0       : in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL1       : in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL2       : in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL3       : in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL4       : in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL5       : in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL6       : in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL7       : in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL8       : in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL9       : in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL10      : in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL11      : in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL12      : in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL13      : in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL0     : in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL1     : in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL2     : in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL3     : in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL4     : in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL5     : in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL6     : in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL7     : in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL8     : in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL9     : in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL10    : in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL11    : in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL12    : in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL13    : in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL0        : in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL1        : in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL2        : in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL3        : in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL4        : in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL5        : in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL6        : in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL7        : in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL8        : in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL9        : in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL10       : in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL11       : in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL12       : in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL13       : in  std_logic_array32(7 downto 0);

        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             : out std_logic
    );
    end component;

    signal user_debug0              : std_logic_vector(31 downto 0);
    signal user_debug1              : std_logic_vector(31 downto 0);
    signal user_debug2              : std_logic_vector(31 downto 0);
    signal user_debug3              : std_logic_vector(31 downto 0);
    signal ignore_frame_id_puxch_rx : std_logic_array8(7 downto 0);
    signal ignore_frame_id_puxch_tx : std_logic_array8(7 downto 0);
    signal ignore_frame_id_prach0_rx: std_logic_array8(7 downto 0);
    signal ignore_frame_id_prach0_tx: std_logic_array8(7 downto 0);
    signal ignore_frame_id_prach1_rx: std_logic_array8(7 downto 0);
    signal ignore_frame_id_prach1_tx: std_logic_array8(7 downto 0);
    signal dl_uplane_only_en        : std_logic;
    signal dl_param_id_en           : std_logic_array64(7 downto 0);
    signal dl_param_id              : std_logic_array64_array16(7 downto 0);
    signal dl_pe_index              : std_logic_array64_array8(7 downto 0);
    signal dl_comp_mode             : std_logic_array64(7 downto 0);
    signal dl_iq_width              : std_logic_array64_array4(7 downto 0);
    signal dl_comp_method           : std_logic_array64_array4(7 downto 0);
    signal dl_scs_config            : std_logic_array64_array4(7 downto 0);
    signal dl_fft_size              : std_logic_array64_array4(7 downto 0);
    signal dl_prb_per_symbol        : std_logic_array64_array10(7 downto 0);
    signal dl_comp_exp_offset       : std_logic_array64_array5(7 downto 0);
    signal ul_param_id_en           : std_logic_array64(7 downto 0);
    signal ul_param_id              : std_logic_array64_array16(7 downto 0);
    signal ul_pe_index              : std_logic_array64_array8(7 downto 0);
    signal ul_comp_mode             : std_logic_array64(7 downto 0);
    signal ul_iq_width              : std_logic_array64_array4(7 downto 0);
    signal ul_comp_method           : std_logic_array64_array4(7 downto 0);
    signal ul_scs_config            : std_logic_array64_array4(7 downto 0);
    signal ul_fft_size              : std_logic_array64_array4(7 downto 0);
    signal ul_prb_per_symbol        : std_logic_array64_array10(7 downto 0);
    signal ul_prb_per_mtu           : std_logic_array64_array10(7 downto 0);
    signal ul_comp_exp_offset       : std_logic_array64_array5(7 downto 0);
    signal ul_comp_gain_offset      : std_logic_array64_array11(7 downto 0);
    signal ul_comp_scale_gain_offset: std_logic_array64_array4(7 downto 0);
    signal map0_exp_offset          : std_logic_array8_array5(7 downto 0) := (others => (others => (others => '0')));
    signal map1_exp_offset          : std_logic_array8_array5(7 downto 0) := (others => (others => (others => '0')));
    signal map2_exp_offset          : std_logic_array8_array5(7 downto 0) := (others => (others => (others => '0')));
    signal map3_exp_offset          : std_logic_array8_array5(7 downto 0) := (others => (others => (others => '0')));
    signal map0_gain_offset         : std_logic_array8_array11(7 downto 0) := (others => (others => (others => '0')));
    signal map1_gain_offset         : std_logic_array8_array11(7 downto 0) := (others => (others => (others => '0')));
    signal map2_gain_offset         : std_logic_array8_array11(7 downto 0) := (others => (others => (others => '0')));
    signal map3_gain_offset         : std_logic_array8_array11(7 downto 0) := (others => (others => (others => '0')));
    signal map0_scale_gain_offset   : std_logic_array8_array4(7 downto 0) := (others => (others => (others => '0')));
    signal map1_scale_gain_offset   : std_logic_array8_array4(7 downto 0) := (others => (others => (others => '0')));
    signal map2_scale_gain_offset   : std_logic_array8_array4(7 downto 0) := (others => (others => (others => '0')));
    signal map3_scale_gain_offset   : std_logic_array8_array4(7 downto 0) := (others => (others => (others => '0')));
    signal param_ru_mac             : std_logic_array48(7 downto 0);
    signal param_port_index         : std_logic_array3(7 downto 0);
    signal param_du_mac             : std_logic_array48(7 downto 0);
    signal param_vlan0_en           : std_logic_vector(7 downto 0);
    signal param_vlan0_vid          : std_logic_array12(7 downto 0);
    signal param_vlan1_en           : std_logic_vector(7 downto 0);
    signal param_vlan1_vid          : std_logic_array12(7 downto 0);
    signal capture_period           : std_logic_array8(7 downto 0);
    signal t2a_max_dl_cp_rx         : std_logic_array5_array22(7 downto 0);
    signal t2a_min_dl_cp_rx         : std_logic_array5_array22(7 downto 0);
    signal t2a_max_dl_up_rx         : std_logic_array5_array22(7 downto 0);
    signal t2a_min_dl_up_rx         : std_logic_array5_array22(7 downto 0);
    signal t2a_max_ul_cp_rx         : std_logic_array5_array22(7 downto 0);
    signal t2a_min_ul_cp_rx         : std_logic_array5_array22(7 downto 0);
    signal stat_cnt_clear           : std_logic_vector(7 downto 0);
    signal dl_cp_scs0_rx_on_time    : std_logic_array64(7 downto 0);
    signal dl_cp_scs0_rx_early      : std_logic_array64(7 downto 0);
    signal dl_cp_scs0_rx_late       : std_logic_array64(7 downto 0);
    signal dl_cp_scs0_rx_ndm        : std_logic_array64(7 downto 0);
    signal dl_cp_scs1_rx_on_time    : std_logic_array64(7 downto 0);
    signal dl_cp_scs1_rx_early      : std_logic_array64(7 downto 0);
    signal dl_cp_scs1_rx_late       : std_logic_array64(7 downto 0);
    signal dl_cp_scs1_rx_ndm        : std_logic_array64(7 downto 0);
    signal dl_cp_scs2_rx_on_time    : std_logic_array64(7 downto 0);
    signal dl_cp_scs2_rx_early      : std_logic_array64(7 downto 0);
    signal dl_cp_scs2_rx_late       : std_logic_array64(7 downto 0);
    signal dl_cp_scs2_rx_ndm        : std_logic_array64(7 downto 0);
    signal dl_cp_scs3_rx_on_time    : std_logic_array64(7 downto 0);
    signal dl_cp_scs3_rx_early      : std_logic_array64(7 downto 0);
    signal dl_cp_scs3_rx_late       : std_logic_array64(7 downto 0);
    signal dl_cp_scs3_rx_ndm        : std_logic_array64(7 downto 0);
    signal dl_cp_scs4_rx_on_time    : std_logic_array64(7 downto 0);
    signal dl_cp_scs4_rx_early      : std_logic_array64(7 downto 0);
    signal dl_cp_scs4_rx_late       : std_logic_array64(7 downto 0);
    signal dl_cp_scs4_rx_ndm        : std_logic_array64(7 downto 0);
    signal dl_up_scs0_rx_on_time    : std_logic_array64(7 downto 0);
    signal dl_up_scs0_rx_early      : std_logic_array64(7 downto 0);
    signal dl_up_scs0_rx_late       : std_logic_array64(7 downto 0);
    signal dl_up_scs0_rx_ndm        : std_logic_array64(7 downto 0);
    signal dl_up_scs1_rx_on_time    : std_logic_array64(7 downto 0);
    signal dl_up_scs1_rx_early      : std_logic_array64(7 downto 0);
    signal dl_up_scs1_rx_late       : std_logic_array64(7 downto 0);
    signal dl_up_scs1_rx_ndm        : std_logic_array64(7 downto 0);
    signal dl_up_scs2_rx_on_time    : std_logic_array64(7 downto 0);
    signal dl_up_scs2_rx_early      : std_logic_array64(7 downto 0);
    signal dl_up_scs2_rx_late       : std_logic_array64(7 downto 0);
    signal dl_up_scs2_rx_ndm        : std_logic_array64(7 downto 0);
    signal dl_up_scs3_rx_on_time    : std_logic_array64(7 downto 0);
    signal dl_up_scs3_rx_early      : std_logic_array64(7 downto 0);
    signal dl_up_scs3_rx_late       : std_logic_array64(7 downto 0);
    signal dl_up_scs3_rx_ndm        : std_logic_array64(7 downto 0);
    signal dl_up_scs4_rx_on_time    : std_logic_array64(7 downto 0);
    signal dl_up_scs4_rx_early      : std_logic_array64(7 downto 0);
    signal dl_up_scs4_rx_late       : std_logic_array64(7 downto 0);
    signal dl_up_scs4_rx_ndm        : std_logic_array64(7 downto 0);
    signal ul_cp_scs0_rx_on_time    : std_logic_array64(7 downto 0);
    signal ul_cp_scs0_rx_early      : std_logic_array64(7 downto 0);
    signal ul_cp_scs0_rx_late       : std_logic_array64(7 downto 0);
    signal ul_cp_scs0_rx_ndm        : std_logic_array64(7 downto 0);
    signal ul_cp_scs1_rx_on_time    : std_logic_array64(7 downto 0);
    signal ul_cp_scs1_rx_early      : std_logic_array64(7 downto 0);
    signal ul_cp_scs1_rx_late       : std_logic_array64(7 downto 0);
    signal ul_cp_scs1_rx_ndm        : std_logic_array64(7 downto 0);
    signal ul_cp_scs2_rx_on_time    : std_logic_array64(7 downto 0);
    signal ul_cp_scs2_rx_early      : std_logic_array64(7 downto 0);
    signal ul_cp_scs2_rx_late       : std_logic_array64(7 downto 0);
    signal ul_cp_scs2_rx_ndm        : std_logic_array64(7 downto 0);
    signal ul_cp_scs3_rx_on_time    : std_logic_array64(7 downto 0);
    signal ul_cp_scs3_rx_early      : std_logic_array64(7 downto 0);
    signal ul_cp_scs3_rx_late       : std_logic_array64(7 downto 0);
    signal ul_cp_scs3_rx_ndm        : std_logic_array64(7 downto 0);
    signal ul_cp_scs4_rx_on_time    : std_logic_array64(7 downto 0);
    signal ul_cp_scs4_rx_early      : std_logic_array64(7 downto 0);
    signal ul_cp_scs4_rx_late       : std_logic_array64(7 downto 0);
    signal ul_cp_scs4_rx_ndm        : std_logic_array64(7 downto 0);
    signal ul_cp_tx_total           : std_logic_array64(7 downto 0);
    signal ul_up_tx_total           : std_logic_array64(7 downto 0);
    signal dss_param_test_en        : std_logic;
    signal reg_cc0_coeff_vld_cnt    : std_logic_vector(31 downto 0);
    signal reg_cc1_coeff_vld_cnt    : std_logic_vector(31 downto 0);
    signal reg_cc0_coeff_idx_mon    : std_logic_vector(31 downto 0);
    signal reg_cc1_coeff_idx_mon    : std_logic_vector(31 downto 0);
    signal rx_pe_valid              : std_logic_array32(7 downto 0);
    signal rx_invalid_dst_mac       : std_logic_array32(7 downto 0);
    signal rx_invalid_src_mac       : std_logic_array32(7 downto 0);
    signal rx_invalid_vlan_vid      : std_logic_array32(7 downto 0);
    signal rx_discontinue           : std_logic_array32(7 downto 0);
    signal rx_byte_size             : std_logic_array32(7 downto 0);
    signal rx_byte_align            : std_logic_array32(7 downto 0);
    signal rx_dl_cp_position        : std_logic_array64(7 downto 0);
    signal rx_dl_up_position        : std_logic_array64(7 downto 0);
    signal rx_ul_cp_position        : std_logic_array64(7 downto 0);
    signal usage_rx_cp_buffer       : std_logic_array32(7 downto 0);
    signal usage_rx_up_buffer       : std_logic_array32(7 downto 0);
    signal cnt_rx_cp                : std_logic_array32(7 downto 0);
    signal cnt_rx_up                : std_logic_array32(7 downto 0);
    signal cnt_rx_cp_lost           : std_logic_array32(7 downto 0);
    signal cnt_rx_up_lost           : std_logic_array32(7 downto 0);
    signal usage_tx0_up_buffer      : std_logic_array32(7 downto 0);
    signal usage_tx1_up_buffer      : std_logic_array32(7 downto 0);
    signal cnt_tx0                  : std_logic_array32(7 downto 0);
    signal cnt_tx1                  : std_logic_array32(7 downto 0);
    signal cnt_tx0_lost             : std_logic_array32(7 downto 0);
    signal cnt_tx1_lost             : std_logic_array32(7 downto 0);
    signal det_dl_cp0_fault_id_31   : std_logic_array16(7 downto 0);
    signal det_dl_cp1_fault_id_31   : std_logic_array16(7 downto 0);
    signal det_dl_cp2_fault_id_31   : std_logic_array16(7 downto 0);
    signal det_ul_cp0_fault_id_31   : std_logic_array16(7 downto 0);
    signal det_ul_cp1_fault_id_31   : std_logic_array16(7 downto 0);
    signal det_ul_cp2_fault_id_31   : std_logic_array16(7 downto 0);
    signal det_ul_cp3_fault_id_31   : std_logic_array16(7 downto 0);
    signal det_ul_cp4_fault_id_31   : std_logic_array16(7 downto 0);
    signal status_tx0_cq_fsm        : std_logic_array8(7 downto 0);
    signal cnt_tx0_cq_fsm_busy      : std_logic_array32(7 downto 0);
    signal cnt_tx0_cq_conv_full     : std_logic_array32(7 downto 0);
    signal cnt_tx0_cpsec_symbol0    : std_logic_array32(7 downto 0);
    signal cnt_tx0_cpsec_symbol1    : std_logic_array32(7 downto 0);
    signal cnt_tx0_cpsec_symbol2    : std_logic_array32(7 downto 0);
    signal cnt_tx0_cpsec_symbol3    : std_logic_array32(7 downto 0);
    signal cnt_tx0_cpsec_symbol4    : std_logic_array32(7 downto 0);
    signal cnt_tx0_cpsec_symbol5    : std_logic_array32(7 downto 0);
    signal cnt_tx0_cpsec_symbol6    : std_logic_array32(7 downto 0);
    signal cnt_tx0_cpsec_symbol7    : std_logic_array32(7 downto 0);
    signal cnt_tx0_cpsec_symbol8    : std_logic_array32(7 downto 0);
    signal cnt_tx0_cpsec_symbol9    : std_logic_array32(7 downto 0);
    signal cnt_tx0_cpsec_symbol10   : std_logic_array32(7 downto 0);
    signal cnt_tx0_cpsec_symbol11   : std_logic_array32(7 downto 0);
    signal cnt_tx0_cpsec_symbol12   : std_logic_array32(7 downto 0);
    signal cnt_tx0_cpsec_symbol13   : std_logic_array32(7 downto 0);
    signal cnt_tx0_uppkt_symbol0    : std_logic_array32(7 downto 0);
    signal cnt_tx0_uppkt_symbol1    : std_logic_array32(7 downto 0);
    signal cnt_tx0_uppkt_symbol2    : std_logic_array32(7 downto 0);
    signal cnt_tx0_uppkt_symbol3    : std_logic_array32(7 downto 0);
    signal cnt_tx0_uppkt_symbol4    : std_logic_array32(7 downto 0);
    signal cnt_tx0_uppkt_symbol5    : std_logic_array32(7 downto 0);
    signal cnt_tx0_uppkt_symbol6    : std_logic_array32(7 downto 0);
    signal cnt_tx0_uppkt_symbol7    : std_logic_array32(7 downto 0);
    signal cnt_tx0_uppkt_symbol8    : std_logic_array32(7 downto 0);
    signal cnt_tx0_uppkt_symbol9    : std_logic_array32(7 downto 0);
    signal cnt_tx0_uppkt_symbol10   : std_logic_array32(7 downto 0);
    signal cnt_tx0_uppkt_symbol11   : std_logic_array32(7 downto 0);
    signal cnt_tx0_uppkt_symbol12   : std_logic_array32(7 downto 0);
    signal cnt_tx0_uppkt_symbol13   : std_logic_array32(7 downto 0);
    signal cnt_tx0_cq_full_symbol0  : std_logic_array32(7 downto 0);
    signal cnt_tx0_cq_full_symbol1  : std_logic_array32(7 downto 0);
    signal cnt_tx0_cq_full_symbol2  : std_logic_array32(7 downto 0);
    signal cnt_tx0_cq_full_symbol3  : std_logic_array32(7 downto 0);
    signal cnt_tx0_cq_full_symbol4  : std_logic_array32(7 downto 0);
    signal cnt_tx0_cq_full_symbol5  : std_logic_array32(7 downto 0);
    signal cnt_tx0_cq_full_symbol6  : std_logic_array32(7 downto 0);
    signal cnt_tx0_cq_full_symbol7  : std_logic_array32(7 downto 0);
    signal cnt_tx0_cq_full_symbol8  : std_logic_array32(7 downto 0);
    signal cnt_tx0_cq_full_symbol9  : std_logic_array32(7 downto 0);
    signal cnt_tx0_cq_full_symbol10 : std_logic_array32(7 downto 0);
    signal cnt_tx0_cq_full_symbol11 : std_logic_array32(7 downto 0);
    signal cnt_tx0_cq_full_symbol12 : std_logic_array32(7 downto 0);
    signal cnt_tx0_cq_full_symbol13 : std_logic_array32(7 downto 0);
    signal usage_tx0_cq_symbol0     : std_logic_array32(7 downto 0);
    signal usage_tx0_cq_symbol1     : std_logic_array32(7 downto 0);
    signal usage_tx0_cq_symbol2     : std_logic_array32(7 downto 0);
    signal usage_tx0_cq_symbol3     : std_logic_array32(7 downto 0);
    signal usage_tx0_cq_symbol4     : std_logic_array32(7 downto 0);
    signal usage_tx0_cq_symbol5     : std_logic_array32(7 downto 0);
    signal usage_tx0_cq_symbol6     : std_logic_array32(7 downto 0);
    signal usage_tx0_cq_symbol7     : std_logic_array32(7 downto 0);
    signal usage_tx0_cq_symbol8     : std_logic_array32(7 downto 0);
    signal usage_tx0_cq_symbol9     : std_logic_array32(7 downto 0);
    signal usage_tx0_cq_symbol10    : std_logic_array32(7 downto 0);
    signal usage_tx0_cq_symbol11    : std_logic_array32(7 downto 0);
    signal usage_tx0_cq_symbol12    : std_logic_array32(7 downto 0);
    signal usage_tx0_cq_symbol13    : std_logic_array32(7 downto 0);
    signal status_tx1_cq_fsm        : std_logic_array8(7 downto 0);
    signal cnt_tx1_cq_fsm_busy      : std_logic_array32(7 downto 0);
    signal cnt_tx1_cq_conv_full     : std_logic_array32(7 downto 0);
    signal cnt_tx1_cpsec_symbol0    : std_logic_array32(7 downto 0);
    signal cnt_tx1_cpsec_symbol1    : std_logic_array32(7 downto 0);
    signal cnt_tx1_cpsec_symbol2    : std_logic_array32(7 downto 0);
    signal cnt_tx1_cpsec_symbol3    : std_logic_array32(7 downto 0);
    signal cnt_tx1_cpsec_symbol4    : std_logic_array32(7 downto 0);
    signal cnt_tx1_cpsec_symbol5    : std_logic_array32(7 downto 0);
    signal cnt_tx1_cpsec_symbol6    : std_logic_array32(7 downto 0);
    signal cnt_tx1_cpsec_symbol7    : std_logic_array32(7 downto 0);
    signal cnt_tx1_cpsec_symbol8    : std_logic_array32(7 downto 0);
    signal cnt_tx1_cpsec_symbol9    : std_logic_array32(7 downto 0);
    signal cnt_tx1_cpsec_symbol10   : std_logic_array32(7 downto 0);
    signal cnt_tx1_cpsec_symbol11   : std_logic_array32(7 downto 0);
    signal cnt_tx1_cpsec_symbol12   : std_logic_array32(7 downto 0);
    signal cnt_tx1_cpsec_symbol13   : std_logic_array32(7 downto 0);
    signal cnt_tx1_uppkt_symbol0    : std_logic_array32(7 downto 0);
    signal cnt_tx1_uppkt_symbol1    : std_logic_array32(7 downto 0);
    signal cnt_tx1_uppkt_symbol2    : std_logic_array32(7 downto 0);
    signal cnt_tx1_uppkt_symbol3    : std_logic_array32(7 downto 0);
    signal cnt_tx1_uppkt_symbol4    : std_logic_array32(7 downto 0);
    signal cnt_tx1_uppkt_symbol5    : std_logic_array32(7 downto 0);
    signal cnt_tx1_uppkt_symbol6    : std_logic_array32(7 downto 0);
    signal cnt_tx1_uppkt_symbol7    : std_logic_array32(7 downto 0);
    signal cnt_tx1_uppkt_symbol8    : std_logic_array32(7 downto 0);
    signal cnt_tx1_uppkt_symbol9    : std_logic_array32(7 downto 0);
    signal cnt_tx1_uppkt_symbol10   : std_logic_array32(7 downto 0);
    signal cnt_tx1_uppkt_symbol11   : std_logic_array32(7 downto 0);
    signal cnt_tx1_uppkt_symbol12   : std_logic_array32(7 downto 0);
    signal cnt_tx1_uppkt_symbol13   : std_logic_array32(7 downto 0);
    signal cnt_tx1_cq_full_symbol0  : std_logic_array32(7 downto 0);
    signal cnt_tx1_cq_full_symbol1  : std_logic_array32(7 downto 0);
    signal cnt_tx1_cq_full_symbol2  : std_logic_array32(7 downto 0);
    signal cnt_tx1_cq_full_symbol3  : std_logic_array32(7 downto 0);
    signal cnt_tx1_cq_full_symbol4  : std_logic_array32(7 downto 0);
    signal cnt_tx1_cq_full_symbol5  : std_logic_array32(7 downto 0);
    signal cnt_tx1_cq_full_symbol6  : std_logic_array32(7 downto 0);
    signal cnt_tx1_cq_full_symbol7  : std_logic_array32(7 downto 0);
    signal cnt_tx1_cq_full_symbol8  : std_logic_array32(7 downto 0);
    signal cnt_tx1_cq_full_symbol9  : std_logic_array32(7 downto 0);
    signal cnt_tx1_cq_full_symbol10 : std_logic_array32(7 downto 0);
    signal cnt_tx1_cq_full_symbol11 : std_logic_array32(7 downto 0);
    signal cnt_tx1_cq_full_symbol12 : std_logic_array32(7 downto 0);
    signal cnt_tx1_cq_full_symbol13 : std_logic_array32(7 downto 0);
    signal usage_tx1_cq_symbol0     : std_logic_array32(7 downto 0);
    signal usage_tx1_cq_symbol1     : std_logic_array32(7 downto 0);
    signal usage_tx1_cq_symbol2     : std_logic_array32(7 downto 0);
    signal usage_tx1_cq_symbol3     : std_logic_array32(7 downto 0);
    signal usage_tx1_cq_symbol4     : std_logic_array32(7 downto 0);
    signal usage_tx1_cq_symbol5     : std_logic_array32(7 downto 0);
    signal usage_tx1_cq_symbol6     : std_logic_array32(7 downto 0);
    signal usage_tx1_cq_symbol7     : std_logic_array32(7 downto 0);
    signal usage_tx1_cq_symbol8     : std_logic_array32(7 downto 0);
    signal usage_tx1_cq_symbol9     : std_logic_array32(7 downto 0);
    signal usage_tx1_cq_symbol10    : std_logic_array32(7 downto 0);
    signal usage_tx1_cq_symbol11    : std_logic_array32(7 downto 0);
    signal usage_tx1_cq_symbol12    : std_logic_array32(7 downto 0);
    signal usage_tx1_cq_symbol13    : std_logic_array32(7 downto 0);
    signal status_tx2_cq_fsm        : std_logic_array8(7 downto 0);
    signal cnt_tx2_cq_fsm_busy      : std_logic_array32(7 downto 0);
    signal cnt_tx2_cq_conv_full     : std_logic_array32(7 downto 0);
    signal cnt_tx2_cpsec_symbol0    : std_logic_array32(7 downto 0);
    signal cnt_tx2_cpsec_symbol1    : std_logic_array32(7 downto 0);
    signal cnt_tx2_cpsec_symbol2    : std_logic_array32(7 downto 0);
    signal cnt_tx2_cpsec_symbol3    : std_logic_array32(7 downto 0);
    signal cnt_tx2_cpsec_symbol4    : std_logic_array32(7 downto 0);
    signal cnt_tx2_cpsec_symbol5    : std_logic_array32(7 downto 0);
    signal cnt_tx2_cpsec_symbol6    : std_logic_array32(7 downto 0);
    signal cnt_tx2_cpsec_symbol7    : std_logic_array32(7 downto 0);
    signal cnt_tx2_cpsec_symbol8    : std_logic_array32(7 downto 0);
    signal cnt_tx2_cpsec_symbol9    : std_logic_array32(7 downto 0);
    signal cnt_tx2_cpsec_symbol10   : std_logic_array32(7 downto 0);
    signal cnt_tx2_cpsec_symbol11   : std_logic_array32(7 downto 0);
    signal cnt_tx2_cpsec_symbol12   : std_logic_array32(7 downto 0);
    signal cnt_tx2_cpsec_symbol13   : std_logic_array32(7 downto 0);
    signal cnt_tx2_uppkt_symbol0    : std_logic_array32(7 downto 0);
    signal cnt_tx2_uppkt_symbol1    : std_logic_array32(7 downto 0);
    signal cnt_tx2_uppkt_symbol2    : std_logic_array32(7 downto 0);
    signal cnt_tx2_uppkt_symbol3    : std_logic_array32(7 downto 0);
    signal cnt_tx2_uppkt_symbol4    : std_logic_array32(7 downto 0);
    signal cnt_tx2_uppkt_symbol5    : std_logic_array32(7 downto 0);
    signal cnt_tx2_uppkt_symbol6    : std_logic_array32(7 downto 0);
    signal cnt_tx2_uppkt_symbol7    : std_logic_array32(7 downto 0);
    signal cnt_tx2_uppkt_symbol8    : std_logic_array32(7 downto 0);
    signal cnt_tx2_uppkt_symbol9    : std_logic_array32(7 downto 0);
    signal cnt_tx2_uppkt_symbol10   : std_logic_array32(7 downto 0);
    signal cnt_tx2_uppkt_symbol11   : std_logic_array32(7 downto 0);
    signal cnt_tx2_uppkt_symbol12   : std_logic_array32(7 downto 0);
    signal cnt_tx2_uppkt_symbol13   : std_logic_array32(7 downto 0);
    signal cnt_tx2_cq_full_symbol0  : std_logic_array32(7 downto 0);
    signal cnt_tx2_cq_full_symbol1  : std_logic_array32(7 downto 0);
    signal cnt_tx2_cq_full_symbol2  : std_logic_array32(7 downto 0);
    signal cnt_tx2_cq_full_symbol3  : std_logic_array32(7 downto 0);
    signal cnt_tx2_cq_full_symbol4  : std_logic_array32(7 downto 0);
    signal cnt_tx2_cq_full_symbol5  : std_logic_array32(7 downto 0);
    signal cnt_tx2_cq_full_symbol6  : std_logic_array32(7 downto 0);
    signal cnt_tx2_cq_full_symbol7  : std_logic_array32(7 downto 0);
    signal cnt_tx2_cq_full_symbol8  : std_logic_array32(7 downto 0);
    signal cnt_tx2_cq_full_symbol9  : std_logic_array32(7 downto 0);
    signal cnt_tx2_cq_full_symbol10 : std_logic_array32(7 downto 0);
    signal cnt_tx2_cq_full_symbol11 : std_logic_array32(7 downto 0);
    signal cnt_tx2_cq_full_symbol12 : std_logic_array32(7 downto 0);
    signal cnt_tx2_cq_full_symbol13 : std_logic_array32(7 downto 0);
    signal usage_tx2_cq_symbol0     : std_logic_array32(7 downto 0);
    signal usage_tx2_cq_symbol1     : std_logic_array32(7 downto 0);
    signal usage_tx2_cq_symbol2     : std_logic_array32(7 downto 0);
    signal usage_tx2_cq_symbol3     : std_logic_array32(7 downto 0);
    signal usage_tx2_cq_symbol4     : std_logic_array32(7 downto 0);
    signal usage_tx2_cq_symbol5     : std_logic_array32(7 downto 0);
    signal usage_tx2_cq_symbol6     : std_logic_array32(7 downto 0);
    signal usage_tx2_cq_symbol7     : std_logic_array32(7 downto 0);
    signal usage_tx2_cq_symbol8     : std_logic_array32(7 downto 0);
    signal usage_tx2_cq_symbol9     : std_logic_array32(7 downto 0);
    signal usage_tx2_cq_symbol10    : std_logic_array32(7 downto 0);
    signal usage_tx2_cq_symbol11    : std_logic_array32(7 downto 0);
    signal usage_tx2_cq_symbol12    : std_logic_array32(7 downto 0);
    signal usage_tx2_cq_symbol13    : std_logic_array32(7 downto 0);
    signal usage_tx3_cq_symbol0     : std_logic_array32(7 downto 0);
    signal usage_tx3_cq_symbol1     : std_logic_array32(7 downto 0);
    signal usage_tx3_cq_symbol2     : std_logic_array32(7 downto 0);
    signal usage_tx3_cq_symbol3     : std_logic_array32(7 downto 0);
    signal usage_tx3_cq_symbol4     : std_logic_array32(7 downto 0);
    signal usage_tx3_cq_symbol5     : std_logic_array32(7 downto 0);
    signal usage_tx3_cq_symbol6     : std_logic_array32(7 downto 0);
    signal usage_tx3_cq_symbol7     : std_logic_array32(7 downto 0);
    signal usage_tx3_cq_symbol8     : std_logic_array32(7 downto 0);
    signal usage_tx3_cq_symbol9     : std_logic_array32(7 downto 0);
    signal usage_tx3_cq_symbol10    : std_logic_array32(7 downto 0);
    signal usage_tx3_cq_symbol11    : std_logic_array32(7 downto 0);
    signal usage_tx3_cq_symbol12    : std_logic_array32(7 downto 0);
    signal usage_tx3_cq_symbol13    : std_logic_array32(7 downto 0);
    signal usage_tx4_cq_symbol0     : std_logic_array32(7 downto 0);
    signal usage_tx4_cq_symbol1     : std_logic_array32(7 downto 0);
    signal usage_tx4_cq_symbol2     : std_logic_array32(7 downto 0);
    signal usage_tx4_cq_symbol3     : std_logic_array32(7 downto 0);
    signal usage_tx4_cq_symbol4     : std_logic_array32(7 downto 0);
    signal usage_tx4_cq_symbol5     : std_logic_array32(7 downto 0);
    signal usage_tx4_cq_symbol6     : std_logic_array32(7 downto 0);
    signal usage_tx4_cq_symbol7     : std_logic_array32(7 downto 0);
    signal usage_tx4_cq_symbol8     : std_logic_array32(7 downto 0);
    signal usage_tx4_cq_symbol9     : std_logic_array32(7 downto 0);
    signal usage_tx4_cq_symbol10    : std_logic_array32(7 downto 0);
    signal usage_tx4_cq_symbol11    : std_logic_array32(7 downto 0);
    signal usage_tx4_cq_symbol12    : std_logic_array32(7 downto 0);
    signal usage_tx4_cq_symbol13    : std_logic_array32(7 downto 0);

begin

--------------------------------------------------------------------------------
-- Port mapping (CU_PE_TOP <-> LPHY, DL 4-antenna, 2CC)
--------------------------------------------------------------------------------

    dl_sync_advance(0)              <= DL_CC0_SYNC_ADVANCE;
    dl_sync_advance(1)              <= DL_CC0_SYNC_ADVANCE; -- + conv_std_logic_vector(8768*2, 22);
    dl_sync_advance(2)              <= DL_CC0_SYNC_ADVANCE;
    dl_sync_advance(3)              <= DL_CC0_SYNC_ADVANCE;-- + conv_std_logic_vector(8768*2, 22);

    ul_sync_retard(0)               <= UL_CC0_SYNC_RETARD;
    ul_sync_retard(1)               <= UL_CC0_SYNC_RETARD;
    ul_sync_retard(2)               <= UL_CC0_SYNC_RETARD;
    ul_sync_retard(3)               <= UL_CC0_SYNC_RETARD;

--    TDD_CC0_SYMBOL_SYNC             <= tdd_sym_sync(0);
--    TDD_CC0_SYMBOL_INDEX            <= tdd_sym_index(0);
--    TDD_CC0_DL_EN                   <= tdd_dl_enable(0);
--    TDD_CC0_UL_EN                   <= tdd_ul_enable(0);

--    TDD_CC1_SYMBOL_SYNC             <= tdd_sym_sync(1);
--    TDD_CC1_SYMBOL_INDEX            <= tdd_sym_index(1);
--    TDD_CC1_DL_EN                   <= tdd_dl_enable(1);
--    TDD_CC1_UL_EN                   <= tdd_ul_enable(1);

--    TDD_CC2_SYMBOL_SYNC             <= tdd_sym_sync(2);
--    TDD_CC2_SYMBOL_INDEX            <= tdd_sym_index(2);
--    TDD_CC2_DL_EN                   <= tdd_dl_enable(2);
--    TDD_CC2_UL_EN                   <= tdd_ul_enable(2);

--    TDD_CC3_SYMBOL_SYNC             <= tdd_sym_sync(3);
--    TDD_CC3_SYMBOL_INDEX            <= tdd_sym_index(3);
--    TDD_CC3_DL_EN                   <= tdd_dl_enable(3);
--    TDD_CC3_UL_EN                   <= tdd_ul_enable(3);

    dlfe_system_mode(0)             <= DLFE_CC0_SYSTEM_MODE;
    dlfe_system_mode(1)             <= DLFE_CC1_SYSTEM_MODE;
--    dlfe_system_mode(2)             <= DLFE_CC2_SYSTEM_MODE;
--    dlfe_system_mode(3)             <= DLFE_CC3_SYSTEM_MODE;

    dlfe_k0(0)                      <= DLFE_CC0_K0;                 
    dlfe_k0(1)                      <= DLFE_CC1_K0;                 
--    dlfe_k0(2)                      <= DLFE_CC2_K0;                 
--    dlfe_k0(3)                      <= DLFE_CC3_K0;                     

    dlfe_nRE(0)                     <= DLFE_CC0_nRE;               
    dlfe_nRE(1)                     <= DLFE_CC1_nRE;               
--    dlfe_nRE(2)                     <= DLFE_CC2_nRE;               
--    dlfe_nRE(3)                     <= DLFE_CC3_nRE;               

    dlfe_nFFT(0)                    <= DLFE_CC0_nFFT;
    dlfe_nFFT(1)                    <= DLFE_CC1_nFFT;
--    dlfe_nFFT(2)                    <= DLFE_CC2_nFFT;
--    dlfe_nFFT(3)                    <= DLFE_CC3_nFFT;    

    DLFE_CC0_FRAME_SYNC             <= dlfe_frame_sync(0);
    DLFE_CC0_FRAME_INDEX            <= dlfe_frame_index(0);
    DLFE_CC0_VALID                  <= dlfe_valid(0);
    DLFE_CC0_RE_MASK                <= dlfe_re_mask(0);
    DLFE_CC0_DATA                   <= dlfe_data(0);

    DLFE_CC1_FRAME_SYNC             <= dlfe_frame_sync(1);
    DLFE_CC1_FRAME_INDEX            <= dlfe_frame_index(1);
    DLFE_CC1_VALID                  <= dlfe_valid(1);
    DLFE_CC1_RE_MASK                <= dlfe_re_mask(1);
    DLFE_CC1_DATA                   <= dlfe_data(1);

--    DLFE_CC2_FRAME_SYNC             <= dlfe_frame_sync(2);
--    DLFE_CC2_FRAME_INDEX            <= dlfe_frame_index(2);
--    DLFE_CC2_VALID                  <= dlfe_valid(2);
--    DLFE_CC2_RE_MASK                <= dlfe_re_mask(2);
--    DLFE_CC2_DATA                   <= dlfe_data(2);

--    DLFE_CC3_FRAME_SYNC             <= dlfe_frame_sync(3);
--    DLFE_CC3_FRAME_INDEX            <= dlfe_frame_index(3);
--    DLFE_CC3_VALID                  <= dlfe_valid(3);
--    DLFE_CC3_RE_MASK                <= dlfe_re_mask(3);
--    DLFE_CC3_DATA                   <= dlfe_data(3);

    RAFE_CC0_FRAMES_SYNC            <= rafe_frame_sync(0);
    RAFE_CC0_FILTER_INDEX           <= rafe_filter_index(0);
    RAFE_CC0_TIME_OFFSET            <= rafe_time_offset(0);
    RAFE_CC0_FRAME_STRUCTURE        <= rafe_frame_structure(0);
    RAFE_CC0_CPLENGTH               <= rafe_cplength(0);
    RAFE_CC0_FREQ_OFFSET            <= rafe_freq_offset(0);
    RAFE_CC0_START_PRBC             <= rafe_start_prbc(0);
    RAFE_CC0_NUM_PRBC               <= rafe_num_prbc(0);
    RAFE_CC0_NUM_PSYMBOL            <= rafe_num_psymbol(0);
    RAFE_CC0_NUM_RO                 <= rafe_num_ro(0);

    RAFE_CC1_FRAMES_SYNC            <= rafe_frame_sync(1);
    RAFE_CC1_FILTER_INDEX           <= rafe_filter_index(1);
    RAFE_CC1_TIME_OFFSET            <= rafe_time_offset(1);
    RAFE_CC1_FRAME_STRUCTURE        <= rafe_frame_structure(1);
    RAFE_CC1_CPLENGTH               <= rafe_cplength(1);
    RAFE_CC1_FREQ_OFFSET            <= rafe_freq_offset(1);
    RAFE_CC1_START_PRBC             <= rafe_start_prbc(1);
    RAFE_CC1_NUM_PRBC               <= rafe_num_prbc(1);
    RAFE_CC1_NUM_PSYMBOL            <= rafe_num_psymbol(1);
    RAFE_CC1_NUM_RO                 <= rafe_num_ro(1);

--    RAFE_CC2_FRAMES_SYNC            <= rafe_frame_sync(2);
--    RAFE_CC2_FILTER_INDEX           <= rafe_filter_index(2);
--    RAFE_CC2_TIME_OFFSET            <= rafe_time_offset(2);
--    RAFE_CC2_FRAME_STRUCTURE        <= rafe_frame_structure(2);
--    RAFE_CC2_CPLENGTH               <= rafe_cplength(2);
--    RAFE_CC2_FREQ_OFFSET            <= rafe_freq_offset(2);
--    RAFE_CC2_START_PRBC             <= rafe_start_prbc(2);
--    RAFE_CC2_NUM_PRBC               <= rafe_num_prbc(2);
--    RAFE_CC2_NUM_PSYMBOL            <= rafe_num_psymbol(2);
--    RAFE_CC2_NUM_RO                 <= rafe_num_ro(2);

--    RAFE_CC3_FRAMES_SYNC            <= rafe_frame_sync(3);
--    RAFE_CC3_FILTER_INDEX           <= rafe_filter_index(3);
--    RAFE_CC3_TIME_OFFSET            <= rafe_time_offset(3);
--    RAFE_CC3_FRAME_STRUCTURE        <= rafe_frame_structure(3);
--    RAFE_CC3_CPLENGTH               <= rafe_cplength(3);
--    RAFE_CC3_FREQ_OFFSET            <= rafe_freq_offset(3);
--    RAFE_CC3_START_PRBC             <= rafe_start_prbc(3);
--    RAFE_CC3_NUM_PRBC               <= rafe_num_prbc(3);
--    RAFE_CC3_NUM_PSYMBOL            <= rafe_num_psymbol(3);
--    RAFE_CC3_NUM_RO                 <= rafe_num_ro(3);

--    eMTC_CC0_FRAME_SYNC             <= rafe_frame_sync(0);                             --  : out std_logic_vector(1-1 downto 0);
--    eMTC_CC0_FILTER_INDEX           <= emtc_filter_index(0);                           --  : out std_logic_vector(2*4-1 downto 0);
--    eMTC_CC0_TIME_OFFSET            <= emtc_time_offset(0);                            --  : out std_logic_vector(2*16-1 downto 0);
--    eMTC_CC0_FRAME_STRUCTURE        <= emtc_frame_structure(0);                        --  : out std_logic_vector(2*8-1 downto 0);
--    eMTC_CC0_CPLENGTH               <= emtc_cplength(0);                               --  : out std_logic_vector(2*16-1 downto 0); 
--    eMTC_CC0_FREQ_OFFSET            <= emtc_freq_offset(0);                            --  : out std_logic_vector(2*24-1 downto 0); 
--    eMTC_CC0_START_PRBC             <= emtc_start_prbc(0);                             --  : out std_logic_vector(2*10-1 downto 0);
--    eMTC_CC0_NUM_PRBC               <= emtc_num_prbc(0);                               --  : out std_logic_vector(2*8-1 downto 0);
--    eMTC_CC0_NUM_PSYMBOL            <= emtc_num_psymbol(0);                            --  : out std_logic_vector(2*4-1 downto 0); 
--    eMTC_CC0_NUM_RO                 <= emtc_num_ro(0);                                 --  : out std_logic_vector(2*3-1 downto 0); 

--    eMTC_CC1_FRAME_SYNC             <= rafe_frame_sync(1);                             --  : out std_logic_vector(1-1 downto 0);                    
--    eMTC_CC1_FILTER_INDEX           <= emtc_filter_index(1);                           --  : out std_logic_vector(2*4-1 downto 0); 
--    eMTC_CC1_TIME_OFFSET            <= emtc_time_offset(1);                            --  : out std_logic_vector(2*16-1 downto 0); 
--    eMTC_CC1_FRAME_STRUCTURE        <= emtc_frame_structure(1);                        --  : out std_logic_vector(2*8-1 downto 0); 
--    eMTC_CC1_CPLENGTH               <= emtc_cplength(1);                               --  : out std_logic_vector(2*16-1 downto 0); 
--    eMTC_CC1_FREQ_OFFSET            <= emtc_freq_offset(1);                            --  : out std_logic_vector(2*24-1 downto 0); 
--    eMTC_CC1_START_PRBC             <= emtc_start_prbc(1);                             --  : out std_logic_vector(2*10-1 downto 0);
--    eMTC_CC1_NUM_PRBC               <= emtc_num_prbc(1);                               --  : out std_logic_vector(2*8-1 downto 0);
--    eMTC_CC1_NUM_PSYMBOL            <= emtc_num_psymbol(1);                            --  : out std_logic_vector(2*4-1 downto 0); 
--    eMTC_CC1_NUM_RO                 <= emtc_num_ro(1);                                 --  : out std_logic_vector(2*3-1 downto 0); 

--    eMTC_CC2_FRAME_SYNC             <= rafe_frame_sync(2);                             --  : out std_logic_vector(1-1 downto 0);                    
--    eMTC_CC2_FILTER_INDEX           <= emtc_filter_index(2);                           --  : out std_logic_vector(2*4-1 downto 0); 
--    eMTC_CC2_TIME_OFFSET            <= emtc_time_offset(2);                            --  : out std_logic_vector(2*16-1 downto 0); 
--    eMTC_CC2_FRAME_STRUCTURE        <= emtc_frame_structure(2);                        --  : out std_logic_vector(2*8-1 downto 0); 
--    eMTC_CC2_CPLENGTH               <= emtc_cplength(2);                               --  : out std_logic_vector(2*16-1 downto 0); 
--    eMTC_CC2_FREQ_OFFSET            <= emtc_freq_offset(2);                            --  : out std_logic_vector(2*24-1 downto 0); 
--    eMTC_CC2_START_PRBC             <= emtc_start_prbc(2);                             --  : out std_logic_vector(2*10-1 downto 0);
--    eMTC_CC2_NUM_PRBC               <= emtc_num_prbc(2);                               --  : out std_logic_vector(2*8-1 downto 0);
--    eMTC_CC2_NUM_PSYMBOL            <= emtc_num_psymbol(2);                            --  : out std_logic_vector(2*4-1 downto 0); 
--    eMTC_CC2_NUM_RO                 <= emtc_num_ro(2);                                 --  : out std_logic_vector(2*3-1 downto 0); 

--    eMTC_CC3_FRAME_SYNC             <= rafe_frame_sync(3);                             --  : out std_logic_vector(1-1 downto 0);                    
--    eMTC_CC3_FILTER_INDEX           <= emtc_filter_index(3);                           --  : out std_logic_vector(2*4-1 downto 0); 
--    eMTC_CC3_TIME_OFFSET            <= emtc_time_offset(3);                            --  : out std_logic_vector(2*16-1 downto 0); 
--    eMTC_CC3_FRAME_STRUCTURE        <= emtc_frame_structure(3);                        --  : out std_logic_vector(2*8-1 downto 0); 
--    eMTC_CC3_CPLENGTH               <= emtc_cplength(3);                               --  : out std_logic_vector(2*16-1 downto 0); 
--    eMTC_CC3_FREQ_OFFSET            <= emtc_freq_offset(3);                            --  : out std_logic_vector(2*24-1 downto 0); 
--    eMTC_CC3_START_PRBC             <= emtc_start_prbc(3);                             --  : out std_logic_vector(2*10-1 downto 0);
--    eMTC_CC3_NUM_PRBC               <= emtc_num_prbc(3);                               --  : out std_logic_vector(2*8-1 downto 0);
--    eMTC_CC3_NUM_PSYMBOL            <= emtc_num_psymbol(3);                            --  : out std_logic_vector(2*4-1 downto 0); 
--    eMTC_CC3_NUM_RO                 <= emtc_num_ro(3);                                 --  : out std_logic_vector(2*3-1 downto 0);     

--------------------------------------------------------------------------------
-- Port mapping (UL_DM <-> LPHY, UL 4-antenna, 2CC)
--------------------------------------------------------------------------------


--------------------------------------------------------------------------------
-- Processor System Reset
--------------------------------------------------------------------------------

    u_PSR : for i in 0 downto 0 generate
    u_PSR_RX : eCPRI_PROC_SYS_RESET
    port map(
        SLOWEST_SYNC_CLK            => CLK_MAC_RX                              ,--: in  std_logic;
        EXT_RESET_IN                => ARESET_RX(i)                            ,--: in  std_logic;
        AUX_RESET_IN                => '0'                                     ,--: in  std_logic;
        MB_DEBUG_SYS_RST            => '0'                                     ,--: in  std_logic;
        DCM_LOCKED                  => '1'                                     ,--: in  std_logic;
        MB_RESET                    => open                                    ,--: out std_logic;
        BUS_STRUCT_RESET            => sreset_inter_rx(i downto i)             ,--: out std_logic_vector(0 downto 0);
        PERIPHERAL_RESET            => sreset_peri_rx(i downto i)              ,--: out std_logic_vector(0 downto 0);
        INTERCONNECT_ARESETN        => sreset_inter_n_rx(i downto i)           ,--: out std_logic_vector(0 downto 0);
        PERIPHERAL_ARESETN          => sreset_peri_n_rx(i downto i)             --: out std_logic_vector(0 downto 0)
    );

    u_PSR_TX : eCPRI_PROC_SYS_RESET
    port map(
        SLOWEST_SYNC_CLK            => CLK_MAC_TX                              ,--: in  std_logic;
        EXT_RESET_IN                => ARESET_TX(i)                            ,--: in  std_logic;
        AUX_RESET_IN                => '0'                                     ,--: in  std_logic;
        MB_DEBUG_SYS_RST            => '0'                                     ,--: in  std_logic;
        DCM_LOCKED                  => '1'                                     ,--: in  std_logic;
        MB_RESET                    => open                                    ,--: out std_logic;
        BUS_STRUCT_RESET            => sreset_inter_tx(i downto i)             ,--: out std_logic_vector(0 downto 0);
        PERIPHERAL_RESET            => sreset_peri_tx(i downto i)              ,--: out std_logic_vector(0 downto 0);
        INTERCONNECT_ARESETN        => sreset_inter_n_tx(i downto i)           ,--: out std_logic_vector(0 downto 0);
        PERIPHERAL_ARESETN          => sreset_peri_n_tx(i downto i)             --: out std_logic_vector(0 downto 0)
    );
    end generate;

--------------------------------------------------------------------------------
-- Interconnect between FHs and user logics
--------------------------------------------------------------------------------

    u_FH0_INTERCONNECT : FH_INTERCONNECT
    generic map(
        IMPL_PDxCH                  => IMPL_PDxCH                              ,--: boolean := true;
        IMPL_SSB                    => IMPL_SSB                                ,--: boolean := false;
        IMPL_H_MATRIX               => IMPL_H_MATRIX                           ,--: boolean := false;
        IMPL_PUxCH                  => IMPL_PUxCH                              ,--: boolean := true;
        IMPL_PRACH                  => IMPL_PRACH                              ,--: boolean := true;
        IMPL_SRS                    => IMPL_SRS                                ,--: boolean := false;
        IMPL_RIM_RS                 => IMPL_RIM_RS                             ,--: boolean := false;
        IMPL_NB_IoT                 => IMPL_NB_IoT                             ,--: boolean := false;

        MAX_PDxCH                   => MAX_CC_DL*MAX_PDxCH                     ,--: natural := 4;
        MAX_SSB                     => MAX_CC_DL*MAX_SSB                       ,--: natural := 0;
        MAX_H_MATRIX                => MAX_CC_DL*MAX_H_MATRIX                  ,--: natural := 0;
        MAX_PUxCH                   => MAX_CC_UL*MAX_PUxCH                     ,--: natural := 4;
        MAX_PRACH                   => MAX_CC_UL*MAX_PRACH                     ,--: natural := 4;
        MAX_SRS                     => MAX_CC_UL*MAX_SRS                       ,--: natural := 0;
        MAX_RIM_RS                  => MAX_CC_UL*MAX_RIM_RS                    ,--: natural := 0;
        MAX_NB_IoT                  => MAX_CC_UL*MAX_NB_IoT                    ,--: natural := 0;

        NUM_PORT_TX                 => NUM_PORT_TX                              --: natural := 2
    )
    port map(
        CLK_MAC_RX                  => CLK_MAC_RX                              ,--: in  std_logic;
        CLK_MAC_TX                  => CLK_MAC_TX                              ,--: in  std_logic;
        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

        RST_RX                      => sreset_inter_rx(0)                      ,--: in  std_logic;
        RST_RX_n                    => sreset_inter_n_rx(0)                    ,--: in  std_logic;
        RST_TX                      => sreset_inter_tx(0)                      ,--: in  std_logic;
        RST_TX_n                    => sreset_inter_n_tx(0)                    ,--: in  std_logic;

        IGNORE_VLAN_VID             => user_debug1(1)                          ,--: in  std_logic;

        DL_PARAM_ID_EN              => dl_param_id_en                          ,--: in  std_logic_array64(7 downto 0);
        DL_PARAM_ID                 => dl_param_id                             ,--: in  std_logic_array64_array16(7 downto 0);
        DL_PE_INDEX                 => dl_pe_index                             ,--: in  std_logic_array64_array8(7 downto 0);
        DL_SCS_CONFIG               => dl_scs_config                           ,--: in  std_logic_array64_array4(7 downto 0);

        UL_PARAM_ID_EN              => ul_param_id_en                          ,--: in  std_logic_array64(7 downto 0);
        UL_PARAM_ID                 => ul_param_id                             ,--: in  std_logic_array64_array16(7 downto 0);
        UL_PE_INDEX                 => ul_pe_index                             ,--: in  std_logic_array64_array8(7 downto 0);
        UL_SCS_CONFIG               => ul_scs_config                           ,--: in  std_logic_array64_array4(7 downto 0);

        PARAM_DST_MAC               => param_ru_mac                            ,--: in  std_logic_array48(7 downto 0);
        PARAM_SRC_MAC               => param_du_mac                            ,--: in  std_logic_array48(7 downto 0);
        PARAM_VLAN0_MODE            => param_vlan0_en                          ,--: in  std_logic_vector(7 downto 0);
        PARAM_VLAN0_VID             => param_vlan0_vid                         ,--: in  std_logic_array12(7 downto 0);
        PARAM_VLAN1_MODE            => param_vlan1_en                          ,--: in  std_logic_vector(7 downto 0);
        PARAM_VLAN1_VID             => param_vlan1_vid                         ,--: in  std_logic_array12(7 downto 0);

        RX_PE_VALID                 => rx_pe_valid                             ,--: out std_logic_array32(7 downto 0);
        RX_INVALID_DST_MAC          => rx_invalid_dst_mac                      ,--: out std_logic_array32(7 downto 0);
        RX_INVALID_SRC_MAC          => rx_invalid_src_mac                      ,--: out std_logic_array32(7 downto 0);
        RX_INVALID_VLAN_VID         => rx_invalid_vlan_vid                     ,--: out std_logic_array32(7 downto 0);

        RX_DISCONTINUE              => rx_discontinue(0)                       ,--: out std_logic_vector(31 downto 0);
        RX_BYTE_SIZE                => rx_byte_size(0)                         ,--: out std_logic_vector(31 downto 0);
        RX_BYTE_ALIGN               => rx_byte_align(0)                        ,--: out std_logic_vector(31 downto 0);

        RX_DL_CP_POSITION           => rx_dl_cp_position                       ,--: out std_logic_array64(7 downto 0);
        RX_DL_UP_POSITION           => rx_dl_up_position                       ,--: out std_logic_array64(7 downto 0);
        RX_UL_CP_POSITION           => rx_ul_cp_position                       ,--: out std_logic_array64(7 downto 0);

        MAC_RX_VALID                => MAC0_RX_VALID                           ,--: in  std_logic;
        MAC_RX_LAST                 => MAC0_RX_LAST                            ,--: in  std_logic;
        MAC_RX_KEEP                 => MAC0_RX_KEEP                            ,--: in  std_logic_vector(7 downto 0);
        MAC_RX_DATA                 => MAC0_RX_DATA                            ,--: in  std_logic_vector(63 downto 0);

        MAC_TX_READY                => MAC0_TX_READY                           ,--: in  std_logic;
        MAC_TX_VALID                => MAC0_TX_VALID                           ,--: out std_logic;
        MAC_TX_LAST                 => MAC0_TX_LAST                            ,--: out std_logic;
        MAC_TX_KEEP                 => MAC0_TX_KEEP                            ,--: out std_logic_vector(7 downto 0);
        MAC_TX_DATA                 => MAC0_TX_DATA                            ,--: out std_logic_vector(63 downto 0);

        PACKET_IS_CP_DL             => packet_is_cp_dl                         ,--: out std_logic_vector(MAX_RU_ELEMENT-1 downto 0);
        PACKET_IS_CP_UL             => packet_is_cp_ul                         ,--: out std_logic_vector(MAX_RU_ELEMENT-1 downto 0);
        PACKET_IS_UP_DL             => packet_is_up_dl                         ,--: out std_logic_vector(MAX_RU_ELEMENT-1 downto 0);
        PACKET_IS_NDM               => packet_is_ndm                           ,--: out std_logic;
        PACKET_SCS                  => packet_scs                              ,--: out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => packet_frame_id                         ,--: out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => packet_subframe_id                      ,--: out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => packet_slot_id                          ,--: out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => packet_symbol_id                        ,--: out std_logic_vector(5 downto 0);

        ORAN_RX_C64_VALID           => oran_rx_c64_valid                       ,--: out std_logic;
        ORAN_RX_C64_LAST            => oran_rx_c64_last                        ,--: out std_logic;
        ORAN_RX_C64_KEEP            => oran_rx_c64_keep                        ,--: out std_logic_vector(7 downto 0);
        ORAN_RX_C64_DATA            => oran_rx_c64_data                        ,--: out std_logic_vector(63 downto 0);
        ORAN_RX_C64_DATA_INDEX      => oran_rx_c64_data_index                  ,--: out std_logic_vector(2 downto 0);
        ORAN_RX_C64_LINK_MAP        => oran_rx_c64_link_map                    ,--: out std_logic_vector(15 downto 0);

        ORAN_RX_U64_VALID           => oran_rx_u64_valid                       ,--: out std_logic;
        ORAN_RX_U64_LAST            => oran_rx_u64_last                        ,--: out std_logic;
        ORAN_RX_U64_KEEP            => oran_rx_u64_keep                        ,--: out std_logic_vector(7 downto 0);
        ORAN_RX_U64_DATA            => oran_rx_u64_data                        ,--: out std_logic_vector(63 downto 0);
        ORAN_RX_U64_DATA_INDEX      => oran_rx_u64_data_index                  ,--: out std_logic_vector(2 downto 0);
        ORAN_RX_U64_LINK_MAP        => oran_rx_u64_link_map                    ,--: out std_logic_vector(15 downto 0);

        MAC_IC_TX_READY             => mac_ic_tx_ready                         ,--: out std_logic_vector(NUM_PORT_TX-1 downto 0);
        MAC_IC_TX_VALID             => mac_ic_tx_valid                         ,--: in  std_logic_vector(NUM_PORT_TX-1 downto 0);
        MAC_IC_TX_LAST              => mac_ic_tx_last                          ,--: in  std_logic_vector(NUM_PORT_TX-1 downto 0);
        MAC_IC_TX_KEEP              => mac_ic_tx_keep                          ,--: in  std_logic_array8(NUM_PORT_TX-1 downto 0);
        MAC_IC_TX_DATA              => mac_ic_tx_data                          ,--: in  std_logic_array64(NUM_PORT_TX-1 downto 0)

        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => RST_CPUIF                               ,--: in  std_logic;
        RX_WINDOW_UPDATE_EN         => rx_window_update_en,

        N_TA_OFFSET                 => N_TA_OFFSET_CC0                         ,--: in  std_logic_vector(15 downto 0);

        REF_10msec                  => FRAME_SYNC                              ,--: in  std_logic;
        REF_SFN                     => FRAME_NUM(7 downto 0)                   ,--: in  std_logic_vector(7 downto 0);

        CAPTURE_PERIOD              => capture_period                          ,--: in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            => t2a_max_dl_cp_rx                        ,--: in  std_logic_array22(4 downto 0);
        T2A_MIN_DL_CP_RX            => t2a_min_dl_cp_rx                        ,--: in  std_logic_array22(4 downto 0);
        T2A_MAX_DL_UP_RX            => t2a_max_dl_up_rx                        ,--: in  std_logic_array22(4 downto 0);
        T2A_MIN_DL_UP_RX            => t2a_min_dl_up_rx                        ,--: in  std_logic_array22(4 downto 0);
        
        CNT_RX_CORRUPT                          => cnt_rx_corrupt                                   ,
        CNT_RX_SECTIONID                        => cnt_rx_corrupt_sectionid                         ,
        CNT_RX_PCID_eCPRIVERSION_PAYLOADVERSION => cnt_rx_corrupt_ecpriversion_payloadversion_pcid  ,
        CNT_RX_PCID                             => cnt_rx_corrupt_pcid                              ,
        CNT_RX_eCPRIVERSION                     => cnt_rx_corrupt_ecpriversion                      ,
        CNT_RX_PAYLOADVERSION                   => cnt_rx_corrupt_payloadversion                    
        
    );

    MAC1_TX_VALID                   <= '0';
    MAC1_TX_LAST                    <= '0';
    MAC1_TX_KEEP                    <= (others => '0');
    MAC1_TX_DATA                    <= (others => '0');

--------------------------------------------------------------------------------
-- Downlink
--------------------------------------------------------------------------------

    u_DL : for i in DL_UNIT-1 downto 0 generate
    u_ORAN_RX : ORAN_RX
    generic map(
        LINK_MAP_MASK               => LINK_MASK_4U(i) --LINK_MASK_2U(i)                          --: std_logic_vector(15 downto 0)
    )
    port map(
        RST                         => sreset_inter_rx(0)                      ,--: in  std_logic;

        CLK_MAC                     => CLK_MAC_RX                              ,--: in  std_logic;
        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

        DL_COMP_MODE                => dl_comp_mode                            ,--: in  std_logic_array64(7 downto 0);
        DL_IQ_WIDTH                 => dl_iq_width                             ,--: in  std_logic_array64_array4(7 downto 0);
        DL_COMP_METHOD              => dl_comp_method                          ,--: in  std_logic_array64_array4(7 downto 0);
        DL_PRB_PER_SYMBOL           => dl_prb_per_symbol                       ,--: in  std_logic_array64_array10(7 downto 0);
        DL_COMP_EXP_OFFSET          => dl_comp_exp_offset                      ,--: in  std_logic_array64_array5(7 downto 0);

        USAGE_RX_CP_BUFFER          => usage_rx_cp_buffer(i)                   ,--: out std_logic_vector(31 downto 0);
        USAGE_RX_UP_BUFFER          => usage_rx_up_buffer(i)                   ,--: out std_logic_vector(31 downto 0);

        CNT_RX_CP                   => cnt_rx_cp(i)                            ,--: out std_logic_vector(31 downto 0);
        CNT_RX_UP                   => cnt_rx_up(i)                            ,--: out std_logic_vector(31 downto 0);
        CNT_RX_CP_LOST              => cnt_rx_cp_lost(i)                       ,--: out std_logic_vector(31 downto 0);
        CNT_RX_UP_LOST              => cnt_rx_up_lost(i)                       ,--: out std_logic_vector(31 downto 0);

        DET_DL_CP0_FAULT_ID_31      => det_dl_cp0_fault_id_31(i)               ,--: out std_logic_vector(15 downto 0);
        DET_DL_CP1_FAULT_ID_31      => det_dl_cp1_fault_id_31(i)               ,--: out std_logic_vector(15 downto 0);
        DET_DL_CP2_FAULT_ID_31      => det_dl_cp2_fault_id_31(i)               ,--: out std_logic_vector(15 downto 0);
        DET_DL_CP3_FAULT_ID_31      => open                                    ,--: out std_logic_vector(15 downto 0);
        DET_DL_CP4_FAULT_ID_31      => open                                    ,--: out std_logic_vector(15 downto 0);
        DET_DL_CP5_FAULT_ID_31      => open                                    ,--: out std_logic_vector(15 downto 0);
        DET_DL_CP6_FAULT_ID_31      => open                                    ,--: out std_logic_vector(15 downto 0);
        DET_DL_CP7_FAULT_ID_31      => open                                    ,--: out std_logic_vector(15 downto 0);
        DET_UL_CP0_FAULT_ID_31      => det_ul_cp0_fault_id_31(i)               ,--: out std_logic_vector(15 downto 0);
        DET_UL_CP1_FAULT_ID_31      => det_ul_cp1_fault_id_31(i)               ,--: out std_logic_vector(15 downto 0);
        DET_UL_CP2_FAULT_ID_31      => det_ul_cp2_fault_id_31(i)               ,--: out std_logic_vector(15 downto 0);
        DET_UL_CP3_FAULT_ID_31      => det_ul_cp3_fault_id_31(i)               ,--: out std_logic_vector(15 downto 0);
        DET_UL_CP4_FAULT_ID_31      => det_ul_cp4_fault_id_31(i)               ,--: out std_logic_vector(15 downto 0);
        DET_UL_CP5_FAULT_ID_31      => open                                    ,--: out std_logic_vector(15 downto 0);
        DET_UL_CP6_FAULT_ID_31      => open                                    ,--: out std_logic_vector(15 downto 0);
        DET_UL_CP7_FAULT_ID_31      => open                                    ,--: out std_logic_vector(15 downto 0);

        ORAN_RX_C64_VALID           => oran_rx_c64_valid                       ,--: in  std_logic;
        ORAN_RX_C64_LAST            => oran_rx_c64_last                        ,--: in  std_logic;
        ORAN_RX_C64_KEEP            => oran_rx_c64_keep                        ,--: in  std_logic_vector(7 downto 0);
        ORAN_RX_C64_DATA            => oran_rx_c64_data                        ,--: in  std_logic_vector(63 downto 0);
        ORAN_RX_C64_DATA_INDEX      => oran_rx_c64_data_index                  ,--: in  std_logic_vector(2 downto 0);
        ORAN_RX_C64_LINK_MAP        => oran_rx_c64_link_map                    ,--: in  std_logic_vector(15 downto 0);

        ORAN_RX_U64_VALID           => oran_rx_u64_valid                       ,--: in  std_logic;
        ORAN_RX_U64_LAST            => oran_rx_u64_last                        ,--: in  std_logic;
        ORAN_RX_U64_KEEP            => oran_rx_u64_keep                        ,--: in  std_logic_vector(7 downto 0);
        ORAN_RX_U64_DATA            => oran_rx_u64_data                        ,--: in  std_logic_vector(63 downto 0);
        ORAN_RX_U64_DATA_INDEX      => oran_rx_u64_data_index                  ,--: in  std_logic_vector(2 downto 0);
        ORAN_RX_U64_LINK_MAP        => oran_rx_u64_link_map                    ,--: in  std_logic_vector(15 downto 0);

        xL_CP_VALID                 => xl_cp_valid(i)                          ,--: out std_logic;
        xL_CP_LAST                  => xl_cp_last(i)                           ,--: out std_logic;
        xL_CP_DATA                  => xl_cp_data(i)                           ,--: out std_logic_vector(31 downto 0);
        xL_CP_DATA_INDEX            => xl_cp_data_index(i)                     ,--: out std_logic_vector(2 downto 0);
        xL_CP_LINK_INDEX            => xl_cp_link_index(i)                     ,--: out std_logic_vector(3 downto 0);

        DL_RB_eAxC_ID               => open                                    ,--: out std_logic_vector(15 downto 0);
        DL_RB_SEQUENCE_ID           => open                                    ,--: out std_logic_vector(15 downto 0);
        DL_RB_CHANNEL_ID            => dl_rb_channel_id(i)                     ,--: out std_logic_vector(3 downto 0);
        DL_RB_FRAME_ID              => dl_rb_frame_id(i)                       ,--: out std_logic_vector(7 downto 0);
        DL_RB_SUBFRAME_ID           => dl_rb_subframe_id(i)                    ,--: out std_logic_vector(3 downto 0);
        DL_RB_SLOT_ID               => dl_rb_slot_id(i)                        ,--: out std_logic_vector(5 downto 0);
        DL_RB_SYMBOL_ID             => dl_rb_symbol_id(i)                      ,--: out std_logic_vector(5 downto 0);
        DL_RB_SECTION_ID            => dl_rb_section_id(i)                     ,--: out std_logic_vector(11 downto 0);
        DL_RB_NUMBER                => open                                    ,--: out std_logic_vector(9 downto 0);
        DL_RE_NUMBER                => dl_re_number(i)                         ,--: out std_logic_vector(11 downto 0);

        DL_RB_VALID                 => dl_rb_valid(i)                          ,--: out std_logic;
        DL_RB_START                 => dl_rb_start(i)                          ,--: out std_logic;
        DL_RB_TICK                  => dl_rb_tick(i)                           ,--: out std_logic;
        DL_RB_LAST                  => dl_rb_last(i)                           ,--: out std_logic;
        DL_RB_DATA_I                => dl_rb_data_i(i)                         ,--: out std_logic_vector(15 downto 0);
        DL_RB_DATA_Q                => dl_rb_data_q(i)                          --: out std_logic_vector(15 downto 0)
    );

    -- Manual mapping
    -- 2t2r
--    xl_cp_link_index_mask(i)        <= "000" & xl_cp_link_index(i)(0 downto 0);
    -- 4t4r
    xl_cp_link_index_mask(i)        <= "00" & xl_cp_link_index(i)(1 downto 0); 

    u_CU_PE_TOP : CU_PE_TOP 
    generic map(
        VENDOR                      => "XILINX", 
        Category                    =>      "A",
        eCPRI_HDR                   =>     TRUE, 
        iFFT_k0_SHIFT               =>     TRUE, 
        iFFT_ZERO_PADDING           =>     TRUE, 
        SCS                         =>       15,
        SECTION_NUM                 =>      128, 
        Max_RB_NUM                  =>      110,  -- 20M LTE 100RB (20Mhz) + NB_IoT 10RB
        iFFT_WIDTH                  =>       11,                             
        SYMBOL_NUM                  =>        7,
        CH_NUM                      =>        4, --2, -- Layer/Path @ module 
        DL_LAYER_NUM                =>        4, 
        UL_RX_NUM                   =>        4, 
        CELL_NUM_eMTC               =>        1,                     
        PATH_NUM                    =>        4, --2,-- Layer/Path @ cell
        Opt_BF_Support              =>        0  -- Mandatory: 0, Optional: 1 
    )
    port map(
        CLK                         => CLK_BUS                                 ,--: in  std_logic;

        nRE                         => dlfe_nRE(i)                             ,--: in  std_logic_vector(11 downto 0);
        nFFT                        => dlfe_nFFT(i)                            ,--: in  std_logic_vector(1 downto 0);

        FRAME_SYNC                  => FRAME_SYNC                              ,--: in  std_logic;

        DL_SYNC_ADVANCE             => dl_sync_advance(i)                      ,--: in  std_logic_vector(21 downto 0);
        UL_SYNC_RETARD              => ul_sync_retard(i)                       ,--: in  std_logic_vector(21 downto 0);

        BFN_NUM_IN                  => FRAME_NUM                               ,--: in  std_logic_vector(11 downto 0); 
        BFN_NUM_OUT                 => open                                    ,--: out std_logic_vector(11 downto 0);

        UP_ONLY_DL_MODE             => dl_uplane_only_en                       ,--: in  std_logic;

        ECPRI_RX_C_CH_IDX           => xl_cp_link_index_mask(i)                ,--: in  std_logic_vector( 3 downto 0);
        ECPRI_RX_C_VALID            => xl_cp_valid(i)                          ,--: in  std_logic;
        ECPRI_RX_C_LAST             => xl_cp_last(i)                           ,--: in  std_logic;
        ECPRI_RX_C_KEEP             => (others => '1')                         ,--: in  std_logic_vector( 3 downto 0);
        ECPRI_RX_C_DATA             => xl_cp_data(i)                           ,--: in  std_logic_vector(31 downto 0);

        RB_CH_IDX                   => dl_rb_channel_id(i)                     ,--: in  std_logic_vector( 3 downto 0);
        RB_FRAME_ID                 => dl_rb_frame_id(i)                       ,--: in  std_logic_vector( 7 downto 0);
        RB_SUBFRAME_ID              => dl_rb_subframe_id(i)                    ,--: in  std_logic_vector( 3 downto 0);
        RB_SLOT_ID                  => dl_rb_slot_id(i)                        ,--: in  std_logic_vector( 5 downto 0);
        RB_SYMBOL_ID                => dl_rb_symbol_id(i)                      ,--: in  std_logic_vector( 5 downto 0);
        RB_SECTION_ID               => dl_rb_section_id(i)                     ,--: in  std_logic_vector(11 downto 0);
        RE_NUMBER                   => dl_re_number(i)                         ,--: in  std_logic_vector(11 downto 0);

        RB_VALID                    => dl_rb_valid(i)                          ,--: in  std_logic;
        RB_START                    => dl_rb_start(i)                          ,--: in  std_logic;
        RB_LAST                     => dl_rb_last(i)                           ,--: in  std_logic;
        RB_TICK                     => dl_rb_tick(i)                           ,--: in  std_logic;
        RB_DATA_I                   => dl_rb_data_i(i)                         ,--: in  std_logic_vector(15 downto 0);
        RB_DATA_Q                   => dl_rb_data_q(i)                         ,--: in  std_logic_vector(15 downto 0);

        SYSTEM_MODE                 => dlfe_system_mode(i)                     ,--: in  std_logic;
        K0                          => dlfe_k0(i)                              ,--: in  std_logic_vector(11 downto 0);
        DL_FRAME_SYNC               => dlfe_frame_sync(i)                      ,--: out std_logic;
        DL_FRAME_INDEX              => dlfe_frame_index(i)                     ,--: out std_logic_vector( 7 downto 0);
        DL_FRAME_STRUCTURE          => open                                    ,--: out std_logic_vector( 7 downto 0);
        DL_MuSu_nLayer              => open                                    ,--: out std_logic_vector( 4 downto 0);
        DL_VALID                    => dlfe_valid(i)                           ,--: out std_logic_vector( 3 downto 0);
        DL_RE_MASK                  => dlfe_re_mask(i)                         ,--: out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);
        DL_BEAMID                   => open                                    ,--: out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*15 - 1 downto 0);
        DL_DATA                     => dlfe_data(i)                            ,--: out std_logic_vector(CH_NUM*32 - 1 downto 0);

        UL_FRAME_SYNC               => rafe_frame_sync(i)                      ,--: out std_logic;
        UL_FILTER_INDEX             => rafe_filter_index(i)                    ,--: out std_logic_vector( 4*2-1 downto 0);
        UL_TIME_OFFSET              => rafe_time_offset(i)                     ,--: out std_logic_vector(16*2-1 downto 0);
        UL_FRAME_STRUCTURE          => rafe_frame_structure(i)                 ,--: out std_logic_vector( 8*2-1 downto 0);
        UL_CPLENGTH                 => rafe_cplength(i)                        ,--: out std_logic_vector(16*2-1 downto 0);
        UL_FREQ_OFFSET              => rafe_freq_offset(i)                     ,--: out std_logic_vector(24*2-1 downto 0);
        UL_START_PRBC               => rafe_start_prbc(i)                      ,--: out std_logic_vector(10*2-1 downto 0);
        UL_NUM_PRBC                 => rafe_num_prbc(i)                        ,--: out std_logic_vector( 8*2-1 downto 0);
        UL_NUM_PSYMBOL              => rafe_num_psymbol(i)                     ,--: out std_logic_vector( 4*2-1 downto 0);
        UL_NUM_RO                   => rafe_num_ro(i)                          ,--: out std_logic_vector( 3*2-1 downto 0);

--        UL_eMTC_FILTER_INDEX        => emtc_filter_index(i)                    ,--:out std_logic_vector( 4*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_TIME_OFFSET         => emtc_time_offset(i)                     ,--:out std_logic_vector(16*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_FRAME_STRUCTURE     => emtc_frame_structure(i)                 ,--:out std_logic_vector( 8*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_CPLENGTH            => emtc_cplength(i)                        ,--:out std_logic_vector(16*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_FREQ_OFFSET         => emtc_freq_offset(i)                     ,--:out std_logic_vector(24*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_START_PRBC          => emtc_start_prbc(i)                      ,--:out std_logic_vector(10*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_NUM_PRBC            => emtc_num_prbc(i)                        ,--:out std_logic_vector( 8*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_NUM_PSYMBOL         => emtc_num_psymbol(i)                     ,--:out std_logic_vector( 4*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
--        UL_eMTC_NUM_RO              => emtc_num_ro(i)                          ,--:out std_logic_vector( 3*CELL_NUM_eMTC*PATH_NUM-1 downto 0);

        SYMBOL_SYNC                 => tdd_sym_sync(i)                         ,--: out std_logic;
        SYMBOL_INDEX                => tdd_sym_index(i)                        ,--: out std_logic_vector(3 downto 0);
        TDD_DL_EN                   => tdd_dl_enable(i)                        ,--: out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);
        TDD_UL_EN                   => tdd_ul_enable(i)                        ,--: out std_logic_vector((Opt_BF_Support*(UL_RX_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);

        BLANKINGPATTERNID_VALID     => blankingpatternid_valid(i)              ,--: out std_logic;
        BLANKINGPATTERNID           => blankingpatternid(i)                     --: out std_logic_vector(7 downto 0)
    );

    u_FREQ_OFFSET_PRACH0 : for a in 7 downto 0 generate
    u_USED : if a < UL_ANT_RX generate
    freq_offset_for_prach0(i)(a)    <= rafe_freq_offset(i)(24*0+23 downto 24*0+0);
    end generate;
    u_UNUSED : if a >= UL_ANT_RX generate
    freq_offset_for_prach0(i)(a)    <= (others => '0');
    end generate;
    end generate;

    freq_offset_for_prach1(i)       <= (others => (others => '0'));

    end generate;

--------------------------------------------------------------------------------
-- UL input conversion
--------------------------------------------------------------------------------

    u_ULFE_IF0 : ULFE_CONVERSION
    port map(
        CLK                         => CLK_BUS                                 ,--: in  std_logic;

        ULFE_RB_FRAME_ID_IN         => ULFE_CC0_FRAME_ID                       ,--: in  std_logic_vector(7 downto 0);
        ULFE_RB_SUBFRAME_ID_IN      => ULFE_CC0_SUBFRAME_ID                    ,--: in  std_logic_vector(3 downto 0);
        ULFE_RB_SLOT_ID_IN          => ULFE_CC0_SLOT_ID                        ,--: in  std_logic_vector(5 downto 0);
        ULFE_RB_SYMBOL_ID_IN        => ULFE_CC0_SYMBOL_ID                      ,--: in  std_logic_vector(5 downto 0);
        ULFE_RB_START_RE_IN         => ULFE_CC0_START_RE                       ,--: in  std_logic_vector(2*16-1 downto 0);

        ULFE_RB_VALID_IN            => ULFE_CC0_VALID                          ,--: in  std_logic_vector(2*1-1 downto 0);
        ULFE_RB_START_IN            => ULFE_CC0_START                          ,--: in  std_logic_vector(2*1-1 downto 0);
        ULFE_RB_LAST_IN             => ULFE_CC0_LAST                           ,--: in  std_logic_vector(2*1-1 downto 0);
        ULFE_RB_DATA_IN             => ULFE_CC0_DATA                           ,--: in  std_logic_vector(2*32-1 downto 0);

        ULFE_RB_FRAME_ID_OUT        => ulfe_rb_frame_id(0)                     ,--: out std_logic_vector(7 downto 0);
        ULFE_RB_SUBFRAME_ID_OUT     => ulfe_rb_subframe_id(0)                  ,--: out std_logic_vector(3 downto 0);
        ULFE_RB_SLOT_ID_OUT         => ulfe_rb_slot_id(0)                      ,--: out std_logic_vector(5 downto 0);
        ULFE_RB_SYMBOL_ID_OUT       => ulfe_rb_symbol_id(0)                    ,--: out std_logic_vector(5 downto 0);

        ULFE_RB_VALID_OUT           => ulfe_rb_valid(0)                        ,--: out std_logic_vector(7 downto 0);
        ULFE_RB_START_OUT           => ulfe_rb_start(0)                        ,--: out std_logic_vector(7 downto 0);
        ULFE_RB_LAST_OUT            => ulfe_rb_last(0)                         ,--: out std_logic_vector(7 downto 0);
        ULFE_RB_DATA_I_OUT          => ulfe_rb_data_i(0)                       ,--: out std_logic_array16(7 downto 0);
        ULFE_RB_DATA_Q_OUT          => ulfe_rb_data_q(0)                        --: out std_logic_array16(7 downto 0)
    );

    u_ULFE_IF1 : ULFE_CONVERSION
    port map(
        CLK                         => CLK_BUS                                 ,--: in  std_logic;

        ULFE_RB_FRAME_ID_IN         => ULFE_CC1_FRAME_ID                       ,--: in  std_logic_vector(7 downto 0);
        ULFE_RB_SUBFRAME_ID_IN      => ULFE_CC1_SUBFRAME_ID                    ,--: in  std_logic_vector(3 downto 0);
        ULFE_RB_SLOT_ID_IN          => ULFE_CC1_SLOT_ID                        ,--: in  std_logic_vector(5 downto 0);
        ULFE_RB_SYMBOL_ID_IN        => ULFE_CC1_SYMBOL_ID                      ,--: in  std_logic_vector(5 downto 0);
        ULFE_RB_START_RE_IN         => ULFE_CC1_START_RE                       ,--: in  std_logic_vector(2*16-1 downto 0);

        ULFE_RB_VALID_IN            => ULFE_CC1_VALID                          ,--: in  std_logic_vector(2*1-1 downto 0);
        ULFE_RB_START_IN            => ULFE_CC1_START                          ,--: in  std_logic_vector(2*1-1 downto 0);
        ULFE_RB_LAST_IN             => ULFE_CC1_LAST                           ,--: in  std_logic_vector(2*1-1 downto 0);
        ULFE_RB_DATA_IN             => ULFE_CC1_DATA                           ,--: in  std_logic_vector(2*32-1 downto 0);

        ULFE_RB_FRAME_ID_OUT        => ulfe_rb_frame_id(1)                     ,--: out std_logic_vector(7 downto 0);
        ULFE_RB_SUBFRAME_ID_OUT     => ulfe_rb_subframe_id(1)                  ,--: out std_logic_vector(3 downto 0);
        ULFE_RB_SLOT_ID_OUT         => ulfe_rb_slot_id(1)                      ,--: out std_logic_vector(5 downto 0);
        ULFE_RB_SYMBOL_ID_OUT       => ulfe_rb_symbol_id(1)                    ,--: out std_logic_vector(5 downto 0);

        ULFE_RB_VALID_OUT           => ulfe_rb_valid(1)                        ,--: out std_logic_vector(7 downto 0);
        ULFE_RB_START_OUT           => ulfe_rb_start(1)                        ,--: out std_logic_vector(7 downto 0);
        ULFE_RB_LAST_OUT            => ulfe_rb_last(1)                         ,--: out std_logic_vector(7 downto 0);
        ULFE_RB_DATA_I_OUT          => ulfe_rb_data_i(1)                       ,--: out std_logic_array16(7 downto 0);
        ULFE_RB_DATA_Q_OUT          => ulfe_rb_data_q(1)                        --: out std_logic_array16(7 downto 0)
    );

    u_RAFE0_IF0 : RAFE_CONVERSION
    port map(
        CLK                         => CLK_BUS                                 ,--: in  std_logic;

        RAFE_RB_FRAME_ID_IN         => RAFE_CC0_FRAME_ID                       ,--: in  std_logic_vector(7 downto 0);
        RAFE_RB_SUBFRAME_ID_IN      => RAFE_CC0_SUBFRAME_ID                    ,--: in  std_logic_vector(3 downto 0);
        RAFE_RB_SLOT_ID_IN          => RAFE_CC0_SLOT_ID                        ,--: in  std_logic_vector(5 downto 0);
        RAFE_RB_SYMBOL_ID_IN        => RAFE_CC0_SYMBOL_ID                      ,--: in  std_logic_vector(5 downto 0);

        RAFE_RB_VALID_IN            => RAFE_CC0_VALID                          ,--: in  std_logic_vector(2*1-1 downto 0);
        RAFE_RB_START_IN            => RAFE_CC0_START                          ,--: in  std_logic_vector(2*1-1 downto 0);
        RAFE_RB_LAST_IN             => RAFE_CC0_LAST                           ,--: in  std_logic_vector(2*1-1 downto 0);
        RAFE_RB_DATA_IN             => RAFE_CC0_DATA                           ,--: in  std_logic_vector(2*32-1 downto 0);

        RAFE_RB_FRAME_ID_OUT        => rafe0_rb_frame_id(0)                    ,--: out std_logic_vector(7 downto 0);
        RAFE_RB_SUBFRAME_ID_OUT     => rafe0_rb_subframe_id(0)                 ,--: out std_logic_vector(3 downto 0);
        RAFE_RB_SLOT_ID_OUT         => rafe0_rb_slot_id(0)                     ,--: out std_logic_vector(5 downto 0);
        RAFE_RB_SYMBOL_ID_OUT       => rafe0_rb_symbol_id(0)                   ,--: out std_logic_vector(5 downto 0);
        RAFE_RB_ANT_ID_OUT          => rafe0_rb_ant_id(0)                      ,--: out std_logic_vector(2 downto 0);

        RAFE_RB_VALID_OUT           => rafe0_rb_valid(0)                       ,--: out std_logic;
        RAFE_RB_START_OUT           => rafe0_rb_start(0)                       ,--: out std_logic;
        RAFE_RB_LAST_OUT            => rafe0_rb_last(0)                        ,--: out std_logic;
        RAFE_RB_DATA_I_OUT          => rafe0_rb_data_i(0)                      ,--: out std_logic_vector(15 downto 0);
        RAFE_RB_DATA_Q_OUT          => rafe0_rb_data_q(0)                       --: out std_logic_vector(15 downto 0)
    );

    u_RAFE0_IF1 : RAFE_CONVERSION
    port map(
        CLK                         => CLK_BUS                                 ,--: in  std_logic;

        RAFE_RB_FRAME_ID_IN         => RAFE_CC1_FRAME_ID                       ,--: in  std_logic_vector(7 downto 0);
        RAFE_RB_SUBFRAME_ID_IN      => RAFE_CC1_SUBFRAME_ID                    ,--: in  std_logic_vector(3 downto 0);
        RAFE_RB_SLOT_ID_IN          => RAFE_CC1_SLOT_ID                        ,--: in  std_logic_vector(5 downto 0);
        RAFE_RB_SYMBOL_ID_IN        => RAFE_CC1_SYMBOL_ID                      ,--: in  std_logic_vector(5 downto 0);

        RAFE_RB_VALID_IN            => RAFE_CC1_VALID                          ,--: in  std_logic_vector(2*1-1 downto 0);
        RAFE_RB_START_IN            => RAFE_CC1_START                          ,--: in  std_logic_vector(2*1-1 downto 0);
        RAFE_RB_LAST_IN             => RAFE_CC1_LAST                           ,--: in  std_logic_vector(2*1-1 downto 0);
        RAFE_RB_DATA_IN             => RAFE_CC1_DATA                           ,--: in  std_logic_vector(2*32-1 downto 0);

        RAFE_RB_FRAME_ID_OUT        => rafe0_rb_frame_id(1)                    ,--: out std_logic_vector(7 downto 0);
        RAFE_RB_SUBFRAME_ID_OUT     => rafe0_rb_subframe_id(1)                 ,--: out std_logic_vector(3 downto 0);
        RAFE_RB_SLOT_ID_OUT         => rafe0_rb_slot_id(1)                     ,--: out std_logic_vector(5 downto 0);
        RAFE_RB_SYMBOL_ID_OUT       => rafe0_rb_symbol_id(1)                   ,--: out std_logic_vector(5 downto 0);
        RAFE_RB_ANT_ID_OUT          => rafe0_rb_ant_id(1)                      ,--: out std_logic_vector(2 downto 0);

        RAFE_RB_VALID_OUT           => rafe0_rb_valid(1)                       ,--: out std_logic;
        RAFE_RB_START_OUT           => rafe0_rb_start(1)                       ,--: out std_logic;
        RAFE_RB_LAST_OUT            => rafe0_rb_last(1)                        ,--: out std_logic;
        RAFE_RB_DATA_I_OUT          => rafe0_rb_data_i(1)                      ,--: out std_logic_vector(15 downto 0);
        RAFE_RB_DATA_Q_OUT          => rafe0_rb_data_q(1)                       --: out std_logic_vector(15 downto 0)
    );

--------------------------------------------------------------------------------
-- Uplink
--------------------------------------------------------------------------------

    u_UL : for i in UL_UNIT-1 downto 0 generate
    u_UP_GEN : UP_GEN
    generic map(
        OFFSET                      => UL_ANT_RX*i                             ,--: natural := 4;
        MAX_CH                      => UL_ANT_PER_UNIT                         ,--: natural := 4;
        MAX_NUM_PORTC               => UL_ANT_RX                                --: natural := 4
    )
    port map(
        CLK                         => CLK_BUS                                 ,--: in  std_logic;
        RST                         => ARESET_TX(0)                            ,--: in  std_logic;

        IGNORE_FRAME_ID             => user_debug0(0)                          ,--: in  std_logic;
        IGNORE_FRAME_ID_PUxCH_RX    => ignore_frame_id_puxch_rx(i)             ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    => ignore_frame_id_puxch_tx(i)             ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_RX   => ignore_frame_id_prach0_rx(i)            ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_TX   => ignore_frame_id_prach0_tx(i)            ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_RX   => ignore_frame_id_prach1_rx(i)            ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_TX   => ignore_frame_id_prach1_tx(i)            ,--: out std_logic_vector(7 downto 0);

        UL_PARAM_ID_EN              => ul_param_id_en                          ,--: in  std_logic_array64(7 downto 0);
        UL_PARAM_ID                 => ul_param_id                             ,--: in  std_logic_array64_array16(7 downto 0);
        UL_PE_INDEX                 => ul_pe_index                             ,--: in  std_logic_array64_array8(7 downto 0);

        UL_COMP_MODE                => ul_comp_mode                            ,--: in  std_logic_array64(7 downto 0);
        UL_IQ_WIDTH                 => ul_iq_width                             ,--: in  std_logic_array64_array4(7 downto 0);
        UL_COMP_METHOD              => ul_comp_method                          ,--: in  std_logic_array64_array4(7 downto 0);
        UL_PRB_PER_SYMBOL           => ul_prb_per_symbol                       ,--: in  std_logic_array64_array10(7 downto 0);
        UL_PRB_PER_MTU              => ul_prb_per_mtu                          ,--: in  std_logic_array64_array10(7 downto 0);

        FREQ_OFFSET_FOR_PRACH0      => freq_offset_for_prach0(i)               ,--: in  std_logic_array24(MAX_NUM_PORTC-1 downto 0);
        FREQ_OFFSET_FOR_PRACH1      => freq_offset_for_prach1(i)               ,--: in  std_logic_array24(MAX_NUM_PORTC-1 downto 0);

        STATUS_TX0_CQ_FSM           => status_tx0_cq_fsm(i)                    ,--: out std_logic_vector(7 downto 0);
        CNT_TX0_CQ_FSM_BUSY         => cnt_tx0_cq_fsm_busy(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_CONV_FULL        => cnt_tx0_cq_conv_full(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL0       => cnt_tx0_cpsec_symbol0(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL1       => cnt_tx0_cpsec_symbol1(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL2       => cnt_tx0_cpsec_symbol2(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL3       => cnt_tx0_cpsec_symbol3(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL4       => cnt_tx0_cpsec_symbol4(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL5       => cnt_tx0_cpsec_symbol5(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL6       => cnt_tx0_cpsec_symbol6(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL7       => cnt_tx0_cpsec_symbol7(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL8       => cnt_tx0_cpsec_symbol8(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL9       => cnt_tx0_cpsec_symbol9(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL10      => cnt_tx0_cpsec_symbol10(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL11      => cnt_tx0_cpsec_symbol11(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL12      => cnt_tx0_cpsec_symbol12(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CPSEC_SYMBOL13      => cnt_tx0_cpsec_symbol13(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL0       => cnt_tx0_uppkt_symbol0(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL1       => cnt_tx0_uppkt_symbol1(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL2       => cnt_tx0_uppkt_symbol2(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL3       => cnt_tx0_uppkt_symbol3(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL4       => cnt_tx0_uppkt_symbol4(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL5       => cnt_tx0_uppkt_symbol5(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL6       => cnt_tx0_uppkt_symbol6(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL7       => cnt_tx0_uppkt_symbol7(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL8       => cnt_tx0_uppkt_symbol8(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL9       => cnt_tx0_uppkt_symbol9(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL10      => cnt_tx0_uppkt_symbol10(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL11      => cnt_tx0_uppkt_symbol11(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL12      => cnt_tx0_uppkt_symbol12(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_UPPKT_SYMBOL13      => cnt_tx0_uppkt_symbol13(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL0     => cnt_tx0_cq_full_symbol0(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL1     => cnt_tx0_cq_full_symbol1(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL2     => cnt_tx0_cq_full_symbol2(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL3     => cnt_tx0_cq_full_symbol3(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL4     => cnt_tx0_cq_full_symbol4(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL5     => cnt_tx0_cq_full_symbol5(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL6     => cnt_tx0_cq_full_symbol6(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL7     => cnt_tx0_cq_full_symbol7(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL8     => cnt_tx0_cq_full_symbol8(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL9     => cnt_tx0_cq_full_symbol9(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL10    => cnt_tx0_cq_full_symbol10(i)             ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL11    => cnt_tx0_cq_full_symbol11(i)             ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL12    => cnt_tx0_cq_full_symbol12(i)             ,--: out std_logic_vector(31 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL13    => cnt_tx0_cq_full_symbol13(i)             ,--: out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL0        => usage_tx0_cq_symbol0(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL1        => usage_tx0_cq_symbol1(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL2        => usage_tx0_cq_symbol2(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL3        => usage_tx0_cq_symbol3(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL4        => usage_tx0_cq_symbol4(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL5        => usage_tx0_cq_symbol5(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL6        => usage_tx0_cq_symbol6(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL7        => usage_tx0_cq_symbol7(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL8        => usage_tx0_cq_symbol8(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL9        => usage_tx0_cq_symbol9(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL10       => usage_tx0_cq_symbol10(i)                ,--: out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL11       => usage_tx0_cq_symbol11(i)                ,--: out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL12       => usage_tx0_cq_symbol12(i)                ,--: out std_logic_vector(31 downto 0);
        USAGE_TX0_CQ_SYMBOL13       => usage_tx0_cq_symbol13(i)                ,--: out std_logic_vector(31 downto 0);

        STATUS_TX1_CQ_FSM           => status_tx1_cq_fsm(i)                    ,--: out std_logic_vector(7 downto 0);
        CNT_TX1_CQ_FSM_BUSY         => cnt_tx1_cq_fsm_busy(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_CONV_FULL        => cnt_tx1_cq_conv_full(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL0       => cnt_tx1_cpsec_symbol0(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL1       => cnt_tx1_cpsec_symbol1(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL2       => cnt_tx1_cpsec_symbol2(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL3       => cnt_tx1_cpsec_symbol3(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL4       => cnt_tx1_cpsec_symbol4(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL5       => cnt_tx1_cpsec_symbol5(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL6       => cnt_tx1_cpsec_symbol6(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL7       => cnt_tx1_cpsec_symbol7(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL8       => cnt_tx1_cpsec_symbol8(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL9       => cnt_tx1_cpsec_symbol9(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL10      => cnt_tx1_cpsec_symbol10(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL11      => cnt_tx1_cpsec_symbol11(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL12      => cnt_tx1_cpsec_symbol12(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CPSEC_SYMBOL13      => cnt_tx1_cpsec_symbol13(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL0       => cnt_tx1_uppkt_symbol0(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL1       => cnt_tx1_uppkt_symbol1(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL2       => cnt_tx1_uppkt_symbol2(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL3       => cnt_tx1_uppkt_symbol3(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL4       => cnt_tx1_uppkt_symbol4(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL5       => cnt_tx1_uppkt_symbol5(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL6       => cnt_tx1_uppkt_symbol6(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL7       => cnt_tx1_uppkt_symbol7(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL8       => cnt_tx1_uppkt_symbol8(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL9       => cnt_tx1_uppkt_symbol9(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL10      => cnt_tx1_uppkt_symbol10(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL11      => cnt_tx1_uppkt_symbol11(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL12      => cnt_tx1_uppkt_symbol12(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_UPPKT_SYMBOL13      => cnt_tx1_uppkt_symbol13(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL0     => cnt_tx1_cq_full_symbol0(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL1     => cnt_tx1_cq_full_symbol1(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL2     => cnt_tx1_cq_full_symbol2(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL3     => cnt_tx1_cq_full_symbol3(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL4     => cnt_tx1_cq_full_symbol4(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL5     => cnt_tx1_cq_full_symbol5(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL6     => cnt_tx1_cq_full_symbol6(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL7     => cnt_tx1_cq_full_symbol7(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL8     => cnt_tx1_cq_full_symbol8(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL9     => cnt_tx1_cq_full_symbol9(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL10    => cnt_tx1_cq_full_symbol10(i)             ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL11    => cnt_tx1_cq_full_symbol11(i)             ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL12    => cnt_tx1_cq_full_symbol12(i)             ,--: out std_logic_vector(31 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL13    => cnt_tx1_cq_full_symbol13(i)             ,--: out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL0        => usage_tx1_cq_symbol0(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL1        => usage_tx1_cq_symbol1(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL2        => usage_tx1_cq_symbol2(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL3        => usage_tx1_cq_symbol3(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL4        => usage_tx1_cq_symbol4(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL5        => usage_tx1_cq_symbol5(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL6        => usage_tx1_cq_symbol6(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL7        => usage_tx1_cq_symbol7(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL8        => usage_tx1_cq_symbol8(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL9        => usage_tx1_cq_symbol9(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL10       => usage_tx1_cq_symbol10(i)                ,--: out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL11       => usage_tx1_cq_symbol11(i)                ,--: out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL12       => usage_tx1_cq_symbol12(i)                ,--: out std_logic_vector(31 downto 0);
        USAGE_TX1_CQ_SYMBOL13       => usage_tx1_cq_symbol13(i)                ,--: out std_logic_vector(31 downto 0);

        STATUS_TX2_CQ_FSM           => status_tx2_cq_fsm(i)                    ,--: out std_logic_vector(7 downto 0);
        CNT_TX2_CQ_FSM_BUSY         => cnt_tx2_cq_fsm_busy(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_CONV_FULL        => cnt_tx2_cq_conv_full(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL0       => cnt_tx2_cpsec_symbol0(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL1       => cnt_tx2_cpsec_symbol1(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL2       => cnt_tx2_cpsec_symbol2(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL3       => cnt_tx2_cpsec_symbol3(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL4       => cnt_tx2_cpsec_symbol4(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL5       => cnt_tx2_cpsec_symbol5(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL6       => cnt_tx2_cpsec_symbol6(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL7       => cnt_tx2_cpsec_symbol7(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL8       => cnt_tx2_cpsec_symbol8(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL9       => cnt_tx2_cpsec_symbol9(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL10      => cnt_tx2_cpsec_symbol10(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL11      => cnt_tx2_cpsec_symbol11(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL12      => cnt_tx2_cpsec_symbol12(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CPSEC_SYMBOL13      => cnt_tx2_cpsec_symbol13(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL0       => cnt_tx2_uppkt_symbol0(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL1       => cnt_tx2_uppkt_symbol1(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL2       => cnt_tx2_uppkt_symbol2(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL3       => cnt_tx2_uppkt_symbol3(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL4       => cnt_tx2_uppkt_symbol4(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL5       => cnt_tx2_uppkt_symbol5(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL6       => cnt_tx2_uppkt_symbol6(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL7       => cnt_tx2_uppkt_symbol7(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL8       => cnt_tx2_uppkt_symbol8(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL9       => cnt_tx2_uppkt_symbol9(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL10      => cnt_tx2_uppkt_symbol10(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL11      => cnt_tx2_uppkt_symbol11(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL12      => cnt_tx2_uppkt_symbol12(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_UPPKT_SYMBOL13      => cnt_tx2_uppkt_symbol13(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL0     => cnt_tx2_cq_full_symbol0(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL1     => cnt_tx2_cq_full_symbol1(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL2     => cnt_tx2_cq_full_symbol2(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL3     => cnt_tx2_cq_full_symbol3(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL4     => cnt_tx2_cq_full_symbol4(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL5     => cnt_tx2_cq_full_symbol5(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL6     => cnt_tx2_cq_full_symbol6(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL7     => cnt_tx2_cq_full_symbol7(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL8     => cnt_tx2_cq_full_symbol8(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL9     => cnt_tx2_cq_full_symbol9(i)              ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL10    => cnt_tx2_cq_full_symbol10(i)             ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL11    => cnt_tx2_cq_full_symbol11(i)             ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL12    => cnt_tx2_cq_full_symbol12(i)             ,--: out std_logic_vector(31 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL13    => cnt_tx2_cq_full_symbol13(i)             ,--: out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL0        => usage_tx2_cq_symbol0(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL1        => usage_tx2_cq_symbol1(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL2        => usage_tx2_cq_symbol2(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL3        => usage_tx2_cq_symbol3(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL4        => usage_tx2_cq_symbol4(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL5        => usage_tx2_cq_symbol5(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL6        => usage_tx2_cq_symbol6(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL7        => usage_tx2_cq_symbol7(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL8        => usage_tx2_cq_symbol8(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL9        => usage_tx2_cq_symbol9(i)                 ,--: out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL10       => usage_tx2_cq_symbol10(i)                ,--: out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL11       => usage_tx2_cq_symbol11(i)                ,--: out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL12       => usage_tx2_cq_symbol12(i)                ,--: out std_logic_vector(31 downto 0);
        USAGE_TX2_CQ_SYMBOL13       => usage_tx2_cq_symbol13(i)                ,--: out std_logic_vector(31 downto 0);

        C_PLANE_VALID               => xl_cp_valid(i)                          ,--: in  std_logic;
        C_PLANE_LAST                => xl_cp_last(i)                           ,--: in  std_logic;
        C_PLANE_DATA                => xl_cp_data(i)                           ,--: in  std_logic_vector(31 downto 0);
        C_PLANE_DATA_INDEX          => xl_cp_data_index(i)                     ,--: in  std_logic_vector(2 downto 0);
        C_PLANE_LINK_INDEX          => xl_cp_link_index_mask(i)                ,--: in  std_logic_vector(3 downto 0);

        ULFE_FRAME_ID               => ulfe_rb_frame_id(i)                     ,--: in  std_logic_vector(7 downto 0);
        ULFE_SUBFRAME_ID            => ulfe_rb_subframe_id(i)                  ,--: in  std_logic_vector(3 downto 0);
        ULFE_SLOT_ID                => ulfe_rb_slot_id(i)                      ,--: in  std_logic_vector(5 downto 0);
        ULFE_SYMBOL_ID              => ulfe_rb_symbol_id(i)                    ,--: in  std_logic_vector(5 downto 0);

        ULFE_VALID                  => ulfe_rb_valid(i)                        ,--: in  std_logic_vector(7 downto 0);
        ULFE_START                  => ulfe_rb_start(i)                        ,--: in  std_logic_vector(7 downto 0);
        ULFE_LAST                   => ulfe_rb_last(i)                         ,--: in  std_logic_vector(7 downto 0);
        ULFE_DATA_I                 => ulfe_rb_data_i(i)                       ,--: in  std_logic_array16(7 downto 0);
        ULFE_DATA_Q                 => ulfe_rb_data_q(i)                       ,--: in  std_logic_array16(7 downto 0);

        RAFE0_FRAME_ID              => rafe0_rb_frame_id(i)                    ,--: in  std_logic_vector(7 downto 0);
        RAFE0_SUBFRAME_ID           => rafe0_rb_subframe_id(i)                 ,--: in  std_logic_vector(3 downto 0);
        RAFE0_SLOT_ID               => rafe0_rb_slot_id(i)                     ,--: in  std_logic_vector(5 downto 0);
        RAFE0_SYMBOL_ID             => rafe0_rb_symbol_id(i)                   ,--: in  std_logic_vector(5 downto 0);
        RAFE0_ANT_ID                => rafe0_rb_ant_id(i)                      ,--: in  std_logic_vector(2 downto 0);

        RAFE0_VALID                 => rafe0_rb_valid(i)                       ,--: in  std_logic;
        RAFE0_START                 => rafe0_rb_start(i)                       ,--: in  std_logic;
        RAFE0_LAST                  => rafe0_rb_last(i)                        ,--: in  std_logic;
        RAFE0_DATA_I                => rafe0_rb_data_i(i)                      ,--: in  std_logic_vector(15 downto 0);
        RAFE0_DATA_Q                => rafe0_rb_data_q(i)                      ,--: in  std_logic_vector(15 downto 0);

        RAFE1_FRAME_ID              => (others => '0')                         ,--: in  std_logic_vector(7 downto 0);
        RAFE1_SUBFRAME_ID           => (others => '0')                         ,--: in  std_logic_vector(3 downto 0);
        RAFE1_SLOT_ID               => (others => '0')                         ,--: in  std_logic_vector(5 downto 0);
        RAFE1_SYMBOL_ID             => (others => '0')                         ,--: in  std_logic_vector(5 downto 0);
        RAFE1_ANT_ID                => (others => '0')                         ,--: in  std_logic_vector(2 downto 0);

        RAFE1_VALID                 => '0'                                     ,--: in  std_logic;
        RAFE1_START                 => '0'                                     ,--: in  std_logic;
        RAFE1_LAST                  => '0'                                     ,--: in  std_logic;
        RAFE1_DATA_I                => (others => '0')                         ,--: in  std_logic_vector(15 downto 0);
        RAFE1_DATA_Q                => (others => '0')                         ,--: in  std_logic_vector(15 downto 0);

        TX0_RB_INIT                 => tx0_rb_init(i)                          ,--: out std_logic;
        TX0_RB_PATH                 => tx0_rb_path(i)                          ,--: out std_logic_vector(2 downto 0);
        TX0_RB_PE_INDEX             => tx0_rb_pe_index(i)                      ,--: out std_logic_vector(2 downto 0);
        TX0_RB_eAxC_ID              => tx0_rb_eaxc_id(i)                       ,--: out std_logic_vector(15 downto 0);
        TX0_RB_SEQUENCE_ID          => tx0_rb_sequence_id(i)                   ,--: out std_logic_vector(15 downto 0);
        TX0_RB_HEADER_APP           => tx0_rb_header_app(i)                    ,--: out std_logic_vector(31 downto 0);
        TX0_RB_HEADER_APP_ACK       => tx0_rb_header_app_ack(i)                ,--: in  std_logic;
        TX0_RB_HEADER_SEC           => tx0_rb_header_sec(i)                    ,--: out std_logic_vector(31 downto 0);
        TX0_RB_HEADER_SEC_ACK       => tx0_rb_header_sec_ack(i)                ,--: in  std_logic;
        TX0_RB_COMP_HDR             => tx0_rb_comp_hdr(i)                      ,--: out std_logic_vector(8 downto 0);
        TX0_RB_VALID                => tx0_rb_valid(i)                         ,--: out std_logic;
        TX0_RB_TICK                 => tx0_rb_tick(i)                          ,--: out std_logic;
        TX0_RB_DATA_I               => tx0_rb_data_i(i)                        ,--: out std_logic_vector(15 downto 0);
        TX0_RB_DATA_Q               => tx0_rb_data_q(i)                        ,--: out std_logic_vector(15 downto 0);
        TX0_RB_USER                 => tx0_rb_user(i)                          ,--: out std_logic_vector(15 downto 0);

        TX1_RB_INIT                 => tx1_rb_init(i)                          ,--: out std_logic;
        TX1_RB_PATH                 => tx1_rb_path(i)                          ,--: out std_logic_vector(2 downto 0);
        TX1_RB_PE_INDEX             => tx1_rb_pe_index(i)                      ,--: out std_logic_vector(2 downto 0);
        TX1_RB_eAxC_ID              => tx1_rb_eaxc_id(i)                       ,--: out std_logic_vector(15 downto 0);
        TX1_RB_SEQUENCE_ID          => tx1_rb_sequence_id(i)                   ,--: out std_logic_vector(15 downto 0);
        TX1_RB_HEADER_APP           => tx1_rb_header_app(i)                    ,--: out std_logic_vector(31 downto 0);
        TX1_RB_HEADER_APP_ACK       => tx1_rb_header_app_ack(i)                ,--: in  std_logic;
        TX1_RB_HEADER_SEC           => tx1_rb_header_sec(i)                    ,--: out std_logic_vector(31 downto 0);
        TX1_RB_HEADER_SEC_ACK       => tx1_rb_header_sec_ack(i)                ,--: in  std_logic;
        TX1_RB_COMP_HDR             => tx1_rb_comp_hdr(i)                      ,--: out std_logic_vector(8 downto 0);
        TX1_RB_VALID                => tx1_rb_valid(i)                         ,--: out std_logic;
        TX1_RB_TICK                 => tx1_rb_tick(i)                          ,--: out std_logic;
        TX1_RB_DATA_I               => tx1_rb_data_i(i)                        ,--: out std_logic_vector(15 downto 0);
        TX1_RB_DATA_Q               => tx1_rb_data_q(i)                        ,--: out std_logic_vector(15 downto 0);
        TX1_RB_USER                 => tx1_rb_user(i)                          ,--: out std_logic_vector(15 downto 0);

        TX2_RB_INIT                 => open                                    ,--: out std_logic;
        TX2_RB_PATH                 => open                                    ,--: out std_logic_vector(2 downto 0);
        TX2_RB_PE_INDEX             => open                                    ,--: out std_logic_vector(2 downto 0);
        TX2_RB_eAxC_ID              => open                                    ,--: out std_logic_vector(15 downto 0);
        TX2_RB_SEQUENCE_ID          => open                                    ,--: out std_logic_vector(15 downto 0);
        TX2_RB_HEADER_APP           => open                                    ,--: out std_logic_vector(31 downto 0);
        TX2_RB_HEADER_APP_ACK       => '0'                                     ,--: in  std_logic;
        TX2_RB_HEADER_SEC           => open                                    ,--: out std_logic_vector(31 downto 0);
        TX2_RB_HEADER_SEC_ACK       => '0'                                     ,--: in  std_logic;
        TX2_RB_COMP_HDR             => open                                    ,--: out std_logic_vector(8 downto 0);
        TX2_RB_VALID                => open                                    ,--: out std_logic;
        TX2_RB_TICK                 => open                                    ,--: out std_logic;
        TX2_RB_DATA_I               => open                                    ,--: out std_logic_vector(15 downto 0);
        TX2_RB_DATA_Q               => open                                    ,--: out std_logic_vector(15 downto 0);
        TX2_RB_USER                 => open                                     --: out std_logic_vector(15 downto 0);

    );

    map0_exp_offset(i)(0)           <= ul_comp_exp_offset(0)(i*UL_ANT_RX+0);
    map0_exp_offset(i)(1)           <= ul_comp_exp_offset(0)(i*UL_ANT_RX+1);
    map0_exp_offset(i)(2)           <= ul_comp_exp_offset(0)(i*UL_ANT_RX+2);
    map0_exp_offset(i)(3)           <= ul_comp_exp_offset(0)(i*UL_ANT_RX+3);
    map0_exp_offset(i)(4)           <= (others => '0');
    map0_exp_offset(i)(5)           <= (others => '0');
    map0_exp_offset(i)(6)           <= (others => '0');
    map0_exp_offset(i)(7)           <= (others => '0');
    map0_gain_offset(i)(0)          <= ul_comp_gain_offset(0)(i*UL_ANT_RX+0);
    map0_gain_offset(i)(1)          <= ul_comp_gain_offset(0)(i*UL_ANT_RX+1);
    map0_gain_offset(i)(2)          <= ul_comp_gain_offset(0)(i*UL_ANT_RX+2);
    map0_gain_offset(i)(3)          <= ul_comp_gain_offset(0)(i*UL_ANT_RX+3);
    map0_gain_offset(i)(4)          <= (others => '0');
    map0_gain_offset(i)(5)          <= (others => '0');
    map0_gain_offset(i)(6)          <= (others => '0');
    map0_gain_offset(i)(7)          <= (others => '0');
    map0_scale_gain_offset(i)(0)    <= ul_comp_scale_gain_offset(0)(i*UL_ANT_RX+0);
    map0_scale_gain_offset(i)(1)    <= ul_comp_scale_gain_offset(0)(i*UL_ANT_RX+1);
    map0_scale_gain_offset(i)(2)    <= ul_comp_scale_gain_offset(0)(i*UL_ANT_RX+2);
    map0_scale_gain_offset(i)(3)    <= ul_comp_scale_gain_offset(0)(i*UL_ANT_RX+3);
    map0_scale_gain_offset(i)(4)    <= (others => '0');
    map0_scale_gain_offset(i)(5)    <= (others => '0');
    map0_scale_gain_offset(i)(6)    <= (others => '0');
    map0_scale_gain_offset(i)(7)    <= (others => '0');

    u_UL_ORAN_UP_TX0 : ORAN_UP_TX
    port map(
        CLK                         => CLK_MAC_TX                              ,--: in  std_logic;
        RST                         => sreset_inter_tx(0)                      ,--: in  std_logic;

        CLK_UP                      => CLK_BUS                                 ,--: in  std_logic;

        PARAM_RU_MAC                => param_ru_mac                            ,--: in  std_logic_array48(7 downto 0);
        PARAM_PORT_INDEX            => param_port_index                        ,--: in  std_logic_array3(7 downto 0);
        PARAM_DU_MAC                => param_du_mac                            ,--: in  std_logic_array48(7 downto 0);
        PARAM_VLAN0_EN              => param_vlan0_en                          ,--: in  std_logic_vector(7 downto 0);
        PARAM_VLAN0_VID             => param_vlan0_vid                         ,--: in  std_logic_array12(7 downto 0);
        PARAM_VLAN1_EN              => param_vlan1_en                          ,--: in  std_logic_vector(7 downto 0);
        PARAM_VLAN1_VID             => param_vlan1_vid                         ,--: in  std_logic_array12(7 downto 0);

        TX_COMP_EXP_OFFSET          => map0_exp_offset(i)                      ,--: in  std_logic_array5(7 downto 0);
        TX_COMP_GAIN_OFFSET         => map0_gain_offset(i)                     ,--: in  std_logic_array11(7 downto 0);
        TX_COMP_SCALE_GAIN_OFFSET   => map0_scale_gain_offset(i)               ,--: in  std_logic_array4(7 downto 0);

        USAGE_DATA_BUFFER           => usage_tx0_up_buffer(i)                  ,--: out std_logic_vector(31 downto 0);

        CNT_TX                      => cnt_tx0(i)                              ,--: out std_logic_vector(31 downto 0);
        CNT_LOST                    => cnt_tx0_lost(i)                         ,--: out std_logic_vector(31 downto 0);

        RB_INIT                     => tx0_rb_init(i)                          ,--: in  std_logic;
        RB_PATH                     => tx0_rb_path(i)                          ,--: in  std_logic_array3(7 downto 0);
        RB_PE_INDEX                 => tx0_rb_pe_index(i)                      ,--: in  std_logic_vector(2 downto 0);
        RB_eAxC_ID                  => tx0_rb_eaxc_id(i)                       ,--: in  std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              => tx0_rb_sequence_id(i)                   ,--: in  std_logic_vector(15 downto 0);
        RB_HEADER_APP               => tx0_rb_header_app(i)                    ,--: in  std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           => tx0_rb_header_app_ack(i)                ,--: out std_logic;
        RB_HEADER_SEC               => tx0_rb_header_sec(i)                    ,--: in  std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           => tx0_rb_header_sec_ack(i)                ,--: out std_logic;

        RB_COMP_HDR                 => tx0_rb_comp_hdr(i)                      ,--: in  std_logic_vector(8 downto 0);
                                                                                  
        RB_VALID                    => tx0_rb_valid(i)                         ,--: in  std_logic;
        RB_START                    => '0'                                     ,--: in  std_logic;
        RB_TICK                     => tx0_rb_tick(i)                          ,--: in  std_logic;
        RB_LAST                     => '0'                                     ,--: in  std_logic;
        RB_DATA_I                   => tx0_rb_data_i(i)                        ,--: in  std_logic_vector(15 downto 0);
        RB_DATA_Q                   => tx0_rb_data_q(i)                        ,--: in  std_logic_vector(15 downto 0);
        RB_USER                     => tx0_rb_user(i)                          ,--: in  std_logic_vector(15 downto 0)

        PE_TRANSMITTED              => tx0_pe_transmitted(i)                   ,--: out std_logic_vector(MAX_RU_ELEMENT-1 downto 0);

        UP64_READY                  => tx0_up64_ready(i)                       ,--: in  std_logic;
        UP64_VALID                  => tx0_up64_valid(i)                       ,--: out std_logic;
        UP64_LAST                   => tx0_up64_last(i)                        ,--: out std_logic;
        UP64_KEEP                   => tx0_up64_keep(i)                        ,--: out std_logic_vector(7 downto 0);
        UP64_DATA                   => tx0_up64_data(i)                         --: out std_logic_vector(63 downto 0)
    );

    map1_exp_offset(i)(0)           <= ul_comp_exp_offset(1)(i*UL_ANT_RX+0);
    map1_exp_offset(i)(1)           <= ul_comp_exp_offset(1)(i*UL_ANT_RX+1);
    map1_exp_offset(i)(2)           <= ul_comp_exp_offset(1)(i*UL_ANT_RX+2);
    map1_exp_offset(i)(3)           <= ul_comp_exp_offset(1)(i*UL_ANT_RX+3);
    map1_exp_offset(i)(4)           <= (others => '0');
    map1_exp_offset(i)(5)           <= (others => '0');
    map1_exp_offset(i)(6)           <= (others => '0');
    map1_exp_offset(i)(7)           <= (others => '0');
    map1_gain_offset(i)(0)          <= ul_comp_gain_offset(1)(i*UL_ANT_RX+0);
    map1_gain_offset(i)(1)          <= ul_comp_gain_offset(1)(i*UL_ANT_RX+1);
    map1_gain_offset(i)(2)          <= ul_comp_gain_offset(1)(i*UL_ANT_RX+2);
    map1_gain_offset(i)(3)          <= ul_comp_gain_offset(1)(i*UL_ANT_RX+3);
    map1_gain_offset(i)(4)          <= (others => '0');
    map1_gain_offset(i)(5)          <= (others => '0');
    map1_gain_offset(i)(6)          <= (others => '0');
    map1_gain_offset(i)(7)          <= (others => '0');
    map1_scale_gain_offset(i)(0)    <= ul_comp_scale_gain_offset(1)(i*UL_ANT_RX+0);
    map1_scale_gain_offset(i)(1)    <= ul_comp_scale_gain_offset(1)(i*UL_ANT_RX+1);
    map1_scale_gain_offset(i)(2)    <= ul_comp_scale_gain_offset(1)(i*UL_ANT_RX+2);
    map1_scale_gain_offset(i)(3)    <= ul_comp_scale_gain_offset(1)(i*UL_ANT_RX+3);
    map1_scale_gain_offset(i)(4)    <= (others => '0');
    map1_scale_gain_offset(i)(5)    <= (others => '0');
    map1_scale_gain_offset(i)(6)    <= (others => '0');
    map1_scale_gain_offset(i)(7)    <= (others => '0');

    u_UL_ORAN_UP_TX1 : ORAN_UP_TX
    port map(
        CLK                         => CLK_MAC_TX                              ,--: in  std_logic;
        RST                         => sreset_inter_tx(0)                      ,--: in  std_logic;

        CLK_UP                      => CLK_BUS                                 ,--: in  std_logic;

        PARAM_RU_MAC                => param_ru_mac                            ,--: in  std_logic_array48(7 downto 0);
        PARAM_PORT_INDEX            => param_port_index                        ,--: in  std_logic_array3(7 downto 0);
        PARAM_DU_MAC                => param_du_mac                            ,--: in  std_logic_array48(7 downto 0);
        PARAM_VLAN0_EN              => param_vlan0_en                          ,--: in  std_logic_vector(7 downto 0);
        PARAM_VLAN0_VID             => param_vlan0_vid                         ,--: in  std_logic_array12(7 downto 0);
        PARAM_VLAN1_EN              => param_vlan1_en                          ,--: in  std_logic_vector(7 downto 0);
        PARAM_VLAN1_VID             => param_vlan1_vid                         ,--: in  std_logic_array12(7 downto 0);

        TX_COMP_EXP_OFFSET          => map1_exp_offset(i)                      ,--: in  std_logic_array5(7 downto 0);
        TX_COMP_GAIN_OFFSET         => map1_gain_offset(i)                     ,--: in  std_logic_array11(7 downto 0);
        TX_COMP_SCALE_GAIN_OFFSET   => map1_scale_gain_offset(i)               ,--: in  std_logic_array4(7 downto 0);

        USAGE_DATA_BUFFER           => usage_tx1_up_buffer(i)                  ,--: out std_logic_vector(31 downto 0);

        CNT_TX                      => cnt_tx1(i)                              ,--: out std_logic_vector(31 downto 0);
        CNT_LOST                    => cnt_tx1_lost(i)                         ,--: out std_logic_vector(31 downto 0);

        RB_INIT                     => tx1_rb_init(i)                          ,--: in  std_logic;
        RB_PATH                     => tx1_rb_path(i)                          ,--: in  std_logic_array3(7 downto 0);
        RB_PE_INDEX                 => tx1_rb_pe_index(i)                      ,--: in  std_logic_vector(2 downto 0);
        RB_eAxC_ID                  => tx1_rb_eaxc_id(i)                       ,--: in  std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              => tx1_rb_sequence_id(i)                   ,--: in  std_logic_vector(15 downto 0);
        RB_HEADER_APP               => tx1_rb_header_app(i)                    ,--: in  std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           => tx1_rb_header_app_ack(i)                ,--: out std_logic;
        RB_HEADER_SEC               => tx1_rb_header_sec(i)                    ,--: in  std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           => tx1_rb_header_sec_ack(i)                ,--: out std_logic;

        RB_COMP_HDR                 => tx1_rb_comp_hdr(i)                      ,--: in  std_logic_vector(8 downto 0);

        RB_VALID                    => tx1_rb_valid(i)                         ,--: in  std_logic;
        RB_START                    => '0'                                     ,--: in  std_logic;
        RB_TICK                     => tx1_rb_tick(i)                          ,--: in  std_logic;
        RB_LAST                     => '0'                                     ,--: in  std_logic;
        RB_DATA_I                   => tx1_rb_data_i(i)                        ,--: in  std_logic_vector(15 downto 0);
        RB_DATA_Q                   => tx1_rb_data_q(i)                        ,--: in  std_logic_vector(15 downto 0);
        RB_USER                     => tx1_rb_user(i)                          ,--: in  std_logic_vector(15 downto 0);

        PE_TRANSMITTED              => tx1_pe_transmitted(i)                   ,--: out std_logic_vector(MAX_RU_ELEMENT-1 downto 0);

        UP64_READY                  => tx1_up64_ready(i)                       ,--: in  std_logic;
        UP64_VALID                  => tx1_up64_valid(i)                       ,--: out std_logic;
        UP64_LAST                   => tx1_up64_last(i)                        ,--: out std_logic;
        UP64_KEEP                   => tx1_up64_keep(i)                        ,--: out std_logic_vector(7 downto 0);
        UP64_DATA                   => tx1_up64_data(i)                         --: out std_logic_vector(63 downto 0)
    );

    u_TX_MUX : ORAN_TX_MUX
    generic map(
        TX_UNIT                     => NUM_MUX_TX                               --: natural := 6
    )
    port map(
        CLK                         => CLK_MAC_TX                              ,--: in  std_logic;
        RST                         => sreset_inter_tx(0)                      ,--: in  std_logic;

        IN0_READY                   => tx0_up64_ready(i)                       ,--: out std_logic;
        IN0_VALID                   => tx0_up64_valid(i)                       ,--: in  std_logic;
        IN0_LAST                    => tx0_up64_last(i)                        ,--: in  std_logic;
        IN0_KEEP                    => tx0_up64_keep(i)                        ,--: in  std_logic_vector(7 downto 0);
        IN0_DATA                    => tx0_up64_data(i)                        ,--: in  std_logic_vector(63 downto 0);

        IN1_READY                   => tx1_up64_ready(i)                       ,--: out std_logic;
        IN1_VALID                   => tx1_up64_valid(i)                       ,--: in  std_logic;
        IN1_LAST                    => tx1_up64_last(i)                        ,--: in  std_logic;
        IN1_KEEP                    => tx1_up64_keep(i)                        ,--: in  std_logic_vector(7 downto 0);
        IN1_DATA                    => tx1_up64_data(i)                        ,--: in  std_logic_vector(63 downto 0);

        IN2_READY                   => open                                    ,--: out std_logic;
        IN2_VALID                   => '0'                                     ,--: in  std_logic;
        IN2_LAST                    => '0'                                     ,--: in  std_logic;
        IN2_KEEP                    => (others => '0')                         ,--: in  std_logic_vector(7 downto 0);
        IN2_DATA                    => (others => '0')                         ,--: in  std_logic_vector(63 downto 0);

        IN3_READY                   => open                                    ,--: out std_logic;
        IN3_VALID                   => '0'                                     ,--: in  std_logic;
        IN3_LAST                    => '0'                                     ,--: in  std_logic;
        IN3_KEEP                    => (others => '0')                         ,--: in  std_logic_vector(7 downto 0);
        IN3_DATA                    => (others => '0')                         ,--: in  std_logic_vector(63 downto 0);

        IN4_READY                   => open                                    ,--: out std_logic;
        IN4_VALID                   => '0'                                     ,--: in  std_logic;
        IN4_LAST                    => '0'                                     ,--: in  std_logic;
        IN4_KEEP                    => (others => '0')                         ,--: in  std_logic_vector(7 downto 0);
        IN4_DATA                    => (others => '0')                         ,--: in  std_logic_vector(63 downto 0);

        IN5_READY                   => open                                    ,--: out std_logic;
        IN5_VALID                   => '0'                                     ,--: in  std_logic;
        IN5_LAST                    => '0'                                     ,--: in  std_logic;
        IN5_KEEP                    => (others => '0')                         ,--: in  std_logic_vector(7 downto 0);
        IN5_DATA                    => (others => '0')                         ,--: in  std_logic_vector(63 downto 0);

        IN6_READY                   => open                                    ,--: out std_logic;
        IN6_VALID                   => '0'                                     ,--: in  std_logic;
        IN6_LAST                    => '0'                                     ,--: in  std_logic;
        IN6_KEEP                    => (others => '0')                         ,--: in  std_logic_vector(7 downto 0);
        IN6_DATA                    => (others => '0')                         ,--: in  std_logic_vector(63 downto 0);

        IN7_READY                   => open                                    ,--: out std_logic;
        IN7_VALID                   => '0'                                     ,--: in  std_logic;
        IN7_LAST                    => '0'                                     ,--: in  std_logic;
        IN7_KEEP                    => (others => '0')                         ,--: in  std_logic_vector(7 downto 0);
        IN7_DATA                    => (others => '0')                         ,--: in  std_logic_vector(63 downto 0);

        OUT_READY                   => mac_ic_tx_ready(i)                      ,--: in  std_logic;
        OUT_VALID                   => mac_ic_tx_valid(i)                      ,--: out std_logic;
        OUT_LAST                    => mac_ic_tx_last(i)                       ,--: out std_logic;
        OUT_KEEP                    => mac_ic_tx_keep(i)                       ,--: out std_logic_vector(7 downto 0);
        OUT_DATA                    => mac_ic_tx_data(i)                        --: out std_logic_vector(63 downto 0)
    );
    end generate;

--------------------------------------------------------------------------------
-- Rx-window-stat/tx-stat
--------------------------------------------------------------------------------

    u_MEASUREMENT : for i in MAX_RU_ELEMENT-1 downto 0 generate
    u_MEASUREMENT : MEASUREMENT
    generic map(
        NUM_TX                      => UL_UNIT*NUM_MUX_TX                       --: natural := 1
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => RST_CPUIF                               ,--: in  std_logic;

        CLK_245p76MHz               => CLK_BUS                                 ,--: in  std_logic;

        N_TA_OFFSET                 => N_TA_OFFSET_CC0                         ,--: in  std_logic_vector(15 downto 0);

        REF_10msec                  => FRAME_SYNC                              ,--: in  std_logic;
        REF_SFN                     => FRAME_NUM(7 downto 0)                   ,--: in  std_logic_vector(7 downto 0);

        CAPTURE_PERIOD              => capture_period(i)                       ,--: in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            => t2a_max_dl_cp_rx(i)                     ,--: in  std_logic_array22(4 downto 0);
        T2A_MIN_DL_CP_RX            => t2a_min_dl_cp_rx(i)                     ,--: in  std_logic_array22(4 downto 0);
        T2A_MAX_DL_UP_RX            => t2a_max_dl_up_rx(i)                     ,--: in  std_logic_array22(4 downto 0);
        T2A_MIN_DL_UP_RX            => t2a_min_dl_up_rx(i)                     ,--: in  std_logic_array22(4 downto 0);
        T2A_MAX_UL_CP_RX            => t2a_max_ul_cp_rx(i)                     ,--: in  std_logic_array22(4 downto 0);
        T2A_MIN_UL_CP_RX            => t2a_min_ul_cp_rx(i)                     ,--: in  std_logic_array22(4 downto 0);

        STAT_CNT_CLEAR              => stat_cnt_clear(i)                       ,--: in  std_logic;

        DL_CP_RX_ON_TIME            => dl_cp_rx_on_time(i)                     ,--: out std_logic_array64(4 downto 0);
        DL_CP_RX_EARLY              => dl_cp_rx_early(i)                       ,--: out std_logic_array64(4 downto 0);
        DL_CP_RX_LATE               => dl_cp_rx_late(i)                        ,--: out std_logic_array64(4 downto 0);
        DL_CP_RX_NDM                => dl_cp_rx_ndm(i)                         ,--: out std_logic_array64(4 downto 0);

        DL_UP_RX_ON_TIME            => dl_up_rx_on_time(i)                     ,--: out std_logic_array64(4 downto 0);
        DL_UP_RX_EARLY              => dl_up_rx_early(i)                       ,--: out std_logic_array64(4 downto 0);
        DL_UP_RX_LATE               => dl_up_rx_late(i)                        ,--: out std_logic_array64(4 downto 0);
        DL_UP_RX_NDM                => dl_up_rx_ndm(i)                         ,--: out std_logic_array64(4 downto 0);

        UL_CP_RX_ON_TIME            => ul_cp_rx_on_time(i)                     ,--: out std_logic_array64(4 downto 0);
        UL_CP_RX_EARLY              => ul_cp_rx_early(i)                       ,--: out std_logic_array64(4 downto 0);
        UL_CP_RX_LATE               => ul_cp_rx_late(i)                        ,--: out std_logic_array64(4 downto 0);
        UL_CP_RX_NDM                => ul_cp_rx_ndm(i)                         ,--: out std_logic_array64(4 downto 0);

        UL_CP_TX_TOTAL              => ul_cp_tx_total(i)                       ,--: out std_logic_vector(63 downto 0);
        UL_UP_TX_TOTAL              => ul_up_tx_total(i)                       ,--: out std_logic_vector(63 downto 0);

        RX_PACKET_CLK               => CLK_MAC_RX                              ,--: in  std_logic;
        UPDATE_EN_OUT               => rx_window_update_en(i),
        RX_PACKET_IS_CP_DL          => packet_is_cp_dl(i)                      ,--: in  std_logic;
        RX_PACKET_IS_CP_UL          => packet_is_cp_ul(i)                      ,--: in  std_logic;
        RX_PACKET_IS_UP_DL          => packet_is_up_dl(i)                      ,--: in  std_logic;
        RX_PACKET_IS_NDM            => packet_is_ndm                           ,--: in  std_logic;
        RX_PACKET_SCS               => packet_scs                              ,--: in  std_logic_vector(3 downto 0);
        RX_PACKET_FRAME_ID          => packet_frame_id                         ,--: in  std_logic_vector(7 downto 0);
        RX_PACKET_SUBFRAME_ID       => packet_subframe_id                      ,--: in  std_logic_vector(3 downto 0);
        RX_PACKET_SLOT_ID           => packet_slot_id                          ,--: in  std_logic_vector(5 downto 0);
        RX_PACKET_SYMBOL_ID         => packet_symbol_id                        ,--: in  std_logic_vector(5 downto 0);

        TX_PACKET_CLK               => CLK_BUS                                 ,--: in  std_logic;

        TX0_PACKET_EXIST            => tx0_pe_transmitted(0)(i)                ,--: in  std_logic;
        TX1_PACKET_EXIST            => tx1_pe_transmitted(0)(i)                ,--: in  std_logic;
        TX2_PACKET_EXIST            => tx0_pe_transmitted(1)(i)                ,--: in  std_logic;
        TX3_PACKET_EXIST            => tx1_pe_transmitted(1)(i)                ,--: in  std_logic;
        TX4_PACKET_EXIST            => '0'                                     ,--: in  std_logic;
        TX5_PACKET_EXIST            => '0'                                     ,--: in  std_logic;
        TX6_PACKET_EXIST            => '0'                                     ,--: in  std_logic;
        TX7_PACKET_EXIST            => '0'                                     ,--: in  std_logic;
        TX8_PACKET_EXIST            => '0'                                     ,--: in  std_logic;
        TX9_PACKET_EXIST            => '0'                                     ,--: in  std_logic;
        TX10_PACKET_EXIST           => '0'                                     ,--: in  std_logic;
        TX11_PACKET_EXIST           => '0'                                     ,--: in  std_logic;
        TX12_PACKET_EXIST           => '0'                                     ,--: in  std_logic;
        TX13_PACKET_EXIST           => '0'                                     ,--: in  std_logic;
        TX14_PACKET_EXIST           => '0'                                     ,--: in  std_logic;
        TX15_PACKET_EXIST           => '0'                                     ,--: in  std_logic;
        TX16_PACKET_EXIST           => '0'                                     ,--: in  std_logic;
        TX17_PACKET_EXIST           => '0'                                     ,--: in  std_logic;
        TX18_PACKET_EXIST           => '0'                                     ,--: in  std_logic;
        TX19_PACKET_EXIST           => '0'                                      --: in  std_logic
    );

    dl_cp_scs0_rx_on_time(i)        <= dl_cp_rx_on_time(i)(0);
    dl_cp_scs1_rx_on_time(i)        <= dl_cp_rx_on_time(i)(1);
    dl_cp_scs2_rx_on_time(i)        <= dl_cp_rx_on_time(i)(2);
    dl_cp_scs3_rx_on_time(i)        <= dl_cp_rx_on_time(i)(3);
    dl_cp_scs4_rx_on_time(i)        <= dl_cp_rx_on_time(i)(4);
    dl_cp_scs0_rx_early(i)          <= dl_cp_rx_early(i)(0);
    dl_cp_scs1_rx_early(i)          <= dl_cp_rx_early(i)(1);
    dl_cp_scs2_rx_early(i)          <= dl_cp_rx_early(i)(2);
    dl_cp_scs3_rx_early(i)          <= dl_cp_rx_early(i)(3);
    dl_cp_scs4_rx_early(i)          <= dl_cp_rx_early(i)(4);
    dl_cp_scs0_rx_late(i)           <= dl_cp_rx_late(i)(0);
    dl_cp_scs1_rx_late(i)           <= dl_cp_rx_late(i)(1);
    dl_cp_scs2_rx_late(i)           <= dl_cp_rx_late(i)(2);
    dl_cp_scs3_rx_late(i)           <= dl_cp_rx_late(i)(3);
    dl_cp_scs4_rx_late(i)           <= dl_cp_rx_late(i)(4);
    dl_cp_scs0_rx_ndm(i)            <= dl_cp_rx_ndm(i)(0);
    dl_cp_scs1_rx_ndm(i)            <= dl_cp_rx_ndm(i)(1);
    dl_cp_scs2_rx_ndm(i)            <= dl_cp_rx_ndm(i)(2);
    dl_cp_scs3_rx_ndm(i)            <= dl_cp_rx_ndm(i)(3);
    dl_cp_scs4_rx_ndm(i)            <= dl_cp_rx_ndm(i)(4);

    dl_up_scs0_rx_on_time(i)        <= dl_up_rx_on_time(i)(0);
    dl_up_scs1_rx_on_time(i)        <= dl_up_rx_on_time(i)(1);
    dl_up_scs2_rx_on_time(i)        <= dl_up_rx_on_time(i)(2);
    dl_up_scs3_rx_on_time(i)        <= dl_up_rx_on_time(i)(3);
    dl_up_scs4_rx_on_time(i)        <= dl_up_rx_on_time(i)(4);
    dl_up_scs0_rx_early(i)          <= dl_up_rx_early(i)(0);
    dl_up_scs1_rx_early(i)          <= dl_up_rx_early(i)(1);
    dl_up_scs2_rx_early(i)          <= dl_up_rx_early(i)(2);
    dl_up_scs3_rx_early(i)          <= dl_up_rx_early(i)(3);
    dl_up_scs4_rx_early(i)          <= dl_up_rx_early(i)(4);
    dl_up_scs0_rx_late(i)           <= dl_up_rx_late(i)(0);
    dl_up_scs1_rx_late(i)           <= dl_up_rx_late(i)(1);
    dl_up_scs2_rx_late(i)           <= dl_up_rx_late(i)(2);
    dl_up_scs3_rx_late(i)           <= dl_up_rx_late(i)(3);
    dl_up_scs4_rx_late(i)           <= dl_up_rx_late(i)(4);
    dl_up_scs0_rx_ndm(i)            <= dl_up_rx_ndm(i)(0);
    dl_up_scs1_rx_ndm(i)            <= dl_up_rx_ndm(i)(1);
    dl_up_scs2_rx_ndm(i)            <= dl_up_rx_ndm(i)(2);
    dl_up_scs3_rx_ndm(i)            <= dl_up_rx_ndm(i)(3);
    dl_up_scs4_rx_ndm(i)            <= dl_up_rx_ndm(i)(4);

    ul_cp_scs0_rx_on_time(i)        <= ul_cp_rx_on_time(i)(0);
    ul_cp_scs1_rx_on_time(i)        <= ul_cp_rx_on_time(i)(1);
    ul_cp_scs2_rx_on_time(i)        <= ul_cp_rx_on_time(i)(2);
    ul_cp_scs3_rx_on_time(i)        <= ul_cp_rx_on_time(i)(3);
    ul_cp_scs4_rx_on_time(i)        <= ul_cp_rx_on_time(i)(4);
    ul_cp_scs0_rx_early(i)          <= ul_cp_rx_early(i)(0);
    ul_cp_scs1_rx_early(i)          <= ul_cp_rx_early(i)(1);
    ul_cp_scs2_rx_early(i)          <= ul_cp_rx_early(i)(2);
    ul_cp_scs3_rx_early(i)          <= ul_cp_rx_early(i)(3);
    ul_cp_scs4_rx_early(i)          <= ul_cp_rx_early(i)(4);
    ul_cp_scs0_rx_late(i)           <= ul_cp_rx_late(i)(0);
    ul_cp_scs1_rx_late(i)           <= ul_cp_rx_late(i)(1);
    ul_cp_scs2_rx_late(i)           <= ul_cp_rx_late(i)(2);
    ul_cp_scs3_rx_late(i)           <= ul_cp_rx_late(i)(3);
    ul_cp_scs4_rx_late(i)           <= ul_cp_rx_late(i)(4);
    ul_cp_scs0_rx_ndm(i)            <= ul_cp_rx_ndm(i)(0);
    ul_cp_scs1_rx_ndm(i)            <= ul_cp_rx_ndm(i)(1);
    ul_cp_scs2_rx_ndm(i)            <= ul_cp_rx_ndm(i)(2);
    ul_cp_scs3_rx_ndm(i)            <= ul_cp_rx_ndm(i)(3);
    ul_cp_scs4_rx_ndm(i)            <= ul_cp_rx_ndm(i)(4);
    end generate;

--------------------------------------------------------------------------------
-- MPI
--------------------------------------------------------------------------------

    u_MPI : ORAN_MPI
    generic map(
        IMPL_PDxCH                  => IMPL_PDxCH                              ,--: boolean := true;
        IMPL_SSB                    => IMPL_SSB                                ,--: boolean := false;
        IMPL_H_MATRIX               => IMPL_H_MATRIX                           ,--: boolean := false;
        IMPL_PUxCH                  => IMPL_PUxCH                              ,--: boolean := true;
        IMPL_PRACH                  => IMPL_PRACH                              ,--: boolean := true;
        IMPL_SRS                    => IMPL_SRS                                ,--: boolean := false;
        IMPL_RIM_RS                 => IMPL_RIM_RS                             ,--: boolean := false;
        IMPL_NB_IoT                 => IMPL_NB_IoT                             ,--: boolean := true;

        MAX_CC_DL                   => MAX_CC_DL                               ,--: natural := 2;
        MAX_CC_UL                   => MAX_CC_UL                               ,--: natural := 1;
        MAX_PDxCH                   => MAX_PDxCH                               ,--: natural := 4;
        MAX_SSB                     => MAX_SSB                                 ,--: natural := 0;
        MAX_H_MATRIX                => MAX_H_MATRIX                            ,--: natural := 0;
        MAX_PUxCH                   => MAX_PUxCH                               ,--: natural := 4;
        MAX_PRACH                   => MAX_PRACH                               ,--: natural := 4;
        MAX_SRS                     => MAX_SRS                                 ,--: natural := 0;
        MAX_RIM_RS                  => MAX_RIM_RS                              ,--: natural := 0;
        MAX_NB_IoT                  => MAX_NB_IoT                              ,--: natural := 1;

        MAX_PE                      => MAX_PE                                   --: natural := 4
    )
    port map(
        CLK                         => CLK_CPUIF                               ,--: in  std_logic;
        RST                         => RST_CPUIF                               ,--: in  std_logic;

        USER_DEBUG0                 => user_debug0                             ,--: out std_logic_vector(31 downto 0);
        USER_DEBUG1                 => user_debug1                             ,--: out std_logic_vector(31 downto 0);
        USER_DEBUG2                 => user_debug2                             ,--: out std_logic_vector(31 downto 0);
        USER_DEBUG3                 => user_debug3                             ,--: out std_logic_vector(31 downto 0);

        IGNORE_FRAME_ID_PUxCH_RX    => ignore_frame_id_puxch_rx                ,--: in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    => ignore_frame_id_puxch_tx                ,--: in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_RX   => ignore_frame_id_prach0_rx               ,--: in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_TX   => ignore_frame_id_prach0_tx               ,--: in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_RX   => ignore_frame_id_prach1_rx               ,--: in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_TX   => ignore_frame_id_prach1_tx               ,--: in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_RX   => (others => (others => '0'))             ,--: in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_TX   => (others => (others => '0'))             ,--: in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_RX   => (others => (others => '0'))             ,--: in  std_logic_array8(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_TX   => (others => (others => '0'))             ,--: in  std_logic_array8(7 downto 0);

        DL_UPLANE_ONLY_EN           => dl_uplane_only_en                       ,--: out std_logic;

        DL_PARAM_ID_EN              => dl_param_id_en                          ,--: out std_logic_array64(7 downto 0);
        DL_PARAM_ID                 => dl_param_id                             ,--: out std_logic_array64_array16(7 downto 0);
        DL_PE_INDEX                 => dl_pe_index                             ,--: out std_logic_array64_array8(7 downto 0);
        DL_COMP_MODE                => dl_comp_mode                            ,--: out std_logic_array64(7 downto 0);
        DL_IQ_WIDTH                 => dl_iq_width                             ,--: out std_logic_array64_array4(7 downto 0);
        DL_COMP_METHOD              => dl_comp_method                          ,--: out std_logic_array64_array4(7 downto 0);
        DL_SCS_CONFIG               => dl_scs_config                           ,--: out std_logic_array64_array4(7 downto 0);
        DL_FFT_SIZE                 => dl_fft_size                             ,--: out std_logic_array64_array4(7 downto 0);
        DL_PRB_PER_SYMBOL           => dl_prb_per_symbol                       ,--: out std_logic_array64_array10(7 downto 0);
        DL_COMP_EXP_OFFSET          => dl_comp_exp_offset                      ,--: out std_logic_array64_array5(7 downto 0);

        UL_PARAM_ID_EN              => ul_param_id_en                          ,--: out std_logic_array64(7 downto 0);
        UL_PARAM_ID                 => ul_param_id                             ,--: out std_logic_array64_array16(7 downto 0);
        UL_PE_INDEX                 => ul_pe_index                             ,--: out std_logic_array64_array8(7 downto 0);
        UL_COMP_MODE                => ul_comp_mode                            ,--: out std_logic_array64(7 downto 0);
        UL_IQ_WIDTH                 => ul_iq_width                             ,--: out std_logic_array64_array4(7 downto 0);
        UL_COMP_METHOD              => ul_comp_method                          ,--: out std_logic_array64_array4(7 downto 0);
        UL_SCS_CONFIG               => ul_scs_config                           ,--: out std_logic_array64_array4(7 downto 0);
        UL_FFT_SIZE                 => ul_fft_size                             ,--: out std_logic_array64_array4(7 downto 0);
        UL_PRB_PER_SYMBOL           => ul_prb_per_symbol                       ,--: out std_logic_array64_array10(7 downto 0);
        UL_PRB_PER_MTU              => ul_prb_per_mtu                          ,--: out std_logic_array64_array10(7 downto 0);
        UL_COMP_EXP_OFFSET          => ul_comp_exp_offset                      ,--: out std_logic_array64_array5(7 downto 0);
        UL_COMP_GAIN_OFFSET         => ul_comp_gain_offset                     ,--: out std_logic_array64_array11(7 downto 0);
        UL_COMP_SCALE_GAIN_OFFSET   => ul_comp_scale_gain_offset               ,--: out std_logic_array64_array4(7 downto 0);

        PARAM_RU_MAC                => param_ru_mac                            ,--: out std_logic_array48(7 downto 0);
        PARAM_PORT_INDEX            => param_port_index                        ,--: out std_logic_array3(7 downto 0);
        PARAM_DU_MAC                => param_du_mac                            ,--: out std_logic_array48(7 downto 0);
        PARAM_VLAN0_EN              => param_vlan0_en                          ,--: out std_logic_vector(7 downto 0);
        PARAM_VLAN0_VID             => param_vlan0_vid                         ,--: out std_logic_array12(7 downto 0);
        PARAM_VLAN1_EN              => param_vlan1_en                          ,--: out std_logic_vector(7 downto 0);
        PARAM_VLAN1_VID             => param_vlan1_vid                         ,--: out std_logic_array12(7 downto 0);

        CAPTURE_PERIOD              => capture_period                          ,--: out std_logic_array8(7 downto 0);

        T2A_MAX_DL_CP_RX            => t2a_max_dl_cp_rx                        ,--: out std_logic_array5_array22(7 downto 0);
        T2A_MIN_DL_CP_RX            => t2a_min_dl_cp_rx                        ,--: out std_logic_array5_array22(7 downto 0);
        T2A_MAX_DL_UP_RX            => t2a_max_dl_up_rx                        ,--: out std_logic_array5_array22(7 downto 0);
        T2A_MIN_DL_UP_RX            => t2a_min_dl_up_rx                        ,--: out std_logic_array5_array22(7 downto 0);
        T2A_MAX_UL_CP_RX            => t2a_max_ul_cp_rx                        ,--: out std_logic_array5_array22(7 downto 0);
        T2A_MIN_UL_CP_RX            => t2a_min_ul_cp_rx                        ,--: out std_logic_array5_array22(7 downto 0);

        STAT_CNT_CLEAR              => stat_cnt_clear                          ,--: out std_logic_vector(7 downto 0);

        CNT_RX_CORRUPT                          => cnt_rx_corrupt                                   ,
        CNT_RX_SECTIONID                        => cnt_rx_corrupt_sectionid                         ,
        CNT_RX_PCID_eCPRIVERSION_PAYLOADVERSION => cnt_rx_corrupt_ecpriversion_payloadversion_pcid  ,
        CNT_RX_PCID                             => cnt_rx_corrupt_pcid                              ,
        CNT_RX_eCPRIVERSION                     => cnt_rx_corrupt_ecpriversion                      ,
        CNT_RX_PAYLOADVERSION                   => cnt_rx_corrupt_payloadversion                    ,
        
        
        DL_CP_SCS0_RX_ON_TIME       => dl_cp_scs0_rx_on_time                   ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS0_RX_EARLY         => dl_cp_scs0_rx_early                     ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS0_RX_LATE          => dl_cp_scs0_rx_late                      ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS0_RX_NDM           => dl_cp_scs0_rx_ndm                       ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS1_RX_ON_TIME       => dl_cp_scs1_rx_on_time                   ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS1_RX_EARLY         => dl_cp_scs1_rx_early                     ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS1_RX_LATE          => dl_cp_scs1_rx_late                      ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS1_RX_NDM           => dl_cp_scs1_rx_ndm                       ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS2_RX_ON_TIME       => dl_cp_scs2_rx_on_time                   ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS2_RX_EARLY         => dl_cp_scs2_rx_early                     ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS2_RX_LATE          => dl_cp_scs2_rx_late                      ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS2_RX_NDM           => dl_cp_scs2_rx_ndm                       ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS3_RX_ON_TIME       => dl_cp_scs3_rx_on_time                   ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS3_RX_EARLY         => dl_cp_scs3_rx_early                     ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS3_RX_LATE          => dl_cp_scs3_rx_late                      ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS3_RX_NDM           => dl_cp_scs3_rx_ndm                       ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS4_RX_ON_TIME       => dl_cp_scs4_rx_on_time                   ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS4_RX_EARLY         => dl_cp_scs4_rx_early                     ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS4_RX_LATE          => dl_cp_scs4_rx_late                      ,--: in  std_logic_array64(7 downto 0);
        DL_CP_SCS4_RX_NDM           => dl_cp_scs4_rx_ndm                       ,--: in  std_logic_array64(7 downto 0);

        DL_UP_SCS0_RX_ON_TIME       => dl_up_scs0_rx_on_time                   ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS0_RX_EARLY         => dl_up_scs0_rx_early                     ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS0_RX_LATE          => dl_up_scs0_rx_late                      ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS0_RX_NDM           => dl_up_scs0_rx_ndm                       ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS1_RX_ON_TIME       => dl_up_scs1_rx_on_time                   ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS1_RX_EARLY         => dl_up_scs1_rx_early                     ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS1_RX_LATE          => dl_up_scs1_rx_late                      ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS1_RX_NDM           => dl_up_scs1_rx_ndm                       ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS2_RX_ON_TIME       => dl_up_scs2_rx_on_time                   ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS2_RX_EARLY         => dl_up_scs2_rx_early                     ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS2_RX_LATE          => dl_up_scs2_rx_late                      ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS2_RX_NDM           => dl_up_scs2_rx_ndm                       ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS3_RX_ON_TIME       => dl_up_scs3_rx_on_time                   ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS3_RX_EARLY         => dl_up_scs3_rx_early                     ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS3_RX_LATE          => dl_up_scs3_rx_late                      ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS3_RX_NDM           => dl_up_scs3_rx_ndm                       ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS4_RX_ON_TIME       => dl_up_scs4_rx_on_time                   ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS4_RX_EARLY         => dl_up_scs4_rx_early                     ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS4_RX_LATE          => dl_up_scs4_rx_late                      ,--: in  std_logic_array64(7 downto 0);
        DL_UP_SCS4_RX_NDM           => dl_up_scs4_rx_ndm                       ,--: in  std_logic_array64(7 downto 0);

        UL_CP_SCS0_RX_ON_TIME       => ul_cp_scs0_rx_on_time                   ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS0_RX_EARLY         => ul_cp_scs0_rx_early                     ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS0_RX_LATE          => ul_cp_scs0_rx_late                      ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS0_RX_NDM           => ul_cp_scs0_rx_ndm                       ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS1_RX_ON_TIME       => ul_cp_scs1_rx_on_time                   ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS1_RX_EARLY         => ul_cp_scs1_rx_early                     ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS1_RX_LATE          => ul_cp_scs1_rx_late                      ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS1_RX_NDM           => ul_cp_scs1_rx_ndm                       ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS2_RX_ON_TIME       => ul_cp_scs2_rx_on_time                   ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS2_RX_EARLY         => ul_cp_scs2_rx_early                     ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS2_RX_LATE          => ul_cp_scs2_rx_late                      ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS2_RX_NDM           => ul_cp_scs2_rx_ndm                       ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS3_RX_ON_TIME       => ul_cp_scs3_rx_on_time                   ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS3_RX_EARLY         => ul_cp_scs3_rx_early                     ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS3_RX_LATE          => ul_cp_scs3_rx_late                      ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS3_RX_NDM           => ul_cp_scs3_rx_ndm                       ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS4_RX_ON_TIME       => ul_cp_scs4_rx_on_time                   ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS4_RX_EARLY         => ul_cp_scs4_rx_early                     ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS4_RX_LATE          => ul_cp_scs4_rx_late                      ,--: in  std_logic_array64(7 downto 0);
        UL_CP_SCS4_RX_NDM           => ul_cp_scs4_rx_ndm                       ,--: in  std_logic_array64(7 downto 0);

        UL_CP_TX_TOTAL              => ul_cp_tx_total                          ,--: in  std_logic_array64(7 downto 0);
        UL_UP_TX_TOTAL              => ul_up_tx_total                          ,--: in  std_logic_array64(7 downto 0);

        DSS_PARAM_TEST_PATTERN_EN   => dss_param_test_en                       ,--: out std_logic;

        I_CC0_COEFF_VLD_CNT         => reg_cc0_coeff_vld_cnt                   ,--: in  std_logic_vector(31 downto 0);
        I_CC1_COEFF_VLD_CNT         => reg_cc1_coeff_vld_cnt                   ,--: in  std_logic_vector(31 downto 0);

        I_CC0_COEFF_IDX_MON         => reg_cc0_coeff_idx_mon                   ,--: in  std_logic_vector(31 downto 0);
        I_CC1_COEFF_IDX_MON         => reg_cc1_coeff_idx_mon                   ,--: in  std_logic_vector(31 downto 0);

        RX_PE_VALID                 => rx_pe_valid                             ,--: in  std_logic_array32(7 downto 0);
        RX_INVALID_DST_MAC          => rx_invalid_dst_mac                      ,--: in  std_logic_array32(7 downto 0);
        RX_INVALID_SRC_MAC          => rx_invalid_src_mac                      ,--: in  std_logic_array32(7 downto 0);
        RX_INVALID_VLAN_VID         => rx_invalid_vlan_vid                     ,--: in  std_logic_array32(7 downto 0);
        RX_DISCONTINUE              => rx_discontinue                          ,--: in  std_logic_array32(7 downto 0);
        RX_BYTE_SIZE                => rx_byte_size                            ,--: in  std_logic_array32(7 downto 0);
        RX_BYTE_ALIGN               => rx_byte_align                           ,--: in  std_logic_array32(7 downto 0);

        RX_DL_CP_POSITION           => rx_dl_cp_position                       ,--: in  std_logic_array64(7 downto 0);
        RX_DL_UP_POSITION           => rx_dl_up_position                       ,--: in  std_logic_array64(7 downto 0);
        RX_UL_CP_POSITION           => rx_ul_cp_position                       ,--: in  std_logic_array64(7 downto 0);

        USAGE_RX_CP_BUFFER          => usage_rx_cp_buffer                      ,--: in  std_logic_array32(7 downto 0);
        USAGE_RX_UP_BUFFER          => usage_rx_up_buffer                      ,--: in  std_logic_array32(7 downto 0);

        CNT_RX_CP                   => cnt_rx_cp                               ,--: in  std_logic_array32(7 downto 0);
        CNT_RX_UP                   => cnt_rx_up                               ,--: in  std_logic_array32(7 downto 0);
        CNT_RX_CP_LOST              => cnt_rx_cp_lost                          ,--: in  std_logic_array32(7 downto 0);
        CNT_RX_UP_LOST              => cnt_rx_up_lost                          ,--: in  std_logic_array32(7 downto 0);

        USAGE_TX0_UP_BUFFER         => usage_tx0_up_buffer                     ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX1_UP_BUFFER         => usage_tx1_up_buffer                     ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX2_UP_BUFFER         => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX3_UP_BUFFER         => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX4_UP_BUFFER         => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);

        CNT_TX0                     => cnt_tx0                                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1                     => cnt_tx1                                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2                     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3                     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4                     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_LOST                => cnt_tx0_lost                            ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_LOST                => cnt_tx1_lost                            ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_LOST                => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_LOST                => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_LOST                => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);

        DET_DL_CP0_FAULT_ID_31      => det_dl_cp0_fault_id_31                  ,--: in  std_logic_array16(7 downto 0);
        DET_DL_CP1_FAULT_ID_31      => det_dl_cp1_fault_id_31                  ,--: in  std_logic_array16(7 downto 0);
        DET_DL_CP2_FAULT_ID_31      => det_dl_cp2_fault_id_31                  ,--: in  std_logic_array16(7 downto 0);
        DET_DL_CP3_FAULT_ID_31      => (others => (others => '0'))             ,--: in  std_logic_array16(7 downto 0);
        DET_DL_CP4_FAULT_ID_31      => (others => (others => '0'))             ,--: in  std_logic_array16(7 downto 0);
        DET_DL_CP5_FAULT_ID_31      => (others => (others => '0'))             ,--: in  std_logic_array16(7 downto 0);
        DET_DL_CP6_FAULT_ID_31      => (others => (others => '0'))             ,--: in  std_logic_array16(7 downto 0);
        DET_DL_CP7_FAULT_ID_31      => (others => (others => '0'))             ,--: in  std_logic_array16(7 downto 0);
        DET_UL_CP0_FAULT_ID_31      => det_ul_cp0_fault_id_31                  ,--: in  std_logic_array16(7 downto 0);
        DET_UL_CP1_FAULT_ID_31      => det_ul_cp1_fault_id_31                  ,--: in  std_logic_array16(7 downto 0);
        DET_UL_CP2_FAULT_ID_31      => det_ul_cp2_fault_id_31                  ,--: in  std_logic_array16(7 downto 0);
        DET_UL_CP3_FAULT_ID_31      => det_ul_cp3_fault_id_31                  ,--: in  std_logic_array16(7 downto 0);
        DET_UL_CP4_FAULT_ID_31      => det_ul_cp4_fault_id_31                  ,--: in  std_logic_array16(7 downto 0);
        DET_UL_CP5_FAULT_ID_31      => (others => (others => '0'))             ,--: in  std_logic_array16(7 downto 0);
        DET_UL_CP6_FAULT_ID_31      => (others => (others => '0'))             ,--: in  std_logic_array16(7 downto 0);
        DET_UL_CP7_FAULT_ID_31      => (others => (others => '0'))             ,--: in  std_logic_array16(7 downto 0);

        STATUS_TX0_CQ_FSM           => status_tx0_cq_fsm                       ,--: in  std_logic_array8(7 downto 0);
        CNT_TX0_CQ_FSM_BUSY         => cnt_tx0_cq_fsm_busy                     ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_CONV_FULL        => cnt_tx0_cq_conv_full                    ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL0       => cnt_tx0_cpsec_symbol0                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL1       => cnt_tx0_cpsec_symbol1                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL2       => cnt_tx0_cpsec_symbol2                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL3       => cnt_tx0_cpsec_symbol3                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL4       => cnt_tx0_cpsec_symbol4                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL5       => cnt_tx0_cpsec_symbol5                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL6       => cnt_tx0_cpsec_symbol6                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL7       => cnt_tx0_cpsec_symbol7                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL8       => cnt_tx0_cpsec_symbol8                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL9       => cnt_tx0_cpsec_symbol9                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL10      => cnt_tx0_cpsec_symbol10                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL11      => cnt_tx0_cpsec_symbol11                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL12      => cnt_tx0_cpsec_symbol12                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CPSEC_SYMBOL13      => cnt_tx0_cpsec_symbol13                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL0       => cnt_tx0_uppkt_symbol0                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL1       => cnt_tx0_uppkt_symbol1                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL2       => cnt_tx0_uppkt_symbol2                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL3       => cnt_tx0_uppkt_symbol3                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL4       => cnt_tx0_uppkt_symbol4                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL5       => cnt_tx0_uppkt_symbol5                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL6       => cnt_tx0_uppkt_symbol6                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL7       => cnt_tx0_uppkt_symbol7                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL8       => cnt_tx0_uppkt_symbol8                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL9       => cnt_tx0_uppkt_symbol9                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL10      => cnt_tx0_uppkt_symbol10                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL11      => cnt_tx0_uppkt_symbol11                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL12      => cnt_tx0_uppkt_symbol12                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_UPPKT_SYMBOL13      => cnt_tx0_uppkt_symbol13                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL0     => cnt_tx0_cq_full_symbol0                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL1     => cnt_tx0_cq_full_symbol1                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL2     => cnt_tx0_cq_full_symbol2                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL3     => cnt_tx0_cq_full_symbol3                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL4     => cnt_tx0_cq_full_symbol4                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL5     => cnt_tx0_cq_full_symbol5                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL6     => cnt_tx0_cq_full_symbol6                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL7     => cnt_tx0_cq_full_symbol7                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL8     => cnt_tx0_cq_full_symbol8                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL9     => cnt_tx0_cq_full_symbol9                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL10    => cnt_tx0_cq_full_symbol10                ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL11    => cnt_tx0_cq_full_symbol11                ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL12    => cnt_tx0_cq_full_symbol12                ,--: in  std_logic_array32(7 downto 0);
        CNT_TX0_CQ_FULL_SYMBOL13    => cnt_tx0_cq_full_symbol13                ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL0        => usage_tx0_cq_symbol0                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL1        => usage_tx0_cq_symbol1                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL2        => usage_tx0_cq_symbol2                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL3        => usage_tx0_cq_symbol3                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL4        => usage_tx0_cq_symbol4                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL5        => usage_tx0_cq_symbol5                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL6        => usage_tx0_cq_symbol6                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL7        => usage_tx0_cq_symbol7                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL8        => usage_tx0_cq_symbol8                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL9        => usage_tx0_cq_symbol9                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL10       => usage_tx0_cq_symbol10                   ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL11       => usage_tx0_cq_symbol11                   ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL12       => usage_tx0_cq_symbol12                   ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX0_CQ_SYMBOL13       => usage_tx0_cq_symbol13                   ,--: in  std_logic_array32(7 downto 0);

        STATUS_TX1_CQ_FSM           => status_tx1_cq_fsm                       ,--: in  std_logic_array8(7 downto 0);
        CNT_TX1_CQ_FSM_BUSY         => cnt_tx1_cq_fsm_busy                     ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_CONV_FULL        => cnt_tx1_cq_conv_full                    ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL0       => cnt_tx1_cpsec_symbol0                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL1       => cnt_tx1_cpsec_symbol1                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL2       => cnt_tx1_cpsec_symbol2                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL3       => cnt_tx1_cpsec_symbol3                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL4       => cnt_tx1_cpsec_symbol4                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL5       => cnt_tx1_cpsec_symbol5                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL6       => cnt_tx1_cpsec_symbol6                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL7       => cnt_tx1_cpsec_symbol7                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL8       => cnt_tx1_cpsec_symbol8                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL9       => cnt_tx1_cpsec_symbol9                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL10      => cnt_tx1_cpsec_symbol10                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL11      => cnt_tx1_cpsec_symbol11                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL12      => cnt_tx1_cpsec_symbol12                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CPSEC_SYMBOL13      => cnt_tx1_cpsec_symbol13                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL0       => cnt_tx1_uppkt_symbol0                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL1       => cnt_tx1_uppkt_symbol1                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL2       => cnt_tx1_uppkt_symbol2                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL3       => cnt_tx1_uppkt_symbol3                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL4       => cnt_tx1_uppkt_symbol4                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL5       => cnt_tx1_uppkt_symbol5                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL6       => cnt_tx1_uppkt_symbol6                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL7       => cnt_tx1_uppkt_symbol7                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL8       => cnt_tx1_uppkt_symbol8                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL9       => cnt_tx1_uppkt_symbol9                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL10      => cnt_tx1_uppkt_symbol10                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL11      => cnt_tx1_uppkt_symbol11                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL12      => cnt_tx1_uppkt_symbol12                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_UPPKT_SYMBOL13      => cnt_tx1_uppkt_symbol13                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL0     => cnt_tx1_cq_full_symbol0                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL1     => cnt_tx1_cq_full_symbol1                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL2     => cnt_tx1_cq_full_symbol2                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL3     => cnt_tx1_cq_full_symbol3                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL4     => cnt_tx1_cq_full_symbol4                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL5     => cnt_tx1_cq_full_symbol5                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL6     => cnt_tx1_cq_full_symbol6                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL7     => cnt_tx1_cq_full_symbol7                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL8     => cnt_tx1_cq_full_symbol8                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL9     => cnt_tx1_cq_full_symbol9                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL10    => cnt_tx1_cq_full_symbol10                ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL11    => cnt_tx1_cq_full_symbol11                ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL12    => cnt_tx1_cq_full_symbol12                ,--: in  std_logic_array32(7 downto 0);
        CNT_TX1_CQ_FULL_SYMBOL13    => cnt_tx1_cq_full_symbol13                ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL0        => usage_tx1_cq_symbol0                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL1        => usage_tx1_cq_symbol1                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL2        => usage_tx1_cq_symbol2                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL3        => usage_tx1_cq_symbol3                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL4        => usage_tx1_cq_symbol4                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL5        => usage_tx1_cq_symbol5                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL6        => usage_tx1_cq_symbol6                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL7        => usage_tx1_cq_symbol7                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL8        => usage_tx1_cq_symbol8                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL9        => usage_tx1_cq_symbol9                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL10       => usage_tx1_cq_symbol10                   ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL11       => usage_tx1_cq_symbol11                   ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL12       => usage_tx1_cq_symbol12                   ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX1_CQ_SYMBOL13       => usage_tx1_cq_symbol13                   ,--: in  std_logic_array32(7 downto 0);

        STATUS_TX2_CQ_FSM           => status_tx2_cq_fsm                       ,--: in  std_logic_array8(7 downto 0);
        CNT_TX2_CQ_FSM_BUSY         => cnt_tx2_cq_fsm_busy                     ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_CONV_FULL        => cnt_tx2_cq_conv_full                    ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL0       => cnt_tx2_cpsec_symbol0                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL1       => cnt_tx2_cpsec_symbol1                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL2       => cnt_tx2_cpsec_symbol2                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL3       => cnt_tx2_cpsec_symbol3                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL4       => cnt_tx2_cpsec_symbol4                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL5       => cnt_tx2_cpsec_symbol5                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL6       => cnt_tx2_cpsec_symbol6                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL7       => cnt_tx2_cpsec_symbol7                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL8       => cnt_tx2_cpsec_symbol8                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL9       => cnt_tx2_cpsec_symbol9                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL10      => cnt_tx2_cpsec_symbol10                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL11      => cnt_tx2_cpsec_symbol11                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL12      => cnt_tx2_cpsec_symbol12                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CPSEC_SYMBOL13      => cnt_tx2_cpsec_symbol13                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL0       => cnt_tx2_uppkt_symbol0                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL1       => cnt_tx2_uppkt_symbol1                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL2       => cnt_tx2_uppkt_symbol2                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL3       => cnt_tx2_uppkt_symbol3                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL4       => cnt_tx2_uppkt_symbol4                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL5       => cnt_tx2_uppkt_symbol5                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL6       => cnt_tx2_uppkt_symbol6                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL7       => cnt_tx2_uppkt_symbol7                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL8       => cnt_tx2_uppkt_symbol8                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL9       => cnt_tx2_uppkt_symbol9                   ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL10      => cnt_tx2_uppkt_symbol10                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL11      => cnt_tx2_uppkt_symbol11                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL12      => cnt_tx2_uppkt_symbol12                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_UPPKT_SYMBOL13      => cnt_tx2_uppkt_symbol13                  ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL0     => cnt_tx2_cq_full_symbol0                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL1     => cnt_tx2_cq_full_symbol1                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL2     => cnt_tx2_cq_full_symbol2                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL3     => cnt_tx2_cq_full_symbol3                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL4     => cnt_tx2_cq_full_symbol4                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL5     => cnt_tx2_cq_full_symbol5                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL6     => cnt_tx2_cq_full_symbol6                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL7     => cnt_tx2_cq_full_symbol7                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL8     => cnt_tx2_cq_full_symbol8                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL9     => cnt_tx2_cq_full_symbol9                 ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL10    => cnt_tx2_cq_full_symbol10                ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL11    => cnt_tx2_cq_full_symbol11                ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL12    => cnt_tx2_cq_full_symbol12                ,--: in  std_logic_array32(7 downto 0);
        CNT_TX2_CQ_FULL_SYMBOL13    => cnt_tx2_cq_full_symbol13                ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL0        => usage_tx2_cq_symbol0                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL1        => usage_tx2_cq_symbol1                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL2        => usage_tx2_cq_symbol2                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL3        => usage_tx2_cq_symbol3                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL4        => usage_tx2_cq_symbol4                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL5        => usage_tx2_cq_symbol5                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL6        => usage_tx2_cq_symbol6                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL7        => usage_tx2_cq_symbol7                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL8        => usage_tx2_cq_symbol8                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL9        => usage_tx2_cq_symbol9                    ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL10       => usage_tx2_cq_symbol10                   ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL11       => usage_tx2_cq_symbol11                   ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL12       => usage_tx2_cq_symbol12                   ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX2_CQ_SYMBOL13       => usage_tx2_cq_symbol13                   ,--: in  std_logic_array32(7 downto 0);

        STATUS_TX3_CQ_FSM           => (others => (others => '0'))             ,--: in  std_logic_array8(7 downto 0);
        CNT_TX3_CQ_FSM_BUSY         => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_CONV_FULL        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL0       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL1       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL2       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL3       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL4       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL5       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL6       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL7       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL8       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL9       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL10      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL11      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL12      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CPSEC_SYMBOL13      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL0       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL1       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL2       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL3       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL4       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL5       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL6       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL7       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL8       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL9       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL10      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL11      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL12      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_UPPKT_SYMBOL13      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL0     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL1     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL2     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL3     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL4     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL5     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL6     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL7     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL8     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL9     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL10    => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL11    => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL12    => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX3_CQ_FULL_SYMBOL13    => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL0        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL1        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL2        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL3        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL4        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL5        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL6        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL7        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL8        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL9        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL10       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL11       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL12       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX3_CQ_SYMBOL13       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);

        STATUS_TX4_CQ_FSM           => (others => (others => '0'))             ,--: in  std_logic_array8(7 downto 0);
        CNT_TX4_CQ_FSM_BUSY         => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_CONV_FULL        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL0       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL1       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL2       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL3       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL4       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL5       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL6       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL7       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL8       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL9       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL10      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL11      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL12      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CPSEC_SYMBOL13      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL0       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL1       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL2       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL3       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL4       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL5       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL6       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL7       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL8       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL9       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL10      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL11      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL12      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_UPPKT_SYMBOL13      => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL0     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL1     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL2     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL3     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL4     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL5     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL6     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL7     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL8     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL9     => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL10    => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL11    => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL12    => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        CNT_TX4_CQ_FULL_SYMBOL13    => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL0        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL1        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL2        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL3        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL4        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL5        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL6        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL7        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL8        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL9        => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL10       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL11       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL12       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);
        USAGE_TX4_CQ_SYMBOL13       => (others => (others => '0'))             ,--: in  std_logic_array32(7 downto 0);

        WREN_CPUIF_IN               => WREN_CPUIF_IN                           ,--: in  std_logic;
        RDEN_CPUIF_IN               => RDEN_CPUIF_IN                           ,--: in  std_logic;
        ADDR_CPUIF_IN               => ADDR_CPUIF_IN                           ,--: in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN              => WDATA_CPUIF_IN                          ,--: in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             => RDATA_CPUIF_OUT                         ,--: out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             => RDVAL_CPUIF_OUT                          --: out std_logic
    );

end BEHAVE;
