--------------------------------------------------------------------------------
--
-- Copyright (C) 2024, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Author   : jaekyu.no (jaekyu.no@samsung.com)
-- Date     : 2024.03.11
--------------------------------------------------------------------------------
-- Function description
--   -. Performance measurement
--------------------------------------------------------------------------------
-- Change log
--   Rev 1 (2024.03.11) - initial release
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;
use WORK.PKG_ORAN.ALL;

entity MEASUREMENT is
    generic (
        NUM_TX                      : natural := 1
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK_245p76MHz               : in  std_logic;                            -- 245.76-MHz

--------------------------------------------------------------------------------
-- Synchronization
--------------------------------------------------------------------------------

        N_TA_OFFSET                 : in  std_logic_vector(15 downto 0);

        REF_10msec                  : in  std_logic;                            -- Longer than 1-clocks@245.76-MHz
        REF_SFN                     : in  std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        CAPTURE_PERIOD              : in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            : in  std_logic_array22(4 downto 0);
        T2A_MIN_DL_CP_RX            : in  std_logic_array22(4 downto 0);
        T2A_MAX_DL_UP_RX            : in  std_logic_array22(4 downto 0);
        T2A_MIN_DL_UP_RX            : in  std_logic_array22(4 downto 0);
        T2A_MAX_UL_CP_RX            : in  std_logic_array22(4 downto 0);
        T2A_MIN_UL_CP_RX            : in  std_logic_array22(4 downto 0);

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        STAT_CNT_CLEAR              : in  std_logic;

        DL_CP_RX_ON_TIME            : out std_logic_array64(4 downto 0);
        DL_CP_RX_EARLY              : out std_logic_array64(4 downto 0);
        DL_CP_RX_LATE               : out std_logic_array64(4 downto 0);
        DL_CP_RX_NDM                : out std_logic_array64(4 downto 0);

        DL_UP_RX_ON_TIME            : out std_logic_array64(4 downto 0);
        DL_UP_RX_EARLY              : out std_logic_array64(4 downto 0);
        DL_UP_RX_LATE               : out std_logic_array64(4 downto 0);
        DL_UP_RX_NDM                : out std_logic_array64(4 downto 0);

        UL_CP_RX_ON_TIME            : out std_logic_array64(4 downto 0);
        UL_CP_RX_EARLY              : out std_logic_array64(4 downto 0);
        UL_CP_RX_LATE               : out std_logic_array64(4 downto 0);
        UL_CP_RX_NDM                : out std_logic_array64(4 downto 0);

        UL_CP_TX_TOTAL              : out std_logic_vector(63 downto 0);
        UL_UP_TX_TOTAL              : out std_logic_vector(63 downto 0);

--------------------------------------------------------------------------------
-- Packet stamp for RX
--------------------------------------------------------------------------------
        UPDATE_EN_OUT               : out std_logic;

        RX_PACKET_CLK               : in  std_logic;

        RX_PACKET_IS_CP_DL          : in  std_logic;
        RX_PACKET_IS_CP_UL          : in  std_logic;
        RX_PACKET_IS_UP_DL          : in  std_logic;
        RX_PACKET_IS_NDM            : in  std_logic;
        RX_PACKET_SCS               : in  std_logic_vector(3 downto 0);
        RX_PACKET_FRAME_ID          : in  std_logic_vector(7 downto 0);
        RX_PACKET_SUBFRAME_ID       : in  std_logic_vector(3 downto 0);
        RX_PACKET_SLOT_ID           : in  std_logic_vector(5 downto 0);
        RX_PACKET_SYMBOL_ID         : in  std_logic_vector(5 downto 0);

--------------------------------------------------------------------------------
-- Packet stamp for TX
--------------------------------------------------------------------------------

        TX_PACKET_CLK               : in  std_logic;

        TX0_PACKET_EXIST            : in  std_logic;
        TX1_PACKET_EXIST            : in  std_logic;
        TX2_PACKET_EXIST            : in  std_logic;
        TX3_PACKET_EXIST            : in  std_logic;
        TX4_PACKET_EXIST            : in  std_logic;
        TX5_PACKET_EXIST            : in  std_logic;
        TX6_PACKET_EXIST            : in  std_logic;
        TX7_PACKET_EXIST            : in  std_logic;
        TX8_PACKET_EXIST            : in  std_logic;
        TX9_PACKET_EXIST            : in  std_logic;
        TX10_PACKET_EXIST           : in  std_logic;
        TX11_PACKET_EXIST           : in  std_logic;
        TX12_PACKET_EXIST           : in  std_logic;
        TX13_PACKET_EXIST           : in  std_logic;
        TX14_PACKET_EXIST           : in  std_logic;
        TX15_PACKET_EXIST           : in  std_logic;
        TX16_PACKET_EXIST           : in  std_logic;
        TX17_PACKET_EXIST           : in  std_logic;
        TX18_PACKET_EXIST           : in  std_logic;
        TX19_PACKET_EXIST           : in  std_logic
    );
end MEASUREMENT;

architecture BEHAVE of MEASUREMENT is

    signal prev_period              : std_logic_vector(7 downto 0);
    signal condi_reset              : std_logic;

    component RST_SYNC is
    generic (
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port (
        RST_IN                      : in  std_logic;
        CLK                         : in  std_logic;
        RST_OUT                     : out std_logic
    );
    end component;

    signal rst_245p76mhz            : std_logic;

    component REF_GEN is
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        N_TA_OFFSET                 : in  std_logic_vector(15 downto 0);

        IN_10msec                   : in  std_logic;
        IN_SFN                      : in  std_logic_vector(7 downto 0);

        OUT_10msec                  : out std_logic;
        OUT_SFN                     : out std_logic_vector(7 downto 0)
    );
    end component;

    signal ref_rx_window            : std_logic;
    signal ref_rx_sfn               : std_logic_vector(7 downto 0);
    signal ref_tx_window            : std_logic;
    signal ref_tx_sfn               : std_logic_vector(7 downto 0);

    component RX_WINDOW is
    generic (
        SCS_CONFIG                  : natural := 0
    );
    port (
        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK_245p76MHz               : in  std_logic;

        WINDOW_START                : in  std_logic_vector(21 downto 0);
        WINDOW_END                  : in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               : in  std_logic_vector(7 downto 0);

        REF_10msec                  : in  std_logic;
        REF_SFN                     : in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   : in  std_logic;

        CNT_ON_TIME                 : out std_logic_vector(63 downto 0);
        CNT_EARLY                   : out std_logic_vector(63 downto 0);
        CNT_LATE                    : out std_logic_vector(63 downto 0);
        CNT_NDM                     : out std_logic_vector(63 downto 0);

        CLK_PACKET                  : in  std_logic;
        UPDATE_EN_OUT               : out std_logic;

        PACKET_EN                   : in  std_logic;
        PACKET_IS_NDM               : in  std_logic;
        PACKET_SCS                  : in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             : in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          : in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              : in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            : in  std_logic_vector(5 downto 0)
    );
    end component;

    component TX_STAT is
    generic (
        NUM_TX                      : natural := 6
    );
    port (
        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK_245p76MHz               : in  std_logic;

        WINDOW_PERIOD               : in  std_logic_vector(7 downto 0);

        REF_10msec                  : in  std_logic;

        CNT_CLEAR                   : in  std_logic;

        CNT_TOTAL                   : out std_logic_vector(63 downto 0);

        CLK_PACKET                  : in  std_logic;

        PACKET_EN                   : in  std_logic_vector(NUM_TX-1 downto 0)
    );
    end component;

    signal tx_packet_en             : std_logic_vector(19 downto 0);
    signal rx_window_update_en      : std_logic_vector(5 downto 0) := (others => '0');

begin
    process (CLK_CPUIF)
    begin
        if (CLK_CPUIF'event and CLK_CPUIF = '1') then
            UPDATE_EN_OUT <= rx_window_update_en(0) or rx_window_update_en(1) or rx_window_update_en(2) or rx_window_update_en(3) or rx_window_update_en(4);
        end if;
    end process;

--------------------------------------------------------------------------------
-- Conditional reset control
--------------------------------------------------------------------------------

    process (CLK_CPUIF)
    begin
        if (CLK_CPUIF'event and CLK_CPUIF = '1') then
            prev_period <= CAPTURE_PERIOD;
        end if;
    end process;

    process (RST_CPUIF, CLK_CPUIF)
    begin
        if (RST_CPUIF = '1') then
            condi_reset <= '1';
        elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
            if (CAPTURE_PERIOD = prev_period) then
                condi_reset <= '0';
            else
                condi_reset <= '1';
            end if;
        end if;
    end process;

    u_RST : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => condi_reset                             ,--: in  std_logic;
        CLK                         => CLK_245p76MHz                           ,--: in  std_logic;
        RST_OUT                     => rst_245p76mhz                            --: out std_logic
    );

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_RX_10msec : REF_GEN
    port map(
        CLK                         => CLK_245p76MHz                           ,--: in  std_logic;
        RST                         => rst_245p76mhz                           ,--: in  std_logic;

        N_TA_OFFSET                 => (others => '0')                         ,--: in  std_logic_vector(15 downto 0);

        IN_10msec                   => REF_10msec                              ,--: in  std_logic;
        IN_SFN                      => REF_SFN                                 ,--: in  std_logic_vector(7 downto 0);

        OUT_10msec                  => ref_rx_window                           ,--: out std_logic;
        OUT_SFN                     => ref_rx_sfn                               --: out std_logic_vector(7 downto 0)

    );

    u_TX_10msec : REF_GEN
    port map(
        CLK                         => CLK_245p76MHz                           ,--: in  std_logic;
        RST                         => rst_245p76mhz                           ,--: in  std_logic;

        N_TA_OFFSET                 => N_TA_OFFSET                             ,--: in  std_logic_vector(15 downto 0);

        IN_10msec                   => REF_10msec                              ,--: in  std_logic;
        IN_SFN                      => REF_SFN                                 ,--: in  std_logic_vector(7 downto 0);

        OUT_10msec                  => ref_tx_window                           ,--: out std_logic;
        OUT_SFN                     => ref_tx_sfn                               --: out std_logic_vector(7 downto 0)
    );

    u_RX_WINDOW_15kHz : if SCS_CONFIG_0 = true generate
    u_CP_DL : RX_WINDOW
    generic map(
        SCS_CONFIG                  => 0                                        --: natural := 0
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_DL_CP_RX(0)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_DL_CP_RX(0)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_rx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_rx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;
        UPDATE_EN_OUT               => rx_window_update_en(0),
        CNT_ON_TIME                 => DL_CP_RX_ON_TIME(0)                     ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => DL_CP_RX_EARLY(0)                       ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => DL_CP_RX_LATE(0)                        ,--: out std_logic_vector(63 downto 0);
        CNT_NDM                     => DL_CP_RX_NDM(0)                         ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;

        PACKET_EN                   => RX_PACKET_IS_CP_DL                      ,--: in  std_logic;
        PACKET_IS_NDM               => RX_PACKET_IS_NDM                        ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );

    u_UP_DL : RX_WINDOW
    generic map(
        SCS_CONFIG                  => 0                                        --: natural := 0
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_DL_UP_RX(0)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_DL_UP_RX(0)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_rx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_rx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;
        UPDATE_EN_OUT               => open,
        CNT_ON_TIME                 => DL_UP_RX_ON_TIME(0)                     ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => DL_UP_RX_EARLY(0)                       ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => DL_UP_RX_LATE(0)                        ,--: out std_logic_vector(63 downto 0);
        CNT_NDM                     => DL_UP_RX_NDM(0)                         ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;

        PACKET_EN                   => RX_PACKET_IS_UP_DL                      ,--: in  std_logic;
        PACKET_IS_NDM               => RX_PACKET_IS_NDM                        ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );

    u_CP_UL : RX_WINDOW
    generic map(
        SCS_CONFIG                  => 0                                        --: natural := 0
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_UL_CP_RX(0)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_UL_CP_RX(0)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_tx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_tx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;

        CNT_ON_TIME                 => UL_CP_RX_ON_TIME(0)                     ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => UL_CP_RX_EARLY(0)                       ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => UL_CP_RX_LATE(0)                        ,--: out std_logic_vector(63 downto 0);
        CNT_NDM                     => UL_CP_RX_NDM(0)                         ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;
        UPDATE_EN_OUT               => open,
        PACKET_EN                   => RX_PACKET_IS_CP_UL                      ,--: in  std_logic;
        PACKET_IS_NDM               => RX_PACKET_IS_NDM                        ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );
    end generate;

    u_RX_WINDOW_30kHz : if SCS_CONFIG_1 = true generate
    u_CP_DL : RX_WINDOW
    generic map(
        SCS_CONFIG                  => 1                                        --: natural := 0
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_DL_CP_RX(1)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_DL_CP_RX(1)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_rx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_rx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;
        UPDATE_EN_OUT               => rx_window_update_en(1),
        CNT_ON_TIME                 => DL_CP_RX_ON_TIME(1)                     ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => DL_CP_RX_EARLY(1)                       ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => DL_CP_RX_LATE(1)                        ,--: out std_logic_vector(63 downto 0);
        CNT_NDM                     => DL_CP_RX_NDM(1)                         ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;

        PACKET_EN                   => RX_PACKET_IS_CP_DL                      ,--: in  std_logic;
        PACKET_IS_NDM               => RX_PACKET_IS_NDM                        ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );

    u_UP_DL : RX_WINDOW
    generic map(
        SCS_CONFIG                  => 1                                        --: natural := 0
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_DL_UP_RX(1)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_DL_UP_RX(1)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_rx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_rx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;

        CNT_ON_TIME                 => DL_UP_RX_ON_TIME(1)                     ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => DL_UP_RX_EARLY(1)                       ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => DL_UP_RX_LATE(1)                        ,--: out std_logic_vector(63 downto 0);
        CNT_NDM                     => DL_UP_RX_NDM(1)                         ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;
        UPDATE_EN_OUT               => open,
        PACKET_EN                   => RX_PACKET_IS_UP_DL                      ,--: in  std_logic;
        PACKET_IS_NDM               => RX_PACKET_IS_NDM                        ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );

    u_CP_UL : RX_WINDOW
    generic map(
        SCS_CONFIG                  => 1                                        --: natural := 0
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_UL_CP_RX(1)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_UL_CP_RX(1)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_tx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_tx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;

        CNT_ON_TIME                 => UL_CP_RX_ON_TIME(1)                     ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => UL_CP_RX_EARLY(1)                       ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => UL_CP_RX_LATE(1)                        ,--: out std_logic_vector(63 downto 0);
        CNT_NDM                     => UL_CP_RX_NDM(1)                         ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;
        UPDATE_EN_OUT               => open,
        PACKET_EN                   => RX_PACKET_IS_CP_UL                      ,--: in  std_logic;
        PACKET_IS_NDM               => RX_PACKET_IS_NDM                        ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );
    end generate;

    u_RX_WINDOW_60kHz : if SCS_CONFIG_2 = true generate
    u_CP_DL : RX_WINDOW
    generic map(
        SCS_CONFIG                  => 2                                        --: natural := 0
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_DL_CP_RX(2)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_DL_CP_RX(2)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_rx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_rx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;

        CNT_ON_TIME                 => DL_CP_RX_ON_TIME(2)                     ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => DL_CP_RX_EARLY(2)                       ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => DL_CP_RX_LATE(2)                        ,--: out std_logic_vector(63 downto 0);
        CNT_NDM                     => DL_CP_RX_NDM(2)                         ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;
        UPDATE_EN_OUT               => rx_window_update_en(2),
        PACKET_EN                   => RX_PACKET_IS_CP_DL                      ,--: in  std_logic;
        PACKET_IS_NDM               => RX_PACKET_IS_NDM                        ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );

    u_UP_DL : RX_WINDOW
    generic map(
        SCS_CONFIG                  => 2                                        --: natural := 0
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_DL_UP_RX(2)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_DL_UP_RX(2)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_rx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_rx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;

        CNT_ON_TIME                 => DL_UP_RX_ON_TIME(2)                     ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => DL_UP_RX_EARLY(2)                       ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => DL_UP_RX_LATE(2)                        ,--: out std_logic_vector(63 downto 0);
        CNT_NDM                     => DL_UP_RX_NDM(2)                         ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;
        UPDATE_EN_OUT               => open,
        PACKET_EN                   => RX_PACKET_IS_UP_DL                      ,--: in  std_logic;
        PACKET_IS_NDM               => RX_PACKET_IS_NDM                        ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );

    u_CP_UL : RX_WINDOW
    generic map(
        SCS_CONFIG                  => 2                                        --: natural := 0
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_UL_CP_RX(2)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_UL_CP_RX(2)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_tx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_tx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;

        CNT_ON_TIME                 => UL_CP_RX_ON_TIME(2)                     ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => UL_CP_RX_EARLY(2)                       ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => UL_CP_RX_LATE(2)                        ,--: out std_logic_vector(63 downto 0);
        CNT_NDM                     => UL_CP_RX_NDM(2)                         ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;
        UPDATE_EN_OUT               => open,
        PACKET_EN                   => RX_PACKET_IS_CP_UL                      ,--: in  std_logic;
        PACKET_IS_NDM               => RX_PACKET_IS_NDM                        ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );
    end generate;

    u_RX_WINDOW_120kHz : if SCS_CONFIG_3 = true generate
    u_CP_DL : RX_WINDOW
    generic map(
        SCS_CONFIG                  => 3                                        --: natural := 0
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_DL_CP_RX(3)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_DL_CP_RX(3)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_rx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_rx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;

        CNT_ON_TIME                 => DL_CP_RX_ON_TIME(3)                     ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => DL_CP_RX_EARLY(3)                       ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => DL_CP_RX_LATE(3)                        ,--: out std_logic_vector(63 downto 0);
        CNT_NDM                     => DL_CP_RX_NDM(3)                         ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;
        UPDATE_EN_OUT               => rx_window_update_en(3),
        PACKET_EN                   => RX_PACKET_IS_CP_DL                      ,--: in  std_logic;
        PACKET_IS_NDM               => RX_PACKET_IS_NDM                        ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );

    u_UP_DL : RX_WINDOW
    generic map(
        SCS_CONFIG                  => 3                                        --: natural := 0
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_DL_UP_RX(3)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_DL_UP_RX(3)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_rx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_rx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;

        CNT_ON_TIME                 => DL_UP_RX_ON_TIME(3)                     ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => DL_UP_RX_EARLY(3)                       ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => DL_UP_RX_LATE(3)                        ,--: out std_logic_vector(63 downto 0);
        CNT_NDM                     => DL_UP_RX_NDM(3)                         ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;
        UPDATE_EN_OUT               => open,
        PACKET_EN                   => RX_PACKET_IS_UP_DL                      ,--: in  std_logic;
        PACKET_IS_NDM               => RX_PACKET_IS_NDM                        ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );

    u_CP_UL : RX_WINDOW
    generic map(
        SCS_CONFIG                  => 3                                        --: natural := 0
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_UL_CP_RX(3)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_UL_CP_RX(3)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_tx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_tx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;

        CNT_ON_TIME                 => UL_CP_RX_ON_TIME(3)                     ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => UL_CP_RX_EARLY(3)                       ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => UL_CP_RX_LATE(3)                        ,--: out std_logic_vector(63 downto 0);
        CNT_NDM                     => UL_CP_RX_NDM(3)                         ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;
        UPDATE_EN_OUT               => open,
        PACKET_EN                   => RX_PACKET_IS_CP_UL                      ,--: in  std_logic;
        PACKET_IS_NDM               => RX_PACKET_IS_NDM                        ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );
    end generate;

    u_RX_WINDOW_240kHz : if SCS_CONFIG_4 = true generate
    u_CP_DL : RX_WINDOW
    generic map(
        SCS_CONFIG                  => 4                                        --: natural := 0
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_DL_CP_RX(4)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_DL_CP_RX(4)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_rx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_rx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;

        CNT_ON_TIME                 => DL_CP_RX_ON_TIME(4)                     ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => DL_CP_RX_EARLY(4)                       ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => DL_CP_RX_LATE(4)                        ,--: out std_logic_vector(63 downto 0);
        CNT_NDM                     => DL_CP_RX_NDM(4)                         ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;
        UPDATE_EN_OUT               => rx_window_update_en(4),
        PACKET_EN                   => RX_PACKET_IS_CP_DL                      ,--: in  std_logic;
        PACKET_IS_NDM               => RX_PACKET_IS_NDM                        ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );

    u_UP_DL : RX_WINDOW
    generic map(
        SCS_CONFIG                  => 4                                        --: natural := 0
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_DL_UP_RX(4)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_DL_UP_RX(4)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_rx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_rx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;

        CNT_ON_TIME                 => DL_UP_RX_ON_TIME(4)                     ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => DL_UP_RX_EARLY(4)                       ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => DL_UP_RX_LATE(4)                        ,--: out std_logic_vector(63 downto 0);
        CNT_NDM                     => DL_UP_RX_NDM(4)                         ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;
        UPDATE_EN_OUT               => open,
        PACKET_EN                   => RX_PACKET_IS_UP_DL                      ,--: in  std_logic;
        PACKET_IS_NDM               => RX_PACKET_IS_NDM                        ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );

    u_CP_UL : RX_WINDOW
    generic map(
        SCS_CONFIG                  => 4                                        --: natural := 0
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_UL_CP_RX(4)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_UL_CP_RX(4)                     ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_tx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_tx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;

        CNT_ON_TIME                 => UL_CP_RX_ON_TIME(4)                     ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => UL_CP_RX_EARLY(4)                       ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => UL_CP_RX_LATE(4)                        ,--: out std_logic_vector(63 downto 0);
        CNT_NDM                     => UL_CP_RX_NDM(4)                         ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;
        UPDATE_EN_OUT               => open,
        PACKET_EN                   => RX_PACKET_IS_CP_UL                      ,--: in  std_logic;
        PACKET_IS_NDM               => RX_PACKET_IS_NDM                        ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );
    end generate;

    UL_CP_TX_TOTAL                  <= (others => '0');

    tx_packet_en(0)                 <= TX0_PACKET_EXIST;
    tx_packet_en(1)                 <= TX1_PACKET_EXIST;
    tx_packet_en(2)                 <= TX2_PACKET_EXIST;
    tx_packet_en(3)                 <= TX3_PACKET_EXIST;
    tx_packet_en(4)                 <= TX4_PACKET_EXIST;
    tx_packet_en(5)                 <= TX5_PACKET_EXIST;
    tx_packet_en(6)                 <= TX6_PACKET_EXIST;
    tx_packet_en(7)                 <= TX7_PACKET_EXIST;
    tx_packet_en(8)                 <= TX8_PACKET_EXIST;
    tx_packet_en(9)                 <= TX9_PACKET_EXIST;
    tx_packet_en(10)                <= TX10_PACKET_EXIST;
    tx_packet_en(11)                <= TX11_PACKET_EXIST;
    tx_packet_en(12)                <= TX12_PACKET_EXIST;
    tx_packet_en(13)                <= TX13_PACKET_EXIST;
    tx_packet_en(14)                <= TX14_PACKET_EXIST;
    tx_packet_en(15)                <= TX15_PACKET_EXIST;
    tx_packet_en(16)                <= TX16_PACKET_EXIST;
    tx_packet_en(17)                <= TX17_PACKET_EXIST;
    tx_packet_en(18)                <= TX18_PACKET_EXIST;
    tx_packet_en(19)                <= TX19_PACKET_EXIST;

    u_TX : TX_STAT
    generic map(
        NUM_TX                      => NUM_TX                                   --: natural := 6
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_tx_window                           ,--: in  std_logic;

        CNT_CLEAR                   => STAT_CNT_CLEAR                          ,--: in  std_logic;

        CNT_TOTAL                   => UL_UP_TX_TOTAL                          ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => TX_PACKET_CLK                           ,--: in  std_logic;

        PACKET_EN                   => tx_packet_en(NUM_TX-1 downto 0)          --: in  std_logic_vector(NUM_TX-1 downto 0)
    );

end BEHAVE;