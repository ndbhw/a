------------------------------------------------------------------------------
-- user_logic.vhd - entity/architecture pair
------------------------------------------------------------------------------
--
-- ***************************************************************************
-- ** Copyright (c) 1995-2012 Xilinx, Inc.  All rights reserved.            **
-- **                                                                       **
-- ** Xilinx, Inc.                                                          **
-- ** XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"         **
-- ** AS A COURTESY TO YOU, SOLELY FOR USE IN DEVELOPING PROGRAMS AND       **
-- ** SOLUTIONS FOR XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE,        **
-- ** OR INFORMATION AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE,        **
-- ** APPLICATION OR STANDARD, XILINX IS MAKING NO REPRESENTATION           **
-- ** THAT THIS IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,     **
-- ** AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE      **
-- ** FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY              **
-- ** WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE               **
-- ** IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR        **
-- ** REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF       **
-- ** INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       **
-- ** FOR A PARTICULAR PURPOSE.                                             **
-- **                                                                       **
-- ***************************************************************************
--
------------------------------------------------------------------------------
-- Filename:          user_logic.vhd
-- Version:           1.00.a
-- Description:       User logic.
-- Date:              Mon Jul 03 07:27:28 2017 (by Create and Import Peripheral Wizard)
-- VHDL Standard:     VHDL'93
------------------------------------------------------------------------------
-- Naming Conventions:
--   active low signals:                    "*_n"
--   clock signals:                         "clk", "clk_div#", "clk_#x"
--   reset signals:                         "rst", "rst_n"
--   generics:                              "C_*"
--   user defined types:                    "*_TYPE"
--   state machine next state:              "*_ns"
--   state machine current state:           "*_cs"
--   combinatorial signals:                 "*_com"
--   pipelined or register delay signals:   "*_d#"
--   counter signals:                       "*cnt*"
--   clock enable signals:                  "*_ce"
--   internal version of output port:       "*_i"
--   device pins:                           "*_pin"
--   ports:                                 "- Names begin with Uppercase"
--   processes:                             "*_PROCESS"
--   component instantiations:              "<ENTITY_>I_<#|FUNC>"
------------------------------------------------------------------------------

-- DO NOT EDIT BELOW THIS LINE --------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

library proc_common_v3_00_a;
use proc_common_v3_00_a.proc_common_pkg.all;

-- DO NOT EDIT ABOVE THIS LINE --------------------

--USER libraries added here

------------------------------------------------------------------------------
-- Entity section
------------------------------------------------------------------------------
-- Definition of Generics:
--   C_SLV_AWIDTH                 -- Slave interface address bus width
--   C_SLV_DWIDTH                 -- Slave interface data bus width
--   C_NUM_MEM                    -- Number of memory spaces
--
-- Definition of Ports:
--   Bus2IP_Clk                   -- Bus to IP clock
--   Bus2IP_Resetn                -- Bus to IP reset
--   Bus2IP_Addr                  -- Bus to IP address bus
--   Bus2IP_CS                    -- Bus to IP chip select for user logic memory selection
--   Bus2IP_RNW                   -- Bus to IP read/not write
--   Bus2IP_Data                  -- Bus to IP data bus
--   Bus2IP_BE                    -- Bus to IP byte enables
--   Bus2IP_RdCE                  -- Bus to IP read chip enable
--   Bus2IP_WrCE                  -- Bus to IP write chip enable
--   Bus2IP_Burst                 -- Bus to IP burst-mode qualifier
--   Bus2IP_BurstLength           -- Bus to IP burst length
--   Bus2IP_RdReq                 -- Bus to IP read request
--   Bus2IP_WrReq                 -- Bus to IP write request
--   Type_of_xfer                 -- Transfer Type
--   IP2Bus_AddrAck               -- IP to Bus address acknowledgement
--   IP2Bus_Data                  -- IP to Bus data bus
--   IP2Bus_RdAck                 -- IP to Bus read transfer acknowledgement
--   IP2Bus_WrAck                 -- IP to Bus write transfer acknowledgement
--   IP2Bus_Error                 -- IP to Bus error response
------------------------------------------------------------------------------

entity user_logic is
  generic
  (
    -- ADD USER GENERICS BELOW THIS LINE ---------------
    --USER generics added here
    -- ADD USER GENERICS ABOVE THIS LINE ---------------
    C_TIMEOUT_CNTR_VAL             : integer              := 8;

    -- DO NOT EDIT BELOW THIS LINE ---------------------
    -- Bus protocol parameters, do not add to or delete
    C_SLV_AWIDTH                   : integer              := 32;
    C_SLV_DWIDTH                   : integer              := 32;
    C_NUM_MEM                      : integer              := 1
    -- DO NOT EDIT ABOVE THIS LINE ---------------------
  );
  port
  (
    -- ADD USER PORTS BELOW THIS LINE ------------------
    --USER ports added here
    -- ADD USER PORTS ABOVE THIS LINE ------------------
    user_cs                        : out std_logic;
    user_rd                        : out std_logic;
    user_wr                        : out std_logic;
    user_clk                       : out std_logic;
    user_add                       : out std_logic_vector(19 downto 0);
    user_read_data                 : in  std_logic_vector(31 downto 0);
    user_write_data                : out std_logic_vector(31 downto 0);

    -- DO NOT EDIT BELOW THIS LINE ---------------------
    -- Bus protocol ports, do not add to or delete
    Bus2IP_Clk                     : in  std_logic;
    Bus2IP_Resetn                  : in  std_logic;
    Bus2IP_Addr                    : in  std_logic_vector(C_SLV_AWIDTH-1 downto 0);
    Bus2IP_CS                      : in  std_logic_vector(C_NUM_MEM-1 downto 0);
    Bus2IP_RNW                     : in  std_logic;
    Bus2IP_Data                    : in  std_logic_vector(C_SLV_DWIDTH-1 downto 0);
    Bus2IP_BE                      : in  std_logic_vector(C_SLV_DWIDTH/8-1 downto 0);
    Bus2IP_RdCE                    : in  std_logic_vector(C_NUM_MEM-1 downto 0);
    Bus2IP_WrCE                    : in  std_logic_vector(C_NUM_MEM-1 downto 0);
    Bus2IP_Burst                   : in  std_logic;
    Bus2IP_BurstLength             : in  std_logic_vector(7 downto 0);
    Bus2IP_RdReq                   : in  std_logic;
    Bus2IP_WrReq                   : in  std_logic;
    Type_of_xfer                   : in  std_logic;
    IP2Bus_AddrAck                 : out std_logic;
    IP2Bus_Data                    : out std_logic_vector(C_SLV_DWIDTH-1 downto 0);
    IP2Bus_RdAck                   : out std_logic;
    IP2Bus_WrAck                   : out std_logic;
    IP2Bus_Error                   : out std_logic
    -- DO NOT EDIT ABOVE THIS LINE ---------------------
  );

  attribute MAX_FANOUT : string;
  attribute SIGIS : string;

  attribute SIGIS of Bus2IP_Clk    : signal is "CLK";
  attribute SIGIS of Bus2IP_Resetn : signal is "RST";

end entity user_logic;

------------------------------------------------------------------------------
-- Architecture section
------------------------------------------------------------------------------

architecture IMP of user_logic is

  --USER signal declarations added here, as needed for user logic

  signal wait_max_value                 : std_logic_vector(4 downto 0);

  signal write_ack_cnt                  : std_logic_vector(4 downto 0);
  signal write_burst_cnt                : std_logic_vector(7 downto 0);

  signal user_write_ack                 : std_logic;
  signal user_write_enable              : std_logic;

  signal read_ack_cnt                   : std_logic_vector(4 downto 0);
  signal read_burst_cnt                 : std_logic_vector(7 downto 0);

  signal user_read_ack                  : std_logic;
  signal user_read_enable               : std_logic;

begin

  --USER logic implementation added here
  wait_max_value <= conv_std_logic_vector(C_TIMEOUT_CNTR_VAL, 5);

  user_cs         <= Bus2IP_CS(0);
  user_rd         <= user_read_enable;
  user_wr         <= user_write_enable;
  user_clk        <= Bus2IP_Clk;
  user_add        <= Bus2IP_Addr(21 downto 2);
  user_write_data <= Bus2IP_Data;

--WRITE
  USER_WRITE_CNT_PROC : process( Bus2IP_Clk ) is
  begin
    if ( Bus2IP_Clk'event and Bus2IP_Clk = '1' ) then
      if ( Bus2IP_Resetn = '0' ) then
        write_ack_cnt <= (others => '0');
      else
        if(Bus2IP_WrCE(0) = '1')then
          if(write_ack_cnt = wait_max_value - 1)then
            write_ack_cnt <= (others => '0');
          else
            write_ack_cnt <= write_ack_cnt + 1;
          end if;
        else
          write_ack_cnt <= (others => '0');
        end if;
      end if;
    end if;
  end process USER_WRITE_CNT_PROC;

  USER_WRITE_BURST_CNT_PROC : process( Bus2IP_Clk ) is
  begin
    if ( Bus2IP_Clk'event and Bus2IP_Clk = '1' ) then
      if ( Bus2IP_Resetn = '0' ) then
        write_burst_cnt <= (others => '0');
      else
        if(Bus2IP_WrCE(0) = '1')then
          if(write_ack_cnt = wait_max_value - 1)then
            write_burst_cnt <= write_burst_cnt + 1;
          end if;
        else
          write_burst_cnt <= (others => '0');
        end if;
      end if;
    end if;
  end process USER_WRITE_BURST_CNT_PROC;

  USER_WRITE_ACK_PROC : process( Bus2IP_Clk ) is
  begin
    if ( Bus2IP_Clk'event and Bus2IP_Clk = '1' ) then
      if ( Bus2IP_Resetn = '0' ) then
        user_write_ack <= '0';
      else
        if(Bus2IP_WrCE(0) = '1')then
          if(write_ack_cnt = wait_max_value - 2)then
            user_write_ack <= '1';
          else
            user_write_ack <= '0';
          end if;
        else
          user_write_ack <= '0';
        end if;
      end if;
    end if;
  end process USER_WRITE_ACK_PROC;

  USER_WRITE_EN_PROC : process( Bus2IP_Clk ) is
  begin
    if ( Bus2IP_Clk'event and Bus2IP_Clk = '1' ) then
      if ( Bus2IP_Resetn = '0' ) then
        user_write_enable <= '0';
      else
        if(Bus2IP_WrCE(0) = '1')then
          if(write_ack_cnt = 1)then
            user_write_enable <= '1';
          elsif(write_ack_cnt = wait_max_value - 1)then
            user_write_enable <= '0';
          end if;
        else
          user_write_enable <= '0';
        end if;
      end if;
    end if;
  end process USER_WRITE_EN_PROC;

--READ
  USER_READ_CNT_PROC : process( Bus2IP_Clk ) is
  begin
    if ( Bus2IP_Clk'event and Bus2IP_Clk = '1' ) then
      if ( Bus2IP_Resetn = '0' ) then
        read_ack_cnt <= (others => '0');
      else
        if(Bus2IP_RdCE(0) = '1')then
          if(read_ack_cnt = wait_max_value - 1)then
            read_ack_cnt <= (others => '0');
          else
            read_ack_cnt <= read_ack_cnt + 1;
          end if;
        else
          read_ack_cnt <= (others => '0');
        end if;
      end if;
    end if;
  end process USER_READ_CNT_PROC;

  USER_READ_BURST_CNT_PROC : process( Bus2IP_Clk ) is
  begin
    if ( Bus2IP_Clk'event and Bus2IP_Clk = '1' ) then
      if ( Bus2IP_Resetn = '0' ) then
        read_burst_cnt <= (others => '0');
      else
        if(Bus2IP_RdCE(0) = '1')then
          if(read_ack_cnt = wait_max_value - 1)then
            read_burst_cnt <= read_burst_cnt + 1;
          end if;
        else
          read_burst_cnt <= (others => '0');
        end if;
      end if;
    end if;
  end process USER_READ_BURST_CNT_PROC;

  USER_READ_ACK_PROC : process( Bus2IP_Clk ) is
  begin
    if ( Bus2IP_Clk'event and Bus2IP_Clk = '1' ) then
      if ( Bus2IP_Resetn = '0' ) then
        user_read_ack <= '0';
      else
        if(Bus2IP_RdCE(0) = '1')then
          if(read_ack_cnt = wait_max_value - 2)then
            user_read_ack <= '1';
          else
            user_read_ack <= '0';
          end if;
        else
          user_read_ack <= '0';
        end if;
      end if;
    end if;
  end process USER_READ_ACK_PROC;

  USER_READ_EN_PROC : process( Bus2IP_Clk ) is
  begin
    if ( Bus2IP_Clk'event and Bus2IP_Clk = '1' ) then
      if ( Bus2IP_Resetn = '0' ) then
        user_read_enable <= '0';
      else
        if(Bus2IP_RdCE(0) = '1')then
          if(read_ack_cnt = 1)then
            user_read_enable <= '1';
          elsif(read_ack_cnt = wait_max_value - 1)then
            user_read_enable <= '0';
          end if;
        else
          user_read_enable <= '0';
        end if;
      end if;
    end if;
  end process USER_READ_EN_PROC;


  ------------------------------------------
  -- Example code to drive IP to Bus signals
  ------------------------------------------
  IP2Bus_Data  <= user_read_data when user_read_ack = '1' else
                  (others => '0');

  IP2Bus_AddrAck <= user_write_ack or (Bus2IP_RdCE(0) and user_read_ack);
  IP2Bus_WrAck <= user_write_ack;
  IP2Bus_RdAck <= user_read_ack;
  IP2Bus_Error <= '0';

end IMP;
