add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G1_5/hdlsrc/ltehdlMIBRecovery/HDL_LTE_MIB_Recovery_tc.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G1_5/hdlsrc/ltehdlMIBRecovery/Detect_Rise_Positive.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G1_5/hdlsrc/ltehdlMIBRecovery/Detect_Rise_Positive1.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G1_5/hdlsrc/ltehdlMIBRecovery/MIB_Decoder.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G1_5/hdlsrc/ltehdlMIBRecovery/HDL_LTE_MIB_Recovery.vhd
