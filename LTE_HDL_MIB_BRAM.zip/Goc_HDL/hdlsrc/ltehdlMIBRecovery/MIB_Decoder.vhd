-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlChannelEqualizer;
LIBRARY work_ltehdlPBCHDecoder;
LIBRARY work_ltehdlPBCHIndexing;
LIBRARY work_ltehdlResourceGrid;

ENTITY MIB_Decoder IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        enb_1_2_1                         :   IN    std_logic;
        NcellID                           :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        cellDetected                      :   IN    std_logic;
        Nsubframe                         :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        OFDMdata_gridData_re              :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        OFDMdata_gridData_im              :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        OFDMdata_gridDataValid            :   IN    std_logic;
        restart                           :   IN    std_logic;
        NDLRB                             :   OUT   std_logic_vector(6 DOWNTO 0);  -- ufix7
        PHICH                             :   OUT   std_logic;
        Ng                                :   OUT   std_logic_vector(1 DOWNTO 0);  -- ufix2
        NFrame                            :   OUT   std_logic_vector(9 DOWNTO 0);  -- ufix10
        CellRefP                          :   OUT   std_logic_vector(2 DOWNTO 0);  -- ufix3
        mibDetected                       :   OUT   std_logic;
        mibError                          :   OUT   std_logic
        );
END MIB_Decoder;


ARCHITECTURE rtl OF MIB_Decoder IS

  -- Component Declarations
  COMPONENT Detect_Rise_Positive
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          U_U                             :   IN    std_logic;
          Y_Y                             :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT Detect_Rise_Positive1
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          U_U                             :   IN    std_logic;
          Y_Y                             :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHIndexing
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          cellID                          :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          start                           :   IN    std_logic;
          addr_rd_addr                    :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          addr_rd_bank                    :   OUT   std_logic_vector(3 DOWNTO 0);  -- ufix4
          addr_rd_en                      :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlResourceGrid
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          rst                             :   IN    std_logic;
          OFDMdata_gridData_re            :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          OFDMdata_gridData_im            :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          OFDMdata_gridDataValid          :   IN    std_logic;
          writeSubframe                   :   IN    std_logic;
          NcellID                         :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          NDLRB                           :   IN    std_logic_vector(6 DOWNTO 0);  -- ufix7
          rd_bus_rd_addr                  :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
          rd_bus_rd_bank                  :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          rd_bus_rd_en                    :   IN    std_logic;
          gridData_gridData_re            :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          gridData_gridData_im            :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          gridData_gridDataValid          :   OUT   std_logic;
          hestReadAddr                    :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          gridWriteDone                   :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlChannelEqualizer
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          enb_1_2_1                       :   IN    std_logic;
          cellDetected                    :   IN    std_logic;
          NCellID                         :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          NSubframe                       :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          NDLRB                           :   IN    std_logic_vector(6 DOWNTO 0);  -- ufix7
          gridData_gridData_re            :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          gridData_gridData_im            :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          gridData_gridDataValid          :   IN    std_logic;
          hestRdAddr                      :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
          gridWriteDone                   :   IN    std_logic;
          eqSymbols_eqSymbols_re          :   OUT   std_logic_vector(17 DOWNTO 0);  -- sfix18_En17
          eqSymbols_eqSymbols_im          :   OUT   std_logic_vector(17 DOWNTO 0);  -- sfix18_En17
          eqSymbols_eqSymbolsValid        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          enb_1_2_1                       :   IN    std_logic;
          NCellID                         :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          symbols_eqSymbols_re            :   IN    std_logic_vector(17 DOWNTO 0);  -- sfix18_En17
          symbols_eqSymbols_im            :   IN    std_logic_vector(17 DOWNTO 0);  -- sfix18_En17
          symbols_eqSymbolsValid          :   IN    std_logic;
          enableDecoder                   :   IN    std_logic;
          clearOutputReg                  :   IN    std_logic;
          NDLRB                           :   OUT   std_logic_vector(6 DOWNTO 0);  -- ufix7
          PHICH                           :   OUT   std_logic;
          Ng                              :   OUT   std_logic_vector(1 DOWNTO 0);  -- ufix2
          NFrame                          :   OUT   std_logic_vector(9 DOWNTO 0);  -- ufix10
          CellRefP                        :   OUT   std_logic_vector(2 DOWNTO 0);  -- ufix3
          MIBDetected                     :   OUT   std_logic;
          MIBError                        :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : Detect_Rise_Positive
    USE ENTITY work.Detect_Rise_Positive(rtl);

  FOR ALL : Detect_Rise_Positive1
    USE ENTITY work.Detect_Rise_Positive1(rtl);

  FOR ALL : ltehdlPBCHIndexing
    USE ENTITY work_ltehdlPBCHIndexing.ltehdlPBCHIndexing_ltehdlPBCHIndexing(rtl);

  FOR ALL : ltehdlResourceGrid
    USE ENTITY work_ltehdlResourceGrid.ltehdlResourceGrid_ltehdlResourceGrid(rtl);

  FOR ALL : ltehdlChannelEqualizer
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_ltehdlChannelEqualizer(rtl);

  FOR ALL : ltehdlPBCHDecoder
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_ltehdlPBCHDecoder(rtl);

  -- Signals
  SIGNAL Detect_Rise_Positive1_Y          : std_logic;
  SIGNAL PBCH_Indexing_addr_rd_addr       : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL PBCH_Indexing_addr_rd_bank       : std_logic_vector(3 DOWNTO 0);  -- ufix4
  SIGNAL PBCH_Indexing_addr_rd_en         : std_logic;
  SIGNAL Detect_Rise_Positive_Y           : std_logic;
  SIGNAL Compare_To_Constant1_out1        : std_logic;
  SIGNAL Delay1_out1_rd_en                : std_logic := '0';
  SIGNAL Resource_Grid_Memory_gridData_gridData_re : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL Resource_Grid_Memory_gridData_gridData_im : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL Resource_Grid_Memory_gridData_gridDataValid : std_logic;
  SIGNAL Resource_Grid_Memory_hestReadAddr : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL Resource_Grid_Memory_gridWriteDone : std_logic;
  SIGNAL eqSymb_eqSymbols_re              : std_logic_vector(17 DOWNTO 0);  -- ufix18
  SIGNAL eqSymb_eqSymbols_im              : std_logic_vector(17 DOWNTO 0);  -- ufix18
  SIGNAL eqSymb_eqSymbolsValid            : std_logic;
  SIGNAL Constant_out1                    : std_logic;
  SIGNAL OR_out1                          : std_logic;
  SIGNAL PBCH_Decoder_NDLRB               : std_logic_vector(6 DOWNTO 0);  -- ufix7
  SIGNAL PBCH_Decoder_PHICH               : std_logic;
  SIGNAL PBCH_Decoder_Ng                  : std_logic_vector(1 DOWNTO 0);  -- ufix2
  SIGNAL PBCH_Decoder_NFrame              : std_logic_vector(9 DOWNTO 0);  -- ufix10
  SIGNAL PBCH_Decoder_CellRefP            : std_logic_vector(2 DOWNTO 0);  -- ufix3
  SIGNAL PBCH_Decoder_MIBDetected         : std_logic;
  SIGNAL PBCH_Decoder_MIBError            : std_logic;
  SIGNAL NcellID_unsigned                 : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL NCellID_5                        : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL NCellID_6                        : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Nsubframe_unsigned               : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL subFrameNum_1                    : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL Constant2_out1_2                 : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL subFrameNum_2                    : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL NCellID_7                        : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL NCellID_8                        : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL PBCH_Indexing_addr_rd_bank_unsigned : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL Delay1_out1_rd_bank_1            : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL PBCH_Indexing_addr_rd_addr_unsigned : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL Delay1_out1_rd_addr_1            : unsigned(10 DOWNTO 0) := to_unsigned(16#000#, 11);  -- ufix11

BEGIN
  -- DECODING
  -- INDEXING
  -- GRID

  UDetect_Rise_Positive_1 : Detect_Rise_Positive
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              U_U => cellDetected,
              Y_Y => Detect_Rise_Positive_Y
              );

  UDetect_Rise_Positive1_1 : Detect_Rise_Positive1
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              U_U => Resource_Grid_Memory_gridWriteDone,
              Y_Y => Detect_Rise_Positive1_Y
              );

  UPBCH_Indexing : ltehdlPBCHIndexing
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              cellID => std_logic_vector(NCellID_8),  -- ufix9
              start => Detect_Rise_Positive1_Y,
              addr_rd_addr => PBCH_Indexing_addr_rd_addr,  -- ufix11
              addr_rd_bank => PBCH_Indexing_addr_rd_bank,  -- ufix4
              addr_rd_en => PBCH_Indexing_addr_rd_en
              );

  UResource_Grid_Memory : ltehdlResourceGrid
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb_1_2_0 => enb_1_2_0,
              rst => Detect_Rise_Positive_Y,
              OFDMdata_gridData_re => OFDMdata_gridData_re,  -- sfix16_En15
              OFDMdata_gridData_im => OFDMdata_gridData_im,  -- sfix16_En15
              OFDMdata_gridDataValid => OFDMdata_gridDataValid,
              writeSubframe => Compare_To_Constant1_out1,
              NcellID => std_logic_vector(NCellID_7),  -- ufix9
              NDLRB => std_logic_vector(Constant2_out1_2),  -- ufix7
              rd_bus_rd_addr => std_logic_vector(Delay1_out1_rd_addr_1),  -- ufix11
              rd_bus_rd_bank => std_logic_vector(Delay1_out1_rd_bank_1),  -- ufix4
              rd_bus_rd_en => Delay1_out1_rd_en,
              gridData_gridData_re => Resource_Grid_Memory_gridData_gridData_re,  -- sfix16_En15
              gridData_gridData_im => Resource_Grid_Memory_gridData_gridData_im,  -- sfix16_En15
              gridData_gridDataValid => Resource_Grid_Memory_gridData_gridDataValid,
              hestReadAddr => Resource_Grid_Memory_hestReadAddr,  -- ufix11
              gridWriteDone => Resource_Grid_Memory_gridWriteDone
              );

  UChannel_Equalization : ltehdlChannelEqualizer
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              enb_1_2_0 => enb_1_2_0,
              enb_1_2_1 => enb_1_2_1,
              cellDetected => Detect_Rise_Positive_Y,
              NCellID => std_logic_vector(NCellID_6),  -- ufix9
              NSubframe => std_logic_vector(subFrameNum_1),  -- ufix4
              NDLRB => std_logic_vector(Constant2_out1_2),  -- ufix7
              gridData_gridData_re => Resource_Grid_Memory_gridData_gridData_re,  -- sfix16_En15
              gridData_gridData_im => Resource_Grid_Memory_gridData_gridData_im,  -- sfix16_En15
              gridData_gridDataValid => Resource_Grid_Memory_gridData_gridDataValid,
              hestRdAddr => Resource_Grid_Memory_hestReadAddr,  -- ufix11
              gridWriteDone => Resource_Grid_Memory_gridWriteDone,
              eqSymbols_eqSymbols_re => eqSymb_eqSymbols_re,  -- sfix18_En17
              eqSymbols_eqSymbols_im => eqSymb_eqSymbols_im,  -- sfix18_En17
              eqSymbols_eqSymbolsValid => eqSymb_eqSymbolsValid
              );

  UPBCH_Decoder : ltehdlPBCHDecoder
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              enb_1_2_0 => enb_1_2_0,
              enb_1_2_1 => enb_1_2_1,
              NCellID => std_logic_vector(NCellID_5),  -- ufix9
              symbols_eqSymbols_re => eqSymb_eqSymbols_re,  -- sfix18_En17
              symbols_eqSymbols_im => eqSymb_eqSymbols_im,  -- sfix18_En17
              symbols_eqSymbolsValid => eqSymb_eqSymbolsValid,
              enableDecoder => Constant_out1,
              clearOutputReg => OR_out1,
              NDLRB => PBCH_Decoder_NDLRB,  -- ufix7
              PHICH => PBCH_Decoder_PHICH,
              Ng => PBCH_Decoder_Ng,  -- ufix2
              NFrame => PBCH_Decoder_NFrame,  -- ufix10
              CellRefP => PBCH_Decoder_CellRefP,  -- ufix3
              MIBDetected => PBCH_Decoder_MIBDetected,
              MIBError => PBCH_Decoder_MIBError
              );

  NcellID_unsigned <= unsigned(NcellID);

  NCellID_5 <= NcellID_unsigned;

  NCellID_6 <= unsigned(NcellID);

  Nsubframe_unsigned <= unsigned(Nsubframe);

  subFrameNum_1 <= Nsubframe_unsigned;

  Constant2_out1_2 <= to_unsigned(16#06#, 7);

  subFrameNum_2 <= unsigned(Nsubframe);

  
  Compare_To_Constant1_out1 <= '1' WHEN subFrameNum_2 = to_unsigned(16#0#, 4) ELSE
      '0';

  NCellID_7 <= unsigned(NcellID);

  NCellID_8 <= unsigned(NcellID);

  c_c_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_out1_rd_en <= PBCH_Indexing_addr_rd_en;
      END IF;
    END IF;
  END PROCESS c_c_process;


  PBCH_Indexing_addr_rd_bank_unsigned <= unsigned(PBCH_Indexing_addr_rd_bank);

  c_c_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_out1_rd_bank_1 <= PBCH_Indexing_addr_rd_bank_unsigned;
      END IF;
    END IF;
  END PROCESS c_c_1_process;


  PBCH_Indexing_addr_rd_addr_unsigned <= unsigned(PBCH_Indexing_addr_rd_addr);

  c_c_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_out1_rd_addr_1 <= PBCH_Indexing_addr_rd_addr_unsigned;
      END IF;
    END IF;
  END PROCESS c_c_2_process;


  Constant_out1 <= '1';

  OR_out1 <= Detect_Rise_Positive_Y OR restart;

  NDLRB <= PBCH_Decoder_NDLRB;

  PHICH <= PBCH_Decoder_PHICH;

  Ng <= PBCH_Decoder_Ng;

  NFrame <= PBCH_Decoder_NFrame;

  CellRefP <= PBCH_Decoder_CellRefP;

  mibDetected <= PBCH_Decoder_MIBDetected;

  mibError <= PBCH_Decoder_MIBError;

END rtl;

