-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlResourceGrid_repeat1 IS
  PORT( alpha1                            :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
        alpha14_0                         :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        alpha14_1                         :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        alpha14_2                         :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        alpha14_3                         :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        alpha14_4                         :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        alpha14_5                         :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        alpha14_6                         :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        alpha14_7                         :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        alpha14_8                         :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        alpha14_9                         :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        alpha14_10                        :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        alpha14_11                        :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        alpha14_12                        :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        alpha14_13                        :   OUT   std_logic_vector(10 DOWNTO 0)  -- ufix11
        );
END ltehdlResourceGrid_repeat1;


ARCHITECTURE rtl OF ltehdlResourceGrid_repeat1 IS

BEGIN
  alpha14_0 <= alpha1;

  alpha14_1 <= alpha1;

  alpha14_2 <= alpha1;

  alpha14_3 <= alpha1;

  alpha14_4 <= alpha1;

  alpha14_5 <= alpha1;

  alpha14_6 <= alpha1;

  alpha14_7 <= alpha1;

  alpha14_8 <= alpha1;

  alpha14_9 <= alpha1;

  alpha14_10 <= alpha1;

  alpha14_11 <= alpha1;

  alpha14_12 <= alpha1;

  alpha14_13 <= alpha1;

END rtl;

