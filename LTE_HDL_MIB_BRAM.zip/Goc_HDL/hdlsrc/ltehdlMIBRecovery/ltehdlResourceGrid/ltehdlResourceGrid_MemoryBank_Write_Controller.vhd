-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlResourceGrid;

ENTITY ltehdlResourceGrid_MemoryBank_Write_Controller IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        rst                               :   IN    std_logic;
        ofdmData_gridData_re              :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        ofdmData_gridData_im              :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        ofdmData_gridDataValid            :   IN    std_logic;
        writeSubframe                     :   IN    std_logic;
        data_in_mem_re                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_in_mem_im                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        wr_addr                           :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        wr_en_flag                        :   OUT   std_logic_vector(13 DOWNTO 0);  -- ufix14
        wr_done                           :   OUT   std_logic
        );
END ltehdlResourceGrid_MemoryBank_Write_Controller;


ARCHITECTURE rtl OF ltehdlResourceGrid_MemoryBank_Write_Controller IS

  -- Component Declarations
  COMPONENT ltehdlResourceGrid_LTE_Memory_Bank_Write_Controller
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          rst                             :   IN    std_logic;
          data_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          data_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          enb_1                           :   IN    std_logic;
          data_in_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          data_in_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          wr_addr                         :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          wr_en_flag                      :   OUT   std_logic_vector(13 DOWNTO 0);  -- ufix14
          writeDone                       :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlResourceGrid_Detect_Rise_Positive
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          U_U                             :   IN    std_logic;
          Y_Y                             :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlResourceGrid_LTE_Memory_Bank_Write_Controller
    USE ENTITY work_ltehdlResourceGrid.ltehdlResourceGrid_LTE_Memory_Bank_Write_Controller(rtl);

  FOR ALL : ltehdlResourceGrid_Detect_Rise_Positive
    USE ENTITY work_ltehdlResourceGrid.ltehdlResourceGrid_Detect_Rise_Positive(rtl);

  -- Signals
  SIGNAL gridData_re                      : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL gridData_im                      : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL gridData_re_1                    : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL gridData_im_1                    : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL gridDataValid                    : std_logic;
  SIGNAL gridWrtCtrlEn                    : std_logic;
  SIGNAL LTE_Memory_Bank_Write_Controller_data_in_re : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL LTE_Memory_Bank_Write_Controller_data_in_im : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL LTE_Memory_Bank_Write_Controller_wr_addr : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL LTE_Memory_Bank_Write_Controller_wr_en_flag : std_logic_vector(13 DOWNTO 0);  -- ufix14
  SIGNAL wrtDonePulse                     : std_logic;
  SIGNAL wrtReset                         : std_logic;
  SIGNAL Detect_Rise_Positive_Y           : std_logic;
  SIGNAL Delay_out1                       : std_logic := '0';

BEGIN
  ULTE_Memory_Bank_Write_Contr : ltehdlResourceGrid_LTE_Memory_Bank_Write_Controller
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb_1_2_0 => enb_1_2_0,
              rst => rst,
              data_re => gridData_re_1,  -- sfix16_En15
              data_im => gridData_im_1,  -- sfix16_En15
              enb_1 => gridWrtCtrlEn,
              data_in_re => LTE_Memory_Bank_Write_Controller_data_in_re,  -- sfix16_En15
              data_in_im => LTE_Memory_Bank_Write_Controller_data_in_im,  -- sfix16_En15
              wr_addr => LTE_Memory_Bank_Write_Controller_wr_addr,  -- ufix11
              wr_en_flag => LTE_Memory_Bank_Write_Controller_wr_en_flag,  -- ufix14
              writeDone => wrtDonePulse
              );

  UDetect_Rise_Positive : ltehdlResourceGrid_Detect_Rise_Positive
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              U_U => wrtReset,
              Y_Y => Detect_Rise_Positive_Y
              );

  gridData_re <= signed(ofdmData_gridData_re);

  gridData_re_1 <= std_logic_vector(gridData_re);

  gridData_im <= signed(ofdmData_gridData_im);

  gridData_im_1 <= std_logic_vector(gridData_im);

  gridDataValid <= ofdmData_gridDataValid;

  gridWrtCtrlEn <= gridDataValid AND writeSubframe;

  wrtReset <= rst OR writeSubframe;

  Delay_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF Detect_Rise_Positive_Y = '1' THEN
          Delay_out1 <= '0';
        ELSIF wrtDonePulse = '1' THEN
          Delay_out1 <= '1';
        END IF;
      END IF;
    END IF;
  END PROCESS Delay_rsvd_process;


  data_in_mem_re <= LTE_Memory_Bank_Write_Controller_data_in_re;

  data_in_mem_im <= LTE_Memory_Bank_Write_Controller_data_in_im;

  wr_addr <= LTE_Memory_Bank_Write_Controller_wr_addr;

  wr_en_flag <= LTE_Memory_Bank_Write_Controller_wr_en_flag;

  wr_done <= Delay_out1;

END rtl;

