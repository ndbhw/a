-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlResourceGrid;

ENTITY ltehdlResourceGrid_Memory_Bank IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        data_in_re                        :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_in_im                        :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        wr_addr                           :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
        wr_en                             :   IN    std_logic_vector(13 DOWNTO 0);  -- ufix14
        rd_addr                           :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
        data_out_re_0                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_re_1                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_re_2                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_re_3                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_re_4                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_re_5                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_re_6                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_re_7                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_re_8                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_re_9                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_re_10                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_re_11                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_re_12                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_re_13                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_im_0                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_im_1                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_im_2                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_im_3                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_im_4                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_im_5                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_im_6                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_im_7                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_im_8                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_im_9                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_im_10                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_im_11                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_im_12                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_out_im_13                    :   OUT   std_logic_vector(15 DOWNTO 0)  -- sfix16_En15
        );
END ltehdlResourceGrid_Memory_Bank;


ARCHITECTURE rtl OF ltehdlResourceGrid_Memory_Bank IS

  -- Component Declarations
  COMPONENT ltehdlResourceGrid_repeat
    PORT( alpha1_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha1_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_re_0                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_re_1                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_re_2                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_re_3                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_re_4                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_re_5                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_re_6                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_re_7                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_re_8                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_re_9                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_re_10                   :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_re_11                   :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_re_12                   :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_re_13                   :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_im_0                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_im_1                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_im_2                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_im_3                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_im_4                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_im_5                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_im_6                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_im_7                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_im_8                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_im_9                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_im_10                   :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_im_11                   :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_im_12                   :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          alpha14_im_13                   :   OUT   std_logic_vector(15 DOWNTO 0)  -- sfix16_En15
          );
  END COMPONENT;

  COMPONENT ltehdlResourceGrid_repeat1
    PORT( alpha1                          :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_0                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_1                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_2                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_3                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_4                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_5                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_6                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_7                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_8                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_9                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_10                      :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_11                      :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_12                      :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_13                      :   OUT   std_logic_vector(10 DOWNTO 0)  -- ufix11
          );
  END COMPONENT;

  COMPONENT ltehdlResourceGrid_repeat2
    PORT( alpha1                          :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_0                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_1                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_2                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_3                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_4                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_5                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_6                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_7                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_8                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_9                       :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_10                      :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_11                      :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_12                      :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          alpha14_13                      :   OUT   std_logic_vector(10 DOWNTO 0)  -- ufix11
          );
  END COMPONENT;

  COMPONENT ltehdlResourceGrid_SimpleDualPortRAM_generic
    GENERIC( AddrWidth                    : integer;
             DataWidth                    : integer
             );
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          wr_din_re                       :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          wr_din_im                       :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          wr_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          wr_en                           :   IN    std_logic;
          rd_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          dout_re                         :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          dout_im                         :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0)  -- generic width
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlResourceGrid_repeat
    USE ENTITY work_ltehdlResourceGrid.ltehdlResourceGrid_repeat(rtl);

  FOR ALL : ltehdlResourceGrid_repeat1
    USE ENTITY work_ltehdlResourceGrid.ltehdlResourceGrid_repeat1(rtl);

  FOR ALL : ltehdlResourceGrid_repeat2
    USE ENTITY work_ltehdlResourceGrid.ltehdlResourceGrid_repeat2(rtl);

  FOR ALL : ltehdlResourceGrid_SimpleDualPortRAM_generic
    USE ENTITY work_ltehdlResourceGrid.ltehdlResourceGrid_SimpleDualPortRAM_generic(rtl);

  -- Signals
  SIGNAL repeat_14_re_0                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_re_1                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_re_2                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_re_3                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_re_4                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_re_5                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_re_6                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_re_7                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_re_8                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_re_9                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_re_10                  : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_re_11                  : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_re_12                  : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_re_13                  : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_im_0                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_im_1                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_im_2                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_im_3                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_im_4                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_im_5                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_im_6                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_im_7                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_im_8                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_im_9                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_im_10                  : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_im_11                  : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_im_12                  : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat_14_im_13                  : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL repeat1_14_0                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat1_14_1                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat1_14_2                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat1_14_3                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat1_14_4                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat1_14_5                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat1_14_6                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat1_14_7                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat1_14_8                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat1_14_9                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat1_14_10                    : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat1_14_11                    : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat1_14_12                    : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat1_14_13                    : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL wr_en_unsigned                   : unsigned(13 DOWNTO 0);  -- ufix14
  SIGNAL dtc1                             : std_logic;  -- ufix1
  SIGNAL Data_Type_Conversion27_out1      : std_logic;
  SIGNAL repeat2_14_0                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat2_14_1                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat2_14_2                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat2_14_3                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat2_14_4                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat2_14_5                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat2_14_6                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat2_14_7                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat2_14_8                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat2_14_9                     : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat2_14_10                    : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat2_14_11                    : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat2_14_12                    : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL repeat2_14_13                    : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL pri_rd_out_1_re                  : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL pri_rd_out_1_im                  : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dtc1_1                           : std_logic;  -- ufix1_E1
  SIGNAL Extract_Bits26_out1              : std_logic;  -- ufix1
  SIGNAL Data_Type_Conversion26_out1      : std_logic;
  SIGNAL pri_rd_out_1_re_1                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL pri_rd_out_1_im_1                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dtc1_2                           : std_logic;  -- ufix1_E2
  SIGNAL Extract_Bits25_out1              : std_logic;  -- ufix1
  SIGNAL Data_Type_Conversion25_out1      : std_logic;
  SIGNAL pri_rd_out_1_re_2                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL pri_rd_out_1_im_2                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dtc1_3                           : std_logic;  -- ufix1_E3
  SIGNAL Extract_Bits24_out1              : std_logic;  -- ufix1
  SIGNAL Data_Type_Conversion24_out1      : std_logic;
  SIGNAL pri_rd_out_1_re_3                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL pri_rd_out_1_im_3                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dtc1_4                           : std_logic;  -- ufix1_E4
  SIGNAL Extract_Bits23_out1              : std_logic;  -- ufix1
  SIGNAL Data_Type_Conversion23_out1      : std_logic;
  SIGNAL pri_rd_out_1_re_4                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL pri_rd_out_1_im_4                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dtc1_5                           : std_logic;  -- ufix1_E5
  SIGNAL Extract_Bits22_out1              : std_logic;  -- ufix1
  SIGNAL Data_Type_Conversion22_out1      : std_logic;
  SIGNAL pri_rd_out_1_re_5                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL pri_rd_out_1_im_5                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dtc1_6                           : std_logic;  -- ufix1_E6
  SIGNAL Extract_Bits21_out1              : std_logic;  -- ufix1
  SIGNAL Data_Type_Conversion21_out1      : std_logic;
  SIGNAL pri_rd_out_1_re_6                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL pri_rd_out_1_im_6                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dtc1_7                           : std_logic;  -- ufix1_E7
  SIGNAL Extract_Bits14_out1              : std_logic;  -- ufix1
  SIGNAL Data_Type_Conversion20_out1      : std_logic;
  SIGNAL pri_rd_out_1_re_7                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL pri_rd_out_1_im_7                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dtc1_8                           : std_logic;  -- ufix1_E8
  SIGNAL Extract_Bits20_out1              : std_logic;  -- ufix1
  SIGNAL Data_Type_Conversion18_out1      : std_logic;
  SIGNAL pri_rd_out_1_re_8                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL pri_rd_out_1_im_8                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dtc1_9                           : std_logic;  -- ufix1_E9
  SIGNAL Extract_Bits19_out1              : std_logic;  -- ufix1
  SIGNAL Data_Type_Conversion17_out1      : std_logic;
  SIGNAL pri_rd_out_1_re_9                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL pri_rd_out_1_im_9                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dtc1_10                          : std_logic;  -- ufix1_E10
  SIGNAL Extract_Bits18_out1              : std_logic;  -- ufix1
  SIGNAL Data_Type_Conversion16_out1      : std_logic;
  SIGNAL pri_rd_out_1_re_10               : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL pri_rd_out_1_im_10               : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dtc1_11                          : std_logic;  -- ufix1_E11
  SIGNAL Extract_Bits17_out1              : std_logic;  -- ufix1
  SIGNAL Data_Type_Conversion15_out1      : std_logic;
  SIGNAL pri_rd_out_1_re_11               : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL pri_rd_out_1_im_11               : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dtc1_12                          : std_logic;  -- ufix1_E12
  SIGNAL Extract_Bits16_out1              : std_logic;  -- ufix1
  SIGNAL Data_Type_Conversion14_out1      : std_logic;
  SIGNAL pri_rd_out_1_re_12               : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL pri_rd_out_1_im_12               : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL Extract_Bits15_out1              : std_logic;  -- ufix1
  SIGNAL Data_Type_Conversion19_out1      : std_logic;
  SIGNAL pri_rd_out_1_re_13               : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL pri_rd_out_1_im_13               : std_logic_vector(15 DOWNTO 0);  -- ufix16

BEGIN
  -- make the signal 
  -- into vector of 14
  Urepeat_rsvd : ltehdlResourceGrid_repeat
    PORT MAP( alpha1_re => data_in_re,  -- sfix16_En15
              alpha1_im => data_in_im,  -- sfix16_En15
              alpha14_re_0 => repeat_14_re_0,  -- sfix16_En15
              alpha14_re_1 => repeat_14_re_1,  -- sfix16_En15
              alpha14_re_2 => repeat_14_re_2,  -- sfix16_En15
              alpha14_re_3 => repeat_14_re_3,  -- sfix16_En15
              alpha14_re_4 => repeat_14_re_4,  -- sfix16_En15
              alpha14_re_5 => repeat_14_re_5,  -- sfix16_En15
              alpha14_re_6 => repeat_14_re_6,  -- sfix16_En15
              alpha14_re_7 => repeat_14_re_7,  -- sfix16_En15
              alpha14_re_8 => repeat_14_re_8,  -- sfix16_En15
              alpha14_re_9 => repeat_14_re_9,  -- sfix16_En15
              alpha14_re_10 => repeat_14_re_10,  -- sfix16_En15
              alpha14_re_11 => repeat_14_re_11,  -- sfix16_En15
              alpha14_re_12 => repeat_14_re_12,  -- sfix16_En15
              alpha14_re_13 => repeat_14_re_13,  -- sfix16_En15
              alpha14_im_0 => repeat_14_im_0,  -- sfix16_En15
              alpha14_im_1 => repeat_14_im_1,  -- sfix16_En15
              alpha14_im_2 => repeat_14_im_2,  -- sfix16_En15
              alpha14_im_3 => repeat_14_im_3,  -- sfix16_En15
              alpha14_im_4 => repeat_14_im_4,  -- sfix16_En15
              alpha14_im_5 => repeat_14_im_5,  -- sfix16_En15
              alpha14_im_6 => repeat_14_im_6,  -- sfix16_En15
              alpha14_im_7 => repeat_14_im_7,  -- sfix16_En15
              alpha14_im_8 => repeat_14_im_8,  -- sfix16_En15
              alpha14_im_9 => repeat_14_im_9,  -- sfix16_En15
              alpha14_im_10 => repeat_14_im_10,  -- sfix16_En15
              alpha14_im_11 => repeat_14_im_11,  -- sfix16_En15
              alpha14_im_12 => repeat_14_im_12,  -- sfix16_En15
              alpha14_im_13 => repeat_14_im_13  -- sfix16_En15
              );

  -- make the signal 
  -- into vector of 14
  Urepeat1 : ltehdlResourceGrid_repeat1
    PORT MAP( alpha1 => wr_addr,  -- ufix11
              alpha14_0 => repeat1_14_0,  -- ufix11
              alpha14_1 => repeat1_14_1,  -- ufix11
              alpha14_2 => repeat1_14_2,  -- ufix11
              alpha14_3 => repeat1_14_3,  -- ufix11
              alpha14_4 => repeat1_14_4,  -- ufix11
              alpha14_5 => repeat1_14_5,  -- ufix11
              alpha14_6 => repeat1_14_6,  -- ufix11
              alpha14_7 => repeat1_14_7,  -- ufix11
              alpha14_8 => repeat1_14_8,  -- ufix11
              alpha14_9 => repeat1_14_9,  -- ufix11
              alpha14_10 => repeat1_14_10,  -- ufix11
              alpha14_11 => repeat1_14_11,  -- ufix11
              alpha14_12 => repeat1_14_12,  -- ufix11
              alpha14_13 => repeat1_14_13  -- ufix11
              );

  -- make the signal 
  -- into vector of 14
  Urepeat2 : ltehdlResourceGrid_repeat2
    PORT MAP( alpha1 => rd_addr,  -- ufix11
              alpha14_0 => repeat2_14_0,  -- ufix11
              alpha14_1 => repeat2_14_1,  -- ufix11
              alpha14_2 => repeat2_14_2,  -- ufix11
              alpha14_3 => repeat2_14_3,  -- ufix11
              alpha14_4 => repeat2_14_4,  -- ufix11
              alpha14_5 => repeat2_14_5,  -- ufix11
              alpha14_6 => repeat2_14_6,  -- ufix11
              alpha14_7 => repeat2_14_7,  -- ufix11
              alpha14_8 => repeat2_14_8,  -- ufix11
              alpha14_9 => repeat2_14_9,  -- ufix11
              alpha14_10 => repeat2_14_10,  -- ufix11
              alpha14_11 => repeat2_14_11,  -- ufix11
              alpha14_12 => repeat2_14_12,  -- ufix11
              alpha14_13 => repeat2_14_13  -- ufix11
              );

  UDual_Port_RAM_System1_bank0 : ltehdlResourceGrid_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 11,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => repeat_14_re_0,
              wr_din_im => repeat_14_im_0,
              wr_addr => repeat1_14_0,
              wr_en => Data_Type_Conversion27_out1,
              rd_addr => repeat2_14_0,
              dout_re => pri_rd_out_1_re,
              dout_im => pri_rd_out_1_im
              );

  UDual_Port_RAM_System1_bank1_4 : ltehdlResourceGrid_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 11,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => repeat_14_re_1,
              wr_din_im => repeat_14_im_1,
              wr_addr => repeat1_14_1,
              wr_en => Data_Type_Conversion26_out1,
              rd_addr => repeat2_14_1,
              dout_re => pri_rd_out_1_re_1,
              dout_im => pri_rd_out_1_im_1
              );

  UDual_Port_RAM_System1_bank2 : ltehdlResourceGrid_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 11,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => repeat_14_re_2,
              wr_din_im => repeat_14_im_2,
              wr_addr => repeat1_14_2,
              wr_en => Data_Type_Conversion25_out1,
              rd_addr => repeat2_14_2,
              dout_re => pri_rd_out_1_re_2,
              dout_im => pri_rd_out_1_im_2
              );

  UDual_Port_RAM_System1_bank3 : ltehdlResourceGrid_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 11,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => repeat_14_re_3,
              wr_din_im => repeat_14_im_3,
              wr_addr => repeat1_14_3,
              wr_en => Data_Type_Conversion24_out1,
              rd_addr => repeat2_14_3,
              dout_re => pri_rd_out_1_re_3,
              dout_im => pri_rd_out_1_im_3
              );

  UDual_Port_RAM_System1_bank4 : ltehdlResourceGrid_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 11,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => repeat_14_re_4,
              wr_din_im => repeat_14_im_4,
              wr_addr => repeat1_14_4,
              wr_en => Data_Type_Conversion23_out1,
              rd_addr => repeat2_14_4,
              dout_re => pri_rd_out_1_re_4,
              dout_im => pri_rd_out_1_im_4
              );

  UDual_Port_RAM_System1_bank5 : ltehdlResourceGrid_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 11,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => repeat_14_re_5,
              wr_din_im => repeat_14_im_5,
              wr_addr => repeat1_14_5,
              wr_en => Data_Type_Conversion22_out1,
              rd_addr => repeat2_14_5,
              dout_re => pri_rd_out_1_re_5,
              dout_im => pri_rd_out_1_im_5
              );

  UDual_Port_RAM_System1_bank6 : ltehdlResourceGrid_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 11,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => repeat_14_re_6,
              wr_din_im => repeat_14_im_6,
              wr_addr => repeat1_14_6,
              wr_en => Data_Type_Conversion21_out1,
              rd_addr => repeat2_14_6,
              dout_re => pri_rd_out_1_re_6,
              dout_im => pri_rd_out_1_im_6
              );

  UDual_Port_RAM_System1_bank7 : ltehdlResourceGrid_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 11,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => repeat_14_re_7,
              wr_din_im => repeat_14_im_7,
              wr_addr => repeat1_14_7,
              wr_en => Data_Type_Conversion20_out1,
              rd_addr => repeat2_14_7,
              dout_re => pri_rd_out_1_re_7,
              dout_im => pri_rd_out_1_im_7
              );

  UDual_Port_RAM_System1_bank8 : ltehdlResourceGrid_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 11,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => repeat_14_re_8,
              wr_din_im => repeat_14_im_8,
              wr_addr => repeat1_14_8,
              wr_en => Data_Type_Conversion18_out1,
              rd_addr => repeat2_14_8,
              dout_re => pri_rd_out_1_re_8,
              dout_im => pri_rd_out_1_im_8
              );

  UDual_Port_RAM_System1_bank9 : ltehdlResourceGrid_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 11,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => repeat_14_re_9,
              wr_din_im => repeat_14_im_9,
              wr_addr => repeat1_14_9,
              wr_en => Data_Type_Conversion17_out1,
              rd_addr => repeat2_14_9,
              dout_re => pri_rd_out_1_re_9,
              dout_im => pri_rd_out_1_im_9
              );

  UDual_Port_RAM_System1_bank1_3 : ltehdlResourceGrid_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 11,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => repeat_14_re_10,
              wr_din_im => repeat_14_im_10,
              wr_addr => repeat1_14_10,
              wr_en => Data_Type_Conversion16_out1,
              rd_addr => repeat2_14_10,
              dout_re => pri_rd_out_1_re_10,
              dout_im => pri_rd_out_1_im_10
              );

  UDual_Port_RAM_System1_bank1_2 : ltehdlResourceGrid_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 11,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => repeat_14_re_11,
              wr_din_im => repeat_14_im_11,
              wr_addr => repeat1_14_11,
              wr_en => Data_Type_Conversion15_out1,
              rd_addr => repeat2_14_11,
              dout_re => pri_rd_out_1_re_11,
              dout_im => pri_rd_out_1_im_11
              );

  UDual_Port_RAM_System1_bank1_1 : ltehdlResourceGrid_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 11,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => repeat_14_re_12,
              wr_din_im => repeat_14_im_12,
              wr_addr => repeat1_14_12,
              wr_en => Data_Type_Conversion14_out1,
              rd_addr => repeat2_14_12,
              dout_re => pri_rd_out_1_re_12,
              dout_im => pri_rd_out_1_im_12
              );

  UDual_Port_RAM_System1_bank1 : ltehdlResourceGrid_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 11,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => repeat_14_re_13,
              wr_din_im => repeat_14_im_13,
              wr_addr => repeat1_14_13,
              wr_en => Data_Type_Conversion19_out1,
              rd_addr => repeat2_14_13,
              dout_re => pri_rd_out_1_re_13,
              dout_im => pri_rd_out_1_im_13
              );

  wr_en_unsigned <= unsigned(wr_en);

  dtc1 <= wr_en_unsigned(0);

  Data_Type_Conversion27_out1 <= dtc1;

  dtc1_1 <= wr_en_unsigned(1);

  Extract_Bits26_out1 <= dtc1_1;

  Data_Type_Conversion26_out1 <= Extract_Bits26_out1;

  dtc1_2 <= wr_en_unsigned(2);

  Extract_Bits25_out1 <= dtc1_2;

  Data_Type_Conversion25_out1 <= Extract_Bits25_out1;

  dtc1_3 <= wr_en_unsigned(3);

  Extract_Bits24_out1 <= dtc1_3;

  Data_Type_Conversion24_out1 <= Extract_Bits24_out1;

  dtc1_4 <= wr_en_unsigned(4);

  Extract_Bits23_out1 <= dtc1_4;

  Data_Type_Conversion23_out1 <= Extract_Bits23_out1;

  dtc1_5 <= wr_en_unsigned(5);

  Extract_Bits22_out1 <= dtc1_5;

  Data_Type_Conversion22_out1 <= Extract_Bits22_out1;

  dtc1_6 <= wr_en_unsigned(6);

  Extract_Bits21_out1 <= dtc1_6;

  Data_Type_Conversion21_out1 <= Extract_Bits21_out1;

  dtc1_7 <= wr_en_unsigned(7);

  Extract_Bits14_out1 <= dtc1_7;

  Data_Type_Conversion20_out1 <= Extract_Bits14_out1;

  dtc1_8 <= wr_en_unsigned(8);

  Extract_Bits20_out1 <= dtc1_8;

  Data_Type_Conversion18_out1 <= Extract_Bits20_out1;

  dtc1_9 <= wr_en_unsigned(9);

  Extract_Bits19_out1 <= dtc1_9;

  Data_Type_Conversion17_out1 <= Extract_Bits19_out1;

  dtc1_10 <= wr_en_unsigned(10);

  Extract_Bits18_out1 <= dtc1_10;

  Data_Type_Conversion16_out1 <= Extract_Bits18_out1;

  dtc1_11 <= wr_en_unsigned(11);

  Extract_Bits17_out1 <= dtc1_11;

  Data_Type_Conversion15_out1 <= Extract_Bits17_out1;

  dtc1_12 <= wr_en_unsigned(12);

  Extract_Bits16_out1 <= dtc1_12;

  Data_Type_Conversion14_out1 <= Extract_Bits16_out1;

  Extract_Bits15_out1 <= wr_en_unsigned(13);

  Data_Type_Conversion19_out1 <= Extract_Bits15_out1;

  data_out_re_0 <= pri_rd_out_1_re;

  data_out_re_1 <= pri_rd_out_1_re_1;

  data_out_re_2 <= pri_rd_out_1_re_2;

  data_out_re_3 <= pri_rd_out_1_re_3;

  data_out_re_4 <= pri_rd_out_1_re_4;

  data_out_re_5 <= pri_rd_out_1_re_5;

  data_out_re_6 <= pri_rd_out_1_re_6;

  data_out_re_7 <= pri_rd_out_1_re_7;

  data_out_re_8 <= pri_rd_out_1_re_8;

  data_out_re_9 <= pri_rd_out_1_re_9;

  data_out_re_10 <= pri_rd_out_1_re_10;

  data_out_re_11 <= pri_rd_out_1_re_11;

  data_out_re_12 <= pri_rd_out_1_re_12;

  data_out_re_13 <= pri_rd_out_1_re_13;

  data_out_im_0 <= pri_rd_out_1_im;

  data_out_im_1 <= pri_rd_out_1_im_1;

  data_out_im_2 <= pri_rd_out_1_im_2;

  data_out_im_3 <= pri_rd_out_1_im_3;

  data_out_im_4 <= pri_rd_out_1_im_4;

  data_out_im_5 <= pri_rd_out_1_im_5;

  data_out_im_6 <= pri_rd_out_1_im_6;

  data_out_im_7 <= pri_rd_out_1_im_7;

  data_out_im_8 <= pri_rd_out_1_im_8;

  data_out_im_9 <= pri_rd_out_1_im_9;

  data_out_im_10 <= pri_rd_out_1_im_10;

  data_out_im_11 <= pri_rd_out_1_im_11;

  data_out_im_12 <= pri_rd_out_1_im_12;

  data_out_im_13 <= pri_rd_out_1_im_13;

END rtl;

