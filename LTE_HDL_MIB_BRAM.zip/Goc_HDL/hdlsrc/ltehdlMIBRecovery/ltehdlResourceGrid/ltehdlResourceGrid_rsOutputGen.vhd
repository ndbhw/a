-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlResourceGrid;
USE work.ltehdlResourceGrid_ltehdlResourceGrid_pac.ALL;

ENTITY ltehdlResourceGrid_rsOutputGen IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        wrData_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        wrData_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        wr_en_flag                        :   IN    std_logic_vector(13 DOWNTO 0);  -- ufix14
        wrAddr                            :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
        cellID                            :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        rsData_re                         :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        rsData_im                         :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        rsValid                           :   OUT   std_logic
        );
END ltehdlResourceGrid_rsOutputGen;


ARCHITECTURE rtl OF ltehdlResourceGrid_rsOutputGen IS

  -- Component Declarations
  COMPONENT ltehdlResourceGrid_mod3cellID
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          addr_in                         :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          reminder                        :   OUT   std_logic_vector(15 DOWNTO 0)  -- uint16
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlResourceGrid_mod3cellID
    USE ENTITY work_ltehdlResourceGrid.ltehdlResourceGrid_mod3cellID(rtl);

  -- Signals
  SIGNAL wrData_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL wrData_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay2_reg_re                    : vector_of_signed16(0 TO 4) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16_En15 [5]
  SIGNAL Delay2_reg_im                    : vector_of_signed16(0 TO 4) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16_En15 [5]
  SIGNAL rsData_re_tmp                    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL rsData_im_tmp                    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL wr_en_flag_unsigned              : unsigned(13 DOWNTO 0);  -- ufix14
  SIGNAL Delay1_reg_rsvd                  : vector_of_unsigned14(0 TO 4) := (OTHERS => to_unsigned(16#0000#, 14));  -- ufix14 [5]
  SIGNAL Delay1_out1                      : unsigned(13 DOWNTO 0);  -- ufix14
  SIGNAL dtc1                             : std_logic;  -- ufix1
  SIGNAL sym0                             : std_logic;
  SIGNAL dtc1_1                           : std_logic;  -- ufix1_E1
  SIGNAL Extract_Bits26_out1              : std_logic;  -- ufix1
  SIGNAL sym1                             : std_logic;
  SIGNAL dtc1_2                           : std_logic;  -- ufix1_E4
  SIGNAL Extract_Bits23_out1              : std_logic;  -- ufix1
  SIGNAL sym4                             : std_logic;
  SIGNAL dtc1_3                           : std_logic;  -- ufix1_E7
  SIGNAL Extract_Bits14_out1              : std_logic;  -- ufix1
  SIGNAL sym7                             : std_logic;
  SIGNAL dtc1_4                           : std_logic;  -- ufix1_E8
  SIGNAL Extract_Bits20_out1              : std_logic;  -- ufix1
  SIGNAL sym8                             : std_logic;
  SIGNAL dtc1_5                           : std_logic;  -- ufix1_E11
  SIGNAL Extract_Bits17_out1              : std_logic;  -- ufix1
  SIGNAL sym11                            : std_logic;
  SIGNAL OR_out1                          : std_logic;
  SIGNAL wrAddr_unsigned                  : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL Relational_Operator_out1         : std_logic;
  SIGNAL Relational_Operator1_out1        : std_logic;
  SIGNAL Relational_Operator2_out1        : std_logic;
  SIGNAL AND1_out1                        : std_logic;
  SIGNAL Delay4_reg_rsvd                  : std_logic_vector(4 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [5]
  SIGNAL isSubcarrier                     : std_logic;
  SIGNAL Compare_To_Constant_out1         : std_logic;
  SIGNAL mod3_addr                        : unsigned(15 DOWNTO 0) := to_unsigned(16#0000#, 16);  -- uint16
  SIGNAL count                            : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL need_to_wrap                     : std_logic;
  SIGNAL count_value                      : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL count_1                          : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL count_2                          : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL mod3_cellID                      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL mod3_cellID_unsigned             : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL isRS                             : std_logic;
  SIGNAL AND_out1                         : std_logic;

BEGIN
  Umod3cellID : ltehdlResourceGrid_mod3cellID
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              addr_in => cellID,  -- ufix9
              reminder => mod3_cellID  -- uint16
              );

  wrData_re_signed <= signed(wrData_re);

  wrData_im_signed <= signed(wrData_im);

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay2_reg_im(0) <= wrData_im_signed;
        Delay2_reg_im(1 TO 4) <= Delay2_reg_im(0 TO 3);
        Delay2_reg_re(0) <= wrData_re_signed;
        Delay2_reg_re(1 TO 4) <= Delay2_reg_re(0 TO 3);
      END IF;
    END IF;
  END PROCESS Delay2_process;

  rsData_re_tmp <= Delay2_reg_re(4);
  rsData_im_tmp <= Delay2_reg_im(4);

  rsData_re <= std_logic_vector(rsData_re_tmp);

  rsData_im <= std_logic_vector(rsData_im_tmp);

  wr_en_flag_unsigned <= unsigned(wr_en_flag);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_reg_rsvd(0) <= wr_en_flag_unsigned;
        Delay1_reg_rsvd(1 TO 4) <= Delay1_reg_rsvd(0 TO 3);
      END IF;
    END IF;
  END PROCESS Delay1_process;

  Delay1_out1 <= Delay1_reg_rsvd(4);

  dtc1 <= Delay1_out1(0);

  sym0 <= dtc1;

  dtc1_1 <= Delay1_out1(1);

  Extract_Bits26_out1 <= dtc1_1;

  sym1 <= Extract_Bits26_out1;

  dtc1_2 <= Delay1_out1(4);

  Extract_Bits23_out1 <= dtc1_2;

  sym4 <= Extract_Bits23_out1;

  dtc1_3 <= Delay1_out1(7);

  Extract_Bits14_out1 <= dtc1_3;

  sym7 <= Extract_Bits14_out1;

  dtc1_4 <= Delay1_out1(8);

  Extract_Bits20_out1 <= dtc1_4;

  sym8 <= Extract_Bits20_out1;

  dtc1_5 <= Delay1_out1(11);

  Extract_Bits17_out1 <= dtc1_5;

  sym11 <= Extract_Bits17_out1;

  OR_out1 <= sym11 OR (sym8 OR (sym7 OR (sym4 OR (sym0 OR sym1))));

  wrAddr_unsigned <= unsigned(wrAddr);

  
  Relational_Operator_out1 <= '1' WHEN wrAddr_unsigned >= to_unsigned(16#16C#, 11) ELSE
      '0';

  
  Relational_Operator1_out1 <= '1' WHEN wrAddr_unsigned <= to_unsigned(16#694#, 11) ELSE
      '0';

  
  Relational_Operator2_out1 <= '1' WHEN wrAddr_unsigned /= to_unsigned(16#400#, 11) ELSE
      '0';

  -- exclude anything outside of central 110 RB's
  -- subcarriers, and DC subcarrier
  -- (RS are generated based on 110 RBs)
  AND1_out1 <= Relational_Operator2_out1 AND (Relational_Operator_out1 AND Relational_Operator1_out1);

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay4_reg_rsvd(0) <= AND1_out1;
        Delay4_reg_rsvd(4 DOWNTO 1) <= Delay4_reg_rsvd(3 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS Delay4_process;

  isSubcarrier <= Delay4_reg_rsvd(4);

  
  Compare_To_Constant_out1 <= '1' WHEN wrAddr_unsigned = to_unsigned(16#000#, 11) ELSE
      '0';

  -- Count limited, Unsigned Counter
  --  initial value   = 0
  --  step value      = 1
  --  count to value  = 2
  count <= mod3_addr + to_unsigned(16#0001#, 16);

  
  need_to_wrap <= '1' WHEN mod3_addr = to_unsigned(16#0002#, 16) ELSE
      '0';

  
  count_value <= count WHEN need_to_wrap = '0' ELSE
      to_unsigned(16#0000#, 16);

  
  count_1 <= mod3_addr WHEN isSubcarrier = '0' ELSE
      count_value;

  
  count_2 <= count_1 WHEN Compare_To_Constant_out1 = '0' ELSE
      to_unsigned(16#0000#, 16);

  HDL_Counter_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        mod3_addr <= count_2;
      END IF;
    END IF;
  END PROCESS HDL_Counter_process;


  mod3_cellID_unsigned <= unsigned(mod3_cellID);

  
  isRS <= '1' WHEN mod3_addr = mod3_cellID_unsigned ELSE
      '0';

  AND_out1 <= isRS AND (OR_out1 AND isSubcarrier);

  rsValid <= AND_out1;

END rtl;

