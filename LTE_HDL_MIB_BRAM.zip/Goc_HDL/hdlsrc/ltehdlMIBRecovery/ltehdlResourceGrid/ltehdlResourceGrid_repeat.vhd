-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlResourceGrid_repeat IS
  PORT( alpha1_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha1_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_re_0                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_re_1                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_re_2                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_re_3                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_re_4                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_re_5                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_re_6                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_re_7                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_re_8                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_re_9                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_re_10                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_re_11                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_re_12                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_re_13                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_im_0                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_im_1                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_im_2                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_im_3                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_im_4                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_im_5                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_im_6                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_im_7                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_im_8                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_im_9                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_im_10                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_im_11                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_im_12                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        alpha14_im_13                     :   OUT   std_logic_vector(15 DOWNTO 0)  -- sfix16_En15
        );
END ltehdlResourceGrid_repeat;


ARCHITECTURE rtl OF ltehdlResourceGrid_repeat IS

BEGIN
  alpha14_re_0 <= alpha1_re;

  alpha14_re_1 <= alpha1_re;

  alpha14_re_2 <= alpha1_re;

  alpha14_re_3 <= alpha1_re;

  alpha14_re_4 <= alpha1_re;

  alpha14_re_5 <= alpha1_re;

  alpha14_re_6 <= alpha1_re;

  alpha14_re_7 <= alpha1_re;

  alpha14_re_8 <= alpha1_re;

  alpha14_re_9 <= alpha1_re;

  alpha14_re_10 <= alpha1_re;

  alpha14_re_11 <= alpha1_re;

  alpha14_re_12 <= alpha1_re;

  alpha14_re_13 <= alpha1_re;

  alpha14_im_0 <= alpha1_im;

  alpha14_im_1 <= alpha1_im;

  alpha14_im_2 <= alpha1_im;

  alpha14_im_3 <= alpha1_im;

  alpha14_im_4 <= alpha1_im;

  alpha14_im_5 <= alpha1_im;

  alpha14_im_6 <= alpha1_im;

  alpha14_im_7 <= alpha1_im;

  alpha14_im_8 <= alpha1_im;

  alpha14_im_9 <= alpha1_im;

  alpha14_im_10 <= alpha1_im;

  alpha14_im_11 <= alpha1_im;

  alpha14_im_12 <= alpha1_im;

  alpha14_im_13 <= alpha1_im;

END rtl;

