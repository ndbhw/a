-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlResourceGrid_wr_en_calculator IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        enb_1                             :   IN    std_logic;
        shift                             :   IN    std_logic;
        rst                               :   IN    std_logic;
        en_flag                           :   OUT   std_logic_vector(13 DOWNTO 0)  -- ufix14
        );
END ltehdlResourceGrid_wr_en_calculator;


ARCHITECTURE rtl OF ltehdlResourceGrid_wr_en_calculator IS

  -- Signals
  SIGNAL switch_compare_1                 : std_logic;
  SIGNAL Enabled_Delay_out1               : unsigned(13 DOWNTO 0);  -- ufix14
  SIGNAL Bit_Shift_out1                   : unsigned(13 DOWNTO 0);  -- ufix14
  SIGNAL Switch_out1                      : unsigned(13 DOWNTO 0);  -- ufix14
  SIGNAL Switch1_out1                     : unsigned(13 DOWNTO 0);  -- ufix14

BEGIN
  
  switch_compare_1 <= '1' WHEN shift > '0' ELSE
      '0';

  Bit_Shift_out1 <= Enabled_Delay_out1 sll 1;

  
  Switch_out1 <= Enabled_Delay_out1 WHEN switch_compare_1 = '0' ELSE
      Bit_Shift_out1;

  Enabled_Delay_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        Enabled_Delay_out1 <= to_unsigned(16#0001#, 14);
      ELSIF enb_1_2_0 = '1' THEN
        IF rst = '1' THEN
          Enabled_Delay_out1 <= to_unsigned(16#0001#, 14);
        ELSE 
          Enabled_Delay_out1 <= Switch_out1;
        END IF;
      END IF;
    END IF;
  END PROCESS Enabled_Delay_process;


  
  Switch1_out1 <= to_unsigned(16#0000#, 14) WHEN enb_1 = '0' ELSE
      Enabled_Delay_out1;

  en_flag <= std_logic_vector(Switch1_out1);

END rtl;

