-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlResourceGrid_ltehdlResourceGrid_pac.ALL;

ENTITY ltehdlResourceGrid_MATLAB_Function IS
  PORT( data_re_0                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_re_1                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_re_2                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_re_3                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_re_4                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_re_5                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_re_6                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_re_7                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_re_8                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_re_9                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_re_10                        :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_re_11                        :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_re_12                        :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_re_13                        :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_im_0                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_im_1                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_im_2                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_im_3                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_im_4                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_im_5                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_im_6                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_im_7                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_im_8                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_im_9                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_im_10                        :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_im_11                        :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_im_12                        :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        data_im_13                        :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        bank_num                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        data_sel_re                       :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_sel_im                       :   OUT   std_logic_vector(15 DOWNTO 0)  -- sfix16_En15
        );
END ltehdlResourceGrid_MATLAB_Function;


ARCHITECTURE rtl OF ltehdlResourceGrid_MATLAB_Function IS

  -- Signals
  SIGNAL data_re                          : vector_of_signed16(0 TO 13);  -- sfix16_En15 [14]
  SIGNAL data_im                          : vector_of_signed16(0 TO 13);  -- sfix16_En15 [14]
  SIGNAL bank_num_unsigned                : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL data_sel_re_tmp                  : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL data_sel_im_tmp                  : signed(15 DOWNTO 0);  -- sfix16_En15

BEGIN
  data_re(0) <= signed(data_re_0);
  data_re(1) <= signed(data_re_1);
  data_re(2) <= signed(data_re_2);
  data_re(3) <= signed(data_re_3);
  data_re(4) <= signed(data_re_4);
  data_re(5) <= signed(data_re_5);
  data_re(6) <= signed(data_re_6);
  data_re(7) <= signed(data_re_7);
  data_re(8) <= signed(data_re_8);
  data_re(9) <= signed(data_re_9);
  data_re(10) <= signed(data_re_10);
  data_re(11) <= signed(data_re_11);
  data_re(12) <= signed(data_re_12);
  data_re(13) <= signed(data_re_13);

  data_im(0) <= signed(data_im_0);
  data_im(1) <= signed(data_im_1);
  data_im(2) <= signed(data_im_2);
  data_im(3) <= signed(data_im_3);
  data_im(4) <= signed(data_im_4);
  data_im(5) <= signed(data_im_5);
  data_im(6) <= signed(data_im_6);
  data_im(7) <= signed(data_im_7);
  data_im(8) <= signed(data_im_8);
  data_im(9) <= signed(data_im_9);
  data_im(10) <= signed(data_im_10);
  data_im(11) <= signed(data_im_11);
  data_im(12) <= signed(data_im_12);
  data_im(13) <= signed(data_im_13);

  bank_num_unsigned <= unsigned(bank_num);

  MATLAB_Function_output : PROCESS (bank_num_unsigned, data_im, data_re)
  BEGIN
    CASE bank_num_unsigned IS
      WHEN "0000" =>
        data_sel_re_tmp <= data_re(0);
        data_sel_im_tmp <= data_im(0);
      WHEN "0001" =>
        data_sel_re_tmp <= data_re(1);
        data_sel_im_tmp <= data_im(1);
      WHEN "0010" =>
        data_sel_re_tmp <= data_re(2);
        data_sel_im_tmp <= data_im(2);
      WHEN "0011" =>
        data_sel_re_tmp <= data_re(3);
        data_sel_im_tmp <= data_im(3);
      WHEN "0100" =>
        data_sel_re_tmp <= data_re(4);
        data_sel_im_tmp <= data_im(4);
      WHEN "0101" =>
        data_sel_re_tmp <= data_re(5);
        data_sel_im_tmp <= data_im(5);
      WHEN "0110" =>
        data_sel_re_tmp <= data_re(6);
        data_sel_im_tmp <= data_im(6);
      WHEN "0111" =>
        data_sel_re_tmp <= data_re(7);
        data_sel_im_tmp <= data_im(7);
      WHEN "1000" =>
        data_sel_re_tmp <= data_re(8);
        data_sel_im_tmp <= data_im(8);
      WHEN "1001" =>
        data_sel_re_tmp <= data_re(9);
        data_sel_im_tmp <= data_im(9);
      WHEN "1010" =>
        data_sel_re_tmp <= data_re(10);
        data_sel_im_tmp <= data_im(10);
      WHEN "1011" =>
        data_sel_re_tmp <= data_re(11);
        data_sel_im_tmp <= data_im(11);
      WHEN "1100" =>
        data_sel_re_tmp <= data_re(12);
        data_sel_im_tmp <= data_im(12);
      WHEN "1101" =>
        data_sel_re_tmp <= data_re(13);
        data_sel_im_tmp <= data_im(13);
      WHEN OTHERS => 
        data_sel_re_tmp <= data_re(0);
        data_sel_im_tmp <= data_im(0);
    END CASE;
  END PROCESS MATLAB_Function_output;


  data_sel_re <= std_logic_vector(data_sel_re_tmp);

  data_sel_im <= std_logic_vector(data_sel_im_tmp);

END rtl;

