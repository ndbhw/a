-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlResourceGrid;

ENTITY ltehdlResourceGrid_LTE_Memory_Bank_Write_Controller IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        rst                               :   IN    std_logic;
        data_re                           :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_im                           :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        enb_1                             :   IN    std_logic;
        data_in_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        data_in_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        wr_addr                           :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        wr_en_flag                        :   OUT   std_logic_vector(13 DOWNTO 0);  -- ufix14
        writeDone                         :   OUT   std_logic
        );
END ltehdlResourceGrid_LTE_Memory_Bank_Write_Controller;


ARCHITECTURE rtl OF ltehdlResourceGrid_LTE_Memory_Bank_Write_Controller IS

  -- Component Declarations
  COMPONENT ltehdlResourceGrid_wr_en_calculator
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          enb_1                           :   IN    std_logic;
          shift                           :   IN    std_logic;
          rst                             :   IN    std_logic;
          en_flag                         :   OUT   std_logic_vector(13 DOWNTO 0)  -- ufix14
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlResourceGrid_wr_en_calculator
    USE ENTITY work_ltehdlResourceGrid.ltehdlResourceGrid_wr_en_calculator(rtl);

  -- Signals
  SIGNAL subcarrierCount                  : unsigned(10 DOWNTO 0) := to_unsigned(16#000#, 11);  -- ufix11
  SIGNAL count                            : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL need_to_wrap                     : std_logic;
  SIGNAL count_value                      : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL count_1                          : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL count_2                          : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL isLastSubcarrier                 : std_logic;
  SIGNAL ofdmSymbolCount                  : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL count_3                          : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL need_to_wrap_1                   : std_logic;
  SIGNAL count_value_1                    : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL count_4                          : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL count_5                          : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL Compare_To_Constant1_out1        : std_logic;
  SIGNAL writeDone_1                      : std_logic;
  SIGNAL Delay_out1                       : std_logic := '0';
  SIGNAL OR_out1                          : std_logic;
  SIGNAL writeEnable                      : std_logic_vector(13 DOWNTO 0);  -- ufix14
  SIGNAL data_re_signed                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL data_im_signed                   : signed(15 DOWNTO 0);  -- sfix16_En15

BEGIN
  Uwr_en_calculator : ltehdlResourceGrid_wr_en_calculator
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb_1_2_0 => enb_1_2_0,
              enb_1 => enb_1,
              shift => isLastSubcarrier,
              rst => OR_out1,
              en_flag => writeEnable  -- ufix14
              );

  -- Count limited, Unsigned Counter
  --  initial value   = 0
  --  step value      = 1
  --  count to value  = 2047
  count <= subcarrierCount + to_unsigned(16#001#, 11);

  
  need_to_wrap <= '1' WHEN subcarrierCount = to_unsigned(16#7FF#, 11) ELSE
      '0';

  
  count_value <= count WHEN need_to_wrap = '0' ELSE
      to_unsigned(16#000#, 11);

  
  count_1 <= subcarrierCount WHEN enb_1 = '0' ELSE
      count_value;

  
  count_2 <= count_1 WHEN rst = '0' ELSE
      to_unsigned(16#000#, 11);

  SubcarrierCounter_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        subcarrierCount <= count_2;
      END IF;
    END IF;
  END PROCESS SubcarrierCounter_process;


  wr_addr <= std_logic_vector(subcarrierCount);

  
  isLastSubcarrier <= '1' WHEN subcarrierCount = to_unsigned(16#7FF#, 11) ELSE
      '0';

  -- Count limited, Unsigned Counter
  --  initial value   = 0
  --  step value      = 1
  --  count to value  = 13
  count_3 <= ofdmSymbolCount + to_unsigned(16#1#, 4);

  
  need_to_wrap_1 <= '1' WHEN ofdmSymbolCount = to_unsigned(16#D#, 4) ELSE
      '0';

  
  count_value_1 <= count_3 WHEN need_to_wrap_1 = '0' ELSE
      to_unsigned(16#0#, 4);

  
  count_4 <= ofdmSymbolCount WHEN isLastSubcarrier = '0' ELSE
      count_value_1;

  
  count_5 <= count_4 WHEN rst = '0' ELSE
      to_unsigned(16#0#, 4);

  ofdmSymbolCounter_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        ofdmSymbolCount <= count_5;
      END IF;
    END IF;
  END PROCESS ofdmSymbolCounter_process;


  
  Compare_To_Constant1_out1 <= '1' WHEN ofdmSymbolCount = to_unsigned(16#D#, 4) ELSE
      '0';

  writeDone_1 <= isLastSubcarrier AND Compare_To_Constant1_out1;

  Delay_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay_out1 <= writeDone_1;
      END IF;
    END IF;
  END PROCESS Delay_rsvd_process;


  OR_out1 <= rst OR Delay_out1;

  data_in_re <= data_re;

  data_in_im <= data_im;

  wr_en_flag <= writeEnable;

  writeDone <= writeDone_1;

END rtl;

