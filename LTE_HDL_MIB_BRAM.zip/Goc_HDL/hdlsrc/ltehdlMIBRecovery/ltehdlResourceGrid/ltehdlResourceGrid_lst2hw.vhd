-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlResourceGrid_lst2hw IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        lst_index                         :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
        nBank                             :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        valid_in                          :   IN    std_logic;
        NDLRB                             :   IN    std_logic_vector(6 DOWNTO 0);  -- ufix7
        hw_index                          :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        rd_bank                           :   OUT   std_logic_vector(3 DOWNTO 0);  -- ufix4
        eq_index                          :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        valid_out                         :   OUT   std_logic
        );
END ltehdlResourceGrid_lst2hw;


ARCHITECTURE rtl OF ltehdlResourceGrid_lst2hw IS

  -- Signals
  SIGNAL lst_index_unsigned               : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL NDLRB_unsigned                   : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL Gain_mul_temp                    : unsigned(13 DOWNTO 0);  -- ufix14_En4
  SIGNAL Gain_out1                        : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL Relational_Operator_out1         : std_logic;
  SIGNAL Add_out1                         : signed(10 DOWNTO 0);  -- sfix11
  SIGNAL Add1_out1                        : signed(10 DOWNTO 0);  -- sfix11
  SIGNAL Switch1_out1                     : signed(10 DOWNTO 0);  -- sfix11
  SIGNAL hw_index_1                       : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL rd_index                         : unsigned(10 DOWNTO 0) := to_unsigned(16#000#, 11);  -- ufix11
  SIGNAL nBank_unsigned                   : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL rd_bank_tmp                      : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL Delay3_out1                      : unsigned(10 DOWNTO 0) := to_unsigned(16#000#, 11);  -- ufix11

BEGIN
  lst_index_unsigned <= unsigned(lst_index);

  NDLRB_unsigned <= unsigned(NDLRB);

  Gain_mul_temp <= to_unsigned(16#60#, 7) * NDLRB_unsigned;
  Gain_out1 <= Gain_mul_temp(13 DOWNTO 4);

  
  Relational_Operator_out1 <= '1' WHEN lst_index_unsigned >= resize(Gain_out1, 11) ELSE
      '0';

  Add_out1 <= to_signed(-16#400#, 11) - signed(resize(Gain_out1, 11));

  Add1_out1 <= to_signed(-16#3FF#, 11) - signed(resize(Gain_out1, 11));

  
  Switch1_out1 <= Add_out1 WHEN Relational_Operator_out1 = '0' ELSE
      Add1_out1;

  hw_index_1 <= lst_index_unsigned + unsigned(Switch1_out1);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        rd_index <= hw_index_1;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  hw_index <= std_logic_vector(rd_index);

  nBank_unsigned <= unsigned(nBank);

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        rd_bank_tmp <= nBank_unsigned;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  rd_bank <= std_logic_vector(rd_bank_tmp);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay3_out1 <= lst_index_unsigned;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  eq_index <= std_logic_vector(Delay3_out1);

  Delay_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        valid_out <= valid_in;
      END IF;
    END IF;
  END PROCESS Delay_rsvd_process;


END rtl;

