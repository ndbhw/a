-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlPBCHDecoder;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_BCH_Decoder IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_0                          :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        dataIn_1                          :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        dataIn_2                          :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        validIn                           :   IN    std_logic;
        clearReg                          :   IN    std_logic;
        cellRefP                          :   OUT   std_logic_vector(2 DOWNTO 0);  -- ufix3
        repeatQPSK                        :   OUT   std_logic;
        restartMIB                        :   OUT   std_logic;
        MIBDetected                       :   OUT   std_logic;
        dataOut                           :   OUT   std_logic_vector(23 DOWNTO 0);  -- ufix24
        nfmod4                            :   OUT   std_logic_vector(1 DOWNTO 0)  -- ufix2
        );
END ltehdlPBCHDecoder_BCH_Decoder;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_BCH_Decoder IS

  -- Component Declarations
  COMPONENT ltehdlPBCHDecoder_controlbusGen
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          In1                             :   IN    std_logic;
          Out1_start                      :   OUT   std_logic;
          Out1_end                        :   OUT   std_logic;
          Out1_valid                      :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_softBitScalingUnit
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_0                        :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          dataIn_1                        :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          dataIn_2                        :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          ctrlIn_start                    :   IN    std_logic;
          ctrlIn_end                      :   IN    std_logic;
          ctrlIn_valid                    :   IN    std_logic;
          dataOut_0                       :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
          dataOut_1                       :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
          dataOut_2                       :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
          ctrlOut_start                   :   OUT   std_logic;
          ctrlOut_end                     :   OUT   std_logic;
          ctrlOut_valid                   :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_Convolutional_Decoder
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          data_0                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          data_1                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          data_2                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          ctrl_start                      :   IN    std_logic;
          ctrl_end                        :   IN    std_logic;
          ctrl_valid                      :   IN    std_logic;
          data                            :   OUT   std_logic;
          ctrl_start_1                    :   OUT   std_logic;
          ctrl_end_1                      :   OUT   std_logic;
          ctrl_valid_1                    :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_CRC_Decoder
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          in0                             :   IN    std_logic;
          in1_start                       :   IN    std_logic;
          in1_end                         :   IN    std_logic;
          in1_valid                       :   IN    std_logic;
          out0                            :   OUT   std_logic;
          out1_start                      :   OUT   std_logic;
          out1_end                        :   OUT   std_logic;
          out1_valid                      :   OUT   std_logic;
          out2                            :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_BCH_Controller
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          data                            :   IN    std_logic;
          ctrl_start                      :   IN    std_logic;
          ctrl_end                        :   IN    std_logic;
          ctrl_valid                      :   IN    std_logic;
          crcErr                          :   IN    std_logic_vector(15 DOWNTO 0);  -- uint16
          clearReg                        :   IN    std_logic;
          dataOut                         :   OUT   std_logic_vector(23 DOWNTO 0);  -- ufix24
          repeatQPSK                      :   OUT   std_logic;
          MIBDetected                     :   OUT   std_logic;
          restartMIB                      :   OUT   std_logic;
          nfmod4                          :   OUT   std_logic_vector(1 DOWNTO 0);  -- ufix2
          cellRefP                        :   OUT   std_logic_vector(2 DOWNTO 0)  -- ufix3
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlPBCHDecoder_controlbusGen
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_controlbusGen(rtl);

  FOR ALL : ltehdlPBCHDecoder_softBitScalingUnit
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_softBitScalingUnit(rtl);

  FOR ALL : ltehdlPBCHDecoder_Convolutional_Decoder
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_Convolutional_Decoder(rtl);

  FOR ALL : ltehdlPBCHDecoder_CRC_Decoder
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_CRC_Decoder(rtl);

  FOR ALL : ltehdlPBCHDecoder_BCH_Controller
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_BCH_Controller(rtl);

  -- Signals
  SIGNAL dataIn                           : vector_of_signed20(0 TO 2);  -- sfix20_En17 [3]
  SIGNAL Delay2_out1                      : vector_of_signed20(0 TO 2) := (OTHERS => to_signed(16#00000#, 20));  -- sfix20_En17 [3]
  SIGNAL Delay3_out1                      : std_logic := '0';
  SIGNAL controlbusGen_Out1_start         : std_logic;
  SIGNAL controlbusGen_Out1_end           : std_logic;
  SIGNAL controlbusGen_Out1_valid         : std_logic;
  SIGNAL softBitScalingUnit_dataOut_0     : std_logic_vector(3 DOWNTO 0);  -- ufix4
  SIGNAL softBitScalingUnit_dataOut_1     : std_logic_vector(3 DOWNTO 0);  -- ufix4
  SIGNAL softBitScalingUnit_dataOut_2     : std_logic_vector(3 DOWNTO 0);  -- ufix4
  SIGNAL softBitScalingUnit_ctrlOut_start : std_logic;
  SIGNAL softBitScalingUnit_ctrlOut_end   : std_logic;
  SIGNAL softBitScalingUnit_ctrlOut_valid : std_logic;
  SIGNAL data                             : std_logic;
  SIGNAL ctrl_start                       : std_logic;
  SIGNAL ctrl_end                         : std_logic;
  SIGNAL ctrl_valid                       : std_logic;
  SIGNAL crcdatain                        : std_logic := '0';
  SIGNAL crcctrlin_start                  : std_logic := '0';
  SIGNAL crcctrlin_end                    : std_logic := '0';
  SIGNAL crcctrlin_valid                  : std_logic := '0';
  SIGNAL cecdataout                       : std_logic;
  SIGNAL CRC_Decoder_out2_start           : std_logic;
  SIGNAL CRC_Decoder_out2_end             : std_logic;
  SIGNAL CRC_Decoder_out2_valid           : std_logic;
  SIGNAL crcerror                         : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL Delay4_out1                      : std_logic := '0';
  SIGNAL Delay6_out1_start                : std_logic := '0';
  SIGNAL Delay6_out1_end                  : std_logic := '0';
  SIGNAL crcerror_unsigned                : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Delay6_out1_valid                : std_logic := '0';
  SIGNAL Delay5_out1                      : unsigned(15 DOWNTO 0) := to_unsigned(16#0000#, 16);  -- uint16
  SIGNAL dataOut_tmp                      : std_logic_vector(23 DOWNTO 0);  -- ufix24
  SIGNAL BCH_Controller_repeatQPSK        : std_logic;
  SIGNAL BCH_Controller_MIBDetected       : std_logic;
  SIGNAL BCH_Controller_restartMIB        : std_logic;
  SIGNAL BCH_Controller_nfmod4            : std_logic_vector(1 DOWNTO 0);  -- ufix2
  SIGNAL cellrefp_1                       : std_logic_vector(2 DOWNTO 0);  -- ufix3

BEGIN
  UcontrolbusGen : ltehdlPBCHDecoder_controlbusGen
    PORT MAP( clk => clk,
              enb => enb,
              In1 => Delay3_out1,
              Out1_start => controlbusGen_Out1_start,
              Out1_end => controlbusGen_Out1_end,
              Out1_valid => controlbusGen_Out1_valid
              );

  UsoftBitScalingUnit : ltehdlPBCHDecoder_softBitScalingUnit
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              dataIn_0 => std_logic_vector(Delay2_out1(0)),  -- sfix20_En17
              dataIn_1 => std_logic_vector(Delay2_out1(1)),  -- sfix20_En17
              dataIn_2 => std_logic_vector(Delay2_out1(2)),  -- sfix20_En17
              ctrlIn_start => controlbusGen_Out1_start,
              ctrlIn_end => controlbusGen_Out1_end,
              ctrlIn_valid => controlbusGen_Out1_valid,
              dataOut_0 => softBitScalingUnit_dataOut_0,  -- sfix4_En1
              dataOut_1 => softBitScalingUnit_dataOut_1,  -- sfix4_En1
              dataOut_2 => softBitScalingUnit_dataOut_2,  -- sfix4_En1
              ctrlOut_start => softBitScalingUnit_ctrlOut_start,
              ctrlOut_end => softBitScalingUnit_ctrlOut_end,
              ctrlOut_valid => softBitScalingUnit_ctrlOut_valid
              );

  UConvolutional_Decoder : ltehdlPBCHDecoder_Convolutional_Decoder
    PORT MAP( clk => clk,
              enb => enb,
              data_0 => softBitScalingUnit_dataOut_0,  -- ufix4
              data_1 => softBitScalingUnit_dataOut_1,  -- ufix4
              data_2 => softBitScalingUnit_dataOut_2,  -- ufix4
              ctrl_start => softBitScalingUnit_ctrlOut_start,
              ctrl_end => softBitScalingUnit_ctrlOut_end,
              ctrl_valid => softBitScalingUnit_ctrlOut_valid,
              data => data,
              ctrl_start_1 => ctrl_start,
              ctrl_end_1 => ctrl_end,
              ctrl_valid_1 => ctrl_valid
              );

  UCRC_Decoder : ltehdlPBCHDecoder_CRC_Decoder
    PORT MAP( clk => clk,
              enb => enb,
              in0 => crcdatain,
              in1_start => crcctrlin_start,
              in1_end => crcctrlin_end,
              in1_valid => crcctrlin_valid,
              out0 => cecdataout,
              out1_start => CRC_Decoder_out2_start,
              out1_end => CRC_Decoder_out2_end,
              out1_valid => CRC_Decoder_out2_valid,
              out2 => crcerror  -- ufix16
              );

  UBCH_Controller : ltehdlPBCHDecoder_BCH_Controller
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              data => Delay4_out1,
              ctrl_start => Delay6_out1_start,
              ctrl_end => Delay6_out1_end,
              ctrl_valid => Delay6_out1_valid,
              crcErr => std_logic_vector(Delay5_out1),  -- uint16
              clearReg => clearReg,
              dataOut => dataOut_tmp,  -- ufix24
              repeatQPSK => BCH_Controller_repeatQPSK,
              MIBDetected => BCH_Controller_MIBDetected,
              restartMIB => BCH_Controller_restartMIB,
              nfmod4 => BCH_Controller_nfmod4,  -- ufix2
              cellRefP => cellrefp_1  -- ufix3
              );

  dataIn(0) <= signed(dataIn_0);
  dataIn(1) <= signed(dataIn_1);
  dataIn(2) <= signed(dataIn_2);

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_out1 <= dataIn;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1 <= validIn;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  Delay_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        crcdatain <= data;
      END IF;
    END IF;
  END PROCESS Delay_rsvd_process;


  c_c_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        crcctrlin_start <= ctrl_start;
      END IF;
    END IF;
  END PROCESS c_c_process;


  c_c_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        crcctrlin_end <= ctrl_end;
      END IF;
    END IF;
  END PROCESS c_c_1_process;


  c_c_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        crcctrlin_valid <= ctrl_valid;
      END IF;
    END IF;
  END PROCESS c_c_2_process;


  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay4_out1 <= cecdataout;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  c_c_3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay6_out1_start <= CRC_Decoder_out2_start;
      END IF;
    END IF;
  END PROCESS c_c_3_process;


  c_c_4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay6_out1_end <= CRC_Decoder_out2_end;
      END IF;
    END IF;
  END PROCESS c_c_4_process;


  crcerror_unsigned <= unsigned(crcerror);

  c_c_5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay6_out1_valid <= CRC_Decoder_out2_valid;
      END IF;
    END IF;
  END PROCESS c_c_5_process;


  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay5_out1 <= crcerror_unsigned;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  cellRefP <= cellrefp_1;

  repeatQPSK <= BCH_Controller_repeatQPSK;

  restartMIB <= BCH_Controller_restartMIB;

  MIBDetected <= BCH_Controller_MIBDetected;

  dataOut <= dataOut_tmp;

  nfmod4 <= BCH_Controller_nfmod4;

END rtl;

