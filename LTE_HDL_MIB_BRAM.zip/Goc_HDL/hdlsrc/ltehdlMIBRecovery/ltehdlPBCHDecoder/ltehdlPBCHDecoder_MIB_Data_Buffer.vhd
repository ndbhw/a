-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlPBCHDecoder_MIB_Data_Buffer IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn                            :   IN    std_logic;
        ctrlIn_start                      :   IN    std_logic;
        ctrlIn_end                        :   IN    std_logic;
        ctrlIn_valid                      :   IN    std_logic;
        dataOut                           :   OUT   std_logic_vector(23 DOWNTO 0)  -- ufix24
        );
END ltehdlPBCHDecoder_MIB_Data_Buffer;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_MIB_Data_Buffer IS

  -- Signals
  SIGNAL dataOut_tmp                      : unsigned(23 DOWNTO 0);  -- ufix24
  SIGNAL dBuffer                          : std_logic_vector(23 DOWNTO 0);  -- ufix1 [24]
  SIGNAL dBuffer_next                     : std_logic_vector(23 DOWNTO 0);  -- ufix1 [24]

BEGIN
  MIB_Data_Buffer_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        dBuffer <= (OTHERS => '0');
      ELSIF enb = '1' THEN
        dBuffer <= dBuffer_next;
      END IF;
    END IF;
  END PROCESS MIB_Data_Buffer_process;

  MIB_Data_Buffer_output : PROCESS (ctrlIn_valid, dBuffer, dataIn)
  BEGIN
    dBuffer_next <= dBuffer;
    IF ctrlIn_valid = '1' THEN 

      FOR t_0 IN 0 TO 22 LOOP
        dBuffer_next(1 + t_0) <= dBuffer(t_0);
      END LOOP;

      dBuffer_next(0) <= dataIn;
    END IF;
    dataOut_tmp <= unsigned'(dBuffer(0) & dBuffer(1) & dBuffer(2) & dBuffer(3) & dBuffer(4) & dBuffer(5) & dBuffer(6) & dBuffer(7) & dBuffer(8) & dBuffer(9) & dBuffer(10) & dBuffer(11) & dBuffer(12) & dBuffer(13) & dBuffer(14) & dBuffer(15) & 
      dBuffer(16) & dBuffer(17) & dBuffer(18) & dBuffer(19) & dBuffer(20) & dBuffer(21) & dBuffer(22) & dBuffer(23));
  END PROCESS MIB_Data_Buffer_output;


  dataOut <= std_logic_vector(dataOut_tmp);

END rtl;

