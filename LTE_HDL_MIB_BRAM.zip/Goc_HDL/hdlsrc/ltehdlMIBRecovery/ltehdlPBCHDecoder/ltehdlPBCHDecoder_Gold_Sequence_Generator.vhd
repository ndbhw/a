-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlPBCHDecoder;

ENTITY ltehdlPBCHDecoder_Gold_Sequence_Generator IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        Load                              :   IN    std_logic;
        Init                              :   IN    std_logic_vector(30 DOWNTO 0);  -- ufix31
        enable                            :   IN    std_logic;
        Out2                              :   OUT   std_logic;
        Out1                              :   OUT   std_logic
        );
END ltehdlPBCHDecoder_Gold_Sequence_Generator;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_Gold_Sequence_Generator IS

  -- Component Declarations
  COMPONENT ltehdlPBCHDecoder_SetFF
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          D_D                             :   IN    std_logic;
          Q_Q                             :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_LFSR1
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          Load                            :   IN    std_logic;
          getDimension                    :   IN    std_logic_vector(30 DOWNTO 0);  -- ufix31
          Enable                          :   IN    std_logic;
          Out1                            :   OUT   std_logic  -- ufix1
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_LFSR2
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          Load                            :   IN    std_logic;
          Init                            :   IN    std_logic_vector(30 DOWNTO 0);  -- ufix31
          Enable                          :   IN    std_logic;
          Out1                            :   OUT   std_logic  -- ufix1
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlPBCHDecoder_SetFF
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_SetFF(rtl);

  FOR ALL : ltehdlPBCHDecoder_LFSR1
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_LFSR1(rtl);

  FOR ALL : ltehdlPBCHDecoder_LFSR2
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_LFSR2(rtl);

  -- Signals
  SIGNAL Delay5_reg_rsvd                  : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [2]
  SIGNAL Delay5_out1                      : std_logic;
  SIGNAL SetFF_Q                          : std_logic;
  SIGNAL Logical_Operator6_out1           : std_logic;
  SIGNAL Logical_Operator4_out1           : std_logic;
  SIGNAL Delay1_out1                      : std_logic := '0';
  SIGNAL Logical_Operator5_out1           : std_logic;
  SIGNAL Logical_Operator1_out1           : std_logic;
  SIGNAL Logical_Operator3_out1           : std_logic;
  SIGNAL LFSR1_Out1                       : std_logic;  -- ufix1
  SIGNAL Init_unsigned                    : unsigned(30 DOWNTO 0);  -- ufix31
  SIGNAL Delay4_out1                      : unsigned(30 DOWNTO 0) := to_unsigned(16#00000000#, 31);  -- ufix31
  SIGNAL LFSR2_Out1                       : std_logic;  -- ufix1
  SIGNAL Logical_Operator2_out1           : std_logic;
  SIGNAL Delay2_out1                      : std_logic := '0';
  SIGNAL Delay3_out1                      : std_logic := '0';

BEGIN
  USetFF : ltehdlPBCHDecoder_SetFF
    PORT MAP( clk => clk,
              enb => enb,
              D_D => Load,
              Q_Q => SetFF_Q
              );

  ULFSR1 : ltehdlPBCHDecoder_LFSR1
    PORT MAP( clk => clk,
              enb => enb,
              Load => Delay1_out1,
              getDimension => Init,  -- ufix31
              Enable => Logical_Operator3_out1,
              Out1 => LFSR1_Out1  -- ufix1
              );

  ULFSR2 : ltehdlPBCHDecoder_LFSR2
    PORT MAP( clk => clk,
              enb => enb,
              Load => Delay1_out1,
              Init => std_logic_vector(Delay4_out1),  -- ufix31
              Enable => Logical_Operator3_out1,
              Out1 => LFSR2_Out1  -- ufix1
              );

  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay5_reg_rsvd(0) <= enable;
        Delay5_reg_rsvd(1) <= Delay5_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay5_process;

  Delay5_out1 <= Delay5_reg_rsvd(1);

  Logical_Operator6_out1 <= Delay5_out1 AND SetFF_Q;

  Logical_Operator4_out1 <=  NOT Load;

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1 <= Load;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  Logical_Operator5_out1 <=  NOT Delay1_out1;

  Logical_Operator1_out1 <= Logical_Operator5_out1 AND (Logical_Operator6_out1 AND Logical_Operator4_out1);

  Logical_Operator3_out1 <= Logical_Operator1_out1 OR Delay1_out1;

  Init_unsigned <= unsigned(Init);

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay4_out1 <= Init_unsigned;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  Logical_Operator2_out1 <= LFSR1_Out1 XOR LFSR2_Out1;

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Logical_Operator1_out1 = '1' THEN
        Delay2_out1 <= Logical_Operator2_out1;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1 <= Logical_Operator1_out1;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  Out2 <= Delay2_out1;

  Out1 <= Delay3_out1;

END rtl;

