-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlPBCHDecoder_repeatQPSKPulseResync IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        enb_1_2_1                         :   IN    std_logic;
        p_p                               :   IN    std_logic;
        q_q                               :   OUT   std_logic
        );
END ltehdlPBCHDecoder_repeatQPSKPulseResync;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_repeatQPSKPulseResync IS

  -- Signals
  SIGNAL Delay1_out1                      : std_logic := '0';
  SIGNAL Logical_Operator_out1            : std_logic;
  SIGNAL Downsample_out1                  : std_logic := '0';
  SIGNAL Delay5_out1                      : std_logic := '0';
  SIGNAL Delay2_out1                      : std_logic := '0';
  SIGNAL Logical_Operator1_out1           : std_logic;

BEGIN
  Logical_Operator_out1 <= Delay1_out1 XOR p_p;

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1 <= Logical_Operator_out1;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  -- Downsample by 2 register (Sample offset 0)
  Downsample_output_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_1 = '1' THEN
        Downsample_out1 <= Delay1_out1;
      END IF;
    END IF;
  END PROCESS Downsample_output_process;


  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay5_out1 <= Downsample_out1;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay2_out1 <= Delay5_out1;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  Logical_Operator1_out1 <= Delay5_out1 XOR Delay2_out1;

  q_q <= Logical_Operator1_out1;

END rtl;

