-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_Symmetric_Saturation IS
  PORT( x_0                               :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
        x_1                               :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
        x_2                               :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
        y_0                               :   OUT   std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        y_1                               :   OUT   std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        y_2                               :   OUT   std_logic_vector(19 DOWNTO 0)  -- sfix20_En17
        );
END ltehdlPBCHDecoder_Symmetric_Saturation;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_Symmetric_Saturation IS

  -- Signals
  SIGNAL x_x                              : vector_of_signed20(0 TO 2);  -- sfix20_En17 [3]
  SIGNAL y_y                              : vector_of_signed20(0 TO 2);  -- sfix20_En17 [3]

BEGIN
  x_x(0) <= signed(x_0);
  x_x(1) <= signed(x_1);
  x_x(2) <= signed(x_2);

  Symmetric_Saturation_output : PROCESS (x_x)
    VARIABLE yy : signed(19 DOWNTO 0);
  BEGIN
    yy := to_signed(16#00000#, 20);
    -- Assume input is signed with numerictype(1,W,F)
    -- Lowest possible input value
    -- Lower limit to saturate to

    FOR kk IN 0 TO 2 LOOP
      yy := x_x(kk);
      IF x_x(kk) = to_signed(-16#80000#, 20) THEN 
        yy := to_signed(-16#7FFFF#, 20);
      END IF;
      y_y(kk) <= yy;
    END LOOP;

  END PROCESS Symmetric_Saturation_output;


  y_0 <= std_logic_vector(y_y(0));

  y_1 <= std_logic_vector(y_y(1));

  y_2 <= std_logic_vector(y_y(2));

END rtl;

