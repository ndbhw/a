-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlPBCHDecoder;

ENTITY ltehdlPBCHDecoder_CRCGenerator IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn                            :   IN    std_logic;
        startIn                           :   IN    std_logic;  -- ufix1
        endIn                             :   IN    std_logic;  -- ufix1
        validIn                           :   IN    std_logic;  -- ufix1
        dataOut                           :   OUT   std_logic;
        startOut                          :   OUT   std_logic;  -- ufix1
        endOut                            :   OUT   std_logic;  -- ufix1
        validOut                          :   OUT   std_logic  -- ufix1
        );
END ltehdlPBCHDecoder_CRCGenerator;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_CRCGenerator IS

  -- Component Declarations
  COMPONENT ltehdlPBCHDecoder_CRCGenControl
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          startIn                         :   IN    std_logic;  -- ufix1
          endIn                           :   IN    std_logic;  -- ufix1
          validIn                         :   IN    std_logic;  -- ufix1
          startOut                        :   OUT   std_logic;  -- ufix1
          processMsg                      :   OUT   std_logic;  -- ufix1
          padZero                         :   OUT   std_logic;  -- ufix1
          outputCRC                       :   OUT   std_logic;  -- ufix1
          endOut                          :   OUT   std_logic;  -- ufix1
          validOut                        :   OUT   std_logic;  -- ufix1
          regClr                          :   OUT   std_logic;  -- ufix1
          counter                         :   OUT   std_logic_vector(3 DOWNTO 0);  -- ufix4
          counter_outputCRC               :   OUT   std_logic_vector(3 DOWNTO 0)  -- ufix4
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_CRCGenCompute
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          datainReg                       :   IN    std_logic;
          validIn                         :   IN    std_logic;  -- ufix1
          processMsg                      :   IN    std_logic;  -- ufix1
          padZero                         :   IN    std_logic;  -- ufix1
          counter                         :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          regClr                          :   IN    std_logic;  -- ufix1
          crcChecksum_0                   :   OUT   std_logic;  -- ufix1
          crcChecksum_1                   :   OUT   std_logic;  -- ufix1
          crcChecksum_2                   :   OUT   std_logic;  -- ufix1
          crcChecksum_3                   :   OUT   std_logic;  -- ufix1
          crcChecksum_4                   :   OUT   std_logic;  -- ufix1
          crcChecksum_5                   :   OUT   std_logic;  -- ufix1
          crcChecksum_6                   :   OUT   std_logic;  -- ufix1
          crcChecksum_7                   :   OUT   std_logic;  -- ufix1
          crcChecksum_8                   :   OUT   std_logic;  -- ufix1
          crcChecksum_9                   :   OUT   std_logic;  -- ufix1
          crcChecksum_10                  :   OUT   std_logic;  -- ufix1
          crcChecksum_11                  :   OUT   std_logic;  -- ufix1
          crcChecksum_12                  :   OUT   std_logic;  -- ufix1
          crcChecksum_13                  :   OUT   std_logic;  -- ufix1
          crcChecksum_14                  :   OUT   std_logic;  -- ufix1
          crcChecksum_15                  :   OUT   std_logic  -- ufix1
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlPBCHDecoder_CRCGenControl
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_CRCGenControl(rtl);

  FOR ALL : ltehdlPBCHDecoder_CRCGenCompute
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_CRCGenCompute(rtl);

  -- Signals
  SIGNAL tstartout                        : std_logic;  -- ufix1
  SIGNAL processMsg                       : std_logic;  -- ufix1
  SIGNAL padZero                          : std_logic;  -- ufix1
  SIGNAL outputCRC                        : std_logic;  -- ufix1
  SIGNAL lastfout                         : std_logic;  -- ufix1
  SIGNAL validdata                        : std_logic;  -- ufix1
  SIGNAL regClr                           : std_logic;  -- ufix1
  SIGNAL counter                          : std_logic_vector(3 DOWNTO 0);  -- ufix4
  SIGNAL counter_opcrc                    : std_logic_vector(3 DOWNTO 0);  -- ufix4
  SIGNAL msgenb                           : std_logic;  -- ufix1
  SIGNAL datainReg                        : std_logic := '0';
  SIGNAL alpha_reg_rsvd                   : std_logic_vector(15 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [16]
  SIGNAL dataBuffer                       : std_logic;  -- ufix1
  SIGNAL counter_opcrc_unsigned           : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL crcCheckSum                      : std_logic_vector(15 DOWNTO 0);  -- ufix1 [16]
  SIGNAL crcp1                            : std_logic;  -- ufix1
  SIGNAL crcp2                            : std_logic;  -- ufix1
  SIGNAL crcp3                            : std_logic;  -- ufix1
  SIGNAL crcp4                            : std_logic;  -- ufix1
  SIGNAL crcp5                            : std_logic;  -- ufix1
  SIGNAL crcp6                            : std_logic;  -- ufix1
  SIGNAL crcp7                            : std_logic;  -- ufix1
  SIGNAL crcp8                            : std_logic;  -- ufix1
  SIGNAL crcp9                            : std_logic;  -- ufix1
  SIGNAL crcp10                           : std_logic;  -- ufix1
  SIGNAL crcp11                           : std_logic;  -- ufix1
  SIGNAL crcp12                           : std_logic;  -- ufix1
  SIGNAL crcp13                           : std_logic;  -- ufix1
  SIGNAL crcp14                           : std_logic;  -- ufix1
  SIGNAL crcp15                           : std_logic;  -- ufix1
  SIGNAL crcp16                           : std_logic;  -- ufix1
  SIGNAL crcOut                           : std_logic;  -- ufix1
  SIGNAL msgcrc                           : std_logic;  -- ufix1
  SIGNAL tdataout                         : std_logic;  -- ufix1
  SIGNAL tstartoutGated                   : std_logic;  -- ufix1

BEGIN
  UControlsignal_inst : ltehdlPBCHDecoder_CRCGenControl
    PORT MAP( clk => clk,
              enb => enb,
              startIn => startIn,  -- ufix1
              endIn => endIn,  -- ufix1
              validIn => validIn,  -- ufix1
              startOut => tstartout,  -- ufix1
              processMsg => processMsg,  -- ufix1
              padZero => padZero,  -- ufix1
              outputCRC => outputCRC,  -- ufix1
              endOut => lastfout,  -- ufix1
              validOut => validdata,  -- ufix1
              regClr => regClr,  -- ufix1
              counter => counter,  -- ufix4
              counter_outputCRC => counter_opcrc  -- ufix4
              );

  UComputeCRC_inst : ltehdlPBCHDecoder_CRCGenCompute
    PORT MAP( clk => clk,
              enb => enb,
              datainReg => datainReg,
              validIn => validIn,  -- ufix1
              processMsg => processMsg,  -- ufix1
              padZero => padZero,  -- ufix1
              counter => counter,  -- ufix4
              regClr => regClr,  -- ufix1
              crcChecksum_0 => crcCheckSum(0),  -- ufix1
              crcChecksum_1 => crcCheckSum(1),  -- ufix1
              crcChecksum_2 => crcCheckSum(2),  -- ufix1
              crcChecksum_3 => crcCheckSum(3),  -- ufix1
              crcChecksum_4 => crcCheckSum(4),  -- ufix1
              crcChecksum_5 => crcCheckSum(5),  -- ufix1
              crcChecksum_6 => crcCheckSum(6),  -- ufix1
              crcChecksum_7 => crcCheckSum(7),  -- ufix1
              crcChecksum_8 => crcCheckSum(8),  -- ufix1
              crcChecksum_9 => crcCheckSum(9),  -- ufix1
              crcChecksum_10 => crcCheckSum(10),  -- ufix1
              crcChecksum_11 => crcCheckSum(11),  -- ufix1
              crcChecksum_12 => crcCheckSum(12),  -- ufix1
              crcChecksum_13 => crcCheckSum(13),  -- ufix1
              crcChecksum_14 => crcCheckSum(14),  -- ufix1
              crcChecksum_15 => crcCheckSum(15)  -- ufix1
              );

  msgenb <= processMsg OR padZero;

  datainput_register_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        datainReg <= dataIn;
      END IF;
    END IF;
  END PROCESS datainput_register_process;


  -- Buffer Input Data
  c_c_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND enb = '1' AND msgenb = '1' THEN
        alpha_reg_rsvd(0) <= datainReg;
        alpha_reg_rsvd(15 DOWNTO 1) <= alpha_reg_rsvd(14 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS c_c_process;

  dataBuffer <= alpha_reg_rsvd(15);

  counter_opcrc_unsigned <= unsigned(counter_opcrc);


  -- Select CRC output bits
  crcp1 <= crcCheckSum(0);

  -- Select CRC output bits
  crcp2 <= crcCheckSum(1);

  -- Select CRC output bits
  crcp3 <= crcCheckSum(2);

  -- Select CRC output bits
  crcp4 <= crcCheckSum(3);

  -- Select CRC output bits
  crcp5 <= crcCheckSum(4);

  -- Select CRC output bits
  crcp6 <= crcCheckSum(5);

  -- Select CRC output bits
  crcp7 <= crcCheckSum(6);

  -- Select CRC output bits
  crcp8 <= crcCheckSum(7);

  -- Select CRC output bits
  crcp9 <= crcCheckSum(8);

  -- Select CRC output bits
  crcp10 <= crcCheckSum(9);

  -- Select CRC output bits
  crcp11 <= crcCheckSum(10);

  -- Select CRC output bits
  crcp12 <= crcCheckSum(11);

  -- Select CRC output bits
  crcp13 <= crcCheckSum(12);

  -- Select CRC output bits
  crcp14 <= crcCheckSum(13);

  -- Select CRC output bits
  crcp15 <= crcCheckSum(14);

  -- Select CRC output bits
  crcp16 <= crcCheckSum(15);

  
  crcOut <= crcp1 WHEN counter_opcrc_unsigned = to_unsigned(16#0#, 4) ELSE
      crcp2 WHEN counter_opcrc_unsigned = to_unsigned(16#1#, 4) ELSE
      crcp3 WHEN counter_opcrc_unsigned = to_unsigned(16#2#, 4) ELSE
      crcp4 WHEN counter_opcrc_unsigned = to_unsigned(16#3#, 4) ELSE
      crcp5 WHEN counter_opcrc_unsigned = to_unsigned(16#4#, 4) ELSE
      crcp6 WHEN counter_opcrc_unsigned = to_unsigned(16#5#, 4) ELSE
      crcp7 WHEN counter_opcrc_unsigned = to_unsigned(16#6#, 4) ELSE
      crcp8 WHEN counter_opcrc_unsigned = to_unsigned(16#7#, 4) ELSE
      crcp9 WHEN counter_opcrc_unsigned = to_unsigned(16#8#, 4) ELSE
      crcp10 WHEN counter_opcrc_unsigned = to_unsigned(16#9#, 4) ELSE
      crcp11 WHEN counter_opcrc_unsigned = to_unsigned(16#A#, 4) ELSE
      crcp12 WHEN counter_opcrc_unsigned = to_unsigned(16#B#, 4) ELSE
      crcp13 WHEN counter_opcrc_unsigned = to_unsigned(16#C#, 4) ELSE
      crcp14 WHEN counter_opcrc_unsigned = to_unsigned(16#D#, 4) ELSE
      crcp15 WHEN counter_opcrc_unsigned = to_unsigned(16#E#, 4) ELSE
      crcp16;

  
  msgcrc <= dataBuffer WHEN outputCRC = '0' ELSE
      crcOut;

  -- Output data and CRC CheckSum
  -- Constant Zero
  
  tdataout <= '0' WHEN validdata = '0' ELSE
      msgcrc;

  -- Data output register
  dataOut_register_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        dataOut <= tdataout;
      END IF;
    END IF;
  END PROCESS dataOut_register_process;


  tstartoutGated <= tstartout AND validdata;

  -- startOut output register
  startOut_register_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        startOut <= tstartoutGated;
      END IF;
    END IF;
  END PROCESS startOut_register_process;


  -- endOut output register
  endout_register_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        endOut <= lastfout;
      END IF;
    END IF;
  END PROCESS endout_register_process;


  -- validOut output register
  validout_register_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        validOut <= validdata;
      END IF;
    END IF;
  END PROCESS validout_register_process;


END rtl;

