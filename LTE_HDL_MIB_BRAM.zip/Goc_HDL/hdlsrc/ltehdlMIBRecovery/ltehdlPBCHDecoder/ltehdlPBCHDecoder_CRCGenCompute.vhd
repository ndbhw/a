-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_CRCGenCompute IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        datainReg                         :   IN    std_logic;  -- ufix1
        validIn                           :   IN    std_logic;  -- ufix1
        processMsg                        :   IN    std_logic;  -- ufix1
        padZero                           :   IN    std_logic;  -- ufix1
        counter                           :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        regClr                            :   IN    std_logic;  -- ufix1
        crcChecksum_0                     :   OUT   std_logic;  -- ufix1
        crcChecksum_1                     :   OUT   std_logic;  -- ufix1
        crcChecksum_2                     :   OUT   std_logic;  -- ufix1
        crcChecksum_3                     :   OUT   std_logic;  -- ufix1
        crcChecksum_4                     :   OUT   std_logic;  -- ufix1
        crcChecksum_5                     :   OUT   std_logic;  -- ufix1
        crcChecksum_6                     :   OUT   std_logic;  -- ufix1
        crcChecksum_7                     :   OUT   std_logic;  -- ufix1
        crcChecksum_8                     :   OUT   std_logic;  -- ufix1
        crcChecksum_9                     :   OUT   std_logic;  -- ufix1
        crcChecksum_10                    :   OUT   std_logic;  -- ufix1
        crcChecksum_11                    :   OUT   std_logic;  -- ufix1
        crcChecksum_12                    :   OUT   std_logic;  -- ufix1
        crcChecksum_13                    :   OUT   std_logic;  -- ufix1
        crcChecksum_14                    :   OUT   std_logic;  -- ufix1
        crcChecksum_15                    :   OUT   std_logic  -- ufix1
        );
END ltehdlPBCHDecoder_CRCGenCompute;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_CRCGenCompute IS

  -- Signals
  SIGNAL counter_unsigned                 : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL xoredSel                         : std_logic;  -- ufix1
  SIGNAL dvalidin                         : std_logic := '0';  -- ufix1
  SIGNAL tcsSel                           : std_logic;  -- ufix1
  SIGNAL csSel                            : std_logic;  -- ufix1
  SIGNAL checksumRst                      : std_logic;  -- ufix1
  SIGNAL rpadZero                         : std_logic;  -- ufix1
  SIGNAL dataSel                          : std_logic;  -- ufix1
  SIGNAL padingzeros                      : std_logic_vector(15 DOWNTO 0);  -- ufix1 [16]
  SIGNAL inputzeros                       : std_logic_vector(14 DOWNTO 0);  -- ufix1 [15]
  SIGNAL datamux                          : std_logic_vector(15 DOWNTO 0);  -- ufix1 [16]
  SIGNAL datacpt                          : std_logic_vector(15 DOWNTO 0);  -- ufix1 [16]
  SIGNAL datacpt_15                       : std_logic;  -- ufix1
  SIGNAL datacpt_14                       : std_logic;  -- ufix1
  SIGNAL datacpt_13                       : std_logic;  -- ufix1
  SIGNAL datacpt_12                       : std_logic;  -- ufix1
  SIGNAL datacpt_11                       : std_logic;  -- ufix1
  SIGNAL datacpt_10                       : std_logic;  -- ufix1
  SIGNAL datacpt_9                        : std_logic;  -- ufix1
  SIGNAL datacpt_8                        : std_logic;  -- ufix1
  SIGNAL datacpt_7                        : std_logic;  -- ufix1
  SIGNAL datacpt_6                        : std_logic;  -- ufix1
  SIGNAL datacpt_5                        : std_logic;  -- ufix1
  SIGNAL datacpt_4                        : std_logic;  -- ufix1
  SIGNAL datacpt_3                        : std_logic;  -- ufix1
  SIGNAL datacpt_2                        : std_logic;  -- ufix1
  SIGNAL datacpt_1                        : std_logic;  -- ufix1
  SIGNAL datacpt_0                        : std_logic;  -- ufix1
  SIGNAL finalXorValue                    : std_logic_vector(15 DOWNTO 0);  -- ufix1 [16]
  SIGNAL newChecksum                      : std_logic_vector(15 DOWNTO 0);  -- ufix1 [16]
  SIGNAL Selector_sub_temp                : vector_of_signed32(0 TO 15);  -- int32 [16]
  SIGNAL refelctCheckSum                  : std_logic_vector(15 DOWNTO 0);  -- ufix1 [16]
  SIGNAL xoredChecksum                    : std_logic_vector(15 DOWNTO 0);  -- ufix1 [16]
  SIGNAL checksumReg                      : std_logic_vector(15 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [16]
  SIGNAL checksumReg_14                   : std_logic;  -- ufix1
  SIGNAL tcs_entry15                      : std_logic;  -- ufix1
  SIGNAL checksumReg_13                   : std_logic;  -- ufix1
  SIGNAL tcs_entry14                      : std_logic;  -- ufix1
  SIGNAL checksumReg_12                   : std_logic;  -- ufix1
  SIGNAL tcs_entry13                      : std_logic;  -- ufix1
  SIGNAL checksumReg_11                   : std_logic;  -- ufix1
  SIGNAL checksumReg_15                   : std_logic;  -- ufix1
  SIGNAL tcs_entry12                      : std_logic;  -- ufix1
  SIGNAL checksumReg_10                   : std_logic;  -- ufix1
  SIGNAL tcs_entry11                      : std_logic;  -- ufix1
  SIGNAL checksumReg_9                    : std_logic;  -- ufix1
  SIGNAL tcs_entry10                      : std_logic;  -- ufix1
  SIGNAL checksumReg_8                    : std_logic;  -- ufix1
  SIGNAL tcs_entry9                       : std_logic;  -- ufix1
  SIGNAL checksumReg_7                    : std_logic;  -- ufix1
  SIGNAL tcs_entry8                       : std_logic;  -- ufix1
  SIGNAL checksumReg_6                    : std_logic;  -- ufix1
  SIGNAL tcs_entry7                       : std_logic;  -- ufix1
  SIGNAL checksumReg_5                    : std_logic;  -- ufix1
  SIGNAL tcs_entry6                       : std_logic;  -- ufix1
  SIGNAL checksumReg_4                    : std_logic;  -- ufix1
  SIGNAL tcs_entry5                       : std_logic;  -- ufix1
  SIGNAL checksumReg_3                    : std_logic;  -- ufix1
  SIGNAL tcs_entry4                       : std_logic;  -- ufix1
  SIGNAL checksumReg_2                    : std_logic;  -- ufix1
  SIGNAL tcs_entry3                       : std_logic;  -- ufix1
  SIGNAL checksumReg_1                    : std_logic;  -- ufix1
  SIGNAL tcs_entry2                       : std_logic;  -- ufix1
  SIGNAL checksumReg_0                    : std_logic;  -- ufix1
  SIGNAL tcs_entry1                       : std_logic;  -- ufix1
  SIGNAL tcs_entry0                       : std_logic;  -- ufix1
  SIGNAL tchecksum                        : std_logic_vector(15 DOWNTO 0);  -- ufix1 [16]
  SIGNAL finalChecksum                    : std_logic_vector(15 DOWNTO 0);  -- ufix1 [16]
  SIGNAL crcChecksum                      : std_logic_vector(15 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [16]

BEGIN
  counter_unsigned <= unsigned(counter);

  
  xoredSel <= '1' WHEN counter_unsigned = to_unsigned(16#F#, 4) ELSE
      '0';

  validin_register_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        dvalidin <= validIn;
      END IF;
    END IF;
  END PROCESS validin_register_process;


  tcsSel <= processMsg AND dvalidin;

  csSel <= tcsSel OR padZero;

  checksumRst <= xoredSel OR regClr;

  rpadZero <=  NOT padZero;

  -- Selection signal: Select input data or pad zeros
  dataSel <= rpadZero AND dvalidin;

  -- Padding zeros
  padingzeros <= (OTHERS => '0');

  inputzeros <= (OTHERS => '0');

  -- Prepare inputs for parallel CRC computation
  datamux(0) <= inputzeros(0);
  datamux(1) <= inputzeros(1);
  datamux(2) <= inputzeros(2);
  datamux(3) <= inputzeros(3);
  datamux(4) <= inputzeros(4);
  datamux(5) <= inputzeros(5);
  datamux(6) <= inputzeros(6);
  datamux(7) <= inputzeros(7);
  datamux(8) <= inputzeros(8);
  datamux(9) <= inputzeros(9);
  datamux(10) <= inputzeros(10);
  datamux(11) <= inputzeros(11);
  datamux(12) <= inputzeros(12);
  datamux(13) <= inputzeros(13);
  datamux(14) <= inputzeros(14);
  datamux(15) <= datainReg;

  -- Switch between input data and padded zeros
  
  datacpt <= padingzeros WHEN dataSel = '0' ELSE
      datamux;

  datacpt_15 <= datacpt(15);

  datacpt_14 <= datacpt(14);

  datacpt_13 <= datacpt(13);

  datacpt_12 <= datacpt(12);

  datacpt_11 <= datacpt(11);

  datacpt_10 <= datacpt(10);

  datacpt_9 <= datacpt(9);

  datacpt_8 <= datacpt(8);

  datacpt_7 <= datacpt(7);

  datacpt_6 <= datacpt(6);

  datacpt_5 <= datacpt(5);

  datacpt_4 <= datacpt(4);

  datacpt_3 <= datacpt(3);

  datacpt_2 <= datacpt(2);

  datacpt_1 <= datacpt(1);

  datacpt_0 <= datacpt(0);

  -- Compute finalXor
  finalXorValue <= (OTHERS => '0');

  -- Reflect Checksum and make checksum LSB first

  refelctCheckSum_gen: FOR ii_select IN 0 TO 15 GENERATE
    Selector_sub_temp(ii_select) <= to_signed(16 - ii_select, 32);
    refelctCheckSum(ii_select) <= newChecksum(to_integer(Selector_sub_temp(ii_select) - 1));
  END GENERATE refelctCheckSum_gen;



  xoredChecksum_gen: FOR t_0 IN 0 TO 15 GENERATE
    xoredChecksum(t_0) <= refelctCheckSum(t_0) XOR finalXorValue(t_0);
  END GENERATE xoredChecksum_gen;


  checksumReg_14 <= checksumReg(14);

  -- Compute checksum element16
  tcs_entry15 <= checksumReg_14 XOR datacpt_0;

  checksumReg_13 <= checksumReg(13);

  -- Compute checksum element15
  tcs_entry14 <= checksumReg_13 XOR datacpt_1;

  checksumReg_12 <= checksumReg(12);

  -- Compute checksum element14
  tcs_entry13 <= checksumReg_12 XOR datacpt_2;

  checksumReg_11 <= checksumReg(11);

  -- Compute checksum element13
  tcs_entry12 <= datacpt_3 XOR (checksumReg_15 XOR checksumReg_11);

  checksumReg_10 <= checksumReg(10);

  -- Compute checksum element12
  tcs_entry11 <= checksumReg_10 XOR datacpt_4;

  checksumReg_9 <= checksumReg(9);

  -- Compute checksum element11
  tcs_entry10 <= checksumReg_9 XOR datacpt_5;

  checksumReg_8 <= checksumReg(8);

  -- Compute checksum element10
  tcs_entry9 <= checksumReg_8 XOR datacpt_6;

  checksumReg_7 <= checksumReg(7);

  -- Compute checksum element9
  tcs_entry8 <= checksumReg_7 XOR datacpt_7;

  checksumReg_6 <= checksumReg(6);

  -- Compute checksum element8
  tcs_entry7 <= checksumReg_6 XOR datacpt_8;

  checksumReg_5 <= checksumReg(5);

  -- Compute checksum element7
  tcs_entry6 <= checksumReg_5 XOR datacpt_9;

  checksumReg_4 <= checksumReg(4);

  -- Compute checksum element6
  tcs_entry5 <= datacpt_10 XOR (checksumReg_15 XOR checksumReg_4);

  checksumReg_3 <= checksumReg(3);

  -- Compute checksum element5
  tcs_entry4 <= checksumReg_3 XOR datacpt_11;

  checksumReg_2 <= checksumReg(2);

  -- Compute checksum element4
  tcs_entry3 <= checksumReg_2 XOR datacpt_12;

  checksumReg_1 <= checksumReg(1);

  -- Compute checksum element3
  tcs_entry2 <= checksumReg_1 XOR datacpt_13;

  checksumReg_0 <= checksumReg(0);

  -- Compute checksum element2
  tcs_entry1 <= checksumReg_0 XOR datacpt_14;

  checksumReg_15 <= checksumReg(15);

  -- Compute checksum element1
  -- Checksum selection signal
  tcs_entry0 <= checksumReg_15 XOR datacpt_15;

  tchecksum(0) <= tcs_entry0;
  tchecksum(1) <= tcs_entry1;
  tchecksum(2) <= tcs_entry2;
  tchecksum(3) <= tcs_entry3;
  tchecksum(4) <= tcs_entry4;
  tchecksum(5) <= tcs_entry5;
  tchecksum(6) <= tcs_entry6;
  tchecksum(7) <= tcs_entry7;
  tchecksum(8) <= tcs_entry8;
  tchecksum(9) <= tcs_entry9;
  tchecksum(10) <= tcs_entry10;
  tchecksum(11) <= tcs_entry11;
  tchecksum(12) <= tcs_entry12;
  tchecksum(13) <= tcs_entry13;
  tchecksum(14) <= tcs_entry14;
  tchecksum(15) <= tcs_entry15;

  checksum_register_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        IF checksumRst = '1' THEN
          checksumReg <= (OTHERS => '0');
        ELSE 
          checksumReg <= finalChecksum;
        END IF;
      END IF;
    END IF;
  END PROCESS checksum_register_process;


  -- Update checksum register for valid inputs
  
  newChecksum <= checksumReg WHEN csSel = '0' ELSE
      tchecksum;

  -- Xor after computing the checksum
  
  finalChecksum <= newChecksum WHEN xoredSel = '0' ELSE
      xoredChecksum;

  -- 1
  outputchecksum_register_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND xoredSel = '1' THEN
        crcChecksum <= finalChecksum;
      END IF;
    END IF;
  END PROCESS outputchecksum_register_process;


  crcChecksum_0 <= crcChecksum(0);

  crcChecksum_1 <= crcChecksum(1);

  crcChecksum_2 <= crcChecksum(2);

  crcChecksum_3 <= crcChecksum(3);

  crcChecksum_4 <= crcChecksum(4);

  crcChecksum_5 <= crcChecksum(5);

  crcChecksum_6 <= crcChecksum(6);

  crcChecksum_7 <= crcChecksum(7);

  crcChecksum_8 <= crcChecksum(8);

  crcChecksum_9 <= crcChecksum(9);

  crcChecksum_10 <= crcChecksum(10);

  crcChecksum_11 <= crcChecksum(11);

  crcChecksum_12 <= crcChecksum(12);

  crcChecksum_13 <= crcChecksum(13);

  crcChecksum_14 <= crcChecksum(14);

  crcChecksum_15 <= crcChecksum(15);

END rtl;

