-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlPBCHDecoder_endInNet IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        endin                             :   IN    std_logic;  -- ufix1
        out_rsvd                          :   OUT   std_logic  -- ufix1
        );
END ltehdlPBCHDecoder_endInNet;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_endInNet IS

  -- Signals
  SIGNAL endInDelayerComp_reg_rsvd        : std_logic_vector(16 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [17]
  SIGNAL endInDelayerComp_reg_next        : std_logic_vector(16 DOWNTO 0);  -- ufix1 [17]

BEGIN
  -- endIn_Delayer
  endInDelayerComp_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        endInDelayerComp_reg_rsvd <= endInDelayerComp_reg_next;
      END IF;
    END IF;
  END PROCESS endInDelayerComp_process;

  endInDelayerComp_output : PROCESS (endInDelayerComp_reg_rsvd, endin)
    VARIABLE yy : std_logic;
    VARIABLE reg_temp : std_logic_vector(16 DOWNTO 0);
  BEGIN
    reg_temp := endInDelayerComp_reg_rsvd;
    reg_temp(15 DOWNTO 0) := endInDelayerComp_reg_rsvd(16 DOWNTO 1);
    reg_temp(16) := endin;
    yy := '0';

    FOR kk IN 0 TO 16 LOOP
      yy := yy OR reg_temp(kk);
    END LOOP;

    out_rsvd <= yy OR endin;
    endInDelayerComp_reg_next <= reg_temp;
  END PROCESS endInDelayerComp_output;


END rtl;

