-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlPBCHDecoder;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_softBitScalingUnit IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_0                          :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        dataIn_1                          :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        dataIn_2                          :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        ctrlIn_start                      :   IN    std_logic;
        ctrlIn_end                        :   IN    std_logic;
        ctrlIn_valid                      :   IN    std_logic;
        dataOut_0                         :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
        dataOut_1                         :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
        dataOut_2                         :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
        ctrlOut_start                     :   OUT   std_logic;
        ctrlOut_end                       :   OUT   std_logic;
        ctrlOut_valid                     :   OUT   std_logic
        );
END ltehdlPBCHDecoder_softBitScalingUnit;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_softBitScalingUnit IS

  -- Component Declarations
  COMPONENT ltehdlPBCHDecoder_Symmetric_Saturation
    PORT( x_0                             :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          x_1                             :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          x_2                             :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          y_0                             :   OUT   std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          y_1                             :   OUT   std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          y_2                             :   OUT   std_logic_vector(19 DOWNTO 0)  -- sfix20_En17
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_Maximum_Average_Absolute_Value
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_0                        :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          dataIn_1                        :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          dataIn_2                        :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          ctrlIn_start                    :   IN    std_logic;
          ctrlIn_end                      :   IN    std_logic;
          ctrlIn_valid                    :   IN    std_logic;
          maxOut                          :   OUT   std_logic_vector(18 DOWNTO 0);  -- ufix19_En17
          maxValid                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_Determine_Scaling
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          maxIn                           :   IN    std_logic_vector(18 DOWNTO 0);  -- ufix19_En17
          maxValid                        :   IN    std_logic;
          shiftAmount                     :   OUT   std_logic_vector(4 DOWNTO 0);  -- ufix5
          fineGain                        :   OUT   std_logic_vector(7 DOWNTO 0);  -- ufix8_En7
          scalingValid                    :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_MemoryController
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          ctrlIn_start                    :   IN    std_logic;
          ctrlIn_end                      :   IN    std_logic;
          ctrlIn_valid                    :   IN    std_logic;
          startReading                    :   IN    std_logic;
          addr                            :   OUT   std_logic_vector(5 DOWNTO 0);  -- ufix6
          writeEn                         :   OUT   std_logic;
          ctrlOut_start                   :   OUT   std_logic;
          ctrlOut_end                     :   OUT   std_logic;
          ctrlOut_valid                   :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_SinglePortRAM_generic
    GENERIC( AddrWidth                    : integer;
             DataWidth                    : integer
             );
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          din                             :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          addr                            :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          we                              :   IN    std_logic;
          dout                            :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0)  -- generic width
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_Apply_Scaling
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          shiftAmount                     :   IN    std_logic_vector(4 DOWNTO 0);  -- ufix5
          fineGain                        :   IN    std_logic_vector(7 DOWNTO 0);  -- ufix8_En7
          dataIn_0                        :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          dataIn_1                        :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          dataIn_2                        :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          ctrlIn_start                    :   IN    std_logic;
          ctrlIn_end                      :   IN    std_logic;
          ctrlIn_valid                    :   IN    std_logic;
          dataOut_0                       :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
          dataOut_1                       :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
          dataOut_2                       :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
          ctrlOut_start                   :   OUT   std_logic;
          ctrlOut_end                     :   OUT   std_logic;
          ctrlOut_valid                   :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlPBCHDecoder_Symmetric_Saturation
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_Symmetric_Saturation(rtl);

  FOR ALL : ltehdlPBCHDecoder_Maximum_Average_Absolute_Value
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_Maximum_Average_Absolute_Value(rtl);

  FOR ALL : ltehdlPBCHDecoder_Determine_Scaling
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_Determine_Scaling(rtl);

  FOR ALL : ltehdlPBCHDecoder_MemoryController
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_MemoryController(rtl);

  FOR ALL : ltehdlPBCHDecoder_SinglePortRAM_generic
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_SinglePortRAM_generic(rtl);

  FOR ALL : ltehdlPBCHDecoder_Apply_Scaling
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_Apply_Scaling(rtl);

  -- Signals
  SIGNAL dataIn                           : vector_of_std_logic_vector20(0 TO 2);  -- ufix20 [3]
  SIGNAL dataIn_3                         : vector_of_signed20(0 TO 2);  -- sfix20_En17 [3]
  SIGNAL y_0                              : std_logic_vector(19 DOWNTO 0);  -- ufix20
  SIGNAL y_1                              : std_logic_vector(19 DOWNTO 0);  -- ufix20
  SIGNAL y_2                              : std_logic_vector(19 DOWNTO 0);  -- ufix20
  SIGNAL y_y                              : vector_of_signed20(0 TO 2);  -- sfix20_En17 [3]
  SIGNAL maxAvDataIn                      : vector_of_signed20(0 TO 2) := (OTHERS => to_signed(16#00000#, 20));  -- sfix20_En17 [3]
  SIGNAL axAvCtrlIn_start                 : std_logic := '0';
  SIGNAL axAvCtrlIn_end                   : std_logic := '0';
  SIGNAL axAvCtrlIn_valid                 : std_logic := '0';
  SIGNAL maxOut                           : std_logic_vector(18 DOWNTO 0);  -- ufix19
  SIGNAL maxValid                         : std_logic;
  SIGNAL shiftAmount                      : std_logic_vector(4 DOWNTO 0);  -- ufix5
  SIGNAL fineGain                         : std_logic_vector(7 DOWNTO 0);  -- ufix8
  SIGNAL scalingValid                     : std_logic;
  SIGNAL addr                             : std_logic_vector(5 DOWNTO 0);  -- ufix6
  SIGNAL writeEn                          : std_logic;
  SIGNAL ctrlOut_start_1                  : std_logic;
  SIGNAL ctrlOut_end_1                    : std_logic;
  SIGNAL ctrlOut_valid_1                  : std_logic;
  SIGNAL pri_wr_out_1_1                   : std_logic_vector(19 DOWNTO 0);  -- ufix20
  SIGNAL pri_wr_out_1_2                   : std_logic_vector(19 DOWNTO 0);  -- ufix20
  SIGNAL dataOut                          : vector_of_std_logic_vector20(0 TO 2);  -- ufix20 [3]
  SIGNAL dataOut_3                        : vector_of_signed20(0 TO 2);  -- sfix20_En17 [3]
  SIGNAL validOut_start                   : std_logic := '0';
  SIGNAL validOut_end                     : std_logic := '0';
  SIGNAL validOut_valid                   : std_logic := '0';
  SIGNAL Apply_Scaling_dataOut_0          : std_logic_vector(3 DOWNTO 0);  -- ufix4
  SIGNAL Apply_Scaling_dataOut_1          : std_logic_vector(3 DOWNTO 0);  -- ufix4
  SIGNAL Apply_Scaling_dataOut_2          : std_logic_vector(3 DOWNTO 0);  -- ufix4
  SIGNAL Apply_Scaling_ctrlOut_start      : std_logic;
  SIGNAL Apply_Scaling_ctrlOut_end        : std_logic;
  SIGNAL Apply_Scaling_ctrlOut_valid      : std_logic;

BEGIN
  -- start reading data from RAM once the scaling terms are ready
  -- shiftAmount and fineGain are constant after scalingValid goes HIGH.

  USymmetric_Saturation : ltehdlPBCHDecoder_Symmetric_Saturation
    PORT MAP( x_0 => std_logic_vector(dataIn_3(0)),  -- sfix20_En17
              x_1 => dataIn_1,  -- sfix20_En17
              x_2 => dataIn_2,  -- sfix20_En17
              y_0 => y_0,  -- sfix20_En17
              y_1 => y_1,  -- sfix20_En17
              y_2 => y_2  -- sfix20_En17
              );

  UMaximum_Average_Absolute_Va : ltehdlPBCHDecoder_Maximum_Average_Absolute_Value
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              dataIn_0 => std_logic_vector(maxAvDataIn(0)),  -- sfix20_En17
              dataIn_1 => std_logic_vector(maxAvDataIn(1)),  -- sfix20_En17
              dataIn_2 => std_logic_vector(maxAvDataIn(2)),  -- sfix20_En17
              ctrlIn_start => axAvCtrlIn_start,
              ctrlIn_end => axAvCtrlIn_end,
              ctrlIn_valid => axAvCtrlIn_valid,
              maxOut => maxOut,  -- ufix19_En17
              maxValid => maxValid
              );

  UDetermine_Scaling : ltehdlPBCHDecoder_Determine_Scaling
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              maxIn => maxOut,  -- ufix19_En17
              maxValid => maxValid,
              shiftAmount => shiftAmount,  -- ufix5
              fineGain => fineGain,  -- ufix8_En7
              scalingValid => scalingValid
              );

  UMemoryController : ltehdlPBCHDecoder_MemoryController
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              ctrlIn_start => ctrlIn_start,
              ctrlIn_end => ctrlIn_end,
              ctrlIn_valid => ctrlIn_valid,
              startReading => scalingValid,
              addr => addr,  -- ufix6
              writeEn => writeEn,
              ctrlOut_start => ctrlOut_start_1,
              ctrlOut_end => ctrlOut_end_1,
              ctrlOut_valid => ctrlOut_valid_1
              );

  USimple_Dual_Port_RAM_System_2 : ltehdlPBCHDecoder_SinglePortRAM_generic
    GENERIC MAP( AddrWidth => 6,
                 DataWidth => 20
                 )
    PORT MAP( clk => clk,
              enb => enb,
              din => std_logic_vector(maxAvDataIn(0)),
              addr => addr,
              we => writeEn,
              dout => dataOut(0)
              );

  USimple_Dual_Port_RAM_System_1 : ltehdlPBCHDecoder_SinglePortRAM_generic
    GENERIC MAP( AddrWidth => 6,
                 DataWidth => 20
                 )
    PORT MAP( clk => clk,
              enb => enb,
              din => std_logic_vector(maxAvDataIn(1)),
              addr => addr,
              we => writeEn,
              dout => pri_wr_out_1_1
              );

  USimple_Dual_Port_RAM_System : ltehdlPBCHDecoder_SinglePortRAM_generic
    GENERIC MAP( AddrWidth => 6,
                 DataWidth => 20
                 )
    PORT MAP( clk => clk,
              enb => enb,
              din => std_logic_vector(maxAvDataIn(2)),
              addr => addr,
              we => writeEn,
              dout => pri_wr_out_1_2
              );

  UApply_Scaling : ltehdlPBCHDecoder_Apply_Scaling
    PORT MAP( clk => clk,
              enb => enb,
              shiftAmount => shiftAmount,  -- ufix5
              fineGain => fineGain,  -- ufix8_En7
              dataIn_0 => std_logic_vector(dataOut_3(0)),  -- sfix20_En17
              dataIn_1 => pri_wr_out_1_1,  -- sfix20_En17
              dataIn_2 => pri_wr_out_1_2,  -- sfix20_En17
              ctrlIn_start => validOut_start,
              ctrlIn_end => validOut_end,
              ctrlIn_valid => validOut_valid,
              dataOut_0 => Apply_Scaling_dataOut_0,  -- sfix4_En1
              dataOut_1 => Apply_Scaling_dataOut_1,  -- sfix4_En1
              dataOut_2 => Apply_Scaling_dataOut_2,  -- sfix4_En1
              ctrlOut_start => Apply_Scaling_ctrlOut_start,
              ctrlOut_end => Apply_Scaling_ctrlOut_end,
              ctrlOut_valid => Apply_Scaling_ctrlOut_valid
              );

  dataIn(0) <= dataIn_0;
  dataIn(1) <= dataIn_1;
  dataIn(2) <= dataIn_2;

  outputgen1: FOR kk IN 0 TO 2 GENERATE
    dataIn_3(kk) <= signed(dataIn(kk));
  END GENERATE;

  y_y(0) <= signed(y_0);
  y_y(1) <= signed(y_1);
  y_y(2) <= signed(y_2);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        maxAvDataIn <= y_y;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  c_c_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        axAvCtrlIn_start <= ctrlIn_start;
      END IF;
    END IF;
  END PROCESS c_c_process;


  c_c_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        axAvCtrlIn_end <= ctrlIn_end;
      END IF;
    END IF;
  END PROCESS c_c_1_process;


  c_c_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        axAvCtrlIn_valid <= ctrlIn_valid;
      END IF;
    END IF;
  END PROCESS c_c_2_process;


  dataOut(1) <= pri_wr_out_1_1;
  dataOut(2) <= pri_wr_out_1_2;

  outputgen: FOR kk IN 0 TO 2 GENERATE
    dataOut_3(kk) <= signed(dataOut(kk));
  END GENERATE;

  c_c_3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        validOut_start <= ctrlOut_start_1;
      END IF;
    END IF;
  END PROCESS c_c_3_process;


  c_c_4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        validOut_end <= ctrlOut_end_1;
      END IF;
    END IF;
  END PROCESS c_c_4_process;


  c_c_5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        validOut_valid <= ctrlOut_valid_1;
      END IF;
    END IF;
  END PROCESS c_c_5_process;


  dataOut_0 <= Apply_Scaling_dataOut_0;

  dataOut_1 <= Apply_Scaling_dataOut_1;

  dataOut_2 <= Apply_Scaling_dataOut_2;

  ctrlOut_start <= Apply_Scaling_ctrlOut_start;

  ctrlOut_end <= Apply_Scaling_ctrlOut_end;

  ctrlOut_valid <= Apply_Scaling_ctrlOut_valid;

END rtl;

