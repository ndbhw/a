-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlPBCHDecoder;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_PBCH_Rate_Recovery IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        data                              :   IN    std_logic_vector(17 DOWNTO 0);  -- sfix18_En17
        enb_1                             :   IN    std_logic;
        rateRecovered_0                   :   OUT   std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        rateRecovered_1                   :   OUT   std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        rateRecovered_2                   :   OUT   std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        validOut                          :   OUT   std_logic
        );
END ltehdlPBCHDecoder_PBCH_Rate_Recovery;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_PBCH_Rate_Recovery IS

  -- Component Declarations
  COMPONENT ltehdlPBCHDecoder_rateRecovery
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          u1                              :   IN    std_logic_vector(17 DOWNTO 0);  -- sfix18_En17
          enb_1                           :   IN    std_logic;
          y_0                             :   OUT   std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          y_1                             :   OUT   std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          y_2                             :   OUT   std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlPBCHDecoder_rateRecovery
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_rateRecovery(rtl);

  -- Signals
  SIGNAL data_signed                      : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Delay1_reg_rsvd                  : vector_of_signed18(0 TO 1) := (OTHERS => to_signed(16#00000#, 18));  -- sfix18 [2]
  SIGNAL Delay1_out1                      : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Delay4_reg_rsvd                  : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [2]
  SIGNAL Delay4_out1                      : std_logic;
  SIGNAL y_0                              : std_logic_vector(19 DOWNTO 0);  -- ufix20
  SIGNAL y_1                              : std_logic_vector(19 DOWNTO 0);  -- ufix20
  SIGNAL y_2                              : std_logic_vector(19 DOWNTO 0);  -- ufix20
  SIGNAL validOut_1                       : std_logic;
  SIGNAL y_y                              : vector_of_signed20(0 TO 2);  -- sfix20_En17 [3]
  SIGNAL Delay2_reg_rsvd                  : vector_of_signed20(0 TO 5) := (OTHERS => to_signed(16#00000#, 20));  -- sfix20 [6]
  SIGNAL Delay2_out1                      : vector_of_signed20(0 TO 2);  -- sfix20_En17 [3]
  SIGNAL Delay3_reg_rsvd                  : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [2]
  SIGNAL Delay3_out1                      : std_logic;

BEGIN
  UrateRecovery : ltehdlPBCHDecoder_rateRecovery
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              u1 => std_logic_vector(Delay1_out1),  -- sfix18_En17
              enb_1 => Delay4_out1,
              y_0 => y_0,  -- sfix20_En17
              y_1 => y_1,  -- sfix20_En17
              y_2 => y_2,  -- sfix20_En17
              validOut => validOut_1
              );

  data_signed <= signed(data);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_reg_rsvd(0) <= data_signed;
        Delay1_reg_rsvd(1) <= Delay1_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay1_process;

  Delay1_out1 <= Delay1_reg_rsvd(1);

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay4_reg_rsvd(0) <= enb_1;
        Delay4_reg_rsvd(1) <= Delay4_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay4_process;

  Delay4_out1 <= Delay4_reg_rsvd(1);

  y_y(0) <= signed(y_0);
  y_y(1) <= signed(y_1);
  y_y(2) <= signed(y_2);

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_reg_rsvd(0 TO 2) <= y_y(0 TO 2);
        Delay2_reg_rsvd(3 TO 5) <= Delay2_reg_rsvd(0 TO 2);
      END IF;
    END IF;
  END PROCESS Delay2_process;

  Delay2_out1(0 TO 2) <= Delay2_reg_rsvd(3 TO 5);

  rateRecovered_0 <= std_logic_vector(Delay2_out1(0));

  rateRecovered_1 <= std_logic_vector(Delay2_out1(1));

  rateRecovered_2 <= std_logic_vector(Delay2_out1(2));

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_reg_rsvd(0) <= validOut_1;
        Delay3_reg_rsvd(1) <= Delay3_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay3_process;

  Delay3_out1 <= Delay3_reg_rsvd(1);

  validOut <= Delay3_out1;

END rtl;

