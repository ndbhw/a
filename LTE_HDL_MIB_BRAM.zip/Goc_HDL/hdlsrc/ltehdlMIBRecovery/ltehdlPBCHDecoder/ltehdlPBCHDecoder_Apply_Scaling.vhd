-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlPBCHDecoder;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_Apply_Scaling IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        shiftAmount                       :   IN    std_logic_vector(4 DOWNTO 0);  -- ufix5
        fineGain                          :   IN    std_logic_vector(7 DOWNTO 0);  -- ufix8_En7
        dataIn_0                          :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        dataIn_1                          :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        dataIn_2                          :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        ctrlIn_start                      :   IN    std_logic;
        ctrlIn_end                        :   IN    std_logic;
        ctrlIn_valid                      :   IN    std_logic;
        dataOut_0                         :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
        dataOut_1                         :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
        dataOut_2                         :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
        ctrlOut_start                     :   OUT   std_logic;
        ctrlOut_end                       :   OUT   std_logic;
        ctrlOut_valid                     :   OUT   std_logic
        );
END ltehdlPBCHDecoder_Apply_Scaling;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_Apply_Scaling IS

  -- Component Declarations
  COMPONENT ltehdlPBCHDecoder_Sign_Extend_by_2
    PORT( x_0                             :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          x_1                             :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          x_2                             :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          y_0                             :   OUT   std_logic_vector(21 DOWNTO 0);  -- sfix22_En17
          y_1                             :   OUT   std_logic_vector(21 DOWNTO 0);  -- sfix22_En17
          y_2                             :   OUT   std_logic_vector(21 DOWNTO 0)  -- sfix22_En17
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_Rounding_Symmetric_Saturation
    PORT( dataScaled_0                    :   IN    std_logic_vector(29 DOWNTO 0);  -- sfix30_En24
          dataScaled_1                    :   IN    std_logic_vector(29 DOWNTO 0);  -- sfix30_En24
          dataScaled_2                    :   IN    std_logic_vector(29 DOWNTO 0);  -- sfix30_En24
          validIn                         :   IN    std_logic;
          dataInDT_0                      :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          dataInDT_1                      :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          dataInDT_2                      :   IN    std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
          dataOut_0                       :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
          dataOut_1                       :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
          dataOut_2                       :   OUT   std_logic_vector(3 DOWNTO 0)  -- sfix4_En1
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlPBCHDecoder_Sign_Extend_by_2
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_Sign_Extend_by_2(rtl);

  FOR ALL : ltehdlPBCHDecoder_Rounding_Symmetric_Saturation
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_Rounding_Symmetric_Saturation(rtl);

  -- Signals
  SIGNAL fineGain_unsigned                : unsigned(7 DOWNTO 0);  -- ufix8_En7
  SIGNAL y_0                              : std_logic_vector(21 DOWNTO 0);  -- ufix22
  SIGNAL y_1                              : std_logic_vector(21 DOWNTO 0);  -- ufix22
  SIGNAL y_2                              : std_logic_vector(21 DOWNTO 0);  -- ufix22
  SIGNAL y_0_signed                       : signed(21 DOWNTO 0);  -- sfix22_En17
  SIGNAL shiftAmount_unsigned             : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL shift_arithmetic_1_cast          : unsigned(7 DOWNTO 0);  -- uint8
  SIGNAL out_1                            : signed(21 DOWNTO 0);  -- sfix22_En17
  SIGNAL y_1_signed                       : signed(21 DOWNTO 0);  -- sfix22_En17
  SIGNAL shift_arithmetic_2_cast          : unsigned(7 DOWNTO 0);  -- uint8
  SIGNAL out_2                            : signed(21 DOWNTO 0);  -- sfix22_En17
  SIGNAL y_2_signed                       : signed(21 DOWNTO 0);  -- sfix22_En17
  SIGNAL shift_arithmetic_3_cast          : unsigned(7 DOWNTO 0);  -- uint8
  SIGNAL out_3                            : signed(21 DOWNTO 0);  -- sfix22_En17
  SIGNAL Shift_Arithmetic_out1            : vector_of_signed22(0 TO 2);  -- sfix22_En17 [3]
  SIGNAL Delay2_out1                      : vector_of_signed22(0 TO 2) := (OTHERS => to_signed(16#000000#, 22));  -- sfix22_En17 [3]
  SIGNAL Product_rsvd_cast                : vector_of_signed9(0 TO 2);  -- sfix9_En7 [3]
  SIGNAL Product_rsvd_mul_temp            : vector_of_signed31(0 TO 2);  -- sfix31_En24 [3]
  SIGNAL Product_out1                     : vector_of_signed30(0 TO 2);  -- sfix30_En24 [3]
  SIGNAL tb_dataScaled                    : vector_of_signed30(0 TO 2) := (OTHERS => to_signed(16#00000000#, 30));  -- sfix30_En24 [3]
  SIGNAL Delay5_out1_valid                : std_logic := '0';
  SIGNAL Delay1_out1_valid                : std_logic := '0';
  SIGNAL valid                            : std_logic;
  SIGNAL dataOut_0_1                      : std_logic_vector(3 DOWNTO 0);  -- ufix4
  SIGNAL dataOut_1_1                      : std_logic_vector(3 DOWNTO 0);  -- ufix4
  SIGNAL dataOut_2_1                      : std_logic_vector(3 DOWNTO 0);  -- ufix4
  SIGNAL dataOut                          : vector_of_signed4(0 TO 2);  -- sfix4_En1 [3]
  SIGNAL Delay6_out1                      : vector_of_signed4(0 TO 2) := (OTHERS => to_signed(16#0#, 4));  -- sfix4_En1 [3]
  SIGNAL Delay5_out1_start                : std_logic := '0';
  SIGNAL Delay1_out1_start                : std_logic := '0';
  SIGNAL Delay3_out1_start                : std_logic := '0';
  SIGNAL Delay5_out1_end                  : std_logic := '0';
  SIGNAL Delay1_out1_end                  : std_logic := '0';
  SIGNAL Delay3_out1_end                  : std_logic := '0';
  SIGNAL Delay3_out1_valid                : std_logic := '0';

BEGIN
  -- dataInDT is used to convey type information only.
  -- Its signal values are not used.
  -- coarse gain (left shift)
  -- fine gain

  USign_Extend_by_2 : ltehdlPBCHDecoder_Sign_Extend_by_2
    PORT MAP( x_0 => dataIn_0,  -- sfix20_En17
              x_1 => dataIn_1,  -- sfix20_En17
              x_2 => dataIn_2,  -- sfix20_En17
              y_0 => y_0,  -- sfix22_En17
              y_1 => y_1,  -- sfix22_En17
              y_2 => y_2  -- sfix22_En17
              );

  URounding_Symmetric_Saturati : ltehdlPBCHDecoder_Rounding_Symmetric_Saturation
    PORT MAP( dataScaled_0 => std_logic_vector(tb_dataScaled(0)),  -- sfix30_En24
              dataScaled_1 => std_logic_vector(tb_dataScaled(1)),  -- sfix30_En24
              dataScaled_2 => std_logic_vector(tb_dataScaled(2)),  -- sfix30_En24
              validIn => valid,
              dataInDT_0 => dataIn_0,  -- sfix20_En17
              dataInDT_1 => dataIn_1,  -- sfix20_En17
              dataInDT_2 => dataIn_2,  -- sfix20_En17
              dataOut_0 => dataOut_0_1,  -- sfix4_En1
              dataOut_1 => dataOut_1_1,  -- sfix4_En1
              dataOut_2 => dataOut_2_1  -- sfix4_En1
              );

  fineGain_unsigned <= unsigned(fineGain);

  y_0_signed <= signed(y_0);

  shiftAmount_unsigned <= unsigned(shiftAmount);

  shift_arithmetic_1_cast <= resize(shiftAmount_unsigned, 8);
  out_1 <= y_0_signed sll to_integer(shift_arithmetic_1_cast);

  y_1_signed <= signed(y_1);

  shift_arithmetic_2_cast <= resize(shiftAmount_unsigned, 8);
  out_2 <= y_1_signed sll to_integer(shift_arithmetic_2_cast);

  y_2_signed <= signed(y_2);

  shift_arithmetic_3_cast <= resize(shiftAmount_unsigned, 8);
  out_3 <= y_2_signed sll to_integer(shift_arithmetic_3_cast);

  Shift_Arithmetic_out1(0) <= out_1;
  Shift_Arithmetic_out1(1) <= out_2;
  Shift_Arithmetic_out1(2) <= out_3;

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_out1 <= Shift_Arithmetic_out1;
      END IF;
    END IF;
  END PROCESS Delay2_process;



  Product_out1_gen: FOR t_0 IN 0 TO 2 GENERATE
    Product_rsvd_cast(t_0) <= signed(resize(fineGain_unsigned, 9));
    Product_rsvd_mul_temp(t_0) <= Product_rsvd_cast(t_0) * Delay2_out1(t_0);
    Product_out1(t_0) <= Product_rsvd_mul_temp(t_0)(29 DOWNTO 0);
  END GENERATE Product_out1_gen;


  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        tb_dataScaled <= Product_out1;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  c_c_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay5_out1_valid <= ctrlIn_valid;
      END IF;
    END IF;
  END PROCESS c_c_process;


  c_c_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1_valid <= Delay5_out1_valid;
      END IF;
    END IF;
  END PROCESS c_c_1_process;


  valid <= Delay1_out1_valid;

  dataOut(0) <= signed(dataOut_0_1);
  dataOut(1) <= signed(dataOut_1_1);
  dataOut(2) <= signed(dataOut_2_1);

  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay6_out1 <= dataOut;
      END IF;
    END IF;
  END PROCESS Delay6_process;


  dataOut_0 <= std_logic_vector(Delay6_out1(0));

  dataOut_1 <= std_logic_vector(Delay6_out1(1));

  dataOut_2 <= std_logic_vector(Delay6_out1(2));

  c_c_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay5_out1_start <= ctrlIn_start;
      END IF;
    END IF;
  END PROCESS c_c_2_process;


  c_c_3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1_start <= Delay5_out1_start;
      END IF;
    END IF;
  END PROCESS c_c_3_process;


  c_c_4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1_start <= Delay1_out1_start;
      END IF;
    END IF;
  END PROCESS c_c_4_process;


  c_c_5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay5_out1_end <= ctrlIn_end;
      END IF;
    END IF;
  END PROCESS c_c_5_process;


  c_c_6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1_end <= Delay5_out1_end;
      END IF;
    END IF;
  END PROCESS c_c_6_process;


  c_c_7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1_end <= Delay1_out1_end;
      END IF;
    END IF;
  END PROCESS c_c_7_process;


  c_c_8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1_valid <= Delay1_out1_valid;
      END IF;
    END IF;
  END PROCESS c_c_8_process;


  ctrlOut_start <= Delay3_out1_start;

  ctrlOut_end <= Delay3_out1_end;

  ctrlOut_valid <= Delay3_out1_valid;

END rtl;

