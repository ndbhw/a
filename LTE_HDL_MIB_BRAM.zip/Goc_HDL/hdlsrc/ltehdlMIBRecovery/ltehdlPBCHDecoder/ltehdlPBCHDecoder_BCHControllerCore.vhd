-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlPBCHDecoder_BCHControllerCore IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        ctrlIn_start                      :   IN    std_logic;
        ctrlIn_end                        :   IN    std_logic;
        ctrlIn_valid                      :   IN    std_logic;
        crcmask                           :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        clearReg                          :   IN    std_logic;
        repeat_QPSK                       :   OUT   std_logic;
        MIB_detected                      :   OUT   std_logic;
        restart_MIB                       :   OUT   std_logic;
        nfmod4                            :   OUT   std_logic_vector(1 DOWNTO 0);  -- ufix2
        cellrefp                          :   OUT   std_logic_vector(2 DOWNTO 0)  -- ufix3
        );
END ltehdlPBCHDecoder_BCHControllerCore;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_BCHControllerCore IS

  -- Signals
  SIGNAL crcmask_unsigned                 : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL nfmod4_tmp                       : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL cellrefp_tmp                     : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL nfcnt                            : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL cellrefp_reg                     : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL nfcnt_next                       : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL cellrefp_reg_next                : unsigned(2 DOWNTO 0);  -- ufix3

BEGIN
  crcmask_unsigned <= unsigned(crcmask);

  BCHControllerCore_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        nfcnt <= to_unsigned(16#0#, 2);
        cellrefp_reg <= to_unsigned(16#0#, 3);
      ELSIF enb = '1' THEN
        nfcnt <= nfcnt_next;
        cellrefp_reg <= cellrefp_reg_next;
      END IF;
    END IF;
  END PROCESS BCHControllerCore_process;

  BCHControllerCore_output : PROCESS (cellrefp_reg, clearReg, crcmask_unsigned, ctrlIn_end, ctrlIn_valid, nfcnt)
    VARIABLE MIB_detected1 : std_logic;
  BEGIN
    nfcnt_next <= nfcnt;
    cellrefp_reg_next <= cellrefp_reg;
    repeat_QPSK <= '0';
    MIB_detected1 := '0';
    restart_MIB <= '0';
    IF clearReg = '1' THEN 
      nfcnt_next <= to_unsigned(16#0#, 2);
      cellrefp_reg_next <= to_unsigned(16#0#, 3);
    ELSIF (ctrlIn_valid AND ctrlIn_end) = '1' THEN 
      CASE crcmask_unsigned IS
        WHEN "0000000000000000" =>
          cellrefp_reg_next <= to_unsigned(16#1#, 3);
          MIB_detected1 := '1';
        WHEN "1111111111111111" =>
          cellrefp_reg_next <= to_unsigned(16#2#, 3);
          MIB_detected1 := '1';
        WHEN "0101010101010101" =>
          cellrefp_reg_next <= to_unsigned(16#4#, 3);
          MIB_detected1 := '1';
        WHEN OTHERS => 
          cellrefp_reg_next <= to_unsigned(16#0#, 3);
      END CASE;
      IF ( NOT MIB_detected1) = '1' THEN 
        IF nfcnt = to_unsigned(16#3#, 2) THEN 
          restart_MIB <= '1';
          nfcnt_next <= to_unsigned(16#0#, 2);
        ELSE 
          repeat_QPSK <= '1';
          nfcnt_next <= nfcnt + to_unsigned(16#1#, 2);
        END IF;
      ELSE 
        restart_MIB <= '1';
        nfcnt_next <= to_unsigned(16#0#, 2);
      END IF;
    END IF;
    MIB_detected <= MIB_detected1;
    nfmod4_tmp <= nfcnt;
    cellrefp_tmp <= cellrefp_reg;
  END PROCESS BCHControllerCore_output;


  nfmod4 <= std_logic_vector(nfmod4_tmp);

  cellrefp <= std_logic_vector(cellrefp_tmp);

END rtl;

