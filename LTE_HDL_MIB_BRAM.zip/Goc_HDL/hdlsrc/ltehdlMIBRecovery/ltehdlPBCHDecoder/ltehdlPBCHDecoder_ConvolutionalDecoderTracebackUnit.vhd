-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlPBCHDecoder;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_ConvolutionalDecoderTracebackUnit IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        varargin_1_0                      :   IN    std_logic;
        varargin_1_1                      :   IN    std_logic;
        varargin_1_2                      :   IN    std_logic;
        varargin_1_3                      :   IN    std_logic;
        varargin_1_4                      :   IN    std_logic;
        varargin_1_5                      :   IN    std_logic;
        varargin_1_6                      :   IN    std_logic;
        varargin_1_7                      :   IN    std_logic;
        varargin_1_8                      :   IN    std_logic;
        varargin_1_9                      :   IN    std_logic;
        varargin_1_10                     :   IN    std_logic;
        varargin_1_11                     :   IN    std_logic;
        varargin_1_12                     :   IN    std_logic;
        varargin_1_13                     :   IN    std_logic;
        varargin_1_14                     :   IN    std_logic;
        varargin_1_15                     :   IN    std_logic;
        varargin_1_16                     :   IN    std_logic;
        varargin_1_17                     :   IN    std_logic;
        varargin_1_18                     :   IN    std_logic;
        varargin_1_19                     :   IN    std_logic;
        varargin_1_20                     :   IN    std_logic;
        varargin_1_21                     :   IN    std_logic;
        varargin_1_22                     :   IN    std_logic;
        varargin_1_23                     :   IN    std_logic;
        varargin_1_24                     :   IN    std_logic;
        varargin_1_25                     :   IN    std_logic;
        varargin_1_26                     :   IN    std_logic;
        varargin_1_27                     :   IN    std_logic;
        varargin_1_28                     :   IN    std_logic;
        varargin_1_29                     :   IN    std_logic;
        varargin_1_30                     :   IN    std_logic;
        varargin_1_31                     :   IN    std_logic;
        varargin_1_32                     :   IN    std_logic;
        varargin_1_33                     :   IN    std_logic;
        varargin_1_34                     :   IN    std_logic;
        varargin_1_35                     :   IN    std_logic;
        varargin_1_36                     :   IN    std_logic;
        varargin_1_37                     :   IN    std_logic;
        varargin_1_38                     :   IN    std_logic;
        varargin_1_39                     :   IN    std_logic;
        varargin_1_40                     :   IN    std_logic;
        varargin_1_41                     :   IN    std_logic;
        varargin_1_42                     :   IN    std_logic;
        varargin_1_43                     :   IN    std_logic;
        varargin_1_44                     :   IN    std_logic;
        varargin_1_45                     :   IN    std_logic;
        varargin_1_46                     :   IN    std_logic;
        varargin_1_47                     :   IN    std_logic;
        varargin_1_48                     :   IN    std_logic;
        varargin_1_49                     :   IN    std_logic;
        varargin_1_50                     :   IN    std_logic;
        varargin_1_51                     :   IN    std_logic;
        varargin_1_52                     :   IN    std_logic;
        varargin_1_53                     :   IN    std_logic;
        varargin_1_54                     :   IN    std_logic;
        varargin_1_55                     :   IN    std_logic;
        varargin_1_56                     :   IN    std_logic;
        varargin_1_57                     :   IN    std_logic;
        varargin_1_58                     :   IN    std_logic;
        varargin_1_59                     :   IN    std_logic;
        varargin_1_60                     :   IN    std_logic;
        varargin_1_61                     :   IN    std_logic;
        varargin_1_62                     :   IN    std_logic;
        varargin_1_63                     :   IN    std_logic;
        varargin_2                        :   IN    std_logic;
        varargin_3                        :   IN    std_logic;
        varargin_4                        :   IN    std_logic;
        varargin_5                        :   IN    std_logic_vector(5 DOWNTO 0);  -- ufix6
        varargin_6                        :   IN    std_logic;
        varargin_7                        :   IN    std_logic;
        varargout_1                       :   OUT   std_logic;
        varargout_2                       :   OUT   std_logic;
        varargout_3                       :   OUT   std_logic;
        varargout_4                       :   OUT   std_logic
        );
END ltehdlPBCHDecoder_ConvolutionalDecoderTracebackUnit;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_ConvolutionalDecoderTracebackUnit IS

  -- Component Declarations
  COMPONENT ltehdlPBCHDecoder_SinglePortRAM_generic_block
    GENERIC( AddrWidth                    : integer;
             DataWidth                    : integer
             );
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          din                             :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          addr                            :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          we                              :   IN    std_logic;
          dout                            :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0)  -- generic width
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_SimpleDualPortRAM_singlebit
    GENERIC( AddrWidth                    : integer;
             DataWidth                    : integer
             );
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          wr_din                          :   IN    std_logic;  -- ufix1
          wr_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          wr_en                           :   IN    std_logic;
          rd_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          dout                            :   OUT   std_logic  -- ufix1
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlPBCHDecoder_SinglePortRAM_generic_block
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_SinglePortRAM_generic_block(rtl);

  FOR ALL : ltehdlPBCHDecoder_SimpleDualPortRAM_singlebit
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_SimpleDualPortRAM_singlebit(rtl);

  -- Constants
  CONSTANT nc                             : std_logic_vector(2 DOWNTO 0) := 
    ('1', '0', '1');  -- boolean [3]
  CONSTANT nc_2                           : std_logic_vector(2 DOWNTO 0) := 
    ('1', '0', '0');  -- boolean [3]
  CONSTANT nc_4                           : std_logic_vector(2 DOWNTO 0) := 
    ('1', '1', '0');  -- boolean [3]

  -- Functions
  -- HDLCODER_TO_STDLOGIC 
  FUNCTION hdlcoder_to_stdlogic(arg: boolean) RETURN std_logic IS
  BEGIN
    IF arg THEN
      RETURN '1';
    ELSE
      RETURN '0';
    END IF;
  END FUNCTION;


  -- Signals
  SIGNAL varargout_2_1                    : std_logic;
  SIGNAL varargout_3_1                    : std_logic;
  SIGNAL varargout_4_1                    : std_logic;
  SIGNAL varargout_6                      : std_logic;
  SIGNAL extEndMsgDelayed                 : std_logic;
  SIGNAL s_s                              : std_logic;
  SIGNAL obj_tracebackUnit_trelDec_validInReg : std_logic := '0';
  SIGNAL obj_tracebackUnit_trelDec_endExtInReg : std_logic := '0';
  SIGNAL trelDecNext_state                : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL trelDecNext_state_1              : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL tmp                              : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL trelDecNext_state_2              : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL trelDecNext_state_3              : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL trelDecNext_state_4              : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL tmp_1                            : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL trelDecNext_count                : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL trelDecNext_count_1              : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL trelDecNext_count_2              : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL trelDecNext_state_5              : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL trelDecNext_state_6              : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL trelDecNext_state_7              : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL trelDecNext_state_8              : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL obj_tracebackUnit_trelDec_count  : unsigned(8 DOWNTO 0) := to_unsigned(16#000#, 9);  -- ufix9
  SIGNAL tmp_2                            : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL s_s_1                            : std_logic;
  SIGNAL tmp_3                            : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_4                            : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_5                            : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_6                            : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_7                            : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_8                            : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_9                            : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL s_s_2                            : signed(31 DOWNTO 0);  -- int32
  SIGNAL tmp_10                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_11                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_12                           : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL obj_tracebackUnit_trelDec_state  : unsigned(2 DOWNTO 0) := to_unsigned(16#0#, 3);  -- ufix3
  SIGNAL tmp_13                           : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL tmp_14                           : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL tmp_15                           : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL obj_tracebackUnit_trelDec_stateReg : unsigned(2 DOWNTO 0) := to_unsigned(16#0#, 3);  -- ufix3
  SIGNAL tmp_16                           : std_logic;
  SIGNAL obj_tracebackUnit_trelDec_tracingBack : std_logic := '0';
  SIGNAL ramDataIn                        : unsigned(63 DOWNTO 0);  -- ufix64
  SIGNAL x_x                              : std_logic_vector(63 DOWNTO 0);  -- boolean [64]
  SIGNAL trelDecNext_decisionsReg         : std_logic_vector(63 DOWNTO 0);  -- boolean [64]
  SIGNAL varargout_1_1                    : std_logic_vector(63 DOWNTO 0);  -- boolean [64]
  SIGNAL trelDecNext_decisionsReg_1       : std_logic_vector(63 DOWNTO 0);  -- boolean [64]
  SIGNAL obj_tracebackUnit_trelDec_decisionsReg : std_logic_vector(63 DOWNTO 0) := (OTHERS => '0');  -- boolean [64]
  SIGNAL obj_tracebackUnit_trelDec_decisionsReg_1 : std_logic_vector(63 DOWNTO 0);  -- boolean [64]
  SIGNAL x_x_1                            : std_logic_vector(63 DOWNTO 0);  -- boolean [64]
  SIGNAL ramDataIn_1                      : unsigned(63 DOWNTO 0);  -- ufix64
  SIGNAL wrEn                             : std_logic;
  SIGNAL tmp_18                           : std_logic_vector(63 DOWNTO 0);  -- ufix64
  SIGNAL tmp_unsigned                     : unsigned(63 DOWNTO 0);  -- ufix64
  SIGNAL obj_tracebackUnit_trelDec_RAMOutReg : unsigned(63 DOWNTO 0) := to_unsigned(0, 64);  -- ufix64
  SIGNAL varargin_5_unsigned              : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL obj_tracebackUnit_trelDec_winningState : unsigned(5 DOWNTO 0) := to_unsigned(16#00#, 6);  -- ufix6
  SIGNAL tmp_19                           : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL p220tmp_bit_idx                  : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL tmp_20                           : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL tmp_21                           : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL tmp_22                           : std_logic;  -- ufix1
  SIGNAL obj_tracebackUnit_msgBuf_RAMDataIn : std_logic := '0';  -- ufix1
  SIGNAL trelDecNext_countReg             : vector_of_unsigned9(0 TO 1);  -- ufix9 [2]
  SIGNAL obj_tracebackUnit_trelDec_countReg : vector_of_unsigned9(0 TO 1) := (OTHERS => to_unsigned(16#000#, 9));  -- ufix9 [2]
  SIGNAL trelDecNext_countReg_1           : vector_of_unsigned9(0 TO 1);  -- ufix9 [2]
  SIGNAL trelDecNext_countReg_2           : vector_of_unsigned9(0 TO 1);  -- ufix9 [2]
  SIGNAL obj_tracebackUnit_trelDec_countReg_1 : vector_of_unsigned9(0 TO 1);  -- ufix9 [2]
  SIGNAL tracebackCountOut                : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_23                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tracebackCountOut_1              : std_logic;
  SIGNAL guard1                           : std_logic;
  SIGNAL tmp_24                           : std_logic;
  SIGNAL obj_tracebackUnit_trelDec_trellisEnd : std_logic := '0';
  SIGNAL tmp_25                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL obj_tracebackUnit_msgBuf_tbTrainingStartAddr : unsigned(8 DOWNTO 0) := to_unsigned(16#000#, 9);  -- ufix9
  SIGNAL tmp_26                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tracebackCountOut_2              : std_logic;
  SIGNAL guard1_1                         : std_logic;
  SIGNAL guard1_2                         : std_logic;
  SIGNAL tmp_27                           : std_logic;
  SIGNAL tmp_28                           : std_logic;
  SIGNAL s_s_3                            : std_logic;
  SIGNAL msgLocNext_counting              : std_logic;
  SIGNAL msgLocNext_inputCount            : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL msgLocNext_inputCount_1          : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL msgLocNext_inputCount_2          : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL msgLocNext_startMsg              : std_logic;
  SIGNAL obj_tracebackUnit_msgLoc_startMsg : std_logic := '0';
  SIGNAL tmp_29                           : std_logic;
  SIGNAL tmp_30                           : std_logic;
  SIGNAL msgLocNext_counting_1            : std_logic;
  SIGNAL msgLocNext_counting_2            : std_logic;
  SIGNAL msgLocNext_counting_3            : std_logic;
  SIGNAL obj_tracebackUnit_msgLoc_inputCount : unsigned(8 DOWNTO 0) := to_unsigned(16#000#, 9);  -- ufix9
  SIGNAL tmp_31                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL s_s_4                            : std_logic;
  SIGNAL tmp_32                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL obj_tracebackUnit_msgLoc_counting : std_logic := '0';
  SIGNAL tmp_33                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_34                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_35                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_36                           : std_logic;
  SIGNAL tmp_37                           : std_logic;
  SIGNAL tmp_38                           : std_logic;
  SIGNAL tmp_39                           : std_logic;
  SIGNAL msgLocNext_msgStartAddr          : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_40                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL msgLocNext_msgStartAddr_1        : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL obj_tracebackUnit_msgLoc_msgStartAddr : unsigned(8 DOWNTO 0) := to_unsigned(16#000#, 9);  -- ufix9
  SIGNAL tmp_41                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_42                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_43                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tracebackCountOut_3              : std_logic;
  SIGNAL msgLocNext_msgLengthAquired      : std_logic;
  SIGNAL msgLocNext_msgLengthAquired_1    : std_logic;
  SIGNAL msgLocNext_msgLengthAquired_2    : std_logic;
  SIGNAL tmp_44                           : std_logic;
  SIGNAL msgLocNext_msgLengthAquired_3    : std_logic;
  SIGNAL s_s_5                            : std_logic;
  SIGNAL tmp_45                           : std_logic;
  SIGNAL obj_tracebackUnit_msgLoc_msgLengthAquired : std_logic := '0';
  SIGNAL tmp_46                           : std_logic;
  SIGNAL tmp_47                           : std_logic;
  SIGNAL tmp_48                           : std_logic;
  SIGNAL msgLocNext_msgLengthMinus1       : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_49                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL msgLocNext_msgLengthMinus1_1     : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL obj_tracebackUnit_msgLoc_msgLengthMinus1 : unsigned(8 DOWNTO 0) := to_unsigned(16#000#, 9);  -- ufix9
  SIGNAL tmp_50                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_51                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_52                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_53                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_54                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL obj_tracebackUnit_msgBuf_sliceB_offset : unsigned(8 DOWNTO 0) := to_unsigned(16#000#, 9);  -- ufix9
  SIGNAL tmp_55                           : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL tmp_56                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tmp_57                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tmp_58                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tmp_59                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL obj_tracebackUnit_msgBuf_RAMWrAddr : unsigned(7 DOWNTO 0) := to_unsigned(16#00#, 8);  -- ufix8
  SIGNAL tmp_60                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tmp_61                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tmp_62                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tmp_63                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL msgBufNext_RAMWr                 : std_logic;
  SIGNAL msgBufNext_RAMWr_1               : std_logic;
  SIGNAL msgBufNext_RAMWr_2               : std_logic;
  SIGNAL tmp_64                           : std_logic;
  SIGNAL msgBufNext_RAMWr_3               : std_logic;
  SIGNAL obj_tracebackUnit_msgBuf_RAMWr   : std_logic := '0';
  SIGNAL tmp_65                           : std_logic;
  SIGNAL tmp_66                           : std_logic;
  SIGNAL tmp_67                           : std_logic;
  SIGNAL tmp_68                           : std_logic;
  SIGNAL s_s_6                            : std_logic;
  SIGNAL s_s_7                            : std_logic;
  SIGNAL s_s_8                            : std_logic;
  SIGNAL tmp_69                           : std_logic;
  SIGNAL obj_tracebackUnit_trelDec_trellisStart : std_logic := '0';
  SIGNAL s_s_9                            : std_logic;
  SIGNAL s_s_10                           : std_logic;
  SIGNAL s_s_11                           : std_logic;
  SIGNAL tmp_70                           : std_logic;
  SIGNAL obj_tracebackUnit_msgBuf_lastWrite : std_logic := '0';
  SIGNAL msgBufNext_state                 : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL msgBufNext_state_1               : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL tmp_71                           : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL msgBufNext_state_2               : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL msgBufNext_state_3               : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL msgBufNext_state_4               : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL msgBufNext_state_5               : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL msgBufNext_RAMRdAddr             : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL msgBufNext_RAMRdAddr_1           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tmp_72                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL msgBufNext_RAMRdAddr_2           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL msgBufNext_RAMRdAddr_3           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL obj_tracebackUnit_msgBuf_RAMRdAddr : unsigned(7 DOWNTO 0) := to_unsigned(16#00#, 8);  -- ufix8
  SIGNAL tmp_73                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tmp_74                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL a0                               : std_logic;
  SIGNAL tmp_75                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tmp_76                           : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL s_s_12                           : signed(31 DOWNTO 0);  -- int32
  SIGNAL tmp_77                           : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL tmp_78                           : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL obj_tracebackUnit_msgBuf_state   : unsigned(1 DOWNTO 0) := to_unsigned(16#0#, 2);  -- ufix2
  SIGNAL tmp_79                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tmp_80                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL a_a                              : std_logic;  -- ufix1
  SIGNAL tmp_81                           : std_logic;
  SIGNAL obj_tracebackUnit_dataOut        : std_logic := '0';
  SIGNAL msgBufNext_RAMCtrlOut            : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL msgBufNext_FSMCtrlOut            : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL tmp_82                           : std_logic;
  SIGNAL msgBufNext_FSMCtrlOut_1          : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL msgBufNext_FSMCtrlOut_2          : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL msgBufNext_FSMCtrlOut_3          : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL tmp_83                           : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL msgBufNext_FSMCtrlOut_4          : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL msgBufNext_FSMCtrlOut_5          : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL msgBufNext_FSMCtrlOut_6          : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL msgBufNext_FSMCtrlOut_7          : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL tmp_84                           : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL msgBufNext_FSMCtrlOut_8          : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL tmp_85                           : std_logic;
  SIGNAL msgBufNext_FSMCtrlOut_9          : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL tmp_86                           : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL msgBufNext_FSMCtrlOut_10         : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL tmp_87                           : std_logic;
  SIGNAL msgBufNext_FSMCtrlOut_11         : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL tmp_88                           : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL obj_tracebackUnit_msgBuf_FSMCtrlOut : std_logic_vector(2 DOWNTO 0) := (OTHERS => '0');  -- boolean [3]
  SIGNAL obj_tracebackUnit_msgBuf_FSMCtrlOut_1 : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL msgBufNext_RAMCtrlOut_1          : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL obj_tracebackUnit_msgBuf_RAMCtrlOut : std_logic_vector(2 DOWNTO 0) := (OTHERS => '0');  -- boolean [3]
  SIGNAL obj_tracebackUnit_msgBuf_RAMCtrlOut_1 : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL tmp_89                           : std_logic;
  SIGNAL obj_tracebackUnit_startOut       : std_logic := '0';
  SIGNAL tmp_90                           : std_logic;
  SIGNAL obj_tracebackUnit_endOut         : std_logic := '0';
  SIGNAL tmp_91                           : std_logic;
  SIGNAL obj_tracebackUnit_validOut       : std_logic := '0';

BEGIN
  UsinglePortRam : ltehdlPBCHDecoder_SinglePortRAM_generic_block
    GENERIC MAP( AddrWidth => 9,
                 DataWidth => 64
                 )
    PORT MAP( clk => clk,
              enb => enb,
              din => std_logic_vector(ramDataIn_1),
              addr => std_logic_vector(obj_tracebackUnit_trelDec_count),
              we => wrEn,
              dout => tmp_18
              );

  UsimpleDualPortRam_singlebit : ltehdlPBCHDecoder_SimpleDualPortRAM_singlebit
    GENERIC MAP( AddrWidth => 8,
                 DataWidth => 1
                 )
    PORT MAP( clk => clk,
              enb => enb,
              wr_din => obj_tracebackUnit_msgBuf_RAMDataIn,  -- ufix1
              wr_addr => std_logic_vector(obj_tracebackUnit_msgBuf_RAMWrAddr),
              wr_en => obj_tracebackUnit_msgBuf_RAMWr,
              rd_addr => std_logic_vector(obj_tracebackUnit_msgBuf_RAMRdAddr),
              dout => a_a  -- ufix1
              );

  varargout_2_1 <= varargin_2;

  varargout_3_1 <= varargin_3;

  varargout_4_1 <= varargin_4;

  varargout_6 <= varargin_6;

  extEndMsgDelayed <= varargin_7;

  s_s <= varargout_4_1 AND varargout_2_1;

  obj_tracebackUnit_trelDec_validInReg_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_trelDec_validInReg <= varargout_4_1;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_trelDec_validInReg_reg_process;


  obj_tracebackUnit_trelDec_endExtInReg_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_trelDec_endExtInReg <= varargout_3_1;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_trelDec_endExtInReg_reg_process;


  trelDecNext_state <= to_unsigned(16#1#, 3);

  trelDecNext_state_1 <= to_unsigned(16#3#, 3);

  
  tmp <= trelDecNext_state WHEN obj_tracebackUnit_trelDec_endExtInReg = '0' ELSE
      trelDecNext_state_1;

  trelDecNext_state_2 <= to_unsigned(16#2#, 3);

  trelDecNext_state_3 <= to_unsigned(16#2#, 3);

  trelDecNext_state_4 <= to_unsigned(16#4#, 3);

  
  tmp_1 <= trelDecNext_state_3 WHEN varargout_6 = '0' ELSE
      trelDecNext_state_4;

  trelDecNext_count <= to_unsigned(16#000#, 9);

  trelDecNext_count_1 <= to_unsigned(16#000#, 9);

  trelDecNext_count_2 <= to_unsigned(16#000#, 9);

  trelDecNext_state_5 <= to_unsigned(16#0#, 3);

  trelDecNext_state_6 <= to_unsigned(16#4#, 3);

  trelDecNext_state_7 <= to_unsigned(16#0#, 3);

  trelDecNext_state_8 <= to_unsigned(16#1#, 3);

  tmp_2 <= obj_tracebackUnit_trelDec_count - to_unsigned(16#001#, 9);

  
  tmp_3 <= trelDecNext_count WHEN s_s_1 = '0' ELSE
      tmp_2;

  tmp_4 <= obj_tracebackUnit_trelDec_count - to_unsigned(16#001#, 9);

  
  tmp_5 <= obj_tracebackUnit_trelDec_count WHEN varargout_6 = '0' ELSE
      tmp_4;

  tmp_6 <= obj_tracebackUnit_trelDec_count + to_unsigned(16#001#, 9);

  tmp_7 <= obj_tracebackUnit_trelDec_count + to_unsigned(16#001#, 9);

  
  tmp_8 <= tmp_7 WHEN obj_tracebackUnit_trelDec_endExtInReg = '0' ELSE
      tmp_6;

  
  tmp_9 <= obj_tracebackUnit_trelDec_count WHEN obj_tracebackUnit_trelDec_validInReg = '0' ELSE
      tmp_8;

  
  tmp_10 <= tmp_9 WHEN s_s_2 = to_signed(1, 32) ELSE
      obj_tracebackUnit_trelDec_count WHEN s_s_2 = to_signed(3, 32) ELSE
      tmp_5 WHEN s_s_2 = to_signed(2, 32) ELSE
      tmp_3 WHEN s_s_2 = to_signed(4, 32) ELSE
      trelDecNext_count_1;

  
  tmp_11 <= tmp_10 WHEN s_s = '0' ELSE
      trelDecNext_count_2;

  obj_tracebackUnit_trelDec_count_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_trelDec_count <= tmp_11;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_trelDec_count_reg_process;


  
  s_s_1 <= '1' WHEN obj_tracebackUnit_trelDec_count /= to_unsigned(16#000#, 9) ELSE
      '0';

  
  tmp_12 <= trelDecNext_state_5 WHEN s_s_1 = '0' ELSE
      trelDecNext_state_6;

  
  tmp_13 <= obj_tracebackUnit_trelDec_state WHEN obj_tracebackUnit_trelDec_validInReg = '0' ELSE
      tmp;

  s_s_2 <= signed(resize(obj_tracebackUnit_trelDec_state, 32));

  
  tmp_14 <= tmp_13 WHEN s_s_2 = to_signed(1, 32) ELSE
      trelDecNext_state_2 WHEN s_s_2 = to_signed(3, 32) ELSE
      tmp_1 WHEN s_s_2 = to_signed(2, 32) ELSE
      tmp_12 WHEN s_s_2 = to_signed(4, 32) ELSE
      trelDecNext_state_7;

  
  tmp_15 <= tmp_14 WHEN s_s = '0' ELSE
      trelDecNext_state_8;

  obj_tracebackUnit_trelDec_state_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_trelDec_state <= tmp_15;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_trelDec_state_reg_process;


  obj_tracebackUnit_trelDec_stateReg_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_trelDec_stateReg <= obj_tracebackUnit_trelDec_state;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_trelDec_stateReg_reg_process;


  
  tmp_16 <= '1' WHEN obj_tracebackUnit_trelDec_stateReg = to_unsigned(16#4#, 3) ELSE
      '0';

  obj_tracebackUnit_trelDec_tracingBack_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_trelDec_tracingBack <= tmp_16;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_trelDec_tracingBack_reg_process;


  ramDataIn <= to_unsigned(0, 64);

  x_x <= (OTHERS => '0');

  trelDecNext_decisionsReg <= (OTHERS => '0');

  varargout_1_1(0) <= varargin_1_0;
  varargout_1_1(1) <= varargin_1_1;
  varargout_1_1(2) <= varargin_1_2;
  varargout_1_1(3) <= varargin_1_3;
  varargout_1_1(4) <= varargin_1_4;
  varargout_1_1(5) <= varargin_1_5;
  varargout_1_1(6) <= varargin_1_6;
  varargout_1_1(7) <= varargin_1_7;
  varargout_1_1(8) <= varargin_1_8;
  varargout_1_1(9) <= varargin_1_9;
  varargout_1_1(10) <= varargin_1_10;
  varargout_1_1(11) <= varargin_1_11;
  varargout_1_1(12) <= varargin_1_12;
  varargout_1_1(13) <= varargin_1_13;
  varargout_1_1(14) <= varargin_1_14;
  varargout_1_1(15) <= varargin_1_15;
  varargout_1_1(16) <= varargin_1_16;
  varargout_1_1(17) <= varargin_1_17;
  varargout_1_1(18) <= varargin_1_18;
  varargout_1_1(19) <= varargin_1_19;
  varargout_1_1(20) <= varargin_1_20;
  varargout_1_1(21) <= varargin_1_21;
  varargout_1_1(22) <= varargin_1_22;
  varargout_1_1(23) <= varargin_1_23;
  varargout_1_1(24) <= varargin_1_24;
  varargout_1_1(25) <= varargin_1_25;
  varargout_1_1(26) <= varargin_1_26;
  varargout_1_1(27) <= varargin_1_27;
  varargout_1_1(28) <= varargin_1_28;
  varargout_1_1(29) <= varargin_1_29;
  varargout_1_1(30) <= varargin_1_30;
  varargout_1_1(31) <= varargin_1_31;
  varargout_1_1(32) <= varargin_1_32;
  varargout_1_1(33) <= varargin_1_33;
  varargout_1_1(34) <= varargin_1_34;
  varargout_1_1(35) <= varargin_1_35;
  varargout_1_1(36) <= varargin_1_36;
  varargout_1_1(37) <= varargin_1_37;
  varargout_1_1(38) <= varargin_1_38;
  varargout_1_1(39) <= varargin_1_39;
  varargout_1_1(40) <= varargin_1_40;
  varargout_1_1(41) <= varargin_1_41;
  varargout_1_1(42) <= varargin_1_42;
  varargout_1_1(43) <= varargin_1_43;
  varargout_1_1(44) <= varargin_1_44;
  varargout_1_1(45) <= varargin_1_45;
  varargout_1_1(46) <= varargin_1_46;
  varargout_1_1(47) <= varargin_1_47;
  varargout_1_1(48) <= varargin_1_48;
  varargout_1_1(49) <= varargin_1_49;
  varargout_1_1(50) <= varargin_1_50;
  varargout_1_1(51) <= varargin_1_51;
  varargout_1_1(52) <= varargin_1_52;
  varargout_1_1(53) <= varargin_1_53;
  varargout_1_1(54) <= varargin_1_54;
  varargout_1_1(55) <= varargin_1_55;
  varargout_1_1(56) <= varargin_1_56;
  varargout_1_1(57) <= varargin_1_57;
  varargout_1_1(58) <= varargin_1_58;
  varargout_1_1(59) <= varargin_1_59;
  varargout_1_1(60) <= varargin_1_60;
  varargout_1_1(61) <= varargin_1_61;
  varargout_1_1(62) <= varargin_1_62;
  varargout_1_1(63) <= varargin_1_63;

  trelDecNext_decisionsReg_1 <= varargout_1_1;

  obj_tracebackUnit_trelDec_decisionsReg_1 <= trelDecNext_decisionsReg_1;

  obj_tracebackUnit_trelDec_decisionsReg_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_trelDec_decisionsReg <= obj_tracebackUnit_trelDec_decisionsReg_1;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_trelDec_decisionsReg_reg_process;


  x_x_1 <= obj_tracebackUnit_trelDec_decisionsReg;

  p180_output : PROCESS (ramDataIn, x_x_1)
    VARIABLE tmp17 : unsigned(63 DOWNTO 0);
    VARIABLE mask : unsigned(63 DOWNTO 0);
    VARIABLE tmp_0 : unsigned(63 DOWNTO 0);
    VARIABLE cast : unsigned(15 DOWNTO 0);
  BEGIN
    mask := to_unsigned(0, 64);
    tmp_0 := to_unsigned(0, 64);
    cast := to_unsigned(16#0000#, 16);
    tmp17 := ramDataIn;

    FOR kk IN 0 TO 63 LOOP
      cast := unsigned(to_signed(kk, 32)(15 DOWNTO 0));
      mask := to_unsigned(1, 64) sll to_integer(cast);
      IF x_x_1(kk) = '1' THEN 
        tmp_0 := tmp17 OR mask;
      ELSE 
        tmp_0 := tmp17 AND ( NOT mask);
      END IF;
      tmp17 := tmp_0;
    END LOOP;

    ramDataIn_1 <= tmp17;
  END PROCESS p180_output;


  
  wrEn <= '1' WHEN obj_tracebackUnit_trelDec_state = to_unsigned(16#1#, 3) ELSE
      '0';

  tmp_unsigned <= unsigned(tmp_18);

  obj_tracebackUnit_trelDec_RAMOutReg_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_trelDec_RAMOutReg <= tmp_unsigned;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_trelDec_RAMOutReg_reg_process;


  varargin_5_unsigned <= unsigned(varargin_5);

  p220tmp_bit_idx <= resize(resize(resize(obj_tracebackUnit_trelDec_winningState, 7) + to_unsigned(16#01#, 7), 8) - to_unsigned(16#01#, 8), 16);
  tmp_19 <= obj_tracebackUnit_trelDec_winningState(4 DOWNTO 0) & obj_tracebackUnit_trelDec_RAMOutReg(to_integer(p220tmp_bit_idx));

  
  tmp_20 <= obj_tracebackUnit_trelDec_winningState WHEN obj_tracebackUnit_trelDec_tracingBack = '0' ELSE
      tmp_19;

  
  tmp_21 <= tmp_20 WHEN varargout_6 = '0' ELSE
      varargin_5_unsigned;

  obj_tracebackUnit_trelDec_winningState_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_trelDec_winningState <= tmp_21;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_trelDec_winningState_reg_process;


  tmp_22 <= obj_tracebackUnit_trelDec_winningState(5);

  obj_tracebackUnit_msgBuf_RAMDataIn_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgBuf_RAMDataIn <= tmp_22;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgBuf_RAMDataIn_reg_process;


  trelDecNext_countReg <= (OTHERS => to_unsigned(16#000#, 9));

  trelDecNext_countReg_1 <= obj_tracebackUnit_trelDec_countReg;

  p167trelDecNext_countReg_output : PROCESS (obj_tracebackUnit_trelDec_count, obj_tracebackUnit_trelDec_countReg)
  BEGIN
    trelDecNext_countReg_2(0) <= obj_tracebackUnit_trelDec_count;
    trelDecNext_countReg_2(1) <= obj_tracebackUnit_trelDec_countReg(0);
  END PROCESS p167trelDecNext_countReg_output;


  obj_tracebackUnit_trelDec_countReg_1 <= trelDecNext_countReg_2;

  obj_tracebackUnit_trelDec_countReg_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_trelDec_countReg <= obj_tracebackUnit_trelDec_countReg_1;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_trelDec_countReg_reg_process;


  tracebackCountOut <= obj_tracebackUnit_trelDec_countReg(1);

  tmp_23 <= tracebackCountOut(7 DOWNTO 0);

  
  tracebackCountOut_1 <= '1' WHEN tracebackCountOut >= to_unsigned(16#028#, 9) ELSE
      '0';

  guard1 <= '1';

  
  tmp_24 <= '1' WHEN obj_tracebackUnit_trelDec_stateReg = to_unsigned(16#3#, 3) ELSE
      '0';

  obj_tracebackUnit_trelDec_trellisEnd_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_trelDec_trellisEnd <= tmp_24;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_trelDec_trellisEnd_reg_process;


  tmp_25 <= tracebackCountOut - to_unsigned(16#028#, 9);

  
  tmp_26 <= obj_tracebackUnit_msgBuf_tbTrainingStartAddr WHEN obj_tracebackUnit_trelDec_trellisEnd = '0' ELSE
      tmp_25;

  obj_tracebackUnit_msgBuf_tbTrainingStartAddr_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgBuf_tbTrainingStartAddr <= tmp_26;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgBuf_tbTrainingStartAddr_reg_process;


  
  tracebackCountOut_2 <= '1' WHEN tracebackCountOut < obj_tracebackUnit_msgBuf_tbTrainingStartAddr ELSE
      '0';

  guard1_1 <= '1';

  guard1_2 <= '0';

  
  tmp_27 <= guard1_1 WHEN tracebackCountOut_2 = '0' ELSE
      guard1_2;

  
  tmp_28 <= guard1 WHEN tracebackCountOut_1 = '0' ELSE
      tmp_27;

  s_s_3 <= varargout_4_1 AND varargout_2_1;

  msgLocNext_counting <= '0';

  msgLocNext_inputCount <= to_unsigned(16#000#, 9);

  msgLocNext_inputCount_1 <= to_unsigned(16#000#, 9);

  msgLocNext_inputCount_2 <= to_unsigned(16#001#, 9);

  msgLocNext_startMsg <= '0';

  
  tmp_29 <= obj_tracebackUnit_msgLoc_startMsg WHEN varargout_4_1 = '0' ELSE
      extEndMsgDelayed;

  
  tmp_30 <= tmp_29 WHEN s_s_3 = '0' ELSE
      msgLocNext_startMsg;

  obj_tracebackUnit_msgLoc_startMsg_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgLoc_startMsg <= tmp_30;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgLoc_startMsg_reg_process;


  msgLocNext_counting_1 <= '1';

  msgLocNext_counting_2 <= '0';

  msgLocNext_counting_3 <= '1';

  tmp_31 <= obj_tracebackUnit_msgLoc_inputCount + to_unsigned(16#001#, 9);

  
  tmp_32 <= tmp_31 WHEN s_s_4 = '0' ELSE
      msgLocNext_inputCount_1;

  
  tmp_33 <= msgLocNext_inputCount WHEN obj_tracebackUnit_msgLoc_counting = '0' ELSE
      tmp_32;

  
  tmp_34 <= obj_tracebackUnit_msgLoc_inputCount WHEN varargout_4_1 = '0' ELSE
      tmp_33;

  
  tmp_35 <= tmp_34 WHEN s_s_3 = '0' ELSE
      msgLocNext_inputCount_2;

  obj_tracebackUnit_msgLoc_inputCount_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgLoc_inputCount <= tmp_35;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgLoc_inputCount_reg_process;


  s_s_4 <= hdlcoder_to_stdlogic(obj_tracebackUnit_msgLoc_inputCount >= to_unsigned(16#028#, 9)) AND obj_tracebackUnit_msgLoc_startMsg;

  
  tmp_36 <= msgLocNext_counting_1 WHEN s_s_4 = '0' ELSE
      msgLocNext_counting_2;

  
  tmp_37 <= msgLocNext_counting WHEN obj_tracebackUnit_msgLoc_counting = '0' ELSE
      tmp_36;

  
  tmp_38 <= obj_tracebackUnit_msgLoc_counting WHEN varargout_4_1 = '0' ELSE
      tmp_37;

  
  tmp_39 <= tmp_38 WHEN s_s_3 = '0' ELSE
      msgLocNext_counting_3;

  obj_tracebackUnit_msgLoc_counting_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgLoc_counting <= tmp_39;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgLoc_counting_reg_process;


  msgLocNext_msgStartAddr <= to_unsigned(16#000#, 9);

  
  tmp_40 <= msgLocNext_msgStartAddr WHEN s_s_4 = '0' ELSE
      obj_tracebackUnit_msgLoc_inputCount;

  msgLocNext_msgStartAddr_1 <= to_unsigned(16#000#, 9);

  
  tmp_41 <= obj_tracebackUnit_msgLoc_msgStartAddr WHEN obj_tracebackUnit_msgLoc_counting = '0' ELSE
      tmp_40;

  
  tmp_42 <= obj_tracebackUnit_msgLoc_msgStartAddr WHEN varargout_4_1 = '0' ELSE
      tmp_41;

  
  tmp_43 <= tmp_42 WHEN s_s_3 = '0' ELSE
      msgLocNext_msgStartAddr_1;

  obj_tracebackUnit_msgLoc_msgStartAddr_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgLoc_msgStartAddr <= tmp_43;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgLoc_msgStartAddr_reg_process;


  
  tracebackCountOut_3 <= '1' WHEN tracebackCountOut >= obj_tracebackUnit_msgLoc_msgStartAddr ELSE
      '0';

  msgLocNext_msgLengthAquired <= '1';

  msgLocNext_msgLengthAquired_1 <= '0';

  msgLocNext_msgLengthAquired_2 <= '1';

  
  tmp_44 <= msgLocNext_msgLengthAquired_1 WHEN extEndMsgDelayed = '0' ELSE
      msgLocNext_msgLengthAquired_2;

  msgLocNext_msgLengthAquired_3 <= '0';

  
  tmp_45 <= msgLocNext_msgLengthAquired WHEN s_s_5 = '0' ELSE
      tmp_44;

  
  tmp_46 <= obj_tracebackUnit_msgLoc_msgLengthAquired WHEN obj_tracebackUnit_msgLoc_counting = '0' ELSE
      tmp_45;

  
  tmp_47 <= obj_tracebackUnit_msgLoc_msgLengthAquired WHEN varargout_4_1 = '0' ELSE
      tmp_46;

  
  tmp_48 <= tmp_47 WHEN s_s_3 = '0' ELSE
      msgLocNext_msgLengthAquired_3;

  obj_tracebackUnit_msgLoc_msgLengthAquired_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgLoc_msgLengthAquired <= tmp_48;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgLoc_msgLengthAquired_reg_process;


  s_s_5 <=  NOT obj_tracebackUnit_msgLoc_msgLengthAquired;

  msgLocNext_msgLengthMinus1 <= to_unsigned(16#000#, 9);

  
  tmp_49 <= msgLocNext_msgLengthMinus1 WHEN extEndMsgDelayed = '0' ELSE
      obj_tracebackUnit_msgLoc_inputCount;

  msgLocNext_msgLengthMinus1_1 <= to_unsigned(16#000#, 9);

  
  tmp_50 <= obj_tracebackUnit_msgLoc_msgLengthMinus1 WHEN s_s_5 = '0' ELSE
      tmp_49;

  
  tmp_51 <= obj_tracebackUnit_msgLoc_msgLengthMinus1 WHEN obj_tracebackUnit_msgLoc_counting = '0' ELSE
      tmp_50;

  
  tmp_52 <= obj_tracebackUnit_msgLoc_msgLengthMinus1 WHEN varargout_4_1 = '0' ELSE
      tmp_51;

  
  tmp_53 <= tmp_52 WHEN s_s_3 = '0' ELSE
      msgLocNext_msgLengthMinus1_1;

  obj_tracebackUnit_msgLoc_msgLengthMinus1_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgLoc_msgLengthMinus1 <= tmp_53;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgLoc_msgLengthMinus1_reg_process;


  tmp_54 <= resize(resize(obj_tracebackUnit_msgLoc_msgStartAddr, 11) - resize(resize(obj_tracebackUnit_msgLoc_msgLengthMinus1, 10) + to_unsigned(16#001#, 10), 11), 9);

  
  tmp_55 <= obj_tracebackUnit_msgBuf_sliceB_offset WHEN obj_tracebackUnit_trelDec_trellisEnd = '0' ELSE
      tmp_54;

  obj_tracebackUnit_msgBuf_sliceB_offset_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgBuf_sliceB_offset <= tmp_55;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgBuf_sliceB_offset_reg_process;


  tmp_56 <= resize(resize(tracebackCountOut, 10) - resize(obj_tracebackUnit_msgBuf_sliceB_offset, 10), 8);

  tmp_57 <= resize(resize(tracebackCountOut, 10) - resize(obj_tracebackUnit_msgLoc_msgStartAddr, 10), 8);

  
  tmp_58 <= tmp_56 WHEN tracebackCountOut_3 = '0' ELSE
      tmp_57;

  tmp_59 <= tracebackCountOut(7 DOWNTO 0);

  
  tmp_60 <= obj_tracebackUnit_msgBuf_RAMWrAddr WHEN tracebackCountOut_2 = '0' ELSE
      tmp_58;

  
  tmp_61 <= obj_tracebackUnit_msgBuf_RAMWrAddr WHEN tracebackCountOut_1 = '0' ELSE
      tmp_60;

  
  tmp_62 <= tmp_61 WHEN tmp_28 = '0' ELSE
      tmp_59;

  
  tmp_63 <= tmp_23 WHEN obj_tracebackUnit_trelDec_tracingBack = '0' ELSE
      tmp_62;

  obj_tracebackUnit_msgBuf_RAMWrAddr_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgBuf_RAMWrAddr <= tmp_63;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgBuf_RAMWrAddr_reg_process;


  msgBufNext_RAMWr <= '0';

  msgBufNext_RAMWr_1 <= '1';

  msgBufNext_RAMWr_2 <= '1';

  
  tmp_64 <= msgBufNext_RAMWr_1 WHEN tracebackCountOut_3 = '0' ELSE
      msgBufNext_RAMWr_2;

  msgBufNext_RAMWr_3 <= '0';

  
  tmp_65 <= obj_tracebackUnit_msgBuf_RAMWr WHEN tracebackCountOut_2 = '0' ELSE
      tmp_64;

  
  tmp_66 <= obj_tracebackUnit_msgBuf_RAMWr WHEN tracebackCountOut_1 = '0' ELSE
      tmp_65;

  
  tmp_67 <= tmp_66 WHEN tmp_28 = '0' ELSE
      msgBufNext_RAMWr_3;

  
  tmp_68 <= msgBufNext_RAMWr WHEN obj_tracebackUnit_trelDec_tracingBack = '0' ELSE
      tmp_67;

  obj_tracebackUnit_msgBuf_RAMWr_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgBuf_RAMWr <= tmp_68;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgBuf_RAMWr_reg_process;


  
  s_s_6 <= '1' WHEN (obj_tracebackUnit_trelDec_stateReg = to_unsigned(16#1#, 3)) AND (trelDecNext_countReg_1(0) = to_unsigned(16#000#, 9)) ELSE
      '0';

  s_s_7 <= '0';

  s_s_8 <= '1';

  
  tmp_69 <= s_s_7 WHEN s_s_6 = '0' ELSE
      s_s_8;

  obj_tracebackUnit_trelDec_trellisStart_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_trelDec_trellisStart <= tmp_69;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_trelDec_trellisStart_reg_process;


  s_s_9 <= obj_tracebackUnit_trelDec_tracingBack AND hdlcoder_to_stdlogic(tracebackCountOut = to_unsigned(16#028#, 9));

  s_s_10 <= '0';

  s_s_11 <= '1';

  
  tmp_70 <= s_s_10 WHEN s_s_9 = '0' ELSE
      s_s_11;

  obj_tracebackUnit_msgBuf_lastWrite_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgBuf_lastWrite <= tmp_70;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgBuf_lastWrite_reg_process;


  msgBufNext_state <= to_unsigned(16#1#, 2);

  msgBufNext_state_1 <= to_unsigned(16#2#, 2);

  
  tmp_71 <= msgBufNext_state WHEN obj_tracebackUnit_msgBuf_lastWrite = '0' ELSE
      msgBufNext_state_1;

  msgBufNext_state_2 <= to_unsigned(16#2#, 2);

  msgBufNext_state_3 <= to_unsigned(16#0#, 2);

  msgBufNext_state_4 <= to_unsigned(16#0#, 2);

  msgBufNext_state_5 <= to_unsigned(16#1#, 2);

  msgBufNext_RAMRdAddr <= to_unsigned(16#00#, 8);

  msgBufNext_RAMRdAddr_1 <= to_unsigned(16#00#, 8);

  
  tmp_72 <= msgBufNext_RAMRdAddr WHEN obj_tracebackUnit_msgBuf_lastWrite = '0' ELSE
      msgBufNext_RAMRdAddr_1;

  msgBufNext_RAMRdAddr_2 <= to_unsigned(16#00#, 8);

  msgBufNext_RAMRdAddr_3 <= to_unsigned(16#00#, 8);

  tmp_73 <= obj_tracebackUnit_msgBuf_RAMRdAddr + to_unsigned(16#01#, 8);

  tmp_74 <= obj_tracebackUnit_msgBuf_RAMRdAddr + to_unsigned(16#01#, 8);

  
  tmp_75 <= tmp_74 WHEN a0 = '0' ELSE
      tmp_73;

  
  a0 <= '1' WHEN resize(obj_tracebackUnit_msgBuf_RAMRdAddr, 10) = (resize(obj_tracebackUnit_msgLoc_msgLengthMinus1, 10) - to_unsigned(16#001#, 10)) ELSE
      '0';

  
  tmp_76 <= msgBufNext_state_2 WHEN a0 = '0' ELSE
      msgBufNext_state_3;

  
  tmp_77 <= tmp_71 WHEN s_s_12 = to_signed(1, 32) ELSE
      tmp_76 WHEN s_s_12 = to_signed(2, 32) ELSE
      msgBufNext_state_4;

  
  tmp_78 <= tmp_77 WHEN obj_tracebackUnit_trelDec_trellisStart = '0' ELSE
      msgBufNext_state_5;

  obj_tracebackUnit_msgBuf_state_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgBuf_state <= tmp_78;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgBuf_state_reg_process;


  s_s_12 <= signed(resize(obj_tracebackUnit_msgBuf_state, 32));

  
  tmp_79 <= tmp_72 WHEN s_s_12 = to_signed(1, 32) ELSE
      tmp_75 WHEN s_s_12 = to_signed(2, 32) ELSE
      msgBufNext_RAMRdAddr_2;

  
  tmp_80 <= tmp_79 WHEN obj_tracebackUnit_trelDec_trellisStart = '0' ELSE
      msgBufNext_RAMRdAddr_3;

  obj_tracebackUnit_msgBuf_RAMRdAddr_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgBuf_RAMRdAddr <= tmp_80;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgBuf_RAMRdAddr_reg_process;


  tmp_81 <= a_a;

  obj_tracebackUnit_dataOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_dataOut <= tmp_81;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_dataOut_reg_process;


  msgBufNext_RAMCtrlOut <= (OTHERS => '0');

  msgBufNext_FSMCtrlOut <= (OTHERS => '0');

  tmp_82 <= '0';

  msgBufNext_FSMCtrlOut_1 <= (OTHERS => tmp_82);

  msgBufNext_FSMCtrlOut_2 <= (OTHERS => '0');

  msgBufNext_FSMCtrlOut_3 <= nc;

  
  tmp_83 <= msgBufNext_FSMCtrlOut_1 WHEN obj_tracebackUnit_msgBuf_lastWrite = '0' ELSE
      msgBufNext_FSMCtrlOut_3;

  msgBufNext_FSMCtrlOut_4 <= (OTHERS => '0');

  msgBufNext_FSMCtrlOut_5 <= nc_2;

  msgBufNext_FSMCtrlOut_6 <= (OTHERS => '0');

  msgBufNext_FSMCtrlOut_7 <= nc_4;

  
  tmp_84 <= msgBufNext_FSMCtrlOut_5 WHEN a0 = '0' ELSE
      msgBufNext_FSMCtrlOut_7;

  msgBufNext_FSMCtrlOut_8 <= (OTHERS => '0');

  tmp_85 <= '0';

  msgBufNext_FSMCtrlOut_9 <= (OTHERS => tmp_85);

  c_c_4_output : PROCESS (msgBufNext_FSMCtrlOut_9, s_s_12, tmp_83, tmp_84)
  BEGIN
    IF s_s_12 = to_signed(1, 32) THEN 
      tmp_86 <= tmp_83;
    ELSIF s_s_12 = to_signed(2, 32) THEN 
      tmp_86 <= tmp_84;
    ELSE 
      tmp_86 <= msgBufNext_FSMCtrlOut_9;
    END IF;
  END PROCESS c_c_4_output;


  msgBufNext_FSMCtrlOut_10 <= (OTHERS => '0');

  tmp_87 <= '0';

  msgBufNext_FSMCtrlOut_11 <= (OTHERS => tmp_87);

  
  tmp_88 <= tmp_86 WHEN obj_tracebackUnit_trelDec_trellisStart = '0' ELSE
      msgBufNext_FSMCtrlOut_11;

  obj_tracebackUnit_msgBuf_FSMCtrlOut_1 <= tmp_88;

  obj_tracebackUnit_msgBuf_FSMCtrlOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgBuf_FSMCtrlOut <= obj_tracebackUnit_msgBuf_FSMCtrlOut_1;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgBuf_FSMCtrlOut_reg_process;


  msgBufNext_RAMCtrlOut_1 <= obj_tracebackUnit_msgBuf_FSMCtrlOut;

  obj_tracebackUnit_msgBuf_RAMCtrlOut_1 <= msgBufNext_RAMCtrlOut_1;

  obj_tracebackUnit_msgBuf_RAMCtrlOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_msgBuf_RAMCtrlOut <= obj_tracebackUnit_msgBuf_RAMCtrlOut_1;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_msgBuf_RAMCtrlOut_reg_process;


  tmp_89 <= obj_tracebackUnit_msgBuf_RAMCtrlOut(0);

  obj_tracebackUnit_startOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_startOut <= tmp_89;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_startOut_reg_process;


  tmp_90 <= obj_tracebackUnit_msgBuf_RAMCtrlOut(1);

  obj_tracebackUnit_endOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_endOut <= tmp_90;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_endOut_reg_process;


  tmp_91 <= obj_tracebackUnit_msgBuf_RAMCtrlOut(2);

  obj_tracebackUnit_validOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_tracebackUnit_validOut <= tmp_91;
      END IF;
    END IF;
  END PROCESS obj_tracebackUnit_validOut_reg_process;


  varargout_1 <= obj_tracebackUnit_dataOut;

  varargout_2 <= obj_tracebackUnit_startOut;

  varargout_3 <= obj_tracebackUnit_endOut;

  varargout_4 <= obj_tracebackUnit_validOut;

END rtl;

