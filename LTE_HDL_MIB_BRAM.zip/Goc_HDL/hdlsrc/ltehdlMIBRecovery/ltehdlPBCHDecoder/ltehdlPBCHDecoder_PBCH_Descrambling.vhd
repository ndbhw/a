-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlPBCHDecoder_PBCH_Descrambling IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        goldSeq                           :   IN    std_logic;
        valid_seq                         :   IN    std_logic;
        qpsksymbol_re                     :   IN    std_logic_vector(17 DOWNTO 0);  -- sfix18_En17
        qpsksymbol_im                     :   IN    std_logic_vector(17 DOWNTO 0);  -- sfix18_En17
        deScrambled                       :   OUT   std_logic_vector(17 DOWNTO 0);  -- sfix18_En17
        valid                             :   OUT   std_logic
        );
END ltehdlPBCHDecoder_PBCH_Descrambling;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_PBCH_Descrambling IS

  -- Signals
  SIGNAL Upsample2_muxsel                 : std_logic := '1';  -- ufix1
  SIGNAL qpsksymbol_re_signed             : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL qpsksymbol_im_signed             : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Unary_Minus_cast                 : signed(18 DOWNTO 0);  -- sfix19_En17
  SIGNAL Unary_Minus_cast_1               : signed(18 DOWNTO 0);  -- sfix19_En17
  SIGNAL Unary_Minus_out1_re              : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Unary_Minus_out1_im              : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Upsample2_zero                   : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Upsample2_out1                   : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Upsample1_muxsel                 : std_logic := '0';  -- ufix1
  SIGNAL Upsample1_zero                   : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Upsample3_muxsel                 : std_logic := '1';  -- ufix1
  SIGNAL Upsample3_zero                   : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Upsample3_out1                   : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Upsample4_muxsel                 : std_logic := '0';  -- ufix1
  SIGNAL Upsample4_zero                   : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL switch_compare_1                 : std_logic;
  SIGNAL Upsample1_out1                   : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Sum1_out1                        : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Upsample4_out1                   : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Sum2_out1                        : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Switch_out1                      : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Delay_out1                       : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En17
  SIGNAL Delay1_out1                      : std_logic := '0';

BEGIN
  -- Free running, Unsigned Counter
  --  initial value   = 1
  --  step value      = 1
  Upsample2_cnt_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Upsample2_muxsel <=  NOT Upsample2_muxsel;
      END IF;
    END IF;
  END PROCESS Upsample2_cnt_process;


  qpsksymbol_re_signed <= signed(qpsksymbol_re);

  qpsksymbol_im_signed <= signed(qpsksymbol_im);

  Unary_Minus_cast <=  - (resize(qpsksymbol_re_signed, 19));
  Unary_Minus_out1_re <= Unary_Minus_cast(17 DOWNTO 0);
  Unary_Minus_cast_1 <=  - (resize(qpsksymbol_im_signed, 19));
  Unary_Minus_out1_im <= Unary_Minus_cast_1(17 DOWNTO 0);

  Upsample2_zero <= to_signed(16#00000#, 18);

  -- Upsample2: Upsample by 2, Sample offset 0 
  
  Upsample2_out1 <= Unary_Minus_out1_re WHEN Upsample2_muxsel = '1' ELSE
      Upsample2_zero;

  -- Free running, Unsigned Counter
  --  initial value   = 0
  --  step value      = 1
  Upsample1_cnt_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Upsample1_muxsel <=  NOT Upsample1_muxsel;
      END IF;
    END IF;
  END PROCESS Upsample1_cnt_process;


  Upsample1_zero <= to_signed(16#00000#, 18);

  -- Free running, Unsigned Counter
  --  initial value   = 1
  --  step value      = 1
  Upsample3_cnt_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Upsample3_muxsel <=  NOT Upsample3_muxsel;
      END IF;
    END IF;
  END PROCESS Upsample3_cnt_process;


  Upsample3_zero <= to_signed(16#00000#, 18);

  -- Upsample3: Upsample by 2, Sample offset 0 
  
  Upsample3_out1 <= qpsksymbol_re_signed WHEN Upsample3_muxsel = '1' ELSE
      Upsample3_zero;

  -- Free running, Unsigned Counter
  --  initial value   = 0
  --  step value      = 1
  Upsample4_cnt_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Upsample4_muxsel <=  NOT Upsample4_muxsel;
      END IF;
    END IF;
  END PROCESS Upsample4_cnt_process;


  Upsample4_zero <= to_signed(16#00000#, 18);

  
  switch_compare_1 <= '1' WHEN goldSeq > '0' ELSE
      '0';

  -- Upsample1: Upsample by 2, Sample offset 1 
  
  Upsample1_out1 <= Unary_Minus_out1_im WHEN Upsample1_muxsel = '1' ELSE
      Upsample1_zero;

  Sum1_out1 <= Upsample2_out1 + Upsample1_out1;

  -- Upsample4: Upsample by 2, Sample offset 1 
  
  Upsample4_out1 <= qpsksymbol_im_signed WHEN Upsample4_muxsel = '1' ELSE
      Upsample4_zero;

  Sum2_out1 <= Upsample3_out1 + Upsample4_out1;

  
  Switch_out1 <= Sum1_out1 WHEN switch_compare_1 = '0' ELSE
      Sum2_out1;

  Delay_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay_out1 <= Switch_out1;
      END IF;
    END IF;
  END PROCESS Delay_rsvd_process;


  deScrambled <= std_logic_vector(Delay_out1);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1 <= valid_seq;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  valid <= Delay1_out1;

END rtl;

