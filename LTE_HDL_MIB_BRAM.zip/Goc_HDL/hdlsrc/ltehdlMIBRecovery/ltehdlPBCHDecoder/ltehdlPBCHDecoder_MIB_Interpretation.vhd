-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_MIB_Interpretation IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        restartMIB                        :   IN    std_logic;
        MIBDetect                         :   IN    std_logic;
        dataIn                            :   IN    std_logic_vector(23 DOWNTO 0);  -- ufix24
        nfmod4                            :   IN    std_logic_vector(1 DOWNTO 0);  -- ufix2
        clearReg                          :   IN    std_logic;
        NDLRB                             :   OUT   std_logic_vector(6 DOWNTO 0);  -- ufix7
        PHICHDuration                     :   OUT   std_logic;
        Ng                                :   OUT   std_logic_vector(1 DOWNTO 0);  -- ufix2
        NFrame                            :   OUT   std_logic_vector(9 DOWNTO 0);  -- ufix10
        MIBDetected                       :   OUT   std_logic;
        MIBError                          :   OUT   std_logic
        );
END ltehdlPBCHDecoder_MIB_Interpretation;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_MIB_Interpretation IS

  -- Constants
  CONSTANT nc                             : vector_of_unsigned7(0 TO 5) := 
    (to_unsigned(16#06#, 7), to_unsigned(16#0F#, 7), to_unsigned(16#19#, 7), to_unsigned(16#32#, 7), to_unsigned(16#4B#, 7), to_unsigned(16#64#, 7));  -- ufix7 [6]

  -- Signals
  SIGNAL dataIn_unsigned                  : unsigned(23 DOWNTO 0);  -- ufix24
  SIGNAL nfmod4_unsigned                  : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL NDLRB_tmp                        : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL Ng_tmp                           : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL NFrame_tmp                       : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL AllZeroMIB                       : std_logic;
  SIGNAL NDLRBReg                         : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL NgReg                            : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL PHICHReg                         : std_logic;
  SIGNAL NFrameReg                        : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL MIBDetectedReg                   : std_logic;
  SIGNAL AllZeroMIB_reg                   : std_logic;
  SIGNAL waitingForMIB                    : std_logic;
  SIGNAL MIBErrorReg                      : std_logic;
  SIGNAL NDLRBReg_next                    : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL NgReg_next                       : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL PHICHReg_next                    : std_logic;
  SIGNAL NFrameReg_next                   : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL MIBDetectedReg_next              : std_logic;
  SIGNAL AllZeroMIB_reg_next              : std_logic;
  SIGNAL waitingForMIB_next               : std_logic;
  SIGNAL MIBErrorReg_next                 : std_logic;

BEGIN
  dataIn_unsigned <= unsigned(dataIn);

  nfmod4_unsigned <= unsigned(nfmod4);

  MIB_Interpretation_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        NDLRBReg <= to_unsigned(16#00#, 7);
        NgReg <= to_unsigned(16#0#, 2);
        PHICHReg <= '0';
        NFrameReg <= to_unsigned(16#000#, 10);
        MIBDetectedReg <= '0';
        AllZeroMIB_reg <= '0';
        waitingForMIB <= '1';
        MIBErrorReg <= '0';
      ELSIF enb = '1' THEN
        NDLRBReg <= NDLRBReg_next;
        NgReg <= NgReg_next;
        PHICHReg <= PHICHReg_next;
        NFrameReg <= NFrameReg_next;
        MIBDetectedReg <= MIBDetectedReg_next;
        AllZeroMIB_reg <= AllZeroMIB_reg_next;
        waitingForMIB <= waitingForMIB_next;
        MIBErrorReg <= MIBErrorReg_next;
      END IF;
    END IF;
  END PROCESS MIB_Interpretation_process;

  MIB_Interpretation_output : PROCESS (AllZeroMIB_reg, MIBDetect, MIBDetectedReg, MIBErrorReg, NDLRBReg, NFrameReg,
       NgReg, PHICHReg, clearReg, dataIn_unsigned, nfmod4_unsigned, restartMIB,
       waitingForMIB)
    VARIABLE RBIndex : unsigned(6 DOWNTO 0);
    VARIABLE NFIndex : unsigned(15 DOWNTO 0);
    VARIABLE add_cast : unsigned(1 DOWNTO 0);
    VARIABLE add_cast_0 : unsigned(1 DOWNTO 0);
    VARIABLE add_temp : unsigned(3 DOWNTO 0);
    VARIABLE sub_cast : signed(31 DOWNTO 0);
    VARIABLE add_cast_1 : unsigned(1 DOWNTO 0);
    VARIABLE add_cast_2 : unsigned(1 DOWNTO 0);
    VARIABLE add_temp_0 : unsigned(3 DOWNTO 0);
    VARIABLE add_cast_3 : unsigned(1 DOWNTO 0);
    VARIABLE add_temp_1 : unsigned(5 DOWNTO 0);
    VARIABLE add_cast_4 : unsigned(1 DOWNTO 0);
    VARIABLE add_temp_2 : unsigned(7 DOWNTO 0);
    VARIABLE add_cast_5 : unsigned(1 DOWNTO 0);
    VARIABLE add_temp_3 : unsigned(9 DOWNTO 0);
    VARIABLE add_cast_6 : unsigned(1 DOWNTO 0);
    VARIABLE add_temp_4 : unsigned(11 DOWNTO 0);
    VARIABLE add_cast_7 : unsigned(1 DOWNTO 0);
    VARIABLE add_temp_5 : unsigned(13 DOWNTO 0);
    VARIABLE add_cast_8 : unsigned(1 DOWNTO 0);
    VARIABLE add_cast_9 : unsigned(1 DOWNTO 0);
    VARIABLE add_temp_6 : unsigned(3 DOWNTO 0);
    VARIABLE add_temp_7 : unsigned(18 DOWNTO 0);
  BEGIN
    RBIndex := to_unsigned(16#00#, 7);
    NFIndex := to_unsigned(16#0000#, 16);
    add_temp := to_unsigned(16#0#, 4);
    add_temp_0 := to_unsigned(16#0#, 4);
    add_temp_1 := to_unsigned(16#00#, 6);
    add_temp_2 := to_unsigned(16#00#, 8);
    add_temp_3 := to_unsigned(16#000#, 10);
    add_temp_4 := to_unsigned(16#000#, 12);
    add_temp_5 := to_unsigned(16#0000#, 14);
    add_temp_6 := to_unsigned(16#0#, 4);
    add_temp_7 := to_unsigned(16#00000#, 19);
    add_cast := to_unsigned(16#0#, 2);
    add_cast_0 := to_unsigned(16#0#, 2);
    sub_cast := to_signed(16#00000000#, 32);
    add_cast_1 := to_unsigned(16#0#, 2);
    add_cast_2 := to_unsigned(16#0#, 2);
    add_cast_3 := to_unsigned(16#0#, 2);
    add_cast_4 := to_unsigned(16#0#, 2);
    add_cast_5 := to_unsigned(16#0#, 2);
    add_cast_6 := to_unsigned(16#0#, 2);
    add_cast_7 := to_unsigned(16#0#, 2);
    add_cast_8 := to_unsigned(16#0#, 2);
    add_cast_9 := to_unsigned(16#0#, 2);
    NDLRBReg_next <= NDLRBReg;
    NgReg_next <= NgReg;
    PHICHReg_next <= PHICHReg;
    NFrameReg_next <= NFrameReg;
    MIBDetectedReg_next <= MIBDetectedReg;
    AllZeroMIB_reg_next <= AllZeroMIB_reg;
    waitingForMIB_next <= waitingForMIB;
    MIBErrorReg_next <= MIBErrorReg;
    IF (restartMIB AND ( NOT MIBDetect)) = '1' THEN 
      MIBErrorReg_next <= '1';
    ELSIF clearReg = '1' THEN 
      MIBErrorReg_next <= '0';
    END IF;
    IF waitingForMIB = '1' THEN 
      IF MIBDetect = '1' THEN 
        waitingForMIB_next <= '0';
        IF dataIn_unsigned = to_unsigned(16#000000#, 24) THEN 
          AllZeroMIB_reg_next <= '1';
        END IF;
        add_cast := '0' & dataIn_unsigned(0);
        add_cast_0 := '0' & dataIn_unsigned(1);
        add_temp := (resize(add_cast & '0', 4)) + (resize(add_cast_0, 4));
        RBIndex := resize((resize(add_temp & '0', 6)) + ('0' & '0' & '0' & '0' & '0' & dataIn_unsigned(2)), 7) + to_unsigned(16#01#, 7);
        IF RBIndex < to_unsigned(16#07#, 7) THEN 
          sub_cast := signed(resize(RBIndex, 32));
          NDLRBReg_next <= nc(to_integer(sub_cast - 1));
        END IF;
        add_cast_1 := '0' & dataIn_unsigned(6);
        add_cast_2 := '0' & dataIn_unsigned(7);
        add_temp_0 := (resize(add_cast_1 & '0', 4)) + (resize(add_cast_2, 4));
        add_cast_3 := '0' & dataIn_unsigned(8);
        add_temp_1 := (resize(add_temp_0 & '0', 6)) + (resize(add_cast_3, 6));
        add_cast_4 := '0' & dataIn_unsigned(9);
        add_temp_2 := (resize(add_temp_1 & '0', 8)) + (resize(add_cast_4, 8));
        add_cast_5 := '0' & dataIn_unsigned(10);
        add_temp_3 := (resize(add_temp_2 & '0', 10)) + (resize(add_cast_5, 10));
        add_cast_6 := '0' & dataIn_unsigned(11);
        add_temp_4 := (resize(add_temp_3 & '0', 12)) + (resize(add_cast_6, 12));
        add_cast_7 := '0' & dataIn_unsigned(12);
        add_temp_5 := (resize(add_temp_4 & '0', 14)) + (resize(add_cast_7, 14));
        add_cast_8 := '0' & dataIn_unsigned(13);
        NFIndex := (resize(add_temp_5 & '0', 16)) + (resize(add_cast_8, 16));
        PHICHReg_next <= dataIn_unsigned(3);
        add_cast_9 := '0' & dataIn_unsigned(4);
        add_temp_6 := (resize(add_cast_9 & '0', 4)) + ('0' & '0' & '0' & dataIn_unsigned(5));
        IF add_temp_6(3 DOWNTO 2) /= "00" THEN 
          NgReg_next <= "11";
        ELSE 
          NgReg_next <= add_temp_6(1 DOWNTO 0);
        END IF;
        add_temp_7 := (resize(NFIndex & '0' & '0', 19)) + resize(nfmod4_unsigned, 19);
        IF add_temp_7(18 DOWNTO 10) /= "000000000" THEN 
          NFrameReg_next <= "1111111111";
        ELSE 
          NFrameReg_next <= add_temp_7(9 DOWNTO 0);
        END IF;
        MIBDetectedReg_next <= '1';
      END IF;
    ELSIF clearReg = '1' THEN 
      NDLRBReg_next <= to_unsigned(16#00#, 7);
      NgReg_next <= to_unsigned(16#0#, 2);
      PHICHReg_next <= '0';
      NFrameReg_next <= to_unsigned(16#000#, 10);
      MIBDetectedReg_next <= '0';
      AllZeroMIB_reg_next <= '0';
      waitingForMIB_next <= '1';
      MIBErrorReg_next <= '0';
    END IF;
    NDLRB_tmp <= NDLRBReg;
    PHICHDuration <= PHICHReg;
    Ng_tmp <= NgReg;
    NFrame_tmp <= NFrameReg;
    MIBDetected <= MIBDetectedReg;
    AllZeroMIB <= AllZeroMIB_reg;
    MIBError <= MIBErrorReg;
  END PROCESS MIB_Interpretation_output;


  NDLRB <= std_logic_vector(NDLRB_tmp);

  Ng <= std_logic_vector(Ng_tmp);

  NFrame <= std_logic_vector(NFrame_tmp);

END rtl;

