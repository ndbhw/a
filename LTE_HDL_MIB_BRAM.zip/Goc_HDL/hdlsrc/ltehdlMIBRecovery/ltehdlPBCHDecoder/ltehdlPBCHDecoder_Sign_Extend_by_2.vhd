-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_Sign_Extend_by_2 IS
  PORT( x_0                               :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
        x_1                               :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
        x_2                               :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
        y_0                               :   OUT   std_logic_vector(21 DOWNTO 0);  -- sfix22_En17
        y_1                               :   OUT   std_logic_vector(21 DOWNTO 0);  -- sfix22_En17
        y_2                               :   OUT   std_logic_vector(21 DOWNTO 0)  -- sfix22_En17
        );
END ltehdlPBCHDecoder_Sign_Extend_by_2;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_Sign_Extend_by_2 IS

  -- Signals
  SIGNAL x_x                              : vector_of_signed20(0 TO 2);  -- sfix20_En17 [3]
  SIGNAL y_y                              : vector_of_signed22(0 TO 2);  -- sfix22_En17 [3]

BEGIN
  x_x(0) <= signed(x_0);
  x_x(1) <= signed(x_1);
  x_x(2) <= signed(x_2);


  y_y_gen: FOR t_0 IN 0 TO 2 GENERATE
    y_y(t_0) <= resize(x_x(t_0), 22);
  END GENERATE y_y_gen;


  y_0 <= std_logic_vector(y_y(0));

  y_1 <= std_logic_vector(y_y(1));

  y_2 <= std_logic_vector(y_y(2));

END rtl;

