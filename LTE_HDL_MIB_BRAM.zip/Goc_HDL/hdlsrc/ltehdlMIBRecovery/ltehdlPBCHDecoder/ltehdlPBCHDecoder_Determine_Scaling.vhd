-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_Determine_Scaling IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        maxIn                             :   IN    std_logic_vector(18 DOWNTO 0);  -- ufix19
        maxValid                          :   IN    std_logic;
        shiftAmount                       :   OUT   std_logic_vector(4 DOWNTO 0);  -- ufix5
        fineGain                          :   OUT   std_logic_vector(7 DOWNTO 0);  -- ufix8_En7
        scalingValid                      :   OUT   std_logic
        );
END ltehdlPBCHDecoder_Determine_Scaling;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_Determine_Scaling IS

  -- Constants
  CONSTANT recipLUT                       : vector_of_unsigned8(0 TO 15) := 
    (to_unsigned(16#F8#, 8), to_unsigned(16#E9#, 8), to_unsigned(16#DC#, 8), to_unsigned(16#D1#, 8), to_unsigned(16#C6#, 8), to_unsigned(16#BD#, 8), to_unsigned(16#B4#, 8), to_unsigned(16#AD#, 8), to_unsigned(16#A5#, 8), to_unsigned(16#9F#, 8), 
      to_unsigned(16#99#, 8), to_unsigned(16#93#, 8), to_unsigned(16#8E#, 8), to_unsigned(16#89#, 8), to_unsigned(16#84#, 8), to_unsigned(16#80#, 8)); -- ufix8 [16]

  -- Signals
  SIGNAL maxIn_unsigned                   : unsigned(18 DOWNTO 0);  -- ufix19_En17
  SIGNAL shiftAmount_tmp                  : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL fineGain_tmp                     : unsigned(7 DOWNTO 0);  -- ufix8_En7
  SIGNAL regs_shiftAmount                 : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL regs_fineGain                    : unsigned(7 DOWNTO 0);  -- ufix8_En7
  SIGNAL regs_validOut                    : std_logic;
  SIGNAL regs_shiftAmount_next            : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL regs_fineGain_next               : unsigned(7 DOWNTO 0);  -- ufix8_En7
  SIGNAL regs_validOut_next               : std_logic;

BEGIN
  maxIn_unsigned <= unsigned(maxIn);

  Determine_Scaling_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        regs_shiftAmount <= to_unsigned(16#00#, 5);
        regs_fineGain <= to_unsigned(16#00#, 8);
        regs_validOut <= '0';
      ELSIF enb = '1' THEN
        regs_shiftAmount <= regs_shiftAmount_next;
        regs_fineGain <= regs_fineGain_next;
        regs_validOut <= regs_validOut_next;
      END IF;
    END IF;
  END PROCESS Determine_Scaling_process;

  Determine_Scaling_output : PROCESS (maxIn_unsigned, maxValid, regs_fineGain, regs_shiftAmount, regs_validOut)
    VARIABLE kmssb : unsigned(4 DOWNTO 0);
    VARIABLE recipLUTIndex : unsigned(3 DOWNTO 0);
    VARIABLE next_shiftAmount : unsigned(4 DOWNTO 0);
    VARIABLE bit_idx : unsigned(15 DOWNTO 0);
    VARIABLE cc : unsigned(18 DOWNTO 0);
    VARIABLE add_temp : signed(31 DOWNTO 0);
    VARIABLE cast : unsigned(7 DOWNTO 0);
  BEGIN
    cc := to_unsigned(16#00000#, 19);
    recipLUTIndex := to_unsigned(16#0#, 4);
    kmssb := to_unsigned(16#00#, 5);
    add_temp := to_signed(16#00000000#, 32);
    bit_idx := to_unsigned(16#0000#, 16);
    cast := to_unsigned(16#00#, 8);
    -- Approximates the gain which would need to be applied to maxIn
    -- so that it results in the maximum possible value representable by its
    -- data type. If M is the largest possible value representable by the data
    -- type of maxIn, then the gain, G, is approximately G = M/maxIn.
    -- G is expressed as a left shiftAmount and a fineGain term.
    --------------------------------------------------------------------------
    -- Constants
    --------------------------------------------------------------------------
    -- Compute fine adjustment
    -- Number of bits from max av to use to determine fine adjustment
    -- Create fine gain LUT
    --------------------------------------------------------------------------
    -- Registers
    --------------------------------------------------------------------------
    -- Signals (non-registers)
    --------------------------------------------------------------------------
    -- Assign outputs
    --------------------------------------------------------------------------
    --------------------------------------------------------------------------
    -- Update registers
    --------------------------------------------------------------------------
    -- Initialize next register values
    next_shiftAmount := regs_shiftAmount;
    regs_fineGain_next <= regs_fineGain;
    IF maxValid = '1' THEN 
      kmssb := to_unsigned(16#01#, 5);
      -- Find the most significant set bit (kmssb)

      FOR kk IN 0 TO 18 LOOP
        bit_idx := unsigned(to_signed(kk, 32)(15 DOWNTO 0));
        IF maxIn_unsigned(to_integer(bit_idx)) = '1' THEN 
          add_temp := to_signed(kk + 1, 32);
          kmssb := unsigned(add_temp(4 DOWNTO 0));
        END IF;
      END LOOP;

      -- Compute the shift required to make the coarse adjustment
      next_shiftAmount := to_unsigned(16#13#, 5) - kmssb;
      -- Use N bits to the right of kmssb to index the fine gain LUT
      cast := resize(next_shiftAmount, 8);
      cc := maxIn_unsigned sll to_integer(cast);
      recipLUTIndex := cc(17 DOWNTO 14);
      regs_fineGain_next <= recipLUT(to_integer(recipLUTIndex));
    END IF;
    -- Update registers
    regs_shiftAmount_next <= next_shiftAmount;
    regs_validOut_next <= maxValid;
    shiftAmount_tmp <= regs_shiftAmount;
    fineGain_tmp <= regs_fineGain;
    scalingValid <= regs_validOut;
  END PROCESS Determine_Scaling_output;


  shiftAmount <= std_logic_vector(shiftAmount_tmp);

  fineGain <= std_logic_vector(fineGain_tmp);

END rtl;

