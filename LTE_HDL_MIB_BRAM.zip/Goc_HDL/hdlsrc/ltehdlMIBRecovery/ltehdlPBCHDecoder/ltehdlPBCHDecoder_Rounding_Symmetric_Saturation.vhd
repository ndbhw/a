-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_Rounding_Symmetric_Saturation IS
  PORT( dataScaled_0                      :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30
        dataScaled_1                      :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30
        dataScaled_2                      :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30
        validIn                           :   IN    std_logic;
        dataInDT_0                        :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
        dataInDT_1                        :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
        dataInDT_2                        :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
        dataOut_0                         :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
        dataOut_1                         :   OUT   std_logic_vector(3 DOWNTO 0);  -- sfix4_En1
        dataOut_2                         :   OUT   std_logic_vector(3 DOWNTO 0)  -- sfix4_En1
        );
END ltehdlPBCHDecoder_Rounding_Symmetric_Saturation;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_Rounding_Symmetric_Saturation IS

  -- Signals
  SIGNAL dataScaled                       : vector_of_signed30(0 TO 2);  -- sfix30_En24 [3]
  SIGNAL dataInDT                         : vector_of_signed20(0 TO 2);  -- sfix20_En17 [3]
  SIGNAL dataOut_3                        : vector_of_signed4(0 TO 2);  -- sfix4_En1 [3]

BEGIN
  dataScaled(0) <= signed(dataScaled_0);
  dataScaled(1) <= signed(dataScaled_1);
  dataScaled(2) <= signed(dataScaled_2);

  dataInDT(0) <= signed(dataInDT_0);
  dataInDT(1) <= signed(dataInDT_1);
  dataInDT(2) <= signed(dataInDT_2);

  Rounding_Symmetric_Saturation_output : PROCESS (dataScaled, validIn)
    VARIABLE dataOut : vector_of_signed4(0 TO 2);
    VARIABLE dataout_01 : signed(3 DOWNTO 0);
  BEGIN
    dataout_01 := to_signed(16#0#, 4);
    ------------------------------------------------------------------------------
    -- Constants
    ------------------------------------------------------------------------------
    -- Number of output bits
    -- LSBs to delete relative to original input data
    -- Define data out data type
    -- Lowest possible input value
    -- Lower limit to saturate to
    ------------------------------------------------------------------------------
    -- Calculate output
    ------------------------------------------------------------------------------
    IF validIn = '1' THEN 
      -- Change any instances of the lowest possible input
      -- value to the lower saturation limit.

      FOR kk IN 0 TO 2 LOOP
        IF ((dataScaled(kk)(29) = '0') AND (dataScaled(kk)(28 DOWNTO 26) /= "000")) OR ((dataScaled(kk)(29) = '0') AND (dataScaled(kk)(26 DOWNTO 23) = "0111")) THEN 
          dataout_01 := "0111";
        ELSIF (dataScaled(kk)(29) = '1') AND (dataScaled(kk)(28 DOWNTO 26) /= "111") THEN 
          dataout_01 := "1000";
        ELSE 
          dataout_01 := dataScaled(kk)(26 DOWNTO 23) + ('0' & (dataScaled(kk)(22) AND (( NOT dataScaled(kk)(29)) OR (dataScaled(kk)(21) OR dataScaled(kk)(20) OR dataScaled(kk)(19) OR dataScaled(kk)(18) OR dataScaled(kk)(17) OR dataScaled(kk)(16) OR 
            dataScaled(kk)(15) OR dataScaled(kk)(14) OR dataScaled(kk)(13) OR dataScaled(kk)(12) OR dataScaled(kk)(11) OR dataScaled(kk)(10) OR dataScaled(kk)(9) OR dataScaled(kk)(8) OR dataScaled(kk)(7) OR dataScaled(kk)(6) OR dataScaled(kk)(5) OR 
            dataScaled(kk)(4) OR dataScaled(kk)(3) OR dataScaled(kk)(2) OR dataScaled(kk)(1) OR dataScaled(kk)(0)))));
        END IF;
        dataOut(kk) := dataout_01;
        IF dataout_01 = to_signed(-16#8#, 4) THEN 
          dataOut(kk) := to_signed(-16#7#, 4);
        END IF;
      END LOOP;

    ELSE 
      dataOut := (OTHERS => to_signed(16#0#, 4));
    END IF;
    dataOut_3 <= dataOut;
  END PROCESS Rounding_Symmetric_Saturation_output;


  dataOut_0 <= std_logic_vector(dataOut_3(0));

  dataOut_1 <= std_logic_vector(dataOut_3(1));

  dataOut_2 <= std_logic_vector(dataOut_3(2));

END rtl;

