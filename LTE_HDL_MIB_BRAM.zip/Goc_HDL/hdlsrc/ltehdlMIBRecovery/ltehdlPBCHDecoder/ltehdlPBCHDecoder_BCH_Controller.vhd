-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlPBCHDecoder;

ENTITY ltehdlPBCHDecoder_BCH_Controller IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        data                              :   IN    std_logic;
        ctrl_start                        :   IN    std_logic;
        ctrl_end                          :   IN    std_logic;
        ctrl_valid                        :   IN    std_logic;
        crcErr                            :   IN    std_logic_vector(15 DOWNTO 0);  -- uint16
        clearReg                          :   IN    std_logic;
        dataOut                           :   OUT   std_logic_vector(23 DOWNTO 0);  -- ufix24
        repeatQPSK                        :   OUT   std_logic;
        MIBDetected                       :   OUT   std_logic;
        restartMIB                        :   OUT   std_logic;
        nfmod4                            :   OUT   std_logic_vector(1 DOWNTO 0);  -- ufix2
        cellRefP                          :   OUT   std_logic_vector(2 DOWNTO 0)  -- ufix3
        );
END ltehdlPBCHDecoder_BCH_Controller;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_BCH_Controller IS

  -- Component Declarations
  COMPONENT ltehdlPBCHDecoder_MIB_Data_Buffer
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn                          :   IN    std_logic;
          ctrlIn_start                    :   IN    std_logic;
          ctrlIn_end                      :   IN    std_logic;
          ctrlIn_valid                    :   IN    std_logic;
          dataOut                         :   OUT   std_logic_vector(23 DOWNTO 0)  -- ufix24
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_BCHControllerCore
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          ctrlIn_start                    :   IN    std_logic;
          ctrlIn_end                      :   IN    std_logic;
          ctrlIn_valid                    :   IN    std_logic;
          crcmask                         :   IN    std_logic_vector(15 DOWNTO 0);  -- uint16
          clearReg                        :   IN    std_logic;
          repeat_QPSK                     :   OUT   std_logic;
          MIB_detected                    :   OUT   std_logic;
          restart_MIB                     :   OUT   std_logic;
          nfmod4                          :   OUT   std_logic_vector(1 DOWNTO 0);  -- ufix2
          cellrefp                        :   OUT   std_logic_vector(2 DOWNTO 0)  -- ufix3
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlPBCHDecoder_MIB_Data_Buffer
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_MIB_Data_Buffer(rtl);

  FOR ALL : ltehdlPBCHDecoder_BCHControllerCore
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_BCHControllerCore(rtl);

  -- Signals
  SIGNAL dataOut_tmp                      : std_logic_vector(23 DOWNTO 0);  -- ufix24
  SIGNAL repeat_QPSK                      : std_logic;
  SIGNAL MIB_detected                     : std_logic;
  SIGNAL restart_MIB                      : std_logic;
  SIGNAL nfmod4_1                         : std_logic_vector(1 DOWNTO 0);  -- ufix2
  SIGNAL cellrefp_1                       : std_logic_vector(2 DOWNTO 0);  -- ufix3
  SIGNAL Delay8_out1                      : std_logic := '0';
  SIGNAL Delay7_out1                      : std_logic := '0';
  SIGNAL Delay11_out1                     : std_logic := '0';
  SIGNAL nfmod4_unsigned                  : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL Delay14_out1                     : unsigned(1 DOWNTO 0) := to_unsigned(16#0#, 2);  -- ufix2
  SIGNAL Switch_out1                      : unsigned(1 DOWNTO 0);  -- ufix2

BEGIN
  UMIB_Data_Buffer : ltehdlPBCHDecoder_MIB_Data_Buffer
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              dataIn => data,
              ctrlIn_start => ctrl_start,
              ctrlIn_end => ctrl_end,
              ctrlIn_valid => ctrl_valid,
              dataOut => dataOut_tmp  -- ufix24
              );

  UBCHControllerCore : ltehdlPBCHDecoder_BCHControllerCore
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              ctrlIn_start => ctrl_start,
              ctrlIn_end => ctrl_end,
              ctrlIn_valid => ctrl_valid,
              crcmask => crcErr,  -- uint16
              clearReg => clearReg,
              repeat_QPSK => repeat_QPSK,
              MIB_detected => MIB_detected,
              restart_MIB => restart_MIB,
              nfmod4 => nfmod4_1,  -- ufix2
              cellrefp => cellrefp_1  -- ufix3
              );

  Delay8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay8_out1 <= repeat_QPSK;
      END IF;
    END IF;
  END PROCESS Delay8_process;


  Delay7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay7_out1 <= MIB_detected;
      END IF;
    END IF;
  END PROCESS Delay7_process;


  Delay11_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay11_out1 <= restart_MIB;
      END IF;
    END IF;
  END PROCESS Delay11_process;


  nfmod4_unsigned <= unsigned(nfmod4_1);

  
  Switch_out1 <= Delay14_out1 WHEN MIB_detected = '0' ELSE
      nfmod4_unsigned;

  Delay14_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay14_out1 <= Switch_out1;
      END IF;
    END IF;
  END PROCESS Delay14_process;


  nfmod4 <= std_logic_vector(Delay14_out1);

  dataOut <= dataOut_tmp;

  repeatQPSK <= Delay8_out1;

  MIBDetected <= Delay7_out1;

  restartMIB <= Delay11_out1;

  cellRefP <= cellrefp_1;

END rtl;

