-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_ConvolutionalDecoderMetricComputer IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        varargin_1_0                      :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        varargin_1_1                      :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        varargin_1_2                      :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        varargin_2                        :   IN    std_logic;
        varargin_3                        :   IN    std_logic;
        varargin_4                        :   IN    std_logic;
        varargout_1_0                     :   OUT   std_logic;
        varargout_1_1                     :   OUT   std_logic;
        varargout_1_2                     :   OUT   std_logic;
        varargout_1_3                     :   OUT   std_logic;
        varargout_1_4                     :   OUT   std_logic;
        varargout_1_5                     :   OUT   std_logic;
        varargout_1_6                     :   OUT   std_logic;
        varargout_1_7                     :   OUT   std_logic;
        varargout_1_8                     :   OUT   std_logic;
        varargout_1_9                     :   OUT   std_logic;
        varargout_1_10                    :   OUT   std_logic;
        varargout_1_11                    :   OUT   std_logic;
        varargout_1_12                    :   OUT   std_logic;
        varargout_1_13                    :   OUT   std_logic;
        varargout_1_14                    :   OUT   std_logic;
        varargout_1_15                    :   OUT   std_logic;
        varargout_1_16                    :   OUT   std_logic;
        varargout_1_17                    :   OUT   std_logic;
        varargout_1_18                    :   OUT   std_logic;
        varargout_1_19                    :   OUT   std_logic;
        varargout_1_20                    :   OUT   std_logic;
        varargout_1_21                    :   OUT   std_logic;
        varargout_1_22                    :   OUT   std_logic;
        varargout_1_23                    :   OUT   std_logic;
        varargout_1_24                    :   OUT   std_logic;
        varargout_1_25                    :   OUT   std_logic;
        varargout_1_26                    :   OUT   std_logic;
        varargout_1_27                    :   OUT   std_logic;
        varargout_1_28                    :   OUT   std_logic;
        varargout_1_29                    :   OUT   std_logic;
        varargout_1_30                    :   OUT   std_logic;
        varargout_1_31                    :   OUT   std_logic;
        varargout_1_32                    :   OUT   std_logic;
        varargout_1_33                    :   OUT   std_logic;
        varargout_1_34                    :   OUT   std_logic;
        varargout_1_35                    :   OUT   std_logic;
        varargout_1_36                    :   OUT   std_logic;
        varargout_1_37                    :   OUT   std_logic;
        varargout_1_38                    :   OUT   std_logic;
        varargout_1_39                    :   OUT   std_logic;
        varargout_1_40                    :   OUT   std_logic;
        varargout_1_41                    :   OUT   std_logic;
        varargout_1_42                    :   OUT   std_logic;
        varargout_1_43                    :   OUT   std_logic;
        varargout_1_44                    :   OUT   std_logic;
        varargout_1_45                    :   OUT   std_logic;
        varargout_1_46                    :   OUT   std_logic;
        varargout_1_47                    :   OUT   std_logic;
        varargout_1_48                    :   OUT   std_logic;
        varargout_1_49                    :   OUT   std_logic;
        varargout_1_50                    :   OUT   std_logic;
        varargout_1_51                    :   OUT   std_logic;
        varargout_1_52                    :   OUT   std_logic;
        varargout_1_53                    :   OUT   std_logic;
        varargout_1_54                    :   OUT   std_logic;
        varargout_1_55                    :   OUT   std_logic;
        varargout_1_56                    :   OUT   std_logic;
        varargout_1_57                    :   OUT   std_logic;
        varargout_1_58                    :   OUT   std_logic;
        varargout_1_59                    :   OUT   std_logic;
        varargout_1_60                    :   OUT   std_logic;
        varargout_1_61                    :   OUT   std_logic;
        varargout_1_62                    :   OUT   std_logic;
        varargout_1_63                    :   OUT   std_logic;
        varargout_2                       :   OUT   std_logic;
        varargout_3                       :   OUT   std_logic;
        varargout_4                       :   OUT   std_logic;
        varargout_5                       :   OUT   std_logic_vector(5 DOWNTO 0);  -- ufix6
        varargout_6                       :   OUT   std_logic
        );
END ltehdlPBCHDecoder_ConvolutionalDecoderMetricComputer;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_ConvolutionalDecoderMetricComputer IS

  -- Constants
  CONSTANT nc                             : std_logic_vector(23 DOWNTO 0) := 
    ('1', '0', '1', '0', '1', '0', '1', '0', '1', '1', '0', '0', '1', '1', '0', '0', '1', '1', '1', '1', '0', '0', '0', '0');  -- boolean [24]
  CONSTANT nc_2                           : vector_of_signed8(0 TO 63) := 
    (to_signed(16#00#, 8), to_signed(16#02#, 8), to_signed(16#04#, 8), to_signed(16#06#, 8), to_signed(16#08#, 8), to_signed(16#0A#, 8), to_signed(16#0C#, 8), to_signed(16#0E#, 8), to_signed(16#10#, 8), to_signed(16#12#, 8), to_signed(16#14#, 8), 
      to_signed(16#16#, 8), to_signed(16#18#, 8), to_signed(16#1A#, 8), to_signed(16#1C#, 8), to_signed(16#1E#, 8), to_signed(16#20#, 8), to_signed(16#22#, 8), to_signed(16#24#, 8), to_signed(16#26#, 8), to_signed(16#28#, 8), to_signed(16#2A#, 8), 
      to_signed(16#2C#, 8), to_signed(16#2E#, 8), to_signed(16#30#, 8), to_signed(16#32#, 8), to_signed(16#34#, 8), to_signed(16#36#, 8), to_signed(16#38#, 8), to_signed(16#3A#, 8), to_signed(16#3C#, 8), to_signed(16#3E#, 8), to_signed(16#00#, 8), 
      to_signed(16#02#, 8), to_signed(16#04#, 8), to_signed(16#06#, 8), to_signed(16#08#, 8), to_signed(16#0A#, 8), to_signed(16#0C#, 8), to_signed(16#0E#, 8), to_signed(16#10#, 8), to_signed(16#12#, 8), to_signed(16#14#, 8), to_signed(16#16#, 8), 
      to_signed(16#18#, 8), to_signed(16#1A#, 8), to_signed(16#1C#, 8), to_signed(16#1E#, 8), to_signed(16#20#, 8), to_signed(16#22#, 8), to_signed(16#24#, 8), to_signed(16#26#, 8), to_signed(16#28#, 8), to_signed(16#2A#, 8), to_signed(16#2C#, 8), 
      to_signed(16#2E#, 8), to_signed(16#30#, 8), to_signed(16#32#, 8), to_signed(16#34#, 8), to_signed(16#36#, 8), to_signed(16#38#, 8), to_signed(16#3A#, 8), to_signed(16#3C#, 8), to_signed(16#3E#, 8)); -- int8 [64]
  CONSTANT nc_0                           : vector_of_signed8(0 TO 63) := 
    (to_signed(16#00#, 8), to_signed(16#04#, 8), to_signed(16#01#, 8), to_signed(16#05#, 8), to_signed(16#06#, 8), to_signed(16#02#, 8), to_signed(16#07#, 8), to_signed(16#03#, 8), to_signed(16#07#, 8), to_signed(16#03#, 8), to_signed(16#06#, 8), 
      to_signed(16#02#, 8), to_signed(16#01#, 8), to_signed(16#05#, 8), to_signed(16#00#, 8), to_signed(16#04#, 8), to_signed(16#03#, 8), to_signed(16#07#, 8), to_signed(16#02#, 8), to_signed(16#06#, 8), to_signed(16#05#, 8), to_signed(16#01#, 8), 
      to_signed(16#04#, 8), to_signed(16#00#, 8), to_signed(16#04#, 8), to_signed(16#00#, 8), to_signed(16#05#, 8), to_signed(16#01#, 8), to_signed(16#02#, 8), to_signed(16#06#, 8), to_signed(16#03#, 8), to_signed(16#07#, 8), to_signed(16#07#, 8), 
      to_signed(16#03#, 8), to_signed(16#06#, 8), to_signed(16#02#, 8), to_signed(16#01#, 8), to_signed(16#05#, 8), to_signed(16#00#, 8), to_signed(16#04#, 8), to_signed(16#00#, 8), to_signed(16#04#, 8), to_signed(16#01#, 8), to_signed(16#05#, 8), 
      to_signed(16#06#, 8), to_signed(16#02#, 8), to_signed(16#07#, 8), to_signed(16#03#, 8), to_signed(16#04#, 8), to_signed(16#00#, 8), to_signed(16#05#, 8), to_signed(16#01#, 8), to_signed(16#02#, 8), to_signed(16#06#, 8), to_signed(16#03#, 8), 
      to_signed(16#07#, 8), to_signed(16#03#, 8), to_signed(16#07#, 8), to_signed(16#02#, 8), to_signed(16#06#, 8), to_signed(16#05#, 8), to_signed(16#01#, 8), to_signed(16#04#, 8), to_signed(16#00#, 8)); -- int8 [64]
  CONSTANT nc_1_1                         : vector_of_signed8(0 TO 63) := 
    (to_signed(16#01#, 8), to_signed(16#03#, 8), to_signed(16#05#, 8), to_signed(16#07#, 8), to_signed(16#09#, 8), to_signed(16#0B#, 8), to_signed(16#0D#, 8), to_signed(16#0F#, 8), to_signed(16#11#, 8), to_signed(16#13#, 8), to_signed(16#15#, 8), 
      to_signed(16#17#, 8), to_signed(16#19#, 8), to_signed(16#1B#, 8), to_signed(16#1D#, 8), to_signed(16#1F#, 8), to_signed(16#21#, 8), to_signed(16#23#, 8), to_signed(16#25#, 8), to_signed(16#27#, 8), to_signed(16#29#, 8), to_signed(16#2B#, 8), 
      to_signed(16#2D#, 8), to_signed(16#2F#, 8), to_signed(16#31#, 8), to_signed(16#33#, 8), to_signed(16#35#, 8), to_signed(16#37#, 8), to_signed(16#39#, 8), to_signed(16#3B#, 8), to_signed(16#3D#, 8), to_signed(16#3F#, 8), to_signed(16#01#, 8), 
      to_signed(16#03#, 8), to_signed(16#05#, 8), to_signed(16#07#, 8), to_signed(16#09#, 8), to_signed(16#0B#, 8), to_signed(16#0D#, 8), to_signed(16#0F#, 8), to_signed(16#11#, 8), to_signed(16#13#, 8), to_signed(16#15#, 8), to_signed(16#17#, 8), 
      to_signed(16#19#, 8), to_signed(16#1B#, 8), to_signed(16#1D#, 8), to_signed(16#1F#, 8), to_signed(16#21#, 8), to_signed(16#23#, 8), to_signed(16#25#, 8), to_signed(16#27#, 8), to_signed(16#29#, 8), to_signed(16#2B#, 8), to_signed(16#2D#, 8), 
      to_signed(16#2F#, 8), to_signed(16#31#, 8), to_signed(16#33#, 8), to_signed(16#35#, 8), to_signed(16#37#, 8), to_signed(16#39#, 8), to_signed(16#3B#, 8), to_signed(16#3D#, 8), to_signed(16#3F#, 8)); -- int8 [64]
  CONSTANT nc_2_1                         : vector_of_signed8(0 TO 63) := 
    (to_signed(16#07#, 8), to_signed(16#03#, 8), to_signed(16#06#, 8), to_signed(16#02#, 8), to_signed(16#01#, 8), to_signed(16#05#, 8), to_signed(16#00#, 8), to_signed(16#04#, 8), to_signed(16#00#, 8), to_signed(16#04#, 8), to_signed(16#01#, 8), 
      to_signed(16#05#, 8), to_signed(16#06#, 8), to_signed(16#02#, 8), to_signed(16#07#, 8), to_signed(16#03#, 8), to_signed(16#04#, 8), to_signed(16#00#, 8), to_signed(16#05#, 8), to_signed(16#01#, 8), to_signed(16#02#, 8), to_signed(16#06#, 8), 
      to_signed(16#03#, 8), to_signed(16#07#, 8), to_signed(16#03#, 8), to_signed(16#07#, 8), to_signed(16#02#, 8), to_signed(16#06#, 8), to_signed(16#05#, 8), to_signed(16#01#, 8), to_signed(16#04#, 8), to_signed(16#00#, 8), to_signed(16#00#, 8), 
      to_signed(16#04#, 8), to_signed(16#01#, 8), to_signed(16#05#, 8), to_signed(16#06#, 8), to_signed(16#02#, 8), to_signed(16#07#, 8), to_signed(16#03#, 8), to_signed(16#07#, 8), to_signed(16#03#, 8), to_signed(16#06#, 8), to_signed(16#02#, 8), 
      to_signed(16#01#, 8), to_signed(16#05#, 8), to_signed(16#00#, 8), to_signed(16#04#, 8), to_signed(16#03#, 8), to_signed(16#07#, 8), to_signed(16#02#, 8), to_signed(16#06#, 8), to_signed(16#05#, 8), to_signed(16#01#, 8), to_signed(16#04#, 8), 
      to_signed(16#00#, 8), to_signed(16#04#, 8), to_signed(16#00#, 8), to_signed(16#05#, 8), to_signed(16#01#, 8), to_signed(16#02#, 8), to_signed(16#06#, 8), to_signed(16#03#, 8), to_signed(16#07#, 8)); -- int8 [64]

  -- Signals
  SIGNAL varargout_2_1                    : std_logic;
  SIGNAL varargout_3_1                    : std_logic;
  SIGNAL varargout_4_1                    : std_logic;
  SIGNAL s_s                              : std_logic;
  SIGNAL resetIn                          : std_logic;
  SIGNAL resetIn_1                        : std_logic;
  SIGNAL tmp                              : std_logic;
  SIGNAL tmp_1                            : signed(31 DOWNTO 0);  -- int32
  SIGNAL tmp_2                            : signed(31 DOWNTO 0);  -- int32
  SIGNAL tmp_3                            : signed(31 DOWNTO 0);  -- int32
  SIGNAL tmp_4                            : signed(31 DOWNTO 0);  -- int32
  SIGNAL obj_metricComputer_validInPipe   : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- boolean [2]
  SIGNAL tmp_5                            : std_logic;
  SIGNAL obj_metricComputer_validInPipe_1 : std_logic_vector(1 DOWNTO 0);  -- boolean [2]
  SIGNAL tmp_6                            : std_logic_vector(1 DOWNTO 0);  -- boolean [2]
  SIGNAL tmp_7                            : std_logic;
  SIGNAL tmp_8                            : signed(9 DOWNTO 0);  -- sfix10_En1
  SIGNAL branchMetrics                    : vector_of_signed6(0 TO 7);  -- sfix6_En1 [8]
  SIGNAL branchMetrics_1                  : vector_of_signed6(0 TO 7);  -- sfix6_En1 [8]
  SIGNAL tmp_9                            : signed(5 DOWNTO 0);  -- sfix6_En1
  SIGNAL branchMetrics_2                  : vector_of_signed6(0 TO 7);  -- sfix6_En1 [8]
  SIGNAL tmp_10                           : signed(5 DOWNTO 0);  -- sfix6_En1
  SIGNAL dataIn                           : vector_of_signed4(0 TO 2);  -- sfix4_En1 [3]
  SIGNAL varargout_1                      : vector_of_signed4(0 TO 2);  -- sfix4_En1 [3]
  SIGNAL obj_metricComputer_dataInReg     : vector_of_signed4(0 TO 2) := (OTHERS => to_signed(16#0#, 4));  -- sfix4_En1 [3]
  SIGNAL obj_metricComputer_dataInReg_1   : vector_of_signed4(0 TO 2);  -- sfix4_En1 [3]
  SIGNAL dataIn_1                         : vector_of_signed4(0 TO 2);  -- sfix4_En1 [3]
  SIGNAL branchMetrics_3                  : vector_of_signed6(0 TO 7);  -- sfix6_En1 [8]
  SIGNAL obj_metricComputer_branchMetrics : vector_of_signed6(0 TO 7) := (OTHERS => to_signed(16#00#, 6));  -- sfix6_En1 [8]
  SIGNAL obj_metricComputer_branchMetrics_1 : vector_of_signed6(0 TO 7);  -- sfix6_En1 [8]
  SIGNAL branchMetrics_4                  : vector_of_signed6(0 TO 7);  -- sfix6_En1 [8]
  SIGNAL oldStateMetrics                  : vector_of_signed10(0 TO 63);  -- sfix10_En1 [64]
  SIGNAL tmp_11                           : std_logic;
  SIGNAL tmp_12                           : std_logic;
  SIGNAL obj_metricComputer_stateMetrics  : vector_of_signed10(0 TO 63) := (OTHERS => to_signed(16#000#, 10));  -- sfix10_En1 [64]
  SIGNAL oldStateMetrics_1                : vector_of_signed10(0 TO 63);  -- sfix10_En1 [64]
  SIGNAL obj_metricComputer_stateMetrics_1 : vector_of_signed10(0 TO 63);  -- sfix10_En1 [64]
  SIGNAL obj_metricComputer_stateMetrics_2 : vector_of_signed10(0 TO 63);  -- sfix10_En1 [64]
  SIGNAL tmp_13                           : vector_of_signed10(0 TO 63);  -- sfix10_En1 [64]
  SIGNAL tmp_14                           : vector_of_signed10(0 TO 63);  -- sfix10_En1 [64]
  SIGNAL obj_metricComputer_decisions     : std_logic_vector(63 DOWNTO 0) := (OTHERS => '0');  -- boolean [64]
  SIGNAL obj_metricComputer_decisions_1   : std_logic_vector(63 DOWNTO 0);  -- boolean [64]
  SIGNAL tmp_15                           : std_logic_vector(63 DOWNTO 0);  -- boolean [64]
  SIGNAL tmp_16                           : std_logic_vector(63 DOWNTO 0);  -- boolean [64]
  SIGNAL varargout_1_64                   : std_logic_vector(63 DOWNTO 0);  -- boolean [64]
  SIGNAL varargout_1_65                   : std_logic_vector(63 DOWNTO 0);  -- boolean [64]
  SIGNAL tmp_17                           : signed(31 DOWNTO 0);  -- int32
  SIGNAL tmp_18                           : signed(31 DOWNTO 0);  -- int32
  SIGNAL tmp_19                           : signed(31 DOWNTO 0);  -- int32
  SIGNAL tmp_20                           : signed(31 DOWNTO 0);  -- int32
  SIGNAL obj_metricComputer_startInPipe   : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- boolean [2]
  SIGNAL tmp_21                           : std_logic;
  SIGNAL obj_metricComputer_startInPipe_1 : std_logic_vector(1 DOWNTO 0);  -- boolean [2]
  SIGNAL tmp_22                           : std_logic_vector(1 DOWNTO 0);  -- boolean [2]
  SIGNAL tmp_23                           : std_logic;
  SIGNAL obj_metricComputer_startOutPipe  : std_logic := '0';
  SIGNAL tmp_24                           : signed(31 DOWNTO 0);  -- int32
  SIGNAL tmp_25                           : signed(31 DOWNTO 0);  -- int32
  SIGNAL tmp_26                           : signed(31 DOWNTO 0);  -- int32
  SIGNAL tmp_27                           : signed(31 DOWNTO 0);  -- int32
  SIGNAL obj_metricComputer_endInPipe     : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- boolean [2]
  SIGNAL tmp_28                           : std_logic;
  SIGNAL obj_metricComputer_endInPipe_1   : std_logic_vector(1 DOWNTO 0);  -- boolean [2]
  SIGNAL tmp_29                           : std_logic_vector(1 DOWNTO 0);  -- boolean [2]
  SIGNAL tmp_30                           : std_logic;
  SIGNAL obj_metricComputer_endOutPipe    : std_logic := '0';
  SIGNAL obj_metricComputer_validOutPipe  : std_logic := '0';
  SIGNAL stateMetricsOut                  : vector_of_signed10(0 TO 63);  -- sfix10_En1 [64]
  SIGNAL stateMetricsOut_1                : vector_of_signed10(0 TO 63);  -- sfix10_En1 [64]
  SIGNAL obj_metricComputer_maxStates     : vector_of_unsigned6(0 TO 63) := (OTHERS => to_unsigned(16#00#, 6));  -- ufix6 [64]
  SIGNAL obj_metricComputer_maxStates_1   : vector_of_unsigned6(0 TO 63);  -- ufix6 [64]
  SIGNAL obj_metricComputer_maxMetrics    : vector_of_signed10(0 TO 63) := (OTHERS => to_signed(16#000#, 10));  -- sfix10_En1 [64]
  SIGNAL obj_metricComputer_maxMetrics_1  : vector_of_signed10(0 TO 63);  -- sfix10_En1 [64]
  SIGNAL obj_metricComputer_maxMetrics_2  : vector_of_signed10(0 TO 63);  -- sfix10_En1 [64]
  SIGNAL tmp_31                           : vector_of_signed10(0 TO 63);  -- sfix10_En1 [64]
  SIGNAL obj_metricComputer_maxStates_2   : vector_of_unsigned6(0 TO 63);  -- ufix6 [64]
  SIGNAL tmp_32                           : vector_of_unsigned6(0 TO 63);  -- ufix6 [64]
  SIGNAL varargout_5_tmp                  : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL tmp_33                           : signed(31 DOWNTO 0);  -- int32
  SIGNAL tmp_34                           : signed(31 DOWNTO 0);  -- int32
  SIGNAL tmp_35                           : signed(31 DOWNTO 0);  -- int32
  SIGNAL tmp_36                           : signed(31 DOWNTO 0);  -- int32
  SIGNAL obj_metricComputer_resetInPipe   : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- boolean [2]
  SIGNAL tmp_37                           : std_logic;
  SIGNAL obj_metricComputer_resetInPipe_1 : std_logic_vector(1 DOWNTO 0);  -- boolean [2]
  SIGNAL tmp_38                           : std_logic_vector(1 DOWNTO 0);  -- boolean [2]
  SIGNAL resetIn_2                        : std_logic;
  SIGNAL endOut                           : std_logic_vector(6 DOWNTO 0);  -- boolean [7]
  SIGNAL s_s_1                            : std_logic;
  SIGNAL sel                              : std_logic;
  SIGNAL sel_2                            : std_logic;
  SIGNAL endOut_1                         : std_logic_vector(6 DOWNTO 0);  -- boolean [7]
  SIGNAL tmp_39                           : std_logic;
  SIGNAL obj_metricComputer_maxValidPipe  : std_logic_vector(6 DOWNTO 0) := (OTHERS => '0');  -- boolean [7]
  SIGNAL obj_metricComputer_maxValidPipe_1 : std_logic_vector(6 DOWNTO 0);  -- boolean [7]
  SIGNAL endOut_2                         : std_logic_vector(6 DOWNTO 0);  -- boolean [7]
  SIGNAL obj_metricComputer_maxValidPipe_2 : std_logic_vector(6 DOWNTO 0);  -- boolean [7]
  SIGNAL tmp_40                           : std_logic_vector(6 DOWNTO 0);  -- boolean [7]

BEGIN
  varargout_2_1 <= varargin_2;

  varargout_3_1 <= varargin_3;

  varargout_4_1 <= varargin_4;

  s_s <= varargout_2_1 AND varargout_4_1;

  resetIn <= '0';

  resetIn_1 <= '1';

  
  tmp <= resetIn WHEN s_s = '0' ELSE
      resetIn_1;

  tmp_1 <= to_signed(16#00000000#, 32);

  tmp_2 <= to_signed(16#00000000#, 32);

  tmp_3 <= to_signed(16#00000000#, 32);

  tmp_4 <= to_signed(16#00000000#, 32);

  tmp_5 <= obj_metricComputer_validInPipe(to_integer(tmp_3 + tmp_4));

  p105obj_metricComputer_validInPipe_output : PROCESS (obj_metricComputer_validInPipe, tmp_1, tmp_2, varargout_4_1)
  BEGIN
    obj_metricComputer_validInPipe_1 <= obj_metricComputer_validInPipe;
    obj_metricComputer_validInPipe_1(to_integer(tmp_1 + tmp_2)) <= varargout_4_1;
  END PROCESS p105obj_metricComputer_validInPipe_output;


  p106tmp_output : PROCESS (obj_metricComputer_validInPipe_1, tmp_5)
  BEGIN
    tmp_6 <= obj_metricComputer_validInPipe_1;
    tmp_6(1) <= tmp_5;
  END PROCESS p106tmp_output;


  obj_metricComputer_validInPipe_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_metricComputer_validInPipe <= tmp_6;
      END IF;
    END IF;
  END PROCESS obj_metricComputer_validInPipe_reg_process;


  tmp_7 <= obj_metricComputer_validInPipe(1);

  tmp_8 <= to_signed(16#000#, 10);

  branchMetrics <= (OTHERS => to_signed(16#00#, 6));

  branchMetrics_1 <= (OTHERS => to_signed(16#00#, 6));

  tmp_9 <= to_signed(16#00#, 6);

  branchMetrics_2 <= (OTHERS => tmp_9);

  tmp_10 <= to_signed(16#00#, 6);

  dataIn <= (OTHERS => to_signed(16#0#, 4));

  varargout_1(0) <= signed(varargin_1_0);
  varargout_1(1) <= signed(varargin_1_1);
  varargout_1(2) <= signed(varargin_1_2);

  obj_metricComputer_dataInReg_1 <= varargout_1;

  obj_metricComputer_dataInReg_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_metricComputer_dataInReg <= obj_metricComputer_dataInReg_1;
      END IF;
    END IF;
  END PROCESS obj_metricComputer_dataInReg_reg_process;


  dataIn_1 <= obj_metricComputer_dataInReg;

  p17_output : PROCESS (dataIn_1, tmp_10)
    VARIABLE branchMetrics1 : vector_of_signed6(0 TO 7);
  BEGIN

    FOR ks IN 0 TO 7 LOOP
      branchMetrics1(ks) := tmp_10;

      FOR kb IN 0 TO 2 LOOP
        IF nc(to_integer(to_signed(ks, 32) + resize(resize(to_signed(kb, 32) & '0' & '0' & '0', 64), 32))) = '1' THEN 
          branchMetrics1(ks) := branchMetrics1(ks) + (resize(dataIn_1(kb), 6));
        ELSE 
          branchMetrics1(ks) := branchMetrics1(ks) - (resize(dataIn_1(kb), 6));
        END IF;
      END LOOP;

      branchMetrics_3(ks) <= branchMetrics1(ks);
    END LOOP;

  END PROCESS p17_output;


  obj_metricComputer_branchMetrics_1 <= branchMetrics_3;

  obj_metricComputer_branchMetrics_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_metricComputer_branchMetrics <= obj_metricComputer_branchMetrics_1;
      END IF;
    END IF;
  END PROCESS obj_metricComputer_branchMetrics_reg_process;


  branchMetrics_4 <= obj_metricComputer_branchMetrics;

  oldStateMetrics <= (OTHERS => to_signed(16#000#, 10));

  tmp_11 <= '0';

  tmp_12 <= '1';

  oldStateMetrics_1 <= obj_metricComputer_stateMetrics;

  obj_metricComputer_stateMetrics_1 <= (OTHERS => tmp_8);

  
  tmp_13 <= obj_metricComputer_stateMetrics WHEN tmp_7 = '0' ELSE
      obj_metricComputer_stateMetrics_2;

  
  tmp_14 <= tmp_13 WHEN tmp = '0' ELSE
      obj_metricComputer_stateMetrics_1;

  obj_metricComputer_stateMetrics_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_metricComputer_stateMetrics <= tmp_14;
      END IF;
    END IF;
  END PROCESS obj_metricComputer_stateMetrics_reg_process;


  p47_output : PROCESS (branchMetrics_4, oldStateMetrics_1, tmp_11, tmp_12)
    VARIABLE newStateMetricA : signed(9 DOWNTO 0);
    VARIABLE newStateMetricB : signed(9 DOWNTO 0);
    VARIABLE obj_metricComputer_stateMetrics1 : signed(9 DOWNTO 0);
    VARIABLE obj_metricComputer_decisions1 : std_logic;
  BEGIN
    newStateMetricA := to_signed(16#000#, 10);
    newStateMetricB := to_signed(16#000#, 10);
    obj_metricComputer_decisions1 := '0';
    obj_metricComputer_stateMetrics1 := to_signed(16#000#, 10);

    FOR mm IN 0 TO 63 LOOP
      newStateMetricA := oldStateMetrics_1(to_integer(nc_2(mm))) + (resize(branchMetrics_4(to_integer(nc_0(mm))), 10));
      newStateMetricB := oldStateMetrics_1(to_integer(nc_1_1(mm))) + (resize(branchMetrics_4(to_integer(nc_2_1(mm))), 10));
      IF (newStateMetricA - newStateMetricB) >= to_signed(16#000#, 10) THEN 
        obj_metricComputer_decisions1 := tmp_11;
        obj_metricComputer_stateMetrics1 := newStateMetricA;
      ELSE 
        obj_metricComputer_decisions1 := tmp_12;
        obj_metricComputer_stateMetrics1 := newStateMetricB;
      END IF;
      obj_metricComputer_decisions_1(mm) <= obj_metricComputer_decisions1;
      obj_metricComputer_stateMetrics_2(mm) <= obj_metricComputer_stateMetrics1;
    END LOOP;

  END PROCESS p47_output;


  
  tmp_15 <= obj_metricComputer_decisions WHEN tmp_7 = '0' ELSE
      obj_metricComputer_decisions_1;

  
  tmp_16 <= tmp_15 WHEN tmp = '0' ELSE
      obj_metricComputer_decisions;

  obj_metricComputer_decisions_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_metricComputer_decisions <= tmp_16;
      END IF;
    END IF;
  END PROCESS obj_metricComputer_decisions_reg_process;


  varargout_1_64 <= obj_metricComputer_decisions;

  varargout_1_65 <= varargout_1_64;

  varargout_1_0 <= varargout_1_65(0);

  varargout_1_1 <= varargout_1_65(1);

  varargout_1_2 <= varargout_1_65(2);

  varargout_1_3 <= varargout_1_65(3);

  varargout_1_4 <= varargout_1_65(4);

  varargout_1_5 <= varargout_1_65(5);

  varargout_1_6 <= varargout_1_65(6);

  varargout_1_7 <= varargout_1_65(7);

  varargout_1_8 <= varargout_1_65(8);

  varargout_1_9 <= varargout_1_65(9);

  varargout_1_10 <= varargout_1_65(10);

  varargout_1_11 <= varargout_1_65(11);

  varargout_1_12 <= varargout_1_65(12);

  varargout_1_13 <= varargout_1_65(13);

  varargout_1_14 <= varargout_1_65(14);

  varargout_1_15 <= varargout_1_65(15);

  varargout_1_16 <= varargout_1_65(16);

  varargout_1_17 <= varargout_1_65(17);

  varargout_1_18 <= varargout_1_65(18);

  varargout_1_19 <= varargout_1_65(19);

  varargout_1_20 <= varargout_1_65(20);

  varargout_1_21 <= varargout_1_65(21);

  varargout_1_22 <= varargout_1_65(22);

  varargout_1_23 <= varargout_1_65(23);

  varargout_1_24 <= varargout_1_65(24);

  varargout_1_25 <= varargout_1_65(25);

  varargout_1_26 <= varargout_1_65(26);

  varargout_1_27 <= varargout_1_65(27);

  varargout_1_28 <= varargout_1_65(28);

  varargout_1_29 <= varargout_1_65(29);

  varargout_1_30 <= varargout_1_65(30);

  varargout_1_31 <= varargout_1_65(31);

  varargout_1_32 <= varargout_1_65(32);

  varargout_1_33 <= varargout_1_65(33);

  varargout_1_34 <= varargout_1_65(34);

  varargout_1_35 <= varargout_1_65(35);

  varargout_1_36 <= varargout_1_65(36);

  varargout_1_37 <= varargout_1_65(37);

  varargout_1_38 <= varargout_1_65(38);

  varargout_1_39 <= varargout_1_65(39);

  varargout_1_40 <= varargout_1_65(40);

  varargout_1_41 <= varargout_1_65(41);

  varargout_1_42 <= varargout_1_65(42);

  varargout_1_43 <= varargout_1_65(43);

  varargout_1_44 <= varargout_1_65(44);

  varargout_1_45 <= varargout_1_65(45);

  varargout_1_46 <= varargout_1_65(46);

  varargout_1_47 <= varargout_1_65(47);

  varargout_1_48 <= varargout_1_65(48);

  varargout_1_49 <= varargout_1_65(49);

  varargout_1_50 <= varargout_1_65(50);

  varargout_1_51 <= varargout_1_65(51);

  varargout_1_52 <= varargout_1_65(52);

  varargout_1_53 <= varargout_1_65(53);

  varargout_1_54 <= varargout_1_65(54);

  varargout_1_55 <= varargout_1_65(55);

  varargout_1_56 <= varargout_1_65(56);

  varargout_1_57 <= varargout_1_65(57);

  varargout_1_58 <= varargout_1_65(58);

  varargout_1_59 <= varargout_1_65(59);

  varargout_1_60 <= varargout_1_65(60);

  varargout_1_61 <= varargout_1_65(61);

  varargout_1_62 <= varargout_1_65(62);

  varargout_1_63 <= varargout_1_65(63);

  tmp_17 <= to_signed(16#00000000#, 32);

  tmp_18 <= to_signed(16#00000000#, 32);

  tmp_19 <= to_signed(16#00000000#, 32);

  tmp_20 <= to_signed(16#00000000#, 32);

  tmp_21 <= obj_metricComputer_startInPipe(to_integer(tmp_19 + tmp_20));

  p89obj_metricComputer_startInPipe_output : PROCESS (obj_metricComputer_startInPipe, tmp_17, tmp_18, varargout_2_1)
  BEGIN
    obj_metricComputer_startInPipe_1 <= obj_metricComputer_startInPipe;
    obj_metricComputer_startInPipe_1(to_integer(tmp_17 + tmp_18)) <= varargout_2_1;
  END PROCESS p89obj_metricComputer_startInPipe_output;


  p90tmp_output : PROCESS (obj_metricComputer_startInPipe_1, tmp_21)
  BEGIN
    tmp_22 <= obj_metricComputer_startInPipe_1;
    tmp_22(1) <= tmp_21;
  END PROCESS p90tmp_output;


  obj_metricComputer_startInPipe_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_metricComputer_startInPipe <= tmp_22;
      END IF;
    END IF;
  END PROCESS obj_metricComputer_startInPipe_reg_process;


  tmp_23 <= obj_metricComputer_startInPipe(1);

  obj_metricComputer_startOutPipe_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_metricComputer_startOutPipe <= tmp_23;
      END IF;
    END IF;
  END PROCESS obj_metricComputer_startOutPipe_reg_process;


  tmp_24 <= to_signed(16#00000000#, 32);

  tmp_25 <= to_signed(16#00000000#, 32);

  tmp_26 <= to_signed(16#00000000#, 32);

  tmp_27 <= to_signed(16#00000000#, 32);

  tmp_28 <= obj_metricComputer_endInPipe(to_integer(tmp_26 + tmp_27));

  p97obj_metricComputer_endInPipe_output : PROCESS (obj_metricComputer_endInPipe, tmp_24, tmp_25, varargout_3_1)
  BEGIN
    obj_metricComputer_endInPipe_1 <= obj_metricComputer_endInPipe;
    obj_metricComputer_endInPipe_1(to_integer(tmp_24 + tmp_25)) <= varargout_3_1;
  END PROCESS p97obj_metricComputer_endInPipe_output;


  p98tmp_output : PROCESS (obj_metricComputer_endInPipe_1, tmp_28)
  BEGIN
    tmp_29 <= obj_metricComputer_endInPipe_1;
    tmp_29(1) <= tmp_28;
  END PROCESS p98tmp_output;


  obj_metricComputer_endInPipe_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_metricComputer_endInPipe <= tmp_29;
      END IF;
    END IF;
  END PROCESS obj_metricComputer_endInPipe_reg_process;


  tmp_30 <= obj_metricComputer_endInPipe(1);

  obj_metricComputer_endOutPipe_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_metricComputer_endOutPipe <= tmp_30;
      END IF;
    END IF;
  END PROCESS obj_metricComputer_endOutPipe_reg_process;


  obj_metricComputer_validOutPipe_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_metricComputer_validOutPipe <= tmp_7;
      END IF;
    END IF;
  END PROCESS obj_metricComputer_validOutPipe_reg_process;


  stateMetricsOut <= (OTHERS => to_signed(16#000#, 10));

  stateMetricsOut_1 <= obj_metricComputer_stateMetrics;


  obj_metricComputer_maxStates_1_gen: FOR kk IN 0 TO 63 GENERATE
    obj_metricComputer_maxStates_1(kk) <= unsigned(to_signed(kk, 32)(5 DOWNTO 0));
  END GENERATE obj_metricComputer_maxStates_1_gen;


  obj_metricComputer_maxMetrics_1 <= stateMetricsOut_1;

  
  tmp_31 <= obj_metricComputer_maxMetrics_2 WHEN obj_metricComputer_endOutPipe = '0' ELSE
      obj_metricComputer_maxMetrics_1;

  obj_metricComputer_maxMetrics_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_metricComputer_maxMetrics <= tmp_31;
      END IF;
    END IF;
  END PROCESS obj_metricComputer_maxMetrics_reg_process;


  p37_output : PROCESS (obj_metricComputer_maxMetrics, obj_metricComputer_maxStates)
    VARIABLE obj_metricComputer_maxStates1 : vector_of_unsigned6(0 TO 63);
    VARIABLE obj_metricComputer_maxMetrics1 : vector_of_signed10(0 TO 63);
  BEGIN
    obj_metricComputer_maxStates1 := obj_metricComputer_maxStates;
    obj_metricComputer_maxMetrics1 := obj_metricComputer_maxMetrics;

    FOR kk1 IN 0 TO 31 LOOP
      IF (obj_metricComputer_maxMetrics1(to_integer(resize(resize(to_signed(kk1, 32) & '0', 64), 31))) - obj_metricComputer_maxMetrics1(to_integer(resize(resize(to_signed(kk1, 32) & '0', 64), 32) + 1))) >= to_signed(16#000#, 10) THEN 
        obj_metricComputer_maxMetrics1(kk1) := obj_metricComputer_maxMetrics1(to_integer(resize(resize(to_signed(kk1, 32) & '0', 64), 31)));
        obj_metricComputer_maxStates1(kk1) := obj_metricComputer_maxStates1(to_integer(resize(resize(to_signed(kk1, 32) & '0', 64), 31)));
      ELSE 
        obj_metricComputer_maxMetrics1(kk1) := obj_metricComputer_maxMetrics1(to_integer(resize(resize(to_signed(kk1, 32) & '0', 64), 32) + 1));
        obj_metricComputer_maxStates1(kk1) := obj_metricComputer_maxStates1(to_integer(resize(resize(to_signed(kk1, 32) & '0', 64), 32) + 1));
      END IF;
    END LOOP;

    obj_metricComputer_maxStates_2 <= obj_metricComputer_maxStates1;
    obj_metricComputer_maxMetrics_2 <= obj_metricComputer_maxMetrics1;
  END PROCESS p37_output;


  
  tmp_32 <= obj_metricComputer_maxStates_2 WHEN obj_metricComputer_endOutPipe = '0' ELSE
      obj_metricComputer_maxStates_1;

  obj_metricComputer_maxStates_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_metricComputer_maxStates <= tmp_32;
      END IF;
    END IF;
  END PROCESS obj_metricComputer_maxStates_reg_process;


  varargout_5_tmp <= obj_metricComputer_maxStates(0);

  varargout_5 <= std_logic_vector(varargout_5_tmp);

  tmp_33 <= to_signed(16#00000000#, 32);

  tmp_34 <= to_signed(16#00000000#, 32);

  tmp_35 <= to_signed(16#00000000#, 32);

  tmp_36 <= to_signed(16#00000000#, 32);

  tmp_37 <= obj_metricComputer_resetInPipe(to_integer(tmp_35 + tmp_36));

  p113obj_metricComputer_resetInPipe_output : PROCESS (obj_metricComputer_resetInPipe, tmp, tmp_33, tmp_34)
  BEGIN
    obj_metricComputer_resetInPipe_1 <= obj_metricComputer_resetInPipe;
    obj_metricComputer_resetInPipe_1(to_integer(tmp_33 + tmp_34)) <= tmp;
  END PROCESS p113obj_metricComputer_resetInPipe_output;


  p114tmp_output : PROCESS (obj_metricComputer_resetInPipe_1, tmp_37)
  BEGIN
    tmp_38 <= obj_metricComputer_resetInPipe_1;
    tmp_38(1) <= tmp_37;
  END PROCESS p114tmp_output;


  obj_metricComputer_resetInPipe_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_metricComputer_resetInPipe <= tmp_38;
      END IF;
    END IF;
  END PROCESS obj_metricComputer_resetInPipe_reg_process;


  resetIn_2 <= obj_metricComputer_resetInPipe(1);

  endOut <= (OTHERS => '0');

  s_s_1 <= '1';

  sel <= '0';

  
  sel_2 <= s_s_1 WHEN resetIn_2 = '0' ELSE
      sel;

  p25endOut_output : PROCESS (endOut, obj_metricComputer_endOutPipe, sel_2)
  BEGIN
    endOut_1 <= endOut;
    IF sel_2 = '1' THEN 
      endOut_1(0) <= obj_metricComputer_endOutPipe;
    END IF;
  END PROCESS p25endOut_output;


  tmp_39 <= '0';

  obj_metricComputer_maxValidPipe_1 <= (OTHERS => tmp_39);

  p24_output : PROCESS (endOut_1, obj_metricComputer_maxValidPipe)
  BEGIN
    endOut_2 <= endOut_1;
    endOut_2(6 DOWNTO 1) <= obj_metricComputer_maxValidPipe(5 DOWNTO 0);
  END PROCESS p24_output;


  obj_metricComputer_maxValidPipe_2 <= endOut_2;

  
  tmp_40 <= obj_metricComputer_maxValidPipe_2 WHEN resetIn_2 = '0' ELSE
      obj_metricComputer_maxValidPipe_1;

  obj_metricComputer_maxValidPipe_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_metricComputer_maxValidPipe <= tmp_40;
      END IF;
    END IF;
  END PROCESS obj_metricComputer_maxValidPipe_reg_process;


  varargout_6 <= obj_metricComputer_maxValidPipe(6);

  varargout_2 <= obj_metricComputer_startOutPipe;

  varargout_3 <= obj_metricComputer_endOutPipe;

  varargout_4 <= obj_metricComputer_validOutPipe;

END rtl;

