-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlPBCHDecoder;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_ConvolutionalDecoderMessageExtender IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        varargin_1_0                      :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        varargin_1_1                      :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        varargin_1_2                      :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        varargin_2                        :   IN    std_logic;
        varargin_3                        :   IN    std_logic;
        varargin_4                        :   IN    std_logic;
        varargout_1_0                     :   OUT   std_logic_vector(3 DOWNTO 0);  -- ufix4
        varargout_1_1                     :   OUT   std_logic_vector(3 DOWNTO 0);  -- ufix4
        varargout_1_2                     :   OUT   std_logic_vector(3 DOWNTO 0);  -- ufix4
        varargout_2                       :   OUT   std_logic;
        varargout_3                       :   OUT   std_logic;
        varargout_4                       :   OUT   std_logic;
        varargout_5                       :   OUT   std_logic
        );
END ltehdlPBCHDecoder_ConvolutionalDecoderMessageExtender;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_ConvolutionalDecoderMessageExtender IS

  -- Component Declarations
  COMPONENT ltehdlPBCHDecoder_SinglePortRAM_generic_block
    GENERIC( AddrWidth                    : integer;
             DataWidth                    : integer
             );
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          din                             :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          addr                            :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          we                              :   IN    std_logic;
          dout                            :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0)  -- generic width
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlPBCHDecoder_SinglePortRAM_generic_block
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_SinglePortRAM_generic_block(rtl);

  -- Signals
  SIGNAL ctrl_start                       : std_logic;
  SIGNAL ctrl_end                         : std_logic;
  SIGNAL ctrl_valid                       : std_logic;
  SIGNAL dataIn                           : vector_of_signed4(0 TO 2);  -- sfix4_En1 [3]
  SIGNAL data                             : vector_of_signed4(0 TO 2);  -- sfix4_En1 [3]
  SIGNAL obj_messageExtender_dataIn       : vector_of_signed4(0 TO 2) := (OTHERS => to_signed(16#0#, 4));  -- sfix4_En1 [3]
  SIGNAL obj_messageExtender_dataIn_1     : vector_of_signed4(0 TO 2);  -- sfix4_En1 [3]
  SIGNAL dataIn_1                         : vector_of_signed4(0 TO 2);  -- sfix4_En1 [3]
  SIGNAL ramDataIn                        : unsigned(11 DOWNTO 0);  -- ufix12
  SIGNAL s_s                              : std_logic;
  SIGNAL fsmNext_state                    : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL fsmNext_state_1                  : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL fsmNext_state_2                  : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL tmp                              : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL tmp_1                            : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL fsmNext_state_3                  : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL fsmNext_extCount                 : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL fsmNext_extCount_1               : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL fsmNext_state_4                  : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL fsmNext_state_5                  : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL fsmNext_state_6                  : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL fsmNext_state_7                  : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL obj_messageExtender_fsm_extCount : unsigned(6 DOWNTO 0) := to_unsigned(16#00#, 7);  -- ufix7
  SIGNAL tmp_2                            : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL s_s_1                            : signed(31 DOWNTO 0);  -- int32
  SIGNAL tmp_3                            : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL tmp_4                            : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL s_s_2                            : std_logic;
  SIGNAL tmp_5                            : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL tmp_6                            : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL tmp_7                            : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL obj_messageExtender_fsm_state    : unsigned(1 DOWNTO 0) := to_unsigned(16#0#, 2);  -- ufix2
  SIGNAL fsmNext_addr                     : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL fsmNext_addr_1                   : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL fsmNext_addr_2                   : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL obj_messageExtender_fsm_addr     : unsigned(7 DOWNTO 0) := to_unsigned(16#00#, 8);  -- ufix8
  SIGNAL tmp_8                            : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL obj_messageExtender_fsm_endAddr  : unsigned(7 DOWNTO 0) := to_unsigned(16#00#, 8);  -- ufix8
  SIGNAL tmp_9                            : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tmp_10                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL s_s_3                            : std_logic;
  SIGNAL tmp_11                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tmp_12                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tmp_13                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tmp_14                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL tmp_15                           : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL fsmNext_wrEn                     : std_logic;
  SIGNAL fsmNext_wrEn_1                   : std_logic;
  SIGNAL tmp_16                           : std_logic;
  SIGNAL fsmNext_wrEn_2                   : std_logic;
  SIGNAL fsmNext_wrEn_3                   : std_logic;
  SIGNAL fsmNext_wrEn_4                   : std_logic;
  SIGNAL tmp_17                           : std_logic;
  SIGNAL fsmNext_wrEn_5                   : std_logic;
  SIGNAL tmp_18                           : std_logic;
  SIGNAL obj_messageExtender_fsm_wrEn     : std_logic := '0';
  SIGNAL dataSplit                        : vector_of_signed4(0 TO 2);  -- sfix4_En1 [3]
  SIGNAL yfi_trivial_scaling              : vector_of_signed4(0 TO 2);  -- sfix4 [3]
  SIGNAL xfi_trivial_scaling              : vector_of_unsigned4(0 TO 2);  -- ufix4 [3]
  SIGNAL xfi_stripped                     : vector_of_unsigned4(0 TO 2);  -- ufix4 [3]
  SIGNAL ramDataOut                       : std_logic_vector(11 DOWNTO 0);  -- ufix12
  SIGNAL ramDataOut_unsigned              : unsigned(11 DOWNTO 0);  -- ufix12
  SIGNAL xfi_stripped_1                   : vector_of_unsigned4(0 TO 2);  -- ufix4 [3]
  SIGNAL xfi_trivial_scaling_1            : vector_of_unsigned4(0 TO 2);  -- ufix4 [3]
  SIGNAL yfi_trivial_scaling_1            : vector_of_signed4(0 TO 2);  -- sfix4 [3]
  SIGNAL dataSplit_1                      : vector_of_signed4(0 TO 2);  -- sfix4_En1 [3]
  SIGNAL obj_messageExtender_dataOut      : vector_of_signed4(0 TO 2) := (OTHERS => to_signed(16#0#, 4));  -- sfix4_En1 [3]
  SIGNAL obj_messageExtender_dataOut_1    : vector_of_signed4(0 TO 2);  -- sfix4_En1 [3]
  SIGNAL fsmNext_startOut                 : std_logic;
  SIGNAL fsmNext_startOut_1               : std_logic;
  SIGNAL tmp_19                           : std_logic;
  SIGNAL fsmNext_startOut_2               : std_logic;
  SIGNAL fsmNext_startOut_3               : std_logic;
  SIGNAL fsmNext_startOut_4               : std_logic;
  SIGNAL tmp_20                           : std_logic;
  SIGNAL fsmNext_startOut_5               : std_logic;
  SIGNAL tmp_21                           : std_logic;
  SIGNAL obj_messageExtender_fsm_startOut : std_logic := '0';
  SIGNAL fsmNext_endExtOut                : std_logic;
  SIGNAL fsmNext_endExtOut_1              : std_logic;
  SIGNAL tmp_22                           : std_logic;
  SIGNAL fsmNext_endExtOut_2              : std_logic;
  SIGNAL fsmNext_endExtOut_3              : std_logic;
  SIGNAL fsmNext_endExtOut_4              : std_logic;
  SIGNAL tmp_23                           : std_logic;
  SIGNAL fsmNext_endExtOut_5              : std_logic;
  SIGNAL tmp_24                           : std_logic;
  SIGNAL fsmNext_endExtOut_6              : std_logic;
  SIGNAL tmp_25                           : std_logic;
  SIGNAL obj_messageExtender_fsm_endExtOut : std_logic := '0';
  SIGNAL fsmNext_validOut                 : std_logic;
  SIGNAL fsmNext_validOut_1               : std_logic;
  SIGNAL tmp_26                           : std_logic;
  SIGNAL fsmNext_validOut_2               : std_logic;
  SIGNAL fsmNext_validOut_3               : std_logic;
  SIGNAL fsmNext_validOut_4               : std_logic;
  SIGNAL tmp_27                           : std_logic;
  SIGNAL fsmNext_validOut_5               : std_logic;
  SIGNAL tmp_28                           : std_logic;
  SIGNAL obj_messageExtender_fsm_validOut : std_logic := '0';
  SIGNAL fsmNext_endMsgOut                : std_logic;
  SIGNAL fsmNext_endMsgOut_1              : std_logic;
  SIGNAL fsmNext_endMsgOut_2              : std_logic;
  SIGNAL tmp_29                           : std_logic;
  SIGNAL tmp_30                           : std_logic;
  SIGNAL fsmNext_endMsgOut_3              : std_logic;
  SIGNAL tmp_31                           : std_logic;
  SIGNAL fsmNext_endMsgOut_4              : std_logic;
  SIGNAL tmp_32                           : std_logic;
  SIGNAL fsmNext_endMsgOut_5              : std_logic;
  SIGNAL tmp_33                           : std_logic;
  SIGNAL obj_messageExtender_fsm_endMsgOut : std_logic := '0';
  SIGNAL obj_messageExtender_ctrlDelay    : std_logic_vector(3 DOWNTO 0) := (OTHERS => '0');  -- boolean [4]
  SIGNAL tmp_34                           : std_logic_vector(3 DOWNTO 0);  -- boolean [4]
  SIGNAL tmp_35                           : std_logic;
  SIGNAL obj_messageExtender_startOut     : std_logic := '0';
  SIGNAL tmp_36                           : std_logic;
  SIGNAL obj_messageExtender_endExtOut    : std_logic := '0';
  SIGNAL tmp_37                           : std_logic;
  SIGNAL obj_messageExtender_validOut     : std_logic := '0';
  SIGNAL tmp_38                           : std_logic;
  SIGNAL obj_messageExtender_endMsgOut    : std_logic := '0';

BEGIN
  UsinglePortRam_generic : ltehdlPBCHDecoder_SinglePortRAM_generic_block
    GENERIC MAP( AddrWidth => 8,
                 DataWidth => 12
                 )
    PORT MAP( clk => clk,
              enb => enb,
              din => std_logic_vector(ramDataIn),
              addr => std_logic_vector(obj_messageExtender_fsm_addr),
              we => obj_messageExtender_fsm_wrEn,
              dout => ramDataOut
              );

  ctrl_start <= varargin_2;

  ctrl_end <= varargin_3;

  ctrl_valid <= varargin_4;

  dataIn <= (OTHERS => to_signed(16#0#, 4));

  data(0) <= signed(varargin_1_0);
  data(1) <= signed(varargin_1_1);
  data(2) <= signed(varargin_1_2);

  obj_messageExtender_dataIn_1 <= data;

  obj_messageExtender_dataIn_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_dataIn <= obj_messageExtender_dataIn_1;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_dataIn_reg_process;


  dataIn_1 <= obj_messageExtender_dataIn;

  ramDataIn <= unsigned(dataIn_1(0)) & unsigned(dataIn_1(1)) & unsigned(dataIn_1(2));

  s_s <= ctrl_valid AND ctrl_start;

  fsmNext_state <= to_unsigned(16#1#, 2);

  fsmNext_state_1 <= to_unsigned(16#1#, 2);

  fsmNext_state_2 <= to_unsigned(16#2#, 2);

  
  tmp <= fsmNext_state_1 WHEN ctrl_end = '0' ELSE
      fsmNext_state_2;

  
  tmp_1 <= fsmNext_state WHEN ctrl_valid = '0' ELSE
      tmp;

  fsmNext_state_3 <= to_unsigned(16#3#, 2);

  fsmNext_extCount <= to_unsigned(16#00#, 7);

  fsmNext_extCount_1 <= to_unsigned(16#00#, 7);

  fsmNext_state_4 <= to_unsigned(16#3#, 2);

  fsmNext_state_5 <= to_unsigned(16#0#, 2);

  fsmNext_state_6 <= to_unsigned(16#0#, 2);

  fsmNext_state_7 <= to_unsigned(16#1#, 2);

  tmp_2 <= obj_messageExtender_fsm_extCount + to_unsigned(16#01#, 7);

  
  tmp_3 <= obj_messageExtender_fsm_extCount WHEN s_s_1 = to_signed(1, 32) ELSE
      fsmNext_extCount WHEN s_s_1 = to_signed(2, 32) ELSE
      tmp_2 WHEN s_s_1 = to_signed(3, 32) ELSE
      fsmNext_extCount_1;

  
  tmp_4 <= tmp_3 WHEN s_s = '0' ELSE
      obj_messageExtender_fsm_extCount;

  obj_messageExtender_fsm_extCount_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_fsm_extCount <= tmp_4;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_fsm_extCount_reg_process;


  
  s_s_2 <= '1' WHEN obj_messageExtender_fsm_extCount = to_unsigned(16#4E#, 7) ELSE
      '0';

  
  tmp_5 <= fsmNext_state_4 WHEN s_s_2 = '0' ELSE
      fsmNext_state_5;

  
  tmp_6 <= tmp_1 WHEN s_s_1 = to_signed(1, 32) ELSE
      fsmNext_state_3 WHEN s_s_1 = to_signed(2, 32) ELSE
      tmp_5 WHEN s_s_1 = to_signed(3, 32) ELSE
      fsmNext_state_6;

  
  tmp_7 <= tmp_6 WHEN s_s = '0' ELSE
      fsmNext_state_7;

  obj_messageExtender_fsm_state_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_fsm_state <= tmp_7;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_fsm_state_reg_process;


  s_s_1 <= signed(resize(obj_messageExtender_fsm_state, 32));

  fsmNext_addr <= to_unsigned(16#00#, 8);

  fsmNext_addr_1 <= to_unsigned(16#00#, 8);

  fsmNext_addr_2 <= to_unsigned(16#00#, 8);

  tmp_8 <= obj_messageExtender_fsm_addr + to_unsigned(16#01#, 8);

  
  tmp_9 <= obj_messageExtender_fsm_endAddr WHEN s_s_1 = to_signed(1, 32) ELSE
      obj_messageExtender_fsm_addr WHEN s_s_1 = to_signed(2, 32) ELSE
      obj_messageExtender_fsm_endAddr WHEN s_s_1 = to_signed(3, 32) ELSE
      obj_messageExtender_fsm_endAddr;

  
  tmp_10 <= tmp_9 WHEN s_s = '0' ELSE
      obj_messageExtender_fsm_endAddr;

  obj_messageExtender_fsm_endAddr_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_fsm_endAddr <= tmp_10;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_fsm_endAddr_reg_process;


  
  s_s_3 <= '1' WHEN obj_messageExtender_fsm_addr = obj_messageExtender_fsm_endAddr ELSE
      '0';

  
  tmp_11 <= tmp_8 WHEN s_s_3 = '0' ELSE
      fsmNext_addr_1;

  tmp_12 <= obj_messageExtender_fsm_addr + to_unsigned(16#01#, 8);

  
  tmp_13 <= obj_messageExtender_fsm_addr WHEN ctrl_valid = '0' ELSE
      tmp_12;

  
  tmp_14 <= tmp_13 WHEN s_s_1 = to_signed(1, 32) ELSE
      fsmNext_addr WHEN s_s_1 = to_signed(2, 32) ELSE
      tmp_11 WHEN s_s_1 = to_signed(3, 32) ELSE
      obj_messageExtender_fsm_addr;

  
  tmp_15 <= tmp_14 WHEN s_s = '0' ELSE
      fsmNext_addr_2;

  obj_messageExtender_fsm_addr_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_fsm_addr <= tmp_15;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_fsm_addr_reg_process;


  fsmNext_wrEn <= '0';

  fsmNext_wrEn_1 <= '1';

  
  tmp_16 <= fsmNext_wrEn WHEN ctrl_valid = '0' ELSE
      fsmNext_wrEn_1;

  fsmNext_wrEn_2 <= '0';

  fsmNext_wrEn_3 <= '0';

  fsmNext_wrEn_4 <= '0';

  
  tmp_17 <= tmp_16 WHEN s_s_1 = to_signed(1, 32) ELSE
      fsmNext_wrEn_2 WHEN s_s_1 = to_signed(2, 32) ELSE
      fsmNext_wrEn_3 WHEN s_s_1 = to_signed(3, 32) ELSE
      fsmNext_wrEn_4;

  fsmNext_wrEn_5 <= '1';

  
  tmp_18 <= tmp_17 WHEN s_s = '0' ELSE
      fsmNext_wrEn_5;

  obj_messageExtender_fsm_wrEn_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_fsm_wrEn <= tmp_18;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_fsm_wrEn_reg_process;


  dataSplit <= (OTHERS => to_signed(16#0#, 4));

  yfi_trivial_scaling <= (OTHERS => to_signed(16#0#, 4));

  xfi_trivial_scaling <= (OTHERS => to_unsigned(16#0#, 4));

  xfi_stripped <= (OTHERS => to_unsigned(16#0#, 4));

  ramDataOut_unsigned <= unsigned(ramDataOut);

  p87xfi_stripped_output : PROCESS (ramDataOut_unsigned)
  BEGIN
    xfi_stripped_1(0) <= ramDataOut_unsigned(11 DOWNTO 8);
    xfi_stripped_1(1) <= ramDataOut_unsigned(7 DOWNTO 4);
    xfi_stripped_1(2) <= ramDataOut_unsigned(3 DOWNTO 0);
  END PROCESS p87xfi_stripped_output;


  xfi_trivial_scaling_1 <= xfi_stripped_1;


  yfi_trivial_scaling_1_gen: FOR t_0 IN 0 TO 2 GENERATE
    yfi_trivial_scaling_1(t_0) <= signed(xfi_trivial_scaling_1(t_0));
  END GENERATE yfi_trivial_scaling_1_gen;


  dataSplit_1 <= yfi_trivial_scaling_1;

  obj_messageExtender_dataOut_1 <= dataSplit_1;

  obj_messageExtender_dataOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_dataOut <= obj_messageExtender_dataOut_1;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_dataOut_reg_process;


  varargout_1_0 <= std_logic_vector(obj_messageExtender_dataOut(0));

  varargout_1_1 <= std_logic_vector(obj_messageExtender_dataOut(1));

  varargout_1_2 <= std_logic_vector(obj_messageExtender_dataOut(2));

  fsmNext_startOut <= '0';

  fsmNext_startOut_1 <= '0';

  
  tmp_19 <= fsmNext_startOut WHEN ctrl_valid = '0' ELSE
      fsmNext_startOut_1;

  fsmNext_startOut_2 <= '0';

  fsmNext_startOut_3 <= '0';

  fsmNext_startOut_4 <= '0';

  
  tmp_20 <= tmp_19 WHEN s_s_1 = to_signed(1, 32) ELSE
      fsmNext_startOut_2 WHEN s_s_1 = to_signed(2, 32) ELSE
      fsmNext_startOut_3 WHEN s_s_1 = to_signed(3, 32) ELSE
      fsmNext_startOut_4;

  fsmNext_startOut_5 <= '1';

  
  tmp_21 <= tmp_20 WHEN s_s = '0' ELSE
      fsmNext_startOut_5;

  obj_messageExtender_fsm_startOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_fsm_startOut <= tmp_21;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_fsm_startOut_reg_process;


  fsmNext_endExtOut <= '0';

  fsmNext_endExtOut_1 <= '0';

  
  tmp_22 <= fsmNext_endExtOut WHEN ctrl_valid = '0' ELSE
      fsmNext_endExtOut_1;

  fsmNext_endExtOut_2 <= '0';

  fsmNext_endExtOut_3 <= '0';

  fsmNext_endExtOut_4 <= '1';

  
  tmp_23 <= fsmNext_endExtOut_3 WHEN s_s_2 = '0' ELSE
      fsmNext_endExtOut_4;

  fsmNext_endExtOut_5 <= '0';

  
  tmp_24 <= tmp_22 WHEN s_s_1 = to_signed(1, 32) ELSE
      fsmNext_endExtOut_2 WHEN s_s_1 = to_signed(2, 32) ELSE
      tmp_23 WHEN s_s_1 = to_signed(3, 32) ELSE
      fsmNext_endExtOut_5;

  fsmNext_endExtOut_6 <= '0';

  
  tmp_25 <= tmp_24 WHEN s_s = '0' ELSE
      fsmNext_endExtOut_6;

  obj_messageExtender_fsm_endExtOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_fsm_endExtOut <= tmp_25;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_fsm_endExtOut_reg_process;


  fsmNext_validOut <= '0';

  fsmNext_validOut_1 <= '1';

  
  tmp_26 <= fsmNext_validOut WHEN ctrl_valid = '0' ELSE
      fsmNext_validOut_1;

  fsmNext_validOut_2 <= '1';

  fsmNext_validOut_3 <= '1';

  fsmNext_validOut_4 <= '0';

  
  tmp_27 <= tmp_26 WHEN s_s_1 = to_signed(1, 32) ELSE
      fsmNext_validOut_2 WHEN s_s_1 = to_signed(2, 32) ELSE
      fsmNext_validOut_3 WHEN s_s_1 = to_signed(3, 32) ELSE
      fsmNext_validOut_4;

  fsmNext_validOut_5 <= '1';

  
  tmp_28 <= tmp_27 WHEN s_s = '0' ELSE
      fsmNext_validOut_5;

  obj_messageExtender_fsm_validOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_fsm_validOut <= tmp_28;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_fsm_validOut_reg_process;


  fsmNext_endMsgOut <= '0';

  fsmNext_endMsgOut_1 <= '0';

  fsmNext_endMsgOut_2 <= '1';

  
  tmp_29 <= fsmNext_endMsgOut_1 WHEN ctrl_end = '0' ELSE
      fsmNext_endMsgOut_2;

  
  tmp_30 <= fsmNext_endMsgOut WHEN ctrl_valid = '0' ELSE
      tmp_29;

  fsmNext_endMsgOut_3 <= '0';

  
  tmp_31 <= '1' WHEN resize(obj_messageExtender_fsm_addr, 9) = (resize(obj_messageExtender_fsm_endAddr, 9) - to_unsigned(16#001#, 9)) ELSE
      '0';

  fsmNext_endMsgOut_4 <= '0';

  
  tmp_32 <= tmp_30 WHEN s_s_1 = to_signed(1, 32) ELSE
      fsmNext_endMsgOut_3 WHEN s_s_1 = to_signed(2, 32) ELSE
      tmp_31 WHEN s_s_1 = to_signed(3, 32) ELSE
      fsmNext_endMsgOut_4;

  fsmNext_endMsgOut_5 <= '0';

  
  tmp_33 <= tmp_32 WHEN s_s = '0' ELSE
      fsmNext_endMsgOut_5;

  obj_messageExtender_fsm_endMsgOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_fsm_endMsgOut <= tmp_33;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_fsm_endMsgOut_reg_process;


  p73tmp_output : PROCESS (obj_messageExtender_fsm_endExtOut, obj_messageExtender_fsm_endMsgOut,
       obj_messageExtender_fsm_startOut, obj_messageExtender_fsm_validOut)
  BEGIN
    tmp_34(0) <= obj_messageExtender_fsm_startOut;
    tmp_34(1) <= obj_messageExtender_fsm_endExtOut;
    tmp_34(2) <= obj_messageExtender_fsm_validOut;
    tmp_34(3) <= obj_messageExtender_fsm_endMsgOut;
  END PROCESS p73tmp_output;


  obj_messageExtender_ctrlDelay_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_ctrlDelay <= tmp_34;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_ctrlDelay_reg_process;


  tmp_35 <= obj_messageExtender_ctrlDelay(0);

  obj_messageExtender_startOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_startOut <= tmp_35;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_startOut_reg_process;


  tmp_36 <= obj_messageExtender_ctrlDelay(1);

  obj_messageExtender_endExtOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_endExtOut <= tmp_36;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_endExtOut_reg_process;


  tmp_37 <= obj_messageExtender_ctrlDelay(2);

  obj_messageExtender_validOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_validOut <= tmp_37;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_validOut_reg_process;


  tmp_38 <= obj_messageExtender_ctrlDelay(3);

  obj_messageExtender_endMsgOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        obj_messageExtender_endMsgOut <= tmp_38;
      END IF;
    END IF;
  END PROCESS obj_messageExtender_endMsgOut_reg_process;


  varargout_2 <= obj_messageExtender_startOut;

  varargout_3 <= obj_messageExtender_endExtOut;

  varargout_4 <= obj_messageExtender_validOut;

  varargout_5 <= obj_messageExtender_endMsgOut;

END rtl;

