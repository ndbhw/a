-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_rateRecovery IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        u1                                :   IN    std_logic_vector(17 DOWNTO 0);  -- ufix18
        enb_1                             :   IN    std_logic;
        y_0                               :   OUT   std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        y_1                               :   OUT   std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        y_2                               :   OUT   std_logic_vector(19 DOWNTO 0);  -- sfix20_En17
        validOut                          :   OUT   std_logic
        );
END ltehdlPBCHDecoder_rateRecovery;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_rateRecovery IS

  -- Constants
  CONSTANT nc                             : vector_of_unsigned7(0 TO 39) := 
    (to_unsigned(16#18#, 7), to_unsigned(16#04#, 7), to_unsigned(16#22#, 7), to_unsigned(16#0E#, 7), to_unsigned(16#1D#, 7), to_unsigned(16#09#, 7), to_unsigned(16#27#, 7), to_unsigned(16#13#, 7), to_unsigned(16#15#, 7), to_unsigned(16#01#, 7), 
      to_unsigned(16#1F#, 7), to_unsigned(16#0B#, 7), to_unsigned(16#1A#, 7), to_unsigned(16#06#, 7), to_unsigned(16#24#, 7), to_unsigned(16#10#, 7), to_unsigned(16#17#, 7), to_unsigned(16#03#, 7), to_unsigned(16#21#, 7), to_unsigned(16#0D#, 7), 
      to_unsigned(16#1C#, 7), to_unsigned(16#08#, 7), to_unsigned(16#26#, 7), to_unsigned(16#12#, 7), to_unsigned(16#16#, 7), to_unsigned(16#02#, 7), to_unsigned(16#20#, 7), to_unsigned(16#0C#, 7), to_unsigned(16#1B#, 7), to_unsigned(16#07#, 7), 
      to_unsigned(16#25#, 7), to_unsigned(16#11#, 7), to_unsigned(16#19#, 7), to_unsigned(16#05#, 7), to_unsigned(16#23#, 7), to_unsigned(16#0F#, 7), to_unsigned(16#1E#, 7), to_unsigned(16#0A#, 7), to_unsigned(16#28#, 7), to_unsigned(16#14#, 7)); 
-- ufix7 [40]

  -- Signals
  SIGNAL u1_signed                        : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL y_y                              : vector_of_signed20(0 TO 2);  -- sfix20_En17 [3]
  SIGNAL dbuffer                          : vector_of_signed20(0 TO 119);  -- sfix20 [120]
  SIGNAL waddr                            : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL rIdx                             : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL rCnt                             : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL rateRState                       : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL readFlag                         : std_logic;
  SIGNAL dbuffer_next                     : vector_of_signed20(0 TO 119);  -- sfix20_En17 [120]
  SIGNAL waddr_next                       : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL rIdx_next                        : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL rCnt_next                        : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL rateRState_next                  : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL readFlag_next                    : std_logic;

BEGIN
  u1_signed <= signed(u1);

  rateRecovery_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        dbuffer <= (OTHERS => to_signed(16#00000#, 20));
        waddr <= to_unsigned(16#000#, 9);
        rIdx <= to_unsigned(16#00#, 7);
        rCnt <= to_unsigned(16#00#, 7);
        rateRState <= to_unsigned(16#0#, 2);
        readFlag <= '0';
      ELSIF enb = '1' THEN
        dbuffer <= dbuffer_next;
        waddr <= waddr_next;
        rIdx <= rIdx_next;
        rCnt <= rCnt_next;
        rateRState <= rateRState_next;
        readFlag <= readFlag_next;
      END IF;
    END IF;
  END PROCESS rateRecovery_process;

  rateRecovery_output : PROCESS (dbuffer, enb_1, rCnt, rIdx, rateRState, readFlag, u1_signed, waddr)
    VARIABLE raddr : vector_of_unsigned7(0 TO 2);
    VARIABLE tt : signed(20 DOWNTO 0);
    VARIABLE waddr_temp : unsigned(8 DOWNTO 0);
    VARIABLE rIdx_temp : unsigned(6 DOWNTO 0);
    VARIABLE rCnt_temp : unsigned(6 DOWNTO 0);
    VARIABLE sub_cast : signed(31 DOWNTO 0);
    VARIABLE sub_cast_0 : signed(31 DOWNTO 0);
    VARIABLE sub_cast_1 : signed(31 DOWNTO 0);
  BEGIN
    tt := to_signed(16#000000#, 21);
    sub_cast := to_signed(16#00000000#, 32);
    sub_cast_0 := to_signed(16#00000000#, 32);
    sub_cast_1 := to_signed(16#00000000#, 32);
    waddr_temp := waddr;
    rIdx_temp := rIdx;
    rCnt_temp := rCnt;
    dbuffer_next <= dbuffer;
    rateRState_next <= rateRState;
    readFlag_next <= readFlag;
    --Assuming input is always signed fi type
    -- connecting to Viterbi Decoder
    y_y <= (OTHERS => to_signed(16#00000#, 20));
    validOut <= '0';
    CASE rateRState IS
      WHEN "00" =>
        -- idle state
        IF enb_1 = '1' THEN 
          rateRState_next <= to_unsigned(16#1#, 2);
          waddr_temp := waddr + to_unsigned(16#001#, 9);
          dbuffer_next(119) <= resize(u1_signed, 20);
        END IF;
      WHEN "01" =>
        IF enb_1 = '1' THEN 
          waddr_temp := waddr + to_unsigned(16#001#, 9);
          tt := (resize(dbuffer(0), 21)) + (resize(u1_signed, 21));
          dbuffer_next(0 TO 118) <= dbuffer(1 TO 119);
          dbuffer_next(119) <= tt(19 DOWNTO 0);
          IF waddr_temp = to_unsigned(16#1E0#, 9) THEN 
            waddr_temp := to_unsigned(16#000#, 9);
            rateRState_next <= to_unsigned(16#2#, 2);
            readFlag_next <= '1';
          END IF;
        END IF;
      WHEN "10" =>
        IF readFlag = '1' THEN 
          rIdx_temp := rIdx + to_unsigned(16#01#, 7);
          rCnt_temp := rCnt + to_unsigned(16#01#, 7);
          sub_cast := signed(resize(rIdx_temp, 32));
          raddr(0) := nc(to_integer(sub_cast - 1));
          raddr(1) := raddr(0) + to_unsigned(16#28#, 7);
          raddr(2) := raddr(0) + to_unsigned(16#50#, 7);
          IF rIdx_temp = to_unsigned(16#28#, 7) THEN 
            rIdx_temp := to_unsigned(16#00#, 7);
          END IF;
          IF rCnt_temp = to_unsigned(16#28#, 7) THEN 
            rateRState_next <= to_unsigned(16#0#, 2);
            waddr_temp := to_unsigned(16#000#, 9);
            rIdx_temp := to_unsigned(16#00#, 7);
            rCnt_temp := to_unsigned(16#00#, 7);
            readFlag_next <= '0';
          END IF;

          FOR t_0 IN 0 TO 2 LOOP
            sub_cast_0 := signed(resize(raddr(t_0), 32));
            y_y(t_0) <= dbuffer(to_integer(sub_cast_0 - 1));
            sub_cast_1 := signed(resize(raddr(t_0), 32));
            dbuffer_next(to_integer(sub_cast_1 - 1)) <= to_signed(16#00000#, 20);
          END LOOP;

          validOut <= '1';
        END IF;
        --   readFlag = ~readFlag; %read rate control
      WHEN OTHERS => 
        y_y <= (OTHERS => to_signed(16#00000#, 20));
        rateRState_next <= to_unsigned(16#0#, 2);
        waddr_temp := to_unsigned(16#000#, 9);
        rIdx_temp := to_unsigned(16#00#, 7);
    END CASE;
    waddr_next <= waddr_temp;
    rIdx_next <= rIdx_temp;
    rCnt_next <= rCnt_temp;
  END PROCESS rateRecovery_output;


  y_0 <= std_logic_vector(y_y(0));

  y_1 <= std_logic_vector(y_y(1));

  y_2 <= std_logic_vector(y_y(2));

END rtl;

