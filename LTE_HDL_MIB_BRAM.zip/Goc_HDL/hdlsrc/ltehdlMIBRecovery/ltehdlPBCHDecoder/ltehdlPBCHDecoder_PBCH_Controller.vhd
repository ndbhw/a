-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlPBCHDecoder_PBCH_Controller IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        valid_eq                          :   IN    std_logic;
        repeat_qpsk                       :   IN    std_logic;
        MIB_detected                      :   IN    std_logic;
        restart_MIB                       :   IN    std_logic;
        load_des                          :   OUT   std_logic;
        enb_des                           :   OUT   std_logic;
        waddr_qpsk                        :   OUT   std_logic_vector(7 DOWNTO 0);  -- uint8
        raddr_qpsk                        :   OUT   std_logic_vector(7 DOWNTO 0)  -- uint8
        );
END ltehdlPBCHDecoder_PBCH_Controller;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_PBCH_Controller IS

  -- Signals
  SIGNAL waddr_qpsk_tmp                   : unsigned(7 DOWNTO 0);  -- uint8
  SIGNAL raddr_qpsk_tmp                   : unsigned(7 DOWNTO 0);  -- uint8
  SIGNAL PBCHState                        : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL waddr_qpsk_cnt                   : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL raddr_qpsk_cnt                   : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL PBCHState_next                   : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL waddr_qpsk_cnt_next              : unsigned(7 DOWNTO 0);  -- ufix8
  SIGNAL raddr_qpsk_cnt_next              : unsigned(7 DOWNTO 0);  -- ufix8

BEGIN
  PBCH_Controller_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        PBCHState <= to_unsigned(16#0#, 2);
        waddr_qpsk_cnt <= to_unsigned(16#00#, 8);
        raddr_qpsk_cnt <= to_unsigned(16#00#, 8);
      ELSIF enb_1_2_0 = '1' THEN
        PBCHState <= PBCHState_next;
        waddr_qpsk_cnt <= waddr_qpsk_cnt_next;
        raddr_qpsk_cnt <= raddr_qpsk_cnt_next;
      END IF;
    END IF;
  END PROCESS PBCH_Controller_process;

  PBCH_Controller_output : PROCESS (MIB_detected, PBCHState, raddr_qpsk_cnt, repeat_qpsk, restart_MIB, valid_eq,
       waddr_qpsk_cnt)
    VARIABLE add_temp : unsigned(8 DOWNTO 0);
    VARIABLE add_temp_0 : unsigned(8 DOWNTO 0);
    VARIABLE add_temp_1 : unsigned(8 DOWNTO 0);
  BEGIN
    add_temp := to_unsigned(16#000#, 9);
    add_temp_0 := to_unsigned(16#000#, 9);
    add_temp_1 := to_unsigned(16#000#, 9);
    PBCHState_next <= PBCHState;
    waddr_qpsk_cnt_next <= waddr_qpsk_cnt;
    raddr_qpsk_cnt_next <= raddr_qpsk_cnt;
    load_des <= '0';
    enb_des <= '0';
    CASE PBCHState IS
      WHEN "00" =>
        --idle
        IF valid_eq = '1' THEN 
          PBCHState_next <= to_unsigned(16#1#, 2);
          load_des <= '1';
          add_temp_1 := resize(waddr_qpsk_cnt, 9) + to_unsigned(16#001#, 9);
          IF add_temp_1(8) /= '0' THEN 
            waddr_qpsk_cnt_next <= "11111111";
          ELSE 
            waddr_qpsk_cnt_next <= add_temp_1(7 DOWNTO 0);
          END IF;
        END IF;
      WHEN "01" =>
        IF valid_eq = '1' THEN 
          -- assuming all eq data comes before the first valid seq
          IF waddr_qpsk_cnt < to_unsigned(16#EF#, 8) THEN 
            add_temp := resize(waddr_qpsk_cnt, 9) + to_unsigned(16#001#, 9);
            IF add_temp(8) /= '0' THEN 
              waddr_qpsk_cnt_next <= "11111111";
            ELSE 
              waddr_qpsk_cnt_next <= add_temp(7 DOWNTO 0);
            END IF;
          ELSE 
            waddr_qpsk_cnt_next <= to_unsigned(16#00#, 8);
            PBCHState_next <= to_unsigned(16#2#, 2);
          END IF;
        END IF;
      WHEN "10" =>
        -- read from RAM, output Seq
        enb_des <= '1';
        IF raddr_qpsk_cnt < to_unsigned(16#EF#, 8) THEN 
          add_temp_0 := resize(raddr_qpsk_cnt, 9) + to_unsigned(16#001#, 9);
          IF add_temp_0(8) /= '0' THEN 
            raddr_qpsk_cnt_next <= "11111111";
          ELSE 
            raddr_qpsk_cnt_next <= add_temp_0(7 DOWNTO 0);
          END IF;
        ELSE 
          raddr_qpsk_cnt_next <= to_unsigned(16#00#, 8);
          PBCHState_next <= to_unsigned(16#3#, 2);
        END IF;
      WHEN "11" =>
        -- process
        IF repeat_qpsk = '1' THEN 
          PBCHState_next <= to_unsigned(16#2#, 2);
          raddr_qpsk_cnt_next <= to_unsigned(16#00#, 8);
        END IF;
        IF (MIB_detected OR restart_MIB) = '1' THEN 
          PBCHState_next <= to_unsigned(16#0#, 2);
          --reset all
          waddr_qpsk_cnt_next <= to_unsigned(16#00#, 8);
          raddr_qpsk_cnt_next <= to_unsigned(16#00#, 8);
        END IF;
      WHEN OTHERS => 
        NULL;
    END CASE;
    waddr_qpsk_tmp <= waddr_qpsk_cnt;
    raddr_qpsk_tmp <= raddr_qpsk_cnt;
  END PROCESS PBCH_Controller_output;


  waddr_qpsk <= std_logic_vector(waddr_qpsk_tmp);

  raddr_qpsk <= std_logic_vector(raddr_qpsk_tmp);

END rtl;

