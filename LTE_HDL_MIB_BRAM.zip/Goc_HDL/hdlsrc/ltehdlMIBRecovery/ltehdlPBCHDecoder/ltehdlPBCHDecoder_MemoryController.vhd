-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlPBCHDecoder_MemoryController IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        ctrlIn_start                      :   IN    std_logic;
        ctrlIn_end                        :   IN    std_logic;
        ctrlIn_valid                      :   IN    std_logic;
        startReading                      :   IN    std_logic;
        addr                              :   OUT   std_logic_vector(5 DOWNTO 0);  -- ufix6
        writeEn                           :   OUT   std_logic;
        ctrlOut_start                     :   OUT   std_logic;
        ctrlOut_end                       :   OUT   std_logic;
        ctrlOut_valid                     :   OUT   std_logic
        );
END ltehdlPBCHDecoder_MemoryController;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_MemoryController IS

  -- Constants
  CONSTANT nc                             : std_logic_vector(2 DOWNTO 0) := 
    ('1', '0', '0');  -- boolean [3]
  CONSTANT nc_0                           : std_logic_vector(2 DOWNTO 0) := 
    ('1', '1', '0');  -- boolean [3]
  CONSTANT nc_1_1                         : std_logic_vector(2 DOWNTO 0) := 
    ('1', '0', '1');  -- boolean [3]

  -- Signals
  SIGNAL addr_tmp                         : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL regs_state                       : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL regs_addr                        : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL regs_endAddr                     : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL regs_writeEn                     : std_logic;
  SIGNAL regs_ctrlVec                     : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL regs_not_empty                   : std_logic;
  SIGNAL regs_state_next                  : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL regs_addr_next                   : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL regs_endAddr_next                : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL regs_writeEn_next                : std_logic;
  SIGNAL regs_ctrlVec_next                : std_logic_vector(2 DOWNTO 0);  -- boolean [3]
  SIGNAL regs_not_empty_next              : std_logic;

BEGIN
  MemoryController_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        regs_not_empty <= '0';
      ELSIF enb = '1' THEN
        regs_state <= regs_state_next;
        regs_addr <= regs_addr_next;
        regs_endAddr <= regs_endAddr_next;
        regs_writeEn <= regs_writeEn_next;
        regs_ctrlVec <= regs_ctrlVec_next;
        regs_not_empty <= regs_not_empty_next;
      END IF;
    END IF;
  END PROCESS MemoryController_process;

  MemoryController_output : PROCESS (ctrlIn_end, ctrlIn_start, ctrlIn_valid, regs_addr, regs_ctrlVec, regs_endAddr,
       regs_not_empty, regs_state, regs_writeEn, startReading)
    VARIABLE next_state : unsigned(1 DOWNTO 0);
    VARIABLE next_addr : unsigned(5 DOWNTO 0);
    VARIABLE next_endAddr : unsigned(5 DOWNTO 0);
    VARIABLE next_ctrlVec : std_logic_vector(2 DOWNTO 0);
    VARIABLE regs_addr_temp : unsigned(5 DOWNTO 0);
    VARIABLE regs_ctrlVec_temp : std_logic_vector(2 DOWNTO 0);
  BEGIN
    next_state := regs_state;
    regs_addr_temp := regs_addr;
    next_endAddr := regs_endAddr;
    writeEn <= regs_writeEn;
    regs_ctrlVec_temp := regs_ctrlVec;
    regs_not_empty_next <= regs_not_empty;
    IF ( NOT regs_not_empty) = '1' THEN 
      next_state := to_unsigned(16#0#, 2);
      regs_addr_temp := to_unsigned(16#00#, 6);
      next_endAddr := to_unsigned(16#00#, 6);
      writeEn <= '0';
      regs_ctrlVec_temp := (OTHERS => '0');
      regs_not_empty_next <= '1';
    END IF;
    -- Assign outputs
    ctrlOut_start <= regs_ctrlVec_temp(0);
    ctrlOut_end <= regs_ctrlVec_temp(1);
    ctrlOut_valid <= regs_ctrlVec_temp(2);
    -- Update registers
    next_addr := regs_addr_temp;
    IF (ctrlIn_valid AND ctrlIn_start) = '1' THEN 
      next_state := to_unsigned(16#1#, 2);
      next_addr := to_unsigned(16#00#, 6);
      next_endAddr := to_unsigned(16#00#, 6);
      regs_writeEn_next <= '1';
      next_ctrlVec := (OTHERS => '0');
    ELSE 
      CASE next_state IS
        WHEN "01" =>
          IF ctrlIn_valid = '1' THEN 
            IF ctrlIn_end = '1' THEN 
              next_state := to_unsigned(16#2#, 2);
            END IF;
            next_addr := regs_addr_temp + to_unsigned(16#01#, 6);
            regs_writeEn_next <= '1';
          ELSE 
            regs_writeEn_next <= '0';
          END IF;
          next_ctrlVec := (OTHERS => '0');
        WHEN "10" =>
          IF startReading = '1' THEN 
            next_state := to_unsigned(16#3#, 2);
            next_addr := to_unsigned(16#00#, 6);
            next_endAddr := regs_addr_temp;
            regs_writeEn_next <= '0';
            next_ctrlVec := nc_1_1;
          ELSE 
            next_state := to_unsigned(16#2#, 2);
            next_endAddr := regs_addr_temp;
            regs_writeEn_next <= '0';
            next_ctrlVec := (OTHERS => '0');
          END IF;
        WHEN "11" =>
          IF regs_addr_temp >= next_endAddr THEN 
            next_state := to_unsigned(16#0#, 2);
            next_addr := to_unsigned(16#00#, 6);
            next_endAddr := to_unsigned(16#00#, 6);
            regs_writeEn_next <= '0';
            next_ctrlVec := (OTHERS => '0');
          ELSE 
            next_addr := regs_addr_temp + to_unsigned(16#01#, 6);
            regs_writeEn_next <= '0';
            IF next_addr = next_endAddr THEN 
              next_ctrlVec := nc_0;
            ELSE 
              next_ctrlVec := nc;
            END IF;
          END IF;
        WHEN OTHERS => 
          -- includes IDLE state
          next_state := to_unsigned(16#0#, 2);
          next_addr := to_unsigned(16#00#, 6);
          next_endAddr := to_unsigned(16#00#, 6);
          regs_writeEn_next <= '0';
          next_ctrlVec := (OTHERS => '0');
      END CASE;
    END IF;
    regs_ctrlVec_next <= next_ctrlVec;
    addr_tmp <= regs_addr_temp;
    regs_state_next <= next_state;
    regs_addr_next <= next_addr;
    regs_endAddr_next <= next_endAddr;
  END PROCESS MemoryController_output;


  addr <= std_logic_vector(addr_tmp);

END rtl;

