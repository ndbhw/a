-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlPBCHDecoder_Sample_Control_Bus_Creator IS
  PORT( In1                               :   IN    std_logic;
        In2                               :   IN    std_logic;
        In3                               :   IN    std_logic;
        Out1_start                        :   OUT   std_logic;
        Out1_end                          :   OUT   std_logic;
        Out1_valid                        :   OUT   std_logic
        );
END ltehdlPBCHDecoder_Sample_Control_Bus_Creator;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_Sample_Control_Bus_Creator IS

BEGIN
  Out1_start <= In1;

  Out1_end <= In2;

  Out1_valid <= In3;

END rtl;

