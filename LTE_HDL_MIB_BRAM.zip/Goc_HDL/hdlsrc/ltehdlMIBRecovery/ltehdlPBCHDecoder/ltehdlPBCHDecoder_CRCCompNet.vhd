-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_CRCCompNet IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        in1                               :   IN    std_logic;
        in2                               :   IN    std_logic;
        en                                :   IN    std_logic;  -- ufix1
        rst                               :   IN    std_logic;  -- ufix1
        gateErrIn                         :   IN    std_logic;  -- ufix1
        err                               :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
        );
END ltehdlPBCHDecoder_CRCCompNet;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_CRCCompNet IS

  -- Constants
  CONSTANT CRCComp_data                   : vector_of_unsigned5(0 TO 15) := 
    (to_unsigned(16#0F#, 5), to_unsigned(16#0E#, 5), to_unsigned(16#0D#, 5), to_unsigned(16#0C#, 5), to_unsigned(16#0B#, 5), to_unsigned(16#0A#, 5), to_unsigned(16#09#, 5), to_unsigned(16#08#, 5), to_unsigned(16#07#, 5), to_unsigned(16#06#, 5), 
      to_unsigned(16#05#, 5), to_unsigned(16#04#, 5), to_unsigned(16#03#, 5), to_unsigned(16#02#, 5), to_unsigned(16#01#, 5), to_unsigned(16#00#, 5)); -- ufix5 [16]

  -- Functions
  -- HDLCODER_TO_UNSIGNED
  FUNCTION hdlcoder_to_unsigned(arg: boolean; width: integer) RETURN unsigned IS
  BEGIN
    IF arg THEN
      RETURN to_unsigned(1, width);
    ELSE
      RETURN to_unsigned(0, width);
    END IF;
  END FUNCTION;


  -- Signals
  SIGNAL CRCComp_crc_in                   : std_logic_vector(16 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [17]
  SIGNAL CRCComp_crc_rec                  : std_logic_vector(16 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [17]
  SIGNAL CRCComp_crc_in_next              : std_logic_vector(16 DOWNTO 0);  -- ufix1 [17]
  SIGNAL CRCComp_crc_rec_next             : std_logic_vector(16 DOWNTO 0);  -- ufix1 [17]
  SIGNAL err_tmp                          : unsigned(15 DOWNTO 0);  -- ufix16

BEGIN
  -- CRCCompareFunction
  CRCComp_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        CRCComp_crc_in <= CRCComp_crc_in_next;
        CRCComp_crc_rec <= CRCComp_crc_rec_next;
      END IF;
    END IF;
  END PROCESS CRCComp_process;

  CRCComp_output : PROCESS (CRCComp_crc_in, CRCComp_crc_rec, en, gateErrIn, in1, in2, rst)
    VARIABLE concat_reg : vector_of_unsigned16(0 TO 15);
    VARIABLE YY : unsigned(19 DOWNTO 0);
    VARIABLE crc_in_temp : std_logic_vector(16 DOWNTO 0);
    VARIABLE crc_rec_temp : std_logic_vector(16 DOWNTO 0);
  BEGIN
    YY := to_unsigned(16#00000#, 20);
    crc_in_temp := CRCComp_crc_in;
    crc_rec_temp := CRCComp_crc_rec;
    IF rst /= '0' THEN 
      crc_in_temp := (OTHERS => '0');
      crc_rec_temp := (OTHERS => '0');
    ELSIF en /= '0' THEN 
      crc_in_temp(16) := in1;
      crc_in_temp(15 DOWNTO 0) := CRCComp_crc_in(16 DOWNTO 1);
      crc_rec_temp(15 DOWNTO 0) := CRCComp_crc_rec(16 DOWNTO 1);
      crc_rec_temp(16) := in2;
    END IF;

    FOR k_0 IN 0 TO 15 LOOP
      concat_reg(k_0) := resize(hdlcoder_to_unsigned((crc_in_temp(k_0) XOR crc_rec_temp(k_0)) /= '0', 32) sll to_integer(CRCComp_data(k_0)), 16);
    END LOOP;

    IF gateErrIn /= '0' THEN 
      YY := resize(concat_reg(0), 20);

      FOR kk IN 0 TO 14 LOOP
        YY := resize(resize(YY, 21) + resize(concat_reg(kk + 1), 21), 20);
      END LOOP;

      err_tmp <= YY(15 DOWNTO 0);
    ELSE 
      err_tmp <= to_unsigned(16#0000#, 16);
    END IF;
    CRCComp_crc_in_next <= crc_in_temp;
    CRCComp_crc_rec_next <= crc_rec_temp;
  END PROCESS CRCComp_output;


  err <= std_logic_vector(err_tmp);

END rtl;

