-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlPBCHDecoder;

ENTITY ltehdlPBCHDecoder_CRC_Decoder IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        in0                               :   IN    std_logic;
        in1_start                         :   IN    std_logic;
        in1_end                           :   IN    std_logic;
        in1_valid                         :   IN    std_logic;
        out0                              :   OUT   std_logic;
        out1_start                        :   OUT   std_logic;
        out1_end                          :   OUT   std_logic;
        out1_valid                        :   OUT   std_logic;
        out2                              :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
        );
END ltehdlPBCHDecoder_CRC_Decoder;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_CRC_Decoder IS

  -- Component Declarations
  COMPONENT ltehdlPBCHDecoder_CRCGenerator
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn                          :   IN    std_logic;
          startIn                         :   IN    std_logic;
          endIn                           :   IN    std_logic;
          validIn                         :   IN    std_logic;
          dataOut                         :   OUT   std_logic;
          startOut                        :   OUT   std_logic;
          endOut                          :   OUT   std_logic;
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_endInNet
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          endin                           :   IN    std_logic;
          out_rsvd                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHDecoder_CRCCompNet
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          in1                             :   IN    std_logic;
          in2                             :   IN    std_logic;
          en                              :   IN    std_logic;
          rst                             :   IN    std_logic;
          gateErrIn                       :   IN    std_logic;
          err                             :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlPBCHDecoder_CRCGenerator
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_CRCGenerator(rtl);

  FOR ALL : ltehdlPBCHDecoder_endInNet
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_endInNet(rtl);

  FOR ALL : ltehdlPBCHDecoder_CRCCompNet
    USE ENTITY work_ltehdlPBCHDecoder.ltehdlPBCHDecoder_CRCCompNet(rtl);

  -- Signals
  SIGNAL dataIn                           : std_logic;
  SIGNAL validin_ff_1                     : std_logic := '0';
  SIGNAL switch_compare_1                 : std_logic;
  SIGNAL datain_ff_1                      : std_logic := '0';
  SIGNAL dataInReg_reg_rsvd               : std_logic_vector(15 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [16]
  SIGNAL datain_reg                       : std_logic;
  SIGNAL datain_crcgen                    : std_logic;
  SIGNAL startin_ff_1                     : std_logic := '0';
  SIGNAL startInReg_reg_rsvd              : std_logic_vector(15 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [16]
  SIGNAL startin_reg                      : std_logic;
  SIGNAL startin_crcgen                   : std_logic;
  SIGNAL endin_ff_1                       : std_logic := '0';
  SIGNAL dataoutgen                       : std_logic;
  SIGNAL startoutgen                      : std_logic;
  SIGNAL endoutgen                        : std_logic;
  SIGNAL validoutgen                      : std_logic;
  SIGNAL startOutReg_reg_rsvd             : std_logic_vector(15 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [16]
  SIGNAL startout_del                     : std_logic;
  SIGNAL startoutgen_gated                : std_logic;
  SIGNAL endOutdelay                      : std_logic := '0';
  SIGNAL endOut_n                         : std_logic;
  SIGNAL endOut_nxt_state                 : std_logic;
  SIGNAL endOut_state                     : std_logic := '0';
  SIGNAL endgate_sr                       : std_logic;
  SIGNAL local_rst_srcell_n               : std_logic;
  SIGNAL validOutTemp                     : std_logic;
  SIGNAL sel_dataoutmux                   : std_logic;
  SIGNAL switch_compare_1_1               : std_logic;
  SIGNAL dataOutReg_reg_rsvd              : std_logic_vector(15 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [16]
  SIGNAL dataoutgen_del                   : std_logic;
  SIGNAL dataoutgen_gated                 : std_logic;
  SIGNAL dataOut_2del_reg_rsvd            : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [2]
  SIGNAL dataOut                          : std_logic;
  SIGNAL startOut_2del_reg_rsvd           : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [2]
  SIGNAL startOut                         : std_logic;
  SIGNAL endOut                           : std_logic;
  SIGNAL endout_ff1                       : std_logic := '0';
  SIGNAL endOut_1                         : std_logic := '0';
  SIGNAL validOut_2del_reg_rsvd           : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [2]
  SIGNAL validOut                         : std_logic;
  SIGNAL endin_ffdel                      : std_logic;
  SIGNAL enCRCBuf                         : std_logic;
  SIGNAL switch_compare_1_2               : std_logic;
  SIGNAL crcReg_reg_rsvd                  : std_logic_vector(15 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [16]
  SIGNAL crc_reg                          : std_logic;
  SIGNAL crc_reg_gated                    : std_logic;
  SIGNAL crcRegDEPTH2_reg_rsvd            : std_logic_vector(17 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [18]
  SIGNAL crc_to_mask                      : std_logic;
  SIGNAL endout_large                     : std_logic := '0';
  SIGNAL endout_orlarge                   : std_logic;
  SIGNAL enable_maskgen                   : std_logic;
  SIGNAL errout_word                      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL errout_word_unsigned             : unsigned(15 DOWNTO 0);  -- ufix16
  SIGNAL err                              : unsigned(15 DOWNTO 0) := to_unsigned(16#0000#, 16);  -- uint16

BEGIN
  -- HDL CRC Generator
  UHDLCRCGen_inst : ltehdlPBCHDecoder_CRCGenerator
    PORT MAP( clk => clk,
              enb => enb,
              dataIn => datain_crcgen,
              startIn => startin_crcgen,
              endIn => endin_ff_1,
              validIn => validin_ff_1,
              dataOut => dataoutgen,
              startOut => startoutgen,
              endOut => endoutgen,
              validOut => validoutgen
              );

  UendInEntity : ltehdlPBCHDecoder_endInNet
    PORT MAP( clk => clk,
              enb => enb,
              endin => endin_ff_1,
              out_rsvd => endin_ffdel
              );

  UErrPortEntity : ltehdlPBCHDecoder_CRCCompNet
    PORT MAP( clk => clk,
              enb => enb,
              in1 => dataoutgen,
              in2 => crc_to_mask,
              en => enable_maskgen,
              rst => startin_ff_1,
              gateErrIn => endout_ff1,
              err => errout_word  -- ufix16
              );

  dataIn <= in0;

  validin_ff_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        validin_ff_1 <= in1_valid;
      END IF;
    END IF;
  END PROCESS validin_ff_process;


  
  switch_compare_1 <= '1' WHEN validin_ff_1 > '0' ELSE
      '0';

  datain_ff_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        datain_ff_1 <= dataIn;
      END IF;
    END IF;
  END PROCESS datain_ff_process;


  dataInReg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND validin_ff_1 = '1' THEN
        dataInReg_reg_rsvd(0) <= datain_ff_1;
        dataInReg_reg_rsvd(15 DOWNTO 1) <= dataInReg_reg_rsvd(14 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS dataInReg_process;

  datain_reg <= dataInReg_reg_rsvd(15);

  
  datain_crcgen <= '0' WHEN switch_compare_1 = '0' ELSE
      datain_reg;

  startin_ff_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        startin_ff_1 <= in1_start;
      END IF;
    END IF;
  END PROCESS startin_ff_process;


  startInReg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND validin_ff_1 = '1' THEN
        startInReg_reg_rsvd(0) <= startin_ff_1;
        startInReg_reg_rsvd(15 DOWNTO 1) <= startInReg_reg_rsvd(14 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS startInReg_process;

  startin_reg <= startInReg_reg_rsvd(15);

  startin_crcgen <= validin_ff_1 AND startin_reg;

  endin_ff_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        endin_ff_1 <= in1_end;
      END IF;
    END IF;
  END PROCESS endin_ff_process;


  startOutReg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND validoutgen = '1' THEN
        startOutReg_reg_rsvd(0) <= startoutgen;
        startOutReg_reg_rsvd(15 DOWNTO 1) <= startOutReg_reg_rsvd(14 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS startOutReg_process;

  startout_del <= startOutReg_reg_rsvd(15);

  startoutgen_gated <= startout_del AND validoutgen;

  endRegSR_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        endOutdelay <= endoutgen;
      END IF;
    END IF;
  END PROCESS endRegSR_process;


  endOut_n <=  NOT endOutdelay;

  SRcell_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        IF startoutgen = '1' THEN
          endOut_state <= '0';
        ELSE 
          endOut_state <= endOut_nxt_state;
        END IF;
      END IF;
    END IF;
  END PROCESS SRcell_process;


  endgate_sr <= endOut_n AND endOut_state;

  endOut_nxt_state <= startoutgen_gated OR endgate_sr;

  local_rst_srcell_n <=  NOT startoutgen;

  validOutTemp <= local_rst_srcell_n AND (endOut_nxt_state AND validoutgen);

  sel_dataoutmux <= validOutTemp AND validoutgen;

  
  switch_compare_1_1 <= '1' WHEN sel_dataoutmux > '0' ELSE
      '0';

  dataOutReg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND validoutgen = '1' THEN
        dataOutReg_reg_rsvd(0) <= dataoutgen;
        dataOutReg_reg_rsvd(15 DOWNTO 1) <= dataOutReg_reg_rsvd(14 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS dataOutReg_process;

  dataoutgen_del <= dataOutReg_reg_rsvd(15);

  
  dataoutgen_gated <= '0' WHEN switch_compare_1_1 = '0' ELSE
      dataoutgen_del;

  dataOut_2del_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        dataOut_2del_reg_rsvd(0) <= dataoutgen_gated;
        dataOut_2del_reg_rsvd(1) <= dataOut_2del_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS dataOut_2del_process;

  dataOut <= dataOut_2del_reg_rsvd(1);

  startOut_2del_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        startOut_2del_reg_rsvd(0) <= startoutgen_gated;
        startOut_2del_reg_rsvd(1) <= startOut_2del_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS startOut_2del_process;

  startOut <= startOut_2del_reg_rsvd(1);

  out1_start <= startOut;

  endOut <= validOutTemp AND endoutgen;

  endOut_1del1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        endout_ff1 <= endOut;
      END IF;
    END IF;
  END PROCESS endOut_1del1_process;


  endOut_1del2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        endOut_1 <= endout_ff1;
      END IF;
    END IF;
  END PROCESS endOut_1del2_process;


  out1_end <= endOut_1;

  validOut_2del_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        validOut_2del_reg_rsvd(0) <= validOutTemp;
        validOut_2del_reg_rsvd(1) <= validOut_2del_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS validOut_2del_process;

  validOut <= validOut_2del_reg_rsvd(1);

  out1_valid <= validOut;

  enCRCBuf <= endin_ffdel OR validin_ff_1;

  
  switch_compare_1_2 <= '1' WHEN enCRCBuf > '0' ELSE
      '0';

  crcReg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND enCRCBuf = '1' THEN
        crcReg_reg_rsvd(0) <= datain_ff_1;
        crcReg_reg_rsvd(15 DOWNTO 1) <= crcReg_reg_rsvd(14 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS crcReg_process;

  crc_reg <= crcReg_reg_rsvd(15);

  
  crc_reg_gated <= '0' WHEN switch_compare_1_2 = '0' ELSE
      crc_reg;

  crcRegDEPTH2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        crcRegDEPTH2_reg_rsvd(0) <= crc_reg_gated;
        crcRegDEPTH2_reg_rsvd(17 DOWNTO 1) <= crcRegDEPTH2_reg_rsvd(16 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS crcRegDEPTH2_process;

  crc_to_mask <= crcRegDEPTH2_reg_rsvd(17);

  endout_largeFF_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        endout_large <= endOut;
      END IF;
    END IF;
  END PROCESS endout_largeFF_process;


  endout_orlarge <= endout_large OR endOut;

  enable_maskgen <= endout_orlarge OR validoutgen;

  errout_word_unsigned <= unsigned(errout_word);

  errOut_1del_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        err <= errout_word_unsigned;
      END IF;
    END IF;
  END PROCESS errOut_1del_process;


  out2 <= std_logic_vector(err);

  out0 <= dataOut;

END rtl;

