-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.ALL;

ENTITY ltehdlPBCHDecoder_Maximum_Average_Absolute_Value IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_0                          :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
        dataIn_1                          :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
        dataIn_2                          :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
        ctrlIn_start                      :   IN    std_logic;
        ctrlIn_end                        :   IN    std_logic;
        ctrlIn_valid                      :   IN    std_logic;
        maxOut                            :   OUT   std_logic_vector(18 DOWNTO 0);  -- ufix19_En17
        maxValid                          :   OUT   std_logic
        );
END ltehdlPBCHDecoder_Maximum_Average_Absolute_Value;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_Maximum_Average_Absolute_Value IS

  -- Signals
  SIGNAL dataIn                           : vector_of_signed20(0 TO 2);  -- sfix20_En17 [3]
  SIGNAL maxOut_tmp                       : unsigned(18 DOWNTO 0);  -- ufix19_En17
  SIGNAL regs_absVals                     : vector_of_unsigned19(0 TO 2);  -- ufix19_En17 [3]
  SIGNAL regs_sumAbs                      : unsigned(20 DOWNTO 0);  -- ufix21_En17
  SIGNAL regs_averageFull                 : unsigned(37 DOWNTO 0);  -- ufix38_En35
  SIGNAL regs_average                     : unsigned(18 DOWNTO 0);  -- ufix19_En17
  SIGNAL regs_maxAverage                  : unsigned(18 DOWNTO 0);  -- ufix19_En17
  SIGNAL regs_startPipe                   : std_logic_vector(4 DOWNTO 0);  -- boolean [5]
  SIGNAL regs_validPipe                   : std_logic_vector(4 DOWNTO 0);  -- boolean [5]
  SIGNAL regs_endPipe                     : std_logic_vector(4 DOWNTO 0);  -- boolean [5]
  SIGNAL regs_not_empty                   : std_logic;
  SIGNAL regs_absVals_next                : vector_of_unsigned19(0 TO 2);  -- ufix19_En17 [3]
  SIGNAL regs_sumAbs_next                 : unsigned(20 DOWNTO 0);  -- ufix21_En17
  SIGNAL regs_averageFull_next            : unsigned(37 DOWNTO 0);  -- ufix38_En35
  SIGNAL regs_average_next                : unsigned(18 DOWNTO 0);  -- ufix19_En17
  SIGNAL regs_maxAverage_next             : unsigned(18 DOWNTO 0);  -- ufix19_En17
  SIGNAL regs_startPipe_next              : std_logic_vector(4 DOWNTO 0);  -- boolean [5]
  SIGNAL regs_validPipe_next              : std_logic_vector(4 DOWNTO 0);  -- boolean [5]
  SIGNAL regs_endPipe_next                : std_logic_vector(4 DOWNTO 0);  -- boolean [5]
  SIGNAL regs_not_empty_next              : std_logic;

BEGIN
  dataIn(0) <= signed(dataIn_0);
  dataIn(1) <= signed(dataIn_1);
  dataIn(2) <= signed(dataIn_2);

  Maximum_Average_Absolute_Value_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        regs_not_empty <= '0';
      ELSIF enb = '1' THEN
        regs_absVals <= regs_absVals_next;
        regs_sumAbs <= regs_sumAbs_next;
        regs_averageFull <= regs_averageFull_next;
        regs_average <= regs_average_next;
        regs_maxAverage <= regs_maxAverage_next;
        regs_startPipe <= regs_startPipe_next;
        regs_validPipe <= regs_validPipe_next;
        regs_endPipe <= regs_endPipe_next;
        regs_not_empty <= regs_not_empty_next;
      END IF;
    END IF;
  END PROCESS Maximum_Average_Absolute_Value_process;

  Maximum_Average_Absolute_Value_output : PROCESS (ctrlIn_end, ctrlIn_start, ctrlIn_valid, dataIn, regs_absVals, regs_average,
       regs_averageFull, regs_endPipe, regs_maxAverage, regs_not_empty,
       regs_startPipe, regs_sumAbs, regs_validPipe)
    VARIABLE next_absVals : vector_of_unsigned19(0 TO 2);
    VARIABLE next_sumAbs : unsigned(20 DOWNTO 0);
    VARIABLE next_startPipe : std_logic_vector(4 DOWNTO 0);
    VARIABLE next_validPipe : std_logic_vector(4 DOWNTO 0);
    VARIABLE next_endPipe : std_logic_vector(4 DOWNTO 0);
    VARIABLE t0_startPipe : std_logic_vector(4 DOWNTO 0);
    VARIABLE t0_validPipe : std_logic_vector(4 DOWNTO 0);
    VARIABLE t0_endPipe : std_logic_vector(4 DOWNTO 0);
    VARIABLE regs_absVals_temp : vector_of_unsigned19(0 TO 2);
    VARIABLE regs_sumAbs_temp : unsigned(20 DOWNTO 0);
    VARIABLE regs_averageFull_temp : unsigned(37 DOWNTO 0);
    VARIABLE regs_average_temp : unsigned(18 DOWNTO 0);
    VARIABLE regs_maxAverage_temp : unsigned(18 DOWNTO 0);
    VARIABLE regs_startPipe_temp : std_logic_vector(4 DOWNTO 0);
    VARIABLE regs_validPipe_temp : std_logic_vector(4 DOWNTO 0);
    VARIABLE regs_endPipe_temp : std_logic_vector(4 DOWNTO 0);
    VARIABLE yy : signed(19 DOWNTO 0);
    VARIABLE cast : signed(20 DOWNTO 0);
    VARIABLE add_temp : unsigned(21 DOWNTO 0);
  BEGIN
    yy := to_signed(16#00000#, 20);
    cast := to_signed(16#000000#, 21);
    add_temp := to_unsigned(16#000000#, 22);
    regs_absVals_temp := regs_absVals;
    regs_sumAbs_temp := regs_sumAbs;
    regs_averageFull_temp := regs_averageFull;
    regs_average_temp := regs_average;
    regs_maxAverage_temp := regs_maxAverage;
    regs_startPipe_temp := regs_startPipe;
    regs_validPipe_temp := regs_validPipe;
    regs_endPipe_temp := regs_endPipe;
    regs_not_empty_next <= regs_not_empty;
    -- Calculate the average absolute value of each 3 element input vector,
    -- and then compute the maximum result within the incoming packet.
    -- The start, end and valid samples of the packet are indicated by the
    -- corresponding elements of the ctrlIn signal.
    IF ( NOT regs_not_empty) = '1' THEN 
      t0_startPipe := (OTHERS => '0');
      t0_validPipe := (OTHERS => '0');
      t0_endPipe := (OTHERS => '0');
      regs_absVals_temp := (OTHERS => to_unsigned(16#00000#, 19));
      regs_sumAbs_temp := to_unsigned(16#000000#, 21);
      regs_averageFull_temp := to_unsigned(0, 38);
      regs_average_temp := to_unsigned(16#00000#, 19);
      regs_maxAverage_temp := to_unsigned(16#00000#, 19);
      regs_startPipe_temp := t0_startPipe;
      regs_validPipe_temp := t0_validPipe;
      regs_endPipe_temp := t0_endPipe;
      regs_not_empty_next <= '1';
    END IF;
    --------------------------------------------------------------------------
    -- Assign outputs
    --------------------------------------------------------------------------
    maxValid <= regs_endPipe_temp(4);
    --------------------------------------------------------------------------
    -- Compute next register values.
    --------------------------------------------------------------------------
    regs_maxAverage_next <= regs_maxAverage_temp;
    -- Udate control logic pipelines
    next_startPipe(0) := ctrlIn_start;
    next_validPipe(0) := ctrlIn_valid;
    next_endPipe(0) := ctrlIn_end;
    next_startPipe(4 DOWNTO 1) := regs_startPipe_temp(3 DOWNTO 0);
    next_validPipe(4 DOWNTO 1) := regs_validPipe_temp(3 DOWNTO 0);
    next_endPipe(4 DOWNTO 1) := regs_endPipe_temp(3 DOWNTO 0);

    FOR kk IN 0 TO 2 LOOP
      IF dataIn(kk) < to_signed(16#00000#, 20) THEN 
        cast :=  - (resize(dataIn(kk), 21));
        IF (cast(20) = '0') AND (cast(19) /= '0') THEN 
          yy := X"7FFFF";
        ELSIF (cast(20) = '1') AND (cast(19) /= '1') THEN 
          yy := X"80000";
        ELSE 
          yy := cast(19 DOWNTO 0);
        END IF;
      ELSE 
        yy := dataIn(kk);
      END IF;
      next_absVals(kk) := unsigned(yy(18 DOWNTO 0));
    END LOOP;

    next_sumAbs := resize(regs_absVals_temp(0), 21);

    FOR k_0 IN 0 TO 1 LOOP
      add_temp := (resize(next_sumAbs, 22)) + (resize(regs_absVals_temp(k_0 + 1), 22));
      next_sumAbs := add_temp(20 DOWNTO 0);
    END LOOP;

    regs_averageFull_next <= regs_sumAbs_temp * to_unsigned(16#15555#, 17);
    IF (regs_averageFull_temp(37) /= '0') OR (regs_averageFull_temp(36 DOWNTO 18) = "1111111111111111111") THEN 
      regs_average_next <= "1111111111111111111";
    ELSE 
      regs_average_next <= regs_averageFull_temp(36 DOWNTO 18) + ('0' & regs_averageFull_temp(17));
    END IF;
    IF regs_validPipe_temp(3) = '1' THEN 
      IF regs_startPipe_temp(3) = '1' THEN 
        regs_maxAverage_next <= regs_average_temp;
      ELSIF regs_average_temp > regs_maxAverage_temp THEN 
        regs_maxAverage_next <= regs_average_temp;
      END IF;
    END IF;
    --------------------------------------------------------------------------
    -- Write new values to registers.
    --------------------------------------------------------------------------
    regs_absVals_next <= next_absVals;
    regs_startPipe_next <= next_startPipe;
    regs_validPipe_next <= next_validPipe;
    regs_endPipe_next <= next_endPipe;
    maxOut_tmp <= regs_maxAverage_temp;
    regs_sumAbs_next <= next_sumAbs;
  END PROCESS Maximum_Average_Absolute_Value_output;


  maxOut <= std_logic_vector(maxOut_tmp);

END rtl;

