-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlPBCHDecoder_SetFF IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        D_D                               :   IN    std_logic;
        Q_Q                               :   OUT   std_logic
        );
END ltehdlPBCHDecoder_SetFF;


ARCHITECTURE rtl OF ltehdlPBCHDecoder_SetFF IS

  -- Signals
  SIGNAL Logical_Operator6_out1           : std_logic;
  SIGNAL Delay5_out1                      : std_logic := '0';

BEGIN
  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay5_out1 <= Logical_Operator6_out1;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  Logical_Operator6_out1 <= D_D OR Delay5_out1;

  Q_Q <= Logical_Operator6_out1;

END rtl;

