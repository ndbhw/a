-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlPBCHIndexing_ltehdlPBCHIndexing_pac.ALL;

ENTITY ltehdlPBCHIndexing_mod_12_6 IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        addr_in                           :   IN    std_logic_vector(15 DOWNTO 0);  -- uint16
        reminder                          :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        quotient                          :   OUT   std_logic_vector(10 DOWNTO 0)  -- ufix11
        );
END ltehdlPBCHIndexing_mod_12_6;


ARCHITECTURE rtl OF ltehdlPBCHIndexing_mod_12_6 IS

  -- Signals
  SIGNAL addr_in_unsigned                 : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Delay_rsvd_reg_rsvd              : vector_of_unsigned16(0 TO 3) := (OTHERS => to_unsigned(16#0000#, 16));  -- ufix16 [4]
  SIGNAL Delay_out1                       : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Product1_mul_temp                : signed(32 DOWNTO 0);  -- sfix33_En15
  SIGNAL Product1_cast                    : signed(31 DOWNTO 0);  -- sfix32_En15
  SIGNAL Product1_out1                    : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Delay4_reg_rsvd                  : vector_of_unsigned16(0 TO 1) := (OTHERS => to_unsigned(16#0000#, 16));  -- ufix16 [2]
  SIGNAL Delay4_out1                      : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Product2_out1                    : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Delay6_reg_rsvd                  : vector_of_unsigned16(0 TO 1) := (OTHERS => to_unsigned(16#0000#, 16));  -- ufix16 [2]
  SIGNAL Delay6_out1                      : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Subtract_out1                    : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Delay10_out1                     : unsigned(15 DOWNTO 0) := to_unsigned(16#0000#, 16);  -- uint16
  SIGNAL switch_compare_1                 : std_logic;
  SIGNAL Delay10_out1_dtc                 : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL Switch_out1                      : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL switch_compare_1_1               : std_logic;
  SIGNAL Delay2_reg_rsvd                  : vector_of_unsigned16(0 TO 2) := (OTHERS => to_unsigned(16#0000#, 16));  -- ufix16 [3]
  SIGNAL Delay2_out1                      : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Delay2_out1_dtc                  : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL Delay13_reg_rsvd                 : vector_of_unsigned16(0 TO 1) := (OTHERS => to_unsigned(16#0000#, 16));  -- ufix16 [2]
  SIGNAL Delay13_out1                     : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Add_out1                         : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL Delay7_out1                      : unsigned(10 DOWNTO 0) := to_unsigned(16#000#, 11);  -- ufix11
  SIGNAL Switch1_out1                     : unsigned(10 DOWNTO 0);  -- ufix11

BEGIN
  addr_in_unsigned <= unsigned(addr_in);

  Delay_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay_rsvd_reg_rsvd(0) <= addr_in_unsigned;
        Delay_rsvd_reg_rsvd(1 TO 3) <= Delay_rsvd_reg_rsvd(0 TO 2);
      END IF;
    END IF;
  END PROCESS Delay_rsvd_process;

  Delay_out1 <= Delay_rsvd_reg_rsvd(3);

  Product1_mul_temp <= signed(resize(addr_in_unsigned, 17)) * to_signed(16#01C7#, 16);
  Product1_cast <= Product1_mul_temp(31 DOWNTO 0);
  Product1_out1 <= unsigned(Product1_cast(30 DOWNTO 15));

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay4_reg_rsvd(0) <= Product1_out1;
        Delay4_reg_rsvd(1) <= Delay4_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay4_process;

  Delay4_out1 <= Delay4_reg_rsvd(1);

  Product2_out1 <= resize(Delay4_out1 * to_unsigned(16#0048#, 16), 16);

  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay6_reg_rsvd(0) <= Product2_out1;
        Delay6_reg_rsvd(1) <= Delay6_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay6_process;

  Delay6_out1 <= Delay6_reg_rsvd(1);

  Subtract_out1 <= Delay_out1 - Delay6_out1;

  Delay10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay10_out1 <= Subtract_out1;
      END IF;
    END IF;
  END PROCESS Delay10_process;


  
  switch_compare_1 <= '1' WHEN Delay10_out1 > to_unsigned(16#0047#, 16) ELSE
      '0';

  Delay10_out1_dtc <= Delay10_out1(10 DOWNTO 0);

  
  Switch_out1 <= Delay10_out1_dtc WHEN switch_compare_1 = '0' ELSE
      to_unsigned(16#000#, 11);

  reminder <= std_logic_vector(Switch_out1);

  
  switch_compare_1_1 <= '1' WHEN Delay10_out1 > to_unsigned(16#0047#, 16) ELSE
      '0';

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay2_reg_rsvd(0) <= Delay4_out1;
        Delay2_reg_rsvd(1 TO 2) <= Delay2_reg_rsvd(0 TO 1);
      END IF;
    END IF;
  END PROCESS Delay2_process;

  Delay2_out1 <= Delay2_reg_rsvd(2);

  Delay2_out1_dtc <= Delay2_out1(10 DOWNTO 0);

  Delay13_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay13_reg_rsvd(0) <= Delay4_out1;
        Delay13_reg_rsvd(1) <= Delay13_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay13_process;

  Delay13_out1 <= Delay13_reg_rsvd(1);

  Add_out1 <= resize(Delay13_out1, 11) + to_unsigned(16#001#, 11);

  Delay7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay7_out1 <= Add_out1;
      END IF;
    END IF;
  END PROCESS Delay7_process;


  
  Switch1_out1 <= Delay2_out1_dtc WHEN switch_compare_1_1 = '0' ELSE
      Delay7_out1;

  quotient <= std_logic_vector(Switch1_out1);

END rtl;

