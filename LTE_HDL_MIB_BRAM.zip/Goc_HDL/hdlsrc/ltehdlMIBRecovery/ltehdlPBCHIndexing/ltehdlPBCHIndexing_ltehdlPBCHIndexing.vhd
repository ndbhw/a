-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlPBCHIndexing;

ENTITY ltehdlPBCHIndexing_ltehdlPBCHIndexing IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        cellID                            :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        start                             :   IN    std_logic;
        addr_rd_addr                      :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
        addr_rd_bank                      :   OUT   std_logic_vector(3 DOWNTO 0);  -- ufix4
        addr_rd_en                        :   OUT   std_logic
        );
END ltehdlPBCHIndexing_ltehdlPBCHIndexing;


ARCHITECTURE rtl OF ltehdlPBCHIndexing_ltehdlPBCHIndexing IS

  -- Component Declarations
  COMPONENT ltehdlPBCHIndexing_PBCHIndGen
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          NCellID                         :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          start                           :   IN    std_logic;
          idx_data                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- uint16
          idx_data_valid                  :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHIndexing_mod_12_6
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          addr_in                         :   IN    std_logic_vector(15 DOWNTO 0);  -- uint16
          reminder                        :   OUT   std_logic_vector(10 DOWNTO 0);  -- ufix11
          quotient                        :   OUT   std_logic_vector(10 DOWNTO 0)  -- ufix11
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlPBCHIndexing_PBCHIndGen
    USE ENTITY work_ltehdlPBCHIndexing.ltehdlPBCHIndexing_PBCHIndGen(rtl);

  FOR ALL : ltehdlPBCHIndexing_mod_12_6
    USE ENTITY work_ltehdlPBCHIndexing.ltehdlPBCHIndexing_mod_12_6(rtl);

  -- Signals
  SIGNAL PBCHIndGen_idx_data              : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL PBCHIndGen_idx_data_valid        : std_logic;
  SIGNAL rd_addr                          : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL rd_bank                          : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL rd_bank_unsigned                 : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL rd_bank_1                        : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL Delay_rsvd_reg_rsvd              : std_logic_vector(4 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [5]
  SIGNAL rd_en                            : std_logic;

BEGIN
  UPBCHIndGen : ltehdlPBCHIndexing_PBCHIndGen
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              NCellID => cellID,  -- ufix9
              start => start,
              idx_data => PBCHIndGen_idx_data,  -- uint16
              idx_data_valid => PBCHIndGen_idx_data_valid
              );

  Umod_12_6 : ltehdlPBCHIndexing_mod_12_6
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              addr_in => PBCHIndGen_idx_data,  -- uint16
              reminder => rd_addr,  -- ufix11
              quotient => rd_bank  -- ufix11
              );

  rd_bank_unsigned <= unsigned(rd_bank);

  rd_bank_1 <= rd_bank_unsigned(3 DOWNTO 0);

  addr_rd_bank <= std_logic_vector(rd_bank_1);

  Delay_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay_rsvd_reg_rsvd(0) <= PBCHIndGen_idx_data_valid;
        Delay_rsvd_reg_rsvd(4 DOWNTO 1) <= Delay_rsvd_reg_rsvd(3 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS Delay_rsvd_process;

  rd_en <= Delay_rsvd_reg_rsvd(4);

  addr_rd_addr <= rd_addr;

  addr_rd_en <= rd_en;

END rtl;

