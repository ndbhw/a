add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G1_5/hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_ltehdlPBCHIndexing_pac.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G1_5/hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_Enabled_Subsystem.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G1_5/hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_enbGen.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G1_5/hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_mod3HDL1.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G1_5/hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_PBCHIndGen.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G1_5/hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_mod_12_6.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G1_5/hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_ltehdlPBCHIndexing.vhd
