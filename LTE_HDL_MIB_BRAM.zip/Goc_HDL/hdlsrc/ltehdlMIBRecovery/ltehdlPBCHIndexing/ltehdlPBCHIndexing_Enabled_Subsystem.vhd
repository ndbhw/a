-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlPBCHIndexing_Enabled_Subsystem IS
  PORT( idxdata                           :   IN    std_logic_vector(15 DOWNTO 0);  -- uint16
        seI                               :   IN    std_logic;
        adjustIdx                         :   OUT   std_logic_vector(15 DOWNTO 0)  -- uint16
        );
END ltehdlPBCHIndexing_Enabled_Subsystem;


ARCHITECTURE rtl OF ltehdlPBCHIndexing_Enabled_Subsystem IS

  -- Signals
  SIGNAL idxdata_unsigned                 : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Add_out1                         : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Multiport_Switch_out1            : unsigned(15 DOWNTO 0);  -- uint16

BEGIN
  idxdata_unsigned <= unsigned(idxdata);

  Add_out1 <= idxdata_unsigned - to_unsigned(16#0001#, 16);

  
  Multiport_Switch_out1 <= idxdata_unsigned WHEN seI = '0' ELSE
      Add_out1;

  adjustIdx <= std_logic_vector(Multiport_Switch_out1);

END rtl;

