-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlPBCHIndexing;
USE work.ltehdlPBCHIndexing_ltehdlPBCHIndexing_pac.ALL;

ENTITY ltehdlPBCHIndexing_PBCHIndGen IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        NCellID                           :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        start                             :   IN    std_logic;
        idx_data                          :   OUT   std_logic_vector(15 DOWNTO 0);  -- uint16
        idx_data_valid                    :   OUT   std_logic
        );
END ltehdlPBCHIndexing_PBCHIndGen;


ARCHITECTURE rtl OF ltehdlPBCHIndexing_PBCHIndGen IS

  -- Component Declarations
  COMPONENT ltehdlPBCHIndexing_mod3HDL1
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          addr_in                         :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          reminder                        :   OUT   std_logic_vector(15 DOWNTO 0)  -- uint16
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHIndexing_enbGen
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          start                           :   IN    std_logic;
          enb_1                           :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlPBCHIndexing_Enabled_Subsystem
    PORT( idxdata                         :   IN    std_logic_vector(15 DOWNTO 0);  -- uint16
          seI                             :   IN    std_logic;
          adjustIdx                       :   OUT   std_logic_vector(15 DOWNTO 0)  -- uint16
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlPBCHIndexing_mod3HDL1
    USE ENTITY work_ltehdlPBCHIndexing.ltehdlPBCHIndexing_mod3HDL1(rtl);

  FOR ALL : ltehdlPBCHIndexing_enbGen
    USE ENTITY work_ltehdlPBCHIndexing.ltehdlPBCHIndexing_enbGen(rtl);

  FOR ALL : ltehdlPBCHIndexing_Enabled_Subsystem
    USE ENTITY work_ltehdlPBCHIndexing.ltehdlPBCHIndexing_Enabled_Subsystem(rtl);

  -- Constants
  CONSTANT Direct_Lookup_Table_n_D_data   : vector_of_unsigned16(0 TO 239) := 
    (to_unsigned(16#01F9#, 16), to_unsigned(16#01FA#, 16), to_unsigned(16#01FC#, 16), to_unsigned(16#01FD#, 16), to_unsigned(16#01FF#, 16), to_unsigned(16#0200#, 16), to_unsigned(16#0202#, 16), to_unsigned(16#0203#, 16), to_unsigned(16#0205#, 16), 
      to_unsigned(16#0206#, 16), to_unsigned(16#0208#, 16), to_unsigned(16#0209#, 16), to_unsigned(16#020B#, 16), to_unsigned(16#020C#, 16), to_unsigned(16#020E#, 16), to_unsigned(16#020F#, 16), to_unsigned(16#0211#, 16), to_unsigned(16#0212#, 16), 
      to_unsigned(16#0214#, 16), to_unsigned(16#0215#, 16), to_unsigned(16#0217#, 16), to_unsigned(16#0218#, 16), to_unsigned(16#021A#, 16), to_unsigned(16#021B#, 16), to_unsigned(16#021D#, 16), to_unsigned(16#021E#, 16), to_unsigned(16#0220#, 16), 
      to_unsigned(16#0221#, 16), to_unsigned(16#0223#, 16), to_unsigned(16#0224#, 16), to_unsigned(16#0226#, 16), to_unsigned(16#0227#, 16), to_unsigned(16#0229#, 16), to_unsigned(16#022A#, 16), to_unsigned(16#022C#, 16), to_unsigned(16#022D#, 16), 
      to_unsigned(16#022F#, 16), to_unsigned(16#0230#, 16), to_unsigned(16#0232#, 16), to_unsigned(16#0233#, 16), to_unsigned(16#0235#, 16), to_unsigned(16#0236#, 16), to_unsigned(16#0238#, 16), to_unsigned(16#0239#, 16), to_unsigned(16#023B#, 16), 
      to_unsigned(16#023C#, 16), to_unsigned(16#023E#, 16), to_unsigned(16#023F#, 16), to_unsigned(16#0241#, 16), to_unsigned(16#0242#, 16), to_unsigned(16#0244#, 16), to_unsigned(16#0245#, 16), to_unsigned(16#0247#, 16), to_unsigned(16#0248#, 16), 
      to_unsigned(16#024A#, 16), to_unsigned(16#024B#, 16), to_unsigned(16#024D#, 16), to_unsigned(16#024E#, 16), to_unsigned(16#0250#, 16), to_unsigned(16#0251#, 16), to_unsigned(16#0253#, 16), to_unsigned(16#0254#, 16), to_unsigned(16#0256#, 16), 
      to_unsigned(16#0257#, 16), to_unsigned(16#0259#, 16), to_unsigned(16#025A#, 16), to_unsigned(16#025C#, 16), to_unsigned(16#025D#, 16), to_unsigned(16#025F#, 16), to_unsigned(16#0260#, 16), to_unsigned(16#0262#, 16), to_unsigned(16#0263#, 16), 
      to_unsigned(16#0265#, 16), to_unsigned(16#0266#, 16), to_unsigned(16#0268#, 16), to_unsigned(16#0269#, 16), to_unsigned(16#026B#, 16), to_unsigned(16#026C#, 16), to_unsigned(16#026E#, 16), to_unsigned(16#026F#, 16), to_unsigned(16#0271#, 16), 
      to_unsigned(16#0272#, 16), to_unsigned(16#0274#, 16), to_unsigned(16#0275#, 16), to_unsigned(16#0277#, 16), to_unsigned(16#0278#, 16), to_unsigned(16#027A#, 16), to_unsigned(16#027B#, 16), to_unsigned(16#027D#, 16), to_unsigned(16#027E#, 16), 
      to_unsigned(16#0280#, 16), to_unsigned(16#0281#, 16), to_unsigned(16#0283#, 16), to_unsigned(16#0284#, 16), to_unsigned(16#0286#, 16), to_unsigned(16#0287#, 16), to_unsigned(16#0288#, 16), to_unsigned(16#0289#, 16), to_unsigned(16#028A#, 16), 
      to_unsigned(16#028B#, 16), to_unsigned(16#028C#, 16), to_unsigned(16#028D#, 16), to_unsigned(16#028E#, 16), to_unsigned(16#028F#, 16), to_unsigned(16#0290#, 16), to_unsigned(16#0291#, 16), to_unsigned(16#0292#, 16), to_unsigned(16#0293#, 16), 
      to_unsigned(16#0294#, 16), to_unsigned(16#0295#, 16), to_unsigned(16#0296#, 16), to_unsigned(16#0297#, 16), to_unsigned(16#0298#, 16), to_unsigned(16#0299#, 16), to_unsigned(16#029A#, 16), to_unsigned(16#029B#, 16), to_unsigned(16#029C#, 16), 
      to_unsigned(16#029D#, 16), to_unsigned(16#029E#, 16), to_unsigned(16#029F#, 16), to_unsigned(16#02A0#, 16), to_unsigned(16#02A1#, 16), to_unsigned(16#02A2#, 16), to_unsigned(16#02A3#, 16), to_unsigned(16#02A4#, 16), to_unsigned(16#02A5#, 16), 
      to_unsigned(16#02A6#, 16), to_unsigned(16#02A7#, 16), to_unsigned(16#02A8#, 16), to_unsigned(16#02A9#, 16), to_unsigned(16#02AA#, 16), to_unsigned(16#02AB#, 16), to_unsigned(16#02AC#, 16), to_unsigned(16#02AD#, 16), to_unsigned(16#02AE#, 16), 
      to_unsigned(16#02AF#, 16), to_unsigned(16#02B0#, 16), to_unsigned(16#02B1#, 16), to_unsigned(16#02B2#, 16), to_unsigned(16#02B3#, 16), to_unsigned(16#02B4#, 16), to_unsigned(16#02B5#, 16), to_unsigned(16#02B6#, 16), to_unsigned(16#02B7#, 16), 
      to_unsigned(16#02B8#, 16), to_unsigned(16#02B9#, 16), to_unsigned(16#02BA#, 16), to_unsigned(16#02BB#, 16), to_unsigned(16#02BC#, 16), to_unsigned(16#02BD#, 16), to_unsigned(16#02BE#, 16), to_unsigned(16#02BF#, 16), to_unsigned(16#02C0#, 16), 
      to_unsigned(16#02C1#, 16), to_unsigned(16#02C2#, 16), to_unsigned(16#02C3#, 16), to_unsigned(16#02C4#, 16), to_unsigned(16#02C5#, 16), to_unsigned(16#02C6#, 16), to_unsigned(16#02C7#, 16), to_unsigned(16#02C8#, 16), to_unsigned(16#02C9#, 16), 
      to_unsigned(16#02CA#, 16), to_unsigned(16#02CB#, 16), to_unsigned(16#02CC#, 16), to_unsigned(16#02CD#, 16), to_unsigned(16#02CE#, 16), to_unsigned(16#02CF#, 16), to_unsigned(16#02D0#, 16), to_unsigned(16#02D1#, 16), to_unsigned(16#02D2#, 16), 
      to_unsigned(16#02D3#, 16), to_unsigned(16#02D4#, 16), to_unsigned(16#02D5#, 16), to_unsigned(16#02D6#, 16), to_unsigned(16#02D7#, 16), to_unsigned(16#02D8#, 16), to_unsigned(16#02D9#, 16), to_unsigned(16#02DA#, 16), to_unsigned(16#02DB#, 16), 
      to_unsigned(16#02DC#, 16), to_unsigned(16#02DD#, 16), to_unsigned(16#02DE#, 16), to_unsigned(16#02DF#, 16), to_unsigned(16#02E0#, 16), to_unsigned(16#02E1#, 16), to_unsigned(16#02E2#, 16), to_unsigned(16#02E3#, 16), to_unsigned(16#02E4#, 16), 
      to_unsigned(16#02E5#, 16), to_unsigned(16#02E6#, 16), to_unsigned(16#02E7#, 16), to_unsigned(16#02E8#, 16), to_unsigned(16#02E9#, 16), to_unsigned(16#02EA#, 16), to_unsigned(16#02EB#, 16), to_unsigned(16#02EC#, 16), to_unsigned(16#02ED#, 16), 
      to_unsigned(16#02EE#, 16), to_unsigned(16#02EF#, 16), to_unsigned(16#02F0#, 16), to_unsigned(16#02F1#, 16), to_unsigned(16#02F2#, 16), to_unsigned(16#02F3#, 16), to_unsigned(16#02F4#, 16), to_unsigned(16#02F5#, 16), to_unsigned(16#02F6#, 16), 
      to_unsigned(16#02F7#, 16), to_unsigned(16#02F8#, 16), to_unsigned(16#02F9#, 16), to_unsigned(16#02FA#, 16), to_unsigned(16#02FB#, 16), to_unsigned(16#02FC#, 16), to_unsigned(16#02FD#, 16), to_unsigned(16#02FE#, 16), to_unsigned(16#02FF#, 16), 
      to_unsigned(16#0300#, 16), to_unsigned(16#0301#, 16), to_unsigned(16#0302#, 16), to_unsigned(16#0303#, 16), to_unsigned(16#0304#, 16), to_unsigned(16#0305#, 16), to_unsigned(16#0306#, 16), to_unsigned(16#0307#, 16), to_unsigned(16#0308#, 16), 
      to_unsigned(16#0309#, 16), to_unsigned(16#030A#, 16), to_unsigned(16#030B#, 16), to_unsigned(16#030C#, 16), to_unsigned(16#030D#, 16), to_unsigned(16#030E#, 16), to_unsigned(16#030F#, 16), to_unsigned(16#0310#, 16), to_unsigned(16#0311#, 16), 
      to_unsigned(16#0312#, 16), to_unsigned(16#0313#, 16), to_unsigned(16#0314#, 16), to_unsigned(16#0315#, 16), to_unsigned(16#0316#, 16), to_unsigned(16#0317#, 16)); -- ufix16 [240]

  -- Signals
  SIGNAL mod3HDL1_reminder                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL mod3HDL1_reminder_unsigned       : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Delay3_out1                      : unsigned(15 DOWNTO 0) := to_unsigned(16#0000#, 16);  -- uint16
  SIGNAL enbGen_enb                       : std_logic;
  SIGNAL Delay4_reg_rsvd                  : std_logic_vector(4 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [5]
  SIGNAL Delay4_out1                      : std_logic;
  SIGNAL Logical_Operator1_out1           : std_logic;
  SIGNAL HDL_Counter2_out1                : unsigned(7 DOWNTO 0) := to_unsigned(16#00#, 8);  -- uint8
  SIGNAL count                            : unsigned(7 DOWNTO 0);  -- uint8
  SIGNAL need_to_wrap                     : std_logic;
  SIGNAL count_value                      : unsigned(7 DOWNTO 0);  -- uint8
  SIGNAL count_1                          : unsigned(7 DOWNTO 0);  -- uint8
  SIGNAL count_2                          : unsigned(7 DOWNTO 0);  -- uint8
  SIGNAL Direct_Lookup_Table_n_D_out1     : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL resetNoneReg_out1                : unsigned(15 DOWNTO 0) := to_unsigned(16#0000#, 16);  -- uint16
  SIGNAL Compare_To_Constant_out1         : std_logic;
  SIGNAL dtc1                             : std_logic;  -- ufix1
  SIGNAL NOT_out1                         : std_logic;
  SIGNAL Logical_Operator_out1            : std_logic;
  SIGNAL Delay2_out1                      : std_logic := '0';
  SIGNAL Add_sub_cast                     : signed(16 DOWNTO 0);  -- sfix17
  SIGNAL Add_sub_temp                     : signed(16 DOWNTO 0);  -- sfix17
  SIGNAL Add_out1                         : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Delay5_out1                      : std_logic := '0';
  SIGNAL Enabled_Subsystem_adjustIdx      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL Enabled_Subsystem_adjustIdx_unsigned : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Multiport_Switch1_out1           : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Delay6_out1                      : unsigned(15 DOWNTO 0) := to_unsigned(16#0000#, 16);  -- uint16
  SIGNAL Delay1_reg_rsvd                  : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [2]
  SIGNAL Delay1_out1                      : std_logic;

BEGIN
  Umod3HDL1 : ltehdlPBCHIndexing_mod3HDL1
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              addr_in => NCellID,  -- ufix9
              reminder => mod3HDL1_reminder  -- uint16
              );

  UenbGen : ltehdlPBCHIndexing_enbGen
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              start => start,
              enb_1 => enbGen_enb
              );

  UEnabled_Subsystem : ltehdlPBCHIndexing_Enabled_Subsystem
    PORT MAP( idxdata => std_logic_vector(resetNoneReg_out1),  -- uint16
              seI => Delay5_out1,
              adjustIdx => Enabled_Subsystem_adjustIdx  -- uint16
              );

  mod3HDL1_reminder_unsigned <= unsigned(mod3HDL1_reminder);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay3_out1 <= mod3HDL1_reminder_unsigned;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay4_reg_rsvd(0) <= enbGen_enb;
        Delay4_reg_rsvd(4 DOWNTO 1) <= Delay4_reg_rsvd(3 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS Delay4_process;

  Delay4_out1 <= Delay4_reg_rsvd(4);

  Logical_Operator1_out1 <=  NOT Delay4_out1;

  -- Count limited, Unsigned Counter
  --  initial value   = 0
  --  step value      = 1
  --  count to value  = 239
  count <= HDL_Counter2_out1 + to_unsigned(16#01#, 8);

  
  need_to_wrap <= '1' WHEN HDL_Counter2_out1 = to_unsigned(16#EF#, 8) ELSE
      '0';

  
  count_value <= count WHEN need_to_wrap = '0' ELSE
      to_unsigned(16#00#, 8);

  
  count_1 <= HDL_Counter2_out1 WHEN Delay4_out1 = '0' ELSE
      count_value;

  
  count_2 <= count_1 WHEN Logical_Operator1_out1 = '0' ELSE
      to_unsigned(16#00#, 8);

  HDL_Counter2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        HDL_Counter2_out1 <= count_2;
      END IF;
    END IF;
  END PROCESS HDL_Counter2_process;


  Direct_Lookup_Table_n_D_out1 <= Direct_Lookup_Table_n_D_data(to_integer(HDL_Counter2_out1));

  resetNoneReg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        resetNoneReg_out1 <= Direct_Lookup_Table_n_D_out1;
      END IF;
    END IF;
  END PROCESS resetNoneReg_process;


  
  Compare_To_Constant_out1 <= '1' WHEN HDL_Counter2_out1 <= to_unsigned(16#5F#, 8) ELSE
      '0';

  dtc1 <= HDL_Counter2_out1(0);

  NOT_out1 <=  NOT dtc1;

  Logical_Operator_out1 <= Compare_To_Constant_out1 AND NOT_out1;

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay2_out1 <= Logical_Operator_out1;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  Add_sub_cast <= '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & Delay2_out1;
  Add_sub_temp <= signed(resize(resetNoneReg_out1, 17)) - Add_sub_cast;
  Add_out1 <= unsigned(Add_sub_temp(15 DOWNTO 0));

  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay5_out1 <= Compare_To_Constant_out1;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  Enabled_Subsystem_adjustIdx_unsigned <= unsigned(Enabled_Subsystem_adjustIdx);

  
  Multiport_Switch1_out1 <= resetNoneReg_out1 WHEN Delay3_out1 = to_unsigned(16#0000#, 16) ELSE
      Add_out1 WHEN Delay3_out1 = to_unsigned(16#0001#, 16) ELSE
      Enabled_Subsystem_adjustIdx_unsigned;

  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay6_out1 <= Multiport_Switch1_out1;
      END IF;
    END IF;
  END PROCESS Delay6_process;


  idx_data <= std_logic_vector(Delay6_out1);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_reg_rsvd(0) <= Delay4_out1;
        Delay1_reg_rsvd(1) <= Delay1_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay1_process;

  Delay1_out1 <= Delay1_reg_rsvd(1);

  idx_data_valid <= Delay1_out1;

END rtl;

