-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_SDFCommutator6 IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        dout_5_1_vld                      :   IN    std_logic;
        xf_re                             :   IN    std_logic_vector(21 DOWNTO 0);  -- ufix22
        xf_im                             :   IN    std_logic_vector(21 DOWNTO 0);  -- ufix22
        xf_vld                            :   IN    std_logic;
        dinf_re                           :   IN    std_logic_vector(21 DOWNTO 0);  -- ufix22
        dinf_im                           :   IN    std_logic_vector(21 DOWNTO 0);  -- ufix22
        dinf_vld                          :   IN    std_logic;
        btf1_re                           :   IN    std_logic_vector(21 DOWNTO 0);  -- ufix22
        btf1_im                           :   IN    std_logic_vector(21 DOWNTO 0);  -- ufix22
        btf2_re                           :   IN    std_logic_vector(21 DOWNTO 0);  -- ufix22
        btf2_im                           :   IN    std_logic_vector(21 DOWNTO 0);  -- ufix22
        btfout_vld                        :   IN    std_logic;
        syncReset                         :   IN    std_logic;
        wrData_re                         :   OUT   std_logic_vector(21 DOWNTO 0);  -- ufix22
        wrData_im                         :   OUT   std_logic_vector(21 DOWNTO 0);  -- ufix22
        wrAddr                            :   OUT   std_logic_vector(4 DOWNTO 0);  -- ufix5
        wrEnb                             :   OUT   std_logic;
        dout_6_1_re                       :   OUT   std_logic_vector(21 DOWNTO 0);  -- ufix22
        dout_6_1_im                       :   OUT   std_logic_vector(21 DOWNTO 0);  -- ufix22
        dout_6_1_vld                      :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_SDFCommutator6;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_SDFCommutator6 IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    GENERIC( AddrWidth                    : integer;
             DataWidth                    : integer
             );
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          wr_din                          :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          wr_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          wr_en                           :   IN    std_logic;
          rd_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          dout                            :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0)  -- generic width
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block(rtl);

  -- Signals
  SIGNAL xf_re_signed                     : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL xf_im_signed                     : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL dinf_re_signed                   : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL dinf_im_signed                   : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL btf1_re_signed                   : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL btf1_im_signed                   : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL btf2_re_signed                   : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL btf2_im_signed                   : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL SDFCummutator_out_re             : signed(21 DOWNTO 0) := to_signed(16#000000#, 22);  -- sfix22
  SIGNAL SDFCummutator_out_im             : signed(21 DOWNTO 0) := to_signed(16#000000#, 22);  -- sfix22
  SIGNAL SDFCummutator_out_vld            : std_logic := '0';
  SIGNAL SDFCummutator_wrAddr_reg         : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL SDFCummutator_wrState            : unsigned(2 DOWNTO 0) := to_unsigned(16#0#, 3);  -- ufix3
  SIGNAL SDFCummutator_mem_btf_switch     : unsigned(1 DOWNTO 0) := to_unsigned(16#0#, 2);  -- ufix2
  SIGNAL SDFCummutator_rdCnt              : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL SDFCummutator_wrData_re_reg      : signed(21 DOWNTO 0) := to_signed(16#000000#, 22);  -- sfix22
  SIGNAL SDFCummutator_wrData_im_reg      : signed(21 DOWNTO 0) := to_signed(16#000000#, 22);  -- sfix22
  SIGNAL SDFCummutator_wrEnb_reg          : std_logic := '0';
  SIGNAL SDFCummutator_wrXData_re_reg     : signed(21 DOWNTO 0) := to_signed(16#000000#, 22);  -- sfix22
  SIGNAL SDFCummutator_wrXData_im_reg     : signed(21 DOWNTO 0) := to_signed(16#000000#, 22);  -- sfix22
  SIGNAL SDFCummutator_xWrAddr            : unsigned(2 DOWNTO 0) := to_unsigned(16#0#, 3);  -- ufix3
  SIGNAL SDFCummutator_wrxEnb_reg         : std_logic := '0';
  SIGNAL SDFCummutator_xRdAddr            : unsigned(2 DOWNTO 0) := to_unsigned(16#0#, 3);  -- ufix3
  SIGNAL SDFCummutator_XState             : unsigned(2 DOWNTO 0) := to_unsigned(16#0#, 3);  -- ufix3
  SIGNAL SDFCummutator_rdEnb_xmem         : std_logic := '0';
  SIGNAL SDFCummutator_wrEnb_xmem         : std_logic := '0';
  SIGNAL SDFCummutator_xX_vld_reg         : std_logic := '0';
  SIGNAL SDFCummutator_out_re_next        : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL SDFCummutator_out_im_next        : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL SDFCummutator_out_vld_next       : std_logic;
  SIGNAL SDFCummutator_wrAddr_reg_next    : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL SDFCummutator_wrState_next       : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL SDFCummutator_mem_btf_switch_next : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL SDFCummutator_rdCnt_next         : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL SDFCummutator_wrData_re_reg_next : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL SDFCummutator_wrData_im_reg_next : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL SDFCummutator_wrEnb_reg_next     : std_logic;
  SIGNAL SDFCummutator_wrXData_re_reg_next : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL SDFCummutator_wrXData_im_reg_next : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL SDFCummutator_xWrAddr_next       : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL SDFCummutator_wrxEnb_reg_next    : std_logic;
  SIGNAL SDFCummutator_xRdAddr_next       : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL SDFCummutator_XState_next        : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL SDFCummutator_rdEnb_xmem_next    : std_logic;
  SIGNAL SDFCummutator_wrEnb_xmem_next    : std_logic;
  SIGNAL SDFCummutator_xX_vld_reg_next    : std_logic;
  SIGNAL wrData_re_tmp                    : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL wrData_im_tmp                    : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL wrAddr_tmp                       : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL xData_re                         : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL xData_im                         : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL wrXAddr                          : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL wrXEnb                           : std_logic;
  SIGNAL rdXAddr                          : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL xX_vld                           : std_logic;
  SIGNAL dout0_re                         : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL dout0_im                         : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL dout0_vld                        : std_logic;
  SIGNAL xX_re                            : std_logic_vector(21 DOWNTO 0);  -- ufix22
  SIGNAL xX_re_signed                     : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL xX_im                            : std_logic_vector(21 DOWNTO 0);  -- ufix22
  SIGNAL xX_im_signed                     : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL SDFOutmux_btf2Pipe_re            : signed(21 DOWNTO 0) := to_signed(16#000000#, 22);  -- sfix22
  SIGNAL SDFOutmux_btf2Pipe_im            : signed(21 DOWNTO 0) := to_signed(16#000000#, 22);  -- sfix22
  SIGNAL SDFOutmux_btfPipe_vld            : std_logic := '0';
  SIGNAL SDFOutmux_btf2Pipe_re_next       : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL SDFOutmux_btf2Pipe_im_next       : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL SDFOutmux_btfPipe_vld_next       : std_logic;
  SIGNAL dout_6_1_re_tmp                  : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL dout_6_1_im_tmp                  : signed(21 DOWNTO 0);  -- sfix22_En15

BEGIN
  UdataXMEM_re_0_6 : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    GENERIC MAP( AddrWidth => 3,
                 DataWidth => 22
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din => std_logic_vector(xData_re),
              wr_addr => std_logic_vector(wrXAddr),
              wr_en => wrXEnb,
              rd_addr => std_logic_vector(rdXAddr),
              dout => xX_re
              );

  UdataXMEM_im_0_6 : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    GENERIC MAP( AddrWidth => 3,
                 DataWidth => 22
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din => std_logic_vector(xData_im),
              wr_addr => std_logic_vector(wrXAddr),
              wr_en => wrXEnb,
              rd_addr => std_logic_vector(rdXAddr),
              dout => xX_im
              );

  xf_re_signed <= signed(xf_re);

  xf_im_signed <= signed(xf_im);

  dinf_re_signed <= signed(dinf_re);

  dinf_im_signed <= signed(dinf_im);

  btf1_re_signed <= signed(btf1_re);

  btf1_im_signed <= signed(btf1_im);

  btf2_re_signed <= signed(btf2_re);

  btf2_im_signed <= signed(btf2_im);

  -- SDFCummutator
  SDFCummutator_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          SDFCummutator_out_re <= to_signed(16#000000#, 22);
          SDFCummutator_out_im <= to_signed(16#000000#, 22);
          SDFCummutator_wrData_re_reg <= to_signed(16#000000#, 22);
          SDFCummutator_wrData_im_reg <= to_signed(16#000000#, 22);
          SDFCummutator_wrEnb_reg <= '0';
          SDFCummutator_out_vld <= '0';
          SDFCummutator_wrState <= to_unsigned(16#0#, 3);
          SDFCummutator_mem_btf_switch <= to_unsigned(16#0#, 2);
          SDFCummutator_wrAddr_reg <= to_unsigned(16#00#, 5);
          SDFCummutator_rdCnt <= to_unsigned(16#00#, 5);
          SDFCummutator_wrXData_re_reg <= to_signed(16#000000#, 22);
          SDFCummutator_wrXData_im_reg <= to_signed(16#000000#, 22);
          SDFCummutator_xWrAddr <= to_unsigned(16#0#, 3);
          SDFCummutator_wrxEnb_reg <= '0';
          SDFCummutator_xRdAddr <= to_unsigned(16#0#, 3);
          SDFCummutator_XState <= to_unsigned(16#0#, 3);
          SDFCummutator_rdEnb_xmem <= '0';
          SDFCummutator_wrEnb_xmem <= '0';
          SDFCummutator_xX_vld_reg <= '0';
        ELSE 
          SDFCummutator_out_re <= SDFCummutator_out_re_next;
          SDFCummutator_out_im <= SDFCummutator_out_im_next;
          SDFCummutator_out_vld <= SDFCummutator_out_vld_next;
          SDFCummutator_wrAddr_reg <= SDFCummutator_wrAddr_reg_next;
          SDFCummutator_wrState <= SDFCummutator_wrState_next;
          SDFCummutator_mem_btf_switch <= SDFCummutator_mem_btf_switch_next;
          SDFCummutator_rdCnt <= SDFCummutator_rdCnt_next;
          SDFCummutator_wrData_re_reg <= SDFCummutator_wrData_re_reg_next;
          SDFCummutator_wrData_im_reg <= SDFCummutator_wrData_im_reg_next;
          SDFCummutator_wrEnb_reg <= SDFCummutator_wrEnb_reg_next;
          SDFCummutator_wrXData_re_reg <= SDFCummutator_wrXData_re_reg_next;
          SDFCummutator_wrXData_im_reg <= SDFCummutator_wrXData_im_reg_next;
          SDFCummutator_xWrAddr <= SDFCummutator_xWrAddr_next;
          SDFCummutator_wrxEnb_reg <= SDFCummutator_wrxEnb_reg_next;
          SDFCummutator_xRdAddr <= SDFCummutator_xRdAddr_next;
          SDFCummutator_XState <= SDFCummutator_XState_next;
          SDFCummutator_rdEnb_xmem <= SDFCummutator_rdEnb_xmem_next;
          SDFCummutator_wrEnb_xmem <= SDFCummutator_wrEnb_xmem_next;
          SDFCummutator_xX_vld_reg <= SDFCummutator_xX_vld_reg_next;
        END IF;
      END IF;
    END IF;
  END PROCESS SDFCummutator_process;

  SDFCummutator_output : PROCESS (SDFCummutator_XState, SDFCummutator_mem_btf_switch, SDFCummutator_out_im,
       SDFCummutator_out_re, SDFCummutator_out_vld, SDFCummutator_rdCnt,
       SDFCummutator_rdEnb_xmem, SDFCummutator_wrAddr_reg,
       SDFCummutator_wrData_im_reg, SDFCummutator_wrData_re_reg,
       SDFCummutator_wrEnb_reg, SDFCummutator_wrEnb_xmem, SDFCummutator_wrState,
       SDFCummutator_wrXData_im_reg, SDFCummutator_wrXData_re_reg,
       SDFCummutator_wrxEnb_reg, SDFCummutator_xRdAddr, SDFCummutator_xWrAddr,
       SDFCummutator_xX_vld_reg, btf1_im_signed, btf1_re_signed, btf2_im_signed,
       btf2_re_signed, btfout_vld, dinf_im_signed, dinf_re_signed, dinf_vld,
       xf_im_signed, xf_re_signed, xf_vld)
  BEGIN
    SDFCummutator_wrAddr_reg_next <= SDFCummutator_wrAddr_reg;
    SDFCummutator_rdCnt_next <= SDFCummutator_rdCnt;
    SDFCummutator_wrData_re_reg_next <= SDFCummutator_wrData_re_reg;
    SDFCummutator_wrData_im_reg_next <= SDFCummutator_wrData_im_reg;
    SDFCummutator_wrEnb_reg_next <= SDFCummutator_wrEnb_reg;
    SDFCummutator_wrXData_re_reg_next <= SDFCummutator_wrXData_re_reg;
    SDFCummutator_wrXData_im_reg_next <= SDFCummutator_wrXData_im_reg;
    SDFCummutator_xWrAddr_next <= SDFCummutator_xWrAddr;
    SDFCummutator_wrxEnb_reg_next <= SDFCummutator_wrxEnb_reg;
    SDFCummutator_xRdAddr_next <= SDFCummutator_xRdAddr;
    SDFCummutator_XState_next <= SDFCummutator_XState;
    SDFCummutator_rdEnb_xmem_next <= SDFCummutator_rdEnb_xmem;
    SDFCummutator_wrEnb_xmem_next <= SDFCummutator_wrEnb_xmem;
    SDFCummutator_xX_vld_reg_next <= SDFCummutator_xX_vld_reg;
    CASE SDFCummutator_XState IS
      WHEN "000" =>
        SDFCummutator_wrXData_re_reg_next <= to_signed(16#000000#, 22);
        SDFCummutator_wrXData_im_reg_next <= to_signed(16#000000#, 22);
        SDFCummutator_xWrAddr_next <= to_unsigned(16#0#, 3);
        SDFCummutator_xRdAddr_next <= to_unsigned(16#0#, 3);
        SDFCummutator_wrxEnb_reg_next <= '0';
        SDFCummutator_xX_vld_reg_next <= '0';
        SDFCummutator_XState_next <= to_unsigned(16#0#, 3);
        IF (SDFCummutator_wrEnb_xmem = '1' AND (SDFCummutator_wrAddr_reg = to_unsigned(16#17#, 5))) AND SDFCummutator_wrEnb_reg = '1' THEN 
          SDFCummutator_wrXData_re_reg_next <= btf2_re_signed;
          SDFCummutator_wrXData_im_reg_next <= btf2_im_signed;
          SDFCummutator_xWrAddr_next <= to_unsigned(16#0#, 3);
          IF btfout_vld = '1' THEN 
            SDFCummutator_wrxEnb_reg_next <= '1';
            SDFCummutator_XState_next <= to_unsigned(16#2#, 3);
          ELSE 
            SDFCummutator_wrxEnb_reg_next <= '0';
            SDFCummutator_XState_next <= to_unsigned(16#1#, 3);
          END IF;
        END IF;
      WHEN "001" =>
        SDFCummutator_XState_next <= to_unsigned(16#1#, 3);
        SDFCummutator_xX_vld_reg_next <= '0';
        IF btfout_vld = '1' THEN 
          SDFCummutator_wrXData_re_reg_next <= btf2_re_signed;
          SDFCummutator_wrXData_im_reg_next <= btf2_im_signed;
          SDFCummutator_xWrAddr_next <= to_unsigned(16#0#, 3);
          SDFCummutator_wrxEnb_reg_next <= '1';
          SDFCummutator_XState_next <= to_unsigned(16#2#, 3);
        END IF;
      WHEN "010" =>
        SDFCummutator_wrXData_re_reg_next <= btf2_re_signed;
        SDFCummutator_wrXData_im_reg_next <= btf2_im_signed;
        SDFCummutator_xX_vld_reg_next <= '0';
        IF SDFCummutator_xWrAddr = to_unsigned(16#7#, 3) THEN 
          SDFCummutator_wrxEnb_reg_next <= '0';
          IF SDFCummutator_rdEnb_xmem = '1' THEN 
            SDFCummutator_XState_next <= to_unsigned(16#4#, 3);
            SDFCummutator_xX_vld_reg_next <= '1';
            SDFCummutator_xRdAddr_next <= to_unsigned(16#1#, 3);
          ELSE 
            SDFCummutator_XState_next <= to_unsigned(16#3#, 3);
          END IF;
          SDFCummutator_xWrAddr_next <= to_unsigned(16#0#, 3);
        ELSIF btfout_vld = '1' THEN 
          SDFCummutator_XState_next <= to_unsigned(16#2#, 3);
          SDFCummutator_wrxEnb_reg_next <= '1';
          SDFCummutator_xWrAddr_next <= SDFCummutator_xWrAddr + to_unsigned(16#1#, 3);
        ELSE 
          SDFCummutator_XState_next <= to_unsigned(16#2#, 3);
          SDFCummutator_wrxEnb_reg_next <= '0';
        END IF;
      WHEN "011" =>
        IF SDFCummutator_rdEnb_xmem = '1' THEN 
          SDFCummutator_XState_next <= to_unsigned(16#4#, 3);
          SDFCummutator_xX_vld_reg_next <= '1';
          SDFCummutator_xRdAddr_next <= to_unsigned(16#1#, 3);
        END IF;
      WHEN "100" =>
        IF SDFCummutator_xRdAddr = to_unsigned(16#7#, 3) THEN 
          SDFCummutator_xX_vld_reg_next <= '1';
          SDFCummutator_xWrAddr_next <= to_unsigned(16#0#, 3);
          SDFCummutator_xRdAddr_next <= to_unsigned(16#0#, 3);
          IF SDFCummutator_wrEnb_xmem = '1' THEN 
            SDFCummutator_wrXData_re_reg_next <= btf2_re_signed;
            SDFCummutator_wrXData_im_reg_next <= btf2_im_signed;
            IF btfout_vld = '1' THEN 
              SDFCummutator_wrxEnb_reg_next <= '1';
              SDFCummutator_XState_next <= to_unsigned(16#2#, 3);
            ELSE 
              SDFCummutator_wrxEnb_reg_next <= '0';
              SDFCummutator_XState_next <= to_unsigned(16#1#, 3);
            END IF;
          ELSE 
            SDFCummutator_XState_next <= to_unsigned(16#0#, 3);
            SDFCummutator_wrxEnb_reg_next <= '0';
            SDFCummutator_wrXData_re_reg_next <= to_signed(16#000000#, 22);
            SDFCummutator_wrXData_im_reg_next <= to_signed(16#000000#, 22);
          END IF;
        ELSE 
          SDFCummutator_xRdAddr_next <= SDFCummutator_xRdAddr + to_unsigned(16#1#, 3);
        END IF;
      WHEN OTHERS => 
        SDFCummutator_wrXData_re_reg_next <= to_signed(16#000000#, 22);
        SDFCummutator_wrXData_im_reg_next <= to_signed(16#000000#, 22);
        SDFCummutator_xWrAddr_next <= to_unsigned(16#0#, 3);
        SDFCummutator_xRdAddr_next <= to_unsigned(16#0#, 3);
        SDFCummutator_wrxEnb_reg_next <= '0';
        SDFCummutator_XState_next <= to_unsigned(16#0#, 3);
    END CASE;
    CASE SDFCummutator_mem_btf_switch IS
      WHEN "00" =>
        SDFCummutator_mem_btf_switch_next <= to_unsigned(16#0#, 2);
        SDFCummutator_rdCnt_next <= to_unsigned(16#00#, 5);
        SDFCummutator_out_re_next <= xf_re_signed;
        SDFCummutator_out_im_next <= xf_im_signed;
        SDFCummutator_out_vld_next <= '0';
        SDFCummutator_rdEnb_xmem_next <= '0';
        IF dinf_vld = '1' THEN 
          SDFCummutator_mem_btf_switch_next <= to_unsigned(16#1#, 2);
          SDFCummutator_rdCnt_next <= to_unsigned(16#00#, 5);
        END IF;
      WHEN "01" =>
        SDFCummutator_mem_btf_switch_next <= to_unsigned(16#1#, 2);
        SDFCummutator_rdEnb_xmem_next <= '0';
        IF (SDFCummutator_rdCnt = to_unsigned(16#1F#, 5)) AND btfout_vld = '1' THEN 
          SDFCummutator_mem_btf_switch_next <= to_unsigned(16#2#, 2);
        END IF;
        IF btfout_vld = '1' THEN 
          SDFCummutator_rdCnt_next <= SDFCummutator_rdCnt + to_unsigned(16#01#, 5);
        END IF;
        SDFCummutator_out_re_next <= btf1_re_signed;
        SDFCummutator_out_im_next <= btf1_im_signed;
        SDFCummutator_out_vld_next <= btfout_vld;
      WHEN "10" =>
        SDFCummutator_mem_btf_switch_next <= to_unsigned(16#2#, 2);
        IF (SDFCummutator_rdCnt = to_unsigned(16#17#, 5)) AND xf_vld = '1' THEN 
          SDFCummutator_mem_btf_switch_next <= to_unsigned(16#1#, 2);
          SDFCummutator_rdEnb_xmem_next <= '1';
        END IF;
        IF xf_vld = '1' THEN 
          IF SDFCummutator_rdCnt = to_unsigned(16#17#, 5) THEN 
            SDFCummutator_rdCnt_next <= to_unsigned(16#00#, 5);
          ELSE 
            SDFCummutator_rdCnt_next <= SDFCummutator_rdCnt + to_unsigned(16#01#, 5);
          END IF;
        END IF;
        SDFCummutator_out_re_next <= xf_re_signed;
        SDFCummutator_out_im_next <= xf_im_signed;
        SDFCummutator_out_vld_next <= xf_vld;
      WHEN OTHERS => 
        SDFCummutator_mem_btf_switch_next <= to_unsigned(16#0#, 2);
        SDFCummutator_rdCnt_next <= to_unsigned(16#00#, 5);
        SDFCummutator_out_re_next <= xf_re_signed;
        SDFCummutator_out_im_next <= xf_im_signed;
        SDFCummutator_out_vld_next <= xf_vld;
    END CASE;
    CASE SDFCummutator_wrState IS
      WHEN "000" =>
        SDFCummutator_wrState_next <= to_unsigned(16#0#, 3);
        SDFCummutator_wrEnb_xmem_next <= '0';
        SDFCummutator_wrAddr_reg_next <= to_unsigned(16#00#, 5);
        SDFCummutator_wrData_re_reg_next <= dinf_re_signed;
        SDFCummutator_wrData_im_reg_next <= dinf_im_signed;
        IF dinf_vld = '1' THEN 
          SDFCummutator_wrState_next <= to_unsigned(16#1#, 3);
          SDFCummutator_wrAddr_reg_next <= to_unsigned(16#00#, 5);
          SDFCummutator_wrEnb_reg_next <= '1';
        END IF;
      WHEN "001" =>
        SDFCummutator_wrState_next <= to_unsigned(16#1#, 3);
        SDFCummutator_wrEnb_reg_next <= '0';
        SDFCummutator_wrEnb_xmem_next <= '0';
        IF SDFCummutator_wrAddr_reg = to_unsigned(16#1F#, 5) THEN 
          IF btfout_vld = '1' THEN 
            SDFCummutator_wrState_next <= to_unsigned(16#2#, 3);
          ELSE 
            SDFCummutator_wrState_next <= to_unsigned(16#4#, 3);
          END IF;
          SDFCummutator_wrAddr_reg_next <= to_unsigned(16#00#, 5);
          SDFCummutator_wrEnb_reg_next <= btfout_vld;
          SDFCummutator_wrData_re_reg_next <= btf2_re_signed;
          SDFCummutator_wrData_im_reg_next <= btf2_im_signed;
        ELSIF dinf_vld = '1' THEN 
          SDFCummutator_wrState_next <= to_unsigned(16#1#, 3);
          SDFCummutator_wrAddr_reg_next <= SDFCummutator_wrAddr_reg + to_unsigned(16#01#, 5);
          SDFCummutator_wrEnb_reg_next <= '1';
          SDFCummutator_wrData_re_reg_next <= dinf_re_signed;
          SDFCummutator_wrData_im_reg_next <= dinf_im_signed;
        END IF;
      WHEN "010" =>
        SDFCummutator_wrState_next <= to_unsigned(16#2#, 3);
        SDFCummutator_wrEnb_reg_next <= '0';
        SDFCummutator_wrEnb_xmem_next <= '0';
        IF SDFCummutator_wrAddr_reg = to_unsigned(16#16#, 5) THEN 
          SDFCummutator_wrEnb_xmem_next <= '1';
        END IF;
        IF SDFCummutator_wrAddr_reg = to_unsigned(16#17#, 5) THEN 
          SDFCummutator_wrAddr_reg_next <= SDFCummutator_wrAddr_reg + to_unsigned(16#01#, 5);
          SDFCummutator_wrState_next <= to_unsigned(16#3#, 3);
          SDFCummutator_wrEnb_reg_next <= '0';
          SDFCummutator_wrData_re_reg_next <= dinf_re_signed;
          SDFCummutator_wrData_im_reg_next <= dinf_im_signed;
        ELSIF btfout_vld = '1' THEN 
          SDFCummutator_wrState_next <= to_unsigned(16#2#, 3);
          SDFCummutator_wrAddr_reg_next <= SDFCummutator_wrAddr_reg + to_unsigned(16#01#, 5);
          SDFCummutator_wrEnb_reg_next <= '1';
          SDFCummutator_wrData_re_reg_next <= btf2_re_signed;
          SDFCummutator_wrData_im_reg_next <= btf2_im_signed;
        END IF;
      WHEN "011" =>
        SDFCummutator_wrAddr_reg_next <= to_unsigned(16#00#, 5);
        SDFCummutator_wrEnb_reg_next <= dinf_vld;
        SDFCummutator_wrData_re_reg_next <= dinf_re_signed;
        SDFCummutator_wrData_im_reg_next <= dinf_im_signed;
        SDFCummutator_wrEnb_xmem_next <= '0';
        IF dinf_vld = '1' THEN 
          SDFCummutator_wrState_next <= to_unsigned(16#1#, 3);
        ELSE 
          SDFCummutator_wrState_next <= to_unsigned(16#0#, 3);
        END IF;
      WHEN "100" =>
        SDFCummutator_wrState_next <= to_unsigned(16#4#, 3);
        SDFCummutator_wrEnb_reg_next <= '0';
        SDFCummutator_wrEnb_xmem_next <= '0';
        IF btfout_vld = '1' THEN 
          SDFCummutator_wrState_next <= to_unsigned(16#2#, 3);
          SDFCummutator_wrAddr_reg_next <= to_unsigned(16#00#, 5);
          SDFCummutator_wrEnb_reg_next <= '1';
          SDFCummutator_wrData_re_reg_next <= btf2_re_signed;
          SDFCummutator_wrData_im_reg_next <= btf2_im_signed;
        END IF;
      WHEN OTHERS => 
        SDFCummutator_wrState_next <= to_unsigned(16#0#, 3);
        SDFCummutator_wrAddr_reg_next <= to_unsigned(16#00#, 5);
        SDFCummutator_wrEnb_reg_next <= dinf_vld;
        SDFCummutator_wrData_re_reg_next <= dinf_re_signed;
        SDFCummutator_wrData_im_reg_next <= dinf_im_signed;
    END CASE;
    wrData_re_tmp <= SDFCummutator_wrData_re_reg;
    wrData_im_tmp <= SDFCummutator_wrData_im_reg;
    wrAddr_tmp <= SDFCummutator_wrAddr_reg;
    wrEnb <= SDFCummutator_wrEnb_reg;
    xData_re <= SDFCummutator_wrXData_re_reg;
    xData_im <= SDFCummutator_wrXData_im_reg;
    wrXAddr <= SDFCummutator_xWrAddr;
    wrXEnb <= SDFCummutator_wrxEnb_reg;
    rdXAddr <= SDFCummutator_xRdAddr;
    xX_vld <= SDFCummutator_xX_vld_reg;
    dout0_re <= SDFCummutator_out_re;
    dout0_im <= SDFCummutator_out_im;
    dout0_vld <= SDFCummutator_out_vld;
  END PROCESS SDFCummutator_output;


  wrData_re <= std_logic_vector(wrData_re_tmp);

  wrData_im <= std_logic_vector(wrData_im_tmp);

  wrAddr <= std_logic_vector(wrAddr_tmp);

  xX_re_signed <= signed(xX_re);

  xX_im_signed <= signed(xX_im);

  -- SDFOutmux
  SDFOutmux_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          SDFOutmux_btf2Pipe_re <= to_signed(16#000000#, 22);
          SDFOutmux_btf2Pipe_im <= to_signed(16#000000#, 22);
          SDFOutmux_btfPipe_vld <= '0';
        ELSE 
          SDFOutmux_btf2Pipe_re <= SDFOutmux_btf2Pipe_re_next;
          SDFOutmux_btf2Pipe_im <= SDFOutmux_btf2Pipe_im_next;
          SDFOutmux_btfPipe_vld <= SDFOutmux_btfPipe_vld_next;
        END IF;
      END IF;
    END IF;
  END PROCESS SDFOutmux_process;

  SDFOutmux_output : PROCESS (SDFOutmux_btf2Pipe_im, SDFOutmux_btf2Pipe_re, SDFOutmux_btfPipe_vld, dout0_im,
       dout0_re, dout0_vld, xX_im_signed, xX_re_signed, xX_vld)
  BEGIN
    SDFOutmux_btf2Pipe_re_next <= SDFOutmux_btf2Pipe_re;
    SDFOutmux_btf2Pipe_im_next <= SDFOutmux_btf2Pipe_im;
    IF dout0_vld = '1' THEN 
      SDFOutmux_btf2Pipe_re_next <= dout0_re;
      SDFOutmux_btf2Pipe_im_next <= dout0_im;
      SDFOutmux_btfPipe_vld_next <= '1';
    ELSIF xX_vld = '1' THEN 
      SDFOutmux_btf2Pipe_re_next <= xX_re_signed;
      SDFOutmux_btf2Pipe_im_next <= xX_im_signed;
      SDFOutmux_btfPipe_vld_next <= '1';
    ELSE 
      SDFOutmux_btfPipe_vld_next <= '0';
    END IF;
    dout_6_1_re_tmp <= SDFOutmux_btf2Pipe_re;
    dout_6_1_im_tmp <= SDFOutmux_btf2Pipe_im;
    dout_6_1_vld <= SDFOutmux_btfPipe_vld;
  END PROCESS SDFOutmux_output;


  dout_6_1_re <= std_logic_vector(dout_6_1_re_tmp);

  dout_6_1_im <= std_logic_vector(dout_6_1_im_tmp);

END rtl;

