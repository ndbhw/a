-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_Output_Interfacing IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        reset                             :   IN    std_logic;
        PSSDone                           :   IN    std_logic;
        PSSSuccess                        :   IN    std_logic;
        SSSDone                           :   IN    std_logic;
        SSSSuccess                        :   IN    std_logic;
        NCellIDIn                         :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        TDDModeIn                         :   IN    std_logic;
        timingOffsetIn                    :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
        NCellIDOut                        :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
        TDDModeOut                        :   OUT   std_logic;
        timingOffsetOut                   :   OUT   std_logic_vector(14 DOWNTO 0);  -- ufix15
        cellDetected                      :   OUT   std_logic;
        cellsearchDone                    :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Output_Interfacing;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Output_Interfacing IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_Detection_Status
    PORT( PSSDone                         :   IN    std_logic;
          PSSSuccess                      :   IN    std_logic;
          SSSDone                         :   IN    std_logic;
          SSSSuccess                      :   IN    std_logic;
          cellDetectedStb                 :   OUT   std_logic;
          cellSearchDoneStb               :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_Detection_Status
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Detection_Status(rtl);

  -- Signals
  SIGNAL cellDetectedStb                  : std_logic;
  SIGNAL cellSearchDoneStb                : std_logic;
  SIGNAL NCellIDIn_unsigned               : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Unit_Delay_Enabled_Resettable_Synchronous_out1 : unsigned(8 DOWNTO 0) := to_unsigned(16#000#, 9);  -- ufix9
  SIGNAL Unit_Delay_Enabled_Resettable_Synchronous1_out1 : std_logic := '0';
  SIGNAL timingOffsetIn_unsigned          : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL Unit_Delay_Enabled_Resettable_Synchronous2_out1 : unsigned(14 DOWNTO 0) := to_unsigned(16#0000#, 15);  -- ufix15
  SIGNAL Unit_Delay_Enabled_Resettable_Synchronous4_out1 : std_logic := '0';
  SIGNAL Unit_Delay_Enabled_Resettable_Synchronous3_out1 : std_logic := '0';

BEGIN
  UDetection_Status : ltehdlDownlinkSyncDemod_Detection_Status
    PORT MAP( PSSDone => PSSDone,
              PSSSuccess => PSSSuccess,
              SSSDone => SSSDone,
              SSSSuccess => SSSSuccess,
              cellDetectedStb => cellDetectedStb,
              cellSearchDoneStb => cellSearchDoneStb
              );

  NCellIDIn_unsigned <= unsigned(NCellIDIn);

  Unit_Delay_Enabled_Resettable_Synchronous_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        IF reset = '1' THEN
          Unit_Delay_Enabled_Resettable_Synchronous_out1 <= to_unsigned(16#000#, 9);
        ELSIF cellDetectedStb = '1' THEN
          Unit_Delay_Enabled_Resettable_Synchronous_out1 <= NCellIDIn_unsigned;
        END IF;
      END IF;
    END IF;
  END PROCESS Unit_Delay_Enabled_Resettable_Synchronous_process;


  NCellIDOut <= std_logic_vector(Unit_Delay_Enabled_Resettable_Synchronous_out1);

  Unit_Delay_Enabled_Resettable_Synchronous1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        IF reset = '1' THEN
          Unit_Delay_Enabled_Resettable_Synchronous1_out1 <= '0';
        ELSIF cellDetectedStb = '1' THEN
          Unit_Delay_Enabled_Resettable_Synchronous1_out1 <= TDDModeIn;
        END IF;
      END IF;
    END IF;
  END PROCESS Unit_Delay_Enabled_Resettable_Synchronous1_process;


  timingOffsetIn_unsigned <= unsigned(timingOffsetIn);

  Unit_Delay_Enabled_Resettable_Synchronous2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        IF reset = '1' THEN
          Unit_Delay_Enabled_Resettable_Synchronous2_out1 <= to_unsigned(16#0000#, 15);
        ELSIF cellDetectedStb = '1' THEN
          Unit_Delay_Enabled_Resettable_Synchronous2_out1 <= timingOffsetIn_unsigned;
        END IF;
      END IF;
    END IF;
  END PROCESS Unit_Delay_Enabled_Resettable_Synchronous2_process;


  timingOffsetOut <= std_logic_vector(Unit_Delay_Enabled_Resettable_Synchronous2_out1);

  Unit_Delay_Enabled_Resettable_Synchronous4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        IF reset = '1' THEN
          Unit_Delay_Enabled_Resettable_Synchronous4_out1 <= '0';
        ELSIF cellDetectedStb = '1' THEN
          Unit_Delay_Enabled_Resettable_Synchronous4_out1 <= cellDetectedStb;
        END IF;
      END IF;
    END IF;
  END PROCESS Unit_Delay_Enabled_Resettable_Synchronous4_process;


  Unit_Delay_Enabled_Resettable_Synchronous3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        IF reset = '1' THEN
          Unit_Delay_Enabled_Resettable_Synchronous3_out1 <= '0';
        ELSIF cellSearchDoneStb = '1' THEN
          Unit_Delay_Enabled_Resettable_Synchronous3_out1 <= cellSearchDoneStb;
        END IF;
      END IF;
    END IF;
  END PROCESS Unit_Delay_Enabled_Resettable_Synchronous3_process;


  TDDModeOut <= Unit_Delay_Enabled_Resettable_Synchronous1_out1;

  cellDetected <= Unit_Delay_Enabled_Resettable_Synchronous4_out1;

  cellsearchDone <= Unit_Delay_Enabled_Resettable_Synchronous3_out1;

END rtl;

