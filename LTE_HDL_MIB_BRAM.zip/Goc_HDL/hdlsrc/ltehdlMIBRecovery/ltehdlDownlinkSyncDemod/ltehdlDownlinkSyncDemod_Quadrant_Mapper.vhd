-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_Quadrant_Mapper IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        xin                               :   IN    std_logic_vector(24 DOWNTO 0);  -- ufix25
        yin                               :   IN    std_logic_vector(24 DOWNTO 0);  -- ufix25
        xout                              :   OUT   std_logic_vector(24 DOWNTO 0);  -- ufix25
        yout                              :   OUT   std_logic_vector(24 DOWNTO 0);  -- ufix25
        QA_Control                        :   OUT   std_logic_vector(4 DOWNTO 0)  -- ufix5
        );
END ltehdlDownlinkSyncDemod_Quadrant_Mapper;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Quadrant_Mapper IS

  -- Signals
  SIGNAL xin_signed                       : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL abs_rsvd_y                       : signed(25 DOWNTO 0);  -- sfix26_En23
  SIGNAL xAbs                             : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL xAbsReg                          : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin_signed                       : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL abs_rsvd_y_1                     : signed(25 DOWNTO 0);  -- sfix26_En23
  SIGNAL yAbs                             : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yAbsReg                          : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL XGreaterThanY                    : std_logic;  -- ufix1
  SIGNAL xout_1                           : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout_1                           : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL in2reg                           : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yZero                            : std_logic;  -- ufix1
  SIGNAL in1reg                           : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL xPositive                        : std_logic;  -- ufix1
  SIGNAL yZeroXPositive                   : std_logic;  -- ufix1
  SIGNAL xNegative                        : std_logic;  -- ufix1
  SIGNAL yZeroXNegative                   : std_logic;  -- ufix1
  SIGNAL yNegative                        : std_logic;  -- ufix1
  SIGNAL qcControl                        : unsigned(4 DOWNTO 0);  -- ufix5

BEGIN
  xin_signed <= signed(xin);

  
  abs_rsvd_y <=  - (resize(xin_signed, 26)) WHEN xin_signed < to_signed(16#0000000#, 25) ELSE
      resize(xin_signed, 26);
  xAbs <= abs_rsvd_y(24 DOWNTO 0);

  DelayxAbs_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xAbsReg <= xAbs;
      END IF;
    END IF;
  END PROCESS DelayxAbs_process;


  yin_signed <= signed(yin);

  
  abs_rsvd_y_1 <=  - (resize(yin_signed, 26)) WHEN yin_signed < to_signed(16#0000000#, 25) ELSE
      resize(yin_signed, 26);
  yAbs <= abs_rsvd_y_1(24 DOWNTO 0);

  DelayyAbs_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yAbsReg <= yAbs;
      END IF;
    END IF;
  END PROCESS DelayyAbs_process;


  
  XGreaterThanY <= '1' WHEN xAbsReg > yAbsReg ELSE
      '0';

  
  xout_1 <= yAbsReg WHEN XGreaterThanY = '0' ELSE
      xAbsReg;

  xout <= std_logic_vector(xout_1);

  
  yout_1 <= xAbsReg WHEN XGreaterThanY = '0' ELSE
      yAbsReg;

  yout <= std_logic_vector(yout_1);

  Delayin2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        in2reg <= yin_signed;
      END IF;
    END IF;
  END PROCESS Delayin2_process;


  
  yZero <= '1' WHEN in2reg = to_signed(16#0000000#, 25) ELSE
      '0';

  Delayin1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        in1reg <= xin_signed;
      END IF;
    END IF;
  END PROCESS Delayin1_process;


  
  xPositive <= '1' WHEN in1reg >= to_signed(16#0000000#, 25) ELSE
      '0';

  yZeroXPositive <= yZero AND xPositive;

  
  xNegative <= '1' WHEN in1reg < to_signed(16#0000000#, 25) ELSE
      '0';

  yZeroXNegative <= yZero AND xNegative;

  
  yNegative <= '1' WHEN in2reg < to_signed(16#0000000#, 25) ELSE
      '0';

  qcControl <= unsigned'(yZeroXPositive & yZeroXNegative & XGreaterThanY & xNegative & yNegative);

  QA_Control <= std_logic_vector(qcControl);

END rtl;

