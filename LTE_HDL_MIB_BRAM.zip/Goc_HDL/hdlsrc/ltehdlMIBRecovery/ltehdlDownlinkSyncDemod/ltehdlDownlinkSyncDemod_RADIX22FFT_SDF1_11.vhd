-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_11 IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        din_11_re_dly                     :   IN    std_logic_vector(25 DOWNTO 0);  -- ufix26
        din_11_im_dly                     :   IN    std_logic_vector(25 DOWNTO 0);  -- ufix26
        din_11_vld_dly                    :   IN    std_logic;
        rd_11_Addr                        :   IN    std_logic;
        rd_11_Enb_dly                     :   IN    std_logic;
        twdl_11_re                        :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        twdl_11_im                        :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        proc_11_enb                       :   IN    std_logic;
        syncReset                         :   IN    std_logic;
        dout_11_re                        :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
        dout_11_im                        :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
        dout_11_vld                       :   OUT   std_logic;
        dinXTwdl_11_vld                   :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_11;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_11 IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_Complex3Multiply_block3
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          din_re                          :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
          din_im                          :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
          din_11_vld_dly                  :   IN    std_logic;
          twdl_11_re                      :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          twdl_11_im                      :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          syncReset                       :   IN    std_logic;
          dinXTwdl_re                     :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
          dinXTwdl_im                     :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
          dinXTwdl_11_vld                 :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_SDFCommutator11
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          din_11_vld_dly                  :   IN    std_logic;
          xf_re                           :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
          xf_im                           :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
          xf_vld                          :   IN    std_logic;
          dinXTwdlf_re                    :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
          dinXTwdlf_im                    :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
          dinxTwdlf_vld                   :   IN    std_logic;
          btf1_re                         :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
          btf1_im                         :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
          btf2_re                         :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
          btf2_im                         :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
          btf_vld                         :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          wrData_re                       :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
          wrData_im                       :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
          wrAddr                          :   OUT   std_logic;  -- ufix1
          wrEnb                           :   OUT   std_logic;
          dout_11_re                      :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
          dout_11_im                      :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
          dout_11_vld                     :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_Complex3Multiply_block3
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Complex3Multiply_block3(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_SDFCommutator11
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_SDFCommutator11(rtl);

  -- Signals
  SIGNAL din_11_re_dly_signed             : signed(25 DOWNTO 0);  -- sfix26_En15
  SIGNAL din_re                           : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL din_11_im_dly_signed             : signed(25 DOWNTO 0);  -- sfix26_En15
  SIGNAL din_im                           : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL dinXTwdl_re                      : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL dinXTwdl_im                      : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL dinXTwdl_11_vld_1                : std_logic;
  SIGNAL dinXTwdl_re_signed               : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL dinXTwdl_im_signed               : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL x_vld                            : std_logic := '0';
  SIGNAL btf2_im                          : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL btf2_re                          : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL btf1_im                          : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL btf1_re                          : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL dinXTwdlf_im                     : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL dinXTwdlf_re                     : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL xf_im                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En15
  SIGNAL wrData_im                        : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL wrData_im_signed                 : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL wrData_re                        : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL wrData_re_signed                 : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL wrAddr                           : std_logic;  -- ufix1
  SIGNAL wrEnb                            : std_logic;
  SIGNAL twoLocationReg_0_MEM_re_0        : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27
  SIGNAL twoLocationReg_0_MEM_im_0        : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27
  SIGNAL twoLocationReg_0_MEM_re_1        : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27
  SIGNAL twoLocationReg_0_MEM_im_1        : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27
  SIGNAL twoLocationReg_0_dout_re_reg     : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27
  SIGNAL twoLocationReg_0_dout_im_reg     : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27
  SIGNAL twoLocationReg_0_MEM_re_0_next   : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL twoLocationReg_0_MEM_im_0_next   : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL twoLocationReg_0_MEM_re_1_next   : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL twoLocationReg_0_MEM_im_1_next   : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL twoLocationReg_0_dout_re_reg_next : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL twoLocationReg_0_dout_im_reg_next : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL x_re                             : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL x_im                             : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL Radix22ButterflyG1_btf1_re_reg   : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28
  SIGNAL Radix22ButterflyG1_btf1_im_reg   : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28
  SIGNAL Radix22ButterflyG1_btf2_re_reg   : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28
  SIGNAL Radix22ButterflyG1_btf2_im_reg   : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28
  SIGNAL Radix22ButterflyG1_dinXtwdl_re_dly1 : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27
  SIGNAL Radix22ButterflyG1_dinXtwdl_im_dly1 : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27
  SIGNAL Radix22ButterflyG1_dinXtwdl_re_dly2 : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27
  SIGNAL Radix22ButterflyG1_dinXtwdl_im_dly2 : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27
  SIGNAL Radix22ButterflyG1_dinXtwdl_vld_dly1 : std_logic := '0';
  SIGNAL Radix22ButterflyG1_dinXtwdl_vld_dly2 : std_logic := '0';
  SIGNAL Radix22ButterflyG1_btf1_re_reg_next : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Radix22ButterflyG1_btf1_im_reg_next : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Radix22ButterflyG1_btf2_re_reg_next : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Radix22ButterflyG1_btf2_im_reg_next : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL xf_re                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En15
  SIGNAL xf_vld                           : std_logic := '0';
  SIGNAL dinxTwdlf_vld                    : std_logic;
  SIGNAL btf_vld                          : std_logic := '0';
  SIGNAL dout_11_re_tmp                   : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL dout_11_im_tmp                   : std_logic_vector(26 DOWNTO 0);  -- ufix27

BEGIN
  UMUL3_4 : ltehdlDownlinkSyncDemod_Complex3Multiply_block3
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              din_re => std_logic_vector(din_re),  -- ufix27
              din_im => std_logic_vector(din_im),  -- ufix27
              din_11_vld_dly => din_11_vld_dly,
              twdl_11_re => twdl_11_re,  -- ufix16
              twdl_11_im => twdl_11_im,  -- ufix16
              syncReset => syncReset,
              dinXTwdl_re => dinXTwdl_re,  -- ufix27
              dinXTwdl_im => dinXTwdl_im,  -- ufix27
              dinXTwdl_11_vld => dinXTwdl_11_vld_1
              );

  USDFCOMMUTATOR_11 : ltehdlDownlinkSyncDemod_SDFCommutator11
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              din_11_vld_dly => din_11_vld_dly,
              xf_re => std_logic_vector(xf_re),  -- ufix27
              xf_im => std_logic_vector(xf_im),  -- ufix27
              xf_vld => xf_vld,
              dinXTwdlf_re => std_logic_vector(dinXTwdlf_re),  -- ufix27
              dinXTwdlf_im => std_logic_vector(dinXTwdlf_im),  -- ufix27
              dinxTwdlf_vld => dinxTwdlf_vld,
              btf1_re => std_logic_vector(btf1_re),  -- ufix27
              btf1_im => std_logic_vector(btf1_im),  -- ufix27
              btf2_re => std_logic_vector(btf2_re),  -- ufix27
              btf2_im => std_logic_vector(btf2_im),  -- ufix27
              btf_vld => btf_vld,
              syncReset => syncReset,
              wrData_re => wrData_re,  -- ufix27
              wrData_im => wrData_im,  -- ufix27
              wrAddr => wrAddr,  -- ufix1
              wrEnb => wrEnb,
              dout_11_re => dout_11_re_tmp,  -- ufix27
              dout_11_im => dout_11_im_tmp,  -- ufix27
              dout_11_vld => dout_11_vld
              );

  din_11_re_dly_signed <= signed(din_11_re_dly);

  din_re <= resize(din_11_re_dly_signed, 27);

  din_11_im_dly_signed <= signed(din_11_im_dly);

  din_im <= resize(din_11_im_dly_signed, 27);

  dinXTwdl_re_signed <= signed(dinXTwdl_re);

  dinXTwdl_im_signed <= signed(dinXTwdl_im);

  intdelay_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          x_vld <= '0';
        ELSE 
          x_vld <= rd_11_Enb_dly;
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_process;


  wrData_im_signed <= signed(wrData_im);

  wrData_re_signed <= signed(wrData_re);

  -- twoLocationReg_0
  twoLocationReg_0_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          twoLocationReg_0_MEM_re_0 <= to_signed(16#0000000#, 27);
          twoLocationReg_0_MEM_im_0 <= to_signed(16#0000000#, 27);
          twoLocationReg_0_MEM_re_1 <= to_signed(16#0000000#, 27);
          twoLocationReg_0_MEM_im_1 <= to_signed(16#0000000#, 27);
          twoLocationReg_0_dout_re_reg <= to_signed(16#0000000#, 27);
          twoLocationReg_0_dout_im_reg <= to_signed(16#0000000#, 27);
        ELSE 
          twoLocationReg_0_MEM_re_0 <= twoLocationReg_0_MEM_re_0_next;
          twoLocationReg_0_MEM_im_0 <= twoLocationReg_0_MEM_im_0_next;
          twoLocationReg_0_MEM_re_1 <= twoLocationReg_0_MEM_re_1_next;
          twoLocationReg_0_MEM_im_1 <= twoLocationReg_0_MEM_im_1_next;
          twoLocationReg_0_dout_re_reg <= twoLocationReg_0_dout_re_reg_next;
          twoLocationReg_0_dout_im_reg <= twoLocationReg_0_dout_im_reg_next;
        END IF;
      END IF;
    END IF;
  END PROCESS twoLocationReg_0_process;

  twoLocationReg_0_output : PROCESS (rd_11_Addr, twoLocationReg_0_MEM_im_0, twoLocationReg_0_MEM_im_1,
       twoLocationReg_0_MEM_re_0, twoLocationReg_0_MEM_re_1,
       twoLocationReg_0_dout_im_reg, twoLocationReg_0_dout_re_reg, wrAddr,
       wrData_im_signed, wrData_re_signed, wrEnb)
  BEGIN
    twoLocationReg_0_MEM_re_0_next <= twoLocationReg_0_MEM_re_0;
    twoLocationReg_0_MEM_im_0_next <= twoLocationReg_0_MEM_im_0;
    twoLocationReg_0_MEM_re_1_next <= twoLocationReg_0_MEM_re_1;
    twoLocationReg_0_MEM_im_1_next <= twoLocationReg_0_MEM_im_1;
    IF rd_11_Addr = '1' THEN 
      twoLocationReg_0_dout_re_reg_next <= twoLocationReg_0_MEM_re_1;
      twoLocationReg_0_dout_im_reg_next <= twoLocationReg_0_MEM_im_1;
    ELSE 
      twoLocationReg_0_dout_re_reg_next <= twoLocationReg_0_MEM_re_0;
      twoLocationReg_0_dout_im_reg_next <= twoLocationReg_0_MEM_im_0;
    END IF;
    IF wrEnb = '1' THEN 
      IF wrAddr = '1' THEN 
        twoLocationReg_0_MEM_re_1_next <= wrData_re_signed;
        twoLocationReg_0_MEM_im_1_next <= wrData_im_signed;
      ELSE 
        twoLocationReg_0_MEM_re_0_next <= wrData_re_signed;
        twoLocationReg_0_MEM_im_0_next <= wrData_im_signed;
      END IF;
    END IF;
    x_re <= twoLocationReg_0_dout_re_reg;
    x_im <= twoLocationReg_0_dout_im_reg;
  END PROCESS twoLocationReg_0_output;


  -- Radix22ButterflyG1
  Radix22ButterflyG1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          Radix22ButterflyG1_btf1_re_reg <= to_signed(16#0000000#, 28);
          Radix22ButterflyG1_btf1_im_reg <= to_signed(16#0000000#, 28);
          Radix22ButterflyG1_btf2_re_reg <= to_signed(16#0000000#, 28);
          Radix22ButterflyG1_btf2_im_reg <= to_signed(16#0000000#, 28);
          xf_re <= to_signed(16#0000000#, 27);
          xf_im <= to_signed(16#0000000#, 27);
          xf_vld <= '0';
          Radix22ButterflyG1_dinXtwdl_re_dly1 <= to_signed(16#0000000#, 27);
          Radix22ButterflyG1_dinXtwdl_im_dly1 <= to_signed(16#0000000#, 27);
          Radix22ButterflyG1_dinXtwdl_re_dly2 <= to_signed(16#0000000#, 27);
          Radix22ButterflyG1_dinXtwdl_im_dly2 <= to_signed(16#0000000#, 27);
          Radix22ButterflyG1_dinXtwdl_vld_dly1 <= '0';
          Radix22ButterflyG1_dinXtwdl_vld_dly2 <= '0';
          btf_vld <= '0';
        ELSE 
          Radix22ButterflyG1_btf1_re_reg <= Radix22ButterflyG1_btf1_re_reg_next;
          Radix22ButterflyG1_btf1_im_reg <= Radix22ButterflyG1_btf1_im_reg_next;
          Radix22ButterflyG1_btf2_re_reg <= Radix22ButterflyG1_btf2_re_reg_next;
          Radix22ButterflyG1_btf2_im_reg <= Radix22ButterflyG1_btf2_im_reg_next;
          btf_vld <= Radix22ButterflyG1_dinXtwdl_vld_dly2;
          Radix22ButterflyG1_dinXtwdl_vld_dly2 <= Radix22ButterflyG1_dinXtwdl_vld_dly1;
          Radix22ButterflyG1_dinXtwdl_re_dly2 <= Radix22ButterflyG1_dinXtwdl_re_dly1;
          Radix22ButterflyG1_dinXtwdl_im_dly2 <= Radix22ButterflyG1_dinXtwdl_im_dly1;
          Radix22ButterflyG1_dinXtwdl_re_dly1 <= dinXTwdl_re_signed;
          Radix22ButterflyG1_dinXtwdl_im_dly1 <= dinXTwdl_im_signed;
          xf_re <= x_re;
          xf_im <= x_im;
          xf_vld <= x_vld;
          Radix22ButterflyG1_dinXtwdl_vld_dly1 <= proc_11_enb AND dinXTwdl_11_vld_1;
        END IF;
      END IF;
    END IF;
  END PROCESS Radix22ButterflyG1_process;

  dinxTwdlf_vld <= ( NOT proc_11_enb) AND dinXTwdl_11_vld_1;
  Radix22ButterflyG1_btf1_re_reg_next <= (resize(x_re, 28)) + (resize(Radix22ButterflyG1_dinXtwdl_re_dly2, 28));
  Radix22ButterflyG1_btf2_re_reg_next <= (resize(x_re, 28)) - (resize(Radix22ButterflyG1_dinXtwdl_re_dly2, 28));
  Radix22ButterflyG1_btf1_im_reg_next <= (resize(x_im, 28)) + (resize(Radix22ButterflyG1_dinXtwdl_im_dly2, 28));
  Radix22ButterflyG1_btf2_im_reg_next <= (resize(x_im, 28)) - (resize(Radix22ButterflyG1_dinXtwdl_im_dly2, 28));
  dinXTwdlf_re <= dinXTwdl_re_signed;
  dinXTwdlf_im <= dinXTwdl_im_signed;
  btf1_re <= Radix22ButterflyG1_btf1_re_reg(26 DOWNTO 0);
  btf1_im <= Radix22ButterflyG1_btf1_im_reg(26 DOWNTO 0);
  btf2_re <= Radix22ButterflyG1_btf2_re_reg(26 DOWNTO 0);
  btf2_im <= Radix22ButterflyG1_btf2_im_reg(26 DOWNTO 0);

  dout_11_re <= dout_11_re_tmp;

  dout_11_im <= dout_11_im_tmp;

  dinXTwdl_11_vld <= dinXTwdl_11_vld_1;

END rtl;

