-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_SSS_Dot_Product IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        seqIn                             :   IN    std_logic_vector(1 DOWNTO 0);  -- sfix2
        seqNumIn                          :   IN    std_logic_vector(9 DOWNTO 0);  -- ufix10
        accStart                          :   IN    std_logic;
        accEnd                            :   IN    std_logic;
        correlation                       :   OUT   std_logic_vector(35 DOWNTO 0);  -- sfix36_En26
        threshold                         :   OUT   std_logic_vector(35 DOWNTO 0);  -- sfix36_En26
        validOut                          :   OUT   std_logic;
        seqNumOut                         :   OUT   std_logic_vector(9 DOWNTO 0)  -- ufix10
        );
END ltehdlDownlinkSyncDemod_SSS_Dot_Product;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_SSS_Dot_Product IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_Magnitude_Squared_0
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(17 DOWNTO 0);  -- sfix18_En13
          dataIn_im                       :   IN    std_logic_vector(17 DOWNTO 0);  -- sfix18_En13
          dataOut                         :   OUT   std_logic_vector(35 DOWNTO 0)  -- sfix36_En26
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Magnitude_Squared_1
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataOut                         :   OUT   std_logic_vector(31 DOWNTO 0)  -- sfix32_En30
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_ThresholdLimiter_block
    PORT( x_x                             :   IN    std_logic_vector(35 DOWNTO 0);  -- sfix36_En26
          y_y                             :   OUT   std_logic_vector(35 DOWNTO 0)  -- sfix36_En26
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_Magnitude_Squared_0
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Magnitude_Squared_0(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Magnitude_Squared_1
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Magnitude_Squared_1(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_ThresholdLimiter_block
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_ThresholdLimiter_block(rtl);

  -- Signals
  SIGNAL accEndReg                        : std_logic;
  SIGNAL Delay26_out1                     : std_logic := '0';
  SIGNAL Delay31_out1                     : std_logic := '0';
  SIGNAL Delay39_out1                     : std_logic := '0';
  SIGNAL Delay4_out1                      : std_logic := '0';
  SIGNAL Delay15_out1                     : std_logic := '0';
  SIGNAL Delay17_out1                     : std_logic := '0';
  SIGNAL Delay2_reg_rsvd                  : std_logic_vector(3 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [4]
  SIGNAL Delay2_out1                      : std_logic;
  SIGNAL Delay22_out1                     : std_logic := '0';
  SIGNAL Delay28_out1                     : std_logic := '0';
  SIGNAL Delay36_out1                     : std_logic := '0';
  SIGNAL accEnReg                         : std_logic := '0';
  SIGNAL Delay25_out1                     : std_logic := '0';
  SIGNAL Delay30_out1                     : std_logic := '0';
  SIGNAL Delay38_out1                     : std_logic := '0';
  SIGNAL accStartReg                      : std_logic := '0';
  SIGNAL seqIn_signed                     : signed(1 DOWNTO 0);  -- sfix2
  SIGNAL Delay23_out1                     : signed(1 DOWNTO 0) := to_signed(16#0#, 2);  -- sfix2
  SIGNAL Compare_To_Zero1_out1            : std_logic;
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay24_out1_re                  : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay24_out1_im                  : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Gain_cast                        : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL Gain_cast_1                      : signed(31 DOWNTO 0);  -- sfix32_En30
  SIGNAL Gain_cast_2                      : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL Gain_cast_3                      : signed(31 DOWNTO 0);  -- sfix32_En30
  SIGNAL Gain_out1_re                     : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Gain_out1_im                     : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL real1_out1_re                    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL real1_out1_im                    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay29_out1_re                  : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay29_out1_im                  : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Gain1_out1_re                    : signed(31 DOWNTO 0);  -- sfix32_En32
  SIGNAL Gain1_out1_im                    : signed(31 DOWNTO 0);  -- sfix32_En32
  SIGNAL Delay37_out1_re                  : signed(31 DOWNTO 0) := to_signed(0, 32);  -- sfix32_En32
  SIGNAL Delay37_out1_im                  : signed(31 DOWNTO 0) := to_signed(0, 32);  -- sfix32_En32
  SIGNAL Data_Type_Conversion4_out1_re    : signed(15 DOWNTO 0);  -- sfix16_En17
  SIGNAL Data_Type_Conversion4_out1_im    : signed(15 DOWNTO 0);  -- sfix16_En17
  SIGNAL Delay1_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En17
  SIGNAL Delay1_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En17
  SIGNAL acc_dataIn_re                    : signed(21 DOWNTO 0);  -- sfix22_En17
  SIGNAL acc_dataIn_im                    : signed(21 DOWNTO 0);  -- sfix22_En17
  SIGNAL acc_re                           : signed(21 DOWNTO 0) := to_signed(16#000000#, 22);  -- sfix22_En17
  SIGNAL acc_im                           : signed(21 DOWNTO 0) := to_signed(16#000000#, 22);  -- sfix22_En17
  SIGNAL Add_out1_re                      : signed(21 DOWNTO 0);  -- sfix22_En17
  SIGNAL Add_out1_im                      : signed(21 DOWNTO 0);  -- sfix22_En17
  SIGNAL Switch_out1_re                   : signed(21 DOWNTO 0);  -- sfix22_En17
  SIGNAL Switch_out1_im                   : signed(21 DOWNTO 0);  -- sfix22_En17
  SIGNAL Data_Type_Conversion1_out1_re    : signed(17 DOWNTO 0);  -- sfix18_En13
  SIGNAL Data_Type_Conversion1_out1_im    : signed(17 DOWNTO 0);  -- sfix18_En13
  SIGNAL Delay16_out1_re                  : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En13
  SIGNAL Delay16_out1_im                  : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En13
  SIGNAL Magnitude_Squared_0_dataOut      : std_logic_vector(35 DOWNTO 0);  -- ufix36
  SIGNAL Magnitude_Squared_0_dataOut_signed : signed(35 DOWNTO 0);  -- sfix36_En26
  SIGNAL Delay10_out1                     : signed(35 DOWNTO 0) := to_signed(0, 36);  -- sfix36_En26
  SIGNAL Delay33_out1                     : signed(1 DOWNTO 0) := to_signed(16#0#, 2);  -- sfix2
  SIGNAL Delay33_out1_is_not0             : std_logic;
  SIGNAL seqNumIn_unsigned                : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL Delay27_out1                     : unsigned(9 DOWNTO 0) := to_unsigned(16#000#, 10);  -- ufix10
  SIGNAL Compare_To_Constant_out1         : std_logic;
  SIGNAL Delay34_out1                     : std_logic := '0';
  SIGNAL calculateEnergy                  : std_logic;
  SIGNAL Delay41_out1                     : std_logic := '0';
  SIGNAL Delay13_out1                     : std_logic := '0';
  SIGNAL Delay14_reg_rsvd                 : std_logic_vector(3 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [4]
  SIGNAL Delay14_out1                     : std_logic;
  SIGNAL Delay19_reg_rsvd                 : std_logic_vector(3 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [4]
  SIGNAL Delay19_out1                     : std_logic;
  SIGNAL Delay32_out1_re                  : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay32_out1_im                  : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Gain2_out1_re                    : signed(31 DOWNTO 0);  -- sfix32_En31
  SIGNAL Gain2_out1_im                    : signed(31 DOWNTO 0);  -- sfix32_En31
  SIGNAL Delay40_out1_re                  : signed(31 DOWNTO 0) := to_signed(0, 32);  -- sfix32_En31
  SIGNAL Delay40_out1_im                  : signed(31 DOWNTO 0) := to_signed(0, 32);  -- sfix32_En31
  SIGNAL Data_Type_Conversion5_out1_re    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Data_Type_Conversion5_out1_im    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay11_out1_re                  : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay11_out1_im                  : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Magnitude_Squared_1_dataOut      : std_logic_vector(31 DOWNTO 0);  -- ufix32
  SIGNAL Magnitude_Squared_1_dataOut_signed : signed(31 DOWNTO 0);  -- sfix32_En30
  SIGNAL acc_dataIn                       : signed(37 DOWNTO 0);  -- sfix38_En30
  SIGNAL acc                              : signed(37 DOWNTO 0) := to_signed(0, 38);  -- sfix38_En30
  SIGNAL Add1_out1                        : signed(37 DOWNTO 0);  -- sfix38_En30
  SIGNAL Switch1_out1                     : signed(37 DOWNTO 0);  -- sfix38_En30
  SIGNAL Data_Type_Conversion3_out1       : signed(35 DOWNTO 0);  -- sfix36_En26
  SIGNAL Delay18_out1                     : signed(35 DOWNTO 0) := to_signed(0, 36);  -- sfix36_En26
  SIGNAL y_y                              : std_logic_vector(35 DOWNTO 0);  -- ufix36
  SIGNAL y_signed                         : signed(35 DOWNTO 0);  -- sfix36_En26
  SIGNAL Delay12_out1                     : signed(35 DOWNTO 0) := to_signed(0, 36);  -- sfix36_En26
  SIGNAL Delay20_out1                     : std_logic := '0';
  SIGNAL Delay35_out1                     : unsigned(9 DOWNTO 0) := to_unsigned(16#000#, 10);  -- ufix10
  SIGNAL Delay42_out1                     : unsigned(9 DOWNTO 0) := to_unsigned(16#000#, 10);  -- ufix10
  SIGNAL Delay3_out1                      : unsigned(9 DOWNTO 0) := to_unsigned(16#000#, 10);  -- ufix10
  SIGNAL Delay7_reg_rsvd                  : vector_of_unsigned10(0 TO 3) := (OTHERS => to_unsigned(16#000#, 10));  -- ufix10 [4]
  SIGNAL Delay7_out1                      : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL Delay8_out1                      : unsigned(9 DOWNTO 0) := to_unsigned(16#000#, 10);  -- ufix10
  SIGNAL Delay9_out1                      : unsigned(9 DOWNTO 0) := to_unsigned(16#000#, 10);  -- ufix10
  SIGNAL Delay21_out1                     : unsigned(9 DOWNTO 0) := to_unsigned(16#000#, 10);  -- ufix10

BEGIN
  -- SSS Threshold Scaling
  -- 
  -- Apply gain of sqrt(SSSThresholdScalingfactor) before squaring the signal to avoid the need for a wide multiplier.
  -- SSS Normalization Factor
  -- Magnitude squared
  -- Reduce the correlation result to 18 bits, keeping the MSBs.
  -- This facilitates efficient resource utilization on Xilinx and Intel FPGAs.
  -- Multiply dataIn by seqIn:
  -- since seqIn is always either -1 or 1, use a gain of -1 and a switch to invert dataIn when seqIn = -1.
  -- SSS correlation accumulator:
  -- The SSS consists of 62 complex values therefore
  -- 6 bits of headroom are required in the accumulator.
  -- Only compute signal energy the first time, since the data is repeated 336 times.

  UMagnitude_Squared_0 : ltehdlDownlinkSyncDemod_Magnitude_Squared_0
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => std_logic_vector(Delay16_out1_re),  -- sfix18_En13
              dataIn_im => std_logic_vector(Delay16_out1_im),  -- sfix18_En13
              dataOut => Magnitude_Squared_0_dataOut  -- sfix36_En26
              );

  UMagnitude_Squared_1 : ltehdlDownlinkSyncDemod_Magnitude_Squared_1
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => std_logic_vector(Delay11_out1_re),  -- sfix16_En15
              dataIn_im => std_logic_vector(Delay11_out1_im),  -- sfix16_En15
              dataOut => Magnitude_Squared_1_dataOut  -- sfix32_En30
              );

  UThresholdLimiter_1 : ltehdlDownlinkSyncDemod_ThresholdLimiter_block
    PORT MAP( x_x => std_logic_vector(Delay18_out1),  -- sfix36_En26
              y_y => y_y  -- sfix36_En26
              );

  accEndReg <= accEnd;

  Delay26_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay26_out1 <= accEndReg;
      END IF;
    END IF;
  END PROCESS Delay26_process;


  Delay31_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay31_out1 <= Delay26_out1;
      END IF;
    END IF;
  END PROCESS Delay31_process;


  Delay39_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay39_out1 <= Delay31_out1;
      END IF;
    END IF;
  END PROCESS Delay39_process;


  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay4_out1 <= Delay39_out1;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  Delay15_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay15_out1 <= Delay4_out1;
      END IF;
    END IF;
  END PROCESS Delay15_process;


  Delay17_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay17_out1 <= Delay15_out1;
      END IF;
    END IF;
  END PROCESS Delay17_process;


  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_reg_rsvd(0) <= Delay17_out1;
        Delay2_reg_rsvd(3 DOWNTO 1) <= Delay2_reg_rsvd(2 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS Delay2_process;

  Delay2_out1 <= Delay2_reg_rsvd(3);

  Delay22_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay22_out1 <= validIn;
      END IF;
    END IF;
  END PROCESS Delay22_process;


  Delay28_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay28_out1 <= Delay22_out1;
      END IF;
    END IF;
  END PROCESS Delay28_process;


  Delay36_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay36_out1 <= Delay28_out1;
      END IF;
    END IF;
  END PROCESS Delay36_process;


  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        accEnReg <= Delay36_out1;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  Delay25_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay25_out1 <= accStart;
      END IF;
    END IF;
  END PROCESS Delay25_process;


  Delay30_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay30_out1 <= Delay25_out1;
      END IF;
    END IF;
  END PROCESS Delay30_process;


  Delay38_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay38_out1 <= Delay30_out1;
      END IF;
    END IF;
  END PROCESS Delay38_process;


  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        accStartReg <= Delay38_out1;
      END IF;
    END IF;
  END PROCESS Delay6_process;


  seqIn_signed <= signed(seqIn);

  Delay23_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay23_out1 <= seqIn_signed;
      END IF;
    END IF;
  END PROCESS Delay23_process;


  
  Compare_To_Zero1_out1 <= '1' WHEN Delay23_out1 < to_signed(16#0#, 2) ELSE
      '0';

  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Delay24_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay24_out1_re <= dataIn_re_signed;
        Delay24_out1_im <= dataIn_im_signed;
      END IF;
    END IF;
  END PROCESS Delay24_process;


  Gain_cast <=  - (resize(Delay24_out1_re, 17));
  Gain_cast_1 <= Gain_cast & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0';
  Gain_out1_re <= Gain_cast_1(30 DOWNTO 15);
  Gain_cast_2 <=  - (resize(Delay24_out1_im, 17));
  Gain_cast_3 <= Gain_cast_2 & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0';
  Gain_out1_im <= Gain_cast_3(30 DOWNTO 15);

  
  real1_out1_re <= Delay24_out1_re WHEN Compare_To_Zero1_out1 = '0' ELSE
      Gain_out1_re;
  
  real1_out1_im <= Delay24_out1_im WHEN Compare_To_Zero1_out1 = '0' ELSE
      Gain_out1_im;

  Delay29_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay29_out1_re <= real1_out1_re;
        Delay29_out1_im <= real1_out1_im;
      END IF;
    END IF;
  END PROCESS Delay29_process;


  Gain1_out1_re <= to_signed(16#4106#, 16) * Delay29_out1_re;
  Gain1_out1_im <= to_signed(16#4106#, 16) * Delay29_out1_im;

  Delay37_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay37_out1_re <= Gain1_out1_re;
        Delay37_out1_im <= Gain1_out1_im;
      END IF;
    END IF;
  END PROCESS Delay37_process;


  Data_Type_Conversion4_out1_re <= Delay37_out1_re(30 DOWNTO 15) + ('0' & (Delay37_out1_re(14) AND (( NOT Delay37_out1_re(31)) OR (Delay37_out1_re(13) OR Delay37_out1_re(12) OR Delay37_out1_re(11) OR Delay37_out1_re(10) OR Delay37_out1_re(9) OR 
    Delay37_out1_re(8) OR Delay37_out1_re(7) OR Delay37_out1_re(6) OR Delay37_out1_re(5) OR Delay37_out1_re(4) OR Delay37_out1_re(3) OR Delay37_out1_re(2) OR Delay37_out1_re(1) OR Delay37_out1_re(0)))));
  Data_Type_Conversion4_out1_im <= Delay37_out1_im(30 DOWNTO 15) + ('0' & (Delay37_out1_im(14) AND (( NOT Delay37_out1_im(31)) OR (Delay37_out1_im(13) OR Delay37_out1_im(12) OR Delay37_out1_im(11) OR Delay37_out1_im(10) OR Delay37_out1_im(9) OR 
    Delay37_out1_im(8) OR Delay37_out1_im(7) OR Delay37_out1_im(6) OR Delay37_out1_im(5) OR Delay37_out1_im(4) OR Delay37_out1_im(3) OR Delay37_out1_im(2) OR Delay37_out1_im(1) OR Delay37_out1_im(0)))));

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1_re <= Data_Type_Conversion4_out1_re;
        Delay1_out1_im <= Data_Type_Conversion4_out1_im;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  acc_dataIn_re <= resize(Delay1_out1_re, 22);
  acc_dataIn_im <= resize(Delay1_out1_im, 22);

  Add_out1_re <= acc_dataIn_re + acc_re;
  Add_out1_im <= acc_dataIn_im + acc_im;

  
  Switch_out1_re <= Add_out1_re WHEN accStartReg = '0' ELSE
      acc_dataIn_re;
  
  Switch_out1_im <= Add_out1_im WHEN accStartReg = '0' ELSE
      acc_dataIn_im;

  Accumulator_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND accEnReg = '1' THEN
        acc_re <= Switch_out1_re;
        acc_im <= Switch_out1_im;
      END IF;
    END IF;
  END PROCESS Accumulator_process;


  Data_Type_Conversion1_out1_re <= acc_re(21 DOWNTO 4) + ('0' & (acc_re(3) AND (( NOT acc_re(21)) OR (acc_re(2) OR acc_re(1) OR acc_re(0)))));
  Data_Type_Conversion1_out1_im <= acc_im(21 DOWNTO 4) + ('0' & (acc_im(3) AND (( NOT acc_im(21)) OR (acc_im(2) OR acc_im(1) OR acc_im(0)))));

  Delay16_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay16_out1_re <= Data_Type_Conversion1_out1_re;
        Delay16_out1_im <= Data_Type_Conversion1_out1_im;
      END IF;
    END IF;
  END PROCESS Delay16_process;


  Magnitude_Squared_0_dataOut_signed <= signed(Magnitude_Squared_0_dataOut);

  Delay10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay2_out1 = '1' THEN
        Delay10_out1 <= Magnitude_Squared_0_dataOut_signed;
      END IF;
    END IF;
  END PROCESS Delay10_process;


  correlation <= std_logic_vector(Delay10_out1);

  Delay33_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay33_out1 <= Delay23_out1;
      END IF;
    END IF;
  END PROCESS Delay33_process;


  
  Delay33_out1_is_not0 <= '1' WHEN Delay33_out1 /= to_signed(16#0#, 2) ELSE
      '0';

  seqNumIn_unsigned <= unsigned(seqNumIn);

  Delay27_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay27_out1 <= seqNumIn_unsigned;
      END IF;
    END IF;
  END PROCESS Delay27_process;


  
  Compare_To_Constant_out1 <= '1' WHEN Delay27_out1 < to_unsigned(16#003#, 10) ELSE
      '0';

  Delay34_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay34_out1 <= Compare_To_Constant_out1;
      END IF;
    END IF;
  END PROCESS Delay34_process;


  calculateEnergy <= Delay33_out1_is_not0 AND Delay34_out1;

  Delay41_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay41_out1 <= calculateEnergy;
      END IF;
    END IF;
  END PROCESS Delay41_process;


  Delay13_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay13_out1 <= Delay41_out1;
      END IF;
    END IF;
  END PROCESS Delay13_process;


  Delay14_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay14_reg_rsvd(0) <= Delay13_out1;
        Delay14_reg_rsvd(3 DOWNTO 1) <= Delay14_reg_rsvd(2 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS Delay14_process;

  Delay14_out1 <= Delay14_reg_rsvd(3);

  Delay19_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay19_reg_rsvd(0) <= accStartReg;
        Delay19_reg_rsvd(3 DOWNTO 1) <= Delay19_reg_rsvd(2 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS Delay19_process;

  Delay19_out1 <= Delay19_reg_rsvd(3);

  Delay32_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay32_out1_re <= Delay24_out1_re;
        Delay32_out1_im <= Delay24_out1_im;
      END IF;
    END IF;
  END PROCESS Delay32_process;


  Gain2_out1_re <= to_signed(16#7A88#, 16) * Delay32_out1_re;
  Gain2_out1_im <= to_signed(16#7A88#, 16) * Delay32_out1_im;

  Delay40_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay40_out1_re <= Gain2_out1_re;
        Delay40_out1_im <= Gain2_out1_im;
      END IF;
    END IF;
  END PROCESS Delay40_process;


  Data_Type_Conversion5_out1_re <= Delay40_out1_re(31 DOWNTO 16) + ('0' & (Delay40_out1_re(15) AND (( NOT Delay40_out1_re(31)) OR (Delay40_out1_re(14) OR Delay40_out1_re(13) OR Delay40_out1_re(12) OR Delay40_out1_re(11) OR Delay40_out1_re(10) OR 
    Delay40_out1_re(9) OR Delay40_out1_re(8) OR Delay40_out1_re(7) OR Delay40_out1_re(6) OR Delay40_out1_re(5) OR Delay40_out1_re(4) OR Delay40_out1_re(3) OR Delay40_out1_re(2) OR Delay40_out1_re(1) OR Delay40_out1_re(0)))));
  Data_Type_Conversion5_out1_im <= Delay40_out1_im(31 DOWNTO 16) + ('0' & (Delay40_out1_im(15) AND (( NOT Delay40_out1_im(31)) OR (Delay40_out1_im(14) OR Delay40_out1_im(13) OR Delay40_out1_im(12) OR Delay40_out1_im(11) OR Delay40_out1_im(10) OR 
    Delay40_out1_im(9) OR Delay40_out1_im(8) OR Delay40_out1_im(7) OR Delay40_out1_im(6) OR Delay40_out1_im(5) OR Delay40_out1_im(4) OR Delay40_out1_im(3) OR Delay40_out1_im(2) OR Delay40_out1_im(1) OR Delay40_out1_im(0)))));

  Delay11_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay11_out1_re <= Data_Type_Conversion5_out1_re;
        Delay11_out1_im <= Data_Type_Conversion5_out1_im;
      END IF;
    END IF;
  END PROCESS Delay11_process;


  Magnitude_Squared_1_dataOut_signed <= signed(Magnitude_Squared_1_dataOut);

  acc_dataIn <= resize(Magnitude_Squared_1_dataOut_signed, 38);

  Add1_out1 <= acc_dataIn + acc;

  
  Switch1_out1 <= Add1_out1 WHEN Delay19_out1 = '0' ELSE
      acc_dataIn;

  Accumulator1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay14_out1 = '1' THEN
        acc <= Switch1_out1;
      END IF;
    END IF;
  END PROCESS Accumulator1_process;


  Data_Type_Conversion3_out1 <= (resize(acc(37 DOWNTO 4), 36)) + ('0' & (acc(3) AND (( NOT acc(37)) OR (acc(2) OR acc(1) OR acc(0)))));

  Delay18_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay18_out1 <= Data_Type_Conversion3_out1;
      END IF;
    END IF;
  END PROCESS Delay18_process;


  y_signed <= signed(y_y);

  Delay12_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay2_out1 = '1' THEN
        Delay12_out1 <= y_signed;
      END IF;
    END IF;
  END PROCESS Delay12_process;


  threshold <= std_logic_vector(Delay12_out1);

  Delay20_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay20_out1 <= Delay2_out1;
      END IF;
    END IF;
  END PROCESS Delay20_process;


  Delay35_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay35_out1 <= Delay27_out1;
      END IF;
    END IF;
  END PROCESS Delay35_process;


  Delay42_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay42_out1 <= Delay35_out1;
      END IF;
    END IF;
  END PROCESS Delay42_process;


  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1 <= Delay42_out1;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  Delay7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay7_reg_rsvd(0) <= Delay3_out1;
        Delay7_reg_rsvd(1 TO 3) <= Delay7_reg_rsvd(0 TO 2);
      END IF;
    END IF;
  END PROCESS Delay7_process;

  Delay7_out1 <= Delay7_reg_rsvd(3);

  Delay8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay8_out1 <= Delay7_out1;
      END IF;
    END IF;
  END PROCESS Delay8_process;


  Delay9_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay9_out1 <= Delay8_out1;
      END IF;
    END IF;
  END PROCESS Delay9_process;


  Delay21_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay2_out1 = '1' THEN
        Delay21_out1 <= Delay9_out1;
      END IF;
    END IF;
  END PROCESS Delay21_process;


  seqNumOut <= std_logic_vector(Delay21_out1);

  validOut <= Delay20_out1;

END rtl;

