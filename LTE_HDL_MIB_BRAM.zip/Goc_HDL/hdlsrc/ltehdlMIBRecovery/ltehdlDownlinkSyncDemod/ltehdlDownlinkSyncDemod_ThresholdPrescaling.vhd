-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_ThresholdPrescaling IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataOut_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_ThresholdPrescaling;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_ThresholdPrescaling IS

  -- Signals
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay8_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay8_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Gain_out1_re                     : signed(31 DOWNTO 0);  -- sfix32_En31
  SIGNAL Gain_out1_im                     : signed(31 DOWNTO 0);  -- sfix32_En31
  SIGNAL Delay9_out1_re                   : signed(31 DOWNTO 0) := to_signed(0, 32);  -- sfix32_En31
  SIGNAL Delay9_out1_im                   : signed(31 DOWNTO 0) := to_signed(0, 32);  -- sfix32_En31
  SIGNAL Data_Type_Conversion_out1_re     : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Data_Type_Conversion_out1_im     : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay2_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay2_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay10_out1                     : std_logic := '0';
  SIGNAL Delay11_out1                     : std_logic := '0';
  SIGNAL Delay1_out1                      : std_logic := '0';

BEGIN
  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Delay8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay8_out1_re <= dataIn_re_signed;
        Delay8_out1_im <= dataIn_im_signed;
      END IF;
    END IF;
  END PROCESS Delay8_process;


  Gain_out1_re <= to_signed(16#7A88#, 16) * Delay8_out1_re;
  Gain_out1_im <= to_signed(16#7A88#, 16) * Delay8_out1_im;

  Delay9_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay9_out1_re <= Gain_out1_re;
        Delay9_out1_im <= Gain_out1_im;
      END IF;
    END IF;
  END PROCESS Delay9_process;


  Data_Type_Conversion_out1_re <= Delay9_out1_re(31 DOWNTO 16) + ('0' & (Delay9_out1_re(15) AND (( NOT Delay9_out1_re(31)) OR (Delay9_out1_re(14) OR Delay9_out1_re(13) OR Delay9_out1_re(12) OR Delay9_out1_re(11) OR Delay9_out1_re(10) OR 
    Delay9_out1_re(9) OR Delay9_out1_re(8) OR Delay9_out1_re(7) OR Delay9_out1_re(6) OR Delay9_out1_re(5) OR Delay9_out1_re(4) OR Delay9_out1_re(3) OR Delay9_out1_re(2) OR Delay9_out1_re(1) OR Delay9_out1_re(0)))));
  Data_Type_Conversion_out1_im <= Delay9_out1_im(31 DOWNTO 16) + ('0' & (Delay9_out1_im(15) AND (( NOT Delay9_out1_im(31)) OR (Delay9_out1_im(14) OR Delay9_out1_im(13) OR Delay9_out1_im(12) OR Delay9_out1_im(11) OR Delay9_out1_im(10) OR 
    Delay9_out1_im(9) OR Delay9_out1_im(8) OR Delay9_out1_im(7) OR Delay9_out1_im(6) OR Delay9_out1_im(5) OR Delay9_out1_im(4) OR Delay9_out1_im(3) OR Delay9_out1_im(2) OR Delay9_out1_im(1) OR Delay9_out1_im(0)))));

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_out1_re <= Data_Type_Conversion_out1_re;
        Delay2_out1_im <= Data_Type_Conversion_out1_im;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  dataOut_re <= std_logic_vector(Delay2_out1_re);

  dataOut_im <= std_logic_vector(Delay2_out1_im);

  Delay10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay10_out1 <= validIn;
      END IF;
    END IF;
  END PROCESS Delay10_process;


  Delay11_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay11_out1 <= Delay10_out1;
      END IF;
    END IF;
  END PROCESS Delay11_process;


  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1 <= Delay11_out1;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  validOut <= Delay1_out1;

END rtl;

