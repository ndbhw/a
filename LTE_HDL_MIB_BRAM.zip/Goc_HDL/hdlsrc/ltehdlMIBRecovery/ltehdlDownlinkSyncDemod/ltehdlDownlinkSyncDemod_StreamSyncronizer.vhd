-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_StreamSyncronizer IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        pop                               :   IN    std_logic;
        dataIn                            :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30
        push                              :   IN    std_logic;
        dataOut                           :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_StreamSyncronizer;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_StreamSyncronizer IS

  -- Signals
  SIGNAL dataIn_unsigned                  : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL dataOut_tmp                      : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL wrAddr                           : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL rdAddr                           : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL dataOutReg                       : unsigned(29 DOWNTO 0);  -- ufix30
  SIGNAL validOutReg                      : std_logic;
  SIGNAL mem                              : vector_of_unsigned30(0 TO 3);  -- ufix30 [4]
  SIGNAL level                            : signed(15 DOWNTO 0);  -- int16
  SIGNAL wrAddr_next                      : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL rdAddr_next                      : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL dataOutReg_next                  : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL validOutReg_next                 : std_logic;
  SIGNAL mem_next                         : vector_of_unsigned30(0 TO 3);  -- ufix30_En24 [4]
  SIGNAL level_next                       : signed(15 DOWNTO 0);  -- int16

BEGIN
  dataIn_unsigned <= unsigned(dataIn);

  StreamSyncronizer_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        wrAddr <= to_unsigned(16#0#, 2);
        rdAddr <= to_unsigned(16#0#, 2);
        dataOutReg <= to_unsigned(16#00000000#, 30);
        validOutReg <= '0';
        mem <= (OTHERS => to_unsigned(16#00000000#, 30));
        level <= to_signed(16#0000#, 16);
      ELSIF enb = '1' THEN
        wrAddr <= wrAddr_next;
        rdAddr <= rdAddr_next;
        dataOutReg <= dataOutReg_next;
        validOutReg <= validOutReg_next;
        mem <= mem_next;
        level <= level_next;
      END IF;
    END IF;
  END PROCESS StreamSyncronizer_process;

  StreamSyncronizer_output : PROCESS (dataIn_unsigned, dataOutReg, level, mem, pop, push, rdAddr, validOutReg,
       wrAddr)
    VARIABLE level_temp : signed(15 DOWNTO 0);
    VARIABLE sub_temp : signed(16 DOWNTO 0);
    VARIABLE add_temp : signed(16 DOWNTO 0);
  BEGIN
    sub_temp := to_signed(16#00000#, 17);
    add_temp := to_signed(16#00000#, 17);
    level_temp := level;
    wrAddr_next <= wrAddr;
    rdAddr_next <= rdAddr;
    dataOutReg_next <= dataOutReg;
    mem_next <= mem;
    --------------------------------------------------------------------------
    -- Constants
    --------------------------------------------------------------------------
    -- Persistent variable initialization
    --------------------------------------------------------------------------
    -- Outputs
    --------------------------------------------------------------------------
    --------------------------------------------------------------------------
    -- Calculate next state values
    --------------------------------------------------------------------------
    IF pop = '1' THEN 
      dataOutReg_next <= mem(to_integer(rdAddr));
      rdAddr_next <= rdAddr + to_unsigned(16#1#, 2);
      sub_temp := resize(level, 17) - to_signed(16#00001#, 17);
      IF (sub_temp(16) = '0') AND (sub_temp(15) /= '0') THEN 
        level_temp := X"7FFF";
      ELSIF (sub_temp(16) = '1') AND (sub_temp(15) /= '1') THEN 
        level_temp := X"8000";
      ELSE 
        level_temp := sub_temp(15 DOWNTO 0);
      END IF;
    END IF;
    IF push = '1' THEN 
      mem_next(to_integer(wrAddr)) <= dataIn_unsigned;
      wrAddr_next <= wrAddr + to_unsigned(16#1#, 2);
      add_temp := resize(level_temp, 17) + to_signed(16#00001#, 17);
      IF (add_temp(16) = '0') AND (add_temp(15) /= '0') THEN 
        level_temp := X"7FFF";
      ELSIF (add_temp(16) = '1') AND (add_temp(15) /= '1') THEN 
        level_temp := X"8000";
      ELSE 
        level_temp := add_temp(15 DOWNTO 0);
      END IF;
    END IF;
    validOutReg_next <= pop;
    dataOut_tmp <= dataOutReg;
    validOut <= validOutReg;
    level_next <= level_temp;
  END PROCESS StreamSyncronizer_output;


  dataOut <= std_logic_vector(dataOut_tmp);

END rtl;

