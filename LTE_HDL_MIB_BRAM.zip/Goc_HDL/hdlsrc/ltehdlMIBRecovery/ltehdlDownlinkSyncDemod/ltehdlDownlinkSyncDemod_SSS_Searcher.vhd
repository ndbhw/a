-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_SSS_Searcher IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        startBuffering                    :   IN    std_logic;
        PSSEndTimingOffset                :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
        NCellID2                          :   IN    std_logic_vector(1 DOWNTO 0);  -- ufix2
        PSSDetected                       :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        NCellID                           :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
        done                              :   OUT   std_logic;
        success                           :   OUT   std_logic;
        timingOffset                      :   OUT   std_logic_vector(14 DOWNTO 0);  -- ufix15
        TDD                               :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_SSS_Searcher;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_SSS_Searcher IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_SSS_Search_Controller
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          startBuffering                  :   IN    std_logic;
          PSSEndTimingOffset              :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
          PSSDetected                     :   IN    std_logic;
          validIn                         :   IN    std_logic;
          modeDone                        :   IN    std_logic;
          SSSFound                        :   IN    std_logic;
          addr                            :   OUT   std_logic_vector(9 DOWNTO 0);  -- ufix10
          wrEn                            :   OUT   std_logic;
          rdEn                            :   OUT   std_logic;
          duplexMode                      :   OUT   std_logic;  -- ufix1
          SSSPSSPhaseAligned              :   OUT   std_logic;
          done                            :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_SinglePortRAM_generic
    GENERIC( AddrWidth                    : integer;
             DataWidth                    : integer
             );
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          din_re                          :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          din_im                          :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          addr                            :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          we                              :   IN    std_logic;
          dout_re                         :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          dout_im                         :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0)  -- generic width
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_FFT_HDL_Optimized_block
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          validIn                         :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Max_Likelihood_SSS
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          reset                           :   IN    std_logic;
          NCellID2                        :   IN    std_logic_vector(1 DOWNTO 0);  -- ufix2
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          duplexMode                      :   IN    std_logic;  -- ufix1
          NCellID                         :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
          halfFrameIndicator              :   OUT   std_logic;
          TDD                             :   OUT   std_logic;
          success                         :   OUT   std_logic;
          modeDone                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Determine_Frame_Timing
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          reset                           :   IN    std_logic;
          enable                          :   IN    std_logic;
          PSSTimingOffset                 :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
          TDD                             :   IN    std_logic;
          halfFrameIndicator              :   IN    std_logic;
          SSSPSSPhaseAligned              :   IN    std_logic;
          timingOffset                    :   OUT   std_logic_vector(14 DOWNTO 0)  -- ufix15
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_SSS_Search_Controller
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_SSS_Search_Controller(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_SinglePortRAM_generic
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_SinglePortRAM_generic(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_FFT_HDL_Optimized_block
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_FFT_HDL_Optimized_block(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Max_Likelihood_SSS
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Max_Likelihood_SSS(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Determine_Frame_Timing
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Determine_Frame_Timing(rtl);

  -- Signals
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_re_1                      : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL dataIn_im_1                      : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay3_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay3_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL validIn_1                        : std_logic := '0';
  SIGNAL duplexMode                       : std_logic;  -- ufix1
  SIGNAL Delay12_out1                     : std_logic := '0';  -- ufix1
  SIGNAL rdEn                             : std_logic;
  SIGNAL RAMValidOut                      : std_logic := '0';
  SIGNAL success_1                        : std_logic;
  SIGNAL success_2                        : std_logic;
  SIGNAL SSSFound                         : std_logic := '0';
  SIGNAL modeDone                         : std_logic;
  SIGNAL modeDone_1                       : std_logic;
  SIGNAL modeDone_2                       : std_logic := '0';
  SIGNAL addr                             : std_logic_vector(9 DOWNTO 0);  -- ufix10
  SIGNAL wrEn                             : std_logic;
  SIGNAL SSSPSSPhaseAligned               : std_logic;
  SIGNAL done_1                           : std_logic;
  SIGNAL RAMDataOut_re                    : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL RAMDataOut_im                    : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL FFTDataOut_re                    : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL FFTDataOut_im                    : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL FFTValidOut                      : std_logic;
  SIGNAL NCellID_1                        : std_logic_vector(8 DOWNTO 0);  -- ufix9
  SIGNAL halfFrameIndicator               : std_logic;
  SIGNAL TDD_1                            : std_logic;
  SIGNAL NCellID_unsigned                 : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL NCellID_tmp                      : unsigned(8 DOWNTO 0) := to_unsigned(16#000#, 9);  -- ufix9
  SIGNAL Logical_Operator_out1            : std_logic;
  SIGNAL timingOffset_tmp                 : std_logic_vector(14 DOWNTO 0);  -- ufix15
  SIGNAL PSSEndTimingOffset_unsigned      : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL NCellID2_unsigned                : unsigned(1 DOWNTO 0);  -- ufix2

BEGIN
  -- Introduce a 1 cycle delay to the data stream. This means that the PSS searcher outputs are advanced 1 cycle relative 
  -- to the the data stream, and simplifies the SSS state machine by giving it one cycle to respond to PSSDetected and 
  -- entering the WAITING_FOR_PSS_END state

  USSS_Search_Controller : ltehdlDownlinkSyncDemod_SSS_Search_Controller
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              startBuffering => startBuffering,
              PSSEndTimingOffset => PSSEndTimingOffset,  -- ufix15
              PSSDetected => PSSDetected,
              validIn => validIn_1,
              modeDone => modeDone_2,
              SSSFound => SSSFound,
              addr => addr,  -- ufix10
              wrEn => wrEn,
              rdEn => rdEn,
              duplexMode => duplexMode,  -- ufix1
              SSSPSSPhaseAligned => SSSPSSPhaseAligned,
              done => done_1
              );

  USingle_Port_RAM_System : ltehdlDownlinkSyncDemod_SinglePortRAM_generic
    GENERIC MAP( AddrWidth => 10,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb => enb,
              din_re => std_logic_vector(Delay3_out1_re),
              din_im => std_logic_vector(Delay3_out1_im),
              addr => addr,
              we => wrEn,
              dout_re => RAMDataOut_re,
              dout_im => RAMDataOut_im
              );

  UFFT_HDL_Optimized_1 : ltehdlDownlinkSyncDemod_FFT_HDL_Optimized_block
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => RAMDataOut_re,  -- ufix16
              dataIn_im => RAMDataOut_im,  -- ufix16
              validIn => RAMValidOut,
              syncReset => startBuffering,
              dataOut_re => FFTDataOut_re,  -- ufix16
              dataOut_im => FFTDataOut_im,  -- ufix16
              validOut => FFTValidOut
              );

  UMax_Likelihood_SSS : ltehdlDownlinkSyncDemod_Max_Likelihood_SSS
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              reset => startBuffering,
              NCellID2 => NCellID2,  -- ufix2
              dataIn_re => FFTDataOut_re,  -- sfix16_En15
              dataIn_im => FFTDataOut_im,  -- sfix16_En15
              validIn => FFTValidOut,
              duplexMode => Delay12_out1,  -- ufix1
              NCellID => NCellID_1,  -- ufix9
              halfFrameIndicator => halfFrameIndicator,
              TDD => TDD_1,
              success => success_1,
              modeDone => modeDone
              );

  UDetermine_Frame_Timing : ltehdlDownlinkSyncDemod_Determine_Frame_Timing
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              reset => startBuffering,
              enable => Logical_Operator_out1,
              PSSTimingOffset => PSSEndTimingOffset,  -- ufix15
              TDD => TDD_1,
              halfFrameIndicator => halfFrameIndicator,
              SSSPSSPhaseAligned => SSSPSSPhaseAligned,
              timingOffset => timingOffset_tmp  -- ufix15
              );

  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        dataIn_re_1 <= dataIn_re_signed;
        dataIn_im_1 <= dataIn_im_signed;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1_re <= dataIn_re_1;
        Delay3_out1_im <= dataIn_im_1;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        validIn_1 <= validIn;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  Delay12_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay12_out1 <= duplexMode;
      END IF;
    END IF;
  END PROCESS Delay12_process;


  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        RAMValidOut <= rdEn;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  success_2 <= success_1;

  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        SSSFound <= success_2;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  modeDone_1 <= modeDone;

  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        modeDone_2 <= modeDone_1;
      END IF;
    END IF;
  END PROCESS Delay6_process;


  NCellID_unsigned <= unsigned(NCellID_1);

  Delay8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        NCellID_tmp <= NCellID_unsigned;
      END IF;
    END IF;
  END PROCESS Delay8_process;


  NCellID <= std_logic_vector(NCellID_tmp);

  Delay10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        done <= done_1;
      END IF;
    END IF;
  END PROCESS Delay10_process;


  Delay11_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        success <= success_1;
      END IF;
    END IF;
  END PROCESS Delay11_process;


  Logical_Operator_out1 <= success_1 AND done_1;

  Delay13_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        TDD <= TDD_1;
      END IF;
    END IF;
  END PROCESS Delay13_process;


  timingOffset <= timingOffset_tmp;

END rtl;

