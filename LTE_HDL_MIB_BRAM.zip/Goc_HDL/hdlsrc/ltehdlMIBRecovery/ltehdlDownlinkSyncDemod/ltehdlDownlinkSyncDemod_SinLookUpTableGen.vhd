-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_SinLookUpTableGen IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        lutaddr                           :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
        lutSine                           :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
        );
END ltehdlDownlinkSyncDemod_SinLookUpTableGen;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_SinLookUpTableGen IS

  -- Constants
  CONSTANT DirectLookupTable_data         : vector_of_signed16(0 TO 2047) := 
    (to_signed(16#0000#, 16), to_signed(16#0006#, 16), to_signed(16#000D#, 16), to_signed(16#0013#, 16), to_signed(16#0019#, 16), to_signed(16#001F#, 16), to_signed(16#0026#, 16), to_signed(16#002C#, 16), to_signed(16#0032#, 16), to_signed(16#0039#, 
      16), to_signed(16#003F#, 16), to_signed(16#0045#, 16), to_signed(16#004B#, 16), to_signed(16#0052#, 16), to_signed(16#0058#, 16), to_signed(16#005E#, 16), to_signed(16#0065#, 16), to_signed(16#006B#, 16), to_signed(16#0071#, 16), 
      to_signed(16#0077#, 16), to_signed(16#007E#, 16), to_signed(16#0084#, 16), to_signed(16#008A#, 16), to_signed(16#0091#, 16), to_signed(16#0097#, 16), to_signed(16#009D#, 16), to_signed(16#00A3#, 16), to_signed(16#00AA#, 16), 
      to_signed(16#00B0#, 16), to_signed(16#00B6#, 16), to_signed(16#00BC#, 16), to_signed(16#00C3#, 16), to_signed(16#00C9#, 16), to_signed(16#00CF#, 16), to_signed(16#00D6#, 16), to_signed(16#00DC#, 16), to_signed(16#00E2#, 16), 
      to_signed(16#00E8#, 16), to_signed(16#00EF#, 16), to_signed(16#00F5#, 16), to_signed(16#00FB#, 16), to_signed(16#0102#, 16), to_signed(16#0108#, 16), to_signed(16#010E#, 16), to_signed(16#0114#, 16), to_signed(16#011B#, 16), 
      to_signed(16#0121#, 16), to_signed(16#0127#, 16), to_signed(16#012E#, 16), to_signed(16#0134#, 16), to_signed(16#013A#, 16), to_signed(16#0140#, 16), to_signed(16#0147#, 16), to_signed(16#014D#, 16), to_signed(16#0153#, 16), 
      to_signed(16#015A#, 16), to_signed(16#0160#, 16), to_signed(16#0166#, 16), to_signed(16#016C#, 16), to_signed(16#0173#, 16), to_signed(16#0179#, 16), to_signed(16#017F#, 16), to_signed(16#0186#, 16), to_signed(16#018C#, 16), 
      to_signed(16#0192#, 16), to_signed(16#0198#, 16), to_signed(16#019F#, 16), to_signed(16#01A5#, 16), to_signed(16#01AB#, 16), to_signed(16#01B1#, 16), to_signed(16#01B8#, 16), to_signed(16#01BE#, 16), to_signed(16#01C4#, 16), 
      to_signed(16#01CB#, 16), to_signed(16#01D1#, 16), to_signed(16#01D7#, 16), to_signed(16#01DD#, 16), to_signed(16#01E4#, 16), to_signed(16#01EA#, 16), to_signed(16#01F0#, 16), to_signed(16#01F7#, 16), to_signed(16#01FD#, 16), 
      to_signed(16#0203#, 16), to_signed(16#0209#, 16), to_signed(16#0210#, 16), to_signed(16#0216#, 16), to_signed(16#021C#, 16), to_signed(16#0223#, 16), to_signed(16#0229#, 16), to_signed(16#022F#, 16), to_signed(16#0235#, 16), 
      to_signed(16#023C#, 16), to_signed(16#0242#, 16), to_signed(16#0248#, 16), to_signed(16#024E#, 16), to_signed(16#0255#, 16), to_signed(16#025B#, 16), to_signed(16#0261#, 16), to_signed(16#0268#, 16), to_signed(16#026E#, 16), 
      to_signed(16#0274#, 16), to_signed(16#027A#, 16), to_signed(16#0281#, 16), to_signed(16#0287#, 16), to_signed(16#028D#, 16), to_signed(16#0294#, 16), to_signed(16#029A#, 16), to_signed(16#02A0#, 16), to_signed(16#02A6#, 16), 
      to_signed(16#02AD#, 16), to_signed(16#02B3#, 16), to_signed(16#02B9#, 16), to_signed(16#02C0#, 16), to_signed(16#02C6#, 16), to_signed(16#02CC#, 16), to_signed(16#02D2#, 16), to_signed(16#02D9#, 16), to_signed(16#02DF#, 16), 
      to_signed(16#02E5#, 16), to_signed(16#02EB#, 16), to_signed(16#02F2#, 16), to_signed(16#02F8#, 16), to_signed(16#02FE#, 16), to_signed(16#0305#, 16), to_signed(16#030B#, 16), to_signed(16#0311#, 16), to_signed(16#0317#, 16), 
      to_signed(16#031E#, 16), to_signed(16#0324#, 16), to_signed(16#032A#, 16), to_signed(16#0330#, 16), to_signed(16#0337#, 16), to_signed(16#033D#, 16), to_signed(16#0343#, 16), to_signed(16#034A#, 16), to_signed(16#0350#, 16), 
      to_signed(16#0356#, 16), to_signed(16#035C#, 16), to_signed(16#0363#, 16), to_signed(16#0369#, 16), to_signed(16#036F#, 16), to_signed(16#0375#, 16), to_signed(16#037C#, 16), to_signed(16#0382#, 16), to_signed(16#0388#, 16), 
      to_signed(16#038F#, 16), to_signed(16#0395#, 16), to_signed(16#039B#, 16), to_signed(16#03A1#, 16), to_signed(16#03A8#, 16), to_signed(16#03AE#, 16), to_signed(16#03B4#, 16), to_signed(16#03BB#, 16), to_signed(16#03C1#, 16), 
      to_signed(16#03C7#, 16), to_signed(16#03CD#, 16), to_signed(16#03D4#, 16), to_signed(16#03DA#, 16), to_signed(16#03E0#, 16), to_signed(16#03E6#, 16), to_signed(16#03ED#, 16), to_signed(16#03F3#, 16), to_signed(16#03F9#, 16), 
      to_signed(16#03FF#, 16), to_signed(16#0406#, 16), to_signed(16#040C#, 16), to_signed(16#0412#, 16), to_signed(16#0419#, 16), to_signed(16#041F#, 16), to_signed(16#0425#, 16), to_signed(16#042B#, 16), to_signed(16#0432#, 16), 
      to_signed(16#0438#, 16), to_signed(16#043E#, 16), to_signed(16#0444#, 16), to_signed(16#044B#, 16), to_signed(16#0451#, 16), to_signed(16#0457#, 16), to_signed(16#045E#, 16), to_signed(16#0464#, 16), to_signed(16#046A#, 16), 
      to_signed(16#0470#, 16), to_signed(16#0477#, 16), to_signed(16#047D#, 16), to_signed(16#0483#, 16), to_signed(16#0489#, 16), to_signed(16#0490#, 16), to_signed(16#0496#, 16), to_signed(16#049C#, 16), to_signed(16#04A2#, 16), 
      to_signed(16#04A9#, 16), to_signed(16#04AF#, 16), to_signed(16#04B5#, 16), to_signed(16#04BC#, 16), to_signed(16#04C2#, 16), to_signed(16#04C8#, 16), to_signed(16#04CE#, 16), to_signed(16#04D5#, 16), to_signed(16#04DB#, 16), 
      to_signed(16#04E1#, 16), to_signed(16#04E7#, 16), to_signed(16#04EE#, 16), to_signed(16#04F4#, 16), to_signed(16#04FA#, 16), to_signed(16#0500#, 16), to_signed(16#0507#, 16), to_signed(16#050D#, 16), to_signed(16#0513#, 16), 
      to_signed(16#051A#, 16), to_signed(16#0520#, 16), to_signed(16#0526#, 16), to_signed(16#052C#, 16), to_signed(16#0533#, 16), to_signed(16#0539#, 16), to_signed(16#053F#, 16), to_signed(16#0545#, 16), to_signed(16#054C#, 16), 
      to_signed(16#0552#, 16), to_signed(16#0558#, 16), to_signed(16#055E#, 16), to_signed(16#0565#, 16), to_signed(16#056B#, 16), to_signed(16#0571#, 16), to_signed(16#0577#, 16), to_signed(16#057E#, 16), to_signed(16#0584#, 16), 
      to_signed(16#058A#, 16), to_signed(16#0590#, 16), to_signed(16#0597#, 16), to_signed(16#059D#, 16), to_signed(16#05A3#, 16), to_signed(16#05AA#, 16), to_signed(16#05B0#, 16), to_signed(16#05B6#, 16), to_signed(16#05BC#, 16), 
      to_signed(16#05C3#, 16), to_signed(16#05C9#, 16), to_signed(16#05CF#, 16), to_signed(16#05D5#, 16), to_signed(16#05DC#, 16), to_signed(16#05E2#, 16), to_signed(16#05E8#, 16), to_signed(16#05EE#, 16), to_signed(16#05F5#, 16), 
      to_signed(16#05FB#, 16), to_signed(16#0601#, 16), to_signed(16#0607#, 16), to_signed(16#060E#, 16), to_signed(16#0614#, 16), to_signed(16#061A#, 16), to_signed(16#0620#, 16), to_signed(16#0627#, 16), to_signed(16#062D#, 16), 
      to_signed(16#0633#, 16), to_signed(16#0639#, 16), to_signed(16#0640#, 16), to_signed(16#0646#, 16), to_signed(16#064C#, 16), to_signed(16#0652#, 16), to_signed(16#0659#, 16), to_signed(16#065F#, 16), to_signed(16#0665#, 16), 
      to_signed(16#066B#, 16), to_signed(16#0672#, 16), to_signed(16#0678#, 16), to_signed(16#067E#, 16), to_signed(16#0684#, 16), to_signed(16#068B#, 16), to_signed(16#0691#, 16), to_signed(16#0697#, 16), to_signed(16#069D#, 16), 
      to_signed(16#06A4#, 16), to_signed(16#06AA#, 16), to_signed(16#06B0#, 16), to_signed(16#06B6#, 16), to_signed(16#06BD#, 16), to_signed(16#06C3#, 16), to_signed(16#06C9#, 16), to_signed(16#06CF#, 16), to_signed(16#06D6#, 16), 
      to_signed(16#06DC#, 16), to_signed(16#06E2#, 16), to_signed(16#06E8#, 16), to_signed(16#06EF#, 16), to_signed(16#06F5#, 16), to_signed(16#06FB#, 16), to_signed(16#0701#, 16), to_signed(16#0708#, 16), to_signed(16#070E#, 16), 
      to_signed(16#0714#, 16), to_signed(16#071A#, 16), to_signed(16#0721#, 16), to_signed(16#0727#, 16), to_signed(16#072D#, 16), to_signed(16#0733#, 16), to_signed(16#073A#, 16), to_signed(16#0740#, 16), to_signed(16#0746#, 16), 
      to_signed(16#074C#, 16), to_signed(16#0753#, 16), to_signed(16#0759#, 16), to_signed(16#075F#, 16), to_signed(16#0765#, 16), to_signed(16#076C#, 16), to_signed(16#0772#, 16), to_signed(16#0778#, 16), to_signed(16#077E#, 16), 
      to_signed(16#0784#, 16), to_signed(16#078B#, 16), to_signed(16#0791#, 16), to_signed(16#0797#, 16), to_signed(16#079D#, 16), to_signed(16#07A4#, 16), to_signed(16#07AA#, 16), to_signed(16#07B0#, 16), to_signed(16#07B6#, 16), 
      to_signed(16#07BD#, 16), to_signed(16#07C3#, 16), to_signed(16#07C9#, 16), to_signed(16#07CF#, 16), to_signed(16#07D6#, 16), to_signed(16#07DC#, 16), to_signed(16#07E2#, 16), to_signed(16#07E8#, 16), to_signed(16#07EF#, 16), 
      to_signed(16#07F5#, 16), to_signed(16#07FB#, 16), to_signed(16#0801#, 16), to_signed(16#0807#, 16), to_signed(16#080E#, 16), to_signed(16#0814#, 16), to_signed(16#081A#, 16), to_signed(16#0820#, 16), to_signed(16#0827#, 16), 
      to_signed(16#082D#, 16), to_signed(16#0833#, 16), to_signed(16#0839#, 16), to_signed(16#0840#, 16), to_signed(16#0846#, 16), to_signed(16#084C#, 16), to_signed(16#0852#, 16), to_signed(16#0858#, 16), to_signed(16#085F#, 16), 
      to_signed(16#0865#, 16), to_signed(16#086B#, 16), to_signed(16#0871#, 16), to_signed(16#0878#, 16), to_signed(16#087E#, 16), to_signed(16#0884#, 16), to_signed(16#088A#, 16), to_signed(16#0891#, 16), to_signed(16#0897#, 16), 
      to_signed(16#089D#, 16), to_signed(16#08A3#, 16), to_signed(16#08A9#, 16), to_signed(16#08B0#, 16), to_signed(16#08B6#, 16), to_signed(16#08BC#, 16), to_signed(16#08C2#, 16), to_signed(16#08C9#, 16), to_signed(16#08CF#, 16), 
      to_signed(16#08D5#, 16), to_signed(16#08DB#, 16), to_signed(16#08E1#, 16), to_signed(16#08E8#, 16), to_signed(16#08EE#, 16), to_signed(16#08F4#, 16), to_signed(16#08FA#, 16), to_signed(16#0901#, 16), to_signed(16#0907#, 16), 
      to_signed(16#090D#, 16), to_signed(16#0913#, 16), to_signed(16#0919#, 16), to_signed(16#0920#, 16), to_signed(16#0926#, 16), to_signed(16#092C#, 16), to_signed(16#0932#, 16), to_signed(16#0939#, 16), to_signed(16#093F#, 16), 
      to_signed(16#0945#, 16), to_signed(16#094B#, 16), to_signed(16#0951#, 16), to_signed(16#0958#, 16), to_signed(16#095E#, 16), to_signed(16#0964#, 16), to_signed(16#096A#, 16), to_signed(16#0970#, 16), to_signed(16#0977#, 16), 
      to_signed(16#097D#, 16), to_signed(16#0983#, 16), to_signed(16#0989#, 16), to_signed(16#0990#, 16), to_signed(16#0996#, 16), to_signed(16#099C#, 16), to_signed(16#09A2#, 16), to_signed(16#09A8#, 16), to_signed(16#09AF#, 16), 
      to_signed(16#09B5#, 16), to_signed(16#09BB#, 16), to_signed(16#09C1#, 16), to_signed(16#09C7#, 16), to_signed(16#09CE#, 16), to_signed(16#09D4#, 16), to_signed(16#09DA#, 16), to_signed(16#09E0#, 16), to_signed(16#09E6#, 16), 
      to_signed(16#09ED#, 16), to_signed(16#09F3#, 16), to_signed(16#09F9#, 16), to_signed(16#09FF#, 16), to_signed(16#0A06#, 16), to_signed(16#0A0C#, 16), to_signed(16#0A12#, 16), to_signed(16#0A18#, 16), to_signed(16#0A1E#, 16), 
      to_signed(16#0A25#, 16), to_signed(16#0A2B#, 16), to_signed(16#0A31#, 16), to_signed(16#0A37#, 16), to_signed(16#0A3D#, 16), to_signed(16#0A44#, 16), to_signed(16#0A4A#, 16), to_signed(16#0A50#, 16), to_signed(16#0A56#, 16), 
      to_signed(16#0A5C#, 16), to_signed(16#0A63#, 16), to_signed(16#0A69#, 16), to_signed(16#0A6F#, 16), to_signed(16#0A75#, 16), to_signed(16#0A7B#, 16), to_signed(16#0A82#, 16), to_signed(16#0A88#, 16), to_signed(16#0A8E#, 16), 
      to_signed(16#0A94#, 16), to_signed(16#0A9A#, 16), to_signed(16#0AA1#, 16), to_signed(16#0AA7#, 16), to_signed(16#0AAD#, 16), to_signed(16#0AB3#, 16), to_signed(16#0AB9#, 16), to_signed(16#0AC0#, 16), to_signed(16#0AC6#, 16), 
      to_signed(16#0ACC#, 16), to_signed(16#0AD2#, 16), to_signed(16#0AD8#, 16), to_signed(16#0ADE#, 16), to_signed(16#0AE5#, 16), to_signed(16#0AEB#, 16), to_signed(16#0AF1#, 16), to_signed(16#0AF7#, 16), to_signed(16#0AFD#, 16), 
      to_signed(16#0B04#, 16), to_signed(16#0B0A#, 16), to_signed(16#0B10#, 16), to_signed(16#0B16#, 16), to_signed(16#0B1C#, 16), to_signed(16#0B23#, 16), to_signed(16#0B29#, 16), to_signed(16#0B2F#, 16), to_signed(16#0B35#, 16), 
      to_signed(16#0B3B#, 16), to_signed(16#0B41#, 16), to_signed(16#0B48#, 16), to_signed(16#0B4E#, 16), to_signed(16#0B54#, 16), to_signed(16#0B5A#, 16), to_signed(16#0B60#, 16), to_signed(16#0B67#, 16), to_signed(16#0B6D#, 16), 
      to_signed(16#0B73#, 16), to_signed(16#0B79#, 16), to_signed(16#0B7F#, 16), to_signed(16#0B85#, 16), to_signed(16#0B8C#, 16), to_signed(16#0B92#, 16), to_signed(16#0B98#, 16), to_signed(16#0B9E#, 16), to_signed(16#0BA4#, 16), 
      to_signed(16#0BAB#, 16), to_signed(16#0BB1#, 16), to_signed(16#0BB7#, 16), to_signed(16#0BBD#, 16), to_signed(16#0BC3#, 16), to_signed(16#0BC9#, 16), to_signed(16#0BD0#, 16), to_signed(16#0BD6#, 16), to_signed(16#0BDC#, 16), 
      to_signed(16#0BE2#, 16), to_signed(16#0BE8#, 16), to_signed(16#0BEF#, 16), to_signed(16#0BF5#, 16), to_signed(16#0BFB#, 16), to_signed(16#0C01#, 16), to_signed(16#0C07#, 16), to_signed(16#0C0D#, 16), to_signed(16#0C14#, 16), 
      to_signed(16#0C1A#, 16), to_signed(16#0C20#, 16), to_signed(16#0C26#, 16), to_signed(16#0C2C#, 16), to_signed(16#0C32#, 16), to_signed(16#0C39#, 16), to_signed(16#0C3F#, 16), to_signed(16#0C45#, 16), to_signed(16#0C4B#, 16), 
      to_signed(16#0C51#, 16), to_signed(16#0C57#, 16), to_signed(16#0C5E#, 16), to_signed(16#0C64#, 16), to_signed(16#0C6A#, 16), to_signed(16#0C70#, 16), to_signed(16#0C76#, 16), to_signed(16#0C7C#, 16), to_signed(16#0C83#, 16), 
      to_signed(16#0C89#, 16), to_signed(16#0C8F#, 16), to_signed(16#0C95#, 16), to_signed(16#0C9B#, 16), to_signed(16#0CA1#, 16), to_signed(16#0CA7#, 16), to_signed(16#0CAE#, 16), to_signed(16#0CB4#, 16), to_signed(16#0CBA#, 16), 
      to_signed(16#0CC0#, 16), to_signed(16#0CC6#, 16), to_signed(16#0CCC#, 16), to_signed(16#0CD3#, 16), to_signed(16#0CD9#, 16), to_signed(16#0CDF#, 16), to_signed(16#0CE5#, 16), to_signed(16#0CEB#, 16), to_signed(16#0CF1#, 16), 
      to_signed(16#0CF8#, 16), to_signed(16#0CFE#, 16), to_signed(16#0D04#, 16), to_signed(16#0D0A#, 16), to_signed(16#0D10#, 16), to_signed(16#0D16#, 16), to_signed(16#0D1C#, 16), to_signed(16#0D23#, 16), to_signed(16#0D29#, 16), 
      to_signed(16#0D2F#, 16), to_signed(16#0D35#, 16), to_signed(16#0D3B#, 16), to_signed(16#0D41#, 16), to_signed(16#0D47#, 16), to_signed(16#0D4E#, 16), to_signed(16#0D54#, 16), to_signed(16#0D5A#, 16), to_signed(16#0D60#, 16), 
      to_signed(16#0D66#, 16), to_signed(16#0D6C#, 16), to_signed(16#0D72#, 16), to_signed(16#0D79#, 16), to_signed(16#0D7F#, 16), to_signed(16#0D85#, 16), to_signed(16#0D8B#, 16), to_signed(16#0D91#, 16), to_signed(16#0D97#, 16), 
      to_signed(16#0D9D#, 16), to_signed(16#0DA4#, 16), to_signed(16#0DAA#, 16), to_signed(16#0DB0#, 16), to_signed(16#0DB6#, 16), to_signed(16#0DBC#, 16), to_signed(16#0DC2#, 16), to_signed(16#0DC8#, 16), to_signed(16#0DCF#, 16), 
      to_signed(16#0DD5#, 16), to_signed(16#0DDB#, 16), to_signed(16#0DE1#, 16), to_signed(16#0DE7#, 16), to_signed(16#0DED#, 16), to_signed(16#0DF3#, 16), to_signed(16#0DF9#, 16), to_signed(16#0E00#, 16), to_signed(16#0E06#, 16), 
      to_signed(16#0E0C#, 16), to_signed(16#0E12#, 16), to_signed(16#0E18#, 16), to_signed(16#0E1E#, 16), to_signed(16#0E24#, 16), to_signed(16#0E2B#, 16), to_signed(16#0E31#, 16), to_signed(16#0E37#, 16), to_signed(16#0E3D#, 16), 
      to_signed(16#0E43#, 16), to_signed(16#0E49#, 16), to_signed(16#0E4F#, 16), to_signed(16#0E55#, 16), to_signed(16#0E5C#, 16), to_signed(16#0E62#, 16), to_signed(16#0E68#, 16), to_signed(16#0E6E#, 16), to_signed(16#0E74#, 16), 
      to_signed(16#0E7A#, 16), to_signed(16#0E80#, 16), to_signed(16#0E86#, 16), to_signed(16#0E8C#, 16), to_signed(16#0E93#, 16), to_signed(16#0E99#, 16), to_signed(16#0E9F#, 16), to_signed(16#0EA5#, 16), to_signed(16#0EAB#, 16), 
      to_signed(16#0EB1#, 16), to_signed(16#0EB7#, 16), to_signed(16#0EBD#, 16), to_signed(16#0EC4#, 16), to_signed(16#0ECA#, 16), to_signed(16#0ED0#, 16), to_signed(16#0ED6#, 16), to_signed(16#0EDC#, 16), to_signed(16#0EE2#, 16), 
      to_signed(16#0EE8#, 16), to_signed(16#0EEE#, 16), to_signed(16#0EF4#, 16), to_signed(16#0EFB#, 16), to_signed(16#0F01#, 16), to_signed(16#0F07#, 16), to_signed(16#0F0D#, 16), to_signed(16#0F13#, 16), to_signed(16#0F19#, 16), 
      to_signed(16#0F1F#, 16), to_signed(16#0F25#, 16), to_signed(16#0F2B#, 16), to_signed(16#0F31#, 16), to_signed(16#0F38#, 16), to_signed(16#0F3E#, 16), to_signed(16#0F44#, 16), to_signed(16#0F4A#, 16), to_signed(16#0F50#, 16), 
      to_signed(16#0F56#, 16), to_signed(16#0F5C#, 16), to_signed(16#0F62#, 16), to_signed(16#0F68#, 16), to_signed(16#0F6F#, 16), to_signed(16#0F75#, 16), to_signed(16#0F7B#, 16), to_signed(16#0F81#, 16), to_signed(16#0F87#, 16), 
      to_signed(16#0F8D#, 16), to_signed(16#0F93#, 16), to_signed(16#0F99#, 16), to_signed(16#0F9F#, 16), to_signed(16#0FA5#, 16), to_signed(16#0FAB#, 16), to_signed(16#0FB2#, 16), to_signed(16#0FB8#, 16), to_signed(16#0FBE#, 16), 
      to_signed(16#0FC4#, 16), to_signed(16#0FCA#, 16), to_signed(16#0FD0#, 16), to_signed(16#0FD6#, 16), to_signed(16#0FDC#, 16), to_signed(16#0FE2#, 16), to_signed(16#0FE8#, 16), to_signed(16#0FEE#, 16), to_signed(16#0FF5#, 16), 
      to_signed(16#0FFB#, 16), to_signed(16#1001#, 16), to_signed(16#1007#, 16), to_signed(16#100D#, 16), to_signed(16#1013#, 16), to_signed(16#1019#, 16), to_signed(16#101F#, 16), to_signed(16#1025#, 16), to_signed(16#102B#, 16), 
      to_signed(16#1031#, 16), to_signed(16#1037#, 16), to_signed(16#103D#, 16), to_signed(16#1044#, 16), to_signed(16#104A#, 16), to_signed(16#1050#, 16), to_signed(16#1056#, 16), to_signed(16#105C#, 16), to_signed(16#1062#, 16), 
      to_signed(16#1068#, 16), to_signed(16#106E#, 16), to_signed(16#1074#, 16), to_signed(16#107A#, 16), to_signed(16#1080#, 16), to_signed(16#1086#, 16), to_signed(16#108C#, 16), to_signed(16#1093#, 16), to_signed(16#1099#, 16), 
      to_signed(16#109F#, 16), to_signed(16#10A5#, 16), to_signed(16#10AB#, 16), to_signed(16#10B1#, 16), to_signed(16#10B7#, 16), to_signed(16#10BD#, 16), to_signed(16#10C3#, 16), to_signed(16#10C9#, 16), to_signed(16#10CF#, 16), 
      to_signed(16#10D5#, 16), to_signed(16#10DB#, 16), to_signed(16#10E1#, 16), to_signed(16#10E7#, 16), to_signed(16#10ED#, 16), to_signed(16#10F4#, 16), to_signed(16#10FA#, 16), to_signed(16#1100#, 16), to_signed(16#1106#, 16), 
      to_signed(16#110C#, 16), to_signed(16#1112#, 16), to_signed(16#1118#, 16), to_signed(16#111E#, 16), to_signed(16#1124#, 16), to_signed(16#112A#, 16), to_signed(16#1130#, 16), to_signed(16#1136#, 16), to_signed(16#113C#, 16), 
      to_signed(16#1142#, 16), to_signed(16#1148#, 16), to_signed(16#114E#, 16), to_signed(16#1154#, 16), to_signed(16#115A#, 16), to_signed(16#1160#, 16), to_signed(16#1167#, 16), to_signed(16#116D#, 16), to_signed(16#1173#, 16), 
      to_signed(16#1179#, 16), to_signed(16#117F#, 16), to_signed(16#1185#, 16), to_signed(16#118B#, 16), to_signed(16#1191#, 16), to_signed(16#1197#, 16), to_signed(16#119D#, 16), to_signed(16#11A3#, 16), to_signed(16#11A9#, 16), 
      to_signed(16#11AF#, 16), to_signed(16#11B5#, 16), to_signed(16#11BB#, 16), to_signed(16#11C1#, 16), to_signed(16#11C7#, 16), to_signed(16#11CD#, 16), to_signed(16#11D3#, 16), to_signed(16#11D9#, 16), to_signed(16#11DF#, 16), 
      to_signed(16#11E5#, 16), to_signed(16#11EB#, 16), to_signed(16#11F1#, 16), to_signed(16#11F7#, 16), to_signed(16#11FD#, 16), to_signed(16#1204#, 16), to_signed(16#120A#, 16), to_signed(16#1210#, 16), to_signed(16#1216#, 16), 
      to_signed(16#121C#, 16), to_signed(16#1222#, 16), to_signed(16#1228#, 16), to_signed(16#122E#, 16), to_signed(16#1234#, 16), to_signed(16#123A#, 16), to_signed(16#1240#, 16), to_signed(16#1246#, 16), to_signed(16#124C#, 16), 
      to_signed(16#1252#, 16), to_signed(16#1258#, 16), to_signed(16#125E#, 16), to_signed(16#1264#, 16), to_signed(16#126A#, 16), to_signed(16#1270#, 16), to_signed(16#1276#, 16), to_signed(16#127C#, 16), to_signed(16#1282#, 16), 
      to_signed(16#1288#, 16), to_signed(16#128E#, 16), to_signed(16#1294#, 16), to_signed(16#129A#, 16), to_signed(16#12A0#, 16), to_signed(16#12A6#, 16), to_signed(16#12AC#, 16), to_signed(16#12B2#, 16), to_signed(16#12B8#, 16), 
      to_signed(16#12BE#, 16), to_signed(16#12C4#, 16), to_signed(16#12CA#, 16), to_signed(16#12D0#, 16), to_signed(16#12D6#, 16), to_signed(16#12DC#, 16), to_signed(16#12E2#, 16), to_signed(16#12E8#, 16), to_signed(16#12EE#, 16), 
      to_signed(16#12F4#, 16), to_signed(16#12FA#, 16), to_signed(16#1300#, 16), to_signed(16#1306#, 16), to_signed(16#130C#, 16), to_signed(16#1312#, 16), to_signed(16#1318#, 16), to_signed(16#131E#, 16), to_signed(16#1324#, 16), 
      to_signed(16#132A#, 16), to_signed(16#1330#, 16), to_signed(16#1336#, 16), to_signed(16#133C#, 16), to_signed(16#1342#, 16), to_signed(16#1348#, 16), to_signed(16#134E#, 16), to_signed(16#1354#, 16), to_signed(16#135A#, 16), 
      to_signed(16#1360#, 16), to_signed(16#1366#, 16), to_signed(16#136C#, 16), to_signed(16#1372#, 16), to_signed(16#1378#, 16), to_signed(16#137E#, 16), to_signed(16#1384#, 16), to_signed(16#138A#, 16), to_signed(16#1390#, 16), 
      to_signed(16#1396#, 16), to_signed(16#139C#, 16), to_signed(16#13A2#, 16), to_signed(16#13A8#, 16), to_signed(16#13AE#, 16), to_signed(16#13B4#, 16), to_signed(16#13BA#, 16), to_signed(16#13C0#, 16), to_signed(16#13C6#, 16), 
      to_signed(16#13CC#, 16), to_signed(16#13D2#, 16), to_signed(16#13D8#, 16), to_signed(16#13DE#, 16), to_signed(16#13E4#, 16), to_signed(16#13EA#, 16), to_signed(16#13F0#, 16), to_signed(16#13F6#, 16), to_signed(16#13FB#, 16), 
      to_signed(16#1401#, 16), to_signed(16#1407#, 16), to_signed(16#140D#, 16), to_signed(16#1413#, 16), to_signed(16#1419#, 16), to_signed(16#141F#, 16), to_signed(16#1425#, 16), to_signed(16#142B#, 16), to_signed(16#1431#, 16), 
      to_signed(16#1437#, 16), to_signed(16#143D#, 16), to_signed(16#1443#, 16), to_signed(16#1449#, 16), to_signed(16#144F#, 16), to_signed(16#1455#, 16), to_signed(16#145B#, 16), to_signed(16#1461#, 16), to_signed(16#1467#, 16), 
      to_signed(16#146D#, 16), to_signed(16#1473#, 16), to_signed(16#1479#, 16), to_signed(16#147F#, 16), to_signed(16#1485#, 16), to_signed(16#148B#, 16), to_signed(16#1490#, 16), to_signed(16#1496#, 16), to_signed(16#149C#, 16), 
      to_signed(16#14A2#, 16), to_signed(16#14A8#, 16), to_signed(16#14AE#, 16), to_signed(16#14B4#, 16), to_signed(16#14BA#, 16), to_signed(16#14C0#, 16), to_signed(16#14C6#, 16), to_signed(16#14CC#, 16), to_signed(16#14D2#, 16), 
      to_signed(16#14D8#, 16), to_signed(16#14DE#, 16), to_signed(16#14E4#, 16), to_signed(16#14EA#, 16), to_signed(16#14F0#, 16), to_signed(16#14F6#, 16), to_signed(16#14FB#, 16), to_signed(16#1501#, 16), to_signed(16#1507#, 16), 
      to_signed(16#150D#, 16), to_signed(16#1513#, 16), to_signed(16#1519#, 16), to_signed(16#151F#, 16), to_signed(16#1525#, 16), to_signed(16#152B#, 16), to_signed(16#1531#, 16), to_signed(16#1537#, 16), to_signed(16#153D#, 16), 
      to_signed(16#1543#, 16), to_signed(16#1549#, 16), to_signed(16#154E#, 16), to_signed(16#1554#, 16), to_signed(16#155A#, 16), to_signed(16#1560#, 16), to_signed(16#1566#, 16), to_signed(16#156C#, 16), to_signed(16#1572#, 16), 
      to_signed(16#1578#, 16), to_signed(16#157E#, 16), to_signed(16#1584#, 16), to_signed(16#158A#, 16), to_signed(16#1590#, 16), to_signed(16#1596#, 16), to_signed(16#159B#, 16), to_signed(16#15A1#, 16), to_signed(16#15A7#, 16), 
      to_signed(16#15AD#, 16), to_signed(16#15B3#, 16), to_signed(16#15B9#, 16), to_signed(16#15BF#, 16), to_signed(16#15C5#, 16), to_signed(16#15CB#, 16), to_signed(16#15D1#, 16), to_signed(16#15D7#, 16), to_signed(16#15DC#, 16), 
      to_signed(16#15E2#, 16), to_signed(16#15E8#, 16), to_signed(16#15EE#, 16), to_signed(16#15F4#, 16), to_signed(16#15FA#, 16), to_signed(16#1600#, 16), to_signed(16#1606#, 16), to_signed(16#160C#, 16), to_signed(16#1612#, 16), 
      to_signed(16#1617#, 16), to_signed(16#161D#, 16), to_signed(16#1623#, 16), to_signed(16#1629#, 16), to_signed(16#162F#, 16), to_signed(16#1635#, 16), to_signed(16#163B#, 16), to_signed(16#1641#, 16), to_signed(16#1647#, 16), 
      to_signed(16#164C#, 16), to_signed(16#1652#, 16), to_signed(16#1658#, 16), to_signed(16#165E#, 16), to_signed(16#1664#, 16), to_signed(16#166A#, 16), to_signed(16#1670#, 16), to_signed(16#1676#, 16), to_signed(16#167C#, 16), 
      to_signed(16#1681#, 16), to_signed(16#1687#, 16), to_signed(16#168D#, 16), to_signed(16#1693#, 16), to_signed(16#1699#, 16), to_signed(16#169F#, 16), to_signed(16#16A5#, 16), to_signed(16#16AB#, 16), to_signed(16#16B0#, 16), 
      to_signed(16#16B6#, 16), to_signed(16#16BC#, 16), to_signed(16#16C2#, 16), to_signed(16#16C8#, 16), to_signed(16#16CE#, 16), to_signed(16#16D4#, 16), to_signed(16#16DA#, 16), to_signed(16#16DF#, 16), to_signed(16#16E5#, 16), 
      to_signed(16#16EB#, 16), to_signed(16#16F1#, 16), to_signed(16#16F7#, 16), to_signed(16#16FD#, 16), to_signed(16#1703#, 16), to_signed(16#1709#, 16), to_signed(16#170E#, 16), to_signed(16#1714#, 16), to_signed(16#171A#, 16), 
      to_signed(16#1720#, 16), to_signed(16#1726#, 16), to_signed(16#172C#, 16), to_signed(16#1732#, 16), to_signed(16#1737#, 16), to_signed(16#173D#, 16), to_signed(16#1743#, 16), to_signed(16#1749#, 16), to_signed(16#174F#, 16), 
      to_signed(16#1755#, 16), to_signed(16#175B#, 16), to_signed(16#1760#, 16), to_signed(16#1766#, 16), to_signed(16#176C#, 16), to_signed(16#1772#, 16), to_signed(16#1778#, 16), to_signed(16#177E#, 16), to_signed(16#1783#, 16), 
      to_signed(16#1789#, 16), to_signed(16#178F#, 16), to_signed(16#1795#, 16), to_signed(16#179B#, 16), to_signed(16#17A1#, 16), to_signed(16#17A6#, 16), to_signed(16#17AC#, 16), to_signed(16#17B2#, 16), to_signed(16#17B8#, 16), 
      to_signed(16#17BE#, 16), to_signed(16#17C4#, 16), to_signed(16#17C9#, 16), to_signed(16#17CF#, 16), to_signed(16#17D5#, 16), to_signed(16#17DB#, 16), to_signed(16#17E1#, 16), to_signed(16#17E7#, 16), to_signed(16#17EC#, 16), 
      to_signed(16#17F2#, 16), to_signed(16#17F8#, 16), to_signed(16#17FE#, 16), to_signed(16#1804#, 16), to_signed(16#180A#, 16), to_signed(16#180F#, 16), to_signed(16#1815#, 16), to_signed(16#181B#, 16), to_signed(16#1821#, 16), 
      to_signed(16#1827#, 16), to_signed(16#182D#, 16), to_signed(16#1832#, 16), to_signed(16#1838#, 16), to_signed(16#183E#, 16), to_signed(16#1844#, 16), to_signed(16#184A#, 16), to_signed(16#184F#, 16), to_signed(16#1855#, 16), 
      to_signed(16#185B#, 16), to_signed(16#1861#, 16), to_signed(16#1867#, 16), to_signed(16#186C#, 16), to_signed(16#1872#, 16), to_signed(16#1878#, 16), to_signed(16#187E#, 16), to_signed(16#1884#, 16), to_signed(16#1889#, 16), 
      to_signed(16#188F#, 16), to_signed(16#1895#, 16), to_signed(16#189B#, 16), to_signed(16#18A1#, 16), to_signed(16#18A6#, 16), to_signed(16#18AC#, 16), to_signed(16#18B2#, 16), to_signed(16#18B8#, 16), to_signed(16#18BE#, 16), 
      to_signed(16#18C3#, 16), to_signed(16#18C9#, 16), to_signed(16#18CF#, 16), to_signed(16#18D5#, 16), to_signed(16#18DB#, 16), to_signed(16#18E0#, 16), to_signed(16#18E6#, 16), to_signed(16#18EC#, 16), to_signed(16#18F2#, 16), 
      to_signed(16#18F8#, 16), to_signed(16#18FD#, 16), to_signed(16#1903#, 16), to_signed(16#1909#, 16), to_signed(16#190F#, 16), to_signed(16#1914#, 16), to_signed(16#191A#, 16), to_signed(16#1920#, 16), to_signed(16#1926#, 16), 
      to_signed(16#192C#, 16), to_signed(16#1931#, 16), to_signed(16#1937#, 16), to_signed(16#193D#, 16), to_signed(16#1943#, 16), to_signed(16#1948#, 16), to_signed(16#194E#, 16), to_signed(16#1954#, 16), to_signed(16#195A#, 16), 
      to_signed(16#1960#, 16), to_signed(16#1965#, 16), to_signed(16#196B#, 16), to_signed(16#1971#, 16), to_signed(16#1977#, 16), to_signed(16#197C#, 16), to_signed(16#1982#, 16), to_signed(16#1988#, 16), to_signed(16#198E#, 16), 
      to_signed(16#1993#, 16), to_signed(16#1999#, 16), to_signed(16#199F#, 16), to_signed(16#19A5#, 16), to_signed(16#19AA#, 16), to_signed(16#19B0#, 16), to_signed(16#19B6#, 16), to_signed(16#19BC#, 16), to_signed(16#19C1#, 16), 
      to_signed(16#19C7#, 16), to_signed(16#19CD#, 16), to_signed(16#19D3#, 16), to_signed(16#19D8#, 16), to_signed(16#19DE#, 16), to_signed(16#19E4#, 16), to_signed(16#19EA#, 16), to_signed(16#19EF#, 16), to_signed(16#19F5#, 16), 
      to_signed(16#19FB#, 16), to_signed(16#1A01#, 16), to_signed(16#1A06#, 16), to_signed(16#1A0C#, 16), to_signed(16#1A12#, 16), to_signed(16#1A18#, 16), to_signed(16#1A1D#, 16), to_signed(16#1A23#, 16), to_signed(16#1A29#, 16), 
      to_signed(16#1A2F#, 16), to_signed(16#1A34#, 16), to_signed(16#1A3A#, 16), to_signed(16#1A40#, 16), to_signed(16#1A46#, 16), to_signed(16#1A4B#, 16), to_signed(16#1A51#, 16), to_signed(16#1A57#, 16), to_signed(16#1A5C#, 16), 
      to_signed(16#1A62#, 16), to_signed(16#1A68#, 16), to_signed(16#1A6E#, 16), to_signed(16#1A73#, 16), to_signed(16#1A79#, 16), to_signed(16#1A7F#, 16), to_signed(16#1A84#, 16), to_signed(16#1A8A#, 16), to_signed(16#1A90#, 16), 
      to_signed(16#1A96#, 16), to_signed(16#1A9B#, 16), to_signed(16#1AA1#, 16), to_signed(16#1AA7#, 16), to_signed(16#1AAC#, 16), to_signed(16#1AB2#, 16), to_signed(16#1AB8#, 16), to_signed(16#1ABE#, 16), to_signed(16#1AC3#, 16), 
      to_signed(16#1AC9#, 16), to_signed(16#1ACF#, 16), to_signed(16#1AD4#, 16), to_signed(16#1ADA#, 16), to_signed(16#1AE0#, 16), to_signed(16#1AE6#, 16), to_signed(16#1AEB#, 16), to_signed(16#1AF1#, 16), to_signed(16#1AF7#, 16), 
      to_signed(16#1AFC#, 16), to_signed(16#1B02#, 16), to_signed(16#1B08#, 16), to_signed(16#1B0D#, 16), to_signed(16#1B13#, 16), to_signed(16#1B19#, 16), to_signed(16#1B1F#, 16), to_signed(16#1B24#, 16), to_signed(16#1B2A#, 16), 
      to_signed(16#1B30#, 16), to_signed(16#1B35#, 16), to_signed(16#1B3B#, 16), to_signed(16#1B41#, 16), to_signed(16#1B46#, 16), to_signed(16#1B4C#, 16), to_signed(16#1B52#, 16), to_signed(16#1B57#, 16), to_signed(16#1B5D#, 16), 
      to_signed(16#1B63#, 16), to_signed(16#1B68#, 16), to_signed(16#1B6E#, 16), to_signed(16#1B74#, 16), to_signed(16#1B79#, 16), to_signed(16#1B7F#, 16), to_signed(16#1B85#, 16), to_signed(16#1B8A#, 16), to_signed(16#1B90#, 16), 
      to_signed(16#1B96#, 16), to_signed(16#1B9B#, 16), to_signed(16#1BA1#, 16), to_signed(16#1BA7#, 16), to_signed(16#1BAC#, 16), to_signed(16#1BB2#, 16), to_signed(16#1BB8#, 16), to_signed(16#1BBD#, 16), to_signed(16#1BC3#, 16), 
      to_signed(16#1BC9#, 16), to_signed(16#1BCE#, 16), to_signed(16#1BD4#, 16), to_signed(16#1BDA#, 16), to_signed(16#1BDF#, 16), to_signed(16#1BE5#, 16), to_signed(16#1BEB#, 16), to_signed(16#1BF0#, 16), to_signed(16#1BF6#, 16), 
      to_signed(16#1BFC#, 16), to_signed(16#1C01#, 16), to_signed(16#1C07#, 16), to_signed(16#1C0D#, 16), to_signed(16#1C12#, 16), to_signed(16#1C18#, 16), to_signed(16#1C1E#, 16), to_signed(16#1C23#, 16), to_signed(16#1C29#, 16), 
      to_signed(16#1C2F#, 16), to_signed(16#1C34#, 16), to_signed(16#1C3A#, 16), to_signed(16#1C3F#, 16), to_signed(16#1C45#, 16), to_signed(16#1C4B#, 16), to_signed(16#1C50#, 16), to_signed(16#1C56#, 16), to_signed(16#1C5C#, 16), 
      to_signed(16#1C61#, 16), to_signed(16#1C67#, 16), to_signed(16#1C6C#, 16), to_signed(16#1C72#, 16), to_signed(16#1C78#, 16), to_signed(16#1C7D#, 16), to_signed(16#1C83#, 16), to_signed(16#1C89#, 16), to_signed(16#1C8E#, 16), 
      to_signed(16#1C94#, 16), to_signed(16#1C99#, 16), to_signed(16#1C9F#, 16), to_signed(16#1CA5#, 16), to_signed(16#1CAA#, 16), to_signed(16#1CB0#, 16), to_signed(16#1CB6#, 16), to_signed(16#1CBB#, 16), to_signed(16#1CC1#, 16), 
      to_signed(16#1CC6#, 16), to_signed(16#1CCC#, 16), to_signed(16#1CD2#, 16), to_signed(16#1CD7#, 16), to_signed(16#1CDD#, 16), to_signed(16#1CE2#, 16), to_signed(16#1CE8#, 16), to_signed(16#1CEE#, 16), to_signed(16#1CF3#, 16), 
      to_signed(16#1CF9#, 16), to_signed(16#1CFF#, 16), to_signed(16#1D04#, 16), to_signed(16#1D0A#, 16), to_signed(16#1D0F#, 16), to_signed(16#1D15#, 16), to_signed(16#1D1A#, 16), to_signed(16#1D20#, 16), to_signed(16#1D26#, 16), 
      to_signed(16#1D2B#, 16), to_signed(16#1D31#, 16), to_signed(16#1D36#, 16), to_signed(16#1D3C#, 16), to_signed(16#1D42#, 16), to_signed(16#1D47#, 16), to_signed(16#1D4D#, 16), to_signed(16#1D52#, 16), to_signed(16#1D58#, 16), 
      to_signed(16#1D5E#, 16), to_signed(16#1D63#, 16), to_signed(16#1D69#, 16), to_signed(16#1D6E#, 16), to_signed(16#1D74#, 16), to_signed(16#1D79#, 16), to_signed(16#1D7F#, 16), to_signed(16#1D85#, 16), to_signed(16#1D8A#, 16), 
      to_signed(16#1D90#, 16), to_signed(16#1D95#, 16), to_signed(16#1D9B#, 16), to_signed(16#1DA0#, 16), to_signed(16#1DA6#, 16), to_signed(16#1DAC#, 16), to_signed(16#1DB1#, 16), to_signed(16#1DB7#, 16), to_signed(16#1DBC#, 16), 
      to_signed(16#1DC2#, 16), to_signed(16#1DC7#, 16), to_signed(16#1DCD#, 16), to_signed(16#1DD3#, 16), to_signed(16#1DD8#, 16), to_signed(16#1DDE#, 16), to_signed(16#1DE3#, 16), to_signed(16#1DE9#, 16), to_signed(16#1DEE#, 16), 
      to_signed(16#1DF4#, 16), to_signed(16#1DF9#, 16), to_signed(16#1DFF#, 16), to_signed(16#1E05#, 16), to_signed(16#1E0A#, 16), to_signed(16#1E10#, 16), to_signed(16#1E15#, 16), to_signed(16#1E1B#, 16), to_signed(16#1E20#, 16), 
      to_signed(16#1E26#, 16), to_signed(16#1E2B#, 16), to_signed(16#1E31#, 16), to_signed(16#1E36#, 16), to_signed(16#1E3C#, 16), to_signed(16#1E42#, 16), to_signed(16#1E47#, 16), to_signed(16#1E4D#, 16), to_signed(16#1E52#, 16), 
      to_signed(16#1E58#, 16), to_signed(16#1E5D#, 16), to_signed(16#1E63#, 16), to_signed(16#1E68#, 16), to_signed(16#1E6E#, 16), to_signed(16#1E73#, 16), to_signed(16#1E79#, 16), to_signed(16#1E7E#, 16), to_signed(16#1E84#, 16), 
      to_signed(16#1E89#, 16), to_signed(16#1E8F#, 16), to_signed(16#1E94#, 16), to_signed(16#1E9A#, 16), to_signed(16#1E9F#, 16), to_signed(16#1EA5#, 16), to_signed(16#1EAB#, 16), to_signed(16#1EB0#, 16), to_signed(16#1EB6#, 16), 
      to_signed(16#1EBB#, 16), to_signed(16#1EC1#, 16), to_signed(16#1EC6#, 16), to_signed(16#1ECC#, 16), to_signed(16#1ED1#, 16), to_signed(16#1ED7#, 16), to_signed(16#1EDC#, 16), to_signed(16#1EE2#, 16), to_signed(16#1EE7#, 16), 
      to_signed(16#1EED#, 16), to_signed(16#1EF2#, 16), to_signed(16#1EF8#, 16), to_signed(16#1EFD#, 16), to_signed(16#1F03#, 16), to_signed(16#1F08#, 16), to_signed(16#1F0E#, 16), to_signed(16#1F13#, 16), to_signed(16#1F19#, 16), 
      to_signed(16#1F1E#, 16), to_signed(16#1F24#, 16), to_signed(16#1F29#, 16), to_signed(16#1F2F#, 16), to_signed(16#1F34#, 16), to_signed(16#1F3A#, 16), to_signed(16#1F3F#, 16), to_signed(16#1F44#, 16), to_signed(16#1F4A#, 16), 
      to_signed(16#1F4F#, 16), to_signed(16#1F55#, 16), to_signed(16#1F5A#, 16), to_signed(16#1F60#, 16), to_signed(16#1F65#, 16), to_signed(16#1F6B#, 16), to_signed(16#1F70#, 16), to_signed(16#1F76#, 16), to_signed(16#1F7B#, 16), 
      to_signed(16#1F81#, 16), to_signed(16#1F86#, 16), to_signed(16#1F8C#, 16), to_signed(16#1F91#, 16), to_signed(16#1F97#, 16), to_signed(16#1F9C#, 16), to_signed(16#1FA2#, 16), to_signed(16#1FA7#, 16), to_signed(16#1FAC#, 16), 
      to_signed(16#1FB2#, 16), to_signed(16#1FB7#, 16), to_signed(16#1FBD#, 16), to_signed(16#1FC2#, 16), to_signed(16#1FC8#, 16), to_signed(16#1FCD#, 16), to_signed(16#1FD3#, 16), to_signed(16#1FD8#, 16), to_signed(16#1FDE#, 16), 
      to_signed(16#1FE3#, 16), to_signed(16#1FE8#, 16), to_signed(16#1FEE#, 16), to_signed(16#1FF3#, 16), to_signed(16#1FF9#, 16), to_signed(16#1FFE#, 16), to_signed(16#2004#, 16), to_signed(16#2009#, 16), to_signed(16#200F#, 16), 
      to_signed(16#2014#, 16), to_signed(16#2019#, 16), to_signed(16#201F#, 16), to_signed(16#2024#, 16), to_signed(16#202A#, 16), to_signed(16#202F#, 16), to_signed(16#2035#, 16), to_signed(16#203A#, 16), to_signed(16#203F#, 16), 
      to_signed(16#2045#, 16), to_signed(16#204A#, 16), to_signed(16#2050#, 16), to_signed(16#2055#, 16), to_signed(16#205B#, 16), to_signed(16#2060#, 16), to_signed(16#2065#, 16), to_signed(16#206B#, 16), to_signed(16#2070#, 16), 
      to_signed(16#2076#, 16), to_signed(16#207B#, 16), to_signed(16#2080#, 16), to_signed(16#2086#, 16), to_signed(16#208B#, 16), to_signed(16#2091#, 16), to_signed(16#2096#, 16), to_signed(16#209B#, 16), to_signed(16#20A1#, 16), 
      to_signed(16#20A6#, 16), to_signed(16#20AC#, 16), to_signed(16#20B1#, 16), to_signed(16#20B7#, 16), to_signed(16#20BC#, 16), to_signed(16#20C1#, 16), to_signed(16#20C7#, 16), to_signed(16#20CC#, 16), to_signed(16#20D1#, 16), 
      to_signed(16#20D7#, 16), to_signed(16#20DC#, 16), to_signed(16#20E2#, 16), to_signed(16#20E7#, 16), to_signed(16#20EC#, 16), to_signed(16#20F2#, 16), to_signed(16#20F7#, 16), to_signed(16#20FD#, 16), to_signed(16#2102#, 16), 
      to_signed(16#2107#, 16), to_signed(16#210D#, 16), to_signed(16#2112#, 16), to_signed(16#2118#, 16), to_signed(16#211D#, 16), to_signed(16#2122#, 16), to_signed(16#2128#, 16), to_signed(16#212D#, 16), to_signed(16#2132#, 16), 
      to_signed(16#2138#, 16), to_signed(16#213D#, 16), to_signed(16#2142#, 16), to_signed(16#2148#, 16), to_signed(16#214D#, 16), to_signed(16#2153#, 16), to_signed(16#2158#, 16), to_signed(16#215D#, 16), to_signed(16#2163#, 16), 
      to_signed(16#2168#, 16), to_signed(16#216D#, 16), to_signed(16#2173#, 16), to_signed(16#2178#, 16), to_signed(16#217D#, 16), to_signed(16#2183#, 16), to_signed(16#2188#, 16), to_signed(16#218E#, 16), to_signed(16#2193#, 16), 
      to_signed(16#2198#, 16), to_signed(16#219E#, 16), to_signed(16#21A3#, 16), to_signed(16#21A8#, 16), to_signed(16#21AE#, 16), to_signed(16#21B3#, 16), to_signed(16#21B8#, 16), to_signed(16#21BE#, 16), to_signed(16#21C3#, 16), 
      to_signed(16#21C8#, 16), to_signed(16#21CE#, 16), to_signed(16#21D3#, 16), to_signed(16#21D8#, 16), to_signed(16#21DE#, 16), to_signed(16#21E3#, 16), to_signed(16#21E8#, 16), to_signed(16#21EE#, 16), to_signed(16#21F3#, 16), 
      to_signed(16#21F8#, 16), to_signed(16#21FE#, 16), to_signed(16#2203#, 16), to_signed(16#2208#, 16), to_signed(16#220E#, 16), to_signed(16#2213#, 16), to_signed(16#2218#, 16), to_signed(16#221E#, 16), to_signed(16#2223#, 16), 
      to_signed(16#2228#, 16), to_signed(16#222D#, 16), to_signed(16#2233#, 16), to_signed(16#2238#, 16), to_signed(16#223D#, 16), to_signed(16#2243#, 16), to_signed(16#2248#, 16), to_signed(16#224D#, 16), to_signed(16#2253#, 16), 
      to_signed(16#2258#, 16), to_signed(16#225D#, 16), to_signed(16#2263#, 16), to_signed(16#2268#, 16), to_signed(16#226D#, 16), to_signed(16#2272#, 16), to_signed(16#2278#, 16), to_signed(16#227D#, 16), to_signed(16#2282#, 16), 
      to_signed(16#2288#, 16), to_signed(16#228D#, 16), to_signed(16#2292#, 16), to_signed(16#2297#, 16), to_signed(16#229D#, 16), to_signed(16#22A2#, 16), to_signed(16#22A7#, 16), to_signed(16#22AD#, 16), to_signed(16#22B2#, 16), 
      to_signed(16#22B7#, 16), to_signed(16#22BC#, 16), to_signed(16#22C2#, 16), to_signed(16#22C7#, 16), to_signed(16#22CC#, 16), to_signed(16#22D2#, 16), to_signed(16#22D7#, 16), to_signed(16#22DC#, 16), to_signed(16#22E1#, 16), 
      to_signed(16#22E7#, 16), to_signed(16#22EC#, 16), to_signed(16#22F1#, 16), to_signed(16#22F6#, 16), to_signed(16#22FC#, 16), to_signed(16#2301#, 16), to_signed(16#2306#, 16), to_signed(16#230B#, 16), to_signed(16#2311#, 16), 
      to_signed(16#2316#, 16), to_signed(16#231B#, 16), to_signed(16#2320#, 16), to_signed(16#2326#, 16), to_signed(16#232B#, 16), to_signed(16#2330#, 16), to_signed(16#2335#, 16), to_signed(16#233B#, 16), to_signed(16#2340#, 16), 
      to_signed(16#2345#, 16), to_signed(16#234A#, 16), to_signed(16#2350#, 16), to_signed(16#2355#, 16), to_signed(16#235A#, 16), to_signed(16#235F#, 16), to_signed(16#2365#, 16), to_signed(16#236A#, 16), to_signed(16#236F#, 16), 
      to_signed(16#2374#, 16), to_signed(16#237A#, 16), to_signed(16#237F#, 16), to_signed(16#2384#, 16), to_signed(16#2389#, 16), to_signed(16#238E#, 16), to_signed(16#2394#, 16), to_signed(16#2399#, 16), to_signed(16#239E#, 16), 
      to_signed(16#23A3#, 16), to_signed(16#23A9#, 16), to_signed(16#23AE#, 16), to_signed(16#23B3#, 16), to_signed(16#23B8#, 16), to_signed(16#23BD#, 16), to_signed(16#23C3#, 16), to_signed(16#23C8#, 16), to_signed(16#23CD#, 16), 
      to_signed(16#23D2#, 16), to_signed(16#23D7#, 16), to_signed(16#23DD#, 16), to_signed(16#23E2#, 16), to_signed(16#23E7#, 16), to_signed(16#23EC#, 16), to_signed(16#23F1#, 16), to_signed(16#23F7#, 16), to_signed(16#23FC#, 16), 
      to_signed(16#2401#, 16), to_signed(16#2406#, 16), to_signed(16#240B#, 16), to_signed(16#2411#, 16), to_signed(16#2416#, 16), to_signed(16#241B#, 16), to_signed(16#2420#, 16), to_signed(16#2425#, 16), to_signed(16#242B#, 16), 
      to_signed(16#2430#, 16), to_signed(16#2435#, 16), to_signed(16#243A#, 16), to_signed(16#243F#, 16), to_signed(16#2444#, 16), to_signed(16#244A#, 16), to_signed(16#244F#, 16), to_signed(16#2454#, 16), to_signed(16#2459#, 16), 
      to_signed(16#245E#, 16), to_signed(16#2464#, 16), to_signed(16#2469#, 16), to_signed(16#246E#, 16), to_signed(16#2473#, 16), to_signed(16#2478#, 16), to_signed(16#247D#, 16), to_signed(16#2483#, 16), to_signed(16#2488#, 16), 
      to_signed(16#248D#, 16), to_signed(16#2492#, 16), to_signed(16#2497#, 16), to_signed(16#249C#, 16), to_signed(16#24A1#, 16), to_signed(16#24A7#, 16), to_signed(16#24AC#, 16), to_signed(16#24B1#, 16), to_signed(16#24B6#, 16), 
      to_signed(16#24BB#, 16), to_signed(16#24C0#, 16), to_signed(16#24C5#, 16), to_signed(16#24CB#, 16), to_signed(16#24D0#, 16), to_signed(16#24D5#, 16), to_signed(16#24DA#, 16), to_signed(16#24DF#, 16), to_signed(16#24E4#, 16), 
      to_signed(16#24E9#, 16), to_signed(16#24EF#, 16), to_signed(16#24F4#, 16), to_signed(16#24F9#, 16), to_signed(16#24FE#, 16), to_signed(16#2503#, 16), to_signed(16#2508#, 16), to_signed(16#250D#, 16), to_signed(16#2512#, 16), 
      to_signed(16#2518#, 16), to_signed(16#251D#, 16), to_signed(16#2522#, 16), to_signed(16#2527#, 16), to_signed(16#252C#, 16), to_signed(16#2531#, 16), to_signed(16#2536#, 16), to_signed(16#253B#, 16), to_signed(16#2541#, 16), 
      to_signed(16#2546#, 16), to_signed(16#254B#, 16), to_signed(16#2550#, 16), to_signed(16#2555#, 16), to_signed(16#255A#, 16), to_signed(16#255F#, 16), to_signed(16#2564#, 16), to_signed(16#2569#, 16), to_signed(16#256E#, 16), 
      to_signed(16#2574#, 16), to_signed(16#2579#, 16), to_signed(16#257E#, 16), to_signed(16#2583#, 16), to_signed(16#2588#, 16), to_signed(16#258D#, 16), to_signed(16#2592#, 16), to_signed(16#2597#, 16), to_signed(16#259C#, 16), 
      to_signed(16#25A1#, 16), to_signed(16#25A6#, 16), to_signed(16#25AB#, 16), to_signed(16#25B1#, 16), to_signed(16#25B6#, 16), to_signed(16#25BB#, 16), to_signed(16#25C0#, 16), to_signed(16#25C5#, 16), to_signed(16#25CA#, 16), 
      to_signed(16#25CF#, 16), to_signed(16#25D4#, 16), to_signed(16#25D9#, 16), to_signed(16#25DE#, 16), to_signed(16#25E3#, 16), to_signed(16#25E8#, 16), to_signed(16#25ED#, 16), to_signed(16#25F2#, 16), to_signed(16#25F8#, 16), 
      to_signed(16#25FD#, 16), to_signed(16#2602#, 16), to_signed(16#2607#, 16), to_signed(16#260C#, 16), to_signed(16#2611#, 16), to_signed(16#2616#, 16), to_signed(16#261B#, 16), to_signed(16#2620#, 16), to_signed(16#2625#, 16), 
      to_signed(16#262A#, 16), to_signed(16#262F#, 16), to_signed(16#2634#, 16), to_signed(16#2639#, 16), to_signed(16#263E#, 16), to_signed(16#2643#, 16), to_signed(16#2648#, 16), to_signed(16#264D#, 16), to_signed(16#2652#, 16), 
      to_signed(16#2657#, 16), to_signed(16#265C#, 16), to_signed(16#2661#, 16), to_signed(16#2666#, 16), to_signed(16#266B#, 16), to_signed(16#2671#, 16), to_signed(16#2676#, 16), to_signed(16#267B#, 16), to_signed(16#2680#, 16), 
      to_signed(16#2685#, 16), to_signed(16#268A#, 16), to_signed(16#268F#, 16), to_signed(16#2694#, 16), to_signed(16#2699#, 16), to_signed(16#269E#, 16), to_signed(16#26A3#, 16), to_signed(16#26A8#, 16), to_signed(16#26AD#, 16), 
      to_signed(16#26B2#, 16), to_signed(16#26B7#, 16), to_signed(16#26BC#, 16), to_signed(16#26C1#, 16), to_signed(16#26C6#, 16), to_signed(16#26CB#, 16), to_signed(16#26D0#, 16), to_signed(16#26D5#, 16), to_signed(16#26DA#, 16), 
      to_signed(16#26DF#, 16), to_signed(16#26E4#, 16), to_signed(16#26E9#, 16), to_signed(16#26EE#, 16), to_signed(16#26F3#, 16), to_signed(16#26F8#, 16), to_signed(16#26FD#, 16), to_signed(16#2702#, 16), to_signed(16#2707#, 16), 
      to_signed(16#270C#, 16), to_signed(16#2711#, 16), to_signed(16#2715#, 16), to_signed(16#271A#, 16), to_signed(16#271F#, 16), to_signed(16#2724#, 16), to_signed(16#2729#, 16), to_signed(16#272E#, 16), to_signed(16#2733#, 16), 
      to_signed(16#2738#, 16), to_signed(16#273D#, 16), to_signed(16#2742#, 16), to_signed(16#2747#, 16), to_signed(16#274C#, 16), to_signed(16#2751#, 16), to_signed(16#2756#, 16), to_signed(16#275B#, 16), to_signed(16#2760#, 16), 
      to_signed(16#2765#, 16), to_signed(16#276A#, 16), to_signed(16#276F#, 16), to_signed(16#2774#, 16), to_signed(16#2779#, 16), to_signed(16#277E#, 16), to_signed(16#2783#, 16), to_signed(16#2788#, 16), to_signed(16#278C#, 16), 
      to_signed(16#2791#, 16), to_signed(16#2796#, 16), to_signed(16#279B#, 16), to_signed(16#27A0#, 16), to_signed(16#27A5#, 16), to_signed(16#27AA#, 16), to_signed(16#27AF#, 16), to_signed(16#27B4#, 16), to_signed(16#27B9#, 16), 
      to_signed(16#27BE#, 16), to_signed(16#27C3#, 16), to_signed(16#27C8#, 16), to_signed(16#27CD#, 16), to_signed(16#27D1#, 16), to_signed(16#27D6#, 16), to_signed(16#27DB#, 16), to_signed(16#27E0#, 16), to_signed(16#27E5#, 16), 
      to_signed(16#27EA#, 16), to_signed(16#27EF#, 16), to_signed(16#27F4#, 16), to_signed(16#27F9#, 16), to_signed(16#27FE#, 16), to_signed(16#2803#, 16), to_signed(16#2808#, 16), to_signed(16#280C#, 16), to_signed(16#2811#, 16), 
      to_signed(16#2816#, 16), to_signed(16#281B#, 16), to_signed(16#2820#, 16), to_signed(16#2825#, 16), to_signed(16#282A#, 16), to_signed(16#282F#, 16), to_signed(16#2834#, 16), to_signed(16#2838#, 16), to_signed(16#283D#, 16), 
      to_signed(16#2842#, 16), to_signed(16#2847#, 16), to_signed(16#284C#, 16), to_signed(16#2851#, 16), to_signed(16#2856#, 16), to_signed(16#285B#, 16), to_signed(16#2860#, 16), to_signed(16#2864#, 16), to_signed(16#2869#, 16), 
      to_signed(16#286E#, 16), to_signed(16#2873#, 16), to_signed(16#2878#, 16), to_signed(16#287D#, 16), to_signed(16#2882#, 16), to_signed(16#2886#, 16), to_signed(16#288B#, 16), to_signed(16#2890#, 16), to_signed(16#2895#, 16), 
      to_signed(16#289A#, 16), to_signed(16#289F#, 16), to_signed(16#28A4#, 16), to_signed(16#28A8#, 16), to_signed(16#28AD#, 16), to_signed(16#28B2#, 16), to_signed(16#28B7#, 16), to_signed(16#28BC#, 16), to_signed(16#28C1#, 16), 
      to_signed(16#28C6#, 16), to_signed(16#28CA#, 16), to_signed(16#28CF#, 16), to_signed(16#28D4#, 16), to_signed(16#28D9#, 16), to_signed(16#28DE#, 16), to_signed(16#28E3#, 16), to_signed(16#28E7#, 16), to_signed(16#28EC#, 16), 
      to_signed(16#28F1#, 16), to_signed(16#28F6#, 16), to_signed(16#28FB#, 16), to_signed(16#2900#, 16), to_signed(16#2904#, 16), to_signed(16#2909#, 16), to_signed(16#290E#, 16), to_signed(16#2913#, 16), to_signed(16#2918#, 16), 
      to_signed(16#291C#, 16), to_signed(16#2921#, 16), to_signed(16#2926#, 16), to_signed(16#292B#, 16), to_signed(16#2930#, 16), to_signed(16#2935#, 16), to_signed(16#2939#, 16), to_signed(16#293E#, 16), to_signed(16#2943#, 16), 
      to_signed(16#2948#, 16), to_signed(16#294D#, 16), to_signed(16#2951#, 16), to_signed(16#2956#, 16), to_signed(16#295B#, 16), to_signed(16#2960#, 16), to_signed(16#2965#, 16), to_signed(16#2969#, 16), to_signed(16#296E#, 16), 
      to_signed(16#2973#, 16), to_signed(16#2978#, 16), to_signed(16#297C#, 16), to_signed(16#2981#, 16), to_signed(16#2986#, 16), to_signed(16#298B#, 16), to_signed(16#2990#, 16), to_signed(16#2994#, 16), to_signed(16#2999#, 16), 
      to_signed(16#299E#, 16), to_signed(16#29A3#, 16), to_signed(16#29A7#, 16), to_signed(16#29AC#, 16), to_signed(16#29B1#, 16), to_signed(16#29B6#, 16), to_signed(16#29BB#, 16), to_signed(16#29BF#, 16), to_signed(16#29C4#, 16), 
      to_signed(16#29C9#, 16), to_signed(16#29CE#, 16), to_signed(16#29D2#, 16), to_signed(16#29D7#, 16), to_signed(16#29DC#, 16), to_signed(16#29E1#, 16), to_signed(16#29E5#, 16), to_signed(16#29EA#, 16), to_signed(16#29EF#, 16), 
      to_signed(16#29F4#, 16), to_signed(16#29F8#, 16), to_signed(16#29FD#, 16), to_signed(16#2A02#, 16), to_signed(16#2A07#, 16), to_signed(16#2A0B#, 16), to_signed(16#2A10#, 16), to_signed(16#2A15#, 16), to_signed(16#2A1A#, 16), 
      to_signed(16#2A1E#, 16), to_signed(16#2A23#, 16), to_signed(16#2A28#, 16), to_signed(16#2A2C#, 16), to_signed(16#2A31#, 16), to_signed(16#2A36#, 16), to_signed(16#2A3B#, 16), to_signed(16#2A3F#, 16), to_signed(16#2A44#, 16), 
      to_signed(16#2A49#, 16), to_signed(16#2A4D#, 16), to_signed(16#2A52#, 16), to_signed(16#2A57#, 16), to_signed(16#2A5C#, 16), to_signed(16#2A60#, 16), to_signed(16#2A65#, 16), to_signed(16#2A6A#, 16), to_signed(16#2A6E#, 16), 
      to_signed(16#2A73#, 16), to_signed(16#2A78#, 16), to_signed(16#2A7D#, 16), to_signed(16#2A81#, 16), to_signed(16#2A86#, 16), to_signed(16#2A8B#, 16), to_signed(16#2A8F#, 16), to_signed(16#2A94#, 16), to_signed(16#2A99#, 16), 
      to_signed(16#2A9D#, 16), to_signed(16#2AA2#, 16), to_signed(16#2AA7#, 16), to_signed(16#2AAB#, 16), to_signed(16#2AB0#, 16), to_signed(16#2AB5#, 16), to_signed(16#2AB9#, 16), to_signed(16#2ABE#, 16), to_signed(16#2AC3#, 16), 
      to_signed(16#2AC8#, 16), to_signed(16#2ACC#, 16), to_signed(16#2AD1#, 16), to_signed(16#2AD6#, 16), to_signed(16#2ADA#, 16), to_signed(16#2ADF#, 16), to_signed(16#2AE4#, 16), to_signed(16#2AE8#, 16), to_signed(16#2AED#, 16), 
      to_signed(16#2AF2#, 16), to_signed(16#2AF6#, 16), to_signed(16#2AFB#, 16), to_signed(16#2AFF#, 16), to_signed(16#2B04#, 16), to_signed(16#2B09#, 16), to_signed(16#2B0D#, 16), to_signed(16#2B12#, 16), to_signed(16#2B17#, 16), 
      to_signed(16#2B1B#, 16), to_signed(16#2B20#, 16), to_signed(16#2B25#, 16), to_signed(16#2B29#, 16), to_signed(16#2B2E#, 16), to_signed(16#2B33#, 16), to_signed(16#2B37#, 16), to_signed(16#2B3C#, 16), to_signed(16#2B40#, 16), 
      to_signed(16#2B45#, 16), to_signed(16#2B4A#, 16), to_signed(16#2B4E#, 16), to_signed(16#2B53#, 16), to_signed(16#2B58#, 16), to_signed(16#2B5C#, 16), to_signed(16#2B61#, 16), to_signed(16#2B65#, 16), to_signed(16#2B6A#, 16), 
      to_signed(16#2B6F#, 16), to_signed(16#2B73#, 16), to_signed(16#2B78#, 16), to_signed(16#2B7D#, 16), to_signed(16#2B81#, 16), to_signed(16#2B86#, 16), to_signed(16#2B8A#, 16), to_signed(16#2B8F#, 16), to_signed(16#2B94#, 16), 
      to_signed(16#2B98#, 16), to_signed(16#2B9D#, 16), to_signed(16#2BA1#, 16), to_signed(16#2BA6#, 16), to_signed(16#2BAB#, 16), to_signed(16#2BAF#, 16), to_signed(16#2BB4#, 16), to_signed(16#2BB8#, 16), to_signed(16#2BBD#, 16), 
      to_signed(16#2BC2#, 16), to_signed(16#2BC6#, 16), to_signed(16#2BCB#, 16), to_signed(16#2BCF#, 16), to_signed(16#2BD4#, 16), to_signed(16#2BD8#, 16), to_signed(16#2BDD#, 16), to_signed(16#2BE2#, 16), to_signed(16#2BE6#, 16), 
      to_signed(16#2BEB#, 16), to_signed(16#2BEF#, 16), to_signed(16#2BF4#, 16), to_signed(16#2BF8#, 16), to_signed(16#2BFD#, 16), to_signed(16#2C02#, 16), to_signed(16#2C06#, 16), to_signed(16#2C0B#, 16), to_signed(16#2C0F#, 16), 
      to_signed(16#2C14#, 16), to_signed(16#2C18#, 16), to_signed(16#2C1D#, 16), to_signed(16#2C21#, 16), to_signed(16#2C26#, 16), to_signed(16#2C2B#, 16), to_signed(16#2C2F#, 16), to_signed(16#2C34#, 16), to_signed(16#2C38#, 16), 
      to_signed(16#2C3D#, 16), to_signed(16#2C41#, 16), to_signed(16#2C46#, 16), to_signed(16#2C4A#, 16), to_signed(16#2C4F#, 16), to_signed(16#2C53#, 16), to_signed(16#2C58#, 16), to_signed(16#2C5C#, 16), to_signed(16#2C61#, 16), 
      to_signed(16#2C66#, 16), to_signed(16#2C6A#, 16), to_signed(16#2C6F#, 16), to_signed(16#2C73#, 16), to_signed(16#2C78#, 16), to_signed(16#2C7C#, 16), to_signed(16#2C81#, 16), to_signed(16#2C85#, 16), to_signed(16#2C8A#, 16), 
      to_signed(16#2C8E#, 16), to_signed(16#2C93#, 16), to_signed(16#2C97#, 16), to_signed(16#2C9C#, 16), to_signed(16#2CA0#, 16), to_signed(16#2CA5#, 16), to_signed(16#2CA9#, 16), to_signed(16#2CAE#, 16), to_signed(16#2CB2#, 16), 
      to_signed(16#2CB7#, 16), to_signed(16#2CBB#, 16), to_signed(16#2CC0#, 16), to_signed(16#2CC4#, 16), to_signed(16#2CC9#, 16), to_signed(16#2CCD#, 16), to_signed(16#2CD2#, 16), to_signed(16#2CD6#, 16), to_signed(16#2CDB#, 16), 
      to_signed(16#2CDF#, 16), to_signed(16#2CE4#, 16), to_signed(16#2CE8#, 16), to_signed(16#2CED#, 16), to_signed(16#2CF1#, 16), to_signed(16#2CF5#, 16), to_signed(16#2CFA#, 16), to_signed(16#2CFE#, 16), to_signed(16#2D03#, 16), 
      to_signed(16#2D07#, 16), to_signed(16#2D0C#, 16), to_signed(16#2D10#, 16), to_signed(16#2D15#, 16), to_signed(16#2D19#, 16), to_signed(16#2D1E#, 16), to_signed(16#2D22#, 16), to_signed(16#2D27#, 16), to_signed(16#2D2B#, 16), 
      to_signed(16#2D2F#, 16), to_signed(16#2D34#, 16), to_signed(16#2D38#, 16), to_signed(16#2D3D#, 16)); -- sfix16 [2048]

  -- Signals
  SIGNAL lutaddr_unsigned                 : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL lutaddrInReg                     : unsigned(10 DOWNTO 0) := to_unsigned(16#000#, 11);  -- ufix11
  SIGNAL lutSineout                       : signed(15 DOWNTO 0);  -- sfix16_En14
  SIGNAL lutSineoutreg1                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En14
  SIGNAL lutSine_tmp                      : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En14

BEGIN
  lutaddr_unsigned <= unsigned(lutaddr);

  -- Look up table address input register
  LUTaddrRegister_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        lutaddrInReg <= lutaddr_unsigned;
      END IF;
    END IF;
  END PROCESS LUTaddrRegister_process;


  -- Octant Sine wave table
  lutSineout <= DirectLookupTable_data(to_integer(lutaddrInReg));

  -- Sin lookup table output register
  LUTSineoutResetRegister_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        lutSineoutreg1 <= lutSineout;
      END IF;
    END IF;
  END PROCESS LUTSineoutResetRegister_process;


  LUTSineoutRegister_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        lutSine_tmp <= lutSineoutreg1;
      END IF;
    END IF;
  END PROCESS LUTSineoutRegister_process;


  lutSine <= std_logic_vector(lutSine_tmp);

END rtl;

