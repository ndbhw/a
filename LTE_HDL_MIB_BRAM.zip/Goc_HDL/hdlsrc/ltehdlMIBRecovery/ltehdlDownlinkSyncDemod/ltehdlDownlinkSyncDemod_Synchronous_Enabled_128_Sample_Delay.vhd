-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_Synchronous_Enabled_128_Sample_Delay IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn                            :   IN    std_logic_vector(36 DOWNTO 0);  -- ufix37_En30
        en                                :   IN    std_logic;
        dataOut                           :   OUT   std_logic_vector(36 DOWNTO 0)  -- ufix37_En30
        );
END ltehdlDownlinkSyncDemod_Synchronous_Enabled_128_Sample_Delay;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Synchronous_Enabled_128_Sample_Delay IS

  -- Signals
  SIGNAL dataIn_unsigned                  : unsigned(36 DOWNTO 0);  -- ufix37_En30
  SIGNAL Delay1_reg_rsvd                  : vector_of_unsigned37(0 TO 127) := (OTHERS => to_unsigned(0, 37));  -- ufix37 [128]
  SIGNAL Delay1_out1                      : unsigned(36 DOWNTO 0);  -- ufix37_En30

BEGIN
  dataIn_unsigned <= unsigned(dataIn);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND en = '1' THEN
        Delay1_reg_rsvd(0) <= dataIn_unsigned;
        Delay1_reg_rsvd(1 TO 127) <= Delay1_reg_rsvd(0 TO 126);
      END IF;
    END IF;
  END PROCESS Delay1_process;

  Delay1_out1 <= Delay1_reg_rsvd(127);

  dataOut <= std_logic_vector(Delay1_out1);

END rtl;

