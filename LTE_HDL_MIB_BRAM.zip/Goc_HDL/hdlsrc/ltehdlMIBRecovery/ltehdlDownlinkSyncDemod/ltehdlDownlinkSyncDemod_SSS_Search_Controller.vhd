-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_SSS_Search_Controller IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        startBuffering                    :   IN    std_logic;
        PSSEndTimingOffset                :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
        PSSDetected                       :   IN    std_logic;
        validIn                           :   IN    std_logic;
        modeDone                          :   IN    std_logic;
        SSSFound                          :   IN    std_logic;
        addr                              :   OUT   std_logic_vector(9 DOWNTO 0);  -- ufix10
        wrEn                              :   OUT   std_logic;
        rdEn                              :   OUT   std_logic;
        duplexMode                        :   OUT   std_logic;  -- ufix1
        SSSPSSPhaseAligned                :   OUT   std_logic;
        done                              :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_SSS_Search_Controller;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_SSS_Search_Controller IS

  -- Functions
  -- HDLCODER_TO_STDLOGIC 
  FUNCTION hdlcoder_to_stdlogic(arg: boolean) RETURN std_logic IS
  BEGIN
    IF arg THEN
      RETURN '1';
    ELSE
      RETURN '0';
    END IF;
  END FUNCTION;


  -- Signals
  SIGNAL PSSEndTimingOffset_unsigned      : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL addr_tmp                         : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL attempt                          : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL reg_timingReference              : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_state                        : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL reg_duplexMode                   : std_logic;  -- ufix1
  SIGNAL reg_attempt                      : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL reg_PSSEndTimingOffset           : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_SSSPSSPhaseAligned           : std_logic;
  SIGNAL reg_addr                         : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL reg_PSSEndAddr                   : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL reg_SSSEndAddr                   : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL reg_wrEn                         : std_logic;
  SIGNAL reg_rdEn                         : std_logic;
  SIGNAL reg_done                         : std_logic;
  SIGNAL reg_timingReference_next         : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_state_next                   : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL reg_duplexMode_next              : std_logic;  -- ufix1
  SIGNAL reg_attempt_next                 : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL reg_PSSEndTimingOffset_next      : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_SSSPSSPhaseAligned_next      : std_logic;
  SIGNAL reg_addr_next                    : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL reg_PSSEndAddr_next              : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL reg_SSSEndAddr_next              : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL reg_wrEn_next                    : std_logic;
  SIGNAL reg_rdEn_next                    : std_logic;
  SIGNAL reg_done_next                    : std_logic;

BEGIN
  PSSEndTimingOffset_unsigned <= unsigned(PSSEndTimingOffset);

  SSS_Search_Controller_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        reg_timingReference <= to_unsigned(16#0000#, 15);
        reg_state <= to_unsigned(16#0#, 3);
        reg_duplexMode <= '0';
        reg_attempt <= to_unsigned(16#0#, 4);
        reg_PSSEndTimingOffset <= to_unsigned(16#0000#, 15);
        reg_SSSPSSPhaseAligned <= '1';
        reg_addr <= to_unsigned(16#000#, 10);
        reg_PSSEndAddr <= to_unsigned(16#000#, 10);
        reg_SSSEndAddr <= to_unsigned(16#000#, 10);
        reg_wrEn <= '1';
        reg_rdEn <= '0';
        reg_done <= '0';
      ELSIF enb = '1' THEN
        reg_timingReference <= reg_timingReference_next;
        reg_state <= reg_state_next;
        reg_duplexMode <= reg_duplexMode_next;
        reg_attempt <= reg_attempt_next;
        reg_PSSEndTimingOffset <= reg_PSSEndTimingOffset_next;
        reg_SSSPSSPhaseAligned <= reg_SSSPSSPhaseAligned_next;
        reg_addr <= reg_addr_next;
        reg_PSSEndAddr <= reg_PSSEndAddr_next;
        reg_SSSEndAddr <= reg_SSSEndAddr_next;
        reg_wrEn <= reg_wrEn_next;
        reg_rdEn <= reg_rdEn_next;
        reg_done <= reg_done_next;
      END IF;
    END IF;
  END PROCESS SSS_Search_Controller_process;

  SSS_Search_Controller_output : PROCESS (PSSDetected, PSSEndTimingOffset_unsigned, SSSFound, modeDone, reg_PSSEndAddr,
       reg_PSSEndTimingOffset, reg_SSSEndAddr, reg_SSSPSSPhaseAligned, reg_addr,
       reg_attempt, reg_done, reg_duplexMode, reg_rdEn, reg_state,
       reg_timingReference, reg_wrEn, startBuffering, validIn)
    VARIABLE next_state : unsigned(2 DOWNTO 0);
    VARIABLE next_done : std_logic;
  BEGIN
    -- Responsibilities
    -- * Maintains a timingReference to track sample timing.
    -- * On a start strobe, writes data into the SSS RAM circular buffer.
    -- * On PSSDetected, waits until the sample corresponding to timingOffset is
    --   written into the buffer and then stops writing.
    -- * Reads the SSS samples from the buffer for FDD mode and waits for
    ----------------------------------------------------------------------------
    -- Constants
    ----------------------------------------------------------------------------
    -- Frame structure constants @ 1.92Msps
    -- length of cyclic prefix 0
    -- length of cyclic prefixes 1 to 6
    -- length of useful part of OFDM symbol
    -- FDD mode:
    --       SSS                PSS
    -- [ Lcpn |    Lu    ][ Lcpn |    Lu    ]
    --         o<---- 2*Lu + Lcpn - 1 -----o
    --
    -- TDD mode:
    --       SSS          | subframe start                            PSS
    -- [ Lcpn |    Lu    ][ Lcp0 |    Lu    ][ Lcpn |    Lu    ][ Lcpn |    Lu    ]
    --         o<------------------- 4*Lu + 2*Lcpn + Lcp0 -1 --------------------o
    --
    -- State definitions
    -- Do nothing.
    -- Feed data into the buffer.
    -- Feed data into the buffer until last sample of PSS has been written.
    -- Last write cycle before starting to read SSS data back out of the buffer.
    -- Reading SSS locations for current mode.
    -- Waiting for SSS metric computer to complete current mode.
    -- duplexMode enumeration
    ----------------------------------------------------------------------------
    -- Initialize registers
    ----------------------------------------------------------------------------
    -- Assign outputs
    ----------------------------------------------------------------------------
    ----------------------------------------------------------------------------
    -- Update registers
    ----------------------------------------------------------------------------
    -- Change number of attempts for Coarse Mode
    --     if coarseMode
    --         maxAttempts = cast(1,'like',reg.attempt);
    --     else
    --         maxAttempts = cast(8,'like',reg.attempt);
    --     end
    -- Initialize next reg values to current values.
    reg_timingReference_next <= reg_timingReference;
    next_state := reg_state;
    reg_duplexMode_next <= reg_duplexMode;
    reg_attempt_next <= reg_attempt;
    reg_PSSEndTimingOffset_next <= reg_PSSEndTimingOffset;
    reg_SSSPSSPhaseAligned_next <= reg_SSSPSSPhaseAligned;
    reg_addr_next <= reg_addr;
    reg_PSSEndAddr_next <= reg_PSSEndAddr;
    reg_SSSEndAddr_next <= reg_SSSEndAddr;
    reg_wrEn_next <= reg_wrEn;
    reg_rdEn_next <= reg_rdEn;
    -- Timing reference, runs continuously.
    IF validIn = '1' THEN 
      IF reg_timingReference >= to_unsigned(16#4AFF#, 15) THEN 
        reg_timingReference_next <= to_unsigned(16#0000#, 15);
      ELSE 
        reg_timingReference_next <= reg_timingReference + to_unsigned(16#0001#, 15);
      END IF;
    END IF;
    -- State machine
    IF startBuffering = '1' THEN 
      next_state := to_unsigned(16#1#, 3);
      reg_duplexMode_next <= '0';
      reg_addr_next <= to_unsigned(16#3FF#, 10);
      -- Allow this to wrap.
      reg_wrEn_next <= '0';
      reg_rdEn_next <= '0';
      reg_SSSPSSPhaseAligned_next <= '1';
      reg_PSSEndAddr_next <= to_unsigned(16#000#, 10);
      reg_SSSEndAddr_next <= to_unsigned(16#000#, 10);
      reg_attempt_next <= to_unsigned(16#0#, 4);
      reg_PSSEndTimingOffset_next <= to_unsigned(16#0000#, 15);
    ELSE 
      -- finished searching, do nothing
      CASE reg_state IS
        WHEN "001" =>
          IF PSSDetected = '1' THEN 
            next_state := to_unsigned(16#2#, 3);
            reg_attempt_next <= to_unsigned(16#1#, 4);
            reg_PSSEndTimingOffset_next <= PSSEndTimingOffset_unsigned;
          END IF;
          IF validIn = '1' THEN 
            reg_addr_next <= reg_addr + to_unsigned(16#001#, 10);
          END IF;
          reg_wrEn_next <= validIn;
          reg_rdEn_next <= '0';
        WHEN "010" =>
          IF validIn = '1' THEN 
            reg_addr_next <= reg_addr + to_unsigned(16#001#, 10);
            IF reg_timingReference = reg_PSSEndTimingOffset THEN 
              next_state := to_unsigned(16#3#, 3);
            END IF;
          END IF;
          reg_wrEn_next <= validIn;
          reg_rdEn_next <= '0';
        WHEN "011" =>
          -- Start reading locations on next cycle.
          next_state := to_unsigned(16#4#, 3);
          -- reg.addr is currently pointing to the last sample of PSS.
          -- Move addr to start of SSS location.
          IF reg_duplexMode = '0' THEN 
            -- FDD
            reg_addr_next <= reg_addr - to_unsigned(16#108#, 10);
            -- Store PSSEnd address for later.
            reg_PSSEndAddr_next <= reg_addr;
            reg_SSSEndAddr_next <= reg_addr - to_unsigned(16#089#, 10);
          ELSE 
            -- TDD
            reg_addr_next <= reg_PSSEndAddr - to_unsigned(16#21B#, 10);
            reg_SSSEndAddr_next <= reg_PSSEndAddr - to_unsigned(16#19C#, 10);
          END IF;
          -- 2*Lu + 2*Lcpn + Lcp0
          -- Stop writing and start reading out values.
          reg_wrEn_next <= '0';
          reg_rdEn_next <= '1';
        WHEN "100" =>
          IF reg_addr = reg_SSSEndAddr THEN 
            next_state := to_unsigned(16#5#, 3);
            reg_addr_next <= to_unsigned(16#3FF#, 10);
            reg_wrEn_next <= '0';
            reg_rdEn_next <= '0';
          ELSE 
            reg_addr_next <= reg_addr + to_unsigned(16#001#, 10);
            reg_wrEn_next <= '0';
            reg_rdEn_next <= '1';
          END IF;
        WHEN "101" =>
          IF modeDone = '1' THEN 
            IF reg_duplexMode = '0' THEN 
              -- Done searching FDD SSS position
              next_state := to_unsigned(16#3#, 3);
              reg_duplexMode_next <= '1';
            ELSE 
              -- Done searching TDD SSS position
              IF SSSFound = '1' THEN 
                next_state := to_unsigned(16#6#, 3);
              ELSIF reg_attempt = to_unsigned(16#4#, 4) THEN 
                next_state := to_unsigned(16#6#, 3);
              ELSE 
                -- No SSS found. Start buffering again and
                -- wait for next SSS location to be received.
                next_state := to_unsigned(16#2#, 3);
                reg_duplexMode_next <= '0';
                -- toggle between PSS end offsets since there are two per frame.
                IF reg_PSSEndTimingOffset < to_unsigned(16#2580#, 15) THEN 
                  reg_PSSEndTimingOffset_next <= reg_PSSEndTimingOffset + to_unsigned(16#2580#, 15);
                ELSE 
                  reg_PSSEndTimingOffset_next <= reg_PSSEndTimingOffset - to_unsigned(16#2580#, 15);
                END IF;
                -- keep a record of whether or not PSS and SSS were detected in the
                -- same "phase", i.e. in the same half frame offset.
                reg_SSSPSSPhaseAligned_next <=  NOT reg_SSSPSSPhaseAligned;
                -- Keep track of attempt #.
                reg_attempt_next <= reg_attempt + to_unsigned(16#1#, 4);
              END IF;
            END IF;
          END IF;
        WHEN "110" =>
          NULL;
        WHEN OTHERS => 
          -- includes IDLE
          next_state := to_unsigned(16#0#, 3);
          reg_duplexMode_next <= '0';
          reg_addr_next <= to_unsigned(16#000#, 10);
          reg_wrEn_next <= '0';
          reg_rdEn_next <= '0';
          reg_SSSPSSPhaseAligned_next <= '1';
          reg_SSSEndAddr_next <= to_unsigned(16#000#, 10);
          reg_attempt_next <= to_unsigned(16#0#, 4);
          reg_PSSEndTimingOffset_next <= to_unsigned(16#0000#, 15);
      END CASE;
    END IF;
    next_done := hdlcoder_to_stdlogic((reg_state = to_unsigned(16#5#, 3)) AND (next_state = to_unsigned(16#6#, 3)));
    -- Write new values to registers.
    reg_state_next <= next_state;
    reg_done_next <= next_done;
    addr_tmp <= reg_addr;
    wrEn <= reg_wrEn;
    rdEn <= reg_rdEn;
    duplexMode <= reg_duplexMode;
    SSSPSSPhaseAligned <= reg_SSSPSSPhaseAligned;
    attempt <= reg_attempt;
    done <= reg_done;
  END PROCESS SSS_Search_Controller_output;


  addr <= std_logic_vector(addr_tmp);

END rtl;

