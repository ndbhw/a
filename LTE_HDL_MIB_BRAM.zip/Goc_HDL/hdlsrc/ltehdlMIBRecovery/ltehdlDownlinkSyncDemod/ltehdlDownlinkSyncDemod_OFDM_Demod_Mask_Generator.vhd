-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_OFDM_Demod_Mask_Generator IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        validIn                           :   IN    std_logic;
        reset                             :   IN    std_logic;
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_OFDM_Demod_Mask_Generator;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_OFDM_Demod_Mask_Generator IS

  -- Signals
  SIGNAL reg_sampleCount                  : unsigned(11 DOWNTO 0);  -- ufix12
  SIGNAL reg_symbolCount                  : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL reg_validOut                     : std_logic;
  SIGNAL reg_sampleCount_next             : unsigned(11 DOWNTO 0);  -- ufix12
  SIGNAL reg_symbolCount_next             : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL reg_validOut_next                : std_logic;

BEGIN
  OFDM_Demod_Mask_Generator_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        reg_sampleCount <= to_unsigned(16#000#, 12);
        reg_symbolCount <= to_unsigned(16#0#, 3);
        reg_validOut <= '0';
      ELSIF enb_1_2_0 = '1' THEN
        reg_sampleCount <= reg_sampleCount_next;
        reg_symbolCount <= reg_symbolCount_next;
        reg_validOut <= reg_validOut_next;
      END IF;
    END IF;
  END PROCESS OFDM_Demod_Mask_Generator_process;

  OFDM_Demod_Mask_Generator_output : PROCESS (reg_sampleCount, reg_symbolCount, reg_validOut, reset, validIn)
    VARIABLE Lcp : unsigned(11 DOWNTO 0);
    VARIABLE Lsym : unsigned(11 DOWNTO 0);
  BEGIN
    -- length of cyclic prefix 0
    -- length of cyclic prefixes 1 to 6
    -- length of useful part of each symbol
    -- number of symbols per slot
    -- Assign outputs
    -- Initialize next states
    reg_sampleCount_next <= reg_sampleCount;
    reg_symbolCount_next <= reg_symbolCount;
    -- Determine current CP length
    IF reg_symbolCount = to_unsigned(16#0#, 3) THEN 
      Lcp := to_unsigned(16#0A0#, 12);
      Lsym := to_unsigned(16#8A0#, 12);
    ELSE 
      Lcp := to_unsigned(16#090#, 12);
      Lsym := to_unsigned(16#890#, 12);
    END IF;
    -- Counters for keeping track of samples and symbols within each slot
    IF reset = '1' THEN 
      reg_sampleCount_next <= to_unsigned(16#000#, 12);
      reg_symbolCount_next <= to_unsigned(16#0#, 3);
    ELSIF validIn = '1' THEN 
      IF resize(reg_sampleCount, 13) < (resize(Lsym, 13) - to_unsigned(16#0001#, 13)) THEN 
        reg_sampleCount_next <= reg_sampleCount + to_unsigned(16#001#, 12);
      ELSE 
        -- last sample of symbol
        reg_sampleCount_next <= to_unsigned(16#000#, 12);
        IF reg_symbolCount < to_unsigned(16#6#, 3) THEN 
          reg_symbolCount_next <= reg_symbolCount + to_unsigned(16#1#, 3);
        ELSE 
          -- last sample of slot
          reg_symbolCount_next <= to_unsigned(16#0#, 3);
        END IF;
      END IF;
    END IF;
    -- next validOut value
    IF reg_sampleCount < Lcp THEN 
      reg_validOut_next <= '0';
    ELSE 
      reg_validOut_next <= validIn;
    END IF;
    -- Update register with next values
    validOut <= reg_validOut;
  END PROCESS OFDM_Demod_Mask_Generator_output;


END rtl;

