-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_SSS_Correlation_Controller IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        NCellID2                          :   IN    std_logic_vector(1 DOWNTO 0);  -- ufix2
        validIn                           :   IN    std_logic;
        sampleIndex                       :   OUT   std_logic_vector(5 DOWNTO 0);  -- ufix6
        wrEn                              :   OUT   std_logic;
        rdEn                              :   OUT   std_logic;
        seqNum                            :   OUT   std_logic_vector(9 DOWNTO 0);  -- ufix10
        seqStart                          :   OUT   std_logic;
        seqEnd                            :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_SSS_Correlation_Controller;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_SSS_Correlation_Controller IS

  -- Signals
  SIGNAL NCellID2_unsigned                : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL sampleIndex_tmp                  : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL seqNum_tmp                       : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL reg_validIn                      : std_logic;
  SIGNAL reg_state                        : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL reg_FFTIndex                     : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL reg_sampleIndex                  : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL reg_wrEn                         : std_logic;
  SIGNAL reg_rdEn                         : std_logic;
  SIGNAL reg_seqNum                       : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL reg_seqStart                     : std_logic;
  SIGNAL reg_seqEnd                       : std_logic;
  SIGNAL reg_validIn_next                 : std_logic;
  SIGNAL reg_state_next                   : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL reg_FFTIndex_next                : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL reg_sampleIndex_next             : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL reg_wrEn_next                    : std_logic;
  SIGNAL reg_rdEn_next                    : std_logic;
  SIGNAL reg_seqNum_next                  : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL reg_seqStart_next                : std_logic;
  SIGNAL reg_seqEnd_next                  : std_logic;

BEGIN
  NCellID2_unsigned <= unsigned(NCellID2);

  SSS_Correlation_Controller_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        reg_validIn <= '0';
        reg_state <= to_unsigned(16#0#, 3);
        reg_FFTIndex <= to_unsigned(16#00#, 7);
        reg_sampleIndex <= to_unsigned(16#00#, 6);
        reg_wrEn <= '0';
        reg_rdEn <= '0';
        reg_seqNum <= to_unsigned(16#000#, 10);
        reg_seqStart <= '0';
        reg_seqEnd <= '0';
      ELSIF enb = '1' THEN
        reg_validIn <= reg_validIn_next;
        reg_state <= reg_state_next;
        reg_FFTIndex <= reg_FFTIndex_next;
        reg_sampleIndex <= reg_sampleIndex_next;
        reg_wrEn <= reg_wrEn_next;
        reg_rdEn <= reg_rdEn_next;
        reg_seqNum <= reg_seqNum_next;
        reg_seqStart <= reg_seqStart_next;
        reg_seqEnd <= reg_seqEnd_next;
      END IF;
    END IF;
  END PROCESS SSS_Correlation_Controller_process;

  SSS_Correlation_Controller_output : PROCESS (NCellID2_unsigned, reg_FFTIndex, reg_rdEn, reg_sampleIndex, reg_seqEnd,
       reg_seqNum, reg_seqStart, reg_state, reg_validIn, reg_wrEn, validIn)
    VARIABLE next_FFTIndex : unsigned(6 DOWNTO 0);
    VARIABLE next_wrEn : std_logic;
  BEGIN
    ----------------------------------------------------------------------------
    -- Constants
    ----------------------------------------------------------------------------
    -- number of SSS sequences checked for a given PSS
    -- State definitions
    -- State wordlength
    ----------------------------------------------------------------------------
    -- Initialize registers
    ----------------------------------------------------------------------------
    -- Assign outputs
    ----------------------------------------------------------------------------
    ----------------------------------------------------------------------------
    -- Update registers
    ----------------------------------------------------------------------------
    -- Initialize next reg values to current values.
    reg_state_next <= reg_state;
    next_FFTIndex := reg_FFTIndex;
    reg_sampleIndex_next <= reg_sampleIndex;
    next_wrEn := reg_wrEn;
    reg_rdEn_next <= reg_rdEn;
    reg_seqNum_next <= reg_seqNum;
    reg_seqStart_next <= reg_seqStart;
    reg_seqEnd_next <= reg_seqEnd;
    -- Register the validIn signal so that edge detection can be used to
    -- establish the start of the 128-point IFFT output.
    -- State machine
    IF (validIn AND ( NOT reg_validIn)) = '1' THEN 
      -- If validIn just went from LOW to HIGH
      reg_state_next <= to_unsigned(16#1#, 3);
      reg_sampleIndex_next <= to_unsigned(16#00#, 6);
      next_FFTIndex := to_unsigned(16#00#, 7);
      next_wrEn := '0';
      reg_rdEn_next <= '0';
      reg_seqNum_next <= to_unsigned(16#000#, 10);
      reg_seqStart_next <= '0';
      reg_seqEnd_next <= '0';
    ELSE 
      -- includes IDLE
      CASE reg_state IS
        WHEN "001" =>
          IF reg_FFTIndex = to_unsigned(16#7F#, 7) THEN 
            reg_state_next <= to_unsigned(16#2#, 3);
            reg_sampleIndex_next <= to_unsigned(16#00#, 6);
            -- Initialize to NCellID
            next_FFTIndex := to_unsigned(16#00#, 7);
            next_wrEn := '0';
            reg_rdEn_next <= '1';
            reg_seqNum_next <= resize(NCellID2_unsigned, 10);
            reg_seqStart_next <= '1';
            reg_seqEnd_next <= '0';
          ELSE 
            next_FFTIndex := reg_FFTIndex + to_unsigned(16#01#, 7);
            -- Reorder SSS subcarrier values on the fly so that they
            -- land in the correct order in RAM.
            IF (next_FFTIndex >= to_unsigned(16#01#, 7)) AND (next_FFTIndex <= to_unsigned(16#1F#, 7)) THEN 
              -- Above DC carrier.
              next_wrEn := '1';
            ELSIF next_FFTIndex >= to_unsigned(16#61#, 7) THEN 
              -- Below DC carrier.
              next_wrEn := '1';
            ELSE 
              -- Somewhere else.
              next_wrEn := '0';
            END IF;
            -- Determine write sample index
            IF next_FFTIndex = to_unsigned(16#01#, 7) THEN 
              reg_sampleIndex_next <= to_unsigned(16#1F#, 6);
            ELSIF next_FFTIndex = to_unsigned(16#61#, 7) THEN 
              reg_sampleIndex_next <= to_unsigned(16#00#, 6);
            ELSIF next_wrEn = '1' THEN 
              reg_sampleIndex_next <= reg_sampleIndex + to_unsigned(16#01#, 6);
            END IF;
            reg_rdEn_next <= '0';
          END IF;
        WHEN "010" =>
          IF reg_sampleIndex = to_unsigned(16#3D#, 6) THEN 
            reg_sampleIndex_next <= to_unsigned(16#00#, 6);
            IF reg_seqNum >= to_unsigned(16#3ED#, 10) THEN 
              -- Finished.
              reg_state_next <= to_unsigned(16#0#, 3);
              reg_seqNum_next <= to_unsigned(16#000#, 10);
              reg_seqStart_next <= '0';
              reg_seqEnd_next <= '0';
            ELSE 
              reg_seqNum_next <= reg_seqNum + to_unsigned(16#003#, 10);
              reg_seqStart_next <= '1';
              reg_seqEnd_next <= '0';
            END IF;
          ELSE 
            reg_sampleIndex_next <= reg_sampleIndex + to_unsigned(16#01#, 6);
            reg_seqStart_next <= '0';
            IF reg_sampleIndex = to_unsigned(16#3C#, 6) THEN 
              reg_seqEnd_next <= '1';
            ELSE 
              reg_seqEnd_next <= '0';
            END IF;
          END IF;
        WHEN OTHERS => 
          NULL;
      END CASE;
    END IF;
    -- Write new values to registers.
    reg_validIn_next <= validIn;
    reg_FFTIndex_next <= next_FFTIndex;
    reg_wrEn_next <= next_wrEn;
    sampleIndex_tmp <= reg_sampleIndex;
    wrEn <= reg_wrEn;
    rdEn <= reg_rdEn;
    seqNum_tmp <= reg_seqNum;
    seqStart <= reg_seqStart;
    seqEnd <= reg_seqEnd;
  END PROCESS SSS_Correlation_Controller_output;


  sampleIndex <= std_logic_vector(sampleIndex_tmp);

  seqNum <= std_logic_vector(seqNum_tmp);

END rtl;

