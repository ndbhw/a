-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_ThresholdLimiter IS
  PORT( x_x                               :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30
        y_y                               :   OUT   std_logic_vector(29 DOWNTO 0)  -- ufix30_En24
        );
END ltehdlDownlinkSyncDemod_ThresholdLimiter;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_ThresholdLimiter IS

  -- Signals
  SIGNAL x_unsigned                       : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL y_tmp                            : unsigned(29 DOWNTO 0);  -- ufix30_En24

BEGIN
  x_unsigned <= unsigned(x_x);

  -- Apply a lower limit to the threshold.
  -- Threshold is computed by summing across 128 samples.
  -- Set lower limit to be equivalent of all 128 samples
  -- having their LSB set to 1 and all others set to 0. 
  
  y_tmp <= to_unsigned(16#00000080#, 30) WHEN x_unsigned < to_unsigned(16#00000080#, 30) ELSE
      x_unsigned;

  y_y <= std_logic_vector(y_tmp);

END rtl;

