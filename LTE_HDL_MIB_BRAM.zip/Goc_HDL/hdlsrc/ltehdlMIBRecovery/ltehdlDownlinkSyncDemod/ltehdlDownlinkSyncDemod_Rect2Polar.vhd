-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_Rect2Polar IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(23 DOWNTO 0);  -- sfix24_En23
        dataIn_im                         :   IN    std_logic_vector(23 DOWNTO 0);  -- sfix24_En23
        validIn                           :   IN    std_logic;
        magOut                            :   OUT   std_logic_vector(24 DOWNTO 0);  -- sfix25_En23
        angleOut                          :   OUT   std_logic_vector(13 DOWNTO 0);  -- sfix14_En14
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Rect2Polar;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Rect2Polar IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_HDL_CMA_core
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          In_re                           :   IN    std_logic_vector(23 DOWNTO 0);  -- ufix24
          In_im                           :   IN    std_logic_vector(23 DOWNTO 0);  -- ufix24
          validIn                         :   IN    std_logic;
          magnitude                       :   OUT   std_logic_vector(24 DOWNTO 0);  -- ufix25
          angle_rsvd                      :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_HDL_CMA_core
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_HDL_CMA_core(rtl);

  -- Signals
  SIGNAL dataIn_re_signed                 : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL dataIn_im_signed                 : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay5_reg_re                    : vector_of_signed24(0 TO 1) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [2]
  SIGNAL Delay5_reg_im                    : vector_of_signed24(0 TO 1) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [2]
  SIGNAL cxDataIn_re                      : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL cxDataIn_im                      : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay1_reg_rsvd                  : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [2]
  SIGNAL cxValidIn                        : std_logic;
  SIGNAL cxMagOut                         : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL cxAngOut                         : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL cxValidOut                       : std_logic;
  SIGNAL cxMagOut_signed                  : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL Delay2_out1                      : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL cxAngOut_signed                  : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL Delay3_out1                      : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL Gain_cast                        : signed(53 DOWNTO 0);  -- sfix54_En52
  SIGNAL Gain_out1                        : signed(13 DOWNTO 0);  -- sfix14_En14
  SIGNAL Delay4_out1                      : std_logic := '0';

BEGIN
  UComplex_to_Magnitude_Angle : ltehdlDownlinkSyncDemod_HDL_CMA_core
    PORT MAP( clk => clk,
              enb => enb,
              In_re => std_logic_vector(cxDataIn_re),  -- ufix24
              In_im => std_logic_vector(cxDataIn_im),  -- ufix24
              validIn => cxValidIn,
              magnitude => cxMagOut,  -- ufix25
              angle_rsvd => cxAngOut,  -- ufix27
              validOut => cxValidOut
              );

  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay5_reg_im(0) <= dataIn_im_signed;
        Delay5_reg_im(1) <= Delay5_reg_im(0);
        Delay5_reg_re(0) <= dataIn_re_signed;
        Delay5_reg_re(1) <= Delay5_reg_re(0);
      END IF;
    END IF;
  END PROCESS Delay5_process;

  cxDataIn_re <= Delay5_reg_re(1);
  cxDataIn_im <= Delay5_reg_im(1);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_reg_rsvd(0) <= validIn;
        Delay1_reg_rsvd(1) <= Delay1_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay1_process;

  cxValidIn <= Delay1_reg_rsvd(1);

  cxMagOut_signed <= signed(cxMagOut);

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_out1 <= cxMagOut_signed;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  magOut <= std_logic_vector(Delay2_out1);

  cxAngOut_signed <= signed(cxAngOut);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1 <= cxAngOut_signed;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  Gain_cast <= resize(Delay3_out1 & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 54);
  
  Gain_out1 <= "01111111111111" WHEN ((Gain_cast(53) = '0') AND (Gain_cast(52 DOWNTO 51) /= "00")) OR ((Gain_cast(53) = '0') AND (Gain_cast(51 DOWNTO 38) = "01111111111111")) ELSE
      "10000000000000" WHEN (Gain_cast(53) = '1') AND (Gain_cast(52 DOWNTO 51) /= "11") ELSE
      Gain_cast(51 DOWNTO 38) + ('0' & (Gain_cast(37) AND (( NOT Gain_cast(53)) OR (Gain_cast(36) OR Gain_cast(35) OR Gain_cast(34) OR Gain_cast(33) OR Gain_cast(32) OR Gain_cast(31) OR Gain_cast(30) OR Gain_cast(29) OR Gain_cast(28) OR 
        Gain_cast(27) OR Gain_cast(26) OR Gain_cast(25) OR Gain_cast(24) OR Gain_cast(23) OR Gain_cast(22) OR Gain_cast(21) OR Gain_cast(20) OR Gain_cast(19) OR Gain_cast(18) OR Gain_cast(17) OR Gain_cast(16) OR Gain_cast(15) OR Gain_cast(14) OR 
        Gain_cast(13) OR Gain_cast(12) OR Gain_cast(11) OR Gain_cast(10) OR Gain_cast(9) OR Gain_cast(8) OR Gain_cast(7) OR Gain_cast(6) OR Gain_cast(5) OR Gain_cast(4) OR Gain_cast(3) OR Gain_cast(2) OR Gain_cast(1) OR Gain_cast(0)))));

  angleOut <= std_logic_vector(Gain_out1);

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay4_out1 <= cxValidOut;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  validOut <= Delay4_out1;

END rtl;

