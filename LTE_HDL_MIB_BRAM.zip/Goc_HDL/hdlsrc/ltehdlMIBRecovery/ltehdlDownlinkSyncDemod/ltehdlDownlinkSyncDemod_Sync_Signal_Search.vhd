-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_Sync_Signal_Search IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        start                             :   IN    std_logic;
        startTime                         :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
        NCellID                           :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
        TDDMode                           :   OUT   std_logic;
        timingOffset                      :   OUT   std_logic_vector(14 DOWNTO 0);  -- ufix15
        cellDetected                      :   OUT   std_logic;
        cellSearchDone                    :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Sync_Signal_Search;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Sync_Signal_Search IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_PSS_Searcher
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          start                           :   IN    std_logic;
          startTime                       :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
          timingOffset                    :   OUT   std_logic_vector(14 DOWNTO 0);  -- ufix15
          NCellID2                        :   OUT   std_logic_vector(1 DOWNTO 0);  -- ufix2
          done                            :   OUT   std_logic;
          success                         :   OUT   std_logic;
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Stream_Syncronizer
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          pop                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          push                            :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_SSS_Searcher
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          startBuffering                  :   IN    std_logic;
          PSSEndTimingOffset              :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
          NCellID2                        :   IN    std_logic_vector(1 DOWNTO 0);  -- ufix2
          PSSDetected                     :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          NCellID                         :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
          done                            :   OUT   std_logic;
          success                         :   OUT   std_logic;
          timingOffset                    :   OUT   std_logic_vector(14 DOWNTO 0);  -- ufix15
          TDD                             :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Output_Interfacing
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          reset                           :   IN    std_logic;
          PSSDone                         :   IN    std_logic;
          PSSSuccess                      :   IN    std_logic;
          SSSDone                         :   IN    std_logic;
          SSSSuccess                      :   IN    std_logic;
          NCellIDIn                       :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          TDDModeIn                       :   IN    std_logic;
          timingOffsetIn                  :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
          NCellIDOut                      :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
          TDDModeOut                      :   OUT   std_logic;
          timingOffsetOut                 :   OUT   std_logic_vector(14 DOWNTO 0);  -- ufix15
          cellDetected                    :   OUT   std_logic;
          cellsearchDone                  :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_PSS_Searcher
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_PSS_Searcher(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Stream_Syncronizer
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Stream_Syncronizer(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_SSS_Searcher
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_SSS_Searcher(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Output_Interfacing
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Output_Interfacing(rtl);

  -- Signals
  SIGNAL timingOffset_1                   : std_logic_vector(14 DOWNTO 0);  -- ufix15
  SIGNAL NCellID2                         : std_logic_vector(1 DOWNTO 0);  -- ufix2
  SIGNAL PSSDone                          : std_logic;
  SIGNAL PSSSuccess                       : std_logic;
  SIGNAL streamSyncPop                    : std_logic;
  SIGNAL timingOffset_unsigned            : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL NCellID2_unsigned                : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL Delay1_out1                      : std_logic := '0';
  SIGNAL Delay2_out1                      : unsigned(14 DOWNTO 0) := to_unsigned(16#0000#, 15);  -- ufix15
  SIGNAL Delay3_out1                      : unsigned(1 DOWNTO 0) := to_unsigned(16#0#, 2);  -- ufix2
  SIGNAL PSSDetected                      : std_logic;
  SIGNAL Delay4_out1                      : std_logic := '0';
  SIGNAL dataOut_re                       : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dataOut_im                       : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL validOut                         : std_logic;
  SIGNAL NCellID_1                        : std_logic_vector(8 DOWNTO 0);  -- ufix9
  SIGNAL SSSDone                          : std_logic;
  SIGNAL SSSSuccess                       : std_logic;
  SIGNAL timingOffset_2                   : std_logic_vector(14 DOWNTO 0);  -- ufix15
  SIGNAL TDD                              : std_logic;
  SIGNAL NCellID_tmp                      : std_logic_vector(8 DOWNTO 0);  -- ufix9
  SIGNAL timingOffset_tmp                 : std_logic_vector(14 DOWNTO 0);  -- ufix15

BEGIN
  UPSS_Searcher : ltehdlDownlinkSyncDemod_PSS_Searcher
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              dataIn_re => dataIn_re,  -- sfix16_En15
              dataIn_im => dataIn_im,  -- sfix16_En15
              validIn => validIn,
              start => start,
              startTime => startTime,  -- ufix15
              timingOffset => timingOffset_1,  -- ufix15
              NCellID2 => NCellID2,  -- ufix2
              done => PSSDone,
              success => PSSSuccess,
              validOut => streamSyncPop
              );

  UStream_Syncronizer : ltehdlDownlinkSyncDemod_Stream_Syncronizer
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              pop => streamSyncPop,
              dataIn_re => dataIn_re,  -- sfix16_En15
              dataIn_im => dataIn_im,  -- sfix16_En15
              push => validIn,
              dataOut_re => dataOut_re,  -- sfix16_En15
              dataOut_im => dataOut_im,  -- sfix16_En15
              validOut => validOut
              );

  USSS_Searcher : ltehdlDownlinkSyncDemod_SSS_Searcher
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              startBuffering => Delay1_out1,
              PSSEndTimingOffset => std_logic_vector(Delay2_out1),  -- ufix15
              NCellID2 => std_logic_vector(Delay3_out1),  -- ufix2
              PSSDetected => Delay4_out1,
              dataIn_re => dataOut_re,  -- sfix16_En15
              dataIn_im => dataOut_im,  -- sfix16_En15
              validIn => validOut,
              NCellID => NCellID_1,  -- ufix9
              done => SSSDone,
              success => SSSSuccess,
              timingOffset => timingOffset_2,  -- ufix15
              TDD => TDD
              );

  UOutput_Interfacing : ltehdlDownlinkSyncDemod_Output_Interfacing
    PORT MAP( clk => clk,
              enb => enb,
              reset => start,
              PSSDone => PSSDone,
              PSSSuccess => PSSSuccess,
              SSSDone => SSSDone,
              SSSSuccess => SSSSuccess,
              NCellIDIn => NCellID_1,  -- ufix9
              TDDModeIn => TDD,
              timingOffsetIn => timingOffset_2,  -- ufix15
              NCellIDOut => NCellID_tmp,  -- ufix9
              TDDModeOut => TDDMode,
              timingOffsetOut => timingOffset_tmp,  -- ufix15
              cellDetected => cellDetected,
              cellsearchDone => cellSearchDone
              );

  timingOffset_unsigned <= unsigned(timingOffset_1);

  NCellID2_unsigned <= unsigned(NCellID2);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1 <= start;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_out1 <= timingOffset_unsigned;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1 <= NCellID2_unsigned;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  PSSDetected <= PSSDone AND PSSSuccess;

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay4_out1 <= PSSDetected;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  NCellID <= NCellID_tmp;

  timingOffset <= timingOffset_tmp;

END rtl;

