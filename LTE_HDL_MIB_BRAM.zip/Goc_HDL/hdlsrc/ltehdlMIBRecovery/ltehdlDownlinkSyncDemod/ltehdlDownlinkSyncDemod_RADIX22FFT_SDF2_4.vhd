-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_4 IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        dout_3_1_re                       :   IN    std_logic_vector(18 DOWNTO 0);  -- ufix19
        dout_3_1_im                       :   IN    std_logic_vector(18 DOWNTO 0);  -- ufix19
        dout_3_1_vld                      :   IN    std_logic;
        rd_4_Addr                         :   IN    std_logic_vector(6 DOWNTO 0);  -- ufix7
        rd_4_Enb                          :   IN    std_logic;
        proc_4_enb                        :   IN    std_logic;
        multiply_4_J                      :   IN    std_logic;
        syncReset                         :   IN    std_logic;
        dout_4_1_re                       :   OUT   std_logic_vector(19 DOWNTO 0);  -- ufix20
        dout_4_1_im                       :   OUT   std_logic_vector(19 DOWNTO 0);  -- ufix20
        dout_4_1_vld                      :   OUT   std_logic;
        dinXTwdl_4_1_vld                  :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_4;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_4 IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    GENERIC( AddrWidth                    : integer;
             DataWidth                    : integer
             );
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          wr_din                          :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          wr_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          wr_en                           :   IN    std_logic;
          rd_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          dout                            :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0)  -- generic width
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_SDFCommutator4
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_3_1_vld                    :   IN    std_logic;
          xf_re                           :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
          xf_im                           :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
          xf_vld                          :   IN    std_logic;
          dinf_re                         :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
          dinf_im                         :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
          dinf_vld                        :   IN    std_logic;
          btf1_re                         :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
          btf1_im                         :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
          btf2_re                         :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
          btf2_im                         :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
          btfout_vld                      :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          wrData_re                       :   OUT   std_logic_vector(19 DOWNTO 0);  -- ufix20
          wrData_im                       :   OUT   std_logic_vector(19 DOWNTO 0);  -- ufix20
          wrAddr                          :   OUT   std_logic_vector(6 DOWNTO 0);  -- ufix7
          wrEnb                           :   OUT   std_logic;
          dout_4_1_re                     :   OUT   std_logic_vector(19 DOWNTO 0);  -- ufix20
          dout_4_1_im                     :   OUT   std_logic_vector(19 DOWNTO 0);  -- ufix20
          dout_4_1_vld                    :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_SDFCommutator4
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_SDFCommutator4(rtl);

  -- Signals
  SIGNAL dout_3_1_re_signed               : signed(18 DOWNTO 0);  -- sfix19_En15
  SIGNAL din_re                           : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL dout_3_1_im_signed               : signed(18 DOWNTO 0);  -- sfix19_En15
  SIGNAL din_im                           : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL btfin_vld                        : std_logic;
  SIGNAL saveEnb                          : std_logic;
  SIGNAL dinVld                           : std_logic;
  SIGNAL x_vld                            : std_logic := '0';
  SIGNAL x_vld_dly                        : std_logic := '0';
  SIGNAL btf2_im                          : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL btf2_re                          : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL btf1_im                          : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL btf1_re                          : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL dinf_im                          : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL dinf_re                          : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL xf_im                            : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL wrData_im                        : std_logic_vector(19 DOWNTO 0);  -- ufix20
  SIGNAL wrAddr                           : std_logic_vector(6 DOWNTO 0);  -- ufix7
  SIGNAL wrEnb                            : std_logic;
  SIGNAL x_im                             : std_logic_vector(19 DOWNTO 0);  -- ufix20
  SIGNAL x_im_signed                      : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL x_im_dly                         : signed(19 DOWNTO 0) := to_signed(16#00000#, 20);  -- sfix20_En15
  SIGNAL wrData_re                        : std_logic_vector(19 DOWNTO 0);  -- ufix20
  SIGNAL x_re                             : std_logic_vector(19 DOWNTO 0);  -- ufix20
  SIGNAL x_re_signed                      : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL x_re_dly                         : signed(19 DOWNTO 0) := to_signed(16#00000#, 20);  -- sfix20_En15
  SIGNAL Radix22ButterflyG2_procEnb_dly   : std_logic := '0';
  SIGNAL Radix22ButterflyG2_procEnb_dly1  : std_logic := '0';
  SIGNAL Radix22ButterflyG2_procEnb_dly2  : std_logic := '0';
  SIGNAL Radix22ButterflyG2_btf1_re_reg   : signed(20 DOWNTO 0) := to_signed(16#000000#, 21);  -- sfix21
  SIGNAL Radix22ButterflyG2_btf1_im_reg   : signed(20 DOWNTO 0) := to_signed(16#000000#, 21);  -- sfix21
  SIGNAL Radix22ButterflyG2_btf2_re_reg   : signed(20 DOWNTO 0) := to_signed(16#000000#, 21);  -- sfix21
  SIGNAL Radix22ButterflyG2_btf2_im_reg   : signed(20 DOWNTO 0) := to_signed(16#000000#, 21);  -- sfix21
  SIGNAL Radix22ButterflyG2_din_re_dly    : signed(19 DOWNTO 0) := to_signed(16#00000#, 20);  -- sfix20
  SIGNAL Radix22ButterflyG2_din_im_dly    : signed(19 DOWNTO 0) := to_signed(16#00000#, 20);  -- sfix20
  SIGNAL Radix22ButterflyG2_din_vld_dly   : std_logic := '0';
  SIGNAL Radix22ButterflyG2_x_re_dly      : signed(19 DOWNTO 0) := to_signed(16#00000#, 20);  -- sfix20
  SIGNAL Radix22ButterflyG2_x_im_dly      : signed(19 DOWNTO 0) := to_signed(16#00000#, 20);  -- sfix20
  SIGNAL Radix22ButterflyG2_x_vld_dly     : std_logic := '0';
  SIGNAL Radix22ButterflyG2_dinXTwdl_re_dly1 : signed(19 DOWNTO 0) := to_signed(16#00000#, 20);  -- sfix20
  SIGNAL Radix22ButterflyG2_dinXTwdl_im_dly1 : signed(19 DOWNTO 0) := to_signed(16#00000#, 20);  -- sfix20
  SIGNAL Radix22ButterflyG2_dinXTwdl_re_dly2 : signed(19 DOWNTO 0) := to_signed(16#00000#, 20);  -- sfix20
  SIGNAL Radix22ButterflyG2_dinXTwdl_im_dly2 : signed(19 DOWNTO 0) := to_signed(16#00000#, 20);  -- sfix20
  SIGNAL Radix22ButterflyG2_multiply_J_dly1 : std_logic := '0';
  SIGNAL Radix22ButterflyG2_procEnb_dly_next : std_logic;
  SIGNAL Radix22ButterflyG2_procEnb_dly1_next : std_logic;
  SIGNAL Radix22ButterflyG2_procEnb_dly2_next : std_logic;
  SIGNAL Radix22ButterflyG2_btf1_re_reg_next : signed(20 DOWNTO 0);  -- sfix21_En15
  SIGNAL Radix22ButterflyG2_btf1_im_reg_next : signed(20 DOWNTO 0);  -- sfix21_En15
  SIGNAL Radix22ButterflyG2_btf2_re_reg_next : signed(20 DOWNTO 0);  -- sfix21_En15
  SIGNAL Radix22ButterflyG2_btf2_im_reg_next : signed(20 DOWNTO 0);  -- sfix21_En15
  SIGNAL Radix22ButterflyG2_din_re_dly_next : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL Radix22ButterflyG2_din_im_dly_next : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL Radix22ButterflyG2_din_vld_dly_next : std_logic;
  SIGNAL Radix22ButterflyG2_x_re_dly_next : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL Radix22ButterflyG2_x_im_dly_next : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL Radix22ButterflyG2_x_vld_dly_next : std_logic;
  SIGNAL Radix22ButterflyG2_dinXTwdl_re_dly1_next : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL Radix22ButterflyG2_dinXTwdl_im_dly1_next : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL Radix22ButterflyG2_dinXTwdl_re_dly2_next : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL Radix22ButterflyG2_dinXTwdl_im_dly2_next : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL Radix22ButterflyG2_multiply_J_dly1_next : std_logic;
  SIGNAL xf_re                            : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL xf_vld                           : std_logic;
  SIGNAL dinf_vld                         : std_logic;
  SIGNAL btfout_vld                       : std_logic;
  SIGNAL dout_4_1_re_tmp                  : std_logic_vector(19 DOWNTO 0);  -- ufix20
  SIGNAL dout_4_1_im_tmp                  : std_logic_vector(19 DOWNTO 0);  -- ufix20

BEGIN
  UdataMEM_im_0_4 : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    GENERIC MAP( AddrWidth => 7,
                 DataWidth => 20
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din => wrData_im,
              wr_addr => wrAddr,
              wr_en => wrEnb,
              rd_addr => rd_4_Addr,
              dout => x_im
              );

  UdataMEM_re_0_4 : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    GENERIC MAP( AddrWidth => 7,
                 DataWidth => 20
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din => wrData_re,
              wr_addr => wrAddr,
              wr_en => wrEnb,
              rd_addr => rd_4_Addr,
              dout => x_re
              );

  USDFCOMMUTATOR_4 : ltehdlDownlinkSyncDemod_SDFCommutator4
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_3_1_vld => dout_3_1_vld,
              xf_re => std_logic_vector(xf_re),  -- ufix20
              xf_im => std_logic_vector(xf_im),  -- ufix20
              xf_vld => xf_vld,
              dinf_re => std_logic_vector(dinf_re),  -- ufix20
              dinf_im => std_logic_vector(dinf_im),  -- ufix20
              dinf_vld => dinf_vld,
              btf1_re => std_logic_vector(btf1_re),  -- ufix20
              btf1_im => std_logic_vector(btf1_im),  -- ufix20
              btf2_re => std_logic_vector(btf2_re),  -- ufix20
              btf2_im => std_logic_vector(btf2_im),  -- ufix20
              btfout_vld => btfout_vld,
              syncReset => syncReset,
              wrData_re => wrData_re,  -- ufix20
              wrData_im => wrData_im,  -- ufix20
              wrAddr => wrAddr,  -- ufix7
              wrEnb => wrEnb,
              dout_4_1_re => dout_4_1_re_tmp,  -- ufix20
              dout_4_1_im => dout_4_1_im_tmp,  -- ufix20
              dout_4_1_vld => dout_4_1_vld
              );

  dout_3_1_re_signed <= signed(dout_3_1_re);

  din_re <= resize(dout_3_1_re_signed, 20);

  dout_3_1_im_signed <= signed(dout_3_1_im);

  din_im <= resize(dout_3_1_im_signed, 20);

  btfin_vld <= dout_3_1_vld AND proc_4_enb;

  saveEnb <=  NOT btfin_vld;

  dinVld <= dout_3_1_vld AND saveEnb;

  intdelay_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          x_vld <= '0';
        ELSE 
          x_vld <= rd_4_Enb;
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_process;


  intdelay_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          x_vld_dly <= '0';
        ELSE 
          x_vld_dly <= x_vld;
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_1_process;


  x_im_signed <= signed(x_im);

  intdelay_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          x_im_dly <= to_signed(16#00000#, 20);
        ELSE 
          x_im_dly <= x_im_signed;
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_2_process;


  x_re_signed <= signed(x_re);

  intdelay_3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          x_re_dly <= to_signed(16#00000#, 20);
        ELSE 
          x_re_dly <= x_re_signed;
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_3_process;


  -- Radix22ButterflyG2
  Radix22ButterflyG2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          Radix22ButterflyG2_procEnb_dly <= '0';
          Radix22ButterflyG2_procEnb_dly1 <= '0';
          Radix22ButterflyG2_procEnb_dly2 <= '0';
          Radix22ButterflyG2_btf1_re_reg <= to_signed(16#000000#, 21);
          Radix22ButterflyG2_btf1_im_reg <= to_signed(16#000000#, 21);
          Radix22ButterflyG2_btf2_re_reg <= to_signed(16#000000#, 21);
          Radix22ButterflyG2_btf2_im_reg <= to_signed(16#000000#, 21);
          Radix22ButterflyG2_din_re_dly <= to_signed(16#00000#, 20);
          Radix22ButterflyG2_din_im_dly <= to_signed(16#00000#, 20);
          Radix22ButterflyG2_din_vld_dly <= '0';
          Radix22ButterflyG2_x_re_dly <= to_signed(16#00000#, 20);
          Radix22ButterflyG2_x_im_dly <= to_signed(16#00000#, 20);
          Radix22ButterflyG2_x_vld_dly <= '0';
          Radix22ButterflyG2_dinXTwdl_re_dly1 <= to_signed(16#00000#, 20);
          Radix22ButterflyG2_dinXTwdl_im_dly1 <= to_signed(16#00000#, 20);
          Radix22ButterflyG2_dinXTwdl_re_dly2 <= to_signed(16#00000#, 20);
          Radix22ButterflyG2_dinXTwdl_im_dly2 <= to_signed(16#00000#, 20);
          Radix22ButterflyG2_multiply_J_dly1 <= '0';
        ELSE 
          Radix22ButterflyG2_procEnb_dly <= Radix22ButterflyG2_procEnb_dly_next;
          Radix22ButterflyG2_procEnb_dly1 <= Radix22ButterflyG2_procEnb_dly1_next;
          Radix22ButterflyG2_procEnb_dly2 <= Radix22ButterflyG2_procEnb_dly2_next;
          Radix22ButterflyG2_btf1_re_reg <= Radix22ButterflyG2_btf1_re_reg_next;
          Radix22ButterflyG2_btf1_im_reg <= Radix22ButterflyG2_btf1_im_reg_next;
          Radix22ButterflyG2_btf2_re_reg <= Radix22ButterflyG2_btf2_re_reg_next;
          Radix22ButterflyG2_btf2_im_reg <= Radix22ButterflyG2_btf2_im_reg_next;
          Radix22ButterflyG2_din_re_dly <= Radix22ButterflyG2_din_re_dly_next;
          Radix22ButterflyG2_din_im_dly <= Radix22ButterflyG2_din_im_dly_next;
          Radix22ButterflyG2_din_vld_dly <= Radix22ButterflyG2_din_vld_dly_next;
          Radix22ButterflyG2_x_re_dly <= Radix22ButterflyG2_x_re_dly_next;
          Radix22ButterflyG2_x_im_dly <= Radix22ButterflyG2_x_im_dly_next;
          Radix22ButterflyG2_x_vld_dly <= Radix22ButterflyG2_x_vld_dly_next;
          Radix22ButterflyG2_dinXTwdl_re_dly1 <= Radix22ButterflyG2_dinXTwdl_re_dly1_next;
          Radix22ButterflyG2_dinXTwdl_im_dly1 <= Radix22ButterflyG2_dinXTwdl_im_dly1_next;
          Radix22ButterflyG2_dinXTwdl_re_dly2 <= Radix22ButterflyG2_dinXTwdl_re_dly2_next;
          Radix22ButterflyG2_dinXTwdl_im_dly2 <= Radix22ButterflyG2_dinXTwdl_im_dly2_next;
          Radix22ButterflyG2_multiply_J_dly1 <= Radix22ButterflyG2_multiply_J_dly1_next;
        END IF;
      END IF;
    END IF;
  END PROCESS Radix22ButterflyG2_process;

  Radix22ButterflyG2_output : PROCESS (Radix22ButterflyG2_btf1_im_reg, Radix22ButterflyG2_btf1_re_reg,
       Radix22ButterflyG2_btf2_im_reg, Radix22ButterflyG2_btf2_re_reg,
       Radix22ButterflyG2_dinXTwdl_im_dly1, Radix22ButterflyG2_dinXTwdl_im_dly2,
       Radix22ButterflyG2_dinXTwdl_re_dly1, Radix22ButterflyG2_dinXTwdl_re_dly2,
       Radix22ButterflyG2_din_im_dly, Radix22ButterflyG2_din_re_dly,
       Radix22ButterflyG2_din_vld_dly, Radix22ButterflyG2_multiply_J_dly1,
       Radix22ButterflyG2_procEnb_dly, Radix22ButterflyG2_procEnb_dly1,
       Radix22ButterflyG2_procEnb_dly2, Radix22ButterflyG2_x_im_dly,
       Radix22ButterflyG2_x_re_dly, Radix22ButterflyG2_x_vld_dly, btfin_vld,
       dinVld, din_im, din_re, multiply_4_J, x_im_dly, x_re_dly, x_vld_dly)
  BEGIN
    Radix22ButterflyG2_x_re_dly_next <= x_re_dly;
    Radix22ButterflyG2_x_im_dly_next <= x_im_dly;
    Radix22ButterflyG2_x_vld_dly_next <= x_vld_dly;
    Radix22ButterflyG2_din_re_dly_next <= din_re;
    Radix22ButterflyG2_din_im_dly_next <= din_im;
    Radix22ButterflyG2_din_vld_dly_next <= dinVld;
    Radix22ButterflyG2_procEnb_dly2_next <= Radix22ButterflyG2_procEnb_dly1;
    Radix22ButterflyG2_procEnb_dly1_next <= Radix22ButterflyG2_procEnb_dly;
    Radix22ButterflyG2_procEnb_dly_next <= btfin_vld;
    IF Radix22ButterflyG2_multiply_J_dly1 = '1' THEN 
      Radix22ButterflyG2_btf1_re_reg_next <= (resize(x_re_dly, 21)) + (resize(Radix22ButterflyG2_dinXTwdl_im_dly2, 21));
      Radix22ButterflyG2_btf2_re_reg_next <= (resize(x_re_dly, 21)) - (resize(Radix22ButterflyG2_dinXTwdl_im_dly2, 21));
      Radix22ButterflyG2_btf2_im_reg_next <= (resize(x_im_dly, 21)) + (resize(Radix22ButterflyG2_dinXTwdl_re_dly2, 21));
      Radix22ButterflyG2_btf1_im_reg_next <= (resize(x_im_dly, 21)) - (resize(Radix22ButterflyG2_dinXTwdl_re_dly2, 21));
    ELSE 
      Radix22ButterflyG2_btf1_re_reg_next <= (resize(x_re_dly, 21)) + (resize(Radix22ButterflyG2_dinXTwdl_re_dly2, 21));
      Radix22ButterflyG2_btf2_re_reg_next <= (resize(x_re_dly, 21)) - (resize(Radix22ButterflyG2_dinXTwdl_re_dly2, 21));
      Radix22ButterflyG2_btf1_im_reg_next <= (resize(x_im_dly, 21)) + (resize(Radix22ButterflyG2_dinXTwdl_im_dly2, 21));
      Radix22ButterflyG2_btf2_im_reg_next <= (resize(x_im_dly, 21)) - (resize(Radix22ButterflyG2_dinXTwdl_im_dly2, 21));
    END IF;
    Radix22ButterflyG2_dinXTwdl_re_dly2_next <= Radix22ButterflyG2_dinXTwdl_re_dly1;
    Radix22ButterflyG2_dinXTwdl_im_dly2_next <= Radix22ButterflyG2_dinXTwdl_im_dly1;
    Radix22ButterflyG2_dinXTwdl_re_dly1_next <= din_re;
    Radix22ButterflyG2_dinXTwdl_im_dly1_next <= din_im;
    Radix22ButterflyG2_multiply_J_dly1_next <= multiply_4_J;
    xf_re <= Radix22ButterflyG2_x_re_dly;
    xf_im <= Radix22ButterflyG2_x_im_dly;
    xf_vld <= Radix22ButterflyG2_x_vld_dly;
    dinf_re <= Radix22ButterflyG2_din_re_dly;
    dinf_im <= Radix22ButterflyG2_din_im_dly;
    dinf_vld <= Radix22ButterflyG2_din_vld_dly;
    btf1_re <= Radix22ButterflyG2_btf1_re_reg(19 DOWNTO 0);
    btf1_im <= Radix22ButterflyG2_btf1_im_reg(19 DOWNTO 0);
    btf2_re <= Radix22ButterflyG2_btf2_re_reg(19 DOWNTO 0);
    btf2_im <= Radix22ButterflyG2_btf2_im_reg(19 DOWNTO 0);
    btfout_vld <= Radix22ButterflyG2_procEnb_dly2;
  END PROCESS Radix22ButterflyG2_output;


  dout_4_1_re <= dout_4_1_re_tmp;

  dout_4_1_im <= dout_4_1_im_tmp;

  dinXTwdl_4_1_vld <= btfin_vld;

END rtl;

