-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_Timing_Offset_Mask_Generator1 IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        validIn                           :   IN    std_logic;
        timingOffset                      :   IN    std_logic_vector(18 DOWNTO 0);  -- ufix19
        timingOffsetValid                 :   IN    std_logic;
        start                             :   IN    std_logic;
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Timing_Offset_Mask_Generator1;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Timing_Offset_Mask_Generator1 IS

  -- Signals
  SIGNAL timingOffset_unsigned            : unsigned(18 DOWNTO 0);  -- ufix19
  SIGNAL reg_timingReference              : unsigned(18 DOWNTO 0);  -- ufix19
  SIGNAL reg_state                        : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL reg_validOut                     : std_logic;
  SIGNAL reg_timingReference_next         : unsigned(18 DOWNTO 0);  -- ufix19
  SIGNAL reg_state_next                   : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL reg_validOut_next                : std_logic;

BEGIN
  timingOffset_unsigned <= unsigned(timingOffset);

  Timing_Offset_Mask_Generator1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        reg_timingReference <= to_unsigned(16#00000#, 19);
        reg_state <= to_unsigned(16#0#, 2);
        reg_validOut <= '0';
      ELSIF enb_1_2_0 = '1' THEN
        reg_timingReference <= reg_timingReference_next;
        reg_state <= reg_state_next;
        reg_validOut <= reg_validOut_next;
      END IF;
    END IF;
  END PROCESS Timing_Offset_Mask_Generator1_process;

  Timing_Offset_Mask_Generator1_output : PROCESS (reg_state, reg_timingReference, reg_validOut, start, timingOffsetValid,
       timingOffset_unsigned, validIn)
  BEGIN
    -- Search state definitions
    -- Assign outputs
    -- Update states
    reg_timingReference_next <= reg_timingReference;
    reg_state_next <= reg_state;
    reg_validOut_next <= reg_validOut;
    -- Timing reference, runs continuously.
    -- Aligned with input samples.
    IF validIn = '1' THEN 
      IF reg_timingReference >= to_unsigned(16#4AFFF#, 19) THEN 
        reg_timingReference_next <= to_unsigned(16#00000#, 19);
      ELSE 
        reg_timingReference_next <= reg_timingReference + to_unsigned(16#00001#, 19);
      END IF;
    END IF;
    -- State machine
    IF start = '1' THEN 
      reg_state_next <= to_unsigned(16#1#, 2);
    ELSE 
      CASE reg_state IS
        WHEN "01" =>
          IF timingOffsetValid = '1' THEN 
            reg_state_next <= to_unsigned(16#2#, 2);
          END IF;
          reg_validOut_next <= '0';
        WHEN "10" =>
          IF timingOffset_unsigned = reg_timingReference THEN 
            reg_state_next <= to_unsigned(16#3#, 2);
            reg_validOut_next <= validIn;
          ELSE 
            reg_validOut_next <= '0';
          END IF;
        WHEN "11" =>
          reg_validOut_next <= validIn;
        WHEN OTHERS => 
          -- includes IDLE
          reg_validOut_next <= '0';
      END CASE;
    END IF;
    validOut <= reg_validOut;
  END PROCESS Timing_Offset_Mask_Generator1_output;


END rtl;

