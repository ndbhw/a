-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_2 IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        dout_1_1_re                       :   IN    std_logic_vector(16 DOWNTO 0);  -- ufix17
        dout_1_1_im                       :   IN    std_logic_vector(16 DOWNTO 0);  -- ufix17
        dout_1_1_vld                      :   IN    std_logic;
        rd_2_Addr                         :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        rd_2_Enb                          :   IN    std_logic;
        proc_2_enb                        :   IN    std_logic;
        multiply_2_J                      :   IN    std_logic;
        syncReset                         :   IN    std_logic;
        dout_2_1_re                       :   OUT   std_logic_vector(17 DOWNTO 0);  -- ufix18
        dout_2_1_im                       :   OUT   std_logic_vector(17 DOWNTO 0);  -- ufix18
        dout_2_1_vld                      :   OUT   std_logic;
        dinXTwdl_2_1_vld                  :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_2;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_2 IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    GENERIC( AddrWidth                    : integer;
             DataWidth                    : integer
             );
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          wr_din                          :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          wr_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          wr_en                           :   IN    std_logic;
          rd_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          dout                            :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0)  -- generic width
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_SDFCommutator2
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_1_1_vld                    :   IN    std_logic;
          xf_re                           :   IN    std_logic_vector(17 DOWNTO 0);  -- ufix18
          xf_im                           :   IN    std_logic_vector(17 DOWNTO 0);  -- ufix18
          xf_vld                          :   IN    std_logic;
          dinf_re                         :   IN    std_logic_vector(17 DOWNTO 0);  -- ufix18
          dinf_im                         :   IN    std_logic_vector(17 DOWNTO 0);  -- ufix18
          dinf_vld                        :   IN    std_logic;
          btf1_re                         :   IN    std_logic_vector(17 DOWNTO 0);  -- ufix18
          btf1_im                         :   IN    std_logic_vector(17 DOWNTO 0);  -- ufix18
          btf2_re                         :   IN    std_logic_vector(17 DOWNTO 0);  -- ufix18
          btf2_im                         :   IN    std_logic_vector(17 DOWNTO 0);  -- ufix18
          btfout_vld                      :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          wrData_re                       :   OUT   std_logic_vector(17 DOWNTO 0);  -- ufix18
          wrData_im                       :   OUT   std_logic_vector(17 DOWNTO 0);  -- ufix18
          wrAddr                          :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
          wrEnb                           :   OUT   std_logic;
          dout_2_1_re                     :   OUT   std_logic_vector(17 DOWNTO 0);  -- ufix18
          dout_2_1_im                     :   OUT   std_logic_vector(17 DOWNTO 0);  -- ufix18
          dout_2_1_vld                    :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_SDFCommutator2
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_SDFCommutator2(rtl);

  -- Signals
  SIGNAL dout_1_1_re_signed               : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL din_re                           : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL dout_1_1_im_signed               : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL din_im                           : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL btfin_vld                        : std_logic;
  SIGNAL saveEnb                          : std_logic;
  SIGNAL dinVld                           : std_logic;
  SIGNAL x_vld                            : std_logic := '0';
  SIGNAL x_vld_dly                        : std_logic := '0';
  SIGNAL btf2_im                          : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL btf2_re                          : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL btf1_im                          : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL btf1_re                          : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL dinf_im                          : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL dinf_re                          : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL xf_im                            : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL wrData_im                        : std_logic_vector(17 DOWNTO 0);  -- ufix18
  SIGNAL wrAddr                           : std_logic_vector(8 DOWNTO 0);  -- ufix9
  SIGNAL wrEnb                            : std_logic;
  SIGNAL x_im                             : std_logic_vector(17 DOWNTO 0);  -- ufix18
  SIGNAL x_im_signed                      : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL x_im_dly                         : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En15
  SIGNAL wrData_re                        : std_logic_vector(17 DOWNTO 0);  -- ufix18
  SIGNAL x_re                             : std_logic_vector(17 DOWNTO 0);  -- ufix18
  SIGNAL x_re_signed                      : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL x_re_dly                         : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En15
  SIGNAL Radix22ButterflyG2_procEnb_dly   : std_logic := '0';
  SIGNAL Radix22ButterflyG2_procEnb_dly1  : std_logic := '0';
  SIGNAL Radix22ButterflyG2_procEnb_dly2  : std_logic := '0';
  SIGNAL Radix22ButterflyG2_btf1_re_reg   : signed(18 DOWNTO 0) := to_signed(16#00000#, 19);  -- sfix19
  SIGNAL Radix22ButterflyG2_btf1_im_reg   : signed(18 DOWNTO 0) := to_signed(16#00000#, 19);  -- sfix19
  SIGNAL Radix22ButterflyG2_btf2_re_reg   : signed(18 DOWNTO 0) := to_signed(16#00000#, 19);  -- sfix19
  SIGNAL Radix22ButterflyG2_btf2_im_reg   : signed(18 DOWNTO 0) := to_signed(16#00000#, 19);  -- sfix19
  SIGNAL Radix22ButterflyG2_din_re_dly    : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18
  SIGNAL Radix22ButterflyG2_din_im_dly    : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18
  SIGNAL Radix22ButterflyG2_din_vld_dly   : std_logic := '0';
  SIGNAL Radix22ButterflyG2_x_re_dly      : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18
  SIGNAL Radix22ButterflyG2_x_im_dly      : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18
  SIGNAL Radix22ButterflyG2_x_vld_dly     : std_logic := '0';
  SIGNAL Radix22ButterflyG2_dinXTwdl_re_dly1 : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18
  SIGNAL Radix22ButterflyG2_dinXTwdl_im_dly1 : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18
  SIGNAL Radix22ButterflyG2_dinXTwdl_re_dly2 : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18
  SIGNAL Radix22ButterflyG2_dinXTwdl_im_dly2 : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18
  SIGNAL Radix22ButterflyG2_multiply_J_dly1 : std_logic := '0';
  SIGNAL Radix22ButterflyG2_procEnb_dly_next : std_logic;
  SIGNAL Radix22ButterflyG2_procEnb_dly1_next : std_logic;
  SIGNAL Radix22ButterflyG2_procEnb_dly2_next : std_logic;
  SIGNAL Radix22ButterflyG2_btf1_re_reg_next : signed(18 DOWNTO 0);  -- sfix19_En15
  SIGNAL Radix22ButterflyG2_btf1_im_reg_next : signed(18 DOWNTO 0);  -- sfix19_En15
  SIGNAL Radix22ButterflyG2_btf2_re_reg_next : signed(18 DOWNTO 0);  -- sfix19_En15
  SIGNAL Radix22ButterflyG2_btf2_im_reg_next : signed(18 DOWNTO 0);  -- sfix19_En15
  SIGNAL Radix22ButterflyG2_din_re_dly_next : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL Radix22ButterflyG2_din_im_dly_next : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL Radix22ButterflyG2_din_vld_dly_next : std_logic;
  SIGNAL Radix22ButterflyG2_x_re_dly_next : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL Radix22ButterflyG2_x_im_dly_next : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL Radix22ButterflyG2_x_vld_dly_next : std_logic;
  SIGNAL Radix22ButterflyG2_dinXTwdl_re_dly1_next : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL Radix22ButterflyG2_dinXTwdl_im_dly1_next : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL Radix22ButterflyG2_dinXTwdl_re_dly2_next : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL Radix22ButterflyG2_dinXTwdl_im_dly2_next : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL Radix22ButterflyG2_multiply_J_dly1_next : std_logic;
  SIGNAL xf_re                            : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL xf_vld                           : std_logic;
  SIGNAL dinf_vld                         : std_logic;
  SIGNAL btfout_vld                       : std_logic;
  SIGNAL dout_2_1_re_tmp                  : std_logic_vector(17 DOWNTO 0);  -- ufix18
  SIGNAL dout_2_1_im_tmp                  : std_logic_vector(17 DOWNTO 0);  -- ufix18

BEGIN
  UdataMEM_im_0_2 : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    GENERIC MAP( AddrWidth => 9,
                 DataWidth => 18
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din => wrData_im,
              wr_addr => wrAddr,
              wr_en => wrEnb,
              rd_addr => rd_2_Addr,
              dout => x_im
              );

  UdataMEM_re_0_2 : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    GENERIC MAP( AddrWidth => 9,
                 DataWidth => 18
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din => wrData_re,
              wr_addr => wrAddr,
              wr_en => wrEnb,
              rd_addr => rd_2_Addr,
              dout => x_re
              );

  USDFCOMMUTATOR_2 : ltehdlDownlinkSyncDemod_SDFCommutator2
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_1_1_vld => dout_1_1_vld,
              xf_re => std_logic_vector(xf_re),  -- ufix18
              xf_im => std_logic_vector(xf_im),  -- ufix18
              xf_vld => xf_vld,
              dinf_re => std_logic_vector(dinf_re),  -- ufix18
              dinf_im => std_logic_vector(dinf_im),  -- ufix18
              dinf_vld => dinf_vld,
              btf1_re => std_logic_vector(btf1_re),  -- ufix18
              btf1_im => std_logic_vector(btf1_im),  -- ufix18
              btf2_re => std_logic_vector(btf2_re),  -- ufix18
              btf2_im => std_logic_vector(btf2_im),  -- ufix18
              btfout_vld => btfout_vld,
              syncReset => syncReset,
              wrData_re => wrData_re,  -- ufix18
              wrData_im => wrData_im,  -- ufix18
              wrAddr => wrAddr,  -- ufix9
              wrEnb => wrEnb,
              dout_2_1_re => dout_2_1_re_tmp,  -- ufix18
              dout_2_1_im => dout_2_1_im_tmp,  -- ufix18
              dout_2_1_vld => dout_2_1_vld
              );

  dout_1_1_re_signed <= signed(dout_1_1_re);

  din_re <= resize(dout_1_1_re_signed, 18);

  dout_1_1_im_signed <= signed(dout_1_1_im);

  din_im <= resize(dout_1_1_im_signed, 18);

  btfin_vld <= dout_1_1_vld AND proc_2_enb;

  saveEnb <=  NOT btfin_vld;

  dinVld <= dout_1_1_vld AND saveEnb;

  intdelay_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          x_vld <= '0';
        ELSE 
          x_vld <= rd_2_Enb;
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_process;


  intdelay_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          x_vld_dly <= '0';
        ELSE 
          x_vld_dly <= x_vld;
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_1_process;


  x_im_signed <= signed(x_im);

  intdelay_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          x_im_dly <= to_signed(16#00000#, 18);
        ELSE 
          x_im_dly <= x_im_signed;
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_2_process;


  x_re_signed <= signed(x_re);

  intdelay_3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          x_re_dly <= to_signed(16#00000#, 18);
        ELSE 
          x_re_dly <= x_re_signed;
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_3_process;


  -- Radix22ButterflyG2
  Radix22ButterflyG2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          Radix22ButterflyG2_procEnb_dly <= '0';
          Radix22ButterflyG2_procEnb_dly1 <= '0';
          Radix22ButterflyG2_procEnb_dly2 <= '0';
          Radix22ButterflyG2_btf1_re_reg <= to_signed(16#00000#, 19);
          Radix22ButterflyG2_btf1_im_reg <= to_signed(16#00000#, 19);
          Radix22ButterflyG2_btf2_re_reg <= to_signed(16#00000#, 19);
          Radix22ButterflyG2_btf2_im_reg <= to_signed(16#00000#, 19);
          Radix22ButterflyG2_din_re_dly <= to_signed(16#00000#, 18);
          Radix22ButterflyG2_din_im_dly <= to_signed(16#00000#, 18);
          Radix22ButterflyG2_din_vld_dly <= '0';
          Radix22ButterflyG2_x_re_dly <= to_signed(16#00000#, 18);
          Radix22ButterflyG2_x_im_dly <= to_signed(16#00000#, 18);
          Radix22ButterflyG2_x_vld_dly <= '0';
          Radix22ButterflyG2_dinXTwdl_re_dly1 <= to_signed(16#00000#, 18);
          Radix22ButterflyG2_dinXTwdl_im_dly1 <= to_signed(16#00000#, 18);
          Radix22ButterflyG2_dinXTwdl_re_dly2 <= to_signed(16#00000#, 18);
          Radix22ButterflyG2_dinXTwdl_im_dly2 <= to_signed(16#00000#, 18);
          Radix22ButterflyG2_multiply_J_dly1 <= '0';
        ELSE 
          Radix22ButterflyG2_procEnb_dly <= Radix22ButterflyG2_procEnb_dly_next;
          Radix22ButterflyG2_procEnb_dly1 <= Radix22ButterflyG2_procEnb_dly1_next;
          Radix22ButterflyG2_procEnb_dly2 <= Radix22ButterflyG2_procEnb_dly2_next;
          Radix22ButterflyG2_btf1_re_reg <= Radix22ButterflyG2_btf1_re_reg_next;
          Radix22ButterflyG2_btf1_im_reg <= Radix22ButterflyG2_btf1_im_reg_next;
          Radix22ButterflyG2_btf2_re_reg <= Radix22ButterflyG2_btf2_re_reg_next;
          Radix22ButterflyG2_btf2_im_reg <= Radix22ButterflyG2_btf2_im_reg_next;
          Radix22ButterflyG2_din_re_dly <= Radix22ButterflyG2_din_re_dly_next;
          Radix22ButterflyG2_din_im_dly <= Radix22ButterflyG2_din_im_dly_next;
          Radix22ButterflyG2_din_vld_dly <= Radix22ButterflyG2_din_vld_dly_next;
          Radix22ButterflyG2_x_re_dly <= Radix22ButterflyG2_x_re_dly_next;
          Radix22ButterflyG2_x_im_dly <= Radix22ButterflyG2_x_im_dly_next;
          Radix22ButterflyG2_x_vld_dly <= Radix22ButterflyG2_x_vld_dly_next;
          Radix22ButterflyG2_dinXTwdl_re_dly1 <= Radix22ButterflyG2_dinXTwdl_re_dly1_next;
          Radix22ButterflyG2_dinXTwdl_im_dly1 <= Radix22ButterflyG2_dinXTwdl_im_dly1_next;
          Radix22ButterflyG2_dinXTwdl_re_dly2 <= Radix22ButterflyG2_dinXTwdl_re_dly2_next;
          Radix22ButterflyG2_dinXTwdl_im_dly2 <= Radix22ButterflyG2_dinXTwdl_im_dly2_next;
          Radix22ButterflyG2_multiply_J_dly1 <= Radix22ButterflyG2_multiply_J_dly1_next;
        END IF;
      END IF;
    END IF;
  END PROCESS Radix22ButterflyG2_process;

  Radix22ButterflyG2_output : PROCESS (Radix22ButterflyG2_btf1_im_reg, Radix22ButterflyG2_btf1_re_reg,
       Radix22ButterflyG2_btf2_im_reg, Radix22ButterflyG2_btf2_re_reg,
       Radix22ButterflyG2_dinXTwdl_im_dly1, Radix22ButterflyG2_dinXTwdl_im_dly2,
       Radix22ButterflyG2_dinXTwdl_re_dly1, Radix22ButterflyG2_dinXTwdl_re_dly2,
       Radix22ButterflyG2_din_im_dly, Radix22ButterflyG2_din_re_dly,
       Radix22ButterflyG2_din_vld_dly, Radix22ButterflyG2_multiply_J_dly1,
       Radix22ButterflyG2_procEnb_dly, Radix22ButterflyG2_procEnb_dly1,
       Radix22ButterflyG2_procEnb_dly2, Radix22ButterflyG2_x_im_dly,
       Radix22ButterflyG2_x_re_dly, Radix22ButterflyG2_x_vld_dly, btfin_vld,
       dinVld, din_im, din_re, multiply_2_J, x_im_dly, x_re_dly, x_vld_dly)
  BEGIN
    Radix22ButterflyG2_x_re_dly_next <= x_re_dly;
    Radix22ButterflyG2_x_im_dly_next <= x_im_dly;
    Radix22ButterflyG2_x_vld_dly_next <= x_vld_dly;
    Radix22ButterflyG2_din_re_dly_next <= din_re;
    Radix22ButterflyG2_din_im_dly_next <= din_im;
    Radix22ButterflyG2_din_vld_dly_next <= dinVld;
    Radix22ButterflyG2_procEnb_dly2_next <= Radix22ButterflyG2_procEnb_dly1;
    Radix22ButterflyG2_procEnb_dly1_next <= Radix22ButterflyG2_procEnb_dly;
    Radix22ButterflyG2_procEnb_dly_next <= btfin_vld;
    IF Radix22ButterflyG2_multiply_J_dly1 = '1' THEN 
      Radix22ButterflyG2_btf1_re_reg_next <= (resize(x_re_dly, 19)) + (resize(Radix22ButterflyG2_dinXTwdl_im_dly2, 19));
      Radix22ButterflyG2_btf2_re_reg_next <= (resize(x_re_dly, 19)) - (resize(Radix22ButterflyG2_dinXTwdl_im_dly2, 19));
      Radix22ButterflyG2_btf2_im_reg_next <= (resize(x_im_dly, 19)) + (resize(Radix22ButterflyG2_dinXTwdl_re_dly2, 19));
      Radix22ButterflyG2_btf1_im_reg_next <= (resize(x_im_dly, 19)) - (resize(Radix22ButterflyG2_dinXTwdl_re_dly2, 19));
    ELSE 
      Radix22ButterflyG2_btf1_re_reg_next <= (resize(x_re_dly, 19)) + (resize(Radix22ButterflyG2_dinXTwdl_re_dly2, 19));
      Radix22ButterflyG2_btf2_re_reg_next <= (resize(x_re_dly, 19)) - (resize(Radix22ButterflyG2_dinXTwdl_re_dly2, 19));
      Radix22ButterflyG2_btf1_im_reg_next <= (resize(x_im_dly, 19)) + (resize(Radix22ButterflyG2_dinXTwdl_im_dly2, 19));
      Radix22ButterflyG2_btf2_im_reg_next <= (resize(x_im_dly, 19)) - (resize(Radix22ButterflyG2_dinXTwdl_im_dly2, 19));
    END IF;
    Radix22ButterflyG2_dinXTwdl_re_dly2_next <= Radix22ButterflyG2_dinXTwdl_re_dly1;
    Radix22ButterflyG2_dinXTwdl_im_dly2_next <= Radix22ButterflyG2_dinXTwdl_im_dly1;
    Radix22ButterflyG2_dinXTwdl_re_dly1_next <= din_re;
    Radix22ButterflyG2_dinXTwdl_im_dly1_next <= din_im;
    Radix22ButterflyG2_multiply_J_dly1_next <= multiply_2_J;
    xf_re <= Radix22ButterflyG2_x_re_dly;
    xf_im <= Radix22ButterflyG2_x_im_dly;
    xf_vld <= Radix22ButterflyG2_x_vld_dly;
    dinf_re <= Radix22ButterflyG2_din_re_dly;
    dinf_im <= Radix22ButterflyG2_din_im_dly;
    dinf_vld <= Radix22ButterflyG2_din_vld_dly;
    btf1_re <= Radix22ButterflyG2_btf1_re_reg(17 DOWNTO 0);
    btf1_im <= Radix22ButterflyG2_btf1_im_reg(17 DOWNTO 0);
    btf2_re <= Radix22ButterflyG2_btf2_re_reg(17 DOWNTO 0);
    btf2_im <= Radix22ButterflyG2_btf2_im_reg(17 DOWNTO 0);
    btfout_vld <= Radix22ButterflyG2_procEnb_dly2;
  END PROCESS Radix22ButterflyG2_output;


  dout_2_1_re <= dout_2_1_re_tmp;

  dout_2_1_im <= dout_2_1_im_tmp;

  dinXTwdl_2_1_vld <= btfin_vld;

END rtl;

