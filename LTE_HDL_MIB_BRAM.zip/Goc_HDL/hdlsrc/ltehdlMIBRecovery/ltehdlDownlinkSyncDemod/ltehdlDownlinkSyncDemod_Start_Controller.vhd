-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_Start_Controller IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        inputValid                        :   IN    std_logic;
        startIn                           :   IN    std_logic;
        freqEstValid                      :   IN    std_logic;
        freqEstRegEn                      :   OUT   std_logic;
        searchStart                       :   OUT   std_logic;
        startTime                         :   OUT   std_logic_vector(14 DOWNTO 0)  -- ufix15
        );
END ltehdlDownlinkSyncDemod_Start_Controller;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Start_Controller IS

  -- Functions
  -- HDLCODER_TO_STDLOGIC 
  FUNCTION hdlcoder_to_stdlogic(arg: boolean) RETURN std_logic IS
  BEGIN
    IF arg THEN
      RETURN '1';
    ELSE
      RETURN '0';
    END IF;
  END FUNCTION;


  -- Signals
  SIGNAL startTime_tmp                    : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_inputTimingRef               : unsigned(18 DOWNTO 0);  -- ufix19
  SIGNAL reg_freqEstTimingRef             : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_startTime                    : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_state                        : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL reg_freqEstRegEn                 : std_logic;
  SIGNAL reg_searchStartCount             : unsigned(13 DOWNTO 0);  -- ufix14
  SIGNAL reg_searchStart                  : std_logic;
  SIGNAL reg_inputTimingRef_next          : unsigned(18 DOWNTO 0);  -- ufix19
  SIGNAL reg_freqEstTimingRef_next        : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_startTime_next               : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_state_next                   : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL reg_freqEstRegEn_next            : std_logic;
  SIGNAL reg_searchStartCount_next        : unsigned(13 DOWNTO 0);  -- ufix14
  SIGNAL reg_searchStart_next             : std_logic;

BEGIN
  Start_Controller_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        reg_inputTimingRef <= to_unsigned(16#00000#, 19);
        reg_freqEstTimingRef <= to_unsigned(16#0000#, 15);
        reg_startTime <= to_unsigned(16#0000#, 15);
        reg_state <= to_unsigned(16#0#, 2);
        reg_freqEstRegEn <= '0';
        reg_searchStartCount <= to_unsigned(16#0000#, 14);
        reg_searchStart <= '0';
      ELSIF enb = '1' THEN
        reg_inputTimingRef <= reg_inputTimingRef_next;
        reg_freqEstTimingRef <= reg_freqEstTimingRef_next;
        reg_startTime <= reg_startTime_next;
        reg_state <= reg_state_next;
        reg_freqEstRegEn <= reg_freqEstRegEn_next;
        reg_searchStartCount <= reg_searchStartCount_next;
        reg_searchStart <= reg_searchStart_next;
      END IF;
    END IF;
  END PROCESS Start_Controller_process;

  Start_Controller_output : PROCESS (freqEstValid, inputValid, reg_freqEstRegEn, reg_freqEstTimingRef,
       reg_inputTimingRef, reg_searchStart, reg_searchStartCount, reg_startTime,
       reg_state, startIn)
    VARIABLE next_freqEstRegEn : std_logic;
    VARIABLE startTime16x : unsigned(18 DOWNTO 0);
    VARIABLE yy : unsigned(18 DOWNTO 0);
  BEGIN
    yy := to_unsigned(16#00000#, 19);
    startTime16x := to_unsigned(16#00000#, 19);
    -- Responsibilities
    ----------------------------------------------------------------------------
    -- Constants
    ----------------------------------------------------------------------------
    -- State definitions
    -- Enable/disable frequency correction.
    -- Useful for test/debug.
    ----------------------------------------------------------------------------
    -- Initialize registers
    ----------------------------------------------------------------------------
    -- Assign outputs
    ----------------------------------------------------------------------------
    freqEstRegEn <= reg_freqEstRegEn;
    ----------------------------------------------------------------------------
    -- Update registers
    ----------------------------------------------------------------------------
    -- Initialize next reg values to current values.
    reg_inputTimingRef_next <= reg_inputTimingRef;
    reg_freqEstTimingRef_next <= reg_freqEstTimingRef;
    reg_startTime_next <= reg_startTime;
    reg_state_next <= reg_state;
    reg_searchStartCount_next <= reg_searchStartCount;
    reg_searchStart_next <= reg_searchStart;
    -- input timing reference (16x)
    IF inputValid = '1' THEN 
      IF reg_inputTimingRef >= to_unsigned(16#4AFFF#, 19) THEN 
        reg_inputTimingRef_next <= to_unsigned(16#00000#, 19);
      ELSE 
        reg_inputTimingRef_next <= reg_inputTimingRef + to_unsigned(16#00001#, 19);
      END IF;
    END IF;
    -- frequency estimate timing reference (1x)
    IF freqEstValid = '1' THEN 
      IF reg_freqEstTimingRef >= to_unsigned(16#4AFF#, 15) THEN 
        reg_freqEstTimingRef_next <= to_unsigned(16#0000#, 15);
      ELSE 
        reg_freqEstTimingRef_next <= reg_freqEstTimingRef + to_unsigned(16#0001#, 15);
      END IF;
    END IF;
    -- State machine
    IF startIn = '1' THEN 
      reg_state_next <= to_unsigned(16#1#, 2);
      -- startTime = ceil(inputTimingRefRef/16)
      -- Add 15 then divide by 16 by right shifting by 4 places.
      startTime16x := reg_inputTimingRef + to_unsigned(16#0000F#, 19);
      yy := SHIFT_RIGHT(startTime16x, 4);
      reg_startTime_next <= yy(14 DOWNTO 0);
    ELSIF freqEstValid = '1' THEN 
      CASE reg_state IS
        WHEN "01" =>
          IF reg_freqEstTimingRef = reg_startTime THEN 
            reg_state_next <= to_unsigned(16#2#, 2);
          END IF;
        WHEN "10" =>
          IF reg_freqEstTimingRef = reg_startTime THEN 
            reg_state_next <= to_unsigned(16#0#, 2);
          END IF;
        WHEN OTHERS => 
          -- includes IDLE
          reg_state_next <= to_unsigned(16#0#, 2);
      END CASE;
    END IF;
    -- Generate freqEstRegEn
    next_freqEstRegEn := (freqEstValid AND hdlcoder_to_stdlogic(reg_state = to_unsigned(16#2#, 2))) AND hdlcoder_to_stdlogic(reg_freqEstTimingRef = reg_startTime);
    -- Search start controller    
    IF startIn = '1' THEN 
      reg_searchStart_next <= '1';
      reg_searchStartCount_next <= to_unsigned(16#257F#, 14);
    ELSIF freqEstValid = '1' THEN 
      IF reg_searchStartCount /= to_unsigned(16#0000#, 14) THEN 
        reg_searchStartCount_next <= reg_searchStartCount - to_unsigned(16#0001#, 14);
      ELSE 
        reg_searchStart_next <= '0';
      END IF;
    END IF;
    -- Write new values to registers.
    reg_freqEstRegEn_next <= next_freqEstRegEn;
    searchStart <= reg_searchStart;
    startTime_tmp <= reg_startTime;
  END PROCESS Start_Controller_output;


  startTime <= std_logic_vector(startTime_tmp);

END rtl;

