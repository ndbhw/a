-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_Transient_Removal IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        validIn                           :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataOut_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Transient_Removal;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Transient_Removal IS

  -- Signals
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataOut_re_tmp                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataOut_im_tmp                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL count                            : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL dataOutReg_re                    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataOutReg_im                    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL validOutReg                      : std_logic;
  SIGNAL count_next                       : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL dataOutReg_next_re               : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataOutReg_next_im               : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL validOutReg_next                 : std_logic;

BEGIN
  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Transient_Removal_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        count <= to_unsigned(16#0#, 3);
        dataOutReg_re <= to_signed(16#0000#, 16);
        dataOutReg_im <= to_signed(16#0000#, 16);
        validOutReg <= '0';
      ELSIF enb = '1' THEN
        count <= count_next;
        dataOutReg_re <= dataOutReg_next_re;
        dataOutReg_im <= dataOutReg_next_im;
        validOutReg <= validOutReg_next;
      END IF;
    END IF;
  END PROCESS Transient_Removal_process;

  Transient_Removal_output : PROCESS (count, dataIn_im_signed, dataIn_re_signed, dataOutReg_im, dataOutReg_re,
       validIn, validOutReg)
  BEGIN
    count_next <= count;
    dataOutReg_next_re <= dataOutReg_re;
    dataOutReg_next_im <= dataOutReg_im;
    IF validIn = '1' AND (count = to_unsigned(16#7#, 3)) THEN 
      dataOutReg_next_re <= dataIn_re_signed;
      dataOutReg_next_im <= dataIn_im_signed;
      validOutReg_next <= '1';
    ELSE 
      validOutReg_next <= '0';
    END IF;
    IF validIn = '1' AND (count /= to_unsigned(16#7#, 3)) THEN 
      count_next <= count + to_unsigned(16#1#, 3);
    END IF;
    dataOut_re_tmp <= dataOutReg_re;
    dataOut_im_tmp <= dataOutReg_im;
    validOut <= validOutReg;
  END PROCESS Transient_Removal_output;


  dataOut_re <= std_logic_vector(dataOut_re_tmp);

  dataOut_im <= std_logic_vector(dataOut_im_tmp);

END rtl;

