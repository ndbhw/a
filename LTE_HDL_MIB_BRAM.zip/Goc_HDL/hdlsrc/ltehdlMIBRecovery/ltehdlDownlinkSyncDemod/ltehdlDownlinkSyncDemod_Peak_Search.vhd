-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_Peak_Search IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        corr                              :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30
        PSSIdxIn                          :   IN    std_logic_vector(1 DOWNTO 0);  -- ufix2
        thresholdIn                       :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30
        thresholdExceeded                 :   IN    std_logic;
        validIn                           :   IN    std_logic;
        start                             :   IN    std_logic;
        startTime                         :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
        timingOffset                      :   OUT   std_logic_vector(14 DOWNTO 0);  -- ufix15
        NCellID2                          :   OUT   std_logic_vector(1 DOWNTO 0);  -- ufix2
        done                              :   OUT   std_logic;
        success                           :   OUT   std_logic;
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Peak_Search;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Peak_Search IS

  -- Functions
  -- HDLCODER_TO_STDLOGIC 
  FUNCTION hdlcoder_to_stdlogic(arg: boolean) RETURN std_logic IS
  BEGIN
    IF arg THEN
      RETURN '1';
    ELSE
      RETURN '0';
    END IF;
  END FUNCTION;


  -- Signals
  SIGNAL corr_unsigned                    : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL PSSIdxIn_unsigned                : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL thresholdIn_unsigned             : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL startTime_unsigned               : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL timingOffset_tmp                 : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL timingOffsetLong                 : unsigned(31 DOWNTO 0);  -- uint32
  SIGNAL NCellID2_tmp                     : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL maxCorr                          : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL thresholdOut                     : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL attempt                          : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL reg_startTime                    : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_timingReference              : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_timingReferenceLong          : unsigned(31 DOWNTO 0);  -- ufix32
  SIGNAL reg_sampleCount                  : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_attemptCount                 : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL reg_state                        : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL reg_maxCorr                      : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL reg_timingOffset                 : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_timingOffsetLong             : unsigned(31 DOWNTO 0);  -- ufix32
  SIGNAL reg_PSSIdx                       : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL reg_threshold                    : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL reg_attempt                      : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL reg_validOut                     : std_logic;
  SIGNAL reg_done                         : std_logic;
  SIGNAL reg_success                      : std_logic;
  SIGNAL reg_startTime_next               : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_timingReference_next         : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_timingReferenceLong_next     : unsigned(31 DOWNTO 0);  -- ufix32
  SIGNAL reg_sampleCount_next             : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_attemptCount_next            : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL reg_state_next                   : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL reg_maxCorr_next                 : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL reg_timingOffset_next            : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_timingOffsetLong_next        : unsigned(31 DOWNTO 0);  -- ufix32
  SIGNAL reg_PSSIdx_next                  : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL reg_threshold_next               : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL reg_attempt_next                 : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL reg_validOut_next                : std_logic;
  SIGNAL reg_done_next                    : std_logic;
  SIGNAL reg_success_next                 : std_logic;

BEGIN
  corr_unsigned <= unsigned(corr);

  PSSIdxIn_unsigned <= unsigned(PSSIdxIn);

  thresholdIn_unsigned <= unsigned(thresholdIn);

  startTime_unsigned <= unsigned(startTime);

  Peak_Search_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        reg_startTime <= to_unsigned(16#0000#, 15);
        reg_timingReference <= to_unsigned(16#0000#, 15);
        reg_timingReferenceLong <= to_unsigned(0, 32);
        reg_sampleCount <= to_unsigned(16#0000#, 15);
        reg_attemptCount <= to_unsigned(16#0#, 3);
        reg_state <= to_unsigned(16#0#, 2);
        reg_maxCorr <= to_unsigned(16#00000000#, 30);
        reg_timingOffset <= to_unsigned(16#0000#, 15);
        reg_timingOffsetLong <= to_unsigned(0, 32);
        reg_PSSIdx <= to_unsigned(16#0#, 2);
        reg_threshold <= to_unsigned(16#00000000#, 30);
        reg_attempt <= to_unsigned(16#0#, 3);
        reg_validOut <= '0';
        reg_done <= '0';
        reg_success <= '0';
      ELSIF enb = '1' THEN
        reg_startTime <= reg_startTime_next;
        reg_timingReference <= reg_timingReference_next;
        reg_timingReferenceLong <= reg_timingReferenceLong_next;
        reg_sampleCount <= reg_sampleCount_next;
        reg_attemptCount <= reg_attemptCount_next;
        reg_state <= reg_state_next;
        reg_maxCorr <= reg_maxCorr_next;
        reg_timingOffset <= reg_timingOffset_next;
        reg_timingOffsetLong <= reg_timingOffsetLong_next;
        reg_PSSIdx <= reg_PSSIdx_next;
        reg_threshold <= reg_threshold_next;
        reg_attempt <= reg_attempt_next;
        reg_validOut <= reg_validOut_next;
        reg_done <= reg_done_next;
        reg_success <= reg_success_next;
      END IF;
    END IF;
  END PROCESS Peak_Search_process;

  Peak_Search_output : PROCESS (PSSIdxIn_unsigned, corr_unsigned, reg_PSSIdx, reg_attempt, reg_attemptCount,
       reg_done, reg_maxCorr, reg_sampleCount, reg_startTime, reg_state,
       reg_success, reg_threshold, reg_timingOffset, reg_timingOffsetLong,
       reg_timingReference, reg_timingReferenceLong, reg_validOut, start,
       startTime_unsigned, thresholdExceeded, thresholdIn_unsigned, validIn)
    VARIABLE next_state : unsigned(1 DOWNTO 0);
    VARIABLE next_done : std_logic;
    VARIABLE next_success : std_logic;
    VARIABLE almostStartTime : unsigned(14 DOWNTO 0);
  BEGIN
    almostStartTime := to_unsigned(16#0000#, 15);
    -- start takes priority over validIn. When start=true,
    -- the search starts the next time validIn=true and not
    -- on the same cycle.
    -- Search state definitions
    -- Waiting for start time 
    -- Searching for PSS
    -- Assign outputs
    -- Change number of attempts for Coarse Mode
    --     if coarseMode
    --         maxAttempts = cast(1,'like',reg.attempt);
    --     else
    --         maxAttempts = cast(4,'like',reg.attempt);
    --     end
    -- Initialize next set of states
    reg_startTime_next <= reg_startTime;
    reg_timingReference_next <= reg_timingReference;
    reg_timingReferenceLong_next <= reg_timingReferenceLong;
    reg_sampleCount_next <= reg_sampleCount;
    reg_attemptCount_next <= reg_attemptCount;
    next_state := reg_state;
    reg_maxCorr_next <= reg_maxCorr;
    reg_timingOffset_next <= reg_timingOffset;
    reg_timingOffsetLong_next <= reg_timingOffsetLong;
    reg_PSSIdx_next <= reg_PSSIdx;
    reg_threshold_next <= reg_threshold;
    reg_attempt_next <= reg_attempt;
    next_success := reg_success;
    -- Start time register
    IF start = '1' THEN 
      reg_startTime_next <= startTime_unsigned;
    END IF;
    -- Timing reference, runs continuously.
    IF validIn = '1' THEN 
      IF reg_timingReference >= to_unsigned(16#4AFF#, 15) THEN 
        reg_timingReference_next <= to_unsigned(16#0000#, 15);
      ELSE 
        reg_timingReference_next <= reg_timingReference + to_unsigned(16#0001#, 15);
      END IF;
      reg_timingReferenceLong_next <= reg_timingReferenceLong + to_unsigned(1, 32);
    END IF;
    -- Attempt counter.
    IF start = '1' THEN 
      reg_sampleCount_next <= to_unsigned(16#0000#, 15);
      reg_attemptCount_next <= to_unsigned(16#1#, 3);
    ELSIF reg_state = to_unsigned(16#2#, 2) THEN 
      IF validIn = '1' AND (reg_attemptCount /= to_unsigned(16#0#, 3)) THEN 
        IF reg_sampleCount = to_unsigned(16#4AFF#, 15) THEN 
          reg_sampleCount_next <= to_unsigned(16#0000#, 15);
          reg_attemptCount_next <= reg_attemptCount + to_unsigned(16#1#, 3);
        ELSE 
          reg_sampleCount_next <= reg_sampleCount + to_unsigned(16#0001#, 15);
        END IF;
      END IF;
    ELSE 
      reg_sampleCount_next <= to_unsigned(16#0000#, 15);
    END IF;
    -- State machine
    IF start = '1' THEN 
      next_state := to_unsigned(16#1#, 2);
      next_success := '0';
      reg_maxCorr_next <= to_unsigned(16#00000000#, 30);
      reg_timingOffset_next <= to_unsigned(16#0000#, 15);
      reg_timingOffsetLong_next <= to_unsigned(0, 32);
      reg_PSSIdx_next <= to_unsigned(16#0#, 2);
      reg_threshold_next <= to_unsigned(16#00000000#, 30);
      reg_attempt_next <= to_unsigned(16#0#, 3);
    ELSIF validIn = '1' THEN 
      CASE reg_state IS
        WHEN "01" =>
          IF reg_startTime = to_unsigned(16#0000#, 15) THEN 
            almostStartTime := to_unsigned(16#4AFF#, 15);
          ELSE 
            almostStartTime := reg_startTime - to_unsigned(16#0001#, 15);
          END IF;
          -- Wait for start time, then start searching.
          IF reg_timingReference = almostStartTime THEN 
            next_state := to_unsigned(16#2#, 2);
          END IF;
        WHEN "10" =>
          -- If we have a new max for the current attempt, record it's details.
          IF (corr_unsigned > reg_maxCorr) AND thresholdExceeded = '1' THEN 
            next_success := '1';
            reg_maxCorr_next <= corr_unsigned;
            reg_timingOffset_next <= reg_timingReference;
            reg_timingOffsetLong_next <= reg_timingReferenceLong;
            reg_PSSIdx_next <= PSSIdxIn_unsigned;
            reg_threshold_next <= thresholdIn_unsigned;
          END IF;
          -- Decide what to do at the end of each attempt.
          IF reg_sampleCount = to_unsigned(16#4AFF#, 15) THEN 
            IF next_success = '1' THEN 
              next_state := to_unsigned(16#3#, 2);
            ELSIF reg_attemptCount = to_unsigned(16#2#, 3) THEN 
              next_state := to_unsigned(16#3#, 2);
            END IF;
          END IF;
          reg_attempt_next <= reg_attemptCount;
        WHEN "11" =>
          next_state := to_unsigned(16#3#, 2);
        WHEN OTHERS => 
          -- includes IDLE
          next_state := to_unsigned(16#0#, 2);
          next_success := '0';
          reg_maxCorr_next <= to_unsigned(16#00000000#, 30);
          reg_timingOffset_next <= to_unsigned(16#0000#, 15);
          reg_timingOffsetLong_next <= to_unsigned(0, 32);
          reg_PSSIdx_next <= to_unsigned(16#0#, 2);
          reg_threshold_next <= to_unsigned(16#00000000#, 30);
          reg_attempt_next <= to_unsigned(16#0#, 3);
      END CASE;
    END IF;
    next_done := hdlcoder_to_stdlogic((reg_state = to_unsigned(16#2#, 2)) AND (next_state = to_unsigned(16#3#, 2)));
    reg_state_next <= next_state;
    reg_validOut_next <= validIn;
    reg_done_next <= next_done;
    reg_success_next <= next_success;
    timingOffset_tmp <= reg_timingOffset;
    timingOffsetLong <= reg_timingOffsetLong;
    NCellID2_tmp <= reg_PSSIdx;
    maxCorr <= reg_maxCorr;
    thresholdOut <= reg_threshold;
    attempt <= reg_attempt;
    done <= reg_done;
    success <= reg_success;
    validOut <= reg_validOut;
  END PROCESS Peak_Search_output;


  timingOffset <= std_logic_vector(timingOffset_tmp);

  NCellID2 <= std_logic_vector(NCellID2_tmp);

END rtl;

