-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_4 IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        dout_3_1_vld                      :   IN    std_logic;
        dinXTwdl_4_1_vld                  :   IN    std_logic;
        syncReset                         :   IN    std_logic;
        rd_4_Addr                         :   OUT   std_logic_vector(6 DOWNTO 0);  -- ufix7
        rd_4_Enb                          :   OUT   std_logic;
        proc_4_enb                        :   OUT   std_logic;
        multiply_4_J                      :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_4;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_4 IS

  -- Signals
  SIGNAL SDFController_wrCount            : unsigned(6 DOWNTO 0) := to_unsigned(16#00#, 7);  -- ufix7
  SIGNAL SDFController_wrState            : unsigned(1 DOWNTO 0) := to_unsigned(16#0#, 2);  -- ufix2
  SIGNAL SDFController_rdState            : unsigned(1 DOWNTO 0) := to_unsigned(16#0#, 2);  -- ufix2
  SIGNAL SDFController_rdAddr_reg         : unsigned(6 DOWNTO 0) := to_unsigned(16#00#, 7);  -- ufix7
  SIGNAL SDFController_procEnb_reg        : std_logic := '0';
  SIGNAL SDFController_multjState         : unsigned(1 DOWNTO 0) := to_unsigned(16#0#, 2);  -- ufix2
  SIGNAL SDFController_multiply_J_reg     : std_logic := '0';
  SIGNAL SDFController_wrCount_next       : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL SDFController_wrState_next       : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL SDFController_rdState_next       : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL SDFController_rdAddr_reg_next    : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL SDFController_procEnb_reg_next   : std_logic;
  SIGNAL SDFController_multjState_next    : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL SDFController_multiply_J_reg_next : std_logic;
  SIGNAL rd_4_Addr_tmp                    : unsigned(6 DOWNTO 0);  -- ufix7

BEGIN
  -- SDFController
  SDFController_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          SDFController_wrCount <= to_unsigned(16#00#, 7);
          SDFController_rdAddr_reg <= to_unsigned(16#00#, 7);
          SDFController_wrState <= to_unsigned(16#0#, 2);
          SDFController_rdState <= to_unsigned(16#0#, 2);
          SDFController_multjState <= to_unsigned(16#0#, 2);
          SDFController_procEnb_reg <= '0';
          SDFController_multiply_J_reg <= '0';
        ELSE 
          SDFController_wrCount <= SDFController_wrCount_next;
          SDFController_wrState <= SDFController_wrState_next;
          SDFController_rdState <= SDFController_rdState_next;
          SDFController_rdAddr_reg <= SDFController_rdAddr_reg_next;
          SDFController_procEnb_reg <= SDFController_procEnb_reg_next;
          SDFController_multjState <= SDFController_multjState_next;
          SDFController_multiply_J_reg <= SDFController_multiply_J_reg_next;
        END IF;
      END IF;
    END IF;
  END PROCESS SDFController_process;

  SDFController_output : PROCESS (SDFController_multiply_J_reg, SDFController_multjState,
       SDFController_procEnb_reg, SDFController_rdAddr_reg,
       SDFController_rdState, SDFController_wrCount, SDFController_wrState,
       dinXTwdl_4_1_vld, dout_3_1_vld)
  BEGIN
    SDFController_wrCount_next <= SDFController_wrCount;
    SDFController_rdState_next <= SDFController_rdState;
    SDFController_rdAddr_reg_next <= SDFController_rdAddr_reg;
    SDFController_procEnb_reg_next <= SDFController_procEnb_reg;
    SDFController_multjState_next <= SDFController_multjState;
    CASE SDFController_multjState IS
      WHEN "00" =>
        SDFController_multjState_next <= to_unsigned(16#0#, 2);
        SDFController_multiply_J_reg_next <= '0';
        IF SDFController_rdState = to_unsigned(16#1#, 2) THEN 
          SDFController_multjState_next <= to_unsigned(16#1#, 2);
        END IF;
      WHEN "01" =>
        SDFController_multiply_J_reg_next <= '0';
        IF SDFController_rdState = to_unsigned(16#2#, 2) THEN 
          SDFController_multjState_next <= to_unsigned(16#2#, 2);
        END IF;
      WHEN "10" =>
        SDFController_multiply_J_reg_next <= '0';
        IF SDFController_rdState = to_unsigned(16#1#, 2) THEN 
          SDFController_multjState_next <= to_unsigned(16#3#, 2);
          SDFController_multiply_J_reg_next <= '1';
        END IF;
      WHEN "11" =>
        IF SDFController_rdState = to_unsigned(16#1#, 2) THEN 
          SDFController_multjState_next <= to_unsigned(16#3#, 2);
          SDFController_multiply_J_reg_next <= '1';
        ELSE 
          SDFController_multiply_J_reg_next <= '0';
          SDFController_multjState_next <= to_unsigned(16#0#, 2);
        END IF;
      WHEN OTHERS => 
        SDFController_multjState_next <= to_unsigned(16#0#, 2);
        SDFController_multiply_J_reg_next <= '0';
    END CASE;
    CASE SDFController_rdState IS
      WHEN "00" =>
        SDFController_rdState_next <= to_unsigned(16#0#, 2);
        SDFController_rdAddr_reg_next <= to_unsigned(16#00#, 7);
        rd_4_Enb <= '0';
        IF dout_3_1_vld = '1' AND (SDFController_wrCount = to_unsigned(16#7F#, 7)) THEN 
          SDFController_rdState_next <= to_unsigned(16#1#, 2);
        END IF;
      WHEN "01" =>
        SDFController_rdState_next <= to_unsigned(16#1#, 2);
        rd_4_Enb <= dinXTwdl_4_1_vld;
        IF dinXTwdl_4_1_vld = '1' THEN 
          IF SDFController_rdAddr_reg = to_unsigned(16#7F#, 7) THEN 
            SDFController_rdState_next <= to_unsigned(16#2#, 2);
          END IF;
          SDFController_rdAddr_reg_next <= SDFController_rdAddr_reg + to_unsigned(16#01#, 7);
        END IF;
      WHEN "10" =>
        rd_4_Enb <= '1';
        IF SDFController_rdAddr_reg = to_unsigned(16#7F#, 7) THEN 
          IF dout_3_1_vld = '1' AND (SDFController_wrCount = to_unsigned(16#7F#, 7)) THEN 
            SDFController_rdState_next <= to_unsigned(16#1#, 2);
          ELSE 
            SDFController_rdState_next <= to_unsigned(16#0#, 2);
          END IF;
        END IF;
        SDFController_rdAddr_reg_next <= SDFController_rdAddr_reg + to_unsigned(16#01#, 7);
      WHEN OTHERS => 
        SDFController_rdState_next <= to_unsigned(16#0#, 2);
        SDFController_rdAddr_reg_next <= to_unsigned(16#00#, 7);
        rd_4_Enb <= '0';
    END CASE;
    CASE SDFController_wrState IS
      WHEN "00" =>
        SDFController_wrState_next <= to_unsigned(16#0#, 2);
        SDFController_wrCount_next <= to_unsigned(16#00#, 7);
        SDFController_procEnb_reg_next <= '0';
        IF dout_3_1_vld = '1' THEN 
          SDFController_wrState_next <= to_unsigned(16#1#, 2);
          SDFController_wrCount_next <= to_unsigned(16#01#, 7);
        END IF;
      WHEN "01" =>
        SDFController_wrState_next <= to_unsigned(16#1#, 2);
        SDFController_procEnb_reg_next <= '0';
        IF dout_3_1_vld = '1' THEN 
          IF SDFController_wrCount = to_unsigned(16#7F#, 7) THEN 
            SDFController_wrState_next <= to_unsigned(16#2#, 2);
            SDFController_procEnb_reg_next <= '1';
          ELSE 
            SDFController_wrState_next <= to_unsigned(16#1#, 2);
          END IF;
          SDFController_wrCount_next <= SDFController_wrCount + to_unsigned(16#01#, 7);
        END IF;
      WHEN "10" =>
        SDFController_wrState_next <= to_unsigned(16#2#, 2);
        IF dout_3_1_vld = '1' THEN 
          IF SDFController_wrCount = to_unsigned(16#7F#, 7) THEN 
            SDFController_wrState_next <= to_unsigned(16#1#, 2);
            SDFController_procEnb_reg_next <= '0';
          ELSE 
            SDFController_wrState_next <= to_unsigned(16#2#, 2);
            SDFController_procEnb_reg_next <= '1';
          END IF;
          SDFController_wrCount_next <= SDFController_wrCount + to_unsigned(16#01#, 7);
        END IF;
      WHEN OTHERS => 
        SDFController_wrState_next <= to_unsigned(16#0#, 2);
        SDFController_wrCount_next <= to_unsigned(16#7F#, 7);
        SDFController_procEnb_reg_next <= '0';
    END CASE;
    rd_4_Addr_tmp <= SDFController_rdAddr_reg;
    proc_4_enb <= SDFController_procEnb_reg;
    multiply_4_J <= SDFController_multiply_J_reg;
  END PROCESS SDFController_output;


  rd_4_Addr <= std_logic_vector(rd_4_Addr_tmp);

END rtl;

