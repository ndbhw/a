-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_Quadrant_Correction IS
  PORT( zin                               :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
        QA_Control                        :   IN    std_logic_vector(4 DOWNTO 0);  -- ufix5
        zout                              :   OUT   std_logic_vector(26 DOWNTO 0)  -- ufix27
        );
END ltehdlDownlinkSyncDemod_Quadrant_Correction;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Quadrant_Correction IS

  -- Signals
  SIGNAL QA_Control_unsigned              : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL yZeroXNegative                   : std_logic;  -- ufix1
  SIGNAL xyNegative                       : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL AbsRel                           : std_logic;  -- ufix1
  SIGNAL zin_signed                       : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL pivdivtwosubout                  : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL mux1out                          : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL Negation_cast                    : signed(27 DOWNTO 0);  -- sfix28_En26
  SIGNAL Negation_cast_1                  : signed(28 DOWNTO 0);  -- sfix29_En26
  SIGNAL mux1out_negate                   : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL pi_subtraction                   : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL negpi_addition                   : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL yZeroXPositive                   : std_logic;  -- ufix1
  SIGNAL mux2out                          : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL mux5out                          : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL mux6out                          : signed(26 DOWNTO 0);  -- sfix27_En26

BEGIN
  QA_Control_unsigned <= unsigned(QA_Control);

  yZeroXNegative <= QA_Control_unsigned(3);

  xyNegative <= QA_Control_unsigned(1 DOWNTO 0);

  AbsRel <= QA_Control_unsigned(2);

  zin_signed <= signed(zin);

  pivdivtwosubout <= to_signed(16#2000000#, 27) - zin_signed;

  
  mux1out <= pivdivtwosubout WHEN AbsRel = '0' ELSE
      zin_signed;

  Negation_cast <=  - (resize(mux1out, 28));
  Negation_cast_1 <= resize(Negation_cast, 29);
  mux1out_negate <= Negation_cast_1(26 DOWNTO 0);

  pi_subtraction <= to_signed(16#3FFFFFF#, 27) - mux1out;

  negpi_addition <= mux1out + to_signed(-16#4000000#, 27);

  yZeroXPositive <= QA_Control_unsigned(4);

  
  mux2out <= mux1out WHEN xyNegative = to_unsigned(16#0#, 2) ELSE
      mux1out_negate WHEN xyNegative = to_unsigned(16#1#, 2) ELSE
      pi_subtraction WHEN xyNegative = to_unsigned(16#2#, 2) ELSE
      negpi_addition;

  
  mux5out <= mux2out WHEN yZeroXNegative = '0' ELSE
      to_signed(16#3FFFFFF#, 27);

  
  mux6out <= mux5out WHEN yZeroXPositive = '0' ELSE
      to_signed(16#0000000#, 27);

  zout <= std_logic_vector(mux6out);

END rtl;

