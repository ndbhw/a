-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_PSSXCorr2 IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En12
        dataOut_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En12
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_PSSXCorr2;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_PSSXCorr2 IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_C_D_block4
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn                          :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          validIn                         :   IN    std_logic;
          dataOut                         :   OUT   std_logic_vector(28 DOWNTO 0)  -- ufix29
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_C_block1
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn                          :   IN    std_logic_vector(16 DOWNTO 0);  -- ufix17
          validIn                         :   IN    std_logic;
          dataOut                         :   OUT   std_logic_vector(28 DOWNTO 0)  -- ufix29
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_C_D_block3
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn                          :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          validIn                         :   IN    std_logic;
          dataOut                         :   OUT   std_logic_vector(28 DOWNTO 0);  -- ufix29
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_C_D_block4
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_C_D_block4(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_C_block1
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_C_block1(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_C_D_block3
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_C_D_block3(rtl);

  -- Signals
  SIGNAL C_D_out1                         : std_logic_vector(28 DOWNTO 0);  -- ufix29
  SIGNAL C_D_out1_signed                  : signed(28 DOWNTO 0);  -- sfix29_En24
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Sum2_out1                        : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL C_out1                           : std_logic_vector(28 DOWNTO 0);  -- ufix29
  SIGNAL C_out1_signed                    : signed(28 DOWNTO 0);  -- sfix29_En24
  SIGNAL Sum3_out1                        : signed(29 DOWNTO 0);  -- sfix30_En24
  SIGNAL C_D_out1_1                       : std_logic_vector(28 DOWNTO 0);  -- ufix29
  SIGNAL C_D_out2                         : std_logic;
  SIGNAL C_D_out1_signed_1                : signed(28 DOWNTO 0);  -- sfix29_En24
  SIGNAL Sum4_out1                        : signed(29 DOWNTO 0);  -- sfix30_En24
  SIGNAL Delay1_out1_re                   : signed(29 DOWNTO 0) := to_signed(16#00000000#, 30);  -- sfix30_En24
  SIGNAL Delay1_out1_im                   : signed(29 DOWNTO 0) := to_signed(16#00000000#, 30);  -- sfix30_En24
  SIGNAL Data_Type_Conversion_out1_re     : signed(15 DOWNTO 0);  -- sfix16_En12
  SIGNAL Data_Type_Conversion_out1_im     : signed(15 DOWNTO 0);  -- sfix16_En12
  SIGNAL Delay2_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En12
  SIGNAL Delay2_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En12
  SIGNAL Delay3_out1                      : std_logic := '0';
  SIGNAL Delay4_out1                      : std_logic := '0';

BEGIN
  -- A
  -- B
  -- explicitly model filter running at 61.44MHz (32 x 1.92MHz)
  -- to enable resource sharing

  UC_D_3 : ltehdlDownlinkSyncDemod_C_D_block4
    PORT MAP( clk => clk,
              enb => enb,
              dataIn => dataIn_im,  -- ufix16
              validIn => validIn,
              dataOut => C_D_out1  -- ufix29
              );

  UC_C_2 : ltehdlDownlinkSyncDemod_C_block1
    PORT MAP( clk => clk,
              enb => enb,
              dataIn => std_logic_vector(Sum2_out1),  -- ufix17
              validIn => validIn,
              dataOut => C_out1  -- ufix29
              );

  UC_D_1_2 : ltehdlDownlinkSyncDemod_C_D_block3
    PORT MAP( clk => clk,
              enb => enb,
              dataIn => dataIn_re,  -- ufix16
              validIn => validIn,
              dataOut => C_D_out1_1,  -- ufix29
              validOut => C_D_out2
              );

  C_D_out1_signed <= signed(C_D_out1);

  dataIn_im_signed <= signed(dataIn_im);

  dataIn_re_signed <= signed(dataIn_re);

  Sum2_out1 <= (resize(dataIn_im_signed, 17)) - (resize(dataIn_re_signed, 17));

  C_out1_signed <= signed(C_out1);

  Sum3_out1 <= (resize(C_D_out1_signed, 30)) - (resize(C_out1_signed, 30));

  C_D_out1_signed_1 <= signed(C_D_out1_1);

  Sum4_out1 <= (resize(C_out1_signed, 30)) + (resize(C_D_out1_signed_1, 30));

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1_re <= Sum3_out1;
        Delay1_out1_im <= Sum4_out1;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  Data_Type_Conversion_out1_re <= Delay1_out1_re(27 DOWNTO 12) + ('0' & (Delay1_out1_re(11) AND (( NOT Delay1_out1_re(29)) OR (Delay1_out1_re(10) OR Delay1_out1_re(9) OR Delay1_out1_re(8) OR Delay1_out1_re(7) OR Delay1_out1_re(6) OR 
    Delay1_out1_re(5) OR Delay1_out1_re(4) OR Delay1_out1_re(3) OR Delay1_out1_re(2) OR Delay1_out1_re(1) OR Delay1_out1_re(0)))));
  Data_Type_Conversion_out1_im <= Delay1_out1_im(27 DOWNTO 12) + ('0' & (Delay1_out1_im(11) AND (( NOT Delay1_out1_im(29)) OR (Delay1_out1_im(10) OR Delay1_out1_im(9) OR Delay1_out1_im(8) OR Delay1_out1_im(7) OR Delay1_out1_im(6) OR 
    Delay1_out1_im(5) OR Delay1_out1_im(4) OR Delay1_out1_im(3) OR Delay1_out1_im(2) OR Delay1_out1_im(1) OR Delay1_out1_im(0)))));

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_out1_re <= Data_Type_Conversion_out1_re;
        Delay2_out1_im <= Data_Type_Conversion_out1_im;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  dataOut_re <= std_logic_vector(Delay2_out1_re);

  dataOut_im <= std_logic_vector(Delay2_out1_im);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1 <= C_D_out2;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay4_out1 <= Delay3_out1;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  validOut <= Delay4_out1;

END rtl;

