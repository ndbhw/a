-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_Subframe_Counter IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        validIn                           :   IN    std_logic;
        reset                             :   IN    std_logic;
        subframe                          :   OUT   std_logic_vector(3 DOWNTO 0)  -- ufix4
        );
END ltehdlDownlinkSyncDemod_Subframe_Counter;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Subframe_Counter IS

  -- Signals
  SIGNAL subframe_tmp                     : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL reg_sampleCount                  : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_subframeCount                : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL reg_sampleCount_next             : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL reg_subframeCount_next           : unsigned(3 DOWNTO 0);  -- ufix4

BEGIN
  Subframe_Counter_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        reg_sampleCount <= to_unsigned(16#0000#, 15);
        reg_subframeCount <= to_unsigned(16#0#, 4);
      ELSIF enb_1_2_0 = '1' THEN
        reg_sampleCount <= reg_sampleCount_next;
        reg_subframeCount <= reg_subframeCount_next;
      END IF;
    END IF;
  END PROCESS Subframe_Counter_process;

  Subframe_Counter_output : PROCESS (reg_sampleCount, reg_subframeCount, reset, validIn)
  BEGIN
    -- Each subframe consists of 14 OFDM symbols, each containing 2048 samples. 
    -- Sample count tracks samples # within each subframe.
    -- There are 10 subframes within a frame.
    -- Assign outputs
    -- Initialize next states
    reg_sampleCount_next <= reg_sampleCount;
    reg_subframeCount_next <= reg_subframeCount;
    -- Counters for keeping track of samples and symbols within each slot
    IF reset = '1' THEN 
      reg_sampleCount_next <= to_unsigned(16#0000#, 15);
      reg_subframeCount_next <= to_unsigned(16#0#, 4);
    ELSIF validIn = '1' THEN 
      IF reg_sampleCount < to_unsigned(16#6FFF#, 15) THEN 
        reg_sampleCount_next <= reg_sampleCount + to_unsigned(16#0001#, 15);
      ELSE 
        -- last sample of subframe
        reg_sampleCount_next <= to_unsigned(16#0000#, 15);
        IF reg_subframeCount < to_unsigned(16#9#, 4) THEN 
          reg_subframeCount_next <= reg_subframeCount + to_unsigned(16#1#, 4);
        ELSE 
          -- last subframe of frame
          reg_subframeCount_next <= to_unsigned(16#0#, 4);
        END IF;
      END IF;
    END IF;
    -- Update register with next values
    subframe_tmp <= reg_subframeCount;
  END PROCESS Subframe_Counter_output;


  subframe <= std_logic_vector(subframe_tmp);

END rtl;

