-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_Transfer_Timing_Offset IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        enb_1_2_1                         :   IN    std_logic;
        tin                               :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
        tout                              :   OUT   std_logic_vector(18 DOWNTO 0)  -- ufix19
        );
END ltehdlDownlinkSyncDemod_Transfer_Timing_Offset;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Transfer_Timing_Offset IS

  -- Signals
  SIGNAL tin_unsigned                     : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL Gain1_cast                       : unsigned(19 DOWNTO 0);  -- ufix20
  SIGNAL Gain1_out1                       : unsigned(18 DOWNTO 0);  -- ufix19
  SIGNAL ofdm_timingOffset                : unsigned(18 DOWNTO 0) := to_unsigned(16#00000#, 19);  -- ufix19
  SIGNAL Delay5_out1                      : unsigned(18 DOWNTO 0) := to_unsigned(16#00000#, 19);  -- ufix19

BEGIN
  tin_unsigned <= unsigned(tin);

  Gain1_cast <= resize(tin_unsigned & '0' & '0' & '0' & '0', 20);
  Gain1_out1 <= Gain1_cast(18 DOWNTO 0);

  -- Downsample by 2 register (Sample offset 0)
  Downsample1_output_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_1 = '1' THEN
        ofdm_timingOffset <= Gain1_out1;
      END IF;
    END IF;
  END PROCESS Downsample1_output_process;


  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay5_out1 <= ofdm_timingOffset;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  tout <= std_logic_vector(Delay5_out1);

END rtl;

