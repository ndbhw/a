-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_1 IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        din_1_1_re_dly                    :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        din_1_1_im_dly                    :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        din_1_vld_dly                     :   IN    std_logic;
        rd_1_Addr                         :   IN    std_logic_vector(9 DOWNTO 0);  -- ufix10
        rd_1_Enb                          :   IN    std_logic;
        proc_1_enb                        :   IN    std_logic;
        syncReset                         :   IN    std_logic;
        dout_1_1_re                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- ufix17
        dout_1_1_im                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- ufix17
        dout_1_1_vld                      :   OUT   std_logic;
        dinXTwdl_1_1_vld                  :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_1;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_1 IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    GENERIC( AddrWidth                    : integer;
             DataWidth                    : integer
             );
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          wr_din                          :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          wr_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          wr_en                           :   IN    std_logic;
          rd_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          dout                            :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0)  -- generic width
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_SDFCommutator1
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          din_1_vld_dly                   :   IN    std_logic;
          xf_re                           :   IN    std_logic_vector(16 DOWNTO 0);  -- ufix17
          xf_im                           :   IN    std_logic_vector(16 DOWNTO 0);  -- ufix17
          xf_vld                          :   IN    std_logic;
          dinXTwdlf_re                    :   IN    std_logic_vector(16 DOWNTO 0);  -- ufix17
          dinXTwdlf_im                    :   IN    std_logic_vector(16 DOWNTO 0);  -- ufix17
          dinxTwdlf_vld                   :   IN    std_logic;
          btf1_re                         :   IN    std_logic_vector(16 DOWNTO 0);  -- ufix17
          btf1_im                         :   IN    std_logic_vector(16 DOWNTO 0);  -- ufix17
          btf2_re                         :   IN    std_logic_vector(16 DOWNTO 0);  -- ufix17
          btf2_im                         :   IN    std_logic_vector(16 DOWNTO 0);  -- ufix17
          btf_vld                         :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          wrData_re                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- ufix17
          wrData_im                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- ufix17
          wrAddr                          :   OUT   std_logic_vector(9 DOWNTO 0);  -- ufix10
          wrEnb                           :   OUT   std_logic;
          dout_1_1_re                     :   OUT   std_logic_vector(16 DOWNTO 0);  -- ufix17
          dout_1_1_im                     :   OUT   std_logic_vector(16 DOWNTO 0);  -- ufix17
          dout_1_1_vld                    :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_SDFCommutator1
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_SDFCommutator1(rtl);

  -- Signals
  SIGNAL din_1_1_re_dly_signed            : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL din_re                           : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL dinXTwdl_re                      : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En15
  SIGNAL din_1_1_im_dly_signed            : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL din_im                           : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL dinXTwdl_im                      : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En15
  SIGNAL dinXTwdl_1_1_vld_1               : std_logic := '0';
  SIGNAL x_vld                            : std_logic := '0';
  SIGNAL btf2_im                          : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL btf2_re                          : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL btf1_im                          : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL btf1_re                          : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL dinXTwdlf_im                     : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL dinXTwdlf_re                     : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL xf_im                            : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En15
  SIGNAL wrData_im                        : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL wrAddr                           : std_logic_vector(9 DOWNTO 0);  -- ufix10
  SIGNAL wrEnb                            : std_logic;
  SIGNAL x_im                             : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL x_im_signed                      : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL wrData_re                        : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL x_re                             : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL x_re_signed                      : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL Radix22ButterflyG1_btf1_re_reg   : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18
  SIGNAL Radix22ButterflyG1_btf1_im_reg   : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18
  SIGNAL Radix22ButterflyG1_btf2_re_reg   : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18
  SIGNAL Radix22ButterflyG1_btf2_im_reg   : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18
  SIGNAL Radix22ButterflyG1_x_re_dly1     : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17
  SIGNAL Radix22ButterflyG1_x_im_dly1     : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17
  SIGNAL Radix22ButterflyG1_x_vld_dly1    : std_logic := '0';
  SIGNAL Radix22ButterflyG1_dinXtwdl_re_dly1 : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17
  SIGNAL Radix22ButterflyG1_dinXtwdl_im_dly1 : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17
  SIGNAL Radix22ButterflyG1_dinXtwdl_re_dly2 : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17
  SIGNAL Radix22ButterflyG1_dinXtwdl_im_dly2 : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17
  SIGNAL Radix22ButterflyG1_dinXtwdl_vld_dly1 : std_logic := '0';
  SIGNAL Radix22ButterflyG1_dinXtwdl_vld_dly2 : std_logic := '0';
  SIGNAL Radix22ButterflyG1_btf1_re_reg_next : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL Radix22ButterflyG1_btf1_im_reg_next : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL Radix22ButterflyG1_btf2_re_reg_next : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL Radix22ButterflyG1_btf2_im_reg_next : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL xf_re                            : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En15
  SIGNAL xf_vld                           : std_logic := '0';
  SIGNAL dinxTwdlf_vld                    : std_logic;
  SIGNAL btf_vld                          : std_logic := '0';
  SIGNAL dout_1_1_re_tmp                  : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL dout_1_1_im_tmp                  : std_logic_vector(16 DOWNTO 0);  -- ufix17

BEGIN
  UdataMEM_im_0_1 : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    GENERIC MAP( AddrWidth => 10,
                 DataWidth => 17
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din => wrData_im,
              wr_addr => wrAddr,
              wr_en => wrEnb,
              rd_addr => rd_1_Addr,
              dout => x_im
              );

  UdataMEM_re_0_1_generic : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block
    GENERIC MAP( AddrWidth => 10,
                 DataWidth => 17
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din => wrData_re,
              wr_addr => wrAddr,
              wr_en => wrEnb,
              rd_addr => rd_1_Addr,
              dout => x_re
              );

  USDFCOMMUTATOR_1 : ltehdlDownlinkSyncDemod_SDFCommutator1
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              din_1_vld_dly => din_1_vld_dly,
              xf_re => std_logic_vector(xf_re),  -- ufix17
              xf_im => std_logic_vector(xf_im),  -- ufix17
              xf_vld => xf_vld,
              dinXTwdlf_re => std_logic_vector(dinXTwdlf_re),  -- ufix17
              dinXTwdlf_im => std_logic_vector(dinXTwdlf_im),  -- ufix17
              dinxTwdlf_vld => dinxTwdlf_vld,
              btf1_re => std_logic_vector(btf1_re),  -- ufix17
              btf1_im => std_logic_vector(btf1_im),  -- ufix17
              btf2_re => std_logic_vector(btf2_re),  -- ufix17
              btf2_im => std_logic_vector(btf2_im),  -- ufix17
              btf_vld => btf_vld,
              syncReset => syncReset,
              wrData_re => wrData_re,  -- ufix17
              wrData_im => wrData_im,  -- ufix17
              wrAddr => wrAddr,  -- ufix10
              wrEnb => wrEnb,
              dout_1_1_re => dout_1_1_re_tmp,  -- ufix17
              dout_1_1_im => dout_1_1_im_tmp,  -- ufix17
              dout_1_1_vld => dout_1_1_vld
              );

  din_1_1_re_dly_signed <= signed(din_1_1_re_dly);

  din_re <= resize(din_1_1_re_dly_signed, 17);

  intdelay_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          dinXTwdl_re <= to_signed(16#00000#, 17);
        ELSE 
          dinXTwdl_re <= din_re;
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_process;


  din_1_1_im_dly_signed <= signed(din_1_1_im_dly);

  din_im <= resize(din_1_1_im_dly_signed, 17);

  intdelay_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          dinXTwdl_im <= to_signed(16#00000#, 17);
        ELSE 
          dinXTwdl_im <= din_im;
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_1_process;


  intdelay_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          dinXTwdl_1_1_vld_1 <= '0';
        ELSE 
          dinXTwdl_1_1_vld_1 <= din_1_vld_dly;
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_2_process;


  intdelay_3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          x_vld <= '0';
        ELSE 
          x_vld <= rd_1_Enb;
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_3_process;


  x_im_signed <= signed(x_im);

  x_re_signed <= signed(x_re);

  -- Radix22ButterflyG1
  Radix22ButterflyG1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          Radix22ButterflyG1_btf1_re_reg <= to_signed(16#00000#, 18);
          Radix22ButterflyG1_btf1_im_reg <= to_signed(16#00000#, 18);
          Radix22ButterflyG1_btf2_re_reg <= to_signed(16#00000#, 18);
          Radix22ButterflyG1_btf2_im_reg <= to_signed(16#00000#, 18);
          Radix22ButterflyG1_x_re_dly1 <= to_signed(16#00000#, 17);
          Radix22ButterflyG1_x_im_dly1 <= to_signed(16#00000#, 17);
          Radix22ButterflyG1_x_vld_dly1 <= '0';
          xf_re <= to_signed(16#00000#, 17);
          xf_im <= to_signed(16#00000#, 17);
          xf_vld <= '0';
          Radix22ButterflyG1_dinXtwdl_re_dly1 <= to_signed(16#00000#, 17);
          Radix22ButterflyG1_dinXtwdl_im_dly1 <= to_signed(16#00000#, 17);
          Radix22ButterflyG1_dinXtwdl_re_dly2 <= to_signed(16#00000#, 17);
          Radix22ButterflyG1_dinXtwdl_im_dly2 <= to_signed(16#00000#, 17);
          Radix22ButterflyG1_dinXtwdl_vld_dly1 <= '0';
          Radix22ButterflyG1_dinXtwdl_vld_dly2 <= '0';
          btf_vld <= '0';
        ELSE 
          Radix22ButterflyG1_btf1_re_reg <= Radix22ButterflyG1_btf1_re_reg_next;
          Radix22ButterflyG1_btf1_im_reg <= Radix22ButterflyG1_btf1_im_reg_next;
          Radix22ButterflyG1_btf2_re_reg <= Radix22ButterflyG1_btf2_re_reg_next;
          Radix22ButterflyG1_btf2_im_reg <= Radix22ButterflyG1_btf2_im_reg_next;
          xf_re <= Radix22ButterflyG1_x_re_dly1;
          xf_im <= Radix22ButterflyG1_x_im_dly1;
          xf_vld <= Radix22ButterflyG1_x_vld_dly1;
          btf_vld <= Radix22ButterflyG1_dinXtwdl_vld_dly2;
          Radix22ButterflyG1_dinXtwdl_vld_dly2 <= Radix22ButterflyG1_dinXtwdl_vld_dly1;
          Radix22ButterflyG1_dinXtwdl_re_dly2 <= Radix22ButterflyG1_dinXtwdl_re_dly1;
          Radix22ButterflyG1_dinXtwdl_im_dly2 <= Radix22ButterflyG1_dinXtwdl_im_dly1;
          Radix22ButterflyG1_dinXtwdl_re_dly1 <= dinXTwdl_re;
          Radix22ButterflyG1_dinXtwdl_im_dly1 <= dinXTwdl_im;
          Radix22ButterflyG1_x_re_dly1 <= x_re_signed;
          Radix22ButterflyG1_x_im_dly1 <= x_im_signed;
          Radix22ButterflyG1_x_vld_dly1 <= x_vld;
          Radix22ButterflyG1_dinXtwdl_vld_dly1 <= proc_1_enb AND dinXTwdl_1_1_vld_1;
        END IF;
      END IF;
    END IF;
  END PROCESS Radix22ButterflyG1_process;

  dinxTwdlf_vld <= ( NOT proc_1_enb) AND dinXTwdl_1_1_vld_1;
  Radix22ButterflyG1_btf1_re_reg_next <= (resize(Radix22ButterflyG1_x_re_dly1, 18)) + (resize(Radix22ButterflyG1_dinXtwdl_re_dly2, 18));
  Radix22ButterflyG1_btf2_re_reg_next <= (resize(Radix22ButterflyG1_x_re_dly1, 18)) - (resize(Radix22ButterflyG1_dinXtwdl_re_dly2, 18));
  Radix22ButterflyG1_btf1_im_reg_next <= (resize(Radix22ButterflyG1_x_im_dly1, 18)) + (resize(Radix22ButterflyG1_dinXtwdl_im_dly2, 18));
  Radix22ButterflyG1_btf2_im_reg_next <= (resize(Radix22ButterflyG1_x_im_dly1, 18)) - (resize(Radix22ButterflyG1_dinXtwdl_im_dly2, 18));
  dinXTwdlf_re <= dinXTwdl_re;
  dinXTwdlf_im <= dinXTwdl_im;
  btf1_re <= Radix22ButterflyG1_btf1_re_reg(16 DOWNTO 0);
  btf1_im <= Radix22ButterflyG1_btf1_im_reg(16 DOWNTO 0);
  btf2_re <= Radix22ButterflyG1_btf2_re_reg(16 DOWNTO 0);
  btf2_im <= Radix22ButterflyG1_btf2_im_reg(16 DOWNTO 0);

  dout_1_1_re <= dout_1_1_re_tmp;

  dout_1_1_im <= dout_1_1_im_tmp;

  dinXTwdl_1_1_vld <= dinXTwdl_1_1_vld_1;

END rtl;

