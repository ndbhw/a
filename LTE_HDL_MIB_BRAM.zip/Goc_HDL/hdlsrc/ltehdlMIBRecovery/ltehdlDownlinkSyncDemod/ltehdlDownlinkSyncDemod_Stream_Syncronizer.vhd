-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_Stream_Syncronizer IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        pop                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        push                              :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataOut_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Stream_Syncronizer;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Stream_Syncronizer IS

  -- Signals
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataOut_re_tmp                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataOut_im_tmp                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL wrAddr                           : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL rdAddr                           : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL dataOutReg_re                    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataOutReg_im                    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL validOutReg                      : std_logic;
  SIGNAL mem_re                           : vector_of_signed16(0 TO 127);  -- sfix16_En15 [128]
  SIGNAL mem_im                           : vector_of_signed16(0 TO 127);  -- sfix16_En15 [128]
  SIGNAL level                            : signed(15 DOWNTO 0);  -- int16
  SIGNAL wrAddr_next                      : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL rdAddr_next                      : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL dataOutReg_next_re               : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataOutReg_next_im               : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL validOutReg_next                 : std_logic;
  SIGNAL mem_next_re                      : vector_of_signed16(0 TO 127);  -- sfix16_En15 [128]
  SIGNAL mem_next_im                      : vector_of_signed16(0 TO 127);  -- sfix16_En15 [128]
  SIGNAL level_next                       : signed(15 DOWNTO 0);  -- int16

BEGIN
  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Stream_Syncronizer_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        wrAddr <= to_unsigned(16#00#, 7);
        rdAddr <= to_unsigned(16#00#, 7);
        dataOutReg_re <= to_signed(16#0000#, 16);
        dataOutReg_im <= to_signed(16#0000#, 16);
        validOutReg <= '0';
        mem_re <= (OTHERS => to_signed(16#0000#, 16));
        mem_im <= (OTHERS => to_signed(16#0000#, 16));
        level <= to_signed(16#0000#, 16);
      ELSIF enb = '1' THEN
        wrAddr <= wrAddr_next;
        rdAddr <= rdAddr_next;
        dataOutReg_re <= dataOutReg_next_re;
        dataOutReg_im <= dataOutReg_next_im;
        validOutReg <= validOutReg_next;
        mem_re <= mem_next_re;
        mem_im <= mem_next_im;
        level <= level_next;
      END IF;
    END IF;
  END PROCESS Stream_Syncronizer_process;

  Stream_Syncronizer_output : PROCESS (dataIn_im_signed, dataIn_re_signed, dataOutReg_im, dataOutReg_re, level,
       mem_im, mem_re, pop, push, rdAddr, validOutReg, wrAddr)
    VARIABLE level_temp : signed(15 DOWNTO 0);
    VARIABLE sub_temp : signed(16 DOWNTO 0);
    VARIABLE add_temp : signed(16 DOWNTO 0);
  BEGIN
    sub_temp := to_signed(16#00000#, 17);
    add_temp := to_signed(16#00000#, 17);
    level_temp := level;
    wrAddr_next <= wrAddr;
    rdAddr_next <= rdAddr;
    dataOutReg_next_re <= dataOutReg_re;
    dataOutReg_next_im <= dataOutReg_im;
    mem_next_re <= mem_re;
    mem_next_im <= mem_im;
    --------------------------------------------------------------------------
    -- Constants
    --------------------------------------------------------------------------
    -- Persistent variable initialization
    --------------------------------------------------------------------------
    -- Outputs
    --------------------------------------------------------------------------
    --------------------------------------------------------------------------
    -- Calculate next state values
    --------------------------------------------------------------------------
    IF pop = '1' THEN 
      dataOutReg_next_re <= mem_re(to_integer(rdAddr));
      dataOutReg_next_im <= mem_im(to_integer(rdAddr));
      rdAddr_next <= rdAddr + to_unsigned(16#01#, 7);
      sub_temp := resize(level, 17) - to_signed(16#00001#, 17);
      IF (sub_temp(16) = '0') AND (sub_temp(15) /= '0') THEN 
        level_temp := X"7FFF";
      ELSIF (sub_temp(16) = '1') AND (sub_temp(15) /= '1') THEN 
        level_temp := X"8000";
      ELSE 
        level_temp := sub_temp(15 DOWNTO 0);
      END IF;
    END IF;
    IF push = '1' THEN 
      mem_next_re(to_integer(wrAddr)) <= dataIn_re_signed;
      mem_next_im(to_integer(wrAddr)) <= dataIn_im_signed;
      wrAddr_next <= wrAddr + to_unsigned(16#01#, 7);
      add_temp := resize(level_temp, 17) + to_signed(16#00001#, 17);
      IF (add_temp(16) = '0') AND (add_temp(15) /= '0') THEN 
        level_temp := X"7FFF";
      ELSIF (add_temp(16) = '1') AND (add_temp(15) /= '1') THEN 
        level_temp := X"8000";
      ELSE 
        level_temp := add_temp(15 DOWNTO 0);
      END IF;
    END IF;
    validOutReg_next <= pop;
    dataOut_re_tmp <= dataOutReg_re;
    dataOut_im_tmp <= dataOutReg_im;
    validOut <= validOutReg;
    level_next <= level_temp;
  END PROCESS Stream_Syncronizer_output;


  dataOut_re <= std_logic_vector(dataOut_re_tmp);

  dataOut_im <= std_logic_vector(dataOut_im_tmp);

END rtl;

