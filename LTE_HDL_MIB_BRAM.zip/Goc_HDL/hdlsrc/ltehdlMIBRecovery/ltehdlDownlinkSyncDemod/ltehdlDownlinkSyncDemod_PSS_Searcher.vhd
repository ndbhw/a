-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_PSS_Searcher IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        start                             :   IN    std_logic;
        startTime                         :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
        timingOffset                      :   OUT   std_logic_vector(14 DOWNTO 0);  -- ufix15
        NCellID2                          :   OUT   std_logic_vector(1 DOWNTO 0);  -- ufix2
        done                              :   OUT   std_logic;
        success                           :   OUT   std_logic;
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_PSS_Searcher;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_PSS_Searcher IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_Correlators
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          correlation_0                   :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
          correlation_1                   :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
          correlation_2                   :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
          threshold                       :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Max_Peak_Searcher
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          correlationIn_0                 :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
          correlationIn_1                 :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
          correlationIn_2                 :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
          thresholdIn                     :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
          validIn                         :   IN    std_logic;
          start                           :   IN    std_logic;
          startTime                       :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
          timingOffset                    :   OUT   std_logic_vector(14 DOWNTO 0);  -- ufix15
          NCellID2                        :   OUT   std_logic_vector(1 DOWNTO 0);  -- ufix2
          done                            :   OUT   std_logic;
          success                         :   OUT   std_logic;
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_Correlators
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Correlators(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Max_Peak_Searcher
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Max_Peak_Searcher(rtl);

  -- Signals
  SIGNAL tb_PSSCorrelation_1              : std_logic_vector(29 DOWNTO 0);  -- ufix30
  SIGNAL tb_PSSCorrelation_2              : std_logic_vector(29 DOWNTO 0);  -- ufix30
  SIGNAL tb_PSSThreshold                  : std_logic_vector(29 DOWNTO 0);  -- ufix30
  SIGNAL tb_PSSValid                      : std_logic;
  SIGNAL tb_PSSCorrelation                : vector_of_std_logic_vector30(0 TO 2);  -- ufix30 [3]
  SIGNAL tb_PSSCorrelation_3              : vector_of_unsigned30(0 TO 2);  -- ufix30_En24 [3]
  SIGNAL timingOffset_tmp                 : std_logic_vector(14 DOWNTO 0);  -- ufix15
  SIGNAL tb_NCellID2                      : std_logic_vector(1 DOWNTO 0);  -- ufix2
  SIGNAL startTime_unsigned               : unsigned(14 DOWNTO 0);  -- ufix15

BEGIN
  UCorrelators : ltehdlDownlinkSyncDemod_Correlators
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              dataIn_re => dataIn_re,  -- sfix16_En15
              dataIn_im => dataIn_im,  -- sfix16_En15
              validIn => validIn,
              correlation_0 => tb_PSSCorrelation(0),  -- ufix30_En24
              correlation_1 => tb_PSSCorrelation_1,  -- ufix30_En24
              correlation_2 => tb_PSSCorrelation_2,  -- ufix30_En24
              threshold => tb_PSSThreshold,  -- ufix30_En24
              validOut => tb_PSSValid
              );

  UMax_Peak_Searcher : ltehdlDownlinkSyncDemod_Max_Peak_Searcher
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              correlationIn_0 => std_logic_vector(tb_PSSCorrelation_3(0)),  -- ufix30_En24
              correlationIn_1 => tb_PSSCorrelation_1,  -- ufix30_En24
              correlationIn_2 => tb_PSSCorrelation_2,  -- ufix30_En24
              thresholdIn => tb_PSSThreshold,  -- ufix30_En24
              validIn => tb_PSSValid,
              start => start,
              startTime => startTime,  -- ufix15
              timingOffset => timingOffset_tmp,  -- ufix15
              NCellID2 => tb_NCellID2,  -- ufix2
              done => done,
              success => success,
              validOut => validOut
              );

  tb_PSSCorrelation(1) <= tb_PSSCorrelation_1;
  tb_PSSCorrelation(2) <= tb_PSSCorrelation_2;

  outputgen: FOR kk IN 0 TO 2 GENERATE
    tb_PSSCorrelation_3(kk) <= unsigned(tb_PSSCorrelation(kk));
  END GENERATE;

  timingOffset <= timingOffset_tmp;

  NCellID2 <= tb_NCellID2;

END rtl;

