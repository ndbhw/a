-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_SlotAverage IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(23 DOWNTO 0);  -- sfix24_En23
        dataIn_im                         :   IN    std_logic_vector(23 DOWNTO 0);  -- sfix24_En23
        validIn                           :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(23 DOWNTO 0);  -- sfix24_En23
        dataOut_im                        :   OUT   std_logic_vector(23 DOWNTO 0);  -- sfix24_En23
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_SlotAverage;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_SlotAverage IS

  -- Signals
  SIGNAL Delay13_out1                     : std_logic := '0';
  SIGNAL Delay9_out1                      : std_logic := '0';
  SIGNAL Delay14_out1                     : std_logic := '0';
  SIGNAL Delay20_out1                     : std_logic := '0';
  SIGNAL Delay23_out1                     : std_logic := '0';
  SIGNAL Delay26_out1                     : std_logic := '0';
  SIGNAL dataIn_re_signed                 : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL dataIn_im_signed                 : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay7_out1_re                   : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay7_out1_im                   : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay6_reg_re                    : vector_of_signed24(0 TO 136) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [137]
  SIGNAL Delay6_reg_im                    : vector_of_signed24(0 TO 136) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [137]
  SIGNAL Delay6_out1_re                   : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay6_out1_im                   : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay10_out1_re                  : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay10_out1_im                  : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay4_reg_re                    : vector_of_signed24(0 TO 136) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [137]
  SIGNAL Delay4_reg_im                    : vector_of_signed24(0 TO 136) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [137]
  SIGNAL Delay4_out1_re                   : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay4_out1_im                   : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay15_out1_re                  : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay15_out1_im                  : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay3_reg_re                    : vector_of_signed24(0 TO 136) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [137]
  SIGNAL Delay3_reg_im                    : vector_of_signed24(0 TO 136) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [137]
  SIGNAL Delay3_out1_re                   : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay3_out1_im                   : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay19_out1_re                  : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay19_out1_im                  : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay2_reg_re                    : vector_of_signed24(0 TO 136) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [137]
  SIGNAL Delay2_reg_im                    : vector_of_signed24(0 TO 136) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [137]
  SIGNAL Delay2_out1_re                   : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay2_out1_im                   : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay22_out1_re                  : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay22_out1_im                  : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay1_reg_re                    : vector_of_signed24(0 TO 136) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [137]
  SIGNAL Delay1_reg_im                    : vector_of_signed24(0 TO 136) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [137]
  SIGNAL Delay1_out1_re                   : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay1_out1_im                   : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay25_out1_re                  : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay25_out1_im                  : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay5_reg_re                    : vector_of_signed24(0 TO 136) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [137]
  SIGNAL Delay5_reg_im                    : vector_of_signed24(0 TO 136) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [137]
  SIGNAL Delay5_out1_re                   : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay5_out1_im                   : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Add1_out1_re                     : signed(27 DOWNTO 0);  -- sfix28_En23
  SIGNAL Add1_out1_im                     : signed(27 DOWNTO 0);  -- sfix28_En23
  SIGNAL Delay8_out1_re                   : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En23
  SIGNAL Delay8_out1_im                   : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En23
  SIGNAL Add2_out1_re                     : signed(28 DOWNTO 0);  -- sfix29_En23
  SIGNAL Add2_out1_im                     : signed(28 DOWNTO 0);  -- sfix29_En23
  SIGNAL Delay16_out1_re                  : signed(28 DOWNTO 0) := to_signed(16#00000000#, 29);  -- sfix29_En23
  SIGNAL Delay16_out1_im                  : signed(28 DOWNTO 0) := to_signed(16#00000000#, 29);  -- sfix29_En23
  SIGNAL Add3_add_temp                    : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Add3_add_temp_1                  : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Add3_out1_re                     : signed(28 DOWNTO 0);  -- sfix29_En23
  SIGNAL Add3_out1_im                     : signed(28 DOWNTO 0);  -- sfix29_En23
  SIGNAL Delay21_out1_re                  : signed(28 DOWNTO 0) := to_signed(16#00000000#, 29);  -- sfix29_En23
  SIGNAL Delay21_out1_im                  : signed(28 DOWNTO 0) := to_signed(16#00000000#, 29);  -- sfix29_En23
  SIGNAL Add4_out1_re                     : signed(28 DOWNTO 0);  -- sfix29_En23
  SIGNAL Add4_out1_im                     : signed(28 DOWNTO 0);  -- sfix29_En23
  SIGNAL Delay24_out1_re                  : signed(28 DOWNTO 0) := to_signed(16#00000000#, 29);  -- sfix29_En23
  SIGNAL Delay24_out1_im                  : signed(28 DOWNTO 0) := to_signed(16#00000000#, 29);  -- sfix29_En23
  SIGNAL Add5_out1_re                     : signed(29 DOWNTO 0);  -- sfix30_En23
  SIGNAL Add5_out1_im                     : signed(29 DOWNTO 0);  -- sfix30_En23
  SIGNAL Delay27_out1_re                  : signed(29 DOWNTO 0) := to_signed(16#00000000#, 30);  -- sfix30_En23
  SIGNAL Delay27_out1_im                  : signed(29 DOWNTO 0) := to_signed(16#00000000#, 30);  -- sfix30_En23
  SIGNAL Add6_out1_re                     : signed(29 DOWNTO 0);  -- sfix30_En23
  SIGNAL Add6_out1_im                     : signed(29 DOWNTO 0);  -- sfix30_En23
  SIGNAL Delay12_out1_re                  : signed(29 DOWNTO 0) := to_signed(16#00000000#, 30);  -- sfix30_En23
  SIGNAL Delay12_out1_im                  : signed(29 DOWNTO 0) := to_signed(16#00000000#, 30);  -- sfix30_En23
  SIGNAL Gain_cast                        : signed(59 DOWNTO 0);  -- sfix60_En54
  SIGNAL Gain_cast_1                      : signed(59 DOWNTO 0);  -- sfix60_En54
  SIGNAL Gain_out1_re                     : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Gain_out1_im                     : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay11_out1_re                  : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay11_out1_im                  : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay17_out1                     : std_logic := '0';
  SIGNAL Delay18_out1                     : std_logic := '0';

BEGIN
  -- This subsystem averages 7 of the CP correlation results, equivalant to 1 slot of averaging. This is done by delaying 
  -- the signal by integer multiples of the OFDM symbol period, i.e. 137 samples
  -- To optimize for HDL we scale the summation result by 1/8 rather than 1/7. 

  Delay13_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay13_out1 <= validIn;
      END IF;
    END IF;
  END PROCESS Delay13_process;


  Delay9_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay9_out1 <= Delay13_out1;
      END IF;
    END IF;
  END PROCESS Delay9_process;


  Delay14_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay14_out1 <= Delay9_out1;
      END IF;
    END IF;
  END PROCESS Delay14_process;


  Delay20_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay20_out1 <= Delay14_out1;
      END IF;
    END IF;
  END PROCESS Delay20_process;


  Delay23_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay23_out1 <= Delay20_out1;
      END IF;
    END IF;
  END PROCESS Delay23_process;


  Delay26_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay26_out1 <= Delay23_out1;
      END IF;
    END IF;
  END PROCESS Delay26_process;


  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Delay7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay7_out1_re <= dataIn_re_signed;
        Delay7_out1_im <= dataIn_im_signed;
      END IF;
    END IF;
  END PROCESS Delay7_process;


  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay13_out1 = '1' THEN
        Delay6_reg_im(0) <= Delay7_out1_im;
        Delay6_reg_im(1 TO 136) <= Delay6_reg_im(0 TO 135);
        Delay6_reg_re(0) <= Delay7_out1_re;
        Delay6_reg_re(1 TO 136) <= Delay6_reg_re(0 TO 135);
      END IF;
    END IF;
  END PROCESS Delay6_process;

  Delay6_out1_re <= Delay6_reg_re(136);
  Delay6_out1_im <= Delay6_reg_im(136);

  Delay10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay10_out1_re <= Delay6_out1_re;
        Delay10_out1_im <= Delay6_out1_im;
      END IF;
    END IF;
  END PROCESS Delay10_process;


  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay9_out1 = '1' THEN
        Delay4_reg_im(0) <= Delay10_out1_im;
        Delay4_reg_im(1 TO 136) <= Delay4_reg_im(0 TO 135);
        Delay4_reg_re(0) <= Delay10_out1_re;
        Delay4_reg_re(1 TO 136) <= Delay4_reg_re(0 TO 135);
      END IF;
    END IF;
  END PROCESS Delay4_process;

  Delay4_out1_re <= Delay4_reg_re(136);
  Delay4_out1_im <= Delay4_reg_im(136);

  Delay15_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay15_out1_re <= Delay4_out1_re;
        Delay15_out1_im <= Delay4_out1_im;
      END IF;
    END IF;
  END PROCESS Delay15_process;


  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay14_out1 = '1' THEN
        Delay3_reg_im(0) <= Delay15_out1_im;
        Delay3_reg_im(1 TO 136) <= Delay3_reg_im(0 TO 135);
        Delay3_reg_re(0) <= Delay15_out1_re;
        Delay3_reg_re(1 TO 136) <= Delay3_reg_re(0 TO 135);
      END IF;
    END IF;
  END PROCESS Delay3_process;

  Delay3_out1_re <= Delay3_reg_re(136);
  Delay3_out1_im <= Delay3_reg_im(136);

  Delay19_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay19_out1_re <= Delay3_out1_re;
        Delay19_out1_im <= Delay3_out1_im;
      END IF;
    END IF;
  END PROCESS Delay19_process;


  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay20_out1 = '1' THEN
        Delay2_reg_im(0) <= Delay19_out1_im;
        Delay2_reg_im(1 TO 136) <= Delay2_reg_im(0 TO 135);
        Delay2_reg_re(0) <= Delay19_out1_re;
        Delay2_reg_re(1 TO 136) <= Delay2_reg_re(0 TO 135);
      END IF;
    END IF;
  END PROCESS Delay2_process;

  Delay2_out1_re <= Delay2_reg_re(136);
  Delay2_out1_im <= Delay2_reg_im(136);

  Delay22_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay22_out1_re <= Delay2_out1_re;
        Delay22_out1_im <= Delay2_out1_im;
      END IF;
    END IF;
  END PROCESS Delay22_process;


  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay23_out1 = '1' THEN
        Delay1_reg_im(0) <= Delay22_out1_im;
        Delay1_reg_im(1 TO 136) <= Delay1_reg_im(0 TO 135);
        Delay1_reg_re(0) <= Delay22_out1_re;
        Delay1_reg_re(1 TO 136) <= Delay1_reg_re(0 TO 135);
      END IF;
    END IF;
  END PROCESS Delay1_process;

  Delay1_out1_re <= Delay1_reg_re(136);
  Delay1_out1_im <= Delay1_reg_im(136);

  Delay25_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay25_out1_re <= Delay1_out1_re;
        Delay25_out1_im <= Delay1_out1_im;
      END IF;
    END IF;
  END PROCESS Delay25_process;


  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay26_out1 = '1' THEN
        Delay5_reg_im(0) <= Delay25_out1_im;
        Delay5_reg_im(1 TO 136) <= Delay5_reg_im(0 TO 135);
        Delay5_reg_re(0) <= Delay25_out1_re;
        Delay5_reg_re(1 TO 136) <= Delay5_reg_re(0 TO 135);
      END IF;
    END IF;
  END PROCESS Delay5_process;

  Delay5_out1_re <= Delay5_reg_re(136);
  Delay5_out1_im <= Delay5_reg_im(136);

  Add1_out1_re <= (resize(Delay6_out1_re, 28)) + (resize(Delay7_out1_re, 28));
  Add1_out1_im <= (resize(Delay6_out1_im, 28)) + (resize(Delay7_out1_im, 28));

  Delay8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay8_out1_re <= Add1_out1_re;
        Delay8_out1_im <= Add1_out1_im;
      END IF;
    END IF;
  END PROCESS Delay8_process;


  Add2_out1_re <= (resize(Delay4_out1_re, 29)) + (resize(Delay8_out1_re, 29));
  Add2_out1_im <= (resize(Delay4_out1_im, 29)) + (resize(Delay8_out1_im, 29));

  Delay16_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay16_out1_re <= Add2_out1_re;
        Delay16_out1_im <= Add2_out1_im;
      END IF;
    END IF;
  END PROCESS Delay16_process;


  Add3_add_temp <= Delay3_out1_re + Delay16_out1_re(23 DOWNTO 0);
  Add3_out1_re <= resize(Add3_add_temp, 29);
  Add3_add_temp_1 <= Delay3_out1_im + Delay16_out1_im(23 DOWNTO 0);
  Add3_out1_im <= resize(Add3_add_temp_1, 29);

  Delay21_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay21_out1_re <= Add3_out1_re;
        Delay21_out1_im <= Add3_out1_im;
      END IF;
    END IF;
  END PROCESS Delay21_process;


  Add4_out1_re <= (resize(Delay2_out1_re, 29)) + Delay21_out1_re;
  Add4_out1_im <= (resize(Delay2_out1_im, 29)) + Delay21_out1_im;

  Delay24_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay24_out1_re <= Add4_out1_re;
        Delay24_out1_im <= Add4_out1_im;
      END IF;
    END IF;
  END PROCESS Delay24_process;


  Add5_out1_re <= (resize(Delay1_out1_re, 30)) + (resize(Delay24_out1_re, 30));
  Add5_out1_im <= (resize(Delay1_out1_im, 30)) + (resize(Delay24_out1_im, 30));

  Delay27_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay27_out1_re <= Add5_out1_re;
        Delay27_out1_im <= Add5_out1_im;
      END IF;
    END IF;
  END PROCESS Delay27_process;


  Add6_out1_re <= (resize(Delay5_out1_re, 30)) + Delay27_out1_re;
  Add6_out1_im <= (resize(Delay5_out1_im, 30)) + Delay27_out1_im;

  Delay12_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay12_out1_re <= Add6_out1_re;
        Delay12_out1_im <= Add6_out1_im;
      END IF;
    END IF;
  END PROCESS Delay12_process;


  Gain_cast <= resize(Delay12_out1_re & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 60);
  Gain_out1_re <= Gain_cast(54 DOWNTO 31);
  Gain_cast_1 <= resize(Delay12_out1_im & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 60);
  Gain_out1_im <= Gain_cast_1(54 DOWNTO 31);

  Delay11_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay11_out1_re <= Gain_out1_re;
        Delay11_out1_im <= Gain_out1_im;
      END IF;
    END IF;
  END PROCESS Delay11_process;


  dataOut_re <= std_logic_vector(Delay11_out1_re);

  dataOut_im <= std_logic_vector(Delay11_out1_im);

  Delay17_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay17_out1 <= Delay26_out1;
      END IF;
    END IF;
  END PROCESS Delay17_process;


  Delay18_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay18_out1 <= Delay17_out1;
      END IF;
    END IF;
  END PROCESS Delay18_process;


  validOut <= Delay18_out1;

END rtl;

