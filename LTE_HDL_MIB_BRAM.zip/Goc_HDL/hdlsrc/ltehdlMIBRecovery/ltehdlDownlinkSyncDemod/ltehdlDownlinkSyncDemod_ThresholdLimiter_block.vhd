-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_ThresholdLimiter_block IS
  PORT( x_x                               :   IN    std_logic_vector(35 DOWNTO 0);  -- ufix36
        y_y                               :   OUT   std_logic_vector(35 DOWNTO 0)  -- sfix36_En26
        );
END ltehdlDownlinkSyncDemod_ThresholdLimiter_block;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_ThresholdLimiter_block IS

  -- Signals
  SIGNAL x_signed                         : signed(35 DOWNTO 0);  -- sfix36_En26
  SIGNAL y_tmp                            : signed(35 DOWNTO 0);  -- sfix36_En26

BEGIN
  x_signed <= signed(x_x);

  -- Apply a lower limit to the threshold.
  -- Threshold is computed by summing across 62 samples.
  -- Set lower limit to be equivalent of all 62 samples
  -- having their LSB set to 1 and all others set to 0. 
  
  y_tmp <= to_signed(62, 36) WHEN x_signed < to_signed(62, 36) ELSE
      x_signed;

  y_y <= std_logic_vector(y_tmp);

END rtl;

