# HDL Coder Downstream Integration Tcl Script

set myTool "Xilinx Vivado 2022.2"
set myProject "HDL_LTE_MIB_Recovery_vivado"
set myProjectFile "HDL_LTE_MIB_Recovery_vivado.xpr"
set myTopLevelEntity "HDL_LTE_MIB_Recovery"
set Family "Zynq UltraScale+"
set Device "xazu5ev-sfvc784-1LV-i"
set Package ""
set Speed ""
set MapTimePathNumber "3"
set MapTimeAdvAnalysis "True"
set PARTimePathNumber "3"
set PARTimeAdvAnalysis "True"

if { ! [ file exists $myProjectFile ] } {
    # Create new project
    puts "### Create new $myTool project <a href=\"matlab:downstream.handle('Model','ltehdlMIBRecovery').openTargetTool;\">C:\\Users\\binhn\\Temp\\test_fpga\\MIB\\LTE\\G1_5\\vivado_prj\\HDL_LTE_MIB_Recovery_vivado.xpr</a>"
    create_project $myProject -force

} else {
    # Open existing project
    puts "### Open existing $myTool project <a href=\"matlab:downstream.handle('Model','ltehdlMIBRecovery').openTargetTool;\">C:\\Users\\binhn\\Temp\\test_fpga\\MIB\\LTE\\G1_5\\vivado_prj\\HDL_LTE_MIB_Recovery_vivado.xpr</a>"
    open_project ${myProject}

    # Remove Old HDL source files
    set files_to_delete [get_files]
      if { [llength $files_to_delete] > 0 } {
        remove_files [get_files]
      }

}

# Set project properties
puts "### Set $myTool project properties"
if { [string compare -nocase $Family "virtexu"] == 0 || [string compare -nocase $Family "kintexu"] == 0  || [string match -nocase "*ultrascale*" $Family] == 1 } {
     set_property PART $Device [current_project]
} else {
     set_property PART ${Device}${Package}${Speed} [current_project]
}

# Add HDL source files
puts "### Update $myTool project with HDL source files"
add_file \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_ltehdlChannelEqualizer_pac.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_MATLAB_Function.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_LFSR1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_LFSR2.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_SetFF.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_Gold_Sequence_Generator.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_LTE_Gold_Seq_upsampling.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_c_initGen.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_downsampling_seq2complex.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_trigger_cinit_load.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_cellRefGen.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_TxDivDecode.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_mod3HDL1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_addr_mapper.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_Complex_shift.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_InterpCalculation.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_SimpleDualPortRAM_generic.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_hEstInterpAndStore.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_Subsystem1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_SinglePortRAM_generic.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_Subsystem2.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_hEstInterpAndStore_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_mod3HDL.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_mod6HDL.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_hEstControl.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_chEst.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_Detect_Rise_Positive.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_rsBankSymbolCount.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_ltehdlChannelEqualizer.vhd} \
  
set_property library work_ltehdlChannelEqualizer [get_files { ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_ltehdlChannelEqualizer_pac.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_MATLAB_Function.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_LFSR1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_LFSR2.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_SetFF.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_Gold_Sequence_Generator.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_LTE_Gold_Seq_upsampling.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_c_initGen.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_downsampling_seq2complex.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_trigger_cinit_load.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_cellRefGen.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_TxDivDecode.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_mod3HDL1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_addr_mapper.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_Complex_shift.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_InterpCalculation.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_SimpleDualPortRAM_generic.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_hEstInterpAndStore.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_Subsystem1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_SinglePortRAM_generic.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_Subsystem2.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_hEstInterpAndStore_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_mod3HDL.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_mod6HDL.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_hEstControl.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_chEst.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_Detect_Rise_Positive.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_rsBankSymbolCount.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlChannelEqualizer/ltehdlChannelEqualizer_ltehdlChannelEqualizer.vhd}]
add_file \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Decimator.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolicPreAdd.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block2.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolicPreAdd_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Discrete_FIR_Filter.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_CIC_Compensation_Decimator.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Decimator_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_CIC_Filter.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_CIC_Gain_Comp.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Transient_Removal.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Decimation_Filters.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Edge_Detector.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_DitherGen.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SinLookUpTableGen.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_CosLookUpTableGen.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_WaveformGen.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_NCO_HDL_Optimized1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Frequency_Correction_16x.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_DitherGen_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SinLookUpTableGen_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_CosLookUpTableGen_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_WaveformGen_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_NCO_HDL_Optimized1_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Frequency_Correction_1x.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_AngleAtMaximum.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MovingAverage.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SlotAverage.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_CyclicPrefixCorrelator.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Quadrant_Mapper.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_CordicKernelMag.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Quadrant_Correction.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_HDL_CMA_core.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Rect2Polar.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FrequencyEstimation.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FFT_Shift.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_OFDM_Demod_Mask_Generator.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator2.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_2.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_2.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_TWDLROM_3_1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Complex3Multiply.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator3.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_3.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_3.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator4.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_4.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_4.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_TWDLROM_5_1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Complex3Multiply_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator5.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_5.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_5.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator6.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_6.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_6.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_TWDLROM_7_1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Complex3Multiply_block1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator7.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_7.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_7.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator8.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_8.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_8.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_TWDLROM_9_1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Complex3Multiply_block2.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator9.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_9.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_9.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator10.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_10.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_10.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_TWDLROM_11_1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Complex3Multiply_block3.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator11.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_11.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_1_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX2FFT_bitNatural.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FFT_HDL_Optimized.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_OFDM_Demodulation.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Detection_Status.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Output_Interfacing.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MagnitudeSquared.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MagnitudeSquared0.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MagnitudeSquared1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MagnitudeSquared2.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Synchronous_Enabled_128_Sample_Delay.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MovingAverage_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block3.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block4.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_D.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block2.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block5.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_D_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_PSSXCorr0.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block3.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block6.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block2.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block4.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block7.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block3.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_D_block1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block5.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block8.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block4.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_D_block2.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_PSSXCorr1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block6.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block9.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block5.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_block1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block7.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block10.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block6.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_D_block3.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block8.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block11.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block7.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_D_block4.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_PSSXCorr2.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_ThresholdPrescaling.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_StreamSyncronizer.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_ThresholdLimiter.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Correlators.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Max_Element.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Peak_Search.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Max_Peak_Searcher.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_PSS_Searcher.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Determine_Frame_Timing.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SinglePortRAM_generic.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_TWDLROM.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MINRESRX2FFT_CTRL.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MINRESRX2FFT_MEMORY.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MINRESRX2FFT_BTFSEL.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Complex4Multiply.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MINRESRX2_BUTTERFLY.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MINRESRX2FFT_MEMSEL.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MINRESRX2FFT_OUTMux.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FFT_HDL_Optimized_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SSS_Search_Controller.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Magnitude_Squared_0.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Magnitude_Squared_1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_ThresholdLimiter_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SSS_Dot_Product.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Find_Max_Correlation.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Find_Max_Correlation1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SSS_Correlation_Controller.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Max_Likelihood_SSS.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SSS_Searcher.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Stream_Syncronizer.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Sync_Signal_Search.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Transfer_Timing_Offset.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Start_Controller.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Subframe_Counter.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Timing_Offset_Mask_Generator1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod.vhd} \
  
set_property library work_ltehdlDownlinkSyncDemod [get_files { ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Decimator.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolicPreAdd.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block2.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolicPreAdd_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Discrete_FIR_Filter.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_CIC_Compensation_Decimator.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Decimator_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_CIC_Filter.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_CIC_Gain_Comp.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Transient_Removal.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Decimation_Filters.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Edge_Detector.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_DitherGen.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SinLookUpTableGen.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_CosLookUpTableGen.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_WaveformGen.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_NCO_HDL_Optimized1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Frequency_Correction_16x.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_DitherGen_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SinLookUpTableGen_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_CosLookUpTableGen_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_WaveformGen_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_NCO_HDL_Optimized1_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Frequency_Correction_1x.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_AngleAtMaximum.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MovingAverage.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SlotAverage.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_CyclicPrefixCorrelator.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Quadrant_Mapper.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_CordicKernelMag.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Quadrant_Correction.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_HDL_CMA_core.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Rect2Polar.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FrequencyEstimation.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FFT_Shift.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_OFDM_Demod_Mask_Generator.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator2.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_2.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_2.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_TWDLROM_3_1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Complex3Multiply.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator3.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_3.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_3.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator4.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_4.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_4.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_TWDLROM_5_1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Complex3Multiply_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator5.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_5.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_5.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator6.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_6.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_6.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_TWDLROM_7_1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Complex3Multiply_block1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator7.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_7.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_7.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator8.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_8.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_8.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_TWDLROM_9_1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Complex3Multiply_block2.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator9.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_9.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_9.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator10.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_10.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_10.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_TWDLROM_11_1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Complex3Multiply_block3.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SDFCommutator11.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_11.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_1_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_RADIX2FFT_bitNatural.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FFT_HDL_Optimized.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_OFDM_Demodulation.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Detection_Status.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Output_Interfacing.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MagnitudeSquared.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MagnitudeSquared0.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MagnitudeSquared1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MagnitudeSquared2.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Synchronous_Enabled_128_Sample_Delay.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MovingAverage_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block3.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block4.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_D.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block2.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block5.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_D_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_PSSXCorr0.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block3.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block6.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block2.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block4.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block7.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block3.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_D_block1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block5.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block8.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block4.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_D_block2.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_PSSXCorr1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block6.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block9.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block5.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_block1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block7.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block10.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block6.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_D_block3.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FirRdyLogic_block8.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block11.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FilterTapSystolic_block7.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_C_D_block4.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_PSSXCorr2.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_ThresholdPrescaling.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_StreamSyncronizer.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_ThresholdLimiter.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Correlators.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Max_Element.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Peak_Search.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Max_Peak_Searcher.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_PSS_Searcher.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Determine_Frame_Timing.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SinglePortRAM_generic.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_TWDLROM.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MINRESRX2FFT_CTRL.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MINRESRX2FFT_MEMORY.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MINRESRX2FFT_BTFSEL.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Complex4Multiply.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MINRESRX2_BUTTERFLY.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MINRESRX2FFT_MEMSEL.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_MINRESRX2FFT_OUTMux.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_FFT_HDL_Optimized_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SSS_Search_Controller.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Magnitude_Squared_0.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Magnitude_Squared_1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_ThresholdLimiter_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SSS_Dot_Product.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Find_Max_Correlation.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Find_Max_Correlation1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SSS_Correlation_Controller.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Max_Likelihood_SSS.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_SSS_Searcher.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Stream_Syncronizer.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Sync_Signal_Search.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Transfer_Timing_Offset.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Start_Controller.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Subframe_Counter.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_Timing_Offset_Mask_Generator1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlDownlinkSyncDemod/ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod.vhd}]
add_file \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_MIB_Interpretation.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_SimpleDualPortRAM_generic.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_PBCH_Controller.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_MATLAB_Function.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_LFSR1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_LFSR2.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_SetFF.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Gold_Sequence_Generator.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_PBCH_Descrambling.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_rateRecovery.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_PBCH_Rate_Recovery.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_BCHControllerCore.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_MIB_Data_Buffer.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_BCH_Controller.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Sample_Control_Bus_Creator.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_controlbusGen.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Rounding_Symmetric_Saturation.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Sign_Extend_by_2.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Apply_Scaling.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Determine_Scaling.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Maximum_Average_Absolute_Value.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_MemoryController.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Symmetric_Saturation.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_SinglePortRAM_generic.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_softBitScalingUnit.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_SinglePortRAM_generic_block.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_ConvolutionalDecoderMessageExtender.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_ConvolutionalDecoderMetricComputer.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_SimpleDualPortRAM_singlebit.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_ConvolutionalDecoderTracebackUnit.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Convolutional_Decoder.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_endInNet.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_CRCGenControl.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_CRCGenCompute.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_CRCGenerator.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_CRCCompNet.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_CRC_Decoder.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_BCH_Decoder.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_repeatQPSKPulseResync.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_restartMIBPulseResync.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_MIBDetectedPulseResync.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_ltehdlPBCHDecoder.vhd} \
  
set_property library work_ltehdlPBCHDecoder [get_files { ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_ltehdlPBCHDecoder_pac.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_MIB_Interpretation.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_SimpleDualPortRAM_generic.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_PBCH_Controller.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_MATLAB_Function.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_LFSR1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_LFSR2.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_SetFF.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Gold_Sequence_Generator.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_PBCH_Descrambling.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_rateRecovery.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_PBCH_Rate_Recovery.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_BCHControllerCore.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_MIB_Data_Buffer.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_BCH_Controller.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Sample_Control_Bus_Creator.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_controlbusGen.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Rounding_Symmetric_Saturation.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Sign_Extend_by_2.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Apply_Scaling.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Determine_Scaling.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Maximum_Average_Absolute_Value.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_MemoryController.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Symmetric_Saturation.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_SinglePortRAM_generic.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_softBitScalingUnit.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_SinglePortRAM_generic_block.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_ConvolutionalDecoderMessageExtender.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_ConvolutionalDecoderMetricComputer.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_SimpleDualPortRAM_singlebit.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_ConvolutionalDecoderTracebackUnit.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_Convolutional_Decoder.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_endInNet.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_CRCGenControl.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_CRCGenCompute.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_CRCGenerator.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_CRCCompNet.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_CRC_Decoder.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_BCH_Decoder.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_repeatQPSKPulseResync.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_restartMIBPulseResync.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_MIBDetectedPulseResync.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHDecoder/ltehdlPBCHDecoder_ltehdlPBCHDecoder.vhd}]
add_file \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_ltehdlPBCHIndexing_pac.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_Enabled_Subsystem.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_enbGen.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_mod3HDL1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_PBCHIndGen.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_mod_12_6.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_ltehdlPBCHIndexing.vhd} \
  
set_property library work_ltehdlPBCHIndexing [get_files { ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_ltehdlPBCHIndexing_pac.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_Enabled_Subsystem.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_enbGen.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_mod3HDL1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_PBCHIndGen.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_mod_12_6.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlPBCHIndexing/ltehdlPBCHIndexing_ltehdlPBCHIndexing.vhd}]
add_file \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_ltehdlResourceGrid_pac.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_repeat.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_repeat1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_repeat2.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_SimpleDualPortRAM_generic.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_Memory_Bank.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_MATLAB_Function.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_gridBankSelect.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_Grid_Memory_Bank.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_Detect_Rise_Positive.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_wr_en_calculator.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_LTE_Memory_Bank_Write_Controller.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_MemoryBank_Write_Controller.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_lst2hw.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_mod3cellID.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_rsOutputGen.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_ltehdlResourceGrid.vhd} \
  
set_property library work_ltehdlResourceGrid [get_files { ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_ltehdlResourceGrid_pac.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_repeat.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_repeat1.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_repeat2.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_SimpleDualPortRAM_generic.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_Memory_Bank.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_MATLAB_Function.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_gridBankSelect.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_Grid_Memory_Bank.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_Detect_Rise_Positive.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_wr_en_calculator.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_LTE_Memory_Bank_Write_Controller.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_MemoryBank_Write_Controller.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_lst2hw.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_mod3cellID.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_rsOutputGen.vhd ../hdlsrc/ltehdlMIBRecovery/ltehdlResourceGrid/ltehdlResourceGrid_ltehdlResourceGrid.vhd}]
add_file \
    {../hdlsrc/ltehdlMIBRecovery/HDL_LTE_MIB_Recovery_tc.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/Detect_Rise_Positive.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/Detect_Rise_Positive1.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/MIB_Decoder.vhd} \
    {../hdlsrc/ltehdlMIBRecovery/HDL_LTE_MIB_Recovery.vhd} \
{../hdlsrc/ltehdlMIBRecovery/clock_constraint.xdc} \
  
update_compile_order -fileset sources_1
foreach fs [get_files *.tcl] {
source $fs
}

set_property {STEPS.SYNTH_DESIGN.ARGS.MORE OPTIONS} -value {-mode out_of_context} -objects [get_runs synth_1]
# Close project
puts "### Close $myTool project."
close_project

