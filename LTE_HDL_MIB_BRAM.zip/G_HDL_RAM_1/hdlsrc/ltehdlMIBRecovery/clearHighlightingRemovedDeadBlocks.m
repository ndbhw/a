SLStudio.Utils.RemoveHighlighting(get_param('ltehdlDownlinkSyncDemod','Handle'));
