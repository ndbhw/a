-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlChannelEqualizer;

ENTITY ltehdlChannelEqualizer_hEstInterpAndStore_block IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        rsData_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        rsData_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        addr                              :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        wrtA0                             :   IN    std_logic;
        wrtA1                             :   IN    std_logic;
        doAverage                         :   IN    std_logic;
        isFirstRS                         :   IN    std_logic;
        isLastRS                          :   IN    std_logic;
        doInterp                          :   IN    std_logic;
        addrBias                          :   IN    std_logic_vector(1 DOWNTO 0);  -- ufix2
        readAddress                       :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
        readEnable                        :   IN    std_logic;
        hEst_a0_re                        :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        hEst_a0_im                        :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        hEst_a1_re                        :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        hEst_a1_im                        :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        hEstValid                         :   OUT   std_logic
        );
END ltehdlChannelEqualizer_hEstInterpAndStore_block;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_hEstInterpAndStore_block IS

  -- Component Declarations
  COMPONENT ltehdlChannelEqualizer_Subsystem1
    PORT( previous_re                     :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          previous_im                     :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          current_re                      :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En16
          current_im                      :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En16
          doAverage                       :   IN    std_logic;
          average_re                      :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          average_im                      :   OUT   std_logic_vector(16 DOWNTO 0)  -- sfix17_En16
          );
  END COMPONENT;

  COMPONENT ltehdlChannelEqualizer_SinglePortRAM_generic
    GENERIC( AddrWidth                    : integer;
             DataWidth                    : integer
             );
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          din_re                          :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          din_im                          :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          addr                            :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          we                              :   IN    std_logic;
          dout_re                         :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          dout_im                         :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0)  -- generic width
          );
  END COMPONENT;

  COMPONENT ltehdlChannelEqualizer_Subsystem2
    PORT( previous_re                     :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          previous_im                     :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          current_re                      :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En16
          current_im                      :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En16
          doAverage                       :   IN    std_logic;
          average_re                      :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          average_im                      :   OUT   std_logic_vector(16 DOWNTO 0)  -- sfix17_En16
          );
  END COMPONENT;

  COMPONENT ltehdlChannelEqualizer_addr_mapper
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          addrBias                        :   IN    std_logic_vector(1 DOWNTO 0);  -- ufix2
          address                         :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
          enable                          :   IN    std_logic;
          memory_addr                     :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
          memory_num                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- uint16
          enOut                           :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlChannelEqualizer_hEstInterpAndStore
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dataIn_re_0                     :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dataIn_re_1                     :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dataIn_im_0                     :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dataIn_im_1                     :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          ramAddr                         :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          doInterp                        :   IN    std_logic;
          isFirstRS                       :   IN    std_logic;
          isLastRS                        :   IN    std_logic;
          rdAddr                          :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          addrBank                        :   IN    std_logic_vector(15 DOWNTO 0);  -- uint16
          rdEn                            :   IN    std_logic;
          hEst_re_0                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          hEst_re_1                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          hEst_im_0                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          hEst_im_1                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          Out2                            :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlChannelEqualizer_Subsystem1
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_Subsystem1(rtl);

  FOR ALL : ltehdlChannelEqualizer_SinglePortRAM_generic
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_SinglePortRAM_generic(rtl);

  FOR ALL : ltehdlChannelEqualizer_Subsystem2
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_Subsystem2(rtl);

  FOR ALL : ltehdlChannelEqualizer_addr_mapper
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_addr_mapper(rtl);

  FOR ALL : ltehdlChannelEqualizer_hEstInterpAndStore
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_hEstInterpAndStore(rtl);

  -- Signals
  SIGNAL a0_en                            : std_logic;
  SIGNAL a1_en                            : std_logic;
  SIGNAL rsData_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL rsData_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Multiply_cast                    : signed(31 DOWNTO 0);  -- sfix32_En30
  SIGNAL Multiply_cast_1                  : signed(31 DOWNTO 0);  -- sfix32_En30
  SIGNAL Multiply_out1_re                 : signed(15 DOWNTO 0);  -- sfix16_En16
  SIGNAL Multiply_out1_im                 : signed(15 DOWNTO 0);  -- sfix16_En16
  SIGNAL Delay8_out1                      : std_logic := '0';
  SIGNAL ant0ram_out1_re                  : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL ant0ram_out1_im                  : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL Subsystem1_average_re            : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL Subsystem1_average_im            : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL Delay9_out1                      : std_logic := '0';
  SIGNAL ant1ram_out1_re                  : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL ant1ram_out1_im                  : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL Subsystem2_average_re            : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL Subsystem2_average_im            : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL addr_unsigned                    : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Delay6_out1                      : unsigned(8 DOWNTO 0) := to_unsigned(16#000#, 9);  -- ufix9
  SIGNAL Delay5_out1                      : std_logic := '0';
  SIGNAL Delay4_out1                      : std_logic := '0';
  SIGNAL Delay12_out1                     : std_logic := '0';
  SIGNAL addr_mapper_memory_addr          : std_logic_vector(8 DOWNTO 0);  -- ufix9
  SIGNAL addr_mapper_memory_num           : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL addr_mapper_enOut                : std_logic;
  SIGNAL hEstInterpAndStore_hEst_re_0     : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL hEstInterpAndStore_hEst_re_1     : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL hEstInterpAndStore_hEst_im_0     : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL hEstInterpAndStore_hEst_im_1     : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL hEstInterpAndStore_Out2          : std_logic;
  SIGNAL hEstInterpAndStore_hEst_re_0_signed : signed(16 DOWNTO 0);  -- sfix17_En16
  SIGNAL hEstInterpAndStore_hEst_im_0_signed : signed(16 DOWNTO 0);  -- sfix17_En16
  SIGNAL Delay1_out1_re                   : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL Delay1_out1_im                   : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL Delay7_out1_re                   : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL Delay7_out1_im                   : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL hEstInterpAndStore_hEst_re_1_signed : signed(16 DOWNTO 0);  -- sfix17_En16
  SIGNAL hEstInterpAndStore_hEst_im_1_signed : signed(16 DOWNTO 0);  -- sfix17_En16
  SIGNAL Delay3_out1_re                   : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL Delay3_out1_im                   : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL Delay11_out1_re                  : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL Delay11_out1_im                  : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL Delay2_out1                      : std_logic := '0';
  SIGNAL Delay10_out1                     : std_logic := '0';

BEGIN
  -- Averaging two values
  USubsystem1 : ltehdlChannelEqualizer_Subsystem1
    PORT MAP( previous_re => ant0ram_out1_re,  -- sfix17_En16
              previous_im => ant0ram_out1_im,  -- sfix17_En16
              current_re => std_logic_vector(Multiply_out1_re),  -- sfix16_En16
              current_im => std_logic_vector(Multiply_out1_im),  -- sfix16_En16
              doAverage => doAverage,
              average_re => Subsystem1_average_re,  -- sfix17_En16
              average_im => Subsystem1_average_im  -- sfix17_En16
              );

  Uant0ram : ltehdlChannelEqualizer_SinglePortRAM_generic
    GENERIC MAP( AddrWidth => 9,
                 DataWidth => 17
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              din_re => Subsystem1_average_re,
              din_im => Subsystem1_average_im,
              addr => addr,
              we => Delay8_out1,
              dout_re => ant0ram_out1_re,
              dout_im => ant0ram_out1_im
              );

  -- Averaging two values
  USubsystem2 : ltehdlChannelEqualizer_Subsystem2
    PORT MAP( previous_re => ant1ram_out1_re,  -- sfix17_En16
              previous_im => ant1ram_out1_im,  -- sfix17_En16
              current_re => std_logic_vector(Multiply_out1_re),  -- sfix16_En16
              current_im => std_logic_vector(Multiply_out1_im),  -- sfix16_En16
              doAverage => doAverage,
              average_re => Subsystem2_average_re,  -- sfix17_En16
              average_im => Subsystem2_average_im  -- sfix17_En16
              );

  Uant1ram : ltehdlChannelEqualizer_SinglePortRAM_generic
    GENERIC MAP( AddrWidth => 9,
                 DataWidth => 17
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              din_re => Subsystem2_average_re,
              din_im => Subsystem2_average_im,
              addr => addr,
              we => Delay9_out1,
              dout_re => ant1ram_out1_re,
              dout_im => ant1ram_out1_im
              );

  Uaddr_mapper : ltehdlChannelEqualizer_addr_mapper
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              addrBias => addrBias,  -- ufix2
              address => readAddress,  -- ufix11
              enable => readEnable,
              memory_addr => addr_mapper_memory_addr,  -- ufix9
              memory_num => addr_mapper_memory_num,  -- uint16
              enOut => addr_mapper_enOut
              );

  UhEstInterpAndStore : ltehdlChannelEqualizer_hEstInterpAndStore
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dataIn_re_0 => ant0ram_out1_re,  -- sfix17_En16
              dataIn_re_1 => ant1ram_out1_re,  -- sfix17_En16
              dataIn_im_0 => ant0ram_out1_im,  -- sfix17_En16
              dataIn_im_1 => ant1ram_out1_im,  -- sfix17_En16
              ramAddr => std_logic_vector(Delay6_out1),  -- ufix9
              doInterp => Delay5_out1,
              isFirstRS => Delay4_out1,
              isLastRS => Delay12_out1,
              rdAddr => addr_mapper_memory_addr,  -- ufix9
              addrBank => addr_mapper_memory_num,  -- uint16
              rdEn => addr_mapper_enOut,
              hEst_re_0 => hEstInterpAndStore_hEst_re_0,  -- sfix17_En16
              hEst_re_1 => hEstInterpAndStore_hEst_re_1,  -- sfix17_En16
              hEst_im_0 => hEstInterpAndStore_hEst_im_0,  -- sfix17_En16
              hEst_im_1 => hEstInterpAndStore_hEst_im_1,  -- sfix17_En16
              Out2 => hEstInterpAndStore_Out2
              );

  a0_en <= wrtA0;

  a1_en <= wrtA1;

  rsData_re_signed <= signed(rsData_re);

  rsData_im_signed <= signed(rsData_im);

  -- Averaging two values
  Multiply_cast <= resize(rsData_re_signed & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 32);
  Multiply_out1_re <= Multiply_cast(29 DOWNTO 14);
  Multiply_cast_1 <= resize(rsData_im_signed & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 32);
  Multiply_out1_im <= Multiply_cast_1(29 DOWNTO 14);

  Delay8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay8_out1 <= a0_en;
      END IF;
    END IF;
  END PROCESS Delay8_process;


  Delay9_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay9_out1 <= a1_en;
      END IF;
    END IF;
  END PROCESS Delay9_process;


  addr_unsigned <= unsigned(addr);

  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay6_out1 <= addr_unsigned;
      END IF;
    END IF;
  END PROCESS Delay6_process;


  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay5_out1 <= doInterp;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay4_out1 <= isFirstRS;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  Delay12_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay12_out1 <= isLastRS;
      END IF;
    END IF;
  END PROCESS Delay12_process;


  hEstInterpAndStore_hEst_re_0_signed <= signed(hEstInterpAndStore_hEst_re_0);

  hEstInterpAndStore_hEst_im_0_signed <= signed(hEstInterpAndStore_hEst_im_0);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_out1_re <= hEstInterpAndStore_hEst_re_0_signed;
        Delay1_out1_im <= hEstInterpAndStore_hEst_im_0_signed;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  Delay7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay7_out1_re <= Delay1_out1_re;
        Delay7_out1_im <= Delay1_out1_im;
      END IF;
    END IF;
  END PROCESS Delay7_process;


  hEst_a0_re <= std_logic_vector(Delay7_out1_re);

  hEst_a0_im <= std_logic_vector(Delay7_out1_im);

  hEstInterpAndStore_hEst_re_1_signed <= signed(hEstInterpAndStore_hEst_re_1);

  hEstInterpAndStore_hEst_im_1_signed <= signed(hEstInterpAndStore_hEst_im_1);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay3_out1_re <= hEstInterpAndStore_hEst_re_1_signed;
        Delay3_out1_im <= hEstInterpAndStore_hEst_im_1_signed;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  Delay11_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay11_out1_re <= Delay3_out1_re;
        Delay11_out1_im <= Delay3_out1_im;
      END IF;
    END IF;
  END PROCESS Delay11_process;


  hEst_a1_re <= std_logic_vector(Delay11_out1_re);

  hEst_a1_im <= std_logic_vector(Delay11_out1_im);

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay2_out1 <= hEstInterpAndStore_Out2;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  Delay10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay10_out1 <= Delay2_out1;
      END IF;
    END IF;
  END PROCESS Delay10_process;


  hEstValid <= Delay10_out1;

END rtl;

