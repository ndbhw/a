-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlChannelEqualizer_TxDivDecode IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        -- Received Symbols
        gridData_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        gridData_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        -- 1st channel estimate, h1
        A_re                              :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        A_im                              :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        -- 2nd channel estimate, h2
        B_re                              :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        B_im                              :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dataValid                         :   IN    std_logic;
        resetCount                        :   IN    std_logic;
        S_re                              :   OUT   std_logic_vector(17 DOWNTO 0);  -- sfix18_En17
        S_im                              :   OUT   std_logic_vector(17 DOWNTO 0);  -- sfix18_En17
        SValid                            :   OUT   std_logic
        );
END ltehdlChannelEqualizer_TxDivDecode;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_TxDivDecode IS

  -- Signals
  SIGNAL eqInValid                        : std_logic;
  SIGNAL Delay6_out1                      : std_logic := '0';
  SIGNAL Delay14_out1                     : std_logic := '0';
  SIGNAL n_n                              : std_logic := '0';  -- ufix1
  SIGNAL count                            : std_logic;  -- ufix1
  SIGNAL count_1                          : std_logic;  -- ufix1
  SIGNAL count_2                          : std_logic;  -- ufix1
  SIGNAL Delay15_out1                     : std_logic := '0';  -- ufix1
  SIGNAL Delay4_out1                      : std_logic := '0';  -- ufix1
  SIGNAL A_re_signed                      : signed(16 DOWNTO 0);  -- sfix17_En16
  SIGNAL A_im_signed                      : signed(16 DOWNTO 0);  -- sfix17_En16
  SIGNAL conj_cast                        : signed(17 DOWNTO 0);  -- sfix18_En16
  SIGNAL Conjugate1_out1_re               : signed(16 DOWNTO 0);  -- sfix17_En16
  SIGNAL Conjugate1_out1_im               : signed(16 DOWNTO 0);  -- sfix17_En16
  SIGNAL Delay8_out1_re                   : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL Delay8_out1_im                   : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL gridData_re_signed               : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL gridData_im_signed               : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay9_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay9_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Product3_mul_temp                : signed(32 DOWNTO 0);  -- sfix33_En31
  SIGNAL Product3_mul_temp_1              : signed(32 DOWNTO 0);  -- sfix33_En31
  SIGNAL Product3_mul_temp_2              : signed(32 DOWNTO 0);  -- sfix33_En31
  SIGNAL Product3_mul_temp_3              : signed(32 DOWNTO 0);  -- sfix33_En31
  SIGNAL m0_re                            : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL m0_im                            : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Delay12_out1_re                  : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En17
  SIGNAL Delay12_out1_im                  : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En17
  SIGNAL Delay5_out1_re                   : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En17
  SIGNAL Delay5_out1_im                   : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En17
  SIGNAL B_re_signed                      : signed(16 DOWNTO 0);  -- sfix17_En16
  SIGNAL B_im_signed                      : signed(16 DOWNTO 0);  -- sfix17_En16
  SIGNAL Delay10_out1_re                  : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL Delay10_out1_im                  : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL conj_cast_1                      : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL Conjugate5_out1_re               : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Conjugate5_out1_im               : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay11_out1_re                  : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay11_out1_im                  : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Product1_mul_temp                : signed(32 DOWNTO 0);  -- sfix33_En31
  SIGNAL Product1_mul_temp_1              : signed(32 DOWNTO 0);  -- sfix33_En31
  SIGNAL Product1_mul_temp_2              : signed(32 DOWNTO 0);  -- sfix33_En31
  SIGNAL Product1_mul_temp_3              : signed(32 DOWNTO 0);  -- sfix33_En31
  SIGNAL m1_re                            : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL m1_im                            : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Delay13_out1_re                  : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En17
  SIGNAL Delay13_out1_im                  : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En17
  SIGNAL S_2n_re                          : signed(18 DOWNTO 0);  -- sfix19_En17
  SIGNAL S_2n_im                          : signed(18 DOWNTO 0);  -- sfix19_En17
  SIGNAL Delay16_out1_re                  : signed(18 DOWNTO 0) := to_signed(16#00000#, 19);  -- sfix19_En17
  SIGNAL Delay16_out1_im                  : signed(18 DOWNTO 0) := to_signed(16#00000#, 19);  -- sfix19_En17
  SIGNAL Gain_cast                        : signed(37 DOWNTO 0);  -- sfix38_En35
  SIGNAL Gain_cast_1                      : signed(37 DOWNTO 0);  -- sfix38_En35
  SIGNAL Gain_out1_re                     : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Gain_out1_im                     : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Delay3_out1_re                   : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En17
  SIGNAL Delay3_out1_im                   : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En17
  SIGNAL Sub_out1_re                      : signed(18 DOWNTO 0);  -- sfix19_En17
  SIGNAL Sub_out1_im                      : signed(18 DOWNTO 0);  -- sfix19_En17
  SIGNAL Delay17_out1_re                  : signed(18 DOWNTO 0) := to_signed(16#00000#, 19);  -- sfix19_En17
  SIGNAL Delay17_out1_im                  : signed(18 DOWNTO 0) := to_signed(16#00000#, 19);  -- sfix19_En17
  SIGNAL S_2n_1_re                        : signed(18 DOWNTO 0) := to_signed(16#00000#, 19);  -- sfix19_En17
  SIGNAL S_2n_1_im                        : signed(18 DOWNTO 0) := to_signed(16#00000#, 19);  -- sfix19_En17
  SIGNAL Gain1_cast                       : signed(37 DOWNTO 0);  -- sfix38_En35
  SIGNAL Gain1_cast_1                     : signed(37 DOWNTO 0);  -- sfix38_En35
  SIGNAL Gain1_out1_re                    : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Gain1_out1_im                    : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Multiport_Switch_out1_re         : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Multiport_Switch_out1_im         : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Delay18_out1_re                  : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En17
  SIGNAL Delay18_out1_im                  : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En17
  SIGNAL Delay7_out1                      : std_logic := '0';
  SIGNAL Delay1_out1                      : std_logic := '0';
  SIGNAL Delay19_out1                     : std_logic := '0';

BEGIN
  eqInValid <= dataValid;

  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay6_out1 <= eqInValid;
      END IF;
    END IF;
  END PROCESS Delay6_process;


  Delay14_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay14_out1 <= Delay6_out1;
      END IF;
    END IF;
  END PROCESS Delay14_process;


  -- 1-bit counter to toggle on odd and even bits
  -- 1-bit counter to toggle on odd and even bits
  -- Free running, Unsigned Counter
  --  initial value   = 0
  --  step value      = 1
  -- 1-bit counter to toggle on odd and even bits
  -- 1-bit counter to toggle on odd and even bits
  count <= n_n XOR '1';

  -- 1-bit counter to toggle on odd and even bits
  
  count_1 <= n_n WHEN Delay14_out1 = '0' ELSE
      count;

  -- 1-bit counter to toggle on odd and even bits
  -- 1-bit counter to toggle on odd and even bits
  
  count_2 <= count_1 WHEN resetCount = '0' ELSE
      '0';

  -- 1-bit counter to toggle on odd and even bits
  HDL_Counter_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        n_n <= count_2;
      END IF;
    END IF;
  END PROCESS HDL_Counter_process;


  Delay15_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay15_out1 <= n_n;
      END IF;
    END IF;
  END PROCESS Delay15_process;


  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay4_out1 <= Delay15_out1;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  A_re_signed <= signed(A_re);

  A_im_signed <= signed(A_im);

  Conjugate1_out1_re <= A_re_signed;
  conj_cast <=  - (resize(A_im_signed, 18));
  
  Conjugate1_out1_im <= "01111111111111111" WHEN (conj_cast(17) = '0') AND (conj_cast(16) /= '0') ELSE
      "10000000000000000" WHEN (conj_cast(17) = '1') AND (conj_cast(16) /= '1') ELSE
      conj_cast(16 DOWNTO 0);

  Delay8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay8_out1_re <= Conjugate1_out1_re;
        Delay8_out1_im <= Conjugate1_out1_im;
      END IF;
    END IF;
  END PROCESS Delay8_process;


  gridData_re_signed <= signed(gridData_re);

  gridData_im_signed <= signed(gridData_im);

  Delay9_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay9_out1_re <= gridData_re_signed;
        Delay9_out1_im <= gridData_im_signed;
      END IF;
    END IF;
  END PROCESS Delay9_process;


  -- A*.R
  Product3_mul_temp <= Delay8_out1_re * Delay9_out1_re;
  Product3_mul_temp_1 <= Delay8_out1_im * Delay9_out1_im;
  m0_re <= Product3_mul_temp(31 DOWNTO 14) - Product3_mul_temp_1(31 DOWNTO 14);
  Product3_mul_temp_2 <= Delay8_out1_im * Delay9_out1_re;
  Product3_mul_temp_3 <= Delay8_out1_re * Delay9_out1_im;
  m0_im <= Product3_mul_temp_2(31 DOWNTO 14) + Product3_mul_temp_3(31 DOWNTO 14);

  Delay12_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay12_out1_re <= m0_re;
        Delay12_out1_im <= m0_im;
      END IF;
    END IF;
  END PROCESS Delay12_process;


  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay5_out1_re <= Delay12_out1_re;
        Delay5_out1_im <= Delay12_out1_im;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  B_re_signed <= signed(B_re);

  B_im_signed <= signed(B_im);

  Delay10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay10_out1_re <= B_re_signed;
        Delay10_out1_im <= B_im_signed;
      END IF;
    END IF;
  END PROCESS Delay10_process;


  Conjugate5_out1_re <= gridData_re_signed;
  conj_cast_1 <=  - (resize(gridData_im_signed, 17));
  
  Conjugate5_out1_im <= X"7FFF" WHEN (conj_cast_1(16) = '0') AND (conj_cast_1(15) /= '0') ELSE
      X"8000" WHEN (conj_cast_1(16) = '1') AND (conj_cast_1(15) /= '1') ELSE
      conj_cast_1(15 DOWNTO 0);

  Delay11_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay11_out1_re <= Conjugate5_out1_re;
        Delay11_out1_im <= Conjugate5_out1_im;
      END IF;
    END IF;
  END PROCESS Delay11_process;


  -- B.R*
  Product1_mul_temp <= Delay10_out1_re * Delay11_out1_re;
  Product1_mul_temp_1 <= Delay10_out1_im * Delay11_out1_im;
  m1_re <= Product1_mul_temp(31 DOWNTO 14) - Product1_mul_temp_1(31 DOWNTO 14);
  Product1_mul_temp_2 <= Delay10_out1_im * Delay11_out1_re;
  Product1_mul_temp_3 <= Delay10_out1_re * Delay11_out1_im;
  m1_im <= Product1_mul_temp_2(31 DOWNTO 14) + Product1_mul_temp_3(31 DOWNTO 14);

  Delay13_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay13_out1_re <= m1_re;
        Delay13_out1_im <= m1_im;
      END IF;
    END IF;
  END PROCESS Delay13_process;


  -- delay(A*.R) + B.R*
  S_2n_re <= (resize(Delay5_out1_re, 19)) + (resize(Delay13_out1_re, 19));
  S_2n_im <= (resize(Delay5_out1_im, 19)) + (resize(Delay13_out1_im, 19));

  Delay16_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay16_out1_re <= S_2n_re;
        Delay16_out1_im <= S_2n_im;
      END IF;
    END IF;
  END PROCESS Delay16_process;


  -- Scale to keep output in +/-1 range
  Gain_cast <= resize(Delay16_out1_re & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 38);
  Gain_out1_re <= Gain_cast(35 DOWNTO 18);
  Gain_cast_1 <= resize(Delay16_out1_im & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 38);
  Gain_out1_im <= Gain_cast_1(35 DOWNTO 18);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay3_out1_re <= Delay13_out1_re;
        Delay3_out1_im <= Delay13_out1_im;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  -- A*.R - delay(B.R*)
  Sub_out1_re <= (resize(Delay12_out1_re, 19)) - (resize(Delay3_out1_re, 19));
  Sub_out1_im <= (resize(Delay12_out1_im, 19)) - (resize(Delay3_out1_im, 19));

  Delay17_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay17_out1_re <= Sub_out1_re;
        Delay17_out1_im <= Sub_out1_im;
      END IF;
    END IF;
  END PROCESS Delay17_process;


  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        S_2n_1_re <= Delay17_out1_re;
        S_2n_1_im <= Delay17_out1_im;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  -- Scale to keep output in +/-1 range
  Gain1_cast <= resize(S_2n_1_re & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 38);
  Gain1_out1_re <= Gain1_cast(35 DOWNTO 18);
  Gain1_cast_1 <= resize(S_2n_1_im & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 38);
  Gain1_out1_im <= Gain1_cast_1(35 DOWNTO 18);

  -- toggle on 'n'
  
  Multiport_Switch_out1_re <= Gain_out1_re WHEN Delay4_out1 = '0' ELSE
      Gain1_out1_re;
  
  Multiport_Switch_out1_im <= Gain_out1_im WHEN Delay4_out1 = '0' ELSE
      Gain1_out1_im;

  Delay18_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay18_out1_re <= Multiport_Switch_out1_re;
        Delay18_out1_im <= Multiport_Switch_out1_im;
      END IF;
    END IF;
  END PROCESS Delay18_process;


  S_re <= std_logic_vector(Delay18_out1_re);

  S_im <= std_logic_vector(Delay18_out1_im);

  Delay7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay7_out1 <= Delay14_out1;
      END IF;
    END IF;
  END PROCESS Delay7_process;


  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_out1 <= Delay7_out1;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  Delay19_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay19_out1 <= Delay1_out1;
      END IF;
    END IF;
  END PROCESS Delay19_process;


  SValid <= Delay19_out1;

END rtl;

