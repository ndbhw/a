-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlChannelEqualizer;
USE work.ltehdlChannelEqualizer_ltehdlChannelEqualizer_pac.ALL;

ENTITY ltehdlChannelEqualizer_ltehdlChannelEqualizer IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        enb_1_2_1                         :   IN    std_logic;
        cellDetected                      :   IN    std_logic;
        NCellID                           :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        NSubframe                         :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        NDLRB                             :   IN    std_logic_vector(6 DOWNTO 0);  -- ufix7
        gridData_gridData_re              :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        gridData_gridData_im              :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        gridData_gridDataValid            :   IN    std_logic;
        hestRdAddr                        :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
        gridWriteDone                     :   IN    std_logic;
        eqSymbols_eqSymbols_re            :   OUT   std_logic_vector(17 DOWNTO 0);  -- ufix18
        eqSymbols_eqSymbols_im            :   OUT   std_logic_vector(17 DOWNTO 0);  -- ufix18
        eqSymbols_eqSymbolsValid          :   OUT   std_logic
        );
END ltehdlChannelEqualizer_ltehdlChannelEqualizer;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_ltehdlChannelEqualizer IS

  -- Component Declarations
  COMPONENT ltehdlChannelEqualizer_rsBankSymbolCount
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          rsValid                         :   IN    std_logic;
          reset                           :   IN    std_logic;
          rsBank                          :   OUT   std_logic_vector(3 DOWNTO 0);  -- ufix4
          rsCount                         :   OUT   std_logic_vector(8 DOWNTO 0)  -- ufix9
          );
  END COMPONENT;

  COMPONENT ltehdlChannelEqualizer_cellRefGen
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          enb_1_2_1                       :   IN    std_logic;
          Nsubframe                       :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          ofdmSymb                        :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          NcellID                         :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          enGold                          :   IN    std_logic;
          cellDetected                    :   IN    std_logic;
          cellRef_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          cellRef_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          outValid                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlChannelEqualizer_chEst
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          rxRS_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          rxRS_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          refRS_re                        :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          refRS_im                        :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          rsValid                         :   IN    std_logic;
          rsbank                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          rscount                         :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          cellID                          :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          ndlrb                           :   IN    std_logic_vector(6 DOWNTO 0);  -- ufix7
          hestRdAddr                      :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
          hestRdEnable                    :   IN    std_logic;
          reset                           :   IN    std_logic;
          hEst_a0_re                      :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          hEst_a0_im                      :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          hEst_a1_re                      :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          hEst_a1_im                      :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          hEstValid                       :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlChannelEqualizer_TxDivDecode
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          gridData_re                     :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          gridData_im                     :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          A_re                            :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          A_im                            :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          B_re                            :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          B_im                            :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dataValid                       :   IN    std_logic;
          resetCount                      :   IN    std_logic;
          S_re                            :   OUT   std_logic_vector(17 DOWNTO 0);  -- sfix18_En17
          S_im                            :   OUT   std_logic_vector(17 DOWNTO 0);  -- sfix18_En17
          SValid                          :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlChannelEqualizer_rsBankSymbolCount
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_rsBankSymbolCount(rtl);

  FOR ALL : ltehdlChannelEqualizer_cellRefGen
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_cellRefGen(rtl);

  FOR ALL : ltehdlChannelEqualizer_chEst
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_chEst(rtl);

  FOR ALL : ltehdlChannelEqualizer_TxDivDecode
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_TxDivDecode(rtl);

  -- Signals
  SIGNAL gridData_re                      : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL gridData_im                      : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay12_reg_re                   : vector_of_signed16(0 TO 11) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16_En15 [12]
  SIGNAL Delay12_reg_im                   : vector_of_signed16(0 TO 11) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16_En15 [12]
  SIGNAL Delay12_out1_re                  : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay12_out1_im                  : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay7_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay7_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay2_reg_re                    : vector_of_signed16(0 TO 3) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16_En15 [4]
  SIGNAL Delay2_reg_im                    : vector_of_signed16(0 TO 3) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16_En15 [4]
  SIGNAL Delay2_out1_re                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay2_out1_im                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL gridDataValid                    : std_logic;
  SIGNAL rsValid                          : std_logic;
  SIGNAL rsBankSymbolCount_rsBank         : std_logic_vector(3 DOWNTO 0);  -- ufix4
  SIGNAL rsBankSymbolCount_rsCount        : std_logic_vector(8 DOWNTO 0);  -- ufix9
  SIGNAL alpha_cellRefGen_cellRef_re      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL alpha_cellRefGen_cellRef_im      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL alpha_cellRefGen_outValid        : std_logic;
  SIGNAL rsBankSymbolCount_rsBank_unsigned : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL Delay10_reg_rsvd                 : vector_of_unsigned4(0 TO 3) := (OTHERS => to_unsigned(16#0#, 4));  -- ufix4 [4]
  SIGNAL rsbank                           : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL rsBankSymbolCount_rsCount_unsigned : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Delay11_reg_rsvd                 : vector_of_unsigned9(0 TO 3) := (OTHERS => to_unsigned(16#000#, 9));  -- ufix9 [4]
  SIGNAL rscount                          : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL dataValid                        : std_logic;
  SIGNAL chEst_hEst_a0_re                 : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL chEst_hEst_a0_im                 : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL chEst_hEst_a1_re                 : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL chEst_hEst_a1_im                 : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL chEst_hEstValid                  : std_logic;
  SIGNAL chEst_hEst_a0_re_signed          : signed(16 DOWNTO 0);  -- sfix17_En16
  SIGNAL chEst_hEst_a0_im_signed          : signed(16 DOWNTO 0);  -- sfix17_En16
  SIGNAL Delay1_out1_re                   : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL Delay1_out1_im                   : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL chEst_hEst_a1_re_signed          : signed(16 DOWNTO 0);  -- sfix17_En16
  SIGNAL chEst_hEst_a1_im_signed          : signed(16 DOWNTO 0);  -- sfix17_En16
  SIGNAL Delay3_out1_re                   : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL Delay3_out1_im                   : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17_En16
  SIGNAL Delay4_out1                      : std_logic := '0';
  SIGNAL eqSymbols_re                     : std_logic_vector(17 DOWNTO 0);  -- ufix18
  SIGNAL eqSymbols_im                     : std_logic_vector(17 DOWNTO 0);  -- ufix18
  SIGNAL eqSymbolsValid                   : std_logic;
  SIGNAL eqSymbols_re_signed              : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL eqSymbols_im_signed              : signed(17 DOWNTO 0);  -- sfix18_En17
  SIGNAL Delay5_out1_eqSymbols_re         : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En17
  SIGNAL Delay5_out1_eqSymbols_im         : signed(17 DOWNTO 0) := to_signed(16#00000#, 18);  -- sfix18_En17
  SIGNAL Delay5_out1_eqSymbolsValid       : std_logic := '0';

BEGIN
  UrsBankSymbolCount : ltehdlChannelEqualizer_rsBankSymbolCount
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              rsValid => rsValid,
              reset => cellDetected,
              rsBank => rsBankSymbolCount_rsBank,  -- ufix4
              rsCount => rsBankSymbolCount_rsCount  -- ufix9
              );

  Ualpha_cellRefGen : ltehdlChannelEqualizer_cellRefGen
    PORT MAP( clk => clk,
              enb => enb,
              enb_1_2_0 => enb_1_2_0,
              enb_1_2_1 => enb_1_2_1,
              Nsubframe => NSubframe,  -- ufix4
              ofdmSymb => rsBankSymbolCount_rsBank,  -- ufix4
              NcellID => NCellID,  -- ufix9
              enGold => rsValid,
              cellDetected => cellDetected,
              cellRef_re => alpha_cellRefGen_cellRef_re,  -- sfix16_En15
              cellRef_im => alpha_cellRefGen_cellRef_im,  -- sfix16_En15
              outValid => alpha_cellRefGen_outValid
              );

  UchEst : ltehdlChannelEqualizer_chEst
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb_1_2_0 => enb_1_2_0,
              rxRS_re => std_logic_vector(Delay2_out1_re),  -- sfix16_En15
              rxRS_im => std_logic_vector(Delay2_out1_im),  -- sfix16_En15
              refRS_re => alpha_cellRefGen_cellRef_re,  -- sfix16_En15
              refRS_im => alpha_cellRefGen_cellRef_im,  -- sfix16_En15
              rsValid => alpha_cellRefGen_outValid,
              rsbank => std_logic_vector(rsbank),  -- ufix4
              rscount => std_logic_vector(rscount),  -- ufix9
              cellID => NCellID,  -- ufix9
              ndlrb => NDLRB,  -- ufix7
              hestRdAddr => hestRdAddr,  -- ufix11
              hestRdEnable => dataValid,
              reset => cellDetected,
              hEst_a0_re => chEst_hEst_a0_re,  -- sfix17_En16
              hEst_a0_im => chEst_hEst_a0_im,  -- sfix17_En16
              hEst_a1_re => chEst_hEst_a1_re,  -- sfix17_En16
              hEst_a1_im => chEst_hEst_a1_im,  -- sfix17_En16
              hEstValid => chEst_hEstValid
              );

  UTxDivDecode : ltehdlChannelEqualizer_TxDivDecode
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              gridData_re => std_logic_vector(Delay7_out1_re),  -- sfix16_En15
              gridData_im => std_logic_vector(Delay7_out1_im),  -- sfix16_En15
              A_re => std_logic_vector(Delay1_out1_re),  -- sfix17_En16
              A_im => std_logic_vector(Delay1_out1_im),  -- sfix17_En16
              B_re => std_logic_vector(Delay3_out1_re),  -- sfix17_En16
              B_im => std_logic_vector(Delay3_out1_im),  -- sfix17_En16
              dataValid => Delay4_out1,
              resetCount => cellDetected,
              S_re => eqSymbols_re,  -- sfix18_En17
              S_im => eqSymbols_im,  -- sfix18_En17
              SValid => eqSymbolsValid
              );

  gridData_re <= signed(gridData_gridData_re);

  gridData_im <= signed(gridData_gridData_im);

  Delay12_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay12_reg_im(0) <= gridData_im;
        Delay12_reg_im(1 TO 11) <= Delay12_reg_im(0 TO 10);
        Delay12_reg_re(0) <= gridData_re;
        Delay12_reg_re(1 TO 11) <= Delay12_reg_re(0 TO 10);
      END IF;
    END IF;
  END PROCESS Delay12_process;

  Delay12_out1_re <= Delay12_reg_re(11);
  Delay12_out1_im <= Delay12_reg_im(11);

  Delay7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay7_out1_re <= Delay12_out1_re;
        Delay7_out1_im <= Delay12_out1_im;
      END IF;
    END IF;
  END PROCESS Delay7_process;


  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay2_reg_im(0) <= gridData_im;
        Delay2_reg_im(1 TO 3) <= Delay2_reg_im(0 TO 2);
        Delay2_reg_re(0) <= gridData_re;
        Delay2_reg_re(1 TO 3) <= Delay2_reg_re(0 TO 2);
      END IF;
    END IF;
  END PROCESS Delay2_process;

  Delay2_out1_re <= Delay2_reg_re(3);
  Delay2_out1_im <= Delay2_reg_im(3);

  gridDataValid <= gridData_gridDataValid;

  
  rsValid <= gridDataValid WHEN gridWriteDone = '0' ELSE
      '0';

  rsBankSymbolCount_rsBank_unsigned <= unsigned(rsBankSymbolCount_rsBank);

  Delay10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay10_reg_rsvd(0) <= rsBankSymbolCount_rsBank_unsigned;
        Delay10_reg_rsvd(1 TO 3) <= Delay10_reg_rsvd(0 TO 2);
      END IF;
    END IF;
  END PROCESS Delay10_process;

  rsbank <= Delay10_reg_rsvd(3);

  rsBankSymbolCount_rsCount_unsigned <= unsigned(rsBankSymbolCount_rsCount);

  Delay11_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay11_reg_rsvd(0) <= rsBankSymbolCount_rsCount_unsigned;
        Delay11_reg_rsvd(1 TO 3) <= Delay11_reg_rsvd(0 TO 2);
      END IF;
    END IF;
  END PROCESS Delay11_process;

  rscount <= Delay11_reg_rsvd(3);

  
  dataValid <= '0' WHEN gridWriteDone = '0' ELSE
      gridDataValid;

  chEst_hEst_a0_re_signed <= signed(chEst_hEst_a0_re);

  chEst_hEst_a0_im_signed <= signed(chEst_hEst_a0_im);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_out1_re <= chEst_hEst_a0_re_signed;
        Delay1_out1_im <= chEst_hEst_a0_im_signed;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  chEst_hEst_a1_re_signed <= signed(chEst_hEst_a1_re);

  chEst_hEst_a1_im_signed <= signed(chEst_hEst_a1_im);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay3_out1_re <= chEst_hEst_a1_re_signed;
        Delay3_out1_im <= chEst_hEst_a1_im_signed;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay4_out1 <= chEst_hEstValid;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  eqSymbols_re_signed <= signed(eqSymbols_re);

  eqSymbols_im_signed <= signed(eqSymbols_im);

  c_c_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay5_out1_eqSymbols_re <= eqSymbols_re_signed;
        Delay5_out1_eqSymbols_im <= eqSymbols_im_signed;
      END IF;
    END IF;
  END PROCESS c_c_process;


  eqSymbols_eqSymbols_re <= std_logic_vector(Delay5_out1_eqSymbols_re);

  eqSymbols_eqSymbols_im <= std_logic_vector(Delay5_out1_eqSymbols_im);

  c_c_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay5_out1_eqSymbolsValid <= eqSymbolsValid;
      END IF;
    END IF;
  END PROCESS c_c_1_process;


  eqSymbols_eqSymbolsValid <= Delay5_out1_eqSymbolsValid;

END rtl;

