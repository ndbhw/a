-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlChannelEqualizer;
USE work.ltehdlChannelEqualizer_ltehdlChannelEqualizer_pac.ALL;

ENTITY ltehdlChannelEqualizer_InterpCalculation IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        dataIn_re_0                       :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dataIn_re_1                       :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dataIn_im_0                       :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dataIn_im_1                       :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        wrtAddr                           :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        doInterp                          :   IN    std_logic;
        isFirstRS                         :   IN    std_logic;
        isLastRS                          :   IN    std_logic;
        dOut_RS_re_0                      :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dOut_RS_re_1                      :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dOut_RS_im_0                      :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dOut_RS_im_1                      :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dOut13_re_0                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dOut13_re_1                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dOut13_im_0                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dOut13_im_1                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dOut23_re_0                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dOut23_re_1                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dOut23_im_0                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dOut23_im_1                       :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        wrtAddrBase                       :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
        interpValid                       :   OUT   std_logic
        );
END ltehdlChannelEqualizer_InterpCalculation;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_InterpCalculation IS

  -- Component Declarations
  COMPONENT ltehdlChannelEqualizer_Complex_shift
    PORT( In1_re_0                        :   IN    std_logic_vector(17 DOWNTO 0);  -- sfix18_En16
          In1_re_1                        :   IN    std_logic_vector(17 DOWNTO 0);  -- sfix18_En16
          In1_im_0                        :   IN    std_logic_vector(17 DOWNTO 0);  -- sfix18_En16
          In1_im_1                        :   IN    std_logic_vector(17 DOWNTO 0);  -- sfix18_En16
          Out1_re_0                       :   OUT   std_logic_vector(17 DOWNTO 0);  -- sfix18_En16
          Out1_re_1                       :   OUT   std_logic_vector(17 DOWNTO 0);  -- sfix18_En16
          Out1_im_0                       :   OUT   std_logic_vector(17 DOWNTO 0);  -- sfix18_En16
          Out1_im_1                       :   OUT   std_logic_vector(17 DOWNTO 0)  -- sfix18_En16
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlChannelEqualizer_Complex_shift
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_Complex_shift(rtl);

  -- Signals
  SIGNAL doInterp_1                       : std_logic;
  SIGNAL firstTS                          : std_logic;
  SIGNAL LastRs                           : std_logic;
  SIGNAL Delay4_reg_rsvd                  : std_logic_vector(4 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [5]
  SIGNAL Delay4_out1                      : std_logic;
  SIGNAL Delay3_reg_rsvd                  : std_logic_vector(4 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [5]
  SIGNAL Delay3_out1                      : std_logic;
  SIGNAL currentRS_re                     : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL currentRS_im                     : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL prevRS_re                        : vector_of_signed17(0 TO 1) := (OTHERS => to_signed(16#00000#, 17));  -- sfix17_En16 [2]
  SIGNAL prevRS_im                        : vector_of_signed17(0 TO 1) := (OTHERS => to_signed(16#00000#, 17));  -- sfix17_En16 [2]
  SIGNAL Delay1_reg_re                    : vector_of_signed17(0 TO 5) := (OTHERS => to_signed(16#00000#, 17));  -- sfix17_En16 [6]
  SIGNAL Delay1_reg_im                    : vector_of_signed17(0 TO 5) := (OTHERS => to_signed(16#00000#, 17));  -- sfix17_En16 [6]
  SIGNAL Delay1_out1_re                   : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Delay1_out1_im                   : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL prev_re                          : vector_of_signed17(0 TO 1) := (OTHERS => to_signed(16#00000#, 17));  -- sfix17_En16 [2]
  SIGNAL prev_im                          : vector_of_signed17(0 TO 1) := (OTHERS => to_signed(16#00000#, 17));  -- sfix17_En16 [2]
  SIGNAL prev_re_1                        : vector_of_signed17(0 TO 1) := (OTHERS => to_signed(16#00000#, 17));  -- sfix17_En16 [2]
  SIGNAL prev_im_1                        : vector_of_signed17(0 TO 1) := (OTHERS => to_signed(16#00000#, 17));  -- sfix17_En16 [2]
  SIGNAL Delay5_reg_re                    : vector_of_signed17(0 TO 9) := (OTHERS => to_signed(16#00000#, 17));  -- sfix17_En16 [10]
  SIGNAL Delay5_reg_im                    : vector_of_signed17(0 TO 9) := (OTHERS => to_signed(16#00000#, 17));  -- sfix17_En16 [10]
  SIGNAL current_re                       : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL current_im                       : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Multiport_Switch5_out1_re        : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Multiport_Switch5_out1_im        : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Multiport_Switch4_out1_re        : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Multiport_Switch4_out1_im        : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Subtract2_sub_cast               : vector_of_signed18(0 TO 1);  -- sfix18_En16 [2]
  SIGNAL Subtract2_sub_cast_1             : vector_of_signed18(0 TO 1);  -- sfix18_En16 [2]
  SIGNAL Subtract2_sub_cast_2             : vector_of_signed18(0 TO 1);  -- sfix18_En16 [2]
  SIGNAL Subtract2_sub_cast_3             : vector_of_signed18(0 TO 1);  -- sfix18_En16 [2]
  SIGNAL Subtract2_out1_re                : vector_of_signed18(0 TO 1);  -- sfix18_En16 [2]
  SIGNAL Subtract2_out1_im                : vector_of_signed18(0 TO 1);  -- sfix18_En16 [2]
  SIGNAL Delay7_out1_re                   : vector_of_signed18(0 TO 1) := (OTHERS => to_signed(16#00000#, 18));  -- sfix18_En16 [2]
  SIGNAL Delay7_out1_im                   : vector_of_signed18(0 TO 1) := (OTHERS => to_signed(16#00000#, 18));  -- sfix18_En16 [2]
  SIGNAL Gain_mul_temp                    : signed(35 DOWNTO 0);  -- sfix36_En34
  SIGNAL Gain_mul_temp_1                  : signed(35 DOWNTO 0);  -- sfix36_En34
  SIGNAL Gain_mul_temp_2                  : signed(35 DOWNTO 0);  -- sfix36_En34
  SIGNAL Gain_mul_temp_3                  : signed(35 DOWNTO 0);  -- sfix36_En34
  SIGNAL Gain_out1_re                     : vector_of_signed18(0 TO 1);  -- sfix18_En16 [2]
  SIGNAL Gain_out1_im                     : vector_of_signed18(0 TO 1);  -- sfix18_En16 [2]
  SIGNAL Delay8_reg_re                    : vector_of_signed18(0 TO 3) := (OTHERS => to_signed(16#00000#, 18));  -- sfix18_En16 [4]
  SIGNAL Delay8_reg_im                    : vector_of_signed18(0 TO 3) := (OTHERS => to_signed(16#00000#, 18));  -- sfix18_En16 [4]
  SIGNAL Delay8_out1_re                   : vector_of_signed18(0 TO 1);  -- sfix18_En16 [2]
  SIGNAL Delay8_out1_im                   : vector_of_signed18(0 TO 1);  -- sfix18_En16 [2]
  SIGNAL Delay14_out1_re                  : vector_of_signed18(0 TO 1) := (OTHERS => to_signed(16#00000#, 18));  -- sfix18_En16 [2]
  SIGNAL Delay14_out1_im                  : vector_of_signed18(0 TO 1) := (OTHERS => to_signed(16#00000#, 18));  -- sfix18_En16 [2]
  SIGNAL Add2_add_cast                    : vector_of_signed19(0 TO 1);  -- sfix19_En16 [2]
  SIGNAL Add2_add_cast_1                  : vector_of_signed19(0 TO 1);  -- sfix19_En16 [2]
  SIGNAL Add2_add_temp                    : vector_of_signed19(0 TO 1);  -- sfix19_En16 [2]
  SIGNAL Add2_add_cast_2                  : vector_of_signed19(0 TO 1);  -- sfix19_En16 [2]
  SIGNAL Add2_add_cast_3                  : vector_of_signed19(0 TO 1);  -- sfix19_En16 [2]
  SIGNAL Add2_add_temp_1                  : vector_of_signed19(0 TO 1);  -- sfix19_En16 [2]
  SIGNAL Add2_out1_re                     : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Add2_out1_im                     : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Delay19_out1_re                  : vector_of_signed17(0 TO 1) := (OTHERS => to_signed(16#00000#, 17));  -- sfix17_En16 [2]
  SIGNAL Delay19_out1_im                  : vector_of_signed17(0 TO 1) := (OTHERS => to_signed(16#00000#, 17));  -- sfix17_En16 [2]
  SIGNAL Multiport_Switch_out1_re         : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Multiport_Switch_out1_im         : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Multiport_Switch3_out1_re        : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Multiport_Switch3_out1_im        : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Complex_shift_Out1_re_0          : std_logic_vector(17 DOWNTO 0);  -- ufix18
  SIGNAL Complex_shift_Out1_re_1          : std_logic_vector(17 DOWNTO 0);  -- ufix18
  SIGNAL Complex_shift_Out1_im_0          : std_logic_vector(17 DOWNTO 0);  -- ufix18
  SIGNAL Complex_shift_Out1_im_1          : std_logic_vector(17 DOWNTO 0);  -- ufix18
  SIGNAL Complex_shift_Out1_re            : vector_of_signed18(0 TO 1);  -- sfix18_En16 [2]
  SIGNAL Complex_shift_Out1_im            : vector_of_signed18(0 TO 1);  -- sfix18_En16 [2]
  SIGNAL Delay16_out1_re                  : vector_of_signed18(0 TO 1) := (OTHERS => to_signed(16#00000#, 18));  -- sfix18_En16 [2]
  SIGNAL Delay16_out1_im                  : vector_of_signed18(0 TO 1) := (OTHERS => to_signed(16#00000#, 18));  -- sfix18_En16 [2]
  SIGNAL Add1_add_cast                    : vector_of_signed19(0 TO 1);  -- sfix19_En16 [2]
  SIGNAL Add1_add_cast_1                  : vector_of_signed19(0 TO 1);  -- sfix19_En16 [2]
  SIGNAL Add1_add_temp                    : vector_of_signed19(0 TO 1);  -- sfix19_En16 [2]
  SIGNAL Add1_add_cast_2                  : vector_of_signed19(0 TO 1);  -- sfix19_En16 [2]
  SIGNAL Add1_add_cast_3                  : vector_of_signed19(0 TO 1);  -- sfix19_En16 [2]
  SIGNAL Add1_add_temp_1                  : vector_of_signed19(0 TO 1);  -- sfix19_En16 [2]
  SIGNAL Add1_out1_re                     : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Add1_out1_im                     : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Delay18_out1_re                  : vector_of_signed17(0 TO 1) := (OTHERS => to_signed(16#00000#, 17));  -- sfix17_En16 [2]
  SIGNAL Delay18_out1_im                  : vector_of_signed17(0 TO 1) := (OTHERS => to_signed(16#00000#, 17));  -- sfix17_En16 [2]
  SIGNAL Multiport_Switch1_out1_re        : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Multiport_Switch1_out1_im        : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Multiport_Switch2_out1_re        : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Multiport_Switch2_out1_im        : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL wrtAddr_unsigned                 : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Delay9_reg_rsvd                  : vector_of_unsigned9(0 TO 4) := (OTHERS => to_unsigned(16#000#, 9));  -- ufix9 [5]
  SIGNAL Delay9_out1                      : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Delay6_reg_rsvd                  : std_logic_vector(4 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [5]
  SIGNAL Delay6_out1                      : std_logic;

BEGIN
  -- multiply by 2 to get 2/3rds
  UComplex_shift : ltehdlChannelEqualizer_Complex_shift
    PORT MAP( In1_re_0 => std_logic_vector(Delay8_out1_re(0)),  -- sfix18_En16
              In1_re_1 => std_logic_vector(Delay8_out1_re(1)),  -- sfix18_En16
              In1_im_0 => std_logic_vector(Delay8_out1_im(0)),  -- sfix18_En16
              In1_im_1 => std_logic_vector(Delay8_out1_im(1)),  -- sfix18_En16
              Out1_re_0 => Complex_shift_Out1_re_0,  -- sfix18_En16
              Out1_re_1 => Complex_shift_Out1_re_1,  -- sfix18_En16
              Out1_im_0 => Complex_shift_Out1_im_0,  -- sfix18_En16
              Out1_im_1 => Complex_shift_Out1_im_1  -- sfix18_En16
              );

  doInterp_1 <= doInterp;

  firstTS <= isFirstRS;

  LastRs <= isLastRS;

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay4_reg_rsvd(0) <= LastRs;
        Delay4_reg_rsvd(4 DOWNTO 1) <= Delay4_reg_rsvd(3 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS Delay4_process;

  Delay4_out1 <= Delay4_reg_rsvd(4);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay3_reg_rsvd(0) <= firstTS;
        Delay3_reg_rsvd(4 DOWNTO 1) <= Delay3_reg_rsvd(3 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS Delay3_process;

  Delay3_out1 <= Delay3_reg_rsvd(4);

  currentRS_re(0) <= signed(dataIn_re_0);
  currentRS_re(1) <= signed(dataIn_re_1);

  currentRS_im(0) <= signed(dataIn_im_0);
  currentRS_im(1) <= signed(dataIn_im_1);

  Delay_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        prevRS_re <= currentRS_re;
        prevRS_im <= currentRS_im;
      END IF;
    END IF;
  END PROCESS Delay_rsvd_process;


  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_reg_re(0 TO 1) <= prevRS_re(0 TO 1);
        Delay1_reg_re(2 TO 5) <= Delay1_reg_re(0 TO 3);
        Delay1_reg_im(0 TO 1) <= prevRS_im(0 TO 1);
        Delay1_reg_im(2 TO 5) <= Delay1_reg_im(0 TO 3);
      END IF;
    END IF;
  END PROCESS Delay1_process;

  Delay1_out1_re(0 TO 1) <= Delay1_reg_re(4 TO 5);
  Delay1_out1_im(0 TO 1) <= Delay1_reg_im(4 TO 5);

  Delay17_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        prev_re <= Delay1_out1_re;
        prev_im <= Delay1_out1_im;
      END IF;
    END IF;
  END PROCESS Delay17_process;


  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        prev_re_1 <= prev_re;
        prev_im_1 <= prev_im;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay5_reg_re(0 TO 1) <= currentRS_re(0 TO 1);
        Delay5_reg_re(2 TO 9) <= Delay5_reg_re(0 TO 7);
        Delay5_reg_im(0 TO 1) <= currentRS_im(0 TO 1);
        Delay5_reg_im(2 TO 9) <= Delay5_reg_im(0 TO 7);
      END IF;
    END IF;
  END PROCESS Delay5_process;

  current_re(0 TO 1) <= Delay5_reg_re(8 TO 9);
  current_im(0 TO 1) <= Delay5_reg_im(8 TO 9);

  
  Multiport_Switch5_out1_re <= prev_re_1 WHEN Delay3_out1 = '0' ELSE
      current_re;
  
  Multiport_Switch5_out1_im <= prev_im_1 WHEN Delay3_out1 = '0' ELSE
      current_im;

  
  Multiport_Switch4_out1_re <= Multiport_Switch5_out1_re WHEN Delay4_out1 = '0' ELSE
      prev_re_1;
  
  Multiport_Switch4_out1_im <= Multiport_Switch5_out1_im WHEN Delay4_out1 = '0' ELSE
      prev_im_1;

  dOut_RS_re_0 <= std_logic_vector(Multiport_Switch4_out1_re(0));

  dOut_RS_re_1 <= std_logic_vector(Multiport_Switch4_out1_re(1));

  dOut_RS_im_0 <= std_logic_vector(Multiport_Switch4_out1_im(0));

  dOut_RS_im_1 <= std_logic_vector(Multiport_Switch4_out1_im(1));

  -- get difference between RS

  Subtract2_out1_im_gen: FOR t_0 IN 0 TO 1 GENERATE
    Subtract2_sub_cast(t_0) <= resize(currentRS_re(t_0), 18);
    Subtract2_sub_cast_1(t_0) <= resize(prevRS_re(t_0), 18);
    Subtract2_out1_re(t_0) <= Subtract2_sub_cast(t_0) - Subtract2_sub_cast_1(t_0);
    Subtract2_sub_cast_2(t_0) <= resize(currentRS_im(t_0), 18);
    Subtract2_sub_cast_3(t_0) <= resize(prevRS_im(t_0), 18);
    Subtract2_out1_im(t_0) <= Subtract2_sub_cast_2(t_0) - Subtract2_sub_cast_3(t_0);
  END GENERATE Subtract2_out1_im_gen;


  Delay7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay7_out1_re <= Subtract2_out1_re;
        Delay7_out1_im <= Subtract2_out1_im;
      END IF;
    END IF;
  END PROCESS Delay7_process;


  -- average difference across 3 locations
  Gain_mul_temp <= to_signed(16#15554#, 18) * Delay7_out1_re(0);
  Gain_out1_re(0) <= Gain_mul_temp(35 DOWNTO 18);
  Gain_mul_temp_1 <= to_signed(16#15554#, 18) * Delay7_out1_im(0);
  Gain_out1_im(0) <= Gain_mul_temp_1(35 DOWNTO 18);
  Gain_mul_temp_2 <= to_signed(16#15554#, 18) * Delay7_out1_re(1);
  Gain_out1_re(1) <= Gain_mul_temp_2(35 DOWNTO 18);
  Gain_mul_temp_3 <= to_signed(16#15554#, 18) * Delay7_out1_im(1);
  Gain_out1_im(1) <= Gain_mul_temp_3(35 DOWNTO 18);

  Delay8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay8_reg_re(0 TO 1) <= Gain_out1_re(0 TO 1);
        Delay8_reg_re(2 TO 3) <= Delay8_reg_re(0 TO 1);
        Delay8_reg_im(0 TO 1) <= Gain_out1_im(0 TO 1);
        Delay8_reg_im(2 TO 3) <= Delay8_reg_im(0 TO 1);
      END IF;
    END IF;
  END PROCESS Delay8_process;

  Delay8_out1_re(0 TO 1) <= Delay8_reg_re(2 TO 3);
  Delay8_out1_im(0 TO 1) <= Delay8_reg_im(2 TO 3);

  Delay14_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay14_out1_re <= Delay8_out1_re;
        Delay14_out1_im <= Delay8_out1_im;
      END IF;
    END IF;
  END PROCESS Delay14_process;



  Add2_out1_im_gen: FOR t_01 IN 0 TO 1 GENERATE
    Add2_add_cast(t_01) <= resize(Delay14_out1_re(t_01), 19);
    Add2_add_cast_1(t_01) <= resize(prev_re(t_01), 19);
    Add2_add_temp(t_01) <= Add2_add_cast(t_01) + Add2_add_cast_1(t_01);
    Add2_out1_re(t_01) <= Add2_add_temp(t_01)(16 DOWNTO 0);
    Add2_add_cast_2(t_01) <= resize(Delay14_out1_im(t_01), 19);
    Add2_add_cast_3(t_01) <= resize(prev_im(t_01), 19);
    Add2_add_temp_1(t_01) <= Add2_add_cast_2(t_01) + Add2_add_cast_3(t_01);
    Add2_out1_im(t_01) <= Add2_add_temp_1(t_01)(16 DOWNTO 0);
  END GENERATE Add2_out1_im_gen;


  Delay19_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay19_out1_re <= Add2_out1_re;
        Delay19_out1_im <= Add2_out1_im;
      END IF;
    END IF;
  END PROCESS Delay19_process;


  -- if first RS repeat current RS downwards
  
  Multiport_Switch_out1_re <= Delay19_out1_re WHEN Delay3_out1 = '0' ELSE
      current_re;
  
  Multiport_Switch_out1_im <= Delay19_out1_im WHEN Delay3_out1 = '0' ELSE
      current_im;

  -- if last RS repeat previous RS upwards
  
  Multiport_Switch3_out1_re <= Multiport_Switch_out1_re WHEN Delay4_out1 = '0' ELSE
      prev_re_1;
  
  Multiport_Switch3_out1_im <= Multiport_Switch_out1_im WHEN Delay4_out1 = '0' ELSE
      prev_im_1;

  dOut13_re_0 <= std_logic_vector(Multiport_Switch3_out1_re(0));

  dOut13_re_1 <= std_logic_vector(Multiport_Switch3_out1_re(1));

  dOut13_im_0 <= std_logic_vector(Multiport_Switch3_out1_im(0));

  dOut13_im_1 <= std_logic_vector(Multiport_Switch3_out1_im(1));

  Complex_shift_Out1_re(0) <= signed(Complex_shift_Out1_re_0);
  Complex_shift_Out1_re(1) <= signed(Complex_shift_Out1_re_1);

  Complex_shift_Out1_im(0) <= signed(Complex_shift_Out1_im_0);
  Complex_shift_Out1_im(1) <= signed(Complex_shift_Out1_im_1);

  Delay16_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay16_out1_re <= Complex_shift_Out1_re;
        Delay16_out1_im <= Complex_shift_Out1_im;
      END IF;
    END IF;
  END PROCESS Delay16_process;



  Add1_out1_im_gen: FOR t_02 IN 0 TO 1 GENERATE
    Add1_add_cast(t_02) <= resize(Delay16_out1_re(t_02), 19);
    Add1_add_cast_1(t_02) <= resize(prev_re(t_02), 19);
    Add1_add_temp(t_02) <= Add1_add_cast(t_02) + Add1_add_cast_1(t_02);
    Add1_out1_re(t_02) <= Add1_add_temp(t_02)(16 DOWNTO 0);
    Add1_add_cast_2(t_02) <= resize(Delay16_out1_im(t_02), 19);
    Add1_add_cast_3(t_02) <= resize(prev_im(t_02), 19);
    Add1_add_temp_1(t_02) <= Add1_add_cast_2(t_02) + Add1_add_cast_3(t_02);
    Add1_out1_im(t_02) <= Add1_add_temp_1(t_02)(16 DOWNTO 0);
  END GENERATE Add1_out1_im_gen;


  Delay18_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay18_out1_re <= Add1_out1_re;
        Delay18_out1_im <= Add1_out1_im;
      END IF;
    END IF;
  END PROCESS Delay18_process;


  -- if first RS repeat current RS downwards
  
  Multiport_Switch1_out1_re <= Delay18_out1_re WHEN Delay3_out1 = '0' ELSE
      current_re;
  
  Multiport_Switch1_out1_im <= Delay18_out1_im WHEN Delay3_out1 = '0' ELSE
      current_im;

  -- if last RS repeat previous RS upwards
  
  Multiport_Switch2_out1_re <= Multiport_Switch1_out1_re WHEN Delay4_out1 = '0' ELSE
      prev_re_1;
  
  Multiport_Switch2_out1_im <= Multiport_Switch1_out1_im WHEN Delay4_out1 = '0' ELSE
      prev_im_1;

  dOut23_re_0 <= std_logic_vector(Multiport_Switch2_out1_re(0));

  dOut23_re_1 <= std_logic_vector(Multiport_Switch2_out1_re(1));

  dOut23_im_0 <= std_logic_vector(Multiport_Switch2_out1_im(0));

  dOut23_im_1 <= std_logic_vector(Multiport_Switch2_out1_im(1));

  wrtAddr_unsigned <= unsigned(wrtAddr);

  Delay9_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay9_reg_rsvd(0) <= wrtAddr_unsigned;
        Delay9_reg_rsvd(1 TO 4) <= Delay9_reg_rsvd(0 TO 3);
      END IF;
    END IF;
  END PROCESS Delay9_process;

  Delay9_out1 <= Delay9_reg_rsvd(4);

  wrtAddrBase <= std_logic_vector(Delay9_out1);

  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay6_reg_rsvd(0) <= doInterp_1;
        Delay6_reg_rsvd(4 DOWNTO 1) <= Delay6_reg_rsvd(3 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS Delay6_process;

  Delay6_out1 <= Delay6_reg_rsvd(4);

  interpValid <= Delay6_out1;

END rtl;

