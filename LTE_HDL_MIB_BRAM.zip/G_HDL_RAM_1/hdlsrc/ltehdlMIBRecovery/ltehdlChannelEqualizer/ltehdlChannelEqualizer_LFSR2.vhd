-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlChannelEqualizer_LFSR2 IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        Load                              :   IN    std_logic;
        Init                              :   IN    std_logic_vector(30 DOWNTO 0);  -- ufix31
        Enable                            :   IN    std_logic;
        Out1                              :   OUT   std_logic  -- ufix1
        );
END ltehdlChannelEqualizer_LFSR2;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_LFSR2 IS

  -- Signals
  SIGNAL enb_gated                        : std_logic;
  SIGNAL switch_compare_1                 : std_logic;
  SIGNAL Init_unsigned                    : unsigned(30 DOWNTO 0);  -- ufix31
  SIGNAL Delay2_out1                      : unsigned(30 DOWNTO 0) := to_unsigned(16#00000000#, 31);  -- ufix31
  SIGNAL Extract_Bits5_out1               : unsigned(29 DOWNTO 0);  -- ufix30
  SIGNAL dtc1                             : std_logic;  -- ufix1
  SIGNAL dtc1_1                           : std_logic;  -- ufix1_E1
  SIGNAL Extract_Bits6_out1               : std_logic;  -- ufix1
  SIGNAL dtc1_2                           : std_logic;  -- ufix1_E2
  SIGNAL Extract_Bits3_out1               : std_logic;  -- ufix1
  SIGNAL dtc1_3                           : std_logic;  -- ufix1_E3
  SIGNAL Extract_Bits4_out1               : std_logic;  -- ufix1
  SIGNAL Logical_Operator1_out1           : std_logic;
  SIGNAL Bit_Concat2_out1                 : unsigned(30 DOWNTO 0);  -- ufix31
  SIGNAL Switch1_out1                     : unsigned(30 DOWNTO 0);  -- ufix31
  SIGNAL bitMask_for_Bitwise_Operator     : unsigned(30 DOWNTO 0);  -- ufix31
  SIGNAL Bitwise_Operator_out1            : unsigned(30 DOWNTO 0);  -- ufix31
  SIGNAL Bit_Reduce_out1                  : std_logic;  -- ufix1

BEGIN
  
  switch_compare_1 <= '1' WHEN Load > '0' ELSE
      '0';

  Init_unsigned <= unsigned(Init);

  enb_gated <= Enable AND enb;

  Extract_Bits5_out1 <= Delay2_out1(30 DOWNTO 1);

  dtc1 <= Delay2_out1(0);

  dtc1_1 <= Delay2_out1(1);

  Extract_Bits6_out1 <= dtc1_1;

  dtc1_2 <= Delay2_out1(2);

  Extract_Bits3_out1 <= dtc1_2;

  dtc1_3 <= Delay2_out1(3);

  Extract_Bits4_out1 <= dtc1_3;

  Logical_Operator1_out1 <= dtc1 XOR (Extract_Bits6_out1 XOR (Extract_Bits4_out1 XOR Extract_Bits3_out1));

  Bit_Concat2_out1 <= Logical_Operator1_out1 & Extract_Bits5_out1;

  
  Switch1_out1 <= Bit_Concat2_out1 WHEN switch_compare_1 = '0' ELSE
      Init_unsigned;

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_gated = '1' THEN
        Delay2_out1 <= Switch1_out1;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  bitMask_for_Bitwise_Operator <= to_unsigned(16#0099110E#, 31);

  Bitwise_Operator_out1 <= Delay2_out1 AND bitMask_for_Bitwise_Operator;

  Bit_Reduce_out1 <= (Bitwise_Operator_out1(30) XOR Bitwise_Operator_out1(29) XOR Bitwise_Operator_out1(28) XOR Bitwise_Operator_out1(27) XOR Bitwise_Operator_out1(26) XOR Bitwise_Operator_out1(25) XOR Bitwise_Operator_out1(24) XOR 
    Bitwise_Operator_out1(23) XOR Bitwise_Operator_out1(22) XOR Bitwise_Operator_out1(21) XOR Bitwise_Operator_out1(20) XOR Bitwise_Operator_out1(19) XOR Bitwise_Operator_out1(18) XOR Bitwise_Operator_out1(17) XOR Bitwise_Operator_out1(16) XOR 
    Bitwise_Operator_out1(15) XOR Bitwise_Operator_out1(14) XOR Bitwise_Operator_out1(13) XOR Bitwise_Operator_out1(12) XOR Bitwise_Operator_out1(11) XOR Bitwise_Operator_out1(10) XOR Bitwise_Operator_out1(9) XOR Bitwise_Operator_out1(8) XOR 
    Bitwise_Operator_out1(7) XOR Bitwise_Operator_out1(6) XOR Bitwise_Operator_out1(5) XOR Bitwise_Operator_out1(4) XOR Bitwise_Operator_out1(3) XOR Bitwise_Operator_out1(2) XOR Bitwise_Operator_out1(1) XOR Bitwise_Operator_out1(0));

  Out1 <= Bit_Reduce_out1;

END rtl;

