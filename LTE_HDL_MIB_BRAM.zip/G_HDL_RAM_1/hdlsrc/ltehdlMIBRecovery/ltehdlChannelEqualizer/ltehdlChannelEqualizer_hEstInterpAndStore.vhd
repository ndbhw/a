-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlChannelEqualizer;
USE work.ltehdlChannelEqualizer_ltehdlChannelEqualizer_pac.ALL;

ENTITY ltehdlChannelEqualizer_hEstInterpAndStore IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        dataIn_re_0                       :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dataIn_re_1                       :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dataIn_im_0                       :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        dataIn_im_1                       :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        ramAddr                           :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        doInterp                          :   IN    std_logic;
        isFirstRS                         :   IN    std_logic;
        isLastRS                          :   IN    std_logic;
        rdAddr                            :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        addrBank                          :   IN    std_logic_vector(15 DOWNTO 0);  -- uint16
        rdEn                              :   IN    std_logic;
        hEst_re_0                         :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        hEst_re_1                         :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        hEst_im_0                         :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        hEst_im_1                         :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        Out2                              :   OUT   std_logic
        );
END ltehdlChannelEqualizer_hEstInterpAndStore;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_hEstInterpAndStore IS

  -- Component Declarations
  COMPONENT ltehdlChannelEqualizer_InterpCalculation
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dataIn_re_0                     :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dataIn_re_1                     :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dataIn_im_0                     :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dataIn_im_1                     :   IN    std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          wrtAddr                         :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          doInterp                        :   IN    std_logic;
          isFirstRS                       :   IN    std_logic;
          isLastRS                        :   IN    std_logic;
          dOut_RS_re_0                    :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dOut_RS_re_1                    :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dOut_RS_im_0                    :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dOut_RS_im_1                    :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dOut13_re_0                     :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dOut13_re_1                     :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dOut13_im_0                     :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dOut13_im_1                     :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dOut23_re_0                     :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dOut23_re_1                     :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dOut23_im_0                     :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          dOut23_im_1                     :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          wrtAddrBase                     :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
          interpValid                     :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlChannelEqualizer_SimpleDualPortRAM_generic
    GENERIC( AddrWidth                    : integer;
             DataWidth                    : integer
             );
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          wr_din_re                       :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          wr_din_im                       :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          wr_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          wr_en                           :   IN    std_logic;
          rd_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          dout_re                         :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          dout_im                         :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0)  -- generic width
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlChannelEqualizer_InterpCalculation
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_InterpCalculation(rtl);

  FOR ALL : ltehdlChannelEqualizer_SimpleDualPortRAM_generic
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_SimpleDualPortRAM_generic(rtl);

  -- Signals
  SIGNAL addrBank_unsigned                : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL InterpCalculation_dOut_RS_re_0   : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL InterpCalculation_dOut_RS_re_1   : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL InterpCalculation_dOut_RS_im_0   : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL InterpCalculation_dOut_RS_im_1   : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL InterpCalculation_dOut13_re_0    : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL InterpCalculation_dOut13_re_1    : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL InterpCalculation_dOut13_im_0    : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL InterpCalculation_dOut13_im_1    : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL InterpCalculation_dOut23_re_0    : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL InterpCalculation_dOut23_re_1    : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL InterpCalculation_dOut23_im_0    : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL InterpCalculation_dOut23_im_1    : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL InterpCalculation_wrtAddrBase    : std_logic_vector(8 DOWNTO 0);  -- ufix9
  SIGNAL interpValid                      : std_logic;
  SIGNAL pri_rd_out_1_re                  : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL pri_rd_out_1_im                  : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL pri_rd_out_1_re_1                : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL pri_rd_out_1_im_1                : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL pri_rd_out_1_re_2                : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL pri_rd_out_1_im_2                : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL pri_rd_out_1_re_3                : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL pri_rd_out_1_im_3                : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL pri_rd_out_1_re_4                : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL pri_rd_out_1_im_4                : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL pri_rd_out_1_re_5                : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL pri_rd_out_1_im_5                : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL Delay11_out1                     : unsigned(15 DOWNTO 0) := to_unsigned(16#0000#, 16);  -- uint16
  SIGNAL ant0ram1_out1_re                 : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL ant0ram1_out1_im                 : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL ant0ram2_out1_re                 : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL ant0ram2_out1_im                 : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL ant0ram3_out1_re                 : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL ant0ram3_out1_im                 : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Multiport_Switch_out1_re         : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Multiport_Switch_out1_im         : vector_of_signed17(0 TO 1);  -- sfix17_En16 [2]
  SIGNAL Delay1_out1                      : std_logic := '0';

BEGIN
  UInterpCalculation : ltehdlChannelEqualizer_InterpCalculation
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dataIn_re_0 => dataIn_re_0,  -- sfix17_En16
              dataIn_re_1 => dataIn_re_1,  -- sfix17_En16
              dataIn_im_0 => dataIn_im_0,  -- sfix17_En16
              dataIn_im_1 => dataIn_im_1,  -- sfix17_En16
              wrtAddr => ramAddr,  -- ufix9
              doInterp => doInterp,
              isFirstRS => isFirstRS,
              isLastRS => isLastRS,
              dOut_RS_re_0 => InterpCalculation_dOut_RS_re_0,  -- sfix17_En16
              dOut_RS_re_1 => InterpCalculation_dOut_RS_re_1,  -- sfix17_En16
              dOut_RS_im_0 => InterpCalculation_dOut_RS_im_0,  -- sfix17_En16
              dOut_RS_im_1 => InterpCalculation_dOut_RS_im_1,  -- sfix17_En16
              dOut13_re_0 => InterpCalculation_dOut13_re_0,  -- sfix17_En16
              dOut13_re_1 => InterpCalculation_dOut13_re_1,  -- sfix17_En16
              dOut13_im_0 => InterpCalculation_dOut13_im_0,  -- sfix17_En16
              dOut13_im_1 => InterpCalculation_dOut13_im_1,  -- sfix17_En16
              dOut23_re_0 => InterpCalculation_dOut23_re_0,  -- sfix17_En16
              dOut23_re_1 => InterpCalculation_dOut23_re_1,  -- sfix17_En16
              dOut23_im_0 => InterpCalculation_dOut23_im_0,  -- sfix17_En16
              dOut23_im_1 => InterpCalculation_dOut23_im_1,  -- sfix17_En16
              wrtAddrBase => InterpCalculation_wrtAddrBase,  -- ufix9
              interpValid => interpValid
              );

  Uant0ram1_bank0 : ltehdlChannelEqualizer_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 9,
                 DataWidth => 17
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => InterpCalculation_dOut_RS_re_0,
              wr_din_im => InterpCalculation_dOut_RS_im_0,
              wr_addr => InterpCalculation_wrtAddrBase,
              wr_en => interpValid,
              rd_addr => rdAddr,
              dout_re => pri_rd_out_1_re,
              dout_im => pri_rd_out_1_im
              );

  Uant0ram1_bank1 : ltehdlChannelEqualizer_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 9,
                 DataWidth => 17
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => InterpCalculation_dOut_RS_re_1,
              wr_din_im => InterpCalculation_dOut_RS_im_1,
              wr_addr => InterpCalculation_wrtAddrBase,
              wr_en => interpValid,
              rd_addr => rdAddr,
              dout_re => pri_rd_out_1_re_1,
              dout_im => pri_rd_out_1_im_1
              );

  Uant0ram2_bank0 : ltehdlChannelEqualizer_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 9,
                 DataWidth => 17
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => InterpCalculation_dOut13_re_0,
              wr_din_im => InterpCalculation_dOut13_im_0,
              wr_addr => InterpCalculation_wrtAddrBase,
              wr_en => interpValid,
              rd_addr => rdAddr,
              dout_re => pri_rd_out_1_re_2,
              dout_im => pri_rd_out_1_im_2
              );

  Uant0ram2_bank1 : ltehdlChannelEqualizer_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 9,
                 DataWidth => 17
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => InterpCalculation_dOut13_re_1,
              wr_din_im => InterpCalculation_dOut13_im_1,
              wr_addr => InterpCalculation_wrtAddrBase,
              wr_en => interpValid,
              rd_addr => rdAddr,
              dout_re => pri_rd_out_1_re_3,
              dout_im => pri_rd_out_1_im_3
              );

  Uant0ram3_bank0 : ltehdlChannelEqualizer_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 9,
                 DataWidth => 17
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => InterpCalculation_dOut23_re_0,
              wr_din_im => InterpCalculation_dOut23_im_0,
              wr_addr => InterpCalculation_wrtAddrBase,
              wr_en => interpValid,
              rd_addr => rdAddr,
              dout_re => pri_rd_out_1_re_4,
              dout_im => pri_rd_out_1_im_4
              );

  Uant0ram3_bank1 : ltehdlChannelEqualizer_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 9,
                 DataWidth => 17
                 )
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              wr_din_re => InterpCalculation_dOut23_re_1,
              wr_din_im => InterpCalculation_dOut23_im_1,
              wr_addr => InterpCalculation_wrtAddrBase,
              wr_en => interpValid,
              rd_addr => rdAddr,
              dout_re => pri_rd_out_1_re_5,
              dout_im => pri_rd_out_1_im_5
              );

  addrBank_unsigned <= unsigned(addrBank);

  Delay11_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay11_out1 <= addrBank_unsigned;
      END IF;
    END IF;
  END PROCESS Delay11_process;


  ant0ram1_out1_re(0) <= signed(pri_rd_out_1_re);
  ant0ram1_out1_re(1) <= signed(pri_rd_out_1_re_1);

  ant0ram1_out1_im(0) <= signed(pri_rd_out_1_im);
  ant0ram1_out1_im(1) <= signed(pri_rd_out_1_im_1);

  ant0ram2_out1_re(0) <= signed(pri_rd_out_1_re_2);
  ant0ram2_out1_re(1) <= signed(pri_rd_out_1_re_3);

  ant0ram2_out1_im(0) <= signed(pri_rd_out_1_im_2);
  ant0ram2_out1_im(1) <= signed(pri_rd_out_1_im_3);

  ant0ram3_out1_re(0) <= signed(pri_rd_out_1_re_4);
  ant0ram3_out1_re(1) <= signed(pri_rd_out_1_re_5);

  ant0ram3_out1_im(0) <= signed(pri_rd_out_1_im_4);
  ant0ram3_out1_im(1) <= signed(pri_rd_out_1_im_5);

  Multiport_Switch_output : PROCESS (Delay11_out1, ant0ram1_out1_im, ant0ram1_out1_re, ant0ram2_out1_im,
       ant0ram2_out1_re, ant0ram3_out1_im, ant0ram3_out1_re)
  BEGIN
    IF Delay11_out1 = to_unsigned(16#0000#, 16) THEN 
      Multiport_Switch_out1_re <= ant0ram1_out1_re;
      Multiport_Switch_out1_im <= ant0ram1_out1_im;
    ELSIF Delay11_out1 = to_unsigned(16#0001#, 16) THEN 
      Multiport_Switch_out1_re <= ant0ram2_out1_re;
      Multiport_Switch_out1_im <= ant0ram2_out1_im;
    ELSE 
      Multiport_Switch_out1_re <= ant0ram3_out1_re;
      Multiport_Switch_out1_im <= ant0ram3_out1_im;
    END IF;
  END PROCESS Multiport_Switch_output;


  hEst_re_0 <= std_logic_vector(Multiport_Switch_out1_re(0));

  hEst_re_1 <= std_logic_vector(Multiport_Switch_out1_re(1));

  hEst_im_0 <= std_logic_vector(Multiport_Switch_out1_im(0));

  hEst_im_1 <= std_logic_vector(Multiport_Switch_out1_im(1));

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_out1 <= rdEn;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  Out2 <= Delay1_out1;

END rtl;

