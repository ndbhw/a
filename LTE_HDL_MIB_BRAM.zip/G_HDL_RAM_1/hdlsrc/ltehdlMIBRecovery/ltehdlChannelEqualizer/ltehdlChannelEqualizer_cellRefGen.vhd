-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlChannelEqualizer;

ENTITY ltehdlChannelEqualizer_cellRefGen IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        enb_1_2_1                         :   IN    std_logic;
        Nsubframe                         :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        ofdmSymb                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        NcellID                           :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        enGold                            :   IN    std_logic;
        cellDetected                      :   IN    std_logic;
        cellRef_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        cellRef_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        outValid                          :   OUT   std_logic
        );
END ltehdlChannelEqualizer_cellRefGen;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_cellRefGen IS

  -- Component Declarations
  COMPONENT ltehdlChannelEqualizer_trigger_cinit_load
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          cellDetected                    :   IN    std_logic;
          ofdmSymb                        :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          subframe                        :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          load                            :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlChannelEqualizer_c_initGen
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          NSubframe                       :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          ofdmSymb                        :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          NcellID                         :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          Ncp                             :   IN    std_logic;
          cinit                           :   OUT   std_logic_vector(30 DOWNTO 0)  -- ufix31
          );
  END COMPONENT;

  COMPONENT ltehdlChannelEqualizer_LTE_Gold_Seq_upsampling
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          load                            :   IN    std_logic;
          cinit                           :   IN    std_logic_vector(30 DOWNTO 0);  -- ufix31
          en_GoldCode                     :   IN    std_logic;
          gold                            :   OUT   std_logic;
          valid                           :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlChannelEqualizer_downsampling_seq2complex
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          enb_1_2_1                       :   IN    std_logic;
          sequence_rsvd                   :   IN    std_logic;
          valid                           :   IN    std_logic;
          complex_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          complex_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlChannelEqualizer_trigger_cinit_load
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_trigger_cinit_load(rtl);

  FOR ALL : ltehdlChannelEqualizer_c_initGen
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_c_initGen(rtl);

  FOR ALL : ltehdlChannelEqualizer_LTE_Gold_Seq_upsampling
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_LTE_Gold_Seq_upsampling(rtl);

  FOR ALL : ltehdlChannelEqualizer_downsampling_seq2complex
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_downsampling_seq2complex(rtl);

  -- Signals
  SIGNAL goldLoad                         : std_logic;
  SIGNAL Constant1_out1                   : std_logic;
  SIGNAL c_initGen_cinit                  : std_logic_vector(30 DOWNTO 0);  -- ufix31
  SIGNAL HDL_Counter_out1                 : std_logic := '0';  -- ufix1
  SIGNAL count                            : std_logic;  -- ufix1
  SIGNAL need_to_wrap                     : std_logic;
  SIGNAL count_value                      : std_logic;  -- ufix1
  SIGNAL count_1                          : std_logic;  -- ufix1
  SIGNAL count_2                          : std_logic;  -- ufix1
  SIGNAL NOT_out1                         : std_logic;
  SIGNAL enGoldDown                       : std_logic;
  SIGNAL LTE_Gold_Seq_upsampling_gold     : std_logic;
  SIGNAL LTE_Gold_Seq_upsampling_valid    : std_logic;
  SIGNAL downsampling_seq2complex_complex_re : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL downsampling_seq2complex_complex_im : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL downsampling_seq2complex_validOut : std_logic;
  SIGNAL downsampling_seq2complex_complex_re_signed : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL downsampling_seq2complex_complex_im_signed : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay2_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay2_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay1_reg_rsvd                  : std_logic_vector(2 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [3]
  SIGNAL Delay1_out1                      : std_logic;
  SIGNAL Delay3_out1                      : std_logic := '0';

BEGIN
  Utrigger_cinit_load : ltehdlChannelEqualizer_trigger_cinit_load
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              cellDetected => cellDetected,
              ofdmSymb => ofdmSymb,  -- ufix4
              subframe => Nsubframe,  -- ufix4
              load => goldLoad
              );

  Uc_initGen : ltehdlChannelEqualizer_c_initGen
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              NSubframe => Nsubframe,  -- ufix4
              ofdmSymb => ofdmSymb,  -- ufix4
              NcellID => NcellID,  -- ufix9
              Ncp => Constant1_out1,
              cinit => c_initGen_cinit  -- ufix31
              );

  ULTE_Gold_Seq_upsampling : ltehdlChannelEqualizer_LTE_Gold_Seq_upsampling
    PORT MAP( clk => clk,
              enb => enb,
              load => goldLoad,
              cinit => c_initGen_cinit,  -- ufix31
              en_GoldCode => enGoldDown,
              gold => LTE_Gold_Seq_upsampling_gold,
              valid => LTE_Gold_Seq_upsampling_valid
              );

  Udownsampling_seq2complex : ltehdlChannelEqualizer_downsampling_seq2complex
    PORT MAP( clk => clk,
              enb => enb,
              enb_1_2_1 => enb_1_2_1,
              sequence_rsvd => LTE_Gold_Seq_upsampling_gold,
              valid => LTE_Gold_Seq_upsampling_valid,
              complex_re => downsampling_seq2complex_complex_re,  -- sfix16_En15
              complex_im => downsampling_seq2complex_complex_im,  -- sfix16_En15
              validOut => downsampling_seq2complex_validOut
              );

  Constant1_out1 <= '1';

  -- Count limited, Unsigned Counter
  --  initial value   = 0
  --  step value      = 1
  --  count to value  = 1
  count <= HDL_Counter_out1 XOR '1';

  
  need_to_wrap <= '1' WHEN HDL_Counter_out1 = '1' ELSE
      '0';

  
  count_value <= count WHEN need_to_wrap = '0' ELSE
      '0';

  
  count_1 <= HDL_Counter_out1 WHEN enGold = '0' ELSE
      count_value;

  
  count_2 <= count_1 WHEN goldLoad = '0' ELSE
      '0';

  HDL_Counter_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        HDL_Counter_out1 <= count_2;
      END IF;
    END IF;
  END PROCESS HDL_Counter_process;


  NOT_out1 <=  NOT HDL_Counter_out1;

  enGoldDown <= NOT_out1 AND enGold;

  downsampling_seq2complex_complex_re_signed <= signed(downsampling_seq2complex_complex_re);

  downsampling_seq2complex_complex_im_signed <= signed(downsampling_seq2complex_complex_im);

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' AND downsampling_seq2complex_validOut = '1' THEN
        Delay2_out1_re <= downsampling_seq2complex_complex_re_signed;
        Delay2_out1_im <= downsampling_seq2complex_complex_im_signed;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  cellRef_re <= std_logic_vector(Delay2_out1_re);

  cellRef_im <= std_logic_vector(Delay2_out1_im);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_reg_rsvd(0) <= enGold;
        Delay1_reg_rsvd(2 DOWNTO 1) <= Delay1_reg_rsvd(1 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS Delay1_process;

  Delay1_out1 <= Delay1_reg_rsvd(2);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay3_out1 <= Delay1_out1;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  outValid <= Delay3_out1;

END rtl;

