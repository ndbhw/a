-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlChannelEqualizer_ltehdlChannelEqualizer_pac.ALL;

ENTITY ltehdlChannelEqualizer_mod3HDL IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        cellID                            :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        reminder                          :   OUT   std_logic_vector(15 DOWNTO 0)  -- uint16
        );
END ltehdlChannelEqualizer_mod3HDL;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_mod3HDL IS

  -- Signals
  SIGNAL cellID_unsigned                  : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Delay_rsvd_reg_rsvd              : vector_of_unsigned9(0 TO 3) := (OTHERS => to_unsigned(16#000#, 9));  -- ufix9 [4]
  SIGNAL Delay_out1                       : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Product1_mul_temp                : signed(25 DOWNTO 0);  -- sfix26_En15
  SIGNAL Product1_cast                    : signed(24 DOWNTO 0);  -- sfix25_En15
  SIGNAL Product1_out1                    : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Delay4_reg_rsvd                  : vector_of_unsigned9(0 TO 1) := (OTHERS => to_unsigned(16#000#, 9));  -- ufix9 [2]
  SIGNAL Delay4_out1                      : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Product2_out1                    : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Delay6_reg_rsvd                  : vector_of_unsigned9(0 TO 1) := (OTHERS => to_unsigned(16#000#, 9));  -- ufix9 [2]
  SIGNAL Delay6_out1                      : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Subtract_out1                    : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Delay10_out1                     : unsigned(8 DOWNTO 0) := to_unsigned(16#000#, 9);  -- ufix9
  SIGNAL switch_compare_1                 : std_logic;
  SIGNAL Delay10_out1_dtc                 : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Switch_out1                      : unsigned(15 DOWNTO 0);  -- uint16

BEGIN
  cellID_unsigned <= unsigned(cellID);

  Delay_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay_rsvd_reg_rsvd(0) <= cellID_unsigned;
        Delay_rsvd_reg_rsvd(1 TO 3) <= Delay_rsvd_reg_rsvd(0 TO 2);
      END IF;
    END IF;
  END PROCESS Delay_rsvd_process;

  Delay_out1 <= Delay_rsvd_reg_rsvd(3);

  Product1_mul_temp <= signed(resize(cellID_unsigned, 10)) * to_signed(16#2AAB#, 16);
  Product1_cast <= Product1_mul_temp(24 DOWNTO 0);
  Product1_out1 <= unsigned(Product1_cast(23 DOWNTO 15));

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay4_reg_rsvd(0) <= Product1_out1;
        Delay4_reg_rsvd(1) <= Delay4_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay4_process;

  Delay4_out1 <= Delay4_reg_rsvd(1);

  Product2_out1 <= resize(Delay4_out1 * to_unsigned(16#3#, 3), 9);

  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay6_reg_rsvd(0) <= Product2_out1;
        Delay6_reg_rsvd(1) <= Delay6_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay6_process;

  Delay6_out1 <= Delay6_reg_rsvd(1);

  Subtract_out1 <= Delay_out1 - Delay6_out1;

  Delay10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay10_out1 <= Subtract_out1;
      END IF;
    END IF;
  END PROCESS Delay10_process;


  
  switch_compare_1 <= '1' WHEN Delay10_out1 > to_unsigned(16#002#, 9) ELSE
      '0';

  Delay10_out1_dtc <= resize(Delay10_out1, 16);

  
  Switch_out1 <= Delay10_out1_dtc WHEN switch_compare_1 = '0' ELSE
      to_unsigned(16#0000#, 16);

  reminder <= std_logic_vector(Switch_out1);

END rtl;

