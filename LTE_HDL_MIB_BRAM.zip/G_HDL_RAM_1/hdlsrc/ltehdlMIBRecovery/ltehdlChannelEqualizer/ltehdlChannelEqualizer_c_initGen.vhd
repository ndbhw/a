-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlChannelEqualizer_ltehdlChannelEqualizer_pac.ALL;

ENTITY ltehdlChannelEqualizer_c_initGen IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        NSubframe                         :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        ofdmSymb                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        NcellID                           :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        Ncp                               :   IN    std_logic;
        cinit                             :   OUT   std_logic_vector(30 DOWNTO 0)  -- ufix31
        );
END ltehdlChannelEqualizer_c_initGen;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_c_initGen IS

  -- Signals
  SIGNAL ofdmSymb_unsigned                : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL NSubframe_unsigned               : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL dtc1                             : std_logic;  -- ufix1_E2
  SIGNAL Extract_Bits_out1                : std_logic;  -- ufix1
  SIGNAL Switch_out1                      : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL Switch4_out1                     : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL Switch1_out1                     : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL Switch2_out1                     : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL Switch5_out1                     : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL Switch3_out1                     : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL Multiport_Switch_out1            : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL NcellID_unsigned                 : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Data_Type_Conversion1_out1       : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL Bit_Shift1_out1                  : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL Add2_out1                        : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL Product_out1                     : unsigned(30 DOWNTO 0);  -- ufix31
  SIGNAL Delay6_reg_rsvd                  : vector_of_unsigned10(0 TO 1) := (OTHERS => to_unsigned(16#000#, 10));  -- ufix10 [2]
  SIGNAL Delay6_out1                      : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL Delay2_reg_rsvd                  : vector_of_unsigned31(0 TO 1) := (OTHERS => to_unsigned(16#00000000#, 31));  -- ufix31 [2]
  SIGNAL Delay2_out1                      : unsigned(30 DOWNTO 0);  -- ufix31
  SIGNAL Bit_Shift3_out1                  : unsigned(30 DOWNTO 0);  -- ufix31
  SIGNAL Delay12_reg_rsvd                 : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [2]
  SIGNAL Delay12_out1                     : std_logic;
  SIGNAL Add4_out1                        : unsigned(30 DOWNTO 0);  -- ufix31
  SIGNAL Add5_out1                        : unsigned(30 DOWNTO 0);  -- ufix31

BEGIN
  -- See 36.211 section 6.10.1.1 for Cinit calculation

  ofdmSymb_unsigned <= unsigned(ofdmSymb);

  NSubframe_unsigned <= unsigned(NSubframe);

  dtc1 <= NSubframe_unsigned(2);

  Extract_Bits_out1 <= dtc1;

  -- subframe 0 symbol 0
  -- subframe 5 symbol 0
  
  Switch_out1 <= to_unsigned(16#08#, 7) WHEN Extract_Bits_out1 = '0' ELSE
      to_unsigned(16#4E#, 7);

  -- subframe 0 symbol 1
  -- subframe 5 symbol 1
  
  Switch4_out1 <= to_unsigned(16#09#, 7) WHEN Extract_Bits_out1 = '0' ELSE
      to_unsigned(16#4F#, 7);

  -- subframe 0 symbol 4
  -- subframe 5 symbol 4
  
  Switch1_out1 <= to_unsigned(16#0C#, 7) WHEN Extract_Bits_out1 = '0' ELSE
      to_unsigned(16#52#, 7);

  -- subframe 5 symbol 7
  -- subframe 0 symbol 7
  
  Switch2_out1 <= to_unsigned(16#0F#, 7) WHEN Extract_Bits_out1 = '0' ELSE
      to_unsigned(16#55#, 7);

  -- subframe 5 symbol 8
  -- subframe 0 symbol 8
  
  Switch5_out1 <= to_unsigned(16#10#, 7) WHEN Extract_Bits_out1 = '0' ELSE
      to_unsigned(16#56#, 7);

  -- subframe 5 symbol 11
  -- subframe 0 symbol 11
  
  Switch3_out1 <= to_unsigned(16#13#, 7) WHEN Extract_Bits_out1 = '0' ELSE
      to_unsigned(16#59#, 7);

  
  Multiport_Switch_out1 <= Switch_out1 WHEN ofdmSymb_unsigned = to_unsigned(16#0#, 4) ELSE
      Switch4_out1 WHEN ofdmSymb_unsigned = to_unsigned(16#1#, 4) ELSE
      to_unsigned(16#00#, 7) WHEN ofdmSymb_unsigned = to_unsigned(16#2#, 4) ELSE
      to_unsigned(16#00#, 7) WHEN ofdmSymb_unsigned = to_unsigned(16#3#, 4) ELSE
      Switch1_out1 WHEN ofdmSymb_unsigned = to_unsigned(16#4#, 4) ELSE
      to_unsigned(16#00#, 7) WHEN ofdmSymb_unsigned = to_unsigned(16#5#, 4) ELSE
      to_unsigned(16#00#, 7) WHEN ofdmSymb_unsigned = to_unsigned(16#6#, 4) ELSE
      Switch2_out1 WHEN ofdmSymb_unsigned = to_unsigned(16#7#, 4) ELSE
      Switch5_out1 WHEN ofdmSymb_unsigned = to_unsigned(16#8#, 4) ELSE
      to_unsigned(16#00#, 7) WHEN ofdmSymb_unsigned = to_unsigned(16#9#, 4) ELSE
      to_unsigned(16#00#, 7) WHEN ofdmSymb_unsigned = to_unsigned(16#A#, 4) ELSE
      Switch3_out1 WHEN ofdmSymb_unsigned = to_unsigned(16#B#, 4) ELSE
      to_unsigned(16#00#, 7) WHEN ofdmSymb_unsigned = to_unsigned(16#C#, 4) ELSE
      to_unsigned(16#00#, 7);

  NcellID_unsigned <= unsigned(NcellID);

  Data_Type_Conversion1_out1 <= resize(NcellID_unsigned, 10);

  Bit_Shift1_out1 <= Data_Type_Conversion1_out1 sll 1;

  Add2_out1 <= Bit_Shift1_out1 + to_unsigned(16#001#, 10);

  Product_out1 <= resize(Multiport_Switch_out1 * Add2_out1, 31);

  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay6_reg_rsvd(0) <= Bit_Shift1_out1;
        Delay6_reg_rsvd(1) <= Delay6_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay6_process;

  Delay6_out1 <= Delay6_reg_rsvd(1);

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay2_reg_rsvd(0) <= Product_out1;
        Delay2_reg_rsvd(1) <= Delay2_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay2_process;

  Delay2_out1 <= Delay2_reg_rsvd(1);

  Bit_Shift3_out1 <= Delay2_out1 sll 10;

  Delay12_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay12_reg_rsvd(0) <= Ncp;
        Delay12_reg_rsvd(1) <= Delay12_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay12_process;

  Delay12_out1 <= Delay12_reg_rsvd(1);

  Add4_out1 <= resize(Delay6_out1 + ('0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & Delay12_out1), 31);

  Add5_out1 <= Bit_Shift3_out1 + Add4_out1;

  cinit <= std_logic_vector(Add5_out1);

END rtl;

