-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlChannelEqualizer_ltehdlChannelEqualizer_pac.ALL;

ENTITY ltehdlChannelEqualizer_mod3HDL1 IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        addr_in                           :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
        quotient                          :   OUT   std_logic_vector(15 DOWNTO 0);  -- uint16
        reminder                          :   OUT   std_logic_vector(15 DOWNTO 0)  -- uint16
        );
END ltehdlChannelEqualizer_mod3HDL1;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_mod3HDL1 IS

  -- Signals
  SIGNAL addr_in_unsigned                 : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL Delay3_out1                      : unsigned(10 DOWNTO 0) := to_unsigned(16#000#, 11);  -- ufix11
  SIGNAL Delay_rsvd_reg_rsvd              : vector_of_unsigned11(0 TO 4) := (OTHERS => to_unsigned(16#000#, 11));  -- ufix11 [5]
  SIGNAL Delay_out1                       : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL Delay12_out1                     : unsigned(10 DOWNTO 0) := to_unsigned(16#000#, 11);  -- ufix11
  SIGNAL Product1_mul_temp                : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Product1_cast                    : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL Product1_out1                    : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL Delay4_reg_rsvd                  : vector_of_unsigned11(0 TO 1) := (OTHERS => to_unsigned(16#000#, 11));  -- ufix11 [2]
  SIGNAL Delay4_out1                      : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL Delay5_out1                      : unsigned(10 DOWNTO 0) := to_unsigned(16#000#, 11);  -- ufix11
  SIGNAL Product2_out1                    : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL Delay6_reg_rsvd                  : vector_of_unsigned11(0 TO 1) := (OTHERS => to_unsigned(16#000#, 11));  -- ufix11 [2]
  SIGNAL Delay6_out1                      : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL Delay11_out1                     : unsigned(10 DOWNTO 0) := to_unsigned(16#000#, 11);  -- ufix11
  SIGNAL Subtract_out1                    : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL Delay10_out1                     : unsigned(10 DOWNTO 0) := to_unsigned(16#000#, 11);  -- ufix11
  SIGNAL switch_compare_1                 : std_logic;
  SIGNAL Delay2_reg_rsvd                  : vector_of_unsigned11(0 TO 4) := (OTHERS => to_unsigned(16#000#, 11));  -- ufix11 [5]
  SIGNAL Delay2_out1                      : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL Delay2_out1_dtc                  : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Delay13_reg_rsvd                 : vector_of_unsigned11(0 TO 2) := (OTHERS => to_unsigned(16#000#, 11));  -- ufix11 [3]
  SIGNAL Delay13_out1                     : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL Delay1_out1                      : unsigned(10 DOWNTO 0) := to_unsigned(16#000#, 11);  -- ufix11
  SIGNAL Add_out1                         : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Delay7_out1                      : unsigned(15 DOWNTO 0) := to_unsigned(16#0000#, 16);  -- uint16
  SIGNAL Switch1_out1                     : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL switch_compare_1_1               : std_logic;
  SIGNAL Delay10_out1_dtc                 : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Switch_out1                      : unsigned(15 DOWNTO 0);  -- uint16

BEGIN
  addr_in_unsigned <= unsigned(addr_in);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay3_out1 <= addr_in_unsigned;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  Delay_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay_rsvd_reg_rsvd(0) <= Delay3_out1;
        Delay_rsvd_reg_rsvd(1 TO 4) <= Delay_rsvd_reg_rsvd(0 TO 3);
      END IF;
    END IF;
  END PROCESS Delay_rsvd_process;

  Delay_out1 <= Delay_rsvd_reg_rsvd(4);

  Delay12_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay12_out1 <= Delay_out1;
      END IF;
    END IF;
  END PROCESS Delay12_process;


  Product1_mul_temp <= signed(resize(Delay3_out1, 12)) * to_signed(16#2AAB#, 16);
  Product1_cast <= Product1_mul_temp(26 DOWNTO 0);
  Product1_out1 <= unsigned(Product1_cast(25 DOWNTO 15));

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay4_reg_rsvd(0) <= Product1_out1;
        Delay4_reg_rsvd(1) <= Delay4_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay4_process;

  Delay4_out1 <= Delay4_reg_rsvd(1);

  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay5_out1 <= Delay4_out1;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  Product2_out1 <= resize(Delay5_out1 * to_unsigned(16#003#, 11), 11);

  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay6_reg_rsvd(0) <= Product2_out1;
        Delay6_reg_rsvd(1) <= Delay6_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay6_process;

  Delay6_out1 <= Delay6_reg_rsvd(1);

  Delay11_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay11_out1 <= Delay6_out1;
      END IF;
    END IF;
  END PROCESS Delay11_process;


  Subtract_out1 <= Delay12_out1 - Delay11_out1;

  Delay10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay10_out1 <= Subtract_out1;
      END IF;
    END IF;
  END PROCESS Delay10_process;


  
  switch_compare_1 <= '1' WHEN Delay10_out1 > to_unsigned(16#002#, 11) ELSE
      '0';

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay2_reg_rsvd(0) <= Delay4_out1;
        Delay2_reg_rsvd(1 TO 4) <= Delay2_reg_rsvd(0 TO 3);
      END IF;
    END IF;
  END PROCESS Delay2_process;

  Delay2_out1 <= Delay2_reg_rsvd(4);

  Delay2_out1_dtc <= resize(Delay2_out1, 16);

  Delay13_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay13_reg_rsvd(0) <= Delay4_out1;
        Delay13_reg_rsvd(1 TO 2) <= Delay13_reg_rsvd(0 TO 1);
      END IF;
    END IF;
  END PROCESS Delay13_process;

  Delay13_out1 <= Delay13_reg_rsvd(2);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_out1 <= Delay13_out1;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  Add_out1 <= resize(resize(Delay1_out1, 12) + to_unsigned(16#001#, 12), 16);

  Delay7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay7_out1 <= Add_out1;
      END IF;
    END IF;
  END PROCESS Delay7_process;


  
  Switch1_out1 <= Delay2_out1_dtc WHEN switch_compare_1 = '0' ELSE
      Delay7_out1;

  quotient <= std_logic_vector(Switch1_out1);

  
  switch_compare_1_1 <= '1' WHEN Delay10_out1 > to_unsigned(16#002#, 11) ELSE
      '0';

  Delay10_out1_dtc <= resize(Delay10_out1, 16);

  
  Switch_out1 <= Delay10_out1_dtc WHEN switch_compare_1_1 = '0' ELSE
      to_unsigned(16#0000#, 16);

  reminder <= std_logic_vector(Switch_out1);

END rtl;

