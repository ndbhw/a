-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlChannelEqualizer_MATLAB_Function IS
  PORT( u_u                               :   IN    std_logic_vector(30 DOWNTO 0);  -- ufix31
        y_y                               :   OUT   std_logic_vector(30 DOWNTO 0)  -- ufix31
        );
END ltehdlChannelEqualizer_MATLAB_Function;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_MATLAB_Function IS

  -- Signals
  SIGNAL u_unsigned                       : unsigned(30 DOWNTO 0);  -- ufix31
  SIGNAL y_tmp                            : unsigned(30 DOWNTO 0);  -- ufix31

BEGIN
  u_unsigned <= unsigned(u_u);

  y_tmp <= to_unsigned(16#00000001#, 31);

  y_y <= std_logic_vector(y_tmp);

END rtl;

