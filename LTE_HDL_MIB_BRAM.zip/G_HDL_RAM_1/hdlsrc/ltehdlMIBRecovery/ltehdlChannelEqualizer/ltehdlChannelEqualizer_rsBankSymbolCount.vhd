-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlChannelEqualizer;

ENTITY ltehdlChannelEqualizer_rsBankSymbolCount IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        rsValid                           :   IN    std_logic;
        reset                             :   IN    std_logic;
        rsBank                            :   OUT   std_logic_vector(3 DOWNTO 0);  -- ufix4
        rsCount                           :   OUT   std_logic_vector(8 DOWNTO 0)  -- ufix9
        );
END ltehdlChannelEqualizer_rsBankSymbolCount;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_rsBankSymbolCount IS

  -- Component Declarations
  COMPONENT ltehdlChannelEqualizer_Detect_Rise_Positive
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          U_U                             :   IN    std_logic;
          Y_Y                             :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlChannelEqualizer_Detect_Rise_Positive
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_Detect_Rise_Positive(rtl);

  -- Signals
  SIGNAL rsCount_tmp                      : unsigned(8 DOWNTO 0) := to_unsigned(16#000#, 9);  -- ufix9
  SIGNAL count                            : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL need_to_wrap                     : std_logic;
  SIGNAL count_value                      : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL count_1                          : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL fullOFDMSymb                     : std_logic;
  SIGNAL Delay2_out1                      : std_logic := '0';
  SIGNAL OR_out1                          : std_logic;
  SIGNAL count_2                          : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Detect_Rise_Positive_Y           : std_logic;
  SIGNAL Symb_Counter_out1                : unsigned(2 DOWNTO 0) := to_unsigned(16#0#, 3);  -- ufix3
  SIGNAL count_3                          : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL need_to_wrap_1                   : std_logic;
  SIGNAL count_value_1                    : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL count_4                          : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL count_5                          : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL rsBank_1                         : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL Delay1_out1                      : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4

BEGIN
  UDetect_Rise_Positive : ltehdlChannelEqualizer_Detect_Rise_Positive
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              U_U => fullOFDMSymb,
              Y_Y => Detect_Rise_Positive_Y
              );

  -- Count limited, Unsigned Counter
  --  initial value   = 0
  --  step value      = 1
  --  count to value  = 440
  count <= rsCount_tmp + to_unsigned(16#001#, 9);

  
  need_to_wrap <= '1' WHEN rsCount_tmp = to_unsigned(16#1B8#, 9) ELSE
      '0';

  
  count_value <= count WHEN need_to_wrap = '0' ELSE
      to_unsigned(16#000#, 9);

  
  count_1 <= rsCount_tmp WHEN rsValid = '0' ELSE
      count_value;

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay2_out1 <= fullOFDMSymb;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  OR_out1 <= Delay2_out1 OR reset;

  
  count_2 <= count_1 WHEN OR_out1 = '0' ELSE
      to_unsigned(16#000#, 9);

  RS_Counter_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        rsCount_tmp <= count_2;
      END IF;
    END IF;
  END PROCESS RS_Counter_process;


  
  fullOFDMSymb <= '1' WHEN rsCount_tmp = to_unsigned(16#1B8#, 9) ELSE
      '0';

  -- Count limited, Unsigned Counter
  --  initial value   = 0
  --  step value      = 1
  --  count to value  = 5
  count_3 <= Symb_Counter_out1 + to_unsigned(16#1#, 3);

  
  need_to_wrap_1 <= '1' WHEN Symb_Counter_out1 = to_unsigned(16#5#, 3) ELSE
      '0';

  
  count_value_1 <= count_3 WHEN need_to_wrap_1 = '0' ELSE
      to_unsigned(16#0#, 3);

  
  count_4 <= Symb_Counter_out1 WHEN Detect_Rise_Positive_Y = '0' ELSE
      count_value_1;

  
  count_5 <= count_4 WHEN reset = '0' ELSE
      to_unsigned(16#0#, 3);

  Symb_Counter_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Symb_Counter_out1 <= count_5;
      END IF;
    END IF;
  END PROCESS Symb_Counter_process;


  
  rsBank_1 <= to_unsigned(16#0#, 4) WHEN Symb_Counter_out1 = to_unsigned(16#0#, 3) ELSE
      to_unsigned(16#1#, 4) WHEN Symb_Counter_out1 = to_unsigned(16#1#, 3) ELSE
      to_unsigned(16#4#, 4) WHEN Symb_Counter_out1 = to_unsigned(16#2#, 3) ELSE
      to_unsigned(16#7#, 4) WHEN Symb_Counter_out1 = to_unsigned(16#3#, 3) ELSE
      to_unsigned(16#8#, 4) WHEN Symb_Counter_out1 = to_unsigned(16#4#, 3) ELSE
      to_unsigned(16#B#, 4);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_out1 <= rsBank_1;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  rsBank <= std_logic_vector(Delay1_out1);

  rsCount <= std_logic_vector(rsCount_tmp);

END rtl;

