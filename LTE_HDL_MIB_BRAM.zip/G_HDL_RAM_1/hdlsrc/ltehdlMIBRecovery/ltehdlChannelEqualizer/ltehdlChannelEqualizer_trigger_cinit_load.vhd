-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlChannelEqualizer_trigger_cinit_load IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        cellDetected                      :   IN    std_logic;
        ofdmSymb                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        subframe                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        load                              :   OUT   std_logic
        );
END ltehdlChannelEqualizer_trigger_cinit_load;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_trigger_cinit_load IS

  -- Signals
  SIGNAL ofdmSymb_unsigned                : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL Delay_out1                       : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL Equal_out1                       : std_logic;
  SIGNAL subframe_unsigned                : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL Delay1_out1                      : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL Equal1_out1                      : std_logic;
  SIGNAL OR_out1                          : std_logic;
  SIGNAL Delay2_reg_rsvd                  : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [2]
  SIGNAL Delay2_out1                      : std_logic;

BEGIN
  ofdmSymb_unsigned <= unsigned(ofdmSymb);

  Delay_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay_out1 <= ofdmSymb_unsigned;
      END IF;
    END IF;
  END PROCESS Delay_rsvd_process;


  
  Equal_out1 <= '1' WHEN ofdmSymb_unsigned /= Delay_out1 ELSE
      '0';

  subframe_unsigned <= unsigned(subframe);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_out1 <= subframe_unsigned;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  
  Equal1_out1 <= '1' WHEN subframe_unsigned /= Delay1_out1 ELSE
      '0';

  OR_out1 <= Equal1_out1 OR (cellDetected OR Equal_out1);

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay2_reg_rsvd(0) <= OR_out1;
        Delay2_reg_rsvd(1) <= Delay2_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay2_process;

  Delay2_out1 <= Delay2_reg_rsvd(1);

  load <= Delay2_out1;

END rtl;

