-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlChannelEqualizer;

ENTITY ltehdlChannelEqualizer_chEst IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        rxRS_re                           :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        rxRS_im                           :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        refRS_re                          :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        refRS_im                          :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        rsValid                           :   IN    std_logic;
        rsbank                            :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        rscount                           :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        cellID                            :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        ndlrb                             :   IN    std_logic_vector(6 DOWNTO 0);  -- ufix7
        hestRdAddr                        :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
        hestRdEnable                      :   IN    std_logic;
        reset                             :   IN    std_logic;
        hEst_a0_re                        :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        hEst_a0_im                        :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        hEst_a1_re                        :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        hEst_a1_im                        :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
        hEstValid                         :   OUT   std_logic
        );
END ltehdlChannelEqualizer_chEst;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_chEst IS

  -- Component Declarations
  COMPONENT ltehdlChannelEqualizer_mod3HDL
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          cellID                          :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          reminder                        :   OUT   std_logic_vector(15 DOWNTO 0)  -- uint16
          );
  END COMPONENT;

  COMPONENT ltehdlChannelEqualizer_mod6HDL
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          cellID                          :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          reminder                        :   OUT   std_logic_vector(15 DOWNTO 0)  -- uint16
          );
  END COMPONENT;

  COMPONENT ltehdlChannelEqualizer_hEstControl
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          reset                           :   IN    std_logic;
          hestRS_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          hestRS_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          rsValid                         :   IN    std_logic;
          ofdmSymbol                      :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          rsCount                         :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          cellMod3                        :   IN    std_logic_vector(15 DOWNTO 0);  -- uint16
          cellMod6                        :   IN    std_logic_vector(15 DOWNTO 0);  -- uint16
          ndlrb                           :   IN    std_logic_vector(6 DOWNTO 0);  -- ufix7
          rsData_re                       :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          rsData_im                       :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          addr                            :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
          wrtEnA0                         :   OUT   std_logic;
          wrtEnA1                         :   OUT   std_logic;
          doAverage                       :   OUT   std_logic;
          isFirstRS                       :   OUT   std_logic;
          isLastRS                        :   OUT   std_logic;
          doInterp                        :   OUT   std_logic;
          addrBias                        :   OUT   std_logic_vector(1 DOWNTO 0)  -- ufix2
          );
  END COMPONENT;

  COMPONENT ltehdlChannelEqualizer_hEstInterpAndStore_block
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          rsData_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          rsData_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          addr                            :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          wrtA0                           :   IN    std_logic;
          wrtA1                           :   IN    std_logic;
          doAverage                       :   IN    std_logic;
          isFirstRS                       :   IN    std_logic;
          isLastRS                        :   IN    std_logic;
          doInterp                        :   IN    std_logic;
          addrBias                        :   IN    std_logic_vector(1 DOWNTO 0);  -- ufix2
          readAddress                     :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
          readEnable                      :   IN    std_logic;
          hEst_a0_re                      :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          hEst_a0_im                      :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          hEst_a1_re                      :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          hEst_a1_im                      :   OUT   std_logic_vector(16 DOWNTO 0);  -- sfix17_En16
          hEstValid                       :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlChannelEqualizer_mod3HDL
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_mod3HDL(rtl);

  FOR ALL : ltehdlChannelEqualizer_mod6HDL
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_mod6HDL(rtl);

  FOR ALL : ltehdlChannelEqualizer_hEstControl
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_hEstControl(rtl);

  FOR ALL : ltehdlChannelEqualizer_hEstInterpAndStore_block
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_hEstInterpAndStore_block(rtl);

  -- Signals
  SIGNAL rxRS_re_signed                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL rxRS_im_signed                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL refRS_re_signed                  : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL refRS_im_signed                  : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Product_rsvd_mul_temp            : signed(31 DOWNTO 0);  -- sfix32_En30
  SIGNAL Product_rsvd_mul_temp_1          : signed(31 DOWNTO 0);  -- sfix32_En30
  SIGNAL Product_rsvd_mul_temp_2          : signed(31 DOWNTO 0);  -- sfix32_En30
  SIGNAL Product_rsvd_mul_temp_3          : signed(31 DOWNTO 0);  -- sfix32_En30
  SIGNAL Product_out1_re                  : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Product_out1_im                  : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL mod3HDL_reminder                 : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL mod6HDL_reminder                 : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL rsData_re                        : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL rsData_im                        : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL addr                             : std_logic_vector(8 DOWNTO 0);  -- ufix9
  SIGNAL wrtEnA0                          : std_logic;
  SIGNAL wrtEnA1                          : std_logic;
  SIGNAL doAverage                        : std_logic;
  SIGNAL isFirstRS                        : std_logic;
  SIGNAL isLastRS                         : std_logic;
  SIGNAL doInterp                         : std_logic;
  SIGNAL addrBias                         : std_logic_vector(1 DOWNTO 0);  -- ufix2
  SIGNAL hEstInterpAndStore_hEst_a0_re    : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL hEstInterpAndStore_hEst_a0_im    : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL hEstInterpAndStore_hEst_a1_re    : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL hEstInterpAndStore_hEst_a1_im    : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL hEstInterpAndStore_hEstValid     : std_logic;

BEGIN
  Umod3HDL : ltehdlChannelEqualizer_mod3HDL
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              cellID => cellID,  -- ufix9
              reminder => mod3HDL_reminder  -- uint16
              );

  Umod6HDL : ltehdlChannelEqualizer_mod6HDL
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              cellID => cellID,  -- ufix9
              reminder => mod6HDL_reminder  -- uint16
              );

  UhEstControl : ltehdlChannelEqualizer_hEstControl
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb_1_2_0 => enb_1_2_0,
              reset => reset,
              hestRS_re => std_logic_vector(Product_out1_re),  -- sfix16_En15
              hestRS_im => std_logic_vector(Product_out1_im),  -- sfix16_En15
              rsValid => rsValid,
              ofdmSymbol => rsbank,  -- ufix4
              rsCount => rscount,  -- ufix9
              cellMod3 => mod3HDL_reminder,  -- uint16
              cellMod6 => mod6HDL_reminder,  -- uint16
              ndlrb => ndlrb,  -- ufix7
              rsData_re => rsData_re,  -- sfix16_En15
              rsData_im => rsData_im,  -- sfix16_En15
              addr => addr,  -- ufix9
              wrtEnA0 => wrtEnA0,
              wrtEnA1 => wrtEnA1,
              doAverage => doAverage,
              isFirstRS => isFirstRS,
              isLastRS => isLastRS,
              doInterp => doInterp,
              addrBias => addrBias  -- ufix2
              );

  UhEstInterpAndStore_1 : ltehdlChannelEqualizer_hEstInterpAndStore_block
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              rsData_re => rsData_re,  -- sfix16_En15
              rsData_im => rsData_im,  -- sfix16_En15
              addr => addr,  -- ufix9
              wrtA0 => wrtEnA0,
              wrtA1 => wrtEnA1,
              doAverage => doAverage,
              isFirstRS => isFirstRS,
              isLastRS => isLastRS,
              doInterp => doInterp,
              addrBias => addrBias,  -- ufix2
              readAddress => hestRdAddr,  -- ufix11
              readEnable => hestRdEnable,
              hEst_a0_re => hEstInterpAndStore_hEst_a0_re,  -- sfix17_En16
              hEst_a0_im => hEstInterpAndStore_hEst_a0_im,  -- sfix17_En16
              hEst_a1_re => hEstInterpAndStore_hEst_a1_re,  -- sfix17_En16
              hEst_a1_im => hEstInterpAndStore_hEst_a1_im,  -- sfix17_En16
              hEstValid => hEstInterpAndStore_hEstValid
              );

  rxRS_re_signed <= signed(rxRS_re);

  rxRS_im_signed <= signed(rxRS_im);

  refRS_re_signed <= signed(refRS_re);

  refRS_im_signed <= signed(refRS_im);

  Product_rsvd_mul_temp <= rxRS_re_signed * refRS_re_signed;
  Product_rsvd_mul_temp_1 <= rxRS_im_signed * refRS_im_signed;
  Product_out1_re <= Product_rsvd_mul_temp(30 DOWNTO 15) - Product_rsvd_mul_temp_1(30 DOWNTO 15);
  Product_rsvd_mul_temp_2 <= rxRS_im_signed * refRS_re_signed;
  Product_rsvd_mul_temp_3 <= rxRS_re_signed * refRS_im_signed;
  Product_out1_im <= Product_rsvd_mul_temp_2(30 DOWNTO 15) + Product_rsvd_mul_temp_3(30 DOWNTO 15);

  hEst_a0_re <= hEstInterpAndStore_hEst_a0_re;

  hEst_a0_im <= hEstInterpAndStore_hEst_a0_im;

  hEst_a1_re <= hEstInterpAndStore_hEst_a1_re;

  hEst_a1_im <= hEstInterpAndStore_hEst_a1_im;

  hEstValid <= hEstInterpAndStore_hEstValid;

END rtl;

