-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlChannelEqualizer;

ENTITY ltehdlChannelEqualizer_addr_mapper IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        addrBias                          :   IN    std_logic_vector(1 DOWNTO 0);  -- ufix2
        address                           :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
        enable                            :   IN    std_logic;
        memory_addr                       :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
        memory_num                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- uint16
        enOut                             :   OUT   std_logic
        );
END ltehdlChannelEqualizer_addr_mapper;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_addr_mapper IS

  -- Component Declarations
  COMPONENT ltehdlChannelEqualizer_mod3HDL1
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          addr_in                         :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
          quotient                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- uint16
          reminder                        :   OUT   std_logic_vector(15 DOWNTO 0)  -- uint16
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlChannelEqualizer_mod3HDL1
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_mod3HDL1(rtl);

  -- Signals
  SIGNAL address_unsigned                 : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL addrBias_unsigned                : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL Add_out1                         : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL mod3HDL1_quotient                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL mod3HDL1_reminder                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL mod3HDL1_quotient_unsigned       : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Data_Type_Conversion_out1        : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Delay1_out1                      : unsigned(8 DOWNTO 0) := to_unsigned(16#000#, 9);  -- ufix9
  SIGNAL Add1_out1                        : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL mod3HDL1_reminder_unsigned       : unsigned(15 DOWNTO 0);  -- uint16
  SIGNAL Delay3_out1                      : unsigned(15 DOWNTO 0) := to_unsigned(16#0000#, 16);  -- uint16
  SIGNAL Delay4_reg_rsvd                  : std_logic_vector(7 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [8]
  SIGNAL Delay4_out1                      : std_logic;
  SIGNAL Delay2_out1                      : std_logic := '0';

BEGIN
  Umod3HDL1 : ltehdlChannelEqualizer_mod3HDL1
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              addr_in => std_logic_vector(Add_out1),  -- ufix11
              quotient => mod3HDL1_quotient,  -- uint16
              reminder => mod3HDL1_reminder  -- uint16
              );

  address_unsigned <= unsigned(address);

  addrBias_unsigned <= unsigned(addrBias);

  Add_out1 <= address_unsigned + resize(addrBias_unsigned, 11);

  mod3HDL1_quotient_unsigned <= unsigned(mod3HDL1_quotient);

  Data_Type_Conversion_out1 <= mod3HDL1_quotient_unsigned(8 DOWNTO 0);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_out1 <= Data_Type_Conversion_out1;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  Add1_out1 <= Delay1_out1 + to_unsigned(16#001#, 9);

  memory_addr <= std_logic_vector(Add1_out1);

  mod3HDL1_reminder_unsigned <= unsigned(mod3HDL1_reminder);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay3_out1 <= mod3HDL1_reminder_unsigned;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  memory_num <= std_logic_vector(Delay3_out1);

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay4_reg_rsvd(0) <= enable;
        Delay4_reg_rsvd(7 DOWNTO 1) <= Delay4_reg_rsvd(6 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS Delay4_process;

  Delay4_out1 <= Delay4_reg_rsvd(7);

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay2_out1 <= Delay4_out1;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  enOut <= Delay2_out1;

END rtl;

