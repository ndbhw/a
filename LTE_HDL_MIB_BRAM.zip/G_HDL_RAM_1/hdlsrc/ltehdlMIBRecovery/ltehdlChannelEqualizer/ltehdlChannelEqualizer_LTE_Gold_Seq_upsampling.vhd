-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlChannelEqualizer;

ENTITY ltehdlChannelEqualizer_LTE_Gold_Seq_upsampling IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        load                              :   IN    std_logic;
        cinit                             :   IN    std_logic_vector(30 DOWNTO 0);  -- ufix31
        en_GoldCode                       :   IN    std_logic;
        gold                              :   OUT   std_logic;
        valid                             :   OUT   std_logic
        );
END ltehdlChannelEqualizer_LTE_Gold_Seq_upsampling;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_LTE_Gold_Seq_upsampling IS

  -- Component Declarations
  COMPONENT ltehdlChannelEqualizer_Gold_Sequence_Generator
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          Load                            :   IN    std_logic;
          Init                            :   IN    std_logic_vector(30 DOWNTO 0);  -- ufix31
          enable                          :   IN    std_logic;
          Out2                            :   OUT   std_logic;
          Out1                            :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlChannelEqualizer_Gold_Sequence_Generator
    USE ENTITY work_ltehdlChannelEqualizer.ltehdlChannelEqualizer_Gold_Sequence_Generator(rtl);

  -- Signals
  SIGNAL Repeat3_out1                     : std_logic;
  SIGNAL Repeat1_out1                     : unsigned(30 DOWNTO 0);  -- ufix31
  SIGNAL Repeat1_out1_1                   : std_logic_vector(30 DOWNTO 0);  -- ufix31
  SIGNAL Repeat2_out1                     : std_logic;
  SIGNAL Gold_Sequence_Generator_Out2     : std_logic;
  SIGNAL Gold_Sequence_Generator_Out1     : std_logic;
  SIGNAL Delay1_out1                      : std_logic := '0';
  SIGNAL Delay_out1                       : std_logic := '0';

BEGIN
  UGold_Sequence_Generator : ltehdlChannelEqualizer_Gold_Sequence_Generator
    PORT MAP( clk => clk,
              enb => enb,
              Load => Repeat3_out1,
              Init => Repeat1_out1_1,  -- ufix31
              enable => Repeat2_out1,
              Out2 => Gold_Sequence_Generator_Out2,
              Out1 => Gold_Sequence_Generator_Out1
              );

  Repeat3_out1 <= load;

  Repeat1_out1 <= unsigned(cinit);

  Repeat1_out1_1 <= std_logic_vector(Repeat1_out1);

  Repeat2_out1 <= en_GoldCode;

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1 <= Gold_Sequence_Generator_Out2;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  Delay_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay_out1 <= Gold_Sequence_Generator_Out1;
      END IF;
    END IF;
  END PROCESS Delay_rsvd_process;


  gold <= Delay1_out1;

  valid <= Delay_out1;

END rtl;

