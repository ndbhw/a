-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlChannelEqualizer_downsampling_seq2complex IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        enb_1_2_1                         :   IN    std_logic;
        sequence_rsvd                     :   IN    std_logic;
        valid                             :   IN    std_logic;
        complex_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        complex_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validOut                          :   OUT   std_logic
        );
END ltehdlChannelEqualizer_downsampling_seq2complex;


ARCHITECTURE rtl OF ltehdlChannelEqualizer_downsampling_seq2complex IS

  -- Signals
  SIGNAL Delay3_out1                      : std_logic := '0';
  SIGNAL Delay1_out1                      : std_logic := '0';
  SIGNAL Downsample3_bypass_reg_rsvd      : std_logic := '0';  -- ufix1
  SIGNAL Downsample3_out1                 : std_logic;
  SIGNAL Switch1_out1                     : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Downsample2_bypass_reg_rsvd      : std_logic := '0';  -- ufix1
  SIGNAL Downsample2_out1                 : std_logic;
  SIGNAL Switch2_out1                     : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay4_out1                      : std_logic := '0';
  SIGNAL Downsample1_bypass_reg_rsvd      : std_logic := '0';  -- ufix1
  SIGNAL Downsample1_out1                 : std_logic;

BEGIN
  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1 <= sequence_rsvd;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1 <= Delay3_out1;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  -- Downsample3: Downsample by 2, Sample offset 0 
  -- Downsample bypass register
  Downsample3_bypass_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_1 = '1' THEN
        Downsample3_bypass_reg_rsvd <= Delay1_out1;
      END IF;
    END IF;
  END PROCESS Downsample3_bypass_process;

  
  Downsample3_out1 <= Delay1_out1 WHEN enb_1_2_1 = '1' ELSE
      Downsample3_bypass_reg_rsvd;

  
  Switch1_out1 <= to_signed(16#5A82#, 16) WHEN Downsample3_out1 = '0' ELSE
      to_signed(-16#5A82#, 16);

  complex_re <= std_logic_vector(Switch1_out1);

  -- Downsample2: Downsample by 2, Sample offset 0 
  -- Downsample bypass register
  Downsample2_bypass_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_1 = '1' THEN
        Downsample2_bypass_reg_rsvd <= Delay3_out1;
      END IF;
    END IF;
  END PROCESS Downsample2_bypass_process;

  
  Downsample2_out1 <= Delay3_out1 WHEN enb_1_2_1 = '1' ELSE
      Downsample2_bypass_reg_rsvd;

  
  Switch2_out1 <= to_signed(-16#5A82#, 16) WHEN Downsample2_out1 = '0' ELSE
      to_signed(16#5A82#, 16);

  complex_im <= std_logic_vector(Switch2_out1);

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay4_out1 <= valid;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  -- Downsample1: Downsample by 2, Sample offset 0 
  -- Downsample bypass register
  Downsample1_bypass_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_1 = '1' THEN
        Downsample1_bypass_reg_rsvd <= Delay4_out1;
      END IF;
    END IF;
  END PROCESS Downsample1_bypass_process;

  
  Downsample1_out1 <= Delay4_out1 WHEN enb_1_2_1 = '1' ELSE
      Downsample1_bypass_reg_rsvd;

  validOut <= Downsample1_out1;

END rtl;

