add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/HDL_LTE_MIB_Recovery_tc.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/Detect_Rise_Positive.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/Detect_Rise_Positive1.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/MIB_Decoder.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/HDL_LTE_MIB_Recovery.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/HDL_LTE_MIB_Recovery_tb_pac.vhd
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/HDL_LTE_MIB_Recovery_tb.vhd
