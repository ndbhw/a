-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_textio.ALL;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY STD;
USE STD.textio.ALL;
USE work.HDL_LTE_MIB_Recovery_tb_pac.ALL;

ENTITY HDL_LTE_MIB_Recovery_tb IS
END HDL_LTE_MIB_Recovery_tb;


ARCHITECTURE rtl OF HDL_LTE_MIB_Recovery_tb IS

  -- Component Declarations
  COMPONENT HDL_LTE_MIB_Recovery
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          clk_en                          :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          startIn                         :   IN    std_logic;
          ce_out                          :   OUT   std_logic;
          NCellID                         :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
          TDDMode                         :   OUT   std_logic;
          freqEst                         :   OUT   std_logic_vector(13 DOWNTO 0);  -- sfix14
          cellDetected                    :   OUT   std_logic;
          cellSearchDone                  :   OUT   std_logic;
          NDLRB                           :   OUT   std_logic_vector(6 DOWNTO 0);  -- ufix7
          PHICH                           :   OUT   std_logic;
          Ng                              :   OUT   std_logic_vector(1 DOWNTO 0);  -- ufix2
          NFrame                          :   OUT   std_logic_vector(9 DOWNTO 0);  -- ufix10
          CellRefP                        :   OUT   std_logic_vector(2 DOWNTO 0);  -- ufix3
          mibDetected                     :   OUT   std_logic;
          mibError                        :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : HDL_LTE_MIB_Recovery
    USE ENTITY work.HDL_LTE_MIB_Recovery(rtl);

  -- Signals
  SIGNAL clk                              : std_logic;
  SIGNAL n_rst                            : std_logic;
  SIGNAL clk_en                           : std_logic;
  SIGNAL rawData_validIn                  : std_logic;
  SIGNAL mibError_done                    : std_logic;  -- ufix1
  SIGNAL ce_out                           : std_logic;
  SIGNAL mibError_done_enb                : std_logic;  -- ufix1
  SIGNAL NCellID_addr                     : unsigned(20 DOWNTO 0);  -- ufix21
  SIGNAL mibError_lastAddr                : std_logic;  -- ufix1
  SIGNAL check12_done                     : std_logic;  -- ufix1
  SIGNAL mibDetected_done                 : std_logic;  -- ufix1
  SIGNAL mibDetected_done_enb             : std_logic;  -- ufix1
  SIGNAL mibDetected_lastAddr             : std_logic;  -- ufix1
  SIGNAL check11_done                     : std_logic;  -- ufix1
  SIGNAL CellRefP_done                    : std_logic;  -- ufix1
  SIGNAL CellRefP_done_enb                : std_logic;  -- ufix1
  SIGNAL CellRefP_lastAddr                : std_logic;  -- ufix1
  SIGNAL check10_done                     : std_logic;  -- ufix1
  SIGNAL NFrame_done                      : std_logic;  -- ufix1
  SIGNAL NFrame_done_enb                  : std_logic;  -- ufix1
  SIGNAL NFrame_lastAddr                  : std_logic;  -- ufix1
  SIGNAL check9_done                      : std_logic;  -- ufix1
  SIGNAL Ng_done                          : std_logic;  -- ufix1
  SIGNAL Ng_done_enb                      : std_logic;  -- ufix1
  SIGNAL Ng_lastAddr                      : std_logic;  -- ufix1
  SIGNAL check8_done                      : std_logic;  -- ufix1
  SIGNAL PHICH_done                       : std_logic;  -- ufix1
  SIGNAL PHICH_done_enb                   : std_logic;  -- ufix1
  SIGNAL PHICH_lastAddr                   : std_logic;  -- ufix1
  SIGNAL check7_done                      : std_logic;  -- ufix1
  SIGNAL NDLRB_done                       : std_logic;  -- ufix1
  SIGNAL NDLRB_done_enb                   : std_logic;  -- ufix1
  SIGNAL NDLRB_lastAddr                   : std_logic;  -- ufix1
  SIGNAL check6_done                      : std_logic;  -- ufix1
  SIGNAL cellSearchDone_done              : std_logic;  -- ufix1
  SIGNAL cellSearchDone_done_enb          : std_logic;  -- ufix1
  SIGNAL cellSearchDone_lastAddr          : std_logic;  -- ufix1
  SIGNAL check5_done                      : std_logic;  -- ufix1
  SIGNAL cellDetected_done                : std_logic;  -- ufix1
  SIGNAL cellDetected_done_enb            : std_logic;  -- ufix1
  SIGNAL cellDetected_lastAddr            : std_logic;  -- ufix1
  SIGNAL check4_done                      : std_logic;  -- ufix1
  SIGNAL freqEst_done                     : std_logic;  -- ufix1
  SIGNAL freqEst_done_enb                 : std_logic;  -- ufix1
  SIGNAL freqEst_lastAddr                 : std_logic;  -- ufix1
  SIGNAL check3_done                      : std_logic;  -- ufix1
  SIGNAL TDDMode_done                     : std_logic;  -- ufix1
  SIGNAL TDDMode_done_enb                 : std_logic;  -- ufix1
  SIGNAL TDDMode_lastAddr                 : std_logic;  -- ufix1
  SIGNAL check2_done                      : std_logic;  -- ufix1
  SIGNAL NCellID_done                     : std_logic;  -- ufix1
  SIGNAL NCellID_done_enb                 : std_logic;  -- ufix1
  SIGNAL NCellID_active                   : std_logic;  -- ufix1
  SIGNAL dataIn_addr                      : unsigned(20 DOWNTO 0);  -- ufix21
  SIGNAL startIn_addr_delay_1             : unsigned(20 DOWNTO 0);  -- ufix21
  SIGNAL tb_enb                           : std_logic;
  SIGNAL phase_1                          : std_logic;
  SIGNAL rawData_startIn                  : std_logic;
  SIGNAL holdData_startIn                 : std_logic;
  SIGNAL startIn_offset                   : std_logic;
  SIGNAL startIn                          : std_logic;
  SIGNAL holdData_validIn                 : std_logic;
  SIGNAL validIn_offset                   : std_logic;
  SIGNAL validIn_1                        : std_logic;
  SIGNAL dataIn_addr_delay                : unsigned(20 DOWNTO 0);  -- ufix21
  SIGNAL rawData_dataIn_im                : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL holdData_dataIn_im               : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_offset                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im                        : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_1                      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dataIn_active                    : std_logic;  -- ufix1
  SIGNAL tb_enb_delay                     : std_logic;
  SIGNAL counter                          : std_logic;  -- ufix1
  SIGNAL phase_1_ctr                      : std_logic;
  SIGNAL dataIn_enb                       : std_logic;  -- ufix1
  SIGNAL rawData_dataIn_re                : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL holdData_dataIn_re               : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_re_offset                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_re                        : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_re_1                      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL snkDone                          : std_logic;
  SIGNAL snkDonen                         : std_logic;
  SIGNAL notDone                          : std_logic;
  SIGNAL NCellID                          : std_logic_vector(8 DOWNTO 0);  -- ufix9
  SIGNAL TDDMode                          : std_logic;
  SIGNAL freqEst                          : std_logic_vector(13 DOWNTO 0);  -- ufix14
  SIGNAL cellDetected                     : std_logic;
  SIGNAL cellSearchDone                   : std_logic;
  SIGNAL NDLRB                            : std_logic_vector(6 DOWNTO 0);  -- ufix7
  SIGNAL PHICH                            : std_logic;
  SIGNAL Ng                               : std_logic_vector(1 DOWNTO 0);  -- ufix2
  SIGNAL NFrame                           : std_logic_vector(9 DOWNTO 0);  -- ufix10
  SIGNAL CellRefP                         : std_logic_vector(2 DOWNTO 0);  -- ufix3
  SIGNAL mibDetected                      : std_logic;
  SIGNAL mibError                         : std_logic;
  SIGNAL NCellID_enb                      : std_logic;  -- ufix1
  SIGNAL NCellID_lastAddr                 : std_logic;  -- ufix1
  SIGNAL check1_done                      : std_logic;  -- ufix1
  SIGNAL NCellID_unsigned                 : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL NCellID_addr_delay_1             : unsigned(20 DOWNTO 0);  -- ufix21
  SIGNAL NCellID_expected                 : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL NCellID_ref_hold                 : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL NCellID_ref                      : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL NCellID_testFailure              : std_logic;  -- ufix1
  SIGNAL TDDMode_expected_1               : std_logic;
  SIGNAL TDDMode_ref_hold                 : std_logic;
  SIGNAL TDDMode_ref                      : std_logic;
  SIGNAL TDDMode_testFailure              : std_logic;  -- ufix1
  SIGNAL freqEst_signed                   : signed(13 DOWNTO 0);  -- sfix14
  SIGNAL freqEst_addr_delay_1             : unsigned(20 DOWNTO 0);  -- ufix21
  SIGNAL freqEst_expected                 : signed(13 DOWNTO 0);  -- sfix14
  SIGNAL freqEst_ref_hold                 : signed(13 DOWNTO 0);  -- sfix14
  SIGNAL freqEst_ref                      : signed(13 DOWNTO 0);  -- sfix14
  SIGNAL freqEst_testFailure              : std_logic;  -- ufix1
  SIGNAL cellDetected_addr_delay_1        : unsigned(20 DOWNTO 0);  -- ufix21
  SIGNAL cellDetected_expected            : std_logic;
  SIGNAL cellDetected_ref_hold            : std_logic;
  SIGNAL cellDetected_ref                 : std_logic;
  SIGNAL cellDetected_testFailure         : std_logic;  -- ufix1
  SIGNAL cellSearchDone_addr_delay_1      : unsigned(20 DOWNTO 0);  -- ufix21
  SIGNAL cellSearchDone_expected          : std_logic;
  SIGNAL cellSearchDone_ref_hold          : std_logic;
  SIGNAL cellSearchDone_ref               : std_logic;
  SIGNAL cellSearchDone_testFailure       : std_logic;  -- ufix1
  SIGNAL NDLRB_unsigned                   : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL NDLRB_addr_delay_1               : unsigned(20 DOWNTO 0);  -- ufix21
  SIGNAL NDLRB_expected                   : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL NDLRB_ref_hold                   : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL NDLRB_ref                        : unsigned(6 DOWNTO 0);  -- ufix7
  SIGNAL NDLRB_testFailure                : std_logic;  -- ufix1
  SIGNAL PHICH_expected_1                 : std_logic;
  SIGNAL PHICH_ref_hold                   : std_logic;
  SIGNAL PHICH_ref                        : std_logic;
  SIGNAL PHICH_testFailure                : std_logic;  -- ufix1
  SIGNAL Ng_unsigned                      : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL Ng_addr_delay_1                  : unsigned(20 DOWNTO 0);  -- ufix21
  SIGNAL Ng_expected                      : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL Ng_ref_hold                      : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL Ng_ref                           : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL Ng_testFailure                   : std_logic;  -- ufix1
  SIGNAL NFrame_unsigned                  : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL NFrame_addr_delay_1              : unsigned(20 DOWNTO 0);  -- ufix21
  SIGNAL NFrame_expected                  : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL NFrame_ref_hold                  : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL NFrame_ref                       : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL NFrame_testFailure               : std_logic;  -- ufix1
  SIGNAL CellRefP_unsigned                : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL CellRefP_addr_delay_1            : unsigned(20 DOWNTO 0);  -- ufix21
  SIGNAL CellRefP_expected                : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL CellRefP_ref_hold                : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL CellRefP_ref                     : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL CellRefP_testFailure             : std_logic;  -- ufix1
  SIGNAL mibDetected_addr_delay_1         : unsigned(20 DOWNTO 0);  -- ufix21
  SIGNAL mibDetected_expected             : std_logic;
  SIGNAL mibDetected_ref_hold             : std_logic;
  SIGNAL mibDetected_ref                  : std_logic;
  SIGNAL mibDetected_testFailure          : std_logic;  -- ufix1
  SIGNAL mibError_expected_1              : std_logic;
  SIGNAL mibError_ref_hold                : std_logic;
  SIGNAL mibError_ref                     : std_logic;
  SIGNAL mibError_testFailure             : std_logic;  -- ufix1
  SIGNAL testFailure                      : std_logic;  -- ufix1

BEGIN
  u_HDL_LTE_MIB_Recovery : HDL_LTE_MIB_Recovery
    PORT MAP( clk => clk,
              n_rst => n_rst,
              clk_en => clk_en,
              dataIn_re => dataIn_re_1,  -- sfix16_En15
              dataIn_im => dataIn_im_1,  -- sfix16_En15
              validIn => validIn_1,
              startIn => startIn,
              ce_out => ce_out,
              NCellID => NCellID,  -- ufix9
              TDDMode => TDDMode,
              freqEst => freqEst,  -- sfix14
              cellDetected => cellDetected,
              cellSearchDone => cellSearchDone,
              NDLRB => NDLRB,  -- ufix7
              PHICH => PHICH,
              Ng => Ng,  -- ufix2
              NFrame => NFrame,  -- ufix10
              CellRefP => CellRefP,  -- ufix3
              mibDetected => mibDetected,
              mibError => mibError
              );

  -- Data source for validIn
  rawData_validIn <= '1';

  mibError_done_enb <= mibError_done AND ce_out;

  
  mibError_lastAddr <= '1' WHEN NCellID_addr >= to_unsigned(16#11B897#, 21) ELSE
      '0';

  mibError_done <= mibError_lastAddr AND n_rst;

  -- Delay to allow last sim cycle to complete
  checkDone_12_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        check12_done <= '0';
      ELSIF mibError_done_enb = '1' THEN
        check12_done <= mibError_done;
      END IF;
    END IF;
  END PROCESS checkDone_12_process;

  mibDetected_done_enb <= mibDetected_done AND ce_out;

  
  mibDetected_lastAddr <= '1' WHEN NCellID_addr >= to_unsigned(16#11B897#, 21) ELSE
      '0';

  mibDetected_done <= mibDetected_lastAddr AND n_rst;

  -- Delay to allow last sim cycle to complete
  checkDone_11_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        check11_done <= '0';
      ELSIF mibDetected_done_enb = '1' THEN
        check11_done <= mibDetected_done;
      END IF;
    END IF;
  END PROCESS checkDone_11_process;

  CellRefP_done_enb <= CellRefP_done AND ce_out;

  
  CellRefP_lastAddr <= '1' WHEN NCellID_addr >= to_unsigned(16#11B897#, 21) ELSE
      '0';

  CellRefP_done <= CellRefP_lastAddr AND n_rst;

  -- Delay to allow last sim cycle to complete
  checkDone_10_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        check10_done <= '0';
      ELSIF CellRefP_done_enb = '1' THEN
        check10_done <= CellRefP_done;
      END IF;
    END IF;
  END PROCESS checkDone_10_process;

  NFrame_done_enb <= NFrame_done AND ce_out;

  
  NFrame_lastAddr <= '1' WHEN NCellID_addr >= to_unsigned(16#11B897#, 21) ELSE
      '0';

  NFrame_done <= NFrame_lastAddr AND n_rst;

  -- Delay to allow last sim cycle to complete
  checkDone_9_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        check9_done <= '0';
      ELSIF NFrame_done_enb = '1' THEN
        check9_done <= NFrame_done;
      END IF;
    END IF;
  END PROCESS checkDone_9_process;

  Ng_done_enb <= Ng_done AND ce_out;

  
  Ng_lastAddr <= '1' WHEN NCellID_addr >= to_unsigned(16#11B897#, 21) ELSE
      '0';

  Ng_done <= Ng_lastAddr AND n_rst;

  -- Delay to allow last sim cycle to complete
  checkDone_8_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        check8_done <= '0';
      ELSIF Ng_done_enb = '1' THEN
        check8_done <= Ng_done;
      END IF;
    END IF;
  END PROCESS checkDone_8_process;

  PHICH_done_enb <= PHICH_done AND ce_out;

  
  PHICH_lastAddr <= '1' WHEN NCellID_addr >= to_unsigned(16#11B897#, 21) ELSE
      '0';

  PHICH_done <= PHICH_lastAddr AND n_rst;

  -- Delay to allow last sim cycle to complete
  checkDone_7_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        check7_done <= '0';
      ELSIF PHICH_done_enb = '1' THEN
        check7_done <= PHICH_done;
      END IF;
    END IF;
  END PROCESS checkDone_7_process;

  NDLRB_done_enb <= NDLRB_done AND ce_out;

  
  NDLRB_lastAddr <= '1' WHEN NCellID_addr >= to_unsigned(16#11B897#, 21) ELSE
      '0';

  NDLRB_done <= NDLRB_lastAddr AND n_rst;

  -- Delay to allow last sim cycle to complete
  checkDone_6_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        check6_done <= '0';
      ELSIF NDLRB_done_enb = '1' THEN
        check6_done <= NDLRB_done;
      END IF;
    END IF;
  END PROCESS checkDone_6_process;

  cellSearchDone_done_enb <= cellSearchDone_done AND ce_out;

  
  cellSearchDone_lastAddr <= '1' WHEN NCellID_addr >= to_unsigned(16#11B897#, 21) ELSE
      '0';

  cellSearchDone_done <= cellSearchDone_lastAddr AND n_rst;

  -- Delay to allow last sim cycle to complete
  checkDone_5_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        check5_done <= '0';
      ELSIF cellSearchDone_done_enb = '1' THEN
        check5_done <= cellSearchDone_done;
      END IF;
    END IF;
  END PROCESS checkDone_5_process;

  cellDetected_done_enb <= cellDetected_done AND ce_out;

  
  cellDetected_lastAddr <= '1' WHEN NCellID_addr >= to_unsigned(16#11B897#, 21) ELSE
      '0';

  cellDetected_done <= cellDetected_lastAddr AND n_rst;

  -- Delay to allow last sim cycle to complete
  checkDone_4_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        check4_done <= '0';
      ELSIF cellDetected_done_enb = '1' THEN
        check4_done <= cellDetected_done;
      END IF;
    END IF;
  END PROCESS checkDone_4_process;

  freqEst_done_enb <= freqEst_done AND ce_out;

  
  freqEst_lastAddr <= '1' WHEN NCellID_addr >= to_unsigned(16#11B897#, 21) ELSE
      '0';

  freqEst_done <= freqEst_lastAddr AND n_rst;

  -- Delay to allow last sim cycle to complete
  checkDone_3_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        check3_done <= '0';
      ELSIF freqEst_done_enb = '1' THEN
        check3_done <= freqEst_done;
      END IF;
    END IF;
  END PROCESS checkDone_3_process;

  TDDMode_done_enb <= TDDMode_done AND ce_out;

  
  TDDMode_lastAddr <= '1' WHEN NCellID_addr >= to_unsigned(16#11B897#, 21) ELSE
      '0';

  TDDMode_done <= TDDMode_lastAddr AND n_rst;

  -- Delay to allow last sim cycle to complete
  checkDone_2_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        check2_done <= '0';
      ELSIF TDDMode_done_enb = '1' THEN
        check2_done <= TDDMode_done;
      END IF;
    END IF;
  END PROCESS checkDone_2_process;

  NCellID_done_enb <= NCellID_done AND ce_out;

  
  NCellID_active <= '1' WHEN NCellID_addr /= to_unsigned(16#11B897#, 21) ELSE
      '0';

  startIn_addr_delay_1 <= dataIn_addr AFTER 1 ns;

  -- Data source for startIn
  startIn_fileread: PROCESS (startIn_addr_delay_1, tb_enb, phase_1)
    FILE fp: TEXT open READ_MODE is "startIn.dat";
    VARIABLE l: LINE;
    VARIABLE read_data: std_logic;

  BEGIN
    IF tb_enb /= '1' THEN
    ELSIF phase_1 = '1' AND NOT ENDFILE(fp) THEN
      READLINE(fp, l);
      READ(l, read_data);
    END IF;
    rawData_startIn <= read_data;
  END PROCESS startIn_fileread;

  -- holdData reg for startIn
  stimuli_startIn_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        holdData_startIn <= 'X';
      ELSE
        holdData_startIn <= rawData_startIn;
      END IF;
    END IF;
  END PROCESS stimuli_startIn_process;

  stimuli_startIn_1: PROCESS (rawData_startIn, phase_1)
  BEGIN
    IF phase_1 = '0' THEN
      startIn_offset <= holdData_startIn;
    ELSE
      startIn_offset <= rawData_startIn;
    END IF;
  END PROCESS stimuli_startIn_1;

  startIn <= startIn_offset AFTER 2 ns;

  -- holdData reg for validIn
  stimuli_validIn_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        holdData_validIn <= 'X';
      ELSE
        holdData_validIn <= rawData_validIn;
      END IF;
    END IF;
  END PROCESS stimuli_validIn_process;

  stimuli_validIn_1: PROCESS (rawData_validIn, phase_1)
  BEGIN
    IF phase_1 = '0' THEN
      validIn_offset <= holdData_validIn;
    ELSE
      validIn_offset <= rawData_validIn;
    END IF;
  END PROCESS stimuli_validIn_1;

  validIn_1 <= validIn_offset AFTER 2 ns;

  -- Data source for dataIn_im
  dataIn_im_fileread: PROCESS (dataIn_addr_delay, tb_enb, phase_1)
    FILE fp: TEXT open READ_MODE is "dataIn_im.dat";
    VARIABLE l: LINE;
    VARIABLE read_data: std_logic_vector(15 DOWNTO 0);

  BEGIN
    IF tb_enb /= '1' THEN
    ELSIF phase_1 = '1' AND NOT ENDFILE(fp) THEN
      READLINE(fp, l);
      HREAD(l, read_data);
    END IF;
    rawData_dataIn_im <= signed(read_data(15 DOWNTO 0));
  END PROCESS dataIn_im_fileread;

  -- holdData reg for dataIn
  stimuli_dataIn_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        holdData_dataIn_im <= (OTHERS => 'X');
      ELSE
        holdData_dataIn_im <= rawData_dataIn_im;
      END IF;
    END IF;
  END PROCESS stimuli_dataIn_process;

  stimuli_dataIn_1: PROCESS (rawData_dataIn_im, phase_1)
  BEGIN
    IF phase_1 = '0' THEN
      dataIn_im_offset <= holdData_dataIn_im;
    ELSE
      dataIn_im_offset <= rawData_dataIn_im;
    END IF;
  END PROCESS stimuli_dataIn_1;

  dataIn_im <= dataIn_im_offset AFTER 2 ns;

  dataIn_im_1 <= std_logic_vector(dataIn_im);

  
  dataIn_active <= '1' WHEN dataIn_addr /= to_unsigned(16#11B897#, 21) ELSE
      '0';

  tb_enb_delay <= tb_enb;

  -- Count limited, Unsigned Counter
  --  initial value   = 1
  --  step value      = 1
  --  count to value  = 1
  slow_clock_enable_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        counter <= '1';
      ELSIF tb_enb_delay = '1' THEN
        counter <=  NOT counter;
      END IF;
    END IF;
  END PROCESS slow_clock_enable_process;


  
  phase_1_ctr <= '1' WHEN counter = '1' ELSE
      '0';

  phase_1 <= phase_1_ctr AND tb_enb;

  dataIn_enb <= dataIn_active AND (phase_1 AND tb_enb);

  -- Count limited, Unsigned Counter
  --  initial value   = 0
  --  step value      = 1
  --  count to value  = 1161367
  DataTypeConversion5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        dataIn_addr <= to_unsigned(16#000000#, 21);
      ELSIF dataIn_enb = '1' THEN
        IF dataIn_addr >= to_unsigned(16#11B897#, 21) THEN 
          dataIn_addr <= to_unsigned(16#000000#, 21);
        ELSE 
          dataIn_addr <= dataIn_addr + to_unsigned(16#000001#, 21);
        END IF;
      END IF;
    END IF;
  END PROCESS DataTypeConversion5_process;


  dataIn_addr_delay <= dataIn_addr AFTER 1 ns;

  -- Data source for dataIn_re
  dataIn_re_fileread: PROCESS (dataIn_addr_delay, tb_enb, phase_1)
    FILE fp: TEXT open READ_MODE is "dataIn_re.dat";
    VARIABLE l: LINE;
    VARIABLE read_data: std_logic_vector(15 DOWNTO 0);

  BEGIN
    IF tb_enb /= '1' THEN
    ELSIF phase_1 = '1' AND NOT ENDFILE(fp) THEN
      READLINE(fp, l);
      HREAD(l, read_data);
    END IF;
    rawData_dataIn_re <= signed(read_data(15 DOWNTO 0));
  END PROCESS dataIn_re_fileread;

  -- holdData reg for dataIn
  stimuli_dataIn_2_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        holdData_dataIn_re <= (OTHERS => 'X');
      ELSE
        holdData_dataIn_re <= rawData_dataIn_re;
      END IF;
    END IF;
  END PROCESS stimuli_dataIn_2_process;

  stimuli_dataIn_3: PROCESS (rawData_dataIn_re, phase_1)
  BEGIN
    IF phase_1 = '0' THEN
      dataIn_re_offset <= holdData_dataIn_re;
    ELSE
      dataIn_re_offset <= rawData_dataIn_re;
    END IF;
  END PROCESS stimuli_dataIn_3;

  dataIn_re <= dataIn_re_offset AFTER 2 ns;

  dataIn_re_1 <= std_logic_vector(dataIn_re);

  snkDonen <=  NOT snkDone;

  tb_enb <= n_rst AND snkDonen;

  notDone <= tb_enb AND snkDonen;

  clk_en <= notDone AFTER 2 ns;

  n_rst_gen: PROCESS 
  BEGIN
    n_rst <= '0';
    WAIT FOR 20 ns;
    WAIT UNTIL rising_edge(clk);
    WAIT FOR 2 ns;
    n_rst <= '1';
    WAIT;
  END PROCESS n_rst_gen;

  clk_gen: PROCESS 
  BEGIN
    clk <= '1';
    WAIT FOR 5 ns;
    clk <= '0';
    WAIT FOR 5 ns;
    IF snkDone = '1' THEN
      clk <= '1';
      WAIT FOR 5 ns;
      clk <= '0';
      WAIT FOR 5 ns;
      WAIT;
    END IF;
  END PROCESS clk_gen;

  NCellID_enb <= ce_out AND NCellID_active;

  -- Count limited, Unsigned Counter
  --  initial value   = 0
  --  step value      = 1
  --  count to value  = 1161367
  c_3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        NCellID_addr <= to_unsigned(16#000000#, 21);
      ELSIF NCellID_enb = '1' THEN
        IF NCellID_addr >= to_unsigned(16#11B897#, 21) THEN 
          NCellID_addr <= to_unsigned(16#000000#, 21);
        ELSE 
          NCellID_addr <= NCellID_addr + to_unsigned(16#000001#, 21);
        END IF;
      END IF;
    END IF;
  END PROCESS c_3_process;


  
  NCellID_lastAddr <= '1' WHEN NCellID_addr >= to_unsigned(16#11B897#, 21) ELSE
      '0';

  NCellID_done <= NCellID_lastAddr AND n_rst;

  -- Delay to allow last sim cycle to complete
  checkDone_1_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        check1_done <= '0';
      ELSIF NCellID_done_enb = '1' THEN
        check1_done <= NCellID_done;
      END IF;
    END IF;
  END PROCESS checkDone_1_process;

  snkDone <= check12_done AND (check11_done AND (check10_done AND (check9_done AND (check8_done AND (check7_done AND (check6_done AND (check5_done AND (check4_done AND (check3_done AND (check1_done AND check2_done))))))))));

  NCellID_unsigned <= unsigned(NCellID);

  NCellID_addr_delay_1 <= NCellID_addr AFTER 1 ns;

  -- Data source for NCellID_expected
  NCellID_expected_fileread: PROCESS (NCellID_addr_delay_1, tb_enb)
    FILE fp: TEXT open READ_MODE is "NCellID_expected.dat";
    VARIABLE l: LINE;
    VARIABLE read_data: std_logic_vector(11 DOWNTO 0);

  BEGIN
    IF tb_enb /= '1' THEN
    ELSIF NOT ENDFILE(fp) THEN
      READLINE(fp, l);
      HREAD(l, read_data);
    END IF;
    NCellID_expected <= unsigned(read_data(8 DOWNTO 0));
  END PROCESS NCellID_expected_fileread;

  -- Bypass register to hold NCellID_ref
  DataHold_NCellID_ref_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        NCellID_ref_hold <= (OTHERS => '0');
      ELSIF ce_out = '1' THEN
        NCellID_ref_hold <= NCellID_expected;
      END IF;
    END IF;
  END PROCESS DataHold_NCellID_ref_process;

  
  NCellID_ref <= NCellID_ref_hold WHEN ce_out = '0' ELSE
      NCellID_expected;

  NCellID_unsigned_checker: PROCESS (clk, n_rst)
  BEGIN
    IF n_rst = '0' THEN
      NCellID_testFailure <= '0';
    ELSIF rising_edge(clk) THEN
      IF ce_out = '1' AND NCellID_unsigned /= NCellID_ref THEN
        NCellID_testFailure <= '1';
        ASSERT FALSE
          REPORT "Error in NCellID_unsigned: Expected " & to_hex(NCellID_ref) & (" Actual " & to_hex(NCellID_unsigned))
          SEVERITY ERROR;
      END IF;
    END IF;
  END PROCESS NCellID_unsigned_checker;

  -- Data source for TDDMode_expected
  TDDMode_expected_1 <= '0';

  -- Bypass register to hold TDDMode_ref
  DataHold_TDDMode_ref_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        TDDMode_ref_hold <= '0';
      ELSIF ce_out = '1' THEN
        TDDMode_ref_hold <= TDDMode_expected_1;
      END IF;
    END IF;
  END PROCESS DataHold_TDDMode_ref_process;

  -- Data source for TDDMode_expected
  
  TDDMode_ref <= TDDMode_ref_hold WHEN ce_out = '0' ELSE
      '0';

  TDDMode_checker: PROCESS (clk, n_rst)
  BEGIN
    IF n_rst = '0' THEN
      TDDMode_testFailure <= '0';
    ELSIF rising_edge(clk) THEN
      IF ce_out = '1' AND TDDMode /= TDDMode_ref THEN
        TDDMode_testFailure <= '1';
        ASSERT FALSE
          REPORT "Error in TDDMode: Expected " & to_hex(TDDMode_ref) & (" Actual " & to_hex(TDDMode))
          SEVERITY ERROR;
      END IF;
    END IF;
  END PROCESS TDDMode_checker;

  freqEst_signed <= signed(freqEst);

  freqEst_addr_delay_1 <= NCellID_addr AFTER 1 ns;

  -- Data source for freqEst_expected
  freqEst_expected_fileread: PROCESS (freqEst_addr_delay_1, tb_enb)
    FILE fp: TEXT open READ_MODE is "freqEst_expected.dat";
    VARIABLE l: LINE;
    VARIABLE read_data: std_logic_vector(15 DOWNTO 0);

  BEGIN
    IF tb_enb /= '1' THEN
    ELSIF NOT ENDFILE(fp) THEN
      READLINE(fp, l);
      HREAD(l, read_data);
    END IF;
    freqEst_expected <= signed(read_data(13 DOWNTO 0));
  END PROCESS freqEst_expected_fileread;

  -- Bypass register to hold freqEst_ref
  DataHold_freqEst_ref_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        freqEst_ref_hold <= (OTHERS => '0');
      ELSIF ce_out = '1' THEN
        freqEst_ref_hold <= freqEst_expected;
      END IF;
    END IF;
  END PROCESS DataHold_freqEst_ref_process;

  
  freqEst_ref <= freqEst_ref_hold WHEN ce_out = '0' ELSE
      freqEst_expected;

  freqEst_signed_checker: PROCESS (clk, n_rst)
  BEGIN
    IF n_rst = '0' THEN
      freqEst_testFailure <= '0';
    ELSIF rising_edge(clk) THEN
      IF ce_out = '1' AND freqEst_signed /= freqEst_ref THEN
        freqEst_testFailure <= '1';
        ASSERT FALSE
          REPORT "Error in freqEst_signed: Expected " & to_hex(freqEst_ref) & (" Actual " & to_hex(freqEst_signed))
          SEVERITY ERROR;
      END IF;
    END IF;
  END PROCESS freqEst_signed_checker;

  cellDetected_addr_delay_1 <= NCellID_addr AFTER 1 ns;

  -- Data source for cellDetected_expected
  cellDetected_expected_fileread: PROCESS (cellDetected_addr_delay_1, tb_enb)
    FILE fp: TEXT open READ_MODE is "cellDetected_expected.dat";
    VARIABLE l: LINE;
    VARIABLE read_data: std_logic;

  BEGIN
    IF tb_enb /= '1' THEN
    ELSIF NOT ENDFILE(fp) THEN
      READLINE(fp, l);
      READ(l, read_data);
    END IF;
    cellDetected_expected <= read_data;
  END PROCESS cellDetected_expected_fileread;

  -- Bypass register to hold cellDetected_ref
  DataHold_cellDetected_ref_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        cellDetected_ref_hold <= '0';
      ELSIF ce_out = '1' THEN
        cellDetected_ref_hold <= cellDetected_expected;
      END IF;
    END IF;
  END PROCESS DataHold_cellDetected_ref_process;

  
  cellDetected_ref <= cellDetected_ref_hold WHEN ce_out = '0' ELSE
      cellDetected_expected;

  cellDetected_checker: PROCESS (clk, n_rst)
  BEGIN
    IF n_rst = '0' THEN
      cellDetected_testFailure <= '0';
    ELSIF rising_edge(clk) THEN
      IF ce_out = '1' AND cellDetected /= cellDetected_ref THEN
        cellDetected_testFailure <= '1';
        ASSERT FALSE
          REPORT "Error in cellDetected: Expected " & to_hex(cellDetected_ref) & (" Actual " & to_hex(cellDetected))
          SEVERITY ERROR;
      END IF;
    END IF;
  END PROCESS cellDetected_checker;

  cellSearchDone_addr_delay_1 <= NCellID_addr AFTER 1 ns;

  -- Data source for cellSearchDone_expected
  cellSearchDone_expected_fileread: PROCESS (cellSearchDone_addr_delay_1, tb_enb)
    FILE fp: TEXT open READ_MODE is "cellSearchDone_expected.dat";
    VARIABLE l: LINE;
    VARIABLE read_data: std_logic;

  BEGIN
    IF tb_enb /= '1' THEN
    ELSIF NOT ENDFILE(fp) THEN
      READLINE(fp, l);
      READ(l, read_data);
    END IF;
    cellSearchDone_expected <= read_data;
  END PROCESS cellSearchDone_expected_fileread;

  -- Bypass register to hold cellSearchDone_ref
  DataHold_cellSearchDone_ref_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        cellSearchDone_ref_hold <= '0';
      ELSIF ce_out = '1' THEN
        cellSearchDone_ref_hold <= cellSearchDone_expected;
      END IF;
    END IF;
  END PROCESS DataHold_cellSearchDone_ref_process;

  
  cellSearchDone_ref <= cellSearchDone_ref_hold WHEN ce_out = '0' ELSE
      cellSearchDone_expected;

  cellSearchDone_checker: PROCESS (clk, n_rst)
  BEGIN
    IF n_rst = '0' THEN
      cellSearchDone_testFailure <= '0';
    ELSIF rising_edge(clk) THEN
      IF ce_out = '1' AND cellSearchDone /= cellSearchDone_ref THEN
        cellSearchDone_testFailure <= '1';
        ASSERT FALSE
          REPORT "Error in cellSearchDone: Expected " & to_hex(cellSearchDone_ref) & (" Actual " & to_hex(cellSearchDone))
          SEVERITY ERROR;
      END IF;
    END IF;
  END PROCESS cellSearchDone_checker;

  NDLRB_unsigned <= unsigned(NDLRB);

  NDLRB_addr_delay_1 <= NCellID_addr AFTER 1 ns;

  -- Data source for NDLRB_expected
  NDLRB_expected_fileread: PROCESS (NDLRB_addr_delay_1, tb_enb)
    FILE fp: TEXT open READ_MODE is "NDLRB_expected.dat";
    VARIABLE l: LINE;
    VARIABLE read_data: std_logic_vector(7 DOWNTO 0);

  BEGIN
    IF tb_enb /= '1' THEN
    ELSIF NOT ENDFILE(fp) THEN
      READLINE(fp, l);
      HREAD(l, read_data);
    END IF;
    NDLRB_expected <= unsigned(read_data(6 DOWNTO 0));
  END PROCESS NDLRB_expected_fileread;

  -- Bypass register to hold NDLRB_ref
  DataHold_NDLRB_ref_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        NDLRB_ref_hold <= (OTHERS => '0');
      ELSIF ce_out = '1' THEN
        NDLRB_ref_hold <= NDLRB_expected;
      END IF;
    END IF;
  END PROCESS DataHold_NDLRB_ref_process;

  
  NDLRB_ref <= NDLRB_ref_hold WHEN ce_out = '0' ELSE
      NDLRB_expected;

  NDLRB_unsigned_checker: PROCESS (clk, n_rst)
  BEGIN
    IF n_rst = '0' THEN
      NDLRB_testFailure <= '0';
    ELSIF rising_edge(clk) THEN
      IF ce_out = '1' AND NDLRB_unsigned /= NDLRB_ref THEN
        NDLRB_testFailure <= '1';
        ASSERT FALSE
          REPORT "Error in NDLRB_unsigned: Expected " & to_hex(NDLRB_ref) & (" Actual " & to_hex(NDLRB_unsigned))
          SEVERITY ERROR;
      END IF;
    END IF;
  END PROCESS NDLRB_unsigned_checker;

  -- Data source for PHICH_expected
  PHICH_expected_1 <= '0';

  -- Bypass register to hold PHICH_ref
  DataHold_PHICH_ref_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        PHICH_ref_hold <= '0';
      ELSIF ce_out = '1' THEN
        PHICH_ref_hold <= PHICH_expected_1;
      END IF;
    END IF;
  END PROCESS DataHold_PHICH_ref_process;

  -- Data source for PHICH_expected
  
  PHICH_ref <= PHICH_ref_hold WHEN ce_out = '0' ELSE
      '0';

  PHICH_checker: PROCESS (clk, n_rst)
  BEGIN
    IF n_rst = '0' THEN
      PHICH_testFailure <= '0';
    ELSIF rising_edge(clk) THEN
      IF ce_out = '1' AND PHICH /= PHICH_ref THEN
        PHICH_testFailure <= '1';
        ASSERT FALSE
          REPORT "Error in PHICH: Expected " & to_hex(PHICH_ref) & (" Actual " & to_hex(PHICH))
          SEVERITY ERROR;
      END IF;
    END IF;
  END PROCESS PHICH_checker;

  Ng_unsigned <= unsigned(Ng);

  Ng_addr_delay_1 <= NCellID_addr AFTER 1 ns;

  -- Data source for Ng_expected
  Ng_expected_fileread: PROCESS (Ng_addr_delay_1, tb_enb)
    FILE fp: TEXT open READ_MODE is "Ng_expected.dat";
    VARIABLE l: LINE;
    VARIABLE read_data: std_logic_vector(3 DOWNTO 0);

  BEGIN
    IF tb_enb /= '1' THEN
    ELSIF NOT ENDFILE(fp) THEN
      READLINE(fp, l);
      HREAD(l, read_data);
    END IF;
    Ng_expected <= unsigned(read_data(1 DOWNTO 0));
  END PROCESS Ng_expected_fileread;

  -- Bypass register to hold Ng_ref
  DataHold_Ng_ref_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        Ng_ref_hold <= (OTHERS => '0');
      ELSIF ce_out = '1' THEN
        Ng_ref_hold <= Ng_expected;
      END IF;
    END IF;
  END PROCESS DataHold_Ng_ref_process;

  
  Ng_ref <= Ng_ref_hold WHEN ce_out = '0' ELSE
      Ng_expected;

  Ng_unsigned_checker: PROCESS (clk, n_rst)
  BEGIN
    IF n_rst = '0' THEN
      Ng_testFailure <= '0';
    ELSIF rising_edge(clk) THEN
      IF ce_out = '1' AND Ng_unsigned /= Ng_ref THEN
        Ng_testFailure <= '1';
        ASSERT FALSE
          REPORT "Error in Ng_unsigned: Expected " & to_hex(Ng_ref) & (" Actual " & to_hex(Ng_unsigned))
          SEVERITY ERROR;
      END IF;
    END IF;
  END PROCESS Ng_unsigned_checker;

  NFrame_unsigned <= unsigned(NFrame);

  NFrame_addr_delay_1 <= NCellID_addr AFTER 1 ns;

  -- Data source for NFrame_expected
  NFrame_expected_fileread: PROCESS (NFrame_addr_delay_1, tb_enb)
    FILE fp: TEXT open READ_MODE is "NFrame_expected.dat";
    VARIABLE l: LINE;
    VARIABLE read_data: std_logic_vector(11 DOWNTO 0);

  BEGIN
    IF tb_enb /= '1' THEN
    ELSIF NOT ENDFILE(fp) THEN
      READLINE(fp, l);
      HREAD(l, read_data);
    END IF;
    NFrame_expected <= unsigned(read_data(9 DOWNTO 0));
  END PROCESS NFrame_expected_fileread;

  -- Bypass register to hold NFrame_ref
  DataHold_NFrame_ref_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        NFrame_ref_hold <= (OTHERS => '0');
      ELSIF ce_out = '1' THEN
        NFrame_ref_hold <= NFrame_expected;
      END IF;
    END IF;
  END PROCESS DataHold_NFrame_ref_process;

  
  NFrame_ref <= NFrame_ref_hold WHEN ce_out = '0' ELSE
      NFrame_expected;

  NFrame_unsigned_checker: PROCESS (clk, n_rst)
  BEGIN
    IF n_rst = '0' THEN
      NFrame_testFailure <= '0';
    ELSIF rising_edge(clk) THEN
      IF ce_out = '1' AND NFrame_unsigned /= NFrame_ref THEN
        NFrame_testFailure <= '1';
        ASSERT FALSE
          REPORT "Error in NFrame_unsigned: Expected " & to_hex(NFrame_ref) & (" Actual " & to_hex(NFrame_unsigned))
          SEVERITY ERROR;
      END IF;
    END IF;
  END PROCESS NFrame_unsigned_checker;

  CellRefP_unsigned <= unsigned(CellRefP);

  CellRefP_addr_delay_1 <= NCellID_addr AFTER 1 ns;

  -- Data source for CellRefP_expected
  CellRefP_expected_fileread: PROCESS (CellRefP_addr_delay_1, tb_enb)
    FILE fp: TEXT open READ_MODE is "CellRefP_expected.dat";
    VARIABLE l: LINE;
    VARIABLE read_data: std_logic_vector(3 DOWNTO 0);

  BEGIN
    IF tb_enb /= '1' THEN
    ELSIF NOT ENDFILE(fp) THEN
      READLINE(fp, l);
      HREAD(l, read_data);
    END IF;
    CellRefP_expected <= unsigned(read_data(2 DOWNTO 0));
  END PROCESS CellRefP_expected_fileread;

  -- Bypass register to hold CellRefP_ref
  DataHold_CellRefP_ref_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        CellRefP_ref_hold <= (OTHERS => '0');
      ELSIF ce_out = '1' THEN
        CellRefP_ref_hold <= CellRefP_expected;
      END IF;
    END IF;
  END PROCESS DataHold_CellRefP_ref_process;

  
  CellRefP_ref <= CellRefP_ref_hold WHEN ce_out = '0' ELSE
      CellRefP_expected;

  CellRefP_unsigned_checker: PROCESS (clk, n_rst)
  BEGIN
    IF n_rst = '0' THEN
      CellRefP_testFailure <= '0';
    ELSIF rising_edge(clk) THEN
      IF ce_out = '1' AND CellRefP_unsigned /= CellRefP_ref THEN
        CellRefP_testFailure <= '1';
        ASSERT FALSE
          REPORT "Error in CellRefP_unsigned: Expected " & to_hex(CellRefP_ref) & (" Actual " & to_hex(CellRefP_unsigned))
          SEVERITY ERROR;
      END IF;
    END IF;
  END PROCESS CellRefP_unsigned_checker;

  mibDetected_addr_delay_1 <= NCellID_addr AFTER 1 ns;

  -- Data source for mibDetected_expected
  mibDetected_expected_fileread: PROCESS (mibDetected_addr_delay_1, tb_enb)
    FILE fp: TEXT open READ_MODE is "mibDetected_expected.dat";
    VARIABLE l: LINE;
    VARIABLE read_data: std_logic;

  BEGIN
    IF tb_enb /= '1' THEN
    ELSIF NOT ENDFILE(fp) THEN
      READLINE(fp, l);
      READ(l, read_data);
    END IF;
    mibDetected_expected <= read_data;
  END PROCESS mibDetected_expected_fileread;

  -- Bypass register to hold mibDetected_ref
  DataHold_mibDetected_ref_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        mibDetected_ref_hold <= '0';
      ELSIF ce_out = '1' THEN
        mibDetected_ref_hold <= mibDetected_expected;
      END IF;
    END IF;
  END PROCESS DataHold_mibDetected_ref_process;

  
  mibDetected_ref <= mibDetected_ref_hold WHEN ce_out = '0' ELSE
      mibDetected_expected;

  mibDetected_checker: PROCESS (clk, n_rst)
  BEGIN
    IF n_rst = '0' THEN
      mibDetected_testFailure <= '0';
    ELSIF rising_edge(clk) THEN
      IF ce_out = '1' AND mibDetected /= mibDetected_ref THEN
        mibDetected_testFailure <= '1';
        ASSERT FALSE
          REPORT "Error in mibDetected: Expected " & to_hex(mibDetected_ref) & (" Actual " & to_hex(mibDetected))
          SEVERITY ERROR;
      END IF;
    END IF;
  END PROCESS mibDetected_checker;

  -- Data source for mibError_expected
  mibError_expected_1 <= '0';

  -- Bypass register to hold mibError_ref
  DataHold_mibError_ref_process: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        mibError_ref_hold <= '0';
      ELSIF ce_out = '1' THEN
        mibError_ref_hold <= mibError_expected_1;
      END IF;
    END IF;
  END PROCESS DataHold_mibError_ref_process;

  -- Data source for mibError_expected
  
  mibError_ref <= mibError_ref_hold WHEN ce_out = '0' ELSE
      '0';

  mibError_checker: PROCESS (clk, n_rst)
  BEGIN
    IF n_rst = '0' THEN
      mibError_testFailure <= '0';
    ELSIF rising_edge(clk) THEN
      IF ce_out = '1' AND mibError /= mibError_ref THEN
        mibError_testFailure <= '1';
        ASSERT FALSE
          REPORT "Error in mibError: Expected " & to_hex(mibError_ref) & (" Actual " & to_hex(mibError))
          SEVERITY ERROR;
      END IF;
    END IF;
  END PROCESS mibError_checker;

  testFailure <= mibError_testFailure OR (mibDetected_testFailure OR (CellRefP_testFailure OR (NFrame_testFailure OR (Ng_testFailure OR (PHICH_testFailure OR (NDLRB_testFailure OR (cellSearchDone_testFailure OR (cellDetected_testFailure OR (freqEst_testFailure OR (NCellID_testFailure OR TDDMode_testFailure))))))))));

  completed_msg: PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF snkDone = '1' THEN
        IF testFailure = '0' THEN
          ASSERT FALSE
            REPORT "**************TEST COMPLETED (PASSED)**************"
            SEVERITY NOTE;
        ELSE
          ASSERT FALSE
            REPORT "**************TEST COMPLETED (FAILED)**************"
            SEVERITY NOTE;
        END IF;
      END IF;
    END IF;
  END PROCESS completed_msg;

END rtl;

