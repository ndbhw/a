-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY HDL_LTE_MIB_Recovery IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        clk_en                            :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        startIn                           :   IN    std_logic;
        ce_out                            :   OUT   std_logic;
        NCellID                           :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
        TDDMode                           :   OUT   std_logic;
        freqEst                           :   OUT   std_logic_vector(13 DOWNTO 0);  -- sfix14
        cellDetected                      :   OUT   std_logic;
        cellSearchDone                    :   OUT   std_logic;
        NDLRB                             :   OUT   std_logic_vector(6 DOWNTO 0);  -- ufix7
        PHICH                             :   OUT   std_logic;
        Ng                                :   OUT   std_logic_vector(1 DOWNTO 0);  -- ufix2
        NFrame                            :   OUT   std_logic_vector(9 DOWNTO 0);  -- ufix10
        CellRefP                          :   OUT   std_logic_vector(2 DOWNTO 0);  -- ufix3
        mibDetected                       :   OUT   std_logic;
        mibError                          :   OUT   std_logic
        );
END HDL_LTE_MIB_Recovery;


ARCHITECTURE rtl OF HDL_LTE_MIB_Recovery IS

  -- Component Declarations
  COMPONENT HDL_LTE_MIB_Recovery_tc
    PORT( clk                             :   IN    std_logic;
          clk_en                          :   IN    std_logic;
          enb                             :   OUT   std_logic;
          enb_1_2_0                       :   OUT   std_logic;
          enb_1_2_1                       :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          enb_1_2_1                       :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          start                           :   IN    std_logic;
          NCellID                         :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
          TDDMode                         :   OUT   std_logic;
          freqEst                         :   OUT   std_logic_vector(13 DOWNTO 0);  -- sfix14
          cellDetected                    :   OUT   std_logic;
          cellSearchDone                  :   OUT   std_logic;
          subframeNum                     :   OUT   std_logic_vector(3 DOWNTO 0);  -- ufix4
          gridData_re                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          gridData_im                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          gridValid                       :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT MIB_Decoder
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          enb_1_2_1                       :   IN    std_logic;
          NcellID                         :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          cellDetected                    :   IN    std_logic;
          Nsubframe                       :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          OFDMdata_gridData_re            :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          OFDMdata_gridData_im            :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          OFDMdata_gridDataValid          :   IN    std_logic;
          restart                         :   IN    std_logic;
          NDLRB                           :   OUT   std_logic_vector(6 DOWNTO 0);  -- ufix7
          PHICH                           :   OUT   std_logic;
          Ng                              :   OUT   std_logic_vector(1 DOWNTO 0);  -- ufix2
          NFrame                          :   OUT   std_logic_vector(9 DOWNTO 0);  -- ufix10
          CellRefP                        :   OUT   std_logic_vector(2 DOWNTO 0);  -- ufix3
          mibDetected                     :   OUT   std_logic;
          mibError                        :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : HDL_LTE_MIB_Recovery_tc
    USE ENTITY work.HDL_LTE_MIB_Recovery_tc(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod(rtl);

  FOR ALL : MIB_Decoder
    USE ENTITY work.MIB_Decoder(rtl);

  -- Signals
  SIGNAL enb                              : std_logic;
  SIGNAL enb_1_2_0                        : std_logic;
  SIGNAL enb_1_2_1                        : std_logic;
  SIGNAL start                            : std_logic;
  SIGNAL NCellID_tmp                      : std_logic_vector(8 DOWNTO 0);  -- ufix9
  SIGNAL Downlink_Sync_Demod_freqEst      : std_logic_vector(13 DOWNTO 0);  -- ufix14
  SIGNAL cellDetected_1                   : std_logic;
  SIGNAL Downlink_Sync_Demod_cellSearchDone : std_logic;
  SIGNAL subFrameNum                      : std_logic_vector(3 DOWNTO 0);  -- ufix4
  SIGNAL gridData_re                      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL gridData_im                      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL gridDataValid                    : std_logic;
  SIGNAL NDLRB_tmp                        : std_logic_vector(6 DOWNTO 0);  -- ufix7
  SIGNAL Ng_tmp                           : std_logic_vector(1 DOWNTO 0);  -- ufix2
  SIGNAL nFrame_1                         : std_logic_vector(9 DOWNTO 0);  -- ufix10
  SIGNAL cellRefP_1                       : std_logic_vector(2 DOWNTO 0);  -- ufix3
  SIGNAL MIBDetected_1                    : std_logic;

BEGIN
  UHDL_LTE_MIB_Recovery_tc : HDL_LTE_MIB_Recovery_tc
    PORT MAP( clk => clk,
              clk_en => clk_en,
              enb => enb,
              enb_1_2_0 => enb_1_2_0,
              enb_1_2_1 => enb_1_2_1
              );

  UDownlink_Sync_Demod : ltehdlDownlinkSyncDemod
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              enb_1_2_0 => enb_1_2_0,
              enb_1_2_1 => enb_1_2_1,
              dataIn_re => dataIn_re,  -- sfix16_En15
              dataIn_im => dataIn_im,  -- sfix16_En15
              validIn => validIn,
              start => start,
              NCellID => NCellID_tmp,  -- ufix9
              TDDMode => TDDMode,
              freqEst => Downlink_Sync_Demod_freqEst,  -- sfix14
              cellDetected => cellDetected_1,
              cellSearchDone => Downlink_Sync_Demod_cellSearchDone,
              subframeNum => subFrameNum,  -- ufix4
              gridData_re => gridData_re,  -- sfix16_En15
              gridData_im => gridData_im,  -- sfix16_En15
              gridValid => gridDataValid
              );

  UMIB_Decoder_1 : MIB_Decoder
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              enb_1_2_0 => enb_1_2_0,
              enb_1_2_1 => enb_1_2_1,
              NcellID => NCellID_tmp,  -- ufix9
              cellDetected => cellDetected_1,
              Nsubframe => subFrameNum,  -- ufix4
              OFDMdata_gridData_re => gridData_re,  -- sfix16_En15
              OFDMdata_gridData_im => gridData_im,  -- sfix16_En15
              OFDMdata_gridDataValid => gridDataValid,
              restart => start,
              NDLRB => NDLRB_tmp,  -- ufix7
              PHICH => PHICH,
              Ng => Ng_tmp,  -- ufix2
              NFrame => nFrame_1,  -- ufix10
              CellRefP => cellRefP_1,  -- ufix3
              mibDetected => MIBDetected_1,
              mibError => mibError
              );

  start <= startIn;

  ce_out <= enb_1_2_1;

  NCellID <= NCellID_tmp;

  freqEst <= Downlink_Sync_Demod_freqEst;

  cellDetected <= cellDetected_1;

  cellSearchDone <= Downlink_Sync_Demod_cellSearchDone;

  NDLRB <= NDLRB_tmp;

  Ng <= Ng_tmp;

  NFrame <= nFrame_1;

  CellRefP <= cellRefP_1;

  mibDetected <= MIBDetected_1;

END rtl;

