-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_MagnitudeSquared IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        dataOut                           :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En30
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_MagnitudeSquared;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_MagnitudeSquared IS

  -- Signals
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Product4_out1                    : signed(31 DOWNTO 0);  -- sfix32_En30
  SIGNAL Product1_out1                    : signed(31 DOWNTO 0);  -- sfix32_En30
  SIGNAL Delay2_out1                      : signed(31 DOWNTO 0) := to_signed(0, 32);  -- sfix32_En30
  SIGNAL Data_Type_Conversion_out1        : unsigned(29 DOWNTO 0);  -- ufix30_En30
  SIGNAL Delay1_out1                      : signed(31 DOWNTO 0) := to_signed(0, 32);  -- sfix32_En30
  SIGNAL Data_Type_Conversion1_out1       : unsigned(29 DOWNTO 0);  -- ufix30_En30
  SIGNAL Add_out1                         : unsigned(29 DOWNTO 0);  -- ufix30_En30
  SIGNAL Delay4_out1                      : unsigned(29 DOWNTO 0) := to_unsigned(16#00000000#, 30);  -- ufix30_En30
  SIGNAL Delay7_out1                      : std_logic := '0';
  SIGNAL Delay8_out1                      : std_logic := '0';

BEGIN
  dataIn_re_signed <= signed(dataIn_re);

  Product4_out1 <= dataIn_re_signed * dataIn_re_signed;

  dataIn_im_signed <= signed(dataIn_im);

  Product1_out1 <= dataIn_im_signed * dataIn_im_signed;

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_out1 <= Product4_out1;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  Data_Type_Conversion_out1 <= unsigned(Delay2_out1(29 DOWNTO 0));

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1 <= Product1_out1;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  Data_Type_Conversion1_out1 <= unsigned(Delay1_out1(29 DOWNTO 0));

  Add_out1 <= Data_Type_Conversion_out1 + Data_Type_Conversion1_out1;

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay4_out1 <= Add_out1;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  dataOut <= std_logic_vector(Delay4_out1);

  Delay7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay7_out1 <= validIn;
      END IF;
    END IF;
  END PROCESS Delay7_process;


  Delay8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay8_out1 <= Delay7_out1;
      END IF;
    END IF;
  END PROCESS Delay8_process;


  validOut <= Delay8_out1;

END rtl;

