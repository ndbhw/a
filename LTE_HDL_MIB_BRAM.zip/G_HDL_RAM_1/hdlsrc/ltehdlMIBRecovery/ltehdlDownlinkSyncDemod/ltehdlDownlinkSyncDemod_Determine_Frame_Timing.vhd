-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_Determine_Frame_Timing IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        reset                             :   IN    std_logic;
        enable                            :   IN    std_logic;
        PSSTimingOffset                   :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
        TDD                               :   IN    std_logic;
        halfFrameIndicator                :   IN    std_logic;
        SSSPSSPhaseAligned                :   IN    std_logic;
        timingOffset                      :   OUT   std_logic_vector(14 DOWNTO 0)  -- ufix15
        );
END ltehdlDownlinkSyncDemod_Determine_Frame_Timing;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Determine_Frame_Timing IS

  -- Signals
  SIGNAL PSSTimingOffset_unsigned         : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL timingOffset_tmp                 : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL timingOffsetReg                  : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL timingOffsetReg_next             : unsigned(14 DOWNTO 0);  -- ufix15

BEGIN
  PSSTimingOffset_unsigned <= unsigned(PSSTimingOffset);

  Determine_Frame_Timing_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        timingOffsetReg <= to_unsigned(16#0000#, 15);
      ELSIF enb = '1' THEN
        timingOffsetReg <= timingOffsetReg_next;
      END IF;
    END IF;
  END PROCESS Determine_Frame_Timing_process;

  Determine_Frame_Timing_output : PROCESS (PSSTimingOffset_unsigned, SSSPSSPhaseAligned, TDD, enable, halfFrameIndicator,
       reset, timingOffsetReg)
    VARIABLE halfFrameOffsetNeeded : std_logic;
    VARIABLE toff : signed(15 DOWNTO 0);
    VARIABLE toff_0 : signed(15 DOWNTO 0);
    VARIABLE sub_temp : signed(17 DOWNTO 0);
    VARIABLE sub_temp_0 : signed(17 DOWNTO 0);
  BEGIN
    halfFrameOffsetNeeded := '0';
    toff_0 := to_signed(16#0000#, 16);
    sub_temp := to_signed(16#00000#, 18);
    sub_temp_0 := to_signed(16#00000#, 18);
    toff := to_signed(16#0000#, 16);
    timingOffsetReg_next <= timingOffsetReg;
    ----------------------------------------------------------------------------
    -- Constants
    ----------------------------------------------------------------------------
    -- length of cyclic prefix 0
    -- length of cyclic prefixes 1 to 6
    -- length of useful part of OFDM symbol
    ----------------------------------------------------------------------------
    -- Registers
    ----------------------------------------------------------------------------
    -- Assign output
    ----------------------------------------------------------------------------
    ----------------------------------------------------------------------------
    -- Compute timing offset and update register
    ----------------------------------------------------------------------------
    IF reset = '1' THEN 
      timingOffsetReg_next <= to_unsigned(16#0000#, 15);
    ELSIF enable = '1' THEN 
      -- A half frame offset is needed if either halfFrameIndicator==true
      -- or SSSPSSPhaseAligned==true, but not if both are true or false.
      -- This results in an xnor.
      IF halfFrameIndicator = SSSPSSPhaseAligned THEN 
        halfFrameOffsetNeeded := '1';
      ELSE 
        halfFrameOffsetNeeded := '0';
      END IF;
      toff := signed(resize(PSSTimingOffset_unsigned, 16));
      IF TDD = '1' THEN 
        sub_temp_0 := resize(resize(toff, 17) + to_signed(16#00001#, 17), 18) - to_signed(16#0091C#, 18);
        toff_0 := sub_temp_0(15 DOWNTO 0);
      ELSE 
        sub_temp := resize(resize(toff, 17) + to_signed(16#00001#, 17), 18) - to_signed(16#003C0#, 18);
        toff_0 := sub_temp(15 DOWNTO 0);
      END IF;
      IF halfFrameOffsetNeeded = '1' THEN 
        toff_0 := toff_0 - to_signed(16#2580#, 16);
      END IF;
      IF toff_0 < to_signed(16#0000#, 16) THEN 
        -- Wrap if the result is below zero.
        toff_0 := toff_0 + to_signed(16#4B00#, 16);
      END IF;
      timingOffsetReg_next <= unsigned(toff_0(14 DOWNTO 0));
    END IF;
    timingOffset_tmp <= timingOffsetReg;
  END PROCESS Determine_Frame_Timing_output;


  timingOffset <= std_logic_vector(timingOffset_tmp);

END rtl;

