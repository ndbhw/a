-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_Correlators IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        correlation_0                     :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
        correlation_1                     :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
        correlation_2                     :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
        threshold                         :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Correlators;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Correlators IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_PSSXCorr0
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En12
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0)  -- sfix16_En12
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_MagnitudeSquared0
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En12
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En12
          dataOut                         :   OUT   std_logic_vector(29 DOWNTO 0)  -- ufix30_En24
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_PSSXCorr1
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En12
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0)  -- sfix16_En12
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_MagnitudeSquared1
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En12
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En12
          dataOut                         :   OUT   std_logic_vector(29 DOWNTO 0)  -- ufix30_En24
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_PSSXCorr2
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En12
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En12
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_MagnitudeSquared2
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En12
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En12
          validIn                         :   IN    std_logic;
          dataOut                         :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_ThresholdPrescaling
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_MagnitudeSquared
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          dataOut                         :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En30
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_MovingAverage_block
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn                          :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30_En30
          validIn                         :   IN    std_logic;
          dataOut                         :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_ThresholdLimiter
    PORT( x_x                             :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
          y_y                             :   OUT   std_logic_vector(29 DOWNTO 0)  -- ufix30_En24
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_StreamSyncronizer
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          pop                             :   IN    std_logic;
          dataIn                          :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
          push                            :   IN    std_logic;
          dataOut                         :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_PSSXCorr0
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_PSSXCorr0(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_MagnitudeSquared0
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_MagnitudeSquared0(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_PSSXCorr1
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_PSSXCorr1(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_MagnitudeSquared1
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_MagnitudeSquared1(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_PSSXCorr2
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_PSSXCorr2(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_MagnitudeSquared2
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_MagnitudeSquared2(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_ThresholdPrescaling
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_ThresholdPrescaling(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_MagnitudeSquared
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_MagnitudeSquared(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_MovingAverage_block
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_MovingAverage_block(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_ThresholdLimiter
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_ThresholdLimiter(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_StreamSyncronizer
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_StreamSyncronizer(rtl);

  -- Signals
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay3_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay3_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay2_out1                      : std_logic := '0';
  SIGNAL PSSXCorr0_dataOut_re             : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL PSSXCorr0_dataOut_im             : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL MagnitudeSquared0_dataOut        : std_logic_vector(29 DOWNTO 0);  -- ufix30
  SIGNAL MagnitudeSquared0_dataOut_unsigned : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL Delay1_out1                      : unsigned(29 DOWNTO 0) := to_unsigned(16#00000000#, 30);  -- ufix30_En24
  SIGNAL PSSXCorr1_dataOut_re             : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL PSSXCorr1_dataOut_im             : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL MagnitudeSquared1_dataOut        : std_logic_vector(29 DOWNTO 0);  -- ufix30
  SIGNAL MagnitudeSquared1_dataOut_unsigned : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL Delay5_out1                      : unsigned(29 DOWNTO 0) := to_unsigned(16#00000000#, 30);  -- ufix30_En24
  SIGNAL PSSXCorr2_dataOut_re             : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL PSSXCorr2_dataOut_im             : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL PSSXCorr2_validOut               : std_logic;
  SIGNAL MagnitudeSquared2_dataOut        : std_logic_vector(29 DOWNTO 0);  -- ufix30
  SIGNAL pop                              : std_logic;
  SIGNAL MagnitudeSquared2_dataOut_unsigned : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL Delay4_out1                      : unsigned(29 DOWNTO 0) := to_unsigned(16#00000000#, 30);  -- ufix30_En24
  SIGNAL ThresholdPrescaling_dataOut_re   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL ThresholdPrescaling_dataOut_im   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL ThresholdPrescaling_validOut     : std_logic;
  SIGNAL MagnitudeSquared_dataOut         : std_logic_vector(29 DOWNTO 0);  -- ufix30
  SIGNAL MagnitudeSquared_validOut        : std_logic;
  SIGNAL dataIn                           : std_logic_vector(29 DOWNTO 0);  -- ufix30
  SIGNAL push                             : std_logic;
  SIGNAL y_y                              : std_logic_vector(29 DOWNTO 0);  -- ufix30
  SIGNAL y_unsigned                       : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL Delay6_out1                      : unsigned(29 DOWNTO 0) := to_unsigned(16#00000000#, 30);  -- ufix30_En24
  SIGNAL Delay7_out1                      : std_logic := '0';
  SIGNAL dataOut                          : std_logic_vector(29 DOWNTO 0);  -- ufix30

BEGIN
  -- Measure the energy in the signal across a 128 sample window, which is equivalent to the PSS correlation window. 
  -- This will be used later to generate a threshold
  -- Use a simple circular buffer to synchronize the streams, given that the correlators have greater latency than the 
  -- signal power measurement
  -- Scale the signal by the square root of the threshold scaling factor before measuring the energy. This leads to 
  -- a more efficient implementation than applying the scaling factor afterwards
  -- Apply a lower limit to the threshold to prevent small signals from triggering detection.

  UPSSXCorr0 : ltehdlDownlinkSyncDemod_PSSXCorr0
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => std_logic_vector(Delay3_out1_re),  -- sfix16_En15
              dataIn_im => std_logic_vector(Delay3_out1_im),  -- sfix16_En15
              validIn => Delay2_out1,
              dataOut_re => PSSXCorr0_dataOut_re,  -- sfix16_En12
              dataOut_im => PSSXCorr0_dataOut_im  -- sfix16_En12
              );

  UMagnitudeSquared0 : ltehdlDownlinkSyncDemod_MagnitudeSquared0
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => PSSXCorr0_dataOut_re,  -- sfix16_En12
              dataIn_im => PSSXCorr0_dataOut_im,  -- sfix16_En12
              dataOut => MagnitudeSquared0_dataOut  -- ufix30_En24
              );

  UPSSXCorr1 : ltehdlDownlinkSyncDemod_PSSXCorr1
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => std_logic_vector(Delay3_out1_re),  -- sfix16_En15
              dataIn_im => std_logic_vector(Delay3_out1_im),  -- sfix16_En15
              validIn => Delay2_out1,
              dataOut_re => PSSXCorr1_dataOut_re,  -- sfix16_En12
              dataOut_im => PSSXCorr1_dataOut_im  -- sfix16_En12
              );

  UMagnitudeSquared1 : ltehdlDownlinkSyncDemod_MagnitudeSquared1
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => PSSXCorr1_dataOut_re,  -- sfix16_En12
              dataIn_im => PSSXCorr1_dataOut_im,  -- sfix16_En12
              dataOut => MagnitudeSquared1_dataOut  -- ufix30_En24
              );

  UPSSXCorr2 : ltehdlDownlinkSyncDemod_PSSXCorr2
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => std_logic_vector(Delay3_out1_re),  -- sfix16_En15
              dataIn_im => std_logic_vector(Delay3_out1_im),  -- sfix16_En15
              validIn => Delay2_out1,
              dataOut_re => PSSXCorr2_dataOut_re,  -- sfix16_En12
              dataOut_im => PSSXCorr2_dataOut_im,  -- sfix16_En12
              validOut => PSSXCorr2_validOut
              );

  UMagnitudeSquared2 : ltehdlDownlinkSyncDemod_MagnitudeSquared2
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => PSSXCorr2_dataOut_re,  -- sfix16_En12
              dataIn_im => PSSXCorr2_dataOut_im,  -- sfix16_En12
              validIn => PSSXCorr2_validOut,
              dataOut => MagnitudeSquared2_dataOut,  -- ufix30_En24
              validOut => pop
              );

  UThresholdPrescaling : ltehdlDownlinkSyncDemod_ThresholdPrescaling
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => std_logic_vector(Delay3_out1_re),  -- sfix16_En15
              dataIn_im => std_logic_vector(Delay3_out1_im),  -- sfix16_En15
              validIn => Delay2_out1,
              dataOut_re => ThresholdPrescaling_dataOut_re,  -- sfix16_En15
              dataOut_im => ThresholdPrescaling_dataOut_im,  -- sfix16_En15
              validOut => ThresholdPrescaling_validOut
              );

  UMagnitudeSquared : ltehdlDownlinkSyncDemod_MagnitudeSquared
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => ThresholdPrescaling_dataOut_re,  -- sfix16_En15
              dataIn_im => ThresholdPrescaling_dataOut_im,  -- sfix16_En15
              validIn => ThresholdPrescaling_validOut,
              dataOut => MagnitudeSquared_dataOut,  -- ufix30_En30
              validOut => MagnitudeSquared_validOut
              );

  UMovingAverage_1 : ltehdlDownlinkSyncDemod_MovingAverage_block
    PORT MAP( clk => clk,
              enb => enb,
              dataIn => MagnitudeSquared_dataOut,  -- ufix30_En30
              validIn => MagnitudeSquared_validOut,
              dataOut => dataIn,  -- ufix30_En24
              validOut => push
              );

  UThresholdLimiter : ltehdlDownlinkSyncDemod_ThresholdLimiter
    PORT MAP( x_x => dataIn,  -- ufix30_En24
              y_y => y_y  -- ufix30_En24
              );

  UStreamSyncronizer : ltehdlDownlinkSyncDemod_StreamSyncronizer
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              pop => pop,
              dataIn => std_logic_vector(Delay6_out1),  -- ufix30_En24
              push => Delay7_out1,
              dataOut => dataOut,  -- ufix30_En24
              validOut => validOut
              );

  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1_re <= dataIn_re_signed;
        Delay3_out1_im <= dataIn_im_signed;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_out1 <= validIn;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  MagnitudeSquared0_dataOut_unsigned <= unsigned(MagnitudeSquared0_dataOut);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1 <= MagnitudeSquared0_dataOut_unsigned;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  correlation_0 <= std_logic_vector(Delay1_out1);

  MagnitudeSquared1_dataOut_unsigned <= unsigned(MagnitudeSquared1_dataOut);

  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay5_out1 <= MagnitudeSquared1_dataOut_unsigned;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  correlation_1 <= std_logic_vector(Delay5_out1);

  MagnitudeSquared2_dataOut_unsigned <= unsigned(MagnitudeSquared2_dataOut);

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay4_out1 <= MagnitudeSquared2_dataOut_unsigned;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  correlation_2 <= std_logic_vector(Delay4_out1);

  y_unsigned <= unsigned(y_y);

  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay6_out1 <= y_unsigned;
      END IF;
    END IF;
  END PROCESS Delay6_process;


  Delay7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay7_out1 <= push;
      END IF;
    END IF;
  END PROCESS Delay7_process;


  threshold <= dataOut;

END rtl;

