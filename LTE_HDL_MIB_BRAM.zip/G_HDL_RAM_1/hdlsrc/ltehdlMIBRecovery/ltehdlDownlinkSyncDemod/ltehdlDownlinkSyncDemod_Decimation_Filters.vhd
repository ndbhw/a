-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_Decimation_Filters IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataOut_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Decimation_Filters;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Decimation_Filters IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_CIC_Filter
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(27 DOWNTO 0);  -- sfix28_En15
          dataOut_im                      :   OUT   std_logic_vector(27 DOWNTO 0);  -- sfix28_En15
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_CIC_Gain_Comp
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(27 DOWNTO 0);  -- sfix28_En15
          dataIn_im                       :   IN    std_logic_vector(27 DOWNTO 0);  -- sfix28_En15
          validIn                         :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_CIC_Compensation_Decimator
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Transient_Removal
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_CIC_Filter
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_CIC_Filter(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_CIC_Gain_Comp
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_CIC_Gain_Comp(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_CIC_Compensation_Decimator
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_CIC_Compensation_Decimator(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Transient_Removal
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Transient_Removal(rtl);

  -- Signals
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay_rsvd_reg_re                : vector_of_signed16(0 TO 1) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16_En15 [2]
  SIGNAL Delay_rsvd_reg_im                : vector_of_signed16(0 TO 1) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16_En15 [2]
  SIGNAL Delay_out1_re                    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay_out1_im                    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataOut_re_1                     : std_logic_vector(27 DOWNTO 0);  -- ufix28
  SIGNAL dataOut_im_1                     : std_logic_vector(27 DOWNTO 0);  -- ufix28
  SIGNAL validOut_1                       : std_logic;
  SIGNAL CIC_Gain_Comp_dataOut_re         : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL CIC_Gain_Comp_dataOut_im         : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL CIC_Gain_Comp_validOut           : std_logic;
  SIGNAL CIC_Compensation_Decimator_dataOut_re : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL CIC_Compensation_Decimator_dataOut_im : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL CIC_Compensation_Decimator_validOut : std_logic;
  SIGNAL dataOut_re_tmp                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dataOut_im_tmp                   : std_logic_vector(15 DOWNTO 0);  -- ufix16

BEGIN
  -- Extra delay, to make overall
  -- filter chain delay up to a multiple
  -- of 16.

  UCIC_Filter : ltehdlDownlinkSyncDemod_CIC_Filter
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              dataIn_re => std_logic_vector(Delay_out1_re),  -- sfix16_En15
              dataIn_im => std_logic_vector(Delay_out1_im),  -- sfix16_En15
              validIn => validIn,
              dataOut_re => dataOut_re_1,  -- sfix28_En15
              dataOut_im => dataOut_im_1,  -- sfix28_En15
              validOut => validOut_1
              );

  UCIC_Gain_Comp : ltehdlDownlinkSyncDemod_CIC_Gain_Comp
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => dataOut_re_1,  -- sfix28_En15
              dataIn_im => dataOut_im_1,  -- sfix28_En15
              validIn => validOut_1,
              dataOut_re => CIC_Gain_Comp_dataOut_re,  -- sfix16_En15
              dataOut_im => CIC_Gain_Comp_dataOut_im,  -- sfix16_En15
              validOut => CIC_Gain_Comp_validOut
              );

  UCIC_Compensation_Decimator : ltehdlDownlinkSyncDemod_CIC_Compensation_Decimator
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              dataIn_re => CIC_Gain_Comp_dataOut_re,  -- sfix16_En15
              dataIn_im => CIC_Gain_Comp_dataOut_im,  -- sfix16_En15
              validIn => CIC_Gain_Comp_validOut,
              dataOut_re => CIC_Compensation_Decimator_dataOut_re,  -- sfix16_En15
              dataOut_im => CIC_Compensation_Decimator_dataOut_im,  -- sfix16_En15
              validOut => CIC_Compensation_Decimator_validOut
              );

  UTransient_Removal : ltehdlDownlinkSyncDemod_Transient_Removal
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              dataIn_re => CIC_Compensation_Decimator_dataOut_re,  -- sfix16_En15
              dataIn_im => CIC_Compensation_Decimator_dataOut_im,  -- sfix16_En15
              validIn => CIC_Compensation_Decimator_validOut,
              dataOut_re => dataOut_re_tmp,  -- sfix16_En15
              dataOut_im => dataOut_im_tmp,  -- sfix16_En15
              validOut => validOut
              );

  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Delay_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND validIn = '1' THEN
        Delay_rsvd_reg_im(0) <= dataIn_im_signed;
        Delay_rsvd_reg_im(1) <= Delay_rsvd_reg_im(0);
        Delay_rsvd_reg_re(0) <= dataIn_re_signed;
        Delay_rsvd_reg_re(1) <= Delay_rsvd_reg_re(0);
      END IF;
    END IF;
  END PROCESS Delay_rsvd_process;

  Delay_out1_re <= Delay_rsvd_reg_re(1);
  Delay_out1_im <= Delay_rsvd_reg_im(1);

  dataOut_re <= dataOut_re_tmp;

  dataOut_im <= dataOut_im_tmp;

END rtl;

