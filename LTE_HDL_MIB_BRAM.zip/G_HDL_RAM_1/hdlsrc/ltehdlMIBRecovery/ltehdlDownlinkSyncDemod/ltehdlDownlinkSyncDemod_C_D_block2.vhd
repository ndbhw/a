-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_C_D_block2 IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn                            :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        validIn                           :   IN    std_logic;
        dataOut                           :   OUT   std_logic_vector(28 DOWNTO 0)  -- ufix29
        );
END ltehdlDownlinkSyncDemod_C_D_block2;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_C_D_block2 IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_FirRdyLogic_block5
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dinSwitch                       :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          dinVldSwitch                    :   IN    std_logic;
          coeff                           :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          haltProcess                     :   IN    std_logic;
          dinSM                           :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          dinVldSM                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block8
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn                          :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          wrEn                            :   IN    std_logic;
          wrAddr                          :   IN    std_logic_vector(4 DOWNTO 0);  -- ufix5
          rdAddr                          :   IN    std_logic_vector(4 DOWNTO 0);  -- ufix5
          delayLineEnd                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          dataOut                         :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_FilterTapSystolic_block4
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          din_re                          :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          coeff                           :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          sumIn                           :   IN    std_logic_vector(28 DOWNTO 0);  -- ufix29
          sumOut                          :   OUT   std_logic_vector(28 DOWNTO 0)  -- ufix29
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_FirRdyLogic_block5
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_FirRdyLogic_block5(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block8
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block8(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_FilterTapSystolic_block4
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_FilterTapSystolic_block4(rtl);

  -- Functions
  -- HDLCODER_TO_STDLOGIC 
  FUNCTION hdlcoder_to_stdlogic(arg: boolean) RETURN std_logic IS
  BEGIN
    IF arg THEN
      RETURN '1';
    ELSE
      RETURN '0';
    END IF;
  END FUNCTION;


  -- Signals
  SIGNAL coeff                            : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL haltProcess                      : std_logic;
  SIGNAL dinSM                            : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dinVldSM                         : std_logic;
  SIGNAL nextDelayLineRdAddrReverse       : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL rdCountReverse_1                 : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL nextDelayLineWrAddr              : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL wrCount_1                        : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL nextDelayLineRdAddr              : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL rdCount_1                        : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL nextSharingCount                 : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL sharingCount_1                   : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL delayLineValidInP                : std_logic;
  SIGNAL lastPhaseStrobe                  : std_logic;
  SIGNAL delayLineShiftEnP                : std_logic := '0';
  SIGNAL delayLineShiftEn1_1              : std_logic := '0';
  SIGNAL delayLineShiftEn2_1              : std_logic := '0';
  SIGNAL delayLineShiftEn3_1              : std_logic := '0';
  SIGNAL validOutLookahead_reg_rsvd       : std_logic_vector(6 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [7]
  SIGNAL validOutLookahead_1              : std_logic;
  SIGNAL vldOut_1                         : std_logic := '0';
  SIGNAL notValid                         : std_logic;
  SIGNAL rdAddr0_1                        : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL rdAddr1                          : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL rdAddr2                          : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL rdAddr3                          : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL rdAddrEndNonZero                 : std_logic;
  SIGNAL rdAddrEndZero                    : std_logic;
  SIGNAL finalSumValidPipe_reg_rsvd       : std_logic_vector(5 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [6]
  SIGNAL accumulate                       : std_logic;
  SIGNAL wrAddrP                          : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL rdAddrDelayLine0                 : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL delayLineEnd0                    : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL delayLineDataOut0                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL delayLineEnd0_signed             : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL delayLineDataIn1_1               : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL wrAddr1                          : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL rdAddrDelayLine1                 : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL delayLineEnd1                    : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL delayLineDataOut1                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL delayLineEnd1_signed             : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL delayLineDataIn2_1               : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL wrAddr2                          : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL rdAddrDelayLine2                 : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL delayLineEnd2                    : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL delayLineDataOut2                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL delayLineEnd2_signed             : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL delayLineDataIn3_1               : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL wrAddr3                          : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL rdAddrDelayLine3                 : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL coeffTableOut3                   : signed(8 DOWNTO 0);  -- sfix9_En9
  SIGNAL delayLineEnd3deadOutdeadOut      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL delayLineDataOut3                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL coeffTableRegP3_1                : signed(8 DOWNTO 0) := to_signed(16#000#, 9);  -- sfix9_En9
  SIGNAL coeffTableOut2                   : signed(8 DOWNTO 0);  -- sfix9_En9
  SIGNAL coeffTableRegP2_1                : signed(8 DOWNTO 0) := to_signed(16#000#, 9);  -- sfix9_En9
  SIGNAL coeffTableOut1                   : signed(8 DOWNTO 0);  -- sfix9_En9
  SIGNAL coeffTableRegP1_1                : signed(8 DOWNTO 0) := to_signed(16#000#, 9);  -- sfix9_En9
  SIGNAL coeffTableOut0                   : signed(8 DOWNTO 0);  -- sfix9_En9
  SIGNAL coeffTableRegP0_1                : signed(8 DOWNTO 0) := to_signed(16#000#, 9);  -- sfix9_En9
  SIGNAL sumIn                            : signed(28 DOWNTO 0);  -- sfix29_En24
  SIGNAL sumOut                           : std_logic_vector(28 DOWNTO 0);  -- ufix29
  SIGNAL sumOut_0                         : std_logic_vector(28 DOWNTO 0);  -- ufix29
  SIGNAL sumOut_1                         : std_logic_vector(28 DOWNTO 0);  -- ufix29
  SIGNAL sumOut_2                         : std_logic_vector(28 DOWNTO 0);  -- ufix29
  SIGNAL sumOut_2_signed                  : signed(28 DOWNTO 0);  -- sfix29_En24
  SIGNAL sumOutReg_1                      : signed(28 DOWNTO 0) := to_signed(16#00000000#, 29);  -- sfix29_En24
  SIGNAL accDataOut                       : signed(28 DOWNTO 0) := to_signed(16#00000000#, 29);  -- sfix29_En24
  SIGNAL accSwitchOut                     : signed(28 DOWNTO 0);  -- sfix29_En24
  SIGNAL accAdderOut                      : signed(28 DOWNTO 0);  -- sfix29_En24
  SIGNAL dout_re_1                        : signed(28 DOWNTO 0) := to_signed(16#00000000#, 29);  -- sfix29_En24
  SIGNAL dataOut_tmp                      : signed(28 DOWNTO 0);  -- sfix29_En24

BEGIN
  UfirRdyLogic_6 : ltehdlDownlinkSyncDemod_FirRdyLogic_block5
    PORT MAP( clk => clk,
              enb => enb,
              dinSwitch => dataIn,  -- ufix16
              dinVldSwitch => validIn,
              coeff => std_logic_vector(coeff),  -- ufix16
              haltProcess => haltProcess,
              dinSM => dinSM,  -- ufix16
              dinVldSM => dinVldSM
              );

  UdelayLine0_7 : ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block8
    PORT MAP( clk => clk,
              enb => enb,
              dataIn => dinSM,  -- ufix16
              wrEn => delayLineValidInP,
              wrAddr => std_logic_vector(wrAddrP),  -- ufix5
              rdAddr => std_logic_vector(rdAddrDelayLine0),  -- ufix5
              delayLineEnd => delayLineEnd0,  -- ufix16
              dataOut => delayLineDataOut0  -- ufix16
              );

  UdelayLine1_7 : ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block8
    PORT MAP( clk => clk,
              enb => enb,
              dataIn => std_logic_vector(delayLineDataIn1_1),  -- ufix16
              wrEn => delayLineShiftEn1_1,
              wrAddr => std_logic_vector(wrAddr1),  -- ufix5
              rdAddr => std_logic_vector(rdAddrDelayLine1),  -- ufix5
              delayLineEnd => delayLineEnd1,  -- ufix16
              dataOut => delayLineDataOut1  -- ufix16
              );

  UdelayLine2_5 : ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block8
    PORT MAP( clk => clk,
              enb => enb,
              dataIn => std_logic_vector(delayLineDataIn2_1),  -- ufix16
              wrEn => delayLineShiftEn2_1,
              wrAddr => std_logic_vector(wrAddr2),  -- ufix5
              rdAddr => std_logic_vector(rdAddrDelayLine2),  -- ufix5
              delayLineEnd => delayLineEnd2,  -- ufix16
              dataOut => delayLineDataOut2  -- ufix16
              );

  UdelayLine3_5 : ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block8
    PORT MAP( clk => clk,
              enb => enb,
              dataIn => std_logic_vector(delayLineDataIn3_1),  -- ufix16
              wrEn => delayLineShiftEn3_1,
              wrAddr => std_logic_vector(wrAddr3),  -- ufix5
              rdAddr => std_logic_vector(rdAddrDelayLine3),  -- ufix5
              delayLineEnd => delayLineEnd3deadOutdeadOut,  -- ufix16
              dataOut => delayLineDataOut3  -- ufix16
              );

  UfilterTap0_7 : ltehdlDownlinkSyncDemod_FilterTapSystolic_block4
    PORT MAP( clk => clk,
              enb => enb,
              din_re => delayLineDataOut0,  -- ufix16
              coeff => std_logic_vector(coeffTableRegP0_1),  -- ufix9
              sumIn => std_logic_vector(sumIn),  -- ufix29
              sumOut => sumOut  -- ufix29
              );

  UfilterTap1_5 : ltehdlDownlinkSyncDemod_FilterTapSystolic_block4
    PORT MAP( clk => clk,
              enb => enb,
              din_re => delayLineDataOut1,  -- ufix16
              coeff => std_logic_vector(coeffTableRegP1_1),  -- ufix9
              sumIn => sumOut,  -- ufix29
              sumOut => sumOut_0  -- ufix29
              );

  UfilterTap2_5 : ltehdlDownlinkSyncDemod_FilterTapSystolic_block4
    PORT MAP( clk => clk,
              enb => enb,
              din_re => delayLineDataOut2,  -- ufix16
              coeff => std_logic_vector(coeffTableRegP2_1),  -- ufix9
              sumIn => sumOut_0,  -- ufix29
              sumOut => sumOut_1  -- ufix29
              );

  UfilterTap3_5 : ltehdlDownlinkSyncDemod_FilterTapSystolic_block4
    PORT MAP( clk => clk,
              enb => enb,
              din_re => delayLineDataOut3,  -- ufix16
              coeff => std_logic_vector(coeffTableRegP3_1),  -- ufix9
              sumIn => sumOut_1,  -- ufix29
              sumOut => sumOut_2  -- ufix29
              );

  coeff <= to_signed(16#0000#, 16);

  haltProcess <= '0';

  rdCountReverse_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdCountReverse_1 <= nextDelayLineRdAddrReverse;
      END IF;
    END IF;
  END PROCESS rdCountReverse_process;


  wrCount_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        wrCount_1 <= nextDelayLineWrAddr;
      END IF;
    END IF;
  END PROCESS wrCount_process;


  rdCount_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdCount_1 <= nextDelayLineRdAddr;
      END IF;
    END IF;
  END PROCESS rdCount_process;


  sharingCount_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        sharingCount_1 <= nextSharingCount;
      END IF;
    END IF;
  END PROCESS sharingCount_process;


  -- Input control counter combinatorial logic
  InputControl_output : PROCESS (dinVldSM, rdCountReverse_1, rdCount_1, sharingCount_1, wrCount_1)
    VARIABLE out4 : unsigned(4 DOWNTO 0);
  BEGIN
    delayLineValidInP <= hdlcoder_to_stdlogic((sharingCount_1 = to_unsigned(16#00#, 5)) AND (dinVldSM = '1'));
    lastPhaseStrobe <= hdlcoder_to_stdlogic(sharingCount_1 = to_unsigned(16#1F#, 5));
    IF (dinVldSM = '1') OR (sharingCount_1 > to_unsigned(16#00#, 5)) THEN 
      IF sharingCount_1 = to_unsigned(16#1F#, 5) THEN 
        nextSharingCount <= to_unsigned(16#00#, 5);
      ELSE 
        nextSharingCount <= sharingCount_1 + to_unsigned(16#01#, 5);
      END IF;
    ELSE 
      nextSharingCount <= sharingCount_1;
    END IF;
    IF dinVldSM = '1' THEN 
      IF wrCount_1 = to_unsigned(16#1F#, 5) THEN 
        out4 := to_unsigned(16#00#, 5);
      ELSE 
        out4 := wrCount_1 + to_unsigned(16#01#, 5);
      END IF;
    ELSE 
      out4 := wrCount_1;
    END IF;
    IF (rdCount_1 /= out4) OR (dinVldSM = '1') THEN 
      IF rdCount_1 = to_unsigned(16#00#, 5) THEN 
        nextDelayLineRdAddr <= to_unsigned(16#1F#, 5);
      ELSE 
        nextDelayLineRdAddr <= rdCount_1 - to_unsigned(16#01#, 5);
      END IF;
    ELSE 
      nextDelayLineRdAddr <= rdCount_1;
    END IF;
    IF (sharingCount_1 > to_unsigned(16#00#, 5)) OR (dinVldSM = '1') THEN 
      IF sharingCount_1 = to_unsigned(16#1F#, 5) THEN 
        IF wrCount_1 = to_unsigned(16#1F#, 5) THEN 
          nextDelayLineRdAddrReverse <= to_unsigned(16#00#, 5);
        ELSE 
          nextDelayLineRdAddrReverse <= wrCount_1 + to_unsigned(16#01#, 5);
        END IF;
      ELSIF rdCountReverse_1 = to_unsigned(16#1F#, 5) THEN 
        nextDelayLineRdAddrReverse <= to_unsigned(16#00#, 5);
      ELSE 
        nextDelayLineRdAddrReverse <= rdCountReverse_1 + to_unsigned(16#01#, 5);
      END IF;
    ELSE 
      nextDelayLineRdAddrReverse <= rdCountReverse_1;
    END IF;
    nextDelayLineWrAddr <= out4;
  END PROCESS InputControl_output;


  delayLineShiftEn0_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        delayLineShiftEnP <= lastPhaseStrobe;
      END IF;
    END IF;
  END PROCESS delayLineShiftEn0_process;


  delayLineShiftEn1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        delayLineShiftEn1_1 <= delayLineShiftEnP;
      END IF;
    END IF;
  END PROCESS delayLineShiftEn1_process;


  delayLineShiftEn2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        delayLineShiftEn2_1 <= delayLineShiftEn1_1;
      END IF;
    END IF;
  END PROCESS delayLineShiftEn2_process;


  delayLineShiftEn3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        delayLineShiftEn3_1 <= delayLineShiftEn2_1;
      END IF;
    END IF;
  END PROCESS delayLineShiftEn3_process;


  validOutLookahead_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        validOutLookahead_reg_rsvd(0) <= delayLineShiftEn3_1;
        validOutLookahead_reg_rsvd(6 DOWNTO 1) <= validOutLookahead_reg_rsvd(5 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS validOutLookahead_process;

  validOutLookahead_1 <= validOutLookahead_reg_rsvd(6);

  vldOut_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        vldOut_1 <= validOutLookahead_1;
      END IF;
    END IF;
  END PROCESS vldOut_process;


  notValid <=  NOT vldOut_1;

  rdAddr0_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdAddr0_1 <= sharingCount_1;
      END IF;
    END IF;
  END PROCESS rdAddr0_process;


  rdAddr0_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdAddr1 <= rdAddr0_1;
      END IF;
    END IF;
  END PROCESS rdAddr0_2_process;


  rdAddr1_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdAddr2 <= rdAddr1;
      END IF;
    END IF;
  END PROCESS rdAddr1_1_process;


  rdAddr2_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdAddr3 <= rdAddr2;
      END IF;
    END IF;
  END PROCESS rdAddr2_1_process;


  
  rdAddrEndNonZero <= '1' WHEN rdAddr3 /= to_unsigned(16#00#, 5) ELSE
      '0';

  rdAddrEndZero <=  NOT rdAddrEndNonZero;

  finalSumValidPipe_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        finalSumValidPipe_reg_rsvd(0) <= rdAddrEndZero;
        finalSumValidPipe_reg_rsvd(5 DOWNTO 1) <= finalSumValidPipe_reg_rsvd(4 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS finalSumValidPipe_process;

  accumulate <= finalSumValidPipe_reg_rsvd(5);

  wrAddr_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        wrAddrP <= wrCount_1;
      END IF;
    END IF;
  END PROCESS wrAddr_process;


  rdAddrDelayLine_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdAddrDelayLine0 <= rdCount_1;
      END IF;
    END IF;
  END PROCESS rdAddrDelayLine_process;


  delayLineEnd0_signed <= signed(delayLineEnd0);

  delayLineDataIn1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        delayLineDataIn1_1 <= delayLineEnd0_signed;
      END IF;
    END IF;
  END PROCESS delayLineDataIn1_process;


  wrAddr0_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        wrAddr1 <= wrAddrP;
      END IF;
    END IF;
  END PROCESS wrAddr0_process;


  rdAddrDelayLine0_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdAddrDelayLine1 <= rdAddrDelayLine0;
      END IF;
    END IF;
  END PROCESS rdAddrDelayLine0_1_process;


  delayLineEnd1_signed <= signed(delayLineEnd1);

  delayLineDataIn2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        delayLineDataIn2_1 <= delayLineEnd1_signed;
      END IF;
    END IF;
  END PROCESS delayLineDataIn2_process;


  wrAddr1_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        wrAddr2 <= wrAddr1;
      END IF;
    END IF;
  END PROCESS wrAddr1_1_process;


  rdAddrDelayLine1_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdAddrDelayLine2 <= rdAddrDelayLine1;
      END IF;
    END IF;
  END PROCESS rdAddrDelayLine1_1_process;


  delayLineEnd2_signed <= signed(delayLineEnd2);

  delayLineDataIn3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        delayLineDataIn3_1 <= delayLineEnd2_signed;
      END IF;
    END IF;
  END PROCESS delayLineDataIn3_process;


  wrAddr2_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        wrAddr3 <= wrAddr2;
      END IF;
    END IF;
  END PROCESS wrAddr2_1_process;


  rdAddrDelayLine2_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdAddrDelayLine3 <= rdAddrDelayLine2;
      END IF;
    END IF;
  END PROCESS rdAddrDelayLine2_1_process;


  -- Coefficient table for multiplier3
  coeffTable3_output : PROCESS (rdAddr3)
  BEGIN
    CASE rdAddr3 IS
      WHEN "00000" =>
        coeffTableOut3 <= to_signed(-16#028#, 9);
      WHEN "00001" =>
        coeffTableOut3 <= to_signed(-16#01E#, 9);
      WHEN "00010" =>
        coeffTableOut3 <= to_signed(16#027#, 9);
      WHEN "00011" =>
        coeffTableOut3 <= to_signed(16#03E#, 9);
      WHEN "00100" =>
        coeffTableOut3 <= to_signed(16#005#, 9);
      WHEN "00101" =>
        coeffTableOut3 <= to_signed(-16#039#, 9);
      WHEN "00110" =>
        coeffTableOut3 <= to_signed(-16#041#, 9);
      WHEN "00111" =>
        coeffTableOut3 <= to_signed(-16#030#, 9);
      WHEN "01000" =>
        coeffTableOut3 <= to_signed(-16#025#, 9);
      WHEN "01001" =>
        coeffTableOut3 <= to_signed(-16#006#, 9);
      WHEN "01010" =>
        coeffTableOut3 <= to_signed(16#033#, 9);
      WHEN "01011" =>
        coeffTableOut3 <= to_signed(16#045#, 9);
      WHEN "01100" =>
        coeffTableOut3 <= to_signed(16#006#, 9);
      WHEN "01101" =>
        coeffTableOut3 <= to_signed(-16#045#, 9);
      WHEN "01110" =>
        coeffTableOut3 <= to_signed(-16#03F#, 9);
      WHEN "01111" =>
        coeffTableOut3 <= to_signed(16#008#, 9);
      WHEN "10000" =>
        coeffTableOut3 <= to_signed(16#027#, 9);
      WHEN "10001" =>
        coeffTableOut3 <= to_signed(-16#006#, 9);
      WHEN "10010" =>
        coeffTableOut3 <= to_signed(-16#034#, 9);
      WHEN "10011" =>
        coeffTableOut3 <= to_signed(-16#028#, 9);
      WHEN "10100" =>
        coeffTableOut3 <= to_signed(16#006#, 9);
      WHEN "10101" =>
        coeffTableOut3 <= to_signed(16#00F#, 9);
      WHEN "10110" =>
        coeffTableOut3 <= to_signed(-16#00E#, 9);
      WHEN "10111" =>
        coeffTableOut3 <= to_signed(-16#01B#, 9);
      WHEN "11000" =>
        coeffTableOut3 <= to_signed(16#007#, 9);
      WHEN "11001" =>
        coeffTableOut3 <= to_signed(16#03B#, 9);
      WHEN "11010" =>
        coeffTableOut3 <= to_signed(16#04F#, 9);
      WHEN "11011" =>
        coeffTableOut3 <= to_signed(16#038#, 9);
      WHEN "11100" =>
        coeffTableOut3 <= to_signed(16#00F#, 9);
      WHEN "11101" =>
        coeffTableOut3 <= to_signed(-16#00B#, 9);
      WHEN "11110" =>
        coeffTableOut3 <= to_signed(-16#010#, 9);
      WHEN "11111" =>
        coeffTableOut3 <= to_signed(-16#00F#, 9);
      WHEN OTHERS => 
        coeffTableOut3 <= to_signed(16#000#, 9);
    END CASE;
  END PROCESS coeffTable3_output;


  coeffTableRegP3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        coeffTableRegP3_1 <= coeffTableOut3;
      END IF;
    END IF;
  END PROCESS coeffTableRegP3_process;


  -- Coefficient table for multiplier2
  coeffTable2_output : PROCESS (rdAddr2)
  BEGIN
    CASE rdAddr2 IS
      WHEN "00000" =>
        coeffTableOut2 <= to_signed(-16#01B#, 9);
      WHEN "00001" =>
        coeffTableOut2 <= to_signed(-16#040#, 9);
      WHEN "00010" =>
        coeffTableOut2 <= to_signed(-16#037#, 9);
      WHEN "00011" =>
        coeffTableOut2 <= to_signed(16#00B#, 9);
      WHEN "00100" =>
        coeffTableOut2 <= to_signed(16#044#, 9);
      WHEN "00101" =>
        coeffTableOut2 <= to_signed(16#02C#, 9);
      WHEN "00110" =>
        coeffTableOut2 <= to_signed(-16#028#, 9);
      WHEN "00111" =>
        coeffTableOut2 <= to_signed(-16#054#, 9);
      WHEN "01000" =>
        coeffTableOut2 <= to_signed(-16#035#, 9);
      WHEN "01001" =>
        coeffTableOut2 <= to_signed(-16#014#, 9);
      WHEN "01010" =>
        coeffTableOut2 <= to_signed(-16#02C#, 9);
      WHEN "01011" =>
        coeffTableOut2 <= to_signed(-16#04A#, 9);
      WHEN "01100" =>
        coeffTableOut2 <= to_signed(-16#024#, 9);
      WHEN "01101" =>
        coeffTableOut2 <= to_signed(16#024#, 9);
      WHEN "01110" =>
        coeffTableOut2 <= to_signed(16#03B#, 9);
      WHEN "01111" =>
        coeffTableOut2 <= to_signed(16#020#, 9);
      WHEN "10000" =>
        coeffTableOut2 <= to_signed(16#010#, 9);
      WHEN "10001" =>
        coeffTableOut2 <= to_signed(16#00E#, 9);
      WHEN "10010" =>
        coeffTableOut2 <= to_signed(-16#015#, 9);
      WHEN "10011" =>
        coeffTableOut2 <= to_signed(-16#043#, 9);
      WHEN "10100" =>
        coeffTableOut2 <= to_signed(-16#02A#, 9);
      WHEN "10101" =>
        coeffTableOut2 <= to_signed(16#02D#, 9);
      WHEN "10110" =>
        coeffTableOut2 <= to_signed(16#054#, 9);
      WHEN "10111" =>
        coeffTableOut2 <= to_signed(16#016#, 9);
      WHEN "11000" =>
        coeffTableOut2 <= to_signed(-16#02F#, 9);
      WHEN "11001" =>
        coeffTableOut2 <= to_signed(-16#01F#, 9);
      WHEN "11010" =>
        coeffTableOut2 <= to_signed(16#022#, 9);
      WHEN "11011" =>
        coeffTableOut2 <= to_signed(16#043#, 9);
      WHEN "11100" =>
        coeffTableOut2 <= to_signed(16#045#, 9);
      WHEN "11101" =>
        coeffTableOut2 <= to_signed(16#051#, 9);
      WHEN "11110" =>
        coeffTableOut2 <= to_signed(16#04F#, 9);
      WHEN "11111" =>
        coeffTableOut2 <= to_signed(16#018#, 9);
      WHEN OTHERS => 
        coeffTableOut2 <= to_signed(16#000#, 9);
    END CASE;
  END PROCESS coeffTable2_output;


  coeffTableRegP2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        coeffTableRegP2_1 <= coeffTableOut2;
      END IF;
    END IF;
  END PROCESS coeffTableRegP2_process;


  -- Coefficient table for multiplier1
  coeffTable1_output : PROCESS (rdAddr1)
  BEGIN
    CASE rdAddr1 IS
      WHEN "00000" =>
        coeffTableOut1 <= to_signed(16#04F#, 9);
      WHEN "00001" =>
        coeffTableOut1 <= to_signed(16#051#, 9);
      WHEN "00010" =>
        coeffTableOut1 <= to_signed(16#045#, 9);
      WHEN "00011" =>
        coeffTableOut1 <= to_signed(16#043#, 9);
      WHEN "00100" =>
        coeffTableOut1 <= to_signed(16#022#, 9);
      WHEN "00101" =>
        coeffTableOut1 <= to_signed(-16#01F#, 9);
      WHEN "00110" =>
        coeffTableOut1 <= to_signed(-16#02F#, 9);
      WHEN "00111" =>
        coeffTableOut1 <= to_signed(16#016#, 9);
      WHEN "01000" =>
        coeffTableOut1 <= to_signed(16#054#, 9);
      WHEN "01001" =>
        coeffTableOut1 <= to_signed(16#02D#, 9);
      WHEN "01010" =>
        coeffTableOut1 <= to_signed(-16#02A#, 9);
      WHEN "01011" =>
        coeffTableOut1 <= to_signed(-16#043#, 9);
      WHEN "01100" =>
        coeffTableOut1 <= to_signed(-16#015#, 9);
      WHEN "01101" =>
        coeffTableOut1 <= to_signed(16#00E#, 9);
      WHEN "01110" =>
        coeffTableOut1 <= to_signed(16#010#, 9);
      WHEN "01111" =>
        coeffTableOut1 <= to_signed(16#020#, 9);
      WHEN "10000" =>
        coeffTableOut1 <= to_signed(16#03B#, 9);
      WHEN "10001" =>
        coeffTableOut1 <= to_signed(16#024#, 9);
      WHEN "10010" =>
        coeffTableOut1 <= to_signed(-16#024#, 9);
      WHEN "10011" =>
        coeffTableOut1 <= to_signed(-16#04A#, 9);
      WHEN "10100" =>
        coeffTableOut1 <= to_signed(-16#02C#, 9);
      WHEN "10101" =>
        coeffTableOut1 <= to_signed(-16#014#, 9);
      WHEN "10110" =>
        coeffTableOut1 <= to_signed(-16#035#, 9);
      WHEN "10111" =>
        coeffTableOut1 <= to_signed(-16#054#, 9);
      WHEN "11000" =>
        coeffTableOut1 <= to_signed(-16#028#, 9);
      WHEN "11001" =>
        coeffTableOut1 <= to_signed(16#02C#, 9);
      WHEN "11010" =>
        coeffTableOut1 <= to_signed(16#044#, 9);
      WHEN "11011" =>
        coeffTableOut1 <= to_signed(16#00B#, 9);
      WHEN "11100" =>
        coeffTableOut1 <= to_signed(-16#037#, 9);
      WHEN "11101" =>
        coeffTableOut1 <= to_signed(-16#040#, 9);
      WHEN "11110" =>
        coeffTableOut1 <= to_signed(-16#01B#, 9);
      WHEN "11111" =>
        coeffTableOut1 <= to_signed(-16#006#, 9);
      WHEN OTHERS => 
        coeffTableOut1 <= to_signed(16#000#, 9);
    END CASE;
  END PROCESS coeffTable1_output;


  coeffTableRegP1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        coeffTableRegP1_1 <= coeffTableOut1;
      END IF;
    END IF;
  END PROCESS coeffTableRegP1_process;


  -- Coefficient table for multiplier0
  coeffTable0_output : PROCESS (rdAddr0_1)
  BEGIN
    CASE rdAddr0_1 IS
      WHEN "00000" =>
        coeffTableOut0 <= to_signed(-16#010#, 9);
      WHEN "00001" =>
        coeffTableOut0 <= to_signed(-16#00B#, 9);
      WHEN "00010" =>
        coeffTableOut0 <= to_signed(16#00F#, 9);
      WHEN "00011" =>
        coeffTableOut0 <= to_signed(16#038#, 9);
      WHEN "00100" =>
        coeffTableOut0 <= to_signed(16#04F#, 9);
      WHEN "00101" =>
        coeffTableOut0 <= to_signed(16#03B#, 9);
      WHEN "00110" =>
        coeffTableOut0 <= to_signed(16#007#, 9);
      WHEN "00111" =>
        coeffTableOut0 <= to_signed(-16#01B#, 9);
      WHEN "01000" =>
        coeffTableOut0 <= to_signed(-16#00E#, 9);
      WHEN "01001" =>
        coeffTableOut0 <= to_signed(16#00F#, 9);
      WHEN "01010" =>
        coeffTableOut0 <= to_signed(16#006#, 9);
      WHEN "01011" =>
        coeffTableOut0 <= to_signed(-16#028#, 9);
      WHEN "01100" =>
        coeffTableOut0 <= to_signed(-16#034#, 9);
      WHEN "01101" =>
        coeffTableOut0 <= to_signed(-16#006#, 9);
      WHEN "01110" =>
        coeffTableOut0 <= to_signed(16#027#, 9);
      WHEN "01111" =>
        coeffTableOut0 <= to_signed(16#008#, 9);
      WHEN "10000" =>
        coeffTableOut0 <= to_signed(-16#03F#, 9);
      WHEN "10001" =>
        coeffTableOut0 <= to_signed(-16#045#, 9);
      WHEN "10010" =>
        coeffTableOut0 <= to_signed(16#006#, 9);
      WHEN "10011" =>
        coeffTableOut0 <= to_signed(16#045#, 9);
      WHEN "10100" =>
        coeffTableOut0 <= to_signed(16#033#, 9);
      WHEN "10101" =>
        coeffTableOut0 <= to_signed(-16#006#, 9);
      WHEN "10110" =>
        coeffTableOut0 <= to_signed(-16#025#, 9);
      WHEN "10111" =>
        coeffTableOut0 <= to_signed(-16#030#, 9);
      WHEN "11000" =>
        coeffTableOut0 <= to_signed(-16#041#, 9);
      WHEN "11001" =>
        coeffTableOut0 <= to_signed(-16#039#, 9);
      WHEN "11010" =>
        coeffTableOut0 <= to_signed(16#005#, 9);
      WHEN "11011" =>
        coeffTableOut0 <= to_signed(16#03E#, 9);
      WHEN "11100" =>
        coeffTableOut0 <= to_signed(16#027#, 9);
      WHEN "11101" =>
        coeffTableOut0 <= to_signed(-16#01E#, 9);
      WHEN "11110" =>
        coeffTableOut0 <= to_signed(-16#028#, 9);
      WHEN "11111" =>
        coeffTableOut0 <= to_signed(16#018#, 9);
      WHEN OTHERS => 
        coeffTableOut0 <= to_signed(16#000#, 9);
    END CASE;
  END PROCESS coeffTable0_output;


  coeffTableRegP0_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        coeffTableRegP0_1 <= coeffTableOut0;
      END IF;
    END IF;
  END PROCESS coeffTableRegP0_process;


  sumIn <= to_signed(16#00000000#, 29);

  sumOut_2_signed <= signed(sumOut_2);

  sumOutReg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        sumOutReg_1 <= sumOut_2_signed;
      END IF;
    END IF;
  END PROCESS sumOutReg_process;


  
  accSwitchOut <= accDataOut WHEN accumulate = '0' ELSE
      to_signed(16#00000000#, 29);

  accAdderOut <= accSwitchOut + sumOutReg_1;

  accDataOut_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        accDataOut <= accAdderOut;
      END IF;
    END IF;
  END PROCESS accDataOut_1_process;


  dout_re_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND validOutLookahead_1 = '1' THEN
        dout_re_1 <= accDataOut;
      END IF;
    END IF;
  END PROCESS dout_re_process;


  
  dataOut_tmp <= dout_re_1 WHEN notValid = '0' ELSE
      to_signed(16#00000000#, 29);

  dataOut <= std_logic_vector(dataOut_tmp);

END rtl;

