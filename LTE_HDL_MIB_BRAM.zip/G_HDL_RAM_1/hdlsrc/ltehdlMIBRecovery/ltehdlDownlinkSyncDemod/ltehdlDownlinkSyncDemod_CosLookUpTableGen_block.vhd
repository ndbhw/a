-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_CosLookUpTableGen_block IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        lutaddr                           :   IN    std_logic_vector(10 DOWNTO 0);  -- ufix11
        lutCosine                         :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
        );
END ltehdlDownlinkSyncDemod_CosLookUpTableGen_block;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_CosLookUpTableGen_block IS

  -- Constants
  CONSTANT DirectLookupTable_data         : vector_of_signed16(0 TO 2047) := 
    (to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#4000#, 
      16), to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#4000#, 16), 
      to_signed(16#4000#, 16), to_signed(16#4000#, 16), to_signed(16#3FFF#, 16), to_signed(16#3FFF#, 16), to_signed(16#3FFF#, 16), to_signed(16#3FFF#, 16), to_signed(16#3FFF#, 16), to_signed(16#3FFF#, 16), to_signed(16#3FFF#, 16), 
      to_signed(16#3FFF#, 16), to_signed(16#3FFF#, 16), to_signed(16#3FFF#, 16), to_signed(16#3FFF#, 16), to_signed(16#3FFF#, 16), to_signed(16#3FFF#, 16), to_signed(16#3FFF#, 16), to_signed(16#3FFF#, 16), to_signed(16#3FFE#, 16), 
      to_signed(16#3FFE#, 16), to_signed(16#3FFE#, 16), to_signed(16#3FFE#, 16), to_signed(16#3FFE#, 16), to_signed(16#3FFE#, 16), to_signed(16#3FFE#, 16), to_signed(16#3FFE#, 16), to_signed(16#3FFE#, 16), to_signed(16#3FFE#, 16), 
      to_signed(16#3FFD#, 16), to_signed(16#3FFD#, 16), to_signed(16#3FFD#, 16), to_signed(16#3FFD#, 16), to_signed(16#3FFD#, 16), to_signed(16#3FFD#, 16), to_signed(16#3FFD#, 16), to_signed(16#3FFD#, 16), to_signed(16#3FFC#, 16), 
      to_signed(16#3FFC#, 16), to_signed(16#3FFC#, 16), to_signed(16#3FFC#, 16), to_signed(16#3FFC#, 16), to_signed(16#3FFC#, 16), to_signed(16#3FFC#, 16), to_signed(16#3FFC#, 16), to_signed(16#3FFB#, 16), to_signed(16#3FFB#, 16), 
      to_signed(16#3FFB#, 16), to_signed(16#3FFB#, 16), to_signed(16#3FFB#, 16), to_signed(16#3FFB#, 16), to_signed(16#3FFA#, 16), to_signed(16#3FFA#, 16), to_signed(16#3FFA#, 16), to_signed(16#3FFA#, 16), to_signed(16#3FFA#, 16), 
      to_signed(16#3FFA#, 16), to_signed(16#3FF9#, 16), to_signed(16#3FF9#, 16), to_signed(16#3FF9#, 16), to_signed(16#3FF9#, 16), to_signed(16#3FF9#, 16), to_signed(16#3FF8#, 16), to_signed(16#3FF8#, 16), to_signed(16#3FF8#, 16), 
      to_signed(16#3FF8#, 16), to_signed(16#3FF8#, 16), to_signed(16#3FF7#, 16), to_signed(16#3FF7#, 16), to_signed(16#3FF7#, 16), to_signed(16#3FF7#, 16), to_signed(16#3FF7#, 16), to_signed(16#3FF6#, 16), to_signed(16#3FF6#, 16), 
      to_signed(16#3FF6#, 16), to_signed(16#3FF6#, 16), to_signed(16#3FF6#, 16), to_signed(16#3FF5#, 16), to_signed(16#3FF5#, 16), to_signed(16#3FF5#, 16), to_signed(16#3FF5#, 16), to_signed(16#3FF4#, 16), to_signed(16#3FF4#, 16), 
      to_signed(16#3FF4#, 16), to_signed(16#3FF4#, 16), to_signed(16#3FF3#, 16), to_signed(16#3FF3#, 16), to_signed(16#3FF3#, 16), to_signed(16#3FF3#, 16), to_signed(16#3FF2#, 16), to_signed(16#3FF2#, 16), to_signed(16#3FF2#, 16), 
      to_signed(16#3FF2#, 16), to_signed(16#3FF1#, 16), to_signed(16#3FF1#, 16), to_signed(16#3FF1#, 16), to_signed(16#3FF1#, 16), to_signed(16#3FF0#, 16), to_signed(16#3FF0#, 16), to_signed(16#3FF0#, 16), to_signed(16#3FF0#, 16), 
      to_signed(16#3FEF#, 16), to_signed(16#3FEF#, 16), to_signed(16#3FEF#, 16), to_signed(16#3FEE#, 16), to_signed(16#3FEE#, 16), to_signed(16#3FEE#, 16), to_signed(16#3FED#, 16), to_signed(16#3FED#, 16), to_signed(16#3FED#, 16), 
      to_signed(16#3FED#, 16), to_signed(16#3FEC#, 16), to_signed(16#3FEC#, 16), to_signed(16#3FEC#, 16), to_signed(16#3FEB#, 16), to_signed(16#3FEB#, 16), to_signed(16#3FEB#, 16), to_signed(16#3FEA#, 16), to_signed(16#3FEA#, 16), 
      to_signed(16#3FEA#, 16), to_signed(16#3FE9#, 16), to_signed(16#3FE9#, 16), to_signed(16#3FE9#, 16), to_signed(16#3FE8#, 16), to_signed(16#3FE8#, 16), to_signed(16#3FE8#, 16), to_signed(16#3FE7#, 16), to_signed(16#3FE7#, 16), 
      to_signed(16#3FE7#, 16), to_signed(16#3FE6#, 16), to_signed(16#3FE6#, 16), to_signed(16#3FE6#, 16), to_signed(16#3FE5#, 16), to_signed(16#3FE5#, 16), to_signed(16#3FE5#, 16), to_signed(16#3FE4#, 16), to_signed(16#3FE4#, 16), 
      to_signed(16#3FE3#, 16), to_signed(16#3FE3#, 16), to_signed(16#3FE3#, 16), to_signed(16#3FE2#, 16), to_signed(16#3FE2#, 16), to_signed(16#3FE2#, 16), to_signed(16#3FE1#, 16), to_signed(16#3FE1#, 16), to_signed(16#3FE0#, 16), 
      to_signed(16#3FE0#, 16), to_signed(16#3FE0#, 16), to_signed(16#3FDF#, 16), to_signed(16#3FDF#, 16), to_signed(16#3FDE#, 16), to_signed(16#3FDE#, 16), to_signed(16#3FDE#, 16), to_signed(16#3FDD#, 16), to_signed(16#3FDD#, 16), 
      to_signed(16#3FDC#, 16), to_signed(16#3FDC#, 16), to_signed(16#3FDC#, 16), to_signed(16#3FDB#, 16), to_signed(16#3FDB#, 16), to_signed(16#3FDA#, 16), to_signed(16#3FDA#, 16), to_signed(16#3FD9#, 16), to_signed(16#3FD9#, 16), 
      to_signed(16#3FD9#, 16), to_signed(16#3FD8#, 16), to_signed(16#3FD8#, 16), to_signed(16#3FD7#, 16), to_signed(16#3FD7#, 16), to_signed(16#3FD6#, 16), to_signed(16#3FD6#, 16), to_signed(16#3FD5#, 16), to_signed(16#3FD5#, 16), 
      to_signed(16#3FD5#, 16), to_signed(16#3FD4#, 16), to_signed(16#3FD4#, 16), to_signed(16#3FD3#, 16), to_signed(16#3FD3#, 16), to_signed(16#3FD2#, 16), to_signed(16#3FD2#, 16), to_signed(16#3FD1#, 16), to_signed(16#3FD1#, 16), 
      to_signed(16#3FD0#, 16), to_signed(16#3FD0#, 16), to_signed(16#3FCF#, 16), to_signed(16#3FCF#, 16), to_signed(16#3FCE#, 16), to_signed(16#3FCE#, 16), to_signed(16#3FCD#, 16), to_signed(16#3FCD#, 16), to_signed(16#3FCC#, 16), 
      to_signed(16#3FCC#, 16), to_signed(16#3FCB#, 16), to_signed(16#3FCB#, 16), to_signed(16#3FCA#, 16), to_signed(16#3FCA#, 16), to_signed(16#3FC9#, 16), to_signed(16#3FC9#, 16), to_signed(16#3FC8#, 16), to_signed(16#3FC8#, 16), 
      to_signed(16#3FC7#, 16), to_signed(16#3FC7#, 16), to_signed(16#3FC6#, 16), to_signed(16#3FC6#, 16), to_signed(16#3FC5#, 16), to_signed(16#3FC5#, 16), to_signed(16#3FC4#, 16), to_signed(16#3FC4#, 16), to_signed(16#3FC3#, 16), 
      to_signed(16#3FC3#, 16), to_signed(16#3FC2#, 16), to_signed(16#3FC1#, 16), to_signed(16#3FC1#, 16), to_signed(16#3FC0#, 16), to_signed(16#3FC0#, 16), to_signed(16#3FBF#, 16), to_signed(16#3FBF#, 16), to_signed(16#3FBE#, 16), 
      to_signed(16#3FBE#, 16), to_signed(16#3FBD#, 16), to_signed(16#3FBC#, 16), to_signed(16#3FBC#, 16), to_signed(16#3FBB#, 16), to_signed(16#3FBB#, 16), to_signed(16#3FBA#, 16), to_signed(16#3FB9#, 16), to_signed(16#3FB9#, 16), 
      to_signed(16#3FB8#, 16), to_signed(16#3FB8#, 16), to_signed(16#3FB7#, 16), to_signed(16#3FB7#, 16), to_signed(16#3FB6#, 16), to_signed(16#3FB5#, 16), to_signed(16#3FB5#, 16), to_signed(16#3FB4#, 16), to_signed(16#3FB4#, 16), 
      to_signed(16#3FB3#, 16), to_signed(16#3FB2#, 16), to_signed(16#3FB2#, 16), to_signed(16#3FB1#, 16), to_signed(16#3FB0#, 16), to_signed(16#3FB0#, 16), to_signed(16#3FAF#, 16), to_signed(16#3FAF#, 16), to_signed(16#3FAE#, 16), 
      to_signed(16#3FAD#, 16), to_signed(16#3FAD#, 16), to_signed(16#3FAC#, 16), to_signed(16#3FAB#, 16), to_signed(16#3FAB#, 16), to_signed(16#3FAA#, 16), to_signed(16#3FAA#, 16), to_signed(16#3FA9#, 16), to_signed(16#3FA8#, 16), 
      to_signed(16#3FA8#, 16), to_signed(16#3FA7#, 16), to_signed(16#3FA6#, 16), to_signed(16#3FA6#, 16), to_signed(16#3FA5#, 16), to_signed(16#3FA4#, 16), to_signed(16#3FA4#, 16), to_signed(16#3FA3#, 16), to_signed(16#3FA2#, 16), 
      to_signed(16#3FA2#, 16), to_signed(16#3FA1#, 16), to_signed(16#3FA0#, 16), to_signed(16#3FA0#, 16), to_signed(16#3F9F#, 16), to_signed(16#3F9E#, 16), to_signed(16#3F9E#, 16), to_signed(16#3F9D#, 16), to_signed(16#3F9C#, 16), 
      to_signed(16#3F9B#, 16), to_signed(16#3F9B#, 16), to_signed(16#3F9A#, 16), to_signed(16#3F99#, 16), to_signed(16#3F99#, 16), to_signed(16#3F98#, 16), to_signed(16#3F97#, 16), to_signed(16#3F97#, 16), to_signed(16#3F96#, 16), 
      to_signed(16#3F95#, 16), to_signed(16#3F94#, 16), to_signed(16#3F94#, 16), to_signed(16#3F93#, 16), to_signed(16#3F92#, 16), to_signed(16#3F92#, 16), to_signed(16#3F91#, 16), to_signed(16#3F90#, 16), to_signed(16#3F8F#, 16), 
      to_signed(16#3F8F#, 16), to_signed(16#3F8E#, 16), to_signed(16#3F8D#, 16), to_signed(16#3F8C#, 16), to_signed(16#3F8C#, 16), to_signed(16#3F8B#, 16), to_signed(16#3F8A#, 16), to_signed(16#3F89#, 16), to_signed(16#3F89#, 16), 
      to_signed(16#3F88#, 16), to_signed(16#3F87#, 16), to_signed(16#3F86#, 16), to_signed(16#3F86#, 16), to_signed(16#3F85#, 16), to_signed(16#3F84#, 16), to_signed(16#3F83#, 16), to_signed(16#3F82#, 16), to_signed(16#3F82#, 16), 
      to_signed(16#3F81#, 16), to_signed(16#3F80#, 16), to_signed(16#3F7F#, 16), to_signed(16#3F7F#, 16), to_signed(16#3F7E#, 16), to_signed(16#3F7D#, 16), to_signed(16#3F7C#, 16), to_signed(16#3F7B#, 16), to_signed(16#3F7B#, 16), 
      to_signed(16#3F7A#, 16), to_signed(16#3F79#, 16), to_signed(16#3F78#, 16), to_signed(16#3F77#, 16), to_signed(16#3F77#, 16), to_signed(16#3F76#, 16), to_signed(16#3F75#, 16), to_signed(16#3F74#, 16), to_signed(16#3F73#, 16), 
      to_signed(16#3F72#, 16), to_signed(16#3F72#, 16), to_signed(16#3F71#, 16), to_signed(16#3F70#, 16), to_signed(16#3F6F#, 16), to_signed(16#3F6E#, 16), to_signed(16#3F6D#, 16), to_signed(16#3F6D#, 16), to_signed(16#3F6C#, 16), 
      to_signed(16#3F6B#, 16), to_signed(16#3F6A#, 16), to_signed(16#3F69#, 16), to_signed(16#3F68#, 16), to_signed(16#3F68#, 16), to_signed(16#3F67#, 16), to_signed(16#3F66#, 16), to_signed(16#3F65#, 16), to_signed(16#3F64#, 16), 
      to_signed(16#3F63#, 16), to_signed(16#3F62#, 16), to_signed(16#3F62#, 16), to_signed(16#3F61#, 16), to_signed(16#3F60#, 16), to_signed(16#3F5F#, 16), to_signed(16#3F5E#, 16), to_signed(16#3F5D#, 16), to_signed(16#3F5C#, 16), 
      to_signed(16#3F5B#, 16), to_signed(16#3F5A#, 16), to_signed(16#3F5A#, 16), to_signed(16#3F59#, 16), to_signed(16#3F58#, 16), to_signed(16#3F57#, 16), to_signed(16#3F56#, 16), to_signed(16#3F55#, 16), to_signed(16#3F54#, 16), 
      to_signed(16#3F53#, 16), to_signed(16#3F52#, 16), to_signed(16#3F51#, 16), to_signed(16#3F51#, 16), to_signed(16#3F50#, 16), to_signed(16#3F4F#, 16), to_signed(16#3F4E#, 16), to_signed(16#3F4D#, 16), to_signed(16#3F4C#, 16), 
      to_signed(16#3F4B#, 16), to_signed(16#3F4A#, 16), to_signed(16#3F49#, 16), to_signed(16#3F48#, 16), to_signed(16#3F47#, 16), to_signed(16#3F46#, 16), to_signed(16#3F45#, 16), to_signed(16#3F44#, 16), to_signed(16#3F43#, 16), 
      to_signed(16#3F42#, 16), to_signed(16#3F42#, 16), to_signed(16#3F41#, 16), to_signed(16#3F40#, 16), to_signed(16#3F3F#, 16), to_signed(16#3F3E#, 16), to_signed(16#3F3D#, 16), to_signed(16#3F3C#, 16), to_signed(16#3F3B#, 16), 
      to_signed(16#3F3A#, 16), to_signed(16#3F39#, 16), to_signed(16#3F38#, 16), to_signed(16#3F37#, 16), to_signed(16#3F36#, 16), to_signed(16#3F35#, 16), to_signed(16#3F34#, 16), to_signed(16#3F33#, 16), to_signed(16#3F32#, 16), 
      to_signed(16#3F31#, 16), to_signed(16#3F30#, 16), to_signed(16#3F2F#, 16), to_signed(16#3F2E#, 16), to_signed(16#3F2D#, 16), to_signed(16#3F2C#, 16), to_signed(16#3F2B#, 16), to_signed(16#3F2A#, 16), to_signed(16#3F29#, 16), 
      to_signed(16#3F28#, 16), to_signed(16#3F27#, 16), to_signed(16#3F26#, 16), to_signed(16#3F25#, 16), to_signed(16#3F24#, 16), to_signed(16#3F23#, 16), to_signed(16#3F22#, 16), to_signed(16#3F21#, 16), to_signed(16#3F20#, 16), 
      to_signed(16#3F1F#, 16), to_signed(16#3F1E#, 16), to_signed(16#3F1D#, 16), to_signed(16#3F1C#, 16), to_signed(16#3F1A#, 16), to_signed(16#3F19#, 16), to_signed(16#3F18#, 16), to_signed(16#3F17#, 16), to_signed(16#3F16#, 16), 
      to_signed(16#3F15#, 16), to_signed(16#3F14#, 16), to_signed(16#3F13#, 16), to_signed(16#3F12#, 16), to_signed(16#3F11#, 16), to_signed(16#3F10#, 16), to_signed(16#3F0F#, 16), to_signed(16#3F0E#, 16), to_signed(16#3F0D#, 16), 
      to_signed(16#3F0C#, 16), to_signed(16#3F0A#, 16), to_signed(16#3F09#, 16), to_signed(16#3F08#, 16), to_signed(16#3F07#, 16), to_signed(16#3F06#, 16), to_signed(16#3F05#, 16), to_signed(16#3F04#, 16), to_signed(16#3F03#, 16), 
      to_signed(16#3F02#, 16), to_signed(16#3F01#, 16), to_signed(16#3F00#, 16), to_signed(16#3EFE#, 16), to_signed(16#3EFD#, 16), to_signed(16#3EFC#, 16), to_signed(16#3EFB#, 16), to_signed(16#3EFA#, 16), to_signed(16#3EF9#, 16), 
      to_signed(16#3EF8#, 16), to_signed(16#3EF7#, 16), to_signed(16#3EF5#, 16), to_signed(16#3EF4#, 16), to_signed(16#3EF3#, 16), to_signed(16#3EF2#, 16), to_signed(16#3EF1#, 16), to_signed(16#3EF0#, 16), to_signed(16#3EEF#, 16), 
      to_signed(16#3EED#, 16), to_signed(16#3EEC#, 16), to_signed(16#3EEB#, 16), to_signed(16#3EEA#, 16), to_signed(16#3EE9#, 16), to_signed(16#3EE8#, 16), to_signed(16#3EE7#, 16), to_signed(16#3EE5#, 16), to_signed(16#3EE4#, 16), 
      to_signed(16#3EE3#, 16), to_signed(16#3EE2#, 16), to_signed(16#3EE1#, 16), to_signed(16#3EE0#, 16), to_signed(16#3EDE#, 16), to_signed(16#3EDD#, 16), to_signed(16#3EDC#, 16), to_signed(16#3EDB#, 16), to_signed(16#3EDA#, 16), 
      to_signed(16#3ED8#, 16), to_signed(16#3ED7#, 16), to_signed(16#3ED6#, 16), to_signed(16#3ED5#, 16), to_signed(16#3ED4#, 16), to_signed(16#3ED3#, 16), to_signed(16#3ED1#, 16), to_signed(16#3ED0#, 16), to_signed(16#3ECF#, 16), 
      to_signed(16#3ECE#, 16), to_signed(16#3ECC#, 16), to_signed(16#3ECB#, 16), to_signed(16#3ECA#, 16), to_signed(16#3EC9#, 16), to_signed(16#3EC8#, 16), to_signed(16#3EC6#, 16), to_signed(16#3EC5#, 16), to_signed(16#3EC4#, 16), 
      to_signed(16#3EC3#, 16), to_signed(16#3EC1#, 16), to_signed(16#3EC0#, 16), to_signed(16#3EBF#, 16), to_signed(16#3EBE#, 16), to_signed(16#3EBD#, 16), to_signed(16#3EBB#, 16), to_signed(16#3EBA#, 16), to_signed(16#3EB9#, 16), 
      to_signed(16#3EB8#, 16), to_signed(16#3EB6#, 16), to_signed(16#3EB5#, 16), to_signed(16#3EB4#, 16), to_signed(16#3EB3#, 16), to_signed(16#3EB1#, 16), to_signed(16#3EB0#, 16), to_signed(16#3EAF#, 16), to_signed(16#3EAD#, 16), 
      to_signed(16#3EAC#, 16), to_signed(16#3EAB#, 16), to_signed(16#3EAA#, 16), to_signed(16#3EA8#, 16), to_signed(16#3EA7#, 16), to_signed(16#3EA6#, 16), to_signed(16#3EA5#, 16), to_signed(16#3EA3#, 16), to_signed(16#3EA2#, 16), 
      to_signed(16#3EA1#, 16), to_signed(16#3E9F#, 16), to_signed(16#3E9E#, 16), to_signed(16#3E9D#, 16), to_signed(16#3E9B#, 16), to_signed(16#3E9A#, 16), to_signed(16#3E99#, 16), to_signed(16#3E98#, 16), to_signed(16#3E96#, 16), 
      to_signed(16#3E95#, 16), to_signed(16#3E94#, 16), to_signed(16#3E92#, 16), to_signed(16#3E91#, 16), to_signed(16#3E90#, 16), to_signed(16#3E8E#, 16), to_signed(16#3E8D#, 16), to_signed(16#3E8C#, 16), to_signed(16#3E8A#, 16), 
      to_signed(16#3E89#, 16), to_signed(16#3E88#, 16), to_signed(16#3E86#, 16), to_signed(16#3E85#, 16), to_signed(16#3E84#, 16), to_signed(16#3E82#, 16), to_signed(16#3E81#, 16), to_signed(16#3E80#, 16), to_signed(16#3E7E#, 16), 
      to_signed(16#3E7D#, 16), to_signed(16#3E7B#, 16), to_signed(16#3E7A#, 16), to_signed(16#3E79#, 16), to_signed(16#3E77#, 16), to_signed(16#3E76#, 16), to_signed(16#3E75#, 16), to_signed(16#3E73#, 16), to_signed(16#3E72#, 16), 
      to_signed(16#3E71#, 16), to_signed(16#3E6F#, 16), to_signed(16#3E6E#, 16), to_signed(16#3E6C#, 16), to_signed(16#3E6B#, 16), to_signed(16#3E6A#, 16), to_signed(16#3E68#, 16), to_signed(16#3E67#, 16), to_signed(16#3E65#, 16), 
      to_signed(16#3E64#, 16), to_signed(16#3E63#, 16), to_signed(16#3E61#, 16), to_signed(16#3E60#, 16), to_signed(16#3E5E#, 16), to_signed(16#3E5D#, 16), to_signed(16#3E5C#, 16), to_signed(16#3E5A#, 16), to_signed(16#3E59#, 16), 
      to_signed(16#3E57#, 16), to_signed(16#3E56#, 16), to_signed(16#3E54#, 16), to_signed(16#3E53#, 16), to_signed(16#3E52#, 16), to_signed(16#3E50#, 16), to_signed(16#3E4F#, 16), to_signed(16#3E4D#, 16), to_signed(16#3E4C#, 16), 
      to_signed(16#3E4A#, 16), to_signed(16#3E49#, 16), to_signed(16#3E48#, 16), to_signed(16#3E46#, 16), to_signed(16#3E45#, 16), to_signed(16#3E43#, 16), to_signed(16#3E42#, 16), to_signed(16#3E40#, 16), to_signed(16#3E3F#, 16), 
      to_signed(16#3E3D#, 16), to_signed(16#3E3C#, 16), to_signed(16#3E3A#, 16), to_signed(16#3E39#, 16), to_signed(16#3E37#, 16), to_signed(16#3E36#, 16), to_signed(16#3E35#, 16), to_signed(16#3E33#, 16), to_signed(16#3E32#, 16), 
      to_signed(16#3E30#, 16), to_signed(16#3E2F#, 16), to_signed(16#3E2D#, 16), to_signed(16#3E2C#, 16), to_signed(16#3E2A#, 16), to_signed(16#3E29#, 16), to_signed(16#3E27#, 16), to_signed(16#3E26#, 16), to_signed(16#3E24#, 16), 
      to_signed(16#3E23#, 16), to_signed(16#3E21#, 16), to_signed(16#3E20#, 16), to_signed(16#3E1E#, 16), to_signed(16#3E1D#, 16), to_signed(16#3E1B#, 16), to_signed(16#3E1A#, 16), to_signed(16#3E18#, 16), to_signed(16#3E17#, 16), 
      to_signed(16#3E15#, 16), to_signed(16#3E13#, 16), to_signed(16#3E12#, 16), to_signed(16#3E10#, 16), to_signed(16#3E0F#, 16), to_signed(16#3E0D#, 16), to_signed(16#3E0C#, 16), to_signed(16#3E0A#, 16), to_signed(16#3E09#, 16), 
      to_signed(16#3E07#, 16), to_signed(16#3E06#, 16), to_signed(16#3E04#, 16), to_signed(16#3E03#, 16), to_signed(16#3E01#, 16), to_signed(16#3DFF#, 16), to_signed(16#3DFE#, 16), to_signed(16#3DFC#, 16), to_signed(16#3DFB#, 16), 
      to_signed(16#3DF9#, 16), to_signed(16#3DF8#, 16), to_signed(16#3DF6#, 16), to_signed(16#3DF4#, 16), to_signed(16#3DF3#, 16), to_signed(16#3DF1#, 16), to_signed(16#3DF0#, 16), to_signed(16#3DEE#, 16), to_signed(16#3DED#, 16), 
      to_signed(16#3DEB#, 16), to_signed(16#3DE9#, 16), to_signed(16#3DE8#, 16), to_signed(16#3DE6#, 16), to_signed(16#3DE5#, 16), to_signed(16#3DE3#, 16), to_signed(16#3DE1#, 16), to_signed(16#3DE0#, 16), to_signed(16#3DDE#, 16), 
      to_signed(16#3DDD#, 16), to_signed(16#3DDB#, 16), to_signed(16#3DD9#, 16), to_signed(16#3DD8#, 16), to_signed(16#3DD6#, 16), to_signed(16#3DD4#, 16), to_signed(16#3DD3#, 16), to_signed(16#3DD1#, 16), to_signed(16#3DD0#, 16), 
      to_signed(16#3DCE#, 16), to_signed(16#3DCC#, 16), to_signed(16#3DCB#, 16), to_signed(16#3DC9#, 16), to_signed(16#3DC7#, 16), to_signed(16#3DC6#, 16), to_signed(16#3DC4#, 16), to_signed(16#3DC2#, 16), to_signed(16#3DC1#, 16), 
      to_signed(16#3DBF#, 16), to_signed(16#3DBD#, 16), to_signed(16#3DBC#, 16), to_signed(16#3DBA#, 16), to_signed(16#3DB9#, 16), to_signed(16#3DB7#, 16), to_signed(16#3DB5#, 16), to_signed(16#3DB4#, 16), to_signed(16#3DB2#, 16), 
      to_signed(16#3DB0#, 16), to_signed(16#3DAF#, 16), to_signed(16#3DAD#, 16), to_signed(16#3DAB#, 16), to_signed(16#3DA9#, 16), to_signed(16#3DA8#, 16), to_signed(16#3DA6#, 16), to_signed(16#3DA4#, 16), to_signed(16#3DA3#, 16), 
      to_signed(16#3DA1#, 16), to_signed(16#3D9F#, 16), to_signed(16#3D9E#, 16), to_signed(16#3D9C#, 16), to_signed(16#3D9A#, 16), to_signed(16#3D99#, 16), to_signed(16#3D97#, 16), to_signed(16#3D95#, 16), to_signed(16#3D93#, 16), 
      to_signed(16#3D92#, 16), to_signed(16#3D90#, 16), to_signed(16#3D8E#, 16), to_signed(16#3D8D#, 16), to_signed(16#3D8B#, 16), to_signed(16#3D89#, 16), to_signed(16#3D87#, 16), to_signed(16#3D86#, 16), to_signed(16#3D84#, 16), 
      to_signed(16#3D82#, 16), to_signed(16#3D80#, 16), to_signed(16#3D7F#, 16), to_signed(16#3D7D#, 16), to_signed(16#3D7B#, 16), to_signed(16#3D79#, 16), to_signed(16#3D78#, 16), to_signed(16#3D76#, 16), to_signed(16#3D74#, 16), 
      to_signed(16#3D72#, 16), to_signed(16#3D71#, 16), to_signed(16#3D6F#, 16), to_signed(16#3D6D#, 16), to_signed(16#3D6B#, 16), to_signed(16#3D6A#, 16), to_signed(16#3D68#, 16), to_signed(16#3D66#, 16), to_signed(16#3D64#, 16), 
      to_signed(16#3D63#, 16), to_signed(16#3D61#, 16), to_signed(16#3D5F#, 16), to_signed(16#3D5D#, 16), to_signed(16#3D5B#, 16), to_signed(16#3D5A#, 16), to_signed(16#3D58#, 16), to_signed(16#3D56#, 16), to_signed(16#3D54#, 16), 
      to_signed(16#3D52#, 16), to_signed(16#3D51#, 16), to_signed(16#3D4F#, 16), to_signed(16#3D4D#, 16), to_signed(16#3D4B#, 16), to_signed(16#3D49#, 16), to_signed(16#3D48#, 16), to_signed(16#3D46#, 16), to_signed(16#3D44#, 16), 
      to_signed(16#3D42#, 16), to_signed(16#3D40#, 16), to_signed(16#3D3F#, 16), to_signed(16#3D3D#, 16), to_signed(16#3D3B#, 16), to_signed(16#3D39#, 16), to_signed(16#3D37#, 16), to_signed(16#3D35#, 16), to_signed(16#3D34#, 16), 
      to_signed(16#3D32#, 16), to_signed(16#3D30#, 16), to_signed(16#3D2E#, 16), to_signed(16#3D2C#, 16), to_signed(16#3D2A#, 16), to_signed(16#3D28#, 16), to_signed(16#3D27#, 16), to_signed(16#3D25#, 16), to_signed(16#3D23#, 16), 
      to_signed(16#3D21#, 16), to_signed(16#3D1F#, 16), to_signed(16#3D1D#, 16), to_signed(16#3D1B#, 16), to_signed(16#3D1A#, 16), to_signed(16#3D18#, 16), to_signed(16#3D16#, 16), to_signed(16#3D14#, 16), to_signed(16#3D12#, 16), 
      to_signed(16#3D10#, 16), to_signed(16#3D0E#, 16), to_signed(16#3D0C#, 16), to_signed(16#3D0B#, 16), to_signed(16#3D09#, 16), to_signed(16#3D07#, 16), to_signed(16#3D05#, 16), to_signed(16#3D03#, 16), to_signed(16#3D01#, 16), 
      to_signed(16#3CFF#, 16), to_signed(16#3CFD#, 16), to_signed(16#3CFB#, 16), to_signed(16#3CF9#, 16), to_signed(16#3CF8#, 16), to_signed(16#3CF6#, 16), to_signed(16#3CF4#, 16), to_signed(16#3CF2#, 16), to_signed(16#3CF0#, 16), 
      to_signed(16#3CEE#, 16), to_signed(16#3CEC#, 16), to_signed(16#3CEA#, 16), to_signed(16#3CE8#, 16), to_signed(16#3CE6#, 16), to_signed(16#3CE4#, 16), to_signed(16#3CE2#, 16), to_signed(16#3CE0#, 16), to_signed(16#3CDE#, 16), 
      to_signed(16#3CDD#, 16), to_signed(16#3CDB#, 16), to_signed(16#3CD9#, 16), to_signed(16#3CD7#, 16), to_signed(16#3CD5#, 16), to_signed(16#3CD3#, 16), to_signed(16#3CD1#, 16), to_signed(16#3CCF#, 16), to_signed(16#3CCD#, 16), 
      to_signed(16#3CCB#, 16), to_signed(16#3CC9#, 16), to_signed(16#3CC7#, 16), to_signed(16#3CC5#, 16), to_signed(16#3CC3#, 16), to_signed(16#3CC1#, 16), to_signed(16#3CBF#, 16), to_signed(16#3CBD#, 16), to_signed(16#3CBB#, 16), 
      to_signed(16#3CB9#, 16), to_signed(16#3CB7#, 16), to_signed(16#3CB5#, 16), to_signed(16#3CB3#, 16), to_signed(16#3CB1#, 16), to_signed(16#3CAF#, 16), to_signed(16#3CAD#, 16), to_signed(16#3CAB#, 16), to_signed(16#3CA9#, 16), 
      to_signed(16#3CA7#, 16), to_signed(16#3CA5#, 16), to_signed(16#3CA3#, 16), to_signed(16#3CA1#, 16), to_signed(16#3C9F#, 16), to_signed(16#3C9D#, 16), to_signed(16#3C9B#, 16), to_signed(16#3C99#, 16), to_signed(16#3C97#, 16), 
      to_signed(16#3C95#, 16), to_signed(16#3C93#, 16), to_signed(16#3C91#, 16), to_signed(16#3C8F#, 16), to_signed(16#3C8D#, 16), to_signed(16#3C8B#, 16), to_signed(16#3C89#, 16), to_signed(16#3C87#, 16), to_signed(16#3C85#, 16), 
      to_signed(16#3C83#, 16), to_signed(16#3C81#, 16), to_signed(16#3C7F#, 16), to_signed(16#3C7D#, 16), to_signed(16#3C7B#, 16), to_signed(16#3C79#, 16), to_signed(16#3C76#, 16), to_signed(16#3C74#, 16), to_signed(16#3C72#, 16), 
      to_signed(16#3C70#, 16), to_signed(16#3C6E#, 16), to_signed(16#3C6C#, 16), to_signed(16#3C6A#, 16), to_signed(16#3C68#, 16), to_signed(16#3C66#, 16), to_signed(16#3C64#, 16), to_signed(16#3C62#, 16), to_signed(16#3C60#, 16), 
      to_signed(16#3C5E#, 16), to_signed(16#3C5B#, 16), to_signed(16#3C59#, 16), to_signed(16#3C57#, 16), to_signed(16#3C55#, 16), to_signed(16#3C53#, 16), to_signed(16#3C51#, 16), to_signed(16#3C4F#, 16), to_signed(16#3C4D#, 16), 
      to_signed(16#3C4B#, 16), to_signed(16#3C49#, 16), to_signed(16#3C46#, 16), to_signed(16#3C44#, 16), to_signed(16#3C42#, 16), to_signed(16#3C40#, 16), to_signed(16#3C3E#, 16), to_signed(16#3C3C#, 16), to_signed(16#3C3A#, 16), 
      to_signed(16#3C38#, 16), to_signed(16#3C36#, 16), to_signed(16#3C33#, 16), to_signed(16#3C31#, 16), to_signed(16#3C2F#, 16), to_signed(16#3C2D#, 16), to_signed(16#3C2B#, 16), to_signed(16#3C29#, 16), to_signed(16#3C27#, 16), 
      to_signed(16#3C24#, 16), to_signed(16#3C22#, 16), to_signed(16#3C20#, 16), to_signed(16#3C1E#, 16), to_signed(16#3C1C#, 16), to_signed(16#3C1A#, 16), to_signed(16#3C17#, 16), to_signed(16#3C15#, 16), to_signed(16#3C13#, 16), 
      to_signed(16#3C11#, 16), to_signed(16#3C0F#, 16), to_signed(16#3C0D#, 16), to_signed(16#3C0A#, 16), to_signed(16#3C08#, 16), to_signed(16#3C06#, 16), to_signed(16#3C04#, 16), to_signed(16#3C02#, 16), to_signed(16#3C00#, 16), 
      to_signed(16#3BFD#, 16), to_signed(16#3BFB#, 16), to_signed(16#3BF9#, 16), to_signed(16#3BF7#, 16), to_signed(16#3BF5#, 16), to_signed(16#3BF2#, 16), to_signed(16#3BF0#, 16), to_signed(16#3BEE#, 16), to_signed(16#3BEC#, 16), 
      to_signed(16#3BEA#, 16), to_signed(16#3BE7#, 16), to_signed(16#3BE5#, 16), to_signed(16#3BE3#, 16), to_signed(16#3BE1#, 16), to_signed(16#3BDE#, 16), to_signed(16#3BDC#, 16), to_signed(16#3BDA#, 16), to_signed(16#3BD8#, 16), 
      to_signed(16#3BD6#, 16), to_signed(16#3BD3#, 16), to_signed(16#3BD1#, 16), to_signed(16#3BCF#, 16), to_signed(16#3BCD#, 16), to_signed(16#3BCA#, 16), to_signed(16#3BC8#, 16), to_signed(16#3BC6#, 16), to_signed(16#3BC4#, 16), 
      to_signed(16#3BC1#, 16), to_signed(16#3BBF#, 16), to_signed(16#3BBD#, 16), to_signed(16#3BBB#, 16), to_signed(16#3BB8#, 16), to_signed(16#3BB6#, 16), to_signed(16#3BB4#, 16), to_signed(16#3BB2#, 16), to_signed(16#3BAF#, 16), 
      to_signed(16#3BAD#, 16), to_signed(16#3BAB#, 16), to_signed(16#3BA9#, 16), to_signed(16#3BA6#, 16), to_signed(16#3BA4#, 16), to_signed(16#3BA2#, 16), to_signed(16#3B9F#, 16), to_signed(16#3B9D#, 16), to_signed(16#3B9B#, 16), 
      to_signed(16#3B99#, 16), to_signed(16#3B96#, 16), to_signed(16#3B94#, 16), to_signed(16#3B92#, 16), to_signed(16#3B8F#, 16), to_signed(16#3B8D#, 16), to_signed(16#3B8B#, 16), to_signed(16#3B88#, 16), to_signed(16#3B86#, 16), 
      to_signed(16#3B84#, 16), to_signed(16#3B82#, 16), to_signed(16#3B7F#, 16), to_signed(16#3B7D#, 16), to_signed(16#3B7B#, 16), to_signed(16#3B78#, 16), to_signed(16#3B76#, 16), to_signed(16#3B74#, 16), to_signed(16#3B71#, 16), 
      to_signed(16#3B6F#, 16), to_signed(16#3B6D#, 16), to_signed(16#3B6A#, 16), to_signed(16#3B68#, 16), to_signed(16#3B66#, 16), to_signed(16#3B63#, 16), to_signed(16#3B61#, 16), to_signed(16#3B5F#, 16), to_signed(16#3B5C#, 16), 
      to_signed(16#3B5A#, 16), to_signed(16#3B58#, 16), to_signed(16#3B55#, 16), to_signed(16#3B53#, 16), to_signed(16#3B50#, 16), to_signed(16#3B4E#, 16), to_signed(16#3B4C#, 16), to_signed(16#3B49#, 16), to_signed(16#3B47#, 16), 
      to_signed(16#3B45#, 16), to_signed(16#3B42#, 16), to_signed(16#3B40#, 16), to_signed(16#3B3E#, 16), to_signed(16#3B3B#, 16), to_signed(16#3B39#, 16), to_signed(16#3B36#, 16), to_signed(16#3B34#, 16), to_signed(16#3B32#, 16), 
      to_signed(16#3B2F#, 16), to_signed(16#3B2D#, 16), to_signed(16#3B2A#, 16), to_signed(16#3B28#, 16), to_signed(16#3B26#, 16), to_signed(16#3B23#, 16), to_signed(16#3B21#, 16), to_signed(16#3B1E#, 16), to_signed(16#3B1C#, 16), 
      to_signed(16#3B1A#, 16), to_signed(16#3B17#, 16), to_signed(16#3B15#, 16), to_signed(16#3B12#, 16), to_signed(16#3B10#, 16), to_signed(16#3B0E#, 16), to_signed(16#3B0B#, 16), to_signed(16#3B09#, 16), to_signed(16#3B06#, 16), 
      to_signed(16#3B04#, 16), to_signed(16#3B01#, 16), to_signed(16#3AFF#, 16), to_signed(16#3AFD#, 16), to_signed(16#3AFA#, 16), to_signed(16#3AF8#, 16), to_signed(16#3AF5#, 16), to_signed(16#3AF3#, 16), to_signed(16#3AF0#, 16), 
      to_signed(16#3AEE#, 16), to_signed(16#3AEB#, 16), to_signed(16#3AE9#, 16), to_signed(16#3AE6#, 16), to_signed(16#3AE4#, 16), to_signed(16#3AE2#, 16), to_signed(16#3ADF#, 16), to_signed(16#3ADD#, 16), to_signed(16#3ADA#, 16), 
      to_signed(16#3AD8#, 16), to_signed(16#3AD5#, 16), to_signed(16#3AD3#, 16), to_signed(16#3AD0#, 16), to_signed(16#3ACE#, 16), to_signed(16#3ACB#, 16), to_signed(16#3AC9#, 16), to_signed(16#3AC6#, 16), to_signed(16#3AC4#, 16), 
      to_signed(16#3AC1#, 16), to_signed(16#3ABF#, 16), to_signed(16#3ABC#, 16), to_signed(16#3ABA#, 16), to_signed(16#3AB7#, 16), to_signed(16#3AB5#, 16), to_signed(16#3AB2#, 16), to_signed(16#3AB0#, 16), to_signed(16#3AAD#, 16), 
      to_signed(16#3AAB#, 16), to_signed(16#3AA8#, 16), to_signed(16#3AA6#, 16), to_signed(16#3AA3#, 16), to_signed(16#3AA1#, 16), to_signed(16#3A9E#, 16), to_signed(16#3A9C#, 16), to_signed(16#3A99#, 16), to_signed(16#3A97#, 16), 
      to_signed(16#3A94#, 16), to_signed(16#3A92#, 16), to_signed(16#3A8F#, 16), to_signed(16#3A8D#, 16), to_signed(16#3A8A#, 16), to_signed(16#3A88#, 16), to_signed(16#3A85#, 16), to_signed(16#3A82#, 16), to_signed(16#3A80#, 16), 
      to_signed(16#3A7D#, 16), to_signed(16#3A7B#, 16), to_signed(16#3A78#, 16), to_signed(16#3A76#, 16), to_signed(16#3A73#, 16), to_signed(16#3A71#, 16), to_signed(16#3A6E#, 16), to_signed(16#3A6B#, 16), to_signed(16#3A69#, 16), 
      to_signed(16#3A66#, 16), to_signed(16#3A64#, 16), to_signed(16#3A61#, 16), to_signed(16#3A5F#, 16), to_signed(16#3A5C#, 16), to_signed(16#3A59#, 16), to_signed(16#3A57#, 16), to_signed(16#3A54#, 16), to_signed(16#3A52#, 16), 
      to_signed(16#3A4F#, 16), to_signed(16#3A4C#, 16), to_signed(16#3A4A#, 16), to_signed(16#3A47#, 16), to_signed(16#3A45#, 16), to_signed(16#3A42#, 16), to_signed(16#3A3F#, 16), to_signed(16#3A3D#, 16), to_signed(16#3A3A#, 16), 
      to_signed(16#3A38#, 16), to_signed(16#3A35#, 16), to_signed(16#3A32#, 16), to_signed(16#3A30#, 16), to_signed(16#3A2D#, 16), to_signed(16#3A2B#, 16), to_signed(16#3A28#, 16), to_signed(16#3A25#, 16), to_signed(16#3A23#, 16), 
      to_signed(16#3A20#, 16), to_signed(16#3A1D#, 16), to_signed(16#3A1B#, 16), to_signed(16#3A18#, 16), to_signed(16#3A16#, 16), to_signed(16#3A13#, 16), to_signed(16#3A10#, 16), to_signed(16#3A0E#, 16), to_signed(16#3A0B#, 16), 
      to_signed(16#3A08#, 16), to_signed(16#3A06#, 16), to_signed(16#3A03#, 16), to_signed(16#3A00#, 16), to_signed(16#39FE#, 16), to_signed(16#39FB#, 16), to_signed(16#39F8#, 16), to_signed(16#39F6#, 16), to_signed(16#39F3#, 16), 
      to_signed(16#39F0#, 16), to_signed(16#39EE#, 16), to_signed(16#39EB#, 16), to_signed(16#39E8#, 16), to_signed(16#39E6#, 16), to_signed(16#39E3#, 16), to_signed(16#39E0#, 16), to_signed(16#39DE#, 16), to_signed(16#39DB#, 16), 
      to_signed(16#39D8#, 16), to_signed(16#39D6#, 16), to_signed(16#39D3#, 16), to_signed(16#39D0#, 16), to_signed(16#39CE#, 16), to_signed(16#39CB#, 16), to_signed(16#39C8#, 16), to_signed(16#39C5#, 16), to_signed(16#39C3#, 16), 
      to_signed(16#39C0#, 16), to_signed(16#39BD#, 16), to_signed(16#39BB#, 16), to_signed(16#39B8#, 16), to_signed(16#39B5#, 16), to_signed(16#39B2#, 16), to_signed(16#39B0#, 16), to_signed(16#39AD#, 16), to_signed(16#39AA#, 16), 
      to_signed(16#39A8#, 16), to_signed(16#39A5#, 16), to_signed(16#39A2#, 16), to_signed(16#399F#, 16), to_signed(16#399D#, 16), to_signed(16#399A#, 16), to_signed(16#3997#, 16), to_signed(16#3994#, 16), to_signed(16#3992#, 16), 
      to_signed(16#398F#, 16), to_signed(16#398C#, 16), to_signed(16#3989#, 16), to_signed(16#3987#, 16), to_signed(16#3984#, 16), to_signed(16#3981#, 16), to_signed(16#397E#, 16), to_signed(16#397C#, 16), to_signed(16#3979#, 16), 
      to_signed(16#3976#, 16), to_signed(16#3973#, 16), to_signed(16#3971#, 16), to_signed(16#396E#, 16), to_signed(16#396B#, 16), to_signed(16#3968#, 16), to_signed(16#3965#, 16), to_signed(16#3963#, 16), to_signed(16#3960#, 16), 
      to_signed(16#395D#, 16), to_signed(16#395A#, 16), to_signed(16#3958#, 16), to_signed(16#3955#, 16), to_signed(16#3952#, 16), to_signed(16#394F#, 16), to_signed(16#394C#, 16), to_signed(16#394A#, 16), to_signed(16#3947#, 16), 
      to_signed(16#3944#, 16), to_signed(16#3941#, 16), to_signed(16#393E#, 16), to_signed(16#393B#, 16), to_signed(16#3939#, 16), to_signed(16#3936#, 16), to_signed(16#3933#, 16), to_signed(16#3930#, 16), to_signed(16#392D#, 16), 
      to_signed(16#392B#, 16), to_signed(16#3928#, 16), to_signed(16#3925#, 16), to_signed(16#3922#, 16), to_signed(16#391F#, 16), to_signed(16#391C#, 16), to_signed(16#391A#, 16), to_signed(16#3917#, 16), to_signed(16#3914#, 16), 
      to_signed(16#3911#, 16), to_signed(16#390E#, 16), to_signed(16#390B#, 16), to_signed(16#3909#, 16), to_signed(16#3906#, 16), to_signed(16#3903#, 16), to_signed(16#3900#, 16), to_signed(16#38FD#, 16), to_signed(16#38FA#, 16), 
      to_signed(16#38F7#, 16), to_signed(16#38F5#, 16), to_signed(16#38F2#, 16), to_signed(16#38EF#, 16), to_signed(16#38EC#, 16), to_signed(16#38E9#, 16), to_signed(16#38E6#, 16), to_signed(16#38E3#, 16), to_signed(16#38E0#, 16), 
      to_signed(16#38DE#, 16), to_signed(16#38DB#, 16), to_signed(16#38D8#, 16), to_signed(16#38D5#, 16), to_signed(16#38D2#, 16), to_signed(16#38CF#, 16), to_signed(16#38CC#, 16), to_signed(16#38C9#, 16), to_signed(16#38C6#, 16), 
      to_signed(16#38C3#, 16), to_signed(16#38C1#, 16), to_signed(16#38BE#, 16), to_signed(16#38BB#, 16), to_signed(16#38B8#, 16), to_signed(16#38B5#, 16), to_signed(16#38B2#, 16), to_signed(16#38AF#, 16), to_signed(16#38AC#, 16), 
      to_signed(16#38A9#, 16), to_signed(16#38A6#, 16), to_signed(16#38A3#, 16), to_signed(16#38A1#, 16), to_signed(16#389E#, 16), to_signed(16#389B#, 16), to_signed(16#3898#, 16), to_signed(16#3895#, 16), to_signed(16#3892#, 16), 
      to_signed(16#388F#, 16), to_signed(16#388C#, 16), to_signed(16#3889#, 16), to_signed(16#3886#, 16), to_signed(16#3883#, 16), to_signed(16#3880#, 16), to_signed(16#387D#, 16), to_signed(16#387A#, 16), to_signed(16#3877#, 16), 
      to_signed(16#3874#, 16), to_signed(16#3871#, 16), to_signed(16#386E#, 16), to_signed(16#386B#, 16), to_signed(16#3869#, 16), to_signed(16#3866#, 16), to_signed(16#3863#, 16), to_signed(16#3860#, 16), to_signed(16#385D#, 16), 
      to_signed(16#385A#, 16), to_signed(16#3857#, 16), to_signed(16#3854#, 16), to_signed(16#3851#, 16), to_signed(16#384E#, 16), to_signed(16#384B#, 16), to_signed(16#3848#, 16), to_signed(16#3845#, 16), to_signed(16#3842#, 16), 
      to_signed(16#383F#, 16), to_signed(16#383C#, 16), to_signed(16#3839#, 16), to_signed(16#3836#, 16), to_signed(16#3833#, 16), to_signed(16#3830#, 16), to_signed(16#382D#, 16), to_signed(16#382A#, 16), to_signed(16#3827#, 16), 
      to_signed(16#3824#, 16), to_signed(16#3821#, 16), to_signed(16#381E#, 16), to_signed(16#381B#, 16), to_signed(16#3818#, 16), to_signed(16#3815#, 16), to_signed(16#3812#, 16), to_signed(16#380F#, 16), to_signed(16#380B#, 16), 
      to_signed(16#3808#, 16), to_signed(16#3805#, 16), to_signed(16#3802#, 16), to_signed(16#37FF#, 16), to_signed(16#37FC#, 16), to_signed(16#37F9#, 16), to_signed(16#37F6#, 16), to_signed(16#37F3#, 16), to_signed(16#37F0#, 16), 
      to_signed(16#37ED#, 16), to_signed(16#37EA#, 16), to_signed(16#37E7#, 16), to_signed(16#37E4#, 16), to_signed(16#37E1#, 16), to_signed(16#37DE#, 16), to_signed(16#37DB#, 16), to_signed(16#37D8#, 16), to_signed(16#37D5#, 16), 
      to_signed(16#37D1#, 16), to_signed(16#37CE#, 16), to_signed(16#37CB#, 16), to_signed(16#37C8#, 16), to_signed(16#37C5#, 16), to_signed(16#37C2#, 16), to_signed(16#37BF#, 16), to_signed(16#37BC#, 16), to_signed(16#37B9#, 16), 
      to_signed(16#37B6#, 16), to_signed(16#37B3#, 16), to_signed(16#37B0#, 16), to_signed(16#37AC#, 16), to_signed(16#37A9#, 16), to_signed(16#37A6#, 16), to_signed(16#37A3#, 16), to_signed(16#37A0#, 16), to_signed(16#379D#, 16), 
      to_signed(16#379A#, 16), to_signed(16#3797#, 16), to_signed(16#3794#, 16), to_signed(16#3790#, 16), to_signed(16#378D#, 16), to_signed(16#378A#, 16), to_signed(16#3787#, 16), to_signed(16#3784#, 16), to_signed(16#3781#, 16), 
      to_signed(16#377E#, 16), to_signed(16#377B#, 16), to_signed(16#3777#, 16), to_signed(16#3774#, 16), to_signed(16#3771#, 16), to_signed(16#376E#, 16), to_signed(16#376B#, 16), to_signed(16#3768#, 16), to_signed(16#3765#, 16), 
      to_signed(16#3761#, 16), to_signed(16#375E#, 16), to_signed(16#375B#, 16), to_signed(16#3758#, 16), to_signed(16#3755#, 16), to_signed(16#3752#, 16), to_signed(16#374E#, 16), to_signed(16#374B#, 16), to_signed(16#3748#, 16), 
      to_signed(16#3745#, 16), to_signed(16#3742#, 16), to_signed(16#373F#, 16), to_signed(16#373B#, 16), to_signed(16#3738#, 16), to_signed(16#3735#, 16), to_signed(16#3732#, 16), to_signed(16#372F#, 16), to_signed(16#372C#, 16), 
      to_signed(16#3728#, 16), to_signed(16#3725#, 16), to_signed(16#3722#, 16), to_signed(16#371F#, 16), to_signed(16#371C#, 16), to_signed(16#3718#, 16), to_signed(16#3715#, 16), to_signed(16#3712#, 16), to_signed(16#370F#, 16), 
      to_signed(16#370C#, 16), to_signed(16#3708#, 16), to_signed(16#3705#, 16), to_signed(16#3702#, 16), to_signed(16#36FF#, 16), to_signed(16#36FC#, 16), to_signed(16#36F8#, 16), to_signed(16#36F5#, 16), to_signed(16#36F2#, 16), 
      to_signed(16#36EF#, 16), to_signed(16#36EB#, 16), to_signed(16#36E8#, 16), to_signed(16#36E5#, 16), to_signed(16#36E2#, 16), to_signed(16#36DF#, 16), to_signed(16#36DB#, 16), to_signed(16#36D8#, 16), to_signed(16#36D5#, 16), 
      to_signed(16#36D2#, 16), to_signed(16#36CE#, 16), to_signed(16#36CB#, 16), to_signed(16#36C8#, 16), to_signed(16#36C5#, 16), to_signed(16#36C1#, 16), to_signed(16#36BE#, 16), to_signed(16#36BB#, 16), to_signed(16#36B8#, 16), 
      to_signed(16#36B4#, 16), to_signed(16#36B1#, 16), to_signed(16#36AE#, 16), to_signed(16#36AB#, 16), to_signed(16#36A7#, 16), to_signed(16#36A4#, 16), to_signed(16#36A1#, 16), to_signed(16#369D#, 16), to_signed(16#369A#, 16), 
      to_signed(16#3697#, 16), to_signed(16#3694#, 16), to_signed(16#3690#, 16), to_signed(16#368D#, 16), to_signed(16#368A#, 16), to_signed(16#3686#, 16), to_signed(16#3683#, 16), to_signed(16#3680#, 16), to_signed(16#367D#, 16), 
      to_signed(16#3679#, 16), to_signed(16#3676#, 16), to_signed(16#3673#, 16), to_signed(16#366F#, 16), to_signed(16#366C#, 16), to_signed(16#3669#, 16), to_signed(16#3665#, 16), to_signed(16#3662#, 16), to_signed(16#365F#, 16), 
      to_signed(16#365C#, 16), to_signed(16#3658#, 16), to_signed(16#3655#, 16), to_signed(16#3652#, 16), to_signed(16#364E#, 16), to_signed(16#364B#, 16), to_signed(16#3648#, 16), to_signed(16#3644#, 16), to_signed(16#3641#, 16), 
      to_signed(16#363E#, 16), to_signed(16#363A#, 16), to_signed(16#3637#, 16), to_signed(16#3634#, 16), to_signed(16#3630#, 16), to_signed(16#362D#, 16), to_signed(16#362A#, 16), to_signed(16#3626#, 16), to_signed(16#3623#, 16), 
      to_signed(16#3620#, 16), to_signed(16#361C#, 16), to_signed(16#3619#, 16), to_signed(16#3615#, 16), to_signed(16#3612#, 16), to_signed(16#360F#, 16), to_signed(16#360B#, 16), to_signed(16#3608#, 16), to_signed(16#3605#, 16), 
      to_signed(16#3601#, 16), to_signed(16#35FE#, 16), to_signed(16#35FB#, 16), to_signed(16#35F7#, 16), to_signed(16#35F4#, 16), to_signed(16#35F0#, 16), to_signed(16#35ED#, 16), to_signed(16#35EA#, 16), to_signed(16#35E6#, 16), 
      to_signed(16#35E3#, 16), to_signed(16#35DF#, 16), to_signed(16#35DC#, 16), to_signed(16#35D9#, 16), to_signed(16#35D5#, 16), to_signed(16#35D2#, 16), to_signed(16#35CE#, 16), to_signed(16#35CB#, 16), to_signed(16#35C8#, 16), 
      to_signed(16#35C4#, 16), to_signed(16#35C1#, 16), to_signed(16#35BD#, 16), to_signed(16#35BA#, 16), to_signed(16#35B7#, 16), to_signed(16#35B3#, 16), to_signed(16#35B0#, 16), to_signed(16#35AC#, 16), to_signed(16#35A9#, 16), 
      to_signed(16#35A5#, 16), to_signed(16#35A2#, 16), to_signed(16#359F#, 16), to_signed(16#359B#, 16), to_signed(16#3598#, 16), to_signed(16#3594#, 16), to_signed(16#3591#, 16), to_signed(16#358D#, 16), to_signed(16#358A#, 16), 
      to_signed(16#3587#, 16), to_signed(16#3583#, 16), to_signed(16#3580#, 16), to_signed(16#357C#, 16), to_signed(16#3579#, 16), to_signed(16#3575#, 16), to_signed(16#3572#, 16), to_signed(16#356E#, 16), to_signed(16#356B#, 16), 
      to_signed(16#3567#, 16), to_signed(16#3564#, 16), to_signed(16#3561#, 16), to_signed(16#355D#, 16), to_signed(16#355A#, 16), to_signed(16#3556#, 16), to_signed(16#3553#, 16), to_signed(16#354F#, 16), to_signed(16#354C#, 16), 
      to_signed(16#3548#, 16), to_signed(16#3545#, 16), to_signed(16#3541#, 16), to_signed(16#353E#, 16), to_signed(16#353A#, 16), to_signed(16#3537#, 16), to_signed(16#3533#, 16), to_signed(16#3530#, 16), to_signed(16#352C#, 16), 
      to_signed(16#3529#, 16), to_signed(16#3525#, 16), to_signed(16#3522#, 16), to_signed(16#351E#, 16), to_signed(16#351B#, 16), to_signed(16#3517#, 16), to_signed(16#3514#, 16), to_signed(16#3510#, 16), to_signed(16#350D#, 16), 
      to_signed(16#3509#, 16), to_signed(16#3506#, 16), to_signed(16#3502#, 16), to_signed(16#34FF#, 16), to_signed(16#34FB#, 16), to_signed(16#34F8#, 16), to_signed(16#34F4#, 16), to_signed(16#34F1#, 16), to_signed(16#34ED#, 16), 
      to_signed(16#34EA#, 16), to_signed(16#34E6#, 16), to_signed(16#34E2#, 16), to_signed(16#34DF#, 16), to_signed(16#34DB#, 16), to_signed(16#34D8#, 16), to_signed(16#34D4#, 16), to_signed(16#34D1#, 16), to_signed(16#34CD#, 16), 
      to_signed(16#34CA#, 16), to_signed(16#34C6#, 16), to_signed(16#34C3#, 16), to_signed(16#34BF#, 16), to_signed(16#34BB#, 16), to_signed(16#34B8#, 16), to_signed(16#34B4#, 16), to_signed(16#34B1#, 16), to_signed(16#34AD#, 16), 
      to_signed(16#34AA#, 16), to_signed(16#34A6#, 16), to_signed(16#34A2#, 16), to_signed(16#349F#, 16), to_signed(16#349B#, 16), to_signed(16#3498#, 16), to_signed(16#3494#, 16), to_signed(16#3491#, 16), to_signed(16#348D#, 16), 
      to_signed(16#3489#, 16), to_signed(16#3486#, 16), to_signed(16#3482#, 16), to_signed(16#347F#, 16), to_signed(16#347B#, 16), to_signed(16#3477#, 16), to_signed(16#3474#, 16), to_signed(16#3470#, 16), to_signed(16#346D#, 16), 
      to_signed(16#3469#, 16), to_signed(16#3465#, 16), to_signed(16#3462#, 16), to_signed(16#345E#, 16), to_signed(16#345B#, 16), to_signed(16#3457#, 16), to_signed(16#3453#, 16), to_signed(16#3450#, 16), to_signed(16#344C#, 16), 
      to_signed(16#3448#, 16), to_signed(16#3445#, 16), to_signed(16#3441#, 16), to_signed(16#343E#, 16), to_signed(16#343A#, 16), to_signed(16#3436#, 16), to_signed(16#3433#, 16), to_signed(16#342F#, 16), to_signed(16#342B#, 16), 
      to_signed(16#3428#, 16), to_signed(16#3424#, 16), to_signed(16#3420#, 16), to_signed(16#341D#, 16), to_signed(16#3419#, 16), to_signed(16#3416#, 16), to_signed(16#3412#, 16), to_signed(16#340E#, 16), to_signed(16#340B#, 16), 
      to_signed(16#3407#, 16), to_signed(16#3403#, 16), to_signed(16#3400#, 16), to_signed(16#33FC#, 16), to_signed(16#33F8#, 16), to_signed(16#33F5#, 16), to_signed(16#33F1#, 16), to_signed(16#33ED#, 16), to_signed(16#33EA#, 16), 
      to_signed(16#33E6#, 16), to_signed(16#33E2#, 16), to_signed(16#33DF#, 16), to_signed(16#33DB#, 16), to_signed(16#33D7#, 16), to_signed(16#33D3#, 16), to_signed(16#33D0#, 16), to_signed(16#33CC#, 16), to_signed(16#33C8#, 16), 
      to_signed(16#33C5#, 16), to_signed(16#33C1#, 16), to_signed(16#33BD#, 16), to_signed(16#33BA#, 16), to_signed(16#33B6#, 16), to_signed(16#33B2#, 16), to_signed(16#33AF#, 16), to_signed(16#33AB#, 16), to_signed(16#33A7#, 16), 
      to_signed(16#33A3#, 16), to_signed(16#33A0#, 16), to_signed(16#339C#, 16), to_signed(16#3398#, 16), to_signed(16#3395#, 16), to_signed(16#3391#, 16), to_signed(16#338D#, 16), to_signed(16#3389#, 16), to_signed(16#3386#, 16), 
      to_signed(16#3382#, 16), to_signed(16#337E#, 16), to_signed(16#337A#, 16), to_signed(16#3377#, 16), to_signed(16#3373#, 16), to_signed(16#336F#, 16), to_signed(16#336B#, 16), to_signed(16#3368#, 16), to_signed(16#3364#, 16), 
      to_signed(16#3360#, 16), to_signed(16#335D#, 16), to_signed(16#3359#, 16), to_signed(16#3355#, 16), to_signed(16#3351#, 16), to_signed(16#334E#, 16), to_signed(16#334A#, 16), to_signed(16#3346#, 16), to_signed(16#3342#, 16), 
      to_signed(16#333E#, 16), to_signed(16#333B#, 16), to_signed(16#3337#, 16), to_signed(16#3333#, 16), to_signed(16#332F#, 16), to_signed(16#332C#, 16), to_signed(16#3328#, 16), to_signed(16#3324#, 16), to_signed(16#3320#, 16), 
      to_signed(16#331D#, 16), to_signed(16#3319#, 16), to_signed(16#3315#, 16), to_signed(16#3311#, 16), to_signed(16#330D#, 16), to_signed(16#330A#, 16), to_signed(16#3306#, 16), to_signed(16#3302#, 16), to_signed(16#32FE#, 16), 
      to_signed(16#32FA#, 16), to_signed(16#32F7#, 16), to_signed(16#32F3#, 16), to_signed(16#32EF#, 16), to_signed(16#32EB#, 16), to_signed(16#32E7#, 16), to_signed(16#32E4#, 16), to_signed(16#32E0#, 16), to_signed(16#32DC#, 16), 
      to_signed(16#32D8#, 16), to_signed(16#32D4#, 16), to_signed(16#32D0#, 16), to_signed(16#32CD#, 16), to_signed(16#32C9#, 16), to_signed(16#32C5#, 16), to_signed(16#32C1#, 16), to_signed(16#32BD#, 16), to_signed(16#32BA#, 16), 
      to_signed(16#32B6#, 16), to_signed(16#32B2#, 16), to_signed(16#32AE#, 16), to_signed(16#32AA#, 16), to_signed(16#32A6#, 16), to_signed(16#32A3#, 16), to_signed(16#329F#, 16), to_signed(16#329B#, 16), to_signed(16#3297#, 16), 
      to_signed(16#3293#, 16), to_signed(16#328F#, 16), to_signed(16#328B#, 16), to_signed(16#3288#, 16), to_signed(16#3284#, 16), to_signed(16#3280#, 16), to_signed(16#327C#, 16), to_signed(16#3278#, 16), to_signed(16#3274#, 16), 
      to_signed(16#3270#, 16), to_signed(16#326D#, 16), to_signed(16#3269#, 16), to_signed(16#3265#, 16), to_signed(16#3261#, 16), to_signed(16#325D#, 16), to_signed(16#3259#, 16), to_signed(16#3255#, 16), to_signed(16#3251#, 16), 
      to_signed(16#324E#, 16), to_signed(16#324A#, 16), to_signed(16#3246#, 16), to_signed(16#3242#, 16), to_signed(16#323E#, 16), to_signed(16#323A#, 16), to_signed(16#3236#, 16), to_signed(16#3232#, 16), to_signed(16#322E#, 16), 
      to_signed(16#322A#, 16), to_signed(16#3227#, 16), to_signed(16#3223#, 16), to_signed(16#321F#, 16), to_signed(16#321B#, 16), to_signed(16#3217#, 16), to_signed(16#3213#, 16), to_signed(16#320F#, 16), to_signed(16#320B#, 16), 
      to_signed(16#3207#, 16), to_signed(16#3203#, 16), to_signed(16#31FF#, 16), to_signed(16#31FC#, 16), to_signed(16#31F8#, 16), to_signed(16#31F4#, 16), to_signed(16#31F0#, 16), to_signed(16#31EC#, 16), to_signed(16#31E8#, 16), 
      to_signed(16#31E4#, 16), to_signed(16#31E0#, 16), to_signed(16#31DC#, 16), to_signed(16#31D8#, 16), to_signed(16#31D4#, 16), to_signed(16#31D0#, 16), to_signed(16#31CC#, 16), to_signed(16#31C8#, 16), to_signed(16#31C4#, 16), 
      to_signed(16#31C0#, 16), to_signed(16#31BC#, 16), to_signed(16#31B9#, 16), to_signed(16#31B5#, 16), to_signed(16#31B1#, 16), to_signed(16#31AD#, 16), to_signed(16#31A9#, 16), to_signed(16#31A5#, 16), to_signed(16#31A1#, 16), 
      to_signed(16#319D#, 16), to_signed(16#3199#, 16), to_signed(16#3195#, 16), to_signed(16#3191#, 16), to_signed(16#318D#, 16), to_signed(16#3189#, 16), to_signed(16#3185#, 16), to_signed(16#3181#, 16), to_signed(16#317D#, 16), 
      to_signed(16#3179#, 16), to_signed(16#3175#, 16), to_signed(16#3171#, 16), to_signed(16#316D#, 16), to_signed(16#3169#, 16), to_signed(16#3165#, 16), to_signed(16#3161#, 16), to_signed(16#315D#, 16), to_signed(16#3159#, 16), 
      to_signed(16#3155#, 16), to_signed(16#3151#, 16), to_signed(16#314D#, 16), to_signed(16#3149#, 16), to_signed(16#3145#, 16), to_signed(16#3141#, 16), to_signed(16#313D#, 16), to_signed(16#3139#, 16), to_signed(16#3135#, 16), 
      to_signed(16#3131#, 16), to_signed(16#312D#, 16), to_signed(16#3129#, 16), to_signed(16#3125#, 16), to_signed(16#3121#, 16), to_signed(16#311D#, 16), to_signed(16#3119#, 16), to_signed(16#3115#, 16), to_signed(16#3111#, 16), 
      to_signed(16#310D#, 16), to_signed(16#3109#, 16), to_signed(16#3105#, 16), to_signed(16#3101#, 16), to_signed(16#30FD#, 16), to_signed(16#30F9#, 16), to_signed(16#30F4#, 16), to_signed(16#30F0#, 16), to_signed(16#30EC#, 16), 
      to_signed(16#30E8#, 16), to_signed(16#30E4#, 16), to_signed(16#30E0#, 16), to_signed(16#30DC#, 16), to_signed(16#30D8#, 16), to_signed(16#30D4#, 16), to_signed(16#30D0#, 16), to_signed(16#30CC#, 16), to_signed(16#30C8#, 16), 
      to_signed(16#30C4#, 16), to_signed(16#30C0#, 16), to_signed(16#30BC#, 16), to_signed(16#30B8#, 16), to_signed(16#30B3#, 16), to_signed(16#30AF#, 16), to_signed(16#30AB#, 16), to_signed(16#30A7#, 16), to_signed(16#30A3#, 16), 
      to_signed(16#309F#, 16), to_signed(16#309B#, 16), to_signed(16#3097#, 16), to_signed(16#3093#, 16), to_signed(16#308F#, 16), to_signed(16#308B#, 16), to_signed(16#3087#, 16), to_signed(16#3082#, 16), to_signed(16#307E#, 16), 
      to_signed(16#307A#, 16), to_signed(16#3076#, 16), to_signed(16#3072#, 16), to_signed(16#306E#, 16), to_signed(16#306A#, 16), to_signed(16#3066#, 16), to_signed(16#3062#, 16), to_signed(16#305D#, 16), to_signed(16#3059#, 16), 
      to_signed(16#3055#, 16), to_signed(16#3051#, 16), to_signed(16#304D#, 16), to_signed(16#3049#, 16), to_signed(16#3045#, 16), to_signed(16#3041#, 16), to_signed(16#303C#, 16), to_signed(16#3038#, 16), to_signed(16#3034#, 16), 
      to_signed(16#3030#, 16), to_signed(16#302C#, 16), to_signed(16#3028#, 16), to_signed(16#3024#, 16), to_signed(16#3020#, 16), to_signed(16#301B#, 16), to_signed(16#3017#, 16), to_signed(16#3013#, 16), to_signed(16#300F#, 16), 
      to_signed(16#300B#, 16), to_signed(16#3007#, 16), to_signed(16#3002#, 16), to_signed(16#2FFE#, 16), to_signed(16#2FFA#, 16), to_signed(16#2FF6#, 16), to_signed(16#2FF2#, 16), to_signed(16#2FEE#, 16), to_signed(16#2FEA#, 16), 
      to_signed(16#2FE5#, 16), to_signed(16#2FE1#, 16), to_signed(16#2FDD#, 16), to_signed(16#2FD9#, 16), to_signed(16#2FD5#, 16), to_signed(16#2FD0#, 16), to_signed(16#2FCC#, 16), to_signed(16#2FC8#, 16), to_signed(16#2FC4#, 16), 
      to_signed(16#2FC0#, 16), to_signed(16#2FBC#, 16), to_signed(16#2FB7#, 16), to_signed(16#2FB3#, 16), to_signed(16#2FAF#, 16), to_signed(16#2FAB#, 16), to_signed(16#2FA7#, 16), to_signed(16#2FA2#, 16), to_signed(16#2F9E#, 16), 
      to_signed(16#2F9A#, 16), to_signed(16#2F96#, 16), to_signed(16#2F92#, 16), to_signed(16#2F8D#, 16), to_signed(16#2F89#, 16), to_signed(16#2F85#, 16), to_signed(16#2F81#, 16), to_signed(16#2F7D#, 16), to_signed(16#2F78#, 16), 
      to_signed(16#2F74#, 16), to_signed(16#2F70#, 16), to_signed(16#2F6C#, 16), to_signed(16#2F68#, 16), to_signed(16#2F63#, 16), to_signed(16#2F5F#, 16), to_signed(16#2F5B#, 16), to_signed(16#2F57#, 16), to_signed(16#2F52#, 16), 
      to_signed(16#2F4E#, 16), to_signed(16#2F4A#, 16), to_signed(16#2F46#, 16), to_signed(16#2F41#, 16), to_signed(16#2F3D#, 16), to_signed(16#2F39#, 16), to_signed(16#2F35#, 16), to_signed(16#2F30#, 16), to_signed(16#2F2C#, 16), 
      to_signed(16#2F28#, 16), to_signed(16#2F24#, 16), to_signed(16#2F20#, 16), to_signed(16#2F1B#, 16), to_signed(16#2F17#, 16), to_signed(16#2F13#, 16), to_signed(16#2F0E#, 16), to_signed(16#2F0A#, 16), to_signed(16#2F06#, 16), 
      to_signed(16#2F02#, 16), to_signed(16#2EFD#, 16), to_signed(16#2EF9#, 16), to_signed(16#2EF5#, 16), to_signed(16#2EF1#, 16), to_signed(16#2EEC#, 16), to_signed(16#2EE8#, 16), to_signed(16#2EE4#, 16), to_signed(16#2EE0#, 16), 
      to_signed(16#2EDB#, 16), to_signed(16#2ED7#, 16), to_signed(16#2ED3#, 16), to_signed(16#2ECE#, 16), to_signed(16#2ECA#, 16), to_signed(16#2EC6#, 16), to_signed(16#2EC2#, 16), to_signed(16#2EBD#, 16), to_signed(16#2EB9#, 16), 
      to_signed(16#2EB5#, 16), to_signed(16#2EB0#, 16), to_signed(16#2EAC#, 16), to_signed(16#2EA8#, 16), to_signed(16#2EA3#, 16), to_signed(16#2E9F#, 16), to_signed(16#2E9B#, 16), to_signed(16#2E97#, 16), to_signed(16#2E92#, 16), 
      to_signed(16#2E8E#, 16), to_signed(16#2E8A#, 16), to_signed(16#2E85#, 16), to_signed(16#2E81#, 16), to_signed(16#2E7D#, 16), to_signed(16#2E78#, 16), to_signed(16#2E74#, 16), to_signed(16#2E70#, 16), to_signed(16#2E6B#, 16), 
      to_signed(16#2E67#, 16), to_signed(16#2E63#, 16), to_signed(16#2E5E#, 16), to_signed(16#2E5A#, 16), to_signed(16#2E56#, 16), to_signed(16#2E51#, 16), to_signed(16#2E4D#, 16), to_signed(16#2E49#, 16), to_signed(16#2E44#, 16), 
      to_signed(16#2E40#, 16), to_signed(16#2E3C#, 16), to_signed(16#2E37#, 16), to_signed(16#2E33#, 16), to_signed(16#2E2F#, 16), to_signed(16#2E2A#, 16), to_signed(16#2E26#, 16), to_signed(16#2E22#, 16), to_signed(16#2E1D#, 16), 
      to_signed(16#2E19#, 16), to_signed(16#2E15#, 16), to_signed(16#2E10#, 16), to_signed(16#2E0C#, 16), to_signed(16#2E07#, 16), to_signed(16#2E03#, 16), to_signed(16#2DFF#, 16), to_signed(16#2DFA#, 16), to_signed(16#2DF6#, 16), 
      to_signed(16#2DF2#, 16), to_signed(16#2DED#, 16), to_signed(16#2DE9#, 16), to_signed(16#2DE4#, 16), to_signed(16#2DE0#, 16), to_signed(16#2DDC#, 16), to_signed(16#2DD7#, 16), to_signed(16#2DD3#, 16), to_signed(16#2DCF#, 16), 
      to_signed(16#2DCA#, 16), to_signed(16#2DC6#, 16), to_signed(16#2DC1#, 16), to_signed(16#2DBD#, 16), to_signed(16#2DB9#, 16), to_signed(16#2DB4#, 16), to_signed(16#2DB0#, 16), to_signed(16#2DAB#, 16), to_signed(16#2DA7#, 16), 
      to_signed(16#2DA3#, 16), to_signed(16#2D9E#, 16), to_signed(16#2D9A#, 16), to_signed(16#2D95#, 16), to_signed(16#2D91#, 16), to_signed(16#2D8D#, 16), to_signed(16#2D88#, 16), to_signed(16#2D84#, 16), to_signed(16#2D7F#, 16), 
      to_signed(16#2D7B#, 16), to_signed(16#2D76#, 16), to_signed(16#2D72#, 16), to_signed(16#2D6E#, 16), to_signed(16#2D69#, 16), to_signed(16#2D65#, 16), to_signed(16#2D60#, 16), to_signed(16#2D5C#, 16), to_signed(16#2D57#, 16), 
      to_signed(16#2D53#, 16), to_signed(16#2D4F#, 16), to_signed(16#2D4A#, 16), to_signed(16#2D46#, 16)); -- sfix16 [2048]

  -- Signals
  SIGNAL lutaddr_unsigned                 : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL lutaddrInReg                     : unsigned(10 DOWNTO 0) := to_unsigned(16#000#, 11);  -- ufix11
  SIGNAL lutCosineout                     : signed(15 DOWNTO 0);  -- sfix16_En14
  SIGNAL lutCosineoutreg1                 : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En14
  SIGNAL lutCosine_tmp                    : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En14

BEGIN
  lutaddr_unsigned <= unsigned(lutaddr);

  -- Look up tale address input register
  LUTaddrRegister_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        lutaddrInReg <= lutaddr_unsigned;
      END IF;
    END IF;
  END PROCESS LUTaddrRegister_process;


  -- Octant Cosine wave table
  lutCosineout <= DirectLookupTable_data(to_integer(lutaddrInReg));

  -- Cos lookup table output register
  LUTCosineoutResetRegister_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        lutCosineoutreg1 <= lutCosineout;
      END IF;
    END IF;
  END PROCESS LUTCosineoutResetRegister_process;


  LUTCosineoutRegister_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        lutCosine_tmp <= lutCosineoutreg1;
      END IF;
    END IF;
  END PROCESS LUTCosineoutRegister_process;


  lutCosine <= std_logic_vector(lutCosine_tmp);

END rtl;

