-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_CIC_Filter IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(27 DOWNTO 0);  -- sfix28_En15
        dataOut_im                        :   OUT   std_logic_vector(27 DOWNTO 0);  -- sfix28_En15
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_CIC_Filter;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_CIC_Filter IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_Decimator_block
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(27 DOWNTO 0);  -- sfix28_En15
          dataIn_im                       :   IN    std_logic_vector(27 DOWNTO 0);  -- sfix28_En15
          validIn                         :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(27 DOWNTO 0);  -- sfix28_En15
          dataOut_im                      :   OUT   std_logic_vector(27 DOWNTO 0);  -- sfix28_En15
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_Decimator_block
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Decimator_block(rtl);

  -- Signals
  SIGNAL Delay10_out1                     : std_logic := '0';
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay9_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay9_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Data_Type_Conversion1_out1_re    : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Data_Type_Conversion1_out1_im    : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL z2_out1_re                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL z2_out1_im                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Add1_out1_re                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Add1_out1_im                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL z3_out1_re                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL z3_out1_im                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Add2_out1_re                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Add2_out1_im                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL z4_out1_re                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL z4_out1_im                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Add3_out1_re                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Add3_out1_im                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL z1_out1_re                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL z1_out1_im                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Add4_out1_re                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Add4_out1_im                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL dataOut_re_1                     : std_logic_vector(27 DOWNTO 0);  -- ufix28
  SIGNAL dataOut_im_1                     : std_logic_vector(27 DOWNTO 0);  -- ufix28
  SIGNAL validOut_1                       : std_logic;
  SIGNAL dataOut_re_signed                : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL dataOut_im_signed                : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL z5_out1_re                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL z5_out1_im                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Add5_out1_re                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Add5_out1_im                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Delay2_out1_re                   : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Delay2_out1_im                   : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Delay1_out1                      : std_logic := '0';
  SIGNAL z6_out1_re                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL z6_out1_im                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Add6_out1_re                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Add6_out1_im                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Delay3_out1_re                   : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Delay3_out1_im                   : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Delay4_out1                      : std_logic := '0';
  SIGNAL z7_out1_re                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL z7_out1_im                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Add7_out1_re                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Add7_out1_im                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Delay5_out1_re                   : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Delay5_out1_im                   : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Delay6_out1                      : std_logic := '0';
  SIGNAL z8_out1_re                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL z8_out1_im                       : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Add8_out1_re                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Add8_out1_im                     : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Delay7_out1_re                   : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Delay7_out1_im                   : signed(27 DOWNTO 0) := to_signed(16#0000000#, 28);  -- sfix28_En15
  SIGNAL Delay8_out1                      : std_logic := '0';

BEGIN
  -- Note that this subsystem has some warnings suppressed programmatically in it's InitFcn callback.
  -- The CIC filter relies on overflow to function correctly.

  UDecimator_1 : ltehdlDownlinkSyncDemod_Decimator_block
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              dataIn_re => std_logic_vector(z1_out1_re),  -- sfix28_En15
              dataIn_im => std_logic_vector(z1_out1_im),  -- sfix28_En15
              validIn => Delay10_out1,
              dataOut_re => dataOut_re_1,  -- sfix28_En15
              dataOut_im => dataOut_im_1,  -- sfix28_En15
              validOut => validOut_1
              );

  Delay10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay10_out1 <= validIn;
      END IF;
    END IF;
  END PROCESS Delay10_process;


  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Delay9_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay9_out1_re <= dataIn_re_signed;
        Delay9_out1_im <= dataIn_im_signed;
      END IF;
    END IF;
  END PROCESS Delay9_process;


  Data_Type_Conversion1_out1_re <= resize(Delay9_out1_re, 28);
  Data_Type_Conversion1_out1_im <= resize(Delay9_out1_im, 28);

  Add1_out1_re <= Data_Type_Conversion1_out1_re + z2_out1_re;
  Add1_out1_im <= Data_Type_Conversion1_out1_im + z2_out1_im;

  z2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay10_out1 = '1' THEN
        z2_out1_re <= Add1_out1_re;
        z2_out1_im <= Add1_out1_im;
      END IF;
    END IF;
  END PROCESS z2_process;


  Add2_out1_re <= z2_out1_re + z3_out1_re;
  Add2_out1_im <= z2_out1_im + z3_out1_im;

  z3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay10_out1 = '1' THEN
        z3_out1_re <= Add2_out1_re;
        z3_out1_im <= Add2_out1_im;
      END IF;
    END IF;
  END PROCESS z3_process;


  Add3_out1_re <= z3_out1_re + z4_out1_re;
  Add3_out1_im <= z3_out1_im + z4_out1_im;

  z4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay10_out1 = '1' THEN
        z4_out1_re <= Add3_out1_re;
        z4_out1_im <= Add3_out1_im;
      END IF;
    END IF;
  END PROCESS z4_process;


  Add4_out1_re <= z4_out1_re + z1_out1_re;
  Add4_out1_im <= z4_out1_im + z1_out1_im;

  z1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay10_out1 = '1' THEN
        z1_out1_re <= Add4_out1_re;
        z1_out1_im <= Add4_out1_im;
      END IF;
    END IF;
  END PROCESS z1_process;


  dataOut_re_signed <= signed(dataOut_re_1);

  dataOut_im_signed <= signed(dataOut_im_1);

  z5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND validOut_1 = '1' THEN
        z5_out1_re <= dataOut_re_signed;
        z5_out1_im <= dataOut_im_signed;
      END IF;
    END IF;
  END PROCESS z5_process;


  Add5_out1_re <= dataOut_re_signed - z5_out1_re;
  Add5_out1_im <= dataOut_im_signed - z5_out1_im;

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_out1_re <= Add5_out1_re;
        Delay2_out1_im <= Add5_out1_im;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1 <= validOut_1;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  z6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay1_out1 = '1' THEN
        z6_out1_re <= Delay2_out1_re;
        z6_out1_im <= Delay2_out1_im;
      END IF;
    END IF;
  END PROCESS z6_process;


  Add6_out1_re <= Delay2_out1_re - z6_out1_re;
  Add6_out1_im <= Delay2_out1_im - z6_out1_im;

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1_re <= Add6_out1_re;
        Delay3_out1_im <= Add6_out1_im;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay4_out1 <= Delay1_out1;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  z7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay4_out1 = '1' THEN
        z7_out1_re <= Delay3_out1_re;
        z7_out1_im <= Delay3_out1_im;
      END IF;
    END IF;
  END PROCESS z7_process;


  Add7_out1_re <= Delay3_out1_re - z7_out1_re;
  Add7_out1_im <= Delay3_out1_im - z7_out1_im;

  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay5_out1_re <= Add7_out1_re;
        Delay5_out1_im <= Add7_out1_im;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay6_out1 <= Delay4_out1;
      END IF;
    END IF;
  END PROCESS Delay6_process;


  z8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay6_out1 = '1' THEN
        z8_out1_re <= Delay5_out1_re;
        z8_out1_im <= Delay5_out1_im;
      END IF;
    END IF;
  END PROCESS z8_process;


  Add8_out1_re <= Delay5_out1_re - z8_out1_re;
  Add8_out1_im <= Delay5_out1_im - z8_out1_im;

  Delay7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay7_out1_re <= Add8_out1_re;
        Delay7_out1_im <= Add8_out1_im;
      END IF;
    END IF;
  END PROCESS Delay7_process;


  dataOut_re <= std_logic_vector(Delay7_out1_re);

  dataOut_im <= std_logic_vector(Delay7_out1_im);

  Delay8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay8_out1 <= Delay6_out1;
      END IF;
    END IF;
  END PROCESS Delay8_process;


  validOut <= Delay8_out1;

END rtl;

