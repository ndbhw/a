-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_FirRdyLogic_block1 IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dinSwitch                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        dinVldSwitch                      :   IN    std_logic;
        coeff                             :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        haltProcess                       :   IN    std_logic;
        dinSM                             :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
        dinVldSM                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_FirRdyLogic_block1;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_FirRdyLogic_block1 IS

  -- Signals
  SIGNAL dinSwitch_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL coeff_signed                     : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL syncReset                        : std_logic;
  SIGNAL firRdy_xdin                      : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16
  SIGNAL firRdy_xdinVld                   : std_logic := '0';
  SIGNAL firRdy_state                     : unsigned(2 DOWNTO 0) := to_unsigned(16#0#, 3);  -- ufix3
  SIGNAL firRdy_readyReg                  : std_logic := '1';
  SIGNAL firRdy_count                     : unsigned(4 DOWNTO 0) := to_unsigned(16#00#, 5);  -- ufix5
  SIGNAL firRdy_xcoeffin                  : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16
  SIGNAL firRdy_xdin_next                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL firRdy_xdinVld_next              : std_logic;
  SIGNAL firRdy_state_next                : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL firRdy_readyReg_next             : std_logic;
  SIGNAL firRdy_count_next                : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL firRdy_xcoeffin_next             : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL readySM                          : std_logic;
  SIGNAL dinSM_tmp                        : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL coeffS                           : signed(15 DOWNTO 0);  -- sfix16_En15

BEGIN
  dinSwitch_signed <= signed(dinSwitch);

  coeff_signed <= signed(coeff);

  syncReset <= '0';

  -- rdyLogic
  firRdy_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        firRdy_xdin <= firRdy_xdin_next;
        firRdy_xdinVld <= firRdy_xdinVld_next;
        firRdy_state <= firRdy_state_next;
        firRdy_readyReg <= firRdy_readyReg_next;
        firRdy_count <= firRdy_count_next;
        firRdy_xcoeffin <= firRdy_xcoeffin_next;
      END IF;
    END IF;
  END PROCESS firRdy_process;

  firRdy_output : PROCESS (coeff_signed, dinSwitch_signed, dinVldSwitch, firRdy_count, firRdy_readyReg,
       firRdy_state, firRdy_xcoeffin, firRdy_xdin, firRdy_xdinVld, haltProcess,
       syncReset)
    VARIABLE out2 : std_logic;
  BEGIN
    firRdy_xdin_next <= firRdy_xdin;
    firRdy_xdinVld_next <= firRdy_xdinVld;
    firRdy_state_next <= firRdy_state;
    firRdy_readyReg_next <= firRdy_readyReg;
    firRdy_count_next <= firRdy_count;
    firRdy_xcoeffin_next <= firRdy_xcoeffin;
    IF (( NOT haltProcess) AND ( NOT syncReset)) = '1' THEN 
      CASE firRdy_state IS
        WHEN "000" =>
          dinSM_tmp <= dinSwitch_signed;
          out2 := dinVldSwitch;
          coeffS <= coeff_signed;
          firRdy_state_next <= to_unsigned(16#0#, 3);
          firRdy_readyReg_next <= '1';
          firRdy_xdin_next <= to_signed(16#0000#, 16);
          firRdy_xdinVld_next <= '0';
          firRdy_xcoeffin_next <= to_signed(16#0000#, 16);
          IF dinVldSwitch = '1' THEN 
            firRdy_state_next <= to_unsigned(16#1#, 3);
            firRdy_readyReg_next <= '0';
          END IF;
        WHEN "001" =>
          dinSM_tmp <= to_signed(16#0000#, 16);
          out2 := '0';
          coeffS <= to_signed(16#0000#, 16);
          firRdy_state_next <= to_unsigned(16#3#, 3);
          IF dinVldSwitch = '1' THEN 
            firRdy_state_next <= to_unsigned(16#2#, 3);
            firRdy_xdin_next <= dinSwitch_signed;
            firRdy_xdinVld_next <= '1';
            firRdy_xcoeffin_next <= coeff_signed;
          END IF;
        WHEN "010" =>
          dinSM_tmp <= to_signed(16#0000#, 16);
          out2 := '0';
          coeffS <= to_signed(16#0000#, 16);
          firRdy_state_next <= to_unsigned(16#2#, 3);
          IF firRdy_count = to_unsigned(16#1F#, 5) THEN 
            firRdy_state_next <= to_unsigned(16#4#, 3);
          END IF;
          firRdy_readyReg_next <= '0';
        WHEN "011" =>
          IF firRdy_count = to_unsigned(16#1F#, 5) THEN 
            firRdy_readyReg_next <= '1';
            firRdy_state_next <= to_unsigned(16#0#, 3);
          END IF;
          dinSM_tmp <= to_signed(16#0000#, 16);
          coeffS <= to_signed(16#0000#, 16);
          out2 := '0';
        WHEN "100" =>
          firRdy_state_next <= to_unsigned(16#3#, 3);
          dinSM_tmp <= firRdy_xdin;
          out2 := firRdy_xdinVld;
          coeffS <= firRdy_xcoeffin;
          firRdy_xdin_next <= dinSwitch_signed;
          firRdy_xdinVld_next <= dinVldSwitch;
          firRdy_xcoeffin_next <= coeff_signed;
        WHEN OTHERS => 
          dinSM_tmp <= to_signed(16#0000#, 16);
          out2 := '0';
          coeffS <= to_signed(16#0000#, 16);
          firRdy_state_next <= to_unsigned(16#0#, 3);
          firRdy_xdin_next <= to_signed(16#0000#, 16);
          firRdy_xdinVld_next <= '0';
          firRdy_xcoeffin_next <= to_signed(16#0000#, 16);
          firRdy_readyReg_next <= '1';
      END CASE;
    ELSE 
      firRdy_state_next <= to_unsigned(16#0#, 3);
      firRdy_xdin_next <= to_signed(16#0000#, 16);
      firRdy_xcoeffin_next <= to_signed(16#0000#, 16);
      firRdy_xdinVld_next <= '0';
      firRdy_readyReg_next <= '0';
      dinSM_tmp <= to_signed(16#0000#, 16);
      out2 := '0';
      coeffS <= to_signed(16#0000#, 16);
    END IF;
    IF (dinVldSwitch = '1' OR (firRdy_count > to_unsigned(16#00#, 5))) OR out2 = '1' THEN 
      IF ((firRdy_count = to_unsigned(16#1F#, 5)) OR haltProcess = '1') OR syncReset = '1' THEN 
        firRdy_count_next <= to_unsigned(16#00#, 5);
      ELSE 
        firRdy_count_next <= firRdy_count + to_unsigned(16#01#, 5);
      END IF;
    END IF;
    readySM <= firRdy_readyReg;
    dinVldSM <= out2;
  END PROCESS firRdy_output;


  dinSM <= std_logic_vector(dinSM_tmp);

END rtl;

