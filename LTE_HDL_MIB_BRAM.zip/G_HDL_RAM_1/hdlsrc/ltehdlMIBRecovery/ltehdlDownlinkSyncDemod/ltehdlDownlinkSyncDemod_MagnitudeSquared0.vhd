-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_MagnitudeSquared0 IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En12
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En12
        dataOut                           :   OUT   std_logic_vector(29 DOWNTO 0)  -- ufix30_En24
        );
END ltehdlDownlinkSyncDemod_MagnitudeSquared0;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_MagnitudeSquared0 IS

  -- Signals
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En12
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En12
  SIGNAL Delay3_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En12
  SIGNAL Delay3_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En12
  SIGNAL Product4_out1                    : signed(31 DOWNTO 0);  -- sfix32_En24
  SIGNAL Product5_out1                    : signed(31 DOWNTO 0);  -- sfix32_En24
  SIGNAL Delay1_out1                      : signed(31 DOWNTO 0) := to_signed(0, 32);  -- sfix32_En24
  SIGNAL Data_Type_Conversion_out1        : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL Delay2_out1                      : signed(31 DOWNTO 0) := to_signed(0, 32);  -- sfix32_En24
  SIGNAL Data_Type_Conversion1_out1       : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL Add_out1                         : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL Delay4_out1                      : unsigned(29 DOWNTO 0) := to_unsigned(16#00000000#, 30);  -- ufix30_En24

BEGIN
  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1_re <= dataIn_re_signed;
        Delay3_out1_im <= dataIn_im_signed;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  Product4_out1 <= Delay3_out1_re * Delay3_out1_re;

  Product5_out1 <= Delay3_out1_im * Delay3_out1_im;

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1 <= Product4_out1;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  Data_Type_Conversion_out1 <= unsigned(Delay1_out1(29 DOWNTO 0));

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_out1 <= Product5_out1;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  Data_Type_Conversion1_out1 <= unsigned(Delay2_out1(29 DOWNTO 0));

  Add_out1 <= Data_Type_Conversion_out1 + Data_Type_Conversion1_out1;

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay4_out1 <= Add_out1;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  dataOut <= std_logic_vector(Delay4_out1);

END rtl;

