-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_Detection_Status IS
  PORT( PSSDone                           :   IN    std_logic;
        PSSSuccess                        :   IN    std_logic;
        SSSDone                           :   IN    std_logic;
        SSSSuccess                        :   IN    std_logic;
        cellDetectedStb                   :   OUT   std_logic;
        cellSearchDoneStb                 :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Detection_Status;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Detection_Status IS

BEGIN
  cellDetectedStb <= SSSDone AND SSSSuccess;
  cellSearchDoneStb <= (PSSDone AND ( NOT PSSSuccess)) OR SSSDone;

END rtl;

