-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_OFDM_Demodulation IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        reset                             :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataOut_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_OFDM_Demodulation;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_OFDM_Demodulation IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_OFDM_Demod_Mask_Generator
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          validIn                         :   IN    std_logic;
          reset                           :   IN    std_logic;
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_FFT_Shift
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          reset                           :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_FFT_HDL_Optimized
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          validIn                         :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
          dataOut_im                      :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_OFDM_Demod_Mask_Generator
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_OFDM_Demod_Mask_Generator(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_FFT_Shift
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_FFT_Shift(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_FFT_HDL_Optimized
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_FFT_HDL_Optimized(rtl);

  -- Signals
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay1_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay1_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL validOut_1                       : std_logic;
  SIGNAL FFT_Shift_dataOut_re             : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL FFT_Shift_dataOut_im             : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL FFT_Shift_validOut               : std_logic;
  SIGNAL FFT_HDL_Optimized_out1_re        : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL FFT_HDL_Optimized_out1_im        : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL FFT_HDL_Optimized_out2           : std_logic;
  SIGNAL FFT_HDL_Optimized_out1_re_signed : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL FFT_HDL_Optimized_out1_im_signed : signed(26 DOWNTO 0);  -- sfix27_En15
  SIGNAL Data_Type_Conversion4_out1_re    : signed(15 DOWNTO 0);  -- sfix16_En8
  SIGNAL Data_Type_Conversion4_out1_im    : signed(15 DOWNTO 0);  -- sfix16_En8
  SIGNAL Data_Type_Conversion3_out1_re    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Data_Type_Conversion3_out1_im    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Unit_Delay_Resettable_Synchronous_out1_re : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Unit_Delay_Resettable_Synchronous_out1_im : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Unit_Delay_Resettable_Synchronous1_out1 : std_logic := '0';

BEGIN
  -- Reinterpret the result as fixdt(1,16,15),
  -- thereby scaling the signal by 2^-7.
  -- Cast to 16 bits, making the 5th MSB the new MSB.
  -- Use rounding and saturation.

  UOFDM_Demod_Mask_Generator : ltehdlDownlinkSyncDemod_OFDM_Demod_Mask_Generator
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb_1_2_0 => enb_1_2_0,
              validIn => validIn,
              reset => reset,
              validOut => validOut_1
              );

  UFFT_Shift : ltehdlDownlinkSyncDemod_FFT_Shift
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dataIn_re => std_logic_vector(Delay1_out1_re),  -- sfix16_En15
              dataIn_im => std_logic_vector(Delay1_out1_im),  -- sfix16_En15
              validIn => validOut_1,
              reset => reset,
              dataOut_re => FFT_Shift_dataOut_re,  -- sfix16_En15
              dataOut_im => FFT_Shift_dataOut_im,  -- sfix16_En15
              validOut => FFT_Shift_validOut
              );

  UFFT_HDL_Optimized : ltehdlDownlinkSyncDemod_FFT_HDL_Optimized
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dataIn_re => FFT_Shift_dataOut_re,  -- ufix16
              dataIn_im => FFT_Shift_dataOut_im,  -- ufix16
              validIn => FFT_Shift_validOut,
              syncReset => reset,
              dataOut_re => FFT_HDL_Optimized_out1_re,  -- ufix27
              dataOut_im => FFT_HDL_Optimized_out1_im,  -- ufix27
              validOut => FFT_HDL_Optimized_out2
              );

  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_out1_re <= dataIn_re_signed;
        Delay1_out1_im <= dataIn_im_signed;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  FFT_HDL_Optimized_out1_re_signed <= signed(FFT_HDL_Optimized_out1_re);

  FFT_HDL_Optimized_out1_im_signed <= signed(FFT_HDL_Optimized_out1_im);

  
  Data_Type_Conversion4_out1_re <= X"7FFF" WHEN ((FFT_HDL_Optimized_out1_re_signed(26) = '0') AND (FFT_HDL_Optimized_out1_re_signed(25 DOWNTO 22) /= "0000")) OR ((FFT_HDL_Optimized_out1_re_signed(26) = '0') AND (FFT_HDL_Optimized_out1_re_signed(22 
    DOWNTO 7) = X"7FFF")) ELSE
      X"8000" WHEN (FFT_HDL_Optimized_out1_re_signed(26) = '1') AND (FFT_HDL_Optimized_out1_re_signed(25 DOWNTO 22) /= "1111") ELSE
      FFT_HDL_Optimized_out1_re_signed(22 DOWNTO 7) + ('0' & (FFT_HDL_Optimized_out1_re_signed(6) AND (( NOT FFT_HDL_Optimized_out1_re_signed(26)) OR (FFT_HDL_Optimized_out1_re_signed(5) OR FFT_HDL_Optimized_out1_re_signed(4) OR 
        FFT_HDL_Optimized_out1_re_signed(3) OR FFT_HDL_Optimized_out1_re_signed(2) OR FFT_HDL_Optimized_out1_re_signed(1) OR FFT_HDL_Optimized_out1_re_signed(0)))));
  
  Data_Type_Conversion4_out1_im <= X"7FFF" WHEN ((FFT_HDL_Optimized_out1_im_signed(26) = '0') AND (FFT_HDL_Optimized_out1_im_signed(25 DOWNTO 22) /= "0000")) OR ((FFT_HDL_Optimized_out1_im_signed(26) = '0') AND (FFT_HDL_Optimized_out1_im_signed(22 
    DOWNTO 7) = X"7FFF")) ELSE
      X"8000" WHEN (FFT_HDL_Optimized_out1_im_signed(26) = '1') AND (FFT_HDL_Optimized_out1_im_signed(25 DOWNTO 22) /= "1111") ELSE
      FFT_HDL_Optimized_out1_im_signed(22 DOWNTO 7) + ('0' & (FFT_HDL_Optimized_out1_im_signed(6) AND (( NOT FFT_HDL_Optimized_out1_im_signed(26)) OR (FFT_HDL_Optimized_out1_im_signed(5) OR FFT_HDL_Optimized_out1_im_signed(4) OR 
        FFT_HDL_Optimized_out1_im_signed(3) OR FFT_HDL_Optimized_out1_im_signed(2) OR FFT_HDL_Optimized_out1_im_signed(1) OR FFT_HDL_Optimized_out1_im_signed(0)))));

  Data_Type_Conversion3_out1_re <= Data_Type_Conversion4_out1_re;
  Data_Type_Conversion3_out1_im <= Data_Type_Conversion4_out1_im;

  Unit_Delay_Resettable_Synchronous_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF reset = '1' THEN
          Unit_Delay_Resettable_Synchronous_out1_re <= to_signed(16#0000#, 16);
          Unit_Delay_Resettable_Synchronous_out1_im <= to_signed(16#0000#, 16);
        ELSE 
          Unit_Delay_Resettable_Synchronous_out1_re <= Data_Type_Conversion3_out1_re;
          Unit_Delay_Resettable_Synchronous_out1_im <= Data_Type_Conversion3_out1_im;
        END IF;
      END IF;
    END IF;
  END PROCESS Unit_Delay_Resettable_Synchronous_process;


  dataOut_re <= std_logic_vector(Unit_Delay_Resettable_Synchronous_out1_re);

  dataOut_im <= std_logic_vector(Unit_Delay_Resettable_Synchronous_out1_im);

  Unit_Delay_Resettable_Synchronous1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF reset = '1' THEN
          Unit_Delay_Resettable_Synchronous1_out1 <= '0';
        ELSE 
          Unit_Delay_Resettable_Synchronous1_out1 <= FFT_HDL_Optimized_out2;
        END IF;
      END IF;
    END IF;
  END PROCESS Unit_Delay_Resettable_Synchronous1_process;


  validOut <= Unit_Delay_Resettable_Synchronous1_out1;

END rtl;

