-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_FilterTapSystolic_block3 IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        din_re                            :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        coeff                             :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
        sumIn                             :   IN    std_logic_vector(28 DOWNTO 0);  -- ufix29
        sumOut                            :   OUT   std_logic_vector(28 DOWNTO 0)  -- ufix29
        );
END ltehdlDownlinkSyncDemod_FilterTapSystolic_block3;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_FilterTapSystolic_block3 IS

  -- Signals
  SIGNAL din_re_signed                    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL coeff_signed                     : signed(8 DOWNTO 0);  -- sfix9_En9
  SIGNAL sumIn_signed                     : signed(28 DOWNTO 0);  -- sfix29_En24
  SIGNAL fTap_din_reg1                    : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16
  SIGNAL fTap_coef_reg1                   : signed(8 DOWNTO 0) := to_signed(16#000#, 9);  -- sfix9
  SIGNAL fTap_din_reg2                    : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16
  SIGNAL fTap_coef_reg2                   : signed(8 DOWNTO 0) := to_signed(16#000#, 9);  -- sfix9
  SIGNAL fTap_mult_reg                    : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25
  SIGNAL fTap_addout_reg                  : signed(28 DOWNTO 0) := to_signed(16#00000000#, 29);  -- sfix29
  SIGNAL fTap_addout_reg_next             : signed(28 DOWNTO 0);  -- sfix29_En24
  SIGNAL sumOut_tmp                       : signed(28 DOWNTO 0);  -- sfix29_En24

BEGIN
  din_re_signed <= signed(din_re);

  coeff_signed <= signed(coeff);

  sumIn_signed <= signed(sumIn);

  -- FilterTapSystolicS
  fTap_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        fTap_addout_reg <= fTap_addout_reg_next;
        fTap_mult_reg <= fTap_din_reg2 * fTap_coef_reg2;
        fTap_din_reg2 <= fTap_din_reg1;
        fTap_coef_reg2 <= fTap_coef_reg1;
        fTap_din_reg1 <= din_re_signed;
        fTap_coef_reg1 <= coeff_signed;
      END IF;
    END IF;
  END PROCESS fTap_process;

  sumOut_tmp <= fTap_addout_reg;
  fTap_addout_reg_next <= (resize(fTap_mult_reg, 29)) + sumIn_signed;

  sumOut <= std_logic_vector(sumOut_tmp);

END rtl;

