-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_HDL_CMA_core IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        In_re                             :   IN    std_logic_vector(23 DOWNTO 0);  -- ufix24
        In_im                             :   IN    std_logic_vector(23 DOWNTO 0);  -- ufix24
        validIn                           :   IN    std_logic;
        magnitude                         :   OUT   std_logic_vector(24 DOWNTO 0);  -- ufix25
        angle_rsvd                        :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_HDL_CMA_core;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_HDL_CMA_core IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_Quadrant_Mapper
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          xin                             :   IN    std_logic_vector(24 DOWNTO 0);  -- ufix25
          yin                             :   IN    std_logic_vector(24 DOWNTO 0);  -- ufix25
          xout                            :   OUT   std_logic_vector(24 DOWNTO 0);  -- ufix25
          yout                            :   OUT   std_logic_vector(24 DOWNTO 0);  -- ufix25
          QA_Control                      :   OUT   std_logic_vector(4 DOWNTO 0)  -- ufix5
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT( xin                             :   IN    std_logic_vector(24 DOWNTO 0);  -- ufix25
          yin                             :   IN    std_logic_vector(24 DOWNTO 0);  -- ufix25
          zin                             :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
          lut_value                       :   IN    std_logic_vector(23 DOWNTO 0);  -- ufix24
          idx                             :   IN    std_logic_vector(5 DOWNTO 0);  -- ufix6
          xout                            :   OUT   std_logic_vector(24 DOWNTO 0);  -- ufix25
          yout                            :   OUT   std_logic_vector(24 DOWNTO 0);  -- ufix25
          zout                            :   OUT   std_logic_vector(26 DOWNTO 0)  -- ufix27
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Quadrant_Correction
    PORT( zin                             :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
          QA_Control                      :   IN    std_logic_vector(4 DOWNTO 0);  -- ufix5
          zout                            :   OUT   std_logic_vector(26 DOWNTO 0)  -- ufix27
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_Quadrant_Mapper
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Quadrant_Mapper(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_CordicKernelMag
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_CordicKernelMag(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Quadrant_Correction
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Quadrant_Correction(rtl);

  -- Signals
  SIGNAL Delay_ValidIn_reg_rsvd           : std_logic_vector(25 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [26]
  SIGNAL ValidOutDelayed                  : std_logic;
  SIGNAL reset_outval                     : std_logic;
  SIGNAL In_re_signed                     : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL In_im_signed                     : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL qMapReal                         : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL qMapImag                         : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL In1Register                      : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL In2Register                      : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL XQMapped                         : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yQMapped                         : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL ControlQC                        : std_logic_vector(4 DOWNTO 0);  -- ufix5
  SIGNAL XQMapped_signed                  : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yQMapped_signed                  : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL xin1                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin1                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin1                             : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL lut_value1                       : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift1                           : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout1                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout1                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout1                            : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout1_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout1_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout1_signed                     : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin2                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin2                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin2                             : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value2                       : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift2                           : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout2                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout2                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout2                            : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout2_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout2_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout2_signed                     : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin3                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin3                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin3                             : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value3                       : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift3                           : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout3                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout3                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout3                            : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout3_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout3_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout3_signed                     : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin4                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin4                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin4                             : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value4                       : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift4                           : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout4                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout4                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout4                            : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout4_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout4_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout4_signed                     : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin5                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin5                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin5                             : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value5                       : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift5                           : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout5                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout5                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout5                            : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout5_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout5_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout5_signed                     : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin6                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin6                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin6                             : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value6                       : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift6                           : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout6                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout6                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout6                            : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout6_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout6_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout6_signed                     : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin7                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin7                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin7                             : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value7                       : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift7                           : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout7                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout7                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout7                            : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout7_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout7_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout7_signed                     : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin8                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin8                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin8                             : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value8                       : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift8                           : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout8                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout8                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout8                            : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout8_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout8_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout8_signed                     : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin9                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin9                             : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin9                             : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value9                       : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift9                           : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout9                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout9                            : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout9                            : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout9_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout9_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout9_signed                     : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin10                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin10                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin10                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value10                      : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift10                          : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout10                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout10                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout10                           : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout10_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout10_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout10_signed                    : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin11                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin11                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin11                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value11                      : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift11                          : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout11                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout11                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout11                           : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout11_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout11_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout11_signed                    : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin12                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin12                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin12                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value12                      : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift12                          : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout12                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout12                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout12                           : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout12_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout12_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout12_signed                    : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin13                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin13                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin13                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value13                      : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift13                          : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout13                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout13                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout13                           : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout13_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout13_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout13_signed                    : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin14                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin14                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin14                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value14                      : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift14                          : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout14                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout14                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout14                           : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout14_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout14_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout14_signed                    : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin15                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin15                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin15                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value15                      : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift15                          : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout15                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout15                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout15                           : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout15_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout15_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout15_signed                    : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin16                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin16                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin16                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value16                      : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift16                          : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout16                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout16                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout16                           : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout16_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout16_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout16_signed                    : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin17                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin17                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin17                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value17                      : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift17                          : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout17                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout17                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout17                           : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout17_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout17_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout17_signed                    : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin18                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin18                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin18                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value18                      : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift18                          : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout18                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout18                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout18                           : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout18_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout18_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout18_signed                    : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin19                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin19                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin19                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value19                      : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift19                          : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout19                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout19                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout19                           : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout19_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout19_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout19_signed                    : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin20                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin20                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin20                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value20                      : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift20                          : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout20                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout20                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout20                           : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout20_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout20_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout20_signed                    : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin21                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin21                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin21                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value21                      : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift21                          : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout21                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout21                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout21                           : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout21_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout21_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout21_signed                    : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin22                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin22                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin22                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value22                      : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift22                          : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout22                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout22                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout22                           : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout22_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout22_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zout22_signed                    : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL xin23                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL yin23                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zin23                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL lut_value23                      : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL shift23                          : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL xout23                           : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL yout23deadOutdeadOut             : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL zout23                           : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL xout23_signed                    : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL xin24                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL CSD_Gain_Factor_mul_temp         : signed(40 DOWNTO 0);  -- sfix41_En38
  SIGNAL CSD_Gain_Factor_cast             : signed(39 DOWNTO 0);  -- sfix40_En38
  SIGNAL xoutscaled                       : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL outSwitchMag                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL xin25                            : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL zout23_signed                    : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL ControlQC_unsigned               : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL zin24                            : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26
  SIGNAL DelayQC_Control_reg_rsvd         : vector_of_unsigned5(0 TO 23) := (OTHERS => to_unsigned(16#00#, 5));  -- ufix5 [24]
  SIGNAL ControlQCDelay                   : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL zout_corrected                   : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL zout_corrected_signed            : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL outSwitchAng                     : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL zout_corrected_1                 : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En26

BEGIN
  UQuadrantMapper : ltehdlDownlinkSyncDemod_Quadrant_Mapper
    PORT MAP( clk => clk,
              enb => enb,
              xin => std_logic_vector(In1Register),  -- ufix25
              yin => std_logic_vector(In2Register),  -- ufix25
              xout => XQMapped,  -- ufix25
              yout => yQMapped,  -- ufix25
              QA_Control => ControlQC  -- ufix5
              );

  UIteration : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin1),  -- ufix25
              yin => std_logic_vector(yin1),  -- ufix25
              zin => std_logic_vector(zin1),  -- ufix27
              lut_value => std_logic_vector(lut_value1),  -- ufix24
              idx => std_logic_vector(shift1),  -- ufix6
              xout => xout1,  -- ufix25
              yout => yout1,  -- ufix25
              zout => zout1  -- ufix27
              );

  UIteration_1 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin2),  -- ufix25
              yin => std_logic_vector(yin2),  -- ufix25
              zin => std_logic_vector(zin2),  -- ufix27
              lut_value => std_logic_vector(lut_value2),  -- ufix24
              idx => std_logic_vector(shift2),  -- ufix6
              xout => xout2,  -- ufix25
              yout => yout2,  -- ufix25
              zout => zout2  -- ufix27
              );

  UIteration_2 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin3),  -- ufix25
              yin => std_logic_vector(yin3),  -- ufix25
              zin => std_logic_vector(zin3),  -- ufix27
              lut_value => std_logic_vector(lut_value3),  -- ufix24
              idx => std_logic_vector(shift3),  -- ufix6
              xout => xout3,  -- ufix25
              yout => yout3,  -- ufix25
              zout => zout3  -- ufix27
              );

  UIteration_3 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin4),  -- ufix25
              yin => std_logic_vector(yin4),  -- ufix25
              zin => std_logic_vector(zin4),  -- ufix27
              lut_value => std_logic_vector(lut_value4),  -- ufix24
              idx => std_logic_vector(shift4),  -- ufix6
              xout => xout4,  -- ufix25
              yout => yout4,  -- ufix25
              zout => zout4  -- ufix27
              );

  UIteration_4 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin5),  -- ufix25
              yin => std_logic_vector(yin5),  -- ufix25
              zin => std_logic_vector(zin5),  -- ufix27
              lut_value => std_logic_vector(lut_value5),  -- ufix24
              idx => std_logic_vector(shift5),  -- ufix6
              xout => xout5,  -- ufix25
              yout => yout5,  -- ufix25
              zout => zout5  -- ufix27
              );

  UIteration_5 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin6),  -- ufix25
              yin => std_logic_vector(yin6),  -- ufix25
              zin => std_logic_vector(zin6),  -- ufix27
              lut_value => std_logic_vector(lut_value6),  -- ufix24
              idx => std_logic_vector(shift6),  -- ufix6
              xout => xout6,  -- ufix25
              yout => yout6,  -- ufix25
              zout => zout6  -- ufix27
              );

  UIteration_6 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin7),  -- ufix25
              yin => std_logic_vector(yin7),  -- ufix25
              zin => std_logic_vector(zin7),  -- ufix27
              lut_value => std_logic_vector(lut_value7),  -- ufix24
              idx => std_logic_vector(shift7),  -- ufix6
              xout => xout7,  -- ufix25
              yout => yout7,  -- ufix25
              zout => zout7  -- ufix27
              );

  UIteration_7 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin8),  -- ufix25
              yin => std_logic_vector(yin8),  -- ufix25
              zin => std_logic_vector(zin8),  -- ufix27
              lut_value => std_logic_vector(lut_value8),  -- ufix24
              idx => std_logic_vector(shift8),  -- ufix6
              xout => xout8,  -- ufix25
              yout => yout8,  -- ufix25
              zout => zout8  -- ufix27
              );

  UIteration_8 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin9),  -- ufix25
              yin => std_logic_vector(yin9),  -- ufix25
              zin => std_logic_vector(zin9),  -- ufix27
              lut_value => std_logic_vector(lut_value9),  -- ufix24
              idx => std_logic_vector(shift9),  -- ufix6
              xout => xout9,  -- ufix25
              yout => yout9,  -- ufix25
              zout => zout9  -- ufix27
              );

  UIteration_9 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin10),  -- ufix25
              yin => std_logic_vector(yin10),  -- ufix25
              zin => std_logic_vector(zin10),  -- ufix27
              lut_value => std_logic_vector(lut_value10),  -- ufix24
              idx => std_logic_vector(shift10),  -- ufix6
              xout => xout10,  -- ufix25
              yout => yout10,  -- ufix25
              zout => zout10  -- ufix27
              );

  UIteration_10 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin11),  -- ufix25
              yin => std_logic_vector(yin11),  -- ufix25
              zin => std_logic_vector(zin11),  -- ufix27
              lut_value => std_logic_vector(lut_value11),  -- ufix24
              idx => std_logic_vector(shift11),  -- ufix6
              xout => xout11,  -- ufix25
              yout => yout11,  -- ufix25
              zout => zout11  -- ufix27
              );

  UIteration_11 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin12),  -- ufix25
              yin => std_logic_vector(yin12),  -- ufix25
              zin => std_logic_vector(zin12),  -- ufix27
              lut_value => std_logic_vector(lut_value12),  -- ufix24
              idx => std_logic_vector(shift12),  -- ufix6
              xout => xout12,  -- ufix25
              yout => yout12,  -- ufix25
              zout => zout12  -- ufix27
              );

  UIteration_12 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin13),  -- ufix25
              yin => std_logic_vector(yin13),  -- ufix25
              zin => std_logic_vector(zin13),  -- ufix27
              lut_value => std_logic_vector(lut_value13),  -- ufix24
              idx => std_logic_vector(shift13),  -- ufix6
              xout => xout13,  -- ufix25
              yout => yout13,  -- ufix25
              zout => zout13  -- ufix27
              );

  UIteration_13 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin14),  -- ufix25
              yin => std_logic_vector(yin14),  -- ufix25
              zin => std_logic_vector(zin14),  -- ufix27
              lut_value => std_logic_vector(lut_value14),  -- ufix24
              idx => std_logic_vector(shift14),  -- ufix6
              xout => xout14,  -- ufix25
              yout => yout14,  -- ufix25
              zout => zout14  -- ufix27
              );

  UIteration_14 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin15),  -- ufix25
              yin => std_logic_vector(yin15),  -- ufix25
              zin => std_logic_vector(zin15),  -- ufix27
              lut_value => std_logic_vector(lut_value15),  -- ufix24
              idx => std_logic_vector(shift15),  -- ufix6
              xout => xout15,  -- ufix25
              yout => yout15,  -- ufix25
              zout => zout15  -- ufix27
              );

  UIteration_15 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin16),  -- ufix25
              yin => std_logic_vector(yin16),  -- ufix25
              zin => std_logic_vector(zin16),  -- ufix27
              lut_value => std_logic_vector(lut_value16),  -- ufix24
              idx => std_logic_vector(shift16),  -- ufix6
              xout => xout16,  -- ufix25
              yout => yout16,  -- ufix25
              zout => zout16  -- ufix27
              );

  UIteration_16 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin17),  -- ufix25
              yin => std_logic_vector(yin17),  -- ufix25
              zin => std_logic_vector(zin17),  -- ufix27
              lut_value => std_logic_vector(lut_value17),  -- ufix24
              idx => std_logic_vector(shift17),  -- ufix6
              xout => xout17,  -- ufix25
              yout => yout17,  -- ufix25
              zout => zout17  -- ufix27
              );

  UIteration_17 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin18),  -- ufix25
              yin => std_logic_vector(yin18),  -- ufix25
              zin => std_logic_vector(zin18),  -- ufix27
              lut_value => std_logic_vector(lut_value18),  -- ufix24
              idx => std_logic_vector(shift18),  -- ufix6
              xout => xout18,  -- ufix25
              yout => yout18,  -- ufix25
              zout => zout18  -- ufix27
              );

  UIteration_18 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin19),  -- ufix25
              yin => std_logic_vector(yin19),  -- ufix25
              zin => std_logic_vector(zin19),  -- ufix27
              lut_value => std_logic_vector(lut_value19),  -- ufix24
              idx => std_logic_vector(shift19),  -- ufix6
              xout => xout19,  -- ufix25
              yout => yout19,  -- ufix25
              zout => zout19  -- ufix27
              );

  UIteration_19 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin20),  -- ufix25
              yin => std_logic_vector(yin20),  -- ufix25
              zin => std_logic_vector(zin20),  -- ufix27
              lut_value => std_logic_vector(lut_value20),  -- ufix24
              idx => std_logic_vector(shift20),  -- ufix6
              xout => xout20,  -- ufix25
              yout => yout20,  -- ufix25
              zout => zout20  -- ufix27
              );

  UIteration_20 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin21),  -- ufix25
              yin => std_logic_vector(yin21),  -- ufix25
              zin => std_logic_vector(zin21),  -- ufix27
              lut_value => std_logic_vector(lut_value21),  -- ufix24
              idx => std_logic_vector(shift21),  -- ufix6
              xout => xout21,  -- ufix25
              yout => yout21,  -- ufix25
              zout => zout21  -- ufix27
              );

  UIteration_21 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin22),  -- ufix25
              yin => std_logic_vector(yin22),  -- ufix25
              zin => std_logic_vector(zin22),  -- ufix27
              lut_value => std_logic_vector(lut_value22),  -- ufix24
              idx => std_logic_vector(shift22),  -- ufix6
              xout => xout22,  -- ufix25
              yout => yout22,  -- ufix25
              zout => zout22  -- ufix27
              );

  UIteration_22 : ltehdlDownlinkSyncDemod_CordicKernelMag
    PORT MAP( xin => std_logic_vector(xin23),  -- ufix25
              yin => std_logic_vector(yin23),  -- ufix25
              zin => std_logic_vector(zin23),  -- ufix27
              lut_value => std_logic_vector(lut_value23),  -- ufix24
              idx => std_logic_vector(shift23),  -- ufix6
              xout => xout23,  -- ufix25
              yout => yout23deadOutdeadOut,  -- ufix25
              zout => zout23  -- ufix27
              );

  UQuadrantCorrection : ltehdlDownlinkSyncDemod_Quadrant_Correction
    PORT MAP( zin => std_logic_vector(zin24),  -- ufix27
              QA_Control => std_logic_vector(ControlQCDelay),  -- ufix5
              zout => zout_corrected  -- ufix27
              );

  Delay_ValidIn_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay_ValidIn_reg_rsvd(0) <= validIn;
        Delay_ValidIn_reg_rsvd(25 DOWNTO 1) <= Delay_ValidIn_reg_rsvd(24 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS Delay_ValidIn_process;

  ValidOutDelayed <= Delay_ValidIn_reg_rsvd(25);

  reset_outval <=  NOT ValidOutDelayed;

  In_re_signed <= signed(In_re);

  qMapReal <= resize(In_re_signed, 25);

  In_im_signed <= signed(In_im);

  qMapImag <= resize(In_im_signed, 25);

  DelayRealInput_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        In1Register <= qMapReal;
      END IF;
    END IF;
  END PROCESS DelayRealInput_process;


  DelayImagInput_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        In2Register <= qMapImag;
      END IF;
    END IF;
  END PROCESS DelayImagInput_process;


  XQMapped_signed <= signed(XQMapped);

  yQMapped_signed <= signed(yQMapped);

  DelayQuadMapper1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin1 <= XQMapped_signed;
      END IF;
    END IF;
  END PROCESS DelayQuadMapper1_process;


  DelayQuadMapper2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin1 <= yQMapped_signed;
      END IF;
    END IF;
  END PROCESS DelayQuadMapper2_process;


  zin1 <= to_signed(16#0000000#, 27);

  lut_value1 <= to_unsigned(16#972029#, 24);

  shift1 <= to_unsigned(16#01#, 6);

  xout1_signed <= signed(xout1);

  yout1_signed <= signed(yout1);

  zout1_signed <= signed(zout1);

  Pipeline1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin2 <= xout1_signed;
      END IF;
    END IF;
  END PROCESS Pipeline1_process;


  Pipeline1_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin2 <= yout1_signed;
      END IF;
    END IF;
  END PROCESS Pipeline1_1_process;


  Pipeline1_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin2 <= zout1_signed;
      END IF;
    END IF;
  END PROCESS Pipeline1_2_process;


  lut_value2 <= to_unsigned(16#4FD9C3#, 24);

  shift2 <= to_unsigned(16#02#, 6);

  xout2_signed <= signed(xout2);

  yout2_signed <= signed(yout2);

  zout2_signed <= signed(zout2);

  Pipeline2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin3 <= xout2_signed;
      END IF;
    END IF;
  END PROCESS Pipeline2_process;


  Pipeline2_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin3 <= yout2_signed;
      END IF;
    END IF;
  END PROCESS Pipeline2_1_process;


  Pipeline2_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin3 <= zout2_signed;
      END IF;
    END IF;
  END PROCESS Pipeline2_2_process;


  lut_value3 <= to_unsigned(16#28888F#, 24);

  shift3 <= to_unsigned(16#03#, 6);

  xout3_signed <= signed(xout3);

  yout3_signed <= signed(yout3);

  zout3_signed <= signed(zout3);

  Pipeline3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin4 <= xout3_signed;
      END IF;
    END IF;
  END PROCESS Pipeline3_process;


  Pipeline3_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin4 <= yout3_signed;
      END IF;
    END IF;
  END PROCESS Pipeline3_1_process;


  Pipeline3_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin4 <= zout3_signed;
      END IF;
    END IF;
  END PROCESS Pipeline3_2_process;


  lut_value4 <= to_unsigned(16#14586A#, 24);

  shift4 <= to_unsigned(16#04#, 6);

  xout4_signed <= signed(xout4);

  yout4_signed <= signed(yout4);

  zout4_signed <= signed(zout4);

  Pipeline4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin5 <= xout4_signed;
      END IF;
    END IF;
  END PROCESS Pipeline4_process;


  Pipeline4_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin5 <= yout4_signed;
      END IF;
    END IF;
  END PROCESS Pipeline4_1_process;


  Pipeline4_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin5 <= zout4_signed;
      END IF;
    END IF;
  END PROCESS Pipeline4_2_process;


  lut_value5 <= to_unsigned(16#0A2EBF#, 24);

  shift5 <= to_unsigned(16#05#, 6);

  xout5_signed <= signed(xout5);

  yout5_signed <= signed(yout5);

  zout5_signed <= signed(zout5);

  Pipeline5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin6 <= xout5_signed;
      END IF;
    END IF;
  END PROCESS Pipeline5_process;


  Pipeline5_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin6 <= yout5_signed;
      END IF;
    END IF;
  END PROCESS Pipeline5_1_process;


  Pipeline5_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin6 <= zout5_signed;
      END IF;
    END IF;
  END PROCESS Pipeline5_2_process;


  lut_value6 <= to_unsigned(16#0517B1#, 24);

  shift6 <= to_unsigned(16#06#, 6);

  xout6_signed <= signed(xout6);

  yout6_signed <= signed(yout6);

  zout6_signed <= signed(zout6);

  Pipeline6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin7 <= xout6_signed;
      END IF;
    END IF;
  END PROCESS Pipeline6_process;


  Pipeline6_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin7 <= yout6_signed;
      END IF;
    END IF;
  END PROCESS Pipeline6_1_process;


  Pipeline6_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin7 <= zout6_signed;
      END IF;
    END IF;
  END PROCESS Pipeline6_2_process;


  lut_value7 <= to_unsigned(16#028BE3#, 24);

  shift7 <= to_unsigned(16#07#, 6);

  xout7_signed <= signed(xout7);

  yout7_signed <= signed(yout7);

  zout7_signed <= signed(zout7);

  Pipeline7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin8 <= xout7_signed;
      END IF;
    END IF;
  END PROCESS Pipeline7_process;


  Pipeline7_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin8 <= yout7_signed;
      END IF;
    END IF;
  END PROCESS Pipeline7_1_process;


  Pipeline7_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin8 <= zout7_signed;
      END IF;
    END IF;
  END PROCESS Pipeline7_2_process;


  lut_value8 <= to_unsigned(16#0145F3#, 24);

  shift8 <= to_unsigned(16#08#, 6);

  xout8_signed <= signed(xout8);

  yout8_signed <= signed(yout8);

  zout8_signed <= signed(zout8);

  Pipeline8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin9 <= xout8_signed;
      END IF;
    END IF;
  END PROCESS Pipeline8_process;


  Pipeline8_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin9 <= yout8_signed;
      END IF;
    END IF;
  END PROCESS Pipeline8_1_process;


  Pipeline8_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin9 <= zout8_signed;
      END IF;
    END IF;
  END PROCESS Pipeline8_2_process;


  lut_value9 <= to_unsigned(16#00A2F9#, 24);

  shift9 <= to_unsigned(16#09#, 6);

  xout9_signed <= signed(xout9);

  yout9_signed <= signed(yout9);

  zout9_signed <= signed(zout9);

  Pipeline9_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin10 <= xout9_signed;
      END IF;
    END IF;
  END PROCESS Pipeline9_process;


  Pipeline9_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin10 <= yout9_signed;
      END IF;
    END IF;
  END PROCESS Pipeline9_1_process;


  Pipeline9_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin10 <= zout9_signed;
      END IF;
    END IF;
  END PROCESS Pipeline9_2_process;


  lut_value10 <= to_unsigned(16#00517D#, 24);

  shift10 <= to_unsigned(16#0A#, 6);

  xout10_signed <= signed(xout10);

  yout10_signed <= signed(yout10);

  zout10_signed <= signed(zout10);

  Pipeline10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin11 <= xout10_signed;
      END IF;
    END IF;
  END PROCESS Pipeline10_process;


  Pipeline10_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin11 <= yout10_signed;
      END IF;
    END IF;
  END PROCESS Pipeline10_1_process;


  Pipeline10_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin11 <= zout10_signed;
      END IF;
    END IF;
  END PROCESS Pipeline10_2_process;


  lut_value11 <= to_unsigned(16#0028BE#, 24);

  shift11 <= to_unsigned(16#0B#, 6);

  xout11_signed <= signed(xout11);

  yout11_signed <= signed(yout11);

  zout11_signed <= signed(zout11);

  Pipeline11_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin12 <= xout11_signed;
      END IF;
    END IF;
  END PROCESS Pipeline11_process;


  Pipeline11_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin12 <= yout11_signed;
      END IF;
    END IF;
  END PROCESS Pipeline11_1_process;


  Pipeline11_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin12 <= zout11_signed;
      END IF;
    END IF;
  END PROCESS Pipeline11_2_process;


  lut_value12 <= to_unsigned(16#00145F#, 24);

  shift12 <= to_unsigned(16#0C#, 6);

  xout12_signed <= signed(xout12);

  yout12_signed <= signed(yout12);

  zout12_signed <= signed(zout12);

  Pipeline12_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin13 <= xout12_signed;
      END IF;
    END IF;
  END PROCESS Pipeline12_process;


  Pipeline12_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin13 <= yout12_signed;
      END IF;
    END IF;
  END PROCESS Pipeline12_1_process;


  Pipeline12_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin13 <= zout12_signed;
      END IF;
    END IF;
  END PROCESS Pipeline12_2_process;


  lut_value13 <= to_unsigned(16#000A30#, 24);

  shift13 <= to_unsigned(16#0D#, 6);

  xout13_signed <= signed(xout13);

  yout13_signed <= signed(yout13);

  zout13_signed <= signed(zout13);

  Pipeline13_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin14 <= xout13_signed;
      END IF;
    END IF;
  END PROCESS Pipeline13_process;


  Pipeline13_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin14 <= yout13_signed;
      END IF;
    END IF;
  END PROCESS Pipeline13_1_process;


  Pipeline13_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin14 <= zout13_signed;
      END IF;
    END IF;
  END PROCESS Pipeline13_2_process;


  lut_value14 <= to_unsigned(16#000518#, 24);

  shift14 <= to_unsigned(16#0E#, 6);

  xout14_signed <= signed(xout14);

  yout14_signed <= signed(yout14);

  zout14_signed <= signed(zout14);

  Pipeline14_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin15 <= xout14_signed;
      END IF;
    END IF;
  END PROCESS Pipeline14_process;


  Pipeline14_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin15 <= yout14_signed;
      END IF;
    END IF;
  END PROCESS Pipeline14_1_process;


  Pipeline14_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin15 <= zout14_signed;
      END IF;
    END IF;
  END PROCESS Pipeline14_2_process;


  lut_value15 <= to_unsigned(16#00028C#, 24);

  shift15 <= to_unsigned(16#0F#, 6);

  xout15_signed <= signed(xout15);

  yout15_signed <= signed(yout15);

  zout15_signed <= signed(zout15);

  Pipeline15_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin16 <= xout15_signed;
      END IF;
    END IF;
  END PROCESS Pipeline15_process;


  Pipeline15_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin16 <= yout15_signed;
      END IF;
    END IF;
  END PROCESS Pipeline15_1_process;


  Pipeline15_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin16 <= zout15_signed;
      END IF;
    END IF;
  END PROCESS Pipeline15_2_process;


  lut_value16 <= to_unsigned(16#000146#, 24);

  shift16 <= to_unsigned(16#10#, 6);

  xout16_signed <= signed(xout16);

  yout16_signed <= signed(yout16);

  zout16_signed <= signed(zout16);

  Pipeline16_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin17 <= xout16_signed;
      END IF;
    END IF;
  END PROCESS Pipeline16_process;


  Pipeline16_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin17 <= yout16_signed;
      END IF;
    END IF;
  END PROCESS Pipeline16_1_process;


  Pipeline16_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin17 <= zout16_signed;
      END IF;
    END IF;
  END PROCESS Pipeline16_2_process;


  lut_value17 <= to_unsigned(16#0000A3#, 24);

  shift17 <= to_unsigned(16#11#, 6);

  xout17_signed <= signed(xout17);

  yout17_signed <= signed(yout17);

  zout17_signed <= signed(zout17);

  Pipeline17_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin18 <= xout17_signed;
      END IF;
    END IF;
  END PROCESS Pipeline17_process;


  Pipeline17_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin18 <= yout17_signed;
      END IF;
    END IF;
  END PROCESS Pipeline17_1_process;


  Pipeline17_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin18 <= zout17_signed;
      END IF;
    END IF;
  END PROCESS Pipeline17_2_process;


  lut_value18 <= to_unsigned(16#000051#, 24);

  shift18 <= to_unsigned(16#12#, 6);

  xout18_signed <= signed(xout18);

  yout18_signed <= signed(yout18);

  zout18_signed <= signed(zout18);

  Pipeline18_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin19 <= xout18_signed;
      END IF;
    END IF;
  END PROCESS Pipeline18_process;


  Pipeline18_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin19 <= yout18_signed;
      END IF;
    END IF;
  END PROCESS Pipeline18_1_process;


  Pipeline18_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin19 <= zout18_signed;
      END IF;
    END IF;
  END PROCESS Pipeline18_2_process;


  lut_value19 <= to_unsigned(16#000029#, 24);

  shift19 <= to_unsigned(16#13#, 6);

  xout19_signed <= signed(xout19);

  yout19_signed <= signed(yout19);

  zout19_signed <= signed(zout19);

  Pipeline19_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin20 <= xout19_signed;
      END IF;
    END IF;
  END PROCESS Pipeline19_process;


  Pipeline19_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin20 <= yout19_signed;
      END IF;
    END IF;
  END PROCESS Pipeline19_1_process;


  Pipeline19_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin20 <= zout19_signed;
      END IF;
    END IF;
  END PROCESS Pipeline19_2_process;


  lut_value20 <= to_unsigned(16#000014#, 24);

  shift20 <= to_unsigned(16#14#, 6);

  xout20_signed <= signed(xout20);

  yout20_signed <= signed(yout20);

  zout20_signed <= signed(zout20);

  Pipeline20_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin21 <= xout20_signed;
      END IF;
    END IF;
  END PROCESS Pipeline20_process;


  Pipeline20_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin21 <= yout20_signed;
      END IF;
    END IF;
  END PROCESS Pipeline20_1_process;


  Pipeline20_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin21 <= zout20_signed;
      END IF;
    END IF;
  END PROCESS Pipeline20_2_process;


  lut_value21 <= to_unsigned(16#00000A#, 24);

  shift21 <= to_unsigned(16#15#, 6);

  xout21_signed <= signed(xout21);

  yout21_signed <= signed(yout21);

  zout21_signed <= signed(zout21);

  Pipeline21_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin22 <= xout21_signed;
      END IF;
    END IF;
  END PROCESS Pipeline21_process;


  Pipeline21_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin22 <= yout21_signed;
      END IF;
    END IF;
  END PROCESS Pipeline21_1_process;


  Pipeline21_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin22 <= zout21_signed;
      END IF;
    END IF;
  END PROCESS Pipeline21_2_process;


  lut_value22 <= to_unsigned(16#000005#, 24);

  shift22 <= to_unsigned(16#16#, 6);

  xout22_signed <= signed(xout22);

  yout22_signed <= signed(yout22);

  zout22_signed <= signed(zout22);

  Pipeline22_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin23 <= xout22_signed;
      END IF;
    END IF;
  END PROCESS Pipeline22_process;


  Pipeline22_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        yin23 <= yout22_signed;
      END IF;
    END IF;
  END PROCESS Pipeline22_1_process;


  Pipeline22_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin23 <= zout22_signed;
      END IF;
    END IF;
  END PROCESS Pipeline22_2_process;


  lut_value23 <= to_unsigned(16#000003#, 24);

  shift23 <= to_unsigned(16#17#, 6);

  xout23_signed <= signed(xout23);

  Pipeline23_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin24 <= xout23_signed;
      END IF;
    END IF;
  END PROCESS Pipeline23_process;


  -- CSD Encoding (28141) : 1001'001'00001'01'01; Cost (Adders) = 5
  CSD_Gain_Factor_mul_temp <= ((((resize(xin24 & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 41) - resize(xin24 & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 41)) - resize(xin24 
    & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 41)) - resize(xin24 & '0' & '0' & '0' & '0', 41)) - resize(xin24 & '0' & '0', 41)) + resize(xin24, 41);
  CSD_Gain_Factor_cast <= CSD_Gain_Factor_mul_temp(39 DOWNTO 0);
  xoutscaled <= CSD_Gain_Factor_cast(39 DOWNTO 15);

  
  outSwitchMag <= xoutscaled WHEN reset_outval = '0' ELSE
      to_signed(16#0000000#, 25);

  Output_Register_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        xin25 <= outSwitchMag;
      END IF;
    END IF;
  END PROCESS Output_Register_process;


  magnitude <= std_logic_vector(xin25);

  zout23_signed <= signed(zout23);

  ControlQC_unsigned <= unsigned(ControlQC);

  Pipeline23_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zin24 <= zout23_signed;
      END IF;
    END IF;
  END PROCESS Pipeline23_1_process;


  DelayQC_Control_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        DelayQC_Control_reg_rsvd(0) <= ControlQC_unsigned;
        DelayQC_Control_reg_rsvd(1 TO 23) <= DelayQC_Control_reg_rsvd(0 TO 22);
      END IF;
    END IF;
  END PROCESS DelayQC_Control_process;

  ControlQCDelay <= DelayQC_Control_reg_rsvd(23);

  zout_corrected_signed <= signed(zout_corrected);

  
  outSwitchAng <= zout_corrected_signed WHEN reset_outval = '0' ELSE
      to_signed(16#0000000#, 27);

  Output_Register_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        zout_corrected_1 <= outSwitchAng;
      END IF;
    END IF;
  END PROCESS Output_Register_1_process;


  angle_rsvd <= std_logic_vector(zout_corrected_1);

  DelayValidOut_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        validOut <= ValidOutDelayed;
      END IF;
    END IF;
  END PROCESS DelayValidOut_process;


END rtl;

