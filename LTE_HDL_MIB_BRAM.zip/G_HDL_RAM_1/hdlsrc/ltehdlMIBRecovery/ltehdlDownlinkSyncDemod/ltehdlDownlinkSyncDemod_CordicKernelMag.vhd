-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_CordicKernelMag IS
  PORT( xin                               :   IN    std_logic_vector(24 DOWNTO 0);  -- ufix25
        yin                               :   IN    std_logic_vector(24 DOWNTO 0);  -- ufix25
        zin                               :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
        lut_value                         :   IN    std_logic_vector(23 DOWNTO 0);  -- ufix24
        idx                               :   IN    std_logic_vector(5 DOWNTO 0);  -- ufix6
        xout                              :   OUT   std_logic_vector(24 DOWNTO 0);  -- ufix25
        yout                              :   OUT   std_logic_vector(24 DOWNTO 0);  -- ufix25
        zout                              :   OUT   std_logic_vector(26 DOWNTO 0)  -- ufix27
        );
END ltehdlDownlinkSyncDemod_CordicKernelMag;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_CordicKernelMag IS

  -- Signals
  SIGNAL yin_signed                       : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yLessThanZero                    : std_logic;
  SIGNAL xin_signed                       : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL idx_unsigned                     : unsigned(5 DOWNTO 0);  -- ufix6
  SIGNAL dynamic_shift_cast               : unsigned(7 DOWNTO 0);  -- uint8
  SIGNAL yShifted                         : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL xout2                            : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL xout1                            : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL xout_tmp                         : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL dynamic_shift_cast_1             : unsigned(7 DOWNTO 0);  -- uint8
  SIGNAL xShifted                         : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout2                            : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout1                            : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL yout_tmp                         : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL zin_signed                       : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL lut_value_unsigned               : unsigned(23 DOWNTO 0);  -- ufix24_En26
  SIGNAL zout2                            : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL zout1                            : signed(26 DOWNTO 0);  -- sfix27_En26
  SIGNAL zout_tmp                         : signed(26 DOWNTO 0);  -- sfix27_En26

BEGIN
  yin_signed <= signed(yin);

  
  yLessThanZero <= '1' WHEN yin_signed < to_signed(16#0000000#, 25) ELSE
      '0';

  xin_signed <= signed(xin);

  idx_unsigned <= unsigned(idx);

  dynamic_shift_cast <= resize(idx_unsigned, 8);
  yShifted <= SHIFT_RIGHT(yin_signed, to_integer(dynamic_shift_cast));

  xout2 <= xin_signed + yShifted;

  xout1 <= xin_signed - yShifted;

  
  xout_tmp <= xout2 WHEN yLessThanZero = '0' ELSE
      xout1;

  xout <= std_logic_vector(xout_tmp);

  dynamic_shift_cast_1 <= resize(idx_unsigned, 8);
  xShifted <= SHIFT_RIGHT(xin_signed, to_integer(dynamic_shift_cast_1));

  yout2 <= yin_signed - xShifted;

  yout1 <= yin_signed + xShifted;

  
  yout_tmp <= yout2 WHEN yLessThanZero = '0' ELSE
      yout1;

  yout <= std_logic_vector(yout_tmp);

  zin_signed <= signed(zin);

  lut_value_unsigned <= unsigned(lut_value);

  zout2 <= zin_signed + signed(resize(lut_value_unsigned, 27));

  zout1 <= zin_signed - signed(resize(lut_value_unsigned, 27));

  
  zout_tmp <= zout2 WHEN yLessThanZero = '0' ELSE
      zout1;

  zout <= std_logic_vector(zout_tmp);

END rtl;

