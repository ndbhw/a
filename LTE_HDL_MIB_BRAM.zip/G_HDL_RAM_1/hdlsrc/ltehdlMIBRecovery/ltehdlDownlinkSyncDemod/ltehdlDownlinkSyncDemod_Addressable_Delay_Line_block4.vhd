-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block4 IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn                            :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        wrEn                              :   IN    std_logic;
        wrAddr                            :   IN    std_logic_vector(4 DOWNTO 0);  -- ufix5
        rdAddr                            :   IN    std_logic_vector(4 DOWNTO 0);  -- ufix5
        delayLineEnd                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
        dataOut                           :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
        );
END ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block4;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block4 IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic
    GENERIC( AddrWidth                    : integer;
             DataWidth                    : integer
             );
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          wr_din                          :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          wr_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          wr_en                           :   IN    std_logic;
          rd_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          dout                            :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0)  -- generic width
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic(rtl);

  -- Signals
  SIGNAL wrAddr_unsigned                  : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL rdAddr_unsigned                  : unsigned(4 DOWNTO 0);  -- ufix5
  SIGNAL saveLast                         : std_logic;
  SIGNAL dataEndEn                        : std_logic := '0';
  SIGNAL wrEnN                            : std_logic;
  SIGNAL dataEndEnS                       : std_logic;
  SIGNAL delayedSignals                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL delayedSignals_signed            : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL delayLineEnd_tmp                 : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15

BEGIN
  UsimpleDualPortRam_4 : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 5,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb => enb,
              wr_din => dataIn,
              wr_addr => wrAddr,
              wr_en => wrEn,
              rd_addr => rdAddr,
              dout => delayedSignals
              );

  wrAddr_unsigned <= unsigned(wrAddr);

  rdAddr_unsigned <= unsigned(rdAddr);

  
  saveLast <= '1' WHEN wrAddr_unsigned = rdAddr_unsigned ELSE
      '0';

  dataOutReg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        dataEndEn <= saveLast;
      END IF;
    END IF;
  END PROCESS dataOutReg_process;


  wrEnN <=  NOT dataEndEn;

  dataEndEnS <= saveLast AND wrEnN;

  delayedSignals_signed <= signed(delayedSignals);

  dataOutReg_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND dataEndEnS = '1' THEN
        delayLineEnd_tmp <= delayedSignals_signed;
      END IF;
    END IF;
  END PROCESS dataOutReg_1_process;


  delayLineEnd <= std_logic_vector(delayLineEnd_tmp);

  dataOut <= delayedSignals;

END rtl;

