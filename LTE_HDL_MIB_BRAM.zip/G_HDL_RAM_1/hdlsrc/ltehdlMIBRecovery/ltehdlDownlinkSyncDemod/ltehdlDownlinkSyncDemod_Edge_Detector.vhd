-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_Edge_Detector IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        x_x                               :   IN    std_logic;
        y_y                               :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Edge_Detector;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Edge_Detector IS

  -- Signals
  SIGNAL Delay2_out1                      : std_logic := '0';
  SIGNAL Logical_Operator1_out1           : std_logic;
  SIGNAL Logical_Operator_out1            : std_logic;

BEGIN
  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay2_out1 <= x_x;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  Logical_Operator1_out1 <=  NOT Delay2_out1;

  Logical_Operator_out1 <= x_x AND Logical_Operator1_out1;

  y_y <= Logical_Operator_out1;

END rtl;

