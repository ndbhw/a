-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_NCO_HDL_Optimized1_block IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        inc                               :   IN    std_logic_vector(13 DOWNTO 0);  -- ufix14
        validIn                           :   IN    std_logic;
        complexexp_re                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
        complexexp_im                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_NCO_HDL_Optimized1_block;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_NCO_HDL_Optimized1_block IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_DitherGen_block
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          validIn                         :   IN    std_logic;
          dither                          :   OUT   std_logic_vector(10 DOWNTO 0)  -- ufix11
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_WaveformGen_block
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          phaseIdx                        :   IN    std_logic_vector(13 DOWNTO 0);  -- ufix14
          exp_re                          :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          exp_im                          :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_DitherGen_block
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_DitherGen_block(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_WaveformGen_block
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_WaveformGen_block(rtl);

  -- Signals
  SIGNAL outsel_reg_reg_rsvd              : std_logic_vector(4 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [5]
  SIGNAL outsel                           : std_logic;
  SIGNAL outzero_re                       : signed(15 DOWNTO 0);  -- sfix16_En14
  SIGNAL outzero_im                       : signed(15 DOWNTO 0);  -- sfix16_En14
  SIGNAL inc_signed                       : signed(13 DOWNTO 0);  -- sfix14
  SIGNAL pInc                             : signed(20 DOWNTO 0);  -- sfix21
  SIGNAL validPInc                        : signed(20 DOWNTO 0);  -- sfix21
  SIGNAL accphase_reg                     : signed(20 DOWNTO 0) := to_signed(16#000000#, 21);  -- sfix21
  SIGNAL addpInc                          : signed(20 DOWNTO 0);  -- sfix21
  SIGNAL accoffset                        : signed(20 DOWNTO 0);  -- sfix21
  SIGNAL accoffsete_reg                   : signed(20 DOWNTO 0) := to_signed(16#000000#, 21);  -- sfix21
  SIGNAL dither                           : std_logic_vector(10 DOWNTO 0);  -- ufix11
  SIGNAL dither_unsigned                  : unsigned(10 DOWNTO 0);  -- ufix11
  SIGNAL casteddither                     : signed(20 DOWNTO 0);  -- sfix21
  SIGNAL dither_reg                       : signed(20 DOWNTO 0) := to_signed(16#000000#, 21);  -- sfix21
  SIGNAL accumulator                      : signed(20 DOWNTO 0);  -- sfix21
  SIGNAL accQuantized                     : unsigned(13 DOWNTO 0);  -- ufix14_E7
  SIGNAL outs_re                          : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL outs_im                          : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL outs_re_signed                   : signed(15 DOWNTO 0);  -- sfix16_En14
  SIGNAL outs_im_signed                   : signed(15 DOWNTO 0);  -- sfix16_En14
  SIGNAL validouts_re                     : signed(15 DOWNTO 0);  -- sfix16_En14
  SIGNAL validouts_im                     : signed(15 DOWNTO 0);  -- sfix16_En14
  SIGNAL complexexp_re_tmp                : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En14
  SIGNAL complexexp_im_tmp                : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En14

BEGIN
  Udither_inst_1 : ltehdlDownlinkSyncDemod_DitherGen_block
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              validIn => validIn,
              dither => dither  -- ufix11
              );

  UWave_inst_1 : ltehdlDownlinkSyncDemod_WaveformGen_block
    PORT MAP( clk => clk,
              enb => enb,
              phaseIdx => std_logic_vector(accQuantized),  -- ufix14
              exp_re => outs_re,  -- ufix16
              exp_im => outs_im  -- ufix16
              );

  outsel_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        outsel_reg_reg_rsvd(0) <= validIn;
        outsel_reg_reg_rsvd(4 DOWNTO 1) <= outsel_reg_reg_rsvd(3 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS outsel_reg_process;

  outsel <= outsel_reg_reg_rsvd(4);

  outzero_re <= to_signed(16#0000#, 16);
  outzero_im <= to_signed(16#0000#, 16);

  inc_signed <= signed(inc);

  pInc <= resize(inc_signed, 21);

  -- Constant Zero
  
  validPInc <= to_signed(16#000000#, 21) WHEN validIn = '0' ELSE
      pInc;

  -- Add phase increment
  addpInc <= accphase_reg + validPInc;

  -- Phase increment accumulator register
  AccPhaseRegister_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        accphase_reg <= addpInc;
      END IF;
    END IF;
  END PROCESS AccPhaseRegister_process;


  -- Add phase offset
  accoffset <= accphase_reg;

  -- Phase offset accumulator register
  AccOffsetRegister_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        accoffsete_reg <= accoffset;
      END IF;
    END IF;
  END PROCESS AccOffsetRegister_process;


  dither_unsigned <= unsigned(dither);

  casteddither <= signed(resize(dither_unsigned, 21));

  -- Dither input register
  DitherRegister_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        dither_reg <= casteddither;
      END IF;
    END IF;
  END PROCESS DitherRegister_process;


  -- Add dither
  accumulator <= accoffsete_reg + dither_reg;

  -- Phase quantization
  accQuantized <= unsigned(accumulator(20 DOWNTO 7));

  outs_re_signed <= signed(outs_re);

  outs_im_signed <= signed(outs_im);

  
  validouts_re <= outzero_re WHEN outsel = '0' ELSE
      outs_re_signed;
  
  validouts_im <= outzero_im WHEN outsel = '0' ELSE
      outs_im_signed;

  -- Output register
  OutputRegister_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        complexexp_re_tmp <= validouts_re;
        complexexp_im_tmp <= validouts_im;
      END IF;
    END IF;
  END PROCESS OutputRegister_process;


  complexexp_re <= std_logic_vector(complexexp_re_tmp);

  complexexp_im <= std_logic_vector(complexexp_im_tmp);

  -- validOut register
  validOut_reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        validOut <= outsel;
      END IF;
    END IF;
  END PROCESS validOut_reg_process;


END rtl;

