-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_FFT_HDL_Optimized IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        validIn                           :   IN    std_logic;
        syncReset                         :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
        dataOut_im                        :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_FFT_HDL_Optimized;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_FFT_HDL_Optimized IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_1
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dinXTwdl_1_1_vld                :   IN    std_logic;
          dinXTwdl_1_1_vld_1              :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          rd_1_Addr                       :   OUT   std_logic_vector(9 DOWNTO 0);  -- ufix10
          rd_1_Enb                        :   OUT   std_logic;
          proc_1_enb                      :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_1
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          din_1_1_re_dly                  :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          din_1_1_im_dly                  :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          din_1_vld_dly                   :   IN    std_logic;
          rd_1_Addr                       :   IN    std_logic_vector(9 DOWNTO 0);  -- ufix10
          rd_1_Enb                        :   IN    std_logic;
          proc_1_enb                      :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          dout_1_1_re                     :   OUT   std_logic_vector(16 DOWNTO 0);  -- ufix17
          dout_1_1_im                     :   OUT   std_logic_vector(16 DOWNTO 0);  -- ufix17
          dout_1_1_vld                    :   OUT   std_logic;
          dinXTwdl_1_1_vld                :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_2
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_1_1_vld                    :   IN    std_logic;
          dinXTwdl_2_1_vld                :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          rd_2_Addr                       :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
          rd_2_Enb                        :   OUT   std_logic;
          proc_2_enb                      :   OUT   std_logic;
          multiply_2_J                    :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_2
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_1_1_re                     :   IN    std_logic_vector(16 DOWNTO 0);  -- ufix17
          dout_1_1_im                     :   IN    std_logic_vector(16 DOWNTO 0);  -- ufix17
          dout_1_1_vld                    :   IN    std_logic;
          rd_2_Addr                       :   IN    std_logic_vector(8 DOWNTO 0);  -- ufix9
          rd_2_Enb                        :   IN    std_logic;
          proc_2_enb                      :   IN    std_logic;
          multiply_2_J                    :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          dout_2_1_re                     :   OUT   std_logic_vector(17 DOWNTO 0);  -- ufix18
          dout_2_1_im                     :   OUT   std_logic_vector(17 DOWNTO 0);  -- ufix18
          dout_2_1_vld                    :   OUT   std_logic;
          dinXTwdl_2_1_vld                :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_TWDLROM_3_1
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_2_1_vld                    :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          twdl_3_1_re                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          twdl_3_1_im                     :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_3
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dinXTwdl_3_1_vld                :   IN    std_logic;
          dinXTwdl_3_1_vld_1              :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          rd_3_Addr                       :   OUT   std_logic_vector(7 DOWNTO 0);  -- ufix8
          rd_3_Enb                        :   OUT   std_logic;
          proc_3_enb                      :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_3
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          din_3_1_re_dly                  :   IN    std_logic_vector(17 DOWNTO 0);  -- ufix18
          din_3_1_im_dly                  :   IN    std_logic_vector(17 DOWNTO 0);  -- ufix18
          din_3_vld_dly                   :   IN    std_logic;
          rd_3_Addr                       :   IN    std_logic_vector(7 DOWNTO 0);  -- ufix8
          rd_3_Enb                        :   IN    std_logic;
          twdl_3_1_re                     :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          twdl_3_1_im                     :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          proc_3_enb                      :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          dout_3_1_re                     :   OUT   std_logic_vector(18 DOWNTO 0);  -- ufix19
          dout_3_1_im                     :   OUT   std_logic_vector(18 DOWNTO 0);  -- ufix19
          dout_3_1_vld                    :   OUT   std_logic;
          dinXTwdl_3_1_vld                :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_4
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_3_1_vld                    :   IN    std_logic;
          dinXTwdl_4_1_vld                :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          rd_4_Addr                       :   OUT   std_logic_vector(6 DOWNTO 0);  -- ufix7
          rd_4_Enb                        :   OUT   std_logic;
          proc_4_enb                      :   OUT   std_logic;
          multiply_4_J                    :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_4
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_3_1_re                     :   IN    std_logic_vector(18 DOWNTO 0);  -- ufix19
          dout_3_1_im                     :   IN    std_logic_vector(18 DOWNTO 0);  -- ufix19
          dout_3_1_vld                    :   IN    std_logic;
          rd_4_Addr                       :   IN    std_logic_vector(6 DOWNTO 0);  -- ufix7
          rd_4_Enb                        :   IN    std_logic;
          proc_4_enb                      :   IN    std_logic;
          multiply_4_J                    :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          dout_4_1_re                     :   OUT   std_logic_vector(19 DOWNTO 0);  -- ufix20
          dout_4_1_im                     :   OUT   std_logic_vector(19 DOWNTO 0);  -- ufix20
          dout_4_1_vld                    :   OUT   std_logic;
          dinXTwdl_4_1_vld                :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_TWDLROM_5_1
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_4_1_vld                    :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          twdl_5_1_re                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          twdl_5_1_im                     :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_5
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dinXTwdl_5_1_vld                :   IN    std_logic;
          dinXTwdl_5_1_vld_1              :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          rd_5_Addr                       :   OUT   std_logic_vector(5 DOWNTO 0);  -- ufix6
          rd_5_Enb                        :   OUT   std_logic;
          proc_5_enb                      :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_5
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          din_5_1_re_dly                  :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
          din_5_1_im_dly                  :   IN    std_logic_vector(19 DOWNTO 0);  -- ufix20
          din_5_vld_dly                   :   IN    std_logic;
          rd_5_Addr                       :   IN    std_logic_vector(5 DOWNTO 0);  -- ufix6
          rd_5_Enb                        :   IN    std_logic;
          twdl_5_1_re                     :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          twdl_5_1_im                     :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          proc_5_enb                      :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          dout_5_1_re                     :   OUT   std_logic_vector(20 DOWNTO 0);  -- ufix21
          dout_5_1_im                     :   OUT   std_logic_vector(20 DOWNTO 0);  -- ufix21
          dout_5_1_vld                    :   OUT   std_logic;
          dinXTwdl_5_1_vld                :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_6
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_5_1_vld                    :   IN    std_logic;
          dinXTwdl_6_1_vld                :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          rd_6_Addr                       :   OUT   std_logic_vector(4 DOWNTO 0);  -- ufix5
          rd_6_Enb                        :   OUT   std_logic;
          proc_6_enb                      :   OUT   std_logic;
          multiply_6_J                    :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_6
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_5_1_re                     :   IN    std_logic_vector(20 DOWNTO 0);  -- ufix21
          dout_5_1_im                     :   IN    std_logic_vector(20 DOWNTO 0);  -- ufix21
          dout_5_1_vld                    :   IN    std_logic;
          rd_6_Addr                       :   IN    std_logic_vector(4 DOWNTO 0);  -- ufix5
          rd_6_Enb                        :   IN    std_logic;
          proc_6_enb                      :   IN    std_logic;
          multiply_6_J                    :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          dout_6_1_re                     :   OUT   std_logic_vector(21 DOWNTO 0);  -- ufix22
          dout_6_1_im                     :   OUT   std_logic_vector(21 DOWNTO 0);  -- ufix22
          dout_6_1_vld                    :   OUT   std_logic;
          dinXTwdl_6_1_vld                :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_TWDLROM_7_1
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_6_1_vld                    :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          twdl_7_1_re                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          twdl_7_1_im                     :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_7
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dinXTwdl_7_1_vld                :   IN    std_logic;
          dinXTwdl_7_1_vld_1              :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          rd_7_Addr                       :   OUT   std_logic_vector(3 DOWNTO 0);  -- ufix4
          rd_7_Enb                        :   OUT   std_logic;
          proc_7_enb                      :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_7
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          din_7_1_re_dly                  :   IN    std_logic_vector(21 DOWNTO 0);  -- ufix22
          din_7_1_im_dly                  :   IN    std_logic_vector(21 DOWNTO 0);  -- ufix22
          din_7_vld_dly                   :   IN    std_logic;
          rd_7_Addr                       :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          rd_7_Enb                        :   IN    std_logic;
          twdl_7_1_re                     :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          twdl_7_1_im                     :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          proc_7_enb                      :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          dout_7_1_re                     :   OUT   std_logic_vector(22 DOWNTO 0);  -- ufix23
          dout_7_1_im                     :   OUT   std_logic_vector(22 DOWNTO 0);  -- ufix23
          dout_7_1_vld                    :   OUT   std_logic;
          dinXTwdl_7_1_vld                :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_8
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_7_1_vld                    :   IN    std_logic;
          dinXTwdl_8_1_vld                :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          rd_8_Addr                       :   OUT   std_logic_vector(2 DOWNTO 0);  -- ufix3
          rd_8_Enb                        :   OUT   std_logic;
          proc_8_enb                      :   OUT   std_logic;
          multiply_8_J                    :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_8
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_7_1_re                     :   IN    std_logic_vector(22 DOWNTO 0);  -- ufix23
          dout_7_1_im                     :   IN    std_logic_vector(22 DOWNTO 0);  -- ufix23
          dout_7_1_vld                    :   IN    std_logic;
          rd_8_Addr                       :   IN    std_logic_vector(2 DOWNTO 0);  -- ufix3
          rd_8_Enb                        :   IN    std_logic;
          proc_8_enb                      :   IN    std_logic;
          multiply_8_J                    :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          dout_8_1_re                     :   OUT   std_logic_vector(23 DOWNTO 0);  -- ufix24
          dout_8_1_im                     :   OUT   std_logic_vector(23 DOWNTO 0);  -- ufix24
          dout_8_1_vld                    :   OUT   std_logic;
          dinXTwdl_8_1_vld                :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_TWDLROM_9_1
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_8_1_vld                    :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          twdl_9_1_re                     :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          twdl_9_1_im                     :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_9
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dinXTwdl_9_1_vld                :   IN    std_logic;
          dinXTwdl_9_1_vld_1              :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          rd_9_Addr                       :   OUT   std_logic_vector(1 DOWNTO 0);  -- ufix2
          rd_9_Enb                        :   OUT   std_logic;
          proc_9_enb                      :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_9
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          din_9_1_re_dly                  :   IN    std_logic_vector(23 DOWNTO 0);  -- ufix24
          din_9_1_im_dly                  :   IN    std_logic_vector(23 DOWNTO 0);  -- ufix24
          din_9_vld_dly                   :   IN    std_logic;
          rd_9_Addr                       :   IN    std_logic_vector(1 DOWNTO 0);  -- ufix2
          rd_9_Enb                        :   IN    std_logic;
          twdl_9_1_re                     :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          twdl_9_1_im                     :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          proc_9_enb                      :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          dout_9_1_re                     :   OUT   std_logic_vector(24 DOWNTO 0);  -- ufix25
          dout_9_1_im                     :   OUT   std_logic_vector(24 DOWNTO 0);  -- ufix25
          dout_9_1_vld                    :   OUT   std_logic;
          dinXTwdl_9_1_vld                :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_10
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_9_1_vld                    :   IN    std_logic;
          dinXTwdl_10_1_vld               :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          rd_10_Addr                      :   OUT   std_logic;  -- ufix1
          rd_10_Enb                       :   OUT   std_logic;
          proc_10_enb                     :   OUT   std_logic;
          multiply_10_J                   :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_10
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_9_1_re                     :   IN    std_logic_vector(24 DOWNTO 0);  -- ufix25
          dout_9_1_im                     :   IN    std_logic_vector(24 DOWNTO 0);  -- ufix25
          dout_9_1_vld                    :   IN    std_logic;
          rd_10_Addr                      :   IN    std_logic;  -- ufix1
          rd_10_Enb                       :   IN    std_logic;
          proc_10_enb                     :   IN    std_logic;
          multiply_10_J                   :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          dout_10_1_re                    :   OUT   std_logic_vector(25 DOWNTO 0);  -- ufix26
          dout_10_1_im                    :   OUT   std_logic_vector(25 DOWNTO 0);  -- ufix26
          dout_10_1_vld                   :   OUT   std_logic;
          dinXTwdl_10_1_vld               :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_TWDLROM_11_1
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_10_1_vld                   :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          twdl_11_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          twdl_11_im                      :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_1_block
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dinXTwdl_11_vld                 :   IN    std_logic;
          dinXTwdl_11_vld_1               :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          rd_11_Addr                      :   OUT   std_logic;
          rd_11_Enb                       :   OUT   std_logic;
          proc_11_enb                     :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_11
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          din_11_re_dly                   :   IN    std_logic_vector(25 DOWNTO 0);  -- ufix26
          din_11_im_dly                   :   IN    std_logic_vector(25 DOWNTO 0);  -- ufix26
          din_11_vld_dly                  :   IN    std_logic;
          rd_11_Addr                      :   IN    std_logic;
          rd_11_Enb_dly                   :   IN    std_logic;
          twdl_11_re                      :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          twdl_11_im                      :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          proc_11_enb                     :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          dout_11_re                      :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
          dout_11_im                      :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
          dout_11_vld                     :   OUT   std_logic;
          dinXTwdl_11_vld                 :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_RADIX2FFT_bitNatural
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dout_11_re                      :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
          dout_11_im                      :   IN    std_logic_vector(26 DOWNTO 0);  -- ufix27
          dout_11_vld                     :   IN    std_logic;
          syncReset                       :   IN    std_logic;
          dout_re1                        :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
          dout_im1                        :   OUT   std_logic_vector(26 DOWNTO 0);  -- ufix27
          dout_vld1                       :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_1
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_1(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_1
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_1(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_2
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_2(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_2
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_2(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_TWDLROM_3_1
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_TWDLROM_3_1(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_3
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_3(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_3
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_3(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_4
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_4(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_4
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_4(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_TWDLROM_5_1
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_TWDLROM_5_1(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_5
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_5(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_5
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_5(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_6
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_6(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_6
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_6(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_TWDLROM_7_1
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_TWDLROM_7_1(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_7
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_7(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_7
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_7(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_8
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_8(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_8
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_8(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_TWDLROM_9_1
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_TWDLROM_9_1(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_9
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_9(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_9
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_9(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_10
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_10(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_10
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_10(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_TWDLROM_11_1
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_TWDLROM_11_1(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_1_block
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_1_block(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_11
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_11(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_RADIX2FFT_bitNatural
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_RADIX2FFT_bitNatural(rtl);

  -- Signals
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL intdelay_reg_rsvd                : vector_of_signed16(0 TO 2) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16 [3]
  SIGNAL din_1_1_re_dly                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL intdelay_reg_rsvd_1              : vector_of_signed16(0 TO 2) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16 [3]
  SIGNAL din_1_1_im_dly                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL intdelay_reg_rsvd_2              : std_logic_vector(2 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [3]
  SIGNAL din_1_vld_dly                    : std_logic;
  SIGNAL dinXTwdl_1_1_vld                 : std_logic;
  SIGNAL rd_1_Addr                        : std_logic_vector(9 DOWNTO 0);  -- ufix10
  SIGNAL rd_1_Enb                         : std_logic;
  SIGNAL proc_1_enb                       : std_logic;
  SIGNAL dout_1_1_re                      : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL dout_1_1_im                      : std_logic_vector(16 DOWNTO 0);  -- ufix17
  SIGNAL dout_1_1_vld                     : std_logic;
  SIGNAL dinXTwdl_2_1_vld                 : std_logic;
  SIGNAL rd_2_Addr                        : std_logic_vector(8 DOWNTO 0);  -- ufix9
  SIGNAL rd_2_Enb                         : std_logic;
  SIGNAL proc_2_enb                       : std_logic;
  SIGNAL multiply_2_J                     : std_logic;
  SIGNAL dout_2_1_re                      : std_logic_vector(17 DOWNTO 0);  -- ufix18
  SIGNAL dout_2_1_im                      : std_logic_vector(17 DOWNTO 0);  -- ufix18
  SIGNAL dout_2_1_vld                     : std_logic;
  SIGNAL dout_2_1_re_signed               : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL dout_2_1_im_signed               : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL intdelay_reg_rsvd_3              : vector_of_signed18(0 TO 2) := (OTHERS => to_signed(16#00000#, 18));  -- sfix18 [3]
  SIGNAL din_3_1_re_dly                   : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL intdelay_reg_rsvd_4              : vector_of_signed18(0 TO 2) := (OTHERS => to_signed(16#00000#, 18));  -- sfix18 [3]
  SIGNAL din_3_1_im_dly                   : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL intdelay_reg_rsvd_5              : std_logic_vector(2 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [3]
  SIGNAL din_3_vld_dly                    : std_logic;
  SIGNAL twdl_3_1_re                      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL twdl_3_1_im                      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dinXTwdl_3_1_vld                 : std_logic;
  SIGNAL rd_3_Addr                        : std_logic_vector(7 DOWNTO 0);  -- ufix8
  SIGNAL rd_3_Enb                         : std_logic;
  SIGNAL proc_3_enb                       : std_logic;
  SIGNAL dout_3_1_re                      : std_logic_vector(18 DOWNTO 0);  -- ufix19
  SIGNAL dout_3_1_im                      : std_logic_vector(18 DOWNTO 0);  -- ufix19
  SIGNAL dout_3_1_vld                     : std_logic;
  SIGNAL dinXTwdl_4_1_vld                 : std_logic;
  SIGNAL rd_4_Addr                        : std_logic_vector(6 DOWNTO 0);  -- ufix7
  SIGNAL rd_4_Enb                         : std_logic;
  SIGNAL proc_4_enb                       : std_logic;
  SIGNAL multiply_4_J                     : std_logic;
  SIGNAL dout_4_1_re                      : std_logic_vector(19 DOWNTO 0);  -- ufix20
  SIGNAL dout_4_1_im                      : std_logic_vector(19 DOWNTO 0);  -- ufix20
  SIGNAL dout_4_1_vld                     : std_logic;
  SIGNAL dout_4_1_re_signed               : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL dout_4_1_im_signed               : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL intdelay_reg_rsvd_6              : vector_of_signed20(0 TO 2) := (OTHERS => to_signed(16#00000#, 20));  -- sfix20 [3]
  SIGNAL din_5_1_re_dly                   : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL intdelay_reg_rsvd_7              : vector_of_signed20(0 TO 2) := (OTHERS => to_signed(16#00000#, 20));  -- sfix20 [3]
  SIGNAL din_5_1_im_dly                   : signed(19 DOWNTO 0);  -- sfix20_En15
  SIGNAL intdelay_reg_rsvd_8              : std_logic_vector(2 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [3]
  SIGNAL din_5_vld_dly                    : std_logic;
  SIGNAL twdl_5_1_re                      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL twdl_5_1_im                      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dinXTwdl_5_1_vld                 : std_logic;
  SIGNAL rd_5_Addr                        : std_logic_vector(5 DOWNTO 0);  -- ufix6
  SIGNAL rd_5_Enb                         : std_logic;
  SIGNAL proc_5_enb                       : std_logic;
  SIGNAL dout_5_1_re                      : std_logic_vector(20 DOWNTO 0);  -- ufix21
  SIGNAL dout_5_1_im                      : std_logic_vector(20 DOWNTO 0);  -- ufix21
  SIGNAL dout_5_1_vld                     : std_logic;
  SIGNAL dinXTwdl_6_1_vld                 : std_logic;
  SIGNAL rd_6_Addr                        : std_logic_vector(4 DOWNTO 0);  -- ufix5
  SIGNAL rd_6_Enb                         : std_logic;
  SIGNAL proc_6_enb                       : std_logic;
  SIGNAL multiply_6_J                     : std_logic;
  SIGNAL dout_6_1_re                      : std_logic_vector(21 DOWNTO 0);  -- ufix22
  SIGNAL dout_6_1_im                      : std_logic_vector(21 DOWNTO 0);  -- ufix22
  SIGNAL dout_6_1_vld                     : std_logic;
  SIGNAL dout_6_1_re_signed               : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL dout_6_1_im_signed               : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL intdelay_reg_rsvd_9              : vector_of_signed22(0 TO 2) := (OTHERS => to_signed(16#000000#, 22));  -- sfix22 [3]
  SIGNAL din_7_1_re_dly                   : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL intdelay_reg_rsvd_10             : vector_of_signed22(0 TO 2) := (OTHERS => to_signed(16#000000#, 22));  -- sfix22 [3]
  SIGNAL din_7_1_im_dly                   : signed(21 DOWNTO 0);  -- sfix22_En15
  SIGNAL intdelay_reg_rsvd_11             : std_logic_vector(2 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [3]
  SIGNAL din_7_vld_dly                    : std_logic;
  SIGNAL twdl_7_1_re                      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL twdl_7_1_im                      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dinXTwdl_7_1_vld                 : std_logic;
  SIGNAL rd_7_Addr                        : std_logic_vector(3 DOWNTO 0);  -- ufix4
  SIGNAL rd_7_Enb                         : std_logic;
  SIGNAL proc_7_enb                       : std_logic;
  SIGNAL dout_7_1_re                      : std_logic_vector(22 DOWNTO 0);  -- ufix23
  SIGNAL dout_7_1_im                      : std_logic_vector(22 DOWNTO 0);  -- ufix23
  SIGNAL dout_7_1_vld                     : std_logic;
  SIGNAL dinXTwdl_8_1_vld                 : std_logic;
  SIGNAL rd_8_Addr                        : std_logic_vector(2 DOWNTO 0);  -- ufix3
  SIGNAL rd_8_Enb                         : std_logic;
  SIGNAL proc_8_enb                       : std_logic;
  SIGNAL multiply_8_J                     : std_logic;
  SIGNAL dout_8_1_re                      : std_logic_vector(23 DOWNTO 0);  -- ufix24
  SIGNAL dout_8_1_im                      : std_logic_vector(23 DOWNTO 0);  -- ufix24
  SIGNAL dout_8_1_vld                     : std_logic;
  SIGNAL dout_8_1_re_signed               : signed(23 DOWNTO 0);  -- sfix24_En15
  SIGNAL dout_8_1_im_signed               : signed(23 DOWNTO 0);  -- sfix24_En15
  SIGNAL intdelay_reg_rsvd_12             : vector_of_signed24(0 TO 2) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24 [3]
  SIGNAL din_9_1_re_dly                   : signed(23 DOWNTO 0);  -- sfix24_En15
  SIGNAL intdelay_reg_rsvd_13             : vector_of_signed24(0 TO 2) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24 [3]
  SIGNAL din_9_1_im_dly                   : signed(23 DOWNTO 0);  -- sfix24_En15
  SIGNAL intdelay_reg_rsvd_14             : std_logic_vector(2 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [3]
  SIGNAL din_9_vld_dly                    : std_logic;
  SIGNAL twdl_9_1_re                      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL twdl_9_1_im                      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dinXTwdl_9_1_vld                 : std_logic;
  SIGNAL rd_9_Addr                        : std_logic_vector(1 DOWNTO 0);  -- ufix2
  SIGNAL rd_9_Enb                         : std_logic;
  SIGNAL proc_9_enb                       : std_logic;
  SIGNAL dout_9_1_re                      : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL dout_9_1_im                      : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL dout_9_1_vld                     : std_logic;
  SIGNAL dinXTwdl_10_1_vld                : std_logic;
  SIGNAL rd_10_Addr                       : std_logic;  -- ufix1
  SIGNAL rd_10_Enb                        : std_logic;
  SIGNAL proc_10_enb                      : std_logic;
  SIGNAL multiply_10_J                    : std_logic;
  SIGNAL dout_10_1_re                     : std_logic_vector(25 DOWNTO 0);  -- ufix26
  SIGNAL dout_10_1_im                     : std_logic_vector(25 DOWNTO 0);  -- ufix26
  SIGNAL dout_10_1_vld                    : std_logic;
  SIGNAL dout_10_1_re_signed              : signed(25 DOWNTO 0);  -- sfix26_En15
  SIGNAL dout_10_1_im_signed              : signed(25 DOWNTO 0);  -- sfix26_En15
  SIGNAL intdelay_reg_rsvd_15             : vector_of_signed26(0 TO 2) := (OTHERS => to_signed(16#0000000#, 26));  -- sfix26 [3]
  SIGNAL din_11_re_dly                    : signed(25 DOWNTO 0);  -- sfix26_En15
  SIGNAL intdelay_reg_rsvd_16             : vector_of_signed26(0 TO 2) := (OTHERS => to_signed(16#0000000#, 26));  -- sfix26 [3]
  SIGNAL din_11_im_dly                    : signed(25 DOWNTO 0);  -- sfix26_En15
  SIGNAL intdelay_reg_rsvd_17             : std_logic_vector(2 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [3]
  SIGNAL din_11_vld_dly                   : std_logic;
  SIGNAL twdl_11_re                       : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL twdl_11_im                       : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL rd_11_Enb                        : std_logic;
  SIGNAL rd_11_Enb_dly                    : std_logic := '0';
  SIGNAL dinXTwdl_11_vld                  : std_logic;
  SIGNAL rd_11_Addr                       : std_logic;
  SIGNAL proc_11_enb                      : std_logic;
  SIGNAL dout_11_re                       : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL dout_11_im                       : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL dout_11_vld                      : std_logic;
  SIGNAL dout_re1                         : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL dout_im1                         : std_logic_vector(26 DOWNTO 0);  -- ufix27
  SIGNAL dout_vld1                        : std_logic;

BEGIN
  UCTRL1_1_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_1
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dinXTwdl_1_1_vld => dinXTwdl_1_1_vld,
              dinXTwdl_1_1_vld_1 => dinXTwdl_1_1_vld,
              syncReset => syncReset,
              rd_1_Addr => rd_1_Addr,  -- ufix10
              rd_1_Enb => rd_1_Enb,
              proc_1_enb => proc_1_enb
              );

  USDF1_1_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_1
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              din_1_1_re_dly => std_logic_vector(din_1_1_re_dly),  -- ufix16
              din_1_1_im_dly => std_logic_vector(din_1_1_im_dly),  -- ufix16
              din_1_vld_dly => din_1_vld_dly,
              rd_1_Addr => rd_1_Addr,  -- ufix10
              rd_1_Enb => rd_1_Enb,
              proc_1_enb => proc_1_enb,
              syncReset => syncReset,
              dout_1_1_re => dout_1_1_re,  -- ufix17
              dout_1_1_im => dout_1_1_im,  -- ufix17
              dout_1_1_vld => dout_1_1_vld,
              dinXTwdl_1_1_vld => dinXTwdl_1_1_vld
              );

  UCTRL2_2_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_2
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_1_1_vld => dout_1_1_vld,
              dinXTwdl_2_1_vld => dinXTwdl_2_1_vld,
              syncReset => syncReset,
              rd_2_Addr => rd_2_Addr,  -- ufix9
              rd_2_Enb => rd_2_Enb,
              proc_2_enb => proc_2_enb,
              multiply_2_J => multiply_2_J
              );

  USDF2_2_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_2
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_1_1_re => dout_1_1_re,  -- ufix17
              dout_1_1_im => dout_1_1_im,  -- ufix17
              dout_1_1_vld => dout_1_1_vld,
              rd_2_Addr => rd_2_Addr,  -- ufix9
              rd_2_Enb => rd_2_Enb,
              proc_2_enb => proc_2_enb,
              multiply_2_J => multiply_2_J,
              syncReset => syncReset,
              dout_2_1_re => dout_2_1_re,  -- ufix18
              dout_2_1_im => dout_2_1_im,  -- ufix18
              dout_2_1_vld => dout_2_1_vld,
              dinXTwdl_2_1_vld => dinXTwdl_2_1_vld
              );

  UtwdlROM_3_1 : ltehdlDownlinkSyncDemod_TWDLROM_3_1
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_2_1_vld => dout_2_1_vld,
              syncReset => syncReset,
              twdl_3_1_re => twdl_3_1_re,  -- ufix16
              twdl_3_1_im => twdl_3_1_im  -- ufix16
              );

  UCTRL1_3_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_3
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dinXTwdl_3_1_vld => dinXTwdl_3_1_vld,
              dinXTwdl_3_1_vld_1 => dinXTwdl_3_1_vld,
              syncReset => syncReset,
              rd_3_Addr => rd_3_Addr,  -- ufix8
              rd_3_Enb => rd_3_Enb,
              proc_3_enb => proc_3_enb
              );

  USDF1_3_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_3
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              din_3_1_re_dly => std_logic_vector(din_3_1_re_dly),  -- ufix18
              din_3_1_im_dly => std_logic_vector(din_3_1_im_dly),  -- ufix18
              din_3_vld_dly => din_3_vld_dly,
              rd_3_Addr => rd_3_Addr,  -- ufix8
              rd_3_Enb => rd_3_Enb,
              twdl_3_1_re => twdl_3_1_re,  -- ufix16
              twdl_3_1_im => twdl_3_1_im,  -- ufix16
              proc_3_enb => proc_3_enb,
              syncReset => syncReset,
              dout_3_1_re => dout_3_1_re,  -- ufix19
              dout_3_1_im => dout_3_1_im,  -- ufix19
              dout_3_1_vld => dout_3_1_vld,
              dinXTwdl_3_1_vld => dinXTwdl_3_1_vld
              );

  UCTRL2_4_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_4
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_3_1_vld => dout_3_1_vld,
              dinXTwdl_4_1_vld => dinXTwdl_4_1_vld,
              syncReset => syncReset,
              rd_4_Addr => rd_4_Addr,  -- ufix7
              rd_4_Enb => rd_4_Enb,
              proc_4_enb => proc_4_enb,
              multiply_4_J => multiply_4_J
              );

  USDF2_4_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_4
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_3_1_re => dout_3_1_re,  -- ufix19
              dout_3_1_im => dout_3_1_im,  -- ufix19
              dout_3_1_vld => dout_3_1_vld,
              rd_4_Addr => rd_4_Addr,  -- ufix7
              rd_4_Enb => rd_4_Enb,
              proc_4_enb => proc_4_enb,
              multiply_4_J => multiply_4_J,
              syncReset => syncReset,
              dout_4_1_re => dout_4_1_re,  -- ufix20
              dout_4_1_im => dout_4_1_im,  -- ufix20
              dout_4_1_vld => dout_4_1_vld,
              dinXTwdl_4_1_vld => dinXTwdl_4_1_vld
              );

  UtwdlROM_5_1 : ltehdlDownlinkSyncDemod_TWDLROM_5_1
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_4_1_vld => dout_4_1_vld,
              syncReset => syncReset,
              twdl_5_1_re => twdl_5_1_re,  -- ufix16
              twdl_5_1_im => twdl_5_1_im  -- ufix16
              );

  UCTRL1_5_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_5
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dinXTwdl_5_1_vld => dinXTwdl_5_1_vld,
              dinXTwdl_5_1_vld_1 => dinXTwdl_5_1_vld,
              syncReset => syncReset,
              rd_5_Addr => rd_5_Addr,  -- ufix6
              rd_5_Enb => rd_5_Enb,
              proc_5_enb => proc_5_enb
              );

  USDF1_5_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_5
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              din_5_1_re_dly => std_logic_vector(din_5_1_re_dly),  -- ufix20
              din_5_1_im_dly => std_logic_vector(din_5_1_im_dly),  -- ufix20
              din_5_vld_dly => din_5_vld_dly,
              rd_5_Addr => rd_5_Addr,  -- ufix6
              rd_5_Enb => rd_5_Enb,
              twdl_5_1_re => twdl_5_1_re,  -- ufix16
              twdl_5_1_im => twdl_5_1_im,  -- ufix16
              proc_5_enb => proc_5_enb,
              syncReset => syncReset,
              dout_5_1_re => dout_5_1_re,  -- ufix21
              dout_5_1_im => dout_5_1_im,  -- ufix21
              dout_5_1_vld => dout_5_1_vld,
              dinXTwdl_5_1_vld => dinXTwdl_5_1_vld
              );

  UCTRL2_6_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_6
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_5_1_vld => dout_5_1_vld,
              dinXTwdl_6_1_vld => dinXTwdl_6_1_vld,
              syncReset => syncReset,
              rd_6_Addr => rd_6_Addr,  -- ufix5
              rd_6_Enb => rd_6_Enb,
              proc_6_enb => proc_6_enb,
              multiply_6_J => multiply_6_J
              );

  USDF2_6_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_6
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_5_1_re => dout_5_1_re,  -- ufix21
              dout_5_1_im => dout_5_1_im,  -- ufix21
              dout_5_1_vld => dout_5_1_vld,
              rd_6_Addr => rd_6_Addr,  -- ufix5
              rd_6_Enb => rd_6_Enb,
              proc_6_enb => proc_6_enb,
              multiply_6_J => multiply_6_J,
              syncReset => syncReset,
              dout_6_1_re => dout_6_1_re,  -- ufix22
              dout_6_1_im => dout_6_1_im,  -- ufix22
              dout_6_1_vld => dout_6_1_vld,
              dinXTwdl_6_1_vld => dinXTwdl_6_1_vld
              );

  UtwdlROM_7_1 : ltehdlDownlinkSyncDemod_TWDLROM_7_1
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_6_1_vld => dout_6_1_vld,
              syncReset => syncReset,
              twdl_7_1_re => twdl_7_1_re,  -- ufix16
              twdl_7_1_im => twdl_7_1_im  -- ufix16
              );

  UCTRL1_7_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_7
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dinXTwdl_7_1_vld => dinXTwdl_7_1_vld,
              dinXTwdl_7_1_vld_1 => dinXTwdl_7_1_vld,
              syncReset => syncReset,
              rd_7_Addr => rd_7_Addr,  -- ufix4
              rd_7_Enb => rd_7_Enb,
              proc_7_enb => proc_7_enb
              );

  USDF1_7_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_7
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              din_7_1_re_dly => std_logic_vector(din_7_1_re_dly),  -- ufix22
              din_7_1_im_dly => std_logic_vector(din_7_1_im_dly),  -- ufix22
              din_7_vld_dly => din_7_vld_dly,
              rd_7_Addr => rd_7_Addr,  -- ufix4
              rd_7_Enb => rd_7_Enb,
              twdl_7_1_re => twdl_7_1_re,  -- ufix16
              twdl_7_1_im => twdl_7_1_im,  -- ufix16
              proc_7_enb => proc_7_enb,
              syncReset => syncReset,
              dout_7_1_re => dout_7_1_re,  -- ufix23
              dout_7_1_im => dout_7_1_im,  -- ufix23
              dout_7_1_vld => dout_7_1_vld,
              dinXTwdl_7_1_vld => dinXTwdl_7_1_vld
              );

  UCTRL2_8_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_8
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_7_1_vld => dout_7_1_vld,
              dinXTwdl_8_1_vld => dinXTwdl_8_1_vld,
              syncReset => syncReset,
              rd_8_Addr => rd_8_Addr,  -- ufix3
              rd_8_Enb => rd_8_Enb,
              proc_8_enb => proc_8_enb,
              multiply_8_J => multiply_8_J
              );

  USDF2_8_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_8
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_7_1_re => dout_7_1_re,  -- ufix23
              dout_7_1_im => dout_7_1_im,  -- ufix23
              dout_7_1_vld => dout_7_1_vld,
              rd_8_Addr => rd_8_Addr,  -- ufix3
              rd_8_Enb => rd_8_Enb,
              proc_8_enb => proc_8_enb,
              multiply_8_J => multiply_8_J,
              syncReset => syncReset,
              dout_8_1_re => dout_8_1_re,  -- ufix24
              dout_8_1_im => dout_8_1_im,  -- ufix24
              dout_8_1_vld => dout_8_1_vld,
              dinXTwdl_8_1_vld => dinXTwdl_8_1_vld
              );

  UtwdlROM_9_1 : ltehdlDownlinkSyncDemod_TWDLROM_9_1
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_8_1_vld => dout_8_1_vld,
              syncReset => syncReset,
              twdl_9_1_re => twdl_9_1_re,  -- ufix16
              twdl_9_1_im => twdl_9_1_im  -- ufix16
              );

  UCTRL1_9_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_9
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dinXTwdl_9_1_vld => dinXTwdl_9_1_vld,
              dinXTwdl_9_1_vld_1 => dinXTwdl_9_1_vld,
              syncReset => syncReset,
              rd_9_Addr => rd_9_Addr,  -- ufix2
              rd_9_Enb => rd_9_Enb,
              proc_9_enb => proc_9_enb
              );

  USDF1_9_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_9
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              din_9_1_re_dly => std_logic_vector(din_9_1_re_dly),  -- ufix24
              din_9_1_im_dly => std_logic_vector(din_9_1_im_dly),  -- ufix24
              din_9_vld_dly => din_9_vld_dly,
              rd_9_Addr => rd_9_Addr,  -- ufix2
              rd_9_Enb => rd_9_Enb,
              twdl_9_1_re => twdl_9_1_re,  -- ufix16
              twdl_9_1_im => twdl_9_1_im,  -- ufix16
              proc_9_enb => proc_9_enb,
              syncReset => syncReset,
              dout_9_1_re => dout_9_1_re,  -- ufix25
              dout_9_1_im => dout_9_1_im,  -- ufix25
              dout_9_1_vld => dout_9_1_vld,
              dinXTwdl_9_1_vld => dinXTwdl_9_1_vld
              );

  UCTRL2_10_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_10
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_9_1_vld => dout_9_1_vld,
              dinXTwdl_10_1_vld => dinXTwdl_10_1_vld,
              syncReset => syncReset,
              rd_10_Addr => rd_10_Addr,  -- ufix1
              rd_10_Enb => rd_10_Enb,
              proc_10_enb => proc_10_enb,
              multiply_10_J => multiply_10_J
              );

  USDF2_10_1 : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF2_10
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_9_1_re => dout_9_1_re,  -- ufix25
              dout_9_1_im => dout_9_1_im,  -- ufix25
              dout_9_1_vld => dout_9_1_vld,
              rd_10_Addr => rd_10_Addr,  -- ufix1
              rd_10_Enb => rd_10_Enb,
              proc_10_enb => proc_10_enb,
              multiply_10_J => multiply_10_J,
              syncReset => syncReset,
              dout_10_1_re => dout_10_1_re,  -- ufix26
              dout_10_1_im => dout_10_1_im,  -- ufix26
              dout_10_1_vld => dout_10_1_vld,
              dinXTwdl_10_1_vld => dinXTwdl_10_1_vld
              );

  UtwdlROM_11 : ltehdlDownlinkSyncDemod_TWDLROM_11_1
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_10_1_vld => dout_10_1_vld,
              syncReset => syncReset,
              twdl_11_re => twdl_11_re,  -- ufix16
              twdl_11_im => twdl_11_im  -- ufix16
              );

  UCTRLRX2 : ltehdlDownlinkSyncDemod_RADIX22FFT_CTRL1_1_block
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dinXTwdl_11_vld => dinXTwdl_11_vld,
              dinXTwdl_11_vld_1 => dinXTwdl_11_vld,
              syncReset => syncReset,
              rd_11_Addr => rd_11_Addr,
              rd_11_Enb => rd_11_Enb,
              proc_11_enb => proc_11_enb
              );

  URADIX2 : ltehdlDownlinkSyncDemod_RADIX22FFT_SDF1_11
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              din_11_re_dly => std_logic_vector(din_11_re_dly),  -- ufix26
              din_11_im_dly => std_logic_vector(din_11_im_dly),  -- ufix26
              din_11_vld_dly => din_11_vld_dly,
              rd_11_Addr => rd_11_Addr,
              rd_11_Enb_dly => rd_11_Enb_dly,
              twdl_11_re => twdl_11_re,  -- ufix16
              twdl_11_im => twdl_11_im,  -- ufix16
              proc_11_enb => proc_11_enb,
              syncReset => syncReset,
              dout_11_re => dout_11_re,  -- ufix27
              dout_11_im => dout_11_im,  -- ufix27
              dout_11_vld => dout_11_vld,
              dinXTwdl_11_vld => dinXTwdl_11_vld
              );

  UNaturalOrder_Stage : ltehdlDownlinkSyncDemod_RADIX2FFT_bitNatural
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              dout_11_re => dout_11_re,  -- ufix27
              dout_11_im => dout_11_im,  -- ufix27
              dout_11_vld => dout_11_vld,
              syncReset => syncReset,
              dout_re1 => dout_re1,  -- ufix27
              dout_im1 => dout_im1,  -- ufix27
              dout_vld1 => dout_vld1
              );

  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  intdelay_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd <= (OTHERS => to_signed(16#0000#, 16));
        ELSE 
          intdelay_reg_rsvd(0) <= dataIn_re_signed;
          intdelay_reg_rsvd(1 TO 2) <= intdelay_reg_rsvd(0 TO 1);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_process;

  din_1_1_re_dly <= intdelay_reg_rsvd(2);

  intdelay_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_1 <= (OTHERS => to_signed(16#0000#, 16));
        ELSE 
          intdelay_reg_rsvd_1(0) <= dataIn_im_signed;
          intdelay_reg_rsvd_1(1 TO 2) <= intdelay_reg_rsvd_1(0 TO 1);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_1_process;

  din_1_1_im_dly <= intdelay_reg_rsvd_1(2);

  intdelay_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_2 <= (OTHERS => '0');
        ELSE 
          intdelay_reg_rsvd_2(0) <= validIn;
          intdelay_reg_rsvd_2(2 DOWNTO 1) <= intdelay_reg_rsvd_2(1 DOWNTO 0);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_2_process;

  din_1_vld_dly <= intdelay_reg_rsvd_2(2);

  dout_2_1_re_signed <= signed(dout_2_1_re);

  dout_2_1_im_signed <= signed(dout_2_1_im);

  intdelay_3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_3 <= (OTHERS => to_signed(16#00000#, 18));
        ELSE 
          intdelay_reg_rsvd_3(0) <= dout_2_1_re_signed;
          intdelay_reg_rsvd_3(1 TO 2) <= intdelay_reg_rsvd_3(0 TO 1);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_3_process;

  din_3_1_re_dly <= intdelay_reg_rsvd_3(2);

  intdelay_4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_4 <= (OTHERS => to_signed(16#00000#, 18));
        ELSE 
          intdelay_reg_rsvd_4(0) <= dout_2_1_im_signed;
          intdelay_reg_rsvd_4(1 TO 2) <= intdelay_reg_rsvd_4(0 TO 1);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_4_process;

  din_3_1_im_dly <= intdelay_reg_rsvd_4(2);

  intdelay_5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_5 <= (OTHERS => '0');
        ELSE 
          intdelay_reg_rsvd_5(0) <= dout_2_1_vld;
          intdelay_reg_rsvd_5(2 DOWNTO 1) <= intdelay_reg_rsvd_5(1 DOWNTO 0);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_5_process;

  din_3_vld_dly <= intdelay_reg_rsvd_5(2);

  dout_4_1_re_signed <= signed(dout_4_1_re);

  dout_4_1_im_signed <= signed(dout_4_1_im);

  intdelay_6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_6 <= (OTHERS => to_signed(16#00000#, 20));
        ELSE 
          intdelay_reg_rsvd_6(0) <= dout_4_1_re_signed;
          intdelay_reg_rsvd_6(1 TO 2) <= intdelay_reg_rsvd_6(0 TO 1);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_6_process;

  din_5_1_re_dly <= intdelay_reg_rsvd_6(2);

  intdelay_7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_7 <= (OTHERS => to_signed(16#00000#, 20));
        ELSE 
          intdelay_reg_rsvd_7(0) <= dout_4_1_im_signed;
          intdelay_reg_rsvd_7(1 TO 2) <= intdelay_reg_rsvd_7(0 TO 1);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_7_process;

  din_5_1_im_dly <= intdelay_reg_rsvd_7(2);

  intdelay_8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_8 <= (OTHERS => '0');
        ELSE 
          intdelay_reg_rsvd_8(0) <= dout_4_1_vld;
          intdelay_reg_rsvd_8(2 DOWNTO 1) <= intdelay_reg_rsvd_8(1 DOWNTO 0);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_8_process;

  din_5_vld_dly <= intdelay_reg_rsvd_8(2);

  dout_6_1_re_signed <= signed(dout_6_1_re);

  dout_6_1_im_signed <= signed(dout_6_1_im);

  intdelay_9_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_9 <= (OTHERS => to_signed(16#000000#, 22));
        ELSE 
          intdelay_reg_rsvd_9(0) <= dout_6_1_re_signed;
          intdelay_reg_rsvd_9(1 TO 2) <= intdelay_reg_rsvd_9(0 TO 1);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_9_process;

  din_7_1_re_dly <= intdelay_reg_rsvd_9(2);

  intdelay_10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_10 <= (OTHERS => to_signed(16#000000#, 22));
        ELSE 
          intdelay_reg_rsvd_10(0) <= dout_6_1_im_signed;
          intdelay_reg_rsvd_10(1 TO 2) <= intdelay_reg_rsvd_10(0 TO 1);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_10_process;

  din_7_1_im_dly <= intdelay_reg_rsvd_10(2);

  intdelay_11_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_11 <= (OTHERS => '0');
        ELSE 
          intdelay_reg_rsvd_11(0) <= dout_6_1_vld;
          intdelay_reg_rsvd_11(2 DOWNTO 1) <= intdelay_reg_rsvd_11(1 DOWNTO 0);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_11_process;

  din_7_vld_dly <= intdelay_reg_rsvd_11(2);

  dout_8_1_re_signed <= signed(dout_8_1_re);

  dout_8_1_im_signed <= signed(dout_8_1_im);

  intdelay_12_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_12 <= (OTHERS => to_signed(16#000000#, 24));
        ELSE 
          intdelay_reg_rsvd_12(0) <= dout_8_1_re_signed;
          intdelay_reg_rsvd_12(1 TO 2) <= intdelay_reg_rsvd_12(0 TO 1);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_12_process;

  din_9_1_re_dly <= intdelay_reg_rsvd_12(2);

  intdelay_13_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_13 <= (OTHERS => to_signed(16#000000#, 24));
        ELSE 
          intdelay_reg_rsvd_13(0) <= dout_8_1_im_signed;
          intdelay_reg_rsvd_13(1 TO 2) <= intdelay_reg_rsvd_13(0 TO 1);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_13_process;

  din_9_1_im_dly <= intdelay_reg_rsvd_13(2);

  intdelay_14_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_14 <= (OTHERS => '0');
        ELSE 
          intdelay_reg_rsvd_14(0) <= dout_8_1_vld;
          intdelay_reg_rsvd_14(2 DOWNTO 1) <= intdelay_reg_rsvd_14(1 DOWNTO 0);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_14_process;

  din_9_vld_dly <= intdelay_reg_rsvd_14(2);

  dout_10_1_re_signed <= signed(dout_10_1_re);

  dout_10_1_im_signed <= signed(dout_10_1_im);

  intdelay_15_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_15 <= (OTHERS => to_signed(16#0000000#, 26));
        ELSE 
          intdelay_reg_rsvd_15(0) <= dout_10_1_re_signed;
          intdelay_reg_rsvd_15(1 TO 2) <= intdelay_reg_rsvd_15(0 TO 1);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_15_process;

  din_11_re_dly <= intdelay_reg_rsvd_15(2);

  intdelay_16_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_16 <= (OTHERS => to_signed(16#0000000#, 26));
        ELSE 
          intdelay_reg_rsvd_16(0) <= dout_10_1_im_signed;
          intdelay_reg_rsvd_16(1 TO 2) <= intdelay_reg_rsvd_16(0 TO 1);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_16_process;

  din_11_im_dly <= intdelay_reg_rsvd_16(2);

  intdelay_17_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_17 <= (OTHERS => '0');
        ELSE 
          intdelay_reg_rsvd_17(0) <= dout_10_1_vld;
          intdelay_reg_rsvd_17(2 DOWNTO 1) <= intdelay_reg_rsvd_17(1 DOWNTO 0);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_17_process;

  din_11_vld_dly <= intdelay_reg_rsvd_17(2);

  intdelay_18_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        IF syncReset = '1' THEN
          rd_11_Enb_dly <= '0';
        ELSE 
          rd_11_Enb_dly <= rd_11_Enb;
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_18_process;


  dataOut_re <= dout_re1;

  dataOut_im <= dout_im1;

  validOut <= dout_vld1;

END rtl;

