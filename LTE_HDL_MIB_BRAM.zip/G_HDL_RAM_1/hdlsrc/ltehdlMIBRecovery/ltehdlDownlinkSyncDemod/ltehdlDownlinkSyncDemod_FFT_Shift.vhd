-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_FFT_Shift IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        reset                             :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataOut_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_FFT_Shift;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_FFT_Shift IS

  -- Signals
  SIGNAL counter_ctrl_const_out           : std_logic;
  SIGNAL counter_ctrl_delay_out           : std_logic := '0';
  SIGNAL counter_out1                     : std_logic;  -- ufix1
  SIGNAL count                            : std_logic;  -- ufix1
  SIGNAL need_to_wrap                     : std_logic;
  SIGNAL count_value                      : std_logic;  -- ufix1
  SIGNAL count_1                          : std_logic;  -- ufix1
  SIGNAL count_2                          : std_logic;  -- ufix1
  SIGNAL counter_out                      : std_logic := '0';  -- ufix1
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Gain_cast                        : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL Gain_cast_1                      : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL Gain_cast_2                      : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL Gain_cast_3                      : signed(17 DOWNTO 0);  -- sfix18_En15
  SIGNAL Gain_out1_re                     : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Gain_out1_im                     : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Switch_out1_re                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Switch_out1_im                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay_out1_re                    : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay_out1_im                    : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay1_out1                      : std_logic := '0';

BEGIN
  -- Output toggles between 
  -- zero and one 

  counter_ctrl_const_out <= '1';

  counter_ctrl_delay_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        counter_ctrl_delay_out <= counter_ctrl_const_out;
      END IF;
    END IF;
  END PROCESS counter_ctrl_delay_process;


  -- Count limited, Unsigned Counter
  --  initial value   = 1
  --  step value      = -1
  --  count to value  = 0
  count <= counter_out1 XOR '1';

  
  need_to_wrap <= '1' WHEN counter_out1 = '0' ELSE
      '0';

  
  count_value <= count WHEN need_to_wrap = '0' ELSE
      '1';

  
  count_1 <= counter_out1 WHEN validIn = '0' ELSE
      count_value;

  
  count_2 <= count_1 WHEN reset = '0' ELSE
      '1';

  counter_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        counter_out <= count_2;
      END IF;
    END IF;
  END PROCESS counter_process;


  
  counter_out1 <= '1' WHEN counter_ctrl_delay_out = '0' ELSE
      counter_out;

  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Gain_cast <=  - (resize(dataIn_re_signed, 17));
  Gain_cast_1 <= resize(Gain_cast, 18);
  Gain_out1_re <= Gain_cast_1(15 DOWNTO 0);
  Gain_cast_2 <=  - (resize(dataIn_im_signed, 17));
  Gain_cast_3 <= resize(Gain_cast_2, 18);
  Gain_out1_im <= Gain_cast_3(15 DOWNTO 0);

  
  Switch_out1_re <= Gain_out1_re WHEN counter_out1 = '0' ELSE
      dataIn_re_signed;
  
  Switch_out1_im <= Gain_out1_im WHEN counter_out1 = '0' ELSE
      dataIn_im_signed;

  Delay_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay_out1_re <= Switch_out1_re;
        Delay_out1_im <= Switch_out1_im;
      END IF;
    END IF;
  END PROCESS Delay_rsvd_process;


  dataOut_re <= std_logic_vector(Delay_out1_re);

  dataOut_im <= std_logic_vector(Delay_out1_im);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_out1 <= validIn;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  validOut <= Delay1_out1;

END rtl;

