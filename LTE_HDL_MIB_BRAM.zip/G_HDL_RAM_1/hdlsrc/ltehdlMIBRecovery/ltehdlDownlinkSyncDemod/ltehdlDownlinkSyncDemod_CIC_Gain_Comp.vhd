-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_CIC_Gain_Comp IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(27 DOWNTO 0);  -- sfix28_En15
        dataIn_im                         :   IN    std_logic_vector(27 DOWNTO 0);  -- sfix28_En15
        validIn                           :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataOut_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_CIC_Gain_Comp;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_CIC_Gain_Comp IS

  -- Signals
  SIGNAL dataIn_re_signed                 : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL dataIn_im_signed                 : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL Data_Type_Conversion1_out1_re    : signed(27 DOWNTO 0);  -- sfix28_En27
  SIGNAL Data_Type_Conversion1_out1_im    : signed(27 DOWNTO 0);  -- sfix28_En27
  SIGNAL Data_Type_Conversion2_out1_re    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Data_Type_Conversion2_out1_im    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay2_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay2_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay1_out1                      : std_logic := '0';

BEGIN
  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Data_Type_Conversion1_out1_re <= dataIn_re_signed;
  Data_Type_Conversion1_out1_im <= dataIn_im_signed;

  
  Data_Type_Conversion2_out1_re <= X"7FFF" WHEN (Data_Type_Conversion1_out1_re(27) = '0') AND (Data_Type_Conversion1_out1_re(26 DOWNTO 12) = "111111111111111") ELSE
      Data_Type_Conversion1_out1_re(27 DOWNTO 12) + ('0' & (Data_Type_Conversion1_out1_re(11) AND (( NOT Data_Type_Conversion1_out1_re(27)) OR (Data_Type_Conversion1_out1_re(10) OR Data_Type_Conversion1_out1_re(9) OR Data_Type_Conversion1_out1_re(8) 
        OR Data_Type_Conversion1_out1_re(7) OR Data_Type_Conversion1_out1_re(6) OR Data_Type_Conversion1_out1_re(5) OR Data_Type_Conversion1_out1_re(4) OR Data_Type_Conversion1_out1_re(3) OR Data_Type_Conversion1_out1_re(2) OR 
        Data_Type_Conversion1_out1_re(1) OR Data_Type_Conversion1_out1_re(0)))));
  
  Data_Type_Conversion2_out1_im <= X"7FFF" WHEN (Data_Type_Conversion1_out1_im(27) = '0') AND (Data_Type_Conversion1_out1_im(26 DOWNTO 12) = "111111111111111") ELSE
      Data_Type_Conversion1_out1_im(27 DOWNTO 12) + ('0' & (Data_Type_Conversion1_out1_im(11) AND (( NOT Data_Type_Conversion1_out1_im(27)) OR (Data_Type_Conversion1_out1_im(10) OR Data_Type_Conversion1_out1_im(9) OR Data_Type_Conversion1_out1_im(8) 
        OR Data_Type_Conversion1_out1_im(7) OR Data_Type_Conversion1_out1_im(6) OR Data_Type_Conversion1_out1_im(5) OR Data_Type_Conversion1_out1_im(4) OR Data_Type_Conversion1_out1_im(3) OR Data_Type_Conversion1_out1_im(2) OR 
        Data_Type_Conversion1_out1_im(1) OR Data_Type_Conversion1_out1_im(0)))));

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_out1_re <= Data_Type_Conversion2_out1_re;
        Delay2_out1_im <= Data_Type_Conversion2_out1_im;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  dataOut_re <= std_logic_vector(Delay2_out1_re);

  dataOut_im <= std_logic_vector(Delay2_out1_im);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1 <= validIn;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  validOut <= Delay1_out1;

END rtl;

