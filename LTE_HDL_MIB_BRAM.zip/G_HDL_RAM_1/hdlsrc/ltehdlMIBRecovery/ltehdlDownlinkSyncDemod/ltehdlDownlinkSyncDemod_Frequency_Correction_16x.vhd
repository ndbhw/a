-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_Frequency_Correction_16x IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        freq                              :   IN    std_logic_vector(13 DOWNTO 0);  -- sfix14
        validIn                           :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataOut_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Frequency_Correction_16x;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Frequency_Correction_16x IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_NCO_HDL_Optimized1
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          inc                             :   IN    std_logic_vector(13 DOWNTO 0);  -- ufix14
          validIn                         :   IN    std_logic;
          complexexp_re                   :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          complexexp_im                   :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_NCO_HDL_Optimized1
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_NCO_HDL_Optimized1(rtl);

  -- Signals
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay8_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay8_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay10_reg_re                   : vector_of_signed16(0 TO 5) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16_En15 [6]
  SIGNAL Delay10_reg_im                   : vector_of_signed16(0 TO 5) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16_En15 [6]
  SIGNAL Delay10_out1_re                  : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay10_out1_im                  : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay7_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay7_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay2_reg_re                    : vector_of_signed16(0 TO 1) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16_En15 [2]
  SIGNAL Delay2_reg_im                    : vector_of_signed16(0 TO 1) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16_En15 [2]
  SIGNAL Delay2_out1_re                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay2_out1_im                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL freq_signed                      : signed(13 DOWNTO 0);  -- sfix14
  SIGNAL inc3                             : signed(13 DOWNTO 0) := to_signed(16#0000#, 14);  -- sfix14
  SIGNAL Delay12_out1                     : std_logic := '0';
  SIGNAL expData16x_re                    : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL expData16x_im                    : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL expValid16x                      : std_logic;
  SIGNAL expData16x_re_signed             : signed(15 DOWNTO 0);  -- sfix16_En14
  SIGNAL expData16x_im_signed             : signed(15 DOWNTO 0);  -- sfix16_En14
  SIGNAL Delay13_out1_re                  : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En14
  SIGNAL Delay13_out1_im                  : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En14
  SIGNAL conj_cast                        : signed(16 DOWNTO 0);  -- sfix17_En14
  SIGNAL complexConjugate_out1_re         : signed(15 DOWNTO 0);  -- sfix16_En14
  SIGNAL complexConjugate_out1_im         : signed(15 DOWNTO 0);  -- sfix16_En14
  SIGNAL Delay3_reg_re                    : vector_of_signed16(0 TO 1) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16_En14 [2]
  SIGNAL Delay3_reg_im                    : vector_of_signed16(0 TO 1) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16_En14 [2]
  SIGNAL Delay3_out1_re                   : signed(15 DOWNTO 0);  -- sfix16_En14
  SIGNAL Delay3_out1_im                   : signed(15 DOWNTO 0);  -- sfix16_En14
  SIGNAL Product1_out1_re                 : signed(31 DOWNTO 0);  -- sfix32_En29
  SIGNAL Product1_out1_im                 : signed(31 DOWNTO 0);  -- sfix32_En29
  SIGNAL Delay4_reg_re                    : vector_of_signed32(0 TO 1) := (OTHERS => to_signed(0, 32));  -- sfix32_En29 [2]
  SIGNAL Delay4_reg_im                    : vector_of_signed32(0 TO 1) := (OTHERS => to_signed(0, 32));  -- sfix32_En29 [2]
  SIGNAL Delay4_out1_re                   : signed(31 DOWNTO 0);  -- sfix32_En29
  SIGNAL Delay4_out1_im                   : signed(31 DOWNTO 0);  -- sfix32_En29
  SIGNAL Data_Type_Conversion_out1_re     : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Data_Type_Conversion_out1_im     : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay1_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay1_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay14_out1                     : std_logic := '0';
  SIGNAL Delay15_reg_rsvd                 : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [2]
  SIGNAL Delay15_out1                     : std_logic;
  SIGNAL Delay16_reg_rsvd                 : std_logic_vector(1 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [2]
  SIGNAL Delay16_out1                     : std_logic;
  SIGNAL Delay17_out1                     : std_logic := '0';

BEGIN
  -- reinterpret as
  -- 14 bit signed int
  -- This subsystem corrects the frequency offset using an Numerically Controller Oscillator (NCO) and a conjugate multiplication.

  UNCO_HDL_Optimized1 : ltehdlDownlinkSyncDemod_NCO_HDL_Optimized1
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb_1_2_0 => enb_1_2_0,
              inc => std_logic_vector(inc3),  -- ufix14
              validIn => Delay12_out1,
              complexexp_re => expData16x_re,  -- ufix16
              complexexp_im => expData16x_im,  -- ufix16
              validOut => expValid16x
              );

  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Delay8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay8_out1_re <= dataIn_re_signed;
        Delay8_out1_im <= dataIn_im_signed;
      END IF;
    END IF;
  END PROCESS Delay8_process;


  Delay10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay10_reg_im(0) <= Delay8_out1_im;
        Delay10_reg_im(1 TO 5) <= Delay10_reg_im(0 TO 4);
        Delay10_reg_re(0) <= Delay8_out1_re;
        Delay10_reg_re(1 TO 5) <= Delay10_reg_re(0 TO 4);
      END IF;
    END IF;
  END PROCESS Delay10_process;

  Delay10_out1_re <= Delay10_reg_re(5);
  Delay10_out1_im <= Delay10_reg_im(5);

  Delay7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay7_out1_re <= Delay10_out1_re;
        Delay7_out1_im <= Delay10_out1_im;
      END IF;
    END IF;
  END PROCESS Delay7_process;


  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay2_reg_im(0) <= Delay7_out1_im;
        Delay2_reg_im(1) <= Delay2_reg_im(0);
        Delay2_reg_re(0) <= Delay7_out1_re;
        Delay2_reg_re(1) <= Delay2_reg_re(0);
      END IF;
    END IF;
  END PROCESS Delay2_process;

  Delay2_out1_re <= Delay2_reg_re(1);
  Delay2_out1_im <= Delay2_reg_im(1);

  freq_signed <= signed(freq);

  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        inc3 <= freq_signed;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  Delay12_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay12_out1 <= validIn;
      END IF;
    END IF;
  END PROCESS Delay12_process;


  expData16x_re_signed <= signed(expData16x_re);

  expData16x_im_signed <= signed(expData16x_im);

  Delay13_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay13_out1_re <= expData16x_re_signed;
        Delay13_out1_im <= expData16x_im_signed;
      END IF;
    END IF;
  END PROCESS Delay13_process;


  complexConjugate_out1_re <= Delay13_out1_re;
  conj_cast <=  - (resize(Delay13_out1_im, 17));
  
  complexConjugate_out1_im <= X"7FFF" WHEN (conj_cast(16) = '0') AND (conj_cast(15) /= '0') ELSE
      X"8000" WHEN (conj_cast(16) = '1') AND (conj_cast(15) /= '1') ELSE
      conj_cast(15 DOWNTO 0);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay3_reg_im(0) <= complexConjugate_out1_im;
        Delay3_reg_im(1) <= Delay3_reg_im(0);
        Delay3_reg_re(0) <= complexConjugate_out1_re;
        Delay3_reg_re(1) <= Delay3_reg_re(0);
      END IF;
    END IF;
  END PROCESS Delay3_process;

  Delay3_out1_re <= Delay3_reg_re(1);
  Delay3_out1_im <= Delay3_reg_im(1);

  Product1_out1_re <= (Delay2_out1_re * Delay3_out1_re) - (Delay2_out1_im * Delay3_out1_im);
  Product1_out1_im <= (Delay2_out1_im * Delay3_out1_re) + (Delay2_out1_re * Delay3_out1_im);

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay4_reg_im(0) <= Product1_out1_im;
        Delay4_reg_im(1) <= Delay4_reg_im(0);
        Delay4_reg_re(0) <= Product1_out1_re;
        Delay4_reg_re(1) <= Delay4_reg_re(0);
      END IF;
    END IF;
  END PROCESS Delay4_process;

  Delay4_out1_re <= Delay4_reg_re(1);
  Delay4_out1_im <= Delay4_reg_im(1);

  Data_Type_Conversion_out1_re <= Delay4_out1_re(29 DOWNTO 14) + ('0' & Delay4_out1_re(13));
  Data_Type_Conversion_out1_im <= Delay4_out1_im(29 DOWNTO 14) + ('0' & Delay4_out1_im(13));

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay1_out1_re <= Data_Type_Conversion_out1_re;
        Delay1_out1_im <= Data_Type_Conversion_out1_im;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  dataOut_re <= std_logic_vector(Delay1_out1_re);

  dataOut_im <= std_logic_vector(Delay1_out1_im);

  Delay14_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay14_out1 <= expValid16x;
      END IF;
    END IF;
  END PROCESS Delay14_process;


  Delay15_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay15_reg_rsvd(0) <= Delay14_out1;
        Delay15_reg_rsvd(1) <= Delay15_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay15_process;

  Delay15_out1 <= Delay15_reg_rsvd(1);

  Delay16_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay16_reg_rsvd(0) <= Delay15_out1;
        Delay16_reg_rsvd(1) <= Delay16_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay16_process;

  Delay16_out1 <= Delay16_reg_rsvd(1);

  Delay17_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay17_out1 <= Delay16_out1;
      END IF;
    END IF;
  END PROCESS Delay17_process;


  validOut <= Delay17_out1;

END rtl;

