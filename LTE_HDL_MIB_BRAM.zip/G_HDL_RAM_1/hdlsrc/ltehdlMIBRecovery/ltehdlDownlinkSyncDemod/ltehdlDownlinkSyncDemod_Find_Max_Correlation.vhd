-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_Find_Max_Correlation IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        reset                             :   IN    std_logic;
        correlation                       :   IN    std_logic_vector(35 DOWNTO 0);  -- ufix36
        thresholdExceeded                 :   IN    std_logic;
        validIn                           :   IN    std_logic;
        seqNum                            :   IN    std_logic_vector(9 DOWNTO 0);  -- ufix10
        duplexMode                        :   IN    std_logic;  -- ufix1
        winningSeqNum                     :   OUT   std_logic_vector(9 DOWNTO 0);  -- ufix10
        TDD                               :   OUT   std_logic;
        success                           :   OUT   std_logic;
        duplexModeDone                    :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Find_Max_Correlation;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Find_Max_Correlation IS

  -- Functions
  -- HDLCODER_TO_STDLOGIC 
  FUNCTION hdlcoder_to_stdlogic(arg: boolean) RETURN std_logic IS
  BEGIN
    IF arg THEN
      RETURN '1';
    ELSE
      RETURN '0';
    END IF;
  END FUNCTION;


  -- Signals
  SIGNAL correlation_signed               : signed(35 DOWNTO 0);  -- sfix36_En26
  SIGNAL seqNum_unsigned                  : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL maxCorrelation                   : signed(35 DOWNTO 0);  -- sfix36_En26
  SIGNAL winningSeqNum_tmp                : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL reg_maxCorrelation               : signed(35 DOWNTO 0);  -- sfix36_En26
  SIGNAL reg_winningSeqNum                : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL reg_success                      : std_logic;
  SIGNAL reg_duplexMode                   : std_logic;  -- ufix1
  SIGNAL reg_duplexModeDone               : std_logic;
  SIGNAL reg_maxCorrelation_next          : signed(35 DOWNTO 0);  -- sfix36_En26
  SIGNAL reg_winningSeqNum_next           : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL reg_success_next                 : std_logic;
  SIGNAL reg_duplexMode_next              : std_logic;  -- ufix1
  SIGNAL reg_duplexModeDone_next          : std_logic;

BEGIN
  correlation_signed <= signed(correlation);

  seqNum_unsigned <= unsigned(seqNum);

  Find_Max_Correlation_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        reg_maxCorrelation <= to_signed(0, 36);
        reg_winningSeqNum <= to_unsigned(16#000#, 10);
        reg_success <= '0';
        reg_duplexMode <= '0';
        reg_duplexModeDone <= '0';
      ELSIF enb = '1' THEN
        reg_maxCorrelation <= reg_maxCorrelation_next;
        reg_winningSeqNum <= reg_winningSeqNum_next;
        reg_success <= reg_success_next;
        reg_duplexMode <= reg_duplexMode_next;
        reg_duplexModeDone <= reg_duplexModeDone_next;
      END IF;
    END IF;
  END PROCESS Find_Max_Correlation_process;

  Find_Max_Correlation_output : PROCESS (correlation_signed, duplexMode, reg_duplexMode, reg_duplexModeDone,
       reg_maxCorrelation, reg_success, reg_winningSeqNum, reset,
       seqNum_unsigned, thresholdExceeded, validIn)
    VARIABLE next_duplexModeDone : std_logic;
  BEGIN
    ----------------------------------------------------------------------------
    -- Constants
    ----------------------------------------------------------------------------
    -- number of SSS sequences checked for a given PSS
    ----------------------------------------------------------------------------
    -- Initialize registers
    ----------------------------------------------------------------------------
    -- Assign outputs
    ----------------------------------------------------------------------------
    ----------------------------------------------------------------------------
    -- Update registers
    ----------------------------------------------------------------------------
    -- Initialize next reg values to current values.
    reg_maxCorrelation_next <= reg_maxCorrelation;
    reg_winningSeqNum_next <= reg_winningSeqNum;
    reg_success_next <= reg_success;
    reg_duplexMode_next <= reg_duplexMode;
    -- Keep track of winning sequence
    IF reset = '1' THEN 
      reg_maxCorrelation_next <= correlation_signed;
      reg_winningSeqNum_next <= seqNum_unsigned;
      reg_success_next <= '0';
      reg_duplexMode_next <= '0';
    ELSIF (validIn AND thresholdExceeded) = '1' AND ((seqNum_unsigned < to_unsigned(16#003#, 10)) OR (correlation_signed > reg_maxCorrelation)) THEN 
      reg_maxCorrelation_next <= correlation_signed;
      reg_winningSeqNum_next <= seqNum_unsigned;
      reg_success_next <= '1';
      reg_duplexMode_next <= duplexMode;
    END IF;
    next_duplexModeDone := validIn AND hdlcoder_to_stdlogic(seqNum_unsigned >= to_unsigned(16#3ED#, 10));
    -- Write new values to registers.
    reg_duplexModeDone_next <= next_duplexModeDone;
    maxCorrelation <= reg_maxCorrelation;
    winningSeqNum_tmp <= reg_winningSeqNum;
    TDD <= reg_duplexMode;
    success <= reg_success;
    duplexModeDone <= reg_duplexModeDone;
  END PROCESS Find_Max_Correlation_output;


  winningSeqNum <= std_logic_vector(winningSeqNum_tmp);

END rtl;

