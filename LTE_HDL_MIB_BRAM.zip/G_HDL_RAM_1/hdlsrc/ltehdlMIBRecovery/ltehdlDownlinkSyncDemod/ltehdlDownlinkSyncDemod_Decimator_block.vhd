-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_Decimator_block IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(27 DOWNTO 0);  -- ufix28
        dataIn_im                         :   IN    std_logic_vector(27 DOWNTO 0);  -- ufix28
        validIn                           :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(27 DOWNTO 0);  -- sfix28_En15
        dataOut_im                        :   OUT   std_logic_vector(27 DOWNTO 0);  -- sfix28_En15
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Decimator_block;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Decimator_block IS

  -- Signals
  SIGNAL dataIn_re_signed                 : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL dataIn_im_signed                 : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL dataOut_re_tmp                   : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL dataOut_im_tmp                   : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL count                            : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL dataOutReg_re                    : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL dataOutReg_im                    : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL validOutReg                      : std_logic;
  SIGNAL count_next                       : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL dataOutReg_next_re               : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL dataOutReg_next_im               : signed(27 DOWNTO 0);  -- sfix28_En15
  SIGNAL validOutReg_next                 : std_logic;

BEGIN
  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Decimator_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        count <= to_unsigned(16#0#, 3);
        dataOutReg_re <= to_signed(16#0000000#, 28);
        dataOutReg_im <= to_signed(16#0000000#, 28);
        validOutReg <= '0';
      ELSIF enb = '1' THEN
        count <= count_next;
        dataOutReg_re <= dataOutReg_next_re;
        dataOutReg_im <= dataOutReg_next_im;
        validOutReg <= validOutReg_next;
      END IF;
    END IF;
  END PROCESS Decimator_process;

  Decimator_output : PROCESS (count, dataIn_im_signed, dataIn_re_signed, dataOutReg_im, dataOutReg_re,
       validIn, validOutReg)
  BEGIN
    count_next <= count;
    IF validIn = '1' AND (count = to_unsigned(16#0#, 3)) THEN 
      dataOutReg_next_re <= dataIn_re_signed;
      dataOutReg_next_im <= dataIn_im_signed;
      validOutReg_next <= '1';
    ELSE 
      dataOutReg_next_re <= to_signed(16#0000000#, 28);
      dataOutReg_next_im <= to_signed(16#0000000#, 28);
      validOutReg_next <= '0';
    END IF;
    IF validIn = '1' THEN 
      count_next <= count + to_unsigned(16#1#, 3);
    END IF;
    dataOut_re_tmp <= dataOutReg_re;
    dataOut_im_tmp <= dataOutReg_im;
    validOut <= validOutReg;
  END PROCESS Decimator_output;


  dataOut_re <= std_logic_vector(dataOut_re_tmp);

  dataOut_im <= std_logic_vector(dataOut_im_tmp);

END rtl;

