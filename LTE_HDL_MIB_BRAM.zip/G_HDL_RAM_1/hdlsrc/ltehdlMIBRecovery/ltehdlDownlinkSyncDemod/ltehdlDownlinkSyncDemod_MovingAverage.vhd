-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_MovingAverage IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(23 DOWNTO 0);  -- sfix24_En23
        dataIn_im                         :   IN    std_logic_vector(23 DOWNTO 0);  -- sfix24_En23
        validIn                           :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(23 DOWNTO 0);  -- sfix24_En23
        dataOut_im                        :   OUT   std_logic_vector(23 DOWNTO 0);  -- sfix24_En23
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_MovingAverage;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_MovingAverage IS

  -- Signals
  SIGNAL Delay4_out1                      : std_logic := '0';
  SIGNAL dataIn_re_signed                 : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL dataIn_im_signed                 : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay1_reg_re                    : vector_of_signed24(0 TO 7) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [8]
  SIGNAL Delay1_reg_im                    : vector_of_signed24(0 TO 7) := (OTHERS => to_signed(16#000000#, 24));  -- sfix24_En23 [8]
  SIGNAL Delay1_out1_re                   : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay1_out1_im                   : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Add_out1_re                      : signed(26 DOWNTO 0);  -- sfix27_En23
  SIGNAL Add_out1_im                      : signed(26 DOWNTO 0);  -- sfix27_En23
  SIGNAL Delay10_out1_re                  : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En23
  SIGNAL Delay10_out1_im                  : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En23
  SIGNAL Add1_out1_re                     : signed(26 DOWNTO 0);  -- sfix27_En23
  SIGNAL Add1_out1_im                     : signed(26 DOWNTO 0);  -- sfix27_En23
  SIGNAL Delay2_out1_re                   : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En23
  SIGNAL Delay2_out1_im                   : signed(26 DOWNTO 0) := to_signed(16#0000000#, 27);  -- sfix27_En23
  SIGNAL Gain_cast                        : signed(53 DOWNTO 0);  -- sfix54_En51
  SIGNAL Gain_cast_1                      : signed(53 DOWNTO 0);  -- sfix54_En51
  SIGNAL Gain_out1_re                     : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Gain_out1_im                     : signed(23 DOWNTO 0);  -- sfix24_En23
  SIGNAL Delay3_out1_re                   : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay3_out1_im                   : signed(23 DOWNTO 0) := to_signed(16#000000#, 24);  -- sfix24_En23
  SIGNAL Delay5_out1                      : std_logic := '0';

BEGIN
  -- Use a comb filter followed by an integrator
  -- to implement an efficient 8-tap moving average.

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay4_out1 <= validIn;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND validIn = '1' THEN
        Delay1_reg_im(0) <= dataIn_im_signed;
        Delay1_reg_im(1 TO 7) <= Delay1_reg_im(0 TO 6);
        Delay1_reg_re(0) <= dataIn_re_signed;
        Delay1_reg_re(1 TO 7) <= Delay1_reg_re(0 TO 6);
      END IF;
    END IF;
  END PROCESS Delay1_process;

  Delay1_out1_re <= Delay1_reg_re(7);
  Delay1_out1_im <= Delay1_reg_im(7);

  Add_out1_re <= (resize(dataIn_re_signed, 27)) - (resize(Delay1_out1_re, 27));
  Add_out1_im <= (resize(dataIn_im_signed, 27)) - (resize(Delay1_out1_im, 27));

  Delay10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay10_out1_re <= Add_out1_re;
        Delay10_out1_im <= Add_out1_im;
      END IF;
    END IF;
  END PROCESS Delay10_process;


  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay4_out1 = '1' THEN
        Delay2_out1_re <= Add1_out1_re;
        Delay2_out1_im <= Add1_out1_im;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  Add1_out1_re <= Delay2_out1_re + Delay10_out1_re;
  Add1_out1_im <= Delay2_out1_im + Delay10_out1_im;

  Gain_cast <= resize(Add1_out1_re & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 54);
  Gain_out1_re <= Gain_cast(51 DOWNTO 28);
  Gain_cast_1 <= resize(Add1_out1_im & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 54);
  Gain_out1_im <= Gain_cast_1(51 DOWNTO 28);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1_re <= Gain_out1_re;
        Delay3_out1_im <= Gain_out1_im;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  dataOut_re <= std_logic_vector(Delay3_out1_re);

  dataOut_im <= std_logic_vector(Delay3_out1_im);

  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay5_out1 <= Delay4_out1;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  validOut <= Delay5_out1;

END rtl;

