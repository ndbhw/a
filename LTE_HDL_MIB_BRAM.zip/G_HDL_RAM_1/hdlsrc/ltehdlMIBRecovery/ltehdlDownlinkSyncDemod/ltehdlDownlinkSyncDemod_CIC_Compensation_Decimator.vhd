-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_CIC_Compensation_Decimator IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataOut_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_CIC_Compensation_Decimator;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_CIC_Compensation_Decimator IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_Discrete_FIR_Filter
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          validIn                         :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Decimator
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_Discrete_FIR_Filter
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Discrete_FIR_Filter(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Decimator
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Decimator(rtl);

  -- Signals
  SIGNAL Discrete_FIR_Filter_out1_re      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL Discrete_FIR_Filter_out1_im      : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL Discrete_FIR_Filter_out2         : std_logic;
  SIGNAL dataOut_re_1                     : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dataOut_im_1                     : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL validOut_1                       : std_logic;
  SIGNAL dataOut_re_signed                : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataOut_im_signed                : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay2_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay2_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay1_out1                      : std_logic := '0';

BEGIN
  -- Note that this subsystem has an overflow warning suppressed programmatically in it's InitFcn callback.

  UDiscrete_FIR_Filter : ltehdlDownlinkSyncDemod_Discrete_FIR_Filter
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => dataIn_re,  -- ufix16
              dataIn_im => dataIn_im,  -- ufix16
              validIn => validIn,
              dataOut_re => Discrete_FIR_Filter_out1_re,  -- ufix16
              dataOut_im => Discrete_FIR_Filter_out1_im,  -- ufix16
              validOut => Discrete_FIR_Filter_out2
              );

  UDecimator : ltehdlDownlinkSyncDemod_Decimator
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              dataIn_re => Discrete_FIR_Filter_out1_re,  -- sfix16_En15
              dataIn_im => Discrete_FIR_Filter_out1_im,  -- sfix16_En15
              validIn => Discrete_FIR_Filter_out2,
              dataOut_re => dataOut_re_1,  -- sfix16_En15
              dataOut_im => dataOut_im_1,  -- sfix16_En15
              validOut => validOut_1
              );

  dataOut_re_signed <= signed(dataOut_re_1);

  dataOut_im_signed <= signed(dataOut_im_1);

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_out1_re <= dataOut_re_signed;
        Delay2_out1_im <= dataOut_im_signed;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  dataOut_re <= std_logic_vector(Delay2_out1_re);

  dataOut_im <= std_logic_vector(Delay2_out1_im);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1 <= validOut_1;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  validOut <= Delay1_out1;

END rtl;

