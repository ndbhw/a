-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_Discrete_FIR_Filter IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        validIn                           :   IN    std_logic;
        dataOut_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
        dataOut_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Discrete_FIR_Filter;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Discrete_FIR_Filter IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_FirRdyLogic
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dinSwitch_re                    :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          dinSwitch_im                    :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          dinVldSwitch                    :   IN    std_logic;
          coeff_re                        :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          coeff_im                        :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          haltProcess                     :   IN    std_logic;
          dinSM_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          dinSM_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          dinVldSM                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Addressable_Delay_Line
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn                          :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          wrEn                            :   IN    std_logic;
          wrAddr                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          rdAddr                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          delayLineEnd                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          dataOut                         :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn                          :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          validIn                         :   IN    std_logic;
          wrAddr                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          rdAddr                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          dataOut                         :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_FilterTapSystolicPreAdd
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          din_re                          :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          preAddIn                        :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          coeff                           :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          sumIn                           :   IN    std_logic_vector(32 DOWNTO 0);  -- ufix33
          sumOut                          :   OUT   std_logic_vector(32 DOWNTO 0)  -- ufix33
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block1
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn                          :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          wrEn                            :   IN    std_logic;
          wrAddr                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          rdAddr                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          delayLineEnd                    :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
          dataOut                         :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block2
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn                          :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          validIn                         :   IN    std_logic;
          wrAddr                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          rdAddr                          :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
          dataOut                         :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_FilterTapSystolicPreAdd_block
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          din_im                          :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          preAddIn                        :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          coeff                           :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          sumIn                           :   IN    std_logic_vector(32 DOWNTO 0);  -- ufix33
          sumOut                          :   OUT   std_logic_vector(32 DOWNTO 0)  -- ufix33
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_FirRdyLogic
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_FirRdyLogic(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Addressable_Delay_Line
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Addressable_Delay_Line(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_FilterTapSystolicPreAdd
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_FilterTapSystolicPreAdd(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block1
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block1(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block2
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block2(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_FilterTapSystolicPreAdd_block
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_FilterTapSystolicPreAdd_block(rtl);

  -- Functions
  -- HDLCODER_TO_STDLOGIC 
  FUNCTION hdlcoder_to_stdlogic(arg: boolean) RETURN std_logic IS
  BEGIN
    IF arg THEN
      RETURN '1';
    ELSE
      RETURN '0';
    END IF;
  END FUNCTION;


  -- Signals
  SIGNAL coeff_re                         : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL coeff_im                         : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL haltProcess                      : std_logic;
  SIGNAL dinSM_re                         : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dinSM_im                         : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL dinVldSM                         : std_logic;
  SIGNAL nextDelayLineRdAddrReverse       : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL rdCountReverse_1                 : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL nextDelayLineWrAddr              : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL wrCount_1                        : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL nextDelayLineRdAddr              : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL rdCount_1                        : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL nextSharingCount                 : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL sharingCount_1                   : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL delayLineValidInP                : std_logic;
  SIGNAL lastPhaseStrobe                  : std_logic;
  SIGNAL delayLineShiftEnP                : std_logic := '0';
  SIGNAL delayLineShiftEn1_1              : std_logic := '0';
  SIGNAL validOutLookahead_reg_rsvd       : std_logic_vector(4 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [5]
  SIGNAL validOutLookahead_1              : std_logic;
  SIGNAL vldOut_1                         : std_logic := '0';
  SIGNAL notValid                         : std_logic;
  SIGNAL wrAddrP                          : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL rdAddrDelayLine0                 : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL delayLineEnd0                    : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL delayLineDataOut0                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL delayLineEnd0_signed             : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL delayLineDataIn1_1               : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL wrAddr1                          : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL rdAddReverse1                    : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL delayLineDataOut1                : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL rdAddr0_1                        : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL coeffTableOut0                   : signed(15 DOWNTO 0);  -- sfix16_En16
  SIGNAL coeffTableRegP0_1                : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En16
  SIGNAL coeffTableReg0_1                 : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En16
  SIGNAL rdAddr1                          : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL rdAddrEndNonZero                 : std_logic;
  SIGNAL rdAddrEndZero                    : std_logic;
  SIGNAL finalSumValidPipe_reg_rsvd       : std_logic_vector(3 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [4]
  SIGNAL accumulate                       : std_logic;
  SIGNAL sumOut_signed                    : signed(32 DOWNTO 0);  -- sfix33_En31
  SIGNAL accSwitchOut                     : signed(32 DOWNTO 0);  -- sfix33_En31
  SIGNAL sumOut                           : std_logic_vector(32 DOWNTO 0);  -- ufix33
  SIGNAL converterOut                     : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dout_re_1                        : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL validOutLookahead_reg_rsvd_1     : std_logic_vector(4 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [5]
  SIGNAL validOutLookahead_3              : std_logic;
  SIGNAL delayLineEnd0_1                  : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL delayLineDataOut0_1              : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL delayLineEnd0_signed_1           : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL delayLineDataIn1_3               : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL delayLineDataOut1_1              : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL coeffTableOut0_1                 : signed(15 DOWNTO 0);  -- sfix16_En16
  SIGNAL coeffTableRegP0_3                : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En16
  SIGNAL coeffTableReg0_3                 : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En16
  SIGNAL rdAddrEndNonZero_1               : std_logic;
  SIGNAL rdAddrEndZero_1                  : std_logic;
  SIGNAL finalSumValidPipe_reg_rsvd_1     : std_logic_vector(3 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [4]
  SIGNAL accumulate_1                     : std_logic;
  SIGNAL sumOut_signed_1                  : signed(32 DOWNTO 0);  -- sfix33_En31
  SIGNAL accSwitchOut_1                   : signed(32 DOWNTO 0);  -- sfix33_En31
  SIGNAL sumOut_1                         : std_logic_vector(32 DOWNTO 0);  -- ufix33
  SIGNAL converterOut_1                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dout_im_1                        : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL dataZero_dtc_re                  : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataZero_dtc_im                  : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dout_cmplxSW_re                  : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dout_cmplxSW_im                  : signed(15 DOWNTO 0);  -- sfix16_En15

BEGIN
  UfirRdyLogic : ltehdlDownlinkSyncDemod_FirRdyLogic
    PORT MAP( clk => clk,
              enb => enb,
              dinSwitch_re => dataIn_re,  -- ufix16
              dinSwitch_im => dataIn_im,  -- ufix16
              dinVldSwitch => validIn,
              coeff_re => std_logic_vector(coeff_re),  -- ufix16
              coeff_im => std_logic_vector(coeff_im),  -- ufix16
              haltProcess => haltProcess,
              dinSM_re => dinSM_re,  -- ufix16
              dinSM_im => dinSM_im,  -- ufix16
              dinVldSM => dinVldSM
              );

  UdelayLine0 : ltehdlDownlinkSyncDemod_Addressable_Delay_Line
    PORT MAP( clk => clk,
              enb => enb,
              dataIn => dinSM_re,  -- ufix16
              wrEn => delayLineValidInP,
              wrAddr => std_logic_vector(wrAddrP),  -- ufix4
              rdAddr => std_logic_vector(rdAddrDelayLine0),  -- ufix4
              delayLineEnd => delayLineEnd0,  -- ufix16
              dataOut => delayLineDataOut0  -- ufix16
              );

  UdelayLine1 : ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block
    PORT MAP( clk => clk,
              enb => enb,
              dataIn => std_logic_vector(delayLineDataIn1_1),  -- ufix16
              validIn => delayLineShiftEn1_1,
              wrAddr => std_logic_vector(wrAddr1),  -- ufix4
              rdAddr => std_logic_vector(rdAddReverse1),  -- ufix4
              dataOut => delayLineDataOut1  -- ufix16
              );

  UfilterTap0 : ltehdlDownlinkSyncDemod_FilterTapSystolicPreAdd
    PORT MAP( clk => clk,
              enb => enb,
              din_re => delayLineDataOut0,  -- ufix16
              preAddIn => delayLineDataOut1,  -- ufix16
              coeff => std_logic_vector(coeffTableReg0_1),  -- ufix16
              sumIn => std_logic_vector(accSwitchOut),  -- ufix33
              sumOut => sumOut  -- ufix33
              );

  UdelayLine0_1 : ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block1
    PORT MAP( clk => clk,
              enb => enb,
              dataIn => dinSM_im,  -- ufix16
              wrEn => delayLineValidInP,
              wrAddr => std_logic_vector(wrAddrP),  -- ufix4
              rdAddr => std_logic_vector(rdAddrDelayLine0),  -- ufix4
              delayLineEnd => delayLineEnd0_1,  -- ufix16
              dataOut => delayLineDataOut0_1  -- ufix16
              );

  UdelayLine1_1 : ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block2
    PORT MAP( clk => clk,
              enb => enb,
              dataIn => std_logic_vector(delayLineDataIn1_3),  -- ufix16
              validIn => delayLineShiftEn1_1,
              wrAddr => std_logic_vector(wrAddr1),  -- ufix4
              rdAddr => std_logic_vector(rdAddReverse1),  -- ufix4
              dataOut => delayLineDataOut1_1  -- ufix16
              );

  UfilterTap0_1 : ltehdlDownlinkSyncDemod_FilterTapSystolicPreAdd_block
    PORT MAP( clk => clk,
              enb => enb,
              din_im => delayLineDataOut0_1,  -- ufix16
              preAddIn => delayLineDataOut1_1,  -- ufix16
              coeff => std_logic_vector(coeffTableReg0_3),  -- ufix16
              sumIn => std_logic_vector(accSwitchOut_1),  -- ufix33
              sumOut => sumOut_1  -- ufix33
              );

  coeff_re <= to_signed(16#0000#, 16);
  coeff_im <= to_signed(16#0000#, 16);

  haltProcess <= '0';

  rdCountReverse_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdCountReverse_1 <= nextDelayLineRdAddrReverse;
      END IF;
    END IF;
  END PROCESS rdCountReverse_process;


  wrCount_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        wrCount_1 <= nextDelayLineWrAddr;
      END IF;
    END IF;
  END PROCESS wrCount_process;


  rdCount_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdCount_1 <= nextDelayLineRdAddr;
      END IF;
    END IF;
  END PROCESS rdCount_process;


  sharingCount_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        sharingCount_1 <= nextSharingCount;
      END IF;
    END IF;
  END PROCESS sharingCount_process;


  -- Input control counter combinatorial logic
  InputControl_output : PROCESS (dinVldSM, rdCountReverse_1, rdCount_1, sharingCount_1, wrCount_1)
    VARIABLE out4 : unsigned(3 DOWNTO 0);
  BEGIN
    delayLineValidInP <= hdlcoder_to_stdlogic((sharingCount_1 = to_unsigned(16#0#, 4)) AND (dinVldSM = '1'));
    lastPhaseStrobe <= hdlcoder_to_stdlogic(sharingCount_1 = to_unsigned(16#B#, 4));
    IF (dinVldSM = '1') OR (sharingCount_1 > to_unsigned(16#0#, 4)) THEN 
      IF sharingCount_1 = to_unsigned(16#F#, 4) THEN 
        nextSharingCount <= to_unsigned(16#0#, 4);
      ELSE 
        nextSharingCount <= sharingCount_1 + to_unsigned(16#1#, 4);
      END IF;
    ELSE 
      nextSharingCount <= sharingCount_1;
    END IF;
    IF dinVldSM = '1' THEN 
      IF wrCount_1 = to_unsigned(16#B#, 4) THEN 
        out4 := to_unsigned(16#0#, 4);
      ELSE 
        out4 := wrCount_1 + to_unsigned(16#1#, 4);
      END IF;
    ELSE 
      out4 := wrCount_1;
    END IF;
    IF (rdCount_1 /= out4) OR (dinVldSM = '1') THEN 
      IF rdCount_1 = to_unsigned(16#0#, 4) THEN 
        nextDelayLineRdAddr <= to_unsigned(16#B#, 4);
      ELSE 
        nextDelayLineRdAddr <= rdCount_1 - to_unsigned(16#1#, 4);
      END IF;
    ELSE 
      nextDelayLineRdAddr <= rdCount_1;
    END IF;
    IF (sharingCount_1 > to_unsigned(16#0#, 4)) OR (dinVldSM = '1') THEN 
      IF sharingCount_1 = to_unsigned(16#F#, 4) THEN 
        IF wrCount_1 = to_unsigned(16#B#, 4) THEN 
          nextDelayLineRdAddrReverse <= to_unsigned(16#0#, 4);
        ELSE 
          nextDelayLineRdAddrReverse <= wrCount_1 + to_unsigned(16#1#, 4);
        END IF;
      ELSIF rdCountReverse_1 = to_unsigned(16#B#, 4) THEN 
        nextDelayLineRdAddrReverse <= to_unsigned(16#0#, 4);
      ELSE 
        nextDelayLineRdAddrReverse <= rdCountReverse_1 + to_unsigned(16#1#, 4);
      END IF;
    ELSE 
      nextDelayLineRdAddrReverse <= rdCountReverse_1;
    END IF;
    nextDelayLineWrAddr <= out4;
  END PROCESS InputControl_output;


  delayLineShiftEn0_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        delayLineShiftEnP <= lastPhaseStrobe;
      END IF;
    END IF;
  END PROCESS delayLineShiftEn0_process;


  delayLineShiftEn1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        delayLineShiftEn1_1 <= delayLineShiftEnP;
      END IF;
    END IF;
  END PROCESS delayLineShiftEn1_process;


  validOutLookahead_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        validOutLookahead_reg_rsvd(0) <= delayLineShiftEn1_1;
        validOutLookahead_reg_rsvd(4 DOWNTO 1) <= validOutLookahead_reg_rsvd(3 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS validOutLookahead_process;

  validOutLookahead_1 <= validOutLookahead_reg_rsvd(4);

  vldOut_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        vldOut_1 <= validOutLookahead_1;
      END IF;
    END IF;
  END PROCESS vldOut_process;


  notValid <=  NOT vldOut_1;

  wrAddr_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        wrAddrP <= wrCount_1;
      END IF;
    END IF;
  END PROCESS wrAddr_process;


  rdAddrDelayLine_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdAddrDelayLine0 <= rdCount_1;
      END IF;
    END IF;
  END PROCESS rdAddrDelayLine_process;


  delayLineEnd0_signed <= signed(delayLineEnd0);

  delayLineDataIn1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        delayLineDataIn1_1 <= delayLineEnd0_signed;
      END IF;
    END IF;
  END PROCESS delayLineDataIn1_process;


  wrAddr0_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        wrAddr1 <= wrAddrP;
      END IF;
    END IF;
  END PROCESS wrAddr0_process;


  rdAddrReverse0_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdAddReverse1 <= rdCountReverse_1;
      END IF;
    END IF;
  END PROCESS rdAddrReverse0_process;


  rdAddr0_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdAddr0_1 <= sharingCount_1;
      END IF;
    END IF;
  END PROCESS rdAddr0_process;


  -- Coefficient table for multiplier0
  coeffTable0_output : PROCESS (rdAddr0_1)
  BEGIN
    CASE rdAddr0_1 IS
      WHEN "0000" =>
        coeffTableOut0 <= to_signed(16#00AE#, 16);
      WHEN "0001" =>
        coeffTableOut0 <= to_signed(-16#0051#, 16);
      WHEN "0010" =>
        coeffTableOut0 <= to_signed(-16#0291#, 16);
      WHEN "0011" =>
        coeffTableOut0 <= to_signed(-16#0290#, 16);
      WHEN "0100" =>
        coeffTableOut0 <= to_signed(16#02CD#, 16);
      WHEN "0101" =>
        coeffTableOut0 <= to_signed(16#0877#, 16);
      WHEN "0110" =>
        coeffTableOut0 <= to_signed(16#0389#, 16);
      WHEN "0111" =>
        coeffTableOut0 <= to_signed(-16#0CDF#, 16);
      WHEN "1000" =>
        coeffTableOut0 <= to_signed(-16#1571#, 16);
      WHEN "1001" =>
        coeffTableOut0 <= to_signed(16#0161#, 16);
      WHEN "1010" =>
        coeffTableOut0 <= to_signed(16#34F4#, 16);
      WHEN "1011" =>
        coeffTableOut0 <= to_signed(16#6154#, 16);
      WHEN OTHERS => 
        coeffTableOut0 <= to_signed(16#0000#, 16);
    END CASE;
  END PROCESS coeffTable0_output;


  coeffTableRegP0_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        coeffTableRegP0_1 <= coeffTableOut0;
      END IF;
    END IF;
  END PROCESS coeffTableRegP0_process;


  coeffTableReg0_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        coeffTableReg0_1 <= coeffTableRegP0_1;
      END IF;
    END IF;
  END PROCESS coeffTableReg0_process;


  rdAddr0_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        rdAddr1 <= rdAddr0_1;
      END IF;
    END IF;
  END PROCESS rdAddr0_2_process;


  
  rdAddrEndNonZero <= '1' WHEN rdAddr1 /= to_unsigned(16#0#, 4) ELSE
      '0';

  rdAddrEndZero <=  NOT rdAddrEndNonZero;

  finalSumValidPipe_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        finalSumValidPipe_reg_rsvd(0) <= rdAddrEndZero;
        finalSumValidPipe_reg_rsvd(3 DOWNTO 1) <= finalSumValidPipe_reg_rsvd(2 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS finalSumValidPipe_process;

  accumulate <= finalSumValidPipe_reg_rsvd(3);

  
  accSwitchOut <= sumOut_signed WHEN accumulate = '0' ELSE
      to_signed(0, 33);

  sumOut_signed <= signed(sumOut);

  
  converterOut <= X"7FFF" WHEN ((sumOut_signed(32) = '0') AND (sumOut_signed(31) /= '0')) OR ((sumOut_signed(32) = '0') AND (sumOut_signed(31 DOWNTO 16) = X"7FFF")) ELSE
      X"8000" WHEN (sumOut_signed(32) = '1') AND (sumOut_signed(31) /= '1') ELSE
      sumOut_signed(31 DOWNTO 16) + ('0' & (sumOut_signed(15) AND (( NOT sumOut_signed(32)) OR (sumOut_signed(14) OR sumOut_signed(13) OR sumOut_signed(12) OR sumOut_signed(11) OR sumOut_signed(10) OR sumOut_signed(9) OR sumOut_signed(8) OR 
        sumOut_signed(7) OR sumOut_signed(6) OR sumOut_signed(5) OR sumOut_signed(4) OR sumOut_signed(3) OR sumOut_signed(2) OR sumOut_signed(1) OR sumOut_signed(0)))));

  dout_re_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND validOutLookahead_1 = '1' THEN
        dout_re_1 <= converterOut;
      END IF;
    END IF;
  END PROCESS dout_re_process;


  validOutLookahead_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        validOutLookahead_reg_rsvd_1(0) <= delayLineShiftEn1_1;
        validOutLookahead_reg_rsvd_1(4 DOWNTO 1) <= validOutLookahead_reg_rsvd_1(3 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS validOutLookahead_2_process;

  validOutLookahead_3 <= validOutLookahead_reg_rsvd_1(4);

  delayLineEnd0_signed_1 <= signed(delayLineEnd0_1);

  delayLineDataIn1_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        delayLineDataIn1_3 <= delayLineEnd0_signed_1;
      END IF;
    END IF;
  END PROCESS delayLineDataIn1_2_process;


  -- Coefficient table for multiplier0
  coeffTable0_1_output : PROCESS (rdAddr0_1)
  BEGIN
    CASE rdAddr0_1 IS
      WHEN "0000" =>
        coeffTableOut0_1 <= to_signed(16#00AE#, 16);
      WHEN "0001" =>
        coeffTableOut0_1 <= to_signed(-16#0051#, 16);
      WHEN "0010" =>
        coeffTableOut0_1 <= to_signed(-16#0291#, 16);
      WHEN "0011" =>
        coeffTableOut0_1 <= to_signed(-16#0290#, 16);
      WHEN "0100" =>
        coeffTableOut0_1 <= to_signed(16#02CD#, 16);
      WHEN "0101" =>
        coeffTableOut0_1 <= to_signed(16#0877#, 16);
      WHEN "0110" =>
        coeffTableOut0_1 <= to_signed(16#0389#, 16);
      WHEN "0111" =>
        coeffTableOut0_1 <= to_signed(-16#0CDF#, 16);
      WHEN "1000" =>
        coeffTableOut0_1 <= to_signed(-16#1571#, 16);
      WHEN "1001" =>
        coeffTableOut0_1 <= to_signed(16#0161#, 16);
      WHEN "1010" =>
        coeffTableOut0_1 <= to_signed(16#34F4#, 16);
      WHEN "1011" =>
        coeffTableOut0_1 <= to_signed(16#6154#, 16);
      WHEN OTHERS => 
        coeffTableOut0_1 <= to_signed(16#0000#, 16);
    END CASE;
  END PROCESS coeffTable0_1_output;


  coeffTableRegP0_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        coeffTableRegP0_3 <= coeffTableOut0_1;
      END IF;
    END IF;
  END PROCESS coeffTableRegP0_2_process;


  coeffTableReg0_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        coeffTableReg0_3 <= coeffTableRegP0_3;
      END IF;
    END IF;
  END PROCESS coeffTableReg0_2_process;


  
  rdAddrEndNonZero_1 <= '1' WHEN rdAddr1 /= to_unsigned(16#0#, 4) ELSE
      '0';

  rdAddrEndZero_1 <=  NOT rdAddrEndNonZero_1;

  finalSumValidPipe_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        finalSumValidPipe_reg_rsvd_1(0) <= rdAddrEndZero_1;
        finalSumValidPipe_reg_rsvd_1(3 DOWNTO 1) <= finalSumValidPipe_reg_rsvd_1(2 DOWNTO 0);
      END IF;
    END IF;
  END PROCESS finalSumValidPipe_1_process;

  accumulate_1 <= finalSumValidPipe_reg_rsvd_1(3);

  
  accSwitchOut_1 <= sumOut_signed_1 WHEN accumulate_1 = '0' ELSE
      to_signed(0, 33);

  sumOut_signed_1 <= signed(sumOut_1);

  
  converterOut_1 <= X"7FFF" WHEN ((sumOut_signed_1(32) = '0') AND (sumOut_signed_1(31) /= '0')) OR ((sumOut_signed_1(32) = '0') AND (sumOut_signed_1(31 DOWNTO 16) = X"7FFF")) ELSE
      X"8000" WHEN (sumOut_signed_1(32) = '1') AND (sumOut_signed_1(31) /= '1') ELSE
      sumOut_signed_1(31 DOWNTO 16) + ('0' & (sumOut_signed_1(15) AND (( NOT sumOut_signed_1(32)) OR (sumOut_signed_1(14) OR sumOut_signed_1(13) OR sumOut_signed_1(12) OR sumOut_signed_1(11) OR sumOut_signed_1(10) OR sumOut_signed_1(9) OR 
        sumOut_signed_1(8) OR sumOut_signed_1(7) OR sumOut_signed_1(6) OR sumOut_signed_1(5) OR sumOut_signed_1(4) OR sumOut_signed_1(3) OR sumOut_signed_1(2) OR sumOut_signed_1(1) OR sumOut_signed_1(0)))));

  dout_im_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND validOutLookahead_3 = '1' THEN
        dout_im_1 <= converterOut_1;
      END IF;
    END IF;
  END PROCESS dout_im_process;


  dataZero_dtc_re <= to_signed(16#0000#, 16);
  dataZero_dtc_im <= to_signed(16#0000#, 16);

  
  dout_cmplxSW_re <= dout_re_1 WHEN notValid = '0' ELSE
      dataZero_dtc_re;
  
  dout_cmplxSW_im <= dout_im_1 WHEN notValid = '0' ELSE
      dataZero_dtc_im;

  dataOut_re <= std_logic_vector(dout_cmplxSW_re);

  dataOut_im <= std_logic_vector(dout_cmplxSW_im);

  validOut <= vldOut_1;

END rtl;

