-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_Find_Max_Correlation1 IS
  PORT( seqNum                            :   IN    std_logic_vector(9 DOWNTO 0);  -- ufix10
        NCellID                           :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
        halfFrameIndicator                :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_Find_Max_Correlation1;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Find_Max_Correlation1 IS

  -- Signals
  SIGNAL seqNum_unsigned                  : unsigned(9 DOWNTO 0);  -- ufix10
  SIGNAL NCellID_tmp                      : unsigned(8 DOWNTO 0);  -- ufix9

BEGIN
  seqNum_unsigned <= unsigned(seqNum);

  Find_Max_Correlation1_output : PROCESS (seqNum_unsigned)
  BEGIN
    -- Convert a raw SSS sequence number to NCellID and halfFrameIndicator.
    -- There are 3 * 168 possible cell IDs and 2 * 3 * 168 possible SSS sequences
    -- since the sequence depends on which half of the frame it's in.
    -- NCellID is the cell ID of the detected cell.
    -- halfFrameIndicator:
    --   false: SSS was detected in 1st half of frame.
    --    true: SSS was detected in the 2nd half of the frame.
    IF seqNum_unsigned < to_unsigned(16#1F8#, 10) THEN 
      NCellID_tmp <= seqNum_unsigned(8 DOWNTO 0);
      halfFrameIndicator <= '0';
    ELSE 
      NCellID_tmp <= resize(resize(seqNum_unsigned, 11) - to_unsigned(16#1F8#, 11), 9);
      halfFrameIndicator <= '1';
    END IF;
  END PROCESS Find_Max_Correlation1_output;


  NCellID <= std_logic_vector(NCellID_tmp);

END rtl;

