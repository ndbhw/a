-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_FilterTapSystolicPreAdd IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        din_re                            :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        preAddIn                          :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        coeff                             :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        sumIn                             :   IN    std_logic_vector(32 DOWNTO 0);  -- ufix33
        sumOut                            :   OUT   std_logic_vector(32 DOWNTO 0)  -- ufix33
        );
END ltehdlDownlinkSyncDemod_FilterTapSystolicPreAdd;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_FilterTapSystolicPreAdd IS

  -- Signals
  SIGNAL din_re_signed                    : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL preAddIn_signed                  : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL coeff_signed                     : signed(15 DOWNTO 0);  -- sfix16_En16
  SIGNAL sumIn_signed                     : signed(32 DOWNTO 0);  -- sfix33_En31
  SIGNAL fTap_din1_reg1                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16
  SIGNAL fTap_din1_reg2                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16
  SIGNAL fTap_din2_reg1                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16
  SIGNAL fTap_preAdd_reg                  : signed(16 DOWNTO 0) := to_signed(16#00000#, 17);  -- sfix17
  SIGNAL fTap_mult_reg                    : signed(32 DOWNTO 0) := to_signed(0, 33);  -- sfix33
  SIGNAL fTap_addout_reg                  : signed(32 DOWNTO 0) := to_signed(0, 33);  -- sfix33
  SIGNAL fTap_coef_reg1                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16
  SIGNAL fTap_coef_reg2                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16
  SIGNAL fTap_preAdd_reg_next             : signed(16 DOWNTO 0);  -- sfix17_En15
  SIGNAL fTap_mult_reg_next               : signed(32 DOWNTO 0);  -- sfix33_En31
  SIGNAL fTap_addout_reg_next             : signed(32 DOWNTO 0);  -- sfix33_En31
  SIGNAL sumOut_tmp                       : signed(32 DOWNTO 0);  -- sfix33_En31

BEGIN
  din_re_signed <= signed(din_re);

  preAddIn_signed <= signed(preAddIn);

  coeff_signed <= signed(coeff);

  sumIn_signed <= signed(sumIn);

  -- FilterTapSystolicPreAddS
  fTap_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        fTap_preAdd_reg <= fTap_preAdd_reg_next;
        fTap_mult_reg <= fTap_mult_reg_next;
        fTap_addout_reg <= fTap_addout_reg_next;
        fTap_din1_reg2 <= fTap_din1_reg1;
        fTap_din1_reg1 <= din_re_signed;
        fTap_din2_reg1 <= preAddIn_signed;
        fTap_coef_reg2 <= fTap_coef_reg1;
        fTap_coef_reg1 <= coeff_signed;
      END IF;
    END IF;
  END PROCESS fTap_process;

  sumOut_tmp <= fTap_addout_reg;
  fTap_addout_reg_next <= fTap_mult_reg + sumIn_signed;
  fTap_mult_reg_next <= fTap_preAdd_reg * fTap_coef_reg2;
  fTap_preAdd_reg_next <= (resize(fTap_din1_reg2, 17)) + (resize(fTap_din2_reg1, 17));

  sumOut <= std_logic_vector(sumOut_tmp);

END rtl;

