-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_Magnitude_Squared_1 IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataOut                           :   OUT   std_logic_vector(31 DOWNTO 0)  -- sfix32_En30
        );
END ltehdlDownlinkSyncDemod_Magnitude_Squared_1;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Magnitude_Squared_1 IS

  -- Signals
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay3_reg_rsvd                  : vector_of_signed16(0 TO 1) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16 [2]
  SIGNAL Delay3_out1                      : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Product4_out1                    : signed(31 DOWNTO 0);  -- sfix32_En30
  SIGNAL Delay1_reg_rsvd                  : vector_of_signed32(0 TO 1) := (OTHERS => to_signed(0, 32));  -- sfix32 [2]
  SIGNAL Delay1_out1                      : signed(31 DOWNTO 0);  -- sfix32_En30
  SIGNAL Delay4_reg_rsvd                  : vector_of_signed16(0 TO 1) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16 [2]
  SIGNAL Delay4_out1                      : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Product5_out1                    : signed(31 DOWNTO 0);  -- sfix32_En30
  SIGNAL Delay2_reg_rsvd                  : vector_of_signed32(0 TO 1) := (OTHERS => to_signed(0, 32));  -- sfix32 [2]
  SIGNAL Delay2_out1                      : signed(31 DOWNTO 0);  -- sfix32_En30
  SIGNAL Add_out1                         : signed(31 DOWNTO 0);  -- sfix32_En30

BEGIN
  dataIn_re_signed <= signed(dataIn_re);

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_reg_rsvd(0) <= dataIn_re_signed;
        Delay3_reg_rsvd(1) <= Delay3_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay3_process;

  Delay3_out1 <= Delay3_reg_rsvd(1);

  Product4_out1 <= Delay3_out1 * Delay3_out1;

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_reg_rsvd(0) <= Product4_out1;
        Delay1_reg_rsvd(1) <= Delay1_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay1_process;

  Delay1_out1 <= Delay1_reg_rsvd(1);

  dataIn_im_signed <= signed(dataIn_im);

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay4_reg_rsvd(0) <= dataIn_im_signed;
        Delay4_reg_rsvd(1) <= Delay4_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay4_process;

  Delay4_out1 <= Delay4_reg_rsvd(1);

  Product5_out1 <= Delay4_out1 * Delay4_out1;

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_reg_rsvd(0) <= Product5_out1;
        Delay2_reg_rsvd(1) <= Delay2_reg_rsvd(0);
      END IF;
    END IF;
  END PROCESS Delay2_process;

  Delay2_out1 <= Delay2_reg_rsvd(1);

  Add_out1 <= Delay1_out1 + Delay2_out1;

  dataOut <= std_logic_vector(Add_out1);

END rtl;

