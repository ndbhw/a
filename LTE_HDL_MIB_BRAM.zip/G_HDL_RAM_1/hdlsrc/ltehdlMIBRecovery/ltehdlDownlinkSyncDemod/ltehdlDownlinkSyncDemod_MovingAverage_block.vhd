-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_MovingAverage_block IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn                            :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30_En30
        validIn                           :   IN    std_logic;
        dataOut                           :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
        validOut                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_MovingAverage_block;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_MovingAverage_block IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_Synchronous_Enabled_128_Sample_Delay
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn                          :   IN    std_logic_vector(36 DOWNTO 0);  -- ufix37_En30
          en                              :   IN    std_logic;
          dataOut                         :   OUT   std_logic_vector(36 DOWNTO 0)  -- ufix37_En30
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_Synchronous_Enabled_128_Sample_Delay
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Synchronous_Enabled_128_Sample_Delay(rtl);

  -- Signals
  SIGNAL Delay3_out1                      : std_logic := '0';
  SIGNAL dataIn_unsigned                  : unsigned(29 DOWNTO 0);  -- ufix30_En30
  SIGNAL Data_Type_Conversion_out1        : unsigned(36 DOWNTO 0);  -- ufix37_En30
  SIGNAL Synchronous_Enabled_128_Sample_Delay_dataOut : std_logic_vector(36 DOWNTO 0);  -- ufix37
  SIGNAL Synchronous_Enabled_128_Sample_Delay_dataOut_unsigned : unsigned(36 DOWNTO 0);  -- ufix37_En30
  SIGNAL Add_out1                         : unsigned(36 DOWNTO 0);  -- ufix37_En30
  SIGNAL Delay12_out1                     : unsigned(36 DOWNTO 0) := to_unsigned(0, 37);  -- ufix37_En30
  SIGNAL Synchronous_Enabled_Unit_Delay_out1 : unsigned(36 DOWNTO 0) := to_unsigned(0, 37);  -- ufix37_En30
  SIGNAL Add1_out1                        : unsigned(36 DOWNTO 0);  -- ufix37_En30
  SIGNAL Data_Type_Conversion1_out1       : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL Delay5_out1                      : unsigned(29 DOWNTO 0) := to_unsigned(16#00000000#, 30);  -- ufix30_En24
  SIGNAL Delay4_out1                      : std_logic := '0';
  SIGNAL Delay6_out1                      : std_logic := '0';

BEGIN
  -- Sum across a window of 128 samples using a comb filter followed by an integrator.

  USynchronous_Enabled_128_Sam : ltehdlDownlinkSyncDemod_Synchronous_Enabled_128_Sample_Delay
    PORT MAP( clk => clk,
              enb => enb,
              dataIn => std_logic_vector(Data_Type_Conversion_out1),  -- ufix37_En30
              en => validIn,
              dataOut => Synchronous_Enabled_128_Sample_Delay_dataOut  -- ufix37_En30
              );

  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay3_out1 <= validIn;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  dataIn_unsigned <= unsigned(dataIn);

  Data_Type_Conversion_out1 <= resize(dataIn_unsigned, 37);

  Synchronous_Enabled_128_Sample_Delay_dataOut_unsigned <= unsigned(Synchronous_Enabled_128_Sample_Delay_dataOut);

  Add_out1 <= Data_Type_Conversion_out1 - Synchronous_Enabled_128_Sample_Delay_dataOut_unsigned;

  Delay12_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay12_out1 <= Add_out1;
      END IF;
    END IF;
  END PROCESS Delay12_process;


  Add1_out1 <= Delay12_out1 + Synchronous_Enabled_Unit_Delay_out1;

  Synchronous_Enabled_Unit_Delay_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Delay3_out1 = '1' THEN
        Synchronous_Enabled_Unit_Delay_out1 <= Add1_out1;
      END IF;
    END IF;
  END PROCESS Synchronous_Enabled_Unit_Delay_process;


  Data_Type_Conversion1_out1 <= Synchronous_Enabled_Unit_Delay_out1(35 DOWNTO 6);

  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay5_out1 <= Data_Type_Conversion1_out1;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  dataOut <= std_logic_vector(Delay5_out1);

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay4_out1 <= Delay3_out1;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay6_out1 <= Delay4_out1;
      END IF;
    END IF;
  END PROCESS Delay6_process;


  validOut <= Delay6_out1;

END rtl;

