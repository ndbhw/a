-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_FrequencyEstimation IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        freqEst                           :   OUT   std_logic_vector(13 DOWNTO 0);  -- sfix14
        freqEstValid                      :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_FrequencyEstimation;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_FrequencyEstimation IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_CyclicPrefixCorrelator
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          corrOut_re                      :   OUT   std_logic_vector(23 DOWNTO 0);  -- sfix24_En23
          corrOut_im                      :   OUT   std_logic_vector(23 DOWNTO 0);  -- sfix24_En23
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Rect2Polar
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(23 DOWNTO 0);  -- sfix24_En23
          dataIn_im                       :   IN    std_logic_vector(23 DOWNTO 0);  -- sfix24_En23
          validIn                         :   IN    std_logic;
          magOut                          :   OUT   std_logic_vector(24 DOWNTO 0);  -- sfix25_En23
          angleOut                        :   OUT   std_logic_vector(13 DOWNTO 0);  -- sfix14_En14
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_AngleAtMaximum
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          magIn                           :   IN    std_logic_vector(24 DOWNTO 0);  -- sfix25_En23
          angleIn                         :   IN    std_logic_vector(13 DOWNTO 0);  -- sfix14_En14
          validIn                         :   IN    std_logic;
          angleOut                        :   OUT   std_logic_vector(13 DOWNTO 0);  -- sfix14_En14
          sampleValidOut                  :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_CyclicPrefixCorrelator
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_CyclicPrefixCorrelator(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Rect2Polar
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Rect2Polar(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_AngleAtMaximum
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_AngleAtMaximum(rtl);

  -- Signals
  SIGNAL CyclicPrefixCorrelator_corrOut_re : std_logic_vector(23 DOWNTO 0);  -- ufix24
  SIGNAL CyclicPrefixCorrelator_corrOut_im : std_logic_vector(23 DOWNTO 0);  -- ufix24
  SIGNAL CyclicPrefixCorrelator_validOut  : std_logic;
  SIGNAL Rect2Polar_magOut                : std_logic_vector(24 DOWNTO 0);  -- ufix25
  SIGNAL Rect2Polar_angleOut              : std_logic_vector(13 DOWNTO 0);  -- ufix14
  SIGNAL Rect2Polar_validOut              : std_logic;
  SIGNAL AngleAtMaximum_angleOut          : std_logic_vector(13 DOWNTO 0);  -- ufix14
  SIGNAL tb_freqEstDataValid              : std_logic;
  SIGNAL AngleAtMaximum_angleOut_signed   : signed(13 DOWNTO 0);  -- sfix14_En14
  SIGNAL tb_freqEstData                   : signed(13 DOWNTO 0);  -- sfix14

BEGIN
  UCyclicPrefixCorrelator : ltehdlDownlinkSyncDemod_CyclicPrefixCorrelator
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => dataIn_re,  -- sfix16_En15
              dataIn_im => dataIn_im,  -- sfix16_En15
              validIn => validIn,
              corrOut_re => CyclicPrefixCorrelator_corrOut_re,  -- sfix24_En23
              corrOut_im => CyclicPrefixCorrelator_corrOut_im,  -- sfix24_En23
              validOut => CyclicPrefixCorrelator_validOut
              );

  URect2Polar : ltehdlDownlinkSyncDemod_Rect2Polar
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => CyclicPrefixCorrelator_corrOut_re,  -- sfix24_En23
              dataIn_im => CyclicPrefixCorrelator_corrOut_im,  -- sfix24_En23
              validIn => CyclicPrefixCorrelator_validOut,
              magOut => Rect2Polar_magOut,  -- sfix25_En23
              angleOut => Rect2Polar_angleOut,  -- sfix14_En14
              validOut => Rect2Polar_validOut
              );

  UAngleAtMaximum : ltehdlDownlinkSyncDemod_AngleAtMaximum
    PORT MAP( clk => clk,
              enb => enb,
              magIn => Rect2Polar_magOut,  -- sfix25_En23
              angleIn => Rect2Polar_angleOut,  -- sfix14_En14
              validIn => Rect2Polar_validOut,
              angleOut => AngleAtMaximum_angleOut,  -- sfix14_En14
              sampleValidOut => tb_freqEstDataValid
              );

  AngleAtMaximum_angleOut_signed <= signed(AngleAtMaximum_angleOut);

  tb_freqEstData <= AngleAtMaximum_angleOut_signed;

  freqEst <= std_logic_vector(tb_freqEstData);

  freqEstValid <= tb_freqEstDataValid;

END rtl;

