-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block2 IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dataIn                            :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        validIn                           :   IN    std_logic;
        wrAddr                            :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        rdAddr                            :   IN    std_logic_vector(3 DOWNTO 0);  -- ufix4
        dataOut                           :   OUT   std_logic_vector(15 DOWNTO 0)  -- ufix16
        );
END ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block2;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Addressable_Delay_Line_block2 IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic
    GENERIC( AddrWidth                    : integer;
             DataWidth                    : integer
             );
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          wr_din                          :   IN    std_logic_vector(DataWidth - 1 DOWNTO 0);  -- generic width
          wr_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          wr_en                           :   IN    std_logic;
          rd_addr                         :   IN    std_logic_vector(AddrWidth - 1 DOWNTO 0);  -- generic width
          dout                            :   OUT   std_logic_vector(DataWidth - 1 DOWNTO 0)  -- generic width
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic(rtl);

  -- Signals
  SIGNAL delayedSignals                   : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL delayedSignals_signed            : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataOut_tmp                      : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15

BEGIN
  UsimpleDualPortRam_2 : ltehdlDownlinkSyncDemod_SimpleDualPortRAM_generic
    GENERIC MAP( AddrWidth => 4,
                 DataWidth => 16
                 )
    PORT MAP( clk => clk,
              enb => enb,
              wr_din => dataIn,
              wr_addr => wrAddr,
              wr_en => validIn,
              rd_addr => rdAddr,
              dout => delayedSignals
              );

  delayedSignals_signed <= signed(delayedSignals);

  reg_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        dataOut_tmp <= delayedSignals_signed;
      END IF;
    END IF;
  END PROCESS reg_rsvd_process;


  dataOut <= std_logic_vector(dataOut_tmp);

END rtl;

