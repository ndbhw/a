-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_MINRESRX2_BUTTERFLY IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        btfIn1_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        btfIn1_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        btfIn2_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        btfIn2_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        btfIn_vld                         :   IN    std_logic;
        twdl_re                           :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        twdl_im                           :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        syncReset                         :   IN    std_logic;
        btfOut1_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
        btfOut1_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
        btfOut2_re                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
        btfOut2_im                        :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
        btfOut_vld                        :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_MINRESRX2_BUTTERFLY;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_MINRESRX2_BUTTERFLY IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_Complex4Multiply
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          btfIn2_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          btfIn2_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          din2Dly_vld                     :   IN    std_logic;
          twdl_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          twdl_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
          syncReset                       :   IN    std_logic;
          dinXTwdl_re                     :   OUT   std_logic_vector(32 DOWNTO 0);  -- ufix33
          dinXTwdl_im                     :   OUT   std_logic_vector(32 DOWNTO 0);  -- ufix33
          dinXTwdl_vld                    :   OUT   std_logic
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_Complex4Multiply
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Complex4Multiply(rtl);

  -- Signals
  SIGNAL btfIn2_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL btfIn2_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL intdelay_reg_rsvd                : vector_of_signed16(0 TO 1) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16 [2]
  SIGNAL din2Dly_re                       : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL intdelay_reg_rsvd_1              : vector_of_signed16(0 TO 1) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16 [2]
  SIGNAL din2Dly_im                       : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dinXTwdl_re                      : std_logic_vector(32 DOWNTO 0);  -- ufix33
  SIGNAL dinXTwdl_im                      : std_logic_vector(32 DOWNTO 0);  -- ufix33
  SIGNAL dinXTwdl_vld                     : std_logic;
  SIGNAL dinXTwdl_re_signed               : signed(32 DOWNTO 0);  -- sfix33_En29
  SIGNAL dinXTwdl_im_signed               : signed(32 DOWNTO 0);  -- sfix33_En29
  SIGNAL btfIn1_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL intdelay_reg_rsvd_2              : vector_of_signed16(0 TO 7) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16 [8]
  SIGNAL din1Dly_re                       : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL btfIn1_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL intdelay_reg_rsvd_3              : vector_of_signed16(0 TO 7) := (OTHERS => to_signed(16#0000#, 16));  -- sfix16 [8]
  SIGNAL din1Dly_im                       : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL intdelay_reg_rsvd_4              : std_logic_vector(7 DOWNTO 0) := (OTHERS => '0');  -- ufix1 [8]
  SIGNAL din1Dly_vld                      : std_logic;
  SIGNAL minResRX2FFTButterfly_add1_re    : signed(33 DOWNTO 0) := to_signed(0, 34);  -- sfix34
  SIGNAL minResRX2FFTButterfly_add1_im    : signed(33 DOWNTO 0) := to_signed(0, 34);  -- sfix34
  SIGNAL minResRX2FFTButterfly_sub1_re    : signed(33 DOWNTO 0) := to_signed(0, 34);  -- sfix34
  SIGNAL minResRX2FFTButterfly_sub1_im    : signed(33 DOWNTO 0) := to_signed(0, 34);  -- sfix34
  SIGNAL minResRX2FFTButterfly_vld_reg    : std_logic := '0';
  SIGNAL minResRX2FFTButterfly_add1_cast_re : signed(33 DOWNTO 0) := to_signed(0, 34);  -- sfix34
  SIGNAL minResRX2FFTButterfly_add1_cast_im : signed(33 DOWNTO 0) := to_signed(0, 34);  -- sfix34
  SIGNAL minResRX2FFTButterfly_sub1_cast_re : signed(33 DOWNTO 0) := to_signed(0, 34);  -- sfix34
  SIGNAL minResRX2FFTButterfly_sub1_cast_im : signed(33 DOWNTO 0) := to_signed(0, 34);  -- sfix34
  SIGNAL minResRX2FFTButterfly_add1_re_next : signed(33 DOWNTO 0);  -- sfix34_En29
  SIGNAL minResRX2FFTButterfly_add1_im_next : signed(33 DOWNTO 0);  -- sfix34_En29
  SIGNAL minResRX2FFTButterfly_sub1_re_next : signed(33 DOWNTO 0);  -- sfix34_En29
  SIGNAL minResRX2FFTButterfly_sub1_im_next : signed(33 DOWNTO 0);  -- sfix34_En29
  SIGNAL minResRX2FFTButterfly_add1_cast_re_next : signed(33 DOWNTO 0);  -- sfix34_En28
  SIGNAL minResRX2FFTButterfly_add1_cast_im_next : signed(33 DOWNTO 0);  -- sfix34_En28
  SIGNAL minResRX2FFTButterfly_sub1_cast_re_next : signed(33 DOWNTO 0);  -- sfix34_En28
  SIGNAL minResRX2FFTButterfly_sub1_cast_im_next : signed(33 DOWNTO 0);  -- sfix34_En28
  SIGNAL minResRX2FFTButterfly_sra_temp   : signed(33 DOWNTO 0);  -- sfix34_En28
  SIGNAL minResRX2FFTButterfly_sra_temp_1 : signed(33 DOWNTO 0);  -- sfix34_En28
  SIGNAL minResRX2FFTButterfly_sra_temp_2 : signed(33 DOWNTO 0);  -- sfix34_En28
  SIGNAL minResRX2FFTButterfly_sra_temp_3 : signed(33 DOWNTO 0);  -- sfix34_En28
  SIGNAL btfOut1FP_re                     : signed(33 DOWNTO 0);  -- sfix34_En29
  SIGNAL btfOut1FP_im                     : signed(33 DOWNTO 0);  -- sfix34_En29
  SIGNAL btfOut2FP_re                     : signed(33 DOWNTO 0);  -- sfix34_En29
  SIGNAL btfOut2FP_im                     : signed(33 DOWNTO 0);  -- sfix34_En29
  SIGNAL btfOut_vld_1                     : std_logic := '0';
  SIGNAL btfOut1_re_tmp                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL btfOut1_im_tmp                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL btfOut2_re_tmp                   : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL btfOut2_im_tmp                   : signed(15 DOWNTO 0);  -- sfix16_En15

BEGIN
  UMUL4 : ltehdlDownlinkSyncDemod_Complex4Multiply
    PORT MAP( clk => clk,
              enb => enb,
              btfIn2_re => std_logic_vector(din2Dly_re),  -- ufix16
              btfIn2_im => std_logic_vector(din2Dly_im),  -- ufix16
              din2Dly_vld => btfIn_vld,
              twdl_re => twdl_re,  -- ufix16
              twdl_im => twdl_im,  -- ufix16
              syncReset => syncReset,
              dinXTwdl_re => dinXTwdl_re,  -- ufix33
              dinXTwdl_im => dinXTwdl_im,  -- ufix33
              dinXTwdl_vld => dinXTwdl_vld
              );

  btfIn2_re_signed <= signed(btfIn2_re);

  btfIn2_im_signed <= signed(btfIn2_im);

  intdelay_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd <= (OTHERS => to_signed(16#0000#, 16));
        ELSE 
          intdelay_reg_rsvd(0) <= btfIn2_re_signed;
          intdelay_reg_rsvd(1) <= intdelay_reg_rsvd(0);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_process;

  din2Dly_re <= intdelay_reg_rsvd(1);

  intdelay_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_1 <= (OTHERS => to_signed(16#0000#, 16));
        ELSE 
          intdelay_reg_rsvd_1(0) <= btfIn2_im_signed;
          intdelay_reg_rsvd_1(1) <= intdelay_reg_rsvd_1(0);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_1_process;

  din2Dly_im <= intdelay_reg_rsvd_1(1);

  dinXTwdl_re_signed <= signed(dinXTwdl_re);

  dinXTwdl_im_signed <= signed(dinXTwdl_im);

  btfIn1_re_signed <= signed(btfIn1_re);

  intdelay_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_2 <= (OTHERS => to_signed(16#0000#, 16));
        ELSE 
          intdelay_reg_rsvd_2(0) <= btfIn1_re_signed;
          intdelay_reg_rsvd_2(1 TO 7) <= intdelay_reg_rsvd_2(0 TO 6);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_2_process;

  din1Dly_re <= intdelay_reg_rsvd_2(7);

  btfIn1_im_signed <= signed(btfIn1_im);

  intdelay_3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_3 <= (OTHERS => to_signed(16#0000#, 16));
        ELSE 
          intdelay_reg_rsvd_3(0) <= btfIn1_im_signed;
          intdelay_reg_rsvd_3(1 TO 7) <= intdelay_reg_rsvd_3(0 TO 6);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_3_process;

  din1Dly_im <= intdelay_reg_rsvd_3(7);

  intdelay_4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        IF syncReset = '1' THEN
          intdelay_reg_rsvd_4 <= (OTHERS => '0');
        ELSE 
          intdelay_reg_rsvd_4(0) <= btfIn_vld;
          intdelay_reg_rsvd_4(7 DOWNTO 1) <= intdelay_reg_rsvd_4(6 DOWNTO 0);
        END IF;
      END IF;
    END IF;
  END PROCESS intdelay_4_process;

  din1Dly_vld <= intdelay_reg_rsvd_4(7);

  -- minResRX2FFTButterfly
  minResRX2FFTButterfly_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        IF syncReset = '1' THEN
          minResRX2FFTButterfly_add1_re <= to_signed(0, 34);
          minResRX2FFTButterfly_add1_im <= to_signed(0, 34);
          minResRX2FFTButterfly_sub1_re <= to_signed(0, 34);
          minResRX2FFTButterfly_sub1_im <= to_signed(0, 34);
          minResRX2FFTButterfly_add1_cast_re <= to_signed(0, 34);
          minResRX2FFTButterfly_add1_cast_im <= to_signed(0, 34);
          minResRX2FFTButterfly_sub1_cast_re <= to_signed(0, 34);
          minResRX2FFTButterfly_sub1_cast_im <= to_signed(0, 34);
          minResRX2FFTButterfly_vld_reg <= '0';
          btfOut_vld_1 <= '0';
        ELSE 
          minResRX2FFTButterfly_add1_re <= minResRX2FFTButterfly_add1_re_next;
          minResRX2FFTButterfly_add1_im <= minResRX2FFTButterfly_add1_im_next;
          minResRX2FFTButterfly_sub1_re <= minResRX2FFTButterfly_sub1_re_next;
          minResRX2FFTButterfly_sub1_im <= minResRX2FFTButterfly_sub1_im_next;
          minResRX2FFTButterfly_add1_cast_re <= minResRX2FFTButterfly_add1_cast_re_next;
          minResRX2FFTButterfly_add1_cast_im <= minResRX2FFTButterfly_add1_cast_im_next;
          minResRX2FFTButterfly_sub1_cast_re <= minResRX2FFTButterfly_sub1_cast_re_next;
          minResRX2FFTButterfly_sub1_cast_im <= minResRX2FFTButterfly_sub1_cast_im_next;
          btfOut_vld_1 <= minResRX2FFTButterfly_vld_reg;
          minResRX2FFTButterfly_vld_reg <= din1Dly_vld;
        END IF;
      END IF;
    END IF;
  END PROCESS minResRX2FFTButterfly_process;

  minResRX2FFTButterfly_add1_cast_re_next <= (resize(minResRX2FFTButterfly_add1_re(33 DOWNTO 1), 34)) + ('0' & (( NOT minResRX2FFTButterfly_add1_re(33)) AND minResRX2FFTButterfly_add1_re(0)));
  minResRX2FFTButterfly_add1_cast_im_next <= (resize(minResRX2FFTButterfly_add1_im(33 DOWNTO 1), 34)) + ('0' & (( NOT minResRX2FFTButterfly_add1_im(33)) AND minResRX2FFTButterfly_add1_im(0)));
  minResRX2FFTButterfly_sub1_cast_re_next <= (resize(minResRX2FFTButterfly_sub1_re(33 DOWNTO 1), 34)) + ('0' & (( NOT minResRX2FFTButterfly_sub1_re(33)) AND minResRX2FFTButterfly_sub1_re(0)));
  minResRX2FFTButterfly_sub1_cast_im_next <= (resize(minResRX2FFTButterfly_sub1_im(33 DOWNTO 1), 34)) + ('0' & (( NOT minResRX2FFTButterfly_sub1_im(33)) AND minResRX2FFTButterfly_sub1_im(0)));
  minResRX2FFTButterfly_add1_re_next <= (resize(din1Dly_re & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 34)) + (resize(dinXTwdl_re_signed, 34));
  minResRX2FFTButterfly_add1_im_next <= (resize(din1Dly_im & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 34)) + (resize(dinXTwdl_im_signed, 34));
  minResRX2FFTButterfly_sub1_re_next <= (resize(din1Dly_re & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 34)) - (resize(dinXTwdl_re_signed, 34));
  minResRX2FFTButterfly_sub1_im_next <= (resize(din1Dly_im & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0' & '0', 34)) - (resize(dinXTwdl_im_signed, 34));
  minResRX2FFTButterfly_sra_temp <= SHIFT_RIGHT(minResRX2FFTButterfly_add1_cast_re, 1);
  btfOut1FP_re <= minResRX2FFTButterfly_sra_temp(32 DOWNTO 0) & '0';
  minResRX2FFTButterfly_sra_temp_1 <= SHIFT_RIGHT(minResRX2FFTButterfly_add1_cast_im, 1);
  btfOut1FP_im <= minResRX2FFTButterfly_sra_temp_1(32 DOWNTO 0) & '0';
  minResRX2FFTButterfly_sra_temp_2 <= SHIFT_RIGHT(minResRX2FFTButterfly_sub1_cast_re, 1);
  btfOut2FP_re <= minResRX2FFTButterfly_sra_temp_2(32 DOWNTO 0) & '0';
  minResRX2FFTButterfly_sra_temp_3 <= SHIFT_RIGHT(minResRX2FFTButterfly_sub1_cast_im, 1);
  btfOut2FP_im <= minResRX2FFTButterfly_sra_temp_3(32 DOWNTO 0) & '0';

  btfOut1_re_tmp <= btfOut1FP_re(29 DOWNTO 14) + ('0' & (btfOut1FP_re(13) AND (( NOT btfOut1FP_re(33)) OR (btfOut1FP_re(12) OR btfOut1FP_re(11) OR btfOut1FP_re(10) OR btfOut1FP_re(9) OR btfOut1FP_re(8) OR btfOut1FP_re(7) OR btfOut1FP_re(6) OR 
    btfOut1FP_re(5) OR btfOut1FP_re(4) OR btfOut1FP_re(3) OR btfOut1FP_re(2) OR btfOut1FP_re(1) OR btfOut1FP_re(0)))));

  btfOut1_re <= std_logic_vector(btfOut1_re_tmp);

  btfOut1_im_tmp <= btfOut1FP_im(29 DOWNTO 14) + ('0' & (btfOut1FP_im(13) AND (( NOT btfOut1FP_im(33)) OR (btfOut1FP_im(12) OR btfOut1FP_im(11) OR btfOut1FP_im(10) OR btfOut1FP_im(9) OR btfOut1FP_im(8) OR btfOut1FP_im(7) OR btfOut1FP_im(6) OR 
    btfOut1FP_im(5) OR btfOut1FP_im(4) OR btfOut1FP_im(3) OR btfOut1FP_im(2) OR btfOut1FP_im(1) OR btfOut1FP_im(0)))));

  btfOut1_im <= std_logic_vector(btfOut1_im_tmp);

  btfOut2_re_tmp <= btfOut2FP_re(29 DOWNTO 14) + ('0' & (btfOut2FP_re(13) AND (( NOT btfOut2FP_re(33)) OR (btfOut2FP_re(12) OR btfOut2FP_re(11) OR btfOut2FP_re(10) OR btfOut2FP_re(9) OR btfOut2FP_re(8) OR btfOut2FP_re(7) OR btfOut2FP_re(6) OR 
    btfOut2FP_re(5) OR btfOut2FP_re(4) OR btfOut2FP_re(3) OR btfOut2FP_re(2) OR btfOut2FP_re(1) OR btfOut2FP_re(0)))));

  btfOut2_re <= std_logic_vector(btfOut2_re_tmp);

  btfOut2_im_tmp <= btfOut2FP_im(29 DOWNTO 14) + ('0' & (btfOut2FP_im(13) AND (( NOT btfOut2FP_im(33)) OR (btfOut2FP_im(12) OR btfOut2FP_im(11) OR btfOut2FP_im(10) OR btfOut2FP_im(9) OR btfOut2FP_im(8) OR btfOut2FP_im(7) OR btfOut2FP_im(6) OR 
    btfOut2FP_im(5) OR btfOut2FP_im(4) OR btfOut2FP_im(3) OR btfOut2FP_im(2) OR btfOut2FP_im(1) OR btfOut2FP_im(0)))));

  btfOut2_im <= std_logic_vector(btfOut2_im_tmp);

  btfOut_vld <= btfOut_vld_1;

END rtl;

