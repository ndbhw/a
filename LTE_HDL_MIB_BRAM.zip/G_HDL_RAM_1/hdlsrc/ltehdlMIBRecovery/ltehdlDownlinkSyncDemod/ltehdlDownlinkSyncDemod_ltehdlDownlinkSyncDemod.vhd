-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
LIBRARY work_ltehdlDownlinkSyncDemod;

ENTITY ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        enb_1_2_1                         :   IN    std_logic;
        dataIn_re                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        dataIn_im                         :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        validIn                           :   IN    std_logic;
        start                             :   IN    std_logic;
        NCellID                           :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
        TDDMode                           :   OUT   std_logic;
        freqEst                           :   OUT   std_logic_vector(13 DOWNTO 0);  -- sfix14
        cellDetected                      :   OUT   std_logic;
        cellSearchDone                    :   OUT   std_logic;
        subframeNum                       :   OUT   std_logic_vector(3 DOWNTO 0);  -- ufix4
        gridData_re                       :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        gridData_im                       :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
        gridValid                         :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod IS

  -- Component Declarations
  COMPONENT ltehdlDownlinkSyncDemod_Decimation_Filters
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_FrequencyEstimation
    PORT( clk                             :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          freqEst                         :   OUT   std_logic_vector(13 DOWNTO 0);  -- sfix14
          freqEstValid                    :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Start_Controller
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          inputValid                      :   IN    std_logic;
          startIn                         :   IN    std_logic;
          freqEstValid                    :   IN    std_logic;
          freqEstRegEn                    :   OUT   std_logic;
          searchStart                     :   OUT   std_logic;
          startTime                       :   OUT   std_logic_vector(14 DOWNTO 0)  -- ufix15
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Frequency_Correction_1x
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          freq                            :   IN    std_logic_vector(13 DOWNTO 0);  -- sfix14
          validIn                         :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Sync_Signal_Search
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb                             :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          start                           :   IN    std_logic;
          startTime                       :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
          NCellID                         :   OUT   std_logic_vector(8 DOWNTO 0);  -- ufix9
          TDDMode                         :   OUT   std_logic;
          timingOffset                    :   OUT   std_logic_vector(14 DOWNTO 0);  -- ufix15
          cellDetected                    :   OUT   std_logic;
          cellSearchDone                  :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Frequency_Correction_16x
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          freq                            :   IN    std_logic_vector(13 DOWNTO 0);  -- sfix14
          validIn                         :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Transfer_Timing_Offset
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          enb_1_2_1                       :   IN    std_logic;
          tin                             :   IN    std_logic_vector(14 DOWNTO 0);  -- ufix15
          tout                            :   OUT   std_logic_vector(18 DOWNTO 0)  -- ufix19
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Edge_Detector
    PORT( clk                             :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          x_x                             :   IN    std_logic;
          y_y                             :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Timing_Offset_Mask_Generator1
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          validIn                         :   IN    std_logic;
          timingOffset                    :   IN    std_logic_vector(18 DOWNTO 0);  -- ufix19
          timingOffsetValid               :   IN    std_logic;
          start                           :   IN    std_logic;
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_OFDM_Demodulation
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          dataIn_re                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataIn_im                       :   IN    std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validIn                         :   IN    std_logic;
          reset                           :   IN    std_logic;
          dataOut_re                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          dataOut_im                      :   OUT   std_logic_vector(15 DOWNTO 0);  -- sfix16_En15
          validOut                        :   OUT   std_logic
          );
  END COMPONENT;

  COMPONENT ltehdlDownlinkSyncDemod_Subframe_Counter
    PORT( clk                             :   IN    std_logic;
          n_rst                           :   IN    std_logic;
          enb_1_2_0                       :   IN    std_logic;
          validIn                         :   IN    std_logic;
          reset                           :   IN    std_logic;
          subframe                        :   OUT   std_logic_vector(3 DOWNTO 0)  -- ufix4
          );
  END COMPONENT;

  -- Component Configuration Statements
  FOR ALL : ltehdlDownlinkSyncDemod_Decimation_Filters
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Decimation_Filters(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_FrequencyEstimation
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_FrequencyEstimation(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Start_Controller
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Start_Controller(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Frequency_Correction_1x
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Frequency_Correction_1x(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Sync_Signal_Search
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Sync_Signal_Search(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Frequency_Correction_16x
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Frequency_Correction_16x(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Transfer_Timing_Offset
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Transfer_Timing_Offset(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Edge_Detector
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Edge_Detector(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Timing_Offset_Mask_Generator1
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Timing_Offset_Mask_Generator1(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_OFDM_Demodulation
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_OFDM_Demodulation(rtl);

  FOR ALL : ltehdlDownlinkSyncDemod_Subframe_Counter
    USE ENTITY work_ltehdlDownlinkSyncDemod.ltehdlDownlinkSyncDemod_Subframe_Counter(rtl);

  -- Signals
  SIGNAL Upsample_muxsel                  : std_logic := '1';  -- ufix1
  SIGNAL dataIn_re_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dataIn_im_signed                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL ofdm_dataIn_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL ofdm_dataIn_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Upsample_zero_re                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Upsample_zero_im                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Upsample_out1_re                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Upsample_out1_im                 : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Upsample1_muxsel                 : std_logic := '1';  -- ufix1
  SIGNAL ofdm_validIn                     : std_logic := '0';
  SIGNAL Upsample1_zero                   : std_logic;
  SIGNAL inputValid                       : std_logic;
  SIGNAL decimData_re                     : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL decimData_im                     : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL decimValid                       : std_logic;
  SIGNAL Upsample2_muxsel                 : std_logic := '1';  -- ufix1
  SIGNAL ofdm_reset                       : std_logic := '0';
  SIGNAL Upsample2_zero                   : std_logic;
  SIGNAL start_1                          : std_logic;
  SIGNAL freqEstData                      : std_logic_vector(13 DOWNTO 0);  -- ufix14
  SIGNAL freqEstValid                     : std_logic;
  SIGNAL freqEstRegEn                     : std_logic;
  SIGNAL searchStart                      : std_logic;
  SIGNAL startTime                        : std_logic_vector(14 DOWNTO 0);  -- ufix15
  SIGNAL freqEstData_signed               : signed(13 DOWNTO 0);  -- sfix14
  SIGNAL Delay_out1                       : signed(13 DOWNTO 0) := to_signed(16#0000#, 14);  -- sfix14
  SIGNAL freqEstReg                       : signed(13 DOWNTO 0) := to_signed(16#0000#, 14);  -- sfix14
  SIGNAL Frequency_Correction_1x_dataOut_re : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL Frequency_Correction_1x_dataOut_im : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL Frequency_Correction_1x_validOut : std_logic;
  SIGNAL Delay17_out1                     : std_logic := '0';
  SIGNAL startTime_unsigned               : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL Delay5_out1                      : unsigned(14 DOWNTO 0) := to_unsigned(16#0000#, 15);  -- ufix15
  SIGNAL Sync_Signal_Search_NCellID       : std_logic_vector(8 DOWNTO 0);  -- ufix9
  SIGNAL Sync_Signal_Search_TDDMode       : std_logic;
  SIGNAL Sync_Signal_Search_timingOffset  : std_logic_vector(14 DOWNTO 0);  -- ufix15
  SIGNAL Sync_Signal_Search_cellDetected  : std_logic;
  SIGNAL Sync_Signal_Search_cellSearchDone : std_logic;
  SIGNAL Sync_Signal_Search_NCellID_unsigned : unsigned(8 DOWNTO 0);  -- ufix9
  SIGNAL Downsample6_out1                 : unsigned(8 DOWNTO 0) := to_unsigned(16#000#, 9);  -- ufix9
  SIGNAL Delay10_out1                     : unsigned(8 DOWNTO 0) := to_unsigned(16#000#, 9);  -- ufix9
  SIGNAL Delay11_out1                     : unsigned(8 DOWNTO 0) := to_unsigned(16#000#, 9);  -- ufix9
  SIGNAL Downsample5_out1                 : std_logic := '0';
  SIGNAL Delay9_out1                      : std_logic := '0';
  SIGNAL Delay12_out1                     : std_logic := '0';
  SIGNAL Downsample1_out1                 : signed(13 DOWNTO 0) := to_signed(16#0000#, 14);  -- sfix14
  SIGNAL Delay6_out1                      : signed(13 DOWNTO 0) := to_signed(16#0000#, 14);  -- sfix14
  SIGNAL Delay14_out1                     : signed(13 DOWNTO 0) := to_signed(16#0000#, 14);  -- sfix14
  SIGNAL Downsample4_out1                 : std_logic := '0';
  SIGNAL Delay8_out1                      : std_logic := '0';
  SIGNAL Delay15_out1                     : std_logic := '0';
  SIGNAL Downsample3_out1                 : std_logic := '0';
  SIGNAL Delay7_out1                      : std_logic := '0';
  SIGNAL Delay16_out1                     : std_logic := '0';
  SIGNAL Frequency_Correction_16x_dataOut_re : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL Frequency_Correction_16x_dataOut_im : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL Frequency_Correction_16x_validOut : std_logic;
  SIGNAL Frequency_Correction_16x_dataOut_re_signed : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Frequency_Correction_16x_dataOut_im_signed : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL Delay4_out1_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Delay4_out1_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL Transfer_Timing_Offset_tout      : std_logic_vector(18 DOWNTO 0);  -- ufix19
  SIGNAL ofdm_timingOffsetValid           : std_logic;
  SIGNAL validOut                         : std_logic;
  SIGNAL OFDM_Demodulation_dataOut_re     : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL OFDM_Demodulation_dataOut_im     : std_logic_vector(15 DOWNTO 0);  -- ufix16
  SIGNAL OFDM_Demodulation_validOut       : std_logic;
  SIGNAL subframe                         : std_logic_vector(3 DOWNTO 0);  -- ufix4

BEGIN
  -- Signals at the bottom of the block diagram are sampled at 30.72 Msps, represented by a Simulink rate of 30.72 MHz.
  -- 
  -- Signals in this area are processed at a Simulink rate of 61.44 MHz.
  -- 
  -- The sampling rate of the Decimation Filters subsystem output is 1.92 Msps, however the signals are oversampled 
  -- at 61.44 MHz to allow resource sharing within filters and correlators, and accelerate SSS search operations

  UDecimation_Filters : ltehdlDownlinkSyncDemod_Decimation_Filters
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              dataIn_re => std_logic_vector(Upsample_out1_re),  -- sfix16_En15
              dataIn_im => std_logic_vector(Upsample_out1_im),  -- sfix16_En15
              validIn => inputValid,
              dataOut_re => decimData_re,  -- sfix16_En15
              dataOut_im => decimData_im,  -- sfix16_En15
              validOut => decimValid
              );

  UFrequencyEstimation : ltehdlDownlinkSyncDemod_FrequencyEstimation
    PORT MAP( clk => clk,
              enb => enb,
              dataIn_re => decimData_re,  -- sfix16_En15
              dataIn_im => decimData_im,  -- sfix16_En15
              validIn => decimValid,
              freqEst => freqEstData,  -- sfix14
              freqEstValid => freqEstValid
              );

  UStart_Controller : ltehdlDownlinkSyncDemod_Start_Controller
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              inputValid => inputValid,
              startIn => start_1,
              freqEstValid => freqEstValid,
              freqEstRegEn => freqEstRegEn,
              searchStart => searchStart,
              startTime => startTime  -- ufix15
              );

  UFrequency_Correction_1x : ltehdlDownlinkSyncDemod_Frequency_Correction_1x
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              dataIn_re => decimData_re,  -- sfix16_En15
              dataIn_im => decimData_im,  -- sfix16_En15
              freq => std_logic_vector(freqEstReg),  -- sfix14
              validIn => decimValid,
              dataOut_re => Frequency_Correction_1x_dataOut_re,  -- sfix16_En15
              dataOut_im => Frequency_Correction_1x_dataOut_im,  -- sfix16_En15
              validOut => Frequency_Correction_1x_validOut
              );

  USync_Signal_Search : ltehdlDownlinkSyncDemod_Sync_Signal_Search
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb => enb,
              dataIn_re => Frequency_Correction_1x_dataOut_re,  -- sfix16_En15
              dataIn_im => Frequency_Correction_1x_dataOut_im,  -- sfix16_En15
              validIn => Frequency_Correction_1x_validOut,
              start => Delay17_out1,
              startTime => std_logic_vector(Delay5_out1),  -- ufix15
              NCellID => Sync_Signal_Search_NCellID,  -- ufix9
              TDDMode => Sync_Signal_Search_TDDMode,
              timingOffset => Sync_Signal_Search_timingOffset,  -- ufix15
              cellDetected => Sync_Signal_Search_cellDetected,
              cellSearchDone => Sync_Signal_Search_cellSearchDone
              );

  UFrequency_Correction_16x : ltehdlDownlinkSyncDemod_Frequency_Correction_16x
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb_1_2_0 => enb_1_2_0,
              dataIn_re => std_logic_vector(ofdm_dataIn_re),  -- sfix16_En15
              dataIn_im => std_logic_vector(ofdm_dataIn_im),  -- sfix16_En15
              freq => std_logic_vector(Delay6_out1),  -- sfix14
              validIn => ofdm_validIn,
              dataOut_re => Frequency_Correction_16x_dataOut_re,  -- sfix16_En15
              dataOut_im => Frequency_Correction_16x_dataOut_im,  -- sfix16_En15
              validOut => Frequency_Correction_16x_validOut
              );

  UTransfer_Timing_Offset : ltehdlDownlinkSyncDemod_Transfer_Timing_Offset
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              enb_1_2_1 => enb_1_2_1,
              tin => Sync_Signal_Search_timingOffset,  -- ufix15
              tout => Transfer_Timing_Offset_tout  -- ufix19
              );

  UEdge_Detector : ltehdlDownlinkSyncDemod_Edge_Detector
    PORT MAP( clk => clk,
              enb_1_2_0 => enb_1_2_0,
              x_x => Delay8_out1,
              y_y => ofdm_timingOffsetValid
              );

  UTiming_Offset_Mask_Generato : ltehdlDownlinkSyncDemod_Timing_Offset_Mask_Generator1
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb_1_2_0 => enb_1_2_0,
              validIn => Frequency_Correction_16x_validOut,
              timingOffset => Transfer_Timing_Offset_tout,  -- ufix19
              timingOffsetValid => ofdm_timingOffsetValid,
              start => ofdm_reset,
              validOut => validOut
              );

  UOFDM_Demodulation : ltehdlDownlinkSyncDemod_OFDM_Demodulation
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb_1_2_0 => enb_1_2_0,
              dataIn_re => std_logic_vector(Delay4_out1_re),  -- sfix16_En15
              dataIn_im => std_logic_vector(Delay4_out1_im),  -- sfix16_En15
              validIn => validOut,
              reset => ofdm_reset,
              dataOut_re => OFDM_Demodulation_dataOut_re,  -- sfix16_En15
              dataOut_im => OFDM_Demodulation_dataOut_im,  -- sfix16_En15
              validOut => OFDM_Demodulation_validOut
              );

  USubframe_Counter : ltehdlDownlinkSyncDemod_Subframe_Counter
    PORT MAP( clk => clk,
              n_rst => n_rst,
              enb_1_2_0 => enb_1_2_0,
              validIn => OFDM_Demodulation_validOut,
              reset => ofdm_reset,
              subframe => subframe  -- ufix4
              );

  -- Free running, Unsigned Counter
  --  initial value   = 1
  --  step value      = 1
  Upsample_cnt_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Upsample_muxsel <=  NOT Upsample_muxsel;
      END IF;
    END IF;
  END PROCESS Upsample_cnt_process;


  dataIn_re_signed <= signed(dataIn_re);

  dataIn_im_signed <= signed(dataIn_im);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        ofdm_dataIn_re <= dataIn_re_signed;
        ofdm_dataIn_im <= dataIn_im_signed;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  Upsample_zero_re <= to_signed(16#0000#, 16);
  Upsample_zero_im <= to_signed(16#0000#, 16);

  -- Upsample: Upsample by 2, Sample offset 0 
  
  Upsample_out1_re <= ofdm_dataIn_re WHEN Upsample_muxsel = '1' ELSE
      Upsample_zero_re;
  
  Upsample_out1_im <= ofdm_dataIn_im WHEN Upsample_muxsel = '1' ELSE
      Upsample_zero_im;

  -- Free running, Unsigned Counter
  --  initial value   = 1
  --  step value      = 1
  Upsample1_cnt_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Upsample1_muxsel <=  NOT Upsample1_muxsel;
      END IF;
    END IF;
  END PROCESS Upsample1_cnt_process;


  Delay3_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        ofdm_validIn <= validIn;
      END IF;
    END IF;
  END PROCESS Delay3_process;


  Upsample1_zero <= '0';

  -- Upsample1: Upsample by 2, Sample offset 0 
  
  inputValid <= ofdm_validIn WHEN Upsample1_muxsel = '1' ELSE
      Upsample1_zero;

  -- Free running, Unsigned Counter
  --  initial value   = 1
  --  step value      = 1
  Upsample2_cnt_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Upsample2_muxsel <=  NOT Upsample2_muxsel;
      END IF;
    END IF;
  END PROCESS Upsample2_cnt_process;


  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        ofdm_reset <= start;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  Upsample2_zero <= '0';

  -- Upsample2: Upsample by 2, Sample offset 0 
  
  start_1 <= ofdm_reset WHEN Upsample2_muxsel = '1' ELSE
      Upsample2_zero;

  freqEstData_signed <= signed(freqEstData);

  Delay_rsvd_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay_out1 <= freqEstData_signed;
      END IF;
    END IF;
  END PROCESS Delay_rsvd_process;


  Freq_Est_Reg_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        IF start_1 = '1' THEN
          freqEstReg <= to_signed(16#0000#, 14);
        ELSIF freqEstRegEn = '1' THEN
          freqEstReg <= Delay_out1;
        END IF;
      END IF;
    END IF;
  END PROCESS Freq_Est_Reg_process;


  Delay17_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay17_out1 <= searchStart;
      END IF;
    END IF;
  END PROCESS Delay17_process;


  startTime_unsigned <= unsigned(startTime);

  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay5_out1 <= startTime_unsigned;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  Sync_Signal_Search_NCellID_unsigned <= unsigned(Sync_Signal_Search_NCellID);

  -- Downsample by 2 register (Sample offset 0)
  Downsample6_output_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_1 = '1' THEN
        Downsample6_out1 <= Sync_Signal_Search_NCellID_unsigned;
      END IF;
    END IF;
  END PROCESS Downsample6_output_process;


  Delay10_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay10_out1 <= Downsample6_out1;
      END IF;
    END IF;
  END PROCESS Delay10_process;


  Delay11_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay11_out1 <= Delay10_out1;
      END IF;
    END IF;
  END PROCESS Delay11_process;


  NCellID <= std_logic_vector(Delay11_out1);

  -- Downsample by 2 register (Sample offset 0)
  Downsample5_output_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_1 = '1' THEN
        Downsample5_out1 <= Sync_Signal_Search_TDDMode;
      END IF;
    END IF;
  END PROCESS Downsample5_output_process;


  Delay9_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay9_out1 <= Downsample5_out1;
      END IF;
    END IF;
  END PROCESS Delay9_process;


  Delay12_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay12_out1 <= Delay9_out1;
      END IF;
    END IF;
  END PROCESS Delay12_process;


  -- Downsample by 2 register (Sample offset 0)
  Downsample1_output_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_1 = '1' THEN
        Downsample1_out1 <= freqEstReg;
      END IF;
    END IF;
  END PROCESS Downsample1_output_process;


  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay6_out1 <= Downsample1_out1;
      END IF;
    END IF;
  END PROCESS Delay6_process;


  Delay14_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay14_out1 <= Delay6_out1;
      END IF;
    END IF;
  END PROCESS Delay14_process;


  freqEst <= std_logic_vector(Delay14_out1);

  -- Downsample by 2 register (Sample offset 0)
  Downsample4_output_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_1 = '1' THEN
        Downsample4_out1 <= Sync_Signal_Search_cellDetected;
      END IF;
    END IF;
  END PROCESS Downsample4_output_process;


  Delay8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay8_out1 <= Downsample4_out1;
      END IF;
    END IF;
  END PROCESS Delay8_process;


  Delay15_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay15_out1 <= Delay8_out1;
      END IF;
    END IF;
  END PROCESS Delay15_process;


  -- Downsample by 2 register (Sample offset 0)
  Downsample3_output_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_1 = '1' THEN
        Downsample3_out1 <= Sync_Signal_Search_cellSearchDone;
      END IF;
    END IF;
  END PROCESS Downsample3_output_process;


  Delay7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay7_out1 <= Downsample3_out1;
      END IF;
    END IF;
  END PROCESS Delay7_process;


  Delay16_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay16_out1 <= Delay7_out1;
      END IF;
    END IF;
  END PROCESS Delay16_process;


  Frequency_Correction_16x_dataOut_re_signed <= signed(Frequency_Correction_16x_dataOut_re);

  Frequency_Correction_16x_dataOut_im_signed <= signed(Frequency_Correction_16x_dataOut_im);

  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        Delay4_out1_re <= Frequency_Correction_16x_dataOut_re_signed;
        Delay4_out1_im <= Frequency_Correction_16x_dataOut_im_signed;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  TDDMode <= Delay12_out1;

  cellDetected <= Delay15_out1;

  cellSearchDone <= Delay16_out1;

  subframeNum <= subframe;

  gridData_re <= OFDM_Demodulation_dataOut_re;

  gridData_im <= OFDM_Demodulation_dataOut_im;

  gridValid <= OFDM_Demodulation_validOut;

END rtl;

