-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;
USE work.ltehdlDownlinkSyncDemod_ltehdlDownlinkSyncDemod_pac.ALL;

ENTITY ltehdlDownlinkSyncDemod_Max_Element IS
  PORT( clk                               :   IN    std_logic;
        n_rst                             :   IN    std_logic;
        enb                               :   IN    std_logic;
        x_0                               :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30
        x_1                               :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30
        x_2                               :   IN    std_logic_vector(29 DOWNTO 0);  -- ufix30
        xmax                              :   OUT   std_logic_vector(29 DOWNTO 0);  -- ufix30_En24
        idx                               :   OUT   std_logic_vector(1 DOWNTO 0)  -- ufix2
        );
END ltehdlDownlinkSyncDemod_Max_Element;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_Max_Element IS

  -- Signals
  SIGNAL x_x                              : vector_of_unsigned30(0 TO 2);  -- ufix30_En24 [3]
  SIGNAL xmax_tmp                         : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL idx_tmp                          : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL valReg                           : unsigned(29 DOWNTO 0);  -- ufix30
  SIGNAL x3Reg                            : unsigned(29 DOWNTO 0);  -- ufix30
  SIGNAL idxReg                           : unsigned(1 DOWNTO 0);  -- ufix2
  SIGNAL valReg_next                      : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL x3Reg_next                       : unsigned(29 DOWNTO 0);  -- ufix30_En24
  SIGNAL idxReg_next                      : unsigned(1 DOWNTO 0);  -- ufix2

BEGIN
  x_x(0) <= unsigned(x_0);
  x_x(1) <= unsigned(x_1);
  x_x(2) <= unsigned(x_2);

  Max_Element_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF n_rst = '0' THEN
        valReg <= to_unsigned(16#00000000#, 30);
        x3Reg <= to_unsigned(16#00000000#, 30);
        idxReg <= to_unsigned(16#0#, 2);
      ELSIF enb = '1' THEN
        valReg <= valReg_next;
        x3Reg <= x3Reg_next;
        idxReg <= idxReg_next;
      END IF;
    END IF;
  END PROCESS Max_Element_process;

  Max_Element_output : PROCESS (idxReg, valReg, x3Reg, x_x)
  BEGIN
    -- Returns the maximum value in the vector x. x must be of length 3.
    -- This requires two comparisons. To optimize for HDL timing performance,
    -- a single register is placed between the two comparisons.
    -- Has a delay of 1 sample.
    -- max value out of 1 and 2
    -- register for 3rd input
    -- zero based index
    -- second comparison
    IF valReg > x3Reg THEN 
      xmax_tmp <= valReg;
      idx_tmp <= idxReg;
    ELSE 
      xmax_tmp <= x3Reg;
      idx_tmp <= to_unsigned(16#2#, 2);
    END IF;
    -- first comparison
    IF x_x(0) > x_x(1) THEN 
      valReg_next <= x_x(0);
      idxReg_next <= to_unsigned(16#0#, 2);
    ELSE 
      valReg_next <= x_x(1);
      idxReg_next <= to_unsigned(16#1#, 2);
    END IF;
    x3Reg_next <= x_x(2);
  END PROCESS Max_Element_output;


  xmax <= std_logic_vector(xmax_tmp);

  idx <= std_logic_vector(idx_tmp);

END rtl;

