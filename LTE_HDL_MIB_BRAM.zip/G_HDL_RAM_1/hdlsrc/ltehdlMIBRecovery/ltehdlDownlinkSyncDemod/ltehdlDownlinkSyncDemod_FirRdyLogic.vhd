-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_FirRdyLogic IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        dinSwitch_re                      :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        dinSwitch_im                      :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        dinVldSwitch                      :   IN    std_logic;
        coeff_re                          :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        coeff_im                          :   IN    std_logic_vector(15 DOWNTO 0);  -- ufix16
        haltProcess                       :   IN    std_logic;
        dinSM_re                          :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
        dinSM_im                          :   OUT   std_logic_vector(15 DOWNTO 0);  -- ufix16
        dinVldSM                          :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_FirRdyLogic;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_FirRdyLogic IS

  -- Signals
  SIGNAL dinSwitch_re_signed              : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dinSwitch_im_signed              : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL coeff_re_signed                  : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL coeff_im_signed                  : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL syncReset                        : std_logic;
  SIGNAL firRdy_xdin_re                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL firRdy_xdin_im                   : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL firRdy_xdinVld                   : std_logic := '0';
  SIGNAL firRdy_state                     : unsigned(2 DOWNTO 0) := to_unsigned(16#0#, 3);  -- ufix3
  SIGNAL firRdy_readyReg                  : std_logic := '1';
  SIGNAL firRdy_count                     : unsigned(3 DOWNTO 0) := to_unsigned(16#0#, 4);  -- ufix4
  SIGNAL firRdy_xcoeffin_re               : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL firRdy_xcoeffin_im               : signed(15 DOWNTO 0) := to_signed(16#0000#, 16);  -- sfix16_En15
  SIGNAL firRdy_xdin_next_re              : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL firRdy_xdin_next_im              : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL firRdy_xdinVld_next              : std_logic;
  SIGNAL firRdy_state_next                : unsigned(2 DOWNTO 0);  -- ufix3
  SIGNAL firRdy_readyReg_next             : std_logic;
  SIGNAL firRdy_count_next                : unsigned(3 DOWNTO 0);  -- ufix4
  SIGNAL firRdy_xcoeffin_next_re          : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL firRdy_xcoeffin_next_im          : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL readySM                          : std_logic;
  SIGNAL dinSM_re_tmp                     : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL dinSM_im_tmp                     : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL coeffS_re                        : signed(15 DOWNTO 0);  -- sfix16_En15
  SIGNAL coeffS_im                        : signed(15 DOWNTO 0);  -- sfix16_En15

BEGIN
  dinSwitch_re_signed <= signed(dinSwitch_re);

  dinSwitch_im_signed <= signed(dinSwitch_im);

  coeff_re_signed <= signed(coeff_re);

  coeff_im_signed <= signed(coeff_im);

  syncReset <= '0';

  -- rdyLogic
  firRdy_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        firRdy_xdin_re <= firRdy_xdin_next_re;
        firRdy_xdin_im <= firRdy_xdin_next_im;
        firRdy_xdinVld <= firRdy_xdinVld_next;
        firRdy_state <= firRdy_state_next;
        firRdy_readyReg <= firRdy_readyReg_next;
        firRdy_count <= firRdy_count_next;
        firRdy_xcoeffin_re <= firRdy_xcoeffin_next_re;
        firRdy_xcoeffin_im <= firRdy_xcoeffin_next_im;
      END IF;
    END IF;
  END PROCESS firRdy_process;

  firRdy_output : PROCESS (coeff_im_signed, coeff_re_signed, dinSwitch_im_signed, dinSwitch_re_signed,
       dinVldSwitch, firRdy_count, firRdy_readyReg, firRdy_state,
       firRdy_xcoeffin_im, firRdy_xcoeffin_re, firRdy_xdinVld, firRdy_xdin_im,
       firRdy_xdin_re, haltProcess, syncReset)
    VARIABLE out2 : std_logic;
  BEGIN
    firRdy_xdin_next_re <= firRdy_xdin_re;
    firRdy_xdin_next_im <= firRdy_xdin_im;
    firRdy_xdinVld_next <= firRdy_xdinVld;
    firRdy_state_next <= firRdy_state;
    firRdy_readyReg_next <= firRdy_readyReg;
    firRdy_count_next <= firRdy_count;
    firRdy_xcoeffin_next_re <= firRdy_xcoeffin_re;
    firRdy_xcoeffin_next_im <= firRdy_xcoeffin_im;
    IF (( NOT haltProcess) AND ( NOT syncReset)) = '1' THEN 
      CASE firRdy_state IS
        WHEN "000" =>
          dinSM_re_tmp <= dinSwitch_re_signed;
          dinSM_im_tmp <= dinSwitch_im_signed;
          out2 := dinVldSwitch;
          coeffS_re <= coeff_re_signed;
          coeffS_im <= coeff_im_signed;
          firRdy_state_next <= to_unsigned(16#0#, 3);
          firRdy_readyReg_next <= '1';
          firRdy_xdin_next_re <= to_signed(16#0000#, 16);
          firRdy_xdin_next_im <= to_signed(16#0000#, 16);
          firRdy_xdinVld_next <= '0';
          firRdy_xcoeffin_next_re <= to_signed(16#0000#, 16);
          firRdy_xcoeffin_next_im <= to_signed(16#0000#, 16);
          IF dinVldSwitch = '1' THEN 
            firRdy_state_next <= to_unsigned(16#1#, 3);
            firRdy_readyReg_next <= '0';
          END IF;
        WHEN "001" =>
          dinSM_re_tmp <= to_signed(16#0000#, 16);
          dinSM_im_tmp <= to_signed(16#0000#, 16);
          out2 := '0';
          coeffS_re <= to_signed(16#0000#, 16);
          coeffS_im <= to_signed(16#0000#, 16);
          firRdy_state_next <= to_unsigned(16#3#, 3);
          IF dinVldSwitch = '1' THEN 
            firRdy_state_next <= to_unsigned(16#2#, 3);
            firRdy_xdin_next_re <= dinSwitch_re_signed;
            firRdy_xdin_next_im <= dinSwitch_im_signed;
            firRdy_xdinVld_next <= '1';
            firRdy_xcoeffin_next_re <= coeff_re_signed;
            firRdy_xcoeffin_next_im <= coeff_im_signed;
          END IF;
        WHEN "010" =>
          dinSM_re_tmp <= to_signed(16#0000#, 16);
          dinSM_im_tmp <= to_signed(16#0000#, 16);
          out2 := '0';
          coeffS_re <= to_signed(16#0000#, 16);
          coeffS_im <= to_signed(16#0000#, 16);
          firRdy_state_next <= to_unsigned(16#2#, 3);
          IF firRdy_count = to_unsigned(16#F#, 4) THEN 
            firRdy_state_next <= to_unsigned(16#4#, 3);
          END IF;
          firRdy_readyReg_next <= '0';
        WHEN "011" =>
          IF firRdy_count = to_unsigned(16#F#, 4) THEN 
            firRdy_readyReg_next <= '1';
            firRdy_state_next <= to_unsigned(16#0#, 3);
          END IF;
          dinSM_re_tmp <= to_signed(16#0000#, 16);
          dinSM_im_tmp <= to_signed(16#0000#, 16);
          coeffS_re <= to_signed(16#0000#, 16);
          coeffS_im <= to_signed(16#0000#, 16);
          out2 := '0';
        WHEN "100" =>
          firRdy_state_next <= to_unsigned(16#3#, 3);
          dinSM_re_tmp <= firRdy_xdin_re;
          dinSM_im_tmp <= firRdy_xdin_im;
          out2 := firRdy_xdinVld;
          coeffS_re <= firRdy_xcoeffin_re;
          coeffS_im <= firRdy_xcoeffin_im;
          firRdy_xdin_next_re <= dinSwitch_re_signed;
          firRdy_xdin_next_im <= dinSwitch_im_signed;
          firRdy_xdinVld_next <= dinVldSwitch;
          firRdy_xcoeffin_next_re <= coeff_re_signed;
          firRdy_xcoeffin_next_im <= coeff_im_signed;
        WHEN OTHERS => 
          dinSM_re_tmp <= to_signed(16#0000#, 16);
          dinSM_im_tmp <= to_signed(16#0000#, 16);
          out2 := '0';
          coeffS_re <= to_signed(16#0000#, 16);
          coeffS_im <= to_signed(16#0000#, 16);
          firRdy_state_next <= to_unsigned(16#0#, 3);
          firRdy_xdin_next_re <= to_signed(16#0000#, 16);
          firRdy_xdin_next_im <= to_signed(16#0000#, 16);
          firRdy_xdinVld_next <= '0';
          firRdy_xcoeffin_next_re <= to_signed(16#0000#, 16);
          firRdy_xcoeffin_next_im <= to_signed(16#0000#, 16);
          firRdy_readyReg_next <= '1';
      END CASE;
    ELSE 
      firRdy_state_next <= to_unsigned(16#0#, 3);
      firRdy_xdin_next_re <= to_signed(16#0000#, 16);
      firRdy_xdin_next_im <= to_signed(16#0000#, 16);
      firRdy_xcoeffin_next_re <= to_signed(16#0000#, 16);
      firRdy_xcoeffin_next_im <= to_signed(16#0000#, 16);
      firRdy_xdinVld_next <= '0';
      firRdy_readyReg_next <= '0';
      dinSM_re_tmp <= to_signed(16#0000#, 16);
      dinSM_im_tmp <= to_signed(16#0000#, 16);
      out2 := '0';
      coeffS_re <= to_signed(16#0000#, 16);
      coeffS_im <= to_signed(16#0000#, 16);
    END IF;
    IF (dinVldSwitch = '1' OR (firRdy_count > to_unsigned(16#0#, 4))) OR out2 = '1' THEN 
      IF ((firRdy_count = to_unsigned(16#F#, 4)) OR haltProcess = '1') OR syncReset = '1' THEN 
        firRdy_count_next <= to_unsigned(16#0#, 4);
      ELSE 
        firRdy_count_next <= firRdy_count + to_unsigned(16#1#, 4);
      END IF;
    END IF;
    readySM <= firRdy_readyReg;
    dinVldSM <= out2;
  END PROCESS firRdy_output;


  dinSM_re <= std_logic_vector(dinSM_re_tmp);

  dinSM_im <= std_logic_vector(dinSM_im_tmp);

END rtl;

