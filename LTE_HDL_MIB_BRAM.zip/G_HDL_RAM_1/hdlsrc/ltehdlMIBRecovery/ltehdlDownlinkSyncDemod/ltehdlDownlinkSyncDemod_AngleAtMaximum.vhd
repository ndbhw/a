-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY ltehdlDownlinkSyncDemod_AngleAtMaximum IS
  PORT( clk                               :   IN    std_logic;
        enb                               :   IN    std_logic;
        magIn                             :   IN    std_logic_vector(24 DOWNTO 0);  -- sfix25_En23
        angleIn                           :   IN    std_logic_vector(13 DOWNTO 0);  -- sfix14_En14
        validIn                           :   IN    std_logic;
        angleOut                          :   OUT   std_logic_vector(13 DOWNTO 0);  -- sfix14_En14
        sampleValidOut                    :   OUT   std_logic
        );
END ltehdlDownlinkSyncDemod_AngleAtMaximum;


ARCHITECTURE rtl OF ltehdlDownlinkSyncDemod_AngleAtMaximum IS

  -- Signals
  SIGNAL Delay2_out1                      : std_logic := '0';
  SIGNAL HDL_Counter_out1                 : unsigned(14 DOWNTO 0) := to_unsigned(16#0000#, 15);  -- ufix15
  SIGNAL count                            : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL need_to_wrap                     : std_logic;
  SIGNAL count_value                      : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL count_1                          : unsigned(14 DOWNTO 0);  -- ufix15
  SIGNAL Compare_To_Constant_out1         : std_logic;
  SIGNAL Logical_Operator1_out1           : std_logic;
  SIGNAL magIn_signed                     : signed(24 DOWNTO 0);  -- sfix25_En23
  SIGNAL Delay5_out1                      : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL Logical_Operator_out1            : std_logic;
  SIGNAL Delay6_out1                      : signed(24 DOWNTO 0) := to_signed(16#0000000#, 25);  -- sfix25_En23
  SIGNAL Relational_Operator_out1         : std_logic;
  SIGNAL angleIn_signed                   : signed(13 DOWNTO 0);  -- sfix14_En14
  SIGNAL Delay1_out1                      : signed(13 DOWNTO 0) := to_signed(16#0000#, 14);  -- sfix14_En14
  SIGNAL Delay7_out1                      : signed(13 DOWNTO 0) := to_signed(16#0000#, 14);  -- sfix14_En14
  SIGNAL Delay4_out1                      : signed(13 DOWNTO 0) := to_signed(16#0000#, 14);  -- sfix14_En14
  SIGNAL Delay8_out1                      : std_logic := '0';

BEGIN
  -- This subsystem records the maximum CP correlation level, and the corresponding phase angle of the result, across 
  -- windows of time equivalent to 1 slot (960 samples). A counter is used to reset the running max and record the final 
  -- phase value, which is then passed to the output and qualified by the validOut signal
  -- Store current mag & angle if mag is greater than previous max mag.
  -- This register stores the current running max magnitude in the current time window

  Delay2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay2_out1 <= validIn;
      END IF;
    END IF;
  END PROCESS Delay2_process;


  -- Count limited, Unsigned Counter
  --  initial value   = 0
  --  step value      = 1
  --  count to value  = 19199
  count <= HDL_Counter_out1 + to_unsigned(16#0001#, 15);

  
  need_to_wrap <= '1' WHEN HDL_Counter_out1 = to_unsigned(16#4AFF#, 15) ELSE
      '0';

  
  count_value <= count WHEN need_to_wrap = '0' ELSE
      to_unsigned(16#0000#, 15);

  
  count_1 <= HDL_Counter_out1 WHEN Delay2_out1 = '0' ELSE
      count_value;

  HDL_Counter_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        HDL_Counter_out1 <= count_1;
      END IF;
    END IF;
  END PROCESS HDL_Counter_process;


  
  Compare_To_Constant_out1 <= '1' WHEN HDL_Counter_out1 = to_unsigned(16#0000#, 15) ELSE
      '0';

  Logical_Operator1_out1 <= Delay2_out1 AND Compare_To_Constant_out1;

  magIn_signed <= signed(magIn);

  Delay5_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay5_out1 <= magIn_signed;
      END IF;
    END IF;
  END PROCESS Delay5_process;


  Delay6_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Logical_Operator_out1 = '1' THEN
        Delay6_out1 <= Delay5_out1;
      END IF;
    END IF;
  END PROCESS Delay6_process;


  
  Relational_Operator_out1 <= '1' WHEN Delay5_out1 > Delay6_out1 ELSE
      '0';

  Logical_Operator_out1 <= Relational_Operator_out1 OR Logical_Operator1_out1;

  angleIn_signed <= signed(angleIn);

  Delay1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay1_out1 <= angleIn_signed;
      END IF;
    END IF;
  END PROCESS Delay1_process;


  Delay7_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Logical_Operator_out1 = '1' THEN
        Delay7_out1 <= Delay1_out1;
      END IF;
    END IF;
  END PROCESS Delay7_process;


  Delay4_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' AND Logical_Operator1_out1 = '1' THEN
        Delay4_out1 <= Delay7_out1;
      END IF;
    END IF;
  END PROCESS Delay4_process;


  angleOut <= std_logic_vector(Delay4_out1);

  Delay8_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb = '1' THEN
        Delay8_out1 <= Delay2_out1;
      END IF;
    END IF;
  END PROCESS Delay8_process;


  sampleValidOut <= Delay8_out1;

END rtl;

