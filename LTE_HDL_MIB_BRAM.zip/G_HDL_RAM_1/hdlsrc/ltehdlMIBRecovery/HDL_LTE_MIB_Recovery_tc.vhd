-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY HDL_LTE_MIB_Recovery_tc IS
  PORT( clk                               :   IN    std_logic;
        clk_en                            :   IN    std_logic;
        enb                               :   OUT   std_logic;
        enb_1_2_0                         :   OUT   std_logic;
        enb_1_2_1                         :   OUT   std_logic
        );
END HDL_LTE_MIB_Recovery_tc;


ARCHITECTURE rtl OF HDL_LTE_MIB_Recovery_tc IS

  -- Signals
  SIGNAL count2                           : std_logic := '1';  -- ufix1
  SIGNAL comp_0_tmp                       : std_logic;
  SIGNAL phase_0_tmp                      : std_logic;
  SIGNAL phase_0                          : std_logic := '0';
  SIGNAL enb_1_2_0_1                      : std_logic;
  SIGNAL phase_delay_ctrl_const_out       : std_logic;
  SIGNAL phase_delay_ctrl_delay_out       : std_logic := '0';
  SIGNAL comp_1_tmp                       : std_logic;
  SIGNAL phase_1_tmp                      : std_logic;
  SIGNAL phase_delay_out                  : std_logic := '0';
  SIGNAL phase_1                          : std_logic;
  SIGNAL enb_1_2_1_1                      : std_logic;

BEGIN
  enb <= clk_en;

  -- Count limited, Unsigned Counter
  --  initial value   = 1
  --  step value      = 1
  --  count to value  = 1
  counter_2_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF clk_en = '1' THEN
        count2 <=  NOT count2;
      END IF;
    END IF;
  END PROCESS counter_2_process;


  
  comp_0_tmp <= '1' WHEN count2 = '1' ELSE
      '0';

  phase_0_tmp <= comp_0_tmp AND clk_en;

  phase_delay_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF clk_en = '1' THEN
        phase_0 <= phase_0_tmp;
      END IF;
    END IF;
  END PROCESS phase_delay_process;


  enb_1_2_0_1 <= phase_0 AND clk_en;

  enb_1_2_0 <= enb_1_2_0_1;

  phase_delay_ctrl_const_out <= '1';

  phase_delay_ctrl_delay_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF clk_en = '1' THEN
        phase_delay_ctrl_delay_out <= phase_delay_ctrl_const_out;
      END IF;
    END IF;
  END PROCESS phase_delay_ctrl_delay_process;


  
  comp_1_tmp <= '1' WHEN count2 = '0' ELSE
      '0';

  phase_1_tmp <= comp_1_tmp AND clk_en;

  phase_delay_1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF clk_en = '1' THEN
        phase_delay_out <= phase_1_tmp;
      END IF;
    END IF;
  END PROCESS phase_delay_1_process;


  
  phase_1 <= '1' WHEN phase_delay_ctrl_delay_out = '0' ELSE
      phase_delay_out;

  enb_1_2_1_1 <= phase_1 AND clk_en;

  enb_1_2_1 <= enb_1_2_1_1;

END rtl;

