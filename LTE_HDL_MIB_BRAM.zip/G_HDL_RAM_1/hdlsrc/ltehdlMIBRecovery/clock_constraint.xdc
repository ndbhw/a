
# Timing Specification Constraints

create_clock -name MWCLK  -period 16.276 [get_ports clk]
