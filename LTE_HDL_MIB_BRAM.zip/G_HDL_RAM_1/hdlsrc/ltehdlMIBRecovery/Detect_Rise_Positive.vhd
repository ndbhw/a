-- LTE MIB


LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

ENTITY Detect_Rise_Positive IS
  PORT( clk                               :   IN    std_logic;
        enb_1_2_0                         :   IN    std_logic;
        U_U                               :   IN    std_logic;
        Y_Y                               :   OUT   std_logic
        );
END Detect_Rise_Positive;


ARCHITECTURE rtl OF Detect_Rise_Positive IS

  -- Signals
  SIGNAL U_k                              : std_logic;
  SIGNAL U_k_1                            : std_logic := '0';
  SIGNAL FixPt_Relational_Operator_out1   : std_logic;

BEGIN
  -- Edge
  -- U(k)

  
  U_k <= '1' WHEN U_U > '0' ELSE
      '0';

  -- 
  -- Store in Global RAM
  Delay_Input1_process : PROCESS (clk)
  BEGIN
    IF rising_edge(clk) THEN
      IF enb_1_2_0 = '1' THEN
        U_k_1 <= U_k;
      END IF;
    END IF;
  END PROCESS Delay_Input1_process;


  
  FixPt_Relational_Operator_out1 <= '1' WHEN U_k > U_k_1 ELSE
      '0';

  Y_Y <= FixPt_Relational_Operator_out1;

END rtl;

