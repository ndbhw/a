create_project vivado_sim C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/ -part xazu5ev-sfvc784-1LV-i -force
source C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/HDL_LTE_MIB_Recovery_tb_compile.tcl
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/CellRefP_expected.dat
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/NCellID_expected.dat
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/NDLRB_expected.dat
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/NFrame_expected.dat
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/Ng_expected.dat
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/cellDetected_expected.dat
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/cellSearchDone_expected.dat
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/dataIn_im.dat
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/dataIn_re.dat
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/freqEst_expected.dat
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/mibDetected_expected.dat
add_files -fileset sim_1 -norecurse C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/startIn.dat
update_compile_order -fileset sim_1
source C:/Users/binhn/Temp/test_fpga/MIB/LTE/G_RAM_1/hdlsrc/ltehdlMIBRecovery/HDL_LTE_MIB_Recovery_tb_sim.tcl
