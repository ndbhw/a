--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Traffic selection                                             --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.22                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.NUMERIC_STD.all;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

entity TRAFFIC_SELECTION is
    generic (
    NUM_ANTENNA                 : natural := 4
    );
    port (
    RESET                       : in  std_logic;
    CLK                         : in  std_logic;

    PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

    BW_SEL                      : in  std_logic_vector(3 downto 0);

    TEST_MODE                   : in  std_logic_vector(3 downto 0);
    TP_MEM_PEN    : in std_logic; -- A/B port enable
    TP_MEM_AWEN   : in std_logic; -- A port write enable
    TP_MEM_WRADDR : in std_logic_vector(14 downto 0);
    TP_MEM_WRDATA : in std_logic_vector(31 downto 0); -- 31..16 : Q data, 15..0 : I data

    TEST_DC_I                   : in  std_logic_vector(15 downto 0);
    TEST_DC_Q                   : in  std_logic_vector(15 downto 0);
    TEST_NCO                    : in  std_logic_vector(5 downto 0);

    TP_IN_10MS                  : in  std_logic;
    TP_IN_TDD                   : in  std_logic;
    TP_IN_SYNC                  : in  std_logic;
    TP_IN_DATA                  : in  std_logic_vector(15 downto 0);

    TP_OUT_10MS                 : out std_logic;
    TP_OUT_TDD                  : out std_logic;
    TP_OUT_SYNC                 : out std_logic;
    TP_OUT_DATA                 : out std_logic_vector(15 downto 0)
    );
end TRAFFIC_SELECTION;

architecture BEHAVE of TRAFFIC_SELECTION is

    function log2 (data_value : integer)
    return integer is
    variable result : integer := 0;
    variable cnt    : integer := 1;
    begin
    if (data_value <= 1) then
        result := 0;
    else
        while (cnt < data_value) loop
        result := result + 1;
        cnt    := cnt *2;
        end loop;
    end if;
    return result;
    end log2;
    signal tp_10ms       : std_logic_vector(7 downto 0)  := (others => '0');
    signal tp_tdd        : std_logic_vector(7 downto 0)  := (others => '0');
    signal tp_sync       : std_logic_vector(7 downto 0)  := (others => '0');
    signal tp_data                  : std_logic_vector(15 downto 0) := (others => '0');
    signal enable_tp_mem : std_logic                     := '0';

    component PT_GEN_DC is
    generic (
    NUM_ANTENNA                 : natural := 4
    );
    port (
    CLK                         : in  std_logic;
    ENABLE                      : in  std_logic;

    TEST_DC_I                   : in  std_logic_vector(15 downto 0);
    TEST_DC_Q                   : in  std_logic_vector(15 downto 0);

    IN_SYNC                     : in  std_logic;
    OUT_DATA                    : out std_logic_vector(15 downto 0)
    );
    end component;

    signal enable_dc                : std_logic;
    signal pattern_dc               : std_logic_vector(15 downto 0);

    component pulsed_cw_2ant_interleave is
    Port(
        RESET                            : in  std_logic;
        CLK                              : in  std_logic;

        BW_SEL                           : in  std_logic_vector(3 downto 0);
        ENABLE                           : in  std_logic;

        I_SYNC                           : in  std_logic;                                    -- 1 pulse chip sync. signal @245.76MHz
        O_TP_DATA                        : out std_logic_vector(15 downto 0)
    );
    end component;

    signal enable_pulsed_cw         : std_logic;
    signal pattern_pulsed_cw        : std_logic_vector(15 downto 0);

    component PT_GEN_CW is
    generic (
    NUM_ANTENNA                 : natural := 4
    );
    port (
    CLK                         : in  std_logic;
    ENABLE                      : in  std_logic;

    SINE_NCO                    : in  std_logic_vector(5 downto 0);

    IN_SYNC                     : in  std_logic;
    OUT_DATA                    : out std_logic_vector(15 downto 0)
    );
    end component;

    signal enable_cw                : std_logic;
    signal pattern_cw               : std_logic_vector(15 downto 0);

    component TP_1ms_mem is
    port (
        RESET            : in  std_logic;
        CLK              : in  std_logic;
        BW_SEL           : in  std_logic_vector(3 downto 0);
        TP_EN            : in  std_logic;
        TP_MEM_PEN       : in  std_logic; -- A/B port enable
        TP_MEM_AWEN      : in  std_logic; -- A port write enable
        TP_MEM_WRADDR    : in  std_logic_vector(14 downto 0);
        TP_MEM_WRDATA    : in  std_logic_vector(31 downto 0); -- 31..16 : Q data, 15..0 : I data
        PROCESSING_DELAY : out std_logic_vector(23 downto 0);
        MAP_10MS         : in  std_logic;
        MAP_TDD          : in  std_logic;
        MAP_SYNC         : in  std_logic;
        MAP_DATA         : in  std_logic_vector(15 downto 0);
        TP_OUT_10MS      : out std_logic;
        TP_OUT_TDD       : out std_logic;
        TP_OUT_SYNC      : out std_logic;
        TP_OUT_DATA      : out std_logic_vector(15 downto 0)
    );
    end component TP_1ms_mem;
    signal cnt_sync    : std_logic_vector(5 downto 0) := (others => '0');
    signal sample_sync : std_logic_vector(7 downto 0) := (others => '0');
    signal tp_mem_10ms : std_logic;
    signal tp_mem_tdd  : std_logic;
    signal tp_mem_sync : std_logic;
    signal tp_mem_data : std_logic_vector(15 downto 0);
begin

    PROCESSING_DELAY <= conv_std_logic_vector(2, 24);

    -- chip to sample
    process (CLK)
    begin
    if (CLK'event and CLK = '1') then
        if (TP_IN_SYNC = '1') then
        cnt_sync <= (others => '0');
        else
        cnt_sync <= cnt_sync + 1;
        end if;
        case BW_SEL is
        when "0010" => -- 5-MHz
            if (cnt_sync(4 downto 0) = 31) then
            sample_sync(0) <= '1';
            else
            sample_sync(0) <= '0';
            end if;
        when "0011" => -- 10-MHz
            if (cnt_sync(3 downto 0) = 15) then
            sample_sync(0) <= '1';
            else
            sample_sync(0) <= '0';
            end if;
        when others => -- 15/20-MHz
            if (cnt_sync(2 downto 0) = 7) then
            sample_sync(0) <= '1';
            else
            sample_sync(0) <= '0';
            end if;
        end case;
        sample_sync(7 downto 1) <= sample_sync(6 downto 0);
    end if;
    end process;
    -- buffering
    process (CLK)
    begin
    if (CLK'event and CLK = '1') then
        tp_10ms <= tp_10ms(6 downto 0) & TP_IN_10MS;
        tp_tdd  <= tp_tdd(6 downto 0)  & TP_IN_TDD;
        tp_sync <= tp_sync(6 downto 0) & TP_IN_SYNC;
    end if;
    end process;

    -- enable/disable
    process (CLK)
    begin
    if (CLK'event and CLK = '1') then
        case TEST_MODE is
        when "0001" =>
            enable_dc        <= '1';
            enable_pulsed_cw <= '0';
            enable_cw        <= '0';
            enable_tp_mem    <= '0';
        when "0010" =>
            enable_dc        <= '0';
            enable_pulsed_cw <= '1';
            enable_cw        <= '0';
            enable_tp_mem    <= '0';
        when "0011" =>
            enable_dc        <= '0';
            enable_pulsed_cw <= '0';
            enable_cw        <= '1';
            enable_tp_mem    <= '0';
        when "0100" =>
            enable_dc        <= '0';
            enable_pulsed_cw <= '0';
            enable_cw        <= '0';
            enable_tp_mem    <= '1';
        when others =>
            enable_dc        <= '0';
            enable_pulsed_cw <= '0';
            enable_cw        <= '0';
            enable_tp_mem    <= '0';
        end case;
    end if;
    end process;

    -- traffic selection
    process (CLK)
    begin
    if (CLK'event and CLK = '1') then
        case TEST_MODE is
        when "0001" =>
            TP_OUT_10MS <= tp_10ms(1);
            TP_OUT_TDD  <= tp_tdd(1);
            TP_OUT_SYNC <= tp_sync(1);
            TP_OUT_DATA <= pattern_dc;
        when "0010" =>
            TP_OUT_10MS <= tp_10ms(1);
            TP_OUT_TDD  <= tp_tdd(1);
            TP_OUT_SYNC <= tp_sync(1);
            TP_OUT_DATA <= pattern_pulsed_cw;
        when "0011" =>
            TP_OUT_10MS <= tp_10ms(1);
            TP_OUT_TDD  <= tp_tdd(1);
            TP_OUT_SYNC <= tp_sync(1);
            TP_OUT_DATA <= pattern_cw;
        when "0100" =>
            TP_OUT_10MS <= tp_mem_10ms;
            TP_OUT_TDD  <= tp_mem_tdd;
            TP_OUT_SYNC <= tp_mem_sync;
            TP_OUT_DATA <= tp_mem_data;
        when others =>
            TP_OUT_10MS <= TP_IN_10MS;
            TP_OUT_TDD  <= TP_IN_TDD;
            TP_OUT_SYNC <= TP_IN_SYNC;
            TP_OUT_DATA <= TP_IN_DATA;
        end case;
    end if;
    end process;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_DC : PT_GEN_DC
    generic map(
    NUM_ANTENNA                 => NUM_ANTENNA                              --: natural := 4
    )
    port map(
    CLK                         => CLK                                     ,--: in  std_logic;
    ENABLE                      => enable_dc                               ,--: in  std_logic;

    TEST_DC_I                   => TEST_DC_I                               ,--: in  std_logic_vector(15 downto 0);
    TEST_DC_Q                   => TEST_DC_Q                               ,--: in  std_logic_vector(15 downto 0);

        IN_SYNC  => sample_sync(0) , --: in  std_logic;
    OUT_DATA                    => pattern_dc                               --: out std_logic_vector(15 downto 0)
    );

    u_pulsed_cw_2ant_interleave : pulsed_cw_2ant_interleave
    port map(
        RESET                   => RESET                                   ,--: in  std_logic;
        CLK                     => CLK                                     ,--: in  std_logic;

        BW_SEL                  => BW_SEL                                  ,--: in  std_logic_vector(3 downto 0);
        ENABLE                  => enable_pulsed_cw                        ,--: in  std_logic;

        I_SYNC                  => sample_sync(0)                          ,--: in  std_logic;                                    -- 1 pulse chip sync. signal @245.76MHz
        O_TP_DATA               => pattern_pulsed_cw                        --: out std_logic_vector(15 downto 0)
    );

    u_CW : PT_GEN_CW
    generic map(
    NUM_ANTENNA                 => NUM_ANTENNA                              --: natural := 4
    )
    port map(
    CLK                         => CLK                                     ,--: in  std_logic;
    ENABLE                      => enable_cw                               ,--: in  std_logic;

    SINE_NCO                    => TEST_NCO                                ,--: in  std_logic_vector(5 downto 0);

        IN_SYNC  => sample_sync(0) , --: in  std_logic;
    OUT_DATA                    => pattern_cw                               --: out std_logic_vector(15 downto 0)
    );

    u_TP_1ms : TP_1ms_mem
    port map (
        RESET                   => RESET,
        CLK                     => CLK,
        BW_SEL                  => BW_SEL,
        TP_EN                   => enable_tp_mem,
        TP_MEM_PEN              => TP_MEM_PEN,
        TP_MEM_AWEN             => TP_MEM_AWEN,
        TP_MEM_WRADDR           => TP_MEM_WRADDR,
        TP_MEM_WRDATA           => TP_MEM_WRDATA,
        PROCESSING_DELAY        => open,
        MAP_10MS                => TP_IN_10MS,
        MAP_TDD                 => TP_IN_TDD,
        MAP_SYNC                => TP_IN_SYNC,
        MAP_DATA                => TP_IN_DATA,
        TP_OUT_10MS             => tp_mem_10ms,
        TP_OUT_TDD              => tp_mem_tdd,
        TP_OUT_SYNC             => tp_mem_sync,
        TP_OUT_DATA             => tp_mem_data
    );
end BEHAVE;