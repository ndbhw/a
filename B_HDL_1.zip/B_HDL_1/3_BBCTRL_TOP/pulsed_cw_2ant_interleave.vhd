----------------------------------------------------------------------------------
-- Company:
-- Engineer:
--
-- Create Date: 11/29/2023 08:12:21 AM
-- Design Name:
-- Module Name: pulsed_cw_2ant_interleave - Behavioral
-- Project Name:
-- Target Devices:
-- Tool Versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity pulsed_cw_2ant_interleave is
    Port(
        RESET                            : in  std_logic;
        CLK                              : in  std_logic;

        BW_SEL                           : in  std_logic_vector(3 downto 0);
        ENABLE                           : in  std_logic;

        I_SYNC                           : in  std_logic;                                    -- 1 pulse chip sync. signal @245.76MHz
        O_TP_DATA                        : out std_logic_vector(15 downto 0)
    );
end pulsed_cw_2ant_interleave;

architecture Behavioral of pulsed_cw_2ant_interleave is

signal enable_ff                         : std_logic_vector(1 downto 0) := "00";
signal sample_start                      : std_logic := '0';

signal sample_cnt                        : std_logic_vector(4  downto 0);
signal chip_cnt                          : std_logic_vector(12 downto 0);
signal max_chip_cnt_value                : std_logic_vector(12 downto 0);

signal pulse_cnt_enable                  : std_logic;
signal ant0_valid                        : std_logic;
signal ant1_valid                        : std_logic;

signal cnt_updown                        : std_logic;
signal pulse_data_cnt                    : std_logic_vector(7 downto 0);
signal max_pulse_data_cnt_value          : std_logic_vector(7 downto 0);

signal i_sync_d                          : std_logic := '0';
signal pulsed_data                       : std_logic_vector(15 downto 0);

begin

    max_chip_cnt_value <= conv_std_logic_vector(768, 13)  when BW_SEL = "0010" else  --5MHz 
                          conv_std_logic_vector(1536, 13) when BW_SEL = "0011" else  --10MHz
                          conv_std_logic_vector(3072, 13);                           --15/20MHz 

    max_pulse_data_cnt_value <= conv_std_logic_vector(45 , 8) when BW_SEL = "0010" else  --5MHz
                                conv_std_logic_vector(84 , 8) when BW_SEL = "0011" else  --10MHz
                                conv_std_logic_vector(161, 8);                           --15/20MHz

    process(CLK)
    begin
        if(CLK'event and CLK = '1')then
            enable_ff <= enable_ff(0) & ENABLE;
        end if;
    end process;

    process(RESET, CLK)
    begin
        if(CLK'event and CLK = '1')then
            i_sync_d <= I_SYNC;
        end if;
    end process;

    process(RESET, CLK)
    begin
        if(RESET = '1')then
            sample_start <= '0';
        elsif(CLK'event and CLK = '1')then
            if(I_SYNC = '1')then
                sample_start <= enable_ff(1);
            end if;
        end if;
    end process;

    process(RESET, CLK)
    begin
        if(RESET = '1')then
            sample_cnt <= (others => '0');
        elsif(CLK'event and CLK = '1')then
            if(sample_start = '1')then
                if(I_SYNC = '1')then
                    sample_cnt <= (others => '0');
                else
                    sample_cnt <= sample_cnt + 1;
                end if;
            else
                sample_cnt <= (others => '0');
            end if;
        end if;
    end process;

    process(RESET, CLK)
    begin
        if(RESET = '1')then
            chip_cnt <= (others => '0');
        elsif(CLK'event and CLK = '1')then
            if(sample_start = '1')then
                if(I_SYNC = '1')then
                    if(chip_cnt = max_chip_cnt_value-1)then
                        chip_cnt <= (others => '0');
                    else
                        chip_cnt <= chip_cnt + 1;
                    end if;
                end if;
            else
                chip_cnt <= (others => '0');
            end if;
        end if;
    end process;

    process(RESET, CLK)
    begin
        if(RESET = '1')then
            pulse_cnt_enable <= '0';
            ant0_valid <= '0';
            ant1_valid <= '0';
        elsif(CLK'event and CLK = '1')then
            if(chip_cnt = 0)then
                pulse_cnt_enable <= '0';
                ant0_valid <= '0';
                ant1_valid <= '0';
            elsif(chip_cnt = 1)then
                pulse_cnt_enable <= '1';
                ant0_valid <= '1';
                ant1_valid <= '0';
            elsif(chip_cnt = max_chip_cnt_value(12 downto 1)-1)then
                pulse_cnt_enable <= '0';
                ant0_valid <= '0';
                ant1_valid <= '0';
            elsif(chip_cnt = max_chip_cnt_value(12 downto 1)+1)then
                pulse_cnt_enable <= '1';
                ant0_valid <= '0';
                ant1_valid <= '1';
            elsif(chip_cnt = max_chip_cnt_value-1)then
                pulse_cnt_enable <= '0';
                ant0_valid <= '0';
                ant1_valid <= '0';
            end if;
        end if;
    end process;

    process(RESET, CLK)
    begin
        if(RESET = '1')then
            cnt_updown <= '0';
            pulse_data_cnt <= (others => '0');
        elsif(CLK'event and CLK = '1')then
            if(pulse_cnt_enable = '1')then
                if(i_sync_d = '1')then
                    if(cnt_updown = '0')then
                        if(pulse_data_cnt = max_pulse_data_cnt_value-1)then
                            cnt_updown <= '1';
                            pulse_data_cnt <= pulse_data_cnt;
                        else
                            cnt_updown <= cnt_updown;
                            pulse_data_cnt <= pulse_data_cnt + 1;
                        end if;
                    else
                        if(pulse_data_cnt = 0)then
                            cnt_updown <= cnt_updown;
                            pulse_data_cnt <= pulse_data_cnt;
                        else
                            cnt_updown <= cnt_updown;
                            pulse_data_cnt <= pulse_data_cnt - 1;
                        end if;
                    end if;
                end if;
            else
                cnt_updown <= '0';
                pulse_data_cnt <= (others => '0');
            end if;
        end if;
    end process;

    process(RESET, CLK)
    begin
        if(RESET = '1')then
            pulsed_data <= (others => '0');
        elsif(CLK'event and CLK = '1')then
            if(pulse_data_cnt = 0)then
                pulsed_data <= conv_std_logic_vector(   0, 16);
            elsif(pulse_data_cnt = 1)then
                pulsed_data <= conv_std_logic_vector( 302, 16);
            elsif(pulse_data_cnt = 2)then
                pulsed_data <= conv_std_logic_vector( 854, 16);
            elsif(pulse_data_cnt = 3)then
                pulsed_data <= conv_std_logic_vector(1618, 16);
            elsif(pulse_data_cnt = 4)then
                pulsed_data <= conv_std_logic_vector(2539, 16);
            elsif(pulse_data_cnt = 5)then
                pulsed_data <= conv_std_logic_vector(3540, 16);
            elsif(pulse_data_cnt = 6)then
                pulsed_data <= conv_std_logic_vector(4540, 16);
            elsif(pulse_data_cnt = 7)then
                pulsed_data <= conv_std_logic_vector(5461, 16);
            elsif(pulse_data_cnt = 8)then
                pulsed_data <= conv_std_logic_vector(6225, 16);
            elsif(pulse_data_cnt = 9)then
                pulsed_data <= conv_std_logic_vector(6777, 16);
            elsif(pulse_data_cnt = 10)then
                pulsed_data <= conv_std_logic_vector(7079, 16);
            end if;
        end if;
    end process;

    process(RESET, CLK)
    begin
        if(RESET = '1')then
            O_TP_DATA <= (others => '0');
        elsif(CLK'event and CLK = '1')then
            if(ant0_valid = '1')then
                if(sample_cnt = 0 or sample_cnt = 1)then
                    O_TP_DATA <= pulsed_data;
                else
                    O_TP_DATA <= (others => '0');
                end if;
            elsif(ant1_valid = '1')then
                if(sample_cnt = 2 or sample_cnt = 3)then
                    O_TP_DATA <= pulsed_data;
                else
                    O_TP_DATA <= (others => '0');
                end if;
            else
                O_TP_DATA <= (others => '0');
            end if;
        end if;
    end process;

end Behavioral;
