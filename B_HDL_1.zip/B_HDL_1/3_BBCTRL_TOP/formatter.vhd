--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Formatter                                                     --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
-- Target     : Max 4-antennas (8-clocks)                                     --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;

entity FORMATTER is
    generic (
	NUM_ANTENNA                 : natural := 4;
	DL_MAX_DATA_DELAY           : natural := 32768;
	UL_MAX_DATA_DELAY           : natural := 65536 
    );
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

	ARESET                      : in  std_logic;

	CLK                         : in  std_logic;

	BW_SEL                      : in  std_logic_vector(3 downto 0);

	PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
	PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

	SSB_OFFSET                  : in  std_logic_vector(3 downto 0);

        SSB_EXIST_IN                : in  std_logic;

        --------------------------------------------------------------------------------
        -- Map switch
        --------------------------------------------------------------------------------

	DL_10MS                     : in  std_logic;
	DL_BFN                      : in  std_logic_vector(11 downto 0);
	DL_TDD                      : in  std_logic;
	DL_SYNC                     : in  std_logic;
	DL_DATA                     : in  std_logic_vector(15 downto 0);

	UL_10MS                     : out std_logic;
	UL_TDD                      : out std_logic;
	UL_SYNC                     : out std_logic;
	UL_DATA                     : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- DDUC Side
--------------------------------------------------------------------------------

	DUC_BFN_ABNORMAL            : out std_logic;

	DUC_AIRTECH                 : out std_logic_vector(3 downto 0);
	DUC_CHBW                    : out std_logic_vector(3 downto 0);
	DUC_40MS                    : out std_logic;
	DUC_10MS                    : out std_logic;
	DUC_BFN                     : out std_logic_vector(11 downto 0);
	DUC_TDD                     : out std_logic;
	DUC_SYNC                    : out std_logic;
	DUC_DATA                    : out std_logic_vector(15 downto 0);

	DDC_AIRTECH                 : out std_logic_vector(3 downto 0);
	DDC_CHBW                    : out std_logic_vector(3 downto 0);
	DDC_10MS                    : in  std_logic;
	DDC_TDD                     : in  std_logic;
	DDC_SYNC                    : in  std_logic;
	DDC_DATA                    : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- 10ms & TDD control
--------------------------------------------------------------------------------

	SYNC_DELAY_VALUE            : in  std_logic_vector(31 downto 0);

	TDD_AND_CTRL                : in  std_logic;
	TDD_OR_CTRL                 : in  std_logic;

--------------------------------------------------------------------------------
-- Delay
--------------------------------------------------------------------------------

	DL_DELAY_VALUE              : in  std_logic_vector(31 downto 0);
	UL_DELAY_VALUE              : in  std_logic_vector(31 downto 0);

--------------------------------------------------------------------------------
-- Zero Replacement Hard Clipping
--------------------------------------------------------------------------------

	ZRHC_BYPASS                 : in  std_logic;
	ZRHC_THRESHOLD              : in  std_logic_vector(31 downto 0);
	ZRHC_OCCUR                  : out std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- Path on/off and attenuation
--------------------------------------------------------------------------------

	DL_ON                       : in  std_logic_vector(3 downto 0);
	UL_ON                       : in  std_logic_vector(3 downto 0);

	DL_ATT_0                    : in  std_logic_vector(15 downto 0);
	DL_ATT_1                    : in  std_logic_vector(15 downto 0);
	DL_ATT_2                    : in  std_logic_vector(15 downto 0);
	DL_ATT_3                    : in  std_logic_vector(15 downto 0);

	UL_ATT_0                    : in  std_logic_vector(15 downto 0);
	UL_ATT_1                    : in  std_logic_vector(15 downto 0);
	UL_ATT_2                    : in  std_logic_vector(15 downto 0);
	UL_ATT_3                    : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- Power Measure (TSSI/RSSI)
--------------------------------------------------------------------------------

	FBSW_AUTO_MODE_DONE         : in  std_logic;
	FBSW_MEASURE_DONE           : in  std_logic;
	FBSW_COUNTER                : in  std_logic_vector(6 downto 0);

	TSSI_UPDATE_MODE            : in  std_logic_vector(1 downto 0);
	TSSI_UPDATE_CNT_0           : in  std_logic_vector(4 downto 0);
	TSSI_UPDATE_CNT_1           : in  std_logic_vector(4 downto 0);
	TSSI_UPDATE_CNT_2           : in  std_logic_vector(4 downto 0);
	TSSI_UPDATE_CNT_3           : in  std_logic_vector(4 downto 0);

	RSSI_UPDATE_MODE            : in  std_logic_vector(1 downto 0);
	RSSI_UPDATE_CNT_0           : in  std_logic_vector(4 downto 0);
	RSSI_UPDATE_CNT_1           : in  std_logic_vector(4 downto 0);
	RSSI_UPDATE_CNT_2           : in  std_logic_vector(4 downto 0);
	RSSI_UPDATE_CNT_3           : in  std_logic_vector(4 downto 0);

	TSSI_0                      : out std_logic_vector(31 downto 0);
	TSSI_1                      : out std_logic_vector(31 downto 0);
	TSSI_2                      : out std_logic_vector(31 downto 0);
	TSSI_3                      : out std_logic_vector(31 downto 0);

        CUR_TSSI_0 : out std_logic_vector(31 downto 0);
        CUR_TSSI_1 : out std_logic_vector(31 downto 0);

        RSSI_0 : out std_logic_vector(31 downto 0);
        RSSI_1 : out std_logic_vector(31 downto 0);
        RSSI_2 : out std_logic_vector(31 downto 0);
        RSSI_3 : out std_logic_vector(31 downto 0);

--------------------------------------------------------------------------------
-- DUMP
--------------------------------------------------------------------------------

	DUMP_DL_10MS                : out std_logic;
	DUMP_DL_SYNC                : out std_logic;
	DUMP_DL_DATA                : out std_logic_vector(15 downto 0);

	DUMP_UL_10MS                : out std_logic;
	DUMP_UL_SYNC                : out std_logic;
	DUMP_UL_DATA                : out std_logic_vector(15 downto 0)
    );
end FORMATTER;

architecture BEHAVE of FORMATTER is

    signal dl_ftc_delay             : std_logic_vector(23 downto 0);
    signal dl_test_delay            : std_logic_vector(23 downto 0);
    signal dl_zrhc_delay            : std_logic_vector(23 downto 0);
    signal dl_att_delay             : std_logic_vector(23 downto 0);

    signal ul_ftc_delay             : std_logic_vector(23 downto 0);
    signal ul_att_delay             : std_logic_vector(23 downto 0);

    signal bfn                      : std_logic_vector(11 downto 0) := (others => '0');

    signal ddc_10ms_sh              : std_logic := '0';
    signal ddc_tdd_sh               : std_logic := '0';
    signal ddc_data_sh              : std_logic_vector(15 downto 0) := (others => '0');

    signal dl_ftc_10ms_d1           : std_logic := '0';
    signal free_run_bfn             : std_logic_vector(11 downto 0) := (others => '0');
    signal free_run_bfn_r           : std_logic_vector(11 downto 0) := (others => '0');
    signal bfn_abnormal             : std_logic := '0';
    signal bfn_abnormal_lat         : std_logic := '0';
    signal bfn_out                  : std_logic_vector(11 downto 0) := (others => '0');
    signal dl_att_10ms_d2           : std_logic := '0';

    component RST_SYNC is
    generic (
	DLY_NUM                     : natural := 4;
	MAX_FANOUT_NUM              : integer := 200
    );
    port (
	RST_IN                      : in  std_logic;
	CLK                         : in  std_logic;
	RST_OUT                     : out std_logic
    );
    end component;

    signal reset                    : std_logic;

    component FRAME_TIMING_COMPENSATOR is
    generic (
	NUM_ANTENNA                 : natural := 4;                             -- 2 or 4
	MAX_DATA_DELAY              : natural := 11264                          -- Buffer depth
    );
    port (
	RESET                       : in  std_logic;
	CLK                         : in  std_logic;

	PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

	BW_SEL                      : in  std_logic_vector(3 downto 0);

	SYNC_DELAY_VALUE            : in  std_logic_vector(31 downto 0);
	DATA_DELAY_VALUE            : in  std_logic_vector(31 downto 0);

	FTC_IN_10MS                 : in  std_logic;
	FTC_IN_TDD                  : in  std_logic;
	FTC_IN_SYNC                 : in  std_logic;
	FTC_IN_DATA                 : in  std_logic_vector(15 downto 0);

	FTC_OUT_10MS                : out std_logic;
	FTC_OUT_TDD                 : out std_logic;
	FTC_OUT_SYNC                : out std_logic;
	FTC_OUT_DATA                : out std_logic_vector(15 downto 0)
    );
    end component;

    signal dl_ftc_tdd               : std_logic;
    signal dl_ftc_10ms              : std_logic;
    signal dl_ftc_sync              : std_logic;
    signal dl_ftc_data              : std_logic_vector(15 downto 0);
    signal ul_ftc_tdd               : std_logic;
    signal ul_ftc_10ms              : std_logic;
    signal ul_ftc_sync              : std_logic;
    signal ul_ftc_data              : std_logic_vector(15 downto 0);


    component ZRHC is
    port (
	RESET                       : in  std_logic;
	CLK                         : in  std_logic;

	PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

	ZRHC_BYPASS                 : in  std_logic;
	ZRHC_THRESHOLD              : in  std_logic_vector(31 downto 0);
	ZRHC_OCCUR                  : out std_logic_vector(3 downto 0);

	ZRHC_IN_10MS                : in  std_logic;
	ZRHC_IN_TDD                 : in  std_logic;
	ZRHC_IN_SYNC                : in  std_logic;
	ZRHC_IN_DATA                : in  std_logic_vector(15 downto 0);

	ZRHC_OUT_10MS               : out std_logic;
	ZRHC_OUT_TDD                : out std_logic;
	ZRHC_OUT_SYNC               : out std_logic;
	ZRHC_OUT_DATA               : out std_logic_vector(15 downto 0)
    );
    end component;

    signal dl_zrhc_10ms             : std_logic;
    signal dl_zrhc_tdd              : std_logic;
    signal dl_zrhc_sync             : std_logic;
    signal dl_zrhc_data             : std_logic_vector(15 downto 0);

    component ATTENUATOR is
    generic (
	RND_WIDTH                   : natural := 20;
	SAT_WIDTH                   : natural := 16
    );
    port (
	RESET                       : in  std_logic;
	CLK                         : in  std_logic;

	PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

	PATH_ON                     : in  std_logic_vector(3 downto 0);
	PATH_ATT_0                  : in  std_logic_vector(15 downto 0);
	PATH_ATT_1                  : in  std_logic_vector(15 downto 0);
	PATH_ATT_2                  : in  std_logic_vector(15 downto 0);
	PATH_ATT_3                  : in  std_logic_vector(15 downto 0);

	ATT_IN_10MS                 : in  std_logic;
	ATT_IN_TDD                  : in  std_logic;
	ATT_IN_SYNC                 : in  std_logic;
	ATT_IN_DATA                 : in  std_logic_vector(15 downto 0);

	ATT_OUT_10MS                : out std_logic;
	ATT_OUT_TDD                 : out std_logic;
	ATT_OUT_SYNC                : out std_logic;
	ATT_OUT_DATA                : out std_logic_vector(SAT_WIDTH-1 downto 0)
    );
    end component;

    signal dl_att_10ms_out          : std_logic;
    signal dl_att_tdd_out           : std_logic;
    signal dl_att_sync_out          : std_logic;
    signal dl_att_data_out          : std_logic_vector(15 downto 0);
    signal dl_att_10ms              : std_logic_vector(1 downto 0);
    signal dl_att_tdd               : std_logic_vector(1 downto 0);
    signal dl_att_sync              : std_logic_vector(5 downto 0);
    signal dl_att_data              : std_logic_array16(3 downto 0);
    signal ul_att_10ms              : std_logic;
    signal ul_att_tdd               : std_logic;
    signal ul_att_sync              : std_logic;
    signal ul_att_data              : std_logic_vector(15 downto 0);

    component XSSI is
    port (
        RESET                 : in  std_logic;
        CLK                   : in  std_logic;     -- 491.52MHz
    
        I_BW_SEL              : in  std_logic_vector(3  downto 0);  -- 0x2 : 30.72MHz/ 0x3 : 61.44MHz/ 0x4 : 122.88MHz
    
        I_MEAS_SYNC           : in  std_logic;
        I_TDD                 : in  std_logic;
        I_DATA_SYNC           : in  std_logic;
        I_DATA_IQ             : in  std_logic_vector(15 downto 0);
        
        O_MEAS_DONE           : out std_logic_vector(3 downto 0);
        O_XSSI_ANT0           : out std_logic_vector(31 downto 0);
        O_XSSI_ANT1           : out std_logic_vector(31 downto 0);
        O_XSSI_ANT2           : out std_logic_vector(31 downto 0);
        O_XSSI_ANT3           : out std_logic_vector(31 downto 0)
    );
    end component;

    component XSSI_MANTISSA is
    generic (
	ACCUMULATION                : natural := 2457600
    );
    port (
	RESET                       : in  std_logic;
	CLK                         : in  std_logic;

	BW_SEL                      : in  std_logic_vector(3 downto 0);

	PWR_VALID                   : in  std_logic;
	RX_10M_FS                   : in  std_logic;
	TDD_IN                      : in  std_logic;
	D_IN_SYNC                   : in  std_logic;
	D_IN                        : in  std_logic_vector(15 downto 0);

	MEASURE_DONE                : out std_logic_vector(3 downto 0);
	XSSI_0                      : out std_logic_vector(31 downto 0);
	XSSI_1                      : out std_logic_vector(31 downto 0);
	XSSI_2                      : out std_logic_vector(31 downto 0);
	XSSI_3                      : out std_logic_vector(31 downto 0)
    );
    end component;

    signal tssi_fs                  : std_logic;
    signal tssi_sync                : std_logic;
    signal tssi_data                : std_logic_vector(15 downto 0);

    component XSSI_RPT_MANTISSA is
    port (
	RESET                       : in  std_logic;
	CLK                         : in  std_logic;

	RX_10M_FS                   : in  std_logic;
	TDD_IN                      : in  std_logic;
	D_IN_SYNC                   : in  std_logic;
	D_IN                        : in  std_logic_vector(15 downto 0);

	MEASURE_DONE                : out std_logic;
	XSSI_0                      : out std_logic_vector(31 downto 0);
	XSSI_1                      : out std_logic_vector(31 downto 0);
	XSSI_2                      : out std_logic_vector(31 downto 0);
	XSSI_3                      : out std_logic_vector(31 downto 0)
    );
    end component;

    signal tssi_done                : std_logic_vector(3 downto 0);

    signal tssi_0_i                 : std_logic_vector(31 downto 0);
    signal tssi_1_i                 : std_logic_vector(31 downto 0);
    signal tssi_2_i                 : std_logic_vector(31 downto 0);
    signal tssi_3_i                 : std_logic_vector(31 downto 0);
    signal rssi_done                : std_logic;
    signal rssi_0_i                 : std_logic_vector(31 downto 0);
    signal rssi_1_i                 : std_logic_vector(31 downto 0);
    signal rssi_2_i                 : std_logic_vector(31 downto 0);
    signal rssi_3_i                 : std_logic_vector(31 downto 0);

    signal tssi_update_en           : std_logic_vector(3 downto 0);
    signal rssi_update_en           : std_logic_vector(3 downto 0);

    signal ssb_exist_in_d                : std_logic;

begin

    PROCESSING_DELAY_DL <= dl_ftc_delay + dl_zrhc_delay + dl_att_delay + 2;
    PROCESSING_DELAY_UL <= ul_ftc_delay + ul_att_delay + 2;

    -- Buffering
    process (CLK)
    begin
	if (CLK'event and CLK = '1') then
	    dl_att_10ms <= dl_att_10ms(0) & dl_att_10ms_out;
	    dl_att_tdd  <= dl_att_tdd (0) & dl_att_tdd_out;
	    dl_att_sync <= dl_att_sync(4 downto 0) & dl_att_sync_out;
	    dl_att_data <= dl_att_data(2 downto 0) & dl_att_data_out;
	    dl_ftc_10ms_d1 <= dl_ftc_10ms;
	end if;
    end process;

--    process (CLK)
--    begin
--        if (CLK'event and CLK = '1') then
--            dl_att_10ms(1) <= dl_att_10ms(0);
--            dl_att_tdd(1)  <= dl_att_tdd(0);
--            dl_att_sync(1) <= dl_att_sync(0);
--            dl_att_sync(2) <= dl_att_sync(1);
--            dl_att_data(1) <= dl_att_data(0);
--            dl_ftc_10ms_d1 <= dl_ftc_10ms;
--            dl_att_10ms_d2 <= dl_att_10ms(1);
--        end if;
--    end process;

    -- DUC (BFN, 40ms)
    process (reset, CLK)
    begin
	if (reset = '1') then
	    DUC_BFN_ABNORMAL <= '1';
	    bfn              <= (others => '0');
	    DUC_40MS         <= '0';
	    bfn_abnormal     <= '1';
	elsif (CLK'event and CLK = '1') then
	    if (dl_att_10ms(0) = '0' and dl_att_10ms_out = '1') then
		if (bfn = DL_BFN-1) then
		    DUC_BFN_ABNORMAL <= '0';
		    bfn_abnormal     <= '0';
		else
		    DUC_BFN_ABNORMAL <= '1';
		    bfn_abnormal     <= '1';
		end if;
	    end if;
	    if (dl_att_10ms(0) = '0' and dl_att_10ms_out = '1') then
		bfn              <= DL_BFN;
	    end if;
	    if (bfn_out(1 downto 0) = SSB_OFFSET(1 downto 0)) then
		DUC_40MS         <= dl_att_10ms(1);
	    else
		DUC_40MS         <= '0';
	    end if;
	end if;
    end process;

    process (reset, CLK)
    begin
	if (reset = '1') then
	    bfn_out              <= (others => '0');
	elsif (CLK'event and CLK = '1') then
	    if (bfn_abnormal = '1') then
		bfn_out         <= free_run_bfn_r;
	    else
		bfn_out         <= bfn;
	    end if;
		DUC_BFN          <= bfn_out;
	end if;
    end process;


    process (CLK)
    begin
	if (CLK'event and CLK = '1') then
	    if(bfn_abnormal = '1') then
		bfn_abnormal_lat <= '1';
	    end if;
	end if;
    end process;


    -- bfn free running
    process (reset, CLK)
    begin
	if (reset = '1') then
	    free_run_bfn     <= (others => '0');
	elsif (CLK'event and CLK = '1') then
	    if (bfn_abnormal_lat = '1') then
		if ((dl_ftc_10ms and (not dl_ftc_10ms_d1)) = '1') then
		    if (free_run_bfn = 4095) then
			free_run_bfn <= (others => '0');
		    else
			free_run_bfn <= free_run_bfn + 1;
		    end if;
		end if;
	    end if;
	end if;
    end process;
    --free run BFN retiming
    process (CLK)
    begin
	if (CLK'event and CLK = '1') then
	    if (dl_att_10ms(0) = '0' and dl_att_10ms_out = '1') then
		free_run_bfn_r <= free_run_bfn;
	    end if;
	end if;
    end process;
    -- DUC
    process (reset, CLK)
    begin
	if (reset = '1') then
	    DUC_AIRTECH <= (others => '0');
	    DUC_CHBW    <= (others => '0');
	    DUC_10MS    <= '0';
	    DUC_TDD     <= '0';
	    DUC_SYNC    <= '0';
	    DUC_DATA    <= (others => '0');
	elsif (CLK'event and CLK = '1') then
	    DUC_AIRTECH <= (others => '0');
	    DUC_CHBW    <= BW_SEL;
	    DUC_10MS    <= dl_att_10ms(1);
	    DUC_TDD     <= dl_att_tdd(1);
	    
	    DUC_SYNC    <= dl_att_sync(2);
	    
--        if (dl_att_sync(2) = '1' or dl_att_sync(3) = '1') then 
--            DUC_DATA    <= dl_att_data_out;
--        elsif (dl_att_sync(4) = '1' or dl_att_sync(5) = '1') then
--            DUC_DATA    <= dl_att_data(3);
--        else
--            DUC_DATA    <= (others => '0');    
--        end if;    
	    DUC_DATA    <= dl_att_data(1);
	end if;
    end process;
    

--    process (reset, CLK)
--    begin
--	if (reset = '1') then	    
--	    DUC_SYNC    <= '0';
--	    DUC_DATA    <= (others => '0');
--	elsif (CLK'event and CLK = '1') then
--	   if (dl_att_sync(0) = '1') or (dl_att_sync(2) = '1')then 
--           DUC_SYNC    <= dl_att_sync(2);
--           DUC_DATA    <= dl_att_data(0);       
--       end if;
--	end if;
--    end process;    
    
--    DUC_DATA    <= dl_att_data(1);

    -- DDC
    process (reset, CLK)
    begin
	if (reset = '1') then
	    DDC_AIRTECH <= (others => '0');
	    DDC_CHBW    <= (others => '0');
	    ddc_10ms_sh <= '0';
	    ddc_tdd_sh  <= '0';
	    ddc_data_sh <= (others => '0');
	elsif (CLK'event and CLK = '1') then
	    DDC_AIRTECH <= (others => '0');
	    DDC_CHBW    <= BW_SEL;
	    ddc_10ms_sh <= DDC_10MS;
	    ddc_tdd_sh  <= DDC_TDD;
	    ddc_data_sh <= DDC_DATA;
	end if;
    end process;

    -- Mapper output
    process (reset, CLK)
    begin
	if (reset = '1') then
	    UL_10MS <= '0';
	    UL_TDD  <= '0';
	    UL_SYNC <= '0';
	    UL_DATA <= (others => '0');
	elsif (CLK'event and CLK = '1') then
	    UL_10MS <= ul_ftc_10ms;
	    UL_TDD  <= ul_ftc_tdd;
	    UL_SYNC <= ul_ftc_sync;
	    UL_DATA <= ul_ftc_data;
	end if;
    end process;

    -- Dump
    DUMP_DL_10MS <= dl_zrhc_10ms;
    DUMP_DL_SYNC <= dl_zrhc_sync;
    DUMP_DL_DATA <= dl_zrhc_data;

    DUMP_UL_10MS <= DDC_10MS;
    DUMP_UL_SYNC <= DDC_SYNC;
    DUMP_UL_DATA <= DDC_DATA;

--------------------------------------------------------------------------------
-- Power measure
--------------------------------------------------------------------------------

    -- 40ms start
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            -- if (DL_BFN(1 downto 0) = SSB_OFFSET(1 downto 0)) then
            --     tssi_fs <= dl_ftc_10ms;
            -- end if;
            ssb_exist_in_d <= SSB_EXIST_IN;
            tssi_fs        <= dl_ftc_10ms and ssb_exist_in_d;

            tssi_sync      <= dl_ftc_sync;
            tssi_data      <= dl_ftc_data;
        end if;
    end process;

--    -- 40ms start
--    process (CLK)
--    begin
--        if (CLK'event and CLK = '1') then
--            -- if (DL_BFN(1 downto 0) = SSB_OFFSET(1 downto 0)) then
--            --     tssi_fs <= dl_ftc_10ms;
--            -- end if;
--            ssb_exist_in_d <= SSB_EXIST_IN;
--            tssi_fs        <= dl_att_10ms_out and ssb_exist_in_d;

--            tssi_sync      <= dl_att_sync_out;
--            tssi_data      <= dl_att_data_out;
--        end if;
--    end process;

    -- TSSI result update
    process (reset, CLK)
    begin
        if (reset = '1') then
            tssi_update_en <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            if (TSSI_UPDATE_MODE = "00") then
                if (FBSW_MEASURE_DONE = '1') then
                    tssi_update_en <= (others => '1');
                else
                    tssi_update_en <= (others => '0');
                end if;
            elsif (TSSI_UPDATE_MODE = "01") then
                if (FBSW_MEASURE_DONE = '1' and FBSW_AUTO_MODE_DONE = '0') then                
                    if (FBSW_COUNTER(3 downto 0) = X"1") then
                        tssi_update_en(0) <= '1';
                    end if;
                    if (FBSW_COUNTER(3 downto 0) = X"4") then
                        tssi_update_en(1) <= '1';
                    end if;
                    -- if (FBSW_COUNTER(3 downto 0) = TSSI_UPDATE_CNT_2) then
                    --     tssi_update_en(2) <= '1';
                    -- end if;
                    -- if (FBSW_COUNTER(3 downto 0) = TSSI_UPDATE_CNT_3) then
                    --     tssi_update_en(3) <= '1';
                    -- end if;
                else
                    tssi_update_en <= (others => '0');
                end if;
            else
                tssi_update_en <= tssi_done;
            end if;
        end if;
    end process;

    process (reset, CLK)
    begin
        if (reset = '1') then
            TSSI_0 <= (others => '0');
            TSSI_1 <= (others => '0');
            TSSI_2 <= (others => '0');
            TSSI_3 <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            if (tssi_update_en(0) = '1') then
                TSSI_0 <= tssi_0_i;
            end if;
            if (tssi_update_en(1) = '1') then
                TSSI_1 <= tssi_1_i;
            end if;
            -- if (tssi_update_en(2) = '1') then
            --     TSSI_2 <= tssi_2_i;
            -- end if;
            -- if (tssi_update_en(3) = '1') then
            --     TSSI_3 <= tssi_3_i;
            -- end if;
        end if;
    end process;

    process (reset, CLK)
    begin
        if (reset = '1') then
            CUR_TSSI_0                  <= (others => '0');
            CUR_TSSI_1                  <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            if (tssi_done(0) = '1') then
                CUR_TSSI_0              <= tssi_0_i;
            end if;
            if (tssi_done(1) = '1') then
                CUR_TSSI_1              <= tssi_1_i;
            end if;
        end if;
    end process;

    -- RSSI result update
    process (reset, CLK)
    begin
	if (reset = '1') then
	    rssi_update_en <= (others => '0');
	elsif (CLK'event and CLK = '1') then
	    if (RSSI_UPDATE_MODE = "00") then
		if (FBSW_MEASURE_DONE = '1') then
		    rssi_update_en <= (others => '1');
		else
		    rssi_update_en <= (others => '0');
		end if;
	    elsif (RSSI_UPDATE_MODE = "01") then
		if (FBSW_MEASURE_DONE = '1') and (FBSW_AUTO_MODE_DONE = '0') then
		    if (FBSW_COUNTER(4 downto 0) = RSSI_UPDATE_CNT_0) then
			rssi_update_en(0) <= '1';
		    end if;
		    if (FBSW_COUNTER(4 downto 0) = RSSI_UPDATE_CNT_1) then
			rssi_update_en(1) <= '1';
		    end if;
		    if (FBSW_COUNTER(4 downto 0) = RSSI_UPDATE_CNT_2) then
			rssi_update_en(2) <= '1';
		    end if;
		    if (FBSW_COUNTER(4 downto 0) = RSSI_UPDATE_CNT_3) then
			rssi_update_en(3) <= '1';
		    end if;
		else
		    rssi_update_en <= (others => '0');
		end if;
	    else
		rssi_update_en <= rssi_done & rssi_done & rssi_done & rssi_done;
	    end if;
	end if;
    end process;

    process (reset, CLK)
    begin
	if (reset = '1') then
	    RSSI_0 <= (others => '0');
	    RSSI_1 <= (others => '0');
	    RSSI_2 <= (others => '0');
	    RSSI_3 <= (others => '0');
	elsif (CLK'event and CLK = '1') then
	    if (rssi_update_en(0) = '1') then
		RSSI_0 <= rssi_0_i;
	    end if;
	    if (rssi_update_en(1) = '1') then
		RSSI_1 <= rssi_1_i;
	    end if;
	    if (rssi_update_en(2) = '1') then
		RSSI_2 <= rssi_2_i;
	    end if;
	    if (rssi_update_en(3) = '1') then
		RSSI_3 <= rssi_3_i;
	    end if;
	end if;
    end process;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_RESET : RST_SYNC
    generic map(
	DLY_NUM                     => 4                                       ,--: natural := 4;
	MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
	RST_IN                      => ARESET                                  ,--: in  std_logic;
	CLK                         => CLK                                     ,--: in  std_logic;
	RST_OUT                     => reset                                    --: out std_logic
    );

--------------------------------------------------------------------------------
-- DL component mapping
--------------------------------------------------------------------------------

--    process (reset, CLK)
--    begin
--    if (CLK'event and CLK = '1') then
--        dl_att_10ms_out     <=   DL_10MS ;
--        dl_att_tdd_out      <=   DL_TDD  ;
--        dl_att_sync_out     <=   DL_SYNC ;
--        dl_att_data_out     <=   DL_DATA ;
--    end if;
--    end process;

    u_DL_FTC : FRAME_TIMING_COMPENSATOR
    generic map(
	NUM_ANTENNA                 => NUM_ANTENNA                             ,--: natural := 4;
	MAX_DATA_DELAY              => DL_MAX_DATA_DELAY                        --: natural := 11264
    )
    port map(
	RESET                       => reset                                   ,--: in  std_logic;
	CLK                         => CLK                                     ,--: in  std_logic;

	PROCESSING_DELAY            => dl_ftc_delay                            ,--: out std_logic_vector(23 downto 0);

	BW_SEL                      => BW_SEL                                  ,--: in  std_logic_vector(3 downto 0);

	SYNC_DELAY_VALUE            => SYNC_DELAY_VALUE                        ,--: in  std_logic_vector(31 downto 0);
	DATA_DELAY_VALUE            => DL_DELAY_VALUE                          ,--: in  std_logic_vector(31 downto 0);

	FTC_IN_10MS                 => DL_10MS                                 ,--: in  std_logic;
	FTC_IN_TDD                  => DL_TDD                                  ,--: in  std_logic;
	FTC_IN_SYNC                 => DL_SYNC                                 ,--: in  std_logic;
	FTC_IN_DATA                 => DL_DATA                                 ,--: in  std_logic_vector(15 downto 0);

	FTC_OUT_10MS                => dl_ftc_10ms                             ,--: out std_logic;
	FTC_OUT_TDD                 => dl_ftc_tdd                              ,--: out std_logic;
	FTC_OUT_SYNC                => dl_ftc_sync                             ,--: out std_logic;
	FTC_OUT_DATA                => dl_ftc_data                              --: out std_logic_vector(15 downto 0)
    );


    u_ZRHC : ZRHC
    port map(
	RESET                       => reset                                   ,--: in  std_logic;
	CLK                         => CLK                                     ,--: in  std_logic;

	PROCESSING_DELAY            => dl_zrhc_delay                           ,--: out std_logic_vector(23 downto 0);

	ZRHC_BYPASS                 => ZRHC_BYPASS                             ,--: in  std_logic;
	ZRHC_THRESHOLD              => ZRHC_THRESHOLD                          ,--: in  std_logic_vector(31 downto 0);
	ZRHC_OCCUR                  => ZRHC_OCCUR                              ,--: out std_logic_vector(3 downto 0);

	ZRHC_IN_10MS                => dl_ftc_10ms                             ,--: in  std_logic;
	ZRHC_IN_TDD                 => dl_ftc_tdd                              ,--: in  std_logic;
	ZRHC_IN_SYNC                => dl_ftc_sync                             ,--: in  std_logic;
	ZRHC_IN_DATA                => dl_ftc_data                             ,--: in  std_logic_vector(15 downto 0);

	ZRHC_OUT_10MS               => dl_zrhc_10ms                            ,--: out std_logic;
	ZRHC_OUT_TDD                => dl_zrhc_tdd                             ,--: out std_logic;
	ZRHC_OUT_SYNC               => dl_zrhc_sync                            ,--: out std_logic;
	ZRHC_OUT_DATA               => dl_zrhc_data                             --: out std_logic_vector(15 downto 0)
    );

    u_DL_ATT : ATTENUATOR
    generic map(
	RND_WIDTH                   => 19                                      ,--: natural := 20;
	SAT_WIDTH                   => 16                                       --: natural := 16
    )
    port map(
	RESET                       => reset                                   ,--: in  std_logic;
	CLK                         => CLK                                     ,--: in  std_logic;

	PROCESSING_DELAY            => dl_att_delay                            ,--: out std_logic_vector(23 downto 0);

	PATH_ON                     => DL_ON                                   ,--: in  std_logic_vector(3 downto 0);
	PATH_ATT_0                  => DL_ATT_0                                ,--: in  std_logic_vector(15 downto 0);
	PATH_ATT_1                  => DL_ATT_1                                ,--: in  std_logic_vector(15 downto 0);
	PATH_ATT_2                  => DL_ATT_2                                ,--: in  std_logic_vector(15 downto 0);
	PATH_ATT_3                  => DL_ATT_3                                ,--: in  std_logic_vector(15 downto 0);

	ATT_IN_10MS                 => dl_zrhc_10ms                            ,--: in  std_logic;
	ATT_IN_TDD                  => dl_zrhc_tdd                             ,--: in  std_logic;
	ATT_IN_SYNC                 => dl_zrhc_sync                            ,--: in  std_logic;
	ATT_IN_DATA                 => dl_zrhc_data                            ,--: in  std_logic_vector(15 downto 0);

	ATT_OUT_10MS                => dl_att_10ms_out                         ,--: out std_logic;
	ATT_OUT_TDD                 => dl_att_tdd_out                          ,--: out std_logic;
	ATT_OUT_SYNC                => dl_att_sync_out                         ,--: out std_logic;
	ATT_OUT_DATA                => dl_att_data_out                          --: out std_logic_vector(SAT_WIDTH-1 downto 0)
    );

--------------------------------------------------------------------------------
-- UL component mapping
--------------------------------------------------------------------------------

    u_UL_ATT : ATTENUATOR
    generic map(
	RND_WIDTH                   => 22                                      ,--: natural := 20;
	SAT_WIDTH                   => 16                                       --: natural := 16
    )
    port map(
	RESET                       => reset                                   ,--: in  std_logic;
	CLK                         => CLK                                     ,--: in  std_logic;

	PROCESSING_DELAY            => ul_att_delay                            ,--: out std_logic_vector(23 downto 0);

	PATH_ON                     => UL_ON                                   ,--: in  std_logic_vector(3 downto 0);
	PATH_ATT_0                  => UL_ATT_0                                ,--: in  std_logic_vector(15 downto 0);
	PATH_ATT_1                  => UL_ATT_1                                ,--: in  std_logic_vector(15 downto 0);
	PATH_ATT_2                  => UL_ATT_2                                ,--: in  std_logic_vector(15 downto 0);
	PATH_ATT_3                  => UL_ATT_3                                ,--: in  std_logic_vector(15 downto 0);

	ATT_IN_10MS                 => ddc_10ms_sh                             ,--: in  std_logic;
	ATT_IN_TDD                  => ddc_tdd_sh                              ,--: in  std_logic;
	ATT_IN_SYNC                 => DDC_SYNC                                ,--: in  std_logic;
	ATT_IN_DATA                 => ddc_data_sh                             ,--: in  std_logic_vector(15 downto 0);

	ATT_OUT_10MS                => ul_att_10ms                             ,--: out std_logic;
	ATT_OUT_TDD                 => ul_att_tdd                              ,--: out std_logic;
	ATT_OUT_SYNC                => ul_att_sync                             ,--: out std_logic;
	ATT_OUT_DATA                => ul_att_data                              --: out std_logic_vector(SAT_WIDTH-1 downto 0)
    );

    u_UL_FTC : FRAME_TIMING_COMPENSATOR
    generic map(
	NUM_ANTENNA                 => NUM_ANTENNA                             ,--: natural := 4;
	MAX_DATA_DELAY              => UL_MAX_DATA_DELAY                        --: natural := 11264
    )
    port map(
	RESET                       => reset                                   ,--: in  std_logic;
	CLK                         => CLK                                     ,--: in  std_logic;

	PROCESSING_DELAY            => ul_ftc_delay                            ,--: out std_logic_vector(23 downto 0);

	BW_SEL                      => BW_SEL                                  ,--: in  std_logic_vector(3 downto 0);

	SYNC_DELAY_VALUE            => UL_DELAY_VALUE                          ,--: in  std_logic_vector(31 downto 0);
	DATA_DELAY_VALUE            => UL_DELAY_VALUE                          ,--: in  std_logic_vector(31 downto 0);

	FTC_IN_10MS                 => ul_att_10ms                             ,--: in  std_logic;
	FTC_IN_TDD                  => ul_att_tdd                              ,--: in  std_logic;
	FTC_IN_SYNC                 => ul_att_sync                             ,--: in  std_logic;
	FTC_IN_DATA                 => ul_att_data                             ,--: in  std_logic_vector(15 downto 0);

	FTC_OUT_10MS                => ul_ftc_10ms                             ,--: out std_logic;
	FTC_OUT_TDD                 => ul_ftc_tdd                              ,--: out std_logic;
	FTC_OUT_SYNC                => ul_ftc_sync                             ,--: out std_logic;
	FTC_OUT_DATA                => ul_ftc_data                              --: out std_logic_vector(15 downto 0)
    );

--------------------------------------------------------------------------------
-- Power measurement component mapping
--------------------------------------------------------------------------------

---- RF2225 TSSI calculation 
--    U_TSSI : XSSI 
--    port map(
--        RESET                      => reset                                   ,--: in  std_logic;
--        CLK                        => CLK                                     ,--: in  std_logic;     -- 491.52MHz
                                            
--        I_BW_SEL                   => BW_SEL                                  ,--: in  std_logic_vector(3  downto 0);  -- 0x2 : 30.72MHz/ 0x3 : 61.44MHz/ 0x4 : 122.88MHz

--        I_MEAS_SYNC                => tssi_fs                                 ,--: in  std_logic;
--        I_TDD                      => '1'                                     ,--: in  std_logic;
--        I_DATA_SYNC                => tssi_sync                               ,--: in  std_logic;
--        I_DATA_IQ                  => tssi_data                               ,--: in  std_logic_vector(15 downto 0);
        
--        O_MEAS_DONE                => tssi_done                               ,--: out std_logic;
--        O_XSSI_ANT0                => tssi_0_i                                ,--: out std_logic_vector(31 downto 0);
--        O_XSSI_ANT1                => tssi_1_i                                ,--: out std_logic_vector(31 downto 0);
--        O_XSSI_ANT2                => tssi_2_i                                ,--: out std_logic_vector(31 downto 0);
--        O_XSSI_ANT3                => tssi_3_i                                 --: out std_logic_vector(31 downto 0)
--    );


 -- RF2240A mantisa calculation
    u_TSSI : XSSI_MANTISSA
    generic map(
	ACCUMULATION                => 9830400                                  --: natural := 2457600
    )
    port map(
	RESET                       => reset                                   ,--: in  std_logic;
	CLK                         => CLK                                     ,--: in  std_logic;

	BW_SEL                      => BW_SEL                                  ,--: in  std_logic_vector(3 downto 0);

	PWR_VALID                   => '1'                                     ,--: in  std_logic;
	RX_10M_FS                   => tssi_fs                                 ,--: in  std_logic;
	TDD_IN                      => '1'                                     ,--: in  std_logic;
	D_IN_SYNC                   => tssi_sync                               ,--: in  std_logic;
	D_IN                        => tssi_data                               ,--: in  std_logic_vector(15 downto 0);

	MEASURE_DONE                => tssi_done                               ,--: out std_logic_vector(3 downto 0);
	XSSI_0                      => tssi_0_i                                ,--: out std_logic_vector(31 downto 0);
	XSSI_1                      => tssi_1_i                                ,--: out std_logic_vector(31 downto 0);
	XSSI_2                      => tssi_2_i                                ,--: out std_logic_vector(31 downto 0);
	XSSI_3                      => tssi_3_i                                 --: out std_logic_vector(31 downto 0)
    );

--    u_TSSI : XSSI_RPT_MANTISSA
--    port map(
--        RESET                       => reset                                   ,--: in  std_logic;
--        CLK                         => CLK                                     ,--: in  std_logic;
--
--        RX_10M_FS                   => dl_ftc_10ms                             ,--: in  std_logic;
--        TDD_IN                      => '1'                                     ,--: in  std_logic;
--        D_IN_SYNC                   => dl_ftc_sync                             ,--: in  std_logic;
--        D_IN                        => dl_ftc_data                             ,--: in  std_logic_vector(15 downto 0);
--
--        MEASURE_DONE                => tssi_done                               ,--: out std_logic;
--        XSSI_0                      => tssi_0_i                                ,--: out std_logic_vector(31 downto 0);
--        XSSI_1                      => tssi_1_i                                ,--: out std_logic_vector(31 downto 0);
--        XSSI_2                      => tssi_2_i                                ,--: out std_logic_vector(31 downto 0);
--        XSSI_3                      => tssi_3_i                                 --: out std_logic_vector(31 downto 0)
--    );

    u_RSSI : XSSI_RPT_MANTISSA
    port map(
	RESET                       => reset                                   ,--: in  std_logic;
	CLK                         => CLK                                     ,--: in  std_logic;

	RX_10M_FS                   => ul_att_10ms                             ,--: in  std_logic;
	TDD_IN                      => '1'                                     ,--: in  std_logic;
	D_IN_SYNC                   => ul_att_sync                             ,--: in  std_logic;
	D_IN                        => ul_att_data                             ,--: in  std_logic_vector(15 downto 0);

	MEASURE_DONE                => rssi_done                               ,--: out std_logic;
	XSSI_0                      => rssi_0_i                                ,--: out std_logic_vector(31 downto 0);
	XSSI_1                      => rssi_1_i                                ,--: out std_logic_vector(31 downto 0);
	XSSI_2                      => rssi_2_i                                ,--: out std_logic_vector(31 downto 0);
	XSSI_3                      => rssi_3_i                                 --: out std_logic_vector(31 downto 0)
    );

end BEHAVE;