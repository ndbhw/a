--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : BBCTRL Top (Master FPGA)                                      --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2021.12.15                                                    --
-- Target     : RF4430                                                        --
--                                                                            --
--------------------------------------------------------------------------------
-- Feature (V3.0, 2017-05-17 based)                                           --
--------------------------------------------------------------------------------
--  1. Max CPRI port : 2                                                      --
--  2. Max mapper : 2                                                         --
--  3. Max formatter : 2                                                      --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;
use WORK.RU_FPGA_CONFIG.ALL;

entity BBCTRL_TOP is
    port (
--------------------------------------------------------------------------------
-- External System PLL
--------------------------------------------------------------------------------

	EXT_SYSPLL_LOCK_IN          : in  std_logic;

--------------------------------------------------------------------------------
-- SYSCTRL_TOP
--------------------------------------------------------------------------------

	RST_BBCTRL                  : in  std_logic;	

	CLK_SYS                     : in  std_logic;
	CLK_SYSX2                   : in  std_logic;
	CLK_SYSX3                   : in  std_logic;
	CLK_SYSX4                   : in  std_logic;
	CLK_SYSX5                   : in  std_logic;
	CLK_SYSX6                   : in  std_logic;
	CLK_SYSX8                   : in  std_logic;
	CLK_SYSX10                  : in  std_logic;
	CLK_SYSX12                  : in  std_logic;
	CLK_SYSX16                  : in  std_logic;
	CLK_SYSX20                  : in  std_logic;

	TDD_AND_CTRL_IN             : in  std_logic;
	TDD_OR_CTRL_IN              : in  std_logic;

	SSB_OFFSET                  : in  std_logic_vector(3 downto 0);
    DL_BFN                      : in  std_logic_vector(11 downto 0);
--------------------------------------------------------------------------------
-- CPU_TOP
--------------------------------------------------------------------------------

	RST_CPUIF                   : in  std_logic;
	CLK_CPUIF                   : in  std_logic;

--------------------------------------------------------------------------------
-- CPUIF_TOP
--------------------------------------------------------------------------------

	WREN_CPUIF_IN               : in  std_logic;
	RDEN_CPUIF_IN               : in  std_logic;
	ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);
	WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
	RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
	RDVAL_CPUIF_OUT             : out std_logic;

--------------------------------------------------------------------------------
-- LPHY
--------------------------------------------------------------------------------


        lphy_dl_frame_sync          : in  std_logic_vector ( 1 downto 0); 
        lphy_dl_en                  : in  std_logic_vector ( 3 downto 0); 
        lphy_dl_i                   : in  std_logic_array16( 3 downto 0);
        lphy_dl_q                   : in  std_logic_array16( 3 downto 0);


        lphy_ul_frame_sync          : out std_logic_vector ( 1 downto 0);
        lphy_ul_en                  : out std_logic_vector ( 3 downto 0);
        lphy_ul_i                   : out std_logic_array16( 3 downto 0);
        lphy_ul_q                   : out std_logic_array16( 3 downto 0);
    



--------------------------------------------------------------------------------
-- DSP_TOP
--------------------------------------------------------------------------------

	DL_BFN_OK                   : out std_logic;

	DL_AIRTECH_OUT              : out std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
	DL_CHBW_OUT                 : out std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
	DL_TDD_OUT                  : out std_logic;
	DL_40MS_OUT                 : out std_logic;
	DL_BFN_STRB_OUT             : out std_logic;
	DL_BFN_OUT                  : out std_logic_vector(11 downto 0);
	DL_SYNC_OUT                 : out std_logic_vector(DL_BBIQARY_NUM-1 downto 0);
	DL_IQ_OUT                   : out std_logic_array16(DL_BBIQARY_NUM-1 downto 0);

	UL_AIRTECH_OUT              : out std_logic_array4(UL_BBIQARY_NUM-1 downto 0);
	UL_CHBW_OUT                 : out std_logic_array4(UL_BBIQARY_NUM-1 downto 0);
	UL_TDD_IN                   : in  std_logic;
	UL_BFN_STRB_IN              : in  std_logic;
	UL_SYNC_IN                  : in  std_logic_vector(UL_BBIQARY_NUM-1 downto 0);
	UL_IQ_IN                    : in  std_logic_array16(UL_BBIQARY_NUM-1 downto 0);

--------------------------------------------------------------------------------
-- MISC_TOP
--------------------------------------------------------------------------------

	DUMP_BFN_STRB_OUT           : out std_logic_vector(1 downto 0);
	DUMP_DATA_OUT               : out std_logic_array32(1 downto 0);
	DUMP_DVLD_OUT               : out std_logic_vector(1 downto 0);

	SIG_SUS_DLOFF_IN            : in  std_logic_vector(CPRI_NUM-1 downto 0); -- this must be updated from deleted part to keep function operation as before

	FBSW_START_TRIG_IN          : in  std_logic;
	FBSW_AUTO_MODE_DONE_IN      : in  std_logic_vector(FB_PATH_NUM-1 downto 0);
	FBSW_PWR_MSR_UDT_IN         : in  std_logic;

	SSB_EXIST_IN                : in  std_logic
    );
end BBCTRL_TOP;

architecture BEHAVE of BBCTRL_TOP is

    constant NUM_CPRI               : natural := CPRI_NUM;
    constant NUM_FMT                : natural := UL_BBIQARY_NUM;
    constant NUM_MAP                : natural := TOTAL_MAP_NUM;

    signal dl_cdc_delay             : std_logic_array24(NUM_CPRI-1 downto 0) := (others => (others => '0'));
--    signal dl_comp_if_delay         : std_logic_array24(NUM_CPRI-1 downto 0) := (others => (others => '0'));
    signal dl_cpri_if_delay         : std_logic_array24(NUM_CPRI-1 downto 0) := (others => (others => '0'));
    signal dl_cpri_switch_delay     : std_logic_vector(23 downto 0) := (others => '0');
    signal dl_mapper_delay          : std_logic_array24(NUM_MAP-1 downto 0) := (others => (others => '0'));
    signal dl_map_switch_delay      : std_logic_vector(23 downto 0) := (others => '0');
    signal dl_formatter_delay       : std_logic_array24(NUM_FMT-1 downto 0) := (others => (others => '0'));

    signal ul_cdc_delay             : std_logic_array24(NUM_CPRI-1 downto 0) := (others => (others => '0'));
--    signal ul_comp_if_delay         : std_logic_array24(NUM_CPRI-1 downto 0) := (others => (others => '0'));
    signal ul_cpri_if_delay         : std_logic_array24(NUM_CPRI-1 downto 0) := (others => (others => '0'));
--    signal ul_cpri_align_delay      : std_logic_array24(NUM_CPRI-1 downto 0) := (others => (others => '0'));
    signal ul_cpri_switch_delay     : std_logic_vector(23 downto 0) := (others => '0');
    signal ul_mapper_delay          : std_logic_array24(NUM_MAP-1 downto 0) := (others => (others => '0'));
    signal ul_map_switch_delay      : std_logic_vector(23 downto 0) := (others => '0');
    signal ul_formatter_delay       : std_logic_array24(NUM_FMT-1 downto 0) := (others => (others => '0'));

    signal dl_cpri_if_delay_r       : std_logic_array24(NUM_CPRI*2-1 downto 0);
    signal ul_cpri_if_delay_r       : std_logic_array24(NUM_CPRI*2-1 downto 0);
    signal ul_cpri_align_delay_r    : std_logic_array24(NUM_CPRI*2-1 downto 0);

    signal ru_comp_on               : std_logic_vector(NUM_CPRI-1 downto 0);
    signal cpri_rx_i                : std_logic_array16(CPRI_NUM-1 downto 0);
    signal cpri_rx_q                : std_logic_array16(CPRI_NUM-1 downto 0);

    component RST_SYNC is
    generic (
	DLY_NUM                     : natural := 4;
	MAX_FANOUT_NUM              : integer := 200
    );
    port (
	RST_IN                      : in  std_logic;
	CLK                         : in  std_logic;
	RST_OUT                     : out std_logic
    );
    end component;

    signal reset_sysx8              : std_logic := '1';
    signal reset_sysx4              : std_logic := '1';

    component CPUIF_BBCTRL is
    generic (
	OFFSET                      : std_logic_vector(3 downto 0) := x"4";
	NUM_CPRI                    : natural := 8;
	NUM_MAP                     : natural := 8;
	NUM_FMT                     : natural := 8
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

	CLK_AUX                     : in  std_logic;
	CLK_SYSX8                   : in  std_logic;

	RESET                       : in  std_logic;

	DL_CDC_DELAY                : in  std_logic_array24(NUM_CPRI-1 downto 0);
--        DL_COMP_IF_DELAY            : in  std_logic_array24(NUM_CPRI-1 downto 0);
	DL_CPRI_IF_DELAY            : in  std_logic_array24(NUM_CPRI-1 downto 0);
	DL_CPRI_SWITCH_DELAY        : in  std_logic_vector(23 downto 0);
	DL_MAPPER_DELAY             : in  std_logic_array24(NUM_MAP-1 downto 0);
	DL_MAP_SWITCH_DELAY         : in  std_logic_vector(23 downto 0);
	DL_FORMATTER_DELAY          : in  std_logic_array24(NUM_FMT-1 downto 0);

	UL_CDC_DELAY                : in  std_logic_array24(NUM_CPRI-1 downto 0);
--        UL_COMP_IF_DELAY            : in  std_logic_array24(NUM_CPRI-1 downto 0);
	UL_CPRI_IF_DELAY            : in  std_logic_array24(NUM_CPRI-1 downto 0);
--        UL_CPRI_ALIGN_DELAY         : in  std_logic_array24(NUM_CPRI-1 downto 0);
	UL_CPRI_SWITCH_DELAY        : in  std_logic_vector(23 downto 0);
	UL_MAPPER_DELAY             : in  std_logic_array24(NUM_MAP-1 downto 0);
	UL_MAP_SWITCH_DELAY         : in  std_logic_vector(23 downto 0);
	UL_FORMATTER_DELAY          : in  std_logic_array24(NUM_FMT-1 downto 0);

--------------------------------------------------------------------------------
-- Dump
--------------------------------------------------------------------------------

	DUMP_EN                     : out std_logic;
	DUMP_SEL                    : out std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

	BW_SEL                      : out std_logic_array4(NUM_MAP-1 downto 0);
	SPEED_SEL                   : out std_logic_array8(NUM_MAP-1 downto 0);    -- CPRI Line rate [7 : 5G / 15 : 10G]
	LINE_RCF_RATE               : out std_logic_array8(NUM_CPRI-1 downto 0);   -- CPRI Line rate [7 : 5G / 15 : 10G]

--        DIV_BYPASS                  : out std_logic_vector(NUM_CPRI-1 downto 0);
--        DIV_DL_BYPASS               : out std_logic_vector(NUM_CPRI-1 downto 0);
--        DIV_UL_BYPASS               : out std_logic_vector(NUM_CPRI-1 downto 0);
--        COMP_BYPASS                 : out std_logic_vector(NUM_CPRI*2-1 downto 0);
--        COMP_DL_BYPASS              : out std_logic_vector(NUM_CPRI*2-1 downto 0);
--        COMP_UL_BYPASS              : out std_logic_vector(NUM_CPRI*2-1 downto 0);

--------------------------------------------------------------------------------
-- Mapper control
--------------------------------------------------------------------------------

	DL_MAP_WR_EN                : out std_logic_vector(NUM_MAP-1 downto 0);
	DL_MAP_WR_ADDR              : out std_logic_vector(4 downto 0);
	DL_MAP_WR_DATA              : out std_logic_vector(6 downto 0);
	DL_MAP_RD_DATA              : in  std_logic_array7(NUM_MAP-1 downto 0);

	UL_MAP_WR_EN                : out std_logic_vector(NUM_MAP-1 downto 0);
	UL_MAP_WR_ADDR              : out std_logic_vector(5 downto 0);
	UL_MAP_WR_DATA              : out std_logic_vector(6 downto 0);
	UL_MAP_RD_DATA              : in  std_logic_array7(NUM_MAP-1 downto 0);

	MAP_CPRI                    : out std_logic_array8(NUM_MAP-1 downto 0);

--------------------------------------------------------------------------------
-- S/W control
--------------------------------------------------------------------------------

	MAPPER_UL_MAP               : out std_logic_array16(NUM_MAP-1 downto 0);
	FORMATTER_DL_MAP            : out std_logic_array16(NUM_FMT-1 downto 0);
--        CASCADE_UL_SUM              : out std_logic_array16(2 downto 0);

--------------------------------------------------------------------------------
-- Formatter control
--------------------------------------------------------------------------------

	SYNC_DELAY_VALUE            : out std_logic_array32(NUM_FMT-1 downto 0);

	DL_DELAY_VALUE              : out std_logic_array32(NUM_FMT-1 downto 0);
	UL_DELAY_VALUE              : out std_logic_array32(NUM_FMT-1 downto 0);

	ZRHC_BYPASS                 : out std_logic_vector(NUM_FMT-1 downto 0);
	ZRHC_THRESHOLD              : out std_logic_array32(NUM_FMT-1 downto 0);
--        ZRHC_OCCUR                  : in  std_logic_array4(NUM_FMT-1 downto 0);

	DL_ON                       : out std_logic_array4(NUM_FMT-1 downto 0);
	UL_ON                       : out std_logic_array4(NUM_FMT-1 downto 0);

	DL_ATT_0                    : out std_logic_array16(NUM_FMT-1 downto 0);
	DL_ATT_1                    : out std_logic_array16(NUM_FMT-1 downto 0);
	DL_ATT_2                    : out std_logic_array16(NUM_FMT-1 downto 0);
	DL_ATT_3                    : out std_logic_array16(NUM_FMT-1 downto 0);

	UL_ATT_0                    : out std_logic_array16(NUM_FMT-1 downto 0);
	UL_ATT_1                    : out std_logic_array16(NUM_FMT-1 downto 0);
	UL_ATT_2                    : out std_logic_array16(NUM_FMT-1 downto 0);
	UL_ATT_3                    : out std_logic_array16(NUM_FMT-1 downto 0);

	TSSI_UPDATE_MODE            : out std_logic_vector(1 downto 0);
	TSSI_UPDATE_CNT_0           : out std_logic_array5(NUM_FMT-1 downto 0);
	TSSI_UPDATE_CNT_1           : out std_logic_array5(NUM_FMT-1 downto 0);
	TSSI_UPDATE_CNT_2           : out std_logic_array5(NUM_FMT-1 downto 0);
	TSSI_UPDATE_CNT_3           : out std_logic_array5(NUM_FMT-1 downto 0);

	RSSI_UPDATE_MODE            : out std_logic_vector(1 downto 0);
	RSSI_UPDATE_CNT_0           : out std_logic_array5(NUM_FMT-1 downto 0);
	RSSI_UPDATE_CNT_1           : out std_logic_array5(NUM_FMT-1 downto 0);
	RSSI_UPDATE_CNT_2           : out std_logic_array5(NUM_FMT-1 downto 0);
	RSSI_UPDATE_CNT_3           : out std_logic_array5(NUM_FMT-1 downto 0);

	TSSI_0                      : in  std_logic_array32(NUM_FMT-1 downto 0);
	TSSI_1                      : in  std_logic_array32(NUM_FMT-1 downto 0);
	TSSI_2                      : in  std_logic_array32(NUM_FMT-1 downto 0);
	TSSI_3                      : in  std_logic_array32(NUM_FMT-1 downto 0);

	CUR_TSSI_0                  : in std_logic_array32(NUM_FMT-1 downto 0);
    CUR_TSSI_1                  : in std_logic_array32(NUM_FMT-1 downto 0);

	RSSI_0                      : in  std_logic_array32(NUM_FMT-1 downto 0);
	RSSI_1                      : in  std_logic_array32(NUM_FMT-1 downto 0);
	RSSI_2                      : in  std_logic_array32(NUM_FMT-1 downto 0);
	RSSI_3                      : in  std_logic_array32(NUM_FMT-1 downto 0);

--------------------------------------------------------------------------------
-- Cascade repeater mode scale factor
--------------------------------------------------------------------------------

--        SCALE_FACTOR                : out std_logic_array3(5 downto 0);

--------------------------------------------------------------------------------
-- Debug
--------------------------------------------------------------------------------
	DL_10MS_CNT   				: in  std_logic_vector(31 downto 0);
	DL_SYNC_CNT   				: in  std_logic_vector(31 downto 0);
	DL_DATA       				: in  std_logic_vector(15 downto 0);
	DL_DATA_SEL   				: out std_logic_vector(1 downto 0);
--------------------------------------------------------------------------------
-- Test pattern
--------------------------------------------------------------------------------

	TEST_MODE                   : out std_logic_array4(NUM_FMT-1 downto 0);
	TP_EN                       : out std_logic;
	TP_MEM_PEN                  : out std_logic; -- A/B port enable
	TP_MEM_AWEN                 : out std_logic; -- A port write enable
	TP_MEM_WRADDR               : out std_logic_vector(14 downto 0);
	TP_MEM_WRDATA               : out std_logic_vector(31 downto 0); -- 31..16 : Q data, 15..0 : I data
	TEST_DC_I                   : out std_logic_vector(15 downto 0);
	TEST_DC_Q                   : out std_logic_vector(15 downto 0);
	TEST_NCO                    : out std_logic_vector(5 downto 0);

--------------------------------------------------------------------------------
-- CPUIF_TOP
--------------------------------------------------------------------------------

	WREN_CPUIF_IN               : in  std_logic;
	RDEN_CPUIF_IN               : in  std_logic;
	ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);
	WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
	RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
	RDVAL_CPUIF_OUT             : out std_logic
    );
    end component;

    signal dump_en                  : std_logic;
    signal dump_sel                 : std_logic_vector(7 downto 0);
    signal bw_sel                   : std_logic_array4(NUM_MAP-1 downto 0);
    signal speed_sel                : std_logic_array8(NUM_MAP-1 downto 0);
--    signal div_bypass               : std_logic_vector(NUM_CPRI-1 downto 0);
--    signal div_dl_bypass            : std_logic_vector(NUM_CPRI-1 downto 0);
--    signal div_ul_bypass            : std_logic_vector(NUM_CPRI-1 downto 0);
--    signal comp_bypass              : std_logic_vector(NUM_CPRI*2-1 downto 0);
--    signal comp_dl_bypass           : std_logic_vector(NUM_CPRI*2-1 downto 0);
--    signal comp_ul_bypass           : std_logic_vector(NUM_CPRI*2-1 downto 0);
    signal dl_map_wr_en             : std_logic_vector(NUM_MAP-1 downto 0);
    signal dl_map_wr_addr           : std_logic_vector(4 downto 0);
    signal dl_map_wr_data           : std_logic_vector(6 downto 0);
    signal dl_map_rd_data           : std_logic_array7(NUM_MAP-1 downto 0);
    signal ul_map_wr_en             : std_logic_vector(NUM_MAP-1 downto 0);
    signal ul_map_wr_addr           : std_logic_vector(5 downto 0);
    signal ul_map_wr_data           : std_logic_vector(6 downto 0);
    signal ul_map_rd_data           : std_logic_array7(NUM_MAP-1 downto 0);
    signal map_cpri                 : std_logic_array8(NUM_MAP-1 downto 0);
    signal mapper_ul_map            : std_logic_array16(NUM_MAP-1 downto 0);
    signal formatter_dl_map         : std_logic_array16(NUM_FMT-1 downto 0);
--    signal cascade_ul_sum           : std_logic_array16(2 downto 0);
    signal sync_delay_value         : std_logic_array32(NUM_FMT-1 downto 0);
    signal dl_delay_value           : std_logic_array32(NUM_FMT-1 downto 0);
    signal ul_delay_value           : std_logic_array32(NUM_FMT-1 downto 0);
    signal zrhc_bypass              : std_logic_vector(NUM_FMT-1 downto 0);
    signal zrhc_threshold           : std_logic_array32(NUM_FMT-1 downto 0);
    signal zrhc_occur               : std_logic_array4(NUM_FMT-1 downto 0);
    signal dl_on                    : std_logic_array4(NUM_FMT-1 downto 0);
    signal dl_on_max                : std_logic_array4(7 downto 0) := (others => (others => '0'));
    signal ul_on                    : std_logic_array4(NUM_FMT-1 downto 0);
    signal dl_att_0                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal dl_att_1                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal dl_att_2                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal dl_att_3                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal ul_att_0                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal ul_att_1                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal ul_att_2                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal ul_att_3                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal tssi_update_mode         : std_logic_vector(1 downto 0);
    signal tssi_update_cnt_0        : std_logic_array5(NUM_FMT-1 downto 0);
    signal tssi_update_cnt_1        : std_logic_array5(NUM_FMT-1 downto 0);
    signal tssi_update_cnt_2        : std_logic_array5(NUM_FMT-1 downto 0);
    signal tssi_update_cnt_3        : std_logic_array5(NUM_FMT-1 downto 0);
    signal rssi_update_mode         : std_logic_vector(1 downto 0);
    signal rssi_update_cnt_0        : std_logic_array5(NUM_FMT-1 downto 0);
    signal rssi_update_cnt_1        : std_logic_array5(NUM_FMT-1 downto 0);
    signal rssi_update_cnt_2        : std_logic_array5(NUM_FMT-1 downto 0);
    signal rssi_update_cnt_3        : std_logic_array5(NUM_FMT-1 downto 0);
    signal tssi_0                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal tssi_1                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal tssi_2                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal tssi_3                   : std_logic_array32(NUM_FMT-1 downto 0);

    signal cur_tssi_0               : std_logic_array32(NUM_FMT-1 downto 0);
    signal cur_tssi_1               : std_logic_array32(NUM_FMT-1 downto 0);

    signal rssi_0                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal rssi_1                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal rssi_2                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal rssi_3                   : std_logic_array32(NUM_FMT-1 downto 0);
--    signal scale_factor             : std_logic_array3(5 downto 0);
    signal test_mode                : std_logic_array4(NUM_FMT-1 downto 0);
    signal test_dc_i                : std_logic_vector(15 downto 0);
    signal test_dc_q                : std_logic_vector(15 downto 0);
    signal test_nco                 : std_logic_vector(5 downto 0);
	signal dl_10ms_cnt : std_logic_vector(31 downto 0);
	signal dl_sync_cnt : std_logic_vector(31 downto 0);
	signal dl_data     : std_logic_vector(15 downto 0);
	signal dl_data_sel : std_logic_vector(1 downto 0);
    component BB_TIMER is
    port (
	CLK                         : in  std_logic;

	LINE_RATE                   : in  std_logic_vector( 3 downto 0);

	FSYNC_CPRI                  : in  std_logic;
	FSYNC_FREE                  : out std_logic
    );
    end component;

    signal rx_bfn_free_run          : std_logic_vector(NUM_CPRI-1 downto 0);

    

   signal rx_cif_10ms               : std_logic_vector(NUM_CPRI-1 downto 0);
   signal rx_cif_bfn                : std_logic_array12(NUM_CPRI-1 downto 0);
   signal rx_cif_tdd                : std_logic_vector(NUM_CPRI-1 downto 0);
   signal rx_cif_sync               : std_logic_vector(NUM_CPRI-1 downto 0);
   signal rx_cif_data_i             : std_logic_array16(NUM_CPRI-1 downto 0);
   signal rx_cif_data_q             : std_logic_array16(NUM_CPRI-1 downto 0);

   signal tx_sbif_ref_10ms          : std_logic_vector(NUM_CPRI-1 downto 0);
   signal tx_cif_sync               : std_logic_vector(NUM_CPRI-1 downto 0);
   signal tx_cif_data_i             : std_logic_array16(NUM_CPRI-1 downto 0);
   signal tx_cif_data_q             : std_logic_array16(NUM_CPRI-1 downto 0);

   
    signal rx_10ms                  : std_logic_vector( NUM_CPRI-1 downto 0);
    signal rx_bfn                   : std_logic_array12(NUM_CPRI-1 downto 0);
    signal rx_tdd                   : std_logic_vector( NUM_CPRI-1 downto 0);
    signal rx_sync                  : std_logic_vector( NUM_CPRI-1 downto 0);
    signal rx_data_i                : std_logic_array16(NUM_CPRI-1 downto 0);
    signal rx_data_q                : std_logic_array16(NUM_CPRI-1 downto 0);

    signal cpri_tx_i_0              : std_logic_array16(NUM_CPRI-1 downto 0);
    signal cpri_tx_q_0              : std_logic_array16(NUM_CPRI-1 downto 0);


    signal tx_csw_10ms              : std_logic_vector(NUM_CPRI-1 downto 0);
    signal tx_csw_tdd               : std_logic_vector(NUM_CPRI-1 downto 0);
    signal tx_csw_sync              : std_logic_vector(NUM_CPRI-1 downto 0);
    signal tx_csw_data_i            : std_logic_array16(NUM_CPRI-1 downto 0);
    signal tx_csw_data_q            : std_logic_array16(NUM_CPRI-1 downto 0);

    signal rx_map_10ms              : std_logic_vector(NUM_MAP-1 downto 0);
    signal rx_map_bfn               : std_logic_array12(NUM_MAP-1 downto 0);
    signal rx_map_tdd               : std_logic_vector(NUM_MAP-1 downto 0);
    signal rx_map_sync              : std_logic_vector(NUM_MAP-1 downto 0);
    signal rx_map_data_i            : std_logic_array16(NUM_MAP-1 downto 0);
    signal rx_map_data_q            : std_logic_array16(NUM_MAP-1 downto 0);

    signal tx_map_10ms              : std_logic_vector(NUM_MAP-1 downto 0);
    signal tx_map_tdd               : std_logic_vector(NUM_MAP-1 downto 0);
    signal tx_map_sync              : std_logic_vector(NUM_MAP-1 downto 0);
    signal tx_map_data_i            : std_logic_array16(NUM_MAP-1 downto 0);
    signal tx_map_data_q            : std_logic_array16(NUM_MAP-1 downto 0);


    signal dl_map_10ms              : std_logic_vector(NUM_MAP-1 downto 0);
    signal dl_map_bfn               : std_logic_array12(NUM_MAP-1 downto 0);
    signal dl_map_tdd               : std_logic_vector(NUM_MAP-1 downto 0);
    signal dl_map_sync              : std_logic_vector(NUM_MAP-1 downto 0);
    signal dl_map_data              : std_logic_array16(NUM_MAP-1 downto 0);
    signal ul_map_10ms              : std_logic_vector(NUM_MAP-1 downto 0);
    signal ul_map_tdd               : std_logic_vector(NUM_MAP-1 downto 0);
    signal ul_map_sync              : std_logic_vector(NUM_MAP-1 downto 0);
    signal ul_map_data              : std_logic_array16(NUM_MAP-1 downto 0);
    signal bw_sel_fmt               : std_logic_array4(NUM_FMT-1 downto 0);
    signal dl_fmt_10ms              : std_logic_vector(NUM_FMT-1 downto 0);
    signal dl_fmt_bfn               : std_logic_array12(NUM_FMT-1 downto 0);
    signal dl_fmt_tdd               : std_logic_vector(NUM_FMT-1 downto 0);
    signal dl_fmt_sync              : std_logic_vector(NUM_FMT-1 downto 0);
    signal dl_fmt_sync_d1              : std_logic_vector(NUM_FMT-1 downto 0);
    signal dl_fmt_data              : std_logic_array16(NUM_FMT-1 downto 0);
    signal ul_fmt_10ms              : std_logic_vector(NUM_FMT-1 downto 0);
    signal ul_fmt_tdd               : std_logic_vector(NUM_FMT-1 downto 0);
    signal ul_fmt_sync              : std_logic_vector(NUM_FMT-1 downto 0);
    signal ul_fmt_data              : std_logic_array16(NUM_FMT-1 downto 0);

    component FORMATTER is
    generic (
	NUM_ANTENNA                 : natural := 4;
	DL_MAX_DATA_DELAY           : natural := 32768;
	UL_MAX_DATA_DELAY           : natural := 65536 
    );
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

	ARESET                      : in  std_logic;

	CLK                         : in  std_logic;

	BW_SEL                      : in  std_logic_vector(3 downto 0);

	PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
	PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

	SSB_OFFSET                  : in  std_logic_vector(3 downto 0);

	SSB_EXIST_IN                : in  std_logic;

--------------------------------------------------------------------------------
-- MAPPER Side
--------------------------------------------------------------------------------

	DL_10MS                     : in  std_logic;
	DL_BFN                      : in  std_logic_vector(11 downto 0);
	DL_TDD                      : in  std_logic;
	DL_SYNC                     : in  std_logic;
	DL_DATA                     : in  std_logic_vector(15 downto 0);

	UL_10MS                     : out std_logic;
	UL_TDD                      : out std_logic;
	UL_SYNC                     : out std_logic;
	UL_DATA                     : out std_logic_vector(15 downto 0);

	DUC_BFN_ABNORMAL            : out std_logic;

--------------------------------------------------------------------------------
-- DDUC Side
--------------------------------------------------------------------------------

	DUC_AIRTECH                 : out std_logic_vector(3 downto 0);
	DUC_CHBW                    : out std_logic_vector(3 downto 0);
	DUC_40MS                    : out std_logic;
	DUC_10MS                    : out std_logic;
	DUC_BFN                     : out std_logic_vector(11 downto 0);
	DUC_TDD                     : out std_logic;
	DUC_SYNC                    : out std_logic;
	DUC_DATA                    : out std_logic_vector(15 downto 0);

	DDC_AIRTECH                 : out std_logic_vector(3 downto 0);
	DDC_CHBW                    : out std_logic_vector(3 downto 0);
	DDC_10MS                    : in  std_logic;
	DDC_TDD                     : in  std_logic;
	DDC_SYNC                    : in  std_logic;
	DDC_DATA                    : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- 10ms & TDD control
--------------------------------------------------------------------------------

	SYNC_DELAY_VALUE            : in  std_logic_vector(31 downto 0);

	TDD_AND_CTRL                : in  std_logic;
	TDD_OR_CTRL                 : in  std_logic;

--------------------------------------------------------------------------------
-- Delay
--------------------------------------------------------------------------------

	DL_DELAY_VALUE              : in  std_logic_vector(31 downto 0);
	UL_DELAY_VALUE              : in  std_logic_vector(31 downto 0);

--------------------------------------------------------------------------------
-- Zero Replacement Hard Clipping
--------------------------------------------------------------------------------

	ZRHC_BYPASS                 : in  std_logic;
	ZRHC_THRESHOLD              : in  std_logic_vector(31 downto 0);
	ZRHC_OCCUR                  : out std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- Path on/off and attenuation
--------------------------------------------------------------------------------

	DL_ON                       : in  std_logic_vector(3 downto 0);
	UL_ON                       : in  std_logic_vector(3 downto 0);

	DL_ATT_0                    : in  std_logic_vector(15 downto 0);
	DL_ATT_1                    : in  std_logic_vector(15 downto 0);
	DL_ATT_2                    : in  std_logic_vector(15 downto 0);
	DL_ATT_3                    : in  std_logic_vector(15 downto 0);

	UL_ATT_0                    : in  std_logic_vector(15 downto 0);
	UL_ATT_1                    : in  std_logic_vector(15 downto 0);
	UL_ATT_2                    : in  std_logic_vector(15 downto 0);
	UL_ATT_3                    : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- Power Measure (TSSI/RSSI)
--------------------------------------------------------------------------------

	FBSW_AUTO_MODE_DONE         : in  std_logic;
	FBSW_MEASURE_DONE           : in  std_logic;
	FBSW_COUNTER                : in  std_logic_vector(6 downto 0);

	TSSI_UPDATE_MODE            : in  std_logic_vector(1 downto 0);
	TSSI_UPDATE_CNT_0           : in  std_logic_vector(4 downto 0);
	TSSI_UPDATE_CNT_1           : in  std_logic_vector(4 downto 0);
	TSSI_UPDATE_CNT_2           : in  std_logic_vector(4 downto 0);
	TSSI_UPDATE_CNT_3           : in  std_logic_vector(4 downto 0);

	RSSI_UPDATE_MODE            : in  std_logic_vector(1 downto 0);
	RSSI_UPDATE_CNT_0           : in  std_logic_vector(4 downto 0);
	RSSI_UPDATE_CNT_1           : in  std_logic_vector(4 downto 0);
	RSSI_UPDATE_CNT_2           : in  std_logic_vector(4 downto 0);
	RSSI_UPDATE_CNT_3           : in  std_logic_vector(4 downto 0);

	TSSI_0                      : out std_logic_vector(31 downto 0);
	TSSI_1                      : out std_logic_vector(31 downto 0);
	TSSI_2                      : out std_logic_vector(31 downto 0);
	TSSI_3                      : out std_logic_vector(31 downto 0);

	CUR_TSSI_0                  : out std_logic_vector(31 downto 0);
    CUR_TSSI_1                  : out std_logic_vector(31 downto 0);

	RSSI_0                      : out std_logic_vector(31 downto 0);
	RSSI_1                      : out std_logic_vector(31 downto 0);
	RSSI_2                      : out std_logic_vector(31 downto 0);
	RSSI_3                      : out std_logic_vector(31 downto 0);

--------------------------------------------------------------------------------
-- DUMP
--------------------------------------------------------------------------------

	DUMP_DL_10MS                : out std_logic;
	DUMP_DL_SYNC                : out std_logic;
	DUMP_DL_DATA                : out std_logic_vector(15 downto 0);

	DUMP_UL_10MS                : out std_logic;
	DUMP_UL_SYNC                : out std_logic;
	DUMP_UL_DATA                : out std_logic_vector(15 downto 0)
    );
    end component;

    signal duc_bfn_abnormal         : std_logic_vector(NUM_FMT-1 downto 0);
    signal duc_bfn_normal_max       : std_logic_vector(7 downto 0) := (others => '0');
    signal duc_40ms                 : std_logic_vector(NUM_FMT-1 downto 0);
    signal duc_40ms_max             : std_logic_vector(7 downto 0) := (others => '0');
    signal duc_10ms                 : std_logic_vector(NUM_FMT-1 downto 0);
    signal duc_10ms_max             : std_logic_vector(7 downto 0) := (others => '0');
    signal duc_bfn                  : std_logic_array12(NUM_FMT-1 downto 0);
    signal duc_bfn_max              : std_logic_array12(7 downto 0) := (others => (others => '0'));
    signal duc_tdd                  : std_logic_vector(NUM_FMT-1 downto 0);
    signal duc_tdd_max              : std_logic_vector(7 downto 0) := (others => '0');
    signal ddc_10ms                 : std_logic_vector(NUM_FMT-1 downto 0);
    signal ddc_tdd                  : std_logic_vector(NUM_FMT-1 downto 0);

    signal fbsw_start_trig_buf      : std_logic_vector(2 downto 0) := (others => '0');
    signal fbsw_pwr_msr_udt_buf     : std_logic_vector(2 downto 0) := (others => '0');

    signal fbsw_auto_mode_done      : std_logic := '1';
    signal fbsw_measure_done        : std_logic := '0';
    signal fbsw_cnt_buf             : std_logic_vector(6 downto 0) := (others => '0');
    signal fbsw_counter             : std_logic_vector(6 downto 0) := (others => '0');

    signal dump_dl_10ms             : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_dl_sync             : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_dl_sync_sh          : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_dl_data             : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal dump_ul_10ms             : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_ul_sync             : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_ul_data             : std_logic_array16(7 downto 0) := (others => (others => '0'));

    signal dump_sel_dl_10ms         : std_logic := '0';
    signal dump_sel_dl_sync         : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_sel_dl_data_i       : std_logic_vector(15 downto 0) := (others => '0');
    signal dump_sel_dl_data_q       : std_logic_vector(15 downto 0) := (others => '0');
    signal dump_sel_ul_10ms         : std_logic := '0';
    signal dump_sel_ul_sync         : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_sel_ul_data_i       : std_logic_vector(15 downto 0) := (others => '0');
    signal dump_sel_ul_data_q       : std_logic_vector(15 downto 0) := (others => '0');

    component TRAFFIC_SELECTION is
	generic (
	    NUM_ANTENNA : natural := 4
	);
	port (
	    RESET            : in  std_logic;
	    CLK              : in  std_logic;
	    PROCESSING_DELAY : out std_logic_vector(23 downto 0);
	    BW_SEL           : in  std_logic_vector(3 downto 0);
	    TEST_MODE        : in  std_logic_vector(3 downto 0);
	    TP_MEM_PEN       : in  std_logic;
	    TP_MEM_AWEN      : in  std_logic;
	    TP_MEM_WRADDR    : in  std_logic_vector(14 downto 0);
	    TP_MEM_WRDATA    : in  std_logic_vector(31 downto 0);
	    TEST_DC_I        : in  std_logic_vector(15 downto 0);
	    TEST_DC_Q        : in  std_logic_vector(15 downto 0);
	    TEST_NCO         : in  std_logic_vector(5 downto 0);
	    TP_IN_10MS       : in  std_logic;
	    TP_IN_TDD        : in  std_logic;
	    TP_IN_SYNC       : in  std_logic;
	    TP_IN_DATA       : in  std_logic_vector(15 downto 0);
	    TP_OUT_10MS      : out std_logic;
	    TP_OUT_TDD       : out std_logic;
	    TP_OUT_SYNC      : out std_logic;
	    TP_OUT_DATA      : out std_logic_vector(15 downto 0)
	);
    end component TRAFFIC_SELECTION;
    signal dl_tp_10ms    : std_logic_vector(NUM_FMT-1 downto 0);
    signal dl_tp_tdd     : std_logic_vector(NUM_FMT-1 downto 0);
    signal dl_tp_sync    : std_logic_vector(NUM_FMT-1 downto 0);
    signal dl_tp_data    : std_logic_array16(NUM_FMT-1 downto 0);
    signal tp_mem_pen    : std_logic; -- A/B port enable
    signal tp_mem_awen   : std_logic; -- A port write enable
    signal tp_mem_wraddr : std_logic_vector(14 downto 0);
    signal tp_mem_wrdata : std_logic_vector(31 downto 0); -- 31..16 : Q data, 15..0 : I data
    signal tp_mem_10ms   : std_logic;
    signal tp_mem_tdd    : std_logic;
    signal tp_mem_sync   : std_logic;
    signal tp_mem_data   : std_logic_vector(15 downto 0);
    signal tp_en         : std_logic;


--attribute MARK_DEBUG : string;
--attribute MARK_DEBUG of rx_bfn_free_run: signal is "TRUE";
--attribute MARK_DEBUG of dl_fmt_10ms: signal is "TRUE";
--attribute MARK_DEBUG of dl_fmt_sync: signal is "TRUE";
--attribute MARK_DEBUG of dl_fmt_data: signal is "TRUE";
--attribute MARK_DEBUG of tp_mem_10ms: signal is "TRUE";
--attribute MARK_DEBUG of tp_mem_sync: signal is "TRUE";
--attribute MARK_DEBUG of tp_mem_data: signal is "TRUE";

    component BBCTRL_LPHY_DLUL_IF is
    port (
    --------------------------------------------------------------------------------
    -- Common
    --------------------------------------------------------------------------------

            CLK_SYSX8                   : in  std_logic;

            BW_SEL                      : in  std_logic_vector(3 downto 0);
            PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
            PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

    --------------------------------------------------------------------------------
    -- BB_TOP
    --------------------------------------------------------------------------------

            I_DL_FSYNC                  :in  std_logic;    -- 1 clock frame(10ms) sync  
            I_DL_TDD                    :in  std_logic;       
            I_DL_DATA_I                 :in  std_logic_array16(1 downto 0);         
            I_DL_DATA_Q                 :in  std_logic_array16(1 downto 0);     

            O_UL_FSYNC                  :out std_logic;    -- 1 clock frame(10ms) sync   
            O_UL_TDD                    :out std_logic;       
            O_UL_VLD                    :out std_logic_vector( 1 downto 0);    
            O_UL_DATA_I                 :out std_logic_array16(1 downto 0);      
            O_UL_DATA_Q                 :out std_logic_array16(1 downto 0);      

    --------------------------------------------------------------------------------
    -- FORMATTER
    --------------------------------------------------------------------------------

            O_DL_10MS                   : out std_logic;
            O_DL_TDD                    : out std_logic;
            O_DL_SYNC                   : out std_logic;
            O_DL_DATA                   : out std_logic_vector(15 downto 0);

            I_UL_FSYNC                  : in  std_logic;
            I_UL_TDD                    : in  std_logic;
            I_UL_SYNC                   : in  std_logic;
            I_UL_DATA                   : in  std_logic_vector(15 downto 0) 
        );
    end component;
    
    signal dl_dduc_if_delay         : std_logic_array24(NUM_FMT-1 downto 0);
    signal ul_dduc_if_delay         : std_logic_array24(NUM_FMT-1 downto 0);

begin

--------------------------------------------------------------------------------
-- Port mapping
--------------------------------------------------------------------------------

    u_UL_FMT : for i in NUM_FMT-1 downto 0 generate
	ddc_10ms(i) <= UL_BFN_STRB_IN;
	ddc_tdd(i)  <= UL_TDD_IN;

	dl_on_max(i)            <= dl_on(i);
	duc_bfn_normal_max(i)   <= not duc_bfn_abnormal(i);
	duc_40ms_max(i)         <= duc_40ms(i);
	duc_10ms_max(i)         <= duc_10ms(i);
	duc_bfn_max(i)          <= duc_bfn(i);
	duc_tdd_max(i)          <= duc_tdd(i);
    end generate;

    DL_BFN_OK       <= duc_bfn_normal_max(0) when dl_on_max(0) /= 0 else
		       duc_bfn_normal_max(1) when dl_on_max(1) /= 0 else
		       duc_bfn_normal_max(2) when dl_on_max(2) /= 0 else
		       duc_bfn_normal_max(3) when dl_on_max(3) /= 0 else
		       duc_bfn_normal_max(4) when dl_on_max(4) /= 0 else
		       duc_bfn_normal_max(5) when dl_on_max(5) /= 0 else
		       duc_bfn_normal_max(6) when dl_on_max(6) /= 0 else
		       duc_bfn_normal_max(7) when dl_on_max(7) /= 0 else
		       duc_bfn_normal_max(0);

    DL_TDD_OUT      <= duc_tdd_max(0) when dl_on_max(0) /= 0 else
		       duc_tdd_max(1) when dl_on_max(1) /= 0 else
		       duc_tdd_max(2) when dl_on_max(2) /= 0 else
		       duc_tdd_max(3) when dl_on_max(3) /= 0 else
		       duc_tdd_max(4) when dl_on_max(4) /= 0 else
		       duc_tdd_max(5) when dl_on_max(5) /= 0 else
		       duc_tdd_max(6) when dl_on_max(6) /= 0 else
		       duc_tdd_max(7) when dl_on_max(7) /= 0 else
		       duc_tdd_max(0);

    DL_40MS_OUT     <= duc_40ms_max(0) when dl_on_max(0) /= 0 else
		       duc_40ms_max(1) when dl_on_max(1) /= 0 else
		       duc_40ms_max(2) when dl_on_max(2) /= 0 else
		       duc_40ms_max(3) when dl_on_max(3) /= 0 else
		       duc_40ms_max(4) when dl_on_max(4) /= 0 else
		       duc_40ms_max(5) when dl_on_max(5) /= 0 else
		       duc_40ms_max(6) when dl_on_max(6) /= 0 else
		       duc_40ms_max(7) when dl_on_max(7) /= 0 else
		       duc_40ms_max(0);

    DL_BFN_STRB_OUT <= duc_10ms_max(0) when dl_on_max(0) /= 0 else
		       duc_10ms_max(1) when dl_on_max(1) /= 0 else
		       duc_10ms_max(2) when dl_on_max(2) /= 0 else
		       duc_10ms_max(3) when dl_on_max(3) /= 0 else
		       duc_10ms_max(4) when dl_on_max(4) /= 0 else
		       duc_10ms_max(5) when dl_on_max(5) /= 0 else
		       duc_10ms_max(6) when dl_on_max(6) /= 0 else
		       duc_10ms_max(7) when dl_on_max(7) /= 0 else
		       duc_10ms_max(0);

    DL_BFN_OUT      <= duc_bfn_max(0) when dl_on_max(0) /= 0 else
		       duc_bfn_max(1) when dl_on_max(1) /= 0 else
		       duc_bfn_max(2) when dl_on_max(2) /= 0 else
		       duc_bfn_max(3) when dl_on_max(3) /= 0 else
		       duc_bfn_max(4) when dl_on_max(4) /= 0 else
		       duc_bfn_max(5) when dl_on_max(5) /= 0 else
		       duc_bfn_max(6) when dl_on_max(6) /= 0 else
		       duc_bfn_max(7) when dl_on_max(7) /= 0 else
		       duc_bfn_max(0);

	--------------------------------------------------------------------------------
	-- Debug
	--------------------------------------------------------------------------------
	process (CLK_SYSX8,RST_BBCTRL)
	begin
		if(RST_BBCTRL = '1') then
			dl_data <= (others => '0');
		else
			if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
				if(dl_data_sel = "00") then
					dl_data <= dl_fmt_data(0);
				elsif(dl_data_sel = "01") then
					dl_data <= dump_dl_data(0);
				elsif (dl_data_sel = "10") then
					dl_data <= tp_mem_data;
				else
					dl_data <= x"DEAD";
				end if;
			end if;
		end if;
	end process;
	process (CLK_SYSX8,RST_BBCTRL)
	begin
		if(RST_BBCTRL = '1') then
			dl_10ms_cnt <= (others => '0');
		else
			if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
				if(rx_bfn_free_run(0) = '1') then
					dl_10ms_cnt <= dl_10ms_cnt+1;
				else
					dl_10ms_cnt <= dl_10ms_cnt;
				end if;
			end if;
		end if;
	end process;
	process (CLK_SYSX8,RST_BBCTRL)
	begin
		if(RST_BBCTRL = '1') then
			dl_sync_cnt <= (others => '0');
		else
			if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
				if(dl_fmt_sync(0) = '1') then
					dl_sync_cnt <= dl_sync_cnt+1;
				else
					dl_sync_cnt <= dl_sync_cnt;
				end if;
			end if;
		end if;
	end process;


--------------------------------------------------------------------------------
-- xSSI update
--------------------------------------------------------------------------------

    process (CLK_SYSX8)
    begin
	if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
	    fbsw_start_trig_buf  <= fbsw_start_trig_buf(1 downto 0) & FBSW_START_TRIG_IN;
	    fbsw_pwr_msr_udt_buf <= fbsw_pwr_msr_udt_buf(1 downto 0) & FBSW_PWR_MSR_UDT_IN;
	end if;
    end process;

    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            fbsw_auto_mode_done					<=  FBSW_AUTO_MODE_DONE_IN(0);
        end if;
    end process;

    process (CLK_SYSX8)
    begin
	if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
	    if (fbsw_pwr_msr_udt_buf(2 downto 1) = "01") then
            fbsw_measure_done <= '1';
	    else
            fbsw_measure_done <= '0';
	    end if;
	end if;
    end process;

    process (CLK_SYSX8)
    begin
	if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
	    if (fbsw_start_trig_buf(2 downto 1) = "01") then
		fbsw_cnt_buf <= (others => '0');
		fbsw_counter <= (others => '0');
	    else
		if (fbsw_pwr_msr_udt_buf(2 downto 1) = "01") then
		    fbsw_cnt_buf <= fbsw_cnt_buf + 1;
		    fbsw_counter <= fbsw_cnt_buf;
		end if;
	    end if;
	end if;
    end process;

--------------------------------------------------------------------------------
-- Dump
--------------------------------------------------------------------------------

    -- Path selection (DL)
    process (CLK_SYSX8)
    begin
	if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
	    dump_dl_sync_sh <= dump_dl_sync;
	    for i in 7 downto 0 loop
	    if (dump_sel(4 downto 2) = i) then
		dump_sel_dl_10ms   <= dump_dl_10ms(i);
		dump_sel_dl_sync   <= dump_sel_dl_sync(6 downto 0) & dump_dl_sync_sh(i);
		dump_sel_dl_data_i <= dump_sel_dl_data_q;
		dump_sel_dl_data_q <= dump_dl_data(i);
	    end if;
	    end loop;
	end if;
    end process;

    -- Path selection (UL)
    process (CLK_SYSX8)
    begin
	if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
	    for i in 7 downto 0 loop
	    if (dump_sel(4 downto 2) = i) then
		dump_sel_ul_10ms   <= dump_ul_10ms(i);
		dump_sel_ul_sync   <= dump_sel_ul_sync(6 downto 0) & dump_ul_sync(i);
		dump_sel_ul_data_i <= dump_sel_ul_data_q;
		dump_sel_ul_data_q <= dump_ul_data(i);
	    end if;
	    end loop;
	end if;
    end process;

    -- DL/UL selection
    process (CLK_SYSX8)
    begin
	if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
	    if (dump_sel(6) = '0') then
			DUMP_BFN_STRB_OUT(0) <= dump_sel_dl_10ms;
			DUMP_DATA_OUT(0)     <= dump_sel_dl_data_i & dump_sel_dl_data_q;
			for i in 3 downto 0 loop
				if (dump_sel(1 downto 0) = i) then
				    DUMP_DVLD_OUT(0)     <= dump_sel_dl_sync(i*2+1);
				end if;
			end loop;
	    else
			DUMP_BFN_STRB_OUT(0) <= dump_sel_ul_10ms;
			DUMP_DATA_OUT(0)     <= dump_sel_ul_data_i & dump_sel_ul_data_q;
			for i in 3 downto 0 loop
				if (dump_sel(1 downto 0) = i) then
				    DUMP_DVLD_OUT(0)     <= dump_sel_ul_sync(i*2+1);
				end if;
			end loop;
	    end if;
	end if;
    end process;

    DUMP_BFN_STRB_OUT(1) <= '0';
    DUMP_DATA_OUT(1)     <= (others => '0');
    DUMP_DVLD_OUT(1)     <= '0';

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_CPUIF : CPUIF_BBCTRL
    generic map(
	OFFSET                      => x"4"                                    ,--: std_logic_vector(3 downto 0) := x"4";
	NUM_CPRI                    => NUM_CPRI                                ,--: natural := 8;
	NUM_MAP                     => NUM_MAP                                 ,--: natural := 8;
	NUM_FMT                     => NUM_FMT                                  --: natural := 8
    )
    port map(
	CLK_AUX                     => CLK_CPUIF                               ,--: in  std_logic;
	CLK_SYSX8                   => CLK_SYSX8                               ,--: in  std_logic;

	RESET                       => RST_CPUIF                               ,--: in  std_logic;

	DL_CDC_DELAY                => dl_cdc_delay                            ,--: in  std_logic_array24(NUM_CPRI-1 downto 0);
--        DL_COMP_IF_DELAY            => dl_comp_if_delay                        ,--: in  std_logic_array24(NUM_CPRI-1 downto 0);
	DL_CPRI_IF_DELAY            => dl_cpri_if_delay                        ,--: in  std_logic_array24(NUM_CPRI-1 downto 0);
	DL_CPRI_SWITCH_DELAY        => dl_cpri_switch_delay                    ,--: in  std_logic_vector(23 downto 0);
	DL_MAPPER_DELAY             => dl_mapper_delay                         ,--: in  std_logic_array24(NUM_MAP-1 downto 0);
	DL_MAP_SWITCH_DELAY         => dl_map_switch_delay                     ,--: in  std_logic_vector(23 downto 0);
	DL_FORMATTER_DELAY          => dl_formatter_delay                      ,--: in  std_logic_array24(NUM_FMT-1 downto 0);

	UL_CDC_DELAY                => ul_cdc_delay                            ,--: in  std_logic_array24(NUM_CPRI-1 downto 0);
--        UL_COMP_IF_DELAY            => ul_comp_if_delay                        ,--: in  std_logic_array24(NUM_CPRI-1 downto 0);
	UL_CPRI_IF_DELAY            => ul_cpri_if_delay                        ,--: in  std_logic_array24(NUM_CPRI-1 downto 0);
--        UL_CPRI_ALIGN_DELAY         => ul_cpri_align_delay                     ,--: in  std_logic_array24(NUM_CPRI-1 downto 0);
	UL_CPRI_SWITCH_DELAY        => ul_cpri_switch_delay                    ,--: in  std_logic_vector(23 downto 0);
	UL_MAPPER_DELAY             => ul_mapper_delay                         ,--: in  std_logic_array24(NUM_MAP-1 downto 0);
	UL_MAP_SWITCH_DELAY         => ul_map_switch_delay                     ,--: in  std_logic_vector(23 downto 0);
	UL_FORMATTER_DELAY          => ul_formatter_delay                      ,--: in  std_logic_array24(NUM_FMT-1 downto 0);

	DUMP_EN                     => dump_en                                 ,--: out std_logic;
	DUMP_SEL                    => dump_sel                                ,--: out std_logic_vector(7 downto 0);

	BW_SEL                      => bw_sel                                  ,--: out std_logic_array4(NUM_MAP-1 downto 0);
	SPEED_SEL                   => speed_sel                               ,--: out std_logic_array8(NUM_MAP-1 downto 0);
	LINE_RCF_RATE               => open                                    ,--: out std_logic_array8(NUM_CPRI-1 downto 0);
--        DIV_BYPASS                  => div_bypass                              ,--: out std_logic_vector(NUM_CPRI-1 downto 0);
--        DIV_DL_BYPASS               => div_dl_bypass                           ,--: out std_logic_vector(NUM_CPRI-1 downto 0);
--        DIV_UL_BYPASS               => div_ul_bypass                           ,--: out std_logic_vector(NUM_CPRI-1 downto 0);
--        COMP_BYPASS                 => comp_bypass                             ,--: out std_logic_vector(NUM_CPRI*2-1 downto 0);
--        COMP_DL_BYPASS              => comp_dl_bypass                          ,--: out std_logic;
--        COMP_UL_BYPASS              => comp_ul_bypass                          ,--: out std_logic;

	DL_MAP_WR_EN                => dl_map_wr_en                            ,--: out std_logic_vector(NUM_MAP-1 downto 0);
	DL_MAP_WR_ADDR              => dl_map_wr_addr                          ,--: out std_logic_vector(4 downto 0);
	DL_MAP_WR_DATA              => dl_map_wr_data                          ,--: out std_logic_vector(6 downto 0);
	DL_MAP_RD_DATA              => dl_map_rd_data                          ,--: in  std_logic_array7(NUM_MAP-1 downto 0);

	UL_MAP_WR_EN                => ul_map_wr_en                            ,--: out std_logic_vector(NUM_MAP-1 downto 0);
	UL_MAP_WR_ADDR              => ul_map_wr_addr                          ,--: out std_logic_vector(5 downto 0);
	UL_MAP_WR_DATA              => ul_map_wr_data                          ,--: out std_logic_vector(6 downto 0);
	UL_MAP_RD_DATA              => ul_map_rd_data                          ,--: in  std_logic_array7(NUM_MAP-1 downto 0);

	MAP_CPRI                    => map_cpri                                ,--: out std_logic_array8(NUM_MAP-1 downto 0);

	MAPPER_UL_MAP               => mapper_ul_map                           ,--: out std_logic_array16(NUM_MAP-1 downto 0);
	FORMATTER_DL_MAP            => formatter_dl_map                        ,--: out std_logic_array16(NUM_FMT-1 downto 0);
--        CASCADE_UL_SUM              => cascade_ul_sum                          ,--: out std_logic_array16(2 downto 0);

	SYNC_DELAY_VALUE            => sync_delay_value                        ,--: out std_logic_array32(NUM_FMT-1 downto 0);

	DL_DELAY_VALUE              => dl_delay_value                          ,--: out std_logic_array32(NUM_FMT-1 downto 0);
	UL_DELAY_VALUE              => ul_delay_value                          ,--: out std_logic_array32(NUM_FMT-1 downto 0);

	ZRHC_BYPASS                 => zrhc_bypass                             ,--: out std_logic_vector(NUM_FMT-1 downto 0);
	ZRHC_THRESHOLD              => zrhc_threshold                          ,--: out std_logic_array32(NUM_FMT-1 downto 0);
--        ZRHC_OCCUR                  => zrhc_occur                              ,--: in  std_logic_array4(NUM_FMT-1 downto 0);

	DL_ON                       => dl_on                                   ,--: out std_logic_array4(NUM_FMT-1 downto 0);
	UL_ON                       => ul_on                                   ,--: out std_logic_array4(NUM_FMT-1 downto 0);

	DL_ATT_0                    => dl_att_0                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);
	DL_ATT_1                    => dl_att_1                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);
	DL_ATT_2                    => dl_att_2                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);
	DL_ATT_3                    => dl_att_3                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);

	UL_ATT_0                    => ul_att_0                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);
	UL_ATT_1                    => ul_att_1                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);
	UL_ATT_2                    => ul_att_2                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);
	UL_ATT_3                    => ul_att_3                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);

	TSSI_UPDATE_MODE            => tssi_update_mode                        ,--: out std_logic_vector(1 downto 0);
	TSSI_UPDATE_CNT_0           => tssi_update_cnt_0                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
	TSSI_UPDATE_CNT_1           => tssi_update_cnt_1                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
	TSSI_UPDATE_CNT_2           => tssi_update_cnt_2                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
	TSSI_UPDATE_CNT_3           => tssi_update_cnt_3                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);

	RSSI_UPDATE_MODE            => rssi_update_mode                        ,--: out std_logic_vector(1 downto 0);
	RSSI_UPDATE_CNT_0           => rssi_update_cnt_0                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
	RSSI_UPDATE_CNT_1           => rssi_update_cnt_1                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
	RSSI_UPDATE_CNT_2           => rssi_update_cnt_2                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
	RSSI_UPDATE_CNT_3           => rssi_update_cnt_3                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);

	TSSI_0                      => tssi_0                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
	TSSI_1                      => tssi_1                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
	TSSI_2                      => tssi_2                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
	TSSI_3                      => tssi_3                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);

        CUR_TSSI_0                  => cur_tssi_0                              ,--: in std_logic_vector(31 downto 0);
        CUR_TSSI_1                  => cur_tssi_1                              ,--: in std_logic_vector(31 downto 0);

	RSSI_0                      => rssi_0                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
	RSSI_1                      => rssi_1                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
	RSSI_2                      => rssi_2                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
	RSSI_3                      => rssi_3                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);

--        SCALE_FACTOR                => scale_factor                            ,--: out std_logic_array3(5 downto 0);

	TEST_MODE                   => test_mode                               ,--: out std_logic_array4(NUM_FMT-1 downto 0);
	TP_EN                       => tp_en                                   ,
	TP_MEM_PEN                  => tp_mem_pen,
	TP_MEM_AWEN                 => tp_mem_awen,
	TP_MEM_WRADDR               => tp_mem_wraddr,
	TP_MEM_WRDATA               => tp_mem_wrdata,
	DL_10MS_CNT   				=> dl_10ms_cnt 								, --: in  std_logic_vector(15 downto 0);
	DL_SYNC_CNT   				=> dl_sync_cnt 								, --: in  std_logic_vector(15 downto 0);
	DL_DATA       				=> dl_data 								,     --: in  std_logic_vector(15 downto 0);
	DL_DATA_SEL   				=> dl_data_sel 								, --: out std_logic_vector(1 downto 0);
	TEST_DC_I                   => test_dc_i                               ,--: out std_logic_vector(15 downto 0);
	TEST_DC_Q                   => test_dc_q                               ,--: out std_logic_vector(15 downto 0);
	TEST_NCO                    => test_nco                                ,--: out std_logic_vector(5 downto 0);

	WREN_CPUIF_IN               => WREN_CPUIF_IN                           ,--: in  std_logic;
	RDEN_CPUIF_IN               => RDEN_CPUIF_IN                           ,--: in  std_logic;
	ADDR_CPUIF_IN               => ADDR_CPUIF_IN                           ,--: in  std_logic_vector(15 downto 0);
	WDATA_CPUIF_IN              => WDATA_CPUIF_IN                          ,--: in  std_logic_vector(31 downto 0);
	RDATA_CPUIF_OUT             => RDATA_CPUIF_OUT                         ,--: out std_logic_vector(31 downto 0);
	RDVAL_CPUIF_OUT             => RDVAL_CPUIF_OUT                          --: out std_logic
    );



    u_TRAFFIC_SELECTION : TRAFFIC_SELECTION
	generic map (
	    NUM_ANTENNA => 4
	)
	port map (
	    RESET            => RST_BBCTRL,
	    CLK              => CLK_SYSX8,
	    PROCESSING_DELAY => open,
	    BW_SEL           => bw_sel(0),
	    TEST_MODE        => test_mode(0),
	    TP_MEM_PEN       => TP_MEM_PEN,
	    TP_MEM_AWEN      => TP_MEM_AWEN,
	    TP_MEM_WRADDR    => TP_MEM_WRADDR,
	    TP_MEM_WRDATA    => TP_MEM_WRDATA,
	    TEST_DC_I        => test_dc_i,
	    TEST_DC_Q        => test_dc_q,
	    TEST_NCO         => test_nco,
	    TP_IN_10MS       => dl_fmt_10ms(0),
	    TP_IN_TDD        => dl_fmt_tdd(0),
	    TP_IN_SYNC       => dl_fmt_sync(0),
	    TP_IN_DATA       => dl_fmt_data(0),
	    TP_OUT_10MS      => tp_mem_10ms,
	    TP_OUT_TDD       => tp_mem_tdd,
	    TP_OUT_SYNC      => tp_mem_sync,
	    TP_OUT_DATA      => tp_mem_data
	);
	
    u_TP_MEM_IF_GEN : for i in NUM_FMT-1 downto 0 generate
		dl_tp_10ms(i) <= tp_mem_10ms when tp_en = '1' else dl_fmt_10ms(i);
		dl_tp_tdd(i)  <= tp_mem_tdd  when tp_en = '1' else dl_fmt_tdd(i);
		dl_tp_sync(i) <= tp_mem_sync when tp_en = '1' else dl_fmt_sync(i);
		dl_tp_data(i) <= tp_mem_data when tp_en = '1' else dl_fmt_data(i);
    end generate;
    
    u_FMT_GEN : for i in NUM_FMT-1 downto 0 generate
    
        BBCTRL_LPHY_DLUL_IF_INST : BBCTRL_LPHY_DLUL_IF
        port map(
        -- Common

            CLK_SYSX8                   => CLK_SYSX8                    ,
                                                                        
            BW_SEL                      => bw_sel(i)                    ,                                                            
            PROCESSING_DELAY_DL         => dl_dduc_if_delay(i)          ,
            PROCESSING_DELAY_UL         => ul_dduc_if_delay(i)          ,
                                                                                                                                          
        -- BB_TOP                                                       
                                                                        
            I_DL_FSYNC                  => lphy_dl_frame_sync(i)        ,
            I_DL_TDD                    => '0'                          ,
            I_DL_DATA_I                 => lphy_dl_i(2*i+1 downto 2*i)  ,   
            I_DL_DATA_Q                 => lphy_dl_q(2*i+1 downto 2*i)  ,
                                                                        
            O_UL_FSYNC                  => lphy_ul_frame_sync(i)        ,
            O_UL_TDD                    => open                         ,
            O_UL_VLD                    => lphy_ul_en (2*i+1 downto 2*i),
            O_UL_DATA_I                 => lphy_ul_i(2*i+1 downto 2*i)  ,
            O_UL_DATA_Q                 => lphy_ul_q(2*i+1 downto 2*i)  ,
                                                                     
        -- FORMATTER                                                 
                                                                        
            O_DL_10MS                   => dl_fmt_10ms(i)               ,
            O_DL_TDD                    => dl_fmt_tdd (i)               ,
            O_DL_SYNC                   => dl_fmt_sync(i)               ,
            O_DL_DATA                   => dl_fmt_data(i)               ,
                                                                        
            I_UL_FSYNC                  => ul_fmt_10ms(i)               ,
            I_UL_TDD                    => ul_fmt_tdd (i)               ,
            I_UL_SYNC                   => ul_fmt_sync(i)               ,
            I_UL_DATA                   => ul_fmt_data(i)               
        );
        
--          -- Path selection (UL)
--        process (CLK_SYSX8)
--        begin
--            if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
--                dl_fmt_sync_d1(i) <= dl_fmt_sync(i);
--            end if;
--        end process;
    
--        DL_SYNC_OUT(i) <= dl_fmt_sync(i); --dl_fmt_sync_d1(i);
--	    DL_IQ_OUT(i)   <= dl_fmt_data(i);
	    
	    u_FORMATTER : FORMATTER
	    generic map(
		NUM_ANTENNA                 => 4                                       ,--: natural := 4;
		DL_MAX_DATA_DELAY           => 65536                                   ,--: natural := 32768; 
		UL_MAX_DATA_DELAY           => 65536                                    --: natural := 65536  
	    )
	    port map(
		ARESET                      => RST_BBCTRL                              ,--: in  std_logic;
		CLK                         => CLK_SYSX8                               ,--: in  std_logic;
	
		BW_SEL                      => bw_sel(i)                               ,--: in  std_logic_vector(3 downto 0);
	
		PROCESSING_DELAY_DL         => dl_formatter_delay(i)                   ,--: out std_logic_vector(23 downto 0);
		PROCESSING_DELAY_UL         => ul_formatter_delay(i)                   ,--: out std_logic_vector(23 downto 0);
	
		SSB_OFFSET                  => SSB_OFFSET                              ,--: in  std_logic_vector(3 downto 0);
	
		SSB_EXIST_IN                => SSB_EXIST_IN                            ,--: in  std_logic;
	
		DL_10MS                     => dl_tp_10ms(i), --dl_tp_10ms(i)                           ,--: in  std_logic;
		DL_BFN                      => DL_BFN, --dl_fmt_bfn(i)                           ,--: in  std_logic_array12(NUM_FMT-1 downto 0);
		DL_TDD                      => dl_tp_tdd(i), --dl_tp_tdd(i)                            ,--: in  std_logic;
		DL_SYNC                     => dl_tp_sync(i), --dl_tp_sync(i)                           ,--: in  std_logic;
		DL_DATA                     => dl_tp_data(i), --dl_tp_data(i)                           ,--: in  std_logic_vector(15 downto 0);
	
		UL_10MS                     => ul_fmt_10ms(i)                          ,--: out std_logic;
		UL_TDD                      => ul_fmt_tdd(i)                           ,--: out std_logic;
		UL_SYNC                     => ul_fmt_sync(i)                          ,--: out std_logic;
		UL_DATA                     => ul_fmt_data(i)                          ,--: out std_logic_vector(15 downto 0);
	
		DUC_BFN_ABNORMAL            => duc_bfn_abnormal(i)                     ,--: out std_logic;
	
		DUC_AIRTECH                 => DL_AIRTECH_OUT(i)                       ,--: out std_logic_vector(3 downto 0);
		DUC_CHBW                    => DL_CHBW_OUT(i)                          ,--: out std_logic_vector(3 downto 0);
		DUC_40MS                    => duc_40ms(i)                             ,--: out std_logic;
		DUC_10MS                    => duc_10ms(i)                             ,--: out std_logic;
		DUC_BFN                     => duc_bfn(i)                              ,--: out std_logic_vector(11 downto 0);
		DUC_TDD                     => duc_tdd(i)                              ,--: out std_logic;
		DUC_SYNC                    => DL_SYNC_OUT(i)                          ,--: out std_logic;
		DUC_DATA                    => DL_IQ_OUT(i)                            ,--: out std_logic_vector(15 downto 0);
	
		DDC_AIRTECH                 => UL_AIRTECH_OUT(i)                       ,--: out std_logic_vector(3 downto 0);
		DDC_CHBW                    => UL_CHBW_OUT(i)                          ,--: out std_logic_vector(3 downto 0);
		DDC_10MS                    => ddc_10ms(i)                             ,--: in  std_logic;
		DDC_TDD                     => ddc_tdd(i)                              ,--: in  std_logic;
		DDC_SYNC                    => UL_SYNC_IN(i)                           ,--: in  std_logic;
		DDC_DATA                    => UL_IQ_IN(i)                             ,--: in  std_logic_vector(15 downto 0);
	
		SYNC_DELAY_VALUE            => sync_delay_value(i)                     ,--: in  std_logic_vector(31 downto 0);
	
		TDD_AND_CTRL                => TDD_AND_CTRL_IN                         ,--: in  std_logic;
		TDD_OR_CTRL                 => TDD_OR_CTRL_IN                          ,--: in  std_logic;
	
		DL_DELAY_VALUE              => dl_delay_value(i)                       ,--: in  std_logic_vector(31 downto 0);
		UL_DELAY_VALUE              => ul_delay_value(i)                       ,--: in  std_logic_vector(31 downto 0);
	
		ZRHC_BYPASS                 => zrhc_bypass(i)                          ,--: in  std_logic;
		ZRHC_THRESHOLD              => zrhc_threshold(i)                       ,--: in  std_logic_vector(31 downto 0);
		ZRHC_OCCUR                  => zrhc_occur(i)                           ,--: out std_logic_vector(3 downto 0);
	
		DL_ON                       => dl_on(i)                                ,--: in  std_logic_vector(3 downto 0);
		UL_ON                       => ul_on(i)                                ,--: in  std_logic_vector(3 downto 0);
	
		DL_ATT_0                    => dl_att_0(i)                             ,--: in  std_logic_vector(15 downto 0);
		DL_ATT_1                    => dl_att_1(i)                             ,--: in  std_logic_vector(15 downto 0);
		DL_ATT_2                    => dl_att_2(i)                             ,--: in  std_logic_vector(15 downto 0);
		DL_ATT_3                    => dl_att_3(i)                             ,--: in  std_logic_vector(15 downto 0);
	
		UL_ATT_0                    => ul_att_0(i)                             ,--: in  std_logic_vector(15 downto 0);
		UL_ATT_1                    => ul_att_1(i)                             ,--: in  std_logic_vector(15 downto 0);
		UL_ATT_2                    => ul_att_2(i)                             ,--: in  std_logic_vector(15 downto 0);
		UL_ATT_3                    => ul_att_3(i)                             ,--: in  std_logic_vector(15 downto 0);
	
		FBSW_AUTO_MODE_DONE         => fbsw_auto_mode_done                     ,--: in  std_logic;
		FBSW_MEASURE_DONE           => fbsw_measure_done                       ,--: in  std_logic;
		FBSW_COUNTER                => fbsw_counter                            ,--: in  std_logic_vector(6 downto 0);
	
		TSSI_UPDATE_MODE            => tssi_update_mode                        ,--: in  std_logic_vector(1 downto 0);
		TSSI_UPDATE_CNT_0           => tssi_update_cnt_0(i)                    ,--: in  std_logic_vector(4 downto 0);
		TSSI_UPDATE_CNT_1           => tssi_update_cnt_1(i)                    ,--: in  std_logic_vector(4 downto 0);
		TSSI_UPDATE_CNT_2           => tssi_update_cnt_2(i)                    ,--: in  std_logic_vector(4 downto 0);
		TSSI_UPDATE_CNT_3           => tssi_update_cnt_3(i)                    ,--: in  std_logic_vector(4 downto 0);
	
		RSSI_UPDATE_MODE            => rssi_update_mode                        ,--: in  std_logic_vector(1 downto 0);
		RSSI_UPDATE_CNT_0           => rssi_update_cnt_0(i)                    ,--: in  std_logic_vector(4 downto 0);
		RSSI_UPDATE_CNT_1           => rssi_update_cnt_1(i)                    ,--: in  std_logic_vector(4 downto 0);
		RSSI_UPDATE_CNT_2           => rssi_update_cnt_2(i)                    ,--: in  std_logic_vector(4 downto 0);
		RSSI_UPDATE_CNT_3           => rssi_update_cnt_3(i)                    ,--: in  std_logic_vector(4 downto 0);
	
		TSSI_0                      => tssi_0(i)                               ,--: out std_logic_vector(31 downto 0);
		TSSI_1                      => tssi_1(i)                               ,--: out std_logic_vector(31 downto 0);
		TSSI_2                      => tssi_2(i)                               ,--: out std_logic_vector(31 downto 0);
		TSSI_3                      => tssi_3(i)                               ,--: out std_logic_vector(31 downto 0);
	
		CUR_TSSI_0                  => cur_tssi_0(i)						   ,--: out std_logic_vector(31 downto 0);
	    CUR_TSSI_1                  => cur_tssi_1(i)						   ,--: out std_logic_vector(31 downto 0);
	
		RSSI_0                      => rssi_0(i)                               ,--: out std_logic_vector(31 downto 0);
		RSSI_1                      => rssi_1(i)                               ,--: out std_logic_vector(31 downto 0);
		RSSI_2                      => rssi_2(i)                               ,--: out std_logic_vector(31 downto 0);
		RSSI_3                      => rssi_3(i)                               ,--: out std_logic_vector(31 downto 0);
	
		DUMP_DL_10MS                => dump_dl_10ms(i)                         ,--: out std_logic;
		DUMP_DL_SYNC                => dump_dl_sync(i)                         ,--: out std_logic;
		DUMP_DL_DATA                => dump_dl_data(i)                         ,--: out std_logic_vector(15 downto 0);
	
		DUMP_UL_10MS                => dump_ul_10ms(i)                         ,--: out std_logic;
		DUMP_UL_SYNC                => dump_ul_sync(i)                         ,--: out std_logic;
		DUMP_UL_DATA                => dump_ul_data(i)                          --: out std_logic_vector(15 downto 0)
	    );
    end generate;

end BEHAVE;
