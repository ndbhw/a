--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Time compensator                                              --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
-- Target     : Max 4-antennas @ 245.76-MHz                                   --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
-- Rev1.1 - Number of URAM Optimize                                           --
--------------------------------------------------------------------------------
-- Capable maximum delay : MAX_DATA_DELAY-18                                  --
-- Processing delay 18-clocks                                                 --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use WORK.ARRAY_TYPE.ALL;

entity FRAME_TIMING_COMPENSATOR is
    generic (
	NUM_ANTENNA                 : natural := 4;                             -- 2 or 4
	MAX_DATA_DELAY              : natural := 32768                          -- Buffer depth
    );
    port (
	RESET                       : in  std_logic;
	CLK                         : in  std_logic;

	PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

	BW_SEL                      : in  std_logic_vector(3 downto 0);

	SYNC_DELAY_VALUE            : in  std_logic_vector(31 downto 0);
	DATA_DELAY_VALUE            : in  std_logic_vector(31 downto 0);

	FTC_IN_10MS                 : in  std_logic;
	FTC_IN_TDD                  : in  std_logic;
	FTC_IN_SYNC                 : in  std_logic;
	FTC_IN_DATA                 : in  std_logic_vector(15 downto 0);

	FTC_OUT_10MS                : out std_logic;
	FTC_OUT_TDD                 : out std_logic;
	FTC_OUT_SYNC                : out std_logic;
	FTC_OUT_DATA                : out std_logic_vector(15 downto 0)

    );
end FRAME_TIMING_COMPENSATOR;

architecture BEHAVE of FRAME_TIMING_COMPENSATOR is

    constant MAX_SYNC_DELAY         : natural := 2457600;
    constant MAX_DATA_ADDR          : natural := MAX_DATA_DELAY/4;

    function log2 (data_value : integer)
    return integer is
	variable result      : integer := 0;
	variable cnt         : integer := 1;
    begin
	if (data_value <= 1) then
	    result     := 0;
	else
	    while (cnt < data_value) loop
		result := result + 1;
		cnt    := cnt *2;
	    end loop;
	end if;
	return result;
    end log2;

    signal limit_sync               : std_logic_vector(31 downto 0) := (others => '0');
    signal limit_data               : std_logic_vector(31 downto 0) := conv_std_logic_vector(MAX_DATA_DELAY-17, 32);

    signal delay_coarse             : std_logic_vector(16 downto 0) := (others => '1');
    signal delay_fine               : std_logic_vector(5 downto 0) := (others => '0');
    signal cnt_sync                 : std_logic_vector(5 downto 0) := (others => '0');
    signal sample_sync              : std_logic_vector(7 downto 0) := (others => '0');

    component DELAY_PULSE_ME is
    generic (
	DELAY_RANGE                 : natural := 32;                            -- Maximum bit width to set maximum value + 1
	TRANSITION                  : natural := 2
    );
    port (
	RESET                       : in  std_logic;
	CLK                         : in  std_logic;
	DELAY_VALUE                 : in  std_logic_vector(DELAY_RANGE-1 downto 0);
	SYNC_IN                     : in  std_logic;
	SYNC_OUT                    : out std_logic
    );
    end component;

    signal delay_value_10ms         : std_logic_vector(log2(MAX_SYNC_DELAY)-1 downto 0) := (others => '0');
    signal delay_value_tdd          : std_logic_vector(log2(MAX_SYNC_DELAY)-1 downto 0) := (others => '0');

    component bb_buf is
    generic(
	STYLE                       : string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
	NPIPE                       : integer := 6;
	DEPTH                       : integer := 16384;
	WIDTH                       : integer := 72
    );
    port(
	WCLK                        : in  std_logic;
	RCLK                        : in  std_logic;
	WE                          : in  std_logic;
	ENB                         : in  std_logic;
	WADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
	RADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
	WDATA                       : in  std_logic_vector(WIDTH-1 downto 0);
	RDATA                       : out std_logic_vector(WIDTH-1 downto 0)
    );
    end component;

    signal coarse_wea               : std_logic_vector(NUM_ANTENNA*2-1 downto 0) := (others => '0');
    signal coarse_oea               : std_logic_vector(NUM_ANTENNA*2-1 downto 0) := (others => '0');

    -- add hyunseok, 230721
    signal r_data_in_d              : std_logic_array18(NUM_ANTENNA-1 downto 0);
    signal r_coarse_din             : std_logic_vector(18*NUM_ANTENNA-1 downto 0);
    signal r_coarse_dout            : std_logic_vector(18*NUM_ANTENNA-1 downto 0);
    signal r_coarse_wea             : std_logic;
    signal r_coarse_oea             : std_logic;
    signal r_coarse_addra           : std_logic_vector(log2(MAX_DATA_ADDR)-1 downto 0) := (others => '0');
    signal r_coarse_addrb           : std_logic_vector(log2(MAX_DATA_ADDR)-1 downto 0) := conv_std_logic_vector(MAX_DATA_DELAY-17, log2(MAX_DATA_ADDR));
    signal r_coarse_dout_shift      : std_logic_vector(18*NUM_ANTENNA-1 downto 0);

    component BUFFER_FINE is
    port (
	CLKA                        : in  std_logic;
	WEA                         : in  std_logic_vector(0 downto 0);
	ADDRA                       : in  std_logic_vector(5 downto 0);
	DINA                        : in  std_logic_vector(17 downto 0);
	CLKB                        : in  std_logic;
	ADDRB                       : in  std_logic_vector(5 downto 0);
	DOUTB                       : out std_logic_vector(17 downto 0)
    );
    end component;

    -- add hyunseok, 230721
    signal r_fine_addra               : std_logic_vector(5 downto 0) := (others => '0');
    signal r_fine_dina                : std_logic_vector(17 downto 0);
    signal r_fine_addrb               : std_logic_vector(5 downto 0) := (others => '0');
    signal r_fine_doutb               : std_logic_vector(17 downto 0);

begin

    PROCESSING_DELAY <= conv_std_logic_vector(18, 24);

    -- delay saturation
    process (CLK)
    begin
	if (CLK'event and CLK = '1') then
	    if (SYNC_DELAY_VALUE >= MAX_SYNC_DELAY-35) then
		limit_sync <= conv_std_logic_vector(MAX_SYNC_DELAY-35, 32);
	    else
		limit_sync <= SYNC_DELAY_VALUE;
	    end if;
	    if (DATA_DELAY_VALUE >= MAX_DATA_DELAY-18) then
		limit_data <= conv_std_logic_vector(MAX_DATA_DELAY-18, 32);
	    else
		limit_data <= DATA_DELAY_VALUE;
	    end if;
	end if;
    end process;

    -- decoding delay value
    process (CLK)
    begin
	if (CLK'event and CLK = '1') then
	    delay_value_10ms <= limit_sync(log2(MAX_SYNC_DELAY)-1 downto 0) + conv_std_logic_vector(12, log2(MAX_SYNC_DELAY));
	    delay_value_tdd  <= limit_sync(log2(MAX_SYNC_DELAY)-1 downto 0) + conv_std_logic_vector(12, log2(MAX_SYNC_DELAY));
        if (NUM_ANTENNA = 2) then	
		case BW_SEL is        	
		    when "0010" =>  -- 5-MHz
		        delay_coarse     <= "00" & limit_data(16 downto 5) & "00";
		        delay_fine       <= '0' & limit_data(4 downto 0);   --32 clk
		    when "0011" =>  -- 10-MHz
		        delay_coarse     <= "0" & limit_data(16 downto 4) & "00";
		        delay_fine       <= "00" & limit_data(3 downto 0);
		    when others =>  -- 15/20-MHz
		        delay_coarse     <=  limit_data(16 downto 3) & "00";
		        delay_fine       <= "000" & limit_data(2 downto 0);
		    end case;
	    else
		case BW_SEL is
		    when "0010" =>  -- 5-MHz
		        delay_coarse     <= "00" & limit_data(16 downto 5) & "000";
		        delay_fine       <= '0' & limit_data(4 downto 0);
		    when "0011" =>  -- 10-MHz
		        delay_coarse     <= "0" & limit_data(16 downto 4) & "000";
		        delay_fine       <= "00" & limit_data(3 downto 0);
		    when others =>  -- 15/20-MHz
		        delay_coarse     <= limit_data(16 downto 3) & "000";
		        delay_fine       <= "000" & limit_data(2 downto 0);
		    end case;
	    end if;
	end if;
    end process;

    -- chip to sample
    process (CLK)
    begin
	if (CLK'event and CLK = '1') then
	    if (FTC_IN_SYNC = '1') then
		cnt_sync <= (others => '0');
	    else
		cnt_sync <= cnt_sync + 1;
	    end if;
	    case BW_SEL is
	    when "0010" =>  -- 5-MHz
		if (cnt_sync(4 downto 0) = 31) then
		    sample_sync(0) <= '1';
		else
		    sample_sync(0) <= '0';
		end if;
	    when "0011" =>  -- 10-MHz
		if (cnt_sync(3 downto 0) = 15) then
		    sample_sync(0) <= '1';
		else
		    sample_sync(0) <= '0';
		end if;
	    when others =>  -- 15/20-MHz
		if (cnt_sync(2 downto 0) = 7) then
		    sample_sync(0) <= '1';
		else
		    sample_sync(0) <= '0';
		end if;
	    end case;
	    sample_sync(7 downto 1) <= sample_sync(6 downto 0);
	end if;
    end process;

--------------------------------------------------------------------------------
-- Coarse delay
--------------------------------------------------------------------------------

    -- write/read enable
    process (CLK)
    begin
	if (CLK'event and CLK = '1') then
	    if (sample_sync(0) = '1') then
		coarse_wea <= (others => '1');
	    else
		coarse_wea <= coarse_wea(NUM_ANTENNA*2-2 downto 0) & '0';
	    end if;
	    if (sample_sync(7) = '1') then
		coarse_oea <= (others => '1');
	    else
		coarse_oea <= coarse_oea(NUM_ANTENNA*2-2 downto 0) & '0';
	    end if;
	end if;
    end process;

    -- Edit hyunseok, 230721
    process (CLK)
    begin
	if(CLK'event and CLK = '1') then
	    r_data_in_d(0) <= '0' & sample_sync(0) & FTC_IN_DATA;
	    for i in NUM_ANTENNA-1 downto 1 loop
		r_data_in_d(i) <= r_data_in_d(i-1);
	    end loop;
	end if;
    end process;

    process (CLK)
    begin
	if(CLK'event and CLK = '1') then
	    r_coarse_din <= r_data_in_d(3) & r_data_in_d(2) & r_data_in_d(1) & r_data_in_d(0);
	end if;
    end process;

    process (CLK)
    begin
	if(CLK'event and CLK = '1') then
	    r_coarse_wea <= (coarse_wea(2) xor coarse_wea(3)) or (coarse_wea(6) xor coarse_wea(7));
	end if;
    end process;

    process (CLK)
    begin
	if(CLK'event and CLK = '1') then
	    if(r_coarse_wea = '1') then
		if (r_coarse_addra = MAX_DATA_ADDR-1) then
		    r_coarse_addra <= (others => '0');
		else
		    r_coarse_addra <= r_coarse_addra + 1;
		end if;
	    else
		r_coarse_addra <= r_coarse_addra;
	    end if;
	end if;
    end process;

    process (CLK)
    begin
	if(CLK'event and CLK = '1') then
	    if(r_coarse_wea = '1') then
		if (r_coarse_addra = ("00" & delay_coarse(16 downto 2))) then -- Write unit: 4 input data concatenate
		    r_coarse_addrb <= (others => '0');
		else
		    if (r_coarse_addrb = MAX_DATA_ADDR-1) then
			r_coarse_addrb <= (others => '0');
		    else
			r_coarse_addrb <= r_coarse_addrb + 1;
		    end if;
		end if;
	    else
		r_coarse_addrb <= r_coarse_addrb;
	    end if;
	end if;
    end process;

    process (CLK)
    begin
	if(CLK'event and CLK = '1') then
	    r_coarse_oea <= (coarse_oea(2) xor coarse_oea(3)) or (coarse_oea(6) xor coarse_oea(7));
	end if;
    end process;

    process (CLK)
    begin
	if(CLK'event and CLK = '1') then
	    if(r_coarse_oea = '1') then
		r_coarse_dout_shift <= r_coarse_dout;
	    else
		r_coarse_dout_shift <= r_coarse_dout_shift(53 downto 0) & "00" & x"0000";
	    end if;
	end if;
    end process;

--------------------------------------------------------------------------------
-- Fine delay
--------------------------------------------------------------------------------

    -- add hyunseok, 230721
    -- address
    process (CLK)
    begin
	if (CLK'event and CLK = '1') then
	    if (r_fine_addra = 63) then
		r_fine_addra <= (others => '0');
	    else
		r_fine_addra <= r_fine_addra + 1;
	    end if;
	    if (r_fine_addra = delay_fine) then
		r_fine_addrb <= (others => '0');
	    else
		r_fine_addrb <= r_fine_addrb + 1;
	    end if;
	end if;
    end process;

    -- data
    process (CLK)
    begin
	if (CLK'event and CLK = '1') then
	    r_fine_dina <= r_coarse_dout_shift(71 downto 54);
	end if;
    end process;


    -- Output
    FTC_OUT_SYNC <= r_fine_doutb(16);
    process (CLK)
    begin
	if (CLK'event and CLK = '1') then
	    FTC_OUT_DATA <= r_fine_doutb(15 downto 0);
	end if;
    end process;



--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_10ms_DELAY : DELAY_PULSE_ME
    generic map(
	DELAY_RANGE                 => log2(MAX_SYNC_DELAY)                    ,--: natural := 32;
	TRANSITION                  => 1                                        --: natural := 2
    )
    port map(
	RESET                       => RESET                                   ,--: in  std_logic;
	CLK                         => CLK                                     ,--: in  std_logic;
	DELAY_VALUE                 => delay_value_10ms                        ,--: in  std_logic_vector(DELAY_RANGE-1 downto 0);
	SYNC_IN                     => FTC_IN_10MS                             ,--: in  std_logic;
	SYNC_OUT                    => FTC_OUT_10MS                             --: out std_logic
    );

    u_TDD_DELAY : DELAY_PULSE_ME
    generic map(
	DELAY_RANGE                 => log2(MAX_SYNC_DELAY)                    ,--: natural := 32;
	TRANSITION                  => 2                                        --: natural := 2
    )
    port map(
	RESET                       => RESET                                   ,--: in  std_logic;
	CLK                         => CLK                                     ,--: in  std_logic;
	DELAY_VALUE                 => delay_value_tdd                         ,--: in  std_logic_vector(DELAY_RANGE-1 downto 0);
	SYNC_IN                     => FTC_IN_TDD                              ,--: in  std_logic;
	SYNC_OUT                    => FTC_OUT_TDD                              --: out std_logic
    );

    u_COARSE_DELAY_BUFFER_opt : bb_buf
    generic map(
	STYLE                       => "ultra"                                , --: string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
	NPIPE                       => 6                                      , --: integer := 6;
	DEPTH                       => MAX_DATA_ADDR                          , --: integer := 8192;
	WIDTH                       => 72                                       --: integer := 72
    )
    port map(
	WCLK                        => CLK                                    , --: in  std_logic;
	RCLK                        => CLK                                    , --: in  std_logic;
	WE                          => r_coarse_wea                           , --: in  std_logic;
	ENB                         => '1'                                    , --: in  std_logic;
	WADDR                       => r_coarse_addra                         , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
	RADDR                       => r_coarse_addrb                         , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
	WDATA                       => r_coarse_din                           , --: in  std_logic_vector(WIDTH-1 downto 0);
	RDATA                       => r_coarse_dout                           --: out std_logic_vector(WIDTH-1 downto 0)
    );

    u_FINE_DELAY_BUFFER_opt : BUFFER_FINE
    port map(
	CLKA                        => CLK                                     ,--: in  std_logic;
	WEA                         => "1"                                     ,--: in  std_logic_vector(0 downto 0);
	ADDRA                       => r_fine_addra                              ,--: in  std_logic_vector(5 downto 0);
	DINA                        => r_fine_dina                               ,--: in  std_logic_vector(17 downto 0);
	CLKB                        => CLK                                     ,--: in  std_logic;
	ADDRB                       => r_fine_addrb                              ,--: in  std_logic_vector(5 downto 0);
	DOUTB                       => r_fine_doutb                               --: out std_logic_vector(17 downto 0)
    );

end BEHAVE;