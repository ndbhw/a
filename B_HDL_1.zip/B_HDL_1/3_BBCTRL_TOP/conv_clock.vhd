--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : clock domain change                                           --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2020.09.09                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------
-- Processing delay 8-clocks                                                  --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

library work;
use WORK.ARRAY_TYPE.ALL;
use work.RU_FPGA_FNC.all;

entity CONV_CLOCK is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        CLK_CPRI                    : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        RX_TDD                      : in  std_logic;

--------------------------------------------------------------------------------
-- CPRI
--------------------------------------------------------------------------------

        LINE_RCF_START              : in  std_logic;
        LINE_RCF_RATE               : in  std_logic_vector(7 downto 0);
        LINE_RCF_CLKTYPE            : in  std_logic_vector(7 downto 0);
        LINE_RCF_WIDTH              : in  std_logic_vector(7 downto 0);

        CPRI_RX_BFN_STRB            : in  std_logic;
        CPRI_RX_BFN                 : in  std_logic_vector(11 downto 0);
        CPRI_RX_VLD                 : in  std_logic;
        CPRI_RX_I                   : in  std_logic_vector(15 downto 0);
        CPRI_RX_Q                   : in  std_logic_vector(15 downto 0);

        CPRI_TX_ENB                 : in  std_logic;
        CPRI_TX_I                   : out std_logic_vector(15 downto 0);
        CPRI_TX_Q                   : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- CPRI_IF
--------------------------------------------------------------------------------

        CIF_RX_10MS                 : out std_logic;
        CIF_RX_BFN                  : out std_logic_vector(11 downto 0);
        CIF_RX_TDD                  : out std_logic;
        CIF_RX_SYNC                 : out std_logic;
        CIF_RX_DATA_I               : out std_logic_vector(15 downto 0);
        CIF_RX_DATA_Q               : out std_logic_vector(15 downto 0);

        CIF_TX_SYNC                 : in  std_logic;
        CIF_TX_DATA_I               : in  std_logic_vector(15 downto 0);
        CIF_TX_DATA_Q               : in  std_logic_vector(15 downto 0)
    );
end CONV_CLOCK;

architecture ARC_CONV_CLOCK of CONV_CLOCK is

    signal dl_wr_sync_cnt           : std_logic_vector(5 downto 0);
    signal dl_rd_sync               : std_logic := '0';
    signal dl_rd_sync_cdc           : std_logic_vector(3 downto 0) := (others => '0');
    signal dl_rd_sync_rpls          : std_logic := '0';
    signal dl_rd_sync_cnt           : std_logic_vector(5 downto 0) := (others => '0');

    signal ul_rd_addr_cnt           : std_logic_vector(5 downto 0) := (others => '0');
    signal ul_rd_bank               : std_logic_vector(1 downto 0) := (others => '0');
    signal ul_rd_bank_d             : std_logic_vector(2 downto 0) := (others => '0');
    signal ul_wr_addr_cnt           : std_logic_vector(7 downto 0) := (others => '0');
    signal ul_wr_resync_cdc         : std_logic := '0';
    signal ul_wr_resync_cnt         : std_logic_vector(7 downto 0) := (others => '0');
    signal ul_wr_resync             : std_logic := '0';

    component bb_buf is
    generic(
        STYLE                       : string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
        NPIPE                       : integer := 6;
        DEPTH                       : integer := 8192;
        WIDTH                       : integer := 72
    );
    port(
        WCLK                        : in  std_logic;
        RCLK                        : in  std_logic;
        WE                          : in  std_logic;
        ENB                         : in  std_logic;
        WADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
        RADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
        WDATA                       : in  std_logic_vector(WIDTH-1 downto 0);
        RDATA                       : out std_logic_vector(WIDTH-1 downto 0)
    );
    end component;

    signal dl_wr_addr               : std_logic_vector( 5 downto 0) := (others => '0');
    signal dl_rd_addr               : std_logic_vector( 5 downto 0) := (others => '0');
    signal dl_wr_data               : std_logic_vector(33 downto 0) := (others => '0');
    signal dl_rd_data               : std_logic_vector(33 downto 0) := (others => '0');

    signal ul_wr_addr               : std_logic_vector( 7 downto 0) := (others => '0');
    signal ul_rd_addr               : std_logic_vector( 7 downto 0) := (others => '0');
    signal ul_wr_data               : std_logic_vector(31 downto 0) := (others => '0');
    signal ul_rd_data               : std_logic_vector(31 downto 0) := (others => '0');

begin

    PROCESSING_DELAY_DL <= conv_std_logic_vector(40, 24);
    PROCESSING_DELAY_UL <= conv_std_logic_vector(64, 24) when LINE_RCF_RATE = x"07" else conv_std_logic_vector(32, 24);
    
--------------------------------------------------------------------------------
-- DL CDC
--------------------------------------------------------------------------------

    -- dl write address 
    process(CLK_CPRI)
    begin
        if (CLK_CPRI'event and CLK_CPRI = '1') then
            if (CPRI_RX_VLD = '1') then
                dl_wr_sync_cnt <= (others => '0');
            else
                dl_wr_sync_cnt <= dl_wr_sync_cnt + 1;
            end if;
            dl_wr_addr <= dl_wr_sync_cnt;
        end if;
    end process;
        
    --dl write data 
    process(CLK_CPRI)
    begin
        if (CLK_CPRI'event and CLK_CPRI = '1') then
            dl_wr_data(15 downto 0)  <= CPRI_RX_I;
            dl_wr_data(31 downto 16) <= CPRI_RX_Q;
            dl_wr_data(32)           <= CPRI_RX_BFN_STRB;
            dl_wr_data(33)           <= RX_TDD;
        end if;
    end process;
      
    -- dl read address 
    process(CLK_CPRI)
    begin
        if (CLK_CPRI'event and CLK_CPRI = '1') then
            if (LINE_RCF_RATE = 7) then   -- 5G(122.88MHz)
                if (dl_wr_addr = 14) then
                    dl_rd_sync <= '1';
                else
                    dl_rd_sync <= '0';
                end if;
            else
                if (dl_wr_addr = 30) then
                    dl_rd_sync <= '1';
                else
                    dl_rd_sync <= '0';
                end if;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            dl_rd_sync_cdc  <= dl_rd_sync_cdc(2 downto 0) & dl_rd_sync;
            dl_rd_sync_rpls <= dl_rd_sync_cdc(1) and (not dl_rd_sync_cdc(2));
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (dl_rd_sync_cnt = 63) then
                dl_rd_sync_cnt <= (others => '0');
            else
                if (dl_rd_sync_rpls = '1') then
                    if (dl_rd_sync_cnt = 62 or dl_rd_sync_cnt = 0) then
                        dl_rd_sync_cnt <= dl_rd_sync_cnt + 1;
                    else
                        dl_rd_sync_cnt <= (others => '0');
                    end if;
                else
                    dl_rd_sync_cnt <= dl_rd_sync_cnt + 1;
                end if;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (LINE_RCF_RATE = 7) then   -- 5G(122.88MHz)
                dl_rd_addr <= '0' & dl_rd_sync_cnt(5 downto 1);
            else                          -- 10G(245.76MHz)
                dl_rd_addr <= dl_rd_sync_cnt;
            end if;
        end if;
    end process;

    -- dl output mapping
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (LINE_RCF_RATE = 7) then   -- 5G(122.88MHz)
                if (dl_rd_sync_cnt = 2) then
                    CIF_RX_SYNC <= '1';
                else
                    CIF_RX_SYNC <= '0';
                end if;    
            else
                if (dl_rd_sync_cnt = 2) then
                    CIF_RX_SYNC <= '1';
                else
                    CIF_RX_SYNC <= '0';
                end if;  
            end if;
            CIF_RX_DATA_I <= dl_rd_data(15 downto 0); 
            CIF_RX_DATA_Q <= dl_rd_data(31 downto 16); 
            CIF_RX_10MS   <= dl_rd_data(32); 
            CIF_RX_TDD    <= dl_rd_data(33); 
            CIF_RX_BFN    <= CPRI_RX_BFN;
        end if;
    end process;

    U_DL_CDC_BUF : bb_buf
    generic map(
        STYLE                       => "block"                 , --: string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
        NPIPE                       => 2                       , --: integer := 6;
        DEPTH                       => 64                      , --: integer := 8192;
        WIDTH                       => 34                        --: integer := 72
    )
    port map(
        WCLK                        => CLK_CPRI                , --: in  std_logic;
        RCLK                        => CLK_SYSX8               , --: in  std_logic;
        WE                          => '1'                     , --: in  std_logic;
        ENB                         => '1'                     , --: in  std_logic;
        WADDR                       => dl_wr_addr              , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        RADDR                       => dl_rd_addr              , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        WDATA                       => dl_wr_data              , --: in  std_logic_vector(WIDTH-1 downto 0);
        RDATA                       => dl_rd_data                --: out std_logic_vector(WIDTH-1 downto 0)
    );

--------------------------------------------------------------------------------
-- UL CDC
--------------------------------------------------------------------------------

     -- ul write address control  
     process(CLK_SYSX8)
     begin
         if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
             ul_rd_bank_d <= ul_rd_bank_d(1 downto 0) & ul_rd_bank(1);
             ul_wr_resync <= ul_rd_bank_d(1) and (not ul_rd_bank_d(2));
         end if;
     end process;

     process(CLK_SYSX8)
     begin
         if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
             if (ul_wr_resync_cnt = 255) then
                 ul_wr_resync_cnt <= (others => '0');
             else
                 if (ul_wr_resync = '1') then
                     if (ul_wr_resync_cnt = 254 or ul_wr_resync_cnt = 255 or ul_wr_resync_cnt = 0) then
                         ul_wr_resync_cnt <= ul_wr_resync_cnt + '1';
                     else
                         ul_wr_resync_cnt <= (others => '0');
                     end if;
                 else
                     ul_wr_resync_cnt <= ul_wr_resync_cnt + '1';
                 end if;
             end if;
         end if;
     end process;

     process(CLK_SYSX8)
     begin
         if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
             if (ul_wr_resync_cnt = 0) then
                 ul_wr_resync_cdc <= '1';
             elsif (ul_wr_resync_cnt = 64) then
                 ul_wr_resync_cdc <= '0';
             end if;
         end if;
     end process;

     process(CLK_SYSX8)
     begin
         if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
             if (ul_wr_resync_cdc = '1') then
                 if (CIF_TX_SYNC = '1') then
                     ul_wr_addr_cnt <= (others => '0');
                 else
                     ul_wr_addr_cnt <= ul_wr_addr_cnt + '1';
                 end if;
             else
                 ul_wr_addr_cnt <= ul_wr_addr_cnt + '1';
             end if;
         end if;
     end process;

     process(CLK_SYSX8)
     begin
         if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
             ul_wr_addr <= ul_wr_addr_cnt;
         end if;
     end process;

     -- ul write data
     process(CLK_SYSX8)
     begin
         if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
             ul_wr_data(15 downto 0)  <= CIF_TX_DATA_I;
             ul_wr_data(31 downto 16) <= CIF_TX_DATA_Q;
         end if;
     end process;

    -- ul read address control
     process(CLK_CPRI)
     begin
         if (CLK_CPRI'event and CLK_CPRI = '1') then
             if (CPRI_TX_ENB = '1') then
                 ul_rd_addr_cnt <= conv_std_logic_vector(3,6);
             else
                 if (LINE_RCF_RATE = 15) then
                     if (ul_rd_addr_cnt = 63) then
                         ul_rd_addr_cnt <= (others => '0');
                     else
                         ul_rd_addr_cnt <= ul_rd_addr_cnt + '1';
                     end if;
                 else
                     if (ul_rd_addr_cnt = 31) then
                         ul_rd_addr_cnt <= (others => '0');
                     else
                         ul_rd_addr_cnt <= ul_rd_addr_cnt + '1';
                     end if;
                 end if;
             end if;
         end if;
     end process;
    
     process(CLK_CPRI)
     begin
         if (CLK_CPRI'event and CLK_CPRI = '1') then
             if (LINE_RCF_RATE = 15) then
                 if (ul_rd_addr_cnt = 63) then
                     ul_rd_bank <= ul_rd_bank + '1';
                 end if;
             else
                 if (ul_rd_addr_cnt = 31) then
                     ul_rd_bank <= ul_rd_bank + '1';
                 end if;
             end if;
         end if;
     end process;

     process(CLK_CPRI)
     begin
         if (CLK_CPRI'event and CLK_CPRI = '1') then
             if (LINE_RCF_RATE = 15) then
                 ul_rd_addr <= ul_rd_bank & ul_rd_addr_cnt;
             else
                 ul_rd_addr <= ul_rd_bank & ul_rd_addr_cnt(4 downto 0) & '0';
             end if;
         end if;
     end process;

    -- ul output data
    CPRI_TX_I <= ul_rd_data(15 downto 0);      
    CPRI_TX_Q <= ul_rd_data(31 downto 16);      

    U_UL_CDC_BUF : bb_buf
    generic map(
        STYLE                       => "block"                 , --: string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
        NPIPE                       => 2                       , --: integer := 6;
        DEPTH                       => 256                     , --: integer := 8192;
        WIDTH                       => 32                        --: integer := 72
    )
    port map(
        WCLK                        => CLK_SYSX8                , --: in  std_logic;
        RCLK                        => CLK_CPRI               , --: in  std_logic;
        WE                          => '1'                     , --: in  std_logic;
        ENB                         => '1'                     , --: in  std_logic;
        WADDR                       => ul_wr_addr              , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        RADDR                       => ul_rd_addr              , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        WDATA                       => ul_wr_data              , --: in  std_logic_vector(WIDTH-1 downto 0);
        RDATA                       => ul_rd_data                --: out std_logic_vector(WIDTH-1 downto 0)
    );


end ARC_CONV_CLOCK;




