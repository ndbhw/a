--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : CPRI switch (Max 8 CPRIs, Max 8 mappers)                      --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
-- Target     : CPRI Max 8-ports                                              --
--              Mapper Max 8-ports                                            --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity CPRI_SWITCH is
    generic (
        NUM_CPRI                    : natural := 8;
        NUM_MAP                     : natural := 8
    );
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

--------------------------------------------------------------------------------
-- S/W control
--------------------------------------------------------------------------------

        MAP_CPRI                    : in  std_logic_array8(NUM_MAP-1 downto 0);

        SIG_SUS_DLOFF               : in  std_logic_vector(NUM_CPRI-1 downto 0);

--------------------------------------------------------------------------------
-- CPRI
--------------------------------------------------------------------------------

        RX_CPRI_10MS                : in  std_logic_vector(NUM_CPRI-1 downto 0);
        RX_CPRI_BFN                 : in  std_logic_array12(NUM_CPRI-1 downto 0);
        RX_CPRI_TDD                 : in  std_logic_vector(NUM_CPRI-1 downto 0);
        RX_CPRI_SYNC                : in  std_logic_vector(NUM_CPRI-1 downto 0);
        RX_CPRI_DATA_I              : in  std_logic_array16(NUM_CPRI-1 downto 0);
        RX_CPRI_DATA_Q              : in  std_logic_array16(NUM_CPRI-1 downto 0);

        TX_CPRI_10MS                : out std_logic_vector(NUM_CPRI-1 downto 0);
        TX_CPRI_TDD                 : out std_logic_vector(NUM_CPRI-1 downto 0);
        TX_CPRI_SYNC                : in  std_logic_vector(NUM_CPRI-1 downto 0);
        TX_CPRI_DATA_I              : out std_logic_array16(NUM_CPRI-1 downto 0);
        TX_CPRI_DATA_Q              : out std_logic_array16(NUM_CPRI-1 downto 0);

--------------------------------------------------------------------------------
-- Mapper
--------------------------------------------------------------------------------

        RX_MAP_10MS                 : out std_logic_vector(NUM_MAP-1 downto 0);
        RX_MAP_BFN                  : out std_logic_array12(NUM_MAP-1 downto 0);
        RX_MAP_TDD                  : out std_logic_vector(NUM_MAP-1 downto 0);
        RX_MAP_SYNC                 : out std_logic_vector(NUM_MAP-1 downto 0);
        RX_MAP_DATA_I               : out std_logic_array16(NUM_MAP-1 downto 0);
        RX_MAP_DATA_Q               : out std_logic_array16(NUM_MAP-1 downto 0);

        TX_MAP_10MS                 : in  std_logic_vector(NUM_MAP-1 downto 0);
        TX_MAP_TDD                  : in  std_logic_vector(NUM_MAP-1 downto 0);
        TX_MAP_SYNC                 : out std_logic_vector(NUM_MAP-1 downto 0);
        TX_MAP_DATA_I               : in  std_logic_array16(NUM_MAP-1 downto 0);
        TX_MAP_DATA_Q               : in  std_logic_array16(NUM_MAP-1 downto 0)
    );
end CPRI_SWITCH;

architecture BEHAVE of CPRI_SWITCH is

    signal rx_cpri_10ms_w           : std_logic_vector(7 downto 0) := (others => '0');
    signal rx_cpri_bfn_w            : std_logic_array12(7 downto 0) := (others => (others => '0'));
    signal rx_cpri_tdd_w            : std_logic_vector(7 downto 0) := (others => '0');
    signal rx_cpri_sync_w           : std_logic_vector(7 downto 0) := (others => '0');
    signal rx_cpri_data_i_w         : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal rx_cpri_data_q_w         : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal tx_cpri_sync_w           : std_logic_vector(7 downto 0) := (others => '0');

    signal rx_cpri_10ms_buf         : std_logic_vector(NUM_MAP-1 downto 0) := (others => '0');
    signal rx_cpri_bfn_buf          : std_logic_array12(NUM_MAP-1 downto 0) := (others => (others => '0'));
    signal rx_cpri_tdd_buf          : std_logic_vector(NUM_MAP-1 downto 0) := (others => '0');
    signal rx_cpri_sync_buf         : std_logic_vector(NUM_MAP-1 downto 0) := (others => '0');
    signal rx_cpri_data_i_buf       : std_logic_array16(NUM_MAP-1 downto 0) := (others => (others => '0'));
    signal rx_cpri_data_q_buf       : std_logic_array16(NUM_MAP-1 downto 0) := (others => (others => '0'));
    signal tx_cpri_sync_buf         : std_logic_vector(NUM_MAP-1 downto 0) := (others => '0');
    signal tx_cpri_sync_cnt         : std_logic_array6(NUM_MAP-1 downto 0) := (others => (others => '0'));
--    signal tx_map_10ms_buf          : std_logic_vector(15 downto 0) := (others => '0');
--    signal tx_map_tdd_buf           : std_logic_vector(15 downto 0) := (others => '0');
    signal tx_map_sync_buf          : std_logic_vector(NUM_MAP-1 downto 0) := (others => '0');

    signal tx_map_data_i_buf        : std_logic_array8_array16(7 downto 0) := (others => (others => (others => '0')));
    signal tx_map_data_q_buf        : std_logic_array8_array16(7 downto 0) := (others => (others => (others => '0')));
    signal tx_map_data_i_sum        : std_logic_array4_array16(7 downto 0) := (others => (others => (others => '0')));
    signal tx_map_data_q_sum        : std_logic_array4_array16(7 downto 0) := (others => (others => (others => '0')));

begin

    PROCESSING_DELAY_DL <= conv_std_logic_vector(3, 24);
    PROCESSING_DELAY_UL <= conv_std_logic_vector(3, 24);

    u_RX_MASK : for i in NUM_CPRI-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            rx_cpri_10ms_w(i)   <= RX_CPRI_10MS(i);
            rx_cpri_bfn_w(i)    <= RX_CPRI_BFN(i);
            rx_cpri_tdd_w(i)    <= RX_CPRI_TDD(i);
            rx_cpri_sync_w(i)   <= RX_CPRI_SYNC(i);
            if (SIG_SUS_DLOFF(i) = '1') then
                rx_cpri_data_i_w(i) <= (others => '0');
                rx_cpri_data_q_w(i) <= (others => '0');
            else
                rx_cpri_data_i_w(i) <= RX_CPRI_DATA_I(i);
                rx_cpri_data_q_w(i) <= RX_CPRI_DATA_Q(i);
            end if;
        end if;
    end process;

    tx_cpri_sync_w(i)   <= TX_CPRI_SYNC(i);
    end generate;

    -- switch CPRI input
    u_RX : for i in NUM_MAP-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case MAP_CPRI(i) is
            when x"00"  => rx_cpri_10ms_buf(i)   <= rx_cpri_10ms_w(0);
                           rx_cpri_bfn_buf(i)    <= rx_cpri_bfn_w(0);
                           rx_cpri_tdd_buf(i)    <= rx_cpri_tdd_w(0);
                           rx_cpri_sync_buf(i)   <= rx_cpri_sync_w(0);
                           rx_cpri_data_i_buf(i) <= rx_cpri_data_i_w(0);
                           rx_cpri_data_q_buf(i) <= rx_cpri_data_q_w(0);
                           tx_cpri_sync_buf(i)   <= tx_cpri_sync_w(0);
            when x"01"  => rx_cpri_10ms_buf(i)   <= rx_cpri_10ms_w(1);
                           rx_cpri_bfn_buf(i)    <= rx_cpri_bfn_w(1);
                           rx_cpri_tdd_buf(i)    <= rx_cpri_tdd_w(1);
                           rx_cpri_sync_buf(i)   <= rx_cpri_sync_w(1);
                           rx_cpri_data_i_buf(i) <= rx_cpri_data_i_w(1);
                           rx_cpri_data_q_buf(i) <= rx_cpri_data_q_w(1);
                           tx_cpri_sync_buf(i)   <= tx_cpri_sync_w(1);
            when x"02"  => rx_cpri_10ms_buf(i)   <= rx_cpri_10ms_w(2);
                           rx_cpri_bfn_buf(i)    <= rx_cpri_bfn_w(2);
                           rx_cpri_tdd_buf(i)    <= rx_cpri_tdd_w(2);
                           rx_cpri_sync_buf(i)   <= rx_cpri_sync_w(2);
                           rx_cpri_data_i_buf(i) <= rx_cpri_data_i_w(2);
                           rx_cpri_data_q_buf(i) <= rx_cpri_data_q_w(2);
                           tx_cpri_sync_buf(i)   <= tx_cpri_sync_w(2);
            when x"03"  => rx_cpri_10ms_buf(i)   <= rx_cpri_10ms_w(3);
                           rx_cpri_bfn_buf(i)    <= rx_cpri_bfn_w(3);
                           rx_cpri_tdd_buf(i)    <= rx_cpri_tdd_w(3);
                           rx_cpri_sync_buf(i)   <= rx_cpri_sync_w(3);
                           rx_cpri_data_i_buf(i) <= rx_cpri_data_i_w(3);
                           rx_cpri_data_q_buf(i) <= rx_cpri_data_q_w(3);
                           tx_cpri_sync_buf(i)   <= tx_cpri_sync_w(3);
            when x"04"  => rx_cpri_10ms_buf(i)   <= rx_cpri_10ms_w(4);
                           rx_cpri_bfn_buf(i)    <= rx_cpri_bfn_w(4);
                           rx_cpri_tdd_buf(i)    <= rx_cpri_tdd_w(4);
                           rx_cpri_sync_buf(i)   <= rx_cpri_sync_w(4);
                           rx_cpri_data_i_buf(i) <= rx_cpri_data_i_w(4);
                           rx_cpri_data_q_buf(i) <= rx_cpri_data_q_w(4);
                           tx_cpri_sync_buf(i)   <= tx_cpri_sync_w(4);
            when x"05"  => rx_cpri_10ms_buf(i)   <= rx_cpri_10ms_w(5);
                           rx_cpri_bfn_buf(i)    <= rx_cpri_bfn_w(5);
                           rx_cpri_tdd_buf(i)    <= rx_cpri_tdd_w(5);
                           rx_cpri_sync_buf(i)   <= rx_cpri_sync_w(5);
                           rx_cpri_data_i_buf(i) <= rx_cpri_data_i_w(5);
                           rx_cpri_data_q_buf(i) <= rx_cpri_data_q_w(5);
                           tx_cpri_sync_buf(i)   <= tx_cpri_sync_w(5);
            when x"06"  => rx_cpri_10ms_buf(i)   <= rx_cpri_10ms_w(6);
                           rx_cpri_bfn_buf(i)    <= rx_cpri_bfn_w(6);
                           rx_cpri_tdd_buf(i)    <= rx_cpri_tdd_w(6);
                           rx_cpri_sync_buf(i)   <= rx_cpri_sync_w(6);
                           rx_cpri_data_i_buf(i) <= rx_cpri_data_i_w(6);
                           rx_cpri_data_q_buf(i) <= rx_cpri_data_q_w(6);
                           tx_cpri_sync_buf(i)   <= tx_cpri_sync_w(6);
            when x"07"  => rx_cpri_10ms_buf(i)   <= rx_cpri_10ms_w(7);
                           rx_cpri_bfn_buf(i)    <= rx_cpri_bfn_w(7);
                           rx_cpri_tdd_buf(i)    <= rx_cpri_tdd_w(7);
                           rx_cpri_sync_buf(i)   <= rx_cpri_sync_w(7);
                           rx_cpri_data_i_buf(i) <= rx_cpri_data_i_w(7);
                           rx_cpri_data_q_buf(i) <= rx_cpri_data_q_w(7);
                           tx_cpri_sync_buf(i)   <= tx_cpri_sync_w(7);
            when others => rx_cpri_10ms_buf(i)   <= '0';
                           rx_cpri_bfn_buf(i)    <= (others => '0');
                           rx_cpri_tdd_buf(i)    <= '0';
                           rx_cpri_sync_buf(i)   <= '0';
                           rx_cpri_data_i_buf(i) <= (others => '0');
                           rx_cpri_data_q_buf(i) <= (others => '0');
                           tx_cpri_sync_buf(i)   <= '0';
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (tx_cpri_sync_buf(i) = '1') then
                tx_cpri_sync_cnt(i) <= (others => '0');
            else
                tx_cpri_sync_cnt(i) <= tx_cpri_sync_cnt(i) + 1;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (tx_cpri_sync_cnt(i) = 57) then
                tx_map_sync_buf(i) <= '1';
            else
                tx_map_sync_buf(i) <= '0';
            end if;
        end if;
    end process;

    -- map CPRI to mapper
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            RX_MAP_10MS(i)   <= rx_cpri_10ms_buf(i);
            RX_MAP_BFN(i)    <= rx_cpri_bfn_buf(i);
            RX_MAP_TDD(i)    <= rx_cpri_tdd_buf(i);
            RX_MAP_SYNC(i)   <= rx_cpri_sync_buf(i);
            RX_MAP_DATA_I(i) <= rx_cpri_data_i_buf(i);
            RX_MAP_DATA_Q(i) <= rx_cpri_data_q_buf(i);
            TX_MAP_SYNC(i)   <= tx_map_sync_buf(i);
        end if;
    end process;
    end generate;

    u_TX : for i in NUM_CPRI-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            for j in NUM_MAP-1 downto 0 loop
            if (MAP_CPRI(j) = i) then
                tx_map_data_i_buf(i)(j) <= TX_MAP_DATA_I(j);
                tx_map_data_q_buf(i)(j) <= TX_MAP_DATA_Q(j);
            else
                tx_map_data_i_buf(i)(j) <= (others => '0');
                tx_map_data_q_buf(i)(j) <= (others => '0');
            end if;
            end loop;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            tx_map_data_i_sum(i)(0) <= tx_map_data_i_buf(i)(0) or tx_map_data_i_buf(i)(4);
            tx_map_data_i_sum(i)(1) <= tx_map_data_i_buf(i)(1) or tx_map_data_i_buf(i)(5);
            tx_map_data_i_sum(i)(2) <= tx_map_data_i_buf(i)(2) or tx_map_data_i_buf(i)(6);
            tx_map_data_i_sum(i)(3) <= tx_map_data_i_buf(i)(3) or tx_map_data_i_buf(i)(7);
            tx_map_data_q_sum(i)(0) <= tx_map_data_q_buf(i)(0) or tx_map_data_q_buf(i)(4);
            tx_map_data_q_sum(i)(1) <= tx_map_data_q_buf(i)(1) or tx_map_data_q_buf(i)(5);
            tx_map_data_q_sum(i)(2) <= tx_map_data_q_buf(i)(2) or tx_map_data_q_buf(i)(6);
            tx_map_data_q_sum(i)(3) <= tx_map_data_q_buf(i)(3) or tx_map_data_q_buf(i)(7);
        end if;
    end process;

    TX_CPRI_10MS(i) <= '0';
    TX_CPRI_TDD(i)  <= '0';

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            TX_CPRI_DATA_I(i) <= tx_map_data_i_sum(i)(0) or tx_map_data_i_sum(i)(1) or tx_map_data_i_sum(i)(2) or tx_map_data_i_sum(i)(3);
            TX_CPRI_DATA_Q(i) <= tx_map_data_q_sum(i)(0) or tx_map_data_q_sum(i)(1) or tx_map_data_q_sum(i)(2) or tx_map_data_q_sum(i)(3);
        end if;
    end process;
    end generate;

end BEHAVE;