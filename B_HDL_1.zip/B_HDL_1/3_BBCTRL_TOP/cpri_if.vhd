--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : CPRI interface                                                --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--          Not support clock domain crossing                                 --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity CPRI_IF is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        CLK_CPRI                    : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        RX_TDD                      : in  std_logic;

--------------------------------------------------------------------------------
-- CPRI_IF
--------------------------------------------------------------------------------

        LINE_RCF_START              : in  std_logic;
        LINE_RCF_RATE               : in  std_logic_vector(7 downto 0);
        LINE_RCF_CLKTYPE            : in  std_logic_vector(7 downto 0);
        LINE_RCF_WIDTH              : in  std_logic_vector(7 downto 0);

        CIF_RX_BFN_STRB             : in  std_logic;
        CIF_RX_BFN                  : in  std_logic_vector(11 downto 0);
        CIF_RX_VLD                  : in  std_logic;
        CIF_RX_I                    : in  std_logic_vector(15 downto 0);
        CIF_RX_Q                    : in  std_logic_vector(15 downto 0);

        CIF_TX_ENB                  : in  std_logic;
        CIF_TX_I                    : out std_logic_vector(15 downto 0);
        CIF_TX_Q                    : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- CPRI switch
--------------------------------------------------------------------------------

        CSW_RX_10MS                 : out std_logic;
        CSW_RX_BFN                  : out std_logic_vector(11 downto 0);
        CSW_RX_TDD                  : out std_logic;
        CSW_RX_SYNC                 : out std_logic;
        CSW_RX_DATA_I               : out std_logic_vector(15 downto 0);
        CSW_RX_DATA_Q               : out std_logic_vector(15 downto 0);

        CSW_TX_10MS                 : in  std_logic;
        CSW_TX_TDD                  : in  std_logic;
        CSW_TX_SYNC                 : out std_logic;
        CSW_TX_DATA_I               : in  std_logic_vector(15 downto 0);
        CSW_TX_DATA_Q               : in  std_logic_vector(15 downto 0)
    );
end CPRI_IF;

architecture BEHAVE of CPRI_IF is

    component CONV_16TO15_V2 is
    port (
        CLK                         : in  std_logic;

        SPEED_SEL                   : in  std_logic_vector(7 downto 0); -- d'7: 5G / d'15: 10G

        CONV_IN_10MS                : in  std_logic;
        CONV_IN_TDD                 : in  std_logic;
        CONV_IN_SYNC                : in  std_logic;
        CONV_IN_DATA_I              : in  std_logic_vector(15 downto 0);
        CONV_IN_DATA_Q              : in  std_logic_vector(15 downto 0);

        CONV_OUT_10MS               : out std_logic;
        CONV_OUT_TDD                : out std_logic;
        CONV_OUT_SYNC               : out std_logic;
        CONV_OUT_DATA_I             : out std_logic_vector(14 downto 0);
        CONV_OUT_DATA_Q             : out std_logic_vector(14 downto 0)
    );
    end component;

    signal dl_conv_out_data_i       : std_logic_vector(14 downto 0);
    signal dl_conv_out_data_q       : std_logic_vector(14 downto 0);

    component CONV_15TO16_V2 is
    port (
        CLK                         : in  std_logic;

        SPEED_SEL                   : in  std_logic_vector(7 downto 0); -- d'7: 5G / d'15: 10G
    
        CONV_IN_SYNC                : in  std_logic;
        CONV_IN_DATA_I              : in  std_logic_vector(14 downto 0);
        CONV_IN_DATA_Q              : in  std_logic_vector(14 downto 0);

        CONV_OUT_SYNC               : out std_logic;
        CONV_OUT_DATA_I             : out std_logic_vector(15 downto 0);
        CONV_OUT_DATA_Q             : out std_logic_vector(15 downto 0)
    );
    end component;

    signal ul_conv_in_data_i        : std_logic_vector(14 downto 0);
    signal ul_conv_in_data_q        : std_logic_vector(14 downto 0);

begin

    process (LINE_RCF_RATE)
    begin
        case LINE_RCF_RATE is
        when x"07"  => PROCESSING_DELAY_DL <= conv_std_logic_vector( 4, 24);
                       PROCESSING_DELAY_UL <= conv_std_logic_vector( 9, 24);
        when others => PROCESSING_DELAY_DL <= conv_std_logic_vector( 4, 24);
                       PROCESSING_DELAY_UL <= conv_std_logic_vector( 7, 24);
        end case;
    end process;

    -- Didn't be aligned to 10msec signal.
    CSW_RX_BFN <= CIF_RX_BFN + 1;

    CSW_RX_DATA_I <= dl_conv_out_data_i(14) & dl_conv_out_data_i;
    CSW_RX_DATA_Q <= dl_conv_out_data_q(14) & dl_conv_out_data_q;

    ul_conv_in_data_i <= CSW_TX_DATA_I(14 downto 0);
    ul_conv_in_data_q <= CSW_TX_DATA_Q(14 downto 0);

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_DL_CONV : CONV_16TO15_V2
    port map(
        CLK                         => CLK_SYSX8                                ,--: in  std_logic;

        SPEED_SEL                   => LINE_RCF_RATE                           ,--: in  std_logic_vector(7 downto 0); -- d'7: 5G / d'15: 10G

        CONV_IN_10MS                => CIF_RX_BFN_STRB                         ,--: in  std_logic;
        CONV_IN_TDD                 => RX_TDD                                  ,--: in  std_logic;
        CONV_IN_SYNC                => CIF_RX_VLD                              ,--: in  std_logic;
        CONV_IN_DATA_I              => CIF_RX_I                                ,--: in  std_logic_vector(15 downto 0);
        CONV_IN_DATA_Q              => CIF_RX_Q                                ,--: in  std_logic_vector(15 downto 0);

        CONV_OUT_10MS               => CSW_RX_10MS                             ,--: out std_logic;
        CONV_OUT_TDD                => CSW_RX_TDD                              ,--: out std_logic;
        CONV_OUT_SYNC               => CSW_RX_SYNC                             ,--: out std_logic;
        CONV_OUT_DATA_I             => dl_conv_out_data_i                      ,--: out std_logic_vector(14 downto 0);
        CONV_OUT_DATA_Q             => dl_conv_out_data_q                       --: out std_logic_vector(14 downto 0)
    );

    u_UL_CONV : CONV_15TO16_V2
    port map(
        CLK                         => CLK_SYSX8                                ,--: in  std_logic;

        SPEED_SEL                   => LINE_RCF_RATE                           ,--: in  std_logic_vector(7 downto 0); -- d'7: 5G / d'15: 10G
    
        CONV_IN_SYNC                => CIF_TX_ENB                              ,--: in  std_logic;
        CONV_IN_DATA_I              => ul_conv_in_data_i                       ,--: in  std_logic_vector(14 downto 0);
        CONV_IN_DATA_Q              => ul_conv_in_data_q                       ,--: in  std_logic_vector(14 downto 0);

        CONV_OUT_SYNC               => CSW_TX_SYNC                             ,--: out std_logic;
        CONV_OUT_DATA_I             => CIF_TX_I                                ,--: out std_logic_vector(15 downto 0);
        CONV_OUT_DATA_Q             => CIF_TX_Q                                 --: out std_logic_vector(15 downto 0)
    );

end BEHAVE;