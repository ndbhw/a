library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity BB_TIMER is
    port (
    CLK                                : in  std_logic;

    LINE_RATE                          : in  std_logic_vector( 3 downto 0);

    FSYNC_CPRI                         : in  std_logic;
    FSYNC_FREE                         : out std_logic
    );
end BB_TIMER;

architecture BEHAVE of BB_TIMER is

    signal fsync_cpri_d1               : std_logic:='0';
    signal fsync_cpri_rdet             : std_logic:='0';

    signal cnt_sample_end              : std_logic_vector( 5 downto 0):=(others => '0');
    signal cnt_sample                  : std_logic_vector( 5 downto 0):=(others => '0');
    signal cnt_chip                    : std_logic_vector(15 downto 0):=(others => '0');
    
    signal fsync_gen                   : std_logic:='0';

begin


    process(CLK)
    begin
        if rising_edge(CLK) then
            fsync_cpri_d1 <= FSYNC_CPRI;
        end if;
    end process;

    process(CLK)
    begin
        if rising_edge(CLK) then
            fsync_cpri_rdet <= FSYNC_CPRI and (not fsync_cpri_d1);
        end if;
    end process;

    process(CLK)
    begin
        if rising_edge(CLK) then
            if (LINE_RATE = "1111") then
                cnt_sample_end <= conv_std_logic_vector(64-1,6);
            else
                cnt_sample_end <= conv_std_logic_vector(32-1,6);
            end if;
        end if;
    end process;
    

    process(CLK)
    begin
        if rising_edge(CLK) then
            if (fsync_cpri_rdet = '1') then
                cnt_sample <= (others => '0');
            else
                if (cnt_sample = cnt_sample_end) then
                    cnt_sample <= (others => '0');
                else
                    cnt_sample <= cnt_sample + '1';
                end if;
            end if;
        end if;
    end process;

    process(CLK)
    begin
        if rising_edge(CLK) then
            if (fsync_cpri_rdet = '1') then
                cnt_chip <= (others => '0');
            else
                if (cnt_sample = cnt_sample_end) then
                    if (cnt_chip = 38400-1) then
                        cnt_chip <= (others => '0');
                    else
                        cnt_chip <= cnt_chip + '1';
                    end if;
                end if;
            end if;
        end if;
    end process;

    process(CLK)
    begin
        if rising_edge(CLK) then
            if (cnt_sample = cnt_sample_end - 3) then
                if (cnt_chip = 38400-1) then
                    fsync_gen <= '1';
                else
                    fsync_gen <= '0';
                end if;
            end if;
        end if;
    end process;

    process(CLK)
    begin
        if rising_edge(CLK) then
            FSYNC_FREE <= fsync_gen;
        end if;
    end process;


end BEHAVE;

