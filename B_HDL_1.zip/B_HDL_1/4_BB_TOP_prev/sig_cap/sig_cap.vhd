---------------------------------------------------------------------------------
--
-- Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
--
--  Project      : ATnT HRU, VzW FSU20
--  Module       : sig_cap
--  Author       : jiung.woo@samsung.com
--  Description  : signal capture(dump)
--
--  Revision History
--  ------------+---------------+-----------------------------------------------
--     Date     |   Author      |   Description
--  ------------+---------------+-----------------------------------------------
--   2020.06.16 | jiung.woo     | initial release
--  ------------+---------------+-----------------------------------------------
--   2020.06.19 | jiung.woo     | Add setting sampling rate
--  ------------+---------------+-----------------------------------------------
--
---------------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_textio.all;
use IEEE.math_real.all;
use IEEE.numeric_std.all;
use STD.textio.all;
use work.ARRAY_TYPE.all;
use work.ylib_vhd_func.all;

entity sig_cap is
generic(
    CC_NUM               : natural := 6
);
port(
    i_clk                : in  std_logic;

    --NR_BFN
    i_nr_bfn             : in  std_logic_array12(CC_NUM-1 downto 0);

    --NR_DL_FD_DATA
    i_nr_dl_fd_fsync     : in  std_logic_vector(CC_NUM-1 downto 0);
    i_nr_dl_fd_val       : in  std_logic_array4(CC_NUM-1 downto 0);
    i_nr_dl_fd_data      : in  std_logic_array4_array32(CC_NUM-1 downto 0);       

    --NR_DL_TD_DATA
    i_nr_dl_td_fsync     : in  std_logic_vector(CC_NUM-1 downto 0);
    i_nr_dl_td_val       : in  std_logic_array4(CC_NUM-1 downto 0);
    i_nr_dl_td_data      : in  std_logic_array4_array32(CC_NUM-1 downto 0);

    --NR_DL_C_plane_DATA
    i_nr_dl_cp_fsync     : in  std_logic_vector(CC_NUM-1 downto 0);
    i_nr_dl_cp_val       : in  std_logic_array4(CC_NUM-1 downto 0);
    i_nr_dl_cp_data      : in  std_logic_array4_array32(CC_NUM-1 downto 0);

    --NR_UL_FD_DATA
    i_nr_ul_fd_fsync     : in  std_logic_vector(CC_NUM-1 downto 0);
    i_nr_ul_fd_val       : in  std_logic_array4(CC_NUM-1 downto 0);
    i_nr_ul_fd_data      : in  std_logic_array4_array32(CC_NUM-1 downto 0);

    --NR_UL_TD_DATA
    i_nr_ul_td_fsync     : in  std_logic_vector(CC_NUM-1 downto 0);
    i_nr_ul_td_val       : in  std_logic_array4(CC_NUM-1 downto 0);
    i_nr_ul_td_data      : in  std_logic_array4_array32(CC_NUM-1 downto 0);

    --NR_RA_FD_DATA
    i_nr_ra_fd_fsync     : in  std_logic_vector(CC_NUM-1 downto 0);
    i_nr_ra_fd_val       : in  std_logic_array4(CC_NUM-1 downto 0);
    i_nr_ra_fd_data      : in  std_logic_array4_array32(CC_NUM-1 downto 0);

    --NR_RA_C_plane_DATA
    i_nr_ra_cp_fsync     : in  std_logic_vector(CC_NUM-1 downto 0);
    i_nr_ra_cp_val       : in  std_logic_array4(CC_NUM-1 downto 0);
    i_nr_ra_cp_data      : in  std_logic_array4_array32(CC_NUM-1 downto 0);

    --DUMP_SETTING
    i_dump_en            : in  std_logic;
    i_dump_cc_set        : in  std_logic_vector(log2ceil(CC_NUM)-1 downto 0);
    i_dump_ant_set       : in  std_logic_vector(1 downto 0);
    i_dump_frm_set       : in  std_logic_vector(2 downto 0);
    i_dump_slt_set       : in  std_logic_vector(5 downto 0);
    i_dump_sym_set       : in  std_logic_vector(3 downto 0);
    i_dump_idx_set       : in  std_logic_vector(2 downto 0);
    i_dump_mode          : in  std_logic_vector(2 downto 0);
    
    --SYNC_COUNTER info
    i_mu                 : in  std_logic_vector(2 downto 0);         

    --SAMPLE_RATE info
    i_sr                 : in  std_logic_vector(2 downto 0);         

    --DUMP_OUTPUT
    o_dump_val           : out std_logic;
    o_dump_data          : out std_logic_vector(31 downto 0);
    o_dump_addr          : out std_logic_vector(14 downto 0)
);
end sig_cap;

architecture arc_sig_cap of sig_cap is

component dump_sel is
port(
    i_clk                : in  std_logic;
    i_bfn                : in  std_logic_vector(11 downto 0);

    i_dump_fsync         : in  std_logic; 
    i_dump_val           : in  std_logic;
    i_dump_data          : in  std_logic_vector(31 downto 0);
    
    i_dump_en            : in  std_logic;
    i_dump_frm_set       : in  std_logic_vector(2 downto 0); 
    i_dump_slt_set       : in  std_logic_vector(5 downto 0);
    i_dump_sym_set       : in  std_logic_vector(3 downto 0);
    i_dump_mode          : in  std_logic_vector(2 downto 0);
    
    i_mu                 : in  std_logic_vector(2 downto 0);     

    o_dump_val           : out std_logic;
    o_dump_data          : out std_logic_vector(31 downto 0);
    o_dump_addr          : out std_logic_vector(14 downto 0)
);
end component;


signal  r_dump_en         : std_logic := '0';
signal  r_dump_cc_set     : std_logic_vector(log2ceil(CC_NUM)-1 downto 0) := (others => '0');
signal  r_dump_ant_set    : std_logic_vector(1 downto 0) := (others => '0');
signal  r_dump_frm_set    : std_logic_vector(2 downto 0) := (others => '0');
signal  r_dump_slt_set    : std_logic_vector(5 downto 0) := (others => '0');
signal  r_dump_sym_set    : std_logic_vector(3 downto 0) := (others => '0');
signal  r_dump_idx_set    : std_logic_vector(2 downto 0) := (others => '0');
signal  r_dump_mode       : std_logic_vector(2 downto 0) := (others => '0');

signal  r_mu              : std_logic_vector(2 downto 0) := (others => '0');
signal  r_sr              : std_logic_vector(2 downto 0) := (others => '0');    

signal  set_dump_fsync    : std_logic := '0';
signal  set_dump_val      : std_logic := '0';
signal  set_dump_data     : std_logic_vector(31 downto 0) := (others => '0');

signal  set_dump_fsync_1d : std_logic := '0';
signal  set_dump_val_1d   : std_logic := '0';
signal  set_dump_data_1d  : std_logic_vector(31 downto 0) := (others => '0');

signal  r_bfn             : std_logic_vector(11 downto 0) := (others => '0');

signal  r_set_dump_fsync  : std_logic := '0';
signal  r_set_dump_val    : std_logic := '0';
signal  r_set_dump_data   : std_logic_vector(31 downto 0) := (others => '0');

signal  r_dump_val        : std_logic := '0';
signal  r_dump_data       : std_logic_vector(31 downto 0) := (others => '0');
signal  r_dump_addr       : std_logic_vector(14 downto 0) := (others => '0');

signal  r_sr_cnt          : std_logic_vector(5 downto 0) := (others => '0');

signal  num_cc            : integer := 0; 
signal  num_ant           : integer := 0;

begin   

    process (i_clk) begin
        if (i_clk'event) and (i_clk = '1') then
            r_dump_en <= i_dump_en;
            if (r_dump_en = '1') then
                r_dump_cc_set  <= i_dump_cc_set;  
                r_dump_ant_set <= i_dump_ant_set;
                r_dump_frm_set <= i_dump_frm_set;
                r_dump_slt_set <= i_dump_slt_set;
                r_dump_sym_set <= i_dump_sym_set;
                r_dump_idx_set <= i_dump_idx_set;
                r_dump_mode    <= i_dump_mode;
                r_mu           <= i_mu;
                r_sr           <= i_sr;
            end if;
        end if;
    end process;

    num_cc  <= conv_integer(r_dump_cc_set);
    num_ant <= conv_integer(r_dump_ant_set);

    --dump num_cc num_ant setting
    process (i_clk) begin
        if (i_clk'event) and (i_clk = '1') then
            r_bfn <= i_nr_bfn(num_cc)(11 downto 0);
            case r_dump_idx_set is
                when "000" =>
                    set_dump_fsync <= i_nr_dl_fd_fsync(num_cc);
                    set_dump_val   <= i_nr_dl_fd_val(num_cc)(num_ant);
                    set_dump_data  <= i_nr_dl_fd_data(num_cc)(num_ant);
                when "001" =>
                    set_dump_fsync <= i_nr_dl_td_fsync(num_cc);
                    set_dump_val   <= i_nr_dl_td_val(num_cc)(num_ant);
                    set_dump_data  <= i_nr_dl_td_data(num_cc)(num_ant);
                when "010" =>
                    set_dump_fsync <= i_nr_dl_cp_fsync(num_cc);
                    set_dump_val   <= i_nr_dl_cp_val(num_cc)(num_ant);
                    set_dump_data  <= i_nr_dl_cp_data(num_cc)(num_ant);
                when "011" =>
                    set_dump_fsync <= i_nr_ul_fd_fsync(num_cc);
                    set_dump_val   <= i_nr_ul_fd_val(num_cc)(num_ant);
                    set_dump_data  <= i_nr_ul_fd_data(num_cc)(num_ant);
                when "100" =>
                    set_dump_fsync <= i_nr_ul_td_fsync(num_cc);
                    set_dump_val   <= i_nr_ul_td_val(num_cc)(num_ant);
                    set_dump_data  <= i_nr_ul_td_data(num_cc)(num_ant);
                when "101" =>
                    set_dump_fsync <= i_nr_ra_fd_fsync(num_cc);
                    set_dump_val   <= i_nr_ra_fd_val(num_cc)(num_ant);
                    set_dump_data  <= i_nr_ra_fd_data(num_cc)(num_ant);
                when "110" =>
                    set_dump_fsync <= i_nr_ra_cp_fsync(num_cc);
                    set_dump_val   <= i_nr_ra_cp_val(num_cc)(num_ant);
                    set_dump_data  <= i_nr_ra_cp_data(num_cc)(num_ant);
                when others =>
                    set_dump_fsync <= '0';
                    set_dump_val   <= '0';
                    set_dump_data  <= (others => '0');
            end case;
        end if;
    end process;
  
    --dump splating rate setting counter
    process (i_clk) begin
        if (i_clk'event) and (i_clk ='1') then
            if (set_dump_fsync = '1') then
                r_sr_cnt <= (others => '0');
            else
                r_sr_cnt <= r_sr_cnt + '1';
            end if;
        end if;
    end process;

    process (i_clk) begin
        if (i_clk'event) and (i_clk = '1') then
            set_dump_fsync_1d <= set_dump_fsync; 
            set_dump_val_1d   <= set_dump_val;  
            set_dump_data_1d  <= set_dump_data; 
        end if;
    end process;

    --dump smpling rate setting
    process (i_clk) begin
        if (i_clk'event) and (i_clk ='1') then
            case r_sr is
                when "000" =>  --245.76 
                    r_set_dump_fsync <= set_dump_fsync_1d;
                    r_set_dump_val   <= set_dump_val_1d;
                    r_set_dump_data  <= set_dump_data_1d;
                when "001" =>  --122.88
                    if(r_sr_cnt(0) = '0') then
                        r_set_dump_fsync <= set_dump_fsync_1d;
                        r_set_dump_val   <= set_dump_val_1d;
                        r_set_dump_data  <= set_dump_data_1d;
                    else 
                        r_set_dump_fsync <= '0';
                        r_set_dump_val   <= '0';
                        r_set_dump_data  <= (others => '0');
                    end if;
                when "010" =>  --61.44
                    if(r_sr_cnt(1 downto 0) = "00") then
                        r_set_dump_fsync <= set_dump_fsync_1d;
                        r_set_dump_val   <= set_dump_val_1d;
                        r_set_dump_data  <= set_dump_data_1d;
                    else 
                        r_set_dump_fsync <= '0';
                        r_set_dump_val   <= '0';
                        r_set_dump_data  <= (others => '0');
                    end if;
                when "011" =>  --30.72
                    if(r_sr_cnt(2 downto 0) = "000") then
                        r_set_dump_fsync <= set_dump_fsync_1d;
                        r_set_dump_val   <= set_dump_val_1d;
                        r_set_dump_data  <= set_dump_data_1d;
                    else 
                        r_set_dump_fsync <= '0';
                        r_set_dump_val   <= '0';
                        r_set_dump_data  <= (others => '0');
                    end if;
                when "100" =>  --15.36
                    if(r_sr_cnt(3 downto 0) = "0000") then
                        r_set_dump_fsync <= set_dump_fsync_1d;
                        r_set_dump_val   <= set_dump_val_1d;
                        r_set_dump_data  <= set_dump_data_1d;
                    else 
                        r_set_dump_fsync <= '0';
                        r_set_dump_val   <= '0';
                        r_set_dump_data  <= (others => '0');
                    end if;
                when "101" =>  --7.68
                    if(r_sr_cnt(4 downto 0) = "00000") then
                        r_set_dump_fsync <= set_dump_fsync_1d;
                        r_set_dump_val   <= set_dump_val_1d;
                        r_set_dump_data  <= set_dump_data_1d;
                    else 
                        r_set_dump_fsync <= '0';
                        r_set_dump_val   <= '0';
                        r_set_dump_data  <= (others => '0');
                    end if;
                when others =>
                    r_set_dump_fsync <= '0';
                    r_set_dump_val   <= '0'; 
                    r_set_dump_data  <= (others => '0');
            end case;
        end if;
    end process;
  
    U_dump_sel : dump_sel
    port map(
        i_clk           =>  i_clk,
        i_bfn           =>  r_bfn,
                                          
        i_dump_fsync    =>  r_set_dump_fsync,  
        i_dump_val      =>  r_set_dump_val,    
        i_dump_data     =>  r_set_dump_data,   
                            
        i_dump_en       =>  r_dump_en,
        i_dump_frm_set  =>  r_dump_frm_set,
        i_dump_slt_set  =>  r_dump_slt_set,
        i_dump_sym_set  =>  r_dump_sym_set,
        i_dump_mode     =>  r_dump_mode, 
                            
        i_mu            =>  r_mu,          
                                          
        o_dump_val      =>  r_dump_val,    
        o_dump_data     =>  r_dump_data,   
        o_dump_addr     =>  r_dump_addr 
    );

    o_dump_val  <= r_dump_val;
    o_dump_data <= r_dump_data;
    o_dump_addr <= r_dump_addr;


end arc_sig_cap;
