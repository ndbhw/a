---------------------------------------------------------------------------------
--
-- Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
--
--  Project      : ATnT HRU, VzW FSU20
--  Module       : dump_sel
--  Author       : jiung.woo@samsung.com
--  Description  : select dump data by frame, slot, symbol setting  
--
--  Revision History
--  ------------+---------------+-----------------------------------------------
--     Date     |   Author      |   Description
--  ------------+---------------+-----------------------------------------------
--   2020.06.16 | jiung.woo     | initial release
--  ------------+---------------+-----------------------------------------------
--   2020.10.12 | jiung.woo     | dump initial process ( write all '0' -> fsync input -> dump data) 
--  ------------+---------------+-----------------------------------------------
--
---------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_textio.all;
use IEEE.numeric_std.all;
use STD.textio.all;
use work.ARRAY_TYPE.all;

entity dump_sel is
port(
    i_clk                : in  std_logic;
    i_bfn                : in  std_logic_vector(11 downto 0);

    i_dump_fsync         : in  std_logic; 
    i_dump_val           : in  std_logic;
    i_dump_data          : in  std_logic_vector(31 downto 0);
    
    i_dump_en            : in  std_logic;
    i_dump_frm_set       : in  std_logic_vector(2 downto 0); 
    i_dump_slt_set       : in  std_logic_vector(5 downto 0);
    i_dump_sym_set       : in  std_logic_vector(3 downto 0);
    i_dump_mode          : in  std_logic_vector(2 downto 0);
    
    i_mu                 : in  std_logic_vector(2 downto 0);     

    o_dump_val           : out std_logic;
    o_dump_data          : out std_logic_vector(31 downto 0);
    o_dump_addr          : out std_logic_vector(14 downto 0)
);
end dump_sel;

architecture arc_dump_sel of dump_sel is

component ref_vsync_gen is
port(
    i_clk                : in  std_logic;
    i_mu                 : in  std_logic_vector(2 downto 0);
    i_retard             : in  std_logic_vector(21 downto 0); 
    i_frame_sync         : in  std_logic;
    i_en                 : in  std_logic;
    o_frame_sync         : out std_logic; 
    o_subfrm_sync        : out std_logic;
    o_slot_sync          : out std_logic;
    o_symbol_sync        : out std_logic;     
    o_subfrm             : out std_logic_vector(3 downto 0);
    o_slot               : out std_logic_vector(7 downto 0);
    o_symbol             : out std_logic_vector(3 downto 0)
);
end component;

signal r_dump_en         : std_logic := '0';
signal r_dump_frm_set    : std_logic_vector(2 downto 0) := (others => '0');
signal r_dump_slt_set    : std_logic_vector(5 downto 0) := (others => '0');
signal r_dump_sym_set    : std_logic_vector(3 downto 0) := (others => '0');
signal r_dump_mode       : std_logic_vector(1 downto 0) := (others => '0');

signal r_dump_fsync      : std_logic := '0';

signal w_frame_sync      : std_logic := '0'; 
signal w_subfrm_sync     : std_logic := '0';
signal w_slot_sync       : std_logic := '0';
signal w_symbol_sync     : std_logic := '0';     
signal w_subfrm          : std_logic_vector(3 downto 0) := (others => '0');
signal w_slot            : std_logic_vector(7 downto 0) := (others => '0');
signal w_symbol          : std_logic_vector(3 downto 0) := (others => '0');

signal r_frame           : std_logic_vector(2 downto 0) := (others => '0');
signal r_slot            : std_logic_vector(7 downto 0) := (others => '0');
signal r_symbol          : std_logic_vector(3 downto 0) := (others => '0');

signal r_dump_val        : std_logic_vector(6 downto 0) := (others => '0');
signal r_dump_data       : std_logic_array32(6 downto 0) := (others => (others => '0'));

signal r_dump_val_mod0   : std_logic := '0';
signal r_dump_data_mod0  : std_logic_vector(31 downto 0) := (others => '0');
signal r_dump_addr_mod0  : std_logic_vector(15 downto 0) := (others => '1');

signal r_dump_val_mod1   : std_logic := '0';
signal r_dump_data_mod1  : std_logic_vector(31 downto 0) := (others => '0');
signal r_dump_addr_mod1  : std_logic_vector(15 downto 0) := (others => '1');

signal r_dump_val_mod2   : std_logic := '0';
signal r_dump_data_mod2  : std_logic_vector(31 downto 0) := (others => '0');
signal r_dump_addr_mod2  : std_logic_vector(15 downto 0) := (others => '1');

signal r_dump_val_mod3   : std_logic := '0';
signal r_dump_data_mod3  : std_logic_vector(31 downto 0) := (others => '0');
signal r_dump_addr_mod3  : std_logic_vector(15 downto 0) := (others => '1');
signal dump_mod3_start   : std_logic := '0';

signal r_frm_cnt         : std_logic_vector( 2 downto 0) := (others => '1');

signal r_dump_en_rising  : std_logic_vector( 1 downto 0) := (others => '0');
signal initial_cnt       : std_logic_vector(15 downto 0) := (others => '1');
signal initial_done      : std_logic := '0';
signal dump_overwrite    : std_logic := '0';

begin   

    process (i_clk) begin
        if (i_clk'event) and (i_clk = '1') then
            r_dump_en_rising <= r_dump_en_rising(0) & i_dump_en;
            if (r_dump_en_rising = "01") then
                initial_cnt  <= (others => '0');
                initial_done <= '0';
            elsif (initial_cnt = conv_std_logic_vector(32767, 16)) then
                initial_done <= '1';
                initial_cnt   <= initial_cnt;                
            else
                initial_cnt   <= initial_cnt + '1';
            end if;
        end if;
    end process;

    process (i_clk) begin
        if (i_clk'event) and (i_clk = '1') then
            r_dump_fsync <= i_dump_fsync;
            if (initial_done = '1') then
                if (i_dump_fsync = '1') then
                    if (i_dump_mode(2) = '1') then
                        dump_overwrite <= '1';
                    else
                        dump_overwrite <= '0';
                    end if;
                    r_dump_frm_set <= i_dump_frm_set;
                    r_dump_slt_set <= i_dump_slt_set;
                    r_dump_sym_set <= i_dump_sym_set;
                    r_dump_mode    <= i_dump_mode(1 downto 0);
                    r_frame        <= i_bfn(2 downto 0);
                
                    if (r_dump_en_rising = "11") then
                        r_dump_en <= '1';
                    else
                        r_dump_en <= '0';
                        dump_overwrite <= '0';
                    end if;
                end if;
            else
                r_dump_en <= '0';
                dump_overwrite <= '0';
            end if;
        end if;
    end process;

    process (i_clk) begin
        if (i_clk'event) and (i_clk = '1') then
            r_dump_val     <= r_dump_val(5 downto 0) & i_dump_val;
            r_dump_data    <= r_dump_data(5 downto 0) & i_dump_data; 
        end if;
    end process;

    --frame number count
    process (i_clk) begin
        if (i_clk'event) and (i_clk = '1') then
            --if (w_frame_sync = '1') then
            --    r_frm_cnt <= r_frm_cnt + 1;
            --end if; 
            r_slot   <= w_slot;
            r_symbol <= w_symbol;
        end if;
    end process;

    --dump mode "0"
    process (i_clk) begin
        if (i_clk'event) and (i_clk ='1') then
            if (r_dump_en = '1') then
                if (r_dump_fsync = '1') then
                    if (dump_overwrite = '1') then
                        r_dump_addr_mod0 <= (others => '1');
                    end if;
                elsif (r_dump_addr_mod0 = conv_std_logic_vector(32767, 16)) then
                    r_dump_val_mod0  <= '0';
                    r_dump_data_mod0 <= (others => '0');
                else 
                    if ((r_dump_frm_set = r_frame) and
                        (r_dump_slt_set = r_slot) and
                        (r_dump_sym_set = r_symbol)) then
                        r_dump_val_mod0 <= '1';
                        r_dump_data_mod0 <= r_dump_data(4);
                        r_dump_addr_mod0 <= r_dump_addr_mod0 + '1';
                    else 
                        r_dump_val_mod0 <= '0';
                    end if;
                end if;
            else
                r_dump_addr_mod0 <= (others => '1');
            end if;
        end if;
    end process;

    --dump mode "1"
    process (i_clk) begin
        if (i_clk'event) and (i_clk ='1') then
            if (r_dump_en = '1') then
                if (r_dump_fsync = '1') then
                    if (dump_overwrite = '1') then
                        r_dump_addr_mod1 <= (others => '1');
                    end if;
                elsif (r_dump_addr_mod1 = conv_std_logic_vector(32767, 16)) then
                    r_dump_val_mod1  <= '0';
                    r_dump_data_mod1 <= (others => '0');
                else 
                    if ((r_dump_frm_set = r_frame) and
                        (r_dump_slt_set = r_slot) and
                        (r_dump_sym_set = r_symbol)) then
                        r_dump_val_mod1 <= '1';
                        r_dump_data_mod1 <= r_dump_data(4)(31 downto 1) & r_dump_val(5);
                        r_dump_addr_mod1 <= r_dump_addr_mod1 + '1';
                    else 
                        r_dump_val_mod1 <= '0';
                    end if;
                end if;
            else
                r_dump_addr_mod1 <= (others => '1');
            end if;
        end if;
    end process;

    --dump mode "2"
    process (i_clk) begin
        if (i_clk'event) and (i_clk ='1') then
            if (r_dump_en = '1') then
                if (r_dump_fsync = '1') then
                    if (dump_overwrite = '1') then
                        r_dump_addr_mod2 <= (others => '1');
                    end if;
                elsif (r_dump_addr_mod2 = conv_std_logic_vector(32767, 16)) then
                    r_dump_val_mod2  <= '0';
                    r_dump_data_mod2 <= (others => '0');
                else 
                    if ((r_dump_frm_set = r_frame) and
                        (r_dump_slt_set = r_slot) and
                        (r_dump_sym_set = r_symbol) and
                        (r_dump_val(4) = '1')) then
                        r_dump_val_mod2 <= '1';
                        r_dump_data_mod2 <= r_dump_data(4);
                        r_dump_addr_mod2 <= r_dump_addr_mod2 + '1';
                    else 
                        r_dump_val_mod2 <= '0';
                    end if;
                end if;
            else
                r_dump_addr_mod2 <= (others => '1');
            end if;
        end if;
    end process;

    --dump mode "3"
    process (i_clk) begin
        if (i_clk'event) and (i_clk ='1') then
            if (r_dump_en = '1') then
                if (r_dump_fsync = '1') then
                    if (dump_overwrite = '1') then
                        r_dump_addr_mod3 <= (others => '1');
                        dump_mod3_start <= '0';
                    end if;
                elsif (r_dump_addr_mod3 = conv_std_logic_vector(32767, 16)) then
                    r_dump_val_mod3  <= '0';
                    r_dump_data_mod3 <= (others => '0');
                    dump_mod3_start  <= '0';
                else 
                    if ((r_dump_frm_set = r_frame) and
                        (r_dump_slt_set = r_slot) and
                        (r_dump_sym_set = r_symbol)) then
                        dump_mod3_start <= '1';
                    end if;

                    if ((dump_mod3_start = '1') and (r_dump_val(5) = '1')) then
                        r_dump_val_mod3 <= '1';
                        r_dump_data_mod3 <= r_dump_data(5);
                        r_dump_addr_mod3 <= r_dump_addr_mod3 + '1';
                    else 
                        r_dump_val_mod3 <= '0';
                    end if;
                end if;
            else
                r_dump_addr_mod3 <= (others => '1');
            end if;
        end if;
    end process; 

    process (i_clk) begin
        if (i_clk'event) and (i_clk = '1') then
            if (initial_done = '0') then
                o_dump_val  <= '1';
                o_dump_data <= (others => '0');
                o_dump_addr <= initial_cnt(14 downto 0);
            else
                case r_dump_mode(1 downto 0) is
                    when "00" =>
                        o_dump_val  <= r_dump_val_mod0;
                        o_dump_data <= r_dump_data_mod0;
                        o_dump_addr <= r_dump_addr_mod0(14 downto 0);
                    when "01" =>
                        o_dump_val  <= r_dump_val_mod1;
                        o_dump_data <= r_dump_data_mod1;
                        o_dump_addr <= r_dump_addr_mod1(14 downto 0);
                    when "10" =>
                        o_dump_val  <= r_dump_val_mod2;
                        o_dump_data <= r_dump_data_mod2;
                        o_dump_addr <= r_dump_addr_mod2(14 downto 0);
                    when "11" =>
                        o_dump_val  <= r_dump_val_mod3;
                        o_dump_data <= r_dump_data_mod3;
                        o_dump_addr <= r_dump_addr_mod3(14 downto 0);
                    when others =>
                        o_dump_val  <= '0';
                        o_dump_data <= (others => '0');
                        o_dump_addr <= (others => '0');
                end case;
            end if;
        end if;
    end process;

    U_ref_vsync_gen : ref_vsync_gen
    port map(
        i_clk          =>  i_clk,
        i_mu           =>  i_mu,
        i_retard       =>  conv_std_logic_vector(2, 22),
        i_frame_sync   =>  r_dump_fsync,
        i_en           =>  r_dump_en,
        o_frame_sync   =>  w_frame_sync, 
        o_subfrm_sync  =>  w_subfrm_sync,
        o_slot_sync    =>  w_slot_sync,  
        o_symbol_sync  =>  w_symbol_sync,
        o_subfrm       =>  w_subfrm,     
        o_slot         =>  w_slot,       
        o_symbol       =>  w_symbol    
    );

end arc_dump_sel;
