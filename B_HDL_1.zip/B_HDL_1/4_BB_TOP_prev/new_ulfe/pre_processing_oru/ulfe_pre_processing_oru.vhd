-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.08.03 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;

library work;
use work.ulfe_func.all;
use work.ulfe_component_pack_oru.all;
use work.ulfe_config_oru.all;

entity ulfe_pre_processing_oru is
    generic (
        NUM_RX_ANT                                  : integer := 4;
        NUM_CHAIN                                   : integer := 0
    );
    Port (
        i_rst                                       : in std_logic;
        i_clk                                       : in std_logic;
        
        i_fsync_err_flag                            : in std_logic;
        
        --INPUT
        i_frameidx                                  : in std_logic_vector(8-1 downto 0);
        i_10ms_sync                                 : in std_logic;
        i_data_vld                                  : in std_logic_vector(NUM_RX_ANT-1 downto 0);
        i_data_i                                    : in std_logic_vector(15-1 downto 0);
        i_data_q                                    : in std_logic_vector(15-1 downto 0);
        
        i_fs_num                                    : in std_logic_vector(5-1 downto 0);
        i_SR_info                                   : in std_logic_vector(3-1 downto 0);        -- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76
        
        --FREQSHIFT
        i_freqShiftOn                               : in std_logic;
        --CPRM
        i_cpRmOffset                                : in std_logic_vector(11-1 downto 0);
        --TDAGC
        i_tagcBackoff                               : in std_logic_vector(5-1 downto 0);
        i_tagcOn                                    : in std_logic;
        --FFT
        i_fftType                                   : in std_logic_vector(2-1 downto 0);
        i_k0                                        : in std_logic_vector(12-1 downto 0);
        i_rbSize                                    : in std_logic_vector(9-1 downto 0);
        --GAINCOMP
        i_gainCompOn                                : in std_logic;
        --CTS
        i_cts_on                                    : in std_logic;
        i_cts_shft                                  : in std_logic_vector(12-1 downto 0);
        --PHASECOMP
        i_phaseCompOn                               : in std_logic;
        --only DSS
        i_phaseCompBypass                           : in std_logic;
        
        o_PHASECOMP_sync_adv_5clk                   : out std_logic;
        o_PHASECOMP_vld                             : out std_logic_vector(NUM_RX_ANT-1 downto 0);
        
        i_phasecomp_weight_i                        : in std_logic_vector(16-1 downto 0);
        i_phasecomp_weight_q                        : in std_logic_vector(16-1 downto 0);
        
        --CALB
        i_calOn                                     : in std_logic;
        i_calBypassFlag_F                           : in std_logic;
        i_calBypassFlag_E                           : in std_logic;
        i_calWScale                                 : in std_logic_vector(4-1 downto 0);
        
        i_calW_rd_wt_sel                            : in std_logic;
        i_calW_wt_buf                               : in std_logic;
        i_calW_ant_num                              : in std_logic_vector(6-1 downto 0);
        i_calW_wt_en                                : in std_logic;
        i_calW_wt_addr                              : in std_logic_vector(9-1 downto 0);
        i_calW_iq                                   : in std_logic_vector(24-1 downto 0);
        o_calW_rd_data                              : out std_logic_vector(24-1 downto 0);
        
        --OUTPUT
        o_frameidx                                  : out std_logic_vector(8-1 downto 0);
        o_subframeidx                               : out std_logic_vector(4-1 downto 0);
        o_slot_idx                                  : out std_logic_vector(6-1 downto 0);
        o_symbol_sync                               : out std_logic;
        o_symbol_idx                                : out std_logic_vector(4-1 downto 0);
        o_10ms_sync                                 : out std_logic;
        o_data_vld                                  : out std_logic_vector(NUM_RX_ANT-1 downto 0);
        o_start_re                                  : out std_logic_vector(NUM_RX_ANT-1 downto 0);
        o_last_re                                   : out std_logic_vector(NUM_RX_ANT-1 downto 0);
        o_data_iq                                   : out std_logic_vector(NUM_RX_ANT*32-1 downto 0);
        
        o_fft_rst_count                             : out std_logic_vector(8-1 downto 0);
        
        o_tdagc_fsync                               : out std_logic;
        o_tdagc_vld                                 : out std_logic;
        o_tdrssi                                    : out std_logic_array32(NUM_RX_ANT-1 downto 0);
        
        o_bfn_strb_in_ulfeout                       : out std_logic
    );
end ulfe_pre_processing_oru;

architecture Behavioral of ulfe_pre_processing_oru is

    signal  r_rst                                   : std_logic;
    signal  rst_fft                                 : std_logic;
    signal  fft_rst_count                           : std_logic_vector(8-1 downto 0);
    signal  fsync_err_flag                          : std_logic;
    
    signal  i_rbSize_reg                            : std_logic_array9(2-1 downto 0);
    
    signal  w_freqshift_sync                        : std_logic;
    signal  w_freqshift_vld                         : std_logic_vector(NUM_RX_ANT-1 downto 0);
    signal  w_freqshift_i                           : std_logic_vector(15-1 downto 0);
    signal  w_freqshift_q                           : std_logic_vector(15-1 downto 0);
    
    signal  w_sample_cnt                            : std_logic_vector(13-1 downto 0);
    signal  w_cp_size                               : std_logic_vector(12-1 downto 0);
    
    signal  w_cprm_sync                             : std_logic;
    signal  w_cprm_vld                              : std_logic_vector(NUM_RX_ANT-1 downto 0);
    signal  w_cprm_i                                : std_logic_vector(15-1 downto 0);
    signal  w_cprm_q                                : std_logic_vector(15-1 downto 0);
    
    signal  w_tdagc_sync                            : std_logic;
    signal  w_tdagc_vld                             : std_logic;
    signal  w_tdagc_vld_sync                        : std_logic;
    signal  w_tdagc_i                               : std_logic_vector(15-1 downto 0);
    signal  w_tdagc_q                               : std_logic_vector(15-1 downto 0);
    
    signal  w_tdGain_vld                            : std_logic;
    signal  w_tdGain1                               : std_logic_array4(NUM_RX_ANT-1 downto 0);
    signal  w_tdGain2                               : std_logic_array5(NUM_RX_ANT-1 downto 0);
	signal  w_tdGain1_fft                           : std_logic_array4(NUM_RX_ANT-1 downto 0);
    signal  w_tdGain2_fft                           : std_logic_array5(NUM_RX_ANT-1 downto 0);
    
    signal  w_fft_sync_adv_1clk                     : std_logic;
    signal  w_fft_vld                               : std_logic_vector(NUM_RX_ANT-1 downto 0);
    signal  w_fft_vld_adv_2clk                      : std_logic;
    signal  w_fft_i                                 : std_logic_vector(15-1 downto 0);
    signal  w_fft_q                                 : std_logic_vector(15-1 downto 0);
    
    signal  w_gaincomp_sync                         : std_logic;
    signal  w_gaincomp_vld_adv_5clk                 : std_logic_vector(NUM_RX_ANT-1 downto 0);
    signal  w_gaincomp_ant_num                      : std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
    signal  w_gaincomp_i                            : std_logic_vector(15-1 downto 0);
    signal  w_gaincomp_q                            : std_logic_vector(15-1 downto 0);
    
    signal  w_calb_sync                             : std_logic;
    signal  w_calb_vld_adv_5clk                     : std_logic_vector(NUM_RX_ANT-1 downto 0);
    signal  w_calb_i                                : std_logic_vector(15-1 downto 0);
    signal  w_calb_q                                : std_logic_vector(15-1 downto 0);
    
    signal  w_cts_sync_adv_5clk                     : std_logic;
    signal  w_cts_vld                               : std_logic_vector(NUM_RX_ANT-1 downto 0);
    signal  w_cts_i                                 : std_logic_vector(15-1 downto 0);
    signal  w_cts_q                                 : std_logic_vector(15-1 downto 0);
    
    signal  w_phasecomp_i                           : std_logic_vector(16-1 downto 0);
    signal  w_phasecomp_q                           : std_logic_vector(16-1 downto 0);
    
    signal  st_ext_i_data                           : std_logic_vector(2-1 downto 0);
    signal  data_vld_err                            : std_logic_vector(2-1 downto 0);
    signal  sync_unexpected                         : std_logic_vector(2-1 downto 0);
    
    signal  i_10ms_sync_1dd                         : std_logic;
    signal  i_10ms_sync_reg                         : std_logic_vector(5-1 downto 0);

    signal  i_10ms_sync_d                           : std_logic;
    signal  i_data_vld_d                            : std_logic_vector(NUM_RX_ANT-1 downto 0);
    signal  i_data_i_d                              : std_logic_vector(15-1 downto 0);
    signal  i_data_q_d                              : std_logic_vector(15-1 downto 0);

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            st_ext_i_data(1)                        <=  st_ext_i_data(0);
            data_vld_err(1)                         <=  data_vld_err(0);
            sync_unexpected(1)                      <=  sync_unexpected(0);
            i_rbSize_reg                            <=  i_rbSize_reg(0) & i_rbSize;
            fsync_err_flag                          <=  i_fsync_err_flag;
            r_rst                                   <=  (i_rst or rst_fft);
        end if;
    end process;

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            i_10ms_sync_1dd                         <=  i_10ms_sync;
            if (rst_fft = '1' and i_10ms_sync_1dd = '0' and i_10ms_sync = '1') then
                i_10ms_sync_reg                     <=  i_10ms_sync_reg(3 downto 0) & '1';
            elsif (rst_fft = '0') then
                i_10ms_sync_reg                     <=  (others=>'0');
            else
                i_10ms_sync_reg                     <=  i_10ms_sync_reg;
            end if;
        end if;
    end process;

    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            rst_fft                                 <=  '0';
            fft_rst_count                           <=  (others=>'0');
        elsif (rising_edge(i_clk)) then
            if (st_ext_i_data = b"01" or data_vld_err = b"01" or sync_unexpected = b"01") then
                rst_fft                             <=  '1';
                fft_rst_count                       <=  fft_rst_count + '1';
            elsif (i_10ms_sync_reg(4) = '1') then
                rst_fft                             <=  '0';
                fft_rst_count                       <=  fft_rst_count;
            else
                rst_fft                             <=  rst_fft;
                fft_rst_count                       <=  fft_rst_count;
            end if;
        end if;
    end process;
    o_fft_rst_count                                 <=  fft_rst_count;

    dly_fsync_3clk  : ulfe_lib_dly_fixed generic map(3, 1) port map(i_clk => i_clk, data_i(0) => i_10ms_sync, data_o(0) => i_10ms_sync_d);
    dly_vld_3clk    : ulfe_lib_dly_fixed generic map(3, NUM_RX_ANT) port map(i_clk, i_data_vld, i_data_vld_d);
    dly_data_i_3clk : ulfe_lib_dly_fixed generic map(3, 15) port map(i_clk, i_data_i, i_data_i_d);
    dly_data_q_3clk : ulfe_lib_dly_fixed generic map(3, 15) port map(i_clk, i_data_q, i_data_q_d);
    
    FREQSHIFT : ulfe_freqshift_oru generic map(NUM_RX_ANT)
        Port map(
            i_rst                                   =>  r_rst,                  --: in std_logic;
            i_clk                                   =>  i_clk,                  --: in std_logic;
            
            i_FREQSHIFT_sync                        =>  i_10ms_sync_d,          --: in std_logic;
            i_FREQSHIFT_vld                         =>  i_data_vld_d,           --: in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_FREQSHIFT_i                           =>  i_data_i_d,             --: in std_logic_vector(15-1 downto 0);
            i_FREQSHIFT_q                           =>  i_data_q_d,             --: in std_logic_vector(15-1 downto 0);
            
            i_fftType                               =>  i_fftType,              --: in std_logic_vector(2-1 downto 0);
            i_freqShiftOn                           =>  i_freqShiftOn,          --: in std_logic;
            
            i_fs_num                                =>  i_fs_num,               --: in std_logic_vector(5-1 downto 0);
            
            o_sample_cnt                            =>  w_sample_cnt,           --: out std_logic_vector(13-1 downto 0);
            o_cp_size                               =>  w_cp_size,              --: out std_logic_vector(12-1 downto 0);
            
            o_FREQSHIFT_sync                        =>  w_freqshift_sync,       --: out std_logic;
            o_FREQSHIFT_vld                         =>  w_freqshift_vld,        --: out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_FREQSHIFT_i                           =>  w_freqshift_i,          --: out std_logic_vector(15-1 downto 0);
            o_FREQSHIFT_q                           =>  w_freqshift_q           --: out std_logic_vector(15-1 downto 0)
        );
    
    CPRM : ulfe_cprm_oru generic map(NUM_RX_ANT)
        port map(
            i_rst                                   =>  r_rst,                  --: in std_logic;
            i_clk                                   =>  i_clk,                  --: in std_logic;
            
            i_sample_cnt                            =>  w_sample_cnt,           --: in std_logic_vector(13-1 downto 0);
            i_cp_size                               =>  w_cp_size,              --: in std_logic_vector(12-1 downto 0);
            
            i_CPRM_sync                             =>  w_freqshift_sync,       --: in std_logic;
            i_CPRM_vld                              =>  w_freqshift_vld,        --: in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_CPRM_i                                =>  w_freqshift_i,          --: in std_logic_vector(15-1 downto 0);
            i_CPRM_q                                =>  w_freqshift_q,          --: in std_logic_vector(15-1 downto 0);
            
            i_cpRmOffset                            =>  i_cpRmOffset,           --: in std_logic_vector(11-1 downto 0);
            i_fftType                               =>  i_fftType,              --: in std_logic_vector(2-1 downto 0);
            i_calBypassFlag                         =>  i_calBypassFlag_F,      --: in std_logic;
            
            o_CPRM_sync                             =>  w_cprm_sync,            --: out std_logic;
            o_CPRM_vld                              =>  w_cprm_vld,             --: out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_CPRM_i                                =>  w_cprm_i,               --: out std_logic_vector(15-1 downto 0);
            o_CPRM_q                                =>  w_cprm_q                --: out std_logic_vector(15-1 downto 0)
        );
    
    TDAGC : ulfe_tdagc_oru generic map(NUM_RX_ANT)
        port map(
            i_rst                                   =>  r_rst,                  --: in std_logic;
            i_clk                                   =>  i_clk,                  --: in std_logic;
            
            i_fs_num                                =>  i_fs_num,               --: in std_logic_vector(5-1 downto 0);
            i_SR_info                               =>  i_SR_info,              --: in std_logic_vector(3-1 downto 0);        -- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76
            
            i_TDAGC_sync                            =>  w_cprm_sync,            --: in std_logic;
            i_TDAGC_vld                             =>  w_cprm_vld,             --: in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_TDAGC_i                               =>  w_cprm_i,               --: in std_logic_vector(15-1 downto 0);
            i_TDAGC_q                               =>  w_cprm_q,               --: in std_logic_vector(15-1 downto 0);
            
            i_fftType                               =>  i_fftType,              --: in std_logic_vector(2-1 downto 0);
            
            i_calBypassFlag                         =>  i_calBypassFlag_F,      --: in std_logic;
            i_tagcOn                                =>  i_tagcOn,               --: in std_logic;
            i_tagcBackoff                           =>  i_tagcBackoff,          --: in std_logic_vector(5-1 downto 0);
            
            o_TDAGC_sync                            =>  w_tdagc_sync,           --: out std_logic;
            o_TDAGC_vld                             =>  w_tdagc_vld,            --: out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_TDAGC_vld_sync                        =>  w_tdagc_vld_sync,       --: out std_logic;
            o_TDAGC_i                               =>  w_tdagc_i,              --: out std_logic_vector(15-1 downto 0);
            o_TDAGC_q                               =>  w_tdagc_q,              --: out std_logic_vector(15-1 downto 0;
            
            o_tdGain_vld                            =>  w_tdGain_vld,           --: out std_logic;
            o_tdGain1                               =>  w_tdGain1,              --: out std_logic_array4(NUM_RX_ANT-1 downto 0);
            o_tdGain2                               =>  w_tdGain2,              --: out std_logic_array5(NUM_RX_ANT-1 downto 0);
            o_tdrssi                                =>  o_tdrssi                --: out std_logic_array32(NUM_RX_ANT-1 downto 0)
        );
    
    RPT_TDRSSI_TRUE : if (RPT_TDRSSI_ENABLE = TRUE) generate
        o_tdagc_fsync                               <=  w_tdagc_sync;
        o_tdagc_vld                                 <=  w_tdagc_vld;
    end generate RPT_TDRSSI_TRUE;
    
    RPT_TDRSSI_FALSE : if (RPT_TDRSSI_ENABLE = FALSE) generate
        o_tdagc_fsync                               <=  '0';
        o_tdagc_vld                                 <=  '0';
    end generate RPT_TDRSSI_FALSE;
    
    FFT : ulfe_fft_oru generic map(NUM_RX_ANT)
        port map(
            i_rst                                   =>  r_rst,                  --: in std_logic;
            i_clk                                   =>  i_clk,                  --: in std_logic;
            
            i_FFT_sync                              =>  w_tdagc_sync,           --: in std_logic;
            i_FFT_vld                               =>  w_tdagc_vld,            --: in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_FFT_vld_sync                          =>  w_tdagc_vld_sync,       --: in std_logic;
            i_FFT_i                                 =>  w_tdagc_i,              --: in std_logic_vector(15-1 downto 0);
            i_FFT_q                                 =>  w_tdagc_q,              --: in std_logic_vector(15-1 downto 0;
            
            i_tdGain1                               =>  w_tdGain1,              --: in std_logic_array4(NUM_RX_ANT-1 downto 0);
            i_tdGain2                               =>  w_tdGain2,              --: in std_logic_array5(NUM_RX_ANT-1 downto 0);
            
            i_fftType                               =>  i_fftType,              --: in std_logic_vector(2-1 downto 0);
            i_k0                                    =>  i_k0,                   --: in std_logic_vector(12-1 downto 0);
            i_rbSize                                =>  i_rbSize,               --: in std_logic_vector(9-1 downto 0);
            
            o_st_ext_i_data                         =>  st_ext_i_data(0),
            o_data_vld_err                          =>  data_vld_err(0),
            o_sync_unexpected                       =>  sync_unexpected(0),
            
            o_tdGain1                               =>  w_tdGain1_fft,          --: out std_logic_array4(NUM_RX_ANT-1 downto 0);
            o_tdGain2                               =>  w_tdGain2_fft,          --: out std_logic_array5(NUM_RX_ANT-1 downto 0);
            
            o_FFT_sync_adv_1clk                     =>  w_fft_sync_adv_1clk,    --: out std_logic;
            o_FFT_vld                               =>  w_fft_vld,              --: out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_FFT_vld_adv_2clk                      =>  w_fft_vld_adv_2clk,     --: out std_logic;
            o_FFT_i                                 =>  w_fft_i,                --: out std_logic_vector(15-1 downto 0);
            o_FFT_q                                 =>  w_fft_q                 --: out std_logic_vector(15-1 downto 0
        );
    
    GAINCOMP : ulfe_gaincomp_oru generic map(NUM_RX_ANT)
        port map(
            i_rst                                   =>  r_rst,                  --: in std_logic;
            i_clk                                   =>  i_clk,                  --: in std_logic;
            
            i_gainCompOn                            =>  i_gainCompOn,           --: in std_logic;
            i_calBypassFlag                         =>  i_calBypassFlag_E,      --: in std_logic;
            
            i_GAINCOMP_sync_adv_1clk                =>  w_fft_sync_adv_1clk,    --: in std_logic;
            i_GAINCOMP_vld                          =>  w_fft_vld,              --: in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_GAINCOMP_vld_adv_2clk                 =>  w_fft_vld_adv_2clk,     --: in std_logic;
            i_GAINCOMP_i                            =>  w_fft_i,                --: in std_logic_vector(15-1 downto 0);
            i_GAINCOMP_q                            =>  w_fft_q,                --: in std_logic_vector(15-1 downto 0);
            
            i_tdGain1                               =>  w_tdGain1_fft,          --: in std_logic_array4(NUM_RX_ANT-1 downto 0);
            i_tdGain2                               =>  w_tdGain2_fft,          --: in std_logic_array5(NUM_RX_ANT-1 downto 0);
            
            o_GAINCOMP_sync                         =>  w_gaincomp_sync,            --: out std_logic;
            o_GAINCOMP_vld_adv_5clk                 =>  w_gaincomp_vld_adv_5clk,    --: out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_GAINCOMP_ant_num                      =>  w_gaincomp_ant_num,         --: out std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
            o_GAINCOMP_i                            =>  w_gaincomp_i,               --: out std_logic_vector(15-1 downto 0);
            o_GAINCOMP_q                            =>  w_gaincomp_q                --: out std_logic_vector(15-1 downto 0)
        );
    
    CALB_TRUE : if (CALB_MODULE = TRUE) generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                o_bfn_strb_in_ulfeout               <=  w_fft_sync_adv_1clk;
            end if;
        end process;
        
        CALB : ulfe_calb_oru generic map(NUM_RX_ANT,NUM_CHAIN)
            port map(
                i_rst                               =>  r_rst,                  --: in std_logic;
                i_clk                               =>  i_clk,                  --: in std_logic;
                
                i_CALB_sync                         =>  w_gaincomp_sync,            --: in std_logic;
                i_CALB_vld_adv_5clk                 =>  w_gaincomp_vld_adv_5clk,    --: in std_logic_vector(NUM_RX_ANT-1 downto 0);
                i_CALB_ant_num                      =>  w_gaincomp_ant_num,         --: in std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
                i_CALB_i                            =>  w_gaincomp_i,               --: in std_logic_vector(15-1 downto 0);
                i_CALB_q                            =>  w_gaincomp_q,               --: in std_logic_vector(15-1 downto 0);
                
                i_calOn                             =>  i_calOn,                --: in std_logic;
                i_calBypassFlag                     =>  i_calBypassFlag_E,      --: in std_logic;
                i_calWScale                         =>  i_calWScale,            --: in std_logic_vector(4-1 downto 0);
                
                i_calW_rd_wt_sel                    =>  i_calW_rd_wt_sel,       --: in std_logic;
                i_calW_wt_buf                       =>  i_calW_wt_buf,          --: in std_logic;
                i_calW_ant_num                      =>  i_calW_ant_num,         --: in std_logic_vector(6-1 downto 0);
                i_calW_wt_en                        =>  i_calW_wt_en,           --: in std_logic;
                i_calW_wt_addr                      =>  i_calW_wt_addr,         --: in std_logic_vector(9-1 downto 0);
                i_calW_iq                           =>  i_calW_iq,              --: in std_logic_vector(24-1 downto 0);
                o_calW_rd_data                      =>  o_calW_rd_data,         --: out std_logic_vector(24-1 downto 0);
                
                o_CALB_sync                         =>  w_calb_sync,            --: out std_logic;
                o_CALB_vld_adv_5clk                 =>  w_calb_vld_adv_5clk,    --: out std_logic_vector(NUM_RX_ANT-1 downto 0);
                o_CALB_i                            =>  w_calb_i,               --: out std_logic_vector(15-1 downto 0);
                o_CALB_q                            =>  w_calb_q                --: out std_logic_vector(15-1 downto 0)
            );
    end generate CALB_TRUE;
    
    CALB_FALSE : if (CALB_MODULE = FALSE) generate
        w_calb_sync                                 <=  w_gaincomp_sync;		
        w_calb_i                                    <=  w_gaincomp_i;
        w_calb_q                                    <=  w_gaincomp_q;
        o_calW_rd_data                              <=  (others=>'0');
        w_calb_vld_adv_5clk                         <=  w_gaincomp_vld_adv_5clk;
    end generate CALB_FALSE;
    
    CTS : ulfe_cts_oru generic map(NUM_RX_ANT)
        port map(
            i_rst                                   =>  r_rst,                  --: in std_logic;
            i_clk                                   =>  i_clk,                  --: in std_logic;
            
            i_CTS_sync                              =>  w_calb_sync,            --: in std_logic;
            i_CTS_vld_adv_5clk                      =>  w_calb_vld_adv_5clk,    --: in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_CTS_i                                 =>  w_calb_i,               --: in std_logic_vector(15-1 downto 0);
            i_CTS_q                                 =>  w_calb_q,               --: in std_logic_vector(15-1 downto 0);
            
            i_calBypassFlag                         =>  i_calBypassFlag_E,      --: in std_logic;
            i_ctsOn                                 =>  i_cts_on,               --: in std_logic;
            i_ctsShift                              =>  i_cts_shft,             --: in std_logic_vector(12-1 downto 0);
            
            o_CTS_sync_adv_5clk                     =>  w_cts_sync_adv_5clk,    --: out std_logic;
            o_CTS_vld                               =>  w_cts_vld,              --: out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_CTS_i                                 =>  w_cts_i,                --: out std_logic_vector(15-1 downto 0);
            o_CTS_q                                 =>  w_cts_q                 --: out std_logic_vector(15-1 downto 0)
        );
    
    o_PHASECOMP_sync_adv_5clk                       <=  w_cts_sync_adv_5clk;
    o_PHASECOMP_vld                                 <=  w_cts_vld;
    
    PHASECOMP : ulfe_phasecomp_oru generic map(NUM_RX_ANT)
        Port map(
            i_rst                                   =>  r_rst,                  --: in std_logic;
            i_clk                                   =>  i_clk,                  --: in std_logic;
            
            i_PHASECOMP_frameidx                    =>  i_frameidx,             --: in std_logic_vector(8-1 downto 0);
            i_PHASECOMP_sync_adv_5clk               =>  w_cts_sync_adv_5clk,    --: in std_logic;
            i_PHASECOMP_vld                         =>  w_cts_vld,              --: in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_PHASECOMP_i                           =>  w_cts_i,                --: in std_logic_vector(15-1 downto 0);
            i_PHASECOMP_q                           =>  w_cts_q,                --: in std_logic_vector(15-1 downto 0);
            
            i_calBypassFlag                         =>  i_calBypassFlag_E,      --: in std_logic;
            i_phaseCompOn                           =>  i_phaseCompOn,          --: in std_logic;
            i_phaseCompBypass                       =>  i_phaseCompBypass,      --: in std_logic;
            
            i_phasecomp_weight_i                    =>  i_phasecomp_weight_i,   --: in std_logic_vector(16-1 downto 0);
            i_phasecomp_weight_q                    =>  i_phasecomp_weight_q,   --: in std_logic_vector(16-1 downto 0);
            
            o_PHASECOMP_frameidx                    =>  o_frameidx,             --: out std_logic_vector(8-1 downto 0);
            o_PHASECOMP_subframeidx                 =>  o_subframeidx,          --: out std_logic_vector(4-1 downto 0);
            o_PHASECOMP_slotidx                     =>  o_slot_idx,             --: out std_logic_vector(6-1 downto 0);
            o_PHASECOMP_symbol_sync                 =>  o_symbol_sync,          --: out std_logic;
            o_PHASECOMP_symidx                      =>  o_symbol_idx,           --: out std_logic_vector(4-1 downto 0);
            o_PHASECOMP_sync                        =>  o_10ms_sync,            --: out std_logic;
            o_PHASECOMP_vld                         =>  o_data_vld,             --: out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_PHASECOMP_start_re                    =>  o_start_re,             --: out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_PHASECOMP_last_re                     =>  o_last_re,              --: out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_PHASECOMP_i                           =>  w_phasecomp_i,          --: out std_logic_vector(16-1 downto 0);
            o_PHASECOMP_q                           =>  w_phasecomp_q           --: out std_logic_vector(16-1 downto 0)
        );
    
    DATA_OUT_GEN : for i in 0 to NUM_RX_ANT-1 generate
        o_data_iq((i+1)*32-1 downto i*32)           <=  w_phasecomp_i & w_phasecomp_q;
    end generate;

end Behavioral;