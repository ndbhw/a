-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.08.03 v1.0] Initial release
-- [2022.11.16 v1.1] modify about tdgain1, tdgain2
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_func.all;
use work.ulfe_component_pack_oru.all;
use work.ulfe_config_oru.all;

entity ulfe_tdagc_cal_gain_oru is
    generic (		
        NUM_RX_ANT                              : integer := 4
    );
    Port(
        i_clk                                   : in std_logic;
        
        i_fs_num                                : in std_logic_vector(5-1 downto 0);
        i_SR_info                               : in std_logic_vector(3-1 downto 0);        -- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76
        
        i_TDAGC_sync                            : in std_logic;
        i_TDAGC_vld                             : in std_logic_vector(NUM_RX_ANT-1 downto 0);
        i_TDAGC_i                               : in std_logic_vector(15-1 downto 0);
        i_TDAGC_q                               : in std_logic_vector(15-1 downto 0);
        
        i_fftType                               : in std_logic_vector(2-1 downto 0);
        i_fftSize                               : in std_logic_vector(12-1 downto 0);
        
        i_mux_sel                               : in std_logic;
        i_tagcBackoff                           : in std_logic_vector(5-1 downto 0);
        
        o_tdGain_vld                            : out std_logic;
        o_tdGain1                               : out std_logic_array4(NUM_RX_ANT-1 downto 0);
        o_tdGain2                               : out std_logic_array5(NUM_RX_ANT-1 downto 0);
        o_tdrssi                                : out std_logic_array32(NUM_RX_ANT-1 downto 0)
    );
end ulfe_tdagc_cal_gain_oru;

architecture Behavioral of ulfe_tdagc_cal_gain_oru is

    constant PWR_DSP_LATENCY                    : integer := 5;
    
    signal	sum_count                           : std_logic_vector(12-1 downto 0);
    signal  sum_count_flag                      : std_logic;
    signal  sum_count_flag_5d                   : std_logic;
    signal  sum_count_flag_6d                   : std_logic;
    
    signal  i_square                            : std_logic_vector(48-1 downto 0);
    signal  dsp_c                               : std_logic_vector(42-1 downto 0);
    signal  dsp_c_d                             : std_logic_vector(42-1 downto 0);
    
    signal  pwr_sum                             : std_logic_vector(42-1 downto 0);
    signal  pwr_sum_1d                          : std_logic_vector(42-1 downto 0);
    signal  pwr_sum_5d                          : std_logic_vector(42-1 downto 0);
    signal  pwr_sum_13d                         : std_logic_vector(42-1 downto 0);
    signal  pwr_sum_29d                         : std_logic_vector(42-1 downto 0);
    
    signal  i_TDAGC_sync_reg                    : std_logic_vector(PWR_DSP_LATENCY downto 0);
    signal  i_TDAGC_vld_E_reg                   : std_logic_vector(PWR_DSP_LATENCY downto 0);
    signal  i_TDAGC_vld_F_reg                   : std_logic_vector(PWR_DSP_LATENCY+NUM_RX_ANT downto 0);
    
    signal  i_TDAGC_i_1d                        : std_logic_vector(15-1 downto 0);
    signal  i_TDAGC_q_1d                        : std_logic_vector(15-1 downto 0);
    signal  i_TDAGC_q_2d                        : std_logic_vector(15-1 downto 0);
    
    signal  reg_select                          : std_logic;
    signal  reg_count_sig                       : std_logic;
    signal  reg_count_sig_cnt                   : std_logic_vector(5-1 downto 0);
    
    signal  ant_idx                             : std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
    signal  ant_idx_6d                          : std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
    
    signal  td_rssi                             : std_logic_vector(32-1 downto 0);
    signal  td_rssi_1d                          : std_logic_vector(32-1 downto 0);
    signal  td_rssi_array                       : std_logic_array32(NUM_RX_ANT-1 downto 0);
    
    signal  half_up_tdrssi                      : std_logic_vector(16-1 downto 0);
    signal  half_down_tdrssi                    : std_logic_vector(16-1 downto 0);
    signal  HalfUp_cnt_value                    : std_logic_vector(4-1 downto 0);
    signal  HalfDown_cnt_value                  : std_logic_vector(4-1 downto 0);
    
    signal  td_rssi_pad_st0                     : std_logic_vector(19-1 downto 0);
    signal  td_rssi_pad_st1                     : std_logic_vector(11-1 downto 0);
    signal  td_rssi_pad_st2                     : std_logic_vector(7-1 downto 0);
    signal  td_rssi_pad_st3                     : std_logic_vector(5-1 downto 0);
    
    signal  zero_cnt_st0                        : std_logic_vector(6-1 downto 0);
    signal  zero_cnt_st1                        : std_logic_vector(3-1 downto 0);
    signal  zero_cnt_st2                        : std_logic_vector(2-1 downto 0);
    signal  zero_cnt_st3                        : std_logic;
    
    signal  tdagc_gain_pre                      : std_logic_vector(6-1 downto 0);
    signal  tdagc_gain                          : std_logic_vector(5-1 downto 0);
    signal  tdagc_gain_1d                       : std_logic_vector(5-1 downto 0);
    signal  tdagc_gain_2d                       : std_logic_vector(5-1 downto 0);
    signal  nth_bits                            : std_logic_vector(4-1 downto 0);
    
    signal  tdGain_vld                          : std_logic;
    signal  tdGain1_array                       : std_logic_array4(NUM_RX_ANT-1 downto 0);
    signal  tdGain2_array                       : std_logic_array5(NUM_RX_ANT-1 downto 0);

begin

    i_TDAGC_sync_reg(0)                         <=  i_TDAGC_sync;
    i_TDAGC_vld_E_reg(0)                        <=  i_TDAGC_vld(NUM_RX_ANT-1);
    i_TDAGC_vld_F_reg(0)                        <=  i_TDAGC_vld(0);

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            i_TDAGC_sync_reg(PWR_DSP_LATENCY downto 1)                 <=  i_TDAGC_sync_reg(PWR_DSP_LATENCY-1 downto 0);
            i_TDAGC_vld_E_reg(PWR_DSP_LATENCY downto 1)                <=  i_TDAGC_vld_E_reg(PWR_DSP_LATENCY-1 downto 0);
            i_TDAGC_vld_F_reg(PWR_DSP_LATENCY+NUM_RX_ANT downto 1)     <=  i_TDAGC_vld_F_reg(PWR_DSP_LATENCY+NUM_RX_ANT-1 downto 0);
            
            if (i_TDAGC_vld = 0) then
                i_TDAGC_i_1d                    <=  (others=>'0');
                i_TDAGC_q_1d                    <=  (others=>'0');
            else
                i_TDAGC_i_1d                    <=  i_TDAGC_i;
                i_TDAGC_q_1d                    <=  i_TDAGC_q;
            end if;
            i_TDAGC_q_2d                        <=  i_TDAGC_q_1d;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_TDAGC_sync_reg(PWR_DSP_LATENCY) = '1' or (sum_count = i_fftSize and i_TDAGC_vld_E_reg(PWR_DSP_LATENCY) = '1')) then
                sum_count                       <=  (others=>'0');
            elsif (i_TDAGC_vld_E_reg(PWR_DSP_LATENCY) = '1') then
                sum_count                       <=  sum_count + '1';
            else
                sum_count                       <=  sum_count;
            end if;
            
            if (sum_count = i_fftSize and i_TDAGC_vld_F_reg(NUM_RX_ANT+PWR_DSP_LATENCY-1 downto PWR_DSP_LATENCY) /= 0) then
                sum_count_flag                  <=  '1';
            else
                sum_count_flag                  <=  '0';
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_TDAGC_sync_reg(PWR_DSP_LATENCY-2) = '1') then
                reg_count_sig                   <=  '0';
            elsif (sum_count = i_fftSize and i_TDAGC_vld_E_reg(PWR_DSP_LATENCY) = '1') then
                reg_count_sig                   <=  '0';
            elsif (reg_count_sig = '0' and reg_count_sig_cnt = i_fs_num) then
                reg_count_sig                   <=  '1';
            else
                reg_count_sig                   <=  reg_count_sig;
            end if;
            
            if (reg_count_sig = '0') then
                reg_count_sig_cnt               <=  reg_count_sig_cnt + '1';
            else
                reg_count_sig_cnt               <=  (others=>'0');
            end if;
        end if;
    end process;
    
    ------------------------------------------------------------------------------------------------------------------------------------------------------------------
    -- SUM POWER
    
    reg_select                <=  '0' when (i_SR_info = b"101") else '1';
    -- i^2 + q^2 4clk	
    stg0 : ulfe_lib_dsp_multi_add_v2 generic map('0',15,15,42,42) port map(i_clk, '0', '0', i_TDAGC_i_1d, i_TDAGC_i_1d, (others=>'0'), (others=>'0'), open, i_square);
    stg1 : ulfe_lib_dsp_multi_add_v2 generic map('1',15,15,42,42) port map(i_clk, reg_select, reg_count_sig, i_TDAGC_q_2d, i_TDAGC_q_2d, dsp_c_d, i_square, pwr_sum, open);
    
    dsp_c_d                   <=  pwr_sum when (i_SR_info = b"100") else dsp_c;
    -- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            case (i_SR_info) is
                when b"000"  =>  dsp_c        <=  pwr_sum_29d;
                when b"001"  =>  dsp_c        <=  pwr_sum_13d;
                when b"010"  =>  dsp_c        <=  pwr_sum_5d;
                when b"011"  =>  dsp_c        <=  pwr_sum_1d;
                when b"100"  =>  dsp_c        <=  pwr_sum;
                when others  =>  dsp_c        <=  pwr_sum;
            end case;
        end if;
    end process;
    
    pwr_sum_dly_1 : ulfe_lib_dly_fixed generic map(1, 42) port map(i_clk, pwr_sum, pwr_sum_1d);
    
    MIN_SAMPLE_RATE_2 : if (MIN_SAMPLE_RATE = 2) generate
        pwr_sum_dly_2 : ulfe_lib_dly_fixed generic map(4, 42) port map(i_clk, pwr_sum_1d, pwr_sum_5d);
    end generate MIN_SAMPLE_RATE_2;
    
    MIN_SAMPLE_RATE_not_2 : if (MIN_SAMPLE_RATE > 2) generate
        pwr_sum_5d                             <=  (others=>'0');
    end generate MIN_SAMPLE_RATE_not_2;
    
    MIN_SAMPLE_RATE_1 : if (MIN_SAMPLE_RATE = 1) generate
        pwr_sum_dly_2 : ulfe_lib_dly_fixed generic map(4, 42) port map(i_clk, pwr_sum_1d, pwr_sum_5d);
        pwr_sum_dly_3 : ulfe_lib_dly_fixed generic map(8, 42) port map(i_clk, pwr_sum_5d, pwr_sum_13d);
    end generate MIN_SAMPLE_RATE_1;
    
    MIN_SAMPLE_RATE_not_1 : if (MIN_SAMPLE_RATE > 1) generate
        pwr_sum_13d                            <=  (others=>'0');
    end generate MIN_SAMPLE_RATE_not_1;
    
    MIN_SAMPLE_RATE_0 : if (MIN_SAMPLE_RATE = 0) generate
        pwr_sum_dly_2 : ulfe_lib_dly_fixed generic map(4, 42) port map(i_clk, pwr_sum_1d, pwr_sum_5d);
        pwr_sum_dly_3 : ulfe_lib_dly_fixed generic map(8, 42) port map(i_clk, pwr_sum_5d, pwr_sum_13d);
        pwr_sum_dly_4 : ulfe_lib_dly_fixed generic map(16, 42) port map(i_clk, pwr_sum_13d, pwr_sum_29d);
    end generate MIN_SAMPLE_RATE_0;
    
    MIN_SAMPLE_RATE_not_0 : if (MIN_SAMPLE_RATE > 0) generate
        pwr_sum_29d                             <=  (others=>'0');
    end generate MIN_SAMPLE_RATE_not_0;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            case (i_fftType) is
                when b"00"  =>  td_rssi        <=  pwr_sum(40 downto 9);
                when b"01"  =>  td_rssi        <=  b"0" & pwr_sum(40 downto 10);
                when b"10"  =>  td_rssi        <=  b"00" & pwr_sum(40 downto 11);
                when others =>  td_rssi        <=  b"000" & pwr_sum(40 downto 12);
            end case;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (sum_count_flag = '1') then
                ant_idx                        <=  ant_idx + '1';
            else
                ant_idx                        <=  (others=>'0');
            end if;
            
            if (sum_count_flag = '1') then
                td_rssi_array(conv_integer(ant_idx))        <=  td_rssi;
            else
                td_rssi_array                               <=  td_rssi_array;
            end if;
        end if;
    end process;
    
    ------------------------------------------------------------------------------------------------------
    -- CAL GAIN
    -- 1 clk
    half_up_tdrssi                  <=  td_rssi(28 downto 14) & b"1";
    half_down_tdrssi                <=  td_rssi(13 downto 1) & b"111";	
    HALF_UP_ZERO_COUNT   : ulfe_lib_lzc_16 port map(i_clk, half_up_tdrssi, HalfUp_cnt_value);       -- max count value : 15
    HALF_DOWN_ZERO_COUNT : ulfe_lib_lzc_16 port map(i_clk, half_down_tdrssi, HalfDown_cnt_value);   -- max_count_value : 13
    
    -- stage0
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            td_rssi_1d                          <=  td_rssi;
            if (HalfUp_cnt_value = X"F" and HalfDown_cnt_value /= 0) then
                td_rssi_pad_st0                 <=  td_rssi_1d(11 downto 0) & X"0" & b"000";
                zero_cnt_st0                    <=  (b"00" & HalfUp_cnt_value) + (b"00" & HalfDown_cnt_value);
            else
                td_rssi_pad_st0                 <=  td_rssi_1d(27 downto 9);
                zero_cnt_st0                    <=  (b"00" & HalfUp_cnt_value);
            end if;
        end if;
    end process;
    
    -- stage1, stage2, stage3
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            zero_cnt_st1                        <=  zero_cnt_st0(2 downto 0);
            zero_cnt_st2                        <=  zero_cnt_st1(1 downto 0);
            zero_cnt_st3                        <=  zero_cnt_st2(0);
            
            if (zero_cnt_st0(3) = '1') then
                td_rssi_pad_st1                 <=  td_rssi_pad_st0(10 downto 0);
            else
                td_rssi_pad_st1                 <=  td_rssi_pad_st0(18 downto 8);
            end if;
            
            if (zero_cnt_st1(2) = '1') then
                td_rssi_pad_st2                 <=  td_rssi_pad_st1(6 downto 0);
            else
                td_rssi_pad_st2                 <=  td_rssi_pad_st1(10 downto 4);
            end if;
            
            if (zero_cnt_st2(1) = '1') then
                td_rssi_pad_st3                 <=  td_rssi_pad_st2(4 downto 0);
            else
                td_rssi_pad_st3                 <=  td_rssi_pad_st2(6 downto 2);
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            tdagc_gain_pre                      <=  zero_cnt_st0 - ('0' & i_tagcBackoff);
            
            if (zero_cnt_st3 = '1') then
                nth_bits                        <=  td_rssi_pad_st3(3 downto 0);
            else
                nth_bits                        <=  td_rssi_pad_st3(4 downto 1);
            end if;
        end if;
    end process;
    
    -- 1clk
    symm_sat : ulfe_lib_symm_sat generic map(6,5) port map(i_clk, tdagc_gain_pre, tdagc_gain);
    
    flag_dly : ulfe_lib_dly_fixed generic map(5,1) port map(i_clk=>i_clk, data_i(0)=>sum_count_flag, data_o(0)=>sum_count_flag_5d);
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            sum_count_flag_6d                   <=  sum_count_flag_5d;
            if (sum_count_flag_6d = '1') then
                ant_idx_6d                      <=  ant_idx_6d + '1';
            else
                ant_idx_6d                      <=  (others=>'0');
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            tdagc_gain_1d                       <=  tdagc_gain;
            tdagc_gain_2d                       <=  tdagc_gain_1d;
            
            if (i_mux_sel = '1' and sum_count_flag_6d = '1') then
                tdGain1_array(conv_integer(ant_idx_6d))     <=  tdagc_gain_2d(4 downto 1);
                tdGain2_array(conv_integer(ant_idx_6d))     <=  tdagc_gain_2d(0) & nth_bits;
            elsif (sum_count_flag_6d = '1') then
                tdGain1_array(conv_integer(ant_idx_6d))     <=  (others=>'0');
                tdGain2_array(conv_integer(ant_idx_6d))     <=  (others=>'0');
            else
                tdGain1_array                   <=  tdGain1_array;
                tdGain2_array                   <=  tdGain2_array;
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            tdGain_vld                          <=  (not sum_count_flag_5d) and sum_count_flag_6d;
        end if;
    end process;
    
    o_tdGain_vld                                <=  tdGain_vld;
    o_tdGain1                                   <=  tdGain1_array;
    o_tdGain2                                   <=  tdGain2_array;
    o_tdrssi                                    <=  td_rssi_array;

end Behavioral;