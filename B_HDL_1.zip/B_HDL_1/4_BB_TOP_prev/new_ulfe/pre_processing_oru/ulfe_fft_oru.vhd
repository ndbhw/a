-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.08.03 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_func.all;
use work.ulfe_component_pack_oru.all;
use work.ulfe_config_oru.all;

entity ulfe_fft_oru is
    generic (
        NUM_RX_ANT                          : integer := 4
    );
    Port(
        i_rst                               : in std_logic;
        i_clk                               : in std_logic;
        
        i_FFT_sync                          : in std_logic;
        i_FFT_vld_sync                      : in std_logic;
        i_FFT_vld                           : in std_logic;
        i_FFT_i                             : in std_logic_vector(15-1 downto 0);
        i_FFT_q                             : in std_logic_vector(15-1 downto 0);
        
        i_tdGain1                           : in std_logic_array4(NUM_RX_ANT-1 downto 0);
        i_tdGain2                           : in std_logic_array5(NUM_RX_ANT-1 downto 0);
        
        i_fftType                           : in std_logic_vector(2-1 downto 0);
        i_k0                                : in std_logic_vector(12-1 downto 0);
        i_rbSize                            : in std_logic_vector(9-1 downto 0);
        
        o_st_ext_i_data                     : out std_logic;
        o_data_vld_err                      : out std_logic;
        o_sync_unexpected                   : out std_logic;
        
        o_tdGain1                           : out std_logic_array4(NUM_RX_ANT-1 downto 0);
        o_tdGain2                           : out std_logic_array5(NUM_RX_ANT-1 downto 0);
        
        o_FFT_sync_adv_1clk                 : out std_logic;
        o_FFT_vld                           : out std_logic_vector(NUM_RX_ANT-1 downto 0);
        o_FFT_vld_adv_2clk                  : out std_logic;
        o_FFT_i                             : out std_logic_vector(15-1 downto 0);
        o_FFT_q                             : out std_logic_vector(15-1 downto 0)
    );
end ulfe_fft_oru;

architecture Behavioral of ulfe_fft_oru is

    constant FFT_LATENCY_512                : integer := 62;
    constant FFT_LATENCY_1024               : integer := 59;
    constant FFT_LATENCY_2048               : integer := 76;
    constant FFT_LATENCY_4096               : integer := 73;
    
    signal  r_tone_len                      : std_logic_vector(12-1 downto 0);
    signal  r_tone_len_offset               : std_logic_vector(12-1 downto 0);
    signal	r_fftType                       : std_logic_vector(2-1 downto 0);
    signal	r_k0                            : std_logic_vector(13-1 downto 0);
    signal  rd_addr_start_pre               : std_logic_vector(12-1 downto 0);
    signal  rd_addr_end_pre                 : std_logic_vector(12-1 downto 0);
    signal  f_sync_dly_num                  : std_logic_vector(13-1 downto 0);
    
    signal  data_vld                        : std_logic;
    signal  data_vld_1d                     : std_logic;
    signal  data_idx                        : std_logic_vector(log2ceil(4096)-1 downto 0);
    signal  data_i                          : std_logic_vector(15-1 downto 0);
    signal  data_q                          : std_logic_vector(15-1 downto 0);
    signal  data_last                       : std_logic;
    
    signal  ant_num                         : std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
    signal  vld_out_adv_2clk                : std_logic;
    signal  vld_out_adv_1clk                : std_logic;
    
    signal  i_FFT_vld_d                     : std_logic;
    signal  i_tdGain1_d                     : std_logic_array4(NUM_RX_ANT-1 downto 0);
    signal  i_tdGain2_d                     : std_logic_array5(NUM_RX_ANT-1 downto 0);
    
    signal  o_FFT_vld_d                     : std_logic;
    signal  o_tdGain1_d                     : std_logic_array4(NUM_RX_ANT-1 downto 0);
    signal  o_tdGain2_d                     : std_logic_array5(NUM_RX_ANT-1 downto 0);

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            i_FFT_vld_d                     <=  i_FFT_vld;
            if (i_FFT_vld_d = '0' and i_FFT_vld = '1') then
                i_tdGain1_d                 <=  i_tdGain1;
                i_tdGain2_d                 <=  i_tdGain2;
            else
                i_tdGain1_d                 <=  i_tdGain1_d;
                i_tdGain2_d                 <=  i_tdGain2_d;
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            r_fftType                       <=  i_fftType;
            r_k0                            <=  i_k0(11) & i_k0;
            
            r_tone_len                      <=  (i_rbSize & b"000") + (b"0" & i_rbSize & b"00");
            r_tone_len_offset               <=  b"0" & r_tone_len(11 downto 1);
            rd_addr_end_pre                 <=  r_k0(11 downto 0) + r_tone_len_offset;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            case (r_fftType) is
                when b"00"  =>
                    rd_addr_start_pre       <=  conv_std_logic_vector(512, 12) + r_k0(11 downto 0) - r_tone_len_offset;
                    f_sync_dly_num          <=  conv_std_logic_vector(768+FFT_LATENCY_512-1, 13) + r_k0 - r_tone_len_offset;
                when b"01"  =>
                    rd_addr_start_pre       <=  conv_std_logic_vector(1024, 12) + r_k0(11 downto 0) - r_tone_len_offset;
                    f_sync_dly_num          <=  conv_std_logic_vector(1536+FFT_LATENCY_1024-1, 13) + r_k0 - r_tone_len_offset;
                when b"10"  =>
                    rd_addr_start_pre       <=  conv_std_logic_vector(2048, 12) + r_k0(11 downto 0) - r_tone_len_offset;
                    f_sync_dly_num          <=  conv_std_logic_vector(3072+FFT_LATENCY_2048-1, 13) + r_k0 - r_tone_len_offset;
                when others =>
                    rd_addr_start_pre       <=  conv_std_logic_vector(4096, 12) + r_k0(11 downto 0) - r_tone_len_offset;
                    f_sync_dly_num          <=  conv_std_logic_vector(6144+FFT_LATENCY_4096-1, 13) + r_k0 - r_tone_len_offset;
            end case;
        end if;
    end process;
    
    FFT : nfft_wrapper_v2 generic map("ULTRASCALE","4096_2048_1024_512","FFT",FFT_MODE,"THREE",FALSE,FFT_HALF_MODE,15,15)
        port map(
            I_RSTB                          =>  i_rst,
            I_CLK                           =>  i_clk,
            
            I_DATA_SYNC                     =>  i_FFT_vld_sync,
            I_DATA_VLD                      =>  i_FFT_vld,
            I_DATA_I                        =>  i_FFT_i,
            I_DATA_Q                        =>  i_FFT_q,
            
            I_nFFT_TYPE                     =>  r_fftType,
            
            O_DATA_SYNC                     =>  open,
            O_DATA_VLD                      =>  data_vld,
            O_DATA_IDX                      =>  data_idx,
            O_DATA_I                        =>  data_i,
            O_DATA_Q                        =>  data_q,
            O_DATA_LAST                     =>  data_last,
            
            O_STATUS_EXTENDED_INPUT_DATA                =>  o_st_ext_i_data,
            O_EVENT_I_DATA_VLD_SHORT_OR_DISCOUNTINUED   =>  o_data_vld_err,
            O_EVENT_I_SYNC_UNEXPECTED                   =>  o_sync_unexpected
        );
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (data_vld = '0') then
                ant_num                     <=  (others=>'0');
            elsif (data_last = '1') then
                ant_num                     <=  ant_num + '1';
            else
                ant_num                     <=  ant_num;
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (data_idx >= rd_addr_start_pre-2 or data_idx <= rd_addr_end_pre-3) then
                vld_out_adv_2clk            <=  data_vld;
            else
                vld_out_adv_2clk            <=  '0';
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            data_vld_1d                     <=  data_vld;
            if (data_vld_1d = '0' and data_vld = '1') then
                o_tdGain1_d                     <=  i_tdGain1_d;
                o_tdGain2_d                     <=  i_tdGain2_d;
            else
                o_tdGain1_d                     <=  o_tdGain1_d;
                o_tdGain2_d                     <=  o_tdGain2_d;
            end if;
        end if;
    end process;
    
    VALID_OUT : for i in 0 to NUM_RX_ANT-1 generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                vld_out_adv_1clk                <=  vld_out_adv_2clk;
                
                if (conv_integer(ant_num) = i) then
                	o_FFT_vld(i)                <=  vld_out_adv_1clk;
                else
                	o_FFT_vld(i)                <=  '0';
                end if;
            end if;
        end process;
    end generate VALID_OUT;
    
    F_SYNC_OUT : ulfe_lib_dly_variable generic map (13) port map(i_rst, i_clk, f_sync_dly_num, i_FFT_sync, o_FFT_sync_adv_1clk);
    
    o_FFT_vld_adv_2clk                          <=  vld_out_adv_2clk;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            o_FFT_i                             <=  data_i;
            o_FFT_q                             <=  data_q;
        end if;
    end process;
    
    o_tdGain1                                   <=  o_tdGain1_d;
    o_tdGain2                                   <=  o_tdGain2_d;

end Behavioral;