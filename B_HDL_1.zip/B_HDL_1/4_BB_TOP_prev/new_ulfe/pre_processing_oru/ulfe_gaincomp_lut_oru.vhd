library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_arith.all;

entity ulfe_gaincomp_lut_oru is
    Port ( 
        i_clk                          : in std_logic;
        
        i_addr                         : in std_logic_vector(5-1 downto 0);
        o_data                         : out std_logic_vector(10-1 downto 0)
    );
end ulfe_gaincomp_lut_oru;

architecture Behavioral of ulfe_gaincomp_lut_oru is

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            case (i_addr) is
                when b"00000" => o_data <= conv_std_logic_vector(256,10);
                when b"00001" => o_data <= conv_std_logic_vector(264,10);
                when b"00010" => o_data <= conv_std_logic_vector(272,10);
                when b"00011" => o_data <= conv_std_logic_vector(279,10);
                when b"00100" => o_data <= conv_std_logic_vector(286,10);
                when b"00101" => o_data <= conv_std_logic_vector(293,10);
                when b"00110" => o_data <= conv_std_logic_vector(300,10);
                when b"00111" => o_data <= conv_std_logic_vector(307,10);
                when b"01000" => o_data <= conv_std_logic_vector(314,10);
                when b"01001" => o_data <= conv_std_logic_vector(320,10);
                when b"01010" => o_data <= conv_std_logic_vector(326,10);
                when b"01011" => o_data <= conv_std_logic_vector(333,10);
                when b"01100" => o_data <= conv_std_logic_vector(339,10);
                when b"01101" => o_data <= conv_std_logic_vector(345,10);
                when b"01110" => o_data <= conv_std_logic_vector(351,10);
                when b"01111" => o_data <= conv_std_logic_vector(356,10);
                when b"10000" => o_data <= conv_std_logic_vector(181,10);
                when b"10001" => o_data <= conv_std_logic_vector(187,10);
                when b"10010" => o_data <= conv_std_logic_vector(192,10);
                when b"10011" => o_data <= conv_std_logic_vector(197,10);
                when b"10100" => o_data <= conv_std_logic_vector(202,10);
                when b"10101" => o_data <= conv_std_logic_vector(207,10);
                when b"10110" => o_data <= conv_std_logic_vector(212,10);
                when b"10111" => o_data <= conv_std_logic_vector(217,10);
                when b"11000" => o_data <= conv_std_logic_vector(222,10);
                when b"11001" => o_data <= conv_std_logic_vector(226,10);
                when b"11010" => o_data <= conv_std_logic_vector(231,10);
                when b"11011" => o_data <= conv_std_logic_vector(235,10);
                when b"11100" => o_data <= conv_std_logic_vector(239,10);
                when b"11101" => o_data <= conv_std_logic_vector(244,10);
                when b"11110" => o_data <= conv_std_logic_vector(248,10);
                when others   => o_data <= conv_std_logic_vector(252,10);
            end case;
        end if;
    end process;

end Behavioral;