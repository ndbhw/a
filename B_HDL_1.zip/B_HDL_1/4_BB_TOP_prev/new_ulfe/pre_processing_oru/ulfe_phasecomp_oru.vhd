-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.08.08 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_func.all;
use work.ulfe_component_pack_oru.all;
use work.ulfe_config_oru.all;

entity ulfe_phasecomp_oru is
    generic (
        NUM_RX_ANT                          : integer := 4
    );
    Port(
        i_rst                               : in std_logic;
        i_clk                               : in std_logic;
        
        i_PHASECOMP_frameidx                : in std_logic_vector(8-1 downto 0);
        i_PHASECOMP_sync_adv_5clk           : in std_logic;
        i_PHASECOMP_vld                     : in std_logic_vector(NUM_RX_ANT-1 downto 0);
        i_PHASECOMP_i                       : in std_logic_vector(15-1 downto 0);
        i_PHASECOMP_q                       : in std_logic_vector(15-1 downto 0);
        
        i_calBypassFlag                     : in std_logic;
        i_phaseCompOn                       : in std_logic;
        i_phaseCompBypass                   : in std_logic;
        
        i_phasecomp_weight_i                : in std_logic_vector(16-1 downto 0);
        i_phasecomp_weight_q                : in std_logic_vector(16-1 downto 0);
        
        o_PHASECOMP_frameidx                : out std_logic_vector(8-1 downto 0);
        o_PHASECOMP_subframeidx             : out std_logic_vector(4-1 downto 0);
        o_PHASECOMP_slotidx                 : out std_logic_vector(6-1 downto 0);
        o_PHASECOMP_symbol_sync             : out std_logic;
        o_PHASECOMP_symidx                  : out std_logic_vector(4-1 downto 0);
        o_PHASECOMP_sync                    : out std_logic;
        o_PHASECOMP_vld                     : out std_logic_vector(NUM_RX_ANT-1 downto 0);
        o_PHASECOMP_start_re                : out std_logic_vector(NUM_RX_ANT-1 downto 0);
        o_PHASECOMP_last_re                 : out std_logic_vector(NUM_RX_ANT-1 downto 0);
        o_PHASECOMP_i                       : out std_logic_vector(16-1 downto 0);
        o_PHASECOMP_q                       : out std_logic_vector(16-1 downto 0)
    );
end ulfe_phasecomp_oru;

architecture Behavioral of ulfe_phasecomp_oru is

    constant MAX_SYMIDX                     : std_logic_vector(4-1 downto 0) := ternary_func(CPTYPE="normal",X"D",X"B");
    
    signal  r_PHASECOMP_frameidx            : std_logic_vector(8-1 downto 0);
    signal  r_PHASECOMP_frameidx_out        : std_logic_vector(8-1 downto 0);
    
    signal  r_calBypassFlag                 : std_logic;
    signal  r_phaseCompOn                   : std_logic;
    signal  r_phaseCompBypass               : std_logic;
    
    signal  i_PHASECOMP_sync_9d             : std_logic;
    signal  i_PHASECOMP_vld_7d              : std_logic_vector(NUM_RX_ANT-1 downto 0);
    signal  i_PHASECOMP_vld_8d              : std_logic_vector(NUM_RX_ANT-1 downto 0);
    signal  i_PHASECOMP_vld_9d              : std_logic_vector(NUM_RX_ANT-1 downto 0);
    
    signal  symbol_sync                     : std_logic;
    signal  slotIdx_out                     : std_logic_vector(6-1 downto 0);
    signal  symIdx_out                      : std_logic_vector(4-1 downto 0);

    signal  real_data                       : std_logic_vector(16-1 downto 0);
    signal  img_data                        : std_logic_vector(16-1 downto 0);
    
    signal  c_multi_data_i                  : std_logic_vector(31-1 downto 0);
    signal  c_multi_data_q                  : std_logic_vector(31-1 downto 0);
    
    signal  sym_r_sh_sym_sat_i              : std_logic_vector(14 downto 0);
    signal  sym_r_sh_sym_sat_q              : std_logic_vector(14 downto 0);

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            r_calBypassFlag                 <=  i_calBypassFlag;
            r_phaseCompOn                   <=  i_phaseCompOn;
            r_phaseCompBypass               <=  i_phaseCompBypass;
            
            r_PHASECOMP_frameidx            <=  i_PHASECOMP_frameidx;
        end if;
    end process;

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (r_phaseCompOn = '1' and r_calBypassFlag = '0' and r_phaseCompBypass = '0') then
                real_data                   <=  i_phasecomp_weight_i;
                img_data                    <=  i_phasecomp_weight_q;
            else
                real_data                   <=  X"4000";
                img_data                    <=  X"0000";
            end if;
        end if;
    end process;

    -- 6 clk
    C_multi : ulfe_lib_C_multi_v2 generic map(15,16,31) port map(i_clk, i_PHASECOMP_i, i_PHASECOMP_q, real_data, img_data, c_multi_data_i, c_multi_data_q);
    
    -- 3 clk
    r_sh_sym_sat_i : ylib_sshftd_sat generic map(31,14,15,"SYMMETRIC_ROUND","SYMMETRIC") port map(i_clk, '1', c_multi_data_i, open, sym_r_sh_sym_sat_i);
    r_sh_sym_sat_q : ylib_sshftd_sat generic map(31,14,15,"SYMMETRIC_ROUND","SYMMETRIC") port map(i_clk, '1', c_multi_data_q, open, sym_r_sh_sym_sat_q);
    
    -- gen Index
    f_sync_dly : ulfe_lib_dly_fixed generic map(9+5, 1) port map(i_clk => i_clk, data_i(0) => i_PHASECOMP_sync_adv_5clk, data_o(0) => i_PHASECOMP_sync_9d);
    
    vld_dly_0 : ulfe_lib_dly_fixed generic map(9-2, NUM_RX_ANT) port map(i_clk, i_PHASECOMP_vld, i_PHASECOMP_vld_7d);
    vld_dly_1 : ulfe_lib_dly_fixed generic map(1, NUM_RX_ANT) port map(i_clk, i_PHASECOMP_vld_7d, i_PHASECOMP_vld_8d);
    vld_dly_2 : ulfe_lib_dly_fixed generic map(1, NUM_RX_ANT) port map(i_clk, i_PHASECOMP_vld_8d, i_PHASECOMP_vld_9d);
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_PHASECOMP_sync_9d = '1') then
                symIdx_out                  <=  (others=>'0');
                slotIdx_out                 <=  (others=>'0');
                symbol_sync                 <=  '1';
            elsif (i_PHASECOMP_vld_9d(0) = '0' and i_PHASECOMP_vld_8d(0) = '1' and symIdx_out = MAX_SYMIDX) then
                symIdx_out                  <=  (others=>'0');
                slotIdx_out                 <=  slotIdx_out + '1';
                symbol_sync                 <=  '1';
            elsif (i_PHASECOMP_vld_9d(0) = '0' and i_PHASECOMP_vld_8d(0) = '1') then
                symIdx_out                  <=  symIdx_out + '1';
                slotIdx_out                 <=  slotIdx_out;
                symbol_sync                 <=  '1';
            else
                symIdx_out                  <=  symIdx_out;
                slotIdx_out                 <=  slotIdx_out;
                symbol_sync                 <=  '0';
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_PHASECOMP_sync_9d = '1') then
                r_PHASECOMP_frameidx_out    <=  r_PHASECOMP_frameidx;
            else
                r_PHASECOMP_frameidx_out    <=  r_PHASECOMP_frameidx_out;
            end if;
        end if;
    end process;
    ----------------------------------------------------------------------------------------------------------------------------------------------------
    -- DATA OUT
    
    o_PHASECOMP_frameidx                    <=  r_PHASECOMP_frameidx_out;
    
    SCSTYPE_0 : if (SCSTYPE = 0) generate
        o_PHASECOMP_subframeidx             <=  slotIdx_out(3 downto 0);
    end generate SCSTYPE_0;
    
    SCSTYPE_1 : if (SCSTYPE = 1) generate
        o_PHASECOMP_subframeidx             <=  slotIdx_out(4 downto 1);
    end generate SCSTYPE_1;
    
    SCSTYPE_2 : if (SCSTYPE = 2) generate
        o_PHASECOMP_subframeidx             <=  slotIdx_out(5 downto 2);
    end generate SCSTYPE_2;
    
    o_PHASECOMP_symidx                      <=  symIdx_out;
    o_PHASECOMP_symbol_sync                 <=  symbol_sync;
    o_PHASECOMP_slotidx                     <=  slotIdx_out;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            o_PHASECOMP_sync                <=  i_PHASECOMP_sync_9d;
        end if;
    end process;
    o_PHASECOMP_vld                         <=  i_PHASECOMP_vld_9d;
    
    START_END_RE_GEN : for i in 0 to NUM_RX_ANT-1 generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                if (i_PHASECOMP_vld_9d(i) = '0' and i_PHASECOMP_vld_8d(i) = '1') then
                    o_PHASECOMP_start_re(i) <=  '1';
                else
                    o_PHASECOMP_start_re(i) <=  '0';
                end if;
                
                if (i_PHASECOMP_vld_8d(i) = '1' and i_PHASECOMP_vld_7d(i) = '0') then
                    o_PHASECOMP_last_re(i)  <=  '1';
                else
                    o_PHASECOMP_last_re(i)  <=  '0';
                end if;
            end if;
        end process;
    end generate START_END_RE_GEN;
    
    o_PHASECOMP_i                           <=  sym_r_sh_sym_sat_i(14) & sym_r_sh_sym_sat_i;
    o_PHASECOMP_q                           <=  sym_r_sh_sym_sat_q(14) & sym_r_sh_sym_sat_q;
	
end Behavioral;	