-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.10.18 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_func.all;
use work.ulfe_component_pack_oru.all;
use work.ulfe_config_oru.all;

entity ulfe_calb_oru is
    generic (
        NUM_RX_ANT                              : integer := 4;
        NUM_CHAIN                               : integer := 0
    );
    Port(
        i_rst                                   : in std_logic;
        i_clk                                   : in std_logic;
        
        i_CALB_sync                             : in std_logic;
        i_CALB_vld_adv_5clk                     : in std_logic_vector(NUM_RX_ANT-1 downto 0);
        i_CALB_ant_num                          : in std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
        i_CALB_i                                : in std_logic_vector(15-1 downto 0);
        i_CALB_q                                : in std_logic_vector(15-1 downto 0);
        
        i_calOn                                 : in std_logic;
        i_calBypassFlag                         : in std_logic;
        i_calWScale                             : in std_logic_vector(4-1 downto 0);
        
        i_calW_rd_wt_sel                        : in std_logic;
        i_calW_wt_buf                           : in std_logic;
        i_calW_ant_num                          : in std_logic_vector(6-1 downto 0);
        i_calW_wt_en                            : in std_logic;
        i_calW_wt_addr                          : in std_logic_vector(9-1 downto 0);    -- #0~272RB
        i_calW_iq                               : in std_logic_vector(24-1 downto 0);
        o_calW_rd_data                          : out std_logic_vector(24-1 downto 0);
        
        o_CALB_sync                             : out std_logic;
        o_CALB_vld_adv_5clk                     : out std_logic_vector(NUM_RX_ANT-1 downto 0);
        o_CALB_i                                : out std_logic_vector(15-1 downto 0);
        o_CALB_q                                : out std_logic_vector(15-1 downto 0)
    );
end ulfe_calb_oru;

architecture Behavioral of ulfe_calb_oru is

    constant CALB_MEM_RD_LTENCY                 : integer := 2;
    constant CALB_MEM_D_WIDTH                   : integer := 12*2;
    constant CALB_MEM_DEPTH                     : integer := 512*NUM_RX_ANT*2;    -- Double Buffer
    
    signal  r_calOn                             : std_logic;
    signal  r_calBypassFlag                     : std_logic;
    signal  r_calWScale                         : std_logic_vector(5-1 downto 0);
    
    signal  r_CALB_vld_adv_5clk_1d              : std_logic_vector(NUM_RX_ANT-1 downto 0);
    signal  r_CALB_ant_num_1d                   : std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
    
    signal  r_calW_wt_en                        : std_logic;
    signal  r_calW_wt_addr                      : std_logic_vector(log2ceil(CALB_MEM_DEPTH)-1 downto 0);
    signal  r_calW_wt_data                      : std_logic_vector(CALB_MEM_D_WIDTH-1 downto 0);
    
    signal  r_calW_rd_flag                      : std_logic;
    signal  calW_rd_addr                        : std_logic_vector(log2ceil(CALB_MEM_DEPTH)-1 downto 0);
    signal  calW_rd_data                        : std_logic_vector(CALB_MEM_D_WIDTH-1 downto 0);
    
    signal  calb_weight_i                       : std_logic_vector(12-1 downto 0);
    signal  calb_weight_q                       : std_logic_vector(12-1 downto 0);
    
    signal  calb_c_multi_data_i                 : std_logic_vector(27-1 downto 0);
    signal  calb_c_multi_data_q                 : std_logic_vector(27-1 downto 0);
    
    signal  re_count                            : std_logic_vector(4-1 downto 0);
    signal  rb_count                            : std_logic_vector(9-1 downto 0);

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            r_calOn                             <=  i_calOn;
            r_calBypassFlag                     <=  i_calBypassFlag;
            
            if (r_calOn = '1' and r_calBypassFlag = '0') then
                r_calWScale                     <=  '0' & i_calWScale;
            else
                r_calWScale                     <=  (others=>'0');
            end if;
            
            r_CALB_vld_adv_5clk_1d              <=  i_CALB_vld_adv_5clk;
            r_CALB_ant_num_1d                   <=  i_CALB_ant_num;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_calW_ant_num(5 downto log2ceil(NUM_RX_ANT)) = conv_std_logic_vector(NUM_CHAIN,6-log2ceil(NUM_RX_ANT))) then
                r_calW_wt_en                    <=  i_calW_wt_en and i_calW_rd_wt_sel;
            else
                r_calW_wt_en                    <=  '0';
            end if;
            
            if (i_calW_rd_wt_sel = '1') then    -- write
                r_calW_wt_addr                  <=  (not i_calW_wt_buf) & i_calW_ant_num(log2ceil(NUM_RX_ANT)-1 downto 0) & i_calW_wt_addr;
            else                                -- read
                r_calW_wt_addr                  <=  i_calW_wt_buf & i_calW_ant_num(log2ceil(NUM_RX_ANT)-1 downto 0) & i_calW_wt_addr;
            end if;
            r_calW_wt_data                      <=  i_calW_iq;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (r_CALB_vld_adv_5clk_1d = 0) then
                re_count                        <=  (others=>'0');
                rb_count                        <=  (others=>'0');
            elsif (re_count = X"B") then
                re_count                        <=  (others=>'0');
                rb_count                        <=  rb_count + '1';
            else
                re_count                        <=  re_count + '1';
                rb_count                        <=  rb_count;
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (r_CALB_vld_adv_5clk_1d(0) = '0' and i_CALB_vld_adv_5clk(0) = '1') then
                r_calW_rd_flag                  <=  i_calW_wt_buf;
            else
                r_calW_rd_flag                  <=  r_calW_rd_flag;
            end if;
            
            calW_rd_addr                        <=  r_calW_rd_flag & r_CALB_ant_num_1d & rb_count;
        end if;
    end process;
    
    cal_weight : ulfe_lib_tdpram generic map("ultra",CALB_MEM_RD_LTENCY,CALB_MEM_D_WIDTH,CALB_MEM_D_WIDTH,CALB_MEM_DEPTH,CALB_MEM_DEPTH)
        port map(
            i_clk                               =>  i_clk,
            
            i_wt_enable                         =>  r_calW_wt_en,
            i_wt_addra                          =>  r_calW_wt_addr,
            i_wt_data                           =>  r_calW_wt_data,
            o_rd_douta                          =>  o_calW_rd_data,
            
            i_rd_addrb                          =>  calW_rd_addr,
            o_rd_doutb                          =>  calW_rd_data
        );
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (r_calOn = '1' and r_calBypassFlag = '0') then
                calb_weight_i                   <=  calW_rd_data(23 downto 12);
                calb_weight_q                   <=  calW_rd_data(11 downto 0);
            else
                calb_weight_i                   <=  X"001";
                calb_weight_q                   <=  X"000";
            end if;
        end if;
    end process;
    
    -- 6 clk
    calb_c_multi : ulfe_lib_C_multi_v2 generic map(15,12,27) port map(i_clk, i_CALB_i, i_CALB_q, calb_weight_i, calb_weight_q, calb_c_multi_data_i, calb_c_multi_data_q);
    
    -- 4 clk
    calb_r_sh_sym_sat_i : ylib_sshftvd_sat generic map(27,5,15,"SYMMETRIC_ROUND","SYMMETRIC") port map(i_clk, r_calWScale, '1', calb_c_multi_data_i, open, o_CALB_i);
    calb_r_sh_sym_sat_q : ylib_sshftvd_sat generic map(27,5,15,"SYMMETRIC_ROUND","SYMMETRIC") port map(i_clk, r_calWScale, '1', calb_c_multi_data_q, open, o_CALB_q);
    
    d_sync_dly   : ulfe_lib_dly_fixed generic map(10,1) port map(i_clk => i_clk, data_i(0) => i_CALB_sync, data_o(0) => o_CALB_sync);
    vld_dly      : ulfe_lib_dly_fixed generic map(10,NUM_RX_ANT) port map(i_clk, i_CALB_vld_adv_5clk, o_CALB_vld_adv_5clk);

end Behavioral;