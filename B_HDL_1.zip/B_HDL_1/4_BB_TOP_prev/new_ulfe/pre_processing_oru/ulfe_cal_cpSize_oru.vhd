-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.08.03 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
use IEEE.numeric_std.all;

library work;
use work.ulfe_config_oru.all;

entity ulfe_cal_cpSize_oru is	
    Port ( 
        i_clk                               : in std_logic;
        
        i_fftType                           : in std_logic_vector(2-1 downto 0);
        i_slotIdx                           : in std_logic_vector(2-1 downto 0);
        i_symIdx                            : in std_logic_vector(4-1 downto 0);
        
        o_cpSize                            : out std_logic_vector(12-1 downto 0)
    );
end ulfe_cal_cpSize_oru;

architecture Behavioral of ulfe_cal_cpSize_oru is	

    constant zeros                          : std_logic_vector((3+SCSTYPE)-1 downto 0) := (others=>'0');
    
    signal  cpSize_long                     : integer;
    signal  cpSize_short                    : integer;
    
    signal  cpSize_case                     : std_logic_vector(6-1 downto 0);

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            case (i_fftType) is
                when b"00"  =>  cpSize_long     <=  (144/4) + ((16/4)*(2**SCSTYPE));   cpSize_short <=  144/4;
                when b"01"  =>  cpSize_long     <=  (144/2) + ((16/2)*(2**SCSTYPE));   cpSize_short <=  144/2;
                when b"10"  =>  cpSize_long     <=    (144) +   ((16)*(2**SCSTYPE));   cpSize_short <=  144;
                when others =>  cpSize_long     <=  (144*2) + ((16*2)*(2**SCSTYPE));   cpSize_short <=  144*2;
            end case;
        end if;
    end process;

    cpsize_normal : if (CPTYPE = "normal") generate
        -- 1clk
        scstype_0 : if (SCSTYPE = 0) generate
            process(i_clk)
            begin
                if (rising_edge(i_clk)) then
                    case (i_symIdx) is 
                        when X"0"       =>  o_cpSize        <=  conv_std_logic_vector(cpSize_long, 12);
                        when X"7"       =>  o_cpSize        <=  conv_std_logic_vector(cpSize_long, 12);
                        when others     =>  o_cpSize        <=  conv_std_logic_vector(cpSize_short, 12);
                    end case;
                end if;
            end process;
        end generate scstype_0;
        
        scstype_1 : if (SCSTYPE = 1) generate
            process(i_clk)
            begin
                if (rising_edge(i_clk)) then
                    case (i_symIdx) is
                        when X"0"       =>  o_cpSize        <=  conv_std_logic_vector(cpSize_long, 12);
                        when others     =>  o_cpSize        <=  conv_std_logic_vector(cpSize_short, 12);
                    end case;
                end if;
            end process;
        end generate scstype_1;
        
        cpSize_case         <=  i_slotIdx & i_symIdx;
        scstype_2 : if (SCSTYPE = 2) generate
            process(i_clk)
            begin
                if (rising_edge(i_clk)) then
                    case (cpSize_case(4 downto 0)) is 
                        when b"00000"  =>  o_cpSize         <=  conv_std_logic_vector(cpSize_long, 12);
                        when others    =>  o_cpSize         <=  conv_std_logic_vector(cpSize_short, 12);
                    end case;
                end if;
            end process;
        end generate scstype_2;
        
        scstype_3 : if (SCSTYPE = 3) generate
            process(i_clk)
            begin
                if (rising_edge(i_clk)) then
                    case (cpSize_case) is
                        when b"000000"  =>  o_cpSize        <=  conv_std_logic_vector(cpSize_long, 12);
                        when others     =>  o_cpSize        <=  conv_std_logic_vector(cpSize_short, 12);
                    end case;
                end if;
            end process;
        end generate scstype_3;
    	
    end generate cpsize_normal;	
    
    cpsize_extened : if (CPTYPE = "extened") generate
        -- 1clk
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                case (i_fftType) is
                    when b"00" 	 => o_cpSize                <=  conv_std_logic_vector(512/4, 12);
                    when b"01" 	 => o_cpSize                <=  conv_std_logic_vector(512/2, 12);
                    when b"10" 	 => o_cpSize                <=  conv_std_logic_vector(512, 12);
                    when others  => o_cpSize                <=  conv_std_logic_vector(512*2, 12);
                end case;
            end if;
        end process;
    end generate cpsize_extened;

end Behavioral;	