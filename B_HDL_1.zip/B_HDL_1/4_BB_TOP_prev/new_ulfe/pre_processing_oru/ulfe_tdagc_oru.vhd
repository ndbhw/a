-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.08.03 v1.0] Initial release
-- [2023.10.30 v1.1] modify about "calbypassflag"
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_func.all;
use work.ulfe_component_pack_oru.all;
use work.ulfe_config_oru.all;

entity ulfe_tdagc_oru is
    generic (
        NUM_RX_ANT                          : integer := 4
    );
	Port(
        i_rst                               : in std_logic;
        i_clk                               : in std_logic;
        
        i_fs_num                            : in std_logic_vector(5-1 downto 0);
        i_SR_info                           : in std_logic_vector(3-1 downto 0);             -- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76
        
        i_TDAGC_sync                        : in std_logic;
        i_TDAGC_vld                         : in std_logic_vector(NUM_RX_ANT-1 downto 0);
        i_TDAGC_i                           : in std_logic_vector(15-1 downto 0);
        i_TDAGC_q                           : in std_logic_vector(15-1 downto 0);
        
        i_fftType                           : in std_logic_vector(2-1 downto 0);
		
        i_calBypassFlag                     : in std_logic;
        i_tagcOn                            : in std_logic;
        i_tagcBackoff                       : in std_logic_vector(5-1 downto 0);
        
        o_TDAGC_sync                        : out std_logic;
        o_TDAGC_vld                         : out std_logic;
        o_TDAGC_vld_sync                    : out std_logic;
        o_TDAGC_i                           : out std_logic_vector(15-1 downto 0);
        o_TDAGC_q                           : out std_logic_vector(15-1 downto 0);
        
        o_tdGain_vld                        : out std_logic;
        o_tdGain1                           : out std_logic_array4(NUM_RX_ANT-1 downto 0);
        o_tdGain2                           : out std_logic_array5(NUM_RX_ANT-1 downto 0);
        o_tdrssi                            : out std_logic_array32(NUM_RX_ANT-1 downto 0)
	);
end ulfe_tdagc_oru;

architecture Behavioral of ulfe_tdagc_oru is

    constant TDAGC_MEM_READ_LATENCY         : integer := 3;
    constant TDAGC_MEM_D_WIDTH              : integer := 15*2*NUM_RX_ANT;
    constant TDAGC_MEM_DEPTH                : integer := MAX_FFT_SIZE*2;            -- Double buffer
    
    constant module_latency                 : integer := 7+TDAGC_MEM_READ_LATENCY;
    constant zeros                          : std_logic_vector(log2ceil(TDAGC_MEM_DEPTH)-2 downto log2ceil(NUM_RX_ANT)) := (others=>'0');
    
    signal  mux_sel_1                       : std_logic_vector(5-1 downto 0);
    signal  mux_sel_2                       : std_logic;
    signal  mux_sel_2_use                   : std_logic;
    signal  f_sync_dly_num                  : std_logic_vector(16-1 downto 0);
    
    signal  r_fs_num                        : std_logic_vector(5-1 downto 0);
    signal  r_SR_info                       : std_logic_vector(3-1 downto 0);
    signal	r_fftType                       : std_logic_vector(2-1 downto 0);
    signal  r_td_calBypassFlag              : std_logic;
    signal	r_tagcOn                        : std_logic;
    signal	r_tagcBackoff                   : std_logic_vector(5-1 downto 0);
    
    signal  tdGain_vld                      : std_logic;
    signal  tdGain_vld_1d                   : std_logic;
    signal  tdGain1                         : std_logic_array4(NUM_RX_ANT-1 downto 0);
    signal  tdGain2                         : std_logic_array5(NUM_RX_ANT-1 downto 0);
    
    signal  buffer_sel                      : std_logic;
    signal  fftSize                         : std_logic_vector(12-1 downto 0);
    signal  wt_sample_count                 : std_logic_vector(12-1 downto 0);
    signal  wt_sample_count_1d              : std_logic_vector(12-1 downto 0);
    
    signal  wt_enable                       : std_logic;
    signal	wt_addr                         : std_logic_vector(log2ceil(TDAGC_MEM_DEPTH)-1 downto 0);
    signal	wt_data                         : std_logic_vector(TDAGC_MEM_D_WIDTH-1 downto 0);
    
    signal  rd_sample_count                 : std_logic_vector(12-1 downto 0);
    signal  rd_ant_count                    : std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
    signal  rd_ant_count_1d                 : std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
    signal  rd_ant_count_d                  : std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
    signal  rd_ant_count_d_int              : integer range 0 to NUM_RX_ANT-1;
    signal  rd_ant_count_d_3d               : std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
    
    signal  tdagc_vld                       : std_logic;
    signal  tdagc_vld_1d                    : std_logic;
    signal  rd_pre_addr                     : std_logic_vector(log2ceil(TDAGC_MEM_DEPTH)-2 downto 0);
    signal	rd_addr                         : std_logic_vector(log2ceil(TDAGC_MEM_DEPTH)-1 downto 0);
    signal	rd_data                         : std_logic_vector(TDAGC_MEM_D_WIDTH-1 downto 0);
    
    signal  shift_num                       : std_logic_vector(5-1 downto 0);
    signal  lut_addr                        : std_logic_vector(5-1 downto 0);
    signal  lut_data                        : std_logic_vector(10-1 downto 0);
    
    signal  cr_in_i                         : std_logic_vector(15-1 downto 0);
    signal  cr_in_q                         : std_logic_vector(15-1 downto 0);
    signal  cr_out_i                        : std_logic_vector(24-1 downto 0);
    signal  cr_out_q                        : std_logic_vector(24-1 downto 0);
    
    signal  fft_vld_sync                    : std_logic;

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            r_fs_num                            <=  i_fs_num;
            r_SR_info                           <=  i_SR_info;
            r_fftType                           <=  i_fftType;
            r_td_calBypassFlag                  <=  i_calBypassFlag;
            r_tagcOn                            <=  i_tagcOn;
            r_tagcBackoff                       <=  i_tagcBackoff;
        end if;
    end process;

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            case (r_fftType) is 
                when b"00"  =>  fftSize         <=  conv_std_logic_vector(512-1, 12);
                when b"01"  =>  fftSize         <=  conv_std_logic_vector(1024-1, 12);
                when b"10"  =>  fftSize         <=  conv_std_logic_vector(2048-1, 12);
                when others =>  fftSize         <=  conv_std_logic_vector(4096-1, 12);
            end case;
        end if;
    end process;

    -- SAMPLE_RATE ---------------------------------------
    -- SCS\FFT :   0(512)  1(1024) 2(2048) 3(4096)    ----
    -- 0( 15K)     7.68    15.36   30.72   61.44      ----
    -- 1( 30K)     15.36   30.72   61.44   122.88     ----
    -- 2( 60K)     30.72   61.44   122.88  245.76(X)  ----
    -- 3(120K)     61.44   122.88  245.76(x)          ----
    -- 4(240K)     122.88  245.76(x)                  ----
    ------------------------------------------------------

	-- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76
    mux_sel_1                  <=  r_SR_info & r_fftType;
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            case (mux_sel_1) is
                when b"000_00" =>  f_sync_dly_num    <=  conv_std_logic_vector((32*512)-23+module_latency+NUM_RX_ANT+4, 16);
                
                when b"001_00" =>  f_sync_dly_num    <=  conv_std_logic_vector((16*512)+module_latency+NUM_RX_ANT+4, 16);   -- need to check
                when b"001_01" =>  f_sync_dly_num    <=  conv_std_logic_vector((16*1024)-8+module_latency+NUM_RX_ANT+5, 16);
                
                when b"010_00" =>  f_sync_dly_num    <=  conv_std_logic_vector((8*512)+module_latency+NUM_RX_ANT+4, 16);    -- need to check
                when b"010_01" =>  f_sync_dly_num    <=  conv_std_logic_vector((8*1024)+module_latency+NUM_RX_ANT+5, 16);
                when b"010_10" =>  f_sync_dly_num    <=  conv_std_logic_vector((8*2048)-4+module_latency+NUM_RX_ANT+9, 16);
                
                when b"011_01" =>  f_sync_dly_num    <=  conv_std_logic_vector((4*1024)+module_latency+NUM_RX_ANT+5, 16);   -- need to check
                when b"011_10" =>  f_sync_dly_num    <=  conv_std_logic_vector((4*2048)+module_latency+NUM_RX_ANT+9, 16);
                when b"011_11" =>  f_sync_dly_num    <=  conv_std_logic_vector((4*4096)+module_latency+NUM_RX_ANT+11, 16);  -- need to check
                
                when b"100_10" =>  f_sync_dly_num    <=  conv_std_logic_vector((2*2048)+module_latency+NUM_RX_ANT+9, 16);   -- need to check
                when b"100_11" =>  f_sync_dly_num    <=  conv_std_logic_vector((2*4096)+module_latency+NUM_RX_ANT+11, 16);
                
                when b"101_10" =>  f_sync_dly_num    <=  conv_std_logic_vector(2048+module_latency+NUM_RX_ANT+9, 16);       -- need to check
                when b"101_11" =>  f_sync_dly_num    <=  conv_std_logic_vector(4096+module_latency+NUM_RX_ANT+11, 16);      -- need to check
                
                when others    =>  f_sync_dly_num    <=  conv_std_logic_vector(1, 16);
            end case;
        end if;
    end process;

    ----------------------------------------------------------------------------------------------------------------------------------------------------
    -- Cal gain
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            wt_sample_count_1d                  <=  wt_sample_count;
            tdagc_vld_1d                        <=  tdagc_vld;
            
            if (wt_sample_count_1d = 0 and wt_sample_count = 1) then
                mux_sel_2                       <=  (not r_td_calBypassFlag) and r_tagcOn;
            else
                mux_sel_2                       <=  mux_sel_2;
            end if;
        end if;
    end process;
    
    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            mux_sel_2_use                       <=  '1';
        elsif (rising_edge(i_clk)) then
            if (tdagc_vld_1d = '1' and tdagc_vld = '0') then
                mux_sel_2_use                   <=  mux_sel_2;
            else
                mux_sel_2_use                   <=  mux_sel_2_use;
            end if;
        end if;
    end process;
    
    CAL_GAIN : ulfe_tdagc_cal_gain_oru generic map(NUM_RX_ANT)
    port map(i_clk, r_fs_num, r_SR_info, i_TDAGC_sync, i_TDAGC_vld, i_TDAGC_i, i_TDAGC_q, r_fftType, fftSize, mux_sel_2_use, r_tagcBackoff, tdGain_vld, tdGain1, tdGain2, o_tdrssi);
    
    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            o_tdGain_vld                        <=  '0';
        elsif (rising_edge(i_clk)) then
            o_tdGain_vld                        <=  tdGain_vld;
        end if;
    end process;
    
    o_tdGain1                                   <=  tdGain1;
    o_tdGain2                                   <=  tdGain2;

    ----------------------------------------------------------------------------------------------------------------------------------------------------
    -- buffer write
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_TDAGC_sync = '1' or (wt_sample_count = fftSize and i_TDAGC_vld(NUM_RX_ANT-1) = '1')) then
                wt_sample_count                 <=  (others=>'0');
            elsif (i_TDAGC_vld(NUM_RX_ANT-1) = '1') then
                wt_sample_count                 <=  wt_sample_count + '1';
            else
                wt_sample_count                 <=  wt_sample_count;
            end if;
        end if;
    end process;
    
    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            buffer_sel                          <=  '0';
        elsif (rising_edge(i_clk)) then
            if (wt_sample_count = fftSize and i_TDAGC_vld(NUM_RX_ANT-1) = '1') then
                buffer_sel                      <=  not buffer_sel;
            else
                buffer_sel                      <=  buffer_sel;
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_TDAGC_vld(NUM_RX_ANT-1) = '1') then
                wt_enable                       <=  '1';
            else
                wt_enable                       <=  '0';
            end if;
            wt_addr                             <=  buffer_sel & wt_sample_count(log2ceil(TDAGC_MEM_DEPTH)-2 downto 0);
            wt_data                             <=  i_TDAGC_i & i_TDAGC_q & wt_data(30*NUM_RX_ANT-1 downto 30);
        end if;
    end process;
    
    -- iq_data buffer	
    iq_bram : ulfe_lib_sdpram generic map("ultra",TDAGC_MEM_READ_LATENCY,TDAGC_MEM_D_WIDTH,TDAGC_MEM_D_WIDTH,TDAGC_MEM_DEPTH,TDAGC_MEM_DEPTH)
        port map(
            i_clk                               =>  i_clk,
            
            i_wt_enable                         =>  wt_enable,
            i_wt_addr                           =>  wt_addr,
            i_wt_data                           =>  wt_data,
            
            i_rd_addr                           =>  rd_addr,
            o_rd_dout                           =>  rd_data
        );
    
    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            rd_sample_count                     <=  (others=>'1');
            rd_ant_count                        <=  (others=>'1');
            fft_vld_sync                        <=  '0';
        elsif (rising_edge(i_clk)) then
            if (tdGain_vld = '1') then
                rd_sample_count                 <=  (others=>'0');
                rd_ant_count                    <=  (others=>'0');
                fft_vld_sync                    <=  '1';
            elsif (rd_sample_count = fftSize and rd_ant_count /= conv_std_logic_vector(NUM_RX_ANT-1,log2ceil(NUM_RX_ANT))) then
                rd_sample_count                 <=  (others=>'0');
                rd_ant_count                    <=  rd_ant_count + '1';
                fft_vld_sync                    <=  '1';
            else
                rd_sample_count                 <=  rd_sample_count + '1';
                rd_ant_count                    <=  rd_ant_count;
                fft_vld_sync                    <=  '0';
            end if;
            
            rd_ant_count_1d                     <=  rd_ant_count;
        end if;
    end process;
    
    rd_ant_count_dly_1 : ulfe_lib_dly_fixed generic map(TDAGC_MEM_READ_LATENCY, log2ceil(NUM_RX_ANT)) port map(i_clk, rd_ant_count, rd_ant_count_d);
    rd_ant_count_dly_2 : ulfe_lib_dly_fixed generic map(3, log2ceil(NUM_RX_ANT)) port map(i_clk, rd_ant_count_d, rd_ant_count_d_3d);
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            rd_ant_count_d_int                  <=  conv_integer(rd_ant_count_d);
        end if;
    end process;
    
    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            tdGain_vld_1d                       <=  '0';
            tdagc_vld                           <=  '0';
        elsif (rising_edge(i_clk)) then
            tdGain_vld_1d                       <=  tdGain_vld;
            if (tdGain_vld_1d = '1') then
                tdagc_vld                       <=  '1';
            elsif (rd_ant_count_1d = conv_std_logic_vector(NUM_RX_ANT-1,log2ceil(NUM_RX_ANT)) and rd_sample_count = fftSize+1) then
                tdagc_vld                       <=  '0';
            else
                tdagc_vld                       <=  tdagc_vld;
            end if;
        end if;
    end process;
    
    rvs_addr_gen : for i in 0 to log2ceil(TDAGC_MEM_DEPTH)-2 generate
        rd_pre_addr(i)                          <=  rd_sample_count((log2ceil(TDAGC_MEM_DEPTH)-2)-i);
    end generate rvs_addr_gen;
    
    MAX_FFT_SIZE_4096 : if (MAX_FFT_SIZE = 4096) generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                case (r_fftType) is
                    when b"00"  =>  rd_addr <=  (not buffer_sel) & b"000" & rd_pre_addr(log2ceil(TDAGC_MEM_DEPTH)-2 downto 3);
                    when b"01"  =>  rd_addr <=  (not buffer_sel) & b"00" & rd_pre_addr(log2ceil(TDAGC_MEM_DEPTH)-2 downto 2);
                    when b"10"  =>  rd_addr <=  (not buffer_sel) & b"0" & rd_pre_addr(log2ceil(TDAGC_MEM_DEPTH)-2 downto 1);
                    when others =>  rd_addr <=  (not buffer_sel) & rd_pre_addr;
                end case;
            end if;
        end process;
    end generate MAX_FFT_SIZE_4096;
    
    MAX_FFT_SIZE_2048 : if (MAX_FFT_SIZE = 2048) generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                case (r_fftType) is
                    when b"00"  =>  rd_addr <=  (not buffer_sel) & b"00" & rd_pre_addr(log2ceil(TDAGC_MEM_DEPTH)-2 downto 2);
                    when b"01"  =>  rd_addr <=  (not buffer_sel) & b"0" & rd_pre_addr(log2ceil(TDAGC_MEM_DEPTH)-2 downto 1);
                    when others =>  rd_addr <=  (not buffer_sel) & rd_pre_addr;
                end case;
            end if;
        end process;
    end generate MAX_FFT_SIZE_2048;
    
    cr_in_i                       <=  rd_data((30*(rd_ant_count_d_int)+29) downto (30*(rd_ant_count_d_int)+15));
    cr_in_q                       <=  rd_data((30*(rd_ant_count_d_int)+14) downto 30*(rd_ant_count_d_int));
    
    ----------------------------------------------------------------------------------------------------------------------------------------------------
    -- data calculate
    
    lut_addr                      <=  tdGain2(conv_integer(rd_ant_count_d));
    TDAGC_LUT : ulfe_tdagc_lut_oru port map(i_clk, lut_addr, lut_data);
    
    -- 3 clk
    CR_i : ulfe_lib_dsp_CR generic map(15,10,24) port map(i_clk, cr_in_i, lut_data, cr_out_i);
    CR_q : ulfe_lib_dsp_CR generic map(15,10,24) port map(i_clk, cr_in_q, lut_data, cr_out_q);
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            shift_num             <=  b"01000" - (tdGain1(conv_integer(rd_ant_count_d_3d))(3) & tdGain1(conv_integer(rd_ant_count_d_3d)));
        end if;
    end process;
    
    ----------------------------------------------------------------------------------------------------------------------------------------------------
    -- data out
    
    -- 4 clk
    sr_sat_sym_i : ylib_sshftvd_sat generic map(24,5,15,"SYMMETRIC_ROUND","SYMMETRIC") port map(i_clk, shift_num, '1', cr_out_i, open, o_TDAGC_i);
    sr_sat_sym_q : ylib_sshftvd_sat generic map(24,5,15,"SYMMETRIC_ROUND","SYMMETRIC") port map(i_clk, shift_num, '1', cr_out_q, open, o_TDAGC_q);
    
    F_SYNC_OUT   : ulfe_lib_dly_variable generic map (16) port map(i_rst, i_clk, f_sync_dly_num, i_TDAGC_sync, o_TDAGC_sync);
    VLD_SYNC_OUT : ulfe_lib_dly_fixed generic map(module_latency, 1) port map(i_clk	=> i_clk, data_i(0) => fft_vld_sync, data_o(0) => o_TDAGC_vld_sync);
    VLD_DLY_OUT  : ulfe_lib_dly_fixed generic map(module_latency, 1) port map(i_clk	=> i_clk, data_i(0) => tdagc_vld, data_o(0) => o_TDAGC_vld);

end Behavioral;