-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.08.08 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_func.all;
use work.ulfe_component_pack_oru.all;
use work.ulfe_config_oru.all;

entity ulfe_gaincomp_oru is
    generic (
        NUM_RX_ANT                          : integer := 4
    );
    Port(
        i_rst                               : in std_logic;
        i_clk                               : in std_logic;
        
        i_gainCompOn                        : in std_logic;
        i_calBypassFlag                     : in std_logic;
        
        i_GAINCOMP_sync_adv_1clk            : in std_logic;
        i_GAINCOMP_vld                      : in std_logic_vector(NUM_RX_ANT-1 downto 0);
        i_GAINCOMP_vld_adv_2clk             : in std_logic;
        i_GAINCOMP_i                        : in std_logic_vector(15-1 downto 0);
        i_GAINCOMP_q                        : in std_logic_vector(15-1 downto 0);
        
        i_tdGain1                           : in std_logic_array4(NUM_RX_ANT-1 downto 0);
        i_tdGain2                           : in std_logic_array5(NUM_RX_ANT-1 downto 0);
        
        o_GAINCOMP_sync                     : out std_logic;
        o_GAINCOMP_vld_adv_5clk             : out std_logic_vector(NUM_RX_ANT-1 downto 0);
        o_GAINCOMP_ant_num                  : out std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
        o_GAINCOMP_i                        : out std_logic_vector(15-1 downto 0);
        o_GAINCOMP_q                        : out std_logic_vector(15-1 downto 0)
    );
end ulfe_gaincomp_oru;

architecture Behavioral of ulfe_gaincomp_oru is

    constant  module_latency                : integer := 7;
    
    signal  i_GAINCOMP_vld_adv_1clk         : std_logic;
    signal  i_GAINCOMP_vld_1d               : std_logic_vector(NUM_RX_ANT-1 downto 0);
    
    signal  mux_sel                         : std_logic;
    
    signal 	rd_ant_num                      : std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
    signal 	rd_ant_num_1d                   : std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
    
    signal  shift_num                       : std_logic_vector(5-1 downto 0);
    signal  lut_addr                        : std_logic_vector(5-1 downto 0);
    signal  lut_data                        : std_logic_vector(10-1 downto 0);
    
    signal  cr_out_i                        : std_logic_vector(24-1 downto 0);
    signal  cr_out_q                        : std_logic_vector(24-1 downto 0);

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_gainCompOn = '1' and i_calBypassFlag = '0') then
                mux_sel                     <=  '1';
            else
                mux_sel                     <=  '0';
            end if;
        end if;	
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            i_GAINCOMP_vld_adv_1clk         <=  i_GAINCOMP_vld_adv_2clk;
            i_GAINCOMP_vld_1d               <=  i_GAINCOMP_vld;
            if (i_GAINCOMP_sync_adv_1clk = '1') then
                rd_ant_num                  <=  (others=>'0');
            elsif (i_GAINCOMP_vld_1d /= 0 and i_GAINCOMP_vld = 0) then
                rd_ant_num                  <=  rd_ant_num + '1';
            else
                rd_ant_num                  <=  rd_ant_num;
            end if;
            rd_ant_num_1d                   <=  rd_ant_num;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (mux_sel = '0') then
                shift_num                   <=  b"01000";
            else
                shift_num                   <=  b"01000" + (i_tdGain1(conv_integer(rd_ant_num_1d))(3) & i_tdGain1(conv_integer(rd_ant_num_1d)));
            end if;
        end if;
    end process;
    
    process(i_clk) 
    begin
        if (rising_edge(i_clk)) then
            if (i_GAINCOMP_vld_adv_1clk = '0' and i_GAINCOMP_vld_adv_2clk = '1' and mux_sel = '0') then				
                lut_addr                    <=  (others=>'0');
            elsif (i_GAINCOMP_vld_adv_1clk = '0' and i_GAINCOMP_vld_adv_2clk = '1') then
                lut_addr                    <=  i_tdGain2(conv_integer(rd_ant_num));
            else
                lut_addr                    <=  lut_addr;
            end if;
        end if;
    end process;
    
    GAINCOMP_LUT : ulfe_gaincomp_lut_oru port map(i_clk, lut_addr, lut_data);
    
    -- 3 clk
    CR_i : ulfe_lib_dsp_CR generic map(15,10,24) port map(i_clk, i_GAINCOMP_i, lut_data, cr_out_i);
    CR_q : ulfe_lib_dsp_CR generic map(15,10,24) port map(i_clk, i_GAINCOMP_q, lut_data, cr_out_q);
    
    ----------------------------------------------------------------------------------------------------------------------------------------------------
    -- data out
    
    -- 4 clk
    sr_sat_sym_i : ylib_sshftvd_sat generic map(24,5,15,"SYMMETRIC_ROUND","SYMMETRIC") port map(i_clk, shift_num, '1', cr_out_i, open, o_GAINCOMP_i);
    sr_sat_sym_q : ylib_sshftvd_sat generic map(24,5,15,"SYMMETRIC_ROUND","SYMMETRIC") port map(i_clk, shift_num, '1', cr_out_q, open, o_GAINCOMP_q);
    
    F_SYNC_OUT   : ulfe_lib_dly_fixed generic map(module_latency+1, 1) port map(i_clk => i_clk, data_i(0) => i_GAINCOMP_sync_adv_1clk, data_o(0) => o_GAINCOMP_sync);
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            o_GAINCOMP_vld_adv_5clk         <=  i_GAINCOMP_vld_1d;	
            o_GAINCOMP_ant_num              <=  rd_ant_num;
        end if;
    end process;

end Behavioral;