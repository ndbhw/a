-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.08.03 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_func.all;
use work.ulfe_config_oru.all;

entity ulfe_idx_counter_oru is	
    Port ( 
        i_rst                       : in std_logic;
        i_clk                       : in std_logic;
        
        i_fftType                   : in std_logic_vector(2-1 downto 0);
        i_cpSize                    : in std_logic_vector(11-1 downto 0);
        
        i_frame_sync                : in std_logic;
        
        i_fs_num                    : in std_logic_vector(5-1 downto 0);
        
        o_sample_cnt                : out std_logic_vector(13-1 downto 0);
        o_slotIdx                   : out std_logic_vector(8-1 downto 0);
        o_symIdx                    : out std_logic_vector(4-1 downto 0);
        o_slot_tick                 : out std_logic;
        o_sym_tick                  : out std_logic;
        o_fs_tick                   : out std_logic
    );
end ulfe_idx_counter_oru;

architecture Behavioral of ulfe_idx_counter_oru is

    constant MAX_SLOT                       : integer := 10*(2**SCSTYPE);
    constant MAX_SYMIDX                     : std_logic_vector(4-1 downto 0) := ternary_func(CPTYPE="normal",X"D",X"B");
    
    signal  fs_num_cnt                      : std_logic_vector(5-1 downto 0);
    signal  end_condition                   : std_logic_vector(13-1 downto 0);
    
    signal  sample_cnt                      : std_logic_vector(13-1 downto 0);
    signal  slotIdx                         : std_logic_vector(8-1 downto 0);
    signal  symIdx                          : std_logic_vector(4-1 downto 0);
    signal  slot_tick                       : std_logic;
    signal  sym_tick                        : std_logic;
    signal  fs_tick                         : std_logic;

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            case (i_fftType) is
                when b"00"  =>  end_condition   <=  (i_cpSize(10) & i_cpSize(10) & i_cpSize) + conv_std_logic_vector(512-1,13);
                when b"01"  =>  end_condition   <=  (i_cpSize(10) & i_cpSize(10) & i_cpSize) + conv_std_logic_vector(1024-1,13);
                when b"10"  =>	end_condition   <=  (i_cpSize(10) & i_cpSize(10) & i_cpSize) + conv_std_logic_vector(2048-1,13);
                when others =>	end_condition   <=  (i_cpSize(10) & i_cpSize(10) & i_cpSize) + conv_std_logic_vector(4096-1,13);
            end case;
        end if;
    end process;

    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            fs_num_cnt                  <=  (others=>'0');
        elsif (rising_edge(i_clk)) then
            if (i_frame_sync = '1') then
                fs_num_cnt              <=  (others=>'0');
                fs_tick                 <=  '0';
            elsif (fs_num_cnt = i_fs_num) then
                fs_num_cnt              <=  (others=>'0');
                fs_tick                 <=  '1';
            else
                fs_num_cnt              <=  fs_num_cnt + '1';
                fs_tick                 <=  '0';
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_frame_sync = '1' or (sample_cnt = end_condition and fs_num_cnt = i_fs_num)) then
                sample_cnt              <=  (others=>'0');
            elsif (fs_num_cnt = i_fs_num) then
                sample_cnt              <=  sample_cnt + '1';
            else
                sample_cnt              <=  sample_cnt;
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_frame_sync = '1') then
                symIdx                  <=  (others=>'0');
                slotIdx                 <=  (others=>'0');
                slot_tick               <=  '1';
                sym_tick                <=  '1';
            elsif ((sample_cnt = end_condition and fs_num_cnt = i_fs_num) and symIdx = MAX_SYMIDX) then
                symIdx                  <=  (others=>'0');
                slotIdx                 <=  slotIdx + '1';
                slot_tick               <=  '1';
                sym_tick                <=  '1';
            elsif (sample_cnt = end_condition and fs_num_cnt = i_fs_num) then
                symIdx                  <=  symIdx + '1';
                slotIdx                 <=  slotIdx;
                slot_tick               <=  '0';
                sym_tick                <=  '1';
            else
                symIdx                  <=  symIdx;
                slotIdx                 <=  slotIdx;
                slot_tick               <=  '0';
                sym_tick                <=  '0';
            end if;
        end if;
    end process;
    
    o_sample_cnt                        <=  sample_cnt;
    o_slotIdx                           <=  slotIdx;
    o_symIdx                            <=  symIdx;
    o_slot_tick                         <=  slot_tick;
    o_sym_tick                          <=  sym_tick;
    o_fs_tick                           <=  fs_tick;
	
end Behavioral;