-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.08.03 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
use IEEE.numeric_std.all;

library work;
use work.ulfe_config_oru.all;
use work.ulfe_component_pack_oru.all;

entity ulfe_cprm_oru is
    generic (
        NUM_RX_ANT                          : integer := 4
    );
    Port(
        i_rst                               : in std_logic;
        i_clk                               : in std_logic;
        
        i_sample_cnt                        : in std_logic_vector(13-1 downto 0);
        i_cp_size                           : in std_logic_vector(12-1 downto 0);
        
        i_CPRM_sync                         : in std_logic;
        i_CPRM_vld                          : in std_logic_vector(NUM_RX_ANT-1 downto 0);
        i_CPRM_i                            : in std_logic_vector(15-1 downto 0);
        i_CPRM_q                            : in std_logic_vector(15-1 downto 0);
        
        i_cpRmOffset                        : in std_logic_vector(11-1 downto 0);
        i_fftType                           : in std_logic_vector(2-1 downto 0);
        i_calBypassFlag                     : in std_logic;
        
        o_CPRM_sync                         : out std_logic;
        o_CPRM_vld                          : out std_logic_vector(NUM_RX_ANT-1 downto 0);
        o_CPRM_i                            : out std_logic_vector(15-1 downto 0);
        o_CPRM_q                            : out std_logic_vector(15-1 downto 0)
    );
end ulfe_cprm_oru;

architecture Behavioral of ulfe_cprm_oru is

    signal  r_fftType                       : std_logic_vector(2-1 downto 0);
    signal  fft_size                        : std_logic_vector(13-1 downto 0);
    
    signal  cpOffset_pre                    : std_logic_vector(12-1 downto 0);
    signal  end_condition                   : std_logic_vector(13-1 downto 0);
    
    signal  cpOffset                        : std_logic_vector(13-1 downto 0);
    signal  f_sync_dly                      : std_logic_vector(18-1 downto 0);
    
    signal  r_sample_cnt                    : std_logic_vector(13-1 downto 0);
    signal  r_cp_size                       : std_logic_vector(12-1 downto 0);

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            r_fftType                       <=  i_fftType;
            r_sample_cnt                    <=  i_sample_cnt;
            r_cp_size                       <=  i_cp_size;
            
            if (i_calBypassFlag = '0') then
                cpOffset_pre                <=  r_cp_size - ('0' & i_cpRmOffset);
            else
                cpOffset_pre                <=  r_cp_size;
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (cpOffset_pre(11) = '1') then
                end_condition               <=  fft_size;
                cpOffset                    <=  (others=>'0');
            else
                end_condition               <=  (b"0" & cpOffset_pre) + fft_size;
                cpOffset                    <=  b"0" & cpOffset_pre;
            end if;
        end if;
    end process;
    
    scstype_0 : if (SCSTYPE = 0) generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                case (r_fftType) is 
                    when b"00"    =>  f_sync_dly    <=  cpOffset & b"00000";        fft_size    <=  conv_std_logic_vector(512,13);
                    when b"01"    =>  f_sync_dly    <=  b"0" & cpOffset & b"0000";  fft_size    <=  conv_std_logic_vector(1024,13);
                    when b"10"    =>  f_sync_dly    <=  b"00" & cpOffset & b"000";  fft_size    <=  conv_std_logic_vector(2048,13);
                    when others   =>  f_sync_dly    <=  b"000" & cpOffset & b"00";  fft_size    <=  conv_std_logic_vector(4096,13);
                end case;
            end if;
        end process;
    end generate scstype_0;
    
    scstype_1 : if (SCSTYPE = 1) generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                case (r_fftType) is 
                    when b"00"    =>  f_sync_dly    <=  b"0" & cpOffset & b"0000";  fft_size    <=  conv_std_logic_vector(512,13);
                    when b"01"    =>  f_sync_dly    <=  b"00" & cpOffset & b"000";  fft_size    <=  conv_std_logic_vector(1024,13);
                    when b"10"    =>  f_sync_dly    <=  b"000" & cpOffset & b"00";  fft_size    <=  conv_std_logic_vector(2048,13);
                    when others   =>  f_sync_dly    <=  b"0000" & cpOffset & b"0";  fft_size    <=  conv_std_logic_vector(4096,13);
                end case;
            end if;
        end process;
    end generate scstype_1;
    
    scstype_2 : if (SCSTYPE = 2) generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                case (r_fftType) is 
                    when b"00"    =>  f_sync_dly    <=  b"00" & cpOffset & b"000";  fft_size    <=  conv_std_logic_vector(512,13);
                    when b"01"    =>  f_sync_dly    <=  b"000" & cpOffset & b"00";  fft_size    <=  conv_std_logic_vector(1024,13);
                    when b"10"    =>  f_sync_dly    <=  b"0000" & cpOffset & b"0";  fft_size    <=  conv_std_logic_vector(2048,13);
                    when others   =>  f_sync_dly    <=  b"00000" & cpOffset;        fft_size    <=  conv_std_logic_vector(4096,13);
                end case;
            end if;
        end process;
    end generate scstype_2;
    
    scstype_3 : if (SCSTYPE = 3) generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                case (r_fftType) is 
                    when b"00"    =>  f_sync_dly    <=  b"000" & cpOffset & b"00";  fft_size    <=  conv_std_logic_vector(512,13);
                    when b"01"    =>  f_sync_dly    <=  b"0000" & cpOffset & b"0";  fft_size    <=  conv_std_logic_vector(1024,13);
                    when b"11"    =>  f_sync_dly    <=  b"00000" & cpOffset;        fft_size    <=  conv_std_logic_vector(2048,13);
                    when others   =>  f_sync_dly    <=  b"00000" & cpOffset;        fft_size    <=  conv_std_logic_vector(4096,13);
                end case;
            end if;
        end process;
    end generate scstype_3;
    
    ------------------------------------------------------------------------------------------------------------
    -- data out
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (r_sample_cnt >= cpOffset and r_sample_cnt < end_condition) then
                o_CPRM_vld                  <=  i_CPRM_vld;
            else
                o_CPRM_vld                  <=  (others=>'0');
            end if;
            
            o_CPRM_i                        <=  i_CPRM_i;
            o_CPRM_q                        <=  i_CPRM_q;
        end if;
    end process;
    
    f_sync_out : ulfe_lib_dly_variable generic map (18) port map(i_rst, i_clk, f_sync_dly, i_CPRM_sync, o_CPRM_sync);

end Behavioral;