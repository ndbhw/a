-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.08.08 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_func.all;
use work.ulfe_component_pack_oru.all;
use work.ulfe_config_oru.all;

entity ulfe_cts_oru is
    generic (
        NUM_RX_ANT                          : integer := 4
    );
    Port(
        i_rst                               : in std_logic;
        i_clk                               : in std_logic;
        
        i_CTS_sync                          : in std_logic;
        i_CTS_vld_adv_5clk                  : in std_logic_vector(NUM_RX_ANT-1 downto 0);
        i_CTS_i                             : in std_logic_vector(15-1 downto 0);
        i_CTS_q                             : in std_logic_vector(15-1 downto 0);
        
        i_calBypassFlag                     : in std_logic;
        i_ctsOn                             : in std_logic;
        i_ctsShift                          : in std_logic_vector(12-1 downto 0);
        
        o_CTS_sync_adv_5clk                 : out std_logic;
        o_CTS_vld                           : out std_logic_vector(NUM_RX_ANT-1 downto 0);
        o_CTS_i                             : out std_logic_vector(15-1 downto 0);
        o_CTS_q                             : out std_logic_vector(15-1 downto 0)
    );
end ulfe_cts_oru;

architecture Behavioral of ulfe_cts_oru is

    signal  r_calBypassFlag                     : std_logic;
    signal  r_ctsOn                             : std_logic;
    signal  r_ctsShift                          : std_logic_vector(12-1 downto 0);
    
    signal  r_CTS_vld_adv_5clk_1d               : std_logic_vector(NUM_RX_ANT-1 downto 0);
    
    signal  phase_pre                           : std_logic_vector(13-1 downto 0);
    signal  cos                                 : std_logic_vector(16-1 downto 0);
    signal  sin                                 : std_logic_vector(16-1 downto 0);
    
    signal  cts_c_multi_data_i                  : std_logic_vector(31-1 downto 0);
    signal  cts_c_multi_data_q                  : std_logic_vector(31-1 downto 0);

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            r_calBypassFlag                     <=  i_calBypassFlag;
            r_ctsOn                             <=  i_ctsOn;
            r_ctsShift                          <=  i_ctsShift;
            
            r_CTS_vld_adv_5clk_1d               <=  i_CTS_vld_adv_5clk;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (r_ctsOn = '0' or r_calBypassFlag = '1' or (r_CTS_vld_adv_5clk_1d = 0 and i_CTS_vld_adv_5clk /= 0)) then
                phase_pre                       <=  (others=>'0');
            else
                phase_pre                       <=  phase_pre + ('0' & r_ctsShift);
            end if;
        end if;
    end process;
    
    -- 4 clk
    expj14 : ulfe_lib_expj_v2 generic map('1',12) port map(i_clk, phase_pre(11 downto 0), cos, sin);
    
    -- 6 clk
    cts_c_multi : ulfe_lib_C_multi_v2 generic map(15,16,31) port map(i_clk, i_CTS_i, i_CTS_q, cos, sin, cts_c_multi_data_i, cts_c_multi_data_q);
    
    ----------------------------------------------------------------------------------------------------------------------------------------------
    -- data out
    
    -- 3 clk
    cts_r_sh_sym_sat_i : ylib_sshftd_sat generic map(31,15,15,"SYMMETRIC_ROUND","SYMMETRIC") port map(i_clk, '1', cts_c_multi_data_i, open, o_CTS_i);
    cts_r_sh_sym_sat_q : ylib_sshftd_sat generic map(31,15,15,"SYMMETRIC_ROUND","SYMMETRIC") port map(i_clk, '1', cts_c_multi_data_q, open, o_CTS_q);
    
    F_SYNC_OUT 	 : ulfe_lib_dly_fixed generic map(9-5, 1) port map(i_clk => i_clk, data_i(0) => i_CTS_sync, data_o(0) => o_CTS_sync_adv_5clk);
    VLD_DLY_OUT  : ulfe_lib_dly_fixed generic map(9+5, NUM_RX_ANT) port map(i_clk, i_CTS_vld_adv_5clk, o_CTS_vld);

end Behavioral;