-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.08.03 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
use IEEE.numeric_std.all;

library work;
use work.ulfe_config_oru.all;
use work.ulfe_component_pack_oru.all;

entity ulfe_freqshift_oru is
    generic (
        NUM_RX_ANT                          : integer := 4
    );
    Port (
        i_rst                               : in std_logic;
        i_clk                               : in std_logic;
        
        i_FREQSHIFT_sync                    : in std_logic;
        i_FREQSHIFT_vld                     : in std_logic_vector(NUM_RX_ANT-1 downto 0);
        i_FREQSHIFT_i                       : in std_logic_vector(15-1 downto 0);
        i_FREQSHIFT_q                       : in std_logic_vector(15-1 downto 0);
        
        i_fftType                           : in std_logic_vector(2-1 downto 0);
        i_freqShiftOn                       : in std_logic;
        
        i_fs_num                            : in std_logic_vector(5-1 downto 0);
        
        o_sample_cnt                        : out std_logic_vector(13-1 downto 0);
        o_cp_size                           : out std_logic_vector(12-1 downto 0);
        
        o_FREQSHIFT_sync                    : out std_logic;
        o_FREQSHIFT_vld                     : out std_logic_vector(NUM_RX_ANT-1 downto 0);
        o_FREQSHIFT_i                       : out std_logic_vector(15-1 downto 0);
        o_FREQSHIFT_q                       : out std_logic_vector(15-1 downto 0)
    );
end ulfe_freqshift_oru;

architecture Behavioral of ulfe_freqshift_oru is

    constant module_latency                 : integer := 16;
    
    signal  r_fftType                       : std_logic_vector(2-1 downto 0);
    signal  r_freqShiftOn                   : std_logic;
    
    signal  r_fs_num                        : std_logic_vector(5-1 downto 0);
    
    signal  slotIdx                         : std_logic_vector(8-1 downto 0);
    signal  symIdx                          : std_logic_vector(4-1 downto 0);
    signal  symTick                         : std_logic;
    signal  symTick_1d                      : std_logic;
    signal  fsTick                          : std_logic;
    signal  fsTick_1d                       : std_logic;
    signal  cpSize                          : std_logic_vector(12-1 downto 0);
    signal  cpSize_m1                       : std_logic_vector(15-1 downto 0);
    signal  cpSize_m1_sh                    : std_logic_vector(18-1 downto 0);
    
    signal  sample_cnt                      : std_logic_vector(13-1 downto 0);
    
    signal  cos                             : std_logic_vector(16-1 downto 0);
    signal  sin                             : std_logic_vector(16-1 downto 0);
    signal  cos_d                           : std_logic_vector(16-1 downto 0);
    signal  sin_d                           : std_logic_vector(16-1 downto 0);
    
    signal  i_FREQSHIFT_i_7d                : std_logic_vector(15-1 downto 0);
    signal  i_FREQSHIFT_q_7d                : std_logic_vector(15-1 downto 0);
    
    signal  c_multi_data_i                  : std_logic_vector(31-1 downto 0);
    signal  c_multi_data_q                  : std_logic_vector(31-1 downto 0);

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            r_fftType                       <=  i_fftType;
            r_freqShiftOn                   <=  i_freqShiftOn;
            r_fs_num                        <=  i_fs_num;
            
            symTick_1d                      <=  symTick;
            fsTick_1d                       <=  fsTick;
        end if;
    end process;
    
    idx_counter : ulfe_idx_counter_oru port map(i_rst, i_clk, r_fftType, cpSize(10 downto 0), i_FREQSHIFT_sync, r_fs_num, sample_cnt, slotIdx, symIdx, open, symTick, fsTick);
    cal_cpsize : ulfe_cal_cpSize_oru port map(i_clk, r_fftType, slotIdx(1 downto 0), symIdx, cpSize);
    
    NR_GEN : if (LTE_NR_MODE = "NR") generate
        o_sample_cnt                        <=  sample_cnt;
        o_cp_size                           <=  cpSize;
        
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                o_FREQSHIFT_sync            <=  i_FREQSHIFT_sync;
                o_FREQSHIFT_vld             <=  i_FREQSHIFT_vld;
                o_FREQSHIFT_i               <=  i_FREQSHIFT_i;
                o_FREQSHIFT_q               <=  i_FREQSHIFT_q;
            end if;
        end process;
    end generate NR_GEN;
    
    LTE_GEN : if (LTE_NR_MODE /= "NR") generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                if (symTick_1d = '1') then
                    cpSize_m1               <=  b"000" & cpSize;
                elsif (fsTick_1d = '1') then
                    cpSize_m1               <=  cpSize_m1 - '1';
                else
                    cpSize_m1               <=  cpSize_m1;
                end if;
            end if;
        end process;
        
        scstype_0 : if (SCSTYPE = 0) generate
            process(i_clk)
            begin
                if (rising_edge(i_clk)) then
                    case (r_fftType) is 
                        when b"00"    =>  cpSize_m1_sh    <=  cpSize_m1(13 downto 0) & b"0000";
                        when b"01"    =>  cpSize_m1_sh    <=  b"0" & cpSize_m1(13 downto 0) & b"000";
                        when b"10"    =>  cpSize_m1_sh    <=  b"00" & cpSize_m1(13 downto 0) & b"00";
                        when others   =>  cpSize_m1_sh    <=  b"000" & cpSize_m1(13 downto 0) & b"0";
                    end case;
                end if;
            end process;
        end generate scstype_0;
        
        scstype_1 : if (SCSTYPE = 1) generate
            process(i_clk)
            begin
                if (rising_edge(i_clk)) then
                    case (r_fftType) is 
                        when b"00"    =>  cpSize_m1_sh    <=  b"0" & cpSize_m1(13 downto 0) & b"000";
                        when b"01"    =>  cpSize_m1_sh    <=  b"00" & cpSize_m1(13 downto 0) & b"00";
                        when b"10"    =>  cpSize_m1_sh    <=  b"000" & cpSize_m1(13 downto 0) & b"0";
                        when others   =>  cpSize_m1_sh    <=  b"0000" & cpSize_m1(13 downto 0);
                    end case;
                end if;
            end process;
        end generate scstype_1;
        
        scstype_2 : if (SCSTYPE = 2) generate
            process(i_clk)
            begin
                if (rising_edge(i_clk)) then
                    case (r_fftType) is 
                        when b"00"    =>  cpSize_m1_sh    <=  b"00" & cpSize_m1(13 downto 0) & b"00";
                        when b"01"    =>  cpSize_m1_sh    <=  b"000" & cpSize_m1(13 downto 0) & b"0";
                        when b"10"    =>  cpSize_m1_sh    <=  b"0000" & cpSize_m1(13 downto 0);
                        when others   =>  cpSize_m1_sh    <=  b"00000" & cpSize_m1(13 downto 1);
                    end case;
                end if;
            end process;
        end generate scstype_2;
        
        scstype_3 : if (SCSTYPE = 3) generate
            process(i_clk)
            begin
                if (rising_edge(i_clk)) then
                    case (r_fftType) is 
                        when b"00"    =>  cpSize_m1_sh    <=  b"000" & cpSize_m1(13 downto 0) & b"0";
                        when b"01"    =>  cpSize_m1_sh    <=  b"0000" & cpSize_m1(13 downto 0);
                        when b"10"    =>  cpSize_m1_sh    <=  b"00000" & cpSize_m1(13 downto 1);
                        when others   =>  cpSize_m1_sh    <=  b"000000" & cpSize_m1(13 downto 2);
                    end case;
                end if;
            end process;
        end generate scstype_3;
        
        -- 4 clk
        expj14 : ulfe_lib_expj_v2 generic map('0',14) port map(i_clk, cpSize_m1_sh(13 downto 0), cos, sin);
        
        cos_d               <=  cos when (r_freqShiftOn = '1') else X"7FFF";
        sin_d               <=  sin when (r_freqShiftOn = '1') else X"0000";
        
        dly_data_i_8clk : ulfe_lib_dly_fixed generic map(7, 15) port map(i_clk, i_FREQSHIFT_i, i_FREQSHIFT_i_7d);
        dly_data_q_8clk : ulfe_lib_dly_fixed generic map(7, 15) port map(i_clk, i_FREQSHIFT_q, i_FREQSHIFT_q_7d);
        
        ----------------------------------------------------------------------------------------------------------------------------------------------------
        
        -- 6 clk
        C_multi : ulfe_lib_C_multi_v2 generic map(15,16,31) port map(i_clk, i_FREQSHIFT_i_7d, i_FREQSHIFT_q_7d, cos_d, sin_d, c_multi_data_i, c_multi_data_q);
        
        -- 3 clk
        r_sh_sym_sat_i : ylib_sshftd_sat generic map(31,15,15,"SYMMETRIC_ROUND","SYMMETRIC") port map(i_clk, '1', c_multi_data_i, open, o_FREQSHIFT_i);
        r_sh_sym_sat_q : ylib_sshftd_sat generic map(31,15,15,"SYMMETRIC_ROUND","SYMMETRIC") port map(i_clk, '1', c_multi_data_q, open, o_FREQSHIFT_q);
        
        F_SYNC_OUT : ulfe_lib_dly_fixed generic map(module_latency, 1) port map(i_clk	=> i_clk, data_i(0) => i_FREQSHIFT_sync, data_o(0) => o_FREQSHIFT_sync);
        VLD_OUT    : ulfe_lib_dly_fixed generic map(module_latency, NUM_RX_ANT) port map(i_clk, i_FREQSHIFT_vld, o_FREQSHIFT_vld);
        
        SAMPLE_CNT_OUT : ulfe_lib_dly_fixed generic map(module_latency-1, 13) port map(i_clk, sample_cnt, o_sample_cnt);
        CPSIZE_OUT     : ulfe_lib_dly_fixed generic map(module_latency-1, 12) port map(i_clk, cpSize, o_cp_size);
        
    end generate LTE_GEN;

end Behavioral;