-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2024, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2024.05.02 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_config_oru.all;
use work.ulfe_component_pack_oru.all;

entity ulfe_tdrssi_dbg_oru is
    generic (
        NUM_RX_ANT                          : integer := 2
    );
    Port(
        i_rst                               : in std_logic;
        i_clk                               : in std_logic;
        
        i_uin_sync                          : in std_logic;
        i_uin_vld                           : in std_logic_vector(NUM_RX_ANT-1 downto 0);
        i_uin_i                             : in std_logic_vector(15-1 downto 0);
        i_uin_q                             : in std_logic_vector(15-1 downto 0);
        
        i_fs_num                            : in std_logic_vector(5-1 downto 0);
        i_SR_info                           : in std_logic_vector(3-1 downto 0);
        i_tdd_sig                           : in std_logic;
        
        o_xssi                              : out std_logic_array32(NUM_RX_ANT-1 downto 0)
    );
end ulfe_tdrssi_dbg_oru;

architecture Behavioral of ulfe_tdrssi_dbg_oru is

    constant PWR_DSP_LATENCY                    : integer := 5;
    constant SUM_COUNT_NUM                      : integer := 2000;
    
    signal  r_SR_info                           : std_logic_vector(3-1 downto 0);
    signal  r_fs_num                            : std_logic_vector(5-1 downto 0);
    signal  sample_count                        : std_logic_vector(5-1 downto 0);
    signal	sum_count                           : std_logic_vector(12-1 downto 0);
    signal  sum_count_flag                      : std_logic;
    signal  sum_count_flag_1d                   : std_logic;
    
    signal  i_square                            : std_logic_vector(48-1 downto 0);
    signal  dsp_c                               : std_logic_vector(42-1 downto 0);
    signal  dsp_c_d                             : std_logic_vector(42-1 downto 0);
    
    signal  pwr_sum                             : std_logic_vector(42-1 downto 0);
    signal  pwr_sum_1d                          : std_logic_vector(42-1 downto 0);
    signal  pwr_sum_2d                          : std_logic_vector(42-1 downto 0);
    signal  pwr_sum_5d                          : std_logic_vector(42-1 downto 0);
    signal  pwr_sum_10d                         : std_logic_vector(42-1 downto 0);
    signal  pwr_sum_13d                         : std_logic_vector(42-1 downto 0);
    signal  pwr_sum_26d                         : std_logic_vector(42-1 downto 0);
    signal  pwr_sum_29d                         : std_logic_vector(42-1 downto 0);
    
    signal  i_uin_sync_reg                      : std_logic_vector(PWR_DSP_LATENCY+NUM_RX_ANT downto 0);
    
    signal  i_uin_i_1d                          : std_logic_vector(15-1 downto 0);
    signal  i_uin_q_1d                          : std_logic_vector(15-1 downto 0);
    signal  i_uin_q_2d                          : std_logic_vector(15-1 downto 0);
    
    signal  reg_select                          : std_logic;
    signal  reg_count_sig                       : std_logic;
    signal  reg_count_sig_cnt                   : std_logic_vector(5-1 downto 0);
    
    signal  ant_num                             : integer range 0 to NUM_RX_ANT-1;
    
    signal  pwr_sum_d                           : std_logic_vector(42-1 downto 0);
    signal  pwr_sum_vld                         : std_logic;
    signal  pwr_ant_sum                         : std_logic_array64(NUM_RX_ANT-1 downto 0);
    signal  pwr_ant_d                           : std_logic_array64(NUM_RX_ANT-1 downto 0);
    
    signal  data_in                             : std_logic_vector(64-1 downto 0);
    signal  pwr_ant_index                       : integer  range 0 to NUM_RX_ANT-1;
    signal  update_enable                       : std_logic;
    signal  end_enable                          : std_logic;

    signal  rssi                                : std_logic_vector(32-1 downto 0);

begin

    i_uin_sync_reg(0)                           <=  i_uin_sync;	
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            r_fs_num                                                    <=  i_fs_num;
            r_SR_info                                                   <=  i_SR_info;
            i_uin_sync_reg(PWR_DSP_LATENCY+NUM_RX_ANT downto 1)         <=  i_uin_sync_reg(PWR_DSP_LATENCY+NUM_RX_ANT-1 downto 0);
            
            if (i_uin_vld = 0 or i_tdd_sig = '0') then
                i_uin_i_1d                      <=  (others=>'0');
                i_uin_q_1d                      <=  (others=>'0');
            else
                i_uin_i_1d                      <=  i_uin_i;
                i_uin_q_1d                      <=  i_uin_q;
            end if;
            
            i_uin_q_2d                          <=  i_uin_q_1d;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if ((i_uin_sync_reg(PWR_DSP_LATENCY) = '1')) then
                sample_count                    <=  (others=>'0');
            elsif (sample_count = r_fs_num) then
                sample_count                    <=  (others=>'0');
            else
                sample_count                    <=  sample_count + '1';
            end if;
            
            if (i_uin_sync_reg(PWR_DSP_LATENCY) = '1' or (sum_count = conv_std_logic_vector(SUM_COUNT_NUM-1,12) and sample_count = r_fs_num)) then
                sum_count                       <=  (others=>'0');
            elsif (sample_count = r_fs_num) then
                sum_count                       <=  sum_count + '1';
            else
                sum_count                       <=  sum_count;
            end if;
            
            if (sum_count = conv_std_logic_vector(SUM_COUNT_NUM-1,12)) then
                sum_count_flag                  <=  '1';
            else
                sum_count_flag                  <=  '0';
            end if;
            
            sum_count_flag_1d                   <=  sum_count_flag;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_uin_sync_reg(PWR_DSP_LATENCY-2) = '1') then
                reg_count_sig                   <=  '0';
            elsif (r_SR_info = b"100" and (sum_count = conv_std_logic_vector(SUM_COUNT_NUM-2,12)) and sample_count = r_fs_num) then
                reg_count_sig                   <=  '0';
            elsif (r_SR_info /= b"100" and (sum_count = conv_std_logic_vector(SUM_COUNT_NUM-1,12)) and sample_count+2 = r_fs_num) then
                reg_count_sig                   <=  '0';
            elsif (reg_count_sig = '0' and reg_count_sig_cnt = r_fs_num) then
                reg_count_sig                   <=  '1';
            else
                reg_count_sig                   <=  reg_count_sig;
            end if;
            
            if (reg_count_sig = '0') then
                reg_count_sig_cnt               <=  reg_count_sig_cnt + '1';
            else
                reg_count_sig_cnt               <=  (others=>'0');
            end if;
        end if;
    end process;

    ------------------------------------------------------------------------------------------------------------------------------------------------------------------
    -- sum POWER
    
    reg_select                                  <=  '0' when (r_SR_info = b"101") else '1';
    -- i^2 + q^2 4clk
    stg0 : ulfe_lib_dsp_multi_add_v2 generic map('0',15,15,42,42) port map(i_clk, '0', '0', i_uin_i_1d, i_uin_i_1d, (others=>'0'), (others=>'0'), open, i_square);
    stg1 : ulfe_lib_dsp_multi_add_v2 generic map('1',15,15,42,42) port map(i_clk, reg_select, reg_count_sig, i_uin_q_2d, i_uin_q_2d, dsp_c_d, i_square, pwr_sum, open);
    
    dsp_c_d                <=  pwr_sum when (r_SR_info = b"100") else dsp_c;
    -- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            case (r_SR_info) is
                when b"000"  => dsp_c           <=  pwr_sum_29d;
                when b"001"  => dsp_c           <=  pwr_sum_13d;
                when b"010"  => dsp_c           <=  pwr_sum_5d;
                when b"011"  => dsp_c           <=  pwr_sum_1d;
                when b"100" =>  dsp_c           <=  pwr_sum;
                when others =>  dsp_c           <=  pwr_sum;
            end case;
        end if;
    end process;
    pwr_sum_dly_0 : ulfe_lib_dly_fixed generic map(1, 42) port map(i_clk, pwr_sum, pwr_sum_1d);
    pwr_sum_dly_1 : ulfe_lib_dly_fixed generic map(1, 42) port map(i_clk, pwr_sum_1d, pwr_sum_2d);
    
    MIN_SAMPLE_RATE_2 : if (MIN_SAMPLE_RATE = 2) generate
        pwr_sum_dly_2 : ulfe_lib_dly_fixed generic map(3, 42) port map(i_clk, pwr_sum_2d, pwr_sum_5d);
    end generate MIN_SAMPLE_RATE_2;
    
    MIN_SAMPLE_RATE_not_2 : if (MIN_SAMPLE_RATE > 2) generate
        pwr_sum_5d                              <=  (others=>'0');
    end generate MIN_SAMPLE_RATE_not_2;
    
    MIN_SAMPLE_RATE_1 : if (MIN_SAMPLE_RATE = 1) generate
        pwr_sum_dly_3 : ulfe_lib_dly_fixed generic map(5, 42) port map(i_clk, pwr_sum_5d, pwr_sum_10d);
        pwr_sum_dly_4 : ulfe_lib_dly_fixed generic map(3, 42) port map(i_clk, pwr_sum_10d, pwr_sum_13d);
    end generate MIN_SAMPLE_RATE_1;
    
    MIN_SAMPLE_RATE_not_1 : if (MIN_SAMPLE_RATE > 1) generate
        pwr_sum_10d                             <=  (others=>'0');
        pwr_sum_13d                             <=  (others=>'0');
    end generate MIN_SAMPLE_RATE_not_1;
    
    MIN_SAMPLE_RATE_0 : if (MIN_SAMPLE_RATE = 0) generate
        pwr_sum_dly_5 : ulfe_lib_dly_fixed generic map(13, 42) port map(i_clk, pwr_sum_13d, pwr_sum_26d);
        pwr_sum_dly_6 : ulfe_lib_dly_fixed generic map(3, 42) port map(i_clk, pwr_sum_26d, pwr_sum_29d);
    end generate MIN_SAMPLE_RATE_0;
    
    MIN_SAMPLE_RATE_not_0 : if (MIN_SAMPLE_RATE > 0) generate
        pwr_sum_26d                             <=  (others=>'0');
        pwr_sum_29d                             <=  (others=>'0');
    end generate MIN_SAMPLE_RATE_not_0;

    -----------------------------------------------------------------------------------------------------------------

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_uin_sync_reg(NUM_RX_ANT+4-1 downto 4) /= 0 and i_SR_info = b"100") then
                pwr_sum_vld                     <=  '1';
                pwr_sum_d                       <=  pwr_sum;
            elsif (i_uin_sync_reg(NUM_RX_ANT+2-1 downto 2) /= 0 and i_SR_info = b"011") then
                pwr_sum_vld                     <=  '1';
                pwr_sum_d                       <=  pwr_sum;
            elsif (i_uin_sync_reg(NUM_RX_ANT-1 downto 0) /= 0 and i_SR_info = b"010") then
                pwr_sum_vld                     <=  '1';
                pwr_sum_d                       <=  pwr_sum_2d;
            elsif (i_uin_sync_reg(NUM_RX_ANT-1 downto 0) /= 0 and i_SR_info = b"001") then
                pwr_sum_vld                     <=  '1';
                pwr_sum_d                       <=  pwr_sum_10d;
            elsif (i_uin_sync_reg(NUM_RX_ANT-1 downto 0) /= 0 and i_SR_info = b"000") then
                pwr_sum_vld                     <=  '1';
                pwr_sum_d                       <=  pwr_sum_26d;
            elsif (sum_count_flag_1d = '1') then
                pwr_sum_vld                     <=  '1';
                pwr_sum_d                       <=  pwr_sum_2d;
            else
                pwr_sum_vld                     <=  '0';
                pwr_sum_d                       <=  (others=>'0');
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (pwr_sum_vld = '1' and ant_num = NUM_RX_ANT-1) then
                ant_num                         <=  ant_num;
            elsif (pwr_sum_vld = '1') then
                ant_num                         <=  ant_num + 1;
            else
                ant_num                         <=  0;
            end if;
            
            if (i_uin_sync_reg(PWR_DSP_LATENCY+NUM_RX_ANT) = '1') then
                pwr_ant_sum                     <=  (others=>(others=>'0'));
            elsif (pwr_sum_vld = '1') then
                pwr_ant_sum(ant_num)            <=  pwr_ant_sum(ant_num) + (X"0000" & pwr_sum_d);
            else
                pwr_ant_sum                     <=  pwr_ant_sum;
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_uin_sync_reg(PWR_DSP_LATENCY+NUM_RX_ANT) = '1') then
                update_enable                   <=  '1';
                pwr_ant_d                       <=  pwr_ant_sum;
            elsif (end_enable = '1' and pwr_ant_index /= NUM_RX_ANT-1) then
                update_enable                   <=  '1';
                pwr_ant_d                       <=  pwr_ant_d;
            else
                update_enable                   <=  '0';
                pwr_ant_d                       <=  pwr_ant_d;
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_uin_sync_reg(PWR_DSP_LATENCY+NUM_RX_ANT) = '1' or (end_enable = '1' and pwr_ant_index = NUM_RX_ANT-1)) then
                pwr_ant_index                   <=  0;
            elsif (end_enable = '1') then
                pwr_ant_index                   <=  pwr_ant_index + 1;
            else
                pwr_ant_index                   <=  pwr_ant_index;
            end if;
        end if;
    end process;
    
    data_in                <=  pwr_ant_d(pwr_ant_index);
    FORMAT_CH : MANTISSA_FRAMER_modi port map(i_clk, update_enable, data_in, end_enable, rssi);
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (end_enable = '1') then
                o_xssi(pwr_ant_index)           <=  rssi;
            end if;
        end if;
    end process;

end Behavioral;