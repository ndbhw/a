-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2024, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2024.05.02 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_config_oru.all;

entity ulfe_param_proc_oru is
    Port (
        i_clk                           : in std_logic;
        
        i_fftType                       : in std_logic_vector(2-1 downto 0);
        
        o_fs_num                        : out std_logic_vector(5-1 downto 0);
        o_SR_info                       : out std_logic_vector(3-1 downto 0)    -- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76
    );
end ulfe_param_proc_oru;

architecture Behavioral of ulfe_param_proc_oru is

    signal  r_fftType                    : std_logic_vector(2-1 downto 0);

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            r_fftType                <=  i_fftType;
        end if;
    end process;

    -- SAMPLE_RATE ---------------------------------------
    -- SCS\FFT :   0(512)  1(1024) 2(2048) 3(4096)    ----
    -- 0( 15K)     7.68    15.36   30.72   61.44      ----
    -- 1( 30K)     15.36   30.72   61.44   122.88     ----
    -- 2( 60K)     30.72   61.44   122.88  245.76(X)  ----
    -- 3(120K)     61.44   122.88  245.76(x)          ----
    -- 4(240K)     122.88  245.76(x)                  ----
    ------------------------------------------------------

    -- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76
    
    SCSTYPE_0 : if (SCSTYPE = 0) generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                case (r_fftType) is 
                    when b"00"      =>  o_fs_num    <=  conv_std_logic_vector(32-1, 5); o_SR_info    <=  conv_std_logic_vector(0,3);
                    when b"01"      =>  o_fs_num    <=  conv_std_logic_vector(16-1, 5); o_SR_info    <=  conv_std_logic_vector(1,3);
                    when b"10"      =>  o_fs_num    <=  conv_std_logic_vector(8-1, 5);  o_SR_info    <=  conv_std_logic_vector(2,3);
                    when others     =>  o_fs_num    <=  conv_std_logic_vector(4-1, 5);  o_SR_info    <=  conv_std_logic_vector(3,3);
                end case;
            end if;
        end process;
    end generate SCSTYPE_0;
    
    SCSTYPE_1 : if (SCSTYPE = 1) generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                case (r_fftType) is 
                    when b"00"      =>  o_fs_num    <=  conv_std_logic_vector(16-1, 5); o_SR_info    <=  conv_std_logic_vector(1,3);
                    when b"01"      =>  o_fs_num    <=  conv_std_logic_vector(8-1, 5);  o_SR_info    <=  conv_std_logic_vector(2,3);
                    when b"10"      =>  o_fs_num    <=  conv_std_logic_vector(4-1, 5);  o_SR_info    <=  conv_std_logic_vector(3,3);
                    when others     =>  o_fs_num    <=  conv_std_logic_vector(2-1, 5);  o_SR_info    <=  conv_std_logic_vector(4,3);
                end case;
            end if;
        end process;
    end generate SCSTYPE_1;
    
    SCSTYPE_2 : if (SCSTYPE = 2) generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                case (r_fftType) is 
                    when b"00"      =>  o_fs_num    <=  conv_std_logic_vector(8-1, 5);  o_SR_info    <=  conv_std_logic_vector(2,3);
                    when b"01"      =>  o_fs_num    <=  conv_std_logic_vector(4-1, 5);  o_SR_info    <=  conv_std_logic_vector(3,3);
                    when b"10"      =>  o_fs_num    <=  conv_std_logic_vector(2-1, 5);  o_SR_info    <=  conv_std_logic_vector(4,3);
                    when others     =>  o_fs_num    <=  conv_std_logic_vector(1-1, 5);  o_SR_info    <=  conv_std_logic_vector(5,3);
                end case;
            end if;
        end process;
    end generate SCSTYPE_2;
    
    SCSTYPE_3 : if (SCSTYPE = 3) generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                case (r_fftType) is 
                    when b"00"      =>  o_fs_num    <=  conv_std_logic_vector(4-1, 5);  o_SR_info    <=  conv_std_logic_vector(3,3);
                    when b"01"      =>  o_fs_num    <=  conv_std_logic_vector(2-1, 5);  o_SR_info    <=  conv_std_logic_vector(4,3);
                    when others     =>  o_fs_num    <=  conv_std_logic_vector(1-1, 5);  o_SR_info    <=  conv_std_logic_vector(5,3);
                end case;
            end if;
        end process;
    end generate SCSTYPE_3;

end Behavioral;