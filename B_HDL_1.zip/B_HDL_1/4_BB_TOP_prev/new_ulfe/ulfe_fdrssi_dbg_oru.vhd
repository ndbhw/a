-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2024, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2024.05.02 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_func.all;
use work.ulfe_component_pack_oru.all;
use work.ulfe_config_oru.all;

entity ulfe_fdrssi_dbg_oru is
    generic (
        NUM_RX_ANT                              : integer := 8;
        NUM_PRE_PROCESSING                      : integer := 4;
        NUM_CHAIN_ANT                           : integer := 2
    );
    Port(
        i_rst                                   : in std_logic;
        i_clk                                   : in std_logic;
        
        i_uout_sync                             : in std_logic;
        i_uout_vld                              : in std_logic_vector(NUM_RX_ANT-1 downto 0);
        i_uout_iq                               : in std_logic_vector(NUM_RX_ANT*32-1 downto 0);
        
        i_tdd_sig                               : in std_logic;
        
        o_fdssi                                 : out std_logic_array32(NUM_RX_ANT-1 downto 0)
    );
end ulfe_fdrssi_dbg_oru;

architecture Behavioral of ulfe_fdrssi_dbg_oru is

    signal  ANT_NUM                                 : integer range 0 to NUM_CHAIN_ANT-1;
    
    signal  i_uout_sync_1d                          : std_logic;
    signal  i_uout_vld_4d                           : std_logic_vector(NUM_RX_ANT-1 downto 0);
    signal  i_uout_vld_5d                           : std_logic_vector(NUM_RX_ANT-1 downto 0);
    
    signal  i_uout_i_1d                             : std_logic_array16(NUM_PRE_PROCESSING-1 downto 0);
    signal  i_uout_q_1d                             : std_logic_array16(NUM_PRE_PROCESSING-1 downto 0);
    signal  i_uout_q_2d                             : std_logic_array16(NUM_PRE_PROCESSING-1 downto 0);
    signal  i_square                                : std_logic_array48(NUM_PRE_PROCESSING-1 downto 0);
    signal  pwr_sum                                 : std_logic_array42(NUM_PRE_PROCESSING-1 downto 0);
    signal  reg_count_sig                           : std_logic;
    signal  reg_count_sig_2d                        : std_logic;
    signal  reg_count_sig_3d                        : std_logic;
    
    signal  pwr_update_sig                          : std_logic;
    
    type std_logic_array_CANT_64                    is array(natural range <>) of std_logic_array64(NUM_CHAIN_ANT-1 downto 0);
    signal  pwr_ant_sum                             : std_logic_array_CANT_64(NUM_PRE_PROCESSING-1 downto 0);
    signal  pwr_ant_sum_d                           : std_logic_array_CANT_64(NUM_PRE_PROCESSING-1 downto 0);

begin

    Data_ARRANGE : for i in 0 to NUM_PRE_PROCESSING-1 generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                if (i_uout_vld = 0 or i_tdd_sig = '0') then
                    i_uout_i_1d(i)                      <=  (others=>'0');
                    i_uout_q_1d(i)                      <=  (others=>'0');
                else
                    i_uout_i_1d(i)                      <=  i_uout_iq((NUM_CHAIN_ANT*32*i)+32-1 downto (NUM_CHAIN_ANT*32*i)+16);
                    i_uout_q_1d(i)                      <=  i_uout_iq((NUM_CHAIN_ANT*32*i)+16-1 downto NUM_CHAIN_ANT*32*i);
                end if;
                
                i_uout_q_2d                             <=  i_uout_q_1d;
            end if;
        end process;
    end generate Data_ARRANGE;

    uout_vld_dly0 : ulfe_lib_dly_fixed generic map(4, NUM_RX_ANT) port map(i_clk, i_uout_vld, i_uout_vld_4d);
    uout_vld_dly1 : ulfe_lib_dly_fixed generic map(1, NUM_RX_ANT) port map(i_clk, i_uout_vld_4d, i_uout_vld_5d);

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_uout_sync = '1' or (i_uout_vld_5d /= 0 and i_uout_vld_4d = 0 and ANT_NUM = NUM_CHAIN_ANT-1)) then
                ANT_NUM                             <=  0;
            elsif (i_uout_vld_5d /= 0 and i_uout_vld_4d = 0) then
                ANT_NUM                             <=  ANT_NUM + 1;
            else
                ANT_NUM                             <=  ANT_NUM;
            end if;
            
            reg_count_sig                           <=  i_uout_vld(ANT_NUM);
        end if;
    end process;
    
    reg_count_sig_dly0 : ulfe_lib_dly_fixed generic map(2, 1) port map(i_clk => i_clk, data_i(0) => reg_count_sig, data_o(0) => reg_count_sig_2d);
    reg_count_sig_dly1 : ulfe_lib_dly_fixed generic map(1, 1) port map(i_clk => i_clk, data_i(0) => reg_count_sig_2d, data_o(0) => reg_count_sig_3d);
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (reg_count_sig_3d = '1' and reg_count_sig_2d = '0') then
                pwr_update_sig                      <=  '1';
            else
                pwr_update_sig                      <=  '0';
            end if;
        end if;
    end process;
    
    I2_Q2_SUM : for i in 0 to NUM_PRE_PROCESSING-1 generate
        -- i^2 + q^2 4clk
        stg0 : ulfe_lib_dsp_multi_add_v2 generic map('0',16,16,42,42) port map(i_clk, '0', '0', i_uout_i_1d(i), i_uout_i_1d(i), (others=>'0'), (others=>'0'), open, i_square(i));
        stg1 : ulfe_lib_dsp_multi_add_v2 generic map('1',16,16,42,42) port map(i_clk, '0', reg_count_sig_2d, i_uout_q_2d(i), i_uout_q_2d(i), (others=>'0'), i_square(i), pwr_sum(i), open);
        
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                if (i_uout_sync = '1') then
                    pwr_ant_sum(i)                  <=  (others=>(others=>'0'));
                elsif (pwr_update_sig = '1') then
                    pwr_ant_sum(i)(ANT_NUM)         <=  pwr_ant_sum(i)(ANT_NUM) + (X"0000" & pwr_sum(i));
                else
                    pwr_ant_sum                     <=  pwr_ant_sum;
                end if;
            end if;
        end process;
        
    end generate I2_Q2_SUM;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_uout_sync = '1') then
                pwr_ant_sum_d                       <=  pwr_ant_sum;
            else
                pwr_ant_sum_d                       <=  pwr_ant_sum_d;
            end if;
        end if;
    end process;
    
    fsync_dly : ulfe_lib_dly_fixed generic map(1, 1) port map(i_clk => i_clk, data_i(0) => i_uout_sync, data_o(0) => i_uout_sync_1d);
    
    MANTISSA_FORMAT_ST0 : for i in 0 to NUM_PRE_PROCESSING-1 generate
        MANTISSA_FORMAT_ST1 : for q in 0 to NUM_CHAIN_ANT-1 generate
            format_ch : MANTISSA_FRAMER_modi port map(i_clk, i_uout_sync_1d, pwr_ant_sum_d(i)(q), open, o_fdssi(i*NUM_CHAIN_ANT+q));
        end generate MANTISSA_FORMAT_ST1;
    end generate MANTISSA_FORMAT_ST0;

end Behavioral;