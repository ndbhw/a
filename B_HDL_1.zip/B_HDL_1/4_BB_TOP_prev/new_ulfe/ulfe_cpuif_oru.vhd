-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2024, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2024.05.02 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_func.all;
use work.ulfe_component_pack_oru.all;
use work.ulfe_config_oru.all;

entity ulfe_cpuif_oru is
    Generic(
        NUM_PRE_PROCESSING                      : integer := 1;
        NUM_ANT                                 : integer := 4;
        CHAIN_ANT_NUM                           : integer := 2;
        CPUIF_BB_ADDR_BW                        : integer := 16;
        ADDR_OFFSET                             : std_logic_vector(16-1 downto 0) := X"1400"
    );
    Port(
        i_rst                                   : in std_logic;
        i_clk                                   : in std_logic;
        
        i_cpuif_addr                            : in std_logic_vector(CPUIF_BB_ADDR_BW-1 downto 0);
        i_cpuif_wt_en                           : in std_logic_vector(0 downto 0);
        i_cpuif_wt_data                         : in std_logic_vector(32-1 downto 0);
        i_cpuif_rd_en                           : in std_logic_vector(0 downto 0);
        o_cpuif_rd_data                         : out std_logic_vector(32-1 downto 0);
        o_cpuif_rd_vld                          : out std_logic_vector(0 downto 0);
        
        o_par_freqShiftOn                       : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
        o_par_cpRm_Offset                       : out std_logic_array11(NUM_PRE_PROCESSING-1 downto 0);
        o_par_tagcOn                            : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
        o_par_tagcBackoff                       : out std_logic_array5(NUM_PRE_PROCESSING-1 downto 0);
        o_par_k0                                : out std_logic_array12(NUM_PRE_PROCESSING-1 downto 0);
        o_par_rbSize                            : out std_logic_array9(NUM_PRE_PROCESSING-1 downto 0);
        o_par_gainCompOn                        : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
        o_par_ctsOn                             : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
        o_par_ctsShift                          : out std_logic_array12(NUM_PRE_PROCESSING-1 downto 0);
        o_par_phaseCompOn                       : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
        o_par_fftType                           : out std_logic_array2(NUM_PRE_PROCESSING-1 downto 0);
        o_par_scsType                           : out std_logic_array2(NUM_PRE_PROCESSING-1 downto 0);
        
        o_tdrssi_StartSlotIdx                   : out std_logic_vector(7-1 downto 0);
        o_tdrssi_StartSymbIdx                   : out std_logic_vector(4-1 downto 0);
        o_tdrssi_SymbSize                       : out std_logic_vector(6-1 downto 0);
        o_tdrssi_Trigger                        : out std_logic;
        o_tdrssi_SelSymbIdx_rpt                 : out std_logic_vector(6-1 downto 0);
        
        i_tdrssi_rpt_done                       : in std_logic;
        i_tdrssi_rpt_data                       : in std_logic_array32(NUM_ANT-1 downto 0);
        i_tdrssi_dbg_data                       : in std_logic_array32(NUM_ANT-1 downto 0);
        i_fdrssi_dbg_data                       : in std_logic_array32(NUM_ANT-1 downto 0);
        
        o_par_calOn                             : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
        o_par_calWscale                         : out std_logic_array4(NUM_PRE_PROCESSING-1 downto 0);
        
        o_calW_rd_wt_sel                        : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
        o_sel_calw_rx                           : out std_logic_array6(NUM_PRE_PROCESSING-1 downto 0);
        o_calW_wt_buf                           : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
        o_calW_wt_en                            : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
        o_calw_wt_rb_num                        : out std_logic_array9(NUM_PRE_PROCESSING-1 downto 0);
        o_calW_wt_data                          : out std_logic_array24(NUM_PRE_PROCESSING-1 downto 0);
        i_calW_rd_data                          : in std_logic_vector(24-1 downto 0);
        
        i_PHASECOMP_sync_adv_5clk               : in std_logic;
        i_PHASECOMP_vld                         : in std_logic_vector(CHAIN_ANT_NUM-1 downto 0);
        
        o_par_phaseI                            : out std_logic_array16(NUM_PRE_PROCESSING-1 downto 0);
        o_par_phaseQ                            : out std_logic_array16(NUM_PRE_PROCESSING-1 downto 0);
        
        i_fft_rst_count                         : in std_logic_vector(8-1 downto 0);
        i_in_10ms_sync                          : in std_logic;
        i_out_10ms_sync                         : in std_logic;
        i_in_frame_idx                          : in std_logic_vector(8-1 downto 0);
        
        o_dump_td_fd                            : out std_logic;
        o_dump_Trigger                          : out std_logic;
        o_dump_frame                            : out std_logic_vector(2-1 downto 0);
        o_dump_ant                              : out std_logic_vector(3-1 downto 0);
        o_dump_slot                             : out std_logic_vector(6-1 downto 0);
        o_dump_symbol                           : out std_logic_vector(4-1 downto 0);
        
        o_dump_rd_buf                           : out std_logic_vector(4-1 downto 0);
        o_dump_rd_addr                          : out std_logic_vector(16-1 downto 0);
        i_dump_rd_data                          : in std_logic_vector(64-1 downto 0);
        i_dump_done                             : in std_logic;
        
        i_tdd_signal_count_adv                  : in std_logic_vector(22-1 downto 0);
        i_cal_enable_front                      : in std_logic;
        i_cal_enable_end                        : in std_logic;
        o_bypass_set_reg                        : out std_logic;
        
        o_fsync_err_flag                        : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0)
    );
end ulfe_cpuif_oru;

architecture Behavioral of ulfe_cpuif_oru is

    constant MAX_NUM_ANT                            : integer := 4;
    constant RD_REG_DLY                             : integer := 3;
    constant ULFE_START_ADDR                        : std_logic_vector(16-1 downto 0) := X"0010";
    constant ULFE_END_ADDR                          : std_logic_vector(16-1 downto 0) := X"0D00";
    constant PHASE_START_ADDR                       : std_logic_vector(16-1 downto 0) := X"0180";
    constant PHASE_LAST_ADDR                        : std_logic_vector(16-1 downto 0) := PHASE_START_ADDR + conv_std_logic_vector((14*(2**SCSTYPE)-1),16);
    constant CAL_ADDR_OFFSET                        : std_logic_vector(16-1 downto 0) := X"0303";
    constant CAL_LAST_ADDR                          : std_logic_vector(16-1 downto 0) := X"0413";
    constant DUMP_START_ADDR                        : std_logic_vector(16-1 downto 0) := X"0860";
    constant DUMP_LAST_ADDR                         : std_logic_vector(16-1 downto 0) := X"0C5F";
    
    constant MEM_LATENCY                            : integer := 2;
    constant MEM_D_WIDTH                            : integer := 32;
    constant MEM_DEPTH                              : integer := 14*(2**(SCSTYPE));
    
    signal  r_cpu_addr                              : std_logic_vector(CPUIF_BB_ADDR_BW-1 downto 0);
    signal  r_cpu_wren                              : std_logic_vector(0 downto 0);
    signal  r_cpu_wdata                             : std_logic_vector(32-1 downto 0);
    signal  r_cpu_rden                              : std_logic_vector(0 downto 0);
    signal  r_cpu_rden_reg                          : std_logic_vector(RD_REG_DLY-1 downto 0);
    signal  cpuif_rd_vld                            : std_logic;
    signal  cpuif_rd_data                           : std_logic_vector(32-1 downto 0);
    
    signal  par_freqShiftOn                         : std_logic;
    signal  par_cpRm_Offset                         : std_logic_vector(11-1 downto 0);
    signal  par_tagcOn                              : std_logic;
    signal  par_tagcBackoff                         : std_logic_vector(5-1 downto 0);
    signal  par_k0                                  : std_logic_vector(12-1 downto 0);
    signal  par_rbSize                              : std_logic_vector(9-1 downto 0);
    signal  par_gainCompOn                          : std_logic;
    signal  par_ctsOn                               : std_logic;
    signal  par_ctsShift                            : std_logic_vector(12-1 downto 0);
    signal  par_phaseCompOn                         : std_logic;
    signal  par_fftType                             : std_logic_vector(2-1 downto 0);
    signal  par_scsType                             : std_logic_vector(2-1 downto 0);
    signal  par_phaseI                              : std_logic_vector(16-1 downto 0);
    signal  par_phaseQ                              : std_logic_vector(16-1 downto 0);
    
    signal  tdrssi_StartSlotIdx                     : std_logic_vector(7-1 downto 0);
    signal  tdrssi_StartSymbIdx                     : std_logic_vector(4-1 downto 0);
    signal  tdrssi_SymbSize                         : std_logic_vector(6-1 downto 0);
    signal  tdrssi_Trigger                          : std_logic;
    signal  tdrssi_SelSymbIdx_rpt                   : std_logic_vector(6-1 downto 0);
    
    signal  par_calOn                               : std_logic;
    signal  par_calWscale                           : std_logic_vector(4-1 downto 0);
    signal  sel_calw_rx                             : std_logic_vector(6-1 downto 0);
    signal  calW_buf_sel                            : std_logic;
    signal  calW_rd_wt_sel                          : std_logic;
    signal  calW_wt_en                              : std_logic;
    signal  calW_wt_en_1d                           : std_logic;
    signal  calW_wt_enable                          : std_logic;
    signal  calw_wt_rb_num                          : std_logic_vector(16-1 downto 0);
    signal  calW_wt_data                            : std_logic_vector(24-1 downto 0);
    
    signal  phase_weight_wt_en                      : std_logic;
    signal  phase_weight_wt_en_1d                   : std_logic;
    signal  phase_weight_wt_enable                  : std_logic;
    signal  phase_weight_wt_addr                    : std_logic_vector(16-1 downto 0);
    signal  phase_weight_wt_data                    : std_logic_vector(32-1 downto 0);
    signal  phase_weight_rd_data_a                  : std_logic_vector(32-1 downto 0);
    
    signal  i_PHASECOMP_vld_1d                      : std_logic;
    signal  phase_weight_rd_addr                    : std_logic_vector(log2ceil(14*(2**(SCSTYPE)))-1 downto 0);
    signal  phase_weight_rd_data                    : std_logic_vector(32-1 downto 0);
    
    signal  r_tdrssi_rpt_data                       : std_logic_array32(MAX_NUM_ANT-1 downto 0) := (others=>(others=>'0'));
    signal  r_tdrssi_dbg_data                       : std_logic_array32(MAX_NUM_ANT-1 downto 0) := (others=>(others=>'0'));
    signal  r_fdrssi_dbg_data                       : std_logic_array32(MAX_NUM_ANT-1 downto 0) := (others=>(others=>'0'));
    
    signal  in_sync_cnt                             : std_logic_vector(8-1 downto 0);
    signal  out_sync_cnt                            : std_logic_vector(8-1 downto 0);
    signal  err_pre_frame_idx                       : std_logic_vector(8-1 downto 0);
    signal  err_cur_frame_idx                       : std_logic_vector(8-1 downto 0);
    signal  cur_frame_idx                           : std_logic_vector(8-1 downto 0);
    
    constant sync_err_range                         : integer := 1;
    constant minus_2457600                          : std_logic_vector := conv_std_logic_vector(2457599-sync_err_range,22);
    constant plus_2457600                           : std_logic_vector := conv_std_logic_vector(2457599+sync_err_range,22);
    signal  sync_period_cnt                         : std_logic_vector(22-1 downto 0);
    signal  sync_err_cnt                            : std_logic_vector(8-1 downto 0);
    
    signal  dump_td_fd                              : std_logic;
    signal  dump_Trigger                            : std_logic;
    signal  dump_frame                              : std_logic_vector(2-1 downto 0);
    signal  dump_ant                                : std_logic_vector(3-1 downto 0);
    signal  dump_slot                               : std_logic_vector(6-1 downto 0);
    signal  dump_symbol                             : std_logic_vector(4-1 downto 0);

    signal  dump_rd_buf                             : std_logic_vector(4-1 downto 0);
    signal  dump_rd_addr                            : std_logic_vector(16-1 downto 0);
    
    signal  i_in_10ms_sync_1d                       : std_logic;
    
    signal  i_cal_enable_front_1d                   : std_logic;
    signal  i_cal_enable_end_1d                     : std_logic;
    signal  cal_en_cnt                              : std_logic_vector(22-1 downto 0);
    signal  cal_en_f_cnt_d                          : std_logic_vector(22-1 downto 0);
    signal  cal_en_e_cnt_d                          : std_logic_vector(22-1 downto 0);
    signal  bypass_set_reg                          : std_logic;
    
    signal  fsync_err_flag                          : std_logic;
    
    attribute MAX_FANOUT : integer;
    attribute MAX_FANOUT of r_cpu_addr : signal is 10;

begin

    ----------------------------------------------------------------------------------------------------
    -- output
    
    GEN_NUM_PRE_PROCESSING : for i in 0 to NUM_PRE_PROCESSING-1 generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                o_par_freqShiftOn(i)                        <=  par_freqShiftOn;
                o_par_cpRm_Offset(i)                        <=  par_cpRm_Offset;
                o_par_tagcOn(i)                             <=  par_tagcOn;
                o_par_tagcBackoff(i)                        <=  par_tagcBackoff;
                o_par_k0(i)                                 <=  par_k0;
                o_par_rbSize(i)                             <=  par_rbSize;
                o_par_gainCompOn(i)                         <=  par_gainCompOn;
                o_par_ctsOn(i)                              <=  par_ctsOn;
                o_par_ctsShift(i)                           <=  par_ctsShift;
                o_par_phaseCompOn(i)                        <=  par_phaseCompOn;
                o_par_fftType(i)                            <=  par_fftType;
                o_par_scsType(i)                            <=  par_scsType;
                
                o_par_calOn(i)                              <=  par_calOn;
                o_par_calWscale(i)                          <=  par_calWscale;
                
                o_calW_rd_wt_sel(i)                         <=  calW_rd_wt_sel;
                o_sel_calw_rx(i)                            <=  sel_calw_rx;
                o_calW_wt_buf(i)                            <=  calW_buf_sel;
                o_calW_wt_en(i)                             <=  calW_wt_enable;
                o_calw_wt_rb_num(i)                         <=  calw_wt_rb_num(8 downto 0);
                o_calW_wt_data(i)                           <=  calW_wt_data;
                
                o_par_phaseI(i)                             <=  par_phaseI;
                o_par_phaseQ(i)                             <=  par_phaseQ;
                
                o_fsync_err_flag(i)                         <=  fsync_err_flag;
            end if;
        end process;
    end generate GEN_NUM_PRE_PROCESSING;

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            o_bypass_set_reg                                <=  bypass_set_reg;
        end if;
    end process;

    o_tdrssi_StartSlotIdx                       <=  tdrssi_StartSlotIdx;
    o_tdrssi_StartSymbIdx                       <=  tdrssi_StartSymbIdx;
    o_tdrssi_SymbSize                           <=  tdrssi_SymbSize;
    o_tdrssi_Trigger                            <=  tdrssi_Trigger;
    o_tdrssi_SelSymbIdx_rpt                     <=  tdrssi_SelSymbIdx_rpt;
    
    o_dump_td_fd                                <=  dump_td_fd;
    o_dump_Trigger                              <=  dump_Trigger;
    o_dump_frame                                <=  dump_frame;
    o_dump_ant                                  <=  dump_ant;
    o_dump_slot                                 <=  dump_slot;
    o_dump_symbol                               <=  dump_symbol;
    
    o_dump_rd_buf                               <=  dump_rd_buf;
    o_dump_rd_addr                              <=  dump_rd_addr;

    ----------------------------------------------------------------------------------------------------

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            r_cpu_addr                              <=  i_cpuif_addr - ADDR_OFFSET;
            r_cpu_wren                              <=  i_cpuif_wt_en;
            r_cpu_wdata                             <=  i_cpuif_wt_data;
            r_cpu_rden                              <=  i_cpuif_rd_en;
 
            dump_rd_addr                            <=  i_cpuif_addr - (DUMP_START_ADDR + ADDR_OFFSET);
        end if;
    end process;
    ----------------------------------------------------------------------------------------------------
    -- PARAMETER WRITE
    
    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            par_tagcOn                              <=  '1';
            par_k0                                  <=  (others=>'0');
            par_gainCompOn                          <=  '1';
            par_ctsOn                               <=  '1';
            par_calWscale                           <=  X"8";
            bypass_set_reg                          <=  '1';
            
        elsif (rising_edge(i_clk)) then
            if (r_cpu_wren(0) = '1') then
                case (r_cpu_addr(15 downto 0)) is
                    when X"0080" =>  par_freqShiftOn            <=  r_cpu_wdata(0);
                    when X"0082" =>  par_cpRm_Offset            <=  r_cpu_wdata(10 downto 0);
                    when X"0083" =>  par_tagcOn                 <=  r_cpu_wdata(0);
                    when X"0084" =>  par_tagcBackoff            <=  r_cpu_wdata(4 downto 0);
                    when X"0085" =>  par_k0                     <=  r_cpu_wdata(11 downto 0);
                    when X"0086" =>  par_rbSize                 <=  r_cpu_wdata(8 downto 0);
                    when X"0087" =>  par_gainCompOn             <=  r_cpu_wdata(0);
                    when X"0088" =>  par_ctsOn                  <=  r_cpu_wdata(0);
                    when X"0089" =>  par_ctsShift               <=  r_cpu_wdata(11 downto 0);
                    when X"008A" =>  par_phaseCompOn            <=  r_cpu_wdata(0);
                    when X"008B" =>  par_fftType                <=  r_cpu_wdata(5 downto 4);
                                     par_scsType                <=  r_cpu_wdata(1 downto 0);
                    when X"008E" =>  tdrssi_StartSlotIdx        <=  r_cpu_wdata(6 downto 0);
                    when X"008F" =>  tdrssi_StartSymbIdx        <=  r_cpu_wdata(3 downto 0);
                    when X"0090" =>  tdrssi_SymbSize            <=  r_cpu_wdata(5 downto 0);
                    when X"0091" =>  tdrssi_Trigger             <=  r_cpu_wdata(0);
                    when X"0092" =>  tdrssi_SelSymbIdx_rpt      <=  r_cpu_wdata(5 downto 0);
                    when X"0300" =>  par_calOn                  <=  r_cpu_wdata(0);
                    when X"0301" =>  par_calWscale              <=  r_cpu_wdata(3 downto 0);
                    when X"0302" =>  sel_calw_rx                <=  r_cpu_wdata(5 downto 0);
                    when X"0414" =>  calW_buf_sel               <=  r_cpu_wdata(0);
                    when X"0415" =>  calW_rd_wt_sel             <=  r_cpu_wdata(0);
                    
                    when X"0512" =>  dump_Trigger               <=  r_cpu_wdata(0);
                    when X"0513" =>  dump_frame                 <=  r_cpu_wdata(1 downto 0);
                    when X"0514" =>  dump_ant                   <=  r_cpu_wdata(2 downto 0);
                    when X"0515" =>  dump_slot                  <=  r_cpu_wdata(5 downto 0);
                    when X"0516" =>  dump_symbol                <=  r_cpu_wdata(3 downto 0);
                    when X"0517" =>  dump_td_fd                 <=  r_cpu_wdata(0);
                  
                    when X"051B" =>  bypass_set_reg             <=  r_cpu_wdata(0);
                    
                    when X"051C" =>  dump_rd_buf                <=  r_cpu_wdata(3 downto 0);
                    
                    when others => NULL;
                end case;
            end if;
        end if;
    end process;
    
    ----------------------------------------------------------------------------------------------------
    -- PHASE WEIGHT WRITE
    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            phase_weight_wt_en                      <=  '0';
            phase_weight_wt_en_1d                   <=  '0';
            phase_weight_wt_addr                    <=  (others=>'0');
            
        elsif (rising_edge(i_clk)) then
            if (r_cpu_wren(0) = '1' and (r_cpu_addr(15 downto 0) >= PHASE_START_ADDR and r_cpu_addr(15 downto 0) <= PHASE_LAST_ADDR)) then
                phase_weight_wt_en                  <=  '1';
            else
                phase_weight_wt_en                  <=  '0';
            end if;
            phase_weight_wt_en_1d                   <=  phase_weight_wt_en;
            
            if (phase_weight_wt_en_1d = '0' and phase_weight_wt_en = '1') then
                phase_weight_wt_enable              <=  '1';
            else
                phase_weight_wt_enable              <=  '0';
            end if;
            
            phase_weight_wt_addr                    <=  r_cpu_addr(15 downto 0) - PHASE_START_ADDR;
            phase_weight_wt_data                    <=  r_cpu_wdata;
        end if;
    end process;
    
    PHASE_WEIGHT : ulfe_lib_tdpram_distribute generic map("distributed",MEM_LATENCY,MEM_D_WIDTH,MEM_D_WIDTH,MEM_DEPTH,MEM_DEPTH)
    port map(i_clk, phase_weight_wt_enable, phase_weight_wt_addr(log2ceil(14*(2**(SCSTYPE)))-1 downto 0), phase_weight_wt_data, phase_weight_rd_data_a, phase_weight_rd_addr, phase_weight_rd_data);
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            i_PHASECOMP_vld_1d                      <=  i_PHASECOMP_vld(CHAIN_ANT_NUM-1);
            if (i_PHASECOMP_sync_adv_5clk = '1' or (i_PHASECOMP_vld_1d = '1' and i_PHASECOMP_vld(CHAIN_ANT_NUM-1) = '0' and phase_weight_rd_addr = conv_std_logic_vector(14*(2**(SCSTYPE))-1, log2ceil(14*(2**(SCSTYPE)))))) then
                phase_weight_rd_addr                <=  (others=>'0');
            elsif (i_PHASECOMP_vld_1d = '1' and i_PHASECOMP_vld(CHAIN_ANT_NUM-1) = '0') then
                phase_weight_rd_addr                <=  phase_weight_rd_addr + '1';
            else
                phase_weight_rd_addr                <=  phase_weight_rd_addr;
            end if;
            
            par_phaseI                              <=  phase_weight_rd_data(31 downto 16);
            par_phaseQ                              <=  phase_weight_rd_data(15 downto 0);
        end if;
    end process;

    ----------------------------------------------------------------------------------------------------
    -- CAL WEIGHT WRITE
    CALB_TRUE : if (CALB_MODULE = TRUE) generate
        process(i_rst, i_clk)
        begin
            if (i_rst = '1') then
                calW_wt_en                          <=  '0';
                calW_wt_en_1d                       <=  '0';
                calw_wt_rb_num                      <=  (others=>'1');
                calW_wt_data                        <=  (others=>'0');
            elsif (rising_edge(i_clk)) then
                if (r_cpu_wren(0) = '1' and (r_cpu_addr(15 downto 0) >= CAL_ADDR_OFFSET and r_cpu_addr(15 downto 0) <= CAL_LAST_ADDR)) then
                    calW_wt_en                      <=  '1';
                else
                    calW_wt_en                      <=  '0';
                end if;
                calW_wt_en_1d                       <=  calW_wt_en;
                
                if (calW_wt_en_1d = '0' and calW_wt_en = '1') then
                    calW_wt_enable                  <=  '1';
                else
                    calW_wt_enable                  <=  '0';
                end if;
                
                calw_wt_rb_num                      <=  r_cpu_addr(15 downto 0) - CAL_ADDR_OFFSET;
                calW_wt_data                        <=  r_cpu_wdata(27 downto 16) & r_cpu_wdata(11 downto 0);
            end if;
        end process;
    end generate CALB_TRUE;

    ----------------------------------------------------------------------------------------------------
    -- read
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            r_cpu_rden_reg                          <=  r_cpu_rden_reg(RD_REG_DLY-2 downto 0) & r_cpu_rden(0);
            cpuif_rd_vld                            <=  r_cpu_rden_reg(RD_REG_DLY-1);
            
            r_tdrssi_rpt_data(NUM_ANT-1 downto 0)   <=  i_tdrssi_rpt_data;
            r_tdrssi_dbg_data(NUM_ANT-1 downto 0)   <=  i_tdrssi_dbg_data;
            r_fdrssi_dbg_data(NUM_ANT-1 downto 0)   <=  i_fdrssi_dbg_data;
        end if;
    end process;

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            case (r_cpu_addr(15 downto 0)) is
                when X"0080" =>  cpuif_rd_data  <=  X"0000000" & b"000" & par_freqShiftOn;
                when X"0082" =>  cpuif_rd_data  <=  X"00000" & b"0" & par_cpRm_Offset;
                when X"0083" =>  cpuif_rd_data  <=  X"0000000" & b"000" & par_tagcOn;
                when X"0084" =>  cpuif_rd_data  <=  X"000000" & b"000" & par_tagcBackoff;
                when X"0085" =>  cpuif_rd_data  <=  X"00000" & par_k0;
                when X"0086" =>  cpuif_rd_data  <=  X"00000" & b"000" & par_rbSize;
                when X"0087" =>  cpuif_rd_data  <=  X"0000000" & b"000" & par_gainCompOn;
                when X"0088" =>  cpuif_rd_data  <=  X"0000000" & b"000" & par_ctsOn;
                when X"0089" =>  cpuif_rd_data  <=  X"00000" & par_ctsShift;
                when X"008A" =>  cpuif_rd_data  <=  X"0000000" & b"000" & par_phaseCompOn;
                when X"008B" =>  cpuif_rd_data  <=  X"000000" & b"00" & par_fftType & b"00" & par_scsType;
                
                when X"008E" =>  cpuif_rd_data  <=  X"000000" & b"0" & tdrssi_StartSlotIdx;
                when X"008F" =>  cpuif_rd_data  <=  X"0000000" & tdrssi_StartSymbIdx;
                when X"0090" =>  cpuif_rd_data  <=  X"000000" & b"00" & tdrssi_SymbSize;
                when X"0091" =>  cpuif_rd_data  <=  X"0000000" & b"000" & tdrssi_Trigger;
                when X"0092" =>  cpuif_rd_data  <=  X"000000" & b"00" & tdrssi_SelSymbIdx_rpt;
                when X"0093" =>  cpuif_rd_data  <=  X"0000000" & b"000" & i_tdrssi_rpt_done;
                
                when X"0094" =>  cpuif_rd_data  <=  r_tdrssi_rpt_data(0);
                when X"0095" =>  cpuif_rd_data  <=  r_tdrssi_rpt_data(1);
                when X"0096" =>  cpuif_rd_data  <=  r_tdrssi_rpt_data(2);
                when X"0097" =>  cpuif_rd_data  <=  r_tdrssi_rpt_data(3);
                -- when X"0098" =>  cpuif_rd_data  <=  r_tdrssi_rpt_data(4);
                -- when X"0099" =>  cpuif_rd_data  <=  r_tdrssi_rpt_data(5);
                -- when X"009A" =>  cpuif_rd_data  <=  r_tdrssi_rpt_data(6);
                -- when X"009B" =>  cpuif_rd_data  <=  r_tdrssi_rpt_data(7);
                
                when X"0300" =>  cpuif_rd_data  <=  X"0000000" & b"000" & par_calOn;
                when X"0301" =>  cpuif_rd_data  <=  X"0000000" & par_calWscale;
                when X"0302" =>  cpuif_rd_data  <=  X"000000" & b"00" & sel_calw_rx;
                when X"0414" =>  cpuif_rd_data  <=  X"0000000" & b"000" & calW_buf_sel;
                when X"0415" =>  cpuif_rd_data  <=  X"0000000" & b"000" & calW_rd_wt_sel;
                
                when X"0500" =>  cpuif_rd_data  <=  r_tdrssi_dbg_data(0);
                when X"0501" =>  cpuif_rd_data  <=  r_tdrssi_dbg_data(1);
                when X"0502" =>  cpuif_rd_data  <=  r_tdrssi_dbg_data(2);
                when X"0503" =>  cpuif_rd_data  <=  r_tdrssi_dbg_data(3);
                -- when X"0504" =>  cpuif_rd_data  <=  r_tdrssi_dbg_data(4);
                -- when X"0505" =>  cpuif_rd_data  <=  r_tdrssi_dbg_data(5);
                -- when X"0506" =>  cpuif_rd_data  <=  r_tdrssi_dbg_data(6);
                -- when X"0507" =>  cpuif_rd_data  <=  r_tdrssi_dbg_data(7);
                when X"0508" =>  cpuif_rd_data  <=  r_fdrssi_dbg_data(0);
                when X"0509" =>  cpuif_rd_data  <=  r_fdrssi_dbg_data(1);
                when X"050A" =>  cpuif_rd_data  <=  r_fdrssi_dbg_data(2);
                when X"050B" =>  cpuif_rd_data  <=  r_fdrssi_dbg_data(3);
                -- when X"050C" =>  cpuif_rd_data  <=  r_fdrssi_dbg_data(4);
                -- when X"050D" =>  cpuif_rd_data  <=  r_fdrssi_dbg_data(5);
                -- when X"050E" =>  cpuif_rd_data  <=  r_fdrssi_dbg_data(6);
                -- when X"050F" =>  cpuif_rd_data  <=  r_fdrssi_dbg_data(7);
                
                when X"0510" =>  cpuif_rd_data  <=  VERSION & sync_err_cnt & err_pre_frame_idx & err_cur_frame_idx;
                when X"0511" =>  cpuif_rd_data  <=  in_sync_cnt & out_sync_cnt & i_in_frame_idx & i_fft_rst_count;
                
                when X"0512" =>  cpuif_rd_data  <=  X"000" & b"000" & i_dump_done & X"000" & b"000" & dump_Trigger;
                when X"0513" =>  cpuif_rd_data  <=  X"0000000" & b"00" & dump_frame;
                when X"0514" =>  cpuif_rd_data  <=  X"0000000" & b"0" & dump_ant;
                when X"0515" =>  cpuif_rd_data  <=  X"000000" & b"00" & dump_slot;
                when X"0516" =>  cpuif_rd_data  <=  X"0000000" & dump_symbol;
                when X"0517" =>  cpuif_rd_data  <=  X"0000000" & b"000" & dump_td_fd;
                
                when X"0518" =>  cpuif_rd_data  <=  X"00" & b"00" & i_tdd_signal_count_adv;
                when X"0519" =>  cpuif_rd_data  <=  X"00" & b"00" & cal_en_f_cnt_d;
                when X"051A" =>  cpuif_rd_data  <=  X"00" & b"00" & cal_en_e_cnt_d;
                when X"051B" =>  cpuif_rd_data  <=  X"0000000" & b"000" & bypass_set_reg;

                when X"051C" =>  cpuif_rd_data  <=  X"0000000" & dump_rd_buf;
                
                when others  =>  cpuif_rd_data  <=  X"DEADDEAD";
            end case;
        end if;
    end process;

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (r_cpu_addr(15 downto 0) >= PHASE_START_ADDR and r_cpu_addr(15 downto 0) <= PHASE_LAST_ADDR) then
                o_cpuif_rd_data                 <=  phase_weight_rd_data_a;
            elsif (r_cpu_addr(15 downto 0) >= CAL_ADDR_OFFSET and r_cpu_addr(15 downto 0) <= CAL_LAST_ADDR and CALB_MODULE = TRUE) then
                o_cpuif_rd_data                 <=  X"0" & i_calW_rd_data(23 downto 12) & X"0" & i_calW_rd_data(11 downto 0);
            elsif (r_cpu_addr(15 downto 0) >= DUMP_START_ADDR and r_cpu_addr(15 downto 0) <= DUMP_LAST_ADDR and DBG_DUMP_ENABLE = TRUE) then
                o_cpuif_rd_data                 <=  i_dump_rd_data(conv_integer(dump_rd_addr(0))*32+32-1 downto conv_integer(dump_rd_addr(0))*32);
            else
                o_cpuif_rd_data                 <=  cpuif_rd_data;
            end if;
        end if;
    end process;

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (r_cpu_addr(15 downto 0) >= ULFE_START_ADDR and r_cpu_addr(15 downto 0) <= ULFE_END_ADDR) then
                o_cpuif_rd_vld(0)               <=  cpuif_rd_vld;
            else
                o_cpuif_rd_vld(0)               <=  '0';
            end if;
        end if;
    end process;

    ------------------------------------------------------------------------------------------------------------------------------------------
    -- FOR DEBUG
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            i_in_10ms_sync_1d                   <=  i_in_10ms_sync;
        end if;
    end process;
    
    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            in_sync_cnt                         <=  (others=>'0');
            out_sync_cnt                        <=  (others=>'0');
        elsif (rising_edge(i_clk)) then
            if (i_in_10ms_sync_1d = '1') then
                in_sync_cnt                     <=  in_sync_cnt + '1';
            else
                in_sync_cnt                     <=  in_sync_cnt;
            end if;
            
            if (i_out_10ms_sync = '1') then
                out_sync_cnt                    <=  out_sync_cnt + '1';
            else
                out_sync_cnt                    <=  out_sync_cnt;
            end if;
        end if;
    end process;
    
    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            sync_period_cnt                     <=  (others=>'0');
            sync_err_cnt                        <=  (others=>'0');
            cur_frame_idx                       <=  (others=>'0');
            err_pre_frame_idx                   <=  (others=>'0');
            err_cur_frame_idx                   <=  (others=>'0');
            fsync_err_flag                      <=  '0';
        elsif (rising_edge(i_clk)) then
            if (i_in_10ms_sync_1d = '1') then
                sync_period_cnt                 <=  (others=>'0');
            else
                sync_period_cnt                 <=  sync_period_cnt + '1';
            end if;
            
            if (i_in_10ms_sync_1d = '1') then
                cur_frame_idx                   <=  i_in_frame_idx;
            else
                cur_frame_idx                   <=  cur_frame_idx;
            end if;
            
            if (i_in_10ms_sync_1d = '1' and (sync_period_cnt < minus_2457600 or sync_period_cnt > plus_2457600)) then
                sync_err_cnt                    <=  sync_err_cnt + '1';
                err_pre_frame_idx               <=  cur_frame_idx;
                err_cur_frame_idx               <=  i_in_frame_idx;
                fsync_err_flag                  <=  '1';
            else
                sync_err_cnt                    <=  sync_err_cnt;
                err_pre_frame_idx               <=  err_pre_frame_idx;
                err_cur_frame_idx               <=  err_cur_frame_idx;
                fsync_err_flag                  <=  '0';
            end if;
        end if;
    end process;

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            i_cal_enable_front_1d               <=  i_cal_enable_front;
            i_cal_enable_end_1d                 <=  i_cal_enable_end;
            
            if (i_in_10ms_sync_1d = '1') then
                cal_en_cnt                      <=  (others=>'0');
            else
                cal_en_cnt                      <=  cal_en_cnt + '1';
            end if;
            
            if (i_cal_enable_front_1d = '0' and i_cal_enable_front = '1') then
                cal_en_f_cnt_d                  <=  cal_en_cnt;
            else
                cal_en_f_cnt_d                  <=  cal_en_f_cnt_d;
            end if;
            
            if (i_cal_enable_end_1d = '0' and i_cal_enable_end = '1') then
                cal_en_e_cnt_d                  <=  cal_en_cnt;
            else
                cal_en_e_cnt_d                  <=  cal_en_e_cnt_d;
            end if;
        end if;
    end process;

end Behavioral;