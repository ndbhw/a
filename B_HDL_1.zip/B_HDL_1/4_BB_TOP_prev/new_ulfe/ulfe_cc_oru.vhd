-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2024, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2024.05.02 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_func.all;
use work.ulfe_component_pack_oru.all;
use work.ulfe_config_oru.all;

entity ulfe_cc_oru is
    Generic(
        NUM_ANT                             : integer := 4;
        TOP_DIO_BW                          : integer := 16;
        ADDR_OFFSET                         : std_logic_vector(20-1 downto 0) := X"00000";
        CPUIF_BB_ADDR_BW                    : integer := 20
    );
    Port(
        i_rst                               : in std_logic;
        i_clk                               : in std_logic;
        
        i_cpu_addr                          : in std_logic_vector(CPUIF_BB_ADDR_BW-1 downto 0);
        i_cpu_wren                          : in std_logic_vector(0 downto 0);
        i_cpu_wdata                         : in std_logic_vector(32-1 downto 0);
        i_cpu_rden                          : in std_logic_vector(0 downto 0);
        o_cpu_rdata                         : out std_logic_vector(32-1 downto 0);
        o_cpu_rd_valid                      : out std_logic_vector(0 downto 0);
        
        i_uin_frame_sync                    : in std_logic_vector(0 downto 0);
        i_uin_frame_idx                     : in std_logic_vector(8-1 downto 0);
        i_uin_en                            : in std_logic_vector(NUM_ANT-1 downto 0);
        i_uin_iq                            : in std_logic_vector(NUM_ANT*TOP_DIO_BW*2-1 downto 0);
        
        -- -- FROM/TO BFCAL
        -- i_dl_cal_en_ulfein                  : in std_logic;
        -- i_ul_cal_en_ulfein                  : in std_logic;
        -- i_dl_cal_en_ulfeout                 : in std_logic;
        -- i_ul_cal_en_ulfeout                 : in std_logic;
        -- o_bfn_strb_in_ulfeout               : out std_logic;               -- fft out 10m sync
        
        -- TO BB_TOP
        o_uout_frame_sync                   : out std_logic;
        o_uout_frame_idx                    : out std_logic_vector(8-1 downto 0);
        o_uout_subfrm_idx                   : out std_logic_vector(4-1 downto 0);
        o_uout_slot_idx                     : out std_logic_vector(6-1 downto 0);
        o_uout_symbol_sync                  : out std_logic;
        o_uout_symbol_idx                   : out std_logic_vector(4-1 downto 0);
        o_uout_en                           : out std_logic_vector(NUM_ANT-1 downto 0);
        o_uout_iq                           : out std_logic_vector(NUM_ANT*32-1 downto 0);
        o_uout_start_re_idx                 : out std_logic_vector(NUM_ANT*16-1 downto 0);
        o_uout_start_re                     : out std_logic_vector(NUM_ANT-1 downto 0);
        o_uout_last_re                      : out std_logic_vector(NUM_ANT-1 downto 0)
    );
end ulfe_cc_oru;

architecture Behavioral of ulfe_cc_oru is

    constant NUM_PRE_PROCESSING                 : integer := ternary_func(NUM_ANT<MAX_TIME_MUX,1,NUM_ANT/MAX_TIME_MUX);
    constant CHAIN_ANT_NUM                      : integer := ternary_func(NUM_ANT<MAX_TIME_MUX,NUM_ANT,MAX_TIME_MUX);
    
    signal  inner_rst                           : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    
    signal  par_freqShiftOn                     : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  par_cpRm_Offset                     : std_logic_array11(NUM_PRE_PROCESSING-1 downto 0);
    signal  par_tagcOn                          : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  par_tagcBackoff                     : std_logic_array5(NUM_PRE_PROCESSING-1 downto 0);
    signal  par_k0                              : std_logic_array12(NUM_PRE_PROCESSING-1 downto 0);
    signal  par_rbSize                          : std_logic_array9(NUM_PRE_PROCESSING-1 downto 0);
    signal  par_gainCompOn                      : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  par_ctsOn                           : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  par_ctsShift                        : std_logic_array12(NUM_PRE_PROCESSING-1 downto 0);
    signal  par_phaseCompOn                     : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  par_fftType                         : std_logic_array2(NUM_PRE_PROCESSING-1 downto 0);
    signal  par_scsType                         : std_logic_array2(NUM_PRE_PROCESSING-1 downto 0);
    
    signal  tdrssi_StartSlotIdx                 : std_logic_vector(7-1 downto 0);
    signal  tdrssi_StartSymbIdx                 : std_logic_vector(4-1 downto 0);
    signal  tdrssi_SymbSize                     : std_logic_vector(6-1 downto 0);
    signal  tdrssi_Trigger                      : std_logic;
    signal  tdrssi_SelSymbIdx_rpt               : std_logic_vector(6-1 downto 0);
    
    signal  tdrssi_rpt_done                     : std_logic;
    signal  tdrssi_rpt_data                     : std_logic_array32(NUM_ANT-1 downto 0);
    
    signal  par_calOn                           : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  par_calWscale                       : std_logic_array4(NUM_PRE_PROCESSING-1 downto 0);
    
    signal  par_fs_num                          : std_logic_array5(NUM_PRE_PROCESSING-1 downto 0);
    signal  par_sr_info                         : std_logic_array3(NUM_PRE_PROCESSING-1 downto 0);
    
    signal  r_dl_cal_en_ulfein                  : std_logic;
    signal  r_ul_cal_en_ulfein                  : std_logic;
    signal  r_dl_cal_en_ulfeout                 : std_logic;
    signal  r_ul_cal_en_ulfeout                 : std_logic;
    
    signal  calBypassFlag_F                     : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  calBypassFlag_E                     : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    
    signal  uin_sync                            : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  uin_vld                             : std_logic_vector(CHAIN_ANT_NUM*NUM_PRE_PROCESSING-1 downto 0);
    signal  uin_i                               : std_logic_array15(NUM_PRE_PROCESSING-1 downto 0);
    signal  uin_q                               : std_logic_array15(NUM_PRE_PROCESSING-1 downto 0);
    
    signal  tdrssi_dbg                          : std_logic_array32(NUM_ANT-1 downto 0);
    
    signal  calW_rd_wt_sel                      : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  sel_calw_rx                         : std_logic_array6(NUM_PRE_PROCESSING-1 downto 0);
    signal  calW_wt_buf                         : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  calW_wt_en                          : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  calw_wt_rb_num                      : std_logic_array9(NUM_PRE_PROCESSING-1 downto 0);
    signal  calW_wt_data                        : std_logic_array24(NUM_PRE_PROCESSING-1 downto 0);
    signal  cpuif_in_calW_rd_data               : std_logic_vector(24-1 downto 0);
    signal  calW_rd_data                        : std_logic_array24(NUM_PRE_PROCESSING-1 downto 0);
    
    signal  phasecomp_sync_adv_5clk             : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  phasecomp_vld                       : std_logic_vector(CHAIN_ANT_NUM*NUM_PRE_PROCESSING-1 downto 0);
    
    signal  w_par_PhaseI                        : std_logic_array16(NUM_PRE_PROCESSING-1 downto 0);
    signal  w_par_PhaseQ                        : std_logic_array16(NUM_PRE_PROCESSING-1 downto 0);
    
    signal  rpt_tdagc_fsync                     : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  rpt_tdagc_vld                       : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    
    type std_logic_array_CANT_32                is array(natural range <>) of std_logic_array32(CHAIN_ANT_NUM-1 downto 0);
    signal  rpt_tdrssi                          : std_logic_array_CANT_32(NUM_PRE_PROCESSING-1 downto 0);
    signal  rpt_tdrssi_all                      : std_logic_array32(NUM_ANT-1 downto 0);
    
    signal  uout_frame_idx                      : std_logic_array8(NUM_PRE_PROCESSING-1 downto 0);
    signal  uout_subfrm_idx                     : std_logic_array4(NUM_PRE_PROCESSING-1 downto 0);
    signal  uout_slot_idx                       : std_logic_array6(NUM_PRE_PROCESSING-1 downto 0);
    signal  uout_symbol_sync                    : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  uout_symbol_idx                     : std_logic_array4(NUM_PRE_PROCESSING-1 downto 0);
    signal  uout_frame_sync                     : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  uout_en                             : std_logic_vector(NUM_ANT-1 downto 0);
    signal  uout_iq                             : std_logic_vector(NUM_ANT*32-1 downto 0);
    
    signal  fft_rst_count                       : std_logic_array8(NUM_PRE_PROCESSING-1 downto 0);
    signal  fdssi                               : std_logic_array32(NUM_ANT-1 downto 0);
    
    signal  dump_td_fd                          : std_logic;
    signal  dump_Trigger                        : std_logic;
    signal  dump_frame                          : std_logic_vector(2-1 downto 0);
    signal  dump_ant                            : std_logic_vector(3-1 downto 0);
    signal  dump_slot                           : std_logic_vector(6-1 downto 0);
    signal  dump_symbol                         : std_logic_vector(4-1 downto 0);
    
    signal  dump_rd_buf                         : std_logic_vector(4-1 downto 0);
    signal  dump_rd_addr                        : std_logic_vector(16-1 downto 0);
    signal  dump_rd_data                        : std_logic_vector(64-1 downto 0);
    signal  dump_done                           : std_logic;
    
    signal  tdd_signal_count_adv                : std_logic_vector(22-1 downto 0);
    
    signal  bfn_strb_in_ulfeout                 : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    signal  bypass_set_reg                      : std_logic;
    
    signal  fsync_err_flag_reg                  : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);

begin

    GEN_RST : for i in 0 to NUM_PRE_PROCESSING-1 generate
        dly_rst : ulfe_lib_dly_fixed generic map(5,1) port map(i_clk=>i_clk, data_i(0)=>i_rst, data_o(0)=>inner_rst(i));
    end generate GEN_RST;

    U_CPUIF : ulfe_cpuif_oru generic map(NUM_PRE_PROCESSING,NUM_ANT,CHAIN_ANT_NUM,16,ADDR_OFFSET(17 downto 2))
        port map(
            i_rst                               =>  i_rst,                          --: in std_logic;
            i_clk                               =>  i_clk,                          --: in std_logic;
            
            i_cpuif_addr                        =>  i_cpu_addr(17 downto 2),        --: in std_logic_vector(CPUIF_BB_ADDR_BW-1 downto 0);
            i_cpuif_wt_en                       =>  i_cpu_wren,                     --: in std_logic_vector(0 downto 0);
            i_cpuif_wt_data                     =>  i_cpu_wdata,                    --: in std_logic_vector(32-1 downto 0);
            i_cpuif_rd_en                       =>  i_cpu_rden,                     --: in std_logic_vector(0 downto 0);
            o_cpuif_rd_data                     =>  o_cpu_rdata,                    --: out std_logic_vector(32-1 downto 0);
            o_cpuif_rd_vld                      =>  o_cpu_rd_valid,                 --: out std_logic_vector(0 downto 0);
            
            o_par_freqShiftOn                   =>  par_freqShiftOn,                --: out std_logic;
            o_par_cpRm_Offset                   =>  par_cpRm_Offset,                --: out std_logic_vector(11-1 downto 0);
            o_par_tagcOn                        =>  par_tagcOn,                     --: out std_logic;
            o_par_tagcBackoff                   =>  par_tagcBackoff,                --: out std_logic_vector(5-1 downto 0);
            o_par_k0                            =>  par_k0,                         --: out std_logic_vector(12-1 downto 0);
            o_par_rbSize                        =>  par_rbSize,                     --: out std_logic_vector(9-1 downto 0);
            o_par_gainCompOn                    =>  par_gainCompOn,                 --: out std_logic;
            o_par_ctsOn                         =>  par_ctsOn,                      --: out std_logic;
            o_par_ctsShift                      =>  par_ctsShift,                   --: out std_logic_vector(12-1 downto 0);
            o_par_phaseCompOn                   =>  par_phaseCompOn,                --: out std_logic;
            o_par_fftType                       =>  par_fftType,                    --: out std_logic_vector(2-1 downto 0);
            o_par_scsType                       =>  par_scsType,                    --: out std_logic_vector(2-1 downto 0);
            
            o_tdrssi_StartSlotIdx               =>  tdrssi_StartSlotIdx,            --: out std_logic_vector(7-1 downto 0);
            o_tdrssi_StartSymbIdx               =>  tdrssi_StartSymbIdx,            --: out std_logic_vector(4-1 downto 0);
            o_tdrssi_SymbSize                   =>  tdrssi_SymbSize,                --: out std_logic_vector(6-1 downto 0);
            o_tdrssi_Trigger                    =>  tdrssi_Trigger,                 --: out std_logic;
            o_tdrssi_SelSymbIdx_rpt             =>  tdrssi_SelSymbIdx_rpt,          --: out std_logic_vector(6-1 downto 0);
            
            i_tdrssi_rpt_done                   =>  tdrssi_rpt_done,                --: in std_logic;
            i_tdrssi_rpt_data                   =>  tdrssi_rpt_data,                --: in std_logic_array32(NUM_ANT-1 downto 0);
            i_tdrssi_dbg_data                   =>  tdrssi_dbg,                     --: in std_logic_array32(NUM_ANT-1 downto 0);
            i_fdrssi_dbg_data                   =>  fdssi,                          --: in std_logic_array32(NUM_ANT-1 downto 0);
            
            o_par_calOn                         =>  par_calOn,                      --: out std_logic;
            o_par_calWscale                     =>  par_calWscale,                  --: out std_logic_vector(4-1 downto 0);
            
            o_calW_rd_wt_sel                    =>  calW_rd_wt_sel,                 --: out std_logic;
            o_sel_calw_rx                       =>  sel_calw_rx,                    --: out std_logic_vector(6-1 downto 0);
            o_calW_wt_buf                       =>  calW_wt_buf,                    --: out std_logic;
            o_calW_wt_en                        =>  calW_wt_en,                     --: out std_logic;
            o_calw_wt_rb_num                    =>  calw_wt_rb_num,                 --: out std_logic_vector(9-1 downto 0);
            o_calW_wt_data                      =>  calW_wt_data,                   --: out std_logic_vector(24-1 downto 0);
            i_calW_rd_data                      =>  cpuif_in_calW_rd_data,          --: in std_logic_vector(24-1 downto 0);
            
            i_PHASECOMP_sync_adv_5clk           =>  phasecomp_sync_adv_5clk(0),                 --: in std_logic;
            i_PHASECOMP_vld                     =>  phasecomp_vld(CHAIN_ANT_NUM-1 downto 0),    --: in std_logic_vector(CHAIN_ANT_NUM-1 downto 0);
            
            o_par_phaseI                        =>  w_par_PhaseI,                   --: out std_logic_vector(16-1 downto 0);
            o_par_phaseQ                        =>  w_par_PhaseQ,                   --: out std_logic_vector(16-1 downto 0);
            
            i_fft_rst_count                     =>  fft_rst_count(0),               --: in std_logic_vector(8-1 downto 0);
            i_in_10ms_sync                      =>  uin_sync(0),                    --: in std_logic;
            i_out_10ms_sync                     =>  uout_frame_sync(0),             --: in std_logic;
            i_in_frame_idx                      =>  i_uin_frame_idx,                --: in std_logic_vector(8-1 downto 0);
            
            o_dump_td_fd                        =>  dump_td_fd,                     --: out std_logic;
            o_dump_Trigger                      =>  dump_Trigger,                   --: out std_logic;
            o_dump_frame                        =>  dump_frame,                     --: out std_logic_vector(2-1 downto 0);
            o_dump_ant                          =>  dump_ant,                       --: out std_logic_vector(3-1 downto 0);
            o_dump_slot                         =>  dump_slot,                      --: out std_logic_vector(6-1 downto 0);
            o_dump_symbol                       =>  dump_symbol,                    --: out std_logic_vector(4-1 downto 0);
            
            o_dump_rd_buf                       =>  dump_rd_buf,                    --: out std_logic_vector(4-1 downto 0);
            o_dump_rd_addr                      =>  dump_rd_addr,                   --: out std_logic_vector(16-1 downto 0);
            i_dump_rd_data                      =>  dump_rd_data,                   --: in std_logic_vector(64-1 downto 0);
            i_dump_done                         =>  dump_done,                      --: in std_logic;
            
            i_tdd_signal_count_adv              =>  tdd_signal_count_adv,           --: in std_logic_vector(22-1 downto 0);
            i_cal_enable_front                  =>  calBypassFlag_F(0),             --: in std_logic;
            i_cal_enable_end                    =>  calBypassFlag_E(0),             --: in std_logic;
            o_bypass_set_reg                    =>  bypass_set_reg,                 --: out std_logic
            
            o_fsync_err_flag                    =>  fsync_err_flag_reg              --: out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0)
        );

    U_INPUT_CTRL : ulfe_input_ctrl_oru generic map(NUM_ANT,NUM_PRE_PROCESSING,CHAIN_ANT_NUM,TOP_DIO_BW)
        Port map(
            i_rst                               =>  i_rst,                          --: in std_logic;
            i_clk                               =>  i_clk,                          --: in std_logic;
            
            i_uin_sync                          =>  i_uin_frame_sync(0),            --: in std_logic;
            i_uin_vld                           =>  i_uin_en,                       --: in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_uin_iq                            =>  i_uin_iq,                       --: in std_logic_array32(NUM_RX_ANT-1 downto 0);
            
            i_tdd_sig                           =>  '1',                            --: in std_logic;
            
            i_fftType                           =>  par_fftType(0),                 --: in std_logic_vector(2-1 downto 0);
            
            o_fs_num                            =>  par_fs_num,                     --: out std_logic_vector(5-1 downto 0);
            o_SR_info                           =>  par_sr_info,                    --: out std_logic_vector(3-1 downto 0);
            
            o_uin_sync                          =>  uin_sync,                       --: out std_logic;
            o_uin_vld                           =>  uin_vld,                        --: out std_logic_vector(CHAIN_ANT_NUM*NUM_PRE_PROCESSING-1 downto 0);
            o_uin_i                             =>  uin_i,                          --: out std_logic_array15(NUM_PRE_PROCESSING-1 downto 0);
            o_uin_q                             =>  uin_q,                          --: out std_logic_array15(NUM_PRE_PROCESSING-1 downto 0);
            
            o_rssi                              =>  tdrssi_dbg,                     --: out std_logic_array32(NUM_RX_ANT-1 downto 0);
            o_tdd_signal_count_adv              =>  tdd_signal_count_adv            --: out std_logic_vector(22-1 downto 0);
        );

    -- CALB_TRUE : if (CALB_MODULE = TRUE) generate
    --     process(i_clk)
    --     begin
    --         if (rising_edge(i_clk)) then
    --             r_dl_cal_en_ulfein                  <=  i_dl_cal_en_ulfein;
    --             r_ul_cal_en_ulfein                  <=  i_ul_cal_en_ulfein;
    --             r_dl_cal_en_ulfeout                 <=  i_dl_cal_en_ulfeout;
    --             r_ul_cal_en_ulfeout                 <=  i_ul_cal_en_ulfeout;
                
    --             if (bypass_set_reg = '1' and (r_dl_cal_en_ulfein = '1' or r_ul_cal_en_ulfein = '1')) then
    --                 calBypassFlag_F                 <=  (others=>'1');
    --             else
    --               calBypassFlag_F                   <=  (others=>'0');
    --             end if;
                
    --             if (bypass_set_reg = '1' and (r_dl_cal_en_ulfeout = '1' or r_ul_cal_en_ulfeout = '1')) then
    --               calBypassFlag_E                   <=  (others=>'1');
    --             else
    --               calBypassFlag_E                   <=  (others=>'0');
    --             end if;
                
    --             if (sel_calw_rx(0)(5 downto log2ceil(CHAIN_ANT_NUM)) >= 0 and sel_calw_rx(0)(5 downto log2ceil(CHAIN_ANT_NUM)) <= conv_std_logic_vector(NUM_PRE_PROCESSING-1,6-log2ceil(CHAIN_ANT_NUM))) then
    --               cpuif_in_calW_rd_data             <=  calW_rd_data(conv_integer(sel_calw_rx(0)(5 downto log2ceil(CHAIN_ANT_NUM))));
    --             else
    --               cpuif_in_calW_rd_data             <=  (others=>'0');
    --             end if;
    --         end if;
    --     end process;

    --     o_bfn_strb_in_ulfeout                       <=  bfn_strb_in_ulfeout(0);
    -- end generate CALB_TRUE;

    CALB_FALSE : if (CALB_MODULE = FALSE) generate
        calBypassFlag_F                                <=  (others=>'0');
        calBypassFlag_E                                <=  (others=>'0');
        cpuif_in_calW_rd_data                          <=  (others=>'0');
    end generate CALB_FALSE;

    U_CHAIN : for i in 0 to NUM_PRE_PROCESSING-1 generate
        PRE_PROCESSING : ulfe_pre_processing_oru generic map(CHAIN_ANT_NUM,i)
            port map(
                i_rst                           =>  inner_rst(i),                   --: in std_logic;
                i_clk                           =>  i_clk,                          --: in std_logic;
                
                i_fsync_err_flag                =>  fsync_err_flag_reg(i),          --: in std_logic;
                
                --INPUT
                i_frameidx                      =>  i_uin_frame_idx,                --: in std_logic_vector(8-1 downto 0);
                i_10ms_sync                     =>  uin_sync(i),                    --: in std_logic;
                i_data_vld                      =>  uin_vld((i+1)*CHAIN_ANT_NUM-1 downto i*CHAIN_ANT_NUM),          --: in std_logic_vector(NUM_RX_ANT-1 downto 0);
                i_data_i                        =>  uin_i(i),                       --: in std_logic_vector(15-1 downto 0);
                i_data_q                        =>  uin_q(i),                       --: in std_logic_vector(15-1 downto 0);
                
                i_fs_num                        =>  par_fs_num(i),                  --: in std_logic_vector(5-1 downto 0);
                i_SR_info                       =>  par_sr_info(i),                 --: in std_logic_vector(3-1 downto 0);          -- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76
                
                --FREQSHIFT
                i_freqShiftOn                   =>  par_freqShiftOn(i),             --: in std_logic;
                --CPRM
                i_cpRmOffset                    =>  par_cpRm_Offset(i),             --: in std_logic_vector(11-1 downto 0);
                --TDAGC
                i_tagcBackoff                   =>  par_tagcBackoff(i),             --: in std_logic_vector(5-1 downto 0);
                i_tagcOn                        =>  par_tagcOn(i),                  --: in std_logic;
                --FFT
                i_fftType                       =>  par_fftType(i),                 --: in std_logic_vector(2-1 downto 0);
                i_k0                            =>  par_k0(i),                      --: in std_logic_vector(12-1 downto 0);
                i_rbSize                        =>  par_rbSize(i),                  --: in std_logic_vector(9-1 downto 0);
                --GAINCOMP
                i_gainCompOn                    =>  par_gainCompOn(i),              --: in std_logic;
                --CTS
                i_cts_on                        =>  par_ctsOn(i),                   --: in std_logic;
                i_cts_shft                      =>  par_ctsShift(i),                --: in std_logic_vector(12-1 downto 0);
                --PHASECOMP
                i_phaseCompOn                   =>  par_phaseCompOn(i),             --: in std_logic;
                --ONLY DSS
                i_phaseCompBypass               =>  '0',                            --: in std_logic;
                
                o_PHASECOMP_sync_adv_5clk       =>  phasecomp_sync_adv_5clk(i),     --: out std_logic;
                o_PHASECOMP_vld                 =>  phasecomp_vld((i+1)*CHAIN_ANT_NUM-1 downto i*CHAIN_ANT_NUM),--: out std_logic_vector(NUM_RX_ANT-1 downto 0);
                
                i_phasecomp_weight_i            =>  w_par_PhaseI(i),                --: in std_logic_vector(16-1 downto 0);
                i_phasecomp_weight_q            =>  w_par_PhaseQ(i),                --: in std_logic_vector(16-1 downto 0);
                
                --CALB
                i_calOn                         =>  par_calOn(i),                   --: in std_logic;
                i_calBypassFlag_F               =>  calBypassFlag_F(i),             --: in std_logic;
                i_calBypassFlag_E               =>  calBypassFlag_E(i),             --: in std_logic;
                i_calWScale                     =>  par_calWscale(i),               --: in std_logic_vector(4-1 downto 0);
                
                i_calW_rd_wt_sel                =>  calW_rd_wt_sel(i),              --: in std_logic;
                i_calW_wt_buf                   =>  calW_wt_buf(i),                 --: in std_logic;
                i_calW_ant_num                  =>  sel_calw_rx(i),                 --: in std_logic_vector(6-1 downto 0);
                i_calW_wt_en                    =>  calW_wt_en(i),                  --: in std_logic;
                i_calW_wt_addr                  =>  calw_wt_rb_num(i),              --: in std_logic_vector(9-1 downto 0);
                i_calW_iq                       =>  calW_wt_data(i),                --: in std_logic_vector(24-1 downto 0);
                o_calW_rd_data                  =>  calW_rd_data(i),                --: out std_logic_vector(24-1 downto 0);
                
                --OUTPUT
                o_frameidx                      =>  uout_frame_idx(i),                                                  --: out std_logic_vector(8-1 downto 0);
                o_subframeidx                   =>  uout_subfrm_idx(i),                                                 --: out std_logic_vector(4-1 downto 0);
                o_slot_idx                      =>  uout_slot_idx(i),                                                   --: out std_logic_vector(6-1 downto 0);
                o_symbol_sync                   =>  uout_symbol_sync(i),                                                --: out std_logic;
                o_symbol_idx                    =>  uout_symbol_idx(i),                                                 --: out std_logic_vector(4-1 downto 0);
                o_10ms_sync                     =>  uout_frame_sync(i),                                                 --: out std_logic;
                o_data_vld                      =>  uout_en((i+1)*CHAIN_ANT_NUM-1 downto i*CHAIN_ANT_NUM),              --: out std_logic_vector(NUM_RX_ANT-1 downto 0);
                o_start_re                      =>  o_uout_start_re((i+1)*CHAIN_ANT_NUM-1 downto i*CHAIN_ANT_NUM),      --: out std_logic_vector(NUM_RX_ANT-1 downto 0);
                o_last_re                       =>  o_uout_last_re((i+1)*CHAIN_ANT_NUM-1 downto i*CHAIN_ANT_NUM),       --: out std_logic_vector(NUM_RX_ANT-1 downto 0);
                o_data_iq                       =>  uout_iq((i+1)*CHAIN_ANT_NUM*32-1 downto i*CHAIN_ANT_NUM*32),        --: out std_logic_array32(NUM_RX_ANT-1 downto 0);
                
                o_fft_rst_count                 =>  fft_rst_count(i),               --: out std_logic_vector(8-1 downto 0);
                
                o_tdagc_fsync                   =>  rpt_tdagc_fsync(i),             --: out std_logic;
                o_tdagc_vld                     =>  rpt_tdagc_vld(i),               --: out std_logic;
                o_tdrssi                        =>  rpt_tdrssi(i),                  --: out std_logic_array32(NUM_RX_ANT-1 downto 0)
                
                o_bfn_strb_in_ulfeout           =>  bfn_strb_in_ulfeout(i)          --: out std_logic
            );
    end generate U_CHAIN;

    o_uout_frame_idx                            <=  uout_frame_idx(0);
    o_uout_subfrm_idx                           <=  uout_subfrm_idx(0);
    
    SCS_0 : if (SCSTYPE = 0) generate
        o_uout_slot_idx                         <=  (others=>'0');
    end generate SCS_0;
    
    SCS_1 : if (SCSTYPE = 1) generate
        o_uout_slot_idx                         <=  b"00000" & uout_slot_idx(0)(0);
    end generate SCS_1;
    
    SCS_2 : if (SCSTYPE = 2) generate
        o_uout_slot_idx                         <=  b"0000" & uout_slot_idx(0)(1 downto 0);
    end generate SCS_2;
    
    SCS_3 : if (SCSTYPE = 3) generate
        o_uout_slot_idx                         <=  uout_slot_idx(0);
    end generate SCS_3;
    
    o_uout_symbol_sync                          <=  uout_symbol_sync(0);
    o_uout_symbol_idx                           <=  uout_symbol_idx(0);
    o_uout_frame_sync                           <=  uout_frame_sync(0);
    
    o_uout_start_re_idx                         <=  (others=>'0');
    
    o_uout_en                                   <=  uout_en;
    o_uout_iq                                   <=  uout_iq;    

    ------------------------------------------------------------------------------------------------------------------------------------------
    -- RPT_TDRSSI	
    RPT_TDRSSI_TRUE : if (RPT_TDRSSI_ENABLE = TRUE) generate
        RPT_TD_ARRANGE_ST0 : for i in 0 to NUM_PRE_PROCESSING-1 generate
            RPT_TD_ARRANGE_ST1 : for q in 0 to CHAIN_ANT_NUM-1 generate
                rpt_tdrssi_all(i*CHAIN_ANT_NUM+q)               <=  rpt_tdrssi(i)(q);
            end generate RPT_TD_ARRANGE_ST1;
        end generate RPT_TD_ARRANGE_ST0;
        
        U_RPT_TDRSSI : ulfe_tdrssi_rpt_oru generic map(NUM_ANT)
            port map(
                i_rst                           =>  i_rst,                          --: in std_logic;
                i_clk                           =>  i_clk,                          --: in std_logic;
                
                i_framesync                     =>  rpt_tdagc_fsync(0),             --: in std_logic;
                i_data_vld                      =>  rpt_tdagc_vld(0),               --: in std_logic;
                i_tdrssi                        =>  rpt_tdrssi_all,                 --: in std_logic_array32(NUM_ANT-1 downto 0);
                
                i_tdrssi_StartSlotIdx           =>  tdrssi_StartSlotIdx,            --: in std_logic_vector(7-1 downto 0);
                i_tdrssi_StartSymbIdx           =>  tdrssi_StartSymbIdx,            --: in std_logic_vector(4-1 downto 0);
                i_tdrssi_SymbSize               =>  tdrssi_SymbSize,                --: in std_logic_vector(6-1 downto 0);
                i_tdrssi_Trigger                =>  tdrssi_Trigger,                 --: in std_logic;
                i_tdrssi_SelSymbIdx_rpt         =>  tdrssi_SelSymbIdx_rpt,          --: in std_logic_vector(6-1 downto 0);
                
                o_tdrssi_rpt_done               =>  tdrssi_rpt_done,                --: out std_logic;
                o_tdrssi_rpt_data               =>  tdrssi_rpt_data                 --: out std_logic_array32(NUM_ANT-1 downto 0)
            );
    end generate RPT_TDRSSI_TRUE;
    
    RPT_TDRSSI_FALSE : if (RPT_TDRSSI_ENABLE = FALSE) generate
        tdrssi_rpt_done                         <=  '0';
        tdrssi_rpt_data                         <=  (others=>(others=>'0'));
    end generate RPT_TDRSSI_FALSE;

    ------------------------------------------------------------------------------------------------------------------------------------------
    -- DBG_FDRSSI
    FDRSSI_TRUE : if (DBG_FDRSSI_ENABLE = TRUE) generate
        U_FDRSSI : ulfe_fdrssi_dbg_oru generic map(NUM_ANT,NUM_PRE_PROCESSING,CHAIN_ANT_NUM)
            Port map(
                i_rst                           =>  i_rst,                          --: in std_logic;
                i_clk                           =>  i_clk,                          --: in std_logic;
                
                i_uout_sync                     =>  uout_frame_sync(0),             --: in std_logic;
                i_uout_vld                      =>  uout_en,                        --: in std_logic_vector(NUM_RX_ANT-1 downto 0);
                i_uout_iq                       =>  uout_iq,                        --: in std_logic_vector(NUM_RX_ANT*32-1 downto 0);
                
                i_tdd_sig                       =>  '1',                            --: in std_logic;
                
                o_fdssi                         =>  fdssi                           --: out std_logic_array32(NUM_RX_ANT-1 downto 0)
            );
    end generate FDRSSI_TRUE;
    
    FDRSSI_FALSE : if (DBG_FDRSSI_ENABLE = FALSE) generate
        fdssi                                   <=  (others=>(others=>'0'));
    end generate FDRSSI_FALSE;
    
    ------------------------------------------------------------------------------------------------------------------------------------------
    -- DBG_DUMP	
    DUMP_TRUE : if (DBG_DUMP_ENABLE = TRUE) generate
        DUMP : ulfe_dump_cc_oru generic map(NUM_ANT)
            Port map(
                i_rst                               =>  i_rst,                          --: in std_logic;
                i_clk                               =>  i_clk,                          --: in std_logic;
                
                i_fftType                           =>  par_fftType(0),                 --: in std_logic_vector(2-1 downto 0);
                i_fs_num                            =>  par_fs_num(0),                  --: in std_logic_vector(5-1 downto 0);
                
                i_dump_td_fd                        =>  dump_td_fd,                     --: in std_logic;
                i_dump_Trigger                      =>  dump_Trigger,                   --: in std_logic;
                i_dump_frame                        =>  dump_frame,                     --: in std_logic_vector(2-1 downto 0);
                i_dump_ant                          =>  dump_ant,                       --: in std_logic_vector(3-1 downto 0);
                i_dump_slot                         =>  dump_slot,                      --: in std_logic_vector(6-1 downto 0);
                i_dump_symbol                       =>  dump_symbol,                    --: in std_logic_vector(4-1 downto 0);
                
                i_frameidx                          =>  i_uin_frame_idx(1 downto 0),    --: in std_logic_vector(2-1 downto 0);
                i_uin_sync                          =>  i_uin_frame_sync(0),            --: in std_logic;
                i_uin_iq                            =>  i_uin_iq,                       --: in std_logic_vector(NUM_ANT*32-1 downto 0);
                
                i_uout_sync                         =>  uout_frame_sync(0),             --: in std_logic;
                i_uout_vld                          =>  uout_en,                        --: in std_logic_vector(NUM_ANT-1 downto 0);
                i_uout_iq                           =>  uout_iq,                        --: in std_logic_vector(NUM_ANT*32-1 downto 0);
                
                i_dump_rd_buf                       =>  dump_rd_buf,                    --: in std_logic_vector(4-1 downto 0);
                i_dump_rd_addr                      =>  dump_rd_addr,                   --: in std_logic_vector(16-1 downto 0);
                o_dump_rd_data                      =>  dump_rd_data,                   --: out std_logic_vector(64-1 downto 0);
                o_dump_done                         =>  dump_done                       --: out std_logic
            );
    end generate DUMP_TRUE;
    
    DUMP_FALSE : if (DBG_DUMP_ENABLE = FALSE) generate
        dump_rd_data                                <=  X"DEADDEADDEADDEAD";
    end generate DUMP_FALSE;

end Behavioral;