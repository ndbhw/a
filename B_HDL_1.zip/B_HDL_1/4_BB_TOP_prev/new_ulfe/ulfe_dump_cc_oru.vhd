-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2024, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2024.05.02 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_func.all;
use work.ulfe_component_pack_oru.all;
use work.ulfe_config_oru.all;

entity ulfe_dump_cc_oru is
    Generic(
        NUM_ANT                             : integer := 8
    );
    Port(
        i_rst                               : in std_logic;
        i_clk                               : in std_logic;
        
        i_fftType                           : in std_logic_vector(2-1 downto 0);
        i_fs_num                            : in std_logic_vector(5-1 downto 0);
        
        i_dump_td_fd                        : in std_logic;
        i_dump_Trigger                      : in std_logic;
        i_dump_frame                        : in std_logic_vector(2-1 downto 0);
        i_dump_ant                          : in std_logic_vector(3-1 downto 0);
        i_dump_slot                         : in std_logic_vector(6-1 downto 0);
        i_dump_symbol                       : in std_logic_vector(4-1 downto 0);
        
        i_frameidx                          : in std_logic_vector(2-1 downto 0);
        i_uin_sync                          : in std_logic;
        i_uin_iq                            : in std_logic_vector(NUM_ANT*32-1 downto 0);
        
        i_uout_sync                         : in std_logic;
        i_uout_vld                          : in std_logic_vector(NUM_ANT-1 downto 0);
        i_uout_iq                           : in std_logic_vector(NUM_ANT*32-1 downto 0);
        
        i_dump_rd_buf                       : in std_logic_vector(4-1 downto 0);
        i_dump_rd_addr                      : in std_logic_vector(16-1 downto 0);
        o_dump_rd_data                      : out std_logic_vector(64-1 downto 0);
        o_dump_done                         : out std_logic
    );
end ulfe_dump_cc_oru;

architecture Behavioral of ulfe_dump_cc_oru is

    constant MEM_READ_LATENCY               : integer := 2;
    constant MEM_D_WIDTH                    : integer := 32*2;
    constant MEM_DEPTH                      : integer := 4096;
    
    signal  r_fftType                       : std_logic_vector(2-1 downto 0);
    signal  r_fs_num                        : std_logic_vector(5-1 downto 0);
    
    signal  r_dump_td_fd                    : std_logic;
    signal  r_dump_Trigger                  : std_logic;
    signal  r_dump_frame                    : std_logic_vector(2-1 downto 0);
    signal  r_dump_ant                      : std_logic_vector(3-1 downto 0);
    signal  r_dump_slot                     : std_logic_vector(6-1 downto 0);
    signal  r_dump_symbol                   : std_logic_vector(4-1 downto 0);
    
    signal  r_sel_ant                       : integer range 0 to NUM_ANT-1;
    
    signal  i_uin_sync_1d                   : std_logic;
    
    signal  r_frameidx                      : std_logic_vector(2-1 downto 0);
    signal  r_uin_iq                        : std_logic_vector(32-1 downto 0);
    signal  r_uin_sync                      : std_logic;
    
    signal  r_uout_vld                      : std_logic_vector(NUM_ANT-1 downto 0);
    signal  r_uout_iq                       : std_logic_vector(32-1 downto 0);
    
    signal  slotIdx_td                      : std_logic_vector(8-1 downto 0);
    signal  symIdx_td                       : std_logic_vector(4-1 downto 0);
    signal  symTick_td                      : std_logic;
    signal  fsTick_td                       : std_logic;
    signal  cpSize                          : std_logic_vector(12-1 downto 0);
    
    signal  slotIdx_fd                      : std_logic_vector(8-1 downto 0);
    signal  symIdx_fd                       : std_logic_vector(4-1 downto 0);
    signal  sig_toggle                      : std_logic;
    
    signal  dump_ready                      : std_logic;
    signal  dump_done                       : std_logic;
    signal  same_flag                       : std_logic;
    
    signal  wt_enable                       : std_logic;
    signal  wt_enable_1d                    : std_logic;
    signal  wt_enable_d                     : std_logic;
    signal  wt_addr                         : std_logic_vector(log2ceil(MEM_DEPTH)-1 downto 0);
    signal  wt_data                         : std_logic_vector(MEM_D_WIDTH-1 downto 0);

    signal  rd_addr                         : std_logic_vector(log2ceil(MEM_DEPTH)-1 downto 0);	
    signal  rd_data                         : std_logic_vector(64-1 downto 0);

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            r_fftType                       <=  i_fftType;
            r_fs_num                        <=  i_fs_num;
            
            r_dump_td_fd                    <=  i_dump_td_fd;
            r_dump_Trigger                  <=  i_dump_Trigger;
            r_dump_frame                    <=  i_dump_frame;
            r_dump_ant                      <=  i_dump_ant;
            r_dump_slot                     <=  i_dump_slot;
            r_dump_symbol                   <=  i_dump_symbol;
            
            if (r_dump_ant >= 0 and r_dump_ant <= conv_std_logic_vector(NUM_ANT-1,3)) then
                r_sel_ant                   <=  conv_integer(r_dump_ant);
            else
                r_sel_ant                   <=  0;
            end if;
        end if;
    end process;

    ---------------------------------------------------------------------------------------------------------------------------------------------------------------
    -- ulfe_in_index
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            r_frameidx                      <=  i_frameidx;
            i_uin_sync_1d                   <=  i_uin_sync;
            if (i_uin_sync_1d = '0' and i_uin_sync = '1') then
            	r_uin_sync                  <=  '1';
            else
            	r_uin_sync                  <=  '0';
            end if;
            
            r_uin_iq                        <=  i_uin_iq((r_sel_ant+1)*32-1 downto r_sel_ant*32);
        end if;
    end process;
    
    idx_counter : ulfe_idx_counter_oru port map(i_rst, i_clk, r_fftType, cpSize(10 downto 0), r_uin_sync, r_fs_num, open, slotIdx_td, symIdx_td, open, symTick_td, fsTick_td);
    cal_cpsize : ulfe_cal_cpSize_oru port map(i_clk, r_fftType, slotIdx_td(1 downto 0), symIdx_td, cpSize);

    ---------------------------------------------------------------------------------------------------------------------------------------------------------------
    -- ulfe_out_index

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            r_uout_vld                      <=  i_uout_vld;
            r_uout_iq                       <=  i_uout_iq((r_sel_ant+1)*32-1 downto r_sel_ant*32);
            
            if (r_uout_vld(r_sel_ant) = '1') then
                sig_toggle                  <=  not sig_toggle;
            else
                sig_toggle                  <=  '0';
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_uout_sync = '1') then
                slotIdx_fd                  <=	(others=>'0');
                symIdx_fd                   <=	(others=>'0');
                
            elsif (r_uout_vld(NUM_ANT-1) = '1' and i_uout_vld(NUM_ANT-1) = '0' and symIdx_fd = X"D") then
                slotIdx_fd                  <=	slotIdx_fd + '1';
                symIdx_fd                   <=	(others=>'0');
                
            elsif (r_uout_vld(NUM_ANT-1) = '1' and i_uout_vld(NUM_ANT-1) = '0') then
                slotIdx_fd                  <=	slotIdx_fd;
                symIdx_fd                   <=	symIdx_fd + '1';
            end if;
        end if;
    end process;

	---------------------------------------------------------------------------------------------------------------------------------------------------------------

    o_dump_done                             <=  dump_done;
    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            dump_ready                      <=  '0';
            dump_done                       <=  '0';
            same_flag                       <=  '0';
        elsif (rising_edge(i_clk)) then
            if (r_dump_Trigger = '0' and i_dump_Trigger = '1') then
                dump_ready                  <=  '1';
                dump_done                   <=  '0';
            elsif (dump_ready = '1' and wt_enable_d = '1' and wt_addr = conv_std_logic_vector(MEM_DEPTH-1,log2ceil(MEM_DEPTH))) then
                dump_ready                  <=  '0';
                dump_done                   <=  '1';
            else
                dump_ready                  <=  dump_ready;
                dump_done                   <=  dump_done;
            end if;
            
            if (dump_ready = '0') then
                same_flag                   <=  '0';
            elsif ((dump_ready = '1' and r_dump_td_fd = '0') and (slotIdx_td(5 downto 0) = r_dump_slot) and (symIdx_td = r_dump_symbol) and (r_frameidx = r_dump_frame)) then
                same_flag                   <=  '1';
            elsif ((dump_ready = '1' and r_dump_td_fd = '1') and (slotIdx_fd(5 downto 0) = r_dump_slot) and (symIdx_fd = r_dump_symbol) and (r_frameidx = r_dump_frame)) then
                same_flag                   <=  '1';
            else
                same_flag                   <=  same_flag;
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (r_dump_td_fd = '0' and (symTick_td = '1' or fsTick_td = '1')) then
                wt_data                     <=  r_uin_iq & wt_data(63 downto 32);
            elsif (r_dump_td_fd = '1') then
                wt_data                     <=  r_uout_iq & wt_data(63 downto 32);
            else
                wt_data                     <=  wt_data;
            end if;
            
            if (r_uin_sync = '1') then
                wt_enable                   <=  '0';
            elsif (fsTick_td = '1') then
                wt_enable                   <=  not wt_enable;
            else
                wt_enable                   <=  wt_enable;
            end if;
            wt_enable_1d                    <=  wt_enable;
            
            if (dump_ready = '1' and (same_flag = '1' and r_dump_td_fd = '0') and wt_enable_1d = '0' and wt_enable = '1') then
                wt_enable_d                 <=  '1';
            elsif (dump_ready = '1' and (same_flag = '1' and r_dump_td_fd = '1') and sig_toggle = '1') then
                wt_enable_d                 <=  '1';
            else
                wt_enable_d                 <=  '0';
            end if;
            
            if (dump_ready = '0') then
                wt_addr                     <=  (others=>'0');
            elsif (wt_enable_d = '1') then
                wt_addr                     <=  wt_addr + '1';
            else
                wt_addr                     <=  wt_addr;
            end if;
        end if;
    end process;

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            rd_addr                         <=  i_dump_rd_buf(2 downto 0) & i_dump_rd_addr(log2ceil(MEM_DEPTH)-3 downto 1);
        end if;
    end process;

    u_buffer : ulfe_lib_sdpram generic map("ultra",MEM_READ_LATENCY,MEM_D_WIDTH,MEM_D_WIDTH,MEM_DEPTH,MEM_DEPTH)
        port map(
            i_clk                           =>  i_clk,
            
            i_wt_enable                     =>  wt_enable_d,
            i_wt_addr                       =>  wt_addr,
            i_wt_data                       =>  wt_data,
            
            i_rd_addr                       =>  rd_addr,
            o_rd_dout                       =>  rd_data
        );

    o_dump_rd_data                          <=  rd_data;

end Behavioral;