library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

library work;
use work.ulfe_func.all;
use work.ulfe_config_oru.all;

package ulfe_component_pack_oru is

    component ulfe_cpuif_oru is
        Generic(
            NUM_PRE_PROCESSING                  : integer := 1;
            NUM_ANT                             : integer := 4;
            CHAIN_ANT_NUM                       : integer := 2;
            CPUIF_BB_ADDR_BW                    : integer := 16;
            ADDR_OFFSET                         : std_logic_vector(16-1 downto 0) := X"0000"
        );
        Port(
            i_rst                               : in std_logic;
            i_clk                               : in std_logic;
            
            i_cpuif_addr                        : in std_logic_vector(CPUIF_BB_ADDR_BW-1 downto 0);
            i_cpuif_wt_en                       : in std_logic_vector(0 downto 0);
            i_cpuif_wt_data                     : in std_logic_vector(32-1 downto 0);
            i_cpuif_rd_en                       : in std_logic_vector(0 downto 0);
            o_cpuif_rd_data                     : out std_logic_vector(32-1 downto 0);
            o_cpuif_rd_vld                      : out std_logic_vector(0 downto 0);
            
            o_par_freqShiftOn                   : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
            o_par_cpRm_Offset                   : out std_logic_array11(NUM_PRE_PROCESSING-1 downto 0);
            o_par_tagcOn                        : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
            o_par_tagcBackoff                   : out std_logic_array5(NUM_PRE_PROCESSING-1 downto 0);
            o_par_k0                            : out std_logic_array12(NUM_PRE_PROCESSING-1 downto 0);
            o_par_rbSize                        : out std_logic_array9(NUM_PRE_PROCESSING-1 downto 0);
            o_par_gainCompOn                    : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
            o_par_ctsOn                         : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
            o_par_ctsShift                      : out std_logic_array12(NUM_PRE_PROCESSING-1 downto 0);
            o_par_phaseCompOn                   : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
            o_par_fftType                       : out std_logic_array2(NUM_PRE_PROCESSING-1 downto 0);
            o_par_scsType                       : out std_logic_array2(NUM_PRE_PROCESSING-1 downto 0);
            
            o_tdrssi_StartSlotIdx               : out std_logic_vector(7-1 downto 0);
            o_tdrssi_StartSymbIdx               : out std_logic_vector(4-1 downto 0);
            o_tdrssi_SymbSize                   : out std_logic_vector(6-1 downto 0);
            o_tdrssi_Trigger                    : out std_logic;
            o_tdrssi_SelSymbIdx_rpt             : out std_logic_vector(6-1 downto 0);
            
            i_tdrssi_rpt_done                   : in std_logic;
            i_tdrssi_rpt_data                   : in std_logic_array32(NUM_ANT-1 downto 0);
            i_tdrssi_dbg_data                   : in std_logic_array32(NUM_ANT-1 downto 0);
            i_fdrssi_dbg_data                   : in std_logic_array32(NUM_ANT-1 downto 0);
            
            o_par_calOn                         : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
            o_par_calWscale                     : out std_logic_array4(NUM_PRE_PROCESSING-1 downto 0);
            
            o_calW_rd_wt_sel                    : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
            o_sel_calw_rx                       : out std_logic_array6(NUM_PRE_PROCESSING-1 downto 0);
            o_calW_wt_buf                       : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
            o_calW_wt_en                        : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
            o_calw_wt_rb_num                    : out std_logic_array9(NUM_PRE_PROCESSING-1 downto 0);
            o_calW_wt_data                      : out std_logic_array24(NUM_PRE_PROCESSING-1 downto 0);
            i_calW_rd_data                      : in std_logic_vector(24-1 downto 0);
            
            i_PHASECOMP_sync_adv_5clk           : in std_logic;
            i_PHASECOMP_vld                     : in std_logic_vector(CHAIN_ANT_NUM-1 downto 0);
            
            o_par_phaseI                        : out std_logic_array16(NUM_PRE_PROCESSING-1 downto 0);
            o_par_phaseQ                        : out std_logic_array16(NUM_PRE_PROCESSING-1 downto 0);
            
            i_fft_rst_count                     : in std_logic_vector(8-1 downto 0);
            i_in_10ms_sync                      : in std_logic;
            i_out_10ms_sync                     : in std_logic;
            i_in_frame_idx                      : in std_logic_vector(8-1 downto 0);
            
            o_dump_td_fd                        : out std_logic;
            o_dump_Trigger                      : out std_logic;
            o_dump_frame                        : out std_logic_vector(2-1 downto 0);
            o_dump_ant                          : out std_logic_vector(3-1 downto 0);
            o_dump_slot                         : out std_logic_vector(6-1 downto 0);
            o_dump_symbol                       : out std_logic_vector(4-1 downto 0);
            
            o_dump_rd_buf                       : out std_logic_vector(4-1 downto 0);
            o_dump_rd_addr                      : out std_logic_vector(16-1 downto 0);
            i_dump_rd_data                      : in std_logic_vector(64-1 downto 0);
            i_dump_done                         : in std_logic;
            
            i_tdd_signal_count_adv              : in std_logic_vector(22-1 downto 0);
            i_cal_enable_front                  : in std_logic;
            i_cal_enable_end                    : in std_logic;
            o_bypass_set_reg                    : out std_logic;
            
            o_fsync_err_flag                    : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0)
        );
    end component ulfe_cpuif_oru;
    
    component ulfe_input_ctrl_oru is
        generic (
            NUM_RX_ANT                          : integer := 8;
            NUM_PRE_PROCESSING                  : integer := 4;
            CHAIN_ANT_NUM                       : integer := 2;
            TOP_DIO_BW                          : integer := 16
        );
        Port (
            i_rst                               : in std_logic;
            i_clk                               : in std_logic;
            
            i_uin_sync                          : in std_logic;
            i_uin_vld                           : in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_uin_iq                            : in std_logic_vector(2*NUM_RX_ANT*TOP_DIO_BW-1 downto 0);
            
            i_tdd_sig                           : in std_logic;
            
            i_fftType                           : in std_logic_vector(2-1 downto 0);
            
            o_fs_num                            : out std_logic_array5(NUM_PRE_PROCESSING-1 downto 0);
            o_SR_info                           : out std_logic_array3(NUM_PRE_PROCESSING-1 downto 0);
            
            o_uin_sync                          : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
            o_uin_vld                           : out std_logic_vector(CHAIN_ANT_NUM*NUM_PRE_PROCESSING-1 downto 0);
            o_uin_i                             : out std_logic_array15(NUM_PRE_PROCESSING-1 downto 0);
            o_uin_q                             : out std_logic_array15(NUM_PRE_PROCESSING-1 downto 0);
            
            o_rssi                              : out std_logic_array32(NUM_RX_ANT-1 downto 0);
            o_tdd_signal_count_adv              : out std_logic_vector(22-1 downto 0)
        );
    end component ulfe_input_ctrl_oru;
    
    component ulfe_param_proc_oru is	
        Port (
            i_clk                               : in std_logic;
            
            i_fftType                           : in std_logic_vector(2-1 downto 0);
            
            o_fs_num                            : out std_logic_vector(5-1 downto 0);
            o_SR_info                           : out std_logic_vector(3-1 downto 0)    -- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76		
        );
    end component ulfe_param_proc_oru;
    
    component ulfe_tdrssi_dbg_oru is
        generic (
            NUM_RX_ANT                          : integer := 4
        );
        Port(
            i_rst                               : in std_logic;
            i_clk                               : in std_logic;
            
            i_uin_sync                          : in std_logic;
            i_uin_vld                           : in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_uin_i                             : in std_logic_vector(15-1 downto 0);
            i_uin_q                             : in std_logic_vector(15-1 downto 0);
            
            i_fs_num                            : in std_logic_vector(5-1 downto 0);
            i_SR_info                           : in std_logic_vector(3-1 downto 0);
            i_tdd_sig                           : in std_logic;
            
            o_xssi                              : out std_logic_array32(NUM_RX_ANT-1 downto 0)
        );
    end component ulfe_tdrssi_dbg_oru;
    
    component MANTISSA_FRAMER_modi is
        port(
            CLK                                 : in  std_logic;
            
            START_IN                            : in  std_logic;
            DATA_IN                             : in  std_logic_vector(63 downto 0);
            
            DONE_OUT                            : out std_logic;
            MANTISSA_OUT                        : out std_logic_vector(31 downto 0)
        );
    end component MANTISSA_FRAMER_modi;
    
    component ulfe_pre_processing_oru is
        generic (
            NUM_RX_ANT                          : integer := 4;
            NUM_CHAIN                           : integer := 0
        );
        Port (
            i_rst                               : in std_logic;
            i_clk                               : in std_logic;
            
            i_fsync_err_flag                    : in std_logic;
            
            --INPUT
            i_frameidx                          : in std_logic_vector(8-1 downto 0);
            i_10ms_sync                         : in std_logic;
            i_data_vld                          : in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_data_i                            : in std_logic_vector(15-1 downto 0);
            i_data_q                            : in std_logic_vector(15-1 downto 0);
            
            i_fs_num                            : in std_logic_vector(5-1 downto 0);
            i_SR_info                           : in std_logic_vector(3-1 downto 0);    -- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76
            
            --FREQSHIFT
            i_freqShiftOn                       : in std_logic;
            --CPRM
            i_cpRmOffset                        : in std_logic_vector(11-1 downto 0);
            --TDAGC
            i_tagcBackoff                       : in std_logic_vector(5-1 downto 0);
            i_tagcOn                            : in std_logic;
            --FFT
            i_fftType                           : in std_logic_vector(2-1 downto 0);
            i_k0                                : in std_logic_vector(12-1 downto 0);
            i_rbSize                            : in std_logic_vector(9-1 downto 0);
            --GAINCOMP
            i_gainCompOn                        : in std_logic;
            --CTS
            i_cts_on                            : in std_logic;
            i_cts_shft                          : in std_logic_vector(12-1 downto 0);
            --PHASECOMP
            i_phaseCompOn                       : in std_logic;
            --only DSS
            i_phaseCompBypass                   : in std_logic;
            
            o_PHASECOMP_sync_adv_5clk           : out std_logic;
            o_PHASECOMP_vld                     : out std_logic_vector(NUM_RX_ANT-1 downto 0);
            
            i_phasecomp_weight_i                : in std_logic_vector(16-1 downto 0);
            i_phasecomp_weight_q                : in std_logic_vector(16-1 downto 0);
            
            --CALB
            i_calOn                             : in std_logic;
            i_calBypassFlag_F                   : in std_logic;
            i_calBypassFlag_E                   : in std_logic;
            i_calWScale                         : in std_logic_vector(4-1 downto 0);
            
            i_calW_rd_wt_sel                    : in std_logic;
            i_calW_wt_buf                       : in std_logic;
            i_calW_ant_num                      : in std_logic_vector(6-1 downto 0);
            i_calW_wt_en                        : in std_logic;
            i_calW_wt_addr                      : in std_logic_vector(9-1 downto 0);
            i_calW_iq                           : in std_logic_vector(24-1 downto 0);
            o_calW_rd_data                      : out std_logic_vector(24-1 downto 0);
            
            --OUTPUT
            o_frameidx                          : out std_logic_vector(8-1 downto 0);
            o_subframeidx                       : out std_logic_vector(4-1 downto 0);
            o_slot_idx                          : out std_logic_vector(6-1 downto 0);
            o_symbol_sync                       : out std_logic;
            o_symbol_idx                        : out std_logic_vector(4-1 downto 0);
            o_10ms_sync                         : out std_logic;
            o_data_vld                          : out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_start_re                          : out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_last_re                           : out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_data_iq                           : out std_logic_vector(NUM_RX_ANT*32-1 downto 0);
            
            o_fft_rst_count                     : out std_logic_vector(8-1 downto 0);
            
            o_tdagc_fsync                       : out std_logic;
            o_tdagc_vld                         : out std_logic;
            o_tdrssi                            : out std_logic_array32(NUM_RX_ANT-1 downto 0);
            
            o_bfn_strb_in_ulfeout               : out std_logic
        );
    end component ulfe_pre_processing_oru;
    
    component ulfe_tdrssi_rpt_oru is
        generic (
            NUM_ANT                             : integer := 4
        );
        Port(
            i_rst                               : in std_logic;
            i_clk                               : in std_logic;
            
            i_framesync                         : in std_logic;
            i_data_vld                          : in std_logic;
            i_tdrssi                            : in std_logic_array32(NUM_ANT-1 downto 0);
            
            i_tdrssi_StartSlotIdx               : in std_logic_vector(7-1 downto 0);
            i_tdrssi_StartSymbIdx               : in std_logic_vector(4-1 downto 0);
            i_tdrssi_SymbSize                   : in std_logic_vector(6-1 downto 0);
            i_tdrssi_Trigger                    : in std_logic;
            i_tdrssi_SelSymbIdx_rpt             : in std_logic_vector(6-1 downto 0);
            
            o_tdrssi_rpt_done                   : out std_logic;
            o_tdrssi_rpt_data                   : out std_logic_array32(NUM_ANT-1 downto 0)
        );
    end component ulfe_tdrssi_rpt_oru;
    
    component ulfe_fdrssi_dbg_oru is
        generic (
            NUM_RX_ANT                          : integer := 2;
            NUM_PRE_PROCESSING                  : integer := 2;
            NUM_CHAIN_ANT                       : integer := 2
        );
        Port(
            i_rst                               : in std_logic;
            i_clk                               : in std_logic;
            
            i_uout_sync                         : in std_logic;
            i_uout_vld                          : in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_uout_iq                           : in std_logic_vector(NUM_RX_ANT*32-1 downto 0);
            
            i_tdd_sig                           : in std_logic;
            
            o_fdssi                             : out std_logic_array32(NUM_RX_ANT-1 downto 0)
        );
    end component ulfe_fdrssi_dbg_oru;
    
    component ulfe_dump_cc_oru is
        Generic(
            NUM_ANT                             : integer := 8
        );
        Port(
            i_rst                               : in std_logic;
            i_clk                               : in std_logic;
            
            i_fftType                           : in std_logic_vector(2-1 downto 0);
            i_fs_num                            : in std_logic_vector(5-1 downto 0);
            
            i_dump_td_fd                        : in std_logic;
            i_dump_Trigger                      : in std_logic;
            i_dump_frame                        : in std_logic_vector(2-1 downto 0);
            i_dump_ant                          : in std_logic_vector(3-1 downto 0);
            i_dump_slot                         : in std_logic_vector(6-1 downto 0);
            i_dump_symbol                       : in std_logic_vector(4-1 downto 0);
            
            i_frameidx                          : in std_logic_vector(2-1 downto 0);
            i_uin_sync                          : in std_logic;
            i_uin_iq                            : in std_logic_vector(NUM_ANT*32-1 downto 0);
            
            i_uout_sync                         : in std_logic;
            i_uout_vld                          : in std_logic_vector(NUM_ANT-1 downto 0);
            i_uout_iq                           : in std_logic_vector(NUM_ANT*32-1 downto 0);
            
            i_dump_rd_buf                       : in std_logic_vector(4-1 downto 0);
            i_dump_rd_addr                      : in std_logic_vector(16-1 downto 0);
            o_dump_rd_data                      : out std_logic_vector(64-1 downto 0);
            o_dump_done                         : out std_logic
        );
    end component ulfe_dump_cc_oru;
    
    ----------------------------------------------------------------------------------------------------------
    -- pre processing
    
    component ulfe_freqshift_oru is
        generic (
            NUM_RX_ANT                          : integer := 4
        );
        Port (
            i_rst                               : in std_logic;
            i_clk                               : in std_logic;
            
            i_FREQSHIFT_sync                    : in std_logic;
            i_FREQSHIFT_vld                     : in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_FREQSHIFT_i                       : in std_logic_vector(15-1 downto 0);
            i_FREQSHIFT_q                       : in std_logic_vector(15-1 downto 0);
            
            i_fftType                           : in std_logic_vector(2-1 downto 0);
            i_freqShiftOn                       : in std_logic;
            
            i_fs_num                            : in std_logic_vector(5-1 downto 0);
            
            o_sample_cnt                        : out std_logic_vector(13-1 downto 0);
            o_cp_size                           : out std_logic_vector(12-1 downto 0);
            
            o_FREQSHIFT_sync                    : out std_logic;
            o_FREQSHIFT_vld                     : out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_FREQSHIFT_i                       : out std_logic_vector(15-1 downto 0);
            o_FREQSHIFT_q                       : out std_logic_vector(15-1 downto 0)
        );
    end component ulfe_freqshift_oru;
    
    component ulfe_cal_cpSize_oru is
        Port (
            i_clk                               : in std_logic;
            
            i_fftType                           : in std_logic_vector(2-1 downto 0);
            i_slotIdx                           : in std_logic_vector(2-1 downto 0);
            i_symIdx                            : in std_logic_vector(4-1 downto 0);
            
            o_cpSize                            : out std_logic_vector(12-1 downto 0)
        );
    end component ulfe_cal_cpSize_oru;
    
    component ulfe_idx_counter_oru is
        Port (
            i_rst                               : in std_logic;
            i_clk                               : in std_logic;
            
            i_fftType                           : in std_logic_vector(2-1 downto 0);
            i_cpSize                            : in std_logic_vector(11-1 downto 0);
            
            i_frame_sync                        : in std_logic;
            
            i_fs_num                            : std_logic_vector(5-1 downto 0);
            
            o_sample_cnt                        : out std_logic_vector(13-1 downto 0);
            o_slotIdx                           : out std_logic_vector(8-1 downto 0);
            o_symIdx                            : out std_logic_vector(4-1 downto 0);
            o_slot_tick                         : out std_logic;
            o_sym_tick                          : out std_logic;
            o_fs_tick                           : out std_logic
        );
    end component ulfe_idx_counter_oru;
    
    component ulfe_cprm_oru is
        generic (
            NUM_RX_ANT                          : integer := 4
        );
        Port(
            i_rst                               : in std_logic;
            i_clk                               : in std_logic;
            
            i_sample_cnt                        : in std_logic_vector(13-1 downto 0);
            i_cp_size                           : in std_logic_vector(12-1 downto 0);
            
            i_CPRM_sync                         : in std_logic;
            i_CPRM_vld                          : in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_CPRM_i                            : in std_logic_vector(15-1 downto 0);
            i_CPRM_q                            : in std_logic_vector(15-1 downto 0);
            
            i_cpRmOffset                        : in std_logic_vector(11-1 downto 0);
            i_fftType                           : in std_logic_vector(2-1 downto 0);
            i_calBypassFlag                     : in std_logic;
            
            o_CPRM_sync                         : out std_logic;
            o_CPRM_vld                          : out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_CPRM_i                            : out std_logic_vector(15-1 downto 0);
            o_CPRM_q                            : out std_logic_vector(15-1 downto 0)
        );
    end component ulfe_cprm_oru;
    
    component ulfe_tdagc_oru is
        generic (
            NUM_RX_ANT                          : integer := 4
        );
        Port(
            i_rst                               : in std_logic;
            i_clk                               : in std_logic;
            
            i_fs_num                            : in std_logic_vector(5-1 downto 0);
            i_SR_info                           : in std_logic_vector(3-1 downto 0);            -- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76
            
            i_TDAGC_sync                        : in std_logic;
            i_TDAGC_vld                         : in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_TDAGC_i                           : in std_logic_vector(15-1 downto 0);
            i_TDAGC_q                           : in std_logic_vector(15-1 downto 0);
            
            i_fftType                           : in std_logic_vector(2-1 downto 0);
            
            i_calBypassFlag                     : in std_logic;
            i_tagcOn                            : in std_logic;
            i_tagcBackoff                       : in std_logic_vector(5-1 downto 0);
            
            o_TDAGC_sync                        : out std_logic;
            o_TDAGC_vld                         : out std_logic;
            o_TDAGC_vld_sync                    : out std_logic;
            o_TDAGC_i                           : out std_logic_vector(15-1 downto 0);
            o_TDAGC_q                           : out std_logic_vector(15-1 downto 0);
            
            o_tdGain_vld                        : out std_logic;
            o_tdGain1                           : out std_logic_array4(NUM_RX_ANT-1 downto 0);
            o_tdGain2                           : out std_logic_array5(NUM_RX_ANT-1 downto 0);
            o_tdrssi                            : out std_logic_array32(NUM_RX_ANT-1 downto 0)
        );
    end component ulfe_tdagc_oru;
    
    component ulfe_tdagc_cal_gain_oru is
        generic (
            NUM_RX_ANT                          : integer := 4
        );
        Port(
            i_clk                               : in std_logic;
            
            i_fs_num                            : in std_logic_vector(5-1 downto 0);
            i_SR_info                           : in std_logic_vector(3-1 downto 0);            -- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76
            
            i_TDAGC_sync                        : in std_logic;
            i_TDAGC_vld                         : in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_TDAGC_i                           : in std_logic_vector(15-1 downto 0);
            i_TDAGC_q                           : in std_logic_vector(15-1 downto 0);
            
            i_fftType                           : in std_logic_vector(2-1 downto 0);
            i_fftSize                           : in std_logic_vector(12-1 downto 0);
            
            i_mux_sel                           : in std_logic;
            i_tagcBackoff                       : in std_logic_vector(5-1 downto 0);
            
            o_tdGain_vld                        : out std_logic;
            o_tdGain1                           : out std_logic_array4(NUM_RX_ANT-1 downto 0);
            o_tdGain2                           : out std_logic_array5(NUM_RX_ANT-1 downto 0);
            o_tdrssi                            : out std_logic_array32(NUM_RX_ANT-1 downto 0)
        );
    end component ulfe_tdagc_cal_gain_oru;
    
    component ulfe_tdagc_lut_oru is
        Port (
            i_clk                               : in std_logic;
            
            i_addr                              : in std_logic_vector(5-1 downto 0);
            o_data                              : out std_logic_vector(10-1 downto 0)
        );
    end component ulfe_tdagc_lut_oru;
    
    component ulfe_fft_oru is
        generic (
            NUM_RX_ANT                          : integer := 4
        );
        Port(
            i_rst                               : in std_logic;
            i_clk                               : in std_logic;
            
            i_FFT_sync                          : in std_logic;
            i_FFT_vld_sync                      : in std_logic;
            i_FFT_vld                           : in std_logic;
            i_FFT_i                             : in std_logic_vector(15-1 downto 0);
            i_FFT_q                             : in std_logic_vector(15-1 downto 0);
            
            i_tdGain1                           : in std_logic_array4(NUM_RX_ANT-1 downto 0);
            i_tdGain2                           : in std_logic_array5(NUM_RX_ANT-1 downto 0);
            
            i_fftType                           : in std_logic_vector(2-1 downto 0);
            i_k0                                : in std_logic_vector(12-1 downto 0);
            i_rbSize                            : in std_logic_vector(9-1 downto 0);
            
            o_st_ext_i_data                     : out std_logic;
            o_data_vld_err                      : out std_logic;
            o_sync_unexpected                   : out std_logic;
            
            o_tdGain1                           : out std_logic_array4(NUM_RX_ANT-1 downto 0);
            o_tdGain2                           : out std_logic_array5(NUM_RX_ANT-1 downto 0);
            
            o_FFT_sync_adv_1clk                 : out std_logic;
            o_FFT_vld                           : out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_FFT_vld_adv_2clk                  : out std_logic;
            o_FFT_i                             : out std_logic_vector(15-1 downto 0);
            o_FFT_q                             : out std_logic_vector(15-1 downto 0)
        );
    end component ulfe_fft_oru;
    
    component nfft_wrapper_v2 is 
        generic (
            DEVICE                              : string := "ULTRASCALE";         -- "7SERIES" or "ULTRASCALE"
            COMB_SEL                            : string := "4096_2048_1024_512"; -- [ FFT Combination Selection         ] "4096_2048_1024_512"
            FFT_TYPE                            : string := "FFT";                -- [ Forward or Inverse FFT            ] "iFFT" or "FFT"
            DIR                                 : string := "DIF";                -- [ FFT Direction                     ] "DIF" or "DIT"
            N_DSP48_PER_CMULT                   : string := "THREE";              -- [ Number of DSP48E per Complex Mult ] "THREE" or "FOUR"
            XTREME_DSP_MODE                     : boolean := false;               -- [ Xtreme dsp mode                   ] false or true
            HALF_FFT_SHIFT                      : boolean := false;               -- [ Half N_FFT Shift on Output Order  ] false or true Not Avaiable for DIF or XTREAME_DSP_MODE
            IN_WIDTH                            : integer := 16;                  -- [ Input Data Bit Width Parameter    ]
            OUT_WIDTH                           : integer := 16);                 -- [ Output Data Bit Width Parameter   ] OUT_WIDTH = IN_WIDTH
        port (
            I_RSTB                              : in std_logic;                   -- Synchronous Active High Reset
            I_CLK                               : in std_logic;                   -- System Clock
            -- *************************************************************
            -- INPUT DATA
            -- *************************************************************
            I_DATA_SYNC                         : in std_logic;                   -- 1 clk cycle prior to input data [idx 0]
            I_DATA_VLD                          : in std_logic;                   -- input data aligned enable
            I_DATA_I                            : in std_logic_vector((IN_WIDTH-1) downto 0);    -- input data i
            I_DATA_Q                            : in std_logic_vector((IN_WIDTH-1) downto 0);    -- input data q
            -- *************************************************************
            -- Control DATA
            -- *************************************************************      -- [I_nFFT_TYPE] received on [I_DATA_SYNC]	
            I_nFFT_TYPE                         : in std_logic_vector(1 downto 0);-- "00" = 512, "01" = 1024, "10" = 2048, "11" = 4096, 
            -- *************************************************************
            -- OUTPUT DATA
            -- *************************************************************
            O_DATA_SYNC                         : out std_logic;                                   -- 1 clk cycle prior to input data [idx 0]
            O_DATA_VLD                          : out std_logic;                                   -- output data aligned enable
            O_DATA_IDX                          : out std_logic_vector(11 downto 0);               -- output data index
            O_DATA_I                            : out std_logic_vector((OUT_WIDTH-1) downto 0);    -- output data i
            O_DATA_Q                            : out std_logic_vector((OUT_WIDTH-1) downto 0);    -- output data q
            O_DATA_LAST                         : out std_logic;	
            -- *************************************************************
            -- STATUS DATA
            -- *************************************************************	
            O_STATUS_EXTENDED_INPUT_DATA                    : out std_logic;    -- given input data is longer than expected, then extended data just ignored
            O_EVENT_I_DATA_VLD_SHORT_OR_DISCOUNTINUED       : out std_logic;    -- given input data is shorter or discounited, then system halt 
            O_EVENT_I_SYNC_UNEXPECTED                       : out std_logic);   -- given input sync is too early, then ignore previous symbol, restart with current symbol  
    end component nfft_wrapper_v2;
    
    component ulfe_gaincomp_oru is
        generic (
            NUM_RX_ANT                      : integer := 4
        );
        Port(
            i_rst                           : in std_logic;
            i_clk                           : in std_logic;
            
            i_gainCompOn                    : in std_logic;
            i_calBypassFlag                 : in std_logic;
            
            i_GAINCOMP_sync_adv_1clk        : in std_logic;
            i_GAINCOMP_vld                  : in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_GAINCOMP_vld_adv_2clk         : in std_logic;
            i_GAINCOMP_i                    : in std_logic_vector(15-1 downto 0);
            i_GAINCOMP_q                    : in std_logic_vector(15-1 downto 0);
            
            i_tdGain1                       : in std_logic_array4(NUM_RX_ANT-1 downto 0);
            i_tdGain2                       : in std_logic_array5(NUM_RX_ANT-1 downto 0);
            
            o_GAINCOMP_sync                 : out std_logic;
            o_GAINCOMP_vld_adv_5clk         : out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_GAINCOMP_ant_num              : out std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
            o_GAINCOMP_i                    : out std_logic_vector(15-1 downto 0);
            o_GAINCOMP_q                    : out std_logic_vector(15-1 downto 0)
        );
    end component ulfe_gaincomp_oru;
    
    component ulfe_gaincomp_lut_oru is
        Port ( 
            i_clk                           : in std_logic;
            
            i_addr                          : in std_logic_vector(5-1 downto 0);
            o_data                          : out std_logic_vector(10-1 downto 0)
        );
    end component ulfe_gaincomp_lut_oru;
    
    component ulfe_calb_oru is
        generic (
            NUM_RX_ANT                      : integer := 4;
            NUM_CHAIN                       : integer := 0
        );
        Port(
            i_rst                           : in std_logic;
            i_clk                           : in std_logic;
            
            i_CALB_sync                     : in std_logic;
            i_CALB_vld_adv_5clk             : in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_CALB_ant_num                  : in std_logic_vector(log2ceil(NUM_RX_ANT)-1 downto 0);
            i_CALB_i                        : in std_logic_vector(15-1 downto 0);
            i_CALB_q                        : in std_logic_vector(15-1 downto 0);
            
            i_calOn                         : in std_logic;
            i_calBypassFlag                 : in std_logic;
            i_calWScale                     : in std_logic_vector(4-1 downto 0);
            
            i_calW_rd_wt_sel                : in std_logic;
            i_calW_wt_buf                   : in std_logic;
            i_calW_ant_num                  : in std_logic_vector(6-1 downto 0);
            i_calW_wt_en                    : in std_logic;
            i_calW_wt_addr                  : in std_logic_vector(9-1 downto 0);    -- #0~272RB
            i_calW_iq                       : in std_logic_vector(24-1 downto 0);
            o_calW_rd_data                  : out std_logic_vector(24-1 downto 0);
            
            o_CALB_sync                     : out std_logic;
            o_CALB_vld_adv_5clk             : out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_CALB_i                        : out std_logic_vector(15-1 downto 0);
            o_CALB_q                        : out std_logic_vector(15-1 downto 0)
        );
    end component ulfe_calb_oru;
    
    component ulfe_cts_oru is
        generic (
            NUM_RX_ANT                      : integer := 4
        );
        Port(
            i_rst                           : in std_logic;
            i_clk                           : in std_logic;
            
            i_CTS_sync                      : in std_logic;
            i_CTS_vld_adv_5clk              : in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_CTS_i                         : in std_logic_vector(15-1 downto 0);
            i_CTS_q                         : in std_logic_vector(15-1 downto 0);
            
            i_calBypassFlag                 : in std_logic;
            i_ctsOn                         : in std_logic;
            i_ctsShift                      : in std_logic_vector(12-1 downto 0);
            
            o_CTS_sync_adv_5clk             : out std_logic;
            o_CTS_vld                       : out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_CTS_i                         : out std_logic_vector(15-1 downto 0);
            o_CTS_q                         : out std_logic_vector(15-1 downto 0)
        );
    end component ulfe_cts_oru;
    
    component ulfe_phasecomp_oru is
        generic (
            NUM_RX_ANT                      : integer := 4
        );
        Port(
            i_rst                           : in std_logic;
            i_clk                           : in std_logic;
            
            i_PHASECOMP_frameidx            : in std_logic_vector(8-1 downto 0);
            i_PHASECOMP_sync_adv_5clk       : in std_logic;
            i_PHASECOMP_vld                 : in std_logic_vector(NUM_RX_ANT-1 downto 0);
            i_PHASECOMP_i                   : in std_logic_vector(15-1 downto 0);
            i_PHASECOMP_q                   : in std_logic_vector(15-1 downto 0);
            
            i_calBypassFlag                 : in std_logic;
            i_phaseCompOn                   : in std_logic;
            i_phaseCompBypass               : in std_logic;
            
            i_phasecomp_weight_i            : in std_logic_vector(16-1 downto 0);
            i_phasecomp_weight_q            : in std_logic_vector(16-1 downto 0);
            
            o_PHASECOMP_frameidx            : out std_logic_vector(8-1 downto 0);
            o_PHASECOMP_subframeidx         : out std_logic_vector(4-1 downto 0);
            o_PHASECOMP_slotidx             : out std_logic_vector(6-1 downto 0);
            o_PHASECOMP_symbol_sync         : out std_logic;
            o_PHASECOMP_symidx              : out std_logic_vector(4-1 downto 0);
            o_PHASECOMP_sync                : out std_logic;
            o_PHASECOMP_vld                 : out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_PHASECOMP_start_re            : out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_PHASECOMP_last_re             : out std_logic_vector(NUM_RX_ANT-1 downto 0);
            o_PHASECOMP_i                   : out std_logic_vector(16-1 downto 0);
            o_PHASECOMP_q                   : out std_logic_vector(16-1 downto 0)
        );
    end component ulfe_phasecomp_oru;

    ----------------------------------------------------------------------------------------------------------------
    -- LIBRARY -----------------------------------------------------------------------------------------------------
    component ulfe_lib_expj_v2 is
        generic(
            conjugate                       : std_logic := '0';
            phase_b_width                   : integer := 14            -- 12 or 14
        );
        Port ( 
            i_clk                           : in std_logic;
            
            i_data                          : in std_logic_vector(phase_b_width-1 downto 0);
            
            o_cos                           : out std_logic_vector(16-1 downto 0);
            o_sin                           : out std_logic_vector(16-1 downto 0)
        );
    end component ulfe_lib_expj_v2;
    
    component ulfe_lib_dly_fixed is
        generic (
            delay_num                       : integer := 2;
            data_i_width                    : integer := 16
        );
        port ( 
            i_clk                           : in std_logic;
            
            data_i                          : in std_logic_vector(data_i_width-1 downto 0);
            data_o                          : out std_logic_vector(data_i_width-1 downto 0)
        );
    end component ulfe_lib_dly_fixed;

    component ulfe_lib_C_multi_v2 is
        generic(
            width_a                         : integer := 15;
            width_b                         : integer := 16;
            width_p                         : integer := 31
        );
        
        Port (
            i_clk                           : in std_logic;
            
            i_real_data_A                   : in std_logic_vector(width_a-1 downto 0);	-- a
            i_img_data_A                    : in std_logic_vector(width_a-1 downto 0);	-- b
            
            i_real_data_B                   : in std_logic_vector(width_b-1 downto 0);	-- c
            i_img_data_B                    : in std_logic_vector(width_b-1 downto 0);	-- d
            
            o_real_data                     : out std_logic_vector(width_p-1 downto 0);
            o_img_data                      : out std_logic_vector(width_p-1 downto 0)
        );
    end component ulfe_lib_C_multi_v2;
    
    component ylib_sshftd_sat
        generic(
            IB                              : integer :=  33;
            SF                              : integer :=  15;
            OB                              : integer :=  16;
            ROUND_TYPE                      : string :=  "SYMMETRIC_ROUND";
            SAT_TYPE                        : string :=  "SYMMETRIC"
        );
        port(
            i_clk                           : in std_logic;
            
            i_din_vld                       : in std_logic;
            i_din                           : in std_logic_vector(IB-1 downto 0);
            
            o_dout_vld                      : out std_logic;
            o_dout                          : out std_logic_vector(OB-1 downto 0)
        );
    end component ylib_sshftd_sat;
    
    component ylib_sshftvd_sat
        generic(
            IB                              : integer :=  33;
            SB                              : integer :=  4;
            OB                              : integer :=  16;
            ROUND_TYPE                      : string :=  "SYMMETRIC_ROUND";
            SAT_TYPE                        : string :=  "SYMMETRIC"
        );
        port(
            i_clk                           : in std_logic;
            
            i_shft                          : in std_logic_vector(SB-1 downto 0);
            i_din_vld                       : in std_logic;
            i_din                           : in std_logic_vector(IB-1 downto 0);
            
            o_dout_vld                      : out std_logic;
            o_dout                          : out std_logic_vector(OB-1 downto 0)
        );
    end component ylib_sshftvd_sat;
    
    component ulfe_lib_dly_variable is
        generic (
            data_i_width                    : integer := 16
        );
        port ( 
            i_rst                           : in std_logic;
            i_clk                           : in std_logic;
            dly_value                       : in std_logic_vector(data_i_width -1 downto 0);
            
            i_tick                          : in std_logic;
            o_tick                          : out std_logic
        );
    end component ulfe_lib_dly_variable;
    
    component ulfe_lib_dsp_multi_add_v2 is
        generic(
            pcin_enable                     : std_logic := '1';
            width_a                         : integer := 15;
            width_b                         : integer := 15;
            width_c                         : integer := 41;
            width_p                         : integer := 41
        );
        port(
            i_clk                           : in std_logic;
            reg_sel                         : in std_logic;	-- '0' preg, '1' creg
            reg_control_sig                 : in std_logic;
            
            dsp_a                           : in std_logic_vector(width_a-1 downto 0);
            dsp_b                           : in std_logic_vector(width_b-1 downto 0);
            dsp_c                           : in std_logic_vector(width_c-1 downto 0);
            dsp_pcin                        : in std_logic_vector(48-1 downto 0);
            
            dsp_p                           : out std_logic_vector(width_p-1 downto 0);
            dsp_pcout                       : out std_logic_vector(48-1 downto 0)
        );
    end component ulfe_lib_dsp_multi_add_v2;
    
    component ulfe_lib_symm_sat is
        generic(
            d_width                         : integer := 16;
            sat_width                       : integer := 15
        );
        Port (
            i_clk                           : in std_logic;
            
            i_data                          : in std_logic_vector(d_width-1 downto 0);
            o_data                          : out std_logic_vector(sat_width-1 downto 0)
        );
    end component ulfe_lib_symm_sat;
    
    component ulfe_lib_sdpram is
        generic (
            memory_primitive                : string := "block";
            read_latency                    : integer := 2;
            wt_mem_d_width                  : integer := 30;
            rd_mem_d_width                  : integer := 60;
            wt_max_addr                     : integer := 2048;
            rd_max_addr                     : integer := 1024
        );
        Port (
            i_clk                           : in std_logic; 
            
            i_wt_enable                     : in std_logic;
            i_wt_addr                       : in std_logic_vector(log2ceil(wt_max_addr)-1 downto 0);
            i_wt_data                       : in std_logic_vector(wt_mem_d_width-1 downto 0);
            
            i_rd_addr                       : in std_logic_vector(log2ceil(rd_max_addr)-1 downto 0);
            o_rd_dout                       : out std_logic_vector(rd_mem_d_width-1 downto 0)
        );
    end component ulfe_lib_sdpram;
    
    component ulfe_lib_tdpram is
        generic (
            memory_primitive                : string := "block";
            read_latency                    : integer := 2;
            wt_mem_d_width                  : integer := 30;
            rd_mem_d_width                  : integer := 60;
            wt_max_addr                     : integer := 2048;
            rd_max_addr                     : integer := 1024
        );
        Port (
            i_clk                           : in std_logic; 
            
            i_wt_enable                     : in std_logic;
            i_wt_addra                      : in std_logic_vector(log2ceil(wt_max_addr)-1 downto 0);
            i_wt_data                       : in std_logic_vector(wt_mem_d_width-1 downto 0);
            o_rd_douta                      : out std_logic_vector(rd_mem_d_width-1 downto 0);
            
            i_rd_addrb                      : in std_logic_vector(log2ceil(rd_max_addr)-1 downto 0);
            o_rd_doutb                      : out std_logic_vector(rd_mem_d_width-1 downto 0)
        );
    end component ulfe_lib_tdpram;
    
    component ulfe_lib_tdpram_distribute is
        generic (
            memory_primitive                : string := "block";
            read_latency                    : integer := 2;
            wt_mem_d_width                  : integer := 30;
            rd_mem_d_width                  : integer := 60;
            wt_max_addr                     : integer := 2048;
            rd_max_addr                     : integer := 1024
        );
        Port (
            i_clk                           : in std_logic; 
            
            i_wt_enable                     : in std_logic;
            i_wt_addra                      : in std_logic_vector(log2ceil(wt_max_addr)-1 downto 0);
            i_wt_data                       : in std_logic_vector(wt_mem_d_width-1 downto 0);
            o_rd_douta                      : out std_logic_vector(rd_mem_d_width-1 downto 0);
            
            i_rd_addrb                      : in std_logic_vector(log2ceil(rd_max_addr)-1 downto 0);
            o_rd_doutb                      : out std_logic_vector(rd_mem_d_width-1 downto 0)
        );
    end component ulfe_lib_tdpram_distribute;
    
    component ulfe_lib_dsp_CR is
        generic(
            width_a                         : integer := 27;
            width_b                         : integer := 11;
            width_p                         : integer := 38
        );
        port(
            i_clk                           : in  std_logic;
            
            dsp_a                           : in  std_logic_vector(width_a-1 downto 0);
            dsp_b                           : in  std_logic_vector(width_b-1 downto 0);
            
            dsp_p                           : out std_logic_vector(width_p-1 downto 0)
        );
    end component ulfe_lib_dsp_CR;
    
    component ulfe_lib_lzc_16 is
        Port(
            i_clk                           : in std_logic;
            
            i_data                          : in std_logic_vector(16-1 downto 0);
            o_q                             : out std_logic_vector(4-1 downto 0)
        );
    end component ulfe_lib_lzc_16;

end ulfe_component_pack_oru;

package body ulfe_component_pack_oru is

end ulfe_component_pack_oru;
