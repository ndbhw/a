library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

package ulfe_config_oru is

    constant  PBA_NAME                          : string := "RF2240-11B";
    constant  DUPLEX_TYPE                       : string := "FDD";
    
    constant  SYSTEM_CLK                        : real := 245.76;
    constant  MAX_SAMPLE_RATE                   : real := 122.88;
    constant  MAX_TIME_MUX                      : integer := integer(SYSTEM_CLK/MAX_SAMPLE_RATE);
    
    -- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76
    constant  MIN_SAMPLE_RATE                   : integer := 1;
    
    constant  RPT_TDRSSI_ENABLE                 : boolean := FALSE;             -- TRUE, FALSE
    
    constant  DBG_TDRSSI_ENABLE                 : boolean := TRUE;              -- TRUE, FALSE
    constant  DBG_FDRSSI_ENABLE                 : boolean := TRUE;              -- TRUE, FALSE
    constant  DBG_DUMP_ENABLE                   : boolean := TRUE;        	    -- TRUE, FALSE
    
    constant  CALB_MODULE                       : boolean := FALSE;             -- TRUE, FALSE
    
    constant  SCSTYPE                           : integer := 0;                 -- 0, 1, 2
    constant  LTE_NR_MODE                       : string  := "BOTH";              -- "LTE" or "NR" or "BOTH"
    constant  CPTYPE                            : string  := "normal";          -- "normal" or "extened"
    
    constant  MAX_FFT_SIZE                      : integer := 2048;              -- 512, 1024, 2048, 4096
    constant  FFT_MODE                          : string := "DIT";              -- "DIT", "DIF"
    constant  FFT_HALF_MODE                     : boolean := TRUE;              -- TRUE, FALSE
    
    constant  VERSION                           : std_logic_vector(8-1 downto 0) := X"02";
    -------------------------------------------------------------------------------------------------------------------
    
    type std_logic_array2                       is array(natural range <>) of std_logic_vector(2-1 downto 0);
    type std_logic_array3                       is array(natural range <>) of std_logic_vector(3-1 downto 0);
    type std_logic_array4                       is array(natural range <>) of std_logic_vector(4-1 downto 0);
    type std_logic_array5                       is array(natural range <>) of std_logic_vector(5-1 downto 0);
    type std_logic_array6                       is array(natural range <>) of std_logic_vector(6-1 downto 0);
    type std_logic_array8                       is array(natural range <>) of std_logic_vector(8-1 downto 0);
    type std_logic_array9                       is array(natural range <>) of std_logic_vector(9-1 downto 0);
    type std_logic_array11                      is array(natural range <>) of std_logic_vector(11-1 downto 0);
    type std_logic_array12                      is array(natural range <>) of std_logic_vector(12-1 downto 0);
    type std_logic_array15                      is array(natural range <>) of std_logic_vector(15-1 downto 0);
    type std_logic_array16                      is array(natural range <>) of std_logic_vector(16-1 downto 0);
    type std_logic_array24                      is array(natural range <>) of std_logic_vector(24-1 downto 0);
    type std_logic_array30                      is array(natural range <>) of std_logic_vector(30-1 downto 0);
    type std_logic_array32                      is array(natural range <>) of std_logic_vector(32-1 downto 0);
    type std_logic_array42                      is array(natural range <>) of std_logic_vector(42-1 downto 0);
    type std_logic_array48                      is array(natural range <>) of std_logic_vector(48-1 downto 0);
    type std_logic_array64                      is array(natural range <>) of std_logic_vector(64-1 downto 0);

end ulfe_config_oru;

package body ulfe_config_oru is

end ulfe_config_oru;