-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- Project Name		: Custom FFT V2
-- File Name		: fft_dif_4096_2048_1024_512.vhd
-- Date				: 2022.10.18
-- Revision			: 2
-- Engineer			: Jihoon Han
-- Company			: Samsung Electronics
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Functional Description
-- Available for 4096/2048/1024/512 FFT Size
-- Natural Order Input => Bit Reverse Order Output
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Revision History    
-- [2022.10.08, v1.00, jihoon.han] initial release DIF 4096/1024 Cross-Check        
-- [2022.10.18, v1.10, jihoon.han] DIF 2048/512 Cross-Check       
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
library ieee; use ieee.std_logic_1164.all; use ieee.std_logic_signed.all;
use work.RU_FPGA_FNC.all;

-------------------------------------------------------------------------------------------------------------------------------
entity fft_dif_4096_2048_1024_512 is 
	generic (
	    DEVICE          	: string  	:= "ULTRASCALE";	-- "7SERIES" or "ULTRASCALE"
		FFT_TYPE			: string 	:= "FFT";  			-- [ Forward or Inverse FFT			 	] "iFFT" or "FFT"
		N_DSP48_PER_CMULT   : string	:= "FOUR";			-- [ Number of DSP48E per Complex Mult 	] "THREE" or "FOUR"	
		XTREME_DSP_MODE		: boolean	:= false;			-- [ Extreme dsp mode					] false or true 
		IN_WIDTH			: integer 	:= 16;				-- [ Input Data Bit Width Parameter  	]  
		OUT_WIDTH			: integer 	:= 16);				-- [ Output Data Bit Width Parameter  	]  
	port (
		I_RSTB			: in std_logic; 	
		I_CLK			: in std_logic;	
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************		
		I_SYNC			: in std_logic;
		I_DATA_RE	  	: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM	  	: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_NFFT_SEL		: in std_logic_vector(1 downto 0);	-- "00" = 512, "01" = 1024, "10" = 2048, "11" = 4096, 
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************	
		O_SYNC			: out std_logic;			
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
end fft_dif_4096_2048_1024_512;
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
architecture struct of fft_dif_4096_2048_1024_512 is

	component r22_sdf_v2
	generic (
	    DEVICE          	: string  	:= "ULTRASCALE"; 	-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE		: boolean	:= false;			-- [ Extreme dsp mode					] false or true 
		DIR					: string	:= "DIF";			-- [ FFT Direction					] "DIF" or "DIT"		
		IN_WIDTH			: integer;						-- [ Input Data Bit Width Parameter  ]                
		N_SIZE				: integer;						-- [ FFT Point Size Parameter        ] 
		OSYNC_DELAY			: integer);						-- [ O_SYNC Timing Delay Parameter	 ]     
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB			: in std_logic; 	-- system reset(low activated)
		I_CLK			: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_SYNC			: in std_logic;
		I_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_SYNC			: out std_logic;
		O_DATA_RE		: out std_logic_vector((IN_WIDTH+1) downto 0);
		O_DATA_IM		: out std_logic_vector((IN_WIDTH+1) downto 0));
	end component;
	
	component hybrid_r22_sdf_v2
	generic (
	    DEVICE          	: string  	:= "ULTRASCALE"; 	-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE		: boolean	:= false;			-- [ Extreme dsp mode					] false or true 
		DIR					: string	:= "DIF";			-- [ FFT Direction					] "DIF" or "DIT"	
		HALF_FFT_SHIFT		: boolean	:= false;			-- [ Half N_FFT Shift on Output Order(DIT Only)	] false or true
		IN_WIDTH			: integer;						-- [ Input Data Bit Width Parameter  ]                
		N_SIZE				: integer;						-- [ FFT Point Size Parameter        ] 
		LAST_IND			: boolean	:= false;			-- [ LAST SDF Indicator				] false or true
		OSYNC_DELAY			: integer);						-- [ O_SYNC Timing Delay Parameter	 ]       
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB			: in std_logic; 	-- system reset(low activated)
		I_CLK			: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_SYNC			: in std_logic;
		I_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_CTRL_MODE		: in std_logic;			-- '0' = Radix-2 , '1' = Radix-2^2, 
		I_LAST_CTRL		: in std_logic_vector; 	-- "00" = no last, "01" = bfi last, "10" = bfii last, 
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_SYNC			: out std_logic;
		O_DATA_RE		: out std_logic_vector((IN_WIDTH+1) downto 0);
		O_DATA_IM		: out std_logic_vector((IN_WIDTH+1) downto 0));
	end component;	
		
	component hybrid_tw_phaser_v2
	generic (
		DEVICE          : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    	CMULT_N_DSP48   : natural := 		3; 		-- 3 or 4
	    RAM_TYPE      	: string  := "block"; -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  : string  := "read_first"; -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   : string  := "none"        ; 
		IN_WIDTH		: integer := 15;	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		: integer;			-- [ Output Data Bit Width Parameter ]
		N_FFT			: integer := 4096;			
		TW_WIDTH		: integer := 16;			
		TW_LATENCY		: integer := 2;				
		OSYNC_TIMING	: integer := 10);
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB				: in std_logic; 	-- system reset(low activated)
		I_CLK				: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_SYNC				: in std_logic;
		I_DATA_RE			: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM			: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_CTRL_MODE		: in std_logic;	-- '0' = Radix-2 , '1' = Radix-2^2, 
		-- *************************************************************
		-- Common Mult IO
		-- *************************************************************
		I_DATA_X181_RE		: in std_logic_vector(IN_WIDTH downto 0);
		I_DATA_X181_IM		: in std_logic_vector(IN_WIDTH downto 0);
		O_DATA_X181_RE		: out std_logic_vector(IN_WIDTH downto 0);
		O_DATA_X181_IM		: out std_logic_vector(IN_WIDTH downto 0);
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_SYNC			: out std_logic;
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
	end component;
	
	component tw_phaser_v2
	generic (
		DEVICE                      : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
		BF_TYPE			: string  := "Radix22"; 	-- "Radix22" or "Radix2"  
    	CMULT_N_DSP48   : natural := 		3; 		-- 3 or 4
	    RAM_TYPE      	: string  := "block"; -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  : string  := "read_first"; -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   : string  := "none"        ; 
		IN_WIDTH		: integer := 15;	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		: integer;			-- [ Output Data Bit Width Parameter ]
		N_FFT			: integer := 4096;			
		TW_WIDTH		: integer := 16;			
		TW_LATENCY		: integer := 2;				
		OSYNC_TIMING	: integer := 10);
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB			: in std_logic; 	-- system reset(low activated)
		I_CLK			: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_SYNC			: in std_logic;
		I_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_SYNC			: out std_logic;
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
	end component;
	
	component com_mults
	generic (
		DEVICE     		: string  := "ULTRASCALE"; 	-- "7SERIES" or "ULTRASCALE"    
		IN_WIDTH		: integer := 19;			-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		: integer := 16				-- [ Output Data Bit Width Parameter ]	
	);
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_CLK				: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_STG6_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_STG6_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_STG5_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_STG5_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_NFFT_SEL		: in std_logic_vector(1 downto 0);	-- "00" = 512, "01" = 1024, "10" = 2048, "11" = 4096, 
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
	end component;
	
	component norm4
	generic (
		IN_WIDTH		: integer := 18;			-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		: integer := 16				-- [ Output Data Bit Width Parameter ]	
	);
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_CLK				: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_DATA_RE			: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM			: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
	end component;
	
	constant FFT_DIR			: string := "DIF";			
	constant nIFFT_FFT_SEL      : boolean := ternary_func(FFT_TYPE = "FFT", true, false);    
	constant N_DSP48_XTREME_CHECK : string := ternary_func(XTREME_DSP_MODE = false, N_DSP48_PER_CMULT, "FOUR");
	constant CMULT_N_DSP48		: natural := ternary_func(N_DSP48_XTREME_CHECK = "THREE", 3, 4);
	constant STG6_IN_WIDTH 		: integer := IN_WIDTH;
	constant STG5_IN_WIDTH 		: integer := IN_WIDTH;
	constant STG4_IN_WIDTH 		: integer := IN_WIDTH;
	constant STG3_IN_WIDTH 		: integer := IN_WIDTH;
	constant STG2_IN_WIDTH 		: integer := IN_WIDTH;
	constant STG1_IN_WIDTH 		: integer := IN_WIDTH;
	
	constant STG6_N_SIZE	: integer := 4096;
	constant STG5_N_SIZE	: integer := 1024;
	constant STG4_N_SIZE	: integer := 256;
	constant STG3_N_SIZE	: integer := 64;
	constant STG2_N_SIZE	: integer := 16;
	constant STG1_N_SIZE	: integer := 4;
	
	constant R2_SDF_O_SYNC_TIMING						: integer := ternary_func(XTREME_DSP_MODE = true, -1, -5); 
	constant R22_SDF_O_SYNC_TIMING						: integer := ternary_func(XTREME_DSP_MODE = true, 2, -5); 
	constant HYBRID_TW_PHASER_O_SYNC_TIMING_FOUR_DSP	: integer := ternary_func(XTREME_DSP_MODE = true, 10, 11);   
	constant TW_PHASER_O_SYNC_TIMING_FOUR_DSP			: integer := ternary_func(XTREME_DSP_MODE = true, 9, 10);   
	constant HYBRID_TW_PHASER_O_SYNC_TIMING_THREE_DSP	: integer := ternary_func(XTREME_DSP_MODE = true, 11, 12);  
	constant TW_PHASER_O_SYNC_TIMING_THREE_DSP			: integer := ternary_func(XTREME_DSP_MODE = true, 10, 11); 
	constant DIF_STG1_R22_SDF_O_SYNC_TIMING				: integer := 2; 
	constant DIT_R22_SDF_O_SYNC_TIMING					: integer := -4; 
	constant STG1_R22_SDF_O_SYNC_TIMING					: integer := ternary_func(FFT_DIR = "DIF", DIF_STG1_R22_SDF_O_SYNC_TIMING, DIT_R22_SDF_O_SYNC_TIMING); 
	
	constant R2_TW_PHASER_O_SYNC_TIMING	: integer := ternary_func(N_DSP48_XTREME_CHECK = "THREE", 11, 10); 
	constant HYBRID_TW_PHASER_O_SYNC_TIMING	: integer := ternary_func(N_DSP48_XTREME_CHECK = "THREE", HYBRID_TW_PHASER_O_SYNC_TIMING_THREE_DSP, HYBRID_TW_PHASER_O_SYNC_TIMING_FOUR_DSP);   
	constant TW_PHASER_O_SYNC_TIMING	: integer := ternary_func(N_DSP48_XTREME_CHECK = "THREE", TW_PHASER_O_SYNC_TIMING_THREE_DSP, TW_PHASER_O_SYNC_TIMING_FOUR_DSP);   
	constant LAST_TW_PHASER_O_SYNC_TIMING	: integer := ternary_func(N_DSP48_XTREME_CHECK = "THREE", 11, 10);   

	signal stg6_radix2_radix22_sel	: std_logic;
	signal stg5_radix2_radix22_sel	: std_logic;
	signal di_mux					: std_logic;
	
	signal stg6_isync		: std_logic;
	signal stg6_di_re		: std_logic_vector((STG6_IN_WIDTH-1) downto 0);
	signal stg6_di_im		: std_logic_vector((STG6_IN_WIDTH-1) downto 0);
	signal stg6_osync		: std_logic;
	signal stg6_do_re		: std_logic_vector((STG6_IN_WIDTH+1) downto 0);
	signal stg6_do_im		: std_logic_vector((STG6_IN_WIDTH+1) downto 0);
	signal tw6_osync		: std_logic;
	signal tw6_do_re		: std_logic_vector((STG5_IN_WIDTH-1) downto 0);
	signal tw6_do_im		: std_logic_vector((STG5_IN_WIDTH-1) downto 0);
	signal stg5_isync		: std_logic;
	signal stg5_di_re		: std_logic_vector((STG5_IN_WIDTH-1) downto 0);
	signal stg5_di_im		: std_logic_vector((STG5_IN_WIDTH-1) downto 0);
	signal stg5_osync		: std_logic;
	signal stg5_do_re		: std_logic_vector((STG5_IN_WIDTH+1) downto 0);
	signal stg5_do_im		: std_logic_vector((STG5_IN_WIDTH+1) downto 0);
	signal tw5_osync		: std_logic;                                   
	signal tw5_do_re		: std_logic_vector((STG4_IN_WIDTH-1) downto 0);
	signal tw5_do_im		: std_logic_vector((STG4_IN_WIDTH-1) downto 0);
	signal stg4_osync		: std_logic;
	signal stg4_do_re		: std_logic_vector((STG4_IN_WIDTH+1) downto 0);
	signal stg4_do_im		: std_logic_vector((STG4_IN_WIDTH+1) downto 0);
	signal tw4_osync		: std_logic;                                   
	signal tw4_do_re		: std_logic_vector((STG3_IN_WIDTH-1) downto 0);
	signal tw4_do_im		: std_logic_vector((STG3_IN_WIDTH-1) downto 0);
	signal stg3_osync		: std_logic;
	signal stg3_do_re		: std_logic_vector((STG3_IN_WIDTH+1) downto 0);
	signal stg3_do_im		: std_logic_vector((STG3_IN_WIDTH+1) downto 0);
	signal tw3_osync		: std_logic;                                   
	signal tw3_do_re		: std_logic_vector((STG2_IN_WIDTH-1) downto 0);
	signal tw3_do_im		: std_logic_vector((STG2_IN_WIDTH-1) downto 0);
	signal stg2_osync		: std_logic;
	signal stg2_do_re		: std_logic_vector((STG2_IN_WIDTH+1) downto 0);
	signal stg2_do_im		: std_logic_vector((STG2_IN_WIDTH+1) downto 0);
	signal tw2_osync		: std_logic;                                   
	signal tw2_do_re		: std_logic_vector((STG1_IN_WIDTH-1) downto 0);
	signal tw2_do_im		: std_logic_vector((STG1_IN_WIDTH-1) downto 0);
	signal stg1_osync		: std_logic;
	signal stg1_do_re		: std_logic_vector((STG1_IN_WIDTH+1) downto 0);
	signal stg1_do_im		: std_logic_vector((STG1_IN_WIDTH+1) downto 0);
	signal last_norm4_do_re		: std_logic_vector((STG1_IN_WIDTH-1) downto 0);
	signal last_norm4_do_im		: std_logic_vector((STG1_IN_WIDTH-1) downto 0);
	
	signal di_data_xi81_re : std_logic_vector((IN_WIDTH+2) downto 0);
	signal di_data_xi81_im : std_logic_vector((IN_WIDTH+2) downto 0);
	signal do_stg6_data_xi81_re : std_logic_vector((STG6_IN_WIDTH+2) downto 0);
	signal do_stg6_data_xi81_im : std_logic_vector((STG6_IN_WIDTH+2) downto 0);
	signal do_stg5_data_xi81_re : std_logic_vector((STG5_IN_WIDTH+2) downto 0);
	signal do_stg5_data_xi81_im : std_logic_vector((STG5_IN_WIDTH+2) downto 0);
	
begin
		
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			stg6_radix2_radix22_sel <= I_NFFT_SEL(0);
			stg5_radix2_radix22_sel <= I_NFFT_SEL(1) or I_NFFT_SEL(0);
			di_mux <= I_NFFT_SEL(1);
		end if;
	end process;	
	
	g_FFT_IN : if nIFFT_FFT_SEL = true generate -- FFT
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if di_mux = '1' then
				stg6_isync <= I_SYNC;
				stg6_di_re <= I_DATA_RE;
				stg6_di_im <= I_DATA_IM;
			else
				stg6_isync <= '0';
				stg6_di_re <= (others => '0');
				stg6_di_im <= (others => '0');
			end if;
			
			if di_mux = '0' then
				stg5_isync <= I_SYNC;
				stg5_di_re <= I_DATA_RE;
				stg5_di_im <= I_DATA_IM;
			else 
				stg5_isync <= tw6_osync;
				stg5_di_re <= tw6_do_re;
				stg5_di_im <= tw6_do_im;
			end if;				
		end if;
	end process;
    end generate;
    
    g_iFFT_IN : if nIFFT_FFT_SEL = false generate -- iFFT
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if di_mux = '1' then
				stg6_isync <= I_SYNC;
				stg6_di_re <= I_DATA_RE;
				stg6_di_im <= (not I_DATA_IM) + 1;
			else
				stg6_isync <= '0';
				stg6_di_re <= (others => '0');
				stg6_di_im <= (others => '0');
			end if;
			
			if di_mux = '0' then
				stg5_isync <= I_SYNC;
				stg5_di_re <= I_DATA_RE;
				stg5_di_im <= (not I_DATA_IM) + 1;
			else 
				stg5_isync <= tw6_osync;
				stg5_di_re <= tw6_do_re;
				stg5_di_im <= tw6_do_im;
			end if;	
		end if;	
	end process;
	end generate;	
		
	U_FFT_STG6: hybrid_r22_sdf_v2
	generic map(
	    DEVICE          => DEVICE,	 					-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE	=> XTREME_DSP_MODE			,	-- [ Extream dsp mode				] false or true 
		DIR				=> FFT_DIR			,	-- [ FFT Direction					] "DIF" or "DIT"		
		HALF_FFT_SHIFT	=> false			,		-- [ Half N_FFT Shift on Output Order(DIT Only)	] false or true	
		IN_WIDTH		=> STG6_IN_WIDTH			,	-- [ Input Data Bit Width Parameter  ]                 
		N_SIZE			=> STG6_N_SIZE				,	-- [ FFT Point Size Parameter        ]   
		LAST_IND		=> false					,		-- [ LAST SDF Indicator				] false or true
		OSYNC_DELAY		=> R22_SDF_O_SYNC_TIMING        )			-- [ O_SYNC Timing Delay Parameter	 ]    
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg6_isync,
		I_DATA_RE	=> stg6_di_re,  
		I_DATA_IM	=> stg6_di_im,  
		I_CTRL_MODE	=> stg6_radix2_radix22_sel,
		I_LAST_CTRL	=> "00",
		O_SYNC		=> stg6_osync,
		O_DATA_RE	=> stg6_do_re,
		O_DATA_IM	=> stg6_do_im);
    	
	U_FFT_STG6_TW : hybrid_tw_phaser_v2
	generic map(
		DEVICE			=> DEVICE,
		CMULT_N_DSP48	=> CMULT_N_DSP48,
		RAM_TYPE      	=> "block", -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  => "no_change", -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   => "tw_1024.mem", 
		IN_WIDTH		=> (STG6_IN_WIDTH+2),	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		=> (STG6_IN_WIDTH),	-- [ Output Data Bit Width Parameter ]
		N_FFT			=> STG6_N_SIZE,			
		TW_WIDTH		=> 16,			
		TW_LATENCY		=> 2,				
		OSYNC_TIMING	=> HYBRID_TW_PHASER_O_SYNC_TIMING)
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg6_osync,
		I_DATA_RE	=> stg6_do_re,
		I_DATA_IM	=> stg6_do_im, 
		I_CTRL_MODE	=> stg6_radix2_radix22_sel,
		I_DATA_X181_RE	=> di_data_xi81_re,
		I_DATA_X181_IM  => di_data_xi81_im,
		O_DATA_X181_RE  => do_stg6_data_xi81_re,
		O_DATA_X181_IM  => do_stg6_data_xi81_im,
		O_SYNC		=> tw6_osync,
		O_DATA_RE	=> tw6_do_re,
		O_DATA_IM	=> tw6_do_im);
		
	U_FFT_STG5: hybrid_r22_sdf_v2
	generic map(
	    DEVICE          => DEVICE,	 					-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE	=> XTREME_DSP_MODE			,	-- [ Extream dsp mode				] false or true 
		DIR				=> FFT_DIR			,	-- [ FFT Direction					] "DIF" or "DIT"			
		HALF_FFT_SHIFT	=> false			,		-- [ Half N_FFT Shift on Output Order(DIT Only)	] false or true	
		IN_WIDTH		=> STG5_IN_WIDTH			,	-- [ Input Data Bit Width Parameter	]                 
		N_SIZE			=> STG5_N_SIZE				,	-- [ FFT Point Size Parameter      	] 
		LAST_IND		=> false					,		-- [ LAST SDF Indicator				] false or true  
		OSYNC_DELAY		=> R22_SDF_O_SYNC_TIMING	)	-- [ O_SYNC Timing Delay Parameter	]    
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg5_isync,
		I_DATA_RE	=> stg5_di_re,  
		I_DATA_IM	=> stg5_di_im, 
		I_CTRL_MODE	=> stg5_radix2_radix22_sel, 
		I_LAST_CTRL	=> "00",
		O_SYNC		=> stg5_osync,
		O_DATA_RE	=> stg5_do_re,
		O_DATA_IM	=> stg5_do_im);		
		
	U_FFT_STG5_TW : hybrid_tw_phaser_v2
	generic map(
		DEVICE			=> DEVICE,
		CMULT_N_DSP48	=> CMULT_N_DSP48,
		RAM_TYPE      	=> "block", -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  => "no_change", -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   => "tw_256.mem", 
		IN_WIDTH		=> (STG5_IN_WIDTH+2),	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		=> (STG5_IN_WIDTH),	-- [ Output Data Bit Width Parameter ]
		N_FFT			=> STG5_N_SIZE,			
		TW_WIDTH		=> 16,			
		TW_LATENCY		=> 2,				
		OSYNC_TIMING	=> HYBRID_TW_PHASER_O_SYNC_TIMING)
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg5_osync,
		I_DATA_RE	=> stg5_do_re,
		I_DATA_IM	=> stg5_do_im, 
		I_CTRL_MODE	=> stg5_radix2_radix22_sel,
		I_DATA_X181_RE	=> di_data_xi81_re,
		I_DATA_X181_IM  => di_data_xi81_im,
		O_DATA_X181_RE  => do_stg5_data_xi81_re,
		O_DATA_X181_IM  => do_stg5_data_xi81_im,
		O_SYNC		=> tw5_osync,
		O_DATA_RE	=> tw5_do_re,
		O_DATA_IM	=> tw5_do_im);
			
	U_COM_MULTS : com_mults
	generic map(
		DEVICE			=> DEVICE,
		IN_WIDTH		=> (IN_WIDTH+3),
		OUT_WIDTH      	=> (IN_WIDTH+3)
	)
	port map (
		I_CLK			=> I_CLK,
		I_STG6_DATA_RE	=> do_stg6_data_xi81_re,
		I_STG6_DATA_IM	=> do_stg6_data_xi81_im,
		I_STG5_DATA_RE	=> do_stg5_data_xi81_re, 
		I_STG5_DATA_IM	=> do_stg5_data_xi81_im,
		I_NFFT_SEL		=> I_NFFT_SEL,
		O_DATA_RE  		=> di_data_xi81_re,
		O_DATA_IM  		=> di_data_xi81_im);	
	
	U_FFT_STG4: r22_sdf_v2
	generic map(
	    DEVICE          => DEVICE,	 					-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE	=> XTREME_DSP_MODE			,	-- [ Extream dsp mode				] false or true 
		DIR				=> FFT_DIR			,	-- [ FFT Direction					] "DIF" or "DIT"	
		IN_WIDTH		=> STG4_IN_WIDTH	,			-- [ Input Data Bit Width Parameter ]                 
		N_SIZE			=> STG4_N_SIZE		,			-- [ FFT Point Size Parameter       ]   
		OSYNC_DELAY		=> R22_SDF_O_SYNC_TIMING	)	-- [ O_SYNC Timing Delay Parameter	]     
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> tw5_osync,
		I_DATA_RE	=> tw5_do_re,  
		I_DATA_IM	=> tw5_do_im,  
		O_SYNC		=> stg4_osync,
		O_DATA_RE	=> stg4_do_re,
		O_DATA_IM	=> stg4_do_im);		
		
	U_FFT_STG4_TW : tw_phaser_v2
	generic map(
		DEVICE			=> DEVICE,
		BF_TYPE			=> "Radix22",
		CMULT_N_DSP48	=> CMULT_N_DSP48,
		RAM_TYPE      	=> "distributed", -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  => "no_change", -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   => "tw_64.mem", 
		IN_WIDTH		=> (STG4_IN_WIDTH+2),	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		=> (STG4_IN_WIDTH),	-- [ Output Data Bit Width Parameter ]
		N_FFT			=> STG4_N_SIZE,			
		TW_WIDTH		=> 16,			
		TW_LATENCY		=> 2,				
		OSYNC_TIMING	=> TW_PHASER_O_SYNC_TIMING)
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg4_osync,
		I_DATA_RE	=> stg4_do_re,
		I_DATA_IM	=> stg4_do_im, 
		O_SYNC		=> tw4_osync,
		O_DATA_RE	=> tw4_do_re,
		O_DATA_IM	=> tw4_do_im);
	
	U_FFT_STG3: r22_sdf_v2
	generic map(
	    DEVICE          => DEVICE,	 					-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE	=> XTREME_DSP_MODE			,	-- [ Extream dsp mode				] false or true
		DIR				=> FFT_DIR			,	-- [ FFT Direction					] "DIF" or "DIT" 
		IN_WIDTH		=> STG3_IN_WIDTH	,			-- [ Input Data Bit Width Parameter ]                 
		N_SIZE			=> STG3_N_SIZE		,			-- [ FFT Point Size Parameter       ]    
		OSYNC_DELAY		=> R22_SDF_O_SYNC_TIMING	)	-- [ O_SYNC Timing Delay Parameter	]  
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> tw4_osync,
		I_DATA_RE	=> tw4_do_re,  
		I_DATA_IM	=> tw4_do_im,  
		O_SYNC		=> stg3_osync,
		O_DATA_RE	=> stg3_do_re,
		O_DATA_IM	=> stg3_do_im);		
				
	U_FFT_STG3_TW : tw_phaser_v2
	generic map(
		DEVICE			=> DEVICE,
		BF_TYPE			=> "Radix22",
		CMULT_N_DSP48	=> CMULT_N_DSP48,
		RAM_TYPE      	=> "distributed", -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  => "no_change", -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   => "tw_16.mem", 
		IN_WIDTH		=> (STG3_IN_WIDTH+2),	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		=> (STG3_IN_WIDTH),	-- [ Output Data Bit Width Parameter ]
		N_FFT			=> STG3_N_SIZE,			
		TW_WIDTH		=> 16,			
		TW_LATENCY		=> 2,				
		OSYNC_TIMING	=> TW_PHASER_O_SYNC_TIMING)
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg3_osync,
		I_DATA_RE	=> stg3_do_re,
		I_DATA_IM	=> stg3_do_im, 
		O_SYNC		=> tw3_osync,
		O_DATA_RE	=> tw3_do_re,
		O_DATA_IM	=> tw3_do_im);	
	
	U_FFT_STG2: r22_sdf_v2
	generic map(
	    DEVICE          => DEVICE,	 					-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE	=> XTREME_DSP_MODE			,	-- [ Extream dsp mode				] false or true
		DIR				=> FFT_DIR			,	-- [ FFT Direction					] "DIF" or "DIT" 
		IN_WIDTH		=> STG2_IN_WIDTH	,			-- [ Input Data Bit Width Parameter ]                 
		N_SIZE			=> STG2_N_SIZE		,			-- [ FFT Point Size Parameter       ]   
		OSYNC_DELAY		=> R22_SDF_O_SYNC_TIMING	)	-- [ O_SYNC Timing Delay Parameter	]    
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> tw3_osync,
		I_DATA_RE	=> tw3_do_re,  
		I_DATA_IM	=> tw3_do_im,  
		O_SYNC		=> stg2_osync,
		O_DATA_RE	=> stg2_do_re,
		O_DATA_IM	=> stg2_do_im);		
				
	U_FFT_STG2_TW : tw_phaser_v2
	generic map(
		DEVICE			=> DEVICE,
		BF_TYPE			=> "Radix22",
		CMULT_N_DSP48	=> CMULT_N_DSP48,
		RAM_TYPE      	=> "distributed", -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  => "no_change", -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   => "tw_4.mem", 
		IN_WIDTH		=> (STG2_IN_WIDTH+2),	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		=> (STG2_IN_WIDTH),	-- [ Output Data Bit Width Parameter ]
		N_FFT			=> STG2_N_SIZE,			
		TW_WIDTH		=> 16,			
		TW_LATENCY		=> 2,				
		OSYNC_TIMING	=> LAST_TW_PHASER_O_SYNC_TIMING)
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg2_osync,
		I_DATA_RE	=> stg2_do_re,
		I_DATA_IM	=> stg2_do_im, 
		O_SYNC		=> tw2_osync,
		O_DATA_RE	=> tw2_do_re,
		O_DATA_IM	=> tw2_do_im);			
		
	U_FFT_STG1: r22_sdf_v2
	generic map(
	    DEVICE          => DEVICE,	 			-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE	=> false			,	-- [ Extream dsp mode		] false or true 
		DIR				=> FFT_DIR			,	-- [ FFT Direction					] "DIF" or "DIT"
		IN_WIDTH		=> STG1_IN_WIDTH	,	-- [ Input Data Bit Width Parameter  ]                 
		N_SIZE			=> STG1_N_SIZE		,	-- [ FFT Point Size Parameter        ]   
		OSYNC_DELAY		=> STG1_R22_SDF_O_SYNC_TIMING        )			-- [ O_SYNC Timing Delay Parameter	 ]    
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> tw2_osync,
		I_DATA_RE	=> tw2_do_re,  
		I_DATA_IM	=> tw2_do_im,  
		O_SYNC		=> stg1_osync,
		O_DATA_RE	=> stg1_do_re  ,
		O_DATA_IM	=> stg1_do_im  );			
		
	U_LAST_NORM4: norm4
	generic map(
		IN_WIDTH	=> (STG1_IN_WIDTH + 2),	-- [ Input Data Bit Width Parameter  ]                 
		OUT_WIDTH	=> STG1_IN_WIDTH)		-- [ Output Data Bit Width Parameter ]	
	port map (
		I_CLK		=> I_CLK,
		I_DATA_RE	=> stg1_do_re,  
		I_DATA_IM	=> stg1_do_im,  
		O_DATA_RE	=> last_norm4_do_re  ,
		O_DATA_IM	=> last_norm4_do_im  );	
	
	g_FFT_OUT : if nIFFT_FFT_SEL = true generate -- FFT
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			O_SYNC		<= stg1_osync; 
			O_DATA_RE	<= last_norm4_do_re; 
			O_DATA_IM	<= last_norm4_do_im;
		end if;
	end process;
    end generate;
    
    g_iFFT_OUT : if nIFFT_FFT_SEL = false generate -- iFFT
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			O_SYNC		<= stg1_osync; 
			O_DATA_RE	<= last_norm4_do_re; 
			O_DATA_IM	<= (not last_norm4_do_im) + 1;
		end if;
	end process;
	end generate;
		
end struct;
-------------------------------------------------------------------------------------------------------------------------------

