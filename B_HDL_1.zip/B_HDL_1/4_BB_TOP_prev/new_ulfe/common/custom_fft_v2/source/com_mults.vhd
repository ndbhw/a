-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- Project Name		: Custom FFT V2
-- File Name		: com_mults.vhd
-- Date				: 2022.10.18
-- Revision			: 2
-- Engineer			: Jihoon Han
-- Company			: Samsung Electronics
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Functional Description
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Revision History    
-- [2022.10.08, v1.00, jihoon.han] initial release DIF 4096/1024 Cross-Check        
-- [2022.10.18, v1.10, jihoon.han] DIF 2048/512 Cross-Check             
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
library ieee; use ieee.std_logic_1164.all; use ieee.std_logic_unsigned.all;use ieee.math_real.all; use ieee.std_logic_arith.all;
use work.RU_FPGA_FNC.all;
-------------------------------------------------------------------------------------------------------------------------------
entity com_mults is 
	generic (       
		DEVICE     		: string  := "ULTRASCALE"; 	-- "7SERIES" or "ULTRASCALE"    
		IN_WIDTH		: integer := 19;			-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		: integer := 19				-- [ Output Data Bit Width Parameter ]	
		);
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_CLK				: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_STG6_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_STG6_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_STG5_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_STG5_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_NFFT_SEL		: in std_logic_vector(1 downto 0);	-- "00" = 512, "01" = 1024, "10" = 2048, "11" = 4096, 
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
end com_mults;
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
architecture struct of com_mults is
	
	component FFT_DSP48E_MULT is
	generic(
	    DEVICE                      : string  := "ULTRASCALE";
	    DSP48_MODECTRL              : boolean :=       FALSE ;
	    DSP48_PREADDER_USE          : boolean :=        TRUE ;
	    DSP48_PCIN_USE              : boolean :=       FALSE ;
	    DSP48_PCOUT_USE             : boolean :=       FALSE ;
	    DSP48_POSTADDER_MODE         : string  :=        "ADD"; -- "ADD" or "SUB" 
	
	    A_nREG                      : integer :=           2 ; -- 0, 1, 2
	    B_nREG                      : integer :=           2 ; -- 0, 1, 2
	
	    C_EN                        : boolean :=        TRUE ; -- RND ENable
	    RND_SYMMETRY                : boolean :=       FALSE 
	);
	port(
	    I_CLK                       : in  std_logic;
	
	    I_ALUMODE                   : in  std_logic_vector( 3 downto 0);
	    I_OPMODE                    : in  std_logic_vector( 8 downto 0);
    	I_PREADDER_OP				: in  std_logic_vector(4 downto 0); -- "00101" - ADD, "01101" - SUB, "00001" - A1, "0011X" - D 
	
	    I_C                         : in  std_logic_vector(47 downto 0); -- RND Value
	    I_A                         : in  std_logic_vector(29 downto 0);
	    I_D                         : in  std_logic_vector(26 downto 0);
	    I_B                         : in  std_logic_vector(17 downto 0);
	
	    I_P_C                       : in  std_logic_vector(47 downto 0);
	    O_P_C                       : out std_logic_vector(47 downto 0);
	
	    O_P                         : out std_logic_vector(47 downto 0);
	    O_CRRY                      : out std_logic
	    );
	end component;
	
	constant PREADDER_NULL			: std_logic_vector(4 downto 0) := "00000";

	signal rnd_qpoint 		: std_logic_vector(47 downto 0) := conv_std_logic_vector(63, 48);
	signal constant_x181 	: std_logic_vector(17 downto 0) := conv_std_logic_vector(181, 18);
	signal di_mul_re 		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal di_mul_im 		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal di_mul30_re 		: std_logic_vector(29 downto 0);
	signal di_mul30_im 		: std_logic_vector(29 downto 0);
	
	signal do_mul_re 		: std_logic_vector(47 downto 0);
	signal do_mul_im 		: std_logic_vector(47 downto 0);
	
begin
		
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_NFFT_SEL = "10" then -- 2048
				di_mul_re <= I_STG6_DATA_RE;
				di_mul_im <= I_STG6_DATA_IM;
			elsif I_NFFT_SEL = "00" then -- 512
				di_mul_re <= I_STG5_DATA_RE;
				di_mul_im <= I_STG5_DATA_IM;
			else
				di_mul_re <= (others => '0');
				di_mul_im <= (others => '0');
			end if;
		end if;
	end process;	
		
	--------------------------------------------------------------------------------------------
	di_mul30_re    <= sign_extension(di_mul_re, 30);
	di_mul30_im    <= sign_extension(di_mul_im, 30);
	
	U_MULT_I : FFT_DSP48E_MULT generic map(DEVICE,FALSE,FALSE,FALSE,FALSE,"ADD",2,2,TRUE,TRUE) 
	port map(I_CLK,x"0",(others=>'0'),PREADDER_NULL, rnd_qpoint, di_mul30_re, (others => '0'),constant_x181,(others=>'0'),open, do_mul_re, open);

	U_MULT_Q : FFT_DSP48E_MULT generic map(DEVICE,FALSE,FALSE,FALSE,FALSE,"ADD",2,2,TRUE,TRUE) 
	port map(I_CLK,x"0",(others=>'0'),PREADDER_NULL ,rnd_qpoint, di_mul30_im, (others => '0'),constant_x181,(others=>'0'),open, do_mul_im, open);
	--------------------------------------------------------------------------------------------	
		
	O_DATA_RE	<= do_mul_re((IN_WIDTH+6) downto 7); 
	O_DATA_IM	<= do_mul_im((IN_WIDTH+6) downto 7);
	
end struct;
-------------------------------------------------------------------------------------------------------------------------------

