-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- Project Name		: Custom FFT V2
-- File Name		: hybrid_norm.vhd
-- Date				: 2022.10.18
-- Revision			: 2
-- Engineer			: Jihoon Han
-- Company			: Samsung Electronics
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Functional Description
		
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Revision History    
-- [2022.10.08, v1.00, jihoon.han] initial release DIF 4096/1024 Cross-Check        
-- [2022.10.18, v1.10, jihoon.han] DIF 2048/512 Cross-Check       
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
library ieee; use ieee.std_logic_1164.all; use ieee.std_logic_unsigned.all;use ieee.math_real.all; use ieee.std_logic_arith.all;
use work.RU_FPGA_FNC.all;
-------------------------------------------------------------------------------------------------------------------------------
entity hybrid_norm is 
	generic (         
		IN_WIDTH		: integer := 18;			-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		: integer := 16				-- [ Output Data Bit Width Parameter ]	
	);
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_CLK				: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_DATA_RE			: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM			: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_X181_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_X181_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_CTRL_MODE		: in std_logic;	-- '0' = Radix-2 , '1' = Radix-2^2,
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
end hybrid_norm;
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
architecture struct of hybrid_norm is
		
	component FFT_SAT_FUNC is
	generic(
	    SIGN_UNSIGN                 : string  := "S"; -- "S" : Signed, "U" : Unsigned
	    INPUT_BIT                   : natural :=  19;
	    OUTPUT_BIT                  : natural :=  16 
	    );
	port(
	    I_CLK                       : in  std_logic;
	    I_DATA                      : in  std_logic_vector( INPUT_BIT-1 downto 0);
	    O_DATA                      : out std_logic_vector(OUTPUT_BIT-1 downto 0)
	    );
	end component;

	signal di_sat16_re 		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal di_sat16_im 		: std_logic_vector((IN_WIDTH-1) downto 0);
	
begin
	
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_CTRL_MODE = '1' then
				di_sat16_re <= I_DATA_RE;
				di_sat16_im <= I_DATA_IM;
			else
				di_sat16_re <= I_DATA_X181_RE;	
				di_sat16_im <= I_DATA_X181_IM;		
			end if;		
		end if;
	end process;
		
    U_SAT_I : FFT_SAT_FUNC generic map("S",IN_WIDTH,(OUT_WIDTH)) port map(I_CLK, di_sat16_re, O_DATA_RE);
    U_SAT_Q : FFT_SAT_FUNC generic map("S",IN_WIDTH,(OUT_WIDTH)) port map(I_CLK, di_sat16_im, O_DATA_IM);
		
end struct;
-------------------------------------------------------------------------------------------------------------------------------

