-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- Project Name		: Custom FFT V2
-- File Name		: nfft_wrapper_v2.vhd
-- Date				: 2022.10.18
-- Revision			: 2
-- Engineer			: Jihoon Han
-- Company			: Samsung Electronics
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Functional Description
-- FFT/iFFT Wrapper
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Revision History    
-- [2022.10.08, v1.00, jihoon.han] initial release DIF 4096/1024 Cross-Check        
-- [2022.10.18, v1.10, jihoon.han] DIF 2048/512 Cross-Check       
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
library ieee; use ieee.std_logic_1164.all; use ieee.std_logic_signed.all;
use work.RU_FPGA_FNC.all;

-------------------------------------------------------------------------------------------------------------------------------
entity nfft_wrapper_v2 is 
	generic (
	    DEVICE          	: string  	:= "ULTRASCALE";		-- "7SERIES" or "ULTRASCALE"
	    COMB_SEL			: string	:= "4096_2048_1024_512";-- [ FFT Combination Selection					] "4096_2048_1024_512"
		FFT_TYPE			: string 	:= "FFT";  				-- [ Forward or Inverse FFT			 			] "iFFT" or "FFT"
		DIR					: string	:= "DIF";				-- [ FFT Direction								] "DIF" or "DIT"			 
		N_DSP48_PER_CMULT   : string	:= "THREE";				-- [ Number of DSP48E per Complex Mult 			] "THREE" or "FOUR"	
		XTREME_DSP_MODE		: boolean	:= false;				-- [ Xtreme dsp mode							] false or true
		HALF_FFT_SHIFT		: boolean	:= false;				-- [ Half N_FFT Shift on Output Order			] false or true 	Not Avaiable for DIF or XTREAME_DSP_MODE
		IN_WIDTH			: integer 	:= 16;					-- [ Input Data Bit Width Parameter  			]  
		OUT_WIDTH			: integer 	:= 16);					-- [ Output Data Bit Width Parameter  			] OUT_WIDTH = IN_WIDTH  
	port (
		I_RSTB			: in std_logic; 									-- Synchronous Active High Reset
		I_CLK			: in std_logic;										-- System Clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************		
		I_DATA_SYNC		: in std_logic;										-- 1 clk cycle prior to input data [idx 0]
		I_DATA_VLD		: in std_logic;										-- input data aligned enable
		I_DATA_I  		: in std_logic_vector((IN_WIDTH-1) downto 0);		-- input data i
		I_DATA_Q  		: in std_logic_vector((IN_WIDTH-1) downto 0);		-- input data q
		-- *************************************************************
		-- Control DATA
		-- *************************************************************	-- [I_nFFT_TYPE] received on [I_DATA_SYNC]	
		I_nFFT_TYPE		: in std_logic_vector(1 downto 0); 					-- "00" = 512, "01" = 1024, "10" = 2048, "11" = 4096, 
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************	
		O_DATA_SYNC		: out std_logic;									-- 1 clk cycle prior to input data [idx 0]
		O_DATA_VLD		: out std_logic;									-- output data aligned enable
		O_DATA_IDX		: out std_logic_vector(11 downto 0);				-- output data index
		O_DATA_I  		: out std_logic_vector((OUT_WIDTH-1) downto 0); 	-- output data i
		O_DATA_Q 		: out std_logic_vector((OUT_WIDTH-1) downto 0);		-- output data q
		O_DATA_LAST		: out std_logic;	
		-- *************************************************************
		-- STATUS DATA
		-- *************************************************************	
		O_STATUS_EXTENDED_INPUT_DATA					: out std_logic;	-- given input data is longer than expected, then extended data just ignored
		O_EVENT_I_DATA_VLD_SHORT_OR_DISCOUNTINUED		: out std_logic;	-- given input data is shorter or discounited, then system halt 
		O_EVENT_I_SYNC_UNEXPECTED						: out std_logic);	-- given input sync is too early, then ignore previous symbol, restart with current symbol  
end nfft_wrapper_v2;
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
architecture struct of nfft_wrapper_v2 is	

	component fft_dif_4096_2048_1024_512 
	generic (
	    DEVICE          	: string  	:= "ULTRASCALE";	-- "7SERIES" or "ULTRASCALE"
		FFT_TYPE			: string 	:= "FFT";  			-- [ Forward or Inverse FFT			 	] "iFFT" or "FFT"
		N_DSP48_PER_CMULT   : string	:= "THREE";			-- [ Number of DSP48E per Complex Mult 	] "THREE" or "FOUR"	
		XTREME_DSP_MODE		: boolean	:= false;			-- [ Xtreme dsp mode					] false or true 
		IN_WIDTH			: integer 	:= 16;				-- [ Input Data Bit Width Parameter  	]  
		OUT_WIDTH			: integer 	:= 16);				-- [ Output Data Bit Width Parameter  	] OUT_WIDTH = IN_WIDTH + log2(N_FFT)
	port (
		I_RSTB			: in std_logic; 	
		I_CLK			: in std_logic;	
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************		
		I_SYNC			: in std_logic;
		I_DATA_RE	  	: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM	  	: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_NFFT_SEL		: in std_logic_vector(1 downto 0);	-- "00" = 512, "01" = 1024, "10" = 2048, "11" = 4096, 
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************	
		O_SYNC			: out std_logic;			
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
	end component;
	
	component fft_dit_4096_2048_1024_512 
	generic (
	    DEVICE          	: string  	:= "ULTRASCALE";	-- "7SERIES" or "ULTRASCALE"
		FFT_TYPE			: string 	:= "FFT";  			-- [ Forward or Inverse FFT			 			] "iFFT" or "FFT"
		N_DSP48_PER_CMULT   : string	:= "FOUR";			-- [ Number of DSP48E per Complex Mult 			] "THREE" or "FOUR"	
		XTREME_DSP_MODE		: boolean	:= false;			-- [ Extreme dsp mode							] false or true 
		HALF_FFT_SHIFT		: boolean	:= false;			-- [ Half N_FFT Shift on Output Order(DIT Only)	] false or true
		IN_WIDTH			: integer 	:= 16;				-- [ Input Data Bit Width Parameter  			]  
		OUT_WIDTH			: integer 	:= 16);				-- [ Output Data Bit Width Parameter  			]  
	port (
		I_RSTB			: in std_logic; 	
		I_CLK			: in std_logic;	
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************		
		I_SYNC			: in std_logic;
		I_DATA_RE	  	: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM	  	: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_NFFT_SEL		: in std_logic_vector(1 downto 0);	-- "00" = 512, "01" = 1024, "10" = 2048, "11" = 4096, 
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************	
		O_SYNC			: out std_logic;			
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
	end component;

	signal i_data_sync_d1		: std_logic;							
	signal i_data_i_d1	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal i_data_q_d1	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal i_data_sync_d2		: std_logic;							
	signal i_data_i_d2	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal i_data_q_d2	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal i_data_sync_d3		: std_logic;							
	signal i_data_i_d3	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal i_data_q_d3	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal i_fft_sync			: std_logic;							
	signal i_fft_data_i	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal i_fft_data_q	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal o_fft_sync       	: std_logic := '0';							       
	signal n_fft_sel 			: std_logic_vector(1 downto 0)	:= (others => '0');
	signal i_data_idx_max 		: std_logic_vector(11 downto 0)	:= (others => '0');
	signal i_data_idx 			: std_logic_vector(11 downto 0)	:= (others => '0');
	signal i_sync_unexpected 	: std_logic := '0'; 
	signal i_data_vld_missing 	: std_logic := '0'; 
	signal fft_reset_en 		: std_logic := '0';
	signal fft_reset_en_d 		: std_logic := '0';
	signal fft_nRSTB 			: std_logic := '0';
	signal o_data_cnt 			: std_logic_vector(11 downto 0)	:= (others => '0');
	signal tmp_o_data_vld		: std_logic := '0';
	signal input_receiving			: std_logic := '0';
	signal out_data_last			: std_logic := '0';
	signal input_receiving_d		: std_logic := '0';
				
begin

	g_FFT_IN_DSP : if ((XTREME_DSP_MODE = true) and (DIR = "DIF")) generate -- DSP Butterfly(Xtream DSP) Mode	
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '0' then
				i_fft_sync		<= i_data_sync_d2;
			else 
				i_fft_sync		<= '0';
			end if;
		end if;
	end process;
    end generate;
    
    g_FFT_IN_LUT : if ((XTREME_DSP_MODE = false) or ((XTREME_DSP_MODE = true) and (DIR = "DIT"))) generate 
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '0' then
				i_data_sync_d3	<= i_data_sync_d2;
				i_fft_sync		<= i_data_sync_d3;
			else 
				i_data_sync_d3	<= '0';
				i_fft_sync		<= '0';
			end if;
		end if;
	end process;
	end generate;
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '0' then
				i_data_sync_d1	<= I_DATA_SYNC;
				i_data_sync_d2	<= i_data_sync_d1;
			else 
				i_data_sync_d1	<= '0';
				i_data_sync_d2	<= '0';
			end if;
			
		    i_data_i_d1	  	<= I_DATA_I   ;
		    i_data_q_d1	  	<= I_DATA_Q   ;
		    i_data_i_d2	  	<= i_data_i_d1	  ;
		    i_data_q_d2	  	<= i_data_q_d1	  ;
		    i_data_i_d3	  	<= i_data_i_d2	   ;
		    i_data_q_d3	  	<= i_data_q_d2	   ;
		    i_fft_data_i  	<= i_data_i_d3	   ;
		    i_fft_data_q	<= i_data_q_d3	   ;
		end if;
	end process;
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_DATA_SYNC = '1' then
				n_fft_sel <= I_nFFT_TYPE;
			end if;
			
			if i_data_sync_d2 = '1' then
				i_data_idx_max(11) <= I_nFFT_TYPE(1) and I_nFFT_TYPE(0);
				i_data_idx_max(10) <= I_nFFT_TYPE(1);
				i_data_idx_max(9) <= I_nFFT_TYPE(1) or I_nFFT_TYPE(0);
			end if;
		end if;
	end process;
		                        
	i_data_idx_max(8 downto 0) <= "111111111";
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_DATA_SYNC = '1' then
				i_data_idx <= (others => '0');
			elsif i_data_idx /= i_data_idx_max then
				i_data_idx <= i_data_idx + 1;
			end if;
		end if;
	end process;
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '0' then
				input_receiving_d <= input_receiving;
			else 
				input_receiving_d <= '0';
			end if;
			
			if I_DATA_SYNC = '1' and I_RSTB = '0' then
				input_receiving <= '1';
			elsif (i_data_idx = (i_data_idx_max(11 downto 1) & '0')) or (I_RSTB = '1') then
				input_receiving <= '0';			
			end if;
			
			if I_DATA_SYNC = '1' and input_receiving = '1' and I_RSTB = '0' then
				i_sync_unexpected <= '1';
			else
				i_sync_unexpected <= '0';
			end if;
			
			if I_DATA_SYNC = '1' or I_RSTB = '1' then
				O_EVENT_I_SYNC_UNEXPECTED <= '0';
			elsif i_sync_unexpected = '1' then
				O_EVENT_I_SYNC_UNEXPECTED <= '1';
			end if;				
		end if;
	end process;
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_DATA_SYNC = '1' or I_RSTB = '1' then
				i_data_vld_missing <= '0';
			elsif I_DATA_VLD = '0' and (input_receiving = '1' or input_receiving_d = '1') then
				i_data_vld_missing <= '1';
			end if;
			
			if I_DATA_SYNC = '1' or I_RSTB = '1' then
				O_EVENT_I_DATA_VLD_SHORT_OR_DISCOUNTINUED <= '0';
			elsif i_data_vld_missing = '1' then
				O_EVENT_I_DATA_VLD_SHORT_OR_DISCOUNTINUED <= '1';
			end if;		    
			
			if I_DATA_SYNC = '1' or I_RSTB = '1' then
				O_STATUS_EXTENDED_INPUT_DATA <= '0';
			elsif I_DATA_VLD = '1' and (input_receiving_d = '0' and input_receiving = '0') then
				O_STATUS_EXTENDED_INPUT_DATA <= '1';
			end if;
		end if;
	end process; 
	
	fft_nRSTB <= fft_reset_en and fft_reset_en_d;
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			fft_reset_en <= not (i_sync_unexpected or i_data_vld_missing);	
		    fft_reset_en_d <= (not I_RSTB) and fft_reset_en;
		end if;
	end process; 		
		
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if o_fft_sync = '1' then
				o_data_cnt <= (others => '0');
			elsif o_data_cnt /= i_data_idx_max then
				o_data_cnt <= o_data_cnt + 1;
			end if;
			
			if o_fft_sync = '1' and I_RSTB = '0' then
				tmp_o_data_vld <= '1';
			elsif o_data_cnt = i_data_idx_max or I_RSTB = '1' then
				tmp_o_data_vld <= '0';
			end if;			
			
			if (o_data_cnt = i_data_idx_max) and (tmp_o_data_vld = '1') then
				out_data_last <= '1';
			else 
				out_data_last <= '0';
			end if;			
			
			O_DATA_VLD <= tmp_o_data_vld and (not I_RSTB);	
			O_DATA_SYNC <= o_fft_sync and (not I_RSTB);
		end if;
	end process; 
	
	O_DATA_LAST <= out_data_last;
	
	
    g_FFT_DIF_IDX : if (DIR = "DIF") generate 
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
            case (n_fft_sel) is
                when "00"   => O_DATA_IDX  <= "000" &  o_data_cnt(0) & o_data_cnt(1) & o_data_cnt(2) & 
                							  o_data_cnt(3) & o_data_cnt(4) & o_data_cnt(5) & o_data_cnt(6) & o_data_cnt(7) & o_data_cnt(8);
                when "01"   => O_DATA_IDX  <= "00" &  o_data_cnt(0) & o_data_cnt(1) & o_data_cnt(2) & o_data_cnt(3) & 
                         					  o_data_cnt(4) & o_data_cnt(5) & o_data_cnt(6) & o_data_cnt(7) & o_data_cnt(8) & o_data_cnt(9);
                when "10"   => O_DATA_IDX  <= '0' &  o_data_cnt(0) & o_data_cnt(1) & o_data_cnt(2) & o_data_cnt(3) & o_data_cnt(4) &
					  	 					  o_data_cnt(5) & o_data_cnt(6) & o_data_cnt(7) & o_data_cnt(8) & o_data_cnt(9) & o_data_cnt(10);
                when others => O_DATA_IDX  <= o_data_cnt(0) & o_data_cnt(1) & o_data_cnt(2) & o_data_cnt(3) & o_data_cnt(4) & o_data_cnt(5) &
					   						  o_data_cnt(6) & o_data_cnt(7) & o_data_cnt(8) & o_data_cnt(9) & o_data_cnt(10) & o_data_cnt(11); 
            end case;
		end if;
	end process; 	
    end generate;
		
    
    g_FFT_DIT_IDX : if ((DIR = "DIT") and (HALF_FFT_SHIFT = false)) generate 
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
        	O_DATA_IDX  <= o_data_cnt;
		end if;
	end process; 	
    end generate;
    
    g_FFT_DIT_HALF_IDX : if ((DIR = "DIT") and (HALF_FFT_SHIFT = true)) generate 
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
            case (n_fft_sel) is
                when "00"   => O_DATA_IDX  <= ("000" & (not o_data_cnt(8)) & o_data_cnt(7 downto 0)); 
                when "01"   => O_DATA_IDX  <= ("00" & (not o_data_cnt(9)) & o_data_cnt(8 downto 0)); 
                when "10"   => O_DATA_IDX  <= ('0' & (not o_data_cnt(10)) & o_data_cnt(9 downto 0)); 
                when others => O_DATA_IDX  <= ((not o_data_cnt(11)) & o_data_cnt(10 downto 0)); 
            end case;
		end if;
	end process; 	
    end generate;
	
	g_FFT_DIF : if DIR = "DIF" generate -- FFT DIF
	U_nFFT_DIF: fft_dif_4096_2048_1024_512
	generic map(
	    DEVICE        		=> DEVICE   ,
		FFT_TYPE 			=> FFT_TYPE ,     
		N_DSP48_PER_CMULT  	=> N_DSP48_PER_CMULT,
		XTREME_DSP_MODE		=> XTREME_DSP_MODE,
		IN_WIDTH 			=> IN_WIDTH ,   
		OUT_WIDTH			=> OUT_WIDTH )   
	port map (
		I_RSTB		=> fft_nRSTB,
		I_CLK		=> I_CLK,
		I_SYNC	  	=> i_fft_sync		,
		I_DATA_RE	=> i_fft_data_i		 ,  
		I_DATA_IM	=> i_fft_data_q		 ,  
		I_NFFT_SEL	=> n_fft_sel		,
		O_SYNC	  	=> o_fft_sync		,
		O_DATA_RE	=> O_DATA_I	    ,
		O_DATA_IM	=> O_DATA_Q	    );	
    end generate;
    
    g_FFT_DIT : if DIR = "DIT" generate -- FFT DIT
	U_nFFT_DIT: fft_dit_4096_2048_1024_512
	generic map(
	    DEVICE        		=> DEVICE   ,
		FFT_TYPE 			=> FFT_TYPE ,     
		N_DSP48_PER_CMULT  	=> N_DSP48_PER_CMULT,
		XTREME_DSP_MODE		=> XTREME_DSP_MODE,
		HALF_FFT_SHIFT		=> HALF_FFT_SHIFT,
		IN_WIDTH 			=> IN_WIDTH ,   
		OUT_WIDTH			=> OUT_WIDTH )   
	port map (
		I_RSTB		=> fft_nRSTB,
		I_CLK		=> I_CLK,
		I_SYNC	  	=> i_fft_sync		,
		I_DATA_RE	=> i_fft_data_i		 ,  
		I_DATA_IM	=> i_fft_data_q		 ,  
		I_NFFT_SEL	=> n_fft_sel		,
		O_SYNC	  	=> o_fft_sync		,
		O_DATA_RE	=> O_DATA_I	    ,
		O_DATA_IM	=> O_DATA_Q	    );	
	end generate;
	
end struct;
-------------------------------------------------------------------------------------------------------------------------------

