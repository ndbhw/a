-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- Project Name		: Custom FFT V2
-- File Name		: hybrid_r22_bf_ctrl_v2.vhd
-- Date				: 2022.10.18
-- Revision			: 2
-- Engineer			: Jihoon Han
-- Company			: Samsung Electronics
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Functional Description
		
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Revision History    
-- [2022.10.08, v1.00, jihoon.han] initial release DIF 4096/1024 Cross-Check        
-- [2022.10.18, v1.10, jihoon.han] DIF 2048/512 Cross-Check       
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
library ieee; use ieee.std_logic_1164.all; use ieee.std_logic_unsigned.all;use ieee.math_real.all; use ieee.std_logic_arith.all;
use work.RU_FPGA_FNC.all;
-------------------------------------------------------------------------------------------------------------------------------
entity hybrid_r22_bf_ctrl_v2 is 
	generic (           
		DIR				: string;		-- [ FFT Direction					] "DIF" or "DIT"	
		N_SIZE			: integer;		-- [ FFT Point Size Parameter   	] 
		XTREME_DSP_MODE	: boolean;		-- [ Xtreme dsp mode				] false or true 	
		OSYNC_DELAY		: integer);		-- [ O_SYNC Timing Delay Parameter	]  
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB  		: in std_logic; 	-- system reset(low activated)
		I_CLK	  		: in std_logic;		-- main clock
		I_SYNC			: in std_logic;
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_CTRL_MODE		: in std_logic;	-- '0' = Radix-2 , '1' = Radix-2^2, 
      	-- *************************************************************
      	-- TO FFT_STG0 module
      	-- *************************************************************
		O_BFI_CTRL_S	: out std_logic;
		O_BFI_CTRL_T	: out std_logic;
		O_BFII_CTRL_S	: out std_logic;
		O_BFII_CTRL_T	: out std_logic;
		O_SYNC	  		: out std_logic
	);
end hybrid_r22_bf_ctrl_v2;
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
architecture struct of hybrid_r22_bf_ctrl_v2 is
	
	-- DIF Parameter
	constant MSBIT					: integer := integer(ceil(log2(real(N_SIZE))));
	constant CNT_MSB        		: integer := ternary_func(N_SIZE /= 4, (MSBIT-1), MSBIT);   
	constant HYBRID_JUNC			: integer := ternary_func((DIR = "DIT"), 1, 0);
	constant INT_CTRL_MODE0_TIMING		: integer := ternary_func(XTREME_DSP_MODE = true, ((N_SIZE/4) + OSYNC_DELAY - HYBRID_JUNC - 4), ((N_SIZE/4) + OSYNC_DELAY - HYBRID_JUNC - 1));
	constant INT_CTRL_MODE1_TIMING		: integer := ((N_SIZE/2) + (N_SIZE/4) + OSYNC_DELAY);
	
	-- DIF Parameter
	constant DIF_BFII_STAGE_TRIGGER		: integer := ternary_func(XTREME_DSP_MODE = true, (N_SIZE/2 + 3), (N_SIZE/2 - 1));  
	
	-- DIT Parameter
	constant DIT_BFII_STAGE_TRIGGER		: integer := ternary_func(XTREME_DSP_MODE = true, (N_SIZE/4 + 3), (N_SIZE/4 - 1));  
	
	constant BFII_STAGE_TRIGGER		: integer := ternary_func(DIR = "DIF", DIF_BFII_STAGE_TRIGGER, 		DIT_BFII_STAGE_TRIGGER); 
	
	constant ctrl_mode0_timing_cnt	: std_logic_vector(CNT_MSB downto 0) := conv_std_logic_vector(INT_CTRL_MODE0_TIMING, (CNT_MSB+1));
	constant ctrl_mode1_timing_cnt	: std_logic_vector(CNT_MSB downto 0) := conv_std_logic_vector(INT_CTRL_MODE1_TIMING, (CNT_MSB+1));
	
	signal osync_timing_cnt	: std_logic_vector(CNT_MSB downto 0);
	signal osync_en			: std_logic;
	signal bfi_stage_cnt	: std_logic_vector(CNT_MSB downto 0);
	signal bfii_stage_cnt	: std_logic_vector(CNT_MSB downto 0);
	
begin

	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_CTRL_MODE = '0' then
				osync_timing_cnt <= ctrl_mode0_timing_cnt;
			else
				osync_timing_cnt <= ctrl_mode1_timing_cnt;
			end if;
		end if;
	end process;
	
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '0' then
				osync_en <= '0';
			elsif I_SYNC = '1' then
				osync_en <= '1';
			elsif bfi_stage_cnt = osync_timing_cnt then
				osync_en <= '0';
			end if;
		end if;
	end process;
	
	-- *************************************************************
    -- Butterfly I Control
   	-- *************************************************************
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '0' or I_SYNC = '1' then
				bfi_stage_cnt <= (others => '0');	
			else
				bfi_stage_cnt <= bfi_stage_cnt + '1';
			end if;
		end if;
	end process;
	
	g_BFI_DIF : if DIR = "DIF" generate -- FFT DIF
	O_BFI_CTRL_S 	<= bfi_stage_cnt(MSBIT - 1);	
	O_BFI_CTRL_T 	<= bfi_stage_cnt(MSBIT - 2);
    	end generate;

   	 g_BFI_DIT : if DIR = "DIT" generate -- FFT DIT
	O_BFI_CTRL_S 	<= bfi_stage_cnt(MSBIT - 2);	
	O_BFI_CTRL_T 	<= bfi_stage_cnt(MSBIT - 1);
	end generate;
	
	-- *************************************************************
    -- Butterfly II Control
   	-- *************************************************************
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '0' or bfi_stage_cnt = BFII_STAGE_TRIGGER then
				bfii_stage_cnt <= (others => '0');	
			else
				bfii_stage_cnt <= bfii_stage_cnt + '1';
			end if;
		end if;
	end process;
	
	
	g_BFII_DIF : if DIR = "DIF" generate -- FFT DIF
	O_BFII_CTRL_S 	<= bfii_stage_cnt(MSBIT - 1);
	O_BFII_CTRL_T 	<= bfii_stage_cnt(MSBIT - 2);
    end generate;
    
    g_BFII_DIT : if DIR = "DIT" generate -- FFT DIT
	O_BFII_CTRL_S 	<= bfii_stage_cnt(MSBIT - 2);
	O_BFII_CTRL_T 	<= bfii_stage_cnt(MSBIT - 1);
	end generate;
	-- *************************************************************
    -- Out Sync
   	-- *************************************************************	
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if bfi_stage_cnt = osync_timing_cnt and osync_en = '1' and I_RSTB = '1' then
				O_SYNC <= '1';
			else 
				O_SYNC <= '0'; 
			end if;
		end if;
	end process;
	
end struct;
-------------------------------------------------------------------------------------------------------------------------------
