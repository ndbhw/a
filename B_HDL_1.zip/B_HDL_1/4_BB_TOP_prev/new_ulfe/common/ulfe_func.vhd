-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.01.xx v1.0] Initial release
-- *****************************************************************************


library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.numeric_std.all;
use ieee.std_logic_arith.all;

package ulfe_func is

    function ternary_func(constant cond:Boolean;constant trueval:Boolean;constant falseval:Boolean)return Boolean;
    function ternary_func(constant cond:Boolean;constant trueval:integer;constant falseval:integer)return integer;
    function ternary_func(constant cond:Boolean;constant trueval:std_logic;constant falseval:std_logic)return std_logic;
    function ternary_func(constant cond:Boolean;constant trueval:std_logic_vector;constant falseval:std_logic)return std_logic_vector;
    function ternary_func(constant cond:Boolean;constant trueval:std_logic_vector;constant falseval:std_logic)return std_logic;
    function ternary_func(constant cond:Boolean;constant trueval:std_logic_vector;constant falseval:std_logic_vector)return std_logic_vector;
    function ternary_func(constant cond:Boolean;constant trueval:integer;constant falseval:std_logic_vector)return std_logic_vector;
    function ternary_func(constant cond:Boolean;constant trueval:string;constant falseval:string)return string;
    function sign_extension (input:std_logic_vector;output:integer) return std_logic_vector;
    function log2ceil (data_value : integer) return integer;	

end ulfe_func;

package body ulfe_func is

    -- ternary function
    function ternary_func(constant cond:Boolean;constant trueval:Boolean;constant falseval:Boolean)return Boolean is
    begin
        if cond then
            return trueval;
        else
            return falseval;
        end if;
    end ternary_func;
    
    function ternary_func(constant cond:Boolean;constant trueval:integer;constant falseval:integer)return integer is
    begin
        if cond then
            return trueval;
        else
            return falseval;
        end if;
    end ternary_func;
    
    function ternary_func(constant cond:Boolean;constant trueval:std_logic;constant falseval:std_logic)return std_logic is
    begin
        if cond then
            return trueval;
        else
            return falseval;
        end if;
    end ternary_func;
    
    function ternary_func(constant cond:Boolean;constant trueval:std_logic_vector;constant falseval:std_logic)return std_logic is
    begin
        if cond then
            return trueval(0);
        else
            return falseval;
        end if;
    end ternary_func;
    
    function ternary_func(constant cond : Boolean;constant trueval:std_logic_vector;constant falseval:std_logic)return std_logic_vector is
    variable result:std_logic_vector(0 downto 0);
    begin
        if cond then
            return trueval;
        else
            result(0):=falseval;
            return result;
        end if;
    end ternary_func;
    
    function ternary_func(constant cond : Boolean;constant trueval:std_logic_vector;constant falseval:std_logic_vector)return std_logic_vector is
    begin
        if cond then
            return trueval;
        else
            return falseval;
        end if;
    end ternary_func;
    
    function ternary_func(constant cond:Boolean;constant trueval:integer;constant falseval:std_logic_vector)return std_logic_vector is
    begin
        if cond then
            return std_logic_vector(to_unsigned(trueval,falseval'length));
        else
            return falseval;
        end if;
    end ternary_func;
    
    function ternary_func(constant cond:Boolean;constant trueval:string;constant falseval:string)return string is
    begin
        if cond then
            return trueval;
        else
            return falseval;
        end if;
    end ternary_func;
    
    function sign_extension(input:std_logic_vector;output:integer)return std_logic_vector is
        variable widthi:integer;
        variable result:std_logic_vector(output-1 downto 0);
    begin
        widthi := input'length;
        result(widthi-2 downto 0):=input(widthi-2 downto 0);
        result(output-1 downto widthi-1):=(others=>input(widthi-1));
        return  result;
    end sign_extension;
    
    function log2ceil (data_value : integer)
    return integer is
    
        variable width       : integer := 0;
        variable cnt         : integer := 1;
    
    begin
        if (data_value <= 1) then
            width   := 1;
        else
        while (cnt < data_value) loop
            width := width + 1;
            cnt   := cnt*2;
        end loop;
        end if;
    
    return width;
    end log2ceil;

end ulfe_func;