-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.04.25 v1.0] Initial release
-- *****************************************************************************


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity ulfe_lib_dly_fixed is
    generic (
        delay_num                       : integer := 2;
        data_i_width                    : integer := 16
    );
    port (
        i_clk                           : in std_logic;
        
        data_i                          : in std_logic_vector(data_i_width-1 downto 0);
        data_o                          : out std_logic_vector(data_i_width-1 downto 0)
    );
end ulfe_lib_dly_fixed;

architecture Behavioral of ulfe_lib_dly_fixed is
    
    type data_i_width_array             is array(natural range <>) of std_logic_vector(data_i_width-1 downto 0);
    signal  delay_array                 : data_i_width_array(delay_num-1 downto 0);
    
begin

    dly_num_1 : if (delay_num = 1) generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                delay_array(0)              <=  data_i;
            end if;
        end process;
    end generate;
    
    dly_num_above1 : if (delay_num > 1) generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                delay_array                 <=  delay_array(delay_num-2 downto 0) & data_i;
            end if;
        end process;
    end generate;
    
    data_o                <=  delay_array(delay_num-1);

end Behavioral;
