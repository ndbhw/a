-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.11.15 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity ulfe_lib_lzc_16 is
    Port(
        i_clk                           : in std_logic;
        
        i_data                          : in std_logic_vector(16-1 downto 0);
        o_q                             : out std_logic_vector(4-1 downto 0)
    );
end ulfe_lib_lzc_16;

architecture Behavioral of ulfe_lib_lzc_16 is

    component ulfe_lib_lzc_4 is
        Port(
            i_data                          : in std_logic_vector(4-1 downto 0);
            
            o_a                             : out std_logic;
            o_q1                            : out std_logic;
            o_q0                            : out std_logic
        );
    end component ulfe_lib_lzc_4;
    
    signal  a                               : std_logic_vector(4-1 downto 0);
    signal  q1                              : std_logic_vector(4-1 downto 0);
    signal  q0                              : std_logic_vector(4-1 downto 0);
    
    signal  q3                              : std_logic;
    signal  q2                              : std_logic;
    
    signal  mux_sel                         : std_logic_vector(2-1 downto 0);

begin

    -----------------------------------
    --a0  a1  a2  a3  q3  q2  (q1,q0)--
    --0   X   X   X   0   0     z0	 --
    --1   0   X   X   0   1     z1   --
    --1   1   0   X   1   0     z2   --
    --1   1   1   0   1   1     z3   --
    -----------------------------------
    
    LZC16 : for i in 0 to 4-1 generate
        U : ulfe_lib_lzc_4 port map(i_data((i+1)*4-1 downto i*4), a(3-i), q1(3-i), q0(3-i));
    end generate LZC16;
    
    q3                          <=  a(0) and a(1) and ((not a(2)) or (not a(3)));
    q2                          <=  a(0) and ((not a(1)) or (a(2) and (not a(3))));
    
    mux_sel                     <=  q3 & q2;
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            case(mux_sel) is
                when b"00"  =>  o_q           <=  q3 & q2 & q1(0) & q0(0);
                when b"01"  =>  o_q           <=  q3 & q2 & q1(1) & q0(1);
                when b"10"  =>  o_q           <=  q3 & q2 & q1(2) & q0(2);
                when others =>  o_q           <=  q3 & q2 & q1(3) & q0(3);
            end case;
        end if;
    end process;

end Behavioral;
