-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.04.25 v1.0] Initial release
-- [2022.08.03 v2.0] changed latency 6->4
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
use IEEE.numeric_std.all;

entity ulfe_lib_expj_v2 is
    generic(
        conjugate                          : std_logic := '0';
        phase_b_width                      : integer := 14                   -- 12 or 14
    );
    Port ( 
        i_clk                              : in std_logic;
        
        i_data                             : in std_logic_vector(phase_b_width-1 downto 0);
        
        o_cos                              : out std_logic_vector(16-1 downto 0);
        o_sin                              : out std_logic_vector(16-1 downto 0)
    );
end ulfe_lib_expj_v2;

architecture Behavioral of ulfe_lib_expj_v2 is

    component ulfe_lib_sat_u is
        generic(
            d_width                        : integer := 16;
            sat_width                      : integer := 15
        );
        Port ( 
            i_clk                          : in std_logic;
            
            i_data                         : in std_logic_vector(d_width-1 downto 0);
            o_data                         : out std_logic_vector(sat_width-1 downto 0)
        );
    end component ulfe_lib_sat_u;
    
    component ulfe_lib_sin_table_expj12_d16_dprom is
        Port ( 
            i_clk                          : in std_logic;
            
            i_addr_a                       : in std_logic_vector(10-1 downto 0);
            i_addr_b                       : in std_logic_vector(10-1 downto 0);
            
            o_dout_a                       : out std_logic_vector(16-1 downto 0);
            o_dout_b                       : out std_logic_vector(16-1 downto 0)
        );
    end component ulfe_lib_sin_table_expj12_d16_dprom;
    
    component ulfe_lib_sin_table_expj14_d16_dprom is
        Port (
            i_clk                          : in std_logic;
            
            i_addr_a                       : in std_logic_vector(12-1 downto 0);
            i_addr_b                       : in std_logic_vector(12-1 downto 0);
            
            o_dout_a                       : out std_logic_vector(16-1 downto 0);
            o_dout_b                       : out std_logic_vector(16-1 downto 0)
        );
    end component ulfe_lib_sin_table_expj14_d16_dprom;
    
    constant module_latency                : integer := 4;
    constant add_num                       : std_logic_vector(phase_b_width-2 downto 0) := conv_std_logic_vector(2**(phase_b_width-2),phase_b_width-1);
    
    signal  i_data_1d                      : std_logic_vector(phase_b_width-1 downto 0);
    
    signal  msb_bit_reg                    : std_logic_vector(module_latency-2 downto 0);
    signal  msb_m1_bit_reg                 : std_logic_vector(module_latency-2 downto 0);
    
    signal  data_minus                     : std_logic_vector(phase_b_width-2 downto 0);
    signal  satu_data                      : std_logic_vector(phase_b_width-2 downto 0);
    
    signal  cos_rom_addr                   : std_logic_vector(phase_b_width-3 downto 0);
    signal  sin_rom_addr                   : std_logic_vector(phase_b_width-3 downto 0);
    signal  cos_out                        : std_logic_vector(16-1 downto 0);
    signal  sin_out                        : std_logic_vector(16-1 downto 0);
    signal  sin_mux_sel                    : std_logic_vector(2-1 downto 0);

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            i_data_1d                      <=  i_data;
            
            msb_bit_reg                    <=  msb_bit_reg(module_latency-3 downto 0) & i_data(phase_b_width-1);
            msb_m1_bit_reg                 <=  msb_m1_bit_reg(module_latency-3 downto 0) & i_data(phase_b_width-2);
        end if;
    end process;
    
    -- 1clk
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_data(phase_b_width-3 downto 0) = 0) then
                satu_data                  <=  add_num - b"1";
            else
                satu_data                  <=  add_num - ('0' & i_data(phase_b_width-3 downto 0));
            end if;
        end if;
    end process;

    -- 1clk
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (msb_m1_bit_reg(0) = '1') then
                cos_rom_addr               <=  i_data_1d(phase_b_width-3 downto 0);
                sin_rom_addr               <=  satu_data(phase_b_width-3 downto 0);
            else
                cos_rom_addr               <=  satu_data(phase_b_width-3 downto 0);
                sin_rom_addr               <=  i_data_1d(phase_b_width-3 downto 0);
            end if;
        end if;
    end process;
    
    -- 1clk
    sin_gen_12 : if (phase_b_width = 12) generate
        cos_sin_rom : ulfe_lib_sin_table_expj12_d16_dprom port map(i_clk, cos_rom_addr, sin_rom_addr, cos_out, sin_out);
    end generate;
    
    sin_gen_14 : if (phase_b_width = 14) generate
        cos_sin_rom : ulfe_lib_sin_table_expj14_d16_dprom port map(i_clk, cos_rom_addr, sin_rom_addr, cos_out, sin_out);
    end generate;
    
    -- 1clk	
    sin_mux_sel		<=	conjugate & msb_bit_reg(2);
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            case (msb_bit_reg(2) xor msb_m1_bit_reg(2)) is
                when '0'    =>  o_cos           <=  cos_out;
                when others =>  o_cos           <=  (not cos_out) + '1';
            end case;
            
            case (sin_mux_sel) is
                when b"00"  =>  o_sin           <=  sin_out;
                when b"01"  =>  o_sin           <=  (not sin_out) + '1';
                when b"10"  =>  o_sin           <=  (not sin_out) + '1';
                when b"11"  =>  o_sin           <=  sin_out;
                when others =>  o_sin           <=  sin_out;
            end case;
        end if;
    end process;

end Behavioral;