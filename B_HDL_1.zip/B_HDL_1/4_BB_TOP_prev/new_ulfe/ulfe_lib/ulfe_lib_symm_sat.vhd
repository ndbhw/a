-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.04.25 v1.0] Initial release
-- *****************************************************************************


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity ulfe_lib_symm_sat is
    generic(
        d_width                         : integer := 16;
        sat_width                       : integer := 15
    );
    Port (
        i_clk                           : in std_logic;
        
        i_data                          : in std_logic_vector(d_width-1 downto 0);
        o_data                          : out std_logic_vector(sat_width-1 downto 0)
    );
end ulfe_lib_symm_sat;

architecture Behavioral of ulfe_lib_symm_sat is

    constant  ones                      : std_logic_vector(d_width-sat_width-1 downto 0) := (others=>'1');
    constant  zeros_1                   : std_logic_vector(d_width-sat_width-1 downto 0) := (others=>'0');
    constant  zeros_2                   : std_logic_vector(sat_width-2 downto 0) := (others=>'0');

begin

    -- 1clk
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_data(d_width-1) = '0' and (i_data(d_width-2 downto sat_width-1) > zeros_1)) then	-- positive saturation
                o_data(sat_width-1)                 <=  '0';
                o_data(sat_width-2 downto 0)		<=  (others=>'1');
            elsif (i_data(d_width-1) = '1' and ((i_data(d_width-2 downto sat_width-1) < ones) or (i_data(sat_width-2 downto 0) = zeros_2))) then	-- negative saturation or symmetric
                o_data(sat_width-1)                 <=  '1';
                o_data(sat_width-2 downto 1)        <=  (others=>'0');
                o_data(0)                           <=  '1';
            else
                o_data                              <=  i_data(sat_width-1 downto 0);
            end if;
        end if;
    end process;

end Behavioral;