-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.04.25 v1.0] Initial release
-- [2022.08.05 v2.0] add dsp_2 c pipeline
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

library work;
use work.ulfe_func.all;

library UNISIM;
use UNISIM.VComponents.all;

entity ulfe_lib_C_multi_v2 is
    generic(
        width_a                              : integer := 15;
        width_b                              : integer := 16;
        width_p                              : integer := 31
    );
    
    Port (
        i_clk                                : in std_logic;
        
        i_real_data_A                        : in std_logic_vector(width_a-1 downto 0);	-- a
        i_img_data_A                         : in std_logic_vector(width_a-1 downto 0);	-- b
        
        i_real_data_B                        : in std_logic_vector(width_b-1 downto 0);	-- c
        i_img_data_B                         : in std_logic_vector(width_b-1 downto 0);	-- d
        
        o_real_data                          : out std_logic_vector(width_p-1 downto 0);
        o_img_data                           : out std_logic_vector(width_p-1 downto 0)
    );
end ulfe_lib_C_multi_v2;

architecture Behavioral of ulfe_lib_C_multi_v2 is

    constant A_INT_WIDTH                     : integer := 30;
    constant D_INT_WIDTH                     : integer := 27;
    constant B_INT_WIDTH                     : integer := 18;
    constant C_INT_WIDTH                     : integer := 48;
    constant P_INT_WIDTH                     : integer := 48;
    constant ALUMODE                         : std_logic_vector(3 downto 0) := b"0000";          -- Z +W + X + Y + CIN
    
    constant dsp0_INMODE                     : std_logic_vector(4 downto 0) := b"01101";         -- (D-A2)*B2
    constant dsp0_OPMODE                     : std_logic_vector(8 downto 0) := b"000000101";
    signal  dsp0_A                           : std_logic_vector(A_INT_WIDTH-1 downto 0);
    signal  dsp0_D                           : std_logic_vector(D_INT_WIDTH-1 downto 0);
    signal  dsp0_B                           : std_logic_vector(B_INT_WIDTH-1 downto 0);
    signal  dsp0_P                           : std_logic_vector(P_INT_WIDTH-1 downto 0);
    signal  dsp0_pcout                       : std_logic_vector(P_INT_WIDTH-1 downto 0);
    
    constant dsp1_INMODE                     : std_logic_vector(4 downto 0) := b"01101";         -- (D-A2)*B2
    constant dsp1_OPMODE                     : std_logic_vector(8 downto 0) := b"000010101";     -- (D-A2)*B2 + PCIN
    signal  dsp1_A                           : std_logic_vector(A_INT_WIDTH-1 downto 0);
    signal  dsp1_D                           : std_logic_vector(D_INT_WIDTH-1 downto 0);
    signal  dsp1_B                           : std_logic_vector(B_INT_WIDTH-1 downto 0);
    signal  dsp1_P                           : std_logic_vector(P_INT_WIDTH-1 downto 0);
    signal  dsp1_P_1d                        : std_logic_vector(width_p-1 downto 0);
    
    constant dsp2_INMODE                     : std_logic_vector(4 downto 0) := b"00101";         -- (D+A2)*B2
    constant dsp2_OPMODE                     : std_logic_vector(8 downto 0) := b"110000101";     -- (D+A2)*B2 + C
    signal  dsp2_A                           : std_logic_vector(A_INT_WIDTH-1 downto 0);
    signal  dsp2_D                           : std_logic_vector(D_INT_WIDTH-1 downto 0);
    signal  dsp2_B                           : std_logic_vector(B_INT_WIDTH-1 downto 0);
    signal  dsp2_P                           : std_logic_vector(P_INT_WIDTH-1 downto 0);
    
    signal  i_real_data_A_1d                 : std_logic_vector(width_a-1 downto 0);
    signal  i_img_data_A_1d                  : std_logic_vector(width_a-1 downto 0);
    signal  i_real_data_B_1d                 : std_logic_vector(width_b-1 downto 0);
    signal  i_img_data_B_1d                  : std_logic_vector(width_b-1 downto 0);
    
    signal  i_real_data_A_2d                 : std_logic_vector(width_a-1 downto 0);
    signal  i_img_data_A_2d                  : std_logic_vector(width_a-1 downto 0);	
    signal  i_img_data_B_2d                  : std_logic_vector(width_b-1 downto 0);

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            i_real_data_A_1d                <=  i_real_data_A;
            i_img_data_A_1d                 <=  i_img_data_A;
            i_real_data_B_1d                <=  i_real_data_B;
            i_img_data_B_1d                 <=  i_img_data_B;
            
            i_real_data_A_2d                <=  i_real_data_A_1d;
            i_img_data_A_2d                 <=  i_img_data_A_1d;		    
            i_img_data_B_2d                 <=  i_img_data_B_1d;
            
            dsp1_P_1d                       <=  dsp1_P(width_p-1 downto 0);
        end if;
    end process;

    dsp0_A          <=  sign_extension(i_img_data_B, A_INT_WIDTH);
    dsp0_D          <=  sign_extension(i_real_data_B, D_INT_WIDTH);
    dsp0_B          <=  sign_extension(i_img_data_A, B_INT_WIDTH);
    
    dsp1_A          <=  sign_extension(i_img_data_A_1d, A_INT_WIDTH);
    dsp1_D          <=  sign_extension(i_real_data_A_1d, D_INT_WIDTH);
    dsp1_B          <=  sign_extension(i_real_data_B_1d, B_INT_WIDTH);
    
    dsp2_A          <=  sign_extension(i_img_data_A_2d, A_INT_WIDTH);
    dsp2_D          <=  sign_extension(i_real_data_A_2d, D_INT_WIDTH);
    dsp2_B          <=  sign_extension(i_img_data_B_2d, B_INT_WIDTH);
    
    o_real_data     <=  dsp1_P_1d;
    o_img_data      <=  dsp2_P(width_p-1 downto 0);

    -----------------------------------------------------------------------------------
    -- calculate
    
    DSP0 : DSP48E2
        generic map (
            -- Feature Control Attributes: Data Path Selection
            AMULTSEL                    => "AD",                -- Selects A input to multiplier (A, AD)
            A_INPUT                     => "DIRECT",            -- Selects A input source, "DIRECT" (A port) or "CASCADE" (ACIN port)
            BMULTSEL                    => "B",                 -- Selects B input to multiplier (AD, B)
            B_INPUT                     => "DIRECT",            -- Selects B input source, "DIRECT" (B port) or "CASCADE" (BCIN port)
            PREADDINSEL                 => "A",                 -- Selects input to pre-adder (A, B)
            RND                         => X"000000000000",     -- Rounding Constant
            USE_MULT                    => "MULTIPLY",          -- Select multiplier usage (DYNAMIC, MULTIPLY, NONE)
            USE_SIMD                    => "ONE48",             -- SIMD selection (FOUR12, ONE48, TWO24)
            USE_WIDEXOR                 => "FALSE",             -- Use the Wide XOR function (FALSE, TRUE)
            XORSIMD                     => "XOR24_48_96",       -- Mode of operation for the Wide XOR (XOR12, XOR24_48_96)
            -- Pattern Detector Attributes: Pattern Detection Configuration
            AUTORESET_PATDET            => "NO_RESET",          -- NO_RESET, RESET_MATCH, RESET_NOT_MATCH
            AUTORESET_PRIORITY          => "RESET",             -- Priority of AUTORESET vs. CEP (CEP, RESET).
            MASK                        => X"3fffffffffff",     -- 48-bit mask value for pattern detect (1=ignore)
            PATTERN                     => X"000000000000",     -- 48-bit pattern match for pattern detect
            SEL_MASK                    => "MASK",              -- C, MASK, ROUNDING_MODE1, ROUNDING_MODE2
            SEL_PATTERN                 => "PATTERN",           -- Select pattern value (C, PATTERN)
            USE_PATTERN_DETECT          => "NO_PATDET",         -- Enable pattern detect (NO_PATDET, PATDET)
            -- Programmable Inversion Attributes: Specifies built-in programmable inversion on specific pins
            IS_ALUMODE_INVERTED         => "0000",              -- Optional inversion for ALUMODE
            IS_CARRYIN_INVERTED         => '0',                 -- Optional inversion for CARRYIN
            IS_CLK_INVERTED             => '0',                 -- Optional inversion for CLK
            IS_INMODE_INVERTED          => "00000",             -- Optional inversion for INMODE
            IS_OPMODE_INVERTED          => "000000000",         -- Optional inversion for OPMODE
            IS_RSTALLCARRYIN_INVERTED   => '0',                 -- Optional inversion for RSTALLCARRYIN
            IS_RSTALUMODE_INVERTED      => '0',                 -- Optional inversion for RSTALUMODE
            IS_RSTA_INVERTED            => '0',                 -- Optional inversion for RSTA
            IS_RSTB_INVERTED            => '0',                 -- Optional inversion for RSTB
            IS_RSTCTRL_INVERTED         => '0',                 -- Optional inversion for RSTCTRL
            IS_RSTC_INVERTED            => '0',                 -- Optional inversion for RSTC
            IS_RSTD_INVERTED            => '0',                 -- Optional inversion for RSTD
            IS_RSTINMODE_INVERTED       => '0',                 -- Optional inversion for RSTINMODE
            IS_RSTM_INVERTED            => '0',                 -- Optional inversion for RSTM
            IS_RSTP_INVERTED            => '0',                 -- Optional inversion for RSTP
            -- Register Control Attributes: Pipeline Register Configuration
            ACASCREG                    => 2,                   -- Number of pipeline stages between A/ACIN and ACOUT (0-2)
            ADREG                       => 1,                   -- Pipeline stages for pre-adder (0-1)
            ALUMODEREG                  => 1,                   -- Pipeline stages for ALUMODE (0-1)
            AREG                        => 2,                   -- Pipeline stages for A (0-2)
            BCASCREG                    => 1,                   -- Number of pipeline stages between B/BCIN and BCOUT (0-2)
            BREG                        => 2,                   -- Pipeline stages for B (0-2)
            CARRYINREG                  => 1,                   -- Pipeline stages for CARRYIN (0-1)
            CARRYINSELREG               => 1,                   -- Pipeline stages for CARRYINSEL (0-1)
            CREG                        => 1,                   -- Pipeline stages for C (0-1)
            DREG                        => 1,                   -- Pipeline stages for D (0-1)
            INMODEREG                   => 1,                   -- Pipeline stages for INMODE (0-1)
            MREG                        => 1,                   -- Multiplier pipeline stages (0-1)
            OPMODEREG                   => 1,                   -- Pipeline stages for OPMODE (0-1)
            PREG                        => 1                    -- Number of pipeline stages for P (0-1)
        )
        port map (
            -- Cascade outputs: Cascade Ports
            ACOUT                       => open,                -- 30-bit output: A port cascade
            BCOUT                       => open,                -- 18-bit output: B cascade
            CARRYCASCOUT                => open,                -- 1-bit output: Cascade carry
            MULTSIGNOUT                 => open,                -- 1-bit output: Multiplier sign cascade
            PCOUT                       => dsp0_pcout,          -- 48-bit output: Cascade output
            -- Control outputs: Control Inputs/Status Bits
            OVERFLOW                    => open,                -- 1-bit output: Overflow in add/acc
            PATTERNBDETECT              => open,                -- 1-bit output: Pattern bar detect
            PATTERNDETECT               => open,                -- 1-bit output: Pattern detect
            UNDERFLOW                   => open,                -- 1-bit output: Underflow in add/acc
            -- Data outputs: Data Ports
            CARRYOUT                    => open,             	-- 4-bit output: Carry
            P                           => dsp0_P,              -- 48-bit output: Primary data
            XOROUT                      => open,                -- 8-bit output: XOR data
            -- Cascade inputs: Cascade Ports
            ACIN                        => (others=>'0'),       -- 30-bit input: A cascade data
            BCIN                        => (others=>'0'),       -- 18-bit input: B cascade
            CARRYCASCIN                 => '0',                 -- 1-bit input: Cascade carry
            MULTSIGNIN                  => '0',                 -- 1-bit input: Multiplier sign cascade
            PCIN                        => (others=>'0'),       -- 48-bit input: P cascade
            -- Control inputs: Control Inputs/Status Bits
            ALUMODE                     => ALUMODE,             -- 4-bit input: ALU control
            CARRYINSEL                  => (others=>'0'),       -- 3-bit input: Carry select
            CLK                         => i_clk,               -- 1-bit input: Clock
            INMODE                      => dsp0_INMODE,         -- 5-bit input: INMODE control
            OPMODE                      => dsp0_OPMODE,         -- 9-bit input: Operation mode
            -- Data inputs: Data Ports
            A                           => dsp0_A,              -- 30-bit input: A data
            B                           => dsp0_B,              -- 18-bit input: B data
            C                           => (others=>'0'),       -- 48-bit input: C data
            CARRYIN                     => '0',               	-- 1-bit input: Carry-in
            D                           => dsp0_D,              -- 27-bit input: D data
            -- Reset/Clock Enable inputs: Reset/Clock Enable Inputs
            CEA1                        => '1',                 -- 1-bit input: Clock enable for 1st stage AREG
            CEA2                        => '1',                 -- 1-bit input: Clock enable for 2nd stage AREG
            CEAD                        => '1',                 -- 1-bit input: Clock enable for ADREG
            CEALUMODE                   => '1',                 -- 1-bit input: Clock enable for ALUMODE
            CEB1                        => '1',                 -- 1-bit input: Clock enable for 1st stage BREG
            CEB2                        => '1',                 -- 1-bit input: Clock enable for 2nd stage BREG
            CEC                         => '1',                 -- 1-bit input: Clock enable for CREG
            CECARRYIN                   => '0',                 -- 1-bit input: Clock enable for CARRYINREG
            CECTRL                      => '1',                 -- 1-bit input: Clock enable for OPMODEREG and CARRYINSELREG
            CED                         => '1',                 -- 1-bit input: Clock enable for DREG
            CEINMODE                    => '1',                 -- 1-bit input: Clock enable for INMODEREG
            CEM                         => '1',                 -- 1-bit input: Clock enable for MREG
            CEP                         => '1',                 -- 1-bit input: Clock enable for PREG
            RSTA                        => '0',                 -- 1-bit input: Reset for AREG
            RSTALLCARRYIN               => '0',                 -- 1-bit input: Reset for CARRYINREG
            RSTALUMODE                  => '0',                 -- 1-bit input: Reset for ALUMODEREG
            RSTB                        => '0',                 -- 1-bit input: Reset for BREG
            RSTC                        => '0',                 -- 1-bit input: Reset for CREG
            RSTCTRL                     => '0',                 -- 1-bit input: Reset for OPMODEREG and CARRYINSELREG
            RSTD                        => '0',                 -- 1-bit input: Reset for DREG and ADREG
            RSTINMODE                   => '0',                 -- 1-bit input: Reset for INMODEREG
            RSTM                        => '0',                 -- 1-bit input: Reset for MREG
            RSTP                        => '0'                  -- 1-bit input: Reset for PREG
        );
    
    -- calculate real data
    DSP1 : DSP48E2
        generic map (
            -- Feature Control Attributes: Data Path Selection
            AMULTSEL                    => "AD",                -- Selects A input to multiplier (A, AD)
            A_INPUT                     => "DIRECT",            -- Selects A input source, "DIRECT" (A port) or "CASCADE" (ACIN port)
            BMULTSEL                    => "B",                 -- Selects B input to multiplier (AD, B)
            B_INPUT                     => "DIRECT",            -- Selects B input source, "DIRECT" (B port) or "CASCADE" (BCIN port)
            PREADDINSEL                 => "A",                 -- Selects input to pre-adder (A, B)
            RND                         => X"000000000000",     -- Rounding Constant
            USE_MULT                    => "MULTIPLY",          -- Select multiplier usage (DYNAMIC, MULTIPLY, NONE)
            USE_SIMD                    => "ONE48",             -- SIMD selection (FOUR12, ONE48, TWO24)
            USE_WIDEXOR                 => "FALSE",             -- Use the Wide XOR function (FALSE, TRUE)
            XORSIMD                     => "XOR24_48_96",       -- Mode of operation for the Wide XOR (XOR12, XOR24_48_96)
            -- Pattern Detector Attributes: Pattern Detection Configuration
            AUTORESET_PATDET            => "NO_RESET",          -- NO_RESET, RESET_MATCH, RESET_NOT_MATCH
            AUTORESET_PRIORITY          => "RESET",             -- Priority of AUTORESET vs. CEP (CEP, RESET).
            MASK                        => X"3fffffffffff",     -- 48-bit mask value for pattern detect (1=ignore)
            PATTERN                     => X"000000000000",     -- 48-bit pattern match for pattern detect
            SEL_MASK                    => "MASK",              -- C, MASK, ROUNDING_MODE1, ROUNDING_MODE2
            SEL_PATTERN                 => "PATTERN",           -- Select pattern value (C, PATTERN)
            USE_PATTERN_DETECT          => "NO_PATDET",         -- Enable pattern detect (NO_PATDET, PATDET)
            -- Programmable Inversion Attributes: Specifies built-in programmable inversion on specific pins
            IS_ALUMODE_INVERTED         => "0000",              -- Optional inversion for ALUMODE
            IS_CARRYIN_INVERTED         => '0',                 -- Optional inversion for CARRYIN
            IS_CLK_INVERTED             => '0',                 -- Optional inversion for CLK
            IS_INMODE_INVERTED          => "00000",             -- Optional inversion for INMODE
            IS_OPMODE_INVERTED          => "000000000",         -- Optional inversion for OPMODE
            IS_RSTALLCARRYIN_INVERTED   => '0',                 -- Optional inversion for RSTALLCARRYIN
            IS_RSTALUMODE_INVERTED      => '0',                 -- Optional inversion for RSTALUMODE
            IS_RSTA_INVERTED            => '0',                 -- Optional inversion for RSTA
            IS_RSTB_INVERTED            => '0',                 -- Optional inversion for RSTB
            IS_RSTCTRL_INVERTED         => '0',                 -- Optional inversion for RSTCTRL
            IS_RSTC_INVERTED            => '0',                 -- Optional inversion for RSTC
            IS_RSTD_INVERTED            => '0',                 -- Optional inversion for RSTD
            IS_RSTINMODE_INVERTED       => '0',                 -- Optional inversion for RSTINMODE
            IS_RSTM_INVERTED            => '0',                 -- Optional inversion for RSTM
            IS_RSTP_INVERTED            => '0',                 -- Optional inversion for RSTP
            -- Register Control Attributes: Pipeline Register Configuration
            ACASCREG                    => 2,                   -- Number of pipeline stages between A/ACIN and ACOUT (0-2)
            ADREG                       => 1,                   -- Pipeline stages for pre-adder (0-1)
            ALUMODEREG                  => 1,                   -- Pipeline stages for ALUMODE (0-1)
            AREG                        => 2,                   -- Pipeline stages for A (0-2)
            BCASCREG                    => 1,                   -- Number of pipeline stages between B/BCIN and BCOUT (0-2)
            BREG                        => 2,                   -- Pipeline stages for B (0-2)
            CARRYINREG                  => 1,                   -- Pipeline stages for CARRYIN (0-1)
            CARRYINSELREG               => 1,                 	-- Pipeline stages for CARRYINSEL (0-1)
            CREG                        => 1,                   -- Pipeline stages for C (0-1)
            DREG                        => 1,                   -- Pipeline stages for D (0-1)
            INMODEREG                   => 1,                   -- Pipeline stages for INMODE (0-1)
            MREG                        => 1,                   -- Multiplier pipeline stages (0-1)
            OPMODEREG                   => 1,                   -- Pipeline stages for OPMODE (0-1)
            PREG                        => 1                    -- Number of pipeline stages for P (0-1)
        )
        port map (
            -- Cascade outputs: Cascade Ports
            ACOUT                       => open,                -- 30-bit output: A port cascade
            BCOUT                       => open,                -- 18-bit output: B cascade
            CARRYCASCOUT                => open,                -- 1-bit output: Cascade carry
            MULTSIGNOUT                 => open,                -- 1-bit output: Multiplier sign cascade
            PCOUT                       => open,                -- 48-bit output: Cascade output
            -- Control outputs: Control Inputs/Status Bits
            OVERFLOW                    => open,                -- 1-bit output: Overflow in add/acc
            PATTERNBDETECT              => open,                -- 1-bit output: Pattern bar detect
            PATTERNDETECT               => open,                -- 1-bit output: Pattern detect
            UNDERFLOW                   => open,                -- 1-bit output: Underflow in add/acc
            -- Data outputs: Data Ports
            CARRYOUT                    => open,                -- 4-bit output: Carry
            P                           => dsp1_P,              -- 48-bit output: Primary data
            XOROUT                      => open,                -- 8-bit output: XOR data
            -- Cascade inputs: Cascade Ports
            ACIN                        => (others=>'0'),       -- 30-bit input: A cascade data
            BCIN                        => (others=>'0'),       -- 18-bit input: B cascade
            CARRYCASCIN                 => '0',                 -- 1-bit input: Cascade carry
            MULTSIGNIN                  => '0',                 -- 1-bit input: Multiplier sign cascade
            PCIN                        => dsp0_pcout,          -- 48-bit input: P cascade
            -- Control inputs: Control Inputs/Status Bits
            ALUMODE                     => ALUMODE,             -- 4-bit input: ALU control
            CARRYINSEL                  => (others=>'0'),       -- 3-bit input: Carry select
            CLK                         => i_clk,               -- 1-bit input: Clock
            INMODE                      => dsp1_INMODE,         -- 5-bit input: INMODE control
            OPMODE                      => dsp1_OPMODE,         -- 9-bit input: Operation mode
            -- Data inputs: Data Ports
            A                           => dsp1_A,              -- 30-bit input: A data
            B                           => dsp1_B,              -- 18-bit input: B data
            C                           => (others=>'0'),       -- 48-bit input: C data
            CARRYIN                     => '0',               	-- 1-bit input: Carry-in
            D                           => dsp1_D,              -- 27-bit input: D data
            -- Reset/Clock Enable inputs: Reset/Clock Enable Inputs
            CEA1                        => '1',                 -- 1-bit input: Clock enable for 1st stage AREG
            CEA2                        => '1',                 -- 1-bit input: Clock enable for 2nd stage AREG
            CEAD                        => '1',                 -- 1-bit input: Clock enable for ADREG
            CEALUMODE                   => '1',                 -- 1-bit input: Clock enable for ALUMODE
            CEB1                        => '1',                 -- 1-bit input: Clock enable for 1st stage BREG
            CEB2                        => '1',                 -- 1-bit input: Clock enable for 2nd stage BREG
            CEC                         => '0',                 -- 1-bit input: Clock enable for CREG
            CECARRYIN                   => '0',                 -- 1-bit input: Clock enable for CARRYINREG
            CECTRL                      => '1',                 -- 1-bit input: Clock enable for OPMODEREG and CARRYINSELREG
            CED                         => '1',                 -- 1-bit input: Clock enable for DREG
            CEINMODE                    => '1',                 -- 1-bit input: Clock enable for INMODEREG
            CEM                         => '1',                 -- 1-bit input: Clock enable for MREG
            CEP                         => '1',                 -- 1-bit input: Clock enable for PREG
            RSTA                        => '0',                 -- 1-bit input: Reset for AREG
            RSTALLCARRYIN               => '0',                 -- 1-bit input: Reset for CARRYINREG
            RSTALUMODE                  => '0',                 -- 1-bit input: Reset for ALUMODEREG
            RSTB                        => '0',                 -- 1-bit input: Reset for BREG
            RSTC                        => '0',                 -- 1-bit input: Reset for CREG
            RSTCTRL                     => '0',                 -- 1-bit input: Reset for OPMODEREG and CARRYINSELREG
            RSTD                        => '0',                 -- 1-bit input: Reset for DREG and ADREG
            RSTINMODE                   => '0',                 -- 1-bit input: Reset for INMODEREG
            RSTM                        => '0',                 -- 1-bit input: Reset for MREG
            RSTP                        => '0'                  -- 1-bit input: Reset for PREG
        );

    -- calculate img data
    DSP2 : DSP48E2
        generic map (
            -- Feature Control Attributes: Data Path Selection
            AMULTSEL                    => "AD",                -- Selects A input to multiplier (A, AD)
            A_INPUT                     => "DIRECT",            -- Selects A input source, "DIRECT" (A port) or "CASCADE" (ACIN port)
            BMULTSEL                    => "B",                 -- Selects B input to multiplier (AD, B)
            B_INPUT                     => "DIRECT",            -- Selects B input source, "DIRECT" (B port) or "CASCADE" (BCIN port)
            PREADDINSEL                 => "A",                 -- Selects input to pre-adder (A, B)
            RND                         => X"000000000000",     -- Rounding Constant
            USE_MULT                    => "MULTIPLY",          -- Select multiplier usage (DYNAMIC, MULTIPLY, NONE)
            USE_SIMD                    => "ONE48",             -- SIMD selection (FOUR12, ONE48, TWO24)
            USE_WIDEXOR                 => "FALSE",             -- Use the Wide XOR function (FALSE, TRUE)
            XORSIMD                     => "XOR24_48_96",       -- Mode of operation for the Wide XOR (XOR12, XOR24_48_96)
            -- Pattern Detector Attributes: Pattern Detection Configuration
            AUTORESET_PATDET            => "NO_RESET",          -- NO_RESET, RESET_MATCH, RESET_NOT_MATCH
            AUTORESET_PRIORITY          => "RESET",             -- Priority of AUTORESET vs. CEP (CEP, RESET).
            MASK                        => X"3fffffffffff",     -- 48-bit mask value for pattern detect (1=ignore)
            PATTERN                     => X"000000000000",     -- 48-bit pattern match for pattern detect
            SEL_MASK                    => "MASK",              -- C, MASK, ROUNDING_MODE1, ROUNDING_MODE2
            SEL_PATTERN                 => "PATTERN",           -- Select pattern value (C, PATTERN)
            USE_PATTERN_DETECT          => "NO_PATDET",         -- Enable pattern detect (NO_PATDET, PATDET)
            -- Programmable Inversion Attributes: Specifies built-in programmable inversion on specific pins
            IS_ALUMODE_INVERTED         => "0000",              -- Optional inversion for ALUMODE
            IS_CARRYIN_INVERTED         => '0',                 -- Optional inversion for CARRYIN
            IS_CLK_INVERTED             => '0',                 -- Optional inversion for CLK
            IS_INMODE_INVERTED          => "00000",             -- Optional inversion for INMODE
            IS_OPMODE_INVERTED          => "000000000",         -- Optional inversion for OPMODE
            IS_RSTALLCARRYIN_INVERTED   => '0',                 -- Optional inversion for RSTALLCARRYIN
            IS_RSTALUMODE_INVERTED      => '0',                 -- Optional inversion for RSTALUMODE
            IS_RSTA_INVERTED            => '0',                 -- Optional inversion for RSTA
            IS_RSTB_INVERTED            => '0',                 -- Optional inversion for RSTB
            IS_RSTCTRL_INVERTED         => '0',                 -- Optional inversion for RSTCTRL
            IS_RSTC_INVERTED            => '0',                 -- Optional inversion for RSTC
            IS_RSTD_INVERTED            => '0',                 -- Optional inversion for RSTD
            IS_RSTINMODE_INVERTED       => '0',                 -- Optional inversion for RSTINMODE
            IS_RSTM_INVERTED            => '0',                 -- Optional inversion for RSTM
            IS_RSTP_INVERTED            => '0',                 -- Optional inversion for RSTP
            -- Register Control Attributes: Pipeline Register Configuration
            ACASCREG                    => 2,                   -- Number of pipeline stages between A/ACIN and ACOUT (0-2)
            ADREG                       => 1,                   -- Pipeline stages for pre-adder (0-1)
            ALUMODEREG                  => 1,                   -- Pipeline stages for ALUMODE (0-1)
            AREG                        => 2,                   -- Pipeline stages for A (0-2)
            BCASCREG                    => 1,                   -- Number of pipeline stages between B/BCIN and BCOUT (0-2)
            BREG                        => 2,                   -- Pipeline stages for B (0-2)
            CARRYINREG                  => 1,                   -- Pipeline stages for CARRYIN (0-1)
            CARRYINSELREG               => 1,                 	-- Pipeline stages for CARRYINSEL (0-1)
            CREG                        => 1,                   -- Pipeline stages for C (0-1)
            DREG                        => 1,                   -- Pipeline stages for D (0-1)
            INMODEREG                   => 1,                   -- Pipeline stages for INMODE (0-1)
            MREG                        => 1,                   -- Multiplier pipeline stages (0-1)
            OPMODEREG                   => 1,                   -- Pipeline stages for OPMODE (0-1)
            PREG                        => 1                    -- Number of pipeline stages for P (0-1)
        )
        port map (
            -- Cascade outputs: Cascade Ports
            ACOUT                       => open,                -- 30-bit output: A port cascade
            BCOUT                       => open,                -- 18-bit output: B cascade
            CARRYCASCOUT                => open,                -- 1-bit output: Cascade carry
            MULTSIGNOUT                 => open,                -- 1-bit output: Multiplier sign cascade
            PCOUT                       => open,                -- 48-bit output: Cascade output
            -- Control outputs: Control Inputs/Status Bits
            OVERFLOW                    => open,                -- 1-bit output: Overflow in add/acc
            PATTERNBDETECT              => open,                -- 1-bit output: Pattern bar detect
            PATTERNDETECT               => open,                -- 1-bit output: Pattern detect
            UNDERFLOW                   => open,                -- 1-bit output: Underflow in add/acc
            -- Data outputs: Data Ports
            CARRYOUT                    => open,             	-- 4-bit output: Carry
            P                           => dsp2_P,              -- 48-bit output: Primary data
            XOROUT                      => open,                -- 8-bit output: XOR data
            -- Cascade inputs: Cascade Ports
            ACIN                        => (others=>'0'),       -- 30-bit input: A cascade data
            BCIN                        => (others=>'0'),       -- 18-bit input: B cascade
            CARRYCASCIN                 => '0',                 -- 1-bit input: Cascade carry
            MULTSIGNIN                  => '0',                 -- 1-bit input: Multiplier sign cascade
            PCIN                        => (others=>'0'),       -- 48-bit input: P cascade
            -- Control inputs: Control Inputs/Status Bits
            ALUMODE                     => ALUMODE,             -- 4-bit input: ALU control
            CARRYINSEL                  => (others=>'0'),       -- 3-bit input: Carry select
            CLK                         => i_clk,               -- 1-bit input: Clock
            INMODE                      => dsp2_INMODE,         -- 5-bit input: INMODE control
            OPMODE                      => dsp2_OPMODE,         -- 9-bit input: Operation mode
            -- Data inputs: Data Ports
            A                           => dsp2_A,              -- 30-bit input: A data
            B                           => dsp2_B,              -- 18-bit input: B data
            C                           => dsp0_P,              -- 48-bit input: C data
            CARRYIN                     => '0',               	-- 1-bit input: Carry-in
            D                           => dsp2_D,              -- 27-bit input: D data
            -- Reset/Clock Enable inputs: Reset/Clock Enable Inputs
            CEA1                        => '1',                 -- 1-bit input: Clock enable for 1st stage AREG
            CEA2                        => '1',                 -- 1-bit input: Clock enable for 2nd stage AREG
            CEAD                        => '1',                 -- 1-bit input: Clock enable for ADREG
            CEALUMODE                   => '1',                 -- 1-bit input: Clock enable for ALUMODE
            CEB1                        => '1',                 -- 1-bit input: Clock enable for 1st stage BREG
            CEB2                        => '1',                 -- 1-bit input: Clock enable for 2nd stage BREG
            CEC                         => '1',                 -- 1-bit input: Clock enable for CREG
            CECARRYIN                   => '0',                 -- 1-bit input: Clock enable for CARRYINREG
            CECTRL                      => '1',                 -- 1-bit input: Clock enable for OPMODEREG and CARRYINSELREG
            CED                         => '1',                 -- 1-bit input: Clock enable for DREG
            CEINMODE                    => '1',                 -- 1-bit input: Clock enable for INMODEREG
            CEM                         => '1',                 -- 1-bit input: Clock enable for MREG
            CEP                         => '1',                 -- 1-bit input: Clock enable for PREG
            RSTA                        => '0',                 -- 1-bit input: Reset for AREG
            RSTALLCARRYIN               => '0',                 -- 1-bit input: Reset for CARRYINREG
            RSTALUMODE                  => '0',                 -- 1-bit input: Reset for ALUMODEREG
            RSTB                        => '0',                 -- 1-bit input: Reset for BREG
            RSTC                        => '0',                 -- 1-bit input: Reset for CREG
            RSTCTRL                     => '0',                 -- 1-bit input: Reset for OPMODEREG and CARRYINSELREG
            RSTD                        => '0',                 -- 1-bit input: Reset for DREG and ADREG
            RSTINMODE                   => '0',                 -- 1-bit input: Reset for INMODEREG
            RSTM                        => '0',                 -- 1-bit input: Reset for MREG
            RSTP                        => '0'                  -- 1-bit input: Reset for PREG
        );

end Behavioral;
