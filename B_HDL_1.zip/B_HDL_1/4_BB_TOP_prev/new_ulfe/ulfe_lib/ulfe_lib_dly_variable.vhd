-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.04.25 v1.0] Initial release
-- [2023.01.04 v1.1] add reset
-- *****************************************************************************


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

entity ulfe_lib_dly_variable is
    generic (
        data_i_width                : integer := 16
    );
    port ( 
        i_rst                       : in std_logic;
        i_clk                       : in std_logic;
        dly_value                   : in std_logic_vector(data_i_width -1 downto 0);
        
        i_tick                      : in std_logic;
        o_tick                      : out std_logic
    );
end ulfe_lib_dly_variable;

architecture Behavioral of ulfe_lib_dly_variable is

    signal  count                   : std_logic_vector(data_i_width -1 downto 0);
    signal  count_en                : std_logic;

begin

    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            count_en                <=  '0';
        elsif (rising_edge(i_clk)) then
            if (i_tick = '1') then
                count_en            <=  '1';
            elsif (count = dly_value) then
                count_en            <=  '0';
            else
                count_en            <=  count_en;
            end if;
        end if;
    end process;
    
    
    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            count                   <=  (others=>'0');
        elsif (rising_edge(i_clk)) then
            if (i_tick = '1') then
                count               <=  (others=>'0');
            elsif (count_en = '1' and count = dly_value) then
                count               <=  (others=>'0');
            elsif (count_en = '1') then
                count               <=  count + '1';
            else
                count               <=  count;
            end if;
        end if;
    end process;
    
    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            o_tick                  <=  '0';
        elsif (rising_edge(i_clk)) then
            if (count_en = '1' and count = dly_value-1) then
                o_tick              <=  '1';
            else
                o_tick              <=  '0';
            end if;
        end if;
    end process;

end Behavioral;
