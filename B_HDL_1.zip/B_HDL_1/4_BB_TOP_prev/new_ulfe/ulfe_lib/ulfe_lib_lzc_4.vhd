-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.11.15 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity ulfe_lib_lzc_4 is
    Port(
        i_data                          : in std_logic_vector(4-1 downto 0);
        
        o_a                             : out std_logic;
        o_q1                            : out std_logic;
        o_q0                            : out std_logic
    );
end ulfe_lib_lzc_4;

architecture Behavioral of ulfe_lib_lzc_4 is

begin

    -----------------------------
    --x3  x2  x1  x0  a  q1  q0--
    --0   0   0   0   1  X   X --
    --0   0   0   1   0  1   1 --
    --0   0   1   X   0  1   0 --
    --0   1   X   X   0  0   1 --
    --1   X   X   X   0  0   0 --
    -----------------------------

    o_a                    <=  not (i_data(3) or i_data(2) or i_data(1) or i_data(0));
    o_q1                   <=  i_data(3) nor i_data(2);
    o_q0                   <=  (not i_data(3)) and (i_data(2) or (not i_data(1)));

end Behavioral;
