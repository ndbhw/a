-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.11.17 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;

library work;
use work.ulfe_func.all;

Library xpm;
use xpm.vcomponents.all;

entity ulfe_lib_tdpram_distribute is
    generic (
        memory_primitive                    : string := "distributed";
        read_latency                        : integer := 2;
        wt_mem_d_width                      : integer := 30;
        rd_mem_d_width                      : integer := 60;
        wt_max_addr                         : integer := 2048;
        rd_max_addr                         : integer := 1024
    );
    Port (
        i_clk                               : in std_logic; 
        
        i_wt_enable                         : in std_logic;
        i_wt_addra                          : in std_logic_vector(log2ceil(wt_max_addr)-1 downto 0);
        i_wt_data                           : in std_logic_vector(wt_mem_d_width-1 downto 0);
        o_rd_douta                          : out std_logic_vector(rd_mem_d_width-1 downto 0);
        
        i_rd_addrb                          : in std_logic_vector(log2ceil(rd_max_addr)-1 downto 0);
        o_rd_doutb                          : out std_logic_vector(rd_mem_d_width-1 downto 0)
    );
end ulfe_lib_tdpram_distribute;

architecture Behavioral of ulfe_lib_tdpram_distribute is

    constant mem_size                       : integer := wt_max_addr*wt_mem_d_width;

begin

    lib_tdpram : xpm_memory_tdpram
        generic map (
            addr_width_a                =>  log2ceil(wt_max_addr),
            addr_width_b                =>  log2ceil(rd_max_addr),
            auto_sleep_time             =>  0,
            byte_write_width_a          =>  wt_mem_d_width,
            byte_write_width_b          =>  wt_mem_d_width,
            cascade_height              =>  0,
            clocking_mode               =>  "common_clock",
            ecc_mode                    =>  "no_ecc",
            memory_init_file            =>  "none",
            memory_init_param           =>  "0",
            memory_optimization         =>  "true",
            memory_primitive            =>  memory_primitive,
            memory_size                 =>  mem_size,
            message_control             =>  0,
            read_data_width_a           =>  rd_mem_d_width,
            read_data_width_b           =>  rd_mem_d_width,
            read_latency_a              =>  read_latency,
            read_latency_b              =>  read_latency,
            read_reset_value_a          =>  "0",
            read_reset_value_b          =>  "0",
            rst_mode_a                  =>  "sync",
            rst_mode_b                  =>  "sync",
            sim_assert_chk              =>  0,
            use_embedded_constraint     =>  0,
            use_mem_init                =>  1,
            use_mem_init_mmi            =>  0,
            wakeup_time                 =>  "disable_sleep",
            write_data_width_a          =>  wt_mem_d_width,
            write_data_width_b          =>  wt_mem_d_width,
            write_mode_a                =>  "read_first",
            write_mode_b                =>  "read_first",
            write_protect               =>  1
        )
        port map (
            dbiterra                    =>  open,
            dbiterrb                    =>  open,		-- indicate double bit error occurrence on the data output of port B
            douta                       =>  o_rd_douta,
            doutb                       =>  o_rd_doutb,
            sbiterra                    =>  open,
            sbiterrb                    =>  open,		-- indicate single bit error occurrence on the data output of port B
            addra                       =>  i_wt_addra,
            addrb                       =>  i_rd_addrb,
            clka                        =>  i_clk,
            clkb                        =>  i_clk,
            dina                        =>  i_wt_data,
            dinb                        =>  (others=>'0'),
            ena                         =>  '1',
            enb                         =>  '1',
            injectdbiterra              =>  '0',
            injectdbiterrb              =>  '0',
            injectsbiterra              =>  '0',
            injectsbiterrb              =>  '0',
            regcea                      =>  '1',
            regceb                      =>  '1',
            rsta                        =>  '0',
            rstb                        =>  '0',
            sleep                       =>  '0',
            wea(0)                      =>  i_wt_enable,
            web(0)                      =>  '0'
        );

end Behavioral;
