-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.04.25 v1.0] Initial release
-- *****************************************************************************


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity ulfe_lib_sat_u is
    generic(
        d_width                             : integer := 16;
        sat_width                           : integer := 15
    );
    Port ( 
        i_clk                               : in std_logic;
        
        i_data                              : in std_logic_vector(d_width-1 downto 0);
        o_data                              : out std_logic_vector(sat_width-1 downto 0)
    );
end ulfe_lib_sat_u;

architecture Behavioral of ulfe_lib_sat_u is

    constant  ones                          : std_logic_vector(d_width-1 downto 0) := (others=>'1');
    signal  saturation_data                 : std_logic_vector(d_width-sat_width downto 0);

begin

    saturation_d0 : for i in d_width-sat_width downto 1 generate
        saturation_data(i)                  <=  '0';
    end generate;	
        saturation_data(0)                  <=  '1';
    
    -- 1clk
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_data(d_width-1 downto sat_width-1) > saturation_data) then  -- saturation
                o_data                      <=  ones(sat_width-1 downto 0);
            else
                o_data                      <=  i_data(sat_width-1 downto 0);
            end if;
        end if;
    end process;

end Behavioral;
