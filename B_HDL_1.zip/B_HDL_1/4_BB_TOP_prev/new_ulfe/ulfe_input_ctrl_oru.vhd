-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2024, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2024.05.02 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_func.all;
use work.ulfe_config_oru.all;
use work.ulfe_component_pack_oru.all;

entity ulfe_input_ctrl_oru is
    generic (
        NUM_RX_ANT                          : integer := 8;
        NUM_PRE_PROCESSING                  : integer := 4;
        CHAIN_ANT_NUM                       : integer := 2;
        TOP_DIO_BW                          : integer := 16
    );
    Port (
        i_rst                               : in std_logic;
        i_clk                               : in std_logic;
        
        i_uin_sync                          : in std_logic;
        i_uin_vld                           : in std_logic_vector(NUM_RX_ANT-1 downto 0);
        i_uin_iq                            : in std_logic_vector(2*NUM_RX_ANT*TOP_DIO_BW-1 downto 0);
        
        i_tdd_sig                           : in std_logic;
        
        i_fftType                           : in std_logic_vector(2-1 downto 0);
        
        o_fs_num                            : out std_logic_array5(NUM_PRE_PROCESSING-1 downto 0);
        o_SR_info                           : out std_logic_array3(NUM_PRE_PROCESSING-1 downto 0);
        
        o_uin_sync                          : out std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
        o_uin_vld                           : out std_logic_vector(CHAIN_ANT_NUM*NUM_PRE_PROCESSING-1 downto 0);
        o_uin_i                             : out std_logic_array15(NUM_PRE_PROCESSING-1 downto 0);
        o_uin_q                             : out std_logic_array15(NUM_PRE_PROCESSING-1 downto 0);
        
        o_rssi                              : out std_logic_array32(NUM_RX_ANT-1 downto 0);
        o_tdd_signal_count_adv              : out std_logic_vector(22-1 downto 0)
    );
end ulfe_input_ctrl_oru;

architecture Behavioral of ulfe_input_ctrl_oru is

    type std_logic_array_DIO_x2			is array(natural range <>) of std_logic_vector(TOP_DIO_BW*2-1 downto 0);
    type std_logic_array_CANT_DIO_x2	is array(natural range <>) of std_logic_array_DIO_x2(CHAIN_ANT_NUM-1 downto 0);
    type std_logic_array_CANT_32		is array(natural range <>) of std_logic_array32(CHAIN_ANT_NUM-1 downto 0);
    
    signal  fs_num                          : std_logic_vector(5-1 downto 0);
    signal  SR_info                         : std_logic_vector(3-1 downto 0);
    signal  r_tdd_sig                       : std_logic;
    
    signal  sample_count                    : std_logic_vector(5-1 downto 0);
    
    signal  i_uin_vld_1d                    : std_logic_vector(NUM_RX_ANT-1 downto 0);
    signal  i_uin_sync_1d                   : std_logic;
    signal  r_uin_sync                      : std_logic;
    signal  r_uin_sync_2d                   : std_logic_vector(NUM_PRE_PROCESSING-1 downto 0);
    
    signal  uin_iq_chain                    : std_logic_array_CANT_DIO_x2(NUM_PRE_PROCESSING-1 downto 0);
    signal  uin_vld_out                     : std_logic_vector(CHAIN_ANT_NUM*NUM_PRE_PROCESSING-1 downto 0);
    signal  uin_vld_out_1d                  : std_logic_vector(CHAIN_ANT_NUM*NUM_PRE_PROCESSING-1 downto 0);
    signal  uin_i                           : std_logic_array16(NUM_PRE_PROCESSING-1 downto 0);
    signal  uin_q                           : std_logic_array16(NUM_PRE_PROCESSING-1 downto 0);
    signal  uin_i_sat                       : std_logic_array15(NUM_PRE_PROCESSING-1 downto 0);
    signal  uin_q_sat                       : std_logic_array15(NUM_PRE_PROCESSING-1 downto 0);
    
    signal  rssi                            : std_logic_array_CANT_32(NUM_PRE_PROCESSING-1 downto 0);
    
    -----------------------------------------------------------------------------------------------------------------
    -- test
    signal  t_tdd_signal_count_adv          : std_logic_vector(22-1 downto 0);
    signal  t_tdd_signal_count_adv_d        : std_logic_vector(22-1 downto 0);	
    signal  count_flag_adv                  : std_logic;
    
    attribute MARK_DEBUG : string;
    attribute MARK_DEBUG of uin_iq_chain	: signal is "TRUE";

begin

    -----------------------------------------------------------------------------------------------------------------
    -- test
    o_tdd_signal_count_adv                          <=  t_tdd_signal_count_adv_d;	
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (r_uin_sync = '1') then
                t_tdd_signal_count_adv              <=  (others=>'0');
                t_tdd_signal_count_adv_d            <=  t_tdd_signal_count_adv;
            elsif (count_flag_adv = '0') then
                t_tdd_signal_count_adv              <=  t_tdd_signal_count_adv + '1';
                t_tdd_signal_count_adv_d            <=  t_tdd_signal_count_adv_d;
            else
                t_tdd_signal_count_adv              <=  t_tdd_signal_count_adv;
                t_tdd_signal_count_adv_d            <=  t_tdd_signal_count_adv_d;
            end if;
            
            if (r_uin_sync = '1') then
                count_flag_adv                      <=  '0';
            elsif (i_uin_vld_1d(0) = '0' and i_uin_vld(0) = '1') then
                count_flag_adv                      <=  '1';
            else
                count_flag_adv                      <=  count_flag_adv;
            end if;
        end if;
    end process;

    -----------------------------------------------------------------------------------------------------------------

    U_PARAM_PROC : ulfe_param_proc_oru
        port map(
            i_clk                               =>  i_clk,                          --: in std_logic;
            
            i_fftType                           =>  i_fftType,                      --: in std_logic_vector(2-1 downto 0);
            
            o_fs_num                            =>  fs_num,                         --: out std_logic_vector(5-1 downto 0);
            o_SR_info                           =>  SR_info                         --: out std_logic_vector(3-1 downto 0)	-- 0:7.68, 1:15.36, 2:30.72, 3:61.44, 4:122.88, 5:245.76		
        );
    
    DATA_REARRANGE_st0 : for i in 0 to NUM_PRE_PROCESSING-1 generate
        DATA_REARRANGE_st1 : for q in 0 to CHAIN_ANT_NUM-1 generate
            process(i_clk)
            begin
                if (rising_edge(i_clk)) then
                    uin_iq_chain(i)(q)          <=  i_uin_iq(2*TOP_DIO_BW*((i*CHAIN_ANT_NUM)+(q+1))-1 downto 2*TOP_DIO_BW*((i*CHAIN_ANT_NUM)+q));
                end if;
            end process;
        end generate DATA_REARRANGE_st1;
    end generate DATA_REARRANGE_st0;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            i_uin_sync_1d                       <=  i_uin_sync;
            i_uin_vld_1d                        <=  i_uin_vld;
            
            if (i_uin_sync_1d = '0' and i_uin_sync = '1') then
                r_uin_sync                      <=  '1';
            else
                r_uin_sync                      <=  '0';
            end if;
        end if;
    end process;
    
    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            sample_count                        <=  (others=>'1');
        elsif (rising_edge(i_clk)) then
            if (r_uin_sync = '1' or (sample_count = fs_num) or sample_count = b"11111") then
                sample_count                    <=  (others=>'0');
            else
                sample_count                    <=  sample_count + '1';
            end if;
        end if;
    end process;
    
    DATA_OUT : for i in 0 to NUM_PRE_PROCESSING-1 generate
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                if (sample_count > conv_std_logic_vector(CHAIN_ANT_NUM-1,5)) then
                    uin_i(i)                    <=  (others=>'0');
                    uin_q(i)                    <=  (others=>'0');
                else
                    uin_i(i)                    <=  uin_iq_chain(i)(conv_integer(sample_count))(31 downto 16);
                    uin_q(i)                    <=  uin_iq_chain(i)(conv_integer(sample_count))(15 downto 0);
                end if;
            end if;
        end process;
        
        symm_sat_i : ulfe_lib_symm_sat generic map(16,15) port map(i_clk, uin_i(i), uin_i_sat(i));
        symm_sat_q : ulfe_lib_symm_sat generic map(16,15) port map(i_clk, uin_q(i), uin_q_sat(i));
    end generate DATA_OUT;
    
    VLD_OUT_ST0 : for i in 0 to NUM_PRE_PROCESSING-1 generate
        VLD_OUT_ST1 : for q in 0 to CHAIN_ANT_NUM-1 generate
            process(i_clk)
            begin
                if (rising_edge(i_clk)) then
                    if (sample_count > conv_std_logic_vector(CHAIN_ANT_NUM-1,5)) then
                        uin_vld_out(i*CHAIN_ANT_NUM+q)          <=  '0';
                    elsif (sample_count = conv_std_logic_vector(q,5)) then
                        uin_vld_out(i*CHAIN_ANT_NUM+q)          <=  '1';
                    else
                        uin_vld_out(i*CHAIN_ANT_NUM+q)          <=  '0';
                    end if;
                end if;
            end process;
        end generate VLD_OUT_ST1;
    end generate VLD_OUT_ST0;
    
    GEN_0 : for i in 0 to NUM_PRE_PROCESSING-1 generate
        fsync_dly : ulfe_lib_dly_fixed generic map(2,1) port map(i_clk=>i_clk, data_i(0)=>r_uin_sync, data_o(0)=>r_uin_sync_2d(i));
        
        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                o_fs_num(i)                         <=  fs_num;
                o_SR_info(i)                        <=  SR_info;
            end if;
        end process;
    end generate GEN_0;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            uin_vld_out_1d                          <=  uin_vld_out;
        end if;
    end process;
    
    o_uin_sync                                  <=  r_uin_sync_2d;
    o_uin_vld                                   <=  uin_vld_out_1d;
    o_uin_i                                     <=  uin_i_sat;
    o_uin_q                                     <=  uin_q_sat;

    -----------------------------------------------------------------------------------------------
    -- TDRSSI FOR DEBUG
    
    RSSI_FALSE : if (DBG_TDRSSI_ENABLE = FALSE) generate
        rssi_out : for i in 0 to NUM_RX_ANT-1 generate
            o_rssi(i)                           <=	(others=>'0');
        end generate rssi_out;
    end generate RSSI_FALSE;
    
    RSSI_TRUE : if (DBG_TDRSSI_ENABLE = TRUE) generate
        TDD : if (DUPLEX_TYPE = "TDD") generate
            process(i_clk)
            begin
                if (rising_edge(i_clk)) then
                    r_tdd_sig                   <=  i_uin_vld(0);
                end if;
            end process;
        end generate TDD;
        
        FDD : if (DUPLEX_TYPE = "FDD") generate
            r_tdd_sig                           <=  '1';
        end generate FDD;
        
        RSSI_GEN : for i in 0 to NUM_PRE_PROCESSING-1 generate
            DBG_TDRSSI : ulfe_tdrssi_dbg_oru generic map(CHAIN_ANT_NUM)
                port map(
                    i_rst                   =>  i_rst,                      --: in std_logic;
                    i_clk                   =>  i_clk,                      --: in std_logic;
                    
                    i_uin_sync              =>  r_uin_sync_2d(0),           --: in std_logic;
                    i_uin_vld               =>  uin_vld_out_1d((i+1)*CHAIN_ANT_NUM-1 downto i*CHAIN_ANT_NUM),                --: in std_logic_vector(NUM_RX_ANT-1 downto 0);;
                    i_uin_i                 =>  uin_i_sat(i),               --: in std_logic_vector(15-1 downto 0);
                    i_uin_q                 =>  uin_q_sat(i),               --: in std_logic_vector(15-1 downto 0);
                    
                    i_fs_num                =>  fs_num,                     --: in std_logic_vector(5-1 downto 0);
                    i_SR_info               =>  SR_info,                    --: in std_logic_vector(3-1 downto 0);
                    i_tdd_sig               =>  r_tdd_sig,                  --: in std_logic;
                    
                    o_xssi                  =>  rssi(i)                     --: out std_logic_array32(NUM_RX_ANT-1 downto 0)
                );
        end generate RSSI_GEN;
        
        REARRANGE_RSSI_ST0 : for i in 0 to NUM_PRE_PROCESSING-1 generate
            REARRANGE_RSSI_ST1 : for q in 0 to CHAIN_ANT_NUM-1 generate
                o_rssi(i*CHAIN_ANT_NUM+q)                <=	rssi(i)(q);
            end generate REARRANGE_RSSI_ST1;
        end generate REARRANGE_RSSI_ST0;
        
    end generate RSSI_TRUE;

end Behavioral;