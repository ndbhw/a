-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2024, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2024.05.02 v1.0] Initial release
-- *****************************************************************************

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ulfe_func.all;
use work.ulfe_component_pack_oru.all;
use work.ulfe_config_oru.all;

entity ulfe_tdrssi_rpt_oru is
    generic (
        NUM_ANT                             : integer := 8
    );
    Port(
        i_rst                               : in std_logic;
        i_clk                               : in std_logic;
        
        i_framesync                         : in std_logic;
        i_data_vld                          : in std_logic;
        i_tdrssi                            : in std_logic_array32(NUM_ANT-1 downto 0);
        
        i_tdrssi_StartSlotIdx               : in std_logic_vector(7-1 downto 0);
        i_tdrssi_StartSymbIdx               : in std_logic_vector(4-1 downto 0);
        i_tdrssi_SymbSize                   : in std_logic_vector(6-1 downto 0);
        i_tdrssi_Trigger                    : in std_logic;
        i_tdrssi_SelSymbIdx_rpt             : in std_logic_vector(6-1 downto 0);
        
        o_tdrssi_rpt_done                   : out std_logic;
        o_tdrssi_rpt_data                   : out std_logic_array32(NUM_ANT-1 downto 0)
    );
end ulfe_tdrssi_rpt_oru;

architecture Behavioral of ulfe_tdrssi_rpt_oru is

    constant MAX_SYMIDX                         : std_logic_vector(4-1 downto 0) := ternary_func(CPTYPE="normal",X"D",X"B");

    signal  r_tdrssi                            : std_logic_array32(NUM_ANT-1 downto 0);
    signal  i_data_vld_1d                       : std_logic;
    signal  i_data_vld_2d                       : std_logic;
    
    signal  i_tdrssi_Trigger_1d                 : std_logic;
    signal  r_tdrssi_StartSlotIdx               : std_logic_vector(7-1 downto 0);
    signal  r_tdrssi_StartSymbIdx               : std_logic_vector(4-1 downto 0);
    signal  r_tdrssi_SelSymbIdx_rpt             : std_logic_vector(5-1 downto 0);
    
    signal  slot_idx                            : std_logic_vector(7-1 downto 0);
    signal  symb_idx                            : std_logic_vector(4-1 downto 0);
    
    signal  tdrssi_rpt_ready                    : std_logic;
    signal  tdrssi_rpt_done                     : std_logic;
    signal  symb_same_flag                      : std_logic;
    
    signal  inter_sym_cnt                       : std_logic_vector(5-1 downto 0);
    signal  wt_enable                           : std_logic;

begin

    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            i_data_vld_1d                           <=  i_data_vld;
            i_data_vld_2d                           <=  i_data_vld_1d;
            i_tdrssi_Trigger_1d                     <=  i_tdrssi_Trigger;
            
            r_tdrssi_StartSlotIdx                   <=  i_tdrssi_StartSlotIdx;
            r_tdrssi_StartSymbIdx                   <=  i_tdrssi_StartSymbIdx;
            r_tdrssi_SelSymbIdx_rpt                 <=  i_tdrssi_SelSymbIdx_rpt(4 downto 0);
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (i_framesync = '1') then
                slot_idx                            <=  (others=>'0');
                symb_idx                            <=  (others=>'0');
            else
                if (i_data_vld_1d = '1' and i_data_vld = '0' and symb_idx = MAX_SYMIDX) then
                    symb_idx                        <=  (others=>'0');
                    slot_idx                        <=  slot_idx + '1';
                elsif (i_data_vld_1d = '1' and i_data_vld = '0') then
                    symb_idx                        <=  symb_idx + '1';
                    slot_idx                        <=  slot_idx;
                else
                    symb_idx                        <=  symb_idx;
                    slot_idx                        <=  slot_idx;
                end if;
            end if;
        end if;
    end process;
    
    process(i_rst, i_clk)
    begin
        if (i_rst = '1') then
            tdrssi_rpt_ready                        <=  '0';
            tdrssi_rpt_done                         <=  '0';
            symb_same_flag                          <=  '0';
        elsif (rising_edge(i_clk)) then
            if (i_tdrssi_Trigger_1d = '0' and i_tdrssi_Trigger = '1') then
                tdrssi_rpt_ready                    <=  '1';
                tdrssi_rpt_done                     <=  '0';
            elsif (tdrssi_rpt_ready = '1' and i_data_vld_1d = '1' and i_data_vld = '0' and inter_sym_cnt = b"11111") then
                tdrssi_rpt_ready                    <=  '0';
                tdrssi_rpt_done                     <=  '1';
            else
                tdrssi_rpt_ready                    <=  tdrssi_rpt_ready;
                tdrssi_rpt_done                     <=  tdrssi_rpt_done;
            end if;
            
            if (tdrssi_rpt_ready = '0') then
                symb_same_flag                      <=  '0';
            elsif (tdrssi_rpt_ready = '1' and (slot_idx = r_tdrssi_StartSlotIdx) and (symb_idx = r_tdrssi_StartSymbIdx)) then
                symb_same_flag                      <=  '1';
            else
                symb_same_flag                      <=  symb_same_flag;
            end if;
        end if;
    end process;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            if (symb_same_flag = '0') then
                inter_sym_cnt                       <=  (others=>'0');
            elsif (symb_same_flag = '1' and i_data_vld_2d = '1' and i_data_vld_1d = '0') then
                inter_sym_cnt                       <=  inter_sym_cnt + '1';
            else
                inter_sym_cnt                       <=  inter_sym_cnt;
            end if;
            
            if (symb_same_flag = '1' and i_data_vld_1d = '1' and i_data_vld = '0') then
                wt_enable                           <=  '1';
            else
                wt_enable                           <=  '0';
            end if;
            
            r_tdrssi                                <=  i_tdrssi;
        end if;
    end process;
    
    RPT_TDRSSI_BUFFER : for i in 0 to NUM_ANT-1 generate
        U : ulfe_lib_sdpram generic map("distributed",2,32,32,32,32) port map(i_clk, wt_enable, inter_sym_cnt, r_tdrssi(i), r_tdrssi_SelSymbIdx_rpt, o_tdrssi_rpt_data(i));
    end generate RPT_TDRSSI_BUFFER;
    
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            o_tdrssi_rpt_done                       <=  tdrssi_rpt_done;
        end if;
    end process;

end Behavioral;