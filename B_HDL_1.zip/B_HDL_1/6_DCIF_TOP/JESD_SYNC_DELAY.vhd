library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

entity JESD_SYNC_DELAY is
    port(
    RESET                              : in  std_logic;
    CLK                                : in  std_logic;
    
    SYNC_DELAY_VALUE                   : in  std_logic_vector(23 downto 0);
    
    SYNC_IN                            : in  std_logic;
    SYNC_OUT                           : out std_logic
    );
end JESD_SYNC_DELAY;

architecture ARC_JESD_SYNC_DELAY of JESD_SYNC_DELAY is

    signal sync_dly_value              : std_logic_vector(23 downto 0);

    signal bypass_sh                   : std_logic_vector( 2 downto 0);
    
    signal bfn_strb_reg_dly            : std_logic_vector( 6 downto 0);
    
    signal bfn_strb_cntdly             : std_logic;
    
    signal shdly_sig                   : std_logic;
    
    signal cntdly_value                : std_logic_vector(23 downto 0);
    signal cntdly_value_minus_1        : std_logic_vector(23 downto 0);
    signal cntdly_value_minus_7        : std_logic_vector(23 downto 0);
    signal cntdly_en                   : std_logic;

    signal sig_sh                      : std_logic_vector(2 downto 0);
    signal sig_rpls                    : std_logic;
    signal sig_fpls                    : std_logic;
    
    signal sig_rpls_d                  : std_logic;
    signal sig_fpls_d                  : std_logic;
    signal cntdly_sig                  : std_logic;
    
    signal rpls_dly_cnt                : std_logic_vector(23 downto 0);
    signal fpls_dly_cnt                : std_logic_vector(23 downto 0);

    signal rpls_checked                : std_logic;
    signal fpls_checked                : std_logic;
    
    signal state                       : std_logic;
    
begin

    P_For_Clocking : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            sync_dly_value <= SYNC_DELAY_VALUE;              
        end if;
    end process;

    ------------------------------------------------------------------------------------
    -- Delay count =< 6 (processing delay)
    ------------------------------------------------------------------------------------
    P_STRB_DLY_register : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            bfn_strb_reg_dly <= bfn_strb_reg_dly(5 downto 0) & SYNC_IN;
        end if;
    end process;

    -------------------------------------------------------------------------------------
    -- Delay count > 6 (processing delay)
    ------------------------------------------------------------------------------------
    P_Limit_Delay_Count : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            case (sync_dly_value) is
                when x"000000" => cntdly_value <= x"000007"     ; cntdly_en <= '0';
                when x"000001" => cntdly_value <= x"000007"     ; cntdly_en <= '0';
                when x"000002" => cntdly_value <= x"000007"     ; cntdly_en <= '0';
                when x"000003" => cntdly_value <= x"000007"     ; cntdly_en <= '0';
                when x"000004" => cntdly_value <= x"000007"     ; cntdly_en <= '0';
                when x"000005" => cntdly_value <= x"000007"     ; cntdly_en <= '0';
                when x"000006" => cntdly_value <= x"000007"     ; cntdly_en <= '0';
                when others    => cntdly_value <= sync_dly_value; cntdly_en <= '1';
            end case;

            cntdly_value_minus_1 <= cntdly_value - 1;
            cntdly_value_minus_7 <= cntdly_value - 7;
        end if;
    end process;
    
    P_Edge_Detect : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            sig_sh   <= sig_sh(1 downto 0) & SYNC_IN;
            sig_rpls <= sig_sh(1) and (not sig_sh(2));
            sig_fpls <= (not sig_sh(1)) and sig_sh(2);
        end if;
    end process;

    P_Pulse_count_delay : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (sig_rpls = '1') then               -- Rising edge pulse
                rpls_dly_cnt <= (others => '0');   -- count init
                rpls_checked <= '1';
            else
                if (rpls_dly_cnt = cntdly_value_minus_1) then
                    rpls_dly_cnt <= rpls_dly_cnt;
                    rpls_checked <= '0';
                else
                    if (rpls_checked = '1') then
                        rpls_dly_cnt <= rpls_dly_cnt + '1';
                    end if;
                end if;
            end if;
        
            if (sig_fpls = '1') then               -- Falling edge pulse
                fpls_dly_cnt <= (others => '0');   -- count init
                fpls_checked <= '1';
            else
                if (fpls_dly_cnt = cntdly_value_minus_1) then
                    fpls_dly_cnt <= fpls_dly_cnt;
                    fpls_checked <= '0';
                else
                    if (fpls_checked = '1') then
                        fpls_dly_cnt <= fpls_dly_cnt + '1';
                    end if;
                end if;
            end if;
        end if;
    end process;

    P_Delayed_Pulse : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (rpls_dly_cnt = cntdly_value_minus_7) then
                sig_rpls_d <= '1';
            else
                sig_rpls_d <= '0';
            end if;

            if (fpls_dly_cnt = cntdly_value_minus_7) then
                sig_fpls_d <= '1';
            else
                sig_fpls_d <= '0';
            end if;
        end if;
    end process;

    P_State_Define : process(RESET, CLK) begin
        if (RESET = '1') then
            state   <= '0';
            cntdly_sig <= '0'; 
        elsif (CLK'event) and (CLK = '1') then
            case (state) is
                when '0' =>
                     state <= '1';
                     if (sig_sh(2) = '0') then 
                         cntdly_sig <= '0';
                     else                   
                         cntdly_sig <= '1';
                     end if;
                when '1' =>
                     state <= state;
                     if (sig_rpls_d = '1') then
                          cntdly_sig <= '1';
                     elsif (sig_fpls_d = '1') then
                          cntdly_sig <= '0';
                     else
                          cntdly_sig <= cntdly_sig;
                     end if;
                when others =>
                     state   <= state;
                     cntdly_sig <= cntdly_sig;
            end case;
        end if;
    end process;

    -------------------------------------------------------------------------------------
    -- Delayed sync out selection
    ------------------------------------------------------------------------------------

    SYNC_OUT <= SYNC_IN when ((cntdly_en = '0') and (sync_dly_value(2 downto 0) = 0)) else 
                shdly_sig; 

    P_MUX : process(RESET, CLK) begin
        if (RESET = '1') then
            shdly_sig <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (cntdly_en = '1') then
                shdly_sig <= cntdly_sig;
            else
                case (sync_dly_value(2 downto 0)) is
                    when "000" =>
                        shdly_sig <= SYNC_IN;
                    when "001" =>
                        shdly_sig <= SYNC_IN;
                    when "010" =>
                        shdly_sig <= bfn_strb_reg_dly(0);
                    when "011" =>
                        shdly_sig <= bfn_strb_reg_dly(1);
                    when "100" =>
                        shdly_sig <= bfn_strb_reg_dly(2);
                    when "101" =>
                        shdly_sig <= bfn_strb_reg_dly(3);
                    when "110" =>
                        shdly_sig <= bfn_strb_reg_dly(4);
                    when "111" =>
                        shdly_sig <= bfn_strb_reg_dly(5);
                    when others =>
                        shdly_sig <= cntdly_sig;
                end case;
            end if;
        end if;
    end process;    

end ARC_JESD_SYNC_DELAY;
