----------------------------------------------------------------------------------
-- Company       : Samsung Electronics
-- Engineer      : HJ
--
-- Create Date   : 2023.09.11
-- Design Name   :
-- Module Name   : CPUIF_DCIF
-- Project Name  :
-- Target Devices: ZU15EG
-- Tool versions : Vivado 2021.1, Xilinx
-- Description   : Data converter interface module for RFIC
--
-- JESD_TX_LINK_NUM : 1
-- JESD_RX_LINK_NUM : 1
-- JESD_FB_LINK_NUM : 1
-- TX_ANT_NUM : 4
-- RX_ANT_NUM : 4
-- JESD_TX_LANE_NUM : 4
-- JESD_RX_LANE_NUM : 2
-- JESD_FB_LANE_NUM : 2
--
-- Revision      : JESD BD version

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;   
use ieee.std_logic_unsigned.all;

library UNISIM;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_CONFIG.all;

entity CPUIF_DCIF is
    generic
    (
        DCIF_MODULE_DATE                    : std_logic_vector(31 downto 0):= x"2023_1116"
    );    
    port(
        -- CPUIF
        RST_CPU                             : in  std_logic;                    
        CLK_CPU                             : in  std_logic;  
        ADDR_CPU_IN                         : in  std_logic_vector(15 downto 0);
        WDATA_CPU_IN                        : in  std_logic_vector(31 downto 0);
        RDATA_CPU_OUT                       : out std_logic_vector(31 downto 0);
        WREN_CPU_IN                         : in  std_logic;                    
        RDEN_CPU_IN                         : in  std_logic;                    
        RDVAL_CPU_OUT                       : out std_logic;                    
                                                
        --reset                             
        DL_JESD204_RST_OUT                  : out std_logic_vector((JESD_TX_LINK_NUM-1) downto 0);
        UL_JESD204_RST_OUT                  : out std_logic_vector((JESD_RX_LINK_NUM-1) downto 0);   
        FB_JESD204_RST_OUT                  : out std_logic_vector((JESD_FB_LINK_NUM-1) downto 0);   
                                            
        --control                           
        RFIC_SYSREF_ON_OUT                  : out  std_logic;
        JESD_IP_TX_SYSREF_ON_OUT            : out  std_logic;
        JESD_IP_RX_SYSREF_ON_OUT            : out  std_logic;
        JESD_IP_FB_SYSREF_ON_OUT            : out  std_logic;
                                            
        -- For IQ Test      
        TEST_MODE_OUT                       : out std_logic;                           
        TEST_SYNC_DL_OUT                    : out std_logic_vector((JESD_TX_LINK_NUM-1) downto 0);          
        TEST_SYNC_FB_OUT                    : out std_logic_vector((JESD_FB_LINK_NUM-1) downto 0);          
        TEST_SYNC_UL_OUT                    : out std_logic_vector((JESD_RX_LINK_NUM-1) downto 0);          
                                            
        TEST_IQ_DL_OUT                      : out std_logic_array2((TX_ANT_NUM-1) downto 0);         
        SINE_NCO_OUT                        : out std_logic_vector(5 downto 0);
                                            
        DL_AI_TEST_OUT                      : out std_logic_vector(15 downto 0);      
        DL_AQ_TEST_OUT                      : out std_logic_vector(15 downto 0);      
                                            
        TEST_IQ_UL_OUT                      : out std_logic_array2((RX_ANT_NUM-1) downto 0);     
        UL_AI_TEST_OUT                      : out std_logic_vector(15 downto 0);      
        UL_AQ_TEST_OUT                      : out std_logic_vector(15 downto 0);      
                                            
        DUMP_SEL_VAL_OUT                    : out std_logic;
        DUMP_ENB_OUT                        : out std_logic;
        DUMP_STRB_SEL_OUT                   : out std_logic;
        DUMP_SEL_OUT                        : out std_logic_vector(7 downto 0);

        DL_TDD_OFFSET_OUT                   : out std_logic_vector(23 downto 0);
        UL_TDD_OFFSET_OUT                   : out std_logic_vector(23 downto 0);
        FB_TDD_OFFSET_OUT                   : out std_logic_vector(23 downto 0);                
                                            
        SIG_SUS_DLFLAG_OUT                  : out std_logic_vector((JESD_TX_LINK_NUM-1) downto 0);
        SIG_SUS_ULFLAG_OUT                  : out std_logic_vector((JESD_RX_LINK_NUM-1) downto 0);
        SIG_SUS_FBFLAG_OUT                  : out std_logic_vector((JESD_FB_LINK_NUM-1) downto 0);        
                                            
        DL_IQ_SWAP_OUT                      : out std_logic_vector((TX_ANT_NUM-1) downto 0);                                                 
        UL_IQ_SWAP_OUT                      : out std_logic_vector((RX_ANT_NUM-1) downto 0);   
        FB_IQ_SWAP_OUT                      : out std_logic_vector((FB_PATH_NUM-1) downto 0)                                                                                                                               
    );
end CPUIF_DCIF;                    

architecture ARC_CPUIF_DCIF of CPUIF_DCIF is

    component REG32_WRITE is
    generic (
        BIT_ENABLE                          : std_logic_vector(31 downto 0) := (others => '1');
        REG_ADDR                            : std_logic_vector(7 downto 0) := (others => '0');
        REG_DATA                            : std_logic_vector(31 downto 0) := (others => '0')
    );
    port (
        RST                                 : in  std_logic;                            -- reset, '1': reset
        CLK                                 : in  std_logic;                            -- clock

        EN                                  : in  std_logic;                            -- Write enable
        ADDR                                : in  std_logic_vector(7 downto 0);         -- Input Address
        DATA_IN                             : in  std_logic_vector(31 downto 0);        -- Data input
        DATA_OUT                            : out std_logic_vector(31 downto 0)         -- Data output
    );
    end component;

    component REG32_LATCH is
    generic (
        BIT_ENABLE                          : std_logic_vector(31 downto 0) := (others => '1');
        REG_ADDR                            : std_logic_vector(7 downto 0) := (others => '0')
    );
    port (
        RST                                 : in  std_logic;
        CLK                                 : in  std_logic;

        CLR_IN                              : in  std_logic;                            -- Clear input, falling edge detection
        ADDR_IN                             : in  std_logic_vector( 7 downto 0);        -- Address input
        DATA_IN                             : in  std_logic_vector(31 downto 0);
        DATA_OUT                            : out std_logic_vector(31 downto 0);
        FLAG_OUT                            : out std_logic_vector(31 downto 0)
    );
    end component;

--DELAY REG : simulation total 71 clk /UL delay 43 clk
constant clock_speed                        : std_logic_vector(7 downto 0):= X"08"; --Clock Speed = 30.72MHz * Parameter (245.76M = 8 * 30.72M)

constant tx_jesd_latency                    : std_logic_vector(23 downto 0):= X"00001c"; --DL delay 28 clk /245.76M
constant rx_jesd_latency                    : std_logic_vector(23 downto 0):= X"00002b"; --UL delay 43 clk /245.76M
constant fb_jesd_latency                    : std_logic_vector(23 downto 0):= X"00002b";

--CPUIF
signal wdata                                : std_logic_vector(31 downto 0);

signal we_buf                               : std_logic;
signal we                                   : std_logic_vector(15 downto 0);
signal oe_buf                               : std_logic;
signal oe                                   : std_logic_vector(15 downto 0);
signal addr_msb                             : std_logic_vector(7 downto 0);
signal addr_lsb                             : std_logic_vector(7 downto 0);
signal read_data                            : std_logic_array32(15 downto 0) := (others => (others => '0'));
signal valid                                : std_logic_vector(3 downto 0);

--Control register
signal i_dcif_test_iq_a                     : std_logic_vector(31 downto 0); 
signal i_dcif_test_ul_iq_a                  : std_logic_vector(31 downto 0);   
signal i_dcif_test_nco                      : std_logic_vector(31 downto 0);
signal i_dcif_tx_iq_swap_ctrl               : std_logic_vector(31 downto 0);
signal i_dcif_tx_jesdip_rst                 : std_logic_vector(31 downto 0);     

signal test_mode_on                         : std_logic_vector(31 downto 0);                   

signal i_dcif_tx_test_sync                  : std_logic_vector(31 downto 0); 
signal i_dcif_test_iq_dl_ctrl               : std_logic_vector(31 downto 0);
signal i_dcif_test_iq_ul_ctrl               : std_logic_vector(31 downto 0);  

signal i_sysref_rfic_on                     : std_logic_vector(31 downto 0);

signal i_dcif_sig_sus_dl_ctrl               : std_logic_vector(31 downto 0);  
signal i_dcif_sig_sus_ul_ctrl               : std_logic_vector(31 downto 0);  
signal i_dcif_sig_sus_fb_ctrl               : std_logic_vector(31 downto 0);  
------------------------------------------------------------------------------------
signal i_dcif_rx_jesdip_rst                 : std_logic_vector(31 downto 0);
signal i_dcif_rx_iq_swap_ctrl               : std_logic_vector(31 downto 0);     
signal i_dcif_rx_test_sync                  : std_logic_vector(31 downto 0);  
------------------------------------------------------------------------------------  
signal i_dcif_fb_jesdip_rst                 : std_logic_vector(31 downto 0);
signal i_dcif_fb_iq_swap_ctrl               : std_logic_vector(31 downto 0);    
signal i_dcif_fb_test_sync                  : std_logic_vector(31 downto 0);  

signal i_sysref_tx_jesd_ip_on               : std_logic_vector(31 downto 0);
signal i_sysref_rx_jesd_ip_on               : std_logic_vector(31 downto 0);
signal i_sysref_fb_jesd_ip_on               : std_logic_vector(31 downto 0);
--dump
signal i_dcif_test_dump_ctrl                : std_logic_vector(31 downto 0);   -- TEST Pattern enable/selection & Dump enable/selection

signal i_dcif_tx_tdd_offset                 : std_logic_vector(31 downto 0);
signal i_dcif_rx_tdd_offset                 : std_logic_vector(31 downto 0);
signal i_dcif_fb_tdd_offset                 : std_logic_vector(31 downto 0);

--pulsed CW
--signal pulsed_cw_enable_s                   : std_logic_vector(31 downto 0);
--signal pulsed_cw_delay_s                    : std_logic_vector(31 downto 0);

begin    

addr_msb <= ADDR_CPU_IN(15 downto 8);
addr_lsb <= ADDR_CPU_IN(7 downto 0);

wdata  <= WDATA_CPU_IN;

--------------------------------------------------------------------------------
-- WE/OE, address decoding
--------------------------------------------------------------------------------
    process (RST_CPU, CLK_CPU)
    begin
        if (RST_CPU = '1') then
            we_buf <= '0';
            oe_buf <= '0';
        elsif (CLK_CPU'event and CLK_CPU = '1') then
            we_buf <= WREN_CPU_IN;
            oe_buf <= RDEN_CPU_IN;
        end if;
    end process;

    -- read/write (short pulse)
    process (RST_CPU, CLK_CPU)
    begin
        if (RST_CPU = '1') then
            we <= (others => '0');
            oe <= (others => '0');
        elsif (CLK_CPU'event and CLK_CPU = '1') then
            for i in 15 downto 0 loop
--            if (addr_msb(7 downto 4) = x"6") and (addr_msb(3 downto 0) = i) then
            if (addr_msb(3 downto 0) = i) then
                if (WREN_CPU_IN = '1') and (we_buf = '0') then        we(i) <= '1';
                else                                                  we(i) <= '0';
                end if;
                if (RDEN_CPU_IN = '1') and (oe_buf = '0') then        oe(i) <= '1';
                else                                                  oe(i) <= '0';
                end if;
            end if;
            end loop;
        end if;
    end process;

    process (RST_CPU, CLK_CPU)
    begin
        if (RST_CPU = '1') then
            valid           <= (others => '0');
            RDVAL_CPU_OUT <= '0';
        elsif (CLK_CPU'event and CLK_CPU = '1') then
            valid           <= valid(2 downto 0) & RDEN_CPU_IN;
            if (valid(3 downto 2) = "01") then
                RDVAL_CPU_OUT <= '1';
            else
                RDVAL_CPU_OUT <= '0';
            end if;
        end if;
    end process;
-------------------------------------------------------------------------------------
------Output countrol signal mapping-------------------------------------------------
-------------------------------------------------------------------------------------   
RFIC_SYSREF_ON_OUT  <=  i_sysref_rfic_on(0);

u_tx_jesd204ip_array : for i in (JESD_TX_LINK_NUM-1) downto 0 generate begin 
    DL_JESD204_RST_OUT(i)               <= i_dcif_tx_jesdip_rst(i);
    TEST_SYNC_DL_OUT(i)                 <= i_dcif_tx_test_sync(i);     
    SIG_SUS_DLFLAG_OUT(i)               <= i_dcif_sig_sus_dl_ctrl(i);      
end generate ;

u_rx_jesd204ip_array : for i in (JESD_RX_LINK_NUM-1) downto 0 generate begin
    UL_JESD204_RST_OUT(i)               <= i_dcif_rx_jesdip_rst(i);
    TEST_SYNC_UL_OUT(i)                 <= i_dcif_rx_test_sync(i);     
    SIG_SUS_ULFLAG_OUT(i)               <= i_dcif_sig_sus_ul_ctrl(i);   
end generate;

u_fb_jesd204ip_array : for i in (JESD_FB_LINK_NUM-1) downto 0 generate begin
    FB_JESD204_RST_OUT(i)               <= i_dcif_fb_jesdip_rst(i);   
    TEST_SYNC_FB_OUT(i)                 <= i_dcif_fb_test_sync(i);   
    SIG_SUS_FBFLAG_OUT(i)               <= i_dcif_sig_sus_fb_ctrl(i);
end generate;       

u_tx_path_assign_array : for i in (TX_ANT_NUM-1) downto 0 generate              
    TEST_IQ_DL_OUT(i)                   <= i_dcif_test_iq_dl_ctrl(i*2+1 downto i*2);   -- 1 Antenna per 2bit  
    DL_IQ_SWAP_OUT(i)                   <= i_dcif_tx_iq_swap_ctrl(i); 
end generate;

u_rx_path_assign_array : for i in (RX_ANT_NUM-1) downto 0 generate              
    TEST_IQ_UL_OUT(i)                   <= i_dcif_test_iq_ul_ctrl(i*2+1 downto i*2);   -- 1 Antenna per 2bit  
    UL_IQ_SWAP_OUT(i)                   <= i_dcif_rx_iq_swap_ctrl(i); 
end generate;

u_fb_path_assign_array : for i in (FB_PATH_NUM-1) downto 0 generate              
    FB_IQ_SWAP_OUT(i)                   <= i_dcif_fb_iq_swap_ctrl(i); 
end generate;      
                          
-- For IQ Test       
JESD_IP_TX_SYSREF_ON_OUT                <= i_sysref_tx_jesd_ip_on(0);
JESD_IP_RX_SYSREF_ON_OUT                <= i_sysref_rx_jesd_ip_on(0);
JESD_IP_FB_SYSREF_ON_OUT                <= i_sysref_fb_jesd_ip_on(0);                                 
                                        
DL_AI_TEST_OUT                          <= i_dcif_test_iq_a(15 downto 0);
DL_AQ_TEST_OUT                          <= i_dcif_test_iq_a(31 downto 16);
SINE_NCO_OUT                            <= i_dcif_test_nco(5 downto 0);
                                        
UL_AI_TEST_OUT                          <= i_dcif_test_ul_iq_a(15 downto 0);
UL_AQ_TEST_OUT                          <= i_dcif_test_ul_iq_a(31 downto 16);

TEST_MODE_OUT                           <= test_mode_on(0);

-- For DUMP                                            
DUMP_SEL_VAL_OUT                        <= we(0);
DUMP_ENB_OUT                            <= i_dcif_test_dump_ctrl(8);
DUMP_STRB_SEL_OUT                       <= i_dcif_test_dump_ctrl(12);
DUMP_SEL_OUT                            <= i_dcif_test_dump_ctrl(7 downto 0);

DL_TDD_OFFSET_OUT                       <= i_dcif_tx_tdd_offset(23 downto 0);  
UL_TDD_OFFSET_OUT                       <= i_dcif_rx_tdd_offset(23 downto 0);  
FB_TDD_OFFSET_OUT                       <= i_dcif_fb_tdd_offset(23 downto 0);  
-------------------------------------------------------------------------------------
------Register write ----------------------------------------------------------------
-------------------------------------------------------------------------------------
REG_WR_0x00C : REG32_WRITE generic map(x"FFFFFFFF", x"0C", x"00000000") port map(RST_CPU, CLK_CPU, we(0), addr_lsb, wdata, i_dcif_test_dump_ctrl);
REG_WR_0x008 : REG32_WRITE generic map(x"FFFFFFFF", x"08", x"00000000") port map(RST_CPU, CLK_CPU, we(0), addr_lsb, wdata, i_dcif_sig_sus_dl_ctrl);
REG_WR_0x009 : REG32_WRITE generic map(x"FFFFFFFF", x"09", x"00000000") port map(RST_CPU, CLK_CPU, we(0), addr_lsb, wdata, i_dcif_sig_sus_ul_ctrl);
REG_WR_0x00A : REG32_WRITE generic map(x"FFFFFFFF", x"0A", x"00000000") port map(RST_CPU, CLK_CPU, we(0), addr_lsb, wdata, i_dcif_sig_sus_fb_ctrl);
REG_WR_0x020 : REG32_WRITE generic map(x"FFFFFFFF", x"20", x"00000000") port map(RST_CPU, CLK_CPU, we(0), addr_lsb, wdata, test_mode_on);

REG_WR_0x200 : REG32_WRITE generic map(x"FFFFFFFF" , x"00", x"00000000") port map(RST_CPU, CLK_CPU, we(2), addr_lsb, wdata, i_sysref_rfic_on);   -- need default value   
REG_WR_0x210 : REG32_WRITE generic map(x"FFFFFFFF" , x"10", x"00000000") port map(RST_CPU, CLK_CPU, we(2), addr_lsb, wdata, i_sysref_tx_jesd_ip_on);   -- need default value
REG_WR_0x211 : REG32_WRITE generic map(x"FFFFFFFF" , x"11", x"00000000") port map(RST_CPU, CLK_CPU, we(2), addr_lsb, wdata, i_sysref_rx_jesd_ip_on);   -- need default value
REG_WR_0x212 : REG32_WRITE generic map(x"FFFFFFFF" , x"12", x"00000000") port map(RST_CPU, CLK_CPU, we(2), addr_lsb, wdata, i_sysref_fb_jesd_ip_on);   -- need default value

REG_WR_0x408 : REG32_WRITE generic map(x"FFFFFFFF", x"08", x"00000000") port map(RST_CPU, CLK_CPU, we(4), addr_lsb, wdata, i_dcif_tx_jesdip_rst);
REG_WR_0x409 : REG32_WRITE generic map(x"FFFFFFFF", x"09", x"00000000") port map(RST_CPU, CLK_CPU, we(4), addr_lsb, wdata, i_dcif_tx_test_sync);
REG_WR_0x40A : REG32_WRITE generic map(x"FFFFFFFF", x"0A", x"00000000") port map(RST_CPU, CLK_CPU, we(4), addr_lsb, wdata, i_dcif_tx_iq_swap_ctrl);
REG_WR_0x420 : REG32_WRITE generic map(x"FFFFFFFF", x"20", x"0000001C") port map(RST_CPU, CLK_CPU, we(4), addr_lsb, wdata, i_dcif_tx_tdd_offset);
                                            
REG_WR_0x4C0 : REG32_WRITE generic map(x"FFFFFFFF", x"C0", x"00000000") port map(RST_CPU, CLK_CPU, we(4), addr_lsb, wdata, i_dcif_test_iq_a);
REG_WR_0x4C3 : REG32_WRITE generic map(x"FFFFFFFF", x"C3", x"00000001") port map(RST_CPU, CLK_CPU, we(4), addr_lsb, wdata, i_dcif_test_nco);
REG_WR_0x4C4 : REG32_WRITE generic map(x"FFFFFFFF", x"C4", x"00000000") port map(RST_CPU, CLK_CPU, we(4), addr_lsb, wdata, i_dcif_test_iq_dl_ctrl);

--REG_WR_0x4D0 : REG32_WRITE generic map(x"00000001", x"D0", x"00000000") port map(RST_CPU, CLK_CPU, we(4), addr_lsb, wdata, pulsed_cw_enable_s);
--REG_WR_0x4D1 : REG32_WRITE generic map(x"FFFFFFFF", x"D1", x"00000000") port map(RST_CPU, CLK_CPU, we(4), addr_lsb, wdata, pulsed_cw_delay_s);

REG_WR_0x508 : REG32_WRITE generic map(x"FFFFFFFF", x"08", x"00000000") port map(RST_CPU, CLK_CPU, we(5), addr_lsb, wdata, i_dcif_rx_jesdip_rst);
REG_WR_0x509 : REG32_WRITE generic map(x"FFFFFFFF", x"09", x"00000000") port map(RST_CPU, CLK_CPU, we(5), addr_lsb, wdata, i_dcif_rx_test_sync);
REG_WR_0x50A : REG32_WRITE generic map(x"FFFFFFFF", x"0A", x"00000000") port map(RST_CPU, CLK_CPU, we(5), addr_lsb, wdata, i_dcif_rx_iq_swap_ctrl);
REG_WR_0x520 : REG32_WRITE generic map(x"FFFFFFFF", x"20", x"0000002B") port map(RST_CPU, CLK_CPU, we(5), addr_lsb, wdata, i_dcif_rx_tdd_offset);

REG_WR_0x5C0 : REG32_WRITE generic map(x"FFFFFFFF", x"C0", x"00000000") port map(RST_CPU, CLK_CPU, we(5), addr_lsb, wdata, i_dcif_test_ul_iq_a);
REG_WR_0x5C4 : REG32_WRITE generic map(x"FFFFFFFF", x"C4", x"00000000") port map(RST_CPU, CLK_CPU, we(5), addr_lsb, wdata, i_dcif_test_iq_ul_ctrl);       
 
REG_WR_0x608 : REG32_WRITE generic map(x"FFFFFFFF", x"08", x"00000000") port map(RST_CPU, CLK_CPU, we(6), addr_lsb, wdata, i_dcif_fb_jesdip_rst);   
REG_WR_0x609 : REG32_WRITE generic map(x"FFFFFFFF", x"09", x"00000000") port map(RST_CPU, CLK_CPU, we(6), addr_lsb, wdata, i_dcif_fb_test_sync);
REG_WR_0x60A : REG32_WRITE generic map(x"FFFFFFFF", x"0A", x"00000000") port map(RST_CPU, CLK_CPU, we(6), addr_lsb, wdata, i_dcif_fb_iq_swap_ctrl); 
REG_WR_0x620 : REG32_WRITE generic map(x"FFFFFFFF", x"20", x"0000002B") port map(RST_CPU, CLK_CPU, we(4), addr_lsb, wdata, i_dcif_fb_tdd_offset);

-------------------------------------------------------------------------------------
------Register read -----------------------------------------------------------------
-------------------------------------------------------------------------------------
READ_DATA_MUX : process (RST_CPU, CLK_CPU)
begin
    if (RST_CPU = '1') then
        RDATA_CPU_OUT <= (others => '0');
    elsif (CLK_CPU'event and CLK_CPU = '1') then
            case addr_msb(3 downto 0) is
            when x"0"   => RDATA_CPU_OUT <= read_data(0);
            when x"1"   => RDATA_CPU_OUT <= read_data(1);
            when x"2"   => RDATA_CPU_OUT <= read_data(2);
            when x"3"   => RDATA_CPU_OUT <= read_data(3);
            when x"4"   => RDATA_CPU_OUT <= read_data(4);
            when x"5"   => RDATA_CPU_OUT <= read_data(5);
            when x"6"   => RDATA_CPU_OUT <= read_data(6);
            when x"7"   => RDATA_CPU_OUT <= read_data(7);
            when x"8"   => RDATA_CPU_OUT <= read_data(8);
            when x"9"   => RDATA_CPU_OUT <= read_data(9);
            when x"A"   => RDATA_CPU_OUT <= read_data(10);
            when x"B"   => RDATA_CPU_OUT <= read_data(11);
            when x"C"   => RDATA_CPU_OUT <= read_data(12);
            when x"D"   => RDATA_CPU_OUT <= read_data(13);
            when x"E"   => RDATA_CPU_OUT <= read_data(14);
            when others =>  RDATA_CPU_OUT <= read_data(15);
            end case;
    end if;
end process;

--0x90XX
RDATA_MODULE: process(RST_CPU, CLK_CPU)
begin
    if (RST_CPU = '1') then
        read_data(0) <= (others => '0');
    elsif (CLK_CPU'event and CLK_CPU = '1') then
        case addr_lsb is
            when x"00"  => read_data(0) <= DCIF_MODULE_DATE;             
            when x"08"  => read_data(0) <= i_dcif_sig_sus_dl_ctrl;            
            when x"09"  => read_data(0) <= i_dcif_sig_sus_ul_ctrl;  
            when x"0A"  => read_data(0) <= i_dcif_sig_sus_fb_ctrl;  
            when x"0C"  => read_data(0) <= i_dcif_test_dump_ctrl;
            when x"20"  => read_data(0) <= test_mode_on;
            when others => read_data(0) <= (others => '0');
        end case;
    end if;
end process;

--0x92XX  /SYSREF
RDATA_SYSREF: process(RST_CPU, CLK_CPU)
begin
    if (RST_CPU = '1') then
        read_data(2) <= (others => '0');
    elsif (CLK_CPU'event and CLK_CPU = '1') then
         case addr_lsb is                 
             when x"00"  => read_data(2) <= i_sysref_rfic_on;
             when x"10"  => read_data(2) <= i_sysref_tx_jesd_ip_on;
             when x"11"  => read_data(2) <= i_sysref_rx_jesd_ip_on;
             when x"12"  => read_data(2) <= i_sysref_fb_jesd_ip_on;             
             when others => read_data(2) <= (others => '0');
         end case;
    end if;
end process;

--0x94XX  /DL
RDATA_DL: process(RST_CPU, CLK_CPU)
begin
    if (RST_CPU = '1') then
        read_data(4) <= (others => '0');
    elsif (CLK_CPU'event and CLK_CPU = '1') then
        case addr_lsb is     
            when x"04"  => read_data(4) <= clock_speed & tx_jesd_latency;        
            when x"08"  => read_data(4) <= i_dcif_tx_jesdip_rst;
            when x"09"  => read_data(4) <= i_dcif_tx_test_sync;            
            when x"0A"  => read_data(4) <= i_dcif_tx_iq_swap_ctrl;
            when x"20"  => read_data(4) <= i_dcif_tx_tdd_offset;               
            when x"C0"  => read_data(4) <= i_dcif_test_iq_a;
            when x"C3"  => read_data(4) <= i_dcif_test_nco;
            when x"C4"  => read_data(4) <= i_dcif_test_iq_dl_ctrl;
--            when x"D0"  => read_data(4) <= pulsed_cw_enable_s;
--            when x"D1"  => read_data(4) <= pulsed_cw_delay_s;
            when others => read_data(4) <= (others => '0');
        end case;
    end if;
end process;

--0x95XX  /UL
RDATA_UL: process(RST_CPU, CLK_CPU)
begin
    if (RST_CPU = '1') then
        read_data(5) <= (others => '0');
    elsif (CLK_CPU'event and CLK_CPU = '1') then
        case addr_lsb is
            when x"04"  => read_data(5) <= clock_speed & rx_jesd_latency;           
            when x"08"  => read_data(5) <= i_dcif_rx_jesdip_rst;
            when x"09"  => read_data(5) <= i_dcif_rx_test_sync;               
            when x"0A"  => read_data(5) <= i_dcif_rx_iq_swap_ctrl; 
            when x"20"  => read_data(5) <= i_dcif_rx_tdd_offset;                          
            when x"C0"  => read_data(5) <= i_dcif_test_ul_iq_a;      
            when x"C4"  => read_data(5) <= i_dcif_test_iq_ul_ctrl;
            when others => read_data(5) <= (others => '0');
        end case;
    end if;
end process;

--0x96XX  /FB
RDATA_FB: process(RST_CPU, CLK_CPU)
begin
    if (RST_CPU = '1') then
        read_data(6) <= (others => '0');
    elsif (CLK_CPU'event and CLK_CPU = '1') then
        case addr_lsb is
            when x"04"  => read_data(6) <= clock_speed & fb_jesd_latency;           
            when x"08"  => read_data(6) <= i_dcif_fb_jesdip_rst;
            when x"09"  => read_data(6) <= i_dcif_fb_test_sync;               
            when x"0A"  => read_data(6) <= i_dcif_fb_iq_swap_ctrl;
            when x"20"  => read_data(6) <= i_dcif_fb_tdd_offset;                
            when others => read_data(6) <= (others => '0');
        end case;
    end if;
end process;

end ARC_CPUIF_DCIF;







