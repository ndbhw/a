----------------------------------------------------------------------------------
-- Company       : Samsung Electronics
-- Engineer      : HJ
--
-- Create Date   : 2023.09.11
-- Design Name   :
-- Module Name   : DCIF_TOP
-- Project Name  :
-- Target Devices: ZU15EG
-- Tool versions : Vivado 2021.1, Xilinx
-- Description   : Data converter interface module for RFIC
--
-- JESD_TX_LINK_NUM : 1
-- JESD_RX_LINK_NUM : 1
-- JESD_FB_LINK_NUM : 1
-- TX_ANT_NUM : 4
-- RX_ANT_NUM : 4
-- JESD_TX_LANE_NUM : 4
-- JESD_RX_LANE_NUM : 2
-- JESD_FB_LANE_NUM : 2
--
-- Revision      : JESD BD version

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
--use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

library UNISIM;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_CONFIG.all;

Library xpm;
use xpm.vcomponents.all;

entity DCIF_TOP is
    PORT(
        -- Clock
        RST_DCIF                                : in  std_logic;
        CLK_153p6                               : in  std_logic;  --Pll clock
        CLK_307p2                               : in  std_logic;  --Pll clock
        REFCLK_SERDES_IN                        : in  std_logic;  --122.88MHz

        --CPU Interface
        RST_CPUIF                               : in  std_logic;                     -- cpuif reset, '1': Reset
        CLK_CPUIF                               : in  std_logic;                     -- cpuif clock, faster than iclk/oclk
        ADDR_CPUIF_IN                           : in  std_logic_vector(15 downto 0); -- cpuif address input, word address.
        WDATA_CPUIF_IN                          : in  std_logic_vector(31 downto 0); -- cpuif data input
        RDATA_CPUIF_OUT                         : out std_logic_vector(31 downto 0); -- cpuif data output
        WREN_CPUIF_IN                           : in  std_logic;                     -- cpuif write enable, '1': active, synchronous with iclk
        RDEN_CPUIF_IN                           : in  std_logic;                     -- cpuif read enable, '1': active.
        RDVAL_CPUIF_OUT                         : out std_logic;                     -- cpuif read data valid, '1': active, synchronous with clk_cpu.
        ------------------------------------------------------------------------------------------
        -- RFIC Interface
        ------------------------------------------------------------------------------------------
        RFIC_SYSREF_OUT                         : out std_logic;                                                          -- RFIC SYSREF OUT

        JESD_SERIAL_TX_OUT_P                    : out std_logic_vector((JESD_TX_LINK_NUM*JESD_TX_LANE_NUM-1) downto 0);   -- JESD204B Serial TX P
        JESD_SERIAL_TX_OUT_N                    : out std_logic_vector((JESD_TX_LINK_NUM*JESD_TX_LANE_NUM-1) downto 0);   -- JESD204B Serial TX N
        JESD_SYNC_TX_IN                         : in  std_logic_vector((JESD_TX_LINK_NUM-1) downto 0);

        JESD_SERIAL_RX_IN_P                     : in  std_logic_vector((JESD_RX_LINK_NUM*JESD_RX_LANE_NUM-1) downto 0);   -- JESD204B Serial RX P
        JESD_SERIAL_RX_IN_N                     : in  std_logic_vector((JESD_RX_LINK_NUM*JESD_RX_LANE_NUM-1) downto 0);   -- JESD204B Serial RX N
        JESD_SYNC_RX_OUT                        : out std_logic_vector((JESD_RX_LINK_NUM-1) downto 0);

        JESD_SERIAL_FB_IN_P                     : in  std_logic_vector((JESD_FB_LINK_NUM*JESD_FB_LANE_NUM-1) downto 0);   -- JESD204B Serial RX P
        JESD_SERIAL_FB_IN_N                     : in  std_logic_vector((JESD_FB_LINK_NUM*JESD_FB_LANE_NUM-1) downto 0);   -- JESD204B Serial RX N
        JESD_SYNC_FB_OUT                        : out std_logic_vector((JESD_FB_LINK_NUM-1) downto 0);
       ------------------------------------------------------------------------------------------
        -- JESD IP AXI Interface
        ------------------------------------------------------------------------------------------
        JESD204B_AXI_ACLK                       : in  std_logic;
        JESD204B_AXI_ARESETN                    : in  std_logic;
        JESD204B_AXI_araddr                     : in  std_logic_vector ( 31 downto 0 );
        JESD204B_AXI_arburst                    : in  std_logic_vector ( 1 downto 0 );
        JESD204B_AXI_arcache                    : in  std_logic_vector ( 3 downto 0 );
        JESD204B_AXI_arlen                      : in  std_logic_vector ( 7 downto 0 );
        JESD204B_AXI_arlock                     : in  std_logic_vector ( 0 to 0 );
        JESD204B_AXI_arprot                     : in  std_logic_vector ( 2 downto 0 );
        JESD204B_AXI_arqos                      : in  std_logic_vector ( 3 downto 0 );
        JESD204B_AXI_arready                    : out std_logic;
        JESD204B_AXI_arregion                   : in  std_logic_vector ( 3 downto 0 );
        JESD204B_AXI_arsize                     : in  std_logic_vector ( 2 downto 0 );
        JESD204B_AXI_arvalid                    : in  std_logic;
        JESD204B_AXI_awaddr                     : in  std_logic_vector ( 31 downto 0 );
        JESD204B_AXI_awburst                    : in  std_logic_vector ( 1 downto 0 );
        JESD204B_AXI_awcache                    : in  std_logic_vector ( 3 downto 0 );
        JESD204B_AXI_awlen                      : in  std_logic_vector ( 7 downto 0 );
        JESD204B_AXI_awlock                     : in  std_logic_vector ( 0 to 0 );
        JESD204B_AXI_awprot                     : in  std_logic_vector ( 2 downto 0 );
        JESD204B_AXI_awqos                      : in  std_logic_vector ( 3 downto 0 );
        JESD204B_AXI_awready                    : out std_logic;
        JESD204B_AXI_awregion                   : in  std_logic_vector ( 3 downto 0 );
        JESD204B_AXI_awsize                     : in  std_logic_vector ( 2 downto 0 );
        JESD204B_AXI_awvalid                    : in  std_logic;
        JESD204B_AXI_bready                     : in  std_logic;
        JESD204B_AXI_bresp                      : out std_logic_vector ( 1 downto 0 );
        JESD204B_AXI_bvalid                     : out std_logic;
        JESD204B_AXI_rdata                      : out std_logic_vector ( 31 downto 0 );
        JESD204B_AXI_rlast                      : out std_logic;
        JESD204B_AXI_rready                     : in  std_logic;
        JESD204B_AXI_rresp                      : out std_logic_vector ( 1 downto 0 );
        JESD204B_AXI_rvalid                     : out std_logic;
        JESD204B_AXI_wdata                      : in  std_logic_vector ( 31 downto 0 );
        JESD204B_AXI_wlast                      : in  std_logic;
        JESD204B_AXI_wready                     : out std_logic;
        JESD204B_AXI_wstrb                      : in  std_logic_vector ( 3 downto 0 );
        JESD204B_AXI_wvalid                     : in  std_logic;
        ------------------------------------------------------------------------------------------
        -- DUMP Interface
        ------------------------------------------------------------------------------------------
        DL_BFN_STRB_IN                          : in  std_logic;
        UL_BFN_STRB_IN                          : in  std_logic;
        FB_BFN_STRB_IN                          : in  std_logic;

        DL_BFN_STRB_OUT                         : out  std_logic;
        UL_BFN_STRB_OUT                         : out  std_logic;
        FB_BFN_STRB_OUT                         : out  std_logic;

        DUMP_BFN_STRB_OUT                       : out std_logic;
        DUMP_DVLD_OUT                           : out std_logic; -- Dump valid
        DUMP_DATA_OUT                           : out std_logic_vector(31 downto 0); -- Dump data
        ------------------------------------------------------------------------------------------
        -- DSP_TOP IF
        ------------------------------------------------------------------------------------------
        DL_I_IN                                 : in  std_logic_array16((TX_ANT_NUM-1) downto 0);
        DL_Q_IN                                 : in  std_logic_array16((TX_ANT_NUM-1) downto 0);

        UL_VALID_OUT                            : out std_logic; --245.76M clk 122.88Msps toggle
        UL_I_OUT                                : out std_logic_array16((RX_ANT_NUM-1) downto 0);
        UL_Q_OUT                                : out std_logic_array16((RX_ANT_NUM-1) downto 0);

        FB_I_OUT                                : out std_logic_array16(FB_PATH_NUM-1 downto 0);
        FB_Q_OUT                                : out std_logic_array16(FB_PATH_NUM-1 downto 0);

        -- Flag gen
        SIG_SUS_DLFLAG_OUT                      : out std_logic_vector((JESD_TX_LINK_NUM-1) downto 0);
        SIG_SUS_ULFLAG_OUT                      : out std_logic_vector((JESD_RX_LINK_NUM-1) downto 0);
        SIG_SUS_FBFLAG_OUT                      : out std_logic_vector((JESD_FB_LINK_NUM-1) downto 0)
    );
end DCIF_TOP;


architecture Behavioral of DCIF_TOP is

    component CPUIF_DCIF
    generic
    (
        DCIF_MODULE_DATE                        : std_logic_vector(31 downto 0):= x"2023_0913"
    );
    port(
        -- CPUIF
        RST_CPU                             : in  std_logic;
        CLK_CPU                             : in  std_logic;
        ADDR_CPU_IN                         : in  std_logic_vector(15 downto 0);
        WDATA_CPU_IN                        : in  std_logic_vector(31 downto 0);
        RDATA_CPU_OUT                       : out std_logic_vector(31 downto 0);
        WREN_CPU_IN                         : in  std_logic;
        RDEN_CPU_IN                         : in  std_logic;
        RDVAL_CPU_OUT                       : out std_logic;

        --reset
        DL_JESD204_RST_OUT                  : out std_logic_vector((JESD_TX_LINK_NUM-1) downto 0);
        UL_JESD204_RST_OUT                  : out std_logic_vector((JESD_RX_LINK_NUM-1) downto 0);
        FB_JESD204_RST_OUT                  : out std_logic_vector((JESD_FB_LINK_NUM-1) downto 0);

        --control
        RFIC_SYSREF_ON_OUT                  : out  std_logic;
        JESD_IP_TX_SYSREF_ON_OUT            : out  std_logic;
        JESD_IP_RX_SYSREF_ON_OUT            : out  std_logic;
        JESD_IP_FB_SYSREF_ON_OUT            : out  std_logic;

        -- For IQ Test
        TEST_MODE_OUT                       : out std_logic;
        TEST_SYNC_DL_OUT                    : out std_logic_vector((JESD_TX_LINK_NUM-1) downto 0);
        TEST_SYNC_FB_OUT                    : out std_logic_vector((JESD_FB_LINK_NUM-1) downto 0);
        TEST_SYNC_UL_OUT                    : out std_logic_vector((JESD_RX_LINK_NUM-1) downto 0);

        TEST_IQ_DL_OUT                      : out std_logic_array2((TX_ANT_NUM-1) downto 0);
        SINE_NCO_OUT                        : out std_logic_vector(5 downto 0);

        DL_AI_TEST_OUT                      : out std_logic_vector(15 downto 0);
        DL_AQ_TEST_OUT                      : out std_logic_vector(15 downto 0);

        TEST_IQ_UL_OUT                      : out std_logic_array2((RX_ANT_NUM-1) downto 0);
        UL_AI_TEST_OUT                      : out std_logic_vector(15 downto 0);
        UL_AQ_TEST_OUT                      : out std_logic_vector(15 downto 0);

        DUMP_SEL_VAL_OUT                    : out std_logic;
        DUMP_ENB_OUT                        : out std_logic;
        DUMP_STRB_SEL_OUT                   : out std_logic;
        DUMP_SEL_OUT                        : out std_logic_vector(7 downto 0);

        DL_TDD_OFFSET_OUT                   : out std_logic_vector(23 downto 0);
        UL_TDD_OFFSET_OUT                   : out std_logic_vector(23 downto 0);
        FB_TDD_OFFSET_OUT                   : out std_logic_vector(23 downto 0);

        SIG_SUS_DLFLAG_OUT                  : out std_logic_vector((JESD_TX_LINK_NUM-1) downto 0);
        SIG_SUS_ULFLAG_OUT                  : out std_logic_vector((JESD_RX_LINK_NUM-1) downto 0);
        SIG_SUS_FBFLAG_OUT                  : out std_logic_vector((JESD_FB_LINK_NUM-1) downto 0);

        DL_IQ_SWAP_OUT                      : out std_logic_vector((TX_ANT_NUM-1) downto 0);
        UL_IQ_SWAP_OUT                      : out std_logic_vector((RX_ANT_NUM-1) downto 0);
        FB_IQ_SWAP_OUT                      : out std_logic_vector((FB_PATH_NUM-1) downto 0)
    );
    end component;

    component JESD204B_TOP_wrapper is
    port (
        AXI_JESD_CLK                        : in STD_LOGIC;
        AXI_JESD_ARESETN                    : in STD_LOGIC;
        AXI_JESD_araddr                     : in STD_LOGIC_VECTOR ( 31 downto 0 );
        AXI_JESD_arburst                    : in STD_LOGIC_VECTOR ( 1 downto 0 );
        AXI_JESD_arcache                    : in STD_LOGIC_VECTOR ( 3 downto 0 );
        AXI_JESD_arlen                      : in STD_LOGIC_VECTOR ( 7 downto 0 );
        AXI_JESD_arlock                     : in STD_LOGIC_VECTOR ( 0 to 0 );
        AXI_JESD_arprot                     : in STD_LOGIC_VECTOR ( 2 downto 0 );
        AXI_JESD_arqos                      : in STD_LOGIC_VECTOR ( 3 downto 0 );
        AXI_JESD_arready                    : out STD_LOGIC;
        AXI_JESD_arregion                   : in STD_LOGIC_VECTOR ( 3 downto 0 );
        AXI_JESD_arsize                     : in STD_LOGIC_VECTOR ( 2 downto 0 );
        AXI_JESD_arvalid                    : in STD_LOGIC;
        AXI_JESD_awaddr                     : in STD_LOGIC_VECTOR ( 31 downto 0 );
        AXI_JESD_awburst                    : in STD_LOGIC_VECTOR ( 1 downto 0 );
        AXI_JESD_awcache                    : in STD_LOGIC_VECTOR ( 3 downto 0 );
        AXI_JESD_awlen                      : in STD_LOGIC_VECTOR ( 7 downto 0 );
        AXI_JESD_awlock                     : in STD_LOGIC_VECTOR ( 0 to 0 );
        AXI_JESD_awprot                     : in STD_LOGIC_VECTOR ( 2 downto 0 );
        AXI_JESD_awqos                      : in STD_LOGIC_VECTOR ( 3 downto 0 );
        AXI_JESD_awready                    : out STD_LOGIC;
        AXI_JESD_awregion                   : in STD_LOGIC_VECTOR ( 3 downto 0 );
        AXI_JESD_awsize                     : in STD_LOGIC_VECTOR ( 2 downto 0 );
        AXI_JESD_awvalid                    : in STD_LOGIC;
        AXI_JESD_bready                     : in STD_LOGIC;
        AXI_JESD_bresp                      : out STD_LOGIC_VECTOR ( 1 downto 0 );
        AXI_JESD_bvalid                     : out STD_LOGIC;
        AXI_JESD_rdata                      : out STD_LOGIC_VECTOR ( 31 downto 0 );
        AXI_JESD_rlast                      : out STD_LOGIC;
        AXI_JESD_rready                     : in STD_LOGIC;
        AXI_JESD_rresp                      : out STD_LOGIC_VECTOR ( 1 downto 0 );
        AXI_JESD_rvalid                     : out STD_LOGIC;
        AXI_JESD_wdata                      : in STD_LOGIC_VECTOR ( 31 downto 0 );
        AXI_JESD_wlast                      : in STD_LOGIC;
        AXI_JESD_wready                     : out STD_LOGIC;
        AXI_JESD_wstrb                      : in STD_LOGIC_VECTOR ( 3 downto 0 );
        AXI_JESD_wvalid                     : in STD_LOGIC;

        I_CORE_CLK                          : in STD_LOGIC;
        I_JESD_REFCLK                       : in STD_LOGIC;

        I_TX_RESET                          : in STD_LOGIC;
        I_TX_SYSREF                         : in STD_LOGIC;
        I_JESD_TX0_GT_N                     : out STD_LOGIC_VECTOR ( 1 downto 0 );
        I_JESD_TX0_GT_P                     : out STD_LOGIC_VECTOR ( 1 downto 0 );
        I_JESD_TX1_GT_N                     : out STD_LOGIC_VECTOR ( 1 downto 0 );
        I_JESD_TX1_GT_P                     : out STD_LOGIC_VECTOR ( 1 downto 0 );
        I_JESD_TXDATA_tdata                 : in STD_LOGIC_VECTOR ( 127 downto 0 );
        I_JESD_TXDATA_tready                : out STD_LOGIC;
        I_JESD_TX_SYNC                      : in STD_LOGIC;

        I_RX_RESET                          : in STD_LOGIC;
        I_RX_SYSREF                         : in STD_LOGIC;
        I_JESD_RX_GT_N                      : in STD_LOGIC_VECTOR ( 1 downto 0 );
        I_JESD_RX_GT_P                      : in STD_LOGIC_VECTOR ( 1 downto 0 );
        O_JESD_RXDATA_tdata                 : out STD_LOGIC_VECTOR ( 63 downto 0 );
        O_JESD_RXDATA_tvalid                : out STD_LOGIC;
        O_JESD_RX_ARESETN                   : out STD_LOGIC;
        O_JESD_RX_SOF                       : out STD_LOGIC_VECTOR ( 3 downto 0 );
        O_JESD_RX_SYNC                      : out STD_LOGIC;

        I_FB_RESET                          : in STD_LOGIC;
        I_FB_SYSREF                         : in STD_LOGIC;
        I_JESD_FB_GT_N                      : in STD_LOGIC_VECTOR ( 1 downto 0 );
        I_JESD_FB_GT_P                      : in STD_LOGIC_VECTOR ( 1 downto 0 );
        O_JESD_FBDATA_tdata                 : out STD_LOGIC_VECTOR ( 63 downto 0 );
        O_JESD_FBDATA_tvalid                : out STD_LOGIC;
        O_JESD_FB_ARESETN                   : out STD_LOGIC;
        O_JESD_FB_SOF                       : out STD_LOGIC_VECTOR ( 3 downto 0 );
        O_JESD_FB_SYNC                      : out STD_LOGIC
        );
    end component;

    component RST_SYNC is
    generic (
        DLY_NUM        : natural := 4;    -- Number of delay.
        MAX_FANOUT_NUM : integer := 200   -- Number of maximum fanout
    );
    port (
        RST_IN  : in  std_logic;          -- Active high asynchronous reset
        CLK     : in  std_logic;          -- clock to be sync'ed to
        RST_OUT : out std_logic           -- "Synchronised" reset signal
    );
    end component;

    component SINE_ROM
      PORT (
        CLKA                                : in  std_logic;
        ADDRA                               : in  std_logic_vector(5 DOWNTO 0);
        DOUTA                               : out std_logic_vector(31 DOWNTO 0)
      );
    end component;

    component JESD_SYNC_DELAY is
    port(
    RESET                                   : in  std_logic;
    CLK                                     : in  std_logic;

    SYNC_DELAY_VALUE                        : in  std_logic_vector(23 downto 0);

    SYNC_IN                                 : in  std_logic;
    SYNC_OUT                                : out std_logic
    );
    end component;
    
    component dcif_fifo_dl_sync is
    port(        
        s_axis_aclk     : in  std_logic;
        s_axis_aresetn  : in  std_logic;
                        
        s_axis_tdata    : in  std_logic_vector(127 downto 0);
        s_axis_tready   : out std_logic;
        s_axis_tvalid   : in  std_logic;
                        
        m_axis_aclk     : in  std_logic;
                        
        m_axis_tdata    : out std_logic_vector(127 downto 0);
        m_axis_tready   : in  std_logic;
        m_axis_tvalid   : out std_logic
    );
    end component;
    
    component dcif_fifo_sync is
    port(        
        s_axis_aclk     : in  std_logic;
        s_axis_aresetn  : in  std_logic;
                        
        s_axis_tdata    : in  std_logic_vector(63 downto 0);
        s_axis_tready   : out std_logic;
        s_axis_tvalid   : in  std_logic;
                        
        m_axis_aclk     : in  std_logic;
                        
        m_axis_tdata    : out std_logic_vector(63 downto 0);
        m_axis_tready   : in  std_logic;
        m_axis_tvalid   : out std_logic
    );
    end component;
    
    signal rstn_dl_iq          : std_logic;
    signal rstn_ul_iq          : std_logic;
    signal rstn_fb_iq          : std_logic;
    
    signal rst_dl_iq_inv       : std_logic;
    signal rst_ul_iq_inv       : std_logic;
    signal rst_fb_iq_inv       : std_logic;
    
    signal dl_we_sw            : std_logic;
    signal tx_write_307p2      : std_logic;
    signal tx_data_307p2       : std_logic_vector(127 downto 0);    
    signal tx_data_153p6       : std_logic_vector(127 downto 0); 
    
    signal rx_jesd_lane_153p6  : std_logic_vector(63 downto 0);
    signal rx_jesd_lane_307p2  : std_logic_vector(63 downto 0);
    
    signal orx_jesd_lane_153p6 : std_logic_vector(63 downto 0);
    signal orx_jesd_lane_307p2 : std_logic_vector(63 downto 0);
    signal orx_jesd_buff       : std_logic_vector(63 downto 0);
    
    signal ul_jesd_lane_307p2  : std_logic_array32((JESD_RX_LINK_NUM*JESD_RX_LANE_NUM-1) downto 0);
    
    signal fb_ai_e_bs_307p2    : std_logic_array16(0 downto 0);
    signal fb_aq_e_bs_307p2    : std_logic_array16(0 downto 0);
    signal fb_ai_o_bs_307p2    : std_logic_array16(0 downto 0);
    signal fb_aq_o_bs_307p2    : std_logic_array16(0 downto 0);
    
    --=================================================================================================================
    -- Signal
    --=================================================================================================================
    --rst
    signal rst_sysref                           : std_logic;
    signal rst_dl_iq                            : std_logic;
    signal rst_ul_iq                            : std_logic;
    signal rst_fb_iq                            : std_logic;
    signal tx_core_rst                          : std_logic_vector((JESD_TX_LINK_NUM-1) downto 0);
    signal rx_core_rst                          : std_logic_vector((JESD_RX_LINK_NUM-1) downto 0);
    signal fb_core_rst                          : std_logic_vector((JESD_FB_LINK_NUM-1) downto 0);

    --sysref
    signal sys_ref_cnt                          : std_logic_vector(7 downto 0);
    signal sysref_s                             : std_logic;
    signal sysref_d                             : std_logic;

    signal rfic_sysref_onoff                    : std_logic;
    signal rfic_sysref_onoff_s                  : std_logic;

    signal tx_ip_sysref_onoff                   : std_logic;
    signal rx_ip_sysref_onoff                   : std_logic;
    signal fb_ip_sysref_onoff                   : std_logic;
    signal tx_ip_sysref_onoff_s                 : std_logic;
    signal rx_ip_sysref_onoff_s                 : std_logic;
    signal fb_ip_sysref_onoff_s                 : std_logic;

    signal jesd_tx_sysref                       : std_logic;
    signal jesd_rx_sysref                       : std_logic;
    signal jesd_fb_sysref                       : std_logic;

    --for test
    signal dl_jesd204_rst_s                     : std_logic_vector((JESD_TX_LINK_NUM-1) downto 0);
    signal ul_jesd204_rst_s                     : std_logic_vector((JESD_RX_LINK_NUM-1) downto 0);
    signal fb_jesd204_rst_s                     : std_logic_vector((JESD_FB_LINK_NUM-1) downto 0);

    signal test_data_sel                        : std_logic_array2((TX_ANT_NUM-1) downto 0);
    signal ul_test_data_sel                     : std_logic_array2((TX_ANT_NUM-1) downto 0);

    signal sin_tbl_addr                         : std_logic_vector(6 downto 0);
    signal sin_tbl_data                         : std_logic_vector(31 downto 0);
    signal sine_nco                             : std_logic_vector(5 downto 0);

    signal dl_ai_fixed                          : std_logic_vector(15 downto 0);
    signal dl_aq_fixed                          : std_logic_vector(15 downto 0);
    signal ul_ai_fixed                          : std_logic_vector(15 downto 0);
    signal ul_aq_fixed                          : std_logic_vector(15 downto 0);
    signal dl_iq_swap                           : std_logic_vector((TX_ANT_NUM-1) downto 0);
    signal ul_iq_swap                           : std_logic_vector((RX_ANT_NUM-1) downto 0);
    signal fb_iq_swap                           : std_logic_vector((FB_PATH_NUM-1) downto 0);
    --signal pulsed_cw_enable_s                   : std_logic;
    --signal pulsed_cw_delay_s                    : std_logic_array4(7 downto 0);
    --signal pulsed_cw_data                       : std_logic_array16(7 downto 0);

    signal test_mode_on                         : std_logic;
    signal test_sync_dl                         : std_logic_vector((JESD_TX_LINK_NUM-1) downto 0);
    signal test_sync_ul                         : std_logic_vector((JESD_RX_LINK_NUM-1) downto 0);
    signal test_sync_fb                         : std_logic_vector((JESD_FB_LINK_NUM-1) downto 0);

    signal i_sig_sus_dlflag                     : std_logic_vector((JESD_TX_LINK_NUM-1) downto 0);
    signal i_sig_sus_fbflag                     : std_logic_vector((JESD_FB_LINK_NUM-1) downto 0);
    signal i_sig_sus_ulflag                     : std_logic_vector((JESD_RX_LINK_NUM-1) downto 0);

    -----------------------------------------------
    --data path signal
    -----------------------------------------------
    --sync
    signal tx_sync_r                            : std_logic_vector((JESD_TX_LINK_NUM-1) downto 0);
    signal tx_sync_i                            : std_logic_vector((JESD_TX_LINK_NUM-1) downto 0);
    signal rx_sync_i                            : std_logic_vector((JESD_RX_LINK_NUM-1) downto 0);
    signal rx_sync_r                            : std_logic_vector((JESD_RX_LINK_NUM-1) downto 0);
    signal fb_sync_i                            : std_logic_vector((JESD_FB_LINK_NUM-1) downto 0);
    signal fb_sync_r                            : std_logic_vector((JESD_FB_LINK_NUM-1) downto 0);

    --signal tx_sof_s                             : std_logic_vector((JESD_TX_LANE_NUM-1) downto 0);
    --signal rx_sof_s                             : std_logic_vector(3 downto 0);
    --signal fb_sof_s                             : std_logic_vector((JESD_FB_LANE_NUM-1) downto 0);

    signal rx_toggle_valid                      : std_logic; -- := '0';
    --dl
    signal dl_ai_test                           : std_logic_array16((TX_ANT_NUM-1) downto 0);
    signal dl_aq_test                           : std_logic_array16((TX_ANT_NUM-1) downto 0);
    signal dl_ai_sw                             : std_logic_array16((TX_ANT_NUM-1) downto 0);
    signal dl_aq_sw                             : std_logic_array16((TX_ANT_NUM-1) downto 0);
    signal dl_ai_bs                             : std_logic_array16((TX_ANT_NUM-1) downto 0);
    signal dl_aq_bs                             : std_logic_array16((TX_ANT_NUM-1) downto 0);
    signal dl_ai_bs_d                           : std_logic_array16((TX_ANT_NUM-1) downto 0);
    signal dl_aq_bs_d                           : std_logic_array16((TX_ANT_NUM-1) downto 0);
    signal dl_ai_align_1                        : std_logic_array16((TX_ANT_NUM-1) downto 0);
    signal dl_aq_align_1                        : std_logic_array16((TX_ANT_NUM-1) downto 0);
    signal dl_ai_align_0                        : std_logic_array16((TX_ANT_NUM-1) downto 0);
    signal dl_aq_align_0                        : std_logic_array16((TX_ANT_NUM-1) downto 0);
    signal dl_jesd_lane                         : std_logic_array32((JESD_TX_LINK_NUM*JESD_TX_LANE_NUM-1) downto 0);

    signal dl_jesd_tdata                        : std_logic_vector((32*JESD_TX_LINK_NUM*JESD_TX_LANE_NUM-1) downto 0);
    signal dl_jesd_tready                       : std_logic_vector((JESD_TX_LINK_NUM-1) downto 0);

   --ul
    signal ul_ai_test                           : std_logic_array16((RX_ANT_NUM-1) downto 0);
    signal ul_aq_test                           : std_logic_array16((RX_ANT_NUM-1) downto 0);
    signal ul_ai_bs                             : std_logic_array16((RX_ANT_NUM-1) downto 0);
    signal ul_aq_bs                             : std_logic_array16((RX_ANT_NUM-1) downto 0);
    signal ul_ai_sw                             : std_logic_array16((RX_ANT_NUM-1) downto 0);
    signal ul_aq_sw                             : std_logic_array16((RX_ANT_NUM-1) downto 0);
    signal ul_jesd_lane                         : std_logic_array32((JESD_RX_LINK_NUM*JESD_RX_LANE_NUM-1) downto 0);

    signal ul_jesd_tdata                        : std_logic_vector((32*JESD_RX_LINK_NUM*JESD_RX_LANE_NUM-1) downto 0):=(others => '0');
    signal ul_jesd_tvalid                       : std_logic_vector((JESD_RX_LINK_NUM-1) downto 0);

    --fb
    signal fb_jesd_toggle                       : std_logic;
    signal fb_jesd_toggle_d1                    : std_logic;
    signal fb_jesd_toggle_d2                    : std_logic;
    signal fb_jesd_toggle_d3                    : std_logic;
    signal data_start_fb                        : std_logic;

    signal fb_ai_e_sw                           : std_logic_array16((FB_PATH_NUM-1) downto 0);
    signal fb_aq_e_sw                           : std_logic_array16((FB_PATH_NUM-1) downto 0);
    signal fb_ai_o_sw                           : std_logic_array16((FB_PATH_NUM-1) downto 0);
    signal fb_aq_o_sw                           : std_logic_array16((FB_PATH_NUM-1) downto 0);

    signal fb_ai_e_bs                           : std_logic_array16((FB_PATH_NUM-1) downto 0);
    signal fb_aq_e_bs                           : std_logic_array16((FB_PATH_NUM-1) downto 0);
    signal fb_ai_o_bs                           : std_logic_array16((FB_PATH_NUM-1) downto 0);
    signal fb_aq_o_bs                           : std_logic_array16((FB_PATH_NUM-1) downto 0);

    signal fb_ai_out                            : std_logic_array16((FB_PATH_NUM-1) downto 0);
    signal fb_aq_out                            : std_logic_array16((FB_PATH_NUM-1) downto 0);

    signal fb_jesd_lane                         : std_logic_array32((JESD_FB_LINK_NUM*JESD_FB_LANE_NUM-1) downto 0);

    signal fb_jesd_tdata                        : std_logic_vector((32*JESD_FB_LINK_NUM*JESD_FB_LANE_NUM-1) downto 0):=(others => '0');
    signal fb_jesd_tvalid                       : std_logic_vector((JESD_FB_LINK_NUM-1) downto 0);

    --dump
    signal rst_dump                             : std_logic;

    signal dump_sel_val                         : std_logic;    -- need to detect fal
    signal dump_enb                             : std_logic;
    signal dump_strb_sel                        : std_logic;
    signal dump_sel                             : std_logic_vector(7 downto 0);

    signal dumpval_dl                           : std_logic;
    signal dumpval_ul                           : std_logic;
    signal dumpval_fb                           : std_logic;

    signal dumpsel_dl                           : std_logic_vector(7 downto 0);
    signal dumpsel_ul                           : std_logic_vector(7 downto 0);
    signal dumpsel_fb                           : std_logic_vector(7 downto 0);

    signal dumpval_dl_ff                        : std_logic_vector(2 downto 0);
    signal dumpval_ul_ff                        : std_logic_vector(2 downto 0);
    signal dumpval_fb_ff                        : std_logic_vector(2 downto 0);

    signal dumpsel_cdc                          : std_logic_vector(7 downto 0);
    signal dumpsel_val_d                        : std_logic_vector(2 downto 0);

    signal dump_bfn_strb                        : std_logic;
    signal dump_val_jesdblk                     : std_logic;
    signal dump_data_jesdblk                    : std_logic_vector(31 downto 0);

    signal dump_bfn_strb_dl                     : std_logic;
    signal dump_data_dcif_dl                    : std_logic_vector(31 downto 0);

    signal dump_bfn_strb_ul                     : std_logic;
    signal dump_data_dcif_ul                    : std_logic_vector(31 downto 0);

    signal dump_bfn_strb_fb                     : std_logic;
    signal dump_data_dcif_fb                    : std_logic_vector(31 downto 0);

    signal dl_bfn_strb_sw                       : std_logic;
    signal dl_bfn_strb_test                     : std_logic;
    signal dl_bfn_strb_align                    : std_logic;

    signal ul_bfn_strb_jesd                     : std_logic:='0';
    signal ul_bfn_strb_lane                     : std_logic;
    signal ul_bfn_strb_sw                       : std_logic;
    signal ul_bfn_strb_test                     : std_logic;

    signal fb_bfn_strb_jesd                     : std_logic:='0';
    signal fb_bfn_strb_lane                     : std_logic;
    signal fb_bfn_strb_sw                       : std_logic;
    signal fb_bfn_strb_o                        : std_logic;

    signal dl_tdd_offset                        : std_logic_vector(23 downto 0);
    signal ul_tdd_offset                        : std_logic_vector(23 downto 0);
    signal fb_tdd_offset                        : std_logic_vector(23 downto 0);

--attribute MARK_DEBUG : string;
--attribute MARK_DEBUG of rfic_sysref_onoff: signal is "TRUE";
--attribute MARK_DEBUG : string;
--attribute MARK_DEBUG of FB_BFN_STRB_OUT       : signal is "TRUE";
--attribute MARK_DEBUG of fb_bfn_strb_sw        : signal is "TRUE";
--attribute MARK_DEBUG of fb_bfn_strb_jesd      : signal is "TRUE";
--attribute MARK_DEBUG of FB_BFN_STRB_IN        : signal is "TRUE";

begin
    --=================================================================================================================
    -- Reset/Clock (Traffic)
    --=================================================================================================================
    u_rst_sysref_sync                           : RST_SYNC generic map(4, 200) port map(RST_DCIF,   CLK_307p2,  rst_sysref);
    u_rst_dl_iq_sync                            : RST_SYNC generic map(4, 200) port map(RST_DCIF,   CLK_307p2,  rst_dl_iq);
    u_rst_ul_iq_sync                            : RST_SYNC generic map(4, 200) port map(RST_DCIF,   CLK_307p2,  rst_ul_iq);
    u_rst_fb_iq_sync                            : RST_SYNC generic map(4, 200) port map(RST_DCIF,   CLK_307p2,  rst_fb_iq);
    u_rst_dump_sync                             : RST_SYNC generic map(4, 200) port map(RST_DCIF,   CLK_307p2,  rst_dump);

    JESD_TX_LINK_ASSIGN_0 : for I in (JESD_TX_LINK_NUM-1) downto 0 generate begin
        tx_core_rst       (I)  <= rst_dl_iq or dl_jesd204_rst_s(I);
    end generate;

    JESD_RX_LINK_ASSIGN_0 : for I in (JESD_RX_LINK_NUM-1) downto 0 generate begin
        rx_core_rst       (I)  <= rst_ul_iq or ul_jesd204_rst_s(I);
    end generate;

    JESD_FB_LINK_ASSIGN_0 : for I in (JESD_FB_LINK_NUM-1) downto 0 generate begin
        fb_core_rst       (I)  <= rst_fb_iq or fb_jesd204_rst_s(I);
    end generate;

    --=================================================================================================================
    -- TDD/Strobe/BCF_ENB Delay
    --=================================================================================================================
    u_DL_STRB_DLY_GEN : JESD_SYNC_DELAY port map(rst_dl_iq, CLK_307p2, dl_tdd_offset, dl_bfn_strb_align , DL_BFN_STRB_OUT);
    u_UL_STRB_DLY_GEN : JESD_SYNC_DELAY port map(rst_ul_iq, CLK_307p2, ul_tdd_offset, UL_BFN_STRB_IN , ul_bfn_strb_jesd);
    u_FB_STRB_DLY_GEN : JESD_SYNC_DELAY port map(rst_fb_iq, CLK_307p2, fb_tdd_offset, FB_BFN_STRB_IN , fb_bfn_strb_jesd);
    --=================================================================================================================
    -- SYSREF control
    --=================================================================================================================
    SYSREF_GEN : process(rst_sysref, CLK_307p2)
    begin
        if (rst_sysref = '1') then
            sys_ref_cnt  <= (others => '0');
            sysref_s     <= '0';
        elsif (CLK_307p2'event and CLK_307p2 = '1') then
            sys_ref_cnt  <= sys_ref_cnt + 1;
            sysref_d     <= sysref_s;
            if(sys_ref_cnt(7) = '1') then              -- sys_ref_cnt 16~31 high(960KHz)
                sysref_s <= '1';
            else
                sysref_s <= '0';
            end if;
        end if;
    end process;

    SYSREF_ONOFF_FALLING_EDGE_DETECTION : process(rst_sysref, CLK_307p2)
    begin
        if (rst_sysref = '1') then
            rfic_sysref_onoff_s      <= '0';
            tx_ip_sysref_onoff_s     <= '0';
            rx_ip_sysref_onoff_s     <= '0';
            fb_ip_sysref_onoff_s     <= '0';
        elsif (CLK_307p2'event and CLK_307p2 = '1') then
            RFIC_SYSREF_OUT  <= rfic_sysref_onoff_s  and sysref_d;
            jesd_tx_sysref   <= tx_ip_sysref_onoff_s and sysref_d;
            jesd_rx_sysref   <= rx_ip_sysref_onoff_s and sysref_d;
            jesd_fb_sysref   <= fb_ip_sysref_onoff_s and sysref_d;
            if (sysref_s = '0' and sysref_d = '1') then
                rfic_sysref_onoff_s  <= rfic_sysref_onoff;
                tx_ip_sysref_onoff_s <= tx_ip_sysref_onoff;
                rx_ip_sysref_onoff_s <= rx_ip_sysref_onoff;
                fb_ip_sysref_onoff_s <= fb_ip_sysref_onoff;
            end if;
        end if;
    end process;

    --=================================================================================================================
    -- SYNC control
    --=================================================================================================================
    u_tx_sync_n_array : for i in (JESD_TX_LINK_NUM-1) downto 0 generate
        -- TX SYNC
        TXSYNC_PROC: process(rst_dl_iq, CLK_307p2)   --sync reset
        begin
            if (rst_dl_iq = '1') then
                tx_sync_r(i) <= '0';
            elsif (CLK_307p2'event and CLK_307p2 = '1') then
                tx_sync_r(i) <= JESD_SYNC_TX_IN(i);
            end if;
        end process;

        tx_sync_i(i)         <= test_sync_dl(i) when (test_mode_on = '1') else tx_sync_r(i); -- for test
    end generate ;

    u_rx_sync_n_array : for i in (JESD_RX_LINK_NUM-1) downto 0 generate
        -- RX SYNC
        rx_sync_r(i)          <= test_sync_ul(i) when (test_mode_on = '1') else rx_sync_i(i);

        RXSYNC_PROC: process(rst_ul_iq, CLK_307p2)
        begin
            if (rst_ul_iq = '1') then
                JESD_SYNC_RX_OUT(i) <= '0';
            elsif (CLK_307p2'event and CLK_307p2 = '1') then
                JESD_SYNC_RX_OUT(i) <= rx_sync_r(i);
            end if;
        end process;
    end generate ;

    u_fb_sync_n_array : for i in (JESD_FB_LINK_NUM-1) downto 0 generate
        -- FB SYNC
        fb_sync_r(i)         <= test_sync_fb(i) when (test_mode_on = '1') else fb_sync_i(i);

        FBSYNC_PROC: process(rst_fb_iq, CLK_307p2)
        begin
            if (rst_fb_iq = '1') then
                JESD_SYNC_FB_OUT(i) <= '0';
            elsif (CLK_307p2'event and CLK_307p2 = '1') then
                JESD_SYNC_FB_OUT(i) <= fb_sync_r(i);
            end if;
        end process;
    end generate ;

    --=================================================================================================================
    -- sine wave test patten
    --=================================================================================================================
    SINE_WAVE_ADDR : process(rst_dl_iq,CLK_307p2) begin  --CLK_307p2
       if(rst_dl_iq = '1') then
          sin_tbl_addr <= (others => '0');
       elsif(CLK_307p2'event and CLK_307p2='1') then
           if(sin_tbl_addr = 47) then   --0~47 * 2 clk
              sin_tbl_addr <= (others => '0');
           else
              sin_tbl_addr <= sin_tbl_addr + ('0' & sine_nco);
           end if;
       end if;
    end process;

        U_sin_tbl       : sine_rom port map ( CLK_307p2, sin_tbl_addr(5 downto 0), sin_tbl_data );
    --=================================================================================================================
    -- TX Data control
    --=================================================================================================================
    rst_dl_iq_inv <= not rst_dl_iq;
    
    rstn_dl_iq_inst : xpm_cdc_async_rst
    generic map (
        DEST_SYNC_FF => 4,    
        INIT_SYNC_FF => 0,    
        RST_ACTIVE_HIGH => 0 
    )
    port map (
        dest_arst => rstn_dl_iq, 
        dest_clk => CLK_307p2,   
        src_arst => rst_dl_iq_inv   
    );
    
    u_dl_path_array : for i in (TX_ANT_NUM-1) downto 0 generate
        DL_TEST_SEL: process(rst_dl_iq, CLK_307p2)
        begin
            if rst_dl_iq = '1' then
                dl_ai_test(i) <= (others => '0');
                dl_aq_test(i) <= (others => '0');
            elsif CLK_307p2'event and CLK_307p2 = '1' then
                if (test_data_sel(i) = "01") then
                    dl_ai_test(i) <= dl_ai_fixed;
                    dl_aq_test(i) <= dl_aq_fixed;
                elsif(test_data_sel(i) = "10") then
                    dl_ai_test(i) <= sin_tbl_data(14) & sin_tbl_data(14 downto  0);
                    dl_aq_test(i) <= sin_tbl_data(30) & sin_tbl_data(30 downto 16);
                else
                    dl_ai_test(i) <= DL_I_IN(i);
                    dl_aq_test(i) <= DL_Q_IN(i);
                end if;
            end if;
        end process;

        DL_SWAP : process(rst_dl_iq, CLK_307p2)
        begin
            if (rst_dl_iq = '1') then
                dl_ai_sw(i) <= (others => '0');
                dl_aq_sw(i) <= (others => '0');
            elsif (CLK_307p2'event and CLK_307p2 = '1') then
                if (dl_iq_swap(i) = '0') then
                    dl_ai_sw(i) <= dl_ai_test(i);
                    dl_aq_sw(i) <= dl_aq_test(i);
                else
                    dl_aq_sw(i) <= dl_ai_test(i);
                    dl_ai_sw(i) <= dl_aq_test(i);
                end if;
                dl_ai_bs_d(i)  <= dl_ai_bs(i);
                dl_aq_bs_d(i)  <= dl_aq_bs(i);  
            end if;
        end process;
        
        -- Low and High Byte Swap for JESD204B
        dl_ai_bs(i)(15 downto 8) <= dl_ai_sw(i)(7 downto 0);    dl_ai_bs(i)(7 downto 0) <= dl_ai_sw(i)(15 downto 8);
        dl_aq_bs(i)(15 downto 8) <= dl_aq_sw(i)(7 downto 0);    dl_aq_bs(i)(7 downto 0) <= dl_aq_sw(i)(15 downto 8);
    end generate;
    
    DL_BUFF : process(rst_dl_iq, CLK_307p2)
    begin
        if (rst_dl_iq = '1') then
            dl_we_sw       <= '0';
            tx_write_307p2 <= '0';
            tx_data_307p2  <= (others => '0');
        elsif (CLK_307p2'event and CLK_307p2 = '1') then
            dl_we_sw <= not dl_we_sw;
            tx_write_307p2 <= dl_we_sw;
            tx_data_307p2  <= dl_ai_bs(1) & dl_aq_bs(1) & dl_ai_bs_d(1) & dl_aq_bs_d(1)&
                              dl_ai_bs(0) & dl_aq_bs(0) & dl_ai_bs_d(0) & dl_aq_bs_d(0);
        end if;
    end process;
    
    dcif_fifo_sync_tx_inst : dcif_fifo_dl_sync
    port map(        
        s_axis_aclk     => CLK_307p2,
        s_axis_aresetn  => rstn_dl_iq,
                       
        s_axis_tdata    => tx_data_307p2,
        s_axis_tready   => open,
        s_axis_tvalid   => tx_write_307p2,
                        
        m_axis_aclk     => CLK_153p6,
                       
        m_axis_tdata    => tx_data_153p6,
        m_axis_tready   => '1',
        m_axis_tvalid   => open
    );

    dl_ai_align_0(1)   <= tx_data_153p6( 95 downto  80);
    dl_aq_align_0(1)   <= tx_data_153p6( 79 downto  64);
    dl_ai_align_1(1)   <= tx_data_153p6(127 downto 112);
    dl_aq_align_1(1)   <= tx_data_153p6(111 downto  96);
    
    dl_ai_align_0(0)   <= tx_data_153p6( 31 downto  16);
    dl_aq_align_0(0)   <= tx_data_153p6( 15 downto   0);
    dl_ai_align_1(0)   <= tx_data_153p6( 63 downto  48);
    dl_aq_align_1(0)   <= tx_data_153p6( 47 downto  32);
    
    DL_LANE_MAPPING : process(rst_dl_iq, CLK_153p6)
    begin
        if (CLK_153p6'event and CLK_153p6 = '1') then
            dl_jesd_lane(0) <= dl_aq_align_1(0) & dl_aq_align_0(0);
            dl_jesd_lane(1) <= dl_ai_align_1(0) & dl_ai_align_0(0);
            dl_jesd_lane(2) <= dl_aq_align_1(1) & dl_aq_align_0(1);
            dl_jesd_lane(3) <= dl_ai_align_1(1) & dl_ai_align_0(1);
        end if;
    end process;

    dl_jesd_tdata <=  dl_jesd_lane(3) & dl_jesd_lane(2) & dl_jesd_lane(1) & dl_jesd_lane(0);

    DL_DUMP_STRB : process(rst_dl_iq, CLK_307p2)
    begin
        if(CLK_307p2'event and CLK_307p2= '1') then
            dl_bfn_strb_test  <= DL_BFN_STRB_IN;
            dl_bfn_strb_sw    <= dl_bfn_strb_test;
            dl_bfn_strb_align <= dl_bfn_strb_sw;
       end if;
    end process;

    --=================================================================================================================
    -- RX Data control
    --=================================================================================================================
    
    rst_ul_iq_inv <= not rst_ul_iq;
    
    rstn_ul_iq_inst : xpm_cdc_async_rst
    generic map (
        DEST_SYNC_FF => 4,    
        INIT_SYNC_FF => 0,    
        RST_ACTIVE_HIGH => 0 
    )
    port map (
        dest_arst => rstn_ul_iq, 
        dest_clk => CLK_153p6,   
        src_arst => rst_ul_iq_inv   
    );
    
    u_ul_link_map_array: for i in (JESD_RX_LINK_NUM-1) downto 0 generate
    u_ul_lane_map_array : for j in (JESD_RX_LANE_NUM-1) downto 0 generate

        UL_LANE_MAPPING : process(rst_ul_iq, CLK_153p6)
        begin
            if (rst_ul_iq = '1') then
                ul_jesd_lane(i*JESD_RX_LANE_NUM+j) <= (others => '0');
            elsif (CLK_153p6'event and CLK_153p6 = '1') then
                ul_jesd_lane(i*JESD_RX_LANE_NUM+j) <= ul_jesd_tdata(((32*(i*JESD_RX_LANE_NUM+(j+1)))-1) downto (32*(i*JESD_RX_LANE_NUM+j)));
            end if;
        end process;
        
    end generate;  -- end of ul lane array
    end generate;  -- end of ul link array
        
    rx_jesd_lane_153p6 <= ul_jesd_lane(1) & ul_jesd_lane(0);
    
    dcif_fifo_sync_rx_inst : dcif_fifo_sync
    port map(        
        s_axis_aclk     => CLK_153p6,
        s_axis_aresetn  => rstn_ul_iq,
                        
        s_axis_tdata    => rx_jesd_lane_153p6,
        s_axis_tready   => open,
        s_axis_tvalid   => '1',
                        
        m_axis_aclk     => CLK_307p2,
                        
        m_axis_tdata    => rx_jesd_lane_307p2,
        m_axis_tready   => rx_toggle_valid,
        m_axis_tvalid   => open
    );
    
    ul_jesd_lane_307p2(1) <= rx_jesd_lane_307p2(63 downto 32);
    ul_jesd_lane_307p2(0) <= rx_jesd_lane_307p2(31 downto  0);
        
    u_ul_link_sync_array: for i in (JESD_RX_LINK_NUM-1) downto 0 generate
    u_ul_lane_sync_array : for j in (JESD_RX_LANE_NUM-1) downto 0 generate
        UL_SWAP : process(rst_ul_iq, CLK_307p2)
        begin
            if(CLK_307p2'event and CLK_307p2= '1') then
                if (ul_iq_swap(i*JESD_RX_LANE_NUM+j) = '0') then  -- IQ swap
                    ul_ai_sw(i*JESD_RX_LANE_NUM+j) <= ul_jesd_lane_307p2(i*JESD_RX_LANE_NUM+j)(31 downto 16); -- I <= I sample
                    ul_aq_sw(i*JESD_RX_LANE_NUM+j) <= ul_jesd_lane_307p2(i*JESD_RX_LANE_NUM+j)(15 downto 0);  -- Q <= Q sample
                else
                    ul_aq_sw(i*JESD_RX_LANE_NUM+j) <= ul_jesd_lane_307p2(i*JESD_RX_LANE_NUM+j)(31 downto 16); -- Q <= I sample
                    ul_ai_sw(i*JESD_RX_LANE_NUM+j) <= ul_jesd_lane_307p2(i*JESD_RX_LANE_NUM+j)(15 downto 0);  -- I <= Q sample
                end if;
            end if;
        end process;

        -- Low and High Byte Swap
        ul_ai_bs(i*JESD_RX_LANE_NUM+j)(15 downto 8) <= ul_ai_sw(i*JESD_RX_LANE_NUM+j)( 7 downto 0);       --I
        ul_ai_bs(i*JESD_RX_LANE_NUM+j)( 7 downto 0) <= ul_ai_sw(i*JESD_RX_LANE_NUM+j)(15 downto 8);

        ul_aq_bs(i*JESD_RX_LANE_NUM+j)(15 downto 8) <= ul_aq_sw(i*JESD_RX_LANE_NUM+j)( 7 downto 0);        --Q
        ul_aq_bs(i*JESD_RX_LANE_NUM+j)( 7 downto 0) <= ul_aq_sw(i*JESD_RX_LANE_NUM+j)(15 downto 8);

    end generate;  -- end of ul lane array
    end generate;  -- end of ul link array

    u_ul_ant_array: for i in (RX_ANT_NUM-1) downto 0 generate
        UL_TEST_SEL : process(CLK_307p2)
        begin
            if (CLK_307p2'event and CLK_307p2= '1') then
                if rx_toggle_valid = '0' then
                    if (ul_test_data_sel(i) = "01") then
                        ul_ai_test(i)   <= ul_ai_fixed(15 downto 0);
                        ul_aq_test(i)   <= ul_aq_fixed(15 downto 0);
                    elsif(ul_test_data_sel(i) = "10") then
                        ul_ai_test(i)   <= sin_tbl_data(14) & sin_tbl_data(14 downto  0);
                        ul_aq_test(i)   <= sin_tbl_data(30) & sin_tbl_data(30 downto 16);
                    elsif(ul_test_data_sel(i) = "11") then
                        ul_ai_test(i)   <= (others => '0');
                        ul_aq_test(i)   <= (others => '0');
                    else
                        ul_ai_test(i)   <= ul_ai_bs(i);
                        ul_aq_test(i)   <= ul_aq_bs(i);
                    end if;
                else
                    ul_ai_test(i) <= ul_ai_test(i);
                    ul_aq_test(i) <= ul_aq_test(i);
                end if;
                    
               UL_I_OUT(i) <= ul_ai_test(i);
               UL_Q_OUT(i) <= ul_aq_test(i);
           end if;
        end process;

    end generate; -- end of ul ant array

    RX_VALID : process(CLK_307p2) --Needed for 245.76MHz 122.88 Msps (1/2 data)
    begin
        if (CLK_307p2'event and CLK_307p2= '1') then
            if ul_jesd_tvalid(0) = '0' then --only use lane 0 valid(IF LMFC is same)
                rx_toggle_valid <= '0';
            else
                rx_toggle_valid <= not rx_toggle_valid;
            end if;
            UL_VALID_OUT <= rx_toggle_valid;
       end if;
    end process;

    UL_DUMP_STRB : process(rst_ul_iq, CLK_307p2)
    begin
        if(CLK_307p2'event and CLK_307p2= '1') then
            ul_bfn_strb_lane <= ul_bfn_strb_jesd;
            ul_bfn_strb_sw   <= ul_bfn_strb_lane;
            ul_bfn_strb_test <= ul_bfn_strb_sw;
       end if;
    end process;

    UL_BFN_STRB_OUT <= ul_bfn_strb_test;

    --=================================================================================================================
    -- FB  Data control
    --=================================================================================================================
    rst_fb_iq_inv <= not rst_fb_iq;
    
    rstn_fb_iq_inst : xpm_cdc_async_rst
    generic map (
        DEST_SYNC_FF => 4,    
        INIT_SYNC_FF => 0,    
        RST_ACTIVE_HIGH => 0 
    )
    port map (
        dest_arst => rstn_fb_iq, 
        dest_clk => CLK_153p6,   
        src_arst => rst_fb_iq_inv   
    );
    
    
    u_fb_link_array : for i in (JESD_FB_LINK_NUM-1) downto 0 generate
    u_fb_lane_array : for j in (JESD_FB_LANE_NUM-1) downto 0 generate
        FB_LANE_MAPPING : process(rst_fb_iq, CLK_153p6)
        begin
            if rst_fb_iq = '1' then
                fb_jesd_lane(i*JESD_FB_LANE_NUM+j) <= (others => '0');
            elsif CLK_153p6'event and CLK_153p6 = '1' then
                fb_jesd_lane(i*JESD_FB_LANE_NUM+j) <= fb_jesd_tdata(((32*(i*JESD_FB_LANE_NUM+(j+1)))-1) downto (32*(i*JESD_FB_LANE_NUM+j)));
            end if;
        end process;
    end generate ; -- end of jesd lane array

        FB_SWAP: process(CLK_153p6)
        begin
            if (CLK_153p6'event and CLK_153p6= '1') then
                if (fb_iq_swap(i) = '0') then  -- IQ swap
                    fb_ai_o_sw(i) <= fb_jesd_lane(i*JESD_FB_LANE_NUM+0)(31 downto 16);  -- h16b : I sample1 / lsb first
                    fb_ai_e_sw(i) <= fb_jesd_lane(i*JESD_FB_LANE_NUM+0)(15 downto 0);   -- l16b : I sample0
                    fb_aq_o_sw(i) <= fb_jesd_lane(i*JESD_FB_LANE_NUM+1)(31 downto 16);  -- h16b : Q sample1
                    fb_aq_e_sw(i) <= fb_jesd_lane(i*JESD_FB_LANE_NUM+1)(15 downto 0);   -- l16b : Q sample0
                else
                   fb_ai_o_sw(i) <= fb_jesd_lane(i*JESD_FB_LANE_NUM+1)(31 downto 16);   --I <= Q
                   fb_ai_e_sw(i) <= fb_jesd_lane(i*JESD_FB_LANE_NUM+1)(15 downto 0);
                   fb_aq_o_sw(i) <= fb_jesd_lane(i*JESD_FB_LANE_NUM+0)(31 downto 16);   --Q <= I
                   fb_aq_e_sw(i) <= fb_jesd_lane(i*JESD_FB_LANE_NUM+0)(15 downto 0);
                end if;
            end if;
        end process;
    end generate; -- end of jesd link array

    FB_DATA_START: process(rst_fb_iq, CLK_307p2)
    begin
        if (rst_fb_iq = '1') then
            data_start_fb <= '0';
        elsif CLK_307p2'event and CLK_307p2 = '1' then
            data_start_fb <= (not data_start_fb);
        end if;
    end process;

    u_fb_path_array : for i in (FB_PATH_NUM-1) downto 0 generate --path 0 only
        -- Low and High Byte Swap
        fb_aq_e_bs(i)(15 downto 8) <= fb_aq_e_sw(i)( 7 downto 0);
        fb_aq_e_bs(i)( 7 downto 0) <= fb_aq_e_sw(i)(15 downto 8);
        fb_aq_o_bs(i)(15 downto 8) <= fb_aq_o_sw(i)( 7 downto 0);
        fb_aq_o_bs(i)( 7 downto 0) <= fb_aq_o_sw(i)(15 downto 8);

        fb_ai_e_bs(i)(15 downto 8) <= fb_ai_e_sw(i)( 7 downto 0);
        fb_ai_e_bs(i)( 7 downto 0) <= fb_ai_e_sw(i)(15 downto 8);
        fb_ai_o_bs(i)(15 downto 8) <= fb_ai_o_sw(i)( 7 downto 0);
        fb_ai_o_bs(i)( 7 downto 0) <= fb_ai_o_sw(i)(15 downto 8);
    end generate ; -- end of jesd path array
    
    
        orx_jesd_lane_153p6 <= fb_aq_e_bs(0) & fb_aq_o_bs(0) & fb_ai_e_bs(0) & fb_ai_o_bs(0);
        

        
        dcif_fifo_sync_orx_inst : dcif_fifo_sync
        port map(        
            s_axis_aclk     => CLK_153p6,
            s_axis_aresetn  => rstn_fb_iq,
                           
            s_axis_tdata    => orx_jesd_lane_153p6,
            s_axis_tready   => open,
            s_axis_tvalid   => '1',
                            
            m_axis_aclk     => CLK_307p2,
                           
            m_axis_tdata    => orx_jesd_lane_307p2,
            m_axis_tready   => data_start_fb,
            m_axis_tvalid   => open
        );
        
        FB_buffer: process(CLK_307p2)
        begin
            if (CLK_307p2'event and CLK_307p2= '1') then
                if (data_start_fb = '1') then
                    orx_jesd_buff <= orx_jesd_lane_307p2;
                else
                    orx_jesd_buff <= orx_jesd_buff;
                end if;
            end if;
        end process;
        
        fb_aq_e_bs_307p2(0) <= orx_jesd_buff(63 downto 48);
        fb_aq_o_bs_307p2(0) <= orx_jesd_buff(47 downto 32);
        
        fb_ai_e_bs_307p2(0) <= orx_jesd_buff(31 downto 16);        
        fb_ai_o_bs_307p2(0) <= orx_jesd_buff(15 downto  0); 
        
        FB_CDC: process(CLK_307p2)
        begin
            if (CLK_307p2'event and CLK_307p2= '1') then
                if (data_start_fb = '0') then
                    fb_ai_out <= fb_ai_e_bs_307p2;
                    fb_aq_out <= fb_aq_e_bs_307p2;
                else
                    fb_ai_out <= fb_ai_o_bs_307p2;
                    fb_aq_out <= fb_aq_o_bs_307p2;
                end if;
            end if;
        end process;

    FB_I_OUT <= fb_ai_out;
    FB_Q_OUT <= fb_aq_out;

    FB_DUMP_STRB : process(rst_fb_iq, CLK_307p2)
    begin
        if(CLK_307p2'event and CLK_307p2= '1') then
            fb_bfn_strb_lane <= fb_bfn_strb_jesd;
            fb_bfn_strb_sw   <= fb_bfn_strb_lane;
            fb_bfn_strb_o    <= fb_bfn_strb_sw;
       end if;
    end process;

    FB_BFN_STRB_OUT <= fb_bfn_strb_o;
    --=================================================================================================================
    -- Dump
    --=================================================================================================================
    -- DL Dump
    process(rst_dump,CLK_307p2)
        begin
        if  (rst_dump = '1') then
            dumpval_dl <= '0';
        elsif(CLK_307p2'event and CLK_307p2='1') then
            dumpval_dl <= '1'; -- not dumpval_dl;
        end if;
    end process;

    process(rst_dump,CLK_307p2)
        begin
        if  (rst_dump = '1') then
            dumpval_dl_ff <= (others => '0');
            dumpsel_dl <= (others => '0');
        elsif(CLK_307p2'event and CLK_307p2='1') then
            dumpval_dl_ff <= dumpval_dl_ff(1 downto 0) & dump_sel_val;
            if (dumpval_dl_ff (2) = '1' and dumpval_dl_ff(1) = '0') then -- falling edge detection
                dumpsel_dl <= dump_sel;
            else
                dumpsel_dl <= dumpsel_dl;
            end if;
        end if;
    end process;

    process(rst_dl_iq,CLK_307p2)
        begin
        if  (rst_dl_iq = '1') then
            dump_bfn_strb_dl <= '0';
            dump_data_dcif_dl <= (others => '0');
        elsif(CLK_307p2'event and CLK_307p2='1') then
            case dumpsel_dl(3 downto 0) is
                when x"0" =>
                    dump_bfn_strb_dl <= dl_bfn_strb_sw;
                    dump_data_dcif_dl <= dl_ai_sw(0) & dl_aq_sw(0);
                when x"1" =>
                    dump_bfn_strb_dl <= dl_bfn_strb_sw;
                    dump_data_dcif_dl <= dl_ai_sw(1) & dl_aq_sw(1);
--                when x"2" =>
--                    dump_bfn_strb_dl <= dl_bfn_strb_sw;
--                    dump_data_dcif_dl <= dl_ai_sw(2) & dl_aq_sw(2);
--                when x"3" =>
--                    dump_bfn_strb_dl <= dl_bfn_strb_sw;
--                    dump_data_dcif_dl <= dl_ai_sw(3) & dl_aq_sw(3);
                when others  =>
                    dump_bfn_strb_dl <= '0';
                    dump_data_dcif_dl <= (others => '0');
            end case;
        end if;
    end process;

    -- UL Dump
        process(rst_dump,CLK_307p2)
            begin
            if  (rst_dump = '1') then
                dumpval_ul <= '0';
            elsif(CLK_307p2'event and CLK_307p2='1') then
                dumpval_ul <= rx_toggle_valid; --'1'; --not dumpval_ul;
            end if;
        end process;

    process(rst_ul_iq, CLK_307p2) begin
        if rst_ul_iq = '1' then
            dumpval_ul_ff <= (others => '0');
            dumpsel_ul <= (others => '0');
        elsif CLK_307p2'event and CLK_307p2 = '1' then
            dumpval_ul_ff <= dumpval_ul_ff(1 downto 0) & dump_sel_val;
            if (dumpval_ul_ff (2) = '1' and dumpval_ul_ff(1) = '0') then -- falling edge detection
                dumpsel_ul <= dump_sel;
            else
                dumpsel_ul <= dumpsel_ul;
            end if;
        end if;
    end process;

    process(rst_ul_iq, CLK_307p2) begin
        if rst_ul_iq = '1' then
            dump_bfn_strb_ul <= '0';
            dump_data_dcif_ul <= (others => '0');
        elsif CLK_307p2'event and CLK_307p2 = '1' then
            case dumpsel_ul(3 downto 0) is
                when x"0" =>
                    dump_bfn_strb_ul <= ul_bfn_strb_test;
                    dump_data_dcif_ul <= ul_ai_test(0) & ul_aq_test(0);
                when x"1" =>
                    dump_bfn_strb_ul <= ul_bfn_strb_test;
                    dump_data_dcif_ul <= ul_ai_test(1) & ul_aq_test(1);
--                when x"2" =>
--                    dump_bfn_strb_ul <= ul_bfn_strb_test;
--                    dump_data_dcif_ul <= ul_ai_test(2) & ul_aq_test(2);
--                when x"3" =>
--                    dump_bfn_strb_ul <= ul_bfn_strb_test;
--                    dump_data_dcif_ul <= ul_ai_test(3) & ul_aq_test(3);
                when others  =>
                    dump_bfn_strb_ul <= '0';
                    dump_data_dcif_ul <=(others => '0');
           end case;
       end if;
    end process;


    process(rst_dump,CLK_307p2)
       begin
       if  (rst_dump = '1') then
           dumpval_fb <= '0';
       elsif(CLK_307p2'event and CLK_307p2='1') then
           dumpval_fb <= '1'; -- not dumpval_fb;
       end if;
    end process;

    process(rst_fb_iq, CLK_307p2) begin
        if rst_fb_iq = '1' then
            dumpval_fb_ff <= (others => '0');
            dumpsel_fb <= (others => '0');
        elsif CLK_307p2'event and CLK_307p2 = '1' then
            dumpval_fb_ff <= dumpval_fb_ff(1 downto 0) & dump_sel_val;
            if (dumpval_fb_ff (2) = '1' and dumpval_fb_ff(1) = '0') then  -- falling edge detection
                dumpsel_fb <= dump_sel;
            else
                dumpsel_fb <= dumpsel_fb;
            end if;
        end if;
    end process;

    process(rst_fb_iq, CLK_307p2) begin
       if rst_fb_iq = '1' then
           dump_bfn_strb_fb <= '0';
           dump_data_dcif_fb <= (others => '0');
       elsif CLK_307p2'event and CLK_307p2 = '1' then
           case dumpsel_fb(3 downto 0) is
               when x"0" =>
                   dump_bfn_strb_fb <= fb_bfn_strb_o;
                   dump_data_dcif_fb <= fb_ai_out(0) & fb_aq_out(0);
--               when x"1" =>
--                   dump_bfn_strb_fb <= fb_bfn_strb_o;
--                   dump_data_dcif_fb <= fb_ai_out(0) & fb_aq_out(0);
--                when x"2" =>
--                   dump_bfn_strb_fb <= fb_bfn_strb_o;
--                   dump_data_dcif_fb <= fb_ai_out(0) & fb_aq_out(0);
--                when x"3" =>
--                   dump_bfn_strb_fb <= fb_bfn_strb_o;
--                   dump_data_dcif_fb <= fb_ai_out(0) & fb_aq_out(0);
               when others  =>
                   dump_bfn_strb_fb <= '0';
                   dump_data_dcif_fb <= (others => '0');
           end case;
       end if;
    end process;


    process(rst_dump, CLK_307p2)
       begin
       if  (rst_dump = '1') then
            dumpsel_cdc <= (others => '0');
            dumpsel_val_d <= (others => '0');
        elsif(CLK_307p2'event and CLK_307p2='1') then
            dumpsel_val_d <= dumpsel_val_d(1 downto 0) & dump_sel_val;
            if (dumpsel_val_d(2) = '1' and dumpsel_val_d(1) = '0') then  -- falling edge detection
                dumpsel_cdc <= dump_sel;
            else
                dumpsel_cdc <= dumpsel_cdc;
            end if;
        end if;
    end process;

    process(rst_dump,CLK_307p2)
       begin
       if  (rst_dump = '1') then
           dump_bfn_strb    <= '0';
           dump_val_jesdblk  <= '0';
           dump_data_jesdblk <= (others => '0');
       elsif(CLK_307p2'event and CLK_307p2='1') then
           case dumpsel_cdc(7 downto 4) is
               when x"0" =>
                   dump_bfn_strb     <= dump_bfn_strb_dl;
                   dump_val_jesdblk  <= dumpval_dl;
                   dump_data_jesdblk <= dump_data_dcif_dl;
               when x"1" =>
                   dump_bfn_strb     <= dump_bfn_strb_ul;
                   dump_val_jesdblk  <= dumpval_ul;
                   dump_data_jesdblk <= dump_data_dcif_ul;
               when x"2" =>
                   dump_bfn_strb     <= dump_bfn_strb_fb;
                   dump_val_jesdblk  <= dumpval_fb;
                   dump_data_jesdblk <= dump_data_dcif_fb;
               when others  =>
                   dump_bfn_strb    <= '0';
                   dump_val_jesdblk  <= '0';
                   dump_data_jesdblk <=(others => '0');
           end case;
       end if;
    end process;

    DUMP_BFN_STRB_OUT <= dump_bfn_strb;
    DUMP_DVLD_OUT     <= dump_val_jesdblk;
    DUMP_DATA_OUT     <= dump_data_jesdblk;
    --=================================================================================================================
    -- Test & Debug
    --=================================================================================================================
    G_DL_JESD_Core_Clock_Assign : for I in 0 to (JESD_TX_LINK_NUM-1) generate begin
        SIG_SUS_DLFLAG_OUT(I) <= (not tx_sync_i(i)) or i_sig_sus_dlflag(I);
    end generate;

    G_UL_JESD_Core_Clock_Assign : for I in 0 to (JESD_RX_LINK_NUM-1) generate begin
        SIG_SUS_ULFLAG_OUT(I) <= (not rx_sync_i(i)) or i_sig_sus_ulflag(I);
    end generate;

    G_FB_JESD_Core_Clock_Assign : for I in 0 to (JESD_FB_LINK_NUM-1) generate begin
        SIG_SUS_FBFLAG_OUT(I) <= (not fb_sync_i(i)) or i_sig_sus_fbflag(I);
    end generate;
    --=================================================================================================================
    -- Component mapping
    --=================================================================================================================
    U_CPUIF_DCIF_i : CPUIF_DCIF
    port map(
        -- CPUIF
        RST_CPU                             => RST_CPUIF                                , --: in  std_logic;                     -- cpuif reset, '1': Reset
        CLK_CPU                             => CLK_CPUIF                                , --: in  std_logic;  -- cpuif clock, faster than iclk/oclk
        ADDR_CPU_IN                         => ADDR_CPUIF_IN                            , --: in  std_logic_vector(15 downto 0); -- cpuif address input, word address.
        WDATA_CPU_IN                        => WDATA_CPUIF_IN                           , --: in  std_logic_vector(31 downto 0); -- cpuif data input
        RDATA_CPU_OUT                       => RDATA_CPUIF_OUT                          , --: out std_logic_vector(31 downto 0); -- cpuif data output
        WREN_CPU_IN                         => WREN_CPUIF_IN                            , --: in  std_logic;                     -- cpuif write enable, '1': active, synchronous with iclk
        RDEN_CPU_IN                         => RDEN_CPUIF_IN                            , --: in  std_logic;                     -- cpuif read enable, '1': active.
        RDVAL_CPU_OUT                       => RDVAL_CPUIF_OUT                          , --: out std_logic;                     -- cpuif read data valid,

        --reset
        DL_JESD204_RST_OUT                  => dl_jesd204_rst_s                         , --: ((JESD_TX_LINK_NUM-1) downto 0);
        UL_JESD204_RST_OUT                  => ul_jesd204_rst_s                         , --: ((JESD_RX_LINK_NUM-1) downto 0);
        FB_JESD204_RST_OUT                  => fb_jesd204_rst_s                         , --: ((JESD_FB_LINK_NUM-1) downto 0);

        --control
        RFIC_SYSREF_ON_OUT                  => rfic_sysref_onoff                        , --: out  std_logic;
        JESD_IP_TX_SYSREF_ON_OUT            => tx_ip_sysref_onoff                       , --: out  std_logic;
        JESD_IP_RX_SYSREF_ON_OUT            => rx_ip_sysref_onoff                       , --: out  std_logic;
        JESD_IP_FB_SYSREF_ON_OUT            => fb_ip_sysref_onoff                       , --: out  std_logic;

        -- For IQ Test
        TEST_MODE_OUT                       => test_mode_on                             , --: out std_logic;
        TEST_SYNC_DL_OUT                    => test_sync_dl                             , --: out std_logic;           -- 0x6115     -- tx clk
        TEST_SYNC_FB_OUT                    => test_sync_fb                             , --: out std_logic;           -- 0x6115     -- fb clk
        TEST_SYNC_UL_OUT                    => test_sync_ul                             , --: out std_logic;           -- 0x6115     -- rx clk

        TEST_IQ_DL_OUT                      => test_data_sel                            , --: out std_logic_array2((TX_ANT_NUM-1) downto 0);
        SINE_NCO_OUT                        => sine_nco                                 , --: out std_logic_vector(5 downto 0);

        DL_AI_TEST_OUT                      => dl_ai_fixed                              , --: out std_logic_vector(15 downto 0);
        DL_AQ_TEST_OUT                      => dl_aq_fixed                              , --: out std_logic_vector(15 downto 0);

        TEST_IQ_UL_OUT                      => ul_test_data_sel                         , --: out std_logic_array2((RX_ANT_NUM-1) downto 0);
        UL_AI_TEST_OUT                      => ul_ai_fixed                              , --: out std_logic_vector(15 downto 0);
        UL_AQ_TEST_OUT                      => ul_aq_fixed                              , --: out std_logic_vector(15 downto 0);

        DUMP_SEL_VAL_OUT                    => dump_sel_val                             , --out std_logic;
        DUMP_ENB_OUT                        => dump_enb                                 , --out std_logic;
        DUMP_STRB_SEL_OUT                   => dump_strb_sel                            , --out std_logic;
        DUMP_SEL_OUT                        => dump_sel                                 , --out std_logic_vector(7 downto 0);

        DL_TDD_OFFSET_OUT                   => dl_tdd_offset                            , --: out std_logic_vector(23 downto 0);
        UL_TDD_OFFSET_OUT                   => ul_tdd_offset                            , --: out std_logic_vector(23 downto 0);
        FB_TDD_OFFSET_OUT                   => fb_tdd_offset                            , --: out std_logic_vector(23 downto 0);

        SIG_SUS_DLFLAG_OUT                  => i_sig_sus_dlflag                         ,--: out std_logic_vector(((TX_LINK_NUM-1) downto 0);
        SIG_SUS_ULFLAG_OUT                  => i_sig_sus_ulflag                         ,--: out std_logic_vector(((RX_LINK_NUM-1) downto 0);
        SIG_SUS_FBFLAG_OUT                  => i_sig_sus_fbflag                         ,--: out std_logic_vector(((FB_LINK_NUM-1) downto 0);

        DL_IQ_SWAP_OUT                      => dl_iq_swap                               ,--: out((JESD_TX_LINK_NUM-1) downto 0);
        UL_IQ_SWAP_OUT                      => ul_iq_swap                               ,--: out((JESD_RX_LINK_NUM-1) downto 0);
        FB_IQ_SWAP_OUT                      => fb_iq_swap                                --: out((JESD_FB_LINK_NUM-1) downto 0)

    );

    u_JESD204B_TOP : JESD204B_TOP_wrapper
    port map (
        AXI_JESD_CLK                        =>   JESD204B_AXI_ACLK                      ,--: in STD_LOGIC;
        AXI_JESD_ARESETN                    =>   JESD204B_AXI_ARESETN                   ,--: in STD_LOGIC;
        AXI_JESD_araddr                     =>   JESD204B_AXI_araddr                    ,--: in STD_LOGIC_VECTOR ( 31 downto 0 );
        AXI_JESD_arburst                    =>   JESD204B_AXI_arburst                   ,--: in STD_LOGIC_VECTOR ( 1 downto 0 );
        AXI_JESD_arcache                    =>   JESD204B_AXI_arcache                   ,--: in STD_LOGIC_VECTOR ( 3 downto 0 );
        AXI_JESD_arlen                      =>   JESD204B_AXI_arlen                     ,--: in STD_LOGIC_VECTOR ( 7 downto 0 );
        AXI_JESD_arlock                     =>   JESD204B_AXI_arlock                    ,--: in STD_LOGIC_VECTOR ( 0 to 0 );
        AXI_JESD_arprot                     =>   JESD204B_AXI_arprot                    ,--: in STD_LOGIC_VECTOR ( 2 downto 0 );
        AXI_JESD_arqos                      =>   JESD204B_AXI_arqos                     ,--: in STD_LOGIC_VECTOR ( 3 downto 0 );
        AXI_JESD_arready                    =>   JESD204B_AXI_arready                   ,--: out STD_LOGIC;
        AXI_JESD_arregion                   =>   JESD204B_AXI_arregion                  ,--: in STD_LOGIC_VECTOR ( 3 downto 0 );
        AXI_JESD_arsize                     =>   JESD204B_AXI_arsize                    ,--: in STD_LOGIC_VECTOR ( 2 downto 0 );
        AXI_JESD_arvalid                    =>   JESD204B_AXI_arvalid                   ,--: in STD_LOGIC;
        AXI_JESD_awaddr                     =>   JESD204B_AXI_awaddr                    ,--: in STD_LOGIC_VECTOR ( 31 downto 0 );
        AXI_JESD_awburst                    =>   JESD204B_AXI_awburst                   ,--: in STD_LOGIC_VECTOR ( 1 downto 0 );
        AXI_JESD_awcache                    =>   JESD204B_AXI_awcache                   ,--: in STD_LOGIC_VECTOR ( 3 downto 0 );
        AXI_JESD_awlen                      =>   JESD204B_AXI_awlen                     ,--: in STD_LOGIC_VECTOR ( 7 downto 0 );
        AXI_JESD_awlock                     =>   JESD204B_AXI_awlock                    ,--: in STD_LOGIC_VECTOR ( 0 to 0 );
        AXI_JESD_awprot                     =>   JESD204B_AXI_awprot                    ,--: in STD_LOGIC_VECTOR ( 2 downto 0 );
        AXI_JESD_awqos                      =>   JESD204B_AXI_awqos                     ,--: in STD_LOGIC_VECTOR ( 3 downto 0 );
        AXI_JESD_awready                    =>   JESD204B_AXI_awready                   ,--: out STD_LOGIC;
        AXI_JESD_awregion                   =>   JESD204B_AXI_awregion                  ,--: in STD_LOGIC_VECTOR ( 3 downto 0 );
        AXI_JESD_awsize                     =>   JESD204B_AXI_awsize                    ,--: in STD_LOGIC_VECTOR ( 2 downto 0 );
        AXI_JESD_awvalid                    =>   JESD204B_AXI_awvalid                   ,--: in STD_LOGIC;
        AXI_JESD_bready                     =>   JESD204B_AXI_bready                    ,--: in STD_LOGIC;
        AXI_JESD_bresp                      =>   JESD204B_AXI_bresp                     ,--: out STD_LOGIC_VECTOR ( 1 downto 0 );
        AXI_JESD_bvalid                     =>   JESD204B_AXI_bvalid                    ,--: out STD_LOGIC;
        AXI_JESD_rdata                      =>   JESD204B_AXI_rdata                     ,--: out STD_LOGIC_VECTOR ( 31 downto 0 );
        AXI_JESD_rlast                      =>   JESD204B_AXI_rlast                     ,--: out STD_LOGIC;
        AXI_JESD_rready                     =>   JESD204B_AXI_rready                    ,--: in STD_LOGIC;
        AXI_JESD_rresp                      =>   JESD204B_AXI_rresp                     ,--: out STD_LOGIC_VECTOR ( 1 downto 0 );
        AXI_JESD_rvalid                     =>   JESD204B_AXI_rvalid                    ,--: out STD_LOGIC;
        AXI_JESD_wdata                      =>   JESD204B_AXI_wdata                     ,--: in STD_LOGIC_VECTOR ( 31 downto 0 );
        AXI_JESD_wlast                      =>   JESD204B_AXI_wlast                     ,--: in STD_LOGIC;
        AXI_JESD_wready                     =>   JESD204B_AXI_wready                    ,--: out STD_LOGIC;
        AXI_JESD_wstrb                      =>   JESD204B_AXI_wstrb                     ,--: in STD_LOGIC_VECTOR ( 3 downto 0 );
        AXI_JESD_wvalid                     =>   JESD204B_AXI_wvalid                    ,--: in STD_LOGIC;

        I_CORE_CLK                          =>   CLK_153p6                             ,--: in STD_LOGIC;
        I_JESD_REFCLK                       =>   REFCLK_SERDES_IN                       ,--: in STD_LOGIC;

        I_TX_RESET                          =>   tx_core_rst(0)                         ,--: in STD_LOGIC;
        I_TX_SYSREF                         =>   jesd_tx_sysref                         ,--: in STD_LOGIC;
        I_JESD_TX0_GT_N                     =>   JESD_SERIAL_TX_OUT_N(1 downto 0)       ,--: out STD_LOGIC_VECTOR ( 1 downto 0 );
        I_JESD_TX0_GT_P                     =>   JESD_SERIAL_TX_OUT_P(1 downto 0)       ,--: out STD_LOGIC_VECTOR ( 1 downto 0 );
        I_JESD_TX1_GT_N                     =>   JESD_SERIAL_TX_OUT_N(3 downto 2)       ,--: out STD_LOGIC_VECTOR ( 1 downto 0 );
        I_JESD_TX1_GT_P                     =>   JESD_SERIAL_TX_OUT_P(3 downto 2)       ,--: out STD_LOGIC_VECTOR ( 1 downto 0 );
        I_JESD_TXDATA_tdata                 =>   dl_jesd_tdata                          ,--: in STD_LOGIC_VECTOR ( 127 downto 0 );
        I_JESD_TXDATA_tready                =>   dl_jesd_tready(0)                      ,--: out STD_LOGIC;
        I_JESD_TX_SYNC                      =>   tx_sync_i(0)                           ,--: in STD_LOGIC;

        I_RX_RESET                          =>   rx_core_rst(0)                         ,--: in STD_LOGIC;
        I_RX_SYSREF                         =>   jesd_rx_sysref                         ,--: in STD_LOGIC;
        I_JESD_RX_GT_N                      =>   JESD_SERIAL_RX_IN_N                    ,--: in STD_LOGIC_VECTOR ( 1 downto 0 );
        I_JESD_RX_GT_P                      =>   JESD_SERIAL_RX_IN_P                    ,--: in STD_LOGIC_VECTOR ( 1 downto 0 );
        O_JESD_RXDATA_tdata                 =>   ul_jesd_tdata                          ,--: out STD_LOGIC_VECTOR ( 63 downto 0 );
        O_JESD_RXDATA_tvalid                =>   ul_jesd_tvalid(0)                      ,--: out STD_LOGIC;
        O_JESD_RX_ARESETN                   =>   open                                   ,--: out STD_LOGIC;
        O_JESD_RX_SOF                       =>   open                                   ,--: out STD_LOGIC_VECTOR ( 3 downto 0 );
        O_JESD_RX_SYNC                      =>   rx_sync_i(0)                           ,--: out STD_LOGIC;

        I_FB_RESET                          =>   fb_core_rst(0)                         ,--: in STD_LOGIC;
        I_FB_SYSREF                         =>   jesd_fb_sysref                         ,--: in STD_LOGIC;
        I_JESD_FB_GT_N                      =>   JESD_SERIAL_FB_IN_N                    ,--: in STD_LOGIC_VECTOR ( 1 downto 0 );
        I_JESD_FB_GT_P                      =>   JESD_SERIAL_FB_IN_P                    ,--: in STD_LOGIC_VECTOR ( 1 downto 0 );
        O_JESD_FBDATA_tdata                 =>   fb_jesd_tdata                          ,--: out STD_LOGIC_VECTOR ( 63 downto 0 );
        O_JESD_FBDATA_tvalid                =>   fb_jesd_tvalid(0)                      ,--: out STD_LOGIC;
        O_JESD_FB_ARESETN                   =>   open                                   ,--: out STD_LOGIC;
        O_JESD_FB_SOF                       =>   open                                   ,--: out STD_LOGIC_VECTOR ( 3 downto 0 );
        O_JESD_FB_SYNC                      =>   fb_sync_i(0)                            --: out STD_LOGICc
);

end Behavioral;