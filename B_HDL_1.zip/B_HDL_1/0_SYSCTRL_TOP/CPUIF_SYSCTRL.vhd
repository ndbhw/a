----------------------------------------------------------------------------------
-- Company: SEC
-- Engineer:
--
-- Create Date: 2016-10-08 AM 09:40:53
-- Design Name: jinoo.bae
-- Module Name: CPUIF_SYSCTRL - Behavioral
-- Project Name: FD-MIMO
-- Target Devices: ZYNQ035_2LI
-- Tool versions: vivado20162
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;
use work.datetime.all;

entity CPUIF_SYSCTRL is
    generic(
        LED_NUM                : natural                       := 4;
        TX_ANT_NUM             : natural                       := 8;
        CSREF_NUM              : natural                       := 6;
        JSREF_NUM              : natural                       := 6;
        SSREF_NUM              : natural                       := 6;
        C_SYSCTRL_IMG_DATE     : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"2024_0822";
        C_SYSCTRL_IMG_VER      : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0000_0001";
        C_SYSCTRL_SYSTEM_INFO0 : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0000_0000"; -- air_tech[3:0]
        C_SYSCTRL_SYSTEM_INFO1 : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0000_0000"; -- freq_band[7:0]
        C_SYSCTRL_SYSTEM_INFO2 : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0000_0000"; -- freq_band[7:0]
        C_SYSCTRL_SYSTEM_INFO3 : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0232_3206"; -- fb_path_num, rx_ant_num, tx_ant_num,cpri_num
        C_SYSCTRL_PBA_INFO     : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0000_0000";
        C_SYSCTRL_DEV_INFO     : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0000_0000";
        C_SYSCTRL_MODULE_INFO  : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0000_0001";
        C_SYSCTRL_STRUCT_INFO  : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0000_0000";
        C_SYSCTRL_MODULE_DATE  : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"2024_0822"
    );
    port(
        FPGA_ID                 : in std_logic_vector(1 downto 0);
        PCB_VER                 : in std_logic_vector(3 downto 0);
                
        CLK_CPUIF               : in std_logic;
        RST_CPUIF               : in std_logic;

        ADDR_CPUIF_SYSCTRL      : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_SYSCTRL     : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_SYSCTRL     : out std_logic_vector(31 downto 0);
        WREN_CPUIF_SYSCTRL      : in  std_logic;
        RDEN_CPUIF_SYSCTRL      : in  std_logic;
        RDVAL_CPUIF_SYSCTRL     : out std_logic;
    
        SYSCTRL_IPLL_RST        : out std_logic_vector(2 downto 0);
        SYSCTRL_ORAN_RX_RST     : out std_logic_vector(NUM_ORAN-1 downto 0);
        SYSCTRL_ORAN_TX_RST     : out std_logic_vector(NUM_ORAN-1 downto 0);
        SYSCTRL_BBTOP_RST       : out std_logic;
        SYSCTRL_DLFE_RST        : out std_logic;
        SYSCTRL_ULFE_RST        : out std_logic;
        SYSCTRL_RAFE_RST        : out std_logic;
        SYSCTRL_BBCTRL_RST      : out std_logic;
        SYSCTRL_DDUC_RST        : out std_logic;
        SYSCTRL_CFR_RST         : out std_logic;
        SYSCTRL_DPD_RST         : out std_logic;
        SYSCTRL_DCIF_RST        : out std_logic;
        SYSCTRL_MISC_RST        : out std_logic;
        SYSCTRL_DUMP_RST        : out std_logic;

        SYSCTRL_FUNC_FAIL_TRIG  : in  std_logic_vector(1 downto 0); -- need to check
        SYSCTRL_CLK_FAIL_TRIG   : in  std_logic_vector(31 downto 0);
        SYSCTRL_TDD_CTRL        : out std_logic_array32(19 downto 0);
        LOCK_1588               : out std_logic;
        SYSCTRL_LED_CTRL        : out std_logic_array5(LED_NUM -1 downto 0);
        SYSCTRL_HW_WDT_CTRL     : out std_logic_vector(31 downto 0);
        SYSCTRL_RUID            : out std_logic_vector(3 downto 0);
        SYSCTRL_RU_FF           : out std_logic;
        
        DL_FSYNC_ERR            : in  std_logic_vector(4 downto 0);
        DL_FSYNC_CNT_0          : in  std_logic_vector(21 downto 0);
        DL_FSYNC_CNT_1          : in  std_logic_vector(21 downto 0);
        DL_FSYNC_CNT_2          : in  std_logic_vector(21 downto 0);
        DL_FSYNC_CNT_3          : in  std_logic_vector(21 downto 0);

        UL_FSYNC_ERR            : in  std_logic_vector(4 downto 0);
        UL_FSYNC_CNT_0          : in  std_logic_vector(21 downto 0);
        UL_FSYNC_CNT_1          : in  std_logic_vector(21 downto 0);
        UL_FSYNC_CNT_2          : in  std_logic_vector(21 downto 0);

        DL_SYNC_ADVANCE         : out std_logic_vector(21 downto 0);
        UL_SYNC_RETARD          : out std_logic_vector(21 downto 0);
        N_TA_OFFSET             : out std_logic_vector(15 downto 0);

        TP_CON_SEL              : out std_logic_vector(7 downto 0);
        MUX_SEL                 : out std_logic_vector(1 downto 0);

        NR_SSB_PERIOD           : out std_logic_vector(4 downto 0);
        NR_SSB_OFFSET : out std_logic_vector(3 downto 0);
        BFN_CTRL      : out std_logic;
        BFN_MORNITOR  : in  std_logic_vector(3 downto 0)
    );
end CPUIF_SYSCTRL;

architecture ARC_CPUIF_OTHERS of CPUIF_SYSCTRL is

    component REG32_WRITE is
        generic (
            BIT_ENABLE : std_logic_vector(31 downto 0) := (others => '1');
            REG_ADDR   : std_logic_vector( 7 downto 0) := (others => '0'); -- Register address
            REG_DATA   : std_logic_vector(31 downto 0) := (others => '0')  -- Default value
        );
        port (
            RST : in std_logic; -- reset, '1': reset
            CLK : in std_logic; -- clock

            EN       : in  std_logic;                     -- Write enable
            ADDR     : in  std_logic_vector( 7 downto 0); -- Input Address
            DATA_IN  : in  std_logic_vector(31 downto 0); -- Data input
            DATA_OUT : out std_logic_vector(31 downto 0)  -- Data output
        );
    end component;

    component REG32_LATCH
        generic(
            BIT_ENABLE : std_logic_vector(31 downto 0) := (others => '1');
            REG_ADDR   : std_logic_vector( 7 downto 0) := (others => '0')
        );
        port(
            RST : in std_logic;
            CLK : in std_logic;

            CLR_IN   : in  std_logic;                     -- Clear input, falling edge detection
            ADDR_IN  : in  std_logic_vector( 7 downto 0); -- Address input
            DATA_IN  : in  std_logic_vector(31 downto 0);
            DATA_OUT : out std_logic_vector(31 downto 0);
            FLAG_OUT : out std_logic_vector(31 downto 0)
        );
    end component;

    constant VERSION_INFO : std_logic_vector(31 downto 0) := x"2023_0925";
    constant COMPILE_DATE : std_logic_vector(31 downto 0) := DATE_HEX;
    constant COMPILE_TIME : std_logic_vector(31 downto 0) := TIME_HEX;

    signal rden_dly    : std_logic_vector(7 downto 0);  -- Read Enable Signal Delay
    signal addrl8b     : std_logic_vector(7 downto 0);  -- Address Low 8Bit
    signal wdata       : std_logic_vector(31 downto 0); -- CPU Write Data
    signal rdata       : std_logic_vector(31 downto 0); -- CPU Read Data
    signal wren_d1     : std_logic;                     -- 1-Clock Delayed Write Enable
    signal wren_d2     : std_logic;                     -- 2-Clock Delayed Write Enable
    signal wren_pls    : std_logic;                     -- Write Enable 1-Clock Pulse
    signal rden_d1     : std_logic;                     -- 1-Clock Delayed Read Enable
    signal rden_strobe : std_logic;                     -- 2-Clock Delayed Read Strobe
    signal rdval_pls   : std_logic;                     -- Read Data Valud Pulse

    signal wren_pls_00 : std_logic;
    signal wren_pls_01 : std_logic;
    signal wren_pls_02 : std_logic;
    signal wren_pls_03 : std_logic;
    signal wren_pls_04 : std_logic;
    signal wren_pls_05 : std_logic;
    signal wren_pls_06 : std_logic;
    signal wren_pls_07 : std_logic;
    signal wren_pls_08 : std_logic;
    signal wren_pls_09 : std_logic;

    signal rden_pls_02 : std_logic;
    --signal rden_pls_00                          : std_logic;
    --signal rden_pls_01                          : std_logic;
    --signal rden_pls_03                          : std_logic;
    --signal rden_pls_04                          : std_logic;
    --signal rden_pls_05                          : std_logic;
    --signal rden_pls_06                          : std_logic;
    --signal rden_pls_07                          : std_logic;
    --signal rden_pls_08                          : std_logic;
    --signal rden_pls_09                          : std_logic;

    signal func_fail_flag_oring     : std_logic;
    signal func_fail_flag_d         : std_logic_vector(1 downto 0);
    signal vss_remote_rst_oring     : std_logic; -- vss reset oring
    signal vss_remote_rst_d         : std_logic_vector(1 downto 0);
    signal sysctrl_img_date         : std_logic_vector(31 downto 0);
    signal sysctrl_img_ver          : std_logic_vector(31 downto 0);
    signal sysctrl_system_info0     : std_logic_vector(31 downto 0); -- air_tech[3:0]
    signal sysctrl_system_info1     : std_logic_vector(31 downto 0); -- freq_band[7:0]
    signal sysctrl_system_info2     : std_logic_vector(31 downto 0); -- freq_band[7:0]
    signal sysctrl_system_info3     : std_logic_vector(31 downto 0); -- fb_path_num, rx_ant_num, tx_ant_num,cpri_num
    signal sysctrl_system_info4     : std_logic_vector(31 downto 0); -- fpga_id
    signal sysctrl_pba_info         : std_logic_vector(31 downto 0);
    signal sysctrl_dev_info         : std_logic_vector(31 downto 0);
    signal sysctrl_module_info      : std_logic_vector(31 downto 0);
    signal sysctrl_struct_info      : std_logic_vector(31 downto 0);
    signal sysctrl_module_date      : std_logic_vector(31 downto 0);
    signal sysctrl_ipll_rst_r       : std_logic_vector(31 downto 0); -- number of internal DCM
    signal sysctrl_cpriphy_rst_r    : std_logic_vector(31 downto 0);
    signal sysctrl_cpri_rst_r       : std_logic_vector(31 downto 0);
    signal sysctrl_ethmux_rst_r     : std_logic_vector(31 downto 0);
    signal sysctrl_oran_rx_rst_r    : std_logic_vector(31 downto 0) := (others => '1');
    signal sysctrl_oran_tx_rst_r    : std_logic_vector(31 downto 0) := (others => '1');
    signal sysctrl_bbtop_rst_r      : std_logic_vector(31 downto 0) := (others => '1');
    signal sysctrl_dlfe_rst_r       : std_logic_vector(31 downto 0) := (others => '1');
    signal sysctrl_ulfe_rst_r       : std_logic_vector(31 downto 0) := (others => '1');
    signal sysctrl_rafe_rst_r       : std_logic_vector(31 downto 0) := (others => '1');
    signal sysctrl_bbctrl_rst_r     : std_logic_vector(31 downto 0);
    signal sysctrl_dduc_rst_r       : std_logic_vector(31 downto 0);
    signal sysctrl_cfr_rst_r        : std_logic_vector(31 downto 0);
    signal sysctrl_dpd_rst_r        : std_logic_vector(31 downto 0);
    signal sysctrl_dcif_rst_r       : std_logic_vector(31 downto 0);
    signal sysctrl_ruid_r           : std_logic_vector(31 downto 0);
    signal sysctrl_misc_rst_r       : std_logic_vector(31 downto 0);
    signal sysctrl_pim_rst_r        : std_logic_vector(31 downto 0);
    signal sysctrl_dump_rst_r       : std_logic_vector(31 downto 0) := (others => '1');
    signal sysctrl_clk_fail_flag_r  : std_logic_vector(31 downto 0);
    signal sysctrl_clk_fail_sts_r   : std_logic_vector(31 downto 0);
    signal i_func_fail_flag_d       : std_logic_vector(31 downto 0);
    signal sysctrl_func_fail_flag_r : std_logic_vector(31 downto 0);
    signal sysctrl_func_fail_sts_r  : std_logic_vector(31 downto 0);
    signal sysctrl_led_ctrl_r       : std_logic_vector(31 downto 0); -- init -0x1111
    signal sysctrl_hw_wdt_ctrl_r    : std_logic_vector(31 downto 0); -- check inital value
    signal sysctrl_vss_rst_ctrl_r   : std_logic_vector(31 downto 0);
    signal sysctrl_pa_enb_r         : std_logic_vector(31 downto 0);
    signal zeros32                  : std_logic_vector(31 downto 0) := (others => '0');
    signal i_vss_rmt_rst_cpri       : std_logic_vector(31 downto 0);
    signal sysctrl_vss_rst_flag     : std_logic_vector(31 downto 0);
    signal sysctrl_vss_rst_sts      : std_logic_vector(31 downto 0);
    signal nr_ssb_offset_r          : std_logic_vector(31 downto 0);
    signal nr_ssb_period_r          : std_logic_vector(31 downto 0);
    signal bfn_ctrl_r               : std_logic_vector(31 downto 0);

    signal lock_sts_1588_r          : std_logic_vector(31 downto 0);

    signal dl_sync_advance_r        : std_logic_vector(31 downto 0);
    signal ul_sync_retard_r         : std_logic_vector(31 downto 0);
    signal n_ta_offset_r            : std_logic_vector(31 downto 0);

    signal tp_con_sel_r             : std_logic_vector(31 downto 0);

    signal sysctrl_tdd_ctrl_r       : std_logic_array32(19 downto 0);
    
    signal fail_clock_w             : std_logic_vector(31 downto 0) := (others => '0');
    signal fail_clock_f             : std_logic_vector(31 downto 0);
    signal fail_clock_s             : std_logic_vector(31 downto 0);

    signal dl_fsync_err_w           : std_logic_vector(31 downto 0);
    signal dl_fsync_err_f           : std_logic_vector(31 downto 0);
    signal dl_fsync_err_s           : std_logic_vector(31 downto 0);

    signal ul_fsync_err_w           : std_logic_vector(31 downto 0);
    signal ul_fsync_err_f           : std_logic_vector(31 downto 0);
    signal ul_fsync_err_s           : std_logic_vector(31 downto 0);
begin

    ----------------------------------------------------------------------------
    -- Port Mapping
    ----------------------------------------------------------------------------
    sysctrl_img_date     <= C_SYSCTRL_IMG_DATE;
    sysctrl_img_ver      <= C_SYSCTRL_IMG_VER;
    sysctrl_system_info0 <= C_SYSCTRL_SYSTEM_INFO0;
    sysctrl_system_info1 <= C_SYSCTRL_SYSTEM_INFO1;
    sysctrl_system_info2 <= C_SYSCTRL_SYSTEM_INFO2;
    sysctrl_system_info3 <= C_SYSCTRL_SYSTEM_INFO3;
    sysctrl_system_info4 <= x"0000000" & "00" & FPGA_ID;
    sysctrl_pba_info     <= x"0000000" & PCB_VER;
    sysctrl_dev_info     <= C_SYSCTRL_DEV_INFO;
    sysctrl_module_info  <= C_SYSCTRL_MODULE_INFO;
    sysctrl_struct_info  <= C_SYSCTRL_STRUCT_INFO;
    sysctrl_module_date  <= C_SYSCTRL_MODULE_DATE;
    SYSCTRL_IPLL_RST     <= sysctrl_ipll_rst_r(2 downto 0);
    SYSCTRL_ORAN_RX_RST  <= sysctrl_oran_rx_rst_r(NUM_ORAN-1 downto 0);
    SYSCTRL_ORAN_TX_RST  <= sysctrl_oran_tx_rst_r(NUM_ORAN-1 downto 0);
    SYSCTRL_BBTOP_RST    <= sysctrl_bbtop_rst_r(0);  
    SYSCTRL_DLFE_RST     <= sysctrl_dlfe_rst_r(0);  
    SYSCTRL_ULFE_RST     <= sysctrl_ulfe_rst_r(0);   
    SYSCTRL_RAFE_RST     <= sysctrl_rafe_rst_r(0);   

    SYSCTRL_BBCTRL_RST   <= sysctrl_bbctrl_rst_r(0);
    SYSCTRL_DDUC_RST     <= sysctrl_dduc_rst_r(0);
    SYSCTRL_CFR_RST      <= sysctrl_cfr_rst_r(0);
    SYSCTRL_DPD_RST      <= sysctrl_dpd_rst_r(0);
    SYSCTRL_DCIF_RST     <= sysctrl_dcif_rst_r(0);
    SYSCTRL_RUID         <= sysctrl_ruid_r(3 downto 0);
    SYSCTRL_RU_FF        <= sysctrl_func_fail_sts_r(0);
    SYSCTRL_MISC_RST     <= sysctrl_misc_rst_r(0);
    SYSCTRL_DUMP_RST     <= sysctrl_dump_rst_r(0);
    
    DL_SYNC_ADVANCE      <= dl_sync_advance_r(21 downto 0);
    UL_SYNC_RETARD       <= ul_sync_retard_r(21 downto 0);
    N_TA_OFFSET          <= n_ta_offset_r(15 downto 0);
    --    LOCK_1588            <= lock_sts_1588_r;

    TP_CON_SEL           <= tp_con_sel_r(7 downto 0);
    MUX_SEL              <= tp_con_sel_r(16) & tp_con_sel_r(8);

    U_LED_ASSIGN_GEN : for I in 0 to (LED_NUM - 1) generate
        SYSCTRL_LED_CTRL(i) <= sysctrl_led_ctrl_r(3+4*i) & sysctrl_led_ctrl_r(2+4*i) & sysctrl_led_ctrl_r(24+2*i) & sysctrl_led_ctrl_r(1+4*i) & sysctrl_led_ctrl_r(0+4*i);
    end generate;

    SYSCTRL_HW_WDT_CTRL <= sysctrl_hw_wdt_ctrl_r; -- need to check
    NR_SSB_PERIOD       <= nr_ssb_period_r(4 downto 0);
    NR_SSB_OFFSET       <= nr_ssb_offset_r(3 downto 0);

    i_func_fail_flag_d  <= zeros32(31 downto 1) & func_fail_flag_d(1);

    BFN_CTRL            <= bfn_ctrl_r(0);


    -------------------------------------------------------------------- function fail
    func_fail_flag_oring <= '1' when (SYSCTRL_FUNC_FAIL_TRIG = "11") else '0';

    process(RST_CPUIF, CLK_CPUIF)
    begin
        if (RST_CPUIF = '1') then
            func_fail_flag_d <= "00";
        elsif (CLK_CPUIF = '1' and CLK_CPUIF'event) then
            func_fail_flag_d <= func_fail_flag_d(0) & func_fail_flag_oring;
        end if;
    end process;

    ----------------------------------------------------------------------------------------------
    -- Read Data Valid Signal Generation, 5 Clock Latency
    ----------------------------------------------------------------------------------------------
    process(RST_CPUIF, CLK_CPUIF)
    begin
        if (RST_CPUIF = '1') then
            rden_dly  <= (others => '0');
            rdval_pls <= '0';
        elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
            rden_dly <= rden_dly(6 downto 0) & RDEN_CPUIF_SYSCTRL;
            if (rden_dly(3) = '1' and rden_dly(4) = '0') then -- 1 Clock Duration
                rdval_pls <= '1';
            else
                rdval_pls <= '0';
            end if;
        end if;
    end process;
    RDATA_CPUIF_SYSCTRL <= rdata;
    RDVAL_CPUIF_SYSCTRL <= rdval_pls;


    ----------------------------------------------------------------------------------------------
    -- Register Write
    ----------------------------------------------------------------------------------------------
    wdata   <= WDATA_CPUIF_SYSCTRL;
    addrl8b <= ADDR_CPUIF_SYSCTRL(7 downto 0);
    -- Write Enable Pulse Signal Generation
    process(RST_CPUIF, CLK_CPUIF)
    begin
        if (RST_CPUIF = '1') then
            wren_d1 <= '0';
            wren_d2 <= '0';
        elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
            wren_d1 <= WREN_CPUIF_SYSCTRL;
            wren_d2 <= wren_d1;
        end if;
    end process;

    process(RST_CPUIF, CLK_CPUIF)
    begin
        if (RST_CPUIF = '1') then
            wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
            wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
        elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
            if (wren_d1 = '1' and wren_d2 = '0') then -- rising edge
                case ADDR_CPUIF_SYSCTRL(15 downto 8) is
                    when x"00" => wren_pls_00 <= '1'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                        wren_pls_05               <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                    when x"01" => wren_pls_00 <= '0'; wren_pls_01 <= '1'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                        wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                    when x"02" => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '1'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                        wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                    when x"03" => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '1'; wren_pls_04 <= '0';
                        wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                    when x"04" => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '1';
                        wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                    when x"05" => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                        wren_pls_05 <= '1'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                    when x"06" => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                        wren_pls_05 <= '0'; wren_pls_06 <= '1'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                    when x"07" => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                        wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '1'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                    when x"08" => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                        wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '1'; wren_pls_09 <= '0';
                    when x"09" => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                        wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '1';
                    when others => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                        wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                end case;
            else
                wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
            end if;
        end if;
    end process;

    REG32_WRITE_0X0002 : REG32_WRITE generic map(x"0000_000F", x"02", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_00, addrl8b, wdata, sysctrl_ruid_r);
    REG32_WRITE_0X0110 : REG32_WRITE generic map(x"0000_00FF", x"10", x"000000FF") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_ipll_rst_r);
    REG32_WRITE_0X0120 : REG32_WRITE generic map(x"00FF_00FF", x"20", x"00FF00FF") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_cpriphy_rst_r);
    REG32_WRITE_0X0130 : REG32_WRITE generic map(x"0000_00FF", x"30", x"000000FF") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_cpri_rst_r);
    REG32_WRITE_0X0132 : REG32_WRITE generic map(x"0000_0001", x"32", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_ethmux_rst_r);
    REG32_WRITE_0X0138 : REG32_WRITE generic map(x"0000_0001", x"38", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_oran_rx_rst_r);
    REG32_WRITE_0X0139 : REG32_WRITE generic map(x"0000_0001", x"39", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_oran_tx_rst_r);
    REG32_WRITE_0X0140 : REG32_WRITE generic map(x"0000_0001", x"40", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_bbctrl_rst_r);
    REG32_WRITE_0X0151 : REG32_WRITE generic map(x"0000_0001", x"51", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_dduc_rst_r);
    REG32_WRITE_0X0152 : REG32_WRITE generic map(x"0000_0001", x"52", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_cfr_rst_r);
    REG32_WRITE_0X0153 : REG32_WRITE generic map(x"0000_0001", x"53", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_dpd_rst_r);
    REG32_WRITE_0X0160 : REG32_WRITE generic map(x"0000_0001", x"60", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_dcif_rst_r);
    REG32_WRITE_0X0170 : REG32_WRITE generic map(x"0000_0001", x"70", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_misc_rst_r);
    REG32_WRITE_0X0171 : REG32_WRITE generic map(x"0000_0001", x"71", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_dump_rst_r);
    REG32_WRITE_0X0180 : REG32_WRITE generic map(x"0000_0001", x"80", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_dlfe_rst_r);
    REG32_WRITE_0X0190 : REG32_WRITE generic map(x"0000_0001", x"90", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_ulfe_rst_r);
    REG32_WRITE_0X0191 : REG32_WRITE generic map(x"0000_0001", x"91", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_rafe_rst_r);
    REG32_WRITE_0X0192 : REG32_WRITE generic map(x"0000_0001", x"92", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_bbtop_rst_r);
    REG32_WRITE_0X01D0 : REG32_WRITE generic map(x"0000_0001", x"D0", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_pim_rst_r);
    REG32_WRITE_0X0202 : REG32_WRITE generic map(x"0000_0001", x"02", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_02, addrl8b, wdata, sysctrl_vss_rst_ctrl_r);
    REG32_WRITE_0X0300 : REG32_WRITE generic map(x"FFFF_FFFF", x"00", x"00001111") port map(RST_CPUIF, CLK_CPUIF, wren_pls_03, addrl8b, wdata, sysctrl_led_ctrl_r);
    REG32_WRITE_0X0304 : REG32_WRITE generic map(x"FFFF_FFFF", x"04", x"00010078") port map(RST_CPUIF, CLK_CPUIF, wren_pls_03, addrl8b, wdata, sysctrl_hw_wdt_ctrl_r);
    REG32_WRITE_0X0320 : REG32_WRITE generic map(x"FFFF_FFFF", x"20", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_03, addrl8b, wdata, sysctrl_pa_enb_r);
        REG32_WRITE_0X0580 : REG32_WRITE generic map(x"FFFF_FFFF", x"80", x"00000004") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, nr_ssb_period_r);
        REG32_WRITE_0X0581 : REG32_WRITE generic map(x"0000_000F", x"81", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, nr_ssb_offset_r);
        REG32_WRITE_0X0582 : REG32_WRITE generic map(x"0000_000F", x"82", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, bfn_ctrl_r);
    REG_LATCH_0x0200   : REG32_LATCH generic map(x"0000_FFFF", x"00") port map(RST_CPUIF, CLK_CPUIF, rden_pls_02, addrl8b, i_vss_rmt_rst_cpri, sysctrl_vss_rst_sts, sysctrl_vss_rst_flag );
    REG_LATCH_0x0204   : REG32_LATCH generic map(x"0000_0001", x"04") port map(RST_CPUIF, CLK_CPUIF, rden_pls_02, addrl8b, i_func_fail_flag_d, sysctrl_func_fail_sts_r, sysctrl_func_fail_flag_r );
    REG_LATCH_0x0206   : REG32_LATCH generic map(x"FFFF_FFFF", x"06") port map(RST_CPUIF, CLK_CPUIF, rden_pls_02, addrl8b, SYSCTRL_CLK_FAIL_TRIG, sysctrl_clk_fail_sts_r, sysctrl_clk_fail_flag_r ); -- need to clk_fail check
    REG_LATCH_0X0220   : REG32_LATCH generic map(x"FFFFFFFF",   x"20") port map(RST_CPUIF, CLK_CPUIF, rden_pls_02, addrl8b, dl_fsync_err_w, dl_fsync_err_s, dl_fsync_err_f );
    REG_LATCH_0X0222   : REG32_LATCH generic map(x"FFFFFFFF",   x"22") port map(RST_CPUIF, CLK_CPUIF, rden_pls_02, addrl8b, ul_fsync_err_w, ul_fsync_err_s, ul_fsync_err_f );                                                                                                                                                                                                         ----------------------------------------------------------------------------------------------
                                                                                                                                                                                                     -- Register Read
                                                                                                                                                                                                     ----------------------------------------------------------------------------------------------
                                                                                                                                                                                                     -- Clock Domain Change for Control Signals
    REG32_WRITE_0X0210 : REG32_WRITE generic map(x"00000003",   x"10", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_02, addrl8b, wdata, lock_sts_1588_r );
    REG32_WRITE_0X0230 : REG32_WRITE generic map(x"FFFFFFFF",   x"30", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_02, addrl8b, wdata, tp_con_sel_r );
--    REG32_WRITE_0X0240 : REG32_WRITE generic map(x"FFFFFFFF",   x"40", x"002524c2") port map(RST_CPUIF, CLK_CPUIF, wren_pls_02, addrl8b, wdata, dl_sync_advance_r );
--    REG32_WRITE_0X0241 : REG32_WRITE generic map(x"FFFFFFFF",   x"41", x"00257384") port map(RST_CPUIF, CLK_CPUIF, wren_pls_02, addrl8b, wdata, ul_sync_retard_r );

    REG32_WRITE_0X0240 : REG32_WRITE generic map(x"FFFFFFFF",   x"40", x"00254ff0") port map(RST_CPUIF, CLK_CPUIF, wren_pls_02, addrl8b, wdata, dl_sync_advance_r );
    REG32_WRITE_0X0241 : REG32_WRITE generic map(x"FFFFFFFF",   x"41", x"00255000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_02, addrl8b, wdata, ul_sync_retard_r );
    
    REG32_WRITE_0X0260 : REG32_WRITE generic map(x"FFFFFFFF",   x"60", x"00006400") port map(RST_CPUIF, CLK_CPUIF, wren_pls_02, addrl8b, wdata, n_ta_offset_r ); -- 0/25600(13us)/39936(20.3us)
    



    
    RDEN_DLY_GEN0 : process(RST_CPUIF, CLK_CPUIF)
    begin
        if (RST_CPUIF = '1') then
            rden_d1     <= '0';
            rden_strobe <= '0';
        elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
            rden_d1     <= RDEN_CPUIF_SYSCTRL;
            rden_strobe <= rden_d1;
        end if;
    end process;


    RDEN_LATCH_GEN0 : process(RST_CPUIF, CLK_CPUIF)
    begin
        if (RST_CPUIF = '1') then
            rden_pls_02 <= '0';
        elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
            if (RDEN_DLY(1) = '1' and RDEN_DLY(2) = '0') then
                case ADDR_CPUIF_SYSCTRL(15 downto 8) is
                    when x"02"  => rden_pls_02 <= '1';
                    when others => rden_pls_02 <= '0';
                end case;
            else
                rden_pls_02 <= '0';
            end if;
        end if;
    end process;




    RDATA_MUX_PROC0 : process(RST_CPUIF, CLK_CPUIF)
    begin
        if (RST_CPUIF = '1') then
            rdata <= (others => '0');
        elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
            if (rden_strobe = '1') then
                case ADDR_CPUIF_SYSCTRL(15 downto 8) is
                    when x"00" =>
                        case addrl8b is
                            when x"00"  => rdata <= COMPILE_DATE;
                            when x"01"  => rdata <= sysctrl_img_ver;
                            when x"02"  => rdata <= sysctrl_ruid_r;
                            when x"04"  => rdata <= sysctrl_system_info0;
                            when x"05"  => rdata <= sysctrl_system_info1;
                            when x"06"  => rdata <= sysctrl_system_info2;
                            when x"07"  => rdata <= sysctrl_system_info3;
                            when x"08"  => rdata <= sysctrl_system_info4;
                            when x"0C"  => rdata <= sysctrl_pba_info;
                            when x"0D"  => rdata <= sysctrl_dev_info;
                            when others => rdata <= (others => '0');
                        end case;
                    when x"01" =>
                        case addrl8b is
                            when x"00"  => rdata <= sysctrl_module_info;
                            when x"01"  => rdata <= sysctrl_struct_info;
                            when x"02"  => rdata <= sysctrl_module_date;
                            when x"10"  => rdata <= sysctrl_ipll_rst_r;
                            when x"38"  => rdata <= sysctrl_oran_rx_rst_r;
                            when x"39"  => rdata <= sysctrl_oran_tx_rst_r;
                            when x"20"  => rdata <= sysctrl_cpriphy_rst_r;
                            when x"30"  => rdata <= sysctrl_cpri_rst_r;
                            when x"32"  => rdata <= sysctrl_ethmux_rst_r;
                            when x"40"  => rdata <= sysctrl_bbctrl_rst_r;
                            when x"51"  => rdata <= sysctrl_dduc_rst_r;
                            when x"52"  => rdata <= sysctrl_cfr_rst_r;
                            when x"53"  => rdata <= sysctrl_dpd_rst_r;
                            when x"60"  => rdata <= sysctrl_dcif_rst_r;
                            when x"70"  => rdata <= sysctrl_misc_rst_r;
                            when x"71"  => rdata <= sysctrl_dump_rst_r;
                            when x"80"  => rdata <= sysctrl_dlfe_rst_r;
                            when x"90"  => rdata <= sysctrl_ulfe_rst_r;
                            when x"91"  => rdata <= sysctrl_rafe_rst_r;
                            when x"92"  => rdata <= sysctrl_bbtop_rst_r;
                            when x"D0"  => rdata <= sysctrl_pim_rst_r;
                            when others => rdata <= (others => '0');
                        end case;
                    when x"02" =>
                        case addrl8b is
                            when x"00"  => rdata <= sysctrl_vss_rst_flag;
                            when x"01"  => rdata <= sysctrl_vss_rst_sts;
                            when x"02"  => rdata <= sysctrl_vss_rst_ctrl_r;
                            when x"04"  => rdata <= sysctrl_func_fail_flag_r;
                            when x"05"  => rdata <= sysctrl_func_fail_sts_r;
                            when x"06"  => rdata <= sysctrl_clk_fail_flag_r;
                            when x"07"  => rdata <= sysctrl_clk_fail_sts_r;
                            when x"10"  => rdata <= lock_sts_1588_r;
                            when x"20"  => rdata <= dl_fsync_err_f;
                            when x"21"  => rdata <= dl_fsync_err_s;
                            when x"22"  => rdata <= ul_fsync_err_f;
                            when x"23"  => rdata <= ul_fsync_err_s;
                            when x"28"  => rdata <= x"00" & "00" & DL_FSYNC_CNT_0;
                            when x"29"  => rdata <= x"00" & "00" & DL_FSYNC_CNT_1;
                            when x"2A"  => rdata <= x"00" & "00" & DL_FSYNC_CNT_2;
                            when x"2B"  => rdata <= x"00" & "00" & DL_FSYNC_CNT_3;
                            when x"2C"  => rdata <= x"00" & "00" & UL_FSYNC_CNT_0;
                            when x"2D"  => rdata <= x"00" & "00" & UL_FSYNC_CNT_1;
                            when x"2E"  => rdata <= x"00" & "00" & UL_FSYNC_CNT_2;
                            when x"30"  => rdata <= tp_con_sel_r;
                            when x"40"  => rdata <= dl_sync_advance_r;
                            when x"41"  => rdata <= ul_sync_retard_r;
                            when x"60"  => rdata <= n_ta_offset_r;
                            when others => rdata <= (others => '0');
                        end case;
                    when x"03" =>
                        case addrl8b is
                            when x"00"  => rdata <= sysctrl_led_ctrl_r;
                            when x"04"  => rdata <= sysctrl_hw_wdt_ctrl_r;
                            when x"20"  => rdata <= sysctrl_pa_enb_r;
                            when others => rdata <= (others => '0');
                        end case;

                    when x"05" =>
                        case addrl8b is
                            when x"80"  => rdata <= nr_ssb_period_r;
                            when x"81"  => rdata <= nr_ssb_offset_r;
                            when x"82"  => rdata <= x"000000" & BFN_MORNITOR & bfn_ctrl_r(3 downto 0);
                            when others => rdata <= (others => '0');
                        end case;
                    when others => rdata <= (others => '0');
                end case;
            else
                rdata <= (others => '0');
            end if;
        end if;
    end process;

end ARC_CPUIF_OTHERS;
