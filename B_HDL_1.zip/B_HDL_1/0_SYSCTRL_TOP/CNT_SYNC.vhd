library IEEE;
use IEEE.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
USE ieee.numeric_std.ALL;
use work.RU_FPGA_FNC.all;

entity CNT_SYNC is
    generic (
        CNT_10MS_VALUE              : natural:= 1228800
    );
    port(
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        SYNC_IN_1                   : in  std_logic;
        SYNC_IN_2                   : in  std_logic;
        SYNC_CNT                    : out std_logic_vector(log2(CNT_10MS_VALUE)-1 downto 0)
    );
end CNT_SYNC;

architecture behave of CNT_SYNC is

    signal sync_d1                  : std_logic;
    signal sync_d2                  : std_logic;
    signal sync_cnt_r               : std_logic_vector(log2(CNT_10MS_VALUE)-1 downto 0);

begin

    process(RESET, CLK)
    begin
        if RESET = '1' then
            sync_d1 <= '0';
            sync_d2 <= '0';
        elsif rising_edge(CLK) then
            sync_d1 <= SYNC_IN_1;
            sync_d2 <= SYNC_IN_2;
        end if;
    end process;

    process(RESET, CLK)
    begin
        if RESET = '1' then
            sync_cnt_r  <= (others => '0');
        elsif rising_edge(CLK) then
            if (sync_cnt_r = CNT_10MS_VALUE - 1) or (sync_d1 = '0' and SYNC_IN_1 = '1') then
                sync_cnt_r  <= (others => '0');
            else
                sync_cnt_r  <= sync_cnt_r + 1;
            end if;
        end if;
    end process;

    process(RESET, CLK)
    begin
        if RESET = '1' then
            SYNC_CNT  <= (others => '0');
        elsif rising_edge(CLK) then
            if sync_d2 = '0' and SYNC_IN_2 = '1' then
                SYNC_CNT  <= sync_cnt_r;
            end if;
        end if;
    end process;


end behave;
