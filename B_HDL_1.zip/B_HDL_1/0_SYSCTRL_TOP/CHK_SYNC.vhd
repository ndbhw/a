library IEEE;
use IEEE.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
USE ieee.numeric_std.ALL;
use work.RU_FPGA_FNC.all;

entity CHK_SYNC is
    generic (
        INTERVAL                    : natural:= 80
    );
    port(
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        SYNC                        : in  std_logic;
        SYNC_ERR                    : out std_logic
    );
end CHK_SYNC;

architecture behave of CHK_SYNC is

    signal sync_d                   : std_logic;
    signal sync_cnt                 : std_logic_vector(log2(INTERVAL)-1 downto 0);

begin

    process(RESET, CLK)
    begin
        if RESET = '1' then
            sync_d  <= '0';
        elsif rising_edge(CLK) then
            sync_d  <= SYNC;
        end if;
    end process;

    process(RESET, CLK)
    begin
        if RESET = '1' then
            sync_cnt  <= (others => '0');
        elsif rising_edge(CLK) then
            if (sync_cnt = INTERVAL - 1) or (sync_d = '0' and SYNC = '1') then
                sync_cnt  <= (others => '0');
            else
                sync_cnt  <= sync_cnt + 1;
            end if;
        end if;
    end process;

    process(RESET, CLK)
    begin
        if RESET = '1' then
            SYNC_ERR  <= '1';
        elsif rising_edge(CLK) then
            if sync_d = '0' and SYNC = '1' then
                if (sync_cnt = INTERVAL - 1)then
                    SYNC_ERR  <= '0';
                else
                    SYNC_ERR  <= '1';
                end if;
            elsif (sync_cnt = INTERVAL - 1) then
                if SYNC = '1' then
                    SYNC_ERR  <= '0';
                else
                    SYNC_ERR  <= '1';
                end if;
            end if;
        end if;
    end process;

end behave;
