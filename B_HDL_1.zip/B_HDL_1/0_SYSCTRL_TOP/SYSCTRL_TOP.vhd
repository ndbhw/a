----------------------------------------------------------------------------------
-- Company: SEC
-- Engineer:
--
-- Create Date: 2016-09-26 AM 9:52:19
-- Design Name: jinoo.bae
-- Module Name: SYSCTRL_TOP - Behavioral
-- Project Name: FD-MIMO
-- Target Devices: ZYNQ035_2LI
-- Tool versions: vivado20162
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

library UNISIM;
use UNISIM.VCOMPONENTS.ALL;

entity SYSCTRL_TOP is
port (
    ----------------------------------------------------------------------
    ----  External System PLL
    ----------------------------------------------------------------------
    FPGA_ID                 : in std_logic_vector(1 downto 0);
    PCB_VER                 : in std_logic_vector(3 downto 0);

    ----------------------------------------------------------------------
    ----  External System PLL
    ----------------------------------------------------------------------
    EXT_SYSPLL_LOCK_IN      : in std_logic_vector(2 downto 0);
    EXT_SYSPLL_LOS_IN       : in std_logic;
    EXT_SYSCLK_IN           : in std_logic;
    MGT_REFCLK0_IN          : in std_logic; -- ORAN
    MGT_REFCLK1_IN          : in std_logic; -- CPRI
    MGT_REFCLK2_IN          : in std_logic; -- JESD

    ----------------------------------------------------------------------
    --  CPU_TOP
    ----------------------------------------------------------------------
    CLK_CPUIF               : in std_logic;
    RST_CPUIF               : in std_logic;
    EMIO_GPIO               : in std_logic;
    EMIO_WDT1               : in std_logic;

    ----------------------------------------------------------------------
    --  CPUIF_TOP
    ----------------------------------------------------------------------
    ADDR_CPUIF_SYSCTRL_IN   : in  std_logic_vector(15 downto 0);
    WDATA_CPUIF_SYSCTRL_IN  : in  std_logic_vector(31 downto 0);
    RDATA_CPUIF_SYSCTRL_OUT : out std_logic_vector(31 downto 0);
    WREN_CPUIF_SYSCTRL_IN   : in  std_logic;
    RDEN_CPUIF_SYSCTRL_IN   : in  std_logic;
    RDVAL_CPUIF_SYSCTRL_OUT : out std_logic;


    --------------------------------------------------------------------------------
    -- Clock
    --------------------------------------------------------------------------------
    INT_SYSPLL_LOCK_OUT     : out std_logic;
    LOCK_1588               : out std_logic;
        
    CLK_SYS                 : out std_logic; -- 30.72  MHz
    CLK_SYSX2               : out std_logic; -- 61.44  MHz
    CLK_SYSX3               : out std_logic; -- 92.16  MHz
    CLK_SYSX4               : out std_logic; -- 122.88 MHz
    CLK_SYSX5               : out std_logic; -- 153.6  MHz
    CLK_SYSX6               : out std_logic; -- 184.32 MHz
    CLK_SYSX8               : out std_logic; -- 245.76 MHz
    CLK_SYSX10              : out std_logic; -- 307.2  MHz
    CLK_SYSX12              : out std_logic; -- 368.64 MHz
    CLK_SYSX16              : out std_logic; -- 491.52 MHz
    CLK_SYSX20              : out std_logic; -- 614.4  MHz

    --------------------------------------------------------------------------------
    -- TCXO Clock
    --------------------------------------------------------------------------------
    TCXO_OUT_PLL            : in  std_logic;
    REF_CLK_OUT             : out std_logic;
     
    --------------------------------------------------------------------------------
    -- ORAN_TOP
    --------------------------------------------------------------------------------
    RST_ORAN_L0_RX          : out std_logic_vector(NUM_ORAN-1 downto 0);
    RST_ORAN_L0_TX          : out std_logic_vector(NUM_ORAN-1 downto 0);
		
		RX_BFN_STRB_IN      : in  std_logic_vector(NUM_ORAN - 1 downto 0);
        RX_BFN_NR_IN        : in  std_logic_array12(NUM_ORAN - 1 downto 0);
        TX_BFN_STRB_OUT     : out std_logic_vector(NUM_ORAN - 1 downto 0);
        TX_BFN_NR_OUT       : out std_logic_array12(NUM_ORAN - 1 downto 0);
        RX_BFN_STRB_OUT     : out std_logic_vector( NUM_ORAN-1 downto 0);
        RX_BFN_NR_OUT       : out std_logic_array12(NUM_ORAN - 1 downto 0);
        
    --------------------------------------------------------------------------------
    -- LPHY_TOP
    --------------------------------------------------------------------------------
    RST_BBTOP               : out std_logic;
    RST_DLFE                : out std_logic;
    RST_ULFE                : out std_logic;
    RST_RAFE                : out std_logic;

    ----------------------------------------------------------------------
    --  DSP_TOP
    ----------------------------------------------------------------------
    RST_BBCTRL              : out std_logic;
    RST_DDUC                : out std_logic;
    RST_CFR                 : out std_logic;
    RST_DPD                 : out std_logic;

    ----------------------------------------------------------------------
    --  DCIP_TOP
    ----------------------------------------------------------------------
    RST_DCIF                : out std_logic;
    REFCLK_JSERDES_OUT      : out std_logic_vector(JSREF_NUM - 1 downto 0);

    ----------------------------------------------------------------------
    --  MISC_TOP
    ----------------------------------------------------------------------
    WATCHDOG_CLR            : in  std_logic;
    HWWDT_FLAG_OUT          : out std_logic;
    SWWDT_FLAG_OUT          : out std_logic;
    LED_CTRL_OUT            : out std_logic_array5(LED_NUM - 1 downto 0); -- don't used in verizon
    FUNC_FAIL_TRIG_IN       : in  std_logic_vector(1 downto 0);
    VSS_RMT_RST_OUT         : out std_logic;
    OOK_CLK                 : out std_logic; -- 8.704
    RST_MISC                : out std_logic;
    
    --------------------------------------------------------------------------------
    -- Frame Signal
    --------------------------------------------------------------------------------
    DL_FS_1PPS              : in  std_logic;
    DL_FS_DLFE              : in  std_logic;
    DL_FS_BBTOP             : in  std_logic;
    DL_FS_BBCTRL            : in  std_logic;
    DL_FS_DSP               : in  std_logic;

    UL_FS_MISC              : in  std_logic;
    UL_FS_DCIF              : in  std_logic;
    UL_FS_DSP               : in  std_logic;
    UL_FS_BBCTRL            : in  std_logic;
    UL_FS_RAFE              : in  std_logic;

    DL_SYNC_ADVANCE         : out std_logic_vector(21 downto 0);
    UL_SYNC_RETARD          : out std_logic_vector(21 downto 0);
    N_TA_OFFSET             : out std_logic_vector(15 downto 0);

    TP_CON_SEL              : out std_logic_vector(7 downto 0);
    MUX_SEL                 : out std_logic_vector(1 downto 0);

	NR_SSB_PERIOD : out std_logic_vector( 4 downto 0);
    NR_SSB_OFFSET : out std_logic_vector( 3 downto 0);

    --------------------------------------------------------------------------------
    -- DUMP_TOP
    --------------------------------------------------------------------------------
    RST_DUMP                : out std_logic
);
END SYSCTRL_TOP;

ARCHITECTURE SYSCTRL_TOP_ARC of SYSCTRL_TOP IS


    component BUFGCE
        port(
            O  : out std_ulogic;
            CE : in  std_ulogic;
            I  : in  std_ulogic
        );
    end component;

    component DATA_PLL
    port
     (-- Clock in ports
      -- Clock out ports
      clk_out1          : out    std_logic; -- 122.88 Mhz
      clk_out2          : out    std_logic; -- 245.76 Mhz
      clk_out3          : out    std_logic; -- 153.60 Mhz
      clk_out4          : out    std_logic; -- 307.20 Mhz
      -- Status and control signals
      reset             : in     std_logic;
      locked            : out    std_logic;
      clk_in1           : in     std_logic
     );
    end component;


    component CLK_OOK is
        port
        (-- Clock in ports
            CLK_IN1 : in std_logic;
            -- Clock out ports
            CLK_OUT1 : out std_logic;
            -- Status and control signals
            RESET  : in  std_logic;
            LOCKED : out std_logic
        );
    end component;

    component RST_SYNC
        generic (
            DLY_NUM        : natural := 4;  -- Number of delay.
            MAX_FANOUT_NUM : integer := 200 -- Number of maximum fanout
        );
        port (
            RST_IN  : in  std_logic; -- Active high asynchronous reset
            CLK     : in  std_logic; -- clock to be sync'ed to
            RST_OUT : out std_logic  -- "Synchronised" reset signal
        );
    end component;

    component GLBFS
        port (
            RESET    : in std_logic;
            PLL_LOCK : in std_logic; -- sys_pll lock
            CLK      : in std_logic; -- sys_hclk,122.88MHz
            BFN_STRB : in std_logic;
            BFN_NR   : in std_logic_vector(11 downto 0);

            BFN_FAIL    : out std_logic;
            BFN_NR_FAIL : out std_logic;

            T80MS        : out std_logic; -- active high
            T10MS        : out std_logic; -- active high
            BFN_STRB_OUT : out std_logic; -- active high
            BFN_NR_OUT   : out std_logic_vector(11 downto 0)
        );
    end component;

    component CHK_SYNC is
    generic (
        Interval                    : natural := 80
    );
    port(
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;                            -- 153.6 MHz

        SYNC                        : in  std_logic;
        SYNC_ERR                    : out std_logic
    );
    end component;

    component WATCHDOG is
        port(
            RESET : in std_logic; -- Synchronous Reset
            CLK   : in std_logic; -- 100MHz Clock

            WATCHDOG_EN   : in  std_logic;                     -- Async. Watchdog Enable
            WATCHDOG_CLR  : in  std_logic;                     -- Async. Watchdog Clear
            WDT_TIMER_SEC : in  std_logic_vector(15 downto 0); -- Watchdog timer (unit : second)
            CPU_FAIL      : out std_logic
        );
    end component;
    
    component CNT_SYNC is
    generic (
        CNT_10MS_VALUE              : natural:= 1228799
    );
    port(
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        SYNC_IN_1                   : in  std_logic;
        SYNC_IN_2                   : in  std_logic;
        SYNC_CNT                    : out std_logic_vector(log2(CNT_10MS_VALUE)-1 downto 0)
    );
    end component;

    component CPUIF_SYSCTRL is
    generic(
        LED_NUM                : natural                       := 4;
        TX_ANT_NUM             : natural                       := 8;
        CSREF_NUM              : natural                       := 6;
        JSREF_NUM              : natural                       := 6;
        SSREF_NUM              : natural                       := 6;
        C_SYSCTRL_IMG_DATE     : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"2024_0822";
        C_SYSCTRL_IMG_VER      : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0000_0001";
        C_SYSCTRL_SYSTEM_INFO0 : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0000_0000"; -- air_tech[3:0]
        C_SYSCTRL_SYSTEM_INFO1 : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0000_0000"; -- freq_band[7:0]
        C_SYSCTRL_SYSTEM_INFO2 : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0000_0000"; -- freq_band[7:0]
            C_SYSCTRL_SYSTEM_INFO3 : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0232_3206"; -- fb_path_num, rx_ant_num, tx_ant_num,cpri_num
        C_SYSCTRL_PBA_INFO     : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0000_0000";
        C_SYSCTRL_DEV_INFO     : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0000_0000";
        C_SYSCTRL_MODULE_INFO  : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"0000_0001";
        C_SYSCTRL_MODULE_DATE  : STD_LOGIC_VECTOR(31 DOWNTO 0) := X"2024_0822"
    );
    port(
        FPGA_ID                 : in std_logic_vector(1 downto 0);
        PCB_VER                 : in std_logic_vector(3 downto 0);
                
        CLK_CPUIF               : in std_logic;
        RST_CPUIF               : in std_logic;

        ADDR_CPUIF_SYSCTRL      : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_SYSCTRL     : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_SYSCTRL     : out std_logic_vector(31 downto 0);
        WREN_CPUIF_SYSCTRL      : in  std_logic;
        RDEN_CPUIF_SYSCTRL      : in  std_logic;
        RDVAL_CPUIF_SYSCTRL     : out std_logic;
    
        SYSCTRL_IPLL_RST        : out std_logic_vector(2 downto 0);
        SYSCTRL_ORAN_RX_RST     : out std_logic_vector(NUM_ORAN-1 downto 0);
        SYSCTRL_ORAN_TX_RST     : out std_logic_vector(NUM_ORAN-1 downto 0);
        SYSCTRL_BBTOP_RST       : out std_logic;
        SYSCTRL_DLFE_RST        : out std_logic;
        SYSCTRL_ULFE_RST        : out std_logic;
        SYSCTRL_RAFE_RST        : out std_logic;
        SYSCTRL_BBCTRL_RST      : out std_logic;
        SYSCTRL_DDUC_RST        : out std_logic;
        SYSCTRL_CFR_RST         : out std_logic;
        SYSCTRL_DPD_RST         : out std_logic;
        SYSCTRL_DCIF_RST        : out std_logic;
        SYSCTRL_MISC_RST        : out std_logic;
        SYSCTRL_DUMP_RST        : out std_logic;

        SYSCTRL_FUNC_FAIL_TRIG  : in  std_logic_vector(1 downto 0); -- need to check
        SYSCTRL_CLK_FAIL_TRIG   : in  std_logic_vector(31 downto 0);
        LOCK_1588               : out std_logic;
        SYSCTRL_LED_CTRL        : out std_logic_array5(LED_NUM -1 downto 0);
        SYSCTRL_HW_WDT_CTRL     : out std_logic_vector(31 downto 0);
        SYSCTRL_RUID            : out std_logic_vector(3 downto 0);
        SYSCTRL_RU_FF           : out std_logic;
        
        NR_SSB_PERIOD : out std_logic_vector(4 downto 0);
        NR_SSB_OFFSET : out std_logic_vector(3 downto 0);
        
        BFN_CTRL      : out std_logic;
        BFN_MORNITOR  : in  std_logic_vector(3 downto 0);
            
        DL_FSYNC_ERR            : in  std_logic_vector(4 downto 0);
        DL_FSYNC_CNT_0          : in  std_logic_vector(21 downto 0);
        DL_FSYNC_CNT_1          : in  std_logic_vector(21 downto 0);
        DL_FSYNC_CNT_2          : in  std_logic_vector(21 downto 0);
        DL_FSYNC_CNT_3          : in  std_logic_vector(21 downto 0);

        UL_FSYNC_ERR            : in  std_logic_vector(4 downto 0);
        UL_FSYNC_CNT_0          : in  std_logic_vector(21 downto 0);
        UL_FSYNC_CNT_1          : in  std_logic_vector(21 downto 0);
        UL_FSYNC_CNT_2          : in  std_logic_vector(21 downto 0);

        DL_SYNC_ADVANCE         : out std_logic_vector(21 downto 0);
        UL_SYNC_RETARD          : out std_logic_vector(21 downto 0);
        N_TA_OFFSET             : out std_logic_vector(15 downto 0);

        TP_CON_SEL              : out std_logic_vector(7 downto 0);
        MUX_SEL                 : out std_logic_vector(1 downto 0)
    );
    end component;


    --------------------------------------------------------------------------------
    -- Signal Declaration
    --------------------------------------------------------------------------------
    signal internal_pll_rst        : std_logic_vector(2 downto 0);
    signal clk_122p88m             : std_logic;
    signal clk_245p76m             : std_logic;
    signal clk_153p60m             : std_logic;
    signal clk_307p20m             : std_logic;
    signal data_pll_locked         : std_logic;
    signal clk_8p704m              : std_logic;
    signal ook_pll_locked          : std_logic;
    signal cpuif_245p76_sync_reset : std_logic;
    signal clk_fail_r              : std_logic_vector(31 downto 0) := x"0000_0000";
    signal rx_bfn_strobe           : std_logic_vector(CPRI_NUM - 1 downto 0);
    signal rx_bfn_nr               : std_logic_array12(CPRI_NUM - 1 downto 0);
    signal hwwdt_flag_r            : std_logic_vector(31 downto 0);
    signal free_run_bfn            : std_logic_vector(11 downto 0) := (others => '0');
    signal free_run_bfn_r          : std_logic_vector(11 downto 0) := (others => '0');
    signal rx_bfn_strobe_d1        : std_logic;
    signal bfn_ctrl_r              : std_logic;
    signal hwwdt_flag_out_w        : std_logic;
    signal sw_wdt_r                : std_logic;
    signal emio_r                  : std_logic;
    
    signal rst_bbtop_r             : std_logic;
    
    signal dl_fsync_err             : std_logic_vector(4 downto 0);
    signal ul_fsync_err             : std_logic_vector(4 downto 0);

    signal cnt_dl_fsync_0           : std_logic_vector(21 downto 0);
    signal cnt_dl_fsync_1           : std_logic_vector(21 downto 0);
    signal cnt_dl_fsync_2           : std_logic_vector(21 downto 0);
    signal cnt_dl_fsync_3           : std_logic_vector(21 downto 0);

    signal cnt_ul_fsync_0           : std_logic_vector(21 downto 0);
    signal cnt_ul_fsync_1           : std_logic_vector(21 downto 0);
    signal cnt_ul_fsync_2           : std_logic_vector(21 downto 0);

BEGIN


    ----------------------------------------------------------------------------
    -- Port Mapping
    ----------------------------------------------------------------------------
    CLK_SYS                 <= '0';         -- 30.72  MHz
    CLK_SYSX2               <= '0';         -- 61.44  MHz
    CLK_SYSX3               <= '0';         -- 92.16  MHz
    CLK_SYSX4               <= clk_122p88m; -- 122.88 MHz
    CLK_SYSX5               <= clk_153p60m; -- 153.6  MHz
    CLK_SYSX6               <= '0';         -- 184.32 MHz
    CLK_SYSX8               <= clk_245p76m; -- 245.76 MHz
    CLK_SYSX10              <= clk_307p20m; -- 307.2  MHz
    CLK_SYSX12              <= '0';         -- 368.64 MHz
    CLK_SYSX16              <= '0';         -- 491.52 MHz
    CLK_SYSX20              <= '0';         -- 614.4  MHz
    OOK_CLK                 <= clk_8p704m;
    INT_SYSPLL_LOCK_OUT     <= (data_pll_locked and ook_pll_locked);

    U_REFCLK_JSERDES_ASSIGN : for I in 0 to (JSREF_NUM - 1) generate --JESD
        REFCLK_JSERDES_OUT(I) <= MGT_REFCLK2_IN;
    end generate;
    
----------------------------------------------------------------------------------
----  Check Sync
----------------------------------------------------------------------------------
--
    u_CHK_DL_FS_0 : CHK_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, DL_FS_1PPS,    dl_fsync_err(0));
    u_CHK_DL_FS_1 : CHK_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, DL_FS_DLFE,    dl_fsync_err(1));
    u_CHK_DL_FS_2 : CHK_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, DL_FS_BBTOP,   dl_fsync_err(2));
    u_CHK_DL_FS_3 : CHK_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, DL_FS_BBCTRL,  dl_fsync_err(3));
    u_CHK_DL_FS_4 : CHK_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, DL_FS_DSP,     dl_fsync_err(4));

    u_CNT_DL_FS_0 : CNT_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, DL_FS_1PPS,    DL_FS_DLFE,   cnt_dl_fsync_0);
    u_CNT_DL_FS_1 : CNT_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, DL_FS_DLFE,    DL_FS_BBTOP,  cnt_dl_fsync_1);
    u_CNT_DL_FS_2 : CNT_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, DL_FS_BBTOP,   DL_FS_BBCTRL, cnt_dl_fsync_2);
    u_CNT_DL_FS_3 : CNT_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, DL_FS_BBCTRL,  DL_FS_DSP,    cnt_dl_fsync_3);

    u_CHK_UL_FS_0 : CHK_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, UL_FS_MISC,    ul_fsync_err(0));
    u_CHK_UL_FS_1 : CHK_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, UL_FS_DCIF,    ul_fsync_err(1));
    u_CHK_UL_FS_2 : CHK_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, UL_FS_DSP,     ul_fsync_err(2));
    u_CHK_UL_FS_3 : CHK_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, UL_FS_BBCTRL,  ul_fsync_err(3));
    u_CHK_UL_FS_4 : CHK_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, UL_FS_RAFE,    ul_fsync_err(4));

    u_CNT_UL_FS_0 : CNT_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, UL_FS_MISC,    UL_FS_DCIF,   cnt_ul_fsync_0);
    u_CNT_UL_FS_1 : CNT_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, UL_FS_DCIF,    UL_FS_DSP,    cnt_ul_fsync_1);
    u_CNT_UL_FS_2 : CNT_SYNC generic map(2457600) port map(rst_bbtop_r, clk_245p76m, UL_FS_DSP,     UL_FS_BBCTRL, cnt_ul_fsync_2);


    U_CPRI_BFN_ASSIGN : for I in 0 to (CPRI_NUM - 1) generate
        TX_BFN_STRB_OUT(I) <= rx_bfn_strobe(I) when bfn_ctrl_r = '0' else rx_bfn_strobe_d1; -- need to check
        RX_BFN_STRB_OUT(I) <= rx_bfn_strobe(I) when bfn_ctrl_r = '0' else rx_bfn_strobe_d1;
        TX_BFN_NR_OUT(I)   <= rx_bfn_nr(I) when bfn_ctrl_r = '0' else free_run_bfn; -- need to check
        RX_BFN_NR_OUT(I)   <= rx_bfn_nr(I) when bfn_ctrl_r = '0' else free_run_bfn;
    end generate;
    ----------------------------------------------------------------------------
    -- Instance Mapping
    ----------------------------------------------------------------------------

    U_TRAFFIC_CLK_GEN : DATA_PLL
    port map (
        clk_in1  => EXT_SYSCLK_IN ,       --: in  std_logic;    -- 122.88 Mhz
        clk_out1 => clk_122p88m ,         --: out std_logic;    -- 245.76 Mhz
        clk_out2 => clk_245p76m ,         --: out std_logic;    -- 153.60 Mhz
        clk_out3 => clk_153p60m ,         --: out std_logic;    -- 307.20 Mhz
        clk_out4 => clk_307p20m ,         --: out    std_logic;

        reset    => internal_pll_rst(0) , --: in  std_logic;
        locked   => data_pll_locked       --: out std_logic
    );


    U_OOK_CLK_GEN : CLK_OOK
    port map (
        -- Clock in ports
        CLK_IN1 => EXT_SYSCLK_IN ,      -- : in  std_logic;
                                        -- Clock out ports
        CLK_OUT1 => clk_8p704m ,        -- : out std_logic;
                                        -- Status and control signals
        RESET  => internal_pll_rst(0) , -- : in  std_logic;
        LOCKED => ook_pll_locked        -- : out std_logic
    );

    U_OCXO_30P72_CLK : BUFGCE
    port map (
        O  => REF_CLK_OUT,
        CE => '1' ,
        I  => TCXO_OUT_PLL
    );


    U_PS_RST_SYNC_245P76M : RST_SYNC
        generic map(
            DLY_NUM        => 4 , --: natural := 4;
            MAX_FANOUT_NUM => 200
        )
        port map(
            RST_IN  => RST_CPUIF,
            CLK     => clk_245p76m,--_bufg,
            RST_OUT => cpuif_245p76_sync_reset
        );


    U_CPRI_BFN_FREE_GEN : for I in 0 to (CPRI_NUM - 1) generate
        U_CPRI_BFN_RESYNC_GEN : GLBFS
            port map(
                RESET    => cpuif_245p76_sync_reset, -- : in std_logic;
                PLL_LOCK => data_pll_locked,         -- : in std_logic;
                CLK      => clk_245p76m,             --_bufg,                -- : in std_logic;
                BFN_STRB => RX_BFN_STRB_IN(I),       -- : in std_logic;
                BFN_NR   => RX_BFN_NR_IN(I),         -- : in std_logic_vector(11 downto 0);

                BFN_FAIL    => open, -- : out std_logic;
                BFN_NR_FAIL => open, -- : out std_logic;

                T80MS        => open,             -- : out std_logic; -- active high
                T10MS        => open,             -- : out std_logic; -- active high
                BFN_STRB_OUT => rx_bfn_strobe(I), -- : out std_logic; -- active high
                BFN_NR_OUT   => rx_bfn_nr(I)      -- : out std_logic_vector(11 downto 0)
            );

    end generate;

    -- delay
    process (clk_245p76m)
    begin
        if (clk_245p76m'event and clk_245p76m = '1') then
            rx_bfn_strobe_d1 <= rx_bfn_strobe(0);
        end if;
    end process;

    -- bfn free running
    process (cpuif_245p76_sync_reset, clk_245p76m)
    begin
        if (cpuif_245p76_sync_reset = '1') then
            free_run_bfn <= (others => '0');
        elsif (clk_245p76m'event and clk_245p76m = '1') then
            if ((rx_bfn_strobe(0) and (not rx_bfn_strobe_d1)) = '1') then
                if (free_run_bfn = 4095) then
                    free_run_bfn <= (others => '0');
                else
                    free_run_bfn <= free_run_bfn + 1;
                end if;
            end if;
        end if;
    end process;


    -- SW Watchdog Signal Extension
    process(RST_CPUIF, CLK_CPUIF)
    begin
        if (RST_CPUIF = '1') then
            emio_r <= '0';
            sw_wdt_r <= '0';
        elsif (CLK_CPUIF = '1' and CLK_CPUIF'event) then
            if (EMIO_GPIO = '1') then
                emio_r <= '1';
            else
                emio_r <= emio_r;
            end if;

            if (EMIO_WDT1 = '1') then
                sw_wdt_r <= '1';
            else
                sw_wdt_r <= sw_wdt_r;
            end if;
        end if;
    end process;

    U_WATCHDOG : WATCHDOG
    port map(
        RESET => RST_CPUIF , --: in  std_logic;                        -- Synchronous Reset
        CLK   => CLK_CPUIF , --: in  std_logic;                        -- 100MHz Clock

        WATCHDOG_EN   => hwwdt_flag_r(16) ,          --: in  std_logic;                        -- Async. Watchdog Enable
        WATCHDOG_CLR  => WATCHDOG_CLR ,              --: in  std_logic;                        -- Async. Watchdog Clear
        WDT_TIMER_SEC => hwwdt_flag_r(15 downto 0) , --: in  std_logic_vector(15 downto 0);    -- Watchdog timer (unit : second)
        CPU_FAIL      => hwwdt_flag_out_w            --: out std_logic
    );

    HWWDT_FLAG_OUT <= hwwdt_flag_out_w;
    SWWDT_FLAG_OUT <= sw_wdt_r or emio_r;

    clk_fail_r(3 downto 0)   <= '0' & (not EXT_SYSPLL_LOCK_IN);                      -- external PLL unlock
    clk_fail_r(11 downto 8)  <= "000" & EXT_SYSPLL_LOS_IN;                           -- external LOS    -- in B13 zeor
    clk_fail_r(19 downto 16) <= "00" & (not ook_pll_locked) & (not data_pll_locked); -- internal PLL unlock
    clk_fail_r(27 downto 24) <= x"0";                                                -- internal LOS

    U_CPUIF_SYSCTRL : CPUIF_SYSCTRL
    generic map(
        LED_NUM                => LED_NUM ,                --: natural:= 4;
        TX_ANT_NUM             => TX_ANT_NUM ,             --: natural:= 8;
        CSREF_NUM              => CSREF_NUM ,              --: natural:= 6;
        JSREF_NUM              => JSREF_NUM ,              --: natural:= 6;
        SSREF_NUM              => SSREF_NUM ,              --: natural:= 6;
        C_SYSCTRL_IMG_DATE     => C_SYSCTRL_IMG_DATE ,     --: STD_LOGIC_VECTOR(31 DOWNTO 0):= X"2016_1010";
        C_SYSCTRL_IMG_VER      => C_SYSCTRL_IMG_VER ,      --: STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0000_0001";
        C_SYSCTRL_SYSTEM_INFO0 => C_SYSCTRL_SYSTEM_INFO0 , --: STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0000_0002";     -- air_tech[3:0]
        C_SYSCTRL_SYSTEM_INFO1 => C_SYSCTRL_SYSTEM_INFO1 , --: STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0000_0000";     -- freq_band[7:0]
        C_SYSCTRL_SYSTEM_INFO2 => C_SYSCTRL_SYSTEM_INFO2 , --: STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0000_0000";     -- freq_band[7:0]
        C_SYSCTRL_SYSTEM_INFO3 => C_SYSCTRL_SYSTEM_INFO3 , --: STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0232_3206";     -- fb_path_num, rx_ant_num, tx_ant_num,cpri_num
        C_SYSCTRL_PBA_INFO     => C_SYSCTRL_PBA_INFO ,     --: STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0000_0000";
        C_SYSCTRL_DEV_INFO     => C_SYSCTRL_DEV_INFO ,     --: STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0000_0000";
        C_SYSCTRL_MODULE_INFO  => C_SYSCTRL_MODULE_INFO ,  --: STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0000_0001";
        C_SYSCTRL_MODULE_DATE  => C_SYSCTRL_MODULE_DATE    --: STD_LOGIC_VECTOR(31 DOWNTO 0):= X"2016_1010"
    )
    port map(
        FPGA_ID                 => FPGA_ID ,--: in  std_logic_vector(1 downto 0);
        PCB_VER                 => PCB_VER ,
                        
                        
        CLK_CPUIF               => CLK_CPUIF , --: in  std_logic;
        RST_CPUIF               => RST_CPUIF , --: in  std_logic;

        ADDR_CPUIF_SYSCTRL      => ADDR_CPUIF_SYSCTRL_IN ,   --: in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_SYSCTRL     => WDATA_CPUIF_SYSCTRL_IN ,  --: in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_SYSCTRL     => RDATA_CPUIF_SYSCTRL_OUT , --: out std_logic_vector(31 downto 0);
        WREN_CPUIF_SYSCTRL      => WREN_CPUIF_SYSCTRL_IN ,   --: in  std_logic;
        RDEN_CPUIF_SYSCTRL      => RDEN_CPUIF_SYSCTRL_IN ,   --: in  std_logic;
        RDVAL_CPUIF_SYSCTRL     => RDVAL_CPUIF_SYSCTRL_OUT , --: out std_logic;
        SYSCTRL_IPLL_RST        => internal_pll_rst , --: out std_logic_vector(1 downto 0);
        SYSCTRL_ORAN_RX_RST     => RST_ORAN_L0_RX,    --: out std_logic;
        SYSCTRL_ORAN_TX_RST     => RST_ORAN_L0_TX,    --: out std_logic;
        SYSCTRL_BBTOP_RST       => rst_bbtop_r,       --: out std_logic;
        SYSCTRL_DLFE_RST        => RST_DLFE,          --: out std_logic;
        SYSCTRL_ULFE_RST        => RST_ULFE,          --: out std_logic;
        SYSCTRL_RAFE_RST        => RST_RAFE,          --: out std_logic;
        SYSCTRL_BBCTRL_RST      => RST_BBCTRL ,       --: out std_logic;
        SYSCTRL_DDUC_RST        => RST_DDUC ,         --: out std_logic;
        SYSCTRL_CFR_RST         => RST_CFR ,          --: out std_logic;
        SYSCTRL_DPD_RST         => RST_DPD ,          --: out std_logic;
        SYSCTRL_DCIF_RST        => RST_DCIF,          --: out std_logic;
        SYSCTRL_MISC_RST        => RST_MISC,          --: out std_logic;
        SYSCTRL_DUMP_RST        => RST_DUMP,

        DL_FSYNC_ERR            => dl_fsync_err                             ,--: in  std_logic_vector(4 downto 0);
        DL_FSYNC_CNT_0          => cnt_dl_fsync_0                           ,--: in  std_logic_vector(21 downto 0);
        DL_FSYNC_CNT_1          => cnt_dl_fsync_1                           ,--: in  std_logic_vector(21 downto 0);
        DL_FSYNC_CNT_2          => cnt_dl_fsync_2                           ,--: in  std_logic_vector(21 downto 0);
        DL_FSYNC_CNT_3          => cnt_dl_fsync_3                           ,--: in  std_logic_vector(21 downto 0);

        UL_FSYNC_ERR            => ul_fsync_err                             ,--: in  std_logic_vector(4 downto 0);
        UL_FSYNC_CNT_0          => cnt_ul_fsync_0                           ,--: in  std_logic_vector(21 downto 0);
        UL_FSYNC_CNT_1          => cnt_ul_fsync_1                           ,--: in  std_logic_vector(21 downto 0);
        UL_FSYNC_CNT_2          => cnt_ul_fsync_2                           ,--: in  std_logic_vector(21 downto 0);

        DL_SYNC_ADVANCE         => DL_SYNC_ADVANCE                          ,--: out std_logic_vector(21 downto 0);
        UL_SYNC_RETARD          => UL_SYNC_RETARD                           ,--: out std_logic_vector(21 downto 0);
        N_TA_OFFSET             => N_TA_OFFSET                              ,--: out std_logic_vector(15 downto 0);

        TP_CON_SEL              => TP_CON_SEL                               ,--: out std_logic_vector(7 downto 0);
        MUX_SEL                 => MUX_SEL                                  ,--: out std_logic_vector(1 downto 0);

        SYSCTRL_FUNC_FAIL_TRIG  => FUNC_FAIL_TRIG_IN ,   --: in  std_logic_vector(3 downto 0);   -- need to check
        SYSCTRL_CLK_FAIL_TRIG   => clk_fail_r ,          --: in  std_logic_vector(31 downto 0);
        LOCK_1588               => LOCK_1588,            --: out std_logic;   
        SYSCTRL_LED_CTRL        => LED_CTRL_OUT,         --: out std_logic_array4(LED_NUM -1 downto 0);   -- don't used in verizon
        SYSCTRL_HW_WDT_CTRL     => hwwdt_flag_r ,        --: out std_logic_vector(31 downto 0);
        
        NR_SSB_PERIOD           => NR_SSB_PERIOD , --: out std_logic;
        NR_SSB_OFFSET           => NR_SSB_OFFSET,  --: out std_logic_vector(3 downto 0)

        BFN_CTRL                => bfn_ctrl_r,-- : out std_logic;
        BFN_MORNITOR            => free_run_bfn(3 downto 0)-- : in  std_logic_vector(3 downto 0)
    );
    
    RST_BBTOP <= rst_bbtop_r;

END SYSCTRL_TOP_ARC;

