-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name : PWRMEAS_MANTISSA
-- Project    : CP10_42A, 3.5G KDDI Low power
-- Structure  : 
-- History    : 2015.08.11 - 1st release

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.ALL;
use work.RU_FPGA_FNC.ALL;

entity PWRMEAS_MANTISSA is
generic(
    DEVICE                      : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    CLK_DIV                     : natural :=  2; -- CLK_DIV = (Clock Rate)/(Data Rate)
    DATA_WIDTH                  : natural := 16  -- Data bit width
    );
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    
    FRAME_SYNC_IN               : in  std_logic; -- BFN 10ms strobe
    TDD_SIG_IN                  : in  std_logic; -- TDD strobe, DL : '1', UL : '0', when FDD mode, always set high

    DATA_I_IN                   : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    DATA_Q_IN                   : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    PWR_UPDATE_DONE_OUT         : out std_logic;
    PWR_OUT                     : out std_logic_vector(31 downto 0)
    );
end PWRMEAS_MANTISSA;

architecture arc_PWRMEAS_MANTISSA of PWRMEAS_MANTISSA is

component RST_SYNC is
generic(
    DLY_NUM                     : natural := 3;    -- Number of delay.
    MAX_FANOUT_NUM              : integer := 200   -- Number of maximum fanout
    );
port(
    RST_IN                      : in  std_logic;   -- Active high asynchronous reset
    CLK                         : in  std_logic;   -- clock to be sync'ed to
    RST_OUT                     : out std_logic    -- "Synchronised" reset signal
    );         
end component;

component DSP48E_MULT is
generic(
    DEVICE                      : string  := "ULTRASCALE";
    DSP48_MODECTRL              : boolean :=       FALSE ;
    DSP48_PREADDER_USE          : boolean :=        TRUE ;
    DSP48_PREADDER_MODE         : string  :=        "ADD";  -- "ADD" or "SUB" 
    DSP48_PCIN_USE              : boolean :=       FALSE ;
    DSP48_PCOUT_USE             : boolean :=       FALSE ;

    A_nREG                      : integer :=           2 ;  -- 0, 1, 2
    B_nREG                      : integer :=           2 ;  -- 0, 1, 2

    C_EN                        : boolean :=        TRUE ;
    RND_SYMMETRY                : boolean :=       FALSE 
    );
port(
    CLK                         : in  std_logic;

    ALUMODE_IN                  : in  std_logic_vector( 3 downto 0);
    OPMODE_IN                   : in  std_logic_vector( 8 downto 0);

    C_IN                        : in  std_logic_vector(47 downto 0);
    A_IN                        : in  std_logic_vector(29 downto 0);
    D_IN                        : in  std_logic_vector(26 downto 0);
    B_IN                        : in  std_logic_vector(17 downto 0);

    P_CIN                       : in  std_logic_vector(47 downto 0);
    P_COUT                      : out std_logic_vector(47 downto 0);

    P_OUT                       : out std_logic_vector(47 downto 0);
    CRRY_OUT                    : out std_logic
    );
end component;

component MANTISSA_FRAMER is
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    START_IN                    : in  std_logic;
    DATA_IN                     : in  std_logic_vector(63 downto 0);
    
    DONE_OUT                    : out std_logic;
    MANTISSA_OUT                : out std_logic_vector(31 downto 0)
    );
end component;

signal rst_synch                : std_logic;

signal data_i                   : std_logic_vector(DATA_WIDTH-1 downto 0);
signal data_q                   : std_logic_vector(DATA_WIDTH-1 downto 0);

signal fs_sh                    : std_logic_vector(2 downto 0);
signal fs_rpls                  : std_logic;

signal tdd_sig_sh               : std_logic_vector(3 downto 0);

signal clk_div_cnt              : std_logic_vector(log2(CLK_DIV) downto 0);
signal data_vld                 : std_logic;

signal sample_i                 : std_logic_vector(DATA_WIDTH-1 downto 0);
signal sample_q                 : std_logic_vector(DATA_WIDTH-1 downto 0);

signal se_i_a                   : std_logic_vector(29 downto 0);
signal se_i_b                   : std_logic_vector(17 downto 0);

signal se_q_a                   : std_logic_vector(29 downto 0);
signal se_q_b                   : std_logic_vector(17 downto 0);

signal sample_pwr_i             : std_logic_vector(47 downto 0); 
signal sample_pwr_q             : std_logic_vector(47 downto 0); 

signal se_sample_pwr_i          : std_logic_vector(22+2*DATA_WIDTH-1 downto 0); 
signal se_sample_pwr_q          : std_logic_vector(22+2*DATA_WIDTH-1 downto 0); 

signal pwr_accum_i              : std_logic_vector(22+2*DATA_WIDTH-1 downto 0); 
signal pwr_accum_q              : std_logic_vector(22+2*DATA_WIDTH-1 downto 0); 

signal tdd_accum_pwr            : std_logic_vector(22+2*DATA_WIDTH-1 downto 0);
signal update_done              : std_logic_vector(3 downto 0);

signal pre_conv_pwr             : std_logic_vector(63 downto 0);

signal conv_done                : std_logic;

signal pwr_meas_done            : std_logic;
signal conv_pwr                 : std_logic_vector(31 downto 0);

constant zero                   : std_logic_vector(21 downto 0):= (others => '0');
constant zero_conv              : std_logic_vector((42-2*DATA_WIDTH)-1 downto 0):= (others => '0'); 

begin

    U_RST_SYNC : RST_SYNC generic map(4, 200) port map(RST, CLK, rst_synch);

    P_Input_data_control : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            data_i <= DATA_I_IN;
            data_q <= DATA_Q_IN;
        end if;
    end process;

    P_Gen_frame_sync_rising_pulse : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            fs_sh      <= fs_sh(1 downto 0) & FRAME_SYNC_IN;
            fs_rpls    <= fs_sh(1) and (not fs_sh(2));
        end if;
    end process;

    P_TDD_signal_shift : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            tdd_sig_sh <= tdd_sig_sh(2 downto 0) & TDD_SIG_IN;
        end if;
    end process;

    P_CLK_Division_count : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (rst_synch = '1') then
                clk_div_cnt <= (others => '0');
            else
                if (fs_rpls = '1') then
                    clk_div_cnt <= (others => '0');
                elsif (clk_div_cnt = CLK_DIV - 1) then
                    clk_div_cnt <= (others => '0');
                else
                    clk_div_cnt <= clk_div_cnt + '1';
                end if;
            end if;
        end if;
    end process;

    P_Gen_data_vld : process(rst_synch, CLK) begin
        if (rst_synch = '1') then
            data_vld <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (tdd_sig_sh(3) = '1') then
                if (clk_div_cnt = CLK_DIV - 1) then
                    data_vld <= '1';
                else
                    data_vld <= '0';
                end if;
            else
                data_vld <= '0';
            end if;
        end if;
    end process;
            
    P_Sample_Align : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (clk_div_cnt = 0) then
                sample_i <= data_i;        
                sample_q <= data_q;        
            end if;
        end if;
    end process;

    se_i_a <= sign_extension(sample_i, 30);
    se_i_b <= sign_extension(sample_i, 18);

    se_q_a <= sign_extension(sample_q, 30);
    se_q_b <= sign_extension(sample_q, 18);

    U_Square_I : DSP48E_MULT generic map(DEVICE, FALSE, FALSE, "ADD", FALSE, FALSE, 2, 2, FALSE, FALSE) port map(CLK, x"0", (others => '0'), (others => '0'), se_i_a, (others => '0'), se_i_b, (others => '0'), open, sample_pwr_i, open);  
    U_Square_Q : DSP48E_MULT generic map(DEVICE, FALSE, FALSE, "ADD", FALSE, FALSE, 2, 2, FALSE, FALSE) port map(CLK, x"0", (others => '0'), (others => '0'), se_q_a, (others => '0'), se_q_b, (others => '0'), open, sample_pwr_q, open);  


    -- Sample Power Sign Extention
    se_sample_pwr_i  <= sign_extension(sample_pwr_i, 22+2*DATA_WIDTH); 
    se_sample_pwr_q  <= sign_extension(sample_pwr_q, 22+2*DATA_WIDTH); 

    P_Sample_power_accumulation : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (rst_synch = '1') then
                pwr_accum_i <= (others => '0');      
                pwr_accum_q <= (others => '0');      
            else
                if (fs_rpls = '1') then -- Accumulation value initialization
                    pwr_accum_i <= (others => '0');      
                    pwr_accum_q <= (others => '0');      
                elsif (data_vld = '1') then
                    pwr_accum_i <= pwr_accum_i + se_sample_pwr_i;      
                    pwr_accum_q <= pwr_accum_q + se_sample_pwr_q;      
                end if;
            end if;
        end if;
    end process;
                
    P_FRAME_POWER : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (rst_synch = '1') then
                tdd_accum_pwr <= (others => '0');   
                update_done   <= (others => '0');   
            else
                if (fs_rpls = '1') then
                    tdd_accum_pwr <= pwr_accum_i + pwr_accum_q;   
                    update_done   <= x"1";   
                else
                    tdd_accum_pwr <= tdd_accum_pwr;   
                    update_done   <= update_done(2 downto 0) & '0';   
                end if;
            end if;
        end if;
    end process;

    pre_conv_pwr <= zero_conv & tdd_accum_pwr;

    pwr_conv_blk : MANTISSA_FRAMER 
    port map(
        RST          => rst_synch           , 
        CLK          => CLK                 , 
    
        START_IN     => update_done(3)      , 
        DATA_IN      => pre_conv_pwr        , 
        
        DONE_OUT     => conv_done           , 
        MANTISSA_OUT => conv_pwr              
        );

    P_Gen_measure_done : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (rst_synch = '1') then
                pwr_meas_done <= '1';
            else
                if (fs_rpls = '1') then
                    pwr_meas_done <= '0';
                else
                    if (conv_done = '1') then
                        pwr_meas_done <= '1';
                    end if;
                end if;
            end if;
        end if;
    end process;

    PWR_OUT             <= conv_pwr;
    PWR_UPDATE_DONE_OUT <= pwr_meas_done;

end arc_PWRMEAS_MANTISSA;

    
