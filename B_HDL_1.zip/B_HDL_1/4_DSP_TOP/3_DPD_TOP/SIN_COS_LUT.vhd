library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;

entity SIN_COS_LUT is
generic(
    HS_MODE     : boolean :=  TRUE  -- High Speed Mode (Operating Clock > 307.2MHz)
    );
port(
    RST         : in  std_logic;
    CLK         : in  std_logic;

    LUT_INDEX   : in  std_logic_vector( 4 downto 0);

    SIN         : out std_logic_vector(13 downto 0);
    COS         : out std_logic_vector(13 downto 0)
    );
end SIN_COS_LUT;

architecture arc_SIN_COS_LUT of SIN_COS_LUT is

component ROM_SIN_LUT is
generic(
    DATA_WIDTH  : natural := 14;
    ADDR_WIDTH  : natural :=  5 
    );
port(
    CLK	        : in  std_logic;
    ADDR        : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    RDEN        : in  std_logic;
    Q           : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end component;

component ROM_COS_LUT is
generic(
    DATA_WIDTH  : natural := 14;
    ADDR_WIDTH  : natural :=  5 
    );
port(
    CLK	        : in  std_logic;
    ADDR        : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    RDEN        : in  std_logic;
    Q           : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end component;

signal lut_addr_align : std_logic_vector(4 downto 0);
signal lut_addr_msb_4 : std_logic_vector(4 downto 0);
signal lut_addr_msb_3 : std_logic_vector(3 downto 0);
signal lut_addr_msb_2 : std_logic_vector(2 downto 0);
signal lut_addr_msb_1 : std_logic_vector(1 downto 0);
signal lut_addr_msb_0 : std_logic;

begin

    G_Normal_Operation : if (HS_MODE = FALSE) generate begin
        -- LUT-UP Table Address Align
        -- 1st Clock
        P_Stage_Index_Align_NM : process(RST, CLK) begin
            if (RST = '1') then 
                lut_addr_msb_4  <= (others => '0');
                lut_addr_msb_3  <= (others => '0');
                lut_addr_msb_2  <= (others => '0');
                lut_addr_msb_1  <= (others => '0');
                lut_addr_msb_0  <= '0';
            elsif (CLK'event) and (CLK = '1') then
                lut_addr_msb_4  <= lut_addr_msb_4(3 downto 0) & LUT_INDEX(4); -- cordic_stage0_q
                lut_addr_msb_3  <= lut_addr_msb_3(2 downto 0) & LUT_INDEX(3); -- cordic_stage1_q
                lut_addr_msb_2  <= lut_addr_msb_2(1 downto 0) & LUT_INDEX(2); -- cordic_stage2_q
                lut_addr_msb_1  <= lut_addr_msb_1(0 downto 0) & LUT_INDEX(1); -- cordic_stage3_q
                lut_addr_msb_0  <= LUT_INDEX(0);                              -- cordic_stage4_q
            end if;
        end process;

        -- 2nd Clock
        P_Address_Align_NM : process(RST, CLK) begin
            if (RST = '1') then
                lut_addr_align <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                lut_addr_align <= lut_addr_msb_4(4) &  -- Latency 4
                                  lut_addr_msb_3(3) &  -- Latency 3
                                  lut_addr_msb_2(2) &  -- Latency 2
                                  lut_addr_msb_1(1) &  -- Latency 1
                                  lut_addr_msb_0;      -- Latency 0
            end if;
        end process;
    end generate;

    G_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
        -- LUT-UP Table Address Align
        -- 1st Clock
        P_Stage_Index_Align_NM : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                lut_addr_msb_4  <= lut_addr_msb_4(3 downto 0) & LUT_INDEX(4); -- cordic_stage0_q
                lut_addr_msb_3  <= lut_addr_msb_3(2 downto 0) & LUT_INDEX(3); -- cordic_stage1_q
                lut_addr_msb_2  <= lut_addr_msb_2(1 downto 0) & LUT_INDEX(2); -- cordic_stage2_q
                lut_addr_msb_1  <= lut_addr_msb_1(0 downto 0) & LUT_INDEX(1); -- cordic_stage3_q
                lut_addr_msb_0  <= LUT_INDEX(0);                              -- cordic_stage4_q
            end if;
        end process;

        -- 2nd Clock
        P_Address_Align_NM : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                lut_addr_align <= lut_addr_msb_4(4) &  -- Latency 4
                                  lut_addr_msb_3(3) &  -- Latency 3
                                  lut_addr_msb_2(2) &  -- Latency 2
                                  lut_addr_msb_1(1) &  -- Latency 1
                                  lut_addr_msb_0;      -- Latency 0
            end if;
        end process;
    end generate;

    -- Latency : 2 Clock
    U_Sine_LUT   : ROM_SIN_LUT generic map(14, 5) port map(CLK, lut_addr_align, '1', SIN); 
    U_Cosine_LUT : ROM_COS_LUT generic map(14, 5) port map(CLK, lut_addr_align, '1', COS); 

end arc_SIN_COS_LUT;


