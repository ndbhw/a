-- k1340.heo

Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

--   SRL16E    : In order to incorporate this function into the design,
--    VHDL     : the following instance declaration needs to be placed
--  instance   : in the architecture body of the design code.  The
-- declaration : instance name (SRL16E_inst) and/or the port declarations
--    code     : after the "=>" assignment maybe changed to properly
--             : reference and connect this function to the design.
--             : All inputs and outputs must be connected.

--   Library   : In addition to adding the instance declaration, a use
-- declaration : statement for the UNISIM.vcomponents library needs to be
--     for     : added before the entity declaration.  This library
--   Xilinx    : contains the component declarations for all Xilinx
--  primitives : primitives and points to the models that will be used
--             : for simulation.

--  Copy the following two statements and paste them before the
--  Entity declaration, unless they already exist.

Library UNISIM;
use UNISIM.vcomponents.all;

entity SRL16E_DLY_7S is
generic(
    HS_MODE   : boolean := FALSE; 

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0) -- Delayed DATA
    );
end SRL16E_DLY_7S;

architecture arc_SRL16E_DLY_7S of SRL16E_DLY_7S is
	
constant sel_dly_nm : std_logic_vector( 3 downto 0) := conv_std_logic_vector(DELAY_NUM-2, 4);
constant sel_dly_hs : std_logic_vector( 3 downto 0) := conv_std_logic_vector(DELAY_NUM-3, 4);

signal data_d1   : std_logic_vector(BIT_WIDTH-1 downto 0);
signal data_d2   : std_logic_vector(BIT_WIDTH-1 downto 0);
signal data_srl  : std_logic_vector(BIT_WIDTH-1 downto 0);
signal data_reg  : std_logic_vector(BIT_WIDTH-1 downto 0);

attribute KEEP : string;
attribute KEEP of data_d1  : signal is "TRUE";
attribute KEEP of data_d2  : signal is "TRUE";
attribute KEEP of data_srl : signal is "TRUE";
attribute KEEP of data_reg : signal is "TRUE";

attribute MAX_FANOUT : integer;
attribute MAX_FANOUT of data_reg : signal is ternary_func(HS_MODE=TRUE, 10, 2000);

begin	

    G_SRL_Normal_operation : if (HS_MODE = FALSE) generate begin
        G_Data_1_Clock_Delay_NM : if (DELAY_NUM = 1) generate begin
            G_1CLK_DLY_Normal_Operation : if (HS_MODE = FALSE) generate begin
                P_1Clock_Delay_NM : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        data_reg <= DATA_IN;  
                    end if;
                end process;
            end generate;

            data_srl <= (others => '0');

        end generate;

        G_DATA_DELAY_NM : if (DELAY_NUM > 1) generate begin

            G_SRL16E_GEN_NM : for I in 0 to (BIT_WIDTH-1) generate begin
                -- SRL16E: 16-bit shift register LUT with clock enable operating on posedge of clock (Mapped to SliceM LUT6)
                --        Kintex-7
                -- Xilinx HDL Language Template, version 2014.4
                SRL16E_inst : SRL16E
                generic map(
                    INIT => X"0000"
                    )
                port map(
                    Q    => data_srl(I)  , -- SRL data output
                    A0   => sel_dly_nm(0), -- Select[0] input
                    A1   => sel_dly_nm(1), -- Select[1] input
                    A2   => sel_dly_nm(2), -- Select[2] input
                    A3   => sel_dly_nm(3), -- Select[3] input
                    CE   => '1'          , -- Clock enable input
                    CLK  => CLK          , -- Clock input
                    D    => DATA_IN(I)     -- SRL data input
                    );
                -- End of SRL16E_inst instantiation
            end generate;

            P_SRL_Output_Clocking_NM : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    data_reg <= data_srl; 
                end if;
            end process;
        end generate;

        data_d1  <= (others => '0');
        data_d2  <= (others => '0');

    end generate;


    G_SRL_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
        G_Data_1_Clock_Delay : if (DELAY_NUM = 1) generate begin
            G_1CLK_DLY_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_1Clock_Delay_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        data_reg <= DATA_IN;  
                    end if;
                end process;
            end generate;

            data_d1  <= (others => '0');
            data_d2  <= (others => '0');
            data_srl <= (others => '0');

        end generate;
            
        G_Data_2_Clock_Delay : if (DELAY_NUM = 2) generate begin
            G_2CLK_DLY_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_2Clock_Delay_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        data_d1  <= DATA_IN;
                        data_reg <= data_d1;  
                    end if;
                end process;
            end generate;

            data_d2  <= (others => '0');
            data_srl <= (others => '0');
        end generate;

        G_Data_N_Clock_Delay_HS : if (DELAY_NUM > 2) generate begin

            G_SRL_Input_PP_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_SRL_Input_Pipelining_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        data_d1  <= DATA_IN;
                    end if;
                end process;
            end generate;

            G_SRL16E_GEN_HS : for I in 0 to (BIT_WIDTH-1) generate begin
                -- SRL16E: 16-bit shift register LUT with clock enable operating on posedge of clock (Mapped to SliceM LUT6)
                --        Kintex-7
                -- Xilinx HDL Language Template, version 2014.4
                SRL16E_inst : SRL16E
                generic map(
                    INIT => X"0000"
                    )
                port map(
                    Q    => data_srl(I)  , -- SRL data output
                    A0   => sel_dly_hs(0), -- Select[0] input
                    A1   => sel_dly_hs(1), -- Select[1] input
                    A2   => sel_dly_hs(2), -- Select[2] input
                    A3   => sel_dly_hs(3), -- Select[3] input
                    CE   => '1'          , -- Clock enable input
                    CLK  => CLK          , -- Clock input
                    D    => data_d1(I)     -- SRL data input
                    );
                -- End of SRL16E_inst instantiation
            end generate;

            G_SRL_Ouput_Clocking_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_SRL_Output_Clocking_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        data_reg <= data_srl; 
                    end if;
                end process;
            end generate;

            data_d2 <= (others => '0');

        end generate;
    end generate;

    DATA_OUT <= data_reg;

end arc_SRL16E_DLY_7S;
