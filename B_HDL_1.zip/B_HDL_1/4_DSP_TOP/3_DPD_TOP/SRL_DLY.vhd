-- k1340.heo

Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

Library UNISIM;
use UNISIM.vcomponents.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity SRL_DLY is
generic(
    HS_MODE   : boolean := FALSE; 

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK       : in  std_logic;
    
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_COUT : out std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end SRL_DLY;

architecture arc_SRL_DLY of SRL_DLY is

component SRL16E_DLY is
generic(
    HS_MODE   : boolean := FALSE; 

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK      : IN  STD_LOGIC;
    DATA_IN  : IN  STD_LOGIC_VECTOR(BIT_WIDTH-1 downto 0);
    DATA_OUT : OUT STD_LOGIC_VECTOR(BIT_WIDTH-1 downto 0) -- Delayed DATA
    );
end component;

component SRLC32E_DLY is
generic(
    HS_MODE   : boolean := FALSE; 

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK       : IN  STD_LOGIC;
    DATA_IN   : IN  STD_LOGIC_VECTOR(BIT_WIDTH-1 downto 0);
    DATA_COUT : OUT STD_LOGIC_VECTOR(BIT_WIDTH-1 downto 0); -- SRLC32E Chain, 32clock Delayed DATA
    DATA_OUT  : OUT STD_LOGIC_VECTOR(BIT_WIDTH-1 downto 0)  -- Delayed DATA
    );
end component;


begin

    G_DLY0 : if (DELAY_NUM = 0) generate begin
        DATA_OUT  <= DATA_IN;
        DATA_COUT <= (others => '0');
    end generate;

    G_SRL16E_DLY : if ((DELAY_NUM < 17) and (DELAY_NUM > 0)) generate begin
        U_SRL16E_DLY : SRL16E_DLY generic map(HS_MODE, BIT_WIDTH, DELAY_NUM) port map (CLK, DATA_IN, DATA_OUT);
        DATA_COUT <= (others => '0');
    end generate;

    G_SRLC32E_DLY : if (DELAY_NUM > 16) generate begin
        U_SRLC32E_DLY : SRLC32E_DLY generic map(HS_MODE, BIT_WIDTH, DELAY_NUM) port map (CLK, DATA_IN, DATA_COUT, DATA_OUT);
    end generate;

end arc_SRL_DLY;
