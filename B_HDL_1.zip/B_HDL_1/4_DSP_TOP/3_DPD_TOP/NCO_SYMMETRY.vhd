-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part
-- Block Name : NCO_SYMMETRY

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity NCO_SYMMETRY is
generic(
    DEVICE               : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2

    HOVS                 : natural :=        2 ; -- HOVS = (Clock Frequency)/(Sampling Rate)
    SYMMETRY             : boolean :=    FALSE ; -- TRUE  : Symmetry Operation(+a/-a freq shift), Generate POS/NEG_SHIFT_PATH
                                                 -- FALSE : Simplex Operation(+a freq shift), Only Generate POS_SHIFT_PATH
    POS_SHIFTH_PATH_NUM  : natural :=        2 ; -- The Number of Positive Frequency Shifting Path Number
    NEG_SHIFTH_PATH_NUM  : natural :=        1 ; -- The Number of Negative Frequency Shifting Path Number
    NCO_WIDTH            : natural :=       16 ; -- Sinusoidal Wave Sample Wdith
    RES_VAL              : natural :=    24576   -- Frequency Shift Step Resolution, 10kHz
    );
port(
    RST                  : in  std_logic;
    CLK                  : in  std_logic;

    NCO_WREN             : in  std_logic;
    NCO_WORD             : in  std_logic_vector(31 downto 0);

    NCO_FREQ_COMP_OFFSET : in  std_logic_vector(31 downto 0);

    DATA_P_SH_VLD_IN     : in  std_logic_vector( POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift
    DATA_P_SH_I_IN       : in  std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift
    DATA_P_SH_Q_IN       : in  std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift

    DATA_P_SH_VLD_OUT    : out std_logic_vector( POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift
    DATA_P_SH_I_OUT      : out std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift
    DATA_P_SH_Q_OUT      : out std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift

    DATA_N_SH_VLD_IN     : in  std_logic_vector( NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_I_IN       : in  std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_Q_IN       : in  std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift

    DATA_N_SH_VLD_OUT    : out std_logic_vector( NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_I_OUT      : out std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_Q_OUT      : out std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0)  -- Negative shift
    );
end NCO_SYMMETRY;

architecture arc_NCO_SYMMETRY of NCO_SYMMETRY is

-- !!!!!!!!!! Caution !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
-- !! Resolution    : 2.5kHz
-- !! Sampling Rate : 368.64Msps
-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
constant RESOLUTION      : real    := 2.5; -- kHz
constant RES_FACTOR      : natural := natural(10.0/RESOLUTION);
constant RESOLUTION_VAL  : natural := RES_VAL*RES_FACTOR;

component RST_SYNC is
generic(
    DLY_NUM              : natural := 3;    -- Number of delay.
    MAX_FANOUT_NUM       : integer := 200   -- Number of maximum fanout
    );
port(
    RST_IN               : in  std_logic;   -- Active high asynchronous reset
    CLK                  : in  std_logic;   -- clock to be sync'ed to
    RST_OUT              : out std_logic    -- "Synchronised" reset signal
    );
end component;

component GEN_NCO_WAVE is
generic(
    DEVICE               : string  := "ULTRASCALE";
    HS_MODE              : boolean :=        TRUE ;
    HOVS                 : natural :=           2 ;
    RES_VAL              : natural :=       24576 ;
    DATA_WIDTH           : natural :=          16
    );
port(
    RST                  : in  std_logic;
    CLK                  : in  std_logic;

    SAMPLE_VLD_IN        : in  std_logic;

    NCO_WREN_IN          : in  std_logic;
    NCO_FREQ_OFFSET_IN   : in  std_logic_vector(log2(RES_VAL)-1 downto 0);

    NCO_FREQ_COMP_OFFSET : in  std_logic_vector(log2(RES_VAL)-1 downto 0);

    COS_OUT              : out std_logic_vector(DATA_WIDTH-1 downto 0);
    SIN_OUT              : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end component;

component MIXER is
generic(
    DEVICE               : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HS_MODE              : boolean :=     TRUE ;

    HOVS                 : natural :=        2 ;
    DATA_WIDTH           : natural :=       16 ;
    RND_BIT              : natural :=       15
    );
port(
    RST                  : in  std_logic;
    CLK                  : in  std_logic;

    SAMPLE_VLD_IN        : in  std_logic;
    SAMPLE_I_IN          : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    SAMPLE_Q_IN          : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    COS_I_IN             : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    SIN_Q_IN             : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    SAMPLE_VLD_OUT       : out std_logic;
    SAMPLE_I_OUT         : out std_logic_vector(DATA_WIDTH-1 downto 0);
    SAMPLE_Q_OUT         : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end component;

signal rst_synch         : std_logic;

signal nco_vld           : std_logic;
signal p_nco_sin         : std_logic_vector(NCO_WIDTH-1 downto 0);
signal p_nco_cos         : std_logic_vector(NCO_WIDTH-1 downto 0);

signal n_nco_sin         : std_logic_vector(NCO_WIDTH-1 downto 0);
signal n_nco_cos         : std_logic_vector(NCO_WIDTH-1 downto 0);

constant zeros           : std_logic_vector(NCO_WIDTH-1 downto 0) := (others => '0');

begin

    U_RST_SYNC : RST_SYNC generic map(4, 200) port map(RST, CLK, rst_synch);

    G_NCO_Sample_Valid_HOVS1 : if (HOVS = 1) generate begin
        nco_vld <= '1';
    end generate;

    G_NCO_Sample_Valid_HOVS2 : if (HOVS = 2) generate begin
        P_Generate_Sample_Valid : process(rst_synch, CLK) begin
            if (rst_synch = '1') then
                nco_vld <= '1';
            elsif (CLK'event) and (CLK = '1') then
                nco_vld <= not nco_vld;
            end if;
        end process;
    end generate;

    -- !!!!!!!!!! Caution !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    -- !! Resolution    : 2.5kHz
    -- !! Sampling Rate : 368.64Msps
    -- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    U_NCO_GEN_Sinusoidal_Wave : GEN_NCO_WAVE
    generic map(
        DEVICE               => DEVICE              ,
        HS_MODE              => TRUE                ,
        HOVS                 => HOVS                ,
        RES_VAL              => RESOLUTION_VAL      ,
        DATA_WIDTH           => NCO_WIDTH
        )
    port map(
        RST                  => rst_synch           ,
        CLK                  => CLK                 ,

        SAMPLE_VLD_IN        => nco_vld             ,

        NCO_WREN_IN          => NCO_WREN            ,
        NCO_FREQ_OFFSET_IN   => NCO_WORD(log2(RESOLUTION_VAL)-1 downto 0),

        NCO_FREQ_COMP_OFFSET => NCO_FREQ_COMP_OFFSET(log2(RESOLUTION_VAL)-1 downto 0),

        COS_OUT              => p_nco_cos           ,
        SIN_OUT              => p_nco_sin
        );

    G_NCO_Positive_Frequency_Shifting : for P in 0 to (POS_SHIFTH_PATH_NUM - 1) generate begin
        U_Positive_Frequency_Shift_MIXER : MIXER
        generic map(
            DEVICE           => DEVICE            ,
            HS_MODE          => TRUE              ,

            HOVS             => HOVS              ,
            DATA_WIDTH       => NCO_WIDTH         ,
            RND_BIT          => NCO_WIDTH-1
            )
        port map(
            RST              => rst_synch         ,
            CLK              => CLK               ,

            SAMPLE_VLD_IN    => DATA_P_SH_VLD_IN(P) ,
            SAMPLE_I_IN      => DATA_P_SH_I_IN(P)   ,
            SAMPLE_Q_IN      => DATA_P_SH_Q_IN(P)   ,

            COS_I_IN         => p_nco_cos           ,
            SIN_Q_IN         => p_nco_sin           ,

            SAMPLE_VLD_OUT   => DATA_P_SH_VLD_OUT(P),
            SAMPLE_I_OUT     => DATA_P_SH_I_OUT(P)  ,
            SAMPLE_Q_OUT     => DATA_P_SH_Q_OUT(P)
            );
    end generate;

    G_NCO_SYMMETRY_MODE : if (SYMMETRY = TRUE) generate begin

        P_Reverse_NCO_Generate_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                n_nco_sin <= p_nco_sin ;          -- sin
                n_nco_cos <= (not p_nco_cos) + 1; -- -cos
            end if;
        end process;

        G_NCO_Negative_Frequency_Shifting : for N in 0 to (NEG_SHIFTH_PATH_NUM - 1) generate begin

            U_Negative_Frequency_Shift_MIXER : MIXER
            generic map(
                DEVICE           => DEVICE              ,
                HS_MODE          => TRUE                ,

                HOVS             => HOVS                ,
                DATA_WIDTH       => NCO_WIDTH           ,
                RND_BIT          => NCO_WIDTH-1
                )
            port map(
                RST              => rst_synch           ,
                CLK              => CLK                 ,

                SAMPLE_VLD_IN    => DATA_N_SH_VLD_IN(N) ,
                SAMPLE_I_IN      => DATA_N_SH_I_IN(N)   ,
                SAMPLE_Q_IN      => DATA_N_SH_Q_IN(N)   ,

                COS_I_IN         => n_nco_cos           ,
                SIN_Q_IN         => n_nco_sin           ,

                SAMPLE_VLD_OUT   => DATA_N_SH_VLD_OUT(N),
                SAMPLE_I_OUT     => DATA_N_SH_I_OUT(N)  ,
                SAMPLE_Q_OUT     => DATA_N_SH_Q_OUT(N)
                );

        end generate;
    end generate;

    G_NCO_SIMPLEX_MODE : if (SYMMETRY = FALSE) generate begin

        n_nco_sin <= zeros; -- sin
        n_nco_cos <= zeros; -- -cos

        DATA_N_SH_VLD_OUT <= DATA_N_SH_VLD_IN;
        DATA_N_SH_I_OUT   <= DATA_N_SH_I_IN;
        DATA_N_SH_Q_OUT   <= DATA_N_SH_Q_IN;

    end generate;

end arc_NCO_SYMMETRY;
