library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;

entity CORDIC_STAGE is
   -- STAGE_NUM : 0 ~ 5
   -- 0 : 45.000 degree Shift
   -- 1 : 26.565 degree Shift
   -- 2 : 14.036 degree Shift
   -- 3 :  7.125 degree Shift
   -- 4 :  3.576 degree Shift
   -- 5 :  1.783 degree Shift
generic(
    HS_MODE     : boolean :=  TRUE;               -- High Speed Mode (Operating Clock > 307.2MHz)
    STAGE_NUM   : natural 
    );
port(
    RST         : in  std_logic;
    CLK         : in  std_logic; 
    DATA_I_IN   : in  std_logic_vector(18 downto 0);
    DATA_Q_IN   : in  std_logic_vector(18 downto 0); 

    DATA_I_OUT  : out std_logic_vector(18 downto 0);
    DATA_Q_OUT  : out std_logic_vector(18 downto 0)     
    );
end CORDIC_STAGE;

architecture arc_CORDIC_STAGE of CORDIC_STAGE is

signal data_i_sign_vec          : std_logic_vector(STAGE_NUM downto 0);
signal data_q_sign_vec          : std_logic_vector(STAGE_NUM downto 0);

signal data_i_right_sh          : std_logic_vector(19 downto 0);
signal data_q_right_sh          : std_logic_vector(19 downto 0);

signal cordic_stage_i_minus_qrs : std_logic_vector(18 downto 0);
signal cordic_stage_q_plus_irs  : std_logic_vector(18 downto 0);
signal cordic_stage_i_plus_qrs  : std_logic_vector(18 downto 0);
signal cordic_stage_q_minus_irs : std_logic_vector(18 downto 0);

signal data_q_sign              : std_logic;

attribute KEEP : string;
attribute KEEP of data_q_sign : signal is "TRUE";

begin

--The CORDIC algorithm itself.
--Function performs rotation of complex vector to drive image part (Q) to zero. 
--At the final loop iteration, real part (I) will contain magnitude of the complex number.
--The algorithm is as shown below:
--(a) The input complex number is subject to a series of phase rotations.
--(b) The sign of the phase rotation is the negative of the sign of imaginary component of result.
--(c) After multiple iterations, imaginary component tends to zero.
--(d) Then, the real part of the new complex vector represents the magnitude and the cumulative phase index represents the phase of input complex number.


    -- if Q_in < 0, I_out = Ki[I_in - (Q_in)*2^-i], Q_out = Ki[Q_in + (I_in)*2^-i] 
    -- if Q_in >=0, I_out = Ki[I_in + (Q_in)*2^-i], Q_out = Ki[Q_in - (I_in)*2^-i] 
    --              2^-i = Right shift

    -- Right Shift & Sign Bit Extended
    --data_i_right_sh(18 downto 18-STAGE_NUM )   <= (others => '0') when I_in(18) = '0' else -- Postive Extended
    --                                              (others => '1');                         -- Negative Extended   
    --data_i_right_sh(18-STAGE_NUM downto 0)     <= I_in( 18 downto STAGE_NUM ); 
    --
    --data_q_right_sh(18 downto 18-STAGE_NUM )   <= (others => '0') when Q_in(18) = '0' else -- Postive Extended
    --                                              (others => '1');    
    --data_q_right_sh(18-STAGE_NUM downto 0)     <= Q_in( 18 downto STAGE_NUM );             -- Negative Extended 

    G_Sign_Extended : for I in 0 to (STAGE_NUM) generate begin
        data_i_sign_vec(I) <= DATA_I_IN(18);
        data_q_sign_vec(I) <= DATA_Q_IN(18);
    end generate; 

    data_i_right_sh <= data_i_sign_vec & DATA_I_IN(18 downto STAGE_NUM); -- DATA_I_IN *2^(-STAGE_NUM)
    data_q_right_sh <= data_q_sign_vec & DATA_Q_IN(18 downto STAGE_NUM); -- DATA_Q_IN *2^(-STAGE_NUM)
                
    G_Normal_Operation : if (HS_MODE = FALSE) generate begin

        -- 1st Clock
        P_IQ_Calculate_NM : process(RST, CLK) begin -- (I/Q_in)*2^-i
            if (RST = '1') then
                DATA_I_OUT <= (others => '0');  
                DATA_Q_OUT <= (others => '0');     
            elsif (CLK'event) and (CLK = '1') then
                if (DATA_Q_IN(18) = '1') then
                    DATA_I_OUT <= DATA_I_IN - data_q_right_sh(18 downto 0);  
                    DATA_Q_OUT <= DATA_Q_IN + data_i_right_sh(18 downto 0);     
                else
                    DATA_I_OUT <= DATA_I_IN + data_q_right_sh(18 downto 0);  
                    DATA_Q_OUT <= DATA_Q_IN - data_i_right_sh(18 downto 0);     
                end if;
            end if;
        end process;

        cordic_stage_i_minus_qrs <= (others => '0'); 
        cordic_stage_q_plus_irs  <= (others => '0'); 
        cordic_stage_i_plus_qrs  <= (others => '0'); 
        cordic_stage_q_minus_irs <= (others => '0'); 
        
        data_q_sign              <= '0'; 

    end generate;

    G_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
        -- 1st Clock
        P_IQ_Calculate_HS : process(CLK) begin -- (I/Q_in)*2^-i
            if (CLK'event) and (CLK = '1') then
                cordic_stage_i_minus_qrs <= DATA_I_IN - data_q_right_sh(18 downto 0);    
                cordic_stage_q_plus_irs  <= DATA_Q_IN + data_i_right_sh(18 downto 0);    
                             
                cordic_stage_i_plus_qrs  <= DATA_I_IN + data_q_right_sh(18 downto 0);    
                cordic_stage_q_minus_irs <= DATA_Q_IN - data_i_right_sh(18 downto 0);    
            end if;
        end process;

        -- 1st Clock
        P_Q_Sign_Clocking_NM : process(CLK) begin 
            if (CLK'event) and (CLK = '1') then
                data_q_sign <= DATA_Q_IN(18);    
            end if;
        end process;

        DATA_I_OUT <= cordic_stage_i_minus_qrs when (data_q_sign = '1') else cordic_stage_i_plus_qrs;  
        DATA_Q_OUT <= cordic_stage_q_plus_irs  when (data_q_sign = '1') else cordic_stage_q_minus_irs;     

    end generate;

    -- Cordic Stage
    -- Q_in < 0, check the sign of image part; the rotation angle must be negative to the phase of the current intermediate result 
    -- update real part; at the final stage it will hold amplitude of complex number                    
    -- the sign of acc_Q is "minus", therfore we perform addition; our target is to drive acc_Q to zero 
    -- Q_in >= 0 
    -- update real part; at the final stage it will hold amplitude of complex number                      
    -- the sign of acc_Q is "plus", therfore we perform subtraction; our target is to drive acc_Q to zero 

end arc_CORDIC_STAGE;

