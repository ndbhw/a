-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part
-- Block Name : UNSIGNED_COMPARE 

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

-- library work;
-- use work.ARRAY_TYPE.all;
-- use work.RU_FPGA_FNC.all;

entity UNSIGNED_COMPARE is
generic(
    DATA_WIDTH       : natural := 32;
    BIT_DIV          : natural := 24  -- DATA_WIDTH > BIT_DIV, Mantissa Compare : 24, Narual Compare : 16
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;

    THRESHOLD_IN     : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    DATA_IN          : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    COMPARE_FLAG_OUT : out std_logic
    );
end UNSIGNED_COMPARE;

architecture arc_UNSIGNED_COMPARE of UNSIGNED_COMPARE is

signal data_h       : std_logic_vector(DATA_WIDTH downto BIT_DIV);
signal thres_h      : std_logic_vector(DATA_WIDTH downto BIT_DIV);

signal data_l       : std_logic_vector(BIT_DIV downto 0);
signal thres_l      : std_logic_vector(BIT_DIV downto 0);

signal comp_h_flag  : std_logic_vector(1 downto 0);
signal comp_l_flag  : std_logic;

signal compare_flag : std_logic;

begin

    P_Bit_Dividing : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            data_h  <= '0' & DATA_IN(DATA_WIDTH-1 downto BIT_DIV);            
            thres_h <= '0' & THRESHOLD_IN(DATA_WIDTH-1 downto BIT_DIV);       

            data_l  <= '0' & DATA_IN(BIT_DIV-1 downto 0);           
            thres_l <= '0' & THRESHOLD_IN(BIT_DIV-1 downto 0);      
        end if;
    end process;

    P_Compare_High_Low : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (data_h > thres_h) then  
                comp_h_flag <= "00"; 
            elsif (data_h = thres_h) then
                comp_h_flag <= "10"; 
            else -- (data_h < thres_h)
                comp_h_flag <= "01"; 
            end if;

            if (data_l < thres_l) then  
                comp_l_flag <= '1'; 
            else
                comp_l_flag <= '0'; 
            end if;
        end if;
    end process;

    P_Compare_Result : process(RST, CLK) begin
        if (RST = '1') then
            compare_flag <= '0'; 
        elsif (CLK'event) and (CLK = '1') then
            if (comp_h_flag = "00") then -- (data_h > thres_h)
                compare_flag <= '0'; 
            elsif (comp_h_flag = "10") then -- (data_h = thres_h)
                if (comp_l_flag = '0') then
                    compare_flag <= '0'; 
                else
                    compare_flag <= '1'; 
                end if;
            else -- (data_h < thres_h)
                compare_flag <= '1'; 
            end if;
        end if;
    end process;

    COMPARE_FLAG_OUT <= compare_flag; 

end arc_UNSIGNED_COMPARE;
    
