--   SRL16E    : In order to incorporate this function into the design,
--    VHDL     : the following instance declaration needs to be placed
--  instance   : in the architecture body of the design code.  The
-- declaration : instance name (SRL16E_inst) and/or the port declarations
--    code     : after the "=>" assignment maybe changed to properly
--             : reference and connect this function to the design.
--             : All inputs and outputs must be connected.

--   Library   : In addition to adding the instance declaration, a use
-- declaration : statement for the UNISIM.vcomponents library needs to be
--     for     : added before the entity declaration.  This library
--   Xilinx    : contains the component declarations for all Xilinx
--  primitives : primitives and points to the models that will be used
--             : for simulation.

--  Copy the following two statements and paste them before the
--  Entity declaration, unless they already exist.

Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

Library UNISIM;
use UNISIM.vcomponents.all;

entity SRL16E_WRAP_7S is
generic(
    BIT_WIDTH : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    SEL_DLY   : in  std_logic_vector( 3 downto 0);         -- Select Delay, 0 ~ 15 => 0 ~ 15 clk delay
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0) -- Delayed DATA
    );
end SRL16E_WRAP_7S;

architecture arc_SRL16E_WRAP_7S of SRL16E_WRAP_7S is

begin	
--  <-----Cut code below this line and paste into the architecture body---->

    G_SRL16E_INST_GEN : for I in 0 to (BIT_WIDTH-1) generate begin
        -- SRL16E: 16-bit shift register LUT with clock enable operating on posedge of clock (Mapped to SliceM LUT6)
        --        Kintex-7
        -- Xilinx HDL Language Template, version 2014.4
        SRL16E_inst : SRL16E
        generic map(
            INIT => X"0000"
            )
        port map(
            Q   => DATA_OUT(I), -- SRL data output
            A0  => SEL_DLY(0) , -- Select[0] input
            A1  => SEL_DLY(1) , -- Select[1] input
            A2  => SEL_DLY(2) , -- Select[2] input
            A3  => SEL_DLY(3) , -- Select[3] input
            CE  => '1'        , -- Clock enable input
            CLK => CLK        , -- Clock input
            D   => DATA_IN(I)   -- SRL data input
            );
        -- End of SRL16E_inst instantiation
    end generate;

end arc_SRL16E_WRAP_7S;
