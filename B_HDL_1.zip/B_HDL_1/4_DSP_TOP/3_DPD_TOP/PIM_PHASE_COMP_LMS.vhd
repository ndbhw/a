library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.numeric_std.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

-- processing-delay : 12 clk
entity PIM_PHASE_COMP_LMS is
generic(
    DEVICE                       : string             := "ULTRASCALE";
    HOVS                         : natural            := 1
);
port(
    RX_DATA_I_IN                 : in  std_logic_vector(15 downto 0);    -- PIM source in         BB_IN_I                      
    RX_DATA_Q_IN                 : in  std_logic_vector(15 downto 0);    -- PIM source in         BB_IN_Q                      
    CNT_RST_IN                   : in  std_logic_vector( 0 downto 0);    -- count rst in          CNT_RST                      
    PIM_DATA_I_IN                : in  std_logic_vector(15 downto 0);    -- UL in                 FB_IN_I                      
    PIM_DATA_Q_IN                : in  std_logic_vector(15 downto 0);    -- UL in                 FB_IN_Q                      
    MU_SELECT_IN                 : in  std_logic_vector( 1 downto 0);    -- Mu select in          FB_MU_PP_SEL                 
    PNPC_EN_IN                   : in  std_logic_vector( 0 downto 0);    -- PNPC enalbe in        FB_PP_EN                     
    PNPC_SET_IN                  : in  std_logic_vector( 0 downto 0);    -- PNPC coef set in      FB_PP_SET                    
    COEF_I_IN                    : in  std_logic_vector(15 downto 0);    -- initial coeff in      FB_PP_SETVAL_I               
    COEF_Q_IN                    : in  std_logic_vector(15 downto 0);    -- initial coeff in      FB_PP_SETVAL_Q               
    CLK_PIMD                     : in  std_logic;                        -- CLK                   CLK                          
    CE_CLR_IN                    : in  std_logic;                        -- ?                     CLR                          
    UL_DATA_DLY_I_OUT            : out std_logic_vector(15 downto 0);    -- UL delayed data out   BB_PP_OUT_I                  
    UL_DATA_DLY_Q_OUT            : out std_logic_vector(15 downto 0);    -- UL delayed data out   BB_PP_OUT_Q                  
    PIM_I_OUT                    : out std_logic_vector(15 downto 0);    -- PNPCed data out       FB_PP_OUT_I                  
    PIM_Q_OUT                    : out std_logic_vector(15 downto 0);    -- PNPCed data out       FB_PP_OUT_Q                  
    COEF_I_OUT                   : out std_logic_vector(15 downto 0);    -- coef out              TP_FB_DC_I                   
    COEF_Q_OUT                   : out std_logic_vector(15 downto 0)     -- coef out              TP_FB_DC_Q                   
    );
end PIM_PHASE_COMP_LMS;

architecture arc_PIM_PHASE_COMP_LMS of PIM_PHASE_COMP_LMS is

constant C_COEF_UPDATE_DLY_OFFSET    : natural := 0;

component COMPLEX_MULTIPLIER is
generic(
    DEVICE                      : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HOVS                        : natural :=        1 ;

    INPUT_WIDTH                 : natural :=       16 ; -- AIN bitwidth : 0 to 29
    RND_EN                      : boolean :=     TRUE ; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT                     : natural :=       15 ; -- Rounding bit  
    OUTPUT_WIDTH                : natural :=       16   -- Result bitwidth : 0 to 47
    );
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    DATA_VLD_IN                 : in  std_logic;
    ADATA_I_IN                  : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    ADATA_Q_IN                  : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
                                                         
    BDATA_I_IN                  : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    BDATA_Q_IN                  : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
   
    DATA_VLD_OUT                : out std_logic;
    DATA_I_OUT                  : out std_logic_vector(OUTPUT_WIDTH-1 downto 0);
    DATA_Q_OUT                  : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
end component;

component DSP48E_MULT is
generic(
    DEVICE                      : string  := "ULTRASCALE";
    DSP48_MODECTRL              : boolean :=       FALSE ;
    DSP48_PREADDER_USE          : boolean :=        TRUE ;
    DSP48_PREADDER_MODE         : string  :=        "ADD"; -- "ADD" or "SUB" 
    DSP48_PCIN_USE              : boolean :=       FALSE ;
    DSP48_PCOUT_USE             : boolean :=       FALSE ;

    A_nREG                      : integer :=           2 ; -- 0, 1, 2
    B_nREG                      : integer :=           2 ; -- 0, 1, 2

    C_EN                        : boolean :=        TRUE ; -- RND ENable
    RND_SYMMETRY                : boolean :=       FALSE 
    );
port(
    CLK                         : in  std_logic;

    ALUMODE_IN                  : in  std_logic_vector( 3 downto 0);
    OPMODE_IN                   : in  std_logic_vector( 8 downto 0);

    C_IN                        : in  std_logic_vector(47 downto 0); -- RND Value
    A_IN                        : in  std_logic_vector(29 downto 0);
    D_IN                        : in  std_logic_vector(26 downto 0);
    B_IN                        : in  std_logic_vector(17 downto 0);

    P_CIN                       : in  std_logic_vector(47 downto 0);
    P_COUT                      : out std_logic_vector(47 downto 0);

    P_OUT                       : out std_logic_vector(47 downto 0);
    CRRY_OUT                    : out std_logic
    );
end component;

component SAT_SIGN is
generic(
    HS_MODE          : boolean := TRUE;
    INPUT_BIT        : natural;
    OUTPUT_BIT       : natural 
    );
port( 
    RST              : in  std_logic;
    CLK              : in  std_logic;
    DATA_IN          : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT         : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

component RND_FUNC is
generic(
    RND_STYLE  : string := "SYMMETRY";
    RND_BIT    : natural;
    INPUT_BIT  : natural;
    OUTPUT_BIT : natural
    );
port(
    CLK        : in  std_logic;

    DATA_IN    : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT   : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

component SRL16E_DLY is
generic(
    DEVICE       : string  := "ULTRASCALE";
    HS_MODE      : boolean :=       FALSE ;

    BIT_WIDTH    : natural;            -- 2 to 64
    DELAY_NUM    : natural
    );
port(
    CLK          : in  std_logic;

    DATA_IN      : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT     : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end component;

component SRLC32E_DLY is
generic(
    DEVICE    : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HS_MODE   : boolean :=        TRUE ;

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_COUT : out std_logic_vector(BIT_WIDTH-1 downto 0); -- SRLC32E Chain, 32clock Delayed DATA
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0)  -- Delayed DATA
    );
end component;

signal pim_i_in_16b             : std_logic_vector(15 downto 0) := (others=>'0'); 
signal pim_q_in_16b             : std_logic_vector(15 downto 0) := (others=>'0'); 
signal pim_i_in_16b_d           : std_logic_vector(15 downto 0) := (others=>'0'); 
signal pim_q_in_16b_d           : std_logic_vector(15 downto 0) := (others=>'0'); 
signal pim_i_in_16b_d2          : std_logic_vector(15 downto 0) := (others=>'0'); 
signal pim_q_in_16b_d2          : std_logic_vector(15 downto 0) := (others=>'0'); 
signal pim_i_in_16b_dly         : std_logic_vector(15 downto 0) := (others=>'0'); 
signal pim_q_in_conj_17b        : std_logic_vector(16 downto 0) := (others=>'0'); 
signal pim_q_in_conj_16b        : std_logic_vector(15 downto 0) := (others=>'0'); 
signal pim_q_in_conj_16b_dly    : std_logic_vector(15 downto 0) := (others=>'0'); 
signal coef_i_in_16b            : std_logic_vector(15 downto 0) := (others=>'0'); 
signal coef_q_in_16b            : std_logic_vector(15 downto 0) := (others=>'0'); 
signal coef_i_in_48b            : std_logic_vector(47 downto 0) := (others=>'0'); 
signal coef_q_in_48b            : std_logic_vector(47 downto 0) := (others=>'0'); 
signal coef_i_mux_48b           : std_logic_vector(47 downto 0) := (others=>'0'); 
signal coef_q_mux_48b           : std_logic_vector(47 downto 0) := (others=>'0'); 
signal coef_i_in_48b_lat        : std_logic_vector(47 downto 0) := (others=>'0'); 
signal coef_q_in_48b_lat        : std_logic_vector(47 downto 0) := (others=>'0'); 
signal coef_i_in_48b_lat_24b    : std_logic_vector(23 downto 0) := (others=>'0'); 
signal coef_q_in_48b_lat_24b    : std_logic_vector(23 downto 0) := (others=>'0'); 
signal coef_i_in_48b_lat_sft    : std_logic_vector(48 downto 0) := (others=>'0'); 
signal coef_q_in_48b_lat_sft    : std_logic_vector(48 downto 0) := (others=>'0'); 
signal coef_i_leaked_49b        : std_logic_vector(48 downto 0) := (others=>'0'); 
signal coef_q_leaked_49b        : std_logic_vector(48 downto 0) := (others=>'0'); 
signal coef_i_leaked_50b        : std_logic_vector(49 downto 0) := (others=>'0'); 
signal coef_q_leaked_50b        : std_logic_vector(49 downto 0) := (others=>'0'); 
signal coef_i_leaked_48b        : std_logic_vector(47 downto 0) := (others=>'0'); 
signal coef_q_leaked_48b        : std_logic_vector(47 downto 0) := (others=>'0'); 
signal coef_i_leaked_48b_dly    : std_logic_vector(47 downto 0) := (others=>'0'); 
signal coef_q_leaked_48b_dly    : std_logic_vector(47 downto 0) := (others=>'0'); 
signal coef_i_lat_32b           : std_logic_vector(31 downto 0) := (others=>'0'); 
signal coef_q_lat_32b           : std_logic_vector(31 downto 0) := (others=>'0'); 
signal coef_i_lat_28b           : std_logic_vector(27 downto 0) := (others=>'0'); 
signal coef_q_lat_28b           : std_logic_vector(27 downto 0) := (others=>'0'); 
signal coef_i_lat_25b           : std_logic_vector(24 downto 0) := (others=>'0'); 
signal coef_q_lat_25b           : std_logic_vector(24 downto 0) := (others=>'0'); 
signal coef_i_lat_21b           : std_logic_vector(20 downto 0) := (others=>'0'); 
signal coef_q_lat_21b           : std_logic_vector(20 downto 0) := (others=>'0'); 
signal coef_i_lat_32b_16b       : std_logic_vector(15 downto 0) := (others=>'0'); 
signal coef_q_lat_32b_16b       : std_logic_vector(15 downto 0) := (others=>'0'); 
signal coef_i_lat_28b_16b       : std_logic_vector(15 downto 0) := (others=>'0'); 
signal coef_q_lat_28b_16b       : std_logic_vector(15 downto 0) := (others=>'0'); 
signal coef_i_lat_25b_16b       : std_logic_vector(15 downto 0) := (others=>'0'); 
signal coef_q_lat_25b_16b       : std_logic_vector(15 downto 0) := (others=>'0'); 
signal coef_i_lat_21b_16b       : std_logic_vector(15 downto 0) := (others=>'0'); 
signal coef_q_lat_21b_16b       : std_logic_vector(15 downto 0) := (others=>'0'); 
signal coef_i_mwm_16b           : std_logic_vector(15 downto 0) := (others=>'0'); 
signal coef_q_mwm_16b           : std_logic_vector(15 downto 0) := (others=>'0'); 
signal rst_in                   : std_logic;
signal pim_i_mult_22b           : std_logic_vector(21 downto 0) := (others=>'0'); 
signal pim_q_mult_22b           : std_logic_vector(21 downto 0) := (others=>'0'); 
signal pim_i_mult_16b           : std_logic_vector(15 downto 0) := (others=>'0'); 
signal pim_q_mult_16b           : std_logic_vector(15 downto 0) := (others=>'0'); 
signal pim_i_sub_17b            : std_logic_vector(16 downto 0) := (others=>'0'); 
signal pim_q_sub_17b            : std_logic_vector(16 downto 0) := (others=>'0'); 
signal pim_i_sub_16b            : std_logic_vector(15 downto 0) := (others=>'0'); 
signal pim_q_sub_16b            : std_logic_vector(15 downto 0) := (others=>'0'); 
signal rx_i_in_16b              : std_logic_vector(15 downto 0) := (others=>'0'); 
signal rx_q_in_16b              : std_logic_vector(15 downto 0) := (others=>'0'); 
signal rx_i_in_16b_dly          : std_logic_vector(15 downto 0) := (others=>'0'); 
signal rx_q_in_16b_dly          : std_logic_vector(15 downto 0) := (others=>'0'); 
signal cor_i_34b                : std_logic_vector(33 downto 0) := (others=>'0'); 
signal cor_q_34b                : std_logic_vector(33 downto 0) := (others=>'0'); 
signal cor_i_34b_dly            : std_logic_vector(33 downto 0) := (others=>'0'); 
signal cor_q_34b_dly            : std_logic_vector(33 downto 0) := (others=>'0'); 
signal cor_i_46b                : std_logic_vector(45 downto 0) := (others=>'0'); 
signal cor_q_46b                : std_logic_vector(45 downto 0) := (others=>'0'); 
signal counter_rst              : std_logic := '0';
signal end_of_blk               : std_logic := '0';
signal mu_sel_in                : std_logic_vector( 1 downto 0) := (others=>'0'); 
signal en_adapt_in              : std_logic := '0'; 
signal set_coef_in              : std_logic := '0'; 
signal rst_cnt_mux              : std_logic_vector(11 downto 0) := (others=>'0');
-- signal rst_cnt_d                : std_logic_vector(10 downto 0) := (others=>'0');

signal accum_i                  : std_logic_vector(45 downto 0) := (others=>'0');
signal accum_q                  : std_logic_vector(45 downto 0) := (others=>'0');
signal accum_i_out              : std_logic_vector(45 downto 0) := (others=>'0');
signal accum_q_out              : std_logic_vector(45 downto 0) := (others=>'0');
signal accum_i_out_50b          : std_logic_vector(49 downto 0) := (others=>'0');
signal accum_q_out_50b          : std_logic_vector(49 downto 0) := (others=>'0');

signal coef_i_in_sht_33b        : std_logic_vector(32 downto 0) := (others=>'0');
signal coef_i_in_sht_37b        : std_logic_vector(36 downto 0) := (others=>'0');
signal coef_i_in_sht_40b        : std_logic_vector(39 downto 0) := (others=>'0');
signal coef_i_in_sht_44b        : std_logic_vector(43 downto 0) := (others=>'0');
signal coef_i_in_33b_48b        : std_logic_vector(47 downto 0) := (others=>'0');
signal coef_i_in_37b_48b        : std_logic_vector(47 downto 0) := (others=>'0');
signal coef_i_in_40b_48b        : std_logic_vector(47 downto 0) := (others=>'0');
signal coef_i_in_44b_48b        : std_logic_vector(47 downto 0) := (others=>'0');
signal coef_q_in_sht_33b        : std_logic_vector(32 downto 0) := (others=>'0');
signal coef_q_in_sht_37b        : std_logic_vector(36 downto 0) := (others=>'0');
signal coef_q_in_sht_40b        : std_logic_vector(39 downto 0) := (others=>'0');
signal coef_q_in_sht_44b        : std_logic_vector(43 downto 0) := (others=>'0');
signal coef_q_in_33b_48b        : std_logic_vector(47 downto 0) := (others=>'0');
signal coef_q_in_37b_48b        : std_logic_vector(47 downto 0) := (others=>'0');
signal coef_q_in_40b_48b        : std_logic_vector(47 downto 0) := (others=>'0');
signal coef_q_in_44b_48b        : std_logic_vector(47 downto 0) := (others=>'0');

begin

    process ( CLK_PIMD )
    begin
        if ( rising_edge(CLK_PIMD) ) then
            rst_in              <= CE_CLR_IN;
            pim_i_in_16b        <= PIM_DATA_I_IN;
            pim_q_in_16b        <= PIM_DATA_Q_IN;
            pim_q_in_conj_17b   <= ('1'&x"0000") - (PIM_DATA_Q_IN(15) & PIM_DATA_Q_IN); -- 2's complement
            rx_i_in_16b         <= RX_DATA_I_IN;
            rx_q_in_16b         <= RX_DATA_Q_IN;
            counter_rst         <= CNT_RST_IN(0);
            mu_sel_in           <= MU_SELECT_IN;
            en_adapt_in         <= PNPC_EN_IN(0);
            set_coef_in         <= PNPC_SET_IN(0);
            pim_i_in_16b_d      <= pim_i_in_16b;
            pim_q_in_16b_d      <= pim_q_in_16b;
            pim_i_in_16b_d2     <= pim_i_in_16b_d;
            pim_q_in_16b_d2     <= pim_q_in_16b_d;

            if ( rst_in = '1' ) then
                coef_i_in_16b       <= (others=>'0');             
                coef_q_in_16b       <= (others=>'0');          
            else
                coef_i_in_16b       <= COEF_I_IN;             
                coef_q_in_16b       <= COEF_Q_IN;   
            end if;
        end if;
    end process;

    pim_q_in_conj_16b     <= pim_q_in_conj_17b(15 downto 0);

    -- 8 clk
    U_MULT_W_RND : COMPLEX_MULTIPLIER 
    generic map(
        DEVICE                   => DEVICE                       , 
        HOVS                     => HOVS                         ,                    
    
        INPUT_WIDTH              => 16                           , 
        RND_EN                   => TRUE                         , 
        RND_BIT                  => 13                           ,
        OUTPUT_WIDTH             => 22                           
        )
    port map(
        RST                      => rst_in                       , 
        CLK                      => CLK_PIMD                     , 
                                                                 
        DATA_VLD_IN              => '1'                          , 
        ADATA_I_IN               => pim_i_in_16b               ,
        ADATA_Q_IN               => pim_q_in_16b               ,
                                                               
        BDATA_I_IN               => coef_i_mwm_16b                ,
        BDATA_Q_IN               => coef_q_mwm_16b                ,
                                                                 
        DATA_VLD_OUT             => open                         ,
        DATA_I_OUT               => pim_i_mult_22b                ,
        DATA_Q_OUT               => pim_q_mult_22b                
        );
    -- 2 clk
    U_SAT_MWR_0_I : SAT_SIGN generic map(TRUE, 22, 16) port map('0', CLK_PIMD, pim_i_mult_22b, pim_i_mult_16b );            
    U_SAT_MWR_0_Q : SAT_SIGN generic map(TRUE, 22, 16) port map('0', CLK_PIMD, pim_q_mult_22b, pim_q_mult_16b );            
    -- 10 clk
    U_MPA5_D3_I  : SRL16E_DLY generic map(DEVICE, TRUE, 16, 10) port map (CLK_PIMD, rx_i_in_16b, rx_i_in_16b_dly);
    U_MPA5_D3_Q  : SRL16E_DLY generic map(DEVICE, TRUE, 16, 10) port map (CLK_PIMD, rx_q_in_16b, rx_q_in_16b_dly);

    -- 1 clk
    process ( CLK_PIMD )
    begin
        if ( rising_edge(CLK_PIMD) ) then
            PIM_I_OUT          <= pim_i_mult_16b;
            PIM_Q_OUT          <= pim_q_mult_16b;
            UL_DATA_DLY_I_OUT  <= rx_i_in_16b_dly;
            UL_DATA_DLY_Q_OUT  <= rx_q_in_16b_dly;

            pim_i_sub_17b       <= (rx_i_in_16b_dly(15) & rx_i_in_16b_dly) - (pim_i_mult_16b(15) & pim_i_mult_16b);
            pim_q_sub_17b       <= (rx_q_in_16b_dly(15) & rx_q_in_16b_dly) - (pim_q_mult_16b(15) & pim_q_mult_16b);
        end if;
    end process;
    -- 2 clk
    U_SAT_MWR_1_I : SAT_SIGN generic map(TRUE, 17, 16) port map('0', CLK_PIMD, pim_i_sub_17b, pim_i_sub_16b );            
    U_SAT_MWR_1_Q : SAT_SIGN generic map(TRUE, 17, 16) port map('0', CLK_PIMD, pim_q_sub_17b, pim_q_sub_16b );            
    
    -- 13 clk
    U_PIM_IN_DLY_I  : SRL16E_DLY generic map(DEVICE, TRUE, 16, 13) port map (CLK_PIMD, pim_i_in_16b,      pim_i_in_16b_dly);
    U_PIM_IN_DLY_Q  : SRL16E_DLY generic map(DEVICE, TRUE, 16, 13) port map (CLK_PIMD, pim_q_in_conj_16b, pim_q_in_conj_16b_dly);

    -- 8 clk
    U_MULT_W_CONJ : COMPLEX_MULTIPLIER 
    generic map(
        DEVICE                   => DEVICE                       , 
        HOVS                     => HOVS                         ,                    
    
        INPUT_WIDTH              => 16                           , 
        RND_EN                   => FALSE                        , 
        RND_BIT                  => 0                            ,
        OUTPUT_WIDTH             => 34                           
        )
    port map(
        RST                      => rst_in                       , 
        CLK                      => CLK_PIMD                     , 
                                                                 
        DATA_VLD_IN              => '1'                          , 
        ADATA_I_IN               => pim_i_sub_16b                ,
        ADATA_Q_IN               => pim_q_sub_16b                ,
                                                               
        BDATA_I_IN               => pim_i_in_16b_dly             ,
        BDATA_Q_IN               => pim_q_in_conj_16b_dly        ,
                                                                 
        DATA_VLD_OUT             => open                         ,
        DATA_I_OUT               => cor_i_34b                    ,
        DATA_Q_OUT               => cor_q_34b                
        );

    -- P_free_running_counter
    process ( CLK_PIMD ) 
    begin
        if ( rising_edge(CLK_PIMD) ) then
            if( counter_rst = '1' ) then
                rst_cnt_mux   <= (others=>'0');
            elsif ( rst_cnt_mux = x"800" ) then
                rst_cnt_mux   <= (others=>'0');
            elsif ( counter_rst = '0' ) then
                rst_cnt_mux   <= rst_cnt_mux + '1';
            end if;

            if ( rst_cnt_mux = C_COEF_UPDATE_DLY_OFFSET ) then
                end_of_blk    <= '1';
            else
                end_of_blk    <= '0';
            end if;

        end if;
    end process;

    -- 22 clk
    --U_COR_DLY_I  : SRLC32E_DLY generic map(DEVICE, TRUE, 34, 22) port map (CLK_PIMD, cor_i_34b, open, cor_i_34b_dly);
    -- P_ACCUM_I
    cor_i_46b <= sign_extension(cor_i_34b,46);
    process ( CLK_PIMD ) 
    begin
        if ( rst_in = '1' ) then
            accum_i        <= (others=>'0');
        elsif ( rising_edge(CLK_PIMD) ) then
            if ( end_of_blk = '0' ) then
                accum_i       <= accum_i + cor_i_46b;
            elsif( end_of_blk = '1' ) then
                accum_i_out   <= accum_i;
                accum_i       <= cor_i_46b;
            end if;

        end if;
    end process;

    -- 22 clk
    -- U_COR_DLY_Q  : SRLC32E_DLY generic map(DEVICE, TRUE, 34, 22) port map (CLK_PIMD, cor_q_34b, open, cor_q_34b_dly);
    -- P_ACCUM_Q
    cor_q_46b <= sign_extension(cor_q_34b,46);
    process ( rst_in, CLK_PIMD ) 
    begin
        if ( rst_in = '1' ) then
            accum_q        <= (others=>'0');
        elsif ( rising_edge(CLK_PIMD) ) then
            if ( end_of_blk = '0' ) then
                accum_q       <= accum_q + cor_q_46b;
            elsif( end_of_blk = '1' ) then
                accum_q_out   <= accum_q;
                accum_q       <= cor_q_46b;
            end if;

        end if;
    end process;

    -- divide by Mu I
    coef_i_in_sht_33b  <= coef_i_in_16b & ('0'&x"0000");
    coef_i_in_sht_37b  <= coef_i_in_16b & ('0'&x"00000");
    coef_i_in_sht_40b  <= coef_i_in_16b & (    x"000000");
    coef_i_in_sht_44b  <= coef_i_in_16b & (    x"0000000");
    coef_i_in_33b_48b  <= sign_extension(coef_i_in_sht_33b, 48);    
    coef_i_in_37b_48b  <= sign_extension(coef_i_in_sht_37b, 48);           
    coef_i_in_40b_48b  <= sign_extension(coef_i_in_sht_40b, 48);           
    coef_i_in_44b_48b  <= sign_extension(coef_i_in_sht_44b, 48);           
    process ( CLK_PIMD ) 
    begin
        if ( rising_edge(CLK_PIMD) ) then
            if ( mu_sel_in = "00" ) then
                coef_i_in_48b     <= coef_i_in_33b_48b;
            elsif ( mu_sel_in = "01" ) then
                coef_i_in_48b     <= coef_i_in_37b_48b;
            elsif ( mu_sel_in = "10" ) then
                coef_i_in_48b     <= coef_i_in_40b_48b;
            elsif ( mu_sel_in = "11" ) then
                coef_i_in_48b     <= coef_i_in_37b_48b;
            end if;
        end if;
    end process;
    -- divide by Mu Q
    coef_q_in_sht_33b  <= coef_q_in_16b & ('0'&x"0000");
    coef_q_in_sht_37b  <= coef_q_in_16b & ('0'&x"00000");
    coef_q_in_sht_40b  <= coef_q_in_16b & (    x"000000");
    coef_q_in_sht_44b  <= coef_q_in_16b & (    x"0000000");
    coef_q_in_33b_48b  <= sign_extension(coef_q_in_sht_33b, 48);    
    coef_q_in_37b_48b  <= sign_extension(coef_q_in_sht_37b, 48);           
    coef_q_in_40b_48b  <= sign_extension(coef_q_in_sht_40b, 48);           
    coef_q_in_44b_48b  <= sign_extension(coef_q_in_sht_44b, 48);           
    process ( CLK_PIMD ) 
    begin
        if ( rising_edge(CLK_PIMD) ) then
            if ( mu_sel_in = "00" ) then
                coef_q_in_48b     <= coef_q_in_33b_48b;
            elsif ( mu_sel_in = "01" ) then
                coef_q_in_48b     <= coef_q_in_37b_48b;
            elsif ( mu_sel_in = "10" ) then
                coef_q_in_48b     <= coef_q_in_40b_48b;
            elsif ( mu_sel_in = "11" ) then
                coef_q_in_48b     <= coef_q_in_37b_48b;
            end if;
        end if;
    end process;


--    coef_i_mux_48b <= coef_i_in_48b when (set_coef_in = '1') else coef_i_leaked_48b;
    coef_i_mux_48b         <= coef_i_in_48b when (set_coef_in = '1') else coef_i_leaked_48b_dly;
    coef_i_in_48b_lat_24b  <= coef_i_in_48b_lat(47 downto 24);
    coef_i_in_48b_lat_sft  <= sign_extension(coef_i_in_48b_lat_24b, 49);
    accum_i_out_50b        <= sign_extension(accum_i_out, 50);
    -- extended coef I
    -- 3 clk
    process ( CLK_PIMD ) 
    begin
        if ( rst_in = '1' ) then
            coef_i_in_48b_lat  <= (others=>'0');
        elsif ( rising_edge(CLK_PIMD) ) then
            if ( end_of_blk = en_adapt_in or set_coef_in = '1' ) then
                coef_i_in_48b_lat  <= coef_i_mux_48b;
            end if;

            coef_i_leaked_49b  <= (coef_i_in_48b_lat(47) & coef_i_in_48b_lat) - coef_i_in_48b_lat_sft;
            coef_i_leaked_50b  <= (coef_i_leaked_49b(48) & coef_i_leaked_49b) + accum_i_out_50b;
        end if;
    end process;
--    coef_q_mux_48b <= coef_q_in_48b when (set_coef_in = '1') else coef_q_leaked_48b;
    coef_q_mux_48b         <= coef_q_in_48b when (set_coef_in = '1') else coef_q_leaked_48b_dly;
    coef_q_in_48b_lat_24b  <= coef_q_in_48b_lat(47 downto 24);
    coef_q_in_48b_lat_sft  <= sign_extension(coef_q_in_48b_lat_24b, 49);
    accum_q_out_50b        <= sign_extension(accum_q_out, 50);
    -- extended coef I
    -- 3 clk
    process ( CLK_PIMD ) 
    begin
        if ( rst_in = '1' ) then
            coef_q_in_48b_lat  <= (others=>'0');
        elsif ( rising_edge(CLK_PIMD) ) then
            if ( end_of_blk = en_adapt_in or set_coef_in = '1' ) then
                coef_q_in_48b_lat  <= coef_q_mux_48b;
            end if;

            coef_q_leaked_49b  <= (coef_q_in_48b_lat(47) & coef_q_in_48b_lat) - coef_q_in_48b_lat_sft;
            coef_q_leaked_50b  <= (coef_q_leaked_49b(48) & coef_q_leaked_49b) + accum_q_out_50b;
        end if;
    end process;

    -- 2 clk
    U_LEAK_SAT_I : SAT_SIGN generic map(TRUE, 50, 48) port map('0', CLK_PIMD, coef_i_leaked_50b, coef_i_leaked_48b );            
    -- 5 clk
    U_COEF_DLY_I  : SRL16E_DLY generic map(DEVICE, TRUE, 48, 5) port map (CLK_PIMD, coef_i_leaked_48b, coef_i_leaked_48b_dly);
    -- 2 clk
    U_LEAK_SAT_Q : SAT_SIGN generic map(TRUE, 50, 48) port map('0', CLK_PIMD, coef_q_leaked_50b, coef_q_leaked_48b );            
    -- 5 clk
    U_COEF_DLY_Q  : SRL16E_DLY generic map(DEVICE, TRUE, 48, 5) port map (CLK_PIMD, coef_q_leaked_48b, coef_q_leaked_48b_dly);

    -- devide with Mu I
    U_DWM_RND_I_0 : RND_FUNC generic map ( "SYMMETRY", 17, 48, 32) port map ( CLK_PIMD, coef_i_leaked_48b, coef_i_lat_32b );
    U_DWM_RND_I_1 : RND_FUNC generic map ( "SYMMETRY", 21, 48, 28) port map ( CLK_PIMD, coef_i_leaked_48b, coef_i_lat_28b );
    U_DWM_RND_I_2 : RND_FUNC generic map ( "SYMMETRY", 24, 48, 25) port map ( CLK_PIMD, coef_i_leaked_48b, coef_i_lat_25b );
    U_DWM_RND_I_3 : RND_FUNC generic map ( "SYMMETRY", 28, 48, 21) port map ( CLK_PIMD, coef_i_leaked_48b, coef_i_lat_21b );
    U_DWM_SAT_I_0 : SAT_SIGN generic map(TRUE, 32, 16) port map('0', CLK_PIMD, coef_i_lat_32b, coef_i_lat_32b_16b );            
    U_DWM_SAT_I_1 : SAT_SIGN generic map(TRUE, 28, 16) port map('0', CLK_PIMD, coef_i_lat_28b, coef_i_lat_28b_16b );            
    U_DWM_SAT_I_2 : SAT_SIGN generic map(TRUE, 25, 16) port map('0', CLK_PIMD, coef_i_lat_25b, coef_i_lat_25b_16b );            
    U_DWM_SAT_I_3 : SAT_SIGN generic map(TRUE, 21, 16) port map('0', CLK_PIMD, coef_i_lat_21b, coef_i_lat_21b_16b );            
    process ( CLK_PIMD ) 
    begin
        if ( rising_edge(CLK_PIMD) ) then
            if ( mu_sel_in = "00" ) then
                coef_i_mwm_16b     <= coef_i_lat_32b_16b;
            elsif ( mu_sel_in = "01" ) then
                coef_i_mwm_16b     <= coef_i_lat_28b_16b;
            elsif ( mu_sel_in = "10" ) then
                coef_i_mwm_16b     <= coef_i_lat_25b_16b;
            elsif ( mu_sel_in = "11" ) then
                coef_i_mwm_16b     <= coef_i_lat_21b_16b;
            end if;
        end if;
    end process;
    -- devide with Mu Q
    U_DWM_RND_Q_0 : RND_FUNC generic map ( "SYMMETRY", 17, 48, 32) port map ( CLK_PIMD, coef_q_leaked_48b, coef_q_lat_32b );
    U_DWM_RND_Q_1 : RND_FUNC generic map ( "SYMMETRY", 21, 48, 28) port map ( CLK_PIMD, coef_q_leaked_48b, coef_q_lat_28b );
    U_DWM_RND_Q_2 : RND_FUNC generic map ( "SYMMETRY", 24, 48, 25) port map ( CLK_PIMD, coef_q_leaked_48b, coef_q_lat_25b );
    U_DWM_RND_Q_3 : RND_FUNC generic map ( "SYMMETRY", 28, 48, 21) port map ( CLK_PIMD, coef_q_leaked_48b, coef_q_lat_21b );
    U_DWM_SAT_Q_0 : SAT_SIGN generic map(TRUE, 32, 16) port map('0', CLK_PIMD, coef_q_lat_32b, coef_q_lat_32b_16b );            
    U_DWM_SAT_Q_1 : SAT_SIGN generic map(TRUE, 28, 16) port map('0', CLK_PIMD, coef_q_lat_28b, coef_q_lat_28b_16b );            
    U_DWM_SAT_Q_2 : SAT_SIGN generic map(TRUE, 25, 16) port map('0', CLK_PIMD, coef_q_lat_25b, coef_q_lat_25b_16b );            
    U_DWM_SAT_Q_3 : SAT_SIGN generic map(TRUE, 21, 16) port map('0', CLK_PIMD, coef_q_lat_21b, coef_q_lat_21b_16b );            

    process ( CLK_PIMD ) 
    begin
        if ( rising_edge(CLK_PIMD) ) then
            if ( mu_sel_in = "00" ) then
                coef_q_mwm_16b     <= coef_q_lat_32b_16b;
            elsif ( mu_sel_in = "01" ) then
                coef_q_mwm_16b     <= coef_q_lat_28b_16b;
            elsif ( mu_sel_in = "10" ) then
                coef_q_mwm_16b     <= coef_q_lat_25b_16b;
            elsif ( mu_sel_in = "11" ) then
                coef_q_mwm_16b     <= coef_q_lat_21b_16b;
            end if;
        end if;
    end process;

    COEF_I_OUT  <= coef_i_mwm_16b;
    COEF_Q_OUT  <= coef_q_mwm_16b;

end arc_PIM_PHASE_COMP_LMS;

