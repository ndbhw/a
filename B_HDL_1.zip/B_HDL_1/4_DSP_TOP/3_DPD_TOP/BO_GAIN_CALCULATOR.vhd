----------------------------------------------------------------------------
-- Designer   : Kyoung Heo, (k1340.heo@samsung.com)
-- Block Name : BO_GAIN_CALCULATOR 
-- Function   : Back Off Gain Calculation 
-- Revision   : - ver 1.0, First Relase, 16.04.18
----------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity BO_GAIN_CALCULATOR is
generic(
    DEVICE                      : string  := "7SERIES"  -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    );
port(
    CLK                         : in  std_logic;

    DATA_IN                     : in  std_logic_vector(31 downto 0);
    GAIN_IN                     : in  std_logic_vector(15 downto 0);

    DATA_OUT                    : out std_logic_vector(31 downto 0)
    );
end BO_GAIN_CALCULATOR;

architecture arc_BO_GAIN_CALCULATOR of BO_GAIN_CALCULATOR is

component DSP48E_MULT is
generic(
    DEVICE                      : string  := "ULTRASCALE";
    DSP48_MODECTRL              : boolean :=       FALSE ;
    DSP48_PREADDER_USE          : boolean :=        TRUE ;
    DSP48_PREADDER_MODE         : string  :=        "ADD";  -- "ADD" or "SUB" 
    DSP48_PCIN_USE              : boolean :=       FALSE ;
    DSP48_PCOUT_USE             : boolean :=       FALSE ;

    A_nREG                      : integer :=           2 ;  -- 0, 1, 2
    B_nREG                      : integer :=           2 ;  -- 0, 1, 2

    C_EN                        : boolean :=        TRUE ;
    RND_SYMMETRY                : boolean :=       FALSE 
    );
port(
    CLK                         : in  std_logic;

    ALUMODE_IN                  : in  std_logic_vector( 3 downto 0);
    OPMODE_IN                   : in  std_logic_vector( 8 downto 0);

    C_IN                        : in  std_logic_vector(47 downto 0);
    A_IN                        : in  std_logic_vector(29 downto 0);
    D_IN                        : in  std_logic_vector(26 downto 0);
    B_IN                        : in  std_logic_vector(17 downto 0);

    P_CIN                       : in  std_logic_vector(47 downto 0);
    P_COUT                      : out std_logic_vector(47 downto 0);

    P_OUT                       : out std_logic_vector(47 downto 0);
    CRRY_OUT                    : out std_logic
    );
end component;

component RND_FUNC is
generic(
    RND_STYLE                   : string := "SYMMETRY";
    RND_BIT                     : natural;
    INPUT_BIT                   : natural;
    OUTPUT_BIT                  : natural
    );
port(
    CLK                         : in  std_logic;

    DATA_IN                     : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT                    : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

component SAT_FUNC is
generic(
    SIGN_UNSIGN                 : string  := "S"; -- "S" : Signed, "U" : Unsigned
    INPUT_BIT                   : natural :=  18;
    OUTPUT_BIT                  : natural :=  16 
    );
port( 
    CLK                         : in  std_logic;
    DATA_IN                     : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT                    : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

signal uns_gain_val             : std_logic_vector(16 downto 0);
signal uns_data_l               : std_logic_vector(16 downto 0);
signal uns_data_h               : std_logic_vector(16 downto 0);

signal se_gain_val              : std_logic_vector(29 downto 0);
signal se_data_l                : std_logic_vector(17 downto 0);
signal se_data_h                : std_logic_vector(17 downto 0);

signal result_l                 : std_logic_vector(47 downto 0);
signal result_h                 : std_logic_vector(47 downto 0);

signal mult_low                 : std_logic_vector(49 downto 0);
signal mult_high                : std_logic_vector(49 downto 0);

signal multout                  : std_logic_vector(50 downto 0);

signal rnd_out                  : std_logic_vector(33 downto 0);
signal sat_out                  : std_logic_vector(31 downto 0);

constant zeros                  : std_logic_vector(15 downto 0) := (others => '0');

begin

    -- Unsigned Data
    uns_gain_val <= '0' & GAIN_IN;
    uns_data_l    <= '0' & DATA_IN(15 downto  0);
    uns_data_h    <= '0' & DATA_IN(31 downto 16);

    -- Positive Sign Extention 
    se_gain_val  <= sign_extension(uns_gain_val, 30);
    se_data_l    <= sign_extension(uns_data_l  , 18);
    se_data_h    <= sign_extension(uns_data_h  , 18);

    -- DATA_IN : I^2+Q^2 >= 0
    U_High_MULT : DSP48E_MULT generic map(DEVICE, FALSE, FALSE, "ADD", FALSE, FALSE, 2, 2, FALSE, FALSE) port map(CLK, x"0", (others => '0'), (others => '0'), se_gain_val, (others => '0'), se_data_h, (others => '0'), open, result_h, open); 
    U_Low_MULT  : DSP48E_MULT generic map(DEVICE, FALSE, FALSE, "ADD", FALSE, FALSE, 2, 2, FALSE, FALSE) port map(CLK, x"0", (others => '0'), (others => '0'), se_gain_val, (others => '0'), se_data_l, (others => '0'), open, result_l, open); 

    mult_low  <= "00" & result_l;   
    mult_high <= result_h(33 downto 0) & zeros;   

    P_Multiplier_Result : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            multout <= (mult_high(49)&mult_high) + (mult_low(49)&mult_low);     
        end if;
    end process;
     
    U_15b_RND : RND_FUNC generic map("SYMMETRY",15,48,34) port map(CLK, multout(47 downto 0), rnd_out);
    U_32b_SAT : SAT_FUNC generic map("S", 34, 32) port map(CLK, rnd_out, sat_out);

    DATA_OUT <= sat_out;

end arc_BO_GAIN_CALCULATOR;
