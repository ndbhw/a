library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

-- just 2 clocking
-- Latency : 2 Clocks @ CLK_B 
entity MULTIBIT_CDC is
generic(
    BIT_WIDTH  : natural :=    16
    );
port(
    DATA_A_IN  : in  std_logic_vector(BIT_WIDTH-1 downto 0);

    CLK_B      : in  std_logic;
    DATA_B_OUT : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end MULTIBIT_CDC;

architecture arc_MULTIBIT_CDC of MULTIBIT_CDC is

signal data_aclk_d1   : std_logic_vector(BIT_WIDTH-1 downto 0);
signal data_bclk_cdc  : std_logic_vector(BIT_WIDTH-1 downto 0);

begin
    
    -- Clock B Domain
    P_Destination_Data_CDC : process(CLK_B) begin
        if (CLK_B'event) and (CLK_B = '1') then
            data_aclk_d1 <= DATA_A_IN;  
            data_bclk_cdc <= data_aclk_d1;
        end if;
    end process;

    DATA_B_OUT <= data_bclk_cdc;

end arc_MULTIBIT_CDC;

