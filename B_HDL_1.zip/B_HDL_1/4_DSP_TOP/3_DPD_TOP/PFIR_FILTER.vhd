-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name : PFIR_FILTER

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity PFIR_FILTER is
generic(
    DEVICE         : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    PIM_MODE       : boolean :=     TRUE ;    
    HOVS           : natural :=        2 ;
    SYMMETRY       : string  :=    "EVEN";
    COEF_FIX       : boolean :=     TRUE ;
    COEF_NUM       : natural :=       39 ;
    RND_BIT        : natural :=       15
    );
port(
    RST_DSP        : in  std_logic;
    CLK_DSP        : in  std_logic;

    DATA_VLD_IN    : in  std_logic;
    DATA_I_IN      : in  std_logic_vector(15 downto 0);
    DATA_Q_IN      : in  std_logic_vector(15 downto 0);

    BYPASS_IN      : in  std_logic;

    DATA_VLD_OUT   : out std_logic;
    DATA_I_OUT     : out std_logic_vector(15 downto 0);
    DATA_Q_OUT     : out std_logic_vector(15 downto 0);

    RST_CPU        : in  std_logic;
    CLK_CPU        : in  std_logic;

    COEF_WR_EN     : in  std_logic;                     -- coefficient write enable(indirect)
    COEF_RD_EN     : in  std_logic;                     -- coefficient write done(indirect)
    COEF_WR_DN     : in  std_logic;                     -- coefficient read  enable(indirect)
    COEF_ADDR      : in  std_logic_vector( 7 downto 0); -- coefficient write address(indirect) 
    COEF_WR_DATA   : in  std_logic_vector(15 downto 0); -- coefficient write data(indirect) 
    COEF_RD_DATA   : out std_logic_vector(15 downto 0)  -- coefficient read  data(indirect) 
    );
end PFIR_FILTER;

architecture arc_PFIR_FILTER of PFIR_FILTER is

component RST_SYNC is
generic(
    DLY_NUM           : natural := 3;    -- Number of delay.
    MAX_FANOUT_NUM    : integer := 200   -- Number of maximum fanout
    );
port(
    RST_IN            : in  std_logic;   -- Active high asynchronous reset
    CLK               : in  std_logic;   -- clock to be sync'ed to
    RST_OUT           : out std_logic    -- "Synchronised" reset signal
    );         
end component;

component INDIRECT_COEF_UPDATE is
generic(
    COEF_NUM      : natural := 39;
    HS_MODE       : boolean := FALSE
    );
port(
    RST_CPU       : in  std_logic;
    CLK_CPU       : in  std_logic;

    COEF_WR_EN    : in  std_logic;                     -- coefficient write enable(indirect)
    COEF_RD_EN    : in  std_logic;                     -- coefficient write done(indirect)
    COEF_WR_DN    : in  std_logic;                     -- coefficient read  enable(indirect)
    COEF_ADDR     : in  std_logic_vector( 7 downto 0); -- coefficient write address(indirect) 
    COEF_WR_DATA  : in  std_logic_vector(15 downto 0); -- coefficient write data(indirect) 
    COEF_RD_DATA  : out std_logic_vector(15 downto 0); -- coefficient read  data(indirect) 

    RST_DSP       : in  std_logic;
    CLK_DSP       : in  std_logic;

    FIR_COEF      : out std_logic_array16(COEF_NUM-1 downto 0)
    );
end component;

component REAL_FIR_FILTER_HOVS1 is
generic(
    DEVICE         : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    SYMMETRY       : string  :=    "EVEN";
    COEF_NUM       : natural :=       39 ;
    RND_BIT        : natural :=       15
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;

    COEFFICIENT    : in  std_logic_array16(COEF_NUM-1 downto 0);
    DATA_VLD_IN    : in  std_logic;
    DATA_IN        : in  std_logic_vector(15 downto 0);

    DATA_VLD_OUT   : out std_logic;
    DATA_OUT       : out std_logic_vector(15 downto 0)
    );
end component;

component REAL_FIR_FILTER_HOVS2 is
generic(
    DEVICE         : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    SYMMETRY       : string  :=    "EVEN";
    COEF_NUM       : natural :=       39 ;
    RND_BIT        : natural :=       15
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;

    COEFFICIENT    : in  std_logic_array16(COEF_NUM-1 downto 0);
    DATA_VALID_IN  : in  std_logic;
    DATA_IN        : in  std_logic_vector(15 downto 0);

    DATA_VALID_OUT : out std_logic;
    DATA_OUT       : out std_logic_vector(15 downto 0)
    );
end component;

-- constant coef39_set      : std_logic_array16(38 downto 0)         := (x"4D18",x"F0EE",x"FEF8",x"0791",x"F74B",x"0679",x"FD4E",x"FF06",
--                                                                       x"035B",x"FC10",x"02EF",x"FEF6",x"FF20",x"021A",x"FDB0",x"019B",
--                                                                       x"FF96",x"FF43",x"016A",x"FE90",x"00E9",x"FFE0",x"FF6C",x"00F1",
--                                                                       x"FF1C",x"0082",x"FFFF",x"FF96",x"0099",x"FF79",x"0047",x"0006",
--                                                                       x"FFBF",x"0058",x"FFB4",x"002A",x"FFFB",x"FFED",x"0019");

-- DPD
constant coef39_set       : std_logic_array16(38 downto 0)         := (x"4E7A",x"ED6C",x"0364",x"03C8",x"F921",x"072E",x"FA60",x"0317",
                                                                       x"FF99",x"FE3A",x"0307",x"FCC3",x"028D",x"FEB2",x"FFED",x"0136",
                                                                       x"FE29",x"01E1",x"FE99",x"009F",x"0037",x"FF21",x"0132",x"FED9",
                                                                       x"00CD",x"FFB8",x"FFC3",x"00A0",x"FF37",x"00B5",x"FF8F",x"0015",
                                                                       x"0045",x"FF78",x"00A8",x"FF5B",x"008B",x"FF74",x"FFF0");
                                                                       
--constant coef39_set       : std_logic_array16(38 downto 0)         := (x"50F6",x"E667",x"0DBE",x"F7D6",x"04C1",x"FD98",x"00B2",x"0090",
--                                                                       x"FE86",x"021C",x"FD80",x"02B1",x"FD4A",x"0297",x"FDA3",x"020E",
--                                                                       x"FE4E",x"014E",x"FF16",x"0089",x"FFD0",x"FFE2",x"005F",x"FF6F",
--                                                                       x"00B4",x"FF37",x"00D1",x"FF32",x"00C2",x"FF51",x"0097",x"FF83",
--                                                                       x"0062",x"FFB7",x"0032",x"FFE0",x"0012",x"FFF6",x"FFA5");

-- DPD B2
constant coef30_set       : std_logic_array16(29 downto 0)         := (x"1B6D",x"195C",x"13BB",x"0C0E",x"044C",x"FE40",x"FAFB",x"FA9E",
                                                                       x"FC6A",x"FF20",x"0182",x"02BD",x"0299",x"0174",x"FFF8",x"FECF",
                                                                       x"FE60",x"FEB0",x"FF76",x"0049",x"00D0",x"00E3",x"0094",x"001B",
                                                                       x"FFB2",x"FF82",x"FF8E",x"FFBE",x"FFEF",x"00AA");
-- DPD B2
-- constant coef24_set       : std_logic_array16(23 downto 0)         := (x"4F87",x"EA81",x"0780",x"FF6D",x"FCC1",x"0511",x"FA90",x"04C6",
--                                                                        x"FC86",x"01EA",x"FF9B",x"FF28",x"01AB",x"FDF6",x"0201",x"FE55",
--                                                                        x"012A",x"FF61",x"0025",x"0033",x"FF9C",x"0070",x"FF9E",x"006D");

-- DPD
constant coef24_set       : std_logic_array16(23 downto 0)         := (x"508E",x"E794",x"0BE6",x"FA2E",x"021E",x"004D",x"FE26",x"02C0",
                                                                       x"FCDB",x"0327",x"FD1F",x"026D",x"FE20",x"014E",x"FF39",x"0054",
                                                                       x"0004",x"FFC0",x"0061",x"FF94",x"0066",x"FFAB",x"0040",x"FFC1");

-- -- DPD B66
-- constant coef24_set       : std_logic_array16(23 downto 0)         := (x"4ABD",x"F6DC",x"F8AC",x"0AEB",x"F884",x"0183",x"0340",x"FB32",
--                                                                        x"0349",x"FFA7",x"FDF3",x"02B8",x"FE4C",x"FFF7",x"015A",x"FE68",
--                                                                        x"00DA",x"0045",x"FEE4",x"0153",x"FF02",x"0072",x"FFF8",x"FFB3");

constant coef14_set       : std_logic_array16(13 downto 0)         := (x"0082",x"FFFF",x"FF96",x"0099",x"FF79",x"0047",x"0006",
                                                                       x"FFBF",x"0058",x"FFB4",x"002A",x"FFFB",x"FFED",x"0019");

constant coef39_even_set       : std_logic_array16(38 downto 0)         := (x"4C80",x"F299",x"FD01",x"08F6",x"F711",x"0573",x"FF1D",x"FD3C",
                                                                       x"045A",x"FC43",x"01A9",x"00B8",x"FDA6",x"02AC",x"FE3A",x"003F",
                                                                       x"0126",x"FE2D",x"0199",x"FF4D",x"FFA0",x"0122",x"FEB8",x"00D8",
                                                                       x"FFE8",x"FF68",x"00EC",x"FF35",x"0055",x"0037",x"FF67",x"00A8",
                                                                       x"FF97",x"FFFB",x"006D",x"FF4B",x"00A5",x"FF34",x"0031");
								       
-- PIM B2
constant pim_coef39_odd_set   : std_logic_array16(38 downto 0)         :=  (x"2000",x"1CC7",x"1448",x"0981",x"FFFF",x"FA66",x"F97B",x"FC1D",
                                                                        x"0002",x"02ED",x"03A2",x"0245",x"FFFC",x"FE2A",x"FDAF",x"FE8A",
                                                                        x"0007",x"013A",x"018B",x"00F7",x"FFF7",x"FF2A",x"FEF7",x"FF5F",
                                                                        x"000B",x"0091",x"00AE",x"0065",x"FFF4",x"FFA0",x"FF92",x"FFC3",
                                                                        x"000B",x"003E",x"0048",x"002C",x"FFF4",x"FF7F",
                                                                        x"002D");

-- -- PIM B66
-- constant coef39_odd_set   : std_logic_array16(38 downto 0)         :=  (x"2A3D",x"2308",x"11C5",x"006C",x"F78E",x"F8F2",x"FF98",x"048E",
--                                                                         x"0448",x"0061",x"FD0E",x"FD0C",x"FFA8",x"020C",x"0226",x"004E",
--                                                                         x"FE87",x"FE67",x"FFBD",x"0112",x"0131",x"0037",x"FF38",x"FF1E",
--                                                                         x"FFD5",x"0091",x"00A5",x"0020",x"FF98",x"FF8A",x"FFE9",x"0049",
--                                                                         x"0054",x"0011",x"FFCC",x"FFBC",x"FFEC",x"0078",x"FFDA");

-- -- ATnT PIM 39coef odd B25 65Mhz Odd 77 Tap
-- constant coef39_odd_set   : std_logic_array16(38 downto 0)         :=  ( x"19CD", x"181B", x"136C", x"0CD5", x"05CE", x"FFCC", x"FBE0", x"FA75",
--                                                                              x"FB49", x"FD8E", x"0036", x"024B", x"0333", x"02CF", x"0176", x"FFC6", 
--                                                                              x"FE66", x"FDCA", x"FE12", x"FF09", x"0040", x"013D", x"01A9", x"0168", 
--                                                                              x"00A5", x"FFB6", x"FEFA", x"FEB5", x"FEF8", x"FF9C", x"005A", x"00E3", 
--                                                                              x"0103", x"00B3", x"001C", x"FF85", x"FF36", x"FF5E", x"FFFD");
-- Orange(2.1G) PIM 39coef odd B1 60Mhz ODD 77 Tap
-- constant coef39_odd_set   : std_logic_array16(38 downto 0)         :=  ( x"180E", x"16A9", x"12C7", x"0D35", x"0712", x"0182", x"FD70", x"FB56",
--                                                                             x"FB2E", x"FC83", x"FE9A", x"00AF", x"0223", x"02A8", x"0242", x"013A", 
--                                                                             x"FFFD", x"FEF7", x"FE6F", x"FE7A", x"FEFD", x"FFBB", x"0070", x"00E4", 
--                                                                             x"00FF", x"00C7", x"005C", x"FFE7", x"FF8D", x"FF66", x"FF74", x"FFA8", 
--                                                                             x"FFEB", x"0027", x"004C", x"0055", x"0048", x"002F", x"0015");
-- Orange(1.8G) PIM 39coef odd B3 75Mhz ODD 77 tap
constant coef39_odd_set   : std_logic_array16(38 downto 0)         :=  ( x"1C83", x"1A37", x"13FE", x"0BA0", x"035E", x"FD39", x"FA4C", x"FA8E", 
                                                                             x"FCF9", x"000D", x"0267", x"033C", x"0285", x"00DF", x"FF29", x"FE1F", 
                                                                             x"FE14", x"FEDE", x"0001", x"00F1", x"0150", x"010F", x"0065", x"FFAE", 
                                                                             x"FF3B", x"FF2F", x"FF7D", x"FFF3", x"0058", x"0085", x"0074", x"0038", 
                                                                             x"FFF4", x"FFC3", x"FFB3", x"FFC0", x"FFDB", x"FFF4", x"0003");
-- Orange(2.1G) PIM 31coef odd B1 60Mhz ODD 61 Tap
constant coef31_odd_set   : std_logic_array16(30 downto 0)         :=  ( x"18EE", x"1762", x"1316", x"0D00", x"066B", x"00A7", x"FCAF", x"FAF2", 
                                                                            x"FB48", x"FD0F", x"FF64", x"016D", x"0295", x"02A7", x"01D4", x"008A", 
                                                                            x"FF4C", x"FE81", x"FE5B", x"FEC9", x"FF8D", x"0057", x"00E0", x"0106", 
                                                                            x"00CD", x"0059", x"FFDC", x"FF83", x"FF66", x"FF82", x"FFC2");
-- Orange(1.8G) PIM 31coef odd B3 75Mhz ODD 61 tap
-- constant coef31_odd_set   : std_logic_array16(30 downto 0)         :=  ( x"1D91", x"1B05", x"142B", x"0B17", x"0261", x"FC41", x"F9CE", x"FAC3", 
--                                                                             x"FDC5", x"010E", x"0323", x"035C", x"01FE", x"FFF5", x"FE4C", x"FDB7", 
--                                                                             x"FE4D", x"FF98", x"00E0", x"018A", x"015F", x"0093", x"FF9F", x"FEFF", 
--                                                                             x"FEF4", x"FF6F", x"001E", x"00A3", x"00BE", x"006A", x"FFD9");
-- RF2221 B8
constant pim_coef31_odd_set0   : std_logic_array16(30 downto 0)         :=  ( x"145F", x"1385", x"1119", x"0D79", x"092C", x"04CE", x"00F2", x"FE08", 
                                                                              x"FC4F", x"FBCD", x"FC54", x"FD90", x"FF1B", x"0091", x"01A6", x"022F", 
                                                                              x"0223", x"019F", x"00D3", x"FFF6", x"FF3E", x"FECC", x"FEAE", x"FEDE", 
                                                                              x"FF43", x"FFBF", x"0030", x"0081", x"00A5", x"009E", x"0077");
-- RF2221 B20
constant pim_coef31_odd_set1   : std_logic_array16(30 downto 0)         :=  ( x"112B", x"10A7", x"0F2B", x"0CE1", x"0A06", x"06E8", x"03D5", x"0117", 
                                                                              x"FEE6", x"FD67", x"FCA4", x"FC92", x"FD0F", x"FDEF", x"FEFE", x"0009", 
                                                                              x"00E9", x"0180", x"01C4", x"01B5", x"0163", x"00E5", x"0055", x"FFCD", 
                                                                              x"FF61", x"FF1C", x"FF02", x"FF10", x"FF3A", x"FF75", x"FFB3");
-- RF2221 B8
constant pim_coef12_odd_set0   : std_logic_array16(11 downto 0) :=  (  x"1318", x"125F", x"1050", x"0D39", x"0989", x"05C3", x"025C", x"FFB2", 
                                                                       x"FDF7", x"FD31", x"FD3E", x"FDDD");
-- RF2221 B20                                                                               
constant pim_coef12_odd_set1   : std_logic_array16(11 downto 0) :=  (  x"11DC", x"1147", x"0F99", x"0D06", x"09DC", x"0677", x"0334", x"0066", 
                                                                       x"FE4A", x"FCFD", x"FC82", x"FCBE");

-- PIM B2
constant pim_coef22_set       : std_logic_array16(21 downto 0)         := (x"1709", x"15C4", x"1239", x"0D22", x"077F", x"0256", x"FE77", x"FC4E", 
                                                                           x"FBD8", x"FCB1", x"FE3F", x"FFE2", x"011B", x"01AD", x"0198", x"0110", 
                                                                           x"005E", x"FFC2", x"FF61", x"FF33", x"FF09", x"00B7");
-- -- PIM B66
-- constant coef32_set       : std_logic_array16(31 downto 0)         :=  (x"2B07",x"2367",x"1155",x"FFA4",x"F742",x"F970",x"0059",x"04C5",
--                                                                         x"03BE",x"FFAC",x"FCEB",x"FD9B",x"004E",x"021C",x"0195",x"FFBA",
--                                                                         x"FE88",x"FEF4",x"003D",x"0103",x"00AD",x"FFCC",x"FF51",x"FF96",
--                                                                         x"002A",x"0071",x"003F",x"FFE1",x"FFB4",x"FFC9",x"0061",x"FFF7");

signal fir_coef           : std_logic_array16(COEF_NUM-1 downto 0);

signal rst_synch_cpu      : std_logic;
signal rst_synch_dsp      : std_logic;

signal fir_out_vld        : std_logic;
signal fir_out_i          : std_logic_vector(15 downto 0);
signal fir_out_q          : std_logic_vector(15 downto 0);

signal bypass_sh          : std_logic_vector( 2 downto 0);

begin

    U_RST_SYNC_CPUCLK : RST_SYNC generic map(4, 200) port map(RST_CPU, CLK_CPU, rst_synch_cpu); 
    U_RST_SYNC_DSPCLK : RST_SYNC generic map(4, 200) port map(RST_DSP, CLK_DSP, rst_synch_dsp); 

    G_Coef_Set_Write_Read : if (COEF_FIX = FALSE) generate begin
        U_COEF_Write_N_Read : INDIRECT_COEF_UPDATE 
        generic map(
            COEF_NUM      => COEF_NUM     ,
            HS_MODE       => TRUE                	    
            )
        port map(
            RST_CPU       => rst_synch_cpu ,
            CLK_CPU       => CLK_CPU      ,
        
            COEF_WR_EN    => COEF_WR_EN   ,
            COEF_RD_EN    => COEF_RD_EN   ,
            COEF_WR_DN    => COEF_WR_DN   ,
            COEF_ADDR     => COEF_ADDR    ,
            COEF_WR_DATA  => COEF_WR_DATA ,
            COEF_RD_DATA  => COEF_RD_DATA ,
        
            RST_DSP       => rst_synch_dsp ,
            CLK_DSP       => CLK_DSP      ,
        
            FIR_COEF      => fir_coef      
            );
    end generate;

    G_Coef_Set_Fix : if (COEF_FIX = TRUE) generate begin
        COEF_RD_DATA <= (others => '0');  
 
        G_DPD_COEF : if (PIM_MODE = FALSE) generate begin
            G_Coef14_Set : if (COEF_NUM = 14) generate begin      
                fir_coef     <= coef14_set;        
            end generate;

            G_Coef24_Set : if (COEF_NUM = 24) generate begin      
                fir_coef     <= coef24_set;        
            end generate;

            G_Coef39_Set : if (COEF_NUM = 39) generate begin      
                G_Coef39_Even : if (SYMMETRY = "EVEN") generate begin
                    fir_coef     <= coef39_set;        
                end generate;

                G_Coef39_Odd : if (SYMMETRY = "ODD") generate begin
                    fir_coef     <= coef39_odd_set;        
                end generate;
            end generate;
        end generate;
	
        G_PIM_COEF : if (PIM_MODE = TRUE) generate begin
            G_Coef12_Set : if (COEF_NUM = 12) generate begin
                fir_coef     <= pim_coef12_odd_set0;
            end generate;

            G_Coef14_Set : if (COEF_NUM = 14) generate begin
                fir_coef     <= coef14_set;        
            end generate;
    
            G_Coef24_Set : if (COEF_NUM = 24) generate begin
                fir_coef     <= coef24_set;        
            end generate;
            G_Coef22_Set : if (COEF_NUM = 22) generate begin
                fir_coef     <= pim_coef22_set;        
            end generate;
    
            G_Coef31_Set : if (COEF_NUM = 31) generate begin
                fir_coef     <= pim_coef31_odd_set0;
            end generate;

            G_Coef39_Set : if (COEF_NUM = 39) generate begin
                G_Coef39_Even : if (SYMMETRY = "EVEN") generate begin
                    fir_coef     <= coef39_even_set;        
                end generate;

                G_Coef39_Odd : if (SYMMETRY = "ODD") generate begin
                    fir_coef     <= pim_coef39_odd_set;
                end generate;
            end generate;
        end generate;

    end generate;

    G_LPF_HOVS1 : if (HOVS = 1) generate begin
        U_FIR_I_Filter_HOVS1 : REAL_FIR_FILTER_HOVS1 generic map(DEVICE, SYMMETRY, COEF_NUM, RND_BIT) port map('0', CLK_DSP, fir_coef, DATA_VLD_IN, DATA_I_IN, fir_out_vld, fir_out_i); 
        U_FIR_Q_Filter_HOVS1 : REAL_FIR_FILTER_HOVS1 generic map(DEVICE, SYMMETRY, COEF_NUM, RND_BIT) port map('0', CLK_DSP, fir_coef, DATA_VLD_IN, DATA_Q_IN, open       , fir_out_q); 
    end generate;                                                                            
                                                                                             
    G_LPF_HOVS2 : if (HOVS = 2) generate begin                                               
        U_FIR_I_Filter_HOVS2 : REAL_FIR_FILTER_HOVS2 generic map(DEVICE, SYMMETRY, COEF_NUM, RND_BIT) port map('0', CLK_DSP, fir_coef, DATA_VLD_IN, DATA_I_IN, fir_out_vld, fir_out_i);
        U_FIR_Q_Filter_HOVS2 : REAL_FIR_FILTER_HOVS2 generic map(DEVICE, SYMMETRY, COEF_NUM, RND_BIT) port map('0', CLK_DSP, fir_coef, DATA_VLD_IN, DATA_Q_IN, open       , fir_out_q);
    end generate;

    P_PFIR_FILTER_Bypass_HS : process(CLK_DSP) begin
        if (CLK_DSP'event) and (CLK_DSP = '1') then
            bypass_sh <= bypass_sh(1 downto 0) & BYPASS_IN;
            if (rst_synch_dsp = '1') then
                DATA_I_OUT <= (others => '0');  
                DATA_Q_OUT <= (others => '0');  
            else
                if (bypass_sh(2) = '1') then
                    DATA_I_OUT <= DATA_I_IN;  
                    DATA_Q_OUT <= DATA_Q_IN;  
                else
                    DATA_I_OUT <= fir_out_i;  
                    DATA_Q_OUT <= fir_out_q;  
                end if;
            end if;
        end if;
    end process;

    DATA_VLD_OUT <= DATA_VLD_IN;

end arc_PFIR_FILTER;




