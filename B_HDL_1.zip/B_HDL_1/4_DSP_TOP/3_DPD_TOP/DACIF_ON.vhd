-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Revision 0.02 - Remove the debouncing logic because it is already applied IQ_OFF in SIG_SUS Block 
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
-- library unisim;
-- use unisim.vcomponents.all;

entity DACIF_ON is
generic(
    DEVICE         : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HOVS           : natural :=        2  
    );
port (
    RST            : in  std_logic;
    CLK            : in  std_logic;

    DATA_VLD_IN    : in  std_logic;
    DATA_I_IN      : in  std_logic_vector(15 downto 0);
    DATA_Q_IN      : in  std_logic_vector(15 downto 0);

    CPU_CTRL_ONOFF : in  std_logic;  -- '1' : IQ On , '0' : IQ Off
    IQ_OFF         : in  std_logic;  -- '1' : IQ Off , '0' : IQ On
	STAGE_NUM	   : in  std_logic_vector(4-1 downto 0);

    DATA_VLD_OUT   : out std_logic;
    DATA_I_OUT     : out std_logic_vector(15 downto 0);
    DATA_Q_OUT     : out std_logic_vector(15 downto 0)
    );
end DACIF_ON;

architecture arc_DACIF_ON of DACIF_ON is

    component RST_SYNC is
    generic(
        DLY_NUM        : natural := 3;    -- Number of delay.
        MAX_FANOUT_NUM : integer := 200   -- Number of maximum fanout
        );
    port(
        RST_IN         : in  std_logic;   -- Active high asynchronous reset
        CLK            : in  std_logic;   -- clock to be sync'ed to
        RST_OUT        : out std_logic    -- "Synchronised" reset signal
        );         
    end component;

    component SRL16E_DLY is
    generic(
        DEVICE         : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
        HS_MODE        : boolean :=        TRUE ;

        BIT_WIDTH      : natural;
        DELAY_NUM      : natural
        );
    port(
        RST            : in  std_logic;
        CLK            : in  std_logic;
        DATA_IN        : in  std_logic_vector(BIT_WIDTH-1 downto 0);
        DATA_OUT       : out std_logic_vector(BIT_WIDTH-1 downto 0) -- Delayed DATA
        );
    end component;

    component DSP48E1_MULTIPLIER is
    generic(
        AIN_BITWIDTH   : natural; -- AIN bitwidth : 0 to 29
        BIN_BITWIDTH   : natural; -- BIN bitwidth : 0 to 17
        RND_EN         : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
        RND_BIT        : natural; -- Rounding bit  
        OUTPUT_WIDTH   : natural  -- Result bitwidth : 0 to 47
        );
    port(
        RST            : in  std_logic;
        CLK            : in  std_logic;
        AIN            : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
        BIN            : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
        P              : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
        );
    end component;

    component DSP48E2_MULTIPLIER is
    generic(
        AIN_BITWIDTH   : natural; -- AIN bitwidth : 0 to 29
        BIN_BITWIDTH   : natural; -- BIN bitwidth : 0 to 17
        RND_EN         : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
        RND_BIT        : natural; -- Rounding bit  
        OUTPUT_WIDTH   : natural  -- Result bitwidth : 0 to 47
        );
    port(
        RST            : in  std_logic;
        CLK            : in  std_logic;
        AIN            : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
        BIN            : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
        P              : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
        );
    end component;

    component SAT_SIGN is
    generic(
        HS_MODE        : boolean := TRUE;
        INPUT_BIT      : natural;
        OUTPUT_BIT     : natural 
        );
    port( 
        RST            : in  std_logic;
        CLK            : in  std_logic;
        DATA_IN        : in  std_logic_vector(INPUT_BIT-1  downto 0);
        DATA_OUT       : out std_logic_vector(OUTPUT_BIT-1 downto 0)
        );
    end component;

    component WINDOW_COEF_ROM_227 is
        generic(
            DATA_WIDTH                  : natural := 17;
            ADDR_WIDTH                  : natural := 8
        );
        port(
            CLK                         : in  std_logic;
            ADDR_A                      : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
            Q_A                         : out std_logic_vector(DATA_WIDTH -1 downto 0)
        );
    end component;

    constant windowing_coef_num                 : integer := 227;

    signal rst_synch                            : std_logic;

    signal iq_off_sh                            : std_logic_vector( 1 downto 0);
    signal cpu_ctrl_on_sh                       : std_logic_vector( 1 downto 0);
    signal tx_onoff                             : std_logic;

    signal ctrl_status                          : std_logic_vector( 3 downto 0) := "0001";

    signal tx_onoff_flg                         : std_logic; -- '1' : 1 left shift, '0' : 0 right shift
    signal window_addr			                : std_logic_vector(8-1 downto 0);
    signal windowing_coef                       : std_logic_vector(16 downto 0);

    signal rnd_i                                : std_logic_vector(17 downto 0);
    signal rnd_q                                : std_logic_vector(17 downto 0);

    signal data_out_i                           : std_logic_vector(15 downto 0);
    signal data_out_q                           : std_logic_vector(15 downto 0);

    attribute KEEP : string;
    attribute KEEP of ctrl_status : signal is "TRUE";

begin

    U_RST_SYNC : RST_SYNC generic map(4, 200) port map(RST, CLK, rst_synch);
	
    G_HOVS1 : if (HOVS = 1) generate begin

        process(CLK)
        begin
            if (CLK'event) and (CLK = '1') then
                iq_off_sh                       <=  iq_off_sh(0) & IQ_OFF;
                cpu_ctrl_on_sh                  <=  cpu_ctrl_on_sh(0) & CPU_CTRL_ONOFF;
                tx_onoff                        <=  (not iq_off_sh(1)) and cpu_ctrl_on_sh(1);
            end if;
        end process;

        process(rst_synch, CLK)
        begin
            if (rst_synch = '1') then
                ctrl_status   <= "0001";
                tx_onoff_flg  <= '0'; 
            elsif (CLK'event) and (CLK = '1') then
                case (ctrl_status) is
                    when "0001" =>                  -- off state
                        if (tx_onoff = '1') then
                            ctrl_status <= "0100";
                        else
                            ctrl_status <= ctrl_status;
                        end if;
                        tx_onoff_flg <= '0';

                    when "0100" =>                  -- on state
                        if (tx_onoff = '0') then
                            ctrl_status <= "0010";
                        else
                            ctrl_status <= ctrl_status;
                        end if;
                        tx_onoff_flg <= '1';

                    when "0010" =>                  -- off transition state
                        if (window_addr = 0) then 
                            ctrl_status <= "0001";
                        else
                            ctrl_status <= "0010";
                        end if;
                        tx_onoff_flg <= '0';

                    when others =>
                        ctrl_status   <= "0001";
                        tx_onoff_flg  <= '0';
                end case;
            end if;
        end process;

		process(rst_synch, CLK)
		begin
			if (rst_synch = '1') then
				window_addr						<=	(others=>'0');
			elsif (rising_edge(CLK)) then
				if (tx_onoff_flg = '1') then
					if (window_addr = conv_std_logic_vector(windowing_coef_num-1,8)) then
						window_addr				<=	window_addr;
					else
						window_addr				<=	window_addr + '1';
					end if;
				else
					if (window_addr = 0) then
						window_addr				<=	window_addr;
					else
						window_addr				<=	window_addr - '1';
					end if;
				end if;
			end if;
		end process;

		U_WINDOW_COEF_ROM_227 : WINDOW_COEF_ROM_227 generic map(17,8) port map(CLK, window_addr, windowing_coef);

        G_7Series_DSP48E1_HOVS1 : if (DEVICE = "7SERIES") generate begin
            U_DSP48E1_I_multiple_HOVS1 : DSP48E1_MULTIPLIER generic map(16,17,TRUE,15,18) port map(rst_synch, CLK, DATA_I_IN, windowing_coef, rnd_i);
            U_DSP48E1_Q_multiple_HOVS1 : DSP48E1_MULTIPLIER generic map(16,17,TRUE,15,18) port map(rst_synch, CLK, DATA_Q_IN, windowing_coef, rnd_q);
        end generate;

        G_UltraScale_DSP48E2_HOVS1 : if (DEVICE = "ULTRASCALE") generate begin
            U_DSP48E2_I_multiple_HOVS1 : DSP48E2_MULTIPLIER generic map(16,17,TRUE,15,18) port map(rst_synch, CLK, DATA_I_IN, windowing_coef, rnd_i);
            U_DSP48E2_Q_multiple_HOVS1 : DSP48E2_MULTIPLIER generic map(16,17,TRUE,15,18) port map(rst_synch, CLK, DATA_Q_IN, windowing_coef, rnd_q);
        end generate;

        U_I_SAT : SAT_SIGN generic map(TRUE, 18, 16) port map(rst_synch, CLK, rnd_i, data_out_i);
        U_Q_SAT : SAT_SIGN generic map(TRUE, 18, 16) port map(rst_synch, CLK, rnd_q, data_out_q);

    end generate;
  
	DATA_VLD_OUT                    <=  DATA_VLD_IN;
	DATA_I_OUT                      <=  data_out_i;
	DATA_Q_OUT                      <=  data_out_q;
		
end arc_DACIF_ON;