
--   DSP48E2   : In order to incorporate this function into the design,
--    VHDL     : the following instance declaration needs to be placed
--  instance   : in the body of the design code.  The instance name
-- declaration : (DSP48E2_inst) and/or the port declarations after the
--    code     : "=>" declaration maybe changed to properly reference and
--             : connect this function to the design.  All inputs and outputs
--             : must be connected.

--   Library   : In addition to adding the instance declaration, a use
-- declaration : statement for the UNISIM.vcomponents library needs to be
--     for     : added before the entity declaration.  This library
--   Xilinx    : contains the component declarations for all Xilinx
-- primitives  : primitives and points to the models that will be used
--             : for simulation.

--  Copy the following two statements and paste them before the
--  Entity declaration, unless they already exist.
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_signed.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

Library UNISIM;
use UNISIM.vcomponents.all;

entity MONO_DSP48_A is
    generic(
    HOVS                            : natural
    );
    port(
    RST                             : in  std_logic;
    CLK                             : in  std_logic;

    A                               : in  std_logic_vector(29 downto 0);
    C                               : in  std_logic_vector(47 downto 0);
    B                               : in  std_logic_vector(17 downto 0);
    D                               : in  std_logic_vector(26 downto 0);

    OPMODE                          : in  std_logic_vector( 8 downto 0);   --000000101 or 000010101 or 000100101
    ACOUT                           : out std_logic_vector(29 downto 0);
    PCOUT                           : out std_logic_vector(47 downto 0)
);
end MONO_DSP48_A;

architecture arc_MONO_DSP48_A of MONO_DSP48_A is

    attribute DONT_TOUCH : string;
    attribute DONT_TOUCH of DSP48E2_inst : label is "TRUE";

begin

-- <-----Cut code below this line and paste into the architecture body---->

   -- DSP48E2: 48-bit Multi-Functional Arithmetic Block
   --          Kintex-7
   -- Xilinx HDL Language Template, version 2015.2

   DSP48E2_inst : DSP48E2
   generic map (
      -- Feature Control Attributes: Data Path Selection
      AMULTSEL              => "AD",                            -- Selects A input to multiplier (A, AD)
      A_INPUT               => "DIRECT",                        -- Selects A input source, "DIRECT" (A port) or "CASCADE" (ACIN port)
      BMULTSEL              => "B",                             -- Selects B input to multiplier (AD, B)
      B_INPUT               => "DIRECT",                        -- Selects B input source, "DIRECT" (B port) or "CASCADE" (BCIN port)
      PREADDINSEL           => "A",                             -- Selects input to pre-adder (A, B)
      RND                   => X"000000000000",                 -- Rounding Constant
      USE_MULT              => "MULTIPLY",                      -- Select multiplier usage ("MULTIPLY", "DYNAMIC", or "NONE")
      USE_SIMD              => "ONE48",                         -- SIMD selection ("ONE48", "TWO24", "FOUR12")
      USE_WIDEXOR           => "FALSE",                         -- Use the Wide XOR function (FALSE, TRUE)
      XORSIMD               => "XOR24_48_96",                   -- Mode of operation for the Wide XOR (XOR12, XOR24_48_96)
      -- Pattern Detector Attributes: Pattern Detection Configuration
      AUTORESET_PATDET      => "NO_RESET",                      -- "NO_RESET", "RESET_MATCH", "RESET_NOT_MATCH" 
      AUTORESET_PRIORITY    => "RESET",                         -- Priority of AUTORESET vs. CEP (CEP, RESET).
      MASK                  => X"3fffffffffff",                 -- 48-bit mask value for pattern detect (1=ignore)
      PATTERN               => X"000000000000",                 -- 48-bit pattern match for pattern detect
      SEL_MASK              => "MASK",                          -- "C", "MASK", "ROUNDING_MODE1", "ROUNDING_MODE2" 
      SEL_PATTERN           => "PATTERN",                       -- Select pattern value ("PATTERN" or "C")
      USE_PATTERN_DETECT    => "NO_PATDET",                     -- Enable pattern detect ("PATDET" or "NO_PATDET")
      -- Programmable Inversion Attributes: Specifies built-in programmable inversion on specific pins
      IS_ALUMODE_INVERTED   => "0000",                          -- Optional inversion for ALUMODE
      IS_CARRYIN_INVERTED   => '0',                             -- Optional inversion for CARRYIN
      IS_CLK_INVERTED       => '0',                             -- Optional inversion for CLK
      IS_INMODE_INVERTED    => "00000",                         -- Optional inversion for INMODE
      IS_OPMODE_INVERTED    => "000000000",                     -- Optional inversion for OPMODE
      IS_RSTALLCARRYIN_INVERTED => '0',                         -- Optional inversion for RSTALLCARRYIN
      IS_RSTALUMODE_INVERTED => '0',                            -- Optional inversion for RSTALUMODE
      IS_RSTA_INVERTED      => '0',                             -- Optional inversion for RSTA
      IS_RSTB_INVERTED      => '0',                             -- Optional inversion for RSTB
      IS_RSTCTRL_INVERTED   => '0',                             -- Optional inversion for RSTCTRL
      IS_RSTC_INVERTED      => '0',                             -- Optional inversion for RSTC
      IS_RSTD_INVERTED      => '0',                             -- Optional inversion for RSTD
      IS_RSTINMODE_INVERTED => '0',                             -- Optional inversion for RSTINMODE
      IS_RSTM_INVERTED      => '0',                             -- Optional inversion for RSTM
      IS_RSTP_INVERTED      => '0',                             -- Optional inversion for RSTP
      -- Register Control Attributes: Pipeline Register Configuration
      ACASCREG              => ternary_func(HOVS = 1 , 2 , 1),  -- Number of pipeline stages between A/ACIN and ACOUT (0, 1 or 2)
      ADREG                 => 1,                               -- Number of pipeline stages for pre-adder (0 or 1)
      ALUMODEREG            => 1,                               -- Number of pipeline stages for ALUMODE (0 or 1)
      AREG                  => ternary_func(HOVS = 1 , 2 , 1),  -- Number of pipeline stages for A (0, 1 or 2)
      BCASCREG              => 2,                               -- Number of pipeline stages between B/BCIN and BCOUT (0, 1 or 2)
      BREG                  => 2,                               -- Number of pipeline stages for B (0, 1 or 2)
      CARRYINREG            => 0,                               -- Number of pipeline stages for CARRYIN (0 or 1)
      CARRYINSELREG         => 0,                               -- Number of pipeline stages for CARRYINSEL (0 or 1)
      CREG                  => 1,                               -- Number of pipeline stages for C (0 or 1)
      DREG                  => 1,                               -- Number of pipeline stages for D (0 or 1)
      INMODEREG             => 1,                               -- Number of pipeline stages for INMODE (0 or 1)
      MREG                  => 1,                               -- Number of multiplier pipeline stages (0 or 1)
      OPMODEREG             => 1,                               -- Number of pipeline stages for OPMODE (0 or 1)
      PREG                  => 1                                -- Number of pipeline stages for P (0 or 1)
   )
   port map (
      -- Cascade: 30-bit (each) output: Cascade Ports
      ACOUT                 => ACOUT,                           -- 30-bit output: A port cascade output
      BCOUT                 => open,                            -- 18-bit output: B port cascade output
      CARRYCASCOUT          => open,                            -- 1-bit output: Cascade carry output
      MULTSIGNOUT           => open,                            -- 1-bit output: Multiplier sign cascade output
      PCOUT                 => PCOUT,                           -- 48-bit output: Cascade output
      -- Control: 1-bit (each) output: Control Inputs/Status Bits
      OVERFLOW              => open,                            -- 1-bit output: Overflow in add/acc output
      PATTERNBDETECT        => open,                            -- 1-bit output: Pattern bar detect output
      PATTERNDETECT         => open,                            -- 1-bit output: Pattern detect output
      UNDERFLOW             => open,                            -- 1-bit output: Underflow in add/acc output
      -- Data: 4-bit (each) output: Data Ports
      CARRYOUT              => open,                            -- 4-bit output: Carry output
      P                     => open,                            -- 48-bit output: Primary data output
      XOROUT                => open,                            -- 8-bit output: XOR data
      -- Cascade: 30-bit (each) input: Cascade Ports
      ACIN                  => (others => '0'),                 -- 30-bit input: A cascade data input
      BCIN                  => (others => '0'),                 -- 18-bit input: B cascade input
      CARRYCASCIN           => '0',                             -- 1-bit input: Cascade carry input
      MULTSIGNIN            => '0',                             -- 1-bit input: Multiplier sign input
      PCIN                  => (others => '0'),                 -- 48-bit input: P cascade input
      -- Control: 4-bit (each) input: Control Inputs/Status Bits
      ALUMODE               => "0000",                          -- 4-bit input: ALU control input
      CARRYINSEL            => (others => '0'),                 -- 3-bit input: Carry select input
      CLK                   => CLK,                             -- 1-bit input: Clock input
      INMODE                => ternary_func(HOVS = 1 ,"00100","00101"), -- 5-bit input: INMODE control input
      OPMODE                => OPMODE,                          -- 7-bit input: Operation mode input
      -- Data: 30-bit (each) input: Data Ports
      A                     => A,                               -- 30-bit input: A data input
      B                     => B,                               -- 18-bit input: B data input
      C                     => C,                               -- 48-bit input: C data input
      CARRYIN               => '0',                             -- 1-bit input: Carry input signal
      D                     => D,                               -- 25-bit input: D data input
      -- Reset/Clock Enable: 1-bit (each) input: Reset/Clock Enable Inputs
      CEA1                  => '1',                             -- 1-bit input: Clock enable input for 1st stage AREG
      CEA2                  => ternary_func(HOVS = 1 , '1' , '0'),  -- 1-bit input: Clock enable input for 2nd stage AREG
      CEAD                  => '1',                             -- 1-bit input: Clock enable input for ADREG
      CEALUMODE             => '1',                             -- 1-bit input: Clock enable input for ALUMODE
      CEB1                  => '1',                             -- 1-bit input: Clock enable input for 1st stage BREG
      CEB2                  => '1',                             -- 1-bit input: Clock enable input for 2nd stage BREG
      CEC                   => '1',                             -- 1-bit input: Clock enable input for CREG
      CECARRYIN             => '0',                             -- 1-bit input: Clock enable input for CARRYINREG
      CECTRL                => '1',                             -- 1-bit input: Clock enable input for OPMODEREG and CARRYINSELREG
      CED                   => '1',                             -- 1-bit input: Clock enable input for DREG
      CEINMODE              => '1',                             -- 1-bit input: Clock enable input for INMODEREG
      CEM                   => '1',                             -- 1-bit input: Clock enable input for MREG
      CEP                   => '1',                             -- 1-bit input: Clock enable input for PREG
      RSTA                  => '0',                             -- 1-bit input: Reset input for AREG
      RSTALLCARRYIN         => '0',                             -- 1-bit input: Reset input for CARRYINREG
      RSTALUMODE            => '0',                             -- 1-bit input: Reset input for ALUMODEREG
      RSTB                  => '0',                             -- 1-bit input: Reset input for BREG
      RSTC                  => '0',                             -- 1-bit input: Reset input for CREG
      RSTCTRL               => '0',                             -- 1-bit input: Reset input for OPMODEREG and CARRYINSELREG
      RSTD                  => '0',                             -- 1-bit input: Reset input for DREG and ADREG
      RSTINMODE             => '0',                             -- 1-bit input: Reset input for INMODEREG
      RSTM                  => '0',                             -- 1-bit input: Reset input for MREG
      RSTP                  => '0'                              -- 1-bit input: Reset input for PREG
   );

   -- End of DSP48E2_inst instantiation
end arc_MONO_DSP48_A;
