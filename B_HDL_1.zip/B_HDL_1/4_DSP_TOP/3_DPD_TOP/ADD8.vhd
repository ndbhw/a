library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity ADD8 is
generic(
    HS_MODE      : boolean := TRUE; -- High Speed Mode (Operating Clock > 307.2MHz)
    BITWIDTH     : natural := 16
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
  
    DATA0_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA1_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA2_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA3_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);

    DATA4_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA5_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA6_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA7_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);

    DATA_OUT     : out std_logic_vector(BITWIDTH+2 downto 0)
    );
end ADD8;

architecture arc_ADD8 of ADD8 is

signal add0      : std_logic_vector(BITWIDTH   downto 0);
signal add1      : std_logic_vector(BITWIDTH   downto 0);
signal add2      : std_logic_vector(BITWIDTH   downto 0);
signal add3      : std_logic_vector(BITWIDTH   downto 0);
signal sum0      : std_logic_vector(BITWIDTH+1 downto 0);
signal sum1      : std_logic_vector(BITWIDTH+1 downto 0);
signal sum       : std_logic_vector(BITWIDTH+2 downto 0);

begin

    G_Normal_Operation : if (HS_MODE = FALSE) generate begin

        P_Adder_NM : process(RST, CLK) begin
            if (RST = '1') then
                add0 <= (others => '0'); 
                add1 <= (others => '0'); 
                add2 <= (others => '0');   
                add3 <= (others => '0');   
                sum0 <= (others => '0');   
                sum1 <= (others => '0');   
                sum  <= (others => '0'); 
            elsif (CLK'event) and (CLK = '1') then
                add0 <= (DATA0_IN(BITWIDTH-1) & DATA0_IN) + (DATA1_IN(BITWIDTH-1) & DATA1_IN); 
                add1 <= (DATA2_IN(BITWIDTH-1) & DATA2_IN) + (DATA3_IN(BITWIDTH-1) & DATA3_IN); 
                sum0 <= (    add0(BITWIDTH  ) &     add0) + (    add1(BITWIDTH  ) &     add1); 

                add2 <= (DATA4_IN(BITWIDTH-1) & DATA4_IN) + (DATA5_IN(BITWIDTH-1) & DATA5_IN); 
                add3 <= (DATA6_IN(BITWIDTH-1) & DATA6_IN) + (DATA7_IN(BITWIDTH-1) & DATA7_IN); 
                sum1 <= (    add2(BITWIDTH  ) &     add2) + (    add3(BITWIDTH  ) &     add3); 

                sum  <= (    sum0(BITWIDTH+1) &     sum0) + (    sum1(BITWIDTH+1) &     sum1);
            end if;
        end process;
    end generate;

    G_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
        P_Adder_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                add0 <= (DATA0_IN(BITWIDTH-1) & DATA0_IN) + (DATA1_IN(BITWIDTH-1) & DATA1_IN); 
                add1 <= (DATA2_IN(BITWIDTH-1) & DATA2_IN) + (DATA3_IN(BITWIDTH-1) & DATA3_IN); 
                sum0 <= (    add0(BITWIDTH  ) &     add0) + (    add1(BITWIDTH  ) &     add1); 

                add2 <= (DATA4_IN(BITWIDTH-1) & DATA4_IN) + (DATA5_IN(BITWIDTH-1) & DATA5_IN); 
                add3 <= (DATA6_IN(BITWIDTH-1) & DATA6_IN) + (DATA7_IN(BITWIDTH-1) & DATA7_IN); 
                sum1 <= (    add2(BITWIDTH  ) &     add2) + (    add3(BITWIDTH  ) &     add3); 

                sum  <= (    sum0(BITWIDTH+1) &     sum0) + (    sum1(BITWIDTH+1) &     sum1);
            end if;
        end process;
    end generate;

    DATA_OUT     <= sum;

end arc_ADD8;

