library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity fir_3_buf is
generic(
    W_HOVS                      : integer;
    R_HOVS                      : integer
    );
port(
    RST_W                       : in  std_logic;
    CLK_W                       : in  std_logic;
    RST_R                       : in  std_logic;
    CLK_R                       : in  std_logic;

    DATA_IN_VALID               : in  std_logic;
    DATA_IN_I                   : in  std_logic_vector(15 downto 0);
    DATA_IN_Q                   : in  std_logic_vector(15 downto 0);

    BUF_COLLISION_FLAG          : out std_logic;
    DATA_OUT_VALID              : out std_logic;
    DATA_OUT_I                  : out std_logic_vector(15 downto 0);
    DATA_OUT_Q                  : out std_logic_vector(15 downto 0)
);
end fir_3_buf;

architecture Behavioral of fir_3_buf is

component fir_3_sdpram is
generic(
    BUFF_DEPTH                  : integer := 1024;
    WIDTH_IN                    : integer := 16
);
port(
    CLK_W                       : in  std_logic;
    CLK_R                       : in  std_logic;
    WE                          : in  std_logic;
    ADDR_W                      : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    ADDR_R                      : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_W                      : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_R                      : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

constant BUFFER_DEPTH           : integer := 16;
constant DATA_WIDTH             : integer := 16;

signal waddr                    : std_logic_vector(log2(BUFFER_DEPTH)-1 downto 0);
signal raddr                    : std_logic_vector(log2(BUFFER_DEPTH)-1 downto 0);
signal buf_wdata                : std_logic_vector(31 downto 0);
signal buf_rdata                : std_logic_vector(31 downto 0);

signal wsync                    : std_logic;
signal wsync_d                  : std_logic_vector(2 downto 0);
signal resync                   : std_logic;
signal hovs_cnt                 : std_logic_vector(log2(R_HOVS)-1 downto 0);

attribute MAX_FANOUT            : integer;
attribute MAX_FANOUT of raddr   : signal is 16;

begin

    ---------------------------------------------------------------- write clock domain begin
    -- write address generation
    process (RST_W, CLK_W)
    begin
    if RST_W = '1' then
        waddr <= (others => '0');
    elsif rising_edge(CLK_W) then
        if DATA_IN_VALID = '1' then
            waddr <= waddr + 1;
        end if;
    end if;
    end process;

    -- wsync for avoiding w/r address collision
    process (RST_W, CLK_W)
    begin
    if RST_W = '1' then
        wsync <= '0';
    elsif rising_edge(CLK_W) then
        if waddr = 0 or waddr = 1 then
            wsync <= '1';
        else
            wsync <= '0';
        end if;
    end if;
    end process;
    ---------------------------------------------------------------- write clock domain end


    ---------------------------------------------------------------- read clock domain begin
    -- write sync. double clocking
    process (RST_R, CLK_R)
    begin
    if RST_R = '1' then
        wsync_d <= (others => '0');
    elsif rising_edge(CLK_R) then
        wsync_d <= wsync_d(1 downto 0) & wsync;
    end if;
    end process;

    -- resync control
    BUF_COLLISION_FLAG <= resync;
    process (RST_R, CLK_R)
    begin
    if RST_R = '1' then
        resync <= '0';
    elsif rising_edge(CLK_R) then
        if wsync_d(2 downto 1) = "01" then
            if raddr >= 7 and raddr <= 11 then
                resync <= '0';--normal
            else
                resync <= '1';--abnormal, resync
            end if;
        else
            resync <= '0';
        end if;
    end if;
    end process;

    -- write address generation
    process (RST_R, CLK_R)
    begin
    if RST_R = '1' then
        hovs_cnt<= (others => '0');
        raddr   <= (others => '0');
    elsif rising_edge(CLK_R) then
        if resync = '1' then
            hovs_cnt<= (others => '0');
            raddr   <= std_logic_vector(to_unsigned(11, log2(BUFFER_DEPTH)));
        else
            if hovs_cnt = R_HOVS-1 then
                hovs_cnt<= (others => '0');
                raddr   <= raddr + '1';
            else
                hovs_cnt<= hovs_cnt + '1';
            end if;
        end if;
    end if;
    end process;

    -- write sync. double clocking
    process (RST_R, CLK_R)
    begin
    if RST_R = '1' then
        DATA_OUT_VALID <= '0';
    elsif rising_edge(CLK_R) then
        if hovs_cnt = R_HOVS-1 then
            DATA_OUT_VALID <= '1';
        else
            DATA_OUT_VALID <= '0';
        end if;
    end if;
    end process;

    ---------------------------------------------------------------- read clock domain end

    buf_wdata <= DATA_IN_I & DATA_IN_Q;

    u_fir_3_sdpram : fir_3_sdpram
    generic map(
        BUFF_DEPTH                  => BUFFER_DEPTH                 ,--: integer := 1024;
        WIDTH_IN                    => 2*DATA_WIDTH                  --: integer := 16
    )
    port map(
        CLK_W                       => CLK_W                        ,--: in  std_logic;
        CLK_R                       => CLK_R                        ,--: in  std_logic;
        WE                          => DATA_IN_VALID                ,--: in  std_logic;
        ADDR_W                      => waddr                        ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
        ADDR_R                      => raddr                        ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
        DATA_W                      => buf_wdata                    ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
        DATA_R                      => buf_rdata                     --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );

    process (RST_R, CLK_R)
    begin
    if RST_R = '1' then
        DATA_OUT_I <= (others=>'0');
        DATA_OUT_Q <= (others=>'0');
    elsif rising_edge(CLK_R) then
        DATA_OUT_I <= buf_rdata(2*DATA_WIDTH-1 downto DATA_WIDTH);
        DATA_OUT_Q <= buf_rdata(  DATA_WIDTH-1 downto          0);
    end if;
    end process;

end Behavioral;
