-- k1340.heo
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_signed.all;

-- Latency : 2 Clocks
entity SAT_UNSIGN is
generic(
    HS_MODE    : boolean :=  TRUE;  -- High Speed Mode (Operating Clock > 307.2MHz)
    INPUT_BIT  : natural;
    OUTPUT_BIT : natural
    );
port( 
    RST        : in  std_logic;
    CLK        : in  std_logic;
    DATA_IN    : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT   : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end SAT_UNSIGN;

architecture arc_SAT_UNSIGN of SAT_UNSIGN is

constant p_sat     : std_logic_vector( INPUT_BIT-1 downto OUTPUT_BIT) := (others => '0');
constant p_max     : std_logic_vector(OUTPUT_BIT-1 downto 0) := (others => '1');

signal   max_flg   : std_logic;
signal   data_d1   : std_logic_vector(OUTPUT_BIT-1 downto 0);

signal   sat_out   : std_logic_vector(OUTPUT_BIT-1 downto 0);

begin

    G_Normal_Operation : if (HS_MODE = FALSE) generate begin

        -- 1st Clock
        P_Saturation : process(RST, CLK) begin
            if (RST = '1') then
                sat_out <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                -- Not Saturated
                if (DATA_IN(INPUT_BIT-1 downto OUTPUT_BIT) = p_sat) then 
                    sat_out <= DATA_IN(OUTPUT_BIT-1 downto 0);
                -- Positive Saturated
                else
                    sat_out <= p_max;
                end if;
            end if;
        end process;

        -- 2nd Clock
        P_Delay_Fix_NM : process(RST, CLK) begin
            if (RST = '1') then
                DATA_OUT <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                DATA_OUT <= sat_out;
            end if;
        end process;

        max_flg <= '0';            
        data_d1 <= (others => '0');

    end generate;

    G_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
        -- 1st Clock
        P_MAX_Flag_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (DATA_IN(INPUT_BIT-1 downto OUTPUT_BIT) = p_sat) then 
                    max_flg <= '0';
                else
                    max_flg <= '1';
                end if;
            end if;
        end process;

        -- 1st Clock 
        P_Data_Clocking_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                data_d1 <= DATA_IN(OUTPUT_BIT-1 downto 0);
            end if;
        end process;

        -- 2nd Clock
        P_Saturation_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (max_flg = '1') then
                    sat_out <= p_max;   
                else
                    sat_out <= data_d1;   
                end if;
            end if;
        end process;

        DATA_OUT <= sat_out; 

    end generate;

end arc_SAT_UNSIGN;
