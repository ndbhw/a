library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity RX_SSD_ACCUMULATOR is
generic(
    HS_MODE                : boolean := FALSE ;
    HOVS                   : natural :=     2  
    );
port(
    RST                    : in  std_logic;
    CLK                    : in  std_logic;

    ACCU_EN_IN             : in  std_logic;
    ACCU_LENGTH_IN         : in  std_logic_vector(16 downto 0);
    REPEAT_PER_SW_IN       : in  std_logic_vector(16 downto 0);
    ACCU_DONE_FLG_OUT      : out std_logic;

    FS_10ms_RPLS_IN        : in  std_logic;
    FBSW_ALIGN_IN          : in  std_logic;

    FB_VLD_IN              : in  std_logic;
    FB_I_IN                : in  std_logic_vector(15 downto 0);
    FB_Q_IN                : in  std_logic_vector(15 downto 0);

    MEM_RDEN_I_IN          : in  std_logic;
    MEM_ADDR_I_IN          : in  std_logic_vector( 8 downto 0);
    MEM_DATA_I_OUT         : out std_logic_vector(31 downto 0);

    MEM_RDEN_Q_IN          : in  std_logic;
    MEM_ADDR_Q_IN          : in  std_logic_vector( 8 downto 0);
    MEM_DATA_Q_OUT         : out std_logic_vector(31 downto 0)
    );
end RX_SSD_ACCUMULATOR;

architecture arc_RX_SSD_ACCUMULATOR of RX_SSD_ACCUMULATOR is

-- component SIMPLE_DPRAM is
-- generic(
--     RAM_STYLE              : string  := "DISTRIBUTED"; -- DISTRIBUTED or BLOCK
--     RAM_INIT_VALUE         : integer := 0; 
-- 
--     DATA_WIDTH             : natural := 8;
--     ADDR_WIDTH             : natural := 6
--     );
-- port(
--     CLK	                   : in  std_logic;
--     ENA                    : in  std_logic;
--     WEA                    : in  std_logic;
--     ADDRA                  : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
--     DATAA                  : in  std_logic_vector(DATA_WIDTH-1 downto 0);
-- 
--     ENB                    : in  std_logic;
--     ADDRB                  : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
--     DATAB                  : out std_logic_vector(DATA_WIDTH-1 downto 0)
--     );
-- end component;
component SIMPLE_DPRAM is
generic(
    RAM_TYPE                    : string  := "BLOCK"; -- DISTRIBUTED or BLOCK or ULTRA
    RAM_INIT_VALUE              : integer := 0 ; 
                                               
    DATA_WIDTH                  : natural := 8 ;
    ADDR_WIDTH                  : natural := 6
    );
port(
    CLK_A	                    : in  std_logic;
    EN_A                        : in  std_logic;
    WE_A                        : in  std_logic;
    ADDR_A                      : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATA_A                      : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    CLK_B	                    : in  std_logic;
    EN_B                        : in  std_logic;
    ADDR_B                      : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATA_B                      : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end component;

-- component BUF_SAMPLE_DELAY is
-- generic(
--     RAM_STYLE              : string  := "DISTRIBUTED"; -- DISTRIBUTED or BLOCK
--     HS_MODE                : boolean :=         TRUE ;
-- 
--     DATA_WIDTH             : natural;
--     ADDR_WIDTH             : natural
--     );
-- port(
--     RST                    : in  std_logic;
--     CLK                    : in  std_logic;
-- 
--     DELAY_VALUE_IN         : in  std_logic_vector(ADDR_WIDTH-1 downto 0); 
-- 
--     SAMPLE_VLD_IN          : in  std_logic;
--     SAMPLE_IN              : in  std_logic_vector(DATA_WIDTH-1 downto 0); 
--     SAMPLE_DELAY_OUT       : out std_logic_vector(DATA_WIDTH-1 downto 0) 
--     );
-- end component;
component BUF_SAMPLE_DLY is
generic(
    RAM_STYLE            : string := "DISTRIBUTED"; -- "DISTRIBUTED" or "BLOCK"
    RESOLUTION           : string := "CLOCK";       -- "CLOCK" or "SAMPLE_RATE"

    DATA_WIDTH           : natural;
    ADDR_WIDTH           : natural
    );
port(
    RST                  : in  std_logic;
    CLK                  : in  std_logic;

    DELAY_VALUE_IN       : in  std_logic_vector(ADDR_WIDTH-1 downto 0); 

    SAMPLE_VLD_IN        : in  std_logic;
    SAMPLE_IN            : in  std_logic_vector(DATA_WIDTH-1 downto 0); 
    SAMPLE_DELAY_OUT     : out std_logic_vector(DATA_WIDTH-1 downto 0) 
    );
end component;


signal accu_en_d1          : std_logic;
signal accu_en_rpls        : std_logic;

signal fbsw_align_d1       : std_logic;
signal fbsw_align_rpls     : std_logic;

signal state_cnt           : std_logic_vector( 1 downto 0);
signal cnt_512             : std_logic_vector( 8 downto 0);

signal cnt_repeat_sw       : std_logic_vector(16 downto 0);
signal accu_section        : std_logic;
signal accu_indicator      : std_logic;
signal accu_indicator_d2   : std_logic_vector( 1 downto 0);
signal accu_indicator_wr   : std_logic;

signal accu_length_cnt     : std_logic_vector(16 downto 0);

type ST_ACCUATE is (S0_EN_WAIT, S1_MEM_CLR, S2_ACCU, S3_DONE);
signal ST_ACCU             : ST_ACCUATE;

signal mem_clr_en          : std_logic;

signal mem_clr_dn_pls      : std_logic;
signal clr_addr            : std_logic_vector( 8 downto 0);

signal accu_st_en          : std_logic;
signal accu_st_en_d2       : std_logic_vector( 1 downto 0);
signal accu_st_en_wr       : std_logic;
signal accu_dn_flg         : std_logic;
signal accu_dn_flg_sh      : std_logic_vector( 1 downto 0);
signal accu_dn_flg_sh_d1   : std_logic;
signal accu_dn_pls         : std_logic;
signal accu_mem_en         : std_logic;
signal accu_mem_addr       : std_logic_vector( 8 downto 0);
signal accu_mem_addr_d2    : std_logic_array9( 2 downto 0);
signal accu_mem_addr_dly   : std_logic_vector( 8 downto 0);
signal accu_mem_i          : std_logic_vector(31 downto 0);
signal accu_mem_q          : std_logic_vector(31 downto 0);

signal accu_done_flg       : std_logic;

signal mem_en_i            : std_logic;
signal mem_en_q            : std_logic;
signal mem_wren            : std_logic;
signal mem_waddr           : std_logic_vector( 8 downto 0);
signal mem_wdata_i         : std_logic_vector(31 downto 0);
signal mem_wdata_q         : std_logic_vector(31 downto 0);

signal mem_raddr_i         : std_logic_vector( 8 downto 0);
signal mem_raddr_q         : std_logic_vector( 8 downto 0);
signal mem_rdata_i         : std_logic_vector(31 downto 0);
signal mem_rdata_q         : std_logic_vector(31 downto 0);

signal fb_sample_dly_i     : std_logic_vector(15 downto 0);
signal fb_sample_dly_q     : std_logic_vector(15 downto 0);

signal fb_sample_dly_i_d2  : std_logic_array16(2 downto 0);
signal fb_sample_dly_q_d2  : std_logic_array16(2 downto 0);

signal mem_rdata_i_rpt     : std_logic_vector(31 downto 0);
signal mem_rdata_q_rpt     : std_logic_vector(31 downto 0);


begin 

    P_RPLS_GEN : process(RST, CLK) begin
        if (RST = '1') then
            accu_en_d1      <= '0';
            accu_en_rpls    <= '0';
            
            fbsw_align_d1   <= '0';
            fbsw_align_rpls <= '0';
            
        elsif (CLK'event) and (CLK = '1') then
            accu_en_d1      <= ACCU_EN_IN;
            accu_en_rpls    <= ACCU_EN_IN and (not accu_en_d1);
            
            fbsw_align_d1   <= FBSW_ALIGN_IN;
            fbsw_align_rpls <= FBSW_ALIGN_IN and (not fbsw_align_d1);
        end if;
    end process;

    P_FBSW_State_Count : process(RST, CLK) begin
        if (RST = '1') then
            state_cnt <= "11";
        elsif (CLK'event) and (CLK = '1') then
            if (fbsw_align_d1 = '0') then
                state_cnt <= "11";
            else
                if (state_cnt = "01") then
                    state_cnt <= state_cnt;
                else
                    if (FS_10ms_RPLS_IN = '1') then        
                        state_cnt <= state_cnt + '1';
                    else
                        state_cnt <= state_cnt;
                    end if;
                end if;
            end if;
        end if;
    end process;
    
    -- Pattern Repeatation Count
    P_512_Counter_NM : process(RST, CLK) begin
        if (RST = '1') then    
            cnt_512 <= (others => '1');
        elsif (CLK'event) and (CLK = '1') then
            if (state_cnt = "01") then
                if (FB_VLD_IN = '1') then
                    cnt_512 <= cnt_512 + '1';
                else
                    cnt_512 <= cnt_512;
                end if;
            else
                cnt_512 <= (others => '1');
            end if;
        end if;
    end process;

    P_Reapeat_Counter_NM : process(RST, CLK) begin
        if (RST = '1') then
            cnt_repeat_sw <= (others => '1');
            accu_section  <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (state_cnt = "01") then
                if (FB_VLD_IN = '1') then
                    if (cnt_512 = '1'&x"FF") then
                        if (cnt_repeat_sw = REPEAT_PER_SW_IN) then
                            cnt_repeat_sw <= cnt_repeat_sw;
                            accu_section  <= '0';
                        else
                            cnt_repeat_sw <= cnt_repeat_sw + '1';
                            accu_section  <= '1';
                        end if;
                    else
                        cnt_repeat_sw <= cnt_repeat_sw;
                        accu_section  <= accu_section;
                    end if;
                else
                    cnt_repeat_sw <= cnt_repeat_sw;
                    accu_section  <= accu_section;
                end if;
            else
                cnt_repeat_sw <= (others => '1');
                accu_section  <= '0';
            end if;
        end if;
    end process;

    P_ACCU_Length : process(RST, CLK) begin
        if (RST = '1') then
            accu_length_cnt <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (accu_en_rpls = '1') then
                accu_length_cnt <= (others => '0');
            else
                if (accu_length_cnt = ACCU_LENGTH_IN) then          
                    accu_length_cnt <= accu_length_cnt;
                elsif (accu_section = '1') then
                    if (FB_VLD_IN = '1') then
                        if (cnt_512 = '1'&x"FF") then
                            accu_length_cnt <= accu_length_cnt + '1';
                        else
                            accu_length_cnt <= accu_length_cnt;
                        end if;
                    else
                        accu_length_cnt <= accu_length_cnt;
                    end if;
                else
                    accu_length_cnt <= accu_length_cnt;
                end if;
            end if;
        end if;
    end process;
 
    P_ACCU_Done : process(RST, CLK) begin
        if (RST = '1') then
            accu_dn_flg       <= '0';
            accu_dn_flg_sh    <= (others => '0');  
            accu_dn_flg_sh_d1 <= '0';              
            accu_dn_pls       <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (accu_length_cnt = ACCU_LENGTH_IN) then
                accu_dn_flg <= '1';
            else
                accu_dn_flg <= '0';
            end if;
            accu_dn_flg_sh    <= accu_dn_flg_sh(0) & accu_dn_flg;  

            if (FB_VLD_IN = '1') then
                accu_dn_flg_sh_d1 <= accu_dn_flg_sh(1);              
                accu_dn_pls       <= accu_dn_flg_sh(1) and (not accu_dn_flg_sh_d1);
            else
                accu_dn_flg_sh_d1 <= accu_dn_flg_sh_d1 ;              
                accu_dn_pls       <= accu_dn_pls       ;
            end if;
        end if;
    end process;

    P_ACCU_Indicator : process(RST, CLK) begin
        if (RST = '1') then
            accu_indicator    <= '0';
            accu_indicator_d2 <= (others => '0');
            accu_indicator_wr <= '0';

        elsif (CLK'event) and (CLK = '1') then
            if (FB_VLD_IN = '1') then
                if (accu_length_cnt = ACCU_LENGTH_IN) then
                    accu_indicator <= '0';
                else
                    accu_indicator <= accu_section;
                end if;
            else
                accu_indicator <= accu_indicator;
            end if;

            accu_indicator_d2 <= accu_indicator_d2(0)&accu_indicator;
            if (FB_VLD_IN = '1') then
                accu_indicator_wr <= accu_indicator_d2(1);
            else
                accu_indicator_wr <= accu_indicator_wr;
            end if;
        end if;
    end process;

    P_DPRAM_ADDR_CTRL : process(RST, CLK) begin
        if (RST = '1') then
            ST_ACCU         <= S0_EN_WAIT;

            mem_clr_en      <= '0';
            accu_st_en      <= '0';

            accu_done_flg   <= '1';

            mem_en_i        <= '0';            
            mem_en_q        <= '0';            
            mem_wren        <= '0';            
            mem_waddr       <= (others => '0');
            mem_wdata_i     <= (others => '0');
            mem_wdata_q     <= (others => '0');
            mem_raddr_i     <= (others => '0');
            mem_raddr_q     <= (others => '0');

            mem_rdata_i_rpt <= (others => '0');
            mem_rdata_q_rpt <= (others => '0');

        elsif (CLK'event) and (CLK = '1') then
            case (ST_ACCU) is      
                when S0_EN_WAIT =>
                    mem_clr_en    <= '0';
                    accu_st_en    <= '0';
                    accu_done_flg <= '1';

                    if (accu_en_rpls = '1') then
                        ST_ACCU <= S1_MEM_CLR; 
                    else
                        ST_ACCU <= ST_ACCU; 
                    end if;

                    mem_en_i        <= MEM_RDEN_I_IN;            
                    mem_en_q        <= MEM_RDEN_Q_IN;            
                    mem_wren        <= '0';            
                    mem_waddr       <= (others => '0');
                    mem_wdata_i     <= (others => '0');
                    mem_wdata_q     <= (others => '0');
                    mem_raddr_i     <= MEM_ADDR_I_IN;
                    mem_raddr_q     <= MEM_ADDR_Q_IN;
                    mem_rdata_i_rpt <= mem_rdata_i;
                    mem_rdata_q_rpt <= mem_rdata_q;

                when S1_MEM_CLR =>
                    accu_st_en    <= '0';
                    accu_done_flg <= '0';

                    if (mem_clr_dn_pls = '1') then
                        ST_ACCU     <= S2_ACCU; 
                        mem_clr_en  <= '0';
                    else
                        ST_ACCU     <= ST_ACCU; 
                        mem_clr_en  <= '1';
                    end if;

                    mem_en_i        <= '1';            
                    mem_en_q        <= '1';            
                    mem_wren        <= '1';            
                    mem_waddr       <= clr_addr;
                    mem_wdata_i     <= (others => '0');
                    mem_wdata_q     <= (others => '0');
                    mem_raddr_i     <= (others => '0');
                    mem_raddr_q     <= (others => '0');
                    mem_rdata_i_rpt <= (others => '0');
                    mem_rdata_q_rpt <= (others => '0');
                    
                when S2_ACCU =>
                    mem_clr_en    <= '0';
                    accu_done_flg <= '0';

                    if (accu_dn_pls = '1') then         
                        ST_ACCU    <= S3_DONE; 
                        accu_st_en <= '0';
                    else
                        ST_ACCU    <= ST_ACCU; 
                        accu_st_en <= '1';
                    end if;

                    mem_en_i        <= accu_mem_en;            
                    mem_en_q        <= accu_mem_en;            
                    mem_wren        <= accu_mem_en;            
                    mem_waddr       <= accu_mem_addr_dly;
                    mem_wdata_i     <= accu_mem_i;
                    mem_wdata_q     <= accu_mem_q;
                    mem_raddr_i     <= accu_mem_addr;
                    mem_raddr_q     <= accu_mem_addr;
                    mem_rdata_i_rpt <= (others => '0');
                    mem_rdata_q_rpt <= (others => '0');
                    
                when S3_DONE =>
                    mem_clr_en      <= '0';
                    accu_st_en      <= '0';

                    accu_done_flg   <= '1';
                    ST_ACCU         <= S0_EN_WAIT; 

                    mem_en_i        <= '0';            
                    mem_en_q        <= '0';            
                    mem_wren        <= '0';            
                    mem_waddr       <= (others => '0');
                    mem_wdata_i     <= (others => '0');
                    mem_wdata_q     <= (others => '0');
                    mem_raddr_i     <= (others => '0');
                    mem_raddr_q     <= (others => '0');
                    mem_rdata_i_rpt <= (others => '0');
                    mem_rdata_q_rpt <= (others => '0');

                when others =>
                    mem_clr_en      <= '0';
                    accu_st_en      <= '0';
                    accu_done_flg   <= '1';

                    ST_ACCU         <= S0_EN_WAIT;  

                    mem_en_i        <= MEM_RDEN_I_IN;            
                    mem_en_q        <= MEM_RDEN_Q_IN;            
                    mem_wren        <= '0';            
                    mem_waddr       <= (others => '0');
                    mem_wdata_i     <= (others => '0');
                    mem_wdata_q     <= (others => '0');
                    mem_raddr_i     <= MEM_ADDR_I_IN;
                    mem_raddr_q     <= MEM_ADDR_Q_IN;
                    mem_rdata_i_rpt <= mem_rdata_i;
                    mem_rdata_q_rpt <= mem_rdata_q;

            end case;
        end if;
    end process;

    P_ACCU_ST_EN : process(RST, CLK) begin
        if (RST = '1') then
            accu_st_en_d2 <= (others => '0');
            accu_st_en_wr <= '0';            
        elsif (CLK'event) and (CLK = '1') then
            accu_st_en_d2 <= accu_st_en_d2(0)&accu_st_en;
          
            if (FB_VLD_IN = '1') then
                accu_st_en_wr <= accu_st_en_d2(1);            
            else
                accu_st_en_wr <= accu_st_en_wr;            
            end if;
        end if;
    end process;

    P_S1_MEM_CLR : process(RST, CLK) begin
        if (RST = '1') then
            mem_clr_dn_pls <= '0';
            clr_addr       <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (mem_clr_en = '1') then 
                if (clr_addr = '1'&x"FF") then
                    clr_addr <= clr_addr;
                else
                    clr_addr <= clr_addr + '1';
                end if;
            else
                clr_addr <= (others => '0');
            end if;

            if (clr_addr = '1'&x"FE") then
                mem_clr_dn_pls <= '1';
            else
                mem_clr_dn_pls <= '0';
            end if;
        end if;
    end process;

    U_FB_DLY_COMP_I : BUF_SAMPLE_DLY generic map("DISTRIBUTED", "CLOCK", 16, 2) port map(RST, CLK, "11", FB_VLD_IN, FB_I_IN, fb_sample_dly_i);
    U_FB_DLY_COMP_Q : BUF_SAMPLE_DLY generic map("DISTRIBUTED", "CLOCK", 16, 2) port map(RST, CLK, "11", FB_VLD_IN, FB_Q_IN, fb_sample_dly_q);

    P_S2_ACCU_MEM_CTRL : process(RST, CLK) begin
        if (RST = '1') then
            accu_mem_en        <= '0';
            accu_mem_addr      <= (others => '1');
            accu_mem_addr_d2   <= (others => (others => '1'));

            fb_sample_dly_i_d2 <= (others => (others => '0'));
            fb_sample_dly_q_d2 <= (others => (others => '0'));

        elsif (CLK'event) and (CLK = '1') then
            fb_sample_dly_i_d2 <= fb_sample_dly_i_d2(1 downto 0)& fb_sample_dly_i;
            fb_sample_dly_q_d2 <= fb_sample_dly_q_d2(1 downto 0)& fb_sample_dly_q;

            if (accu_st_en = '1') then
                if (accu_indicator = '1') or (accu_indicator_wr = '1') then
                    accu_mem_en <= FB_VLD_IN;
                else
                    accu_mem_en <= '0';
                end if;
            else
                accu_mem_en <= '0';
            end if;

            if (accu_st_en = '1') then
                if (accu_indicator = '1') then
                    if (FB_VLD_IN = '1') then
                        accu_mem_addr <= accu_mem_addr + '1';
                    else
                        accu_mem_addr <= accu_mem_addr;
                    end if;
                else
                    accu_mem_addr <= accu_mem_addr;
                end if;
            else
                accu_mem_addr <= (others => '1');
            end if;

            accu_mem_addr_d2 <= accu_mem_addr_d2(1 downto 0)&accu_mem_addr;
        end if;
    end process;

    G_S2_ACCU_HOVS1 : if (HOVS = 1) generate begin 
        P_S2_ACCU_HOVS1 : process(RST, CLK) begin
            if (RST = '1') then
                accu_mem_i         <= (others => '0');
                accu_mem_q         <= (others => '0');
                accu_mem_addr_dly  <= (others => '1');
            elsif (CLK'event) and (CLK = '1') then
                if (accu_st_en_wr = '1') then
                    if (accu_indicator_wr = '1') then
                        accu_mem_i <= mem_rdata_i + sign_extension(fb_sample_dly_i_d2(2), 32);
                        accu_mem_q <= mem_rdata_q + sign_extension(fb_sample_dly_q_d2(2), 32);
                    else
                        accu_mem_i <= (others => '0');
                        accu_mem_q <= (others => '0');
                    end if;
                else
                    accu_mem_i <= (others => '0');
                    accu_mem_q <= (others => '0');
                end if;

                accu_mem_addr_dly <= accu_mem_addr_d2(2);
            end if;
        end process;
    end generate;

    G_S2_ACCU_HOVS2 : if (HOVS = 2) generate begin 
        P_S2_ACCU_HOVS2 : process(RST, CLK) begin
            if (RST = '1') then
                accu_mem_i         <= (others => '0');
                accu_mem_q         <= (others => '0');
                accu_mem_addr_dly  <= (others => '1');
            elsif (CLK'event) and (CLK = '1') then
                if (accu_st_en_wr = '1') then
                    if (accu_indicator_wr = '1') then
                        if (FB_VLD_IN = '1') then
                            accu_mem_i <= mem_rdata_i + sign_extension(fb_sample_dly_i_d2(1), 32);
                            accu_mem_q <= mem_rdata_q + sign_extension(fb_sample_dly_q_d2(1), 32);
                        else
                            accu_mem_i <= accu_mem_i;
                            accu_mem_q <= accu_mem_q;
                        end if;
                    else
                        accu_mem_i <= (others => '0');
                        accu_mem_q <= (others => '0');
                    end if;
                else
                    accu_mem_i <= (others => '0');
                    accu_mem_q <= (others => '0');
                end if;

                if (FB_VLD_IN = '1') then
                    accu_mem_addr_dly <= accu_mem_addr_d2(1);
                else
                    accu_mem_addr_dly <= accu_mem_addr_dly;
                end if;
            end if;
        end process;
    end generate;


    U_ACCU_I_MEM : SIMPLE_DPRAM 
    generic map(
        RAM_TYPE               => "BLOCK"        , 
        RAM_INIT_VALUE         =>      0         , 
                                                 
        DATA_WIDTH             =>     32         , 
        ADDR_WIDTH             =>      9           
        )
    port map(
        CLK_A	                => CLK            , 
        EN_A                    => mem_en_i       , 
        WE_A                    => mem_wren       , 
        ADDR_A                  => mem_waddr      , 
        DATA_A                  => mem_wdata_i    , 
   
        CLK_B                   => CLK            ,
        EN_B                    => mem_en_i       , 
        ADDR_B                  => mem_raddr_i    , 
        DATA_B                  => mem_rdata_i                 
        );

    U_ACCU_Q_MEM : SIMPLE_DPRAM 
    generic map(
        RAM_TYPE               => "BLOCK"        , 
        RAM_INIT_VALUE         =>      0         , 
                                                 
        DATA_WIDTH             =>     32         , 
        ADDR_WIDTH             =>      9           
        )
    port map(
        CLK_A	                => CLK            , 
        EN_A                    => mem_en_q       , 
        WE_A                    => mem_wren       , 
        ADDR_A                  => mem_waddr      , 
        DATA_A                  => mem_wdata_q    , 
   
        CLK_B                   => CLK            ,
        EN_B                    => mem_en_q       , 
        ADDR_B                  => mem_raddr_q    , 
        DATA_B                  => mem_rdata_q                 
        );

    P_Done_Flag_Clocking : process(RST, CLK) begin
        if (RST = '1') then
            ACCU_DONE_FLG_OUT <= '1';
        elsif (CLK'event) and (CLK = '1') then
            ACCU_DONE_FLG_OUT <= accu_done_flg;
        end if;
    end process;

    MEM_DATA_I_OUT    <= mem_rdata_i_rpt;
    MEM_DATA_Q_OUT    <= mem_rdata_q_rpt;

end arc_RX_SSD_ACCUMULATOR;



