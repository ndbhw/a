library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity PIMD_SRC_PROC is
generic(
    DEVICE                       : string  := "ULTRASCALE";
    HOVS                         : natural :=           1 ;
   
    TX_ANT_NUM                   : natural :=           4 ;
    PIM_SRC_NUM                  : natural :=           2   -- B2 : 3, B66 : 2
    );
port(
    RST                          : in  std_logic;           -- Reset, Active High
    CLK                          : in  std_logic;

    PIM_CFR_REF_SEL_IN           : in  std_logic_vector( TX_ANT_NUM-1 downto 0); 

    PIM_CFR_REF_VLD_IN           : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_CFR_REF_I_IN             : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_CFR_REF_Q_IN             : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    PIM_INTERB_SRC_I_IN          : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_INTERB_SRC_Q_IN          : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    PIM_CFR_REF_VLD_OUT          : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_CFR_REF_I_OUT            : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_CFR_REF_Q_OUT            : out std_logic_array16(TX_ANT_NUM-1 downto 0);

    PIM_INTERB_SRC_I_OUT         : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_INTERB_SRC_Q_OUT         : out std_logic_array16(TX_ANT_NUM-1 downto 0) 
    );
end PIMD_SRC_PROC;

architecture arc_PIMD_SRC_PROC of PIMD_SRC_PROC is

component COMPLEX_MULTIPLIER is
generic(
    DEVICE                       : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HOVS                         : natural :=        1 ;

    INPUT_WIDTH                  : natural :=       16 ; -- AIN bitwidth : 0 to 29
    RND_EN                       : boolean :=     TRUE ; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT                      : natural :=       15 ; -- Rounding bit  
    OUTPUT_WIDTH                 : natural :=       16   -- Result bitwidth : 0 to 47
    );
port(
    RST                          : in  std_logic;
    CLK                          : in  std_logic;

    DATA_VLD_IN                  : in  std_logic;
    ADATA_I_IN                   : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    ADATA_Q_IN                   : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
                                                          
    BDATA_I_IN                   : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    BDATA_Q_IN                   : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
   
    DATA_VLD_OUT                 : out std_logic;
    DATA_I_OUT                   : out std_logic_vector(OUTPUT_WIDTH-1 downto 0);
    DATA_Q_OUT                   : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
end component;

component SRL16E_DLY is
generic(
    DEVICE                       : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HS_MODE                      : boolean :=        TRUE ;

    BIT_WIDTH                    : natural;
    DELAY_NUM                    : natural
    );
port(
    CLK                          : in  std_logic;
    DATA_IN                      : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT                     : out std_logic_vector(BIT_WIDTH-1 downto 0) 
    );
end component;

signal align_vld                 : std_logic_vector( TX_ANT_NUM-1 downto 0);

signal cfr_ref_align_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal cfr_ref_align_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal interb_src_align_i        : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal interb_src_align_q        : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal align_vld_d1              : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal align_out_vld             : std_logic_vector( TX_ANT_NUM-1 downto 0);

-- PIM_SRC_NUM : 3
signal cfr_ref_i_d1              : std_logic_array17(TX_ANT_NUM-1 downto 0);
signal cfr_ref_q_d1              : std_logic_array17(TX_ANT_NUM-1 downto 0);

signal cfr_ref_i_sel             : std_logic_array17(TX_ANT_NUM-1 downto 0);
signal cfr_ref_q_sel             : std_logic_array17(TX_ANT_NUM-1 downto 0);


signal interb_src_i_d1           : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal interb_src_q_d1           : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal interb_src_i_conj         : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal interb_src_q_conj         : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal interb_src_i_sel          : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal interb_src_q_sel          : std_logic_array16(TX_ANT_NUM-1 downto 0);

-- PIM_SRC_NUM : 2
signal cfr_ref_i_conj            : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal cfr_ref_q_conj            : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal cfr_ref_out_i             : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal cfr_ref_out_q             : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal interb_src_out_i          : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal interb_src_out_q          : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal align_out_vld_d1          : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal cfr_ref_out_i_align       : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal cfr_ref_out_q_align       : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal interb_src_out_i_align    : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal interb_src_out_q_align    : std_logic_array16(TX_ANT_NUM-1 downto 0);



begin

    -- Input valid align
    P_Input_Align_HS : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            align_vld          <= PIM_CFR_REF_VLD_IN;                   
            
            cfr_ref_align_i    <= PIM_CFR_REF_I_IN;       
            cfr_ref_align_q    <= PIM_CFR_REF_Q_IN;       
                                                               
            interb_src_align_i <= PIM_INTERB_SRC_I_IN;       
            interb_src_align_q <= PIM_INTERB_SRC_Q_IN;       
        end if;
    end process;

    G_TX_PATH_GEN : for I in 0 to (TX_ANT_NUM-1) generate begin
    -- *********************************************************************
    -- B2  : PIM_SRC_NUM : 3
    -- *********************************************************************
        G_PIM_SRC_3 : if (PIM_SRC_NUM = 3) generate begin
            -- 2 Clock
            P_InterBand_SRC_CONJ : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    interb_src_i_d1(I)   <= interb_src_align_i(I);
                    interb_src_q_d1(I)   <= interb_src_align_q(I);

                    interb_src_i_conj(I) <= interb_src_align_i(I);
                    interb_src_q_conj(I) <= (not interb_src_align_q(I)) + '1';

                    if (PIM_CFR_REF_SEL_IN(I) = '1') then            
                        interb_src_i_sel(I)  <= interb_src_i_d1(I);
                        interb_src_q_sel(I)  <= interb_src_q_d1(I);
                    else
                        interb_src_i_sel(I)  <= interb_src_i_conj(I);
                        interb_src_q_sel(I)  <= interb_src_q_conj(I); 
                    end if;
                end if;
            end process;

            -- 1 Clock
            P_PIM_REF_SRC_SEL : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    align_vld_d1(I)  <= align_vld(I);      
                    cfr_ref_i_d1(I)  <= sign_extension(cfr_ref_align_i(I), 17);
                    cfr_ref_q_d1(I)  <= sign_extension(cfr_ref_align_q(I), 17);

                    if (PIM_CFR_REF_SEL_IN(I) = '1') then            
                        cfr_ref_i_sel(I) <= '0'&x"8000"; 
                        cfr_ref_q_sel(I) <= '0'&x"0000"; 
                    else
                        cfr_ref_i_sel(I) <= sign_extension(cfr_ref_align_i(I), 17); 
                        cfr_ref_q_sel(I) <= sign_extension(cfr_ref_align_q(I), 17); 
                    end if;
                end if;
            end process;

            U_InterB_SRC_I_DLY : SRL16E_DLY generic map(DEVICE, TRUE, 16, 7) port map(CLK, interb_src_i_sel(I), interb_src_out_i(I));            
            U_InterB_SRC_Q_DLY : SRL16E_DLY generic map(DEVICE, TRUE, 16, 7) port map(CLK, interb_src_q_sel(I), interb_src_out_q(I));            

            U_PIM_CFR_REF_Square : COMPLEX_MULTIPLIER 
            generic map(
                DEVICE                       => DEVICE                       , 
                HOVS                         => HOVS                         ,
            
                INPUT_WIDTH                  => 17                           ,
                RND_EN                       => TRUE                         ,
                RND_BIT                      => 15                           ,
                OUTPUT_WIDTH                 => 16                            
                )
            port map(
                RST                          => RST                          ,
                CLK                          => CLK                          ,
            
                DATA_VLD_IN                  => align_vld_d1(I)              ,
                ADATA_I_IN                   => cfr_ref_i_d1(I)              ,
                ADATA_Q_IN                   => cfr_ref_q_d1(I)              ,

                BDATA_I_IN                   => cfr_ref_i_sel(I)             ,
                BDATA_Q_IN                   => cfr_ref_q_sel(I)             ,
               
                DATA_VLD_OUT                 => align_out_vld(I)             ,
                DATA_I_OUT                   => cfr_ref_out_i(I)           ,
                DATA_Q_OUT                   => cfr_ref_out_q(I)            
                );

            -- Unused Signals
            cfr_ref_i_conj(I)     <= (others => '0');
            cfr_ref_q_conj(I)     <= (others => '0');

        end generate;

    -- *********************************************************************
    -- B66 : PIM_SRC_NUM : 2
    -- *********************************************************************
        G_B66_PIM_SRC_2 : if (PIM_SRC_NUM = 2) generate begin

            -- 1 Clock
            P_InterBand_SRC_CONJ : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    cfr_ref_i_conj(I) <= cfr_ref_align_i(I);
                    cfr_ref_q_conj(I) <= (not cfr_ref_align_q(I)) + '1';
                end if;
            end process;

            U_CFR_REF_SRC_I_DLY : SRL16E_DLY generic map(DEVICE, TRUE, 16, 7) port map(CLK, cfr_ref_i_conj(I), cfr_ref_out_i(I));            
            U_CFR_REF_SRC_Q_DLY : SRL16E_DLY generic map(DEVICE, TRUE, 16, 7) port map(CLK, cfr_ref_q_conj(I), cfr_ref_out_q(I));            

            U_InterB_SRC_Square : COMPLEX_MULTIPLIER 
            generic map(
                DEVICE                       => DEVICE                       , 
                HOVS                         => HOVS                         ,
            
                INPUT_WIDTH                  => 16                           ,
                RND_EN                       => TRUE                         ,
                RND_BIT                      => 15                           ,
                OUTPUT_WIDTH                 => 16                            
                )
            port map(
                RST                          => RST                          ,
                CLK                          => CLK                          ,
            
                DATA_VLD_IN                  => align_vld(I)                 ,
                ADATA_I_IN                   => interb_src_align_i(I)        ,
                ADATA_Q_IN                   => interb_src_align_q(I)        ,

                BDATA_I_IN                   => interb_src_align_i(I)        ,
                BDATA_Q_IN                   => interb_src_align_q(I)        ,
               
                DATA_VLD_OUT                 => align_out_vld(I)             ,
                DATA_I_OUT                   => interb_src_out_i(I)        ,
                DATA_Q_OUT                   => interb_src_out_q(I)            
                );

            -- Unused Signals
            align_vld_d1(I)      <= '0';             

            cfr_ref_i_d1(I)      <= (others => '0'); 
            cfr_ref_q_d1(I)      <= (others => '0'); 

            cfr_ref_i_sel(I)     <= (others => '0');  
            cfr_ref_q_sel(I)     <= (others => '0');  


            interb_src_i_d1(I)   <= (others => '0');
            interb_src_q_d1(I)   <= (others => '0');

            interb_src_i_conj(I) <= (others => '0');
            interb_src_q_conj(I) <= (others => '0');

            interb_src_i_sel(I)  <= (others => '0');
            interb_src_q_sel(I)  <= (others => '0');

        end generate;
    end generate;

    -- Output Valid Align
    P_Output_Align : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            for I in 0 to (TX_ANT_NUM-1) loop 
                align_out_vld_d1(I)       <= align_out_vld(I);             
                cfr_ref_out_i_align(I)    <= cfr_ref_out_i(I);
                cfr_ref_out_q_align(I)    <= cfr_ref_out_q(I);
                                             
                interb_src_out_i_align(I) <= interb_src_out_i(I);
                interb_src_out_q_align(I) <= interb_src_out_q(I);
            end loop;
        end if;
    end process;
 
    PIM_CFR_REF_VLD_OUT  <= align_out_vld_d1       ; 
    PIM_CFR_REF_I_OUT    <= cfr_ref_out_i_align    ; 
    PIM_CFR_REF_Q_OUT    <= cfr_ref_out_q_align    ; 
                            
    PIM_INTERB_SRC_I_OUT <= interb_src_out_i_align ; 
    PIM_INTERB_SRC_Q_OUT <= interb_src_out_q_align ; 


end arc_PIMD_SRC_PROC;
