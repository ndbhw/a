-- Designer         : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name       : CE_CLR_GEN 
-- Project          : SLR600 UQ only : Has two MBs for 4 DPD blocks

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

entity CE_CLR_GEN is
port(
    RST                  : in  std_logic;
    TRAFFIC_PLL_LOCK_IN  : in  std_logic;
    CLK                  : in  std_logic; -- DSP clock

    MDL_CE_CLR_OUT       : out std_logic;
    MDL_SYNC_RST_OUT     : out std_logic
    );
end CE_CLR_GEN;

architecture arc_CE_CLR_GEN of CE_CLR_GEN is

signal pll_traffic_rst   : std_logic :='1';
signal ce_clr_cnt        : std_logic_vector(19 downto 0);
signal ce_clr            : std_logic;

signal rst_sync_d1       : std_logic_vector(0 downto 0);
signal rst_sync_d2       : std_logic_vector(0 downto 0);
signal rst_sync_d3       : std_logic_vector(0 downto 0);
signal rst_sync_d4       : std_logic_vector(0 downto 0);

signal ce_clr_d1         : std_logic;
signal ce_clr_d2         : std_logic;
signal ce_clr_d3         : std_logic;
signal ce_clr_d4         : std_logic;
signal ce_clr_d5         : std_logic;

attribute EQUIVALENT_REGISTER_REMOVAL : string;
attribute EQUIVALENT_REGISTER_REMOVAL of ce_clr_d1   : signal is "NO";
attribute EQUIVALENT_REGISTER_REMOVAL of ce_clr_d2   : signal is "NO";
attribute EQUIVALENT_REGISTER_REMOVAL of ce_clr_d3   : signal is "NO";
attribute EQUIVALENT_REGISTER_REMOVAL of ce_clr_d4   : signal is "NO";
attribute EQUIVALENT_REGISTER_REMOVAL of ce_clr_d5   : signal is "NO";

attribute EQUIVALENT_REGISTER_REMOVAL of rst_sync_d1 : signal is "NO";
attribute EQUIVALENT_REGISTER_REMOVAL of rst_sync_d2 : signal is "NO";
attribute EQUIVALENT_REGISTER_REMOVAL of rst_sync_d3 : signal is "NO";
attribute EQUIVALENT_REGISTER_REMOVAL of rst_sync_d4 : signal is "NO";


begin

--========================================================================
-- CE_CLR Generate 
--========================================================================
    pll_traffic_rst <= not TRAFFIC_PLL_LOCK_IN;
    
    P_PLL_Lock_Time_Offset : process(pll_traffic_rst, CLK) begin
        if (pll_traffic_rst = '1') then
            ce_clr_cnt <= (others => '0');
            ce_clr     <= '1';
        elsif (CLK'event) and (CLK = '1') then
            if (ce_clr_cnt = x"fffff") then
                ce_clr_cnt <= ce_clr_cnt;
                ce_clr     <= '0';
            else
                ce_clr_cnt <= ce_clr_cnt +1;
                ce_clr     <= '1';
            end if;
        end if;
    end process;
        
    P_CE_CLR_5clocking : process(ce_clr, CLK) begin  --RST_CE_CLR
        if (ce_clr = '1') then
            ce_clr_d1 <= '1';
            ce_clr_d2 <= '1';
            ce_clr_d3 <= '1';
            ce_clr_d4 <= '1';
            ce_clr_d5 <= '1';
        elsif (CLK'event) and (CLK = '1') then
    	    ce_clr_d1 <= '0';
    	    ce_clr_d2 <= ce_clr_d1;
    	    ce_clr_d3 <= ce_clr_d2;
    	    ce_clr_d4 <= ce_clr_d3;
    	    ce_clr_d5 <= ce_clr_d4;
        end if;
    end process;
    	
    MDL_CE_CLR_OUT <= ce_clr_d5;

    P_RST_CE_CLR : process(ce_clr, CLK) begin  --RST_CE_CLR
        if (ce_clr = '1') then
            rst_sync_d1 <= "1";
            rst_sync_d2 <= "1";
            rst_sync_d3 <= "1";
            rst_sync_d4 <= "1";
        elsif (CLK'event) and (CLK = '1') then
            rst_sync_d1(0) <= RST;
            rst_sync_d2    <= rst_sync_d1;
            rst_sync_d3    <= rst_sync_d2;
            rst_sync_d4    <= rst_sync_d3;
        end if;
    end process;

    MDL_SYNC_RST_OUT <= rst_sync_d4(0);

end arc_CE_CLR_GEN;

