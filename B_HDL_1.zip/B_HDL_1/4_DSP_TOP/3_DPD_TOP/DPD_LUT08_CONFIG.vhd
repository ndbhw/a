library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity DPD_LUT08_CONFIG is
generic(
    DEVICE                   : string  := "ULTRASCALE";
    HS_MODE                  : boolean :=       FALSE ;
    TX_ANT_NUM               : natural :=           4 ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_RAM_NUM              : natural :=           8 ;
    DPD_TAP_NUM              : natural :=           4
    );
port(
    RST                      : in  std_logic;
    CLK                      : in  std_logic;
   
    LUT_DATA_VLD             : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    MAG                      : in  std_logic_array9( TX_ANT_NUM-1 downto 0);
    LUT_ADDR                 : out std_logic_array8_array9( TX_ANT_NUM-1 downto 0);

    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);
    LUT_RDATA_IN             : in  std_logic_array8_array32(TX_ANT_NUM downto 0);

    LUT_ADD_I                : out std_logic_array4_array16(TX_ANT_NUM-1 downto 0);
    LUT_ADD_Q                : out std_logic_array4_array16(TX_ANT_NUM-1 downto 0)
    );
end DPD_LUT08_CONFIG;

architecture arc_DPD_LUT08_CONFIG of DPD_LUT08_CONFIG is

-- Latency 8
component ADD4 is
generic(
    HS_MODE      : boolean := FALSE;
    BITWIDTH     : natural := 16
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
  
    DATA0_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA1_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA2_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA3_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
                                                
    DATA_OUT     : out std_logic_vector(BITWIDTH+1 downto 0)
    );
end component;

component SRL16E_DLY is
generic(
    DEVICE       : string  := "ULTRASCALE";
    HS_MODE      : boolean :=       FALSE ;

    BIT_WIDTH    : natural;            -- 2 to 64
    DELAY_NUM    : natural
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;

    DATA_IN      : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT     : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end component;

signal dpd_lut_output_switch : std_logic_array4(TX_ANT_NUM-1 downto 0);
signal lut_rdata_i           : std_logic_array8_array16(TX_ANT_NUM downto 0);
signal lut_rdata_q           : std_logic_array8_array16(TX_ANT_NUM downto 0);

signal lut_rdata_sw_i        : std_logic_array8_array16(TX_ANT_NUM-1 downto 0);
signal lut_rdata_sw_q        : std_logic_array8_array16(TX_ANT_NUM-1 downto 0);

signal mag_sh                : std_logic_array5_array9(TX_ANT_NUM-1 downto 0);
signal magnitude             : std_logic_array4_array9(TX_ANT_NUM-1 downto 0);

signal lut_mpa1_i            : std_logic_array18(TX_ANT_NUM-1 downto 0);
signal lut_mpa1_q            : std_logic_array18(TX_ANT_NUM-1 downto 0);

signal lut_mp00_i            : std_logic_array18(TX_ANT_NUM-1 downto 0);
signal lut_mp00_q            : std_logic_array18(TX_ANT_NUM-1 downto 0);

signal lut_mp01_i            : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal lut_mp01_q            : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal lut_mp02_i            : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal lut_mp02_q            : std_logic_array16(TX_ANT_NUM-1 downto 0);

attribute KEEP : string;
attribute KEEP of dpd_lut_output_switch : signal is "TRUE";
attribute KEEP of lut_rdata_sw_i        : signal is "TRUE";
attribute KEEP of lut_rdata_sw_q        : signal is "TRUE";

attribute MAX_FANOUT : integer;
attribute MAX_FANOUT of dpd_lut_output_switch : signal is ternary_func(HS_MODE=TRUE, 20, 2000);

begin

    -- LUT Read Data Align
    G_LUT_RDATA_Assign_TX_ANT : for I in 0 to (TX_ANT_NUM) generate begin
        G_LUT_RDATA_Assign_LUT_RAM : for J in 0 to (LUT_RAM_NUM-1) generate begin
            lut_rdata_i(I)(J) <= LUT_RDATA_IN(I)(J)(31 downto 16); 
            lut_rdata_q(I)(J) <= LUT_RDATA_IN(I)(J)(15 downto  0); 
        end generate;
    end generate;

    G_LUT_Non_Optimized : if (LUT_OPTIMIZED = FALSE) generate begin            
        P_LUT_Rdata_Clocking_Normal_Operation : if (HS_MODE = FALSE) generate begin
            P_LUT_Rdata_Clocking_NM : process(RST, CLK) begin
                if (RST = '1') then
                    lut_rdata_sw_i <= (others => (others => (others => '0')));
                    lut_rdata_sw_q <= (others => (others => (others => '0')));
                elsif (CLK'event) and (CLK = '1') then
                    lut_rdata_sw_i <= lut_rdata_i(TX_ANT_NUM-1 downto 0);
                    lut_rdata_sw_q <= lut_rdata_q(TX_ANT_NUM-1 downto 0);
                end if;
            end process;
        end generate;

        P_LUT_Rdata_Clocking_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
            P_LUT_Rdata_Clocking_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    lut_rdata_sw_i <= lut_rdata_i(TX_ANT_NUM-1 downto 0);
                    lut_rdata_sw_q <= lut_rdata_q(TX_ANT_NUM-1 downto 0);
                end if;
            end process;
        end generate;

        dpd_lut_output_switch <= (others => (others => '0')); 
    end generate;

    G_LUT_Optimized_Switch : if (LUT_OPTIMIZED = TRUE) generate begin            
        G_LUT_RDATA_SW : for I in 0 to (TX_ANT_NUM-1) generate begin
            G_LUT_RDATA_SW_Normal_Operation : if (HS_MODE = FALSE) generate begin
                P_LUT_RDATA_SW_NM : process(RST, CLK) begin
                    if (RST = '1') then
                        dpd_lut_output_switch(I) <= (others => '0');
                    elsif (CLK'event) and (CLK = '1') then 
                        dpd_lut_output_switch(I) <= DPD_LUT_OUTPUT_SWITCH_IN(4*I+3 downto 4*I);
                    end if;
                end process;
            end generate;

            G_LUT_RDATA_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_LUT_RDATA_SW_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then 
                        dpd_lut_output_switch(I) <= DPD_LUT_OUTPUT_SWITCH_IN(4*I+3 downto 4*I);
                    end if;
                end process;
            end generate;
        end generate;

        G_LUT_Rdata_Switching_ANT2 : if (TX_ANT_NUM = 2) generate begin
            G_LUT_RDATA_SW_ANT2_Normal_Operation : if (HS_MODE = FALSE) generate begin
                P_LUT_Rdata_2Path_Switch_NM : process(RST, CLK) begin
                    if (RST = '1') then
                        lut_rdata_sw_i <= (others => (others => (others => '0')));
                        lut_rdata_sw_q <= (others => (others => (others => '0')));
                    elsif (CLK'event) and (CLK = '1') then
                        case (dpd_lut_output_switch(0)) is 
                            when x"0"   => lut_rdata_sw_i(0) <= lut_rdata_i(0);              lut_rdata_sw_q(0) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(0) <= lut_rdata_i(1);              lut_rdata_sw_q(0) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(0) <= lut_rdata_i(2);              lut_rdata_sw_q(0) <= lut_rdata_q(2);
                            when others => lut_rdata_sw_i(0) <= (others => (others => '0')); lut_rdata_sw_q(0) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(1)) is 
                            when x"0"   => lut_rdata_sw_i(1) <= lut_rdata_i(0);              lut_rdata_sw_q(1) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(1) <= lut_rdata_i(1);              lut_rdata_sw_q(1) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(1) <= lut_rdata_i(2);              lut_rdata_sw_q(1) <= lut_rdata_q(2);
                            when others => lut_rdata_sw_i(1) <= (others => (others => '0')); lut_rdata_sw_q(1) <= (others => (others => '0'));
                        end case;
                    end if;
                end process;
            end generate;

            G_LUT_RDATA_SW_ANT2_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_LUT_Rdata_2Path_Switch_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (dpd_lut_output_switch(0)) is 
                            when x"0"   => lut_rdata_sw_i(0) <= lut_rdata_i(0);              lut_rdata_sw_q(0) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(0) <= lut_rdata_i(1);              lut_rdata_sw_q(0) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(0) <= lut_rdata_i(2);              lut_rdata_sw_q(0) <= lut_rdata_q(2);
                            when others => lut_rdata_sw_i(0) <= (others => (others => '0')); lut_rdata_sw_q(0) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(1)) is 
                            when x"0"   => lut_rdata_sw_i(1) <= lut_rdata_i(0);              lut_rdata_sw_q(1) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(1) <= lut_rdata_i(1);              lut_rdata_sw_q(1) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(1) <= lut_rdata_i(2);              lut_rdata_sw_q(1) <= lut_rdata_q(2);
                            when others => lut_rdata_sw_i(1) <= (others => (others => '0')); lut_rdata_sw_q(1) <= (others => (others => '0'));
                        end case;
                    end if;
                end process;
            end generate;
        end generate;

        G_LUT_Rdata_Switching_ANT4 : if (TX_ANT_NUM = 4) generate begin
            G_LUT_RDATA_SW_ANT4_Normal_Operation : if (HS_MODE = FALSE) generate begin
                P_LUT_Rdata_4Path_Switch_NM : process(RST, CLK) begin
                    if (RST = '1') then
                        lut_rdata_sw_i <= (others => (others => (others => '0')));
                        lut_rdata_sw_q <= (others => (others => (others => '0')));
                    elsif (CLK'event) and (CLK = '1') then
                        case (dpd_lut_output_switch(0)) is 
                            when x"0"   => lut_rdata_sw_i(0) <= lut_rdata_i(0);              lut_rdata_sw_q(0) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(0) <= lut_rdata_i(1);              lut_rdata_sw_q(0) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(0) <= lut_rdata_i(2);              lut_rdata_sw_q(0) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(0) <= lut_rdata_i(3);              lut_rdata_sw_q(0) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(0) <= lut_rdata_i(4);              lut_rdata_sw_q(0) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(0) <= (others => (others => '0')); lut_rdata_sw_q(0) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(1)) is 
                            when x"0"   => lut_rdata_sw_i(1) <= lut_rdata_i(0);              lut_rdata_sw_q(1) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(1) <= lut_rdata_i(1);              lut_rdata_sw_q(1) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(1) <= lut_rdata_i(2);              lut_rdata_sw_q(1) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(1) <= lut_rdata_i(3);              lut_rdata_sw_q(1) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(1) <= lut_rdata_i(4);              lut_rdata_sw_q(1) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(1) <= (others => (others => '0')); lut_rdata_sw_q(1) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(2)) is 
                            when x"0"   => lut_rdata_sw_i(2) <= lut_rdata_i(0);              lut_rdata_sw_q(2) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(2) <= lut_rdata_i(1);              lut_rdata_sw_q(2) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(2) <= lut_rdata_i(2);              lut_rdata_sw_q(2) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(2) <= lut_rdata_i(3);              lut_rdata_sw_q(2) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(2) <= lut_rdata_i(4);              lut_rdata_sw_q(2) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(2) <= (others => (others => '0')); lut_rdata_sw_q(2) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(3)) is 
                            when x"0"   => lut_rdata_sw_i(3) <= lut_rdata_i(0);              lut_rdata_sw_q(3) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(3) <= lut_rdata_i(1);              lut_rdata_sw_q(3) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(3) <= lut_rdata_i(2);              lut_rdata_sw_q(3) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(3) <= lut_rdata_i(3);              lut_rdata_sw_q(3) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(3) <= lut_rdata_i(4);              lut_rdata_sw_q(3) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(3) <= (others => (others => '0')); lut_rdata_sw_q(3) <= (others => (others => '0'));
                        end case;
                    end if;
                end process;
            end generate;

            G_LUT_RDATA_SW_ANT4_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_LUT_Rdata_4Path_Switch_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (dpd_lut_output_switch(0)) is 
                            when x"0"   => lut_rdata_sw_i(0) <= lut_rdata_i(0);              lut_rdata_sw_q(0) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(0) <= lut_rdata_i(1);              lut_rdata_sw_q(0) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(0) <= lut_rdata_i(2);              lut_rdata_sw_q(0) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(0) <= lut_rdata_i(3);              lut_rdata_sw_q(0) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(0) <= lut_rdata_i(4);              lut_rdata_sw_q(0) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(0) <= (others => (others => '0')); lut_rdata_sw_q(0) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(1)) is 
                            when x"0"   => lut_rdata_sw_i(1) <= lut_rdata_i(0);              lut_rdata_sw_q(1) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(1) <= lut_rdata_i(1);              lut_rdata_sw_q(1) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(1) <= lut_rdata_i(2);              lut_rdata_sw_q(1) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(1) <= lut_rdata_i(3);              lut_rdata_sw_q(1) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(1) <= lut_rdata_i(4);              lut_rdata_sw_q(1) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(1) <= (others => (others => '0')); lut_rdata_sw_q(1) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(2)) is 
                            when x"0"   => lut_rdata_sw_i(2) <= lut_rdata_i(0);              lut_rdata_sw_q(2) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(2) <= lut_rdata_i(1);              lut_rdata_sw_q(2) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(2) <= lut_rdata_i(2);              lut_rdata_sw_q(2) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(2) <= lut_rdata_i(3);              lut_rdata_sw_q(2) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(2) <= lut_rdata_i(4);              lut_rdata_sw_q(2) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(2) <= (others => (others => '0')); lut_rdata_sw_q(2) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(3)) is 
                            when x"0"   => lut_rdata_sw_i(3) <= lut_rdata_i(0);              lut_rdata_sw_q(3) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(3) <= lut_rdata_i(1);              lut_rdata_sw_q(3) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(3) <= lut_rdata_i(2);              lut_rdata_sw_q(3) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(3) <= lut_rdata_i(3);              lut_rdata_sw_q(3) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(3) <= lut_rdata_i(4);              lut_rdata_sw_q(3) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(3) <= (others => (others => '0')); lut_rdata_sw_q(3) <= (others => (others => '0'));
                        end case;
                    end if;
                end process;
            end generate;
        end generate;
    end generate;

    G_TX_ANT : for I in 0 to (TX_ANT_NUM-1) generate begin

        mag_sh(I)(0) <= MAG(I);

        G_Magnitude_time_shift : for J in 0 to (DPD_TAP_NUM-1) generate begin 
            G_Normal_Operation : if (HS_MODE = FALSE) generate begin
                P_Magnitude_Time_Shift_NM : process(RST, CLK) begin
                    if (RST = '1') then
                        mag_sh(I)(J+1) <= (others => '0');
                    elsif (CLK'event) and (CLK = '1') then
                        if (LUT_DATA_VLD(I) = '1') then
                            mag_sh(I)(J+1) <= mag_sh(I)(J);
                        else
                            mag_sh(I)(J+1) <= mag_sh(I)(J+1);
                        end if;
                    end if;
                end process;
            end generate;

            G_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_Magnitude_Time_Shift_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        mag_sh(I)(J+1) <= mag_sh(I)(J);
                    end if;
                end process;
            end generate;

        end generate;

        magnitude(I) <= mag_sh(I)(DPD_TAP_NUM downto 1);

        -- [Magnitude Index Mapping]==================================================== --
        --                                                                               --
        -- Can Modify according to DPD_CORE eqaution, Always need to check!!             --
        --                                                                               --
        -- ============================================================================= -- 

        -- magnitude(0) --> |x[n+1]|
        -- magnitude(1) --> |x[n]|
        -- magnitude(2) --> |x[n-1]|
        -- magnitude(3) --> |x[n-2]|

        -- LUT address Encoding  
        G_LUT_Address_Encoding_Normal_Operation : if (HS_MODE = FALSE) generate begin
	    P_LUT_Address_Encoding_NM : process(RST, CLK) begin
                if (RST = '1') then
                    LUT_ADDR(I) <= (others => (others =>'0'));
                elsif (CLK'event) and (CLK = '1') then
                    LUT_ADDR(I)(0)  <= magnitude(I)(1);   -- MP0 , |x[n]|
                    LUT_ADDR(I)(1)  <= magnitude(I)(2);   -- MP1 , |x[n-1]|
                    LUT_ADDR(I)(2)  <= magnitude(I)(3);   -- MP2 , |x[n-2]|
                    LUT_ADDR(I)(3)  <= magnitude(I)(2);   -- MP0 , |x[n-1]|
                    LUT_ADDR(I)(4)  <= magnitude(I)(3);   -- MP0 , |x[n-2]|
                    LUT_ADDR(I)(5)  <= magnitude(I)(0);   -- MPA1, |x[n+1]|
                    LUT_ADDR(I)(6)  <= magnitude(I)(0);   -- MP0 , |x[n+1]|
                    LUT_ADDR(I)(7)  <= magnitude(I)(1);   -- MPA1, |x[n]|
                end if;
            end process;
        end generate;

        G_LUT_Address_Encoding_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
	    P_LUT_Address_Encoding_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    LUT_ADDR(I)(0)  <= magnitude(I)(1);   -- MP0 , |x[n]|
                    LUT_ADDR(I)(1)  <= magnitude(I)(2);   -- MP1 , |x[n-1]|
                    LUT_ADDR(I)(2)  <= magnitude(I)(3);   -- MP2 , |x[n-2]|
                    LUT_ADDR(I)(3)  <= magnitude(I)(2);   -- MP0 , |x[n-1]|
                    LUT_ADDR(I)(4)  <= magnitude(I)(3);   -- MP0 , |x[n-2]|
                    LUT_ADDR(I)(5)  <= magnitude(I)(0);   -- MPA1, |x[n+1]|
                    LUT_ADDR(I)(6)  <= magnitude(I)(0);   -- MP0 , |x[n+1]|
                    LUT_ADDR(I)(7)  <= magnitude(I)(1);   -- MPA1, |x[n]|
                end if;
            end process;
        end generate;

        -- [Summation Diagonal/Off-Diagonal Term]======================================= --
        --                                                                               --
        -- Can Modify according to DPD_CORE eqaution, Always need to check!!             --
        --                                                                               --
        -- ============================================================================= -- 

        -- MP_LUT_MAPPING, Latency3
        -- MPA1 LUT output summation : MPA1, |x[n+1]|+|x[n]| => LUT5+LUT7
        U_MPA1_ADD_I : ADD4 generic map(HS_MODE, 16) port map(RST, CLK, lut_rdata_sw_i(I)( 5), (others => '0'),        lut_rdata_sw_i(I)( 7), (others => '0'),       lut_mpa1_i(I)); 
        U_MPA1_ADD_Q : ADD4 generic map(HS_MODE, 16) port map(RST, CLK, lut_rdata_sw_q(I)( 5), (others => '0'),        lut_rdata_sw_q(I)( 7), (others => '0'),       lut_mpa1_q(I)); 
                                                                                                                                      
        -- MP0  LUT output summation : MP0,  |x[n+1]|+|x[n]|+|x[n-1]|+|x[n-2]| --> LUT6+LUT0+LUT3+LUT4                                
        U_MP0_ADD_I  : ADD4 generic map(HS_MODE, 16) port map(RST, CLK, lut_rdata_sw_i(I)( 6), lut_rdata_sw_i(I)( 0),  lut_rdata_sw_i(I)( 3), lut_rdata_sw_i(I)( 4), lut_mp00_i(I)); 
        U_MP0_ADD_Q  : ADD4 generic map(HS_MODE, 16) port map(RST, CLK, lut_rdata_sw_q(I)( 6), lut_rdata_sw_q(I)( 0),  lut_rdata_sw_q(I)( 3), lut_rdata_sw_q(I)( 4), lut_mp00_q(I)); 
                                                                                                                                      
        -- MP1  LUT output summation : MP1,  |x[n-1]| --> LUT1                                                                        
        U_MP1_D3_I  : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 3) port map(RST, CLK, lut_rdata_sw_i(I)( 1), lut_mp01_i(I)); 
        U_MP1_D3_Q  : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 3) port map(RST, CLK, lut_rdata_sw_q(I)( 1), lut_mp01_q(I)); 
                                                                                                     
        -- MP2  LUT output summation : MP2,  |x[n-2]| --> LUT2                                       
        U_MP2_D3_I  : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 3) port map(RST, CLK, lut_rdata_sw_i(I)( 2), lut_mp02_i(I)); 
        U_MP2_D3_Q  : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 3) port map(RST, CLK, lut_rdata_sw_q(I)( 2), lut_mp02_q(I)); 

        LUT_ADD_I(I)(0) <= lut_mpa1_i(I)(17) & lut_mpa1_i(I)(14 downto 0);
        LUT_ADD_Q(I)(0) <= lut_mpa1_q(I)(17) & lut_mpa1_q(I)(14 downto 0);

        LUT_ADD_I(I)(1) <= lut_mp00_i(I)(17) & lut_mp00_i(I)(14 downto 0);
        LUT_ADD_Q(I)(1) <= lut_mp00_q(I)(17) & lut_mp00_q(I)(14 downto 0);

        LUT_ADD_I(I)(2) <= lut_mp01_i(I);
        LUT_ADD_Q(I)(2) <= lut_mp01_q(I);

        LUT_ADD_I(I)(3) <= lut_mp02_i(I);
        LUT_ADD_Q(I)(3) <= lut_mp02_q(I);

    end generate;

end arc_DPD_LUT08_CONFIG;
