-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name : CORDIC 
-- Project    : 

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity CORDIC is
generic(
    HS_MODE            : boolean :=  TRUE ; -- High Speed Mode (Operating Clock > 307.2MHz)

    STAGE_NUM          : natural :=     6 ;
    MAGN               : boolean :=  TRUE ;
    ANGLE              : boolean := FALSE
    );
port(
    CLK                : in  std_logic;

    DATA_I             : in  std_logic_vector(15 downto 0);
    DATA_Q             : in  std_logic_vector(15 downto 0);

    MAGNITUDE_OUT      : out std_logic_vector(15 downto 0);
    SIN_OUT            : out std_logic_vector(13 downto 0);
    COS_OUT            : out std_logic_vector(13 downto 0)
    );
end CORDIC;

architecture arc_CORDIC of CORDIC is

-- Latency : 4 clocks
component CORDIC_MAPPER is
generic(
    HS_MODE            : boolean :=  TRUE ; -- High Speed Mode (Operating Clock > 307.2MHz)
    ANGLE              : boolean := FALSE
    );
port(
    RST                : in  std_logic;
    CLK                : in  std_logic; 

    DATA_I_IN          : in  std_logic_vector(15 downto 0); 
    DATA_Q_IN          : in  std_logic_vector(15 downto 0); 

    DATA_I_OUT         : out std_logic_vector(18 downto 0); 
    DATA_Q_OUT         : out std_logic_vector(18 downto 0);

    SWAP_IQ_OUT        : out std_logic;
    SIGN_I_OUT         : out std_logic;
    SIGN_Q_OUT         : out std_logic
    );
end component;

-- Latency : 2 clocks
component CORDIC_STAGE is
   -- STAGE_NUM : 0 ~ 5
   -- 0 : 45.000 degree Shift
   -- 1 : 26.565 degree Shift
   -- 2 : 14.036 degree Shift
   -- 3 :  7.125 degree Shift
   -- 4 :  3.576 degree Shift
   -- 5 :  1.783 degree Shift
generic(
    HS_MODE            : boolean :=  TRUE; -- High Speed Mode (Operating Clock > 307.2MHz)
    STAGE_NUM          : natural 
    );
port(
    RST                : in  std_logic;
    CLK                : in  std_logic; 
    DATA_I_IN          : in  std_logic_vector(18 downto 0);
    DATA_Q_IN          : in  std_logic_vector(18 downto 0); 

    DATA_I_OUT         : out std_logic_vector(18 downto 0);
    DATA_Q_OUT         : out std_logic_vector(18 downto 0)     
    );
end component;

-- Latency : 7 Clock
component CORDIC_GAIN is
generic(
    HS_MODE            : boolean :=  TRUE  -- High Speed Mode (Operating Clock > 307.2MHz)
    );
port(
    RST                : in  std_logic;
    CLK                : in  std_logic; 

    MAGNITUDE_IN       : in  std_logic_vector(18 downto 0); 
    MAGNITUDE_GAIN_OUT : out std_logic_vector(15 downto 0)
    );
end component;

-- Latency : 4 Clock
component SIN_COS_LUT is
generic(
    HS_MODE            : boolean :=  TRUE  -- High Speed Mode (Operating Clock > 307.2MHz)
    );
port(
    RST                : in  std_logic;
    CLK                : in  std_logic;

    LUT_INDEX          : in  std_logic_vector( 4 downto 0);

    SIN                : out std_logic_vector(13 downto 0);
    COS                : out std_logic_vector(13 downto 0)
    );
end component;

-- Latency : 2 Clock
component CORDIC_DEMAPPER  is
generic(
    HS_MODE            : boolean :=  TRUE  -- High Speed Mode (Operating Clock > 307.2MHz)
    );
port(
    RST                : in  std_logic;
    CLK                : in  std_logic; -- 122.88MHz

    SIN_IN             : in  std_logic_vector(13 downto 0); 
    COS_IN             : in  std_logic_vector(13 downto 0); 
    I_SIGN_IN          : in  std_logic; 
    Q_SIGN_IN          : in  std_logic; 
    IQ_SWAP_IN         : in  std_logic;   

    SIN_OUT            : out std_logic_vector(13 downto 0); 
    COS_OUT            : out std_logic_vector(13 downto 0)
    );
end component;

signal iq_swap             : std_logic;
signal i_sign              : std_logic;
signal q_sign              : std_logic;

signal cordic_mapper_out_i : std_logic_vector(18 downto 0) := (others => '0');
signal cordic_mapper_out_q : std_logic_vector(18 downto 0) := (others => '0');

signal i_stage             : std_logic_array19(STAGE_NUM downto 0);
signal q_stage             : std_logic_array19(STAGE_NUM downto 0);

signal magnitude           : std_logic_vector(15 downto 0);

signal sin_cos_lut_index   : std_logic_vector( 4 downto 0);
signal sin_lut             : std_logic_vector(13 downto 0);
signal cos_lut             : std_logic_vector(13 downto 0);

signal i_sign_sh           : std_logic_vector(10 downto 0);
signal q_sign_sh           : std_logic_vector(10 downto 0);
signal iq_swap_sh          : std_logic_vector(10 downto 0);

signal sinout              : std_logic_vector(13 downto 0) := (others => '0');
signal cosout              : std_logic_vector(13 downto 0) := (others => '0');

begin

    -- Rotation of complex number
    -- latency = 4 clocks
    U_Cordic_Mapper : CORDIC_MAPPER 
    generic map(
        HS_MODE     => HS_MODE            ,
        ANGLE       => ANGLE
        )
    port map(
        RST         => '0'                , 
        CLK         => CLK                , 
    
        DATA_I_IN   => DATA_I             , 
        DATA_Q_IN   => DATA_Q             , 
    
        DATA_I_OUT  => cordic_mapper_out_i, 
        DATA_Q_OUT  => cordic_mapper_out_q, 
    
        SWAP_IQ_OUT => iq_swap            , 
        SIGN_I_OUT  => i_sign             , 
        SIGN_Q_OUT  => q_sign            
        );

    P_Cordic_Mapper_Out_1Clocking : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            i_stage(0) <= cordic_mapper_out_i;
            q_stage(0) <= cordic_mapper_out_q;
        end if;
    end process;

    -- Latency : 2*(STAGE_NUM) Clocks
    G_Cordic_Stage : for I in 0 to (STAGE_NUM-1) generate begin
        -- STAGE_NUM : 0 ~ 5
        -- 0 : 45.000 degree Shift
        -- 1 : 26.565 degree Shift
        -- 2 : 14.036 degree Shift
        -- 3 :  7.125 degree Shift
        -- 4 :  3.576 degree Shift
        -- 5 :  1.783 degree Shift
        U_CORDIC_STAGE : CORDIC_STAGE generic map(HS_MODE, I) port map('0', CLK, i_stage(I), q_stage(I), i_stage(I+1), q_stage(I+1)); 
    end generate;
        
    -- Latency : 7 Clocks
    U_Cordic_Gain : CORDIC_GAIN generic map(HS_MODE) port map('0', CLK, i_stage(STAGE_NUM), magnitude); 

    MAGNITUDE_OUT <= magnitude;


    G_Angle_Generate : if (ANGLE = TRUE) generate begin
        -- Sine/Cosine LUT Mapping
        -- Latency : 1 Clocks
        P_Sinusoidal_LUT_Index : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                sin_cos_lut_index <= q_stage(1)(18) & q_stage(2)(18) & q_stage(3)(18) & q_stage(4)(18) & q_stage(5)(18);
            end if;
        end process;

        -- Latency : 3 clocks
        U_SIN_COS_TABLE : SIN_COS_LUT
        generic map(
            HS_MODE   => HS_MODE
            )
        port map(
            RST       => '0'              , 
            CLK       => CLK              , 
        
            LUT_INDEX => sin_cos_lut_index, 
        
            SIN       => sin_lut          , 
            COS       => cos_lut            
            );

        -- Delay Compensation
        P_Delay_Compensation_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                i_sign_sh  <= i_sign_sh( 9 downto 0) & i_sign;
                q_sign_sh  <= q_sign_sh( 9 downto 0) & q_sign;
                iq_swap_sh <= iq_swap_sh(9 downto 0) & iq_swap;
            end if;
        end process;

        -- Latency : 2 clocks
        U_Cordic_Demapper : CORDIC_DEMAPPER
        generic map(
            HS_MODE    => HS_MODE
            )
        port map(
            RST        => '0'                      , 
            CLK        => CLK                      , 
        
            SIN_IN     => sin_lut                  , 
            COS_IN     => cos_lut                  , 
            I_SIGN_IN  => i_sign_sh(STAGE_NUM + 4) , 
            Q_SIGN_IN  => q_sign_sh(STAGE_NUM + 4) , 
            IQ_SWAP_IN => iq_swap_sh(STAGE_NUM + 4), 
        
            SIN_OUT    => sinout                   , 
            COS_OUT    => cosout                    
            );
    end generate;

    G_Angle_Non_Generate : if (ANGLE = FALSE) generate begin
        sinout <= (others => '0');                   
        cosout <= (others => '0');                   
    end generate;

    SIN_OUT <= sinout;
    COS_OUT <= cosout;

end arc_CORDIC;
