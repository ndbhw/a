library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity DPD_LUT17_WRAPPER is
generic(
    DEVICE                   : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
    TX_ANT_NUM               : natural :=           4 ;
    HOVS                     : natural :=           1 ;
    HS_MODE                  : boolean :=       FALSE ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_MEM_DEPTH            : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    LUT_RBTEST               : boolean :=        TRUE ;
    LUT_RAM_NUM              : natural :=          17 ;
    DPD_TAP_NUM              : natural :=          10 
    );
port(
    RST_DPD                  : in  std_logic;
    CLK_DPD                  : in  std_logic;

    DATA_VLD_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DATA_MAG09_IN            : in  std_logic_array9( TX_ANT_NUM-1 downto 0);

    DPD_COEF_I_OUT           : out std_logic_array10_array27(TX_ANT_NUM-1 downto 0);
    DPD_COEF_Q_OUT           : out std_logic_array10_array27(TX_ANT_NUM-1 downto 0);

    RST_CPU                  : in  std_logic;
    CLK_CPU                  : in  std_logic;

    DPD_LUT_RB_TEST_EN_IN    : in  std_logic;                                       -- LUT Read Back Test

    DPD_CDC_STRB_IN          : in  std_logic;
    DPD_LUT_INPUT_SWITCH_IN  : in  std_logic_vector(19 downto 0);                   -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);                   -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN     : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_RDEN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_ADDR_IN          : in  std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN         : in  std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT        : out std_logic_array32(TX_ANT_NUM-1 downto 0)         -- LUT Write IQ : I[31:16]/Q[15:0] 
    );
end DPD_LUT17_WRAPPER;

architecture arc_DPD_LUT17_WRAPPER of DPD_LUT17_WRAPPER is

--*******************************
-- Components                    
--*******************************

component DPD_LUT17_SWIF is
generic(
    TX_ANT_NUM                : natural :=     4 ;
    HS_MODE                   : boolean := FALSE ;
    LUT_OPTIMIZED             : boolean := FALSE ;
    LUT_RBTEST                : boolean := FALSE ;
    LUT_RAM_NUM               : natural :=    17 ;
    DPD_TAP_NUM               : natural :=    10 
    );
port(
    RST_CPU                   : in  std_logic;                                -- Reset, Active High, CPU Clock Domain
    CLK_CPU                   : in  std_logic;                                -- CPU Operating Clock

    DPD_LUT_RB_TEST_EN_IN     : in  std_logic;                                -- LUT Read Back Test

    DPD_CDC_STRB_IN           : in  std_logic;
    DPD_LUT_INPUT_SWITCH_IN   : in  std_logic_vector(19 downto 0);            -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN  : in  std_logic_vector(19 downto 0);            -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN      : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN           : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- LUT Write Enable
    DPD_LUT_RDEN_IN           : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- LUT Write Enable
    DPD_LUT_ADDR_IN           : in  std_logic_array15(TX_ANT_NUM-1 downto 0); -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN          : in  std_logic_array32(TX_ANT_NUM-1 downto 0); -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT         : out std_logic_array32(TX_ANT_NUm-1 downto 0); -- LUT Write IQ : I[31:16]/Q[15:0]

    RST_DPD                   : in  std_logic;                                -- Reset, Active High, DPD Clock Domain
    CLK_DPD                   : in  std_logic;                                -- DPD Operating Clock

    DPD_MAG_ADDR_IN           : in  std_logic_array17_array9(TX_ANT_NUM-1 downto 0);

    DPD_LUT_OUTPUT_SWITCH_OUT : out std_logic_vector(19 downto 0);            -- LUT Output Switch Control
    
    SW_LUT_UPDATE_SWITCH_OUT  : out std_logic_vector(TX_ANT_NUM-1 downto 0);
    SW_LUT_ENA_OUT            : out std_logic_array17(TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path
    SW_LUT_WREN_OUT           : out std_logic_array17(TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path
    SW_LUT_WADDR_OUT          : out std_logic_array9( TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path
    SW_LUT_WDATA_OUT          : out std_logic_array32(TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path

    SW_LUT_RADDR_OUT          : out std_logic_array17_array9( TX_ANT_NUM downto 0);
    SW_LUT_RBDATA_IN          : in  std_logic_array17_array32(TX_ANT_NUM downto 0)
    );
end component;

component DPD_LUT17_CONFIG is
generic(
    DEVICE                   : string  := "ULTRASCALE";
    HS_MODE                  : boolean :=       FALSE ;
    TX_ANT_NUM               : natural :=           4 ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_RAM_NUM              : natural :=          17 ;
    DPD_TAP_NUM              : natural :=          10
    );
port(
    RST                      : in  std_logic;
    CLK                      : in  std_logic;
   
    LUT_DATA_VLD             : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    MAG                      : in  std_logic_array9( TX_ANT_NUM-1 downto 0);
    LUT_ADDR                 : out std_logic_array17_array9(TX_ANT_NUM-1 downto 0);

    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);
    LUT_RDATA_IN             : in  std_logic_array17_array32(TX_ANT_NUM downto 0);

    LUT_ADD_I                : out std_logic_array10_array16(TX_ANT_NUM-1 downto 0);
    LUT_ADD_Q                : out std_logic_array10_array16(TX_ANT_NUM-1 downto 0)
    );
end component;

component DPD_LUT17_RAM_SET is
generic(
    DEVICE                   : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
    TX_ANT_NUM               : natural :=           4 ;
    HS_MODE                  : boolean :=       FALSE ;
    HOVS                     : natural :=           1 ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_MEM_DEPTH            : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    LUT_RBTEST               : boolean :=       FALSE ;
    LUT_RAM_NUM              : natural :=          17 
    );
port(
    RST_CPU                  : in  std_logic;
    CLK_CPU                  : in  std_logic;

    LUT_SWITCH_IN            : in  std_logic_vector(TX_ANT_NUM-1 downto 0);
    LUT_ENA_IN               : in  std_logic_array17(TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path
    LUT_WREN_IN              : in  std_logic_array17(TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path
    LUT_WADDR_IN             : in  std_logic_array9( TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path
    LUT_WDATA_IN             : in  std_logic_array32(TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path
    LUT_RBDATA_OUT           : out std_logic_array17_array32(TX_ANT_NUM downto 0);

    RST_DPD                  : in  std_logic;
    CLK_DPD                  : in  std_logic;

    LUT_RADDR_IN             : in  std_logic_array17_array9( TX_ANT_NUM downto 0);
    LUT_RDATA_OUT            : out std_logic_array17_array32(TX_ANT_NUM downto 0)
    );
end component;

component SRL16E_DLY is
generic(
    DEVICE                   : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HS_MODE                  : boolean :=        TRUE ;

    BIT_WIDTH                : natural; -- 2 to 64
    DELAY_NUM                : natural
    );
port(
    RST                      : in  std_logic;
    CLK                      : in  std_logic;

    DATA_IN                  : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT                 : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end component;

--*****************************
-- Constants
--*****************************

--*****************************
-- Array Type 
--*****************************

--*****************************
-- Signals
--*****************************
signal lut_update_switch_cpuclk      : std_logic_vector(TX_ANT_NUM-1 downto 0);
signal lut_ena_cpuclk                : std_logic_array17(TX_ANT_NUM downto 0); 
signal lut_wren_cpuclk               : std_logic_array17(TX_ANT_NUM downto 0); 
signal lut_waddr_cpuclk              : std_logic_array9( TX_ANT_NUM downto 0); 
signal lut_wdata_cpuclk              : std_logic_array32(TX_ANT_NUM downto 0); 

signal lut_raddr_dpdclk              : std_logic_array17_array9( TX_ANT_NUM downto 0);

signal dpd_lut_output_switch_dpdclk  : std_logic_vector(19 downto 0);          

signal lut_mag_addr                  : std_logic_array17_array9(TX_ANT_NUM-1 downto 0);

signal lut_rbdata                    : std_logic_array17_array32(TX_ANT_NUM downto 0);

signal lut_rdata                     : std_logic_array17_array32(TX_ANT_NUM downto 0);

signal lut_add_i                     : std_logic_array10_array16(TX_ANT_NUM-1 downto 0);
signal lut_add_q                     : std_logic_array10_array16(TX_ANT_NUM-1 downto 0);

signal dpd_coef_i                    : std_logic_array10_array16(TX_ANT_NUM-1 downto 0);
signal dpd_coef_q                    : std_logic_array10_array16(TX_ANT_NUM-1 downto 0);

begin

    --*******************************
    -- Resets
    --*******************************
    --*******************************
    -- DPDSW Interface 
    --*******************************
    U_DPD_LUT17_SW_Interface : DPD_LUT17_SWIF 
    generic map(
        TX_ANT_NUM                => TX_ANT_NUM                  , 
        HS_MODE                   => HS_MODE                     , 
        LUT_OPTIMIZED             => LUT_OPTIMIZED               , 
        LUT_RBTEST                => LUT_RBTEST                  ,
        LUT_RAM_NUM               => LUT_RAM_NUM                 , 
        DPD_TAP_NUM               => DPD_TAP_NUM                  
        )
    port map(
        RST_CPU                   => RST_CPU                     , 
        CLK_CPU                   => CLK_CPU                     , 
    
        DPD_LUT_RB_TEST_EN_IN     => DPD_LUT_RB_TEST_EN_IN       , 
    
        DPD_CDC_STRB_IN           => DPD_CDC_STRB_IN             ,
        DPD_LUT_INPUT_SWITCH_IN   => DPD_LUT_INPUT_SWITCH_IN     , 
        DPD_LUT_OUTPUT_SWITCH_IN  => DPD_LUT_OUTPUT_SWITCH_IN    , 
    
        DPD_LUT_UPDATE_SW_IN      => DPD_LUT_UPDATE_SW_IN        , 
        DPD_LUT_WREN_IN           => DPD_LUT_WREN_IN             , 
        DPD_LUT_RDEN_IN           => DPD_LUT_RDEN_IN             , 
        DPD_LUT_ADDR_IN           => DPD_LUT_ADDR_IN             , 
        DPD_LUT_WDATA_IN          => DPD_LUT_WDATA_IN            , 
        DPD_LUT_RDATA_OUT         => DPD_LUT_RDATA_OUT           , 

        RST_DPD                   => RST_DPD                     , 
        CLK_DPD                   => CLK_DPD                     , 
        
        DPD_MAG_ADDR_IN           => lut_mag_addr                , 

        DPD_LUT_OUTPUT_SWITCH_OUT => dpd_lut_output_switch_dpdclk, 

        SW_LUT_UPDATE_SWITCH_OUT  => lut_update_switch_cpuclk    , 
        SW_LUT_ENA_OUT            => lut_ena_cpuclk              ,
        SW_LUT_WREN_OUT           => lut_wren_cpuclk             ,
        SW_LUT_WADDR_OUT          => lut_waddr_cpuclk            ,
        SW_LUT_WDATA_OUT          => lut_wdata_cpuclk            ,
                                                                 
        SW_LUT_RADDR_OUT          => lut_raddr_dpdclk            ,
        SW_LUT_RBDATA_IN          => lut_rbdata            
        );

    --*******************************
    -- DPD Core Configuration 
    --*******************************

        -- MPA2, |x[n+2]| 
        -- MPA1, |x[n+1]|+|x[n]| 
        -- MP0 , |x[n]|  +|x[n-1]|+|x[n-2]|+|x[n-3]|
        -- MP1 , |x[n]|  +|x[n-1]|+|x[n-2]|
        -- MP2 , |x[n]|  +|x[n-1]|+|x[n-2]|
        -- MP3 , |x[n]|  +|x[n-3]| 
        -- MP4 , |x[n-4]| 
        -- MP5 , |x[n-5]| 

    U_LUT_Configuration : DPD_LUT17_CONFIG 
    generic map(
        DEVICE                    => DEVICE                      , 
        HS_MODE                   => HS_MODE                     , 
        TX_ANT_NUM                => TX_ANT_NUM                  , 
        LUT_OPTIMIZED             => LUT_OPTIMIZED               , 
        LUT_RAM_NUM               => LUT_RAM_NUM                 , 
        DPD_TAP_NUM               => DPD_TAP_NUM                   
        )
    port map(
        RST                       => RST_DPD                     , 
        CLK                       => CLK_DPD                     , 
       
        LUT_DATA_VLD              => DATA_VLD_IN                 , 
        MAG                       => DATA_MAG09_IN               , 
        LUT_ADDR                  => lut_mag_addr                , 
    
        DPD_LUT_OUTPUT_SWITCH_IN  => dpd_lut_output_switch_dpdclk, 
        LUT_RDATA_IN              => lut_rdata                   , 
    
        LUT_ADD_I                 => lut_add_i                   , 
        LUT_ADD_Q                 => lut_add_q                     
        );

    --*******************************
    -- DPD LUT
    --*******************************
    U_DPD_LUT17_RAM_SET : DPD_LUT17_RAM_SET 
    generic map(
        DEVICE                   => DEVICE                       , 
        TX_ANT_NUM               => TX_ANT_NUM                   , 
        HS_MODE                  => HS_MODE                      , 
        HOVS                     => HOVS                         , 
        LUT_OPTIMIZED            => LUT_OPTIMIZED                , 
        LUT_MEM_DEPTH            => LUT_MEM_DEPTH                ,
        LUT_RBTEST               => LUT_RBTEST                   ,
        LUT_RAM_NUM              => LUT_RAM_NUM                    
        )
    port map(
        RST_CPU                  => RST_CPU                      , 
        CLK_CPU                  => CLK_CPU                      , 
    
        LUT_SWITCH_IN            => lut_update_switch_cpuclk     , 
        LUT_ENA_IN               => lut_ena_cpuclk               , 
        LUT_WREN_IN              => lut_wren_cpuclk              , 
        LUT_WADDR_IN             => lut_waddr_cpuclk             , 
        LUT_WDATA_IN             => lut_wdata_cpuclk             , 
        LUT_RBDATA_OUT           => lut_rbdata                   , 
    
        RST_DPD                  => RST_DPD                      , 
        CLK_DPD                  => CLK_DPD                      , 
    
        LUT_RADDR_IN             => lut_raddr_dpdclk             , 
        LUT_RDATA_OUT            => lut_rdata                
        );

    --*******************************
    -- DPD Coefficient 
    --*******************************
    G_DPD_COEF_Path : for I in 0 to (TX_ANT_NUM-1) generate begin
        G_LUT_ADDER_Delay : for J in 0 to (DPD_TAP_NUM-1) generate begin
            G_1st_LUT_ADDER_DLY : if (J = 0) generate begin
                dpd_coef_i(I)(J) <= lut_add_i(I)(J);           
                dpd_coef_q(I)(J) <= lut_add_q(I)(J);           
            end generate;

            G_LUT_ADDER_J_DLY : if (J > 0) generate begin
                U_LUT_ADDER_I_DLY_HOVS1 : SRL16E_DLY generic map (DEVICE, HS_MODE, 16, HOVS*J) port map (RST_DPD, CLK_DPD, lut_add_i(I)(J), dpd_coef_i(I)(J));
                U_LUT_ADDER_Q_DLY_HOVS1 : SRL16E_DLY generic map (DEVICE, HS_MODE, 16, HOVS*J) port map (RST_DPD, CLK_DPD, lut_add_q(I)(J), dpd_coef_q(I)(J));
            end generate;

            -- Sign Extention
            DPD_COEF_I_OUT(I)(J) <= sign_extension(dpd_coef_i(I)(J), 27);
            DPD_COEF_Q_OUT(I)(J) <= sign_extension(dpd_coef_q(I)(J), 27);

        end generate;
    end generate;

end arc_DPD_LUT17_WRAPPER;
