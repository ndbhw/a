-------------------------------------------------------------------------------
-- File name : CPUIF_DSP_DPDSC.vhd
-- Purpose   : CPUIF for SUB_BLOCK
-------------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity CPUIF_DSP_DPDSC is
generic(
    DPD_CORE_IMPLEMENTATION             : boolean :=  TRUE ;                            -- R 8.9.1 LUT 
    DPD_CORE_LUT_OPTIMIZED              : boolean := FALSE ;
    DPD_CORE_LUT_RBTEST                 : boolean :=  TRUE ;
    SC_IMPLEMENTATION                   : boolean :=  TRUE ;                            -- R 8.9.4 Smart Capture
    PIM_IMPLEMENTATION                  : boolean :=  TRUE ;                            -- R ?.?.? PIM 
    PIMD_BLK_TYPE                       : string  := "SELECTABLE";                      -- SELELCTABLE / INTER or INTRA
    PIM_CORE_LUT_OPTIMIZED              : boolean := FALSE ;
    PIM_CORE_LUT_RBTEST                 : boolean := FALSE ;

    RX_SSD_IMPLEMENTATION               : boolean :=  TRUE ;
    ADDR_WIDTH                          : natural :=    16 ;                            -- CPU Address Bitwidth
    WDATA_WIDTH                         : natural :=    32 ;                            -- CPU Write Data Bitwidth
    RDATA_WIDTH                         : natural :=    32 ;                            -- CPU Read  Data Bitwidth

    TX_ANT_NUM                          : natural :=     8 ; 
    RX_ANT_NUM                          : natural :=     8 
    );
port(
    -- Reset & Clock
    RST_CPU                             : in  std_logic;                                -- cpuif reset, '1': Reset
    CLK_CPU                             : in  std_logic;                                -- cpuif clock, faster than iclk/oclk  
    CLK_SC                              : in  std_logic;                                -- dpd operation clock, 122.88MHz for KDDI DB
    CLK_PIMD                            : in  std_logic;                                -- dpd operation clock, 122.88MHz for KDDI DB

    -- CPU Interface
    ADDR_CPU_IN                         : in  std_logic_vector( ADDR_WIDTH-1 downto 0); -- cpuif address input, Halfword address.
    WDATA_CPU_IN                        : in  std_logic_vector(WDATA_WIDTH-1 downto 0); -- cpuif data input
    RDATA_DPD_OUT                       : out std_logic_vector(RDATA_WIDTH-1 downto 0); -- cpuif data outputRDATA_CPU
    WREN_CPU_IN                         : in  std_logic;                                -- cpuif write enable, '1': active, synchronous with iclk
    RDEN_CPU_IN                         : in  std_logic;                                -- cpuif read enable, '1': active.
    RDVLD_CPU_OUT                       : out std_logic;
    
    -- DPD_CORE Control
    DPD_CORE_SET_STRB_OUT               : out std_logic_vector( 1 downto 0);
    DPD_CORE_GAIN_INDEX_OUT             : out std_logic_array2( TX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
    DPD_CORE_QPOINT_SEL_OUT             : out std_logic_array2( TX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection

    DPD_CORE_LUT_SWITCH_CDC_STRB_OUT    : out std_logic_vector( 3 downto 0);  -- unused
    DPD_CORE_LUT_INPUT_SWITCH_OUT       : out std_logic_array20(3 downto 0);  -- unused
    DPD_CORE_LUT_OUTPUT_SWITCH_OUT      : out std_logic_array20(3 downto 0);  -- unused

    DPD_CORE_LUT_RB_TEST_OUT            : out std_logic_vector( 3 downto 0);

    DPD_CORE_LUT_UPDATE_SW_OUT          : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_CORE_LUT_WREN_OUT               : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_CORE_LUT_RDEN_OUT               : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_CORE_LUT_ADDR_OUT               : out std_logic_array15(TX_ANT_NUM-1 downto 0);
    DPD_CORE_LUT_WDATA_OUT              : out std_logic_array32(TX_ANT_NUM-1 downto 0);
    DPD_CORE_LUT_RDATA_IN               : in  std_logic_array32(TX_ANT_NUM-1 downto 0);

    -- PIM_CORE Control
    PIM_DETECTOR_ON_IN                  : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
    PIM_MITIGATOR_ON_IN                 : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
    -- PIM (LUT dpd core)
    PIM_CORE_SET_STRB_OUT               : out std_logic_vector( 1 downto 0);
    PIM_CORE_GAIN_INDEX_OUT             : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
    PIM_CORE_QPOINT_SEL_OUT             : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection

    PIM_CORE_LUT_SWITCH_CDC_STRB_OUT    : out std_logic_vector( 3 downto 0);  -- unsued
    PIM_CORE_LUT_INPUT_SWITCH_OUT       : out std_logic_array20(3 downto 0);  -- unsued
    PIM_CORE_LUT_OUTPUT_SWITCH_OUT      : out std_logic_array20(3 downto 0);  -- unsued

    PIM_CORE_LUT_RB_TEST_OUT            : out std_logic_vector( 3 downto 0);  -- unsued

    PIM_CORE_LUT_UPDATE_SW_OUT          : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_CORE_LUT_WREN_OUT               : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_CORE_LUT_RDEN_OUT               : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_CORE_LUT_ADDR_OUT               : out std_logic_array15(TX_ANT_NUM-1 downto 0);
    PIM_CORE_LUT_WDATA_OUT              : out std_logic_array32(TX_ANT_NUM-1 downto 0);
    PIM_CORE_LUT_RDATA_IN               : in  std_logic_array32(TX_ANT_NUM-1 downto 0);
    -- selectable PIM_CORE 1 -- add
    PIM_SLTB1_DETECTOR_ON_IN            : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
    PIM_SLTB1_MITIGATOR_ON_IN           : in  std_logic_vector( RX_ANT_NUM-1 downto 0);

    PIM_SLTB1_CORE_SET_STRB_OUT         : out std_logic_vector( 1 downto 0);
    PIM_SLTB1_CORE_GAIN_INDEX_OUT       : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
    PIM_SLTB1_CORE_QPOINT_SEL_OUT       : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection

    PIM_SLTB1_CORE_LUT_UPDATE_SW_OUT    : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB1_CORE_LUT_WREN_OUT         : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB1_CORE_LUT_RDEN_OUT         : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB1_CORE_LUT_ADDR_OUT         : out std_logic_array15(TX_ANT_NUM-1 downto 0);
    PIM_SLTB1_CORE_LUT_WDATA_OUT        : out std_logic_array32(TX_ANT_NUM-1 downto 0);
    PIM_SLTB1_CORE_LUT_RDATA_IN         : in  std_logic_array32(TX_ANT_NUM-1 downto 0);
    -- selectable PIM_CORE 2 -- add
    PIM_SLTB2_DETECTOR_ON_IN            : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
    PIM_SLTB2_MITIGATOR_ON_IN           : in  std_logic_vector( RX_ANT_NUM-1 downto 0);

    PIM_SLTB2_CORE_SET_STRB_OUT         : out std_logic_vector( 1 downto 0);
    PIM_SLTB2_CORE_GAIN_INDEX_OUT       : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
    PIM_SLTB2_CORE_QPOINT_SEL_OUT       : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection

    PIM_SLTB2_CORE_LUT_UPDATE_SW_OUT    : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB2_CORE_LUT_WREN_OUT         : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB2_CORE_LUT_RDEN_OUT         : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB2_CORE_LUT_ADDR_OUT         : out std_logic_array15(TX_ANT_NUM-1 downto 0);
    PIM_SLTB2_CORE_LUT_WDATA_OUT        : out std_logic_array32(TX_ANT_NUM-1 downto 0);
    PIM_SLTB2_CORE_LUT_RDATA_IN         : in  std_logic_array32(TX_ANT_NUM-1 downto 0);
    --
    PIM_SLTB_INTRA_NCO_WREN_OUT         : out std_logic;   
    PIM_SLTB_INTRA_NCO_WORD_OUT         : out std_logic_vector( 31 downto 0);   
    PIM_SLTB_INTER1_NCO_WREN_OUT        : out std_logic;   
    PIM_SLTB_INTER1_NCO_WORD_OUT        : out std_logic_vector( 31 downto 0);   
    PIM_SLTB_INTER2_NCO_WREN_OUT        : out std_logic;   
    PIM_SLTB_INTER2_NCO_WORD_OUT        : out std_logic_vector( 31 downto 0);   

    PIMDLY_SLTB1_VALUE_OUT              : out std_logic_array12(TX_ANT_NUM-1 downto 0);
    PIMDLY_SLTB2_VALUE_OUT              : out std_logic_array12(TX_ANT_NUM-1 downto 0);

    -- PIM_SLTB_INTRA_BAND_SEL_OUT         : out std_logic;
	-- PIM_SLTB_INTER_BAND_TYPE1_SEL_OUT   : out std_logic_vector(1 downto 0);
    -- PIM_SLTB_INTER_BAND_TYPE2_SEL_OUT   : out std_logic_vector(1 downto 0);
	PIM_SLTB_INTRA_BAND_SEL_OUT         : out std_logic_vector(TX_ANT_NUM-1 downto 0);
    PIM_SLTB_INTER_BAND_TYPE1_SEL_OUT   : out std_logic_array2(TX_ANT_NUM-1 downto 0);
    PIM_SLTB_INTER_BAND_TYPE2_SEL_OUT   : out std_logic_array2(TX_ANT_NUM-1 downto 0);
    PIM_SLTB_BIT_SHIFT_SEL_OUT          : out std_logic_vector(1 downto 0);

    PIM_SLTB_SHIFT_DIRECTION_INTRA_OUT  : out std_logic_array2(TX_ANT_NUM-1 downto 0);
    PIM_SLTB_SHIFT_DIRECTION_INTER1_OUT : out std_logic_array2(TX_ANT_NUM-1 downto 0);
    PIM_SLTB_SHIFT_DIRECTION_INTER2_OUT : out std_logic_array2(TX_ANT_NUM-1 downto 0);

    ----- coef type pim core
    PIM_COMPLEX_FILTER_COEF_WREN_OUT    : out std_logic_vector(RX_ANT_NUM-1 downto 0);
    PIM_COMPLEX_FILTER_COEF_RDEN_OUT    : out std_logic_vector(RX_ANT_NUM-1 downto 0);
    PIM_COMPLEX_FILTER_COEF_WRDN_OUT    : out std_logic_vector(RX_ANT_NUM-1 downto 0);
    PIM_COMPLEX_FILTER_COEF_ADDR_OUT    : out std_logic_vector( 3 downto 0);
    PIM_COMPLEX_FILTER_COEF_I_WDATA_OUT : out std_logic_vector(20 downto 0);
    PIM_COMPLEX_FILTER_COEF_Q_WDATA_OUT : out std_logic_vector(20 downto 0);
    PIM_COMPLEX_FILTER_COEF_I_RDATA_IN  : in  std_logic_vector(20 downto 0);
    PIM_COMPLEX_FILTER_COEF_Q_RDATA_IN  : in  std_logic_vector(20 downto 0);
    -- ~
    PIM_SRC_INTRAB_DLY_STRB_OUT         : out std_logic;
    PIM_SRC_INTRAB_DLY_OUT              : out std_logic_array12(TX_ANT_NUM-1 downto 0);
                                                     
    PIM_SRC_INTERB_DLY_STRB_OUT         : out std_logic;       
    PIM_SRC_INTERB_CDLY_OUT             : out std_logic_array11(TX_ANT_NUM-1 downto 0);
    PIM_SRC_INTERB_FDLY_OUT             : out std_logic_array4( TX_ANT_NUM-1 downto 0);
                                                    
    PIM_REF_DLY_STRB_OUT                : out std_logic;      
    PIM_REF_SAMPLE_DLY_OUT              : out std_logic_array12(TX_ANT_NUM-1 downto 0);
                                                    
    PIM_UL_DLY_STRB_OUT                 : out std_logic;       
    PIM_UL_SAMPLE_DLY_OUT               : out std_logic_array12(RX_ANT_NUM-1 downto 0);

    PNPC_EN_OUT                         : out std_logic_vector(RX_ANT_NUM-1 downto 0);
    PNPC_SET_OUT                        : out std_logic_vector(RX_ANT_NUM-1 downto 0);

    PNPC_MU_SEL_STRB_OUT                : out std_logic; 
    PNPC_MU_SEL_OUT                     : out std_logic_array2(RX_ANT_NUM-1 downto 0);

    PNPC_SETVAL_STRB_OUT                : out std_logic;
    PNPC_SETVAL_I_OUT                   : out std_logic_array16(RX_ANT_NUM-1 downto 0);                    
    PNPC_SETVAL_Q_OUT                   : out std_logic_array16(RX_ANT_NUM-1 downto 0);                    

    PNPC_TP_DC_IQ_IN                    : in  std_logic_array32(RX_ANT_NUM-1 downto 0);                    

    PIM_UL_MIXER_FREQ_ERR_COMP_STRB_OUT : out std_logic;                    
    PIM_UL_MIXER_FREQ_ERR_COMP_WORD_OUT : out std_logic_vector(31 downto 0);                    

    -- SMART_CAPTURE Control
    SC_CONTROL_OUT                      : out std_logic;
    SC_COMPLETE_FLAG_IN                 : in  std_logic;
    SC_TDD_MODE_OUT                     : out std_logic;
    SC_FORCED_MODE_OUT                  : out std_logic;
    SC_DEBOUNCING_TIME_OUT              : out std_logic_vector( 9 downto 0);
    SC_CAP_SIZE_SEL_OUT                 : out std_logic;
    SC_DPDFB_PIM_MODE_SEL_OUT           : out std_logic; 

    SC_PATH_SEL_STRB_OUT                : out std_logic;
    SC_PATH_SEL_OUT                     : out std_logic_vector( 4 downto 0);

    SC_CAP_MEMORY_SEL_OUT               : out std_logic_vector( 2 downto 0);
    SC_DPD_CORE_HC_LATENCY_OUT          : out std_logic_vector( 9 downto 0);
    SC_FB_LATENCY_OUT                   : out std_logic_vector( 9 downto 0);
    SC_REF_LATENCY_OUT                  : out std_logic_vector( 9 downto 0);
    SC_CAP_OFF_START_OUT                : out std_logic_vector(21 downto 0);
    SC_CAP_OFF_STOP_OUT                 : out std_logic_vector(21 downto 0);
    SC_STATIC_POSITION_OUT              : out std_logic_vector(21 downto 0);
    SC_STATIC_LENGTH_OUT                : out std_logic_vector( 8 downto 0);
    SC_MAX_PEAK_BO_GAIN_OUT             : out std_logic_vector(15 downto 0);
    SC_CUR_PEAK_BO_GAIN_OUT             : out std_logic_vector(15 downto 0);
    SC_SUB_PWR_IN                       : in  std_logic_vector(31 downto 0);
    SC_SUB_PEAK_IN                      : in  std_logic_vector(31 downto 0);
    SC_SUB_PEAK_NUM_IN                  : in  std_logic_vector(12 downto 0);
    SC_TIME_INDEX_IN                    : in  std_logic_vector(31 downto 0);

    SC_INTER_PIM_DBG_SEL_OUT            : out std_logic_vector( 1 downto 0);
    SC_INTRA_PIM_DBG_SEL_OUT            : out std_logic_vector( 1 downto 0);

    SC_MEM_RDEN_OUT                     : out std_logic;
    SC_MEM_ADDR_OUT                     : out std_logic_vector(12 downto 0);
    SC_MEM_RDATA_IN                     : in  std_logic_vector(31 downto 0);

    UL_MON0_DATA_IN                     : in  std_logic_vector(31 downto 0);
    UL_MON0_VLD_IN                      : in  std_logic;
    UL_MON1_DATA_IN                     : in  std_logic_vector(31 downto 0);
    UL_MON1_VLD_IN                      : in  std_logic;
    UL_MON2_DATA_IN                     : in  std_logic_vector(31 downto 0);
    UL_MON2_VLD_IN                      : in  std_logic;

    -- SSD Control
    SSD_PATH_SEL_OUT                    : out std_logic_vector( 4 downto 0);
    SSD_CTRL_OUT                        : out std_logic;
    SSD_PERIOD_OUT                      : out std_logic_vector( 9 downto 0);
    SSD_LENGTH_PER_SWITCH_OUT           : out std_logic_vector(16 downto 0);
    SSD_ACCU_LENGTH_OUT                 : out std_logic_vector(16 downto 0);
    SSD_ACCU_DONE_IN                    : in  std_logic;
    SSD_GAIN_OUT                        : out std_logic_vector(15 downto 0);
    SSD_PTN_WREN_OUT                    : out std_logic;
    SSD_PTN_WADDR_OUT                   : out std_logic_vector( 8 downto 0);
    SSD_PTN_WDATA_OUT                   : out std_logic_vector(31 downto 0);
    SSD_MEM_RDEN_OUT                    : out std_logic;
    SSD_MEM_ADDR_OUT                    : out std_logic_vector( 9 downto 0);
    SSD_MEM_RDATA_IN                    : in  std_logic_vector(31 downto 0);
    -- H/W alrm gathering
    SIG_SUS_DLOFF_IN                    : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    CLOCK_FAIL_FLAG_IN                  : in  std_logic_vector( TX_ANT_NUM-1 downto 0)
    );
end CPUIF_DSP_DPDSC;

architecture arc_CPUIF_DSP_DPDSC of CPUIF_DSP_DPDSC is

-- Components -------------------------------------------------------------------------
component RST_SYNC is
generic (
    DLY_NUM        : natural := 4;    -- Number of delay.
    MAX_FANOUT_NUM : integer := 200   -- Number of maximum fanout
    );
port(
    RST_IN         : in  std_logic;   -- Active high asynchronous reset
    CLK            : in  std_logic;   -- clock to be sync'ed to
    RST_OUT        : out std_logic    -- "Synchronised" reset signal
    );         
end component;

component REG32_WRITE is
generic(
    BIT_ENABLE : std_logic_vector(31 downto 0) := (others => '1');
    REG_ADDR   : std_logic_vector( 7 downto 0) := (others => '0'); -- Register address
    REG_DATA   : std_logic_vector(31 downto 0) := (others => '0')  -- Default value
    );
port(
    RST        : in  std_logic;                                    -- reset, '1': reset
    CLK        : in  std_logic;                                    -- clock

    EN         : in  std_logic;                                    -- Write enable
    ADDR       : in  std_logic_vector( 7 downto 0);                -- Input Address
    DATA_IN    : in  std_logic_vector(31 downto 0);                -- Data input
    DATA_OUT   : out std_logic_vector(31 downto 0)                 -- Data output
    );
end component;

component REG32_LATCH is
generic(
    BIT_ENABLE  : std_logic_vector(31 downto 0) := (others => '1');
    REG_ADDR    : std_logic_vector( 7 downto 0) := (others => '0')
    );
port(
    RST         : in  std_logic;
    CLK         : in  std_logic;

    CLR_IN      : in  std_logic;   
    ADDR_IN     : in  std_logic_vector( 7 downto 0);
    DATA_IN     : in  std_logic_vector(31 downto 0);
    DATA_OUT    : out std_logic_vector(31 downto 0);
    FLAG_OUT    : out std_logic_vector(31 downto 0)
    );
end component;

component MULTIBIT_CDC is
generic(
    BIT_WIDTH  : natural :=    16
    );
port(
    DATA_A_IN  : in  std_logic_vector(BIT_WIDTH-1 downto 0);

    CLK_B      : in  std_logic;
    DATA_B_OUT : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end component;

-- Constants ------------------------------------------------------------------------
constant reg_path_num                      : std_logic_vector(RDATA_WIDTH-1 downto 0) := conv_std_logic_vector((    2**TX_ANT_NUM)-1, RDATA_WIDTH);                        
constant reg_path_num_x2                   : std_logic_vector(RDATA_WIDTH-1 downto 0) := conv_std_logic_vector((2**(2*TX_ANT_NUM))-1, RDATA_WIDTH);                        
constant zeros                             : std_logic_vector(RDATA_WIDTH-1 downto 0) := (others => '0');

-- Signals --------------------------------------------------------------------------
signal rst_synch_cpu                        : std_logic;
signal rst_synch_sc                         : std_logic;
signal rst_synch_pim                        : std_logic;

signal addr_h8                             : std_logic_vector( 7 downto 0);
signal addr_l8                             : std_logic_vector( 7 downto 0);

signal wren_scclk_sh                       : std_logic_vector( 5 downto 0);
signal wren_scclk_rpls                     : std_logic;
signal rden_scclk_sh                       : std_logic_vector( 4 downto 0);
signal rden_scclk_rpls                     : std_logic;
signal wren_ssdclk_sh                      : std_logic_vector( 5 downto 0);
signal wren_ssdclk_rpls                    : std_logic;
signal rden_ssdclk_sh                      : std_logic_vector( 4 downto 0);
signal rden_ssdclk_rpls                    : std_logic;

signal wren_pimclk_sh                      : std_logic_vector( 5 downto 0);
signal wren_pimclk_rpls                    : std_logic;
signal rden_pimclk_sh                      : std_logic_vector( 4 downto 0);
signal rden_pimclk_rpls                    : std_logic;
signal wren_73_pimclk                      : std_logic;
signal wren_74_pimclk                      : std_logic;
signal wren_75_pimclk                      : std_logic;

signal rden_cpuclk_sh                      : std_logic_vector( 5 downto 0);
signal rden_d1_cpuclk_rpls                 : std_logic;
signal rden_d2_cpuclk_rpls                 : std_logic;
signal rden_d4_cpuclk_rpls                 : std_logic;
signal rden_d6_cpuclk_rpls                 : std_logic;
signal rdvld_cpuclk                        : std_logic;
signal lc_cpuclk_rpls                      : std_logic;

signal wren_dpd_00_cpuclk                  : std_logic;
signal wren_dpd_00_cpuclk_sh               : std_logic_vector( 1 downto 0);
signal wren_dpd_00_cpuclk_rpls             : std_logic;

signal reg_dpd_core_gidx_cdc_strb          : std_logic;
signal reg_dpd_core_qpoint_cdc_strb        : std_logic;

signal reg_dpd_core_qpoint_n_gidx_ab       : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_dpd_core_qpoint_n_gidx_cd       : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal reg_dpd_core_gidx                   : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_dpd_core_qpoint                 : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal reg_dpd_core_lut_depth_sel          : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_dpd_core_lut_switch             : std_logic_vector(RDATA_WIDTH-1 downto 0);

-- signal reg_dpd_core_lut_switch_cdc_strb_a  : std_logic;
-- signal reg_dpd_core_lut_input_switch_a     : std_logic_vector(RDATA_WIDTH-1 downto 0);
-- signal reg_dpd_core_lut_output_switch_a    : std_logic_vector(RDATA_WIDTH-1 downto 0);
-- 
-- signal reg_dpd_core_lut_switch_cdc_strb_b  : std_logic;
-- signal reg_dpd_core_lut_input_switch_b     : std_logic_vector(RDATA_WIDTH-1 downto 0);
-- signal reg_dpd_core_lut_output_switch_b    : std_logic_vector(RDATA_WIDTH-1 downto 0);
-- 
-- signal reg_dpd_core_lut_switch_cdc_strb_c  : std_logic;
-- signal reg_dpd_core_lut_input_switch_c     : std_logic_vector(RDATA_WIDTH-1 downto 0);
-- signal reg_dpd_core_lut_output_switch_c    : std_logic_vector(RDATA_WIDTH-1 downto 0);
-- 
-- signal reg_dpd_core_lut_switch_cdc_strb_d  : std_logic;
-- signal reg_dpd_core_lut_input_switch_d     : std_logic_vector(RDATA_WIDTH-1 downto 0);
-- signal reg_dpd_core_lut_output_switch_d    : std_logic_vector(RDATA_WIDTH-1 downto 0);
 
signal reg_dpd_core_lut_rb_test            : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal dpd_lut_nopt_we                     : std_logic_vector( 7 downto 0);
signal dpd_lut_nopt_re                     : std_logic_vector( 7 downto 0);
-- signal dpd_lut_nopt_addr                   : std_logic_vector( 7 downto 0);

signal dpd_lut_we                          : std_logic_vector( 3 downto 0);
signal dpd_lut_re                          : std_logic_vector( 3 downto 0);
signal dpd_lut_we_d                        : std_logic_vector( 3 downto 0) := (others => '0');

signal dpd_core_lut_we                     : std_logic_vector( TX_ANT_NUM-1 downto 0) := (others => '0');
signal dpd_core_lut_re                     : std_logic_vector( TX_ANT_NUM-1 downto 0) := (others => '0');
signal dpd_core_lut_addr                   : std_logic_array15(TX_ANT_NUM-1 downto 0) := (others => (others => '0'));
signal dpd_core_lut_wdata                  : std_logic_array32(TX_ANT_NUM-1 downto 0) := (others => (others => '0'));
signal dpd_core_lut_rdata                  : std_logic_array32(8 downto 0);

signal reg_cpuclk_dpdctrl_rdata            : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal dpd_lut_rdata                       : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal wren_pim_03_cpuclk                  : std_logic;
signal wren_pim_03_cpuclk_sh               : std_logic_vector( 1 downto 0);
signal wren_pim_03_cpuclk_rpls             : std_logic;
signal wren_pim_70_cpuclk                  : std_logic;
signal wren_pim_70_cpuclk_sh               : std_logic_vector( 1 downto 0);
signal wren_pim_70_cpuclk_rpls             : std_logic;

signal reg_pim_mode_status                 : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_sltb1_mode_status           : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_sltb2_mode_status           : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal reg_pim_core_gidx_cdc_strb          : std_logic;
signal reg_pim_core_qpoint_cdc_strb        : std_logic;
signal reg_pim_sltb1_core_gidx_cdc_strb    : std_logic;
signal reg_pim_sltb1_core_qpoint_cdc_strb  : std_logic;
signal reg_pim_sltb2_core_gidx_cdc_strb    : std_logic;
signal reg_pim_sltb2_core_qpoint_cdc_strb  : std_logic;

signal reg_pim_core_qpoint_n_gidx_ab       : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_core_qpoint_n_gidx_cd       : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal reg_pim_core_gidx                   : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_core_qpoint                 : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_sltb1_core_gidx             : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_sltb1_core_qpoint           : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_sltb2_core_gidx             : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_sltb2_core_qpoint           : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal reg_pim_core_lut_depth_sel          : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_core_lut_switch             : std_logic_vector(RDATA_WIDTH-1 downto 0);

-- signal reg_pim_core_lut_switch_cdc_strb_a  : std_logic;
-- signal reg_pim_core_lut_input_switch_a     : std_logic_vector(RDATA_WIDTH-1 downto 0);
-- signal reg_pim_core_lut_output_switch_a    : std_logic_vector(RDATA_WIDTH-1 downto 0);

-- signal reg_pim_core_lut_switch_cdc_strb_b  : std_logic;
-- signal reg_pim_core_lut_input_switch_b     : std_logic_vector(RDATA_WIDTH-1 downto 0);
-- signal reg_pim_core_lut_output_switch_b    : std_logic_vector(RDATA_WIDTH-1 downto 0);
-- 
-- signal reg_pim_core_lut_switch_cdc_strb_c  : std_logic;
-- signal reg_pim_core_lut_input_switch_c     : std_logic_vector(RDATA_WIDTH-1 downto 0);
-- signal reg_pim_core_lut_output_switch_c    : std_logic_vector(RDATA_WIDTH-1 downto 0);
-- 
-- signal reg_pim_core_lut_switch_cdc_strb_d  : std_logic;
-- signal reg_pim_core_lut_input_switch_d     : std_logic_vector(RDATA_WIDTH-1 downto 0);
-- signal reg_pim_core_lut_output_switch_d    : std_logic_vector(RDATA_WIDTH-1 downto 0);
 
signal reg_pim_core_lut_rb_test            : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal reg_pim_complex_filter_coef_wren    : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_complex_filter_coef_rden    : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_complex_filter_coef_wrdn    : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_complex_filter_coef_addr    : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_complex_filter_coef_i_wdata : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_complex_filter_coef_q_wdata : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_complex_filter_coef_i_rdata : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pim_complex_filter_coef_q_rdata : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal reg_pim_src_intrab_dly_strb         : std_logic;
signal reg_pim_src_intrab_dly              : std_logic_array32( 7 downto 0);
                                                                 
signal reg_pim_src_interb_dly_strb         : std_logic;          
signal reg_pim_src_interb_dly              : std_logic_array32( 7 downto 0);
                                                                 
signal reg_pim_ref_dly_strb                : std_logic;          
signal reg_pim_ref_sample_dly              : std_logic_array32( 7 downto 0);
                                                                 
signal reg_pim_ul_dly_strb                 : std_logic;          
signal reg_pim_ul_sample_dly               : std_logic_array32( 7 downto 0);

signal reg_pnpc_en                         : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_pnpc_set                        : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal reg_pnpc_mu_sel_strb                : std_logic;
signal reg_pnpc_mu_sel                     : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal reg_pnpc_setval_strb                : std_logic;
signal reg_pnpc_setval                     : std_logic_array32( 7 downto 0);

signal pnpc_dc_iq                          : std_logic_array32( 8 downto 0);
signal reg_pnpc_dc_iq                      : std_logic_array32( 8 downto 0);

signal reg_pim_ul_mixer_freq_err_comp_strb : std_logic;                    
signal reg_pim_ul_mixer_freq_err_comp_word : std_logic_vector(31 downto 0);

signal pim_lut_nopt_we                     : std_logic_vector( 7 downto 0);
signal pim_lut_nopt_re                     : std_logic_vector( 7 downto 0);

signal pim_sltb1_lut_nopt_we               : std_logic_vector( 7 downto 0);
signal pim_sltb1_lut_nopt_re               : std_logic_vector( 7 downto 0);
signal pim_sltb2_lut_nopt_we               : std_logic_vector( 7 downto 0);
signal pim_sltb2_lut_nopt_re               : std_logic_vector( 7 downto 0);

-- signal pim_lut_we                          : std_logic_vector( 3 downto 0);
-- signal pim_lut_re                          : std_logic_vector( 3 downto 0);
signal pim_lut_we_d                        : std_logic_vector( 3 downto 0) := (others=>'0');

signal pim_sltb1_lut_we_d                  : std_logic_vector( 3 downto 0) := (others=>'0');
signal pim_sltb2_lut_we_d                  : std_logic_vector( 3 downto 0) := (others=>'0');

signal pim_core_lut_we                     : std_logic_vector( TX_ANT_NUM-1 downto 0) := (others=> '0');
signal pim_core_lut_re                     : std_logic_vector( TX_ANT_NUM-1 downto 0) := (others=> '0');
signal pim_core_lut_addr                   : std_logic_array15(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal pim_core_lut_wdata                  : std_logic_array32(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal pim_core_lut_rdata                  : std_logic_array32(8 downto 0);
-- selectable
signal pim_sltb1_core_lut_we               : std_logic_vector( TX_ANT_NUM-1 downto 0) := (others=> '0');
signal pim_sltb1_core_lut_re               : std_logic_vector( TX_ANT_NUM-1 downto 0) := (others=> '0');
signal pim_sltb1_core_lut_addr             : std_logic_array15(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal pim_sltb1_core_lut_wdata            : std_logic_array32(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal pim_sltb1_core_lut_rdata            : std_logic_array32(8 downto 0);
signal pim_sltb2_core_lut_we               : std_logic_vector( TX_ANT_NUM-1 downto 0) := (others=> '0');
signal pim_sltb2_core_lut_re               : std_logic_vector( TX_ANT_NUM-1 downto 0) := (others=> '0');
signal pim_sltb2_core_lut_addr             : std_logic_array15(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal pim_sltb2_core_lut_wdata            : std_logic_array32(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal pim_sltb2_core_lut_rdata            : std_logic_array32(8 downto 0);

signal reg_cpuclk_pimctrl_rdata            : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sltb_cpuclk_pimctrl_rdata       : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal pim_lut_rdata                       : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal wren_sc_01_dpdclk                   : std_logic;
signal wren_sc_01_dpdclk_sh                : std_logic_vector( 4 downto 0);
signal wren_sc_cdc_strb                    : std_logic;

signal wren_cpuclk_sh                      : std_logic_vector( 1 downto 0);
signal wren_cpuclk_rpls                    : std_logic;
signal wren_sc_01_cpuclk                   : std_logic;

signal reg_cpuclk_sc_rdata                 : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal reg_sc_control                      : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal reg_sc_cap_size                     : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sc_mode                         : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sc_force                        : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sc_debouncing_time              : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sc_tdd_mode                     : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal sc_path_sel_strb                    : std_logic;
signal reg_sc_path_sel                     : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sc_cap_memory_sel               : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sc_dpd_hc_latency               : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sc_fb_latency                   : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sc_ref_latency                  : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sc_cap_off_start                : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sc_cap_off_stop                 : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sc_static_position              : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sc_static_length                : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sc_max_cur_bo_gain              : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sc_max_peak_bo_gain             : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sc_pim_dbg_path_sel             : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal reg_sc_complete_flag                : std_logic;
signal reg_sc_sub_pwr                      : std_logic_vector(31 downto 0);
signal reg_sc_sub_peak                     : std_logic_vector(31 downto 0);
signal reg_sc_sub_peak_num                 : std_logic_vector(12 downto 0);
signal reg_sc_time_index                   : std_logic_vector(31 downto 0);

signal reg_sc_ctrl_rdata                   : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal sc_capture_mem_rdata                : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal sc_mem_rden                         : std_logic := '0';
signal sc_mem_rden_d1                      : std_logic := '0';
signal sc_mem_raddr                        : std_logic_vector(12 downto 0);
signal sc_mem_rdata                        : std_logic_vector(RDATA_WIDTH-1 downto 0);

signal lc_reg_02_cpuclk                    : std_logic;

signal wren_ssd_05_dpdclk                  : std_logic;
signal reg_ssd_path_sel                    : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_ssd_ctrl                        : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_ssd_period                      : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_ssd_length_per_switch           : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_ssd_accu_length                 : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_ssd_accu_done_flg               : std_logic := '0';
signal reg_ssd_gain                        : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_ssd_ctrl_rdata                  : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal ssd_ptn_wren                        : std_logic;
signal ssd_ptn_wren_d1                     : std_logic;
signal ssd_ptn_wren_rpls                   : std_logic;
signal ssd_ptn_waddr                       : std_logic_vector( 8 downto 0);
signal ssd_ptn_wdata                       : std_logic_vector(31 downto 0);
signal ssd_mem_rden                        : std_logic;
signal ssd_mem_rden_d1                     : std_logic;
signal ssd_mem_raddr                       : std_logic_vector( 9 downto 0);
signal ssd_accu_mem_rdata                  : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal ssd_mem_rdata                       : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal sig_sus_dloff_d1                    : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal sig_sus_dloff_d2                    : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal reg_sig_sus_dloff_w                 : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sig_sus_dloff_f                 : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_sig_sus_dloff_s                 : std_logic_vector(RDATA_WIDTH-1 downto 0);
signal reg_clock_fail_flag                 : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal reg_clock_fail_flag_d1              : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal reg_clock_fail_flag_d2              : std_logic_vector( TX_ANT_NUM-1 downto 0);

signal reg_hw_log_rdata                    : std_logic_vector(RDATA_WIDTH-1 downto 0);
--
-- selectable pim
signal reg_pim_sltb1_core_gain_qpoint_ab         : std_logic_vector(31 downto 0);
signal reg_pim_sltb1_core_gain_qpoint_cd         : std_logic_vector(31 downto 0);
signal reg_pim_sltb1_core_lut_upt_switch         : std_logic_vector(31 downto 0);
signal reg_pim_sltb1_core_lut_depth_sel          : std_logic_vector(31 downto 0);
signal reg_pim_sltb1_core_out_dly                : std_logic_array32(8-1 downto 0);

signal reg_pim_sltb2_core_gain_qpoint_ab         : std_logic_vector(31 downto 0);
signal reg_pim_sltb2_core_gain_qpoint_cd         : std_logic_vector(31 downto 0);
signal reg_pim_sltb2_core_lut_upt_switch         : std_logic_vector(31 downto 0);
signal reg_pim_sltb2_core_lut_depth_sel          : std_logic_vector(31 downto 0);
signal reg_pim_sltb2_core_out_dly                : std_logic_array32(8-1 downto 0);

signal reg_pim_sltb_intra_nco_wren               : std_logic_vector(31 downto 0) := (others=>'0');
signal reg_pim_sltb_intra_nco_word               : std_logic_vector(31 downto 0) := (others=>'0');
signal reg_pim_sltb_inter1_nco_wren              : std_logic_vector(31 downto 0) := (others=>'0');
signal reg_pim_sltb_inter1_nco_word              : std_logic_vector(31 downto 0) := (others=>'0');
signal reg_pim_sltb_inter2_nco_wren              : std_logic_vector(31 downto 0) := (others=>'0');
signal reg_pim_sltb_inter2_nco_word              : std_logic_vector(31 downto 0) := (others=>'0');
signal reg_pim_sltb_im3gen_intra_sel             : std_logic_vector(31 downto 0) := (others=>'0');
signal reg_pim_sltb_im3gen_inter1_sel            : std_logic_vector(31 downto 0) := (others=>'0');
signal reg_pim_sltb_im3gen_inter2_sel            : std_logic_vector(31 downto 0) := (others=>'0');
signal reg_pim_sltb_bit_shift_sel                : std_logic_vector(31 downto 0) := (others=>'0');
signal s_pim_sltb_bit_shift_sel                  : std_logic_vector(31 downto 0) := (others=>'0');
signal reg_pim_sltb_quarter_shift_intra_sel      : std_logic_vector(31 downto 0) := (others=>'0');
signal reg_pim_sltb_quarter_shift_inter1_sel     : std_logic_vector(31 downto 0) := (others=>'0');
signal reg_pim_sltb_quarter_shift_inter2_sel     : std_logic_vector(31 downto 0) := (others=>'0');
-- -- d2
signal s_pim_sltb1_core_gain_qpoint_ab_d2        : std_logic_vector(31 downto 0)            := (others=>'0') ;
signal s_pim_sltb1_core_gain_qpoint_cd_d2        : std_logic_vector(31 downto 0)            := (others=>'0') ;
signal s_pim_sltb1_core_lut_upt_switch_d2        : std_logic_vector(TX_ANT_NUM-1 downto 0)  := (others=>'0') ;
-- 
signal s_pim_sltb2_core_gain_qpoint_ab_d2        : std_logic_vector(31 downto 0) := (others=>'0') ;
signal s_pim_sltb2_core_gain_qpoint_cd_d2        : std_logic_vector(31 downto 0) := (others=>'0') ;
signal s_pim_sltb2_core_lut_upt_switch_d2        : std_logic_vector(TX_ANT_NUM-1 downto 0)  := (others=>'0') ;

signal s_pim_sltb_intra_nco_wren_d2              : std_logic_vector(0 downto 0) := (others=>'0');
signal s_pim_sltb_inter1_nco_wren_d2             : std_logic_vector(0 downto 0) := (others=>'0');
signal s_pim_sltb_inter2_nco_wren_d2             : std_logic_vector(0 downto 0) := (others=>'0');
-- signal s_pim_sltb_im3gen_intra_sel_d2            : std_logic_vector(0 downto 0) := (others=>'0');
signal s_pim_sltb_im3gen_intra_sel_d2            : std_logic_vector(31 downto 0) := (others=>'0');
signal reg_pim_sltb_im3gen_inter1_sel_d2         : std_logic_vector(31 downto 0) := (others=>'0');
signal reg_pim_sltb_im3gen_inter2_sel_d2         : std_logic_vector(31 downto 0) := (others=>'0');



-- Attribute ------------------------------------------------------------------------
attribute KEEP : string;
attribute KEEP of PIM_SRC_INTRAB_DLY_STRB_OUT                   : signal is "TRUE";                   
attribute KEEP of PIM_SRC_INTRAB_DLY_OUT                        : signal is "TRUE";
attribute KEEP of PIM_SRC_INTERB_DLY_STRB_OUT                   : signal is "TRUE";                   
attribute KEEP of PIM_SRC_INTERB_CDLY_OUT                       : signal is "TRUE";
attribute KEEP of reg_pim_src_intrab_dly                        : signal is "TRUE";
attribute KEEP of wren_pim_03_cpuclk_sh                         : signal is "TRUE";

-- attribute MARK_DEBUG : string;
-- attribute MARK_DEBUG of PIM_SRC_INTRAB_DLY_STRB_OUT             : signal is "TRUE";                   
-- attribute MARK_DEBUG of PIM_SRC_INTRAB_DLY_OUT                  : signal is "TRUE";
-- attribute MARK_DEBUG of PIM_SRC_INTERB_DLY_STRB_OUT             : signal is "TRUE";                   
-- attribute MARK_DEBUG of PIM_SRC_INTERB_CDLY_OUT                 : signal is "TRUE";
-- attribute MARK_DEBUG of reg_pim_src_intrab_dly                  : signal is "TRUE";                   
-- attribute MARK_DEBUG of wren_pim_03_cpuclk_sh                   : signal is "TRUE";

begin

-- *************************************************************************************
-- Input Assign 
-- *************************************************************************************
    G_DPD_Core_LUT_Rdata_Assign : for I in 0 to (TX_ANT_NUM-1) generate begin
        dpd_core_lut_rdata(I) <= DPD_CORE_LUT_RDATA_IN(I);
    end generate;

    G_DPD_Core_LUT_Nulldata_Assign : for I in TX_ANT_NUM to 8 generate begin
        dpd_core_lut_rdata(I) <= (others => '0');
    end generate;

    G_PIM_Core_LUT_Rdata_Assign : for I in 0 to (TX_ANT_NUM-1) generate begin
        pim_core_lut_rdata(I) <= PIM_CORE_LUT_RDATA_IN(I);
    end generate;

    G_PIM_Core_LUT_Nulldata_Assign : for I in TX_ANT_NUM to 8 generate begin
        pim_core_lut_rdata(I) <= (others => '0');
    end generate;

    reg_pim_mode_status                 <= zeros(RDATA_WIDTH-1 downto 16+RX_ANT_NUM) & PIM_DETECTOR_ON_IN & 
                                           zeros(15 downto RX_ANT_NUM) & PIM_MITIGATOR_ON_IN;
    reg_pim_sltb1_mode_status           <= zeros(RDATA_WIDTH-1 downto 16+RX_ANT_NUM) & PIM_SLTB1_DETECTOR_ON_IN & 
                                           zeros(15 downto RX_ANT_NUM) & PIM_SLTB1_MITIGATOR_ON_IN;
    reg_pim_sltb2_mode_status           <= zeros(RDATA_WIDTH-1 downto 16+RX_ANT_NUM) & PIM_SLTB2_DETECTOR_ON_IN & 
                                           zeros(15 downto RX_ANT_NUM) & PIM_SLTB2_MITIGATOR_ON_IN;

    reg_pim_complex_filter_coef_i_rdata <= zeros(RDATA_WIDTH-1 downto 21) & PIM_COMPLEX_FILTER_COEF_I_RDATA_IN;
    reg_pim_complex_filter_coef_q_rdata <= zeros(RDATA_WIDTH-1 downto 21) & PIM_COMPLEX_FILTER_COEF_Q_RDATA_IN;

    G_PNPC_DC_IQ : for I in 0 to (RX_ANT_NUM-1) generate begin
        pnpc_dc_iq(I)                   <= PNPC_TP_DC_IQ_IN(I);
    end generate;

    G_Unsigned_PNPC_DC_IQ : for I in RX_ANT_NUM to 8 generate begin
        pnpc_dc_iq(I)                   <= (others => '0');
    end generate;

    reg_sc_complete_flag                <= SC_COMPLETE_FLAG_IN;       
    reg_sc_sub_pwr                      <= SC_SUB_PWR_IN;       
    reg_sc_sub_peak                     <= SC_SUB_PEAK_IN;       
    reg_sc_sub_peak_num                 <= SC_SUB_PEAK_NUM_IN;       
    reg_sc_time_index                   <= SC_TIME_INDEX_IN;

    reg_ssd_accu_done_flg               <= SSD_ACCU_DONE_IN;
    sc_capture_mem_rdata                <= SC_MEM_RDATA_IN;
    ssd_accu_mem_rdata                  <= SSD_MEM_RDATA_IN;

    P_SIG_SUS_DLOFF_DC : process(rst_synch_cpu, CLK_CPU) begin
        if (rst_synch_cpu = '1') then
            sig_sus_dloff_d1 <= (others => '0');
            sig_sus_dloff_d2 <= (others => '0');
        elsif (CLK_CPU'event) and (CLK_CPU = '1') then
            sig_sus_dloff_d1 <= SIG_SUS_DLOFF_IN;
            sig_sus_dloff_d2 <= sig_sus_dloff_d1;
        end if;
    end process;

    reg_sig_sus_dloff_w                <= zeros(RDATA_WIDTH-1 downto TX_ANT_NUM) & sig_sus_dloff_d2;           
    reg_clock_fail_flag                <= CLOCK_FAIL_FLAG_IN;         



-- *************************************************************************************
-- Reset Synchronizer
-- *************************************************************************************
    U_RST_CLK_CPU : RST_SYNC generic map(4, 200) port map(RST_CPU, CLK_CPU, rst_synch_cpu); 
    U_RST_CLK_SC  : RST_SYNC generic map(4, 200) port map(RST_CPU, CLK_SC , rst_synch_sc ); 
    U_RST_CLK_PIM : RST_SYNC generic map(4, 200) port map(RST_CPU, CLK_PIMD , rst_synch_pim ); 

-- *************************************************************************************
-- CPU Interface Bus Signal Processing : Clock Domain Change
-- *************************************************************************************
    addr_h8 <= ADDR_CPU_IN(15 downto 8);
    addr_l8 <= ADDR_CPU_IN( 7 downto 0);

    P_WR_Enable_Strobe_CPU_CLK : process(rst_synch_cpu, CLK_CPU) begin
        if (rst_synch_cpu = '1') then
            wren_cpuclk_sh   <= (others => '0');  
            wren_cpuclk_rpls <= '0';      
        elsif (CLK_CPU'event) and (CLK_CPU = '1') then
            wren_cpuclk_sh   <= wren_cpuclk_sh(0) & WREN_CPU_IN;  
            wren_cpuclk_rpls <= wren_cpuclk_sh(0) and (not wren_cpuclk_sh(1));      
        end if;
    end process;

    P_Read_Valid_GEN : process(rst_synch_cpu, CLK_CPU) begin
        if (rst_synch_cpu = '1') then
            rden_cpuclk_sh      <= (others => '0'); 
            rden_d1_cpuclk_rpls <= '0';
            rden_d2_cpuclk_rpls <= '0'; 
            rden_d4_cpuclk_rpls <= '0';
            rden_d6_cpuclk_rpls <= '0'; 
            rdvld_cpuclk        <= '0';
            lc_cpuclk_rpls      <= '0';
        elsif (CLK_CPU'event) and (CLK_CPU = '1') then
            rden_cpuclk_sh      <= rden_cpuclk_sh(4 downto 0) & RDEN_CPU_IN; 
            rden_d1_cpuclk_rpls <= rden_cpuclk_sh(0) and (not rden_cpuclk_sh(1));
            rden_d2_cpuclk_rpls <= rden_cpuclk_sh(1) and (not rden_cpuclk_sh(2)); 
            rden_d4_cpuclk_rpls <= rden_cpuclk_sh(3) and (not rden_cpuclk_sh(4));
            rden_d6_cpuclk_rpls <= rden_cpuclk_sh(4) and (not rden_cpuclk_sh(5));  
            lc_cpuclk_rpls      <= rden_cpuclk_sh(0) and (not rden_cpuclk_sh(1));

            if (rden_d6_cpuclk_rpls = '1') then
                rdvld_cpuclk <= '1';
            else
                rdvld_cpuclk <= '0';
            end if;
        end if;
    end process;

-- *************************************************************************************
-- DPD_CORE Control 
-- *************************************************************************************
    G_DPD_CORE_Implementation : if (DPD_CORE_IMPLEMENTATION = TRUE) generate begin 
        P_DPD_REG_WREN_CPUCLK : process(rst_synch_cpu, CLK_CPU) begin
            if (rst_synch_cpu = '1') then
                wren_dpd_00_cpuclk      <= '0';
                wren_dpd_00_cpuclk_sh   <= (others => '0');
                wren_dpd_00_cpuclk_rpls <= '0';
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                if (WREN_CPU_IN = '1') then 
                    if (addr_h8 = x"00") then
                        wren_dpd_00_cpuclk <= '1';
                    else
                        wren_dpd_00_cpuclk <= '0';
                    end if;
                else
                    wren_dpd_00_cpuclk <= '0';
                end if;

                wren_dpd_00_cpuclk_sh   <= wren_dpd_00_cpuclk_sh(0) & wren_dpd_00_cpuclk;
                wren_dpd_00_cpuclk_rpls <= wren_dpd_00_cpuclk and (not wren_dpd_00_cpuclk_sh(0));
            end if;
        end process;

        P_DPD_Core_Switch_CDC_Strobe : process(rst_synch_cpu, CLK_CPU) begin
            if (rst_synch_cpu = '1') then
                reg_dpd_core_gidx_cdc_strb         <= '0'; 
                reg_dpd_core_qpoint_cdc_strb       <= '0'; 

                -- reg_dpd_core_lut_switch_cdc_strb_a <= '0';         
                -- reg_dpd_core_lut_switch_cdc_strb_b <= '0';         
                -- reg_dpd_core_lut_switch_cdc_strb_c <= '0';         
                -- reg_dpd_core_lut_switch_cdc_strb_d <= '0';         
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                if (addr_l8 = x"00") then
                    reg_dpd_core_gidx_cdc_strb         <= wren_dpd_00_cpuclk_sh(1); 
                else
                    reg_dpd_core_gidx_cdc_strb         <= '0'; 
                end if;

                if (addr_l8 = x"01") then
                    reg_dpd_core_qpoint_cdc_strb       <= wren_dpd_00_cpuclk_sh(1); 
                else
                    reg_dpd_core_qpoint_cdc_strb       <= '0'; 
                end if;

                -- if ((addr_l8 = x"10") or (addr_l8 = x"11")) then
                --     reg_dpd_core_lut_switch_cdc_strb_a <= wren_dpd_00_cpuclk_sh(1);         
                -- else
                --     reg_dpd_core_lut_switch_cdc_strb_a <= '0';         
                -- end if;

                -- if ((addr_l8 = x"12") or (addr_l8 = x"13")) then
                --     reg_dpd_core_lut_switch_cdc_strb_b <= wren_dpd_00_cpuclk_sh(1);         
                -- else
                --     reg_dpd_core_lut_switch_cdc_strb_b <= '0';         
                -- end if;

                -- if ((addr_l8 = x"14") or (addr_l8 = x"15")) then
                --     reg_dpd_core_lut_switch_cdc_strb_c <= wren_dpd_00_cpuclk_sh(1);         
                -- else
                --     reg_dpd_core_lut_switch_cdc_strb_c <= '0';         
                -- end if;

                -- if ((addr_l8 = x"16") or (addr_l8 = x"17")) then
                --     reg_dpd_core_lut_switch_cdc_strb_d <= wren_dpd_00_cpuclk_sh(1);         
                -- else
                --     reg_dpd_core_lut_switch_cdc_strb_d <= '0';         
                -- end if;
            end if;
        end process;

        REG_WR_0x10000 : REG32_WRITE generic map(x"FFFFFFFF" , x"00", x"55550000") port map(rst_synch_cpu, CLK_CPU, wren_dpd_00_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_dpd_core_qpoint_n_gidx_ab   );
        REG_WR_0x10001 : REG32_WRITE generic map(x"FFFFFFFF" , x"01", x"55550000") port map(rst_synch_cpu, CLK_CPU, wren_dpd_00_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_dpd_core_qpoint_n_gidx_cd   );
        REG_WR_0x10002 : REG32_WRITE generic map(reg_path_num, x"02", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_dpd_00_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_dpd_core_lut_switch         );
                                                                                                                                  
        -- REG_WR_0x10010 : REG32_WRITE generic map(x"000FFFFF" , x"10", x"00032104") port map(rst_synch_cpu, CLK_CPU, wren_dpd_00_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_dpd_core_lut_input_switch_a );
        -- REG_WR_0x10011 : REG32_WRITE generic map(x"000FFFFF" , x"11", x"00004321") port map(rst_synch_cpu, CLK_CPU, wren_dpd_00_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_dpd_core_lut_output_switch_a);
        -- REG_WR_0x10012 : REG32_WRITE generic map(x"000FFFFF" , x"12", x"00032104") port map(rst_synch_cpu, CLK_CPU, wren_dpd_00_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_dpd_core_lut_input_switch_b );
        -- REG_WR_0x10013 : REG32_WRITE generic map(x"000FFFFF" , x"13", x"00004321") port map(rst_synch_cpu, CLK_CPU, wren_dpd_00_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_dpd_core_lut_output_switch_b);
        -- REG_WR_0x10014 : REG32_WRITE generic map(x"000FFFFF" , x"14", x"00032104") port map(rst_synch_cpu, CLK_CPU, wren_dpd_00_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_dpd_core_lut_input_switch_c );
        -- REG_WR_0x10015 : REG32_WRITE generic map(x"000FFFFF" , x"15", x"00004321") port map(rst_synch_cpu, CLK_CPU, wren_dpd_00_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_dpd_core_lut_output_switch_c);
        -- REG_WR_0x10016 : REG32_WRITE generic map(x"000FFFFF" , x"16", x"00032104") port map(rst_synch_cpu, CLK_CPU, wren_dpd_00_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_dpd_core_lut_input_switch_d );
        -- REG_WR_0x10017 : REG32_WRITE generic map(x"000FFFFF" , x"17", x"00004321") port map(rst_synch_cpu, CLK_CPU, wren_dpd_00_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_dpd_core_lut_output_switch_d);
                                                                                                                                                                      
        REG_WR_0x1001A : REG32_WRITE generic map(x"0000003F" , x"1A", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_dpd_00_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_dpd_core_lut_depth_sel      );
        REG_WR_0x1001F : REG32_WRITE generic map(x"0000000F" , x"1F", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_dpd_00_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_dpd_core_lut_rb_test        );

        P_REG_DPD_CTRL_CPUCLK_Read : process(rst_synch_cpu, CLK_CPU) begin
            if (rst_synch_cpu = '1') then
                reg_cpuclk_dpdctrl_rdata <= (others => '0');
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                if (rden_d2_cpuclk_rpls = '1') then
                    if (addr_h8 = x"00") then
                        case (addr_l8) is
                            when x"00"  => reg_cpuclk_dpdctrl_rdata <= reg_dpd_core_qpoint_n_gidx_ab;  
                            when x"01"  => reg_cpuclk_dpdctrl_rdata <= reg_dpd_core_qpoint_n_gidx_cd;
                            when x"02"  => reg_cpuclk_dpdctrl_rdata <= reg_dpd_core_lut_switch;
                            -- when x"10"  => reg_cpuclk_dpdctrl_rdata <= reg_dpd_core_lut_input_switch_a ;
                            -- when x"11"  => reg_cpuclk_dpdctrl_rdata <= reg_dpd_core_lut_output_switch_a;
                            -- when x"12"  => reg_cpuclk_dpdctrl_rdata <= reg_dpd_core_lut_input_switch_b ;
                            -- when x"13"  => reg_cpuclk_dpdctrl_rdata <= reg_dpd_core_lut_output_switch_b;
                            -- when x"14"  => reg_cpuclk_dpdctrl_rdata <= reg_dpd_core_lut_input_switch_c ;
                            -- when x"15"  => reg_cpuclk_dpdctrl_rdata <= reg_dpd_core_lut_output_switch_c;
                            -- when x"16"  => reg_cpuclk_dpdctrl_rdata <= reg_dpd_core_lut_input_switch_d ;
                            -- when x"17"  => reg_cpuclk_dpdctrl_rdata <= reg_dpd_core_lut_output_switch_d;
                            when x"1A"  => reg_cpuclk_dpdctrl_rdata <= reg_dpd_core_lut_depth_sel;
                            when x"1F"  => reg_cpuclk_dpdctrl_rdata <= reg_dpd_core_lut_rb_test;

                            when x"30"  => reg_cpuclk_dpdctrl_rdata <= UL_MON0_DATA_IN;
                            when x"31"  => reg_cpuclk_dpdctrl_rdata <= x"0000000" & "000" & UL_MON0_VLD_IN ;
                            when x"32"  => reg_cpuclk_dpdctrl_rdata <= UL_MON1_DATA_IN;
                            when x"33"  => reg_cpuclk_dpdctrl_rdata <= x"0000000" & "000" & UL_MON1_VLD_IN ;
                            when x"34"  => reg_cpuclk_dpdctrl_rdata <= UL_MON2_DATA_IN;
                            when x"35"  => reg_cpuclk_dpdctrl_rdata <= x"0000000" & "000" & UL_MON2_VLD_IN ;
                            when others => reg_cpuclk_dpdctrl_rdata <= (others => '0');
                        end case;
                    else
                        reg_cpuclk_dpdctrl_rdata <= (others => '0');
                    end if;
                else
                    reg_cpuclk_dpdctrl_rdata <= reg_cpuclk_dpdctrl_rdata;
                end if;
            end if;
        end process;


        G_DPD_LUT_Non_Optimized : if (DPD_CORE_LUT_OPTIMIZED = FALSE or DPD_CORE_LUT_OPTIMIZED = TRUE) generate begin             

            dpd_lut_we <= "0000";
            dpd_lut_re <= "0000";

            P_DPD_LUT_Non_Optimized_WE : process(rst_synch_cpu, CLK_CPU) begin
                if (rst_synch_cpu = '1') then
                    dpd_lut_nopt_we <= (others => '0');
                    dpd_lut_nopt_re <= (others => '0');
                elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                    if (wren_cpuclk_sh(0) = '1') then
                        case (addr_h8) is
                            when x"10"  => dpd_lut_nopt_we <= "00000001"; 
                            when x"11"  => dpd_lut_nopt_we <= "00000001"; 
                            when x"12"  => dpd_lut_nopt_we <= "00000010"; 
                            when x"13"  => dpd_lut_nopt_we <= "00000010"; 
                            when x"14"  => dpd_lut_nopt_we <= "00000100"; 
                            when x"15"  => dpd_lut_nopt_we <= "00000100"; 
                            when x"16"  => dpd_lut_nopt_we <= "00001000"; 
                            when x"17"  => dpd_lut_nopt_we <= "00001000"; 
                            when x"18"  => dpd_lut_nopt_we <= "00010000"; 
                            when x"19"  => dpd_lut_nopt_we <= "00010000"; 
                            when x"1A"  => dpd_lut_nopt_we <= "00100000"; 
                            when x"1B"  => dpd_lut_nopt_we <= "00100000"; 
                            when x"1C"  => dpd_lut_nopt_we <= "01000000"; 
                            when x"1D"  => dpd_lut_nopt_we <= "01000000"; 
                            when x"1E"  => dpd_lut_nopt_we <= "10000000"; 
                            when x"1F"  => dpd_lut_nopt_we <= "10000000"; 
                            when others => dpd_lut_nopt_we <= (others => '0'); 
                        end case;
                    else
                        dpd_lut_nopt_we <= (others => '0');
                    end if;

                    if (rden_cpuclk_sh(0) = '1') then
                        case (addr_h8) is
                            when x"10"  => dpd_lut_nopt_re <= "00000001"; 
                            when x"11"  => dpd_lut_nopt_re <= "00000001"; 
                            when x"12"  => dpd_lut_nopt_re <= "00000010"; 
                            when x"13"  => dpd_lut_nopt_re <= "00000010"; 
                            when x"14"  => dpd_lut_nopt_re <= "00000100"; 
                            when x"15"  => dpd_lut_nopt_re <= "00000100"; 
                            when x"16"  => dpd_lut_nopt_re <= "00001000"; 
                            when x"17"  => dpd_lut_nopt_re <= "00001000"; 
                            when x"18"  => dpd_lut_nopt_re <= "00010000"; 
                            when x"19"  => dpd_lut_nopt_re <= "00010000"; 
                            when x"1A"  => dpd_lut_nopt_re <= "00100000"; 
                            when x"1B"  => dpd_lut_nopt_re <= "00100000"; 
                            when x"1C"  => dpd_lut_nopt_re <= "01000000"; 
                            when x"1D"  => dpd_lut_nopt_re <= "01000000"; 
                            when x"1E"  => dpd_lut_nopt_re <= "10000000"; 
                            when x"1F"  => dpd_lut_nopt_re <= "10000000"; 
                            when others => dpd_lut_nopt_re <= (others => '0'); 
                        end case;
                    else
                        dpd_lut_nopt_re <= (others => '0');
                    end if;
                end if;
            end process;

            dpd_core_lut_re <= dpd_lut_nopt_re(TX_ANT_NUM-1 downto 0);

            G_DPD_LUT_RAM_SET_TX : for I in 0 to (TX_ANT_NUM-1) generate begin
                P_LUT_WE_CPU_Clocking : process(rst_synch_cpu, CLK_CPU) begin
                    if (rst_synch_cpu = '1') then
                        dpd_lut_we_d(I)  <= '0';
                    elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                        dpd_lut_we_d(I)  <= dpd_lut_nopt_we(I);  
                    end if;
                end process;

                P_DPD_LUT_RAM_Interface : process(rst_synch_cpu, CLK_CPU) begin
                    if (rst_synch_cpu = '1') then
                        dpd_core_lut_we(I)    <= '0';              
                        dpd_core_lut_addr(I)  <= (others => '0');  
                        dpd_core_lut_wdata(I) <= (others => '0');  
                    elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                        dpd_core_lut_we(I)    <= dpd_lut_nopt_we(I) and (not dpd_lut_we_d(I));              
 
                        if (dpd_lut_nopt_we(I) = '1') then
                            dpd_core_lut_wdata(I) <= WDATA_CPU_IN;  
                        else
                            dpd_core_lut_wdata(I) <= dpd_core_lut_wdata(I);  
                        end if;

                        dpd_core_lut_addr(I)  <= reg_dpd_core_lut_depth_sel(5 downto 0) & ADDR_CPU_IN(8 downto 0);  
                    end if;
                end process;
            end generate;

            G_DPD_Core_LUT_Readback_Test_Enable : if (DPD_CORE_LUT_RBTEST = TRUE) generate begin
                P_DL_DPD_LUT_Read : process(rst_synch_cpu, CLK_CPU) begin
                    if (rst_synch_cpu = '1') then
                        dpd_lut_rdata <= (others => '0'); 
                    elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                        if (rden_d4_cpuclk_rpls = '1') then
                            case (addr_h8) is
                                when x"10"  => dpd_lut_rdata <= dpd_core_lut_rdata(0);
                                when x"11"  => dpd_lut_rdata <= dpd_core_lut_rdata(0);
                                when x"12"  => dpd_lut_rdata <= dpd_core_lut_rdata(1);
                                when x"13"  => dpd_lut_rdata <= dpd_core_lut_rdata(1);
                                when x"14"  => dpd_lut_rdata <= dpd_core_lut_rdata(2);
                                when x"15"  => dpd_lut_rdata <= dpd_core_lut_rdata(2);
                                when x"16"  => dpd_lut_rdata <= dpd_core_lut_rdata(3);
                                when x"17"  => dpd_lut_rdata <= dpd_core_lut_rdata(3);
                                when x"18"  => dpd_lut_rdata <= dpd_core_lut_rdata(4);
                                when x"19"  => dpd_lut_rdata <= dpd_core_lut_rdata(4);
                                when x"1A"  => dpd_lut_rdata <= dpd_core_lut_rdata(5);
                                when x"1B"  => dpd_lut_rdata <= dpd_core_lut_rdata(5);
                                when x"1C"  => dpd_lut_rdata <= dpd_core_lut_rdata(6);
                                when x"1D"  => dpd_lut_rdata <= dpd_core_lut_rdata(6);
                                when x"1E"  => dpd_lut_rdata <= dpd_core_lut_rdata(7);
                                when x"1F"  => dpd_lut_rdata <= dpd_core_lut_rdata(7);
                                when others => dpd_lut_rdata <= (others => '0');
                            end case;
                        else
                            dpd_lut_rdata <= dpd_lut_rdata; 
                        end if;
                    end if;
                end process;
            end generate;

            G_DPD_Core_LUT_Readback_Test_Disable : if (DPD_CORE_LUT_RBTEST = FALSE) generate begin
                dpd_lut_rdata <= (others => '0'); 
            end generate;
        end generate;

    end generate;

    G_DPD_CORE_Not_Implementation : if (DPD_CORE_IMPLEMENTATION = FALSE) generate begin 

        wren_dpd_00_cpuclk                 <= '0'; 
        wren_dpd_00_cpuclk_sh              <= (others => '0'); 
        wren_dpd_00_cpuclk_rpls            <= '0'; 

        reg_dpd_core_gidx_cdc_strb         <= '0'; 
        reg_dpd_core_qpoint_cdc_strb       <= '0'; 

        reg_dpd_core_qpoint_n_gidx_ab      <= (others => '0');
        reg_dpd_core_qpoint_n_gidx_cd      <= (others => '0');
        reg_dpd_core_lut_depth_sel         <= (others => '0');
        reg_dpd_core_lut_switch            <= (others => '0');

        -- reg_dpd_core_lut_switch_cdc_strb_a <= '0'; 
        -- reg_dpd_core_lut_input_switch_a    <= (others => '0'); 
        -- reg_dpd_core_lut_output_switch_a   <= (others => '0'); 

        -- reg_dpd_core_lut_switch_cdc_strb_b <= '0'; 
        -- reg_dpd_core_lut_input_switch_b    <= (others => '0'); 
        -- reg_dpd_core_lut_output_switch_b   <= (others => '0'); 

        -- reg_dpd_core_lut_switch_cdc_strb_c <= '0'; 
        -- reg_dpd_core_lut_input_switch_c    <= (others => '0'); 
        -- reg_dpd_core_lut_output_switch_c   <= (others => '0'); 

        -- reg_dpd_core_lut_switch_cdc_strb_d <= '0'; 
        -- reg_dpd_core_lut_input_switch_d    <= (others => '0'); 
        -- reg_dpd_core_lut_output_switch_d   <= (others => '0'); 
        
        reg_dpd_core_lut_rb_test           <= (others => '0'); 

        dpd_lut_we                         <= (others => '0');
        dpd_lut_re                         <= (others => '0');
        dpd_lut_we_d                       <= (others => '0');
        dpd_core_lut_we                    <= (others => '0');             
        dpd_core_lut_re                    <= (others => '0');
        dpd_core_lut_addr                  <= (others => (others => '0')); 
        dpd_core_lut_wdata                 <= (others => (others => '0')); 

        reg_cpuclk_dpdctrl_rdata           <= (others => '0');
        dpd_lut_rdata                      <= (others => '0'); 

    end generate;

-- *************************************************************************************
-- PIM_CORE Control 
-- *************************************************************************************
    G_PIM_CORE_Implementation : if (PIM_IMPLEMENTATION = TRUE) generate begin 
        P_PIM_REG_WREN_CPUCLK : process(rst_synch_cpu, CLK_CPU) begin
            -- "03"
            if (rst_synch_cpu = '1') then
                wren_pim_03_cpuclk      <= '0';
                wren_pim_03_cpuclk_sh   <= (others => '0'); 
                wren_pim_03_cpuclk_rpls <= '0';             
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                if (WREN_CPU_IN = '1') then 
                    if (addr_h8 = x"03") then
                        wren_pim_03_cpuclk <= '1';
                    else
                        wren_pim_03_cpuclk <= '0';
                    end if;
                else
                    wren_pim_03_cpuclk <= '0';
                end if;

                wren_pim_03_cpuclk_sh   <= wren_pim_03_cpuclk_sh(0) & wren_pim_03_cpuclk; 
                wren_pim_03_cpuclk_rpls <= wren_pim_03_cpuclk and (not wren_pim_03_cpuclk_sh(0));             
            end if;
            -- "70" 
            if (rst_synch_cpu = '1') then
                wren_pim_70_cpuclk      <= '0';
                wren_pim_70_cpuclk_sh   <= (others => '0'); 
                wren_pim_70_cpuclk_rpls <= '0';             
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                if (WREN_CPU_IN = '1') then 
                    if (addr_h8 = x"70") then
                        wren_pim_70_cpuclk <= '1';
                    else
                        wren_pim_70_cpuclk <= '0';
                    end if;
                else
                    wren_pim_70_cpuclk <= '0';
                end if;

                wren_pim_70_cpuclk_sh   <= wren_pim_70_cpuclk_sh(0) & wren_pim_70_cpuclk; 
                wren_pim_70_cpuclk_rpls <= wren_pim_70_cpuclk and (not wren_pim_70_cpuclk_sh(0));             
            end if;
           
        end process;

        P_PIM_REG_CDC_Strobe : process(rst_synch_cpu, CLK_CPU) begin
            if (rst_synch_cpu = '1') then
                reg_pim_core_gidx_cdc_strb          <= '0'; 
                reg_pim_core_qpoint_cdc_strb        <= '0'; 
                reg_pim_sltb1_core_gidx_cdc_strb    <= '0'; 
                reg_pim_sltb1_core_qpoint_cdc_strb  <= '0'; 
                reg_pim_sltb2_core_gidx_cdc_strb    <= '0'; 
                reg_pim_sltb2_core_qpoint_cdc_strb  <= '0'; 

                -- reg_pim_core_lut_switch_cdc_strb_a  <= '0';         
                -- reg_pim_core_lut_switch_cdc_strb_b  <= '0';         
                -- reg_pim_core_lut_switch_cdc_strb_c  <= '0';         
                -- reg_pim_core_lut_switch_cdc_strb_d  <= '0';         

                reg_pim_src_intrab_dly_strb         <= '0'; 
                reg_pim_src_interb_dly_strb         <= '0'; 
                reg_pim_ref_dly_strb                <= '0'; 
                reg_pim_ul_dly_strb                 <= '0'; 

                reg_pnpc_mu_sel_strb                <= '0'; 
                reg_pnpc_setval_strb                <= '0'; 

                reg_pim_ul_mixer_freq_err_comp_strb <= '0';                      
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                -- 03
                if (addr_l8 = x"10") then
                    reg_pim_core_gidx_cdc_strb <= wren_pim_03_cpuclk_sh(1); 
                else
                    reg_pim_core_gidx_cdc_strb <= '0'; 
                end if;

                if (addr_l8 = x"11") then
                    reg_pim_core_qpoint_cdc_strb <= wren_pim_03_cpuclk_sh(1); 
                else
                    reg_pim_core_qpoint_cdc_strb <= '0'; 
                end if;
                -- 70 
                if (addr_l8 = x"10") then
                    reg_pim_sltb1_core_gidx_cdc_strb <= wren_pim_70_cpuclk_sh(1); 
                else
                    reg_pim_sltb1_core_gidx_cdc_strb <= '0'; 
                end if;

                if (addr_l8 = x"11") then
                    reg_pim_sltb1_core_qpoint_cdc_strb <= wren_pim_70_cpuclk_sh(1); 
                else
                    reg_pim_sltb1_core_qpoint_cdc_strb <= '0'; 
                end if;

                if (addr_l8 = x"20") then
                    reg_pim_sltb2_core_gidx_cdc_strb <= wren_pim_70_cpuclk_sh(1); 
                else
                    reg_pim_sltb2_core_gidx_cdc_strb <= '0'; 
                end if;

                if (addr_l8 = x"21") then
                    reg_pim_sltb2_core_qpoint_cdc_strb <= wren_pim_70_cpuclk_sh(1); 
                else
                    reg_pim_sltb2_core_qpoint_cdc_strb <= '0'; 
                end if;
                -- if ((addr_l8 = x"20") or (addr_l8 = x"21")) then
                --     reg_pim_core_lut_switch_cdc_strb_a <= wren_pim_03_cpuclk_sh(1);         
                -- else
                --     reg_pim_core_lut_switch_cdc_strb_a <= '0';        
                -- end if;

                -- if ((addr_l8 = x"22") or (addr_l8 = x"23")) then
                --     reg_pim_core_lut_switch_cdc_strb_b <= wren_pim_03_cpuclk_sh(1);         
                -- else
                --     reg_pim_core_lut_switch_cdc_strb_b <= '0';         
                -- end if;

                -- if ((addr_l8 = x"24") or (addr_l8 = x"25")) then
                --     reg_pim_core_lut_switch_cdc_strb_c <= wren_pim_03_cpuclk_sh(1);         
                -- else
                --     reg_pim_core_lut_switch_cdc_strb_c <= '0';         
                -- end if;

                -- if ((addr_l8 = x"26") or (addr_l8 = x"27")) then
                --     reg_pim_core_lut_switch_cdc_strb_d <= wren_pim_03_cpuclk_sh(1);         
                -- else
                --     reg_pim_core_lut_switch_cdc_strb_d <= '0';         
                -- end if;

                if (addr_l8(7 downto 4) = x"4") then
                    reg_pim_src_intrab_dly_strb <= wren_pim_03_cpuclk_sh(1); 
                else
                    reg_pim_src_intrab_dly_strb <= '0'; 
                end if;

                if (addr_l8(7 downto 4) = x"5") then
                    reg_pim_src_interb_dly_strb <= wren_pim_03_cpuclk_sh(1); 
                else
                    reg_pim_src_interb_dly_strb <= '0'; 
                end if;

                if (addr_l8(7 downto 4) = x"6") then
                    reg_pim_ref_dly_strb <= wren_pim_03_cpuclk_sh(1); 
                else
                    reg_pim_ref_dly_strb <= '0'; 
                end if;

                if (addr_l8(7 downto 4) = x"7") then
                    reg_pim_ul_dly_strb <= wren_pim_03_cpuclk_sh(1); 
                else
                    reg_pim_ul_dly_strb <= '0'; 
                end if;

                if (addr_l8 = x"82") then
                    reg_pnpc_mu_sel_strb <= wren_pim_03_cpuclk_sh(1); 
                else
                    reg_pnpc_mu_sel_strb <= '0'; 
                end if;

                if (addr_l8(7 downto 4) = x"9") then
                    reg_pnpc_setval_strb <= wren_pim_03_cpuclk_sh(1);             
                else
                    reg_pnpc_setval_strb <= '0';             
                end if;

                if (addr_l8 = x"A0") then
                    reg_pim_ul_mixer_freq_err_comp_strb <= wren_pim_03_cpuclk_sh(1);                      
                else
                    reg_pim_ul_mixer_freq_err_comp_strb <= '0';                      
                end if;
            end if;
        end process;

        REG_WR_0x10310 : REG32_WRITE generic map(x"FFFFFFFF" , x"10", x"55550000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_core_qpoint_n_gidx_ab       );
        REG_WR_0x10311 : REG32_WRITE generic map(x"FFFFFFFF" , x"11", x"55550000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_core_qpoint_n_gidx_cd       );
        REG_WR_0x10312 : REG32_WRITE generic map(reg_path_num, x"12", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_core_lut_switch             ); -- add
                                                                                                                                  
        -- REG_WR_0x10320 : REG32_WRITE generic map(x"000FFFFF" , x"20", x"00032104") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_core_lut_input_switch_a     );
        -- REG_WR_0x10321 : REG32_WRITE generic map(x"000FFFFF" , x"21", x"00004321") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_core_lut_output_switch_a    );
        -- REG_WR_0x10322 : REG32_WRITE generic map(x"000FFFFF" , x"22", x"00032104") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_core_lut_input_switch_b     );
        -- REG_WR_0x10323 : REG32_WRITE generic map(x"000FFFFF" , x"23", x"00004321") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_core_lut_output_switch_b    );
        -- REG_WR_0x10324 : REG32_WRITE generic map(x"000FFFFF" , x"24", x"00032104") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_core_lut_input_switch_c     );
        -- REG_WR_0x10325 : REG32_WRITE generic map(x"000FFFFF" , x"25", x"00004321") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_core_lut_output_switch_c    );
        -- REG_WR_0x10326 : REG32_WRITE generic map(x"000FFFFF" , x"26", x"00032104") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_core_lut_input_switch_d     );
        -- REG_WR_0x10327 : REG32_WRITE generic map(x"000FFFFF" , x"27", x"00004321") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_core_lut_output_switch_d    );
                                                                                                                                                              
        REG_WR_0x1032A : REG32_WRITE generic map(x"0000003F" , x"2A", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_core_lut_depth_sel          );
        REG_WR_0x1032F : REG32_WRITE generic map(x"0000000F" , x"2F", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_core_lut_rb_test            );
                                                                                                                                  
        REG_WR_0x10330 : REG32_WRITE generic map(reg_path_num, x"30", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_complex_filter_coef_wren    );
        REG_WR_0x10331 : REG32_WRITE generic map(reg_path_num, x"31", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_complex_filter_coef_rden    );
        REG_WR_0x10332 : REG32_WRITE generic map(reg_path_num, x"32", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_complex_filter_coef_wrdn    );
        REG_WR_0x10333 : REG32_WRITE generic map(x"0000000F" , x"33", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_complex_filter_coef_addr    );
        REG_WR_0x10334 : REG32_WRITE generic map(x"001FFFFF" , x"34", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_complex_filter_coef_i_wdata );
        REG_WR_0x10335 : REG32_WRITE generic map(x"001FFFFF" , x"35", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_complex_filter_coef_q_wdata );

        REG_WR_0x10340 : REG32_WRITE generic map(x"00000FFF" , x"40", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_intrab_dly(0));
        REG_WR_0x10341 : REG32_WRITE generic map(x"00000FFF" , x"41", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_intrab_dly(1));
        REG_WR_0x10342 : REG32_WRITE generic map(x"00000FFF" , x"42", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_intrab_dly(2));
        REG_WR_0x10343 : REG32_WRITE generic map(x"00000FFF" , x"43", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_intrab_dly(3));
        REG_WR_0x10344 : REG32_WRITE generic map(x"00000FFF" , x"44", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_intrab_dly(4));
        REG_WR_0x10345 : REG32_WRITE generic map(x"00000FFF" , x"45", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_intrab_dly(5));
        REG_WR_0x10346 : REG32_WRITE generic map(x"00000FFF" , x"46", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_intrab_dly(6));
        REG_WR_0x10347 : REG32_WRITE generic map(x"00000FFF" , x"47", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_intrab_dly(7));

        REG_WR_0x10350 : REG32_WRITE generic map(x"000F0FFF" , x"50", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_interb_dly(0));
        REG_WR_0x10351 : REG32_WRITE generic map(x"000F0FFF" , x"51", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_interb_dly(1));
        REG_WR_0x10352 : REG32_WRITE generic map(x"000F0FFF" , x"52", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_interb_dly(2));
        REG_WR_0x10353 : REG32_WRITE generic map(x"000F0FFF" , x"53", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_interb_dly(3));
        REG_WR_0x10354 : REG32_WRITE generic map(x"000F0FFF" , x"54", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_interb_dly(4));
        REG_WR_0x10355 : REG32_WRITE generic map(x"000F0FFF" , x"55", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_interb_dly(5));
        REG_WR_0x10356 : REG32_WRITE generic map(x"000F0FFF" , x"56", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_interb_dly(6));
        REG_WR_0x10357 : REG32_WRITE generic map(x"000F0FFF" , x"57", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_src_interb_dly(7));

        REG_WR_0x10360 : REG32_WRITE generic map(x"00000FFF" , x"60", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ref_sample_dly(0));
        REG_WR_0x10361 : REG32_WRITE generic map(x"00000FFF" , x"61", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ref_sample_dly(1));
        REG_WR_0x10362 : REG32_WRITE generic map(x"00000FFF" , x"62", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ref_sample_dly(2));
        REG_WR_0x10363 : REG32_WRITE generic map(x"00000FFF" , x"63", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ref_sample_dly(3));
        REG_WR_0x10364 : REG32_WRITE generic map(x"00000FFF" , x"64", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ref_sample_dly(4));
        REG_WR_0x10365 : REG32_WRITE generic map(x"00000FFF" , x"65", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ref_sample_dly(5));
        REG_WR_0x10366 : REG32_WRITE generic map(x"00000FFF" , x"66", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ref_sample_dly(6));
        REG_WR_0x10367 : REG32_WRITE generic map(x"00000FFF" , x"67", x"00000020") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ref_sample_dly(7));

        REG_WR_0x10370 : REG32_WRITE generic map(x"00000FFF" , x"70", x"00000008") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ul_sample_dly(0));
        REG_WR_0x10371 : REG32_WRITE generic map(x"00000FFF" , x"71", x"00000008") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ul_sample_dly(1));
        REG_WR_0x10372 : REG32_WRITE generic map(x"00000FFF" , x"72", x"00000008") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ul_sample_dly(2));
        REG_WR_0x10373 : REG32_WRITE generic map(x"00000FFF" , x"73", x"00000008") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ul_sample_dly(3));
        REG_WR_0x10374 : REG32_WRITE generic map(x"00000FFF" , x"74", x"00000008") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ul_sample_dly(4));
        REG_WR_0x10375 : REG32_WRITE generic map(x"00000FFF" , x"75", x"00000008") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ul_sample_dly(5));
        REG_WR_0x10376 : REG32_WRITE generic map(x"00000FFF" , x"76", x"00000008") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ul_sample_dly(6));
        REG_WR_0x10377 : REG32_WRITE generic map(x"00000FFF" , x"77", x"00000008") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ul_sample_dly(7));

        REG_WR_0x10380 : REG32_WRITE generic map(reg_path_num    , x"80", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pnpc_en    );
        REG_WR_0x10381 : REG32_WRITE generic map(reg_path_num    , x"81", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pnpc_set   );
        REG_WR_0x10382 : REG32_WRITE generic map(reg_path_num_x2 , x"82", x"00005555") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pnpc_mu_sel);

        REG_WR_0x10390 : REG32_WRITE generic map(x"FFFFFFFF" , x"90", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pnpc_setval(0));
        REG_WR_0x10391 : REG32_WRITE generic map(x"FFFFFFFF" , x"91", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pnpc_setval(1));
        REG_WR_0x10392 : REG32_WRITE generic map(x"FFFFFFFF" , x"92", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pnpc_setval(2));
        REG_WR_0x10393 : REG32_WRITE generic map(x"FFFFFFFF" , x"93", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pnpc_setval(3));
        REG_WR_0x10394 : REG32_WRITE generic map(x"FFFFFFFF" , x"94", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pnpc_setval(4));
        REG_WR_0x10395 : REG32_WRITE generic map(x"FFFFFFFF" , x"95", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pnpc_setval(5));
        REG_WR_0x10396 : REG32_WRITE generic map(x"FFFFFFFF" , x"96", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pnpc_setval(6));
        REG_WR_0x10397 : REG32_WRITE generic map(x"FFFFFFFF" , x"97", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pnpc_setval(7));

        REG_WR_0x103A0 : REG32_WRITE generic map(x"FFFFFFFF" , x"A0", x"00000000") port map(rst_synch_cpu, CLK_CPU, wren_pim_03_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_ul_mixer_freq_err_comp_word);

        P_PNPC_DC_IQ_CDC : process(rst_synch_cpu, CLK_CPU) begin
            if (rst_synch_cpu = '1') then
                reg_pnpc_dc_iq <= (others => (others => '0'));
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                for I in 0 to 7 loop
                    if (rden_d1_cpuclk_rpls = '1') then 
                        reg_pnpc_dc_iq(I) <= pnpc_dc_iq(I);
                    else
                        reg_pnpc_dc_iq(I) <= reg_pnpc_dc_iq(I);
                    end if;
                end loop;
            end if;
        end process;

        P_REG_PIM_CTRL_CPUCLK_Read : process(rst_synch_cpu, CLK_CPU) begin
            if (rst_synch_cpu = '1') then
                reg_cpuclk_pimctrl_rdata <= (others => '0');
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                if (rden_d2_cpuclk_rpls = '1') then
                    if (addr_h8 = x"03") then
                        case (addr_l8) is
                            when x"00"  => reg_cpuclk_pimctrl_rdata <= reg_pim_mode_status;  
                            when x"01"  => reg_cpuclk_pimctrl_rdata <= reg_pim_sltb1_mode_status;  
                            when x"02"  => reg_cpuclk_pimctrl_rdata <= reg_pim_sltb2_mode_status;  

                            when x"10"  => reg_cpuclk_pimctrl_rdata <= reg_pim_core_qpoint_n_gidx_ab;  
                            when x"11"  => reg_cpuclk_pimctrl_rdata <= reg_pim_core_qpoint_n_gidx_cd;
                            when x"12"  => reg_cpuclk_pimctrl_rdata <= reg_pim_core_lut_switch;

                            -- when x"20"  => reg_cpuclk_pimctrl_rdata <= reg_pim_core_lut_input_switch_a ;
                            -- when x"21"  => reg_cpuclk_pimctrl_rdata <= reg_pim_core_lut_output_switch_a;
                            -- when x"22"  => reg_cpuclk_pimctrl_rdata <= reg_pim_core_lut_input_switch_b ;
                            -- when x"23"  => reg_cpuclk_pimctrl_rdata <= reg_pim_core_lut_output_switch_b;
                            -- when x"24"  => reg_cpuclk_pimctrl_rdata <= reg_pim_core_lut_input_switch_c ;
                            -- when x"25"  => reg_cpuclk_pimctrl_rdata <= reg_pim_core_lut_output_switch_c;
                            -- when x"26"  => reg_cpuclk_pimctrl_rdata <= reg_pim_core_lut_input_switch_d ;
                            -- when x"27"  => reg_cpuclk_pimctrl_rdata <= reg_pim_core_lut_output_switch_d;
                            when x"2A"  => reg_cpuclk_pimctrl_rdata <= reg_pim_core_lut_depth_sel;
                            when x"2F"  => reg_cpuclk_pimctrl_rdata <= reg_pim_core_lut_rb_test;

                            when x"30"  => reg_cpuclk_pimctrl_rdata <= reg_pim_complex_filter_coef_wren;
                            when x"31"  => reg_cpuclk_pimctrl_rdata <= reg_pim_complex_filter_coef_rden;
                            when x"32"  => reg_cpuclk_pimctrl_rdata <= reg_pim_complex_filter_coef_wrdn;
                            when x"33"  => reg_cpuclk_pimctrl_rdata <= reg_pim_complex_filter_coef_addr;
                            when x"34"  => reg_cpuclk_pimctrl_rdata <= reg_pim_complex_filter_coef_i_wdata;
                            when x"35"  => reg_cpuclk_pimctrl_rdata <= reg_pim_complex_filter_coef_q_wdata;
                            when x"36"  => reg_cpuclk_pimctrl_rdata <= reg_pim_complex_filter_coef_i_rdata;
                            when x"37"  => reg_cpuclk_pimctrl_rdata <= reg_pim_complex_filter_coef_q_rdata;

                            when x"40"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_intrab_dly(0);
                            when x"41"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_intrab_dly(1);
                            when x"42"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_intrab_dly(2);
                            when x"43"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_intrab_dly(3);
                            when x"44"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_intrab_dly(4);
                            when x"45"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_intrab_dly(5);
                            when x"46"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_intrab_dly(6);
                            when x"47"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_intrab_dly(7);

                            when x"50"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_interb_dly(0);
                            when x"51"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_interb_dly(1);
                            when x"52"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_interb_dly(2);
                            when x"53"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_interb_dly(3);
                            when x"54"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_interb_dly(4);
                            when x"55"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_interb_dly(5);
                            when x"56"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_interb_dly(6);
                            when x"57"  => reg_cpuclk_pimctrl_rdata <= reg_pim_src_interb_dly(7);

                            when x"60"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ref_sample_dly(0);
                            when x"61"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ref_sample_dly(1);
                            when x"62"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ref_sample_dly(2);
                            when x"63"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ref_sample_dly(3);
                            when x"64"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ref_sample_dly(4);
                            when x"65"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ref_sample_dly(5);
                            when x"66"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ref_sample_dly(6);
                            when x"67"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ref_sample_dly(7);

                            when x"70"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ul_sample_dly(0);
                            when x"71"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ul_sample_dly(1);
                            when x"72"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ul_sample_dly(2);
                            when x"73"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ul_sample_dly(3);
                            when x"74"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ul_sample_dly(4);
                            when x"75"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ul_sample_dly(5);
                            when x"76"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ul_sample_dly(6);
                            when x"77"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ul_sample_dly(7);

                            when x"80"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_en;
                            when x"81"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_set;
                            when x"82"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_mu_sel;

                            when x"90"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_setval(0);
                            when x"91"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_setval(1);
                            when x"92"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_setval(2);
                            when x"93"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_setval(3);
                            when x"94"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_setval(4);
                            when x"95"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_setval(5);
                            when x"96"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_setval(6);
                            when x"97"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_setval(7);

                            when x"A0"  => reg_cpuclk_pimctrl_rdata <= reg_pim_ul_mixer_freq_err_comp_word;

                            when x"B0"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_dc_iq(0);
                            when x"B1"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_dc_iq(1);
                            when x"B2"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_dc_iq(2);
                            when x"B3"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_dc_iq(3);
                            when x"B4"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_dc_iq(4);
                            when x"B5"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_dc_iq(5);
                            when x"B6"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_dc_iq(6);
                            when x"B7"  => reg_cpuclk_pimctrl_rdata <= reg_pnpc_dc_iq(7);

                            when others => reg_cpuclk_pimctrl_rdata <= (others => '0');
                        end case;
                    else
                        reg_cpuclk_pimctrl_rdata <= (others => '0');
                    end if;
                else
                    reg_cpuclk_pimctrl_rdata <= reg_cpuclk_pimctrl_rdata;
                end if;
            end if;
        end process;

    G_PIM_LUT_Non_Optimized : if (PIMD_BLK_TYPE /= "SELECTABLE") generate begin     -- NON_SELECTABLE PIM LUT REG     

            -- pim_lut_we <= "0000";
            -- pim_lut_re <= "0000";

            P_PIM_LUT_Non_Optimized_WE : process(rst_synch_cpu, CLK_CPU) begin
                if (rst_synch_cpu = '1') then
                    pim_lut_nopt_we <= (others => '0');
                    pim_lut_nopt_re <= (others => '0');
                elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                    if (wren_cpuclk_sh(0) = '1') then
                        case (addr_h8) is
                            when x"60"  => pim_lut_nopt_we <= "00000001"; 
                            when x"61"  => pim_lut_nopt_we <= "00000001"; 
                            when x"62"  => pim_lut_nopt_we <= "00000010"; 
                            when x"63"  => pim_lut_nopt_we <= "00000010"; 
                            when x"64"  => pim_lut_nopt_we <= "00000100"; 
                            when x"65"  => pim_lut_nopt_we <= "00000100"; 
                            when x"66"  => pim_lut_nopt_we <= "00001000"; 
                            when x"67"  => pim_lut_nopt_we <= "00001000"; 
                            when x"68"  => pim_lut_nopt_we <= "00010000"; 
                            when x"69"  => pim_lut_nopt_we <= "00010000"; 
                            when x"6A"  => pim_lut_nopt_we <= "00100000"; 
                            when x"6B"  => pim_lut_nopt_we <= "00100000"; 
                            when x"6C"  => pim_lut_nopt_we <= "01000000"; 
                            when x"6D"  => pim_lut_nopt_we <= "01000000"; 
                            when x"6E"  => pim_lut_nopt_we <= "10000000"; 
                            when x"6F"  => pim_lut_nopt_we <= "10000000"; 
                            when others => pim_lut_nopt_we <= (others => '0'); 
                        end case;
                    else
                        pim_lut_nopt_we <= (others => '0');
                    end if;

                    if (rden_cpuclk_sh(0) = '1') then
                        case (addr_h8) is
                            when x"60"  => pim_lut_nopt_re <= "00000001"; 
                            when x"61"  => pim_lut_nopt_re <= "00000001"; 
                            when x"62"  => pim_lut_nopt_re <= "00000010"; 
                            when x"63"  => pim_lut_nopt_re <= "00000010"; 
                            when x"64"  => pim_lut_nopt_re <= "00000100"; 
                            when x"65"  => pim_lut_nopt_re <= "00000100"; 
                            when x"66"  => pim_lut_nopt_re <= "00001000"; 
                            when x"67"  => pim_lut_nopt_re <= "00001000"; 
                            when x"68"  => pim_lut_nopt_re <= "00010000"; 
                            when x"69"  => pim_lut_nopt_re <= "00010000"; 
                            when x"6A"  => pim_lut_nopt_re <= "00100000"; 
                            when x"6B"  => pim_lut_nopt_re <= "00100000"; 
                            when x"6C"  => pim_lut_nopt_re <= "01000000"; 
                            when x"6D"  => pim_lut_nopt_re <= "01000000"; 
                            when x"6E"  => pim_lut_nopt_re <= "10000000"; 
                            when x"6F"  => pim_lut_nopt_re <= "10000000"; 
                            when others => pim_lut_nopt_re <= (others => '0'); 
                        end case;
                    else
                        pim_lut_nopt_re <= (others => '0');
                    end if;
                end if;
            end process;
            
            pim_core_lut_re       <= pim_lut_nopt_re(TX_ANT_NUM-1 downto 0);

            --------
            G_PIM_LUT_RAM_SET_TX : for I in 0 to (TX_ANT_NUM-1) generate begin
                -- PIM
                P_LUT_WE_CPU_Clocking : process(rst_synch_cpu, CLK_CPU) begin
                    if (rst_synch_cpu = '1') then
                        pim_lut_we_d(I)  <= '0';
                    elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                        pim_lut_we_d(I)  <= pim_lut_nopt_we(I);  
                    end if;
                end process;

                P_PIM_LUT_RAM_Interface : process(rst_synch_cpu, CLK_CPU) begin
                    if (rst_synch_cpu = '1') then
                        pim_core_lut_we(I)    <= '0';              
                        pim_core_lut_addr(I)  <= (others => '0');  
                        pim_core_lut_wdata(I) <= (others => '0');  
                    elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                        pim_core_lut_we(I)    <= pim_lut_nopt_we(I) and (not pim_lut_we_d(I));              
 
                        if (pim_lut_nopt_we(I) = '1') then
                            pim_core_lut_wdata(I) <= WDATA_CPU_IN;  
                        else
                            pim_core_lut_wdata(I) <= pim_core_lut_wdata(I);  
                        end if;

                        pim_core_lut_addr(I)  <= reg_pim_core_lut_depth_sel(5 downto 0) & ADDR_CPU_IN(8 downto 0);  
                    end if;
                end process;
            end generate;

            G_PIM_Core_LUT_Readback_Test_Enable : if (PIM_CORE_LUT_RBTEST = TRUE) generate begin
                P_DL_PIM_LUT_Read : process(rst_synch_cpu, CLK_CPU) begin
                    if (rst_synch_cpu = '1') then
                        pim_lut_rdata <= (others => '0'); 
                    elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                        if (rden_d4_cpuclk_rpls = '1') then
                            case (addr_h8) is
                                when x"60"  => pim_lut_rdata <= pim_core_lut_rdata(0);
                                when x"61"  => pim_lut_rdata <= pim_core_lut_rdata(0);
                                when x"62"  => pim_lut_rdata <= pim_core_lut_rdata(1);
                                when x"63"  => pim_lut_rdata <= pim_core_lut_rdata(1);
                                when x"64"  => pim_lut_rdata <= pim_core_lut_rdata(2);
                                when x"65"  => pim_lut_rdata <= pim_core_lut_rdata(2);
                                when x"66"  => pim_lut_rdata <= pim_core_lut_rdata(3);
                                when x"67"  => pim_lut_rdata <= pim_core_lut_rdata(3);
                                when x"68"  => pim_lut_rdata <= pim_core_lut_rdata(4);
                                when x"69"  => pim_lut_rdata <= pim_core_lut_rdata(4);
                                when x"6A"  => pim_lut_rdata <= pim_core_lut_rdata(5);
                                when x"6B"  => pim_lut_rdata <= pim_core_lut_rdata(5);
                                when x"6C"  => pim_lut_rdata <= pim_core_lut_rdata(6);
                                when x"6D"  => pim_lut_rdata <= pim_core_lut_rdata(6);
                                when x"6E"  => pim_lut_rdata <= pim_core_lut_rdata(7);
                                when x"6F"  => pim_lut_rdata <= pim_core_lut_rdata(7);
                                when others => pim_lut_rdata <= (others => '0');
                            end case;
                        else
                            pim_lut_rdata <= pim_lut_rdata; 
                        end if;
                    end if;
                end process;
            end generate;

            G_PIM_Core_LUT_Readback_Test_Disable : if (PIM_CORE_LUT_RBTEST = FALSE) generate begin
                pim_lut_rdata <= (others => '0'); 
            end generate;

        end generate; -- ~ NON SELECTABLE PIM LUT REG

        G_SELECTABLE_PIM : if (PIMD_BLK_TYPE = "SELECTABLE" ) generate begin -- SELECTABLE PIM

            -- selectable 1
            P_PIM_LUT_Non_Optimized_WE_SLTB : process(rst_synch_cpu, CLK_CPU) begin
                if (rst_synch_cpu = '1') then
                    pim_sltb1_lut_nopt_we <= (others => '0');
                    pim_sltb1_lut_nopt_re <= (others => '0');
                elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                    if (wren_cpuclk_sh(0) = '1') then
                        case (addr_h8) is
                            when x"A0"  => pim_sltb1_lut_nopt_we <= "00000001"; 
                            when x"A1"  => pim_sltb1_lut_nopt_we <= "00000001"; 
                            when x"A2"  => pim_sltb1_lut_nopt_we <= "00000010"; 
                            when x"A3"  => pim_sltb1_lut_nopt_we <= "00000010"; 
                            when x"A4"  => pim_sltb1_lut_nopt_we <= "00000100"; 
                            when x"A5"  => pim_sltb1_lut_nopt_we <= "00000100"; 
                            when x"A6"  => pim_sltb1_lut_nopt_we <= "00001000"; 
                            when x"A7"  => pim_sltb1_lut_nopt_we <= "00001000"; 
                            when x"A8"  => pim_sltb1_lut_nopt_we <= "00010000"; 
                            when x"A9"  => pim_sltb1_lut_nopt_we <= "00010000"; 
                            when x"AA"  => pim_sltb1_lut_nopt_we <= "00100000"; 
                            when x"AB"  => pim_sltb1_lut_nopt_we <= "00100000"; 
                            when x"AC"  => pim_sltb1_lut_nopt_we <= "01000000"; 
                            when x"AD"  => pim_sltb1_lut_nopt_we <= "01000000"; 
                            when x"AE"  => pim_sltb1_lut_nopt_we <= "10000000"; 
                            when x"AF"  => pim_sltb1_lut_nopt_we <= "10000000"; 
                            when others => pim_sltb1_lut_nopt_we <= (others => '0'); 
                        end case;
                    else
                        pim_sltb1_lut_nopt_we <= (others => '0');
                    end if;

                    if (rden_cpuclk_sh(0) = '1') then
                        case (addr_h8) is
                            when x"A0"  => pim_sltb1_lut_nopt_re <= "00000001"; 
                            when x"A1"  => pim_sltb1_lut_nopt_re <= "00000001"; 
                            when x"A2"  => pim_sltb1_lut_nopt_re <= "00000010"; 
                            when x"A3"  => pim_sltb1_lut_nopt_re <= "00000010"; 
                            when x"A4"  => pim_sltb1_lut_nopt_re <= "00000100"; 
                            when x"A5"  => pim_sltb1_lut_nopt_re <= "00000100"; 
                            when x"A6"  => pim_sltb1_lut_nopt_re <= "00001000"; 
                            when x"A7"  => pim_sltb1_lut_nopt_re <= "00001000"; 
                            when x"A8"  => pim_sltb1_lut_nopt_re <= "00010000"; 
                            when x"A9"  => pim_sltb1_lut_nopt_re <= "00010000"; 
                            when x"AA"  => pim_sltb1_lut_nopt_re <= "00100000"; 
                            when x"AB"  => pim_sltb1_lut_nopt_re <= "00100000"; 
                            when x"AC"  => pim_sltb1_lut_nopt_re <= "01000000"; 
                            when x"AD"  => pim_sltb1_lut_nopt_re <= "01000000"; 
                            when x"AE"  => pim_sltb1_lut_nopt_re <= "10000000"; 
                            when x"AF"  => pim_sltb1_lut_nopt_re <= "10000000"; 
                            when others => pim_sltb1_lut_nopt_re <= (others => '0'); 
                        end case;
                    else
                        pim_sltb1_lut_nopt_re <= (others => '0');
                    end if;
                end if;
            end process;
            
            pim_sltb1_core_lut_re <= pim_sltb1_lut_nopt_re(TX_ANT_NUM-1 downto 0);

            -- selectable 2
            P_PIM_LUT_Non_Optimized_WE_SLTB2 : process(rst_synch_cpu, CLK_CPU) begin
                if (rst_synch_cpu = '1') then
                    pim_sltb2_lut_nopt_we <= (others => '0');
                    pim_sltb2_lut_nopt_re <= (others => '0');
                elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                    if (wren_cpuclk_sh(0) = '1') then
                        case (addr_h8) is
                            when x"B0"  => pim_sltb2_lut_nopt_we <= "00000001"; 
                            when x"B1"  => pim_sltb2_lut_nopt_we <= "00000001"; 
                            when x"B2"  => pim_sltb2_lut_nopt_we <= "00000010"; 
                            when x"B3"  => pim_sltb2_lut_nopt_we <= "00000010"; 
                            when x"B4"  => pim_sltb2_lut_nopt_we <= "00000100"; 
                            when x"B5"  => pim_sltb2_lut_nopt_we <= "00000100"; 
                            when x"B6"  => pim_sltb2_lut_nopt_we <= "00001000"; 
                            when x"B7"  => pim_sltb2_lut_nopt_we <= "00001000"; 
                            when x"B8"  => pim_sltb2_lut_nopt_we <= "00010000"; 
                            when x"B9"  => pim_sltb2_lut_nopt_we <= "00010000"; 
                            when x"BA"  => pim_sltb2_lut_nopt_we <= "00100000"; 
                            when x"BB"  => pim_sltb2_lut_nopt_we <= "00100000"; 
                            when x"BC"  => pim_sltb2_lut_nopt_we <= "01000000"; 
                            when x"BD"  => pim_sltb2_lut_nopt_we <= "01000000"; 
                            when x"BE"  => pim_sltb2_lut_nopt_we <= "10000000"; 
                            when x"BF"  => pim_sltb2_lut_nopt_we <= "10000000"; 
                            when others => pim_sltb2_lut_nopt_we <= (others => '0'); 
                        end case;
                    else
                        pim_sltb2_lut_nopt_we <= (others => '0');
                    end if;

                    if (rden_cpuclk_sh(0) = '1') then
                        case (addr_h8) is
                            when x"B0"  => pim_sltb2_lut_nopt_re <= "00000001"; 
                            when x"B1"  => pim_sltb2_lut_nopt_re <= "00000001"; 
                            when x"B2"  => pim_sltb2_lut_nopt_re <= "00000010"; 
                            when x"B3"  => pim_sltb2_lut_nopt_re <= "00000010"; 
                            when x"B4"  => pim_sltb2_lut_nopt_re <= "00000100"; 
                            when x"B5"  => pim_sltb2_lut_nopt_re <= "00000100"; 
                            when x"B6"  => pim_sltb2_lut_nopt_re <= "00001000"; 
                            when x"B7"  => pim_sltb2_lut_nopt_re <= "00001000"; 
                            when x"B8"  => pim_sltb2_lut_nopt_re <= "00010000"; 
                            when x"B9"  => pim_sltb2_lut_nopt_re <= "00010000"; 
                            when x"BA"  => pim_sltb2_lut_nopt_re <= "00100000"; 
                            when x"BB"  => pim_sltb2_lut_nopt_re <= "00100000"; 
                            when x"BC"  => pim_sltb2_lut_nopt_re <= "01000000"; 
                            when x"BD"  => pim_sltb2_lut_nopt_re <= "01000000"; 
                            when x"BE"  => pim_sltb2_lut_nopt_re <= "10000000"; 
                            when x"BF"  => pim_sltb2_lut_nopt_re <= "10000000"; 
                            when others => pim_sltb2_lut_nopt_re <= (others => '0'); 
                        end case;
                    else
                        pim_sltb2_lut_nopt_re <= (others => '0');
                    end if;
                end if;
            end process;

            pim_sltb2_core_lut_re <= pim_sltb2_lut_nopt_re(TX_ANT_NUM-1 downto 0);
            ---

            G_ANT_MAP_CPUCLK : for I in 0 to (TX_ANT_NUM-1) generate begin

                -- selectable 1
                P_LUT_WE_CPU_Clocking_SLTB1 : process(rst_synch_cpu, CLK_CPU) begin
                    if (rst_synch_cpu = '1') then
                        pim_sltb1_lut_we_d(I)  <= '0';
                    elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                        pim_sltb1_lut_we_d(I)  <= pim_sltb1_lut_nopt_we(I);
                    end if;
                end process;

                P_PIM_LUT_RAM_Interface_SLTB1 : process(rst_synch_cpu, CLK_CPU) begin
                    if (rst_synch_cpu = '1') then
                        pim_sltb1_core_lut_we(I)    <= '0';              
                        pim_sltb1_core_lut_addr(I)  <= (others => '0');  
                        pim_sltb1_core_lut_wdata(I) <= (others => '0');  
                    elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                        pim_sltb1_core_lut_we(I)    <= pim_sltb1_lut_nopt_we(I) and (not pim_sltb1_lut_we_d(I));              
 
                        if (pim_sltb1_lut_nopt_we(I) = '1') then
                            pim_sltb1_core_lut_wdata(I) <= WDATA_CPU_IN;  
                        else
                            pim_sltb1_core_lut_wdata(I) <= pim_sltb1_core_lut_wdata(I);  
                        end if;

                        pim_sltb1_core_lut_addr(I)  <= reg_pim_sltb1_core_lut_depth_sel(5 downto 0) & ADDR_CPU_IN(8 downto 0);  
                    end if;
                end process;
                -- selectable 2
                P_LUT_WE_CPU_Clocking_SLTB2 : process(rst_synch_cpu, CLK_CPU) begin
                    if (rst_synch_cpu = '1') then
                        pim_sltb2_lut_we_d(I)  <= '0';
                    elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                        pim_sltb2_lut_we_d(I)  <= pim_sltb2_lut_nopt_we(I);  
                    end if;
                end process;

                P_PIM_LUT_RAM_Interface_SLTB2 : process(rst_synch_cpu, CLK_CPU) begin
                    if (rst_synch_cpu = '1') then
                        pim_sltb2_core_lut_we(I)    <= '0';              
                        pim_sltb2_core_lut_addr(I)  <= (others => '0');  
                        pim_sltb2_core_lut_wdata(I) <= (others => '0');  
                    elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                        pim_sltb2_core_lut_we(I)    <= pim_sltb2_lut_nopt_we(I) and (not pim_sltb2_lut_we_d(I));              
 
                        if (pim_sltb2_lut_nopt_we(I) = '1') then
                            pim_sltb2_core_lut_wdata(I) <= WDATA_CPU_IN;  
                        else
                            pim_sltb2_core_lut_wdata(I) <= pim_sltb2_core_lut_wdata(I);  
                        end if;

                        pim_sltb2_core_lut_addr(I)  <= reg_pim_sltb2_core_lut_depth_sel(5 downto 0) & ADDR_CPU_IN(8 downto 0);  
                    end if;
                end process;

            end generate;

            -- peripheral REG
            P_WR_RD_Enable_Strobe_PIM_CLK : process(rst_synch_pim, CLK_PIMD) begin
                if (rst_synch_pim = '1') then
                    wren_pimclk_sh   <= (others => '0'); 
                    wren_pimclk_rpls <= '0'; 
                    rden_pimclk_sh   <= (others => '0'); 
                    rden_pimclk_rpls <= '0'; 
                elsif (CLK_PIMD'event) and (CLK_PIMD = '1') then
                    wren_pimclk_sh   <= wren_pimclk_sh(4 downto 0) & WREN_CPU_IN; 
                    wren_pimclk_rpls <= wren_pimclk_sh(4) and (not wren_pimclk_sh(5)); 
                    rden_pimclk_sh   <= rden_pimclk_sh(3 downto 0) & RDEN_CPU_IN; 
                    rden_pimclk_rpls <= rden_pimclk_sh(3) and (not rden_pimclk_sh(4)); 
                end if;
            end process;
            P_REG_WREN_PIM_CLK : process(rst_synch_pim, CLK_PIMD) begin
                if (rst_synch_pim = '1') then	
                    wren_73_pimclk <= '0';
                    wren_74_pimclk <= '0';
                    wren_75_pimclk <= '0';
                elsif (CLK_PIMD'event) and (CLK_PIMD = '1') then
                    if (wren_pimclk_rpls = '1') then  
                        if (addr_h8 = x"73") then
                            wren_73_pimclk <= '1';
                        else
                            wren_73_pimclk <= '0'; 
                        end if;
                        
                        if (addr_h8 = x"74") then
                            wren_74_pimclk <= '1';
                        else
                            wren_74_pimclk <= '0'; 
                        end if;
                        
                        if (addr_h8 = x"75") then
                            wren_75_pimclk <= '1';
                        else
                            wren_75_pimclk <= '0'; 
                        end if;
                    else
                        wren_75_pimclk <= '0'; 
                    end if;
                end if;
            end process;

            REG_WR_0x17010 : REG32_WRITE generic map(x"FFFFFFFF", x"10", x"55550000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb1_core_gain_qpoint_ab     );
            REG_WR_0x17011 : REG32_WRITE generic map(x"FFFFFFFF", x"11", x"55550000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb1_core_gain_qpoint_cd     );
            REG_WR_0x17012 : REG32_WRITE generic map(x"000000FF", x"12", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb1_core_lut_upt_switch     );
            REG_WR_0x17013 : REG32_WRITE generic map(x"0000003F", x"13", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb1_core_lut_depth_sel      );
            REG_WR_0x17020 : REG32_WRITE generic map(x"00000FFF", x"20", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb1_core_out_dly(0)      );
            REG_WR_0x17021 : REG32_WRITE generic map(x"00000FFF", x"21", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb1_core_out_dly(1)      );
            REG_WR_0x17022 : REG32_WRITE generic map(x"00000FFF", x"22", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb1_core_out_dly(2)      );
            REG_WR_0x17023 : REG32_WRITE generic map(x"00000FFF", x"23", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb1_core_out_dly(3)      );
            REG_WR_0x17024 : REG32_WRITE generic map(x"00000FFF", x"24", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb1_core_out_dly(4)      );
            REG_WR_0x17025 : REG32_WRITE generic map(x"00000FFF", x"25", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb1_core_out_dly(5)      );
            REG_WR_0x17026 : REG32_WRITE generic map(x"00000FFF", x"26", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb1_core_out_dly(6)      );
            REG_WR_0x17027 : REG32_WRITE generic map(x"00000FFF", x"27", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb1_core_out_dly(7)      );
                                                                      
            REG_WR_0x17030 : REG32_WRITE generic map(x"FFFFFFFF", x"30", x"55550000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb2_core_gain_qpoint_ab     );
            REG_WR_0x17031 : REG32_WRITE generic map(x"FFFFFFFF", x"31", x"55550000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb2_core_gain_qpoint_cd     );
            REG_WR_0x17032 : REG32_WRITE generic map(x"000000FF", x"32", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb2_core_lut_upt_switch     );
            REG_WR_0x17033 : REG32_WRITE generic map(x"0000003F", x"33", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb2_core_lut_depth_sel      );
            REG_WR_0x17040 : REG32_WRITE generic map(x"00000FFF", x"40", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb2_core_out_dly(0)      );
            REG_WR_0x17041 : REG32_WRITE generic map(x"00000FFF", x"41", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb2_core_out_dly(1)      );
            REG_WR_0x17042 : REG32_WRITE generic map(x"00000FFF", x"42", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb2_core_out_dly(2)      );
            REG_WR_0x17043 : REG32_WRITE generic map(x"00000FFF", x"43", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb2_core_out_dly(3)      );
            REG_WR_0x17044 : REG32_WRITE generic map(x"00000FFF", x"44", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb2_core_out_dly(4)      );
            REG_WR_0x17045 : REG32_WRITE generic map(x"00000FFF", x"45", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb2_core_out_dly(5)      );
            REG_WR_0x17046 : REG32_WRITE generic map(x"00000FFF", x"46", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb2_core_out_dly(6)      );
            REG_WR_0x17047 : REG32_WRITE generic map(x"00000FFF", x"47", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb2_core_out_dly(7)      );
                                                                      
            REG_WR_0x17050 : REG32_WRITE generic map(x"00000001", x"50", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_intra_nco_wren           );
            REG_WR_0x17051 : REG32_WRITE generic map(x"FFFFFFFF", x"51", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_intra_nco_word           );
            REG_WR_0x17052 : REG32_WRITE generic map(x"00000001", x"52", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_inter1_nco_wren          );
            REG_WR_0x17053 : REG32_WRITE generic map(x"FFFFFFFF", x"53", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_inter1_nco_word          );
            REG_WR_0x17054 : REG32_WRITE generic map(x"00000001", x"54", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_inter2_nco_wren          );
            REG_WR_0x17055 : REG32_WRITE generic map(x"FFFFFFFF", x"55", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_inter2_nco_word          );
            -- REG_WR_0x17060 : REG32_WRITE generic map(x"00000001", x"60", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_im3gen_intra_sel         );
			-- REG_WR_0x17061 : REG32_WRITE generic map(x"00000003", x"61", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_im3gen_inter1_sel        );
            -- REG_WR_0x17062 : REG32_WRITE generic map(x"00000003", x"62", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_im3gen_inter2_sel        );
			REG_WR_0x17060 : REG32_WRITE generic map(x"11111111", x"60", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_im3gen_intra_sel         );
            REG_WR_0x17061 : REG32_WRITE generic map(x"33333333", x"61", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_im3gen_inter1_sel        );
            REG_WR_0x17062 : REG32_WRITE generic map(x"33333333", x"62", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_im3gen_inter2_sel        );
            REG_WR_0x17063 : REG32_WRITE generic map(x"00000003", x"63", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_quarter_shift_intra_sel  );
            REG_WR_0x17064 : REG32_WRITE generic map(x"00000003", x"64", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_quarter_shift_inter1_sel );
            REG_WR_0x17065 : REG32_WRITE generic map(x"00000003", x"65", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_quarter_shift_inter2_sel );

            REG_WR_0x17066 : REG32_WRITE generic map(x"00000003", x"66", x"00000000") port map(rst_synch_pim, CLK_PIMD, wren_pim_70_cpuclk_rpls, addr_l8, WDATA_CPU_IN, reg_pim_sltb_bit_shift_sel            );

            
            P_PERI_REG_Read_PIM_CLK : process(rst_synch_pim, CLK_PIMD) begin
                if (rst_synch_pim= '1') then
                    reg_sltb_cpuclk_pimctrl_rdata <= (others => '0');
                elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                    if (rden_d4_cpuclk_rpls = '1') then 
                        if (addr_h8 = x"70") then 
                            case (addr_l8) is
                                when x"10"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb1_core_gain_qpoint_ab       ;
                                when x"11"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb1_core_gain_qpoint_cd       ;
                                when x"12"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb1_core_lut_upt_switch       ;
                                when x"13"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb1_core_lut_depth_sel        ;
                                when x"20"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb1_core_out_dly(0)           ;
                                when x"21"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb1_core_out_dly(1)           ;
                                when x"22"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb1_core_out_dly(2)           ;
                                when x"23"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb1_core_out_dly(3)           ;
                                when x"24"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb1_core_out_dly(4)           ;
                                when x"25"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb1_core_out_dly(5)           ;
                                when x"26"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb1_core_out_dly(6)           ;
                                when x"27"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb1_core_out_dly(7)           ;

                                when x"30"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb2_core_gain_qpoint_ab       ;
                                when x"31"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb2_core_gain_qpoint_cd       ;
                                when x"32"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb2_core_lut_upt_switch       ;
                                when x"33"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb2_core_lut_depth_sel        ;
                                when x"40"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb2_core_out_dly(0)           ;
                                when x"41"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb2_core_out_dly(1)           ;
                                when x"42"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb2_core_out_dly(2)           ;
                                when x"43"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb2_core_out_dly(3)           ;
                                when x"44"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb2_core_out_dly(4)           ;
                                when x"45"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb2_core_out_dly(5)           ;
                                when x"46"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb2_core_out_dly(6)           ;
                                when x"47"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb2_core_out_dly(7)           ;

                                when x"50"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb_intra_nco_wren             ;
                                when x"51"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb_intra_nco_word             ;
                                when x"52"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb_inter1_nco_wren            ;
                                when x"53"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb_inter1_nco_word            ;
                                when x"54"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb_inter2_nco_wren            ;
                                when x"55"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb_inter2_nco_word            ;
                                when x"60"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb_im3gen_intra_sel           ;
                                when x"61"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb_im3gen_inter1_sel          ;
                                when x"62"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb_im3gen_inter2_sel          ;
                                when x"63"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb_quarter_shift_intra_sel    ;
                                when x"64"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb_quarter_shift_inter1_sel   ;
                                when x"65"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb_quarter_shift_inter2_sel   ;
                                when x"66"  => reg_sltb_cpuclk_pimctrl_rdata <= reg_pim_sltb_bit_shift_sel              ;
                                when others => reg_sltb_cpuclk_pimctrl_rdata <= (others => '0'); 
                            end case;
                        else
                            reg_sltb_cpuclk_pimctrl_rdata <= (others => '0');
                        end if;
                    else
                        reg_sltb_cpuclk_pimctrl_rdata <= reg_sltb_cpuclk_pimctrl_rdata ;
                    end if;
                end if;
            end process;
            -- ~ peripheral REG

        end generate;

    end generate; -- ~ SELECTABLE PIM

    G_PIM_CORE_Not_Implementation : if (PIM_IMPLEMENTATION = FALSE) generate begin 

        wren_pim_03_cpuclk                  <= '0'; 
        wren_pim_03_cpuclk_sh               <= (others => '0'); 
        wren_pim_03_cpuclk_rpls             <= '0'; 
        wren_pim_70_cpuclk                  <= '0'; 
        wren_pim_70_cpuclk_sh               <= (others => '0'); 
        wren_pim_70_cpuclk_rpls             <= '0'; 

        reg_pim_core_gidx_cdc_strb          <= '0'; 
        reg_pim_core_qpoint_cdc_strb        <= '0'; 
        reg_pim_sltb1_core_gidx_cdc_strb    <= '0'; 
        reg_pim_sltb1_core_qpoint_cdc_strb  <= '0'; 
        reg_pim_sltb2_core_gidx_cdc_strb    <= '0'; 
        reg_pim_sltb2_core_qpoint_cdc_strb  <= '0'; 

        reg_pim_core_qpoint_n_gidx_ab       <= (others => '0');
        reg_pim_core_qpoint_n_gidx_cd       <= (others => '0');
        reg_pim_core_lut_depth_sel          <= (others => '0');
        reg_pim_core_lut_switch             <= (others => '0');

        -- reg_pim_core_lut_switch_cdc_strb_a  <= '0'; 
        -- reg_pim_core_lut_input_switch_a     <= (others => '0'); 
        -- reg_pim_core_lut_output_switch_a    <= (others => '0'); 

        -- reg_pim_core_lut_switch_cdc_strb_b  <= '0'; 
        -- reg_pim_core_lut_input_switch_b     <= (others => '0'); 
        -- reg_pim_core_lut_output_switch_b    <= (others => '0'); 

        -- reg_pim_core_lut_switch_cdc_strb_c  <= '0'; 
        -- reg_pim_core_lut_input_switch_c     <= (others => '0'); 
        -- reg_pim_core_lut_output_switch_c    <= (others => '0'); 

        -- reg_pim_core_lut_switch_cdc_strb_d  <= '0'; 
        -- reg_pim_core_lut_input_switch_d     <= (others => '0'); 
        -- reg_pim_core_lut_output_switch_d    <= (others => '0'); 
        
        reg_pim_core_lut_rb_test            <= (others => '0'); 

        reg_pim_complex_filter_coef_wren    <= (others => '0'); 
        reg_pim_complex_filter_coef_rden    <= (others => '0'); 
        reg_pim_complex_filter_coef_wrdn    <= (others => '0'); 
        reg_pim_complex_filter_coef_addr    <= (others => '0'); 
        reg_pim_complex_filter_coef_i_wdata <= (others => '0'); 
        reg_pim_complex_filter_coef_q_wdata <= (others => '0'); 

        reg_pim_src_intrab_dly_strb         <= '0'; 
        reg_pim_src_intrab_dly              <= (others => (others => '0')); 
        
        reg_pim_src_interb_dly_strb         <= '0'; 
        reg_pim_src_interb_dly              <= (others => (others => '0')); 
        
        reg_pim_ref_dly_strb                <= '0'; 
        reg_pim_ref_sample_dly              <= (others => (others => '0')); 
        
        reg_pim_ul_dly_strb                 <= '0'; 
        reg_pim_ul_sample_dly               <= (others => (others => '0')); 

        reg_pnpc_en                         <= (others => '0'); 
        reg_pnpc_set                        <= (others => '0'); 

        reg_pnpc_mu_sel_strb                <= '0'; 
        reg_pnpc_mu_sel                     <= (others => '0'); 

        reg_pnpc_setval_strb                <= '0'; 
        reg_pnpc_setval                     <= (others => (others => '0')); 

        reg_pim_ul_mixer_freq_err_comp_strb <= '0';                      
        reg_pim_ul_mixer_freq_err_comp_word <= (others => '0');

        -- pim_lut_we                          <= (others => '0');
        -- pim_lut_re                          <= (others => '0');
        pim_core_lut_we                     <= (others => '0');             
        pim_core_lut_re                     <= (others => '0');
        pim_core_lut_addr                   <= (others => (others => '0')); 
        pim_core_lut_wdata                  <= (others => (others => '0')); 

        pim_sltb1_lut_we_d                  <= (others => '0');  
        pim_sltb1_core_lut_we               <= (others => '0');             
        pim_sltb1_core_lut_re               <= (others => '0');
        pim_sltb1_core_lut_addr             <= (others => (others => '0')); 
        pim_sltb1_core_lut_wdata            <= (others => (others => '0')); 
        pim_sltb2_lut_we_d                  <= (others => '0');
        pim_sltb2_core_lut_we               <= (others => '0');             
        pim_sltb2_core_lut_re               <= (others => '0');
        pim_sltb2_core_lut_addr             <= (others => (others => '0')); 
        pim_sltb2_core_lut_wdata            <= (others => (others => '0')); 

        reg_cpuclk_pimctrl_rdata            <= (others => '0');
        pim_lut_rdata                       <= (others => '0'); 
        -- selectable pim
        reg_pim_sltb1_core_gain_qpoint_ab       <= (others => '0');  
        reg_pim_sltb1_core_gain_qpoint_cd       <= (others => '0');  
        reg_pim_sltb1_core_lut_upt_switch       <= (others => '0');  
        reg_pim_sltb1_core_lut_depth_sel        <= (others => '0');  
        reg_pim_sltb1_core_out_dly              <= (others=> (others => '0'));   

        reg_pim_sltb2_core_gain_qpoint_ab       <= (others => '0');  
        reg_pim_sltb2_core_gain_qpoint_cd       <= (others => '0');  
        reg_pim_sltb2_core_lut_upt_switch       <= (others => '0');  
        reg_pim_sltb2_core_lut_depth_sel        <= (others => '0');  
        reg_pim_sltb2_core_out_dly              <= (others=> (others => '0'));   

        reg_pim_sltb_intra_nco_wren             <= (others => '0');  
        reg_pim_sltb_intra_nco_word             <= (others => '0');  
        reg_pim_sltb_inter1_nco_wren            <= (others => '0');  
        reg_pim_sltb_inter1_nco_word            <= (others => '0');  
        reg_pim_sltb_inter2_nco_wren            <= (others => '0');  
        reg_pim_sltb_inter2_nco_word            <= (others => '0');  
        reg_pim_sltb_im3gen_intra_sel           <= (others => '0');  
        reg_pim_sltb_im3gen_inter1_sel          <= (others => '0');  
        reg_pim_sltb_im3gen_inter2_sel          <= (others => '0');  
        reg_pim_sltb_quarter_shift_intra_sel    <= (others => '0');  
        reg_pim_sltb_quarter_shift_inter1_sel   <= (others => '0');  
        reg_pim_sltb_quarter_shift_inter2_sel   <= (others => '0');  

    end generate;


-- *************************************************************************************
-- SMART_CAPTURE Contorl 
-- *************************************************************************************
    G_SMART_CAPTURE_Implementation : if (SC_IMPLEMENTATION = TRUE) generate begin 

        P_WR_RD_Enable_Strobe_SC_CLK : process(rst_synch_sc, CLK_SC) begin
            if (rst_synch_sc = '1') then
                wren_scclk_sh   <= (others => '0'); 
                wren_scclk_rpls <= '0'; 
                rden_scclk_sh   <= (others => '0'); 
                rden_scclk_rpls <= '0'; 
            elsif (CLK_SC'event) and (CLK_SC = '1') then
                wren_scclk_sh   <= wren_scclk_sh(4 downto 0) & WREN_CPU_IN; 
                wren_scclk_rpls <= wren_scclk_sh(4) and (not wren_scclk_sh(5)); 
                rden_scclk_sh   <= rden_scclk_sh(3 downto 0) & RDEN_CPU_IN; 
                rden_scclk_rpls <= rden_scclk_sh(3) and (not rden_scclk_sh(4)); 
            end if;
        end process;

        P_SC_REG_WREN_DPD_CLK : process(rst_synch_sc, CLK_SC) begin
            if (rst_synch_sc = '1') then	
                wren_sc_01_dpdclk    <= '0'; 
                wren_sc_01_dpdclk_sh <= (others => '0');
            elsif (CLK_SC'event) and (CLK_SC = '1') then
                if (wren_scclk_rpls = '1') then  
                    if (addr_h8 = x"01") then
                        wren_sc_01_dpdclk <= '1'; 
                    else
                        wren_sc_01_dpdclk <= '0'; 
                    end if;
                else
                    wren_sc_01_dpdclk <= '0'; 
                end if;

                wren_sc_01_dpdclk_sh <= wren_sc_01_dpdclk_sh(3 downto 0)&wren_sc_01_dpdclk;
            end if;
        end process;
         
        wren_sc_cdc_strb <= wren_sc_01_dpdclk_sh(4) or wren_sc_01_dpdclk_sh(3) or wren_sc_01_dpdclk_sh(2) or wren_sc_01_dpdclk_sh(1) or wren_sc_01_dpdclk_sh(0);

        P_SC_PATH_SEL_CDC_STRB : process(rst_synch_sc, CLK_SC) begin
            if (rst_synch_sc = '1') then
                sc_path_sel_strb <= '0';
            elsif (CLK_SC'event) and (CLK_SC = '1') then
                if (addr_l8 = x"06") then
                    sc_path_sel_strb <= wren_sc_cdc_strb;
                else
                    sc_path_sel_strb <= '0';
                end if;
            end if;
        end process;

        P_SC_REG_WREN_CPU_CLK : process(rst_synch_cpu, CLK_CPU) begin
            if (rst_synch_cpu = '1') then
                wren_sc_01_cpuclk <= '0';
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                if (wren_cpuclk_rpls = '1') then
                    if (addr_h8 = x"01") then
                        wren_sc_01_cpuclk <= '1';
                    else
                        wren_sc_01_cpuclk <= '0';
                    end if;
                else
                    wren_sc_01_cpuclk <= '0';
                end if; 
            end if;
        end process;

        REG_WR_0x10100 : REG32_WRITE generic map(x"00000001", x"00", x"00000000") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_control         );
        REG_WR_0x10102 : REG32_WRITE generic map(x"00000001", x"02", x"00000000") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_cap_size        );
        REG_WR_0x10103 : REG32_WRITE generic map(x"00000001", x"03", x"00000000") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_mode            );
        REG_WR_0x10104 : REG32_WRITE generic map(x"00000001", x"04", x"00000000") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_force           );
        REG_WR_0x10105 : REG32_WRITE generic map(x"00000001", x"05", x"00000000") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_tdd_mode        );
        REG_WR_0x10106 : REG32_WRITE generic map(x"0000001F", x"06", x"00000000") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_path_sel        );
        REG_WR_0x10107 : REG32_WRITE generic map(x"00000007", x"07", x"00000000") port map(rst_synch_sc, CLK_CPU, wren_sc_01_cpuclk, addr_l8, WDATA_CPU_IN, reg_sc_cap_memory_sel  );
        REG_WR_0x10108 : REG32_WRITE generic map(x"000003FF", x"08", x"0000003E") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_dpd_hc_latency  );
        REG_WR_0x10109 : REG32_WRITE generic map(x"000003FF", x"09", x"0000012C") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_fb_latency      );
        REG_WR_0x1010A : REG32_WRITE generic map(x"000003FF", x"0A", x"0000003E") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_ref_latency     );
        REG_WR_0x1010B : REG32_WRITE generic map(x"003FFFFF", x"0B", x"00000000") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_cap_off_start   );
        REG_WR_0x1010C : REG32_WRITE generic map(x"003FFFFF", x"0C", x"00000000") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_cap_off_stop    );
        REG_WR_0x1010D : REG32_WRITE generic map(x"003FFFFF", x"0D", x"00001000") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_static_position );
        REG_WR_0x1010E : REG32_WRITE generic map(x"000001FF", x"0E", x"000000FF") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_static_length   );
        REG_WR_0x1010F : REG32_WRITE generic map(x"0000FFFF", x"0F", x"00007000") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_max_cur_bo_gain );
        REG_WR_0x10110 : REG32_WRITE generic map(x"0000FFFF", x"10", x"00007800") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_max_peak_bo_gain);
        REG_WR_0x10111 : REG32_WRITE generic map(x"000003FF", x"11", x"00000100") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_debouncing_time );
        REG_WR_0x1011F : REG32_WRITE generic map(x"00030003", x"1F", x"00000000") port map(rst_synch_sc, CLK_SC , wren_sc_01_dpdclk, addr_l8, WDATA_CPU_IN, reg_sc_pim_dbg_path_sel);

        P_SC_REG_Read_DPD_CLK : process(rst_synch_sc, CLK_SC) begin
            if (rst_synch_sc = '1') then
                reg_sc_ctrl_rdata <= (others => '0');
            elsif (CLK_SC'event) and (CLK_SC = '1') then
                if (rden_scclk_rpls = '1') then 
                    if (addr_h8 = x"01") then 
                        case (addr_l8) is
                            when x"00"  => reg_sc_ctrl_rdata <= reg_sc_control; 
                            when x"01"  => reg_sc_ctrl_rdata <= zeros(RDATA_WIDTH-1 downto  1) & reg_sc_complete_flag; 
                            when x"02"  => reg_sc_ctrl_rdata <= reg_sc_cap_size; 
                            when x"03"  => reg_sc_ctrl_rdata <= reg_sc_mode; 
                            when x"04"  => reg_sc_ctrl_rdata <= reg_sc_force; 
                            when x"05"  => reg_sc_ctrl_rdata <= reg_sc_tdd_mode; 
                            when x"06"  => reg_sc_ctrl_rdata <= reg_sc_path_sel; 
                            when x"08"  => reg_sc_ctrl_rdata <= reg_sc_dpd_hc_latency; 
                            when x"09"  => reg_sc_ctrl_rdata <= reg_sc_fb_latency; 
                            when x"0A"  => reg_sc_ctrl_rdata <= reg_sc_ref_latency; 
                            when x"0B"  => reg_sc_ctrl_rdata <= reg_sc_cap_off_start; 
                            when x"0C"  => reg_sc_ctrl_rdata <= reg_sc_cap_off_stop; 
                            when x"0D"  => reg_sc_ctrl_rdata <= reg_sc_static_position; 
                            when x"0E"  => reg_sc_ctrl_rdata <= reg_sc_static_length; 
                            when x"0F"  => reg_sc_ctrl_rdata <= reg_sc_max_cur_bo_gain; 
                            when x"10"  => reg_sc_ctrl_rdata <= reg_sc_max_peak_bo_gain; 
                            when x"11"  => reg_sc_ctrl_rdata <= reg_sc_debouncing_time; 
                            when x"1F"  => reg_sc_ctrl_rdata <= reg_sc_pim_dbg_path_sel; 
                            when x"20"  => reg_sc_ctrl_rdata <= reg_sc_sub_pwr; 
                            when x"21"  => reg_sc_ctrl_rdata <= reg_sc_sub_peak; 
                            when x"22"  => reg_sc_ctrl_rdata <= zeros(RDATA_WIDTH-1 downto 13) & reg_sc_sub_peak_num; 
                            when x"23"  => reg_sc_ctrl_rdata <= reg_sc_time_index; 
                            when others => reg_sc_ctrl_rdata <= (others => '0'); 
                        end case;
                    else
                        reg_sc_ctrl_rdata <= (others => '0');
                    end if;
                else
                    reg_sc_ctrl_rdata <= reg_sc_ctrl_rdata ;
                end if;
            end if;
        end process;

        P_SC_REG_Read_CPU_CLK : process(rst_synch_cpu, CLK_CPU) begin
            if (rst_synch_cpu = '1') then
                reg_cpuclk_sc_rdata <= (others => '0'); 
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                if (rden_d2_cpuclk_rpls = '1') then
                    if (addr_h8 = x"01") then
                        if (addr_l8 = x"07") then
                            reg_cpuclk_sc_rdata <= reg_sc_cap_memory_sel; 
                        else
                            reg_cpuclk_sc_rdata <= (others => '0'); 
                        end if;
                    else
                        reg_cpuclk_sc_rdata <= (others => '0'); 
                    end if;
                else
                    reg_cpuclk_sc_rdata <= reg_cpuclk_sc_rdata; 
                end if;
            end if;
        end process;

        P_SC_Read_Enable : process(rst_synch_cpu, CLK_CPU) begin
            if (rst_synch_cpu = '1') then
                sc_mem_rden    <= '0';           
                sc_mem_rden_d1 <= '0';
                sc_mem_raddr   <= (others => '0');
                sc_mem_rdata   <= (others => '0');
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then 
                -- if (RDEN_CPU_IN = '1') and (ADDR_CPU_IN(15) = '1') then
                if (RDEN_CPU_IN = '1') and ( ADDR_CPU_IN(15 downto 13) = "100" ) then
                    sc_mem_rden  <= '1';           
                    sc_mem_rdata <= sc_capture_mem_rdata;
                else
                    sc_mem_rden  <= '0';           
                    sc_mem_rdata <= (others => '0');
                end if;

		if (sc_mem_rden = '1') then
                    sc_mem_raddr <= ADDR_CPU_IN(12 downto 0);
                else
                    sc_mem_raddr <= sc_mem_raddr;
                end if;

                sc_mem_rden_d1 <= sc_mem_rden;
            end if;
        end process;

    end generate;

    G_SMART_CAPTURE_Not_Implementation : if (SC_IMPLEMENTATION = FALSE) generate begin 

        wren_sc_01_dpdclk       <= '0'; 
        wren_sc_01_cpuclk       <= '0';

        wren_sc_01_dpdclk_sh    <= (others => '0');
        wren_sc_cdc_strb        <= '0';
        sc_path_sel_strb        <= '0';

        reg_sc_control          <= (others => '0'); 
        reg_sc_cap_size         <= (others => '0');
        reg_sc_mode             <= (others => '0');
        reg_sc_force            <= (others => '0');
        reg_sc_tdd_mode         <= (others => '0');
        reg_sc_path_sel         <= (others => '0'); 
        reg_sc_cap_memory_sel   <= (others => '0'); 
        reg_sc_dpd_hc_latency   <= (others => '0');           
        reg_sc_fb_latency       <= (others => '0');           
        reg_sc_ref_latency      <= (others => '0');      

        reg_sc_cap_off_start    <= (others => '0'); 
        reg_sc_cap_off_stop     <= (others => '0'); 
        reg_sc_static_position  <= (others => '0'); 
        reg_sc_static_length    <= (others => '0'); 
        reg_sc_max_cur_bo_gain  <= (others => '0'); 
        reg_sc_max_peak_bo_gain <= (others => '0'); 
        reg_sc_debouncing_time  <= (others => '0');
        reg_sc_pim_dbg_path_sel <= (others => '0');  

        reg_sc_ctrl_rdata       <= (others => '0');
	
        sc_mem_rden             <= '0';
        sc_mem_raddr            <= (others => '0');
        sc_mem_rdata            <= (others => '0');

    end generate;

-- *************************************************************************************
-- SSD Contorl 
-- *************************************************************************************
    G_RX_SSD_Implementation : if (RX_SSD_IMPLEMENTATION = TRUE) generate begin 
        P_WR_RD_Enable_Strobe_SSD_CLK : process(rst_synch_sc, CLK_SC) begin
            if (rst_synch_sc = '1') then
                wren_ssdclk_sh   <= (others => '0'); 
                wren_ssdclk_rpls <= '0'; 
                rden_ssdclk_sh   <= (others => '0'); 
                rden_ssdclk_rpls <= '0'; 
            elsif (CLK_SC'event) and (CLK_SC = '1') then
                wren_ssdclk_sh   <= wren_ssdclk_sh(4 downto 0) & WREN_CPU_IN; 
                wren_ssdclk_rpls <= wren_ssdclk_sh(4) and (not wren_ssdclk_sh(5)); 
                rden_ssdclk_sh   <= rden_ssdclk_sh(3 downto 0) & RDEN_CPU_IN; 
                rden_ssdclk_rpls <= rden_ssdclk_sh(3) and (not rden_ssdclk_sh(4)); 
            end if;
        end process;
        P_SSD_REG_WREN_DPD_CLK : process(rst_synch_sc, CLK_SC) begin
            if (rst_synch_sc = '1') then	
                wren_ssd_05_dpdclk <= '0';
            elsif (CLK_SC'event) and (CLK_SC = '1') then
                if (wren_ssdclk_rpls = '1') then  
                    if (addr_h8 = x"05") then
                        wren_ssd_05_dpdclk <= '1';
                    else
                        wren_ssd_05_dpdclk <= '0'; 
                    end if;
                else
                    wren_ssd_05_dpdclk <= '0'; 
                end if;
            end if;
        end process;
        REG_WR_0x10500 : REG32_WRITE generic map(x"0000001F", x"00", x"00000000") port map(rst_synch_sc, CLK_SC, wren_ssd_05_dpdclk, addr_l8, WDATA_CPU_IN, reg_ssd_path_sel         );
        REG_WR_0x10501 : REG32_WRITE generic map(x"00000001", x"01", x"00000000") port map(rst_synch_sc, CLK_SC, wren_ssd_05_dpdclk, addr_l8, WDATA_CPU_IN, reg_ssd_ctrl             );
        REG_WR_0x10502 : REG32_WRITE generic map(x"000003FF", x"02", x"00000200") port map(rst_synch_sc, CLK_SC, wren_ssd_05_dpdclk, addr_l8, WDATA_CPU_IN, reg_ssd_period           );
        REG_WR_0x10503 : REG32_WRITE generic map(x"0001FFFF", x"03", x"000041A0") port map(rst_synch_sc, CLK_SC, wren_ssd_05_dpdclk, addr_l8, WDATA_CPU_IN, reg_ssd_length_per_switch);
        REG_WR_0x10504 : REG32_WRITE generic map(x"0001FFFF", x"04", x"0001FFFF") port map(rst_synch_sc, CLK_SC, wren_ssd_05_dpdclk, addr_l8, WDATA_CPU_IN, reg_ssd_accu_length      );
        REG_WR_0x10506 : REG32_WRITE generic map(x"0000FFFF", x"06", x"00002000") port map(rst_synch_sc, CLK_SC, wren_ssd_05_dpdclk, addr_l8, WDATA_CPU_IN, reg_ssd_gain             );
        P_SSD_REG_Read_DPD_CLK : process(rst_synch_sc, CLK_SC) begin
            if (rst_synch_sc= '1') then
                reg_ssd_ctrl_rdata <= (others => '0');
            elsif (CLK_SC'event) and (CLK_SC = '1') then
                if (rden_ssdclk_rpls = '1') then 
                    if (addr_h8 = x"05") then 
                        case (addr_l8) is
                            when x"00"  => reg_ssd_ctrl_rdata <= reg_ssd_path_sel; 
                            when x"01"  => reg_ssd_ctrl_rdata <= reg_ssd_ctrl; 
                            when x"02"  => reg_ssd_ctrl_rdata <= reg_ssd_period; 
                            when x"03"  => reg_ssd_ctrl_rdata <= reg_ssd_length_per_switch; 
                            when x"04"  => reg_ssd_ctrl_rdata <= reg_ssd_accu_length; 
                            when x"05"  => reg_ssd_ctrl_rdata <= zeros(RDATA_WIDTH-1 downto  1) & reg_ssd_accu_done_flg; 
                            when x"06"  => reg_ssd_ctrl_rdata <= reg_ssd_gain; 
                            when others => reg_ssd_ctrl_rdata <= (others => '0'); 
                        end case;
                    else
                        reg_ssd_ctrl_rdata <= (others => '0');
                    end if;
                else
                    reg_ssd_ctrl_rdata <= reg_ssd_ctrl_rdata ;
                end if;
            end if;
        end process;
        P_SSD_PTN_Write : process(RST_CPU, CLK_CPU) begin
            if (RST_CPU = '1') then
                ssd_ptn_wren      <= '0';            
                ssd_ptn_wren_d1   <= '0';
                ssd_ptn_wren_rpls <= '0';
                ssd_ptn_waddr     <= (others => '0');
                ssd_ptn_wdata     <= (others => '0');
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                if (WREN_CPU_IN = '1') and (ADDR_CPU_IN(15 downto 12) = x"5") then                         
                    ssd_ptn_wren    <= '1';            
                    ssd_ptn_wdata   <= WDATA_CPU_IN;
                else
                    ssd_ptn_wren    <= '0';            
                    ssd_ptn_wdata   <= (others => '0');
                end if;
                if (ssd_ptn_wren = '1') then    
                    ssd_ptn_waddr   <= ADDR_CPU_IN(8 downto 0);
                else
                    ssd_ptn_waddr   <= ssd_ptn_waddr;
                end if;
                ssd_ptn_wren_d1   <= ssd_ptn_wren;
                ssd_ptn_wren_rpls <= ssd_ptn_wren and (not ssd_ptn_wren_d1);
            end if;
        end process;
        P_SSD_Read_Enable : process(RST_CPU, CLK_CPU) begin
            if (RST_CPU = '1') then
                ssd_mem_rden    <= '0';           
                ssd_mem_rden_d1 <= '0';
                ssd_mem_raddr   <= (others => '0');
                ssd_mem_rdata   <= (others => '0');
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then 
                if (RDEN_CPU_IN = '1') and (ADDR_CPU_IN(15 downto 12) = x"4") then
                    ssd_mem_rden  <= '1';           
                    ssd_mem_rdata <= ssd_accu_mem_rdata;
                else
                    ssd_mem_rden  <= '0';           
                    ssd_mem_rdata <= (others => '0');
                end if;
                if (ssd_mem_rden = '1') then
                    ssd_mem_raddr <= ADDR_CPU_IN(9 downto 0);
                else
                    ssd_mem_raddr <= ssd_mem_raddr;
                end if;
                ssd_mem_rden_d1 <= ssd_mem_rden;
            end if;
        end process;
    end generate;
    G_Unusing_RX_SSD : if (RX_SSD_IMPLEMENTATION = FALSE) generate begin 
        wren_ssdclk_sh   <= (others => '0'); 
        wren_ssdclk_rpls <= '0'; 
        rden_ssdclk_sh   <= (others => '0'); 
        rden_ssdclk_rpls <= '0'; 
        wren_ssd_05_dpdclk <= '0';
        reg_ssd_path_sel          <= (others => '0');
        reg_ssd_ctrl              <= (others => '0');
        reg_ssd_period            <= (others => '0');
        reg_ssd_length_per_switch <= (others => '0');
        reg_ssd_accu_length       <= (others => '0');
        reg_ssd_gain              <= (others => '0');
        reg_ssd_ctrl_rdata        <= (others => '0');
        ssd_ptn_wren              <= '0';            
        ssd_ptn_wren_d1           <= '0';
        ssd_ptn_wren_rpls         <= '0';
        ssd_ptn_waddr             <= (others => '0');
        ssd_ptn_wdata             <= (others => '0');
        ssd_mem_rden              <= '0';           
        ssd_mem_rden_d1           <= '0';
        ssd_mem_raddr             <= (others => '0');
        ssd_mem_rdata             <= (others => '0');
    end generate;
-- *************************************************************************************
-- Ratch & Clear : Hardware Alarm Gathering 
-- *************************************************************************************
    P_REG_Latch_N_Clear : process(rst_synch_cpu, CLK_CPU) begin
        if (rst_synch_cpu = '1') then
            lc_reg_02_cpuclk <= '0';
        elsif (CLK_CPU'event) and (CLK_CPU = '1') then
            if (lc_cpuclk_rpls = '1') then  
                if (addr_h8 = x"02") then
                    lc_reg_02_cpuclk <= '1';
                else
                    lc_reg_02_cpuclk <= '0';
                end if;
            else
                lc_reg_02_cpuclk <= '0';
            end if;
        end if;
    end process;

    REG_RC_0x10200 : REG32_LATCH generic map(reg_path_num, x"00") port map(rst_synch_cpu, CLK_CPU, lc_reg_02_cpuclk, addr_l8, reg_sig_sus_dloff_w, reg_sig_sus_dloff_s, reg_sig_sus_dloff_f); 

    G_Clock_Fail_Flag_Double_Clocking : for I in 0 to (TX_ANT_NUM-1) generate begin
        P_Clock_Fail_Flag_Double_Clocking : process(rst_synch_cpu, CLK_CPU) begin
            if (rst_synch_cpu = '1') then
                reg_clock_fail_flag_d1(I) <= '0';
                reg_clock_fail_flag_d2(I) <= '0'; 
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                reg_clock_fail_flag_d1(I) <= reg_clock_fail_flag(I);
                reg_clock_fail_flag_d2(I) <= reg_clock_fail_flag_d1(I); 
            end if;
        end process;
    end generate;

    P_HW_Log_REG_Read_CPU_CLK : process(rst_synch_cpu, CLK_CPU) begin
        if (rst_synch_cpu = '1') then
            reg_hw_log_rdata  <= (others => '0');
        elsif (CLK_CPU'event) and (CLK_CPU = '1') then
            if (rden_d4_cpuclk_rpls = '1') then 
                if (addr_h8 = x"02") then
                    case (addr_l8) is
                        when x"00"  => reg_hw_log_rdata <= reg_sig_sus_dloff_f; 
                        when x"01"  => reg_hw_log_rdata <= reg_sig_sus_dloff_s; 
                        when x"02"  => reg_hw_log_rdata <= zeros(RDATA_WIDTH-1 downto TX_ANT_NUM) & reg_clock_fail_flag_d2; 
                        when others => reg_hw_log_rdata <= (others => '0'); 
                    end case;
                else
                    reg_hw_log_rdata  <= (others => '0');
                end if;
            else
                reg_hw_log_rdata <=reg_hw_log_rdata;
            end if;
        end if;
    end process;

-- *************************************************************************************
-- Output Assign 
-- *************************************************************************************

    RDVLD_CPU_OUT                        <= rdvld_cpuclk;
    RDATA_DPD_OUT                        <= reg_cpuclk_dpdctrl_rdata      when (ADDR_CPU_IN(15 downto  8) = x"00"  ) else         
                                            reg_cpuclk_sc_rdata           when (ADDR_CPU_IN               = x"0107") else        
                                            reg_cpuclk_pimctrl_rdata      when (ADDR_CPU_IN(15 downto  8) = x"03"  ) else         
                                            reg_sc_ctrl_rdata             when (ADDR_CPU_IN(15 downto  8) = x"01"  ) else          
                                            reg_hw_log_rdata              when (ADDR_CPU_IN(15 downto  8) = x"02"  ) else           
                                            reg_ssd_ctrl_rdata            when (ADDR_CPU_IN(15 downto  8) = x"05"  ) else
                                            dpd_lut_rdata                 when (ADDR_CPU_IN(15 downto 12) = x"2"   ) else
                                            ssd_mem_rdata                 when (ADDR_CPU_IN(15 downto 12) = x"4"   ) else
                                            pim_lut_rdata                 when (ADDR_CPU_IN(15 downto 12) = x"6"   ) else
                                            -- pim_sltb1_lut_rdata             when (ADDR_CPU_IN(15 downto 12) = x"A"   ) else  -- write only
                                            -- pim_sltb2_lut_rdata             when (ADDR_CPU_IN(15 downto 12) = x"B"   ) else  -- write only
                                            reg_sltb_cpuclk_pimctrl_rdata when (ADDR_CPU_IN(15 downto  8) = x"70"  ) else
                                            -- sc_mem_rdata                  when (ADDR_CPU_IN(15)           = '1'    ) else
                                            sc_mem_rdata                  when (ADDR_CPU_IN(15 downto 13) = "100"  ) else
                                            (others => '0');

    -- DPD Core Control

    DPD_CORE_SET_STRB_OUT(0)             <= reg_dpd_core_gidx_cdc_strb;
    DPD_CORE_SET_STRB_OUT(1)             <= reg_dpd_core_qpoint_cdc_strb;

    reg_dpd_core_gidx                    <= reg_dpd_core_qpoint_n_gidx_cd(15 downto  0) & reg_dpd_core_qpoint_n_gidx_ab(15 downto  0);
    reg_dpd_core_qpoint                  <= reg_dpd_core_qpoint_n_gidx_cd(31 downto 16) & reg_dpd_core_qpoint_n_gidx_ab(31 downto 16);
    
    G_DPD_CORE_Gain_N_Qpoint_SEL : for I in 0 to (TX_ANT_NUM-1) generate begin
        DPD_CORE_GAIN_INDEX_OUT(I)       <= reg_dpd_core_gidx(2*I+1 downto 2*I);
        DPD_CORE_QPOINT_SEL_OUT(I)       <= reg_dpd_core_qpoint(2*I+1 downto 2*I);
    end generate;

    DPD_CORE_LUT_SWITCH_CDC_STRB_OUT(0)  <= '0';   -- <= reg_dpd_core_lut_switch_cdc_strb_a; 
    DPD_CORE_LUT_INPUT_SWITCH_OUT(0)     <= (others=>'0');   -- <= reg_dpd_core_lut_input_switch_a(19 downto 0); 
    DPD_CORE_LUT_OUTPUT_SWITCH_OUT(0)    <= (others=>'0');   -- <= reg_dpd_core_lut_output_switch_a(19 downto 0);

    DPD_CORE_LUT_SWITCH_CDC_STRB_OUT(1)  <= '0';   -- <= reg_dpd_core_lut_switch_cdc_strb_b; 
    DPD_CORE_LUT_INPUT_SWITCH_OUT(1)     <= (others=>'0');   -- <= reg_dpd_core_lut_input_switch_b(19 downto 0); 
    DPD_CORE_LUT_OUTPUT_SWITCH_OUT(1)    <= (others=>'0');   -- <= reg_dpd_core_lut_output_switch_b(19 downto 0);

    DPD_CORE_LUT_SWITCH_CDC_STRB_OUT(2)  <= '0';   -- <= reg_dpd_core_lut_switch_cdc_strb_c; 
    DPD_CORE_LUT_INPUT_SWITCH_OUT(2)     <= (others=>'0');   -- <= reg_dpd_core_lut_input_switch_c(19 downto 0); 
    DPD_CORE_LUT_OUTPUT_SWITCH_OUT(2)    <= (others=>'0');   -- <= reg_dpd_core_lut_output_switch_c(19 downto 0);

    DPD_CORE_LUT_SWITCH_CDC_STRB_OUT(3)  <= '0';   -- <= reg_dpd_core_lut_switch_cdc_strb_d; 
    DPD_CORE_LUT_INPUT_SWITCH_OUT(3)     <= (others=>'0');   -- <= reg_dpd_core_lut_input_switch_d(19 downto 0); 
    DPD_CORE_LUT_OUTPUT_SWITCH_OUT(3)    <= (others=>'0');   -- <= reg_dpd_core_lut_output_switch_d(19 downto 0);
                                                                             
    DPD_CORE_LUT_RB_TEST_OUT             <= reg_dpd_core_lut_rb_test(3 downto 0);

    DPD_CORE_LUT_UPDATE_SW_OUT           <= reg_dpd_core_lut_switch(TX_ANT_NUM-1 downto 0); 
    DPD_CORE_LUT_WREN_OUT                <= dpd_core_lut_we;
    DPD_CORE_LUT_RDEN_OUT                <= dpd_core_lut_re;
    DPD_CORE_LUT_ADDR_OUT                <= dpd_core_lut_addr;
    DPD_CORE_LUT_WDATA_OUT               <= dpd_core_lut_wdata;

    -- PIM Core Control
    PIM_CORE_SET_STRB_OUT(0)             <= reg_pim_core_gidx_cdc_strb; 
    PIM_CORE_SET_STRB_OUT(1)             <= reg_pim_core_qpoint_cdc_strb; 
    PIM_SLTB1_CORE_SET_STRB_OUT(0)       <= reg_pim_sltb1_core_gidx_cdc_strb; 
    PIM_SLTB1_CORE_SET_STRB_OUT(1)       <= reg_pim_sltb1_core_qpoint_cdc_strb; 
    PIM_SLTB2_CORE_SET_STRB_OUT(0)       <= reg_pim_sltb2_core_gidx_cdc_strb; 
    PIM_SLTB2_CORE_SET_STRB_OUT(1)       <= reg_pim_sltb2_core_qpoint_cdc_strb; 

    reg_pim_core_gidx                    <= reg_pim_core_qpoint_n_gidx_cd(15 downto  0) & reg_pim_core_qpoint_n_gidx_ab(15 downto  0);
    reg_pim_core_qpoint                  <= reg_pim_core_qpoint_n_gidx_cd(31 downto 16) & reg_pim_core_qpoint_n_gidx_ab(31 downto 16);

    U_SLTB_REG_CDC_13  : MULTIBIT_CDC generic map( 32) port map(reg_pim_sltb1_core_gain_qpoint_ab   , CLK_PIMD, s_pim_sltb1_core_gain_qpoint_ab_d2    );
    U_SLTB_REG_CDC_14  : MULTIBIT_CDC generic map( 32) port map(reg_pim_sltb2_core_gain_qpoint_ab   , CLK_PIMD, s_pim_sltb2_core_gain_qpoint_ab_d2    );
    U_SLTB_REG_CDC_15  : MULTIBIT_CDC generic map( 32) port map(reg_pim_sltb1_core_gain_qpoint_cd   , CLK_PIMD, s_pim_sltb1_core_gain_qpoint_cd_d2    );
    U_SLTB_REG_CDC_16  : MULTIBIT_CDC generic map( 32) port map(reg_pim_sltb2_core_gain_qpoint_cd   , CLK_PIMD, s_pim_sltb2_core_gain_qpoint_cd_d2    );
    reg_pim_sltb1_core_gidx              <= s_pim_sltb1_core_gain_qpoint_cd_d2(15 downto  0) & s_pim_sltb1_core_gain_qpoint_ab_d2(15 downto  0);
    reg_pim_sltb1_core_qpoint            <= s_pim_sltb1_core_gain_qpoint_cd_d2(31 downto 16) & s_pim_sltb1_core_gain_qpoint_ab_d2(31 downto 16);
    reg_pim_sltb2_core_gidx              <= s_pim_sltb2_core_gain_qpoint_cd_d2(15 downto  0) & s_pim_sltb2_core_gain_qpoint_ab_d2(15 downto  0);
    reg_pim_sltb2_core_qpoint            <= s_pim_sltb2_core_gain_qpoint_cd_d2(31 downto 16) & s_pim_sltb2_core_gain_qpoint_ab_d2(31 downto 16);
	    
    G_PIM_CORE_Gain_N_Qpoint_SEL : for I in 0 to (RX_ANT_NUM-1) generate begin
        PIM_CORE_GAIN_INDEX_OUT(I)             <= reg_pim_core_gidx(2*I+1 downto 2*I); 
        PIM_CORE_QPOINT_SEL_OUT(I)             <= reg_pim_core_qpoint(2*I+1 downto 2*I); 
        PIM_SLTB1_CORE_GAIN_INDEX_OUT(I)       <= reg_pim_sltb1_core_gidx(2*I+1 downto 2*I); 
        PIM_SLTB1_CORE_QPOINT_SEL_OUT(I)       <= reg_pim_sltb1_core_qpoint(2*I+1 downto 2*I); 
        PIM_SLTB2_CORE_GAIN_INDEX_OUT(I)       <= reg_pim_sltb2_core_gidx(2*I+1 downto 2*I); 
        PIM_SLTB2_CORE_QPOINT_SEL_OUT(I)       <= reg_pim_sltb2_core_qpoint(2*I+1 downto 2*I); 
    end generate;

    PIM_CORE_LUT_SWITCH_CDC_STRB_OUT(0)  <= '0';  -- <= reg_pim_core_lut_switch_cdc_strb_a; 
    PIM_CORE_LUT_INPUT_SWITCH_OUT(0)     <= (others=>'0');  -- <= reg_pim_core_lut_input_switch_a(19 downto 0);  
    PIM_CORE_LUT_OUTPUT_SWITCH_OUT(0)    <= (others=>'0');  -- <= reg_pim_core_lut_output_switch_a(19 downto 0); 

    PIM_CORE_LUT_SWITCH_CDC_STRB_OUT(1)  <= '0';  -- <= reg_pim_core_lut_switch_cdc_strb_b;              
    PIM_CORE_LUT_INPUT_SWITCH_OUT(1)     <= (others=>'0');  -- <= reg_pim_core_lut_input_switch_b(19 downto 0); 
    PIM_CORE_LUT_OUTPUT_SWITCH_OUT(1)    <= (others=>'0');  -- <= reg_pim_core_lut_output_switch_b(19 downto 0); 

    PIM_CORE_LUT_SWITCH_CDC_STRB_OUT(2)  <= '0';  -- <= reg_pim_core_lut_switch_cdc_strb_c;              
    PIM_CORE_LUT_INPUT_SWITCH_OUT(2)     <= (others=>'0');  -- <= reg_pim_core_lut_input_switch_c(19 downto 0); 
    PIM_CORE_LUT_OUTPUT_SWITCH_OUT(2)    <= (others=>'0');  -- <= reg_pim_core_lut_output_switch_c(19 downto 0); 

    PIM_CORE_LUT_SWITCH_CDC_STRB_OUT(3)  <= '0';  -- <= reg_pim_core_lut_switch_cdc_strb_d;              
    PIM_CORE_LUT_INPUT_SWITCH_OUT(3)     <= (others=>'0');  -- <= reg_pim_core_lut_input_switch_d(19 downto 0); 
    PIM_CORE_LUT_OUTPUT_SWITCH_OUT(3)    <= (others=>'0');  -- <= reg_pim_core_lut_output_switch_d(19 downto 0); 

    PIM_CORE_LUT_RB_TEST_OUT             <= reg_pim_core_lut_rb_test(3 downto 0); 

    PIM_CORE_LUT_UPDATE_SW_OUT           <= reg_pim_core_lut_switch(TX_ANT_NUM-1 downto 0); -- <= (others => '0');
    PIM_CORE_LUT_WREN_OUT                <= pim_core_lut_we;    
    PIM_CORE_LUT_RDEN_OUT                <= pim_core_lut_re;    
    PIM_CORE_LUT_ADDR_OUT                <= pim_core_lut_addr;  
    PIM_CORE_LUT_WDATA_OUT               <= pim_core_lut_wdata; 
    -- selectable pim 
	U_SLTB_REG_CDC_17  : MULTIBIT_CDC generic map(TX_ANT_NUM) port map(reg_pim_sltb1_core_lut_upt_switch(TX_ANT_NUM-1 downto 0), CLK_PIMD, s_pim_sltb1_core_lut_upt_switch_d2);
	U_SLTB_REG_CDC_18  : MULTIBIT_CDC generic map(TX_ANT_NUM) port map(reg_pim_sltb2_core_lut_upt_switch(TX_ANT_NUM-1 downto 0), CLK_PIMD, s_pim_sltb2_core_lut_upt_switch_d2);	
	
    PIM_SLTB1_CORE_LUT_UPDATE_SW_OUT     <= s_pim_sltb1_core_lut_upt_switch_d2; -- <= (others => '0');
    PIM_SLTB1_CORE_LUT_WREN_OUT          <= pim_sltb1_core_lut_we;    
    PIM_SLTB1_CORE_LUT_RDEN_OUT          <= pim_sltb1_core_lut_re;    
    PIM_SLTB1_CORE_LUT_ADDR_OUT          <= pim_sltb1_core_lut_addr;  
    PIM_SLTB1_CORE_LUT_WDATA_OUT         <= pim_sltb1_core_lut_wdata; 
    PIM_SLTB2_CORE_LUT_UPDATE_SW_OUT     <= s_pim_sltb2_core_lut_upt_switch_d2; -- <= (others => '0');
    PIM_SLTB2_CORE_LUT_WREN_OUT          <= pim_sltb2_core_lut_we;    
    PIM_SLTB2_CORE_LUT_RDEN_OUT          <= pim_sltb2_core_lut_re;    
    PIM_SLTB2_CORE_LUT_ADDR_OUT          <= pim_sltb2_core_lut_addr;  
    PIM_SLTB2_CORE_LUT_WDATA_OUT         <= pim_sltb2_core_lut_wdata; 

    PIM_COMPLEX_FILTER_COEF_WREN_OUT     <= reg_pim_complex_filter_coef_wren(RX_ANT_NUM-1 downto 0);
    PIM_COMPLEX_FILTER_COEF_RDEN_OUT     <= reg_pim_complex_filter_coef_rden(RX_ANT_NUM-1 downto 0);
    PIM_COMPLEX_FILTER_COEF_WRDN_OUT     <= reg_pim_complex_filter_coef_wrdn(RX_ANT_NUM-1 downto 0);

    PIM_COMPLEX_FILTER_COEF_ADDR_OUT     <= reg_pim_complex_filter_coef_addr( 3 downto 0);    
    PIM_COMPLEX_FILTER_COEF_I_WDATA_OUT  <= reg_pim_complex_filter_coef_i_wdata(20 downto 0);   
    PIM_COMPLEX_FILTER_COEF_Q_WDATA_OUT  <= reg_pim_complex_filter_coef_q_wdata(20 downto 0);   

    PIM_SRC_INTRAB_DLY_STRB_OUT          <= reg_pim_src_intrab_dly_strb; 
    PIM_SRC_INTERB_DLY_STRB_OUT          <= reg_pim_src_interb_dly_strb;           
    PIM_REF_DLY_STRB_OUT                 <= reg_pim_ref_dly_strb;           
    PIM_UL_DLY_STRB_OUT                  <= reg_pim_ul_dly_strb;           

    G_PIM_Core_Reference_Sample_Delay_Value : for I in 0 to (TX_ANT_NUM-1) generate begin
        PIM_SRC_INTRAB_DLY_OUT(I)        <= reg_pim_src_intrab_dly(I)(11 downto  0); 
        PIM_SRC_INTERB_CDLY_OUT(I)       <= reg_pim_src_interb_dly(I)(10 downto  0); 
        PIM_SRC_INTERB_FDLY_OUT(I)       <= reg_pim_src_interb_dly(I)(19 downto 16);
        PIM_REF_SAMPLE_DLY_OUT(I)        <= reg_pim_ref_sample_dly(I)(11 downto 0); 
    end generate;

    G_PIM_Core_Sample_Delay_Value : for I in 0 to (RX_ANT_NUM-1) generate begin
        PIM_UL_SAMPLE_DLY_OUT(I)         <= reg_pim_ul_sample_dly(I)(11 downto 0); 
    end generate;

    PNPC_EN_OUT                          <= reg_pnpc_en( RX_ANT_NUM-1 downto 0);                       
    PNPC_SET_OUT                         <= reg_pnpc_set(RX_ANT_NUM-1 downto 0);                       

    PNPC_MU_SEL_STRB_OUT                 <= reg_pnpc_mu_sel_strb;
    PNPC_SETVAL_STRB_OUT                 <= reg_pnpc_setval_strb;                

    G_LMS_Power_N_Phase_Compensator_Register : for I in 0 to (RX_ANT_NUM-1) generate begin
        PNPC_MU_SEL_OUT(I)               <= reg_pnpc_mu_sel(2*I+1 downto 2*I);                         
        PNPC_SETVAL_I_OUT(I)             <= reg_pnpc_setval(I)(31 downto 16);                  
        PNPC_SETVAL_Q_OUT(I)             <= reg_pnpc_setval(I)(15 downto  0);                  
    end generate;

    PIM_UL_MIXER_FREQ_ERR_COMP_STRB_OUT  <= reg_pim_ul_mixer_freq_err_comp_strb;                
    PIM_UL_MIXER_FREQ_ERR_COMP_WORD_OUT  <= reg_pim_ul_mixer_freq_err_comp_word;                    

    -- Smart Capture Control

    SC_CONTROL_OUT                       <= reg_sc_control( 0); 
    SC_TDD_MODE_OUT                      <= reg_sc_tdd_mode( 0); 
    SC_FORCED_MODE_OUT                   <= reg_sc_force( 0); 
    SC_DEBOUNCING_TIME_OUT               <= reg_sc_debouncing_time( 9 downto 0);
    SC_CAP_SIZE_SEL_OUT                  <= reg_sc_cap_size(0); 
    SC_DPDFB_PIM_MODE_SEL_OUT            <= reg_sc_mode( 0); 

    SC_PATH_SEL_STRB_OUT                 <= sc_path_sel_strb; 
    SC_PATH_SEL_OUT                      <= reg_sc_path_sel( 4 downto 0); 
    SC_CAP_MEMORY_SEL_OUT                <= reg_sc_cap_memory_sel( 2 downto 0); 
    SC_DPD_CORE_HC_LATENCY_OUT           <= reg_sc_dpd_hc_latency( 9 downto 0);   
    SC_FB_LATENCY_OUT                    <= reg_sc_fb_latency( 9 downto 0);    
    SC_REF_LATENCY_OUT                   <= reg_sc_ref_latency( 9 downto 0);

    SC_CAP_OFF_START_OUT                 <= reg_sc_cap_off_start(21 downto 0); 
    SC_CAP_OFF_STOP_OUT                  <= reg_sc_cap_off_stop(21 downto 0); 
    SC_STATIC_POSITION_OUT               <= reg_sc_static_position(21 downto 0); 
    SC_STATIC_LENGTH_OUT                 <= reg_sc_static_length( 8 downto 0); 
    SC_MAX_PEAK_BO_GAIN_OUT              <= reg_sc_max_cur_bo_gain(15 downto  0); 
    SC_CUR_PEAK_BO_GAIN_OUT              <= reg_sc_max_peak_bo_gain(15 downto  0); 
    SC_INTER_PIM_DBG_SEL_OUT             <= reg_sc_pim_dbg_path_sel( 1 downto  0);
    SC_INTRA_PIM_DBG_SEL_OUT             <= reg_sc_pim_dbg_path_sel(17 downto 16);

    SC_MEM_RDEN_OUT                      <= sc_mem_rden_d1; 
    SC_MEM_ADDR_OUT                      <= sc_mem_raddr;

    -- SSD Control
    SSD_PATH_SEL_OUT                     <= reg_ssd_path_sel(4 downto 0);           
    SSD_CTRL_OUT                         <= reg_ssd_ctrl(0);                        
    SSD_PERIOD_OUT                       <= reg_ssd_period(9 downto 0);             
    SSD_LENGTH_PER_SWITCH_OUT            <= reg_ssd_length_per_switch(16 downto 0); 
    SSD_ACCU_LENGTH_OUT                  <= reg_ssd_accu_length(16 downto 0);       
    SSD_GAIN_OUT                         <= reg_ssd_gain(15 downto 0);              
    SSD_PTN_WREN_OUT                     <= ssd_ptn_wren_rpls; 
    SSD_PTN_WADDR_OUT                    <= ssd_ptn_waddr; 
    SSD_PTN_WDATA_OUT                    <= ssd_ptn_wdata; 
    SSD_MEM_RDEN_OUT                     <= ssd_mem_rden_d1; 
    SSD_MEM_ADDR_OUT                     <= ssd_mem_raddr; 
    -- selectable
    U_SLTB_REG_CDC_00  : MULTIBIT_CDC generic map( 1) port map(reg_pim_sltb_intra_nco_wren(0 downto 0)    , CLK_PIMD, s_pim_sltb_intra_nco_wren_d2         );
    U_SLTB_REG_CDC_01  : MULTIBIT_CDC generic map(32) port map(reg_pim_sltb_intra_nco_word                , CLK_PIMD, PIM_SLTB_INTRA_NCO_WORD_OUT          );
    U_SLTB_REG_CDC_02  : MULTIBIT_CDC generic map( 1) port map(reg_pim_sltb_inter1_nco_wren(0 downto 0)   , CLK_PIMD, s_pim_sltb_inter1_nco_wren_d2        );
    U_SLTB_REG_CDC_03  : MULTIBIT_CDC generic map(32) port map(reg_pim_sltb_inter1_nco_word               , CLK_PIMD, PIM_SLTB_INTER1_NCO_WORD_OUT         );
    U_SLTB_REG_CDC_04  : MULTIBIT_CDC generic map( 1) port map(reg_pim_sltb_inter2_nco_wren(0 downto 0)   , CLK_PIMD, s_pim_sltb_inter2_nco_wren_d2        );
    U_SLTB_REG_CDC_05  : MULTIBIT_CDC generic map(32) port map(reg_pim_sltb_inter2_nco_word               , CLK_PIMD, PIM_SLTB_INTER2_NCO_WORD_OUT         );
    -- U_SLTB_REG_CDC_08  : MULTIBIT_CDC generic map( 1) port map(reg_pim_sltb_im3gen_intra_sel(0 downto 0)  , CLK_PIMD, s_pim_sltb_im3gen_intra_sel_d2       );
    -- U_SLTB_REG_CDC_09  : MULTIBIT_CDC generic map( 2) port map(reg_pim_sltb_im3gen_inter1_sel(1 downto 0) , CLK_PIMD, PIM_SLTB_INTER_BAND_TYPE1_SEL_OUT    );
    -- U_SLTB_REG_CDC_10  : MULTIBIT_CDC generic map( 2) port map(reg_pim_sltb_im3gen_inter2_sel(1 downto 0) , CLK_PIMD, PIM_SLTB_INTER_BAND_TYPE2_SEL_OUT    );
	U_SLTB_REG_CDC_11  : MULTIBIT_CDC generic map( 2) port map(reg_pim_sltb_bit_shift_sel(1 downto 0)     , CLK_PIMD, PIM_SLTB_BIT_SHIFT_SEL_OUT           );
    G_SLTB_REG_CDC : for T in 0 to (TX_ANT_NUM-1) generate begin
        U_SLTB_REG_CDC_06  : MULTIBIT_CDC generic map(12) port map(reg_pim_sltb1_core_out_dly(T)(11 downto 0)   , CLK_PIMD, PIMDLY_SLTB1_VALUE_OUT(T)          );
        U_SLTB_REG_CDC_07  : MULTIBIT_CDC generic map(12) port map(reg_pim_sltb2_core_out_dly(T)(11 downto 0)   , CLK_PIMD, PIMDLY_SLTB2_VALUE_OUT(T)          );
        U_SLTB_REG_CDC_00  : MULTIBIT_CDC generic map( 2) port map(reg_pim_sltb_quarter_shift_intra_sel(1 downto 0)   , CLK_PIMD, PIM_SLTB_SHIFT_DIRECTION_INTRA_OUT(T) );
        U_SLTB_REG_CDC_01  : MULTIBIT_CDC generic map( 2) port map(reg_pim_sltb_quarter_shift_inter1_sel(1 downto 0)  , CLK_PIMD, PIM_SLTB_SHIFT_DIRECTION_INTER1_OUT(T));
        U_SLTB_REG_CDC_02  : MULTIBIT_CDC generic map( 2) port map(reg_pim_sltb_quarter_shift_inter2_sel(1 downto 0)  , CLK_PIMD, PIM_SLTB_SHIFT_DIRECTION_INTER2_OUT(T));
    end generate;
	
    PIM_SLTB_INTRA_NCO_WREN_OUT   <= s_pim_sltb_intra_nco_wren_d2(0);
    PIM_SLTB_INTER1_NCO_WREN_OUT  <= s_pim_sltb_inter1_nco_wren_d2(0);
    PIM_SLTB_INTER2_NCO_WREN_OUT  <= s_pim_sltb_inter2_nco_wren_d2(0);
    -- PIM_SLTB_INTRA_BAND_SEL_OUT   <= s_pim_sltb_im3gen_intra_sel_d2(0);
	
	U_SLTB_REG_CDC_08  : MULTIBIT_CDC generic map(32) port map(reg_pim_sltb_im3gen_intra_sel              , CLK_PIMD, s_pim_sltb_im3gen_intra_sel_d2       );
    U_SLTB_REG_CDC_09  : MULTIBIT_CDC generic map(32) port map(reg_pim_sltb_im3gen_inter1_sel             , CLK_PIMD, reg_pim_sltb_im3gen_inter1_sel_d2    );
    U_SLTB_REG_CDC_10  : MULTIBIT_CDC generic map(32) port map(reg_pim_sltb_im3gen_inter2_sel             , CLK_PIMD, reg_pim_sltb_im3gen_inter2_sel_d2    );
	
	PIM_IM3_SEL_OUT : for i in 0 to TX_ANT_NUM-1 generate
		PIM_SLTB_INTRA_BAND_SEL_OUT(i)   			<= 	s_pim_sltb_im3gen_intra_sel_d2(4*i);
		PIM_SLTB_INTER_BAND_TYPE1_SEL_OUT(i)		<=	reg_pim_sltb_im3gen_inter1_sel_d2(4*i+1 downto 4*i);
		PIM_SLTB_INTER_BAND_TYPE2_SEL_OUT(i)		<=	reg_pim_sltb_im3gen_inter2_sel_d2(4*i+1 downto 4*i);
	end generate PIM_IM3_SEL_OUT;
	
end arc_CPUIF_DSP_DPDSC;
