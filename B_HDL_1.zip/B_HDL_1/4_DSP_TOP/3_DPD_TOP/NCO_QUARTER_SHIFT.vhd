library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity NCO_QUARTER_SHIFT is
generic(
    DEVICE                       : string  := "ULTRASCALE";
    HOVS                         : natural :=           1 ;
    TX_ANT_NUM                   : natural :=           4 
    );
port(
    RST                          : in  std_logic;           -- Reset, Active High
    CLK                          : in  std_logic;

    SHIFT_DIRECTION_IN           : in  std_logic_array2(TX_ANT_NUM-1 downto 0);

    DATA_VLD_IN                  : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DATA_I_IN                    : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    DATA_Q_IN                    : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    DATA_VLD_OUT                 : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    DATA_I_OUT                   : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    DATA_Q_OUT                   : out std_logic_array16(TX_ANT_NUM-1 downto 0) 
    );
end NCO_QUARTER_SHIFT;

architecture arc_NCO_QUARTER_SHIFT of NCO_QUARTER_SHIFT is

constant HS_MODE : boolean := TRUE;

component DSP48E_MULT is
generic(
    DEVICE                      : string  := "ULTRASCALE";
    DSP48_MODECTRL              : boolean :=       FALSE ;
    DSP48_PREADDER_USE          : boolean :=        TRUE ;
    DSP48_PREADDER_MODE         : string  :=        "ADD"; -- "ADD" or "SUB" 
    DSP48_PCIN_USE              : boolean :=       FALSE ;
    DSP48_PCOUT_USE             : boolean :=       FALSE ;

    A_nREG                      : integer :=           2 ; -- 0, 1, 2
    B_nREG                      : integer :=           2 ; -- 0, 1, 2

    C_EN                        : boolean :=        TRUE ; -- RND ENable
    RND_SYMMETRY                : boolean :=       FALSE 
    );
port(
    CLK                         : in  std_logic;

    ALUMODE_IN                  : in  std_logic_vector( 3 downto 0);
    OPMODE_IN                   : in  std_logic_vector( 8 downto 0);

    C_IN                        : in  std_logic_vector(47 downto 0); -- RND Value
    A_IN                        : in  std_logic_vector(29 downto 0);
    D_IN                        : in  std_logic_vector(26 downto 0);
    B_IN                        : in  std_logic_vector(17 downto 0);

    P_CIN                       : in  std_logic_vector(47 downto 0);
    P_COUT                      : out std_logic_vector(47 downto 0);

    P_OUT                       : out std_logic_vector(47 downto 0);
    CRRY_OUT                    : out std_logic
    );
end component;

component SAT_SIGN is
generic(
    HS_MODE                     : boolean := TRUE;
    INPUT_BIT                   : natural;
    OUTPUT_BIT                  : natural 
    );
port( 
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    DATA_IN                     : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT                    : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

component SRL16E_DLY is
generic(
    DEVICE                       : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HS_MODE                      : boolean :=        TRUE ;

    BIT_WIDTH                    : natural;
    DELAY_NUM                    : natural
    );
port(
    CLK                          : in  std_logic;
    DATA_IN                      : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT                     : out std_logic_vector(BIT_WIDTH-1 downto 0) 
    );
end component;

-- INPUT
signal s_shift_direction_in      : std_logic_array2(TX_ANT_NUM-1 downto 0); 
signal s_shift_direction_in_d    : std_logic_array2(TX_ANT_NUM-1 downto 0); 
signal s_shift_direction_in_dly  : std_logic_array2(TX_ANT_NUM-1 downto 0); 
signal s_data_vld_in             : std_logic_vector(TX_ANT_NUM-1 downto 0); 
signal s_data_vld_in_dly         : std_logic_vector(TX_ANT_NUM-1 downto 0); 
signal s_data_i_in               : std_logic_array16(TX_ANT_NUM-1 downto 0); 
signal s_data_q_in               : std_logic_array16(TX_ANT_NUM-1 downto 0); 
signal s_data_i_in_dly           : std_logic_array16(TX_ANT_NUM-1 downto 0); 
signal s_data_q_in_dly           : std_logic_array16(TX_ANT_NUM-1 downto 0); 

signal mux45_sel                 : std_logic_array3(TX_ANT_NUM-1 downto 0);
signal mux45_sel_dly             : std_logic_array3(TX_ANT_NUM-1 downto 0);
signal s_data_i_out              : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal s_data_q_out              : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal mux45_in_i_pos            : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal mux45_in_q_pos            : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal mux45_in_i_neg            : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal mux45_in_q_neg            : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal mux1_sel                  : std_logic_vector(TX_ANT_NUM-1 downto 0);
signal mux2_sel                  : std_logic_vector(TX_ANT_NUM-1 downto 0);




-- dsp48e format
-- signal c_in_dsp48_00             : std_logic_array48(TX_ANT_NUM-1 downto 0);
-- signal a_in_dsp48_00             : std_logic_array30(TX_ANT_NUM-1 downto 0);
-- signal d_in_dsp48_00             : std_logic_array27(TX_ANT_NUM-1 downto 0);
-- signal b_in_dsp48_00             : std_logic_array18(TX_ANT_NUM-1 downto 0);
-- signal p_cin_dsp48_00            : std_logic_array48(TX_ANT_NUM-1 downto 0);
-- signal p_cout_dsp48_00           : std_logic_array48(TX_ANT_NUM-1 downto 0);
-- signal p_out_dsp48_00            : std_logic_array48(TX_ANT_NUM-1 downto 0);
------- Conjugated Multiplication

------
begin

U_DLY_VLD_01   : SRL16E_DLY generic map(DEVICE, HS_MODE, TX_ANT_NUM, 2) port map (CLK, s_data_vld_in, s_data_vld_in_dly);
U_DLY_VLD_02   : SRL16E_DLY generic map(DEVICE, HS_MODE, TX_ANT_NUM, 4) port map (CLK, s_data_vld_in_dly, DATA_VLD_OUT);

G_ANT_QUARTER_SHIFT : for I in 0 to TX_ANT_NUM-1 generate begin   

    process (CLK)
    begin
        if ( RST = '1' ) then
            s_shift_direction_in(I)     <= (others=>'0')  ; 
            s_data_vld_in(I)            <= '0';
            s_data_i_in(I)              <= (others=>'0')  ; 
            s_data_q_in(I)              <= (others=>'0')  ; 

        elsif ( rising_edge(CLK) ) then
            s_shift_direction_in(I)     <= SHIFT_DIRECTION_IN(I)  ;     
            s_data_vld_in(I)            <= DATA_VLD_IN(I)         ;     
            s_data_i_in(I)              <= DATA_I_IN(I)           ;     
            s_data_q_in(I)              <= DATA_Q_IN(I)           ;     

            DATA_I_OUT(I)               <= s_data_i_out(I)        ; 
            DATA_Q_OUT(I)               <= s_data_q_out(I)        ; 

            s_shift_direction_in_d(I)   <= s_shift_direction_in(I)  ;
            s_shift_direction_in_dly(I) <= s_shift_direction_in_d(I);

        end if;
    end process;

    U_DLY_I_01      : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 2) port map (CLK, s_data_i_in(I), mux45_in_i_pos(I));
    U_DLY_Q_01      : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 2) port map (CLK, s_data_q_in(I), mux45_in_q_pos(I));

    -- MUX 1 -- 2 clk
    process (CLK)
    begin
        if ( rising_edge(CLK) ) then
            -- 1 clk
            if ( s_data_i_in(I) = (x"8000") ) then    -- (-)32768
                mux1_sel(I)  <= '1';
            else
                mux1_sel(I)  <= '0';
            end if;

            s_data_i_in_dly(I)  <= s_data_i_in(I);
            -- 1 clk
            if ( mux1_sel(I) = '0' ) then
                --Function toggles sign bit of the given input. Overfow case is
                --checked and saturation is applied if necessary.
                mux45_in_i_neg(I)  <= (not s_data_i_in_dly(I)) + '1';
            else
                mux45_in_i_neg(I)  <=  x"7FFF"; -- 32767
            end if;
            
        end if;
    end process;

    -- MUX 2 -- 2 clk
    process (CLK)
    begin
        if ( rising_edge(CLK) ) then
            -- 1 clk
            if ( s_data_q_in(I) = (x"8000") ) then    -- (-)32768
                mux2_sel(I)  <= '1';
            else
                mux2_sel(I)  <= '0';
            end if;

            s_data_q_in_dly(I)  <= s_data_q_in(I);
            -- 1 clk
            if ( mux2_sel(I) = '0' ) then
                --Function toggles sign bit of the given input. Overfow case is
                --checked and saturation is applied if necessary.
                mux45_in_q_neg(I)  <= (not s_data_q_in_dly(I)) + '1';
            else
                mux45_in_q_neg(I)  <=  x"7FFF"; -- 32767
            end if;
            
        end if;
    end process;

    -- MUX 3  -- 1clk
    process (RST, CLK)
    begin
        if ( (RST = '1') or (s_data_vld_in_dly(I) = '0') ) then
        --if ( RST = '1') then
            mux45_sel(I)  <= "000";
        elsif ( rising_edge(CLK) ) then
            -- -- 1 clk
            -- if ( s_data_q_in(I) = (x"8000") ) then    -- (-)32768
            --     mux2_sel(I)  <= '1';
            -- else
            --     mux2_sel(I)  <= '0';
            -- end if;

            -- -- 1 clk
            -- if ( s_shift_direction_in(I) = "00" ) then
            --     mux45_sel(I)  <= "000";
            -- elsif ( s_shift_direction_in(I) = "01" ) then 
            --     mux45_sel(I)  <= mux45_sel_dly(I) + '1'; -- lsb 2bit
            -- elsif ( s_shift_direction_in(I) = "10" ) then
            --     mux45_sel(I)  <= mux45_sel_dly(I) - '1'; 
            -- end if;

            -- mux45_sel_dly(I)  <= mux45_sel(I);
            if ( s_shift_direction_in_dly(I) = "00" ) then
                mux45_sel(I)  <= "000";
            elsif ( s_shift_direction_in_dly(I) = "01" ) then 
                mux45_sel(I)  <= ( ( mux45_sel(I) + '1') and "011" ) ; -- lsb 2bit
            elsif ( s_shift_direction_in_dly(I) = "10" ) then
                mux45_sel(I)  <= ( ( mux45_sel(I) - '1') and "011" ) ; 
            end if;
        end if;
    end process;

    -- MUX 4 -- 1clk 
    process (CLK)
    begin
        if ( rising_edge(CLK) ) then
            -- 1 clk
            if ( mux45_sel(I)(1 downto 0) = "00" ) then
                s_data_i_out(I)  <= mux45_in_i_pos(I);
            elsif ( mux45_sel(I)(1 downto 0) = "01" ) then 
                s_data_i_out(I)  <= mux45_in_q_neg(I); 
            elsif ( mux45_sel(I)(1 downto 0) = "10" ) then
                s_data_i_out(I)  <= mux45_in_i_neg(I);
            elsif ( mux45_sel(I)(1 downto 0) = "11" ) then
                s_data_i_out(I)  <= mux45_in_q_pos(I);
            end if;
            
        end if;
    end process;

    -- MUX 5 -- 1clk 
    process (CLK)
    begin
        if ( rising_edge(CLK) ) then
            -- 1 clk
            if ( mux45_sel(I)(1 downto 0) = "00" ) then
                s_data_q_out(I)  <= mux45_in_q_pos(I);
            elsif ( mux45_sel(I)(1 downto 0) = "01" ) then 
                s_data_q_out(I)  <= mux45_in_i_pos(I); 
            elsif ( mux45_sel(I)(1 downto 0) = "10" ) then
                s_data_q_out(I)  <= mux45_in_q_neg(I);
            elsif ( mux45_sel(I)(1 downto 0) = "11" ) then
                s_data_q_out(I)  <= mux45_in_i_neg(I);
            end if;
            
        end if;
    end process;

end generate;

end arc_NCO_QUARTER_SHIFT;
