-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part
-- Block Name : MIXER 

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity MIXER is
generic(
    DEVICE           : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HS_MODE          : boolean :=     TRUE ;

    HOVS             : natural :=        2 ;
    DATA_WIDTH       : natural :=       16 ;
    RND_BIT          : natural :=       15
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;

    SAMPLE_VLD_IN    : in  std_logic;
    SAMPLE_I_IN      : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    SAMPLE_Q_IN      : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    
    COS_I_IN         : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    SIN_Q_IN         : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    SAMPLE_VLD_OUT   : out std_logic;
    SAMPLE_I_OUT     : out std_logic_vector(DATA_WIDTH-1 downto 0);
    SAMPLE_Q_OUT     : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end MIXER;

architecture arc_MIXER of MIXER is

component COMPLEX_MULTIPLIER is
generic(
    DEVICE         : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HOVS           : natural :=        1 ;

    INPUT_WIDTH    : natural :=       16 ; -- AIN bitwidth : 0 to 29
    RND_EN         : boolean :=     TRUE ; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT        : natural :=       15 ; -- Rounding bit  
    OUTPUT_WIDTH   : natural :=       16   -- Result bitwidth : 0 to 47
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;

    DATA_VLD_IN    : in  std_logic;
    ADATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    ADATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
                                            
    BDATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    BDATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
   
    DATA_VLD_OUT   : out std_logic;
    DATA_I_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0);
    DATA_Q_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
end component;

component COMPLEX_MULTIPLIER_HOVS1 is
generic(
    DEVICE         : string := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HS_MODE        : boolean;

    INPUT_WIDTH    : natural; -- AIN bitwidth : 0 to 29
    RND_EN         : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT        : natural; -- Rounding bit  
    OUTPUT_WIDTH   : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;

    DATA_VLD_IN    : in  std_logic;
    ADATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    ADATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
                                            
    BDATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    BDATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
   
    DATA_VLD_OUT   : out std_logic;
    DATA_I_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0);
    DATA_Q_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
end component;

component COMPLEX_MULTIPLIER_HOVS2 is
generic(
    DEVICE         : string := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2

    INPUT_WIDTH    : natural; -- AIN bitwidth : 0 to 29
    RND_EN         : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT        : natural; -- Rounding bit  
    OUTPUT_WIDTH   : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;

    DATA_VLD_IN    : in  std_logic;
    ADATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    ADATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
                                            
    BDATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    BDATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
   
    DATA_VLD_OUT   : out std_logic;
    DATA_I_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0);
    DATA_Q_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
end component;

begin

    U_MIXER : COMPLEX_MULTIPLIER 
    generic map(
        DEVICE         => DEVICE         , 
        HOVS           => HOVS           , 
                                         
        INPUT_WIDTH    => DATA_WIDTH     , 
        RND_EN         => TRUE           , 
        RND_BIT        => RND_BIT        , 
        OUTPUT_WIDTH   => DATA_WIDTH       
        )
    port map(
        RST            => RST            , 
        CLK            => CLK            , 
    
        DATA_VLD_IN    => SAMPLE_VLD_IN  , 
        ADATA_I_IN     => SAMPLE_I_IN    , 
        ADATA_Q_IN     => SAMPLE_Q_IN    , 

        BDATA_I_IN     => COS_I_IN       , 
        BDATA_Q_IN     => SIN_Q_IN       , 
       
        DATA_VLD_OUT   => SAMPLE_VLD_OUT ,
        DATA_I_OUT     => SAMPLE_I_OUT   ,
        DATA_Q_OUT     => SAMPLE_Q_OUT    
        );
	
end arc_MIXER;
