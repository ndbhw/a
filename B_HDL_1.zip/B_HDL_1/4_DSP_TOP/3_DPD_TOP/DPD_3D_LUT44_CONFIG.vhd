library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity DPD_3D_LUT44_CONFIG is
generic(
    DEVICE                   : string  := "ULTRASCALE";
    HS_MODE                  : boolean :=       FALSE ;
    TX_ANT_NUM               : natural :=           4 ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_RAM_NUM              : natural :=          44 ;
    DPD_TAP_NUM              : natural :=          10
    );
port(
    RST                      : in  std_logic;
    CLK                      : in  std_logic;
   
    LUT_DATA_VLD             : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    MAG9                     : in  std_logic_array9( TX_ANT_NUM-1 downto 0);
    MAG15                    : in  std_logic_array15(TX_ANT_NUM-1 downto 0);
    LUT_ADDR                 : out std_logic_array44_array9( TX_ANT_NUM-1 downto 0);

    DATA_I_IN                : in  std_logic_array16(TX_ANT_NUM-1 downto 0); 
    DATA_Q_IN                : in  std_logic_array16(TX_ANT_NUM-1 downto 0); 

    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);
    LUT_RDATA_IN             : in  std_logic_array44_array32(TX_ANT_NUM downto 0);

    LUT_ADD_I                : out std_logic_array10_array26(TX_ANT_NUM-1 downto 0);
    LUT_ADD_Q                : out std_logic_array10_array26(TX_ANT_NUM-1 downto 0)
    );
end DPD_3D_LUT44_CONFIG;

architecture arc_DPD_3D_LUT44_CONFIG of DPD_3D_LUT44_CONFIG is

constant DDR_DLY             : integer :=  3;
constant MAX_ADV             : integer :=  1;
constant LUT_4D_START_IDX    : integer :=  37;
constant LUT_4D_NUM          : integer :=  7;
constant SIGNAL_Q_POINT      : integer :=  15;
constant SUM_Q_POINT         : integer :=  22;
constant LUT_Q_POINT         : integer :=  13;
constant LUT3D_Q_POINT       : integer :=  12;
constant LUT_4D_Q_POINT      : integer :=  12;
constant LUT3D_RSHIFT        : integer := LUT3D_Q_POINT + 15 - SUM_Q_POINT;
constant zeros               : std_logic_vector(31 downto 0) := (others => '0');

component ADD4 is
generic(
    HS_MODE      : boolean := TRUE; -- High Speed Mode (Operating Clock > 307.2MHz)
    BITWIDTH     : natural := 16
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
  
    DATA0_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA1_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA2_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA3_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);

    DATA_OUT     : out std_logic_vector(BITWIDTH+1 downto 0)
    );
end component;

component ADD8 is
generic(
    HS_MODE      : boolean := FALSE;
    BITWIDTH     : natural := 16
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
  
    DATA0_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA1_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA2_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA3_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    
    DATA4_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA5_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA6_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA7_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);

    DATA_OUT     : out std_logic_vector(BITWIDTH+2 downto 0)
    );
end component;

component SRL16E_DLY is
generic(
    DEVICE       : string  := "ULTRASCALE";
    HS_MODE      : boolean :=       FALSE ;

    BIT_WIDTH    : natural;            -- 2 to 64
    DELAY_NUM    : natural
    );
port(
    CLK          : in  std_logic;

    DATA_IN      : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT     : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end component;

component SRLC32E_DLY is
generic(
    DEVICE    : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HS_MODE   : boolean :=        TRUE ;

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_COUT : out std_logic_vector(BIT_WIDTH-1 downto 0); -- SRLC32E Chain, 32clock Delayed DATA
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0)  -- Delayed DATA
    );
end component;

component DSP48E_MULT is
generic(
    DEVICE                      : string  := "ULTRASCALE";
    DSP48_MODECTRL              : boolean :=       FALSE ;
    DSP48_PREADDER_USE          : boolean :=        TRUE ;
    DSP48_PREADDER_MODE         : string  :=        "ADD"; -- "ADD" or "SUB" 
    DSP48_PCIN_USE              : boolean :=       FALSE ;
    DSP48_PCOUT_USE             : boolean :=       FALSE ;

    A_nREG                      : integer :=           2 ; -- 0, 1, 2
    B_nREG                      : integer :=           2 ; -- 0, 1, 2

    C_EN                        : boolean :=        TRUE ; -- RND ENable
    RND_SYMMETRY                : boolean :=       FALSE 
    );
port(
    CLK                         : in  std_logic;

    ALUMODE_IN                  : in  std_logic_vector( 3 downto 0);
    OPMODE_IN                   : in  std_logic_vector( 8 downto 0);

    C_IN                        : in  std_logic_vector(47 downto 0); -- RND Value
    A_IN                        : in  std_logic_vector(29 downto 0);
    D_IN                        : in  std_logic_vector(26 downto 0);
    B_IN                        : in  std_logic_vector(17 downto 0);

    P_CIN                       : in  std_logic_vector(47 downto 0);
    P_COUT                      : out std_logic_vector(47 downto 0);

    P_OUT                       : out std_logic_vector(47 downto 0);
    CRRY_OUT                    : out std_logic
    );
end component;


component DSP48E1_MULTIPLIER is
-- Latency 4 clocks
generic(
    AIN_BITWIDTH : natural; -- AIN bitwidth : 0 to 29
    BIN_BITWIDTH : natural; -- BIN bitwidth : 0 to 17
    RND_EN       : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT      : natural; -- Rounding bit  
    OUTPUT_WIDTH : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
    AIN          : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
    BIN          : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
    P            : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
    );
end component;

component DSP48E2_MULTIPLIER is
generic(
    AIN_BITWIDTH : natural; -- AIN bitwidth : 0 to 29
    BIN_BITWIDTH : natural; -- BIN bitwidth : 0 to 17
    RND_EN       : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT      : natural; -- Rounding bit  
    OUTPUT_WIDTH : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
    AIN          : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
    BIN          : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
    P            : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
    );
end component;

component DPD_3D_LUT44_4D is
generic(
    DEVICE                      : string  := "ULTRASCALE";

    DDR_DLY                     : integer :=           2 ;
    LUT_4D_NUM                  : integer :=           2 ;

    SIGNAL_Q_POINT              : integer :=          15 ;
    LUT_4D_Q_POINT              : integer :=          12 ;
    SUM_Q_POINT                 : integer :=          15
    );
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
   
    LUT_DATA_VLD                : in  std_logic;
    LUT_I_IN                    : in  std_logic_array16(LUT_4D_NUM-1 downto 0); 
    LUT_Q_IN                    : in  std_logic_array16(LUT_4D_NUM-1 downto 0); 

    MAG_IN                      : in  std_logic_vector(14 downto 0); 
    DATA_I_IN                   : in  std_logic_vector(15 downto 0); 
    DATA_Q_IN                   : in  std_logic_vector(15 downto 0); 

    DDR_I_OUT                   : out std_logic_array31(1 downto 0); 
    DDR_Q_OUT                   : out std_logic_array31(1 downto 0) 
    );
end component;

component SAT_SIGN is
generic(
    HS_MODE                     : boolean := TRUE;
    INPUT_BIT                   : natural;
    OUTPUT_BIT                  : natural 
    );
port( 
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    DATA_IN                     : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT                    : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

signal dpd_lut_output_switch : std_logic_array4(TX_ANT_NUM-1 downto 0);
signal lut_rdata_i           : std_logic_array44_array16(TX_ANT_NUM downto 0);
signal lut_rdata_q           : std_logic_array44_array16(TX_ANT_NUM downto 0);

signal lut_rdata_sw_i        : std_logic_array44_array16(TX_ANT_NUM-1 downto 0);
signal lut_rdata_sw_q        : std_logic_array44_array16(TX_ANT_NUM-1 downto 0);

signal mag9_sh               : std_logic_array14_array9(TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0'))); 
signal magnitude9            : std_logic_array10_array9(TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0'))); 

signal mag15_sh              : std_logic_array3_array15(TX_ANT_NUM-1 downto 0);
signal mag15_sh_4d           : std_logic_array15(TX_ANT_NUM-1 downto 0);
signal a_mag15_sh_18         : std_logic_array3_array18(TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0')));
signal a_mag15_18_dly        : std_logic_array18(TX_ANT_NUM-1 downto 0);

signal ddr_i                 : std_logic_array2_array31(TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0'))); 
signal ddr_q                 : std_logic_array2_array31(TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0'))); 


signal tap_00_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_00_i_30           : std_logic_array30(TX_ANT_NUM-1 downto 0);            
signal tap_00_i_26           : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_01_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_01_i_34           : std_logic_array34(TX_ANT_NUM-1 downto 0);            
signal tap_02_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_02_i_34           : std_logic_array34(TX_ANT_NUM-1 downto 0);            
signal tap_03_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_04_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_05_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_06_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_07_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_08_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_09_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_00_q              : std_logic_array26(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));            
signal tap_00_q_30           : std_logic_array30(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));            
signal tap_00_q_26           : std_logic_array26(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));            
signal tap_01_q              : std_logic_array26(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));            
signal tap_01_q_34           : std_logic_array34(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));            
signal tap_02_q              : std_logic_array26(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));            
signal tap_02_q_34           : std_logic_array34(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));            
signal tap_03_q              : std_logic_array26(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));            
signal tap_04_q              : std_logic_array26(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));            
signal tap_05_q              : std_logic_array26(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));            
signal tap_06_q              : std_logic_array26(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));            
signal tap_07_q              : std_logic_array26(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));            
signal tap_08_q              : std_logic_array26(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));            
signal tap_09_q              : std_logic_array26(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));            
signal incr_cnt              : std_logic_vector(8 downto 0) := (others=>'0');

signal a_mult_i_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal b_mult_i_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal c_mult_i_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal d_mult_i_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal e_mult_i_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal f_mult_i_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal g_mult_i_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal h_mult_i_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal k_mult_i_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal a_lut_sum_19_i        : std_logic_array19(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal a_lut_sum_19_i_30     : std_logic_array30(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_0_x_0_i       : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_0_x_1_i       : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_0_x_a1_i      : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_1_1_0_i       : std_logic_array29(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_1_0_1_i       : std_logic_array29(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_1_x_a1_i      : std_logic_array29(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_a1_a1_0_i     : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_a1_x_1_i      : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_a1_0_a1_i     : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut9_i_27             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut19_i_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut9_i_27_dly         : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut19_i_27_dly        : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut00_i_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut10_i_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut11_i_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut12_i_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut01_i_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut13_i_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut14_i_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut02_i_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut15_i_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut16_i_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut17_i_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut25_i_30            : std_logic_array30(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut26_i_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut27_i_30            : std_logic_array30(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut28_i_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut29_i_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut30_i_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut31_i_30            : std_logic_array30(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut32_i_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut33_i_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut34_i_30            : std_logic_array30(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut35_i_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut36_i_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut04_i_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut05_i_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut06_i_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut07_i_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut08_i_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp05_i_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp06_i_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp19_i_28            : std_logic_array28(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp20_i_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp20_i_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp20_i_31_dly        : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp21_i_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp22_i_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp23_i_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp24_i_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp24_i_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp24_i_31_dly        : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp25_i_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp26_i_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp27_i_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp25_i_31_dly        : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp26_i_31_dly        : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp27_i_31_dly        : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp28_i_18            : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp28_i_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp28_i_18_dly        : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp29_i_17            : std_logic_array17(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp29_i_26            : std_logic_array26(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));

signal a_mult_q_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal b_mult_q_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal c_mult_q_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal d_mult_q_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal e_mult_q_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal f_mult_q_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal g_mult_q_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal h_mult_q_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal k_mult_q_48           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal a_lut_sum_19_q        : std_logic_array19(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal a_lut_sum_19_q_30     : std_logic_array30(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_0_x_0_q       : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_0_x_1_q       : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_0_x_a1_q      : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_1_1_0_q       : std_logic_array29(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_1_0_1_q       : std_logic_array29(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_1_x_a1_q      : std_logic_array29(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_a1_a1_0_q     : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_a1_x_1_q      : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut_out_a1_0_a1_q     : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut9_q_27             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut19_q_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut9_q_27_dly         : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut19_q_27_dly        : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut00_q_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut10_q_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut11_q_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut12_q_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut01_q_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut13_q_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut14_q_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut02_q_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut15_q_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut16_q_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut17_q_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut25_q_30            : std_logic_array30(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut26_q_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut27_q_30            : std_logic_array30(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut28_q_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut29_q_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut30_q_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut31_q_30            : std_logic_array30(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut32_q_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut33_q_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut34_q_30            : std_logic_array30(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut35_q_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut36_q_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut04_q_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut05_q_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut06_q_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut07_q_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal lut08_q_16            : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp05_q_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp06_q_25            : std_logic_array25(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp19_q_28            : std_logic_array28(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp20_q_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp20_q_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp20_q_31_dly        : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp21_q_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp22_q_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp23_q_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp24_q_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp24_q_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp24_q_31_dly        : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp25_q_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp26_q_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp27_q_31            : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp25_q_31_dly        : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp26_q_31_dly        : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp27_q_31_dly        : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp28_q_18            : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp28_q_27            : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp28_q_18_dly        : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp29_q_17            : std_logic_array17(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));
signal tmp29_q_26            : std_logic_array26(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));

attribute KEEP : string;
attribute KEEP of dpd_lut_output_switch : signal is "TRUE";
attribute KEEP of lut_rdata_sw_i        : signal is "TRUE";
attribute KEEP of lut_rdata_sw_q        : signal is "TRUE";

attribute MAX_FANOUT : integer;
attribute MAX_FANOUT of dpd_lut_output_switch : signal is ternary_func(HS_MODE=TRUE, 20, 2000);

begin

    -- LUT Read Data Align
    G_LUT_RDATA_Assign_TX_ANT : for I in 0 to (TX_ANT_NUM) generate begin
        G_LUT_RDATA_Assign_LUT_RAM : for J in 0 to (LUT_RAM_NUM-1) generate begin
            lut_rdata_i(I)(J) <= LUT_RDATA_IN(I)(J)(31 downto 16); 
            lut_rdata_q(I)(J) <= LUT_RDATA_IN(I)(J)(15 downto  0); 
        end generate;
    end generate;

    G_LUT_Non_Optimized : if (LUT_OPTIMIZED = FALSE) generate begin            
        P_LUT_Rdata_Clocking_Normal_Operation : if (HS_MODE = FALSE) generate begin
            P_LUT_Rdata_Clocking_NM : process(RST, CLK) begin
                if (RST = '1') then
                    lut_rdata_sw_i <= (others => (others => (others => '0')));
                    lut_rdata_sw_q <= (others => (others => (others => '0')));
                elsif (CLK'event) and (CLK = '1') then
                    lut_rdata_sw_i <= lut_rdata_i(TX_ANT_NUM-1 downto 0);
                    lut_rdata_sw_q <= lut_rdata_q(TX_ANT_NUM-1 downto 0);
                end if;
            end process;
        end generate;

        P_LUT_Rdata_Clocking_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
            P_LUT_Rdata_Clocking_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    lut_rdata_sw_i <= lut_rdata_i(TX_ANT_NUM-1 downto 0);
                    lut_rdata_sw_q <= lut_rdata_q(TX_ANT_NUM-1 downto 0);
                end if;
            end process;
        end generate;

        dpd_lut_output_switch <= (others => (others => '0')); 
    end generate;

    G_TX_ANT : for I in 0 to (TX_ANT_NUM-1) generate begin

        mag9_sh(I)(0) <= MAG9(I);

        G_Magnitude_time_shift : for J in 0 to (DPD_TAP_NUM-1) generate begin 
            G_Normal_Operation : if (HS_MODE = FALSE) generate begin
                P_Magnitude_Time_Shift_NM : process(RST, CLK) begin
                    if (RST = '1') then
                        mag9_sh(I)(J+1) <= (others => '0');
                    elsif (CLK'event) and (CLK = '1') then
                        if (LUT_DATA_VLD(I) = '1') then
                            mag9_sh(I)(J+1) <= mag9_sh(I)(J);
                        else
                            mag9_sh(I)(J+1) <= mag9_sh(I)(J+1);
                        end if;
                    end if;
                end process;
            end generate;

            G_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_Magnitude_Time_Shift_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        mag9_sh(I)(J+1) <= mag9_sh(I)(J);
                    end if;
                end process;
            end generate;

        end generate;

        magnitude9(I) <= mag9_sh(I)(DPD_TAP_NUM downto 1);

        -- [Magnitude Index Mapping]==================================================== --
        --                                                                               --
        -- Can Modify according to DPD_CORE eqaution, Always need to check!!             --
        --                                                                               --
        -- ============================================================================= -- 

        -- LUT address decoding  
            -- magnitude9(MAX_ADV-3) --> |x[n+3]|
            -- magnitude9(MAX_ADV-2) --> |x[n+2]|
        -- magnitude9(MAX_ADV-1) --> |x[n+1]|
        -- magnitude9(MAX_ADV+0) --> |x[n-0]|
        -- magnitude9(MAX_ADV+1) --> |x[n-1]|
        -- magnitude9(MAX_ADV+2) --> |x[n-2]|
        -- magnitude9(MAX_ADV+3) --> |x[n-3]|
        -- magnitude9(MAX_ADV+4) --> |x[n-4]|
        -- magnitude9(MAX_ADV+5) --> |x[n-5]|
        -- magnitude9(MAX_ADV+6) --> |x[n-6]|
        -- magnitude9(MAX_ADV+7) --> |x[n-7]|
        -- magnitude9(MAX_ADV+8) --> |x[n-8]|
            -- magnitude9(MAX_ADV+9) --> |x[n-9]|

        -- -- LUT address Encoding  
        -- P_LUT_Address_Encoding_HS : process(CLK) begin
        --     if (CLK'event) and (CLK = '1') then
                -- Diagonal Term                             -- Data# & Mag#
                LUT_ADDR(I)( 0) <= magnitude9(I)(MAX_ADV+0); -- 00   , |x[n-0]|
                LUT_ADDR(I)( 1) <= magnitude9(I)(MAX_ADV+1); -- 01   , |x[n-1]|
                LUT_ADDR(I)( 2) <= magnitude9(I)(MAX_ADV+2); -- 02   , |x[n-2]|
                LUT_ADDR(I)( 3) <= magnitude9(I)(MAX_ADV+3); -- 03   , |x[n-3]|
                LUT_ADDR(I)( 4) <= magnitude9(I)(MAX_ADV+4); -- 04   , |x[n-4]|
                LUT_ADDR(I)( 5) <= magnitude9(I)(MAX_ADV+5); -- 05   , |x[n-5]|
                LUT_ADDR(I)( 6) <= magnitude9(I)(MAX_ADV+6); -- 06   , |x[n-6]|
                LUT_ADDR(I)( 7) <= magnitude9(I)(MAX_ADV+7); -- 07   , |x[n-7]|
                LUT_ADDR(I)( 8) <= magnitude9(I)(MAX_ADV+8); -- 08   , |x[n-8]|
                LUT_ADDR(I)( 9) <= magnitude9(I)(MAX_ADV-1); -- 09   , |x[n+1]|

                -- Off Diagonal Term 
                -- 2D
                LUT_ADDR(I)(10) <= magnitude9(I)(MAX_ADV+1); -- 01   , |x[n-1]|
                LUT_ADDR(I)(11) <= magnitude9(I)(MAX_ADV+2); -- 02   , |x[n-2]|
                LUT_ADDR(I)(12) <= magnitude9(I)(MAX_ADV-1); -- 03   , |x[n+1]|
                LUT_ADDR(I)(13) <= magnitude9(I)(MAX_ADV+0); -- 01   , |x[n-0]|
                LUT_ADDR(I)(14) <= magnitude9(I)(MAX_ADV+2); -- 02   , |x[n-2]|
                LUT_ADDR(I)(15) <= magnitude9(I)(MAX_ADV+0); -- 03   , |x[n-0]|
                LUT_ADDR(I)(16) <= magnitude9(I)(MAX_ADV+1); -- 0A1  , |x[n-1]|
                LUT_ADDR(I)(17) <= magnitude9(I)(MAX_ADV+3); -- 0A2  , |x[n-3]|
                LUT_ADDR(I)(18) <= magnitude9(I)(MAX_ADV+2); -- 10   , |x[n-2]|
                LUT_ADDR(I)(19) <= magnitude9(I)(MAX_ADV+0); -- 12   , |x[n-0]|

                LUT_ADDR(I)(20) <= magnitude9(I)(MAX_ADV+1); -- 20   , |x[nx]|
                LUT_ADDR(I)(21) <= magnitude9(I)(MAX_ADV+2); -- 21   , |x[nx]|
                LUT_ADDR(I)(22) <= magnitude9(I)(MAX_ADV+3); -- 23   , |x[nx]|
                LUT_ADDR(I)(23) <= magnitude9(I)(MAX_ADV+4); -- 30   , |x[nx]|
                LUT_ADDR(I)(24) <= magnitude9(I)(MAX_ADV-1); -- 32   , |x[nx]|
                LUT_ADDR(I)(25) <= magnitude9(I)(MAX_ADV+0); -- A1A2 , |x[nx]|
                LUT_ADDR(I)(26) <= magnitude9(I)(MAX_ADV-1); -- A10  , |x[nx]|
                LUT_ADDR(I)(27) <= magnitude9(I)(MAX_ADV+0); -- A2A1 , |x[nx]|
                LUT_ADDR(I)(28) <= magnitude9(I)(MAX_ADV+1); -- A20  , |x[nx]|

                -- 3D Term
                LUT_ADDR(I)(29) <= magnitude9(I)(MAX_ADV+1); -- A20  , |x[n-0]|
                LUT_ADDR(I)(30) <= magnitude9(I)(MAX_ADV+0); -- 00   , |x[n-1]|
                LUT_ADDR(I)(31) <= magnitude9(I)(MAX_ADV+0); -- 00   , |x[n+1]|
                LUT_ADDR(I)(32) <= magnitude9(I)(MAX_ADV+1); -- 00   , |x[n+1]|
                LUT_ADDR(I)(33) <= magnitude9(I)(MAX_ADV-1); -- 00   , |x[n-0]|
                LUT_ADDR(I)(34) <= magnitude9(I)(MAX_ADV+0); -- 00   , |x[n-1]|
                LUT_ADDR(I)(35) <= magnitude9(I)(MAX_ADV-1); -- 00   , |x[n-1]|
                LUT_ADDR(I)(36) <= magnitude9(I)(MAX_ADV+0); -- 00   , |x[n+1]|

                -- 4D Term
                LUT_ADDR(I)(LUT_4D_START_IDX+0) <= magnitude9(I)(MAX_ADV+1); -- 37  00       , |x[n-1]|
                LUT_ADDR(I)(LUT_4D_START_IDX+1) <= magnitude9(I)(MAX_ADV+0); -- 38  00       , |x[n-0]|
                LUT_ADDR(I)(LUT_4D_START_IDX+2) <= magnitude9(I)(MAX_ADV+1); -- 39  00       , |x[n-1]|
                LUT_ADDR(I)(LUT_4D_START_IDX+3) <= magnitude9(I)(MAX_ADV-1); -- 40  4D Index0, |x[n+1]|
                LUT_ADDR(I)(LUT_4D_START_IDX+4) <= magnitude9(I)(MAX_ADV+1); -- 41  4D Index1, |x[n-1]|
                LUT_ADDR(I)(LUT_4D_START_IDX+5) <= magnitude9(I)(MAX_ADV+0); -- 42  4D Index2, |x[n-0]|
                LUT_ADDR(I)(LUT_4D_START_IDX+6) <= magnitude9(I)(MAX_ADV+0); -- 43  4D Index3, |x[n-0]|
        --     end if;
        -- end process;

        -- 3D Term GEN
        U_MAG15_DLY_COMP : SRL16E_DLY generic map(DEVICE, HS_MODE, 15, DPD_TAP_NUM-2) port map (CLK, MAG15(I), mag15_sh_4d(I));
        -- mag15_sh_4d(I)   <= MAG15(I);
        mag15_sh(I)(0)   <= mag15_sh_4d(I);

        P_MAG15_Shift : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                mag15_sh(I)(1)   <= mag15_sh(I)(0);
                mag15_sh(I)(2)   <= mag15_sh(I)(1);

            end if;
        end process;

        -- 4D_GEN -- 13 clk 
        U_DDR : DPD_3D_LUT44_4D 
        generic map(
            DEVICE                      => DEVICE                      , 
        
            DDR_DLY                     => DDR_DLY                     , 
            LUT_4D_NUM                  => LUT_4D_NUM                  , 
        
            SIGNAL_Q_POINT              => SIGNAL_Q_POINT              ,
            LUT_4D_Q_POINT              => LUT_4D_Q_POINT              ,
            SUM_Q_POINT                 => SUM_Q_POINT                  
            )
        port map(
            RST                         => RST                         , 
            CLK                         => CLK                         , 
           
            LUT_DATA_VLD                => '1'                         , 
            LUT_I_IN                    => lut_rdata_sw_i(I)(LUT_4D_START_IDX+LUT_4D_NUM-1 downto LUT_4D_START_IDX), 
            LUT_Q_IN                    => lut_rdata_sw_q(I)(LUT_4D_START_IDX+LUT_4D_NUM-1 downto LUT_4D_START_IDX), 
        
            MAG_IN                      => mag15_sh_4d(I)              ,
            DATA_I_IN                   => DATA_I_IN(I)                , 
            DATA_Q_IN                   => DATA_Q_IN(I)                , 
        
            DDR_I_OUT                   => ddr_i(I)                    ,
            DDR_Q_OUT                   => ddr_q(I)                      
            );

        -------------------------------------------
        a_mag15_sh_18(I)(0)       <= "000" & mag15_sh(I)(0);
        a_mag15_sh_18(I)(1)       <= "000" & mag15_sh(I)(1);
        a_mag15_sh_18(I)(2)       <= "000" & mag15_sh(I)(2);
        U_MAG15_DLY2     : SRL16E_DLY generic map(DEVICE, HS_MODE, 18, 3) port map (CLK, a_mag15_sh_18(I)(1), a_mag15_18_dly(I));

        -- LUT sum : LUTs have all same (sig, mag3) delay values 
        U_ADD_00_I : ADD8 generic map(HS_MODE,16) port map(RST, CLK, lut_rdata_sw_i(I)(20),lut_rdata_sw_i(I)(21),lut_rdata_sw_i(I)(22),lut_rdata_sw_i(I)(23),lut_rdata_sw_i(I)(24),(others=>'0'),(others=>'0'),(others=>'0'),a_lut_sum_19_i(I));
        U_ADD_00_Q : ADD8 generic map(HS_MODE,16) port map(RST, CLK, lut_rdata_sw_q(I)(20),lut_rdata_sw_q(I)(21),lut_rdata_sw_q(I)(22),lut_rdata_sw_q(I)(23),lut_rdata_sw_q(I)(24),(others=>'0'),(others=>'0'),(others=>'0'),a_lut_sum_19_q(I));
        a_lut_sum_19_i_30(I)   <= sign_extension( a_lut_sum_19_i(I), 30);
        a_lut_sum_19_q_30(I)   <= sign_extension( a_lut_sum_19_q(I), 30);
        U_MULT_00_I : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),a_lut_sum_19_i_30(I),(others=>'0'),a_mag15_18_dly(I),(others=>'0'),open,a_mult_i_48(I),open); 
        U_MULT_00_Q : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),a_lut_sum_19_q_30(I),(others=>'0'),a_mag15_18_dly(I),(others=>'0'),open,a_mult_q_48(I),open); 
        lut_out_0_x_0_i(I)     <= a_mult_i_48(I)(47) & a_mult_i_48(I)(LUT3D_RSHIFT+30-1 downto LUT3D_RSHIFT); --19+15 b
        lut_out_0_x_0_q(I)     <= a_mult_q_48(I)(47) & a_mult_q_48(I)(LUT3D_RSHIFT+30-1 downto LUT3D_RSHIFT);

        lut25_i_30(I)          <= sign_extension( lut_rdata_sw_i(I)(25), 30);
        lut25_q_30(I)          <= sign_extension( lut_rdata_sw_q(I)(25), 30);
        lut26_i_27(I)          <= sign_extension( lut_rdata_sw_i(I)(26), 27);
        lut26_q_27(I)          <= sign_extension( lut_rdata_sw_q(I)(26), 27);
        U_MULT_01_I : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),lut25_i_30(I),lut26_i_27(I),a_mag15_sh_18(I)(2),(others=>'0'),open,b_mult_i_48(I),open); 
        U_MULT_01_Q : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),lut25_q_30(I),lut26_q_27(I),a_mag15_sh_18(I)(2),(others=>'0'),open,b_mult_q_48(I),open); 
        lut_out_0_x_1_i(I)     <= b_mult_i_48(I)(47) & b_mult_i_48(I)(LUT3D_RSHIFT+30-1 downto LUT3D_RSHIFT); -- 17+15 b
        lut_out_0_x_1_q(I)     <= b_mult_q_48(I)(47) & b_mult_q_48(I)(LUT3D_RSHIFT+30-1 downto LUT3D_RSHIFT);
        
        lut27_i_30(I)          <= sign_extension( lut_rdata_sw_i(I)(27), 30);
        lut27_q_30(I)          <= sign_extension( lut_rdata_sw_q(I)(27), 30);
        lut28_i_27(I)          <= sign_extension( lut_rdata_sw_i(I)(28), 27);
        lut28_q_27(I)          <= sign_extension( lut_rdata_sw_q(I)(28), 27);
        U_MULT_02_I : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),lut27_i_30(I),lut28_i_27(I),a_mag15_sh_18(I)(0),(others=>'0'),open,c_mult_i_48(I),open); 
        U_MULT_02_Q : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),lut27_q_30(I),lut28_q_27(I),a_mag15_sh_18(I)(0),(others=>'0'),open,c_mult_q_48(I),open); 
        lut_out_0_x_a1_i(I)    <= c_mult_i_48(I)(47) & c_mult_i_48(I)(LUT3D_RSHIFT+30-1 downto LUT3D_RSHIFT); -- 17+15 b
        lut_out_0_x_a1_q(I)    <= c_mult_q_48(I)(47) & c_mult_q_48(I)(LUT3D_RSHIFT+30-1 downto LUT3D_RSHIFT);

        lut29_i_27(I)          <= sign_extension( lut_rdata_sw_i(I)(29), 27);
        lut29_q_27(I)          <= sign_extension( lut_rdata_sw_q(I)(29), 27);
        U_MULT_03_I : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),lut29_i_27(I),a_mag15_sh_18(I)(1),(others=>'0'),open,d_mult_i_48(I),open); 
        U_MULT_03_Q : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),lut29_q_27(I),a_mag15_sh_18(I)(1),(others=>'0'),open,d_mult_q_48(I),open); 
        lut_out_1_1_0_i(I)     <= d_mult_i_48(I)(47) & d_mult_i_48(I)(LUT3D_RSHIFT+28-1 downto LUT3D_RSHIFT); -- 16+15 b
        lut_out_1_1_0_q(I)     <= d_mult_q_48(I)(47) & d_mult_q_48(I)(LUT3D_RSHIFT+28-1 downto LUT3D_RSHIFT);
        
        lut30_i_27(I)          <= sign_extension( lut_rdata_sw_i(I)(30), 27);
        lut30_q_27(I)          <= sign_extension( lut_rdata_sw_q(I)(30), 27);
        U_MULT_04_I : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),lut30_i_27(I),a_mag15_sh_18(I)(2),(others=>'0'),open,e_mult_i_48(I),open); 
        U_MULT_04_Q : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),lut30_q_27(I),a_mag15_sh_18(I)(2),(others=>'0'),open,e_mult_q_48(I),open); 
        lut_out_1_0_1_i(I)     <= e_mult_i_48(I)(47) & e_mult_i_48(I)(LUT3D_RSHIFT+28-1 downto LUT3D_RSHIFT); -- 16+15 b
        lut_out_1_0_1_q(I)     <= e_mult_q_48(I)(47) & e_mult_q_48(I)(LUT3D_RSHIFT+28-1 downto LUT3D_RSHIFT);
        
        lut31_i_30(I)          <= sign_extension( lut_rdata_sw_i(I)(31), 30);
        lut31_q_30(I)          <= sign_extension( lut_rdata_sw_q(I)(31), 30);
        lut32_i_27(I)          <= sign_extension( lut_rdata_sw_i(I)(32), 27);
        lut32_q_27(I)          <= sign_extension( lut_rdata_sw_q(I)(32), 27);
        U_MULT_05_I : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),lut31_i_30(I),lut32_i_27(I),a_mag15_sh_18(I)(0),(others=>'0'),open,f_mult_i_48(I),open); 
        U_MULT_05_Q : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),lut31_q_30(I),lut32_q_27(I),a_mag15_sh_18(I)(0),(others=>'0'),open,f_mult_q_48(I),open); 
        lut_out_1_x_a1_i(I)    <= f_mult_i_48(I)(47) & f_mult_i_48(I)(LUT3D_RSHIFT+28-1 downto LUT3D_RSHIFT); -- 17+15 b
        lut_out_1_x_a1_q(I)    <= f_mult_q_48(I)(47) & f_mult_q_48(I)(LUT3D_RSHIFT+28-1 downto LUT3D_RSHIFT);
        
        lut33_i_27(I)          <= sign_extension( lut_rdata_sw_i(I)(33), 27);
        lut33_q_27(I)          <= sign_extension( lut_rdata_sw_q(I)(33), 27);
        U_MULT_06_I : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),lut33_i_27(I),a_mag15_sh_18(I)(1),(others=>'0'),open,g_mult_i_48(I),open); 
        U_MULT_06_Q : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),lut33_q_27(I),a_mag15_sh_18(I)(1),(others=>'0'),open,g_mult_q_48(I),open); 
        lut_out_a1_a1_0_i(I)   <= g_mult_i_48(I)(47) & g_mult_i_48(I)(LUT3D_RSHIFT+26-1 downto LUT3D_RSHIFT); -- 16+15 b
        lut_out_a1_a1_0_q(I)   <= g_mult_q_48(I)(47) & g_mult_q_48(I)(LUT3D_RSHIFT+26-1 downto LUT3D_RSHIFT);
        
        lut34_i_30(I)          <= sign_extension( lut_rdata_sw_i(I)(34), 30);
        lut34_q_30(I)          <= sign_extension( lut_rdata_sw_q(I)(34), 30);
        lut35_i_27(I)          <= sign_extension( lut_rdata_sw_i(I)(35), 27);
        lut35_q_27(I)          <= sign_extension( lut_rdata_sw_q(I)(35), 27);
        U_MULT_07_I : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),lut34_i_30(I),lut35_i_27(I),a_mag15_sh_18(I)(2),(others=>'0'),open,h_mult_i_48(I),open); 
        U_MULT_07_Q : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),lut34_q_30(I),lut35_q_27(I),a_mag15_sh_18(I)(2),(others=>'0'),open,h_mult_q_48(I),open); 
        lut_out_a1_x_1_i(I)    <= h_mult_i_48(I)(47) & h_mult_i_48(I)(LUT3D_RSHIFT+26-1 downto LUT3D_RSHIFT); -- 17+15 b
        lut_out_a1_x_1_q(I)    <= h_mult_q_48(I)(47) & h_mult_q_48(I)(LUT3D_RSHIFT+26-1 downto LUT3D_RSHIFT);
        
        lut36_i_27(I)          <= sign_extension( lut_rdata_sw_i(I)(36), 27);
        lut36_q_27(I)          <= sign_extension( lut_rdata_sw_q(I)(36), 27);
        U_MULT_08_I : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),lut36_i_27(I),a_mag15_sh_18(I)(0),(others=>'0'),open,k_mult_i_48(I),open); 
        U_MULT_08_Q : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),lut36_q_27(I),a_mag15_sh_18(I)(0),(others=>'0'),open,k_mult_q_48(I),open); 
        lut_out_a1_0_a1_i(I)   <= k_mult_i_48(I)(47) & k_mult_i_48(I)(LUT3D_RSHIFT+26-1 downto LUT3D_RSHIFT); -- 16+15 b
        lut_out_a1_0_a1_q(I)   <= k_mult_q_48(I)(47) & k_mult_q_48(I)(LUT3D_RSHIFT+26-1 downto LUT3D_RSHIFT);

        -- Sum of LUT output
        -- MPA1 (tap00)
        tmp05_i_25(I)       <= (lut_rdata_sw_i(I)(9)  & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        tmp05_q_25(I)       <= (lut_rdata_sw_q(I)(9)  & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        tmp06_i_25(I)       <= (lut_rdata_sw_i(I)(19) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        tmp06_q_25(I)       <= (lut_rdata_sw_q(I)(19) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut9_i_27(I)        <= sign_extension( tmp05_i_25(I), 27);
        lut9_q_27(I)        <= sign_extension( tmp05_q_25(I), 27);
        lut19_i_27(I)       <= sign_extension( tmp06_i_25(I), 27);
        lut19_q_27(I)       <= sign_extension( tmp06_q_25(I), 27);
        U_TAP0_DLY0_I     : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 4) port map (CLK, lut9_i_27(I), lut9_i_27_dly(I));
        U_TAP0_DLY0_Q     : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 4) port map (CLK, lut9_q_27(I), lut9_q_27_dly(I));
        U_TAP0_DLY1_I     : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 4) port map (CLK, lut19_i_27(I), lut19_i_27_dly(I));
        U_TAP0_DLY1_Q     : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 4) port map (CLK, lut19_q_27(I), lut19_q_27_dly(I));
        -- 4 + 3 clk
        U_ADD_01_I : ADD8 generic map(HS_MODE,27) port map(RST, CLK, lut9_i_27_dly(I),lut19_i_27_dly(I),lut_out_a1_a1_0_i(I),lut_out_a1_x_1_i(I),lut_out_a1_0_a1_i(I),(others=>'0'),(others=>'0'),(others=>'0'),tap_00_i_30(I));
        U_ADD_01_Q : ADD8 generic map(HS_MODE,27) port map(RST, CLK, lut9_q_27_dly(I),lut19_q_27_dly(I),lut_out_a1_a1_0_q(I),lut_out_a1_x_1_q(I),lut_out_a1_0_a1_q(I),(others=>'0'),(others=>'0'),(others=>'0'),tap_00_q_30(I));
        U_SAT_01_I : SAT_SIGN generic map(HS_MODE, 30, 26) port map(RST, CLK, tap_00_i_30(I), tap_00_i_26(I));
        U_SAT_01_Q : SAT_SIGN generic map(HS_MODE, 30, 26) port map(RST, CLK, tap_00_q_30(I), tap_00_q_26(I));
        U_TAP0_DLY2_I     : SRL16E_DLY generic map(DEVICE, HS_MODE, 26, 7) port map (CLK, tap_00_i_26(I), tap_00_i(I)); -- 8
        U_TAP0_DLY2_Q     : SRL16E_DLY generic map(DEVICE, HS_MODE, 26, 7) port map (CLK, tap_00_q_26(I), tap_00_q(I)); -- 8

        -- MP0 (tap01)
        lut00_i_25(I)       <= (lut_rdata_sw_i(I)( 0) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut10_i_25(I)       <= (lut_rdata_sw_i(I)(10) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut11_i_25(I)       <= (lut_rdata_sw_i(I)(11) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut12_i_25(I)       <= (lut_rdata_sw_i(I)(12) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut00_q_25(I)       <= (lut_rdata_sw_q(I)( 0) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut10_q_25(I)       <= (lut_rdata_sw_q(I)(10) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut11_q_25(I)       <= (lut_rdata_sw_q(I)(11) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut12_q_25(I)       <= (lut_rdata_sw_q(I)(12) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        
        U_ADD_02_I : ADD4 generic map(HS_MODE,25) port map(RST, CLK, lut00_i_25(I),lut10_i_25(I),lut11_i_25(I),lut12_i_25(I),tmp20_i_27(I));
        U_ADD_02_Q : ADD4 generic map(HS_MODE,25) port map(RST, CLK, lut00_q_25(I),lut10_q_25(I),lut11_q_25(I),lut12_q_25(I),tmp20_q_27(I));
        tmp20_i_31(I)       <= sign_extension( tmp20_i_27(I), 31);
        tmp20_q_31(I)       <= sign_extension( tmp20_q_27(I), 31);
        U_TAP1_DLY0_I   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 9) port map (CLK, tmp20_i_31(I), tmp20_i_31_dly(I));
        U_TAP1_DLY0_Q   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 9) port map (CLK, tmp20_q_31(I), tmp20_q_31_dly(I));
        
        U_TAP1_DLY1_I   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 5) port map (CLK, lut_out_0_x_0_i(I), tmp21_i_31(I));
        U_TAP1_DLY2_I   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 8) port map (CLK, lut_out_0_x_1_i(I), tmp22_i_31(I));
        U_TAP1_DLY3_I   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 8) port map (CLK, lut_out_0_x_a1_i(I), tmp23_i_31(I));
        U_TAP1_DLY1_Q   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 5) port map (CLK, lut_out_0_x_0_q(I), tmp21_q_31(I));
        U_TAP1_DLY2_Q   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 8) port map (CLK, lut_out_0_x_1_q(I), tmp22_q_31(I));
        U_TAP1_DLY3_Q   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 8) port map (CLK, lut_out_0_x_a1_q(I), tmp23_q_31(I));
        -- 13 clk + 3 clk
        U_ADD_03_I : ADD8 generic map(HS_MODE,31) port map(RST, CLK, tmp20_i_31_dly(I),(others=>'0'),(others=>'0'),(others=>'0'),tmp21_i_31(I),tmp22_i_31(I),tmp23_i_31(I),ddr_i(I)(0),tap_01_i_34(I));
        U_ADD_03_Q : ADD8 generic map(HS_MODE,31) port map(RST, CLK, tmp20_q_31_dly(I),(others=>'0'),(others=>'0'),(others=>'0'),tmp21_q_31(I),tmp22_q_31(I),tmp23_q_31(I),ddr_q(I)(0),tap_01_q_34(I));
        U_SAT_02_I : SAT_SIGN generic map(HS_MODE, 34, 26) port map(RST, CLK, tap_01_i_34(I), tap_01_i(I));
        U_SAT_02_Q : SAT_SIGN generic map(HS_MODE, 34, 26) port map(RST, CLK, tap_01_q_34(I), tap_01_q(I));

        -- MP1 (tap02)
        lut01_i_25(I)       <= (lut_rdata_sw_i(I)( 1) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut13_i_25(I)       <= (lut_rdata_sw_i(I)(13) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut14_i_25(I)       <= (lut_rdata_sw_i(I)(14) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut01_q_25(I)       <= (lut_rdata_sw_q(I)( 1) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut13_q_25(I)       <= (lut_rdata_sw_q(I)(13) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut14_q_25(I)       <= (lut_rdata_sw_q(I)(14) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        U_ADD_04_I : ADD4 generic map(HS_MODE,25) port map(RST, CLK, lut01_i_25(I),lut13_i_25(I),lut14_i_25(I),(others=>'0'),tmp24_i_27(I));
        U_ADD_04_Q : ADD4 generic map(HS_MODE,25) port map(RST, CLK, lut01_q_25(I),lut13_q_25(I),lut14_q_25(I),(others=>'0'),tmp24_q_27(I));
        tmp24_i_31(I)       <= sign_extension(tmp24_i_27(I), 31);
        tmp24_q_31(I)       <= sign_extension(tmp24_q_27(I), 31);
        U_TAP2_DLY0_I   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 7) port map (CLK, tmp24_i_31(I), tmp24_i_31_dly(I));
        U_TAP2_DLY0_Q   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 7) port map (CLK, tmp24_q_31(I), tmp24_q_31_dly(I));
        
        tmp25_i_31(I)       <= sign_extension(lut_out_1_1_0_i(I),  31);
        tmp26_i_31(I)       <= sign_extension(lut_out_1_0_1_i(I),  31);
        tmp27_i_31(I)       <= sign_extension(lut_out_1_x_a1_i(I), 31);
        tmp25_q_31(I)       <= sign_extension(lut_out_1_1_0_q(I),  31);
        tmp26_q_31(I)       <= sign_extension(lut_out_1_0_1_q(I),  31);
        tmp27_q_31(I)       <= sign_extension(lut_out_1_x_a1_q(I), 31);
        U_TAP2_DLY1_I   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 6) port map (CLK, tmp25_i_31(I), tmp25_i_31_dly(I));
        U_TAP2_DLY2_I   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 6) port map (CLK, tmp26_i_31(I), tmp26_i_31_dly(I));
        U_TAP2_DLY3_I   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 6) port map (CLK, tmp27_i_31(I), tmp27_i_31_dly(I));
        U_TAP2_DLY1_Q   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 6) port map (CLK, tmp25_q_31(I), tmp25_q_31_dly(I));
        U_TAP2_DLY2_Q   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 6) port map (CLK, tmp26_q_31(I), tmp26_q_31_dly(I));
        U_TAP2_DLY3_Q   : SRL16E_DLY generic map(DEVICE, HS_MODE, 31, 6) port map (CLK, tmp27_q_31(I), tmp27_q_31_dly(I));
        -- 13 clk + 3 clk
        U_ADD_05_I : ADD8 generic map(HS_MODE,31) port map(RST, CLK, tmp24_i_31_dly(I),(others=>'0'),(others=>'0'),(others=>'0'),tmp25_i_31_dly(I),tmp26_i_31_dly(I),tmp27_i_31_dly(I),ddr_i(I)(1),tap_02_i_34(I));
        U_ADD_05_Q : ADD8 generic map(HS_MODE,31) port map(RST, CLK, tmp24_q_31_dly(I),(others=>'0'),(others=>'0'),(others=>'0'),tmp25_q_31_dly(I),tmp26_q_31_dly(I),tmp27_q_31_dly(I),ddr_q(I)(1),tap_02_q_34(I));
        U_SAT_03_I : SAT_SIGN generic map(HS_MODE, 34, 26) port map(RST, CLK, tap_02_i_34(I), tap_02_i(I));
        U_SAT_03_Q : SAT_SIGN generic map(HS_MODE, 34, 26) port map(RST, CLK, tap_02_q_34(I), tap_02_q(I));

        -- MP2 (tap03)
        lut02_i_16(I)       <= lut_rdata_sw_i(I)( 2); -- & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut15_i_16(I)       <= lut_rdata_sw_i(I)(15); -- & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut16_i_16(I)       <= lut_rdata_sw_i(I)(16); -- & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut17_i_16(I)       <= lut_rdata_sw_i(I)(17); -- & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut02_q_16(I)       <= lut_rdata_sw_q(I)( 2); -- & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut15_q_16(I)       <= lut_rdata_sw_q(I)(15); -- & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut16_q_16(I)       <= lut_rdata_sw_q(I)(16); -- & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        lut17_q_16(I)       <= lut_rdata_sw_q(I)(17); -- & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        U_ADD_06_I : ADD4 generic map(HS_MODE,16) port map(RST, CLK, lut02_i_16(I),lut15_i_16(I),lut16_i_16(I),lut17_i_16(I),tmp28_i_18(I));
        U_ADD_06_Q : ADD4 generic map(HS_MODE,16) port map(RST, CLK, lut02_q_16(I),lut15_q_16(I),lut16_q_16(I),lut17_q_16(I),tmp28_q_18(I));
        U_TAP3_DLY0_I   : SRL16E_DLY generic map(DEVICE, HS_MODE, 18, 14) port map (CLK, tmp28_i_18(I), tmp28_i_18_dly(I));
        U_TAP3_DLY0_Q   : SRL16E_DLY generic map(DEVICE, HS_MODE, 18, 14) port map (CLK, tmp28_q_18(I), tmp28_q_18_dly(I));
        tmp28_i_27(I)       <= (tmp28_i_18_dly(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        tmp28_q_27(I)       <= (tmp28_q_18_dly(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        U_SAT_04_I : SAT_SIGN generic map(HS_MODE, 27, 26) port map(RST, CLK, tmp28_i_27(I), tap_03_i(I));
        U_SAT_04_Q : SAT_SIGN generic map(HS_MODE, 27, 26) port map(RST, CLK, tmp28_q_27(I), tap_03_q(I));

        -- MP3 (tap04)
        process (CLK) begin
            if (CLK'event) and (CLK = '1') then
                tmp29_i_17(I)       <= (lut_rdata_sw_i(I)( 3)(15) & lut_rdata_sw_i(I)( 3)) + (lut_rdata_sw_i(I)(18)(15) & lut_rdata_sw_i(I)(18));
                tmp29_q_17(I)       <= (lut_rdata_sw_q(I)( 3)(15) & lut_rdata_sw_q(I)( 3)) + (lut_rdata_sw_q(I)(18)(15) & lut_rdata_sw_q(I)(18));
            end if;
        end process;
        tmp29_i_26(I)     <= (tmp29_i_17(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        tmp29_q_26(I)     <= (tmp29_q_17(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        U_TAP4_DLY1_I   : SRLC32E_DLY generic map(DEVICE, HS_MODE, 26, 19) port map (CLK, tmp29_i_26(I), open, tap_04_i(I));
        U_TAP4_DLY1_Q   : SRLC32E_DLY generic map(DEVICE, HS_MODE, 26, 19) port map (CLK, tmp29_q_26(I), open, tap_04_q(I));
        -- MP4 (tap05)
        U_TAP5_DLY0_I   : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 21) port map (CLK, lut_rdata_sw_i(I)( 4), open, lut04_i_16(I));
        U_TAP5_DLY0_Q   : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 21) port map (CLK, lut_rdata_sw_q(I)( 4), open, lut04_q_16(I));
        tap_05_i(I)       <= (lut04_i_16(I)(15) & lut04_i_16(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        tap_05_q(I)       <= (lut04_q_16(I)(15) & lut04_q_16(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        -- MP5 (tap06)
        U_TAP6_DLY0_I   : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 22) port map (CLK, lut_rdata_sw_i(I)( 5), open, lut05_i_16(I));
        U_TAP6_DLY0_Q   : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 22) port map (CLK, lut_rdata_sw_q(I)( 5), open, lut05_q_16(I));
        tap_06_i(I)       <= (lut05_i_16(I)(15) & lut05_i_16(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        tap_06_q(I)       <= (lut05_q_16(I)(15) & lut05_q_16(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        -- MP6 (tap07)
        U_TAP7_DLY0_I   : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 23) port map (CLK, lut_rdata_sw_i(I)( 6), open, lut06_i_16(I));
        U_TAP7_DLY0_Q   : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 23) port map (CLK, lut_rdata_sw_q(I)( 6), open, lut06_q_16(I));
        tap_07_i(I)       <= (lut06_i_16(I)(15) & lut06_i_16(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        tap_07_q(I)       <= (lut06_q_16(I)(15) & lut06_q_16(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        -- MP7 (tap08)
        U_TAP8_DLY0_I   : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 24) port map (CLK, lut_rdata_sw_i(I)( 7), open, lut07_i_16(I));
        U_TAP8_DLY0_Q   : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 24) port map (CLK, lut_rdata_sw_q(I)( 7), open, lut07_q_16(I));
        tap_08_i(I)       <= (lut07_i_16(I)(15) & lut07_i_16(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        tap_08_q(I)       <= (lut07_q_16(I)(15) & lut07_q_16(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        -- MP8 (tap09)
        U_TAP9_DLY0_I   : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 25) port map (CLK, lut_rdata_sw_i(I)( 8), open, lut08_i_16(I));
        U_TAP9_DLY0_Q   : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 25) port map (CLK, lut_rdata_sw_q(I)( 8), open, lut08_q_16(I));
        tap_09_i(I)       <= (lut08_i_16(I)(15) & lut08_i_16(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        tap_09_q(I)       <= (lut08_q_16(I)(15) & lut08_q_16(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0));
        
 
        LUT_ADD_I(I)( 0) <=  tap_00_i(I);           
        LUT_ADD_Q(I)( 0) <=  tap_00_q(I);           
        
        LUT_ADD_I(I)( 1) <=  tap_01_i(I);           
        LUT_ADD_Q(I)( 1) <=  tap_01_q(I);           

        U_COEF2_DLY_I   : SRL16E_DLY generic map(DEVICE, HS_MODE, 26, 3) port map (CLK, tap_02_i(I), LUT_ADD_I(I)(2));
        U_COEF2_DLY_Q   : SRL16E_DLY generic map(DEVICE, HS_MODE, 26, 3) port map (CLK, tap_02_q(I), LUT_ADD_Q(I)(2));
                                                                                                                  
        LUT_ADD_I(I)( 3) <=  tap_03_i(I);
        LUT_ADD_Q(I)( 3) <=  tap_03_q(I);
                                                                                                                  
        LUT_ADD_I(I)( 4) <=  tap_04_i(I);
        LUT_ADD_Q(I)( 4) <=  tap_04_q(I);
                                                                                                                  
        LUT_ADD_I(I)( 5) <=  tap_05_i(I);
        LUT_ADD_Q(I)( 5) <=  tap_05_q(I);
        
        LUT_ADD_I(I)( 6) <=  tap_06_i(I);
        LUT_ADD_Q(I)( 6) <=  tap_06_q(I);
                             
        LUT_ADD_I(I)( 7) <=  tap_07_i(I);
        LUT_ADD_Q(I)( 7) <=  tap_07_q(I);
                             
        LUT_ADD_I(I)( 8) <=  tap_08_i(I);                
        LUT_ADD_Q(I)( 8) <=  tap_08_q(I);                
                             
        LUT_ADD_I(I)( 9) <=  tap_09_i(I);                
        LUT_ADD_Q(I)( 9) <=  tap_09_q(I);                
                                                                                                                  
    end generate;

end arc_DPD_3D_LUT44_CONFIG;
