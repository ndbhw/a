-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name : REAL_FIR_FILTER_HOVS1 
-- Project    : 

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
use IEEE.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

-- Symmetry REAL FIR Filter
entity REAL_FIR_FILTER_HOVS1 is
generic(
    DEVICE         : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    SYMMETRY       : string  :=     "ODD"; -- ODD or EVEN
    COEF_NUM       : natural :=       39 ;
    RND_BIT        : natural :=       15
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;

    COEFFICIENT    : in  std_logic_array16(COEF_NUM-1 downto 0);
    DATA_VLD_IN    : in  std_logic;
    DATA_IN        : in  std_logic_vector(15 downto 0);

    DATA_VLD_OUT   : out std_logic;
    DATA_OUT       : out std_logic_vector(15 downto 0)
    );
end REAL_FIR_FILTER_HOVS1;

architecture arc_REAL_FIR_FILTER_HOVS1 of REAL_FIR_FILTER_HOVS1 is

component DSP48E1_REAL_FIR_HOVS1_1st is
generic(
    HS_MODE          : boolean := FALSE ;
    RND_EN           : boolean :=  TRUE ; -- "TRUE" : Using Rounding, "FALSE" : Nonusing Rounding
    RND_BIT          : natural :=    15   -- Rounding Bit
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    DATA_IN          : in  std_logic_vector(29 downto 0);
    DATA_PREADDER    : in  std_logic_vector(24 downto 0);
    COEF_IN          : in  std_logic_vector(17 downto 0);
    DATA_COUT        : out std_logic_vector(29 downto 0);
    RESULT_COUT      : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E1_REAL_FIR_HOVS1_nth is
generic(
    HS_MODE          : boolean := TRUE 
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    DATA_CIN         : in  std_logic_vector(29 downto 0);
    DATA_PREADDER    : in  std_logic_vector(24 downto 0);
    COEF_IN          : in  std_logic_vector(17 downto 0);
    RESULT_CIN       : in  std_logic_vector(47 downto 0);
    DATA_COUT        : out std_logic_vector(29 downto 0);
    RESULT_COUT      : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E1_REAL_FIR_HOVS1_end is
generic(
    HS_MODE          : boolean := TRUE 
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    DATA_CIN         : in  std_logic_vector(29 downto 0);
    DATA_PREADDER    : in  std_logic_vector(24 downto 0);
    COEF_IN          : in  std_logic_vector(17 downto 0);
    RESULT_CIN       : in  std_logic_vector(47 downto 0);
    RESULT           : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E2_REAL_FIR_HOVS1_1st is
generic(
    HS_MODE          : boolean := FALSE ;
    RND_EN           : boolean :=  TRUE ; -- "TRUE" : Using Rounding, "FALSE" : Nonusing Rounding
    RND_BIT          : natural :=    15   -- Rounding Bit
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    DATA_IN          : in  std_logic_vector(29 downto 0);
    DATA_PREADDER    : in  std_logic_vector(26 downto 0);
    COEF_IN          : in  std_logic_vector(17 downto 0);
    DATA_COUT        : out std_logic_vector(29 downto 0);
    RESULT_COUT      : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E2_REAL_FIR_HOVS1_nth is
generic(
    HS_MODE          : boolean := TRUE 
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    DATA_CIN         : in  std_logic_vector(29 downto 0);
    DATA_PREADDER    : in  std_logic_vector(26 downto 0);
    COEF_IN          : in  std_logic_vector(17 downto 0);
    RESULT_CIN       : in  std_logic_vector(47 downto 0);
    DATA_COUT        : out std_logic_vector(29 downto 0);
    RESULT_COUT      : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E2_REAL_FIR_HOVS1_end is
generic(
    HS_MODE          : boolean := TRUE 
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    DATA_CIN         : in  std_logic_vector(29 downto 0);
    DATA_PREADDER    : in  std_logic_vector(26 downto 0);
    COEF_IN          : in  std_logic_vector(17 downto 0);
    RESULT_CIN       : in  std_logic_vector(47 downto 0);
    RESULT           : out std_logic_vector(47 downto 0)
    );
end component;

component SAT_SIGN is
generic(
    HS_MODE          : boolean := TRUE;
    INPUT_BIT        : natural;
    OUTPUT_BIT       : natural 
    );
port( 
    RST              : in  std_logic;
    CLK              : in  std_logic;
    DATA_IN          : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT         : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

signal data_d1              : std_logic_vector(15 downto 0);
signal data_d2              : std_logic_vector(15 downto 0);

signal se_data_symmetry     : std_logic_array27(COEF_NUM-1 downto 0);
signal se_data_symmetry_tmp : std_logic_array16(COEF_NUM-1 downto 0);
signal se_data_chain        : std_logic_array30(COEF_NUM-1 downto 0);

signal se_coef_tap          : std_logic_array18(COEF_NUM-1 downto 0);

signal sum_tab              : std_logic_array48(COEF_NUM downto 1);

signal rnd                  : std_logic_vector(48-RND_BIT downto 0);

-- attribute KEEP : string;
-- attribute KEEP of se_data_symmetry : signal is "TRUE";
-- attribute KEEP of data_d1          : signal is "TRUE";
-- attribute KEEP of data_d2          : signal is "TRUE";
-- 
-- 
-- attribute MAX_FANOUT : integer;
-- attribute MAX_FANOUT of se_data_symmetry : signal is 20;
-- attribute MAX_FANOUT of data_d1          : signal is 20;
-- attribute MAX_FANOUT of data_d2          : signal is 20;

begin

    -- 210617 : FF remove for OPT
    data_d1 <= DATA_IN;
    
    P_Data_Clocking_NM : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            -- data_d1 <= DATA_IN;
            data_d2 <= data_d1;
        end if;
    end process;
	
    -- Sign Extention
    G_COEF_NUM : for I in 0 to (COEF_NUM-1) generate begin
        P_Data_Sign_Extention : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                se_data_symmetry_tmp(I) <= data_d1;
            end if;
        end process;
        -- 210617 : reduce FF
        se_data_symmetry(I) <= sign_extension(se_data_symmetry_tmp(I), 27);
    end generate;

    G_ODD_Sample_Chain_Input : if (SYMMETRY = "ODD") generate begin
        se_data_chain(0) <= sign_extension(data_d2, 30);
    end generate;

    G_Even_Sample_Chain_Input : if (SYMMETRY = "EVEN") generate begin
        P_Fisrt_Sample_1Clock_Delay : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                -- se_data_chain(0) <= data_d2(15)& data_d2(15)& data_d2(15)& data_d2(15)& data_d2(15)& data_d2(15)& data_d2(15)& data_d2(15)& data_d2(15)& data_d2(15)& data_d2(15)& data_d2(15)& data_d2(15)& data_d2(15)& data_d2;
                se_data_chain(0) <= sign_extension(data_d2, 30);
            end if;
        end process;
    end generate;

    G_Sign_Extention_Coefficient : for I in 0 to (COEF_NUM-1) generate begin
        se_coef_tap(COEF_NUM-1-I) <= sign_extension(COEFFICIENT(I), 18);
    end generate;

    -- Calculate convolution
    -- sum_tab[n] = sigma(coef[k] x data[n-k]) (k : 0 to COEF_NUM)
    
    -- DSP48E : Xilinx DSP48 slice, Latency 4 clock
    -- DSP48E_REAL_FIR_HOVS1_1st : RESULT_CHAIN_OUT = {COEFFICIENT * (DATA_IN       + DATA_PREADDER)}
    -- DSP48E_REAL_FIR_HOVS1_nth : RESULT_CHAIN_OUT = {COEFFICIENT * (DATA_CHAIN_IN + DATA_PREADDER)} + RESULT_CHAIN_IN
    -- DSP48E_REAL_FIR_HOVS1_end : RESULT           = {COEFFICIENT * (DATA_CHAIN_IN + DATA_PREADDER)} + RESULT_CHAIN_IN
    G_7Series_DSP48E1 : if (DEVICE = "7SERIES") generate begin
        G_DSP48E1_FIR_TAP : for I in 0 to (COEF_NUM-1) generate begin
            G_DSP48E1_TAP_1ST : if (I = 0) generate begin
                G_DSP48E1_Odd_1st_Tab : if (SYMMETRY = "ODD") generate begin
                    U_DSP48E1_TAP_FIRST  : DSP48E1_REAL_FIR_HOVS1_1st generic map(TRUE, TRUE, RND_BIT) port map(RST, CLK, se_data_chain(I), (others => '0') , se_coef_tap(I), se_data_chain(I+1), sum_tab(I+1));
                end generate;

                G_DSP48E1_Even_1st_Tab : if (SYMMETRY = "EVEN") generate begin
                    U_DSP48E1_TAP_FIRST  : DSP48E1_REAL_FIR_HOVS1_1st generic map(TRUE, TRUE, RND_BIT) port map(RST, CLK, se_data_chain(I), se_data_symmetry(I)(24 downto 0), se_coef_tap(I), se_data_chain(I+1), sum_tab(I+1));
                end generate;
            end generate;
           
            G_DSP48E1_TAP_NTH : if ((I > 0) and (I < COEF_NUM-1)) generate begin
                U_DSP48E1_TAP_MIDDLE : DSP48E1_REAL_FIR_HOVS1_nth generic map(TRUE) port map(RST, CLK, se_data_chain(I), se_data_symmetry(I)(24 downto 0), se_coef_tap(I), sum_tab(I), se_data_chain(I+1), sum_tab(I+1));
            end generate;

            G_DSP48E1_TAP_END : if (I = COEF_NUM-1) generate begin
                U_DSP48E1_TAP_END    : DSP48E1_REAL_FIR_HOVS1_end generic map(TRUE) port map(RST, CLK, se_data_chain(I), se_data_symmetry(I)(24 downto 0), se_coef_tap(I), sum_tab(I), sum_tab(I+1));
            end generate;
        end generate;
    end generate;

    G_UltarScale_DSP48E2 : if (DEVICE = "ULTRASCALE") generate begin
        G_DSP48E2_FIR_TAP : for I in 0 to (COEF_NUM-1) generate begin
            G_DSP48E2_TAP_1ST : if (I = 0) generate begin
                G_DSP48E2_Odd_1st_Tab : if (SYMMETRY = "ODD") generate begin
                    U_DSP48E2_TAP_FIRST  : DSP48E2_REAL_FIR_HOVS1_1st generic map(TRUE, TRUE, RND_BIT) port map(RST, CLK, se_data_chain(I), (others => '0') , se_coef_tap(I), se_data_chain(I+1), sum_tab(I+1));
                end generate;

                G_DSP48E2_Even_1st_Tab : if (SYMMETRY = "EVEN") generate begin
                    U_DSP48E2_TAP_FIRST  : DSP48E2_REAL_FIR_HOVS1_1st generic map(TRUE, TRUE, RND_BIT) port map(RST, CLK, se_data_chain(I), se_data_symmetry(I), se_coef_tap(I), se_data_chain(I+1), sum_tab(I+1));
                end generate;
            end generate;
           
            G_DSP48E2_TAP_NTH : if ((I > 0) and (I < COEF_NUM-1)) generate begin
                U_DSP48E2_TAP_MIDDLE : DSP48E2_REAL_FIR_HOVS1_nth generic map(TRUE) port map(RST, CLK, se_data_chain(I), se_data_symmetry(I), se_coef_tap(I), sum_tab(I), se_data_chain(I+1), sum_tab(I+1));
            end generate;

            G_DSP48E2_TAP_END : if (I = COEF_NUM-1) generate begin
                U_DSP48E2_TAP_END    : DSP48E2_REAL_FIR_HOVS1_end generic map(TRUE) port map(RST, CLK, se_data_chain(I), se_data_symmetry(I), se_coef_tap(I), sum_tab(I), sum_tab(I+1));
            end generate;
        end generate;
    end generate;

    rnd <= sum_tab(COEF_NUM)(47) & sum_tab(COEF_NUM)(47 downto RND_BIT);

    U_SAT : SAT_SIGN generic map (TRUE, 48-RND_BIT+1, 16) port map (RST, CLK, rnd, DATA_OUT);

    DATA_VLD_OUT <= DATA_VLD_IN; 

end arc_REAL_FIR_FILTER_HOVS1;


