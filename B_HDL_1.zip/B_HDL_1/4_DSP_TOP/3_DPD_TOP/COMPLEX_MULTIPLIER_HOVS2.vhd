Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

Library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity COMPLEX_MULTIPLIER_HOVS2 is
generic(
    DEVICE         : string := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2

    INPUT_WIDTH    : natural; -- AIN bitwidth : 0 to 29
    RND_EN         : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT        : natural; -- Rounding bit  
    OUTPUT_WIDTH   : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;

    DATA_VLD_IN    : in  std_logic;
    ADATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    ADATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
                                            
    BDATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    BDATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
   
    DATA_VLD_OUT   : out std_logic;
    DATA_I_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0);
    DATA_Q_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
end COMPLEX_MULTIPLIER_HOVS2;

architecture arc_COMPLEX_MULTIPLIER_HOVS2 of COMPLEX_MULTIPLIER_HOVS2 is

component DSP48E1_MULTIPLIER_WRAPPER is
-- Latency 4 clocks
generic(
    AIN_BITWIDTH : natural; -- AIN bitwidth : 0 to 29
    BIN_BITWIDTH : natural; -- BIN bitwidth : 0 to 17
    RND_EN       : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT      : natural; -- Rounding bit  
    OUTPUT_WIDTH : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;

    ALUMODE      : in  std_logic_vector( 3 downto 0);
    OPMODE       : in  std_logic_vector( 6 downto 0);

    AIN          : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
    BIN          : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
    P            : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
    );
end component;

component DSP48E2_MULTIPLIER_WRAPPER is
-- Latency 4 clocks
generic(
    AIN_BITWIDTH : natural; -- AIN bitwidth : 0 to 29
    BIN_BITWIDTH : natural; -- BIN bitwidth : 0 to 17
    RND_EN       : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT      : natural; -- Rounding bit  
    OUTPUT_WIDTH : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;

    ALUMODE      : in  std_logic_vector( 3 downto 0);
    OPMODE       : in  std_logic_vector( 8 downto 0);

    AIN          : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
    BIN          : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
    P            : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
    );
end component;

constant zeros          : std_logic_vector( 3 downto 0) := (others => '0');

signal sample_i_a_align : std_logic_vector(INPUT_WIDTH-1 downto 0);
signal sample_q_a_align : std_logic_vector(INPUT_WIDTH-1 downto 0);
                
signal sample_i_b_align : std_logic_vector(INPUT_WIDTH-1 downto 0);
signal sample_q_b_align : std_logic_vector(INPUT_WIDTH-1 downto 0);

signal sample_iq_a      : std_logic_vector(INPUT_WIDTH-1 downto 0);

signal sample_iq_b      : std_logic_vector(INPUT_WIDTH-1 downto 0);
signal sample_qi_b      : std_logic_vector(INPUT_WIDTH-1 downto 0);

signal alumode_i        : std_logic_vector( 3 downto 0);
signal alumode_q        : std_logic_vector( 3 downto 0);
signal opmode           : std_logic_vector( 8 downto 0);

signal i_acmbd          : std_logic_vector(OUTPUT_WIDTH-1 downto 0);
signal q_adpbc          : std_logic_vector(OUTPUT_WIDTH-1 downto 0);

signal result_vld       : std_logic;
signal result_i         : std_logic_vector(OUTPUT_WIDTH-1 downto 0);
signal result_q         : std_logic_vector(OUTPUT_WIDTH-1 downto 0);

begin

    P_IQ_Sample_Align : process(RST, CLK) begin
        if (RST = '1') then
            sample_i_a_align <= (others => '0');
            sample_q_a_align <= (others => '0');
                     
            sample_i_b_align <= (others => '0');
            sample_q_b_align <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (DATA_VLD_IN = '0') then
                sample_i_a_align <= ADATA_I_IN;
                sample_q_a_align <= ADATA_Q_IN;
                         
                sample_i_b_align <= BDATA_I_IN;
                sample_q_b_align <= BDATA_Q_IN;
            else
                sample_i_a_align <= sample_i_a_align ;
                sample_q_a_align <= sample_q_a_align ;
                                             
                sample_i_b_align <= sample_i_b_align ;
                sample_q_b_align <= sample_q_b_align ;
            end if;
        end if;
    end process;

    P_IQ_Sample_Time_Mux : process(RST, CLK) begin
        if (RST = '1') then
            sample_iq_a <= (others => '0'); 
            
            sample_iq_b <= (others => '0'); 
            sample_qi_b <= (others => '0'); 
        elsif (CLK'event) and (CLK = '1') then
            if (DATA_VLD_IN = '1') then
                sample_iq_a <= sample_i_a_align; 
                
                sample_iq_b <= sample_i_b_align; 
                sample_qi_b <= sample_q_b_align; 
            else
                sample_iq_a <= sample_q_a_align; 
                                               
                sample_iq_b <= sample_q_b_align; 
                sample_qi_b <= sample_i_b_align; 
            end if;
        end if;
    end process;

    P_DSP48E1_Operation_Control : process(RST, CLK) begin
        if (RST = '1') then
            alumode_i  <= (others => '0');
            alumode_q  <= (others => '0');
            opmode     <= "000110101"; -- Rounding, C_IN calculate
        elsif (CLK'event) and (CLK = '1') then
            alumode_q  <= zeros;

            if (DATA_VLD_IN = '1') then
                alumode_i  <= "0000";    -- A*B
                opmode     <= "000110101"; -- Rounding, C_IN calculation
            else
                alumode_i  <= "0011";    -- P-(A*B)
                opmode     <= "000100101"; -- Internal P calculation
            end if;
        end if;
    end process;

    G_7Series_DSP48E1 : if (DEVICE = "7SERIES") generate begin
        U_DSP48E1_Complex_MULT_I : DSP48E1_MULTIPLIER_WRAPPER generic map(INPUT_WIDTH, INPUT_WIDTH, TRUE, RND_BIT, OUTPUT_WIDTH) port map(RST, CLK, alumode_i, opmode(6 downto 0), sample_iq_a, sample_iq_b, i_acmbd); -- (i_A*i_B)-(q_A*q_B)      
        U_DSP48E1_Complex_MULT_Q : DSP48E1_MULTIPLIER_WRAPPER generic map(INPUT_WIDTH, INPUT_WIDTH, TRUE, RND_BIT, OUTPUT_WIDTH) port map(RST, CLK, alumode_q, opmode(6 downto 0), sample_iq_a, sample_qi_b, q_adpbc); -- (i_A*q_B)+(q_A*i_B)     
    end generate;

    G_UltraScale_DSP48E2 : if (DEVICE = "ULTRASCALE") generate begin
        U_DSP48E2_Complex_MULT_I : DSP48E2_MULTIPLIER_WRAPPER generic map(INPUT_WIDTH, INPUT_WIDTH, TRUE, RND_BIT, OUTPUT_WIDTH) port map(RST, CLK, alumode_i, opmode,             sample_iq_a, sample_iq_b, i_acmbd); -- (i_A*i_B)-(q_A*q_B)      
        U_DSP48E2_Complex_MULT_Q : DSP48E2_MULTIPLIER_WRAPPER generic map(INPUT_WIDTH, INPUT_WIDTH, TRUE, RND_BIT, OUTPUT_WIDTH) port map(RST, CLK, alumode_q, opmode,             sample_iq_a, sample_qi_b, q_adpbc); -- (i_A*q_B)+(q_A*i_B)     
    end generate;

    P_Output_Align : process(RST, CLK) begin
        if (RST = '1') then
            result_vld <= '0';
            result_i     <= (others => '0');
            result_q     <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            result_vld <= DATA_VLD_IN;

            if (DATA_VLD_IN = '1') then
                result_i <= i_acmbd;
                result_q <= q_adpbc;
            else
                result_i <= result_i;
                result_q <= result_q;
            end if;
        end if;
    end process;

    DATA_VLD_OUT   <= result_vld; 
    DATA_I_OUT     <= result_i;
    DATA_Q_OUT     <= result_q; 

end arc_COMPLEX_MULTIPLIER_HOVS2;
