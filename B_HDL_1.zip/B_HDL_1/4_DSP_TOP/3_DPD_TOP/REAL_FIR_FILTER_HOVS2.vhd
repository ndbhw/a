-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name : REAL_FIR_FILTER_HOVS1 
-- Project    : 

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
use IEEE.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

-- Symmetry REAL FIR Filter
entity REAL_FIR_FILTER_HOVS2 is
generic(
    DEVICE         : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    SYMMETRY       : string  :=     "ODD"; -- ODD or EVEN
    COEF_NUM       : natural :=       39 ;
    RND_BIT        : natural :=       15
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;

    COEFFICIENT    : in  std_logic_array16(COEF_NUM-1 downto 0);
    DATA_VALID_IN  : in  std_logic;
    DATA_IN        : in  std_logic_vector(15 downto 0);

    DATA_VALID_OUT : out std_logic;
    DATA_OUT       : out std_logic_vector(15 downto 0)
    );
end REAL_FIR_FILTER_HOVS2;

architecture arc_REAL_FIR_FILTER_HOVS2 of REAL_FIR_FILTER_HOVS2 is

component SRL16E_WRAP is
generic(
    DEVICE    : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    BIT_WIDTH : natural
    );
port(
    CLK      : IN STD_LOGIC;
    DATA_IN  : IN STD_LOGIC_VECTOR(BIT_WIDTH-1 downto 0);
    SEL_DLY  : IN STD_LOGIC_VECTOR(3 downto 0);  -- Select Delay, 0 ~ 15 => 0 ~ 15 clk delay
    DATA_OUT : OUT STD_LOGIC_VECTOR(BIT_WIDTH-1 downto 0) -- Delayed DATA
    );
end component;

component DSP48E1_REAL_FIR_HOVSn_1st is
generic(
    RND_EN           : boolean; -- "TRUE" : Using Rounding, "FALSE" : Nonusing Rounding
    RND_BIT          : natural  -- Rounding Bit
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;

    OPMODE           : in  std_logic_vector( 6 downto 0);

    DATA_IN          : in  std_logic_vector(29 DOWNTO 0);
    DATA_PREADDER    : in  std_logic_vector(24 DOWNTO 0);
    COEFFICIENT      : in  std_logic_vector(17 DOWNTO 0);

    RESULT_CHAIN_OUT : out std_logic_vector(47 DOWNTO 0)
    );
end component;

component DSP48E1_REAL_FIR_HOVSn_nth is
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    
    OPMODE           : in  std_logic_vector( 6 downto 0);
    
    DATA_IN          : in  std_logic_vector(29 DOWNTO 0);
    DATA_PREADDER    : in  std_logic_vector(24 DOWNTO 0);
    COEFFICIENT      : in  std_logic_vector(17 DOWNTO 0);
    
    RESULT_CHAIN_IN  : in  std_logic_vector(47 DOWNTO 0);

    RESULT_CHAIN_OUT : out std_logic_vector(47 DOWNTO 0)
    );
end component;

component DSP48E1_REAL_FIR_HOVSn_end is
port(
    RST             : in  std_logic;
    CLK             : in  std_logic;
    
    OPMODE          : in  std_logic_vector( 6 downto 0);
    
    DATA_IN         : in  std_logic_vector(29 DOWNTO 0);
    DATA_PREADDER   : in  std_logic_vector(24 DOWNTO 0);
    COEFFICIENT     : in  std_logic_vector(17 DOWNTO 0);

    RESULT_CHAIN_IN : in  std_logic_vector(47 DOWNTO 0);

    RESULT          : out std_logic_vector(47 DOWNTO 0)
    );
end component;

component DSP48E2_REAL_FIR_HOVSn_1st is
generic(
    RND_EN           : boolean; -- "TRUE" : Using Rounding, "FALSE" : Nonusing Rounding
    RND_BIT          : natural  -- Rounding Bit
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;

    OPMODE           : in  std_logic_vector( 8 downto 0);

    DATA_IN          : in  std_logic_vector(29 DOWNTO 0);
    DATA_PREADDER    : in  std_logic_vector(26 DOWNTO 0);
    COEFFICIENT      : in  std_logic_vector(17 DOWNTO 0);

    RESULT_CHAIN_OUT : out std_logic_vector(47 DOWNTO 0)
    );
end component;

component DSP48E2_REAL_FIR_HOVSn_nth is
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    
    OPMODE           : in  std_logic_vector( 8 downto 0);
    
    DATA_IN          : in  std_logic_vector(29 DOWNTO 0);
    DATA_PREADDER    : in  std_logic_vector(26 DOWNTO 0);
    COEFFICIENT      : in  std_logic_vector(17 DOWNTO 0);
    
    RESULT_CHAIN_IN  : in  std_logic_vector(47 DOWNTO 0);

    RESULT_CHAIN_OUT : out std_logic_vector(47 DOWNTO 0)
    );
end component;

component DSP48E2_REAL_FIR_HOVSn_end is
port(
    RST             : in  std_logic;
    CLK             : in  std_logic;
    
    OPMODE          : in  std_logic_vector( 8 downto 0);
    
    DATA_IN         : in  std_logic_vector(29 DOWNTO 0);
    DATA_PREADDER   : in  std_logic_vector(26 DOWNTO 0);
    COEFFICIENT     : in  std_logic_vector(17 DOWNTO 0);

    RESULT_CHAIN_IN : in  std_logic_vector(47 DOWNTO 0);

    RESULT          : out std_logic_vector(47 DOWNTO 0)
    );
end component;

component SAT_SIGN is
generic(
    HS_MODE    : boolean := FALSE;
    INPUT_BIT  : integer;
    OUTPUT_BIT : integer
    );
port( 
    RST        : in  std_logic;
    CLK        : in  std_logic;
    DATA_IN    : in  std_logic_vector(INPUT_BIT-1  downto 0);
    DATA_OUT   : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

signal srl_dly_fwd       : std_logic_vector( 3 downto 0);
signal srl_dly_cen       : std_logic_vector( 3 downto 0);
signal srl_dly_rvs       : std_logic_vector( 3 downto 0);

signal opmode_tap_1st    : std_logic_vector( 8 downto 0);
signal opmode_tap_nth    : std_logic_vector( 8 downto 0);

signal data              : std_logic_vector(15 downto 0);
signal data_fwd          : std_logic_array16((COEF_NUM-1)/2 downto 0);
signal data_rvs          : std_logic_array16((COEF_NUM-1)/2 downto 0);

signal df_f              : std_logic_array16((COEF_NUM-1)/2 downto 0);
signal dr_f              : std_logic_array16((COEF_NUM-1)/2 downto 0);

signal se_data_fwd       : std_logic_array30((COEF_NUM-1)/2 downto 0);
signal se_data_rvs       : std_logic_array27((COEF_NUM-1)/2 downto 0);

signal coef_fir          : std_logic_array16(COEF_NUM downto 0);
signal coef_mux          : std_logic_array16((COEF_NUM-1)/2 downto 0);

signal se_coef           : std_logic_array18((COEF_NUM-1)/2 downto 0);

signal sum_tap           : std_logic_array48((COEF_NUM-1)/2 downto 0);  

signal rnd               : std_logic_vector(48-RND_BIT downto 0);
signal sat               : std_logic_vector(15 downto 0);

signal filter_valid      : std_logic;
signal filter_out        : std_logic_vector(15 downto 0);


begin

-- dsp48_os_d = {(A[n]+D[n])*B[n]} + {(A[n-1]+D[n-1])*B[n-1]}
-- dsp48_os_e = {(A[n]+D[n])*B[n]} + {(A[n-1]+D[n-1])*B[n-1]} + PCIN
-- dsp48_os_f = {(A[n]+D[n])*B[n]} + {(A[n-1]+D[n-1])*B[n-1]} + PCIN

    P_OPMODE_CTRL : process(RST, CLK) begin
        if (RST = '1') then
            opmode_tap_1st <= (others => '0');
            opmode_tap_nth <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (DATA_VALID_IN = '1') then
                opmode_tap_1st <= "000110101"; -- RND  calculate
                opmode_tap_nth <= "000010101"; -- PCIN calculate
            else         
                opmode_tap_1st <= "000100101"; -- internal P calculate
                opmode_tap_nth <= "000100101"; -- internal P calculate
            end if;
        end if;
    end process;

    P_Data_Align : process(RST, CLK) begin
        if (RST = '1') then
            data <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (DATA_VALID_IN = '1') then
                data <= DATA_IN;
            else
                data <= data;
            end if;
        end if;
    end process;

    data_fwd(0) <= data;

    G_Even_Symmetry_Data_Array_Align : if (SYMMETRY = "EVEN") generate begin

        P_SRL16E_Delay_CTRL : process(RST, CLK) begin
            if (RST = '1') then
                srl_dly_fwd <= (others => '0');
                srl_dly_cen <= (others => '0');
                srl_dly_rvs <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                if (DATA_VALID_IN = '1') then
                    srl_dly_fwd <= x"0";
                    srl_dly_cen <= x"4";
                    srl_dly_rvs <= x"5";
                else
                    srl_dly_fwd <= x"2";
                    srl_dly_cen <= x"1";
                    srl_dly_rvs <= x"2";
                end if;
            end if;
        end process;
    
        G_Sample_Time_Mux : for I in 0 to ((COEF_NUM-1)/2) generate begin
            G_Tab_FWD_RVS : if (I < (COEF_NUM-1)/2) generate begin
                U_Forward : SRL16E_WRAP generic map(DEVICE, 16) port map(CLK, data_fwd(I),                  srl_dly_fwd, data_fwd(I+1));
                U_Reverse : SRL16E_WRAP generic map(DEVICE, 16) port map(CLK, data_rvs(((COEF_NUM-1)/2)-I), srl_dly_rvs, data_rvs(((COEF_NUM-1)/2)-I-1));
            end generate;
 
            G_Tab_Center  : if (I = (COEF_NUM-1)/2) generate begin
                U_Center  : SRL16E_WRAP generic map(DEVICE, 16) port map(CLK, data_fwd(I),                  srl_dly_cen, data_rvs(I));
            end generate;
        end generate;

        P_SRL16_Output_Clocking : process(RST, CLK) begin
            if (RST = '1') then
                df_f <= (others => (others => '0'));
                dr_f <= (others => (others => '0'));
            elsif (CLK'event) and (CLK = '1') then
                df_f <= data_fwd;
                dr_f <= data_rvs;
            end if;
        end process;

    end generate;

    G_Odd_Symmetry_Data_Array_Align : if (SYMMETRY = "ODD") generate begin

        P_SRL16E_Delay_CTRL : process(RST, CLK) begin
            if (RST = '1') then
                srl_dly_fwd <= (others => '0');
                srl_dly_cen <= (others => '0');
                srl_dly_rvs <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                if (DATA_VALID_IN = '1') then
                    srl_dly_fwd <= x"0";
                    srl_dly_cen <= x"2";
                    srl_dly_rvs <= x"5";
                else
                    srl_dly_fwd <= x"2";
                    srl_dly_cen <= x"1";
                    srl_dly_rvs <= x"2";
                end if;
            end if;
        end process;
    
        G_Sample_Time_Mux : for I in 0 to ((COEF_NUM-1)/2) generate begin
            G_Tab_FWD_RVS : if (I < (COEF_NUM-1)/2) generate begin
                U_Forward : SRL16E_WRAP generic map(DEVICE, 16) port map(CLK, data_fwd(I),                  srl_dly_fwd, data_fwd(I+1));
                U_Reverse : SRL16E_WRAP generic map(DEVICE, 16) port map(CLK, data_rvs(((COEF_NUM-1)/2)-I), srl_dly_rvs, data_rvs(((COEF_NUM-1)/2)-I-1));

                P_SRL16_FWD_RVS_Output_Clocking : process(RST, CLK) begin
                    if (RST = '1') then
                        df_f(I) <= (others => '0');
                        dr_f(I) <= (others => '0');
                    elsif (CLK'event) and (CLK = '1') then
                        df_f(I) <= data_fwd(I);
                        dr_f(I) <= data_rvs(I);
                    end if;
                end process;

            end generate;
 
            G_Tab_Center  : if (I = (COEF_NUM-1)/2) generate begin
                U_Center  : SRL16E_WRAP generic map(DEVICE, 16) port map(CLK, data_fwd(I),                  srl_dly_cen, data_rvs(I));

                P_SRL16_Center_Output_Clocking : process(RST, CLK) begin
                    if (RST = '1') then
                        df_f(I) <= (others => '0');
                        dr_f(I) <= (others => '0');
                    elsif (CLK'event) and (CLK = '1') then
                        df_f(I) <= data_fwd(I);

                        if (DATA_VALID_IN = '1') then
                            dr_f(I) <= (others => '0');
                        else
                            dr_f(I) <= data_rvs(I);
                        end if;
                    end if;
                end process;

            end generate;
        end generate;

    end generate;

    G_Sample_Sign_Extention : for I in 0 to (COEF_NUM-1)/2 generate begin 
        se_data_fwd(I) <= sign_extension(df_f(I), 30);
        se_data_rvs(I) <= sign_extension(dr_f(I), 27);
    end generate;

    G_NUM_of_COEF_is_ODD : if ((COEF_NUM mod 2) > 0) generate begin
        G_Coeff_assign_odd : for I in 0 to COEF_NUM generate begin
            G_1st_tap_coef_odd : if (I = 0) generate begin
                coef_fir(I) <= (others => '0');
            end generate;
 
            G_nth_tap_coef_odd : if (I > 0) generate begin
                coef_fir(I) <= COEFFICIENT(I-1);
            end generate;
        end generate;
    end generate;

    G_NUM_of_COEF_is_EVEN : if ((COEF_NUM mod 2) = 0) generate begin
        G_Coeff_assign_even : for I in 0 to COEF_NUM generate begin
            G_nth_tap_coef_even : if (I < COEF_NUM) generate begin
                coef_fir(I) <= COEFFICIENT(I);
            end generate;

            G_end_tap_coef_even : if (I = COEF_NUM) generate begin
                coef_fir(I) <= (others => '0');
            end generate;
        end generate;
    end generate;

    G_FIR_COEF_Time_MUX : for I in 0 to (COEF_NUM-1)/2 generate begin 
        P_FIR_COEF_Time_MUX : process(RST, CLK) begin
            if (RST = '1') then
                coef_mux(I) <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                if (DATA_VALID_IN = '0') then
                    coef_mux(I) <= coef_fir(2*I);
                else
                    coef_mux(I) <= coef_fir(2*I+1);
                end if;
            end if;
        end process;

        se_coef(I) <= sign_extension(coef_mux(I), 18);

    end generate;

    G_7Series_DSP48E1 : if (DEVICE = "7SERIES") generate begin
        G_DSP48E1_REAL_FIR_TAP : for I in 0 to ((COEF_NUM-1)/2) generate begin
            G_DSP48E1_1st_TAP : if (I = 0) generate begin
                U_DSP48E1_1st_TAP : DSP48E1_REAL_FIR_HOVSn_1st generic map(TRUE, RND_BIT) port map(RST, CLK, opmode_tap_1st(6 downto 0), se_data_fwd(((COEF_NUM-1)/2)-I), se_data_rvs(((COEF_NUM-1)/2)-I)(24 downto 0), se_coef(((COEF_NUM-1)/2)-I), sum_tap(I));
            end generate;

            G_DSP48E1_nth_TAP : if ((I > 0) and (I < (COEF_NUM-1)/2)) generate begin
                U_DSP48E1_nth_TAP : DSP48E1_REAL_FIR_HOVSn_nth port map(RST, CLK, opmode_tap_nth(6 downto 0), se_data_fwd(((COEF_NUM-1)/2)-I), se_data_rvs(((COEF_NUM-1)/2)-I)(24 downto 0), se_coef(((COEF_NUM-1)/2)-I), sum_tap(I-1), sum_tap(I)); 
            end generate;                                                               
                                                                                        
            G_DSP48E1_end_TAP : if (I = (COEF_NUM-1)/2) generate begin                          
                U_DSP48E1_end_TAP : DSP48E1_REAL_FIR_HOVSn_end port map(RST, CLK, opmode_tap_nth(6 downto 0), se_data_fwd(((COEF_NUM-1)/2)-I), se_data_rvs(((COEF_NUM-1)/2)-I)(24 downto 0), se_coef(((COEF_NUM-1)/2)-I), sum_tap(I-1), sum_tap(I)); 
            end generate;
        end generate;
    end generate;

    G_UltraScale_DSP48E2 : if (DEVICE = "ULTRASCALE") generate begin
        G_DSP48E2_REAL_FIR_TAP : for I in 0 to ((COEF_NUM-1)/2) generate begin
            G_DSP48E2_1st_TAP : if (I = 0) generate begin
                U_DSP48E2_1st_TAP : DSP48E2_REAL_FIR_HOVSn_1st generic map(TRUE, RND_BIT) port map(RST, CLK, opmode_tap_1st, se_data_fwd(((COEF_NUM-1)/2)-I), se_data_rvs(((COEF_NUM-1)/2)-I), se_coef(((COEF_NUM-1)/2)-I), sum_tap(I));
            end generate;

            G_DSP48E2_nth_TAP : if ((I > 0) and (I < (COEF_NUM-1)/2)) generate begin
                U_DSP48E2_nth_TAP : DSP48E2_REAL_FIR_HOVSn_nth port map(RST, CLK, opmode_tap_nth, se_data_fwd(((COEF_NUM-1)/2)-I), se_data_rvs(((COEF_NUM-1)/2)-I), se_coef(((COEF_NUM-1)/2)-I), sum_tap(I-1), sum_tap(I)); 
            end generate;                                                                   
                                                                                            
            G_DSP48E2_end_TAP : if (I = (COEF_NUM-1)/2) generate begin                          
                U_DSP48E2_end_TAP : DSP48E2_REAL_FIR_HOVSn_end port map(RST, CLK, opmode_tap_nth, se_data_fwd(((COEF_NUM-1)/2)-I), se_data_rvs(((COEF_NUM-1)/2)-I), se_coef(((COEF_NUM-1)/2)-I), sum_tap(I-1), sum_tap(I)); 
            end generate;
        end generate;
    end generate;

    P_FIR_Valid_Data : process(RST, CLK) begin
        if (RST = '1') then
            rnd <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (DATA_VALID_IN = '1') then
                rnd <= sum_tap((COEF_NUM-1)/2)(47) & sum_tap((COEF_NUM-1)/2)(47 downto RND_BIT);
            else
                rnd <= rnd;
            end if;
        end if;
    end process;

    U_Saturation : SAT_SIGN generic map(FALSE, 48-RND_BIT+1, 16) port map(RST, CLK, rnd, sat); 

    P_Filter_Output_Align : process(RST, CLK) begin
        if (RST = '1') then
            filter_valid <= '0';      
            filter_out   <= (others => '0');      
        elsif (CLK'event) and (CLK = '1') then
            filter_valid <= DATA_VALID_IN;      
   
            if (DATA_VALID_IN = '1') then
                filter_out <= sat;      
            else
                filter_out <= filter_out;      
            end if;
        end if;
    end process;

    DATA_VALID_OUT <= filter_valid; 
    DATA_OUT       <= filter_out; 

end arc_REAL_FIR_FILTER_HOVS2;


