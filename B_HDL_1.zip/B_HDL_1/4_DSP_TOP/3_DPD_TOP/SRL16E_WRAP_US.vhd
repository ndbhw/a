--   SRL16E    : In order to incorporate this function into the design,
--    VHDL     : the following instance declaration needs to be placed
--  instance   : in the architecture body of the design code.  The
-- declaration : instance name (SRL16E_inst) and/or the port declarations
--    code     : after the "=>" assignment maybe changed to properly
--             : reference and connect this function to the design.
--             : All inputs and outputs must be connected.

--   Library   : In addition to adding the instance declaration, a use
-- declaration : statement for the UNISIM.vcomponents library needs to be
--     for     : added before the entity declaration.  This library
--   Xilinx    : contains the component declarations for all Xilinx
--  primitives : primitives and points to the models that will be used
--             : for simulation.

--  Copy the following two statements and paste them before the
--  Entity declaration, unless they already exist.

Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

Library UNISIM;
use UNISIM.vcomponents.all;

entity SRL16E_WRAP_US is
generic(
    BIT_WIDTH : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    SEL_DLY   : in  std_logic_vector( 3 downto 0);         -- Select Delay, 0 ~ 15 => 0 ~ 15 clk delay
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0) -- Delayed DATA
    );
end SRL16E_WRAP_US;

architecture arc_SRL16E_WRAP_US of SRL16E_WRAP_US is

begin	
--  <-----Cut code below this line and paste into the architecture body---->

    G_SRL16E_INST_GEN : for I in 0 to (BIT_WIDTH-1) generate begin
        -- SRL16E: 16-Bit Shift Register Look-Up Table (LUT)
        --         Kintex UltraScale+
        -- Xilinx HDL Language Template, version 2016.3
        SRL16E_inst : SRL16E
        generic map(
            INIT            => X"0000"    , -- Initial contents of shift register 
            IS_CLK_INVERTED =>     '0'      -- Optional inversion for CLK
            )
        port map(
            Q               => DATA_OUT(I), -- 1-bit output: SRL Data
            CE              => '1'        , -- 1-bit input: Clock enable
            CLK             => CLK        , -- 1-bit input: Clock
            D               => DATA_IN(I) , -- 1-bit input: SRL Data
            -- Depth Selection inputs: A0-A3 select SRL depth
            A0              => SEL_DLY(0) ,
            A1              => SEL_DLY(1) ,
            A2              => SEL_DLY(2) ,
            A3              => SEL_DLY(3) 
            );
        -- End of SRL16E_inst instantiation
    end generate;

end arc_SRL16E_WRAP_US;
