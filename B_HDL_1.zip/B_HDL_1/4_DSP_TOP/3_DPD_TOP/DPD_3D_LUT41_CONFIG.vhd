library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity DPD_3D_LUT41_CONFIG is
generic(
    DEVICE                   : string  := "ULTRASCALE";
    HS_MODE                  : boolean :=       FALSE ;
    TX_ANT_NUM               : natural :=           4 ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_RAM_NUM              : natural :=          41 ;
    DPD_TAP_NUM              : natural :=          13
    );
port(
    RST                      : in  std_logic;
    CLK                      : in  std_logic;
   
    LUT_DATA_VLD             : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    MAG9                     : in  std_logic_array9( TX_ANT_NUM-1 downto 0);
    MAG15                    : in  std_logic_array15(TX_ANT_NUM-1 downto 0);
    LUT_ADDR                 : out std_logic_array41_array9( TX_ANT_NUM-1 downto 0);

    DATA_I_IN                : in  std_logic_array16(TX_ANT_NUM-1 downto 0); 
    DATA_Q_IN                : in  std_logic_array16(TX_ANT_NUM-1 downto 0); 

    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);
    LUT_RDATA_IN             : in  std_logic_array41_array32(TX_ANT_NUM downto 0);

    LUT_ADD_I                : out std_logic_array13_array27(TX_ANT_NUM-1 downto 0);
    LUT_ADD_Q                : out std_logic_array13_array27(TX_ANT_NUM-1 downto 0)
    );
end DPD_3D_LUT41_CONFIG;

architecture arc_DPD_3D_LUT41_CONFIG of DPD_3D_LUT41_CONFIG is

constant DDR_DLY             : integer :=  2 ;
constant MAX_ADV             : integer :=  3;
constant DDR_LUT_START_IDX   : integer :=  35;
constant SIGNAL_Q_POINT      : integer :=  15;
constant SUM_Q_POINT         : integer :=  22;
constant LUT_Q_POINT         : integer :=  13;
constant LUT3D_Q_POINT       : integer :=  12;
constant LUT_DDR_Q_POINT     : integer :=  12;
constant zeros               : std_logic_vector(31 downto 0) := (others => '0');

component ADD4 is
generic(
    HS_MODE      : boolean := TRUE; -- High Speed Mode (Operating Clock > 307.2MHz)
    BITWIDTH     : natural := 16
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
  
    DATA0_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA1_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA2_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA3_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);

    DATA_OUT     : out std_logic_vector(BITWIDTH+1 downto 0)
    );
end component;

component ADD8 is
generic(
    HS_MODE      : boolean := FALSE;
    BITWIDTH     : natural := 16
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
  
    DATA0_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA1_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA2_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA3_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    
    DATA4_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA5_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA6_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA7_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);

    DATA_OUT     : out std_logic_vector(BITWIDTH+2 downto 0)
    );
end component;

component SRL16E_DLY is
generic(
    DEVICE       : string  := "ULTRASCALE";
    HS_MODE      : boolean :=       FALSE ;

    BIT_WIDTH    : natural;            -- 2 to 64
    DELAY_NUM    : natural
    );
port(
    CLK          : in  std_logic;

    DATA_IN      : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT     : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end component;

component SRLC32E_DLY is
generic(
    DEVICE    : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HS_MODE   : boolean :=        TRUE ;

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_COUT : out std_logic_vector(BIT_WIDTH-1 downto 0); -- SRLC32E Chain, 32clock Delayed DATA
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0)  -- Delayed DATA
    );
end component;

component DSP48E_MULT is
generic(
    DEVICE                      : string  := "ULTRASCALE";
    DSP48_MODECTRL              : boolean :=       FALSE ;
    DSP48_PREADDER_USE          : boolean :=        TRUE ;
    DSP48_PREADDER_MODE         : string  :=        "ADD"; -- "ADD" or "SUB" 
    DSP48_PCIN_USE              : boolean :=       FALSE ;
    DSP48_PCOUT_USE             : boolean :=       FALSE ;

    A_nREG                      : integer :=           2 ; -- 0, 1, 2
    B_nREG                      : integer :=           2 ; -- 0, 1, 2

    C_EN                        : boolean :=        TRUE ; -- RND ENable
    RND_SYMMETRY                : boolean :=       FALSE 
    );
port(
    CLK                         : in  std_logic;

    ALUMODE_IN                  : in  std_logic_vector( 3 downto 0);
    OPMODE_IN                   : in  std_logic_vector( 8 downto 0);

    C_IN                        : in  std_logic_vector(47 downto 0); -- RND Value
    A_IN                        : in  std_logic_vector(29 downto 0);
    D_IN                        : in  std_logic_vector(26 downto 0);
    B_IN                        : in  std_logic_vector(17 downto 0);

    P_CIN                       : in  std_logic_vector(47 downto 0);
    P_COUT                      : out std_logic_vector(47 downto 0);

    P_OUT                       : out std_logic_vector(47 downto 0);
    CRRY_OUT                    : out std_logic
    );
end component;


component DSP48E1_MULTIPLIER is
-- Latency 4 clocks
generic(
    AIN_BITWIDTH : natural; -- AIN bitwidth : 0 to 29
    BIN_BITWIDTH : natural; -- BIN bitwidth : 0 to 17
    RND_EN       : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT      : natural; -- Rounding bit  
    OUTPUT_WIDTH : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
    AIN          : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
    BIN          : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
    P            : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
    );
end component;

component DSP48E2_MULTIPLIER is
generic(
    AIN_BITWIDTH : natural; -- AIN bitwidth : 0 to 29
    BIN_BITWIDTH : natural; -- BIN bitwidth : 0 to 17
    RND_EN       : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT      : natural; -- Rounding bit  
    OUTPUT_WIDTH : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
    AIN          : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
    BIN          : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
    P            : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
    );
end component;

component DPD_3D_LUT41_DDR is
generic(
    DEVICE                      : string  := "ULTRASCALE";

    DDR_DLY                     : integer :=           2 ;

    SIGNAL_Q_POINT              : integer :=          15 ;
    LUT_DDR_Q_POINT             : integer :=          12 ;
    SUM_Q_POINT                 : integer :=          15
    );
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
   
    LUT_DATA_VLD                : in  std_logic;
    LUT_I_IN                    : in  std_logic_array16(2 downto 0); 
    LUT_Q_IN                    : in  std_logic_array16(2 downto 0); 

    DATA_I_IN                   : in  std_logic_vector(15 downto 0); 
    DATA_Q_IN                   : in  std_logic_vector(15 downto 0); 

    DDR_I_OUT                   : out std_logic_array28(1 downto 0); 
    DDR_Q_OUT                   : out std_logic_array28(1 downto 0) 
    );
end component;

component SAT_SIGN is
generic(
    HS_MODE                     : boolean := TRUE;
    INPUT_BIT                   : natural;
    OUTPUT_BIT                  : natural 
    );
port( 
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    DATA_IN                     : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT                    : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

signal dpd_lut_output_switch : std_logic_array4(TX_ANT_NUM-1 downto 0);
signal lut_rdata_i           : std_logic_array41_array16(TX_ANT_NUM downto 0);
signal lut_rdata_q           : std_logic_array41_array16(TX_ANT_NUM downto 0);

signal lut_rdata_sw_i        : std_logic_array41_array16(TX_ANT_NUM-1 downto 0);
signal lut_rdata_sw_q        : std_logic_array41_array16(TX_ANT_NUM-1 downto 0);

signal mag9_sh               : std_logic_array14_array9(TX_ANT_NUM-1 downto 0);
signal magnitude9            : std_logic_array13_array9(TX_ANT_NUM-1 downto 0);

signal mag15_sh              : std_logic_array3_array15(TX_ANT_NUM-1 downto 0);

signal ddr_i                 : std_logic_array4_array28(TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0'))); 
signal ddr_q                 : std_logic_array4_array28(TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0'))); 


signal lutsum_00_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);            
signal lutsum_00_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);            

signal lutsum_00_ls_i        : std_logic_array25(TX_ANT_NUM-1 downto 0);            
signal lutsum_00_ls_q        : std_logic_array25(TX_ANT_NUM-1 downto 0);            

signal tap_00_i              : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal tap_00_q              : std_logic_array27(TX_ANT_NUM-1 downto 0);            



signal lutsum_01_i           : std_logic_array18(TX_ANT_NUM-1 downto 0);            
signal lutsum_01_q           : std_logic_array18(TX_ANT_NUM-1 downto 0);            

signal lutsum_01_i_dly       : std_logic_array18(TX_ANT_NUM-1 downto 0);            
signal lutsum_01_q_dly       : std_logic_array18(TX_ANT_NUM-1 downto 0);            
signal lutsum_01_i_sat       : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal lutsum_01_q_sat       : std_logic_array27(TX_ANT_NUM-1 downto 0);            

signal tap_01_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_01_q              : std_logic_array26(TX_ANT_NUM-1 downto 0);            



signal lutsum_02_i           : std_logic_array18(TX_ANT_NUM-1 downto 0);            
signal lutsum_02_q           : std_logic_array18(TX_ANT_NUM-1 downto 0);            

signal lutsum_02_i_dly       : std_logic_array18(TX_ANT_NUM-1 downto 0);            
signal lutsum_02_q_dly       : std_logic_array18(TX_ANT_NUM-1 downto 0);            
signal lutsum_02_i_sat       : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal lutsum_02_q_sat       : std_logic_array27(TX_ANT_NUM-1 downto 0);            

signal lutsum_02_ls_i        : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal lutsum_02_ls_q        : std_logic_array27(TX_ANT_NUM-1 downto 0);            

signal tap_02_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_02_q              : std_logic_array26(TX_ANT_NUM-1 downto 0);            




signal lutsum_03_2d_i        : std_logic_array19(TX_ANT_NUM-1 downto 0);            
signal lutsum_03_2d_q        : std_logic_array19(TX_ANT_NUM-1 downto 0);            

signal lutsum_03_2d_ls_i     : std_logic_array28(TX_ANT_NUM-1 downto 0);            
signal lutsum_03_2d_ls_q     : std_logic_array28(TX_ANT_NUM-1 downto 0);            

signal lutsum_03_2d_ls_i_dly : std_logic_array28(TX_ANT_NUM-1 downto 0);            
signal lutsum_03_2d_ls_q_dly : std_logic_array28(TX_ANT_NUM-1 downto 0);            


signal se_lutsum_03_2d_ls_i  : std_logic_array31(TX_ANT_NUM-1 downto 0);            
signal se_lutsum_03_2d_ls_q  : std_logic_array31(TX_ANT_NUM-1 downto 0);            

signal se_lut_ram29_i        : std_logic_array30(TX_ANT_NUM-1 downto 0);
signal se_lut_ram29_q        : std_logic_array30(TX_ANT_NUM-1 downto 0);

signal se_lut_ram30_i        : std_logic_array30(TX_ANT_NUM-1 downto 0);
signal se_lut_ram30_q        : std_logic_array30(TX_ANT_NUM-1 downto 0);

signal se_lutsum_03_mag15_idx0: std_logic_array18(TX_ANT_NUM-1 downto 0);
signal se_lutsum_03_mag15_idx1: std_logic_array18(TX_ANT_NUM-1 downto 0);

signal lutsum_03_3d0_i       : std_logic_array48(TX_ANT_NUM-1 downto 0);            
signal lutsum_03_3d0_q       : std_logic_array48(TX_ANT_NUM-1 downto 0);            

signal lutsum_03_3d1_i       : std_logic_array48(TX_ANT_NUM-1 downto 0);            
signal lutsum_03_3d1_q       : std_logic_array48(TX_ANT_NUM-1 downto 0);            

signal lutsum_03_3d_rs_i     : std_logic_array31(TX_ANT_NUM-1 downto 0);            
signal lutsum_03_3d_rs_q     : std_logic_array31(TX_ANT_NUM-1 downto 0);            

signal lutsum_03_3d_rs_i_dly : std_logic_array31(TX_ANT_NUM-1 downto 0);            
signal lutsum_03_3d_rs_q_dly : std_logic_array31(TX_ANT_NUM-1 downto 0);            


signal se_ddr0_i             : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others => (others => '0')); 
signal se_ddr0_q             : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others => (others => '0')); 
                                                                                                    
signal se_ddr2_i             : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others => (others => '0')); 
signal se_ddr2_q             : std_logic_array31(TX_ANT_NUM-1 downto 0) := (others => (others => '0')); 

signal lutsum_03_i           : std_logic_array33(TX_ANT_NUM-1 downto 0);            
signal lutsum_03_q           : std_logic_array33(TX_ANT_NUM-1 downto 0);            

signal tap_03_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_03_q              : std_logic_array26(TX_ANT_NUM-1 downto 0);            




signal lutsum_04_2d_i        : std_logic_array18(TX_ANT_NUM-1 downto 0);            
signal lutsum_04_2d_q        : std_logic_array18(TX_ANT_NUM-1 downto 0);            

signal lutsum_04_2d_ls_i     : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal lutsum_04_2d_ls_q     : std_logic_array27(TX_ANT_NUM-1 downto 0);            

signal se_lutsum_04_2d_ls_i  : std_logic_array31(TX_ANT_NUM-1 downto 0);            
signal se_lutsum_04_2d_ls_q  : std_logic_array31(TX_ANT_NUM-1 downto 0);            

signal se_lut_ram31_i        : std_logic_array30(TX_ANT_NUM-1 downto 0);
signal se_lut_ram31_q        : std_logic_array30(TX_ANT_NUM-1 downto 0);

signal se_lut_ram32_i        : std_logic_array30(TX_ANT_NUM-1 downto 0);
signal se_lut_ram32_q        : std_logic_array30(TX_ANT_NUM-1 downto 0);

signal se_lut_ram33_i        : std_logic_array30(TX_ANT_NUM-1 downto 0);
signal se_lut_ram33_q        : std_logic_array30(TX_ANT_NUM-1 downto 0);

signal se_lut_ram34_i        : std_logic_array30(TX_ANT_NUM-1 downto 0);
signal se_lut_ram34_q        : std_logic_array30(TX_ANT_NUM-1 downto 0);

signal se_lutsum_04_mag15_idx0: std_logic_array18(TX_ANT_NUM-1 downto 0);
signal se_lutsum_04_mag15_idx1: std_logic_array18(TX_ANT_NUM-1 downto 0);
signal se_lutsum_04_mag15_idx2: std_logic_array18(TX_ANT_NUM-1 downto 0);

signal lutsum_04_3d0_i       : std_logic_array48(TX_ANT_NUM-1 downto 0);            
signal lutsum_04_3d0_q       : std_logic_array48(TX_ANT_NUM-1 downto 0);            

signal lutsum_04_3d1_i       : std_logic_array48(TX_ANT_NUM-1 downto 0);            
signal lutsum_04_3d1_q       : std_logic_array48(TX_ANT_NUM-1 downto 0);            

signal lutsum_04_3d1_rs_i    : std_logic_array31(TX_ANT_NUM-1 downto 0);            
signal lutsum_04_3d1_rs_q    : std_logic_array31(TX_ANT_NUM-1 downto 0);            


signal lutsum_04_3d2_i       : std_logic_array48(TX_ANT_NUM-1 downto 0);            
signal lutsum_04_3d2_q       : std_logic_array48(TX_ANT_NUM-1 downto 0);            

signal lutsum_04_3d3_i       : std_logic_array48(TX_ANT_NUM-1 downto 0);            
signal lutsum_04_3d3_q       : std_logic_array48(TX_ANT_NUM-1 downto 0);            

signal lutsum_04_3d3_rs_i    : std_logic_array31(TX_ANT_NUM-1 downto 0);            
signal lutsum_04_3d3_rs_q    : std_logic_array31(TX_ANT_NUM-1 downto 0);            

signal lutsum_04_i           : std_logic_array33(TX_ANT_NUM-1 downto 0);            
signal lutsum_04_q           : std_logic_array33(TX_ANT_NUM-1 downto 0);            

signal sat_lutsum_04_i       : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal sat_lutsum_04_q       : std_logic_array26(TX_ANT_NUM-1 downto 0);            

signal tap_04_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_04_q              : std_logic_array26(TX_ANT_NUM-1 downto 0);            


signal lutsum_05_i           : std_logic_array18(TX_ANT_NUM-1 downto 0);            
signal lutsum_05_q           : std_logic_array18(TX_ANT_NUM-1 downto 0);            

signal lutsum_05_i_dly       : std_logic_array18(TX_ANT_NUM-1 downto 0);            
signal lutsum_05_q_dly       : std_logic_array18(TX_ANT_NUM-1 downto 0);            

signal lutsum_05_ls_i        : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal lutsum_05_ls_q        : std_logic_array27(TX_ANT_NUM-1 downto 0);            

signal lutsum_05_ddr_i       : std_logic_array29(TX_ANT_NUM-1 downto 0);            
signal lutsum_05_ddr_q       : std_logic_array29(TX_ANT_NUM-1 downto 0);            

signal sat_lutsum_05_ddr_i   : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal sat_lutsum_05_ddr_q   : std_logic_array26(TX_ANT_NUM-1 downto 0);            

signal tap_05_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_05_q              : std_logic_array26(TX_ANT_NUM-1 downto 0);            



signal lutsum_06_i           : std_logic_array18(TX_ANT_NUM-1 downto 0);            
signal lutsum_06_q           : std_logic_array18(TX_ANT_NUM-1 downto 0);            

signal lutsum_06_i_dly       : std_logic_array18(TX_ANT_NUM-1 downto 0);            
signal lutsum_06_q_dly       : std_logic_array18(TX_ANT_NUM-1 downto 0);            

signal lutsum_06_ls_i        : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal lutsum_06_ls_q        : std_logic_array27(TX_ANT_NUM-1 downto 0);            

signal lutsum_06_ddr_i       : std_logic_array29(TX_ANT_NUM-1 downto 0);            
signal lutsum_06_ddr_q       : std_logic_array29(TX_ANT_NUM-1 downto 0);            

signal sat_lutsum_06_ddr_i   : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal sat_lutsum_06_ddr_q   : std_logic_array26(TX_ANT_NUM-1 downto 0);            

signal tap_06_i              : std_logic_array26(TX_ANT_NUM-1 downto 0);            
signal tap_06_q              : std_logic_array26(TX_ANT_NUM-1 downto 0);            



signal lutsum_07_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);            
signal lutsum_07_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);            

signal lutsum_07_ls_i        : std_logic_array25(TX_ANT_NUM-1 downto 0);            
signal lutsum_07_ls_q        : std_logic_array25(TX_ANT_NUM-1 downto 0);            

signal tap_07_i              : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal tap_07_q              : std_logic_array27(TX_ANT_NUM-1 downto 0);            




signal lutsum_08_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);            
signal lutsum_08_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);            

signal lutsum_08_ls_i        : std_logic_array25(TX_ANT_NUM-1 downto 0);            
signal lutsum_08_ls_q        : std_logic_array25(TX_ANT_NUM-1 downto 0);            

signal tap_08_i              : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal tap_08_q              : std_logic_array27(TX_ANT_NUM-1 downto 0);            




signal lutsum_09_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);            
signal lutsum_09_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);            

signal lutsum_09_ls_i        : std_logic_array25(TX_ANT_NUM-1 downto 0);            
signal lutsum_09_ls_q        : std_logic_array25(TX_ANT_NUM-1 downto 0);            

signal tap_09_i              : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal tap_09_q              : std_logic_array27(TX_ANT_NUM-1 downto 0);            



signal lutsum_10_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);            
signal lutsum_10_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);            

signal lutsum_10_ls_i        : std_logic_array25(TX_ANT_NUM-1 downto 0);            
signal lutsum_10_ls_q        : std_logic_array25(TX_ANT_NUM-1 downto 0);            

signal tap_10_i              : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal tap_10_q              : std_logic_array27(TX_ANT_NUM-1 downto 0);            



signal lutsum_11_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);            
signal lutsum_11_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);            

signal lutsum_11_ls_i        : std_logic_array25(TX_ANT_NUM-1 downto 0);            
signal lutsum_11_ls_q        : std_logic_array25(TX_ANT_NUM-1 downto 0);            

signal tap_11_i              : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal tap_11_q              : std_logic_array27(TX_ANT_NUM-1 downto 0);            



signal lutsum_12_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);            
signal lutsum_12_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);            

signal lutsum_12_ls_i        : std_logic_array25(TX_ANT_NUM-1 downto 0);            
signal lutsum_12_ls_q        : std_logic_array25(TX_ANT_NUM-1 downto 0);            

signal tap_12_i              : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal tap_12_q              : std_logic_array27(TX_ANT_NUM-1 downto 0);            


---------------------------------------------------------------------------
-- signal mag1_lut29            : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- signal mag0_lut30            : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- signal mag2_lut31            : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- signal mag0_lut32            : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- signal mag1_lut33            : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- signal mag0_lut34            : std_logic_array16(TX_ANT_NUM-1 downto 0);

-- signal lut29_mp0_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- signal lut29_mp0_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- 
-- signal lut30_mp0_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- signal lut30_mp0_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- 
-- signal lut31_mp1_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- signal lut31_mp1_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- 
-- signal lut32_mp1_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- signal lut32_mp1_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- 
-- signal lut33_mp1_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- signal lut33_mp1_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- 
-- signal lut34_mp1_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- signal lut34_mp1_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);
-- 
-- signal mag1_lut29_mp0_i      : std_logic_array27(TX_ANT_NUM-1 downto 0);
-- signal mag1_lut29_mp0_q      : std_logic_array27(TX_ANT_NUM-1 downto 0);
-- 
-- signal mag0_lut30_mp0_i      : std_logic_array27(TX_ANT_NUM-1 downto 0);
-- signal mag0_lut30_mp0_q      : std_logic_array27(TX_ANT_NUM-1 downto 0);
-- 
-- signal mag2_lut31_mp1_i      : std_logic_array27(TX_ANT_NUM-1 downto 0);
-- signal mag2_lut31_mp1_q      : std_logic_array27(TX_ANT_NUM-1 downto 0);
-- 
-- signal mag0_lut32_mp1_i      : std_logic_array27(TX_ANT_NUM-1 downto 0);  
-- signal mag0_lut32_mp1_q      : std_logic_array27(TX_ANT_NUM-1 downto 0);  
-- 
-- signal mag1_lut33_mp1_i      : std_logic_array27(TX_ANT_NUM-1 downto 0);  
-- signal mag1_lut33_mp1_q      : std_logic_array27(TX_ANT_NUM-1 downto 0);  
-- 
-- signal mag0_lut34_mp1_i      : std_logic_array27(TX_ANT_NUM-1 downto 0);  
-- signal mag0_lut34_mp1_q      : std_logic_array27(TX_ANT_NUM-1 downto 0);  
-- 
-- 
-- signal mag1_lut29_mp0_i_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);
-- signal mag1_lut29_mp0_q_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);
-- 
-- signal mag0_lut30_mp0_i_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);
-- signal mag0_lut30_mp0_q_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);
-- 
-- signal mag2_lut31_mp1_i_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);
-- signal mag2_lut31_mp1_q_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);
-- 
-- signal mag0_lut32_mp1_i_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);  
-- signal mag0_lut32_mp1_q_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);  
-- 
-- signal mag1_lut33_mp1_i_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);  
-- signal mag1_lut33_mp1_q_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);  
-- 
-- signal mag0_lut34_mp1_i_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);  
-- signal mag0_lut34_mp1_q_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);  
-- 
-- 
-- signal lut_rdata_sw_i_d      : std_logic_array29_array16(TX_ANT_NUM-1 downto 0);
-- signal lut_rdata_sw_q_d      : std_logic_array29_array16(TX_ANT_NUM-1 downto 0);
-- 
-- signal lut_rdata_sw_i_ls     : std_logic_array29_array27(TX_ANT_NUM-1 downto 0);
-- signal lut_rdata_sw_q_ls     : std_logic_array29_array27(TX_ANT_NUM-1 downto 0);
-- 
-- signal lut_mpa4_i            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
-- signal lut_mpa4_q            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
-- 
-- signal lut_mpa3_i            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
-- signal lut_mpa3_q            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
-- 
-- signal lut_mpa2_i            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
-- signal lut_mpa2_q            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
-- 
-- signal lut_mpa1_i            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
-- signal lut_mpa1_q            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
-- 
-- signal lut_mp00_i            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
-- signal lut_mp00_q            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
-- 
-- signal lut_mp01_i            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
-- signal lut_mp01_q            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
-- 
-- signal lut_mp02_i            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
-- signal lut_mp02_q            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
-- 
-- signal lut_mp03_i            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
-- signal lut_mp03_q            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
-- 
-- signal lut_mp04_i            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
-- signal lut_mp04_q            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
-- 
-- signal lut_mp05_i            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
-- signal lut_mp05_q            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
-- 
-- signal lut_mp06_i            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
-- signal lut_mp06_q            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
-- 
-- signal lut_mp07_i            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
-- signal lut_mp07_q            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
-- 
-- signal lut_mp08_i            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
-- signal lut_mp08_q            : std_logic_array27(TX_ANT_NUM-1 downto 0);            


attribute KEEP : string;
attribute KEEP of dpd_lut_output_switch : signal is "TRUE";
attribute KEEP of lut_rdata_sw_i        : signal is "TRUE";
attribute KEEP of lut_rdata_sw_q        : signal is "TRUE";

attribute MAX_FANOUT : integer;
attribute MAX_FANOUT of dpd_lut_output_switch : signal is ternary_func(HS_MODE=TRUE, 20, 2000);

begin

    -- LUT Read Data Align
    G_LUT_RDATA_Assign_TX_ANT : for I in 0 to (TX_ANT_NUM) generate begin
        G_LUT_RDATA_Assign_LUT_RAM : for J in 0 to (LUT_RAM_NUM-1) generate begin
            lut_rdata_i(I)(J) <= LUT_RDATA_IN(I)(J)(31 downto 16); 
            lut_rdata_q(I)(J) <= LUT_RDATA_IN(I)(J)(15 downto  0); 
        end generate;
    end generate;

    G_LUT_Non_Optimized : if (LUT_OPTIMIZED = FALSE) generate begin            
        P_LUT_Rdata_Clocking_Normal_Operation : if (HS_MODE = FALSE) generate begin
            P_LUT_Rdata_Clocking_NM : process(RST, CLK) begin
                if (RST = '1') then
                    lut_rdata_sw_i <= (others => (others => (others => '0')));
                    lut_rdata_sw_q <= (others => (others => (others => '0')));
                elsif (CLK'event) and (CLK = '1') then
                    lut_rdata_sw_i <= lut_rdata_i(TX_ANT_NUM-1 downto 0);
                    lut_rdata_sw_q <= lut_rdata_q(TX_ANT_NUM-1 downto 0);
                end if;
            end process;
        end generate;

        P_LUT_Rdata_Clocking_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
            P_LUT_Rdata_Clocking_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    lut_rdata_sw_i <= lut_rdata_i(TX_ANT_NUM-1 downto 0);
                    lut_rdata_sw_q <= lut_rdata_q(TX_ANT_NUM-1 downto 0);
                end if;
            end process;
        end generate;

        dpd_lut_output_switch <= (others => (others => '0')); 
    end generate;

    G_LUT_Optimized_Switch : if (LUT_OPTIMIZED = TRUE) generate begin            
        G_LUT_RDATA_SW : for I in 0 to (TX_ANT_NUM-1) generate begin
            G_LUT_RDATA_SW_Normal_Operation : if (HS_MODE = FALSE) generate begin
                P_LUT_RDATA_SW_NM : process(RST, CLK) begin
                    if (RST = '1') then
                        dpd_lut_output_switch(I) <= (others => '0');
                    elsif (CLK'event) and (CLK = '1') then 
                        dpd_lut_output_switch(I) <= DPD_LUT_OUTPUT_SWITCH_IN(4*I+3 downto 4*I);
                    end if;
                end process;
            end generate;

            G_LUT_RDATA_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_LUT_RDATA_SW_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then 
                        dpd_lut_output_switch(I) <= DPD_LUT_OUTPUT_SWITCH_IN(4*I+3 downto 4*I);
                    end if;
                end process;
            end generate;
        end generate;

        G_LUT_Rdata_Switching_ANT2 : if (TX_ANT_NUM = 2) generate begin
            G_LUT_RDATA_SW_ANT2_Normal_Operation : if (HS_MODE = FALSE) generate begin
                P_LUT_Rdata_2Path_Switch_NM : process(RST, CLK) begin
                    if (RST = '1') then
                        lut_rdata_sw_i <= (others => (others => (others => '0')));
                        lut_rdata_sw_q <= (others => (others => (others => '0')));
                    elsif (CLK'event) and (CLK = '1') then
                        case (dpd_lut_output_switch(0)) is 
                            when x"0"   => lut_rdata_sw_i(0) <= lut_rdata_i(0);              lut_rdata_sw_q(0) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(0) <= lut_rdata_i(1);              lut_rdata_sw_q(0) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(0) <= lut_rdata_i(2);              lut_rdata_sw_q(0) <= lut_rdata_q(2);
                            when others => lut_rdata_sw_i(0) <= (others => (others => '0')); lut_rdata_sw_q(0) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(1)) is 
                            when x"0"   => lut_rdata_sw_i(1) <= lut_rdata_i(0);              lut_rdata_sw_q(1) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(1) <= lut_rdata_i(1);              lut_rdata_sw_q(1) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(1) <= lut_rdata_i(2);              lut_rdata_sw_q(1) <= lut_rdata_q(2);
                            when others => lut_rdata_sw_i(1) <= (others => (others => '0')); lut_rdata_sw_q(1) <= (others => (others => '0'));
                        end case;
                    end if;
                end process;
            end generate;

            G_LUT_RDATA_SW_ANT2_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_LUT_Rdata_2Path_Switch_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (dpd_lut_output_switch(0)) is 
                            when x"0"   => lut_rdata_sw_i(0) <= lut_rdata_i(0);              lut_rdata_sw_q(0) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(0) <= lut_rdata_i(1);              lut_rdata_sw_q(0) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(0) <= lut_rdata_i(2);              lut_rdata_sw_q(0) <= lut_rdata_q(2);
                            when others => lut_rdata_sw_i(0) <= (others => (others => '0')); lut_rdata_sw_q(0) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(1)) is 
                            when x"0"   => lut_rdata_sw_i(1) <= lut_rdata_i(0);              lut_rdata_sw_q(1) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(1) <= lut_rdata_i(1);              lut_rdata_sw_q(1) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(1) <= lut_rdata_i(2);              lut_rdata_sw_q(1) <= lut_rdata_q(2);
                            when others => lut_rdata_sw_i(1) <= (others => (others => '0')); lut_rdata_sw_q(1) <= (others => (others => '0'));
                        end case;
                    end if;
                end process;
            end generate;
        end generate;

        G_LUT_Rdata_Switching_ANT4 : if (TX_ANT_NUM = 4) generate begin
            G_LUT_RDATA_SW_ANT4_Normal_Operation : if (HS_MODE = FALSE) generate begin
                P_LUT_Rdata_4Path_Switch_NM : process(RST, CLK) begin
                    if (RST = '1') then
                        lut_rdata_sw_i <= (others => (others => (others => '0')));
                        lut_rdata_sw_q <= (others => (others => (others => '0')));
                    elsif (CLK'event) and (CLK = '1') then
                        case (dpd_lut_output_switch(0)) is 
                            when x"0"   => lut_rdata_sw_i(0) <= lut_rdata_i(0);              lut_rdata_sw_q(0) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(0) <= lut_rdata_i(1);              lut_rdata_sw_q(0) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(0) <= lut_rdata_i(2);              lut_rdata_sw_q(0) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(0) <= lut_rdata_i(3);              lut_rdata_sw_q(0) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(0) <= lut_rdata_i(4);              lut_rdata_sw_q(0) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(0) <= (others => (others => '0')); lut_rdata_sw_q(0) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(1)) is 
                            when x"0"   => lut_rdata_sw_i(1) <= lut_rdata_i(0);              lut_rdata_sw_q(1) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(1) <= lut_rdata_i(1);              lut_rdata_sw_q(1) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(1) <= lut_rdata_i(2);              lut_rdata_sw_q(1) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(1) <= lut_rdata_i(3);              lut_rdata_sw_q(1) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(1) <= lut_rdata_i(4);              lut_rdata_sw_q(1) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(1) <= (others => (others => '0')); lut_rdata_sw_q(1) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(2)) is 
                            when x"0"   => lut_rdata_sw_i(2) <= lut_rdata_i(0);              lut_rdata_sw_q(2) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(2) <= lut_rdata_i(1);              lut_rdata_sw_q(2) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(2) <= lut_rdata_i(2);              lut_rdata_sw_q(2) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(2) <= lut_rdata_i(3);              lut_rdata_sw_q(2) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(2) <= lut_rdata_i(4);              lut_rdata_sw_q(2) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(2) <= (others => (others => '0')); lut_rdata_sw_q(2) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(3)) is 
                            when x"0"   => lut_rdata_sw_i(3) <= lut_rdata_i(0);              lut_rdata_sw_q(3) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(3) <= lut_rdata_i(1);              lut_rdata_sw_q(3) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(3) <= lut_rdata_i(2);              lut_rdata_sw_q(3) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(3) <= lut_rdata_i(3);              lut_rdata_sw_q(3) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(3) <= lut_rdata_i(4);              lut_rdata_sw_q(3) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(3) <= (others => (others => '0')); lut_rdata_sw_q(3) <= (others => (others => '0'));
                        end case;
                    end if;
                end process;
            end generate;

            G_LUT_RDATA_SW_ANT4_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_LUT_Rdata_4Path_Switch_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (dpd_lut_output_switch(0)) is 
                            when x"0"   => lut_rdata_sw_i(0) <= lut_rdata_i(0);              lut_rdata_sw_q(0) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(0) <= lut_rdata_i(1);              lut_rdata_sw_q(0) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(0) <= lut_rdata_i(2);              lut_rdata_sw_q(0) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(0) <= lut_rdata_i(3);              lut_rdata_sw_q(0) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(0) <= lut_rdata_i(4);              lut_rdata_sw_q(0) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(0) <= (others => (others => '0')); lut_rdata_sw_q(0) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(1)) is 
                            when x"0"   => lut_rdata_sw_i(1) <= lut_rdata_i(0);              lut_rdata_sw_q(1) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(1) <= lut_rdata_i(1);              lut_rdata_sw_q(1) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(1) <= lut_rdata_i(2);              lut_rdata_sw_q(1) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(1) <= lut_rdata_i(3);              lut_rdata_sw_q(1) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(1) <= lut_rdata_i(4);              lut_rdata_sw_q(1) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(1) <= (others => (others => '0')); lut_rdata_sw_q(1) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(2)) is 
                            when x"0"   => lut_rdata_sw_i(2) <= lut_rdata_i(0);              lut_rdata_sw_q(2) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(2) <= lut_rdata_i(1);              lut_rdata_sw_q(2) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(2) <= lut_rdata_i(2);              lut_rdata_sw_q(2) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(2) <= lut_rdata_i(3);              lut_rdata_sw_q(2) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(2) <= lut_rdata_i(4);              lut_rdata_sw_q(2) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(2) <= (others => (others => '0')); lut_rdata_sw_q(2) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(3)) is 
                            when x"0"   => lut_rdata_sw_i(3) <= lut_rdata_i(0);              lut_rdata_sw_q(3) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(3) <= lut_rdata_i(1);              lut_rdata_sw_q(3) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(3) <= lut_rdata_i(2);              lut_rdata_sw_q(3) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(3) <= lut_rdata_i(3);              lut_rdata_sw_q(3) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(3) <= lut_rdata_i(4);              lut_rdata_sw_q(3) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(3) <= (others => (others => '0')); lut_rdata_sw_q(3) <= (others => (others => '0'));
                        end case;
                    end if;
                end process;
            end generate;
        end generate;
    end generate;

    G_TX_ANT : for I in 0 to (TX_ANT_NUM-1) generate begin

        mag9_sh(I)(0) <= MAG9(I);

        G_Magnitude_time_shift : for J in 0 to (DPD_TAP_NUM-1) generate begin 
            G_Normal_Operation : if (HS_MODE = FALSE) generate begin
                P_Magnitude_Time_Shift_NM : process(RST, CLK) begin
                    if (RST = '1') then
                        mag9_sh(I)(J+1) <= (others => '0');
                    elsif (CLK'event) and (CLK = '1') then
                        if (LUT_DATA_VLD(I) = '1') then
                            mag9_sh(I)(J+1) <= mag9_sh(I)(J);
                        else
                            mag9_sh(I)(J+1) <= mag9_sh(I)(J+1);
                        end if;
                    end if;
                end process;
            end generate;

            G_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_Magnitude_Time_Shift_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        mag9_sh(I)(J+1) <= mag9_sh(I)(J);
                    end if;
                end process;
            end generate;

        end generate;

        magnitude9(I) <= mag9_sh(I)(DPD_TAP_NUM downto 1);

        -- [Magnitude Index Mapping]==================================================== --
        --                                                                               --
        -- Can Modify according to DPD_CORE eqaution, Always need to check!!             --
        --                                                                               --
        -- ============================================================================= -- 

        -- LUT address decoding  
        -- magnitude9(MAX_ADV-3) --> |x[n+3]|
        -- magnitude9(MAX_ADV-2) --> |x[n+2]|
        -- magnitude9(MAX_ADV-1) --> |x[n+1]|
        -- magnitude9(MAX_ADV+0) --> |x[n-0]|
        -- magnitude9(MAX_ADV+1) --> |x[n-1]|
        -- magnitude9(MAX_ADV+2) --> |x[n-2]|
        -- magnitude9(MAX_ADV+3) --> |x[n-3]|
        -- magnitude9(MAX_ADV+4) --> |x[n-4]|
        -- magnitude9(MAX_ADV+5) --> |x[n-5]|
        -- magnitude9(MAX_ADV+6) --> |x[n-6]|
        -- magnitude9(MAX_ADV+7) --> |x[n-7]|
        -- magnitude9(MAX_ADV+8) --> |x[n-8]|
        -- magnitude9(MAX_ADV+9) --> |x[n-9]|

        -- LUT address Encoding  
        P_LUT_Address_Encoding_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                -- Diagonal Term                             -- Data# & Mag#
                LUT_ADDR(I)( 0) <= magnitude9(I)(MAX_ADV+0); -- LUT_00   , |x[n-0]|
                LUT_ADDR(I)( 1) <= magnitude9(I)(MAX_ADV+1); -- LUT_11   , |x[n-1]|
                LUT_ADDR(I)( 2) <= magnitude9(I)(MAX_ADV+2); -- LUT_22   , |x[n-2]|
                LUT_ADDR(I)( 3) <= magnitude9(I)(MAX_ADV+3); -- LUT_33   , |x[n-3]|
                LUT_ADDR(I)( 4) <= magnitude9(I)(MAX_ADV+4); -- LUT_44   , |x[n-4]|
                LUT_ADDR(I)( 5) <= magnitude9(I)(MAX_ADV+5); -- LUT_55   , |x[n-5]|
                LUT_ADDR(I)( 6) <= magnitude9(I)(MAX_ADV+6); -- LUT_66   , |x[n-6]|
                LUT_ADDR(I)( 7) <= magnitude9(I)(MAX_ADV+7); -- LUT_77   , |x[n-7]|
                LUT_ADDR(I)( 8) <= magnitude9(I)(MAX_ADV+8); -- LUT_88   , |x[n-8]|
                LUT_ADDR(I)( 9) <= magnitude9(I)(MAX_ADV+9); -- LUT_99   , |x[n-9]|
                LUT_ADDR(I)(10) <= magnitude9(I)(MAX_ADV-1); -- LUT_A1A1 , |x[n+1]|
                LUT_ADDR(I)(11) <= magnitude9(I)(MAX_ADV-2); -- LUT_A2A2 , |x[n+2]|
                LUT_ADDR(I)(12) <= magnitude9(I)(MAX_ADV-3); -- LUT_A3A3 , |x[n+3]|

                -- Off Diagonal Term
                LUT_ADDR(I)(13) <= magnitude9(I)(MAX_ADV+1); -- LUT_01   , |x[n-1]|
                LUT_ADDR(I)(14) <= magnitude9(I)(MAX_ADV+2); -- LUT_02   , |x[n-2]|
                LUT_ADDR(I)(15) <= magnitude9(I)(MAX_ADV+3); -- LUT_03   , |x[n-3]|
                LUT_ADDR(I)(16) <= magnitude9(I)(MAX_ADV-1); -- LUT_0A1  , |x[n+1]|
                LUT_ADDR(I)(17) <= magnitude9(I)(MAX_ADV-2); -- LUT_0A2  , |x[n+2]|
                LUT_ADDR(I)(18) <= magnitude9(I)(MAX_ADV+0); -- LUT_10   , |x[n-0]|
                LUT_ADDR(I)(19) <= magnitude9(I)(MAX_ADV+2); -- LUT_12   , |x[n-2]|
                LUT_ADDR(I)(20) <= magnitude9(I)(MAX_ADV+0); -- LUT_20   , |x[n-0]|
                LUT_ADDR(I)(21) <= magnitude9(I)(MAX_ADV+1); -- LUT_21   , |x[n-1]|
                LUT_ADDR(I)(22) <= magnitude9(I)(MAX_ADV+3); -- LUT_23   , |x[n-3]|
                LUT_ADDR(I)(23) <= magnitude9(I)(MAX_ADV+0); -- LUT_30   , |x[n-0]|
                LUT_ADDR(I)(24) <= magnitude9(I)(MAX_ADV+2); -- LUT_32   , |x[n-2]|
                LUT_ADDR(I)(25) <= magnitude9(I)(MAX_ADV-2); -- LUT_A1A2 , |x[n+2]|
                LUT_ADDR(I)(26) <= magnitude9(I)(MAX_ADV-0); -- LUT_A10  , |x[n-0]|
                LUT_ADDR(I)(27) <= magnitude9(I)(MAX_ADV-1); -- LUT_A2A1 , |x[n+1]|
                LUT_ADDR(I)(28) <= magnitude9(I)(MAX_ADV+0); -- LUT_A20  , |x[n-0]|

                -- 3D Term
                LUT_ADDR(I)(29) <= magnitude9(I)(MAX_ADV+0); -- LUT_A20  , |x[n-0]|
                LUT_ADDR(I)(30) <= magnitude9(I)(MAX_ADV+1); -- LUT_00   , |x[n-1]|
                LUT_ADDR(I)(31) <= magnitude9(I)(MAX_ADV+0); -- LUT_00   , |x[n-0]|
                LUT_ADDR(I)(32) <= magnitude9(I)(MAX_ADV+2); -- LUT_00   , |x[n-2]|
                LUT_ADDR(I)(33) <= magnitude9(I)(MAX_ADV+0); -- LUT_00   , |x[n-0]|
                LUT_ADDR(I)(34) <= magnitude9(I)(MAX_ADV+1); -- LUT_00   , |x[n-1]|

                -- DDR Term
                LUT_ADDR(I)(DDR_LUT_START_IDX+0) <= magnitude9(I)(MAX_ADV+0); -- DDR Index0, |x[n-0]|
                LUT_ADDR(I)(DDR_LUT_START_IDX+1) <= magnitude9(I)(MAX_ADV+0); -- DDR Index1, |x[n-0]|
                LUT_ADDR(I)(DDR_LUT_START_IDX+2) <= magnitude9(I)(MAX_ADV+0); -- DDR Index2, |x[n-0]|
                LUT_ADDR(I)(DDR_LUT_START_IDX+3) <= magnitude9(I)(MAX_ADV+0); -- DDR Index3, |x[n-0]|
                LUT_ADDR(I)(DDR_LUT_START_IDX+4) <= magnitude9(I)(MAX_ADV+0); -- DDR Index4, |x[n-0]|
                LUT_ADDR(I)(DDR_LUT_START_IDX+5) <= magnitude9(I)(MAX_ADV+0); -- DDR Index5, |x[n-0]|
            end if;
        end process;

        -- 3D Term GEN
        U_MAG15_DLY_COMP : SRL16E_DLY generic map(DEVICE, HS_MODE, 15, 9+MAX_ADV) port map (CLK, MAG15(I), mag15_sh(I)(0));

        G_MAG15_SH : for J in 0 to 1 generate begin 
            P_MAG15_Shift : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    mag15_sh(I)(J+1) <= mag15_sh(I)(J);
                end if;
            end process;
        end generate;

        -- DDR_GEN 
        G_DDR : for J in 0 to 1 generate begin
            U_DDR : DPD_3D_LUT41_DDR 
            generic map(
                DEVICE                      => DEVICE                      , 
            
                DDR_DLY                     => DDR_DLY + J                 , 
            
                SIGNAL_Q_POINT              => SIGNAL_Q_POINT              ,
                LUT_DDR_Q_POINT             => LUT_DDR_Q_POINT             ,
                SUM_Q_POINT                 => SUM_Q_POINT                  
                )
            port map(
                RST                         => RST                         , 
                CLK                         => CLK                         , 
               
                LUT_DATA_VLD                => '1'                         , 
                LUT_I_IN                    => lut_rdata_sw_i(I)(3*(J+1)+DDR_LUT_START_IDX-1 downto 3*J+DDR_LUT_START_IDX), 
                LUT_Q_IN                    => lut_rdata_sw_q(I)(3*(J+1)+DDR_LUT_START_IDX-1 downto 3*J+DDR_LUT_START_IDX), 
            
                DATA_I_IN                   => DATA_I_IN(I)                , 
                DATA_Q_IN                   => DATA_Q_IN(I)                , 
            
                DDR_I_OUT                   => ddr_i(I)(2*(J+1)-1 downto 2*J),
                DDR_Q_OUT                   => ddr_q(I)(2*(J+1)-1 downto 2*J)  
                );
        end generate;

        -- G_2D_LUT_DLY_COMP : for J in 0 to 28 generate begin
        --     U_2D_LUT_DLY_COMP_I : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 5) port map (CLK, lut_rdata_sw_i(I)(J), lut_rdata_sw_i_d(I)(J));
        --     U_2D_LUT_DLY_COMP_Q : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 5) port map (CLK, lut_rdata_sw_q(I)(J), lut_rdata_sw_q_d(I)(J));

        --     lut_rdata_sw_i_ls(I)(J) <= lut_rdata_sw_i_d(I)(J)&"00000000000"; 
        --     lut_rdata_sw_q_ls(I)(J) <= lut_rdata_sw_q_d(I)(J)&"00000000000"; 

        -- end generate;

        -- [Summation Diagonal/Off-Diagonal Term]======================================= --
        --                                                                               --
        -- Can Modify according to DPD_CORE eqaution, Always need to check!!             --
        --                                                                               --
        -- ============================================================================= -- 
        -- SUM_Q_POINT = 22;
        -- LUT_Q_POINT = 13;
        -- 
        -- TAP_OUT[0]  = lut_out_A3A3 
        --             = (s25) LUT_RAM[12] << (SUM_Q_POINT - LUT_Q_POINT)
        U_LUTSUM_00_I_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 3+6) port map (CLK, lut_rdata_sw_i(I)(12), lutsum_00_i(I));
        U_LUTSUM_00_Q_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 3+6) port map (CLK, lut_rdata_sw_q(I)(12), lutsum_00_q(I));

        lutsum_00_ls_i(I) <= lutsum_00_i(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);           
        lutsum_00_ls_q(I) <= lutsum_00_q(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);           

        tap_00_i(I) <= sign_extension(lutsum_00_ls_i(I), 27);            
        tap_00_q(I) <= sign_extension(lutsum_00_ls_q(I), 27);            


        -- TAP_OUT[1]  = (sat26) ((s27) lut_out_A2A2 + (s27) lut_out_A2A1 + (s27) lut_out_A20)
        --             =         {(s25) LUT_RAM[11]  + (s25) LUT_RAM[27]  + (s25) LUT_RAM[28]} << (SUM_Q_POINT - LUT_Q_POINT))
        U_LUTSUM_01_I_ADD : ADD4 generic map(HS_MODE, 16) port map(RST, CLK, lut_rdata_sw_i(I)(11), lut_rdata_sw_i(I)(27), lut_rdata_sw_i(I)(28), (others => '0'), lutsum_01_i(I)); 
        U_LUTSUM_01_Q_ADD : ADD4 generic map(HS_MODE, 16) port map(RST, CLK, lut_rdata_sw_q(I)(11), lut_rdata_sw_q(I)(27), lut_rdata_sw_q(I)(28), (others => '0'), lutsum_01_q(I)); 

        U_LUTSUM_01_I_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 18, 5) port map (CLK, lutsum_01_i(I), lutsum_01_i_dly(I));
        U_LUTSUM_01_Q_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 18, 5) port map (CLK, lutsum_01_q(I), lutsum_01_q_dly(I));

        lutsum_01_i_sat(I) <= lutsum_01_i_dly(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);            
        lutsum_01_q_sat(I) <= lutsum_01_q_dly(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);            

        U_LUTSUM_01_I_SAT : SAT_SIGN generic map(HS_MODE, 27, 26) port map(RST, CLK, lutsum_01_i_sat(I), tap_01_i(I));
        U_LUTSUM_01_Q_SAT : SAT_SIGN generic map(HS_MODE, 27, 26) port map(RST, CLK, lutsum_01_q_sat(I), tap_01_q(I));

		-- TAP_OUT[2]  = (sat26) ((s27) lut_out_A1A2 + (s27) lut_out_A1A1 + (s27) lut_out_A10);
        --             =         {(s25) LUT_RAM[25]  + (s25) LUT_RAM[10]  + (s25) LUT_RAM[26]} << (SUM_Q_POINT - LUT_Q_POINT))
        U_LUTSUM_02_I_ADD : ADD4 generic map(HS_MODE, 16) port map(RST, CLK, lut_rdata_sw_i(I)(25), lut_rdata_sw_i(I)(10), lut_rdata_sw_i(I)(26), (others => '0'), lutsum_02_i(I)); 
        U_LUTSUM_02_Q_ADD : ADD4 generic map(HS_MODE, 16) port map(RST, CLK, lut_rdata_sw_q(I)(25), lut_rdata_sw_q(I)(10), lut_rdata_sw_q(I)(26), (others => '0'), lutsum_02_q(I)); 

        U_LUTSUM_02_I_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 18, 6) port map (CLK, lutsum_02_i(I), lutsum_02_i_dly(I));
        U_LUTSUM_02_Q_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 18, 6) port map (CLK, lutsum_02_q(I), lutsum_02_q_dly(I));

        lutsum_02_i_sat(I) <= lutsum_02_i_dly(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);            
        lutsum_02_q_sat(I) <= lutsum_02_q_dly(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);            

        U_LUTSUM_02_I_SAT : SAT_SIGN generic map(HS_MODE, 27, 26) port map(RST, CLK, lutsum_02_i_sat(I), tap_02_i(I));
        U_LUTSUM_02_Q_SAT : SAT_SIGN generic map(HS_MODE, 27, 26) port map(RST, CLK, lutsum_02_q_sat(I), tap_02_q(I));
		-- TAP_OUT[3]  = (sat26) ((s30) lut_out_00 + (s30) lut_out_01  + (s30) lut_out_02  + (s30) lut_out_03  + (s30) lut_out_0A1 + (s30) lut_out_0A2 + (s30) lut_out_001 + (s30) lut_out_010 + (s30) DDR_OUT[0][i] + (s30) DDR_OUT[2][i]);
        --             =         {(s25) LUT_RAM[0] + (s25) LUT_RAM[13] + (s25) LUT_RAM[14] + (s25) LUT_RAM[15] + (s25) LUT_RAM[16] + (s25) LUT_RAM[17]} << (SUM_Q_POINT - LUT_Q_POINT))
        --                      + (s31) (LUT_RAM[29] * Mag[MAX_ADV+1]) >> (LUT3D_Q_POINT + 15 - SUM_Q_POINT)
        --                      + (s31) (LUT_RAM[30] * Mag[MAX_ADV+0]) >> (LUT3D_Q_POINT + 15 - SUM_Q_POINT)
        --                      + (s31) DDR_OUT[0]   
        --                      + (s31) DDR_OUT[2]   
        U_LUTSUM_03_2D_I_ADD : ADD8 generic map(HS_MODE,16) port map(RST, CLK, lut_rdata_sw_i(I)(0),lut_rdata_sw_i(I)(13),lut_rdata_sw_i(I)(14),lut_rdata_sw_i(I)(15),lut_rdata_sw_i(I)(16),lut_rdata_sw_i(I)(17),(others=>'0'),(others=>'0'),lutsum_03_2d_i(I));
        U_LUTSUM_03_2D_Q_ADD : ADD8 generic map(HS_MODE,16) port map(RST, CLK, lut_rdata_sw_q(I)(0),lut_rdata_sw_q(I)(13),lut_rdata_sw_q(I)(14),lut_rdata_sw_q(I)(15),lut_rdata_sw_q(I)(16),lut_rdata_sw_q(I)(17),(others=>'0'),(others=>'0'),lutsum_03_2d_q(I));

        lutsum_03_2d_ls_i(I) <= lutsum_03_2d_i(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);             
        lutsum_03_2d_ls_q(I) <= lutsum_03_2d_q(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);             

        U_LUTSUM_03_2D_I_DLY : SRL16E_DLY generic map(DEVICE,TRUE,28,4) port map(CLK,lutsum_03_2d_ls_i(I),lutsum_03_2d_ls_i_dly(I)); 
        U_LUTSUM_03_2D_Q_DLY : SRL16E_DLY generic map(DEVICE,TRUE,28,4) port map(CLK,lutsum_03_2d_ls_q(I),lutsum_03_2d_ls_q_dly(I)); 

        se_lutsum_03_2d_ls_i(I) <= sign_extension(lutsum_03_2d_ls_i_dly(I), 31);             
        se_lutsum_03_2d_ls_q(I) <= sign_extension(lutsum_03_2d_ls_q_dly(I), 31);             

        se_lut_ram29_i(I) <= sign_extension(lut_rdata_sw_i(I)(29), 30);
        se_lut_ram29_q(I) <= sign_extension(lut_rdata_sw_q(I)(29), 30);

        se_lut_ram30_i(I) <= sign_extension(lut_rdata_sw_i(I)(30), 30);
        se_lut_ram30_q(I) <= sign_extension(lut_rdata_sw_q(I)(30), 30);

        --se_lutsum_03_mag15_idx0(I) <= sign_extension(mag15_sh(I)(0), 18);
        --se_lutsum_03_mag15_idx1(I) <= sign_extension(mag15_sh(I)(1), 18);
        se_lutsum_03_mag15_idx0(I) <= ("000" & mag15_sh(I)(0) );
        se_lutsum_03_mag15_idx1(I) <= ("000" & mag15_sh(I)(1) );

        U_LUTSUM_03_3D0_I: DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",FALSE,TRUE,1,1,FALSE,FALSE)port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),se_lut_ram29_i(I),(others=>'0'),se_lutsum_03_mag15_idx1(I),(others=>'0'),lutsum_03_3d0_i(I),open,open);
        U_LUTSUM_03_3D0_Q: DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",FALSE,TRUE,1,1,FALSE,FALSE)port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),se_lut_ram29_q(I),(others=>'0'),se_lutsum_03_mag15_idx1(I),(others=>'0'),lutsum_03_3d0_q(I),open,open);

        U_LUTSUM_03_3D1_I: DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",TRUE,FALSE,2,2,FALSE,FALSE)port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),se_lut_ram30_i(I),(others=>'0'),se_lutsum_03_mag15_idx0(I),lutsum_03_3d0_i(I),open,lutsum_03_3d1_i(I),open);
        U_LUTSUM_03_3D1_Q: DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",TRUE,FALSE,2,2,FALSE,FALSE)port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),se_lut_ram30_q(I),(others=>'0'),se_lutsum_03_mag15_idx0(I),lutsum_03_3d0_q(I),open,lutsum_03_3d1_q(I),open);

        lutsum_03_3d_rs_i(I) <= lutsum_03_3d1_i(I)(31+LUT3D_Q_POINT+15-SUM_Q_POINT-1 downto LUT3D_Q_POINT+15-SUM_Q_POINT);             -- 12+15-22 = 5
        lutsum_03_3d_rs_q(I) <= lutsum_03_3d1_q(I)(31+LUT3D_Q_POINT+15-SUM_Q_POINT-1 downto LUT3D_Q_POINT+15-SUM_Q_POINT);            

        U_LUTSUM_03_3D_I_DLY : SRL16E_DLY generic map(DEVICE,TRUE,31,3) port map(CLK,lutsum_03_3d_rs_i(I),lutsum_03_3d_rs_i_dly(I)); 
        U_LUTSUM_03_3D_Q_DLY : SRL16E_DLY generic map(DEVICE,TRUE,31,3) port map(CLK,lutsum_03_3d_rs_q(I),lutsum_03_3d_rs_q_dly(I)); 

        se_ddr0_i(I) <= sign_extension(ddr_i(I)(0), 31); 
        se_ddr0_q(I) <= sign_extension(ddr_q(I)(0), 31); 
                                         
        se_ddr2_i(I) <= sign_extension(ddr_i(I)(2), 31); 
        se_ddr2_q(I) <= sign_extension(ddr_q(I)(2), 31); 

        U_LUTSUM_03_I_ADD : ADD4 generic map(HS_MODE, 31) port map(RST, CLK, se_lutsum_03_2d_ls_i(I), lutsum_03_3d_rs_i_dly(I), se_ddr0_i(I), se_ddr2_i(I), lutsum_03_i(I));
        U_LUTSUM_03_Q_ADD : ADD4 generic map(HS_MODE, 31) port map(RST, CLK, se_lutsum_03_2d_ls_q(I), lutsum_03_3d_rs_q_dly(I), se_ddr0_q(I), se_ddr2_q(I), lutsum_03_q(I));

        U_LUTSUM_03_I_SAT : SAT_SIGN generic map(HS_MODE, 33, 26) port map(RST, CLK, lutsum_03_i(I), tap_03_i(I));
        U_LUTSUM_03_Q_SAT : SAT_SIGN generic map(HS_MODE, 33, 26) port map(RST, CLK, lutsum_03_q(I), tap_03_q(I));

		-- TAP_OUT[4]  = (sat26) ((s29) lut_out_10  + (s29) lut_out_11 + (s29) lut_out_12 + (s29) lut_out_102 + (s29) lut_out_120 + (s29) lut_out_101 + (s29) lut_out_110);
        --             =         {(s25) LUT_RAM[18] + (s25) LUT_RAM[1] + (s25) LUT_RAM[19]} << (SUM_Q_POINT - LUT_Q_POINT))
        --                      + (s31) (LUT_RAM[31] * Mag[MAX_ADV+2]) >> (LUT3D_Q_POINT + 15 - SUM_Q_POINT)
        --                      + (s31) (LUT_RAM[32] * Mag[MAX_ADV+0]) >> (LUT3D_Q_POINT + 15 - SUM_Q_POINT)
        --                      + (s31) (LUT_RAM[33] * Mag[MAX_ADV+1]) >> (LUT3D_Q_POINT + 15 - SUM_Q_POINT)
        --                      + (s31) (LUT_RAM[34] * Mag[MAX_ADV+0]) >> (LUT3D_Q_POINT + 15 - SUM_Q_POINT)
        U_LUTSUM_04_2D_I_ADD : ADD4 generic map(HS_MODE,16) port map(RST, CLK, lut_rdata_sw_i(I)(18),lut_rdata_sw_i(I)(1),lut_rdata_sw_i(I)(19),(others=>'0'),lutsum_04_2d_i(I));
        U_LUTSUM_04_2D_Q_ADD : ADD4 generic map(HS_MODE,16) port map(RST, CLK, lut_rdata_sw_q(I)(18),lut_rdata_sw_q(I)(1),lut_rdata_sw_q(I)(19),(others=>'0'),lutsum_04_2d_q(I));

        P_LUTSUM_04_2D : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                lutsum_04_2d_ls_i(I) <= lutsum_04_2d_i(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);            
                lutsum_04_2d_ls_q(I) <= lutsum_04_2d_q(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);            
            end if;
        end process;

        se_lutsum_04_2d_ls_i(I) <= sign_extension(lutsum_04_2d_ls_i(I), 31);            
        se_lutsum_04_2d_ls_q(I) <= sign_extension(lutsum_04_2d_ls_q(I), 31);            

        se_lut_ram31_i(I) <= sign_extension(lut_rdata_sw_i(I)(31), 30);
        se_lut_ram31_q(I) <= sign_extension(lut_rdata_sw_q(I)(31), 30);

        se_lut_ram32_i(I) <= sign_extension(lut_rdata_sw_i(I)(32), 30);
        se_lut_ram32_q(I) <= sign_extension(lut_rdata_sw_q(I)(32), 30);

        se_lut_ram33_i(I) <= sign_extension(lut_rdata_sw_i(I)(33), 30);
        se_lut_ram33_q(I) <= sign_extension(lut_rdata_sw_q(I)(33), 30);

        se_lut_ram34_i(I) <= sign_extension(lut_rdata_sw_i(I)(34), 30);
        se_lut_ram34_q(I) <= sign_extension(lut_rdata_sw_q(I)(34), 30);

        --se_lutsum_04_mag15_idx0(I) <= sign_extension(mag15_sh(I)(0), 18); 
        --se_lutsum_04_mag15_idx1(I) <= sign_extension(mag15_sh(I)(1), 18); 
        --se_lutsum_04_mag15_idx2(I) <= sign_extension(mag15_sh(I)(2), 18); 
        se_lutsum_04_mag15_idx0(I) <= ("000" & mag15_sh(I)(0) ); 
        se_lutsum_04_mag15_idx1(I) <= ("000" & mag15_sh(I)(1) ); 
        se_lutsum_04_mag15_idx2(I) <= ("000" & mag15_sh(I)(2) ); 

        U_LUTSUM_04_3D0_I: DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",FALSE,TRUE,1,1,FALSE,FALSE)port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),se_lut_ram31_i(I),(others=>'0'),se_lutsum_04_mag15_idx2(I),(others=>'0'),lutsum_04_3d0_i(I),open,open);
        U_LUTSUM_04_3D0_Q: DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",FALSE,TRUE,1,1,FALSE,FALSE)port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),se_lut_ram31_q(I),(others=>'0'),se_lutsum_04_mag15_idx2(I),(others=>'0'),lutsum_04_3d0_q(I),open,open);

        U_LUTSUM_04_3D1_I: DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",TRUE,FALSE,2,2,FALSE,FALSE)port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),se_lut_ram32_i(I),(others=>'0'),se_lutsum_04_mag15_idx0(I),lutsum_04_3d0_i(I),open,lutsum_04_3d1_i(I),open);
        U_LUTSUM_04_3D1_Q: DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",TRUE,FALSE,2,2,FALSE,FALSE)port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),se_lut_ram32_q(I),(others=>'0'),se_lutsum_04_mag15_idx0(I),lutsum_04_3d0_q(I),open,lutsum_04_3d1_q(I),open);

        lutsum_04_3d1_rs_i(I) <= lutsum_04_3d1_i(I)(31+LUT3D_Q_POINT+15-SUM_Q_POINT-1 downto LUT3D_Q_POINT+15-SUM_Q_POINT);            
        lutsum_04_3d1_rs_q(I) <= lutsum_04_3d1_q(I)(31+LUT3D_Q_POINT+15-SUM_Q_POINT-1 downto LUT3D_Q_POINT+15-SUM_Q_POINT);            


        U_LUTSUM_04_3D2_I: DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",FALSE,TRUE,1,1,FALSE,FALSE)port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),se_lut_ram33_i(I),(others=>'0'),se_lutsum_04_mag15_idx1(I),(others=>'0'),lutsum_04_3d2_i(I),open,open);
        U_LUTSUM_04_3D2_Q: DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",FALSE,TRUE,1,1,FALSE,FALSE)port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),se_lut_ram33_q(I),(others=>'0'),se_lutsum_04_mag15_idx1(I),(others=>'0'),lutsum_04_3d2_q(I),open,open);

        U_LUTSUM_04_3D3_I: DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",TRUE,FALSE,2,2,FALSE,FALSE)port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),se_lut_ram34_i(I),(others=>'0'),se_lutsum_04_mag15_idx0(I),lutsum_04_3d2_i(I),open,lutsum_04_3d3_i(I),open);
        U_LUTSUM_04_3D3_Q: DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",TRUE,FALSE,2,2,FALSE,FALSE)port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),se_lut_ram34_q(I),(others=>'0'),se_lutsum_04_mag15_idx0(I),lutsum_04_3d2_q(I),open,lutsum_04_3d3_q(I),open);

        lutsum_04_3d3_rs_i(I) <= lutsum_04_3d3_i(I)(31+LUT3D_Q_POINT+15-SUM_Q_POINT-1 downto LUT3D_Q_POINT+15-SUM_Q_POINT);        
        lutsum_04_3d3_rs_q(I) <= lutsum_04_3d3_q(I)(31+LUT3D_Q_POINT+15-SUM_Q_POINT-1 downto LUT3D_Q_POINT+15-SUM_Q_POINT);            

        U_LUTSUM_04_I_ADD : ADD4 generic map(HS_MODE,31) port map(RST, CLK, se_lutsum_04_2d_ls_i(I),lutsum_04_3d1_rs_i(I),lutsum_04_3d3_rs_i(I),(others=>'0'),lutsum_04_i(I));
        U_LUTSUM_04_Q_ADD : ADD4 generic map(HS_MODE,31) port map(RST, CLK, se_lutsum_04_2d_ls_q(I),lutsum_04_3d1_rs_q(I),lutsum_04_3d3_rs_q(I),(others=>'0'),lutsum_04_q(I));

        U_LUTSUM_04_I_SAT : SAT_SIGN generic map(HS_MODE, 33, 26) port map(RST, CLK, lutsum_04_i(I), sat_lutsum_04_i(I));
        U_LUTSUM_04_Q_SAT : SAT_SIGN generic map(HS_MODE, 33, 26) port map(RST, CLK, lutsum_04_q(I), sat_lutsum_04_q(I));

        U_LUTSUM_04_I_DLY : SRL16E_DLY generic map(DEVICE,TRUE,26,4) port map(CLK,sat_lutsum_04_i(I),tap_04_i(I)); 
        U_LUTSUM_04_Q_DLY : SRL16E_DLY generic map(DEVICE,TRUE,26,4) port map(CLK,sat_lutsum_04_q(I),tap_04_q(I)); 

        --
		-- TAP_OUT[5]  = (sat26) ((s29) lut_out_20  + (s29) lut_out_21  + (s29) lut_out_22 + (s29) lut_out_23 + (s29)DDR_OUT[1][i]);
        --             =         {(s25) LUT_RAM[20] + (s25) LUT_RAM[21] + (s25) LUT_RAM[2] + (s25) LUT_RAM[22]} << (SUM_Q_POINT - LUT_Q_POINT))
        --                      + (s31) DDR_OUT[1]   
        U_LUTSUM_05_2D_I_ADD : ADD4 generic map(HS_MODE, 16) port map(RST, CLK, lut_rdata_sw_i(I)(20), lut_rdata_sw_i(I)(21), lut_rdata_sw_i(I)(2), lut_rdata_sw_i(I)(22), lutsum_05_i(I)); 
        U_LUTSUM_05_2D_Q_ADD : ADD4 generic map(HS_MODE, 16) port map(RST, CLK, lut_rdata_sw_q(I)(20), lut_rdata_sw_q(I)(21), lut_rdata_sw_q(I)(2), lut_rdata_sw_q(I)(22), lutsum_05_q(I)); 

        U_LUTSUM_05_2D_I_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 18, 4) port map (CLK, lutsum_05_i(I), lutsum_05_i_dly(I));
        U_LUTSUM_05_2D_Q_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 18, 4) port map (CLK, lutsum_05_q(I), lutsum_05_q_dly(I));

        lutsum_05_ls_i(I) <= lutsum_05_i_dly(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);            
        lutsum_05_ls_q(I) <= lutsum_05_q_dly(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);            

        P_LUTSUM_05_DDRSUM : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                lutsum_05_ddr_i(I) <= sign_extension(lutsum_05_ls_i(I), 29) + sign_extension(ddr_i(I)(1), 29);            
                lutsum_05_ddr_q(I) <= sign_extension(lutsum_05_ls_q(I), 29) + sign_extension(ddr_q(I)(1), 29);            
            end if;
        end process;

        U_LUTSUM_05_SAT_I : SAT_SIGN generic map(HS_MODE, 29, 26) port map(RST, CLK, lutsum_05_ddr_i(I), sat_lutsum_05_ddr_i(I));
        U_LUTSUM_05_SAT_Q : SAT_SIGN generic map(HS_MODE, 29, 26) port map(RST, CLK, lutsum_05_ddr_q(I), sat_lutsum_05_ddr_q(I));

        U_LUTSUM_05_I_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 26, 4) port map (CLK, sat_lutsum_05_ddr_i(I), tap_05_i(I));
        U_LUTSUM_05_Q_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 26, 4) port map (CLK, sat_lutsum_05_ddr_q(I), tap_05_q(I));

        --
		-- TAP_OUT[6]  = (sat26) ((s29) lut_out_33 + (s29) lut_out_30  + (s29) lut_out_32  + (s29) DDR_OUT[3][i]);
        --             =         {(s25) LUT_RAM[3] + (s25) LUT_RAM[23] + (s25) LUT_RAM[24]} << (SUM_Q_POINT - LUT_Q_POINT))
        --                      + (s31) DDR_OUT[3]   
        U_LUTSUM_06_2D_I_ADD : ADD4 generic map(HS_MODE, 16) port map(RST, CLK, lut_rdata_sw_i(I)(3), lut_rdata_sw_i(I)(23), lut_rdata_sw_i(I)(24), (others => '0'), lutsum_06_i(I)); 
        U_LUTSUM_06_2D_Q_ADD : ADD4 generic map(HS_MODE, 16) port map(RST, CLK, lut_rdata_sw_q(I)(3), lut_rdata_sw_q(I)(23), lut_rdata_sw_q(I)(24), (others => '0'), lutsum_06_q(I)); 

        U_LUTSUM_06_2D_I_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 18, 4) port map (CLK, lutsum_06_i(I), lutsum_06_i_dly(I));
        U_LUTSUM_06_2D_Q_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 18, 4) port map (CLK, lutsum_06_q(I), lutsum_06_q_dly(I));

        lutsum_06_ls_i(I) <= lutsum_06_i_dly(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);            
        lutsum_06_ls_q(I) <= lutsum_06_q_dly(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);            

        P_LUTSUM_06_DDRSUM : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                lutsum_06_ddr_i(I) <= sign_extension(lutsum_06_ls_i(I), 29) + sign_extension(ddr_i(I)(3), 29);            
                lutsum_06_ddr_q(I) <= sign_extension(lutsum_06_ls_q(I), 29) + sign_extension(ddr_q(I)(3), 29);            
            end if;
        end process;

        U_LUTSUM_06_I_SAT : SAT_SIGN generic map(HS_MODE, 29, 26) port map(RST, CLK, lutsum_06_ddr_i(I), sat_lutsum_06_ddr_i(I));
        U_LUTSUM_06_Q_SAT : SAT_SIGN generic map(HS_MODE, 29, 26) port map(RST, CLK, lutsum_06_ddr_q(I), sat_lutsum_06_ddr_q(I));

        U_LUTSUM_06_I_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 26, 5) port map (CLK, sat_lutsum_06_ddr_i(I),tap_06_i(I));
        U_LUTSUM_06_Q_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 26, 5) port map (CLK, sat_lutsum_06_ddr_q(I),tap_06_q(I));

        --
		-- TAP_OUT[7]  = lut_out_44;
        --             = (s25) LUT_RAM[4] << (SUM_Q_POINT - LUT_Q_POINT)
        U_LUTSUM_07_I_DLY : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 16) port map (CLK, lut_rdata_sw_i(I)(4), open, lutsum_07_i(I));
        U_LUTSUM_07_Q_DLY : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 16) port map (CLK, lut_rdata_sw_q(I)(4), open, lutsum_07_q(I));

        lutsum_07_ls_i(I) <= lutsum_07_i(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);           
        lutsum_07_ls_q(I) <= lutsum_07_q(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);           

        tap_07_i(I) <= sign_extension(lutsum_07_ls_i(I), 27);            
        tap_07_q(I) <= sign_extension(lutsum_07_ls_q(I), 27);            


        --
		-- TAP_OUT[8]  = lut_out_55;
        --             = (s25) LUT_RAM[5] << (SUM_Q_POINT - LUT_Q_POINT)
        U_LUTSUM_08_I_DLY : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 17) port map (CLK, lut_rdata_sw_i(I)(5), open, lutsum_08_i(I));
        U_LUTSUM_08_Q_DLY : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 17) port map (CLK, lut_rdata_sw_q(I)(5), open, lutsum_08_q(I));

        lutsum_08_ls_i(I) <= lutsum_08_i(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);           
        lutsum_08_ls_q(I) <= lutsum_08_q(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);           

        tap_08_i(I) <= sign_extension(lutsum_08_ls_i(I), 27);            
        tap_08_q(I) <= sign_extension(lutsum_08_ls_q(I), 27);            


        --
		-- TAP_OUT[9]  = lut_out_66;
        --             = (s25) LUT_RAM[6] << (SUM_Q_POINT - LUT_Q_POINT)
        U_LUTSUM_09_I_DLY : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 18) port map (CLK, lut_rdata_sw_i(I)(6), open, lutsum_09_i(I));
        U_LUTSUM_09_Q_DLY : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 18) port map (CLK, lut_rdata_sw_q(I)(6), open, lutsum_09_q(I));

        lutsum_09_ls_i(I) <= lutsum_09_i(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);           
        lutsum_09_ls_q(I) <= lutsum_09_q(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);           

        tap_09_i(I) <= sign_extension(lutsum_09_ls_i(I), 27);            
        tap_09_q(I) <= sign_extension(lutsum_09_ls_q(I), 27);            


        --
		-- TAP_OUT[10] = lut_out_77;
        --             = (s25) LUT_RAM[7] << (SUM_Q_POINT - LUT_Q_POINT)
        U_LUTSUM_10_I_DLY : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 19) port map (CLK, lut_rdata_sw_i(I)(7), open, lutsum_10_i(I));
        U_LUTSUM_10_Q_DLY : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 19) port map (CLK, lut_rdata_sw_q(I)(7), open, lutsum_10_q(I));

        lutsum_10_ls_i(I) <= lutsum_10_i(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);           
        lutsum_10_ls_q(I) <= lutsum_10_q(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);           

        tap_10_i(I) <= sign_extension(lutsum_10_ls_i(I), 27);            
        tap_10_q(I) <= sign_extension(lutsum_10_ls_q(I), 27);            

        --
		-- TAP_OUT[11] = lut_out_88;
        --             = (s25) LUT_RAM[8] << (SUM_Q_POINT - LUT_Q_POINT)
        U_LUTSUM_11_I_DLY : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 20) port map (CLK, lut_rdata_sw_i(I)(8), open, lutsum_11_i(I));
        U_LUTSUM_11_Q_DLY : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 20) port map (CLK, lut_rdata_sw_q(I)(8), open, lutsum_11_q(I));

        lutsum_11_ls_i(I) <= lutsum_11_i(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);           
        lutsum_11_ls_q(I) <= lutsum_11_q(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);           

        tap_11_i(I) <= sign_extension(lutsum_11_ls_i(I), 27);            
        tap_11_q(I) <= sign_extension(lutsum_11_ls_q(I), 27);            


        --
		-- TAP_OUT[12] = lut_out_99;
        --             = (s25) LUT_RAM[9] << (SUM_Q_POINT - LUT_Q_POINT)
        U_LUTSUM_12_I_DLY : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 21) port map (CLK, lut_rdata_sw_i(I)(9), open, lutsum_12_i(I));
        U_LUTSUM_12_Q_DLY : SRLC32E_DLY generic map(DEVICE, HS_MODE, 16, 21) port map (CLK, lut_rdata_sw_q(I)(9), open, lutsum_12_q(I));

        lutsum_12_ls_i(I) <= lutsum_12_i(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);           
        lutsum_12_ls_q(I) <= lutsum_12_q(I) & zeros(SUM_Q_POINT-LUT_Q_POINT-1 downto 0);           

        tap_12_i(I) <= sign_extension(lutsum_12_ls_i(I), 27);            
        tap_12_q(I) <= sign_extension(lutsum_12_ls_q(I), 27);            

        LUT_ADD_I(I)( 0) <=  tap_00_i(I);           
        LUT_ADD_Q(I)( 0) <=  tap_00_q(I);           

        LUT_ADD_I(I)( 1) <=  ( tap_01_i(I)(25) & tap_01_i(I) );           
        LUT_ADD_Q(I)( 1) <=  ( tap_01_q(I)(25) & tap_01_q(I) );           
                             
        LUT_ADD_I(I)( 2) <=  ( tap_02_i(I)(25) & tap_02_i(I) );
        LUT_ADD_Q(I)( 2) <=  ( tap_02_q(I)(25) & tap_02_q(I) );
                             
        LUT_ADD_I(I)( 3) <=  ( tap_03_i(I)(25) & tap_03_i(I) );
        LUT_ADD_Q(I)( 3) <=  ( tap_03_q(I)(25) & tap_03_q(I) );

        LUT_ADD_I(I)( 4) <=  ( tap_04_i(I)(25) & tap_04_i(I) );
        LUT_ADD_Q(I)( 4) <=  ( tap_04_q(I)(25) & tap_04_q(I) );

        LUT_ADD_I(I)( 5) <=  ( tap_05_i(I)(25) & tap_05_i(I) );
        LUT_ADD_Q(I)( 5) <=  ( tap_05_q(I)(25) & tap_05_q(I) );

        LUT_ADD_I(I)( 6) <=  ( tap_06_i(I)(25) & tap_06_i(I) );
        LUT_ADD_Q(I)( 6) <=  ( tap_06_q(I)(25) & tap_06_q(I) );
                             
        LUT_ADD_I(I)( 7) <=  tap_07_i(I);
        LUT_ADD_Q(I)( 7) <=  tap_07_q(I);
                             
        LUT_ADD_I(I)( 8) <=  tap_08_i(I);                
        LUT_ADD_Q(I)( 8) <=  tap_08_q(I);                
                             
        LUT_ADD_I(I)( 9) <=  tap_09_i(I);                
        LUT_ADD_Q(I)( 9) <=  tap_09_q(I);                
                             
        LUT_ADD_I(I)(10) <=  tap_10_i(I);                
        LUT_ADD_Q(I)(10) <=  tap_10_q(I);                
                             
        LUT_ADD_I(I)(11) <=  tap_11_i(I);                
        LUT_ADD_Q(I)(11) <=  tap_11_q(I);                
                             
        LUT_ADD_I(I)(12) <=  tap_12_i(I);                
        LUT_ADD_Q(I)(12) <=  tap_12_q(I);                

    end generate;

end arc_DPD_3D_LUT41_CONFIG;
