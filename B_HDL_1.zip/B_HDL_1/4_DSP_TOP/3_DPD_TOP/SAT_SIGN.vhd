-- k1340.heo
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_signed.all;

entity SAT_SIGN is
generic(
    HS_MODE          : boolean := TRUE;
    INPUT_BIT        : natural;
    OUTPUT_BIT       : natural 
    );
port( 
    RST              : in  std_logic;
    CLK              : in  std_logic;
    DATA_IN          : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT         : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end SAT_SIGN;

architecture arc_SAT_SIGN of SAT_SIGN is

constant p_sat       : std_logic_vector( INPUT_BIT-2 downto OUTPUT_BIT-1) := (others => '0');
constant n_sat       : std_logic_vector( INPUT_BIT-2 downto OUTPUT_BIT-1) := (others => '1');

constant p_max       : std_logic_vector(OUTPUT_BIT-2 downto 0) := (others => '1');
constant n_max       : std_logic_vector(OUTPUT_BIT-2 downto 0) := (others => '0');

constant p_sat_out   : std_logic_vector(OUTPUT_BIT-1 downto 0) := '0' & p_max;
constant n_sat_out   : std_logic_vector(OUTPUT_BIT-1 downto 0) := '1' & n_max;

signal   p_sat_flg   : std_logic;
signal   n_sat_flg   : std_logic;

signal   sat_flg     : std_logic_vector( 1 downto 0);
signal   data_d1     : std_logic_vector(OUTPUT_BIT-1 downto 0);

signal   sat_out     : std_logic_vector(OUTPUT_BIT-1 downto 0);

begin

    G_Normal_Operation : if (HS_MODE = FALSE) generate begin
        -- 1st Clock
        P_Saturation : process(RST, CLK) begin
            if (RST = '1') then
                sat_out <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                -- Positive Value
                if (DATA_IN(INPUT_BIT-1) = '0') then 
                    -- Not Saturated
                    if (DATA_IN(INPUT_BIT-2 downto OUTPUT_BIT-1) = p_sat) then 
                        sat_out <= DATA_IN(INPUT_BIT-1) & DATA_IN(OUTPUT_BIT-2 downto 0);
                    -- Positive Saturated
                    else
                        sat_out <= DATA_IN(INPUT_BIT-1) & p_max;
                    end if;

                -- Negative Value
                else                                 
                    -- Not Saturated
                    if (DATA_IN(INPUT_BIT-2 downto OUTPUT_BIT-1) = n_sat) then 
                        sat_out <= DATA_IN(INPUT_BIT-1) & DATA_IN(OUTPUT_BIT-2 downto 0);
                    -- Negative Saturated
                    else
                        sat_out <= DATA_IN(INPUT_BIT-1) & n_max;
                    end if;
                end if; 
            end if;
        end process;

        -- 2nd Clock
        P_Delay_Fix_NM : process(RST, CLK) begin
            if (RST = '1') then
                DATA_OUT <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                DATA_OUT <= sat_out;
            end if;
        end process;

        p_sat_flg <= '0'; 
        n_sat_flg <= '0'; 
                 
        sat_flg   <= (others => '0'); 
        data_d1   <= (others => '0'); 

    end generate;

    G_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
        -- 1st Clock
        P_SAT_Flag_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (DATA_IN(INPUT_BIT-2 downto OUTPUT_BIT-1) = p_sat) then 
                    p_sat_flg <= '0'; 
                else
                    p_sat_flg <= '0' nor DATA_IN(INPUT_BIT-1); 
                end if;

                if (DATA_IN(INPUT_BIT-2 downto OUTPUT_BIT-1) = n_sat) then 
                    n_sat_flg <= '0'; 
                else
                    n_sat_flg <= '1' and DATA_IN(INPUT_BIT-1); 
                end if;
            end if;
        end process;

        sat_flg <= n_sat_flg & p_sat_flg;

        -- 1st Clock
        P_SAT_Flag_Latency_Compensation_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                data_d1 <= DATA_IN(INPUT_BIT-1) & DATA_IN(OUTPUT_BIT-2 downto 0); 
            end if;
        end process;

        -- 2nd Clock
        P_Saturation_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                case (sat_flg) is
                    when "01"   => sat_out <= p_sat_out; 
                    when "10"   => sat_out <= n_sat_out; 
                    when others => sat_out <= data_d1; 
                end case;
            end if;
        end process;

        DATA_OUT <= sat_out; 

    end generate;

end arc_SAT_SIGN;
