library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity PIMD_IM3_GEN is
generic(
    DEVICE                       : string  := "ULTRASCALE";
    HOVS                         : natural :=           1 ;
    TX_ANT_NUM                   : natural :=           4 ;
    VERSION                      : string  := "A"  -- A : ATnT DB AWS/PCS 's PCS
    );
port(
    RST                          : in  std_logic;           -- Reset, Active High
    CLK                          : in  std_logic;

    -- INTRA_BAND_SEL_IN            : in  std_logic;
    -- INTER_BAND_TYPE1_SEL_IN      : in  std_logic_vector( 1 downto 0);
    -- INTER_BAND_TYPE2_SEL_IN      : in  std_logic_vector( 1 downto 0);

	INTRA_BAND_SEL_IN            : in  std_logic_vector(TX_ANT_NUM-1 downto 0);
    INTER_BAND_TYPE1_SEL_IN      : in  std_logic_array2(TX_ANT_NUM-1 downto 0);
    INTER_BAND_TYPE2_SEL_IN      : in  std_logic_array2(TX_ANT_NUM-1 downto 0);

    PIM_CFR_REF_VLD_IN           : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_CFR_REF_I_IN             : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_CFR_REF_Q_IN             : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    PIM_INTERB_SRC_I_IN          : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_INTERB_SRC_Q_IN          : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    PIM_INTRA_BAND_VLD_OUT       : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_INTRA_BAND_I_OUT         : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_INTRA_BAND_Q_OUT         : out std_logic_array16(TX_ANT_NUM-1 downto 0);

    PIM_INTER_TYPE1_I_OUT        : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_INTER_TYPE1_Q_OUT        : out std_logic_array16(TX_ANT_NUM-1 downto 0);

    PIM_INTER_TYPE2_I_OUT        : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_INTER_TYPE2_Q_OUT        : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    
    DBG_PIM_SUM_I_OUT            : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    DBG_PIM_SUM_Q_OUT            : out std_logic_array16(TX_ANT_NUM-1 downto 0) 
    );
end PIMD_IM3_GEN;

architecture arc_PIMD_IM3_GEN of PIMD_IM3_GEN is

constant HS_MODE : boolean := TRUE;

component DSP48E_MULT is
generic(
    DEVICE                      : string  := "ULTRASCALE";
    DSP48_MODECTRL              : boolean :=       FALSE ;
    DSP48_PREADDER_USE          : boolean :=        TRUE ;
    DSP48_PREADDER_MODE         : string  :=        "ADD"; -- "ADD" or "SUB" 
    DSP48_PCIN_USE              : boolean :=       FALSE ;
    DSP48_PCOUT_USE             : boolean :=       FALSE ;

    A_nREG                      : integer :=           2 ; -- 0, 1, 2
    B_nREG                      : integer :=           2 ; -- 0, 1, 2

    C_EN                        : boolean :=        TRUE ; -- RND ENable
    RND_SYMMETRY                : boolean :=       FALSE 
    );
port(
    CLK                         : in  std_logic;

    ALUMODE_IN                  : in  std_logic_vector( 3 downto 0);
    OPMODE_IN                   : in  std_logic_vector( 8 downto 0);

    C_IN                        : in  std_logic_vector(47 downto 0); -- RND Value
    A_IN                        : in  std_logic_vector(29 downto 0);
    D_IN                        : in  std_logic_vector(26 downto 0);
    B_IN                        : in  std_logic_vector(17 downto 0);

    P_CIN                       : in  std_logic_vector(47 downto 0);
    P_COUT                      : out std_logic_vector(47 downto 0);

    P_OUT                       : out std_logic_vector(47 downto 0);
    CRRY_OUT                    : out std_logic
    );
end component;

component SAT_SIGN is
generic(
    HS_MODE                     : boolean := TRUE;
    INPUT_BIT                   : natural;
    OUTPUT_BIT                  : natural 
    );
port( 
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    DATA_IN                     : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT                    : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

component SAT_UNSIGN is
generic(
    HS_MODE    : boolean :=  TRUE;  -- High Speed Mode (Operating Clock > 307.2MHz)
    INPUT_BIT  : natural;
    OUTPUT_BIT : natural
    );
port( 
    RST        : in  std_logic;
    CLK        : in  std_logic;
    DATA_IN    : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT   : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

component SRL16E_DLY is
generic(
    DEVICE                       : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HS_MODE                      : boolean :=        TRUE ;

    BIT_WIDTH                    : natural;
    DELAY_NUM                    : natural
    );
port(
    CLK                          : in  std_logic;
    DATA_IN                      : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT                     : out std_logic_vector(BIT_WIDTH-1 downto 0) 
    );
end component;

-- INPUT
-- signal s_intra_band_sel_in       : std_logic;
-- signal s_inter_type1_sel_in      : std_logic_vector( 1 downto 0);
-- signal s_inter_type2_sel_in      : std_logic_vector( 1 downto 0);
signal s_intra_band_sel_in       : std_logic_vector(TX_ANT_NUM-1 downto 0);
signal s_inter_type1_sel_in      : std_logic_array2(TX_ANT_NUM-1 downto 0);
signal s_inter_type2_sel_in      : std_logic_array2(TX_ANT_NUM-1 downto 0);


signal s_pim_cfr_ref_vld         : std_logic_vector(TX_ANT_NUM-1 downto 0);     
signal s_pim_cfr_ref_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);     
signal s_pim_cfr_ref_i_neg       : std_logic_array16(TX_ANT_NUM-1 downto 0);     
signal s_pim_cfr_ref_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);     
signal s_pim_cfr_ref_i_dly       : std_logic_array16(TX_ANT_NUM-1 downto 0);     
signal s_pim_cfr_ref_q_dly       : std_logic_array16(TX_ANT_NUM-1 downto 0);     
signal s_pim_interb_src_i_dly    : std_logic_array16(TX_ANT_NUM-1 downto 0);     
signal s_pim_interb_src_q_dly    : std_logic_array16(TX_ANT_NUM-1 downto 0);     
signal s_pim_interb_src_i        : std_logic_array16(TX_ANT_NUM-1 downto 0);     
signal s_pim_interb_src_q        : std_logic_array16(TX_ANT_NUM-1 downto 0);     
-- dsp48e format
-- signal c_in_dsp48_00             : std_logic_array48(TX_ANT_NUM-1 downto 0);
-- signal a_in_dsp48_00             : std_logic_array30(TX_ANT_NUM-1 downto 0);
-- signal d_in_dsp48_00             : std_logic_array27(TX_ANT_NUM-1 downto 0);
-- signal b_in_dsp48_00             : std_logic_array18(TX_ANT_NUM-1 downto 0);
-- signal p_cin_dsp48_00            : std_logic_array48(TX_ANT_NUM-1 downto 0);
-- signal p_cout_dsp48_00           : std_logic_array48(TX_ANT_NUM-1 downto 0);
-- signal p_out_dsp48_00            : std_logic_array48(TX_ANT_NUM-1 downto 0);
------- Conjugated Multiplication
signal s_pim_intra_band_vld_out  : std_logic_vector(TX_ANT_NUM-1 downto 0);     
signal s_pim_intra_band_i_out    : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );     
signal s_pim_intra_band_q_out    : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );     
signal s_pim_intra_band_i_out_d  : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );     
signal s_pim_intra_band_q_out_d  : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );     
signal s_pim_intra_band_i_out_d2 : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );     
signal s_pim_intra_band_q_out_d2 : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );     

signal s_pim_inter_type1_i_out   : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );     
signal s_pim_inter_type1_q_out   : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );     
signal s_pim_inter_type2_i_out   : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );     
signal s_pim_inter_type2_q_out   : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal a_in_dsp48_01             : std_logic_array30(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal d_in_dsp48_01             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal b_in_dsp48_01             : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal p_cout_dsp48_01            : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
--signal dummy0                    : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
--signal dummy1                    : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
--signal dummy2                    : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal a_in_dsp48_02             : std_logic_array30(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal d_in_dsp48_02             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal b_in_dsp48_02             : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal p_cout_dsp48_02            : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal a_in_dsp48_03             : std_logic_array30(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal d_in_dsp48_03             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal b_in_dsp48_03             : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal p_cout_dsp48_03            : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal s_i_01_34b                : std_logic_array34(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_01_34b                : std_logic_array34(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_i_01_29b                : std_logic_array29(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_01_29b                : std_logic_array29(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal res_i_01_27b              : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal res_q_01_27b              : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
------ ~Conjugated Multiplication
------ Normal and Conjugated multiplication A
signal d_in_dsp48_04             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal b_in_dsp48_04             : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal p_cout_dsp48_04            : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal d_in_dsp48_05             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal b_in_dsp48_05             : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal p_cout_dsp48_05            : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal d_in_dsp48_06             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal b_in_dsp48_06             : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal p_cout_dsp48_06            : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal d_in_dsp48_07             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal b_in_dsp48_07             : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal p_cout_dsp48_07            : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal s_i_02_44b                : std_logic_array44(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_02_44b                : std_logic_array44(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_i_03_44b                : std_logic_array44(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_03_44b                : std_logic_array44(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal s_i_04_19b                : std_logic_array19(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_04_19b                : std_logic_array19(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_i_05_19b                : std_logic_array19(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_05_19b                : std_logic_array19(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_i_04_20b                : std_logic_array20(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_04_20b                : std_logic_array20(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_i_05_20b                : std_logic_array20(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_05_20b                : std_logic_array20(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal x1_x1_x2c_i_16b           : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal x1_x1_x2c_q_16b           : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal x1_x2_x1c_i_16b           : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal x1_x2_x1c_q_16b           : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
------ ~Normal and Conjugated multiplication A
------ Normal and Conjugated multiplication B
signal d_in_dsp48_08             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal b_in_dsp48_08             : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal p_cout_dsp48_08            : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal d_in_dsp48_09             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal b_in_dsp48_09             : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal p_cout_dsp48_09            : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal d_in_dsp48_10             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal b_in_dsp48_10             : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal p_cout_dsp48_10            : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal d_in_dsp48_11             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal b_in_dsp48_11             : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal p_cout_dsp48_11            : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal s_i_06_44b                : std_logic_array44(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_06_44b                : std_logic_array44(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_i_07_44b                : std_logic_array44(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_07_44b                : std_logic_array44(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal s_i_08_19b                : std_logic_array19(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_08_19b                : std_logic_array19(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_i_09_19b                : std_logic_array19(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_09_19b                : std_logic_array19(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_i_08_20b                : std_logic_array20(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_08_20b                : std_logic_array20(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_i_09_20b                : std_logic_array20(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_09_20b                : std_logic_array20(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal x2_x1_x2c_i_16b           : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal x2_x1_x2c_q_16b           : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal x2_x2_x1c_i_16b           : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal x2_x2_x1c_q_16b           : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
------ ~Normal and Conjugated multiplication B
------ Complex Norm
signal d_in_dsp48_12             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal b_in_dsp48_12             : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal p_cout_dsp48_12           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal d_in_dsp48_13             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal b_in_dsp48_13             : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal p_out_dsp48_13            : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_11_28bit                : std_logic_array28(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal x2_x2c_i_27b              : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
------ ~Complex Norm
------ Real multiplication A, B
signal s_i_10_18b                : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_10_18b                : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_i_10_19b                : std_logic_array19(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_q_10_19b                : std_logic_array19(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal d_in_dsp48_14             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal b_in_dsp48_14             : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal p_cout_dsp48_14           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal d_in_dsp48_15             : std_logic_array27(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal b_in_dsp48_15             : std_logic_array18(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal p_cout_dsp48_15           : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );

signal x2_x2_x2c_i_16b           : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal x2_x2_x2c_q_16b           : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
------ ~Real multiplication A, B
-- dbg_sum
signal c_in_dsp48_20             : std_logic_array48(TX_ANT_NUM-1 downto 0);
signal a_in_dsp48_20             : std_logic_array30(TX_ANT_NUM-1 downto 0);
signal d_in_dsp48_20             : std_logic_array27(TX_ANT_NUM-1 downto 0);
signal b_in_dsp48_20             : std_logic_vector(17 downto 0)             := (x"0000" & "01") ;
signal p_out_dsp48_20            : std_logic_array48(TX_ANT_NUM-1 downto 0);
signal c_in_dsp48_21             : std_logic_array48(TX_ANT_NUM-1 downto 0);
signal a_in_dsp48_21             : std_logic_array30(TX_ANT_NUM-1 downto 0);
signal d_in_dsp48_21             : std_logic_array27(TX_ANT_NUM-1 downto 0);
signal b_in_dsp48_21             : std_logic_vector(17 downto 0)             := (x"0000" & "01") ;
signal p_out_dsp48_21            : std_logic_array48(TX_ANT_NUM-1 downto 0);

signal s_dbg_pim_sum_i_48b       : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_dbg_pim_sum_q_48b       : std_logic_array48(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_dbg_pim_sum_i_sat       : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
signal s_dbg_pim_sum_q_sat       : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others=> (others=>'0') );
-- ~dbg_sum

------
begin

    process (CLK)
    begin
        if ( RST = '1' ) then
            s_pim_cfr_ref_vld         <= (others=>'0') ;       
            s_pim_cfr_ref_i           <= (others=> (others=>'0') ) ;   -- OPERAND 1 I    
            s_pim_cfr_ref_q           <= (others=> (others=>'0') ) ;   -- OPERAND 1 Q   
            s_pim_interb_src_i        <= (others=> (others=>'0') ) ;   -- OPERAND 2 I   
            s_pim_interb_src_q        <= (others=> (others=>'0') ) ;   -- OPERAND 2 Q

            -- s_intra_band_sel_in       <= '0' ;   
            -- s_inter_type1_sel_in      <= (others=>'0') ;   
            -- s_inter_type2_sel_in      <= (others=>'0') ;  
			s_intra_band_sel_in       <= (others=>'0') ; 
            s_inter_type1_sel_in      <= (others=> (others=>'0') ) ;   
            s_inter_type2_sel_in      <= (others=> (others=>'0') ) ;  

        elsif ( rising_edge(CLK) ) then
            s_pim_cfr_ref_vld         <= PIM_CFR_REF_VLD_IN   ;       
            s_pim_cfr_ref_i           <= PIM_CFR_REF_I_IN     ;   -- OPERAND 1 I    
            s_pim_cfr_ref_q           <= PIM_CFR_REF_Q_IN     ;   -- OPERAND 1 Q   
            s_pim_interb_src_i        <= PIM_INTERB_SRC_I_IN  ;   -- OPERAND 2 I   
            s_pim_interb_src_q        <= PIM_INTERB_SRC_Q_IN  ;   -- OPERAND 2 Q

            s_intra_band_sel_in       <= INTRA_BAND_SEL_IN        ;   
            s_inter_type1_sel_in <= INTER_BAND_TYPE1_SEL_IN  ;   
            s_inter_type2_sel_in <= INTER_BAND_TYPE2_SEL_IN  ;   

            s_pim_intra_band_vld_out  <= s_pim_cfr_ref_vld;

        end if;
    end process;


G_ANT_IM3_GEN : for I in 0 to TX_ANT_NUM-1 generate begin   

    U_DLY_I_01 : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 7) port map (CLK, s_pim_interb_src_i(I), s_pim_interb_src_i_dly(I));
    U_DLY_Q_01 : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 7) port map (CLK, s_pim_interb_src_q(I), s_pim_interb_src_q_dly(I));
    U_DLY_I_02 : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 7) port map (CLK, s_pim_cfr_ref_i(I), s_pim_cfr_ref_i_dly(I));
    U_DLY_Q_02 : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 7) port map (CLK, s_pim_cfr_ref_q(I), s_pim_cfr_ref_q_dly(I));

    ------- Conjugated Multiplication -- 7 clk
    s_pim_cfr_ref_i_neg(I)  <= ( (not s_pim_cfr_ref_i(I)) + '1')  ;
    a_in_dsp48_01(I)        <= sign_extension(s_pim_cfr_ref_i_neg(I), 30)     ;     -- Substract   
    d_in_dsp48_01(I)        <= sign_extension(s_pim_cfr_ref_q(I)    , 27)     ;
    b_in_dsp48_01(I)        <= sign_extension(s_pim_interb_src_q(I) , 18)     ;       

    a_in_dsp48_02(I)        <= sign_extension(s_pim_interb_src_i(I) , 30)     ;       
    d_in_dsp48_02(I)        <= sign_extension(s_pim_interb_src_q(I) , 27)     ;       
    b_in_dsp48_02(I)        <= sign_extension(s_pim_cfr_ref_i(I)    , 18)     ;       

    a_in_dsp48_03(I)        <= sign_extension(s_pim_cfr_ref_i(I)    , 30)     ;       
    d_in_dsp48_03(I)        <= sign_extension(s_pim_cfr_ref_q(I)    , 27)     ;       
    b_in_dsp48_03(I)        <= sign_extension(s_pim_interb_src_i(I) , 18)     ;       

    U_MULT_A_01 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),a_in_dsp48_01(I),d_in_dsp48_01(I),b_in_dsp48_01(I),(others=>'0'),open,p_cout_dsp48_01(I),open);             
    U_MULT_B_01 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),a_in_dsp48_02(I),d_in_dsp48_02(I),b_in_dsp48_02(I),(others=>'0'),open,p_cout_dsp48_02(I),open);             
    U_MULT_C_01 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),a_in_dsp48_03(I),d_in_dsp48_03(I),b_in_dsp48_03(I),(others=>'0'),open,p_cout_dsp48_03(I),open);

    process (CLK)
    begin
        if ( rising_edge(CLK) ) then
            s_i_01_34b(I)  <= ( p_cout_dsp48_01(I)(32) & p_cout_dsp48_01(I)(32 downto 0) ) + ( p_cout_dsp48_02(I)(32) & p_cout_dsp48_02(I)(32 downto 0) );    
            s_q_01_34b(I)  <= ( p_cout_dsp48_02(I)(32) & p_cout_dsp48_02(I)(32 downto 0) ) - ( p_cout_dsp48_03(I)(32) & p_cout_dsp48_03(I)(32 downto 0) );    
            
        end if;
    end process;

    s_i_01_29b(I)   <= s_i_01_34b(I)(33 downto 5);
    s_q_01_29b(I)   <= s_q_01_34b(I)(33 downto 5);

    U_SAT_I_01 : SAT_SIGN generic map(HS_MODE, 29, 27) port map(RST, CLK, s_i_01_29b(I), res_i_01_27b(I) );
    U_SAT_Q_01 : SAT_SIGN generic map(HS_MODE, 29, 27) port map(RST, CLK, s_q_01_29b(I), res_q_01_27b(I) );
    ------ ~Conjugated Multiplication

    ------ Normal and Conjugated multiplication A -- 7clk
    d_in_dsp48_04(I)  <= res_i_01_27b(I)  ;
    b_in_dsp48_04(I)  <= sign_extension( s_pim_interb_src_i_dly(I), 18 ) ;
    
    d_in_dsp48_05(I)  <= res_q_01_27b(I)  ;
    b_in_dsp48_05(I)  <= sign_extension( s_pim_interb_src_i_dly(I), 18 ) ;
    
    d_in_dsp48_06(I)  <= res_q_01_27b(I)  ;
    b_in_dsp48_06(I)  <= sign_extension( s_pim_interb_src_q_dly(I), 18 ) ;
    
    d_in_dsp48_07(I)  <= res_i_01_27b(I)  ;
    b_in_dsp48_07(I)  <= sign_extension( s_pim_interb_src_q_dly(I), 18 ) ;

    U_MULT_A_02 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),d_in_dsp48_04(I),b_in_dsp48_04(I),(others=>'0'),open,p_cout_dsp48_04(I),open);  -- A           
    U_MULT_B_02 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),d_in_dsp48_05(I),b_in_dsp48_05(I),(others=>'0'),open,p_cout_dsp48_05(I),open);  -- B           
    U_MULT_C_02 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),d_in_dsp48_06(I),b_in_dsp48_06(I),(others=>'0'),open,p_cout_dsp48_06(I),open);  -- C           
    U_MULT_D_02 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),d_in_dsp48_07(I),b_in_dsp48_07(I),(others=>'0'),open,p_cout_dsp48_07(I),open);  -- D

    process (CLK)
    begin
        if ( rising_edge(CLK) ) then
            s_i_02_44b(I)   <= p_cout_dsp48_04(I)(43 downto 0) - p_cout_dsp48_06(I)(43 downto 0);
            s_q_02_44b(I)   <= p_cout_dsp48_07(I)(43 downto 0) + p_cout_dsp48_05(I)(43 downto 0);
            s_i_03_44b(I)   <= p_cout_dsp48_04(I)(43 downto 0) + p_cout_dsp48_06(I)(43 downto 0);
            s_q_03_44b(I)   <= p_cout_dsp48_07(I)(43 downto 0) - p_cout_dsp48_05(I)(43 downto 0);

        end if;
    end process;
    
    s_i_04_19b(I)   <= s_i_02_44b(I)(43 downto 25) + s_i_02_44b(I)(24) ;           
    s_q_04_19b(I)   <= s_q_02_44b(I)(43 downto 25) + s_q_02_44b(I)(24) ;              
    s_i_05_19b(I)   <= s_i_03_44b(I)(43 downto 25) + s_i_03_44b(I)(24) ;              
    s_q_05_19b(I)   <= s_q_03_44b(I)(43 downto 25) + s_q_03_44b(I)(24) ;    
    s_i_04_20b(I)   <= ( s_i_04_19b(I)(18) & s_i_04_19b(I) ); 
    s_q_04_20b(I)   <= ( s_q_04_19b(I)(18) & s_q_04_19b(I) ); 
    s_i_05_20b(I)   <= ( s_i_05_19b(I)(18) & s_i_05_19b(I) ); 
    s_q_05_20b(I)   <= ( s_q_05_19b(I)(18) & s_q_05_19b(I) ); 

    U_SAT_I_02 : SAT_SIGN generic map(HS_MODE, 20, 16) port map(RST, CLK, s_i_04_20b(I), x1_x1_x2c_i_16b(I) );
    U_SAT_Q_02 : SAT_SIGN generic map(HS_MODE, 20, 16) port map(RST, CLK, s_q_04_20b(I), x1_x1_x2c_q_16b(I) );
    U_SAT_I_03 : SAT_SIGN generic map(HS_MODE, 20, 16) port map(RST, CLK, s_i_05_20b(I), x1_x2_x1c_i_16b(I) );
    U_SAT_Q_03 : SAT_SIGN generic map(HS_MODE, 20, 16) port map(RST, CLK, s_q_05_20b(I), x1_x2_x1c_q_16b(I) );
    ------ ~Normal and Conjugated multiplication A    

    ------ Normal and Conjugated multiplication B -- 7 clk
    d_in_dsp48_08(I)  <= res_i_01_27b(I)  ;
    b_in_dsp48_08(I)  <= sign_extension(s_pim_cfr_ref_i_dly(I), 18) ;
    
    d_in_dsp48_09(I)  <= res_q_01_27b(I)  ;
    b_in_dsp48_09(I)  <= sign_extension(s_pim_cfr_ref_i_dly(I), 18) ;
    
    d_in_dsp48_10(I)  <= res_q_01_27b(I)  ;
    b_in_dsp48_10(I)  <= sign_extension(s_pim_cfr_ref_q_dly(I), 18) ;
    
    d_in_dsp48_11(I)  <= res_i_01_27b(I)  ;
    b_in_dsp48_11(I)  <= sign_extension(s_pim_cfr_ref_q_dly(I), 18) ;

    U_MULT_A_04 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),d_in_dsp48_08(I),b_in_dsp48_08(I),(others=>'0'),open,p_cout_dsp48_08(I),open);  -- A           
    U_MULT_B_04 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),d_in_dsp48_09(I),b_in_dsp48_09(I),(others=>'0'),open,p_cout_dsp48_09(I),open);  -- B           
    U_MULT_C_05 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),d_in_dsp48_10(I),b_in_dsp48_10(I),(others=>'0'),open,p_cout_dsp48_10(I),open);  -- C           
    U_MULT_D_05 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),d_in_dsp48_11(I),b_in_dsp48_11(I),(others=>'0'),open,p_cout_dsp48_11(I),open);  -- D

    process (CLK)
    begin
        if ( rising_edge(CLK) ) then
            s_i_06_44b(I)   <= p_cout_dsp48_08(I)(43 downto 0) - p_cout_dsp48_10(I)(43 downto 0);
            s_q_06_44b(I)   <= p_cout_dsp48_11(I)(43 downto 0) + p_cout_dsp48_09(I)(43 downto 0);
            s_i_07_44b(I)   <= p_cout_dsp48_08(I)(43 downto 0) + p_cout_dsp48_10(I)(43 downto 0);
            s_q_07_44b(I)   <= p_cout_dsp48_11(I)(43 downto 0) - p_cout_dsp48_09(I)(43 downto 0);
            
        end if;
    end process;

    s_i_08_19b(I)   <= s_i_06_44b(I)(43 downto 25) + s_i_06_44b(I)(24) ;           
    s_q_08_19b(I)   <= s_q_06_44b(I)(43 downto 25) + s_q_06_44b(I)(24) ;              
    s_i_09_19b(I)   <= s_i_07_44b(I)(43 downto 25) + s_i_07_44b(I)(24) ;              
    s_q_09_19b(I)   <= s_q_07_44b(I)(43 downto 25) + s_q_07_44b(I)(24) ;    
    s_i_08_20b(I)   <= ( s_i_08_19b(I)(18) & s_i_08_19b(I) ); 
    s_q_08_20b(I)   <= ( s_q_08_19b(I)(18) & s_q_08_19b(I) ); 
    s_i_09_20b(I)   <= ( s_i_09_19b(I)(18) & s_i_09_19b(I) ); 
    s_q_09_20b(I)   <= ( s_q_09_19b(I)(18) & s_q_09_19b(I) ); 

    U_SAT_I_04 : SAT_SIGN generic map(HS_MODE, 20, 16) port map(RST, CLK, s_i_08_20b(I), x2_x1_x2c_i_16b(I) );
    U_SAT_Q_04 : SAT_SIGN generic map(HS_MODE, 20, 16) port map(RST, CLK, s_q_08_20b(I), x2_x1_x2c_q_16b(I) );
    U_SAT_I_05 : SAT_SIGN generic map(HS_MODE, 20, 16) port map(RST, CLK, s_i_09_20b(I), x2_x2_x1c_i_16b(I) );
    U_SAT_Q_05 : SAT_SIGN generic map(HS_MODE, 20, 16) port map(RST, CLK, s_q_09_20b(I), x2_x2_x1c_q_16b(I) );
    ------ ~Normal and Conjugated multiplication B    

    ------ Complex Norm -- 7 clk
    d_in_dsp48_12(I)     <= sign_extension(s_pim_cfr_ref_i(I), 27);  
    b_in_dsp48_12(I)     <= sign_extension(s_pim_cfr_ref_i(I), 18);

    s_11_28bit(I)        <= p_out_dsp48_13(I)(32 downto 5);
    -- x2_x2c_i_27b(I)      <= p_out_dsp48_13(I)(31 downto 5); -- positive value sasturation
    U_SAT_I_07 : SAT_SIGN generic map(HS_MODE, 28, 27) port map(RST, CLK, s_11_28bit(I), x2_x2c_i_27b(I) );

    process (CLK) 
    begin
        if ( rising_edge(CLK) ) then
            d_in_dsp48_13(I)     <= sign_extension(s_pim_cfr_ref_q(I), 27);
            b_in_dsp48_13(I)     <= sign_extension(s_pim_cfr_ref_q(I), 18);
    
        end if;
    end process;

    U_MULT_A_06 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,TRUE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),d_in_dsp48_12(I),b_in_dsp48_12(I),(others=>'0'),     p_cout_dsp48_12(I),open,open);  -- A           
    U_MULT_B_06 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",TRUE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),d_in_dsp48_13(I),b_in_dsp48_13(I),p_cout_dsp48_12(I),open,p_out_dsp48_13(I),open);  -- B           
    ------ ~Complex Norm

    ------ Real Multiplication A, B  -- 6 clk
    d_in_dsp48_14(I)          <= x2_x2c_i_27b(I);  
    b_in_dsp48_14(I)          <= sign_extension(s_pim_cfr_ref_i_dly(I), 18);
    d_in_dsp48_15(I)          <= x2_x2c_i_27b(I);  
    b_in_dsp48_15(I)          <= sign_extension(s_pim_cfr_ref_q_dly(I), 18);

    U_MULT_A_07 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),d_in_dsp48_14(I),b_in_dsp48_14(I),(others=>'0'),open,p_cout_dsp48_14(I),open);  -- A           
    U_MULT_B_07 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),d_in_dsp48_15(I),b_in_dsp48_15(I),(others=>'0'),open,p_cout_dsp48_15(I),open);  -- A           
    process (CLK)
    begin
        if ( rising_edge(CLK) ) then
            s_i_10_18b(I)   <=  p_cout_dsp48_14(I)(42 downto 25) + p_cout_dsp48_14(I)(24) ;           
            s_q_10_18b(I)   <=  p_cout_dsp48_15(I)(42 downto 25) + p_cout_dsp48_15(I)(24) ;           

        end if;
    end process;

    s_i_10_19b(I)  <= ( s_i_10_18b(I)(17) & s_i_10_18b(I) );  
    s_q_10_19b(I)  <= ( s_q_10_18b(I)(17) & s_q_10_18b(I) );  

    U_SAT_I_06 : SAT_SIGN generic map(HS_MODE, 19, 16) port map(RST, CLK, s_i_10_19b(I), x2_x2_x2c_i_16b(I) );
    U_SAT_Q_06 : SAT_SIGN generic map(HS_MODE, 19, 16) port map(RST, CLK, s_q_10_19b(I), x2_x2_x2c_q_16b(I) );
    ------ ~Real Multiplication A, B

    ------ Muxing by Select
    process (CLK) 
    begin
        if ( rising_edge(CLK) ) then
            if ( s_intra_band_sel_in(I) = '1' ) then
                s_pim_intra_band_i_out(I)   <= x2_x2_x2c_i_16b(I);
                s_pim_intra_band_q_out(I)   <= x2_x2_x2c_q_16b(I);
            else
                s_pim_intra_band_i_out(I)   <= (others=>'0') ;
                s_pim_intra_band_q_out(I)   <= (others=>'0') ;
            end if;

            if ( s_inter_type1_sel_in(I) = "10" ) then
                s_pim_inter_type1_i_out(I)  <= x1_x1_x2c_i_16b(I);
                s_pim_inter_type1_q_out(I)  <= x1_x1_x2c_q_16b(I);
            elsif ( s_inter_type1_sel_in(I) = "01" ) then
                s_pim_inter_type1_i_out(I)  <= x2_x2_x1c_i_16b(I);
                s_pim_inter_type1_q_out(I)  <= x2_x2_x1c_q_16b(I);
            else
                s_pim_inter_type1_i_out(I)  <= (others=>'0') ;
                s_pim_inter_type1_q_out(I)  <= (others=>'0') ;
            end if;
            
            if ( s_inter_type2_sel_in(I) = "10" ) then
                s_pim_inter_type2_i_out(I)  <= x1_x2_x1c_i_16b(I);
                s_pim_inter_type2_q_out(I)  <= x1_x2_x1c_q_16b(I);
            elsif ( s_inter_type2_sel_in(I) = "01" ) then
                s_pim_inter_type2_i_out(I)  <= x2_x1_x2c_i_16b(I);
                s_pim_inter_type2_q_out(I)  <= x2_x1_x2c_q_16b(I);
            else
                s_pim_inter_type2_i_out(I)  <= (others=>'0') ;
                s_pim_inter_type2_q_out(I)  <= (others=>'0') ;
            end if;
            
            PIM_INTRA_BAND_VLD_OUT(I)  <= s_pim_intra_band_vld_out(I);

            PIM_INTRA_BAND_I_OUT(I)    <= s_pim_intra_band_i_out(I)  ;      
            PIM_INTRA_BAND_Q_OUT(I)    <= s_pim_intra_band_q_out(I)  ;      
                                                                    
            PIM_INTER_TYPE1_I_OUT(I)   <= s_pim_inter_type1_i_out(I) ;      
            PIM_INTER_TYPE1_Q_OUT(I)   <= s_pim_inter_type1_q_out(I) ;      
                                                                    
            PIM_INTER_TYPE2_I_OUT(I)   <= s_pim_inter_type2_i_out(I) ;      
            PIM_INTER_TYPE2_Q_OUT(I)   <= s_pim_inter_type2_q_out(I) ;      

            s_pim_intra_band_i_out_d(I)     <= s_pim_intra_band_i_out(I)  ;      
            s_pim_intra_band_q_out_d(I)     <= s_pim_intra_band_q_out(I)  ;      
            s_pim_intra_band_i_out_d2(I)    <= s_pim_intra_band_i_out_d(I)  ;      
            s_pim_intra_band_q_out_d2(I)    <= s_pim_intra_band_q_out_d(I)  ;      

            -- DBG_PIM_SUM_I_OUT(I)            <= s_dbg_pim_sum_i_sat(I);
            -- DBG_PIM_SUM_Q_OUT(I)            <= s_dbg_pim_sum_q_sat(I);
            DBG_PIM_SUM_I_OUT(I)            <= (others=>'0');
            DBG_PIM_SUM_Q_OUT(I)            <= (others=>'0');

        end if;
    end process;

    -- c_in_dsp48_20(I)   <= sign_extension(s_pim_intra_band_i_out_d2(I) , 48) ;
    -- c_in_dsp48_21(I)   <= sign_extension(s_pim_intra_band_q_out_d2(I) , 48) ;
    -- a_in_dsp48_20(I)   <= sign_extension(s_pim_inter_type1_i_out(I) , 30)  ;
    -- a_in_dsp48_21(I)   <= sign_extension(s_pim_inter_type1_q_out(I) , 30)  ;
    -- d_in_dsp48_20(I)   <= sign_extension(s_pim_inter_type2_i_out(I) , 27)  ;
    -- d_in_dsp48_21(I)   <= sign_extension(s_pim_inter_type2_q_out(I) , 27)  ;


    -- U_SUM_A_08 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,TRUE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),c_in_dsp48_20(I),a_in_dsp48_20(I),d_in_dsp48_20(I),b_in_dsp48_20,(others=>'0'),open,s_dbg_pim_sum_i_48b(I),open);  --            
    -- U_SUM_B_08 : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,TRUE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),c_in_dsp48_21(I),a_in_dsp48_21(I),d_in_dsp48_21(I),b_in_dsp48_21,(others=>'0'),open,s_dbg_pim_sum_q_48b(I),open);  --  

    -- U_SAT_I_08 : SAT_SIGN generic map(HS_MODE, 48, 16) port map(RST, CLK, s_dbg_pim_sum_i_48b(I), s_dbg_pim_sum_i_sat(I) );
    -- U_SAT_Q_08 : SAT_SIGN generic map(HS_MODE, 48, 16) port map(RST, CLK, s_dbg_pim_sum_q_48b(I), s_dbg_pim_sum_q_sat(I) );

    ------ ~Muxing by Select

end generate;

-- component DSP48E_MULT is
-- generic(
--     DEVICE                      : string  := "ULTRASCALE";
--     DSP48_MODECTRL              : boolean :=       FALSE ;
--     DSP48_PREADDER_USE          : boolean :=        TRUE ;
--     DSP48_PREADDER_MODE         : string  :=        "ADD"; -- "ADD" or "SUB" 
--     DSP48_PCIN_USE              : boolean :=       FALSE ;
--     DSP48_PCOUT_USE             : boolean :=       FALSE ;
-- 
--     A_nREG                      : integer :=           2 ; -- 0, 1, 2
--     B_nREG                      : integer :=           2 ; -- 0, 1, 2
-- 
--     C_EN                        : boolean :=        TRUE ; -- RND ENable
--     RND_SYMMETRY                : boolean :=       FALSE 
--     );
-- port(
--     CLK                         : in  std_logic;
-- 
--     ALUMODE_IN                  : in  std_logic_vector( 3 downto 0);
--     OPMODE_IN                   : in  std_logic_vector( 8 downto 0);
-- 
--     C_IN                        : in  std_logic_vector(47 downto 0); -- RND Value
--     A_IN                        : in  std_logic_vector(29 downto 0);
--     D_IN                        : in  std_logic_vector(26 downto 0);
--     B_IN                        : in  std_logic_vector(17 downto 0);
-- 
--     P_CIN                       : in  std_logic_vector(47 downto 0);
--     P_COUT                      : out std_logic_vector(47 downto 0);
-- 
--     P_OUT                       : out std_logic_vector(47 downto 0);
--     CRRY_OUT                    : out std_logic
--     );
-- end component;

end arc_PIMD_IM3_GEN;
