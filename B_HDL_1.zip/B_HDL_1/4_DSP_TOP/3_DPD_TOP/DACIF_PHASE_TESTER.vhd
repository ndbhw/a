-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity DACIF_PHASE_TESTER is
port (
    RST                : in  std_logic;
    CLK                : in  std_logic;

    BFN_STRB_IN        : in  std_logic;
    TDD_IN             : in  std_logic;

    TEST_ENB_IN        : in  std_logic;   -- '1': Phase test enable, '0': disable
    REF_SEL_IN         : in  std_logic;   -- '1': BFN_STRB, '0': TDD 
    PATH_AB_SWAP_IN    : in  std_logic;   -- '1': Swap A/B, '0': normal
    PATH_REVERSE_IN    : in  std_logic;   -- '1': Reverse 0 <-> (TX_ANT_NUM-1), '0': normal
    REPEAT_ENB_IN      : in  std_logic;   -- '1': Repeat enable, '0': repeat disable
    DACIF_DEFAULT_IN   : in  std_logic_vector((TX_ANT_NUM-1) downto 0); -- DACIF default value for phase test

    OFFSET_IN          : in  std_logic_vector(23 downto 0); -- Offset from BFN_STRB/TDD
    PERIOD_IN          : in  std_logic_vector(23 downto 0); -- Period on/off for one path
    ON_DURATION_IN     : in  std_logic_vector(23 downto 0); -- On duration of one period

    DACIF_ON_IN        : in  std_logic_vector((TX_ANT_NUM-1) downto 0);  -- '1' : IQ On , '0' : IQ Off
    DACIF_ON_OUT       : out std_logic_vector((TX_ANT_NUM-1) downto 0)   -- '1' : IQ On , '0' : IQ Off
    );
end DACIF_PHASE_TESTER;

architecture arc_DACIF_PHASE_TESTER of DACIF_PHASE_TESTER is

component RST_SYNC is
generic(
    DLY_NUM             : natural := 3;    -- Number of delay.
    MAX_FANOUT_NUM      : integer := 200   -- Number of maximum fanout
    );
port(
    RST_IN              : in  std_logic;   -- Active high asynchronous reset
    CLK                 : in  std_logic;   -- clock to be sync'ed to
    RST_OUT             : out std_logic    -- "Synchronised" reset signal
    );         
end component;

signal rst_synch        : std_logic;

signal offset_cnt       : std_logic_vector(23 downto 0);
signal prd_cnt          : std_logic_vector(23 downto 0);

signal tdd_d1           : std_logic;
signal tdd_d2           : std_logic;
signal tdd_rising       : std_logic;

signal bfn_strb_d1      : std_logic;
signal bfn_strb_d2      : std_logic;
signal bfn_strb_rising  : std_logic;

signal test_enb_d1      : std_logic;
signal test_enb_d2      : std_logic;
signal ref_sel_d1       : std_logic;
signal ref_sel_d2       : std_logic;
signal repeat_enb_d1    : std_logic;
signal repeat_enb_d2    : std_logic;
signal path_ab_swap_d1  : std_logic;
signal path_ab_swap_d2  : std_logic;
signal path_reverse_d1  : std_logic;
signal path_reverse_d2  : std_logic;

signal start_pulse      : std_logic;
signal start_pulse_high : std_logic;
signal start_pulse_low  : std_logic;

signal high_duration    : std_logic;

signal path_enb         : std_logic_vector((TX_ANT_NUM-1) downto 0);
signal path_enb_d1      : std_logic_vector((TX_ANT_NUM-1) downto 0);
signal path_enb_swap    : std_logic_vector((TX_ANT_NUM-1) downto 0);
signal path_enb_reverse : std_logic_vector((TX_ANT_NUM-1) downto 0);

begin

    U_RST_SYNC : RST_SYNC generic map(4, 200) port map(RST, CLK, rst_synch);

    Double_clock_proc0 : process(rst_synch, CLK) begin
        if (rst_synch = '1') then
            tdd_d1           <= '0';
            tdd_d2           <= '0';
            bfn_strb_d1      <= '0';
            bfn_strb_d2      <= '0';
            test_enb_d1      <= '0';
            test_enb_d2      <= '0';
            ref_sel_d1       <= '0';
            ref_sel_d2       <= '0';
            repeat_enb_d1    <= '0';
            repeat_enb_d2    <= '0';
            path_ab_swap_d1  <= '0';
            path_ab_swap_d2  <= '0';
            path_reverse_d1  <= '0';
            path_reverse_d2  <= '0';
        elsif (CLK'event) and (CLK = '1') then
            tdd_d1           <= TDD_IN;
            tdd_d2           <= tdd_d1;
            bfn_strb_d1      <= BFN_STRB_IN;
            bfn_strb_d2      <= bfn_strb_d1;
            test_enb_d1      <= TEST_ENB_IN;
            test_enb_d2      <= test_enb_d1;
            ref_sel_d1       <= REF_SEL_IN;
            ref_sel_d2       <= ref_sel_d1;
            repeat_enb_d1    <= REPEAT_ENB_IN;
            repeat_enb_d2    <= repeat_enb_d1;
            path_ab_swap_d1  <= PATH_AB_SWAP_IN;
            path_ab_swap_d2  <= path_ab_swap_d1;
            path_reverse_d1  <= PATH_REVERSE_IN;
            path_reverse_d2  <= path_reverse_d1;
        end if;
    end process;

    tdd_rising       <= (not tdd_d2) and tdd_d1;
    bfn_strb_rising  <= (not bfn_strb_d2) and bfn_strb_d1;
        
    offset_cnt_gen0: process(rst_synch, CLK) begin
        if (rst_synch = '1') then
            offset_cnt <= (others => '1');
        elsif (CLK'event) and (CLK = '1') then
            if (ref_sel_d2 = '1') then -- offset from bfn_strb
                if (bfn_strb_rising = '1') then
                    offset_cnt <= (others => '0');
                else
                    offset_cnt <= offset_cnt + '1';
                end if;
            else -- offset from tdd
                if (tdd_rising = '1') then
                    offset_cnt <= (others => '0');
                else
                    offset_cnt <= offset_cnt + '1';
                end if;
            end if;
        end if;
    end process;
        
    start_pulse_gen0: process(rst_synch, CLK) begin
        if (rst_synch = '1') then
            start_pulse_high <= '0';
            start_pulse_low  <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (offset_cnt(23 downto 12) = OFFSET_IN(23 downto 12)) then -- high detect
                start_pulse_high <= '1';
            else
                start_pulse_high <= '0';
            end if;
            if (offset_cnt(11 downto 0) = OFFSET_IN(11 downto 0)) then -- low detect
                start_pulse_low <= '1';
            else
                start_pulse_low <= '0';
            end if;
        end if;
    end process;

    start_pulse <= start_pulse_high and start_pulse_low;
        
    period_cnt_gen0: process(rst_synch, CLK) begin
        if (rst_synch = '1') then
            prd_cnt      <= (others => '1');
        elsif (CLK'event) and (CLK = '1') then
            if (start_pulse = '1') then
                prd_cnt      <= (others => '0');
            elsif (prd_cnt = (PERIOD_IN-1)) then
                prd_cnt      <= (others => '0');
            else
                prd_cnt      <= prd_cnt + '1';
            end if;
        end if;
    end process;
        
    path_enb_gen0: process(rst_synch, CLK) begin
        if (rst_synch = '1') then
            path_enb      <= (others => '0');
            path_enb_d1   <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (start_pulse = '1') then
                path_enb      <= DACIF_DEFAULT_IN; --"00000001";
            elsif (prd_cnt = (PERIOD_IN-1)) then
                if (repeat_enb_d2 = '1') then -- repeat enable
                    path_enb      <= path_enb((TX_ANT_NUM-2) downto 0) & path_enb(TX_ANT_NUM-1);
                else
                    path_enb      <= path_enb((TX_ANT_NUM-2) downto 0) & '0';
                end if;
            end if;
            path_enb_d1   <= path_enb;
        end if;
    end process;
        
    on_duration_gen0: process(rst_synch, CLK) begin
        if (rst_synch = '1') then
            high_duration <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (prd_cnt < ON_DURATION_IN) then
                high_duration <= '1';
            else
                high_duration <= '0';
            end if;
        end if;
    end process;
        
    path_swap_gen_ary0: for i in 0 to (TX_ANT_NUM/2-1) generate   
        path_enb_swap_gen0: process(rst_synch, CLK) begin
            if (rst_synch = '1') then
                path_enb_swap(i*2)   <= '0';
                path_enb_swap(i*2+1) <= '0';
            elsif (CLK'event) and (CLK = '1') then
                if (path_ab_swap_d2 = '1') then -- swap even & odd path
                    path_enb_swap(i*2)   <= path_enb_d1(i*2+1) and high_duration;
                    path_enb_swap(i*2+1) <= path_enb_d1(i*2) and high_duration;
                else
                    path_enb_swap(i*2)   <= path_enb_d1(i*2) and high_duration;
                    path_enb_swap(i*2+1) <= path_enb_d1(i*2+1) and high_duration;
                end if;
            end if;
        end process;
    end generate path_swap_gen_ary0;

    path_reverse_gen_ary0: for i in 0 to (TX_ANT_NUM-1) generate   
        path_reverse_gen0: process(rst_synch, CLK) begin
            if (rst_synch = '1') then
                path_enb_reverse(i) <= '0';
            elsif (CLK'event) and (CLK = '1') then
                if (path_reverse_d2 = '1') then -- reverse all the path
                    path_enb_reverse(i) <= path_enb_swap((TX_ANT_NUM-1)-i);
                else
                    path_enb_reverse(i) <= path_enb_swap(i);
                end if;
            end if;
        end process;
    end generate path_reverse_gen_ary0;
            
    dacif_ctrl_gen_ary0: for i in 0 to (TX_ANT_NUM-1) generate   
    dacif_ctrl_gen0: process(rst_synch, CLK) begin
        if (rst_synch = '1') then
            DACIF_ON_OUT(i) <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (test_enb_d2 = '1') then -- phase test enable
                DACIF_ON_OUT(i) <= path_enb_reverse(i) and DACIF_ON_IN(i);
            else
                DACIF_ON_OUT(i) <= DACIF_ON_IN(i);
            end if;
        end if;
    end process;
    end generate dacif_ctrl_gen_ary0;
        

end arc_DACIF_PHASE_TESTER;
