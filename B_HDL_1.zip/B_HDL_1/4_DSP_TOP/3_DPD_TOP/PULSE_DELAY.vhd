-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name : PULSE_DELAY 
-- Structure  : 

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity PULSE_DELAY is
generic(
    CLK_CNTDLY      : integer        -- 0 ~ 8191 clock
    );
port(
    RST             : in  std_logic; -- Active high reset
    CLK             : in  std_logic; -- Clock
    
    BYPASS_IN       : in  std_logic; -- '0' normal mode, '1' bypass mode
    
    PULSE_IN        : in  std_logic;

    PULSE_DELAY_OUT : out std_logic
    );
end PULSE_DELAY;

architecture arc_PULSE_DELAY of PULSE_DELAY is

component CNTDLY is
generic(
    CLK_CNTDLY : integer  -- 0 ~ 8191
    );
port(
    RST        : in  std_logic;
    CLK        : in  std_logic;
    
    SIGNAL_IN  : in  std_logic;
    
    SIGNAL_OUT : out std_logic
    );
end component;

component SRL_DLY is
generic(
    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK       : in  std_logic;
    
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_COUT : out std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end component;

signal pls_srl  : std_logic_array1(6 downto 0);

signal pls_dly  : std_logic;

begin

    pls_srl(0)(0) <= PULSE_IN; 

    G_SRL16E_Delay : if (CLK_CNTDLY < 161) generate begin

        G_REMAIN_0 : if (CLK_CNTDLY mod 32) = 0 generate begin
            G_QUOTIENT_0 : if (CLK_CNTDLY/32 = 0) generate begin
                pls_srl(6) <= pls_srl(0) ; 
            end generate;

            G_QUOTIENT_1 : if (CLK_CNTDLY/32 = 1) generate begin
                U_PULSE_SRLDLY_1 : SRL_DLY generic map(1, 31) port map(CLK, pls_srl(0), open, pls_srl(6));
            end generate;

            G_QUOTIENT_N : if (CLK_CNTDLY/32 > 1) generate begin
                 G_STAGE : for I in 0 to ((CLK_CNTDLY/32)-1) generate begin
                     G_STAGE_NORMAL : if (I < (CLK_CNTDLY/32)-1) generate begin
                        U_PULSE_SRLDLY_STG : SRL_DLY generic map(1, 32) port map(CLK, pls_srl(I), pls_srl(I+1), open);
                     end generate;

                     G_STAGE_FILNAL : if (I = (CLK_CNTDLY/32)-1) generate begin
                        U_PULSE_SRL_DLY_FIN : SRL_DLY generic map(1, 31) port map(CLK, pls_srl(I), open, pls_srl(6));
                     end generate;

                 end generate;
             end generate;
        end generate;

        G_REMAIN_R : if (CLK_CNTDLY mod 32) > 0 generate begin
            G_QUOTIENT_0 : if (CLK_CNTDLY/32 = 0) generate begin
                U_PULSE_SRLDLY_0 : SRL_DLY generic map(1, (CLK_CNTDLY mod 32)-1) port map(CLK, pls_srl(0), open, pls_srl(6));
            end generate;

            G_QUOTIENT_N : if (CLK_CNTDLY/32 > 0) generate begin
                 G_STAGE : for I in 0 to ((CLK_CNTDLY/32)-1) generate begin
                     U_PULSE_SRLDLY_STG : SRL_DLY generic map(1, 32) port map(CLK, pls_srl(I), pls_srl(I+1), open);
                 end generate;

                 U_PULSE_DLY_FIN : SRL_DLY generic map(1, (CLK_CNTDLY mod 32)-1) port map(CLK, pls_srl(CLK_CNTDLY/32), open, pls_srl(6));

             end generate;
        end generate;

        pls_dly <= pls_srl(6)(0);
    end generate;

    G_CLKCNT_Delay : if (CLK_CNTDLY > 160) generate begin
        U_PULSE_CNT_DLY : CNTDLY generic map(CLK_CNTDLY-1) port map(RST, CLK, PULSE_IN, pls_dly);
    end generate;

    P_Bypass : process(RST, CLK) begin
        if (RST = '1') then
            PULSE_DELAY_OUT <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (BYPASS_IN = '1') then                -- Bypass mode
                PULSE_DELAY_OUT <= PULSE_IN;
            else
                PULSE_DELAY_OUT <= pls_dly;
            end if;
        end if;
    end process;

end arc_PULSE_DELAY;


