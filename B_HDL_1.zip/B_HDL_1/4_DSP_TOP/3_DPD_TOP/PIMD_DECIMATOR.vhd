library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity PIMD_DECIMATOR is
generic(
    DNSAMP_RATIO  : natural := 3;
    PATH_NUM      : natural := 4
    );
port(
    RST_H         : in  std_logic;
    CLK_H         : in  std_logic;

    DATAH_I_IN    : in  std_logic_array16(PATH_NUM-1 downto 0);
    DATAH_Q_IN    : in  std_logic_array16(PATH_NUM-1 downto 0);

    RST_L         : in  std_logic;
    CLK_L         : in  std_logic;

    PIMD_ON_IN    : in  std_logic_vector( PATH_NUM-1 downto 0);

    DATAL_VLD_IN  : in  std_logic_vector( PATH_NUM-1 downto 0);
    DATAL_I_IN    : in  std_logic_array16(PATH_NUM-1 downto 0);
    DATAL_Q_IN    : in  std_logic_array16(PATH_NUM-1 downto 0);

    DATAL_VLD_OUT : out std_logic_vector( PATH_NUM-1 downto 0);
    DATAL_I_OUT   : out std_logic_array16(PATH_NUM-1 downto 0);
    DATAL_Q_OUT   : out std_logic_array16(PATH_NUM-1 downto 0)
    );
end PIMD_DECIMATOR;

architecture arc_PIMD_DECIMATOR of PIMD_DECIMATOR is

constant zeros        : std_logic_vector(log2(DNSAMP_RATIO) downto 0) := (others => '0');

signal clkh_div_cnt   : std_logic_vector(log2(DNSAMP_RATIO) downto 0);

signal decimation_i   : std_logic_array16(PATH_NUM-1 downto 0);
signal decimation_q   : std_logic_array16(PATH_NUM-1 downto 0);

signal data_out_vld   : std_logic_vector( PATH_NUM-1 downto 0);
signal data_out_i     : std_logic_array16(PATH_NUM-1 downto 0);
signal data_out_q     : std_logic_array16(PATH_NUM-1 downto 0);

begin

    -- High SamplingRate Domain
    P_High_Clock_Divide_Count : process(RST_H, CLK_H) begin
        if (RST_H = '1') then
            clkh_div_cnt <= (others => '0');
        elsif (CLK_H'event) and (CLK_H = '1') then
            if (clkh_div_cnt = DNSAMP_RATIO-1) then 
                clkh_div_cnt <= (others => '0');
            else
                clkh_div_cnt <= clkh_div_cnt + '1';
            end if;
        end if;
    end process;

    P_Decimation : process(RST_H, CLK_H) begin
        if (RST_H = '1') then
            decimation_i <= (others => (others => '0'));
            decimation_q <= (others => (others => '0'));
        elsif (CLK_H'event) and (CLK_H  = '1') then
            if (clkh_div_cnt = zeros) then 
                decimation_i <= DATAH_I_IN;
                decimation_q <= DATAH_Q_IN;
            else
                decimation_i <= decimation_i;
                decimation_q <= decimation_q;
            end if;
        end if;
    end process;

    -- Low SamplingRate Domain
    P_Output_Clock_Align : process(RST_L, CLK_L) begin
        if (RST_L = '1') then
            data_out_vld <= (others => '0');            
            data_out_i   <= (others => (others => '0'));
            data_out_q   <= (others => (others => '0'));
        elsif (CLK_L'event) and (CLK_L = '1') then
            data_out_vld <= DATAL_VLD_IN;            

            for I in 0 to (PATH_NUM-1) loop
                if (DATAL_VLD_IN(I) = '1') then
                    if (PIMD_ON_IN(I) = '0') then
                        data_out_i(I) <= DATAL_I_IN(I);
                        data_out_q(I) <= DATAL_Q_IN(I);
                    else
                        data_out_i(I) <= decimation_i(I);
                        data_out_q(I) <= decimation_q(I);
                    end if;
                else
                    data_out_i(I) <= data_out_i(I);
                    data_out_q(I) <= data_out_q(I);
                end if;
            end loop;
        end if;
    end process;

    DATAL_VLD_OUT <= data_out_vld ; 
    DATAL_I_OUT   <= data_out_i;   
    DATAL_Q_OUT   <= data_out_q;    

end arc_PIMD_DECIMATOR;

    
