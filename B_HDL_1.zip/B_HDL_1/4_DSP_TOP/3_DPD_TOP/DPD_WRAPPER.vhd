library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity DPD_WRAPPER is
port(
    -- CPU Interface       
    DPD_RST_CPUIF                             : in  std_logic;                                 -- CPUIF Reset, '1': Reset
    DPD_CLK_CPUIF                             : in  std_logic;                                 -- CPUIF Clock, Faster than iclk/oclk
      
    DPD0_ADDR_CPUIF_IN                        : in  std_logic_vector(ADDR_WIDTH-1  downto 0);  -- CPUIF Address Input, Word Address
    DPD0_WDATA_CPUIF_IN                       : in  std_logic_vector(WDATA_WIDTH-1 downto 0);  -- CPUIF Data Input
    DPD0_RDATA_CPUIF_OUT                      : out std_logic_vector(RDATA_WIDTH-1 downto 0);  -- CPUIF Data Output
    DPD0_WREN_CPUIF_IN                        : in  std_logic;                                 -- CPUIF Write Enable, '1': Active, Synchronous with iclk
    DPD0_RDEN_CPUIF_IN                        : in  std_logic;                                 -- CPUIF Read  Enable, '1': Active
    DPD0_RDVLD_CPUIF_OUT                      : out std_logic;                                 -- CPUIF Read Valid,   '1': Active, Synchronous with clk_cpu

    DPD1_ADDR_CPUIF_IN                        : in  std_logic_vector(ADDR_WIDTH-1  downto 0);  -- CPUIF Address Input, Word Address
    DPD1_WDATA_CPUIF_IN                       : in  std_logic_vector(WDATA_WIDTH-1 downto 0);  -- CPUIF Data Input
    DPD1_RDATA_CPUIF_OUT                      : out std_logic_vector(RDATA_WIDTH-1 downto 0);  -- CPUIF Data Output
    DPD1_WREN_CPUIF_IN                        : in  std_logic;                                 -- CPUIF Write Enable, '1': Active, Synchronous with iclk
    DPD1_RDEN_CPUIF_IN                        : in  std_logic;                                 -- CPUIF Read  Enable, '1': Active
    DPD1_RDVLD_CPUIF_OUT                      : out std_logic;                                 -- CPUIF Read Valid,   '1': Active, Synchronous with clk_cpu

    -- Reset & Clock                          
    RST_DPD                                   : in  std_logic;                                 -- DPD_TOP Reset, '1': Reset
    RST_PIM                                   : in  std_logic;                                 -- DPD_TOP Reset, '1': Reset
    CLK_SYS                                   : in  std_logic;                                 -- System Clock :  30.72 MHz
    CLK_SYSX2                                 : in  std_logic;                                 --  2x(CLK_SYS) :  61.44 MHz
    CLK_SYSX3                                 : in  std_logic;                                 --  3x(CLK_SYS) :  92.16 MHz
    CLK_SYSX4                                 : in  std_logic;                                 --  4x(CLK_SYS) : 122.88 MHz
    CLK_SYSX5                                 : in  std_logic;                                 --  5x(CLK_SYS) : 153.60 MHz
    CLK_SYSX6                                 : in  std_logic;                                 --  6x(CLK_SYS) : 184.32 MHz
    CLK_SYSX8                                 : in  std_logic;                                 --  8x(CLK_SYS) : 245.76 MHz
    CLK_SYSX10                                : in  std_logic;                                 -- 10x(CLK_SYS) : 307.20 MHz
    CLK_SYSX12                                : in  std_logic;                                 -- 12x(CLK_SYS) : 368.64 MHz
    CLK_SYSX16                                : in  std_logic;                                 -- 16x(CLK_SYS) : 491.52 MHz
    CLK_SYSX20                                : in  std_logic;                                 -- 20x(CLK_SYS) : 614.40 MHz

    -- PLL Lock
    INT_SYSPLL_LOCK_IN                        : in  std_logic;                                 -- Internal System PLL Lock 

    -- DL/FB Latency
    DPD_DL_PROC_DLY_OUT                       : out std_logic_vector(31 downto 0);             -- Downlink Latency Information (Unit : Clock)
    DPD_FB_PROC_DLY_OUT                       : out std_logic_vector(31 downto 0);             -- Feedback Latency Information (Unit : Clock)
    DPD_UL_PROC_DLY_OUT                       : out std_logic_vector(31 downto 0);             -- Uplink   Latency Information (Unit : Clock)
    
    -- TDD/FS Strobe 
    DL_BFN_STRB_IN                            : in  std_logic;                                 -- Downlink 10ms Frame Sync Strobe
    DL_TDD_IN                                 : in  std_logic;                                 -- Downlink TDD Strobe
    DL_SSB_STRB_IN                            : in  std_logic;                                 -- 40ms sync signal for SSB power measurement
    
    DL_BFN_STRB_OUT                           : out std_logic;                                 -- Delayed Downlink 10ms Frame Sync Strobe as DL Path Latency 
    DL_TDD_OUT                                : out std_logic;                                 -- Delayed Downlink TDD Strobe as DL Path Latency 
    DL_SSB_STRB_OUT                           : out std_logic;                                 -- 40ms sync signal for SSB power measurement
    
    FB_BFN_STRB_IN                            : in  std_logic;                                 -- Feedback 10ms Frame Sync Strobe
    FB_TDD_IN                                 : in  std_logic;                                 -- Feedback TDD Strobe
    FB_SSB_STRB_IN                            : in  std_logic;                                 -- 40ms sync signal for SSB power measurement
    
    UL_BFN_STRB_IN                            : in  std_logic;                                 -- Uplink 10ms Frame Sync Strobe
    UL_TDD_IN                                 : in  std_logic;                                 -- Uplink TDD Strobe
    
    UL_BFN_STRB_OUT                           : out std_logic;                                 -- Delayed Uplink 10ms Frame Sync Strobe as UL Path Latency 
    UL_TDD_OUT                                : out std_logic;                                 -- Delayed Uplink TDD Strobe as DL Path Latency 

    DL_BCF_ENB_IN                             : in  std_logic;
    DL_BCF_ENB_OUT                            : out std_logic;

    UL_BCF_ENB_IN                             : in  std_logic;
    UL_BCF_ENB_OUT                            : out std_logic;

    DL_GSM_120MS_IN                           : in  std_logic;   
    DL_TS16_SYNC_IN                           : in  std_logic;
    DL_TS_SYNC_IN                             : in  std_logic; 
    DL_TS_GP_SYNC_IN                          : in  std_logic;
    
    DL_GSM_120MS_OUT                          : out std_logic;
    DL_TS16_SYNC_OUT                          : out std_logic;
    DL_TS_SYNC_OUT                            : out std_logic;
    DL_TS_GP_SYNC_OUT                         : out std_logic;
    
    UL_GSM_120MS_IN                           : in  std_logic;
    UL_TS16_SYNC_IN                           : in  std_logic;
    UL_TS_SYNC_IN                             : in  std_logic;
    UL_TS_GP_SYNC_IN                          : in  std_logic;
                                                    
    UL_GSM_120MS_OUT                          : out std_logic; 
    UL_TS16_SYNC_OUT                          : out std_logic;
    UL_TS_SYNC_OUT                            : out std_logic;
    UL_TS_GP_SYNC_OUT                         : out std_logic;

    -- Traffic IQ
    DL_SYNC_IN                                : in  std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);  -- CFR-HC output IQ sample valid
    DL_I_IN                                   : in  std_logic_array16(TOTAL_TX_ANT_NUM-1 downto 0);  -- CFR-HC output I data
    DL_Q_IN                                   : in  std_logic_array16(TOTAL_TX_ANT_NUM-1 downto 0);  -- CFR-HC output Q data

    DL_INTERBAND_SYNC_IN                      : in  std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);  -- InterBand PIM DUC output IQ sample valid
    DL_INTERBAND_I_IN                         : in  std_logic_array16(TOTAL_TX_ANT_NUM-1 downto 0);  -- InterBand PIM DUC output I data
    DL_INTERBAND_Q_IN                         : in  std_logic_array16(TOTAL_TX_ANT_NUM-1 downto 0);  -- InterBand PIM DUC output Q data

    DL_SYNC_OUT                               : out std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output IQ sample valid
    DL_I_OUT                                  : out std_logic_array16(TOTAL_TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output I data
    DL_Q_OUT                                  : out std_logic_array16(TOTAL_TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output Q data


    FB_SYNC_IN                                : in  std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback Path IQ sample valid
    FB_I_EVEN_IN                              : in  std_logic_array16(FB_PATH_NUM-1 downto 0); -- Feedback Path I data
    FB_Q_EVEN_IN                              : in  std_logic_array16(FB_PATH_NUM-1 downto 0); -- Feedback Path Q data
    FB_I_ODD_IN                               : in  std_logic_array16(FB_PATH_NUM-1 downto 0); -- Feedback Path I data
    FB_Q_ODD_IN                               : in  std_logic_array16(FB_PATH_NUM-1 downto 0); -- Feedback Path Q data

    UL_SYNC_IN                                : in  std_logic_vector( TOTAL_RX_ANT_NUM-1 downto 0);  -- UL DACIF output IQ sample valid
    UL_I_IN                                   : in  std_logic_array16(TOTAL_RX_ANT_NUM-1 downto 0);  -- UL DACIF output I data
    UL_Q_IN                                   : in  std_logic_array16(TOTAL_RX_ANT_NUM-1 downto 0);  -- UL DACIF output Q data

    UL_SYNC_OUT                               : out std_logic_vector( TOTAL_RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output IQ sample valid
    UL_I_OUT                                  : out std_logic_array16(TOTAL_RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output I data
    UL_Q_OUT                                  : out std_logic_array16(TOTAL_RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output Q data

    -- Feedback Switch
    FBSW_START_TRIG_IN                        : in  std_logic;                                 -- Start Pulse of Feedback Switch Period
    FBSW_AUTO_MODE_DONE_IN                    : in  std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback Switch Automode Done Flag, '0': Auto Mode
    FBSW_MANUAL_MODE_IN                       : in  std_logic;                                 -- Feedback Switch Manual Mode, '1': Manual Mode
    FBSW_CNT_IN                               : in  std_logic_vector( 4 downto 0);             -- Feedback Switch Counter
    FBSW_VAL_OUT                              : out std_logic_vector( 3 downto 0);             -- Encoded Feedback Switch Value

    FBSW_SC_PATH_SEL_OUT                      : out std_logic_array5( 1 downto 0);
    PWR_MSR_FB_SYNC_IN                        : in  std_logic;
    PWR_MSR_EN_IN                             : in  std_logic;

    FBSW_SSB_IND_FLAG                         : in  std_logic;

    -- Control & Status
    SIG_SUS_DLOFF_IN                          : in  std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);  -- Wave-Stop Flag

    DL_NCO_WEN_IN                             : in  std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);  -- Downlink NCO (before DPD) Word Write Enable
    DL_NCO_DATA_IN                            : in  std_logic_array32(TOTAL_TX_ANT_NUM-1 downto 0);  -- Downlink NCO (before DPD) Word Value 

    DPD_BYPASS_IN                             : in  std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);  -- DPD-CORE Bypass '1': Bypass 
    DPD_HC_TRSHD_IN                           : in  std_logic_array16(TOTAL_TX_ANT_NUM-1 downto 0);  -- DPD-HC Threshold Value
    DPD_HC_FLAG_OUT                           : out std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0); -- DPD Hard-Clipping Flag
    DPD_DATT_IN                               : in  std_logic_array16(TOTAL_TX_ANT_NUM-1 downto 0);  -- DPD-Digital Attenuator Atten Value
    DPD_FILTER_BYPASS_IN                      : in  std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Bypass '1': Bypass 

    COEF_WREN_IN                              : in  std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Coefficient Write Enable
    COEF_RDEN_IN                              : in  std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Coefficient Read  Enable
    COEF_WR_DONE_IN                           : in  std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Coefficient Write Done 
    COEF_ADDR_IN                              : in  std_logic_vector( 7 downto 0);             -- DPD-OutFilter Coefficient Write/Read Address
    COEF_WR_DATA_IN                           : in  std_logic_vector(15 downto 0);             -- DPD-OutFilter Coefficient Write Data
    COEF_RD_DATA_OUT                          : out std_logic_vector(15 downto 0);             -- DPD-OutFilter Coefficient Read  Data

    DACIF_BYPASS_IN                           : in  std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);  -- DACIF_ON Block Bypass
    DACIF_ON_IN                               : in  std_logic_vector( TOTAL_TX_ANT_NUM-1 downto 0);  -- DACIF_ON Block Control Register form CPU 

    FB_NCO_WEN_IN                             : in  std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback NCO Word Write Enable
    FB_NCO_WORD_IN                            : in  std_logic_array32(FB_PATH_NUM-1 downto 0); -- Feedback NCO Word Value

    FB_FILTER_BYPASS_IN                       : in  std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback Filter Bypass

    FB_PWR_MSR_BFN_STRB_OUT                   : out std_logic;                                 -- Feedback Power Measure Input BFN Strobe

    FB_PWR_MSR_DONE_OUT                       : out std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback Power Measure Done Flag
    FB_PWR_OUT                                : out std_logic_array32(FB_PATH_NUM-1 downto 0); -- Power Value(Mantissa Format) at Feedback Path

    DL_PWR_OUT                                : out std_logic_array32(TOTAL_TX_ANT_NUM-1 downto 0); 

    FB_FWD_DATT_IN                            : in  std_logic_array16(TOTAL_TX_ANT_NUM-1 downto 0);  -- Feedback Forward Side Digital Atten Value
    FB_RVS_DATT_IN                            : in  std_logic_array16(TOTAL_TX_ANT_NUM-1 downto 0);  -- Feedback Reverse Side Digital Atten Value

    PIM_DETECTOR_ON_IN                        : in  std_logic_vector( TOTAL_RX_ANT_NUM-1 downto 0);
    PIM_MITIGATOR_ON_IN                       : in  std_logic_vector( TOTAL_RX_ANT_NUM-1 downto 0);
    PIM_CFR_REF_SEL_IN                        : in  std_logic_vector( TOTAL_RX_ANT_NUM-1 downto 0);

    PIM_PNPC_SEL_IN                           : in  std_logic_array2( TOTAL_RX_ANT_NUM-1 downto 0);
    
    PIM_CORE_BYPASS_IN                        : in  std_logic_vector( TOTAL_RX_ANT_NUM-1 downto 0); -- PIM Core Bypass

    PIM_FILTER_BYPASS_IN                      : in  std_logic_vector( TOTAL_RX_ANT_NUM-1 downto 0); -- PIM Low Pass Filter Bypass
    PIM_FILTER_COEF_WR_EN_IN                  : in  std_logic_vector( TOTAL_RX_ANT_NUM-1 downto 0); -- PIM LPF coefficient write enable(indirect)
    PIM_FILTER_COEF_RD_EN_IN                  : in  std_logic_vector( TOTAL_RX_ANT_NUM-1 downto 0); -- PIM LPF coefficient read  enable(indirect)
    PIM_FILTER_COEF_WR_DN_IN                  : in  std_logic_vector( TOTAL_RX_ANT_NUM-1 downto 0); -- PIM LPF coefficient write done(indirect)
    PIM_FILTER_COEF_ADDR_IN                   : in  std_logic_vector( 7 downto 0);            -- PIM LPF coefficient write address
    PIM_FILTER_COEF_WR_DATA_IN                : in  std_logic_vector(15 downto 0);            -- PIM LPF coefficient write data(indirect) 
    PIM_FILTER_COEF_RD_DATA_OUT               : out std_logic_vector(15 downto 0);            -- PIM LPF coefficient read  data(indirect) 

    PIM_NCO_WREN_IN                           : in  std_logic;
    PIM_NCO_WORD_IN                           : in  std_logic_vector(31 downto 0);

    PIM_INTERBAND_DUC_GAIN_IN                 : in  std_logic_array16(TOTAL_TX_ANT_NUM-1 downto 0);

    UL_PIM_NCO_WREN_IN                        : in  std_logic_vector( 1 downto 0);
    UL_PIM_NCO_WORD_IN                        : in  std_logic_array32(1 downto 0);

    DPD_INFO_OUT                              : out std_logic_vector(31 downto 0);             -- DPD_TOP Information
    DPD_STRUCT_OUT                            : out std_logic_vector(31 downto 0);             -- DPD_TOP Structure Information 
    DPD_DATE_OUT                              : out std_logic_vector(31 downto 0);             -- DPD_TOP Date

    -- Dump & Test
    SC_LB_ON_IN                               : in  std_logic;                                 -- Loopback Enable for Smart Capture Test, Test Only

    DACIF_PHTEST_ENB_IN                       : in  std_logic;                                 -- '1': Phase test enable, '0': disable
    DACIF_PHTEST_REF_SEL_IN                   : in  std_logic;                                 -- '1': BFN_STRB, '0': TDD 
    DACIF_PHTEST_PATH_AB_SWAP_IN              : in  std_logic;                                 -- '1': Swap A/B, '0': normal
    DACIF_PHTEST_PATH_REVERSE_IN              : in  std_logic;                                 -- '1': Reverse 0 <-> (TX_ANT_NUM-1), '0': normal
    DACIF_PHTEST_REPEAT_ENB_IN                : in  std_logic;                                 -- '1': Repeat enable, '0': repeat disable
    DACIF_PHTEST_DACIF_DEFAULT_IN             : in  std_logic_vector(TOTAL_TX_ANT_NUM-1 downto 0);   -- DACIF default value for phase test

    DACIF_PHTEST_OFFSET_IN                    : in  std_logic_vector(23 downto 0);             -- Offset from BFN_STRB/TDD
    DACIF_PHTEST_PERIOD_IN                    : in  std_logic_vector(23 downto 0);             -- Period on/off for one path
    DACIF_PHTEST_ON_DURATION_IN               : in  std_logic_vector(23 downto 0);             -- On duration of one period

    DBG_SIG_OUT                               : out std_logic_array32(1 downto 0);             -- For Block Debugging, Reserved Output

    DUMP_POINT_SEL_STRB_IN                    : in  std_logic;
    DUMP_POINT_SEL_IN                         : in  std_logic_vector( 7 downto 0);             -- Dump Point Selection
    DUMP_BFN_STRB_OUT                         : out std_logic_vector( 1 downto 0);             -- Delayed 10ms Frame Sync Strobe for DUMP                 
    DUMP_DVLD_OUT                             : out std_logic_vector( 1 downto 0);             -- Dump Sample Valid
    DUMP_DATA_OUT                             : out std_logic_array32(1 downto 0);             -- Dump Sample
	
	DPD_DACIF_STAGE_NUM					      : in  std_logic_vector(4-1 downto 0)
    );
end DPD_WRAPPER;

architecture arc_DPD_WRAPPER of DPD_WRAPPER is

    component DPD_TOP is
    generic(
        DPD_NUM                                   : natural :=      1  
    );
    port(
        -- CPU Interface       
        RST_CPUIF                                 : in  std_logic;                                 -- CPUIF Reset, '1': Reset
        CLK_CPUIF                                 : in  std_logic;                                 -- CPUIF Clock, Faster than iclk/oclk
        ADDR_CPUIF_IN                             : in  std_logic_vector(ADDR_WIDTH-1  downto 0);  -- CPUIF Address Input, Word Address
        WDATA_CPUIF_IN                            : in  std_logic_vector(WDATA_WIDTH-1 downto 0);  -- CPUIF Data Input
        RDATA_CPUIF_OUT                           : out std_logic_vector(RDATA_WIDTH-1 downto 0);  -- CPUIF Data Output
        WREN_CPUIF_IN                             : in  std_logic;                                 -- CPUIF Write Enable, '1': Active, Synchronous with iclk
        RDEN_CPUIF_IN                             : in  std_logic;                                 -- CPUIF Read  Enable, '1': Active
        RDVLD_CPUIF_OUT                           : out std_logic;                                 -- CPUIF Read Valid,   '1': Active, Synchronous with clk_cpu

        -- Reset & Clock                          
        RST_DPD                                   : in  std_logic;                                 -- DPD_TOP Reset, '1': Reset
        RST_PIM                                   : in  std_logic;                                 -- DPD_TOP Reset, '1': Reset
        CLK_SYS                                   : in  std_logic;                                 -- System Clock :  30.72 MHz
        CLK_SYSX2                                 : in  std_logic;                                 --  2x(CLK_SYS) :  61.44 MHz
        CLK_SYSX3                                 : in  std_logic;                                 --  3x(CLK_SYS) :  92.16 MHz
        CLK_SYSX4                                 : in  std_logic;                                 --  4x(CLK_SYS) : 122.88 MHz
        CLK_SYSX5                                 : in  std_logic;                                 --  5x(CLK_SYS) : 153.60 MHz
        CLK_SYSX6                                 : in  std_logic;                                 --  6x(CLK_SYS) : 184.32 MHz
        CLK_SYSX8                                 : in  std_logic;                                 --  8x(CLK_SYS) : 245.76 MHz
        CLK_SYSX10                                : in  std_logic;                                 -- 10x(CLK_SYS) : 307.20 MHz
        CLK_SYSX12                                : in  std_logic;                                 -- 12x(CLK_SYS) : 368.64 MHz
        CLK_SYSX16                                : in  std_logic;                                 -- 16x(CLK_SYS) : 491.52 MHz
        CLK_SYSX20                                : in  std_logic;                                 -- 20x(CLK_SYS) : 614.40 MHz

        -- PLL Lock
        INT_SYSPLL_LOCK_IN                        : in  std_logic;                                 -- Internal System PLL Lock 

        -- DL/FB Latency
        DPD_DL_PROC_DLY_OUT                       : out std_logic_vector(31 downto 0);             -- Downlink Latency Information (Unit : Clock)
        DPD_FB_PROC_DLY_OUT                       : out std_logic_vector(31 downto 0);             -- Feedback Latency Information (Unit : Clock)
        DPD_UL_PROC_DLY_OUT                       : out std_logic_vector(31 downto 0);             -- Uplink   Latency Information (Unit : Clock)
        
        -- TDD/FS Strobe 
        DL_BFN_STRB_IN                            : in  std_logic;                                 -- Downlink 10ms Frame Sync Strobe
        DL_TDD_IN                                 : in  std_logic;                                 -- Downlink TDD Strobe
        DL_SSB_STRB_IN                            : in  std_logic;                                 -- 40ms sync signal for SSB power measurement
        
        DL_BFN_STRB_OUT                           : out std_logic;                                 -- Delayed Downlink 10ms Frame Sync Strobe as DL Path Latency 
        DL_TDD_OUT                                : out std_logic;                                 -- Delayed Downlink TDD Strobe as DL Path Latency 
        DL_SSB_STRB_OUT                           : out std_logic;                                 -- 40ms sync signal for SSB power measurement
        
        FB_BFN_STRB_IN                            : in  std_logic;                                 -- Feedback 10ms Frame Sync Strobe
        FB_TDD_IN                                 : in  std_logic;                                 -- Feedback TDD Strobe
        FB_SSB_STRB_IN                            : in  std_logic;                                 -- 40ms sync signal for SSB power measurement
        
        UL_BFN_STRB_IN                            : in  std_logic;                                 -- Uplink 10ms Frame Sync Strobe
        UL_TDD_IN                                 : in  std_logic;                                 -- Uplink TDD Strobe
        
        UL_BFN_STRB_OUT                           : out std_logic;                                 -- Delayed Uplink 10ms Frame Sync Strobe as UL Path Latency 
        UL_TDD_OUT                                : out std_logic;                                 -- Delayed Uplink TDD Strobe as DL Path Latency 

        DL_BCF_ENB_IN                             : in  std_logic;
        DL_BCF_ENB_OUT                            : out std_logic;

        UL_BCF_ENB_IN                             : in  std_logic;
        UL_BCF_ENB_OUT                            : out std_logic;

        DL_GSM_120MS_IN                           : in  std_logic;   
        DL_TS16_SYNC_IN                           : in  std_logic;
        DL_TS_SYNC_IN                             : in  std_logic; 
        DL_TS_GP_SYNC_IN                          : in  std_logic;
        
        DL_GSM_120MS_OUT                          : out std_logic;
        DL_TS16_SYNC_OUT                          : out std_logic;
        DL_TS_SYNC_OUT                            : out std_logic;
        DL_TS_GP_SYNC_OUT                         : out std_logic;
        
        UL_GSM_120MS_IN                           : in  std_logic;
        UL_TS16_SYNC_IN                           : in  std_logic;
        UL_TS_SYNC_IN                             : in  std_logic;
        UL_TS_GP_SYNC_IN                          : in  std_logic;
                                                        
        UL_GSM_120MS_OUT                          : out std_logic; 
        UL_TS16_SYNC_OUT                          : out std_logic;
        UL_TS_SYNC_OUT                            : out std_logic;
        UL_TS_GP_SYNC_OUT                         : out std_logic;

        -- Traffic IQ
        DL_SYNC_IN                                : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- CFR-HC output IQ sample valid
        DL_I_IN                                   : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- CFR-HC output I data
        DL_Q_IN                                   : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- CFR-HC output Q data

        DL_INTERBAND_SYNC_IN                      : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- InterBand PIM DUC output IQ sample valid
        DL_INTERBAND_I_IN                         : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- InterBand PIM DUC output I data
        DL_INTERBAND_Q_IN                         : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- InterBand PIM DUC output Q data

        DL_SYNC_OUT                               : out std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output IQ sample valid
        DL_I_OUT                                  : out std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output I data
        DL_Q_OUT                                  : out std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output Q data


        FB_SYNC_IN                                : in  std_logic_vector( HALF_DSP_FB_PATH_NUM-1 downto 0); -- Feedback Path IQ sample valid
        FB_I_EVEN_IN                              : in  std_logic_array16(HALF_DSP_FB_PATH_NUM-1 downto 0); -- Feedback Path I data
        FB_Q_EVEN_IN                              : in  std_logic_array16(HALF_DSP_FB_PATH_NUM-1 downto 0); -- Feedback Path Q data
        FB_I_ODD_IN                               : in  std_logic_array16(HALF_DSP_FB_PATH_NUM-1 downto 0); -- Feedback Path I data
        FB_Q_ODD_IN                               : in  std_logic_array16(HALF_DSP_FB_PATH_NUM-1 downto 0); -- Feedback Path Q data

        UL_SYNC_IN                                : in  std_logic_vector( RX_ANT_NUM-1 downto 0);  -- UL DACIF output IQ sample valid
        UL_I_IN                                   : in  std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DACIF output I data
        UL_Q_IN                                   : in  std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DACIF output Q data

        UL_SYNC_OUT                               : out std_logic_vector( RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output IQ sample valid
        UL_I_OUT                                  : out std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output I data
        UL_Q_OUT                                  : out std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output Q data

        -- Feedback Switch
        FBSW_START_TRIG_IN                        : in  std_logic;                                 -- Start Pulse of Feedback Switch Period
        FBSW_AUTO_MODE_DONE_IN                    : in  std_logic_vector( HALF_DSP_FB_PATH_NUM-1 downto 0); -- Feedback Switch Automode Done Flag, '0': Auto Mode
        FBSW_MANUAL_MODE_IN                       : in  std_logic;                                 -- Feedback Switch Manual Mode, '1': Manual Mode
        FBSW_CNT_IN                               : in  std_logic_vector( 4 downto 0);             -- Feedback Switch Counter
        FBSW_VAL_OUT                              : out std_logic_vector( 3 downto 0);             -- Encoded Feedback Switch Value

        FBSW_SC_PATH_SEL_OUT                      : out std_logic_vector( 4 downto 0);
        PWR_MSR_FB_SYNC_IN                        : in  std_logic;
        PWR_MSR_EN_IN                             : in  std_logic;

        FBSW_SSB_IND_FLAG                         : in  std_logic;

        -- Control & Status
        SIG_SUS_DLOFF_IN                          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- Wave-Stop Flag

        DL_NCO_WEN_IN                             : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- Downlink NCO (before DPD) Word Write Enable
        DL_NCO_DATA_IN                            : in  std_logic_array32(TX_ANT_NUM-1 downto 0);  -- Downlink NCO (before DPD) Word Value 

        DPD_BYPASS_IN                             : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DPD-CORE Bypass '1': Bypass 
        DPD_HC_TRSHD_IN                           : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DPD-HC Threshold Value
        DPD_HC_FLAG_OUT                           : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Hard-Clipping Flag
        DPD_DATT_IN                               : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DPD-Digital Attenuator Atten Value
        DPD_FILTER_BYPASS_IN                      : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Bypass '1': Bypass 

        COEF_WREN_IN                              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Coefficient Write Enable
        COEF_RDEN_IN                              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Coefficient Read  Enable
        COEF_WR_DONE_IN                           : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Coefficient Write Done 
        COEF_ADDR_IN                              : in  std_logic_vector( 7 downto 0);             -- DPD-OutFilter Coefficient Write/Read Address
        COEF_WR_DATA_IN                           : in  std_logic_vector(15 downto 0);             -- DPD-OutFilter Coefficient Write Data
        COEF_RD_DATA_OUT                          : out std_logic_vector(15 downto 0);             -- DPD-OutFilter Coefficient Read  Data

        DACIF_BYPASS_IN                           : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DACIF_ON Block Bypass
        DACIF_ON_IN                               : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DACIF_ON Block Control Register form CPU 

        FB_NCO_WEN_IN                             : in  std_logic_vector( HALF_DSP_FB_PATH_NUM-1 downto 0); -- Feedback NCO Word Write Enable
        FB_NCO_WORD_IN                            : in  std_logic_array32(HALF_DSP_FB_PATH_NUM-1 downto 0); -- Feedback NCO Word Value

        FB_FILTER_BYPASS_IN                       : in  std_logic_vector( HALF_DSP_FB_PATH_NUM-1 downto 0); -- Feedback Filter Bypass

        FB_PWR_MSR_BFN_STRB_OUT                   : out std_logic;                                 -- Feedback Power Measure Input BFN Strobe
        FB_PWR_MSR_DONE_OUT                       : out std_logic_vector( HALF_DSP_FB_PATH_NUM-1 downto 0); -- Feedback Power Measure Done Flag
        FB_PWR_OUT                                : out std_logic_array32(HALF_DSP_FB_PATH_NUM-1 downto 0); -- Power Value(Mantissa Format) at Feedback Path

        DL_PWR_OUT                                : out std_logic_array32(TX_ANT_NUM-1 downto 0); 

        FB_FWD_DATT_IN                            : in  std_logic_array16(TOTAL_TX_ANT_NUM-1 downto 0);  -- Feedback Forward Side Digital Atten Value
        FB_RVS_DATT_IN                            : in  std_logic_array16(TOTAL_TX_ANT_NUM-1 downto 0);  -- Feedback Reverse Side Digital Atten Value

        PIM_DETECTOR_ON_IN                        : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
        PIM_MITIGATOR_ON_IN                       : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
        PIM_CFR_REF_SEL_IN                        : in  std_logic_vector( RX_ANT_NUM-1 downto 0);

        PIM_PNPC_SEL_IN                           : in  std_logic_array2( RX_ANT_NUM-1 downto 0);
        
        PIM_CORE_BYPASS_IN                        : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM Core Bypass

        PIM_FILTER_BYPASS_IN                      : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM Low Pass Filter Bypass
        PIM_FILTER_COEF_WR_EN_IN                  : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM LPF coefficient write enable(indirect)
        PIM_FILTER_COEF_RD_EN_IN                  : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM LPF coefficient read  enable(indirect)
        PIM_FILTER_COEF_WR_DN_IN                  : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM LPF coefficient write done(indirect)
        PIM_FILTER_COEF_ADDR_IN                   : in  std_logic_vector( 7 downto 0);            -- PIM LPF coefficient write address
        PIM_FILTER_COEF_WR_DATA_IN                : in  std_logic_vector(15 downto 0);            -- PIM LPF coefficient write data(indirect) 
        PIM_FILTER_COEF_RD_DATA_OUT               : out std_logic_vector(15 downto 0);            -- PIM LPF coefficient read  data(indirect) 

        PIM_NCO_WREN_IN                           : in  std_logic;
        PIM_NCO_WORD_IN                           : in  std_logic_vector(31 downto 0);

        PIM_INTERBAND_DUC_GAIN_IN                 : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

        UL_PIM_NCO_WREN_IN                        : in  std_logic;
        UL_PIM_NCO_WORD_IN                        : in  std_logic_vector(31 downto 0);

        DPD_INFO_OUT                              : out std_logic_vector(31 downto 0);             -- DPD_TOP Information
        DPD_STRUCT_OUT                            : out std_logic_vector(31 downto 0);             -- DPD_TOP Structure Information 
        DPD_DATE_OUT                              : out std_logic_vector(31 downto 0);             -- DPD_TOP Date

        -- Dump & Test
        SC_LB_ON_IN                               : in  std_logic;                                 -- Loopback Enable for Smart Capture Test, Test Only

        DACIF_PHTEST_ENB_IN                       : in  std_logic;                                 -- '1': Phase test enable, '0': disable
        DACIF_PHTEST_REF_SEL_IN                   : in  std_logic;                                 -- '1': BFN_STRB, '0': TDD 
        DACIF_PHTEST_PATH_AB_SWAP_IN              : in  std_logic;                                 -- '1': Swap A/B, '0': normal
        DACIF_PHTEST_PATH_REVERSE_IN              : in  std_logic;                                 -- '1': Reverse 0 <-> (TX_ANT_NUM-1), '0': normal
        DACIF_PHTEST_REPEAT_ENB_IN                : in  std_logic;                                 -- '1': Repeat enable, '0': repeat disable
        DACIF_PHTEST_DACIF_DEFAULT_IN             : in  std_logic_vector(TX_ANT_NUM-1 downto 0);   -- DACIF default value for phase test

        DACIF_PHTEST_OFFSET_IN                    : in  std_logic_vector(23 downto 0);             -- Offset from BFN_STRB/TDD
        DACIF_PHTEST_PERIOD_IN                    : in  std_logic_vector(23 downto 0);             -- Period on/off for one path
        DACIF_PHTEST_ON_DURATION_IN               : in  std_logic_vector(23 downto 0);             -- On duration of one period

        DBG_SIG_OUT                               : out std_logic_array32(1 downto 0);             -- For Block Debugging, Reserved Output

        DUMP_POINT_SEL_STRB_IN                    : in  std_logic;
        DUMP_POINT_SEL_IN                         : in  std_logic_vector( 7 downto 0);             -- Dump Point Selection
        DUMP_BFN_STRB_OUT                         : out std_logic_vector( 1 downto 0);             -- Delayed 10ms Frame Sync Strobe for DUMP                 
        DUMP_DVLD_OUT                             : out std_logic_vector( 1 downto 0);             -- Dump Sample Valid
        DUMP_DATA_OUT                             : out std_logic_array32(1 downto 0);             -- Dump Sample
		
		DPD_DACIF_STAGE_NUM  					  : in  std_logic_vector(4-1 downto 0)
        );         
    end component;

    signal dpd0_coef_rd_data                      : std_logic_vector(15 downto 0);
    signal dpd1_coef_rd_data                      : std_logic_vector(15 downto 0);


    signal dpd0_pim_coef_rd_data                  : std_logic_vector(15 downto 0);   
    signal dpd1_pim_coef_rd_data                  : std_logic_vector(15 downto 0);


    signal dump_point_sel_strb                    : std_logic;
    signal dpd0_dump_point_sel                    : std_logic_vector( 7 downto 0); 
    signal dpd1_dump_point_sel                    : std_logic_vector( 7 downto 0); 

    signal dpd0_dump_bfn_strb                     : std_logic_vector( 1 downto 0); 
    signal dpd0_dump_dvld                         : std_logic_vector( 1 downto 0);
    signal dpd0_dump_data                         : std_logic_array32(1 downto 0);

    signal dpd1_dump_bfn_strb                     : std_logic_vector( 1 downto 0); 
    signal dpd1_dump_dvld                         : std_logic_vector( 1 downto 0);
    signal dpd1_dump_data                         : std_logic_array32(1 downto 0);
    
    begin
        process(DPD_CLK_CPUIF) begin
            if (DPD_CLK_CPUIF'event) and (DPD_CLK_CPUIF = '1') then
                if (COEF_RDEN_IN(0) = '1' or COEF_RDEN_IN(1) = '1' ) then
                    COEF_RD_DATA_OUT <= dpd0_coef_rd_data;
                elsif (COEF_RDEN_IN(2) = '1' or COEF_RDEN_IN(3) = '1' ) then
                    COEF_RD_DATA_OUT <= dpd1_coef_rd_data;
                end if;
            end if;
        end process;

        process(DPD_CLK_CPUIF) begin
            if (DPD_CLK_CPUIF'event) and (DPD_CLK_CPUIF = '1') then
                if (PIM_FILTER_COEF_RD_EN_IN(0) = '1' or PIM_FILTER_COEF_RD_EN_IN(1) = '1' ) then
                    PIM_FILTER_COEF_RD_DATA_OUT <= dpd0_pim_coef_rd_data;
                elsif (PIM_FILTER_COEF_RD_EN_IN(2) = '1' or PIM_FILTER_COEF_RD_EN_IN(3) = '1' ) then
                    PIM_FILTER_COEF_RD_DATA_OUT <= dpd1_pim_coef_rd_data;
                end if;
            end if;
        end process;

        process(DPD_CLK_CPUIF) begin
            if (DPD_CLK_CPUIF'event) and (DPD_CLK_CPUIF = '1') then
                dump_point_sel_strb <= DUMP_POINT_SEL_STRB_IN; 

                dpd0_dump_point_sel <= DUMP_POINT_SEL_IN;
                if (DUMP_POINT_SEL_IN(7 downto 4) = x"A") then
                    dpd1_dump_point_sel <= DUMP_POINT_SEL_IN(7 downto 2) & "00";
                else
                    dpd1_dump_point_sel <= DUMP_POINT_SEL_IN(7 downto 2) & "0" & DUMP_POINT_SEL_IN(0);
                end if;

            end if;
        end process;
            
        process(CLK_SYSX8) begin
            if (CLK_SYSX8'event) and (CLK_SYSX8 = '1') then
                if(DUMP_POINT_SEL_IN(7 downto 4) = x"8" or DUMP_POINT_SEL_IN(7 downto 4) = x"9") then
                   if(DUMP_POINT_SEL_IN(3 downto 0) = x"0" or DUMP_POINT_SEL_IN(3 downto 0) = x"1") then
                       DUMP_BFN_STRB_OUT <= dpd0_dump_bfn_strb;
                       DUMP_DVLD_OUT     <= dpd0_dump_dvld;
                       DUMP_DATA_OUT     <= dpd0_dump_data;
                   elsif(DUMP_POINT_SEL_IN(3 downto 0) = x"2" or DUMP_POINT_SEL_IN(3 downto 0) = x"3") then
                       DUMP_BFN_STRB_OUT <= dpd1_dump_bfn_strb;
                       DUMP_DVLD_OUT     <= dpd1_dump_dvld;
                       DUMP_DATA_OUT     <= dpd1_dump_data;
                   end if;
                elsif(DUMP_POINT_SEL_IN(7 downto 4) = x"A") then
                   if(DUMP_POINT_SEL_IN(3 downto 0) = x"0") then
                       DUMP_BFN_STRB_OUT <= dpd0_dump_bfn_strb;
                       DUMP_DVLD_OUT     <= dpd0_dump_dvld;
                       DUMP_DATA_OUT     <= dpd0_dump_data;
                   elsif(DUMP_POINT_SEL_IN(3 downto 0) = x"1") then
                       DUMP_BFN_STRB_OUT <= dpd1_dump_bfn_strb;
                       DUMP_DVLD_OUT     <= dpd1_dump_dvld;
                       DUMP_DATA_OUT     <= dpd1_dump_data;
                   end if;
                end if;
            end if;
        end process;    

        U_DPD_TOP0 : DPD_TOP 
        generic map(
            DPD_NUM                                  => 0  
        )
        port map(
            -- CPU Interface       
            RST_CPUIF                                => DPD_RST_CPUIF,                                
            CLK_CPUIF                                => DPD_CLK_CPUIF,                                
            ADDR_CPUIF_IN                            => DPD0_ADDR_CPUIF_IN,                            
            WDATA_CPUIF_IN                           => DPD0_WDATA_CPUIF_IN,                           
            RDATA_CPUIF_OUT                          => DPD0_RDATA_CPUIF_OUT,                          
            WREN_CPUIF_IN                            => DPD0_WREN_CPUIF_IN,                            
            RDEN_CPUIF_IN                            => DPD0_RDEN_CPUIF_IN,                            
            RDVLD_CPUIF_OUT                          => DPD0_RDVLD_CPUIF_OUT,                          

            -- Reset & Clock                                                    
            RST_DPD                                  => RST_DPD,                             
            RST_PIM                                  => RST_PIM,                             
            CLK_SYS                                  => CLK_SYS,                             
            CLK_SYSX2                                => CLK_SYSX2,                           
            CLK_SYSX3                                => CLK_SYSX3,                           
            CLK_SYSX4                                => CLK_SYSX4,                           
            CLK_SYSX5                                => CLK_SYSX5,                           
            CLK_SYSX6                                => CLK_SYSX6,                           
            CLK_SYSX8                                => CLK_SYSX8,                           
            CLK_SYSX10                               => CLK_SYSX10,                          
            CLK_SYSX12                               => CLK_SYSX12,                         
            CLK_SYSX16                               => CLK_SYSX16,                          
            CLK_SYSX20                               => CLK_SYSX20,                         

            -- PLL Lock
            INT_SYSPLL_LOCK_IN                       => INT_SYSPLL_LOCK_IN,                   

            -- DL/FB Latency
            DPD_DL_PROC_DLY_OUT                      => DPD_DL_PROC_DLY_OUT, --                           : out std_logic_vector(31 downto 0);             -- Downlink Latency Information (Unit : Clock)
            DPD_FB_PROC_DLY_OUT                      => DPD_FB_PROC_DLY_OUT, --                           : out std_logic_vector(31 downto 0);             -- Feedback Latency Information (Unit : Clock)
            DPD_UL_PROC_DLY_OUT                      => DPD_UL_PROC_DLY_OUT, --                           : out std_logic_vector(31 downto 0);             -- Uplink   Latency Information (Unit : Clock)
            
            -- TDD/FS Strobe 
            DL_BFN_STRB_IN                           => DL_BFN_STRB_IN,                         
            DL_TDD_IN                                => DL_TDD_IN,                               
            DL_SSB_STRB_IN                           => DL_SSB_STRB_IN,                          
            
            DL_BFN_STRB_OUT                          => DL_BFN_STRB_OUT, --                               : out std_logic;                                 -- Delayed Downlink 10ms Frame Sync Strobe as DL Path Latency 
            DL_TDD_OUT                               => DL_TDD_OUT,      --                               : out std_logic;                                 -- Delayed Downlink TDD Strobe as DL Path Latency 
            DL_SSB_STRB_OUT                          => DL_SSB_STRB_OUT, --                               : out std_logic;                                 -- 40ms sync signal for SSB power measurement
            
            FB_BFN_STRB_IN                           => FB_BFN_STRB_IN,                       
            FB_TDD_IN                                => FB_TDD_IN,                               
            FB_SSB_STRB_IN                           => FB_SSB_STRB_IN,                        
            
            UL_BFN_STRB_IN                           => UL_BFN_STRB_IN,                          
            UL_TDD_IN                                => UL_TDD_IN,                            
            
            UL_BFN_STRB_OUT                          => UL_BFN_STRB_OUT, --                               : out std_logic;                                 -- Delayed Uplink 10ms Frame Sync Strobe as UL Path Latency 
            UL_TDD_OUT                               => UL_TDD_OUT,      --                               : out std_logic;                                 -- Delayed Uplink TDD Strobe as DL Path Latency 

            DL_BCF_ENB_IN                            => DL_BCF_ENB_IN,                          
            DL_BCF_ENB_OUT                           => DL_BCF_ENB_OUT, --                                : out std_logic;

            UL_BCF_ENB_IN                            => UL_BCF_ENB_IN,                          
            UL_BCF_ENB_OUT                           => UL_BCF_ENB_OUT, --                                : out std_logic;                                                                                                                                           

            DL_GSM_120MS_IN                          => DL_GSM_120MS_IN,    
            DL_TS16_SYNC_IN                          => DL_TS16_SYNC_IN, 
            DL_TS_SYNC_IN                            => DL_TS_SYNC_IN,  
            DL_TS_GP_SYNC_IN                         => DL_TS_GP_SYNC_IN, 
                                                        
            DL_GSM_120MS_OUT                         => DL_GSM_120MS_OUT, 
            DL_TS16_SYNC_OUT                         => DL_TS16_SYNC_OUT, 
            DL_TS_SYNC_OUT                           => DL_TS_SYNC_OUT, 
            DL_TS_GP_SYNC_OUT                        => DL_TS_GP_SYNC_OUT, 
                                                        
            UL_GSM_120MS_IN                          => UL_GSM_120MS_IN, 
            UL_TS16_SYNC_IN                          => UL_TS16_SYNC_IN, 
            UL_TS_SYNC_IN                            => UL_TS_SYNC_IN, 
            UL_TS_GP_SYNC_IN                         => UL_TS_GP_SYNC_IN, 
            
            UL_GSM_120MS_OUT                         => UL_GSM_120MS_OUT,  
            UL_TS16_SYNC_OUT                         => UL_TS16_SYNC_OUT, 
            UL_TS_SYNC_OUT                           => UL_TS_SYNC_OUT, 
            UL_TS_GP_SYNC_OUT                        => UL_TS_GP_SYNC_OUT, 

            -- Traffic IQ
            DL_SYNC_IN                               => DL_SYNC_IN(1 downto 0),                                    
            DL_I_IN                                  => DL_I_IN(1 downto 0),                                       
            DL_Q_IN                                  => DL_Q_IN(1 downto 0),                                       
                                                                            
            DL_INTERBAND_SYNC_IN                     => DL_INTERBAND_SYNC_IN(3 downto 2),                          
            DL_INTERBAND_I_IN                        => DL_INTERBAND_I_IN(3 downto 2),                             
            DL_INTERBAND_Q_IN                        => DL_INTERBAND_Q_IN(3 downto 2),                                              

            DL_SYNC_OUT                              => DL_SYNC_OUT(1 downto 0), --                        : out std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output IQ sample valid
            DL_I_OUT                                 => DL_I_OUT(1 downto 0), --                           : out std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output I data
            DL_Q_OUT                                 => DL_Q_OUT(1 downto 0), --                           : out std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output Q data


            FB_SYNC_IN                               => FB_SYNC_IN(0 downto 0),                                       
            FB_I_EVEN_IN                             => FB_I_EVEN_IN(0 downto 0),                                          
            FB_Q_EVEN_IN                             => FB_Q_EVEN_IN(0 downto 0),                                                   
            FB_I_ODD_IN                              => FB_I_ODD_IN(0 downto 0),                                          
            FB_Q_ODD_IN                              => FB_Q_ODD_IN(0 downto 0), 


            UL_SYNC_IN                               => UL_SYNC_IN(1 downto 0),                        
            UL_I_IN                                  => UL_I_IN(1 downto 0),                             
            UL_Q_IN                                  => UL_Q_IN(1 downto 0),                             

            UL_SYNC_OUT                              => UL_SYNC_OUT(1 downto 0), --                         : out std_logic_vector( RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output IQ sample valid
            UL_I_OUT                                 => UL_I_OUT(1 downto 0), --                            : out std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output I data
            UL_Q_OUT                                 => UL_Q_OUT(1 downto 0), --                            : out std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output Q data

            -- Feedback Switch
            FBSW_START_TRIG_IN                       => FBSW_START_TRIG_IN,                                 
            FBSW_AUTO_MODE_DONE_IN                   => (others => '0'),                           
            FBSW_MANUAL_MODE_IN                      => FBSW_MANUAL_MODE_IN,                                
            FBSW_CNT_IN                              => FBSW_CNT_IN,                                        
            FBSW_VAL_OUT                             => FBSW_VAL_OUT, --                                               
                                                                              
            FBSW_SC_PATH_SEL_OUT                     => FBSW_SC_PATH_SEL_OUT(0),                                
            PWR_MSR_FB_SYNC_IN                       => PWR_MSR_FB_SYNC_IN,                                 
            PWR_MSR_EN_IN                            => PWR_MSR_EN_IN,                                           

            FBSW_SSB_IND_FLAG                        => FBSW_SSB_IND_FLAG,

            -- Control & Status
            SIG_SUS_DLOFF_IN                         => SIG_SUS_DLOFF_IN(1 downto 0),                           
                                                                         
            DL_NCO_WEN_IN                            => DL_NCO_WEN_IN(1 downto 0),                              
            DL_NCO_DATA_IN                           => DL_NCO_DATA_IN(1 downto 0),                             
                                                                         
            DPD_BYPASS_IN                            => DPD_BYPASS_IN(1 downto 0),                                  
            DPD_HC_TRSHD_IN                          => DPD_HC_TRSHD_IN(1 downto 0),                            
            DPD_HC_FLAG_OUT                          => DPD_HC_FLAG_OUT(1 downto 0), --                            : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Hard-Clipping Flag
            DPD_DATT_IN                              => DPD_DATT_IN(1 downto 0),                                   
            DPD_FILTER_BYPASS_IN                     => DPD_FILTER_BYPASS_IN(1 downto 0),                           

            COEF_WREN_IN                             => COEF_WREN_IN(1 downto 0),                                             
            COEF_RDEN_IN                             => COEF_RDEN_IN(1 downto 0),                                             
            COEF_WR_DONE_IN                          => COEF_WR_DONE_IN(1 downto 0),                                          
            COEF_ADDR_IN                             => COEF_ADDR_IN,                                             
            COEF_WR_DATA_IN                          => COEF_WR_DATA_IN,                                          
            COEF_RD_DATA_OUT                         => dpd0_coef_rd_data, --                                      : out std_logic_vector(15 downto 0);             -- DPD-OutFilter Coefficient Read  Data

            DACIF_BYPASS_IN                          => DACIF_BYPASS_IN(1 downto 0),                                 
            DACIF_ON_IN                              => DACIF_ON_IN(1 downto 0),                                     
                                                                                        
            FB_NCO_WEN_IN                            => FB_NCO_WEN_IN(0 downto 0),                                            
            FB_NCO_WORD_IN                           => FB_NCO_WORD_IN(0 downto 0),                                           
                                                                                        
            FB_FILTER_BYPASS_IN                      => FB_FILTER_BYPASS_IN(0 downto 0),                                            
                                                                                        
            FB_PWR_MSR_BFN_STRB_OUT                  => FB_PWR_MSR_BFN_STRB_OUT, --                                : out std_logic;                                 -- Feedback Power Measure Input BFN Strobe
            FB_PWR_MSR_DONE_OUT                      => FB_PWR_MSR_DONE_OUT(0 downto 0), --                        : out std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback Power Measure Done Flag
            FB_PWR_OUT                               => FB_PWR_OUT(0 downto 0), --                                 : out std_logic_array32(FB_PATH_NUM-1 downto 0); -- Power Value(Mantissa Format) at Feedback Path
                 
            DL_PWR_OUT                               => DL_PWR_OUT(1 downto 0),

            FB_FWD_DATT_IN                           => FB_FWD_DATT_IN,                                             
            FB_RVS_DATT_IN                           => FB_RVS_DATT_IN,                                             
                                                                                        
            PIM_DETECTOR_ON_IN                       => PIM_DETECTOR_ON_IN(1 downto 0),                                         
            PIM_MITIGATOR_ON_IN                      => PIM_MITIGATOR_ON_IN(1 downto 0),                                        
            PIM_CFR_REF_SEL_IN                       => PIM_CFR_REF_SEL_IN(1 downto 0),                                         
                                                                                        
            PIM_PNPC_SEL_IN                          => PIM_PNPC_SEL_IN(1 downto 0),                                            
                                                        
            PIM_CORE_BYPASS_IN                       => PIM_CORE_BYPASS_IN(1 downto 0),                                         
                                                                                        
            PIM_FILTER_BYPASS_IN                     => PIM_FILTER_BYPASS_IN(1 downto 0),                                       
            PIM_FILTER_COEF_WR_EN_IN                 => PIM_FILTER_COEF_WR_EN_IN(1 downto 0),                                   
            PIM_FILTER_COEF_RD_EN_IN                 => PIM_FILTER_COEF_RD_EN_IN(1 downto 0),                                   
            PIM_FILTER_COEF_WR_DN_IN                 => PIM_FILTER_COEF_WR_DN_IN(1 downto 0),                                             
            PIM_FILTER_COEF_ADDR_IN                  => PIM_FILTER_COEF_ADDR_IN,                                   
            PIM_FILTER_COEF_WR_DATA_IN               => PIM_FILTER_COEF_WR_DATA_IN,                                 
            PIM_FILTER_COEF_RD_DATA_OUT              => dpd0_pim_coef_rd_data, --                                  : out std_logic_vector(15 downto 0);            -- PIM LPF coefficient read  data(indirect) 
                                                                                        
            PIM_NCO_WREN_IN                          => PIM_NCO_WREN_IN,                                           
            PIM_NCO_WORD_IN                          => PIM_NCO_WORD_IN,                                           
                                                                                        
            PIM_INTERBAND_DUC_GAIN_IN                => PIM_INTERBAND_DUC_GAIN_IN(1 downto 0),                    
                                                                                        
            UL_PIM_NCO_WREN_IN                       => UL_PIM_NCO_WREN_IN(0),                                        
            UL_PIM_NCO_WORD_IN                       => UL_PIM_NCO_WORD_IN(0),                                        
                                                                                        
            DPD_INFO_OUT                             => DPD_INFO_OUT,   --                                         : out std_logic_vector(31 downto 0);             -- DPD_TOP Information
            DPD_STRUCT_OUT                           => DPD_STRUCT_OUT, --                                         : out std_logic_vector(31 downto 0);             -- DPD_TOP Structure Information 
            DPD_DATE_OUT                             => DPD_DATE_OUT,   --                                         : out std_logic_vector(31 downto 0);             -- DPD_TOP Date

            -- Dump & Test
            SC_LB_ON_IN                              => SC_LB_ON_IN,                                            
                                                                                     
            DACIF_PHTEST_ENB_IN                      => DACIF_PHTEST_ENB_IN,                                    
            DACIF_PHTEST_REF_SEL_IN                  => DACIF_PHTEST_REF_SEL_IN,                                
            DACIF_PHTEST_PATH_AB_SWAP_IN             => DACIF_PHTEST_PATH_AB_SWAP_IN,                           
            DACIF_PHTEST_PATH_REVERSE_IN             => DACIF_PHTEST_PATH_REVERSE_IN,                           
            DACIF_PHTEST_REPEAT_ENB_IN               => DACIF_PHTEST_REPEAT_ENB_IN,                             
            DACIF_PHTEST_DACIF_DEFAULT_IN            => DACIF_PHTEST_DACIF_DEFAULT_IN(1 downto 0),              
                                                                                     
            DACIF_PHTEST_OFFSET_IN                   => DACIF_PHTEST_OFFSET_IN,                                 
            DACIF_PHTEST_PERIOD_IN                   => DACIF_PHTEST_PERIOD_IN,                                 
            DACIF_PHTEST_ON_DURATION_IN              => DACIF_PHTEST_ON_DURATION_IN,                             
                                                                                     
            DBG_SIG_OUT                              => DBG_SIG_OUT, --                                            : out std_logic_array32(1 downto 0);             -- For Block Debugging, Reserved Output
                                                                                     
            DUMP_POINT_SEL_STRB_IN                   => dump_point_sel_strb,                                 
            DUMP_POINT_SEL_IN                        => dpd0_dump_point_sel,                                      
            DUMP_BFN_STRB_OUT                        => dpd0_dump_bfn_strb, --                                                   : out std_logic_vector( 1 downto 0);             -- Delayed 10ms Frame Sync Strobe for DUMP                 
            DUMP_DVLD_OUT                            => dpd0_dump_dvld, --                                                   : out std_logic_vector( 1 downto 0);             -- Dump Sample Valid
            DUMP_DATA_OUT                            => dpd0_dump_data,  --                                                   : out std_logic_array32(1 downto 0)              -- Dump Sampl                           
			
			DPD_DACIF_STAGE_NUM						 => DPD_DACIF_STAGE_NUM
            );


        U_DPD_TOP1 : DPD_TOP 
        generic map(
            DPD_NUM                                  => 1 
        )
        port map(
            -- CPU Interface       
            RST_CPUIF                                => DPD_RST_CPUIF,                                
            CLK_CPUIF                                => DPD_CLK_CPUIF,                                
            ADDR_CPUIF_IN                            => DPD1_ADDR_CPUIF_IN,                            
            WDATA_CPUIF_IN                           => DPD1_WDATA_CPUIF_IN,                           
            RDATA_CPUIF_OUT                          => DPD1_RDATA_CPUIF_OUT,                          
            WREN_CPUIF_IN                            => DPD1_WREN_CPUIF_IN,                            
            RDEN_CPUIF_IN                            => DPD1_RDEN_CPUIF_IN,                            
            RDVLD_CPUIF_OUT                          => DPD1_RDVLD_CPUIF_OUT,                          

            -- Reset & Clock                                                    
            RST_DPD                                  => RST_DPD,                             
            RST_PIM                                  => RST_PIM,                             
            CLK_SYS                                  => CLK_SYS,                             
            CLK_SYSX2                                => CLK_SYSX2,                           
            CLK_SYSX3                                => CLK_SYSX3,                           
            CLK_SYSX4                                => CLK_SYSX4,                           
            CLK_SYSX5                                => CLK_SYSX5,                           
            CLK_SYSX6                                => CLK_SYSX6,                           
            CLK_SYSX8                                => CLK_SYSX8,                           
            CLK_SYSX10                               => CLK_SYSX10,                          
            CLK_SYSX12                               => CLK_SYSX12,                         
            CLK_SYSX16                               => CLK_SYSX16,                          
            CLK_SYSX20                               => CLK_SYSX20,                         

            -- PLL Lock
            INT_SYSPLL_LOCK_IN                       => INT_SYSPLL_LOCK_IN,                   

            -- DL/FB Latency
            DPD_DL_PROC_DLY_OUT                      => open, --                                             : out std_logic_vector(31 downto 0);             -- Downlink Latency Information (Unit : Clock)
            DPD_FB_PROC_DLY_OUT                      => open, --                                             : out std_logic_vector(31 downto 0);             -- Feedback Latency Information (Unit : Clock)
            DPD_UL_PROC_DLY_OUT                      => open, --                                             : out std_logic_vector(31 downto 0);             -- Uplink   Latency Information (Unit : Clock)
            
            -- TDD/FS Strobe 
            DL_BFN_STRB_IN                           => DL_BFN_STRB_IN,                         
            DL_TDD_IN                                => DL_TDD_IN,                               
            DL_SSB_STRB_IN                           => DL_SSB_STRB_IN,                          
            
            DL_BFN_STRB_OUT                          => open, --                                             : out std_logic;                                 -- Delayed Downlink 10ms Frame Sync Strobe as DL Path Latency 
            DL_TDD_OUT                               => open, --                                             : out std_logic;                                 -- Delayed Downlink TDD Strobe as DL Path Latency 
            DL_SSB_STRB_OUT                          => open, --                                             : out std_logic;                                 -- 40ms sync signal for SSB power measurement
            
            FB_BFN_STRB_IN                           => FB_BFN_STRB_IN,                       
            FB_TDD_IN                                => FB_TDD_IN,                               
            FB_SSB_STRB_IN                           => FB_SSB_STRB_IN,                        
            
            UL_BFN_STRB_IN                           => UL_BFN_STRB_IN,                          
            UL_TDD_IN                                => UL_TDD_IN,                            
            
            UL_BFN_STRB_OUT                          => open, --                                             : out std_logic;                                 -- Delayed Uplink 10ms Frame Sync Strobe as UL Path Latency 
            UL_TDD_OUT                               => open, --                                             : out std_logic;                                 -- Delayed Uplink TDD Strobe as DL Path Latency 

            DL_BCF_ENB_IN                            => DL_BCF_ENB_IN,                          
            DL_BCF_ENB_OUT                           => open, --                                             : out std_logic;

            UL_BCF_ENB_IN                            => UL_BCF_ENB_IN,                          
            UL_BCF_ENB_OUT                           => open, --                                             : out std_logic;                                                                                                                                           

            DL_GSM_120MS_IN                          => '0',    
            DL_TS16_SYNC_IN                          => '0', 
            DL_TS_SYNC_IN                            => '0', 
            DL_TS_GP_SYNC_IN                         => '0',  
                                                         
            DL_GSM_120MS_OUT                         => open, 
            DL_TS16_SYNC_OUT                         => open, 
            DL_TS_SYNC_OUT                           => open, 
            DL_TS_GP_SYNC_OUT                        => open,  
                                                         
            UL_GSM_120MS_IN                          => '0', 
            UL_TS16_SYNC_IN                          => '0', 
            UL_TS_SYNC_IN                            => '0', 
            UL_TS_GP_SYNC_IN                         => '0', 
            
            UL_GSM_120MS_OUT                         => open,  
            UL_TS16_SYNC_OUT                         => open, 
            UL_TS_SYNC_OUT                           => open, 
            UL_TS_GP_SYNC_OUT                        => open,  
            
            -- Traffic IQ
            DL_SYNC_IN                               => DL_SYNC_IN(3 downto 2),                                    
            DL_I_IN                                  => DL_I_IN(3 downto 2),                                       
            DL_Q_IN                                  => DL_Q_IN(3 downto 2),                                       
                                                                            
            DL_INTERBAND_SYNC_IN                     => DL_INTERBAND_SYNC_IN(1 downto 0),                          
            DL_INTERBAND_I_IN                        => DL_INTERBAND_I_IN(1 downto 0),                             
            DL_INTERBAND_Q_IN                        => DL_INTERBAND_Q_IN(1 downto 0),                                              

            DL_SYNC_OUT                              => DL_SYNC_OUT(3 downto 2), --                          : out std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output IQ sample valid
            DL_I_OUT                                 => DL_I_OUT(3 downto 2), --                             : out std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output I data
            DL_Q_OUT                                 => DL_Q_OUT(3 downto 2), --                             : out std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output Q data


            FB_SYNC_IN                               => FB_SYNC_IN(1 downto 1),                                       
            FB_I_EVEN_IN                             => FB_I_EVEN_IN(1 downto 1),                                          
            FB_Q_EVEN_IN                             => FB_Q_EVEN_IN(1 downto 1),                                                   
            FB_I_ODD_IN                              => FB_I_ODD_IN(1 downto 1),                                          
            FB_Q_ODD_IN                              => FB_Q_ODD_IN(1 downto 1),                                                   


            UL_SYNC_IN                               => UL_SYNC_IN(3 downto 2),                        
            UL_I_IN                                  => UL_I_IN(3 downto 2),                             
            UL_Q_IN                                  => UL_Q_IN(3 downto 2),                             

            UL_SYNC_OUT                              => UL_SYNC_OUT(3 downto 2), --                                              : out std_logic_vector( RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output IQ sample valid
            UL_I_OUT                                 => UL_I_OUT(3 downto 2), --                                              : out std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output I data
            UL_Q_OUT                                 => UL_Q_OUT(3 downto 2), --                                              : out std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output Q data

            -- Feedback Switch
            FBSW_START_TRIG_IN                       => FBSW_START_TRIG_IN,                                 
            FBSW_AUTO_MODE_DONE_IN                   => (others => '0'),                            
            FBSW_MANUAL_MODE_IN                      => FBSW_MANUAL_MODE_IN,                                
            FBSW_CNT_IN                              => FBSW_CNT_IN,                                        
            FBSW_VAL_OUT                             => open, --                                               
                                                                              
            FBSW_SC_PATH_SEL_OUT                     => FBSW_SC_PATH_SEL_OUT(1),                                
            PWR_MSR_FB_SYNC_IN                       => PWR_MSR_FB_SYNC_IN,                                 
            PWR_MSR_EN_IN                            => PWR_MSR_EN_IN,                                           

            FBSW_SSB_IND_FLAG                        => FBSW_SSB_IND_FLAG,

            -- Control & Status
            SIG_SUS_DLOFF_IN                         => SIG_SUS_DLOFF_IN(3 downto 2),                           
                                                                         
            DL_NCO_WEN_IN                            => DL_NCO_WEN_IN(3 downto 2),                              
            DL_NCO_DATA_IN                           => DL_NCO_DATA_IN(3 downto 2),                             
                                                                         
            DPD_BYPASS_IN                            => DPD_BYPASS_IN(3 downto 2),                                  
            DPD_HC_TRSHD_IN                          => DPD_HC_TRSHD_IN(3 downto 2),                            
            DPD_HC_FLAG_OUT                          => DPD_HC_FLAG_OUT(3 downto 2), --                              : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Hard-Clipping Flag
            DPD_DATT_IN                              => DPD_DATT_IN(3 downto 2),                                   
            DPD_FILTER_BYPASS_IN                     => DPD_FILTER_BYPASS_IN(3 downto 2),                           

            COEF_WREN_IN                             => COEF_WREN_IN(3 downto 2),                                             
            COEF_RDEN_IN                             => COEF_RDEN_IN(3 downto 2),                                             
            COEF_WR_DONE_IN                          => COEF_WR_DONE_IN(3 downto 2),                                          
            COEF_ADDR_IN                             => COEF_ADDR_IN,                                             
            COEF_WR_DATA_IN                          => COEF_WR_DATA_IN,                                          
            COEF_RD_DATA_OUT                         => dpd1_coef_rd_data, --                                        : out std_logic_vector(15 downto 0);             -- DPD-OutFilter Coefficient Read  Data

            DACIF_BYPASS_IN                          => DACIF_BYPASS_IN(3 downto 2),                                 
            DACIF_ON_IN                              => DACIF_ON_IN(3 downto 2),                                     
                                                                                        
            FB_NCO_WEN_IN                            => FB_NCO_WEN_IN(1 downto 1),                                            
            FB_NCO_WORD_IN                           => FB_NCO_WORD_IN(1 downto 1),                                           
                                                                                        
            FB_FILTER_BYPASS_IN                      => FB_FILTER_BYPASS_IN(1 downto 1),                                            
                                                                                        
            FB_PWR_MSR_BFN_STRB_OUT                  => open, --                                                     : out std_logic;                                 -- Feedback Power Measure Input BFN Strobe
            FB_PWR_MSR_DONE_OUT                      => FB_PWR_MSR_DONE_OUT(1 downto 1), --                          : out std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback Power Measure Done Flag
            FB_PWR_OUT                               => FB_PWR_OUT(1 downto 1), --                                   : out std_logic_array32(FB_PATH_NUM-1 downto 0); -- Power Value(Mantissa Format) at Feedback Path
             
            DL_PWR_OUT                               => DL_PWR_OUT(3 downto 2),

            FB_FWD_DATT_IN                           => FB_FWD_DATT_IN,                                             
            FB_RVS_DATT_IN                           => FB_RVS_DATT_IN,                                             
                                                                                        
            PIM_DETECTOR_ON_IN                       => PIM_DETECTOR_ON_IN(3 downto 2),                                         
            PIM_MITIGATOR_ON_IN                      => PIM_MITIGATOR_ON_IN(3 downto 2),                                        
            PIM_CFR_REF_SEL_IN                       => PIM_CFR_REF_SEL_IN(3 downto 2),                                         
                                                                                        
            PIM_PNPC_SEL_IN                          => PIM_PNPC_SEL_IN(3 downto 2),                                            
                                                        
            PIM_CORE_BYPASS_IN                       => PIM_CORE_BYPASS_IN(3 downto 2),                                         
                                                                                        
            PIM_FILTER_BYPASS_IN                     => PIM_FILTER_BYPASS_IN(3 downto 2),                                       
            PIM_FILTER_COEF_WR_EN_IN                 => PIM_FILTER_COEF_WR_EN_IN(3 downto 2),                                   
            PIM_FILTER_COEF_RD_EN_IN                 => PIM_FILTER_COEF_RD_EN_IN(3 downto 2),                                   
            PIM_FILTER_COEF_WR_DN_IN                 => PIM_FILTER_COEF_WR_DN_IN(3 downto 2),                                             
            PIM_FILTER_COEF_ADDR_IN                  => PIM_FILTER_COEF_ADDR_IN,                                   
            PIM_FILTER_COEF_WR_DATA_IN               => PIM_FILTER_COEF_WR_DATA_IN,                                 
            PIM_FILTER_COEF_RD_DATA_OUT              => dpd1_pim_coef_rd_data, --                                    : out std_logic_vector(15 downto 0);            -- PIM LPF coefficient read  data(indirect) 
                                                                                        
            PIM_NCO_WREN_IN                          => PIM_NCO_WREN_IN,                                           
            PIM_NCO_WORD_IN                          => PIM_NCO_WORD_IN,                                           
                                                                                        
            PIM_INTERBAND_DUC_GAIN_IN                => PIM_INTERBAND_DUC_GAIN_IN(3 downto 2),                    
                                                                                        
            UL_PIM_NCO_WREN_IN                       => UL_PIM_NCO_WREN_IN(1),                                        
            UL_PIM_NCO_WORD_IN                       => UL_PIM_NCO_WORD_IN(1),                                        
                                                                                        
            DPD_INFO_OUT                             => open, --                                                     : out std_logic_vector(31 downto 0);             -- DPD_TOP Information
            DPD_STRUCT_OUT                           => open, --                                                     : out std_logic_vector(31 downto 0);             -- DPD_TOP Structure Information 
            DPD_DATE_OUT                             => open, --                                                     : out std_logic_vector(31 downto 0);             -- DPD_TOP Date

            -- Dump & Test
            SC_LB_ON_IN                              => SC_LB_ON_IN,                                            
                                                                                     
            DACIF_PHTEST_ENB_IN                      => DACIF_PHTEST_ENB_IN,                                    
            DACIF_PHTEST_REF_SEL_IN                  => DACIF_PHTEST_REF_SEL_IN,                                
            DACIF_PHTEST_PATH_AB_SWAP_IN             => DACIF_PHTEST_PATH_AB_SWAP_IN,                           
            DACIF_PHTEST_PATH_REVERSE_IN             => DACIF_PHTEST_PATH_REVERSE_IN,                           
            DACIF_PHTEST_REPEAT_ENB_IN               => DACIF_PHTEST_REPEAT_ENB_IN,                             
            DACIF_PHTEST_DACIF_DEFAULT_IN            => DACIF_PHTEST_DACIF_DEFAULT_IN(3 downto 2),              
                                                                                     
            DACIF_PHTEST_OFFSET_IN                   => DACIF_PHTEST_OFFSET_IN,                                 
            DACIF_PHTEST_PERIOD_IN                   => DACIF_PHTEST_PERIOD_IN,                                 
            DACIF_PHTEST_ON_DURATION_IN              => DACIF_PHTEST_ON_DURATION_IN,                             
                                                                                     
            DBG_SIG_OUT                              => open, --                                                   : out std_logic_array32(3 downto 2);             -- For Block Debugging, Reserved Output
                                                                                     
            DUMP_POINT_SEL_STRB_IN                   => dump_point_sel_strb,                                 
            DUMP_POINT_SEL_IN                        => dpd1_dump_point_sel,                                 
            DUMP_BFN_STRB_OUT                        => dpd1_dump_bfn_strb, --                                     : out std_logic_vector( 1 downto 0);             -- Delayed 10ms Frame Sync Strobe for DUMP                 
            DUMP_DVLD_OUT                            => dpd1_dump_dvld, --                                         : out std_logic_vector( 1 downto 0);             -- Dump Sample Valid
            DUMP_DATA_OUT                            => dpd1_dump_data, --                                      : out std_logic_array32(3 downto 2)              -- Dump Sampl                           
            
			DPD_DACIF_STAGE_NUM						 => DPD_DACIF_STAGE_NUM
			);        


end arc_DPD_WRAPPER;
