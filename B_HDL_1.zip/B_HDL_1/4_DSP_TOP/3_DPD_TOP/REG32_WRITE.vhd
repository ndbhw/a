--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2011, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Writable Register (Component)                                 --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2011.11.26 (v1.0)                                             --
--              2016.10.06 (v2.0)                                             --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
--   v1.0 - initial release                                                   --
--   v2.0 - modified for bit-masking, k1340.heo (COMP_WRITE)                  --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;

entity REG32_WRITE is
generic(
    BIT_ENABLE : std_logic_vector(31 downto 0) := (others => '1');
    REG_ADDR   : std_logic_vector( 7 downto 0) := (others => '0'); -- Register address
    REG_DATA   : std_logic_vector(31 downto 0) := (others => '0')  -- Default value
    );
port(
    RST        : in  std_logic;                                    -- reset, '1': reset
    CLK        : in  std_logic;                                    -- clock

    EN         : in  std_logic;                                    -- Write enable
    ADDR       : in  std_logic_vector( 7 downto 0);                -- Input Address
    DATA_IN    : in  std_logic_vector(31 downto 0);                -- Data input
    DATA_OUT   : out std_logic_vector(31 downto 0)                 -- Data output
    );
end REG32_WRITE;

architecture arc_REG32_WRITE of REG32_WRITE is

begin

    Register_32Bits_Write : process(RST, CLK) begin
        if (RST = '1') then
            DATA_OUT <= REG_DATA; 	
        elsif (CLK'event) and (CLK = '1') then
            for I in 31 downto 0 loop
            if ((EN = '1') and (ADDR = REG_ADDR)) then
                DATA_OUT(I) <= DATA_IN(I) and BIT_ENABLE(I); 	
            end if;
            end loop;
        end if;
    end process;

end arc_REG32_WRITE;
