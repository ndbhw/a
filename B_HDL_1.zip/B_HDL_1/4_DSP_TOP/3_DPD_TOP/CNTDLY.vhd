-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name : CNTDLY 
-- Project    : CP10_42A, 3.5G KDDI Low power
-- Structure  : 

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

entity CNTDLY is
generic(
    HS_MODE    : boolean := FALSE; 

    CLK_CNTDLY : integer  -- 0 ~ 8191
    );
port(
    RST        : in  std_logic;
    CLK        : in  std_logic;
    
    SIGNAL_IN  : in  std_logic;
    
    SIGNAL_OUT : out std_logic
    );
end CNTDLY;

architecture arc_CNTDLY of CNTDLY is

constant cnt_value             : std_logic_vector(12 downto 0) := (conv_std_logic_vector(CLK_CNTDLY,            13));

constant int_cnt_value_minus_1 : natural := (CLK_CNTDLY - 1);
constant int_cnt_value_minus_6 : natural := (CLK_CNTDLY - 6);
constant int_cnt_value_minus_7 : natural := (CLK_CNTDLY - 7);

constant cnt_value_minus_6     : std_logic_vector(12 downto 0) := (conv_std_logic_vector(int_cnt_value_minus_6, 13));
constant cnt_value_minus_1     : std_logic_vector(12 downto 0) := (conv_std_logic_vector(int_cnt_value_minus_1, 13));
constant cnt_value_minus_7     : std_logic_vector(12 downto 0) := (conv_std_logic_vector(int_cnt_value_minus_7, 13));

signal cnt_value_minus_1_d1    : std_logic_vector(12 downto 0);
signal cnt_value_minus_6_d1    : std_logic_vector(12 downto 0);
signal cnt_value_minus_7_d1    : std_logic_vector(12 downto 0);

signal rpls_cnt_minus_7_pls    : std_logic;
signal fpls_cnt_minus_7_pls    : std_logic;

signal rpls_cnt_minus_1_flag   : std_logic;
signal fpls_cnt_minus_1_flag   : std_logic;

signal sig_sh                  : std_logic_vector( 2 downto 0);
signal sig_rpls                : std_logic;
signal sig_fpls                : std_logic;

signal sig_rpls_d              : std_logic;
signal sig_fpls_d              : std_logic;
signal dly_sig                 : std_logic;

signal rpls_dly_cnt            : std_logic_vector(12 downto 0);
signal fpls_dly_cnt            : std_logic_vector(12 downto 0);

signal state                   : std_logic;

begin

    G_Normal_Operation : if (HS_MODE = FALSE) generate begin

        cnt_value_minus_1_d1 <= (others => '0');   
        cnt_value_minus_7_d1 <= (others => '0'); 

        rpls_cnt_minus_1_flag <= '0';   
        fpls_cnt_minus_1_flag <= '0';   
        rpls_cnt_minus_7_pls  <= '0';   
        fpls_cnt_minus_7_pls  <= '0';   

        P_Count_Value_Clocking_NM : process(RST, CLK) begin
            if (RST = '1') then
                cnt_value_minus_6_d1 <= (others => '0'); 
            elsif (CLK'event) and (CLK = '1') then 
                cnt_value_minus_6_d1 <= cnt_value_minus_6;
            end if;
        end process;

        P_Edge_Detect_NM : process(RST, CLK) begin
            if (RST = '1') then    
                sig_sh   <= (others => '0');
                sig_rpls <= '0';
                sig_fpls <= '0';
            elsif (CLK'event) and (CLK = '1') then
                sig_sh   <= sig_sh(1 downto 0) & SIGNAL_IN;
                sig_rpls <= sig_sh(1) and (not sig_sh(2));
                sig_fpls <= (not sig_sh(1)) and sig_sh(2);
            end if;
        end process;


        P_Pulse_count_delay_NM : process(RST, CLK) begin
            if (RST = '1') then
                rpls_dly_cnt <= (others => '1');  
                fpls_dly_cnt <= (others => '1');  
            elsif (CLK'event) and (CLK = '1') then
                if (sig_rpls = '1') then               -- Rising edge pulse
                    rpls_dly_cnt <= (others => '0');   -- count init
                else
                    if (rpls_dly_cnt = cnt_value) then
                        rpls_dly_cnt <= rpls_dly_cnt;
                    else
                        rpls_dly_cnt <= rpls_dly_cnt + '1';
                    end if;
                end if;
            
                if (sig_fpls = '1') then               -- Falling edge pulse
                    fpls_dly_cnt <= (others => '0');   -- count init
                else
                    if (fpls_dly_cnt = cnt_value) then
                        fpls_dly_cnt <= fpls_dly_cnt;
                    else
                        fpls_dly_cnt <= fpls_dly_cnt + '1';
                    end if;
                end if;
            end if;
        end process;

        P_Delayed_Pulse_NM : process(RST, CLK) begin
            if (RST = '1') then
                sig_rpls_d <= '0';
                sig_fpls_d <= '0';
            elsif (CLK'event) and (CLK = '1') then
                if (rpls_dly_cnt = cnt_value_minus_6_d1) then
                    sig_rpls_d <= '1';
                else
                    sig_rpls_d <= '0';
                end if;

                if (fpls_dly_cnt = cnt_value_minus_6_d1) then
                    sig_fpls_d <= '1';
                else
                    sig_fpls_d <= '0';
                end if;
            end if;
        end process;

        P_State_Define_NM : process(RST, CLK) begin
            if (RST = '1') then
                state   <= '0';
                dly_sig <= '0'; 
            elsif (CLK'event) and (CLK = '1') then
                case (state) is
                when '0' =>
                     state <= '1';
                     if (sig_sh(1) = '0') then dly_sig <= '0';
                     else                      dly_sig <= '1';
                     end if;
                when '1' =>
                     state <= state;
                     if ((dly_sig = '0') and (sig_rpls_d = '1')) then
                          dly_sig <= '1';
                     elsif ((dly_sig = '1') and (sig_fpls_d = '1')) then
                          dly_sig <= '0';
                     else
                          dly_sig <= dly_sig;
                     end if;
                when others =>
                     state   <= state;
                     dly_sig <= dly_sig;
                end case;
            end if;
        end process;

    end generate;

    G_High_Speed_Mode : if (HS_MODE = TRUE) generate begin

        cnt_value_minus_6_d1 <= (others => '0');
	
        P_Count_Value_Clocking_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then 
                cnt_value_minus_1_d1 <= cnt_value_minus_1;   
                cnt_value_minus_7_d1 <= cnt_value_minus_7;
            end if;
        end process;

        P_Edge_Detect_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                sig_sh   <= sig_sh(1 downto 0) & SIGNAL_IN;
                sig_rpls <= sig_sh(1) and (not sig_sh(2));
                sig_fpls <= (not sig_sh(1)) and sig_sh(2);
            end if;
        end process;

        P_Count_Flag_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (sig_rpls = '1') then
                    rpls_cnt_minus_1_flag <= '0';       
                elsif (rpls_dly_cnt = cnt_value_minus_1_d1) then  
                    rpls_cnt_minus_1_flag <= '1';       
                else
                    rpls_cnt_minus_1_flag <= rpls_cnt_minus_1_flag;       
                end if;

                if (sig_fpls = '1') then
                    fpls_cnt_minus_1_flag <= '0';       
                elsif (fpls_dly_cnt = cnt_value_minus_1_d1) then  
                    fpls_cnt_minus_1_flag <= '1';       
                else
                    fpls_cnt_minus_1_flag <= fpls_cnt_minus_1_flag;       
                end if;

                if (rpls_dly_cnt = cnt_value_minus_7_d1) then  
                    rpls_cnt_minus_7_pls  <= '1';
                else 
                    rpls_cnt_minus_7_pls  <= '0';
                end if;

                if (fpls_dly_cnt = cnt_value_minus_7_d1) then  
                    fpls_cnt_minus_7_pls  <= '1';
                else 
                    fpls_cnt_minus_7_pls  <= '0';
                end if;
            end if;
        end process;

        P_Pulse_count_delay_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (RST = '1') then
                    rpls_dly_cnt <= (others => '1');  
                    fpls_dly_cnt <= (others => '1');  
                else
                    if (sig_rpls = '1') then               -- Rising edge pulse
                        rpls_dly_cnt <= (others => '0');   -- count init
                    else
                        if (rpls_cnt_minus_1_flag = '1') then
                            rpls_dly_cnt <= rpls_dly_cnt;
                        else
                            rpls_dly_cnt <= rpls_dly_cnt + '1';
                        end if;
                    end if;
            
                    if (sig_fpls = '1') then               -- Falling edge pulse
                        fpls_dly_cnt <= (others => '0');   -- count init
                    else
                        if (fpls_cnt_minus_1_flag = '1') then
                            fpls_dly_cnt <= fpls_dly_cnt;
                        else
                            fpls_dly_cnt <= fpls_dly_cnt + '1';
                        end if;
                    end if;
                end if;
            end if;
        end process;

        P_Delayed_Pulse_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (rpls_cnt_minus_7_pls = '1') then
                    sig_rpls_d <= '1';
                else
                    sig_rpls_d <= '0';
                end if;

                if (fpls_cnt_minus_7_pls = '1') then
                    sig_fpls_d <= '1';
                else
                    sig_fpls_d <= '0';
                end if;
            end if;
        end process;

        P_State_Define_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (RST = '1') then
                    state   <= '0';
                    dly_sig <= '0'; 
                else
                    case (state) is
                        when '0' =>
                             state <= '1';
                             if (sig_sh(1) = '0') then dly_sig <= '0';
                             else                      dly_sig <= '1';
                             end if;
                        when '1' =>
                             state <= state;
                             if ((dly_sig = '0') and (sig_rpls_d = '1')) then
                                  dly_sig <= '1';
                             elsif ((dly_sig = '1') and (sig_fpls_d = '1')) then
                                  dly_sig <= '0';
                             else
                                  dly_sig <= dly_sig;
                             end if;
                        when others =>
                             state   <= state;
                             dly_sig <= dly_sig;
                    end case;
                end if;
            end if;
        end process;
    end generate;

    SIGNAL_OUT <= dly_sig;

end arc_CNTDLY;
