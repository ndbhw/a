library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity DPD_3D_LUT32_CONFIG is
generic(
    DEVICE                   : string  := "ULTRASCALE";
    HS_MODE                  : boolean :=       FALSE ;
    TX_ANT_NUM               : natural :=           4 ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_RAM_NUM              : natural :=          32 ;
    DPD_TAP_NUM              : natural :=          14
    );
port(
    RST                      : in  std_logic;
    CLK                      : in  std_logic;
   
    LUT_DATA_VLD             : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    MAG9                     : in  std_logic_array9( TX_ANT_NUM-1 downto 0);
    MAG15                    : in  std_logic_array15(TX_ANT_NUM-1 downto 0);
    LUT_ADDR                 : out std_logic_array32_array9( TX_ANT_NUM-1 downto 0);

    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);
    LUT_RDATA_IN             : in  std_logic_array32_array32(TX_ANT_NUM downto 0);

    LUT_ADD_I                : out std_logic_array13_array27(TX_ANT_NUM-1 downto 0);
    LUT_ADD_Q                : out std_logic_array13_array27(TX_ANT_NUM-1 downto 0)
    );
end DPD_3D_LUT32_CONFIG;

architecture arc_DPD_3D_LUT32_CONFIG of DPD_3D_LUT32_CONFIG is

-- Latency 8
component ADD8 is
generic(
    HS_MODE      : boolean := FALSE;
    BITWIDTH     : natural := 16
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
  
    DATA0_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA1_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA2_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA3_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    
    DATA4_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA5_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA6_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);
    DATA7_IN     : in  std_logic_vector(BITWIDTH-1 downto 0);

    DATA_OUT     : out std_logic_vector(BITWIDTH+2 downto 0)
    );
end component;

component SRL16E_DLY is
generic(
    DEVICE       : string  := "ULTRASCALE";
    HS_MODE      : boolean :=       FALSE ;

    BIT_WIDTH    : natural;            -- 2 to 64
    DELAY_NUM    : natural
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;

    DATA_IN      : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT     : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end component;

component DSP48E1_MULTIPLIER is
-- Latency 4 clocks
generic(
    AIN_BITWIDTH : natural; -- AIN bitwidth : 0 to 29
    BIN_BITWIDTH : natural; -- BIN bitwidth : 0 to 17
    RND_EN       : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT      : natural; -- Rounding bit  
    OUTPUT_WIDTH : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
    AIN          : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
    BIN          : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
    P            : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
    );
end component;

component DSP48E2_MULTIPLIER is
generic(
    AIN_BITWIDTH : natural; -- AIN bitwidth : 0 to 29
    BIN_BITWIDTH : natural; -- BIN bitwidth : 0 to 17
    RND_EN       : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT      : natural; -- Rounding bit  
    OUTPUT_WIDTH : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
    AIN          : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
    BIN          : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
    P            : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
    );
end component;

signal dpd_lut_output_switch : std_logic_array4(TX_ANT_NUM-1 downto 0);
signal lut_rdata_i           : std_logic_array32_array16(TX_ANT_NUM downto 0);
signal lut_rdata_q           : std_logic_array32_array16(TX_ANT_NUM downto 0);

signal lut_rdata_sw_i        : std_logic_array32_array16(TX_ANT_NUM-1 downto 0);
signal lut_rdata_sw_q        : std_logic_array32_array16(TX_ANT_NUM-1 downto 0);

signal mag9_sh               : std_logic_array14_array9(TX_ANT_NUM-1 downto 0);
signal magnitude9            : std_logic_array13_array9(TX_ANT_NUM-1 downto 0);

signal mag15_sh              : std_logic_array8_array15(TX_ANT_NUM-1 downto 0);

signal mag1_mp0              : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal lut29_mp0_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal lut29_mp0_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal mag1_lut29_mp0_i      : std_logic_array27(TX_ANT_NUM-1 downto 0);
signal mag1_lut29_mp0_q      : std_logic_array27(TX_ANT_NUM-1 downto 0);

signal mag0_mp0              : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal lut30_mp0_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal lut30_mp0_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal mag0_lut30_mp0_i      : std_logic_array27(TX_ANT_NUM-1 downto 0);
signal mag0_lut30_mp0_q      : std_logic_array27(TX_ANT_NUM-1 downto 0);


signal mag2_mp1              : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal lut31_mp1_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal lut31_mp1_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal mag2_lut31_mp1_i      : std_logic_array27(TX_ANT_NUM-1 downto 0);
signal mag2_lut31_mp1_q      : std_logic_array27(TX_ANT_NUM-1 downto 0);

signal mag1_lut29_mp0_i_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);
signal mag1_lut29_mp0_q_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);

signal mag0_lut30_mp0_i_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);
signal mag0_lut30_mp0_q_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);

signal mag2_lut31_mp1_i_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);
signal mag2_lut31_mp1_q_d    : std_logic_array27(TX_ANT_NUM-1 downto 0);


signal lut_rdata_sw_i_d      : std_logic_array29_array16(TX_ANT_NUM-1 downto 0);
signal lut_rdata_sw_q_d      : std_logic_array29_array16(TX_ANT_NUM-1 downto 0);

signal lut_rdata_sw_i_ls     : std_logic_array29_array27(TX_ANT_NUM-1 downto 0);
signal lut_rdata_sw_q_ls     : std_logic_array29_array27(TX_ANT_NUM-1 downto 0);

signal lut_mpa4_i            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal lut_mpa4_q            : std_logic_array27(TX_ANT_NUM-1 downto 0);            

signal lut_mpa3_i            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal lut_mpa3_q            : std_logic_array27(TX_ANT_NUM-1 downto 0);            

signal lut_mpa2_i            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
signal lut_mpa2_q            : std_logic_array30(TX_ANT_NUM-1 downto 0);            

signal lut_mpa1_i            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
signal lut_mpa1_q            : std_logic_array30(TX_ANT_NUM-1 downto 0);            

signal lut_mp00_i            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
signal lut_mp00_q            : std_logic_array30(TX_ANT_NUM-1 downto 0);            

signal lut_mp01_i            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
signal lut_mp01_q            : std_logic_array30(TX_ANT_NUM-1 downto 0);            

signal lut_mp02_i            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
signal lut_mp02_q            : std_logic_array30(TX_ANT_NUM-1 downto 0);            

signal lut_mp03_i            : std_logic_array30(TX_ANT_NUM-1 downto 0);            
signal lut_mp03_q            : std_logic_array30(TX_ANT_NUM-1 downto 0);            

signal lut_mp04_i            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal lut_mp04_q            : std_logic_array27(TX_ANT_NUM-1 downto 0);            

signal lut_mp05_i            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal lut_mp05_q            : std_logic_array27(TX_ANT_NUM-1 downto 0);            

signal lut_mp06_i            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal lut_mp06_q            : std_logic_array27(TX_ANT_NUM-1 downto 0);            

signal lut_mp07_i            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal lut_mp07_q            : std_logic_array27(TX_ANT_NUM-1 downto 0);            

signal lut_mp08_i            : std_logic_array27(TX_ANT_NUM-1 downto 0);            
signal lut_mp08_q            : std_logic_array27(TX_ANT_NUM-1 downto 0);            


attribute KEEP : string;
attribute KEEP of dpd_lut_output_switch : signal is "TRUE";
attribute KEEP of lut_rdata_sw_i        : signal is "TRUE";
attribute KEEP of lut_rdata_sw_q        : signal is "TRUE";

attribute MAX_FANOUT : integer;
attribute MAX_FANOUT of dpd_lut_output_switch : signal is ternary_func(HS_MODE=TRUE, 20, 2000);

begin

    -- LUT Read Data Align
    G_LUT_RDATA_Assign_TX_ANT : for I in 0 to (TX_ANT_NUM) generate begin
        G_LUT_RDATA_Assign_LUT_RAM : for J in 0 to (LUT_RAM_NUM-1) generate begin
            lut_rdata_i(I)(J) <= LUT_RDATA_IN(I)(J)(31 downto 16); 
            lut_rdata_q(I)(J) <= LUT_RDATA_IN(I)(J)(15 downto  0); 
        end generate;
    end generate;

    G_LUT_Non_Optimized : if (LUT_OPTIMIZED = FALSE) generate begin            
        P_LUT_Rdata_Clocking_Normal_Operation : if (HS_MODE = FALSE) generate begin
            P_LUT_Rdata_Clocking_NM : process(RST, CLK) begin
                if (RST = '1') then
                    lut_rdata_sw_i <= (others => (others => (others => '0')));
                    lut_rdata_sw_q <= (others => (others => (others => '0')));
                elsif (CLK'event) and (CLK = '1') then
                    lut_rdata_sw_i <= lut_rdata_i(TX_ANT_NUM-1 downto 0);
                    lut_rdata_sw_q <= lut_rdata_q(TX_ANT_NUM-1 downto 0);
                end if;
            end process;
        end generate;

        P_LUT_Rdata_Clocking_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
            P_LUT_Rdata_Clocking_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    lut_rdata_sw_i <= lut_rdata_i(TX_ANT_NUM-1 downto 0);
                    lut_rdata_sw_q <= lut_rdata_q(TX_ANT_NUM-1 downto 0);
                end if;
            end process;
        end generate;

        dpd_lut_output_switch <= (others => (others => '0')); 
    end generate;

    G_LUT_Optimized_Switch : if (LUT_OPTIMIZED = TRUE) generate begin            
        G_LUT_RDATA_SW : for I in 0 to (TX_ANT_NUM-1) generate begin
            G_LUT_RDATA_SW_Normal_Operation : if (HS_MODE = FALSE) generate begin
                P_LUT_RDATA_SW_NM : process(RST, CLK) begin
                    if (RST = '1') then
                        dpd_lut_output_switch(I) <= (others => '0');
                    elsif (CLK'event) and (CLK = '1') then 
                        dpd_lut_output_switch(I) <= DPD_LUT_OUTPUT_SWITCH_IN(4*I+3 downto 4*I);
                    end if;
                end process;
            end generate;

            G_LUT_RDATA_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_LUT_RDATA_SW_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then 
                        dpd_lut_output_switch(I) <= DPD_LUT_OUTPUT_SWITCH_IN(4*I+3 downto 4*I);
                    end if;
                end process;
            end generate;
        end generate;

        G_LUT_Rdata_Switching_ANT2 : if (TX_ANT_NUM = 2) generate begin
            G_LUT_RDATA_SW_ANT2_Normal_Operation : if (HS_MODE = FALSE) generate begin
                P_LUT_Rdata_2Path_Switch_NM : process(RST, CLK) begin
                    if (RST = '1') then
                        lut_rdata_sw_i <= (others => (others => (others => '0')));
                        lut_rdata_sw_q <= (others => (others => (others => '0')));
                    elsif (CLK'event) and (CLK = '1') then
                        case (dpd_lut_output_switch(0)) is 
                            when x"0"   => lut_rdata_sw_i(0) <= lut_rdata_i(0);              lut_rdata_sw_q(0) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(0) <= lut_rdata_i(1);              lut_rdata_sw_q(0) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(0) <= lut_rdata_i(2);              lut_rdata_sw_q(0) <= lut_rdata_q(2);
                            when others => lut_rdata_sw_i(0) <= (others => (others => '0')); lut_rdata_sw_q(0) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(1)) is 
                            when x"0"   => lut_rdata_sw_i(1) <= lut_rdata_i(0);              lut_rdata_sw_q(1) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(1) <= lut_rdata_i(1);              lut_rdata_sw_q(1) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(1) <= lut_rdata_i(2);              lut_rdata_sw_q(1) <= lut_rdata_q(2);
                            when others => lut_rdata_sw_i(1) <= (others => (others => '0')); lut_rdata_sw_q(1) <= (others => (others => '0'));
                        end case;
                    end if;
                end process;
            end generate;

            G_LUT_RDATA_SW_ANT2_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_LUT_Rdata_2Path_Switch_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (dpd_lut_output_switch(0)) is 
                            when x"0"   => lut_rdata_sw_i(0) <= lut_rdata_i(0);              lut_rdata_sw_q(0) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(0) <= lut_rdata_i(1);              lut_rdata_sw_q(0) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(0) <= lut_rdata_i(2);              lut_rdata_sw_q(0) <= lut_rdata_q(2);
                            when others => lut_rdata_sw_i(0) <= (others => (others => '0')); lut_rdata_sw_q(0) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(1)) is 
                            when x"0"   => lut_rdata_sw_i(1) <= lut_rdata_i(0);              lut_rdata_sw_q(1) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(1) <= lut_rdata_i(1);              lut_rdata_sw_q(1) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(1) <= lut_rdata_i(2);              lut_rdata_sw_q(1) <= lut_rdata_q(2);
                            when others => lut_rdata_sw_i(1) <= (others => (others => '0')); lut_rdata_sw_q(1) <= (others => (others => '0'));
                        end case;
                    end if;
                end process;
            end generate;
        end generate;

        G_LUT_Rdata_Switching_ANT4 : if (TX_ANT_NUM = 4) generate begin
            G_LUT_RDATA_SW_ANT4_Normal_Operation : if (HS_MODE = FALSE) generate begin
                P_LUT_Rdata_4Path_Switch_NM : process(RST, CLK) begin
                    if (RST = '1') then
                        lut_rdata_sw_i <= (others => (others => (others => '0')));
                        lut_rdata_sw_q <= (others => (others => (others => '0')));
                    elsif (CLK'event) and (CLK = '1') then
                        case (dpd_lut_output_switch(0)) is 
                            when x"0"   => lut_rdata_sw_i(0) <= lut_rdata_i(0);              lut_rdata_sw_q(0) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(0) <= lut_rdata_i(1);              lut_rdata_sw_q(0) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(0) <= lut_rdata_i(2);              lut_rdata_sw_q(0) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(0) <= lut_rdata_i(3);              lut_rdata_sw_q(0) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(0) <= lut_rdata_i(4);              lut_rdata_sw_q(0) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(0) <= (others => (others => '0')); lut_rdata_sw_q(0) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(1)) is 
                            when x"0"   => lut_rdata_sw_i(1) <= lut_rdata_i(0);              lut_rdata_sw_q(1) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(1) <= lut_rdata_i(1);              lut_rdata_sw_q(1) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(1) <= lut_rdata_i(2);              lut_rdata_sw_q(1) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(1) <= lut_rdata_i(3);              lut_rdata_sw_q(1) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(1) <= lut_rdata_i(4);              lut_rdata_sw_q(1) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(1) <= (others => (others => '0')); lut_rdata_sw_q(1) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(2)) is 
                            when x"0"   => lut_rdata_sw_i(2) <= lut_rdata_i(0);              lut_rdata_sw_q(2) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(2) <= lut_rdata_i(1);              lut_rdata_sw_q(2) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(2) <= lut_rdata_i(2);              lut_rdata_sw_q(2) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(2) <= lut_rdata_i(3);              lut_rdata_sw_q(2) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(2) <= lut_rdata_i(4);              lut_rdata_sw_q(2) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(2) <= (others => (others => '0')); lut_rdata_sw_q(2) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(3)) is 
                            when x"0"   => lut_rdata_sw_i(3) <= lut_rdata_i(0);              lut_rdata_sw_q(3) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(3) <= lut_rdata_i(1);              lut_rdata_sw_q(3) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(3) <= lut_rdata_i(2);              lut_rdata_sw_q(3) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(3) <= lut_rdata_i(3);              lut_rdata_sw_q(3) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(3) <= lut_rdata_i(4);              lut_rdata_sw_q(3) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(3) <= (others => (others => '0')); lut_rdata_sw_q(3) <= (others => (others => '0'));
                        end case;
                    end if;
                end process;
            end generate;

            G_LUT_RDATA_SW_ANT4_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_LUT_Rdata_4Path_Switch_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (dpd_lut_output_switch(0)) is 
                            when x"0"   => lut_rdata_sw_i(0) <= lut_rdata_i(0);              lut_rdata_sw_q(0) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(0) <= lut_rdata_i(1);              lut_rdata_sw_q(0) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(0) <= lut_rdata_i(2);              lut_rdata_sw_q(0) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(0) <= lut_rdata_i(3);              lut_rdata_sw_q(0) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(0) <= lut_rdata_i(4);              lut_rdata_sw_q(0) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(0) <= (others => (others => '0')); lut_rdata_sw_q(0) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(1)) is 
                            when x"0"   => lut_rdata_sw_i(1) <= lut_rdata_i(0);              lut_rdata_sw_q(1) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(1) <= lut_rdata_i(1);              lut_rdata_sw_q(1) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(1) <= lut_rdata_i(2);              lut_rdata_sw_q(1) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(1) <= lut_rdata_i(3);              lut_rdata_sw_q(1) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(1) <= lut_rdata_i(4);              lut_rdata_sw_q(1) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(1) <= (others => (others => '0')); lut_rdata_sw_q(1) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(2)) is 
                            when x"0"   => lut_rdata_sw_i(2) <= lut_rdata_i(0);              lut_rdata_sw_q(2) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(2) <= lut_rdata_i(1);              lut_rdata_sw_q(2) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(2) <= lut_rdata_i(2);              lut_rdata_sw_q(2) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(2) <= lut_rdata_i(3);              lut_rdata_sw_q(2) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(2) <= lut_rdata_i(4);              lut_rdata_sw_q(2) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(2) <= (others => (others => '0')); lut_rdata_sw_q(2) <= (others => (others => '0'));
                        end case;

                        case (dpd_lut_output_switch(3)) is 
                            when x"0"   => lut_rdata_sw_i(3) <= lut_rdata_i(0);              lut_rdata_sw_q(3) <= lut_rdata_q(0);
                            when x"1"   => lut_rdata_sw_i(3) <= lut_rdata_i(1);              lut_rdata_sw_q(3) <= lut_rdata_q(1);
                            when x"2"   => lut_rdata_sw_i(3) <= lut_rdata_i(2);              lut_rdata_sw_q(3) <= lut_rdata_q(2);
                            when x"3"   => lut_rdata_sw_i(3) <= lut_rdata_i(3);              lut_rdata_sw_q(3) <= lut_rdata_q(3);
                            when x"4"   => lut_rdata_sw_i(3) <= lut_rdata_i(4);              lut_rdata_sw_q(3) <= lut_rdata_q(4);
                            when others => lut_rdata_sw_i(3) <= (others => (others => '0')); lut_rdata_sw_q(3) <= (others => (others => '0'));
                        end case;
                    end if;
                end process;
            end generate;
        end generate;
    end generate;

    G_TX_ANT : for I in 0 to (TX_ANT_NUM-1) generate begin

        mag9_sh(I)(0) <= MAG9(I);

        G_Magnitude_time_shift : for J in 0 to (DPD_TAP_NUM-1) generate begin 
            G_Normal_Operation : if (HS_MODE = FALSE) generate begin
                P_Magnitude_Time_Shift_NM : process(RST, CLK) begin
                    if (RST = '1') then
                        mag9_sh(I)(J+1) <= (others => '0');
                    elsif (CLK'event) and (CLK = '1') then
                        if (LUT_DATA_VLD(I) = '1') then
                            mag9_sh(I)(J+1) <= mag9_sh(I)(J);
                        else
                            mag9_sh(I)(J+1) <= mag9_sh(I)(J+1);
                        end if;
                    end if;
                end process;
            end generate;

            G_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                P_Magnitude_Time_Shift_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        mag9_sh(I)(J+1) <= mag9_sh(I)(J);
                    end if;
                end process;
            end generate;

        end generate;

        magnitude9(I) <= mag9_sh(I)(DPD_TAP_NUM downto 1);

        -- [Magnitude Index Mapping]==================================================== --
        --                                                                               --
        -- Can Modify according to DPD_CORE eqaution, Always need to check!!             --
        --                                                                               --
        -- ============================================================================= -- 

        -- LUT address decoding  
        -- magnitude9(0)  --> |x[n+4]|
        -- magnitude9(1)  --> |x[n+3]|
        -- magnitude9(2)  --> |x[n+2]|
        -- magnitude9(3)  --> |x[n+1]|
        -- magnitude9(4)  --> |x[n-0]|
        -- magnitude9(5)  --> |x[n-1]|
        -- magnitude9(6)  --> |x[n-2]|
        -- magnitude9(7)  --> |x[n-3]|
        -- magnitude9(8)  --> |x[n-4]|
        -- magnitude9(9)  --> |x[n-5]|
        -- magnitude9(10) --> |x[n-6]|
        -- magnitude9(11) --> |x[n-7]|
        -- magnitude9(12) --> |x[n-8]|

        -- LUT address Encoding  
        G_LUT_Address_Encoding_Normal_Operation : if (HS_MODE = FALSE) generate begin
	    P_LUT_Address_Encoding_NM : process(RST, CLK) begin
                if (RST = '1') then
                    LUT_ADDR(I) <= (others => (others =>'0'));
                elsif (CLK'event) and (CLK = '1') then
                    LUT_ADDR(I)( 0) <= magnitude9(I)( 4); -- MP0 , |x[n-0]|
                    LUT_ADDR(I)( 1) <= magnitude9(I)( 5); -- MP1 , |x[n-1]|
                    LUT_ADDR(I)( 2) <= magnitude9(I)( 6); -- MP2 , |x[n-2]|
                    LUT_ADDR(I)( 3) <= magnitude9(I)( 7); -- MP3 , |x[n-3]|
                    LUT_ADDR(I)( 4) <= magnitude9(I)( 8); -- MP4 , |x[n-4]|
                    LUT_ADDR(I)( 5) <= magnitude9(I)( 9); -- MP5 , |x[n-5]|
                    LUT_ADDR(I)( 6) <= magnitude9(I)(10); -- MP6 , |x[n-6]|
                    LUT_ADDR(I)( 7) <= magnitude9(I)(11); -- MP7 , |x[n-7]|
                    LUT_ADDR(I)( 8) <= magnitude9(I)(12); -- MP8 , |x[n-8]|
                    LUT_ADDR(I)( 9) <= magnitude9(I)( 3); -- MPA1, |x[n+1]|
                    LUT_ADDR(I)(10) <= magnitude9(I)( 2); -- MPA2, |x[n+2]|
                    LUT_ADDR(I)(11) <= magnitude9(I)( 1); -- MPA3, |x[n+3]|
                    LUT_ADDR(I)(12) <= magnitude9(I)( 0); -- MPA4, |x[n+4]|
                    LUT_ADDR(I)(13) <= magnitude9(I)( 5); -- MP0 , |x[n-1]|
                    LUT_ADDR(I)(14) <= magnitude9(I)( 6); -- MP0 , |x[n-2]|
                    LUT_ADDR(I)(15) <= magnitude9(I)( 7); -- MP0 , |x[n-3]|
                    LUT_ADDR(I)(16) <= magnitude9(I)( 3); -- MP0 , |x[n+1]|
                    LUT_ADDR(I)(17) <= magnitude9(I)( 2); -- MP0 , |x[n+2]|
                    LUT_ADDR(I)(18) <= magnitude9(I)( 4); -- MP1 , |x[n-0]|
                    LUT_ADDR(I)(19) <= magnitude9(I)( 6); -- MP1 , |x[n-2]|
                    LUT_ADDR(I)(20) <= magnitude9(I)( 4); -- MP2 , |x[n-0]|
                    LUT_ADDR(I)(21) <= magnitude9(I)( 5); -- MP2 , |x[n-1]|
                    LUT_ADDR(I)(22) <= magnitude9(I)( 7); -- MP2 , |x[n-3]|
                    LUT_ADDR(I)(23) <= magnitude9(I)( 4); -- MP3 , |x[n-0]|
                    LUT_ADDR(I)(24) <= magnitude9(I)( 6); -- MP3 , |x[n-2]|
                    LUT_ADDR(I)(25) <= magnitude9(I)( 2); -- MPA1, |x[n+2]|
                    LUT_ADDR(I)(26) <= magnitude9(I)( 4); -- MPA1, |x[n-0]|
                    LUT_ADDR(I)(27) <= magnitude9(I)( 3); -- MPA2, |x[n+1]|
                    LUT_ADDR(I)(28) <= magnitude9(I)( 4); -- MPA2, |x[n-0]|
                    LUT_ADDR(I)(29) <= magnitude9(I)( 4); -- MP0 , |x[n-0]|
                    LUT_ADDR(I)(30) <= magnitude9(I)( 5); -- MP2 , |x[n-1]|
                    LUT_ADDR(I)(31) <= magnitude9(I)( 5); -- MP2 , |x[n-1]|
                end if;
            end process;
        end generate;

        G_LUT_Address_Encoding_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
	    P_LUT_Address_Encoding_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    LUT_ADDR(I)( 0) <= magnitude9(I)( 4); -- MP0 , |x[n-0]|
                    LUT_ADDR(I)( 1) <= magnitude9(I)( 5); -- MP1 , |x[n-1]|
                    LUT_ADDR(I)( 2) <= magnitude9(I)( 6); -- MP2 , |x[n-2]|
                    LUT_ADDR(I)( 3) <= magnitude9(I)( 7); -- MP3 , |x[n-3]|
                    LUT_ADDR(I)( 4) <= magnitude9(I)( 8); -- MP4 , |x[n-4]|
                    LUT_ADDR(I)( 5) <= magnitude9(I)( 9); -- MP5 , |x[n-5]|
                    LUT_ADDR(I)( 6) <= magnitude9(I)(10); -- MP6 , |x[n-6]|
                    LUT_ADDR(I)( 7) <= magnitude9(I)(11); -- MP7 , |x[n-7]|
                    LUT_ADDR(I)( 8) <= magnitude9(I)(12); -- MP8 , |x[n-8]|
                    LUT_ADDR(I)( 9) <= magnitude9(I)( 3); -- MPA1, |x[n+1]|
                    LUT_ADDR(I)(10) <= magnitude9(I)( 2); -- MPA2, |x[n+2]|
                    LUT_ADDR(I)(11) <= magnitude9(I)( 1); -- MPA3, |x[n+3]|
                    LUT_ADDR(I)(12) <= magnitude9(I)( 0); -- MPA4, |x[n+4]|
                    LUT_ADDR(I)(13) <= magnitude9(I)( 5); -- MP0 , |x[n-1]|
                    LUT_ADDR(I)(14) <= magnitude9(I)( 6); -- MP0 , |x[n-2]|
                    LUT_ADDR(I)(15) <= magnitude9(I)( 7); -- MP0 , |x[n-3]|
                    LUT_ADDR(I)(16) <= magnitude9(I)( 3); -- MP0 , |x[n+1]|
                    LUT_ADDR(I)(17) <= magnitude9(I)( 2); -- MP0 , |x[n+2]|
                    LUT_ADDR(I)(18) <= magnitude9(I)( 4); -- MP1 , |x[n-0]|
                    LUT_ADDR(I)(19) <= magnitude9(I)( 6); -- MP1 , |x[n-2]|
                    LUT_ADDR(I)(20) <= magnitude9(I)( 4); -- MP2 , |x[n-0]|
                    LUT_ADDR(I)(21) <= magnitude9(I)( 5); -- MP2 , |x[n-1]|
                    LUT_ADDR(I)(22) <= magnitude9(I)( 7); -- MP2 , |x[n-3]|
                    LUT_ADDR(I)(23) <= magnitude9(I)( 4); -- MP3 , |x[n-0]|
                    LUT_ADDR(I)(24) <= magnitude9(I)( 6); -- MP3 , |x[n-2]|
                    LUT_ADDR(I)(25) <= magnitude9(I)( 2); -- MPA1, |x[n+2]|
                    LUT_ADDR(I)(26) <= magnitude9(I)( 4); -- MPA1, |x[n-0]|
                    LUT_ADDR(I)(27) <= magnitude9(I)( 3); -- MPA2, |x[n+1]|
                    LUT_ADDR(I)(28) <= magnitude9(I)( 4); -- MPA2, |x[n-0]|
                    LUT_ADDR(I)(29) <= magnitude9(I)( 4); -- MP0 , |x[n-0]|
                    LUT_ADDR(I)(30) <= magnitude9(I)( 5); -- MP2 , |x[n-1]|
                    LUT_ADDR(I)(31) <= magnitude9(I)( 5); -- MP2 , |x[n-1]|
                end if;
            end process;
        end generate;

        -- [Summation Diagonal/Off-Diagonal Term]======================================= --
        --                                                                               --
        -- Can Modify according to DPD_CORE eqaution, Always need to check!!             --
        --                                                                               --
        -- ============================================================================= -- 
        -- MPA4, x[n+4] * sum(LUT12|x[n+4]|) 
        -- MPA3, x[n+3] * sum(LUT11|x[n+3]|) 
        -- MPA2, x[n+2] * sum(LUT10|x[n+2]| + LUT27|x[n+1]| + LUT28|x[n-0]|)  
        -- MPA1, x[n+1] * sum(LUT25|x[n+2]| + LUT09|x[n+1]| + LUT26|x[n-0]|) 
        -- MP0 , x[n-0] * sum(LUT17|x[n+2]| + LUT16|x[n+1]| + LUT00|x[n-0]| + LUT13|x[n-1]| + LUT14|x[n-2]| + LUT15|x[n-3]| + |x[n-1]|*LUT29|x[n-0]| + |x[n-0]|*LUT30|x[n-1]|) 
        -- MP1 , x[n-1] * sum(LUT18|x[n-0]| + LUT01|x[n-1]| + LUT19|x[n-2]| + |x[n-2]|*LUT31|x[n-1]|)
        -- MP2 , x[n-2] * sum(LUT20|x[n-0]| + LUT21|x[n-1]| + LUT02|x[n-2]| + LUT22|x[n-3]|) 
        -- MP3 , x[n-3] * sum(LUT23|x[n-0]| + LUT24|x[n-2]| + LUT03|x[n-3]|)
        -- MP4 , x[n-4] * sum(LUT04|x[n-4]|)
        -- MP5 , x[n-5] * sum(LUT05|x[n-5]|)
        -- MP6 , x[n-6] * sum(LUT06|x[n-6]|)
        -- MP7 , x[n-7] * sum(LUT07|x[n-7]|)
        -- MP8 , x[n-8] * sum(LUT08|x[n-8]|)

        -- 3-Dimension Processing
        -- MAG15 LUT Latency Compensation
        U_LUT_Latency_MAG15 : SRL16E_DLY generic map(DEVICE, HS_MODE, 15, 9) port map (RST, CLK, MAG15(I), mag15_sh(I)(0));

        G_MAG15_Shift : for J in 0 to 6 generate begin 
            P_MAG15_Shift : process(RST, CLK) begin
                if (RST = '1') then
                    mag15_sh(I)(J+1) <= (others => '0');
                elsif (CLK'event) and (CLK = '1') then
                    if (LUT_DATA_VLD(I) = '1') then
                        mag15_sh(I)(J+1) <= mag15_sh(I)(J);
                    else
                        mag15_sh(I)(J+1) <= mag15_sh(I)(J+1);
                    end if;
                end if;
            end process;
        end generate;

        -- mag15_sh(1)  --> |x[n+4]|
        -- mag15_sh(2)  --> |x[n+3]|
        -- mag15_sh(3)  --> |x[n+2]|
        -- mag15_sh(4)  --> |x[n+1]|
        -- mag15_sh(5)  --> |x[n-0]|
        -- mag15_sh(6)  --> |x[n-1]|
        -- mag15_sh(7)  --> |x[n-2]|

        -- MP0 , |x[n-1]|*LUT29|x[n-0]| 
        -- MP0 , |x[n-0]|*LUT30|x[n-1]|) 

        -- mag15_sh(5)*LUT29
        mag1_mp0(I)    <= '0'&mag15_sh(I)(5);

        lut29_mp0_i(I) <= lut_rdata_sw_i(I)(29);
        lut29_mp0_q(I) <= lut_rdata_sw_q(I)(29);

        -- mag15_sh(4)*LUT30
        mag0_mp0(I)    <= '0'&mag15_sh(I)(4);

        lut30_mp0_i(I) <= lut_rdata_sw_i(I)(30);
        lut30_mp0_q(I) <= lut_rdata_sw_q(I)(30);

        -- MP1 , |x[n-2]|*LUT31|x[n-1]|)
        mag2_mp1(I) <= '0'&mag15_sh(I)(7);

        lut31_mp1_i(I) <= lut_rdata_sw_i(I)(31);
        lut31_mp1_q(I) <= lut_rdata_sw_q(I)(31);

        G_7Series_Multiplier : if (DEVICE = "7SERIES") generate begin
            U_7S_3D_MP0_MAG1_LUT29_I : DSP48E1_MULTIPLIER generic map(16, 16, TRUE, 4, 27) port map(RST, CLK, mag1_mp0(I), lut29_mp0_i(I), mag1_lut29_mp0_i(I));  
            U_7S_3D_MP0_MAG1_LUT29_Q : DSP48E1_MULTIPLIER generic map(16, 16, TRUE, 4, 27) port map(RST, CLK, mag1_mp0(I), lut29_mp0_q(I), mag1_lut29_mp0_q(I));  

            U_7S_3D_MP0_MAG0_LUT30_I : DSP48E1_MULTIPLIER generic map(16, 16, TRUE, 4, 27) port map(RST, CLK, mag0_mp0(I), lut30_mp0_i(I), mag0_lut30_mp0_i(I));  
            U_7S_3D_MP0_MAG0_LUT30_Q : DSP48E1_MULTIPLIER generic map(16, 16, TRUE, 4, 27) port map(RST, CLK, mag0_mp0(I), lut30_mp0_q(I), mag0_lut30_mp0_q(I));  

            U_7S_3D_MP1_MAG2_LUT31_I : DSP48E1_MULTIPLIER generic map(16, 16, TRUE, 4, 27) port map(RST, CLK, mag2_mp1(I), lut31_mp1_i(I), mag2_lut31_mp1_i(I));  
            U_7S_3D_MP1_MAG2_LUT31_Q : DSP48E1_MULTIPLIER generic map(16, 16, TRUE, 4, 27) port map(RST, CLK, mag2_mp1(I), lut31_mp1_q(I), mag2_lut31_mp1_q(I));  
        end generate;                                                                                           
                                                                                                                
        G_UltraScale_Multiplier : if (DEVICE = "ULTRASCALE") generate begin                                     
            U_US_3D_MP0_MAG1_LUT29_I : DSP48E2_MULTIPLIER generic map(16, 16, TRUE, 4, 27) port map(RST, CLK, mag1_mp0(I), lut29_mp0_i(I), mag1_lut29_mp0_i(I));  
            U_US_3D_MP0_MAG1_LUT29_Q : DSP48E2_MULTIPLIER generic map(16, 16, TRUE, 4, 27) port map(RST, CLK, mag1_mp0(I), lut29_mp0_q(I), mag1_lut29_mp0_q(I));  

            U_US_3D_MP0_MAG0_LUT30_I : DSP48E2_MULTIPLIER generic map(16, 16, TRUE, 4, 27) port map(RST, CLK, mag0_mp0(I), lut30_mp0_i(I), mag0_lut30_mp0_i(I));  
            U_US_3D_MP0_MAG0_LUT30_Q : DSP48E2_MULTIPLIER generic map(16, 16, TRUE, 4, 27) port map(RST, CLK, mag0_mp0(I), lut30_mp0_q(I), mag0_lut30_mp0_q(I));  

            U_7S_3D_MP1_MAG2_LUT31_I : DSP48E2_MULTIPLIER generic map(16, 16, TRUE, 4, 27) port map(RST, CLK, mag2_mp1(I), lut31_mp1_i(I), mag2_lut31_mp1_i(I));  
            U_7S_3D_MP1_MAG2_LUT31_Q : DSP48E2_MULTIPLIER generic map(16, 16, TRUE, 4, 27) port map(RST, CLK, mag2_mp1(I), lut31_mp1_q(I), mag2_lut31_mp1_q(I));  
        end generate;

        G_2D_LUT_Latency_Compensation : for J in 0 to 28 generate begin
            U_2D_LUT_DLY_COMP_I : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 5) port map (RST, CLK, lut_rdata_sw_i(I)(J), lut_rdata_sw_i_d(I)(J));
            U_2D_LUT_DLY_COMP_Q : SRL16E_DLY generic map(DEVICE, HS_MODE, 16, 5) port map (RST, CLK, lut_rdata_sw_q(I)(J), lut_rdata_sw_q_d(I)(J));

            lut_rdata_sw_i_ls(I)(J) <= lut_rdata_sw_i_d(I)(J)&"00000000000"; 
            lut_rdata_sw_q_ls(I)(J) <= lut_rdata_sw_q_d(I)(J)&"00000000000"; 

        end generate;

        mag2_lut31_mp1_i_d(I) <= mag2_lut31_mp1_i(I);
        mag2_lut31_mp1_q_d(I) <= mag2_lut31_mp1_q(I);

        G_3D_Factor_DLY_COMP_Normal_Operation : if (HS_MODE = FALSE) generate begin
            P_3D_Factor_DLY_COMP : process(RST, CLK) begin
                if (RST = '1') then
                    mag1_lut29_mp0_i_d(I) <= (others => '0');
                    mag1_lut29_mp0_q_d(I) <= (others => '0');

                    mag0_lut30_mp0_i_d(I) <= (others => '0');
                    mag0_lut30_mp0_q_d(I) <= (others => '0');
                elsif (CLK'event) and (CLK = '1') then
                    if (LUT_DATA_VLD(I) = '1') then
                        mag1_lut29_mp0_i_d(I) <= mag1_lut29_mp0_i(I);
                        mag1_lut29_mp0_q_d(I) <= mag1_lut29_mp0_q(I);
                                                                    
                        mag0_lut30_mp0_i_d(I) <= mag0_lut30_mp0_i(I);
                        mag0_lut30_mp0_q_d(I) <= mag0_lut30_mp0_q(I);
                    else
                        mag1_lut29_mp0_i_d(I) <= mag1_lut29_mp0_i_d(I);
                        mag1_lut29_mp0_q_d(I) <= mag1_lut29_mp0_q_d(I);

                        mag0_lut30_mp0_i_d(I) <= mag0_lut30_mp0_i_d(I);
                        mag0_lut30_mp0_q_d(I) <= mag0_lut30_mp0_q_d(I);
                    end if;
                end if;
            end process;
        end generate;

        G_3D_Factor_DLY_COMP_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
            P_3D_Factor_DLY_COMP : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    mag1_lut29_mp0_i_d(I) <= mag1_lut29_mp0_i(I);
                    mag1_lut29_mp0_q_d(I) <= mag1_lut29_mp0_q(I);
                                                                
                    mag0_lut30_mp0_i_d(I) <= mag0_lut30_mp0_i(I);
                    mag0_lut30_mp0_q_d(I) <= mag0_lut30_mp0_q(I);
                end if;
            end process;
        end generate;

        -- MPA4 LUT output summation : MPA4, LUT12|x[n+4]|
        U_MPA4_D3_I  : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 3) port map (RST, CLK, lut_rdata_sw_i_ls(I)(12), lut_mpa4_i(I));
        U_MPA4_D3_Q  : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 3) port map (RST, CLK, lut_rdata_sw_q_ls(I)(12), lut_mpa4_q(I));

        -- MPA3 LUT output summation : MPA3, LUT11|x[n+3]|
        U_MPA3_D3_I  : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 3) port map (RST, CLK, lut_rdata_sw_i_ls(I)(11), lut_mpa3_i(I));
        U_MPA3_D3_Q  : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 3) port map (RST, CLK, lut_rdata_sw_q_ls(I)(11), lut_mpa3_q(I));

        -- MPA2 LUT output summation : MPA2, LUT10|x[n+2]|+LUT27|x[n+1]|+LUT28|x[n+0]|
        U_MPA2_ADD_I : ADD8 generic map(HS_MODE, 27) port map(RST, CLK, lut_rdata_sw_i_ls(I)(10), (others => '0'), lut_rdata_sw_i_ls(I)(27), (others => '0'), lut_rdata_sw_i_ls(I)(28), (others => '0'), (others => '0'), (others => '0'), lut_mpa2_i(I)); 
        U_MPA2_ADD_Q : ADD8 generic map(HS_MODE, 27) port map(RST, CLK, lut_rdata_sw_q_ls(I)(10), (others => '0'), lut_rdata_sw_q_ls(I)(27), (others => '0'), lut_rdata_sw_q_ls(I)(28), (others => '0'), (others => '0'), (others => '0'), lut_mpa2_q(I)); 

        -- MPA1 LUT output summation : MPA1, LUT25|x[n+2]|+LUT09|x[n+1]|+LUT26|x[n+0]|
        U_MPA1_ADD_I : ADD8 generic map(HS_MODE, 27) port map(RST, CLK, lut_rdata_sw_i_ls(I)(25), (others => '0'), lut_rdata_sw_i_ls(I)( 9), (others => '0'), lut_rdata_sw_i_ls(I)(26), (others => '0'), (others => '0'), (others => '0'), lut_mpa1_i(I)); 
        U_MPA1_ADD_Q : ADD8 generic map(HS_MODE, 27) port map(RST, CLK, lut_rdata_sw_q_ls(I)(25), (others => '0'), lut_rdata_sw_q_ls(I)( 9), (others => '0'), lut_rdata_sw_q_ls(I)(26), (others => '0'), (others => '0'), (others => '0'), lut_mpa1_q(I)); 

        -- MP0  LUT output summation : MP0,  LUT17|x[n+2]|+LUT16|x[n+1]|+LUT00|x[n+0]|+LUT13|x[n-1]|+LUT14|x[n-2]|+LUT15|x[n-3]|+|x[n-1]|*LUT29|x[n-0]|+|x[n-0]|*LUT30|x[n-1]|
        U_MP00_ADD_I : ADD8 generic map(HS_MODE, 27) port map(RST, CLK, lut_rdata_sw_i_ls(I)(17), lut_rdata_sw_i_ls(I)(16), lut_rdata_sw_i_ls(I)(0), lut_rdata_sw_i_ls(I)(13), lut_rdata_sw_i_ls(I)(14), lut_rdata_sw_i_ls(I)(15), mag1_lut29_mp0_i_d(I), mag0_lut30_mp0_i_d(I), lut_mp00_i(I)); 
        U_MP00_ADD_Q : ADD8 generic map(HS_MODE, 27) port map(RST, CLK, lut_rdata_sw_q_ls(I)(17), lut_rdata_sw_q_ls(I)(16), lut_rdata_sw_q_ls(I)(0), lut_rdata_sw_q_ls(I)(13), lut_rdata_sw_q_ls(I)(14), lut_rdata_sw_q_ls(I)(15), mag1_lut29_mp0_q_d(I), mag0_lut30_mp0_q_d(I), lut_mp00_q(I)); 

        -- MP1  LUT output summation : MP1,  LUT18|x[n-0]|+LUT01|x[n-1]|+LUT19|x[n-2]|+|x[n-2]|*LUT31|x[n-2]|
        U_MP01_ADD_I : ADD8 generic map(HS_MODE, 27) port map(RST, CLK, lut_rdata_sw_i_ls(I)(18), (others => '0'), lut_rdata_sw_i_ls(I)(1), (others => '0'), lut_rdata_sw_i_ls(I)(19), (others => '0'), mag2_lut31_mp1_i_d(I), (others => '0'), lut_mp01_i(I)); 
        U_MP01_ADD_Q : ADD8 generic map(HS_MODE, 27) port map(RST, CLK, lut_rdata_sw_q_ls(I)(18), (others => '0'), lut_rdata_sw_q_ls(I)(1), (others => '0'), lut_rdata_sw_q_ls(I)(19), (others => '0'), mag2_lut31_mp1_q_d(I), (others => '0'), lut_mp01_q(I)); 

        -- MP2  LUT output summation : MP2,  LUT20|x[n-0]|+LUT21|x[n-1]|+LUT02|x[n-2]|+LUT22|x[n-3]|
        U_MP02_ADD_I : ADD8 generic map(HS_MODE, 27) port map(RST, CLK, lut_rdata_sw_i_ls(I)(20), (others => '0'), lut_rdata_sw_i_ls(I)(21), (others => '0'), lut_rdata_sw_i_ls(I)(2), (others => '0'), lut_rdata_sw_i_ls(I)(22), (others => '0'), lut_mp02_i(I)); 
        U_MP02_ADD_Q : ADD8 generic map(HS_MODE, 27) port map(RST, CLK, lut_rdata_sw_q_ls(I)(20), (others => '0'), lut_rdata_sw_q_ls(I)(21), (others => '0'), lut_rdata_sw_q_ls(I)(2), (others => '0'), lut_rdata_sw_q_ls(I)(22), (others => '0'), lut_mp02_q(I)); 

        -- MP3  LUT output summation : MP3,  LUT23|x[n-0]|+LUT24|x[n-2]|+LUT03|x[n-3]|
        U_MP03_ADD_I : ADD8 generic map(HS_MODE, 27) port map(RST, CLK, lut_rdata_sw_i_ls(I)(23), (others => '0'), lut_rdata_sw_i_ls(I)(24), (others => '0'), lut_rdata_sw_i_ls(I)(3), (others => '0'), (others => '0'), (others => '0'), lut_mp03_i(I)); 
        U_MP03_ADD_Q : ADD8 generic map(HS_MODE, 27) port map(RST, CLK, lut_rdata_sw_q_ls(I)(23), (others => '0'), lut_rdata_sw_q_ls(I)(24), (others => '0'), lut_rdata_sw_q_ls(I)(3), (others => '0'), (others => '0'), (others => '0'), lut_mp03_q(I)); 

        -- MP4  LUT output summation : MP4,  LUT04|x[n-4]|
        U_MP04_D3_I  : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 3) port map (RST, CLK, lut_rdata_sw_i_ls(I)(4), lut_mp04_i(I));
        U_MP04_D3_Q  : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 3) port map (RST, CLK, lut_rdata_sw_q_ls(I)(4), lut_mp04_q(I));

        -- MP5  LUT output summation : MP5,  LUT05|x[n-5]|
        U_MP05_D3_I  : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 3) port map (RST, CLK, lut_rdata_sw_i_ls(I)(5), lut_mp05_i(I));
        U_MP05_D3_Q  : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 3) port map (RST, CLK, lut_rdata_sw_q_ls(I)(5), lut_mp05_q(I));

        -- MP6  LUT output summation : MP6,  LUT06|x[n-6]|
        U_MP06_D3_I  : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 3) port map (RST, CLK, lut_rdata_sw_i_ls(I)(6), lut_mp06_i(I));
        U_MP06_D3_Q  : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 3) port map (RST, CLK, lut_rdata_sw_q_ls(I)(6), lut_mp06_q(I));

        -- MP7  LUT output summation : MP7,  LUT07|x[n-7]|
        U_MP07_D3_I  : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 3) port map (RST, CLK, lut_rdata_sw_i_ls(I)(7), lut_mp07_i(I));
        U_MP07_D3_Q  : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 3) port map (RST, CLK, lut_rdata_sw_q_ls(I)(7), lut_mp07_q(I));

        -- MP8  LUT output summation : MP8,  LUT08|x[n-8]|
        U_MP08_D3_I  : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 3) port map (RST, CLK, lut_rdata_sw_i_ls(I)(8), lut_mp08_i(I));
        U_MP08_D3_Q  : SRL16E_DLY generic map(DEVICE, HS_MODE, 27, 3) port map (RST, CLK, lut_rdata_sw_q_ls(I)(8), lut_mp08_q(I));

        LUT_ADD_I(I)( 0) <= lut_mpa4_i(I);                  
        LUT_ADD_Q(I)( 0) <= lut_mpa4_q(I);                  

        LUT_ADD_I(I)( 1) <= lut_mpa3_i(I);                  
        LUT_ADD_Q(I)( 1) <= lut_mpa3_q(I);                  

        LUT_ADD_I(I)( 2) <= lut_mpa2_i(I)(29 downto 3);           
        LUT_ADD_Q(I)( 2) <= lut_mpa2_q(I)(29 downto 3);           

        LUT_ADD_I(I)( 3) <= lut_mpa1_i(I)(29 downto 3);           
        LUT_ADD_Q(I)( 3) <= lut_mpa1_q(I)(29 downto 3);           

        LUT_ADD_I(I)( 4) <= lut_mp00_i(I)(29 downto 3);           
        LUT_ADD_Q(I)( 4) <= lut_mp00_q(I)(29 downto 3);           

        LUT_ADD_I(I)( 5) <= lut_mp01_i(I)(29 downto 3);           
        LUT_ADD_Q(I)( 5) <= lut_mp01_q(I)(29 downto 3);           

        LUT_ADD_I(I)( 6) <= lut_mp02_i(I)(29 downto 3);           
        LUT_ADD_Q(I)( 6) <= lut_mp02_q(I)(29 downto 3);           

        LUT_ADD_I(I)( 7) <= lut_mp03_i(I)(29 downto 3);                       
        LUT_ADD_Q(I)( 7) <= lut_mp03_q(I)(29 downto 3);                       

        LUT_ADD_I(I)( 8) <= lut_mp04_i(I);                       
        LUT_ADD_Q(I)( 8) <= lut_mp04_q(I);                       

        LUT_ADD_I(I)( 9) <= lut_mp05_i(I);                       
        LUT_ADD_Q(I)( 9) <= lut_mp05_q(I);                       

        LUT_ADD_I(I)(10) <= lut_mp06_i(I);                       
        LUT_ADD_Q(I)(10) <= lut_mp06_q(I);                       

        LUT_ADD_I(I)(11) <= lut_mp07_i(I);                       
        LUT_ADD_Q(I)(11) <= lut_mp07_q(I);                       

        LUT_ADD_I(I)(12) <= lut_mp08_i(I);                       
        LUT_ADD_Q(I)(12) <= lut_mp08_q(I);                       

    end generate;

end arc_DPD_3D_LUT32_CONFIG;
