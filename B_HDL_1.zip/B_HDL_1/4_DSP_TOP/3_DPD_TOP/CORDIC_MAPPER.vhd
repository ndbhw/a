library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;

-- Latency = 4 clocks
entity CORDIC_MAPPER is
generic(
    HS_MODE     : boolean :=  TRUE ; -- High Speed Mode (Operating Clock > 307.2MHz)
    ANGLE       : boolean := FALSE
    );
port(
    RST         : in  std_logic;
    CLK         : in  std_logic; 

    DATA_I_IN   : in  std_logic_vector(15 downto 0); 
    DATA_Q_IN   : in  std_logic_vector(15 downto 0); 

    DATA_I_OUT  : out std_logic_vector(18 downto 0); 
    DATA_Q_OUT  : out std_logic_vector(18 downto 0);

    SWAP_IQ_OUT : out std_logic;
    SIGN_I_OUT  : out std_logic;
    SIGN_Q_OUT  : out std_logic
    );
end CORDIC_MAPPER;

architecture arc_CORDIC_MAPPER of CORDIC_MAPPER is

signal sign_i_sh             : std_logic_vector( 3 downto 0);
signal sign_q_sh             : std_logic_vector( 3 downto 0);

signal sign_i_d1             : std_logic;
signal sign_q_d1             : std_logic;

signal data_i_d1             : std_logic_vector(15 downto 0); 
signal data_q_d1             : std_logic_vector(15 downto 0); 

signal data_i_sat_flg        : std_logic; 
signal data_q_sat_flg        : std_logic; 

signal mapper_i_stage1       : std_logic_vector(15 downto 0);
signal mapper_q_stage1       : std_logic_vector(15 downto 0);

signal mapper_i_stage1_d1    : std_logic_vector(15 downto 0);
signal mapper_q_stage1_d1    : std_logic_vector(15 downto 0);

signal mapper_iq_compare_flg : std_logic;

signal mapper_i_stage2       : std_logic_vector(15 downto 0);
signal mapper_q_stage2       : std_logic_vector(15 downto 0);

signal swap_iq_flg           : std_logic;

attribute KEEP : string;
attribute KEEP of sign_i_sh  : signal is "TRUE";
attribute KEEP of sign_q_sh  : signal is "TRUE";
attribute KEEP of sign_i_d1  : signal is "TRUE";
attribute KEEP of sign_q_d1  : signal is "TRUE";

begin

-- CORDIC Mapper
-- The mapper module maps the input data to the first half of the first quadrant (in other words, 
-- the region from 0 to pi/4). This is accomplished by inverting the I and Q components if they are
-- negative followed by a swapping of the I and Q components if Q is greater than or equal to I.
-- The mapped I and Q signals then pass through a series of CORDIC stages to compute the
-- magnitude, sine, and cosine components. The demapper module swaps and/or negates the
-- sine and cosine components to undo the effect of the mapping that was performed in the
-- mapper module. The mapping and demapping is generally done to reduce memory
-- requirements. 

    G_Normal_Operating_Mode : if (HS_MODE = FALSE) generate begin
        P_Sign_Bit_DLY_Compensation_NM : process(RST, CLK) begin
            if (RST = '1') then
                sign_i_sh <= (others => '0'); 
                sign_q_sh <= (others => '0'); 
            elsif (CLK'event) and (CLK = '1') then
                sign_i_sh <= sign_i_sh(2 downto 0) & DATA_I_IN(15); 
                sign_q_sh <= sign_q_sh(2 downto 0) & DATA_Q_IN(15); 
            end if; 
        end process;	

        -- 1st clock
        P_Input_Data_1Clocking_NM : procesS(RST, CLK) begin
            if (RST = '1') then
                sign_i_d1 <= '0';  
                sign_q_d1 <= '0';  
                
                data_i_d1 <= (others => '0');   
                data_q_d1 <= (others => '0');   
            elsif (CLK'event) and (CLK = '1') then
                sign_i_d1 <= DATA_I_IN(15);  
                sign_q_d1 <= DATA_Q_IN(15);  
                
                data_i_d1 <= DATA_I_IN;   
                data_q_d1 <= DATA_Q_IN;   
            end if;
        end process;

        G_Angle_Compliment_of_One_NM : if (ANGLE = TRUE) generate begin

            data_i_sat_flg <= '0';   
            data_q_sat_flg <= '0';   
            -- Shift the First Quadrant : the region form 0 to pi/2
            -- 2nd clock	    
            P_Shift_The_1st_Quadrant_NM : process(RST, CLK) begin
                if (RST = '1') then
                    mapper_i_stage1 <= (others => '0'); 
                    mapper_q_stage1 <= (others => '0'); 
                elsif (CLK'event) and (CLK = '1') then
                    if (sign_i_d1 = '1') then             -- DATA_I_IN < 0 
                        mapper_i_stage1 <= not data_i_d1; -- 1's compliment
                    else
                        mapper_i_stage1 <= data_i_d1; 
                    end if;
            
                    if (sign_q_d1 = '1') then             -- DATA_Q_IN < 0
                        mapper_q_stage1 <= not data_q_d1; -- 1's compliment 
                    else
                        mapper_q_stage1 <= data_q_d1; 
                    end if;
                end if;
            end process;

        end generate;

        G_MAG_Compliment_of_two_NM : if (ANGLE = FALSE) generate begin
            -- 1st clock
            P_Saturation_Flag_NM : process(RST, CLK) begin
                if (RST = '1') then	
                    data_i_sat_flg <= '0';   
                    data_q_sat_flg <= '0';   
                elsif (CLK'event) and (CLK = '1') then
                    if (DATA_I_IN = x"8000") then
                        data_i_sat_flg <= '1';   
                    else
                        data_i_sat_flg <= '0';   
                    end if;

                    if (DATA_Q_IN = x"8000") then
                        data_q_sat_flg <= '1';   
                    else
                        data_q_sat_flg <= '0';   
                    end if;
                end if;
            end process;

            -- Shift the First Quadrant : the region form 0 to pi/2
            -- 2nd clock	    
            P_Shift_the_1st_Quadrant_NM : process(RST, CLK) begin
                if (RST = '1') then
                    mapper_i_stage1 <= (others => '0'); 
                    mapper_q_stage1 <= (others => '0'); 
                elsif (CLK'event) and (CLK = '1') then
                    if (data_i_sat_flg = '1') then                    
                        mapper_i_stage1 <= x"7FFF"; 
                    else
                        if (sign_i_d1 = '1') then                     -- DATA_I_IN < 0
                            mapper_i_stage1 <= (not data_i_d1) + '1'; -- 2's compliment
                        else
                            mapper_i_stage1 <= data_i_d1; 
                        end if;
                    end if;

                    if (data_q_sat_flg = '1') then
                        mapper_q_stage1 <= x"7FFF"; 
                    else
                        if (sign_q_d1 = '1') then                     -- DATA_Q_IN < 0
                            mapper_q_stage1 <= (not data_q_d1) + '1'; -- 2's compliment
                        else
                            mapper_q_stage1 <= data_q_d1; 
                        end if;
                    end if;
                end if;
            end process;

        end generate;
            
        -- 3rd clock
        P_Mapper_IQ_Compare_NM : process(RST, CLK) begin
            if (RST = '1') then
                mapper_iq_compare_flg <= '0';              
                mapper_i_stage1_d1    <= (others => '0');  
                mapper_q_stage1_d1    <= (others => '0');  
            elsif (CLK'event) and (CLK = '1') then
                if (mapper_i_stage1 <= mapper_q_stage1) then
                    mapper_iq_compare_flg <= '1';              
                else
                    mapper_iq_compare_flg <= '0';              
                end if;

                mapper_i_stage1_d1 <= mapper_i_stage1;  
                mapper_q_stage1_d1 <= mapper_q_stage1;  
            end if;
        end process;

        -- Swap I/Q
        -- 4th clock
        P_SWAP_IQ_NM : process(RST, CLK) begin
            if (RST = '1') then
                mapper_i_stage2 <= (others => '0'); 
                mapper_q_stage2 <= (others => '0'); 
                swap_iq_flg     <= '0';             
            elsif (CLK'event) and (CLK = '1') then
                if (mapper_iq_compare_flg = '1') then      -- pi/4 < X < pi/2
                    mapper_i_stage2 <= mapper_q_stage1_d1; 
                    mapper_q_stage2 <= mapper_i_stage1_d1; 
                    swap_iq_flg     <= '1';             
                else                                       -- 0 < X < pi/4
                    mapper_i_stage2 <= mapper_i_stage1_d1; 
                    mapper_q_stage2 <= mapper_q_stage1_d1; 
                    swap_iq_flg     <= '0';             
                end if;
            end if;
        end process;
    end generate;

    G_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
        P_Sign_Bit_DLY_Compensation_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                sign_i_sh <= sign_i_sh(2 downto 0) & DATA_I_IN(15); 
                sign_q_sh <= sign_q_sh(2 downto 0) & DATA_Q_IN(15); 
            end if; 
        end process;	

        -- 1st clock
        P_Input_Data_1Clocking_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                sign_i_d1 <= DATA_I_IN(15);  
                sign_q_d1 <= DATA_Q_IN(15);  
                
                data_i_d1 <= DATA_I_IN;   
                data_q_d1 <= DATA_Q_IN;   
            end if;
        end process;

        G_Angle_Compliment_of_One_HS : if (ANGLE = TRUE) generate begin

            data_i_sat_flg <= '0';   
            data_q_sat_flg <= '0';   
            -- Shift the First Quadrant : the region form 0 to pi/2
            -- 2nd clock	    
            P_Shift_The_1st_Quadrant_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    if (sign_i_d1 = '1') then             -- DATA_I_IN < 0 
                        mapper_i_stage1 <= not data_i_d1; -- 1's compliment
                    else
                        mapper_i_stage1 <= data_i_d1; 
                    end if;
            
                    if (sign_q_d1 = '1') then             -- DATA_Q_IN < 0
                        mapper_q_stage1 <= not data_q_d1; -- 1's compliment 
                    else
                        mapper_q_stage1 <= data_q_d1; 
                    end if;
                end if;
            end process;

        end generate;

        G_MAG_Compliment_of_two_HS : if (ANGLE = FALSE) generate begin
            -- 1st clock
            P_Saturation_Flag_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    if (DATA_I_IN = x"8000") then
                        data_i_sat_flg <= '1';   
                    else
                        data_i_sat_flg <= '0';   
                    end if;

                    if (DATA_Q_IN = x"8000") then
                        data_q_sat_flg <= '1';   
                    else
                        data_q_sat_flg <= '0';   
                    end if;
                end if;
            end process;

            -- Shift the First Quadrant : the region form 0 to pi/2
            -- 2nd clock	    
            P_Shift_the_1st_Quadrant_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    if (data_i_sat_flg = '1') then                    
                        mapper_i_stage1 <= x"7FFF"; 
                    else
                        if (sign_i_d1 = '1') then                     -- DATA_I_IN < 0
                            mapper_i_stage1 <= (not data_i_d1) + '1'; -- 2's compliment
                        else
                            mapper_i_stage1 <= data_i_d1; 
                        end if;
                    end if;

                    if (data_q_sat_flg = '1') then
                        mapper_q_stage1 <= x"7FFF"; 
                    else
                        if (sign_q_d1 = '1') then                     -- DATA_Q_IN < 0
                            mapper_q_stage1 <= (not data_q_d1) + '1'; -- 2's compliment
                        else
                            mapper_q_stage1 <= data_q_d1; 
                        end if;
                    end if;
                end if;
            end process;

        end generate;
            
        -- 3rd clock
        P_Mapper_IQ_Compare_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (mapper_i_stage1 <= mapper_q_stage1) then
                    mapper_iq_compare_flg <= '1';              
                else
                    mapper_iq_compare_flg <= '0';              
                end if;

                mapper_i_stage1_d1 <= mapper_i_stage1;  
                mapper_q_stage1_d1 <= mapper_q_stage1;  
            end if;
        end process;

        -- Swap I/Q
        -- 4th clock
        P_SWAP_IQ_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (mapper_iq_compare_flg = '1') then      -- pi/4 < X < pi/2
                    mapper_i_stage2 <= mapper_q_stage1_d1; 
                    mapper_q_stage2 <= mapper_i_stage1_d1; 
                    swap_iq_flg     <= '1';             
                else                                       -- 0 < X < pi/4
                    mapper_i_stage2 <= mapper_i_stage1_d1; 
                    mapper_q_stage2 <= mapper_q_stage1_d1; 
                    swap_iq_flg     <= '0';             
                end if;
            end if;
        end process;
    end generate;


    DATA_I_OUT  <= mapper_i_stage2(15)&mapper_i_stage2(15)&mapper_i_stage2(15)&mapper_i_stage2;  
    DATA_Q_OUT  <= mapper_q_stage2(15)&mapper_q_stage2(15)&mapper_q_stage2(15)&mapper_q_stage2; 

    SWAP_IQ_OUT <= swap_iq_flg;
    SIGN_I_OUT  <= sign_i_sh(3);
    SIGN_Q_OUT  <= sign_q_sh(3);

end arc_CORDIC_MAPPER;
