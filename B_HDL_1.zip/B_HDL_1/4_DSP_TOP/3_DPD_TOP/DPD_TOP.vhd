-- Designer         : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name       : DPD_TOP (New Platform Block Name of DPDFB_WRAPPER) 
-- Revision History : ver0.0   2016.09.20 - First Version of RU FPGA New Platform  
--                    ver0.1   2016.10.19 - Separation DL and FB HOVS
--                    ver0.2   2016.11.17 - Modified FBSW_CTRL, Non Feedback Path Mux
--                    ver0.3   2016.12.05 - Using Optimized DPD (LUT Memory Shared)
--                                          Elimiated declaring Generic at TOP 
--                    ver0.4   2017.01.11 - Added PIM Block
--                    ver0.5   2017.05.16 - Modified Block Hierarchy 
--                    ver0.6   2017.06.01 - Removed CFR_DLY, UL_DLY 
--                    ver0.7   2017.07.25 - Changed Interband PIM Source formular  
--                    ver0.8   2017.08.06 - Add RX_SSD
--                    ver0.9   2018.02.27 - DPD HC Flag Monitoring

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;
use IEEE.math_real.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

-- VzW 2x4T4R B2 Only
entity DPD_TOP is
port(
    -- CPU Interface       
    RST_CPUIF                                 : in  std_logic;                                 -- CPUIF Reset, '1': Reset
    CLK_CPUIF                                 : in  std_logic;                                 -- CPUIF Clock, Faster than iclk/oclk
    ADDR_CPUIF_IN                             : in  std_logic_vector(ADDR_WIDTH-1  downto 0);  -- CPUIF Address Input, Word Address
    WDATA_CPUIF_IN                            : in  std_logic_vector(WDATA_WIDTH-1 downto 0);  -- CPUIF Data Input
    RDATA_CPUIF_OUT                           : out std_logic_vector(RDATA_WIDTH-1 downto 0);  -- CPUIF Data Output
    WREN_CPUIF_IN                             : in  std_logic;                                 -- CPUIF Write Enable, '1': Active, Synchronous with iclk
    RDEN_CPUIF_IN                             : in  std_logic;                                 -- CPUIF Read  Enable, '1': Active
    RDVLD_CPUIF_OUT                           : out std_logic;                                 -- CPUIF Read Valid,   '1': Active, Synchronous with clk_cpu

    -- Reset & Clock                          
    RST_DPD                                   : in  std_logic;                                 -- DPD_TOP Reset, '1': Reset
    RST_PIM                                   : in  std_logic;                                 -- DPD_TOP Reset, '1': Reset
    CLK_SYS                                   : in  std_logic;                                 -- System Clock :  30.72 MHz
    CLK_SYSX2                                 : in  std_logic;                                 --  2x(CLK_SYS) :  61.44 MHz
    CLK_SYSX3                                 : in  std_logic;                                 --  3x(CLK_SYS) :  92.16 MHz
    CLK_SYSX4                                 : in  std_logic;                                 --  4x(CLK_SYS) : 122.88 MHz
    CLK_SYSX5                                 : in  std_logic;                                 --  5x(CLK_SYS) : 153.60 MHz
    CLK_SYSX6                                 : in  std_logic;                                 --  6x(CLK_SYS) : 184.32 MHz
    CLK_SYSX8                                 : in  std_logic;                                 --  8x(CLK_SYS) : 245.76 MHz
    CLK_SYSX10                                : in  std_logic;                                 -- 10x(CLK_SYS) : 307.20 MHz
    CLK_SYSX12                                : in  std_logic;                                 -- 12x(CLK_SYS) : 368.64 MHz
    CLK_SYSX16                                : in  std_logic;                                 -- 16x(CLK_SYS) : 491.52 MHz
    CLK_SYSX20                                : in  std_logic;                                 -- 20x(CLK_SYS) : 614.40 MHz

    -- PLL Lock
    INT_SYSPLL_LOCK_IN                        : in  std_logic;                                 -- Internal System PLL Lock 

    -- DL/FB Latency
    DPD_DL_PROC_DLY_OUT                       : out std_logic_vector(31 downto 0);             -- Downlink Latency Information (Unit : Clock)
    DPD_FB_PROC_DLY_OUT                       : out std_logic_vector(31 downto 0);             -- Feedback Latency Information (Unit : Clock)
    DPD_UL_PROC_DLY_OUT                       : out std_logic_vector(31 downto 0);             -- Uplink   Latency Information (Unit : Clock)
    
    -- TDD/FS Strobe 
    DL_BFN_STRB_IN                            : in  std_logic;                                 -- Downlink 10ms Frame Sync Strobe
    DL_TDD_IN                                 : in  std_logic;                                 -- Downlink TDD Strobe
    DL_SSB_STRB_IN                            : in  std_logic;                                 -- 40ms sync signal for SSB power measurement
    
    DL_BFN_STRB_OUT                           : out std_logic;                                 -- Delayed Downlink 10ms Frame Sync Strobe as DL Path Latency 
    DL_TDD_OUT                                : out std_logic;                                 -- Delayed Downlink TDD Strobe as DL Path Latency 
    DL_SSB_STRB_OUT                           : out std_logic;                                 -- 40ms sync signal for SSB power measurement
    
    FB_BFN_STRB_IN                            : in  std_logic;                                 -- Feedback 10ms Frame Sync Strobe
    FB_TDD_IN                                 : in  std_logic;                                 -- Feedback TDD Strobe
    FB_SSB_STRB_IN                            : in  std_logic;                                 -- 40ms sync signal for SSB power measurement
    
    UL_BFN_STRB_IN                            : in  std_logic;                                 -- Uplink 10ms Frame Sync Strobe
    UL_TDD_IN                                 : in  std_logic;                                 -- Uplink TDD Strobe
    
    UL_BFN_STRB_OUT                           : out std_logic;                                 -- Delayed Uplink 10ms Frame Sync Strobe as UL Path Latency 
    UL_TDD_OUT                                : out std_logic;                                 -- Delayed Uplink TDD Strobe as DL Path Latency 

    DL_BCF_ENB_IN                             : in  std_logic;
    DL_BCF_ENB_OUT                            : out std_logic;

    UL_BCF_ENB_IN                             : in  std_logic;
    UL_BCF_ENB_OUT                            : out std_logic;

    -- Traffic IQ
    DL_SYNC_IN                                : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- CFR-HC output IQ sample valid
    DL_I_IN                                   : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- CFR-HC output I data
    DL_Q_IN                                   : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- CFR-HC output Q data

    DL_INTERBAND_SYNC_IN                      : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- InterBand PIM DUC output IQ sample valid
    DL_INTERBAND_I_IN                         : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- InterBand PIM DUC output I data
    DL_INTERBAND_Q_IN                         : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- InterBand PIM DUC output Q data

    DL_SYNC_OUT                               : out std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output IQ sample valid
    DL_I_OUT                                  : out std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output I data
    DL_Q_OUT                                  : out std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output Q data

    FB_SYNC_IN                                : in  std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback Path IQ sample valid
    FB_I_IN                                   : in  std_logic_array16(FB_PATH_NUM-1 downto 0); -- Feedback Path I data
    FB_Q_IN                                   : in  std_logic_array16(FB_PATH_NUM-1 downto 0); -- Feedback Path Q data

    UL_SYNC_IN                                : in  std_logic_vector( RX_ANT_NUM-1 downto 0);  -- UL DACIF output IQ sample valid
    UL_I_IN                                   : in  std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DACIF output I data
    UL_Q_IN                                   : in  std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DACIF output Q data

    UL_SYNC_OUT                               : out std_logic_vector( RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output IQ sample valid
    UL_I_OUT                                  : out std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output I data
    UL_Q_OUT                                  : out std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output Q data

    -- Feedback Switch
    FBSW_START_TRIG_IN                        : in  std_logic;                                 -- Start Pulse of Feedback Switch Period
    FBSW_AUTO_MODE_DONE_IN                    : in  std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback Switch Automode Done Flag, '0': Auto Mode
    FBSW_MANUAL_MODE_IN                       : in  std_logic;                                 -- Feedback Switch Manual Mode, '1': Manual Mode
    FBSW_CNT_IN                               : in  std_logic_vector( 4 downto 0);             -- Feedback Switch Counter
    FBSW_VAL_OUT                              : out std_logic_vector( 3 downto 0);             -- Encoded Feedback Switch Value

    FBSW_SC_PATH_SEL_OUT                      : out std_logic_vector( 4 downto 0);
    PWR_MSR_FB_SYNC_IN                        : in  std_logic;
    PWR_MSR_EN_IN                             : in  std_logic;

    FBSW_SSB_IND_FLAG                         : in  std_logic;

    -- Control & Status
    SIG_SUS_DLOFF_IN                          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- Wave-Stop Flag

    DL_NCO_WEN_IN                             : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- Downlink NCO (before DPD) Word Write Enable
    DL_NCO_DATA_IN                            : in  std_logic_array32(TX_ANT_NUM-1 downto 0);  -- Downlink NCO (before DPD) Word Value 

    DPD_BYPASS_IN                             : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DPD-CORE Bypass '1': Bypass 
    DPD_HC_TRSHD_IN                           : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DPD-HC Threshold Value
    DPD_HC_FLAG_OUT                           : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Hard-Clipping Flag
    DPD_DATT_IN                               : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DPD-Digital Attenuator Atten Value
    DPD_FILTER_BYPASS_IN                      : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Bypass '1': Bypass 

    COEF_WREN_IN                              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Coefficient Write Enable
    COEF_RDEN_IN                              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Coefficient Read  Enable
    COEF_WR_DONE_IN                           : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Coefficient Write Done 
    COEF_ADDR_IN                              : in  std_logic_vector( 7 downto 0);             -- DPD-OutFilter Coefficient Write/Read Address
    COEF_WR_DATA_IN                           : in  std_logic_vector(15 downto 0);             -- DPD-OutFilter Coefficient Write Data
    COEF_RD_DATA_OUT                          : out std_logic_vector(15 downto 0);             -- DPD-OutFilter Coefficient Read  Data

    DACIF_BYPASS_IN                           : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DACIF_ON Block Bypass
    DACIF_ON_IN                               : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DACIF_ON Block Control Register form CPU 

    FB_NCO_WEN_IN                             : in  std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback NCO Word Write Enable
    FB_NCO_WORD_IN                            : in  std_logic_array32(FB_PATH_NUM-1 downto 0); -- Feedback NCO Word Value

    FB_FILTER_BYPASS_IN                       : in  std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback Filter Bypass

    FB_PWR_MSR_BFN_STRB_OUT                   : out std_logic;                                 -- Feedback Power Measure Input BFN Strobe
    FB_PWR_MSR_DONE_OUT                       : out std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback Power Measure Done Flag
    FB_PWR_OUT                                : out std_logic_array32(FB_PATH_NUM-1 downto 0); -- Power Value(Mantissa Format) at Feedback Path

    DL_PWR_OUT                                : out std_logic_array32(TX_ANT_NUM-1 downto 0); 

    FB_FWD_DATT_IN                            : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- Feedback Forward Side Digital Atten Value
    FB_RVS_DATT_IN                            : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- Feedback Reverse Side Digital Atten Value

    PIM_DETECTOR_ON_IN                        : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
    PIM_MITIGATOR_ON_IN                       : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
    PIM_CFR_REF_SEL_IN                        : in  std_logic_vector( RX_ANT_NUM-1 downto 0);

    PIM_PNPC_SEL_IN                           : in  std_logic_array2( RX_ANT_NUM-1 downto 0);
    
    PIM_CORE_BYPASS_IN                        : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM Core Bypass

    PIM_FILTER_BYPASS_IN                      : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM Low Pass Filter Bypass
    PIM_FILTER_COEF_WR_EN_IN                  : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM LPF coefficient write enable(indirect)
    PIM_FILTER_COEF_RD_EN_IN                  : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM LPF coefficient read  enable(indirect)
    PIM_FILTER_COEF_WR_DN_IN                  : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM LPF coefficient write done(indirect)
    PIM_FILTER_COEF_ADDR_IN                   : in  std_logic_vector( 7 downto 0);            -- PIM LPF coefficient write address
    PIM_FILTER_COEF_WR_DATA_IN                : in  std_logic_vector(15 downto 0);            -- PIM LPF coefficient write data(indirect) 
    PIM_FILTER_COEF_RD_DATA_OUT               : out std_logic_vector(15 downto 0);            -- PIM LPF coefficient read  data(indirect) 

    PIM_NCO_WREN_IN                           : in  std_logic;
    PIM_NCO_WORD_IN                           : in  std_logic_vector(31 downto 0);

    PIM_INTERBAND_DUC_GAIN_IN                 : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    UL_PIM_NCO_WREN_IN                        : in  std_logic;
    UL_PIM_NCO_WORD_IN                        : in  std_logic_vector(31 downto 0);

    DPD_INFO_OUT                              : out std_logic_vector(31 downto 0);             -- DPD_TOP Information
    DPD_STRUCT_OUT                            : out std_logic_vector(31 downto 0);             -- DPD_TOP Structure Information 
    DPD_DATE_OUT                              : out std_logic_vector(31 downto 0);             -- DPD_TOP Date

    -- Dump & Test
    SC_LB_ON_IN                               : in  std_logic;                                 -- Loopback Enable for Smart Capture Test, Test Only

    DACIF_PHTEST_ENB_IN                       : in  std_logic;                                 -- '1': Phase test enable, '0': disable
    DACIF_PHTEST_REF_SEL_IN                   : in  std_logic;                                 -- '1': BFN_STRB, '0': TDD 
    DACIF_PHTEST_PATH_AB_SWAP_IN              : in  std_logic;                                 -- '1': Swap A/B, '0': normal
    DACIF_PHTEST_PATH_REVERSE_IN              : in  std_logic;                                 -- '1': Reverse 0 <-> (TX_ANT_NUM-1), '0': normal
    DACIF_PHTEST_REPEAT_ENB_IN                : in  std_logic;                                 -- '1': Repeat enable, '0': repeat disable
    DACIF_PHTEST_DACIF_DEFAULT_IN             : in  std_logic_vector(TX_ANT_NUM-1 downto 0);   -- DACIF default value for phase test

    DACIF_PHTEST_OFFSET_IN                    : in  std_logic_vector(23 downto 0);             -- Offset from BFN_STRB/TDD
    DACIF_PHTEST_PERIOD_IN                    : in  std_logic_vector(23 downto 0);             -- Period on/off for one path
    DACIF_PHTEST_ON_DURATION_IN               : in  std_logic_vector(23 downto 0);             -- On duration of one period

    DBG_SIG_OUT                               : out std_logic_array32(1 downto 0);             -- For Block Debugging, Reserved Output

    DUMP_POINT_SEL_STRB_IN                    : in  std_logic;
    DUMP_POINT_SEL_IN                         : in  std_logic_vector( 7 downto 0);             -- Dump Point Selection
    DUMP_BFN_STRB_OUT                         : out std_logic_vector( 1 downto 0);             -- Delayed 10ms Frame Sync Strobe for DUMP                 
    DUMP_DVLD_OUT                             : out std_logic_vector( 1 downto 0);             -- Dump Sample Valid
    DUMP_DATA_OUT                             : out std_logic_array32(1 downto 0)              -- Dump Sample	
    );
end DPD_TOP;

architecture arc_DPD_TOP of DPD_TOP is

-- ***********************************
-- CONSTANTs
-- ***********************************
constant ZEROS                                : std_logic_vector(31 downto 0) := (others => '0');
constant SC_EXPANSION                         : boolean :=   TRUE ;
constant DPD_PATH_PHASE                       : string  :=  "MONO"; 

constant DL_NCO_RESOLUTION                    : natural :=  natural(DPD_DL_SAMPLE_RATE*100.00);                         

-- DL Block Latency
constant COMM_MIXER_DLY                       : natural :=  8 ;
constant COMM_HC_DLY                          : natural := 26 ;
constant COMM_ATT_HOVS1_DLY                   : natural :=  6 ;
constant COMM_ATT_HOVS2_DLY                   : natural := 10 ;

constant DL_INPUT_ALIGN_DLY                   : natural := DL_HOVS;
constant DL_MIXER_DLY                         : natural := COMM_MIXER_DLY;
constant DL_RXSSD_DLY                         : natural := DL_HOVS*12; 
-- constant DL_DPDCORE_DLY                       : natural := DPD_HOVS*(DPD_CORE_TAP_NUM+DPD_CORE_LUT0_NUM) + ternary_func((DPD_HOVS = 1), 47, 56);              
constant DL_DPDCORE_DLY                       : natural := 80 + DL_HOVS; -- 82;              
constant DL_DPDHC_DLY                         : natural := COMM_HC_DLY;                       
constant DL_DPDATT_DLY                        : natural := ternary_func((DPD_HOVS = 1), COMM_ATT_HOVS1_DLY, COMM_ATT_HOVS2_DLY);                       
-- constant DL_DPD_FILTER_DLY                    : natural := DPD_HOVS*(DPD_FILTER_COEF_NUM + 8);            
constant DL_DPD_FILTER_DLY                    : natural := DPD_HOVS*(DPD_FILTER_COEF_NUM + 6 + DPD_HOVS);            
constant DL_DACIF_ON_DLY                      : natural := ternary_func((DPD_HOVS = 1), 6+1, 8+1);            

constant DL_MIXER_IMPL                        : natural := ternary_func((DL_MIXER_IMPLEMENTATION    = TRUE), 1, 0);
constant DL_RXSSD_IMPL                        : natural := ternary_func((RX_SSD_IMPLEMENTATION      = TRUE), 1, 0);
constant DL_DPDCORE_IMPL                      : natural := ternary_func((DPD_CORE_IMPLEMENTATION    = TRUE), 1, 0);              
constant DL_DPDHC_IMPL                        : natural := ternary_func((DPD_HC_IMPLEMENTATION      = TRUE), 1, 0);
constant DL_DPDATT_IMPL                       : natural := ternary_func((DPD_ATT_IMPLEMENTATION     = TRUE), 1, 0);                   
constant DL_DPD_FILTER_IMPL                   : natural := ternary_func((DPD_FILTER_IMPLEMENTATION  = TRUE), 1, 0);   
constant DL_DACIF_ON_IMPL                     : natural := ternary_func((DACIF_ONOFF_IMPLEMENTATION = TRUE), 1, 0);     

constant DL_PATH_DLY                          : natural := (DL_INPUT_ALIGN_DLY                    )+                
                                                           (DL_MIXER_DLY       * DL_MIXER_IMPL    )+
                                                           (DL_RXSSD_DLY       * DL_RXSSD_IMPL    )+
                                                           (DL_DPDCORE_IMPL    * DL_DPDCORE_DLY   )+        
                                                           (DL_DPDHC_IMPL      * DL_DPDHC_DLY     )+
                                                           (DL_DPDATT_IMPL     * DL_DPDATT_DLY    )+                 
                                                           (DL_DPD_FILTER_IMPL * DL_DPD_FILTER_DLY)+   
                                                           (DL_DACIF_ON_IMPL   * DL_DACIF_ON_DLY  )+ 1;     


-- FB Block Latency
constant FB_INPUT_ALIGN_DLY                   : natural := FB_HOVS;
constant FB_SW_DLY                            : natural := FB_HOVS + 2;

constant FB_FILTER_TAP_HALF                   : natural := FB_FILTER_TAP_NUM/2;
constant FB_FILTER_TAP_HALF_ODD               : natural := ternary_func((FB_FILTER_TAP_HALF mod 2 = 1),1,0);
constant FB_FILTER_HOVS1_DLY                  : natural := (FB_FILTER_TAP_HALF)                          +  8;
constant FB_FILTER_HOVS2_DLY                  : natural := (FB_FILTER_TAP_HALF+FB_FILTER_TAP_HALF_ODD)*2 + 11;
constant FB_FILTER_DLY                        : natural := ternary_func((FB_HOVS = 1), FB_FILTER_HOVS1_DLY , FB_FILTER_HOVS2_DLY );
constant FB_ATTEN_DLY                         : natural := ternary_func((FB_HOVS = 1), COMM_ATT_HOVS1_DLY, COMM_ATT_HOVS2_DLY);

constant FB_ATTEN_IMPL                        : natural := ternary_func((FB_ATTEN_IMPLEMENTATION  = TRUE), 1, 0);   

constant FB_PATH_DLY                          : natural := FB_INPUT_ALIGN_DLY + FB_SW_DLY + (FB_ATTEN_IMPL * FB_ATTEN_DLY);           

-- UL Block Latency
constant UL_INPUT_ALIGN_DLY                   : natural := UL_HOVS;
constant UL_HBF_I_DLY                         : natural := 59;
constant UL_MIXPS_DLY                         : natural := COMM_MIXER_DLY;
constant UL_PNPC_DLY                          : natural := 12; -- (vhdl) 11; -- (IP) 
constant UL_PIMD_DLY                          : natural :=  2 + DL_HOVS + 2;
constant UL_MIXNS_DLY                         : natural := COMM_MIXER_DLY;
constant UL_HBF_D_DLY                         : natural := 2;
constant UL_HBF_D_CDC_DLY                     : natural := 1;
constant UL_PIM_BYPASS                        : natural :=  1;                      
-- constant UL_PIM_PATH_DLY                      : natural := (UL_INPUT_ALIGN_DLY + UL_HBF_D_CDC_DLY + UL_PIM_BYPASS)+(DL_CLK_SEL/UL_CLK_SEL)*(UL_HBF_I_DLY + UL_MIXPS_DLY + UL_PNPC_DLY + UL_PIMD_DLY + UL_MIXNS_DLY + UL_HBF_D_DLY);                      
constant UL_PIM_PATH_DLY_OP                   : natural := DL_CLK_SEL*(UL_INPUT_ALIGN_DLY + UL_HBF_D_CDC_DLY + UL_PIM_BYPASS)+(UL_CLK_SEL)*(UL_HBF_I_DLY + UL_MIXPS_DLY + UL_PNPC_DLY + UL_PIMD_DLY + UL_MIXNS_DLY + UL_HBF_D_DLY);                      
constant UL_PIM_PATH_DLY                      : natural := (UL_PIM_PATH_DLY_OP / DL_CLK_SEL) ;
constant UL_PIM_OFF_DLY                       : natural := (UL_INPUT_ALIGN_DLY + UL_HBF_D_CDC_DLY + UL_PIM_BYPASS);                      

constant UL_PATH_DLY                          : natural := ternary_func((PIM_IMPLEMENTATION = TRUE), UL_PIM_PATH_DLY-26, 0);
constant UL_PIMOFF_DLY                        : natural := ternary_func((PIM_IMPLEMENTATION = TRUE), UL_PIM_OFF_DLY , 0);

-- DPD_TOP Structure Information
constant DL_SYSCLKX                           : std_logic_vector( 7 downto 0) := std_logic_vector(to_unsigned(DL_CLK_SEL,  8));
constant FB_SYSCLKX                           : std_logic_vector( 7 downto 0) := std_logic_vector(to_unsigned(FB_CLK_SEL,  8));
constant UL_SYSCLKX                           : std_logic_vector( 7 downto 0) := std_logic_vector(to_unsigned(UL_CLK_SEL,  8));

constant DLY_DL_PATH                          : std_logic_vector(23 downto 0) := std_logic_vector(to_unsigned(DL_PATH_DLY  , 24));
constant DLY_FB_PATH                          : std_logic_vector(23 downto 0) := std_logic_vector(to_unsigned(FB_PATH_DLY  , 24));
constant DLY_UL_PATH                          : std_logic_vector(23 downto 0) := std_logic_vector(to_unsigned(UL_PATH_DLY  , 24));
constant DLY_UL_PIMOFF                        : std_logic_vector(23 downto 0) := std_logic_vector(to_unsigned(UL_PIMOFF_DLY, 24)); 
constant DPD_TOP_ID                           : std_logic_vector( 7 downto 0) := x"43";        -- DPD_TOP ID : 0x43
constant CODE_ID                              : std_logic_vector( 7 downto 0) := x"00";        -- SEC : 0x00, SRC : 0x01
constant VERSION_ID                           : std_logic_vector( 7 downto 0) := x"02";        -- Revision Version
constant DPD_INFO                             : std_logic_vector(31 downto 0) := DPD_TOP_ID&CODE_ID&ZEROS(15 downto 8)&VERSION_ID;

constant OPR_CLKX                             : std_logic_vector( 7 downto 0) := std_logic_vector(to_unsigned(DL_CLK_SEL, 8));
constant DL_HOVS_FACTOR                       : std_logic_vector( 3 downto 0) := std_logic_vector(to_unsigned(DL_HOVS   , 4));
constant FB_HOVS_FACTOR                       : std_logic_vector( 3 downto 0) := std_logic_vector(to_unsigned(FB_HOVS   , 4));


-- -------------------------------------
-- |      DPDCORE_CONFIG       | Value |
-- -------------------------------------
-- |                     Unuse |  0x0  |
-- -------------------------------------
-- | Using Non-Path MUX LS DPD |  0x1  |
-- -------------------------------------
-- |     Using Path MUX LS DPD |  0x2  |
-- -------------------------------------
-- |             Using LMS DPD |  0x3  |
-- -------------------------------------

constant DPDCORE_CONFIG                       : std_logic_vector( 3 downto 0) := x"2";

constant DPD_CORE_TAPs                        : std_logic_vector( 3 downto 0) := std_logic_vector(to_unsigned(ternary_func((DPD_CORE_IMPLEMENTATION = TRUE),DPD_CORE_TAP_NUM, 0), 4));

-- ------------------------
-- | OTHER_CONFIG | Value |
-- ------------------------
-- |   Un-Defined | 0x00  |
-- ------------------------
-- |   PIMD-Intra | 0x10  |
-- ------------------------
-- |   PIMD-Inter | 0x11  |
-- ------------------------

constant OTHER_CONFIG                         : std_logic_vector( 7 downto 0) := x"00";

constant DPD_STRUCT                           : std_logic_vector(31 downto 0) := OPR_CLKX&DL_HOVS_FACTOR&FB_HOVS_FACTOR&DPDCORE_CONFIG&DPD_CORE_TAPs&OTHER_CONFIG;

constant DPD_DATE                             : std_logic_vector(31 downto 0) := x"2023_0913"; -- DPD_TOP Block Date

constant DPDFB_DL_DELAY                       : std_logic_vector(31 downto 0) := DL_SYSCLKX & DLY_DL_PATH;
constant DPDFB_FB_DELAY                       : std_logic_vector(31 downto 0) := FB_SYSCLKX & DLY_FB_PATH;
constant DPDFB_UL_DELAY                       : std_logic_vector(31 downto 0) := UL_SYSCLKX & DLY_UL_PATH;
constant DPDFB_UL_PIMOFF_DELAY                : std_logic_vector(31 downto 0) := UL_SYSCLKX & DLY_UL_PIMOFF;

-- ***********************************
-- COMPONENTs
-- ***********************************
component RST_SYNC is
generic(
    DLY_NUM                                   : natural :=   3;
    MAX_FANOUT_NUM                            : integer := 200 
    );
port(
    RST_IN                                    : in  std_logic;
    CLK                                       : in  std_logic; 
    RST_OUT                                   : out std_logic  
    );         
end component;

component TDD_STRB_DLY is
generic(
    CLK_CNTDLY                                : natural        -- 0 ~ 8191 clock
    );
port(
    RST                                       : in  std_logic; -- Active high reset
    CLK                                       : in  std_logic; -- Clock
    
    BLK_BYPASS_IN                             : in  std_logic; -- '0' normal mode, '1' bypass mode
    
    BFN_STROBE_IN                             : in  std_logic;
    TDD_STROBE_IN                             : in  std_logic;

    BFNSTRB_DLY_OUT                           : out std_logic;
    TDDSTRB_DLY_OUT                           : out std_logic
    );
end component;

component MULTIBIT_CDC is
generic(
    BIT_WIDTH  : natural :=    16
    );
port(
    DATA_A_IN  : in  std_logic_vector(BIT_WIDTH-1 downto 0);

    CLK_B      : in  std_logic;
    DATA_B_OUT : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end component;

component POLY2MONO_CONV is
port(
    RST_LOW                                   : in  std_logic;
    CLK_LOW                                   : in  std_logic;
    CLK_HIGH                                  : in  std_logic;
    
    POLY_EVEN_IN                              : in  std_logic_vector(15 downto 0);  -- x1 Clock Domain signal
    POLY_ODD_IN                               : in  std_logic_vector(15 downto 0);  -- x1 Clock Domain signal
    
    MONO_DATA_OUT                             : out std_logic_vector(15 downto 0)   -- x2 Clock Domain signal
    );
end component;

component MONO2POLY_CONV is
port(
    RST_LOW                                   : in  std_logic;
    CLK_LOW                                   : in  std_logic;
    CLK_HIGH                                  : in  std_logic;
    
    MONO_DATA_IN                              : in  std_logic_vector(15 downto 0);  -- x2 Clock Domain signal
    
    POLY_EVEN_OUT                             : out std_logic_vector(15 downto 0);  -- x1 Clock Domain signal
    POLY_ODD_OUT                              : out std_logic_vector(15 downto 0)   -- x1 Clock Domain signal
    );
end component;

component NCO_SYMMETRY is
generic(
    DEVICE                                    : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2

    HOVS                                      : natural :=        2 ; -- HOVS = (Clock Frequency)/(Sampling Rate)
    SYMMETRY                                  : boolean :=    FALSE ; -- TRUE  : Symmetry Operation(+a/-a freq shift), Generate POS/NEG_SHIFT_PATH
                                                                      -- FALSE : Simplex Operation(+a freq shift), Only Generate POS_SHIFT_PATH
    POS_SHIFTH_PATH_NUM                       : natural :=        2 ; -- The Number of Positive Frequency Shifting Path Number
    NEG_SHIFTH_PATH_NUM                       : natural :=        1 ; -- The Number of Negative Frequency Shifting Path Number
    NCO_WIDTH                                 : natural :=       16 ; -- Sinusoidal Wave Sample Wdith
    RES_VAL                                   : natural :=    24576   -- Frequency Shift Step Resolution, 10kHz
    );
port(
    RST                                       : in  std_logic;
    CLK                                       : in  std_logic;

    NCO_WREN                                  : in  std_logic;
    NCO_WORD                                  : in  std_logic_vector(31 downto 0);

    NCO_FREQ_COMP_OFFSET                      : in  std_logic_vector(31 downto 0);

    DATA_P_SH_VLD_IN                          : in  std_logic_vector( POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift
    DATA_P_SH_I_IN                            : in  std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift
    DATA_P_SH_Q_IN                            : in  std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift

    DATA_P_SH_VLD_OUT                         : out std_logic_vector( POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift
    DATA_P_SH_I_OUT                           : out std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift
    DATA_P_SH_Q_OUT                           : out std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift

    DATA_N_SH_VLD_IN                          : in  std_logic_vector( NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_I_IN                            : in  std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_Q_IN                            : in  std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift

    DATA_N_SH_VLD_OUT                         : out std_logic_vector( NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_I_OUT                           : out std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_Q_OUT                           : out std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0)  -- Negative shift
    );
end component;

component SRL_DLY is
generic(
    HS_MODE   : boolean := FALSE; 

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK       : in  std_logic;
    
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_COUT : out std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end component;

component HBF_I_POLY is
port(
    RST                                       : in  std_logic;
    CLK                                       : in  std_logic;

    INPUT_DATA_I                              : in  std_logic_vector(15 downto 0);
    INPUT_DATA_Q                              : in  std_logic_vector(15 downto 0);

    OUTPUT_DATA_I_E                           : out std_logic_vector(15 downto 0);
    OUTPUT_DATA_I_O                           : out std_logic_vector(15 downto 0);
    OUTPUT_DATA_Q_E                           : out std_logic_vector(15 downto 0);
    OUTPUT_DATA_Q_O                           : out std_logic_vector(15 downto 0)
    );
end component;

component DPD_BLK is
generic(
    DEVICE                                    : string  := "ULTRASCALE";                      -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
   
    TX_ANT_NUM                                : natural :=           4 ;
    HOVS                                      : natural :=           1 ; 

    DPD_CORE_IMPLEMENTATION                   : boolean :=        TRUE ;
    DPD_CORE_LUT_OPTIMIZED                    : boolean :=       FALSE ;
    DPD_CORE_LUT_MEM_DEPTH                    : string  :=       "FULL";                      -- "FULL": 32x512x2, "HALF": 32x256x2
    DPD_CORE_LUT_RBTEST                       : boolean :=        TRUE ;
    DPD_CORE_QPOINT_SEL                       : boolean :=       FALSE ;
    DPD_CORE_LUT_DIMENSION                    : string  :=         "2D";                      -- "2D" or "3D"
    DPD_CORE_LUT_NUM                          : natural :=          32 ;
    DPD_CORE_TAP_NUM                          : natural :=          14 ; 
    DPD_CORE_RND_BIT                          : natural :=          13 ; 

    DPD_HC_IMPLEMENTATION                     : boolean :=        TRUE ;  
    DPD_ATT_IMPLEMENTATION                    : boolean :=        TRUE ;  

    DPD_FILTER_IMPLEMENTATION                 : boolean :=        TRUE ;  
    DPD_FILTER_COEF_FIX                       : boolean :=        TRUE ;        
    DPD_FILTER_COEF_NUM                       : natural :=        39   ;
    DPD_FILTER_RND_BIT                        : natural :=        15
    );
port(
    RST_DPD                                   : in  std_logic;                                -- DPD Reset , Active High
    CLK_DPD                                   : in  std_logic;                                -- DPD Operation Clock

    DPD_BLK_VLD_IN                            : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Block Input Sample Valid
    DPD_BLK_I_IN                              : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- DPD Block Input I Sample 
    DPD_BLK_Q_IN                              : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- DPD Block Input Q Sample 

    DPD_HC_VLD_OUT                            : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Output Sample Valid
    DPD_HC_I_OUT                              : out std_logic_array16(TX_ANT_NUM-1 downto 0); -- DPD HC Output I Sample 
    DPD_HC_Q_OUT                              : out std_logic_array16(TX_ANT_NUM-1 downto 0); -- DPD HC Output Q Sample 

    DPD_BLK_VLD_OUT                           : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Block Output Sample Valid
    DPD_BLK_I_OUT                             : out std_logic_array16(TX_ANT_NUM-1 downto 0); -- DPD Block Output I Sample 
    DPD_BLK_Q_OUT                             : out std_logic_array16(TX_ANT_NUM-1 downto 0); -- DPD Block Output Q Sample 

    DPD_CORE_BYPASS_IN                        : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Core Bypass

    DPD_GAIN_INDEX_IN                         : in  std_logic_array2( TX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
    DPD_QPOINT_SEL_IN                         : in  std_logic_array2( TX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection

    RST_CPU                                   : in  std_logic;                                -- CPU Reset , Active High
    CLK_CPU                                   : in  std_logic;                                -- CPU Operation Clock

    DPD_LUT_RB_TEST_EN_IN                     : in  std_logic;                                -- LUT Read Back Test

    DPD_LUT_SWITCH_CDC_STRB_IN                : in  std_logic;                                -- LUT Switch Control Register CDC Strobe
    DPD_LUT_INPUT_SWITCH_IN                   : in  std_logic_vector(19 downto 0);            -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN                  : in  std_logic_vector(19 downto 0);            -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN                      : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN                           : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- LUT Write Enable
    DPD_LUT_RDEN_IN                           : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- LUT Read  Enable
    DPD_LUT_ADDR_IN                           : in  std_logic_array15(TX_ANT_NUM-1 downto 0); -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN                          : in  std_logic_array32(TX_ANT_NUM-1 downto 0); -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT                         : out std_logic_array32(TX_ANT_NUM-1 downto 0); -- LUT Write IQ : I[31:16]/Q[15:0]

    DPD_HC_EN_IN                              : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Hard-Clipper Enable
    DPD_HC_FLAG_OUT                           : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Hard-Clipping Flag
    DPD_HC_TRSHD_IN                           : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- DPD Hard-Clipper Threshold Value

    DL_ATTEN_VALUE_IN                         : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- DL Attenuator Value

    FILTER_BYPASS_IN                          : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PA Protection Filter Bypass
    FILTER_COEF_WR_EN_IN                      : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- coefficient write enable(indirect)
    FILTER_COEF_RD_EN_IN                      : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- coefficient read  enable(indirect)
    FILTER_COEF_WR_DN_IN                      : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- coefficient write done(indirect)
    FILTER_COEF_ADDR_IN                       : in  std_logic_vector( 7 downto 0);            -- coefficient write addr:tas
    FILTER_COEF_WR_DATA_IN                    : in  std_logic_vector(15 downto 0);            -- coefficient write data(indirect) 
    FILTER_COEF_RD_DATA_OUT                   : out std_logic_vector(15 downto 0)             -- coefficient read  data(indirect) 
    );
end component;

component DACIF_ON is
generic(
    DEVICE                                    : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HOVS                                      : natural :=        2  
    );
port (
    RST                                       : in  std_logic;
    CLK                                       : in  std_logic;

    DATA_VLD_IN                               : in  std_logic;
    DATA_I_IN                                 : in  std_logic_vector(15 downto 0);
    DATA_Q_IN                                 : in  std_logic_vector(15 downto 0);

    CPU_CTRL_ONOFF                            : in  std_logic;  -- '1' : IQ On , '0' : IQ Off
    IQ_OFF                                    : in  std_logic;  -- '1' : IQ Off , '0' : IQ On
	STAGE_NUM								  : in  std_logic_vector(4-1 downto 0);  -- '1' : IQ Off , '0' : IQ On

    DATA_VLD_OUT                              : out std_logic;
    DATA_I_OUT                                : out std_logic_vector(15 downto 0);
    DATA_Q_OUT                                : out std_logic_vector(15 downto 0)
    );
end component;

component FBSW_CTRL is
generic(    
    TX_ANT_NUM                                : natural :=      4  ;
    FB_PATH_NUM                               : natural :=      2  ;
    RX_ANT_NUM                                : natural :=      4  ;
    SC_HOVS                                   : natural :=      1  ;

    DPD_PATH_PHASE                            : string  :=  "MONO" ; -- "MONO" or "POLY"
    PIM_IMPLEMENTATION                        : boolean :=   TRUE  ; -- R ?.?.? PIM 
    PIMD_BLK_TYPE                             : string  := "INTER" ; -- "INTER" or "INTRA"

    FB_ATTEN_IMPLEMENTATION                   : boolean :=   TRUE  ; -- TRUE : Using FB_ATTEN, FALSE : FB_ATTEN not implemented
    SC_IMPLEMENTATION                         : boolean :=   TRUE    -- TRUE : Using SC      , FALSE : SC       not implemented
    );
port(
    RST                                       : in  std_logic;                                -- Active high
    CLK                                       : in  std_logic; 
    
    FBSW_CNT_IN                               : in  std_logic_vector( 4 downto 0);            -- Feedback Switch Counter
    FB_VC_OUT                                 : out std_logic_vector( 4 downto 0);

    FBSW_START_TRIG_IN                        : in  std_logic;
    FBSW_START_RPLS_OUT                       : out std_logic;

    FBSW_SC_PATH_SEL_IN                       : in  std_logic_vector( 4 downto 0);

    AUTO_MODE_DONE_IN                         : in  std_logic_vector( FB_PATH_NUM-1 downto 0);

    FB_VLD_IN                                 : in  std_logic_vector( FB_PATH_NUM-1 downto 0);
    FB_MONO_I_IN                              : in  std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_MONO_Q_IN                              : in  std_logic_array16(FB_PATH_NUM-1 downto 0);

    FB_MONO_NCO_I_IN                          : in  std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_MONO_NCO_Q_IN                          : in  std_logic_array16(FB_PATH_NUM-1 downto 0);

    FB_POLY_EVEN_I_IN                         : in  std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_POLY_EVEN_Q_IN                         : in  std_logic_array16(FB_PATH_NUM-1 downto 0);

    FB_POLY_ODD_I_IN                          : in  std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_POLY_ODD_Q_IN                          : in  std_logic_array16(FB_PATH_NUM-1 downto 0);

    FB_VLD_OUT                                : out std_logic_vector( FB_PATH_NUM-1 downto 0);
    FB_MONO_I_OUT                             : out std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_MONO_Q_OUT                             : out std_logic_array16(FB_PATH_NUM-1 downto 0);

    FB_POLY_EVEN_I_OUT                        : out std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_POLY_EVEN_Q_OUT                        : out std_logic_array16(FB_PATH_NUM-1 downto 0);

    FB_POLY_ODD_I_OUT                         : out std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_POLY_ODD_Q_OUT                         : out std_logic_array16(FB_PATH_NUM-1 downto 0);

    -- For PATH_DGATT
    FB_FWD_DGATT_VALUE_IN                     : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    FB_RVS_DGATT_VALUE_IN                     : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    FB_DGATT_OUT                              : out std_logic_array16(FB_PATH_NUM-1 downto 0);

    -- For FB_LOOPBACK 
    SC_LOOPBACK_ON_IN                         : in  std_logic;                                -- Loopback Enable for Smart Capture Test, Test Only

    DL_DACIF_MONO_I_IN                        : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    DL_DACIF_MONO_Q_IN                        : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    DL_DACIF_POLY_EVEN_I_IN                   : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    DL_DACIF_POLY_EVEN_Q_IN                   : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    DL_DACIF_POLY_ODD_I_IN                    : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    DL_DACIF_POLY_ODD_Q_IN                    : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    -- For SC
    SC_DPDFB_PIM_MODE_SEL_IN                  : in  std_logic;

    DL_CFR_MONO_I_IN                          : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_CFR_MONO_Q_IN                          : in  std_logic_array16( TX_ANT_NUM-1 downto 0);

    DL_CFR_POLY_EVEN_I_IN                     : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_CFR_POLY_EVEN_Q_IN                     : in  std_logic_array16( TX_ANT_NUM-1 downto 0);

    DL_CFR_POLY_ODD_I_IN                      : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_CFR_POLY_ODD_Q_IN                      : in  std_logic_array16( TX_ANT_NUM-1 downto 0);


    DL_DPD_MONO_I_IN                          : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_DPD_MONO_Q_IN                          : in  std_logic_array16( TX_ANT_NUM-1 downto 0);

    DL_DPD_POLY_EVEN_I_IN                     : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_DPD_POLY_EVEN_Q_IN                     : in  std_logic_array16( TX_ANT_NUM-1 downto 0);

    DL_DPD_POLY_ODD_I_IN                      : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_DPD_POLY_ODD_Q_IN                      : in  std_logic_array16( TX_ANT_NUM-1 downto 0);


    DL_FB_ATT_MONO_I_IN                       : in  std_logic_array16(FB_PATH_NUM-1 downto 0);
    DL_FB_ATT_MONO_Q_IN                       : in  std_logic_array16(FB_PATH_NUM-1 downto 0);

    DL_FB_ATT_POLY_EVEN_I_IN                  : in  std_logic_array16(FB_PATH_NUM-1 downto 0);
    DL_FB_ATT_POLY_EVEN_Q_IN                  : in  std_logic_array16(FB_PATH_NUM-1 downto 0);

    DL_FB_ATT_POLY_ODD_I_IN                   : in  std_logic_array16(FB_PATH_NUM-1 downto 0);
    DL_FB_ATT_POLY_ODD_Q_IN                   : in  std_logic_array16(FB_PATH_NUM-1 downto 0);


    DL_PIM_3RD_IM_MIXER_I_IN                  : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_PIM_3RD_IM_MIXER_Q_IN                  : in  std_logic_array16( TX_ANT_NUM-1 downto 0);

    UL_PIM_ERROR_I_IN                         : in  std_logic_array16( RX_ANT_NUM-1 downto 0);
    UL_PIM_ERROR_Q_IN                         : in  std_logic_array16( RX_ANT_NUM-1 downto 0);

    UL_PIM_TARGET_I_IN                        : in  std_logic_array16( RX_ANT_NUM-1 downto 0);
    UL_PIM_TARGET_Q_IN                        : in  std_logic_array16( RX_ANT_NUM-1 downto 0);

    DL_PIM_CFR_I_IN                           : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_PIM_CFR_Q_IN                           : in  std_logic_array16( TX_ANT_NUM-1 downto 0);

    DL_PIM_INTER_DUC_DLY_I_IN                 : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_PIM_INTER_DUC_DLY_Q_IN                 : in  std_logic_array16( TX_ANT_NUM-1 downto 0);

    UL_PIM_DBG_I_IN                           : in  std_logic_array16( TX_ANT_NUM-1 downto 0); 
    UL_PIM_DBG_Q_IN                           : in  std_logic_array16( TX_ANT_NUM-1 downto 0); 

    DBG_PIM_MIXPS_I_IN                        : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DBG_PIM_MIXPS_Q_IN                        : in  std_logic_array16( TX_ANT_NUM-1 downto 0);


    SC_REF_VLD_OUT                            : out std_logic;

    SC_REF_I_OUT                              : out std_logic_vector(15 downto 0);
    SC_REF_Q_OUT                              : out std_logic_vector(15 downto 0);

    SC_DPD_I_OUT                              : out std_logic_vector(15 downto 0);
    SC_DPD_Q_OUT                              : out std_logic_vector(15 downto 0);

    SC_FB_I_OUT                               : out std_logic_vector(15 downto 0);
    SC_FB_Q_OUT                               : out std_logic_vector(15 downto 0);

    SC_PIM_SRC0_I_OUT                         : out std_logic_vector(15 downto 0);
    SC_PIM_SRC0_Q_OUT                         : out std_logic_vector(15 downto 0);

    SC_PIM_SRC1_I_OUT                         : out std_logic_vector(15 downto 0);
    SC_PIM_SRC1_Q_OUT                         : out std_logic_vector(15 downto 0);

    SC_PIM_DBG_I_OUT                          : out std_logic_vector(15 downto 0);
    SC_PIM_DBG_Q_OUT                          : out std_logic_vector(15 downto 0)

    );
end component;

component MONO_FIR_WRAPPER is
generic(
    HOVS                                      : natural := 1;
    RND_POINT                                 : natural := 15;    
    TAP_NUM                                   : natural := 52
    );
port(
    RST                                       : in  std_logic;
    CLK                                       : in  std_logic;

    BYPASS_IN                                 : in  std_logic;

    VALID_IN                                  : in  std_logic;
    I_DATA_IN                                 : in  std_logic_vector(15 downto 0);
    Q_DATA_IN                                 : in  std_logic_vector(15 downto 0);
    
    VALID_OUT                                 : out std_logic;
    I_DATA_OUT                                : out std_logic_vector(15 downto 0);
    Q_DATA_OUT                                : out std_logic_vector(15 downto 0)
    );
end component;

component PWRMEAS_MANTISSA is
generic(
    DEVICE                                    : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    CLK_DIV                                   : natural :=  2; -- CLK_DIV = (Clock Rate)/(Data Rate)
    DATA_WIDTH                                : natural := 16  -- Data bit width
    );
port(
    RST                                       : in  std_logic;
    CLK                                       : in  std_logic;
    
    FRAME_SYNC_IN                             : in  std_logic; -- BFN 10ms strobe
    TDD_SIG_IN                                : in  std_logic; -- TDD strobe, DL : '1', UL : '0', when FDD mode, always set high

    DATA_I_IN                                 : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    DATA_Q_IN                                 : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    PWR_UPDATE_DONE_OUT                       : out std_logic;
    PWR_OUT                                   : out std_logic_vector(31 downto 0)
    );
end component;

component PATH_DGATT is
generic(
    DEVICE                                    : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    RND_BIT                                   : natural :=       15 ;
    HOVS                                      : natural :=        1
    );
port(
    RST                                       : in  std_logic;
    CLK                                       : in  std_logic;

    DATA_VALID_IN                             : in  std_logic;
    DATA_I_IN                                 : in  std_logic_vector(15 downto 0);
    DATA_Q_IN                                 : in  std_logic_vector(15 downto 0);

    DGATT_VAL                                 : in  std_logic_vector(15 downto 0);

    DATA_VALID_OUT                            : out std_logic;
    DATA_I_OUT                                : out std_logic_vector(15 downto 0);
    DATA_Q_OUT                                : out std_logic_vector(15 downto 0)
    );
end component;

component PIMD_BLK is
generic(
    DEVICE                                    : string  := "ULTRASCALE";
   
    TX_ANT_NUM                                : natural :=           4 ;
    RX_ANT_NUM                                : natural :=           4 ;

    PIMD_BLK_TYPE                             : string  :=      "INTER"; -- "INTER" or "INTRA"
    PIM_SRC_NUM                               : natural :=           2 ; -- 2: self-conj, 3: the others conj

    PIMD_OPR_CLK_RATE                         : real    :=      245.76 ;
    PIMD_UL_CLK_RATE                          : real    :=      245.76 ;
    PIMD_OPR_SAMPLE_RATE                      : real    :=      245.76 ;
    PIMD_INTER_REF_SAMPLE_RATE                : real    :=      122.88 ;
    PIMD_ULINPUT_SAMPLE_RATE                  : real    :=      122.88 ;
    PIMD_ULOUTPUT_SAMPLE_RATE                 : real    :=      122.88 ;

    PIMD_CORE_LUT_OPTIMIZED                   : boolean :=        TRUE ;
    PIMD_CORE_LUT_MEM_DEPTH                   : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    PIMD_CORE_LUT_RBTEST                      : boolean :=        TRUE ; 
    PIMD_CORE_QPOINT_SEL                      : boolean :=        TRUE ; -- TRUE : PIMD_CORE Qpoint Selectable     FALSE : PIMD_CORE Qpoint Fixed
    PIMD_CORE_LUT_DIMENSION                   : string  :=         "2D"; -- "2D" or "3D"
    PIMD_CORE_LUT_NUM                         : natural :=          20 ;
    PIMD_CORE_TAP_NUM                         : natural :=          10 
    );
port(
    RST_PIMD                                  : in  std_logic;        -- Reset, Active High
    RST_CPU                                   : in  std_logic;

    CLK_PIMD                                  : in  std_logic;
    CLK_UL                                    : in  std_logic;
    CLK_CPU                                   : in  std_logic;


    INT_SYSPLL_LOCK_IN                        : in  std_logic;
    
    DL_PIM_REF_VLD_IN                         : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PIM Reference Source Valid,    DL Mixer Output
    DL_PIM_REF_I_IN                           : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- PIM Reference Source I sample, DL Mixer Output
    DL_PIM_REF_Q_IN                           : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- PIM Reference Source Q sample, DL Mixer Output

    DL_PIM_INTERBAND_VLD_IN                   : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PIM Reference Source Valid,    DL Mixer Output
    DL_PIM_INTERBAND_I_IN                     : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- PIM Reference Source I sample, DL Mixer Output
    DL_PIM_INTERBAND_Q_IN                     : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- PIM Reference Source Q sample, DL Mixer Output

    
    UL_PIM_TGT_VLD_IN                         : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM Target Source Valid,       UL DCIF Output
    UL_PIM_TGT_I_IN                           : in  std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Target Source I sample,    UL DCIF Output
    UL_PIM_TGT_Q_IN                           : in  std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Target Source Q sample,    UL DCIF Output

    UL_PIMD_VLD_OUT                           : out std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM Rejected Valid,            UL DDC Input
    UL_PIMD_I_OUT                             : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Rejected I sample,         UL DDC Input
    UL_PIMD_Q_OUT                             : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Rejected Q sample,         UL DDC Input

    UL_PIM_SC_ERR_I_OUT                       : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Error Source I sample,             SC Input
    UL_PIM_SC_ERR_Q_OUT                       : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Error Source Q sample,             SC Input

    UL_PIM_SC_TGT_I_OUT                       : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Target Source I sample,            SC Input
    UL_PIM_SC_TGT_Q_OUT                       : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Target Source Q sample,            SC Input

    UL_PIM_INTERB_DUCDLY_I_OUT                : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM InterBand DUC_DLY Source I sample, SC Input
    UL_PIM_INTERB_DUCDLY_Q_OUT                : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM InterBand DUC_DLY Source Q sample, SC Input

    UL_PIM_SC_CFR_I_OUT                       : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM CFR Source I sample,               SC Input
    UL_PIM_SC_CFR_Q_OUT                       : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM CFR Source Q sample,               SC Input

    UL_PIM_SC_3RD_IM_I_OUT                    : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM 3rd IM Mixer Source I sample,      SC Input
    UL_PIM_SC_3RD_IM_Q_OUT                    : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM 3rd IM Mixer Source Q sample,      SC Input

    UL_PIM_SC_DBG_I_OUT                       : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM 3rd IM Mixer Source I sample,      SC Input
    UL_PIM_SC_DBG_Q_OUT                       : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM 3rd IM Mixer Source Q sample,      SC Input

    DBG_PIM_MIXPS_I_OUT                       : out std_logic_array16(TX_ANT_NUM-1 downto 0); -- for Debug
    DBG_PIM_MIXPS_Q_OUT                       : out std_logic_array16(TX_ANT_NUM-1 downto 0); -- for Debug

    PIM_SC_INTER_PIM_DBG_SEL_IN               : in  std_logic_vector( 1 downto 0);
    PIM_SC_INTRA_PIM_DBG_SEL_IN               : in  std_logic_vector( 1 downto 0);

    PIM_DETECTOR_ON_IN                        : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- UL PIM Detect On
    PIM_MITIGATOR_ON_IN                       : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- UL PIM Detect On
 
    PIM_CFR_REF_SEL_IN                        : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
    -- lut 1 set
    PIM_CORE_BYPASS_IN                        : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PIM Core Bypass

    PIM_GAIN_INDEX_IN                         : in  std_logic_array2( TX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
    PIM_QPOINT_SEL_IN                         : in  std_logic_array2( TX_ANT_NUM-1 downto 0); -- PIM Core Binary Point Selection

    PIM_LUT_RB_TEST_EN_IN                     : in  std_logic;                                -- LUT Read Back Test

    PIM_LUT_SWITCH_CDC_STRB_IN                : in  std_logic;                                -- LUT Switch Control Register CDC Strobe
    PIM_LUT_INPUT_SWITCH_IN                   : in  std_logic_vector(19 downto 0);            -- LUT Input Mux Control
    PIM_LUT_OUTPUT_SWITCH_IN                  : in  std_logic_vector(19 downto 0);            -- LUT Output Switch Control

    PIM_LUT_UPDATE_SW_IN                      : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- LUT Update Switch
    PIM_LUT_WREN_IN                           : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- LUT Write Enable
    PIM_LUT_RDEN_IN                           : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- LUT Read  Enable
    PIM_LUT_ADDR_IN                           : in  std_logic_array15(TX_ANT_NUM-1 downto 0); -- LUT Depth & LUT Address
    PIM_LUT_WDATA_IN                          : in  std_logic_array32(TX_ANT_NUM-1 downto 0); -- LUT Write IQ : I[31:16]/Q[15:0]
    PIM_LUT_RDATA_OUT                         : out std_logic_array32(TX_ANT_NUM-1 downto 0); -- LUT Write IQ : I[31:16]/Q[15:0]
    -- 
    PIM_CORE_COEF_WR_EN_IN                    : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PIM Core coefficient write enable(indirect)
    PIM_CORE_COEF_RD_EN_IN                    : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PIM Core coefficient read  enable(indirect)
    PIM_CORE_COEF_WR_DN_IN                    : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PIM Core coefficient write done(indirect)
    PIM_CORE_COEF_ADDR_IN                     : in  std_logic_vector( 3 downto 0);            -- PIM Core coefficient write address
    PIM_CORE_COEF_I_WDATA_IN                  : in  std_logic_vector(20 downto 0);            -- PIM Core coefficient write data(indirect) 
    PIM_CORE_COEF_Q_WDATA_IN                  : in  std_logic_vector(20 downto 0);            -- PIM Core coefficient write data(indirect) 
    PIM_CORE_COEF_I_RDATA_OUT                 : out std_logic_vector(20 downto 0);            -- PIM Core coefficient read  data(indirect) 
    PIM_CORE_COEF_Q_RDATA_OUT                 : out std_logic_vector(20 downto 0);            -- PIM Core coefficient read  data(indirect) 

    PIM_FILTER_BYPASS_IN                      : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PA Protection Filter Bypass
    PIM_FILTER_COEF_WR_EN_IN                  : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- coefficient write enable(indirect)
    PIM_FILTER_COEF_RD_EN_IN                  : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- coefficient read  enable(indirect)
    PIM_FILTER_COEF_WR_DN_IN                  : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- coefficient write done(indirect)
    PIM_FILTER_COEF_ADDR_IN                   : in  std_logic_vector( 7 downto 0);            -- coefficient write address
    PIM_FILTER_COEF_WR_DATA_IN                : in  std_logic_vector(15 downto 0);            -- coefficient write data(indirect) 
    PIM_FILTER_COEF_RD_DATA_OUT               : out std_logic_vector(15 downto 0);            -- coefficient read  data(indirect) 

    PIM_NCO_WREN_IN                           : in  std_logic;
    PIM_NCO_WORD_IN                           : in  std_logic_vector(31 downto 0);
    -- selectable pim
    PIM_SLTB1_GAIN_INDEX_IN                   : in  std_logic_array2( TX_ANT_NUM-1 downto 0);
    PIM_SLTB1_QPOINT_SEL_IN                   : in  std_logic_array2( TX_ANT_NUM-1 downto 0);
    PIMDLY_SLTB1_VALUE_IN                     : in  std_logic_array12(TX_ANT_NUM-1 downto 0);           

    PIM_SLTB1_LUT_UPDATE_SW_IN                : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB1_LUT_WREN_IN                     : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    PIM_SLTB1_LUT_RDEN_IN                     : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Read  Enable
    PIM_SLTB1_LUT_ADDR_IN                     : in  std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
    PIM_SLTB1_LUT_WDATA_IN                    : in  std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    PIM_SLTB1_LUT_RDATA_OUT                   : out std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    
    PIM_SLTB2_GAIN_INDEX_IN                   : in  std_logic_array2( TX_ANT_NUM-1 downto 0);
    PIM_SLTB2_QPOINT_SEL_IN                   : in  std_logic_array2( TX_ANT_NUM-1 downto 0);
    PIMDLY_SLTB2_VALUE_IN                     : in  std_logic_array12(TX_ANT_NUM-1 downto 0);          

    PIM_SLTB2_LUT_UPDATE_SW_IN                : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB2_LUT_WREN_IN                     : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    PIM_SLTB2_LUT_RDEN_IN                     : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Read  Enable
    PIM_SLTB2_LUT_ADDR_IN                     : in  std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
    PIM_SLTB2_LUT_WDATA_IN                    : in  std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    PIM_SLTB2_LUT_RDATA_OUT                   : out std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]

    PIM_SLTB_INTRA_NCO_WREN_IN                : in  std_logic;
    PIM_SLTB_INTRA_NCO_WORD_IN                : in  std_logic_vector(31 downto 0);
    PIM_SLTB_INTER1_NCO_WREN_IN               : in  std_logic;
    PIM_SLTB_INTER1_NCO_WORD_IN               : in  std_logic_vector(31 downto 0);
    PIM_SLTB_INTER2_NCO_WREN_IN               : in  std_logic;
    PIM_SLTB_INTER2_NCO_WORD_IN               : in  std_logic_vector(31 downto 0);

    -- INTRA_BAND_SEL_IN                         : in  std_logic; 
    -- INTER_BAND_TYPE1_SEL_IN                   : in  std_logic_vector(1 downto 0);
    -- INTER_BAND_TYPE2_SEL_IN                   : in  std_logic_vector(1 downto 0);
	INTRA_BAND_SEL_IN                         : in  std_logic_vector(TX_ANT_NUM-1 downto 0);
    INTER_BAND_TYPE1_SEL_IN                   : in  std_logic_array2(TX_ANT_NUM-1 downto 0);
    INTER_BAND_TYPE2_SEL_IN                   : in  std_logic_array2(TX_ANT_NUM-1 downto 0);
    PIM_BIT_SHIFT_SEL_IN                      : in  std_logic_vector(1 downto 0);

    SHIFT_DIRECTION_INTRA_IN                  : in  std_logic_array2(TX_ANT_NUM-1 downto 0);
    SHIFT_DIRECTION_INTER1_IN                 : in  std_logic_array2(TX_ANT_NUM-1 downto 0);
    SHIFT_DIRECTION_INTER2_IN                 : in  std_logic_array2(TX_ANT_NUM-1 downto 0);
    -----    

    PIM_INTERBAND_DUC_GAIN_IN                 : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    DL_INTRAB_DLY_VALUE_IN                    : in  std_logic_array12(TX_ANT_NUM-1 downto 0);           
    DL_INTERB_CDLY_VALUE_IN                   : in  std_logic_array11(TX_ANT_NUM-1 downto 0);           
    DL_INTERB_FDLY_VALUE_IN                   : in  std_logic_array4( TX_ANT_NUM-1 downto 0);           
    PIMDLY_VALUE_IN                           : in  std_logic_array12(TX_ANT_NUM-1 downto 0);           

    PNPC_SEL_IN                               : in  std_logic_array2( RX_ANT_NUM-1 downto 0);
    PNPC_EN_IN                                : in  std_logic_vector( RX_ANT_NUM-1 downto 0); 
    PNPC_SET_IN                               : in  std_logic_vector( RX_ANT_NUM-1 downto 0); 
    PNPC_MU_SEL_IN                            : in  std_logic_array2( RX_ANT_NUM-1 downto 0); 
    PNPC_SETVAL_I_IN                          : in  std_logic_array16(RX_ANT_NUM-1 downto 0); 
    PNPC_SETVAL_Q_IN                          : in  std_logic_array16(RX_ANT_NUM-1 downto 0); 

    PNPC_TP_DC_IQ_OUT                         : out std_logic_array32(RX_ANT_NUM-1 downto 0); 

    UL_PIM_NCO_WREN_IN                        : in  std_logic;
    UL_PIM_NCO_WORD_IN                        : in  std_logic_vector(31 downto 0);

    UL_PIM_FREQ_COMP_WORD_IN                  : in  std_logic_vector(31 downto 0)
    );
end component;

component SMART_CAPTURE is
generic(
    DEVICE                                    : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    SC_EXPANSION                              : boolean := TRUE     ; -- 
    DPD_PATH_PHASE                            : string  := "MONO"   ; -- "MONO" or "POLY"
    STATIC_CAPTURE_COUNT                      : natural := 6        ; -- Static Capture Section on Feedback Switch Forward Counter (10ms)
    CAPTURE_DONE_COUNT                        : natural := 6        ; -- Capture Done Boundary on Feedback Switch Forward Counter  (10ms)
    HOVS                                      : natural := 1
    );
port(
    -- Common
    RST_DSP                                   : in  std_logic; 
    CLK_DSP                                   : in  std_logic;                     -- DSP Operation Clock
    CLK_CPU                                   : in  std_logic;                     -- CPU Operation Clock

    -- Sync Strobe
    FS_10MS_IN                                : in  std_logic;                     -- Frame Sync 10ms
    TDD_STROBE_IN                             : in  std_logic;                     -- TDD Strobe

    -- Capturing Sample Port
    REF_VALID_IN                              : in  std_logic;                     -- Reference Sample Valid

    CFR_I_IN                                  : in  std_logic_vector(15 downto 0); -- CFR output I data
    CFR_Q_IN                                  : in  std_logic_vector(15 downto 0); -- CFR output Q data

    DPD_I_IN                                  : in  std_logic_vector(15 downto 0); -- DPD output I data
    DPD_Q_IN                                  : in  std_logic_vector(15 downto 0); -- DPD output Q data

    FB_I_IN                                   : in  std_logic_vector(15 downto 0); -- Feedback I data 
    FB_Q_IN                                   : in  std_logic_vector(15 downto 0); -- Feedback Q data 

    PIM_SRC0_I_IN                             : in  std_logic_vector(15 downto 0); -- UL PIM Target I data
    PIM_SRC0_Q_IN                             : in  std_logic_vector(15 downto 0); -- UL PIM Target Q data

    PIM_SRC1_I_IN                             : in  std_logic_vector(15 downto 0); -- UL PIM Error  I data
    PIM_SRC1_Q_IN                             : in  std_logic_vector(15 downto 0); -- UL PIM Error  Q data

    PIM_DBG_I_IN                              : in  std_logic_vector(15 downto 0); -- UL PIM Debug  I data
    PIM_DBG_Q_IN                              : in  std_logic_vector(15 downto 0); -- UL PIM Debug  Q data

    -- Feedback Switch Information
    FB_VC_IN                                  : in  std_logic_vector( 4 downto 0); -- Feedback Switch Information 
    FB_SW_ROUND_START_IN                      : in  std_logic;                     -- Feeback Switch Period end signal 

    -- For DPD SW iteration Time Test
    FORCED_CAPTURE_CONTROL_IN                 : in  std_logic;                     -- 0 : Normal, 1 : Forced Enable
    FB_MANUAL_MODE_IN                         : in  std_logic;                     -- Feedback Switch Manual Mode, '1' Manual, '0' Auto

    -- Smart Capture Control & Status
    DEBOUNCING_TIME_IN                        : in  std_logic_vector( 9 downto 0); -- Smart Capture Debouncing Time at Feedback Switch 1st Frame 10ms 
    DPDFB_PIM_MODE_SEL_IN                     : in  std_logic;                     -- '0' : DPD mode , '1' : PIM Mode
    CAPTURE_CONTROL_IN                        : in  std_logic;                     -- '0' : Capture Disable, '1' : Capture Enable
    CAPTURE_COMPLETE_OUT                      : out std_logic;                     -- Capture Done Flag, '1' : done 

    CAP_SIZE_SEL_IN                           : in  std_logic;                     -- '0' : 8k       , '1' : 4k
    TDD_MODE_IN                               : in  std_logic;                     -- '0' : FDD mode , '1' : TDD mode    

    PATH_SEL_IN                               : in  std_logic_vector( 3 downto 0);
    DPD_DELAY_IN                              : in  std_logic_vector( 9 downto 0); -- DPD processing latency 
    FB_DELAY_IN                               : in  std_logic_vector( 9 downto 0); -- DPD output to Feedback input latency 
    PIM_REF_DELAY_IN                          : in  std_logic_vector( 9 downto 0); -- IM_GEN to PIMD_MIXER input latency 

    CAP_OFF_START_IN                          : in  std_logic_vector(21 downto 0); -- smart capture exception period start point
    CAP_OFF_STOP_IN                           : in  std_logic_vector(21 downto 0); -- smart capture exception period end point   
    STATIC_POSITION_IN                        : in  std_logic_vector(21 downto 0); -- static capture start position
    SC_LENGTH_IN                              : in  std_logic_vector( 8 downto 0); -- smart capture length
    MAX_PEAK_BO_GAIN_IN                       : in  std_logic_vector(15 downto 0); -- max peak backoff gain value
    CUR_PEAK_BO_GAIN_IN                       : in  std_logic_vector(15 downto 0); -- current peak backoff gain value

    CAP_FRAME_NUM_OUT                         : out std_logic_vector(12 downto 0); -- captured subframe number  
    CAP_FRAME_PEAK_OUT                        : out std_logic_vector(31 downto 0); -- captured subframe maximum peak value
    CAP_FRAME_PWR_OUT                         : out std_logic_vector(31 downto 0); -- captured subframe power value
    CAP_TIME_INDEX_OUT                        : out std_logic_vector(31 downto 0); -- captured time index

    -- CPU Access Interface : CPU Clock Domain
    CAP_MEM_SEL_IN                            : in  std_logic_vector( 2 downto 0); -- 
    CAP_MEM_OE_IN                             : in  std_logic;                     -- Capture Memory Operation Enable 
    CAP_MEM_ADDR_IN                           : in  std_logic_VECTOR(12 downto 0); -- Capture Memory Read Address  
    CAP_MEM_DATA_OUT                          : out std_logic_vector(31 downto 0)  -- Capture Memory Read Data
    );
end component;

component CPUIF_DSP_DPDSC is
generic(
    DPD_CORE_IMPLEMENTATION             : boolean :=  TRUE ;                            -- R 8.9.1 LUT 
    DPD_CORE_LUT_OPTIMIZED              : boolean := FALSE ;
    DPD_CORE_LUT_RBTEST                 : boolean :=  TRUE ;
    SC_IMPLEMENTATION                   : boolean :=  TRUE ;                            -- R 8.9.4 Smart Capture
    PIM_IMPLEMENTATION                  : boolean :=  TRUE ;                            -- R ?.?.? PIM 
    PIMD_BLk_TYPE                       : string  := "SELECTABLE";                      -- SELELCTABLE / INTER or INTRA
    PIM_CORE_LUT_OPTIMIZED              : boolean := FALSE ;
    PIM_CORE_LUT_RBTEST                 : boolean := FALSE ;

    RX_SSD_IMPLEMENTATION               : boolean :=  TRUE ;
    ADDR_WIDTH                          : natural :=    16 ;                            -- CPU Address Bitwidth
    WDATA_WIDTH                         : natural :=    32 ;                            -- CPU Write Data Bitwidth
    RDATA_WIDTH                         : natural :=    32 ;                            -- CPU Read  Data Bitwidth

    TX_ANT_NUM                          : natural :=     8 ; 
    RX_ANT_NUM                          : natural :=     8 
    );
port(
    -- Reset & Clock
    RST_CPU                             : in  std_logic;                                -- cpuif reset, '1': Reset
    CLK_CPU                             : in  std_logic;                                -- cpuif clock, faster than iclk/oclk  
    CLK_SC                              : in  std_logic;                                -- dpd operation clock, 122.88MHz for KDDI DB
    CLK_PIMD                            : in  std_logic;                                -- dpd operation clock, 122.88MHz for KDDI DB

    -- CPU Interface
    ADDR_CPU_IN                         : in  std_logic_vector( ADDR_WIDTH-1 downto 0); -- cpuif address input, Halfword address.
    WDATA_CPU_IN                        : in  std_logic_vector(WDATA_WIDTH-1 downto 0); -- cpuif data input
    RDATA_DPD_OUT                       : out std_logic_vector(RDATA_WIDTH-1 downto 0); -- cpuif data outputRDATA_CPU
    WREN_CPU_IN                         : in  std_logic;                                -- cpuif write enable, '1': active, synchronous with iclk
    RDEN_CPU_IN                         : in  std_logic;                                -- cpuif read enable, '1': active.
    RDVLD_CPU_OUT                       : out std_logic;
    
    -- DPD_CORE Control
    DPD_CORE_SET_STRB_OUT               : out std_logic_vector( 1 downto 0);
    DPD_CORE_GAIN_INDEX_OUT             : out std_logic_array2( TX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
    DPD_CORE_QPOINT_SEL_OUT             : out std_logic_array2( TX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection

    DPD_CORE_LUT_SWITCH_CDC_STRB_OUT    : out std_logic_vector( 3 downto 0);  -- unused
    DPD_CORE_LUT_INPUT_SWITCH_OUT       : out std_logic_array20(3 downto 0);  -- unused
    DPD_CORE_LUT_OUTPUT_SWITCH_OUT      : out std_logic_array20(3 downto 0);  -- unused

    DPD_CORE_LUT_RB_TEST_OUT            : out std_logic_vector( 3 downto 0);

    DPD_CORE_LUT_UPDATE_SW_OUT          : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_CORE_LUT_WREN_OUT               : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_CORE_LUT_RDEN_OUT               : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_CORE_LUT_ADDR_OUT               : out std_logic_array15(TX_ANT_NUM-1 downto 0);
    DPD_CORE_LUT_WDATA_OUT              : out std_logic_array32(TX_ANT_NUM-1 downto 0);
    DPD_CORE_LUT_RDATA_IN               : in  std_logic_array32(TX_ANT_NUM-1 downto 0);

    -- PIM_CORE Control
    PIM_DETECTOR_ON_IN                  : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
    PIM_MITIGATOR_ON_IN                 : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
    -- PIM (LUT dpd core)
    PIM_CORE_SET_STRB_OUT               : out std_logic_vector( 1 downto 0);
    PIM_CORE_GAIN_INDEX_OUT             : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
    PIM_CORE_QPOINT_SEL_OUT             : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection

    PIM_CORE_LUT_SWITCH_CDC_STRB_OUT    : out std_logic_vector( 3 downto 0);  -- unsued
    PIM_CORE_LUT_INPUT_SWITCH_OUT       : out std_logic_array20(3 downto 0);  -- unsued
    PIM_CORE_LUT_OUTPUT_SWITCH_OUT      : out std_logic_array20(3 downto 0);  -- unsued

    PIM_CORE_LUT_RB_TEST_OUT            : out std_logic_vector( 3 downto 0);  -- unsued

    PIM_CORE_LUT_UPDATE_SW_OUT          : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_CORE_LUT_WREN_OUT               : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_CORE_LUT_RDEN_OUT               : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_CORE_LUT_ADDR_OUT               : out std_logic_array15(TX_ANT_NUM-1 downto 0);
    PIM_CORE_LUT_WDATA_OUT              : out std_logic_array32(TX_ANT_NUM-1 downto 0);
    PIM_CORE_LUT_RDATA_IN               : in  std_logic_array32(TX_ANT_NUM-1 downto 0);
    -- selectable PIM_CORE 1 -- add
    PIM_SLTB1_DETECTOR_ON_IN            : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
    PIM_SLTB1_MITIGATOR_ON_IN           : in  std_logic_vector( RX_ANT_NUM-1 downto 0);

    PIM_SLTB1_CORE_SET_STRB_OUT         : out std_logic_vector( 1 downto 0);
    PIM_SLTB1_CORE_GAIN_INDEX_OUT       : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
    PIM_SLTB1_CORE_QPOINT_SEL_OUT       : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection

    PIM_SLTB1_CORE_LUT_UPDATE_SW_OUT    : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB1_CORE_LUT_WREN_OUT         : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB1_CORE_LUT_RDEN_OUT         : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB1_CORE_LUT_ADDR_OUT         : out std_logic_array15(TX_ANT_NUM-1 downto 0);
    PIM_SLTB1_CORE_LUT_WDATA_OUT        : out std_logic_array32(TX_ANT_NUM-1 downto 0);
    PIM_SLTB1_CORE_LUT_RDATA_IN         : in  std_logic_array32(TX_ANT_NUM-1 downto 0);
    -- selectable PIM_CORE 2 -- add
    PIM_SLTB2_DETECTOR_ON_IN            : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
    PIM_SLTB2_MITIGATOR_ON_IN           : in  std_logic_vector( RX_ANT_NUM-1 downto 0);

    PIM_SLTB2_CORE_SET_STRB_OUT         : out std_logic_vector( 1 downto 0);
    PIM_SLTB2_CORE_GAIN_INDEX_OUT       : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
    PIM_SLTB2_CORE_QPOINT_SEL_OUT       : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection

    PIM_SLTB2_CORE_LUT_UPDATE_SW_OUT    : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB2_CORE_LUT_WREN_OUT         : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB2_CORE_LUT_RDEN_OUT         : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB2_CORE_LUT_ADDR_OUT         : out std_logic_array15(TX_ANT_NUM-1 downto 0);
    PIM_SLTB2_CORE_LUT_WDATA_OUT        : out std_logic_array32(TX_ANT_NUM-1 downto 0);
    PIM_SLTB2_CORE_LUT_RDATA_IN         : in  std_logic_array32(TX_ANT_NUM-1 downto 0);
    --
    PIM_SLTB_INTRA_NCO_WREN_OUT         : out std_logic;   
    PIM_SLTB_INTRA_NCO_WORD_OUT         : out std_logic_vector( 31 downto 0);   
    PIM_SLTB_INTER1_NCO_WREN_OUT        : out std_logic;   
    PIM_SLTB_INTER1_NCO_WORD_OUT        : out std_logic_vector( 31 downto 0);   
    PIM_SLTB_INTER2_NCO_WREN_OUT        : out std_logic;   
    PIM_SLTB_INTER2_NCO_WORD_OUT        : out std_logic_vector( 31 downto 0);   

    PIMDLY_SLTB1_VALUE_OUT              : out std_logic_array12(TX_ANT_NUM-1 downto 0);
    PIMDLY_SLTB2_VALUE_OUT              : out std_logic_array12(TX_ANT_NUM-1 downto 0);

    -- PIM_SLTB_INTRA_BAND_SEL_OUT         : out std_logic;
	-- PIM_SLTB_INTER_BAND_TYPE1_SEL_OUT   : out std_logic_vector(1 downto 0);
    -- PIM_SLTB_INTER_BAND_TYPE2_SEL_OUT   : out std_logic_vector(1 downto 0);
	PIM_SLTB_INTRA_BAND_SEL_OUT         : out std_logic_vector(TX_ANT_NUM-1 downto 0);
    PIM_SLTB_INTER_BAND_TYPE1_SEL_OUT   : out std_logic_array2(TX_ANT_NUM-1 downto 0);
    PIM_SLTB_INTER_BAND_TYPE2_SEL_OUT   : out std_logic_array2(TX_ANT_NUM-1 downto 0);
    PIM_SLTB_BIT_SHIFT_SEL_OUT          : out std_logic_vector(1 downto 0);

    PIM_SLTB_SHIFT_DIRECTION_INTRA_OUT  : out std_logic_array2(TX_ANT_NUM-1 downto 0);
    PIM_SLTB_SHIFT_DIRECTION_INTER1_OUT : out std_logic_array2(TX_ANT_NUM-1 downto 0);
    PIM_SLTB_SHIFT_DIRECTION_INTER2_OUT : out std_logic_array2(TX_ANT_NUM-1 downto 0);

    ----- coef type pim core
    PIM_COMPLEX_FILTER_COEF_WREN_OUT    : out std_logic_vector(RX_ANT_NUM-1 downto 0);
    PIM_COMPLEX_FILTER_COEF_RDEN_OUT    : out std_logic_vector(RX_ANT_NUM-1 downto 0);
    PIM_COMPLEX_FILTER_COEF_WRDN_OUT    : out std_logic_vector(RX_ANT_NUM-1 downto 0);
    PIM_COMPLEX_FILTER_COEF_ADDR_OUT    : out std_logic_vector( 3 downto 0);
    PIM_COMPLEX_FILTER_COEF_I_WDATA_OUT : out std_logic_vector(20 downto 0);
    PIM_COMPLEX_FILTER_COEF_Q_WDATA_OUT : out std_logic_vector(20 downto 0);
    PIM_COMPLEX_FILTER_COEF_I_RDATA_IN  : in  std_logic_vector(20 downto 0);
    PIM_COMPLEX_FILTER_COEF_Q_RDATA_IN  : in  std_logic_vector(20 downto 0);
    -- ~
    PIM_SRC_INTRAB_DLY_STRB_OUT         : out std_logic;
    PIM_SRC_INTRAB_DLY_OUT              : out std_logic_array12(TX_ANT_NUM-1 downto 0);
                                                     
    PIM_SRC_INTERB_DLY_STRB_OUT         : out std_logic;       
    PIM_SRC_INTERB_CDLY_OUT             : out std_logic_array11(TX_ANT_NUM-1 downto 0);
    PIM_SRC_INTERB_FDLY_OUT             : out std_logic_array4( TX_ANT_NUM-1 downto 0);
                                                    
    PIM_REF_DLY_STRB_OUT                : out std_logic;      
    PIM_REF_SAMPLE_DLY_OUT              : out std_logic_array12(TX_ANT_NUM-1 downto 0);
                                                    
    PIM_UL_DLY_STRB_OUT                 : out std_logic;       
    PIM_UL_SAMPLE_DLY_OUT               : out std_logic_array12(RX_ANT_NUM-1 downto 0);

    PNPC_EN_OUT                         : out std_logic_vector(RX_ANT_NUM-1 downto 0);
    PNPC_SET_OUT                        : out std_logic_vector(RX_ANT_NUM-1 downto 0);

    PNPC_MU_SEL_STRB_OUT                : out std_logic; 
    PNPC_MU_SEL_OUT                     : out std_logic_array2(RX_ANT_NUM-1 downto 0);

    PNPC_SETVAL_STRB_OUT                : out std_logic;
    PNPC_SETVAL_I_OUT                   : out std_logic_array16(RX_ANT_NUM-1 downto 0);                    
    PNPC_SETVAL_Q_OUT                   : out std_logic_array16(RX_ANT_NUM-1 downto 0);                    

    PNPC_TP_DC_IQ_IN                    : in  std_logic_array32(RX_ANT_NUM-1 downto 0);                    

    PIM_UL_MIXER_FREQ_ERR_COMP_STRB_OUT : out std_logic;                    
    PIM_UL_MIXER_FREQ_ERR_COMP_WORD_OUT : out std_logic_vector(31 downto 0);                    

    -- SMART_CAPTURE Control
    SC_CONTROL_OUT                      : out std_logic;
    SC_COMPLETE_FLAG_IN                 : in  std_logic;
    SC_TDD_MODE_OUT                     : out std_logic;
    SC_FORCED_MODE_OUT                  : out std_logic;
    SC_DEBOUNCING_TIME_OUT              : out std_logic_vector( 9 downto 0);
    SC_CAP_SIZE_SEL_OUT                 : out std_logic;
    SC_DPDFB_PIM_MODE_SEL_OUT           : out std_logic; 

    SC_PATH_SEL_STRB_OUT                : out std_logic;
    SC_PATH_SEL_OUT                     : out std_logic_vector( 4 downto 0);

    SC_CAP_MEMORY_SEL_OUT               : out std_logic_vector( 2 downto 0);
    SC_DPD_CORE_HC_LATENCY_OUT          : out std_logic_vector( 9 downto 0);
    SC_FB_LATENCY_OUT                   : out std_logic_vector( 9 downto 0);
    SC_REF_LATENCY_OUT                  : out std_logic_vector( 9 downto 0);
    SC_CAP_OFF_START_OUT                : out std_logic_vector(21 downto 0);
    SC_CAP_OFF_STOP_OUT                 : out std_logic_vector(21 downto 0);
    SC_STATIC_POSITION_OUT              : out std_logic_vector(21 downto 0);
    SC_STATIC_LENGTH_OUT                : out std_logic_vector( 8 downto 0);
    SC_MAX_PEAK_BO_GAIN_OUT             : out std_logic_vector(15 downto 0);
    SC_CUR_PEAK_BO_GAIN_OUT             : out std_logic_vector(15 downto 0);
    SC_SUB_PWR_IN                       : in  std_logic_vector(31 downto 0);
    SC_SUB_PEAK_IN                      : in  std_logic_vector(31 downto 0);
    SC_SUB_PEAK_NUM_IN                  : in  std_logic_vector(12 downto 0);
    SC_TIME_INDEX_IN                    : in  std_logic_vector(31 downto 0);

    SC_INTER_PIM_DBG_SEL_OUT            : out std_logic_vector( 1 downto 0);
    SC_INTRA_PIM_DBG_SEL_OUT            : out std_logic_vector( 1 downto 0);

    SC_MEM_RDEN_OUT                     : out std_logic;
    SC_MEM_ADDR_OUT                     : out std_logic_vector(12 downto 0);
    SC_MEM_RDATA_IN                     : in  std_logic_vector(31 downto 0);
    
    UL_MON0_DATA_IN                     : in  std_logic_vector(31 downto 0);
    UL_MON0_VLD_IN                      : in  std_logic;
    UL_MON1_DATA_IN                     : in  std_logic_vector(31 downto 0);
    UL_MON1_VLD_IN                      : in  std_logic;
    UL_MON2_DATA_IN                     : in  std_logic_vector(31 downto 0);
    UL_MON2_VLD_IN                      : in  std_logic;

    -- SSD Control
    SSD_PATH_SEL_OUT                    : out std_logic_vector( 4 downto 0);
    SSD_CTRL_OUT                        : out std_logic;
    SSD_PERIOD_OUT                      : out std_logic_vector( 9 downto 0);
    SSD_LENGTH_PER_SWITCH_OUT           : out std_logic_vector(16 downto 0);
    SSD_ACCU_LENGTH_OUT                 : out std_logic_vector(16 downto 0);
    SSD_ACCU_DONE_IN                    : in  std_logic;
    SSD_GAIN_OUT                        : out std_logic_vector(15 downto 0);
    SSD_PTN_WREN_OUT                    : out std_logic;
    SSD_PTN_WADDR_OUT                   : out std_logic_vector( 8 downto 0);
    SSD_PTN_WDATA_OUT                   : out std_logic_vector(31 downto 0);
    SSD_MEM_RDEN_OUT                    : out std_logic;
    SSD_MEM_ADDR_OUT                    : out std_logic_vector( 9 downto 0);
    SSD_MEM_RDATA_IN                    : in  std_logic_vector(31 downto 0);
    -- H/W alrm gathering
    SIG_SUS_DLOFF_IN                    : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    CLOCK_FAIL_FLAG_IN                  : in  std_logic_vector( TX_ANT_NUM-1 downto 0)
    );
end component;

component DACIF_PHASE_TESTER is
port (
    RST                                       : in  std_logic;
    CLK                                       : in  std_logic;

    BFN_STRB_IN                               : in  std_logic;
    TDD_IN                                    : in  std_logic;

    TEST_ENB_IN                               : in  std_logic;   -- '1': Phase test enable, '0': disable
    REF_SEL_IN                                : in  std_logic;   -- '1': BFN_STRB, '0': TDD 
    PATH_AB_SWAP_IN                           : in  std_logic;   -- '1': Swap A/B, '0': normal
    PATH_REVERSE_IN                           : in  std_logic;   -- '1': Reverse 0 <-> (TX_ANT_NUM-1), '0': normal
    REPEAT_ENB_IN                             : in  std_logic;   -- '1': Repeat enable, '0': repeat disable
    DACIF_DEFAULT_IN                          : in  std_logic_vector((TX_ANT_NUM-1) downto 0); -- DACIF default value for phase test

    OFFSET_IN                                 : in  std_logic_vector(23 downto 0); -- Offset from BFN_STRB/TDD
    PERIOD_IN                                 : in  std_logic_vector(23 downto 0); -- Period on/off for one path
    ON_DURATION_IN                            : in  std_logic_vector(23 downto 0); -- On duration of one period

    DACIF_ON_IN                               : in  std_logic_vector((TX_ANT_NUM-1) downto 0);  -- '1' : IQ On , '0' : IQ Off
    DACIF_ON_OUT                              : out std_logic_vector((TX_ANT_NUM-1) downto 0)   -- '1' : IQ On , '0' : IQ Off
    );
end component;

component DPD_DUMP_MUX is
generic(
    DPD_PATH_PHASE                            : string  := "MONO"; -- "MONO" or "POLY"
    DPD_CLK_SEL                               : natural :=     8 ; -- 
    TX_ANT_NUM                                : natural :=     4 ; -- The Number of TX Antenna Paths 
    FB_PATH_NUM                               : natural :=     4   -- The Number of FB Paths 
    );
port(
    RST                                       : in  std_logic; -- Reset, Active High
    CLK_SYS                                   : in  std_logic; -- System Clock :  30.72 MHz
    CLK_SYSX2                                 : in  std_logic; --  2x(CLK_SYS) :  61.44 MHz
    CLK_SYSX3                                 : in  std_logic; --  3x(CLK_SYS) :  92.16 MHz
    CLK_SYSX4                                 : in  std_logic; --  4x(CLK_SYS) : 122.88 MHz
    CLK_SYSX5                                 : in  std_logic; --  5x(CLK_SYS) : 153.60 MHz
    CLK_SYSX6                                 : in  std_logic; --  6x(CLK_SYS) : 184.32 MHz
    CLK_SYSX8                                 : in  std_logic; --  8x(CLK_SYS) : 245.76 MHz
    CLK_SYSX10                                : in  std_logic; -- 10x(CLK_SYS) : 307.20 MHz
    CLK_SYSX12                                : in  std_logic; -- 12x(CLK_SYS) : 368.64 MHz
    CLK_SYSX16                                : in  std_logic; -- 16x(CLK_SYS) : 491.52 MHz
    CLK_SYSX20                                : in  std_logic; -- 20x(CLK_SYS) : 614.40 MHz

    DUMP_POINT_SEL_STRB_IN                    : in  std_logic;
    DUMP_POINT_SEL_IN                         : in  std_logic_vector( 7 downto 0); -- Dump Point Selection

    CFR_OUTPUT_BFN_STRB_IN                    : in  std_logic;
    CFR_OUTPUT_VLD_IN                         : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    CFR_OUTPUT_IQ_IN                          : in  std_logic_array32(TX_ANT_NUM-1 downto 0);

    DPD_OUTPUT_BFN_STRB_IN                    : in  std_logic;
    DPD_OUTPUT_VLD_IN                         : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_OUTPUT_MONO_IQ_IN                     : in  std_logic_array32(TX_ANT_NUM-1 downto 0);
    DPD_OUTPUT_POLY_IQ_EVEN_IN                : in  std_logic_array32(TX_ANT_NUM-1 downto 0);
    DPD_OUTPUT_POLY_IQ_ODD_IN                 : in  std_logic_array32(TX_ANT_NUM-1 downto 0);

    FBATT_INPUT_BFN_STRB_IN                   : in  std_logic;
    FBATT_INPUT_VLD_IN                        : in  std_logic_vector( FB_PATH_NUM-1 downto 0);
    FBATT_INPUT_MONO_IQ_IN                    : in  std_logic_array32(FB_PATH_NUM-1 downto 0);
    FBATT_INPUT_POLY_IQ_EVEN_IN               : in  std_logic_array32(FB_PATH_NUM-1 downto 0);
    FBATT_INPUT_POLY_IQ_ODD_IN                : in  std_logic_array32(FB_PATH_NUM-1 downto 0);

    DUMP_BFN_STRB_OUT                         : out std_logic_vector( 1 downto 0); -- Delayed 10ms Frame Sync Strobe for DUMP                 
    DUMP_DVLD_OUT                             : out std_logic_vector( 1 downto 0); -- Dump Sample Valid
    DUMP_DATA_OUT                             : out std_logic_array32(1 downto 0)  -- Dump Sample
    );
end component;

component RX_SSD is
generic(
    DEVICE                                    : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    RX_SSD_IMPLEMENTATION                     : boolean :=     TRUE ;
    TX_ANT_NUM                                : natural :=       4  ;
    FB_PATH_NUM                               : natural :=       1  ;
    HOVS                                      : natural :=       2  
    );
port(
    RST_DSP                                   : in  std_logic;
    CLK_DSP                                   : in  std_logic;

    -- Control
    PATH_SEL_IN                               : in  std_logic_vector( 4 downto 0);
    CTRL_EN_IN                                : in  std_logic;
    REPEAT_PER_SW_IN                          : in  std_logic_vector(16 downto 0);
    ACCU_LENGTH_IN                            : in  std_logic_vector(16 downto 0);
    PATTERN_GAIN_IN                           : in  std_logic_vector(15 downto 0);

    ACCU_DONE_OUT                             : out std_logic;

    -- FB SW Info
    FBSW_START_TRIG_IN                        : in  std_logic;
    FB_VC_IN                                  : in  std_logic_vector( 4 downto 0);

    -- Traffic
    REF_FS_10ms_IN                            : in  std_logic;

    DL_VLD_IN                                 : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DL_I_IN                                   : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    DL_Q_IN                                   : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    REF_FS_10ms_OUT                           : out std_logic;

    DL_VLD_OUT                                : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    DL_I_OUT                                  : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    DL_Q_OUT                                  : out std_logic_array16(TX_ANT_NUM-1 downto 0);

    FB_FS_10ms_IN                             : in  std_logic;

    FB_VLD_IN                                 : in  std_logic_vector( FB_PATH_NUM-1 downto 0);
    FB_I_IN                                   : in  std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_Q_IN                                   : in  std_logic_array16(FB_PATH_NUM-1 downto 0);

    -- CPU Domain
    RST_CPU                                   : in  std_logic;
    CLK_CPU                                   : in  std_logic;

    PTN_WREN_IN                               : in  std_logic;
    PTN_WADDR_IN                              : in  std_logic_vector( 8 downto 0);
    PTN_WDATA_IN                              : in  std_logic_vector(31 downto 0);

    MEM_RDEN_IN                               : in  std_logic;
    MEM_ADDR_IN                               : in  std_logic_vector( 9 downto 0);
    MEM_DATA_OUT                              : out std_logic_vector(31 downto 0)
    );
end component;

component XPOLY_CONV_XPOLY_16B is
generic(
    WIDE_nPOLY                  : integer :=           4 ; -- available set : 2, 4, 4
    NARROW_nPOLY                : integer :=           2 ; -- available set : 1, 2, 1
    WIDE_TO_NARROW_USAGE        : boolean :=        TRUE ; --  Ex) 4poly -> 2poly 
    NARROW_TO_WIDE_USAGE        : boolean :=        TRUE   --  Ex) 2poly -> 4poly
    );
port(
    RST_IN                      : in  std_logic; -- COMMON RST
    -- CAUTION: Each CLK must be Sync. phase!
    WIDE_CLK                    : in  std_logic; -- LOW SPEED CLK
    NARROW_CLK                  : in  std_logic; -- HIGH SPEED CLK

    NARROW_CLK_PROC_DLY         : out std_logic_vector(15 downto 0);

    -- WIDE TO NARROW
    WIDE_NARROW_SYNC_IN         : in  std_logic;
    WIDE_NARROW_VALID_IN        : in  std_logic;
    WIDE_NARROW_DATA_IN         : in  std_logic_array16(WIDE_nPOLY-1 downto 0);
    WIDE_NARROW_SYNC_OUT        : out std_logic;
    WIDE_NARROW_VALID_OUT       : out std_logic;
    WIDE_NARROW_DATA_OUT        : out std_logic_array16(NARROW_nPOLY-1 downto 0);

    -- NARROW TO WIDE
    NARROW_WIDE_SYNC_IN         : in  std_logic;
    NARROW_WIDE_VALID_IN        : in  std_logic;
    NARROW_WIDE_DATA_IN         : in  std_logic_array16(NARROW_nPOLY-1 downto 0);
    NARROW_WIDE_SYNC_OUT        : out std_logic;
    NARROW_WIDE_VALID_OUT       : out std_logic;
    NARROW_WIDE_DATA_OUT        : out std_logic_array16(WIDE_nPOLY-1 downto 0)
    );
end component; 

component DPD_SIMPLE_DPRAM is
generic(
    RAM_TYPE                    : string  := "block"       ; -- "auto" or "distributed" or "block" or "ultra" 
    CLOCKING_MODE               : string  := "common_clock"; -- "common_clock" or "independent_clock"
    OPERATING_MODE              : string  := "read_first"  ; -- "no_change" or "read_first" or "write_first"

    A_ADDR_DEPTH                : integer :=  1024         ;
    A_DATA_WIDTH                : integer :=     8         ;

    B_ADDR_DEPTH                : integer :=  1024         ;
    B_DATA_WIDTH                : integer :=     8         ;

    READ_LATENCY                : integer :=     2         ;

    RAM_INIT_FILE               : string  := "none"        ; 
    RAM_INIT_VALUE              : string  := "0" 
    );
port(
    CLK_A                       : in  std_logic;
    EN_A                        : in  std_logic;
    WE_A                        : in  std_logic;
    ADDR_A                      : in  std_logic_vector(integer(floor(log2(real(A_ADDR_DEPTH-1)))) downto 0);
    DATA_A                      : in  std_logic_vector(A_DATA_WIDTH-1 downto 0);

    CLK_B                       : in  std_logic;
    EN_B                        : in  std_logic;
    ADDR_B                      : in  std_logic_vector(integer(floor(log2(real(B_ADDR_DEPTH-1)))) downto 0);
    DATA_B                      : out std_logic_vector(B_DATA_WIDTH-1 downto 0)
    );
end component;

component hbf_decimation is
	generic (
		HOVS							: integer := 1;
		TAP_ORDER                   	: integer := 12;
		
		WIDTH_IN                    	: integer := 16;
		WIDTH_OUT                   	: integer := 16;
		WIDTH_COEFF                 	: integer := 16;
		BINARY_POINT                	: integer := 15
	);
	port(		
		i_clk							: in  std_logic;

		i_valid							: in  std_logic;
		i_data_i_even					: in  std_logic_vector(WIDTH_IN-1 downto 0);
		i_data_q_even					: in  std_logic_vector(WIDTH_IN-1 downto 0);
		i_data_i_odd					: in  std_logic_vector(WIDTH_IN-1 downto 0);
		i_data_q_odd					: in  std_logic_vector(WIDTH_IN-1 downto 0);

		o_valid 	                    : out std_logic;
		o_data_i						: out std_logic_vector(WIDTH_OUT-1 downto 0);
		o_data_q						: out std_logic_vector(WIDTH_OUT-1 downto 0)
	);
end component hbf_decimation;

component srl16e_dly is
	generic(
		DEVICE                           : string  := "ULTRASCALE";
		HS_MODE                          : boolean :=       FALSE;

		BIT_WIDTH                        : natural;
		DELAY_NUM                        : natural
	);
	port(
		clk                              : in  std_logic;

		data_in                          : in  std_logic_vector(BIT_WIDTH-1 downto 0);
		data_out                         : out std_logic_vector(BIT_WIDTH-1 downto 0)
	);
end component srl16e_dly;


-- ***********************************
-- SIGNALs
-- ***********************************
-- Reset & Clock
signal clk_unstable                           : std_logic;

signal rst_dl                                 : std_logic;
signal rst_dl_dpd                             : std_logic;
signal rst_fb                                 : std_logic;
signal rst_ul                                 : std_logic;

signal CLK_VECTOR                             : std_logic_vector(19 downto 0);
signal CLK_DPD                                : std_logic;
signal CLK_DL                                 : std_logic;
signal CLK_FB                                 : std_logic;
signal CLK_UL                                 : std_logic;

-- BFN & TDD Strobe 
signal dl_bfn_strb_align_dly                  : std_logic;
signal dl_ssb_strb_align_dly                  : std_logic;
signal dl_tdd_strb_align_dly                  : std_logic;
signal dl_bcf_enb_align_dly                   : std_logic;

signal dl_bfn_strb_mixer_dly                  : std_logic;
signal dl_ssb_strb_mixer_dly                  : std_logic;
signal dl_tdd_strb_mixer_dly                  : std_logic;
signal dl_bcf_enb_mixer_dly                   : std_logic;

signal dl_bfn_strb_rxssd_dly                  : std_logic;                                 
signal dl_ssb_strb_rxssd_dly                  : std_logic;                                 
signal dl_tdd_strb_rxssd_dly                  : std_logic;                                 
signal dl_bcf_enb_rxssd_dly                   : std_logic;

signal dl_bfn_strb_dpdcore_dly                : std_logic;
signal dl_ssb_strb_dpdcore_dly                : std_logic;
signal dl_tdd_strb_dpdcore_dly                : std_logic;
signal dl_bcf_enb_dpdcore_dly                 : std_logic;

signal dl_bfn_strb_dpdhc_dly                  : std_logic;
signal dl_ssb_strb_dpdhc_dly                  : std_logic;
signal dl_tdd_strb_dpdhc_dly                  : std_logic;
signal dl_bcf_enb_dpdhc_dly                   : std_logic;

signal dl_bfn_strb_dpdatt_dly                 : std_logic;
signal dl_ssb_strb_dpdatt_dly                 : std_logic;
signal dl_tdd_strb_dpdatt_dly                 : std_logic;
signal dl_bcf_enb_dpdatt_dly                  : std_logic;

signal dl_bfn_strb_dpdfir_dly                 : std_logic;
signal dl_ssb_strb_dpdfir_dly                 : std_logic;
signal dl_tdd_strb_dpdfir_dly                 : std_logic;
signal dl_bcf_enb_dpdfir_dly                  : std_logic;

signal dl_bfn_strb_dacif_dly                  : std_logic;
signal dl_ssb_strb_dacif_dly                  : std_logic;
signal dl_tdd_strb_dacif_dly                  : std_logic;
signal dl_bcf_enb_dacif_dly                   : std_logic;

signal fb_bfn_strb_align_dly                  : std_logic;
signal fb_ssb_strb_align_dly                  : std_logic;
signal fb_tdd_strb_align_dly                  : std_logic;

signal fb_bfn_strb_sw_dly                     : std_logic;
signal fb_ssb_strb_sw_dly                     : std_logic;
signal fb_tdd_strb_sw_dly                     : std_logic;

signal fb_bfn_strb_fir_dly                    : std_logic;
signal fb_ssb_strb_fir_dly                    : std_logic;
signal fb_tdd_strb_fir_dly                    : std_logic;

signal fb_bfn_strb_att_dly                    : std_logic;
signal fb_ssb_strb_att_dly                    : std_logic;
signal fb_tdd_strb_att_dly                    : std_logic;

signal pwr_msr_strb_align_dly                 : std_logic;
signal pwr_msr_strb_sw_dly                    : std_logic;

signal ul_bfn_strb_align_dly                  : std_logic;
signal ul_tdd_strb_align_dly                  : std_logic;
signal ul_bcf_enb_align_dly                   : std_logic;

signal ul_bfn_strb_hbf_i_dly                  : std_logic;
signal ul_tdd_strb_hbf_i_dly                  : std_logic;
signal ul_bcf_enb_hbf_i_dly                   : std_logic;

signal ul_bfn_strb_mixps_dly                  : std_logic;
signal ul_tdd_strb_mixps_dly                  : std_logic;
signal ul_bcf_enb_mixps_dly                   : std_logic;

signal ul_bfn_strb_buf_dly                    : std_logic;
signal ul_tdd_strb_buf_dly                    : std_logic;
signal ul_bcf_enb_buf_dly                     : std_logic;

signal ul_bfn_strb_pimd_dly                   : std_logic;
signal ul_tdd_strb_pimd_dly                   : std_logic;
signal ul_bcf_enb_pimd_dly                    : std_logic;

signal ul_bfn_strb_mixns_dly                  : std_logic;
signal ul_tdd_strb_mixns_dly                  : std_logic;
signal ul_bcf_enb_mixns_dly                   : std_logic;

signal ul_bfn_strb_hbf_d_dly                  : std_logic;
signal ul_tdd_strb_hbf_d_dly                  : std_logic;
signal ul_bcf_enb_hbf_d_dly                   : std_logic;

signal ul_bfn_strb_hbf_d_cdc_dly              : std_logic;
signal ul_tdd_strb_hbf_d_cdc_dly              : std_logic;
signal ul_bcf_enb_hbf_d_cdc_dly               : std_logic;

signal ul_bfn_strb_dly                        : std_logic;
signal ul_tdd_strb_dly                        : std_logic;
signal ul_bcf_enb_dly                         : std_logic;

-- CDC Processing Signals 
signal dpdcore_bypass_sh                      : std_logic_array2(TX_ANT_NUM-1 downto 0);
signal dpdfir_bypass_sh                       : std_logic_array2(TX_ANT_NUM-1 downto 0);
signal dacif_bypass_sh                        : std_logic_array2(TX_ANT_NUM-1 downto 0);
signal fbfir_bypass_sh                        : std_logic_array2(FB_PATH_NUM-1 downto 0);

signal sc_dpdhc_dly_lsb_sh                    : std_logic_vector( 1 downto 0);
signal sc_fb_dly_lsb_sh                       : std_logic_vector( 1 downto 0);

signal dl_dpdcore_gain_index_cdc              : std_logic_array2( TX_ANT_NUM-1 downto 0); 
signal dl_dpdcore_qpoint_sel_cdc              : std_logic_array2( TX_ANT_NUM-1 downto 0); 

signal dl_dpdhc_trshd_cdc                     : std_logic_array16(TX_ANT_NUM-1 downto 0);  
signal dl_dpdatt_cdc                          : std_logic_array16(TX_ANT_NUM-1 downto 0);  

signal dl_dacif_phtest_offset_cdc             : std_logic_vector(23 downto 0);             
signal dl_dacif_phtest_period_cdc             : std_logic_vector(23 downto 0);            
signal dl_dacif_phtest_on_duration_cdc        : std_logic_vector(23 downto 0);             

signal fb_fwd_att_value_cdc                   : std_logic_array16(TX_ANT_NUM-1 downto 0);  
signal fb_rvs_att_value_cdc                   : std_logic_array16(TX_ANT_NUM-1 downto 0);  

signal ul_pimcore_gain_index_cdc              : std_logic_array2( RX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
signal ul_pimcore_qpoint_sel_cdc              : std_logic_array2( RX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection

signal pim_interb_duc_gain_cdc                : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal ul_pimsrc_intrab_dly_cdc               : std_logic_array12(TX_ANT_NUM-1 downto 0);

signal ul_pimsrc_interb_cdly_cdc              : std_logic_array11(TX_ANT_NUM-1 downto 0);
signal ul_pimsrc_interb_fdly_cdc              : std_logic_array4( TX_ANT_NUM-1 downto 0);

signal ul_pim_ref_sample_dly_cdc              : std_logic_array12(TX_ANT_NUM-1 downto 0);

signal ul_pim_pnpc_sel_cdc                    : std_logic_array2( RX_ANT_NUM-1 downto 0);
signal ul_pnpc_mu_sel_cdc                     : std_logic_array2( RX_ANT_NUM-1 downto 0);

signal ul_pnpc_setval_i_cdc                   : std_logic_array16(RX_ANT_NUM-1 downto 0);                    
signal ul_pnpc_setval_q_cdc                   : std_logic_array16(RX_ANT_NUM-1 downto 0);                    

signal ul_pim_ul_mixer_freq_err_comp_word_cdc : std_logic_vector(31 downto 0);                    

signal pim_mitigator_on                       : std_logic := '0';
signal pim_mitigator_on_sh                    : std_logic_vector(1 downto 0) := (others =>'0');

-- DL : Input 
signal dl_clk_div_cnt                         : std_logic_vector(log2(DL_HOVS) downto 0);
signal dl_vld                                 : std_logic;

signal dl_input_vld                           : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal dl_input_i                             : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal dl_input_q                             : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal dl_pwr_strb                            : std_logic;

-- DL : Mixer 
signal dl_mixer_out_vld                       : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal dl_mixer_out_i                         : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal dl_mixer_out_q                         : std_logic_array16(TX_ANT_NUM-1 downto 0);

-- DL : DPD_BLK 
signal dl_dpdblk_in_vld                       : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal dl_dpdblk_in_i                         : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal dl_dpdblk_in_q                         : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal dl_dpdhc_out_vld                       : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal dl_dpdhc_out_i                         : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal dl_dpdhc_out_q                         : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal dl_dpdblk_out_vld                      : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal dl_dpdblk_out_i                        : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal dl_dpdblk_out_q                        : std_logic_array16(TX_ANT_NUM-1 downto 0);

-- DL : DACIF_ON
signal dl_dacif_on_out_vld                    : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal dl_dacif_on_out_i                      : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal dl_dacif_on_out_q                      : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal dl_dacif_on_phtest                     : std_logic_vector( TX_ANT_NUM-1 downto 0);

signal dl_dacif_on_sel_vld                    : std_logic_vector( TX_ANT_NUM-1 downto 0) := (others => '0');
signal dl_dacif_on_sel_i                      : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others => (others => '0'));
signal dl_dacif_on_sel_q                      : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others => (others => '0'));

signal dl_dpdtop_out_vld                      : std_logic_vector( TX_ANT_NUM-1 downto 0) := (others => '0');            
signal dl_dpdtop_out_i                        : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others => (others => '0'));
signal dl_dpdtop_out_q                        : std_logic_array16(TX_ANT_NUM-1 downto 0) := (others => (others => '0'));

-- FB : Input Align
signal fb_align_i                             : std_logic_array16(FB_PATH_NUM-1 downto 0);
signal fb_align_q                             : std_logic_array16(FB_PATH_NUM-1 downto 0);

signal fb_sw_ctrl_nco_vld                     : std_logic_vector( FB_PATH_NUM-1 downto 0);
signal fb_sw_ctrl_i_nco                       : std_logic_array16(FB_PATH_NUM-1 downto 0);
signal fb_sw_ctrl_q_nco                       : std_logic_array16(FB_PATH_NUM-1 downto 0);

-- FB : FBSW_CTRL
signal fb_sw_ctrl_vld                         : std_logic_vector( FB_PATH_NUM-1 downto 0);
signal fb_sw_ctrl_i                           : std_logic_array16(FB_PATH_NUM-1 downto 0);
signal fb_sw_ctrl_q                           : std_logic_array16(FB_PATH_NUM-1 downto 0);

signal fb_vc                                  : std_logic_vector( 4 downto 0);
signal fbsw_round_start_pls                   : std_logic;

signal fb_atten_value                         : std_logic_array16(FB_PATH_NUM-1 downto 0); 

-- FB : FB_FILTER
signal fb_filter_out_vld                      : std_logic_vector( FB_PATH_NUM-1 downto 0);
signal fb_filter_out_i                        : std_logic_array16(FB_PATH_NUM-1 downto 0);
signal fb_filter_out_q                        : std_logic_array16(FB_PATH_NUM-1 downto 0);
signal fb_pwrmsr_in_i                         : std_logic_array16(FB_PATH_NUM-1 downto 0);
signal fb_pwrmsr_in_q                         : std_logic_array16(FB_PATH_NUM-1 downto 0);

-- FB : Feedback Even Power Measure 
signal fb_pwr_update_done                     : std_logic_vector( FB_PATH_NUM-1 downto 0);
signal fb_pwr                                 : std_logic_array32(FB_PATH_NUM-1 downto 0);

-- FB : Feedback Atten
signal fb_atten_out_vld                       : std_logic_vector( FB_PATH_NUM-1 downto 0);
signal fb_atten_out_i                         : std_logic_array16(FB_PATH_NUM-1 downto 0);
signal fb_atten_out_q                         : std_logic_array16(FB_PATH_NUM-1 downto 0);

-- UL : Uplink Input Align
signal ul_clk_div_cnt                         : std_logic_vector(log2(UL_HOVS) downto 0);
signal ul_vld                                 : std_logic;

signal ul_input_vld                           : std_logic_vector( RX_ANT_NUM-1 downto 0) := (others => '0');
signal ul_input_i                             : std_logic_array16(RX_ANT_NUM-1 downto 0) := (others => (others => '0'));
signal ul_input_q                             : std_logic_array16(RX_ANT_NUM-1 downto 0) := (others => (others => '0'));

signal dl_inter_duc_output_vld                : std_logic_vector( RX_ANT_NUM-1 downto 0) := (others => '0');            
signal dl_inter_duc_output_i                  : std_logic_array16(RX_ANT_NUM-1 downto 0) := (others => (others => '0'));
signal dl_inter_duc_output_q                  : std_logic_array16(RX_ANT_NUM-1 downto 0) := (others => (others => '0'));

signal ul_output_vld                          : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_output_i                            : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal ul_output_q                            : std_logic_array16(RX_ANT_NUM-1 downto 0);

signal ul_mon0_data_iq                        : std_logic_vector(31 downto 0);
signal ul_mon1_data_iq                        : std_logic_vector(31 downto 0);
signal ul_mon2_data_iq                        : std_logic_vector(31 downto 0);

signal ul_pim_sc_err_i                        : std_logic_array16(RX_ANT_NUM-1 downto 0); 
signal ul_pim_sc_err_q                        : std_logic_array16(RX_ANT_NUM-1 downto 0); 

signal ul_pim_sc_tgt_i                        : std_logic_array16(RX_ANT_NUM-1 downto 0); 
signal ul_pim_sc_tgt_q                        : std_logic_array16(RX_ANT_NUM-1 downto 0); 

signal ul_pim_interb_ducdly_i                 : std_logic_array16(RX_ANT_NUM-1 downto 0); 
signal ul_pim_interb_ducdly_q                 : std_logic_array16(RX_ANT_NUM-1 downto 0); 

signal ul_pim_sc_cfr_i                        : std_logic_array16(RX_ANT_NUM-1 downto 0); 
signal ul_pim_sc_cfr_q                        : std_logic_array16(RX_ANT_NUM-1 downto 0); 

signal ul_pim_sc_3rd_im_i                     : std_logic_array16(RX_ANT_NUM-1 downto 0); 
signal ul_pim_sc_3rd_im_q                     : std_logic_array16(RX_ANT_NUM-1 downto 0); 

signal ul_pim_sc_dbg_i                        : std_logic_array16(RX_ANT_NUM-1 downto 0); 
signal ul_pim_sc_dbg_q                        : std_logic_array16(RX_ANT_NUM-1 downto 0); 
    
signal dbg_pim_mixps_i                        : std_logic_array16( TX_ANT_NUM-1 downto 0) := (others => (others => '0'));
signal dbg_pim_mixps_q                        : std_logic_array16( TX_ANT_NUM-1 downto 0) := (others => (others => '0'));

-- Smart Capture
signal sc_ref_vld                             : std_logic;

signal sc_ref_i                               : std_logic_vector(15 downto 0);
signal sc_ref_q                               : std_logic_vector(15 downto 0);

signal sc_dpd_i                               : std_logic_vector(15 downto 0);
signal sc_dpd_q                               : std_logic_vector(15 downto 0);

signal sc_fb_i                                : std_logic_vector(15 downto 0);
signal sc_fb_q                                : std_logic_vector(15 downto 0);

signal sc_pim_src0_i                          : std_logic_vector(15 downto 0);
signal sc_pim_src0_q                          : std_logic_vector(15 downto 0);

signal sc_pim_src1_i                          : std_logic_vector(15 downto 0);
signal sc_pim_src1_q                          : std_logic_vector(15 downto 0);

signal sc_pim_dbg_i                           : std_logic_vector(15 downto 0);
signal sc_pim_dbg_q                           : std_logic_vector(15 downto 0);

-- CPUIF Register Signals
signal reg_dpd_core_set_strb                  : std_logic_vector( 1 downto 0);
signal reg_dpd_core_gain_index                : std_logic_array2( TX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
signal reg_dpd_core_qpoint_sel                : std_logic_array2( TX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection

signal reg_dpd_core_lut_switch_cdc_strb       : std_logic_vector( 3 downto 0);
signal reg_dpd_core_lut_input_switch          : std_logic_array20(3 downto 0);
signal reg_dpd_core_lut_output_switch         : std_logic_array20(3 downto 0);

signal reg_dpd_core_lut_rb_test               : std_logic_vector( 3 downto 0);

signal reg_dpd_core_lut_update_sw             : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal reg_dpd_core_lut_wren                  : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal reg_dpd_core_lut_rden                  : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal reg_dpd_core_lut_addr                  : std_logic_array15(TX_ANT_NUM-1 downto 0);
signal reg_dpd_core_lut_wdata                 : std_logic_array32(TX_ANT_NUM-1 downto 0);
signal reg_dpd_core_lut_rdata                 : std_logic_array32(TX_ANT_NUM-1 downto 0);


signal reg_pim_core_set_strb                  : std_logic_vector( 1 downto 0);
signal reg_pim_core_gain_index                : std_logic_array2( RX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
signal reg_pim_core_qpoint_sel                : std_logic_array2( RX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection

signal reg_pim_core_lut_switch_cdc_strb       : std_logic_vector( 3 downto 0);
signal reg_pim_core_lut_input_switch          : std_logic_array20(3 downto 0);
signal reg_pim_core_lut_output_switch         : std_logic_array20(3 downto 0);

signal reg_pim_core_lut_rb_test               : std_logic_vector( 3 downto 0);

signal reg_pim_core_lut_update_sw             : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal reg_pim_core_lut_wren                  : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal reg_pim_core_lut_rden                  : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal reg_pim_core_lut_addr                  : std_logic_array15(TX_ANT_NUM-1 downto 0);
signal reg_pim_core_lut_wdata                 : std_logic_array32(TX_ANT_NUM-1 downto 0);
signal reg_pim_core_lut_rdata                 : std_logic_array32(TX_ANT_NUM-1 downto 0);

signal reg_pim_complex_filter_coef_wren       : std_logic_vector(RX_ANT_NUM-1 downto 0);
signal reg_pim_complex_filter_coef_rden       : std_logic_vector(RX_ANT_NUM-1 downto 0);
signal reg_pim_complex_filter_coef_wrdn       : std_logic_vector(RX_ANT_NUM-1 downto 0);
signal reg_pim_complex_filter_coef_addr       : std_logic_vector( 3 downto 0);
signal reg_pim_complex_filter_coef_i_wdata    : std_logic_vector(20 downto 0);
signal reg_pim_complex_filter_coef_q_wdata    : std_logic_vector(20 downto 0);
signal reg_pim_complex_filter_coef_i_rdata    : std_logic_vector(20 downto 0);
signal reg_pim_complex_filter_coef_q_rdata    : std_logic_vector(20 downto 0);

signal reg_pimsrc_intrab_dly_strb             : std_logic;
signal reg_pimsrc_intrab_dly                  : std_logic_array12(TX_ANT_NUM-1 downto 0);
                        
signal reg_pimsrc_interb_dly_strb             : std_logic;       
signal reg_pimsrc_interb_cdly                 : std_logic_array11(TX_ANT_NUM-1 downto 0);
signal reg_pimsrc_interb_fdly                 : std_logic_array4( TX_ANT_NUM-1 downto 0);

signal reg_pim_ref_dly_strb                   : std_logic;      
signal reg_pim_ref_sample_dly                 : std_logic_array12(TX_ANT_NUM-1 downto 0);

signal reg_pim_ul_dly_strb                    : std_logic;       
signal reg_pim_ul_sample_dly                  : std_logic_array12(RX_ANT_NUM-1 downto 0);

signal reg_pnpc_en                            : std_logic_vector(RX_ANT_NUM-1 downto 0);
signal reg_pnpc_set                           : std_logic_vector(RX_ANT_NUM-1 downto 0);

signal reg_pnpc_mu_sel_strb                   : std_logic; 
signal reg_pnpc_mu_sel                        : std_logic_array2(RX_ANT_NUM-1 downto 0);

signal reg_pnpc_setval_strb                   : std_logic;
signal reg_pnpc_setval_i                      : std_logic_array16(RX_ANT_NUM-1 downto 0);                    
signal reg_pnpc_setval_q                      : std_logic_array16(RX_ANT_NUM-1 downto 0);                    

signal reg_pnpc_tp_dc_iq                      : std_logic_array32(RX_ANT_NUM-1 downto 0);                    

signal reg_pim_ul_mixer_freq_err_comp_strb    : std_logic;                    
signal reg_pim_ul_mixer_freq_err_comp_word    : std_logic_vector(31 downto 0);                    

signal reg_sc_control                         : std_logic;
signal reg_sc_complete_flag                   : std_logic;
signal reg_sc_tdd_mode                        : std_logic;
signal reg_sc_forced_mode                     : std_logic;
signal reg_sc_debouncing_time                 : std_logic_vector( 9 downto 0);
signal reg_sc_cap_size_sel                    : std_logic;
signal reg_sc_dpdfb_pim_mode_sel              : std_logic; 

signal reg_sc_path_sel_cdc_strb               : std_logic;
signal reg_sc_path_sel                        : std_logic_vector( 4 downto 0);

signal reg_sc_cap_memory_sel                  : std_logic_vector( 2 downto 0);
signal reg_sc_dpd_core_hc_latency             : std_logic_vector( 9 downto 0);
signal reg_sc_fb_latency                      : std_logic_vector( 9 downto 0);
signal reg_sc_ref_latency                     : std_logic_vector( 9 downto 0);
signal reg_sc_cap_off_start                   : std_logic_vector(21 downto 0);
signal reg_sc_cap_off_stop                    : std_logic_vector(21 downto 0);
signal reg_sc_static_position                 : std_logic_vector(21 downto 0);
signal reg_sc_static_length                   : std_logic_vector( 8 downto 0);
signal reg_sc_max_peak_bo_gain                : std_logic_vector(15 downto 0);
signal reg_sc_cur_peak_bo_gain                : std_logic_vector(15 downto 0);
signal reg_sc_sub_pwr                         : std_logic_vector(31 downto 0);
signal reg_sc_sub_peak                        : std_logic_vector(31 downto 0);
signal reg_sc_sub_peak_num                    : std_logic_vector(12 downto 0);
signal reg_sc_time_index                      : std_logic_vector(31 downto 0);

signal reg_sc_inter_pim_dbg_sel               : std_logic_vector( 1 downto 0);
signal reg_sc_intra_pim_dbg_sel               : std_logic_vector( 1 downto 0);

signal reg_sc_mem_rden                        : std_logic;
signal reg_sc_mem_addr                        : std_logic_vector(12 downto 0);
signal reg_sc_mem_rdata                       : std_logic_vector(31 downto 0);

signal reg_ssd_path_sel                       : std_logic_vector( 4 downto 0);
signal reg_ssd_ctrl                           : std_logic;
signal reg_ssd_period                         : std_logic_vector( 9 downto 0);
signal reg_ssd_length_per_switch              : std_logic_vector(16 downto 0);
signal reg_ssd_accu_length                    : std_logic_vector(16 downto 0);
signal reg_ssd_accu_done                      : std_logic;
signal reg_ssd_gain                           : std_logic_vector(15 downto 0);

signal reg_ptn_ram_wren                       : std_logic;
signal reg_ptn_ram_waddr                      : std_logic_vector( 8 downto 0);
signal reg_ptn_ram_wdata                      : std_logic_vector(31 downto 0);

signal reg_ssd_mem_rden                       : std_logic;
signal reg_ssd_mem_addr                       : std_logic_vector( 9 downto 0);
signal reg_ssd_mem_rdata                      : std_logic_vector(31 downto 0);

signal fb_vc_rxssd                            : std_logic_vector( 4 downto 0);

-- selectable pim
signal s_pim_sltb1_gain_index                 : std_logic_array2( TX_ANT_NUM-1 downto 0);
signal s_pim_sltb1_qpoint_sel                 : std_logic_array2( TX_ANT_NUM-1 downto 0);
signal s_pimdly_sltb1_value                   : std_logic_array12(TX_ANT_NUM-1 downto 0);           

signal s_pim_sltb1_lut_update_sw              : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal s_pim_sltb1_lut_wren                   : std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
signal s_pim_sltb1_lut_rden                   : std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Read  Enable
signal s_pim_sltb1_lut_addr                   : std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
signal s_pim_sltb1_lut_wdata                  : std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
signal s_pim_sltb1_lut_rdata                  : std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
                                                                  
signal s_pim_sltb2_gain_index                 : std_logic_array2( TX_ANT_NUM-1 downto 0);
signal s_pim_sltb2_qpoint_sel                 : std_logic_array2( TX_ANT_NUM-1 downto 0);
signal s_pimdly_sltb2_value                   : std_logic_array12(TX_ANT_NUM-1 downto 0);          
                                                                 
signal s_pim_sltb2_lut_update_sw              : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal s_pim_sltb2_lut_wren                   : std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
signal s_pim_sltb2_lut_rden                   : std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Read  Enable
signal s_pim_sltb2_lut_addr                   : std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
signal s_pim_sltb2_lut_wdata                  : std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
signal s_pim_sltb2_lut_rdata                  : std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
                                                                                                                     
signal s_pim_sltb_intra_nco_wren              : std_logic;
signal s_pim_sltb_intra_nco_word              : std_logic_vector(31 downto 0);
signal s_pim_sltb_inter1_nco_wren             : std_logic;
signal s_pim_sltb_inter1_nco_word             : std_logic_vector(31 downto 0);
signal s_pim_sltb_inter2_nco_wren             : std_logic;
signal s_pim_sltb_inter2_nco_word             : std_logic_vector(31 downto 0);
                                                                                                                      
signal s_intra_band_sel                       : std_logic_vector(TX_ANT_NUM-1 downto 0);
signal s_inter_band_type1_sel                 : std_logic_array2(TX_ANT_NUM-1 downto 0);
signal s_inter_band_type2_sel                 : std_logic_array2(TX_ANT_NUM-1 downto 0);
signal s_pim_bit_shift_sel                    : std_logic_vector(1 downto 0);
             
signal s_shift_direction_intra                : std_logic_array2(TX_ANT_NUM-1 downto 0);
signal s_shift_direction_inter1               : std_logic_array2(TX_ANT_NUM-1 downto 0);
signal s_shift_direction_inter2               : std_logic_array2(TX_ANT_NUM-1 downto 0);

signal ul_proc_dly                            : std_logic_vector(31 downto 0) := DPDFB_UL_PIMOFF_DELAY;
-- For DUMP
signal dl_cfrout_dump_bfnstrb                 : std_logic;
signal dl_cfrout_dump_vld                     : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal dl_cfrout_dump_iq                      : std_logic_array32(TX_ANT_NUM-1 downto 0);

signal dl_dpdout_dump_bfnstrb                 : std_logic;
signal dl_dpdout_dump_vld                     : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal dl_dpdout_dump_iq                      : std_logic_array32(TX_ANT_NUM-1 downto 0);

signal fb_att_in_dump_bfnstrb                 : std_logic;
signal fb_att_in_dump_vld                     : std_logic_vector( FB_PATH_NUM-1 downto 0);
signal fb_att_in_dump_iq                      : std_logic_array32(FB_PATH_NUM-1 downto 0);

signal nco_word_d		              		  : std_logic_vector(31 downto 0);

signal fbsw_ssb_ind_flga_1d                   : std_logic;
signal fbsw_ssb_ind_flga_2d                   : std_logic;
signal fb_pwr_strb                            : std_logic;

-- ***********************************
-- ATTRIBUTE 
-- ***********************************
--attribute MARK_DEBUG : string;
--attribute MARK_DEBUG of fb_pwrmsr_in_i           : signal is "TRUE";
--attribute MARK_DEBUG of fb_pwrmsr_in_q           : signal is "TRUE";
--attribute MARK_DEBUG of fb_pwr_update_done       : signal is "TRUE";
--attribute MARK_DEBUG of fb_pwr                   : signal is "TRUE";
--attribute MARK_DEBUG of fb_pwr_strb              : signal is "TRUE";
--attribute MARK_DEBUG of fb_tdd_strb_fir_dly      : signal is "TRUE";

--attribute MARK_DEBUG of pwr_msr_strb_sw_dly      : signal is "TRUE";
--attribute MARK_DEBUG of fbsw_ssb_ind_flga_2d     : signal is "TRUE";
--attribute MARK_DEBUG of pwr_msr_strb_align_dly   : signal is "TRUE";
--attribute MARK_DEBUG of PWR_MSR_FB_SYNC_IN       : signal is "TRUE";
begin

    DPD_INFO_OUT         <= DPD_INFO;
    DPD_STRUCT_OUT       <= DPD_STRUCT;
    DPD_DATE_OUT         <= DPD_DATE;
                                          
    DPD_DL_PROC_DLY_OUT  <= DPDFB_DL_DELAY;
    DPD_FB_PROC_DLY_OUT  <= DPDFB_FB_DELAY;

    P_UL_Delay_MUX : process(CLK_DL) begin
        if (CLK_DL'event) and (CLK_DL  = '1') then
            if (pim_mitigator_on_sh(1) = '1') then 
                ul_proc_dly<= DPDFB_UL_DELAY;
            else
                ul_proc_dly<= DPDFB_UL_PIMOFF_DELAY;
            end if;
        end if;
    end process;

    DPD_UL_PROC_DLY_OUT <= ul_proc_dly;

    process(CLK_DL)
    begin
        if (rising_edge(CLK_DL)) then
            fbsw_ssb_ind_flga_1d                <=  FBSW_SSB_IND_FLAG;
            fbsw_ssb_ind_flga_2d                <=  fbsw_ssb_ind_flga_1d;
        end if;
    end process;
    
-- ***********************************
-- Operation Clock Assign 
-- ***********************************
    CLK_VECTOR <= CLK_SYSX20&'0'&'0'&'0'&CLK_SYSX16&'0'&'0'&'0'&CLK_SYSX12&'0'&CLK_SYSX10&'0'&CLK_SYSX8&'0'&CLK_SYSX6&CLK_SYSX5&CLK_SYSX4&CLK_SYSX3&CLK_SYSX2&CLK_SYS;  

    CLK_DPD    <= CLK_VECTOR(DPD_CLK_SEL  -1);
    CLK_DL     <= CLK_VECTOR(DL_CLK_SEL   -1);
    CLK_FB     <= CLK_VECTOR(FB_CLK_SEL   -1);
    CLK_UL     <= CLK_VECTOR(UL_CLK_SEL   -1);

-- ***********************************
-- Reset 
-- ***********************************
    clk_unstable <= not INT_SYSPLL_LOCK_IN;

    U_RST_SYNC_DL  : RST_SYNC generic map(4, 200) port map(clk_unstable, CLK_DL   , rst_dl    );                            
    U_RST_SYNC_FB  : RST_SYNC generic map(4, 200) port map(clk_unstable, CLK_FB   , rst_fb    );                            
    U_RST_SYNC_UL  : RST_SYNC generic map(4, 200) port map(clk_unstable, CLK_UL   , rst_ul    );                            
    U_RST_SYNC_DPD : RST_SYNC generic map(4, 200) port map(clk_unstable, CLK_DPD  , rst_dl_dpd);                            

-- ***********************************
-- BFN 10ms & TDD Storbe Delay 
-- ***********************************

    -- DL Path
    U_DL_STRB_Input_Align_DLY  : TDD_STRB_DLY generic map(DL_INPUT_ALIGN_DLY) port map(clk_unstable, CLK_DL, '0', DL_BFN_STRB_IN  , DL_TDD_IN, dl_bfn_strb_align_dly, dl_tdd_strb_align_dly);
    U_DL_STRB_Input_Align_SSB  : TDD_STRB_DLY generic map(DL_INPUT_ALIGN_DLY) port map(clk_unstable, CLK_DL, '0', DL_SSB_STRB_IN  , '0'      , dl_ssb_strb_align_dly, open                 );
    U_DL_BCF_Input_Align_DLY   : TDD_STRB_DLY generic map(DL_INPUT_ALIGN_DLY) port map(clk_unstable, CLK_DL, '0', DL_BCF_ENB_IN   , '0'      , dl_bcf_enb_align_dly , open                 );

    G_Using_DL_Mixer_STRB_DLY : if (DL_MIXER_IMPLEMENTATION = TRUE) generate begin
        U_DL_STRB_Mixer_DLY : TDD_STRB_DLY generic map(DL_MIXER_DLY) port map(clk_unstable, CLK_DL, '0', dl_bfn_strb_align_dly, dl_tdd_strb_align_dly, dl_bfn_strb_mixer_dly, dl_tdd_strb_mixer_dly);
        U_DL_STRB_Mixer_SSB : TDD_STRB_DLY generic map(DL_MIXER_DLY) port map(clk_unstable, CLK_DL, '0', dl_ssb_strb_align_dly, '0'                  , dl_ssb_strb_mixer_dly, open                 );
        U_DL_BCF_Mixer_DLY  : TDD_STRB_DLY generic map(DL_MIXER_DLY) port map(clk_unstable, CLK_DL, '0', dl_bcf_enb_align_dly , '0'                  , dl_bcf_enb_mixer_dly , open                 );  
    end generate;

    G_Unusing_DL_Mixer_STRB_DLY : if (DL_MIXER_IMPLEMENTATION = FALSE) generate begin
        dl_bfn_strb_mixer_dly <= dl_bfn_strb_align_dly;
        dl_ssb_strb_mixer_dly <= dl_ssb_strb_align_dly;
        dl_tdd_strb_mixer_dly <= dl_tdd_strb_align_dly;
        dl_bcf_enb_mixer_dly  <= dl_bcf_enb_align_dly ;
    end generate;

    G_Using_RX_SSD : if (RX_SSD_IMPLEMENTATION = TRUE) generate begin
        U_DL_STRB_RXSSD_DLY : TDD_STRB_DLY generic map(DL_RXSSD_DLY) port map(clk_unstable, CLK_DL, '0', dl_bfn_strb_mixer_dly, dl_tdd_strb_mixer_dly, dl_bfn_strb_rxssd_dly, dl_tdd_strb_rxssd_dly);
        U_DL_STRB_RXSSD_SSB : TDD_STRB_DLY generic map(DL_RXSSD_DLY) port map(clk_unstable, CLK_DL, '0', dl_ssb_strb_mixer_dly, '0'                  , dl_ssb_strb_rxssd_dly, open                 );
        U_DL_BCF_RXSSD_DLY  : TDD_STRB_DLY generic map(DL_RXSSD_DLY) port map(clk_unstable, CLK_DL, '0', dl_bcf_enb_mixer_dly , '0'                  , dl_bcf_enb_rxssd_dly , open                 );
    end generate;

    G_Unusing_RX_SSD : if (RX_SSD_IMPLEMENTATION = FALSE) generate begin
        dl_bfn_strb_rxssd_dly <= dl_bfn_strb_mixer_dly;                                 
        dl_ssb_strb_rxssd_dly <= dl_ssb_strb_mixer_dly;                                 
        dl_tdd_strb_rxssd_dly <= dl_tdd_strb_mixer_dly;                                 
        dl_bcf_enb_rxssd_dly  <= dl_bcf_enb_mixer_dly ;
    end generate;

    G_Using_DL_DPD_CORE : if (DPD_CORE_IMPLEMENTATION = TRUE) generate begin
        U_DL_STRB_DPDCORE_DLY : TDD_STRB_DLY generic map(DL_DPDCORE_DLY) port map(clk_unstable, CLK_DL, dpdcore_bypass_sh(0)(1), dl_bfn_strb_rxssd_dly, dl_tdd_strb_rxssd_dly, dl_bfn_strb_dpdcore_dly, dl_tdd_strb_dpdcore_dly);
        U_DL_STRB_DPDCORE_SSB : TDD_STRB_DLY generic map(DL_DPDCORE_DLY) port map(clk_unstable, CLK_DL, dpdcore_bypass_sh(0)(1), dl_ssb_strb_rxssd_dly, '0'                  , dl_ssb_strb_dpdcore_dly, open                   );
        U_DL_BCF_DPDCORE_DLY  : TDD_STRB_DLY generic map(DL_DPDCORE_DLY) port map(clk_unstable, CLK_DL, dpdcore_bypass_sh(0)(1), dl_bcf_enb_rxssd_dly , '0'                  , dl_bcf_enb_dpdcore_dly , open                   );
    end generate;

    G_Unusing_DL_DPD_CORE : if (DPD_CORE_IMPLEMENTATION = FALSE) generate begin
        dl_bfn_strb_dpdcore_dly <= dl_bfn_strb_rxssd_dly;
        dl_ssb_strb_dpdcore_dly <= dl_ssb_strb_rxssd_dly;
        dl_tdd_strb_dpdcore_dly <= dl_tdd_strb_rxssd_dly;
        dl_bcf_enb_dpdcore_dly  <= dl_bcf_enb_rxssd_dly ;
    end generate;

    G_Using_DL_DPDHC : if (DPD_HC_IMPLEMENTATION = TRUE) generate begin        
        U_DL_STRB_DPDHC_DLY : TDD_STRB_DLY generic map(DL_DPDHC_DLY) port map(clk_unstable, CLK_DL, '0', dl_bfn_strb_dpdcore_dly, dl_tdd_strb_dpdcore_dly, dl_bfn_strb_dpdhc_dly, dl_tdd_strb_dpdhc_dly);
        U_DL_STRB_DPDHC_SSB : TDD_STRB_DLY generic map(DL_DPDHC_DLY) port map(clk_unstable, CLK_DL, '0', dl_ssb_strb_dpdcore_dly, '0'                    , dl_ssb_strb_dpdhc_dly, open                 );
        U_DL_BCF_DPDHC_DLY  : TDD_STRB_DLY generic map(DL_DPDHC_DLY) port map(clk_unstable, CLK_DL, '0', dl_bcf_enb_dpdcore_dly , '0'                    , dl_bcf_enb_dpdhc_dly , open                 );
    end generate;

    G_Unusing_DL_DPDHC : if (DPD_HC_IMPLEMENTATION = FALSE) generate begin        
        dl_bfn_strb_dpdhc_dly <= dl_bfn_strb_dpdcore_dly;
        dl_ssb_strb_dpdhc_dly <= dl_ssb_strb_dpdcore_dly;
        dl_tdd_strb_dpdhc_dly <= dl_tdd_strb_dpdcore_dly;
        dl_bcf_enb_dpdhc_dly  <= dl_bcf_enb_dpdcore_dly ;
    end generate;

    G_Using_DL_DPDATT : if (DPD_ATT_IMPLEMENTATION = TRUE) generate begin        
        U_DL_STRB_DPDATT_DLY : TDD_STRB_DLY generic map(DL_DPDATT_DLY) port map(clk_unstable, CLK_DL, '0', dl_bfn_strb_dpdhc_dly, dl_tdd_strb_dpdhc_dly, dl_bfn_strb_dpdatt_dly, dl_tdd_strb_dpdatt_dly);
        U_DL_STRB_DPDATT_SSB : TDD_STRB_DLY generic map(DL_DPDATT_DLY) port map(clk_unstable, CLK_DL, '0', dl_ssb_strb_dpdhc_dly, '0'                  , dl_ssb_strb_dpdatt_dly, open                  );
        U_DL_BCF_DPDATT_DLY  : TDD_STRB_DLY generic map(DL_DPDATT_DLY) port map(clk_unstable, CLK_DL, '0', dl_bcf_enb_dpdhc_dly , '0'                  , dl_bcf_enb_dpdatt_dly , open                  );
    end generate;

    G_Unusing_DL_DPDATT : if (DPD_ATT_IMPLEMENTATION = FALSE) generate begin        
        dl_bfn_strb_dpdatt_dly <= dl_bfn_strb_dpdhc_dly;
        dl_ssb_strb_dpdatt_dly <= dl_ssb_strb_dpdhc_dly;
        dl_tdd_strb_dpdatt_dly <= dl_tdd_strb_dpdhc_dly;
        dl_bcf_enb_dpdatt_dly  <= dl_bcf_enb_dpdhc_dly ;
    end generate;

    G_Using_DL_DPDFILTER : if (DPD_FILTER_IMPLEMENTATION = TRUE) generate begin        
        U_DL_STRB_DPDFIR_DLY : TDD_STRB_DLY generic map(DL_DPD_FILTER_DLY) port map(clk_unstable, CLK_DL, dpdfir_bypass_sh(0)(1), dl_bfn_strb_dpdatt_dly, dl_tdd_strb_dpdatt_dly, dl_bfn_strb_dpdfir_dly, dl_tdd_strb_dpdfir_dly);
        U_DL_STRB_DPDFIR_SSB : TDD_STRB_DLY generic map(DL_DPD_FILTER_DLY) port map(clk_unstable, CLK_DL, dpdfir_bypass_sh(0)(1), dl_ssb_strb_dpdatt_dly, '0'                   , dl_ssb_strb_dpdfir_dly, open                  );
        U_DL_BCF_DPDFIR_DLY  : TDD_STRB_DLY generic map(DL_DPD_FILTER_DLY) port map(clk_unstable, CLK_DL, dpdfir_bypass_sh(0)(1), dl_bcf_enb_dpdatt_dly , '0'                   , dl_bcf_enb_dpdfir_dly , open                  );
    end generate;

    G_Unusing_DL_DPDFILTER : if (DPD_FILTER_IMPLEMENTATION = FALSE) generate begin        
        dl_bfn_strb_dpdfir_dly <= dl_bfn_strb_dpdatt_dly;
        dl_ssb_strb_dpdfir_dly <= dl_ssb_strb_dpdatt_dly;
        dl_tdd_strb_dpdfir_dly <= dl_tdd_strb_dpdatt_dly;
        dl_bcf_enb_dpdfir_dly  <= dl_bcf_enb_dpdatt_dly ;
    end generate;

    G_Using_DL_DACIF_ON_STRB_DLY : if (DACIF_ONOFF_IMPLEMENTATION = TRUE) generate begin        
        U_DL_STRB_DACIF_DLY : TDD_STRB_DLY generic map(DL_DACIF_ON_DLY) port map(clk_unstable, CLK_DL, dacif_bypass_sh(0)(1), dl_bfn_strb_dpdfir_dly, dl_tdd_strb_dpdfir_dly, dl_bfn_strb_dacif_dly, dl_tdd_strb_dacif_dly);
        U_DL_STRB_DACIF_SSB : TDD_STRB_DLY generic map(DL_DACIF_ON_DLY) port map(clk_unstable, CLK_DL, dacif_bypass_sh(0)(1), dl_ssb_strb_dpdfir_dly, '0'                   , dl_ssb_strb_dacif_dly, open                  );
        U_DL_BCF_DACIF_DLY  : TDD_STRB_DLY generic map(DL_DACIF_ON_DLY) port map(clk_unstable, CLK_DL, dacif_bypass_sh(0)(1), dl_bcf_enb_dpdfir_dly , '0'                   , dl_bcf_enb_dacif_dly , open                  );
    end generate;

    G_Unusing_DL_DACIF_ON_STRB_DLY : if (DACIF_ONOFF_IMPLEMENTATION = FALSE) generate begin        
        dl_bfn_strb_dacif_dly <= dl_bfn_strb_dpdfir_dly;
        dl_ssb_strb_dacif_dly <= dl_ssb_strb_dpdfir_dly;
        dl_tdd_strb_dacif_dly <= dl_tdd_strb_dpdfir_dly;
        dl_bcf_enb_dacif_dly  <= dl_bcf_enb_dpdfir_dly ;
    end generate;

    DL_BFN_STRB_OUT   <= dl_bfn_strb_dacif_dly;
    DL_SSB_STRB_OUT   <= dl_ssb_strb_dacif_dly;
    DL_TDD_OUT        <= dl_tdd_strb_dacif_dly;
    DL_BCF_ENB_OUT    <= dl_bcf_enb_dacif_dly ;                  

    -- FB Path
    U_FB_STRB_Input_Align_DLY : TDD_STRB_DLY generic map(FB_INPUT_ALIGN_DLY) port map(clk_unstable, CLK_FB, '0', FB_BFN_STRB_IN       , FB_TDD_IN            , fb_bfn_strb_align_dly, fb_tdd_strb_align_dly);
    U_FB_STRB_Input_Align_SSB : TDD_STRB_DLY generic map(FB_INPUT_ALIGN_DLY) port map(clk_unstable, CLK_FB, '0', FB_SSB_STRB_IN       , '0'                  , fb_ssb_strb_align_dly, open                 );
    U_FB_STRB_Switch_DLY      : TDD_STRB_DLY generic map(FB_SW_DLY         ) port map(clk_unstable, CLK_FB, '0', fb_bfn_strb_align_dly, fb_tdd_strb_align_dly, fb_bfn_strb_sw_dly   , fb_tdd_strb_sw_dly   );
    U_FB_STRB_Switch_SSB      : TDD_STRB_DLY generic map(FB_SW_DLY         ) port map(clk_unstable, CLK_FB, '0', fb_ssb_strb_align_dly, '0'                  , fb_ssb_strb_sw_dly   , open                 );

    G_Using_FB_Filter_STRB_DLY : if (FB_FILTER_IMPLEMENTATION = TRUE) generate begin
        U_FB_STRB_Filter_DLY  : TDD_STRB_DLY generic map(FB_FILTER_DLY) port map(clk_unstable, CLK_FB, fbfir_bypass_sh(0)(1), fb_bfn_strb_sw_dly   , fb_tdd_strb_sw_dly   , fb_bfn_strb_fir_dly  , fb_tdd_strb_fir_dly  );
        U_FB_STRB_Filter_SSB  : TDD_STRB_DLY generic map(FB_FILTER_DLY) port map(clk_unstable, CLK_FB, fbfir_bypass_sh(0)(1), fb_ssb_strb_sw_dly   , '0'                  , fb_ssb_strb_fir_dly  , open                 );
    end generate;

    G_Unusing_FB_Filter_STRB_DLY : if (FB_FILTER_IMPLEMENTATION = FALSE) generate begin
        fb_bfn_strb_fir_dly <= fb_bfn_strb_sw_dly;
        fb_ssb_strb_fir_dly <= fb_ssb_strb_sw_dly;
        fb_tdd_strb_fir_dly <= fb_tdd_strb_sw_dly;
    end generate;

    G_Using_FB_ATTEN_STRB_DLY : if (FB_ATTEN_IMPLEMENTATION = TRUE) generate begin
        U_FB_STRB_ATTEN_DLY   : TDD_STRB_DLY generic map(FB_ATTEN_DLY) port map(clk_unstable, CLK_FB, '0', fb_bfn_strb_sw_dly   , fb_tdd_strb_sw_dly   , fb_bfn_strb_att_dly  , fb_tdd_strb_att_dly  );
        U_FB_STRB_ATTEN_SSB   : TDD_STRB_DLY generic map(FB_ATTEN_DLY) port map(clk_unstable, CLK_FB, '0', fb_ssb_strb_sw_dly   ,  '0'                 , fb_ssb_strb_att_dly  , open                 );
    end generate;

    G_Unusing_FB_ATTEN_STRB_DLY : if (FB_ATTEN_IMPLEMENTATION = FALSE) generate begin
        fb_bfn_strb_att_dly <= fb_bfn_strb_sw_dly;
        fb_ssb_strb_att_dly <= fb_ssb_strb_sw_dly;
        fb_tdd_strb_att_dly <= fb_tdd_strb_sw_dly;
    end generate;

    -- UL Path
    G_Using_PIM_BLK_STRB_DLY : if (PIM_IMPLEMENTATION = TRUE) generate begin
        U_UL_STRB_Align_DLY : TDD_STRB_DLY generic map(UL_INPUT_ALIGN_DLY) port map(clk_unstable, CLK_DL, '0', UL_BFN_STRB_IN   , UL_TDD_IN, ul_bfn_strb_align_dly, ul_tdd_strb_align_dly);
        U_UL_BCF_Align_DLY  : TDD_STRB_DLY generic map(UL_INPUT_ALIGN_DLY) port map(clk_unstable, CLK_DL, '0', UL_BCF_ENB_IN    , '0'      , ul_bcf_enb_align_dly , open                 );

        U_UL_STRB_HBF_I_DLY : TDD_STRB_DLY generic map(UL_HBF_I_DLY) port map(clk_unstable, CLK_DL, '0', ul_bfn_strb_align_dly, ul_tdd_strb_align_dly, ul_bfn_strb_hbf_i_dly, ul_tdd_strb_hbf_i_dly);
        U_UL_BCF_HBF_I_DLY  : TDD_STRB_DLY generic map(UL_HBF_I_DLY) port map(clk_unstable, CLK_DL, '0', ul_bcf_enb_align_dly , '0'                  , ul_bcf_enb_hbf_i_dly , open                 );

        U_UL_STRB_MIXPS_DLY : TDD_STRB_DLY generic map(UL_MIXPS_DLY) port map(clk_unstable, CLK_DL, '0', ul_bfn_strb_hbf_i_dly, ul_tdd_strb_hbf_i_dly, ul_bfn_strb_mixps_dly, ul_tdd_strb_mixps_dly);
        U_UL_BCF_MIXPS_DLY  : TDD_STRB_DLY generic map(UL_MIXPS_DLY) port map(clk_unstable, CLK_DL, '0', ul_bcf_enb_hbf_i_dly , '0'                  , ul_bcf_enb_mixps_dly , open                 );

        U_UL_STRB_BUF_DLY   : TDD_STRB_DLY generic map(UL_PNPC_DLY)  port map(clk_unstable, CLK_DL, '0', ul_bfn_strb_mixps_dly, ul_tdd_strb_mixps_dly, ul_bfn_strb_buf_dly, ul_tdd_strb_buf_dly); 
        U_UL_BCF_BUF_DLY    : TDD_STRB_DLY generic map(UL_PNPC_DLY)  port map(clk_unstable, CLK_DL, '0', ul_bcf_enb_mixps_dly , '0'                  , ul_bcf_enb_buf_dly , open               );

        U_UL_STRB_PIMD_DLY  : TDD_STRB_DLY generic map(UL_PIMD_DLY ) port map(clk_unstable, CLK_DL, '0', ul_bfn_strb_buf_dly , ul_tdd_strb_buf_dly , ul_bfn_strb_pimd_dly, ul_tdd_strb_pimd_dly); 
        U_UL_BCF_PIMD_DLY   : TDD_STRB_DLY generic map(UL_PIMD_DLY ) port map(clk_unstable, CLK_DL, '0', ul_bcf_enb_buf_dly  , '0'                 , ul_bcf_enb_pimd_dly , open                );

        U_UL_STRB_MIXNS_DLY : TDD_STRB_DLY generic map(UL_MIXNS_DLY) port map(clk_unstable, CLK_DL, '0', ul_bfn_strb_pimd_dly, ul_tdd_strb_pimd_dly, ul_bfn_strb_mixns_dly, ul_tdd_strb_mixns_dly);
        U_UL_BCF_MIXNS_DLY  : TDD_STRB_DLY generic map(UL_MIXNS_DLY) port map(clk_unstable, CLK_DL, '0', ul_bcf_enb_pimd_dly , '0'                 , ul_bcf_enb_mixns_dly , open                 );

        U_UL_STRB_HBF_D_DLY : TDD_STRB_DLY generic map(UL_HBF_D_DLY) port map(clk_unstable, CLK_DL, '0', ul_bfn_strb_mixns_dly, ul_tdd_strb_mixns_dly, ul_bfn_strb_hbf_d_dly, ul_tdd_strb_hbf_d_dly);
        U_UL_BCF_HBF_D_DLY  : TDD_STRB_DLY generic map(UL_HBF_D_DLY) port map(clk_unstable, CLK_DL, '0', ul_bcf_enb_mixns_dly , '0'                  , ul_bcf_enb_hbf_d_dly , open                 );

        U_UL_STRB_HBF_D_CDC_DLY : TDD_STRB_DLY generic map(UL_HBF_D_CDC_DLY) port map(clk_unstable, CLK_UL, '0', ul_bfn_strb_hbf_d_dly, ul_tdd_strb_hbf_d_dly, ul_bfn_strb_hbf_d_cdc_dly, ul_tdd_strb_hbf_d_cdc_dly);
        U_UL_BCF_HBF_D_CDC_DLY  : TDD_STRB_DLY generic map(UL_HBF_D_CDC_DLY) port map(clk_unstable, CLK_UL, '0', ul_bcf_enb_hbf_d_dly , '0'                  , ul_bcf_enb_hbf_d_cdc_dly , open                     );

        P_PIM_Mitigator_OnOff_STRB_DLY : process(CLK_UL) begin
            if (CLK_UL'event) and (CLK_UL = '1') then
                if (ul_output_vld(0) = '1') then 
                    if (pim_mitigator_on_sh(1) = '1')then 
                        ul_bfn_strb_dly <= ul_bfn_strb_hbf_d_cdc_dly;
                        ul_tdd_strb_dly <= ul_tdd_strb_hbf_d_cdc_dly;
                        ul_bcf_enb_dly  <= ul_bcf_enb_hbf_d_cdc_dly ;
                    else
                        ul_bfn_strb_dly <= UL_BFN_STRB_IN;
                        ul_tdd_strb_dly <= UL_TDD_IN     ;
                        ul_bcf_enb_dly  <= UL_BCF_ENB_IN ;
                    end if; 
                end if;
            end if;
        end process;

    end generate;

    G_Unusing_PIM_BLK_STRB_DLY : if (PIM_IMPLEMENTATION = FALSE) generate begin
        ul_bfn_strb_align_dly     <= UL_BFN_STRB_IN;
        ul_tdd_strb_align_dly     <= UL_TDD_IN     ;
        ul_bcf_enb_align_dly      <= UL_BCF_ENB_IN ;

        ul_bfn_strb_hbf_i_dly     <= ul_bfn_strb_align_dly;
        ul_tdd_strb_hbf_i_dly     <= ul_tdd_strb_align_dly;
        ul_bcf_enb_hbf_i_dly      <= ul_bcf_enb_align_dly ;
        
        ul_bfn_strb_mixps_dly     <= ul_bfn_strb_hbf_i_dly;
        ul_tdd_strb_mixps_dly     <= ul_tdd_strb_hbf_i_dly;
        ul_bcf_enb_mixps_dly      <= ul_bcf_enb_hbf_i_dly ;
        
        ul_bfn_strb_buf_dly       <= ul_bfn_strb_mixps_dly;
        ul_tdd_strb_buf_dly       <= ul_tdd_strb_mixps_dly;
        ul_bcf_enb_buf_dly        <= ul_bcf_enb_mixps_dly ;
        
        ul_bfn_strb_pimd_dly      <= ul_bfn_strb_buf_dly  ;
        ul_tdd_strb_pimd_dly      <= ul_tdd_strb_buf_dly  ;
        ul_bcf_enb_pimd_dly       <= ul_bcf_enb_buf_dly   ;
        
        ul_bfn_strb_mixns_dly     <= ul_bfn_strb_pimd_dly ;
        ul_tdd_strb_mixns_dly     <= ul_tdd_strb_pimd_dly ;
        ul_bcf_enb_mixns_dly      <= ul_bcf_enb_pimd_dly  ;
        
        ul_bfn_strb_hbf_d_dly     <= ul_bfn_strb_mixns_dly;
        ul_tdd_strb_hbf_d_dly     <= ul_tdd_strb_mixns_dly;
        ul_bcf_enb_hbf_d_dly      <= ul_bcf_enb_mixns_dly ;

        ul_bfn_strb_hbf_d_cdc_dly <=  ul_bfn_strb_hbf_d_dly;
        ul_tdd_strb_hbf_d_cdc_dly <=  ul_tdd_strb_hbf_d_dly;
        ul_bcf_enb_hbf_d_cdc_dly  <=  ul_bcf_enb_hbf_d_dly ;

        ul_bfn_strb_dly           <= ul_bfn_strb_hbf_d_cdc_dly; 
        ul_tdd_strb_dly           <= ul_tdd_strb_hbf_d_cdc_dly; 
        ul_bcf_enb_dly            <= ul_bcf_enb_hbf_d_cdc_dly ; 

    end generate;

    UL_BFN_STRB_OUT   <= ul_bfn_strb_dly;
    UL_TDD_OUT        <= ul_tdd_strb_dly;
    UL_BCF_ENB_OUT    <= ul_bcf_enb_dly;

-- ***********************************
-- Control Register CDC 
-- ***********************************
    G_DL_Register_CDC : for I in 0 to (TX_ANT_NUM-1) generate begin
        P_DL_REG_DC_CLK_DL : process(CLK_DL) begin 
            if (CLK_DL'event) and (CLK_DL = '1') then
                dpdcore_bypass_sh(I) <= dpdcore_bypass_sh(I)(0) & DPD_BYPASS_IN(I)       ;
                dpdfir_bypass_sh(I)  <= dpdfir_bypass_sh(I)(0)  & DPD_FILTER_BYPASS_IN(I);
            end if;
        end process;

        P_DL_REG_DC_CLK_DPD : process(CLK_DPD) begin 
            if (CLK_DPD'event) and (CLK_DPD = '1') then
                dacif_bypass_sh(I)   <= dacif_bypass_sh(I)(0) & DACIF_BYPASS_IN(I);
            end if;
        end process;
    end generate;

    G_FB_Register_CDC : for I in 0 to (FB_PATH_NUM-1) generate begin
        P_FB_Register_Double_Clocking : process(CLK_FB) begin 
            if (CLK_FB'event) and (CLK_FB = '1') then
                fbfir_bypass_sh(I) <= fbfir_bypass_sh(I)(0) & FB_FILTER_BYPASS_IN(I); 
            end if;
        end process;
    end generate;

    P_SC_DPDHC_DLY_LSB_SEL_DC : process(CLK_DPD) begin
        if (CLK_DPD'event) and (CLK_DPD = '1') then
            sc_dpdhc_dly_lsb_sh <= sc_dpdhc_dly_lsb_sh(0) & reg_sc_dpd_core_hc_latency(0);
        end if;
    end process;

    G_DL_Path_Control_Register_CDC : for I in 0 to (TX_ANT_NUM-1) generate begin
        U_DPDCORE_G_IDX_CDC  : MULTIBIT_CDC generic map( 2) port map(reg_dpd_core_gain_index(I), CLK_DPD, dl_dpdcore_gain_index_cdc(I));
        U_DPDCORE_QPOINT_CDC : MULTIBIT_CDC generic map( 2) port map(reg_dpd_core_qpoint_sel(I), CLK_DPD, dl_dpdcore_qpoint_sel_cdc(I));

        U_DPDHC_TRSHD_CDC    : MULTIBIT_CDC generic map(16) port map(DPD_HC_TRSHD_IN(I), CLK_DPD, dl_dpdhc_trshd_cdc(I));
        U_DPDATT_VALUE_CDC   : MULTIBIT_CDC generic map(16) port map(DPD_DATT_IN(I)    , CLK_DPD, dl_dpdatt_cdc(I)     );

        U_FB_FWD_ATT_VALUE_CDC : MULTIBIT_CDC generic map(16) port map(FB_FWD_DATT_IN(I), CLK_FB, fb_fwd_att_value_cdc(I));
        U_FB_RVS_ATT_VALUE_CDC : MULTIBIT_CDC generic map(16) port map(FB_RVS_DATT_IN(I), CLK_FB, fb_rvs_att_value_cdc(I));
    end generate;

    U_DACIF_PHTEST_Offset_CDC      : MULTIBIT_CDC generic map(24) port map(DACIF_PHTEST_OFFSET_IN     , CLK_DPD, dl_dacif_phtest_offset_cdc);
    U_DACIF_PHTEST_Period_CDC      : MULTIBIT_CDC generic map(24) port map(DACIF_PHTEST_PERIOD_IN     , CLK_DPD, dl_dacif_phtest_period_cdc);
    U_DACIF_PHTEST_ON_Duration_CDC : MULTIBIT_CDC generic map(24) port map(DACIF_PHTEST_ON_DURATION_IN, CLK_DPD, dl_dacif_phtest_on_duration_cdc);

    P_SC_FBDLY_LSB_SEL_DC : process(CLK_FB) begin
        if (CLK_FB'event) and (CLK_FB = '1') then
            sc_fb_dly_lsb_sh <= sc_fb_dly_lsb_sh(0) & reg_sc_fb_latency(0);
        end if;
    end process;

    P_UL_PIM_Mitigator_On_DC : process(CLK_UL) begin
        if (CLK_UL'event) and (CLK_UL = '1') then
            pim_mitigator_on    <= PIM_MITIGATOR_ON_IN(1) and PIM_MITIGATOR_ON_IN(0); 
            pim_mitigator_on_sh <= pim_mitigator_on_sh(0) & pim_mitigator_on;
        end if;
    end process;

    G_UL_Path_Control_Register_CDC : for I in 0 to (RX_ANT_NUM-1) generate begin
        U_PIMCORE_G_IDX_CDC  : MULTIBIT_CDC generic map( 2) port map(reg_pim_core_gain_index(I), CLK_DL, ul_pimcore_gain_index_cdc(I));
        U_PIMCORE_QPOINT_CDC : MULTIBIT_CDC generic map( 2) port map(reg_pim_core_qpoint_sel(I), CLK_DL, ul_pimcore_qpoint_sel_cdc(I));
                                                                     
        U_PIM_INTB_GAIN_CDC  : MULTIBIT_CDC generic map(16) port map(PIM_INTERBAND_DUC_GAIN_IN(I), CLK_UL, pim_interb_duc_gain_cdc(I));

        U_PIMSRC_INTRAB_DLY_CDC  : MULTIBIT_CDC generic map(12) port map(reg_pimsrc_intrab_dly(I) , CLK_DL, ul_pimsrc_intrab_dly_cdc(I) );
        U_PIMSRC_INTERB_CDLY_CDC : MULTIBIT_CDC generic map(11) port map(reg_pimsrc_interb_cdly(I), CLK_UL, ul_pimsrc_interb_cdly_cdc(I));
        U_PIMSRC_INTERB_FDLY_CDC : MULTIBIT_CDC generic map( 4) port map(reg_pimsrc_interb_fdly(I), CLK_DL, ul_pimsrc_interb_fdly_cdc(I));
        U_PIMREF_DLY_CDC     : MULTIBIT_CDC generic map(12) port map(reg_pim_ref_sample_dly(I)  ,CLK_DL, ul_pim_ref_sample_dly_cdc(I)   );

        U_PIM_PNPC_SEL_CDC   : MULTIBIT_CDC generic map( 2) port map(PIM_PNPC_SEL_IN(I)        , CLK_DL, ul_pim_pnpc_sel_cdc(I)         );
        U_PIM_PNPC_MUSEL_CDC : MULTIBIT_CDC generic map( 2) port map(reg_pnpc_mu_sel(I)        , CLK_DL, ul_pnpc_mu_sel_cdc(I)          );
        U_PIM_PNPC_SET_I_CDC : MULTIBIT_CDC generic map(16) port map(reg_pnpc_setval_i(I)      , CLK_DL, ul_pnpc_setval_i_cdc(I)        );
        U_PIM_PNPC_SET_Q_CDC : MULTIBIT_CDC generic map(16) port map(reg_pnpc_setval_q(I)      , CLK_DL, ul_pnpc_setval_q_cdc(I)        );
    end generate;

    U_PIM_ULMIX_FREQERR_CDC : MULTIBIT_CDC generic map(32) port map(reg_pim_ul_mixer_freq_err_comp_word, CLK_DL, ul_pim_ul_mixer_freq_err_comp_word_cdc);
    
    -- ***********************************
    -- Downlink Path 
    -- ***********************************
   -- DL Input Alignment
    P_DL_Clock_Divide_Count : process(rst_dl, CLK_DL) begin
        if (rst_dl = '1') then
            dl_clk_div_cnt <= (others => '0');
        elsif (CLK_DL'event) and (CLK_DL = '1') then
            if (dl_clk_div_cnt = DL_HOVS-1) then 
                dl_clk_div_cnt <= (others => '0');
            else
                dl_clk_div_cnt <= dl_clk_div_cnt + '1';
            end if;
        end if;
    end process;

    dl_vld <= '1' when (dl_clk_div_cnt = DL_HOVS-1) else '0';

    G_DL_Input_Valid_Align : for I in 0 to (TX_ANT_NUM-1) generate begin
        P_DL_Input_VLD_Align_HS : process(CLK_DL) begin
            if (CLK_DL'event) and (CLK_DL = '1') then
                dl_input_vld(I) <= dl_vld;
                dl_input_i(I)   <= DL_I_IN(I);
                dl_input_q(I)   <= DL_Q_IN(I);
            end if;
        end process;
    end generate;

    -- RU-FPGA-R8.9.7 Bulk NCO and Complex mixer before DPD Block 
    G_Using_DL_Mixer : if (DL_MIXER_IMPLEMENTATION = TRUE) generate begin
        U_DL_Mixer : NCO_SYMMETRY 
        generic map(
            DEVICE                                 => DEVICE                              , 
        
            HOVS                                   => DL_HOVS                             , 
            SYMMETRY                               => FALSE                               , 

            POS_SHIFTH_PATH_NUM                    => TX_ANT_NUM                          , 
            NEG_SHIFTH_PATH_NUM                    => FB_PATH_NUM                         , 
            NCO_WIDTH                              => 16                                  , 
            RES_VAL                                => DL_NCO_RESOLUTION/2                   
            )
        port map(
            RST                                    => RST_DPD                             , 
            CLK                                    => CLK_DL                              , 
        
            NCO_WREN                               => DL_NCO_WEN_IN(0)                    , 
            NCO_WORD                               => DL_NCO_DATA_IN(0)                   , 
        
            NCO_FREQ_COMP_OFFSET                   => (others => '0')                     , 
        
            DATA_P_SH_VLD_IN                       => dl_input_vld                        , 
            DATA_P_SH_I_IN                         => dl_input_i                          , 
            DATA_P_SH_Q_IN                         => dl_input_q                          , 
        
            DATA_P_SH_VLD_OUT                      => dl_mixer_out_vld                    , 
            DATA_P_SH_I_OUT                        => dl_mixer_out_i                      , 
            DATA_P_SH_Q_OUT                        => dl_mixer_out_q                      , 
        
            DATA_N_SH_VLD_IN                       => (others => '0')                     , 
            DATA_N_SH_I_IN                         => (others => (others => '0'))         , 
            DATA_N_SH_Q_IN                         => (others => (others => '0'))         , 
        
            DATA_N_SH_VLD_OUT                      => open                                , 
            DATA_N_SH_I_OUT                        => open                                , 
            DATA_N_SH_Q_OUT                        => open                                  
            );
    end generate;

    G_Unusing_DL_Mixer : if (DL_MIXER_IMPLEMENTATION = FALSE) generate begin
        dl_mixer_out_vld     <= dl_input_vld;
        dl_mixer_out_i       <= dl_input_i;
        dl_mixer_out_q       <= dl_input_q;
    end generate;

    -- RU-FPGA-R 8.9.1 DPD LUT
    -- RU-FPGA-R 8.9.3 Hard-Clipping 
    -- RU-FPGA-R11.1.1 Attenuation and Gain Control in TX path
    -- RU-FPGA-R 8.9.6 Filtering Function on DPD output 
    U_DPD_BLK : DPD_BLK 
    generic map(
        DEVICE                                 => DEVICE                              ,
       
        TX_ANT_NUM                             => TX_ANT_NUM                          ,
        HOVS                                   => DPD_HOVS                            ,
    
        DPD_CORE_IMPLEMENTATION                => DPD_CORE_IMPLEMENTATION             ,
        DPD_CORE_LUT_OPTIMIZED                 => DPD_CORE_LUT_OPTIMIZED              ,
        DPD_CORE_LUT_MEM_DEPTH                 => DPD_CORE_LUT_MEM_DEPTH              ,
        DPD_CORE_LUT_RBTEST                    => DPD_CORE_LUT_RBTEST                 , 
        DPD_CORE_QPOINT_SEL                    => DPD_CORE_QPOINT_SEL                 , 
        DPD_CORE_LUT_DIMENSION                 => DPD_CORE_LUT_DIMENSION              ,
        DPD_CORE_LUT_NUM                       => DPD_CORE_LUT_NUM                    ,
        DPD_CORE_TAP_NUM                       => DPD_CORE_TAP_NUM                    ,
        DPD_CORE_RND_BIT                       => 13                                  ,
    
        DPD_HC_IMPLEMENTATION                  => DPD_HC_IMPLEMENTATION               ,
        DPD_ATT_IMPLEMENTATION                 => DPD_ATT_IMPLEMENTATION              ,
    
        DPD_FILTER_IMPLEMENTATION              => DPD_FILTER_IMPLEMENTATION           ,
        DPD_FILTER_COEF_FIX                    => TRUE                                ,
        DPD_FILTER_COEF_NUM                    => DPD_FILTER_COEF_NUM                 ,
        DPD_FILTER_RND_BIT                     => 15                                   
        )
    port map(
        RST_DPD                                => RST_DPD                             , 
        CLK_DPD                                => CLK_DPD                             , 
    
        DPD_BLK_VLD_IN                         => dl_dpdblk_in_vld                    ,
        DPD_BLK_I_IN                           => dl_dpdblk_in_i                      ,  
        DPD_BLK_Q_IN                           => dl_dpdblk_in_q                      ,  
    
        DPD_HC_VLD_OUT                         => dl_dpdhc_out_vld                    ,
        DPD_HC_I_OUT                           => dl_dpdhc_out_i                      ,
        DPD_HC_Q_OUT                           => dl_dpdhc_out_q                      ,
    
        DPD_BLK_VLD_OUT                        => dl_dpdblk_out_vld                   , 
        DPD_BLK_I_OUT                          => dl_dpdblk_out_i                     , 
        DPD_BLK_Q_OUT                          => dl_dpdblk_out_q                     , 
    
        DPD_CORE_BYPASS_IN                     => DPD_BYPASS_IN                       , 
    
        DPD_GAIN_INDEX_IN                      => dl_dpdcore_gain_index_cdc           , 
        DPD_QPOINT_SEL_IN                      => dl_dpdcore_qpoint_sel_cdc           , 
    
        RST_CPU                                => RST_CPUIF                           , 
        CLK_CPU                                => CLK_CPUIF                           , 
    
        DPD_LUT_RB_TEST_EN_IN                  => reg_dpd_core_lut_rb_test(0)         , 
    
        DPD_LUT_SWITCH_CDC_STRB_IN             => reg_dpd_core_lut_switch_cdc_strb(0) , 
        DPD_LUT_INPUT_SWITCH_IN                => reg_dpd_core_lut_input_switch(0)    , 
        DPD_LUT_OUTPUT_SWITCH_IN               => reg_dpd_core_lut_output_switch(0)   , 
    
        DPD_LUT_UPDATE_SW_IN                   => reg_dpd_core_lut_update_sw          , 
        DPD_LUT_WREN_IN                        => reg_dpd_core_lut_wren               , 
        DPD_LUT_RDEN_IN                        => reg_dpd_core_lut_rden               , 
        DPD_LUT_ADDR_IN                        => reg_dpd_core_lut_addr               , 
        DPD_LUT_WDATA_IN                       => reg_dpd_core_lut_wdata              , 
        DPD_LUT_RDATA_OUT                      => reg_dpd_core_lut_rdata              , 
    
        DPD_HC_EN_IN                           => (others => '1')                     , 
        DPD_HC_FLAG_OUT                        => DPD_HC_FLAG_OUT                     , 
        DPD_HC_TRSHD_IN                        => dl_dpdhc_trshd_cdc                  , 
    
        DL_ATTEN_VALUE_IN                      => dl_dpdatt_cdc                       , 
    
        FILTER_BYPASS_IN                       => DPD_FILTER_BYPASS_IN                ,
        FILTER_COEF_WR_EN_IN                   => COEF_WREN_IN                        ,
        FILTER_COEF_RD_EN_IN                   => COEF_RDEN_IN                        ,
        FILTER_COEF_WR_DN_IN                   => COEF_WR_DONE_IN                     ,
        FILTER_COEF_ADDR_IN                    => COEF_ADDR_IN                        ,
        FILTER_COEF_WR_DATA_IN                 => COEF_WR_DATA_IN                     ,
        FILTER_COEF_RD_DATA_OUT                => COEF_RD_DATA_OUT                     
        );

    process(CLK_DPD)
    begin
        if (rising_edge(CLK_DPD)) then
            dl_pwr_strb             <= dl_bfn_strb_dpdfir_dly and fbsw_ssb_ind_flga_2d;
        end if;
    end process;

    G_DL_PWR : for I in 0 to (TX_ANT_NUM-1) generate begin
     
        U_DL_PWRMSR : PWRMEAS_MANTISSA 
        generic map(
            DEVICE                       => DEVICE                          , 
            CLK_DIV                      => DPD_HOVS                        , 
            DATA_WIDTH                   => 16                               
            )
        port map(
            RST                          => clk_unstable                    , 
            CLK                          => CLK_DPD                         , 

            FRAME_SYNC_IN                => dl_pwr_strb                     , 
            TDD_SIG_IN                   => dl_tdd_strb_dpdfir_dly          , 
        
            DATA_I_IN                    => dl_dpdblk_out_i(I)              , 
            DATA_Q_IN                    => dl_dpdblk_out_q(I)              , 
        
            PWR_UPDATE_DONE_OUT          => open                            , 
            PWR_OUT                      => DL_PWR_OUT(I)                        
            );

    end generate;
    
    -- RU-FPGA-R10.2 AMP Protection
    -- R10.2.5 Signal On/Off Control
    G_DL_Path_GEN : for I in 0 to (TX_ANT_NUM-1) generate begin
        G_Using_DL_DACIF_ON : if (DACIF_ONOFF_IMPLEMENTATION = TRUE) generate begin 
            U_DL_DACIF_ON : DACIF_ON 
            generic map(
                DEVICE                                 => DEVICE                              , 
                HOVS                                   => DPD_HOVS                              
                )
            port map(
                RST                                    => clk_unstable                        , 
                CLK                                    => CLK_DPD                             , 
            
                DATA_VLD_IN                            => dl_dpdblk_out_vld(I)                , 
                DATA_I_IN                              => dl_dpdblk_out_i(I)                  , 
                DATA_Q_IN                              => dl_dpdblk_out_q(I)                  , 
            
                CPU_CTRL_ONOFF                         => dl_dacif_on_phtest(I)               , 
                IQ_OFF                                 => SIG_SUS_DLOFF_IN(I)                 , 
				STAGE_NUM							   => (others=>'0')              	      ,
            
                DATA_VLD_OUT                           => dl_dacif_on_out_vld(I)              , 
                DATA_I_OUT                             => dl_dacif_on_out_i(I)                , 
                DATA_Q_OUT                             => dl_dacif_on_out_q(I)
                );
 
            P_DL_DACIF_ON_Bypass : process(CLK_DPD) begin
                if (CLK_DPD'event) and (CLK_DPD = '1') then
                    if (dacif_bypass_sh(I)(1) = '1') then
                        dl_dacif_on_sel_vld(I) <= dl_dpdblk_out_vld(I);
                        dl_dacif_on_sel_i(I)   <= dl_dpdblk_out_i(I);
                        dl_dacif_on_sel_q(I)   <= dl_dpdblk_out_q(I);
                    else
                        dl_dacif_on_sel_vld(I) <= dl_dacif_on_out_vld(I);
                        dl_dacif_on_sel_i(I)   <= dl_dacif_on_out_i(I);
                        dl_dacif_on_sel_q(I)   <= dl_dacif_on_out_q(I);
                    end if;
                end if;
            end process;
        end generate;

        G_Unusing_DL_DACIF_ON : if (DACIF_ONOFF_IMPLEMENTATION = FALSE) generate begin 
            dl_dacif_on_sel_vld(I) <= dl_dacif_on_out_vld(I);
            dl_dacif_on_sel_i(I)   <= dl_dacif_on_out_i(I);
            dl_dacif_on_sel_q(I)   <= dl_dacif_on_out_q(I);
        end generate;

        P_DPD_TOP_Output_Align : process(CLK_DL) begin
            if (CLK_DL'event) and (CLK_DL = '1') then
                if (dl_dacif_on_sel_vld(I) = '1') then
                    dl_dpdtop_out_vld(I) <= not dl_dpdtop_out_vld(I);          
                    dl_dpdtop_out_i(I)   <= dl_dacif_on_sel_i(I);          
                    dl_dpdtop_out_q(I)   <= dl_dacif_on_sel_q(I);          
                else
                    dl_dpdtop_out_vld(I) <= dl_dpdtop_out_vld(I);          
                    dl_dpdtop_out_i(I)   <= dl_dpdtop_out_i(I);          
                    dl_dpdtop_out_q(I)   <= dl_dpdtop_out_q(I);          
                end if;
            end if;
        end process;

    end generate;

    DL_SYNC_OUT   <= dl_dpdtop_out_vld;

    DL_I_OUT      <= dl_dpdtop_out_i;                     
    DL_Q_OUT      <= dl_dpdtop_out_q;                     

-- ***********************************
-- Feedback Path 
-- ***********************************
--    RU-FPGA-R8.16 Feedback
	
    process(CLK_FB)
    begin
        if (rising_edge(CLK_FB)) then
            fb_align_i                  <= FB_I_IN;
            fb_align_q                  <= FB_Q_IN;
        end if;
    end process;
    
    U_FBSW_CTRL : FBSW_CTRL 
    generic map(        
        TX_ANT_NUM                             => TX_ANT_NUM                             , 
        FB_PATH_NUM                            => FB_PATH_NUM                            , 
        RX_ANT_NUM                             => RX_ANT_NUM                             , 
        SC_HOVS                                => FB_HOVS                                , 

        DPD_PATH_PHASE                         => DPD_PATH_PHASE                         , 
        PIM_IMPLEMENTATION                     => PIM_IMPLEMENTATION                     , 
        PIMD_BLK_TYPE                          => PIM_BLK_TYPE                           , 
    
        FB_ATTEN_IMPLEMENTATION                => FB_ATTEN_IMPLEMENTATION                , 
        SC_IMPLEMENTATION                      => SC_IMPLEMENTATION                        
        )
    port map(
        RST                                    => clk_unstable                           , 
        CLK                                    => CLK_FB                                 , 

        FBSW_CNT_IN                            => FBSW_CNT_IN                            ,
        FB_VC_OUT                              => fb_vc                                  , 

        FBSW_START_TRIG_IN                     => FBSW_START_TRIG_IN                     , 
        FBSW_START_RPLS_OUT                    => fbsw_round_start_pls                   , 

        FBSW_SC_PATH_SEL_IN                    => reg_sc_path_sel                        ,

        AUTO_MODE_DONE_IN                      => FBSW_AUTO_MODE_DONE_IN                 , 
    
        FB_VLD_IN                              => (others => '1')                        , 
        FB_MONO_I_IN	                       => fb_align_i                             ,
        FB_MONO_Q_IN	                       => fb_align_q                             ,

        FB_MONO_NCO_I_IN                       => (others => (others => '0'))            , 
        FB_MONO_NCO_Q_IN                       => (others => (others => '0'))            , 

        FB_POLY_EVEN_I_IN                      => (others => (others => '0'))            , 
        FB_POLY_EVEN_Q_IN                      => (others => (others => '0'))            , 

        FB_POLY_ODD_I_IN                       => (others => (others => '0'))            , 
        FB_POLY_ODD_Q_IN                       => (others => (others => '0'))            , 
    
        FB_VLD_OUT                             => fb_sw_ctrl_vld                         , 
        FB_MONO_I_OUT                          => fb_sw_ctrl_i                           , 
        FB_MONO_Q_OUT                          => fb_sw_ctrl_q                           , 
    
        FB_POLY_EVEN_I_OUT                     => open                                   , 
        FB_POLY_EVEN_Q_OUT                     => open                                   , 
 
        FB_POLY_ODD_I_OUT                      => open                                   , 
        FB_POLY_ODD_Q_OUT                      => open                                   , 
    
        -- For PATH_DGATT
        FB_FWD_DGATT_VALUE_IN                  => fb_fwd_att_value_cdc                   , 
        FB_RVS_DGATT_VALUE_IN                  => fb_rvs_att_value_cdc                   , 
                                                                                         
        FB_DGATT_OUT                           => fb_atten_value                         , 
    
        -- For FB_LOOPBACK 
        SC_LOOPBACK_ON_IN                      => SC_LB_ON_IN                            , 
                                                                                         
        DL_DACIF_MONO_I_IN                     => dl_dacif_on_sel_i                      , 
        DL_DACIF_MONO_Q_IN                     => dl_dacif_on_sel_q                      , 
                                                  
        DL_DACIF_POLY_EVEN_I_IN                => (others => (others => '0'))            , 
        DL_DACIF_POLY_EVEN_Q_IN                => (others => (others => '0'))            , 
                                                                                         
        DL_DACIF_POLY_ODD_I_IN                 => (others => (others => '0'))            , 
        DL_DACIF_POLY_ODD_Q_IN                 => (others => (others => '0'))            , 
    
        -- For SC
        SC_DPDFB_PIM_MODE_SEL_IN               => reg_sc_dpdfb_pim_mode_sel              , 

        DL_CFR_MONO_I_IN                       => dl_dpdblk_in_i                         , 
        DL_CFR_MONO_Q_IN                       => dl_dpdblk_in_q                         , 
                                                  
        DL_CFR_POLY_EVEN_I_IN                  => (others => (others => '0'))            , 
        DL_CFR_POLY_EVEN_Q_IN                  => (others => (others => '0'))            , 
                                                                                         
        DL_CFR_POLY_ODD_I_IN                   => (others => (others => '0'))            , 
        DL_CFR_POLY_ODD_Q_IN                   => (others => (others => '0'))            , 
                                                                                         
                                                  
        DL_DPD_MONO_I_IN                       => dl_dpdhc_out_i                         , 
        DL_DPD_MONO_Q_IN                       => dl_dpdhc_out_q                         , 
                                                  
        DL_DPD_POLY_EVEN_I_IN                  => (others => (others => '0'))            , 
        DL_DPD_POLY_EVEN_Q_IN                  => (others => (others => '0'))            , 
                                                                             
        DL_DPD_POLY_ODD_I_IN                   => (others => (others => '0'))            , 
        DL_DPD_POLY_ODD_Q_IN                   => (others => (others => '0'))            ,                                                                                          
                                                  
        DL_FB_ATT_MONO_I_IN                    => fb_atten_out_i                         , 
        DL_FB_ATT_MONO_Q_IN                    => fb_atten_out_q                         , 
                                                  
        DL_FB_ATT_POLY_EVEN_I_IN               => (others => (others => '0'))            , 
        DL_FB_ATT_POLY_EVEN_Q_IN               => (others => (others => '0'))            , 
                                                                                         
        DL_FB_ATT_POLY_ODD_I_IN                => (others => (others => '0'))            , 
        DL_FB_ATT_POLY_ODD_Q_IN                => (others => (others => '0'))            , 
    
    
        DL_PIM_3RD_IM_MIXER_I_IN               => ul_pim_sc_3rd_im_i                     , 
        DL_PIM_3RD_IM_MIXER_Q_IN               => ul_pim_sc_3rd_im_q                     , 
                                                  
        UL_PIM_ERROR_I_IN                      => ul_pim_sc_err_i                        , 
        UL_PIM_ERROR_Q_IN                      => ul_pim_sc_err_q                        , 
                                                                                           
        UL_PIM_TARGET_I_IN                     => ul_pim_sc_tgt_i                        , 
        UL_PIM_TARGET_Q_IN                     => ul_pim_sc_tgt_q                        , 
                                                                                         
        DL_PIM_CFR_I_IN                        => ul_pim_sc_cfr_i                        , 
        DL_PIM_CFR_Q_IN                        => ul_pim_sc_cfr_q                        , 
                                                                                         
        DL_PIM_INTER_DUC_DLY_I_IN              => ul_pim_interb_ducdly_i                 , 
        DL_PIM_INTER_DUC_DLY_Q_IN              => ul_pim_interb_ducdly_q                 , 
                                                                                         
        UL_PIM_DBG_I_IN                        => ul_pim_sc_dbg_i                        , 
        UL_PIM_DBG_Q_IN                        => ul_pim_sc_dbg_q                        , 
    
        DBG_PIM_MIXPS_I_IN                     => dbg_pim_mixps_i                        , 
        DBG_PIM_MIXPS_Q_IN                     => dbg_pim_mixps_q                        , 
    
        SC_REF_VLD_OUT                         => sc_ref_vld                             , 
                                                                                         
        SC_REF_I_OUT                           => sc_ref_i                               , 
        SC_REF_Q_OUT                           => sc_ref_q                               , 
                                                                                         
        SC_DPD_I_OUT                           => sc_dpd_i                               , 
        SC_DPD_Q_OUT                           => sc_dpd_q                               , 
                                                                                         
        SC_FB_I_OUT                            => sc_fb_i                                , 
        SC_FB_Q_OUT                            => sc_fb_q                                , 
                                                                                         
        SC_PIM_SRC0_I_OUT                      => sc_pim_src0_i                          , 
        SC_PIM_SRC0_Q_OUT                      => sc_pim_src0_q                          , 
                                                                                         
        SC_PIM_SRC1_I_OUT                      => sc_pim_src1_i                          , 
        SC_PIM_SRC1_Q_OUT                      => sc_pim_src1_q                          , 
                                                                                         
        SC_PIM_DBG_I_OUT                       => sc_pim_dbg_i                           , 
        SC_PIM_DBG_Q_OUT                       => sc_pim_dbg_q                             
    
        );


    FBSW_VAL_OUT <= fb_vc(3 downto 0);

    U_FB_Mixer : NCO_SYMMETRY 
        generic map(
            DEVICE                                 => DEVICE                              , 
        
            HOVS                                   => DL_HOVS                             , 
            SYMMETRY                               => FALSE                               , 

            POS_SHIFTH_PATH_NUM                    => FB_PATH_NUM                         , 
            NEG_SHIFTH_PATH_NUM                    => FB_PATH_NUM                         , 
            NCO_WIDTH                              => 16                                  , 
            RES_VAL                                => DL_NCO_RESOLUTION/2                   
        )
        port map(
            RST                                    => RST_DPD                             , 
            CLK                                    => CLK_DL                              , 
        
            NCO_WREN                               => FB_NCO_WEN_IN(0)                    , 
            NCO_WORD                               => FB_NCO_WORD_IN(0)                   , 
        
            NCO_FREQ_COMP_OFFSET                   => (others => '0')                     , 
        
            DATA_P_SH_VLD_IN                       => fb_sw_ctrl_vld                      , 
            DATA_P_SH_I_IN                         => fb_sw_ctrl_i                        , 
            DATA_P_SH_Q_IN                         => fb_sw_ctrl_q                        , 
        
            DATA_P_SH_VLD_OUT                      => fb_sw_ctrl_nco_vld                  , 
            DATA_P_SH_I_OUT                        => fb_sw_ctrl_i_nco                    , 
            DATA_P_SH_Q_OUT                        => fb_sw_ctrl_q_nco                    , 
        
            DATA_N_SH_VLD_IN                       => (others => '0')                     , 
            DATA_N_SH_I_IN                         => (others => (others => '0'))         , 
            DATA_N_SH_Q_IN                         => (others => (others => '0'))         , 
        
            DATA_N_SH_VLD_OUT                      => open                                , 
            DATA_N_SH_I_OUT                        => open                                , 
            DATA_N_SH_Q_OUT                        => open                                  
        );

    G_FB_Path : for I in 0 to (FB_PATH_NUM-1) generate begin
        -- R8.16.3 FB Filter
        G_Using_FB_Filter : if (FB_FILTER_IMPLEMENTATION = TRUE) generate begin

            U_FB_FILTER : MONO_FIR_WRAPPER 
            generic map(
                HOVS                                      => FB_HOVS               ,
                RND_POINT                                 => FB_FILTER_RND_POINT   ,
                TAP_NUM                                   => FB_FILTER_TAP_NUM
                )
            port map(
                RST                                       => clk_unstable          ,
                CLK                                       => CLK_FB                ,
            
                BYPASS_IN                                 => FB_FILTER_BYPASS_IN(I),
            
                VALID_IN                                  => fb_sw_ctrl_nco_vld(I) ,
                I_DATA_IN                                 => fb_sw_ctrl_i_nco(I)   ,
                Q_DATA_IN                                 => fb_sw_ctrl_q_nco(I)   ,
                
                VALID_OUT                                 => fb_filter_out_vld(I)  ,
                I_DATA_OUT                                => fb_filter_out_i(I)    ,
                Q_DATA_OUT                                => fb_filter_out_q(I)
                );
        end generate;

        G_Unusing_FB_Filter : if (FB_FILTER_IMPLEMENTATION = FALSE) generate begin
            fb_filter_out_vld(I) <= fb_sw_ctrl_nco_vld(I);                         
            fb_filter_out_i(I)   <= fb_sw_ctrl_i_nco(I)  ;                         
            fb_filter_out_q(I)   <= fb_sw_ctrl_q_nco(I)  ;                         
        end generate;

        fb_pwrmsr_in_i(I) <= fb_filter_out_i(I) when PWR_MSR_EN_IN = '1' else (others => '0');
        fb_pwrmsr_in_q(I) <= fb_filter_out_q(I) when PWR_MSR_EN_IN = '1' else (others => '0');
        
        -- FB Power Measure Sync
        U_D0 : TDD_STRB_DLY generic map(FB_INPUT_ALIGN_DLY) port map(clk_unstable, CLK_FB, '0', PWR_MSR_FB_SYNC_IN     , '0'  , pwr_msr_strb_align_dly, open);
        U_D1 : TDD_STRB_DLY generic map(FB_SW_DLY         ) port map(clk_unstable, CLK_FB, '0', pwr_msr_strb_align_dly , '0'  , pwr_msr_strb_sw_dly   , open);

        -- R8.16.4 Power Measurement
        G_Using_FB_PWRMSR : if (FB_PWRMEAS_IMPLEMENTATION = TRUE) generate begin 

            process(CLK_FB)
            begin
                if (rising_edge(CLK_FB)) then
                    fb_pwr_strb              <= pwr_msr_strb_sw_dly and fbsw_ssb_ind_flga_2d;
                end if;
            end process;

            U_FB_Even_PWRMSR : PWRMEAS_MANTISSA 
            generic map(
                DEVICE                       => DEVICE                          , 
                CLK_DIV                      => FB_HOVS                         , 
                DATA_WIDTH                   => 16                               
                )
            port map(
                RST                          => clk_unstable                    , 
                CLK                          => CLK_FB                          , 
                
                FRAME_SYNC_IN                => fb_pwr_strb                     , 
                TDD_SIG_IN                   => fb_tdd_strb_fir_dly             , 
            
                DATA_I_IN                    => fb_pwrmsr_in_i(I)               , 
                DATA_Q_IN                    => fb_pwrmsr_in_q(I)               , 
            
                PWR_UPDATE_DONE_OUT          => fb_pwr_update_done(I)           , 
                PWR_OUT                      => fb_pwr(I)                        
                );
        end generate;

        G_Unusing_FB_PWRMSR : if (FB_PWRMEAS_IMPLEMENTATION = FALSE) generate begin 
            fb_pwr_update_done(I) <= '0';             
            fb_pwr(I)             <= (others => '0'); 
        end generate;

        G_Using_FB_ATTEN : if (FB_ATTEN_IMPLEMENTATION = TRUE) generate begin 
            U_FB_ATTEN : PATH_DGATT 
            generic map(
                DEVICE                       => DEVICE                          , 
                RND_BIT                      => 15                              ,
                HOVS                         => FB_HOVS                           
                )
            port map(
                RST                          => clk_unstable                    , 
                CLK                          => CLK_FB                          , 
            
                DATA_VALID_IN                => fb_sw_ctrl_vld(I)               , 
                DATA_I_IN                    => fb_sw_ctrl_i(I)                 , 
                DATA_Q_IN                    => fb_sw_ctrl_q(I)                 , 
            
                DGATT_VAL                    => fb_atten_value(I)               , 
            
                DATA_VALID_OUT               => fb_atten_out_vld(I)             ,
                DATA_I_OUT                   => fb_atten_out_i(I)               ,
                DATA_Q_OUT                   => fb_atten_out_q(I)           
                );

        end generate;

        G_Unusing_FB_ATTEN : if (FB_ATTEN_IMPLEMENTATION = FALSE) generate begin 
            fb_atten_out_vld(I)    <= fb_sw_ctrl_vld(I);    
            fb_atten_out_i(I)      <= fb_sw_ctrl_i(I); 
            fb_atten_out_q(I)      <= fb_sw_ctrl_q(I); 
        end generate;

    end generate;

    FB_PWR_MSR_BFN_STRB_OUT <= fb_bfn_strb_fir_dly;
    FB_PWR_MSR_DONE_OUT     <= fb_pwr_update_done;           
    FB_PWR_OUT              <= fb_pwr;                       


-- ***********************************
-- Uplink Path 
-- ***********************************
    G_Using_PIMD_BLK : if (PIM_IMPLEMENTATION = TRUE) generate begin 
        P_UL_Clock_Divide_Count : process(rst_ul, CLK_UL) begin
            if (rst_ul = '1') then
                ul_clk_div_cnt <= (others => '0');
            elsif (CLK_UL'event) and (CLK_UL = '1') then
                if (ul_clk_div_cnt = UL_HOVS-1) then 
                    ul_clk_div_cnt <= (others => '0');
                else 
                    ul_clk_div_cnt <= ul_clk_div_cnt + '1';
                end if;
            end if;
        end process;

        ul_vld <= '1' when (ul_clk_div_cnt = UL_HOVS-1) else '0';

        G_UL_Data_Align : for I in 0 to (RX_ANT_NUM-1) generate begin
            P_UL_Data_Align : process(CLK_UL) begin
                if (CLK_UL'event) and (CLK_UL = '1') then
                    ul_input_vld(I)                 <= ul_vld;
            	    if (ul_vld = '1') then
                        ul_input_i(I)               <= UL_I_IN(I);
                        ul_input_q(I)               <= UL_Q_IN(I);
                    end if;

                    if (DL_HOVS = 1) then
                        dl_inter_duc_output_vld(I)  <= '1';
                        dl_inter_duc_output_i(I)    <= DL_INTERBAND_I_IN(I);
                        dl_inter_duc_output_q(I)    <= DL_INTERBAND_Q_IN(I);
                    end if;
                end if;
            end process;
        end generate;

        U_PIM_BLK : PIMD_BLK 
        generic map(
            DEVICE                                 => DEVICE                                 , 
           
            TX_ANT_NUM                             => TX_ANT_NUM                             , 
            RX_ANT_NUM                             => RX_ANT_NUM                             , 
        
            PIMD_BLK_TYPE                          => PIM_BLK_TYPE                           ,
            PIM_SRC_NUM                            => PIM_SRC_NUM                            , 
        
            PIMD_OPR_CLK_RATE                      => OPR_CLK_DPD_TOP                        , 
            PIMD_UL_CLK_RATE                       => OPR_CLK_UL_PATH                        ,
            PIMD_OPR_SAMPLE_RATE                   => DPD_DL_SAMPLE_RATE                     , 
            PIMD_INTER_REF_SAMPLE_RATE             => DPD_DL_SAMPLE_RATE                     , 
            PIMD_ULINPUT_SAMPLE_RATE               => DPD_UL_SAMPLE_RATE                     ,
            PIMD_ULOUTPUT_SAMPLE_RATE              => DPD_UL_SAMPLE_RATE                     ,
        
            PIMD_CORE_LUT_OPTIMIZED                => PIMD_CORE_LUT_OPTIMIZED                ,
            PIMD_CORE_LUT_MEM_DEPTH                => PIMD_CORE_LUT_MEM_DEPTH                ,
            PIMD_CORE_LUT_RBTEST                   => PIMD_CORE_LUT_RBTEST                   , 
            PIMD_CORE_QPOINT_SEL                   => PIMD_CORE_QPOINT_SEL                   ,
            PIMD_CORE_LUT_DIMENSION                => PIMD_CORE_LUT_DIMENSION                ,
            PIMD_CORE_LUT_NUM                      => PIMD_CORE_LUT_NUM                      ,
            PIMD_CORE_TAP_NUM                      => PIMD_CORE_TAP_NUM                       
            )
        port map(
            RST_PIMD                               => RST_PIM                                , 
            RST_CPU                                => RST_CPUIF                              , 
        
            CLK_PIMD                               => CLK_DL                                 , 
            CLK_UL                                 => CLK_UL                                 , 
            CLK_CPU                                => CLK_CPUIF                              , 
        
        
            INT_SYSPLL_LOCK_IN                     => INT_SYSPLL_LOCK_IN                     , 
        
            DL_PIM_REF_VLD_IN                      => dl_dpdblk_in_vld                       , 
            DL_PIM_REF_I_IN                        => dl_dpdblk_in_i                         , 
            DL_PIM_REF_Q_IN                        => dl_dpdblk_in_q                         , 
        
            DL_PIM_INTERBAND_VLD_IN                => dl_inter_duc_output_vld                , 
            DL_PIM_INTERBAND_I_IN                  => dl_inter_duc_output_i                  , 
            DL_PIM_INTERBAND_Q_IN                  => dl_inter_duc_output_q                  , 
        
            UL_PIM_TGT_VLD_IN                      => ul_input_vld                           , 
            UL_PIM_TGT_I_IN                        => ul_input_i                             , 
            UL_PIM_TGT_Q_IN                        => ul_input_q                             , 
                                                                                             
            UL_PIMD_VLD_OUT                        => ul_output_vld                          , 
            UL_PIMD_I_OUT                          => ul_output_i                            , 
            UL_PIMD_Q_OUT                          => ul_output_q                            , 
        
            UL_PIM_SC_ERR_I_OUT                    => ul_pim_sc_err_i                        , 
            UL_PIM_SC_ERR_Q_OUT                    => ul_pim_sc_err_q                        , 
                                                                                             
            UL_PIM_SC_TGT_I_OUT                    => ul_pim_sc_tgt_i                        , 
            UL_PIM_SC_TGT_Q_OUT                    => ul_pim_sc_tgt_q                        , 
                                                                                             
            UL_PIM_INTERB_DUCDLY_I_OUT             => ul_pim_interb_ducdly_i                 , 
            UL_PIM_INTERB_DUCDLY_Q_OUT             => ul_pim_interb_ducdly_q                 , 
                                                                                             
            UL_PIM_SC_CFR_I_OUT                    => ul_pim_sc_cfr_i                        , 
            UL_PIM_SC_CFR_Q_OUT                    => ul_pim_sc_cfr_q                        , 
                                                                                             
            UL_PIM_SC_3RD_IM_I_OUT                 => ul_pim_sc_3rd_im_i                     , 
            UL_PIM_SC_3RD_IM_Q_OUT                 => ul_pim_sc_3rd_im_q                     , 
                                                                                             
            UL_PIM_SC_DBG_I_OUT                    => ul_pim_sc_dbg_i                        , 
            UL_PIM_SC_DBG_Q_OUT                    => ul_pim_sc_dbg_q                        , 

            DBG_PIM_MIXPS_I_OUT                    => dbg_pim_mixps_i                        , 
            DBG_PIM_MIXPS_Q_OUT                    => dbg_pim_mixps_q                        , 

        
            PIM_SC_INTER_PIM_DBG_SEL_IN            => reg_sc_inter_pim_dbg_sel               , 
            PIM_SC_INTRA_PIM_DBG_SEL_IN            => reg_sc_intra_pim_dbg_sel               , 
        
            PIM_DETECTOR_ON_IN                     => PIM_DETECTOR_ON_IN                     , 
            PIM_MITIGATOR_ON_IN                    => PIM_MITIGATOR_ON_IN                    , 
         
            PIM_CFR_REF_SEL_IN                     => PIM_CFR_REF_SEL_IN                     , 
        
            PIM_CORE_BYPASS_IN                     => PIM_CORE_BYPASS_IN                     , 
        
            PIM_GAIN_INDEX_IN                      => ul_pimcore_gain_index_cdc              , 
            PIM_QPOINT_SEL_IN                      => ul_pimcore_qpoint_sel_cdc              , 
        
            PIM_LUT_RB_TEST_EN_IN                  => reg_pim_core_lut_rb_test(0)            , 
        
            PIM_LUT_SWITCH_CDC_STRB_IN             => reg_pim_core_lut_switch_cdc_strb(0)    , 
            PIM_LUT_INPUT_SWITCH_IN                => reg_pim_core_lut_input_switch(0)       , 
            PIM_LUT_OUTPUT_SWITCH_IN               => reg_pim_core_lut_output_switch(0)      , 
        
            PIM_LUT_UPDATE_SW_IN                   => reg_pim_core_lut_update_sw             , 
            PIM_LUT_WREN_IN                        => reg_pim_core_lut_wren                  , 
            PIM_LUT_RDEN_IN                        => reg_pim_core_lut_rden                  , 
            PIM_LUT_ADDR_IN                        => reg_pim_core_lut_addr                  , 
            PIM_LUT_WDATA_IN                       => reg_pim_core_lut_wdata                 , 
            PIM_LUT_RDATA_OUT                      => reg_pim_core_lut_rdata                 , 
        
            PIM_CORE_COEF_WR_EN_IN                 => reg_pim_complex_filter_coef_wren       , 
            PIM_CORE_COEF_RD_EN_IN                 => reg_pim_complex_filter_coef_rden       , 
            PIM_CORE_COEF_WR_DN_IN                 => reg_pim_complex_filter_coef_wrdn       , 
            PIM_CORE_COEF_ADDR_IN                  => reg_pim_complex_filter_coef_addr       , 
            PIM_CORE_COEF_I_WDATA_IN               => reg_pim_complex_filter_coef_i_wdata    , 
            PIM_CORE_COEF_Q_WDATA_IN               => reg_pim_complex_filter_coef_q_wdata    , 
            PIM_CORE_COEF_I_RDATA_OUT              => reg_pim_complex_filter_coef_i_rdata    , 
            PIM_CORE_COEF_Q_RDATA_OUT              => reg_pim_complex_filter_coef_q_rdata    , 
        
            PIM_FILTER_BYPASS_IN                   => PIM_FILTER_BYPASS_IN                   , 
            PIM_FILTER_COEF_WR_EN_IN               => PIM_FILTER_COEF_WR_EN_IN               ,
            PIM_FILTER_COEF_RD_EN_IN               => PIM_FILTER_COEF_RD_EN_IN               ,
            PIM_FILTER_COEF_WR_DN_IN               => PIM_FILTER_COEF_WR_DN_IN               , 
            PIM_FILTER_COEF_ADDR_IN                => PIM_FILTER_COEF_ADDR_IN                , 
            PIM_FILTER_COEF_WR_DATA_IN             => PIM_FILTER_COEF_WR_DATA_IN             , 
            PIM_FILTER_COEF_RD_DATA_OUT            => PIM_FILTER_COEF_RD_DATA_OUT            , 
        
            PIM_NCO_WREN_IN                        => PIM_NCO_WREN_IN                        , 
            PIM_NCO_WORD_IN                        => PIM_NCO_WORD_IN                        , 
            -- selectable pim
            PIM_SLTB1_GAIN_INDEX_IN                => s_pim_sltb1_gain_index                 , 
            PIM_SLTB1_QPOINT_SEL_IN                => s_pim_sltb1_qpoint_sel                 , 
            PIMDLY_SLTB1_VALUE_IN                  => s_pimdly_sltb1_value                   , 

            PIM_SLTB1_LUT_UPDATE_SW_IN             => s_pim_sltb1_lut_update_sw              , 
            PIM_SLTB1_LUT_WREN_IN                  => s_pim_sltb1_lut_wren                   , 
            PIM_SLTB1_LUT_RDEN_IN                  => s_pim_sltb1_lut_rden                   , 
            PIM_SLTB1_LUT_ADDR_IN                  => s_pim_sltb1_lut_addr                   , 
            PIM_SLTB1_LUT_WDATA_IN                 => s_pim_sltb1_lut_wdata                  , 
            PIM_SLTB1_LUT_RDATA_OUT                => s_pim_sltb1_lut_rdata                  , 
                                  
            PIM_SLTB2_GAIN_INDEX_IN                => s_pim_sltb2_gain_index                 , 
            PIM_SLTB2_QPOINT_SEL_IN                => s_pim_sltb2_qpoint_sel                 , 
            PIMDLY_SLTB2_VALUE_IN                  => s_pimdly_sltb2_value                   , 

            PIM_SLTB2_LUT_UPDATE_SW_IN             => s_pim_sltb2_lut_update_sw              , 
            PIM_SLTB2_LUT_WREN_IN                  => s_pim_sltb2_lut_wren                   , 
            PIM_SLTB2_LUT_RDEN_IN                  => s_pim_sltb2_lut_rden                   , 
            PIM_SLTB2_LUT_ADDR_IN                  => s_pim_sltb2_lut_addr                   , 
            PIM_SLTB2_LUT_WDATA_IN                 => s_pim_sltb2_lut_wdata                  , 
            PIM_SLTB2_LUT_RDATA_OUT                => s_pim_sltb2_lut_rdata                  , 

            PIM_SLTB_INTRA_NCO_WREN_IN             => s_pim_sltb_intra_nco_wren              , 
            PIM_SLTB_INTRA_NCO_WORD_IN             => s_pim_sltb_intra_nco_word              , 
            PIM_SLTB_INTER1_NCO_WREN_IN            => s_pim_sltb_inter1_nco_wren             , 
            PIM_SLTB_INTER1_NCO_WORD_IN            => s_pim_sltb_inter1_nco_word             , 
            PIM_SLTB_INTER2_NCO_WREN_IN            => s_pim_sltb_inter2_nco_wren             , 
            PIM_SLTB_INTER2_NCO_WORD_IN            => s_pim_sltb_inter2_nco_word             , 

            INTRA_BAND_SEL_IN                      => s_intra_band_sel                       , 
            INTER_BAND_TYPE1_SEL_IN                => s_inter_band_type1_sel                 , 
            INTER_BAND_TYPE2_SEL_IN                => s_inter_band_type2_sel                 , 
            PIM_BIT_SHIFT_SEL_IN                   => s_pim_bit_shift_sel                    ,
                                                                             
            SHIFT_DIRECTION_INTRA_IN               => s_shift_direction_intra                , 
            SHIFT_DIRECTION_INTER1_IN              => s_shift_direction_inter1               , 
            SHIFT_DIRECTION_INTER2_IN              => s_shift_direction_inter2               , 
            -----    
    
            PIM_INTERBAND_DUC_GAIN_IN              => pim_interb_duc_gain_cdc                , 
        
            DL_INTRAB_DLY_VALUE_IN                 => ul_pimsrc_intrab_dly_cdc               ,        
            DL_INTERB_CDLY_VALUE_IN                => ul_pimsrc_interb_cdly_cdc              ,        
            DL_INTERB_FDLY_VALUE_IN                => ul_pimsrc_interb_fdly_cdc              ,        
            PIMDLY_VALUE_IN                        => ul_pim_ref_sample_dly_cdc              ,        

            PNPC_SEL_IN                            => ul_pim_pnpc_sel_cdc                    , 
            PNPC_EN_IN                             => reg_pnpc_en                            ,  
            PNPC_SET_IN                            => reg_pnpc_set                           ,  
            PNPC_MU_SEL_IN                         => ul_pnpc_mu_sel_cdc                     , 
            PNPC_SETVAL_I_IN                       => ul_pnpc_setval_i_cdc                   ,  
            PNPC_SETVAL_Q_IN                       => ul_pnpc_setval_q_cdc                   ,  
        
            PNPC_TP_DC_IQ_OUT                      => reg_pnpc_tp_dc_iq                      , 
        
            UL_PIM_NCO_WREN_IN                     => UL_PIM_NCO_WREN_IN                     , 
            UL_PIM_NCO_WORD_IN                     => UL_PIM_NCO_WORD_IN                     , 
        
            UL_PIM_FREQ_COMP_WORD_IN               => ul_pim_ul_mixer_freq_err_comp_word_cdc  
            );
    end generate;

    G_Unusing_PIMD_BLK : if (PIM_IMPLEMENTATION = FALSE) generate begin 

        ul_clk_div_cnt                      <= (others => '0');
        ul_vld                              <= '0';

        ul_input_vld                        <= (others => '0');            
        ul_input_i                          <= (others => (others => '0'));
        ul_input_q                          <= (others => (others => '0'));
                                                                        
        dl_inter_duc_output_vld             <= (others => '0');               
        dl_inter_duc_output_i               <= (others => (others => '0'));    
        dl_inter_duc_output_q               <= (others => (others => '0'));    

        ul_pim_sc_err_i                     <= (others => (others => '0'));  
        ul_pim_sc_err_q                     <= (others => (others => '0'));  

        ul_pim_sc_tgt_i                     <= (others => (others => '0'));  
        ul_pim_sc_tgt_q                     <= (others => (others => '0'));  
	
        ul_pim_interb_ducdly_i              <= (others => (others => '0'));  
        ul_pim_interb_ducdly_q              <= (others => (others => '0'));  

        ul_pim_sc_cfr_i                     <= (others => (others => '0'));  
        ul_pim_sc_cfr_q                     <= (others => (others => '0'));  
        
        ul_pim_sc_3rd_im_i                  <= (others => (others => '0'));  
        ul_pim_sc_3rd_im_q                  <= (others => (others => '0'));  

        ul_pim_sc_dbg_i                     <= (others => (others => '0'));  
        ul_pim_sc_dbg_q                     <= (others => (others => '0'));  

        reg_pim_core_lut_rdata              <= (others => (others => '0'));  

        reg_pim_complex_filter_coef_i_rdata <= (others => '0');  
        reg_pim_complex_filter_coef_q_rdata <= (others => '0');  

        PIM_FILTER_COEF_RD_DATA_OUT         <= (others => '0');  

        reg_pnpc_tp_dc_iq                   <= (others => (others => '0'));  

        ul_output_vld                       <= UL_SYNC_IN;
        ul_output_i                         <= UL_I_IN;   
        ul_output_q                         <= UL_Q_IN;   

    end generate;

    UL_SYNC_OUT <= ul_output_vld;                                                    
    UL_I_OUT    <= ul_output_i;                                                      
    UL_Q_OUT    <= ul_output_q;                                                      

-- ***********************************
-- Smart Capture 
-- ***********************************

    G_Using_Smart_Capture : if (SC_IMPLEMENTATION = TRUE) generate begin
        U_SMART_CAPTURE : SMART_CAPTURE 
        generic map(
            DEVICE                                 => DEVICE                                 , 
            SC_EXPANSION                           => SC_EXPANSION                           , 
            DPD_PATH_PHASE                         => DPD_PATH_PHASE                         ,
            STATIC_CAPTURE_COUNT                   => 3                                      , 
            CAPTURE_DONE_COUNT                     => 3                                      ,
            HOVS                                   => DL_HOVS                                
            )
        port map(
            -- Common
            RST_DSP                                => clk_unstable                           ,  
            CLK_DSP                                => CLK_DL                                 , 
            CLK_CPU                                => CLK_CPUIF                              , 
        
            -- Sync Strobe
            FS_10MS_IN                             => dl_bfn_strb_mixer_dly                  , 
            TDD_STROBE_IN                          => dl_tdd_strb_mixer_dly                  , 
        
            -- Capturing Sample Port
            REF_VALID_IN                           => sc_ref_vld                             , 
                                                                                             
            CFR_I_IN                               => sc_ref_i                               , 
            CFR_Q_IN                               => sc_ref_q                               , 
                                                                                             
            DPD_I_IN                               => sc_dpd_i                               , 
            DPD_Q_IN                               => sc_dpd_q                               , 
                                                                                             
            FB_I_IN                                => sc_fb_i                                , 
            FB_Q_IN                                => sc_fb_q                                , 
                                                                                             
            PIM_SRC0_I_IN                          => sc_pim_src0_i                          , 
            PIM_SRC0_Q_IN                          => sc_pim_src0_q                          , 
                                                                                             
            PIM_SRC1_I_IN                          => sc_pim_src1_i                          , 
            PIM_SRC1_Q_IN                          => sc_pim_src1_q                          , 
                                                                                             
            PIM_DBG_I_IN                           => sc_pim_dbg_i                           , 
            PIM_DBG_Q_IN                           => sc_pim_dbg_q                           , 
        
            -- Feedback Switch Information
            FB_VC_IN                               => fb_vc                                  , 
            FB_SW_ROUND_START_IN                   => fbsw_round_start_pls                   , 
                                                                                             
            -- For DPD SW iteration Time Test         
            FORCED_CAPTURE_CONTROL_IN              => reg_sc_forced_mode                     ,
            FB_MANUAL_MODE_IN                      => FBSW_MANUAL_MODE_IN                    ,
        
            -- Smart Capture Control & Status
            DEBOUNCING_TIME_IN                     => reg_sc_debouncing_time                 ,
            DPDFB_PIM_MODE_SEL_IN                  => reg_sc_dpdfb_pim_mode_sel              , 
            CAPTURE_CONTROL_IN                     => reg_sc_control                         ,
            CAPTURE_COMPLETE_OUT                   => reg_sc_complete_flag                   ,
        
            CAP_SIZE_SEL_IN                        => reg_sc_cap_size_sel                    ,
            TDD_MODE_IN                            => reg_sc_tdd_mode                        ,
        
            PATH_SEL_IN                            => reg_sc_path_sel(3 downto 0)            ,
            DPD_DELAY_IN                           => reg_sc_dpd_core_hc_latency             ,
            FB_DELAY_IN                            => reg_sc_fb_latency                      ,
            PIM_REF_DELAY_IN                       => reg_sc_ref_latency                     ,
        
            CAP_OFF_START_IN                       => reg_sc_cap_off_start                   ,
            CAP_OFF_STOP_IN                        => reg_sc_cap_off_stop                    ,
            STATIC_POSITION_IN                     => reg_sc_static_position                 ,
            SC_LENGTH_IN                           => reg_sc_static_length                   ,
            MAX_PEAK_BO_GAIN_IN                    => reg_sc_max_peak_bo_gain                ,
            CUR_PEAK_BO_GAIN_IN                    => reg_sc_cur_peak_bo_gain                ,
        
            CAP_FRAME_NUM_OUT                      => reg_sc_sub_peak_num                    ,
            CAP_FRAME_PEAK_OUT                     => reg_sc_sub_peak                        ,
            CAP_FRAME_PWR_OUT                      => reg_sc_sub_pwr                         , 
            CAP_TIME_INDEX_OUT                     => reg_sc_time_index                      , 
        
            -- CPU Access Interface : CPU Clock Domain
            CAP_MEM_SEL_IN                         => reg_sc_cap_memory_sel                  , 
            CAP_MEM_OE_IN                          => reg_sc_mem_rden                        , 
            CAP_MEM_ADDR_IN                        => reg_sc_mem_addr                        ,  
            CAP_MEM_DATA_OUT                       => reg_sc_mem_rdata                         
            );
    end generate;

    G_Unusing_Smart_Capture : if (SC_IMPLEMENTATION = FALSE) generate begin
        reg_sc_complete_flag  <= '0';                   
        reg_sc_sub_peak_num   <= (others => '0');                   
        reg_sc_sub_peak       <= (others => '0');                   
        reg_sc_sub_pwr        <= (others => '0');                   
        reg_sc_time_index     <= (others => '0');                   

        reg_sc_mem_rdata      <= (others => '0');  
    end generate;


-- ***********************************
-- CPUIF & MISC 
-- ***********************************

    -- CPUIF_DPDSC
    U_CPUIF_DSP_DPDSC : CPUIF_DSP_DPDSC
    generic map(
        DPD_CORE_IMPLEMENTATION             => DPD_CORE_IMPLEMENTATION             ,  
        DPD_CORE_LUT_OPTIMIZED              => DPD_CORE_LUT_OPTIMIZED              ,
        DPD_CORE_LUT_RBTEST                 => DPD_CORE_LUT_RBTEST                 ,
        SC_IMPLEMENTATION                   => SC_IMPLEMENTATION                   ,
        PIM_IMPLEMENTATION                  => PIM_IMPLEMENTATION                  ,
        PIMD_BLK_TYPE                       => PIM_BLK_TYPE                        ,
        PIM_CORE_LUT_OPTIMIZED              => PIMD_CORE_LUT_OPTIMIZED             ,
        PIM_CORE_LUT_RBTEST                 => PIMD_CORE_LUT_RBTEST                ,
                                                                                   
        RX_SSD_IMPLEMENTATION               => RX_SSD_IMPLEMENTATION               ,
        ADDR_WIDTH                          => ADDR_WIDTH                          ,
        WDATA_WIDTH                         => WDATA_WIDTH                         ,
        RDATA_WIDTH                         => RDATA_WIDTH                         ,
    
        TX_ANT_NUM                          => TX_ANT_NUM                    ,
        RX_ANT_NUM                          => RX_ANT_NUM                           
        )
    port map(
        -- Reset & Clock
        RST_CPU                             => RST_CPUIF                           ,
        CLK_CPU                             => CLK_CPUIF                           ,
        CLK_SC                              => CLK_DL                              ,
        CLK_PIMD                            => CLK_DL                              ,
    
        -- CPU Interface
        ADDR_CPU_IN                         => ADDR_CPUIF_IN                       ,
        WDATA_CPU_IN                        => WDATA_CPUIF_IN                      ,
        RDATA_DPD_OUT                       => RDATA_CPUIF_OUT                     ,
        WREN_CPU_IN                         => WREN_CPUIF_IN                       ,
        RDEN_CPU_IN                         => RDEN_CPUIF_IN                       ,
        RDVLD_CPU_OUT                       => RDVLD_CPUIF_OUT                     ,
        
        -- DPD_CORE Control
        DPD_CORE_SET_STRB_OUT               => reg_dpd_core_set_strb               ,
        DPD_CORE_GAIN_INDEX_OUT             => reg_dpd_core_gain_index             ,
        DPD_CORE_QPOINT_SEL_OUT             => reg_dpd_core_qpoint_sel             ,
                                                                                   
        DPD_CORE_LUT_SWITCH_CDC_STRB_OUT    => reg_dpd_core_lut_switch_cdc_strb    ,
        DPD_CORE_LUT_INPUT_SWITCH_OUT       => reg_dpd_core_lut_input_switch       ,
        DPD_CORE_LUT_OUTPUT_SWITCH_OUT      => reg_dpd_core_lut_output_switch      ,
                                                                                   
        DPD_CORE_LUT_RB_TEST_OUT            => reg_dpd_core_lut_rb_test            ,
                                                                                   
        DPD_CORE_LUT_UPDATE_SW_OUT          => reg_dpd_core_lut_update_sw          ,
        DPD_CORE_LUT_WREN_OUT               => reg_dpd_core_lut_wren               ,
        DPD_CORE_LUT_RDEN_OUT               => reg_dpd_core_lut_rden               ,
        DPD_CORE_LUT_ADDR_OUT               => reg_dpd_core_lut_addr               ,
        DPD_CORE_LUT_WDATA_OUT              => reg_dpd_core_lut_wdata              ,
        DPD_CORE_LUT_RDATA_IN               => reg_dpd_core_lut_rdata              ,
                                                                                   
        -- PIM_CORE Control                                                        
        PIM_DETECTOR_ON_IN                  => PIM_DETECTOR_ON_IN                  , -- : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
        PIM_MITIGATOR_ON_IN                 => PIM_MITIGATOR_ON_IN                 , -- : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
        -- PIM (LUT dpd core)                                                        --                                                                                    
        PIM_CORE_SET_STRB_OUT               => reg_pim_core_set_strb               , -- : out std_logic_vector( 1 downto 0);
        PIM_CORE_GAIN_INDEX_OUT             => reg_pim_core_gain_index             , -- : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
        PIM_CORE_QPOINT_SEL_OUT             => reg_pim_core_qpoint_sel             , -- : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection
                                                                                     --                                                                                    
        PIM_CORE_LUT_SWITCH_CDC_STRB_OUT    => reg_pim_core_lut_switch_cdc_strb    , -- : out std_logic_vector( 3 downto 0);  -- unsued
        PIM_CORE_LUT_INPUT_SWITCH_OUT       => reg_pim_core_lut_input_switch       , -- : out std_logic_array20(3 downto 0);  -- unsued
        PIM_CORE_LUT_OUTPUT_SWITCH_OUT      => reg_pim_core_lut_output_switch      , -- : out std_logic_array20(3 downto 0);  -- unsued
                                                                                     --                                                                                    
        PIM_CORE_LUT_RB_TEST_OUT            => reg_pim_core_lut_rb_test            , -- : out std_logic_vector( 3 downto 0);  -- unsued
                                                                                     --                                                                                    
        PIM_CORE_LUT_UPDATE_SW_OUT          => reg_pim_core_lut_update_sw          , -- : out std_logic_vector( TX_ANT_NUM-1 downto 0);
        PIM_CORE_LUT_WREN_OUT               => reg_pim_core_lut_wren               , -- : out std_logic_vector( TX_ANT_NUM-1 downto 0);
        PIM_CORE_LUT_RDEN_OUT               => reg_pim_core_lut_rden               , -- : out std_logic_vector( TX_ANT_NUM-1 downto 0);
        PIM_CORE_LUT_ADDR_OUT               => reg_pim_core_lut_addr               , -- : out std_logic_array15(TX_ANT_NUM-1 downto 0);
        PIM_CORE_LUT_WDATA_OUT              => reg_pim_core_lut_wdata              , -- : out std_logic_array32(TX_ANT_NUM-1 downto 0);
        PIM_CORE_LUT_RDATA_IN               => reg_pim_core_lut_rdata              , -- : in  std_logic_array32(TX_ANT_NUM-1 downto 0);
        -- selectable PIM_CORE 1 -- add                                              --                                                                                    
        PIM_SLTB1_DETECTOR_ON_IN            => PIM_DETECTOR_ON_IN                  , -- : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
        PIM_SLTB1_MITIGATOR_ON_IN           => PIM_MITIGATOR_ON_IN                 , -- : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
                                                                                     --                                                                                    
        PIM_SLTB1_CORE_SET_STRB_OUT         => open                                , -- : out std_logic_vector( 1 downto 0);
        PIM_SLTB1_CORE_GAIN_INDEX_OUT       => s_pim_sltb1_gain_index              , -- : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
        PIM_SLTB1_CORE_QPOINT_SEL_OUT       => s_pim_sltb1_qpoint_sel              , -- : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection
                                                                                     --                                                                                    
        PIM_SLTB1_CORE_LUT_UPDATE_SW_OUT    => s_pim_sltb1_lut_update_sw           , -- : out std_logic_vector( 3 downto 0);
        PIM_SLTB1_CORE_LUT_WREN_OUT         => s_pim_sltb1_lut_wren                , -- : out std_logic_vector( 3 downto 0);
        PIM_SLTB1_CORE_LUT_RDEN_OUT         => s_pim_sltb1_lut_rden                , -- : out std_logic_vector( 3 downto 0);
        PIM_SLTB1_CORE_LUT_ADDR_OUT         => s_pim_sltb1_lut_addr                , -- : out std_logic_array15(3 downto 0);
        PIM_SLTB1_CORE_LUT_WDATA_OUT        => s_pim_sltb1_lut_wdata               , -- : out std_logic_array32(3 downto 0);
        PIM_SLTB1_CORE_LUT_RDATA_IN         => s_pim_sltb1_lut_rdata               , -- : in  std_logic_array32(3 downto 0);
        -- selectable PIM_CORE 2 -- add                                              --                                                                                    
        PIM_SLTB2_DETECTOR_ON_IN            => PIM_DETECTOR_ON_IN                  , -- : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
        PIM_SLTB2_MITIGATOR_ON_IN           => PIM_MITIGATOR_ON_IN                 , -- : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
                                                                                     --                                                                                    
        PIM_SLTB2_CORE_SET_STRB_OUT         => open                                , -- : out std_logic_vector( 1 downto 0);
        PIM_SLTB2_CORE_GAIN_INDEX_OUT       => s_pim_sltb2_gain_index              , -- : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
        PIM_SLTB2_CORE_QPOINT_SEL_OUT       => s_pim_sltb2_qpoint_sel              , -- : out std_logic_array2( RX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection
                                                                                     --                                                                                    
        PIM_SLTB2_CORE_LUT_UPDATE_SW_OUT    => s_pim_sltb2_lut_update_sw           , -- : out std_logic_vector( 3 downto 0);
        PIM_SLTB2_CORE_LUT_WREN_OUT         => s_pim_sltb2_lut_wren                , -- : out std_logic_vector( 3 downto 0);
        PIM_SLTB2_CORE_LUT_RDEN_OUT         => s_pim_sltb2_lut_rden                , -- : out std_logic_vector( 3 downto 0);
        PIM_SLTB2_CORE_LUT_ADDR_OUT         => s_pim_sltb2_lut_addr                , -- : out std_logic_array15(3 downto 0);
        PIM_SLTB2_CORE_LUT_WDATA_OUT        => s_pim_sltb2_lut_wdata               , -- : out std_logic_array32(3 downto 0);
        PIM_SLTB2_CORE_LUT_RDATA_IN         => s_pim_sltb2_lut_rdata               , -- : in  std_logic_array32(3 downto 0);
        --                                                                           --                                                                                    
        PIM_SLTB_INTRA_NCO_WREN_OUT         => s_pim_sltb_intra_nco_wren           , -- : out std_logic;   
        PIM_SLTB_INTRA_NCO_WORD_OUT         => s_pim_sltb_intra_nco_word           , -- : out std_logic_vector( 31 downto 0);   
        PIM_SLTB_INTER1_NCO_WREN_OUT        => s_pim_sltb_inter1_nco_wren          , -- : out std_logic;   
        PIM_SLTB_INTER1_NCO_WORD_OUT        => s_pim_sltb_inter1_nco_word          , -- : out std_logic_vector( 31 downto 0);   
        PIM_SLTB_INTER2_NCO_WREN_OUT        => s_pim_sltb_inter2_nco_wren          , -- : out std_logic;   
        PIM_SLTB_INTER2_NCO_WORD_OUT        => s_pim_sltb_inter2_nco_word          , -- : out std_logic_vector( 31 downto 0);   
                                                                                     --                                                                                    
        PIMDLY_SLTB1_VALUE_OUT              => s_pimdly_sltb1_value                , -- : out std_logic_array12(TX_ANT_NUM-1 downto 0);
        PIMDLY_SLTB2_VALUE_OUT              => s_pimdly_sltb2_value                , -- : out std_logic_array12(TX_ANT_NUM-1 downto 0);
                                                                                     --                                                                                    
        PIM_SLTB_INTRA_BAND_SEL_OUT         => s_intra_band_sel                    , -- : out std_logic; 
        PIM_SLTB_INTER_BAND_TYPE1_SEL_OUT   => s_inter_band_type1_sel              , -- : out std_logic_vector(1 downto 0);
        PIM_SLTB_INTER_BAND_TYPE2_SEL_OUT   => s_inter_band_type2_sel              , -- : out std_logic_vector(1 downto 0);
        PIM_SLTB_BIT_SHIFT_SEL_OUT          => s_pim_bit_shift_sel                 , -- : out std_logic_vector(1 downto 0);
                                                                                     --                                                                                    
        PIM_SLTB_SHIFT_DIRECTION_INTRA_OUT  => s_shift_direction_intra             , -- : out std_logic_array2(TX_ANT_NUM-1 downto 0);
        PIM_SLTB_SHIFT_DIRECTION_INTER1_OUT => s_shift_direction_inter1            , -- : out std_logic_array2(TX_ANT_NUM-1 downto 0);
        PIM_SLTB_SHIFT_DIRECTION_INTER2_OUT => s_shift_direction_inter2            , -- : out std_logic_array2(TX_ANT_NUM-1 downto 0);
    
        ----- coef type pim core
        PIM_COMPLEX_FILTER_COEF_WREN_OUT    => reg_pim_complex_filter_coef_wren    ,
        PIM_COMPLEX_FILTER_COEF_RDEN_OUT    => reg_pim_complex_filter_coef_rden    ,
        PIM_COMPLEX_FILTER_COEF_WRDN_OUT    => reg_pim_complex_filter_coef_wrdn    ,
        PIM_COMPLEX_FILTER_COEF_ADDR_OUT    => reg_pim_complex_filter_coef_addr    ,
        PIM_COMPLEX_FILTER_COEF_I_WDATA_OUT => reg_pim_complex_filter_coef_i_wdata ,
        PIM_COMPLEX_FILTER_COEF_Q_WDATA_OUT => reg_pim_complex_filter_coef_q_wdata ,
        PIM_COMPLEX_FILTER_COEF_I_RDATA_IN  => reg_pim_complex_filter_coef_i_rdata ,
        PIM_COMPLEX_FILTER_COEF_Q_RDATA_IN  => reg_pim_complex_filter_coef_q_rdata ,
        -- ~
        PIM_SRC_INTRAB_DLY_STRB_OUT         => reg_pimsrc_intrab_dly_strb          ,
        PIM_SRC_INTRAB_DLY_OUT              => reg_pimsrc_intrab_dly               ,
                                                                                   
        PIM_SRC_INTERB_DLY_STRB_OUT         => reg_pimsrc_interb_dly_strb          ,
        PIM_SRC_INTERB_CDLY_OUT             => reg_pimsrc_interb_cdly              ,
        PIM_SRC_INTERB_FDLY_OUT             => reg_pimsrc_interb_fdly              ,
                                                                                 
        PIM_REF_DLY_STRB_OUT                => reg_pim_ref_dly_strb                ,
        PIM_REF_SAMPLE_DLY_OUT              => reg_pim_ref_sample_dly              ,
                                                                                 
        PIM_UL_DLY_STRB_OUT                 => reg_pim_ul_dly_strb                 ,
        PIM_UL_SAMPLE_DLY_OUT               => reg_pim_ul_sample_dly               ,
                                                                                   
        PNPC_EN_OUT                         => reg_pnpc_en                         ,
        PNPC_SET_OUT                        => reg_pnpc_set                        ,
                                                                                   
        PNPC_MU_SEL_STRB_OUT                => reg_pnpc_mu_sel_strb                ,
        PNPC_MU_SEL_OUT                     => reg_pnpc_mu_sel                     ,
                                                                                   
        PNPC_SETVAL_STRB_OUT                => reg_pnpc_setval_strb                ,
        PNPC_SETVAL_I_OUT                   => reg_pnpc_setval_i                   ,
        PNPC_SETVAL_Q_OUT                   => reg_pnpc_setval_q                   ,
                                                                                   
        PNPC_TP_DC_IQ_IN                    => reg_pnpc_tp_dc_iq                   ,
    
        PIM_UL_MIXER_FREQ_ERR_COMP_STRB_OUT => reg_pim_ul_mixer_freq_err_comp_strb ,
        PIM_UL_MIXER_FREQ_ERR_COMP_WORD_OUT => reg_pim_ul_mixer_freq_err_comp_word ,
    
        -- SMART_CAPTURE Control
        SC_CONTROL_OUT                      => reg_sc_control                      ,
        SC_COMPLETE_FLAG_IN                 => reg_sc_complete_flag                ,
        SC_TDD_MODE_OUT                     => reg_sc_tdd_mode                     ,
        SC_FORCED_MODE_OUT                  => reg_sc_forced_mode                  ,
        SC_DEBOUNCING_TIME_OUT              => reg_sc_debouncing_time              ,
        SC_CAP_SIZE_SEL_OUT                 => reg_sc_cap_size_sel                 ,
        SC_DPDFB_PIM_MODE_SEL_OUT           => reg_sc_dpdfb_pim_mode_sel           ,
                                                                                   
        SC_PATH_SEL_STRB_OUT                => reg_sc_path_sel_cdc_strb            ,
        SC_PATH_SEL_OUT                     => reg_sc_path_sel                     ,
                                                                                   
        SC_CAP_MEMORY_SEL_OUT               => reg_sc_cap_memory_sel               ,
        SC_DPD_CORE_HC_LATENCY_OUT          => reg_sc_dpd_core_hc_latency          ,
        SC_FB_LATENCY_OUT                   => reg_sc_fb_latency                   ,
        SC_REF_LATENCY_OUT                  => reg_sc_ref_latency                  ,
        SC_CAP_OFF_START_OUT                => reg_sc_cap_off_start                ,
        SC_CAP_OFF_STOP_OUT                 => reg_sc_cap_off_stop                 ,
        SC_STATIC_POSITION_OUT              => reg_sc_static_position              ,
        SC_STATIC_LENGTH_OUT                => reg_sc_static_length                ,
        SC_MAX_PEAK_BO_GAIN_OUT             => reg_sc_max_peak_bo_gain             ,
        SC_CUR_PEAK_BO_GAIN_OUT             => reg_sc_cur_peak_bo_gain             ,
        SC_SUB_PWR_IN                       => reg_sc_sub_pwr                      ,
        SC_SUB_PEAK_IN                      => reg_sc_sub_peak                     ,
        SC_SUB_PEAK_NUM_IN                  => reg_sc_sub_peak_num                 ,
        SC_TIME_INDEX_IN                    => reg_sc_time_index                   ,
                                                                                   
        SC_INTER_PIM_DBG_SEL_OUT            => reg_sc_inter_pim_dbg_sel            ,
        SC_INTRA_PIM_DBG_SEL_OUT            => reg_sc_intra_pim_dbg_sel            ,
                                                                                   
        SC_MEM_RDEN_OUT                     => reg_sc_mem_rden                     ,
        SC_MEM_ADDR_OUT                     => reg_sc_mem_addr                     ,
        SC_MEM_RDATA_IN                     => reg_sc_mem_rdata                    ,
        
        UL_MON0_DATA_IN                     => ul_mon0_data_iq                     ,
        UL_MON0_VLD_IN                      => ul_vld                              ,
        UL_MON1_DATA_IN                     => ul_mon1_data_iq                     ,
        UL_MON1_VLD_IN                      => ul_vld                              ,
        UL_MON2_DATA_IN                     => ul_mon2_data_iq                     ,
        UL_MON2_VLD_IN                      => ul_output_vld(0)                    ,
    
        -- SSD Control
        SSD_PATH_SEL_OUT                    => reg_ssd_path_sel                    ,
        SSD_CTRL_OUT                        => reg_ssd_ctrl                        ,
        SSD_PERIOD_OUT                      => reg_ssd_period                      ,
        SSD_LENGTH_PER_SWITCH_OUT           => reg_ssd_length_per_switch           ,
        SSD_ACCU_LENGTH_OUT                 => reg_ssd_accu_length                 ,
        SSD_ACCU_DONE_IN                    => reg_ssd_accu_done                   ,
        SSD_GAIN_OUT                        => reg_ssd_gain                        ,
        SSD_PTN_WREN_OUT                    => reg_ptn_ram_wren                    ,
        SSD_PTN_WADDR_OUT                   => reg_ptn_ram_waddr                   ,
        SSD_PTN_WDATA_OUT                   => reg_ptn_ram_wdata                   ,
        SSD_MEM_RDEN_OUT                    => reg_ssd_mem_rden                    ,
        SSD_MEM_ADDR_OUT                    => reg_ssd_mem_addr                    ,
        SSD_MEM_RDATA_IN                    => reg_ssd_mem_rdata                   ,
        -- H/W alrm gathering
        SIG_SUS_DLOFF_IN                    => SIG_SUS_DLOFF_IN                    ,
        CLOCK_FAIL_FLAG_IN                  => (others => '0')                      
        );
	
    FBSW_SC_PATH_SEL_OUT <= reg_sc_path_sel;

    process(CLK_DL) begin
        if (CLK_DL'event) and (CLK_DL = '1') then
            ul_mon0_data_iq  <=  UL_I_IN(0) & UL_Q_IN(0);
            ul_mon1_data_iq  <=  DL_INTERBAND_I_IN(0) & DL_INTERBAND_Q_IN(0);
            ul_mon2_data_iq  <=  ul_output_i(0) & ul_output_q(0);	
        end if;
    end process;

    -- DACIF Phase Tester 
    G_Using_DACIF_Phase_Testor : if (DACIF_PH_TESTOR_IMPLEMENTATION = TRUE) generate begin
        U_DACIF_PHASE_TESTER : DACIF_PHASE_TESTER 
        port map(
            RST                                    => clk_unstable                        , 
            CLK                                    => CLK_DPD                             , 
        
            BFN_STRB_IN                            => dl_bfn_strb_dpdfir_dly              , 
            TDD_IN                                 => dl_tdd_strb_dpdfir_dly              , 
        
            TEST_ENB_IN                            => DACIF_PHTEST_ENB_IN                 , 
            REF_SEL_IN                             => DACIF_PHTEST_REF_SEL_IN             , 
            PATH_AB_SWAP_IN                        => DACIF_PHTEST_PATH_AB_SWAP_IN        , 
            PATH_REVERSE_IN                        => DACIF_PHTEST_PATH_REVERSE_IN        , 
            REPEAT_ENB_IN                          => DACIF_PHTEST_REPEAT_ENB_IN          , 
            DACIF_DEFAULT_IN                       => DACIF_PHTEST_DACIF_DEFAULT_IN       , 
        
            OFFSET_IN                              => dl_dacif_phtest_offset_cdc          , 
            PERIOD_IN                              => dl_dacif_phtest_period_cdc          ,
            ON_DURATION_IN                         => dl_dacif_phtest_on_duration_cdc     , 
        
            DACIF_ON_IN                            => DACIF_ON_IN                         ,
            DACIF_ON_OUT                           => dl_dacif_on_phtest                      
            );
    end generate;

    G_Unusing_DACIF_Phase_Testor : if (DACIF_PH_TESTOR_IMPLEMENTATION = FALSE) generate begin
        dl_dacif_on_phtest <= DACIF_ON_IN;
    end generate;

    DBG_SIG_OUT <= (others => (others => '0'));

    -- RX_SSD
    P_FB_VC_RX_SSD : process(CLK_DL) begin
        if (CLK_DL'event) and (CLK_DL = '1') then
            fb_vc_rxssd <= (not fb_vc(4)) & (fb_vc(3 downto 0));
        end if;
    end process;

    U_RX_SSD : RX_SSD 
    generic map(        
        DEVICE                 => DEVICE                                 ,
        RX_SSD_IMPLEMENTATION  => RX_SSD_IMPLEMENTATION                  ,
        TX_ANT_NUM             => TX_ANT_NUM                             ,
        FB_PATH_NUM            => FB_PATH_NUM                            ,
        HOVS                   => DL_HOVS                                 
        )
    port map(
        RST_DSP                => clk_unstable                           ,
        CLK_DSP                => CLK_DL                                 ,
    
        -- Control
        PATH_SEL_IN            => reg_ssd_path_sel                       ,
        CTRL_EN_IN             => reg_ssd_ctrl                           ,
        REPEAT_PER_SW_IN       => reg_ssd_length_per_switch              ,
        ACCU_LENGTH_IN         => reg_ssd_accu_length                    ,
        PATTERN_GAIN_IN        => reg_ssd_gain                           ,
    
        ACCU_DONE_OUT          => reg_ssd_accu_done                      ,
    
        -- FB SW Info
        FBSW_START_TRIG_IN     => fbsw_round_start_pls                   ,
        FB_VC_IN               => fb_vc_rxssd                            ,
    
        -- Traffic
        REF_FS_10ms_IN         => dl_bfn_strb_mixer_dly                  ,
    
        DL_VLD_IN              => dl_mixer_out_vld                       ,
        DL_I_IN                => dl_mixer_out_i                         ,
        DL_Q_IN                => dl_mixer_out_q                         ,
    
        REF_FS_10ms_OUT        => open                                   ,
    
        DL_VLD_OUT             => dl_dpdblk_in_vld                       ,
        DL_I_OUT               => dl_dpdblk_in_i                         ,
        DL_Q_OUT               => dl_dpdblk_in_q                         ,
    
        FB_FS_10ms_IN          => fb_bfn_strb_fir_dly                    ,
    
        FB_VLD_IN              => fb_filter_out_vld                      ,
        FB_I_IN                => fb_filter_out_i                        ,
        FB_Q_IN                => fb_filter_out_q                        ,
    
        -- CPU Domain
        RST_CPU                => RST_CPUIF                              ,
        CLK_CPU                => CLK_CPUIF                              ,
    
        PTN_WREN_IN            => reg_ptn_ram_wren                       , 
        PTN_WADDR_IN           => reg_ptn_ram_waddr                      ,
        PTN_WDATA_IN           => reg_ptn_ram_wdata                      ,

        MEM_RDEN_IN            => reg_ssd_mem_rden                       ,
        MEM_ADDR_IN            => reg_ssd_mem_addr                       ,
        MEM_DATA_OUT           => reg_ssd_mem_rdata                           
        );

    -- For DUMP

    dl_cfrout_dump_bfnstrb <= dl_bfn_strb_align_dly;
    dl_dpdout_dump_bfnstrb <= dl_bfn_strb_dpdfir_dly;
    fb_att_in_dump_bfnstrb <= fb_bfn_strb_sw_dly;

    G_DL_Path_DUMP : for I in 0 to (TX_ANT_NUM-1) generate begin
        dl_cfrout_dump_vld(I)  <= dl_input_vld(I);              
        dl_cfrout_dump_iq(I)   <= dl_input_i(I) & dl_input_q(I);

        dl_dpdout_dump_vld(I)  <= dl_dpdblk_out_vld(I);
        dl_dpdout_dump_iq(I)   <= dl_dpdblk_out_i(I)& dl_dpdblk_out_q(I);

    end generate;

    G_FB_Path_DUMP : for I in 0 to (FB_PATH_NUM-1) generate begin
        fb_att_in_dump_vld(I)  <= fb_sw_ctrl_vld(I);                     
        fb_att_in_dump_iq(I)   <= fb_sw_ctrl_i(I) & fb_sw_ctrl_q(I);
    end generate;
	

    U_DPD_DUMP_MUX : DPD_DUMP_MUX 
    generic map(
        DPD_PATH_PHASE                            => DPD_PATH_PHASE                            ,
        DPD_CLK_SEL                               => DL_CLK_SEL                                ,
        TX_ANT_NUM                                => TX_ANT_NUM                          ,
        FB_PATH_NUM                               => FB_PATH_NUM                                
        )
    port map(
        RST                                       => clk_unstable                              , 
        CLK_SYS                                   => CLK_SYS                                   , 
        CLK_SYSX2                                 => CLK_SYSX2                                 , 
        CLK_SYSX3                                 => CLK_SYSX3                                 , 
        CLK_SYSX4                                 => CLK_SYSX4                                 , 
        CLK_SYSX5                                 => CLK_SYSX5                                 , 
        CLK_SYSX6                                 => CLK_SYSX6                                 , 
        CLK_SYSX8                                 => CLK_SYSX8                                 , 
        CLK_SYSX10                                => CLK_SYSX10                                , 
        CLK_SYSX12                                => CLK_SYSX12                                , 
        CLK_SYSX16                                => CLK_SYSX16                                , 
        CLK_SYSX20                                => CLK_SYSX20                                , 
    
        DUMP_POINT_SEL_STRB_IN                    => DUMP_POINT_SEL_STRB_IN                    , 
        DUMP_POINT_SEL_IN                         => DUMP_POINT_SEL_IN                         , 
    
        CFR_OUTPUT_BFN_STRB_IN                    => dl_cfrout_dump_bfnstrb                    , 
        CFR_OUTPUT_VLD_IN                         => dl_cfrout_dump_vld                        , 
        CFR_OUTPUT_IQ_IN                          => dl_cfrout_dump_iq                         , 
                                                                                               
        DPD_OUTPUT_BFN_STRB_IN                    => dl_dpdout_dump_bfnstrb                    , 
        DPD_OUTPUT_VLD_IN                         => dl_dpdout_dump_vld                        , 
        DPD_OUTPUT_MONO_IQ_IN                     => dl_dpdout_dump_iq                         , 
        DPD_OUTPUT_POLY_IQ_EVEN_IN                => (others => (others => '0'))               , 
        DPD_OUTPUT_POLY_IQ_ODD_IN                 => (others => (others => '0'))               , 
                                                                                               
        FBATT_INPUT_BFN_STRB_IN                   => fb_att_in_dump_bfnstrb                    , 
        FBATT_INPUT_VLD_IN                        => fb_att_in_dump_vld                        , 
        FBATT_INPUT_MONO_IQ_IN                    => fb_att_in_dump_iq                         , 
        FBATT_INPUT_POLY_IQ_EVEN_IN               => (others => (others => '0'))               , 
        FBATT_INPUT_POLY_IQ_ODD_IN                => (others => (others => '0'))               , 
    
        DUMP_BFN_STRB_OUT                         => DUMP_BFN_STRB_OUT                         ,         
        DUMP_DVLD_OUT                             => DUMP_DVLD_OUT                             ,
        DUMP_DATA_OUT                             => DUMP_DATA_OUT                              
        );

end arc_DPD_TOP;
