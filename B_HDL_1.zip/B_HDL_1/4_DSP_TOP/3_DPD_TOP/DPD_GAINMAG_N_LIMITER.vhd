library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity DPD_GAINMAG_N_LIMITER is
generic(
    DEVICE                     : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HOVS                       : natural :=           1 ; 
    LUT_DIMENSION              : string  :=         "2D"; -- "2D" or "3D"
    LUT_MEM_DEPTH              : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    LUT_RAM_NUM                : natural :=          32
    );
port(
    RST                        : in  std_logic;
    CLK                        : in  std_logic;

    GAIN_INDEX_IN              : in  std_logic_vector( 1 downto 0);

    DATA_I_IN                  : in  std_logic_vector(15 downto 0);
    DATA_Q_IN                  : in  std_logic_vector(15 downto 0);

    DATA_MAG09_OUT             : out std_logic_vector( 8 downto 0);
    DATA_MAG15_OUT             : out std_logic_vector(14 downto 0);

    DATA_I_DDR_OUT             : out std_logic_vector(15 downto 0);
    DATA_Q_DDR_OUT             : out std_logic_vector(15 downto 0);
    
    DATA_I_LMT_DLY_OUT         : out std_logic_vector(15 downto 0);
    DATA_Q_LMT_DLY_OUT         : out std_logic_vector(15 downto 0)
    );
end DPD_GAINMAG_N_LIMITER;

architecture arc_DPD_GAINMAG_N_LIMITER of DPD_GAINMAG_N_LIMITER is

component SAT_SIGN is
generic(
    HS_MODE                    : boolean := FALSE;
    INPUT_BIT                  : natural ;
    OUTPUT_BIT                 : natural 
    );
port( 
    RST                        : in  std_logic;
    CLK                        : in  std_logic;
    DATA_IN                    : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT                   : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

component SRLC32E_DLY is       
generic(
    DEVICE                     : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HS_MODE                    : boolean :=        TRUE ;

    BIT_WIDTH                  : natural;
    DELAY_NUM                  : natural
    );
port(
    CLK                        : in  std_logic;
    DATA_IN                    : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_COUT                  : out std_logic_vector(BIT_WIDTH-1 downto 0); 
    DATA_OUT                   : out std_logic_vector(BIT_WIDTH-1 downto 0)  
    );
end component;

component CORDIC is
generic(
    HS_MODE            : boolean :=  TRUE ; -- High Speed Mode (Operating Clock > 307.2MHz)

    STAGE_NUM          : natural :=     6 ;
    MAGN               : boolean :=  TRUE ;
    ANGLE              : boolean := FALSE
    );
port(
    CLK                : in  std_logic;

    DATA_I             : in  std_logic_vector(15 downto 0);
    DATA_Q             : in  std_logic_vector(15 downto 0);

    MAGNITUDE_OUT      : out std_logic_vector(15 downto 0);
    SIN_OUT            : out std_logic_vector(13 downto 0);
    COS_OUT            : out std_logic_vector(13 downto 0)
    );
end component;

component SAT_UNSIGN is
generic(
    HS_MODE                    : boolean :=  TRUE;  -- High Speed Mode (Operating Clock > 307.2MHz)

    INPUT_BIT                  : natural;
    OUTPUT_BIT                 : natural
    );
port( 
    RST                        : in  std_logic;
    CLK                        : in  std_logic;
    DATA_IN                    : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT                   : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

signal data_i_gain             : std_logic_vector(17 downto 0);
signal data_q_gain             : std_logic_vector(17 downto 0);

signal data_i_gain_sat         : std_logic_vector(15 downto 0);
signal data_q_gain_sat         : std_logic_vector(15 downto 0);

signal sqrt                    : std_logic_vector(15 downto 0);

signal sqrt_sat14              : std_logic_vector(13 downto 0);
signal sqrt_sat15              : std_logic_vector(14 downto 0);

signal data_i_lmt              : std_logic_vector(15 downto 0);
signal data_q_lmt              : std_logic_vector(15 downto 0);

signal data_i_lmt_d1           : std_logic_vector(15 downto 0);
signal data_q_lmt_d1           : std_logic_vector(15 downto 0);

signal data_i_lmt_sh_c         : std_logic_vector(15 downto 0);
signal data_q_lmt_sh_c         : std_logic_vector(15 downto 0);

signal data_i_lmt_sh           : std_logic_vector(15 downto 0);
signal data_q_lmt_sh           : std_logic_vector(15 downto 0);

signal data_i_lmt_ddr_sh       : std_logic_vector(15 downto 0);
signal data_q_lmt_ddr_sh       : std_logic_vector(15 downto 0);

attribute KEEP : string;
attribute KEEP of data_i_lmt_d1 : signal is "TRUE";
attribute KEEP of data_q_lmt_d1 : signal is "TRUE";

begin

    -- Gain
    P_Input_Data_Gain_HS : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            case (GAIN_INDEX_IN) is
                when "00"   => -- x1, Gain = 1  
                    data_i_gain <= DATA_I_IN(15) & DATA_I_IN(15) & DATA_I_IN;      
                    data_q_gain <= DATA_Q_IN(15) & DATA_Q_IN(15) & DATA_Q_IN;      
                when "01"   => -- x2, Gain = 2  
                    data_i_gain <= DATA_I_IN(15) & DATA_I_IN     & '0';       
                    data_q_gain <= DATA_Q_IN(15) & DATA_Q_IN     & '0';       
                when "10"   => -- x4, Gain = 4  
                    data_i_gain <= DATA_I_IN     & "00";       
                    data_q_gain <= DATA_Q_IN     & "00";       
                when others => -- x1, Gain = 1  
                    data_i_gain <= DATA_I_IN(15) & DATA_I_IN(15) & DATA_I_IN;       
                    data_q_gain <= DATA_Q_IN(15) & DATA_Q_IN(15) & DATA_Q_IN;       
            end case;
        end if;
    end process;

    -- Signed Saturation : 4 Clocks 
    U_Input_Data_I_SAT : SAT_SIGN generic map (TRUE, 18, 16) port map (RST, CLK, data_i_gain, data_i_gain_sat);
    U_Input_Data_Q_SAT : SAT_SIGN generic map (TRUE, 18, 16) port map (RST, CLK, data_q_gain, data_q_gain_sat);

    -- Limitation
    P_Limitor_HS : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            case (GAIN_INDEX_IN) is          
                when "00"   => -- x1/1, Gain = 1
                    data_i_lmt <= data_i_gain_sat;       
                    data_q_lmt <= data_q_gain_sat;       
                when "01"   => -- x1/2, Gain = 0.5
                    data_i_lmt <= data_i_gain_sat(15) & data_i_gain_sat(15 downto 1);       
                    data_q_lmt <= data_q_gain_sat(15) & data_q_gain_sat(15 downto 1);       
                when "10"   => -- x1/4, Gain = 0.25
                    data_i_lmt <= data_i_gain_sat(15) & data_i_gain_sat(15) & data_i_gain_sat(15 downto 2);       
                    data_q_lmt <= data_q_gain_sat(15) & data_q_gain_sat(15) & data_q_gain_sat(15 downto 2);       
                when others => -- x1/1, Gain = 1
                    data_i_lmt <= data_i_gain_sat;       
                    data_q_lmt <= data_q_gain_sat;       
            end case;
        end if;
    end process;

    P_1Clocking_HS : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            data_i_lmt_d1 <= data_i_lmt;
            data_q_lmt_d1 <= data_q_lmt;
        end if;
    end process;

    -- Magnitude : Cordic
    U_Cordic  : CORDIC     generic map(TRUE, 7, TRUE, FALSE) port map(CLK, data_i_gain_sat, data_q_gain_sat, sqrt, open, open); -- SQRT(I^2 + Q^2)
    U_USAT_15 : SAT_UNSIGN generic map(TRUE, 16, 15)         port map(RST, CLK, sqrt, sqrt_sat15);
    DATA_MAG15_OUT <= sqrt_sat15; 

    G_LUT_512_Depth : if (LUT_MEM_DEPTH = "FULL") generate begin   
        sqrt_sat14     <= (others => '0');

        DATA_MAG09_OUT <= sqrt_sat15(14 downto 6); 
    end generate;

    G_LUT_256_Depth : if (LUT_MEM_DEPTH = "HALF") generate begin   
        U_USAT_15 : SAT_UNSIGN generic map(TRUE, 16, 14) port map(RST, CLK, sqrt, sqrt_sat14);

        DATA_MAG09_OUT <= '0'&sqrt_sat14(13 downto 6); 
    end generate;

    -- LUT_WRAPPER latency compensation
    G_DPD_LUT_2D : if (LUT_DIMENSION = "2D") generate begin
        G_HOVS1 : if (HOVS = 1) generate begin
            U_LUT_WRAP_PROC_DLY_I : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 31) port map(CLK, data_i_lmt_d1, open, data_i_lmt_sh);
            U_LUT_WRAP_PROC_DLY_Q : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 31) port map(CLK, data_q_lmt_d1, open, data_q_lmt_sh);

            data_i_lmt_sh_c <= (others => '0');        
            data_q_lmt_sh_c <= (others => '0');        

        end generate;

        G_HOVS2 : if (HOVS = 2) generate begin
            U_LUT_WRAP_PROC_DLY_1st_I : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 32) port map(CLK, data_i_lmt_d1, data_i_lmt_sh_c, open);
            U_LUT_WRAP_PROC_DLY_1st_Q : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 32) port map(CLK, data_q_lmt_d1, data_q_lmt_sh_c, open);

            U_LUT_WRAP_PROC_DLY_2nd_I : SRLC32E_DLY generic map(DEVICE, TRUE, 16,  2) port map(CLK, data_i_lmt_sh_c, open, data_i_lmt_sh);
            U_LUT_WRAP_PROC_DLY_2nd_Q : SRLC32E_DLY generic map(DEVICE, TRUE, 16,  2) port map(CLK, data_q_lmt_sh_c, open, data_q_lmt_sh);
        end generate;
    end generate;

    G_DPD_LUT_3D : if (LUT_DIMENSION = "3D") generate begin
        U_LUT_WRAP_PROC_DLY_1st_I : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 32) port map(CLK, data_i_lmt_d1, data_i_lmt_sh_c, open);
        U_LUT_WRAP_PROC_DLY_1st_Q : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 32) port map(CLK, data_q_lmt_d1, data_q_lmt_sh_c, open);

        G_NON_DDR_DPD : if (LUT_RAM_NUM /= 41 and LUT_RAM_NUM /= 44) generate begin
            U_LUT_WRAP_PROC_DLY_2nd_I : SRLC32E_DLY generic map(DEVICE, TRUE, 16,  4) port map(CLK, data_i_lmt_sh_c, open, data_i_lmt_sh);
            U_LUT_WRAP_PROC_DLY_2nd_Q : SRLC32E_DLY generic map(DEVICE, TRUE, 16,  4) port map(CLK, data_q_lmt_sh_c, open, data_q_lmt_sh);
        end generate;

        G_DDR_DPD : if (LUT_RAM_NUM = 41) generate begin
            U_LUT_WRAP_PROC_DLY_2nd_I : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 4+1) port map(CLK, data_i_lmt_sh_c, open, data_i_lmt_sh);
            U_LUT_WRAP_PROC_DLY_2nd_Q : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 4+1) port map(CLK, data_q_lmt_sh_c, open, data_q_lmt_sh);
        end generate;
        G_LUT44_DPD : if (LUT_RAM_NUM = 44) generate begin
            U_LUT_WRAP_PROC_DLY_2nd_I : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 4+1+6) port map(CLK, data_i_lmt_sh_c, open, data_i_lmt_sh);  -- +1+16
            U_LUT_WRAP_PROC_DLY_2nd_Q : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 4+1+6) port map(CLK, data_q_lmt_sh_c, open, data_q_lmt_sh);  -- +1+16
        end generate;
	
        G_DDR_DLY_no44 : if (LUT_RAM_NUM /= 44) generate begin
            U_LUT_DDR_TERM_PROC_DLY_I : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 21) port map(CLK, data_i_lmt_d1, open, data_i_lmt_ddr_sh);
            U_LUT_DDR_TERM_PROC_DLY_Q : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 21) port map(CLK, data_q_lmt_d1, open, data_q_lmt_ddr_sh);
	end generate;
        G_DDR_DLY_44 : if (LUT_RAM_NUM = 44) generate begin
            U_LUT_DDR_TERM_PROC_DLY_I : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 21-1) port map(CLK, data_i_lmt_d1, open, data_i_lmt_ddr_sh);
            U_LUT_DDR_TERM_PROC_DLY_Q : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 21-1) port map(CLK, data_q_lmt_d1, open, data_q_lmt_ddr_sh);
	end generate;
	
        -- G_HOVS2 : if (HOVS = 2) generate begin
        --     U_LUT_WRAP_PROC_DLY_1st_I : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 32) port map(CLK, data_i_lmt_d1, data_i_lmt_sh_c, open);
        --     U_LUT_WRAP_PROC_DLY_1st_Q : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 32) port map(CLK, data_q_lmt_d1, data_q_lmt_sh_c, open);

        --     U_LUT_WRAP_PROC_DLY_2nd_I : SRLC32E_DLY generic map(DEVICE, TRUE, 16,  2) port map(CLK, data_i_lmt_sh_c, open, data_i_lmt_sh);
        --     U_LUT_WRAP_PROC_DLY_2nd_Q : SRLC32E_DLY generic map(DEVICE, TRUE, 16,  2) port map(CLK, data_q_lmt_sh_c, open, data_q_lmt_sh);
        -- end generate;
    end generate;

    -- SRLC Output Clocking
    P_SLRC_1_Clocking_HS : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            DATA_I_DDR_OUT <= data_i_lmt_ddr_sh; 
            DATA_Q_DDR_OUT <= data_q_lmt_ddr_sh; 

            DATA_I_LMT_DLY_OUT  <= data_i_lmt_sh;  
            DATA_Q_LMT_DLY_OUT  <= data_q_lmt_sh;  
        end if;
    end process;

end arc_DPD_GAINMAG_N_LIMITER;
