----------------------------------------------------------------------------
-- Designer   : Kyoung Heo, (k1340.heo@samsung.com)
-- Block Name : PWR_N_MAG_MEASURE
-- Function   : Power and Magnitude Measuring of CFR output IQ sample 
--              for SMART_CAPTURE
-- Revision   : - ver 1.0, First Relase, 16.04.18
----------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity PWR_N_MAG_MEASURE is
generic(
    DEVICE                      : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HOVS                        : natural := 1  -- (Clock Frequency)/(Sampling Rate)
    );
port(
    CLK                         : in  std_logic;

    SAMPLE_VLD_IN               : in  std_logic;
    SAMPLE_I_IN                 : in  std_logic_vector(15 downto 0);
    SAMPLE_Q_IN                 : in  std_logic_vector(15 downto 0);

    MEASURE_SYNC_IN             : in  std_logic;
    MEASURE_EN_IN               : in  std_logic; -- Active High
    MEASURE_LENGTH_IN           : in  std_logic; -- '1' : 4k, '0' : 8k

    MEASURED_PWR_OUT            : out std_logic_vector(31 downto 0);
    MEASURED_MAG_OUT            : out std_logic_vector(31 downto 0)
    );
end PWR_N_MAG_MEASURE;

architecture arc_PWR_N_MAG_MEASURE of PWR_N_MAG_MEASURE is

component DSP48E_MULT is
generic(
    DEVICE                      : string  := "ULTRASCALE";
    DSP48_MODECTRL              : boolean :=       FALSE ;
    DSP48_PREADDER_USE          : boolean :=        TRUE ;
    DSP48_PREADDER_MODE         : string  :=        "ADD";  -- "ADD" or "SUB" 
    DSP48_PCIN_USE              : boolean :=       FALSE ;
    DSP48_PCOUT_USE             : boolean :=       FALSE ;

    A_nREG                      : integer :=           2 ;  -- 0, 1, 2
    B_nREG                      : integer :=           2 ;  -- 0, 1, 2

    C_EN                        : boolean :=        TRUE ;
    RND_SYMMETRY                : boolean :=       FALSE 
    );
port(
    CLK                         : in  std_logic;

    ALUMODE_IN                  : in  std_logic_vector( 3 downto 0);
    OPMODE_IN                   : in  std_logic_vector( 8 downto 0);

    C_IN                        : in  std_logic_vector(47 downto 0);
    A_IN                        : in  std_logic_vector(29 downto 0);
    D_IN                        : in  std_logic_vector(26 downto 0);
    B_IN                        : in  std_logic_vector(17 downto 0);

    P_CIN                       : in  std_logic_vector(47 downto 0);
    P_COUT                      : out std_logic_vector(47 downto 0);

    P_OUT                       : out std_logic_vector(47 downto 0);
    CRRY_OUT                    : out std_logic
    );
end component;

constant zeros                  : std_logic_vector(15 downto 0) := (others => '0');

signal sample_i_align           : std_logic_vector(15 downto 0);
signal sample_q_align           : std_logic_vector(15 downto 0);
signal sample_iq                : std_logic_vector(15 downto 0) := (others => '0');

signal se_i_a                   : std_logic_vector(29 downto 0) := (others => '0');
signal se_i_b                   : std_logic_vector(17 downto 0) := (others => '0');
signal se_q_a                   : std_logic_vector(29 downto 0) := (others => '0');
signal se_q_b                   : std_logic_vector(17 downto 0) := (others => '0');

signal se_iq_a                  : std_logic_vector(29 downto 0) := (others => '0');
signal se_iq_b                  : std_logic_vector(17 downto 0) := (others => '0');

signal opmode                   : std_logic_vector( 8 downto 0) := "000000101";

signal square_i                 : std_logic_vector(47 downto 0) := (others => '0'); -- Unsigned
signal square_q                 : std_logic_vector(47 downto 0) := (others => '0'); -- Unsigned
signal square_pwr               : std_logic_vector(47 downto 0) := (others => '0'); -- Unsigned

signal square_iq                : std_logic_vector(47 downto 0) := (others => '0'); -- Unsigned

signal sample_vld_d1            : std_logic;

signal square_iq_sum            : std_logic_vector(31 downto 0); -- Unsigned
signal square_iq_sum_sat        : std_logic_vector(30 downto 0); -- Unsigned

signal measure_sync_d1          : std_logic;

signal measure_en_sh            : std_logic_vector( 4 downto 0);
signal square_iq_sum_sat_sh     : std_logic_array31(5 downto 0);

signal accum_input              : std_logic_vector(30 downto 0);
signal se_accum_input           : std_logic_vector(43 downto 0);
signal accum_result             : std_logic_vector(43 downto 0);

signal pwr_result               : std_logic_vector(30 downto 0);
signal measure_pwr              : std_logic_vector(31 downto 0);
signal measure_mag              : std_logic_vector(31 downto 0);

begin

    P_Sample_Align : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (SAMPLE_VLD_IN = '1') then
                sample_i_align <= SAMPLE_I_IN; 
                sample_q_align <= SAMPLE_Q_IN; 
            end if;
        end if;
    end process;

    -- I^2+Q^2
    G_HOVS1 : if (HOVS = 1) generate begin

        se_i_a <= sign_extension(sample_i_align, 30);
        se_q_a <= sign_extension(sample_q_align, 30);
              
        se_i_b <= sign_extension(sample_i_align, 18);
        se_q_b <= sign_extension(sample_q_align, 18);

        U_Square_I : DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",FALSE,TRUE,1,1,FALSE,FALSE) port map(CLK,x"0",opmode,(others=>'0'),se_i_a,(others=>'0'),se_i_b,(others=>'0'),square_i,open      ,open); 
        U_Square_Q : DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",TRUE,FALSE,2,2,FALSE,FALSE) port map(CLK,x"0",opmode,(others=>'0'),se_q_a,(others=>'0'),se_q_b,square_i     ,open    ,square_pwr,open); 

        P_IQ_SUM : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                square_iq_sum <= square_pwr(31 downto 0);
            end if;
        end process;
    end generate;
    
    G_HOVS2 : if (HOVS = 2) generate begin

        P_IQ_MUX : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (SAMPLE_VLD_IN = '0') then
                    sample_iq <= sample_i_align;
                else
                    sample_iq <= sample_q_align;
                end if;
            end if;
        end process;

        -- Sign Extension
        se_iq_a <= sign_extension(sample_iq, 30);
        se_iq_b <= sign_extension(sample_iq, 18);

        P_OPMODE_CTRL : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (SAMPLE_VLD_IN = '0') then
                    opmode <= "000000101";
                else
                    opmode <= "000100101"; -- Internal P Calculation
                end if;
            end if;
        end process;

        U_Square_IQ : DSP48E_MULT generic map(DEVICE,TRUE,FALSE,"ADD",FALSE,FALSE,2,2,FALSE,FALSE) port map(CLK,x"0",opmode,(others =>'0'),se_iq_a,(others=>'0'),se_iq_b,(others=>'0'),open,square_iq,open); 

        P_IQ_SUM : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (SAMPLE_VLD_IN = '0') then
                    square_iq_sum <= square_iq(31 downto 0);
                end if;
            end if;
        end process;

    end generate;

    P_Sample_Valid_Clocking : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            sample_vld_d1 <= SAMPLE_VLD_IN;
        end if;
    end process;

    P_Summation_Value_Saturation : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (sample_vld_d1 = '1') then 
                if (square_iq_sum(31) = '1') then
                    square_iq_sum_sat <= (others => '1');
                else    
                    square_iq_sum_sat <= square_iq_sum(30 downto 0);
                end if;
            end if;
        end if;
    end process;

    P_Enable_Signal : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (MEASURE_EN_IN = '0') then
                measure_sync_d1 <= '1';
            else
                if (SAMPLE_VLD_IN = '1') then
                    measure_sync_d1 <= MEASURE_SYNC_IN;
                end if;
            end if;
        end if;
    end process;
		
    P_Accumulator_Input : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (SAMPLE_VLD_IN = '1') then
                if (MEASURE_SYNC_IN = '1') then
                    accum_input <= (others => '0');   
                else
                    accum_input <= square_iq_sum_sat;   
                end if;
            end if;
        end if;
    end process;

    -- Sign Extention (bitwidth : 31 to 44)
    se_accum_input <= sign_extension(accum_input, 44);

    P_Accumulator : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (SAMPLE_VLD_IN = '1') then
                if (measure_sync_d1 = '1') then 
                    accum_result <= se_accum_input;
                else
                    accum_result <= accum_result + se_accum_input;
                end if;
           end if;
        end if;
    end process;

    P_Sample_Delay : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (SAMPLE_VLD_IN = '1') then
                measure_en_sh        <= measure_en_sh(3 downto 0) & MEASURE_EN_IN;   
                square_iq_sum_sat_sh <= square_iq_sum_sat_sh(4 downto 0) & square_iq_sum_sat;   
            end if;
        end if;
    end process;

    P_Measure_Length_Selection : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (SAMPLE_VLD_IN = '1') then
                -- Length : 4k
                if (MEASURE_LENGTH_IN = '1') then 
                    pwr_result  <= accum_result(42 downto 12); -- Power Average = (accum_result)/4096
                -- Length : 8k
                else
                    pwr_result  <= accum_result(43 downto 13); -- Power Average = (accum_result)/8192
                end if;
            end if;
        end if;
    end process;

    P_Measure_Power_N_Magnitude : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (SAMPLE_VLD_IN = '1') then
                if (measure_en_sh(4) = '0') then
                    measure_pwr <= (others => '0');
                    measure_mag <= (others => '0');
                else
                    measure_pwr <= '0' & pwr_result;
                    measure_mag <= '0' & square_iq_sum_sat_sh(5);
                end if;
            end if;
        end if;
    end process;
                
    MEASURED_PWR_OUT <= measure_pwr;
    MEASURED_MAG_OUT <= measure_mag;

end arc_PWR_N_MAG_MEASURE; 

