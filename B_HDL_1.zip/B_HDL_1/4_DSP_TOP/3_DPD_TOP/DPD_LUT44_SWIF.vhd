library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity DPD_LUT44_SWIF is
generic(
    TX_ANT_NUM                : natural :=     4 ;
    HS_MODE                   : boolean := FALSE ;
    LUT_OPTIMIZED             : boolean := FALSE ;
    LUT_RBTEST                : boolean := FALSE ;
    LUT_RAM_NUM               : natural :=    44 ;
    DPD_TAP_NUM               : natural :=    13 
    );
port(
    RST_CPU                   : in  std_logic;                                -- Reset, Active High, CPU Clock Domain
    CLK_CPU                   : in  std_logic;                                -- CPU Operating Clock

    DPD_LUT_RB_TEST_EN_IN     : in  std_logic;                                -- LUT Read Back Test

    DPD_CDC_STRB_IN           : in  std_logic;
    DPD_LUT_INPUT_SWITCH_IN   : in  std_logic_vector(19 downto 0);            -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN  : in  std_logic_vector(19 downto 0);            -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN      : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN           : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- LUT Write Enable
    DPD_LUT_RDEN_IN           : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- LUT Write Enable
    DPD_LUT_ADDR_IN           : in  std_logic_array15(TX_ANT_NUM-1 downto 0); -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN          : in  std_logic_array32(TX_ANT_NUM-1 downto 0); -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT         : out std_logic_array32(TX_ANT_NUM-1 downto 0); -- LUT Write IQ : I[31:16]/Q[15:0]

    RST_DPD                   : in  std_logic;                                -- Reset, Active High, DPD Clock Domain
    CLK_DPD                   : in  std_logic;                                -- DPD Operating Clock

    DPD_MAG_ADDR_IN           : in  std_logic_array44_array9(TX_ANT_NUM-1 downto 0);
    
    DPD_LUT_OUTPUT_SWITCH_OUT : out std_logic_vector(19 downto 0);            -- LUT Output Switch Control

    SW_LUT_UPDATE_SWITCH_OUT  : out std_logic_vector(TX_ANT_NUM-1 downto 0);
    SW_LUT_ENA_OUT            : out std_logic_array44(TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path
    SW_LUT_WREN_OUT           : out std_logic_array44(TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path
    SW_LUT_WADDR_OUT          : out std_logic_array9( TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path
    SW_LUT_WDATA_OUT          : out std_logic_array32(TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path

    SW_LUT_RADDR_OUT          : out std_logic_array44_array9( TX_ANT_NUM downto 0);
    SW_LUT_RBDATA_IN          : in  std_logic_array44_array32(TX_ANT_NUM downto 0)
    );
end DPD_LUT44_SWIF;

architecture arc_DPD_LUT44_SWIF of DPD_LUT44_SWIF is

signal dpdsw_lut_ena_cpuclk         : std_logic_array44(TX_ANT_NUM-1 downto 0); 
signal dpdsw_lut_wren_cpuclk        : std_logic_array44(TX_ANT_NUM-1 downto 0); 
signal dpdsw_lut_addr_cpuclk        : std_logic_array9( TX_ANT_NUM-1 downto 0);
signal dpdsw_lut_wdata_cpuclk       : std_logic_array32(TX_ANT_NUM-1 downto 0);
signal dpdsw_lut_rdata_cpuclk       : std_logic_array32(TX_ANT_NUM-1 downto 0) := (others=>(others=>'0'));

signal dpd_lut_update_sw            : std_logic_vector(TX_ANT_NUM-1 downto 0);

signal dpd_lut_input_wr_switch      : std_logic_array4(TX_ANT_NUM downto 0);

signal lut_ena_cpuclk               : std_logic_vector(LUT_RAM_NUM-1 downto 0); 
signal lut_wren_cpuclk              : std_logic_vector(LUT_RAM_NUM-1 downto 0); 
signal lut_rden_sh_cpuclk           : std_logic_array6( TX_ANT_NUM-1 downto 0); 
signal lut_rden_rpls_cpuclk         : std_logic_vector( TX_ANT_NUM-1 downto 0); 
signal lut_waddr_cpuclk             : std_logic_vector( 8 downto 0); 
signal lut_raddr_cpuclk             : std_logic_array9(LUT_RAM_NUM-1 downto 0); 
signal lut_wdata_cpuclk             : std_logic_vector(31 downto 0); 

signal lut_switch_ena_cpuclk        : std_logic_array44(TX_ANT_NUM downto 0); 
signal lut_switch_wren_cpuclk       : std_logic_array44(TX_ANT_NUM downto 0); 
signal lut_switch_waddr_cpuclk      : std_logic_array9( TX_ANT_NUM downto 0); 
signal lut_switch_wdata_cpuclk      : std_logic_array32(TX_ANT_NUM downto 0); 
signal lut_switch_rdata_cpuclk      : std_logic_array32(LUT_RAM_NUM-1 downto 0); 

signal dpd_lut_rden_sh_dpdclk       : std_logic_vector( 2 downto 0);                              
signal dpd_lut_rden_rpls_dpdclk     : std_logic;                              

signal lut_rbaddr_dpdclk            : std_logic_array9( LUT_RAM_NUM-1 downto 0) := (others => (others => '0')); 
signal lut_raddr_dpdclk             : std_logic_array44_array9(TX_ANT_NUM downto 0); 

signal dpd_cdc_strb_sh_dpdclk       : std_logic_vector( 2 downto 0);
signal dpd_cdc_strb_rpls_dpdclk     : std_logic;
signal dpd_lut_raddr_switch_dpdclk  : std_logic_array4(TX_ANT_NUM downto 0);          
signal dpd_lut_output_switch_dpdclk : std_logic_vector(19 downto 0);          

attribute KEEP : string;
attribute KEEP of dpd_lut_input_wr_switch            : signal is "TRUE";

attribute KEEP of DPD_MAG_ADDR_IN                    : signal is "TRUE";

attribute KEEP of dpd_lut_raddr_switch_dpdclk        : signal is "TRUE";          
attribute KEEP of lut_raddr_dpdclk                   : signal is "TRUE"; 
attribute KEEP of lut_rbaddr_dpdclk                  : signal is "TRUE"; 
attribute KEEP of dpd_lut_rden_rpls_dpdclk           : signal is "TRUE";                              
attribute KEEP of dpd_cdc_strb_sh_dpdclk             : signal is "TRUE";
attribute KEEP of dpd_cdc_strb_rpls_dpdclk           : signal is "TRUE";
attribute KEEP of dpd_lut_output_switch_dpdclk       : signal is "TRUE";          
attribute KEEP of lut_rden_rpls_cpuclk               : signal is "TRUE"; 

attribute MAX_FANOUT : integer;
attribute MAX_FANOUT of DPD_MAG_ADDR_IN              : signal is ternary_func(HS_MODE=TRUE, 30, 2000);
attribute MAX_FANOUT of lut_raddr_dpdclk             : signal is ternary_func(HS_MODE=TRUE, 30, 2000); 
attribute MAX_FANOUT of dpd_lut_rden_rpls_dpdclk     : signal is ternary_func(HS_MODE=TRUE,  5, 2000);                              
attribute MAX_FANOUT of lut_rbaddr_dpdclk            : signal is ternary_func(HS_MODE=TRUE, 30, 2000); 
attribute MAX_FANOUT of dpd_lut_raddr_switch_dpdclk  : signal is ternary_func(HS_MODE=TRUE, 30, 2000);          
attribute MAX_FANOUT of dpd_cdc_strb_sh_dpdclk       : signal is ternary_func(HS_MODE=TRUE, 10, 2000);
attribute MAX_FANOUT of dpd_cdc_strb_rpls_dpdclk     : signal is ternary_func(HS_MODE=TRUE,  5, 2000);
attribute MAX_FANOUT of dpd_lut_output_switch_dpdclk : signal is ternary_func(HS_MODE=TRUE, 10, 2000);          
attribute MAX_FANOUT of lut_rden_rpls_cpuclk         : signal is ternary_func(HS_MODE=TRUE, 30, 2000); 

begin

    -- CPU Clock Domain
    G_LUT_Non_Optimized_Interface_CPUCLK : if (LUT_OPTIMIZED = FALSE) generate begin             

        G_TX_LUT_Non_Optimized_interface : for I in 0 to (TX_ANT_NUM-1) generate begin
            P_LUT_Write_Interface_Encoding : process(RST_CPU, CLK_CPU) begin
                if (RST_CPU = '1') then
                    dpd_lut_update_sw(I)      <= '0';
                    dpdsw_lut_wren_cpuclk(I)  <= (others => '0'); 
                    dpdsw_lut_addr_cpuclk(I)  <= (others => '0'); 
                    dpdsw_lut_wdata_cpuclk(I) <= (others => '0'); 
                elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                    dpd_lut_update_sw(I)      <= DPD_LUT_UPDATE_SW_IN(I);
                    dpdsw_lut_addr_cpuclk(I)  <= DPD_LUT_ADDR_IN(I)(8 downto 0); 
                    dpdsw_lut_wdata_cpuclk(I) <= DPD_LUT_WDATA_IN(I); 

                    case (DPD_LUT_ADDR_IN(I)(14 downto 9)) is	    
                        when "000000" => dpdsw_lut_wren_cpuclk(I)( 0) <= DPD_LUT_WREN_IN(I); 
                        when "000001" => dpdsw_lut_wren_cpuclk(I)( 1) <= DPD_LUT_WREN_IN(I); 
                        when "000010" => dpdsw_lut_wren_cpuclk(I)( 2) <= DPD_LUT_WREN_IN(I); 
                        when "000011" => dpdsw_lut_wren_cpuclk(I)( 3) <= DPD_LUT_WREN_IN(I); 
                        when "000100" => dpdsw_lut_wren_cpuclk(I)( 4) <= DPD_LUT_WREN_IN(I); 
                        when "000101" => dpdsw_lut_wren_cpuclk(I)( 5) <= DPD_LUT_WREN_IN(I); 
                        when "000110" => dpdsw_lut_wren_cpuclk(I)( 6) <= DPD_LUT_WREN_IN(I); 
                        when "000111" => dpdsw_lut_wren_cpuclk(I)( 7) <= DPD_LUT_WREN_IN(I); 
                        when "001000" => dpdsw_lut_wren_cpuclk(I)( 8) <= DPD_LUT_WREN_IN(I); 
                        when "001001" => dpdsw_lut_wren_cpuclk(I)( 9) <= DPD_LUT_WREN_IN(I); 
                        when "001010" => dpdsw_lut_wren_cpuclk(I)(10) <= DPD_LUT_WREN_IN(I); 
                        when "001011" => dpdsw_lut_wren_cpuclk(I)(11) <= DPD_LUT_WREN_IN(I); 
                        when "001100" => dpdsw_lut_wren_cpuclk(I)(12) <= DPD_LUT_WREN_IN(I); 
                        when "001101" => dpdsw_lut_wren_cpuclk(I)(13) <= DPD_LUT_WREN_IN(I); 
                        when "001110" => dpdsw_lut_wren_cpuclk(I)(14) <= DPD_LUT_WREN_IN(I); 
                        when "001111" => dpdsw_lut_wren_cpuclk(I)(15) <= DPD_LUT_WREN_IN(I); 
                        when "010000" => dpdsw_lut_wren_cpuclk(I)(16) <= DPD_LUT_WREN_IN(I); 
                        when "010001" => dpdsw_lut_wren_cpuclk(I)(17) <= DPD_LUT_WREN_IN(I); 
                        when "010010" => dpdsw_lut_wren_cpuclk(I)(18) <= DPD_LUT_WREN_IN(I); 
                        when "010011" => dpdsw_lut_wren_cpuclk(I)(19) <= DPD_LUT_WREN_IN(I); 
                        when "010100" => dpdsw_lut_wren_cpuclk(I)(20) <= DPD_LUT_WREN_IN(I); 
                        when "010101" => dpdsw_lut_wren_cpuclk(I)(21) <= DPD_LUT_WREN_IN(I); 
                        when "010110" => dpdsw_lut_wren_cpuclk(I)(22) <= DPD_LUT_WREN_IN(I); 
                        when "010111" => dpdsw_lut_wren_cpuclk(I)(23) <= DPD_LUT_WREN_IN(I); 
                        when "011000" => dpdsw_lut_wren_cpuclk(I)(24) <= DPD_LUT_WREN_IN(I); 
                        when "011001" => dpdsw_lut_wren_cpuclk(I)(25) <= DPD_LUT_WREN_IN(I); 
                        when "011010" => dpdsw_lut_wren_cpuclk(I)(26) <= DPD_LUT_WREN_IN(I); 
                        when "011011" => dpdsw_lut_wren_cpuclk(I)(27) <= DPD_LUT_WREN_IN(I); 
                        when "011100" => dpdsw_lut_wren_cpuclk(I)(28) <= DPD_LUT_WREN_IN(I); 
                        when "011101" => dpdsw_lut_wren_cpuclk(I)(29) <= DPD_LUT_WREN_IN(I); 
                        when "011110" => dpdsw_lut_wren_cpuclk(I)(30) <= DPD_LUT_WREN_IN(I); 
                        when "011111" => dpdsw_lut_wren_cpuclk(I)(31) <= DPD_LUT_WREN_IN(I); 
                        when "100000" => dpdsw_lut_wren_cpuclk(I)(32) <= DPD_LUT_WREN_IN(I); 
                        when "100001" => dpdsw_lut_wren_cpuclk(I)(33) <= DPD_LUT_WREN_IN(I); 
                        when "100010" => dpdsw_lut_wren_cpuclk(I)(34) <= DPD_LUT_WREN_IN(I); 			
                        when "100011" => dpdsw_lut_wren_cpuclk(I)(35) <= DPD_LUT_WREN_IN(I); 
                        when "100100" => dpdsw_lut_wren_cpuclk(I)(36) <= DPD_LUT_WREN_IN(I); 
                        when "100101" => dpdsw_lut_wren_cpuclk(I)(37) <= DPD_LUT_WREN_IN(I); 	
                        when "100110" => dpdsw_lut_wren_cpuclk(I)(38) <= DPD_LUT_WREN_IN(I); 
                        when "100111" => dpdsw_lut_wren_cpuclk(I)(39) <= DPD_LUT_WREN_IN(I); 
                        when "101000" => dpdsw_lut_wren_cpuclk(I)(40) <= DPD_LUT_WREN_IN(I); 					
                        when "101001" => dpdsw_lut_wren_cpuclk(I)(41) <= DPD_LUT_WREN_IN(I); 					
                        when "101010" => dpdsw_lut_wren_cpuclk(I)(42) <= DPD_LUT_WREN_IN(I); 					
                        when "101011" => dpdsw_lut_wren_cpuclk(I)(43) <= DPD_LUT_WREN_IN(I); 					
                        when others   => dpdsw_lut_wren_cpuclk(I)     <= (others => '0');
                    end case;
                end if;
            end process;

            G_LUT_ReadBack_Test_Enable : if (LUT_RBTEST = TRUE) generate begin

                P_LUT_Enable_Encoding : process(RST_CPU, CLK_CPU) begin
                    if (RST_CPU = '1') then
                        dpdsw_lut_ena_cpuclk(I)   <= (others => '0'); 
                    elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                        case (DPD_LUT_ADDR_IN(I)(14 downto 9)) is	    
                            when "000000" => dpdsw_lut_ena_cpuclk(I)( 0) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "000001" => dpdsw_lut_ena_cpuclk(I)( 1) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "000010" => dpdsw_lut_ena_cpuclk(I)( 2) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "000011" => dpdsw_lut_ena_cpuclk(I)( 3) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "000100" => dpdsw_lut_ena_cpuclk(I)( 4) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "000101" => dpdsw_lut_ena_cpuclk(I)( 5) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "000110" => dpdsw_lut_ena_cpuclk(I)( 6) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "000111" => dpdsw_lut_ena_cpuclk(I)( 7) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "001000" => dpdsw_lut_ena_cpuclk(I)( 8) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "001001" => dpdsw_lut_ena_cpuclk(I)( 9) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "001010" => dpdsw_lut_ena_cpuclk(I)(10) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "001011" => dpdsw_lut_ena_cpuclk(I)(11) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "001100" => dpdsw_lut_ena_cpuclk(I)(12) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "001101" => dpdsw_lut_ena_cpuclk(I)(13) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "001110" => dpdsw_lut_ena_cpuclk(I)(14) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "001111" => dpdsw_lut_ena_cpuclk(I)(15) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "010000" => dpdsw_lut_ena_cpuclk(I)(16) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "010001" => dpdsw_lut_ena_cpuclk(I)(17) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "010010" => dpdsw_lut_ena_cpuclk(I)(18) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "010011" => dpdsw_lut_ena_cpuclk(I)(19) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 
                            when "010100" => dpdsw_lut_ena_cpuclk(I)(20) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "010101" => dpdsw_lut_ena_cpuclk(I)(21) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "010110" => dpdsw_lut_ena_cpuclk(I)(22) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "010111" => dpdsw_lut_ena_cpuclk(I)(23) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "011000" => dpdsw_lut_ena_cpuclk(I)(24) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "011001" => dpdsw_lut_ena_cpuclk(I)(25) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "011010" => dpdsw_lut_ena_cpuclk(I)(26) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "011011" => dpdsw_lut_ena_cpuclk(I)(27) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "011100" => dpdsw_lut_ena_cpuclk(I)(28) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "011101" => dpdsw_lut_ena_cpuclk(I)(29) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "011110" => dpdsw_lut_ena_cpuclk(I)(30) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "011111" => dpdsw_lut_ena_cpuclk(I)(31) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I);
                            when "100000" => dpdsw_lut_ena_cpuclk(I)(32) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "100001" => dpdsw_lut_ena_cpuclk(I)(33) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "100010" => dpdsw_lut_ena_cpuclk(I)(34) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I);
                            when "100011" => dpdsw_lut_ena_cpuclk(I)(35) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "100100" => dpdsw_lut_ena_cpuclk(I)(36) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "100101" => dpdsw_lut_ena_cpuclk(I)(37) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 				    
                            when "100110" => dpdsw_lut_ena_cpuclk(I)(38) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "100111" => dpdsw_lut_ena_cpuclk(I)(39) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 			    
                            when "101000" => dpdsw_lut_ena_cpuclk(I)(40) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 				     			     			        			    
                            when "101001" => dpdsw_lut_ena_cpuclk(I)(41) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 				     			     			        			    
                            when "101010" => dpdsw_lut_ena_cpuclk(I)(42) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 				     			     			        			    
                            when "101011" => dpdsw_lut_ena_cpuclk(I)(43) <= DPD_LUT_WREN_IN(I) or DPD_LUT_RDEN_IN(I); 				     			     			        			    
                            when others => dpdsw_lut_ena_cpuclk(I)     <= (others => '0');
                        end case;
                    end if;
                end process;
			    
                P_LUT_Read_Back : process(RST_CPU, CLK_CPU) begin
                    if (RST_CPU = '1') then
                        dpdsw_lut_rdata_cpuclk(I) <= (others => '0');
                    elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                        case (DPD_LUT_ADDR_IN(I)(14 downto 9)) is
                            when "000000" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)( 0);
                            when "000001" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)( 1);
                            when "000010" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)( 2);
                            when "000011" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)( 3);
                            when "000100" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)( 4);
                            when "000101" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)( 5);
                            when "000110" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)( 6);
                            when "000111" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)( 7);
                            when "001000" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)( 8);
                            when "001001" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)( 9);
                            when "001010" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(10);
                            when "001011" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(11);
                            when "001100" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(12);
                            when "001101" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(13);
                            when "001110" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(14);
                            when "001111" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(15);
                            when "010000" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(16);
                            when "010001" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(17);
                            when "010010" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(18);
                            when "010011" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(19);
                            when "010100" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(20);
                            when "010101" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(21);
                            when "010110" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(22);
                            when "010111" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(23);
                            when "011000" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(24);
                            when "011001" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(25);
                            when "011010" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(26);
                            when "011011" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(27);
                            when "011100" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(28);
                            when "011101" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(29);
                            when "011110" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(30);
                            when "011111" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(31);
                            when "100000" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(32);
                            when "100001" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(33);
                            when "100010" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(34);
                            when "100011" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(35);
                            when "100100" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(36);
                            when "100101" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(37);
                            when "100110" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(38);
                            when "100111" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(39);
                            when "101000" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(40);			    			    
                            when "101001" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(41);			    			    
                            when "101010" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(42);			    			    
                            when "101011" => dpdsw_lut_rdata_cpuclk(I) <= SW_LUT_RBDATA_IN(I)(43);			    			    
                            when others   => dpdsw_lut_rdata_cpuclk(I) <= (others => '0');
                        end case;
                    end if;
                end process;
            end generate;

            G_LUT_ReadBack_Test_Disable : if (LUT_RBTEST = FALSE) generate begin
                dpdsw_lut_ena_cpuclk(I)   <= dpdsw_lut_wren_cpuclk(I); 
                dpdsw_lut_rdata_cpuclk(I) <= (others => '0');
            end generate;

            lut_switch_ena_cpuclk(I)   <= dpdsw_lut_ena_cpuclk(I)  ;
            lut_switch_wren_cpuclk(I)  <= dpdsw_lut_wren_cpuclk(I) ; 
            lut_switch_waddr_cpuclk(I) <= dpdsw_lut_addr_cpuclk(I) ; 
            lut_switch_wdata_cpuclk(I) <= dpdsw_lut_wdata_cpuclk(I); 

            lut_rden_sh_cpuclk(I)   <= (others => '0');
            lut_rden_rpls_cpuclk(I) <= '0'; 

        end generate;

        lut_switch_ena_cpuclk(TX_ANT_NUM)   <= (others => '0'); 
        lut_switch_wren_cpuclk(TX_ANT_NUM)  <= (others => '0'); 
        lut_switch_waddr_cpuclk(TX_ANT_NUM) <= (others => '0'); 
        lut_switch_wdata_cpuclk(TX_ANT_NUM) <= (others => '0'); 

        lut_ena_cpuclk       <= (others => '0'); 
        lut_wren_cpuclk      <= (others => '0');          
        lut_waddr_cpuclk     <= (others => '0');          
        lut_raddr_cpuclk     <= (others => (others => '0'));          
        lut_wdata_cpuclk     <= (others => '0');          

    end generate;

    G_LUT_Optimized_Interface_CPUCLK : if (LUT_OPTIMIZED = TRUE) generate begin             
        dpd_lut_update_sw <= (others => '0');

        P_LUT_Write_Interface_Encoding : process(RST_CPU, CLK_CPU) begin
            if (RST_CPU = '1') then
                dpdsw_lut_wren_cpuclk(0)  <= (others => '0'); 
                dpdsw_lut_addr_cpuclk(0)  <= (others => '0'); 
                dpdsw_lut_wdata_cpuclk(0) <= (others => '0'); 
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                dpdsw_lut_addr_cpuclk(0)  <= DPD_LUT_ADDR_IN(0)(8 downto 0); 
                dpdsw_lut_wdata_cpuclk(0) <= DPD_LUT_WDATA_IN(0); 

                case (DPD_LUT_ADDR_IN(0)(14 downto 9)) is	    
                    when "000000" => dpdsw_lut_wren_cpuclk(0)( 0) <= DPD_LUT_WREN_IN(0); 
                    when "000001" => dpdsw_lut_wren_cpuclk(0)( 1) <= DPD_LUT_WREN_IN(0); 
                    when "000010" => dpdsw_lut_wren_cpuclk(0)( 2) <= DPD_LUT_WREN_IN(0); 
                    when "000011" => dpdsw_lut_wren_cpuclk(0)( 3) <= DPD_LUT_WREN_IN(0); 
                    when "000100" => dpdsw_lut_wren_cpuclk(0)( 4) <= DPD_LUT_WREN_IN(0); 
                    when "000101" => dpdsw_lut_wren_cpuclk(0)( 5) <= DPD_LUT_WREN_IN(0); 
                    when "000110" => dpdsw_lut_wren_cpuclk(0)( 6) <= DPD_LUT_WREN_IN(0); 
                    when "000111" => dpdsw_lut_wren_cpuclk(0)( 7) <= DPD_LUT_WREN_IN(0); 
                    when "001000" => dpdsw_lut_wren_cpuclk(0)( 8) <= DPD_LUT_WREN_IN(0); 
                    when "001001" => dpdsw_lut_wren_cpuclk(0)( 9) <= DPD_LUT_WREN_IN(0); 
                    when "001010" => dpdsw_lut_wren_cpuclk(0)(10) <= DPD_LUT_WREN_IN(0); 
                    when "001011" => dpdsw_lut_wren_cpuclk(0)(11) <= DPD_LUT_WREN_IN(0); 
                    when "001100" => dpdsw_lut_wren_cpuclk(0)(12) <= DPD_LUT_WREN_IN(0); 
                    when "001101" => dpdsw_lut_wren_cpuclk(0)(13) <= DPD_LUT_WREN_IN(0); 
                    when "001110" => dpdsw_lut_wren_cpuclk(0)(14) <= DPD_LUT_WREN_IN(0); 
                    when "001111" => dpdsw_lut_wren_cpuclk(0)(15) <= DPD_LUT_WREN_IN(0); 
                    when "010000" => dpdsw_lut_wren_cpuclk(0)(16) <= DPD_LUT_WREN_IN(0); 
                    when "010001" => dpdsw_lut_wren_cpuclk(0)(17) <= DPD_LUT_WREN_IN(0); 
                    when "010010" => dpdsw_lut_wren_cpuclk(0)(18) <= DPD_LUT_WREN_IN(0); 
                    when "010011" => dpdsw_lut_wren_cpuclk(0)(19) <= DPD_LUT_WREN_IN(0); 
                    when "010100" => dpdsw_lut_wren_cpuclk(0)(20) <= DPD_LUT_WREN_IN(0); 
                    when "010101" => dpdsw_lut_wren_cpuclk(0)(21) <= DPD_LUT_WREN_IN(0); 
                    when "010110" => dpdsw_lut_wren_cpuclk(0)(22) <= DPD_LUT_WREN_IN(0); 
                    when "010111" => dpdsw_lut_wren_cpuclk(0)(23) <= DPD_LUT_WREN_IN(0); 
                    when "011000" => dpdsw_lut_wren_cpuclk(0)(24) <= DPD_LUT_WREN_IN(0); 
                    when "011001" => dpdsw_lut_wren_cpuclk(0)(25) <= DPD_LUT_WREN_IN(0); 
                    when "011010" => dpdsw_lut_wren_cpuclk(0)(26) <= DPD_LUT_WREN_IN(0); 
                    when "011011" => dpdsw_lut_wren_cpuclk(0)(27) <= DPD_LUT_WREN_IN(0); 
                    when "011100" => dpdsw_lut_wren_cpuclk(0)(28) <= DPD_LUT_WREN_IN(0); 
                    when "011101" => dpdsw_lut_wren_cpuclk(0)(29) <= DPD_LUT_WREN_IN(0); 
                    when "011110" => dpdsw_lut_wren_cpuclk(0)(30) <= DPD_LUT_WREN_IN(0); 
                    when "011111" => dpdsw_lut_wren_cpuclk(0)(31) <= DPD_LUT_WREN_IN(0); 
                    when "100000" => dpdsw_lut_wren_cpuclk(0)(32) <= DPD_LUT_WREN_IN(0); 
                    when "100001" => dpdsw_lut_wren_cpuclk(0)(33) <= DPD_LUT_WREN_IN(0); 
                    when "100010" => dpdsw_lut_wren_cpuclk(0)(34) <= DPD_LUT_WREN_IN(0);    
                    when "100011" => dpdsw_lut_wren_cpuclk(0)(35) <= DPD_LUT_WREN_IN(0); 
                    when "100100" => dpdsw_lut_wren_cpuclk(0)(36) <= DPD_LUT_WREN_IN(0); 
                    when "100101" => dpdsw_lut_wren_cpuclk(0)(37) <= DPD_LUT_WREN_IN(0); 
                    when "100110" => dpdsw_lut_wren_cpuclk(0)(38) <= DPD_LUT_WREN_IN(0); 
                    when "100111" => dpdsw_lut_wren_cpuclk(0)(39) <= DPD_LUT_WREN_IN(0); 
                    when "101000" => dpdsw_lut_wren_cpuclk(0)(40) <= DPD_LUT_WREN_IN(0); 		    		     
                    when "101001" => dpdsw_lut_wren_cpuclk(0)(41) <= DPD_LUT_WREN_IN(0); 		    		     
                    when "101010" => dpdsw_lut_wren_cpuclk(0)(42) <= DPD_LUT_WREN_IN(0); 		    		     
                    when "101011" => dpdsw_lut_wren_cpuclk(0)(43) <= DPD_LUT_WREN_IN(0); 		    		     
                    when others   => dpdsw_lut_wren_cpuclk(0)     <= (others => '0');
                end case;
            end if;
        end process;

        P_LUTSW_Read_Back : process(RST_CPU, CLK_CPU) begin
            if (RST_CPU = '1') then
                lut_wren_cpuclk         <= (others => '0');          
                lut_rden_sh_cpuclk(0)   <= (others => '0');
                lut_rden_rpls_cpuclk(0) <= '0'; 
                lut_waddr_cpuclk        <= (others => '0');          
                lut_raddr_cpuclk        <= (others => (others => '0'));          
                lut_wdata_cpuclk        <= (others => '0');          
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                lut_rden_sh_cpuclk(0)   <= lut_rden_sh_cpuclk(0)(4 downto 0) & DPD_LUT_RDEN_IN(0);
                lut_rden_rpls_cpuclk(0) <= lut_rden_sh_cpuclk(0)(3) and (not lut_rden_sh_cpuclk(0)(4)); 

                if (DPD_LUT_RB_TEST_EN_IN = '1') then     
                    lut_wren_cpuclk      <= (others => '0');          
                    lut_waddr_cpuclk     <= (others => '0');          
                    lut_raddr_cpuclk( 0) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk( 1) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk( 2) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk( 3) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk( 4) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk( 5) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk( 6) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk( 7) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk( 8) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk( 9) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(10) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(11) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(12) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(13) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(14) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(15) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(16) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(17) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(18) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(19) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(20) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(21) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(22) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(23) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(24) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(25) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(26) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(27) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(28) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(29) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(30) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(31) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(32) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(33) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(34) <= dpdsw_lut_addr_cpuclk(0);
                    lut_raddr_cpuclk(35) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(36) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(37) <= dpdsw_lut_addr_cpuclk(0);         
                    lut_raddr_cpuclk(38) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(39) <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk(40) <= dpdsw_lut_addr_cpuclk(0);         		    		              
                    lut_raddr_cpuclk(41) <= dpdsw_lut_addr_cpuclk(0);         		    		              
                    lut_raddr_cpuclk(42) <= dpdsw_lut_addr_cpuclk(0);         		    		              
                    lut_raddr_cpuclk(43) <= dpdsw_lut_addr_cpuclk(0);         		    		              
                    lut_wdata_cpuclk     <= (others => '0');          
                else
                    lut_wren_cpuclk      <= dpdsw_lut_wren_cpuclk(0);          
                    lut_waddr_cpuclk     <= dpdsw_lut_addr_cpuclk(0);          
                    lut_raddr_cpuclk     <= (others => (others => '0'));          
                    lut_wdata_cpuclk     <= dpdsw_lut_wdata_cpuclk(0);          
                end if;
            end if;
        end process;

        G_LUTSW_SEL_Bit_Divide : for I in 0 to TX_ANT_NUM generate begin
            P_LUTSW_SEL_Bit_Divide : process(RST_CPU, CLK_CPU) begin
                if (RST_CPU = '1') then
                    dpd_lut_input_wr_switch(I) <= (others => '0');
                elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                    dpd_lut_input_wr_switch(I) <= DPD_LUT_INPUT_SWITCH_IN(4*(I+1)-1 downto 4*I);
                end if;
            end process;

            P_LUTSW_Write_Interface : process(RST_CPU, CLK_CPU) begin
                if (RST_CPU = '1') then
                    lut_switch_ena_cpuclk(I)   <= (others => '0');
                    lut_switch_wren_cpuclk(I)  <= (others => '0'); 
                    lut_switch_waddr_cpuclk(I) <= (others => '0'); 
                    lut_switch_wdata_cpuclk(I) <= (others => '0'); 
                elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                    if (dpd_lut_input_wr_switch(I) = x"4") then 
                        lut_switch_ena_cpuclk(I)   <= lut_ena_cpuclk;
                        lut_switch_wren_cpuclk(I)  <= lut_wren_cpuclk; 
                        lut_switch_waddr_cpuclk(I) <= lut_waddr_cpuclk; 
                        lut_switch_wdata_cpuclk(I) <= lut_wdata_cpuclk; 
                    else
                        lut_switch_ena_cpuclk(I)   <= (others => '0');
                        lut_switch_wren_cpuclk(I)  <= (others => '0'); 
                        lut_switch_waddr_cpuclk(I) <= (others => '0'); 
                        lut_switch_wdata_cpuclk(I) <= (others => '0'); 
                    end if;
                end if;
            end process;
        end generate;

        G_LUT_ReadBack_Test_Enable : if (LUT_RBTEST = TRUE) generate begin

            P_LUT_Enable_Encoding : process(RST_CPU, CLK_CPU) begin
                if (RST_CPU = '1') then
                    dpdsw_lut_ena_cpuclk(0)  <= (others => '0'); 
                elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                    case (DPD_LUT_ADDR_IN(0)(14 downto 9)) is	    
                        when "000000" => dpdsw_lut_ena_cpuclk(0)( 0) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "000001" => dpdsw_lut_ena_cpuclk(0)( 1) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "000010" => dpdsw_lut_ena_cpuclk(0)( 2) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "000011" => dpdsw_lut_ena_cpuclk(0)( 3) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "000100" => dpdsw_lut_ena_cpuclk(0)( 4) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "000101" => dpdsw_lut_ena_cpuclk(0)( 5) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "000110" => dpdsw_lut_ena_cpuclk(0)( 6) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "000111" => dpdsw_lut_ena_cpuclk(0)( 7) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "001000" => dpdsw_lut_ena_cpuclk(0)( 8) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "001001" => dpdsw_lut_ena_cpuclk(0)( 9) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "001010" => dpdsw_lut_ena_cpuclk(0)(10) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "001011" => dpdsw_lut_ena_cpuclk(0)(11) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "001100" => dpdsw_lut_ena_cpuclk(0)(12) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "001101" => dpdsw_lut_ena_cpuclk(0)(13) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "001110" => dpdsw_lut_ena_cpuclk(0)(14) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "001111" => dpdsw_lut_ena_cpuclk(0)(15) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "010000" => dpdsw_lut_ena_cpuclk(0)(16) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "010001" => dpdsw_lut_ena_cpuclk(0)(17) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0); 
                        when "010010" => dpdsw_lut_ena_cpuclk(0)(18) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "010011" => dpdsw_lut_ena_cpuclk(0)(19) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "010100" => dpdsw_lut_ena_cpuclk(0)(20) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "010101" => dpdsw_lut_ena_cpuclk(0)(21) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "010110" => dpdsw_lut_ena_cpuclk(0)(22) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "010111" => dpdsw_lut_ena_cpuclk(0)(23) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "011000" => dpdsw_lut_ena_cpuclk(0)(24) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "011001" => dpdsw_lut_ena_cpuclk(0)(25) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "011010" => dpdsw_lut_ena_cpuclk(0)(26) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "011011" => dpdsw_lut_ena_cpuclk(0)(27) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "011100" => dpdsw_lut_ena_cpuclk(0)(28) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "011101" => dpdsw_lut_ena_cpuclk(0)(29) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "011110" => dpdsw_lut_ena_cpuclk(0)(30) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "011111" => dpdsw_lut_ena_cpuclk(0)(31) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "100000" => dpdsw_lut_ena_cpuclk(0)(32) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "100001" => dpdsw_lut_ena_cpuclk(0)(33) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "100010" => dpdsw_lut_ena_cpuclk(0)(34) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);			
                        when "100011" => dpdsw_lut_ena_cpuclk(0)(35) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "100100" => dpdsw_lut_ena_cpuclk(0)(36) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "100101" => dpdsw_lut_ena_cpuclk(0)(37) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "100110" => dpdsw_lut_ena_cpuclk(0)(38) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "100111" => dpdsw_lut_ena_cpuclk(0)(39) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);
                        when "101000" => dpdsw_lut_ena_cpuclk(0)(40) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);												  			  
                        when "101001" => dpdsw_lut_ena_cpuclk(0)(41) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);												  			  
                        when "101010" => dpdsw_lut_ena_cpuclk(0)(42) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);												  			  
                        when "101011" => dpdsw_lut_ena_cpuclk(0)(43) <= DPD_LUT_WREN_IN(0) or DPD_LUT_RDEN_IN(0);												  			  
                        when others => dpdsw_lut_ena_cpuclk(0)     <= (others => '0');
                    end case;
                end if;
            end process;

            P_LUTSW_Read_Back : process(RST_CPU, CLK_CPU) begin
                if (RST_CPU = '1') then
                    lut_ena_cpuclk          <= (others => '0');          
                elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                    if (DPD_LUT_RB_TEST_EN_IN = '1') then     
                        lut_ena_cpuclk       <= dpdsw_lut_ena_cpuclk(0);          
                    else
                        lut_ena_cpuclk       <= dpdsw_lut_wren_cpuclk(0);          
                    end if;
                end if;
            end process;

            G_LUT_RB_2TX : if (TX_ANT_NUM = 2) generate begin
                P_2TX_LUT_RB_Data_2Path_Switching : process(RST_CPU, CLK_CPU) begin
                    if (RST_CPU = '1') then
                        lut_switch_rdata_cpuclk <= (others => (others => '0'));
                    elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                        if (DPD_LUT_RB_TEST_EN_IN = '0') then     
                            lut_switch_rdata_cpuclk <= (others => (others => '0'));
                        else
                            if (lut_rden_rpls_cpuclk(0) = '1') then 
                                case (DPD_LUT_OUTPUT_SWITCH_IN(19 downto 16)) is  
                                    when x"0"   => lut_switch_rdata_cpuclk <= SW_LUT_RBDATA_IN(0); 
                                    when x"1"   => lut_switch_rdata_cpuclk <= SW_LUT_RBDATA_IN(1); 
                                    when x"2"   => lut_switch_rdata_cpuclk <= SW_LUT_RBDATA_IN(2); 
                                    when others => lut_switch_rdata_cpuclk <= (others => (others => '0')); 
                                end case;
                            else
                                lut_switch_rdata_cpuclk <= lut_switch_rdata_cpuclk;
                            end if;
                        end if;
                    end if;
                end process;
            end generate;

            G_LUT_RB_4TX : if (TX_ANT_NUM = 4) generate begin
                P_4TX_LUT_RB_Data_4Path_Switching : process(RST_CPU, CLK_CPU) begin
                    if (RST_CPU = '1') then
                        lut_switch_rdata_cpuclk <= (others => (others => '0'));
                    elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                        if (DPD_LUT_RB_TEST_EN_IN = '0') then     
                            lut_switch_rdata_cpuclk <= (others => (others => '0'));
                        else
                            if (lut_rden_rpls_cpuclk(0) = '1') then 
                                case (DPD_LUT_OUTPUT_SWITCH_IN(19 downto 16)) is  
                                    when x"0"   => lut_switch_rdata_cpuclk <= SW_LUT_RBDATA_IN(0); 
                                    when x"1"   => lut_switch_rdata_cpuclk <= SW_LUT_RBDATA_IN(1); 
                                    when x"2"   => lut_switch_rdata_cpuclk <= SW_LUT_RBDATA_IN(2); 
                                    when x"3"   => lut_switch_rdata_cpuclk <= SW_LUT_RBDATA_IN(3); 
                                    when x"4"   => lut_switch_rdata_cpuclk <= SW_LUT_RBDATA_IN(4); 
                                    when others => lut_switch_rdata_cpuclk <= (others => (others => '0')); 
                                end case;
                            else
                                lut_switch_rdata_cpuclk <= lut_switch_rdata_cpuclk;
                            end if;
                        end if;
                    end if;
                end process;
            end generate;

            dpdsw_lut_rdata_cpuclk(0) <= lut_switch_rdata_cpuclk( 0) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "000000") else
                                         lut_switch_rdata_cpuclk( 1) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "000001") else
                                         lut_switch_rdata_cpuclk( 2) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "000010") else
                                         lut_switch_rdata_cpuclk( 3) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "000011") else
                                         lut_switch_rdata_cpuclk( 4) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "000100") else
                                         lut_switch_rdata_cpuclk( 5) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "000101") else
                                         lut_switch_rdata_cpuclk( 6) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "000110") else
                                         lut_switch_rdata_cpuclk( 7) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "000111") else
                                         lut_switch_rdata_cpuclk( 8) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "001000") else
                                         lut_switch_rdata_cpuclk( 9) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "001001") else
                                         lut_switch_rdata_cpuclk(10) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "001010") else
                                         lut_switch_rdata_cpuclk(11) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "001011") else
                                         lut_switch_rdata_cpuclk(12) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "001100") else
                                         lut_switch_rdata_cpuclk(13) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "001101") else
                                         lut_switch_rdata_cpuclk(14) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "001110") else
                                         lut_switch_rdata_cpuclk(15) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "001111") else
                                         lut_switch_rdata_cpuclk(16) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "010000") else
                                         lut_switch_rdata_cpuclk(17) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "010001") else
                                         lut_switch_rdata_cpuclk(18) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "010010") else
                                         lut_switch_rdata_cpuclk(19) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "010011") else
                                         lut_switch_rdata_cpuclk(20) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "010100") else
                                         lut_switch_rdata_cpuclk(21) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "010101") else
                                         lut_switch_rdata_cpuclk(22) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "010110") else
                                         lut_switch_rdata_cpuclk(23) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "010111") else
                                         lut_switch_rdata_cpuclk(24) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "011000") else
                                         lut_switch_rdata_cpuclk(25) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "011001") else
                                         lut_switch_rdata_cpuclk(26) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "011010") else
                                         lut_switch_rdata_cpuclk(27) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "011011") else
                                         lut_switch_rdata_cpuclk(28) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "011100") else
                                         lut_switch_rdata_cpuclk(29) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "011101") else
                                         lut_switch_rdata_cpuclk(30) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "011110") else
                                         lut_switch_rdata_cpuclk(31) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "011111") else
                                         lut_switch_rdata_cpuclk(32) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "100000") else
                                         lut_switch_rdata_cpuclk(33) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "100001") else
                                         lut_switch_rdata_cpuclk(34) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "100010") else

                                         lut_switch_rdata_cpuclk(35) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "100011") else
                                         lut_switch_rdata_cpuclk(36) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "100100") else
                                         lut_switch_rdata_cpuclk(37) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "100101") else
                                         lut_switch_rdata_cpuclk(38) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "100110") else
                                         lut_switch_rdata_cpuclk(39) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "100111") else
                                         lut_switch_rdata_cpuclk(40) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "101000") else					 					 
                                         lut_switch_rdata_cpuclk(41) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "101001") else					 					 
                                         lut_switch_rdata_cpuclk(42) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "101010") else					 					 
                                         lut_switch_rdata_cpuclk(43) when (DPD_LUT_ADDR_IN(0)(14 downto 9) = "101011") else					 					 
                                         (others => '0');
        end generate;

        G_LUT_ReadBack_Test_Disable : if (LUT_RBTEST = FALSE) generate begin

            P_LUTSW_ENA : process(RST_CPU, CLK_CPU) begin
                if (RST_CPU = '1') then
                    lut_ena_cpuclk  <= (others => '0');          
                elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                    lut_ena_cpuclk  <= dpdsw_lut_wren_cpuclk(0);          
                end if;
            end process;

            lut_switch_rdata_cpuclk   <= (others => (others => '0'));
            dpdsw_lut_rdata_cpuclk(0) <= (others => '0');

	end generate;

        G_Unused_Signal_in_DPD_LUT_OPT : for I in 1 to (TX_ANT_NUM-1) generate begin
            dpdsw_lut_wren_cpuclk(I)  <= (others => '0'); 
            dpdsw_lut_addr_cpuclk(I)  <= (others => '0'); 
            dpdsw_lut_wdata_cpuclk(I) <= (others => '0'); 

            lut_rden_sh_cpuclk(I)     <= (others => '0');
            lut_rden_rpls_cpuclk(I)   <= '0'; 
            dpdsw_lut_rdata_cpuclk(I) <= (others => '0');
        end generate;

    end generate;

    DPD_LUT_RDATA_OUT <= dpdsw_lut_rdata_cpuclk;

    -- DPD Clock Domain

    G_LUT_Non_Optimized_Interface_DPDCLK : if (LUT_OPTIMIZED = FALSE) generate begin             

        G_TX_DPD_IQ_Magnitude_LUT_RADDR : for I in 0 to (TX_ANT_NUM-1) generate begin
            P_DPD_IQ_Magnitude_LUT_RADDR : process(RST_DPD, CLK_DPD) begin
                if (RST_DPD = '1') then
                    lut_raddr_dpdclk(I) <= (others => (others => '0')); 
                elsif (CLK_DPD'event) and (CLK_DPD = '1') then
                    lut_raddr_dpdclk(I) <= DPD_MAG_ADDR_IN(I); 
                end if;
            end process;
        end generate;
               
        lut_raddr_dpdclk(TX_ANT_NUM) <= (others => (others => '0')); 

        dpd_lut_rden_sh_dpdclk       <= (others => '0');                              
        dpd_lut_rden_rpls_dpdclk     <= '0';                              
        lut_rbaddr_dpdclk            <= (others => (others => '0')); 

        dpd_cdc_strb_sh_dpdclk       <= (others => '0');
        dpd_cdc_strb_rpls_dpdclk     <= '0';
        dpd_lut_raddr_switch_dpdclk  <= (others => (others => '0'));   
        dpd_lut_output_switch_dpdclk <= (others => '0');         

    end generate;

    G_LUT_Optimized_Interface_DPDCLK : if (LUT_OPTIMIZED = TRUE) generate begin             
        G_Normal_Performance : if (HS_MODE = FALSE) generate begin
            P_LUT_Read_Interface_CDC_NM : process(RST_DPD, CLK_DPD) begin
                if (RST_DPD = '1') then
                    dpd_lut_rden_sh_dpdclk   <= (others => '0');                              
                    dpd_lut_rden_rpls_dpdclk <= '0';                              
                    lut_rbaddr_dpdclk        <= (others => (others => '0')); 
                elsif (CLK_DPD'event) and (CLK_DPD = '1') then
                    dpd_lut_rden_sh_dpdclk   <= dpd_lut_rden_sh_dpdclk(1 downto 0) & lut_rden_sh_cpuclk(0)(1);                              
                    dpd_lut_rden_rpls_dpdclk <= dpd_lut_rden_sh_dpdclk(1) and (not dpd_lut_rden_sh_dpdclk(2));                              

                    if (dpd_lut_rden_rpls_dpdclk = '1') then 
                        lut_rbaddr_dpdclk <= lut_raddr_cpuclk; 
                    else     
                        lut_rbaddr_dpdclk <= lut_rbaddr_dpdclk; 
                    end if;
                end if;
            end process;

            P_Switch_REG_CDC_NM : process(RST_DPD, CLK_DPD) begin
                if (RST_DPD = '1') then
                    dpd_cdc_strb_sh_dpdclk       <= (others => '0');
                    dpd_cdc_strb_rpls_dpdclk     <= '0';
                    dpd_lut_raddr_switch_dpdclk  <= (others => (others => '0'));   
                    dpd_lut_output_switch_dpdclk <= (others => '0');         
                elsif (CLK_DPD'event) and (CLK_DPD = '1') then
                    dpd_cdc_strb_sh_dpdclk   <= dpd_cdc_strb_sh_dpdclk(1 downto 0) & DPD_CDC_STRB_IN;
                    dpd_cdc_strb_rpls_dpdclk <= dpd_cdc_strb_sh_dpdclk(1) and (not dpd_cdc_strb_sh_dpdclk(2));

                    if (dpd_cdc_strb_rpls_dpdclk = '1') then     
                        for I in 0 to TX_ANT_NUM loop
                            dpd_lut_raddr_switch_dpdclk(I) <= DPD_LUT_INPUT_SWITCH_IN(4*I+3 downto 4*I);   
                        end loop;
                        dpd_lut_output_switch_dpdclk <= DPD_LUT_OUTPUT_SWITCH_IN;         
                    else
                        dpd_lut_raddr_switch_dpdclk  <= dpd_lut_raddr_switch_dpdclk;   
                        dpd_lut_output_switch_dpdclk <= dpd_lut_output_switch_dpdclk;         
                    end if;
                end if;
            end process;
  
            G_Path_MUX_ANT2_NM : if (TX_ANT_NUM = 2) generate begin
                P_LUT_Read_Addres_Switch_ANT2_NM : process(RST_DPD, CLK_DPD) begin
                    if (RST_DPD = '1') then
                        lut_raddr_dpdclk(0) <= (others => (others => '0')); 
                    elsif (CLK_DPD'event) and (CLK_DPD = '1') then
                        case (dpd_lut_raddr_switch_dpdclk(0)) is -- LUT#0  
                            when x"0"   => lut_raddr_dpdclk(0) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(0) <= DPD_MAG_ADDR_IN(1); 
                            when x"4"   => lut_raddr_dpdclk(0) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(0) <= (others => (others => '0')); 
                        end case;

                        case (dpd_lut_raddr_switch_dpdclk(1)) is -- LUT#1  
                            when x"0"   => lut_raddr_dpdclk(1) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(1) <= DPD_MAG_ADDR_IN(1); 
                            when x"4"   => lut_raddr_dpdclk(1) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(1) <= (others => (others => '0')); 
                        end case;

                        case (dpd_lut_raddr_switch_dpdclk(2)) is -- LUT#2  
                            when x"0"   => lut_raddr_dpdclk(2) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(2) <= DPD_MAG_ADDR_IN(1); 
                            when x"4"   => lut_raddr_dpdclk(2) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(2) <= (others => (others => '0')); 
                        end case;
                    end if;
                end process;
            end generate;

            G_Path_MUX_ANT4_NM : if (TX_ANT_NUM = 4) generate begin
                P_LUT_Read_Addres_Switch_ANT2_NM : process(RST_DPD, CLK_DPD) begin
                    if (RST_DPD = '1') then
                        lut_raddr_dpdclk(0) <= (others => (others => '0')); 
                    elsif (CLK_DPD'event) and (CLK_DPD = '1') then
                        case (dpd_lut_raddr_switch_dpdclk(0)) is -- LUT#0  
                            when x"0"   => lut_raddr_dpdclk(0) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(0) <= DPD_MAG_ADDR_IN(1); 
                            when x"2"   => lut_raddr_dpdclk(0) <= DPD_MAG_ADDR_IN(2); 
                            when x"3"   => lut_raddr_dpdclk(0) <= DPD_MAG_ADDR_IN(3); 
                            when x"4"   => lut_raddr_dpdclk(0) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(0) <= (others => (others => '0')); 
                        end case;

                        case (dpd_lut_raddr_switch_dpdclk(1)) is -- LUT#1  
                            when x"0"   => lut_raddr_dpdclk(1) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(1) <= DPD_MAG_ADDR_IN(1); 
                            when x"2"   => lut_raddr_dpdclk(1) <= DPD_MAG_ADDR_IN(2); 
                            when x"3"   => lut_raddr_dpdclk(1) <= DPD_MAG_ADDR_IN(3); 
                            when x"4"   => lut_raddr_dpdclk(1) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(1) <= (others => (others => '0')); 
                        end case;

                        case (dpd_lut_raddr_switch_dpdclk(2)) is -- LUT#2  
                            when x"0"   => lut_raddr_dpdclk(2) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(2) <= DPD_MAG_ADDR_IN(1); 
                            when x"2"   => lut_raddr_dpdclk(2) <= DPD_MAG_ADDR_IN(2); 
                            when x"3"   => lut_raddr_dpdclk(2) <= DPD_MAG_ADDR_IN(3); 
                            when x"4"   => lut_raddr_dpdclk(2) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(2) <= (others => (others => '0')); 
                        end case;

                        case (dpd_lut_raddr_switch_dpdclk(3)) is -- LUT#3  
                            when x"0"   => lut_raddr_dpdclk(3) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(3) <= DPD_MAG_ADDR_IN(1); 
                            when x"2"   => lut_raddr_dpdclk(3) <= DPD_MAG_ADDR_IN(2); 
                            when x"3"   => lut_raddr_dpdclk(3) <= DPD_MAG_ADDR_IN(3); 
                            when x"4"   => lut_raddr_dpdclk(3) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(3) <= (others => (others => '0')); 
                        end case;

                        case (dpd_lut_raddr_switch_dpdclk(4)) is -- LUT#4  
                            when x"0"   => lut_raddr_dpdclk(4) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(4) <= DPD_MAG_ADDR_IN(1); 
                            when x"2"   => lut_raddr_dpdclk(4) <= DPD_MAG_ADDR_IN(2); 
                            when x"3"   => lut_raddr_dpdclk(4) <= DPD_MAG_ADDR_IN(3); 
                            when x"4"   => lut_raddr_dpdclk(4) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(4) <= (others => (others => '0')); 
                        end case;
                    end if;
                end process;
            end generate;
        end generate;

        G_High_Speed_Performance : if (HS_MODE = TRUE) generate begin
            P_LUT_Read_Interface_CDC_HS : process(CLK_DPD) begin
                if (CLK_DPD'event) and (CLK_DPD = '1') then
                    dpd_lut_rden_sh_dpdclk   <= dpd_lut_rden_sh_dpdclk(1 downto 0) & lut_rden_sh_cpuclk(0)(1);                              
                    dpd_lut_rden_rpls_dpdclk <= dpd_lut_rden_sh_dpdclk(1) and (not dpd_lut_rden_sh_dpdclk(2));                              

                    if (dpd_lut_rden_rpls_dpdclk = '1') then 
                        lut_rbaddr_dpdclk <= lut_raddr_cpuclk; 
                    else     
                        lut_rbaddr_dpdclk <= lut_rbaddr_dpdclk; 
                    end if;
                end if;
            end process;

            P_Switch_REG_CDC_HS : process(CLK_DPD) begin
                if (CLK_DPD'event) and (CLK_DPD = '1') then
                    dpd_cdc_strb_sh_dpdclk   <= dpd_cdc_strb_sh_dpdclk(1 downto 0) & DPD_CDC_STRB_IN;
                    dpd_cdc_strb_rpls_dpdclk <= dpd_cdc_strb_sh_dpdclk(1) and (not dpd_cdc_strb_sh_dpdclk(2));

                    if (dpd_cdc_strb_rpls_dpdclk = '1') then     
                        for I in 0 to TX_ANT_NUM loop
                            dpd_lut_raddr_switch_dpdclk(I) <= DPD_LUT_INPUT_SWITCH_IN(4*I+3 downto 4*I);   
                        end loop;
                        dpd_lut_output_switch_dpdclk <= DPD_LUT_OUTPUT_SWITCH_IN;         
                    else
                        dpd_lut_raddr_switch_dpdclk  <= dpd_lut_raddr_switch_dpdclk;   
                        dpd_lut_output_switch_dpdclk <= dpd_lut_output_switch_dpdclk;         
                    end if;
                end if;
            end process;

            G_Path_MUX_ANT2_HS : if (TX_ANT_NUM = 2) generate begin
                P_LUT_Read_Addres_Switch_ANT2_NM : process(CLK_DPD) begin
                    if (CLK_DPD'event) and (CLK_DPD = '1') then
                        case (dpd_lut_raddr_switch_dpdclk(0)) is -- LUT#0  
                            when x"0"   => lut_raddr_dpdclk(0) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(0) <= DPD_MAG_ADDR_IN(1); 
                            when x"4"   => lut_raddr_dpdclk(0) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(0) <= (others => (others => '0')); 
                        end case;

                        case (dpd_lut_raddr_switch_dpdclk(1)) is -- LUT#1  
                            when x"0"   => lut_raddr_dpdclk(1) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(1) <= DPD_MAG_ADDR_IN(1); 
                            when x"4"   => lut_raddr_dpdclk(1) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(1) <= (others => (others => '0')); 
                        end case;

                        case (dpd_lut_raddr_switch_dpdclk(2)) is -- LUT#2  
                            when x"0"   => lut_raddr_dpdclk(2) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(2) <= DPD_MAG_ADDR_IN(1); 
                            when x"4"   => lut_raddr_dpdclk(2) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(2) <= (others => (others => '0')); 
                        end case;
                    end if;
                end process;
            end generate;

            G_Path_MUX_ANT4_HS : if (TX_ANT_NUM = 4) generate begin
                P_LUT_Read_Addres_Switch_ANT2_NM : process(CLK_DPD) begin
                    if (CLK_DPD'event) and (CLK_DPD = '1') then
                        case (dpd_lut_raddr_switch_dpdclk(0)) is -- LUT#0  
                            when x"0"   => lut_raddr_dpdclk(0) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(0) <= DPD_MAG_ADDR_IN(1); 
                            when x"2"   => lut_raddr_dpdclk(0) <= DPD_MAG_ADDR_IN(2); 
                            when x"3"   => lut_raddr_dpdclk(0) <= DPD_MAG_ADDR_IN(3); 
                            when x"4"   => lut_raddr_dpdclk(0) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(0) <= (others => (others => '0')); 
                        end case;

                        case (dpd_lut_raddr_switch_dpdclk(1)) is -- LUT#1  
                            when x"0"   => lut_raddr_dpdclk(1) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(1) <= DPD_MAG_ADDR_IN(1); 
                            when x"2"   => lut_raddr_dpdclk(1) <= DPD_MAG_ADDR_IN(2); 
                            when x"3"   => lut_raddr_dpdclk(1) <= DPD_MAG_ADDR_IN(3); 
                            when x"4"   => lut_raddr_dpdclk(1) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(1) <= (others => (others => '0')); 
                        end case;

                        case (dpd_lut_raddr_switch_dpdclk(2)) is -- LUT#2  
                            when x"0"   => lut_raddr_dpdclk(2) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(2) <= DPD_MAG_ADDR_IN(1); 
                            when x"2"   => lut_raddr_dpdclk(2) <= DPD_MAG_ADDR_IN(2); 
                            when x"3"   => lut_raddr_dpdclk(2) <= DPD_MAG_ADDR_IN(3); 
                            when x"4"   => lut_raddr_dpdclk(2) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(2) <= (others => (others => '0')); 
                        end case;

                        case (dpd_lut_raddr_switch_dpdclk(3)) is -- LUT#3  
                            when x"0"   => lut_raddr_dpdclk(3) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(3) <= DPD_MAG_ADDR_IN(1); 
                            when x"2"   => lut_raddr_dpdclk(3) <= DPD_MAG_ADDR_IN(2); 
                            when x"3"   => lut_raddr_dpdclk(3) <= DPD_MAG_ADDR_IN(3); 
                            when x"4"   => lut_raddr_dpdclk(3) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(3) <= (others => (others => '0')); 
                        end case;

                        case (dpd_lut_raddr_switch_dpdclk(4)) is -- LUT#4  
                            when x"0"   => lut_raddr_dpdclk(4) <= DPD_MAG_ADDR_IN(0); 
                            when x"1"   => lut_raddr_dpdclk(4) <= DPD_MAG_ADDR_IN(1); 
                            when x"2"   => lut_raddr_dpdclk(4) <= DPD_MAG_ADDR_IN(2); 
                            when x"3"   => lut_raddr_dpdclk(4) <= DPD_MAG_ADDR_IN(3); 
                            when x"4"   => lut_raddr_dpdclk(4) <= lut_rbaddr_dpdclk; 
                            when others => lut_raddr_dpdclk(4) <= (others => (others => '0')); 
                        end case;
                    end if;
                end process;
            end generate;
        end generate;
    end generate;

    SW_LUT_UPDATE_SWITCH_OUT  <= dpd_lut_update_sw;

    SW_LUT_ENA_OUT            <= lut_switch_ena_cpuclk; 
    SW_LUT_WREN_OUT           <= lut_switch_wren_cpuclk; 
    SW_LUT_WADDR_OUT          <= lut_switch_waddr_cpuclk;
    SW_LUT_WDATA_OUT          <= lut_switch_wdata_cpuclk;
    SW_LUT_RADDR_OUT          <= lut_raddr_dpdclk;

    DPD_LUT_OUTPUT_SWITCH_OUT <= dpd_lut_output_switch_dpdclk;

end arc_DPD_LUT44_SWIF;

