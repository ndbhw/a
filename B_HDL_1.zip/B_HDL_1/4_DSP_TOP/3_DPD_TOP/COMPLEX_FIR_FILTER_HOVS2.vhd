library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity COMPLEX_FIR_FILTER_HOVS2 is
generic(
    DEVICE         : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    TAP_NUM        : natural :=  8;
    RND_BIT        : natural := 13
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;

    COEF_I_IN      : in  std_logic_array27(TAP_NUM-1 downto 0);
    COEF_Q_IN      : in  std_logic_array27(TAP_NUM-1 downto 0);

    DATA_VLD_IN    : in  std_logic;
    DATA_I_IN      : in  std_logic_vector(15 downto 0);
    DATA_Q_IN      : in  std_logic_vector(15 downto 0);

    DATA_VLD_OUT   : out std_logic;
    DATA_I_OUT     : out std_logic_vector(15 downto 0);
    DATA_Q_OUT     : out std_logic_vector(15 downto 0)
    );
end COMPLEX_FIR_FILTER_HOVS2;

architecture arc_COMPLEX_FIR_FILTER_HOVS2 of COMPLEX_FIR_FILTER_HOVS2 is

component SRL16E_DLY is
generic(
    DEVICE    : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HS_MODE   : boolean := FALSE; 

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0) -- Delayed DATA
    );
end component;

component SAT_SIGN is
generic(
    HS_MODE    : boolean := FALSE;
    INPUT_BIT  : natural;
    OUTPUT_BIT : natural
    );
port( 
    RST        : in  std_logic;
    CLK        : in  std_logic;
    DATA_IN    : in  std_logic_vector(INPUT_BIT-1  downto 0);
    DATA_OUT   : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

component DSP48E1_COMPLEX_FIR_HOVSn_1st is
generic(
    RND_EN           : boolean; -- "TRUE" : Using Rounding, "FALSE" : Nonusing Rounding
    RND_BIT          : natural  -- Rounding Bit
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;

    ALUMODE          : in  std_logic_vector( 3 downto 0);
    OPMODE           : in  std_logic_vector( 6 downto 0);

    DATA_IN          : in  std_logic_vector(17 downto 0);
    COEFFICIENT      : in  std_logic_vector(29 downto 0);

    RESULT_CHAIN_OUT : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E1_COMPLEX_FIR_HOVSn_nth is
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;

    ALUMODE          : in  std_logic_vector( 3 downto 0);
    OPMODE           : in  std_logic_vector( 6 downto 0);

    DATA_IN          : in  std_logic_vector(17 downto 0);
    COEFFICIENT      : in  std_logic_vector(29 downto 0);
    RESULT_CHAIN_IN  : in  std_logic_vector(47 downto 0);

    RESULT_CHAIN_OUT : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E1_COMPLEX_FIR_HOVSn_end is
port(
    RST             : in  std_logic;
    CLK             : in  std_logic;

    ALUMODE         : in  std_logic_vector( 3 downto 0);
    OPMODE          : in  std_logic_vector( 6 downto 0);

    DATA_IN         : in  std_logic_vector(17 downto 0);
    COEFFICIENT     : in  std_logic_vector(29 downto 0);
    RESULT_CHAIN_IN : in  std_logic_vector(47 downto 0);

    RESULT          : out std_logic_vectoR(47 downto 0)
    );
end component;

component DSP48E2_COMPLEX_FIR_HOVSn_1st is
generic(
    RND_EN           : boolean; -- "TRUE" : Using Rounding, "FALSE" : Nonusing Rounding
    RND_BIT          : natural  -- Rounding Bit
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;

    ALUMODE          : in  std_logic_vector( 3 downto 0);
    OPMODE           : in  std_logic_vector( 8 downto 0);

    DATA_IN          : in  std_logic_vector(17 downto 0);
    COEFFICIENT      : in  std_logic_vector(29 downto 0);

    RESULT_CHAIN_OUT : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E2_COMPLEX_FIR_HOVSn_nth is
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;

    ALUMODE          : in  std_logic_vector( 3 downto 0);
    OPMODE           : in  std_logic_vector( 8 downto 0);

    DATA_IN          : in  std_logic_vector(17 downto 0);
    COEFFICIENT      : in  std_logic_vector(29 downto 0);
    RESULT_CHAIN_IN  : in  std_logic_vector(47 downto 0);

    RESULT_CHAIN_OUT : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E2_COMPLEX_FIR_HOVSn_end is
port(
    RST             : in  std_logic;
    CLK             : in  std_logic;

    ALUMODE         : in  std_logic_vector( 3 downto 0);
    OPMODE          : in  std_logic_vector( 8 downto 0);

    DATA_IN         : in  std_logic_vector(17 downto 0);
    COEFFICIENT     : in  std_logic_vector(29 downto 0);
    RESULT_CHAIN_IN : in  std_logic_vector(47 downto 0);

    RESULT          : out std_logic_vectoR(47 downto 0)
    );
end component;

constant zeros         : std_logic_vector(47 downto 0) := (others => '0');

signal data_i         : std_logic_vector(15 downto 0);
signal data_q         : std_logic_vector(15 downto 0);

signal coef_i         : std_logic_array27(TAP_NUM-1 downto 0);
signal coef_q         : std_logic_array27(TAP_NUM-1 downto 0);

signal data_iq        : std_logic_array16(TAP_NUM-1 downto 0);
signal se_data_iq     : std_logic_array18(TAP_NUM-1 downto 0);

signal coef_iq        : std_logic_array27(TAP_NUM-1 downto 0);
signal coef_qi        : std_logic_array27(TAP_NUM-1 downto 0);

signal se_coef_iq     : std_logic_array30(TAP_NUM-1 downto 0);
signal se_coef_qi     : std_logic_array30(TAP_NUM-1 downto 0);

signal alumode_i      : std_logic_vector(3 downto 0); -- "0000" : PCIN+A*B, "0011" : P-A*B
signal alumode_q      : std_logic_vector(3 downto 0); -- "0000" : PCIN+A*B, "0011" : P-A*B
signal opmode_tap_1st : std_logic_vector(8 downto 0); -- "000010101" : PCIN calculation, "0100101" : Internal P calculation
signal opmode_tap_nth : std_logic_vector(8 downto 0); -- "000010101" : PCIN calculation, "0100101" : Internal P calculation

signal i_acmbd        : std_logic_array48(TAP_NUM-1 downto 0); -- AC - BD 
signal q_adpbc        : std_logic_array48(TAP_NUM-1 downto 0); -- AD + BC

signal rnd_i          : std_logic_vector(48-RND_BIT downto 0);
signal rnd_q          : std_logic_vector(48-RND_BIT downto 0);

signal sat_i          : std_logic_vector(15 downto 0);
signal sat_q          : std_logic_vector(15 downto 0);

signal filter_out_vld : std_logic;
signal filter_out_i   : std_logic_vector(15 downto 0);
signal filter_out_q   : std_logic_vector(15 downto 0);

begin

    P_COEF_N_Sample_Align : process(RST, CLK) begin
        if (RST = '1') then
            data_i <= (others => '0'); 
            data_q <= (others => '0'); 
            
            coef_i <= (others => (others => '0')); 
            coef_q <= (others => (others => '0')); 
        elsif (CLK'event) and (CLK = '1') then
            if (DATA_VLD_IN = '0') then
                data_i <= DATA_I_IN; 
                data_q <= DATA_Q_IN; 
                          
                coef_i <= COEF_I_IN; 
                coef_q <= COEF_Q_IN; 
            else
                data_i <= data_i; 
                data_q <= data_q; 
                                
                coef_i <= coef_i; 
                coef_q <= coef_q; 
            end if;
        end if;
    end process;

    P_Sample_Time_Mux : process(RST, CLK) begin 
        if (RST = '1') then
            data_iq(0) <= (others => '0'); 
        elsif (CLK'event) and (CLK = '1') then
            if (DATA_VLD_IN = '1') then
                data_iq(0) <= data_i; 
            else
                data_iq(0) <= data_q; 
            end if;
        end if;
    end process;

    G_IQ_Sample_Delay : for I in 0 to (TAP_NUM-2) generate begin 
        U_IQ_data_Delay : SRL16E_DLY generic map(DEVICE, FALSE, 16, 4) port map(CLK, data_iq(I), data_iq(I+1));
    end generate;

    G_IQ_Sample_Sign_Extention : for I in 0 to (TAP_NUM-1) generate begin
        se_data_iq(I) <= sign_extension(data_iq(I), 18);
    end generate;

    G_Coef_IQ_Time_Mux : for I in 0 to (TAP_NUM-1) generate begin
        P_Coef_IQ_Time_Mux : process(RST, CLK) begin
            if (RST = '1') then
                coef_iq(I) <= (others => '0');
                coef_qi(I) <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                if (DATA_VLD_IN = '1') then 
                    coef_iq(I) <= coef_i(I);
                    coef_qi(I) <= coef_q(I);
                else                    
                    coef_iq(I) <= coef_q(I);
                    coef_qi(I) <= coef_i(I);
                end if;
            end if;
        end process;
    end generate;

    G_Coef_IQ_Sign_Extention : for I in 0 to (TAP_NUM-1) generate begin
        se_coef_iq(I) <= sign_extension(coef_iq(I), 30);
        se_coef_qi(I) <= sign_extension(coef_qi(I), 30);
    end generate;

    P_DSP48E_Operation_CTRL : process(RST, CLK) begin
        if (RST = '1') then
            alumode_i      <= (others => '0'); -- "0000" : PCIN+A*B, "0011" : P-A*B
            alumode_q      <= (others => '0'); -- "0000" : PCIN+A*B, "0011" : P-A*B
            opmode_tap_1st <= (others => '0'); -- "0010101" : PCIN calculation, "0100101" : Internal P calculation
            opmode_tap_nth <= (others => '0'); -- "0010101" : PCIN calculation, "0100101" : Internal P calculation
        elsif (CLK'event) and (CLK = '1') then
            alumode_q      <= zeros(3 downto 0);         -- P/PCIN+A*B

            if (DATA_VLD_IN = '1') then
                alumode_i      <= "0000"     ; -- P/PCIN+A*B
                opmode_tap_1st <= "000110101"; -- RND  calculation 
                opmode_tap_nth <= "000010101"; -- PCIN calculation 
            else
                alumode_i      <= "0011"     ; -- P/PCIN-A*B
                opmode_tap_1st <= "000100101"; -- Internal P calculation
                opmode_tap_nth <= "000100101"; -- Internal P calculation
            end if;
        end if;
    end process;

-- [Complex multplication calculation] 
--   MPA2 = x[n+2] * lut_sum(|x[n+2]|)
--   MPA1 = x[n+1] * lut_sum(|x[n+1]|+|x[n]|)
--   MP0  = x[n  ] * lut_sum(|x[n+1]|+|x[n]|+|x[n-1]|+|x[n-2]|)
--   MP1  = x[n-1] * lut_sum(|x[n]|+|x[n-1]|+|x[n-2]|)
--   MP2  = x[n-2] * lut_sum(|x[n]|+|x[n-1]|+|x[n-2]|)
--   MP3  = x[n-3] * lut_sum(|x[n-3]|)
--   MP4  = x[n-4] * lut_sum(|x[n-4]|)
--   MP5  = x[n-5] * lut_sum(|x[n-5]|)

-- (a+bi)(c+di) = (ac-bd)+(ad+bc)i

----------------------------------------------------------------------
--                 1clk                      |       2clk 
-- dsp48os_a = (COEF[n]*DATA[n])+0            +- (COEF[n-1]*DATA[n-1]) 
-- dsp48os_b = (COEF[n]*DATA[n])+RESULT_CHAIN +- (COEF[n-1]*DATA[n-1])
-- dsp48os_c = (COEF[n]*DATA[n])+RESULT_CHAIN +- (COEF[n-1]*DATA[n-1]) 
----------------------------------------------------------------------

    G_7Series_DSP48E1 : if (DEVICE = "7SERIES") generate begin
        G_DSP48E1_COMPLEX_FIR_TAP : for I in 0 to TAP_NUM-1 generate begin
            G_DSP48E1_1st_TAP : if (I = 0) generate begin
                U_DSP48E1_I_ACmBD_1st : DSP48E1_COMPLEX_FIR_HOVSn_1st generic map(TRUE, RND_BIT) port map(RST, CLK, alumode_i, opmode_tap_1st(6 downto 0), se_data_iq(I), se_coef_iq(I), i_acmbd(I)); 
                U_DSP48E1_Q_ADpBC_1st : DSP48E1_COMPLEX_FIR_HOVSn_1st generic map(TRUE, RND_BIT) port map(RST, CLK, alumode_q, opmode_tap_1st(6 downto 0), se_data_iq(I), se_coef_qi(I), q_adpbc(I)); 
            end generate;

            G_DSP48E1_nth_TAP : if ((I > 0) and (I < TAP_NUM-1)) generate begin
                U_DSP48E1_I_ACmBD_nth : DSP48E1_COMPLEX_FIR_HOVSn_nth port map(RST, CLK, alumode_i, opmode_tap_nth(6 downto 0), se_data_iq(I), se_coef_iq(I), i_acmbd(I-1), i_acmbd(I));
                U_DSP48E1_Q_ADpBC_nth : DSP48E1_COMPLEX_FIR_HOVSn_nth port map(RST, CLK, alumode_q, opmode_tap_nth(6 downto 0), se_data_iq(I), se_coef_qi(I), q_adpbc(I-1), q_adpbc(I));
            end generate;                                                                                     
                                                                                                              
            G_DSP48E1_end_TAP : if (I = TAP_NUM-1) generate begin                                             
                U_DSP48E1_I_ACmBD_end : DSP48E1_COMPLEX_FIR_HOVSn_end port map(RST, CLK, alumode_i, opmode_tap_nth(6 downto 0), se_data_iq(I), se_coef_iq(I), i_acmbd(I-1), i_acmbd(I));
                U_DSP48E1_Q_ADpBC_end : DSP48E1_COMPLEX_FIR_HOVSn_end port map(RST, CLK, alumode_q, opmode_tap_nth(6 downto 0), se_data_iq(I), se_coef_qi(I), q_adpbc(I-1), q_adpbc(I));
            end generate;
        end generate;
    end generate;

    G_UltraScale_DSP48E2 : if (DEVICE = "ULTRASCALE") generate begin
        G_DSP48E2_COMPLEX_FIR_TAP : for I in 0 to TAP_NUM-1 generate begin
            G_DSP48E2_1st_TAP : if (I = 0) generate begin
                U_DSP48E2_I_ACmBD_1st : DSP48E2_COMPLEX_FIR_HOVSn_1st generic map(TRUE, RND_BIT) port map(RST, CLK, alumode_i, opmode_tap_1st, se_data_iq(I), se_coef_iq(I), i_acmbd(I)); 
                U_DSP48E2_Q_ADpBC_1st : DSP48E2_COMPLEX_FIR_HOVSn_1st generic map(TRUE, RND_BIT) port map(RST, CLK, alumode_q, opmode_tap_1st, se_data_iq(I), se_coef_qi(I), q_adpbc(I)); 
            end generate;

            G_DSP48E2_nth_TAP : if ((I > 0) and (I < TAP_NUM-1)) generate begin
                U_DSP48E2_I_ACmBD_nth : DSP48E2_COMPLEX_FIR_HOVSn_nth port map(RST, CLK, alumode_i, opmode_tap_nth, se_data_iq(I), se_coef_iq(I), i_acmbd(I-1), i_acmbd(I));
                U_DSP48E2_Q_ADpBC_nth : DSP48E2_COMPLEX_FIR_HOVSn_nth port map(RST, CLK, alumode_q, opmode_tap_nth, se_data_iq(I), se_coef_qi(I), q_adpbc(I-1), q_adpbc(I));
            end generate;

            G_DSP48E2_end_TAP : if (I = TAP_NUM-1) generate begin
                U_DSP48E2_I_ACmBD_end : DSP48E2_COMPLEX_FIR_HOVSn_end port map(RST, CLK, alumode_i, opmode_tap_nth, se_data_iq(I), se_coef_iq(I), i_acmbd(I-1), i_acmbd(I));
                U_DSP48E2_Q_ADpBC_end : DSP48E2_COMPLEX_FIR_HOVSn_end port map(RST, CLK, alumode_q, opmode_tap_nth, se_data_iq(I), se_coef_qi(I), q_adpbc(I-1), q_adpbc(I));
            end generate;
        end generate;
    end generate;

    P_Sample_Extract_and_13bit_Rounding : process(RST, CLK) begin
        if (RST = '1') then
            rnd_i <= (others => '0'); 
            rnd_q <= (others => '0'); 
        elsif (CLK'event) and (CLK = '1') then
            if (DATA_VLD_IN = '1') then
                rnd_i <= i_acmbd(TAP_NUM-1)(47) & i_acmbd(TAP_NUM-1)(47 downto RND_BIT); 
                rnd_q <= q_adpbc(TAP_NUM-1)(47) & q_adpbc(TAP_NUM-1)(47 downto RND_BIT); 
            else
                rnd_i <= rnd_i; 
                rnd_q <= rnd_q; 
            end if;
        end if;
    end process;
            
    U_SAT_16B_DPD_OUT_I : SAT_SIGN generic map(FALSE, 48-RND_BIT+1, 16) port map (RST, CLK, rnd_i, sat_i);
    U_SAT_16B_DPD_OUT_Q : SAT_SIGN generic map(FALSE, 48-RND_BIT+1, 16) port map (RST, CLK, rnd_q, sat_q);

    P_Output_Align : process(RST, CLK) begin
        if (RST = '1') then
            filter_out_vld <= '0'; 
            filter_out_i   <= (others => '0');
            filter_out_q   <= (others => '0'); 
        elsif (CLK'event) and (CLK = '1') then
            filter_out_vld <= DATA_VLD_IN; 

            if (DATA_VLD_IN = '1') then
                filter_out_i <= sat_i;
                filter_out_q <= sat_q; 
            else
                filter_out_i <= filter_out_i   ;
                filter_out_q <= filter_out_q   ; 
            end if;
        end if;
    end process;

    DATA_VLD_OUT <= filter_out_vld; 
    DATA_I_OUT   <= filter_out_i; 
    DATA_Q_OUT   <= filter_out_q; 

end arc_COMPLEX_FIR_FILTER_HOVS2;
