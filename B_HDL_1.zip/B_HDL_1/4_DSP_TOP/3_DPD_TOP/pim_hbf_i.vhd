-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2023.09.15 v1.0] Initial release
-- *****************************************************************************

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;
use ieee.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity pim_hbf_i is
    generic (
		FILTER_ORDER					: integer := 27;		-- 27 or 19 or 11
		WIDTH_IN                    	: integer := 16;
		WIDTH_OUT                   	: integer := 16;
		BINARY_POINT                	: integer := 15
	);
	port(
		i_rst   						: in  std_logic;
		i_clk							: in  std_logic;

        -- in sample rate : 122.88 MHz
		i_data_i					    : in  std_logic_vector(WIDTH_IN-1 downto 0);
		i_data_q					    : in  std_logic_vector(WIDTH_IN-1 downto 0);

        -- out sample rate : 245.76 MHz
		o_data_i						: out std_logic_vector(WIDTH_OUT-1 downto 0);
		o_data_q						: out std_logic_vector(WIDTH_OUT-1 downto 0)
	);
end pim_hbf_i;

architecture Behavioral of pim_hbf_i is

    component lib_adder_multi_c_pcin_dsp2 is
		generic(
			width_a                     : integer := 30;		-- max 30
			width_d                     : integer := 27;		-- max 27
			width_b                     : integer := 18;		-- max 18
			width_c						: integer := 48;    	-- max 48
			width_p                     : integer := 48;		-- max 48
			
			pcin_use					: std_logic := '0';		-- '0' : not use, '1' : use
			A_INPUT						: string := "DIRECT";   -- "DIRECT" or "CASCADE"
			B_INPUT						: string := "DIRECT";   -- "DIRECT" or "CASCADE"
			pre_add_minus				: std_logic := '0';		-- '0' : add, '1' : sub
			c_add_minus					: std_logic := '0'		-- '0' : add, '1' : sub
		);
		port(
			i_clk                       : in std_logic;
		
			dsp_a                       : in std_logic_vector(width_a-1 downto 0);
			dsp_d                       : in std_logic_vector(width_d-1 downto 0);
			dsp_b						: in std_logic_vector(width_b-1 downto 0);
			dsp_c						: in std_logic_vector(width_c-1 downto 0);
			dsp_acin					: in std_logic_vector(30-1 downto 0);
			dsp_bcin					: in std_logic_vector(18-1 downto 0);
			dsp_pcin					: in std_logic_vector(48-1 downto 0);
			
			dsp_acout					: out std_logic_vector(30-1 downto 0);
			dsp_bcout					: out std_logic_vector(18-1 downto 0);
			dsp_pcout					: out std_logic_vector(48-1 downto 0);
			dsp_p                       : out std_logic_vector(width_p-1 downto 0)
		);
	end component lib_adder_multi_c_pcin_dsp2;

    type std_logic_array_WIDTH_IN               is array(natural range <>) of std_logic_vector(WIDTH_IN-1 downto 0);

    constant TAP_ORDER                      : integer := ternary_func(FILTER_ORDER = 27, 14, ternary_func(FILTER_ORDER = 19, 10, 6));
    constant hbf_coeff_6					: integer_array(6/2-1 downto 0) := (19446,-3594,535);
	constant hbf_coeff_10					: integer_array(10/2-1 downto 0) := (20196,-5170,1776,-500,84);
	constant hbf_coeff_14					: integer_array(14/2-1 downto 0) := (20502,-5942,2674,-1214,491,-158,33);
	constant coefficient					: integer_array(TAP_ORDER/2-1 downto 0) := ternary_func(TAP_ORDER = 14, hbf_coeff_14, ternary_func(TAP_ORDER = 10, hbf_coeff_10, hbf_coeff_6));

    constant ZERO							: std_logic_vector(15-1 downto 0) := (others=>'0');
    constant round          				: std_logic_vector(48-1 downto 0) := conv_std_logic_vector(2**(BINARY_POINT), 48);	

	signal  r_data_i					    : std_logic_vector(WIDTH_IN-1 downto 0);
	signal  r_data_q					    : std_logic_vector(WIDTH_IN-1 downto 0);

    signal  data_i_dly					    : std_logic_array_WIDTH_IN(TAP_ORDER*2-1 downto 0);
	signal  data_q_dly					    : std_logic_array_WIDTH_IN(TAP_ORDER*2-1 downto 0);

    signal  dsp_a_in_i						: std_logic_array_WIDTH_IN(TAP_ORDER/2-1 downto 0);
	signal  dsp_a_in_q						: std_logic_array_WIDTH_IN(TAP_ORDER/2-1 downto 0);
	signal  dsp_d_in_i						: std_logic_array_WIDTH_IN(TAP_ORDER/2-1 downto 0);
	signal  dsp_d_in_q						: std_logic_array_WIDTH_IN(TAP_ORDER/2-1 downto 0);
    signal  dsp_b_in						: std_logic_array16(TAP_ORDER/2-1 downto 0);
    signal  dsp_c_i							: std_logic_vector(WIDTH_IN+15-1 downto 0) := (others=>'0');
	signal  dsp_c_q							: std_logic_vector(WIDTH_IN+15-1 downto 0);
    signal  dsp_pcout_i						: std_logic_array48(TAP_ORDER/2-1 downto 0);
    signal  dsp_pcout_q						: std_logic_array48(TAP_ORDER/2-1 downto 0);
    signal  dsp_p_i							: std_logic_array48(TAP_ORDER/2-1 downto 0);
	signal  dsp_p_q							: std_logic_array48(TAP_ORDER/2-1 downto 0);
    signal  dsp_p_i_round                   : std_logic_vector(48-1 downto 0);
    signal  dsp_p_q_round                   : std_logic_vector(48-1 downto 0);

	signal  data_i_out						: std_logic_vector(WIDTH_OUT-1 downto 0);
	signal  data_q_out						: std_logic_vector(WIDTH_OUT-1 downto 0);

	signal  toggle_sig						: std_logic;

begin

	process(i_rst, i_clk) begin if (i_rst = '1') then toggle_sig <= '0'; elsif (rising_edge(i_clk)) then toggle_sig <= not toggle_sig; end if; end process;

	process(i_clk)
	begin
		if (rising_edge(i_clk)) then
			if (toggle_sig = '1') then
				r_data_i					<=  i_data_i;
				r_data_q					<=  i_data_q;
			else
				r_data_i					<=  (others=>'0');
				r_data_q					<=  (others=>'0');
			end if;
		end if;
	end process;
	
    process(i_clk)
    begin
        if (rising_edge(i_clk)) then
            data_i_dly                      <=  data_i_dly(TAP_ORDER*2-2 downto 0) & r_data_i;
            data_q_dly                      <=  data_q_dly(TAP_ORDER*2-2 downto 0) & r_data_q;
            
			dsp_c_i							<=	data_i_dly(TAP_ORDER/2+3) & ZERO;
            dsp_c_q							<=	data_q_dly(TAP_ORDER/2+3) & ZERO;
        end if;
    end process;

    GEN_TAP_OREDER : for i in 0 to TAP_ORDER/2-1 generate
        dsp_b_in(i)					        <=	conv_std_logic_vector(coefficient(TAP_ORDER/2-1-i),16);

        process(i_clk)
        begin
            if (rising_edge(i_clk)) then
                dsp_a_in_i(i)               <=  data_i_dly((TAP_ORDER/2)-1-i);
                dsp_a_in_q(i)               <=  data_q_dly((TAP_ORDER/2)-1-i);
                dsp_d_in_i(i)               <=  data_i_dly((i*3)+(TAP_ORDER/2)+1);
                dsp_d_in_q(i)               <=  data_q_dly((i*3)+(TAP_ORDER/2)+1);
            end if;
        end process;
    end generate GEN_TAP_OREDER;

    -- latency 4 clk
    hbf_1st_i : lib_adder_multi_c_pcin_dsp2 generic map(WIDTH_IN,WIDTH_IN,16,WIDTH_IN+15,48,'0',"DIRECT","DIRECT",'0','0')
	port map(i_clk,dsp_a_in_i(0),dsp_d_in_i(0),dsp_b_in(0),dsp_c_i,(others=>'0'),(others=>'0'),(others=>'0'),open,open,dsp_pcout_i(0),open);

    hbf_1st_q : lib_adder_multi_c_pcin_dsp2 generic map(WIDTH_IN,WIDTH_IN,16,WIDTH_IN+15,48,'0',"DIRECT","DIRECT",'0','0')
	port map(i_clk,dsp_a_in_q(0),dsp_d_in_q(0),dsp_b_in(0),dsp_c_q,(others=>'0'),(others=>'0'),(others=>'0'),open,open,dsp_pcout_q(0),open);

    hbf_nth : for i in 1 to TAP_ORDER/2-1 generate	
		gen_i : lib_adder_multi_c_pcin_dsp2 generic map(WIDTH_IN,WIDTH_IN,16,48,48,'1',"DIRECT","DIRECT",'0','0')
		port map(i_clk,dsp_a_in_i(i),dsp_d_in_i(i),dsp_b_in(i),(others=>'0'),(others=>'0'),(others=>'0'),dsp_pcout_i(i-1),open,open,dsp_pcout_i(i),dsp_p_i(i));
		
		gen_q : lib_adder_multi_c_pcin_dsp2 generic map(WIDTH_IN,WIDTH_IN,16,48,48,'1',"DIRECT","DIRECT",'0','0')
		port map(i_clk,dsp_a_in_q(i),dsp_d_in_q(i),dsp_b_in(i),(others=>'0'),(others=>'0'),(others=>'0'),dsp_pcout_q(i-1),open,open,dsp_pcout_q(i),dsp_p_q(i));
	end generate hbf_nth;

    -- round up
    -- 1 clk
    process(i_clk)
	begin
		if (rising_edge(i_clk)) then
			if ((dsp_p_i(TAP_ORDER/2-1)(WIDTH_OUT+BINARY_POINT) = '1') and (dsp_p_i(TAP_ORDER/2-1)(BINARY_POINT downto 0) = round(BINARY_POINT downto 0))) then
				dsp_p_i_round				<=	dsp_p_i(TAP_ORDER/2-1);
			else
                dsp_p_i_round				<=	dsp_p_i(TAP_ORDER/2-1) + round;
			end if;

            if ((dsp_p_q(TAP_ORDER/2-1)(WIDTH_OUT+BINARY_POINT) = '1') and (dsp_p_q(TAP_ORDER/2-1)(BINARY_POINT downto 0) = round(BINARY_POINT downto 0))) then
				dsp_p_q_round				<=	dsp_p_q(TAP_ORDER/2-1);
			else
                dsp_p_q_round				<=	dsp_p_q(TAP_ORDER/2-1) + round;
			end if;
		end if;
	end process;

    -- 1 clk
    process(i_clk)
	begin
		if (rising_edge(i_clk)) then			
			o_data_i					<=  dsp_p_i_round(WIDTH_OUT+BINARY_POINT downto BINARY_POINT+1);
			o_data_q					<=  dsp_p_q_round(WIDTH_OUT+BINARY_POINT downto BINARY_POINT+1);			
		end if;
	end process;

end Behavioral;