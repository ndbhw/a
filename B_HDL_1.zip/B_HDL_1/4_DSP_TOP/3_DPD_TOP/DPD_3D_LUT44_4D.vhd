library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity DPD_3D_LUT44_4D is
generic(
    DEVICE                      : string  := "ULTRASCALE";

    DDR_DLY                     : integer :=           2 ;
    LUT_4D_NUM                  : integer :=           2 ;

    SIGNAL_Q_POINT              : integer :=          15 ;
    LUT_4D_Q_POINT              : integer :=          12 ;
    SUM_Q_POINT                 : integer :=          22
    );
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
   
    LUT_DATA_VLD                : in  std_logic;
    LUT_I_IN                    : in  std_logic_array16(LUT_4D_NUM-1 downto 0); 
    LUT_Q_IN                    : in  std_logic_array16(LUT_4D_NUM-1 downto 0); 

    MAG_IN                      : in  std_logic_vector(14 downto 0); 
    DATA_I_IN                   : in  std_logic_vector(15 downto 0); 
    DATA_Q_IN                   : in  std_logic_vector(15 downto 0); 

    DDR_I_OUT                   : out std_logic_array31(1 downto 0); 
    DDR_Q_OUT                   : out std_logic_array31(1 downto 0) 
    );
end DPD_3D_LUT44_4D;

architecture arc_DPD_3D_LUT44_4D of DPD_3D_LUT44_4D is

constant FRAC_BIT_NUM           : integer := SIGNAL_Q_POINT + SIGNAL_Q_POINT -4 + LUT_4D_Q_POINT - SUM_Q_POINT;
constant one_18b                : std_logic_vector(17 downto 0) := "000000000000000001";

component CMULT_FUNC is
generic(
    DEVICE                      : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    OPTIMIZATION                : string  :=        "DSP"; -- "DSP" : 3 DSPs, 3 Adders, 2 PreAdders, "LUT" : 4 DSPs, 2 Adders, HOVS1 Only
    HOVS                        : natural :=           1 ;
    
    RND_EN                      : boolean :=        TRUE ;
    RND_BIT                     : natural :=          15 ;

    INPUT_PIPELINING            : boolean :=        TRUE ;
    IN_A_BITWIDTH               : natural :=          16 ;  -- (max ~27)
    IN_B_BITWIDTH               : natural :=          16 ;  -- (max ~17 when "DSP")
    OUT_BITWIDTH                : natural :=          16
    );
port(
    CLK                         : in  std_logic;
    
    DATA_VLD_IN                 : in  std_logic;
    ADATA_I_IN                  : in  std_logic_vector(IN_A_BITWIDTH-1 downto 0);
    ADATA_Q_IN                  : in  std_logic_vector(IN_A_BITWIDTH-1 downto 0);

    BDATA_I_IN                  : in  std_logic_vector(IN_B_BITWIDTH-1 downto 0);
    BDATA_Q_IN                  : in  std_logic_vector(IN_B_BITWIDTH-1 downto 0);

    DATA_VLD_OUT                : out std_logic;
    DATA_I_OUT                  : out std_logic_vector(OUT_BITWIDTH+RND_BIT-1 downto RND_BIT);
    DATA_Q_OUT                  : out std_logic_vector(OUT_BITWIDTH+RND_BIT-1 downto RND_BIT)
    );
end component;

component DSP48E_MULT is
generic(
    DEVICE                      : string  := "ULTRASCALE";
    DSP48_MODECTRL              : boolean :=       FALSE ;
    DSP48_PREADDER_USE          : boolean :=        TRUE ;
    DSP48_PREADDER_MODE         : string  :=        "ADD"; -- "ADD" or "SUB" 
    DSP48_PCIN_USE              : boolean :=       FALSE ;
    DSP48_PCOUT_USE             : boolean :=       FALSE ;

    A_nREG                      : integer :=           2 ; -- 0, 1, 2
    B_nREG                      : integer :=           2 ; -- 0, 1, 2

    C_EN                        : boolean :=        TRUE ; -- RND ENable
    RND_SYMMETRY                : boolean :=       FALSE 
    );
port(
    CLK                         : in  std_logic;

    ALUMODE_IN                  : in  std_logic_vector( 3 downto 0);
    OPMODE_IN                   : in  std_logic_vector( 8 downto 0);

    C_IN                        : in  std_logic_vector(47 downto 0); -- RND Value
    A_IN                        : in  std_logic_vector(29 downto 0);
    D_IN                        : in  std_logic_vector(26 downto 0);
    B_IN                        : in  std_logic_vector(17 downto 0);

    P_CIN                       : in  std_logic_vector(47 downto 0);
    P_COUT                      : out std_logic_vector(47 downto 0);

    P_OUT                       : out std_logic_vector(47 downto 0);
    CRRY_OUT                    : out std_logic
    );
end component;

component SAT_SIGN is
generic(
    HS_MODE                     : boolean := TRUE;
    INPUT_BIT                   : natural;
    OUTPUT_BIT                  : natural 
    );
port( 
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    DATA_IN                     : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT                    : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

component SRL16E_DLY is
generic(
    DEVICE       : string  := "ULTRASCALE";
    HS_MODE      : boolean :=       FALSE ;

    BIT_WIDTH    : natural;            -- 2 to 64
    DELAY_NUM    : natural
    );
port(
    CLK          : in  std_logic;

    DATA_IN      : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT     : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end component;

signal data_i_sh                : std_logic_array16(DDR_DLY-1 downto 0) := (others => (others => '0')); 
signal data_q_sh                : std_logic_array16(DDR_DLY-1 downto 0) := (others => (others => '0')); 

-- DDR#0
signal conj_data_i              : std_logic_vector(15 downto 0) := (others => '0'); 
signal conj_data_q              : std_logic_vector(15 downto 0) := (others => '0'); 

signal data_i                   : std_logic_vector(15 downto 0) := (others => '0'); 
signal data_q                   : std_logic_vector(15 downto 0) := (others => '0'); 

signal lut0_i                   : std_logic_vector(15 downto 0) := (others => '0'); 
signal lut0_q                   : std_logic_vector(15 downto 0) := (others => '0'); 

-- new

signal conj_data_q_d1           : std_logic_vector(15 downto 0) := (others=>'0');
signal conj_data_q_d2           : std_logic_vector(15 downto 0) := (others=>'0');

signal mult33_p                 : std_logic_vector(32 downto 0) := (others=>'0');
signal mult33_a                 : std_logic_vector(32 downto 0) := (others=>'0');
signal mult33_b                 : std_logic_vector(32 downto 0) := (others=>'0');
signal a_tmp33_i                : std_logic_vector(32 downto 0) := (others=>'0');
signal a_tmp33_q                : std_logic_vector(32 downto 0) := (others=>'0');
signal a_tmp33_i_26             : std_logic_vector(25 downto 0) := (others=>'0');
signal a_tmp33_q_26             : std_logic_vector(25 downto 0) := (others=>'0');
signal b_tmp33_i                : std_logic_vector(32 downto 0) := (others=>'0');
signal b_tmp33_q                : std_logic_vector(32 downto 0) := (others=>'0');
signal b_tmp33_i_26             : std_logic_vector(25 downto 0) := (others=>'0');
signal b_tmp33_q_26             : std_logic_vector(25 downto 0) := (others=>'0');
signal mult_a1_0_i              : std_logic_vector(25 downto 0) := (others=>'0');
signal mult_a1_0_q              : std_logic_vector(25 downto 0) := (others=>'0');
signal conj_mult_a1_0_q         : std_logic_vector(25 downto 0) := (others=>'0');
signal mult_0_1_i               : std_logic_vector(25 downto 0) := (others=>'0');
signal mult_0_1_q               : std_logic_vector(25 downto 0) := (others=>'0');
signal conj_mult_0_1_q          : std_logic_vector(25 downto 0) := (others=>'0');
-- signal mult_0_1_i_27            : std_logic_vector(26 downto 0) := (others=>'0');
-- signal mult_0_1_q_27            : std_logic_vector(26 downto 0) := (others=>'0');
signal mag15_d_27               : std_logic_vector(26 downto 0) := (others=>'0');
signal mag15_b_18               : std_logic_vector(17 downto 0) := (others=>'0');
signal mag_pwr_48               : std_logic_vector(47 downto 0) := (others=>'0');
signal mag_pwr_26               : std_logic_vector(25 downto 0) := (others=>'0');
signal mag_pwr_27               : std_logic_vector(26 downto 0) := (others=>'0');
signal mag_pwr_26_d             : std_logic_vector(25 downto 0) := (others=>'0');
signal mag_pwr_27_d             : std_logic_vector(26 downto 0) := (others=>'0');

signal lut_0_i_d2               : std_logic_vector(15 downto 0) := (others=>'0');
signal lut_0_q_d2               : std_logic_vector(15 downto 0) := (others=>'0');
signal lut_0_i_d2_18            : std_logic_vector(17 downto 0) := (others=>'0');
signal lut_0_q_d2_18            : std_logic_vector(17 downto 0) := (others=>'0');
signal res_0_i_48               : std_logic_vector(47 downto 0) := (others=>'0');
signal res_0_q_48               : std_logic_vector(47 downto 0) := (others=>'0');
signal res_1_i_48               : std_logic_vector(47 downto 0) := (others=>'0');
signal res_1_q_48               : std_logic_vector(47 downto 0) := (others=>'0');

signal lut_out_0_1_0_0_i        : std_logic_vector(30 downto 0) := (others=>'0');
signal lut_out_0_1_0_0_q        : std_logic_vector(30 downto 0) := (others=>'0');
signal lut_1_i               : std_logic_vector(15 downto 0) := (others=>'0');
signal lut_1_q               : std_logic_vector(15 downto 0) := (others=>'0');
signal lut_2_i               : std_logic_vector(15 downto 0) := (others=>'0');
signal lut_2_q               : std_logic_vector(15 downto 0) := (others=>'0');
signal lut_3_i               : std_logic_vector(15 downto 0) := (others=>'0');
signal lut_3_q               : std_logic_vector(15 downto 0) := (others=>'0');
signal lut_4_i               : std_logic_vector(15 downto 0) := (others=>'0');
signal lut_4_q               : std_logic_vector(15 downto 0) := (others=>'0');
signal lut_5_i               : std_logic_vector(15 downto 0) := (others=>'0');
signal lut_5_q               : std_logic_vector(15 downto 0) := (others=>'0');
signal lut_5_i_18            : std_logic_vector(17 downto 0) := (others=>'0');
signal lut_5_q_18            : std_logic_vector(17 downto 0) := (others=>'0');
signal lut_6_i               : std_logic_vector(15 downto 0) := (others=>'0');
signal lut_6_q               : std_logic_vector(15 downto 0) := (others=>'0');
signal lut_1_i_c_48            : std_logic_vector(47 downto 0);
signal lut_2_i_a_30            : std_logic_vector(29 downto 0);
signal lut_3_i_d_26            : std_logic_vector(26 downto 0);
signal lut_1_q_c_48            : std_logic_vector(47 downto 0);
signal lut_2_q_a_30            : std_logic_vector(29 downto 0);
signal lut_3_q_d_26            : std_logic_vector(26 downto 0);
signal lut_123_i_48            : std_logic_vector(47 downto 0);
signal lut_123_q_48            : std_logic_vector(47 downto 0);
signal lut_123_i_18            : std_logic_vector(17 downto 0);
signal lut_123_q_18            : std_logic_vector(17 downto 0);
signal c_tmp_i_48              : std_logic_vector(47 downto 0);
signal c_tmp_q_48              : std_logic_vector(47 downto 0);
signal d_tmp_i_48              : std_logic_vector(47 downto 0);
signal d_tmp_q_48              : std_logic_vector(47 downto 0);
signal e_tmp_i_48              : std_logic_vector(47 downto 0);
signal e_tmp_q_48              : std_logic_vector(47 downto 0);
signal lut_out_0_x_0_1_i       : std_logic_vector(30 downto 0);
signal lut_out_0_x_0_1_q       : std_logic_vector(30 downto 0);
signal lut_out_0_1_0_A1_i      : std_logic_vector(30 downto 0);
signal lut_out_0_1_0_A1_q      : std_logic_vector(30 downto 0);
signal lut_out_0_0_1_1_i       : std_logic_vector(30 downto 0);
signal lut_out_0_0_1_1_q       : std_logic_vector(30 downto 0);
signal lut_out_1_0_1_0_i       : std_logic_vector(30 downto 0);
signal lut_out_1_0_1_0_q       : std_logic_vector(30 downto 0);
signal mag_dly                 : std_logic_vector(14 downto 0);


begin

    P_DATA_SH : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            data_i_sh <= data_i_sh(DDR_DLY-2 downto 0) & DATA_I_IN; 
            data_q_sh <= data_q_sh(DDR_DLY-2 downto 0) & DATA_Q_IN; 
        end if;
    end process;

    -------------------------------------------
    -- DDR#0 
    -------------------------------------------
    P_Conj : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            conj_data_q_d1    <= (not data_q) + '1'; 
            conj_data_q_d2    <= conj_data_q_d1;

            data_i            <= DATA_I_IN;  
            data_q            <= DATA_Q_IN;  

            mag_pwr_26_d      <= mag_pwr_26;

        end if;
    end process;

    U_MAG_DLY_Q   : SRL16E_DLY generic map(DEVICE, TRUE, 15, 3) port map (CLK, MAG_IN, mag_dly);
    U_LUT_DLY_0_I : SRL16E_DLY generic map(DEVICE, TRUE, 16, 6) port map (CLK, LUT_I_IN(0), lut_0_i_d2);
    U_LUT_DLY_0_Q : SRL16E_DLY generic map(DEVICE, TRUE, 16, 6) port map (CLK, LUT_Q_IN(0), lut_0_q_d2);
    U_LUT_DLY_1_I : SRL16E_DLY generic map(DEVICE, TRUE, 16, 2) port map (CLK, LUT_I_IN(1), lut_1_i);
    U_LUT_DLY_1_Q : SRL16E_DLY generic map(DEVICE, TRUE, 16, 2) port map (CLK, LUT_Q_IN(1), lut_1_q);
    lut_2_i          <=LUT_I_IN(2);
    lut_2_q          <=LUT_Q_IN(2);
    lut_3_i          <=LUT_I_IN(3);
    lut_3_q          <=LUT_Q_IN(3);
    lut_1_i_c_48     <= sign_extension(lut_1_i, 48);
    lut_2_i_a_30     <= sign_extension(lut_2_i, 30);
    lut_3_i_d_26     <= sign_extension(lut_3_i, 27);
    lut_1_q_c_48     <= sign_extension(lut_1_q, 48);
    lut_2_q_a_30     <= sign_extension(lut_2_q, 30);
    lut_3_q_d_26     <= sign_extension(lut_3_q, 27);
    U_LUT_DLY_4_I : SRL16E_DLY generic map(DEVICE, TRUE, 16, 4) port map (CLK, LUT_I_IN(4), lut_4_i);
    U_LUT_DLY_4_Q : SRL16E_DLY generic map(DEVICE, TRUE, 16, 4) port map (CLK, LUT_Q_IN(4), lut_4_q);
    U_LUT_DLY_5_I : SRL16E_DLY generic map(DEVICE, TRUE, 16, 6) port map (CLK, LUT_I_IN(5), lut_5_i);
    U_LUT_DLY_5_Q : SRL16E_DLY generic map(DEVICE, TRUE, 16, 6) port map (CLK, LUT_Q_IN(5), lut_5_q);
    U_LUT_DLY_6_I : SRL16E_DLY generic map(DEVICE, TRUE, 16, 4) port map (CLK, LUT_I_IN(6), lut_6_i);
    U_LUT_DLY_6_Q : SRL16E_DLY generic map(DEVICE, TRUE, 16, 4) port map (CLK, LUT_Q_IN(6), lut_6_q);
--------------------------------------------------------------------------------------------------------------------------------------
    -- complex multiplication : tmp33 = s[A1] * s'[0]
    -- type 1 MULT : 8clk
    U_CMULT_00 : CMULT_FUNC generic map(DEVICE, "DSP", 1, FALSE, 0, FALSE, 16,16, 33) port map(CLK, '1', data_i_sh(0), data_q_sh(0), data_i_sh(1), conj_data_q_d1, open, a_tmp33_i, a_tmp33_q);  
    U_SAT_00_I : SAT_SIGN generic map(TRUE, 29, 26) port map(RST, CLK, a_tmp33_i(32 downto 4), a_tmp33_i_26);
    U_SAT_00_Q : SAT_SIGN generic map(TRUE, 29, 26) port map(RST, CLK, a_tmp33_q(32 downto 4), a_tmp33_q_26);
    U_DLY_2_I : SRL16E_DLY generic map(DEVICE, TRUE, 26, 2) port map (CLK, a_tmp33_i_26, mult_a1_0_i);
    U_DLY_2_Q : SRL16E_DLY generic map(DEVICE, TRUE, 26, 2) port map (CLK, a_tmp33_q_26, mult_a1_0_q);
    -- type 2 MULT : 8clk
    U_CMULT_01 : CMULT_FUNC generic map(DEVICE, "DSP", 1, FALSE, 0, FALSE, 16,16, 33) port map(CLK, '1', data_i_sh(1), data_q_sh(1), data_i_sh(2), conj_data_q_d2, open, b_tmp33_i, b_tmp33_q);  
    U_SAT_01_I : SAT_SIGN generic map(TRUE, 29, 26) port map(RST, CLK, b_tmp33_i(32 downto 4), b_tmp33_i_26);
    U_SAT_01_Q : SAT_SIGN generic map(TRUE, 29, 26) port map(RST, CLK, b_tmp33_q(32 downto 4), b_tmp33_q_26);
    U_DLY_3_I : SRL16E_DLY generic map(DEVICE, TRUE, 26, 2) port map (CLK, b_tmp33_i_26, mult_0_1_i);
    U_DLY_3_Q : SRL16E_DLY generic map(DEVICE, TRUE, 26, 2) port map (CLK, b_tmp33_q_26, mult_0_1_q);

    -- Type 1 : (tmp46[s46.42] = Pwr[u30.30] * LUT[s16.12] ) >> 20 : lut_out[c26.22]
    -- 0 1 0 0 (Type1)
    mag15_b_18      <= "000" & mag_dly;
    mag15_d_27      <= x"000" & mag_dly;
    U_MAG_SQR : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),mag15_d_27,mag15_b_18,(others=>'0'),open,mag_pwr_48,open);
    mag_pwr_26      <= mag_pwr_48(29 downto 4);
    
    mag_pwr_27      <= '0' & mag_pwr_26;
    lut_0_i_d2_18   <= sign_extension(lut_0_i_d2, 18);
    lut_0_q_d2_18   <= sign_extension(lut_0_q_d2, 18);
    U_MULT_00_I : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),mag_pwr_27,lut_0_i_d2_18,(others=>'0'),open,res_0_i_48,open);
    U_MULT_00_Q : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),mag_pwr_27,lut_0_q_d2_18,(others=>'0'),open,res_0_q_48,open);

    -- type 2
    U_MULT_01_I : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",TRUE,FALSE,1,2,TRUE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),lut_1_i_c_48,lut_2_i_a_30,lut_3_i_d_26,one_18b,(others=>'0'),open,lut_123_i_48,open); -- add
    U_MULT_01_Q : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",TRUE,FALSE,1,2,TRUE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),lut_1_q_c_48,lut_2_q_a_30,lut_3_q_d_26,one_18b,(others=>'0'),open,lut_123_q_48,open); -- add
    lut_123_i_18    <= lut_123_i_48(17 downto 0);
    lut_123_q_18    <= lut_123_q_48(17 downto 0);
    U_CMULT_02 : CMULT_FUNC generic map(DEVICE, "DSP", 1, FALSE, 0, FALSE, 26,18, 48) port map(CLK, '1', mult_0_1_i, mult_0_1_q, lut_123_i_18, lut_123_q_18, open, c_tmp_i_48, c_tmp_q_48); 

    -- conj(mult_a1_0) * lut41(lut4) ; -- 6 clk
    conj_mult_a1_0_q  <= not mult_a1_0_q + '1';
    U_CMULT_03 : CMULT_FUNC generic map(DEVICE, "DSP", 1, FALSE, 0, FALSE, 26,16, 48) port map(CLK, '1', mult_a1_0_i, conj_mult_a1_0_q, lut_4_i, lut_4_q, open, d_tmp_i_48, d_tmp_q_48); 

    -- type 1 -- 4 clk
    mag_pwr_27_d    <= '0' & mag_pwr_26_d;
    lut_5_i_18      <= sign_extension(lut_5_i, 18);
    lut_5_q_18      <= sign_extension(lut_5_q, 18);
    U_MULT_02_I : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),mag_pwr_27_d,lut_5_i_18,(others=>'0'),open,res_1_i_48,open);
    U_MULT_02_Q : DSP48E_MULT  generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,1,2,FALSE,FALSE) port map(CLK,(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),mag_pwr_27_d,lut_5_q_18,(others=>'0'),open,res_1_q_48,open);

    -- conj(mult_a1_0) * lut41(lut6) ;  -- 6 clk
    conj_mult_0_1_q  <= not mult_0_1_q + '1';
    U_CMULT_04 : CMULT_FUNC generic map(DEVICE, "DSP", 1, FALSE, 0, FALSE, 26,16, 48) port map(CLK, '1', mult_0_1_i, conj_mult_0_1_q, lut_6_i, lut_6_q, open, e_tmp_i_48, e_tmp_q_48); 
   
    process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            lut_out_0_1_0_0_i     <= res_0_i_48(FRAC_BIT_NUM+31-1 downto FRAC_BIT_NUM);
            lut_out_0_1_0_0_q     <= res_0_q_48(FRAC_BIT_NUM+31-1 downto FRAC_BIT_NUM);
            lut_out_0_x_0_1_i     <= c_tmp_i_48(FRAC_BIT_NUM+31-1 downto FRAC_BIT_NUM);
            lut_out_0_x_0_1_q     <= c_tmp_q_48(FRAC_BIT_NUM+31-1 downto FRAC_BIT_NUM);
            lut_out_0_1_0_A1_i    <= d_tmp_i_48(FRAC_BIT_NUM+31-1 downto FRAC_BIT_NUM);
            lut_out_0_1_0_A1_q    <= d_tmp_q_48(FRAC_BIT_NUM+31-1 downto FRAC_BIT_NUM);
            lut_out_0_0_1_1_i     <= res_1_i_48(FRAC_BIT_NUM+31-1 downto FRAC_BIT_NUM);
            lut_out_0_0_1_1_q     <= res_1_q_48(FRAC_BIT_NUM+31-1 downto FRAC_BIT_NUM);

            -- 4D LUTs for FIR 0 Tap
            DDR_I_OUT(0)          <= (lut_out_0_1_0_0_i + lut_out_0_x_0_1_i + lut_out_0_1_0_A1_i + lut_out_0_0_1_1_i);
            DDR_Q_OUT(0)          <= (lut_out_0_1_0_0_q + lut_out_0_x_0_1_q + lut_out_0_1_0_A1_q + lut_out_0_0_1_1_q);
        end if;
    end process;
    
    -- 4D LUTs for FIR 1 Tap -- 1 adv than DDR(0)
    lut_out_1_0_1_0_i     <= e_tmp_i_48(FRAC_BIT_NUM+31-1 downto FRAC_BIT_NUM);
    lut_out_1_0_1_0_q     <= e_tmp_q_48(FRAC_BIT_NUM+31-1 downto FRAC_BIT_NUM);
    DDR_I_OUT(1)          <= lut_out_1_0_1_0_i;
    DDR_Q_OUT(1)          <= lut_out_1_0_1_0_q;

end arc_DPD_3D_LUT44_4D;
