library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;

entity CORDIC_DEMAPPER  is
generic(
    HS_MODE    : boolean :=  TRUE  -- High Speed Mode (Operating Clock > 307.2MHz)
    );
port(
    RST        : in  std_logic;
    CLK        : in  std_logic; -- 122.88MHz

    SIN_IN     : in  std_logic_vector(13 downto 0); 
    COS_IN     : in  std_logic_vector(13 downto 0); 
    I_SIGN_IN  : in  std_logic; 
    Q_SIGN_IN  : in  std_logic; 
    IQ_SWAP_IN : in  std_logic;   

    SIN_OUT    : out std_logic_vector(13 downto 0); 
    COS_OUT    : out std_logic_vector(13 downto 0)
    );
end CORDIC_DEMAPPER;

architecture arc_CORDIC_DEMAPPER of CORDIC_DEMAPPER is

signal lut_sin_out  : std_logic_vector(13 downto 0); 
signal lut_cos_out  : std_logic_vector(13 downto 0);
signal swap_sin_out : std_logic_vector(13 downto 0); 
signal swap_cos_out : std_logic_vector(13 downto 0);
signal sign_i       : std_logic; 
signal sign_q       : std_logic; 
signal sin          : std_logic_vector(13 downto 0); 
signal cos          : std_logic_vector(13 downto 0);

signal sin_d1       : std_logic_vector(13 downto 0); 
signal cos_d1       : std_logic_vector(13 downto 0);
      
begin

  -- CORDIC DeMapper
-- The mapper module maps the input data to the first half of the first quadrant (in other words, 
-- the region from 0 to ��/4). This is accomplished by inverting the I and Q components if they are
-- negative followed by a swapping of the I and Q components if Q is greater than or equal to I.
-- The mapped I and Q signals then pass through a series of CORDIC stages to compute the
-- magnitude, sine, and cosine components. The demapper module swaps and/or negates the
-- sine and cosine components to undo the effect of the mapping that was performed in the
-- mapper module. The mapping and demapping is generally done to reduce memory requirements. 
      
    lut_sin_out <= SIN_IN;
    lut_cos_out <= COS_IN;

    G_Normal_Operation : if (HS_MODE = FALSE) generate begin
        -- Demapping SWAP I/Q 
        -- 1st Clock 
        P_Demapping_Swap_NM : process(RST, CLK) begin
            if (RST = '1') then 
                swap_sin_out <= (others => '0');
                swap_cos_out <= (others => '0');  
            elsif (CLK'event) and (CLK = '1') then 
                if (IQ_SWAP_IN = '1') then
                    swap_sin_out <= lut_cos_out;
                    swap_cos_out <= lut_sin_out;
                else
                    swap_sin_out <= lut_sin_out;
                    swap_cos_out <= lut_cos_out;
                end if;
            end if;
        end process;

        -- Latch SWAP_IP
        -- 1st Clock
        P_Latch_Swap_IP_NM : process(RST, CLK) begin
            if (RST = '1') then 
                sign_i <= '0';
                sign_q <= '0';
            elsif (CLK'event) and (CLK = '1') then 
                sign_i <= I_SIGN_IN;
                sign_q <= Q_SIGN_IN;
            end if;
        end process;

        -- 2nd Clock
        P_SIN_COS_Twos_Complement_NM : process(RST, CLK) begin
            if (RST = '1') then
                sin    <= (others => '0');          
                cos    <= (others => '0');         
                sin_d1 <= (others => '0');       
                cos_d1 <= (others => '0');      
      
            elsif (CLK'event) and (CLK = '1') then
                if (sign_q = '1') then
                    sin <= (not swap_sin_out) + '1' ; -- 2's compliment
                else                              
                    sin <= swap_sin_out;          
                end if;                           
                                                  
                if (sign_i = '1') then            
                    cos <= (not swap_cos_out) + '1' ; -- 2's compliment
                else
                    cos <= swap_cos_out;
                end if;

                sin_d1 <= sin;       
                cos_d1 <= cos;      
            end if;
        end process;
    end generate;

    G_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
        -- Demapping SWAP I/Q 
        -- 1st Clock 
        P_Demapping_Swap_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then 
                if (IQ_SWAP_IN = '1') then
                    swap_sin_out <= lut_cos_out;
                    swap_cos_out <= lut_sin_out;
                else
                    swap_sin_out <= lut_sin_out;
                    swap_cos_out <= lut_cos_out;
                end if;
            end if;
        end process;

        -- Latch SWAP_IP
        -- 1st Clock
        P_Latch_Swap_IP_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then 
                sign_i <= I_SIGN_IN;
                sign_q <= Q_SIGN_IN;
            end if;
        end process;

        -- 2nd Clock
        P_SIN_COS_Twos_Complement_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (sign_q = '1') then
                    sin <= (not swap_sin_out) + '1' ; -- 2's compliment
                else                              
                    sin <= swap_sin_out;          
                end if;                           
                                                  
                if (sign_i = '1') then            
                    cos <= (not swap_cos_out) + '1' ; -- 2's compliment
                else
                    cos <= swap_cos_out;
                end if;
                sin_d1 <= sin;       
                cos_d1 <= cos;      
            end if;
        end process;
    end generate;

    SIN_OUT <= sin_d1; 
    COS_OUT <= cos_d1;

end arc_CORDIC_DEMAPPER;

