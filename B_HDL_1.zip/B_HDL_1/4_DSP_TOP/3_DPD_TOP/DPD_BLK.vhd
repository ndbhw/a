library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

-- [Relation between DPD_LUT_NUM with DPD_TAP_NUM] 
-- -----------------------------
-- | DPD_LUT_NUM | DPD_TAP_NUM |
-- -----------------------------
-- |      4      |      2      |
-- -----------------------------
-- |      8      |      4      |
-- -----------------------------
-- |     16      |      8      |
-- -----------------------------
-- |     17      |     10      |
-- -----------------------------
-- |     32      |     14      |
-- -----------------------------
-- |     37      |     19      |
-- -----------------------------

entity DPD_BLK is
generic(
    DEVICE                     : string  := "ULTRASCALE";                      -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
   
    TX_ANT_NUM                 : natural :=           4 ;
    HOVS                       : natural :=           1 ; 

    DPD_CORE_IMPLEMENTATION    : boolean :=        TRUE ;
    DPD_CORE_LUT_OPTIMIZED     : boolean :=       FALSE ;
    DPD_CORE_LUT_MEM_DEPTH     : string  :=       "FULL";                      -- "FULL": 32x512x2, "HALF": 32x256x2
    DPD_CORE_LUT_RBTEST        : boolean :=        TRUE ;
    DPD_CORE_QPOINT_SEL        : boolean :=       FALSE ;
    DPD_CORE_LUT_DIMENSION     : string  :=         "2D";                      -- "2D" or "3D"
    DPD_CORE_LUT_NUM           : natural :=          32 ;
    DPD_CORE_TAP_NUM           : natural :=          14 ; 
    DPD_CORE_RND_BIT           : natural :=          13 ; 

    DPD_HC_IMPLEMENTATION      : boolean :=        TRUE ;  
    DPD_ATT_IMPLEMENTATION     : boolean :=        TRUE ;  

    DPD_FILTER_IMPLEMENTATION  : boolean :=        TRUE ;  
    DPD_FILTER_COEF_FIX        : boolean :=        TRUE ;        
    DPD_FILTER_COEF_NUM        : natural :=        39   ;
    DPD_FILTER_RND_BIT         : natural :=        15
    );
port(
    RST_DPD                    : in  std_logic;                                -- DPD Reset , Active High
    CLK_DPD                    : in  std_logic;                                -- DPD Operation Clock

    DPD_BLK_VLD_IN             : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Block Input Sample Valid
    DPD_BLK_I_IN               : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- DPD Block Input I Sample 
    DPD_BLK_Q_IN               : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- DPD Block Input Q Sample 

    DPD_HC_VLD_OUT             : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Output Sample Valid
    DPD_HC_I_OUT               : out std_logic_array16(TX_ANT_NUM-1 downto 0); -- DPD HC Output I Sample 
    DPD_HC_Q_OUT               : out std_logic_array16(TX_ANT_NUM-1 downto 0); -- DPD HC Output Q Sample 

    DPD_BLK_VLD_OUT            : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Block Output Sample Valid
    DPD_BLK_I_OUT              : out std_logic_array16(TX_ANT_NUM-1 downto 0); -- DPD Block Output I Sample 
    DPD_BLK_Q_OUT              : out std_logic_array16(TX_ANT_NUM-1 downto 0); -- DPD Block Output Q Sample 

    DPD_CORE_BYPASS_IN         : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Core Bypass

    DPD_GAIN_INDEX_IN          : in  std_logic_array2( TX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
    DPD_QPOINT_SEL_IN          : in  std_logic_array2( TX_ANT_NUM-1 downto 0); -- DPD Core Binary Point Selection

    RST_CPU                    : in  std_logic;                                -- CPU Reset , Active High
    CLK_CPU                    : in  std_logic;                                -- CPU Operation Clock

    DPD_LUT_RB_TEST_EN_IN      : in  std_logic;                                -- LUT Read Back Test

    DPD_LUT_SWITCH_CDC_STRB_IN : in  std_logic;                                -- LUT Switch Control Register CDC Strobe
    DPD_LUT_INPUT_SWITCH_IN    : in  std_logic_vector(19 downto 0);            -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN   : in  std_logic_vector(19 downto 0);            -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN       : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN            : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- LUT Write Enable
    DPD_LUT_RDEN_IN            : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- LUT Read  Enable
    DPD_LUT_ADDR_IN            : in  std_logic_array15(TX_ANT_NUM-1 downto 0); -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN           : in  std_logic_array32(TX_ANT_NUM-1 downto 0); -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT          : out std_logic_array32(TX_ANT_NUM-1 downto 0); -- LUT Write IQ : I[31:16]/Q[15:0]

    DPD_HC_EN_IN               : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Hard-Clipper Enable
    DPD_HC_FLAG_OUT            : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Hard-Clipping Flag
    DPD_HC_TRSHD_IN            : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- DPD Hard-Clipper Threshold Value

    DL_ATTEN_VALUE_IN          : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- DL Attenuator Value

    FILTER_BYPASS_IN           : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PA Protection Filter Bypass
    FILTER_COEF_WR_EN_IN       : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- coefficient write enable(indirect)
    FILTER_COEF_RD_EN_IN       : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- coefficient read  enable(indirect)
    FILTER_COEF_WR_DN_IN       : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- coefficient write done(indirect)
    FILTER_COEF_ADDR_IN        : in  std_logic_vector( 7 downto 0);            -- coefficient write addr:tas
    FILTER_COEF_WR_DATA_IN     : in  std_logic_vector(15 downto 0);            -- coefficient write data(indirect) 
    FILTER_COEF_RD_DATA_OUT    : out std_logic_vector(15 downto 0)             -- coefficient read  data(indirect) 
    );
end DPD_BLK;

architecture arc_DPD_BLK of DPD_BLK is

--*****************************
-- Components
--*****************************

component DPD_CORE is
generic(
    DEVICE                     : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
   
    TX_ANT_NUM                 : natural :=           4 ;
    HOVS                       : natural :=           1 ; 

    DPD_LUT_OPTIMIZED          : boolean :=       FALSE ;
    DPD_LUT_MEM_DEPTH          : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    DPD_LUT_RBTEST             : boolean :=        TRUE ;
    DPD_CORE_QPOINT_SEL        : boolean :=       FALSE ;
    DPD_CORE_LUT_DIMENSION     : string  :=         "2D"; -- "2D" or "3D"
    DPD_CORE_LUT_NUM           : natural :=          16 ;
    DPD_CORE_TAP_NUM           : natural :=           8 ; 
    DPD_CORE_RND_BIT           : natural :=          13 
    );
port(
    RST_DPD                    : in  std_logic;
    CLK_DPD                    : in  std_logic;

    DPD_CORE_VLD_IN            : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- DPD Core Input Sample Valid
    DPD_CORE_I_IN              : in  std_logic_array16(TX_ANT_NUM-1 downto 0);        -- DPD Core Input I Sample 
    DPD_CORE_Q_IN              : in  std_logic_array16(TX_ANT_NUM-1 downto 0);        -- DPD Core Input Q Sample 

    DPD_CORE_VLD_OUT           : out std_logic_vector( TX_ANT_NUM-1 downto 0);        -- DPD Core Output Sample Valid
    DPD_CORE_I_OUT             : out std_logic_array16(TX_ANT_NUM-1 downto 0);        -- DPD Core Output I Sample 
    DPD_CORE_Q_OUT             : out std_logic_array16(TX_ANT_NUM-1 downto 0);        -- DPD Core Output Q Sample 

    DPD_CORE_BYPASS_IN         : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- DPD Core Bypass

    DPD_GAIN_INDEX_IN          : in  std_logic_array2( TX_ANT_NUM-1 downto 0);        -- Input Signal Gain, x1/x2/x4
    DPD_QPOINT_SEL_IN          : in  std_logic_array2( TX_ANT_NUM-1 downto 0);        -- DPD Core Binary Point Selection

    RST_CPU                    : in  std_logic;
    CLK_CPU                    : in  std_logic;

    DPD_LUT_RB_TEST_EN_IN      : in  std_logic;                                       -- LUT Read Back Test

    DPD_LUT_SWITCH_CDC_STRB_IN : in  std_logic;                                       -- LUT Switch Control Register CDC Strobe
    DPD_LUT_INPUT_SWITCH_IN    : in  std_logic_vector(19 downto 0);                   -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN   : in  std_logic_vector(19 downto 0);                   -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN       : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN            : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_RDEN_IN            : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Read  Enable
    DPD_LUT_ADDR_IN            : in  std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN           : in  std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT          : out std_logic_array32(TX_ANT_NUM-1 downto 0)         -- LUT Write IQ : I[31:16]/Q[15:0]
    );
end component;

component HARD_CLIPPING is
generic(
    DEVICE                     : string  := "7SERIES"  -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    );
port(
    RST                        : in  std_logic;
    CLK                        : in  std_logic;

    DATA_I_IN                  : in  std_logic_vector(15 downto 0);
    DATA_Q_IN                  : in  std_logic_vector(15 downto 0);

    THRESHOLD                  : in  std_logic_vector(15 downto 0);

    DATA_I_OUT                 : out std_logic_vector(15 downto 0);
    DATA_Q_OUT                 : out std_logic_vector(15 downto 0);
  
    HC_EN                      : in  std_logic;
    HC_ON                      : out std_logic
    );
end component;

component PATH_DGATT is
generic(
    DEVICE                     : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    RND_BIT                    : natural :=       15 ;
    HOVS                       : natural :=        1
    );
port(
    RST                        : in  std_logic;
    CLK                        : in  std_logic;

    DATA_VALID_IN              : in  std_logic;
    DATA_I_IN                  : in  std_logic_vector(15 downto 0);
    DATA_Q_IN                  : in  std_logic_vector(15 downto 0);

    DGATT_VAL                  : in  std_logic_vector(15 downto 0);

    DATA_VALID_OUT             : out std_logic;
    DATA_I_OUT                 : out std_logic_vector(15 downto 0);
    DATA_Q_OUT                 : out std_logic_vector(15 downto 0)
    );
end component;

component PFIR_FILTER is
generic(
    DEVICE                     : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    PIM_MODE                   : boolean :=     TRUE ;
    HOVS                       : natural :=        2 ;
    SYMMETRY                   : string  :=    "EVEN";
    COEF_FIX                   : boolean :=     TRUE ;
    COEF_NUM                   : natural :=       39 ;
    RND_BIT                    : natural :=       15
    );
port(
    RST_DSP                    : in  std_logic;
    CLK_DSP                    : in  std_logic;

    DATA_VLD_IN                : in  std_logic;
    DATA_I_IN                  : in  std_logic_vector(15 downto 0);
    DATA_Q_IN                  : in  std_logic_vector(15 downto 0);

    BYPASS_IN                  : in  std_logic;

    DATA_VLD_OUT               : out std_logic;
    DATA_I_OUT                 : out std_logic_vector(15 downto 0);
    DATA_Q_OUT                 : out std_logic_vector(15 downto 0);

    RST_CPU                    : in  std_logic;
    CLK_CPU                    : in  std_logic;

    COEF_WR_EN                 : in  std_logic;                     -- coefficient write enable(indirect)
    COEF_RD_EN                 : in  std_logic;                     -- coefficient write done(indirect)
    COEF_WR_DN                 : in  std_logic;                     -- coefficient read  enable(indirect)
    COEF_ADDR                  : in  std_logic_vector( 7 downto 0); -- coefficient write address(indirect) 
    COEF_WR_DATA               : in  std_logic_vector(15 downto 0); -- coefficient write data(indirect) 
    COEF_RD_DATA               : out std_logic_vector(15 downto 0)  -- coefficient read  data(indirect) 
    );
end component;

--*****************************
-- Constant 
--*****************************

--*****************************
-- Signals 
--*****************************

signal dpd_core_out_vld        : std_logic_vector( TX_ANT_NUM-1 downto 0);        
signal dpd_core_out_i          : std_logic_array16(TX_ANT_NUM-1 downto 0);        
signal dpd_core_out_q          : std_logic_array16(TX_ANT_NUM-1 downto 0);        
    
signal dpd_hc_out_vld          : std_logic_vector( TX_ANT_NUM-1 downto 0);        
signal dpd_hc_out_i            : std_logic_array16(TX_ANT_NUM-1 downto 0);        
signal dpd_hc_out_q            : std_logic_array16(TX_ANT_NUM-1 downto 0);        
    
signal dl_att_out_vld          : std_logic_vector( TX_ANT_NUM-1 downto 0);        
signal dl_att_out_i            : std_logic_array16(TX_ANT_NUM-1 downto 0);        
signal dl_att_out_q            : std_logic_array16(TX_ANT_NUM-1 downto 0);        
    
signal coef_rd_data            : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal filter_coef_rd_data     : std_logic_vector(15 downto 0);
signal filter_out_vld          : std_logic_vector( TX_ANT_NUM-1 downto 0);        
signal filter_out_i            : std_logic_array16(TX_ANT_NUM-1 downto 0);        
signal filter_out_q            : std_logic_array16(TX_ANT_NUM-1 downto 0);        
    

--*****************************
-- Attribute 
--*****************************

begin

    --*****************************
    -- DPD Core 
    --*****************************
    G_Using_DPD_CORE : if (DPD_CORE_IMPLEMENTATION = TRUE) generate begin

        U_DPD_CORE : DPD_CORE 
        generic map(
            DEVICE                     => DEVICE                     , 
                                                                     
            TX_ANT_NUM                 => TX_ANT_NUM                 , 
            HOVS                       => HOVS                       , 
                                                                     
            DPD_LUT_OPTIMIZED          => DPD_CORE_LUT_OPTIMIZED     ,
            DPD_LUT_MEM_DEPTH          => DPD_CORE_LUT_MEM_DEPTH     , 
            DPD_LUT_RBTEST             => DPD_CORE_LUT_RBTEST        ,
            DPD_CORE_QPOINT_SEL        => DPD_CORE_QPOINT_SEL        ,	     
            DPD_CORE_LUT_DIMENSION     => DPD_CORE_LUT_DIMENSION     , 
            DPD_CORE_LUT_NUM           => DPD_CORE_LUT_NUM           , 
            DPD_CORE_TAP_NUM           => DPD_CORE_TAP_NUM           , 
            DPD_CORE_RND_BIT           => DPD_CORE_RND_BIT             
            )
        port map(
            RST_DPD                    => RST_DPD                    , 
            CLK_DPD                    => CLK_DPD                    , 
        
            DPD_CORE_VLD_IN            => DPD_BLK_VLD_IN             , 
            DPD_CORE_I_IN              => DPD_BLK_I_IN               , 
            DPD_CORE_Q_IN              => DPD_BLK_Q_IN               , 
        
            DPD_CORE_VLD_OUT           => dpd_core_out_vld           , 
            DPD_CORE_I_OUT             => dpd_core_out_i             , 
            DPD_CORE_Q_OUT             => dpd_core_out_q             , 
        
            DPD_CORE_BYPASS_IN         => DPD_CORE_BYPASS_IN         , 
                                                                     
            DPD_GAIN_INDEX_IN          => DPD_GAIN_INDEX_IN          ,
            DPD_QPOINT_SEL_IN          => DPD_QPOINT_SEL_IN          ,
                                                                     
            RST_CPU                    => RST_CPU                    ,
            CLK_CPU                    => CLK_CPU                    ,
                                                                     
            DPD_LUT_RB_TEST_EN_IN      => DPD_LUT_RB_TEST_EN_IN      ,
                                                                     
            DPD_LUT_SWITCH_CDC_STRB_IN => DPD_LUT_SWITCH_CDC_STRB_IN ,
            DPD_LUT_INPUT_SWITCH_IN    => DPD_LUT_INPUT_SWITCH_IN    , 
            DPD_LUT_OUTPUT_SWITCH_IN   => DPD_LUT_OUTPUT_SWITCH_IN   , 
        
            DPD_LUT_UPDATE_SW_IN       => DPD_LUT_UPDATE_SW_IN       ,
            DPD_LUT_WREN_IN            => DPD_LUT_WREN_IN            , 
            DPD_LUT_RDEN_IN            => DPD_LUT_RDEN_IN            , 
            DPD_LUT_ADDR_IN            => DPD_LUT_ADDR_IN            , 
            DPD_LUT_WDATA_IN           => DPD_LUT_WDATA_IN           , 
            DPD_LUT_RDATA_OUT          => DPD_LUT_RDATA_OUT            
            );
    end generate;

    G_Unusing_DPD_CORE : if (DPD_CORE_IMPLEMENTATION = FALSE) generate begin

        dpd_core_out_vld   <= DPD_BLK_VLD_IN;                      
        dpd_core_out_i     <= DPD_BLK_I_IN;                        
        dpd_core_out_q     <= DPD_BLK_Q_IN;                        
    
    end generate;

    G_TX_ANT_PATH : for I in 0 to (TX_ANT_NUM-1) generate begin

        --*****************************
        -- DPD Hard Clipper 
        --*****************************
        G_Using_DPDHC : if (DPD_HC_IMPLEMENTATION = TRUE) generate begin  

            U_DPDHC : HARD_CLIPPING 
            generic map(
                DEVICE                     => DEVICE                   
                )
            port map(
                RST                        => RST_DPD                , 
                CLK                        => CLK_DPD                , 
            
                DATA_I_IN                  => dpd_core_out_i(I)      , 
                DATA_Q_IN                  => dpd_core_out_q(I)      , 
            
                THRESHOLD                  => DPD_HC_TRSHD_IN(I)     ,  
            
                DATA_I_OUT                 => dpd_hc_out_i(I)        , 
                DATA_Q_OUT                 => dpd_hc_out_q(I)        , 
              
                HC_EN                      => DPD_HC_EN_IN(I)        , 
                HC_ON                      => DPD_HC_FLAG_OUT(I)           
                );

            dpd_hc_out_vld(I) <= dpd_core_out_vld(I);        

        end generate;
        
        G_Unusing_DPDHC : if (DPD_HC_IMPLEMENTATION = FALSE) generate begin  
            dpd_hc_out_vld(I)   <= dpd_core_out_vld(I);    
            dpd_hc_out_i(I)     <= dpd_core_out_i(I);        
            dpd_hc_out_q(I)     <= dpd_core_out_q(I);        
            DPD_HC_FLAG_OUT     <= (others=>'0');
        end generate; 

        --*****************************
        -- DPD DL Attenuator 
        --*****************************
        G_Using_DL_ATT : if (DPD_ATT_IMPLEMENTATION = TRUE) generate begin  

            U_DL_ATT : PATH_DGATT 
            generic map(
                DEVICE                     => DEVICE                 , 
                RND_BIT                    => 15                     ,
                HOVS                       => HOVS                     
                )
            port map(
                RST                        => RST_DPD                , 
                CLK                        => CLK_DPD                , 
            
                DATA_VALID_IN              => dpd_hc_out_vld(I)      , 
                DATA_I_IN                  => dpd_hc_out_i(I)        , 
                DATA_Q_IN                  => dpd_hc_out_q(I)        , 
            
                DGATT_VAL                  => DL_ATTEN_VALUE_IN(I)   , 
            
                DATA_VALID_OUT             => dl_att_out_vld(I)      , 
                DATA_I_OUT                 => dl_att_out_i(I)        , 
                DATA_Q_OUT                 => dl_att_out_q(I)          
                );
        end generate;

        G_Unusing_DL_ATT : if (DPD_ATT_IMPLEMENTATION = FALSE) generate begin  
            dl_att_out_vld(I)   <= dpd_hc_out_vld(I);             
            dl_att_out_i(I)     <= dpd_hc_out_i(I);               
            dl_att_out_q(I)     <= dpd_hc_out_q(I);               
        end generate;

        --*****************************
        -- DPD PA Protection Filter 
        --*****************************
        G_Using_DPD_Filter : if (DPD_FILTER_IMPLEMENTATION = TRUE) generate begin  
        
            U_PA_Protection_Filter : PFIR_FILTER 
            generic map(
                DEVICE                     => DEVICE                     , 
                PIM_MODE                   => FALSE                      ,
                HOVS                       => HOVS                       , 
                SYMMETRY                   => "EVEN"                     , 
                COEF_FIX                   => DPD_FILTER_COEF_FIX        ,
                COEF_NUM                   => DPD_FILTER_COEF_NUM        , 
                RND_BIT                    => DPD_FILTER_RND_BIT           
                )
            port map(
                RST_DSP                    => RST_DPD                    , 
                CLK_DSP                    => CLK_DPD                    , 
            
                DATA_VLD_IN                => dl_att_out_vld(I)          , 
                DATA_I_IN                  => dl_att_out_i(I)            , 
                DATA_Q_IN                  => dl_att_out_q(I)            , 
            
                BYPASS_IN                  => FILTER_BYPASS_IN(I)        , 
            
                DATA_VLD_OUT               => filter_out_vld(I)          , 
                DATA_I_OUT                 => filter_out_i(I)            , 
                DATA_Q_OUT                 => filter_out_q(I)            , 
            
                RST_CPU                    => RST_CPU                    , 
                CLK_CPU                    => CLK_CPU                    , 
            
                COEF_WR_EN                 => FILTER_COEF_WR_EN_IN(I)    , 
                COEF_RD_EN                 => FILTER_COEF_RD_EN_IN(I)    , 
                COEF_WR_DN                 => FILTER_COEF_WR_DN_IN(I)    , 
                COEF_ADDR                  => FILTER_COEF_ADDR_IN        ,  
                COEF_WR_DATA               => FILTER_COEF_WR_DATA_IN     , 
                COEF_RD_DATA               => coef_rd_data(I)         
                );
        end generate;

        G_Unusing_DPD_Filter : if (DPD_FILTER_IMPLEMENTATION = FALSE) generate begin  
             filter_out_vld(I)    <= dl_att_out_vld(I);              
             filter_out_i(I)      <= dl_att_out_i(I);                
             filter_out_q(I)      <= dl_att_out_q(I);                
             coef_rd_data(I)      <= (others => '0');
        end generate;
    end generate;

    G_DL2_Filter_COEF_Read : if (TX_ANT_NUM = 2) generate begin
        filter_coef_rd_data <= coef_rd_data(0) when (FILTER_COEF_RD_EN_IN = "01") else
                               coef_rd_data(1) when (FILTER_COEF_RD_EN_IN = "10") else
			       (others => '0'); 
    end generate;
    
    G_DL4_Filter_COEF_Read : if (TX_ANT_NUM = 4) generate begin
        filter_coef_rd_data <= coef_rd_data(0) when (FILTER_COEF_RD_EN_IN = "0001") else
                               coef_rd_data(1) when (FILTER_COEF_RD_EN_IN = "0010") else
                               coef_rd_data(2) when (FILTER_COEF_RD_EN_IN = "0100") else
                               coef_rd_data(3) when (FILTER_COEF_RD_EN_IN = "1000") else
			       (others => '0'); 
    end generate;
    
    FILTER_COEF_RD_DATA_OUT <= filter_coef_rd_data;

    DPD_HC_VLD_OUT          <= dpd_hc_out_vld;   
    DPD_HC_I_OUT            <= dpd_hc_out_i;   
    DPD_HC_Q_OUT            <= dpd_hc_out_q;   

    DPD_BLK_VLD_OUT         <= filter_out_vld;             
    DPD_BLK_I_OUT           <= filter_out_i;               
    DPD_BLK_Q_OUT           <= filter_out_q;               

end arc_DPD_BLK;
