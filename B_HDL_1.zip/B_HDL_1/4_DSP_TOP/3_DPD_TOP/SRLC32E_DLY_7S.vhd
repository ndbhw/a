-- k1340.heo

Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

--   SRLC32E   : In order to incorporate this function into the design,
--    VHDL     : the following instance declaration needs to be placed
--  instance   : in the architecture body of the design code.  The
-- declaration : instance name (SRLC32E_inst) and/or the port declarations
--    code     : after the "=>" assignment maybe changed to properly
--             : reference and connect this function to the design.
--             : All inputs and outputs must be connected.

--   Library   : In addition to adding the instance declaration, a use
-- declaration : statement for the UNISIM.vcomponents library needs to be
--     for     : added before the entity declaration.  This library
--   Xilinx    : contains the component declarations for all Xilinx
--  primitives : primitives and points to the models that will be used
--             : for simulation.

--  Copy the following two statements and paste them before the
--  Entity declaration, unless they already exist.

Library UNISIM;
use UNISIM.vcomponents.all;

entity SRLC32E_DLY_7S is
generic(
    HS_MODE   : boolean := TRUE;

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_COUT : out std_logic_vector(BIT_WIDTH-1 downto 0); -- SRLC32E Chain, 32clock Delayed DATA
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0)  -- Delayed DATA
    );
end SRLC32E_DLY_7S;

architecture arc_SRLC32E_DLY_7S of SRLC32E_DLY_7S is

constant sel_dly : std_logic_vector( 4 downto 0) := conv_std_logic_vector(DELAY_NUM-2, 5);

signal data_srl  : std_logic_vector(BIT_WIDTH-1 downto 0);
signal data_d32  : std_logic_vector(BIT_WIDTH-1 downto 0);
signal data_reg  : std_logic_vector(BIT_WIDTH-1 downto 0);

attribute KEEP : string;
attribute KEEP of data_srl : signal is "TRUE";
attribute KEEP of data_d32 : signal is "TRUE";
attribute KEEP of data_reg : signal is "TRUE";

attribute MAX_FANOUT : integer;
attribute MAX_FANOUT of data_reg : signal is ternary_func(HS_MODE=TRUE, 10, 2000);

begin	

--  <-----Cut code below this line and paste into the architecture body---->
    G_Data_1_Clock_Delay : if (DELAY_NUM = 1) generate begin
        G_1CLK_DLY_Normal_Operation : if (HS_MODE = FALSE) generate begin
            P_1CLK_DLY_NM : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    data_reg <= DATA_IN; 
                end if;
            end process;
        end generate;

        G_1CLK_DLY_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
            P_1CLK_DLY_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    data_reg <= DATA_IN; 
                end if;
            end process;
        end generate;

        data_srl <= (others => '0');
    end generate;

    G_Data_N_Clock_Delay : if (DELAY_NUM > 1) generate begin
        G_SRLC32E_GEN : for I in 0 to (BIT_WIDTH-1) generate begin
            -- SRLC32E: 32-bit variable length shift register LUT
            -- with clock enable
            -- Virtex-6
            -- Xilinx HDL Libraries Guide, version 12.3
            SRLC32E_inst : SRLC32E
                generic map(
                    INIT => X"00000000"
                    )
                port map(
                    Q    => data_srl(I), -- SRL data output
                    Q31  => data_d32(I), -- SRL cascade output pin
                    A    => sel_dly    , -- 5-bit shift depth select input
                    CE   => '1'        , -- Clock enable input
                    CLK  => CLK        ,-- Clock input
                    D    => DATA_IN(I)  -- SRL data input
                    );
            -- End of SRLC32E_inst instantiation
        end generate;

        G_SRL_Output_Clocking_Normal_Operation : if (HS_MODE = FALSE) generate begin
            P_SRL_Output_Clocking_NM : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    data_reg <= data_srl; 
                end if;
            end process;
        end generate;

        G_SRL_Output_Clocking_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
            P_SRL_Output_Clocking_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    data_reg <= data_srl; 
                end if;
            end process;
        end generate;
    end generate;

    DATA_COUT <= data_d32;
    DATA_OUT  <= data_reg;

end arc_SRLC32E_DLY_7S;

