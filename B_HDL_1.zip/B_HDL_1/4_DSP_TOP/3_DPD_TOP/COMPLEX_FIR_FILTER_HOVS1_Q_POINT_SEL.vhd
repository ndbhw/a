library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity COMPLEX_FIR_FILTER_HOVS1_Q_POINT_SEL is
generic(
    HS_MODE          : boolean :=     TRUE ; 
    DEVICE           : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    BASE_RND_BIT     : natural :=       13 ;
    TAP_NUM          : natural :=        8 
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;

    Q_POINT_SEL_IN   : in  std_logic_vector( 1 downto 0); 

    COEF_I_IN        : in  std_logic_array27(TAP_NUM-1 downto 0);
    COEF_Q_IN        : in  std_logic_array27(TAP_NUM-1 downto 0);

    DATA_VLD_IN      : in  std_logic;
    DATA_I_IN        : in  std_logic_vector(15 downto 0);
    DATA_Q_IN        : in  std_logic_vector(15 downto 0);

    DATA_VLD_OUT     : out std_logic;
    DATA_I_OUT       : out std_logic_vector(15 downto 0);
    DATA_Q_OUT       : out std_logic_vector(15 downto 0)
    );
end COMPLEX_FIR_FILTER_HOVS1_Q_POINT_SEL ;

architecture arc_COMPLEX_FIR_FILTER_HOVS1_Q_POINT_SEL  of COMPLEX_FIR_FILTER_HOVS1_Q_POINT_SEL  is

-- Xilinx DSP48
component DSP48E1_COMPLEX_FIR_HOVS1_P_1st_Q_POINT_SEL is
generic(
    HS_MODE          : boolean := TRUE 
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    RND_IN           : in  std_logic_vector(47 downto 0);
    COEF_I_IN        : in  std_logic_vector(29 downto 0);
    DATA_IQ_SUM_IN   : in  std_logic_vector(17 downto 0);
    DATA_IQ_SUM_COUT : out std_logic_vector(17 downto 0);
    RESULT_COUT      : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E1_COMPLEX_FIR_HOVS1_P_nth is
generic(
    HS_MODE          : boolean := TRUE 
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    COEF_I_IN        : in  std_logic_vector(29 downto 0);
    DATA_IQ_SUM_CIN  : in  std_logic_vector(17 downto 0);
    RESULT_CIN       : in  std_logic_vector(47 downto 0);
    DATA_IQ_SUM_COUT : out std_logic_vector(17 downto 0);
    RESULT_COUT      : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E1_COMPLEX_FIR_HOVS1_P_end is
generic(
    HS_MODE          : boolean := TRUE 
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    COEF_I_IN        : in  std_logic_vector(29 downto 0);
    DATA_IQ_SUM_CIN  : in  std_logic_vector(17 downto 0);
    RESULT_CIN       : in  std_logic_vector(47 downto 0);
    RESULT           : out std_logic_vectoR(47 downto 0)
    );
end component;

component DSP48E1_COMPLEX_FIR_HOVS1_AB_1st is
generic(
    HS_MODE          : boolean := TRUE ;
    PREADDER_MODE    : boolean := TRUE   -- "TRUE" : (COEF_I + COEF_Q), "FALSE" : (-COEF_I + COEF_Q)
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    COEF_I_IN        : in  std_logic_vector(29 downto 0);
    COEF_Q_IN        : in  std_logic_vector(24 downto 0);
    DATA_IN          : in  std_logic_vector(17 downto 0);
    DATA_COUT        : out std_logic_vector(17 downto 0);
    RESULT_COUT      : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E1_COMPLEX_FIR_HOVS1_AB_nth is
generic(
    HS_MODE          : boolean := TRUE ; 
    PREADDER_MODE    : boolean := TRUE   -- "TRUE" : (COEF_I + COEF_Q), "FALSE" : (-COEF_I + COEF_Q)
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    COEF_I_IN        : in  std_logic_vector(29 downto 0);
    COEF_Q_IN        : in  std_logic_vector(24 downto 0);
    DATA_CIN         : in  std_logic_vector(17 downto 0);
    RESULT_CIN       : in  std_logic_vector(47 downto 0);
    DATA_COUT        : out std_logic_vector(17 downto 0);
    RESULT_COUT      : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E1_COMPLEX_FIR_HOVS1_AB_end is
generic(
    HS_MODE          : boolean := TRUE ; 
    PREADDER_MODE    : boolean := TRUE   -- "TRUE" : (COEF_I + COEF_Q), "FALSE" : (-COEF_I + COEF_Q)
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    COEF_I_IN        : in  std_logic_vector(29 downto 0);
    COEF_Q_IN        : in  std_logic_vector(24 downto 0);
    DATA_CIN         : in  std_logic_vector(17 downto 0);
    RESULT_CIN       : in  std_logic_vector(47 Downto 0);
    RESULT           : out std_logic_vectoR(47 Downto 0)
    );
end component;

component DSP48E2_COMPLEX_FIR_HOVS1_P_1st_Q_POINT_SEL is
generic(
    HS_MODE          : boolean := TRUE 
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    RND_IN           : in  std_logic_vector(47 downto 0);
    COEF_I_IN        : in  std_logic_vector(29 downto 0);
    DATA_IQ_SUM_IN   : in  std_logic_vector(17 downto 0);
    DATA_IQ_SUM_COUT : out std_logic_vector(17 downto 0);
    RESULT_COUT      : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E2_COMPLEX_FIR_HOVS1_P_nth is
generic(
    HS_MODE          : boolean := TRUE 
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    COEF_I_IN        : in  std_logic_vector(29 downto 0);
    DATA_IQ_SUM_CIN  : in  std_logic_vector(17 downto 0);
    RESULT_CIN       : in  std_logic_vector(47 DOWNTO 0);
    DATA_IQ_SUM_COUT : out std_logic_vector(17 DOWNTO 0);
    RESULT_COUT      : out std_logic_vector(47 DOWNTO 0)
    );
end component;

component DSP48E2_COMPLEX_FIR_HOVS1_P_end is
generic(
    HS_MODE          : boolean := TRUE 
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    COEF_I_IN        : in  std_logic_vector(29 downto 0);
    DATA_IQ_SUM_CIN  : in  std_logic_vector(17 downto 0);
    RESULT_CIN       : in  std_logic_vector(47 downto 0);
    RESULT           : out std_logic_vectoR(47 downto 0)
    );
end component;

component DSP48E2_COMPLEX_FIR_HOVS1_AB_1st is
generic(
    HS_MODE          : boolean := TRUE ;
    PREADDER_MODE    : boolean := TRUE   -- "TRUE" : (COEF_I + COEF_Q), "FALSE" : (-COEF_I + COEF_Q)
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    COEF_I_IN        : in  std_logic_vector(29 downto 0);
    COEF_Q_IN        : in  std_logic_vector(26 downto 0);
    DATA_IN          : in  std_logic_vector(17 downto 0);
    DATA_COUT        : out std_logic_vector(17 downto 0);
    RESULT_COUT      : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E2_COMPLEX_FIR_HOVS1_AB_nth is
generic(
    HS_MODE          : boolean := TRUE ; 
    PREADDER_MODE    : boolean := TRUE   -- "TRUE" : (COEF_I + COEF_Q), "FALSE" : (-COEF_I + COEF_Q)
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    COEF_I_IN        : in  std_logic_vector(29 downto 0);
    COEF_Q_IN        : in  std_logic_vector(26 downto 0);
    DATA_CIN         : in  std_logic_vector(17 downto 0);
    RESULT_CIN       : in  std_logic_vector(47 downto 0);
    DATA_COUT        : out std_logic_vector(17 downto 0);
    RESULT_COUT      : out std_logic_vector(47 downto 0)
    );
end component;

component DSP48E2_COMPLEX_FIR_HOVS1_AB_end is
generic(
    HS_MODE          : boolean := TRUE ; 
    PREADDER_MODE    : boolean := TRUE   -- "TRUE" : (COEF_I + COEF_Q), "FALSE" : (-COEF_I + COEF_Q)
    );
port(
    RST              : in  std_logic;
    CLK              : in  std_logic;
    COEF_I_IN        : in  std_logic_vector(29 downto 0);
    COEF_Q_IN        : in  std_logic_vector(26 downto 0);
    DATA_CIN         : in  std_logic_vector(17 downto 0);
    RESULT_CIN       : in  std_logic_vector(47 Downto 0);
    RESULT           : out std_logic_vectoR(47 Downto 0)
    );
end component;

component SAT_SIGN is
generic(
    HS_MODE          : boolean := TRUE; 
    INPUT_BIT        : natural ;
    OUTPUT_BIT       : natural 
    );
port( 
    RST              : in  std_logic;
    CLK              : in  std_logic;
    DATA_IN          : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT         : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

constant zeros         : std_logic_vector(47 downto 0) := (others => '0');

constant rnd_qpoint_a  : std_logic_vector(47 downto 0) := zeros(47 downto BASE_RND_BIT  ) & '1' & zeros(BASE_RND_BIT-2 downto 0);  
constant rnd_qpoint_b  : std_logic_vector(47 downto 0) := zeros(47 downto BASE_RND_BIT+1) & '1' & zeros(BASE_RND_BIT-1 downto 0); 
constant rnd_qpoint_c  : std_logic_vector(47 downto 0) := zeros(47 downto BASE_RND_BIT+2) & '1' & zeros(BASE_RND_BIT   downto 0); 
constant rnd_qpoint_d  : std_logic_vector(47 downto 0) := zeros(47 downto BASE_RND_BIT+3) & '1' & zeros(BASE_RND_BIT+1 downto 0); 

signal rnd_qpoint      : std_logic_vector(47 downto 0); 

signal se_coef_i       : std_logic_array30(TAP_NUM-1 downto 0);
signal se_coef_q       : std_logic_array27(TAP_NUM-1 downto 0);

signal se_data_i       : std_logic_vector(17 downto 0);
signal se_data_q       : std_logic_vector(17 downto 0);

signal se_coef_i_d1    : std_logic_array30(TAP_NUM-1 downto 0);
signal se_coef_q_d1    : std_logic_array27(TAP_NUM-1 downto 0);
                
signal data_iq_sum     : std_logic_array18(TAP_NUM-1 downto 0);

signal coef_i          : std_logic_array30(TAP_NUM-1 downto 0);
signal coef_q          : std_logic_array27(TAP_NUM-1 downto 0);

signal data_i          : std_logic_array18(TAP_NUM-1 downto 0);
signal data_q          : std_logic_array18(TAP_NUM-1 downto 0);

signal result_p        : std_logic_array48(TAP_NUM   downto 1);
signal result_a        : std_logic_array48(TAP_NUM   downto 1);
signal result_b        : std_logic_array48(TAP_NUM   downto 1);

signal result_p_d1     : std_logic_vector(47 downto 0);
signal result_a_d1     : std_logic_vector(47 downto 0);
signal result_b_d1     : std_logic_vector(47 downto 0);

signal result_i        : std_logic_vector(48 downto 0);
signal result_q        : std_logic_vector(48 downto 0);

signal rnd_i_qpoint_a  : std_logic_vector(48-BASE_RND_BIT   downto 0);
signal rnd_q_qpoint_a  : std_logic_vector(48-BASE_RND_BIT   downto 0);

signal rnd_i_qpoint_b  : std_logic_vector(48-BASE_RND_BIT-1 downto 0);
signal rnd_q_qpoint_b  : std_logic_vector(48-BASE_RND_BIT-1 downto 0);

signal rnd_i_qpoint_c  : std_logic_vector(48-BASE_RND_BIT-2 downto 0);
signal rnd_q_qpoint_c  : std_logic_vector(48-BASE_RND_BIT-2 downto 0);

signal rnd_i_qpoint_d  : std_logic_vector(48-BASE_RND_BIT-3 downto 0);
signal rnd_q_qpoint_d  : std_logic_vector(48-BASE_RND_BIT-3 downto 0);

signal sat_i_qpoint_a  : std_logic_vector(15 downto 0);
signal sat_q_qpoint_a  : std_logic_vector(15 downto 0);

signal sat_i_qpoint_b  : std_logic_vector(15 downto 0);
signal sat_q_qpoint_b  : std_logic_vector(15 downto 0);

signal sat_i_qpoint_c  : std_logic_vector(15 downto 0);
signal sat_q_qpoint_c  : std_logic_vector(15 downto 0);

signal sat_i_qpoint_d  : std_logic_vector(15 downto 0);
signal sat_q_qpoint_d  : std_logic_vector(15 downto 0);

--attribute KEEP : string;
--attribute KEEP of coef_i       : signal is "TRUE";
--attribute KEEP of coef_q       : signal is "TRUE";
--attribute KEEP of result_p_d1  : signal is "TRUE";
--attribute KEEP of result_a_d1  : signal is "TRUE";
--attribute KEEP of result_b_d1  : signal is "TRUE";
--attribute KEEP of result_i     : signal is "TRUE";
--attribute KEEP of result_q     : signal is "TRUE";

begin
    
    G_Qpoint_SEL_Normal_Operation : if (HS_MODE = FALSE) generate begin
        P_Binary_Point_Selection_NM : process(RST, CLK) begin
            if (RST = '1') then
                rnd_qpoint <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                case (Q_POINT_SEL_IN) is
                    when "00"   => rnd_qpoint <= rnd_qpoint_a; -- [13], 4096
                    when "01"   => rnd_qpoint <= rnd_qpoint_b; -- [12], 2048 
                    when "10"   => rnd_qpoint <= rnd_qpoint_c; -- [14], 8192 
                    when others => rnd_qpoint <= rnd_qpoint_d; -- [13], 4096
                end case;
            end if;
        end process;
    end generate;

    G_Qpoint_SEL_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
        P_Binary_Point_Selection_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                case (Q_POINT_SEL_IN) is
                    when "00"   => rnd_qpoint <= rnd_qpoint_a; -- [13], 4096
                    when "01"   => rnd_qpoint <= rnd_qpoint_b; -- [12], 2048 
                    when "10"   => rnd_qpoint <= rnd_qpoint_c; -- [14], 8192 
                    when others => rnd_qpoint <= rnd_qpoint_d; -- [13], 4096
                end case;
            end if;
        end process;
    end generate;


    G_Coef_Sign_Extention : for I in 0 to (TAP_NUM-1) generate begin
        se_coef_i(I) <= sign_extension(COEF_I_IN(I), 30);
        se_coef_q(I) <= COEF_Q_IN(I);
    end generate;

    -- -- Data Sign Extention : 16b -> 18b
    -- P_Data_Sign_Extention_HS : process(CLK) begin
    --     if (CLK'event) and (CLK = '1') then
    --         se_data_i <= sign_extension(DATA_I_IN, 18);
    --         se_data_q <= sign_extension(DATA_Q_IN, 18);
    --     end if; 
    -- end process;
    -- 210712 : for resource reduce
    se_data_i <= sign_extension(DATA_I_IN, 18);
    se_data_q <= sign_extension(DATA_Q_IN, 18);
    
    P_P_Calculation_HS : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            data_iq_sum(0) <= se_data_i + se_data_q;
        end if;
    end process;

    -- 210712 : for resource reduce
    se_coef_i_d1 <= se_coef_i;    
    se_coef_q_d1 <= se_coef_q;    

    P_Adder_Delay_Compensation_HS : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            data_i(0)    <= se_data_i;    
            data_q(0)    <= se_data_q;    
            coef_i       <= se_coef_i_d1;    
            coef_q       <= se_coef_q_d1;    
        end if;
    end process;

    -- ************************************************************************
    -- Coef = Cr*I + Cj*Q
    -- Data = Dr*I + Dj*Q
    -- Coef * Data = (Cr*I + Cj*Q)*(Dr*I + Dj*Q) 
    --             = (Cr*Dr-Cj*Dj)*I + (Cr*Dj+Cj*Dr)*Q
    --             = [Cr*(Dr+Dj) - (Cr+Cj)*Dj]*I + [Cr*(Dr+Dj) + (-Cr+Cj)Dr)*Q
    --           P = Cr*(Dr+Dj)
    --           A = (+Cr+Cj)*Dj
    --           B = (-Cr+Cj)*Dr
    -- 
    --           I = P - A
    --           Q = P + B
    -- ************************************************************************

    G_7Series_DSP48E1 : if (DEVICE = "7SERIES") generate begin
        G_DSP48E1_DPD_TAP_1st : for I in 0 to 0 generate begin
            U_DSP48E1_P_1st : DSP48E1_COMPLEX_FIR_HOVS1_P_1st_Q_POINT_SEL generic map(HS_MODE) port map(RST, CLK, rnd_qpoint, coef_i(I), data_iq_sum(I), data_iq_sum(I+1), result_p(I+1));            
            U_DSP48E1_A_1st : DSP48E1_COMPLEX_FIR_HOVS1_AB_1st generic map(HS_MODE, TRUE ) port map(RST, CLK, coef_i(I), coef_q(I)(24 downto 0), data_q(I), data_q(I+1), result_a(I+1));   
            U_DSP48E1_B_1st : DSP48E1_COMPLEX_FIR_HOVS1_AB_1st generic map(HS_MODE, FALSE) port map(RST, CLK, coef_i(I), coef_q(I)(24 downto 0), data_i(I), data_i(I+1), result_b(I+1));   
        end generate;

        G_DSP48E1_DPD_TAP_nth : for I in 1 to (TAP_NUM-2) generate begin
            U_DSP48E1_P_nth : DSP48E1_COMPLEX_FIR_HOVS1_P_nth  generic map(HS_MODE) port map(RST, CLK, coef_i(I), data_iq_sum(I), result_p(I), data_iq_sum(I+1), result_p(I+1));            
            U_DSP48E1_A_nth : DSP48E1_COMPLEX_FIR_HOVS1_AB_nth generic map(HS_MODE, TRUE ) port map(RST, CLK, coef_i(I), coef_q(I)(24 downto 0), data_q(I), result_a(I), data_q(I+1), result_a(I+1));
            U_DSP48E1_B_nth : DSP48E1_COMPLEX_FIR_HOVS1_AB_nth generic map(HS_MODE, FALSE) port map(RST, CLK, coef_i(I), coef_q(I)(24 downto 0), data_i(I), result_b(I), data_i(I+1), result_b(I+1));
        end generate;

        G_DSP48E1_DPD_TAP_end : for I in (TAP_NUM-1) to (TAP_NUM-1) generate begin
            U_DSP48E1_P_end : DSP48E1_COMPLEX_FIR_HOVS1_P_end  generic map(HS_MODE) port map(RST, CLK, coef_i(I), data_iq_sum(I), result_p(I), result_p(I+1));            
            U_DSP48E1_A_end : DSP48E1_COMPLEX_FIR_HOVS1_AB_end generic map(HS_MODE, TRUE ) port map(RST, CLK, coef_i(I), coef_q(I)(24 downto 0), data_q(I), result_a(I), result_a(I+1));
            U_DSP48E1_B_end : DSP48E1_COMPLEX_FIR_HOVS1_AB_end generic map(HS_MODE, FALSE) port map(RST, CLK, coef_i(I), coef_q(I)(24 downto 0), data_i(I), result_b(I), result_b(I+1));
        end generate;
    end generate;

    G_UltraScale_DSP48E2 : if (DEVICE = "ULTRASCALE") generate begin
        G_DSP48E2_DPD_TAP_1st : for I in 0 to 0 generate begin
            U_DSP48E2_P_1st : DSP48E2_COMPLEX_FIR_HOVS1_P_1st_Q_POINT_SEL generic map(HS_MODE) port map(RST, CLK, rnd_qpoint, coef_i(I), data_iq_sum(I), data_iq_sum(I+1), result_p(I+1));            
            U_DSP48E2_A_1st : DSP48E2_COMPLEX_FIR_HOVS1_AB_1st generic map(HS_MODE, TRUE ) port map(RST, CLK, coef_i(I), coef_q(I), data_q(I), data_q(I+1), result_a(I+1));   
            U_DSP48E2_B_1st : DSP48E2_COMPLEX_FIR_HOVS1_AB_1st generic map(HS_MODE, FALSE) port map(RST, CLK, coef_i(I), coef_q(I), data_i(I), data_i(I+1), result_b(I+1));   
        end generate;

        G_DSP48E2_DPD_TAP_nth : for I in 1 to (TAP_NUM-2) generate begin
            U_DSP48E2_P_nth : DSP48E2_COMPLEX_FIR_HOVS1_P_nth  generic map(HS_MODE) port map(RST, CLK, coef_i(I), data_iq_sum(I), result_p(I), data_iq_sum(I+1), result_p(I+1));            
            U_DSP48E2_A_nth : DSP48E2_COMPLEX_FIR_HOVS1_AB_nth generic map(HS_MODE, TRUE ) port map(RST, CLK, coef_i(I), coef_q(I), data_q(I), result_a(I), data_q(I+1), result_a(I+1));
            U_DSP48E2_B_nth : DSP48E2_COMPLEX_FIR_HOVS1_AB_nth generic map(HS_MODE, FALSE) port map(RST, CLK, coef_i(I), coef_q(I), data_i(I), result_b(I), data_i(I+1), result_b(I+1));
        end generate;

        G_DSP48E2_DPD_TAP_end : for I in (TAP_NUM-1) to (TAP_NUM-1) generate begin
            U_DSP48E2_P_end : DSP48E2_COMPLEX_FIR_HOVS1_P_end  generic map(HS_MODE) port map(RST, CLK, coef_i(I), data_iq_sum(I), result_p(I), result_p(I+1));            
            U_DSP48E2_A_end : DSP48E2_COMPLEX_FIR_HOVS1_AB_end generic map(HS_MODE, TRUE ) port map(RST, CLK, coef_i(I), coef_q(I), data_q(I), result_a(I), result_a(I+1));
            U_DSP48E2_B_end : DSP48E2_COMPLEX_FIR_HOVS1_AB_end generic map(HS_MODE, FALSE) port map(RST, CLK, coef_i(I), coef_q(I), data_i(I), result_b(I), result_b(I+1));
        end generate;
    end generate;

    G_Result_Processing_Normal_Operation : if (HS_MODE = FALSE) generate begin
        P_Result_Clocking_NM : process(RST, CLK) begin
            if (RST = '1') then
                result_p_d1 <= (others => '0');     
                result_a_d1 <= (others => '0');     
                result_b_d1 <= (others => '0');     
            elsif (CLK'event) and (CLK = '1') then
                result_p_d1 <= result_p(TAP_NUM);     
                result_a_d1 <= result_a(TAP_NUM);     
                result_b_d1 <= result_b(TAP_NUM);     
            end if;
        end process;

        -- I = P - A
        -- Q = P + B
        P_Complex_Calculate_NM : process(RST, CLK) begin
            if (RST = '1') then
                result_i <= (others => '0');
                result_q <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then                        
                result_i <= (result_p_d1(47)&result_p_d1)-(result_a_d1(47)&result_a_d1);
                result_q <= (result_p_d1(47)&result_p_d1)+(result_b_d1(47)&result_b_d1);
            end if;
        end process;

        -- 13th bit round up
        P_Truncation_NM : process(RST, CLK) begin
            if (RST = '1') then
                rnd_i_qpoint_a  <= (others => '0'); 
                rnd_q_qpoint_a  <= (others => '0'); 
                
                rnd_i_qpoint_b  <= (others => '0'); 
                rnd_q_qpoint_b  <= (others => '0'); 
                
                rnd_i_qpoint_c  <= (others => '0'); 
                rnd_q_qpoint_c  <= (others => '0'); 
                
                rnd_i_qpoint_d  <= (others => '0'); 
                rnd_q_qpoint_d  <= (others => '0'); 
            elsif (CLK'event) and (CLK = '1') then
                rnd_i_qpoint_a <= result_i(48 downto BASE_RND_BIT  ); 
                rnd_q_qpoint_a <= result_q(48 downto BASE_RND_BIT  ); 
                
                rnd_i_qpoint_b <= result_i(48 downto BASE_RND_BIT+1); 
                rnd_q_qpoint_b <= result_q(48 downto BASE_RND_BIT+1); 
                
                rnd_i_qpoint_c <= result_i(48 downto BASE_RND_BIT+2); 
                rnd_q_qpoint_c <= result_q(48 downto BASE_RND_BIT+2); 

                rnd_i_qpoint_d <= result_i(48 downto BASE_RND_BIT+3); 
                rnd_q_qpoint_d <= result_q(48 downto BASE_RND_BIT+3); 
            end if;
        end process;

    end generate;

    G_Result_Processing_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
        P_Result_Clocking_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                result_p_d1 <= result_p(TAP_NUM);     
                result_a_d1 <= result_a(TAP_NUM);     
                result_b_d1 <= result_b(TAP_NUM);     
            end if;
        end process;

        -- I = P - A
        -- Q = P + B
        P_Complex_Calculate_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                result_i <= (result_p_d1(47)&result_p_d1)-(result_a_d1(47)&result_a_d1);
                result_q <= (result_p_d1(47)&result_p_d1)+(result_b_d1(47)&result_b_d1);
            end if;
        end process;

        -- 13th bit round up
        P_Truncation_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                rnd_i_qpoint_a <= result_i(48 downto BASE_RND_BIT  ); 
                rnd_q_qpoint_a <= result_q(48 downto BASE_RND_BIT  ); 
                
                rnd_i_qpoint_b <= result_i(48 downto BASE_RND_BIT+1); 
                rnd_q_qpoint_b <= result_q(48 downto BASE_RND_BIT+1); 
                
                rnd_i_qpoint_c <= result_i(48 downto BASE_RND_BIT+2); 
                rnd_q_qpoint_c <= result_q(48 downto BASE_RND_BIT+2); 

                rnd_i_qpoint_d <= result_i(48 downto BASE_RND_BIT+3); 
                rnd_q_qpoint_d <= result_q(48 downto BASE_RND_BIT+3); 
            end if;
        end process;

    end generate;

    -- Saturation
    U_SAT_A_DPD_OUT_I : SAT_SIGN generic map(HS_MODE, 48-BASE_RND_BIT+1, 16) port map (RST, CLK, rnd_i_qpoint_a, sat_i_qpoint_a);
    U_SAT_A_DPD_OUT_Q : SAT_SIGN generic map(HS_MODE, 48-BASE_RND_BIT+1, 16) port map (RST, CLK, rnd_q_qpoint_a, sat_q_qpoint_a);
                                                                                                                               
    U_SAT_B_DPD_OUT_I : SAT_SIGN generic map(HS_MODE, 48-BASE_RND_BIT  , 16) port map (RST, CLK, rnd_i_qpoint_b, sat_i_qpoint_b);
    U_SAT_B_DPD_OUT_Q : SAT_SIGN generic map(HS_MODE, 48-BASE_RND_BIT  , 16) port map (RST, CLK, rnd_q_qpoint_b, sat_q_qpoint_b);
                                                                                                                               
    U_SAT_C_DPD_OUT_I : SAT_SIGN generic map(HS_MODE, 48-BASE_RND_BIT-1, 16) port map (RST, CLK, rnd_i_qpoint_c, sat_i_qpoint_c);
    U_SAT_C_DPD_OUT_Q : SAT_SIGN generic map(HS_MODE, 48-BASE_RND_BIT-1, 16) port map (RST, CLK, rnd_q_qpoint_c, sat_q_qpoint_c);
                                                                                                                               
    U_SAT_D_DPD_OUT_I : SAT_SIGN generic map(HS_MODE, 48-BASE_RND_BIT-2, 16) port map (RST, CLK, rnd_i_qpoint_d, sat_i_qpoint_d);
    U_SAT_D_DPD_OUT_Q : SAT_SIGN generic map(HS_MODE, 48-BASE_RND_BIT-2, 16) port map (RST, CLK, rnd_q_qpoint_d, sat_q_qpoint_d);

    G_Filter_Output_SEL_Normal_Operation : if (HS_MODE = FALSE) generate begin
        P_Complex_FIR_Output_Selection_NM : process(RST, CLK) begin
            if (RST = '1') then
                DATA_I_OUT <= (others => '0');
                DATA_Q_OUT <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                case (Q_POINT_SEL_IN) is
                    when "00"   => 
                        DATA_I_OUT <= sat_i_qpoint_a; 
                        DATA_Q_OUT <= sat_q_qpoint_a;                                
                    when "01"   =>  
                        DATA_I_OUT <= sat_i_qpoint_b; 
                        DATA_Q_OUT <= sat_q_qpoint_b;                                  
                    when "10"   => 
                        DATA_I_OUT <= sat_i_qpoint_c;  
                        DATA_Q_OUT <= sat_q_qpoint_c;                                 
                    when others => 
                        DATA_I_OUT <= sat_i_qpoint_d;              
                        DATA_Q_OUT <= sat_q_qpoint_d;  
                end case;
            end if;
        end process;
    end generate;

    G_Filter_Output_SEL_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
        P_Complex_FIR_Output_Selection_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                case (Q_POINT_SEL_IN) is
                    when "00"   => 
                        DATA_I_OUT <= sat_i_qpoint_a; -- [13], 4096
                        DATA_Q_OUT <= sat_q_qpoint_a; -- [13], 4096                               
                    when "01"   =>  
                        DATA_I_OUT <= sat_i_qpoint_b; -- [12], 2048
                        DATA_Q_OUT <= sat_q_qpoint_b; -- [12], 2048                                 
                    when "10"   => 
                        DATA_I_OUT <= sat_i_qpoint_c; -- [14], 8192 
                        DATA_Q_OUT <= sat_q_qpoint_c; -- [14], 8192                                
                    when others => 
                        DATA_I_OUT <= sat_i_qpoint_d; -- [13], 4096             
                        DATA_Q_OUT <= sat_q_qpoint_d; -- [13], 4096 
                end case;
            end if;
        end process;
    end generate;

    DATA_VLD_OUT <= DATA_VLD_IN;

end arc_COMPLEX_FIR_FILTER_HOVS1_Q_POINT_SEL ;	

