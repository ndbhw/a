library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
use IEEE.numeric_std.all;

library XPM;
use XPM.vcomponents.all;
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
-- library UNISIM;
-- use UNISIM.VComponents.all;

entity SIMPLE_UDPRAM is
generic(
    READ_LATENCY                : integer :=  2 ;

    A_ADDR_WIDTH                : integer := 14 ;
    A_DATA_WIDTH                : integer :=  8 ; -- 8/16/32/64

    B_ADDR_WIDTH                : integer := 14 ;              
    B_DATA_WIDTH                : integer :=  8   -- 8/16/32/64
    );
-- Read Latency : 2Clocks
port(
    CLK                         : in  std_logic; -- Signal Clock Only

    EN_A                        : in  std_logic;
    WE_A                        : in  std_logic;
    ADDR_A                      : in  std_logic_vector(A_ADDR_WIDTH-1 downto 0);
    DATA_A                      : in  std_logic_vector(A_DATA_WIDTH-1 downto 0);

    EN_B                        : in  std_logic;
    ADDR_B                      : in  std_logic_vector(B_ADDR_WIDTH-1 downto 0);
    DATA_B                      : out std_logic_vector(B_DATA_WIDTH-1 downto 0)
    );
end SIMPLE_UDPRAM;

architecture arc_SIMPLE_UDPRAM of SIMPLE_UDPRAM is

type std_logic_array4                       is array(natural range <>) of std_logic_vector(   3 downto 0);

function exp2b ( data_value : natural) 
    return integer is

    variable width : integer := data_value;
    variable cnt   : integer := 1;

begin
    while (width > 0) loop
        cnt := cnt*2;
        width   := width - 1;
    end loop;

    return cnt;
end function;

function log2 (data_value : integer)
    return integer is
    
    variable width : integer := 0;
    variable cnt   : integer := 1;
begin
    if (data_value <= 1) then
        width := 0;
    else
        while (cnt < data_value) loop
            width := width + 1;
            cnt   := cnt * 2;
        end loop;
    end if;
    
    return width;
end log2;
    
constant zeros                  : std_logic_vector(71 downto 0) := (others => '0');



signal wrena                    : std_logic_vector( 8 downto 0) := (others => '0');
signal addra                    : std_logic_vector(A_ADDR_WIDTH+log2(A_DATA_WIDTH)-7 downto 0) := (others => '0');
signal dataa                    : std_logic_vector(71 downto 0) := (others => '0');

signal addrb                    : std_logic_vector(B_ADDR_WIDTH+log2(B_DATA_WIDTH)-7 downto 0) := (others => '0');
signal addrb_l                  : std_logic_vector( 3 downto 0) := (others => '0');
signal addrb_l_sh               : std_logic_array4(READ_LATENCY-1 downto 0) := (others => (others => '0'));
signal datab                    : std_logic_vector(71 downto 0) := (others => '0');

signal datab_sel                : std_logic_vector(B_DATA_WIDTH-1 downto 0) := (others => '0');

begin

    -- Write Side A
    addra <= ADDR_A(A_ADDR_WIDTH-1 downto 6-log2(A_DATA_WIDTH));

    G_A_DATA_8b : if (A_DATA_WIDTH = 8) generate begin
        P_WR : process(WE_A, ADDR_A, DATA_A) begin
            case (ADDR_A(2 downto 0)) is
                when "000"  => wrena <= zeros(8 downto 1) & WE_A;                     dataa <= zeros(71 downto 1*A_DATA_WIDTH) & DATA_A; 
                when "001"  => wrena <= zeros(8 downto 2) & WE_A & zeros(0 downto 0); dataa <= zeros(71 downto 2*A_DATA_WIDTH) & DATA_A & zeros(1*A_DATA_WIDTH-1 downto 0); 
                when "010"  => wrena <= zeros(8 downto 3) & WE_A & zeros(1 downto 0); dataa <= zeros(71 downto 3*A_DATA_WIDTH) & DATA_A & zeros(2*A_DATA_WIDTH-1 downto 0); 
                when "011"  => wrena <= zeros(8 downto 4) & WE_A & zeros(2 downto 0); dataa <= zeros(71 downto 4*A_DATA_WIDTH) & DATA_A & zeros(3*A_DATA_WIDTH-1 downto 0); 
                when "100"  => wrena <= zeros(8 downto 5) & WE_A & zeros(3 downto 0); dataa <= zeros(71 downto 5*A_DATA_WIDTH) & DATA_A & zeros(4*A_DATA_WIDTH-1 downto 0); 
                when "101"  => wrena <= zeros(8 downto 6) & WE_A & zeros(4 downto 0); dataa <= zeros(71 downto 6*A_DATA_WIDTH) & DATA_A & zeros(5*A_DATA_WIDTH-1 downto 0); 
                when "110"  => wrena <= zeros(8 downto 7) & WE_A & zeros(5 downto 0); dataa <= zeros(71 downto 7*A_DATA_WIDTH) & DATA_A & zeros(6*A_DATA_WIDTH-1 downto 0); 
                when others => wrena <= zeros(8 downto 8) & WE_A & zeros(6 downto 0); dataa <= zeros(71 downto 8*A_DATA_WIDTH) & DATA_A & zeros(7*A_DATA_WIDTH-1 downto 0); 
            end case;
        end process;
    end generate;

    G_A_DATA_16b : if (A_DATA_WIDTH = 16) generate begin
        P_WR : process(WE_A, ADDR_A, DATA_A) begin
            case (ADDR_A(1 downto 0)) is
                when "00"   => wrena <= zeros(8 downto 2) & WE_A & WE_A;                     dataa <= zeros(71 downto 1*A_DATA_WIDTH) & DATA_A; 
                when "01"   => wrena <= zeros(8 downto 4) & WE_A & WE_A & zeros(1 downto 0); dataa <= zeros(71 downto 2*A_DATA_WIDTH) & DATA_A & zeros(1*A_DATA_WIDTH-1 downto 0); 
                when "10"   => wrena <= zeros(8 downto 6) & WE_A & WE_A & zeros(3 downto 0); dataa <= zeros(71 downto 3*A_DATA_WIDTH) & DATA_A & zeros(2*A_DATA_WIDTH-1 downto 0); 
                when others => wrena <= zeros(8 downto 8) & WE_A & WE_A & zeros(5 downto 0); dataa <= zeros(71 downto 4*A_DATA_WIDTH) & DATA_A & zeros(3*A_DATA_WIDTH-1 downto 0); 
            end case;
        end process;
    end generate;

    G_A_DATA_32b : if (A_DATA_WIDTH = 32) generate begin
        P_WR : process(WE_A, ADDR_A, DATA_A) begin
            case (ADDR_A(0 downto 0)) is
                when "0"    => wrena <= zeros(8 downto 4) & WE_A & WE_A & WE_A & WE_A;                     dataa <= zeros(71 downto 1*A_DATA_WIDTH) & DATA_A; 
                when others => wrena <= zeros(8 downto 8) & WE_A & WE_A & WE_A & WE_A & zeros(3 downto 0); dataa <= zeros(71 downto 2*A_DATA_WIDTH) & DATA_A & zeros(1*A_DATA_WIDTH-1 downto 0); 
            end case;
        end process;
    end generate;

    G_A_DATA_64b : if (A_DATA_WIDTH = 64) generate begin
        wrena <= zeros(8 downto 8) & WE_A & WE_A & WE_A & WE_A & WE_A & WE_A & WE_A & WE_A; 
        dataa <= zeros(71 downto 1*A_DATA_WIDTH) & DATA_A; 
    end generate;

    -- URAM Primitive
    U_XPM_MEMORY_TDPRAM : XPM_MEMORY_TDPRAM
    generic map(
        -- Common module generics
        MEMORY_SIZE             => (exp2b(A_ADDR_WIDTH+log2(A_DATA_WIDTH)-6)*72), -- positive integer
        MEMORY_PRIMITIVE        => "ultra"                          , -- string; "auto", "distributed", "block" or "ultra" ;
        CLOCKING_MODE           => "common_clock"                   , -- string; "common_clock", "independent_clock" 
        MEMORY_INIT_FILE        => "none"                           , -- string; "none" or "<filename>.mem" 
        MEMORY_INIT_PARAM       => ""                               , -- string;
        USE_MEM_INIT            => 1                                , -- integer; 0,1
        WAKEUP_TIME             => "disable_sleep"                  , -- string; "disable_sleep" or "use_sleep_pin" 
        MESSAGE_CONTROL         => 0                                , -- integer;
        ECC_MODE                => "no_ecc"                         , -- string; "no_ecc", "encode_only", "decode_only" or "both_encode_and_decode" 
        AUTO_SLEEP_TIME         => 0                                , -- Do not Change
        USE_EMBEDDED_CONSTRAINT => 0                                , -- integer: 0,1
        MEMORY_OPTIMIZATION     => "true"                           , -- string; "true", "false" 
    
        -- Port A module generics
        WRITE_DATA_WIDTH_A      => 72                               , -- positive integer
        READ_DATA_WIDTH_A       => 72                               , -- positive integer
        BYTE_WRITE_WIDTH_A      => 8                                , -- integer; 8, 9, or WRITE_DATA_WIDTH_A value
        ADDR_WIDTH_A            => (A_ADDR_WIDTH+log2(A_DATA_WIDTH)-6), -- positive integer
        READ_RESET_VALUE_A      => "0"                              , -- string
        READ_LATENCY_A          => READ_LATENCY                     , -- non-negative integer
        WRITE_MODE_A            => "no_change"                      , -- string; "write_first", "read_first", "no_change" 
    
        -- Port B module generics
        WRITE_DATA_WIDTH_B      => 72                               , -- positive integer
        READ_DATA_WIDTH_B       => 72                               , -- positive integer
        BYTE_WRITE_WIDTH_B      => 8                                , -- integer; 8, 9, or WRITE_DATA_WIDTH_B value
        ADDR_WIDTH_B            => (B_ADDR_WIDTH+log2(B_DATA_WIDTH)-6), -- positive integer
        READ_RESET_VALUE_B      => "0"                              , -- string
        READ_LATENCY_B          => READ_LATENCY                     , -- non-negative integer
        WRITE_MODE_B            => "no_change"                        -- string; "write_first", "read_first", "no_change" 
        )
    port map(
        -- Common module ports
        SLEEP                   => '0'                              ,
    
        -- Port A module ports
        CLKA                    => CLK                              ,
        RSTA                    => '0'                              ,
        ENA                     => EN_A                             ,
        REGCEA                  => '1'                              ,
        WEA                     => wrena                            ,
        ADDRA                   => addra                            ,
        DINA                    => dataa                            ,
        INJECTSBITERRA          => '0'                              ,
        INJECTDBITERRA          => '0'                              ,
        DOUTA                   => open                             ,
        SBITERRA                => open                             ,
        DBITERRA                => open                             ,
    
        -- Port B module ports
        CLKB                    => CLK                              ,
        RSTB                    => '0'                              ,
        ENB                     => EN_B                             ,
        REGCEB                  => '1'                              ,
        WEB                     => (others => '0')                  ,
        ADDRB                   => addrb                            ,
        DINB                    => (others => '0')                  ,
        INJECTSBITERRB          => '0'                              ,
        INJECTDBITERRB          => '0'                              ,
        DOUTB                   => datab                            ,
        SBITERRB                => open                             ,
        DBITERRB                => open
        );

    -- Read Side B
    addrb   <= ADDR_B(B_ADDR_WIDTH-1 downto 6-log2(B_DATA_WIDTH));

    addrb_l <= zeros(3 downto 6-log2(B_DATA_WIDTH)) & ADDR_B(5-log2(B_DATA_WIDTH) downto 0);

    P_ADDRB_L_SH : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            addrb_l_sh <= addrb_l_sh(READ_LATENCY-2 downto 0) & addrb_l;
        end if;
    end process;

    G_B_DATA_8b : if (B_DATA_WIDTH = 8) generate begin
        P_RD : process(addrb_l_sh(READ_LATENCY-1), datab) begin
            case(addrb_l_sh(READ_LATENCY-1)(2 downto 0)) is
                when "000"  => datab_sel <= datab(1*B_DATA_WIDTH-1 downto 0*B_DATA_WIDTH);           
                when "001"  => datab_sel <= datab(2*B_DATA_WIDTH-1 downto 1*B_DATA_WIDTH);           
                when "010"  => datab_sel <= datab(3*B_DATA_WIDTH-1 downto 2*B_DATA_WIDTH);           
                when "011"  => datab_sel <= datab(4*B_DATA_WIDTH-1 downto 3*B_DATA_WIDTH);           
                when "100"  => datab_sel <= datab(5*B_DATA_WIDTH-1 downto 4*B_DATA_WIDTH);           
                when "101"  => datab_sel <= datab(6*B_DATA_WIDTH-1 downto 5*B_DATA_WIDTH);           
                when "110"  => datab_sel <= datab(7*B_DATA_WIDTH-1 downto 6*B_DATA_WIDTH);           
                when others => datab_sel <= datab(8*B_DATA_WIDTH-1 downto 7*B_DATA_WIDTH);           
            end case;
        end process;
    end generate;

    G_DATA_16b : if (B_DATA_WIDTH = 16) generate begin
        P_RD : process(addrb_l_sh(READ_LATENCY-1), datab) begin
            case(addrb_l_sh(READ_LATENCY-1)(1 downto 0)) is
                when "00"   => datab_sel <= datab(1*B_DATA_WIDTH-1 downto 0*B_DATA_WIDTH);           
                when "01"   => datab_sel <= datab(2*B_DATA_WIDTH-1 downto 1*B_DATA_WIDTH);           
                when "10"   => datab_sel <= datab(3*B_DATA_WIDTH-1 downto 2*B_DATA_WIDTH);           
                when others => datab_sel <= datab(4*B_DATA_WIDTH-1 downto 3*B_DATA_WIDTH);           
            end case;
        end process;
    end generate;

    G_DATA_32b : if (B_DATA_WIDTH = 32) generate begin
        P_RD : process(addrb_l_sh(READ_LATENCY-1), datab) begin
            case(addrb_l_sh(READ_LATENCY-1)(0 downto 0)) is
                when "0"    => datab_sel <= datab(1*B_DATA_WIDTH-1 downto 0*B_DATA_WIDTH);           
                when others => datab_sel <= datab(2*B_DATA_WIDTH-1 downto 1*B_DATA_WIDTH);           
            end case;
        end process;
    end generate;

    G_DATA_72b : if (B_DATA_WIDTH = 64) generate begin
        datab_sel <= datab(B_DATA_WIDTH-1 downto 0);
    end generate;

    P_DATA_B : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            DATA_B <= datab_sel;
        end if;
    end process;

end arc_SIMPLE_UDPRAM;
