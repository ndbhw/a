library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity fir_i3 is
generic(
    VENDOR                      : string := "XILINX";
    CHANNEL_NUMBERS             : integer:= 1;
    WIDTH_IN                    : integer:= 16;
    WIDTH_OUT                   : integer:= 16;
    WIDTH_COEFF                 : integer:= 16;
    BINARY_POINT                : integer:= 15;
    HOVS                        : integer:= 2;
    ORDER                       : integer:= 55
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1  downto 0)
);
end fir_i3;

architecture rtl of fir_i3 is

    component dduc_delay_chain is
    generic(
        BUFF_DEPTH                  : natural:= 16;-- SRL16E
        DIRECTION                   : natural:= 1; -- 1:forward, 0:reverse
        WIDTH_IN                    : natural:= 16 -- Input data width
    );
    port(
        CLK                         : in  std_logic;
        DATA_SEL                    : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
        VALID_I                     : in  std_logic;
        FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
        FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
    );
    end component;

    component dduc_dsp is
    generic(
        PCIN_EN                     : boolean := FALSE;
        D_EN                        : boolean := FALSE;
        C_EN                        : boolean := FALSE;

        WIDTH_A                     : integer := 16;
        WIDTH_D                     : integer := 16;
        WIDTH_B                     : integer := 16;
        WIDTH_C                     : integer := 16;
        WIDTH_PCIN                  : integer := 48;
        WIDTH_PCOUT                 : integer := 48;
        WIDTH_P                     : integer := 48
    );
    port(
        CLK                         : in  std_logic;

        SEL                         : in  std_logic;
        CEP                         : in  std_logic;
        DSP_A_INV                   : in  std_logic;

        DSP_A                       : in  std_logic_vector(WIDTH_A-1 downto 0);
        DSP_D                       : in  std_logic_vector(WIDTH_D-1 downto 0);
        DSP_B                       : in  std_logic_vector(WIDTH_B-1 downto 0);
        DSP_C                       : in  std_logic_vector(WIDTH_C-1 downto 0);

        DSP_PCIN                    : in  std_logic_vector(WIDTH_PCIN-1 downto 0);
        DSP_PCOUT                   : out std_logic_vector(WIDTH_PCOUT-1 downto 0);
        DSP_P                       : out std_logic_vector(WIDTH_P-1 downto 0)
    );
    end component;


    constant I_RATIO                : integer := 3;-- Interpolation Ratio
    constant INT_CYCLE              : integer := HOVS/I_RATIO;-- interpolation cycle count = HOVS/Interpolation Ratio
    constant DSP_INSTANCES          : integer := ORDER/HOVS+ternary_func(ORDER mod HOVS=0, 0, 1);
    constant DELAY_MEM_NUM          : integer := ORDER/HOVS+ternary_func(ORDER mod HOVS=0, 0, 1);
    constant DELAY_MEM_DEPTH        : integer := CHANNEL_NUMBERS*HOVS/I_RATIO;
    constant DELAY_MEM_DEPTH_WIDTH  : integer := ternary_func(INT_CYCLE=1,1,log2(DELAY_MEM_DEPTH));
    constant PROC_DELAY             : integer := 1+DSP_INSTANCES*INT_CYCLE+4;--+1 delay chain +DSP#*accumulation cycle + 1 DSP input reg+3 DSP
    constant WIDTH_DSP              : integer := 48;
    constant WIDTH_BINARY           : integer := BINARY_POINT+2;-- +1 for signed bit
    constant DSP_MAX_COEF_NUM       : integer := 2**log2(HOVS);
    constant COEFF_SET_NUM          : integer := DSP_MAX_COEF_NUM/INT_CYCLE;
    constant FIR_COEFF_60           : integer_array(24-1 downto 0) := (-88,-212,-69,602,1279,606,-2060,-4653,-2796,6343,19966,30234,30234,19966,6343,-2796,-4653,-2060,606,1279,602,-69,-212,-88);
    constant FIR_COEFF_80           : integer_array(36-1 downto 0) := (-43,-74,1,213,352,87,-587,-1022,-365,1322,2474,1127,-2717,-5786,-3350,6598,20435,30487,30487,20435,6598,-3350,-5786,-2717,1127,2474,1322,-365,-1022,-587,87,352,213,1,-74,-43);
    constant FIR_COEFF              : integer_array(ORDER-1 downto 0) := ternary_func(ORDER=24,FIR_COEFF_60,FIR_COEFF_80);

    type data_array                 is array(natural range <>) of std_logic_vector(WIDTH_IN-1 downto 0);
    type coef_array                 is array(natural range <>) of std_logic_vector(WIDTH_COEFF-1 downto 0);
    type dsp_coef_array             is array(natural range <>) of integer_array(DSP_MAX_COEF_NUM-1 downto 0);
    type dsp_coef_sel_array         is array(natural range <>) of std_logic_vector(log2(DSP_MAX_COEF_NUM)-1 downto 0);
    type chain_array                is array(natural range <>) of std_logic_vector(WIDTH_DSP-1 downto 0);
    type binary_array               is array(natural range <>) of std_logic_vector(WIDTH_BINARY-1 downto 0);
    type delay_sel_array            is array(natural range <>) of std_logic_vector(ternary_func(INT_CYCLE=1,1,log2(DELAY_MEM_DEPTH))-1 downto 0);
    type delay_sel_hovs_array       is array(natural range <>) of delay_sel_array(INT_CYCLE-1 downto 0);

--    signal frame_in_d               : std_logic_vector(PROC_DELAY-1 downto 0);
    signal valid_in_d               : std_logic_vector(PROC_DELAY-1 downto 0);
    signal int_cnt                  : std_logic_vector(log2(I_RATIO)-1 downto 0);   -- interpolation count
    signal int_cycle_cnt            : std_logic_vector(ternary_func(INT_CYCLE=1,1,log2(INT_CYCLE))-1 downto 0); -- interpolation cycle count ex) 10 HOVS = 2 interpolation cycle if I_RATIO = 5
    signal int_valid                : std_logic;
    signal int_valid_d              : std_logic_vector(PROC_DELAY-3 downto 0);-- minus 2 clock, (VALID_I, int_cycle_cnt)

    signal delay_data_valid         : std_logic_vector(DELAY_MEM_NUM-1 downto 0);
    signal delay_data_sel_i         : delay_sel_array(DELAY_MEM_NUM-1 downto 1);
    signal delay_data_sel           : delay_sel_array(DELAY_MEM_NUM-1 downto 0);
    signal delay_data_in            : data_array(DELAY_MEM_NUM-1 downto 0);
    signal delay_data_out           : data_array(DELAY_MEM_NUM-1 downto 0);
    signal delay_data_out_d         : data_array(DELAY_MEM_NUM-2 downto 0);

    signal sel                      : std_logic;
    signal sel_1d                   : std_logic;
    signal sel_2d                   : std_logic;
    signal coef_sel                 : dsp_coef_sel_array(DSP_INSTANCES-1 downto 0);
    signal dsp_a                    : data_array(DSP_INSTANCES-1 downto 0);
    signal dsp_d                    : data_array(DSP_INSTANCES-1 downto 0);
    signal dsp_b                    : coef_array(DSP_INSTANCES-1 downto 0);
    signal dsp_c                    : binary_array(DSP_INSTANCES-1 downto 0);
    signal dsp_pcin                 : chain_array(DSP_INSTANCES-1 downto 0);
    signal dsp_pcout                : chain_array(DSP_INSTANCES-1 downto 0);
    signal dsp_p                    : chain_array(DSP_INSTANCES-1 downto 0);

    -- Delay chain selection configuration
    function data_sel_init return delay_sel_hovs_array is
        variable result : delay_sel_hovs_array(DELAY_MEM_NUM-1 downto 0);
    begin
        MEM_LOOP : for M in 0 to DELAY_MEM_NUM-1 loop
            HOVS_LOOP : for H in 0 to INT_CYCLE-1 loop
                if H = 0 then
                    if M = 0  then
                        result(M)(H) := std_logic_vector(to_unsigned(0                  , DELAY_MEM_DEPTH_WIDTH));-- 1st delay chain
                    else
                        result(M)(H) := std_logic_vector(to_unsigned(CHANNEL_NUMBERS-1  , DELAY_MEM_DEPTH_WIDTH));-- Nth delay chain
                    end if;
                else
                    result(M)(H) := std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))+CHANNEL_NUMBERS , DELAY_MEM_DEPTH_WIDTH));-- +C every HOVS cycle
                end if;
            end loop;
        end loop;
        return result;
    end function data_sel_init;

    constant DELAY_HOVS_SEL         : delay_sel_hovs_array(DELAY_MEM_NUM-1 downto 0) := data_sel_init;

    -- Coefficient mapping function for DSP internal coefficient rom data
    function coeff_init return dsp_coef_array is
        variable result : dsp_coef_array(DSP_INSTANCES-1 downto 0);
    begin
        M_LOOP : for M in 0 to DSP_INSTANCES-1 loop
            N_LOOP : for N in 0 to DSP_MAX_COEF_NUM-1 loop
                if N mod COEFF_SET_NUM < I_RATIO then
                    if M*HOVS+I_RATIO*(N/COEFF_SET_NUM)+ (N mod COEFF_SET_NUM) < ORDER then
                        result(M)(N) := FIR_COEFF(M*HOVS+I_RATIO*(N/COEFF_SET_NUM)+ (N mod COEFF_SET_NUM));-- h[0],[1]..... or h[10],h[11]....
                    else
                        result(M)(N) := 0;
                    end if;
                else
                    result(M)(N) := 0;
                end if;
            end loop;
        end loop;
        return result;
    end function coeff_init;

    constant COEFF                  : dsp_coef_array(DSP_INSTANCES-1 downto 0) := coeff_init;


begin

    -- Input delay
    process(CLK,RST)
    begin
        if RST='1' then
            valid_in_d  <= (others=>'0');
        elsif CLK'event and CLK='1' then
            valid_in_d  <= valid_in_d(valid_in_d'length-2 downto 0) & VALID_I;
        end if;
    end process;

    -- interpolation cycle counter
    process(CLK,RST)
    begin
        if RST='1' then
            int_cycle_cnt <= (others => '0');
        elsif CLK'event and CLK='1' then
            if INT_CYCLE = 1 then
                int_cycle_cnt <= (others => '0');
            elsif VALID_I = '1' then
                int_cycle_cnt <= (others => '0');
            else
                int_cycle_cnt <= int_cycle_cnt + 1;
            end if;
        end if;
    end process;

    -- interpolation counter
    process(CLK,RST)
    begin
        if RST='1' then
            int_cnt <= (others => '0');
        elsif CLK'event and CLK='1' then
            if I_RATIO = 1 then
                int_cnt <= (others => '0');
            elsif VALID_I = '1' then
                int_cnt <= (others => '0');
            elsif int_cycle_cnt = INT_CYCLE-1 then-- every interolation cycle
                if int_cnt = I_RATIO-1 then
                    int_cnt <= (others => '0');
                else
                    int_cnt <= int_cnt + 1;
                end if;
            end if;
        end if;
    end process;

    -- interpolated valid signal
    process(CLK,RST)
    begin
        if RST='1' then
            int_valid   <= '0';
            int_valid_d <= (others => '0');
        elsif CLK'event and CLK='1' then
            int_valid_d <= int_valid_d(int_valid_d'length-2 downto 0) & int_valid;
            if int_cycle_cnt = 0 then
                int_valid <= '1';
            else
                int_valid <= '0';
            end if;
        end if;
    end process;

    -- DSP opcode selection
    process(CLK,RST)
    begin
        if RST='1' then
            sel    <= '0';
            sel_1d <= '0';
            sel_2d <= '0';
        elsif CLK'event and CLK='1' then
            if int_cycle_cnt = 0 then
                sel <= '0';
            else
                sel <= '1';
            end if;
            sel_1d <= sel;
            sel_2d <= sel_1d; -- 2 clock after DSP data input
        end if;
    end process;

    DELAY_GEN : for N in 0 to DELAY_MEM_NUM-1 generate
        DELAY_GEN_0 : if N = 0 generate
        begin
            delay_data_valid(N) <= VALID_I;
            delay_data_in(N)    <= FILTER_IN;
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(int_cycle_cnt));
        end generate DELAY_GEN_0;

        DELAY_GEN_N : if N > 0 generate
        begin
            delay_data_valid(N) <= valid_in_d(INT_CYCLE*N-1);-- write delay data (delayed by interpolated cycle)
            delay_data_in(N)    <= delay_data_out_d(N-1);
            delay_data_sel_i(N) <= DELAY_HOVS_SEL(N)(conv_integer(int_cycle_cnt));

            -- interpolation cycle delay
            u_delay_data : dduc_delay_chain
            generic map(
                BUFF_DEPTH                  => ternary_func(INT_CYCLE=1, 2, DELAY_MEM_DEPTH) ,--: natural:= 16;-- SRL16E
                DIRECTION                   => 0                            ,--: natural:= 1: -- 1:forward, 0:reverse
                WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
            )
            port map(
                CLK                         => CLK                          ,--: in  std_logic;
                DATA_SEL                    => std_logic_vector(to_unsigned(INT_CYCLE-1, ternary_func(INT_CYCLE=1, 1, log2(INT_CYCLE)))),
                VALID_I                     => '1'                          ,--: in  std_logic;
                FILTER_IN                   => delay_data_out(N-1)          ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
                FILTER_OUT                  => delay_data_out_d(N-1)         --: out std_logic_vector(WIDTH_IN-1 downto 0)
            );

            -- interpolation cycle delay
            u_delay_sel : dduc_delay_chain
            generic map(
                BUFF_DEPTH                  => ternary_func(INT_CYCLE=1, 2, DELAY_MEM_DEPTH)      ,--: natural:= 16;-- SRL16E
                DIRECTION                   => 0                                                  ,--: natural:= 1: -- 1:forward, 0:reverse
                WIDTH_IN                    => ternary_func(INT_CYCLE=1, 1, log2(DELAY_MEM_DEPTH)) --: natural:= 16 -- Input data width
            )
            port map(
                CLK                         => CLK                          ,--: in  std_logic;
                DATA_SEL                    => std_logic_vector(to_unsigned(INT_CYCLE-1, ternary_func(INT_CYCLE=1, 1, log2(INT_CYCLE)))),
                VALID_I                     => '1'                          ,--: in  std_logic;
                FILTER_IN                   => delay_data_sel_i(N)          ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
                FILTER_OUT                  => delay_data_sel(N)             --: out std_logic_vector(WIDTH_IN-1 downto 0)
            );
        end generate DELAY_GEN_N;

        -- delay chain
        u_dduc_delay_chain : dduc_delay_chain
        generic map(
            BUFF_DEPTH                  => ternary_func(INT_CYCLE=1, 2, DELAY_MEM_DEPTH) ,--: natural:= 16;-- SRL16E
            DIRECTION                   => 0                            ,--: natural:= 1: -- 1:forward, 0:reverse
            WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;
            DATA_SEL                    => delay_data_sel(N)            ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
            VALID_I                     => delay_data_valid(N)          ,--: in  std_logic;
            FILTER_IN                   => delay_data_in(N)             ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
            FILTER_OUT                  => delay_data_out(N)             --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );
    end generate DELAY_GEN;

    DSP_BLOCK_GEN : for N in 0 to DSP_INSTANCES-1  generate
        process(CLK,RST)
        begin
            if RST = '1' then
                dsp_a(N) <= (others => '0');
                dsp_b(N) <= (others => '0');
            elsif CLK'event and CLK='1' then
                dsp_a(N) <= delay_data_out(N);
                dsp_b(N) <= sign_extension(COEFF(N)(conv_integer(coef_sel(N))), WIDTH_COEFF);
            end if;
        end process;
        dsp_d(N)      <= (others => '0');

        DSP_GEN_0 : if N = 0 generate
            dsp_c(N)    <= sign_extension(2**(BINARY_POINT), WIDTH_BINARY);
            dsp_pcin(N) <= (others => '0');
            coef_sel(N) <= ternary_func(INT_CYCLE=1, int_cnt, int_cycle_cnt & int_cnt);
        end generate DSP_GEN_0;

        DSP_GEN_N : if N > 0 generate
            dsp_c(N)    <= (others => '0');
            dsp_pcin(N) <= dsp_pcout(N-1);
                -- interpolation cycle delay
            u_delay_sel : dduc_delay_chain
            generic map(
                BUFF_DEPTH                  => INT_CYCLE                    ,--: natural:= 16;-- SRL16E
                DIRECTION                   => 0                            ,--: natural:= 1: -- 1:forward, 0:reverse
                WIDTH_IN                    => log2(DSP_MAX_COEF_NUM)        --: natural:= 16 -- Input data width
            )
            port map(
                CLK                         => CLK                          ,--: in  std_logic;
                DATA_SEL                    => std_logic_vector(to_unsigned(INT_CYCLE-1, log2(INT_CYCLE))),
                VALID_I                     => '1'                          ,--: in  std_logic;
                FILTER_IN                   => coef_sel(N-1)                ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
                FILTER_OUT                  => coef_sel(N)                   --: out std_logic_vector(WIDTH_IN-1 downto 0)
            );
        end generate DSP_GEN_N;

        u_dduc_dsp : dduc_dsp
        generic map(
            PCIN_EN                     => ternary_func(N=0,FALSE,TRUE) ,--: boolean := FALSE;
            D_EN                        => FALSE                        ,--: boolean := FALSE;
            C_EN                        => ternary_func(N=0,TRUE,FALSE) ,--: boolean := FALSE;

            WIDTH_A                     => WIDTH_IN                     ,--: integer := 16;
            WIDTH_D                     => WIDTH_IN                     ,--: integer := 16;
            WIDTH_B                     => WIDTH_COEFF                  ,--: integer := 16;
            WIDTH_C                     => WIDTH_BINARY                 ,--: integer := 16;
            WIDTH_PCIN                  => WIDTH_DSP                    ,--: integer := 48;
            WIDTH_PCOUT                 => WIDTH_DSP                    ,--: integer := 48;
            WIDTH_P                     => WIDTH_DSP                     --: integer := 48
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;

            SEL                         => sel_2d                       ,--: in  std_logic;
            CEP                         => '1'                          ,--: in  std_logic;
            DSP_A_INV                   => '0'                          ,--: in  std_logic;

            DSP_A                       => dsp_a(N)                     ,--: in  std_logic_vector(WIDTH_A-1 downto 0);
            DSP_D                       => dsp_d(N)                     ,--: in  std_logic_vector(WIDTH_D-1 downto 0);
            DSP_B                       => dsp_b(N)                     ,--: in  std_logic_vector(WIDTH_B-1 downto 0);
            DSP_C                       => dsp_c(N)                     ,--: in  std_logic_vector(WIDTH_C-1 downto 0);

            DSP_PCIN                    => dsp_pcin(N)                  ,--: in  std_logic_vector(WIDTH_PCIN-1 downto 0);
            DSP_PCOUT                   => dsp_pcout(N)                 ,--: out std_logic_vector(WIDTH_PCOUT-1 downto 0);
            DSP_P                       => dsp_p(N)                      --: out std_logic_vector(WIDTH_P-1 downto 0)
        );
    end generate DSP_BLOCK_GEN;

    FRAME_O    <= '0';
    VALID_O    <= int_valid_d(int_valid_d'high);
    FILTER_OUT <= dsp_p(DSP_INSTANCES-1)(WIDTH_OUT+BINARY_POINT downto BINARY_POINT+1);


end rtl;