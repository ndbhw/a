-- Designer         : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part
-- Block Name       : DPD_CORE
-- Revision Histroy : 
--     15.10.27 - First Release
--     16.02.03 - Support HOVS1 or 2
--     16.03.04 - Support Binary Point Selection (Q point 12/13/14)
--     16.04.26 - Added LUT Configuration 37
--     16.05.20 - 2Path LUT Shared Structure
--     16.11.29 - 4Path LUT Shared Structure
--     19.11.22 - Added 41(= 29LUT2D + 6LUT_3D + 6DDRs)LUTs - 13TAPs

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

-- [Relation between DPD_LUT_NUM with DPD_TAP_NUM] 
-- -----------------------------
-- | DPD_LUT_NUM | DPD_TAP_NUM |
-- -----------------------------
-- |      4      |      2      |
-- -----------------------------
-- |      8      |      4      |
-- -----------------------------
-- |     16      |      8      |
-- -----------------------------
-- |     17      |     10      |
-- -----------------------------
-- |     20      |     10      |
-- -----------------------------
-- |     32      |     14      |
-- -----------------------------
-- |     37      |     19      |
-- -----------------------------
-- |     41      |     13      |
-- -----------------------------

entity DPD_CORE is
generic(
    DEVICE                     : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
   
    TX_ANT_NUM                 : natural :=           4 ;
    HOVS                       : natural :=           1 ; 

    DPD_LUT_OPTIMIZED          : boolean :=       FALSE ;
    DPD_LUT_MEM_DEPTH          : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    DPD_LUT_RBTEST             : boolean :=        TRUE ;
    DPD_CORE_QPOINT_SEL        : boolean :=       FALSE ;    
    DPD_CORE_LUT_DIMENSION     : string  :=         "2D"; -- "2D" or "3D"
    DPD_CORE_LUT_NUM           : natural :=          16 ;
    DPD_CORE_TAP_NUM           : natural :=           8 ; 
    DPD_CORE_RND_BIT           : natural :=          13 
    );
port(
    RST_DPD                    : in  std_logic;
    CLK_DPD                    : in  std_logic;

    DPD_CORE_VLD_IN            : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- DPD Core Input Sample Valid
    DPD_CORE_I_IN              : in  std_logic_array16(TX_ANT_NUM-1 downto 0);        -- DPD Core Input I Sample 
    DPD_CORE_Q_IN              : in  std_logic_array16(TX_ANT_NUM-1 downto 0);        -- DPD Core Input Q Sample 

    DPD_CORE_VLD_OUT           : out std_logic_vector( TX_ANT_NUM-1 downto 0);        -- DPD Core Output Sample Valid
    DPD_CORE_I_OUT             : out std_logic_array16(TX_ANT_NUM-1 downto 0);        -- DPD Core Output I Sample 
    DPD_CORE_Q_OUT             : out std_logic_array16(TX_ANT_NUM-1 downto 0);        -- DPD Core Output Q Sample 

    DPD_CORE_BYPASS_IN         : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- DPD Core Bypass

    DPD_GAIN_INDEX_IN          : in  std_logic_array2( TX_ANT_NUM-1 downto 0);        -- Input Signal Gain, x1/x2/x4
    DPD_QPOINT_SEL_IN          : in  std_logic_array2( TX_ANT_NUM-1 downto 0);        -- DPD Core Binary Point Selection

    RST_CPU                    : in  std_logic;
    CLK_CPU                    : in  std_logic;

    DPD_LUT_RB_TEST_EN_IN      : in  std_logic;                                       -- LUT Read Back Test

    DPD_LUT_SWITCH_CDC_STRB_IN : in  std_logic;                                       -- LUT Switch Control Register CDC Strobe
    DPD_LUT_INPUT_SWITCH_IN    : in  std_logic_vector(19 downto 0);                   -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN   : in  std_logic_vector(19 downto 0);                   -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN       : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN            : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_RDEN_IN            : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Read  Enable
    DPD_LUT_ADDR_IN            : in  std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN           : in  std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT          : out std_logic_array32(TX_ANT_NUM-1 downto 0)         -- LUT Write IQ : I[31:16]/Q[15:0]
    );
end DPD_CORE;

architecture arc_DPD_CORE of DPD_CORE is

--*******************************
-- Components                    
--*******************************
component RST_SYNC is
generic (
    DLY_NUM                     : natural :=  1 ; -- Number of delay.
    MAX_FANOUT_NUM              : integer := 20   -- Number of maximum fanout
    );
port (
    RST_IN                      : in  std_logic;   -- Active high asynchronous reset
    CLK                         : in  std_logic;   -- clock to be sync'ed to
    RST_OUT                     : out std_logic    -- "Synchronised" reset signal
    );         
end component;

component DPD_GAINMAG_N_LIMITER is
generic(
    DEVICE                     : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"

    HOVS                       : natural :=           1 ; 
    LUT_DIMENSION              : string  :=         "2D"; -- "2D" or "3D"
    LUT_MEM_DEPTH              : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    LUT_RAM_NUM                : natural :=          32
    );
port(
    RST                        : in  std_logic;
    CLK                        : in  std_logic;

    GAIN_INDEX_IN              : in  std_logic_vector( 1 downto 0);

    DATA_I_IN                  : in  std_logic_vector(15 downto 0);
    DATA_Q_IN                  : in  std_logic_vector(15 downto 0);

    DATA_MAG09_OUT             : out std_logic_vector( 8 downto 0);
    DATA_MAG15_OUT             : out std_logic_vector(14 downto 0);

    DATA_I_DDR_OUT             : out std_logic_vector(15 downto 0);
    DATA_Q_DDR_OUT             : out std_logic_vector(15 downto 0);
    
    DATA_I_LMT_DLY_OUT         : out std_logic_vector(15 downto 0);
    DATA_Q_LMT_DLY_OUT         : out std_logic_vector(15 downto 0)
    );
end component;

component DPD_LUT08_WRAPPER is
generic(
    DEVICE                   : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
    TX_ANT_NUM               : natural :=           4 ;
    HOVS                     : natural :=           1 ;
    HS_MODE                  : boolean :=       FALSE ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_MEM_DEPTH            : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    LUT_RBTEST               : boolean :=        TRUE ;
    LUT_RAM_NUM              : natural :=           8 ;
    DPD_TAP_NUM              : natural :=           4 
    );
port(
    RST_DPD                  : in  std_logic;
    CLK_DPD                  : in  std_logic;

    DATA_VLD_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DATA_MAG09_IN            : in  std_logic_array9( TX_ANT_NUM-1 downto 0);

    DPD_COEF_I_OUT           : out std_logic_array4_array27(TX_ANT_NUM-1 downto 0);
    DPD_COEF_Q_OUT           : out std_logic_array4_array27(TX_ANT_NUM-1 downto 0);

    RST_CPU                  : in  std_logic;
    CLK_CPU                  : in  std_logic;

    DPD_LUT_RB_TEST_EN_IN    : in  std_logic;                                       -- LUT Read Back Test

    DPD_CDC_STRB_IN          : in  std_logic;
    DPD_LUT_INPUT_SWITCH_IN  : in  std_logic_vector(19 downto 0);                   -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);                   -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN     : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_RDEN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Read  Enable
    DPD_LUT_ADDR_IN          : in  std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN         : in  std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT        : out std_logic_array32(TX_ANT_NUM-1 downto 0)         -- LUT Write IQ : I[31:16]/Q[15:0] 
    );
end component;

component DPD_LUT16_WRAPPER is
generic(
    DEVICE                   : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
    TX_ANT_NUM               : natural :=           4 ;
    HOVS                     : natural :=           1 ;
    HS_MODE                  : boolean :=       FALSE ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_MEM_DEPTH            : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    LUT_RBTEST               : boolean :=        TRUE ;
    LUT_RAM_NUM              : natural :=          16 ;
    DPD_TAP_NUM              : natural :=           8 
    );
port(
    RST_DPD                  : in  std_logic;
    CLK_DPD                  : in  std_logic;

    DATA_VLD_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DATA_MAG09_IN            : in  std_logic_array9( TX_ANT_NUM-1 downto 0);

    DPD_COEF_I_OUT           : out std_logic_array8_array27(TX_ANT_NUM-1 downto 0);
    DPD_COEF_Q_OUT           : out std_logic_array8_array27(TX_ANT_NUM-1 downto 0);

    RST_CPU                  : in  std_logic;
    CLK_CPU                  : in  std_logic;

    DPD_LUT_RB_TEST_EN_IN    : in  std_logic;                                       -- LUT Read Back Test

    DPD_CDC_STRB_IN          : in  std_logic;
    DPD_LUT_INPUT_SWITCH_IN  : in  std_logic_vector(19 downto 0);                   -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);                   -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN     : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_RDEN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Read  Enable
    DPD_LUT_ADDR_IN          : in  std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN         : in  std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT        : out std_logic_array32(TX_ANT_NUM-1 downto 0)         -- LUT Write IQ : I[31:16]/Q[15:0] 
    );
end component;

component DPD_LUT17_WRAPPER is
generic(
    DEVICE                   : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
    TX_ANT_NUM               : natural :=           4 ;
    HOVS                     : natural :=           1 ;
    HS_MODE                  : boolean :=       FALSE ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_MEM_DEPTH            : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    LUT_RBTEST               : boolean :=        TRUE ;
    LUT_RAM_NUM              : natural :=          17 ;
    DPD_TAP_NUM              : natural :=           8 
    );
port(
    RST_DPD                  : in  std_logic;
    CLK_DPD                  : in  std_logic;

    DATA_VLD_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DATA_MAG09_IN            : in  std_logic_array9( TX_ANT_NUM-1 downto 0);

    DPD_COEF_I_OUT           : out std_logic_array10_array27(TX_ANT_NUM-1 downto 0);
    DPD_COEF_Q_OUT           : out std_logic_array10_array27(TX_ANT_NUM-1 downto 0);

    RST_CPU                  : in  std_logic;
    CLK_CPU                  : in  std_logic;

    DPD_LUT_RB_TEST_EN_IN    : in  std_logic;                                       -- LUT Read Back Test

    DPD_CDC_STRB_IN          : in  std_logic;
    DPD_LUT_INPUT_SWITCH_IN  : in  std_logic_vector(19 downto 0);                   -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);                   -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN     : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_RDEN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_ADDR_IN          : in  std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN         : in  std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT        : out std_logic_array32(TX_ANT_NUM-1 downto 0)         -- LUT Write IQ : I[31:16]/Q[15:0] 
    );
end component;

component DPD_LUT20_WRAPPER is
generic(
    DEVICE                   : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
    TX_ANT_NUM               : natural :=           4 ;
    HOVS                     : natural :=           1 ;
    HS_MODE                  : boolean :=       FALSE ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_MEM_DEPTH            : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    LUT_RBTEST               : boolean :=        TRUE ;
    LUT_RAM_NUM              : natural :=          20 ;
    DPD_TAP_NUM              : natural :=          10 
    );
port(
    RST_DPD                  : in  std_logic;
    CLK_DPD                  : in  std_logic;

    DATA_VLD_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DATA_MAG09_IN            : in  std_logic_array9( TX_ANT_NUM-1 downto 0);

    DPD_COEF_I_OUT           : out std_logic_array10_array27(TX_ANT_NUM-1 downto 0);
    DPD_COEF_Q_OUT           : out std_logic_array10_array27(TX_ANT_NUM-1 downto 0);

    RST_CPU                  : in  std_logic;
    CLK_CPU                  : in  std_logic;

    DPD_LUT_RB_TEST_EN_IN    : in  std_logic;                                       -- LUT Read Back Test

    DPD_CDC_STRB_IN          : in  std_logic;
    DPD_LUT_INPUT_SWITCH_IN  : in  std_logic_vector(19 downto 0);                   -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);                   -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN     : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_RDEN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_ADDR_IN          : in  std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN         : in  std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT        : out std_logic_array32(TX_ANT_NUM-1 downto 0)         -- LUT Write IQ : I[31:16]/Q[15:0] 
    );
end component;

component DPD_LUT10_WRAPPER is
generic(
    DEVICE                   : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
    TX_ANT_NUM               : natural :=           4 ;
    HOVS                     : natural :=           1 ;
    HS_MODE                  : boolean :=       FALSE ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_MEM_DEPTH            : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    LUT_RBTEST               : boolean :=        TRUE ;
    LUT_RAM_NUM              : natural :=          20 ;
    DPD_TAP_NUM              : natural :=          10 
    );
port(
    RST_DPD                  : in  std_logic;
    CLK_DPD                  : in  std_logic;

    DATA_VLD_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DATA_MAG09_IN            : in  std_logic_array9( TX_ANT_NUM-1 downto 0);

    DPD_COEF_I_OUT           : out std_logic_array10_array27(TX_ANT_NUM-1 downto 0);
    DPD_COEF_Q_OUT           : out std_logic_array10_array27(TX_ANT_NUM-1 downto 0);

    RST_CPU                  : in  std_logic;
    CLK_CPU                  : in  std_logic;

    DPD_LUT_RB_TEST_EN_IN    : in  std_logic;                                       -- LUT Read Back Test

    DPD_CDC_STRB_IN          : in  std_logic;
    DPD_LUT_INPUT_SWITCH_IN  : in  std_logic_vector(19 downto 0);                   -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);                   -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN     : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_RDEN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_ADDR_IN          : in  std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN         : in  std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT        : out std_logic_array32(TX_ANT_NUM-1 downto 0)         -- LUT Write IQ : I[31:16]/Q[15:0] 
    );
end component;

component DPD_LUT32_WRAPPER is
generic(
    DEVICE                   : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
    TX_ANT_NUM               : natural :=           4 ;
    HOVS                     : natural :=           1 ;
    HS_MODE                  : boolean :=       FALSE ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_MEM_DEPTH            : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    LUT_RBTEST               : boolean :=        TRUE ;
    LUT_RAM_NUM              : natural :=          32 ;
    DPD_TAP_NUM              : natural :=          14 
    );
port(
    RST_DPD                  : in  std_logic;
    CLK_DPD                  : in  std_logic;

    DATA_VLD_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DATA_MAG09_IN            : in  std_logic_array9( TX_ANT_NUM-1 downto 0);

    DPD_COEF_I_OUT           : out std_logic_array14_array27(TX_ANT_NUM-1 downto 0);
    DPD_COEF_Q_OUT           : out std_logic_array14_array27(TX_ANT_NUM-1 downto 0);

    RST_CPU                  : in  std_logic;
    CLK_CPU                  : in  std_logic;

    DPD_LUT_RB_TEST_EN_IN    : in  std_logic;                                       -- LUT Read Back Test

    DPD_CDC_STRB_IN          : in  std_logic;
    DPD_LUT_INPUT_SWITCH_IN  : in  std_logic_vector(19 downto 0);                   -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);                   -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN     : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);                                       -- LUT Write Enable
    DPD_LUT_RDEN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);                                       -- LUT Read  Enable
    DPD_LUT_ADDR_IN          : in  std_logic_array15(TX_ANT_NUM-1 downto 0);                   -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN         : in  std_logic_array32(TX_ANT_NUM-1 downto 0);                   -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT        : out std_logic_array32(TX_ANT_NUM-1 downto 0)                    -- LUT Write IQ : I[31:16]/Q[15:0] 
    );
end component;

component DPD_3D_LUT32_WRAPPER is
generic(
    DEVICE                   : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
    TX_ANT_NUM               : natural :=           4 ;
    HOVS                     : natural :=           1 ;
    HS_MODE                  : boolean :=       FALSE ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_MEM_DEPTH            : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    LUT_RBTEST               : boolean :=        TRUE ;
    LUT_RAM_NUM              : natural :=          32 ;
    DPD_TAP_NUM              : natural :=          13 
    );
port(
    RST_DPD                  : in  std_logic;
    CLK_DPD                  : in  std_logic;

    DATA_VLD_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DATA_MAG09_IN            : in  std_logic_array9( TX_ANT_NUM-1 downto 0);
    DATA_MAG15_IN            : in  std_logic_array15(TX_ANT_NUM-1 downto 0);

    DPD_COEF_I_OUT           : out std_logic_array13_array27(TX_ANT_NUM-1 downto 0);
    DPD_COEF_Q_OUT           : out std_logic_array13_array27(TX_ANT_NUM-1 downto 0);

    RST_CPU                  : in  std_logic;
    CLK_CPU                  : in  std_logic;

    DPD_LUT_RB_TEST_EN_IN    : in  std_logic;                                       -- LUT Read Back Test

    DPD_CDC_STRB_IN          : in  std_logic;
    DPD_LUT_INPUT_SWITCH_IN  : in  std_logic_vector(19 downto 0);                   -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);                   -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN     : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);                                       -- LUT Write Enable
    DPD_LUT_RDEN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);                                       -- LUT Read  Enable
    DPD_LUT_ADDR_IN          : in  std_logic_array15(TX_ANT_NUM-1 downto 0);                   -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN         : in  std_logic_array32(TX_ANT_NUM-1 downto 0);                   -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT        : out std_logic_array32(TX_ANT_NUM-1 downto 0)                    -- LUT Write IQ : I[31:16]/Q[15:0] 
    );
end component;

component DPD_3D_LUT35_WRAPPER is
generic(
    DEVICE                   : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
    TX_ANT_NUM               : natural :=           4 ;
    HOVS                     : natural :=           1 ;
    HS_MODE                  : boolean :=       FALSE ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_MEM_DEPTH            : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    LUT_RBTEST               : boolean :=        TRUE ;
    LUT_RAM_NUM              : natural :=          35 ;
    DPD_TAP_NUM              : natural :=          13 
    );
port(
    RST_DPD                  : in  std_logic;
    CLK_DPD                  : in  std_logic;

    DATA_VLD_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DATA_MAG09_IN            : in  std_logic_array9( TX_ANT_NUM-1 downto 0);
    DATA_MAG15_IN            : in  std_logic_array15(TX_ANT_NUM-1 downto 0);

    DPD_COEF_I_OUT           : out std_logic_array13_array27(TX_ANT_NUM-1 downto 0);
    DPD_COEF_Q_OUT           : out std_logic_array13_array27(TX_ANT_NUM-1 downto 0);

    RST_CPU                  : in  std_logic;
    CLK_CPU                  : in  std_logic;

    DPD_LUT_RB_TEST_EN_IN    : in  std_logic;                                       -- LUT Read Back Test

    DPD_CDC_STRB_IN          : in  std_logic;
    DPD_LUT_INPUT_SWITCH_IN  : in  std_logic_vector(19 downto 0);                   -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);                   -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN     : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);                                       -- LUT Write Enable
    DPD_LUT_RDEN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);                                       -- LUT Read  Enable
    DPD_LUT_ADDR_IN          : in  std_logic_array15(TX_ANT_NUM-1 downto 0);                   -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN         : in  std_logic_array32(TX_ANT_NUM-1 downto 0);                   -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT        : out std_logic_array32(TX_ANT_NUM-1 downto 0)                    -- LUT Write IQ : I[31:16]/Q[15:0] 
    );
end component;

component DPD_3D_LUT41_WRAPPER is
generic(
    DEVICE                   : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
    TX_ANT_NUM               : natural :=           4 ;
    HOVS                     : natural :=           1 ;
    HS_MODE                  : boolean :=       FALSE ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_MEM_DEPTH            : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    LUT_RBTEST               : boolean :=        TRUE ;
    LUT_RAM_NUM              : natural :=          41 ;
    DPD_TAP_NUM              : natural :=          13 
    );
port(
    RST_DPD                  : in  std_logic;
    CLK_DPD                  : in  std_logic;

    DATA_VLD_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DATA_MAG09_IN            : in  std_logic_array9( TX_ANT_NUM-1 downto 0);
    DATA_MAG15_IN            : in  std_logic_array15(TX_ANT_NUM-1 downto 0);

    DATA_I_IN                : in  std_logic_array16(TX_ANT_NUM-1 downto 0); 
    DATA_Q_IN                : in  std_logic_array16(TX_ANT_NUM-1 downto 0); 

    DPD_COEF_I_OUT           : out std_logic_array13_array27(TX_ANT_NUM-1 downto 0);
    DPD_COEF_Q_OUT           : out std_logic_array13_array27(TX_ANT_NUM-1 downto 0);

    RST_CPU                  : in  std_logic;
    CLK_CPU                  : in  std_logic;

    DPD_LUT_RB_TEST_EN_IN    : in  std_logic;                                       -- LUT Read Back Test

    DPD_CDC_STRB_IN          : in  std_logic;
    DPD_LUT_INPUT_SWITCH_IN  : in  std_logic_vector(19 downto 0);                   -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);                   -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN     : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_RDEN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_ADDR_IN          : in  std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN         : in  std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT        : out std_logic_array32(TX_ANT_NUM-1 downto 0)         -- LUT Write IQ : I[31:16]/Q[15:0] 
    );
end component;

component DPD_3D_LUT44_WRAPPER is
generic(
    DEVICE                   : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
    TX_ANT_NUM               : natural :=           4 ;
    HOVS                     : natural :=           1 ;
    HS_MODE                  : boolean :=       FALSE ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_MEM_DEPTH            : string  :=       "HALF"; -- "FULL": 32x512x2, "HALF": 32x256x2
    LUT_RBTEST               : boolean :=        TRUE ;
    LUT_RAM_NUM              : natural :=          44 ;
    DPD_TAP_NUM              : natural :=          13 
    );
port(
    RST_DPD                  : in  std_logic;
    CLK_DPD                  : in  std_logic;

    DATA_VLD_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DATA_MAG09_IN            : in  std_logic_array9( TX_ANT_NUM-1 downto 0);
    DATA_MAG15_IN            : in  std_logic_array15(TX_ANT_NUM-1 downto 0);

    DATA_I_IN                : in  std_logic_array16(TX_ANT_NUM-1 downto 0); 
    DATA_Q_IN                : in  std_logic_array16(TX_ANT_NUM-1 downto 0); 

    DPD_COEF_I_OUT           : out std_logic_array10_array27(TX_ANT_NUM-1 downto 0);
    DPD_COEF_Q_OUT           : out std_logic_array10_array27(TX_ANT_NUM-1 downto 0);

    RST_CPU                  : in  std_logic;
    CLK_CPU                  : in  std_logic;

    DPD_LUT_RB_TEST_EN_IN    : in  std_logic;                                       -- LUT Read Back Test

    DPD_CDC_STRB_IN          : in  std_logic;
    DPD_LUT_INPUT_SWITCH_IN  : in  std_logic_vector(19 downto 0);                   -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN : in  std_logic_vector(19 downto 0);                   -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN     : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_RDEN_IN          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_ADDR_IN          : in  std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN         : in  std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT        : out std_logic_array32(TX_ANT_NUM-1 downto 0)         -- LUT Write IQ : I[31:16]/Q[15:0] 
    );
end component;

component COMPLEX_FIR_FILTER_HOVS1 is
generic(
    HS_MODE                  : boolean :=     TRUE ; 
    DEVICE                   : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    TAP_NUM                  : natural :=        8 ; 
    RND_BIT                  : integer :=       13
    );
port(
    RST                      : in  std_logic;
    CLK                      : in  std_logic;

    COEF_I_IN                : in  std_logic_array27(TAP_NUM-1 downto 0);
    COEF_Q_IN                : in  std_logic_array27(TAP_NUM-1 downto 0);

    DATA_VLD_IN              : in  std_logic;
    DATA_I_IN                : in  std_logic_vector(15 downto 0);
    DATA_Q_IN                : in  std_logic_vector(15 downto 0);

    DATA_VLD_OUT             : out std_logic;
    DATA_I_OUT               : out std_logic_vector(15 downto 0);
    DATA_Q_OUT               : out std_logic_vector(15 downto 0)
    );
end component;

component COMPLEX_FIR_FILTER_HOVS2  is
generic(
    DEVICE                   : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    TAP_NUM                  : natural :=  8;
    RND_BIT                  : integer := 13
    );
port(
    RST                      : in  std_logic;
    CLK                      : in  std_logic;

    COEF_I_IN                : in  std_logic_array27(TAP_NUM-1 downto 0);
    COEF_Q_IN                : in  std_logic_array27(TAP_NUM-1 downto 0);

    DATA_VLD_IN              : in  std_logic;
    DATA_I_IN                : in  std_logic_vector(15 downto 0);
    DATA_Q_IN                : in  std_logic_vector(15 downto 0);

    DATA_VLD_OUT             : out std_logic;
    DATA_I_OUT               : out std_logic_vector(15 downto 0);
    DATA_Q_OUT               : out std_logic_vector(15 downto 0)
    );
end component;

component COMPLEX_FIR_FILTER_HOVS1_Q_POINT_SEL is
generic(
    HS_MODE                  : boolean :=     TRUE ; 
    DEVICE                   : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    BASE_RND_BIT             : natural :=       13 ;
    TAP_NUM                  : natural :=        8 
    );
port(
    RST                      : in  std_logic;
    CLK                      : in  std_logic;

    Q_POINT_SEL_IN           : in  std_logic_vector( 1 downto 0); 

    COEF_I_IN                : in  std_logic_array27(TAP_NUM-1 downto 0);
    COEF_Q_IN                : in  std_logic_array27(TAP_NUM-1 downto 0);

    DATA_VLD_IN              : in  std_logic;
    DATA_I_IN                : in  std_logic_vector(15 downto 0);
    DATA_Q_IN                : in  std_logic_vector(15 downto 0);

    DATA_VLD_OUT             : out std_logic;
    DATA_I_OUT               : out std_logic_vector(15 downto 0);
    DATA_Q_OUT               : out std_logic_vector(15 downto 0)
    );
end component;

component COMPLEX_FIR_FILTER_HOVS2_Q_POINT_SEL  is
generic(
    DEVICE                   : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    BASE_RND_BIT             : natural :=       13 ;
    TAP_NUM                  : natural :=        8
    );
port(
    RST                      : in  std_logic;
    CLK                      : in  std_logic;

    Q_POINT_SEL_IN           : in  std_logic_vector( 1 downto 0); 

    COEF_I_IN                : in  std_logic_array27(TAP_NUM-1 downto 0);
    COEF_Q_IN                : in  std_logic_array27(TAP_NUM-1 downto 0);

    DATA_VLD_IN              : in  std_logic;
    DATA_I_IN                : in  std_logic_vector(15 downto 0);
    DATA_Q_IN                : in  std_logic_vector(15 downto 0);

    DATA_VLD_OUT             : out std_logic;
    DATA_I_OUT               : out std_logic_vector(15 downto 0);
    DATA_Q_OUT               : out std_logic_vector(15 downto 0)
    );
end component;


--*****************************
-- Constants
--*****************************

--*****************************
-- Array Type 
--*****************************

--*****************************
-- Signals
--*****************************
signal rst_gidx_lmt            : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal rst_dpdcore             : std_logic;
signal rst_lutwrap             : std_logic;
signal rst_complex_filter      : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal rst_synch_cpu           : std_logic;

signal data_vld                : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal data_i_align            : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal data_q_align            : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal data_magn09             : std_logic_array9( TX_ANT_NUM-1 downto 0);
signal data_magn15             : std_logic_array15(TX_ANT_NUM-1 downto 0);

signal data_i_ddr_sh           : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal data_q_ddr_sh           : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal data_i_lmt_sh           : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal data_q_lmt_sh           : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal magnitude09             : std_logic_array9( TX_ANT_NUM-1 downto 0);
signal magnitude15             : std_logic_array15(TX_ANT_NUM-1 downto 0);

signal dpd_coef_4taps_i        : std_logic_array4_array27( TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0')));
signal dpd_coef_4taps_q        : std_logic_array4_array27( TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0')));
                                                                                                                              
signal dpd_coef_8taps_i        : std_logic_array8_array27( TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0')));
signal dpd_coef_8taps_q        : std_logic_array8_array27( TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0')));
        
signal dpd_coef_10taps_i       : std_logic_array10_array27(TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0')));
signal dpd_coef_10taps_q       : std_logic_array10_array27(TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0')));
        
signal dpd_coef_13taps_i       : std_logic_array13_array27(TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0')));
signal dpd_coef_13taps_q       : std_logic_array13_array27(TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0')));
        
signal dpd_coef_14taps_i       : std_logic_array14_array27(TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0')));
signal dpd_coef_14taps_q       : std_logic_array14_array27(TX_ANT_NUM-1 downto 0) := (others => (others => (others => '0')));
        
signal dpd_core_bypass_sh      : std_logic_array3( TX_ANT_NUM-1 downto 0);        

signal dpd_core_out_vld        : std_logic_vector( TX_ANT_NUM-1 downto 0);        
signal dpd_core_out_i          : std_logic_array16(TX_ANT_NUM-1 downto 0);        
signal dpd_core_out_q          : std_logic_array16(TX_ANT_NUM-1 downto 0);       

signal s_dpd_lut_rb_test_en_in      : std_logic;                                       -- LUT Read Back Test
signal s_dpd_lut_switch_cdc_strb_in : std_logic;                                       -- LUT Switch Control Register CDC Strobe
signal s_dpd_lut_input_switch_in    : std_logic_vector(19 downto 0);                   -- LUT Input Mux Control
signal s_dpd_lut_output_switch_in   : std_logic_vector(19 downto 0);                   -- LUT Output Switch Control
signal s_dpd_lut_update_sw_in       : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal s_dpd_lut_wren_in            : std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
signal s_dpd_lut_rden_in            : std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Read  Enable
signal s_dpd_lut_addr_in            : std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
signal s_dpd_lut_wdata_in           : std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
signal s_dpd_lut_rdata_out          : std_logic_array32(TX_ANT_NUM-1 downto 0);         -- LUT Write IQ : I[31:16]/Q[15:0]


begin

    --*******************************
    -- Resets
    --*******************************
    G_Reset_DL_Path_GEN : for I in 0 to (TX_ANT_NUM-1) generate begin
        U_RST_Gidx_LMT       : RST_SYNC generic map(8, 100) port map(RST_DPD, CLK_DPD, rst_gidx_lmt(I));
        U_RST_Complex_Filter : RST_SYNC generic map(8, 100) port map(RST_DPD, CLK_DPD, rst_complex_filter(I));
    end generate;

    U_RST_Core_Global  : RST_SYNC generic map(8, 100) port map(RST_DPD, CLK_DPD, rst_dpdcore  );
    U_RST_Core_LUTWRAP : RST_SYNC generic map(8, 100) port map(RST_DPD, CLK_DPD, rst_lutwrap  );

    U_RST_Core_CPU     : RST_SYNC generic map(8, 100) port map(RST_CPU, CLK_CPU, rst_synch_cpu);

    P_IN_CPUIF : process ( CLK_DPD ) begin
        if ( rising_edge(CLK_DPD) ) then
            s_dpd_lut_rb_test_en_in         <= DPD_LUT_RB_TEST_EN_IN         ; 
            s_dpd_lut_switch_cdc_strb_in    <= DPD_LUT_SWITCH_CDC_STRB_IN    ;
            s_dpd_lut_input_switch_in       <= DPD_LUT_INPUT_SWITCH_IN       ;
            s_dpd_lut_output_switch_in      <= DPD_LUT_OUTPUT_SWITCH_IN      ;
            s_dpd_lut_update_sw_in          <= DPD_LUT_UPDATE_SW_IN          ;
            s_dpd_lut_wren_in               <= DPD_LUT_WREN_IN               ;
            s_dpd_lut_rden_in               <= DPD_LUT_RDEN_IN               ;
            s_dpd_lut_addr_in               <= DPD_LUT_ADDR_IN               ;
            s_dpd_lut_wdata_in              <= DPD_LUT_WDATA_IN              ;
            DPD_LUT_RDATA_OUT               <= s_dpd_lut_rdata_out           ;
        end if;
    end process;

    --*******************************
    -- Sample Align with Valid
    --*******************************

    G_Data_Align_DL_Path_GEN : for I in 0 to (TX_ANT_NUM-1) generate begin

        G_Data_Align_HOVS1 : if (HOVS = 1) generate begin
            data_vld(I)     <= '1';             
            data_i_align(I) <= DPD_CORE_I_IN(I); 
            data_q_align(I) <= DPD_CORE_Q_IN(I); 
        end generate;

        G_Data_Align_HOVSn : if (HOVS > 1) generate begin
            P_IQ_Data_Align_NM : process(rst_dpdcore, CLK_DPD) begin
                if (rst_dpdcore = '1') then
                    data_vld(I)     <= '0';             
                    data_i_align(I) <= (others => '0'); 
                    data_q_align(I) <= (others => '0'); 
                elsif (CLK_DPD'event) and (CLK_DPD = '1') then
                    data_vld(I)     <= DPD_CORE_VLD_IN(I);             
                    if (DPD_CORE_VLD_IN(I) = '1') then
                        data_i_align(I) <= DPD_CORE_I_IN(I); 
                        data_q_align(I) <= DPD_CORE_Q_IN(I); 
                    else
                        data_i_align(I) <= data_i_align(I); 
                        data_q_align(I) <= data_q_align(I); 
                    end if;
                end if;
            end process;

        end generate;

    end generate;

    --*******************************
    -- Input Gain, Limiter, Magnitude
    --*******************************
    G_Input_Gain_Limit_MAG_DL_Path_GEN : for I in 0 to (TX_ANT_NUM-1) generate begin

        U_Gain_Magnitude_N_Limiter : DPD_GAINMAG_N_LIMITER 
        generic map(
            DEVICE                       => DEVICE                , 

            HOVS                         => HOVS                  , 
            LUT_DIMENSION                => DPD_CORE_LUT_DIMENSION,
            LUT_MEM_DEPTH                => DPD_LUT_MEM_DEPTH     , 
            LUT_RAM_NUM                  => DPD_CORE_LUT_NUM      
            )
        port map(
            RST                          => rst_gidx_lmt(I)       , 
            CLK                          => CLK_DPD               , 
        
            GAIN_INDEX_IN                => DPD_GAIN_INDEX_IN(I)  , 
        
            DATA_I_IN                    => data_i_align(I)       , 
            DATA_Q_IN                    => data_q_align(I)       , 
        
            DATA_MAG09_OUT               => data_magn09(I)        , 
            DATA_MAG15_OUT               => data_magn15(I)        , 

            DATA_I_DDR_OUT               => data_i_ddr_sh(I)      , 
            DATA_Q_DDR_OUT               => data_q_ddr_sh(I)      , 
    
            DATA_I_LMT_DLY_OUT           => data_i_lmt_sh(I)      , 
            DATA_Q_LMT_DLY_OUT           => data_q_lmt_sh(I)    
            );

        P_Magnitude : process(CLK_DPD) begin
            if (CLK_DPD'event) and (CLK_DPD = '1') then
                magnitude09(I) <= data_magn09(I);
                magnitude15(I) <= data_magn15(I);
            end if;
        end process;
	
    end generate;

    --*******************************
    -- DPD 2D LUT Configuration
    --*******************************

    G_DPD_2D_LUT_CONFIG : if (DPD_CORE_LUT_DIMENSION = "2D") generate begin

        dpd_coef_13taps_i <= (others => (others => (others => '0')));
        dpd_coef_13taps_q <= (others => (others => (others => '0')));
        
        G_DPD_LUT8_TAP4_Configuration : if ((DPD_CORE_LUT_NUM = 8) and (DPD_CORE_TAP_NUM = 4)) generate begin

            U_DPD_LUT08_WRAPPER : DPD_LUT08_WRAPPER 
            generic map(
                DEVICE                   => DEVICE                    ,
                TX_ANT_NUM               => TX_ANT_NUM                , 
                HOVS                     => HOVS                      , 
                HS_MODE                  => TRUE                      , 
                LUT_OPTIMIZED            => DPD_LUT_OPTIMIZED         ,
                LUT_MEM_DEPTH            => DPD_LUT_MEM_DEPTH         ,
                LUT_RBTEST               => DPD_LUT_RBTEST            , 
                LUT_RAM_NUM              => DPD_CORE_LUT_NUM          , 
                DPD_TAP_NUM              => DPD_CORE_TAP_NUM            
                )
            port map(
                RST_DPD                  => rst_lutwrap               , 
                CLK_DPD                  => CLK_DPD                   , 
            
                DATA_VLD_IN              => data_vld                  , 
                DATA_MAG09_IN            => magnitude09               , 
            
                DPD_COEF_I_OUT           => dpd_coef_4taps_i          , 
                DPD_COEF_Q_OUT           => dpd_coef_4taps_q          , 
            
                RST_CPU                  => rst_synch_cpu             , 
                CLK_CPU                  => CLK_CPU                   , 
            
                DPD_LUT_RB_TEST_EN_IN    => s_dpd_lut_rb_test_en_in     , 
                                                                     
                DPD_CDC_STRB_IN          => s_dpd_lut_switch_cdc_strb_in,
                DPD_LUT_INPUT_SWITCH_IN  => s_dpd_lut_input_switch_in   , 
                DPD_LUT_OUTPUT_SWITCH_IN => s_dpd_lut_output_switch_in  , 

                DPD_LUT_UPDATE_SW_IN     => s_dpd_lut_update_sw_in      ,
                DPD_LUT_WREN_IN          => s_dpd_lut_wren_in           , 
                DPD_LUT_RDEN_IN          => s_dpd_lut_rden_in           , 
                DPD_LUT_ADDR_IN          => s_dpd_lut_addr_in           , 
                DPD_LUT_WDATA_IN         => s_dpd_lut_wdata_in          , 
                DPD_LUT_RDATA_OUT        => s_dpd_lut_rdata_out         
                );

            dpd_coef_8taps_i  <= (others => (others => (others => '0')));         
            dpd_coef_8taps_q  <= (others => (others => (others => '0')));         

            dpd_coef_10taps_i <= (others => (others => (others => '0')));
            dpd_coef_10taps_q <= (others => (others => (others => '0')));
             
            dpd_coef_14taps_i <= (others => (others => (others => '0')));         
            dpd_coef_14taps_q <= (others => (others => (others => '0')));         
            
        end generate;

        G_DPD_LUT16_TAP8_Configuration : if ((DPD_CORE_LUT_NUM = 16) and (DPD_CORE_TAP_NUM = 8)) generate begin

            U_DPD_LUT16_WRAPPER : DPD_LUT16_WRAPPER 
            generic map(
                DEVICE                   => DEVICE                    ,
                TX_ANT_NUM               => TX_ANT_NUM                , 
                HOVS                     => HOVS                      , 
                HS_MODE                  => TRUE                      , 
                LUT_OPTIMIZED            => DPD_LUT_OPTIMIZED         ,
                LUT_MEM_DEPTH            => DPD_LUT_MEM_DEPTH         ,
                LUT_RBTEST               => DPD_LUT_RBTEST            , 
                LUT_RAM_NUM              => DPD_CORE_LUT_NUM          , 
                DPD_TAP_NUM              => DPD_CORE_TAP_NUM            
                )
            port map(
                RST_DPD                  => rst_lutwrap               , 
                CLK_DPD                  => CLK_DPD                   , 
                                                                      
                DATA_VLD_IN              => data_vld                  , 
                DATA_MAG09_IN            => magnitude09               , 
            
                DPD_COEF_I_OUT           => dpd_coef_8taps_i          , 
                DPD_COEF_Q_OUT           => dpd_coef_8taps_q          , 
            
                RST_CPU                  => rst_synch_cpu             , 
                CLK_CPU                  => CLK_CPU                   , 
                                                                      
                DPD_LUT_RB_TEST_EN_IN    => s_dpd_lut_rb_test_en_in     , 
                                                                    
                DPD_CDC_STRB_IN          => s_dpd_lut_switch_cdc_strb_in,
                DPD_LUT_INPUT_SWITCH_IN  => s_dpd_lut_input_switch_in   , 
                DPD_LUT_OUTPUT_SWITCH_IN => s_dpd_lut_output_switch_in  , 
                                                                    
                DPD_LUT_UPDATE_SW_IN     => s_dpd_lut_update_sw_in      ,
                DPD_LUT_WREN_IN          => s_dpd_lut_wren_in           , 
                DPD_LUT_RDEN_IN          => s_dpd_lut_rden_in           , 
                DPD_LUT_ADDR_IN          => s_dpd_lut_addr_in           , 
                DPD_LUT_WDATA_IN         => s_dpd_lut_wdata_in          , 
                DPD_LUT_RDATA_OUT        => s_dpd_lut_rdata_out          
                );

            dpd_coef_4taps_i  <= (others => (others => (others => '0')));         
            dpd_coef_4taps_q  <= (others => (others => (others => '0')));         

            dpd_coef_10taps_i <= (others => (others => (others => '0')));
            dpd_coef_10taps_q <= (others => (others => (others => '0')));
             
            dpd_coef_14taps_i <= (others => (others => (others => '0')));         
            dpd_coef_14taps_q <= (others => (others => (others => '0')));         
            
        end generate;

        G_DPD_LUT17_TAP8_Configuration : if ((DPD_CORE_LUT_NUM = 17) and (DPD_CORE_TAP_NUM = 10)) generate begin

            U_DPD_LUT17_WRAPPER : DPD_LUT17_WRAPPER 
            generic map(
                DEVICE                   => DEVICE                    ,
                TX_ANT_NUM               => TX_ANT_NUM                , 
                HOVS                     => HOVS                      , 
                HS_MODE                  => TRUE                      , 
                LUT_OPTIMIZED            => DPD_LUT_OPTIMIZED         ,
                LUT_MEM_DEPTH            => DPD_LUT_MEM_DEPTH         ,
                LUT_RBTEST               => DPD_LUT_RBTEST            , 
                LUT_RAM_NUM              => DPD_CORE_LUT_NUM          , 
                DPD_TAP_NUM              => DPD_CORE_TAP_NUM            
                )
            port map(
                RST_DPD                  => rst_lutwrap               , 
                CLK_DPD                  => CLK_DPD                   , 
                                                                      
                DATA_VLD_IN              => data_vld                  , 
                DATA_MAG09_IN            => magnitude09               , 
            
                DPD_COEF_I_OUT           => dpd_coef_10taps_i         , 
                DPD_COEF_Q_OUT           => dpd_coef_10taps_q         , 
            
                RST_CPU                  => rst_synch_cpu             , 
                CLK_CPU                  => CLK_CPU                   , 
                                                                      
                DPD_LUT_RB_TEST_EN_IN    => s_dpd_lut_rb_test_en_in     , 
                                                                    
                DPD_CDC_STRB_IN          => s_dpd_lut_switch_cdc_strb_in,
                DPD_LUT_INPUT_SWITCH_IN  => s_dpd_lut_input_switch_in   , 
                DPD_LUT_OUTPUT_SWITCH_IN => s_dpd_lut_output_switch_in  , 
                                                                    
                DPD_LUT_UPDATE_SW_IN     => s_dpd_lut_update_sw_in      ,
                DPD_LUT_WREN_IN          => s_dpd_lut_wren_in           , 
                DPD_LUT_RDEN_IN          => s_dpd_lut_rden_in           , 
                DPD_LUT_ADDR_IN          => s_dpd_lut_addr_in           , 
                DPD_LUT_WDATA_IN         => s_dpd_lut_wdata_in          , 
                DPD_LUT_RDATA_OUT        => s_dpd_lut_rdata_out          
                );

            dpd_coef_4taps_i  <= (others => (others => (others => '0')));         
            dpd_coef_4taps_q  <= (others => (others => (others => '0')));         
             
            dpd_coef_8taps_i  <= (others => (others => (others => '0')));
            dpd_coef_8taps_q  <= (others => (others => (others => '0')));
             
            dpd_coef_14taps_i <= (others => (others => (others => '0')));         
            dpd_coef_14taps_q <= (others => (others => (others => '0')));         
            
        end generate;

        G_DPD_LUT20_TAP10_Configuration : if ((DPD_CORE_LUT_NUM = 20) and (DPD_CORE_TAP_NUM = 10)) generate begin

            U_DPD_LUT20_WRAPPER : DPD_LUT20_WRAPPER 
            generic map(
                DEVICE                   => DEVICE                    , 
                TX_ANT_NUM               => TX_ANT_NUM                , 
                HOVS                     => HOVS                      , 
                HS_MODE                  => TRUE                      , 
                LUT_OPTIMIZED            => DPD_LUT_OPTIMIZED         ,
                LUT_MEM_DEPTH            => DPD_LUT_MEM_DEPTH         ,
                LUT_RBTEST               => DPD_LUT_RBTEST            , 
                LUT_RAM_NUM              => DPD_CORE_LUT_NUM          , 
                DPD_TAP_NUM              => DPD_CORE_TAP_NUM           
                )                                                     
            port map(                                                 
                RST_DPD                  => rst_lutwrap               , 
                CLK_DPD                  => CLK_DPD                   , 
                                                                      
                DATA_VLD_IN              => data_vld                  , 
                DATA_MAG09_IN            => magnitude09               , 
                                                                      
                DPD_COEF_I_OUT           => dpd_coef_10taps_i         , 
                DPD_COEF_Q_OUT           => dpd_coef_10taps_q         , 
                                                                      
                RST_CPU                  => rst_synch_cpu             , 
                CLK_CPU                  => CLK_CPU                   , 
                                                                      
                DPD_LUT_RB_TEST_EN_IN    => s_dpd_lut_rb_test_en_in     , 
                                                                    
                DPD_CDC_STRB_IN          => s_dpd_lut_switch_cdc_strb_in, 
                DPD_LUT_INPUT_SWITCH_IN  => s_dpd_lut_input_switch_in   , 
                DPD_LUT_OUTPUT_SWITCH_IN => s_dpd_lut_output_switch_in  , 
                                                                     
                DPD_LUT_UPDATE_SW_IN     => s_dpd_lut_update_sw_in      ,
                DPD_LUT_WREN_IN          => s_dpd_lut_wren_in           , 
                DPD_LUT_RDEN_IN          => s_dpd_lut_rden_in           , 
                DPD_LUT_ADDR_IN          => s_dpd_lut_addr_in           , 
                DPD_LUT_WDATA_IN         => s_dpd_lut_wdata_in          , 
                DPD_LUT_RDATA_OUT        => s_dpd_lut_rdata_out          
                );

            dpd_coef_4taps_i  <= (others => (others => (others => '0')));         
            dpd_coef_4taps_q  <= (others => (others => (others => '0')));         
             
            dpd_coef_8taps_i  <= (others => (others => (others => '0')));
            dpd_coef_8taps_q  <= (others => (others => (others => '0')));
             
            dpd_coef_14taps_i <= (others => (others => (others => '0')));         
            dpd_coef_14taps_q <= (others => (others => (others => '0')));         
            
        end generate;

        G_DPD_LUT10_TAP10_Configuration : if ((DPD_CORE_LUT_NUM = 10) and (DPD_CORE_TAP_NUM = 10)) generate begin

            U_DPD_LUT10_WRAPPER : DPD_LUT10_WRAPPER 
            generic map(
                DEVICE                   => DEVICE                    , 
                TX_ANT_NUM               => TX_ANT_NUM                , 
                HOVS                     => HOVS                      , 
                HS_MODE                  => TRUE                      , 
                LUT_OPTIMIZED            => DPD_LUT_OPTIMIZED         ,
                LUT_MEM_DEPTH            => DPD_LUT_MEM_DEPTH         ,
                LUT_RBTEST               => DPD_LUT_RBTEST            , 
                LUT_RAM_NUM              => DPD_CORE_LUT_NUM          , 
                DPD_TAP_NUM              => DPD_CORE_TAP_NUM           
                )                                                     
            port map(                                                 
                RST_DPD                  => rst_lutwrap               , 
                CLK_DPD                  => CLK_DPD                   , 
                                                                      
                DATA_VLD_IN              => data_vld                  , 
                DATA_MAG09_IN            => magnitude09               , 
                                                                      
                DPD_COEF_I_OUT           => dpd_coef_10taps_i         , 
                DPD_COEF_Q_OUT           => dpd_coef_10taps_q         , 
                                                                      
                RST_CPU                  => rst_synch_cpu             , 
                CLK_CPU                  => CLK_CPU                   , 
                                                                      
                DPD_LUT_RB_TEST_EN_IN    => s_dpd_lut_rb_test_en_in     , 
                                                                    
                DPD_CDC_STRB_IN          => s_dpd_lut_switch_cdc_strb_in, 
                DPD_LUT_INPUT_SWITCH_IN  => s_dpd_lut_input_switch_in   , 
                DPD_LUT_OUTPUT_SWITCH_IN => s_dpd_lut_output_switch_in  , 
                                                                    
                DPD_LUT_UPDATE_SW_IN     => s_dpd_lut_update_sw_in      ,
                DPD_LUT_WREN_IN          => s_dpd_lut_wren_in           , 
                DPD_LUT_RDEN_IN          => s_dpd_lut_rden_in           , 
                DPD_LUT_ADDR_IN          => s_dpd_lut_addr_in           , 
                DPD_LUT_WDATA_IN         => s_dpd_lut_wdata_in          , 
                DPD_LUT_RDATA_OUT        => s_dpd_lut_rdata_out          
                );

            dpd_coef_4taps_i  <= (others => (others => (others => '0')));         
            dpd_coef_4taps_q  <= (others => (others => (others => '0')));         
             
            dpd_coef_8taps_i  <= (others => (others => (others => '0')));
            dpd_coef_8taps_q  <= (others => (others => (others => '0')));
             
            dpd_coef_13taps_i <= (others => (others => (others => '0')));
            dpd_coef_13taps_q <= (others => (others => (others => '0')));
             
            dpd_coef_14taps_i <= (others => (others => (others => '0')));         
            dpd_coef_14taps_q <= (others => (others => (others => '0')));         
            
        end generate;

        G_DPD_LUT32_TAP14_Configuration : if ((DPD_CORE_LUT_NUM = 32) and (DPD_CORE_TAP_NUM = 14)) generate begin

            U_DPD_LUT32_WRAPPER : DPD_LUT32_WRAPPER 
            generic map(
                DEVICE                   => DEVICE                    ,
                TX_ANT_NUM               => TX_ANT_NUM                , 
                HOVS                     => HOVS                      , 
                HS_MODE                  => TRUE                      , 
                LUT_OPTIMIZED            => DPD_LUT_OPTIMIZED         ,
                LUT_MEM_DEPTH            => DPD_LUT_MEM_DEPTH         ,
                LUT_RBTEST               => DPD_LUT_RBTEST            , 
                LUT_RAM_NUM              => DPD_CORE_LUT_NUM          , 
                DPD_TAP_NUM              => DPD_CORE_TAP_NUM            
                )                                                     
            port map(                                                 
                RST_DPD                  => rst_lutwrap               , 
                CLK_DPD                  => CLK_DPD                   , 
                                                                      
                DATA_VLD_IN              => data_vld                  , 
                DATA_MAG09_IN            => magnitude09               , 
                                                                      
                DPD_COEF_I_OUT           => dpd_coef_14taps_i         , 
                DPD_COEF_Q_OUT           => dpd_coef_14taps_q         , 
                                                                      
                RST_CPU                  => rst_synch_cpu             , 
                CLK_CPU                  => CLK_CPU                   , 
                                                                      
                DPD_LUT_RB_TEST_EN_IN    => s_dpd_lut_rb_test_en_in     , 
                                                                    
                DPD_CDC_STRB_IN          => s_dpd_lut_switch_cdc_strb_in,
                DPD_LUT_INPUT_SWITCH_IN  => s_dpd_lut_input_switch_in   , 
                DPD_LUT_OUTPUT_SWITCH_IN => s_dpd_lut_output_switch_in  , 
                                                                     
                DPD_LUT_UPDATE_SW_IN     => s_dpd_lut_update_sw_in      ,
                DPD_LUT_WREN_IN          => s_dpd_lut_wren_in           , 
                DPD_LUT_RDEN_IN          => s_dpd_lut_rden_in           , 
                DPD_LUT_ADDR_IN          => s_dpd_lut_addr_in           , 
                DPD_LUT_WDATA_IN         => s_dpd_lut_wdata_in          , 
                DPD_LUT_RDATA_OUT        => s_dpd_lut_rdata_out           
                );

            dpd_coef_4taps_i <= (others => (others => (others => '0')));         
            dpd_coef_4taps_q <= (others => (others => (others => '0')));         
             
            dpd_coef_8taps_i <= (others => (others => (others => '0')));         
            dpd_coef_8taps_q <= (others => (others => (others => '0')));         

        end generate;
    end generate;

    G_DPD_3D_LUT_CONFIG : if (DPD_CORE_LUT_DIMENSION = "3D") generate begin

        dpd_coef_4taps_i  <= (others => (others => (others => '0')));
        dpd_coef_4taps_q  <= (others => (others => (others => '0')));
         
        dpd_coef_8taps_i  <= (others => (others => (others => '0')));
        dpd_coef_8taps_q  <= (others => (others => (others => '0')));
         
        dpd_coef_14taps_i <= (others => (others => (others => '0')));
        dpd_coef_14taps_q <= (others => (others => (others => '0')));
        
        G_DPD_LUT32_TAP13_Configuration : if ((DPD_CORE_LUT_NUM = 32) and (DPD_CORE_TAP_NUM = 13)) generate begin
            U_DPD_3D_LUT32_WRAPPER : DPD_3D_LUT32_WRAPPER 
            generic map(
                DEVICE                   => DEVICE                    ,
                TX_ANT_NUM               => TX_ANT_NUM                , 
                HOVS                     => HOVS                      , 
                HS_MODE                  => TRUE                      , 
                LUT_OPTIMIZED            => DPD_LUT_OPTIMIZED         ,
                LUT_MEM_DEPTH            => DPD_LUT_MEM_DEPTH         , 		
                LUT_RBTEST               => DPD_LUT_RBTEST            , 
                LUT_RAM_NUM              => DPD_CORE_LUT_NUM          , 
                DPD_TAP_NUM              => DPD_CORE_TAP_NUM            
                )                                                     
            port map(                                                 
                RST_DPD                  => rst_lutwrap               , 
                CLK_DPD                  => CLK_DPD                   , 
                                                                      
                DATA_VLD_IN              => data_vld                  , 
                DATA_MAG09_IN            => magnitude09               , 
                DATA_MAG15_IN            => magnitude15               , 
                                                                      
                DPD_COEF_I_OUT           => dpd_coef_13taps_i         , 
                DPD_COEF_Q_OUT           => dpd_coef_13taps_q         , 
                                                                      
                RST_CPU                  => rst_synch_cpu             , 
                CLK_CPU                  => CLK_CPU                   , 
                                                                      
                DPD_LUT_RB_TEST_EN_IN    => s_dpd_lut_rb_test_en_in     , 
                                                                    
                DPD_CDC_STRB_IN          => s_dpd_lut_switch_cdc_strb_in,
                DPD_LUT_INPUT_SWITCH_IN  => s_dpd_lut_input_switch_in   , 
                DPD_LUT_OUTPUT_SWITCH_IN => s_dpd_lut_output_switch_in  , 
                                                                     
                DPD_LUT_UPDATE_SW_IN     => s_dpd_lut_update_sw_in      ,
                DPD_LUT_WREN_IN          => s_dpd_lut_wren_in           , 
                DPD_LUT_RDEN_IN          => s_dpd_lut_rden_in           , 
                DPD_LUT_ADDR_IN          => s_dpd_lut_addr_in           , 
                DPD_LUT_WDATA_IN         => s_dpd_lut_wdata_in          , 
                DPD_LUT_RDATA_OUT        => s_dpd_lut_rdata_out           
                );

        end generate;

        G_DPD_LUT35_TAP13_Configuration : if ((DPD_CORE_LUT_NUM = 35) and (DPD_CORE_TAP_NUM = 13)) generate begin
            U_DPD_3D_LUT35_WRAPPER : DPD_3D_LUT35_WRAPPER 
            generic map(
                DEVICE                   => DEVICE                    ,
                TX_ANT_NUM               => TX_ANT_NUM                , 
                HOVS                     => HOVS                      , 
                HS_MODE                  => TRUE                      ,
                LUT_OPTIMIZED            => DPD_LUT_OPTIMIZED         ,
                LUT_MEM_DEPTH            => DPD_LUT_MEM_DEPTH         , 		
                LUT_RBTEST               => DPD_LUT_RBTEST            , 
                LUT_RAM_NUM              => DPD_CORE_LUT_NUM          , 
                DPD_TAP_NUM              => DPD_CORE_TAP_NUM            
                )                                                     
            port map(                                                 
                RST_DPD                  => rst_lutwrap               , 
                CLK_DPD                  => CLK_DPD                   , 
                                                                      
                DATA_VLD_IN              => data_vld                  , 
                DATA_MAG09_IN            => magnitude09               , 
                DATA_MAG15_IN            => magnitude15               , 
                                                                      
                DPD_COEF_I_OUT           => dpd_coef_13taps_i         , 
                DPD_COEF_Q_OUT           => dpd_coef_13taps_q         , 
                                                                      
                RST_CPU                  => rst_synch_cpu             , 
                CLK_CPU                  => CLK_CPU                   , 
                                                                      
                DPD_LUT_RB_TEST_EN_IN    => s_dpd_lut_rb_test_en_in     , 
                                                                    
                DPD_CDC_STRB_IN          => s_dpd_lut_switch_cdc_strb_in,
                DPD_LUT_INPUT_SWITCH_IN  => s_dpd_lut_input_switch_in   , 
                DPD_LUT_OUTPUT_SWITCH_IN => s_dpd_lut_output_switch_in  , 
                                                                     
                DPD_LUT_UPDATE_SW_IN     => s_dpd_lut_update_sw_in      ,
                DPD_LUT_WREN_IN          => s_dpd_lut_wren_in           , 
                DPD_LUT_RDEN_IN          => s_dpd_lut_rden_in           , 
                DPD_LUT_ADDR_IN          => s_dpd_lut_addr_in           , 
                DPD_LUT_WDATA_IN         => s_dpd_lut_wdata_in          , 
                DPD_LUT_RDATA_OUT        => s_dpd_lut_rdata_out           
                );
        end generate;

        G_DPD_LUT41_TAP13_Configuration : if ((DPD_CORE_LUT_NUM = 41) and (DPD_CORE_TAP_NUM = 13)) generate begin
            U_DPD_3D_LUT41_WRAPPER : DPD_3D_LUT41_WRAPPER 
            generic map(
                DEVICE                   => DEVICE                    ,
                TX_ANT_NUM               => TX_ANT_NUM                ,
                HOVS                     => HOVS                      ,
                HS_MODE                  => TRUE                      ,
                LUT_OPTIMIZED            => DPD_LUT_OPTIMIZED         ,
                LUT_MEM_DEPTH            => DPD_LUT_MEM_DEPTH         ,
                LUT_RBTEST               => DPD_LUT_RBTEST            ,
                LUT_RAM_NUM              => DPD_CORE_LUT_NUM          ,
                DPD_TAP_NUM              => DPD_CORE_TAP_NUM           
                )
            port map(
                RST_DPD                  => rst_lutwrap               , 
                CLK_DPD                  => CLK_DPD                   , 
                                                                      
                DATA_VLD_IN              => data_vld                  , 
                DATA_MAG09_IN            => magnitude09               , 
                DATA_MAG15_IN            => magnitude15               , 
                                                                      
                DATA_I_IN                => data_i_ddr_sh             , 
                DATA_Q_IN                => data_q_ddr_sh             , 

                DPD_COEF_I_OUT           => dpd_coef_13taps_i         , 
                DPD_COEF_Q_OUT           => dpd_coef_13taps_q         , 
                                                                      
                RST_CPU                  => rst_synch_cpu             , 
                CLK_CPU                  => CLK_CPU                   , 
                                                                      
                DPD_LUT_RB_TEST_EN_IN    => s_dpd_lut_rb_test_en_in     , 
                                                                    
                DPD_CDC_STRB_IN          => s_dpd_lut_switch_cdc_strb_in, 
                DPD_LUT_INPUT_SWITCH_IN  => s_dpd_lut_input_switch_in   , 
                DPD_LUT_OUTPUT_SWITCH_IN => s_dpd_lut_output_switch_in  , 
                                                                     
                DPD_LUT_UPDATE_SW_IN     => s_dpd_lut_update_sw_in      , 
                DPD_LUT_WREN_IN          => s_dpd_lut_wren_in           , 
                DPD_LUT_RDEN_IN          => s_dpd_lut_rden_in           , 
                DPD_LUT_ADDR_IN          => s_dpd_lut_addr_in           , 
                DPD_LUT_WDATA_IN         => s_dpd_lut_wdata_in          , 
                DPD_LUT_RDATA_OUT        => s_dpd_lut_rdata_out           
                );
        end generate;

        G_DPD_LUT44_TAP10_Configuration : if ((DPD_CORE_LUT_NUM = 44) and (DPD_CORE_TAP_NUM = 10)) generate begin
            U_DPD_3D_LUT44_WRAPPER : DPD_3D_LUT44_WRAPPER
            generic map(
                DEVICE                   => DEVICE                    ,
                TX_ANT_NUM               => TX_ANT_NUM                ,
                HOVS                     => HOVS                      ,
                HS_MODE                  => TRUE                      ,
                LUT_OPTIMIZED            => DPD_LUT_OPTIMIZED         ,
                LUT_MEM_DEPTH            => DPD_LUT_MEM_DEPTH         ,
                LUT_RBTEST               => DPD_LUT_RBTEST            ,
                LUT_RAM_NUM              => DPD_CORE_LUT_NUM          ,
                DPD_TAP_NUM              => DPD_CORE_TAP_NUM           
                )
            port map(                                                                                                 
                RST_DPD                  => rst_lutwrap               , 
                CLK_DPD                  => CLK_DPD                   , 
                                                                      
                DATA_VLD_IN              => data_vld                  , 
                DATA_MAG09_IN            => magnitude09               , 
                DATA_MAG15_IN            => magnitude15               , 
                                                                      
                DATA_I_IN                => data_i_ddr_sh             , 
                DATA_Q_IN                => data_q_ddr_sh             , 
                                                                                                                  
                DPD_COEF_I_OUT           => dpd_coef_10taps_i         , 
                DPD_COEF_Q_OUT           => dpd_coef_10taps_q         , 
                                                                      
                RST_CPU                  => rst_synch_cpu             , 
                CLK_CPU                  => CLK_CPU                   , 
                                                                      
                DPD_LUT_RB_TEST_EN_IN    => s_dpd_lut_rb_test_en_in     , 
                                                                    
                DPD_CDC_STRB_IN          => s_dpd_lut_switch_cdc_strb_in, 
                DPD_LUT_INPUT_SWITCH_IN  => s_dpd_lut_input_switch_in   , 
                DPD_LUT_OUTPUT_SWITCH_IN => s_dpd_lut_output_switch_in  , 
                                                                     
                DPD_LUT_UPDATE_SW_IN     => s_dpd_lut_update_sw_in      , 
                DPD_LUT_WREN_IN          => s_dpd_lut_wren_in           , 
                DPD_LUT_RDEN_IN          => s_dpd_lut_rden_in           , 
                DPD_LUT_ADDR_IN          => s_dpd_lut_addr_in           , 
                DPD_LUT_WDATA_IN         => s_dpd_lut_wdata_in          , 
                DPD_LUT_RDATA_OUT        => s_dpd_lut_rdata_out           
                );                                                                                                
        end generate;           

    end generate;               
                                
    --*******************************
    -- Complex FIR Filter 
    --*******************************
    G_Complex_Filter_ANT_Path : for I in 0 to (TX_ANT_NUM-1) generate begin

        G_Complex_Filter_Fixed_Binary_Point : if (DPD_CORE_QPOINT_SEL = FALSE) generate begin
            G_Complex_Filter_HOVS1 : if (HOVS = 1) generate begin
                G_Complex_Filter_HOVS1_4TAPs : if (DPD_CORE_TAP_NUM = 4) generate begin

                    U_COMPLEX_FILTER_HOVS1_4TAPs : COMPLEX_FIR_FILTER_HOVS1 
                    generic map(
                        HS_MODE          => TRUE                 ,  
                        DEVICE           => DEVICE               , 
                        TAP_NUM          => DPD_CORE_TAP_NUM     , 
                        RND_BIT          => DPD_CORE_RND_BIT                      
                        )
                    port map(
                        RST              => rst_complex_filter(I), 
                        CLK              => CLK_DPD              , 
                    
                        COEF_I_IN        => dpd_coef_4taps_i(I)  , 
                        COEF_Q_IN        => dpd_coef_4taps_q(I)  , 
                                                                 
                        DATA_VLD_IN      => data_vld(I)          , 
                        DATA_I_IN        => data_i_lmt_sh(I)     , 
                        DATA_Q_IN        => data_q_lmt_sh(I)     , 
                                                                 
                        DATA_VLD_OUT     => dpd_core_out_vld(I)  , 
                        DATA_I_OUT       => dpd_core_out_i(I)    , 
                        DATA_Q_OUT       => dpd_core_out_q(I)      
                        );
	            end generate;

                G_Complex_Filter_HOVS1_8TAPs : if (DPD_CORE_TAP_NUM = 8) generate begin
                    U_COMPLEX_FILTER_HOVS1_8TAPs : COMPLEX_FIR_FILTER_HOVS1 
                    generic map(
                        HS_MODE          => TRUE                 ,  
                        DEVICE           => DEVICE               , 
                        TAP_NUM          => DPD_CORE_TAP_NUM     , 
                        RND_BIT          => DPD_CORE_RND_BIT                 
                        )
                    port map(
                        RST              => rst_complex_filter(I), 
                        CLK              => CLK_DPD              , 
                    
                        COEF_I_IN        => dpd_coef_8taps_i(I)  , 
                        COEF_Q_IN        => dpd_coef_8taps_q(I)  , 
                                                                 
                        DATA_VLD_IN      => data_vld(I)          , 
                        DATA_I_IN        => data_i_lmt_sh(I)     , 
                        DATA_Q_IN        => data_q_lmt_sh(I)     , 
                                                                 
                        DATA_VLD_OUT     => dpd_core_out_vld(I)  , 
                        DATA_I_OUT       => dpd_core_out_i(I)    , 
                        DATA_Q_OUT       => dpd_core_out_q(I)      
                        );
                end generate;

                G_Complex_Filter_HOVS1_10TAPs : if (DPD_CORE_TAP_NUM = 10 ) generate begin
                    G_NM : if (DPD_CORE_LUT_NUM /= 44 ) generate begin
                        U_COMPLEX_FILTER_HOVS1_10TAPs : COMPLEX_FIR_FILTER_HOVS1 
                        generic map(
                            HS_MODE          => TRUE                 ,  
                            DEVICE           => DEVICE               , 
                            TAP_NUM          => DPD_CORE_TAP_NUM     , 
                            RND_BIT          => DPD_CORE_RND_BIT                 
                            )
                        port map(
                            RST              => rst_complex_filter(I), 
                            CLK              => CLK_DPD              , 
                        
                            COEF_I_IN        => dpd_coef_10taps_i(I) , 
                            COEF_Q_IN        => dpd_coef_10taps_q(I) , 
                                                                     
                            DATA_VLD_IN      => data_vld(I)          , 
                            DATA_I_IN        => data_i_lmt_sh(I)     , 
                            DATA_Q_IN        => data_q_lmt_sh(I)     , 
                                                                     
                            DATA_VLD_OUT     => dpd_core_out_vld(I)  , 
                            DATA_I_OUT       => dpd_core_out_i(I)    , 
                            DATA_Q_OUT       => dpd_core_out_q(I)      
                            );
                    end generate;
                    G_LUT44 : if (DPD_CORE_LUT_NUM = 44) generate begin
                        U_COMPLEX_FILTER_HOVS1_10TAPs_LUT44 : COMPLEX_FIR_FILTER_HOVS1 
                        generic map(
                            HS_MODE          => TRUE                 ,  
                            DEVICE           => DEVICE               , 
                            TAP_NUM          => DPD_CORE_TAP_NUM     , 
                            RND_BIT          => DPD_CORE_RND_BIT+9               
                            )
                        port map(
                            RST              => rst_complex_filter(I), 
                            CLK              => CLK_DPD              , 
                        
                            COEF_I_IN        => dpd_coef_10taps_i(I) , 
                            COEF_Q_IN        => dpd_coef_10taps_q(I) , 
                                                                     
                            DATA_VLD_IN      => data_vld(I)          , 
                            DATA_I_IN        => data_i_lmt_sh(I)     , 
                            DATA_Q_IN        => data_q_lmt_sh(I)     , 
                                                                     
                            DATA_VLD_OUT     => dpd_core_out_vld(I)  , 
                            DATA_I_OUT       => dpd_core_out_i(I)    , 
                            DATA_Q_OUT       => dpd_core_out_q(I)      
                            );
                    end generate;
                end generate;

                G_Complex_Filter_HOVS1_13TAPs : if (DPD_CORE_TAP_NUM = 13) generate begin
                    G_NonDDR : if (DPD_CORE_LUT_NUM /= 41) generate begin
                        U_COMPLEX_FILTER_HOVS1_13TAPs : COMPLEX_FIR_FILTER_HOVS1 
                        generic map(
                            HS_MODE          => TRUE                 ,  
                            DEVICE           => DEVICE               , 
                            TAP_NUM          => DPD_CORE_TAP_NUM     , 
                            RND_BIT          => DPD_CORE_RND_BIT+11                 
                            )
                        port map(
                            RST              => rst_complex_filter(I), 
                            CLK              => CLK_DPD              , 
                        
                            COEF_I_IN        => dpd_coef_13taps_i(I) , 
                            COEF_Q_IN        => dpd_coef_13taps_q(I) , 
                                                                     
                            DATA_VLD_IN      => data_vld(I)          , 
                            DATA_I_IN        => data_i_lmt_sh(I)     , 
                            DATA_Q_IN        => data_q_lmt_sh(I)     , 
                                                                     
                            DATA_VLD_OUT     => dpd_core_out_vld(I)  , 
                            DATA_I_OUT       => dpd_core_out_i(I)    , 
                            DATA_Q_OUT       => dpd_core_out_q(I)      
                            );
                    end generate;

                    G_DDR : if (DPD_CORE_LUT_NUM = 41) generate begin
                        U_COMPLEX_FILTER_HOVS1_13TAPs : COMPLEX_FIR_FILTER_HOVS1 
                        generic map(
                            HS_MODE          => TRUE                 ,  
                            DEVICE           => DEVICE               , 
                            TAP_NUM          => DPD_CORE_TAP_NUM     , 
                            RND_BIT          => DPD_CORE_RND_BIT+9                 
                            )
                        port map(
                            RST              => rst_complex_filter(I), 
                            CLK              => CLK_DPD              , 
                        
                            COEF_I_IN        => dpd_coef_13taps_i(I) , 
                            COEF_Q_IN        => dpd_coef_13taps_q(I) , 
                                                                     
                            DATA_VLD_IN      => data_vld(I)          , 
                            DATA_I_IN        => data_i_lmt_sh(I)     , 
                            DATA_Q_IN        => data_q_lmt_sh(I)     , 
                                                                     
                            DATA_VLD_OUT     => dpd_core_out_vld(I)  , 
                            DATA_I_OUT       => dpd_core_out_i(I)    , 
                            DATA_Q_OUT       => dpd_core_out_q(I)      
                            );
                    end generate;
                end generate;

                G_Complex_Filter_HOVS1_14TAPs : if (DPD_CORE_TAP_NUM = 14) generate begin
                    U_COMPLEX_FILTER_HOVS1_14TAPs : COMPLEX_FIR_FILTER_HOVS1 
                    generic map(
                        HS_MODE          => TRUE                 ,  
                        DEVICE           => DEVICE               , 
                        TAP_NUM          => DPD_CORE_TAP_NUM     , 
                        RND_BIT          => DPD_CORE_RND_BIT                 
                        )
                    port map(
                        RST              => rst_complex_filter(I), 
                        CLK              => CLK_DPD              , 
                    
                        COEF_I_IN        => dpd_coef_14taps_i(I) , 
                        COEF_Q_IN        => dpd_coef_14taps_q(I) , 
                                                                 
                        DATA_VLD_IN      => data_vld(I)          , 
                        DATA_I_IN        => data_i_lmt_sh(I)     , 
                        DATA_Q_IN        => data_q_lmt_sh(I)     , 
                                                                 
                        DATA_VLD_OUT     => dpd_core_out_vld(I)  , 
                        DATA_I_OUT       => dpd_core_out_i(I)    , 
                        DATA_Q_OUT       => dpd_core_out_q(I)      
                        );
                end generate;
            end generate;

            G_Complex_Filter_HOVS2 : if (HOVS = 2) generate begin
                G_Complex_Filter_HOVS2_4TAPs : if (DPD_CORE_TAP_NUM = 4) generate begin
                    U_COMPLEX_FILTER_HOVS2_4TAPs : COMPLEX_FIR_FILTER_HOVS2
                    generic map(
                        DEVICE         => DEVICE                     ,
                        TAP_NUM        => DPD_CORE_TAP_NUM           ,               
                        RND_BIT        => DPD_CORE_RND_BIT                        
                        )
                    port map(
                        RST            => rst_complex_filter(I)      , 
                        CLK            => CLK_DPD                    , 
                                                      
                        COEF_I_IN      => dpd_coef_4taps_i(I)        , 
                        COEF_Q_IN      => dpd_coef_4taps_q(I)        , 
                    
                        DATA_VLD_IN    => data_vld(I)                ,
                        DATA_I_IN      => data_i_lmt_sh(I)           ,
                        DATA_Q_IN      => data_q_lmt_sh(I)           ,
                                                           
                        DATA_VLD_OUT   => dpd_core_out_vld(I)        ,
                        DATA_I_OUT     => dpd_core_out_i(I)          ,
                        DATA_Q_OUT     => dpd_core_out_q(I)           
                        );
                end generate;

                G_Complex_Filter_HOVS2_8TAPs : if (DPD_CORE_TAP_NUM = 8) generate begin
                    U_COMPLEX_FILTER_HOVS2_8TAPs : COMPLEX_FIR_FILTER_HOVS2
                    generic map(
                        DEVICE         => DEVICE                     ,
                        TAP_NUM        => DPD_CORE_TAP_NUM           ,                  
                        RND_BIT        => DPD_CORE_RND_BIT                        
                        )
                    port map(
                        RST            => rst_complex_filter(I)      , 
                        CLK            => CLK_DPD                    , 
                                                      
                        COEF_I_IN      => dpd_coef_8taps_i(I)        , 
                        COEF_Q_IN      => dpd_coef_8taps_q(I)        , 
                    
                        DATA_VLD_IN    => data_vld(I)                ,
                        DATA_I_IN      => data_i_lmt_sh(I)           ,
                        DATA_Q_IN      => data_q_lmt_sh(I)           ,
                                                           
                        DATA_VLD_OUT   => dpd_core_out_vld(I)        ,
                        DATA_I_OUT     => dpd_core_out_i(I)          ,
                        DATA_Q_OUT     => dpd_core_out_q(I)           
                        );
                end generate;

                G_Complex_Filter_HOVS2_10TAPs : if (DPD_CORE_TAP_NUM = 10) generate begin
                    G_NM : if (DPD_CORE_LUT_NUM /= 44) generate begin
                        U_COMPLEX_FILTER_HOVS1_13TAPs : COMPLEX_FIR_FILTER_HOVS1 
                        generic map(
                            HS_MODE          => TRUE                 ,  
                            DEVICE           => DEVICE               , 
                            TAP_NUM          => DPD_CORE_TAP_NUM     , 
                            RND_BIT          => DPD_CORE_RND_BIT                     
                            )
                        port map(
                            RST              => rst_complex_filter(I), 
                            CLK              => CLK_DPD              , 
                        
                            COEF_I_IN        => dpd_coef_13taps_i(I) , 
                            COEF_Q_IN        => dpd_coef_13taps_q(I) , 
                                                                     
                            DATA_VLD_IN      => data_vld(I)          , 
                            DATA_I_IN        => data_i_lmt_sh(I)     , 
                            DATA_Q_IN        => data_q_lmt_sh(I)     , 
                                                                     
                            DATA_VLD_OUT     => dpd_core_out_vld(I)  , 
                            DATA_I_OUT       => dpd_core_out_i(I)    , 
                            DATA_Q_OUT       => dpd_core_out_q(I)      
                            );
                    end generate;
                    G_DDR : if (DPD_CORE_LUT_NUM = 44) generate begin
                        U_COMPLEX_FILTER_HOVS1_13TAPs_LUT : COMPLEX_FIR_FILTER_HOVS1 
                        generic map(
                            HS_MODE          => TRUE                 ,  
                            DEVICE           => DEVICE               , 
                            TAP_NUM          => DPD_CORE_TAP_NUM     , 
                            RND_BIT          => DPD_CORE_RND_BIT+9                 
                            )
                        port map(
                            RST              => rst_complex_filter(I), 
                            CLK              => CLK_DPD              , 
                        
                            COEF_I_IN        => dpd_coef_13taps_i(I) , 
                            COEF_Q_IN        => dpd_coef_13taps_q(I) , 
                                                                     
                            DATA_VLD_IN      => data_vld(I)          , 
                            DATA_I_IN        => data_i_lmt_sh(I)     , 
                            DATA_Q_IN        => data_q_lmt_sh(I)     , 
                                                                     
                            DATA_VLD_OUT     => dpd_core_out_vld(I)  , 
                            DATA_I_OUT       => dpd_core_out_i(I)    , 
                            DATA_Q_OUT       => dpd_core_out_q(I)      
                            );
                    end generate;
                end generate;

                G_Complex_Filter_HOVS2_13TAPs : if (DPD_CORE_TAP_NUM = 13) generate begin
                    U_COMPLEX_FILTER_HOVS2_13TAPs : COMPLEX_FIR_FILTER_HOVS2
                    generic map(
                        DEVICE         => DEVICE                     ,
                        TAP_NUM        => DPD_CORE_TAP_NUM           ,                 
                        RND_BIT        => DPD_CORE_RND_BIT+11                        
                        )
                    port map(
                        RST            => rst_complex_filter(I)      , 
                        CLK            => CLK_DPD                    , 
                                                      
                        COEF_I_IN      => dpd_coef_13taps_i(I)       , 
                        COEF_Q_IN      => dpd_coef_13taps_q(I)       , 
                    
                        DATA_VLD_IN    => data_vld(I)                ,
                        DATA_I_IN      => data_i_lmt_sh(I)           ,
                        DATA_Q_IN      => data_q_lmt_sh(I)           ,
                                                           
                        DATA_VLD_OUT   => dpd_core_out_vld(I)        ,
                        DATA_I_OUT     => dpd_core_out_i(I)          ,
                        DATA_Q_OUT     => dpd_core_out_q(I)           
                        );
                end generate;

                G_Complex_Filter_HOVS2_14TAPs : if (DPD_CORE_TAP_NUM = 14) generate begin
                    U_COMPLEX_FILTER_HOVS2_14TAPs : COMPLEX_FIR_FILTER_HOVS2
                    generic map(
                        DEVICE         => DEVICE                     ,
                        TAP_NUM        => DPD_CORE_TAP_NUM           ,                 
                        RND_BIT        => DPD_CORE_RND_BIT                        
                        )
                    port map(
                        RST            => rst_complex_filter(I)      , 
                        CLK            => CLK_DPD                    , 
                                                      
                        COEF_I_IN      => dpd_coef_14taps_i(I)       , 
                        COEF_Q_IN      => dpd_coef_14taps_q(I)       , 
                    
                        DATA_VLD_IN    => data_vld(I)                ,
                        DATA_I_IN      => data_i_lmt_sh(I)           ,
                        DATA_Q_IN      => data_q_lmt_sh(I)           ,
                                                           
                        DATA_VLD_OUT   => dpd_core_out_vld(I)        ,
                        DATA_I_OUT     => dpd_core_out_i(I)          ,
                        DATA_Q_OUT     => dpd_core_out_q(I)           
                        );
                end generate;
            end generate;
        end generate;


        G_Complex_Filter_Selectable_Binary_Point : if (DPD_CORE_QPOINT_SEL = TRUE) generate begin
		
            G_Complex_Filter_Q_SEL_HOVS1 : if (HOVS = 1) generate begin
                G_Complex_Filter_Q_SEL_HOVS1_4TAPs : if (DPD_CORE_TAP_NUM = 4) generate begin

                    U_COMPLEX_FILTER_HOVS1_Q_SEL_4TAPs : COMPLEX_FIR_FILTER_HOVS1_Q_POINT_SEL 
                    generic map(
                        HS_MODE          => TRUE                 ,  
                        DEVICE           => DEVICE               , 
                        BASE_RND_BIT     => DPD_CORE_RND_BIT-1   , 
                        TAP_NUM          => DPD_CORE_TAP_NUM      
                        )
                    port map(
                        RST              => rst_complex_filter(I), 
                        CLK              => CLK_DPD              , 
                    
                        Q_POINT_SEL_IN   => DPD_QPOINT_SEL_IN(I) ,

                        COEF_I_IN        => dpd_coef_4taps_i(I)  , 
                        COEF_Q_IN        => dpd_coef_4taps_q(I)  , 
                                                                 
                        DATA_VLD_IN      => data_vld(I)          , 
                        DATA_I_IN        => data_i_lmt_sh(I)     , 
                        DATA_Q_IN        => data_q_lmt_sh(I)     , 
                                                                 
                        DATA_VLD_OUT     => dpd_core_out_vld(I)  , 
                        DATA_I_OUT       => dpd_core_out_i(I)    , 
                        DATA_Q_OUT       => dpd_core_out_q(I)      
                        );
	        end generate;

                G_Complex_Filter_Q_SEL_HOVS1_8TAPs : if (DPD_CORE_TAP_NUM = 8) generate begin
                    U_COMPLEX_FILTER_HOVS1_Q_SEL_8TAPs : COMPLEX_FIR_FILTER_HOVS1_Q_POINT_SEL 
                    generic map(
                        HS_MODE          => TRUE                 ,  
                        DEVICE           => DEVICE               , 
                        BASE_RND_BIT     => DPD_CORE_RND_BIT-1   , 
                        TAP_NUM          => DPD_CORE_TAP_NUM      
                        )
                    port map(
                        RST              => rst_complex_filter(I), 
                        CLK              => CLK_DPD              , 
                    
                        Q_POINT_SEL_IN   => DPD_QPOINT_SEL_IN(I) ,

                        COEF_I_IN        => dpd_coef_8taps_i(I)  , 
                        COEF_Q_IN        => dpd_coef_8taps_q(I)  , 
                                                                 
                        DATA_VLD_IN      => data_vld(I)          , 
                        DATA_I_IN        => data_i_lmt_sh(I)     , 
                        DATA_Q_IN        => data_q_lmt_sh(I)     , 
                                                                 
                        DATA_VLD_OUT     => dpd_core_out_vld(I)  , 
                        DATA_I_OUT       => dpd_core_out_i(I)    , 
                        DATA_Q_OUT       => dpd_core_out_q(I)      
                        );
                end generate;

                G_Complex_Filter_Q_SEL_HOVS1_10TAPs_LUT : if (DPD_CORE_TAP_NUM = 10 ) generate begin
                    G_NM : if (DPD_CORE_LUT_NUM /= 44) generate begin
                       U_COMPLEX_FILTER_HOVS1_Q_SEL_10TAPs : COMPLEX_FIR_FILTER_HOVS1_Q_POINT_SEL
                       generic map(
                           HS_MODE          => TRUE                       ,  
                           DEVICE           => DEVICE                     ,
                           BASE_RND_BIT     => DPD_CORE_RND_BIT           , 
                           TAP_NUM          => DPD_CORE_TAP_NUM                             
                           )
                       port map(
                           RST              => rst_complex_filter(I)      , 
                           CLK              => CLK_DPD                    , 
                                                           
                           Q_POINT_SEL_IN   => DPD_QPOINT_SEL_IN(I)       ,

                           COEF_I_IN        => dpd_coef_10taps_i(I)       , 
                           COEF_Q_IN        => dpd_coef_10taps_q(I)       , 
                       
                           DATA_VLD_IN      => data_vld(I)                ,
                           DATA_I_IN        => data_i_lmt_sh(I)           ,
                           DATA_Q_IN        => data_q_lmt_sh(I)           ,
                                                                
                           DATA_VLD_OUT     => dpd_core_out_vld(I)        ,
                           DATA_I_OUT       => dpd_core_out_i(I)          ,
                           DATA_Q_OUT       => dpd_core_out_q(I)           
                           );
                    end generate;
                    G_LUT44 : if (DPD_CORE_LUT_NUM = 44) generate begin
                       U_COMPLEX_FILTER_HOVS1_Q_SEL_10TAPs_LUT44 : COMPLEX_FIR_FILTER_HOVS1_Q_POINT_SEL
                       generic map(
                           HS_MODE          => TRUE                       ,  
                           DEVICE           => DEVICE                     ,
                           BASE_RND_BIT     => DPD_CORE_RND_BIT+9-1       , 
                           TAP_NUM          => DPD_CORE_TAP_NUM                             
                           )
                       port map(
                           RST              => rst_complex_filter(I)      , 
                           CLK              => CLK_DPD                    , 
                                                           
                           Q_POINT_SEL_IN   => DPD_QPOINT_SEL_IN(I)       ,

                           COEF_I_IN        => dpd_coef_10taps_i(I)       , 
                           COEF_Q_IN        => dpd_coef_10taps_q(I)       , 
                       
                           DATA_VLD_IN      => data_vld(I)                ,
                           DATA_I_IN        => data_i_lmt_sh(I)           ,
                           DATA_Q_IN        => data_q_lmt_sh(I)           ,
                                                                
                           DATA_VLD_OUT     => dpd_core_out_vld(I)        ,
                           DATA_I_OUT       => dpd_core_out_i(I)          ,
                           DATA_Q_OUT       => dpd_core_out_q(I)           
                           );
                    end generate;
                end generate;

                G_Complex_Filter_Q_SEL_HOVS1_13TAPs : if (DPD_CORE_TAP_NUM = 13 and DPD_CORE_TAP_NUM = 41) generate begin
                    U_COMPLEX_FILTER_HOVS1_Q_SEL_13TAPs : COMPLEX_FIR_FILTER_HOVS1_Q_POINT_SEL 
                    generic map(
                        HS_MODE          => TRUE                 ,  
                        DEVICE           => DEVICE               , 
                        BASE_RND_BIT     => DPD_CORE_RND_BIT+11-1, 
                        TAP_NUM          => DPD_CORE_TAP_NUM      
                        )
                    port map(
                        RST              => rst_complex_filter(I), 
                        CLK              => CLK_DPD              , 
                    
                        Q_POINT_SEL_IN   => DPD_QPOINT_SEL_IN(I) ,

                        COEF_I_IN        => dpd_coef_13taps_i(I) , 
                        COEF_Q_IN        => dpd_coef_13taps_q(I) , 
                                                                 
                        DATA_VLD_IN      => data_vld(I)          , 
                        DATA_I_IN        => data_i_lmt_sh(I)     , 
                        DATA_Q_IN        => data_q_lmt_sh(I)     , 
                                                                 
                        DATA_VLD_OUT     => dpd_core_out_vld(I)  , 
                        DATA_I_OUT       => dpd_core_out_i(I)    , 
                        DATA_Q_OUT       => dpd_core_out_q(I)      
                        );
                end generate;

                G_Complex_Filter_Q_SEL_HOVS1_14TAPs : if (DPD_CORE_TAP_NUM = 14) generate begin
                    U_COMPLEX_FILTER_HOVS1_Q_SEL_14TAPs : COMPLEX_FIR_FILTER_HOVS1_Q_POINT_SEL 
                    generic map(
                        HS_MODE          => TRUE                 ,  
                        DEVICE           => DEVICE               , 
                        BASE_RND_BIT     => DPD_CORE_RND_BIT-1   , 
                        TAP_NUM          => DPD_CORE_TAP_NUM      
                        )
                    port map(
                        RST              => rst_complex_filter(I), 
                        CLK              => CLK_DPD              , 
                    
                        Q_POINT_SEL_IN   => DPD_QPOINT_SEL_IN(I) ,

                        COEF_I_IN        => dpd_coef_14taps_i(I) , 
                        COEF_Q_IN        => dpd_coef_14taps_q(I) , 
                                                                 
                        DATA_VLD_IN      => data_vld(I)          , 
                        DATA_I_IN        => data_i_lmt_sh(I)     , 
                        DATA_Q_IN        => data_q_lmt_sh(I)     , 
                                                                 
                        DATA_VLD_OUT     => dpd_core_out_vld(I)  , 
                        DATA_I_OUT       => dpd_core_out_i(I)    , 
                        DATA_Q_OUT       => dpd_core_out_q(I)      
                        );
                end generate;
            end generate;

            G_Complex_Filter_Q_SEL_HOVS2 : if (HOVS = 2) generate begin
                G_Complex_Filter_Q_SEL_HOVS2_4TAPs : if (DPD_CORE_TAP_NUM = 4) generate begin
                    U_COMPLEX_FILTER_HOVS2_Q_SEL_4TAPs : COMPLEX_FIR_FILTER_HOVS2_Q_POINT_SEL
                    generic map(
                        DEVICE           => DEVICE                     ,
                        BASE_RND_BIT     => DPD_CORE_RND_BIT-1         , 
                        TAP_NUM          => DPD_CORE_TAP_NUM                          
                        )
                    port map(
                        RST              => rst_complex_filter(I)      , 
                        CLK              => CLK_DPD                    , 
                                                        
                        Q_POINT_SEL_IN   => DPD_QPOINT_SEL_IN(I)       ,

                        COEF_I_IN        => dpd_coef_4taps_i(I)        , 
                        COEF_Q_IN        => dpd_coef_4taps_q(I)        , 
                    
                        DATA_VLD_IN      => data_vld(I)                ,
                        DATA_I_IN        => data_i_lmt_sh(I)           ,
                        DATA_Q_IN        => data_q_lmt_sh(I)           ,
                                                             
                        DATA_VLD_OUT     => dpd_core_out_vld(I)        ,
                        DATA_I_OUT       => dpd_core_out_i(I)          ,
                        DATA_Q_OUT       => dpd_core_out_q(I)           
                        );
                end generate;

                G_Complex_Filter_Q_SEL_HOVS2_8TAPs : if (DPD_CORE_TAP_NUM = 8) generate begin
                    U_COMPLEX_FILTER_HOVS2_Q_SEL_8TAPs : COMPLEX_FIR_FILTER_HOVS2_Q_POINT_SEL
                    generic map(
                        DEVICE           => DEVICE                     ,
                        BASE_RND_BIT     => DPD_CORE_RND_BIT-1         , 
                        TAP_NUM          => DPD_CORE_TAP_NUM                             
                        )
                    port map(
                        RST              => rst_complex_filter(I)      , 
                        CLK              => CLK_DPD                    , 
                                                        
                        Q_POINT_SEL_IN   => DPD_QPOINT_SEL_IN(I)       ,

                        COEF_I_IN        => dpd_coef_8taps_i(I)        , 
                        COEF_Q_IN        => dpd_coef_8taps_q(I)        , 
                    
                        DATA_VLD_IN      => data_vld(I)                ,
                        DATA_I_IN        => data_i_lmt_sh(I)           ,
                        DATA_Q_IN        => data_q_lmt_sh(I)           ,
                                                             
                        DATA_VLD_OUT     => dpd_core_out_vld(I)        ,
                        DATA_I_OUT       => dpd_core_out_i(I)          ,
                        DATA_Q_OUT       => dpd_core_out_q(I)           
                        );
                end generate;

                G_Complex_Filter_Q_SEL_HOVS2_10TAPs : if (DPD_CORE_TAP_NUM = 10) generate begin
                    G_NM : if (DPD_CORE_LUT_NUM /= 44) generate begin
                        U_COMPLEX_FILTER_HOVS2_Q_SEL_10TAPS : COMPLEX_FIR_FILTER_HOVS2_Q_POINT_SEL
                        generic map(
                            DEVICE           => DEVICE                     ,
                            BASE_RND_BIT     => DPD_CORE_RND_BIT-1         , 
                            TAP_NUM          => DPD_CORE_TAP_NUM                             
                            )
                        port map(
                            RST              => rst_complex_filter(I)      , 
                            CLK              => CLK_DPD                    , 
                                                            
                            Q_POINT_SEL_IN   => DPD_QPOINT_SEL_IN(I)       ,

                            COEF_I_IN        => dpd_coef_10taps_i(I)       , 
                            COEF_Q_IN        => dpd_coef_10taps_q(I)       , 
                        
                            DATA_VLD_IN      => data_vld(I)                ,
                            DATA_I_IN        => data_i_lmt_sh(I)           ,
                            DATA_Q_IN        => data_q_lmt_sh(I)           ,
                                                                 
                            DATA_VLD_OUT     => dpd_core_out_vld(I)        ,
                            DATA_I_OUT       => dpd_core_out_i(I)          ,
                            DATA_Q_OUT       => dpd_core_out_q(I)           
                            );
                    end generate;
                    G_LUT44 : if (DPD_CORE_LUT_NUM = 44) generate begin
                        U_COMPLEX_FILTER_HOVS2_Q_SEL_10TAPS_LUT : COMPLEX_FIR_FILTER_HOVS2_Q_POINT_SEL
                        generic map(
                            DEVICE           => DEVICE                     ,
                            BASE_RND_BIT     => DPD_CORE_RND_BIT+9-1      , 
                            TAP_NUM          => DPD_CORE_TAP_NUM                             
                            )
                        port map(
                            RST              => rst_complex_filter(I)      , 
                            CLK              => CLK_DPD                    , 
                                                            
                            Q_POINT_SEL_IN   => DPD_QPOINT_SEL_IN(I)       ,

                            COEF_I_IN        => dpd_coef_10taps_i(I)       , 
                            COEF_Q_IN        => dpd_coef_10taps_q(I)       , 
                        
                            DATA_VLD_IN      => data_vld(I)                ,
                            DATA_I_IN        => data_i_lmt_sh(I)           ,
                            DATA_Q_IN        => data_q_lmt_sh(I)           ,
                                                                 
                            DATA_VLD_OUT     => dpd_core_out_vld(I)        ,
                            DATA_I_OUT       => dpd_core_out_i(I)          ,
                            DATA_Q_OUT       => dpd_core_out_q(I)           
                            );
                    end generate;
                end generate;

                G_Complex_Filter_Q_SEL_HOVS2_13TAPs : if (DPD_CORE_TAP_NUM = 13) generate begin
                    U_COMPLEX_FILTER_HOVS2_Q_SEL_13TAPs : COMPLEX_FIR_FILTER_HOVS2_Q_POINT_SEL
                    generic map(
                        DEVICE           => DEVICE                     ,
                        BASE_RND_BIT     => DPD_CORE_RND_BIT+11-1      , 
                        TAP_NUM          => DPD_CORE_TAP_NUM                            
                        )
                    port map(
                        RST              => rst_complex_filter(I)      , 
                        CLK              => CLK_DPD                    , 
                                                        
                        Q_POINT_SEL_IN   => DPD_QPOINT_SEL_IN(I)       ,

                        COEF_I_IN        => dpd_coef_13taps_i(I)       , 
                        COEF_Q_IN        => dpd_coef_13taps_q(I)       , 
                    
                        DATA_VLD_IN      => data_vld(I)                ,
                        DATA_I_IN        => data_i_lmt_sh(I)           ,
                        DATA_Q_IN        => data_q_lmt_sh(I)           ,
                                                             
                        DATA_VLD_OUT     => dpd_core_out_vld(I)        ,
                        DATA_I_OUT       => dpd_core_out_i(I)          ,
                        DATA_Q_OUT       => dpd_core_out_q(I)           
                        );
                end generate;
                G_Complex_Filter_Q_SEL_HOVS2_14TAPs : if (DPD_CORE_TAP_NUM = 14) generate begin
                    U_COMPLEX_FILTER_HOVS2_Q_SEL_14TAPs : COMPLEX_FIR_FILTER_HOVS2_Q_POINT_SEL
                    generic map(
                        DEVICE           => DEVICE                     ,
                        BASE_RND_BIT     => DPD_CORE_RND_BIT-1         , 
                        TAP_NUM          => DPD_CORE_TAP_NUM                            
                        )
                    port map(
                        RST              => rst_complex_filter(I)      , 
                        CLK              => CLK_DPD                    , 
                                                        
                        Q_POINT_SEL_IN   => DPD_QPOINT_SEL_IN(I)       ,

                        COEF_I_IN        => dpd_coef_14taps_i(I)       , 
                        COEF_Q_IN        => dpd_coef_14taps_q(I)       , 
                    
                        DATA_VLD_IN      => data_vld(I)                ,
                        DATA_I_IN        => data_i_lmt_sh(I)           ,
                        DATA_Q_IN        => data_q_lmt_sh(I)           ,
                                                             
                        DATA_VLD_OUT     => dpd_core_out_vld(I)        ,
                        DATA_I_OUT       => dpd_core_out_i(I)          ,
                        DATA_Q_OUT       => dpd_core_out_q(I)           
                        );
                end generate;
            end generate;
        end generate;


        P_DPD_Core_Bypass_DC : process(CLK_DPD) begin
            if (CLK_DPD'event) and (CLK_DPD = '1') then
                dpd_core_bypass_sh(I) <= dpd_core_bypass_sh(I)(1 downto 0) & DPD_CORE_BYPASS_IN(I);  
            end if;
        end process;

        P_DPD_CORE_Bypass : process(CLK_DPD) begin
            if (CLK_DPD'event) and (CLK_DPD = '1') then
                if (rst_complex_filter(I) = '1') then
                    DPD_CORE_VLD_OUT(I) <= '0';               
                    DPD_CORE_I_OUT(I)   <= (others => '0');   
                    DPD_CORE_Q_OUT(I)   <= (others => '0');   
                else
                    if (dpd_core_bypass_sh(I)(2) = '1') then
                        DPD_CORE_VLD_OUT(I) <= DPD_CORE_VLD_IN(I);               
                        DPD_CORE_I_OUT(I)   <= DPD_CORE_I_IN(I);   
                        DPD_CORE_Q_OUT(I)   <= DPD_CORE_Q_IN(I);   
                    else
                        DPD_CORE_VLD_OUT(I) <= dpd_core_out_vld(I);                  
                        DPD_CORE_I_OUT(I)   <= dpd_core_out_i(I);      
                        DPD_CORE_Q_OUT(I)   <= dpd_core_out_q(I);       
                    end if;
                end if;
            end if;
        end process;

    end generate;

end arc_DPD_CORE;
