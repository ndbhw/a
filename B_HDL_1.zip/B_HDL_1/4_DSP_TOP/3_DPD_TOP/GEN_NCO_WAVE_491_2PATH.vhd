-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part
-- Block Name : GEN_NCO_WAVE

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.numeric_std.all;
use ieee.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

-- !!!!!!!!!! Caution !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
-- !! Resolution    : 2.5kHz
-- !! Sampling Rate : 368.64Msps
-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
entity GEN_NCO_WAVE_491_2PATH is
generic(
    DEVICE               : string  := "ULTRASCALE";
    PATH2_EVEN           : boolean :=        TRUE ;    
    RES_VAL              : natural :=       24576 ;
    DATA_WIDTH           : natural :=          16
    );
port(
    RST                  : in  std_logic;
    CLK                  : in  std_logic;

    SAMPLE_VLD_IN        : in  std_logic;

    NCO_WREN_IN          : in  std_logic;
    NCO_FREQ_OFFSET_IN   : in  std_logic_vector(log2(RES_VAL) downto 0);

    NCO_FREQ_COMP_OFFSET : in  std_logic_vector(log2(RES_VAL) downto 0);

    COS_OUT              : out std_logic_vector(DATA_WIDTH-1 downto 0);
    SIN_OUT              : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end GEN_NCO_WAVE_491_2PATH;

architecture arc_GEN_NCO_WAVE_491_2PATH of GEN_NCO_WAVE_491_2PATH is

component NCO_ROM_245 is
generic(
    DATA_WIDTH                  : natural := 15;
    ADDR_DEPTH                  : natural := 24576
);
port(
    CLK                         : in  std_logic;
    ADDR_A                      : in  std_logic_vector(log2(ADDR_DEPTH)-1 downto 0);
    ADDR_B                      : in  std_logic_vector(log2(ADDR_DEPTH)-1 downto 0);
    Q_A                         : out std_logic_vector((DATA_WIDTH -1) downto 0);
    Q_B                         : out std_logic_vector((DATA_WIDTH -1) downto 0)
);
end component;

component SAT_UNSIGN is
generic(
    HS_MODE    : boolean :=  TRUE;  -- High Speed Mode (Operating Clock > 307.2MHz)
    INPUT_BIT  : natural;
    OUTPUT_BIT : natural
    );
port(
    RST        : in  std_logic;
    CLK        : in  std_logic;
    DATA_IN    : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT   : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

component SRL16E_DLY is
generic(
    DEVICE    : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HS_MODE   : boolean :=        TRUE ;

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK      : IN  STD_LOGIC;
    DATA_IN  : IN  STD_LOGIC_VECTOR(BIT_WIDTH-1 downto 0);
    DATA_OUT : OUT STD_LOGIC_VECTOR(BIT_WIDTH-1 downto 0) -- Delayed DATA
    );
end component;

constant ROM_DEPTH                : natural:=log2(RES_VAL);

signal nco_update_auto_recovery   : std_logic_vector(31 downto 0);
signal nco_update                 : std_logic_vector( 7 downto 0);
signal nco_update_rpls            : std_logic_vector( 1 downto 0);

signal freq_comp_offset           : std_logic_vector(log2(RES_VAL)+1 downto 0);

signal freq_offset                : std_logic_vector(log2(RES_VAL)+1 downto 0);

signal freq_word                  : std_logic_vector(log2(RES_VAL)+1 downto 0);

signal freq_word_sat              : std_logic_vector(log2(RES_VAL) downto 0);

signal accumulator                : std_logic_vector(log2(RES_VAL) downto 0);
signal accumulator_d              : std_logic_vector(log2(RES_VAL) downto 0);
signal toggle                     : std_logic;
signal acc_e                      : std_logic_vector(log2(RES_VAL)+1 downto 0);
signal acc_o                      : std_logic_vector(log2(RES_VAL)+1 downto 0);
signal acc_e_mod                  : std_logic_vector(log2(RES_VAL)+1 downto 0);
signal acc_o_mod                  : std_logic_vector(log2(RES_VAL)+1 downto 0);
signal acc_tmp                    : std_logic_vector(log2(RES_VAL) downto 0);

signal angle_1                    : std_logic;
signal angle_2                    : std_logic;  
signal angle_3                    : std_logic;


signal angle                      : std_logic_vector(log2(RES_VAL)-1 downto 0);
signal angle90                    : std_logic_vector(log2(RES_VAL)-3 downto 0);

signal angle_sin                  : std_logic_vector(ROM_DEPTH-3 downto 0);
signal angle_cos                  : std_logic_vector(ROM_DEPTH-3 downto 0);
signal angle_sin_d1               : std_logic_vector(ROM_DEPTH-3 downto 0);
signal angle_cos_d1               : std_logic_vector(ROM_DEPTH-3 downto 0);

signal angle_cos_ones_flg         : std_logic;

signal addr_sin                   : std_logic_vector(ROM_DEPTH-3 downto 0);
signal addr_cos                   : std_logic_vector(ROM_DEPTH-3 downto 0);
signal rom_out_sin                : std_logic_vector(DATA_WIDTH-2 downto 0);
signal rom_out_cos                : std_logic_vector(DATA_WIDTH-2 downto 0);

signal sin_pos                    : std_logic_vector(DATA_WIDTH-1 downto 0);
signal cos_pos                    : std_logic_vector(DATA_WIDTH-1 downto 0);
signal sin_neg                    : std_logic_vector(DATA_WIDTH-1 downto 0);
signal cos_neg                    : std_logic_vector(DATA_WIDTH-1 downto 0);

signal angle_phase                : std_logic_vector( 1 downto 0);
signal quadrant                   : std_logic_vector( 1 downto 0);

begin
    
	process(CLK) begin
		if (CLK'event) and (CLK = '1') then
			if (RST = '1') then
				nco_update_auto_recovery <= x"0000FFFF";
				nco_update               <= (others => '0');
				nco_update_rpls          <= (others => '0');
			else
				nco_update_auto_recovery <= nco_update_auto_recovery(30 downto 0) & '0';
				nco_update               <= nco_update(6 downto 0) & (nco_update_auto_recovery(31) or NCO_WREN_IN);
				nco_update_rpls(0)       <= nco_update(1) and (not nco_update(2));
				nco_update_rpls(1)       <= nco_update(5) and (not nco_update(6));
			end if;
		end if;
	end process;

	process(CLK) begin
		if (CLK'event) and (CLK = '1') then
			if (RST = '1') then
				freq_comp_offset 		<= (others => '0');
			else
				freq_comp_offset 		<= '0'&NCO_FREQ_COMP_OFFSET;
			end if;
		end if;
	end process;

	process(CLK) begin
		if (CLK'event) and (CLK = '1') then
			if (RST = '1') then
				freq_offset 			<= (others => '0');
			else
				if (nco_update_rpls(0) = '1') then
					freq_offset 		<= '0'&NCO_FREQ_OFFSET_IN;
				else
					freq_offset 		<= freq_offset;
				end if;
			end if;
		end if;
	end process;

	process(CLK) begin
		if (CLK'event) and (CLK = '1') then
			freq_word 					<= freq_offset + freq_comp_offset;
		end if;
	end process;

    U_FREQ_Word_SAT_HS : SAT_UNSIGN generic map(TRUE, log2(RES_VAL)+2, log2(RES_VAL)+1) port map(RST, CLK, freq_word, freq_word_sat);

	--------------------------------------------------------------------------------------------------------------------------------------

	process(CLK) begin
	if (CLK'event) and (CLK = '1') then
			if (nco_update_rpls(1) = '1') then toggle <= '1'; else toggle <= not toggle; end if;

			if (toggle = '1') then
				accumulator 			<= acc_e_mod(log2(RES_VAL) downto 0);
			else
				accumulator 			<= acc_o_mod(log2(RES_VAL) downto 0);
			end if;
		end if;
	end process;
	
	EVEN_PATH : if (PATH2_EVEN = TRUE) generate
		process(RST, CLK)
		begin
			if (RST = '1') then
				acc_e 					<= (others => '0');
				acc_e_mod 				<= (others => '0');
			elsif (rising_edge(CLK)) then
				if (nco_update_rpls(1) = '1') then
					acc_e 				<= (others => '0');
				elsif (toggle = '1') then
					acc_e 				<= acc_e_mod + (freq_word_sat & '0');
				else
					acc_e 				<= acc_e;
				end if;
				
				if (nco_update_rpls(1) = '1') then
					acc_e_mod 			<= (others => '0');
				elsif acc_e >= 3*RES_VAL then
					acc_e_mod 			<= acc_e - 3*RES_VAL;
				elsif acc_e >= 2*RES_VAL then
					acc_e_mod 			<= acc_e - 2*RES_VAL;
				elsif acc_e >= RES_VAL and acc_e < 2*RES_VAL then
					acc_e_mod 			<= acc_e - RES_VAL;
				else
					acc_e_mod 			<= acc_e;
				end if;
			end if;
		end process;
		
		process(RST, CLK)
		begin
			if (RST = '1') then
				acc_o 					<=	("0" & freq_word_sat);
				acc_o_mod 				<=  (others => '0');
			elsif (rising_edge(CLK)) then
				if (nco_update_rpls(1) = '1') then				
					acc_o 				<=  ("0" & freq_word_sat);
				elsif (toggle = '0') then
					acc_o 				<=  acc_o_mod + (freq_word_sat & '0');
				else
					acc_o				<=	acc_o;
				end if;
				
				if (nco_update_rpls(1) = '1') then
					acc_o_mod 			<= (others => '0');
				elsif acc_o >= 3*RES_VAL then
					acc_o_mod 			<= acc_o - 3*RES_VAL;
				elsif acc_o >= 2*RES_VAL then
					acc_o_mod 			<= acc_o - 2*RES_VAL;
				elsif acc_o >= RES_VAL and acc_o < 2*RES_VAL then
					acc_o_mod 			<= acc_o - RES_VAL;
				else
					acc_o_mod 			<= acc_o;
				end if;
			end if;
		end process;
	end generate EVEN_PATH;

	ODD_PATH : if (PATH2_EVEN = FALSE) generate
		process(RST, CLK)
		begin
			if (RST = '1') then
				acc_e 					<= (others => '0');
				acc_e_mod 				<= (others => '0');
			elsif (rising_edge(CLK)) then
				if (nco_update_rpls(1) = '1') then
					acc_e 				<= (others => '0');
				elsif (toggle = '1') then
					acc_e 				<= acc_e_mod + (freq_word_sat & '0');
				else
					acc_e 				<= acc_e;
				end if;
				
				if (nco_update_rpls(1) = '1') then
					acc_e_mod 			<= ("0" & freq_word(log2(RES_VAL)+1 downto 1));
				elsif acc_e >= 3*RES_VAL then
					acc_e_mod 			<= acc_e - 3*RES_VAL;
				elsif acc_e >= 2*RES_VAL then
					acc_e_mod 			<= acc_e - 2*RES_VAL;
				elsif acc_e >= RES_VAL and acc_e < 2*RES_VAL then
					acc_e_mod 			<= acc_e - RES_VAL;
				else
					acc_e_mod 			<= acc_e;
				end if;
			end if;
		end process;
		
		process(RST, CLK)
		begin
			if (RST = '1') then
				acc_o 					<=	("0" & freq_word_sat);
				acc_o_mod 				<=  (others => '0');
			elsif (rising_edge(CLK)) then
				if (nco_update_rpls(1) = '1') then				
					acc_o 				<=  ("0" & freq_word_sat) + ("00" & freq_word_sat(log2(RES_VAL) downto 1));
				elsif (toggle = '0') then
					acc_o 				<=  acc_o_mod + (freq_word_sat & '0');
				else
					acc_o				<=	acc_o;
				end if;
				
				if (nco_update_rpls(1) = '1') then
					acc_o_mod 			<= (others => '0');
				elsif acc_o >= 3*RES_VAL then
					acc_o_mod 			<= acc_o - 3*RES_VAL;
				elsif acc_o >= 2*RES_VAL then
					acc_o_mod 			<= acc_o - 2*RES_VAL;
				elsif acc_o >= RES_VAL and acc_o < 2*RES_VAL then
					acc_o_mod 			<= acc_o - RES_VAL;
				else
					acc_o_mod 			<= acc_o;
				end if;
			end if;
		end process;
	end generate ODD_PATH;

	process(CLK) begin
		if (CLK'event) and (CLK = '1') then
			if accumulator < RES_VAL/2 then
				angle_1 			<= '1';
			else
				angle_1 			<= '0';
			end if;

			if accumulator < RES_VAL/4 then
				angle_2 			<= '1';
			else
				angle_2 			<= '0';
			end if;

			if accumulator < RES_VAL*3/4 then
				angle_3 			<= '1';
			else
				angle_3 			<= '0';
			end if;
			
			accumulator_d <= accumulator;

			if (angle_1 = '1') then
				if (angle_2 = '1') then
					angle(  ROM_DEPTH-1 downto ROM_DEPTH-2) <= "00";
					
					angle(  ROM_DEPTH-3 downto 0) <=                 accumulator_d(ROM_DEPTH-3 downto 0);
					angle90(ROM_DEPTH-3 downto 0) <= (RES_VAL*1/4) - accumulator_d(ROM_DEPTH-3 downto 0);
				else
					angle(ROM_DEPTH-1 downto ROM_DEPTH-2) <= "01";
	
					angle(  ROM_DEPTH-3 downto 0) <=                 accumulator_d(ROM_DEPTH-3 downto 0) - RES_VAL*1/4;
					angle90(ROM_DEPTH-3 downto 0) <= (RES_VAL*2/4) - accumulator_d(ROM_DEPTH-3 downto 0);
				end if;
			else
				if (angle_3 = '1') then
					angle(ROM_DEPTH-1 downto ROM_DEPTH-2) <= "10";                        
					
					angle(  ROM_DEPTH-3 downto 0) <=                 accumulator_d(ROM_DEPTH-3 downto 0) - RES_VAL*2/4;
					angle90(ROM_DEPTH-3 downto 0) <= (RES_VAL*3/4) - accumulator_d(ROM_DEPTH-3 downto 0);
				else
					angle(ROM_DEPTH-1 downto ROM_DEPTH-2) <= "11";

					angle(  ROM_DEPTH-3 downto 0) <=                 accumulator_d(ROM_DEPTH-3 downto 0) - RES_VAL*3/4;
					angle90(ROM_DEPTH-3 downto 0) <= (RES_VAL*4/4) - accumulator_d(ROM_DEPTH-3 downto 0);
				end if;
			end if;
		end if;
	end process;

	process(CLK) begin
		if (CLK'event) and (CLK = '1') then
			angle_sin    <= angle(  ROM_DEPTH-3 downto 0);
			angle_cos    <= angle90(ROM_DEPTH-3 downto 0);
			angle_sin_d1 <= angle_sin;
			angle_cos_d1 <= angle_cos;
		end if;
	end process;

	process(CLK) begin
		if (CLK'event) and (CLK = '1') then
			if (angle_cos = RES_VAL/4) then
				angle_cos_ones_flg <= '1';
			else
				angle_cos_ones_flg <= '0';
			end if;
		end if;
	end process;

	process(CLK) begin
		if (CLK'event) and (CLK = '1') then
			if (RST = '1') then
				addr_sin <= (others => '0'); -- Synchronous Reset for Avoiding ROM data corruption
				addr_cos <= (others => '0'); -- Synchronous Reset for Avoiding ROM data corruption
			else
				addr_sin <= angle_sin_d1;

				if (angle_cos_ones_flg = '1') then
					addr_cos <= conv_std_logic_vector(RES_VAL/4-1,ROM_DEPTH-2);
				else
					addr_cos <= angle_cos_d1;-- + '1'; -- Cosine signal should be start from 2^N offset, except when address is all ones
				end if;
			end if;
		end if;
	end process;

	G_ROM_245 : if RES_VAL=24576*4 generate
		U_NCO_ROM : NCO_ROM_245 generic map(DATA_WIDTH-1, RES_VAL/4) port map(CLK, addr_sin, addr_cos, rom_out_sin, rom_out_cos);
	end generate;

	process(CLK) begin
		if (CLK'event) and (CLK = '1') then
			if (RST = '1') then
				sin_pos <= (others => '0');
				cos_pos <= (others => '0');
				sin_neg <= (others => '0');
				cos_neg <= (others => '0');
			else
				sin_pos <= '0' & rom_out_sin;
				cos_pos <= '0' & rom_out_cos;
				sin_neg <= ('1' & (not rom_out_sin)) + '1';
				cos_neg <= ('1' & (not rom_out_cos)) + '1';
			end if;
		end if;
	end process;

	process(CLK) begin
		if (CLK'event) and (CLK = '1') then
			angle_phase <= angle(ROM_DEPTH-1 downto ROM_DEPTH-2);
		end if;
	end process;

    P_Quadrant_Align : SRL16E_DLY generic map(DEVICE, TRUE, 2, 5) port map(CLK, angle_phase, quadrant);

	process(CLK) begin
		if rising_edge(CLK) then
			case quadrant is
				when "00" => COS_OUT <= cos_pos; SIN_OUT <= sin_pos;
				when "01" => COS_OUT <= sin_neg; SIN_OUT <= cos_pos;
				when "10" => COS_OUT <= cos_neg; SIN_OUT <= sin_neg;
				when "11" => COS_OUT <= sin_pos; SIN_OUT <= cos_neg;
				when others => null;
			end case;
		end if;
	end process;
	
end arc_GEN_NCO_WAVE_491_2PATH;