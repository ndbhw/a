-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part
-- Block Name : NCO_SYMMETRY

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;
use IEEE.math_real.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity NCO_SYMMETRY_491_2PATH is
generic(
    DEVICE               : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2

    HOVS                 : natural :=        2 ; -- HOVS = (Clock Frequency)/(Sampling Rate)
    SYMMETRY             : boolean :=    FALSE ; -- TRUE  : Symmetry Operation(+a/-a freq shift), Generate POS/NEG_SHIFT_PATH
                                                 -- FALSE : Simplex Operation(+a freq shift), Only Generate POS_SHIFT_PATH
    POS_SHIFTH_PATH_NUM  : natural :=        2 ; -- The Number of Positive Frequency Shifting Path Number
    NEG_SHIFTH_PATH_NUM  : natural :=        1 ; -- The Number of Negative Frequency Shifting Path Number
    NCO_WIDTH            : natural :=       16 ; -- Sinusoidal Wave Sample Wdith
    RES_VAL              : natural :=    24576   -- Frequency Shift Step Resolution, 10kHz
);
port(
    RST_245               		: in  std_logic;
	RST_491               		: in  std_logic;
    CLK_245              		: in  std_logic;
	CLK_491				 		: in  std_logic;

    NCO_WREN             		: in  std_logic;
    NCO_WORD             		: in  std_logic_vector(31 downto 0);

    NCO_FREQ_COMP_OFFSET		: in  std_logic_vector(31 downto 0);

    DATA_P_SH_VLD_IN_EVEN		: in  std_logic_vector( POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift_even
    DATA_P_SH_I_IN_EVEN			: in  std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift_even
    DATA_P_SH_Q_IN_EVEN			: in  std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift_even

    DATA_P_SH_VLD_OUT_EVEN 	 	: out std_logic_vector( POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift_even
    DATA_P_SH_I_OUT_EVEN   	 	: out std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift_even
    DATA_P_SH_Q_OUT_EVEN    	: out std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift_even
	
	DATA_P_SH_VLD_IN_ODD		: in  std_logic_vector( POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift_odd
    DATA_P_SH_I_IN_ODD			: in  std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift_odd
    DATA_P_SH_Q_IN_ODD			: in  std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift_odd

    DATA_P_SH_VLD_OUT_ODD 	 	: out std_logic_vector( POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift_odd
    DATA_P_SH_I_OUT_ODD   	 	: out std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift_odd
    DATA_P_SH_Q_OUT_ODD    		: out std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift_odd

    DATA_N_SH_VLD_IN     		: in  std_logic_vector( NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_I_IN       		: in  std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_Q_IN       		: in  std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift

    DATA_N_SH_VLD_OUT    		: out std_logic_vector( NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_I_OUT      		: out std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_Q_OUT      		: out std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
	
	sin_out_even				: out std_logic_vector(NCO_WIDTH-1 downto 0);
	cos_out_even				: out std_logic_vector(NCO_WIDTH-1 downto 0);
	sin_out_odd 				: out std_logic_vector(NCO_WIDTH-1 downto 0);
	cos_out_odd 				: out std_logic_vector(NCO_WIDTH-1 downto 0)
);
end NCO_SYMMETRY_491_2PATH;

architecture arc_NCO_SYMMETRY_491_2PATH of NCO_SYMMETRY_491_2PATH is

-- !!!!!!!!!! Caution !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
-- !! Resolution    : 2.5kHz
-- !! Sampling Rate : 368.64Msps
-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
constant RESOLUTION      	 : real    := 2.5; -- kHz
constant RES_FACTOR      	 : natural := natural(10.0/RESOLUTION);
constant RESOLUTION_VAL  	 : natural := RES_VAL*RES_FACTOR;
constant RESOLUTION_VAL_ODD  : natural := RES_VAL*RES_FACTOR*2;

component RST_SYNC is
	generic(
		DLY_NUM              : natural := 3;    -- Number of delay.
		MAX_FANOUT_NUM       : integer := 200   -- Number of maximum fanout
	);
	port(
		RST_IN               : in  std_logic;   -- Active high asynchronous reset
		CLK                  : in  std_logic;   -- clock to be sync'ed to
		RST_OUT              : out std_logic    -- "Synchronised" reset signal
	);
end component;

component GEN_NCO_WAVE_491_2PATH is
	generic(
		DEVICE               : string  := "ULTRASCALE";
		PATH2_EVEN           : boolean :=        TRUE ;    
		RES_VAL              : natural :=       24576 ;
		DATA_WIDTH           : natural :=          16
	);
	port(
		RST                  : in  std_logic;
		CLK                  : in  std_logic;

		SAMPLE_VLD_IN        : in  std_logic;

		NCO_WREN_IN          : in  std_logic;
		NCO_FREQ_OFFSET_IN   : in  std_logic_vector(log2(RES_VAL) downto 0);

		NCO_FREQ_COMP_OFFSET : in  std_logic_vector(log2(RES_VAL) downto 0);

		COS_OUT              : out std_logic_vector(DATA_WIDTH-1 downto 0);
		SIN_OUT              : out std_logic_vector(DATA_WIDTH-1 downto 0)
	);
end component;

component MIXER is
	generic(
		DEVICE               : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
		HS_MODE              : boolean :=     TRUE ;

		HOVS                 : natural :=        2 ;
		DATA_WIDTH           : natural :=       16 ;
		RND_BIT              : natural :=       15
		);
	port(
		RST                  : in  std_logic;
		CLK                  : in  std_logic;

		SAMPLE_VLD_IN        : in  std_logic;
		SAMPLE_I_IN          : in  std_logic_vector(DATA_WIDTH-1 downto 0);
		SAMPLE_Q_IN          : in  std_logic_vector(DATA_WIDTH-1 downto 0);

		COS_I_IN             : in  std_logic_vector(DATA_WIDTH-1 downto 0);
		SIN_Q_IN             : in  std_logic_vector(DATA_WIDTH-1 downto 0);

		SAMPLE_VLD_OUT       : out std_logic;
		SAMPLE_I_OUT         : out std_logic_vector(DATA_WIDTH-1 downto 0);
		SAMPLE_Q_OUT         : out std_logic_vector(DATA_WIDTH-1 downto 0)
	);
end component;

component DPD_SIMPLE_DPRAM is
	generic(
		RAM_TYPE                    : string  := "block"       ; -- "auto" or "distributed" or "block" or "ultra" 
		CLOCKING_MODE               : string  := "common_clock"; -- "common_clock" or "independent_clock"
		OPERATING_MODE              : string  := "read_first"  ; -- "no_change" or "read_first" or "write_first"

		A_ADDR_DEPTH                : integer :=  1024         ;
		A_DATA_WIDTH                : integer :=     8         ;

		B_ADDR_DEPTH                : integer :=  1024         ;
		B_DATA_WIDTH                : integer :=     8         ;

		READ_LATENCY                : integer :=     2         ;

		RAM_INIT_FILE               : string  := "none"        ; 
		RAM_INIT_VALUE              : string  := "0" 
	);
	port(
		CLK_A                       : in  std_logic;
		EN_A                        : in  std_logic;
		WE_A                        : in  std_logic;
		ADDR_A                      : in  std_logic_vector(integer(floor(log2(real(A_ADDR_DEPTH-1)))) downto 0);
		DATA_A                      : in  std_logic_vector(A_DATA_WIDTH-1 downto 0);

		CLK_B                       : in  std_logic;
		EN_B                        : in  std_logic;
		ADDR_B                      : in  std_logic_vector(integer(floor(log2(real(B_ADDR_DEPTH-1)))) downto 0);
		DATA_B                      : out std_logic_vector(B_DATA_WIDTH-1 downto 0)
	);
end component DPD_SIMPLE_DPRAM;

signal p_nco_sin_even           : std_logic_vector(NCO_WIDTH-1 downto 0);
signal p_nco_cos_even           : std_logic_vector(NCO_WIDTH-1 downto 0);
signal p_nco_cos_even_1d		: std_logic_vector(NCO_WIDTH-1 downto 0);
signal p_nco_sin_even_1d		: std_logic_vector(NCO_WIDTH-1 downto 0);

signal p_nco_sin_odd            : std_logic_vector(NCO_WIDTH-1 downto 0);
signal p_nco_cos_odd            : std_logic_vector(NCO_WIDTH-1 downto 0);
signal p_nco_sin_odd_1d         : std_logic_vector(NCO_WIDTH-1 downto 0);
signal p_nco_cos_odd_1d         : std_logic_vector(NCO_WIDTH-1 downto 0);

signal n_nco_sin                : std_logic_vector(NCO_WIDTH-1 downto 0);
signal n_nco_cos                : std_logic_vector(NCO_WIDTH-1 downto 0);

constant zeros                  : std_logic_vector(NCO_WIDTH-1 downto 0) := (others => '0');

begin

    U_NCO_GEN_Sinusoidal_Wave_enen : GEN_NCO_WAVE_491_2PATH
		generic map(
			DEVICE               => DEVICE,
			PATH2_EVEN           => TRUE,
			RES_VAL              => RESOLUTION_VAL,
			DATA_WIDTH           => NCO_WIDTH
		)
		port map(
			RST                  => RST_245,
			CLK                  => CLK_245,

			SAMPLE_VLD_IN        => '1',

			NCO_WREN_IN          => NCO_WREN,
			NCO_FREQ_OFFSET_IN   => NCO_WORD(log2(RESOLUTION_VAL) downto 0),

			NCO_FREQ_COMP_OFFSET => NCO_FREQ_COMP_OFFSET(log2(RESOLUTION_VAL) downto 0),

			COS_OUT              => p_nco_cos_even,
			SIN_OUT              => p_nco_sin_even
		);
	
	U_NCO_GEN_Sinusoidal_Wave_odd : GEN_NCO_WAVE_491_2PATH
		generic map(
			DEVICE               => DEVICE,
			PATH2_EVEN           => FALSE,
			RES_VAL              => RESOLUTION_VAL,
			DATA_WIDTH           => NCO_WIDTH
		)
		port map(
			RST                  => RST_245,
			CLK                  => CLK_245,

			SAMPLE_VLD_IN        => '1',

			NCO_WREN_IN          => NCO_WREN,
			NCO_FREQ_OFFSET_IN   => NCO_WORD(log2(RESOLUTION_VAL) downto 0),

			NCO_FREQ_COMP_OFFSET => NCO_FREQ_COMP_OFFSET(log2(RESOLUTION_VAL) downto 0),

			COS_OUT              => p_nco_cos_odd,
			SIN_OUT              => p_nco_sin_odd
		);

	-------------------------------------------------------------------------------------------	
	
	process(CLK_245)
	begin
		if (rising_edge(CLK_245)) then
			p_nco_cos_even_1d			<=	p_nco_cos_even;
			p_nco_sin_even_1d			<=	p_nco_sin_even;
			p_nco_sin_odd_1d			<=	p_nco_sin_odd;
			p_nco_cos_odd_1d			<=	p_nco_cos_odd;
		end if;
	end process;	
	
	sin_out_even			<=	p_nco_sin_even_1d;
	cos_out_even			<=	p_nco_cos_even_1d;
	sin_out_odd 			<=	p_nco_sin_odd;
	cos_out_odd 			<=	p_nco_cos_odd;
	----------------------------------------------------------------------------------------------------------------------
	
    G_NCO_Positive_Frequency_Shifting : for P in 0 to (POS_SHIFTH_PATH_NUM - 1) generate begin
        U_Positive_Frequency_Shift_MIXER_EVEN : MIXER
			generic map(
				DEVICE           => DEVICE,
				HS_MODE          => TRUE,

				HOVS             => HOVS,
				DATA_WIDTH       => NCO_WIDTH,
				RND_BIT          => NCO_WIDTH-1
			)
			port map(
				RST              => RST_245,
				CLK              => CLK_245,

				SAMPLE_VLD_IN    => DATA_P_SH_VLD_IN_EVEN(P),
				SAMPLE_I_IN      => DATA_P_SH_I_IN_EVEN(P),
				SAMPLE_Q_IN      => DATA_P_SH_Q_IN_EVEN(P),

				COS_I_IN         => p_nco_cos_even_1d,
				SIN_Q_IN         => p_nco_sin_even_1d,

				SAMPLE_VLD_OUT   => DATA_P_SH_VLD_OUT_EVEN(P),
				SAMPLE_I_OUT     => DATA_P_SH_I_OUT_EVEN(P),
				SAMPLE_Q_OUT     => DATA_P_SH_Q_OUT_EVEN(P)
            );
			
		U_Positive_Frequency_Shift_MIXER_ODD : MIXER
			generic map(
				DEVICE           => DEVICE,
				HS_MODE          => TRUE,

				HOVS             => HOVS,
				DATA_WIDTH       => NCO_WIDTH,
				RND_BIT          => NCO_WIDTH-1
			)
			port map(
				RST              => RST_245,
				CLK              => CLK_245,

				SAMPLE_VLD_IN    => DATA_P_SH_VLD_IN_ODD(P),
				SAMPLE_I_IN      => DATA_P_SH_I_IN_ODD(P),
				SAMPLE_Q_IN      => DATA_P_SH_Q_IN_ODD(P),

				COS_I_IN         => p_nco_cos_odd_1d,
				SIN_Q_IN         => p_nco_sin_odd_1d,				

				SAMPLE_VLD_OUT   => DATA_P_SH_VLD_OUT_ODD(P),
				SAMPLE_I_OUT     => DATA_P_SH_I_OUT_ODD(P),
				SAMPLE_Q_OUT     => DATA_P_SH_Q_OUT_ODD(P)
            );
    end generate;

    -- G_NCO_SYMMETRY_MODE : if (SYMMETRY = TRUE) generate begin

        -- P_Reverse_NCO_Generate_HS : process(CLK_245) begin
            -- if (CLK_245'event) and (CLK_245 = '1') then
                -- n_nco_sin <= p_nco_sin ;          -- sin
                -- n_nco_cos <= (not p_nco_cos) + 1; -- -cos
            -- end if;
        -- end process;

        -- G_NCO_Negative_Frequency_Shifting : for N in 0 to (NEG_SHIFTH_PATH_NUM - 1) generate begin

            -- U_Negative_Frequency_Shift_MIXER : MIXER
            -- generic map(
                -- DEVICE           => DEVICE              ,
                -- HS_MODE          => TRUE                ,

                -- HOVS             => HOVS                ,
                -- DATA_WIDTH       => NCO_WIDTH           ,
                -- RND_BIT          => NCO_WIDTH-1
                -- )
            -- port map(
                -- RST              => RST_245           ,
                -- CLK              => CLK_245                 ,

                -- SAMPLE_VLD_IN    => DATA_N_SH_VLD_IN(N) ,
                -- SAMPLE_I_IN      => DATA_N_SH_I_IN(N)   ,
                -- SAMPLE_Q_IN      => DATA_N_SH_Q_IN(N)   ,

                -- COS_I_IN         => n_nco_cos           ,
                -- SIN_Q_IN         => n_nco_sin           ,

                -- SAMPLE_VLD_OUT   => DATA_N_SH_VLD_OUT(N),
                -- SAMPLE_I_OUT     => DATA_N_SH_I_OUT(N)  ,
                -- SAMPLE_Q_OUT     => DATA_N_SH_Q_OUT(N)
                -- );

        -- end generate;
    -- end generate;

    G_NCO_SIMPLEX_MODE : if (SYMMETRY = FALSE) generate begin

        -- n_nco_sin <= zeros; -- sin
        -- n_nco_cos <= zeros; -- -cos

        DATA_N_SH_VLD_OUT <= DATA_N_SH_VLD_IN;
        DATA_N_SH_I_OUT   <= DATA_N_SH_I_IN;
        DATA_N_SH_Q_OUT   <= DATA_N_SH_Q_IN;

    end generate;

end arc_NCO_SYMMETRY_491_2PATH;
