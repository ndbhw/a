-- k1340.heo

Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

entity SRLC32E_DLY is
generic(
    DEVICE    : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HS_MODE   : boolean :=        TRUE ;

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_COUT : out std_logic_vector(BIT_WIDTH-1 downto 0); -- SRLC32E Chain, 32clock Delayed DATA
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0)  -- Delayed DATA
    );
end SRLC32E_DLY;

architecture arc_SRLC32E_DLY of SRLC32E_DLY is

component SRLC32E_DLY_7S is
generic(
    HS_MODE   : boolean := TRUE;

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_COUT : out std_logic_vector(BIT_WIDTH-1 downto 0); -- SRLC32E Chain, 32clock Delayed DATA
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0)  -- Delayed DATA
    );
end component;

component SRLC32E_DLY_US is
generic(
    HS_MODE   : boolean := TRUE;

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_COUT : out std_logic_vector(BIT_WIDTH-1 downto 0); -- SRLC32E Chain, 32clock Delayed DATA
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0)  -- Delayed DATA
    );
end component;

begin	

    G_7Series_SRLC32E : if (DEVICE = "7SERIES") generate begin
        U_SRLC32E_DLY_7S : SRLC32E_DLY_7S generic map(HS_MODE, BIT_WIDTH, DELAY_NUM) port map(CLK, DATA_IN, DATA_COUT, DATA_OUT);
    end generate;

    G_UltraScale_SRL16E : if (DEVICE = "ULTRASCALE") generate begin
        U_SRLC32E_DLY_US : SRLC32E_DLY_US generic map(HS_MODE, BIT_WIDTH, DELAY_NUM) port map(CLK, DATA_IN, DATA_COUT, DATA_OUT);
    end generate;

end arc_SRLC32E_DLY;

