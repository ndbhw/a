--122.88->368.64MHz Interpolation filter
--PASSBAND 60M / 80M
--Processing delay : 49 clk @ 368.64MHz(60M)
--                   59 clk @ 368.64MHz(80M)

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity fir_i3_comm is
generic(
    ANT_NUM                     : integer:= 2;
    PASSBAND                    : integer:=60
);
port(
    RST_W                       : in  std_logic_vector(ANT_NUM-1 downto 0);
    RST_R                       : in  std_logic_vector(ANT_NUM-1 downto 0);
    CLK_W                       : in  std_logic;
    CLK_R                       : in  std_logic;

    DATA_IN_VALID               : in  std_logic;
    DATA_IN_I                   : in  std_logic_array16(ANT_NUM-1 downto 0);
    DATA_IN_Q                   : in  std_logic_array16(ANT_NUM-1 downto 0);

    BUF_COLLISION_FLAG          : out std_logic_vector(ANT_NUM-1 downto 0);
    DATA_OUT_VALID              : out std_logic_vector(ANT_NUM-1 downto 0);
    DATA_OUT_I                  : out std_logic_array16(ANT_NUM-1 downto 0);
    DATA_OUT_Q                  : out std_logic_array16(ANT_NUM-1 downto 0)
);
end fir_i3_comm;

architecture rtl of fir_i3_comm is

    component RST_SYNC is
    generic(
        DLY_NUM                     : natural := 3;    -- Number of delay.
        MAX_FANOUT_NUM              : integer := 200   -- Number of maximum fanout
        );
    port(
        RST_IN                      : in  std_logic;   -- Active high asynchronous reset
        CLK                         : in  std_logic;   -- clock to be sync'ed to
        RST_OUT                     : out std_logic    -- "Synchronised" reset signal
        );         
    end component;

    component fir_i3 is
    generic(
        VENDOR                      : string := "XILINX";
        CHANNEL_NUMBERS             : integer:= 1;
        WIDTH_IN                    : integer:= 16;
        WIDTH_OUT                   : integer:= 16;
        WIDTH_COEFF                 : integer:= 17;
        BINARY_POINT                : integer:= 14;
        HOVS                        : integer:= 2;
        ORDER                       : integer:= 55
    );
    port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        FRAME_I                     : in  std_logic;
        VALID_I                     : in  std_logic;
        FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

        FRAME_O                     : out std_logic;
        VALID_O                     : out std_logic;
        FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1  downto 0)
    );
    end component;

    component fir_3_buf is
    generic(
        W_HOVS                      : integer;
        R_HOVS                      : integer
    );
    port(
        RST_W                       : in  std_logic;
        RST_R                       : in  std_logic;
        CLK_W                       : in  std_logic;
        CLK_R                       : in  std_logic;

        DATA_IN_VALID               : in  std_logic;
        DATA_IN_I                   : in  std_logic_vector(15 downto 0);
        DATA_IN_Q                   : in  std_logic_vector(15 downto 0);

        BUF_COLLISION_FLAG          : out std_logic;
        DATA_OUT_VALID              : out std_logic;
        DATA_OUT_I                  : out std_logic_vector(15 downto 0);
        DATA_OUT_Q                  : out std_logic_vector(15 downto 0)
    );
    end component;

    constant VENDOR                 : string := "XILINX";
    constant WIDTH_IN               : integer:= 16;
    constant WIDTH_OUT              : integer:= 16;
    constant WIDTH_COEFF            : integer:= 16;
    constant WIDTH_RESULT           : integer:= 34;
    constant BINARY_POINT           : integer:= 14;
    constant HOVS                   : integer:= 3;
    constant ORDER                  : integer:= ternary_func(PASSBAND=60,24,36);

    signal rst_synch_w              : std_logic_vector(ANT_NUM-1 downto 0);
    signal rst_synch_r              : std_logic_vector(ANT_NUM-1 downto 0);

    signal buf_valid                : std_logic_vector(ANT_NUM-1 downto 0);
    signal buf_out_i                : std_logic_array16(ANT_NUM-1 downto 0);
    signal buf_out_q                : std_logic_array16(ANT_NUM-1 downto 0);
    signal fir_valid_in             : std_logic_vector(2*ANT_NUM-1 downto 0);
    signal fir_in                   : std_logic_array16(2*ANT_NUM-1 downto 0);
    signal fir_valid_out            : std_logic_vector(2*ANT_NUM-1 downto 0);
    signal fir_out                  : std_logic_array16(2*ANT_NUM-1 downto 0);


begin

GEN_BUF : for N in 0 to ANT_NUM-1 generate

    U_RST_SYNC_W : RST_SYNC generic map(4, 200) port map(RST_W(N), CLK_W, rst_synch_w(N));
    U_RST_SYNC_R : RST_SYNC generic map(4, 200) port map(RST_R(N), CLK_R, rst_synch_r(N));

    u_fir_3_buf : fir_3_buf
    generic map(
        W_HOVS                      => 1                            ,--: integer;
        R_HOVS                      => 3                             --: integer
    )
    port map(
        RST_W                       => rst_synch_w(N)               ,--: in  std_logic;
        RST_R                       => rst_synch_r(N)               ,--: in  std_logic;
        CLK_W                       => CLK_W                        ,--: in  std_logic;
        CLK_R                       => CLK_R                        ,--: in  std_logic;

        DATA_IN_VALID               => DATA_IN_VALID                ,--: in  std_logic;
        DATA_IN_I                   => DATA_IN_I(N)                 ,--: in  std_logic_vector(15 downto 0);
        DATA_IN_Q                   => DATA_IN_Q(N)                 ,--: in  std_logic_vector(15 downto 0);

        BUF_COLLISION_FLAG          => BUF_COLLISION_FLAG(N)        ,--: out std_logic;
        DATA_OUT_VALID              => buf_valid(N)                 ,--: out std_logic;
        DATA_OUT_I                  => buf_out_i(N)                 ,--: out std_logic_vector(15 downto 0);
        DATA_OUT_Q                  => buf_out_q(N)                  --: out std_logic_vector(15 downto 0)
    );

    process(rst_synch_r(N),CLK_R)
    begin
        if RST_R(N)='1' then
            fir_valid_in(2*N)   <= '0';
            fir_valid_in(2*N+1) <= '0';
            fir_in(2*N)         <= (others=>'0');
            fir_in(2*N+1)       <= (others=>'0');
        elsif CLK_R'event and CLK_R='1' then
            fir_valid_in(2*N)   <= buf_valid(N);
            fir_valid_in(2*N+1) <= buf_valid(N);
            fir_in(2*N)         <= buf_out_i(N);
            fir_in(2*N+1)       <= buf_out_q(N);
        end if;
    end process;
end generate;

GEN_FIR : for N in 0 to 2*ANT_NUM-1 generate
    u_fir_i3 : fir_i3
    generic map(
        VENDOR                      => VENDOR                       ,--: string := "XILINX";
        CHANNEL_NUMBERS             => 1                            ,--: integer:= 1;
        WIDTH_IN                    => WIDTH_IN                     ,--: integer:= 16;
        WIDTH_OUT                   => WIDTH_OUT                    ,--: integer:= 16;
        WIDTH_COEFF                 => WIDTH_COEFF                  ,--: integer:= 17;
        BINARY_POINT                => BINARY_POINT                 ,--: integer:= 14;
        HOVS                        => HOVS                         ,--: integer:= 2;
        ORDER                       => ORDER                         --: integer:= 56
    )
    port map(
        RST                         => rst_synch_r(N/2)             ,--: in  std_logic;
        CLK                         => CLK_R                        ,--: in  std_logic;

        FRAME_I                     => '0'                          ,--: in  std_logic;
        VALID_I                     => fir_valid_in(N)              ,--: in  std_logic;
        FILTER_IN                   => fir_in(N)                    ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);

        FRAME_O                     => open                         ,--: out std_logic;
        VALID_O                     => fir_valid_out(N)             ,--: out std_logic;
        FILTER_OUT                  => fir_out(N)                    --: out std_logic_vector(WIDTH_OUT-1  downto 0)
    );
end generate GEN_FIR;

GEN_OUT : for N in 0 to ANT_NUM-1 generate
    DATA_OUT_VALID(N) <= fir_valid_out(2*N);
    DATA_OUT_I(N)     <= fir_out(2*N)  ;
    DATA_OUT_Q(N)     <= fir_out(2*N+1);
end generate;

end rtl;


