------------------------------------------------------------------
-- channel swap
------------------------------------------------------------------
-- 2013.11.01, vyacheslav : 1st release, system verilog
-- 2014.01.29, wj311.kim  : convert system_verilog to vhdl
------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity pim_ser is
generic(
    CHANNEL_NUMBER              : integer := 20;
    HOVS                        : integer := 20;
    WIDTH_IN                    : integer := 16
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN*CHANNEL_NUMBER-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end pim_ser;

architecture Behavioral of pim_ser is

constant PROC_DELAY             : integer := 2;

type data_array                 is array(natural range <>) of std_logic_vector(WIDTH_IN-1 downto 0);

signal frame_i_d                : std_logic_vector(PROC_DELAY-1 downto 0);
signal hovs_cnt                 : std_logic_vector(ternary_func(HOVS=1, 1, log2(HOVS))-1 downto 0);
signal ch_cnt                   : std_logic_vector(log2(CHANNEL_NUMBER)-1 downto 0);
signal filter_in_r              : data_array(CHANNEL_NUMBER-1 downto 0);

begin

    -- Data Input Mapping
    FILTER_IN_GEN : for N in 0 to CHANNEL_NUMBER-1 generate
        process (RST, CLK)
        begin
        if RST = '1' then
            filter_in_r(N) <= (others => '0');
        elsif rising_edge(CLK) then
            if VALID_I = '1' then
                filter_in_r(N) <= FILTER_IN(WIDTH_IN*(N+1)-1 downto WIDTH_IN*N);
            end if;
        end if;
        end process;
    end generate;

    -- Valid input registering
    FRAME_O <= frame_i_d(frame_i_d'high);
    VALID_O <= '1' when HOVS=1 or (HOVS=2 and hovs_cnt=1) else
               '0';-- always '1' when CHANNEL_NUMBER = HOVS
    process (RST, CLK)
    begin
    if RST = '1' then
        frame_i_d <= (others => '0');
    elsif rising_edge(CLK) then
        frame_i_d <= frame_i_d(frame_i_d'length-2 downto 0) & FRAME_I;
    end if;
    end process;

    -- channel count for input data latch
    process (RST, CLK)
    begin
    if RST = '1' then
        hovs_cnt <= (others => '0');
        ch_cnt <= (others => '0');
    elsif rising_edge(CLK) then
        if FRAME_I = '1' then
            hovs_cnt <= (others => '0');
            ch_cnt <= (others => '0');
        else
            if hovs_cnt = HOVS-1 then
                if ch_cnt = CHANNEL_NUMBER-1 then
                    ch_cnt <= (others => '0');
                else
                    ch_cnt <= ch_cnt + 1;
                end if;
            end if;
            if HOVS=1 then
                hovs_cnt <= (others=>'0');
            else
                hovs_cnt <= hovs_cnt + '1';
            end if;
        end if;
    end if;
    end process;

    -- Serialized Ouptput
    process (RST, CLK)
    begin
    if RST = '1' then
        FILTER_OUT <= (others => '0');
    elsif rising_edge(CLK) then
        FILTER_OUT <= filter_in_r(conv_integer(ch_cnt));
    end if;
    end process;

end Behavioral;
