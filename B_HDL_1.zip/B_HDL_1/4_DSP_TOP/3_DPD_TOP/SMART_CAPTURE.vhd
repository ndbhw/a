----------------------------------------------------------------------------
-- Designer   : Kyoung Heo, (k1340.heo@samsung.com)
-- Block Name : SMART_CAPTURE
-- Function   : CFR/DPD/FB I/Q data gathering for DPD operation
-- Revision   : - ver 1.0, First Relase DPD & FB 4k Capture
--              - ver 2.0, CFR & DPD & FB 4k Capture
--              - ver 3.0, CFR & DPD & FB 4k/8k Capture
--              - ver 3.1, 4k mixed Capture debugging based on SC ver3.0
--              - ver 4.0, Considered HOVS2 (Sample Valid) 
--              - ver 4.1, Static Capture Debugging on TDD system (16.03.30)
--              - ver 5.0, Optimized SMART_CAPTURE (16.04~, Compact RRU)
--              - ver 5.1, Extend SC for PIM (17.02~, VzW RU)
----------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

--------------------------------------------------
--        Item    |     FDD mode    | TDD mode   |
--------------------------------------------------
--       TDD_MODE |        '0'      |    '1'     |
--------------------------------------------------
-- FRAME_TDD_SYNC | 10ms Frame Sync | TDD Strobe |
--------------------------------------------------

------------------------------------------------------
-- CAP_MEM_SEL_IN  | Mono-Phase DPD | Poly-Phase DPD |       
--                 |  DPD  |  PIM   |  DPD  |  PIM   |  
------------------------------------------------------
-- 0b000 (DPD_MEM) |  DPD  | UL ERR | DPD E | UL ERR |  
------------------------------------------------------
-- 0b001 (CFR_MEM) |  CFR  |  CFR   | CFR E |  CFR   |  
------------------------------------------------------
-- 0b010           |   -   |   -    |   -   |   -    |  
------------------------------------------------------
-- 0b011 (FB_MEM)  |  FB   | UL TGT | FB E  | UL TGT |  
------------------------------------------------------
-- 0b100 (SRC1_MEM)|   -   |   -    | DPD O |  DUC   |  
------------------------------------------------------
-- 0b101 (SRC0_MEM)|   -   |   -    | CFR O | PimRef |  
------------------------------------------------------
-- 0b110           |   -   |   -    |   -   |   -    |  
------------------------------------------------------
-- 0b111 (DBG_MEM) |   -   |   -    | FB O  | Debug  |  
------------------------------------------------------

-- PATH_SEL = FB_VC
-- 0000  : FWD antenna #0
-- 0001  : RVS antenna #0
-- 0010  : FWD antenna #1
-- 0011  : RVS antenna #1
-- 0100  : FWD antenna #2
-- 0101  : RVS antenna #2
-- 0110  : FWD antenna #3
-- 0111  : RVS antenna #3
-- 1000  : FWD antenna #4
-- 1001  : RVS antenna #4
-- 1010  : FWD antenna #5
-- 1011  : RVS antenna #5
-- 1100  : FWD antenna #6
-- 1101  : RVS antenna #6
-- 1110  : FWD antenna #7
-- 1111  : RVS antenna #7

entity SMART_CAPTURE is
generic(
    DEVICE                    : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    SC_EXPANSION              : boolean := TRUE     ; -- 
    DPD_PATH_PHASE            : string  := "MONO"   ; -- "MONO" or "POLY"
    STATIC_CAPTURE_COUNT      : natural := 6        ; -- Static Capture Section on Feedback Switch Forward Counter (10ms)
    CAPTURE_DONE_COUNT        : natural := 6        ; -- Capture Done Boundary on Feedback Switch Forward Counter  (10ms)
    HOVS                      : natural := 1
    );
port(
    -- Common
    RST_DSP                   : in  std_logic; 
    CLK_DSP                   : in  std_logic;                     -- DSP Operation Clock
    CLK_CPU                   : in  std_logic;                     -- CPU Operation Clock

    -- Sync Strobe
    FS_10MS_IN                : in  std_logic;                     -- Frame Sync 10ms
    TDD_STROBE_IN             : in  std_logic;                     -- TDD Strobe

    -- Capturing Sample Port
    REF_VALID_IN              : in  std_logic;                     -- Reference Sample Valid

    CFR_I_IN                  : in  std_logic_vector(15 downto 0); -- CFR output I data
    CFR_Q_IN                  : in  std_logic_vector(15 downto 0); -- CFR output Q data

    DPD_I_IN                  : in  std_logic_vector(15 downto 0); -- DPD output I data
    DPD_Q_IN                  : in  std_logic_vector(15 downto 0); -- DPD output Q data

    FB_I_IN                   : in  std_logic_vector(15 downto 0); -- Feedback I data 
    FB_Q_IN                   : in  std_logic_vector(15 downto 0); -- Feedback Q data 

    PIM_SRC0_I_IN             : in  std_logic_vector(15 downto 0); -- UL PIM Target I data
    PIM_SRC0_Q_IN             : in  std_logic_vector(15 downto 0); -- UL PIM Target Q data

    PIM_SRC1_I_IN             : in  std_logic_vector(15 downto 0); -- UL PIM Error  I data
    PIM_SRC1_Q_IN             : in  std_logic_vector(15 downto 0); -- UL PIM Error  Q data

    PIM_DBG_I_IN              : in  std_logic_vector(15 downto 0); -- UL PIM Debug  I data
    PIM_DBG_Q_IN              : in  std_logic_vector(15 downto 0); -- UL PIM Debug  Q data

    -- Feedback Switch Information
    FB_VC_IN                  : in  std_logic_vector( 4 downto 0); -- Feedback Switch Information 
    FB_SW_ROUND_START_IN      : in  std_logic;                     -- Feedback Switch Period end signal 

    -- For DPD SW iteration Time Test
    FORCED_CAPTURE_CONTROL_IN : in  std_logic;                     -- 0 : Normal, 1 : Forced Enable
    FB_MANUAL_MODE_IN         : in  std_logic;                     -- Feedback Switch Manual Mode, '1' Manual, '0' Auto

    -- Smart Capture Control & Status
    DEBOUNCING_TIME_IN        : in  std_logic_vector( 9 downto 0); -- Smart Capture Debouncing Time at Feedback Switch 1st Frame 10ms 
    DPDFB_PIM_MODE_SEL_IN     : in  std_logic;                     -- '0' : DPD mode , '1' : PIM Mode
    CAPTURE_CONTROL_IN        : in  std_logic;                     -- '0' : Capture Disable, '1' : Capture Enable
    CAPTURE_COMPLETE_OUT      : out std_logic;                     -- Capture Done Flag, '1' : done 

    CAP_SIZE_SEL_IN           : in  std_logic;                     -- '0' : 8k       , '1' : 4k
    TDD_MODE_IN               : in  std_logic;                     -- '0' : FDD mode , '1' : TDD mode    

    PATH_SEL_IN               : in  std_logic_vector( 3 downto 0);
    DPD_DELAY_IN              : in  std_logic_vector( 9 downto 0); -- DPD processing latency 
    FB_DELAY_IN               : in  std_logic_vector( 9 downto 0); -- DPD output to Feedback input latency 
    PIM_REF_DELAY_IN          : in  std_logic_vector( 9 downto 0); -- IM_GEN to PIMD_MIXER input latency 

    CAP_OFF_START_IN          : in  std_logic_vector(21 downto 0); -- smart capture exception period start point
    CAP_OFF_STOP_IN           : in  std_logic_vector(21 downto 0); -- smart capture exception period end point   
    STATIC_POSITION_IN        : in  std_logic_vector(21 downto 0); -- static capture start position
    SC_LENGTH_IN              : in  std_logic_vector( 8 downto 0); -- smart capture length
    MAX_PEAK_BO_GAIN_IN       : in  std_logic_vector(15 downto 0); -- max peak backoff gain value
    CUR_PEAK_BO_GAIN_IN       : in  std_logic_vector(15 downto 0); -- current peak backoff gain value

    CAP_FRAME_NUM_OUT         : out std_logic_vector(12 downto 0); -- captured subframe number  
    CAP_FRAME_PEAK_OUT        : out std_logic_vector(31 downto 0); -- captured subframe maximum peak value
    CAP_FRAME_PWR_OUT         : out std_logic_vector(31 downto 0); -- captured subframe power value
    CAP_TIME_INDEX_OUT        : out std_logic_vector(31 downto 0); -- captured time index

    -- CPU Access Interface : CPU Clock Domain
    CAP_MEM_SEL_IN            : in  std_logic_vector( 2 downto 0); -- 
    CAP_MEM_OE_IN             : in  std_logic;                     -- Capture Memory Operation Enable 
    CAP_MEM_ADDR_IN           : in  std_logic_VECTOR(12 downto 0); -- Capture Memory Read Address  
    CAP_MEM_DATA_OUT          : out std_logic_vector(31 downto 0)  -- Capture Memory Read Data
    );
end SMART_CAPTURE;

architecture arc_SMART_CAPTURE of SMART_CAPTURE is

constant BUF_DATAWIDTH          : integer := 32;
constant BUF_ADDRDEPTH          : integer := 14;

constant log2_BUF_SIZE          : integer := log2(BUF_DATAWIDTH)+BUF_ADDRDEPTH;  
constant URAM_READ_LATENCY      : integer := ternary_func(log2_BUF_SIZE <= 18, 2, log2_BUF_SIZE-17+2);   


component RST_SYNC is
generic(
    DLY_NUM                   : natural := 3;    -- Number of delay.
    MAX_FANOUT_NUM            : integer := 200   -- Number of maximum fanout
    );
port(
    RST_IN                    : in  std_logic;   -- Active high asynchronous reset
    CLK                       : in  std_logic;   -- clock to be sync'ed to
    RST_OUT                   : out std_logic    -- "Synchronised" reset signal
    );         
end component;

component SMART_CAPTURE_CORE is
generic(
    DEVICE                      : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    STATIC_CAPTURE_COUNT        : natural := 6        ; -- Static Capture Section on Feedback Switch Forward Counter (10ms)
    CAPTURE_DONE_COUNT          : natural := 6        ; -- Capture Done Boundary on Feedback Switch Forward Counter  (10ms)
    HOVS                        : natural := 1
    );
port(
    -- Common
    RST                         : in  std_logic; 
    CLK                         : in  std_logic;                     -- DSP Operation Clock

    -- Sync Strobe
    FS_STRB_IN                  : in  std_logic;                     -- Frame Sync 10ms
    TDD_STRB_IN                 : in  std_logic;                     -- TDD Strobe

    -- Capturing Sample Port
    REF_VLD_IN                  : in  std_logic;                     -- Reference Sample Valid

    REF_I_IN                    : in  std_logic_vector(15 downto 0); -- CFR output I data
    REF_Q_IN                    : in  std_logic_vector(15 downto 0); -- CFR output Q data

    -- Feedback Switch Information
    FB_VC_IN                    : in  std_logic_vector( 5 downto 0); -- Feedback Switch Information 

    -- Smart Capture Control & Status
    CAPTURE_CONTROL_EN_IN       : in  std_logic;                     -- '0' : Capture Disable, '1' : Capture Enable
    CAPTURE_COMPLETE_PLS_OUT    : out std_logic;                     -- Capture Done Pulse, '1' : done 

    DEBOUNCING_TIME_IN          : in  std_logic_vector( 9 downto 0); -- Smart Capture Debouncing Time at Feedback Switch 1st Frame 10ms 
    CAP_SIZE_SEL_IN             : in  std_logic;                     -- '0' : 8k       , '1' : 4k
    TDD_MODE_IN                 : in  std_logic;                     -- '0' : FDD mode , '1' : TDD mode    

    PATH_SEL_IN                 : in  std_logic_vector( 4 downto 0);

    CAP_OFF_START_IN            : in  std_logic_vector(21 downto 0); -- smart capture exception period start point
    CAP_OFF_STOP_IN             : in  std_logic_vector(21 downto 0); -- smart capture exception period end point   
    STATIC_POSITION_IN          : in  std_logic_vector(21 downto 0); -- static capture start position
    SC_LENGTH_IN                : in  std_logic_vector( 8 downto 0); -- smart capture length
    MAX_PEAK_BO_GAIN_IN         : in  std_logic_vector(15 downto 0); -- max peak backoff gain value
    CUR_PEAK_BO_GAIN_IN         : in  std_logic_vector(15 downto 0); -- current peak backoff gain value

    CAP_CONDITION_PLS_OUT       : out std_logic;                     -- REF Capture MSB Address Toggle Pulse

    CAP_REF_MSB_ADDR_OUT        : out std_logic;                     -- REF Capture MSB Address
    CAP_REF_WREN_OUT            : out std_logic_vector( 0 downto 0); -- REF Capture Write Enable
    CAP_REF_WRADDR_OUT          : out std_logic_vector(13 downto 0); -- REF Capture Write Address
    CAP_REF_WRDATA_OUT          : out std_logic_vector(31 downto 0); -- REF Capture Write Data : Q[31:16] & I[15:0]

    CAP_FRAME_NUM_OUT           : out std_logic_vector(12 downto 0); -- caputured subframe number  
    CAP_FRAME_PEAK_OUT          : out std_logic_vector(31 downto 0); -- caputured subframe maximum peak value
    CAP_FRAME_PWR_OUT           : out std_logic_vector(31 downto 0)  -- caputured subframe power value
    );
end component;

-- component BUF_SAMPLE_DELAY is
-- generic(
--     RAM_STYLE                 : string  := "DISTRIBUTED"; -- DISTRIBUTED or BLOCK
--     HS_MODE                   : boolean :=         TRUE ;
-- 
--     DATA_WIDTH                : natural;
--     ADDR_WIDTH                : natural
--     );
-- port(
--     RST                       : in  std_logic;
--     CLK                       : in  std_logic;
-- 
--     DELAY_VALUE_IN            : in  std_logic_vector(ADDR_WIDTH-1 downto 0); 
-- 
--     SAMPLE_VLD_IN             : in  std_logic;
--     SAMPLE_IN                 : in  std_logic_vector(DATA_WIDTH-1 downto 0); 
--     SAMPLE_DELAY_OUT          : out std_logic_vector(DATA_WIDTH-1 downto 0) 
--     );
-- end component;
component BUF_SAMPLE_DLY is
generic(
    RAM_STYLE            : string := "DISTRIBUTED"; -- "DISTRIBUTED" or "BLOCK"
    RESOLUTION           : string := "CLOCK";       -- "CLOCK" or "SAMPLE_RATE"

    DATA_WIDTH           : natural;
    ADDR_WIDTH           : natural
    );
port(
    RST                  : in  std_logic;
    CLK                  : in  std_logic;

    DELAY_VALUE_IN       : in  std_logic_vector(ADDR_WIDTH-1 downto 0); 

    SAMPLE_VLD_IN        : in  std_logic;
    SAMPLE_IN            : in  std_logic_vector(DATA_WIDTH-1 downto 0); 
    SAMPLE_DELAY_OUT     : out std_logic_vector(DATA_WIDTH-1 downto 0) 
    );
end component;

-- component SIMPLE_DPRAM_DUALCLK is
-- generic(
--     RAM_STYLE                 : string  := "BLOCK"; -- DISTRIBUTED or BLOCK
--     RAM_INIT_VALUE            : integer := 0; 
-- 
--     DATA_WIDTH                : natural := 8;
--     ADDR_WIDTH                : natural := 6
--     );
-- port(
--     CLKA                      : in  std_logic;
--     ENA                       : in  std_logic;
--     WEA                       : in  std_logic;
--     ADDRA                     : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
--     DATAA                     : in  std_logic_vector(DATA_WIDTH-1 downto 0);
-- 
--     CLKB                      : in  std_logic;
--     ENB                       : in  std_logic;
--     ADDRB                     : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
--     DATAB                     : out std_logic_vector(DATA_WIDTH-1 downto 0)
--     );
-- end component;

component SIMPLE_UDPRAM is
generic(
    READ_LATENCY                : integer :=  2 ;

    A_ADDR_WIDTH                : integer := 14 ;
    A_DATA_WIDTH                : integer :=  8 ; -- 8/16/32/64

    B_ADDR_WIDTH                : integer := 14 ;              
    B_DATA_WIDTH                : integer :=  8   -- 8/16/32/64
    );
-- Read Latency : 2Clocks
port(
    CLK                         : in  std_logic; -- Signal Clock Only

    EN_A                        : in  std_logic;
    WE_A                        : in  std_logic;
    ADDR_A                      : in  std_logic_vector(A_ADDR_WIDTH-1 downto 0);
    DATA_A                      : in  std_logic_vector(A_DATA_WIDTH-1 downto 0);

    EN_B                        : in  std_logic;
    ADDR_B                      : in  std_logic_vector(B_ADDR_WIDTH-1 downto 0);
    DATA_B                      : out std_logic_vector(B_DATA_WIDTH-1 downto 0)
    );
end component;


signal rst_sync_dsp               : std_logic;

signal fs_strb_sh                 : std_logic_vector( 1 downto 0);
signal tdd_strb_sh                : std_logic_vector( 1 downto 0);

signal tdd_mode_sh                : std_logic_vector( 1 downto 0);
signal fbsw_rnd_start_sh          : std_logic_vector( 2 downto 0);

signal dpdfb_pim_mode_sel_sh      : std_logic_vector( 2 downto 0); -- '0' : DPD mode , '1' : PIM Mode
signal capture_control_sh         : std_logic_vector( 2 downto 0); -- '0' : Capture Disable, '1' : Capture Enable
signal cap_ctrl_rpls              : std_logic;                     
signal cap_ctrl_fpls              : std_logic;                     
signal cap_ctrl_flag              : std_logic;                     -- '0' : Capture Disable, '1' : Capture Enable
signal forced_capture_control_sh  : std_logic_vector( 2 downto 0); -- '0' : Normal, '1' : Forced Enable
signal fb_manual_mode_sh          : std_logic_vector( 2 downto 0); -- Feedback Switch Manual Mode, '1' Manual, '0' Auto
signal sc_forced_on               : std_logic; 

signal fb_vc_d1                 : std_logic_vector( 5 downto 0) := (others => '0');

signal debouncing_time_d1         : std_logic_vector( 9 downto 0); -- Smart Capture Debouncing Time at Feedback Switch 1st Frame 10ms 
signal path_sel_d1                : std_logic_vector( 4 downto 0);
signal dpd_delay_d1               : std_logic_vector( 9 downto 0); -- DPD processing latency 
signal fb_delay_d1                : std_logic_vector( 9 downto 0); -- DPD output to Feedback input latency 
signal pim_ref_delay_d1           : std_logic_vector( 9 downto 0); -- 3rd IM output to PIM Mixer input latency 
signal cap_off_start_d1           : std_logic_vector(21 downto 0); -- smart capture exception period start point
signal cap_off_stop_d1            : std_logic_vector(21 downto 0); -- smart capture exception period end point   
signal static_position_d1         : std_logic_vector(21 downto 0); -- static capture start position
signal sc_length_d1               : std_logic_vector( 8 downto 0); -- smart capture length
signal max_peak_bo_gain_d1        : std_logic_vector(15 downto 0); -- max peak backoff gain value
signal cur_peak_bo_gain_d1        : std_logic_vector(15 downto 0); -- current peak backoff gain value

signal cap_size_sel_sh            : std_logic_vector( 1 downto 0);
signal cap_size_sel               : std_logic;

signal cap_ctrl_en                : std_logic;

signal cap_done_pls               : std_logic;
signal cap_done_flag              : std_logic;

signal dpd_delay                  : std_logic_vector( 9 downto 0); -- DPD processing latency 
signal fb_delay                   : std_logic_vector( 9 downto 0); -- DPD output to Feedback input latency 

signal pim_ref_delay              : std_logic_vector( 9 downto 0); -- DPD output to Feedback input latency 

signal ref_valid                  : std_logic;                     -- REF Valid
signal ref_val_d1                 : std_logic;                     -- REF Valid 1clocking
signal ref_data                   : std_logic_vector(31 downto 0); -- REF Data : Q[31:16] & I[15:0]

signal cap_ref_msb_addr           : std_logic;                     -- REF Capture MSB Address 
signal cap_ref_wren               : std_logic_vector( 0 downto 0); -- REF Capture Write Enable
signal cap_ref_wraddr             : std_logic_vector(13 downto 0); -- REF Capture Write Address
signal cap_ref_wrdata             : std_logic_vector(31 downto 0); -- REF Capture Write Data : Q[31:16] & I[15:0]

signal cap_cfr_wren               : std_logic_vector( 0 downto 0); -- REF Capture Write Enable
signal cap_cfr_wraddr             : std_logic_vector(13 downto 0); -- REF Capture Write Address
signal cap_cfr_wrdata             : std_logic_vector(31 downto 0); -- REF Capture Write Data : Q[31:16] & I[15:0]
    
signal cap_dpd_wren               : std_logic_vector( 0 downto 0); -- DPD Capture Write Enable
signal cap_dpd_wraddr             : std_logic_vector(13 downto 0); -- DPD Capture Write Address
signal cap_dpd_wrdata             : std_logic_vector(31 downto 0); -- DPD Capture Write Data : Q[31:16] & I[15:0]
    
signal cap_fb_wren                : std_logic_vector( 0 downto 0); -- FB  Capture Write Enable
signal cap_fb_wraddr              : std_logic_vector(13 downto 0); -- FB  Capture Write Address
signal cap_fb_wrdata              : std_logic_vector(31 downto 0); -- FB  Capture Write Data : Q[31:16] & I[15:0]

signal cap_src0_wrdata            : std_logic_vector(31 downto 0); -- SRC0 Capture Write Data : Q[31:16] & I[15:0]
signal cap_src0_wrdata_scdly      : std_logic_vector(31 downto 0); -- SRC0 Capture Write Data : Q[31:16] & I[15:0]

signal cap_src1_wrdata            : std_logic_vector(31 downto 0); -- SRC1 Capture Write Data : Q[31:16] & I[15:0]
signal cap_dbg_wrdata             : std_logic_vector(31 downto 0); -- Debug Point Capture Write Data : Q[31:16] & I[15:0]


signal cap_cfr_wren_d1            : std_logic_vector( 0 downto 0); -- REF Capture Write Enable
signal cap_cfr_wraddr_d1          : std_logic_vector(13 downto 0); -- REF Capture Write Address
signal cap_cfr_wrdata_d1          : std_logic_vector(31 downto 0); -- REF Capture Write Data : Q[31:16] & I[15:0]
    
signal cap_dpd_wren_d1            : std_logic_vector( 0 downto 0); -- DPD Capture Write Enable
signal cap_dpd_wraddr_d1          : std_logic_vector(13 downto 0); -- DPD Capture Write Address
signal cap_dpd_wrdata_d1          : std_logic_vector(31 downto 0); -- DPD Capture Write Data : Q[31:16] & I[15:0]
    
signal cap_fb_wren_d1             : std_logic_vector( 0 downto 0); -- FB  Capture Write Enable
signal cap_fb_wraddr_d1           : std_logic_vector(13 downto 0); -- FB  Capture Write Address
signal cap_fb_wrdata_d1           : std_logic_vector(31 downto 0); -- FB  Capture Write Data : Q[31:16] & I[15:0]

signal cap_src0_wren_d1           : std_logic_vector( 0 downto 0); -- SRC0 Capture Write Enable
signal cap_src0_wraddr_d1         : std_logic_vector(13 downto 0); -- SRC0 Capture Write Address
signal cap_src0_wrdata_d1         : std_logic_vector(31 downto 0); -- SRC0 Capture Write Data : Q[31:16] & I[15:0]

signal cap_cfr_wrdata_odd_d1      : std_logic_vector(31 downto 0); -- REF Capture Write Data : Q[31:16] & I[15:0]

signal cap_src1_wren_d1           : std_logic_vector( 0 downto 0); -- SRC1 Capture Write Enable
signal cap_src1_wraddr_d1         : std_logic_vector(13 downto 0); -- SRC1 Capture Write Address
signal cap_src1_wrdata_d1         : std_logic_vector(31 downto 0); -- SRC1 Capture Write Data : Q[31:16] & I[15:0]

signal cap_dbg_wren_d1            : std_logic_vector( 0 downto 0); -- Debug Capture Write Enable
signal cap_dbg_wraddr_d1          : std_logic_vector(13 downto 0); -- Debug Capture Write Address
signal cap_dbg_wrdata_d1          : std_logic_vector(31 downto 0); -- Debug Point Capture Write Data : Q[31:16] & I[15:0]

signal cap_fb_wrdata_odd_d1       : std_logic_vector(31 downto 0); -- Debug Point Capture Write Data : Q[31:16] & I[15:0]

-- signal cap_mem_ena                : std_logic;
    
signal cap_rdaddr                 : std_logic_vector(13 downto 0); -- Capture Memory Read Address

signal cap_ref_rden               : std_logic;                     -- REF Capture Read Enable
signal cap_ref_rden_sh            : std_logic_vector(2 downto 0);  -- REF Capture Read Enable
signal cap_ref_rddata             : std_logic_vector(31 downto 0); -- REF Capture Read Data : Q[31:16] & I[15:0]
    
signal cap_dpd_rden               : std_logic;                     -- DPD Capture Read Enable
signal cap_dpd_rden_sh            : std_logic_vector(2 downto 0);  -- DPD Capture Read Enable
signal cap_dpd_rddata             : std_logic_vector(31 downto 0); -- DPD Capture Read Data : Q[31:16] & I[15:0]
    
signal cap_fb_rden                : std_logic;                     -- FB  Capture Read Enable
signal cap_fb_rden_sh             : std_logic_vector(2 downto 0);  -- FB  Capture Read Enable
signal cap_fb_rddata              : std_logic_vector(31 downto 0); -- FB  Capture Read Data : Q[31:16] & I[15:0]

signal cap_src0_rden              : std_logic;                     -- SRC0 Capture Read Enable
signal cap_src0_rden_sh           : std_logic_vector(2 downto 0);  -- SRC0 Capture Read Enable
signal cap_src0_rddata            : std_logic_vector(31 downto 0); -- SRC0 Capture Read Data : Q[31:16] & I[15:0]

signal cap_src1_rden              : std_logic;                     -- SRC1 Capture Read Enable
signal cap_src1_rden_sh           : std_logic_vector(2 downto 0);  -- SRC1 Capture Read Enable
signal cap_src1_rddata            : std_logic_vector(31 downto 0); -- SRC1 Capture Read Data : Q[31:16] & I[15:0]

signal cap_dbg_rden               : std_logic;                     -- DBG Capture Read Enable
signal cap_dbg_rden_sh            : std_logic_vector(2 downto 0);  -- DBG Capture Read Enable
signal cap_dbg_rddata             : std_logic_vector(31 downto 0); -- DBG Capture Read Data : Q[31:16] & I[15:0]
    
signal cnt_10b                    : std_logic_vector( 9 downto 0); -- 1024 Free-Run Counter
signal cnt_1024_flg               : std_logic;                     -- 1023 counter flag
signal cnt_32b                    : std_logic_vector(31 downto 0);  

signal cap_condition_pls          : std_logic;
signal cnt_32b_lat                : std_logic_vector(31 downto 0); 

signal cap_time_index             : std_logic_vector(31 downto 0); 

attribute KEEP : string;
attribute KEEP of cap_ref_wren         : signal is "TRUE"; 
attribute KEEP of cap_ref_wraddr       : signal is "TRUE"; 

attribute KEEP of  CFR_I_IN         : signal is "TRUE";
attribute KEEP of  CFR_Q_IN         : signal is "TRUE";
attribute KEEP of  fs_strb_sh       : signal is "TRUE";
attribute KEEP of  tdd_strb_sh      : signal is "TRUE";
attribute KEEP of  ref_valid        : signal is "TRUE";
attribute KEEP of  path_sel_d1      : signal is "TRUE";

attribute MAX_FANOUT : integer;
attribute MAX_FANOUT of cap_ref_wren   : signal is 200; 
attribute MAX_FANOUT of cap_ref_wraddr : signal is 200; 



begin

    U_RST_SYNC_DSP : RST_SYNC generic map(4, 200) port map(RST_DSP, CLK_DSP, rst_sync_dsp);

    -- For In/Out CDC
    P_For_Timing : process(rst_sync_dsp, CLK_DSP) begin
        if (rst_sync_dsp = '1') then
            fb_vc_d1   <= (others => '0');
        elsif (CLK_DSP'event) and (CLK_DSP = '1') then
            fb_vc_d1   <= '0' & FB_VC_IN;
        end if;
    end process;

    G_Smart_Capture_Data_Align : if (SC_EXPANSION = FALSE) generate begin
        P_DPD_Data_Valid_Align : process(rst_sync_dsp, CLK_DSP) begin
            if (rst_sync_dsp = '1') then
                ref_valid      <= '0';            
                ref_val_d1     <= '0';
                ref_data       <= (others => '0');
                cap_dpd_wrdata <= (others => '0');
                cap_fb_wrdata  <= (others => '0');
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                ref_valid      <= REF_VALID_IN;            
                ref_val_d1     <= ref_valid;

                if (REF_VALID_IN = '1') then
                    ref_data       <= CFR_Q_IN & CFR_I_IN;
                    cap_dpd_wrdata <= DPD_Q_IN & DPD_I_IN;
                    cap_fb_wrdata  <= FB_Q_IN  & FB_I_IN ;
                else
                    ref_data       <= ref_data      ;
                    cap_dpd_wrdata <= cap_dpd_wrdata;
                    cap_fb_wrdata  <= cap_fb_wrdata ;
                end if;
            end if;
        end process;

        cap_src0_wrdata <= (others => '0');
        cap_src1_wrdata <= (others => '0');
        cap_dbg_wrdata  <= (others => '0');
    end generate;

    G_SC_Expansion_Data_Align : if (SC_EXPANSION = TRUE) generate begin
        P_PIM_Data_Valid_Align : process(rst_sync_dsp, CLK_DSP) begin
            if (rst_sync_dsp = '1') then
                ref_valid       <= '0';            
                ref_val_d1      <= '0';
                ref_data        <= (others => '0');
                cap_dpd_wrdata  <= (others => '0');
                cap_fb_wrdata   <= (others => '0');

                cap_src0_wrdata <= (others => '0');
                cap_src1_wrdata <= (others => '0');
                cap_dbg_wrdata  <= (others => '0');
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                ref_valid      <= REF_VALID_IN;            
                ref_val_d1     <= ref_valid;

                if (REF_VALID_IN = '1') then
                    ref_data        <= CFR_Q_IN & CFR_I_IN;
                    cap_dpd_wrdata  <= DPD_Q_IN & DPD_I_IN;
                    cap_fb_wrdata   <= FB_Q_IN  & FB_I_IN ;

                    cap_src0_wrdata <= PIM_SRC0_Q_IN & PIM_SRC0_I_IN;
                    cap_src1_wrdata <= PIM_SRC1_Q_IN & PIM_SRC1_I_IN;
                    cap_dbg_wrdata  <= PIM_DBG_Q_IN  & PIM_DBG_I_IN ;
                else
                    ref_data        <= ref_data      ;
                    cap_dpd_wrdata  <= cap_dpd_wrdata;
                    cap_fb_wrdata   <= cap_fb_wrdata ;

                    cap_src0_wrdata <= cap_src0_wrdata;
                    cap_src1_wrdata <= cap_src1_wrdata;
                    cap_dbg_wrdata  <= cap_dbg_wrdata;
                end if;
            end if;
        end process;
    end generate;

    P_10bit_Free_Run_Counter : process(rst_sync_dsp, CLK_DSP) begin
        if (rst_sync_dsp = '1') then
            cnt_10b       <= (others => '0');              
            cnt_1024_flg  <= '0';  
        elsif (CLK_DSP'event) and (CLK_DSP = '1') then
            cnt_10b       <= cnt_10b + '1';              

	    if (cnt_10b = "1111111110") then -- 1022       
                cnt_1024_flg  <= '1';        -- 1023  
            else
                cnt_1024_flg  <= '0';  
            end if;
        end if;
    end process;

    P_32bit_1024_resolution_Counter : process(rst_sync_dsp, CLK_DSP) begin
        if (rst_sync_dsp = '1') then
            cnt_32b <= (others => '0');
        elsif (CLK_DSP'event) and (CLK_DSP = '1') then
            if (cnt_1024_flg = '1') then   
                cnt_32b <= cnt_32b + '1'; -- 0 
            else
                cnt_32b <= cnt_32b; 
            end if;
        end if;
    end process;

    P_Double_Clocking : process(rst_sync_dsp, CLK_DSP) begin
        if (rst_sync_dsp = '1') then
            tdd_mode_sh               <= (others => '0');
            fbsw_rnd_start_sh         <= (others => '0');
            dpdfb_pim_mode_sel_sh     <= (others => '0'); 
            capture_control_sh        <= (others => '0');
            forced_capture_control_sh <= (others => '0'); 
            fb_manual_mode_sh         <= (others => '0');
            cap_size_sel_sh           <= (others => '0');
            fs_strb_sh                <= (others => '0');

            sc_forced_on              <= '0'; 
        elsif (CLK_DSP'event) and (CLK_DSP = '1') then
            tdd_mode_sh               <= tdd_mode_sh(0) & TDD_MODE_IN;
            fbsw_rnd_start_sh         <= fbsw_rnd_start_sh(1 downto 0) & FB_SW_ROUND_START_IN;
            dpdfb_pim_mode_sel_sh     <= dpdfb_pim_mode_sel_sh(1 downto 0) & DPDFB_PIM_MODE_SEL_IN; 
            capture_control_sh        <= capture_control_sh(1 downto 0) & CAPTURE_CONTROL_IN;
            forced_capture_control_sh <= forced_capture_control_sh(1 downto 0) & FORCED_CAPTURE_CONTROL_IN; 
            fb_manual_mode_sh         <= fb_manual_mode_sh(1 downto 0) & FB_MANUAL_MODE_IN;
            cap_size_sel_sh           <= cap_size_sel_sh(0) & CAP_SIZE_SEL_IN;
            fs_strb_sh                <= fs_strb_sh(0) &  FS_10MS_IN;
            tdd_strb_sh               <= tdd_strb_sh(0)&  TDD_STROBE_IN;
            sc_forced_on              <= forced_capture_control_sh(1) or fb_manual_mode_sh(1); 
        end if;
    end process;

    P_Multibit_Clocking : process(rst_sync_dsp, CLK_DSP) begin
        if (rst_sync_dsp = '1') then
            debouncing_time_d1  <= (others => '0');
            path_sel_d1         <= (others => '0'); 
            dpd_delay_d1        <= (others => '0'); 
            fb_delay_d1         <= (others => '0'); 
            pim_ref_delay_d1    <= (others => '0');        
            cap_off_start_d1    <= (others => '0'); 
            cap_off_stop_d1     <= (others => '0'); 
            static_position_d1  <= (others => '0'); 
            sc_length_d1        <= (others => '0'); 
            max_peak_bo_gain_d1 <= (others => '0'); 
            cur_peak_bo_gain_d1 <= (others => '0'); 
            cap_size_sel        <= '0'            ;
        elsif (CLK_DSP'event) and (CLK_DSP = '1') then
            if (cap_ctrl_rpls = '1') then
                debouncing_time_d1  <= DEBOUNCING_TIME_IN  ;
                path_sel_d1         <= '0'&PATH_SEL_IN     ; 
                dpd_delay_d1        <= DPD_DELAY_IN        ; 
                fb_delay_d1         <= FB_DELAY_IN         ; 
                pim_ref_delay_d1    <= PIM_REF_DELAY_IN    ;        
                cap_off_start_d1    <= CAP_OFF_START_IN    ; 
                cap_off_stop_d1     <= CAP_OFF_STOP_IN     ; 
                static_position_d1  <= STATIC_POSITION_IN  ; 
                sc_length_d1        <= SC_LENGTH_IN        ; 
                max_peak_bo_gain_d1 <= MAX_PEAK_BO_GAIN_IN ; 
                cur_peak_bo_gain_d1 <= CUR_PEAK_BO_GAIN_IN ; 
                cap_size_sel        <= cap_size_sel_sh(1)  ;
            else
                debouncing_time_d1  <= debouncing_time_d1  ;
                path_sel_d1         <= path_sel_d1         ; 
                dpd_delay_d1        <= dpd_delay_d1        ; 
                fb_delay_d1         <= fb_delay_d1         ; 
                pim_ref_delay_d1    <= pim_ref_delay_d1    ;        
                cap_off_start_d1    <= cap_off_start_d1    ; 
                cap_off_stop_d1     <= cap_off_stop_d1     ; 
                static_position_d1  <= static_position_d1  ; 
                sc_length_d1        <= sc_length_d1        ; 
                max_peak_bo_gain_d1 <= max_peak_bo_gain_d1 ; 
                cur_peak_bo_gain_d1 <= cur_peak_bo_gain_d1 ; 
                cap_size_sel        <= cap_size_sel        ;
            end if;
        end if;
    end process;

    -- Capture Section Indication
    P_Capture_Control_Flag : process(rst_sync_dsp, CLK_DSP) begin
        if (rst_sync_dsp = '1') then
            cap_ctrl_rpls <= '0';                     
            cap_ctrl_fpls <= '0';                     
            cap_ctrl_flag <= '0';
        elsif (CLK_DSP'event) and (CLK_DSP = '1') then 
            cap_ctrl_rpls <= capture_control_sh(1) and (not capture_control_sh(2));                     
            cap_ctrl_fpls <= capture_control_sh(2) and (not capture_control_sh(1));                     

            if (cap_done_pls = '1') then
                cap_ctrl_flag <= '0';
            else
                if (cap_ctrl_fpls = '1') then -- falling Edge Detect
                    cap_ctrl_flag <= '0';
                elsif (cap_ctrl_rpls = '1') then -- Rising Edge Detect
                    cap_ctrl_flag <= '1';
                else
                    cap_ctrl_flag <= cap_ctrl_flag;
                end if;
            end if;
        end if;
    end process;
    P_Capture_Enable : process(rst_sync_dsp, CLK_DSP) begin
        if (rst_sync_dsp = '1') then
            cap_ctrl_en <= '0';
        elsif (CLK_DSP'event) and (CLK_DSP = '1') then
            if (sc_forced_on = '1') then
                cap_ctrl_en <= cap_ctrl_flag;
            else
                if (cap_ctrl_flag = '0') then      
                    cap_ctrl_en <= '0';
                else
                    if (fbsw_rnd_start_sh(1) = '1') then
                        cap_ctrl_en <= '1';
                    else
                        cap_ctrl_en <= cap_ctrl_en;
                    end if;
                end if; 
            end if;
        end if;
    end process;

    U_SC_CORE : SMART_CAPTURE_CORE 
    generic map(
        DEVICE                    => DEVICE                , 
        STATIC_CAPTURE_COUNT      => STATIC_CAPTURE_COUNT  , 
        CAPTURE_DONE_COUNT        => CAPTURE_DONE_COUNT    ,
        HOVS                      => HOVS                 
        )
    port map(
        -- Common
        RST                       => rst_sync_dsp          , 
        CLK                       => CLK_DSP               , 
    
        FS_STRB_IN                => fs_strb_sh(1)         , 
        TDD_STRB_IN               => tdd_strb_sh(1)        , 

        REF_VLD_IN                => ref_valid             , 
                                                        
        REF_I_IN                  => ref_data(15 downto  0), 
        REF_Q_IN                  => ref_data(31 downto 16), 
    
        FB_VC_IN                  => fb_vc_d1              , 
    
        CAPTURE_CONTROL_EN_IN     => cap_ctrl_en           , 
        CAPTURE_COMPLETE_PLS_OUT  => cap_done_pls          , 
    
        DEBOUNCING_TIME_IN        => debouncing_time_d1    , 
        CAP_SIZE_SEL_IN           => cap_size_sel          ,
        TDD_MODE_IN               => tdd_mode_sh(1)        ,
    
        PATH_SEL_IN               => path_sel_d1           ,
    
        CAP_OFF_START_IN          => cap_off_start_d1      ,
        CAP_OFF_STOP_IN           => cap_off_stop_d1       ,
        STATIC_POSITION_IN        => static_position_d1    ,
        SC_LENGTH_IN              => sc_length_d1          ,
        MAX_PEAK_BO_GAIN_IN       => max_peak_bo_gain_d1   ,
        CUR_PEAK_BO_GAIN_IN       => cur_peak_bo_gain_d1   ,

        CAP_CONDITION_PLS_OUT     => cap_condition_pls     ,
    
        CAP_REF_MSB_ADDR_OUT      => cap_ref_msb_addr      ,
        CAP_REF_WREN_OUT          => cap_ref_wren          ,
        CAP_REF_WRADDR_OUT        => cap_ref_wraddr        ,
        CAP_REF_WRDATA_OUT        => cap_ref_wrdata        ,
    
        CAP_FRAME_NUM_OUT         => CAP_FRAME_NUM_OUT     ,
        CAP_FRAME_PEAK_OUT        => CAP_FRAME_PEAK_OUT    , 
        CAP_FRAME_PWR_OUT         => CAP_FRAME_PWR_OUT       
        );

    U_SC_CORE_Delay_Compensator : BUF_SAMPLE_DLY generic map("BLOCK", "SAMPLE_RATE", 32, 5) port map(rst_sync_dsp, CLK_DSP, "01010", ref_val_d1, cap_src0_wrdata, cap_src0_wrdata_scdly);  

    -- Capture Done Flag 
    P_Capture_Complete : process(rst_sync_dsp, CLK_DSP) begin
        if (rst_sync_dsp = '1') then
            cap_done_flag <= '0';
        elsif (CLK_DSP'event) and (CLK_DSP = '1') then
            if (cap_ctrl_rpls = '1') then -- Rising Edge
                cap_done_flag <= '0';
            else
                if (cap_done_pls = '1') then
                    cap_done_flag <= '1';
                else
                    cap_done_flag <= cap_done_flag;
                end if; 
            end if;
        end if;
    end process;

    CAPTURE_COMPLETE_OUT <= cap_done_flag;

    P_CNT_32b_Latch : process(rst_sync_dsp, CLK_DSP) begin
        if (rst_sync_dsp = '1') then
            cnt_32b_lat <= (others => '0');                
        elsif (CLK_DSP'event) and (CLK_DSP = '1') then
            if (cap_condition_pls = '1') then     
                cnt_32b_lat <= cnt_32b;                
            else
                cnt_32b_lat <= cnt_32b_lat;                
            end if;
        end if;
    end process;

    P_CAP_Time_Index : process(rst_sync_dsp, CLK_DSP) begin
        if (rst_sync_dsp = '1') then
            cap_time_index <= (others => '0');            
        elsif (CLK_DSP'event) and (CLK_DSP = '1') then
            if (cap_done_pls = '1') then          
                cap_time_index <= cnt_32b_lat;            
            else
                cap_time_index <= cap_time_index;            
            end if;
        end if;
    end process;

    CAP_TIME_INDEX_OUT <= cap_time_index; 
    
    G_DPD_MonoPhase : if (DPD_PATH_PHASE = "MONO") generate begin
        P_Mono_DPD_FB_Latency : process(rst_sync_dsp, CLK_DSP) begin
            if (rst_sync_dsp = '1') then
                dpd_delay     <= (others => '0');                  
                fb_delay      <= (others => '0');                  
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                dpd_delay     <= dpd_delay_d1 - 10;                  
                fb_delay      <= dpd_delay_d1 - 10 + fb_delay_d1;                  
            end if;
        end process;
    end generate;

    G_DPD_PolyPhase : if (DPD_PATH_PHASE = "POLY") generate begin
        P_Poly_DPD_FB_Latency : process(rst_sync_dsp, CLK_DSP) begin
            if (rst_sync_dsp = '1') then
                dpd_delay     <= (others => '0');                  
                fb_delay      <= (others => '0');                  
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                if (dpdfb_pim_mode_sel_sh(2) = '0') then
                    dpd_delay     <= ('0'&dpd_delay_d1(9 downto 1)) - 10;                  
                    fb_delay      <= ('0'&dpd_delay_d1(9 downto 1)) - 10 + ('0'&fb_delay_d1(9 downto 1)) + ("000000000"&fb_delay_d1(0));                  
                else
                    dpd_delay     <= dpd_delay_d1 - 10;                  
                    fb_delay      <= dpd_delay_d1 - 10 + fb_delay_d1;                  
                end if;
            end if;
        end process;
    end generate;

    G_SC_Capture_Data_Latency : if (SC_EXPANSION = FALSE) generate begin
        pim_ref_delay <= (others => '0');              
    end generate;

    G_SC_Expansion_Capture_Data_Latency : if (SC_EXPANSION = TRUE) generate begin
        P_PIM_Latency : process(rst_sync_dsp, CLK_DSP) begin
            if (rst_sync_dsp = '1') then
                pim_ref_delay <= (others => '0');              
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                pim_ref_delay <= pim_ref_delay_d1;              
            end if;
        end process;
    end generate;

    G_SC_Expansion_Data_Buffer : if (SC_EXPANSION = TRUE) generate begin
        U_PIM_REF_Latency_Compensation_WREN       : BUF_SAMPLE_DLY generic map("DISTRIBUTED", "SAMPLE_RATE",  1, 10) port map(rst_sync_dsp, CLK_DSP, pim_ref_delay, REF_VALID_IN, cap_ref_wren,   cap_cfr_wren      );                     
        U_PIM_REF_Latency_Compensation_WRADDR     : BUF_SAMPLE_DLY generic map(      "BLOCK", "SAMPLE_RATE", 14, 10) port map(rst_sync_dsp, CLK_DSP, pim_ref_delay, REF_VALID_IN, cap_ref_wraddr, cap_cfr_wraddr    );                     

    end generate;

    G_SC_Data_Buffer : if (SC_EXPANSION = FALSE) generate begin
        cap_cfr_wren   <= cap_ref_wren;
        cap_cfr_wraddr <= cap_ref_wraddr;
    end generate;

    cap_cfr_wrdata     <= cap_ref_wrdata;

    U_DPD_Latency_Compensation_WREN       : BUF_SAMPLE_DLY generic map("DISTRIBUTED", "SAMPLE_RATE",  1, 10) port map(rst_sync_dsp, CLK_DSP, dpd_delay, REF_VALID_IN, cap_cfr_wren,   cap_dpd_wren  );                     
    U_DPD_Latency_Compensation_WRADDR     : BUF_SAMPLE_DLY generic map(      "BLOCK", "SAMPLE_RATE", 14, 10) port map(rst_sync_dsp, CLK_DSP, dpd_delay, REF_VALID_IN, cap_cfr_wraddr, cap_dpd_wraddr);                     

    U_FB_Latency_Compensation_WREN        : BUF_SAMPLE_DLY generic map("DISTRIBUTED", "SAMPLE_RATE",  1, 10) port map(rst_sync_dsp, CLK_DSP, fb_delay,  REF_VALID_IN, cap_cfr_wren,   cap_fb_wren   );                     
    U_FB_Latency_Compensation_WRADDR      : BUF_SAMPLE_DLY generic map(      "BLOCK", "SAMPLE_RATE", 14, 10) port map(rst_sync_dsp, CLK_DSP, fb_delay,  REF_VALID_IN, cap_cfr_wraddr, cap_fb_wraddr );                     

    cap_ref_rden <= CAP_MEM_OE_IN when (CAP_MEM_SEL_IN = "001") else '0'; -- CFR out Read          
    cap_dpd_rden <= CAP_MEM_OE_IN when (CAP_MEM_SEL_IN = "000") else '0'; -- DPD out Read            
    cap_fb_rden  <= CAP_MEM_OE_IN when (CAP_MEM_SEL_IN = "011") else '0'; -- FB  out Read            

    G_SC_Expansion_PIM_Memory_Read : if (SC_EXPANSION = TRUE) generate begin
        cap_src0_rden <= CAP_MEM_OE_IN when (CAP_MEM_SEL_IN = "101") else '0';
        cap_src1_rden <= CAP_MEM_OE_IN when (CAP_MEM_SEL_IN = "100") else '0';
        cap_dbg_rden  <= CAP_MEM_OE_IN when (CAP_MEM_SEL_IN = "111") else '0';
    end generate;

    G_Unusing_SC_Expansion_Memory_Read : if (SC_EXPANSION = FALSE) generate begin
        cap_src0_rden <= '0';
        cap_src1_rden <= '0';
        cap_dbg_rden  <= '0';
    end generate;

    P_PIM_Latency : process(rst_sync_dsp, CLK_DSP) begin
        if (CLK_DSP'event) and (CLK_DSP = '1') then
            cap_ref_rden_sh    <= cap_ref_rden_sh(1 downto 0) & cap_ref_rden;
            cap_dpd_rden_sh    <= cap_dpd_rden_sh(1 downto 0) & cap_dpd_rden;
            cap_fb_rden_sh     <= cap_fb_rden_sh(1 downto 0)  & cap_fb_rden ;
            cap_src0_rden_sh   <= cap_src0_rden_sh(1 downto 0) & cap_src0_rden;
            cap_src1_rden_sh   <= cap_src1_rden_sh(1 downto 0) & cap_src1_rden;
            cap_dbg_rden_sh    <= cap_dbg_rden_sh(1 downto 0)  & cap_dbg_rden ;
        end if;
    end process;
    
    cap_rdaddr   <= ('0' & (not cap_ref_msb_addr) & CAP_MEM_ADDR_IN(11 downto 0)) when (cap_size_sel = '1') else -- 4k memory
                          ((not cap_ref_msb_addr) & CAP_MEM_ADDR_IN);                                            -- 8k memory


    G_SC_Memory_DPD_Mono : if (DPD_PATH_PHASE = "MONO") generate begin
        P_SC_Memory_DPD_Classic : process(rst_sync_dsp, CLK_DSP) begin
            if (rst_sync_dsp = '1') then
                cap_cfr_wren_d1   <= (others => '0');
                cap_cfr_wraddr_d1 <= (others => '0');
                cap_cfr_wrdata_d1 <= (others => '0');
                
                cap_dpd_wren_d1   <= (others => '0');
                cap_dpd_wraddr_d1 <= (others => '0');
                cap_dpd_wrdata_d1 <= (others => '0');
                
                cap_fb_wren_d1    <= (others => '0');
                cap_fb_wraddr_d1  <= (others => '0');
                cap_fb_wrdata_d1  <= (others => '0');
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                cap_cfr_wren_d1   <= cap_cfr_wren   ;
                cap_cfr_wraddr_d1 <= cap_cfr_wraddr ;
                cap_cfr_wrdata_d1 <= cap_cfr_wrdata ;
                                     
                cap_dpd_wren_d1   <= cap_dpd_wren   ;
                cap_dpd_wraddr_d1 <= cap_dpd_wraddr ;
                cap_dpd_wrdata_d1 <= cap_dpd_wrdata ;
                                     
                cap_fb_wren_d1    <= cap_fb_wren    ;
                cap_fb_wraddr_d1  <= cap_fb_wraddr  ;
                cap_fb_wrdata_d1  <= cap_fb_wrdata  ;
            end if;
        end process;
    end generate;

    G_SC_Memory_DPD_Poly : if (DPD_PATH_PHASE = "POLY") generate begin
        P_SC_Memory_DPD_Poly : process(rst_sync_dsp, CLK_DSP) begin
            if (rst_sync_dsp = '1') then
                cap_cfr_wren_d1   <= (others => '0');
                cap_cfr_wraddr_d1 <= (others => '0');
                cap_cfr_wrdata_d1 <= (others => '0');
                
                cap_dpd_wren_d1   <= (others => '0');
                cap_dpd_wraddr_d1 <= (others => '0');
                cap_dpd_wrdata_d1 <= (others => '0');
                
                cap_fb_wren_d1    <= (others => '0');
                cap_fb_wraddr_d1  <= (others => '0');
                cap_fb_wrdata_d1  <= (others => '0');
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                cap_cfr_wren_d1   <= cap_cfr_wren   ;
                cap_cfr_wraddr_d1 <= cap_cfr_wraddr ;
                                     
                cap_dpd_wren_d1   <= cap_dpd_wren   ;
                cap_dpd_wraddr_d1 <= cap_dpd_wraddr ;
                cap_dpd_wrdata_d1 <= cap_dpd_wrdata ;
                                     
                cap_fb_wren_d1    <= cap_fb_wren    ;
                cap_fb_wraddr_d1  <= cap_fb_wraddr  ;

                if (dpdfb_pim_mode_sel_sh(2) = '0') then
                    if (dpd_delay_d1(0) = '0') then  
                        cap_cfr_wrdata_d1 <= cap_cfr_wrdata;
                    else
                        cap_cfr_wrdata_d1 <= cap_cfr_wrdata_odd_d1;
                    end if;

                    if (fb_delay_d1(0) = '0') then
                        cap_fb_wrdata_d1  <= cap_fb_wrdata;
                    else
                        cap_fb_wrdata_d1  <= cap_fb_wrdata_odd_d1;
                    end if;
                else
                    cap_cfr_wrdata_d1 <= cap_cfr_wrdata;
                    cap_fb_wrdata_d1  <= cap_fb_wrdata;
                end if;
            end if;
        end process;
    end generate;

    U_REF_Capture_Memory : SIMPLE_UDPRAM 
    generic map(
        READ_LATENCY   => URAM_READ_LATENCY , 

        A_ADDR_WIDTH   => BUF_ADDRDEPTH     , 
        A_DATA_WIDTH   => BUF_DATAWIDTH     , 
                                            
        B_ADDR_WIDTH   => BUF_ADDRDEPTH     ,               
        B_DATA_WIDTH   => BUF_DATAWIDTH                
        )
    port map(
        CLK            => CLK_DSP           , 
        EN_A           => cap_cfr_wren_d1(0), 
        WE_A           => cap_cfr_wren_d1(0), 
        ADDR_A         => cap_cfr_wraddr_d1 ,
        DATA_A         => cap_cfr_wrdata_d1 ,
    
        EN_B           => cap_ref_rden_sh(2),
        ADDR_B         => cap_rdaddr        ,
        DATA_B         => cap_ref_rddata     
        );

    U_DPD_Capture_Memory : SIMPLE_UDPRAM 
    generic map(
        READ_LATENCY   => URAM_READ_LATENCY , 

        A_ADDR_WIDTH   => BUF_ADDRDEPTH     , 
        A_DATA_WIDTH   => BUF_DATAWIDTH     , 
                                            
        B_ADDR_WIDTH   => BUF_ADDRDEPTH     ,               
        B_DATA_WIDTH   => BUF_DATAWIDTH                
        )
    port map(
        CLK            => CLK_DSP           , 
        EN_A           => cap_dpd_wren_d1(0), 
        WE_A           => cap_dpd_wren_d1(0), 
        ADDR_A         => cap_dpd_wraddr_d1 ,
        DATA_A         => cap_dpd_wrdata_d1 ,
                       
        EN_B           => cap_dpd_rden_sh(2),
        ADDR_B         => cap_rdaddr        ,
        DATA_B         => cap_dpd_rddata     
        );

    U_FB_Capture_Memory : SIMPLE_UDPRAM 
    generic map(
        READ_LATENCY   => URAM_READ_LATENCY , 

        A_ADDR_WIDTH   => BUF_ADDRDEPTH     , 
        A_DATA_WIDTH   => BUF_DATAWIDTH     , 
                                            
        B_ADDR_WIDTH   => BUF_ADDRDEPTH     ,               
        B_DATA_WIDTH   => BUF_DATAWIDTH                
        )
    port map(
        CLK            => CLK_DSP           , 
        EN_A           => cap_fb_wren_d1(0) , 
        WE_A           => cap_fb_wren_d1(0) , 
        ADDR_A         => cap_fb_wraddr_d1  ,
        DATA_A         => cap_fb_wrdata_d1  ,
                       
        EN_B           => cap_fb_rden_sh(2) ,
        ADDR_B         => cap_rdaddr        ,
        DATA_B         => cap_fb_rddata     
        );

    G_SC_Expansion_Memoery : if (SC_EXPANSION = TRUE) generate begin

        G_SC_Memery_DPD_Mono : if (DPD_PATH_PHASE = "MONO") generate begin

            cap_cfr_wrdata_odd_d1 <= (others => '0');
            cap_fb_wrdata_odd_d1  <= (others => '0');

            P_SC_Memory_Expension : process(rst_sync_dsp, CLK_DSP) begin
                if (rst_sync_dsp = '1') then
                    cap_src0_wren_d1     <= (others => '0');
                    cap_src0_wraddr_d1   <= (others => '0');
                    cap_src0_wrdata_d1   <= (others => '0');
                    
                    cap_src1_wren_d1     <= (others => '0');
                    cap_src1_wraddr_d1   <= (others => '0');
                    cap_src1_wrdata_d1   <= (others => '0');
                    
                    cap_dbg_wren_d1      <= (others => '0');
                    cap_dbg_wraddr_d1    <= (others => '0');
                    cap_dbg_wrdata_d1    <= (others => '0');

                elsif (CLK_DSP'event) and (CLK_DSP = '1') then 
                    cap_src1_wrdata_d1   <= cap_src1_wrdata;
                    cap_dbg_wrdata_d1    <= cap_dbg_wrdata;

                    if (dpdfb_pim_mode_sel_sh(2) = '1') then      
                        cap_src0_wren_d1   <= cap_ref_wren  ;
                        cap_src0_wraddr_d1 <= cap_ref_wraddr;
                        cap_src0_wrdata_d1 <= cap_src0_wrdata;
                        
                        cap_src1_wren_d1   <= cap_ref_wren  ;
                        cap_src1_wraddr_d1 <= cap_ref_wraddr;
                        
                        cap_dbg_wren_d1    <= cap_ref_wren  ;
                        cap_dbg_wraddr_d1  <= cap_ref_wraddr;
                    else
                        cap_src0_wren_d1   <= cap_cfr_wren  ;
                        cap_src0_wraddr_d1 <= cap_cfr_wraddr;
                        cap_src0_wrdata_d1 <= cap_src0_wrdata_scdly;
                        
                        cap_src1_wren_d1   <= cap_dpd_wren  ;
                        cap_src1_wraddr_d1 <= cap_dpd_wraddr;
                        
                        cap_dbg_wren_d1    <= cap_fb_wren   ;
                        cap_dbg_wraddr_d1  <= cap_fb_wraddr ;
                    end if;
                end if;
            end process;
        end generate;

        G_SC_Memery_DPD_Poly : if (DPD_PATH_PHASE = "POLY") generate begin

            P_SC_Memory_Expension : process(rst_sync_dsp, CLK_DSP) begin
                if (rst_sync_dsp = '1') then
                    cap_src0_wren_d1      <= (others => '0');
                    cap_src0_wraddr_d1    <= (others => '0');
                    cap_src0_wrdata_d1    <= (others => '0');
                    
                    cap_src1_wren_d1      <= (others => '0');
                    cap_src1_wraddr_d1    <= (others => '0');
                    cap_src1_wrdata_d1    <= (others => '0');
                    
                    cap_dbg_wren_d1       <= (others => '0');
                    cap_dbg_wraddr_d1     <= (others => '0');
                    cap_dbg_wrdata_d1     <= (others => '0');

                    cap_cfr_wrdata_odd_d1 <= (others => '0');
                    cap_fb_wrdata_odd_d1  <= (others => '0');

                elsif (CLK_DSP'event) and (CLK_DSP = '1') then 
                    cap_cfr_wrdata_odd_d1 <= cap_src0_wrdata_scdly;
                    cap_src1_wrdata_d1    <= cap_src1_wrdata;
                    cap_fb_wrdata_odd_d1  <= cap_dbg_wrdata;

                    if (dpdfb_pim_mode_sel_sh(2) = '0') then
                        if (dpd_delay_d1(0) = '0') then
                            cap_src0_wrdata_d1 <= cap_src0_wrdata_scdly;
                        else
                            cap_src0_wrdata_d1 <= cap_cfr_wrdata;
                        end if;

                        if (fb_delay_d1(0) = '0') then
                            cap_dbg_wrdata_d1  <= cap_dbg_wrdata;
                        else
                            cap_dbg_wrdata_d1  <= cap_fb_wrdata;
                        end if;
                    else
                        cap_src0_wrdata_d1 <= cap_src0_wrdata;
                        cap_dbg_wrdata_d1  <= cap_dbg_wrdata;
                    end if;

                    if (dpdfb_pim_mode_sel_sh(2) = '1') then      
                        cap_src0_wren_d1   <= cap_ref_wren  ;
                        cap_src0_wraddr_d1 <= cap_ref_wraddr;
                        
                        cap_src1_wren_d1   <= cap_ref_wren  ;
                        cap_src1_wraddr_d1 <= cap_ref_wraddr;
                        
                        cap_dbg_wren_d1    <= cap_ref_wren  ;
                        cap_dbg_wraddr_d1  <= cap_ref_wraddr;
                    else
                        cap_src0_wren_d1   <= cap_cfr_wren  ;
                        cap_src0_wraddr_d1 <= cap_cfr_wraddr;
                        
                        cap_src1_wren_d1   <= cap_dpd_wren  ;
                        cap_src1_wraddr_d1 <= cap_dpd_wraddr;
                        
                        cap_dbg_wren_d1    <= cap_fb_wren   ;
                        cap_dbg_wraddr_d1  <= cap_fb_wraddr ;
                    end if;
                end if;
            end process;
        end generate;

        U_PIM_Target_Capture_Memory : SIMPLE_UDPRAM 
        generic map(
            READ_LATENCY   => URAM_READ_LATENCY , 

            A_ADDR_WIDTH   => BUF_ADDRDEPTH     , 
            A_DATA_WIDTH   => BUF_DATAWIDTH     , 
                                                
            B_ADDR_WIDTH   => BUF_ADDRDEPTH     ,               
            B_DATA_WIDTH   => BUF_DATAWIDTH                
            )
        port map(
            CLK            => CLK_DSP            , 
            EN_A           => cap_src0_wren_d1(0), 
            WE_A           => cap_src0_wren_d1(0), 
            ADDR_A         => cap_src0_wraddr_d1 ,
            DATA_A         => cap_src0_wrdata_d1 ,
                           
            EN_B           => cap_src0_rden_sh(2),
            ADDR_B         => cap_rdaddr         ,
            DATA_B         => cap_src0_rddata                 
            );

        U_PIM_Error_Capture_Memory : SIMPLE_UDPRAM 
        generic map(
            READ_LATENCY   => URAM_READ_LATENCY , 

            A_ADDR_WIDTH   => BUF_ADDRDEPTH     , 
            A_DATA_WIDTH   => BUF_DATAWIDTH     , 
                                                
            B_ADDR_WIDTH   => BUF_ADDRDEPTH     ,               
            B_DATA_WIDTH   => BUF_DATAWIDTH                
            )
        port map(
            CLK            => CLK_DSP            , 
            EN_A           => cap_src1_wren_d1(0), 
            WE_A           => cap_src1_wren_d1(0), 
            ADDR_A         => cap_src1_wraddr_d1 ,
            DATA_A         => cap_src1_wrdata_d1 ,
                           
            EN_B           => cap_src1_rden_sh(2), 
            ADDR_B         => cap_rdaddr         ,
            DATA_B         => cap_src1_rddata 
            );

        U_PIM_Debug_Capture_Memory : SIMPLE_UDPRAM 
        generic map(
            READ_LATENCY   => URAM_READ_LATENCY , 

            A_ADDR_WIDTH   => BUF_ADDRDEPTH     , 
            A_DATA_WIDTH   => BUF_DATAWIDTH     , 
                                                
            B_ADDR_WIDTH   => BUF_ADDRDEPTH     ,               
            B_DATA_WIDTH   => BUF_DATAWIDTH                
            )
        port map(
            CLK            => CLK_DSP            , 
            EN_A           => cap_dbg_wren_d1(0) , 
            WE_A           => cap_dbg_wren_d1(0) , 
            ADDR_A         => cap_dbg_wraddr_d1  ,
            DATA_A         => cap_dbg_wrdata_d1  ,
                           
            EN_B           => cap_dbg_rden_sh(2) ,
            ADDR_B         => cap_rdaddr         ,
            DATA_B         => cap_dbg_rddata                 
            );

    end generate;

    G_Unusing_SC_Expansion_Memoery : if (SC_EXPANSION = FALSE) generate begin
        cap_src0_rden   <= '0';             
        cap_src0_rddata <= (others => '0'); 
                        
        cap_src1_rden   <= '0';            
        cap_src1_rddata <= (others => '0');
                       
        cap_dbg_rden    <= '0';            
        cap_dbg_rddata  <= (others => '0');

        cap_src0_wren_d1   <= (others => '0');
        cap_src0_wraddr_d1 <= (others => '0');
        cap_src0_wrdata_d1 <= (others => '0');
        
        cap_src1_wren_d1   <= (others => '0');
        cap_src1_wraddr_d1 <= (others => '0');
        cap_src1_wrdata_d1 <= (others => '0');
        
        cap_dbg_wren_d1    <= (others => '0');
        cap_dbg_wraddr_d1  <= (others => '0');
        cap_dbg_wrdata_d1  <= (others => '0');

    end generate;

    CAP_MEM_DATA_OUT <= cap_ref_rddata  when (CAP_MEM_SEL_IN = "001") else
                        cap_dpd_rddata  when (CAP_MEM_SEL_IN = "000") else
                        cap_fb_rddata   when (CAP_MEM_SEL_IN = "011") else

                        cap_src0_rddata when (CAP_MEM_SEL_IN = "101") else
                        cap_src1_rddata when (CAP_MEM_SEL_IN = "100") else
                        cap_dbg_rddata  when (CAP_MEM_SEL_IN = "111") else
                        (others => '0');

end arc_SMART_CAPTURE;
