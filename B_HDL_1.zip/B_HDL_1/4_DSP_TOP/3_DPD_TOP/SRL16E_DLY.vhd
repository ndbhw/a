-- k1340.heo

Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

entity SRL16E_DLY is
generic(
    DEVICE    : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HS_MODE   : boolean :=        TRUE ;

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK      : in  std_logic;
    DATA_IN  : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT : out std_logic_vector(BIT_WIDTH-1 downto 0) 
    );
end SRL16E_DLY;

architecture arc_SRL16E_DLY of SRL16E_DLY is

component SRL16E_DLY_7S is
generic(
    HS_MODE   : boolean := FALSE; 

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0) 
    );
end component;

component SRL16E_DLY_US is
generic(
    HS_MODE   : boolean := TRUE;

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK      : in  std_logic;
    DATA_IN  : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT : out std_logic_vector(BIT_WIDTH-1 downto 0) 
    );
end component;

begin	

    G_7Series_SRL16E : if (DEVICE = "7SERIES") generate begin
        U_SRL16E_DLY_7S : SRL16E_DLY_7S generic map(HS_MODE, BIT_WIDTH, DELAY_NUM) port map(CLK, DATA_IN, DATA_OUT); 
    end generate;

    G_UltraScale_SRL16E : if (DEVICE = "ULTRASCALE") generate begin
        U_SRL16E_DLY_US : SRL16E_DLY_US generic map(HS_MODE, BIT_WIDTH, DELAY_NUM) port map(CLK, DATA_IN, DATA_OUT); 
    end generate;

end arc_SRL16E_DLY;
