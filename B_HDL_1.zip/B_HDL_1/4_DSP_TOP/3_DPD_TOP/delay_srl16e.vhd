

--   SRL16E    : In order to incorporate this function into the design,
--    VHDL     : the following instance declaration needs to be placed
--  instance   : in the architecture body of the design code.  The
-- declaration : instance name (SRL16E_inst) and/or the port declarations
--    code     : after the "=>" assignment maybe changed to properly
--             : reference and connect this function to the design.
--             : All inputs and outputs must be connected.

--   Library   : In addition to adding the instance declaration, a use
-- declaration : statement for the UNISIM.vcomponents library needs to be
--     for     : added before the entity declaration.  This library
--   Xilinx    : contains the component declarations for all Xilinx
--  primitives : primitives and points to the models that will be used
--             : for simulation.

--  Copy the following two statements and paste them before the
--  Entity declaration, unless they already exist.

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

Library UNISIM;
use UNISIM.vcomponents.all;

entity DELAY_SRL16E is
    port(
    RST                             : in std_logic;
    CLK                             : in std_logic;

    DATA_IN                         : in  std_logic_vector(15 downto 0);
    DELAY_NUM                       : in  std_logic_vector( 3 downto 0);
    DATA_OUT                        : out std_logic_vector(15 downto 0)
);
end DELAY_SRL16E;

architecture arc_DELAY_SRL16E of DELAY_SRL16E is
    
begin

--  <-----Cut code below this line and paste into the architecture body---->

   -- SRL16E: 16-bit shift register LUT with clock enable operating on posedge of clock (Mapped to SliceM LUT6)
   --        Ultrascale
   -- Xilinx HDL Language Template, version 2014.4

    srl16e_inst_gen : for m in 15 downto 0 generate
    SRL16E_inst : SRL16E
    generic map (
        INIT                        => X"0000")
    port map (
        Q                           => DATA_OUT(m),      -- SRL data output
        CE                          => '1',              -- Clock enable input
        CLK                         => CLK,              -- Clock input
        D                           => DATA_IN(m),       -- SRL data input

        A0                          => DELAY_NUM(0),     -- Select[0] input
        A1                          => DELAY_NUM(1),     -- Select[1] input
        A2                          => DELAY_NUM(2),     -- Select[2] input
        A3                          => DELAY_NUM(3)      -- Select[3] input
    );
    end generate;

   -- End of SRL16E_inst instantiation

end arc_DELAY_SRL16E;

					
					
