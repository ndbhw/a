Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

Library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity COMPLEX_MULTIPLIER_HOVS1 is
generic(
    DEVICE         : string := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HS_MODE        : boolean;

    INPUT_WIDTH    : natural; -- AIN bitwidth : 0 to 29
    RND_EN         : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT        : natural; -- Rounding bit  
    OUTPUT_WIDTH   : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;

    DATA_VLD_IN    : in  std_logic;
    ADATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    ADATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
                                            
    BDATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    BDATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
   
    DATA_VLD_OUT   : out std_logic;
    DATA_I_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0);
    DATA_Q_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
end COMPLEX_MULTIPLIER_HOVS1;

architecture arc_COMPLEX_MULTIPLIER_HOVS1 of COMPLEX_MULTIPLIER_HOVS1 is

component DSP48E1_MULTIPLIER is
-- Latency 4 clocks
generic(
    AIN_BITWIDTH : natural; -- AIN bitwidth : 0 to 29
    BIN_BITWIDTH : natural; -- BIN bitwidth : 0 to 17
    RND_EN       : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT      : natural; -- Rounding bit  
    OUTPUT_WIDTH : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
    AIN          : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
    BIN          : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
    P            : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
    );
end component;

component DSP48E2_MULTIPLIER is
-- Latency 4 clocks
generic(
    AIN_BITWIDTH : natural; -- AIN bitwidth : 0 to 29
    BIN_BITWIDTH : natural; -- BIN bitwidth : 0 to 17
    RND_EN       : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT      : natural; -- Rounding bit  
    OUTPUT_WIDTH : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
    AIN          : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
    BIN          : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
    P            : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
    );
end component;

constant zeros     : std_logic_vector(47 downto 0) := (others => '0');
constant ones      : std_logic_vector(47 downto 0) := (others => '1');

signal rnd         : std_logic_vector(47 downto 0);

signal ai_plus_aq  : std_logic_vector(INPUT_WIDTH downto 0)  ;  -- i_A + q_A
signal bi_plus_bq  : std_logic_vector(INPUT_WIDTH downto 0)  ;  -- i_B + q_B
signal bi_minus_bq : std_logic_vector(INPUT_WIDTH downto 0)  ;  -- i_B - q_B

signal ai_d1       : std_logic_vector(INPUT_WIDTH-1 downto 0);  -- For compensation Adder
signal aq_d1       : std_logic_vector(INPUT_WIDTH-1 downto 0);  -- For compensation Adder
signal bi_d1       : std_logic_vector(INPUT_WIDTH-1 downto 0);  -- For compensation Adder
signal bq_d1       : std_logic_vector(INPUT_WIDTH-1 downto 0);  -- For compensation Adder

signal p           : std_logic_vector(47 downto 0);             -- i_B(i_A + q_A)
signal p_minus_i   : std_logic_vector(47 downto 0);             -- p - i = q_A * (i_B + q_B)
signal p_minus_q   : std_logic_vector(47 downto 0);             -- p - q = i_A * (i_B - q_B)

signal result_i    : std_logic_vector(47 downto 0);             -- p - i = q_A * (i_B + q_B)
signal result_q    : std_logic_vector(47 downto 0);             -- p - q = i_A * (i_B - q_B)

signal rnd_i       : std_logic_vector(47 downto 0);             -- (i_A * i_B) - (q_A * q_B) + 0.5
signal rnd_q       : std_logic_vector(47 downto 0);             -- (i_A * q_B) + (i_B * q_A) + 0.5

begin

    G_Rounding : if (RND_EN = TRUE) generate begin
        G_Rounding_0bit : if (RND_BIT = 0) generate begin
            rnd <= zeros;
        end generate;

        G_Rounding_1bit : if (RND_BIT = 1) generate begin
            rnd <= zeros(47 downto RND_BIT) & '1';
        end generate;

        G_Rounding_Nbit : if (RND_BIT > 1) generate begin
            rnd <= zeros(47 downto RND_BIT) & '1' & zeros(RND_BIT-2 downto 0);
        end generate;
    end generate;

    G_NonRounding : if (RND_EN = FALSE) generate begin
        rnd <= zeros;
    end generate;


    G_Complex_Multiply_Normal_Operation : if (HS_MODE = FALSE) generate begin
        P_Adder_N_Substractor_NM : process(RST, CLK) begin 
            if (RST = '1') then
                ai_plus_aq  <= (others => '0');  -- i_A + q_A
                bi_plus_bq  <= (others => '0');  -- i_B + q_B
                bi_minus_bq <= (others => '0');  -- i_B - q_B
            elsif (CLK'event) and (CLK = '1') then
                ai_plus_aq  <= (ADATA_I_IN(INPUT_WIDTH-1) & ADATA_I_IN) + (ADATA_Q_IN(INPUT_WIDTH-1) & ADATA_Q_IN); 
                bi_plus_bq  <= (BDATA_I_IN(INPUT_WIDTH-1) & BDATA_I_IN) + (BDATA_Q_IN(INPUT_WIDTH-1) & BDATA_Q_IN);  -- i_B + q_B
                bi_minus_bq <= (BDATA_I_IN(INPUT_WIDTH-1) & BDATA_I_IN) - (BDATA_Q_IN(INPUT_WIDTH-1) & BDATA_Q_IN);  -- i_B - q_B
            end if;
        end process;

        P_Compensate_Adder_N_Substractor_Latency_NM : process(RST, CLK) begin
            if (RST = '1') then
                ai_d1 <= (others => '0'); 
                aq_d1 <= (others => '0'); 
                                          
                bi_d1 <= (others => '0'); 
                bq_d1 <= (others => '0'); 
            elsif (CLK'event) and (CLK = '1') then
                ai_d1 <= ADATA_I_IN; -- For compensation Adder_Latency
                aq_d1 <= ADATA_Q_IN; -- For compensation Adder_Latency
                                                             
                bi_d1 <= BDATA_I_IN; -- For compensation Adder_Latency
                bq_d1 <= BDATA_Q_IN; -- For compensation Adder_Latency
            end if;
        end process;
    end generate;

    G_Complex_Multiply_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
        P_Adder_N_Substractor_NM : process(CLK) begin 
            if (CLK'event) and (CLK = '1') then
                ai_plus_aq  <= (ADATA_I_IN(INPUT_WIDTH-1) & ADATA_I_IN) + (ADATA_Q_IN(INPUT_WIDTH-1) & ADATA_Q_IN); 
                bi_plus_bq  <= (BDATA_I_IN(INPUT_WIDTH-1) & BDATA_I_IN) + (BDATA_Q_IN(INPUT_WIDTH-1) & BDATA_Q_IN);  -- i_B + q_B
                bi_minus_bq <= (BDATA_I_IN(INPUT_WIDTH-1) & BDATA_I_IN) - (BDATA_Q_IN(INPUT_WIDTH-1) & BDATA_Q_IN);  -- i_B - q_B
            end if;
        end process;

        P_Compensate_Adder_N_Substractor_Latency_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                ai_d1 <= ADATA_I_IN; -- For compensation Adder_Latency
                aq_d1 <= ADATA_Q_IN; -- For compensation Adder_Latency
                                                             
                bi_d1 <= BDATA_I_IN; -- For compensation Adder_Latency
                bq_d1 <= BDATA_Q_IN; -- For compensation Adder_Latency
            end if;
        end process;
    end generate;

    G_7Series_DSP48E1 : if (DEVICE = "7SERIES") generate begin
        U_DSP48E1_Calculate_P_factor  : DSP48E1_MULTIPLIER generic map(INPUT_WIDTH+1, INPUT_WIDTH, FALSE, 0, 48) port map(RST, CLK, ai_plus_aq,  bi_d1, p        ); -- i_B * (i_A + q_A) 
        U_DSP48E1_Calculate_P_minus_I : DSP48E1_MULTIPLIER generic map(INPUT_WIDTH+1, INPUT_WIDTH, FALSE, 0, 48) port map(RST, CLK, bi_plus_bq,  aq_d1, p_minus_i); -- q_A * (i_B + q_B) 
        U_DSP48E1_Calculate_P_minus_Q : DSP48E1_MULTIPLIER generic map(INPUT_WIDTH+1, INPUT_WIDTH, FALSE, 0, 48) port map(RST, CLK, bi_minus_bq, ai_d1, p_minus_q); -- i_A * (i_B - q_B) 
    end generate;
 
    G_UltraScale_DSP48E2 : if (DEVICE = "ULTRASCALE") generate begin
        U_DSP48E2_Calculate_P_factor  : DSP48E2_MULTIPLIER generic map(INPUT_WIDTH+1, INPUT_WIDTH, FALSE, 0, 48) port map(RST, CLK, ai_plus_aq,  bi_d1, p        ); -- i_B * (i_A + q_A) 
        U_DSP48E2_Calculate_P_minus_I : DSP48E2_MULTIPLIER generic map(INPUT_WIDTH+1, INPUT_WIDTH, FALSE, 0, 48) port map(RST, CLK, bi_plus_bq,  aq_d1, p_minus_i); -- q_A * (i_B + q_B) 
        U_DSP48E2_Calculate_P_minus_Q : DSP48E2_MULTIPLIER generic map(INPUT_WIDTH+1, INPUT_WIDTH, FALSE, 0, 48) port map(RST, CLK, bi_minus_bq, ai_d1, p_minus_q); -- i_A * (i_B - q_B) 
    end generate;
 
    G_Truncation_Nomarl_Operation : if (HS_MODE = FALSE) generate begin
        P_Truncation_NM : process(RST, CLK) begin
            if (RST = '1') then
                result_i <= (others => '0');   
                result_q <= (others => '0');   

                rnd_i    <= (others => '0');
                rnd_q    <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                result_i <= p - p_minus_i;  -- (P+0.5) - (q_A * (i_B + q_B)) = (i_A * i_B) - (q_A * q_B) 
                result_q <= p - p_minus_q;  -- (P+0.5) - (i_A * (i_B - q_B)) = (i_A * q_B) + (i_B * q_A) 

                rnd_i    <= result_i + rnd; 
                rnd_q    <= result_q + rnd; 
            end if;
        end process;

        P_Output_Assign_NM : process(RST, CLK) begin
            if (RST = '1') then
                DATA_VLD_OUT <= '0';
                DATA_I_OUT   <= (others => '0'); 
                DATA_Q_OUT   <= (others => '0'); 
            elsif (CLK'event) and (CLK = '1') then
                DATA_VLD_OUT <= DATA_VLD_IN;
                DATA_I_OUT   <= rnd_i((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT); 
                DATA_Q_OUT   <= rnd_q((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT); 
            end if;
        end process;

    end generate;

    G_Truncation_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
        P_Truncation_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                result_i <= p - p_minus_i;  -- (P+0.5) - (q_A * (i_B + q_B)) = (i_A * i_B) - (q_A * q_B) 
                result_q <= p - p_minus_q;  -- (P+0.5) - (i_A * (i_B - q_B)) = (i_A * q_B) + (i_B * q_A) 

                rnd_i    <= result_i + rnd; 
                rnd_q    <= result_q + rnd; 
            end if;
        end process;

        P_Output_Assign_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                DATA_VLD_OUT <= DATA_VLD_IN;
                DATA_I_OUT   <= rnd_i((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT); 
                DATA_Q_OUT   <= rnd_q((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT); 
            end if;
        end process;

    end generate;

end arc_COMPLEX_MULTIPLIER_HOVS1;
