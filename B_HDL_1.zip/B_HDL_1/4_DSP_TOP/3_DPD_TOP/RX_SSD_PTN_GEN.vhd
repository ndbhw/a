library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity RX_SSD_PTN_GEN is
generic(
    HS_MODE                : boolean := FALSE ;
    HOVS                   : natural :=     2 
    );
port(
    RST_DSP                : in  std_logic;
    CLK_DSP                : in  std_logic;
    CLK_CPU                : in  std_logic;

    PTN_WREN_IN            : in  std_logic;
    PTN_WADDR_IN           : in  std_logic_vector( 8 downto 0);
    PTN_WDATA_IN           : in  std_logic_vector(31 downto 0);

    PTN_GEN_EN_IN          : in  std_logic;
    REPEAT_PER_SW_IN       : in  std_logic_vector(16 downto 0);

    FS_10ms_RPLS_IN        : in  std_logic;

    PTN_VLD_OUT            : out std_logic;
    PTN_I_OUT              : out std_logic_vector(15 downto 0);
    PTN_Q_OUT              : out std_logic_vector(15 downto 0)
    );
end RX_SSD_PTN_GEN;

architecture arc_RX_SSD_PTN_GEN of RX_SSD_PTN_GEN is

component SIMPLE_DPRAM_DUALCLK is
generic(
    RAM_STYLE              : string  := "BLOCK"; -- DISTRIBUTED or BLOCK
    RAM_INIT_VALUE         : integer := 0; 

    DATA_WIDTH             : natural := 8;
    ADDR_WIDTH             : natural := 6
    );
port(
    CLKA                   : in  std_logic;
    ENA                    : in  std_logic;
    WEA                    : in  std_logic;
    ADDRA                  : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATAA                  : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    CLKB                   : in  std_logic;
    ENB                    : in  std_logic;
    ADDRB                  : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATAB                  : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end component;

signal clk_div_cnt         : std_logic_vector(log2(HOVS) downto 0);
signal ptn_vld             : std_logic;
    
signal ptn_gen_en_d1       : std_logic;
signal ptn_gen_en_rpls     : std_logic;

signal state_cnt           : std_logic_vector( 1 downto 0);

signal cnt_repeat          : std_logic_vector(16 downto 0);
signal cnt_512             : std_logic_vector( 8 downto 0);
signal ptn_gen_section     : std_logic;
signal ptn_gen_section_sh  : std_logic_vector( 2 downto 0);
signal ptn_gen_section_en  : std_logic;

signal ren                 : std_logic;
signal raddr               : std_logic_vector( 8 downto 0);
signal rdata               : std_logic_vector(31 downto 0);

signal ptn_gen_vld         : std_logic;
signal ptn_gen_i           : std_logic_vector(15 downto 0);
signal ptn_gen_q           : std_logic_vector(15 downto 0);

begin

    G_PTN_GEN_CTRL_NM : if (HS_MODE = FALSE) generate begin
        -- Pattern Valid Generate
        P_Clock_Divide_Count_NM : process(RST_DSP, CLK_DSP) begin
            if (RST_DSP = '1') then
                clk_div_cnt <= (others => '0');
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                if (clk_div_cnt = HOVS-1) then 
                    clk_div_cnt <= (others => '0');
                else
                    clk_div_cnt <= clk_div_cnt + '1';
                end if;
            end if;
        end process;

        ptn_vld <= '1' when (clk_div_cnt = HOVS-1) else '0';

        -- Avoid 1st Dummy Frame 
        P_Pattern_GEN_Rpls_NM : process(RST_DSP, CLK_DSP) begin
            if (RST_DSP = '1') then
                ptn_gen_en_d1   <= '0';
                ptn_gen_en_rpls <= '0';
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                ptn_gen_en_d1   <= PTN_GEN_EN_IN;
                ptn_gen_en_rpls <= PTN_GEN_EN_IN and (not ptn_gen_en_d1);
            end if;
        end process;

        P_Pattern_GEN_State_Count_NM : process(RST_DSP, CLK_DSP) begin
            if (RST_DSP = '1') then
                state_cnt <= "11";
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                if (PTN_GEN_EN_IN = '0') then
                    state_cnt <= "11";
                else
                    if (ptn_gen_en_rpls = '1') then
                        state_cnt <= "00";
                    elsif (FS_10ms_RPLS_IN = '1') then           
                        state_cnt <= "01";
                    else
                        state_cnt <= state_cnt;
                    end if; 
                end if;
            end if;
        end process;

        -- Pattern Repeatation Count
        P_512_Counter_NM : process(RST_DSP, CLK_DSP) begin
            if (RST_DSP = '1') then    
                cnt_512 <= (others => '1');
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                if (state_cnt = "01") then
                    if (ptn_vld = '1') then
                        cnt_512 <= cnt_512 + '1';
                    else
                        cnt_512 <= cnt_512;
                    end if;
                else
                    cnt_512 <= (others => '1');
                end if;
            end if;
        end process;

        P_Reapeat_Counter_NM : process(RST_DSP, CLK_DSP) begin
            if (RST_DSP = '1') then
                cnt_repeat      <= (others => '1');
                ptn_gen_section <= '0';
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                if (state_cnt = "01") then
                    if (ptn_vld = '1') then
                        if (cnt_512 = '1'&x"FF") then
                            if (cnt_repeat = REPEAT_PER_SW_IN) then
                                cnt_repeat      <= cnt_repeat;
                                ptn_gen_section <= '0';
                            else
                                cnt_repeat      <= cnt_repeat + '1';
                                ptn_gen_section <= '1';
                            end if;
                        else
                            cnt_repeat      <= cnt_repeat;
                            ptn_gen_section <= ptn_gen_section;
                        end if;
                    else
                        cnt_repeat      <= cnt_repeat;
                        ptn_gen_section <= ptn_gen_section;
                    end if;
                else
                    cnt_repeat      <= (others => '1');
                    ptn_gen_section <= '0';
                end if;
            end if;
        end process;

        P_PTN_GEN_Section_Shift_NM : process(RST_DSP, CLK_DSP) begin
            if (RST_DSP = '1') then
                ptn_gen_section_sh <= (others => '0'); 
                ptn_gen_section_en <= '0';             
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                ptn_gen_section_sh <= ptn_gen_section_sh(1 downto 0) & ptn_gen_section; 

                if (ptn_vld = '1') then
                    ptn_gen_section_en <= ptn_gen_section_sh(2);             
                else
                    ptn_gen_section_en <= ptn_gen_section_en;             
                end if;
            end if;
        end process;

        -- Pattern Generate 
        P_ROM_Interface_NM : process(RST_DSP, CLK_DSP) begin
            if (RST_DSP = '1') then
                ren   <= '0';            
                raddr <= (others => '0');
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                if (ptn_gen_section = '1') then
                    ren   <= ptn_vld;            
                    raddr <= cnt_512;
                else
                    ren   <= '0';            
                    raddr <= (others => '0');
                end if;
            end if;
        end process;
    end generate;

    G_PTN_GEN_CTRL_HS : if (HS_MODE = TRUE) generate begin
        clk_div_cnt <= (others => '0');
        ptn_vld     <= '1';

        -- Avoid 1st Dummy Frame 
        P_Pattern_GEN_Rpls_HS : process(CLK_DSP) begin
            if (CLK_DSP'event) and (CLK_DSP = '1') then
                ptn_gen_en_d1   <= PTN_GEN_EN_IN;
                ptn_gen_en_rpls <= PTN_GEN_EN_IN and (not ptn_gen_en_d1);
            end if;
        end process;

        P_Pattern_GEN_State_Count_HS : process(CLK_DSP) begin
            if (CLK_DSP'event) and (CLK_DSP = '1') then
                if (RST_DSP = '1') then
                    state_cnt <= "11";
                else
                    if (PTN_GEN_EN_IN = '0') then
                        state_cnt <= "11";
                    else
                        if (ptn_gen_en_rpls = '1') then
                            state_cnt <= "00";
                        elsif (FS_10ms_RPLS_IN = '1') then           
                            state_cnt <= "01";
                        else
                            state_cnt <= state_cnt;
                        end if; 
                    end if;
                end if;
            end if;
        end process;

        -- Pattern Repeatation Count
        P_512_Counter_HS : process(CLK_DSP) begin
            if (CLK_DSP'event) and (CLK_DSP = '1') then
                if (RST_DSP = '1') then    
                    cnt_512 <= (others => '1');
                else
                    if (state_cnt = "01") then
                        cnt_512 <= cnt_512 + '1';
                    else
                        cnt_512 <= (others => '1');
                    end if;
                end if;
            end if;
        end process;

        P_Reapeat_Counter_HS : process(CLK_DSP) begin
            if (CLK_DSP'event) and (CLK_DSP = '1') then
                if (RST_DSP = '1') then
                    cnt_repeat      <= (others => '1');
                    ptn_gen_section <= '0';
                else
                    if (state_cnt = "01") then
                        if (cnt_512 = '1'&x"FF") then
                            if (cnt_repeat = REPEAT_PER_SW_IN) then
                                cnt_repeat      <= cnt_repeat;
                                ptn_gen_section <= '0';
                            else
                                cnt_repeat      <= cnt_repeat + '1';
                                ptn_gen_section <= '1';
                            end if;
                        else
                            cnt_repeat      <= cnt_repeat;
                            ptn_gen_section <= ptn_gen_section;
                        end if;
                    else
                        cnt_repeat      <= (others => '1');
                        ptn_gen_section <= '0';
                    end if;
                end if;
            end if;
        end process;

        P_PTN_GEN_Section_Shift_HS : process(CLK_DSP) begin
            if (CLK_DSP'event) and (CLK_DSP = '1') then
                ptn_gen_section_sh <= ptn_gen_section_sh(1 downto 0) & ptn_gen_section; 
                ptn_gen_section_en <= ptn_gen_section_sh(2);             
            end if;
        end process;

        -- Pattern Generate 
        P_ROM_Interface_HS : process(CLK_DSP) begin
            if (CLK_DSP'event) and (CLK_DSP = '1') then
                if (ptn_gen_section = '1') then
                    ren   <= ptn_vld;            
                    raddr <= cnt_512;
                else
                    ren   <= '0';            
                    raddr <= (others => '0');
                end if;
            end if;
        end process;
    end generate;

    U_RX_SSD_PTN_RAM : SIMPLE_DPRAM_DUALCLK 
    generic map(
        RAM_STYLE              => "BLOCK"                ,
        RAM_INIT_VALUE         =>      0                 ,
    
        DATA_WIDTH             =>     32                 ,
        ADDR_WIDTH             =>      9  
        )
    port map(
        CLKA                   => CLK_CPU                , 
        ENA                    => PTN_WREN_IN            , 
        WEA                    => PTN_WREN_IN            , 
        ADDRA                  => PTN_WADDR_IN           , 
        DATAA                  => PTN_WDATA_IN           , 
    
        CLKB                   => CLK_DSP                , 
        ENB                    => ren                    , 
        ADDRB                  => raddr                  , 
        DATAB                  => rdata   
        );

    G_PTN_GEN_Align_NM : if (HS_MODE = FALSE) generate begin
        U_Pattern_Align_NM : process(RST_DSP, CLK_DSP) begin
            if (RST_DSP = '1') then
                ptn_gen_vld <= '0';
                ptn_gen_i   <= (others => '0');
                ptn_gen_q   <= (others => '0');
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                ptn_gen_vld <= ptn_vld;

                if (ptn_vld = '1') then
                    if (ptn_gen_section_en = '1') then 
                        ptn_gen_i <= rdata(31 downto 16);
                        ptn_gen_q <= rdata(15 downto  0);
                    else
                        ptn_gen_i   <= (others => '0');
                        ptn_gen_q   <= (others => '0');
                    end if;
                else
                    ptn_gen_i <= ptn_gen_i;
                    ptn_gen_q <= ptn_gen_q;
                end if;
            end if;
        end process;
    end generate;

    G_PTN_GEN_Align_HS : if (HS_MODE = TRUE) generate begin
        U_Pattern_Align_HS : process(CLK_DSP) begin
            if (CLK_DSP'event) and (CLK_DSP = '1') then
                if (ptn_gen_section_en = '1') then 
                    ptn_gen_vld <= ptn_vld;
                    ptn_gen_i   <= rdata(31 downto 16);
                    ptn_gen_q   <= rdata(15 downto  0);
                else
                    ptn_gen_vld <= '0';
                    ptn_gen_i   <= (others => '0');
                    ptn_gen_q   <= (others => '0');
                end if;
            end if;
        end process;

    end generate;

    PTN_VLD_OUT <= ptn_gen_vld;
    PTN_I_OUT   <= ptn_gen_i;
    PTN_Q_OUT   <= ptn_gen_q;

end arc_RX_SSD_PTN_GEN;
