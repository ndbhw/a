library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

entity SRL16E_WRAP is
generic(
    DEVICE    : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    BIT_WIDTH : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    SEL_DLY   : in  std_logic_vector( 3 downto 0);         -- Select Delay, 0 ~ 15 => 0 ~ 15 clk delay
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0) -- Delayed DATA
    );
end SRL16E_WRAP;

architecture arc_SRL16E_WRAP of SRL16E_WRAP is

component SRL16E_WRAP_7S is
generic(
    BIT_WIDTH : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    SEL_DLY   : in  std_logic_vector( 3 downto 0);         -- Select Delay, 0 ~ 15 => 0 ~ 15 clk delay
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0) -- Delayed DATA
    );
end component;

component SRL16E_WRAP_US is
generic(
    BIT_WIDTH : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    SEL_DLY   : in  std_logic_vector( 3 downto 0);         -- Select Delay, 0 ~ 15 => 0 ~ 15 clk delay
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0) -- Delayed DATA
    );
end component;

begin	

    G_7Series_SRL16E : if (DEVICE = "7SERIES") generate begin
        U_SRL16E_WRAP_7S : SRL16E_WRAP_7S generic map(BIT_WIDTH) port map(CLK, DATA_IN, SEL_DLY, DATA_OUT);
    end generate;

    G_UltraScale_SRL16E : if (DEVICE = "ULTRASCALE") generate begin
        U_SRL16E_WRAP_US : SRL16E_WRAP_US generic map(BIT_WIDTH) port map(CLK, DATA_IN, SEL_DLY, DATA_OUT);
    end generate;

end arc_SRL16E_WRAP;
