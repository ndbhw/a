-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name : INDIRECT_COEF_UPDATE 
-- Project    : 

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity INDIRECT_COEF_UPDATE is
generic(
    COEF_NUM      : natural := 39;
    HS_MODE       : boolean := FALSE
    );
port(
    RST_CPU       : in  std_logic;
    CLK_CPU       : in  std_logic;

    COEF_WR_EN    : in  std_logic;                     -- coefficient write enable(indirect)
    COEF_RD_EN    : in  std_logic;                     -- coefficient write done(indirect)
    COEF_WR_DN    : in  std_logic;                     -- coefficient read  enable(indirect)
    COEF_ADDR     : in  std_logic_vector( 7 downto 0); -- coefficient write address(indirect) 
    COEF_WR_DATA  : in  std_logic_vector(15 downto 0); -- coefficient write data(indirect) 
    COEF_RD_DATA  : out std_logic_vector(15 downto 0); -- coefficient read  data(indirect) 

    RST_DSP       : in  std_logic;
    CLK_DSP       : in  std_logic;

    FIR_COEF      : out std_logic_array16(COEF_NUM-1 downto 0)
    );
end INDIRECT_COEF_UPDATE;

architecture arc_INDIRECT_COEF_UPDATE of INDIRECT_COEF_UPDATE is

signal coef_wr_en_sh  : std_logic_vector(2 downto 0);
signal coef_rd_en_sh  : std_logic_vector(2 downto 0);
signal coef_wr_dn_sh  : std_logic_vector(2 downto 0);
signal coef_wr_en_pls : std_logic;
signal coef_rd_en_pls : std_logic;
signal coef_wr_dn_pls : std_logic;

signal coef           : std_logic_array16(COEF_NUM-1 downto 0);
signal coef_rd        : std_logic_vector(15 downto 0);

-- Symmetric impulse response of delay filter
signal coefd          : std_logic_array16(COEF_NUM-1 downto 0);

attribute KEEP : string;
attribute KEEP of coef_wr_dn_sh  : signal is "TRUE";
attribute KEEP of coef_wr_dn_pls : signal is "TRUE";

attribute MAX_FANOUT : integer;
attribute MAX_FANOUT of coef_wr_dn_sh  : signal is 20;
attribute MAX_FANOUT of coef_wr_dn_pls : signal is 20;

begin

    -- CPU Clock Domain
    -- Indirect method : coefficient write/read interface signal processing
    P_Interface_signal_shift : process(RST_CPU, CLK_CPU) begin
        if (RST_CPU = '1') then
            coef_wr_en_sh <= (others => '0');
            coef_rd_en_sh <= (others => '0');
        elsif (CLK_CPU'event) and (CLK_CPU = '1') then
            coef_wr_en_sh <= coef_wr_en_sh(1 downto 0) & COEF_WR_EN;
            coef_rd_en_sh <= coef_rd_en_sh(1 downto 0) & COEF_RD_EN;
        end if;
    end process;

    P_Interface_Signal_Pulse_Gen : process(RST_CPU, CLK_CPU) begin
        if (RST_CPU = '1') then
            coef_wr_en_pls <= '0';
            coef_rd_en_pls <= '0';
        elsif (CLK_CPU'event) and (CLK_CPU = '1') then
	    if (coef_wr_en_sh(2 downto 1) = "01") then  
                coef_wr_en_pls <= '1'; -- Rising edge detect 
            else                                        
                coef_wr_en_pls <= '0'; 
            end if;
            if (coef_rd_en_sh(2 downto 1) = "01") then  
                coef_rd_en_pls <= '1'; -- Rising edge detect 
            else                                        
                coef_rd_en_pls <= '0'; 
            end if;
        end if;
    end process;
	
    -- Coefficient data write
    P_Coef_Write : process(RST_CPU, CLK_CPU) begin
        if (RST_CPU = '1') then
            coef <= (others => (others => '0'));
        elsif (CLK_CPU'event) and (CLK_CPU = '1') then
            if (coef_wr_en_pls = '1') then
                for I in 0 to (COEF_NUM-1) loop 
                if (COEF_ADDR = conv_std_logic_vector(I, 8)) then  
                    coef(I) <= COEF_WR_DATA;
                else
                    coef(I) <= coef(I);
                end if;
                end loop;
            else
                coef <= coef;
            end if;
        end if;
    end process;

    -- Coefficient data read
    P_Coef_Read : process(RST_CPU, CLK_CPU) begin
        if (RST_CPU = '1') then
            coef_rd <= (others => '0');
        elsif (CLK_CPU'event) and (CLK_CPU = '1') then
            if (coef_rd_en_pls = '1') then
                case (COEF_ADDR) is
                    when x"00"  => coef_rd <= coefd(0)  ; -- Coefficient 1
                    when x"01"  => coef_rd <= coefd(1)  ; -- Coefficient 2 
                    when x"02"  => coef_rd <= coefd(2)  ; -- Coefficient 3
                    when x"03"  => coef_rd <= coefd(3)  ; -- Coefficient 4 
                    when x"04"  => coef_rd <= coefd(4)  ; -- Coefficient 5
                    when x"05"  => coef_rd <= coefd(5)  ; -- Coefficient 6
                    when x"06"  => coef_rd <= coefd(6)  ; -- Coefficient 7
                    when x"07"  => coef_rd <= coefd(7)  ; -- Coefficient 8
                    when x"08"  => coef_rd <= coefd(8)  ; -- Coefficient 9
                    when x"09"  => coef_rd <= coefd(9)  ; -- Coefficient 10
                    when x"0A"  => coef_rd <= coefd(10) ; -- Coefficient 11
                    when x"0B"  => coef_rd <= coefd(11) ; -- Coefficient 12
                    when x"0C"  => coef_rd <= coefd(12) ; -- Coefficient 13
                    when x"0D"  => coef_rd <= coefd(13) ; -- Coefficient 14
                    when x"0E"  => coef_rd <= coefd(14) ; -- Coefficient 15
                    when x"0F"  => coef_rd <= coefd(15) ; -- Coefficient 16
                    when x"10"  => coef_rd <= coefd(16) ; -- Coefficient 17
                    when x"11"  => coef_rd <= coefd(17) ; -- Coefficient 18
                    when x"12"  => coef_rd <= coefd(18) ; -- Coefficient 19
                    when x"13"  => coef_rd <= coefd(19) ; -- Coefficient 20
                    when x"14"  => coef_rd <= coefd(20) ; -- Coefficient 21
                    when x"15"  => coef_rd <= coefd(21) ; -- Coefficient 22
                    when x"16"  => coef_rd <= coefd(22) ; -- Coefficient 23
                    when x"17"  => coef_rd <= coefd(23) ; -- Coefficient 24
                    when x"18"  => coef_rd <= coefd(24) ; -- Coefficient 25
                    when x"19"  => coef_rd <= coefd(25) ; -- Coefficient 26
                    when x"1A"  => coef_rd <= coefd(26) ; -- Coefficient 27
                    when x"1B"  => coef_rd <= coefd(27) ; -- Coefficient 28
                    when x"1C"  => coef_rd <= coefd(28) ; -- Coefficient 29
                    when x"1D"  => coef_rd <= coefd(29) ; -- Coefficient 30
                    when x"1E"  => coef_rd <= coefd(30) ; -- Coefficient 31
                    when x"1F"  => coef_rd <= coefd(31) ; -- Coefficient 32
                    when x"20"  => coef_rd <= coefd(32) ; -- Coefficient 33
                    when x"21"  => coef_rd <= coefd(33) ; -- Coefficient 34
                    when x"22"  => coef_rd <= coefd(34) ; -- Coefficient 35
                    when x"23"  => coef_rd <= coefd(35) ; -- Coefficient 36
                    when x"24"  => coef_rd <= coefd(36) ; -- Coefficient 37
                    when x"25"  => coef_rd <= coefd(37) ; -- Coefficient 38
                    when x"26"  => coef_rd <= coefd(38) ; -- Coefficient 39 
                    when others => coef_rd <= (others => '0');
                end case;
            else
                coef_rd <= coef_rd;
            end if;
        end if;
    end process;

    COEF_RD_DATA <= coef_rd;

    -- DSP Clock Domain
    G_Normal_Operation : if (HS_MODE = FALSE) generate begin
        P_Write_Done_NM : process(RST_DSP, CLK_DSP) begin
            if (RST_DSP = '1') then
                coef_wr_dn_sh  <= (others => '0');
                coef_wr_dn_pls <= '0';
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                coef_wr_dn_sh <= coef_wr_dn_sh(1 downto 0) & COEF_WR_DN;

                if (coef_wr_dn_sh(2 downto 1) = "01") then  
                    coef_wr_dn_pls <= '1'; -- Rising edge detect 
                else                                        
                    coef_wr_dn_pls <= '0'; 
                end if;
            end if;
        end process;

        -- Coefficient update
        P_Coef_Update_NM : process(RST_DSP, CLK_DSP) begin
            if (RST_DSP = '1') then 
                coefd(0)  <= x"FFF0"; -- Default coefficient 01 value
                coefd(1)  <= x"FF74"; -- Default coefficient 02 value
                coefd(2)  <= x"008B"; -- Default coefficient 03 value
                coefd(3)  <= x"FF5B"; -- Default coefficient 04 value
                coefd(4)  <= x"00A8"; -- Default coefficient 05 value
                coefd(5)  <= x"FF78"; -- Default coefficient 06 value
                coefd(6)  <= x"0045"; -- Default coefficient 07 value
                coefd(7)  <= x"0015"; -- Default coefficient 08 value
                coefd(8)  <= x"FF8F"; -- Default coefficient 09 value
                coefd(9)  <= x"00B5"; -- Default coefficient 10 value
                coefd(10) <= x"FF37"; -- Default coefficient 11 value
                coefd(11) <= x"00A0"; -- Default coefficient 12 value
                coefd(12) <= x"FFC3"; -- Default coefficient 13 value
                coefd(13) <= x"FFB8"; -- Default coefficient 14 value
                coefd(14) <= x"00CD"; -- Default coefficient 15 value
                coefd(15) <= x"FED9"; -- Default coefficient 16 value
                coefd(16) <= x"0132"; -- Default coefficient 17 value
                coefd(17) <= x"FF21"; -- Default coefficient 18 value
                coefd(18) <= x"0037"; -- Default coefficient 19 value
                coefd(19) <= x"009F"; -- Default coefficient 20 value
                coefd(20) <= x"FE99"; -- Default coefficient 21 value
                coefd(21) <= x"01E1"; -- Default coefficient 22 value
                coefd(22) <= x"FE29"; -- Default coefficient 23 value
                coefd(23) <= x"0136"; -- Default coefficient 24 value
                coefd(24) <= x"FFED"; -- Default coefficient 25 value
                coefd(25) <= x"FEB2"; -- Default coefficient 26 value
                coefd(26) <= x"028D"; -- Default coefficient 27 value
                coefd(27) <= x"FCC3"; -- Default coefficient 28 value
                coefd(28) <= x"0307"; -- Default coefficient 29 value
                coefd(29) <= x"FE3A"; -- Default coefficient 30 value
                coefd(30) <= x"FF99"; -- Default coefficient 31 value
                coefd(31) <= x"0317"; -- Default coefficient 32 value
                coefd(32) <= x"FA60"; -- Default coefficient 33 value
                coefd(33) <= x"072E"; -- Default coefficient 34 value
                coefd(34) <= x"F921"; -- Default coefficient 35 value
                coefd(35) <= x"03C8"; -- Default coefficient 36 value
                coefd(36) <= x"0364"; -- Default coefficient 37 value
                coefd(37) <= x"ED6C"; -- Default coefficient 38 value
                coefd(38) <= x"4E7A"; -- Default coefficient 39 value
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                if (coef_wr_dn_pls = '1') then
                    coefd <= coef;
                else
                    coefd <= coefd;
                end if;
            end if;
        end process;
    end generate;

    G_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
        P_Write_Done_HS : process(CLK_DSP) begin
            if (CLK_DSP'event) and (CLK_DSP = '1') then
                coef_wr_dn_sh <= coef_wr_dn_sh(1 downto 0) & COEF_WR_DN;

                if (coef_wr_dn_sh(2 downto 1) = "01") then  
                    coef_wr_dn_pls <= '1'; -- Rising edge detect 
                else                                        
                    coef_wr_dn_pls <= '0'; 
                end if;
            end if;
        end process;

        -- Coefficient update
        P_Coef_Update_HS : process(CLK_DSP) begin
            if (CLK_DSP'event) and (CLK_DSP = '1') then
                if (RST_DSP = '1') then 
                    coefd(0)  <= x"FFF0"; -- Default coefficient 01 value
                    coefd(1)  <= x"FF74"; -- Default coefficient 02 value
                    coefd(2)  <= x"008B"; -- Default coefficient 03 value
                    coefd(3)  <= x"FF5B"; -- Default coefficient 04 value
                    coefd(4)  <= x"00A8"; -- Default coefficient 05 value
                    coefd(5)  <= x"FF78"; -- Default coefficient 06 value
                    coefd(6)  <= x"0045"; -- Default coefficient 07 value
                    coefd(7)  <= x"0015"; -- Default coefficient 08 value
                    coefd(8)  <= x"FF8F"; -- Default coefficient 09 value
                    coefd(9)  <= x"00B5"; -- Default coefficient 10 value
                    coefd(10) <= x"FF37"; -- Default coefficient 11 value
                    coefd(11) <= x"00A0"; -- Default coefficient 12 value
                    coefd(12) <= x"FFC3"; -- Default coefficient 13 value
                    coefd(13) <= x"FFB8"; -- Default coefficient 14 value
                    coefd(14) <= x"00CD"; -- Default coefficient 15 value
                    coefd(15) <= x"FED9"; -- Default coefficient 16 value
                    coefd(16) <= x"0132"; -- Default coefficient 17 value
                    coefd(17) <= x"FF21"; -- Default coefficient 18 value
                    coefd(18) <= x"0037"; -- Default coefficient 19 value
                    coefd(19) <= x"009F"; -- Default coefficient 20 value
                    coefd(20) <= x"FE99"; -- Default coefficient 21 value
                    coefd(21) <= x"01E1"; -- Default coefficient 22 value
                    coefd(22) <= x"FE29"; -- Default coefficient 23 value
                    coefd(23) <= x"0136"; -- Default coefficient 24 value
                    coefd(24) <= x"FFED"; -- Default coefficient 25 value
                    coefd(25) <= x"FEB2"; -- Default coefficient 26 value
                    coefd(26) <= x"028D"; -- Default coefficient 27 value
                    coefd(27) <= x"FCC3"; -- Default coefficient 28 value
                    coefd(28) <= x"0307"; -- Default coefficient 29 value
                    coefd(29) <= x"FE3A"; -- Default coefficient 30 value
                    coefd(30) <= x"FF99"; -- Default coefficient 31 value
                    coefd(31) <= x"0317"; -- Default coefficient 32 value
                    coefd(32) <= x"FA60"; -- Default coefficient 33 value
                    coefd(33) <= x"072E"; -- Default coefficient 34 value
                    coefd(34) <= x"F921"; -- Default coefficient 35 value
                    coefd(35) <= x"03C8"; -- Default coefficient 36 value
                    coefd(36) <= x"0364"; -- Default coefficient 37 value
                    coefd(37) <= x"ED6C"; -- Default coefficient 38 value
                    coefd(38) <= x"4E7A"; -- Default coefficient 39 value
                else
                    if (coef_wr_dn_pls = '1') then
                        coefd <= coef;
                    else
                        coefd <= coefd;
                    end if;
                end if;
            end if;
        end process;
    end generate;

    FIR_COEF <= coefd;

end arc_INDIRECT_COEF_UPDATE;



