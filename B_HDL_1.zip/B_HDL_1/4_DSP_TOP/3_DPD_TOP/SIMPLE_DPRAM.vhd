library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
use IEEE.numeric_std.all;

library UNISIM;
use UNISIM.vcomponents.all;

entity SIMPLE_DPRAM is
generic(
    RAM_TYPE                    : string  := "BLOCK"; -- DISTRIBUTED or BLOCK or ULTRA
    RAM_INIT_VALUE              : integer := 0 ; 
                                               
    DATA_WIDTH                  : natural := 8 ;
    ADDR_WIDTH                  : natural := 6
    );
port(
    CLK_A	                    : in  std_logic;
    EN_A                        : in  std_logic;
    WE_A                        : in  std_logic;
    ADDR_A                      : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATA_A                      : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    CLK_B	                    : in  std_logic;
    EN_B                        : in  std_logic;
    ADDR_B                      : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATA_B                      : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end SIMPLE_DPRAM;

architecture arc_SIMPLE_DPRAM of SIMPLE_DPRAM is

constant mem_init_value         : std_logic_vector((DATA_WIDTH-1) downto 0) := conv_std_logic_vector(RAM_INIT_VALUE, DATA_WIDTH);

-- Build a 2-D array type for the RAM
subtype word_t is std_logic_vector((DATA_WIDTH-1) downto 0);
type memory_t is array(2**ADDR_WIDTH-1 downto 0) of word_t;

-- Declare the RAM signal.	
signal ram                      : memory_t := (others => mem_init_value);

signal q                        : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
signal q_b                      : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');

attribute RAM_STYLE             : string;
attribute RAM_STYLE of RAM      : signal is RAM_TYPE;

begin

    -- Port A
    P_PortA_Write : process(CLK_A) begin
        if (rising_edge(CLK_A)) then 
            if (EN_A = '1') then
                if (WE_A = '1') then
                    ram(conv_integer(ADDR_A)) <= DATA_A;
                end if;
            end if;
        end if;
    end process;
            
    -- On a read during a write to the same address, the read will
    -- return the OLD data at the address
    
    -- Port B
    P_PortB_Read : process(CLK_B) begin
        if (rising_edge(CLK_B)) then
            if (EN_B = '1') then
                q <= ram(conv_integer(ADDR_B));
            end if;
        end if;
    end process;

    P_PortB_Clocking : process(CLK_B) begin
        if (rising_edge(CLK_B)) then
            q_b <= q;
        end if;
    end process;

    DATA_B <= q_b;

end arc_SIMPLE_DPRAM;

