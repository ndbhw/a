----------------------------------------------------------------------------
-- Designer   : Kyoung Heo, (k1340.heo@samsung.com)
-- Block Name : SMART_CAPTURE_CORE
-- Function   : CFR/DPD/FB I/Q data gathering for DPD operation
-- Revision   : - ver 1.0, First Relase DPD & FB 4k Capture
--              - ver 2.0, CFR & DPD & FB 4k Capture
--              - ver 3.0, CFR & DPD & FB 4k/8k Capture
--              - ver 3.1, 4k mixed Capture debugging based on SC ver3.0
--              - ver 4.0, Considered HOVS2 (Sample Valid) 
--              - ver 4.1, Static Capture Debugging on TDD system (16.03.30)
--              - ver 5.0, Optimized SMART_CAPTURE_CORE (16.04~, Compact RRU)
----------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use IEEE.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

--------------------------------------------------
--        Item    |     FDD mode    | TDD mode   |
--------------------------------------------------
--       TDD_MODE |        '0'      |    '1'     |
--------------------------------------------------
-- FRAME_TDD_SYNC | 10ms Frame Sync | TDD Strobe |
--------------------------------------------------

--------------------------------------------------
-- PATH_SEL = FB_VC
-- 0000  : FWD antenna #0
-- 0001  : RVS antenna #0
-- 0010  : FWD antenna #1
-- 0011  : RVS antenna #1
-- 0100  : FWD antenna #2
-- 0101  : RVS antenna #2
-- 0110  : FWD antenna #3
-- 0111  : RVS antenna #3
-- 1000  : FWD antenna #4
-- 1001  : RVS antenna #4
-- 1010  : FWD antenna #5
-- 1011  : RVS antenna #5
-- 1100  : FWD antenna #6
-- 1101  : RVS antenna #6
-- 1110  : FWD antenna #7
-- 1111  : RVS antenna #7

entity SMART_CAPTURE_CORE is
generic(
    DEVICE                    : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    STATIC_CAPTURE_COUNT      : natural := 2        ; -- Static Capture Section on Feedback Switch Forward Counter (10ms)
    CAPTURE_DONE_COUNT        : natural := 2        ; -- Capture Done Boundary on Feedback Switch Forward Counter  (10ms)
    HOVS                      : natural := 1
    );
port(
    -- Common
    RST                       : in  std_logic; 
    CLK                       : in  std_logic;                     -- DSP Operation Clock

    -- Sync Strobe
    FS_STRB_IN                : in  std_logic;                     -- Frame Sync 10ms
    TDD_STRB_IN               : in  std_logic;                     -- TDD Strobe
    -- Capturing Sample Port
    REF_VLD_IN                : in  std_logic;                     -- Reference Sample Valid

    REF_I_IN                  : in  std_logic_vector(15 downto 0); -- CFR output I data
    REF_Q_IN                  : in  std_logic_vector(15 downto 0); -- CFR output Q data

    -- Feedback Switch Information
    FB_VC_IN                  : in  std_logic_vector( 5 downto 0); -- Feedback Switch Information 

    -- Smart Capture Control & Status
    CAPTURE_CONTROL_EN_IN     : in  std_logic;                     -- '0' : Capture Disable, '1' : Capture Enable
    CAPTURE_COMPLETE_PLS_OUT  : out std_logic;                     -- Capture Done Pulse, '1' : done 

    DEBOUNCING_TIME_IN        : in  std_logic_vector( 9 downto 0); -- Smart Capture Debouncing Time at Feedback Switch 1st Frame 10ms 
    CAP_SIZE_SEL_IN           : in  std_logic;                     -- '0' : 8k       , '1' : 4k
    TDD_MODE_IN               : in  std_logic;                     -- '0' : FDD mode , '1' : TDD mode    

    PATH_SEL_IN               : in  std_logic_vector( 4 downto 0);

    CAP_OFF_START_IN          : in  std_logic_vector(21 downto 0); -- smart capture exception period start point
    CAP_OFF_STOP_IN           : in  std_logic_vector(21 downto 0); -- smart capture exception period end point   
    STATIC_POSITION_IN        : in  std_logic_vector(21 downto 0); -- static capture start position
    SC_LENGTH_IN              : in  std_logic_vector( 8 downto 0); -- smart capture length
    MAX_PEAK_BO_GAIN_IN       : in  std_logic_vector(15 downto 0); -- max peak backoff gain value
    CUR_PEAK_BO_GAIN_IN       : in  std_logic_vector(15 downto 0); -- current peak backoff gain value

    CAP_CONDITION_PLS_OUT     : out std_logic;                     -- REF Capture MSB Address Toggle Pulse

    CAP_REF_MSB_ADDR_OUT      : out std_logic;                     -- REF Capture MSB Address
    CAP_REF_WREN_OUT          : out std_logic_vector( 0 downto 0); -- REF Capture Write Enable
    CAP_REF_WRADDR_OUT        : out std_logic_vector(13 downto 0); -- REF Capture Write Address
    CAP_REF_WRDATA_OUT        : out std_logic_vector(31 downto 0); -- REF Capture Write Data : Q[31:16] & I[15:0]

    CAP_FRAME_NUM_OUT         : out std_logic_vector(12 downto 0); -- caputured subframe number  
    CAP_FRAME_PEAK_OUT        : out std_logic_vector(31 downto 0); -- caputured subframe maximum peak value
    CAP_FRAME_PWR_OUT         : out std_logic_vector(31 downto 0)  -- caputured subframe power value
    );
end SMART_CAPTURE_CORE;

architecture arc_SMART_CAPTURE_CORE of SMART_CAPTURE_CORE is

constant static_capture_fbcnt : std_logic_vector( 2 downto 0) := std_logic_vector(to_unsigned(STATIC_CAPTURE_COUNT, 3));
constant capture_done_fbcnt   : std_logic_vector( 2 downto 0) := std_logic_vector(to_unsigned(CAPTURE_DONE_COUNT  , 3));
constant fbcnt_max            : std_logic_vector( 2 downto 0) := std_logic_vector(to_unsigned(CAPTURE_DONE_COUNT+1, 3));

component PWR_N_MAG_MEASURE is
generic(
    DEVICE                    : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HOVS                      : integer := 1  -- (Clock Frequency)/(Sampling Rate)
    );
port(
    CLK                       : in  std_logic;

    SAMPLE_VLD_IN             : in  std_logic;
    SAMPLE_I_IN               : in  std_logic_vector(15 downto 0);
    SAMPLE_Q_IN               : in  std_logic_vector(15 downto 0);

    MEASURE_SYNC_IN           : in  std_logic;
    MEASURE_EN_IN             : in  std_logic; -- Active High
    MEASURE_LENGTH_IN         : in  std_logic; -- '1' : 4k, '0' : 8k

    MEASURED_PWR_OUT          : out std_logic_vector(31 downto 0);
    MEASURED_MAG_OUT          : out std_logic_vector(31 downto 0)
    );
end component;

component BO_GAIN_CALCULATOR is
generic(
    DEVICE                    : string  := "7SERIES"  -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    );
port(
    CLK                       : in  std_logic;

    DATA_IN                   : in  std_logic_vector(31 downto 0);
    GAIN_IN                   : in  std_logic_vector(15 downto 0);

    DATA_OUT                  : out std_logic_vector(31 downto 0)
    );
end component;

component BUF_SAMPLE_DLY is
generic(
    RAM_STYLE            : string := "DISTRIBUTED"; -- "DISTRIBUTED" or "BLOCK"
    RESOLUTION           : string := "CLOCK";       -- "CLOCK" or "SAMPLE_RATE"

    DATA_WIDTH           : natural;
    ADDR_WIDTH           : natural
    );
port(
    RST                  : in  std_logic;
    CLK                  : in  std_logic;

    DELAY_VALUE_IN       : in  std_logic_vector(ADDR_WIDTH-1 downto 0); 

    SAMPLE_VLD_IN        : in  std_logic;
    SAMPLE_IN            : in  std_logic_vector(DATA_WIDTH-1 downto 0); 
    SAMPLE_DELAY_OUT     : out std_logic_vector(DATA_WIDTH-1 downto 0) 
    );
end component;

-- Latency 3 Clock
component UNSIGNED_COMPARE is
generic(
    DATA_WIDTH                : natural := 32;
    BIT_DIV                   : natural := 24  -- DATA_WIDTH > BIT_DIV, Mantissa Compare : 24, Narual Compare : 16
    );
port(
    RST                       : in  std_logic;
    CLK                       : in  std_logic;

    THRESHOLD_IN              : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    DATA_IN                   : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    COMPARE_FLAG_OUT          : out std_logic
    );
end component;

signal reg_path_sel               : std_logic_vector( 5 downto 0);

signal capture_control_en_d1      : std_logic;                     
signal capture_control_en_rpls    : std_logic;      

signal fs_strb_sh                 : std_logic_vector( 9 downto 0);
signal fs_rpls                    : std_logic;
signal fs_rpls_sh                 : std_logic_vector( 7 downto 0);

signal tdd_strb_sh                : std_logic_vector( 9 downto 0);

signal ref_vld_d1                 : std_logic;

signal cap_off_diff_flag          : std_logic;

signal fbsw_align                 : std_logic;
signal fbsw_align_d1              : std_logic;
signal fbsw_align_rpls            : std_logic;

signal cnt_8k                     : std_logic_vector(12 downto 0);
signal cnt_8k_flag                : std_logic;
signal cnt_debouncing             : std_logic_vector( 9 downto 0);
signal debouncing_done_flag       : std_logic;
signal debouncing_done_flag_d1    : std_logic;
signal debouncing_done_pls        : std_logic;

signal cap_section                : std_logic;
signal cap_section_d1             : std_logic;
signal cap_section_rpls           : std_logic;

signal frame_cnt                  : std_logic_vector( 2 downto 0); -- fs_rpls count signal
signal frame_cnt_d1               : std_logic_vector( 2 downto 0); -- 

signal cap_done_pls               : std_logic;

signal ref_cap_window             : std_logic;

signal smart_length_comp_flag     : std_logic;
signal smart_length               : std_logic_vector(12 downto 0); 

signal ref_sub_frame_cnt          : std_logic_vector(12 downto 0);

signal tdd_on_cnt_condition_flag  : std_logic;
signal tdd_on_cnt                 : std_logic_vector(21 downto 0);

signal static_capture_section     : std_logic;
signal static_cap_cnt             : std_logic_vector(21 downto 0);

signal disable_strobe             : std_logic;
type   state_disable              is (ST0, ST1, ST2, ST3, ST4);
signal st_disable                 : state_disable;  

signal static_start_pls           : std_logic;
signal static_end_pls             : std_logic;
signal static_ref_sub_frame_cnt   : std_logic_vector(12 downto 0);

type   static_state               is (STATIC_ST0, STATIC_ST1, STATIC_ST2);
signal st_static                  : static_state;

signal ref_msb_addr               : std_logic;

signal ref_cap_mem_we             : std_logic_vector(0 downto 0);

signal ref_wraddr                 : std_logic_vector(13 downto 0);

signal sub_frame_cnt_clr_pls      : std_logic;
signal sub_frame_cnt              : std_logic_vector(12 downto 0);
signal sub_frame_cnt_d1           : std_logic_vector(12 downto 0);

signal cap_sync                   : std_logic;

signal measured_power             : std_logic_vector(31 downto 0);
signal measured_magnitude         : std_logic_vector(31 downto 0);

signal current_power              : std_logic_vector(31 downto 0);
signal current_magnitude          : std_logic_vector(31 downto 0);

signal max_peak                   : std_logic_vector(31 downto 0);

signal max_peak_p5db_bo_value     : std_logic_vector(31 downto 0);
signal cur_peak_p5_bo_value       : std_logic_vector(31 downto 0);

signal compare_curpwr_flg         : std_logic;
signal compare_curmag_flg         : std_logic;
signal compare_curpeak_flg        : std_logic;

signal max_peak_p5db_bo_value_lat : std_logic_vector(31 downto 0);
signal cur_peak_p5_bo_value_lat   : std_logic_vector(31 downto 0);

signal compare_pls                : std_logic;
signal latch_pls                  : std_logic;

signal sc_captured_section        : std_logic;

signal pre_current_power          : std_logic_vector(31 downto 0);
signal pre_current_magnitude      : std_logic_vector(31 downto 0);
signal sub_frame_num              : std_logic_vector(12 downto 0);

signal cap_condition_0            : std_logic;
signal cap_condition_1            : std_logic;
signal cap_condition_2            : std_logic;

signal capture_case1              : std_logic;
signal capture_case2              : std_logic;

signal pre_current_power_lat      : std_logic_vector(31 downto 0);
signal pre_current_magnitude_lat  : std_logic_vector(31 downto 0);
signal sub_frame_num_lat          : std_logic_vector(12 downto 0);

signal ref_sample_qi              : std_logic_vector(31 downto 0);
signal ref_sample_delayed_qi      : std_logic_vector(31 downto 0);

begin

    P_For_Timing : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            ref_vld_d1 <= REF_VLD_IN;
        end if;
    end process;

    P_TDD_CAPOFF_Compare_FLAG : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (CAP_OFF_START_IN = CAP_OFF_STOP_IN) then                     
                cap_off_diff_flag <= '0';
            else
                cap_off_diff_flag <= '1';
            end if;
        end if;
    end process;

    P_Sync_Pulse_Shift : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (ref_vld_d1 = '1') then
                fs_strb_sh   <= fs_strb_sh(8 downto 0) & FS_STRB_IN;
                fs_rpls      <= fs_strb_sh(1) and (not fs_strb_sh (2));
                fs_rpls_sh   <= fs_rpls_sh(6 downto 0) & fs_rpls;
                tdd_strb_sh  <= tdd_strb_sh(8 downto 0)& TDD_STRB_IN;
            end if;
        end if;
    end process;

    reg_path_sel <= '0' & PATH_SEL_IN;

    P_Feedback_Switch_Align : process(RST, CLK) begin
        if (RST = '1') then
            fbsw_align      <= '0';
            fbsw_align_d1   <= '0';
            fbsw_align_rpls <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (FB_VC_IN = reg_path_sel) then
                fbsw_align <= '1';
            else
                fbsw_align <= '0';
            end if;

            fbsw_align_d1   <= fbsw_align;
            fbsw_align_rpls <= fbsw_align and (not fbsw_align_d1);
        end if;
    end process;

    P_SYNC_RPLS_Count : process(RST, CLK) begin   
        if (RST = '1') then
            frame_cnt <= (others => '1');
        elsif (CLK'event) and (CLK = '1') then
            if (cap_section = '1') then
                if (frame_cnt = fbcnt_max) then 
                    frame_cnt <= frame_cnt ;
                else
                    if (ref_vld_d1 = '1') then
                        if (fs_rpls_sh(0) = '1') then
                            frame_cnt <= frame_cnt + '1';
                        end if;
                    end if; 
                end if;
            else
                frame_cnt <= (others => '0');
            end if;
        end if;
    end process;

    P_1st_Frame_Debouncing : process(RST, CLK) begin
        if (RST = '1') then
            cnt_8k                  <= (others => '1');
            cnt_8k_flag             <= '0';
            cnt_debouncing          <= (others => '1');
            debouncing_done_flag    <= '0';
            debouncing_done_flag_d1 <= '0';
            debouncing_done_pls     <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (fbsw_align = '1') then
                cnt_8k <= cnt_8k + '1';
                if (cnt_8k = '1'&x"FFE") then -- 8190
                    cnt_8k_flag <= '1';
                else
                    cnt_8k_flag <= '0';
                end if;
            else
                cnt_8k <= (others => '0');
            end if;

            if (fbsw_align_rpls = '1') then 
                cnt_debouncing       <= (others => '0');
                debouncing_done_flag <= '0';
            else
                if (cnt_8k_flag = '1') then -- 8191 
                    if (cnt_debouncing = DEBOUNCING_TIME_IN) then       
                        cnt_debouncing       <= cnt_debouncing;
                        debouncing_done_flag <= '1';
                    else
                        cnt_debouncing       <= cnt_debouncing + '1';
                        debouncing_done_flag <= '0';
                    end if;
                end if;
            end if;

            if (ref_vld_d1 = '1') then
                debouncing_done_flag_d1 <= debouncing_done_flag;
                debouncing_done_pls     <= debouncing_done_flag and (not debouncing_done_flag_d1);
            end if;
        end if;
    end process;

    P_Capture_Valid_Section : process(RST, CLK) begin
        if (RST = '1') then
            cap_section      <= '0';
            cap_section_d1   <= '0';
            cap_section_rpls <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (ref_vld_d1 = '1') then
                if (fbsw_align = '1') then 
                    if (debouncing_done_pls = '1') then
                        cap_section <= (CAPTURE_CONTROL_EN_IN);
                    else
                        if (cap_done_pls = '1') then
                            cap_section <= '0';
                        end if;
                    end if;
                else
                    cap_section <= '0';
                end if;
            end if;

            cap_section_d1   <= cap_section;
            cap_section_rpls <= cap_section and (not cap_section_d1);
        end if;
    end process;

    P_Capture_Done_Flag_GEN : process(RST, CLK) begin
        if (RST = '1') then
            frame_cnt_d1  <= (others => '0');
            cap_done_pls  <= '0';
        elsif (CLK'event) and (CLK = '1') then
            frame_cnt_d1  <= frame_cnt;

            if ((frame_cnt /= capture_done_fbcnt) and (frame_cnt_d1 = capture_done_fbcnt)) then
                cap_done_pls  <= '1';
            else
                cap_done_pls  <= '0';
            end if;
            
        end if;
    end process;

    CAPTURE_COMPLETE_PLS_OUT <= cap_done_pls;

    -- Smart Capture & Mixed Capture Control

    P_REF_Capture_Window : process(RST, CLK) begin
        if (RST = '1') then
            ref_cap_window <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (ref_vld_d1 = '1') then
                if (frame_cnt = capture_done_fbcnt+'1') then 
                     ref_cap_window <= '0';
                else
                    if (cap_section = '1') then
                        -- FDD Mode
                        if (TDD_MODE_IN = '0') then 
                            ref_cap_window <= '1';
                        -- TDD Mode
                        else
                            if (frame_cnt = static_capture_fbcnt) and (smart_length_comp_flag = '1') then
                                ref_cap_window <= '1';
                            else
                                ref_cap_window <= tdd_strb_sh(4);
                            end if;
                        end if;
                    else
                        ref_cap_window <= '0';
                    end if;
                end if;
            end if;
        end if;
    end process;

    -- Mixed Capture
    P_Mixed_Capture_Smart_Length : process(RST, CLK) begin
        if (RST = '1') then
            smart_length <= (others => '0'); 
        elsif (CLK'event) and (CLK = '1') then
            -- Capture Memory : 4k setting
            if (CAP_SIZE_SEL_IN = '1') then 
                smart_length <= '0' & SC_LENGTH_IN(7 downto 0) & "1111"; 
            -- Capture Memory : 8k setting
            else
                smart_length <= SC_LENGTH_IN & "1111"; 
            end if;
        end if;
    end process;

    P_Mixed_Capture_Smart_Length_COMP_Flag : process(RST, CLK) begin
        if (RST = '1') then
            smart_length_comp_flag <= '0';
        elsif (CLK'event) and (CLK = '1') then
            -- Capture Memory : 4k setting
            if (CAP_SIZE_SEL_IN = '1') then 
                if (smart_length = '0' & x"FFF") then
                    smart_length_comp_flag <= '1'; -- Only Smart Capture
                else
                    smart_length_comp_flag <= '0'; -- Mixed Capture
                end if;

            -- Capture Memory : 8k setting
            else
                if (smart_length = '1' & x"FFF") then
                    smart_length_comp_flag <= '1'; -- Only Smart Capture
                else
                    smart_length_comp_flag <= '0'; -- Mixed Capture
                end if;
            end if;
        end if;
    end process;

    -- Sub Frame Counting
    P_SC_Sample_Counter : process(RST, CLK) begin
        if (RST = '1') then
            ref_sub_frame_cnt <= (others => '0'); 
        elsif (CLK'event) and (CLK = '1') then
            if (ref_cap_window = '0') then
                ref_sub_frame_cnt <= (others => '0'); 
            else
                if (ref_vld_d1 = '1') then
                    if (ref_sub_frame_cnt = smart_length) then
                        ref_sub_frame_cnt <= (others => '0'); 
                    else
                        ref_sub_frame_cnt <= ref_sub_frame_cnt + '1'; 
                    end if;
                end if;
            end if;
        end if;
    end process;

    -- TDD On Counting
    P_TDD_On_Counter : process(RST, CLK) begin
        if (RST = '1') then
            tdd_on_cnt_condition_flag <= '0';
            tdd_on_cnt                <= (others => '0'); 
        elsif (CLK'event) and (CLK = '1') then
            tdd_on_cnt_condition_flag  <= (TDD_MODE_IN) and (ref_cap_window) and (tdd_strb_sh(4));

            if (tdd_on_cnt_condition_flag = '1') then  
                if (ref_vld_d1 = '1') then
                    if (tdd_on_cnt = "11" & x"FFFFF") then
                        tdd_on_cnt <= tdd_on_cnt;
                    else 
                        tdd_on_cnt <= tdd_on_cnt + '1';
                    end if;
                end if;
            else
                tdd_on_cnt <= (others => '0'); 
            end if;
            -- -- FDD Mode
            -- if (TDD_MODE_IN  = '0') then -- 
            --     tdd_on_cnt <= (others => '0'); 
            -- 
            -- -- TDD Mode
            -- else
            --     if (ref_cap_window = '0') then
            --         tdd_on_cnt <= (others => '0'); 
            --     else
            --         -- UL Section
            --         if (tdd_strb_sh(4) = '0') then
            --             tdd_on_cnt <= (others => '0'); 
            --         -- DL Section
            --         else
            --             if (ref_vld_d1 = '1') then
            --                 if (tdd_on_cnt = "11" & x"FFFFF") then
            --                     tdd_on_cnt <= tdd_on_cnt;
            --                 else 
            --                     tdd_on_cnt <= tdd_on_cnt + '1';
            --                 end if;
            --             else
            --                 tdd_on_cnt <= tdd_on_cnt;
            --             end if;
            --         end if;
            --     end if;
            -- end if;
        end if;
    end process;

    -- Static Capture 
    static_capture_section <= '1' when ((smart_length_comp_flag = '0') and (frame_cnt = static_capture_fbcnt)) else '0';

    P_Static_Capture_Sample_Counting : process(RST, CLK) begin
        if (RST =  '1') then
            static_cap_cnt <= (others => '0'); 
        elsif (CLK'event) and (CLK = '1') then
            if (static_capture_section = '1') then -- Mixed Static Capture Section
                if (ref_vld_d1 = '1') then
                    static_cap_cnt <= static_cap_cnt + '1'; 
                end if;
            else
                static_cap_cnt <= (others => '0'); 
            end if;
        end if;
    end process;

    -- FSM : Generate Disable Strobe
    P_FSM_for_GEN_Disable_Strobe : process(RST, CLK) begin
        if (RST = '1') then
            disable_strobe <= '1';
            st_disable     <= ST0;  
        elsif (CLK'event) and (CLK = '1') then
            if (cap_section = '0') then
                disable_strobe <= '1';
                st_disable     <= ST0;
            else	
                if (ref_vld_d1 = '1') then
                    case (st_disable) is
                        when ST0    => if (TDD_MODE_IN = '1') then
                                           if (tdd_strb_sh(4) = '1') then
                                               disable_strobe <= '0';
                                               st_disable     <= ST1;
                                           else
                                               disable_strobe <= '0';
                                               st_disable     <= ST0;
                                           end if;
                                       else
                                           disable_strobe <= '0';

                                           if (fs_rpls_sh(1) = '1') then
                                               st_disable     <= ST1;
                                           else
                                               st_disable     <= ST0;
                                           end if;
                                       end if;

                        when ST1    => if (static_capture_section = '1') then
                                           disable_strobe <= '1';
                                           st_disable     <= ST1;
                                       else
                                           disable_strobe <= disable_strobe;

                                           -- TDD Mode
                                           if (TDD_MODE_IN  = '1') then
                                               if (tdd_strb_sh(5) = '1') then
                                                   if (cap_off_diff_flag = '0') then
                                                       st_disable <= ST4;
                                                   else
                                                       st_disable <= ST2;
                                                   end if;
                                               end if;

                                           -- FDD Mode
                                           else
                                               st_disable <= ST1;
                                           end if;
                                       end if;

                        when ST2    => -- TDD Mode
                                       if (TDD_MODE_IN = '1') then
                                           if (tdd_on_cnt = CAP_OFF_START_IN) then
                                               disable_strobe <= '1';
                                               st_disable     <= ST3;
                                           else
                                               disable_strobe <= disable_strobe;
                                               st_disable     <= ST2;
                                           end if;
                                       -- FDD Mode
                                       else
                                           disable_strobe <= '0';
                                           st_disable     <= ST0;
                                       end if;
                        when ST3    => -- TDD Mode
                                       if (TDD_MODE_IN = '1') then
                                           if (tdd_on_cnt = CAP_OFF_STOP_IN) then
                                               disable_strobe <= '0';
                                               st_disable     <= ST4;
                                           else
                                               disable_strobe <= disable_strobe;
                                               st_disable     <= ST3;
                                           end if;
                                       -- FDD Mode
                                       else
                                           disable_strobe <= '0';
                                           st_disable     <= ST0;
                                       end if;
                        when ST4    => -- TDD Mode
                                       if (TDD_MODE_IN = '1') then
                                           if (tdd_strb_sh(4) = '0') then
                                               disable_strobe <= '1';
                                               st_disable     <= ST1;
                                           else
                                               disable_strobe <= '0';
                                               st_disable     <= ST4;
                                           end if;
                                       -- FDD Mode
                                       else
                                           disable_strobe <= '0';
                                           st_disable     <= ST0;
                                       end if;

                        when others => disable_strobe <= '0';
                                       st_disable     <= ST0;
                    end case;
                else
                    disable_strobe <= disable_strobe ;
                    st_disable     <= st_disable     ;
                end if;
            end if;
        end if;
    end process;                                 
          
    P_FSM_For_Static_Capture : process(RST, CLK) begin
        if (RST = '1') then
            static_start_pls         <= '0';
            static_end_pls           <= '0';
            static_ref_sub_frame_cnt <= (others => '0');
            st_static                <= STATIC_ST0;
        elsif (CLK'event) and (CLK = '1') then
            if (ref_vld_d1 = '1') then
                if (static_capture_section = '0') then
                    static_start_pls         <= '0';
                    static_end_pls           <= '0';
                    static_ref_sub_frame_cnt <= smart_length;
                    st_static                <= STATIC_ST0;
                else
                    case (st_static) is
                        when STATIC_ST0 => static_ref_sub_frame_cnt <= static_ref_sub_frame_cnt;
                                           static_end_pls           <= static_end_pls;
                                           if (static_cap_cnt = STATIC_POSITION_IN) then
                                               static_start_pls <= '1';
                                               st_static        <= STATIC_ST1;
                                           else		       
                                               static_start_pls <= static_start_pls;
                                               st_static        <= STATIC_ST0;
                                           end if;

                        when STATIC_ST1 => static_start_pls         <= '0';
                                           static_ref_sub_frame_cnt <= static_ref_sub_frame_cnt + '1';
                                           -- Capture Memory Depth : 4k
                                           if (CAP_SIZE_SEL_IN = '1') then
                                               if (static_ref_sub_frame_cnt = '0'&x"FFE") then
                                                   static_end_pls   <= '1';
                                                   st_static        <= STATIC_ST2;
                                               else
                                                   static_end_pls   <= static_end_pls;
                                                   st_static        <= STATIC_ST1;
                                               end if;
                                           -- Capture Memory Depth : 8k
                                           else
                                               if (static_ref_sub_frame_cnt = '1'&x"FFE") then
                                                   static_end_pls   <= '1';
                                                   st_static        <= STATIC_ST2;
                                               else
                                                   static_end_pls   <= static_end_pls;
                                                   st_static        <= STATIC_ST1;
                                               end if;
                                           end if;

                        when STATIC_ST2 => static_start_pls         <= static_start_pls;
                                           st_static                <= STATIC_ST2;
                                           static_ref_sub_frame_cnt <= static_ref_sub_frame_cnt;
                                           static_end_pls           <= '0';

                        when others     => static_start_pls         <= '0';
                                           static_end_pls           <= '0';
                                           static_ref_sub_frame_cnt <= (others => '0');
                                           st_static                <= STATIC_ST0;
                    end case;
                end if;
            end if;
        end if;
    end process;

    P_MSB_ADDR_Control : process(RST, CLK) begin
        if (RST = '1') then
            ref_msb_addr <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (ref_vld_d1 = '1') then
                if (ref_cap_mem_we = "1") then
                    if (sc_captured_section = '1') or (static_start_pls = '1') or (static_end_pls = '1') then
                        ref_msb_addr <= not ref_msb_addr;
                    end if;
                end if;
            end if;
        end if;
    end process;

    CAP_REF_MSB_ADDR_OUT <= ref_msb_addr;
		
    P_Capture_Size_Select : process(RST, CLK) begin
        if (RST = '1') then
            ref_wraddr <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (ref_vld_d1 = '1') then
                -- Capture Memory Depth : 4k
                if (CAP_SIZE_SEL_IN = '1') then
                    if (static_capture_section = '1') then
                        ref_wraddr <= '0'& ref_msb_addr& static_ref_sub_frame_cnt(11 downto 0);
                    else
                        ref_wraddr <= '0'& ref_msb_addr& ref_sub_frame_cnt(11 downto 0);
                    end if;
                -- Capture Memory Depth : 8k
                else
                    if (static_capture_section = '1') then
                        ref_wraddr <= ref_msb_addr& static_ref_sub_frame_cnt;
                    else
                        ref_wraddr <= ref_msb_addr& ref_sub_frame_cnt;
                    end if;
                end if;
            end if;
        end if;
    end process;

    P_Sub_FR_NUM_Clear_Pulse_GEN : process(RST, CLK) begin
        if (RST = '1') then
            sub_frame_cnt_clr_pls <= '0'; 
        elsif (CLK'event) and (CLK = '1') then
            if (ref_vld_d1 = '1') then
                if (cap_section_rpls = '1') then
                    sub_frame_cnt_clr_pls <= '1'; 
                else
                    sub_frame_cnt_clr_pls <= '0'; 
                end if;
            end if;
        end if;
    end process;

    P_Sub_Frame_Number : process(RST, CLK) begin
        if (RST = '1') then
            sub_frame_cnt    <= (others => '0');
            sub_frame_cnt_d1 <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (ref_vld_d1 = '1') then
                if (sub_frame_cnt_clr_pls = '1') then
                    sub_frame_cnt <= (others => '0');
                elsif (ref_sub_frame_cnt = smart_length) then 
                    sub_frame_cnt <= sub_frame_cnt + '1';
                end if;

                sub_frame_cnt_d1 <= sub_frame_cnt;
            end if;
        end if;
    end process;
          
    P_Capture_Sync : process(RST, CLK) begin
        if (RST = '1') then
            cap_sync <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (ref_vld_d1 = '1') then
                if (ref_cap_window = '0') then        
                    cap_sync <= '0';
                else
                    if (ref_sub_frame_cnt = smart_length(12 downto 4) & "1000") then
                        cap_sync <= '1';
                    else
                        cap_sync <= '0';
                    end if;
                end if;
            end if;
        end if;
    end process;
			    
    P_Capture_Memory_Write_Enable : process(RST, CLK) begin
        if (RST = '1') then
            ref_cap_mem_we <= "0"; 
        elsif (CLK'event) and (CLK = '1') then
            if (cap_section = '0') then
                ref_cap_mem_we <= "0"; 
            else
                ref_cap_mem_we <= "1"; 
            end if;
        end if;
    end process;

    U_Power_N_Magnitude_Measure : PWR_N_MAG_MEASURE 
    generic map(
        DEVICE            => DEVICE            ,
        HOVS              => HOVS                
        )
    port map(
        CLK               => CLK               , 
    
        SAMPLE_VLD_IN     => ref_vld_d1        , 
        SAMPLE_I_IN       => REF_I_IN          , 
        SAMPLE_Q_IN       => REF_Q_IN          , 
    
        MEASURE_SYNC_IN   => cap_sync          , 
        MEASURE_EN_IN     => ref_cap_window    , 
        MEASURE_LENGTH_IN => CAP_SIZE_SEL_IN   , 
    
        MEASURED_PWR_OUT  => measured_power    ,
        MEASURED_MAG_OUT  => measured_magnitude 
        );

    P_Current_Power_N_Magnitude : process(RST, CLK) begin
        if (RST = '1') then
            current_magnitude    <= (others => '0');       
            current_power        <= (others => '0');       
        elsif (CLK'event) and (CLK = '1') then
            if (ref_sub_frame_cnt = smart_length(12 downto 4)&"0011") then
                current_power <= measured_power;    
            end if;

            if (ref_sub_frame_cnt = '0'&x"000") then
                current_magnitude <= (others => '0'); -- Current Peak clear at new subframe   
            elsif (ref_sub_frame_cnt > smart_length(12 downto 4)&"0010") then
                current_magnitude <= current_magnitude; 
            else
                if (current_magnitude < measured_magnitude) then 
                    current_magnitude <= measured_magnitude; 
                end if;
            end if;
        end if;
    end process;

    P_Max_Peak_N_Power : process(RST, CLK) begin
        if (RST = '1') then
            max_peak <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (cap_section_rpls = '1') then 
                max_peak <= (others => '0');
            else
                if (ref_sub_frame_cnt = smart_length(12 downto 4)&"0011") then
                    if ((disable_strobe = '0') and (max_peak < current_magnitude)) then --  max_peak < current_magnitude
                        max_peak <= current_magnitude;
                    end if;
                end if;
            end if;
        end if;
    end process;


    -- MAX_PEAK_p5dB = (MAX_PEAK x 0x7800)/2^15 = 0.9375 = 15/16, 0.28 dB
    U_MAX_PEAK_p5dB_Back_Off : BO_GAIN_CALCULATOR generic map(DEVICE) port map(CLK, max_peak         , MAX_PEAK_BO_GAIN_IN, max_peak_p5db_bo_value);        
    -- CUR_PEAK_p5 = (MAX_PEAK x 0x7000)/2^15 = 0.875  =  7/8,  0.57 dB                                           
    U_CUR_PEAK_p5_Back_Off   : BO_GAIN_CALCULATOR generic map(DEVICE) port map(CLK, current_magnitude, CUR_PEAK_BO_GAIN_IN, cur_peak_p5_bo_value  );        

    P_Compare_Start_Flag : process(RST, CLK) begin
        if (RST = '1') then
            compare_pls <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (ref_vld_d1 = '1') then
                if (ref_sub_frame_cnt = smart_length(12 downto 4)&"1011") then
                    compare_pls <= '1';
                else
                    compare_pls <= '0';
                end if;
            end if;
        end if;
    end process;

    P_Latch_Start_Flag : process(RST, CLK) begin
        if (RST = '1') then
            latch_pls <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (ref_vld_d1 = '1') then
                if (static_capture_section = '0') then
                    if (ref_sub_frame_cnt = smart_length(12 downto 4)&"1100") then
                        latch_pls <= '1';
                    else
                        latch_pls <= '0';
                    end if;
                else
                    latch_pls <= '0';
                end if;
            end if;
        end if;
    end process;

    P_Pre_Status_Update : process(RST, CLK) begin
        if (RST = '1') then
            pre_current_power     <= (others => '0');      
            pre_current_magnitude <= (others => '0');      
            sub_frame_num         <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (cap_section_rpls = '1') then 
                pre_current_power     <= (others => '0');      
                pre_current_magnitude <= (others => '0');      
                sub_frame_num         <= (others => '0');
            else
                if (sc_captured_section = '1') then 
                    pre_current_power     <= current_power     ;      
                    pre_current_magnitude <= current_magnitude ;      
                    sub_frame_num         <= sub_frame_cnt_d1  ;
                end if;
            end if;
        end if;
    end process;

    P_Status_Latch : process(RST, CLK) begin
        if (RST = '1') then
            capture_control_en_d1      <= '0';                      
            capture_control_en_rpls    <= '0';                      

            pre_current_power_lat      <= (others => '0'); 
            pre_current_magnitude_lat  <= (others => '0'); 
            sub_frame_num_lat          <= (others => '0'); 
        elsif (CLK'event) and (CLK = '1') then
            capture_control_en_d1   <= CAPTURE_CONTROL_EN_IN;                      
            capture_control_en_rpls <= CAPTURE_CONTROL_EN_IN and (not capture_control_en_d1);                      

            if ((CAPTURE_CONTROL_EN_IN = '1') and (cap_done_pls = '1')) then
                pre_current_power_lat      <= pre_current_power    ; 
                pre_current_magnitude_lat  <= pre_current_magnitude; 
                sub_frame_num_lat          <= sub_frame_num        ; 
            elsif (capture_control_en_rpls = '1') then
                pre_current_power_lat      <= (others => '0'); 
                pre_current_magnitude_lat  <= (others => '0'); 
                sub_frame_num_lat          <= (others => '0'); 
            end if;
        end if;
    end process;

    CAP_FRAME_NUM_OUT  <= sub_frame_num_lat;        
    CAP_FRAME_PEAK_OUT <= pre_current_magnitude_lat;   
    CAP_FRAME_PWR_OUT  <= pre_current_power_lat;            

    U_COMPARE_CUR_POWER     : UNSIGNED_COMPARE generic map(32, 16) port map(RST, CLK, pre_current_power     , current_power       , compare_curpwr_flg );  
    U_COMPARE_CUR_MAGNITUDE : UNSIGNED_COMPARE generic map(32, 16) port map(RST, CLK, max_peak_p5db_bo_value, current_magnitude   , compare_curmag_flg );  
    U_COMPARE_CUR_PEAK      : UNSIGNED_COMPARE generic map(32, 16) port map(RST, CLK, pre_current_magnitude , cur_peak_p5_bo_value, compare_curpeak_flg);  

    P_Capture_Condition : process(RST, CLK) begin
        if (RST = '1') then
            cap_condition_0 <= '0';           
            cap_condition_1 <= '0';           
            cap_condition_2 <= '0';           
        elsif (CLK'event) and (CLK = '1') then
            if (ref_vld_d1 = '1') then
                if (compare_pls = '1') then
                    if (compare_curpwr_flg = '0') then -- current_power >= pre_current_power 
                        cap_condition_0 <= '1';           
                    else
                        cap_condition_0 <= '0';           
                    end if;

                    if (compare_curmag_flg = '0') then -- current_magnitude >= max_peak_p5db_bo_value 
                        cap_condition_1 <= '1';           
                    else
                        cap_condition_1 <= '0';           
                    end if;

                    if (compare_curpeak_flg = '0') then -- cur_peak_p5_bo_value >= pre_current_magnitude
                        cap_condition_2 <= '1';           
                    else
                        cap_condition_2 <= '0';           
                    end if;
                end if;
            end if;
        end if;
    end process;

    P_Capture_Case : process(RST, CLK) begin
        if (RST = '1') then
            capture_case1 <= '0'; 
            capture_case2 <= '0'; 
        elsif (CLK'event) and (CLK = '1') then
            if (ref_vld_d1 = '1') then
                if (latch_pls = '1') then 
                    if ((cap_condition_0 = '1') and (cap_condition_1 = '1')) then
                        capture_case1 <= '1'; 
                    else
                        capture_case1 <= '0'; 
                    end if;

                    if (cap_condition_2 = '1') then
                        capture_case2 <= '1'; 
                    else
                        capture_case2 <= '0'; 
                    end if;
                else
                    capture_case1 <= '0'; 
                    capture_case2 <= '0'; 
                end if;
            end if;
        end if;
    end process;

    P_Smart_Captured_Section : process(RST, CLK) begin
        if (RST = '1') then
            sc_captured_section <= '0'; 
        elsif (CLK'event) and (CLK = '1') then
            if (disable_strobe = '0') then
                if ((capture_case1 = '1') or (capture_case2 = '1')) then
                    sc_captured_section <= '1'; 
                else
                    sc_captured_section <= '0'; 
                end if;
            else
                sc_captured_section <= '0'; 
            end if;
        end if;
    end process;

    CAP_CONDITION_PLS_OUT <= sc_captured_section;

    ref_sample_qi <= REF_Q_IN & REF_I_IN;

    U_SC_CORE_Delay_Compensator : BUF_SAMPLE_DLY generic map("BLOCK", "SAMPLE_RATE", 32, 5) port map(RST, CLK, "01010", ref_vld_d1, ref_sample_qi, ref_sample_delayed_qi);  

    P_Clock_Align : process(RST, CLK) begin
        if (RST = '1') then
            CAP_REF_WREN_OUT <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            CAP_REF_WREN_OUT   <= ref_cap_mem_we;
        end if;
    end process;

    CAP_REF_WRADDR_OUT <= ref_wraddr;
    CAP_REF_WRDATA_OUT <= ref_sample_delayed_qi;

end arc_SMART_CAPTURE_CORE;
