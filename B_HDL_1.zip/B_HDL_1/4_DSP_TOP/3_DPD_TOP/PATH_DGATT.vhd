-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name : PATH_DGATT 
-- Project    : 

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity PATH_DGATT is
generic(
    DEVICE         : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    RND_BIT        : natural :=       15 ;
    HOVS           : natural :=        1
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;

    DATA_VALID_IN  : in  std_logic;
    DATA_I_IN      : in  std_logic_vector(15 downto 0);
    DATA_Q_IN      : in  std_logic_vector(15 downto 0);

    DGATT_VAL      : in  std_logic_vector(15 downto 0);

    DATA_VALID_OUT : out std_logic;
    DATA_I_OUT     : out std_logic_vector(15 downto 0);
    DATA_Q_OUT     : out std_logic_vector(15 downto 0)
    );
end PATH_DGATT;

architecture arc_PATH_DGATT of PATH_DGATT is

component RST_SYNC is
generic(
    DLY_NUM        : natural := 3;    -- Number of delay.
    MAX_FANOUT_NUM : integer := 200   -- Number of maximum fanout
    );
port(
    RST_IN         : in  std_logic;          -- Active high asynchronous reset
    CLK            : in  std_logic;          -- clock to be sync'ed to
    RST_OUT        : out std_logic           -- "Synchronised" reset signal
    );         
end component;

component DSP48E1_MULTIPLIER is
generic(
    AIN_BITWIDTH   : natural; -- AIN bitwidth : 0 to 29
    BIN_BITWIDTH   : natural; -- BIN bitwidth : 0 to 17
    RND_EN         : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT        : natural; -- Rounding bit  
    OUTPUT_WIDTH   : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;
    AIN            : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
    BIN            : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
    P              : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
    );
end component;

component DSP48E2_MULTIPLIER is
generic(
    AIN_BITWIDTH   : natural; -- AIN bitwidth : 0 to 29
    BIN_BITWIDTH   : natural; -- BIN bitwidth : 0 to 17
    RND_EN         : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT        : natural; -- Rounding bit  
    OUTPUT_WIDTH   : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;
    AIN            : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
    BIN            : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
    P              : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
    );
end component;

component SAT_SIGN is
generic(
    HS_MODE        : boolean := TRUE;
    INPUT_BIT      : natural;
    OUTPUT_BIT     : natural
    );
port( 
    RST            : in  std_logic;
    CLK            : in  std_logic;
    DATA_IN        : in  std_logic_vector(INPUT_BIT-1  downto 0);
    DATA_OUT       : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

signal rst_synch       : std_logic;

signal se_atten_val   : std_logic_vector(16 downto 0);

signal se_data_i      : std_logic_vector(16 downto 0);
signal se_data_q      : std_logic_vector(16 downto 0);

signal rnd_i          : std_logic_vector(17 downto 0) := (others=>'0');
signal rnd_q          : std_logic_vector(17 downto 0) := (others=>'0');

signal data_iq_mux    : std_logic_vector(16 downto 0);
signal rnd            : std_logic_vector(17 downto 0);
signal sat            : std_logic_vector(15 downto 0);
signal sat_i          : std_logic_vector(15 downto 0);
signal sat_q          : std_logic_vector(15 downto 0);

signal data_out_i     : std_logic_vector(15 downto 0) := (others=>'0');
signal data_out_q     : std_logic_vector(15 downto 0) := (others=>'0');

begin

    U_RST_SYNC : RST_SYNC generic map(4, 200) port map(RST, CLK, rst_synch); 

    -- Sign Extention
    se_atten_val     <= '0' & DGATT_VAL;

    G_HOVS1 : if (HOVS = 1) generate begin
        se_data_i    <= DATA_I_IN(15)& DATA_I_IN;
        se_data_q    <= DATA_Q_IN(15)& DATA_Q_IN;

        G_7Series_DSP48E1 : if (DEVICE = "7SERIES") generate begin
            U_DSP48E1_I_Multiple : DSP48E1_MULTIPLIER generic map(17,17,TRUE,RND_BIT,18) port map(rst_synch, CLK, se_atten_val, se_data_i, rnd_i);
            U_DSP48E1_Q_Multiple : DSP48E1_MULTIPLIER generic map(17,17,TRUE,RND_BIT,18) port map(rst_synch, CLK, se_atten_val, se_data_q, rnd_q);
        end generate;

        G_UltraScale_DSP48E2 : if (DEVICE = "ULTRASCALE") generate begin
            U_DSP48E2_I_Multiple : DSP48E2_MULTIPLIER generic map(17,17,TRUE,RND_BIT,18) port map(rst_synch, CLK, se_atten_val, se_data_i, rnd_i);
            U_DSP48E2_Q_Multiple : DSP48E2_MULTIPLIER generic map(17,17,TRUE,RND_BIT,18) port map(rst_synch, CLK, se_atten_val, se_data_q, rnd_q);
        end generate;

        U_SAT_I      : SAT_SIGN generic map(TRUE, 18, 16) port map(rst_synch, CLK, rnd_i, data_out_i);
        U_SAT_Q      : SAT_SIGN generic map(TRUE, 18, 16) port map(rst_synch, CLK, rnd_q, data_out_q);

        data_iq_mux    <= (others => '0');
        rnd            <= (others => '0');
        sat            <= (others => '0'); 
        sat_i          <= (others => '0');
        sat_q          <= (others => '0');

        DATA_VALID_OUT <= DATA_VALID_IN;

    end generate;

    G_HOVS2 : if (HOVS = 2) generate begin

        rnd_i <= (others => '0');         
        rnd_q <= (others => '0');         

        P_Align : process(rst_synch, CLK) begin
            if (rst_synch = '1') then
                se_data_i <= (others => '0');
                se_data_q <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                if (DATA_VALID_IN = '1') then            
                    se_data_i <= DATA_I_IN(15)& DATA_I_IN;
                    se_data_q <= DATA_Q_IN(15)& DATA_Q_IN;
                else
                    se_data_i <= se_data_i;
                    se_data_q <= se_data_q;
                end if;
            end if;
        end process;

        P_IQ_Time_MUX : process(rst_synch, CLK) begin
            if (rst_synch = '1') then
                data_iq_mux <= (others => '0'); 
            elsif (CLK'event) and (CLK = '1') then
                if (DATA_VALID_IN = '0') then
                    data_iq_mux <= se_data_i; 
                else
                    data_iq_mux <= se_data_q; 
                end if;
            end if;
        end process;

        G_7Series_DSP48E1 : if (DEVICE = "7SERIES") generate begin
            U_DSP48E1_Multiple : DSP48E1_MULTIPLIER generic map(17,17,TRUE,RND_BIT,18) port map(rst_synch, CLK, se_atten_val, data_iq_mux, rnd);
        end generate;

        G_UltraScale_DSP48E2 : if (DEVICE = "ULTRASCALE") generate begin
            U_DSP48E2_Multiple : DSP48E2_MULTIPLIER generic map(17,17,TRUE,RND_BIT,18) port map(rst_synch, CLK, se_atten_val, data_iq_mux, rnd);
        end generate;

        U_SAT : SAT_SIGN   generic map(FALSE, 18, 16) port map(rst_synch, CLK, rnd, sat);

        P_Saturation_IQ_Align : process(rst_synch, CLK) begin
            if (rst_synch = '1') then
                sat_i <= (others => '0');
                sat_q <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                if (DATA_VALID_IN = '1') then
                    sat_i <= sat;
                    sat_q <= sat_q;
                else
                    sat_i <= sat_i;
                    sat_q <= sat;
                end if;
            end if;
        end process;

        P_Output_IQ_Align : process(rst_synch, CLK) begin
            if (rst_synch = '1') then
                data_out_i <= (others => '0');
                data_out_q <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                DATA_VALID_OUT <= DATA_VALID_IN;

                if (DATA_VALID_IN = '1') then
                    data_out_i <= sat_i;
                    data_out_q <= sat_q;
                else        
                    data_out_i <= data_out_i;
                    data_out_q <= data_out_q;
                end if;
            end if;
        end process;
    end generate;

    DATA_I_OUT <= data_out_i;
    DATA_Q_OUT <= data_out_q;

end arc_PATH_DGATT;
  
    


