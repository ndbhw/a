library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity PIMD_BLK is
generic(    
    DEVICE                       : string  := "ULTRASCALE";
   
    TX_ANT_NUM                   : natural :=           4 ;
    RX_ANT_NUM                   : natural :=           4 ;

    PIMD_BLK_TYPE                : string  :=      "INTER"; -- "INTER" or "INTRA"
    PIM_SRC_NUM                  : natural :=           2 ; -- B2 : 3, B66 : 2

    PIMD_OPR_CLK_RATE            : real    :=      245.76 ;
    PIMD_UL_CLK_RATE             : real    :=      245.76 ;
    PIMD_OPR_SAMPLE_RATE         : real    :=      245.76 ;
    PIMD_INTER_REF_SAMPLE_RATE   : real    :=      122.88 ;
    PIMD_ULINPUT_SAMPLE_RATE     : real    :=      122.88 ;
    PIMD_ULOUTPUT_SAMPLE_RATE    : real    :=      122.88 ;

    PIMD_CORE_LUT_OPTIMIZED      : boolean :=        TRUE ;
    PIMD_CORE_LUT_MEM_DEPTH      : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    PIMD_CORE_LUT_RBTEST         : boolean :=        TRUE ; 
    PIMD_CORE_QPOINT_SEL         : boolean :=        TRUE ; -- TRUE : PIMD_CORE Qpoint Selectable     FALSE : PIMD_CORE Qpoint Fixed
    PIMD_CORE_LUT_DIMENSION      : string  :=         "2D"; -- "2D" or "3D"
    PIMD_CORE_LUT_NUM            : natural :=          20 ;
    PIMD_CORE_TAP_NUM            : natural :=          10 
    );
port(
    RST_PIMD                     : in  std_logic;        -- Reset, Active High
    RST_CPU                      : in  std_logic;

    CLK_PIMD                     : in  std_logic;
    CLK_UL                       : in  std_logic;
    CLK_CPU                      : in  std_logic;


    INT_SYSPLL_LOCK_IN           : in  std_logic;

    DL_PIM_REF_VLD_IN            : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PIM Reference Source Valid,    DL Mixer Output
    DL_PIM_REF_I_IN              : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- PIM Reference Source I sample, DL Mixer Output
    DL_PIM_REF_Q_IN              : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- PIM Reference Source Q sample, DL Mixer Output

    DL_PIM_INTERBAND_VLD_IN      : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PIM Reference Source Valid,    DL Mixer Output
    DL_PIM_INTERBAND_I_IN        : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- PIM Reference Source I sample, DL Mixer Output
    DL_PIM_INTERBAND_Q_IN        : in  std_logic_array16(TX_ANT_NUM-1 downto 0); -- PIM Reference Source Q sample, DL Mixer Output

    UL_PIM_TGT_VLD_IN            : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM Target Source Valid,       UL DCIF Output
    UL_PIM_TGT_I_IN              : in  std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Target Source I sample,    UL DCIF Output
    UL_PIM_TGT_Q_IN              : in  std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Target Source Q sample,    UL DCIF Output

    UL_PIMD_VLD_OUT              : out std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM Rejected Valid,            UL DDC Input
    UL_PIMD_I_OUT                : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Rejected I sample,         UL DDC Input
    UL_PIMD_Q_OUT                : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Rejected Q sample,         UL DDC Input

    UL_PIM_SC_ERR_I_OUT          : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Error Source I sample,             SC Input
    UL_PIM_SC_ERR_Q_OUT          : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Error Source Q sample,             SC Input

    UL_PIM_SC_TGT_I_OUT          : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Target Source I sample,            SC Input
    UL_PIM_SC_TGT_Q_OUT          : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM Target Source Q sample,            SC Input

    UL_PIM_INTERB_DUCDLY_I_OUT   : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM InterBand DUC_DLY Source I sample, SC Input
    UL_PIM_INTERB_DUCDLY_Q_OUT   : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM InterBand DUC_DLY Source Q sample, SC Input

    UL_PIM_SC_CFR_I_OUT          : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM CFR Source I sample,               SC Input
    UL_PIM_SC_CFR_Q_OUT          : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM CFR Source Q sample,               SC Input

    UL_PIM_SC_3RD_IM_I_OUT       : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM 3rd IM Mixer Source I sample,      SC Input
    UL_PIM_SC_3RD_IM_Q_OUT       : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM 3rd IM Mixer Source Q sample,      SC Input

    UL_PIM_SC_DBG_I_OUT          : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM 3rd IM Mixer Source I sample,      SC Input
    UL_PIM_SC_DBG_Q_OUT          : out std_logic_array16(RX_ANT_NUM-1 downto 0); -- PIM 3rd IM Mixer Source Q sample,      SC Input

    DBG_PIM_MIXPS_I_OUT          : out std_logic_array16(TX_ANT_NUM-1 downto 0); -- for Debug
    DBG_PIM_MIXPS_Q_OUT          : out std_logic_array16(TX_ANT_NUM-1 downto 0); -- for Debug

    PIM_SC_INTER_PIM_DBG_SEL_IN  : in  std_logic_vector( 1 downto 0);
    PIM_SC_INTRA_PIM_DBG_SEL_IN  : in  std_logic_vector( 1 downto 0);

    PIM_DETECTOR_ON_IN           : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- UL PIM Detect On
    PIM_MITIGATOR_ON_IN          : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- UL PIM Detect On
 
    PIM_CFR_REF_SEL_IN           : in  std_logic_vector( RX_ANT_NUM-1 downto 0);

    PIM_CORE_BYPASS_IN           : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PIM Core Bypass

    PIM_GAIN_INDEX_IN            : in  std_logic_array2( TX_ANT_NUM-1 downto 0); -- Input Signal Gain, x1/x2/x4
    PIM_QPOINT_SEL_IN            : in  std_logic_array2( TX_ANT_NUM-1 downto 0); -- PIM Core Binary Point Selection

    PIM_LUT_RB_TEST_EN_IN        : in  std_logic;                                -- LUT Read Back Test

    PIM_LUT_SWITCH_CDC_STRB_IN   : in  std_logic;                                -- LUT Switch Control Register CDC Strobe
    PIM_LUT_INPUT_SWITCH_IN      : in  std_logic_vector(19 downto 0);            -- LUT Input Mux Control
    PIM_LUT_OUTPUT_SWITCH_IN     : in  std_logic_vector(19 downto 0);            -- LUT Output Switch Control

    PIM_LUT_UPDATE_SW_IN         : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- LUT Update Switch
    PIM_LUT_WREN_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- LUT Write Enable
    PIM_LUT_RDEN_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- LUT Read  Enable
    PIM_LUT_ADDR_IN              : in  std_logic_array15(TX_ANT_NUM-1 downto 0); -- LUT Depth & LUT Address
    PIM_LUT_WDATA_IN             : in  std_logic_array32(TX_ANT_NUM-1 downto 0); -- LUT Write IQ : I[31:16]/Q[15:0]
    PIM_LUT_RDATA_OUT            : out std_logic_array32(TX_ANT_NUM-1 downto 0); -- LUT Write IQ : I[31:16]/Q[15:0]

    PIM_CORE_COEF_WR_EN_IN       : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PIM Core coefficient write enable(indirect)
    PIM_CORE_COEF_RD_EN_IN       : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PIM Core coefficient read  enable(indirect)
    PIM_CORE_COEF_WR_DN_IN       : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PIM Core coefficient write done(indirect)
    PIM_CORE_COEF_ADDR_IN        : in  std_logic_vector( 3 downto 0);            -- PIM Core coefficient write address
    PIM_CORE_COEF_I_WDATA_IN     : in  std_logic_vector(20 downto 0);            -- PIM Core coefficient write data(indirect) 
    PIM_CORE_COEF_Q_WDATA_IN     : in  std_logic_vector(20 downto 0);            -- PIM Core coefficient write data(indirect) 
    PIM_CORE_COEF_I_RDATA_OUT    : out std_logic_vector(20 downto 0);            -- PIM Core coefficient read  data(indirect) 
    PIM_CORE_COEF_Q_RDATA_OUT    : out std_logic_vector(20 downto 0);            -- PIM Core coefficient read  data(indirect) 

    PIM_FILTER_BYPASS_IN         : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- PA Protection Filter Bypass
    PIM_FILTER_COEF_WR_EN_IN     : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- coefficient write enable(indirect)
    PIM_FILTER_COEF_RD_EN_IN     : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- coefficient read  enable(indirect)
    PIM_FILTER_COEF_WR_DN_IN     : in  std_logic_vector( TX_ANT_NUM-1 downto 0); -- coefficient write done(indirect)
    PIM_FILTER_COEF_ADDR_IN      : in  std_logic_vector( 7 downto 0);            -- coefficient write address
    PIM_FILTER_COEF_WR_DATA_IN   : in  std_logic_vector(15 downto 0);            -- coefficient write data(indirect) 
    PIM_FILTER_COEF_RD_DATA_OUT  : out std_logic_vector(15 downto 0);            -- coefficient read  data(indirect) 

    PIM_INTERBAND_DUC_GAIN_IN    : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    PIM_NCO_WREN_IN              : in  std_logic;
    PIM_NCO_WORD_IN              : in  std_logic_vector(31 downto 0);

    -- selectable pim
    PIM_SLTB1_GAIN_INDEX_IN      : in  std_logic_array2( TX_ANT_NUM-1 downto 0);
    PIM_SLTB1_QPOINT_SEL_IN      : in  std_logic_array2( TX_ANT_NUM-1 downto 0);
    PIMDLY_SLTB1_VALUE_IN        : in  std_logic_array12(TX_ANT_NUM-1 downto 0);           

    PIM_SLTB1_LUT_UPDATE_SW_IN   : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB1_LUT_WREN_IN        : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    PIM_SLTB1_LUT_RDEN_IN        : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Read  Enable
    PIM_SLTB1_LUT_ADDR_IN        : in  std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
    PIM_SLTB1_LUT_WDATA_IN       : in  std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    PIM_SLTB1_LUT_RDATA_OUT      : out std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    
    PIM_SLTB2_GAIN_INDEX_IN      : in  std_logic_array2( TX_ANT_NUM-1 downto 0);
    PIM_SLTB2_QPOINT_SEL_IN      : in  std_logic_array2( TX_ANT_NUM-1 downto 0);
    PIMDLY_SLTB2_VALUE_IN        : in  std_logic_array12(TX_ANT_NUM-1 downto 0);          

    PIM_SLTB2_LUT_UPDATE_SW_IN   : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_SLTB2_LUT_WREN_IN        : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    PIM_SLTB2_LUT_RDEN_IN        : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Read  Enable
    PIM_SLTB2_LUT_ADDR_IN        : in  std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
    PIM_SLTB2_LUT_WDATA_IN       : in  std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    PIM_SLTB2_LUT_RDATA_OUT      : out std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]

    PIM_SLTB_INTRA_NCO_WREN_IN   : in  std_logic;
    PIM_SLTB_INTRA_NCO_WORD_IN   : in  std_logic_vector(31 downto 0);
    PIM_SLTB_INTER1_NCO_WREN_IN  : in  std_logic;
    PIM_SLTB_INTER1_NCO_WORD_IN  : in  std_logic_vector(31 downto 0);
    PIM_SLTB_INTER2_NCO_WREN_IN  : in  std_logic;
    PIM_SLTB_INTER2_NCO_WORD_IN  : in  std_logic_vector(31 downto 0);

    -- INTRA_BAND_SEL_IN                         : in  std_logic; 
    -- INTER_BAND_TYPE1_SEL_IN                   : in  std_logic_vector(1 downto 0);
    -- INTER_BAND_TYPE2_SEL_IN                   : in  std_logic_vector(1 downto 0);
	INTRA_BAND_SEL_IN                         : in  std_logic_vector(TX_ANT_NUM-1 downto 0);
    INTER_BAND_TYPE1_SEL_IN                   : in  std_logic_array2(TX_ANT_NUM-1 downto 0);
    INTER_BAND_TYPE2_SEL_IN                   : in  std_logic_array2(TX_ANT_NUM-1 downto 0);
    
    PIM_BIT_SHIFT_SEL_IN         : in  std_logic_vector(1 downto 0);

    SHIFT_DIRECTION_INTRA_IN     : in  std_logic_array2(TX_ANT_NUM-1 downto 0);
    SHIFT_DIRECTION_INTER1_IN    : in  std_logic_array2(TX_ANT_NUM-1 downto 0);
    SHIFT_DIRECTION_INTER2_IN    : in  std_logic_array2(TX_ANT_NUM-1 downto 0);
    ----
    DL_INTRAB_DLY_VALUE_IN       : in  std_logic_array12(TX_ANT_NUM-1 downto 0);           
    DL_INTERB_CDLY_VALUE_IN      : in  std_logic_array11(TX_ANT_NUM-1 downto 0);           
    DL_INTERB_FDLY_VALUE_IN      : in  std_logic_array4( TX_ANT_NUM-1 downto 0);           
    PIMDLY_VALUE_IN              : in  std_logic_array12(TX_ANT_NUM-1 downto 0);     

    PNPC_SEL_IN                  : in  std_logic_array2( RX_ANT_NUM-1 downto 0);
    PNPC_EN_IN                   : in  std_logic_vector( RX_ANT_NUM-1 downto 0); 
    PNPC_SET_IN                  : in  std_logic_vector( RX_ANT_NUM-1 downto 0); 
    PNPC_MU_SEL_IN               : in  std_logic_array2( RX_ANT_NUM-1 downto 0); 
    PNPC_SETVAL_I_IN             : in  std_logic_array16(RX_ANT_NUM-1 downto 0); 
    PNPC_SETVAL_Q_IN             : in  std_logic_array16(RX_ANT_NUM-1 downto 0); 

    PNPC_TP_DC_IQ_OUT            : out std_logic_array32(RX_ANT_NUM-1 downto 0); 

    UL_PIM_NCO_WREN_IN           : in  std_logic;
    UL_PIM_NCO_WORD_IN           : in  std_logic_vector(31 downto 0);

    UL_PIM_FREQ_COMP_WORD_IN     : in  std_logic_vector(31 downto 0) 
    );
end PIMD_BLK;

architecture arc_PIMD_BLK of PIMD_BLK is
-- ******************************
-- Type                        
-- ******************************

-- ******************************
-- Constants                   
-- ******************************
constant pimref_hovs             : natural := natural(PIMD_OPR_CLK_RATE/PIMD_OPR_SAMPLE_RATE);                  
constant interband_upsamp_ratio  : natural := natural(PIMD_INTER_REF_SAMPLE_RATE/PIMD_OPR_SAMPLE_RATE);         
constant pimref_nco_symmetry     : boolean := ternary_func((PIMD_BLK_TYPE = "INTRA"), TRUE, FALSE);         
constant pimref_nco_resolution   : natural := natural(PIMD_OPR_SAMPLE_RATE*250.00);         
constant ul_nco_resolution       : natural := natural(PIMD_OPR_SAMPLE_RATE*250.00);         

constant ul_input_upsamp_ratio   : natural := natural(PIMD_OPR_SAMPLE_RATE/PIMD_ULINPUT_SAMPLE_RATE);         
constant ul_output_dnsamp_ratio  : natural := natural(PIMD_OPR_SAMPLE_RATE/PIMD_ULOUTPUT_SAMPLE_RATE);         
constant ul_inout_ratio          : natural := natural(PIMD_ULOUTPUT_SAMPLE_RATE/PIMD_ULINPUT_SAMPLE_RATE);         

constant interb_duc_gain_rnd_bit : natural := ternary_func((PIM_SRC_NUM = 3), 11, 13);                  
constant interb_duc_gain_hovs    : natural := natural(PIMD_UL_CLK_RATE/PIMD_INTER_REF_SAMPLE_RATE);  
constant C_SELECTABLE_TYPE       : natural := 2;

-- ******************************
-- Components                     
-- ******************************

component RST_SYNC is
generic(
    DLY_NUM                      : natural := 3;    -- Number of delay.
    MAX_FANOUT_NUM               : integer := 200   -- Number of maximum fanout
    );
port(
    RST_IN                       : in  std_logic;   -- Active high asynchronous reset
    CLK                          : in  std_logic;   -- clock to be sync'ed to
    RST_OUT                      : out std_logic    -- "Synchronised" reset signal
    );         
end component;

component CE_CLR_GEN is
port(
    RST                          : in  std_logic;
    TRAFFIC_PLL_LOCK_IN          : in  std_logic;
    CLK                          : in  std_logic; -- DSP clock

    MDL_CE_CLR_OUT               : out std_logic;
    MDL_SYNC_RST_OUT             : out std_logic
    );
end component;
component SRL16E_WRAP is
generic(
    DEVICE    : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    BIT_WIDTH : natural
    );
port(
    CLK       : in  std_logic;
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    SEL_DLY   : in  std_logic_vector( 3 downto 0);         -- Select Delay, 0 ~ 15 => 0 ~ 15 clk delay
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0) -- Delayed DATA
    );
end component;

component DPD_CORE is
generic(
    DEVICE                       : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
   
    TX_ANT_NUM                   : natural :=           4 ;
    HOVS                         : natural :=           1 ; 

    DPD_LUT_OPTIMIZED            : boolean :=       FALSE ;
    DPD_LUT_MEM_DEPTH            : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    DPD_LUT_RBTEST               : boolean :=        TRUE ;
    DPD_CORE_QPOINT_SEL          : boolean :=       FALSE ;
    DPD_CORE_LUT_DIMENSION       : string  :=         "2D"; -- "2D" or "3D"
    DPD_CORE_LUT_NUM             : natural :=          16 ;
    DPD_CORE_TAP_NUM             : natural :=           8 ; 
    DPD_CORE_RND_BIT             : natural :=          13 
    );
port(
    RST_DPD                      : in  std_logic;
    CLK_DPD                      : in  std_logic;

    DPD_CORE_VLD_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- DPD Core Input Sample Valid
    DPD_CORE_I_IN                : in  std_logic_array16(TX_ANT_NUM-1 downto 0);        -- DPD Core Input I Sample 
    DPD_CORE_Q_IN                : in  std_logic_array16(TX_ANT_NUM-1 downto 0);        -- DPD Core Input Q Sample 

    DPD_CORE_VLD_OUT             : out std_logic_vector( TX_ANT_NUM-1 downto 0);        -- DPD Core Output Sample Valid
    DPD_CORE_I_OUT               : out std_logic_array16(TX_ANT_NUM-1 downto 0);        -- DPD Core Output I Sample 
    DPD_CORE_Q_OUT               : out std_logic_array16(TX_ANT_NUM-1 downto 0);        -- DPD Core Output Q Sample 

    DPD_CORE_BYPASS_IN           : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- DPD Core Bypass

    DPD_GAIN_INDEX_IN            : in  std_logic_array2( TX_ANT_NUM-1 downto 0);        -- Input Signal Gain, x1/x2/x4
    DPD_QPOINT_SEL_IN            : in  std_logic_array2( TX_ANT_NUM-1 downto 0);        -- DPD Core Binary Point Selection

    RST_CPU                      : in  std_logic;
    CLK_CPU                      : in  std_logic;

    DPD_LUT_RB_TEST_EN_IN        : in  std_logic;                                       -- LUT Read Back Test

    DPD_LUT_SWITCH_CDC_STRB_IN   : in  std_logic;                                       -- LUT Switch Control Register CDC Strobe
    DPD_LUT_INPUT_SWITCH_IN      : in  std_logic_vector(19 downto 0);                   -- LUT Input Mux Control
    DPD_LUT_OUTPUT_SWITCH_IN     : in  std_logic_vector(19 downto 0);                   -- LUT Output Switch Control

    DPD_LUT_UPDATE_SW_IN         : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_LUT_WREN_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Write Enable
    DPD_LUT_RDEN_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);        -- LUT Read  Enable
    DPD_LUT_ADDR_IN              : in  std_logic_array15(TX_ANT_NUM-1 downto 0);        -- LUT Depth & LUT Address
    DPD_LUT_WDATA_IN             : in  std_logic_array32(TX_ANT_NUM-1 downto 0);        -- LUT Write IQ : I[31:16]/Q[15:0]
    DPD_LUT_RDATA_OUT            : out std_logic_array32(TX_ANT_NUM-1 downto 0)         -- LUT Write IQ : I[31:16]/Q[15:0]
    );
end component;

component PATH_DGATT is
generic(
    DEVICE                       : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    RND_BIT                      : natural :=       15 ;
    HOVS                         : natural :=        1
    );
port(
    RST                          : in  std_logic;
    CLK                          : in  std_logic;

    DATA_VALID_IN                : in  std_logic;
    DATA_I_IN                    : in  std_logic_vector(15 downto 0);
    DATA_Q_IN                    : in  std_logic_vector(15 downto 0);

    DGATT_VAL                    : in  std_logic_vector(15 downto 0);

    DATA_VALID_OUT               : out std_logic;
    DATA_I_OUT                   : out std_logic_vector(15 downto 0);
    DATA_Q_OUT                   : out std_logic_vector(15 downto 0)
    );
end component;

component hbf_i_comm is
generic(
    HOVS                         : integer
    );
port(
    RST                          : in  std_logic;
    CLK                          : in  std_logic;

    INPUT_FRAME                  : in  std_logic;
    INPUT_VALID                  : in  std_logic;
    INPUT_DATA_I                 : in  std_logic_vector(15 downto 0);
    INPUT_DATA_Q                 : in  std_logic_vector(15 downto 0);

    OUTPUT_FRAME                 : out std_logic;
    OUTPUT_VALID                 : out std_logic;
    OUTPUT_DATA_I                : out std_logic_vector(15 downto 0);
    OUTPUT_DATA_Q                : out std_logic_vector(15 downto 0)
    );
end component;

component fir_i3_comm is
generic(
    ANT_NUM                      : integer:=  2;
    PASSBAND                     : integer:= 60
    );
port(
    RST_W                        : in  std_logic_vector(ANT_NUM-1 downto 0);
    RST_R                        : in  std_logic_vector(ANT_NUM-1 downto 0);
    CLK_W                        : in  std_logic;
    CLK_R                        : in  std_logic;

    DATA_IN_VALID                : in  std_logic;
    DATA_IN_I                    : in  std_logic_array16(ANT_NUM-1 downto 0);
    DATA_IN_Q                    : in  std_logic_array16(ANT_NUM-1 downto 0);

    BUF_COLLISION_FLAG           : out std_logic_vector(ANT_NUM-1 downto 0);
    DATA_OUT_VALID               : out std_logic_vector(ANT_NUM-1 downto 0);
    DATA_OUT_I                   : out std_logic_array16(ANT_NUM-1 downto 0);
    DATA_OUT_Q                   : out std_logic_array16(ANT_NUM-1 downto 0)
    );
end component;

component PIMD_SRC_PROC is
generic(
    DEVICE                       : string  := "ULTRASCALE";
    HOVS                         : natural :=           1 ;
   
    TX_ANT_NUM                   : natural :=           4 ;
    PIM_SRC_NUM                  : natural :=           2   -- B2 : 3, B66 : 2
    );
port(
    RST                          : in  std_logic;           -- Reset, Active High
    CLK                          : in  std_logic;

    PIM_CFR_REF_SEL_IN           : in  std_logic_vector( TX_ANT_NUM-1 downto 0); 

    PIM_CFR_REF_VLD_IN           : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_CFR_REF_I_IN             : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_CFR_REF_Q_IN             : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    PIM_INTERB_SRC_I_IN          : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_INTERB_SRC_Q_IN          : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    PIM_CFR_REF_VLD_OUT          : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_CFR_REF_I_OUT            : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_CFR_REF_Q_OUT            : out std_logic_array16(TX_ANT_NUM-1 downto 0);

    PIM_INTERB_SRC_I_OUT         : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_INTERB_SRC_Q_OUT         : out std_logic_array16(TX_ANT_NUM-1 downto 0) 
    );
end component;

component COMPLEX_MULTIPLIER is
generic(
    DEVICE                       : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HOVS                         : natural :=        1 ;

    INPUT_WIDTH                  : natural :=       16 ; -- AIN bitwidth : 0 to 29
    RND_EN                       : boolean :=     TRUE ; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT                      : natural :=       15 ; -- Rounding bit  
    OUTPUT_WIDTH                 : natural :=       16   -- Result bitwidth : 0 to 47
    );
port(
    RST                          : in  std_logic;
    CLK                          : in  std_logic;

    DATA_VLD_IN                  : in  std_logic;
    ADATA_I_IN                   : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    ADATA_Q_IN                   : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
                                                          
    BDATA_I_IN                   : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    BDATA_Q_IN                   : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
   
    DATA_VLD_OUT                 : out std_logic;
    DATA_I_OUT                   : out std_logic_vector(OUTPUT_WIDTH-1 downto 0);
    DATA_Q_OUT                   : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
end component;

component SRL16E_DLY is
generic(
    DEVICE                       : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HS_MODE                      : boolean :=        TRUE ;

    BIT_WIDTH                    : natural;
    DELAY_NUM                    : natural
    );
port(
    RST                          : in  std_logic;
    CLK                          : in  std_logic;
    DATA_IN                      : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT                     : out std_logic_vector(BIT_WIDTH-1 downto 0) 
    );
end component;

component NCO_SYMMETRY is
generic(
    DEVICE                       : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2

    HOVS                         : natural :=        2 ; -- HOVS = (Clock Frequency)/(Sampling Rate)
    SYMMETRY                     : boolean :=    FALSE ; -- TRUE  : Symmetry Operation(+a/-a freq shift), Generate POS/NEG_SHIFT_PATH
                                                         -- FALSE : Simplex Operation(+a freq shift), Only Generate POS_SHIFT_PATH
    POS_SHIFTH_PATH_NUM          : natural :=        2 ; -- The Number of Positive Frequency Shifting Path Number
    NEG_SHIFTH_PATH_NUM          : natural :=        1 ; -- The Number of Negative Frequency Shifting Path Number
    NCO_WIDTH                    : natural :=       16 ; -- Sinusoidal Wave Sample Wdith
    RES_VAL                      : natural :=    24576   -- Frequency Shift Step Resolution, 10kHz
    );
port(
    RST                          : in  std_logic;
    CLK                          : in  std_logic;

    NCO_WREN                     : in  std_logic;
    NCO_WORD                     : in  std_logic_vector(31 downto 0);

    NCO_FREQ_COMP_OFFSET         : in  std_logic_vector(31 downto 0);

    DATA_P_SH_VLD_IN             : in  std_logic_vector( POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift
    DATA_P_SH_I_IN               : in  std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift
    DATA_P_SH_Q_IN               : in  std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift

    DATA_P_SH_VLD_OUT            : out std_logic_vector( POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift
    DATA_P_SH_I_OUT              : out std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift
    DATA_P_SH_Q_OUT              : out std_logic_array16(POS_SHIFTH_PATH_NUM-1 downto 0); -- Positive shift

    DATA_N_SH_VLD_IN             : in  std_logic_vector( NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_I_IN               : in  std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_Q_IN               : in  std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift

    DATA_N_SH_VLD_OUT            : out std_logic_vector( NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_I_OUT              : out std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0); -- Negative shift
    DATA_N_SH_Q_OUT              : out std_logic_array16(NEG_SHIFTH_PATH_NUM-1 downto 0)  -- Negative shift
    );
end component;

component PIMD_COMPLEX_FILTER is
generic(
    DEVICE                       : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HS_MODE                      : boolean :=     TRUE ;
    HOVS                         : natural :=        2 ;
    TAP_NUM                      : natural :=       10 ;
    RND_BIT                      : natural :=       15
    );
port(
    RST_DSP                      : in  std_logic;
    CLK_DSP                      : in  std_logic;

    DATA_VLD_IN                  : in  std_logic;
    DATA_I_IN                    : in  std_logic_vector(15 downto 0);
    DATA_Q_IN                    : in  std_logic_vector(15 downto 0);

    DATA_VLD_OUT                 : out std_logic;
    DATA_I_OUT                   : out std_logic_vector(15 downto 0);
    DATA_Q_OUT                   : out std_logic_vector(15 downto 0);

    RST_CPU                      : in  std_logic;
    CLK_CPU                      : in  std_logic;

    BYPASS_IN                    : in  std_logic;

    COEF_WR_EN_IN                : in  std_logic;
    COEF_RD_EN_IN                : in  std_logic;
    COEF_WR_DN_IN                : in  std_logic;
    COEF_ADDR_IN                 : in  std_logic_vector( 3 downto 0);
    COEF_I_WDATA_IN              : in  std_logic_vector(20 downto 0);
    COEF_Q_WDATA_IN              : in  std_logic_vector(20 downto 0);

    COEF_I_RDATA_OUT             : out std_logic_vector(20 downto 0);
    COEF_Q_RDATA_OUT             : out std_logic_vector(20 downto 0)
    );
end component; 

component PFIR_FILTER is
generic(
    DEVICE                       : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    PIM_MODE                     : boolean :=     TRUE ;    
    HOVS                         : natural :=        2 ;
    SYMMETRY                     : string  :=    "EVEN";
    COEF_FIX                     : boolean :=     TRUE ;
    COEF_NUM                     : natural :=       39 ;
    RND_BIT                      : natural :=       15
    );
port(
    RST_DSP                      : in  std_logic;
    CLK_DSP                      : in  std_logic;

    DATA_VLD_IN                  : in  std_logic;
    DATA_I_IN                    : in  std_logic_vector(15 downto 0);
    DATA_Q_IN                    : in  std_logic_vector(15 downto 0);

    BYPASS_IN                    : in  std_logic;

    DATA_VLD_OUT                 : out std_logic;
    DATA_I_OUT                   : out std_logic_vector(15 downto 0);
    DATA_Q_OUT                   : out std_logic_vector(15 downto 0);

    RST_CPU                      : in  std_logic;
    CLK_CPU                      : in  std_logic;

    COEF_WR_EN                   : in  std_logic;                     -- coefficient write enable(indirect)
    COEF_RD_EN                   : in  std_logic;                     -- coefficient write done(indirect)
    COEF_WR_DN                   : in  std_logic;                     -- coefficient read  enable(indirect)
    COEF_ADDR                    : in  std_logic_vector( 7 downto 0); -- coefficient write address(indirect) 
    COEF_WR_DATA                 : in  std_logic_vector(15 downto 0); -- coefficient write data(indirect) 
    COEF_RD_DATA                 : out std_logic_vector(15 downto 0)  -- coefficient read  data(indirect) 
    );
end component;

--component BUF_SAMPLE_DELAY is    
--generic(
--    RAM_STYLE                    : string  := "DISTRIBUTED"; -- DISTRIBUTED or BLOCK
--    HS_MODE                      : boolean :=         TRUE ;

--    DATA_WIDTH                   : natural;
--    ADDR_WIDTH                   : natural
--    );
--port(
--    RST                          : in  std_logic;
--    CLK                          : in  std_logic;

--    DELAY_VALUE_IN               : in  std_logic_vector(ADDR_WIDTH-1 downto 0); 

--    SAMPLE_VLD_IN                : in  std_logic;
--    SAMPLE_IN                    : in  std_logic_vector(DATA_WIDTH-1 downto 0); 
--    SAMPLE_DELAY_OUT             : out std_logic_vector(DATA_WIDTH-1 downto 0) 
--    );
--end component;
component BUF_SAMPLE_DLY is
generic(
    RAM_STYLE                      : string := "DISTRIBUTED"; -- "DISTRIBUTED" or "BLOCK"
    RESOLUTION                     : string := "CLOCK";       -- "CLOCK" or "SAMPLE_RATE"

    DATA_WIDTH                     : natural;
    ADDR_WIDTH                     : natural
    );
port(
    RST                            : in  std_logic;
    CLK                            : in  std_logic;

    DELAY_VALUE_IN                 : in  std_logic_vector(ADDR_WIDTH-1 downto 0); 

    SAMPLE_VLD_IN                  : in  std_logic;
    SAMPLE_IN                      : in  std_logic_vector(DATA_WIDTH-1 downto 0); 
    SAMPLE_DELAY_OUT               : out std_logic_vector(DATA_WIDTH-1 downto 0) 
    );
end component;

-- component lms_pp_0224_release_0 is
-- port(
--     BB_IN_I                      : in  std_logic_vector(15 downto 0);
--     BB_IN_Q                      : in  std_logic_vector(15 downto 0);
--     CNT_RST                      : in  std_logic_vector( 0 downto 0);
--     FB_IN_I                      : in  std_logic_vector(15 downto 0);
--     FB_IN_Q                      : in  std_logic_vector(15 downto 0);
--     FB_MU_PP_SEL                 : in  std_logic_vector( 1 downto 0);
--     FB_PP_EN                     : in  std_logic_vector( 0 downto 0);
--     FB_PP_SET                    : in  std_logic_vector( 0 downto 0);
--     FB_PP_SETVAL_I               : in  std_logic_vector(15 downto 0);
--     FB_PP_SETVAL_Q               : in  std_logic_vector(15 downto 0);
--     CLK                          : in  std_logic;
--     CLR                          : in  std_logic;
--     BB_PP_OUT_I                  : out std_logic_vector(15 downto 0);
--     BB_PP_OUT_Q                  : out std_logic_vector(15 downto 0);
--     FB_PP_OUT_I                  : out std_logic_vector(15 downto 0);
--     FB_PP_OUT_Q                  : out std_logic_vector(15 downto 0);
--     TP_FB_DC_I                   : out std_logic_vector(15 downto 0);
--     TP_FB_DC_Q                   : out std_logic_vector(15 downto 0)
--     );
-- end component;

-- processing-delay : 12 clk
component PIM_PHASE_COMP_LMS is
generic(
    DEVICE                       : string             := "ULTRASCALE";
    HOVS                         : natural            := 1
);
port(
    RX_DATA_I_IN                 : in  std_logic_vector(15 downto 0);    -- PIM source in         BB_IN_I                      
    RX_DATA_Q_IN                 : in  std_logic_vector(15 downto 0);    -- PIM source in         BB_IN_Q                      
    CNT_RST_IN                   : in  std_logic_vector( 0 downto 0);    -- count rst in          CNT_RST                      
    PIM_DATA_I_IN                : in  std_logic_vector(15 downto 0);    -- UL in                 FB_IN_I                      
    PIM_DATA_Q_IN                : in  std_logic_vector(15 downto 0);    -- UL in                 FB_IN_Q                      
    MU_SELECT_IN                 : in  std_logic_vector( 1 downto 0);    -- Mu select in          FB_MU_PP_SEL                 
    PNPC_EN_IN                   : in  std_logic_vector( 0 downto 0);    -- PNPC enalbe in        FB_PP_EN                     
    PNPC_SET_IN                  : in  std_logic_vector( 0 downto 0);    -- PNPC coef set in      FB_PP_SET                    
    COEF_I_IN                    : in  std_logic_vector(15 downto 0);    -- initial coeff in      FB_PP_SETVAL_I               
    COEF_Q_IN                    : in  std_logic_vector(15 downto 0);    -- initial coeff in      FB_PP_SETVAL_Q               
    CLK_PIMD                     : in  std_logic;                        -- CLK                   CLK                          
    CE_CLR_IN                    : in  std_logic;                        -- ?                     CLR                          
    UL_DATA_DLY_I_OUT            : out std_logic_vector(15 downto 0);    -- UL delayed data out   BB_PP_OUT_I                  
    UL_DATA_DLY_Q_OUT            : out std_logic_vector(15 downto 0);    -- UL delayed data out   BB_PP_OUT_Q                  
    PIM_I_OUT                    : out std_logic_vector(15 downto 0);    -- PNPCed data out       FB_PP_OUT_I                  
    PIM_Q_OUT                    : out std_logic_vector(15 downto 0);    -- PNPCed data out       FB_PP_OUT_Q                  
    COEF_I_OUT                   : out std_logic_vector(15 downto 0);    -- coef out              TP_FB_DC_I                   
    COEF_Q_OUT                   : out std_logic_vector(15 downto 0)     -- coef out              TP_FB_DC_Q                   
    );
end component;

component SAT_SIGN is            
generic(
    HS_MODE                      : boolean := TRUE;
    INPUT_BIT                    : natural;
    OUTPUT_BIT                   : natural 
    );
port( 
    RST                          : in  std_logic;
    CLK                          : in  std_logic;
    DATA_IN                      : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT                     : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

component PIMD_DECIMATOR is
generic(
    DNSAMP_RATIO  : natural := 3;
    PATH_NUM      : natural := 4
    );
port(
    RST_H         : in  std_logic;
    CLK_H         : in  std_logic;

    DATAH_I_IN    : in  std_logic_array16(PATH_NUM-1 downto 0);
    DATAH_Q_IN    : in  std_logic_array16(PATH_NUM-1 downto 0);

    RST_L         : in  std_logic;
    CLK_L         : in  std_logic;

    PIMD_ON_IN    : in  std_logic_vector( PATH_NUM-1 downto 0);

    DATAL_VLD_IN  : in  std_logic_vector( PATH_NUM-1 downto 0);
    DATAL_I_IN    : in  std_logic_array16(PATH_NUM-1 downto 0);
    DATAL_Q_IN    : in  std_logic_array16(PATH_NUM-1 downto 0);

    DATAL_VLD_OUT : out std_logic_vector( PATH_NUM-1 downto 0);
    DATAL_I_OUT   : out std_logic_array16(PATH_NUM-1 downto 0);
    DATAL_Q_OUT   : out std_logic_array16(PATH_NUM-1 downto 0)
    );
end component;

component PIMD_IM3_GEN is
generic(
    DEVICE                       : string  := "ULTRASCALE";
    HOVS                         : natural :=           1 ;
    TX_ANT_NUM                   : natural :=           4 ;
    VERSION                      : string  := "A"  -- A : ATnT DB AWS/PCS 's PCS
    );
port(
    RST                          : in  std_logic;           -- Reset, Active High
    CLK                          : in  std_logic;

	-- INTRA_BAND_SEL_IN                         : in  std_logic; 
    -- INTER_BAND_TYPE1_SEL_IN                   : in  std_logic_vector(1 downto 0);
    -- INTER_BAND_TYPE2_SEL_IN                   : in  std_logic_vector(1 downto 0);
	INTRA_BAND_SEL_IN                         : in  std_logic_vector(TX_ANT_NUM-1 downto 0);
    INTER_BAND_TYPE1_SEL_IN                   : in  std_logic_array2(TX_ANT_NUM-1 downto 0);
    INTER_BAND_TYPE2_SEL_IN                   : in  std_logic_array2(TX_ANT_NUM-1 downto 0);

    PIM_CFR_REF_VLD_IN           : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_CFR_REF_I_IN             : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_CFR_REF_Q_IN             : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    PIM_INTERB_SRC_I_IN          : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_INTERB_SRC_Q_IN          : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    PIM_INTRA_BAND_VLD_OUT       : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    PIM_INTRA_BAND_I_OUT         : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_INTRA_BAND_Q_OUT         : out std_logic_array16(TX_ANT_NUM-1 downto 0);

    PIM_INTER_TYPE1_I_OUT        : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_INTER_TYPE1_Q_OUT        : out std_logic_array16(TX_ANT_NUM-1 downto 0);

    PIM_INTER_TYPE2_I_OUT        : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    PIM_INTER_TYPE2_Q_OUT        : out std_logic_array16(TX_ANT_NUM-1 downto 0); 
    
    DBG_PIM_SUM_I_OUT            : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    DBG_PIM_SUM_Q_OUT            : out std_logic_array16(TX_ANT_NUM-1 downto 0) 
    );
end component;

component NCO_QUARTER_SHIFT is
generic(
    DEVICE                       : string  := "ULTRASCALE";
    HOVS                         : natural :=           1 ;
    TX_ANT_NUM                   : natural :=           4 
    );
port(
    RST                          : in  std_logic;           -- Reset, Active High
    CLK                          : in  std_logic;

    SHIFT_DIRECTION_IN           : in  std_logic_array2(TX_ANT_NUM-1 downto 0);

    DATA_VLD_IN                  : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DATA_I_IN                    : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    DATA_Q_IN                    : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    DATA_VLD_OUT                 : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    DATA_I_OUT                   : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    DATA_Q_OUT                   : out std_logic_array16(TX_ANT_NUM-1 downto 0) 
    );
end component;

component pim_hbf_i is
    generic (
		FILTER_ORDER					: integer := 27;		-- 27 or 19 or 11
		WIDTH_IN                    	: integer := 16;
		WIDTH_OUT                   	: integer := 16;
		BINARY_POINT                	: integer := 15
	);
	port(
		i_rst   						: in  std_logic;
		i_clk							: in  std_logic;

        -- in sample rate : 122.88 MHz
		i_data_i					    : in  std_logic_vector(WIDTH_IN-1 downto 0);
		i_data_q					    : in  std_logic_vector(WIDTH_IN-1 downto 0);

        -- out sample rate : 245.76 MHz
		o_data_i						: out std_logic_vector(WIDTH_OUT-1 downto 0);
		o_data_q						: out std_logic_vector(WIDTH_OUT-1 downto 0)
	);
end component;

component pim_hbf_d is
    generic (
		FILTER_ORDER					: integer := 27;		-- 27 or 19 or 11
		WIDTH_IN                    	: integer := 16;
		WIDTH_OUT                   	: integer := 16;
		BINARY_POINT                	: integer := 15
	);
	port(
		i_rst 							: in  std_logic;
		i_clk							: in  std_logic;

        -- in sample rate : 245.76 MHz
		i_data_i					    : in  std_logic_vector(WIDTH_IN-1 downto 0);
		i_data_q					    : in  std_logic_vector(WIDTH_IN-1 downto 0);

        -- out sample rate : 122.88 MHz
		o_valid							: out std_logic;
		o_data_i						: out std_logic_vector(WIDTH_OUT-1 downto 0);
		o_data_q						: out std_logic_vector(WIDTH_OUT-1 downto 0)
	);
end component;

-- ******************************
-- Signals                     
-- ******************************
-- Reset 
signal clk_unstable              : std_logic;

signal rst_pimblk                : std_logic;

signal rst_ul                    : std_logic;
signal rst_mdl                   : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal rst_pnpc                  : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ce_clr_pnpc               : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal rst_uldnsamp              : std_logic_vector( RX_ANT_NUM-1 downto 0);

-- CDC 
signal pim_detector_on_pimclk_sh : std_logic_array2( RX_ANT_NUM-1 downto 0); 
signal pim_detector_on_ulclk_sh  : std_logic_array2( RX_ANT_NUM-1 downto 0); 
signal pim_mitigator_on_sh       : std_logic_array2( RX_ANT_NUM-1 downto 0); 
signal pim_mitigator_on_ulclk_sh : std_logic_array2( RX_ANT_NUM-1 downto 0); 
signal pim_mitigator_on_ulclk    : std_logic_vector( RX_ANT_NUM-1 downto 0); 
signal pim_cfr_ref_sel_sh        : std_logic_array2( RX_ANT_NUM-1 downto 0);
signal pim_cfr_ref_sel_dc        : std_logic_vector( RX_ANT_NUM-1 downto 0);

-- PIM Path 
signal pimd_ref_in_vld           : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_ref_in_i             : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_ref_in_q             : std_logic_array16(TX_ANT_NUM-1 downto 0);
        
signal pimd_interb_cdly_out_i    : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_interb_cdly_out_q    : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_interb_att_out_vld   : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_interb_att_out_i     : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_interb_att_out_q     : std_logic_array16(TX_ANT_NUM-1 downto 0);
        
signal pimd_upsamp_out_vld       : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_upsamp_out_i         : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_upsamp_out_q         : std_logic_array16(TX_ANT_NUM-1 downto 0);
        
signal pimd_interb_fdly_in_vld   : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_interb_fdly_in_i     : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_interb_fdly_in_q     : std_logic_array16(TX_ANT_NUM-1 downto 0);
        
signal pimd_intra_fdly_in_i      : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_intra_fdly_in_q      : std_logic_array16(TX_ANT_NUM-1 downto 0);
        
signal pimd_interb_fdly_out_i    : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_interb_fdly_out_q    : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal pimd_refsrc_in_vld        : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_refsrc_in_i          : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_refsrc_in_q          : std_logic_array16(TX_ANT_NUM-1 downto 0);
        
signal pimd_inter_src_i          : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_inter_src_q          : std_logic_array16(TX_ANT_NUM-1 downto 0);
----
signal pimd_im3gen_intra_out_vld : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_im3gen_intra_out_i   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_im3gen_intra_out_q   : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal pimd_im3gen_inter1_out_vld : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_im3gen_inter1_out_i  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_im3gen_inter1_out_q  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_im3gen_inter2_out_i  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_im3gen_inter2_out_q  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal dbg_pimd_im3gen_sum_out_i  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal dbg_pimd_im3gen_sum_out_q  : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal pimd_quar_shfit_intra_out_vld : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_quar_shfit_intra_out_i   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_quar_shfit_intra_out_q   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_quar_shfit_inter1_out_i  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_quar_shfit_inter1_out_q  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_quar_shfit_inter2_out_i  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_quar_shfit_inter2_out_q  : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal pimd_mixer_beta_intra_out_vld : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_intra_out_i_d   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_intra_out_q_d   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_intra_out_i_d2  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_intra_out_q_d2  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_inter1_out_i_d  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_inter1_out_q_d  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_inter2_out_i_d  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_inter2_out_q_d  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_intra_out_i   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_intra_out_q   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_inter1_out_i  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_inter1_out_q  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_inter2_out_i  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_inter2_out_q  : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal pimd_sum_inter_17b_i          : std_logic_array17(TX_ANT_NUM-1 downto 0);
signal pimd_sum_inter_17b_q          : std_logic_array17(TX_ANT_NUM-1 downto 0);
signal pimd_sum_inter_sat_i          : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_sum_inter_sat_q          : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal pimd_pre_lpf_in_16b_i          : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_in_16b_q          : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_in_18b_i          : std_logic_array18(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_in_18b_q          : std_logic_array18(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_in_18b_tmp_i      : std_logic_array18(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_in_18b_tmp_q      : std_logic_array18(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_out_17b_i         : std_logic_array17(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_out_17b_q         : std_logic_array17(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_out_18b_i         : std_logic_array18(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_out_18b_q         : std_logic_array18(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_out_19b_i         : std_logic_array19(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_out_19b_q         : std_logic_array19(TX_ANT_NUM-1 downto 0);

signal pimd_mixer_beta_intra_dly_i   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_intra_dly_q   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_intra_dly2_i  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixer_beta_intra_dly2_q  : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_inter_dly2_i         : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_inter_dly2_q         : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal pimd_sltb1_core_out_i     : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_sltb1_core_out_q     : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_sltb2_core_out_i     : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_sltb2_core_out_q     : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal pimd_core_in_sum_17b_i    : std_logic_array17(TX_ANT_NUM-1 downto 0);
signal pimd_core_in_sum_17b_q    : std_logic_array17(TX_ANT_NUM-1 downto 0);
signal pimd_core_in_sum_out_i    : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_core_in_sum_out_q    : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal pimd_pre_lpf_out_sat_i      : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_out_sat_q      : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_out_sat_g0_i   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_out_sat_g0_q   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_out_sat_g1_i   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_out_sat_g1_q   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_out_sat_g2_i   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_out_sat_g2_q   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_out_sat_g3_i   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_pre_lpf_out_sat_g3_q   : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal s_pim_bit_shift_sel_in    : std_logic_vector(1 downto 0);

signal pimd_sum_total_out_vld    : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_sum_total_17b_i      : std_logic_array17(TX_ANT_NUM-1 downto 0);
signal pimd_sum_total_17b_q      : std_logic_array17(TX_ANT_NUM-1 downto 0);
signal pimd_sum_total_out_i      : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_sum_total_out_q      : std_logic_array16(TX_ANT_NUM-1 downto 0);
------        
signal pimd_mixps_in_vld         : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_mixps_in_i           : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixps_in_q           : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal pimd_mixps_out_vld        : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_mixps_out_i          : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_mixps_out_q          : std_logic_array16(TX_ANT_NUM-1 downto 0);
        

signal pimd_firlpf_in_vld        : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_firlpf_in_i          : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_firlpf_in_q          : std_logic_array16(TX_ANT_NUM-1 downto 0);
        
signal pimd_firlpf_out_vld       : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_firlpf_out_i         : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_firlpf_out_q         : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal pimd_pre_firlpf_out_vld   : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_pre_firlpf_out_i     : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_pre_firlpf_out_q     : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_pre_firlpf_out_i_d   : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_pre_firlpf_out_q_d   : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal pimd_dly_in_vld           : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_dly_in_i             : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_dly_in_q             : std_logic_array16(TX_ANT_NUM-1 downto 0);
        
signal pimd_dly_out_vld          : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal pimd_dly_out_i            : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_dly_out_q            : std_logic_array16(TX_ANT_NUM-1 downto 0);
        
signal pimd_core_out_vld         : std_logic_vector( TX_ANT_NUM-1 downto 0);

signal ul_upsamp_in_vld          : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_upsamp_in_i            : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal ul_upsamp_in_q            : std_logic_array16(RX_ANT_NUM-1 downto 0);
        

signal ul_upsamp_out_vld         : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_upsamp_out_i           : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal ul_upsamp_out_q           : std_logic_array16(RX_ANT_NUM-1 downto 0);
        
signal ul_mixps_in_vld           : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_mixps_in_i             : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal ul_mixps_in_q             : std_logic_array16(RX_ANT_NUM-1 downto 0);
        
signal ul_mixps_out_vld          : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_mixps_out_i            : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal ul_mixps_out_q            : std_logic_array16(RX_ANT_NUM-1 downto 0);
        
signal ul_tgt_vld                : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_tgt_i                  : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal ul_tgt_q                  : std_logic_array16(RX_ANT_NUM-1 downto 0);
        
signal ul_dly_in_vld             : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_dly_in_i               : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal ul_dly_in_q               : std_logic_array16(RX_ANT_NUM-1 downto 0);
        
signal ul_dly_out_vld            : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_dly_out_i              : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal ul_dly_out_q              : std_logic_array16(RX_ANT_NUM-1 downto 0);
        
signal ul_dly_d1_vld             : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_dly_d1_i               : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal ul_dly_d1_q               : std_logic_array16(RX_ANT_NUM-1 downto 0);
        
signal ul_pnpc_out_vld           : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_pnpc_out_i             : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal ul_pnpc_out_q             : std_logic_array16(RX_ANT_NUM-1 downto 0);
        
signal ul_pnpc_sel_vld           : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_pnpc_sel_i             : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal ul_pnpc_sel_q             : std_logic_array16(RX_ANT_NUM-1 downto 0);
        
signal ul_pim_substract_out_vld  : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_pim_substract_out_i    : std_logic_array17(RX_ANT_NUM-1 downto 0);
signal ul_pim_substract_out_q    : std_logic_array17(RX_ANT_NUM-1 downto 0);

signal ul_pimd_sat_out_vld       : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_pimd_sat_out_i         : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal ul_pimd_sat_out_q         : std_logic_array16(RX_ANT_NUM-1 downto 0);
        
signal ul_mixns_out_vld          : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_mixns_out_i            : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal ul_mixns_out_q            : std_logic_array16(RX_ANT_NUM-1 downto 0);

signal deci_ul_mixns_out_vld     : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal deci_ul_mixns_out_i       : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal deci_ul_mixns_out_q       : std_logic_array16(RX_ANT_NUM-1 downto 0);        

signal ul_data_122p88M_vld       : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_data_122p88M_i         : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal ul_data_122p88M_q         : std_logic_array16(RX_ANT_NUM-1 downto 0);
        
signal ul_out_vld                : std_logic_vector( RX_ANT_NUM-1 downto 0);
signal ul_out_i                  : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal ul_out_q                  : std_logic_array16(RX_ANT_NUM-1 downto 0);
        

signal pimd_scdbg_i              : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal pimd_scdbg_q              : std_logic_array16(TX_ANT_NUM-1 downto 0);
        

signal pimd_ncscore_coef_i_rdata : std_logic_array21(TX_ANT_NUM-1 downto 0);
signal pimd_ncscore_coef_q_rdata : std_logic_array21(TX_ANT_NUM-1 downto 0);

signal pimd_core_coef_i_rdata    : std_logic_vector(20 downto 0)              := (others=>'0');
signal pimd_core_coef_q_rdata    : std_logic_vector(20 downto 0)              := (others=>'0');

signal pimd_firlpf_coef_rd_data  : std_logic_array16(TX_ANT_NUM-1 downto 0);  
signal pimd_firlpf_coef_rdata    : std_logic_vector(15 downto 0);  

signal pnpc_en_sh                : std_logic_array2( RX_ANT_NUM-1 downto 0); 
signal pnpc_set_sh               : std_logic_array2( RX_ANT_NUM-1 downto 0); 

signal pnpc_tp_dc_i              : std_logic_array16(RX_ANT_NUM-1 downto 0); 
signal pnpc_tp_dc_q              : std_logic_array16(RX_ANT_NUM-1 downto 0); 

attribute KEEP : string;
attribute KEEP of pimd_intra_fdly_in_i              : signal is "TRUE";
attribute KEEP of pimd_intra_fdly_in_q              : signal is "TRUE";
attribute KEEP of pimd_ref_in_i                     : signal is "TRUE";
attribute KEEP of pimd_ref_in_q                     : signal is "TRUE";
attribute KEEP of DL_INTRAB_DLY_VALUE_IN            : signal is "TRUE";
attribute KEEP of DL_PIM_REF_VLD_IN                 : signal is "TRUE";
attribute KEEP of pimd_mixer_beta_intra_out_i       : signal is "TRUE";
attribute KEEP of pimd_mixer_beta_intra_out_q       : signal is "TRUE";
attribute KEEP of pimd_pre_lpf_in_16b_i             : signal is "TRUE";
attribute KEEP of pimd_pre_lpf_in_16b_q             : signal is "TRUE";
attribute KEEP of DL_INTERB_CDLY_VALUE_IN           : signal is "TRUE";
attribute KEEP of DL_PIM_INTERBAND_VLD_IN           : signal is "TRUE";
attribute KEEP of pimd_interb_cdly_out_i            : signal is "TRUE";
attribute KEEP of pimd_interb_cdly_out_q            : signal is "TRUE";


begin

    -- ******************************
    -- Reset & CDC & MISC                  
    -- ******************************
    clk_unstable <= not INT_SYSPLL_LOCK_IN;

    U_Reset_Global_PIM : RST_SYNC generic map(3, 200) port map(clk_unstable, CLK_PIMD, rst_pimblk);
    U_Reset_Global_UL  : RST_SYNC generic map(3, 200) port map(clk_unstable, CLK_UL  , rst_ul    );

    G_Reset_UL_Path : for I in 0 to (RX_ANT_NUM-1) generate begin
        U_PNPC_RST_SYNC      : RST_SYNC generic map(3, 200) port map(RST_PIMD    , CLK_PIMD, rst_mdl(I)     ); 
        U_PNPC_CE_CLR        : CE_CLR_GEN port map(rst_mdl(I), INT_SYSPLL_LOCK_IN, CLK_PIMD, ce_clr_pnpc(I), rst_pnpc(I));                          
    end generate;

    P_Register_Double_Clocking_PIMD_CLK : process(rst_pimblk, CLK_PIMD) begin
        if (rst_pimblk = '1') then
            pim_detector_on_pimclk_sh  <= (others => (others => '0'));
            pim_mitigator_on_sh        <= (others => (others => '0'));
            pim_cfr_ref_sel_sh         <= (others => (others => '0'));
            pnpc_en_sh                 <= (others => (others => '0'));
            pnpc_set_sh                <= (others => (others => '0'));

        elsif (CLK_PIMD'event) and (CLK_PIMD = '1') then 
            for I in 0 to (RX_ANT_NUM-1) loop
                pim_detector_on_pimclk_sh(I)  <= pim_detector_on_pimclk_sh(I)(0) & PIM_DETECTOR_ON_IN(I) ;
                pim_mitigator_on_sh(I)        <= pim_mitigator_on_sh(I)(0)& PIM_MITIGATOR_ON_IN(I);
                pim_cfr_ref_sel_sh(I)         <= pim_cfr_ref_sel_sh(I)(0) & PIM_CFR_REF_SEL_IN(I) ;
                pnpc_en_sh(I)                 <= pnpc_en_sh(I)(0) & PNPC_EN_IN(I) ;
                pnpc_set_sh(I)                <= pnpc_set_sh(I)(0)& PNPC_SET_IN(I);

                pim_cfr_ref_sel_dc(I)         <= pim_cfr_ref_sel_sh(I)(1);
            end loop;
        end if;
    end process;


    P_Register_Double_Clocking_UL_CLK : process(rst_ul, CLK_UL) begin
        if (rst_ul = '1') then
            pim_detector_on_ulclk_sh  <= (others => (others => '0'));
            pim_mitigator_on_ulclk_sh <= (others => (others => '0'));
        elsif (CLK_UL'event) and (CLK_UL = '1') then 
            for I in 0 to (RX_ANT_NUM-1) loop
                pim_detector_on_ulclk_sh(I)  <= pim_detector_on_ulclk_sh(I)(0) & PIM_DETECTOR_ON_IN(I) ;
                pim_mitigator_on_ulclk_sh(I) <= pim_mitigator_on_ulclk_sh(I)(0) & PIM_MITIGATOR_ON_IN(I);
            end loop;
        end if;
    end process;

    G_PIMD_MITIGATOR_ON_Assign : for I in 0 to (RX_ANT_NUM-1) generate begin
        pim_mitigator_on_ulclk(I) <= pim_mitigator_on_ulclk_sh(I)(1); 
    end generate;
    -- ******************************
    -- PIM Processing Path                  
    -- ******************************

    P_PIMREF_Detector_OnOff : process(rst_pimblk, CLK_PIMD) begin
        if (rst_pimblk = '1') then
            pimd_ref_in_vld <= (others => '0');            
            pimd_ref_in_i   <= (others => (others => '0'));
            pimd_ref_in_q   <= (others => (others => '0'));
        elsif (CLK_PIMD'event) and (CLK_PIMD = '1') then 
            for I in 0 to (TX_ANT_NUM-1) loop
                if (pim_detector_on_pimclk_sh(I)(1) = '1') then           
                    pimd_ref_in_vld(I) <= DL_PIM_REF_VLD_IN(I);            

    	            if (DL_PIM_REF_VLD_IN(I) = '1') then            
                        pimd_ref_in_i(I) <= DL_PIM_REF_I_IN(I);
                        pimd_ref_in_q(I) <= DL_PIM_REF_Q_IN(I);
                    else
                        pimd_ref_in_i(I) <= pimd_ref_in_i(I);
                        pimd_ref_in_q(I) <= pimd_ref_in_q(I);
                    end if;
                else
                    pimd_ref_in_vld(I) <= '0';            
                    pimd_ref_in_i(I)   <= (others => '0');
                    pimd_ref_in_q(I)   <= (others => '0');
                end if;
            end loop;
        end if;
    end process;

    G_IntraBand_PIM_CORE : if (PIMD_BLK_TYPE = "INTRA") generate begin

        pimd_interb_att_out_vld   <= (others => '0');             
        pimd_interb_att_out_i     <= (others => (others => '0')); 
        pimd_interb_att_out_q     <= (others => (others => '0')); 
        
        pimd_upsamp_out_vld       <= (others => '0');             
        pimd_upsamp_out_i         <= (others => (others => '0')); 
        pimd_upsamp_out_q         <= (others => (others => '0')); 
        
        pimd_interb_fdly_in_vld   <= (others => '0');                 
        pimd_interb_fdly_in_i     <= (others => (others => '0'));     
        pimd_interb_fdly_in_q     <= (others => (others => '0'));     

        pimd_interb_cdly_out_i    <= (others => (others => '0'));
        pimd_interb_cdly_out_q    <= (others => (others => '0'));
        pimd_interb_fdly_out_i    <= (others => (others => '0'));    
        pimd_interb_fdly_out_q    <= (others => (others => '0'));    

        pimd_refsrc_in_vld        <= (others => '0');                
        pimd_refsrc_in_i          <= (others => (others => '0'));    
        pimd_refsrc_in_q          <= (others => (others => '0'));    
        
        pimd_inter_src_i          <= (others => (others => '0'));
        pimd_inter_src_q          <= (others => (others => '0'));

        pimd_ncscore_coef_i_rdata <= (others => (others => '0'));  
        pimd_ncscore_coef_q_rdata <= (others => (others => '0'));  
        
        pimd_core_coef_i_rdata    <= (others => '0');              
        pimd_core_coef_q_rdata    <= (others => '0');              

        U_PIM_CORE_Like_DPD_CORE : DPD_CORE 
        generic map(
            DEVICE                       => DEVICE                       ,
                                                                         
            TX_ANT_NUM                   => TX_ANT_NUM                   ,
            HOVS                         => pimref_hovs                  ,
        
            DPD_LUT_OPTIMIZED            => PIMD_CORE_LUT_OPTIMIZED      ,
            DPD_LUT_MEM_DEPTH            => PIMD_CORE_LUT_MEM_DEPTH      , 
            DPD_LUT_RBTEST               => PIMD_CORE_LUT_RBTEST         , 
            DPD_CORE_QPOINT_SEL          => PIMD_CORE_QPOINT_SEL         , 
            DPD_CORE_LUT_DIMENSION       => PIMD_CORE_LUT_DIMENSION      , 
            DPD_CORE_LUT_NUM             => PIMD_CORE_LUT_NUM            ,
            DPD_CORE_TAP_NUM             => PIMD_CORE_TAP_NUM            ,
            DPD_CORE_RND_BIT             => 10                            
            )
        port map(
            RST_DPD                      => RST_PIMD                     , 
            CLK_DPD                      => CLK_PIMD                     , 
        
            DPD_CORE_VLD_IN              => pimd_ref_in_vld              , 
            DPD_CORE_I_IN                => pimd_ref_in_i                , 
            DPD_CORE_Q_IN                => pimd_ref_in_q                , 
                                             
            DPD_CORE_VLD_OUT             => pimd_mixps_in_vld            , 
            DPD_CORE_I_OUT               => pimd_mixps_in_i              , 
            DPD_CORE_Q_OUT               => pimd_mixps_in_q              , 
        
            DPD_CORE_BYPASS_IN           => PIM_CORE_BYPASS_IN           ,
                                                                         
            DPD_GAIN_INDEX_IN            => PIM_GAIN_INDEX_IN            ,
            DPD_QPOINT_SEL_IN            => PIM_QPOINT_SEL_IN            ,
        
            RST_CPU                      => RST_CPU                      ,
            CLK_CPU                      => CLK_CPU                      ,
        
            DPD_LUT_RB_TEST_EN_IN        => PIM_LUT_RB_TEST_EN_IN        ,
                                                                         
            DPD_LUT_SWITCH_CDC_STRB_IN   => PIM_LUT_SWITCH_CDC_STRB_IN   ,
            DPD_LUT_INPUT_SWITCH_IN      => PIM_LUT_INPUT_SWITCH_IN      , 
            DPD_LUT_OUTPUT_SWITCH_IN     => PIM_LUT_OUTPUT_SWITCH_IN     , 
                                                                         
            DPD_LUT_UPDATE_SW_IN         => PIM_LUT_UPDATE_SW_IN         , 
            DPD_LUT_WREN_IN              => PIM_LUT_WREN_IN              , 
            DPD_LUT_RDEN_IN              => PIM_LUT_RDEN_IN              , 
            DPD_LUT_ADDR_IN              => PIM_LUT_ADDR_IN              , 
            DPD_LUT_WDATA_IN             => PIM_LUT_WDATA_IN             , 
            DPD_LUT_RDATA_OUT            => PIM_LUT_RDATA_OUT              
            );
    end generate;	    

    G_InterBand_3rd_IM_GEN : if (PIMD_BLK_TYPE = "INTER") generate begin

        G_InterBand_Gain_N_Delay_Compensator_TX_GEN : for I in 0 to (TX_ANT_NUM-1) generate begin
            U_INTERB_COARSE_DLY_I : BUF_SAMPLE_DLY generic map("BLOCK", "SAMPLE_RATE", 16, 11) port map(clk_unstable, CLK_UL, DL_INTERB_CDLY_VALUE_IN(I), DL_PIM_INTERBAND_VLD_IN(I), DL_PIM_INTERBAND_I_IN(I), pimd_interb_cdly_out_i(I));
            U_INTERB_COARSE_DLY_Q : BUF_SAMPLE_DLY generic map("BLOCK", "SAMPLE_RATE", 16, 11) port map(clk_unstable, CLK_UL, DL_INTERB_CDLY_VALUE_IN(I), DL_PIM_INTERBAND_VLD_IN(I), DL_PIM_INTERBAND_Q_IN(I), pimd_interb_cdly_out_q(I));
            U_InterBand_Gain_Compensator : PATH_DGATT 
            generic map(
                DEVICE                       => DEVICE                       , 
                RND_BIT                      => interb_duc_gain_rnd_bit      ,
                HOVS                         => interb_duc_gain_hovs          
                )
            port map(
                RST                          => clk_unstable                 , 
                CLK                          => CLK_UL                       , 
            
                DATA_VALID_IN                => DL_PIM_INTERBAND_VLD_IN(I)   , 
                DATA_I_IN                    => pimd_interb_cdly_out_i(I)    , 
                DATA_Q_IN                    => pimd_interb_cdly_out_q(I)    , 
            
                DGATT_VAL                    => PIM_INTERBAND_DUC_GAIN_IN(I) , 
            
                DATA_VALID_OUT               => pimd_interb_att_out_vld(I)   , 
                DATA_I_OUT                   => pimd_interb_att_out_i(I)     , 
                DATA_Q_OUT                   => pimd_interb_att_out_q(I)       
                );
        end generate;


        G_InterBand_DUC_Upsamp_x1 : if (interband_upsamp_ratio = 1) generate begin  

            pimd_upsamp_out_vld <= pimd_interb_att_out_vld; 
            pimd_upsamp_out_i   <= pimd_interb_att_out_i; 
            pimd_upsamp_out_q   <= pimd_interb_att_out_q; 
        end generate;    

        G_InterBand_DUC_Upsamp_x2 : if (interband_upsamp_ratio = 2) generate begin  
            G_InterBand_Upsamp_x2_TX_GEN : for I in 0 to (TX_ANT_NUM-1) generate begin
                U_InterBand_HBFx2 : hbf_i_comm 
                generic map(
                    HOVS                        => 1          
                    )
                port map(
                    RST                         => clk_unstable              , 
                    CLK                         => CLK_PIMD                  , 
                
                    INPUT_FRAME                 => pimd_interb_att_out_vld(I), 
                    INPUT_VALID                 => pimd_interb_att_out_vld(I), 
                    INPUT_DATA_I                => pimd_interb_att_out_i(I)  , 
                    INPUT_DATA_Q                => pimd_interb_att_out_q(I)  , 
                
                    OUTPUT_FRAME                => open                      ,
                    OUTPUT_VALID                => pimd_upsamp_out_vld(I)    ,
                    OUTPUT_DATA_I               => pimd_upsamp_out_i(I)      ,
                    OUTPUT_DATA_Q               => pimd_upsamp_out_q(I)        
                    );
            end generate;
        end generate;

        G_InterBand_DUC_Upsamp_x3 : if (interband_upsamp_ratio = 3) generate begin  
            U_InterBand_Resamp_x3 : fir_i3_comm 
            generic map(
                ANT_NUM                     => TX_ANT_NUM               ,
                PASSBAND                    => 60 
                )
            port map(
                RST_W(0)                    => clk_unstable              , 
                RST_W(1)                    => clk_unstable              , 
                RST_W(2)                    => clk_unstable              , 
                RST_W(3)                    => clk_unstable              , 
                RST_R(0)                    => clk_unstable              , 
                RST_R(1)                    => clk_unstable              , 
                RST_R(2)                    => clk_unstable              , 
                RST_R(3)                    => clk_unstable              , 
                CLK_W                       => CLK_UL                    , 
                CLK_R                       => CLK_PIMD                  , 
            
                DATA_IN_VALID               => pimd_interb_att_out_vld(0), 
                DATA_IN_I                   => pimd_interb_att_out_i     ,
                DATA_IN_Q                   => pimd_interb_att_out_q     ,
            
                BUF_COLLISION_FLAG          => open                      ,
                DATA_OUT_VALID              => pimd_upsamp_out_vld       ,
                DATA_OUT_I                  => pimd_upsamp_out_i         ,
                DATA_OUT_Q                  => pimd_upsamp_out_q           
                );
        end generate;
        
        P_PIM_InterBand_Detector_OnOff : process(rst_pimblk, CLK_PIMD) begin
            if (rst_pimblk = '1') then
                pimd_interb_fdly_in_vld <= (others => '0');                 
                pimd_interb_fdly_in_i   <= (others => (others => '0'));     
                pimd_interb_fdly_in_q   <= (others => (others => '0'));     
            elsif (CLK_PIMD'event) and (CLK_PIMD = '1') then
                for I in 0 to (TX_ANT_NUM-1) loop
                    if (pim_detector_on_pimclk_sh(I)(0) = '1') then           
                        pimd_interb_fdly_in_vld(I) <= pimd_upsamp_out_vld(I);                 

                        if (pimd_upsamp_out_vld(I) = '1') then
                            pimd_interb_fdly_in_i(I) <= pimd_upsamp_out_i(I);     
                            pimd_interb_fdly_in_q(I) <= pimd_upsamp_out_q(I);     
                        else
                            pimd_interb_fdly_in_i(I) <= pimd_interb_fdly_in_i(I);     
                            pimd_interb_fdly_in_q(I) <= pimd_interb_fdly_in_q(I);     
                        end if;
                    else
                        pimd_interb_fdly_in_vld(I) <= '0';                 
                        pimd_interb_fdly_in_i(I)   <= (others => '0');     
                        pimd_interb_fdly_in_q(I)   <= (others => '0');     
                    end if;
                end loop;
            end if;
        end process;

        G_PIMREF_INTERDUC_Delay_Buffer_TX_GEN : for I in 0 to (TX_ANT_NUM-1) generate begin

            U_INTERB_FINE_DLY_I : SRL16E_WRAP generic map(DEVICE, 16) port map(CLK_PIMD, pimd_interb_fdly_in_i(I), DL_INTERB_FDLY_VALUE_IN(I), pimd_interb_fdly_out_i(I));
            U_INTERB_FINE_DLY_Q : SRL16E_WRAP generic map(DEVICE, 16) port map(CLK_PIMD, pimd_interb_fdly_in_q(I), DL_INTERB_FDLY_VALUE_IN(I), pimd_interb_fdly_out_q(I));

        end generate;

        U_PIMD_SRC_PROC : PIMD_SRC_PROC 
        generic map(
            DEVICE                       => DEVICE                       , 
            HOVS                         => pimref_hovs                  , 
                                                                         
            TX_ANT_NUM                   => TX_ANT_NUM                   ,
            PIM_SRC_NUM                  => PIM_SRC_NUM                   
            )
        port map(
            RST                          => rst_pimblk                   , 
            CLK                          => CLK_PIMD                     , 
        
            PIM_CFR_REF_SEL_IN           => pim_cfr_ref_sel_dc           ,  
        
            PIM_CFR_REF_VLD_IN           => pimd_ref_in_vld              , 
            PIM_CFR_REF_I_IN             => pimd_ref_in_i                , 
            PIM_CFR_REF_Q_IN             => pimd_ref_in_q                , 
        
            PIM_INTERB_SRC_I_IN          => pimd_interb_fdly_out_i       , 
            PIM_INTERB_SRC_Q_IN          => pimd_interb_fdly_out_q       , 
        
            PIM_CFR_REF_VLD_OUT          => pimd_refsrc_in_vld           , 
            PIM_CFR_REF_I_OUT            => pimd_refsrc_in_i             , 
            PIM_CFR_REF_Q_OUT            => pimd_refsrc_in_q             , 
                                             
            PIM_INTERB_SRC_I_OUT         => pimd_inter_src_i             , 
            PIM_INTERB_SRC_Q_OUT         => pimd_inter_src_q               
            );

        G_3rd_IM_GEN_PIM_Path : for I in 0 to (TX_ANT_NUM-1) generate begin
            U_3rd_IM_GEN : COMPLEX_MULTIPLIER 
            generic map(
                DEVICE                       => DEVICE                       , 
                HOVS                         => pimref_hovs                  , 
            
                INPUT_WIDTH                  => 16                           , 
                RND_EN                       => TRUE                         ,
                RND_BIT                      => 15                           , 
                OUTPUT_WIDTH                 => 16                             
                )
            port map(
                RST                          => rst_pimblk                   , 
                CLK                          => CLK_PIMD                     , 
            
                DATA_VLD_IN                  => pimd_refsrc_in_vld(I)        , 
                ADATA_I_IN                   => pimd_refsrc_in_i(I)          , 
                ADATA_Q_IN                   => pimd_refsrc_in_q(I)          , 
                                                               
                BDATA_I_IN                   => pimd_inter_src_i(I)          , 
                BDATA_Q_IN                   => pimd_inter_src_q(I)          , 
               
                DATA_VLD_OUT                 => pimd_mixps_in_vld(I)         , 
                DATA_I_OUT                   => pimd_mixps_in_i(I)           ,
                DATA_Q_OUT                   => pimd_mixps_in_q(I)                
                );
        end generate;

    end generate; -- ~ INTER PIM

    G_SELECTABLE_PIM : if (PIMD_BLK_TYPE = "SELECTABLE") generate begin  -- SELECTABLE PIM 

        G_SLTB_Gain_N_Delay_Compensator_TX_GEN : for I in 0 to (TX_ANT_NUM-1) generate begin
            U_INTERB_COARSE_DLY_I : BUF_SAMPLE_DLY generic map("BLOCK", "CLOCK", 16, 11) port map(clk_unstable, CLK_UL, DL_INTERB_CDLY_VALUE_IN(I), DL_PIM_INTERBAND_VLD_IN(I), DL_PIM_INTERBAND_I_IN(I), pimd_interb_cdly_out_i(I));
            U_INTERB_COARSE_DLY_Q : BUF_SAMPLE_DLY generic map("BLOCK", "CLOCK", 16, 11) port map(clk_unstable, CLK_UL, DL_INTERB_CDLY_VALUE_IN(I), DL_PIM_INTERBAND_VLD_IN(I), DL_PIM_INTERBAND_Q_IN(I), pimd_interb_cdly_out_q(I));
            U_InterBand_Gain_Compensator : PATH_DGATT 
            generic map(
                DEVICE                       => DEVICE                       , 
                RND_BIT                      => interb_duc_gain_rnd_bit      ,
                HOVS                         => interb_duc_gain_hovs          
                )
            port map(
                RST                          => clk_unstable                 , 
                CLK                          => CLK_UL                       , 
            
                DATA_VALID_IN                => DL_PIM_INTERBAND_VLD_IN(I)   , 
                DATA_I_IN                    => pimd_interb_cdly_out_i(I)    , 
                DATA_Q_IN                    => pimd_interb_cdly_out_q(I)    , 
            
                DGATT_VAL                    => PIM_INTERBAND_DUC_GAIN_IN(I) , 
            
                DATA_VALID_OUT               => pimd_interb_att_out_vld(I)   , 
                DATA_I_OUT                   => pimd_interb_att_out_i(I)     , 
                DATA_Q_OUT                   => pimd_interb_att_out_q(I)       
                );
        end generate;


        G_SLTB_DUC_Upsamp_x1 : if (interband_upsamp_ratio = 1) generate begin  

            pimd_upsamp_out_vld <= pimd_interb_att_out_vld; 
            pimd_upsamp_out_i   <= pimd_interb_att_out_i; 
            pimd_upsamp_out_q   <= pimd_interb_att_out_q; 
        end generate;    

        G_SLTB_DUC_Upsamp_x2 : if (interband_upsamp_ratio = 2) generate begin  
            G_InterBand_Upsamp_x2_TX_GEN : for I in 0 to (TX_ANT_NUM-1) generate begin
                U_InterBand_HBFx2 : hbf_i_comm 
                generic map(
                    HOVS                        => 1          
                    )
                port map(
                    RST                         => clk_unstable              , 
                    CLK                         => CLK_PIMD                  , 
                
                    INPUT_FRAME                 => pimd_interb_att_out_vld(I), 
                    INPUT_VALID                 => pimd_interb_att_out_vld(I), 
                    INPUT_DATA_I                => pimd_interb_att_out_i(I)  , 
                    INPUT_DATA_Q                => pimd_interb_att_out_q(I)  , 
                
                    OUTPUT_FRAME                => open                      ,
                    OUTPUT_VALID                => pimd_upsamp_out_vld(I)    ,
                    OUTPUT_DATA_I               => pimd_upsamp_out_i(I)      ,
                    OUTPUT_DATA_Q               => pimd_upsamp_out_q(I)        
                    );
            end generate;
        end generate;

        G_SLTB_DUC_Upsamp_x3 : if (interband_upsamp_ratio = 3) generate begin  
            U_InterBand_Resamp_x3 : fir_i3_comm 
            generic map(
                ANT_NUM                     => TX_ANT_NUM               ,
                PASSBAND                    => 60 
                )
            port map(
                RST_W(0)                    => clk_unstable              , 
                RST_W(1)                    => clk_unstable              , 
                RST_W(2)                    => clk_unstable              , 
                RST_W(3)                    => clk_unstable              , 
                RST_R(0)                    => clk_unstable              , 
                RST_R(1)                    => clk_unstable              , 
                RST_R(2)                    => clk_unstable              , 
                RST_R(3)                    => clk_unstable              , 
                CLK_W                       => CLK_UL                    , 
                CLK_R                       => CLK_PIMD                  , 
            
                DATA_IN_VALID               => pimd_interb_att_out_vld(0), 
                DATA_IN_I                   => pimd_interb_att_out_i     ,
                DATA_IN_Q                   => pimd_interb_att_out_q     ,
            
                BUF_COLLISION_FLAG          => open                      ,
                DATA_OUT_VALID              => pimd_upsamp_out_vld       ,
                DATA_OUT_I                  => pimd_upsamp_out_i         ,
                DATA_OUT_Q                  => pimd_upsamp_out_q           
                );
        end generate;
        
        P_PIM_SLTB_Detector_OnOff : process(rst_pimblk, CLK_PIMD) begin
            if (rst_pimblk = '1') then
                pimd_interb_fdly_in_vld                 <= (others => '0');
                pimd_interb_fdly_in_i                   <= (others => (others => '0'));
                pimd_interb_fdly_in_q                   <= (others => (others => '0'));
            elsif (CLK_PIMD'event) and (CLK_PIMD = '1') then
                for I in 0 to (TX_ANT_NUM-1) loop
                    if (pim_detector_on_pimclk_sh(I)(0) = '1') then
                        pimd_interb_fdly_in_vld(I)      <= pimd_upsamp_out_vld(I);

                        if (pimd_upsamp_out_vld(I) = '1') then
                            pimd_interb_fdly_in_i(I)    <= pimd_upsamp_out_i(I);
                            pimd_interb_fdly_in_q(I)    <= pimd_upsamp_out_q(I);
                        else
                            pimd_interb_fdly_in_i(I)    <= pimd_interb_fdly_in_i(I);
                            pimd_interb_fdly_in_q(I)    <= pimd_interb_fdly_in_q(I);
                        end if;
                    else
                        pimd_interb_fdly_in_vld(I)      <= '0';
                        pimd_interb_fdly_in_i(I)        <= (others => '0');
                        pimd_interb_fdly_in_q(I)        <= (others => '0');
                    end if;
                end loop;
            end if;
        end process;

        G_PIMREF_SLTB_DUC_Delay_Buffer_TX_GEN : for I in 0 to (TX_ANT_NUM-1) generate begin

            U_INTERB_FINE_DLY_I : SRL16E_WRAP generic map(DEVICE, 16) port map(CLK_PIMD, pimd_interb_fdly_in_i(I), DL_INTERB_FDLY_VALUE_IN(I), pimd_interb_fdly_out_i(I));
            U_INTERB_FINE_DLY_Q : SRL16E_WRAP generic map(DEVICE, 16) port map(CLK_PIMD, pimd_interb_fdly_in_q(I), DL_INTERB_FDLY_VALUE_IN(I), pimd_interb_fdly_out_q(I));

            U_INTRA_COARSE_DLY_I : BUF_SAMPLE_DLY generic map("BLOCK", "SAMPLE_RATE", 16, 12) port map(clk_unstable, CLK_PIMD, DL_INTRAB_DLY_VALUE_IN(I), DL_PIM_REF_VLD_IN(I), pimd_ref_in_i(I), pimd_intra_fdly_in_i(I));
            U_INTRA_COARSE_DLY_Q : BUF_SAMPLE_DLY generic map("BLOCK", "SAMPLE_RATE", 16, 12) port map(clk_unstable, CLK_PIMD, DL_INTRAB_DLY_VALUE_IN(I), DL_PIM_REF_VLD_IN(I), pimd_ref_in_q(I), pimd_intra_fdly_in_q(I));

        end generate;
---- new ~
        U_PIMD_IM3_GEN : PIMD_IM3_GEN
        generic map(
            DEVICE                       => DEVICE                      , --: string  := "ULTRASCALE";
            HOVS                         => pimref_hovs                 , --: natural :=           1 ;
            TX_ANT_NUM                   => TX_ANT_NUM                  , --: natural :=           4 ;
            VERSION                      => "A"                           --: string  := "A"  -- A : ATnT DB AWS/PCS 's PCS
            )
        port map(
            RST                          => rst_pimblk                  , --: in  std_logic;           -- Reset, Active High
            CLK                          => CLK_PIMD                    , --: in  std_logic;
        
            INTRA_BAND_SEL_IN            => INTRA_BAND_SEL_IN           , --: in  std_logic;
            INTER_BAND_TYPE1_SEL_IN      => INTER_BAND_TYPE1_SEL_IN     , --: in  std_logic_vector( 1 downto 0);
            INTER_BAND_TYPE2_SEL_IN      => INTER_BAND_TYPE2_SEL_IN     , --: in  std_logic_vector( 1 downto 0);
        
            PIM_CFR_REF_VLD_IN           => pimd_ref_in_vld             , --: in  std_logic_vector( TX_ANT_NUM-1 downto 0);
            PIM_CFR_REF_I_IN             => pimd_intra_fdly_in_i        , --: in  std_logic_array16(TX_ANT_NUM-1 downto 0);
            PIM_CFR_REF_Q_IN             => pimd_intra_fdly_in_q        , --: in  std_logic_array16(TX_ANT_NUM-1 downto 0);
        
            PIM_INTERB_SRC_I_IN          => pimd_interb_fdly_out_i      , --: in  std_logic_array16(TX_ANT_NUM-1 downto 0);
            PIM_INTERB_SRC_Q_IN          => pimd_interb_fdly_out_q      , --: in  std_logic_array16(TX_ANT_NUM-1 downto 0);
        
            PIM_INTRA_BAND_VLD_OUT       => pimd_im3gen_intra_out_vld   , --: out std_logic_vector( TX_ANT_NUM-1 downto 0);
            PIM_INTRA_BAND_I_OUT         => pimd_im3gen_intra_out_i     , --: out std_logic_array16(TX_ANT_NUM-1 downto 0);
            PIM_INTRA_BAND_Q_OUT         => pimd_im3gen_intra_out_q     , --: out std_logic_array16(TX_ANT_NUM-1 downto 0);
        
            PIM_INTER_TYPE1_I_OUT        => pimd_im3gen_inter1_out_i    , --: out std_logic_array16(TX_ANT_NUM-1 downto 0);
            PIM_INTER_TYPE1_Q_OUT        => pimd_im3gen_inter1_out_q    , --: out std_logic_array16(TX_ANT_NUM-1 downto 0);
        
            PIM_INTER_TYPE2_I_OUT        => pimd_im3gen_inter2_out_i    , --: out std_logic_array16(TX_ANT_NUM-1 downto 0);
            PIM_INTER_TYPE2_Q_OUT        => pimd_im3gen_inter2_out_q    , --: out std_logic_array16(TX_ANT_NUM-1 downto 0) 
            
            DBG_PIM_SUM_I_OUT            => dbg_pimd_im3gen_sum_out_i   , --: out std_logic_array16(TX_ANT_NUM-1 downto 0);
            DBG_PIM_SUM_Q_OUT            => dbg_pimd_im3gen_sum_out_q     --: out std_logic_array16(TX_ANT_NUM-1 downto 0) 
            );
       
        pimd_refsrc_in_vld          <= (others=>'0');
        pimd_refsrc_in_i            <= (others=>(others=>'0'));
        pimd_refsrc_in_q            <= (others=>(others=>'0'));
        pimd_inter_src_i            <= (others=>(others=>'0'));
        pimd_inter_src_q            <= (others=>(others=>'0'));
        pimd_mixps_in_vld           <= (others=>'0');
        pimd_mixps_in_i             <= (others=>(others=>'0'));
        pimd_mixps_in_q             <= (others=>(others=>'0'));

        U_QUARTER_SHIFT_INTRA : NCO_QUARTER_SHIFT
        generic map(
            DEVICE                       => DEVICE                          , --: string  := "ULTRASCALE";
            HOVS                         => pimref_hovs                     , --: natural :=           1 ;
            TX_ANT_NUM                   => TX_ANT_NUM                        --: natural :=           4 
            )
        port map(
            RST                          => rst_pimblk                      , --: in  std_logic;           -- Reset, Active High
            CLK                          => CLK_PIMD                        , --: in  std_logic;
        
            SHIFT_DIRECTION_IN           => SHIFT_DIRECTION_INTRA_IN        , --: in  std_logic_array2(TX_ANT_NUM-1 downto 0);
        
            DATA_VLD_IN                  => pimd_im3gen_intra_out_vld       , --: in  std_logic_vector( TX_ANT_NUM-1 downto 0);
            DATA_I_IN                    => pimd_im3gen_intra_out_i         , --: in  std_logic_array16(TX_ANT_NUM-1 downto 0);
            DATA_Q_IN                    => pimd_im3gen_intra_out_q         , --: in  std_logic_array16(TX_ANT_NUM-1 downto 0);
       
            DATA_VLD_OUT                 => pimd_quar_shfit_intra_out_vld   ,
            DATA_I_OUT                   => pimd_quar_shfit_intra_out_i     , --: out std_logic_array16(TX_ANT_NUM-1 downto 0);
            DATA_Q_OUT                   => pimd_quar_shfit_intra_out_q       --: out std_logic_array16(TX_ANT_NUM-1 downto 0) 
            );

        -- U_QUARTER_SHIFT_INTER1 : NCO_QUARTER_SHIFT
        -- generic map(
        --     DEVICE                       => DEVICE                          , --: string  := "ULTRASCALE";
        --     HOVS                         => pimref_hovs                     , --: natural :=           1 ;
        --     TX_ANT_NUM                   => TX_ANT_NUM                        --: natural :=           4 
        --     )
        -- port map(
        --     RST                          => rst_pimblk                      , --: in  std_logic;           -- Reset, Active High
        --     CLK                          => CLK_PIMD                        , --: in  std_logic;
        
        --     SHIFT_DIRECTION_IN           => SHIFT_DIRECTION_INTER1_IN       , --: in  std_logic_array2(TX_ANT_NUM-1 downto 0);
        
        --     DATA_VLD_IN                  => pimd_im3gen_intra_out_vld       , --: in  std_logic_vector( TX_ANT_NUM-1 downto 0);
        --     DATA_I_IN                    => pimd_im3gen_inter1_out_i        , --: in  std_logic_array16(TX_ANT_NUM-1 downto 0);
        --     DATA_Q_IN                    => pimd_im3gen_inter1_out_q        , --: in  std_logic_array16(TX_ANT_NUM-1 downto 0);
       
        --     DATA_VLD_OUT                 => open                            ,
        --     DATA_I_OUT                   => pimd_quar_shfit_inter1_out_i    , --: out std_logic_array16(TX_ANT_NUM-1 downto 0);
        --     DATA_Q_OUT                   => pimd_quar_shfit_inter1_out_q      --: out std_logic_array16(TX_ANT_NUM-1 downto 0) 
        -- );

        pimd_quar_shfit_inter1_out_i    <=  pimd_im3gen_inter1_out_i;
        pimd_quar_shfit_inter1_out_q    <=  pimd_im3gen_inter1_out_q;

        -- U_QUARTER_SHIFT_INTER2 : NCO_QUARTER_SHIFT
        -- generic map(
        --     DEVICE                       => DEVICE                          , --: string  := "ULTRASCALE";
        --     HOVS                         => pimref_hovs                     , --: natural :=           1 ;
        --     TX_ANT_NUM                   => TX_ANT_NUM                        --: natural :=           4 
        --     )
        -- port map(
        --     RST                          => rst_pimblk                      , --: in  std_logic;           -- Reset, Active High
        --     CLK                          => CLK_PIMD                        , --: in  std_logic;
        
        --     SHIFT_DIRECTION_IN           => SHIFT_DIRECTION_INTER2_IN       , --: in  std_logic_array2(TX_ANT_NUM-1 downto 0);
        
        --     DATA_VLD_IN                  => pimd_im3gen_intra_out_vld       , --: in  std_logic_vector( TX_ANT_NUM-1 downto 0);
        --     DATA_I_IN                    => pimd_im3gen_inter2_out_i        , --: in  std_logic_array16(TX_ANT_NUM-1 downto 0);
        --     DATA_Q_IN                    => pimd_im3gen_inter2_out_q        , --: in  std_logic_array16(TX_ANT_NUM-1 downto 0);
       
        --     DATA_VLD_OUT                 => open                            ,
        --     DATA_I_OUT                   => pimd_quar_shfit_inter2_out_i    , --: out std_logic_array16(TX_ANT_NUM-1 downto 0);
        --     DATA_Q_OUT                   => pimd_quar_shfit_inter2_out_q      --: out std_logic_array16(TX_ANT_NUM-1 downto 0) 
        -- );

        pimd_quar_shfit_inter2_out_i    <=  pimd_im3gen_inter2_out_i;
        pimd_quar_shfit_inter2_out_q    <=  pimd_im3gen_inter2_out_q;

        U_PIMD_MIXER_INTRA : NCO_SYMMETRY 
        generic map(
            DEVICE                       => DEVICE                       , 
        
            HOVS                         => pimref_hovs                  , 
            SYMMETRY                     => pimref_nco_symmetry          , 
                                                                           
            POS_SHIFTH_PATH_NUM          => TX_ANT_NUM                   , 
            NEG_SHIFTH_PATH_NUM          => TX_ANT_NUM                   , 
            NCO_WIDTH                    => 16                           , 
            RES_VAL                      => pimref_nco_resolution          
            )
        port map(
            RST                          => RST_PIMD                     , 
            CLK                          => CLK_PIMD                     , 
        
            NCO_WREN                     => PIM_SLTB_INTRA_NCO_WREN_IN   , 
            NCO_WORD                     => PIM_SLTB_INTRA_NCO_WORD_IN   , 
        
            NCO_FREQ_COMP_OFFSET         => (others => '0')              , 
        
            DATA_P_SH_VLD_IN             => pimd_quar_shfit_intra_out_vld,
            DATA_P_SH_I_IN               => pimd_quar_shfit_intra_out_i  ,
            DATA_P_SH_Q_IN               => pimd_quar_shfit_intra_out_q  ,
        
            DATA_P_SH_VLD_OUT            => pimd_mixer_beta_intra_out_vld,
            DATA_P_SH_I_OUT              => pimd_mixer_beta_intra_out_i  ,
            DATA_P_SH_Q_OUT              => pimd_mixer_beta_intra_out_q  ,
        
            DATA_N_SH_VLD_IN             => (others=>'0')                , 
            DATA_N_SH_I_IN               => (others=> (others=>'0') )    , 
            DATA_N_SH_Q_IN               => (others=> (others=>'0') )    , 
        
            DATA_N_SH_VLD_OUT            => open                         , 
            DATA_N_SH_I_OUT              => open                         , 
            DATA_N_SH_Q_OUT              => open                           
            );

        --U_PIMD_MIXER_INTER1 : NCO_SYMMETRY 
        --generic map(
        --    DEVICE                       => DEVICE                       , 
        --
        --    HOVS                         => pimref_hovs                  , 
        --    SYMMETRY                     => pimref_nco_symmetry          , 
        --                                                                   
        --    POS_SHIFTH_PATH_NUM          => TX_ANT_NUM                   , 
        --    NEG_SHIFTH_PATH_NUM          => TX_ANT_NUM                   , 
        --    NCO_WIDTH                    => 16                           , 
        --    RES_VAL                      => pimref_nco_resolution          
        --    )
        --port map(
        --    RST                          => RST_PIMD                     , 
        --    CLK                          => CLK_PIMD                     , 
        --
        --    NCO_WREN                     => PIM_SLTB_INTER1_NCO_WREN_IN  , 
        --    NCO_WORD                     => PIM_SLTB_INTER1_NCO_WORD_IN  , 
        --
        --    NCO_FREQ_COMP_OFFSET         => (others => '0')              , 
        --
        --    DATA_P_SH_VLD_IN             => pimd_quar_shfit_intra_out_vld,
        --    DATA_P_SH_I_IN               => pimd_quar_shfit_inter1_out_i  ,
        --    DATA_P_SH_Q_IN               => pimd_quar_shfit_inter1_out_q  ,
        --
        --    DATA_P_SH_VLD_OUT            => open                          ,
        --    DATA_P_SH_I_OUT              => pimd_mixer_beta_inter1_out_i  ,
        --    DATA_P_SH_Q_OUT              => pimd_mixer_beta_inter1_out_q  ,
        --
        --    DATA_N_SH_VLD_IN             => (others=>'0')                , 
        --    DATA_N_SH_I_IN               => (others=> (others=>'0') )    , 
        --    DATA_N_SH_Q_IN               => (others=> (others=>'0') )    , 
        --
        --    DATA_N_SH_VLD_OUT            => open                         , 
        --    DATA_N_SH_I_OUT              => open                         , 
        --    DATA_N_SH_Q_OUT              => open                           
        --    );

        pimd_mixer_beta_inter1_out_i <= pimd_quar_shfit_inter1_out_i;
        pimd_mixer_beta_inter1_out_q <= pimd_quar_shfit_inter1_out_q;

        -- U_PIMD_MIXER_INTER2 : NCO_SYMMETRY 
        -- generic map(
        --     DEVICE                       => DEVICE                       , 
        
        --     HOVS                         => pimref_hovs                  , 
        --     SYMMETRY                     => pimref_nco_symmetry          , 
                                                                           
        --     POS_SHIFTH_PATH_NUM          => TX_ANT_NUM                   , 
        --     NEG_SHIFTH_PATH_NUM          => TX_ANT_NUM                   , 
        --     NCO_WIDTH                    => 16                           , 
        --     RES_VAL                      => pimref_nco_resolution          
        --     )
        -- port map(
        --     RST                          => RST_PIMD                     , 
        --     CLK                          => CLK_PIMD                     , 
        
        --     NCO_WREN                     => PIM_SLTB_INTER2_NCO_WREN_IN  , 
        --     NCO_WORD                     => PIM_SLTB_INTER2_NCO_WORD_IN  , 
        
        --     NCO_FREQ_COMP_OFFSET         => (others => '0')              , 
        
        --     DATA_P_SH_VLD_IN             => pimd_quar_shfit_intra_out_vld,
        --     DATA_P_SH_I_IN               => pimd_quar_shfit_inter2_out_i  ,
        --     DATA_P_SH_Q_IN               => pimd_quar_shfit_inter2_out_q  ,
        
        --     DATA_P_SH_VLD_OUT            => open                          ,
        --     DATA_P_SH_I_OUT              => pimd_mixer_beta_inter2_out_i  ,
        --     DATA_P_SH_Q_OUT              => pimd_mixer_beta_inter2_out_q  ,
        
        --     DATA_N_SH_VLD_IN             => (others=>'0')                , 
        --     DATA_N_SH_I_IN               => (others=> (others=>'0') )    , 
        --     DATA_N_SH_Q_IN               => (others=> (others=>'0') )    , 
        
        --     DATA_N_SH_VLD_OUT            => open                         , 
        --     DATA_N_SH_I_OUT              => open                         , 
        --     DATA_N_SH_Q_OUT              => open                           
        --     );

        pimd_mixer_beta_inter2_out_i    <=  pimd_quar_shfit_inter2_out_i;
        pimd_mixer_beta_inter2_out_q    <=  pimd_quar_shfit_inter2_out_q;

        G_SLTB_TYPE_1 : if ( C_SELECTABLE_TYPE = 1 ) generate begin

            G_SUM_DLY : for I in 0 to (TX_ANT_NUM-1) generate begin
                -- path 1
                process (CLK_PIMD) 
                begin
                    if ( rising_edge(CLK_PIMD) ) then
                        pimd_sum_inter_17b_i(I)  <= ( pimd_mixer_beta_inter1_out_i(I)(15) & pimd_mixer_beta_inter1_out_i(I)(15 downto 0) ) + ( pimd_mixer_beta_inter2_out_i(I)(15) & pimd_mixer_beta_inter2_out_i(I)(15 downto 0) );
                        pimd_sum_inter_17b_q(I)  <= ( pimd_mixer_beta_inter1_out_q(I)(15) & pimd_mixer_beta_inter1_out_q(I)(15 downto 0) ) + ( pimd_mixer_beta_inter2_out_q(I)(15) & pimd_mixer_beta_inter2_out_q(I)(15 downto 0) );
                    end if;
                end process;

                U_SLTB_SAT_I_01          : SAT_SIGN generic map(TRUE, 17, 16) port map(RST_PIMD, CLK_PIMD, pimd_sum_inter_17b_i(I), pimd_sum_inter_sat_i(I) );
                U_SLTB_SAT_Q_01          : SAT_SIGN generic map(TRUE, 17, 16) port map(RST_PIMD, CLK_PIMD, pimd_sum_inter_17b_q(I), pimd_sum_inter_sat_q(I) );
                -- path 2
                U_SLTB_DLY_VLD_I_01      : SRL16E_DLY generic map(DEVICE, TRUE, 16, 3) port map (RST_PIMD, CLK_PIMD, pimd_mixer_beta_intra_out_i(I), pimd_mixer_beta_intra_dly_i(I) );
                U_SLTB_DLY_VLD_Q_01      : SRL16E_DLY generic map(DEVICE, TRUE, 16, 3) port map (RST_PIMD, CLK_PIMD, pimd_mixer_beta_intra_out_q(I), pimd_mixer_beta_intra_dly_q(I) );

                -- path 1
                U_SLTB_INTRA_FINE_DLY_I  : BUF_SAMPLE_DLY generic map("BLOCK", "CLOCK", 16, 12) port map(clk_unstable, CLK_PIMD, PIMDLY_SLTB1_VALUE_IN(I), pimd_mixer_beta_intra_out_vld(I), pimd_mixer_beta_intra_dly_i(I), pimd_mixer_beta_intra_dly2_i(I));
                U_SLTB_INTRA_FINE_DLY_Q  : BUF_SAMPLE_DLY generic map("BLOCK", "CLOCK", 16, 12) port map(clk_unstable, CLK_PIMD, PIMDLY_SLTB1_VALUE_IN(I), pimd_mixer_beta_intra_out_vld(I), pimd_mixer_beta_intra_dly_q(I), pimd_mixer_beta_intra_dly2_q(I));
                -- path 2
                U_SLTB_INTERB_FINE_DLY_I : BUF_SAMPLE_DLY generic map("BLOCK", "CLOCK", 16, 12) port map(clk_unstable, CLK_PIMD, PIMDLY_SLTB2_VALUE_IN(I), pimd_mixer_beta_intra_out_vld(I), pimd_sum_inter_sat_i(I),       pimd_inter_dly2_i(I));
                U_SLTB_INTERB_FINE_DLY_Q : BUF_SAMPLE_DLY generic map("BLOCK", "CLOCK", 16, 12) port map(clk_unstable, CLK_PIMD, PIMDLY_SLTB2_VALUE_IN(I), pimd_mixer_beta_intra_out_vld(I), pimd_sum_inter_sat_q(I),       pimd_inter_dly2_q(I));
            end generate;

            -- CORE 1
            U_PIM_SLTB_INTRA_LUT_CORE : DPD_CORE        generic map(
                DEVICE                       => DEVICE                       ,
                                                                             
                TX_ANT_NUM                   => TX_ANT_NUM                   ,
                HOVS                         => pimref_hovs                  ,
            
                DPD_LUT_OPTIMIZED            => PIMD_CORE_LUT_OPTIMIZED      ,
                DPD_LUT_MEM_DEPTH            => PIMD_CORE_LUT_MEM_DEPTH      , 
                DPD_LUT_RBTEST               => PIMD_CORE_LUT_RBTEST         , 
                DPD_CORE_QPOINT_SEL          => PIMD_CORE_QPOINT_SEL         , 
                DPD_CORE_LUT_DIMENSION       => PIMD_CORE_LUT_DIMENSION      , 
                DPD_CORE_LUT_NUM             => PIMD_CORE_LUT_NUM            ,
                DPD_CORE_TAP_NUM             => PIMD_CORE_TAP_NUM            ,
                DPD_CORE_RND_BIT             => 10                            
                )
            port map(
                RST_DPD                      => RST_PIMD                     , 
                CLK_DPD                      => CLK_PIMD                     , 
            
                DPD_CORE_VLD_IN              => pimd_mixer_beta_intra_out_vld, 
                DPD_CORE_I_IN                => pimd_mixer_beta_intra_dly2_i , 
                DPD_CORE_Q_IN                => pimd_mixer_beta_intra_dly2_q , 
                                                 
                DPD_CORE_VLD_OUT             => pimd_core_out_vld            , 
                DPD_CORE_I_OUT               => pimd_sltb1_core_out_i        , 
                DPD_CORE_Q_OUT               => pimd_sltb1_core_out_q        , 
            
                DPD_CORE_BYPASS_IN           => PIM_CORE_BYPASS_IN           ,
                                                                             
                DPD_GAIN_INDEX_IN            => PIM_SLTB1_GAIN_INDEX_IN      ,
                DPD_QPOINT_SEL_IN            => PIM_SLTB1_QPOINT_SEL_IN      ,
            
                RST_CPU                      => RST_CPU                      ,
                CLK_CPU                      => CLK_CPU                      ,
            
                DPD_LUT_RB_TEST_EN_IN        => '0'                          ,
                                                                             
                DPD_LUT_SWITCH_CDC_STRB_IN   => '0'                          ,
                DPD_LUT_INPUT_SWITCH_IN      => (others=>'0')                , 
                DPD_LUT_OUTPUT_SWITCH_IN     => (others=>'0')                , 
                                                                             
                DPD_LUT_UPDATE_SW_IN         => PIM_SLTB1_LUT_UPDATE_SW_IN   , 
                DPD_LUT_WREN_IN              => PIM_SLTB1_LUT_WREN_IN        , 
                DPD_LUT_RDEN_IN              => PIM_SLTB1_LUT_RDEN_IN        , 
                DPD_LUT_ADDR_IN              => PIM_SLTB1_LUT_ADDR_IN        , 
                DPD_LUT_WDATA_IN             => PIM_SLTB1_LUT_WDATA_IN       , 
                DPD_LUT_RDATA_OUT            => PIM_SLTB1_LUT_RDATA_OUT              
                );

            -- CORE 2
            U_PIM_SLTB_INTER_LUT_CORE : DPD_CORE 
            generic map(
                DEVICE                       => DEVICE                       ,
                                                                             
                TX_ANT_NUM                   => TX_ANT_NUM                   ,
                HOVS                         => pimref_hovs                  ,
            
                DPD_LUT_OPTIMIZED            => PIMD_CORE_LUT_OPTIMIZED      ,
                DPD_LUT_MEM_DEPTH            => PIMD_CORE_LUT_MEM_DEPTH      , 
                DPD_LUT_RBTEST               => PIMD_CORE_LUT_RBTEST         , 
                DPD_CORE_QPOINT_SEL          => PIMD_CORE_QPOINT_SEL         , 
                DPD_CORE_LUT_DIMENSION       => PIMD_CORE_LUT_DIMENSION      , 
                DPD_CORE_LUT_NUM             => PIMD_CORE_LUT_NUM            ,
                DPD_CORE_TAP_NUM             => PIMD_CORE_TAP_NUM            ,
                DPD_CORE_RND_BIT             => 10                            
                )
            port map(
                RST_DPD                      => RST_PIMD                     , 
                CLK_DPD                      => CLK_PIMD                     , 
            
                DPD_CORE_VLD_IN              => pimd_mixer_beta_intra_out_vld, 
                DPD_CORE_I_IN                => pimd_inter_dly2_i            , 
                DPD_CORE_Q_IN                => pimd_inter_dly2_q            , 
                                                 
                DPD_CORE_VLD_OUT             => open                         , 
                DPD_CORE_I_OUT               => pimd_sltb2_core_out_i        , 
                DPD_CORE_Q_OUT               => pimd_sltb2_core_out_q        , 
            
                DPD_CORE_BYPASS_IN           => PIM_CORE_BYPASS_IN           ,
                                                                             
                DPD_GAIN_INDEX_IN            => PIM_SLTB2_GAIN_INDEX_IN      ,
                DPD_QPOINT_SEL_IN            => PIM_SLTB2_QPOINT_SEL_IN      ,
            
                RST_CPU                      => RST_CPU                      ,
                CLK_CPU                      => CLK_CPU                      ,
            
                DPD_LUT_RB_TEST_EN_IN        => '0'                          ,
                                                                 
                DPD_LUT_SWITCH_CDC_STRB_IN   => '0'                          ,
                DPD_LUT_INPUT_SWITCH_IN      => (others=>'0')                , 
                DPD_LUT_OUTPUT_SWITCH_IN     => (others=>'0')                , 
                                                                             
                DPD_LUT_UPDATE_SW_IN         => PIM_SLTB2_LUT_UPDATE_SW_IN   , 
                DPD_LUT_WREN_IN              => PIM_SLTB2_LUT_WREN_IN        , 
                DPD_LUT_RDEN_IN              => PIM_SLTB2_LUT_RDEN_IN        , 
                DPD_LUT_ADDR_IN              => PIM_SLTB2_LUT_ADDR_IN        , 
                DPD_LUT_WDATA_IN             => PIM_SLTB2_LUT_WDATA_IN       , 
                DPD_LUT_RDATA_OUT            => PIM_SLTB2_LUT_RDATA_OUT              
                );

            G_PIM_SUM_OUT : for I in 0 to (TX_ANT_NUM-1) generate begin
                -- sum of core in
                process (CLK_PIMD) 
                begin
                    if ( rising_edge(CLK_PIMD) ) then
                        pimd_core_in_sum_17b_i(I)  <= ( pimd_mixer_beta_intra_dly2_i(I)(15) & pimd_mixer_beta_intra_dly2_i(I)(15 downto 0) ) + ( pimd_inter_dly2_i(I)(15) & pimd_inter_dly2_i(I)(15 downto 0) );
                        pimd_core_in_sum_17b_q(I)  <= ( pimd_mixer_beta_intra_dly2_q(I)(15) & pimd_mixer_beta_intra_dly2_q(I)(15 downto 0) ) + ( pimd_inter_dly2_q(I)(15) & pimd_inter_dly2_q(I)(15 downto 0) );
                    end if;
                end process;
                
                U_SLTB_SAT_I_03  : SAT_SIGN generic map(TRUE, 17, 16) port map(RST_PIMD, CLK_PIMD, pimd_core_in_sum_17b_i(I), pimd_core_in_sum_out_i(I) );
                U_SLTB_SAT_Q_03  : SAT_SIGN generic map(TRUE, 17, 16) port map(RST_PIMD, CLK_PIMD, pimd_core_in_sum_17b_q(I), pimd_core_in_sum_out_q(I) );
            
                -- sum of core out 
                process (CLK_PIMD) 
                begin
                    if ( rising_edge(CLK_PIMD) ) then
                        pimd_sum_total_17b_i(I)  <= ( pimd_sltb1_core_out_i(I)(15) & pimd_sltb1_core_out_i(I)(15 downto 0) ) + ( pimd_sltb2_core_out_i(I)(15) & pimd_sltb2_core_out_i(I)(15 downto 0) );
                        pimd_sum_total_17b_q(I)  <= ( pimd_sltb1_core_out_q(I)(15) & pimd_sltb1_core_out_q(I)(15 downto 0) ) + ( pimd_sltb2_core_out_q(I)(15) & pimd_sltb2_core_out_q(I)(15 downto 0) );
                    end if;
                end process;
            
                U_SLTB_SAT_I_02  : SAT_SIGN generic map(TRUE, 17, 16) port map(RST_PIMD, CLK_PIMD, pimd_sum_total_17b_i(I), pimd_sum_total_out_i(I) );
                U_SLTB_SAT_Q_02  : SAT_SIGN generic map(TRUE, 17, 16) port map(RST_PIMD, CLK_PIMD, pimd_sum_total_17b_q(I), pimd_sum_total_out_q(I) );
            
            end generate;
            
            pimd_firlpf_in_vld  <= pimd_core_out_vld;
            pimd_firlpf_in_i    <= pimd_sum_total_out_i  ;
            pimd_firlpf_in_q    <= pimd_sum_total_out_q  ;

            -- SELECTABLE : bypass / INTER : bypassed in NCO_SYMMETRY
            pimd_dly_in_vld     <= pimd_firlpf_out_vld;
            pimd_dly_in_i       <= pimd_firlpf_out_i;
            pimd_dly_in_q       <= pimd_firlpf_out_q;
        end generate;  -- ~ SLTB_TYPE_1
        
        G_SLTB_TYPE_2 : if ( C_SELECTABLE_TYPE = 2 ) generate begin

            G_SUM_DLY : for I in 0 to (TX_ANT_NUM-1) generate begin
                -- path 1
                process (CLK_PIMD) 
                begin
                    if ( rising_edge(CLK_PIMD) ) then
                        pimd_mixer_beta_inter1_out_i_d(I)  <= pimd_mixer_beta_inter1_out_i(I);
                        pimd_mixer_beta_inter1_out_q_d(I)  <= pimd_mixer_beta_inter1_out_q(I);
                        pimd_mixer_beta_inter2_out_i_d(I)  <= pimd_mixer_beta_inter2_out_i(I);
                        pimd_mixer_beta_inter2_out_q_d(I)  <= pimd_mixer_beta_inter2_out_q(I);
                        pimd_mixer_beta_intra_out_i_d(I)   <= pimd_mixer_beta_intra_out_i(I);
                        pimd_mixer_beta_intra_out_q_d(I)   <= pimd_mixer_beta_intra_out_q(I);
                        pimd_mixer_beta_intra_out_i_d2(I)  <= pimd_mixer_beta_intra_out_i_d(I);
                        pimd_mixer_beta_intra_out_q_d2(I)  <= pimd_mixer_beta_intra_out_q_d(I);


                        pimd_pre_lpf_in_18b_tmp_i(I)  <= ( pimd_mixer_beta_inter1_out_i_d(I)(15) & pimd_mixer_beta_inter1_out_i_d(I)(15) & pimd_mixer_beta_inter1_out_i_d(I)(15 downto 0) ) 
                                                       + ( pimd_mixer_beta_inter2_out_i_d(I)(15) & pimd_mixer_beta_inter2_out_i_d(I)(15) & pimd_mixer_beta_inter2_out_i_d(I)(15 downto 0) );
                        pimd_pre_lpf_in_18b_i(I)      <= pimd_pre_lpf_in_18b_tmp_i(I) + ( pimd_mixer_beta_intra_out_i_d2(I)(15) & pimd_mixer_beta_intra_out_i_d2(I)(15) & pimd_mixer_beta_intra_out_i_d2(I)(15 downto 0) );
                                                    
                        pimd_pre_lpf_in_18b_tmp_q(I)  <= ( pimd_mixer_beta_inter1_out_q_d(I)(15) & pimd_mixer_beta_inter1_out_q_d(I)(15) & pimd_mixer_beta_inter1_out_q_d(I)(15 downto 0) )
                                                       + ( pimd_mixer_beta_inter2_out_q_d(I)(15) & pimd_mixer_beta_inter2_out_q_d(I)(15) & pimd_mixer_beta_inter2_out_q_d(I)(15 downto 0) );
                        pimd_pre_lpf_in_18b_q(I)      <= pimd_pre_lpf_in_18b_tmp_q(I) + ( pimd_mixer_beta_intra_out_q_d2(I)(15) & pimd_mixer_beta_intra_out_q_d2(I)(15) & pimd_mixer_beta_intra_out_q_d2(I)(15 downto 0) );
                    end if;
                end process;
                
                U_SLTB_SAT_I_04          : SAT_SIGN generic map(TRUE, 18, 16) port map(RST_PIMD, CLK_PIMD, pimd_pre_lpf_in_18b_i(I),  pimd_pre_lpf_in_16b_i(I) );
                U_SLTB_SAT_Q_04          : SAT_SIGN generic map(TRUE, 18, 16) port map(RST_PIMD, CLK_PIMD, pimd_pre_lpf_in_18b_q(I),  pimd_pre_lpf_in_16b_q(I) );

                -- pre LPF filter
                U_PIMD_LPF_PRE : PFIR_FILTER 
                    generic map(
                        DEVICE                       => DEVICE                          , 
                        PIM_MODE                     => TRUE                            ,                         
                        HOVS                         => pimref_hovs                     , 
                        SYMMETRY                     => "ODD"                           , 
                        COEF_FIX                     => TRUE                            , 
                        -- COEF_NUM                     => 39                              , 
                        COEF_NUM                     => 12                              , 
                        RND_BIT                      => 15                                
                        )
                    port map(
                        RST_DSP                      => clk_unstable                    , 
                        CLK_DSP                      => CLK_PIMD                        , 
                    
                        DATA_VLD_IN                  => pimd_mixer_beta_intra_out_vld(I), 
                        DATA_I_IN                    => pimd_pre_lpf_in_16b_i(I)         , 
                        DATA_Q_IN                    => pimd_pre_lpf_in_16b_q(I)         , 
                    
                        BYPASS_IN                    => PIM_FILTER_BYPASS_IN(I)         , 
                    
                        DATA_VLD_OUT                 => pimd_pre_firlpf_out_vld(I)          , 
                        DATA_I_OUT                   => pimd_pre_firlpf_out_i(I)        , 
                        DATA_Q_OUT                   => pimd_pre_firlpf_out_q(I)        , 
                    
                        RST_CPU                      => RST_CPU                         , 
                        CLK_CPU                      => CLK_CPU                         , 
                    
                        COEF_WR_EN                   => PIM_FILTER_COEF_WR_EN_IN(I)     , 
                        COEF_RD_EN                   => PIM_FILTER_COEF_RD_EN_IN(I)     , 
                        COEF_WR_DN                   => PIM_FILTER_COEF_WR_DN_IN(I)     , 
                        COEF_ADDR                    => PIM_FILTER_COEF_ADDR_IN         , 
                        COEF_WR_DATA                 => PIM_FILTER_COEF_WR_DATA_IN      , 
                        COEF_RD_DATA                 => pimd_firlpf_coef_rd_data(I)     
                        );

                process (CLK_PIMD) 
                begin
                    if ( rising_edge(CLK_PIMD) ) then
                        -- pimd_pre_firlpf_out_vld(I)    <= pimd_mixer_beta_intra_out_vld(I);

                        pimd_pre_lpf_out_17b_i(I)     <= pimd_pre_firlpf_out_i(I) & '0';
                        pimd_pre_lpf_out_17b_q(I)     <= pimd_pre_firlpf_out_q(I) & '0';
                        pimd_pre_lpf_out_18b_i(I)     <= pimd_pre_firlpf_out_i(I) & "00";
                        pimd_pre_lpf_out_18b_q(I)     <= pimd_pre_firlpf_out_q(I) & "00";
                        pimd_pre_lpf_out_19b_i(I)     <= pimd_pre_firlpf_out_i(I) & "000";
                        pimd_pre_lpf_out_19b_q(I)     <= pimd_pre_firlpf_out_q(I) & "000";

                        pimd_pre_firlpf_out_i_d(I)    <= pimd_pre_firlpf_out_i(I); 
                        pimd_pre_firlpf_out_q_d(I)    <= pimd_pre_firlpf_out_q(I); 
                        pimd_pre_lpf_out_sat_g0_i(I)  <= pimd_pre_firlpf_out_i_d(I); 
                        pimd_pre_lpf_out_sat_g0_q(I)  <= pimd_pre_firlpf_out_q_d(I);
                    end if;
                end process;

                U_SLTB_SAT_I_06          : SAT_SIGN generic map(TRUE, 17, 16) port map(RST_PIMD, CLK_PIMD, pimd_pre_lpf_out_17b_i(I), pimd_pre_lpf_out_sat_g1_i(I) );
                U_SLTB_SAT_Q_06          : SAT_SIGN generic map(TRUE, 17, 16) port map(RST_PIMD, CLK_PIMD, pimd_pre_lpf_out_17b_q(I), pimd_pre_lpf_out_sat_g1_q(I) );
                U_SLTB_SAT_I_07          : SAT_SIGN generic map(TRUE, 18, 16) port map(RST_PIMD, CLK_PIMD, pimd_pre_lpf_out_18b_i(I), pimd_pre_lpf_out_sat_g2_i(I) );
                U_SLTB_SAT_Q_07          : SAT_SIGN generic map(TRUE, 18, 16) port map(RST_PIMD, CLK_PIMD, pimd_pre_lpf_out_18b_q(I), pimd_pre_lpf_out_sat_g2_q(I) );
                U_SLTB_SAT_I_08          : SAT_SIGN generic map(TRUE, 19, 16) port map(RST_PIMD, CLK_PIMD, pimd_pre_lpf_out_19b_i(I), pimd_pre_lpf_out_sat_g3_i(I) );
                U_SLTB_SAT_Q_08          : SAT_SIGN generic map(TRUE, 19, 16) port map(RST_PIMD, CLK_PIMD, pimd_pre_lpf_out_19b_q(I), pimd_pre_lpf_out_sat_g3_q(I) );

                process (CLK_PIMD) 
                begin
                    s_pim_bit_shift_sel_in  <= PIM_BIT_SHIFT_SEL_IN;

                    if ( rising_edge(CLK_PIMD) ) then
                        if ( s_pim_bit_shift_sel_in = "00" ) then
                            pimd_pre_lpf_out_sat_i(I)  <= pimd_pre_lpf_out_sat_g0_i(I);
                            pimd_pre_lpf_out_sat_q(I)  <= pimd_pre_lpf_out_sat_g0_q(I);
                        elsif ( s_pim_bit_shift_sel_in = "01" ) then
                            pimd_pre_lpf_out_sat_i(I)  <= pimd_pre_lpf_out_sat_g1_i(I);
                            pimd_pre_lpf_out_sat_q(I)  <= pimd_pre_lpf_out_sat_g1_q(I);
                        elsif ( s_pim_bit_shift_sel_in = "10" ) then
                            pimd_pre_lpf_out_sat_i(I)  <= pimd_pre_lpf_out_sat_g2_i(I);
                            pimd_pre_lpf_out_sat_q(I)  <= pimd_pre_lpf_out_sat_g2_q(I);
                        elsif ( s_pim_bit_shift_sel_in = "11" ) then
                            pimd_pre_lpf_out_sat_i(I)  <= pimd_pre_lpf_out_sat_g3_i(I);
                            pimd_pre_lpf_out_sat_q(I)  <= pimd_pre_lpf_out_sat_g3_q(I);
                        end if;
                    end if;
                end process;

            end generate; -- ~ ANT_GEN

            -- CORE only1
            U_PIM_SLTB_INTRA_LUT_CORE : DPD_CORE 
            generic map(
                DEVICE                       => DEVICE                       ,
                                                                             
                TX_ANT_NUM                   => TX_ANT_NUM                   ,
                HOVS                         => pimref_hovs                  ,
            
                DPD_LUT_OPTIMIZED            => PIMD_CORE_LUT_OPTIMIZED      ,
                DPD_LUT_MEM_DEPTH            => PIMD_CORE_LUT_MEM_DEPTH      , 
                DPD_LUT_RBTEST               => PIMD_CORE_LUT_RBTEST         , 
                DPD_CORE_QPOINT_SEL          => PIMD_CORE_QPOINT_SEL         , 
                DPD_CORE_LUT_DIMENSION       => PIMD_CORE_LUT_DIMENSION      , 
                DPD_CORE_LUT_NUM             => PIMD_CORE_LUT_NUM            ,
                DPD_CORE_TAP_NUM             => PIMD_CORE_TAP_NUM            ,
                DPD_CORE_RND_BIT             => 10                            
                )
            port map(
                RST_DPD                      => RST_PIMD                     , 
                CLK_DPD                      => CLK_PIMD                     , 
            
                DPD_CORE_VLD_IN              => pimd_pre_firlpf_out_vld      ,  
                DPD_CORE_I_IN                => pimd_pre_lpf_out_sat_i       , 
                DPD_CORE_Q_IN                => pimd_pre_lpf_out_sat_q       , 
                                                 
                DPD_CORE_VLD_OUT             => pimd_core_out_vld            , 
                DPD_CORE_I_OUT               => pimd_sum_total_out_i         , 
                DPD_CORE_Q_OUT               => pimd_sum_total_out_q         , 
            
                DPD_CORE_BYPASS_IN           => PIM_CORE_BYPASS_IN           ,
                                                                             
                DPD_GAIN_INDEX_IN            => PIM_SLTB1_GAIN_INDEX_IN      ,
                DPD_QPOINT_SEL_IN            => PIM_SLTB1_QPOINT_SEL_IN      ,
            
                RST_CPU                      => RST_CPU                      ,
                CLK_CPU                      => CLK_CPU                      ,
            
                DPD_LUT_RB_TEST_EN_IN        => '0'                          ,
                                                                             
                DPD_LUT_SWITCH_CDC_STRB_IN   => '0'                          ,
                DPD_LUT_INPUT_SWITCH_IN      => (others=>'0')                , 
                DPD_LUT_OUTPUT_SWITCH_IN     => (others=>'0')                , 
                                                                             
                DPD_LUT_UPDATE_SW_IN         => PIM_SLTB1_LUT_UPDATE_SW_IN   , 
                DPD_LUT_WREN_IN              => PIM_SLTB1_LUT_WREN_IN        , 
                DPD_LUT_RDEN_IN              => PIM_SLTB1_LUT_RDEN_IN        , 
                DPD_LUT_ADDR_IN              => PIM_SLTB1_LUT_ADDR_IN        , 
                DPD_LUT_WDATA_IN             => PIM_SLTB1_LUT_WDATA_IN       , 
                DPD_LUT_RDATA_OUT            => PIM_SLTB1_LUT_RDATA_OUT              
                );
            
            pimd_firlpf_in_vld  <= pimd_core_out_vld;
            pimd_firlpf_in_i    <= pimd_sum_total_out_i  ;
            pimd_firlpf_in_q    <= pimd_sum_total_out_q  ;

            -- SELECTABLE : bypass / INTER : bypassed in NCO_SYMMETRY
            pimd_dly_in_vld     <= pimd_firlpf_out_vld;
            pimd_dly_in_i       <= pimd_firlpf_out_i;
            pimd_dly_in_q       <= pimd_firlpf_out_q;
        end generate; -- ~ SLTB_TYPE_2
        

    end generate; -- ~ SELECTABLE PIM

    G_Inter_Intra_MIXER_beta : if ( PIMD_BLK_TYPE = "INTER" or PIMD_BLK_TYPE = "INTRA" ) generate begin

        U_PIMD_MIXER : NCO_SYMMETRY 
        generic map(
            DEVICE                       => DEVICE                       , 
        
            HOVS                         => pimref_hovs                  , 
            SYMMETRY                     => pimref_nco_symmetry          , 
                                                                           
            POS_SHIFTH_PATH_NUM          => TX_ANT_NUM                   , 
            NEG_SHIFTH_PATH_NUM          => TX_ANT_NUM                   , 
            NCO_WIDTH                    => 16                           , 
            RES_VAL                      => pimref_nco_resolution          
            )
        port map(
            RST                          => RST_PIMD                     , 
            CLK                          => CLK_PIMD                     , 
        
            NCO_WREN                     => PIM_NCO_WREN_IN              , 
            NCO_WORD                     => PIM_NCO_WORD_IN              , 
        
            NCO_FREQ_COMP_OFFSET         => (others => '0')              , 
        
            DATA_P_SH_VLD_IN             => pimd_mixps_in_vld            ,
            DATA_P_SH_I_IN               => pimd_mixps_in_i              ,
            DATA_P_SH_Q_IN               => pimd_mixps_in_q              ,
        
            DATA_P_SH_VLD_OUT            => pimd_mixps_out_vld           ,
            DATA_P_SH_I_OUT              => pimd_mixps_out_i             ,
            DATA_P_SH_Q_OUT              => pimd_mixps_out_q             ,
        
            DATA_N_SH_VLD_IN             => pimd_firlpf_out_vld          , 
            DATA_N_SH_I_IN               => pimd_firlpf_out_i            , 
            DATA_N_SH_Q_IN               => pimd_firlpf_out_q            , 
        
            DATA_N_SH_VLD_OUT            => pimd_dly_in_vld              , 
            DATA_N_SH_I_OUT              => pimd_dly_in_i                , 
            DATA_N_SH_Q_OUT              => pimd_dly_in_q                  
            );

    end generate;

    G_InterBand_PIM_CORE : if (PIMD_BLK_TYPE = "INTER") generate begin
        -- G_PIM_NCS_CORE_REF_Path : for I in 0 to (TX_ANT_NUM-1) generate begin
        --     U_PIM_CORE_like_NCS_FILTER : PIMD_COMPLEX_FILTER 
        --     generic map(
        --         DEVICE                       => DEVICE                          , 
        --         HS_MODE                      => HS_MODE                         , 
        --         HOVS                         => pimref_hovs                     , 
        --         TAP_NUM                      => PIMD_CORE_TAP_NUM               , 
        --         RND_BIT                      => 17                 
        --         )
        --     port map(
        --         RST_DSP                      => RST_PIMD                        , 
        --         CLK_DSP                      => CLK_PIMD                        , 
        --     
        --         DATA_VLD_IN                  => pimd_mixps_out_vld(I)           , 
        --         DATA_I_IN                    => pimd_mixps_out_i(I)             , 
        --         DATA_Q_IN                    => pimd_mixps_out_q(I)             , 
        --     
        --         DATA_VLD_OUT                 => pimd_firlpf_in_vld(I)           , 
        --         DATA_I_OUT                   => pimd_firlpf_in_i(I)             , 
        --         DATA_Q_OUT                   => pimd_firlpf_in_q(I)             , 
        --     
        --         RST_CPU                      => RST_CPU                         , 
        --         CLK_CPU                      => CLK_CPU                         , 
        --     
        --         BYPASS_IN                    => PIM_CORE_BYPASS_IN(I)           , 
        --     
        --         COEF_WR_EN_IN                => PIM_CORE_COEF_WR_EN_IN(I)       , 
        --         COEF_RD_EN_IN                => PIM_CORE_COEF_RD_EN_IN(I)       , 
        --         COEF_WR_DN_IN                => PIM_CORE_COEF_WR_DN_IN(I)       , 
        --         COEF_ADDR_IN                 => PIM_CORE_COEF_ADDR_IN           , 
        --         COEF_I_WDATA_IN              => PIM_CORE_COEF_I_WDATA_IN        , 
        --         COEF_Q_WDATA_IN              => PIM_CORE_COEF_Q_WDATA_IN        , 
        --     
        --         COEF_I_RDATA_OUT             => pimd_ncscore_coef_i_rdata(I)    , 
        --         COEF_Q_RDATA_OUT             => pimd_ncscore_coef_q_rdata(I)      
        --         );
        -- end generate;
         U_PIM_CORE_Like_DPD_CORE_INTER : DPD_CORE 
        generic map(
            DEVICE                       => DEVICE                       ,
                                                                         
            TX_ANT_NUM                   => TX_ANT_NUM                   ,
            HOVS                         => pimref_hovs                  ,
        
            DPD_LUT_OPTIMIZED            => PIMD_CORE_LUT_OPTIMIZED      ,
            DPD_LUT_MEM_DEPTH            => PIMD_CORE_LUT_MEM_DEPTH      , 
            DPD_LUT_RBTEST               => PIMD_CORE_LUT_RBTEST         , 
            DPD_CORE_QPOINT_SEL          => PIMD_CORE_QPOINT_SEL         , 
            DPD_CORE_LUT_DIMENSION       => PIMD_CORE_LUT_DIMENSION      , 
            DPD_CORE_LUT_NUM             => PIMD_CORE_LUT_NUM            ,
            DPD_CORE_TAP_NUM             => PIMD_CORE_TAP_NUM            ,
            DPD_CORE_RND_BIT             => 10                            
            )
        port map(
            RST_DPD                      => RST_PIMD                     , 
            CLK_DPD                      => CLK_PIMD                     , 
        
            DPD_CORE_VLD_IN              => pimd_mixps_out_vld           , 
            DPD_CORE_I_IN                => pimd_mixps_out_i             , 
            DPD_CORE_Q_IN                => pimd_mixps_out_q             , 
                                             
            DPD_CORE_VLD_OUT             => pimd_firlpf_in_vld           , 
            DPD_CORE_I_OUT               => pimd_firlpf_in_i             , 
            DPD_CORE_Q_OUT               => pimd_firlpf_in_q             , 
        
            DPD_CORE_BYPASS_IN           => PIM_CORE_BYPASS_IN           ,
                                                                         
            DPD_GAIN_INDEX_IN            => PIM_GAIN_INDEX_IN            ,
            DPD_QPOINT_SEL_IN            => PIM_QPOINT_SEL_IN            ,
        
            RST_CPU                      => RST_CPU                      ,
            CLK_CPU                      => CLK_CPU                      ,
        
            DPD_LUT_RB_TEST_EN_IN        => PIM_LUT_RB_TEST_EN_IN        ,
                                                                         
            DPD_LUT_SWITCH_CDC_STRB_IN   => PIM_LUT_SWITCH_CDC_STRB_IN   ,
            DPD_LUT_INPUT_SWITCH_IN      => PIM_LUT_INPUT_SWITCH_IN      , 
            DPD_LUT_OUTPUT_SWITCH_IN     => PIM_LUT_OUTPUT_SWITCH_IN     , 
                                                                         
            DPD_LUT_UPDATE_SW_IN         => PIM_LUT_UPDATE_SW_IN         , 
            DPD_LUT_WREN_IN              => PIM_LUT_WREN_IN              , 
            DPD_LUT_RDEN_IN              => PIM_LUT_RDEN_IN              , 
            DPD_LUT_ADDR_IN              => PIM_LUT_ADDR_IN              , 
            DPD_LUT_WDATA_IN             => PIM_LUT_WDATA_IN             , 
            DPD_LUT_RDATA_OUT            => PIM_LUT_RDATA_OUT              
            ); 

        G_PIM_2Path_NCS_Core_COEF_Read : if (TX_ANT_NUM = 2) generate begin
            pimd_core_coef_i_rdata <= pimd_ncscore_coef_i_rdata(0) when (PIM_CORE_COEF_RD_EN_IN = "01") else
                                      pimd_ncscore_coef_i_rdata(1) when (PIM_CORE_COEF_RD_EN_IN = "10") else
                                      (others => '0');

	    pimd_core_coef_q_rdata <= pimd_ncscore_coef_q_rdata(0) when (PIM_CORE_COEF_RD_EN_IN = "01") else   
                                      pimd_ncscore_coef_q_rdata(1) when (PIM_CORE_COEF_RD_EN_IN = "10") else   
                                      (others => '0');
        end generate;

        G_PIM_4Path_NCS_Core_COEF_Read : if (TX_ANT_NUM = 4) generate begin
            pimd_core_coef_i_rdata <= pimd_ncscore_coef_i_rdata(0) when (PIM_CORE_COEF_RD_EN_IN = "0001") else
                                      pimd_ncscore_coef_i_rdata(1) when (PIM_CORE_COEF_RD_EN_IN = "0010") else
                                      pimd_ncscore_coef_i_rdata(2) when (PIM_CORE_COEF_RD_EN_IN = "0100") else
                                      pimd_ncscore_coef_i_rdata(3) when (PIM_CORE_COEF_RD_EN_IN = "1000") else
                                      (others => '0');

	    pimd_core_coef_q_rdata <= pimd_ncscore_coef_q_rdata(0) when (PIM_CORE_COEF_RD_EN_IN = "0001") else   
                                      pimd_ncscore_coef_q_rdata(1) when (PIM_CORE_COEF_RD_EN_IN = "0010") else   
                                      pimd_ncscore_coef_q_rdata(2) when (PIM_CORE_COEF_RD_EN_IN = "0100") else   
                                      pimd_ncscore_coef_q_rdata(3) when (PIM_CORE_COEF_RD_EN_IN = "1000") else   
                                      (others => '0');
        end generate;

        G_PIM_8Path_NCS_Core_COEF_Read : if (TX_ANT_NUM = 8) generate begin
            pimd_core_coef_i_rdata <= pimd_ncscore_coef_i_rdata(0) when (PIM_CORE_COEF_RD_EN_IN = "00000001") else
                                      pimd_ncscore_coef_i_rdata(1) when (PIM_CORE_COEF_RD_EN_IN = "00000010") else
                                      pimd_ncscore_coef_i_rdata(2) when (PIM_CORE_COEF_RD_EN_IN = "00000100") else
                                      pimd_ncscore_coef_i_rdata(3) when (PIM_CORE_COEF_RD_EN_IN = "00001000") else
                                      pimd_ncscore_coef_i_rdata(4) when (PIM_CORE_COEF_RD_EN_IN = "00010000") else
                                      pimd_ncscore_coef_i_rdata(5) when (PIM_CORE_COEF_RD_EN_IN = "00100000") else
                                      pimd_ncscore_coef_i_rdata(6) when (PIM_CORE_COEF_RD_EN_IN = "01000000") else
                                      pimd_ncscore_coef_i_rdata(7) when (PIM_CORE_COEF_RD_EN_IN = "10000000") else
                                      (others => '0');

	    pimd_core_coef_q_rdata <= pimd_ncscore_coef_q_rdata(0) when (PIM_CORE_COEF_RD_EN_IN = "00000001") else   
                                      pimd_ncscore_coef_q_rdata(1) when (PIM_CORE_COEF_RD_EN_IN = "00000010") else   
                                      pimd_ncscore_coef_q_rdata(2) when (PIM_CORE_COEF_RD_EN_IN = "00000100") else   
                                      pimd_ncscore_coef_q_rdata(3) when (PIM_CORE_COEF_RD_EN_IN = "00001000") else   
                                      pimd_ncscore_coef_q_rdata(4) when (PIM_CORE_COEF_RD_EN_IN = "00010000") else   
                                      pimd_ncscore_coef_q_rdata(5) when (PIM_CORE_COEF_RD_EN_IN = "00100000") else   
                                      pimd_ncscore_coef_q_rdata(6) when (PIM_CORE_COEF_RD_EN_IN = "01000000") else   
                                      pimd_ncscore_coef_q_rdata(7) when (PIM_CORE_COEF_RD_EN_IN = "10000000") else   
                                      (others => '0');
        end generate;

    end generate;

    G_Unusing_NCSlike_PIM_CORE : if (PIMD_BLK_TYPE = "INTRA") generate begin

        pimd_firlpf_in_vld <= pimd_mixps_out_vld;
        pimd_firlpf_in_i   <= pimd_mixps_out_i  ;
        pimd_firlpf_in_q   <= pimd_mixps_out_q  ;
        
    end generate;
    -----    
    PIM_CORE_COEF_I_RDATA_OUT <= pimd_core_coef_i_rdata;
    PIM_CORE_COEF_Q_RDATA_OUT <= pimd_core_coef_q_rdata;

    -- common LPF filter
    G_PIMD_LPF_PIM_REF_Path : for I in 0 to (TX_ANT_NUM-1) generate begin
        U_PIMD_LPF : PFIR_FILTER 
        generic map(
            DEVICE                       => DEVICE                          , 
            PIM_MODE                     => TRUE                            , 
            HOVS                         => pimref_hovs                     , 
            SYMMETRY                     => "ODD"                           , 
            COEF_FIX                     => TRUE                            , 
            -- COEF_NUM                     => 39                              , 
            COEF_NUM                     => 31                              , 
            RND_BIT                      => 15                                
            )
        port map(
            RST_DSP                      => clk_unstable                    , 
            CLK_DSP                      => CLK_PIMD                        , 
        
            DATA_VLD_IN                  => pimd_firlpf_in_vld(I)           , 
            DATA_I_IN                    => pimd_firlpf_in_i(I)             , 
            DATA_Q_IN                    => pimd_firlpf_in_q(I)             , 
        
            BYPASS_IN                    => PIM_FILTER_BYPASS_IN(I)         , 
        
            DATA_VLD_OUT                 => pimd_firlpf_out_vld(I)          , 
            DATA_I_OUT                   => pimd_firlpf_out_i(I)            , 
            DATA_Q_OUT                   => pimd_firlpf_out_q(I)            , 
        
            RST_CPU                      => RST_CPU                         , 
            CLK_CPU                      => CLK_CPU                         , 
        
            COEF_WR_EN                   => PIM_FILTER_COEF_WR_EN_IN(I)     , 
            COEF_RD_EN                   => PIM_FILTER_COEF_RD_EN_IN(I)     , 
            COEF_WR_DN                   => PIM_FILTER_COEF_WR_DN_IN(I)     , 
            COEF_ADDR                    => PIM_FILTER_COEF_ADDR_IN         , 
            COEF_WR_DATA                 => PIM_FILTER_COEF_WR_DATA_IN      , 
            COEF_RD_DATA                 => pimd_firlpf_coef_rd_data(I)     
            );
    end generate;

    G_PIM_2Path_LPF_COEF_Read : if (TX_ANT_NUM = 2) generate begin
        pimd_firlpf_coef_rdata <= pimd_firlpf_coef_rd_data(0) when (PIM_FILTER_COEF_RD_EN_IN = "01") else  
                                  pimd_firlpf_coef_rd_data(1) when (PIM_FILTER_COEF_RD_EN_IN = "10") else  
                                  (others => '0');
    end generate;

    G_PIM_4Path_LPF_COEF_Read : if (TX_ANT_NUM = 4) generate begin
        pimd_firlpf_coef_rdata <= pimd_firlpf_coef_rd_data(0) when (PIM_FILTER_COEF_RD_EN_IN = "0001") else  
                                  pimd_firlpf_coef_rd_data(1) when (PIM_FILTER_COEF_RD_EN_IN = "0010") else  
                                  pimd_firlpf_coef_rd_data(2) when (PIM_FILTER_COEF_RD_EN_IN = "0100") else  
                                  pimd_firlpf_coef_rd_data(3) when (PIM_FILTER_COEF_RD_EN_IN = "1000") else  
                                  (others => '0');
    end generate;

    G_PIM_8Path_LPF_COEF_Read : if (TX_ANT_NUM = 8) generate begin
        pimd_firlpf_coef_rdata <= pimd_firlpf_coef_rd_data(0) when (PIM_FILTER_COEF_RD_EN_IN = "00000001") else  
                                  pimd_firlpf_coef_rd_data(1) when (PIM_FILTER_COEF_RD_EN_IN = "00000010") else  
                                  pimd_firlpf_coef_rd_data(2) when (PIM_FILTER_COEF_RD_EN_IN = "00000100") else  
                                  pimd_firlpf_coef_rd_data(3) when (PIM_FILTER_COEF_RD_EN_IN = "00001000") else  
                                  pimd_firlpf_coef_rd_data(4) when (PIM_FILTER_COEF_RD_EN_IN = "00010000") else  
                                  pimd_firlpf_coef_rd_data(5) when (PIM_FILTER_COEF_RD_EN_IN = "00100000") else  
                                  pimd_firlpf_coef_rd_data(6) when (PIM_FILTER_COEF_RD_EN_IN = "01000000") else  
                                  pimd_firlpf_coef_rd_data(7) when (PIM_FILTER_COEF_RD_EN_IN = "10000000") else  
                                  (others => '0');
    end generate;

    PIM_FILTER_COEF_RD_DATA_OUT <= pimd_firlpf_coef_rdata;            

    G_PIM_DLY_REF_Path_GEN : for I in 0 to (TX_ANT_NUM-1) generate begin
        pimd_dly_out_vld(I) <= pimd_dly_in_vld(I);
        U_PIM_DLY_I : BUF_SAMPLE_DLY generic map("BLOCK", "CLOCK", 16, 12) port map(clk_unstable, CLK_PIMD, PIMDLY_VALUE_IN(I), pimd_dly_in_vld(I), pimd_dly_in_i(I), pimd_dly_out_i(I));
        U_PIM_DLY_Q : BUF_SAMPLE_DLY generic map("BLOCK", "CLOCK", 16, 12) port map(clk_unstable, CLK_PIMD, PIMDLY_VALUE_IN(I), pimd_dly_in_vld(I), pimd_dly_in_q(I), pimd_dly_out_q(I));
    end generate;

    -- ******************************
    -- UL Processing Path                  
    -- ******************************
    
    G_UL_Input_Upsamp_x1 : if (ul_input_upsamp_ratio = 1) generate begin
        P_UL_PIM_Detector_OnOff_Upsamp_x1 : process(rst_ul, CLK_UL) begin
            if (rst_ul = '1') then
                ul_upsamp_in_vld            <= (others => '0');
                ul_upsamp_in_i              <= (others => (others => '0'));
                ul_upsamp_in_q              <= (others => (others => '0'));
            elsif (CLK_UL'event) and (CLK_UL = '1') then
                for I in 0 to (RX_ANT_NUM-1) loop
                    if (pim_detector_on_ulclk_sh(I)(1) = '1') then
                        ul_upsamp_in_vld(I) <= UL_PIM_TGT_VLD_IN(I);
                        ul_upsamp_in_i(I)   <= UL_PIM_TGT_I_IN(I);
                        ul_upsamp_in_q(I)   <= UL_PIM_TGT_Q_IN(I);
                    else
                        ul_upsamp_in_vld(I) <= '0';
                        ul_upsamp_in_i(I)   <= (others => '0');
                        ul_upsamp_in_q(I)   <= (others => '0');
                    end if;
                end loop;
            end if;
        end process;

        ul_upsamp_out_vld           <= ul_upsamp_in_vld;
        ul_upsamp_out_i             <= ul_upsamp_in_i;
        ul_upsamp_out_q             <= ul_upsamp_in_q;

        ul_mixps_in_vld             <= ul_upsamp_out_vld;
        ul_mixps_in_i               <= ul_upsamp_out_i;
        ul_mixps_in_q               <= ul_upsamp_out_q;
    end generate;

    G_UL_Input_Upsamp_x2 : if (ul_input_upsamp_ratio = 2) generate begin  
        G_UL_Input_UL_Path_GEN : for I in 0 to (RX_ANT_NUM-1) generate begin
                P_UL_PIM_Detector_OnOff_Upsamp_x2 : process(rst_ul, CLK_UL) begin
                    if (rst_ul = '1') then
                        ul_upsamp_in_vld(I)         <= '0';
                        ul_upsamp_in_i(I)           <= (others => '0');
                        ul_upsamp_in_q(I)           <= (others => '0');
                    elsif (CLK_UL'event) and (CLK_UL = '1') then
                        if (pim_detector_on_ulclk_sh(I)(1) = '1') then
                            ul_upsamp_in_vld(I)     <= UL_PIM_TGT_VLD_IN(I);
                            ul_upsamp_in_i(I)       <= UL_PIM_TGT_I_IN(I);
                            ul_upsamp_in_q(I)       <= UL_PIM_TGT_Q_IN(I);
                        else
                            ul_upsamp_in_vld(I)     <= '0';
                            ul_upsamp_in_i(I)       <= (others => '0');
                            ul_upsamp_in_q(I)       <= (others => '0');
                        end if;
                    end if;
                end process;

                U_InterBand_HBFx2 : pim_hbf_i
                    generic map(
                        FILTER_ORDER                =>  19,    --: integer := 27;		-- 27 or 19 or 11
                        WIDTH_IN                    =>  16,    --: integer := 16;
                        WIDTH_OUT                   =>  16,    --: integer := 16;
                        BINARY_POINT                =>  14     --: integer := 15
                    )
                    port MAP(
                        i_rst                       =>  clk_unstable,       --: in  std_logic;
                        i_clk                       =>  CLK_PIMD,           --: in  std_logic;
                
                        i_data_i                    =>  ul_upsamp_in_i(I),  --: in  std_logic_vector(WIDTH_IN-1 downto 0);
                        i_data_q                    =>  ul_upsamp_in_q(I),  --: in  std_logic_vector(WIDTH_IN-1 downto 0);
                                
                        o_data_i                    =>  ul_upsamp_out_i(I),	--: out std_logic_vector(WIDTH_OUT-1 downto 0);
                        o_data_q                    =>  ul_upsamp_out_q(I)	--: out std_logic_vector(WIDTH_OUT-1 downto 0)
                    );
                ul_upsamp_out_vld(I)                <=  '1';

                ul_mixps_in_vld(I)                  <= ul_upsamp_out_vld(I);
                ul_mixps_in_i(I)                    <= ul_upsamp_out_i(I);
                ul_mixps_in_q(I)                    <= ul_upsamp_out_q(I);
        end generate;
    end generate;
 
    U_UL_MIXER : NCO_SYMMETRY 
        generic map(
            DEVICE                       => DEVICE                       , 
        
            HOVS                         => pimref_hovs                  , 
            SYMMETRY                     => TRUE                         , 

            POS_SHIFTH_PATH_NUM          => RX_ANT_NUM                   , 
            NEG_SHIFTH_PATH_NUM          => RX_ANT_NUM                   , 
            NCO_WIDTH                    => 16                           , 
            RES_VAL                      => ul_nco_resolution              
            )
        port map(
            RST                          => RST_PIMD                     , 
            CLK                          => CLK_PIMD                     , 
        
            NCO_WREN                     => UL_PIM_NCO_WREN_IN           , 
            NCO_WORD                     => UL_PIM_NCO_WORD_IN           ,       
                                                                        
            NCO_FREQ_COMP_OFFSET         => UL_PIM_FREQ_COMP_WORD_IN     , 
        
            DATA_P_SH_VLD_IN             => ul_mixps_in_vld              , 
            DATA_P_SH_I_IN               => ul_mixps_in_i                , 
            DATA_P_SH_Q_IN               => ul_mixps_in_q                , 
        
            DATA_P_SH_VLD_OUT            => ul_mixps_out_vld             , 
            DATA_P_SH_I_OUT              => ul_mixps_out_i               , 
            DATA_P_SH_Q_OUT              => ul_mixps_out_q               , 
        
            DATA_N_SH_VLD_IN             => ul_pimd_sat_out_vld          , 
            DATA_N_SH_I_IN               => ul_pimd_sat_out_i            , 
            DATA_N_SH_Q_IN               => ul_pimd_sat_out_q            , 
        
            DATA_N_SH_VLD_OUT            => ul_mixns_out_vld             , 
            DATA_N_SH_I_OUT              => ul_mixns_out_i               , 
            DATA_N_SH_Q_OUT              => ul_mixns_out_q                 
        );

    G_PIM_UL_Path_GEN : for I in 0 to (RX_ANT_NUM-1) generate begin
        P_UL_PIM_Mitigator_OnOff : process(rst_pimblk, CLK_PIMD) begin 
            if (rst_pimblk = '1') then 
                ul_tgt_vld(I)       <= '0';
                ul_tgt_i(I)         <= (others => '0');
                ul_tgt_q(I)         <= (others => '0');
                                     
                ul_dly_in_vld(I)    <= '0';
                ul_dly_in_i(I)      <= (others => '0');
                ul_dly_in_q(I)      <= (others => '0');
            elsif (CLK_PIMD'event) and (CLK_PIMD = '1') then
                ul_tgt_vld(I)       <= ul_mixps_out_vld(I);
                ul_dly_in_vld(I)    <= ul_mixps_out_vld(I);
                 
                if (ul_mixps_out_vld(I) = '1') then
                    ul_tgt_i(I)     <= ul_mixps_out_i(I);
                    ul_tgt_q(I)     <= ul_mixps_out_q(I);

            	    if (pim_mitigator_on_sh(I)(1) = '1') then
                        ul_dly_in_i(I) <= ul_mixps_out_i(I);
                        ul_dly_in_q(I) <= ul_mixps_out_q(I);
                    else
                        ul_dly_in_i(I) <= (others => '0');
                        ul_dly_in_q(I) <= (others => '0');
                    end if;
                else
                    ul_tgt_i(I)    <= ul_tgt_i(I);
                    ul_tgt_q(I)    <= ul_tgt_q(I);

                    ul_dly_in_i(I) <= ul_dly_in_i(I);
                    ul_dly_in_q(I) <= ul_dly_in_q(I);
                end if;
            end if;
        end process;

        ul_dly_out_vld(I) <= ul_dly_in_vld(I);

        ul_pnpc_out_vld(I) <= ul_dly_in_vld(I);

        -- U_LMSPWR_N_PHASE_COMPENSATOR : lms_pp_0224_release_0 
        -- port map(
        --     BB_IN_I                      => ul_dly_in_i(I)      ,
        --     BB_IN_Q                      => ul_dly_in_q(I)      ,
        --     CNT_RST(0)                   => rst_pnpc(I)         ,
        --     FB_IN_I                      => pimd_dly_out_i(I)   ,
        --     FB_IN_Q                      => pimd_dly_out_q(I)   ,
        --     FB_MU_PP_SEL                 => PNPC_MU_SEL_IN(I)   ,
        --     FB_PP_EN(0)                  => pnpc_en_sh(I)(1)    ,
        --     FB_PP_SET(0)                 => pnpc_set_sh(I)(1)   ,
        --     FB_PP_SETVAL_I               => PNPC_SETVAL_I_IN(I) ,
        --     FB_PP_SETVAL_Q               => PNPC_SETVAL_Q_IN(I) ,
        --     CLK                          => CLK_PIMD            ,
        --     CLR                          => ce_clr_pnpc(I)      ,
        --     BB_PP_OUT_I                  => ul_dly_out_i(I)     ,
        --     BB_PP_OUT_Q                  => ul_dly_out_q(I)     ,
        --     FB_PP_OUT_I                  => ul_pnpc_out_i(I)    ,
        --     FB_PP_OUT_Q                  => ul_pnpc_out_q(I)    ,
        --     TP_FB_DC_I                   => pnpc_tp_dc_i(I)     ,
        --     TP_FB_DC_Q                   => pnpc_tp_dc_q(I)
        --     );

        U_PIM_PHASE_COMP_LMS : PIM_PHASE_COMP_LMS
        generic map(
            DEVICE                       => DEVICE              , --: string             := "ULTRASCALE";
            HOVS                         => 1                     --: natural            := 1
        )
        port map(
            RX_DATA_I_IN                 => ul_dly_in_i(I)      , --: in  std_logic_vector(15 downto 0);    -- PIM source in         BB_IN_I                      
            RX_DATA_Q_IN                 => ul_dly_in_q(I)      , --: in  std_logic_vector(15 downto 0);    -- PIM source in         BB_IN_Q                      
            CNT_RST_IN(0)                => rst_pnpc(I)         , --: in  std_logic_vector( 0 downto 0);    -- count rst in          CNT_RST                      
            PIM_DATA_I_IN                => pimd_dly_out_i(I)   , --: in  std_logic_vector(15 downto 0);    -- UL in                 FB_IN_I                      
            PIM_DATA_Q_IN                => pimd_dly_out_q(I)   , --: in  std_logic_vector(15 downto 0);    -- UL in                 FB_IN_Q                      
            MU_SELECT_IN                 => PNPC_MU_SEL_IN(I)   , --: in  std_logic_vector( 1 downto 0);    -- Mu select in          FB_MU_PP_SEL                 
            PNPC_EN_IN(0)                => pnpc_en_sh(I)(1)    , --: in  std_logic_vector( 0 downto 0);    -- PNPC enalbe in        FB_PP_EN                     
            PNPC_SET_IN(0)               => pnpc_set_sh(I)(1)   , --: in  std_logic_vector( 0 downto 0);    -- PNPC coef set in      FB_PP_SET                    
            COEF_I_IN                    => PNPC_SETVAL_I_IN(I) , --: in  std_logic_vector(15 downto 0);    -- initial coeff in      FB_PP_SETVAL_I               
            COEF_Q_IN                    => PNPC_SETVAL_Q_IN(I) , --: in  std_logic_vector(15 downto 0);    -- initial coeff in      FB_PP_SETVAL_Q               
            CLK_PIMD                     => CLK_PIMD            , --: in  std_logic;                        -- CLK                   CLK                          
            CE_CLR_IN                    => ce_clr_pnpc(I)      , --: in  std_logic;                        -- ?                     CLR                          
            UL_DATA_DLY_I_OUT            => ul_dly_out_i(I)     , --: out std_logic_vector(15 downto 0);    -- UL delayed data out   BB_PP_OUT_I                  
            UL_DATA_DLY_Q_OUT            => ul_dly_out_q(I)     , --: out std_logic_vector(15 downto 0);    -- UL delayed data out   BB_PP_OUT_Q                  
            PIM_I_OUT                    => ul_pnpc_out_i(I)    , --: out std_logic_vector(15 downto 0);    -- PNPCed data out       FB_PP_OUT_I                  
            PIM_Q_OUT                    => ul_pnpc_out_q(I)    , --: out std_logic_vector(15 downto 0);    -- PNPCed data out       FB_PP_OUT_Q                  
            COEF_I_OUT                   => pnpc_tp_dc_i(I)     , --: out std_logic_vector(15 downto 0);    -- coef out              TP_FB_DC_I                   
            COEF_Q_OUT                   => pnpc_tp_dc_q(I)       --: out std_logic_vector(15 downto 0)     -- coef out              TP_FB_DC_Q                   
            );

        PNPC_TP_DC_IQ_OUT(I) <= pnpc_tp_dc_i(I) & pnpc_tp_dc_q(I);

        P_PNPC_Out_Sel : process(rst_pimblk, CLK_PIMD) begin
            if (rst_pimblk = '1') then
                ul_pnpc_sel_vld(I) <= '0';
                ul_pnpc_sel_i(I)   <= (others => '0');
                ul_pnpc_sel_q(I)   <= (others => '0');

                ul_dly_d1_vld(I)   <= '0';
                ul_dly_d1_i(I)     <= (others => '0');
                ul_dly_d1_q(I)     <= (others => '0');

            elsif (CLK_PIMD'event) and (CLK_PIMD = '1') then
                ul_pnpc_sel_vld(I) <= ul_dly_out_vld(I);
                ul_dly_d1_vld(I)   <= ul_dly_out_vld(I);

        if (ul_dly_out_vld(I) = '1') then
                    ul_dly_d1_i(I)     <= ul_dly_out_i(I);
                    ul_dly_d1_q(I)     <= ul_dly_out_q(I);

                    case (PNPC_SEL_IN(I)) is
                        when "00"   => ul_pnpc_sel_i(I) <= ul_pnpc_out_i(I) ; ul_pnpc_sel_q(I) <= ul_pnpc_out_q(I) ;
                        when "01"   => ul_pnpc_sel_i(I) <= pimd_dly_out_i(I); ul_pnpc_sel_q(I) <= pimd_dly_out_q(I);
                        when "10"   => ul_pnpc_sel_i(I) <= (others => '0')  ; ul_pnpc_sel_q(I) <= (others => '0')  ;
                        when others => ul_pnpc_sel_i(I) <= ul_pnpc_out_i(I) ; ul_pnpc_sel_q(I) <= ul_pnpc_out_q(I) ;
                    end case;
                else
                    ul_dly_d1_i(I)   <= ul_dly_d1_i(I);
                    ul_dly_d1_q(I)   <= ul_dly_d1_q(I);

                    ul_pnpc_sel_i(I) <= ul_pnpc_sel_i(I);
                    ul_pnpc_sel_q(I) <= ul_pnpc_sel_q(I);
                end if;
            end if;
        end process;

        P_PIM_Substract : process(rst_pimblk, CLK_PIMD) begin
            if (rst_pimblk = '1') then
                ul_pim_substract_out_vld(I) <= '0';
                ul_pim_substract_out_i(I)   <= (others => '0');
                ul_pim_substract_out_q(I)   <= (others => '0');
            elsif (CLK_PIMD'event) and (CLK_PIMD = '1') then
                ul_pim_substract_out_vld(I) <= ul_dly_d1_vld(I);

                if (ul_dly_d1_vld(I) = '1') then
                    ul_pim_substract_out_i(I) <= (ul_dly_d1_i(I)(15)&ul_dly_d1_i(I)) - (ul_pnpc_sel_i(I)(15)&ul_pnpc_sel_i(I));
                    ul_pim_substract_out_q(I) <= (ul_dly_d1_q(I)(15)&ul_dly_d1_q(I)) - (ul_pnpc_sel_q(I)(15)&ul_pnpc_sel_q(I));
                else
                    ul_pim_substract_out_i(I) <= ul_pim_substract_out_i(I);
                    ul_pim_substract_out_q(I) <= ul_pim_substract_out_q(I);
                end if;
            end if;
        end process;

        ul_pimd_sat_out_vld(I) <= ul_pim_substract_out_vld(I);
        U_PIMD_SAT_I : SAT_SIGN generic map(TRUE, 17, 16) port map(rst_pimblk, CLK_PIMD, ul_pim_substract_out_i(I), ul_pimd_sat_out_i(I));
        U_PIMD_SAT_Q : SAT_SIGN generic map(TRUE, 17, 16) port map(rst_pimblk, CLK_PIMD, ul_pim_substract_out_q(I), ul_pimd_sat_out_q(I));

    end generate;

    G_UL_PIM_Mitigator_OnOff_122p88M_Input : if (ul_inout_ratio = 1) generate begin
        ul_data_122p88M_vld <= UL_PIM_TGT_VLD_IN;
        ul_data_122p88M_i   <= UL_PIM_TGT_I_IN;  
        ul_data_122p88M_q   <= UL_PIM_TGT_Q_IN;  
    end generate;

    G_UL_PIM_Mitigator_OnOff_61p44M_Input : if (ul_inout_ratio = 2) generate begin
        ul_data_122p88M_vld <= ul_mixps_in_vld;
        ul_data_122p88M_i   <= ul_mixps_in_i;  
        ul_data_122p88M_q   <= ul_mixps_in_q;
    end generate;

    DOWNSAMPLE_SEL_OUT : for i in 0 to RX_ANT_NUM-1 generate
        decimation : pim_hbf_d
            generic map(
                FILTER_ORDER					=>  19,         --: integer := 27;		-- 27 or 19 or 11
                WIDTH_IN                    	=>  16,         --: integer := 16;
                WIDTH_OUT                   	=>  16,         --: integer := 16;
                BINARY_POINT                	=>  15          --: integer := 15
            )
            port map(
                i_rst 							=>  clk_unstable,               --: in  std_logic;
                i_clk							=>  CLK_PIMD,                   --: in  std_logic;
        
                i_data_i					    =>  ul_mixns_out_i(i),          --: in  std_logic_vector(WIDTH_IN-1 downto 0);
                i_data_q					    =>  ul_mixns_out_q(i),          --: in  std_logic_vector(WIDTH_IN-1 downto 0);
                
                o_valid							=>  deci_ul_mixns_out_vld(i),   --: out std_logic;
                o_data_i						=>  deci_ul_mixns_out_i(i),     --: out std_logic_vector(WIDTH_OUT-1 downto 0);
                o_data_q						=>  deci_ul_mixns_out_q(i)      --: out std_logic_vector(WIDTH_OUT-1 downto 0)
            );

        process(rst_ul, CLK_UL) begin
            if (rst_ul = '1') then
                ul_out_vld(I)           <=  '0';
                ul_out_i(I)             <=  (others => '0');
                ul_out_q(I)             <=  (others => '0');
            elsif (rising_edge(CLK_UL)) then
                if (pim_mitigator_on_ulclk(I) = '0') then
                    ul_out_vld(I)       <=  ul_data_122p88M_vld(I);
                    ul_out_i(I)         <=  ul_data_122p88M_i(I);
                    ul_out_q(I)         <=  ul_data_122p88M_q(I);
                else
                    ul_out_vld(I)       <=  deci_ul_mixns_out_vld(I);
                    ul_out_i(I)         <=  deci_ul_mixns_out_i(I);
                    ul_out_q(I)         <=  deci_ul_mixns_out_q(I);
                end if;
            end if;
        end process;
    end generate;

    -- ******************************
    -- PIM Debugging Path Selection
    -- ******************************
    G_IntraBand_PIM_DBG_SEL : if (PIMD_BLK_TYPE = "INTRA") generate begin
        P_IntraBand_PIM_DBG_SEL : process(rst_pimblk, CLK_PIMD) begin
            if (rst_pimblk = '1') then
                pimd_scdbg_i   <= (others => (others => '0'));
                pimd_scdbg_q   <= (others => (others => '0'));
            elsif (CLK_PIMD'event) and (CLK_PIMD = '1') then
                case (PIM_SC_INTRA_PIM_DBG_SEL_IN) is
                    when "00" =>
                        pimd_scdbg_i   <= ul_pimd_sat_out_i;
                        pimd_scdbg_q   <= ul_pimd_sat_out_q;
                    when "01" =>
                        pimd_scdbg_i   <= pimd_dly_in_i;
                        pimd_scdbg_q   <= pimd_dly_in_q;
                    when "10" =>
                        pimd_scdbg_i   <= ul_pnpc_out_i;
                        pimd_scdbg_q   <= ul_pnpc_out_q;
                    when others =>
                        pimd_scdbg_i   <= ul_pimd_sat_out_i;
                        pimd_scdbg_q   <= ul_pimd_sat_out_q;
                end case;
            end if;
        end process;
    end generate;

    G_InterBand_PIM_DBG_SEL : if (PIMD_BLK_TYPE /= "INTRA") generate begin
        P_InterBand_PIM_DBG_SEL : process(rst_pimblk, CLK_PIMD) begin
            if (rst_pimblk = '1') then
                pimd_scdbg_i   <= (others => (others => '0'));
                pimd_scdbg_q   <= (others => (others => '0'));
            elsif (CLK_PIMD'event) and (CLK_PIMD = '1') then
                case (PIM_SC_INTER_PIM_DBG_SEL_IN) is
                    when "00" =>
                        pimd_scdbg_i   <= pimd_firlpf_in_i;
                        pimd_scdbg_q   <= pimd_firlpf_in_q;
                    when "01" =>
                        pimd_scdbg_i   <= ul_pimd_sat_out_i;
                        pimd_scdbg_q   <= ul_pimd_sat_out_q;
                    when "10" =>
                        pimd_scdbg_i   <= ul_pnpc_out_i;
                        pimd_scdbg_q   <= ul_pnpc_out_q;
                    when others =>
                        pimd_scdbg_i   <= (others => (others => '0'));
                        pimd_scdbg_q   <= (others => (others => '0'));
                end case;
            end if;
        end process;
    end generate;

    -- ******************************
    -- PIM Output Assign
    -- ******************************

    UL_PIMD_VLD_OUT              <= ul_out_vld;
    UL_PIMD_I_OUT                <= ul_out_i  ;
    UL_PIMD_Q_OUT                <= ul_out_q  ;

    G_InterBand_SC_PIM_Output_Assign : if (PIMD_BLK_TYPE = "INTER") generate begin
        UL_PIM_SC_ERR_I_OUT          <= pimd_dly_in_i;
        UL_PIM_SC_ERR_Q_OUT          <= pimd_dly_in_q;

        UL_PIM_SC_TGT_I_OUT          <= ul_tgt_i;
        UL_PIM_SC_TGT_Q_OUT          <= ul_tgt_q;

        UL_PIM_SC_CFR_I_OUT          <= pimd_ref_in_i;
        UL_PIM_SC_CFR_Q_OUT          <= pimd_ref_in_q;

        UL_PIM_INTERB_DUCDLY_I_OUT   <= pimd_interb_fdly_out_i;
        UL_PIM_INTERB_DUCDLY_Q_OUT   <= pimd_interb_fdly_out_q;

        UL_PIM_SC_3RD_IM_I_OUT       <= pimd_mixps_out_i;
        UL_PIM_SC_3RD_IM_Q_OUT       <= pimd_mixps_out_q;

        UL_PIM_SC_DBG_I_OUT          <= pimd_scdbg_i;
        UL_PIM_SC_DBG_Q_OUT          <= pimd_scdbg_q;

        DBG_PIM_MIXPS_I_OUT          <= (others => (others => '0'));
        DBG_PIM_MIXPS_Q_OUT          <= (others => (others => '0'));

    end generate;


    G_SLTB_SC_PIM_Output_Assign : if (PIMD_BLK_TYPE = "SELECTABLE") generate begin
        UL_PIM_SC_ERR_I_OUT          <= pimd_dly_in_i;
        UL_PIM_SC_ERR_Q_OUT          <= pimd_dly_in_q;

        UL_PIM_SC_TGT_I_OUT          <= ul_tgt_i;
        UL_PIM_SC_TGT_Q_OUT          <= ul_tgt_q;

        UL_PIM_SC_CFR_I_OUT          <= pimd_intra_fdly_in_i; -- pimd_ref_in_i;
        UL_PIM_SC_CFR_Q_OUT          <= pimd_intra_fdly_in_q; -- pimd_ref_in_q;

        UL_PIM_INTERB_DUCDLY_I_OUT   <= pimd_interb_fdly_out_i;
        UL_PIM_INTERB_DUCDLY_Q_OUT   <= pimd_interb_fdly_out_q;

        G_SLTB_TYPE1 : if (C_SELECTABLE_TYPE = 1) generate begin
            -- UL_PIM_SC_3RD_IM_I_OUT       <= dbg_pimd_im3gen_sum_out_i;
            -- UL_PIM_SC_3RD_IM_Q_OUT       <= dbg_pimd_im3gen_sum_out_q;
            UL_PIM_SC_3RD_IM_I_OUT       <= pimd_core_in_sum_out_i;
            UL_PIM_SC_3RD_IM_Q_OUT       <= pimd_core_in_sum_out_q;
        end generate;
	
        G_SLTB_TYPE2 : if (C_SELECTABLE_TYPE = 2) generate begin
            UL_PIM_SC_3RD_IM_I_OUT       <= pimd_pre_lpf_out_sat_i;
            UL_PIM_SC_3RD_IM_Q_OUT       <= pimd_pre_lpf_out_sat_q;
        end generate;

        UL_PIM_SC_DBG_I_OUT          <= pimd_scdbg_i;
        UL_PIM_SC_DBG_Q_OUT          <= pimd_scdbg_q;

        DBG_PIM_MIXPS_I_OUT          <= (others => (others => '0'));
        DBG_PIM_MIXPS_Q_OUT          <= (others => (others => '0'));

    end generate;

    G_IntraBand_SC_PIM_Output_Assign : if (PIMD_BLK_TYPE = "INTRA") generate begin
        UL_PIM_SC_ERR_I_OUT          <= pimd_scdbg_i;
        UL_PIM_SC_ERR_Q_OUT          <= pimd_scdbg_q;

        UL_PIM_SC_TGT_I_OUT          <= ul_tgt_i;
        UL_PIM_SC_TGT_Q_OUT          <= ul_tgt_q;

        UL_PIM_SC_CFR_I_OUT          <= (others => (others => '0'));
        UL_PIM_SC_CFR_Q_OUT          <= (others => (others => '0'));

        UL_PIM_INTERB_DUCDLY_I_OUT   <= (others => (others => '0'));
        UL_PIM_INTERB_DUCDLY_Q_OUT   <= (others => (others => '0'));

        UL_PIM_SC_3RD_IM_I_OUT       <= (others => (others => '0'));
        UL_PIM_SC_3RD_IM_Q_OUT       <= (others => (others => '0'));

        UL_PIM_SC_DBG_I_OUT          <= (others => (others => '0'));
        UL_PIM_SC_DBG_Q_OUT          <= (others => (others => '0'));

        DBG_PIM_MIXPS_I_OUT          <= pimd_mixps_in_i; 
        DBG_PIM_MIXPS_Q_OUT          <= pimd_mixps_in_q; 
    end generate;

end arc_PIMD_BLK;

