-- k1340.heo

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

-- Latency : 2 Clocks
-- 
-- ------------------------------------------------------------------------- 
--    Generic |          Range 
----------------------------------------------------------------------------
--  RND_STYLE | SYMMETRY : Round Half Away  
--            | RND_UP   : Round Up
--            | RND_DOWN : Round Down 
--            | CEIL     : Up   
--            | FLOOR    : Down   
--            | TRUNC    : Truncation  
-- ------------------------------------------------------------------------- 
--    RND_BIT | INPUT_BIT > RND_BIT > 0
-- ------------------------------------------------------------------------- 
--  INPUT_BIT | INPUT_BIT
-- ------------------------------------------------------------------------- 
-- OUTPUT_BIT | INPUT_BIT - RND_BIT > OUTPUT_BIT
-- ------------------------------------------------------------------------- 

entity RND_FUNC is
generic(
    RND_STYLE  : string := "SYMMETRY";
    RND_BIT    : natural;
    INPUT_BIT  : natural;
    OUTPUT_BIT : natural
    );
port(
    CLK        : in  std_logic;

    DATA_IN    : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT   : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end RND_FUNC;

architecture arc_RND_FUNC of RND_FUNC is

constant zeros       : std_logic_vector( INPUT_BIT downto 0) := (others => '0');
constant ones        : std_logic_vector( INPUT_BIT downto 0) := (others => '1');

signal   rnd_factor  : std_logic_vector( INPUT_BIT downto 0); -- 0.4999999...
signal   sign_factor : std_logic_vector( INPUT_BIT downto 0); -- 0.000....1 (negative sign) or 0 (positive sign)

signal   rnd_out     : std_logic_vector( INPUT_BIT downto 0);
signal   se_data_in  : std_logic_vector( INPUT_BIT downto 0);

begin

    P_Sign_Bit_Processing : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            -- 0.000....1 (negative sign) or 0 (positive sign)
            sign_factor <= zeros(INPUT_BIT downto 1) & (not DATA_IN(INPUT_BIT-1));

            -- Sign Extention
            se_data_in  <= DATA_IN(INPUT_BIT-1) & DATA_IN;    
        end if;
    end process;

    G_BinaryPoint1 : if (RND_BIT = 1) generate begin
        G_Binary_Point1 : if (RND_BIT = 1) generate begin
            rnd_factor  <= zeros(INPUT_BIT downto RND_BIT) & '1'; -- 0.5

            P_Round_Up : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    rnd_out <= se_data_in + rnd_factor;
                end if;
            end process;
        end generate;
    end generate;
 
    G_Binary_PointN : if (RND_BIT > 1) generate begin
        G_Symmetry_Rounding : if (RND_STYLE = "SYMMETRY") generate begin
            rnd_factor  <= zeros(INPUT_BIT downto RND_BIT-1) & ones(RND_BIT-2 downto 0); -- 0.4999...

            P_Round_Half_Away : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    rnd_out <= se_data_in + rnd_factor + sign_factor;
                end if;
            end process;

        end generate;

        G_Round_Up : if (RND_STYLE = "RND_UP") generate begin
            rnd_factor  <= zeros(INPUT_BIT downto RND_BIT) & '1' & zeros(RND_BIT-2 downto 0); -- 0.5

            P_Round_Half_Up : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    rnd_out <= se_data_in + rnd_factor;
                end if;
            end process;

        end generate;

        G_Round_Down : if (RND_STYLE = "RND_DOWN") generate begin
            rnd_factor  <= zeros(INPUT_BIT downto RND_BIT-1) & ones(RND_BIT-2 downto 0); -- 0.4999...

            P_Round_Half_Down : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    rnd_out <= se_data_in + rnd_factor;
                end if;
            end process;

        end generate;

        G_Round_Ceil : if (RND_STYLE = "CEIL") generate begin
            rnd_factor  <= zeros(INPUT_BIT downto RND_BIT+1) & '1' & zeros(RND_BIT-1 downto 0); -- 1

            P_Round_Half_Down : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    rnd_out <= se_data_in + rnd_factor;
                end if;
            end process;
        end generate;

        G_Round_Floor : if (RND_STYLE = "FLOOR") generate begin
            rnd_factor  <= ones(INPUT_BIT downto RND_BIT) & zeros(RND_BIT-1 downto 0); -- -1

            P_Round_Half_Down : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    rnd_out <= se_data_in + rnd_factor;
                end if;
            end process;
        end generate;

        G_Round_Truncation : if (RND_STYLE = "TRUNC") generate begin
            rnd_factor  <= zeros(INPUT_BIT downto 0); -- 0 

            P_Round_Half_Down : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    rnd_out <= se_data_in + rnd_factor;
                end if;
            end process;
        end generate;

    end generate;

    DATA_OUT <= rnd_out((OUTPUT_BIT+RND_BIT-1) downto RND_BIT);

end arc_RND_FUNC;
    
