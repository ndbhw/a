library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_signed.all;
use IEEE.std_logic_arith.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity MONO_FIR_WRAPPER is
    generic(
        HOVS                        : natural := 1 ;
        RND_POINT                   : natural := 15;
        TAP_NUM                     : natural := 52
    );
    port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        BYPASS_IN                   : in  std_logic;

        VALID_IN                    : in  std_logic;
        I_DATA_IN                   : in  std_logic_vector(15 downto 0);
        Q_DATA_IN                   : in  std_logic_vector(15 downto 0);
        
        VALID_OUT                   : out std_logic;
        I_DATA_OUT                  : out std_logic_vector(15 downto 0);
        Q_DATA_OUT                  : out std_logic_vector(15 downto 0)
    );
end MONO_FIR_WRAPPER;

architecture arc_RTL of MONO_FIR_WRAPPER is

    component RST_SYNC is
    generic(
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port(
        RST_IN                      : in  std_logic;
        CLK                         : in  std_logic;
        RST_OUT                     : out std_logic
    );
    end component;    

    component MONO_FIR is
        generic(
            HOVS                    : natural := 1 ;
            RND_POINT               : natural := 15;
            TAP_NUM                 : natural := 52
        );
        port(
            RST                     : in  std_logic;
            CLK                     : in  std_logic;

            VALID_IN                : in  std_logic;
            DATA_IN                 : in  std_logic_vector(15 downto 0);

            DATA_OUT                : out std_logic_vector(15 downto 0)
        );
    end component;

    signal rst_fir                  : std_logic := '1';    
    signal data_i_out               : std_logic_vector(15 downto 0);
    signal data_q_out               : std_logic_vector(15 downto 0);
    signal bypass_i_out             : std_logic_vector(15 downto 0);
    signal bypass_q_out             : std_logic_vector(15 downto 0);
    signal bypass_dc                : std_logic_vector( 2 downto 0);

begin

    U_RST_SYNC : RST_SYNC generic map( 4, 200 ) port map( RST , CLK ,  rst_fir );    

    ---------------------------------------------------------------------------------------------------------------------
    ---------------------------------------------------------------------------------------------------------------------
    ---------------------------------------------------------------------------------------------------------------------
    I_SAMPLE : MONO_FIR
    generic map(
        HOVS                        => HOVS                                 , --: natural := 1 ;
        RND_POINT                   => RND_POINT                            , --: natural := 15;
        TAP_NUM                     => TAP_NUM                                --: natural := 52
    )
    port map(
        RST                         => rst_fir                              , --: in  std_logic;
        CLK                         => CLK                                  , --: in  std_logic;

        VALID_IN                    => VALID_IN                             , --: in  std_logic;
        DATA_IN                     => I_DATA_IN                            , --: in  std_logic_vector(15 downto 0);

        DATA_OUT                    => data_i_out                             --: out std_logic_vector(47 downto 0)
    );

    Q_SAMPLE : MONO_FIR
    generic map(
        HOVS                        => HOVS                                 , --: natural := 1 ;
        RND_POINT                   => RND_POINT                            , --: natural := 15;
        TAP_NUM                     => TAP_NUM                                --: natural := 52
    )
    port map(
        RST                         => rst_fir                              , --: in  std_logic;
        CLK                         => CLK                                  , --: in  std_logic;

        VALID_IN                    => VALID_IN                             , --: in  std_logic;
        DATA_IN                     => Q_DATA_IN                            , --: in  std_logic_vector(15 downto 0);

        DATA_OUT                    => data_q_out                             --: out std_logic_vector(47 downto 0)
    );


    BYPASS : process(rst_fir, CLK)
    begin
        if rst_fir = '1' then
            bypass_i_out            <= (others => '0');
            bypass_q_out            <= (others => '0');
        elsif rising_edge(CLK) then
            bypass_i_out        <= I_DATA_IN;
            bypass_q_out        <= Q_DATA_IN;
        end if;
    end process;


    BYPASS_SIG_CDC : process(rst_fir,CLK)
    begin
        if rst_fir = '1' then
            bypass_dc               <= (others => '0');
        elsif rising_edge(CLK) then
            bypass_dc               <= bypass_dc(1 downto 0) & BYPASS_IN;
        end if;
    end process;

    process(rst_fir,CLK)
    begin
        if rst_fir = '1' then
            VALID_OUT               <= '0';
            I_DATA_OUT              <= (others => '0');
            Q_DATA_OUT              <= (others => '0');
        elsif rising_edge(CLK) then
            VALID_OUT               <= VALID_IN;
            if bypass_dc(2) = '0' then
                I_DATA_OUT          <= data_i_out;
                Q_DATA_OUT          <= data_q_out;
            else
                I_DATA_OUT          <= bypass_i_out;
                Q_DATA_OUT          <= bypass_q_out;
            end if;
        end if;
    end process;

end arc_RTL;
