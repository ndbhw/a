library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.numeric_std.all;

entity SIMPLE_DPRAM_DUALCLK is
generic(
    RAM_STYLE      : string  := "BLOCK"; -- DISTRIBUTED or BLOCK
    RAM_INIT_VALUE : integer := 0; 

    DATA_WIDTH     : natural := 8;
    ADDR_WIDTH     : natural := 6
    );
port(
    CLKA           : in  std_logic;
    ENA            : in  std_logic;
    WEA            : in  std_logic;
    ADDRA          : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATAA          : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    CLKB           : in  std_logic;
    ENB            : in  std_logic;
    ADDRB          : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATAB          : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end SIMPLE_DPRAM_DUALCLK;

architecture arc_SIMPLE_DPRAM_DUALCLK of SIMPLE_DPRAM_DUALCLK is

component SIMPLE_DIST_DPRAM_DUALCLK is
generic(
    RAM_INIT_VALUE : integer := 0;

    DATA_WIDTH     : natural := 8;
    ADDR_WIDTH     : natural := 6
    );
port(
    CLKA           : in  std_logic;
    ENA            : in  std_logic;
    WEA            : in  std_logic;
    ADDRA          : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATAA          : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    CLKB           : in  std_logic;
    ENB            : in  std_logic;
    ADDRB          : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATAB          : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end component;

component SIMPLE_BLK_DPRAM_DUALCLK is
generic(
    RAM_INIT_VALUE : integer := 0;

    DATA_WIDTH     : natural := 8;
    ADDR_WIDTH     : natural := 6
    );
port(
    CLKA           : in  std_logic;
    ENA            : in  std_logic;
    WEA            : in  std_logic;
    ADDRA          : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATAA          : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    CLKB           : in  std_logic;
    ENB            : in  std_logic;
    ADDRB          : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATAB          : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end component;

begin

    G_Distributed_RAM : if (RAM_STYLE = "DISTRIBUTED") generate begin

        U_Distributed_Dual_CLK_RAM : SIMPLE_DIST_DPRAM_DUALCLK 
        generic map(
            RAM_INIT_VALUE => RAM_INIT_VALUE , 
                                             
            DATA_WIDTH     => DATA_WIDTH     , 
            ADDR_WIDTH     => ADDR_WIDTH       
            )
        port map(
            CLKA           => CLKA           , 
            ENA            => ENA            , 
            WEA            => WEA            , 
            ADDRA          => ADDRA          , 
            DATAA          => DATAA          , 
                                             
            CLKB           => CLKB           , 
            ENB            => ENB            , 
            ADDRB          => ADDRB          , 
            DATAB          => DATAB            
            );
    end generate;

    G_Block_RAM : if (RAM_STYLE = "BLOCK") generate begin

        U_Block_Dual_CLK_RAM : SIMPLE_BLK_DPRAM_DUALCLK 
        generic map(
            RAM_INIT_VALUE => RAM_INIT_VALUE ,
                                             
            DATA_WIDTH     => DATA_WIDTH     ,
            ADDR_WIDTH     => ADDR_WIDTH      
            )
        port map(
            CLKA           => CLKA           ,
            ENA            => ENA            ,
            WEA            => WEA            ,
            ADDRA          => ADDRA          ,
            DATAA          => DATAA          ,
                                             
            CLKB           => CLKB           ,
            ENB            => ENB            ,
            ADDRB          => ADDRB          ,
            DATAB          => DATAB           
            );
    end generate;

end arc_SIMPLE_DPRAM_DUALCLK;

