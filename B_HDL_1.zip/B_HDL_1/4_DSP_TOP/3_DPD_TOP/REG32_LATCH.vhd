--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2011, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Latch-up Register (Component)                                 --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2011.11.26                                                    --
--              2016.10.06 (v2.0)                                             --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
--   v1.0 - initial release                                                   --
--   v2.0 - modified for bit-masking, k1340.heo (COMP_WRITE)                  --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;

entity REG32_LATCH is
generic(
    BIT_ENABLE  : std_logic_vector(31 downto 0) := (others => '1');
    REG_ADDR    : std_logic_vector( 7 downto 0) := (others => '0')
    );
port(
    RST         : in  std_logic;
    CLK         : in  std_logic;

    CLR_IN      : in  std_logic;   -- Clear input, falling edge detection
    ADDR_IN     : in  std_logic_vector( 7 downto 0); -- Address input
    DATA_IN     : in  std_logic_vector(31 downto 0); -- Event data input
    DATA_OUT    : out std_logic_vector(31 downto 0); -- Status data output
    FLAG_OUT    : out std_logic_vector(31 downto 0)  -- Flag data output
    );
end REG32_LATCH;

architecture arc_REG32_LATCH of REG32_LATCH is

signal data     : std_logic_vector(31 downto 0);
signal data_ret : std_logic_vector(31 downto 0);
signal flag_ret : std_logic_vector(31 downto 0);
signal clr_d1   : std_logic; -- clr_in delay0
signal clr_d2   : std_logic; -- clr_in delay1
signal clr_fe   : std_logic; -- clr_in falling edge

begin

CLR_FE_GEN0 : process(RST, CLK) begin
    if (RST = '1') then
        clr_d1 <= '0';
        clr_d2 <= '0';
    elsif (CLK'event) and (CLK = '1') then
        clr_d1 <= clr_in;
        clr_d2 <= clr_d1;
    end if;
end process;


clr_fe <= ((not clr_d1) and clr_d2); -- falling edge of clr_fe_in

LATCH_N_CLEAR0 : process(RST, CLK) begin
    if (RST = '1') then
        data     <= (others => '0'); 
        data_ret <= (others => '0'); 
        flag_ret <= (others => '0'); 
    elsif (CLK'event) and (CLK = '1') then
        for I in 31 downto 0 loop
        data(I)     <= DATA_IN(I) and BIT_ENABLE(I); 
        data_ret(I) <= data(I); 

        if (data_ret(I) = '1') then
            flag_ret(I) <= '1'; 
        elsif ((clr_fe = '1') and (ADDR_IN = REG_ADDR)) then
            flag_ret(I) <= '0'; 
        end if;
        end loop;
    end if;
end process;

DATA_OUT <= data_ret;
FLAG_OUT <= flag_ret;

end arc_REG32_LATCH;
