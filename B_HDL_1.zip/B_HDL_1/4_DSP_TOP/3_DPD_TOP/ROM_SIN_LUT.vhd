-- Quartus II VHDL Template
-- Dual-Port ROM

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.numeric_std.all;

entity ROM_SIN_LUT is
generic(
    DATA_WIDTH  : natural := 14;
    ADDR_WIDTH  : natural :=  5 
    );
port(
    CLK	 : in  std_logic;
    ADDR : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    RDEN : in  std_logic;
    Q    : out std_logic_vector((DATA_WIDTH -1) downto 0)
    );
end ROM_SIN_LUT;

architecture arc_ROM_SIN_LUT of ROM_SIN_LUT is

	-- Build a 2-D array type for the ROM
--    signal addr_a_r : natural range 0 to 2**ADDR_WIDTH - 1;
--    signal addr_b_r : natural range 0 to 2**ADDR_WIDTH - 1;
    signal q_a_r		: std_logic_vector((DATA_WIDTH -1) downto 0);

	subtype word_t is std_logic_vector((DATA_WIDTH-1) downto 0);
	type memory_t is array(2**ADDR_WIDTH-1 downto 0) of word_t;

	signal rom : memory_t := (
            "11101101111111",
            "11110101111011",
            "11111101111010",
            "00000101111001",
            "00001101101111",
            "00010101101010",
            "00011101011110",
            "00100101001100",
            "00101011101111",
            "00110011001010",
            "00111010011000",
            "01000001011000",
            "01001000000000",
            "01001110011110",
            "01010100101000",
            "01011010011101",
            "01011010100100",
            "01100000000011",
            "01100101001000",
            "01101001110101",
            "01101110000011",
            "01110001111010",
            "01110101010101",
            "01111000010011",
            "01111010011111",
            "01111100100100",
            "01111110001010",
            "01111111010001",
            "01111111110111",
            "01111111111111",
            "01111111100111",
            "01111110101110"
    );

begin

    process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (RDEN = '1') then
                q_a_r <= rom(conv_integer(ADDR));
            end if;
        end if;
    end process;
    
    process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            Q <= q_a_r;
        end if;
    end process;

end arc_ROM_SIN_LUT;

