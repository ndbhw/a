----------------------------------------------------------------------------
-- Designer   : Kyoung Heo, (k1340.heo@samsung.com)
-- Block Name : RX_SSD
-- Function   : VSWR Measure at RX only Mode
-- Revision   : - ver 1.0, First Relase at VzW RFV01U-D2A
----------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

--------------------------------------------------
-- PATH_SEL = FB_VC
-- 0000  : FWD antenna #0
-- 0001  : RVS antenna #0
-- 0010  : FWD antenna #1
-- 0011  : RVS antenna #1
-- 0100  : FWD antenna #2
-- 0101  : RVS antenna #2
-- 0110  : FWD antenna #3
-- 0111  : RVS antenna #3
-- 1000  : FWD antenna #4
-- 1001  : RVS antenna #4
-- 1010  : FWD antenna #5
-- 1011  : RVS antenna #5
-- 1100  : FWD antenna #6
-- 1101  : RVS antenna #6
-- 1110  : FWD antenna #7
-- 1111  : RVS antenna #7
--------------------------------------------------

entity RX_SSD is
generic(
    DEVICE                 : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    RX_SSD_IMPLEMENTATION  : boolean :=     TRUE ;
    TX_ANT_NUM             : natural :=       4  ;
    FB_PATH_NUM            : natural :=       1  ;
    HOVS                   : natural :=       2  
    );
port(
    RST_DSP                : in  std_logic;
    CLK_DSP                : in  std_logic;

    -- Control
    PATH_SEL_IN            : in  std_logic_vector( 4 downto 0);
    CTRL_EN_IN             : in  std_logic;
    REPEAT_PER_SW_IN       : in  std_logic_vector(16 downto 0);
    ACCU_LENGTH_IN         : in  std_logic_vector(16 downto 0);
    PATTERN_GAIN_IN        : in  std_logic_vector(15 downto 0);

    ACCU_DONE_OUT          : out std_logic;

    -- FB SW Info
    FBSW_START_TRIG_IN     : in  std_logic;
    FB_VC_IN               : in  std_logic_vector( 4 downto 0);

    -- Traffic
    REF_FS_10ms_IN         : in  std_logic;

    DL_VLD_IN              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DL_I_IN                : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    DL_Q_IN                : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    REF_FS_10ms_OUT        : out std_logic;

    DL_VLD_OUT             : out std_logic_vector( TX_ANT_NUM-1 downto 0);
    DL_I_OUT               : out std_logic_array16(TX_ANT_NUM-1 downto 0);
    DL_Q_OUT               : out std_logic_array16(TX_ANT_NUM-1 downto 0);

    FB_FS_10ms_IN          : in  std_logic;

    FB_VLD_IN              : in  std_logic_vector( FB_PATH_NUM-1 downto 0);
    FB_I_IN                : in  std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_Q_IN                : in  std_logic_array16(FB_PATH_NUM-1 downto 0);

    -- CPU Domain
    RST_CPU                : in  std_logic;
    CLK_CPU                : in  std_logic;

    PTN_WREN_IN            : in  std_logic;
    PTN_WADDR_IN           : in  std_logic_vector( 8 downto 0);
    PTN_WDATA_IN           : in  std_logic_vector(31 downto 0);

    MEM_RDEN_IN            : in  std_logic;
    MEM_ADDR_IN            : in  std_logic_vector( 9 downto 0);
    MEM_DATA_OUT           : out std_logic_vector(31 downto 0)
    );
end RX_SSD;

architecture arc_RX_SSD of RX_SSD is

component RST_SYNC is
generic(
    DLY_NUM                : natural :=   3 ;  -- Number of delay.
    MAX_FANOUT_NUM         : integer := 200    -- Number of maximum fanout
    );
port(
    RST_IN                 : in  std_logic;    -- Active high asynchronous reset
    CLK                    : in  std_logic;    -- clock to be sync'ed to
    RST_OUT                : out std_logic     -- "Synchronised" reset signal
    );         
end component;

component RX_SSD_PTN_GEN is
generic(
    HS_MODE                : boolean := FALSE ;
    HOVS                   : natural :=     2 
    );
port(
    RST_DSP                : in  std_logic;
    CLK_DSP                : in  std_logic;
    CLK_CPU                : in  std_logic;

    PTN_WREN_IN            : in  std_logic;
    PTN_WADDR_IN           : in  std_logic_vector( 8 downto 0);
    PTN_WDATA_IN           : in  std_logic_vector(31 downto 0);

    PTN_GEN_EN_IN          : in  std_logic;
    REPEAT_PER_SW_IN       : in  std_logic_vector(16 downto 0);

    FS_10ms_RPLS_IN        : in  std_logic;

    PTN_VLD_OUT            : out std_logic;
    PTN_I_OUT              : out std_logic_vector(15 downto 0);
    PTN_Q_OUT              : out std_logic_vector(15 downto 0)
    );
end component;

component PATH_DGATT is
generic(
    DEVICE                 : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    RND_BIT                : natural :=       15 ;
    HOVS                   : natural :=        1
    );
port(
    RST                    : in  std_logic;
    CLK                    : in  std_logic;

    DATA_VALID_IN          : in  std_logic;
    DATA_I_IN              : in  std_logic_vector(15 downto 0);
    DATA_Q_IN              : in  std_logic_vector(15 downto 0);

    DGATT_VAL              : in  std_logic_vector(15 downto 0);

    DATA_VALID_OUT         : out std_logic;
    DATA_I_OUT             : out std_logic_vector(15 downto 0);
    DATA_Q_OUT             : out std_logic_vector(15 downto 0)
    );
end component;

component BUF_SAMPLE_DLY is
generic(
    RAM_STYLE                      : string := "DISTRIBUTED"; -- "DISTRIBUTED" or "BLOCK"
    RESOLUTION                     : string := "CLOCK";       -- "CLOCK" or "SAMPLE_RATE"

    DATA_WIDTH                     : natural;
    ADDR_WIDTH                     : natural
    );
port(
    RST                            : in  std_logic;
    CLK                            : in  std_logic;

    DELAY_VALUE_IN                 : in  std_logic_vector(ADDR_WIDTH-1 downto 0); 

    SAMPLE_VLD_IN                  : in  std_logic;
    SAMPLE_IN                      : in  std_logic_vector(DATA_WIDTH-1 downto 0); 
    SAMPLE_DELAY_OUT               : out std_logic_vector(DATA_WIDTH-1 downto 0) 
    );
end component;

component PULSE_DELAY is
generic(
    CLK_CNTDLY             : integer        -- 0 ~ 8191 clock
    );
port(
    RST                    : in  std_logic; -- Active high reset
    CLK                    : in  std_logic; -- Clock
    
    BYPASS_IN              : in  std_logic; -- '0' normal mode, '1' bypass mode
    
    PULSE_IN               : in  std_logic;

    PULSE_DELAY_OUT        : out std_logic
    );
end component;

component RX_SSD_ACCUMULATOR is
generic(
    HS_MODE                : boolean := FALSE ;
    HOVS                   : natural :=     2  
    );
port(
    RST                    : in  std_logic;
    CLK                    : in  std_logic;

    ACCU_EN_IN             : in  std_logic;
    ACCU_LENGTH_IN         : in  std_logic_vector(16 downto 0);
    REPEAT_PER_SW_IN       : in  std_logic_vector(16 downto 0);
    ACCU_DONE_FLG_OUT      : out std_logic;

    FS_10ms_RPLS_IN        : in  std_logic;
    FBSW_ALIGN_IN          : in  std_logic;

    FB_VLD_IN              : in  std_logic;
    FB_I_IN                : in  std_logic_vector(15 downto 0);
    FB_Q_IN                : in  std_logic_vector(15 downto 0);

    MEM_RDEN_I_IN            : in  std_logic;
    MEM_ADDR_I_IN          : in  std_logic_vector( 8 downto 0);
    MEM_DATA_I_OUT         : out std_logic_vector(31 downto 0);

    MEM_RDEN_Q_IN            : in  std_logic;
    MEM_ADDR_Q_IN          : in  std_logic_vector( 8 downto 0);
    MEM_DATA_Q_OUT         : out std_logic_vector(31 downto 0)
    );
end component;

signal rst_sync_dsp        : std_logic;
signal rst_sync_cpu        : std_logic;

signal ctrl_en_sh          : std_logic_vector( 3 downto 0);
signal ctrl_en_rpls        : std_logic;
signal ctrl_en_fpls        : std_logic;

signal fbsw_start_trig_sh  : std_logic_vector( 4 downto 0);

signal ref_10ms_sh         : std_logic_vector( 2 downto 0);
signal ref_10ms_rpls       : std_logic;

signal fb_10ms_sh          : std_logic_vector( 2 downto 0);
signal fb_10ms_rpls        : std_logic;

signal path_sel_align      : std_logic_vector( 4 downto 0);
signal repeat_per_sw_align : std_logic_vector(16 downto 0);
signal accu_length_align   : std_logic_vector(16 downto 0);
signal pattern_gain_align  : std_logic_vector(15 downto 0);

signal ctrl_en_state       : std_logic_vector( 1 downto 0);
signal ctrl_en_align       : std_logic;

signal fbsw_align          : std_logic;

signal internal_ssd_en     : std_logic;

signal done_flg            : std_logic;
signal done_flg_dspclk     : std_logic;
signal done_flg_d1         : std_logic;
signal done_pls            : std_logic;

signal ctrl_en_sh_cpuclk   : std_logic_vector( 1 downto 0);
signal ptn_wren            : std_logic;

signal ptn_gen_vld         : std_logic;
signal ptn_gen_i           : std_logic_vector(15 downto 0);
signal ptn_gen_q           : std_logic_vector(15 downto 0);

signal ptn_gain_out_vld    : std_logic;
signal ptn_gain_out_i      : std_logic_vector(15 downto 0);
signal ptn_gain_out_q      : std_logic_vector(15 downto 0);

signal dl_dly_i            : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal dl_dly_q            : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal dl_path_switch      : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal ref_fs_10ms_dly     : std_logic;
signal dl_out_vld          : std_logic_vector( TX_ANT_NUM-1 downto 0);
signal dl_out_i            : std_logic_array16(TX_ANT_NUM-1 downto 0);
signal dl_out_q            : std_logic_array16(TX_ANT_NUM-1 downto 0);

signal fb_mux_vld          : std_logic;
signal fb_mux_i            : std_logic_vector(15 downto 0);
signal fb_mux_q            : std_logic_vector(15 downto 0);

signal mem_rden_sh         : std_logic_vector( 2 downto 0);
signal mem_rden_rpls       : std_logic;
signal mem_rden_rpls_sh    : std_logic_vector( 2 downto 0);

signal mem_rden_i          : std_logic;
signal mem_rden_q          : std_logic;

signal mem_raddr           : std_logic_vector( 9 downto 0);
signal mem_raddr_i         : std_logic_vector( 8 downto 0);
signal mem_raddr_q         : std_logic_vector( 8 downto 0);

signal mem_rdata_i         : std_logic_vector(31 downto 0);
signal mem_rdata_q         : std_logic_vector(31 downto 0);

signal mem_rdata           : std_logic_vector(31 downto 0);

begin

    -- DSP Clock Domain
    U_RST_SYNC_DSP : RST_SYNC generic map(4, 100) port map(RST_DSP, CLK_DSP, rst_sync_dsp); 

    G_RX_SSD_Implementation : if (RX_SSD_IMPLEMENTATION = TRUE) generate begin
        P_Clock_Shift_HS : process(CLK_DSP) begin
            if (CLK_DSP'event) and (CLK_DSP = '1') then
                ctrl_en_sh         <= ctrl_en_sh(2 downto 0) & CTRL_EN_IN;
                ctrl_en_rpls       <= ctrl_en_sh(1) and (not ctrl_en_sh(2));
                ctrl_en_fpls       <= (not ctrl_en_sh(1)) and ctrl_en_sh(2);

                fbsw_start_trig_sh <= fbsw_start_trig_sh(3 downto 0) & FBSW_START_TRIG_IN;

                ref_10ms_sh        <= ref_10ms_sh(1 downto 0) & REF_FS_10ms_IN;  
                ref_10ms_rpls      <= ref_10ms_sh(1) and (not ref_10ms_sh(2));              

                fb_10ms_sh         <= fb_10ms_sh(1 downto 0) & FB_FS_10ms_IN; 
                fb_10ms_rpls       <= fb_10ms_sh(1) and not (fb_10ms_sh(2));             
            end if;
        end process;

        P_Register_Setting_Align_HS : process(CLK_DSP) begin
            if (CLK_DSP'event) and (CLK_DSP = '1') then
                if (ctrl_en_rpls = '1') then
                    path_sel_align      <= PATH_SEL_IN           ;            
                    repeat_per_sw_align <= REPEAT_PER_SW_IN - '1';            
                    accu_length_align   <= ACCU_LENGTH_IN        ;
                    pattern_gain_align  <= PATTERN_GAIN_IN       ;
                else
                    path_sel_align      <= path_sel_align     ;            
                    repeat_per_sw_align <= repeat_per_sw_align;            
                    accu_length_align   <= accu_length_align  ;
                    pattern_gain_align  <= pattern_gain_align ;
                end if;
            end if;
        end process;
 
        P_Control_Enable_Align_HS : process(CLK_DSP) begin
            if (CLK_DSP'event) and (CLK_DSP = '1') then
                if (rst_sync_dsp = '1') then
                    ctrl_en_state <= "11";
                else
                    if ((ctrl_en_state = "11") and (ctrl_en_rpls = '1')) then
                        ctrl_en_state <= "00";
                    elsif ((ctrl_en_state = "00") and (fbsw_start_trig_sh(2) = '1')) then
                        ctrl_en_state <= "01";
                    elsif ((ctrl_en_state = "01") and (done_pls = '1')) then 
                        ctrl_en_state <= "10";
                    elsif ((ctrl_en_state = "10") and (ctrl_en_fpls = '1')) then 
                        ctrl_en_state <= "11";
                    else
                        ctrl_en_state <= ctrl_en_state;
                    end if;
                end if;

                if (ctrl_en_sh(2) = '1') then
                    if (ctrl_en_state = "01") then
                        ctrl_en_align <= '1';
                    else
                        ctrl_en_align <= '0';
                    end if;
                else
                    ctrl_en_align <= '0';
                end if;
            end if;
        end process;

        P_Feedback_Switch_Aligned_HS : process(CLK_DSP) begin 
            if (CLK_DSP'event) and (CLK_DSP = '1') then
                if (path_sel_align = FB_VC_IN) then      
                    fbsw_align <= '1';
                else
                    fbsw_align <= '0';
                end if;
            end if;
        end process;

        P_Internal_SSD_Enable_HS : process(CLK_DSP) begin
            if (CLK_DSP'event) and (CLK_DSP = '1') then
                internal_ssd_en <= ctrl_en_align and fbsw_align;
            end if;
        end process;

        
        P_DL_Path_Switch_HS : process(CLK_DSP) begin
            if (CLK_DSP'event) and (CLK_DSP = '1') then
                if (ctrl_en_sh(3) = '0') then
                    dl_path_switch <= (others => '0');
                else
                    case (path_sel_align(4 downto 1)) is      
                        when x"0"   => dl_path_switch <= "01"; -- FWD/RVS A 
                        when x"1"   => dl_path_switch <= "10"; -- FWD/RVS B
                        when others => dl_path_switch <= "00"; 
                    end case;
                end if;
            end if;
        end process;

        U_SSD_Pattern_Generator : RX_SSD_PTN_GEN 
        generic map(
            HS_MODE                => TRUE                   ,
            HOVS                   => HOVS                     
            )
        port map(
            RST_DSP                => rst_sync_dsp           , 
            CLK_DSP                => CLK_DSP                , 
            CLK_CPU                => CLK_CPU                ,
        
            PTN_WREN_IN            => ptn_wren               , 
            PTN_WADDR_IN           => PTN_WADDR_IN           , 
            PTN_WDATA_IN           => PTN_WDATA_IN           , 

            PTN_GEN_EN_IN          => internal_ssd_en        , 
            REPEAT_PER_SW_IN       => repeat_per_sw_align    , 
        
            FS_10ms_RPLS_IN        => ref_10ms_rpls          , 
        
            PTN_VLD_OUT            => ptn_gen_vld            ,
            PTN_I_OUT              => ptn_gen_i              ,
            PTN_Q_OUT              => ptn_gen_q               
            );

        U_SSD_GAIN : PATH_DGATT 
        generic map(
            DEVICE                 => DEVICE                 , 
            RND_BIT                => 13                     , 
            HOVS                   => HOVS                    
            )
        port map(
            RST                    => rst_sync_dsp           , 
            CLK                    => CLK_DSP                , 
        
            DATA_VALID_IN          => ptn_gen_vld            , 
            DATA_I_IN              => ptn_gen_i              , 
            DATA_Q_IN              => ptn_gen_q              , 
        
            DGATT_VAL              => pattern_gain_align     , 
        
            DATA_VALID_OUT         => ptn_gain_out_vld       ,
            DATA_I_OUT             => ptn_gain_out_i         ,
            DATA_Q_OUT             => ptn_gain_out_q          
            );

        G_DL_DLY_COMP : for I in 0 to (TX_ANT_NUM-1) generate begin
            U_DL_DLY_COMP_I : BUF_SAMPLE_DLY generic map("BLOCK", "SAMPLE_RATE", 16, 4) port map(rst_sync_dsp, CLK_DSP, x"B", DL_VLD_IN(I), DL_I_IN(I), dl_dly_i(I));
            U_DL_DLY_COMP_Q : BUF_SAMPLE_DLY generic map("BLOCK", "SAMPLE_RATE", 16, 4) port map(rst_sync_dsp, CLK_DSP, x"B", DL_VLD_IN(I), DL_Q_IN(I), dl_dly_q(I));
        end generate;

        U_DL_DLY_10ms : PULSE_DELAY generic map(24) port map(rst_sync_dsp, CLK_DSP, '0', REF_FS_10ms_IN, ref_fs_10ms_dly);

        G_DL_Path_GEN : for I in 0 to (TX_ANT_NUM-1) generate begin
            P_DL_Path_Switch : process(CLK_DSP) begin
                if (CLK_DSP'event) and (CLK_DSP = '1') then
                    dl_out_vld(I) <= DL_VLD_IN(I);            
                    if (dl_path_switch(I) = '1') then 
                        dl_out_i(I) <= ptn_gain_out_i;
                        dl_out_q(I) <= ptn_gain_out_q;
                    else
                        dl_out_i(I) <= dl_dly_i(I);
                        dl_out_q(I) <= dl_dly_q(I);
                    end if;
                end if;
            end process;
        end generate;

        REF_FS_10ms_OUT <= ref_fs_10ms_dly;

        DL_VLD_OUT      <= dl_out_vld;
        DL_I_OUT        <= dl_out_i;  
        DL_Q_OUT        <= dl_out_q;  

        G_2FB_Path_NUM : if (FB_PATH_NUM = 2) generate begin
            P_FB_MUX : process(rst_sync_dsp, CLK_DSP) begin
                if (rst_sync_dsp = '1') then
                    fb_mux_vld <= '0';             
                    fb_mux_i   <= (others => '0'); 
                    fb_mux_q   <= (others => '0'); 
                elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                    if (FB_VC_IN(2) = '0') then 
                        fb_mux_vld <= FB_VLD_IN(0);             
                        fb_mux_i   <= FB_I_IN(0); 
                        fb_mux_q   <= FB_Q_IN(0); 
                    else
                        fb_mux_vld <= FB_VLD_IN(1);             
                        fb_mux_i   <= FB_I_IN(1); 
                        fb_mux_q   <= FB_Q_IN(1); 
                    end if;
                end if;
            end process;
        end generate;

        G_1FB_Path_NUM : if (FB_PATH_NUM = 1) generate begin
            P_FB_MUX : process(rst_sync_dsp, CLK_DSP) begin
                if (rst_sync_dsp = '1') then
                    fb_mux_vld <= '0';             
                    fb_mux_i   <= (others => '0'); 
                    fb_mux_q   <= (others => '0'); 
                elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                    fb_mux_vld <= FB_VLD_IN(0);             
                    fb_mux_i   <= FB_I_IN(0); 
                    fb_mux_q   <= FB_Q_IN(0); 
                end if;
            end process;
        end generate;

        U_RX_SSD_Accumulator : RX_SSD_ACCUMULATOR 
        generic map(
            HS_MODE                => TRUE                   ,
            HOVS                   => HOVS                   
            )
        port map(
            RST                    => rst_sync_dsp           , 
            CLK                    => CLK_DSP                , 
        
            ACCU_EN_IN             => ctrl_en_align          , 
            ACCU_LENGTH_IN         => accu_length_align      , 
            REPEAT_PER_SW_IN       => repeat_per_sw_align    , 
            ACCU_DONE_FLG_OUT      => done_flg               , 
        
            FS_10ms_RPLS_IN        => fb_10ms_rpls           , 
            FBSW_ALIGN_IN          => fbsw_align             , 
        
            FB_VLD_IN              => fb_mux_vld             , 
            FB_I_IN                => fb_mux_i               , 
            FB_Q_IN                => fb_mux_q               , 
        
            MEM_RDEN_I_IN          => mem_rden_i             , 
            MEM_ADDR_I_IN          => mem_raddr_i            , 
            MEM_DATA_I_OUT         => mem_rdata_i            ,

            MEM_RDEN_Q_IN          => mem_rden_q             , 
            MEM_ADDR_Q_IN          => mem_raddr_q            , 
            MEM_DATA_Q_OUT         => mem_rdata_q                   
            );

        P_ACCU_Done_PLS : process(rst_sync_dsp, CLK_DSP) begin
            if (rst_sync_dsp = '1') then
                done_flg_d1 <= '0';
                done_pls    <= '0';
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                done_flg_d1 <= done_flg;
                done_pls    <= done_flg and (not done_flg_d1);

                if (ctrl_en_rpls = '1') then 
                    done_flg_dspclk <= '0';
                else
                    if (done_pls = '1') then    
                        done_flg_dspclk <= '1';
                    else
                        done_flg_dspclk <= done_flg_dspclk;
                    end if;
                end if;
            end if;
        end process;

        ACCU_DONE_OUT  <= done_flg_dspclk;       

        P_CPUIF_to_DSP_CDC : process(rst_sync_dsp, CLK_DSP) begin
            if (rst_sync_dsp = '1') then
                mem_rden_sh      <= (others => '0'); 
                mem_rden_rpls    <= '0';             
                mem_rden_rpls_sh <= (others => '0'); 

                mem_raddr        <= (others => '0');
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                mem_rden_sh      <= mem_rden_sh(1 downto 0) & MEM_RDEN_IN; 
                mem_rden_rpls    <= mem_rden_sh(1) and (not mem_rden_sh(2));             
                mem_rden_rpls_sh <= mem_rden_rpls_sh(1 downto 0) & mem_rden_rpls; 

                if (mem_rden_rpls = '1') then    
                    mem_raddr <= MEM_ADDR_IN;
                else
                    mem_raddr <= mem_raddr;
                end if;
            end if;
        end process;

        P_ACCU_MEM_Interface : process(rst_sync_dsp, CLK_DSP) begin
            if (rst_sync_dsp = '1') then
                mem_rden_i  <= '0';            
                mem_rden_q  <= '0';            
                
                mem_raddr_i <= (others => '0');
                mem_raddr_q <= (others => '0');

                mem_rdata   <= (others => '0');
            elsif (CLK_DSP'event) and (CLK_DSP = '1') then
                if (mem_raddr(9) = '0') then 
                    mem_rden_i  <= mem_rden_rpls_sh(1);            
                    mem_rden_q  <= '0';            
                
                    mem_raddr_i <= mem_raddr(8 downto 0);
                    mem_raddr_q <= (others => '0');

                    mem_rdata   <= mem_rdata_i;
                else
                    mem_rden_i  <= '0';            
                    mem_rden_q  <= mem_rden_rpls_sh(1);            
                
                    mem_raddr_i <= (others => '0');
                    mem_raddr_q <= mem_raddr(8 downto 0);

                    mem_rdata   <= mem_rdata_q;
                end if;
            end if;
        end process;

        MEM_DATA_OUT <= mem_rdata;

        -- CPU Clock Domain
        U_RST_SYNC_CPU : RST_SYNC generic map(4, 100) port map(RST_CPU, CLK_CPU, rst_sync_cpu); 

        P_Pattern_Write_Enable : process(rst_sync_cpu, CLK_CPU) begin
            if (rst_sync_cpu = '1') then
                ctrl_en_sh_cpuclk   <= (others => '0');
                ptn_wren            <= '0';
            elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                ctrl_en_sh_cpuclk   <= ctrl_en_sh_cpuclk(0) & CTRL_EN_IN;
                ptn_wren            <= (not ctrl_en_sh_cpuclk(1)) and PTN_WREN_IN;
            end if;
        end process;

    end generate;

    G_Unusing_RX_SSD : if (RX_SSD_IMPLEMENTATION = FALSE) generate begin

        REF_FS_10ms_OUT     <= REF_FS_10ms_IN;
                                              
        DL_VLD_OUT          <= DL_VLD_IN;     
        DL_I_OUT            <= DL_I_IN;       
        DL_Q_OUT            <= DL_Q_IN;       

        MEM_DATA_OUT        <= (others => '0');

        rst_sync_dsp        <= '0'; 
        rst_sync_cpu        <= '0'; 
        
        ctrl_en_sh          <= (others => '0'); 
        ctrl_en_rpls        <= '0'; 
        ctrl_en_fpls        <= '0'; 
        
        fbsw_start_trig_sh  <= (others => '0'); 
        
        ref_10ms_sh         <= (others => '0'); 
        ref_10ms_rpls       <= '0';             
        
        fb_10ms_sh          <= (others => '0'); 
        fb_10ms_rpls        <= '0';             
        
        path_sel_align      <= (others => '0'); 
        repeat_per_sw_align <= (others => '0'); 
        accu_length_align   <= (others => '0'); 
        pattern_gain_align  <= (others => '0'); 
        
        ctrl_en_state       <= "11";
        ctrl_en_align       <= '0'; 
        
        fbsw_align          <= '0'; 
        
        internal_ssd_en     <= '0'; 
        
        done_flg            <= '0'; 
        done_flg_d1         <= '0'; 
        done_pls            <= '0'; 
        
        ptn_wren            <= '0';

        ptn_gen_vld         <= '0';
        ptn_gen_i           <= (others => '0'); 
        ptn_gen_q           <= (others => '0'); 
        
        ptn_gain_out_vld    <= '0'; 
        ptn_gain_out_i      <= (others => '0'); 
        ptn_gain_out_q      <= (others => '0'); 
        
        dl_dly_i            <= (others => (others => '0')); 
        dl_dly_q            <= (others => (others => '0')); 
        
        dl_path_switch      <= (others => '0'); 
        ref_fs_10ms_dly     <= '0';
        dl_out_vld          <= (others => '0');             
        dl_out_i            <= (others => (others => '0')); 
        dl_out_q            <= (others => (others => '0')); 
        
        fb_mux_vld          <= '0'; 
        fb_mux_i            <= (others => '0'); 
        fb_mux_q            <= (others => '0'); 
        
        mem_rden_sh         <= (others => '0'); 
        mem_rden_rpls       <= '0'; 
        mem_rden_rpls_sh    <= (others => '0'); 
        
        mem_rden_i          <= '0'; 
        mem_rden_q          <= '0'; 
        
        mem_raddr           <= (others => '0'); 
        mem_raddr_i         <= (others => '0'); 
        mem_raddr_q         <= (others => '0'); 
        
        mem_rdata_i         <= (others => '0'); 
        mem_rdata_q         <= (others => '0'); 
        
        mem_rdata           <= (others => '0'); 

    end generate;

end arc_RX_SSD;
    
    
