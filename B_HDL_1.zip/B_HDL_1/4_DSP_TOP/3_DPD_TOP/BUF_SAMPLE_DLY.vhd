-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block Name : BrUF_SAMPLE_DLY

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity BUF_SAMPLE_DLY is
generic(
    RAM_STYLE            : string := "DISTRIBUTED"; -- "DISTRIBUTED" or "BLOCK"
    RESOLUTION           : string := "CLOCK";       -- "CLOCK" or "SAMPLE_RATE"

    DATA_WIDTH           : natural;
    ADDR_WIDTH           : natural
    );
port(
    RST                  : in  std_logic;
    CLK                  : in  std_logic;

    DELAY_VALUE_IN       : in  std_logic_vector(ADDR_WIDTH-1 downto 0); 

    SAMPLE_VLD_IN        : in  std_logic;
    SAMPLE_IN            : in  std_logic_vector(DATA_WIDTH-1 downto 0); 
    SAMPLE_DELAY_OUT     : out std_logic_vector(DATA_WIDTH-1 downto 0) 
    );
end BUF_SAMPLE_DLY;

architecture arc_BUF_SAMPLE_DLY of BUF_SAMPLE_DLY is

component RST_SYNC is
generic(
    DLY_NUM              : natural := 3;    -- Number of delay.
    MAX_FANOUT_NUM       : integer := 200   -- Number of maximum fanout
    );
port(
    RST_IN               : in  std_logic;   -- Active high asynchronous reset
    CLK                  : in  std_logic;   -- clock to be sync'ed to
    RST_OUT              : out std_logic    -- "Synchronised" reset signal
    );         
end component;

component SIMPLE_DPRAM is
generic(
    RAM_TYPE             : string  := "BLOCK"; -- DISTRIBUTED or BLOCK
    RAM_INIT_VALUE       : integer := 0 ; 
                                        
    DATA_WIDTH           : natural := 8 ;
    ADDR_WIDTH           : natural := 6
    );
port(
    CLK_A	             : in  std_logic;
    EN_A                 : in  std_logic;
    WE_A                 : in  std_logic;
    ADDR_A               : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATA_A               : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    CLK_B	             : in  std_logic;
    EN_B                 : in  std_logic;
    ADDR_B               : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATA_B               : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end component;

constant zeros           : std_logic_vector(ADDR_WIDTH-1 downto 0) := (others => '0');

signal rst_synch         : std_logic;

signal col_flag          : std_logic;
signal dly_flag          : std_logic_vector( 3 downto 0);

signal addr_cnt          : std_logic_vector(ADDR_WIDTH-1 downto 0);
signal buf_raddr         : std_logic_vector(ADDR_WIDTH-1 downto 0);
signal buf_rdata         : std_logic_vector(DATA_WIDTH-1 downto 0);
signal buf_waddr         : std_logic_vector(ADDR_WIDTH-1 downto 0);
signal buf_wdata         : std_logic_vector(DATA_WIDTH-1 downto 0);

signal nrst              : std_logic;
signal buf_ena           : std_logic;

signal dly_value         : std_logic_vector(ADDR_WIDTH-1 downto 0);

signal sample_d1         : std_logic_vector(DATA_WIDTH-1 downto 0);
signal sample_d2         : std_logic_vector(DATA_WIDTH-1 downto 0);
signal sample_d3         : std_logic_vector(DATA_WIDTH-1 downto 0);

signal sample_delayed    : std_logic_vector(DATA_WIDTH-1 downto 0) := (others=>'0');

attribute KEEP : string;
attribute KEEP of nrst      : signal is "TRUE";
attribute KEEP of buf_ena   : signal is "TRUE";
attribute KEEP of buf_waddr : signal is "TRUE";
attribute KEEP of buf_raddr : signal is "TRUE";

begin

    U_RST_SYNC : RST_SYNC generic map(4, 200) port map(RST, CLK, rst_synch);

    P_Low_Delay_Flag : process(rst_synch, CLK) begin
        if (rst_synch = '1') then
            col_flag <= '0';        
            dly_flag <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (DELAY_VALUE_IN = zeros(ADDR_WIDTH-1 downto 3) & "100") then
                col_flag <= '1';         
            else
                col_flag <= '0';         
            end if;

            if (DELAY_VALUE_IN = zeros) then
                dly_flag(0) <= '1';
            else
                dly_flag(0) <= '0';
            end if;

            if (DELAY_VALUE_IN = zeros(ADDR_WIDTH-1 downto 2) & "01") then
                dly_flag(1) <= '1';
            else
                dly_flag(1) <= '0';
            end if;

            if (DELAY_VALUE_IN = zeros(ADDR_WIDTH-1 downto 2) & "10") then
                dly_flag(2) <= '1';
            else
                dly_flag(2) <= '0';
            end if;

            if (DELAY_VALUE_IN = zeros(ADDR_WIDTH-1 downto 2) & "11") then
                dly_flag(3) <= '1';
            else
                dly_flag(3) <= '0';
            end if;
        end if;
    end process;

    P_Delay_Value : process(rst_synch, CLK) begin
        if (rst_synch = '1') then
            dly_value <= conv_std_logic_vector(1, ADDR_WIDTH);
        elsif (CLK'event) and (CLK = '1') then
            if (col_flag = '1') then
                dly_value <= conv_std_logic_vector(1, ADDR_WIDTH);
            else
                dly_value <= DELAY_VALUE_IN - 4;
            end if;
        end if;
    end process;

    G_ADDR_CLK_CTRL : if (RESOLUTION = "CLOCK") generate begin        
        P_ADDR_CLK_CTRL : process(rst_synch, CLK) begin
            if (rst_synch = '1') then
                addr_cnt  <= (others => '0');
                buf_raddr <= (others => '0');        
                buf_waddr <= conv_std_logic_vector(2, ADDR_WIDTH);    
                buf_wdata <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                addr_cnt  <= addr_cnt + '1' ;
                buf_raddr <= addr_cnt;        
                buf_waddr <= addr_cnt + dly_value;        

                buf_wdata <= SAMPLE_IN;
            end if;
        end process;
    end generate;

    G_ADDR_VLD_CTRL : if (RESOLUTION = "SAMPLE_RATE") generate begin 
        P_ADDR_CLK_CTRL : process(rst_synch, CLK) begin
            if (rst_synch = '1') then
                addr_cnt  <= (others => '0');
                buf_raddr <= (others => '0');        
                buf_waddr <= conv_std_logic_vector(2, ADDR_WIDTH);        
                buf_wdata <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                if (SAMPLE_VLD_IN = '1') then 
                    addr_cnt  <= addr_cnt + '1' ;
                    buf_raddr <= addr_cnt;        
                    buf_waddr <= addr_cnt + dly_value;        

                    buf_wdata <= SAMPLE_IN;
                end if;
            end if;
        end process;
    end generate;

    P_BUF_EN : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            nrst    <= not RST; 
            buf_ena <= nrst;
        end if;
    end process;

    U_Buffer_Delay : SIMPLE_DPRAM 
    generic map(
        RAM_TYPE            => RAM_STYLE , 
        RAM_INIT_VALUE       => 0         , 

        DATA_WIDTH           => DATA_WIDTH, 
        ADDR_WIDTH           => ADDR_WIDTH  
        )
    port map(
        CLK_A	             => CLK       , 
        EN_A                 => buf_ena   , 
        WE_A                 => '1'       , 
        ADDR_A               => buf_waddr , 
        DATA_A               => buf_wdata , 
                                          
        CLK_B	             => CLK       , 
        EN_B                 => '1'       , 
        ADDR_B               => buf_raddr , 
        DATA_B               => buf_rdata   
        );

    P_Sample_Clock_Delay : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            sample_d1 <= SAMPLE_IN;
            sample_d2 <= sample_d1;
            sample_d3 <= sample_d2;
        end if;
    end process;

    P_Data_Delay_Selection : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (col_flag = '1') then
                sample_delayed <= sample_d3; 
            else
                case (dly_flag) is
                    when "0001" => sample_delayed <= SAMPLE_IN; 
                    when "0010" => sample_delayed <= SAMPLE_IN; 
                    when "0100" => sample_delayed <= sample_d1; 
                    when "1000" => sample_delayed <= sample_d2; 
                    when others => sample_delayed <= buf_rdata; 
                end case;
            end if;
        end if;
    end process;

    SAMPLE_DELAY_OUT <= sample_delayed; 

end arc_BUF_SAMPLE_DLY;
