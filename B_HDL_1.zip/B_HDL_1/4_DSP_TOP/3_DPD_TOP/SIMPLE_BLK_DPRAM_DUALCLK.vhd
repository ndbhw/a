-- Quartus Prime VHDL Template
-- Simple Dual-Port RAM with different read/write addresses and
-- different read/write clock

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.numeric_std.all;

entity SIMPLE_BLK_DPRAM_DUALCLK is
generic(
    RAM_INIT_VALUE : integer := 0;

    DATA_WIDTH     : natural := 8;
    ADDR_WIDTH     : natural := 6
    );
port(
    CLKA           : in  std_logic;
    ENA            : in  std_logic;
    WEA            : in  std_logic;
    ADDRA          : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATAA          : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    CLKB           : in  std_logic;
    ENB            : in  std_logic;
    ADDRB          : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATAB          : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end SIMPLE_BLK_DPRAM_DUALCLK;

architecture arc_SIMPLE_BLK_DPRAM_DUALCLK of SIMPLE_BLK_DPRAM_DUALCLK is

constant mem_init_value  : std_logic_vector((DATA_WIDTH-1) downto 0) := std_logic_vector(to_unsigned(RAM_INIT_VALUE, DATA_WIDTH));

-- Build a 2-D array type for the RAM
subtype word_t is std_logic_vector((DATA_WIDTH-1) downto 0);
type memory_t is array(2**ADDR_WIDTH-1 downto 0) of word_t;

-- Declare the RAM signal.	
signal ram : memory_t := (others => mem_init_value);

signal q   : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
signal q_b : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');

attribute RAM_STYLE             : string;
-- attribute RAM_STYLE of RAM      : signal is "DISTRIBUTED";
attribute RAM_STYLE of RAM      : signal is "BLOCK";

begin

    -- Port A
    P_PortA_Write : process(CLKA) begin
        if (rising_edge(CLKA)) then 
            if (ENA = '1') then
                if (WEA = '1') then
                    ram(conv_integer(ADDRA)) <= DATAA;
                end if;
            end if;
        end if;
    end process;
    
    -- Port B

    P_PortB_Read : process(CLKB) begin
        if (rising_edge(CLKB)) then 
            if (ENB = '1') then
                q <= ram(conv_integer(ADDRB));
            end if;
        end if;
    end process;

    P_PortB_Clocking : process(CLKB) begin
        if (rising_edge(CLKB)) then
            q_b <= q;
        end if;
    end process;

    DATAB <= q_b;

end arc_SIMPLE_BLK_DPRAM_DUALCLK;

