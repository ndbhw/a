library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

-- **********************************
-- DUMP Point      |  Setting Value
-- ----------------+-----------------
-- CFR   Output #0 |     0x80
-- CFR   Output #1 |     0x81
-- CFR   Output #2 |     0x82
-- CFR   Output #3 |     0x83
-- CFR   Output #4 |     0x84
-- CFR   Output #5 |     0x85
-- CFR   Output #6 |     0x86
-- CFR   Output #7 |     0x87
-- ----------------+-----------------
-- DPD   Output #0 |     0x90
-- DPD   Output #1 |     0x91
-- DPD   Output #2 |     0x92
-- DPD   Output #3 |     0x93
-- DPD   Output #4 |     0x94
-- DPD   Output #5 |     0x95
-- DPD   Output #6 |     0x96
-- DPD   Output #7 |     0x97
-- ----------------+-----------------
-- FBATT  Input #0 |     0xA0
-- FBATT  Input #1 |     0xA1
-- FBATT  Input #2 |     0xA2
-- FBATT  Input #3 |     0xA3
-- **********************************

entity DPD_DUMP_MUX is
generic(
    DPD_PATH_PHASE              : string  := "MONO"; -- "MONO" or "POLY"
    DPD_CLK_SEL                 : natural :=     8 ; -- 
    TX_ANT_NUM                  : natural :=     4 ; -- The Number of TX Antenna Paths 
    FB_PATH_NUM                 : natural :=     4   -- The Number of FB Paths 
    );
port(
    RST                         : in  std_logic; -- Reset, Active High
    CLK_SYS                     : in  std_logic; -- System Clock :  30.72 MHz
    CLK_SYSX2                   : in  std_logic; --  2x(CLK_SYS) :  61.44 MHz
    CLK_SYSX3                   : in  std_logic; --  3x(CLK_SYS) :  92.16 MHz
    CLK_SYSX4                   : in  std_logic; --  4x(CLK_SYS) : 122.88 MHz
    CLK_SYSX5                   : in  std_logic; --  5x(CLK_SYS) : 153.60 MHz
    CLK_SYSX6                   : in  std_logic; --  6x(CLK_SYS) : 184.32 MHz
    CLK_SYSX8                   : in  std_logic; --  8x(CLK_SYS) : 245.76 MHz
    CLK_SYSX10                  : in  std_logic; -- 10x(CLK_SYS) : 307.20 MHz
    CLK_SYSX12                  : in  std_logic; -- 12x(CLK_SYS) : 368.64 MHz
    CLK_SYSX16                  : in  std_logic; -- 16x(CLK_SYS) : 491.52 MHz
    CLK_SYSX20                  : in  std_logic; -- 20x(CLK_SYS) : 614.40 MHz

    DUMP_POINT_SEL_STRB_IN      : in  std_logic;
    DUMP_POINT_SEL_IN           : in  std_logic_vector( 7 downto 0); -- Dump Point Selection

    CFR_OUTPUT_BFN_STRB_IN      : in  std_logic;
    CFR_OUTPUT_VLD_IN           : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    CFR_OUTPUT_IQ_IN            : in  std_logic_array32(TX_ANT_NUM-1 downto 0);

    DPD_OUTPUT_BFN_STRB_IN      : in  std_logic;
    DPD_OUTPUT_VLD_IN           : in  std_logic_vector( TX_ANT_NUM-1 downto 0);
    DPD_OUTPUT_MONO_IQ_IN       : in  std_logic_array32(TX_ANT_NUM-1 downto 0);
    DPD_OUTPUT_POLY_IQ_EVEN_IN  : in  std_logic_array32(TX_ANT_NUM-1 downto 0);
    DPD_OUTPUT_POLY_IQ_ODD_IN   : in  std_logic_array32(TX_ANT_NUM-1 downto 0);

    FBATT_INPUT_BFN_STRB_IN     : in  std_logic;
    FBATT_INPUT_VLD_IN          : in  std_logic_vector( FB_PATH_NUM-1 downto 0);
    FBATT_INPUT_MONO_IQ_IN      : in  std_logic_array32(FB_PATH_NUM-1 downto 0);
    FBATT_INPUT_POLY_IQ_EVEN_IN : in  std_logic_array32(FB_PATH_NUM-1 downto 0);
    FBATT_INPUT_POLY_IQ_ODD_IN  : in  std_logic_array32(FB_PATH_NUM-1 downto 0);

    DUMP_BFN_STRB_OUT           : out std_logic_vector( 1 downto 0); -- Delayed 10ms Frame Sync Strobe for DUMP                 
    DUMP_DVLD_OUT               : out std_logic_vector( 1 downto 0); -- Dump Sample Valid
    DUMP_DATA_OUT               : out std_logic_array32(1 downto 0)  -- Dump Sample
    );
end DPD_DUMP_MUX;

architecture arc_DPD_DUMP_MUX of DPD_DUMP_MUX is

component RST_SYNC is
generic(
    DLY_NUM                           : natural := 3;    -- Number of delay.
    MAX_FANOUT_NUM                    : integer := 200   -- Number of maximum fanout
    );
port(
    RST_IN                            : in  std_logic;   -- Active high asynchronous reset
    CLK                               : in  std_logic;   -- clock to be sync'ed to
    RST_OUT                           : out std_logic    -- "Synchronised" reset signal
    );         
end component;

signal CLK_VECTOR                     : std_logic_vector(19 downto 0);
signal CLK                            : std_logic; 

signal rst_synch                      : std_logic;

signal dump_point_sel_strb_sh         : std_logic_vector( 2 downto 0);
signal dump_point_sel_strb_rpls       : std_logic;
signal dump_point_sel_h               : std_logic_vector( 3 downto 0);
signal dump_point_sel_h_d1            : std_logic_vector( 3 downto 0);
signal dump_point_sel_l               : std_logic_vector( 3 downto 0);

signal mux_cfrout_vld                 : std_logic;
signal mux_cfrout_iq                  : std_logic_vector(31 downto 0);

signal mux_dpdout_vld                 : std_logic;
signal mux_dpdout_mono_iq             : std_logic_vector(31 downto 0);
signal mux_dpdout_poly_iq_even        : std_logic_vector(31 downto 0);
signal mux_dpdout_poly_iq_odd         : std_logic_vector(31 downto 0);

signal mux_fbattin_vld                : std_logic;
signal mux_fbattin_mono_iq            : std_logic_vector(31 downto 0);
signal mux_fbattin_poly_iq_even       : std_logic_vector(31 downto 0);
signal mux_fbattin_poly_iq_odd        : std_logic_vector(31 downto 0);

signal cfrout_bfn_d1                  : std_logic;
signal dpdout_bfn_d1                  : std_logic;
signal fbattin_bfn_d1                 : std_logic;

signal mux_dump_bfn                   : std_logic;
signal mux_dump_vld                   : std_logic;
signal mux_dump_mono_iq               : std_logic_vector(31 downto 0);
signal mux_dump_poly_iq_even          : std_logic_vector(31 downto 0);
signal mux_dump_poly_iq_odd           : std_logic_vector(31 downto 0);

attribute KEEP : string;
attribute KEEP of dump_point_sel_h    : signal is "TRUE"; 
attribute KEEP of dump_point_sel_h_d1 : signal is "TRUE";
attribute KEEP of dump_point_sel_l    : signal is "TRUE"; 

begin

    CLK_VECTOR <= CLK_SYSX20&'0'&'0'&'0'&CLK_SYSX16&'0'&'0'&'0'&CLK_SYSX12&'0'&CLK_SYSX10&'0'&CLK_SYSX8&'0'&CLK_SYSX6&CLK_SYSX5&CLK_SYSX4&CLK_SYSX3&CLK_SYSX2&CLK_SYS;  
    CLK        <= CLK_VECTOR(DPD_CLK_SEL-1);                

    U_RST_SYNC : RST_SYNC generic map(4, 200) port map(RST, CLK, rst_synch);

    P_Dump_Point_Sel_CDC : process(rst_synch, CLK) begin 
        if (rst_synch = '1') then
            dump_point_sel_strb_sh   <= (others => '0'); 
            dump_point_sel_strb_rpls <= '0';
            dump_point_sel_h         <= (others => '0'); 
            dump_point_sel_l         <= (others => '0'); 
        elsif (CLK'event) and (CLK = '1') then
            dump_point_sel_strb_sh   <= dump_point_sel_strb_sh(1 downto 0) & DUMP_POINT_SEL_STRB_IN; 
            dump_point_sel_strb_rpls <= dump_point_sel_strb_sh(1) and (not dump_point_sel_strb_sh(2));

            if (dump_point_sel_strb_rpls = '1') then
                dump_point_sel_h <= DUMP_POINT_SEL_IN(7 downto 4); 
                dump_point_sel_l <= DUMP_POINT_SEL_IN(3 downto 0); 
            else
                dump_point_sel_h <= dump_point_sel_h; 
                dump_point_sel_l <= dump_point_sel_l; 
            end if;
        end if;
    end process;
 
    G_DL_DUMP_CFR_2 : if (TX_ANT_NUM = 2) generate begin
        P_DL_DUMP_CFR_2 : process(rst_synch, CLK) begin
            if (rst_synch = '1') then
                mux_cfrout_vld <= '0';             
                mux_cfrout_iq  <= (others => '0'); 
            elsif (CLK'event) and (CLK = '1') then
                case (dump_point_sel_l) is
                    when x"0"   => mux_cfrout_vld <= CFR_OUTPUT_VLD_IN(0); mux_cfrout_iq <= CFR_OUTPUT_IQ_IN(0);  
                    when x"1"   => mux_cfrout_vld <= CFR_OUTPUT_VLD_IN(1); mux_cfrout_iq <= CFR_OUTPUT_IQ_IN(1);  
                    when others => mux_cfrout_vld <= '0';                  mux_cfrout_iq <= (others => '0');
                end case; 
            end if;
        end process;
    end generate;

    G_DL_DUMP_CFR_4 : if (TX_ANT_NUM = 4) generate begin
        P_DL_DUMP_CFR_4 : process(rst_synch, CLK) begin
            if (rst_synch = '1') then
                mux_cfrout_vld <= '0';             
                mux_cfrout_iq  <= (others => '0'); 
            elsif (CLK'event) and (CLK = '1') then
                case (dump_point_sel_l) is
                    when x"0"   => mux_cfrout_vld <= CFR_OUTPUT_VLD_IN(0); mux_cfrout_iq <= CFR_OUTPUT_IQ_IN(0);  
                    when x"1"   => mux_cfrout_vld <= CFR_OUTPUT_VLD_IN(1); mux_cfrout_iq <= CFR_OUTPUT_IQ_IN(1);  
                    when x"2"   => mux_cfrout_vld <= CFR_OUTPUT_VLD_IN(2); mux_cfrout_iq <= CFR_OUTPUT_IQ_IN(2);  
                    when x"3"   => mux_cfrout_vld <= CFR_OUTPUT_VLD_IN(3); mux_cfrout_iq <= CFR_OUTPUT_IQ_IN(3);  
                    when others => mux_cfrout_vld <= '0';                  mux_cfrout_iq <= (others => '0');
                end case; 
            end if;
        end process;
    end generate;

    G_DL_DUMP_CFR_8 : if (TX_ANT_NUM = 8) generate begin
        P_DL_DUMP_CFR_8 : process(rst_synch, CLK) begin
            if (rst_synch = '1') then
                mux_cfrout_vld <= '0';             
                mux_cfrout_iq  <= (others => '0'); 
            elsif (CLK'event) and (CLK = '1') then
                case (dump_point_sel_l) is
                    when x"0"   => mux_cfrout_vld <= CFR_OUTPUT_VLD_IN(0); mux_cfrout_iq <= CFR_OUTPUT_IQ_IN(0);  
                    when x"1"   => mux_cfrout_vld <= CFR_OUTPUT_VLD_IN(1); mux_cfrout_iq <= CFR_OUTPUT_IQ_IN(1);  
                    when x"2"   => mux_cfrout_vld <= CFR_OUTPUT_VLD_IN(2); mux_cfrout_iq <= CFR_OUTPUT_IQ_IN(2);  
                    when x"3"   => mux_cfrout_vld <= CFR_OUTPUT_VLD_IN(3); mux_cfrout_iq <= CFR_OUTPUT_IQ_IN(3);  
                    when x"4"   => mux_cfrout_vld <= CFR_OUTPUT_VLD_IN(4); mux_cfrout_iq <= CFR_OUTPUT_IQ_IN(4);  
                    when x"5"   => mux_cfrout_vld <= CFR_OUTPUT_VLD_IN(5); mux_cfrout_iq <= CFR_OUTPUT_IQ_IN(5);  
                    when x"6"   => mux_cfrout_vld <= CFR_OUTPUT_VLD_IN(6); mux_cfrout_iq <= CFR_OUTPUT_IQ_IN(6);  
                    when x"7"   => mux_cfrout_vld <= CFR_OUTPUT_VLD_IN(7); mux_cfrout_iq <= CFR_OUTPUT_IQ_IN(7);  
                    when others => mux_cfrout_vld <= '0';                  mux_cfrout_iq <= (others => '0');
                end case; 
            end if;
        end process;
    end generate;

    G_DPD_Mono_Phase_Mux : if (DPD_PATH_PHASE = "MONO") generate begin              

        mux_dpdout_poly_iq_even  <= (others => '0');
        mux_dpdout_poly_iq_odd   <= (others => '0');

        mux_fbattin_poly_iq_even <= (others => '0');
        mux_fbattin_poly_iq_odd  <= (others => '0');

        G_DL_2Path_Dump_MONO : if (TX_ANT_NUM = 2) generate begin                   
            P_DL_DUMP_DPD_2_MONO : process(rst_synch, CLK) begin
                if (rst_synch = '1') then
                    mux_dpdout_vld     <= '0';             
                    mux_dpdout_mono_iq <= (others => '0'); 
                elsif (CLK'event) and (CLK = '1') then
                    case (dump_point_sel_l) is
                        when x"0"   => mux_dpdout_vld <= DPD_OUTPUT_VLD_IN(0); mux_dpdout_mono_iq <= DPD_OUTPUT_MONO_IQ_IN(0);  
                        when x"1"   => mux_dpdout_vld <= DPD_OUTPUT_VLD_IN(1); mux_dpdout_mono_iq <= DPD_OUTPUT_MONO_IQ_IN(1);  
                        when others => mux_dpdout_vld <= '0';                  mux_dpdout_mono_iq <= (others => '0');
                    end case; 
                end if;
            end process;

        end generate;

        
        G_DL_4Path_Dump_MONO : if (TX_ANT_NUM = 4) generate begin                   
            P_DL_DUMP_DPD_4_MONO : process(rst_synch, CLK) begin
                if (rst_synch = '1') then
                    mux_dpdout_vld     <= '0';             
                    mux_dpdout_mono_iq <= (others => '0'); 
                elsif (CLK'event) and (CLK = '1') then
                    case (dump_point_sel_l) is
                        when x"0"   => mux_dpdout_vld <= DPD_OUTPUT_VLD_IN(0); mux_dpdout_mono_iq <= DPD_OUTPUT_MONO_IQ_IN(0);  
                        when x"1"   => mux_dpdout_vld <= DPD_OUTPUT_VLD_IN(1); mux_dpdout_mono_iq <= DPD_OUTPUT_MONO_IQ_IN(1);  
                        when x"2"   => mux_dpdout_vld <= DPD_OUTPUT_VLD_IN(2); mux_dpdout_mono_iq <= DPD_OUTPUT_MONO_IQ_IN(2);  
                        when x"3"   => mux_dpdout_vld <= DPD_OUTPUT_VLD_IN(3); mux_dpdout_mono_iq <= DPD_OUTPUT_MONO_IQ_IN(3);  
                        when others => mux_dpdout_vld <= '0';                  mux_dpdout_mono_iq <= (others => '0');
                    end case; 
                end if;
            end process;

        end generate;


        G_DL_8Path_Dump_MONO : if (TX_ANT_NUM = 8) generate begin                   
            P_DL_DUMP_DPD_8_MONO : process(rst_synch, CLK) begin
                if (rst_synch = '1') then
                    mux_dpdout_vld     <= '0';             
                    mux_dpdout_mono_iq <= (others => '0'); 
                elsif (CLK'event) and (CLK = '1') then
                    case (dump_point_sel_l) is
                        when x"0"   => mux_dpdout_vld <= DPD_OUTPUT_VLD_IN(0); mux_dpdout_mono_iq <= DPD_OUTPUT_MONO_IQ_IN(0);  
                        when x"1"   => mux_dpdout_vld <= DPD_OUTPUT_VLD_IN(1); mux_dpdout_mono_iq <= DPD_OUTPUT_MONO_IQ_IN(1);  
                        when x"2"   => mux_dpdout_vld <= DPD_OUTPUT_VLD_IN(2); mux_dpdout_mono_iq <= DPD_OUTPUT_MONO_IQ_IN(2);  
                        when x"3"   => mux_dpdout_vld <= DPD_OUTPUT_VLD_IN(3); mux_dpdout_mono_iq <= DPD_OUTPUT_MONO_IQ_IN(3);  
                        when x"4"   => mux_dpdout_vld <= DPD_OUTPUT_VLD_IN(4); mux_dpdout_mono_iq <= DPD_OUTPUT_MONO_IQ_IN(4);  
                        when x"5"   => mux_dpdout_vld <= DPD_OUTPUT_VLD_IN(5); mux_dpdout_mono_iq <= DPD_OUTPUT_MONO_IQ_IN(5);  
                        when x"6"   => mux_dpdout_vld <= DPD_OUTPUT_VLD_IN(6); mux_dpdout_mono_iq <= DPD_OUTPUT_MONO_IQ_IN(6);  
                        when x"7"   => mux_dpdout_vld <= DPD_OUTPUT_VLD_IN(7); mux_dpdout_mono_iq <= DPD_OUTPUT_MONO_IQ_IN(7);  
                        when others => mux_dpdout_vld <= '0';                  mux_dpdout_mono_iq <= (others => '0');
                    end case; 
                end if;
            end process;

        end generate;

        G_FB_1Path_Dump_MONO : if (FB_PATH_NUM = 1) generate begin                   
            P_FB_DUMP_FBATT_1_MONO : process(rst_synch, CLK) begin
                if (rst_synch = '1') then
                    mux_fbattin_vld     <= '0';             
                    mux_fbattin_mono_iq <= (others => '0'); 
                elsif (CLK'event) and (CLK = '1') then
                    case (dump_point_sel_l) is
                        when x"0"   => mux_fbattin_vld <= FBATT_INPUT_VLD_IN(0); mux_fbattin_mono_iq <= FBATT_INPUT_MONO_IQ_IN(0);  
                        when others => mux_fbattin_vld <= '0';                   mux_fbattin_mono_iq <= (others => '0');
                    end case; 
                end if;
            end process;
        end generate;

        G_FB_2Path_Dump_MONO : if (FB_PATH_NUM = 2) generate begin                   
            P_FB_DUMP_FBATT_1_MONO : process(rst_synch, CLK) begin
                if (rst_synch = '1') then
                    mux_fbattin_vld     <= '0';             
                    mux_fbattin_mono_iq <= (others => '0'); 
                elsif (CLK'event) and (CLK = '1') then
                    case (dump_point_sel_l) is
                        when x"0"   => mux_fbattin_vld <= FBATT_INPUT_VLD_IN(0); mux_fbattin_mono_iq <= FBATT_INPUT_MONO_IQ_IN(0);  
                        when x"1"   => mux_fbattin_vld <= FBATT_INPUT_VLD_IN(1); mux_fbattin_mono_iq <= FBATT_INPUT_MONO_IQ_IN(1);  
                        when others => mux_fbattin_vld <= '0';                   mux_fbattin_mono_iq <= (others => '0');
                    end case; 
                end if;
            end process;
        end generate;

        G_FB_4Path_Dump_MONO : if (FB_PATH_NUM = 4) generate begin                   
            P_FB_DUMP_FBATT_1_MONO : process(rst_synch, CLK) begin
                if (rst_synch = '1') then
                    mux_fbattin_vld     <= '0';             
                    mux_fbattin_mono_iq <= (others => '0'); 
                elsif (CLK'event) and (CLK = '1') then
                    case (dump_point_sel_l) is
                        when x"0"   => mux_fbattin_vld <= FBATT_INPUT_VLD_IN(0); mux_fbattin_mono_iq <= FBATT_INPUT_MONO_IQ_IN(0);  
                        when x"1"   => mux_fbattin_vld <= FBATT_INPUT_VLD_IN(1); mux_fbattin_mono_iq <= FBATT_INPUT_MONO_IQ_IN(1);  
                        when x"2"   => mux_fbattin_vld <= FBATT_INPUT_VLD_IN(2); mux_fbattin_mono_iq <= FBATT_INPUT_MONO_IQ_IN(2);  
                        when x"3"   => mux_fbattin_vld <= FBATT_INPUT_VLD_IN(3); mux_fbattin_mono_iq <= FBATT_INPUT_MONO_IQ_IN(3);  
                        when others => mux_fbattin_vld <= '0';                   mux_fbattin_mono_iq <= (others => '0');
                    end case; 
                end if;
            end process;
        end generate;
    end generate;

    G_DPD_Poly_Phase_Mux : if (DPD_PATH_PHASE = "POLY") generate begin              

        mux_dpdout_mono_iq  <= (others => '0');
        mux_fbattin_mono_iq <= (others => '0');

        G_DL_2Path_Dump_POLY : if (TX_ANT_NUM = 2) generate begin                   

            P_DL_DUMP_DPD_2_POLY : process(rst_synch, CLK) begin
                if (rst_synch = '1') then
                    mux_dpdout_vld          <= '0';             
                    mux_dpdout_poly_iq_even <= (others => '0'); 
                    mux_dpdout_poly_iq_odd  <= (others => '0'); 
                elsif (CLK'event) and (CLK = '1') then
                    case (dump_point_sel_l) is
                        when x"0"   => 
                             mux_dpdout_vld          <= DPD_OUTPUT_VLD_IN(0); 
                             mux_dpdout_poly_iq_even <= DPD_OUTPUT_POLY_IQ_EVEN_IN(0);  
                             mux_dpdout_poly_iq_odd  <= DPD_OUTPUT_POLY_IQ_ODD_IN(0);  
                        when x"1"   =>   
                             mux_dpdout_vld          <= DPD_OUTPUT_VLD_IN(1); 
                             mux_dpdout_poly_iq_even <= DPD_OUTPUT_POLY_IQ_EVEN_IN(1);  
                             mux_dpdout_poly_iq_odd  <= DPD_OUTPUT_POLY_IQ_ODD_IN(1);  
                        when others => 
                             mux_dpdout_vld          <= '0'; 
                             mux_dpdout_poly_iq_even <= (others => '0');  
                             mux_dpdout_poly_iq_odd  <= (others => '0');  
                    end case; 
                end if;
            end process;

        end generate;

        
        G_DL_4Path_Dump_POLY : if (TX_ANT_NUM = 4) generate begin                   

            P_DL_DUMP_DPD_4_POLY : process(rst_synch, CLK) begin
                if (rst_synch = '1') then
                    mux_dpdout_vld          <= '0';             
                    mux_dpdout_poly_iq_even <= (others => '0'); 
                    mux_dpdout_poly_iq_odd  <= (others => '0'); 
                elsif (CLK'event) and (CLK = '1') then
                    case (dump_point_sel_l) is
                        when x"0"   => 
                             mux_dpdout_vld          <= DPD_OUTPUT_VLD_IN(0); 
                             mux_dpdout_poly_iq_even <= DPD_OUTPUT_POLY_IQ_EVEN_IN(0);  
                             mux_dpdout_poly_iq_odd  <= DPD_OUTPUT_POLY_IQ_ODD_IN(0);  
                        when x"1"   =>   
                             mux_dpdout_vld          <= DPD_OUTPUT_VLD_IN(1); 
                             mux_dpdout_poly_iq_even <= DPD_OUTPUT_POLY_IQ_EVEN_IN(1);  
                             mux_dpdout_poly_iq_odd  <= DPD_OUTPUT_POLY_IQ_ODD_IN(1);  
                        when x"2"   => 
                             mux_dpdout_vld          <= DPD_OUTPUT_VLD_IN(2); 
                             mux_dpdout_poly_iq_even <= DPD_OUTPUT_POLY_IQ_EVEN_IN(2);  
                             mux_dpdout_poly_iq_odd  <= DPD_OUTPUT_POLY_IQ_ODD_IN(2);  
                        when x"3"   =>   
                             mux_dpdout_vld          <= DPD_OUTPUT_VLD_IN(3); 
                             mux_dpdout_poly_iq_even <= DPD_OUTPUT_POLY_IQ_EVEN_IN(3);  
                             mux_dpdout_poly_iq_odd  <= DPD_OUTPUT_POLY_IQ_ODD_IN(3);  
                        when others => 
                             mux_dpdout_vld          <= '0'; 
                             mux_dpdout_poly_iq_even <= (others => '0');  
                             mux_dpdout_poly_iq_odd  <= (others => '0');  
                    end case; 
                end if;
            end process;

        end generate;

        G_DL_8Path_Dump_POLY : if (TX_ANT_NUM = 8) generate begin                   

            P_DL_DUMP_DPD_8_POLY : process(rst_synch, CLK) begin
                if (rst_synch = '1') then
                    mux_dpdout_vld          <= '0';             
                    mux_dpdout_poly_iq_even <= (others => '0'); 
                    mux_dpdout_poly_iq_odd  <= (others => '0'); 
                elsif (CLK'event) and (CLK = '1') then
                    case (dump_point_sel_l) is
                        when x"0"   => 
                             mux_dpdout_vld          <= DPD_OUTPUT_VLD_IN(0); 
                             mux_dpdout_poly_iq_even <= DPD_OUTPUT_POLY_IQ_EVEN_IN(0);  
                             mux_dpdout_poly_iq_odd  <= DPD_OUTPUT_POLY_IQ_ODD_IN(0);  
                        when x"1"   =>   
                             mux_dpdout_vld          <= DPD_OUTPUT_VLD_IN(1); 
                             mux_dpdout_poly_iq_even <= DPD_OUTPUT_POLY_IQ_EVEN_IN(1);  
                             mux_dpdout_poly_iq_odd  <= DPD_OUTPUT_POLY_IQ_ODD_IN(1);  
                        when x"2"   => 
                             mux_dpdout_vld          <= DPD_OUTPUT_VLD_IN(2); 
                             mux_dpdout_poly_iq_even <= DPD_OUTPUT_POLY_IQ_EVEN_IN(2);  
                             mux_dpdout_poly_iq_odd  <= DPD_OUTPUT_POLY_IQ_ODD_IN(2);  
                        when x"3"   =>   
                             mux_dpdout_vld          <= DPD_OUTPUT_VLD_IN(3); 
                             mux_dpdout_poly_iq_even <= DPD_OUTPUT_POLY_IQ_EVEN_IN(3);  
                             mux_dpdout_poly_iq_odd  <= DPD_OUTPUT_POLY_IQ_ODD_IN(3);  
                        when x"4"   => 
                             mux_dpdout_vld          <= DPD_OUTPUT_VLD_IN(4); 
                             mux_dpdout_poly_iq_even <= DPD_OUTPUT_POLY_IQ_EVEN_IN(4);  
                             mux_dpdout_poly_iq_odd  <= DPD_OUTPUT_POLY_IQ_ODD_IN(4);  
                        when x"5"   =>   
                             mux_dpdout_vld          <= DPD_OUTPUT_VLD_IN(5); 
                             mux_dpdout_poly_iq_even <= DPD_OUTPUT_POLY_IQ_EVEN_IN(5);  
                             mux_dpdout_poly_iq_odd  <= DPD_OUTPUT_POLY_IQ_ODD_IN(5);  
                        when x"6"   => 
                             mux_dpdout_vld          <= DPD_OUTPUT_VLD_IN(6); 
                             mux_dpdout_poly_iq_even <= DPD_OUTPUT_POLY_IQ_EVEN_IN(6);  
                             mux_dpdout_poly_iq_odd  <= DPD_OUTPUT_POLY_IQ_ODD_IN(6);  
                        when x"7"   =>   
                             mux_dpdout_vld          <= DPD_OUTPUT_VLD_IN(8); 
                             mux_dpdout_poly_iq_even <= DPD_OUTPUT_POLY_IQ_EVEN_IN(7);  
                             mux_dpdout_poly_iq_odd  <= DPD_OUTPUT_POLY_IQ_ODD_IN(7);  
                        when others => 
                             mux_dpdout_vld          <= '0'; 
                             mux_dpdout_poly_iq_even <= (others => '0');  
                             mux_dpdout_poly_iq_odd  <= (others => '0');  
                    end case; 
                end if;
            end process;

        end generate;

        G_FB_1Path_Dump_POLY : if (FB_PATH_NUM = 1) generate begin                   
            P_FB_DUMP_FBATT_1_POLY : process(rst_synch, CLK) begin
                if (rst_synch = '1') then
                    mux_fbattin_vld          <= '0';             
                    mux_fbattin_poly_iq_even <= (others => '0'); 
                    mux_fbattin_poly_iq_odd  <= (others => '0'); 
                elsif (CLK'event) and (CLK = '1') then
                    case (dump_point_sel_l) is
                        when x"0"   => 
                            mux_fbattin_vld          <= FBATT_INPUT_VLD_IN(0); 
                            mux_fbattin_poly_iq_even <= FBATT_INPUT_POLY_IQ_EVEN_IN(0); 
                            mux_fbattin_poly_iq_odd  <= FBATT_INPUT_POLY_IQ_ODD_IN(0); 
                        when others => 
                            mux_fbattin_vld          <= '0'; 
                            mux_fbattin_poly_iq_even <= (others => '0'); 
                            mux_fbattin_poly_iq_odd  <= (others => '0'); 
                    end case; 
                end if;
            end process;
        end generate;

        G_FB_2Path_Dump_POLY : if (FB_PATH_NUM = 2) generate begin                   
            P_FB_DUMP_FBATT_1_POLY : process(rst_synch, CLK) begin
                if (rst_synch = '1') then
                    mux_fbattin_vld          <= '0';             
                    mux_fbattin_poly_iq_even <= (others => '0'); 
                    mux_fbattin_poly_iq_odd  <= (others => '0'); 
                elsif (CLK'event) and (CLK = '1') then
                    case (dump_point_sel_l) is
                        when x"0"   => 
                            mux_fbattin_vld          <= FBATT_INPUT_VLD_IN(0); 
                            mux_fbattin_poly_iq_even <= FBATT_INPUT_POLY_IQ_EVEN_IN(0); 
                            mux_fbattin_poly_iq_odd  <= FBATT_INPUT_POLY_IQ_ODD_IN(0); 
                        when x"1"   => 
                            mux_fbattin_vld          <= FBATT_INPUT_VLD_IN(1); 
                            mux_fbattin_poly_iq_even <= FBATT_INPUT_POLY_IQ_EVEN_IN(1); 
                            mux_fbattin_poly_iq_odd  <= FBATT_INPUT_POLY_IQ_ODD_IN(1); 
                        when others => 
                            mux_fbattin_vld          <= '0'; 
                            mux_fbattin_poly_iq_even <= (others => '0'); 
                            mux_fbattin_poly_iq_odd  <= (others => '0'); 
                    end case; 
                end if;
            end process;
        end generate;

        G_FB_4Path_Dump_POLY : if (FB_PATH_NUM = 4) generate begin                   
            P_FB_DUMP_FBATT_1_POLY : process(rst_synch, CLK) begin
                if (rst_synch = '1') then
                    mux_fbattin_vld          <= '0';             
                    mux_fbattin_poly_iq_even <= (others => '0'); 
                    mux_fbattin_poly_iq_odd  <= (others => '0'); 
                elsif (CLK'event) and (CLK = '1') then
                    case (dump_point_sel_l) is
                        when x"0"   => 
                            mux_fbattin_vld          <= FBATT_INPUT_VLD_IN(0); 
                            mux_fbattin_poly_iq_even <= FBATT_INPUT_POLY_IQ_EVEN_IN(0); 
                            mux_fbattin_poly_iq_odd  <= FBATT_INPUT_POLY_IQ_ODD_IN(0); 
                        when x"1"   => 
                            mux_fbattin_vld          <= FBATT_INPUT_VLD_IN(1); 
                            mux_fbattin_poly_iq_even <= FBATT_INPUT_POLY_IQ_EVEN_IN(1); 
                            mux_fbattin_poly_iq_odd  <= FBATT_INPUT_POLY_IQ_ODD_IN(1); 
                        when x"2"   => 
                            mux_fbattin_vld          <= FBATT_INPUT_VLD_IN(2); 
                            mux_fbattin_poly_iq_even <= FBATT_INPUT_POLY_IQ_EVEN_IN(2); 
                            mux_fbattin_poly_iq_odd  <= FBATT_INPUT_POLY_IQ_ODD_IN(2); 
                        when x"3"   => 
                            mux_fbattin_vld          <= FBATT_INPUT_VLD_IN(3); 
                            mux_fbattin_poly_iq_even <= FBATT_INPUT_POLY_IQ_EVEN_IN(3); 
                            mux_fbattin_poly_iq_odd  <= FBATT_INPUT_POLY_IQ_ODD_IN(3); 
                        when others => 
                            mux_fbattin_vld          <= '0'; 
                            mux_fbattin_poly_iq_even <= (others => '0'); 
                            mux_fbattin_poly_iq_odd  <= (others => '0'); 
                    end case; 
                end if;
            end process;
        end generate;
    end generate;

    P_1CLK_Latency_Compensation : process(rst_synch, CLK) begin
        if (rst_synch = '1') then
            dump_point_sel_h_d1 <= (others => '0');
            cfrout_bfn_d1       <= '0';           
            dpdout_bfn_d1       <= '0';           
            fbattin_bfn_d1      <= '0';           
        elsif (CLK'event) and (CLK = '1') then
            dump_point_sel_h_d1 <= dump_point_sel_h;
            cfrout_bfn_d1       <= CFR_OUTPUT_BFN_STRB_IN  ;           
            dpdout_bfn_d1       <= DPD_OUTPUT_BFN_STRB_IN  ;           
            fbattin_bfn_d1      <= FBATT_INPUT_BFN_STRB_IN ;           
        end if;
    end process;

    G_DPD_MONO_Phase_BLK_MUX : if (DPD_PATH_PHASE = "MONO") generate begin              

        mux_dump_poly_iq_even <= (others => '0');
        mux_dump_poly_iq_odd  <= (others => '0');

        P_BLK_Dump_Point_MUX_MONO : process(rst_synch, CLK) begin
            if (rst_synch = '1') then
                mux_dump_bfn        <= '0';        
                mux_dump_vld        <= '0';        
                mux_dump_mono_iq    <= (others => '0');        
            elsif (CLK'event) and (CLK = '1') then
                case (dump_point_sel_h_d1) is
                    when x"8"   =>
                        mux_dump_bfn     <= cfrout_bfn_d1 ;        
                        mux_dump_vld     <= mux_cfrout_vld;        
                        mux_dump_mono_iq <= mux_cfrout_iq;        
                    when x"9"   => 
                        mux_dump_bfn     <= dpdout_bfn_d1 ;        
                        mux_dump_vld     <= mux_dpdout_vld;        
                        mux_dump_mono_iq <= mux_dpdout_mono_iq ;        
                    when x"A"   =>
                        mux_dump_bfn     <= fbattin_bfn_d1 ;        
                        mux_dump_vld     <= mux_fbattin_vld;        
                        mux_dump_mono_iq <= mux_fbattin_mono_iq ;        
                    when others =>
                        mux_dump_bfn     <= '0';        
                        mux_dump_vld     <= '0';        
                        mux_dump_mono_iq <= (others => '0');        
                end case;
            end if;
        end process;

        G_MONO_DUMP_Domain_0_MONO : if ((DPD_CLK_SEL = 4) or (DPD_CLK_SEL = 8)) generate begin
            DUMP_BFN_STRB_OUT(0) <= mux_dump_bfn;                
            DUMP_DVLD_OUT(0)     <= mux_dump_vld;      
            DUMP_DATA_OUT(0)     <= mux_dump_mono_iq;       
                                
            DUMP_BFN_STRB_OUT(1) <= '0';                         
            DUMP_DVLD_OUT(1)     <= '0';               
            DUMP_DATA_OUT(1)     <= (others => '0');   
        end generate;

        G_MONO_DUMP_Domain_1_MONO : if ((DPD_CLK_SEL = 5) or (DPD_CLK_SEL = 10) or (DPD_CLK_SEL = 12)) generate begin
            DUMP_BFN_STRB_OUT(0) <= '0';                         
            DUMP_DVLD_OUT(0)     <= '0';               
            DUMP_DATA_OUT(0)     <= (others => '0');   

            DUMP_BFN_STRB_OUT(1) <= mux_dump_bfn;                
            DUMP_DVLD_OUT(1)     <= mux_dump_vld;      
            DUMP_DATA_OUT(1)     <= mux_dump_mono_iq;       
        end generate;
    end generate;

    G_DPD_POLY_Phase_BLK_MUX : if (DPD_PATH_PHASE = "POLY") generate begin              

        mux_dump_mono_iq    <= (others => '0');        

        P_BLK_Dump_Point_MUX_POLY : process(rst_synch, CLK) begin
            if (rst_synch = '1') then
                mux_dump_bfn          <= '0';        
                mux_dump_vld          <= '0';        
                mux_dump_poly_iq_even <= (others => '0');
                mux_dump_poly_iq_odd  <= (others => '0');

            elsif (CLK'event) and (CLK = '1') then
                case (dump_point_sel_h_d1) is
                    when x"8"   =>
                        mux_dump_bfn          <= cfrout_bfn_d1 ;        
                        mux_dump_vld          <= mux_cfrout_vld;        
                        mux_dump_poly_iq_even <= mux_cfrout_iq;
                        mux_dump_poly_iq_odd  <= (others => '0');
                    when x"9"   => 
                        mux_dump_bfn          <= dpdout_bfn_d1 ;        
                        mux_dump_vld          <= mux_dpdout_vld;        
                        mux_dump_poly_iq_even <= mux_dpdout_poly_iq_even;
                        mux_dump_poly_iq_odd  <= mux_dpdout_poly_iq_odd;
                    when x"A"   =>
                        mux_dump_bfn          <= fbattin_bfn_d1 ;        
                        mux_dump_vld          <= mux_fbattin_vld;        
                        mux_dump_poly_iq_even <= mux_fbattin_poly_iq_even;
                        mux_dump_poly_iq_odd  <= mux_fbattin_poly_iq_odd;
                    when others =>
                        mux_dump_bfn          <= '0';        
                        mux_dump_vld          <= '0';        
                        mux_dump_poly_iq_even <= (others => '0');
                        mux_dump_poly_iq_odd  <= (others => '0');
                end case;
            end if;
        end process;

        DUMP_BFN_STRB_OUT(0) <= mux_dump_bfn;                
        DUMP_DVLD_OUT(0)     <= mux_dump_vld;      
        DUMP_DATA_OUT(0)     <= mux_dump_poly_iq_even;       
                            
        DUMP_BFN_STRB_OUT(1) <= mux_dump_bfn;                         
        DUMP_DVLD_OUT(1)     <= mux_dump_vld;               
        DUMP_DATA_OUT(1)     <= mux_dump_poly_iq_odd;   

    end generate;

end arc_DPD_DUMP_MUX;
