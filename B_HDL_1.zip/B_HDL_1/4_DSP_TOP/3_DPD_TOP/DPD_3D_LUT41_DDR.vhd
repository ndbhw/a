library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity DPD_3D_LUT41_DDR is
generic(
    DEVICE                      : string  := "ULTRASCALE";

    DDR_DLY                     : integer :=           2 ;

    SIGNAL_Q_POINT              : integer :=          15 ;
    LUT_DDR_Q_POINT             : integer :=          12 ;
    SUM_Q_POINT                 : integer :=          22
    );
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
   
    LUT_DATA_VLD                : in  std_logic;
    LUT_I_IN                    : in  std_logic_array16(2 downto 0); 
    LUT_Q_IN                    : in  std_logic_array16(2 downto 0); 

    DATA_I_IN                   : in  std_logic_vector(15 downto 0); 
    DATA_Q_IN                   : in  std_logic_vector(15 downto 0); 

    DDR_I_OUT                   : out std_logic_array28(1 downto 0); 
    DDR_Q_OUT                   : out std_logic_array28(1 downto 0) 
    );
end DPD_3D_LUT41_DDR;

architecture arc_DPD_3D_LUT41_DDR of DPD_3D_LUT41_DDR is


component COMPLEX_MULTIPLIER is
generic(
    DEVICE                      : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HOVS                        : natural :=        1 ;

    INPUT_WIDTH                 : natural :=       16 ; -- AIN bitwidth : 0 to 29
    RND_EN                      : boolean :=     TRUE ; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT                     : natural :=       15 ; -- Rounding bit  
    OUTPUT_WIDTH                : natural :=       16   -- Result bitwidth : 0 to 47
    );
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    DATA_VLD_IN                 : in  std_logic;
    ADATA_I_IN                  : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    ADATA_Q_IN                  : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
                                                         
    BDATA_I_IN                  : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    BDATA_Q_IN                  : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
   
    DATA_VLD_OUT                : out std_logic;
    DATA_I_OUT                  : out std_logic_vector(OUTPUT_WIDTH-1 downto 0);
    DATA_Q_OUT                  : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
end component;

component DSP48E2_MULTIPLIER is
-- Latency 4 clocks
generic(
    AIN_BITWIDTH : natural; -- AIN bitwidth : 0 to 29
    BIN_BITWIDTH : natural; -- BIN bitwidth : 0 to 17
    RND_EN       : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT      : natural; -- Rounding bit  
    OUTPUT_WIDTH : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
    AIN          : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
    BIN          : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
    P            : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
    );
end component;

component SAT_SIGN is
generic(
    HS_MODE                     : boolean := TRUE;
    INPUT_BIT                   : natural;
    OUTPUT_BIT                  : natural 
    );
port( 
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    DATA_IN                     : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT                    : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;


signal data_i_sh                : std_logic_array16(DDR_DLY-1 downto 0) := (others => (others => '0')); 
signal data_q_sh                : std_logic_array16(DDR_DLY-1 downto 0) := (others => (others => '0')); 

-- DDR#0
signal conj_data_i              : std_logic_vector(15 downto 0) := (others => '0'); 
signal conj_data_q              : std_logic_vector(15 downto 0) := (others => '0'); 

signal data_i                   : std_logic_vector(15 downto 0) := (others => '0'); 
signal data_q                   : std_logic_vector(15 downto 0) := (others => '0'); 

signal lut0_i                   : std_logic_vector(15 downto 0) := (others => '0'); 
signal lut0_q                   : std_logic_vector(15 downto 0) := (others => '0'); 

signal sig_cmult_i              : std_logic_vector(32 downto 0) := (others => '0'); 
signal sig_cmult_q              : std_logic_vector(32 downto 0) := (others => '0'); 

signal sat_cmult_i              : std_logic_vector(25 downto 0) := (others => '0'); 
signal sat_cmult_q              : std_logic_vector(25 downto 0) := (others => '0'); 

signal lut0_x_cmult_ac          : std_logic_vector(41 downto 0) := (others => '0');
signal lut0_x_cmult_bd          : std_logic_vector(41 downto 0) := (others => '0');
signal lut0_x_cmult_ad          : std_logic_vector(41 downto 0) := (others => '0');
signal lut0_x_cmult_bc          : std_logic_vector(41 downto 0) := (others => '0');

signal lut0_x_cmult_i           : std_logic_vector(42 downto 0) := (others => '0');
signal lut0_x_cmult_q           : std_logic_vector(42 downto 0) := (others => '0');

signal lut0_x_cmult_rs_i        : std_logic_vector(25 downto 0) := (others => '0');
signal lut0_x_cmult_rs_q        : std_logic_vector(25 downto 0) := (others => '0');

signal ddr0_i                   : std_logic_vector(27 downto 0) := (others => '0');
signal ddr0_q                   : std_logic_vector(27 downto 0) := (others => '0');

-- DDR#1
signal lut_add_i                : std_logic_vector(16 downto 0) := (others => '0');
signal lut_add_q                : std_logic_vector(16 downto 0) := (others => '0');

signal lut_sub_i                : std_logic_vector(16 downto 0) := (others => '0');
signal lut_sub_q                : std_logic_vector(16 downto 0) := (others => '0');

signal lut_op_x_cmult_ac        : std_logic_vector(42 downto 0) := (others => '0');
signal lut_op_x_cmult_bd        : std_logic_vector(42 downto 0) := (others => '0');
signal lut_op_x_cmult_ad        : std_logic_vector(42 downto 0) := (others => '0');
signal lut_op_x_cmult_bc        : std_logic_vector(42 downto 0) := (others => '0');

signal lut_op_x_cmult_i         : std_logic_vector(43 downto 0) := (others => '0');
signal lut_op_x_cmult_q         : std_logic_vector(43 downto 0) := (others => '0');

signal lut_op_x_cmult_rs_i      : std_logic_vector(27 downto 0) := (others => '0');
signal lut_op_x_cmult_rs_q      : std_logic_vector(27 downto 0) := (others => '0');

signal ddr1_i                   : std_logic_vector(27 downto 0) := (others => '0');
signal ddr1_q                   : std_logic_vector(27 downto 0) := (others => '0');

begin

    P_DATA_SH : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            data_i_sh <= data_i_sh(DDR_DLY-2 downto 0) & DATA_I_IN; 
            data_q_sh <= data_q_sh(DDR_DLY-2 downto 0) & DATA_Q_IN; 
        end if;
    end process;

    -------------------------------------------
    -- DDR#0 
    -------------------------------------------
    P_Conj : process(CLK) BEgin
        if (CLK'event) and (CLK = '1') then
            conj_data_i <= data_i_sh(DDR_DLY-1); 
            conj_data_q <= not (data_q_sh(DDR_DLY-1)) + '1'; 

            data_i      <= DATA_I_IN;  
            data_q      <= DATA_Q_IN;  

            lut0_i      <= LUT_I_IN(0); 
            lut0_q      <= LUT_Q_IN(0); 
        end if;
    end process;

    -- mult_I/Q = sig_I[MAG_ADV+DDR_DLY] -j*sig_Q[MAG_ADV+DDR_DLY]) * (sig_I[MAG_ADV]+j*sig_Q[MAG_ADV])/2^4
    U_CMULT : COMPLEX_MULTIPLIER generic map(DEVICE, 1, 16, FALSE, 0, 33) port map(RST, CLK, '1', conj_data_i, conj_data_q, data_i, data_q, open, sig_cmult_i, sig_cmult_q);                       

    U_SAT_SIG_CMULT_I : SAT_SIGN generic map(TRUE, 29, 26) port map(RST, CLK, sig_cmult_i(32 downto 4), sat_cmult_i);
    U_SAT_SIG_CMULT_Q : SAT_SIGN generic map(TRUE, 29, 26) port map(RST, CLK, sig_cmult_q(32 downto 4), sat_cmult_q);

    -- DDR_LUT[0] * mult
    U_LUT0xCMULT_AC : DSP48E2_MULTIPLIER generic map(26, 16, FALSE, 0, 42) port map(RST, CLK, sat_cmult_i, lut0_i, lut0_x_cmult_ac);           
    U_LUT0xCMULT_BD : DSP48E2_MULTIPLIER generic map(26, 16, FALSE, 0, 42) port map(RST, CLK, sat_cmult_q, lut0_q, lut0_x_cmult_bd);           
    U_LUT0xCMULT_AD : DSP48E2_MULTIPLIER generic map(26, 16, FALSE, 0, 42) port map(RST, CLK, sat_cmult_i, lut0_q, lut0_x_cmult_ad);           
    U_LUT0xCMULT_BC : DSP48E2_MULTIPLIER generic map(26, 16, FALSE, 0, 42) port map(RST, CLK, sat_cmult_q, lut0_i, lut0_x_cmult_bc);           

    P_LUT0xCMULT : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            lut0_x_cmult_i <= (lut0_x_cmult_ac(41) & lut0_x_cmult_ac) - (lut0_x_cmult_bd(41) & lut0_x_cmult_bd); 
            lut0_x_cmult_q <= (lut0_x_cmult_ad(41) & lut0_x_cmult_ad) + (lut0_x_cmult_bc(41) & lut0_x_cmult_bc); 
        end if;
    end process;

    lut0_x_cmult_rs_i <= lut0_x_cmult_i(41 downto 2*SIGNAL_Q_POINT-4+LUT_DDR_Q_POINT-SUM_Q_POINT); 
    lut0_x_cmult_rs_q <= lut0_x_cmult_q(41 downto 2*SIGNAL_Q_POINT-4+LUT_DDR_Q_POINT-SUM_Q_POINT); 


    P_DDR_0 : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            ddr0_i <= sign_extension(lut0_x_cmult_rs_i, 28); 
            ddr0_q <= sign_extension(lut0_x_cmult_rs_q, 28); 
        end if;
    end process;

    DDR_I_OUT(0) <= ddr0_i;
    DDR_Q_OUT(0) <= ddr0_q;

    -------------------------------------------
    -- DDR#1 
    -------------------------------------------
    P_LUT_OP : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            lut_add_i <= (LUT_I_IN(2)(15) & LUT_I_IN(2)) + (LUT_I_IN(1)(15) & LUT_I_IN(1)); 
            lut_add_q <= (LUT_Q_IN(2)(15) & LUT_Q_IN(2)) + (LUT_Q_IN(1)(15) & LUT_Q_IN(1)); 
                                                                      
            lut_sub_i <= (LUT_I_IN(2)(15) & LUT_I_IN(2)) - (LUT_I_IN(1)(15) & LUT_I_IN(1)); 
            lut_sub_q <= (LUT_Q_IN(2)(15) & LUT_Q_IN(2)) - (LUT_Q_IN(1)(15) & LUT_Q_IN(1)); 
        end if;
    end process;

    -- DDR_LUT_OP * mult
    U_LUT_OPxCMULT_AC : DSP48E2_MULTIPLIER generic map(26, 17, FALSE, 0, 43) port map(RST, CLK, sat_cmult_i, lut_add_i, lut_op_x_cmult_ac);           
    U_LUT_OPxCMULT_BD : DSP48E2_MULTIPLIER generic map(26, 17, FALSE, 0, 43) port map(RST, CLK, sat_cmult_q, lut_sub_q, lut_op_x_cmult_bd);           
    U_LUT_OPxCMULT_AD : DSP48E2_MULTIPLIER generic map(26, 17, FALSE, 0, 43) port map(RST, CLK, sat_cmult_i, lut_add_q, lut_op_x_cmult_ad);           
    U_LUT_OPxCMULT_BC : DSP48E2_MULTIPLIER generic map(26, 17, FALSE, 0, 43) port map(RST, CLK, sat_cmult_q, lut_sub_i, lut_op_x_cmult_bc);           

    P_LUT_OPxCMULT : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            lut_op_x_cmult_i <= (lut_op_x_cmult_ac(42) & lut_op_x_cmult_ac) - (lut_op_x_cmult_bd(42) & lut_op_x_cmult_bd); 
            lut_op_x_cmult_q <= (lut_op_x_cmult_ad(42) & lut_op_x_cmult_ad) + (lut_op_x_cmult_bc(42) & lut_op_x_cmult_bc); 
        end if;
    end process;

    lut_op_x_cmult_rs_i <= lut_op_x_cmult_i(43 downto 2*SIGNAL_Q_POINT-4+LUT_DDR_Q_POINT-SUM_Q_POINT); 
    lut_op_x_cmult_rs_q <= lut_op_x_cmult_q(43 downto 2*SIGNAL_Q_POINT-4+LUT_DDR_Q_POINT-SUM_Q_POINT); 

    P_DDR_1 : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            ddr1_i <= lut_op_x_cmult_rs_i; 
            ddr1_q <= lut_op_x_cmult_rs_q; 
        end if;
    end process;

    DDR_I_OUT(1) <= ddr1_i;
    DDR_Q_OUT(1) <= ddr1_q;


end arc_DPD_3D_LUT41_DDR;
