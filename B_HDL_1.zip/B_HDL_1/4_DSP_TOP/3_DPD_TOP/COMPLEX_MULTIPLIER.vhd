Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

Library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity COMPLEX_MULTIPLIER is
generic(
    DEVICE         : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HOVS           : natural :=        1 ;

    INPUT_WIDTH    : natural :=       16 ; -- AIN bitwidth : 0 to 29
    RND_EN         : boolean :=     TRUE ; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT        : natural :=       15 ; -- Rounding bit  
    OUTPUT_WIDTH   : natural :=       16   -- Result bitwidth : 0 to 47
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;

    DATA_VLD_IN    : in  std_logic;
    ADATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    ADATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
                                            
    BDATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    BDATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
   
    DATA_VLD_OUT   : out std_logic;
    DATA_I_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0);
    DATA_Q_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
end COMPLEX_MULTIPLIER;

architecture arc_COMPLEX_MULTIPLIER of COMPLEX_MULTIPLIER is

component COMPLEX_MULTIPLIER_HOVS1 is
generic(
    DEVICE         : string := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    HS_MODE        : boolean;

    INPUT_WIDTH    : natural; -- AIN bitwidth : 0 to 29
    RND_EN         : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT        : natural; -- Rounding bit  
    OUTPUT_WIDTH   : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;

    DATA_VLD_IN    : in  std_logic;
    ADATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    ADATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
                                            
    BDATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    BDATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
   
    DATA_VLD_OUT   : out std_logic;
    DATA_I_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0);
    DATA_Q_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
end component;

component COMPLEX_MULTIPLIER_HOVS2 is
generic(
    DEVICE         : string := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2

    INPUT_WIDTH    : natural; -- AIN bitwidth : 0 to 29
    RND_EN         : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT        : natural; -- Rounding bit  
    OUTPUT_WIDTH   : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST            : in  std_logic;
    CLK            : in  std_logic;

    DATA_VLD_IN    : in  std_logic;
    ADATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    ADATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
                                            
    BDATA_I_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
    BDATA_Q_IN     : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
   
    DATA_VLD_OUT   : out std_logic;
    DATA_I_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0);
    DATA_Q_OUT     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
end component;

begin

    G_COMPLEX_MULTIPLIER_HOVS1 : if (HOVS = 1) generate begin
        U_COMPLEX_MULTIPLIER_HOVS1 : COMPLEX_MULTIPLIER_HOVS1 
        generic map(
            DEVICE         => DEVICE         ,
            HS_MODE        => TRUE           ,
                                             
            INPUT_WIDTH    => INPUT_WIDTH    ,
            RND_EN         => RND_EN         ,
            RND_BIT        => RND_BIT        ,
            OUTPUT_WIDTH   => OUTPUT_WIDTH    
            )
        port map(
            RST            => RST            ,
            CLK            => CLK            ,
                                             
            DATA_VLD_IN    => DATA_VLD_IN    ,
            ADATA_I_IN     => ADATA_I_IN     ,
            ADATA_Q_IN     => ADATA_Q_IN     ,
                                           
            BDATA_I_IN     => BDATA_I_IN     ,
            BDATA_Q_IN     => BDATA_Q_IN     ,
                                             
            DATA_VLD_OUT   => DATA_VLD_OUT   ,
            DATA_I_OUT     => DATA_I_OUT     ,
            DATA_Q_OUT     => DATA_Q_OUT      
            );
    end generate;

    G_COMPLEX_MULTIPLIER_HOVS2 : if (HOVS = 2) generate begin
        U_COMPLEX_MULTIPLIER_HOVS2 : COMPLEX_MULTIPLIER_HOVS2 
        generic map(
            DEVICE         => DEVICE         ,
                                             
            INPUT_WIDTH    => INPUT_WIDTH    ,
            RND_EN         => RND_EN         ,
            RND_BIT        => RND_BIT        ,
            OUTPUT_WIDTH   => OUTPUT_WIDTH    
            )
        port map(
            RST            => RST            ,
            CLK            => CLK            ,
                                             
            DATA_VLD_IN    => DATA_VLD_IN    ,
            ADATA_I_IN     => ADATA_I_IN     ,
            ADATA_Q_IN     => ADATA_Q_IN     ,
                                           
            BDATA_I_IN     => BDATA_I_IN     ,
            BDATA_Q_IN     => BDATA_Q_IN     ,
                                             
            DATA_VLD_OUT   => DATA_VLD_OUT   ,
            DATA_I_OUT     => DATA_I_OUT     ,
            DATA_Q_OUT     => DATA_Q_OUT      
            );
    end generate;

end arc_COMPLEX_MULTIPLIER;
