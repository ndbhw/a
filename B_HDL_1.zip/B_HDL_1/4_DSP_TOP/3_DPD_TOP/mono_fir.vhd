library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_signed.all;
use IEEE.std_logic_arith.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity MONO_FIR is
    generic(
        HOVS                        : natural := 1 ;
        RND_POINT                   : natural := 15;
        TAP_NUM                     : natural := 52
    );
    port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        VALID_IN                    : in  std_logic;
        DATA_IN                     : in  std_logic_vector(15 downto 0);
        
        DATA_OUT                    : out std_logic_vector(15 downto 0)
    );
end MONO_FIR;

architecture arc_RTL of MONO_FIR Is

    component MONO_DSP48_A is
        generic(
        HOVS                        : natural
        );
        port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        A                           : in  std_logic_vector(29 downto 0);
        C                           : in  std_logic_vector(47 downto 0);
        B                           : in  std_logic_vector(17 downto 0);
        D                           : in  std_logic_vector(26 downto 0);

        OPMODE                      : in  std_logic_vector(8 downto 0);
        ACOUT                       : out std_logic_vector(29 downto 0);
        PCOUT                       : out std_logic_vector(47 downto 0)
    );
    end component;

    component MONO_DSP48_B is
        generic(
        HOVS                        : natural
        );
        port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        A                           : in  std_logic_vector(29 downto 0);
        ACIN                        : in  std_logic_vector(29 downto 0);
        B                           : in  std_logic_vector(17 downto 0);
        D                           : in  std_logic_vector(26 downto 0);

        OPMODE                      : in  std_logic_vector(8 downto 0);
        PCIN                        : in  std_logic_vector(47 downto 0);
        ACOUT                       : out std_logic_vector(29 downto 0);
        PCOUT                       : out std_logic_vector(47 downto 0)
    );
    end component;

    component MONO_DSP48_C is
        generic(
        HOVS                        : natural
        );
        port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        A                           : in  std_logic_vector(29 downto 0);
        ACIN                        : in  std_logic_vector(29 downto 0);
        B                           : in  std_logic_vector(17 downto 0);
        D                           : in  std_logic_vector(26 downto 0);

        OPMODE                      : in  std_logic_vector(8 downto 0);
        PCIN                        : in  std_logic_vector(47 downto 0);
        P                           : out std_logic_vector(47 downto 0)
    );
    end component;

    component DELAY_SRL16E is
        port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        DATA_IN                     : in  std_logic_vector(15 downto 0);
        DELAY_NUM                   : in  std_logic_vector( 3 downto 0);
        DATA_OUT                    : out std_logic_vector(15 downto 0)
        );
    end component;

    constant TAP_HALF               : natural := TAP_NUM/2;
    constant TAP_HALF_ODD           : natural := ternary_func((TAP_HALF mod 2 = 1),1,0);
    constant DSP_INSTANCES          : natural := ternary_func(HOVS = 1 , TAP_NUM/2 , TAP_NUM/(2*HOVS)+TAP_HALF_ODD);
    constant coeff_hovs1            : integer_array(TAP_HALF-1 downto 0) :=
    -- (15213, 12435, 7814, 2834, -1057, -2985, -2907, -1500, 227, 1405, 1632, 1030, 60, -779, -1180, -1030, -106, 2608, -949);                  
    -- (18661, 13622, 6033, -618, -3828, -3295, -726, 1562, 2123, 1044, -509, -1346, -1050, -66, 846, 1146, 469, -2233, 764);           -- RF4440 B13
    -- (9089, 6482, 2822, -10, -1119, -890, -269, 96, 132, 50);
    -- (13596, 11582, 8122, 4151, 654, -1652, -2508, -2136, -1070, 76, 843, 1050, 795, 339, -42, -1002);                                   -- RF2239
	(11911, 10526, 8068, 5073, 2152, -171, -1585, -2046, -1743, -1011, -204, 412, 723, 781, 787, -703);                                   -- RF2239_NEW_307
    -- (16236, 12903, 7494, 1948, -1971, -3397, -2602, -685, 1060, 1783, 1368, 311, -678, -1105, -875, -203, 717, 1985, -1365);         -- RF4440 B5
    constant coeff_hovs2            : integer_array(TAP_HALF+TAP_HALF_ODD-1 downto 0) :=
    -- (15213, 12435, 7814, 2834, -1057, -2985, -2907, -1500, 227, 1405, 1632, 1030, 60, -779, -1180, -1030, -106, 2608, -949, 0);                  
    --(18661, 13622, 6033, -618, -3828, -3295, -726, 1562, 2123, 1044, -509, -1346, -1050, -66, 846, 1146, 469, -2233, 764, 0);        -- RF4440 B13
    -- (9089, 6482, 2822, -10, -1119, -890, -269, 96, 132, 50, 0);
    -- (16236, 12903, 7494, 1948, -1971, -3397, -2602, -685, 1060, 1783, 1368, 311, -678, -1105, -875, -203, 717, 1985, -1365, 0);      -- RF4440 B5
    -- (13596, 11582, 8122, 4151, 654, -1652, -2508, -2136, -1070, 76, 843, 1050, 795, 339, -42, -1002);                                   -- RF2239
	(11911, 10526, 8068, 5073, 2152, -171, -1585, -2046, -1743, -1011, -204, 412, 723, 781, 787, -703);                                   -- RF2239_NEW_307
    --signal rnd_const                : std_logic_vector( 47 downto 0)                := conv_std_logic_vector(2**RND_POINT,48);
    constant rnd_const              : std_logic_vector( 47 downto 0)                := conv_std_logic_vector(2**RND_POINT,48);
    --constant rnd_const              : std_logic_vector( 47 downto 0)              := (others => '0');

    signal coefficient              : integer_array(DSP_INSTANCES-1 downto 0)       := (others => 0);
    signal ex_coefficient           : std_logic_array18(DSP_INSTANCES-1 downto 0)   := (others => (others => '0'));

    signal delayed_data             : std_logic_array16( 2 downto 0)                := (others => (others => '0'));
    signal opmode_a                 : std_logic_vector(  8 downto 0)                := (others => '0');
    signal opmode                   : std_logic_vector(  8 downto 0)                := (others => '0');

    signal a_input_data             : std_logic_array30(DSP_INSTANCES-1 downto 0)   := (others => (others => '0'));
    signal d_input_data             : std_logic_vector( 26 downto 0)                := (others => '0');

    signal ex_a_input               : std_logic_array30(DSP_INSTANCES-1 downto 0)   := (others => (others => '0'));
    signal ex_d_input               : std_logic_array27(DSP_INSTANCES-1 downto 0)   := (others => (others => '0'));
    
    signal dsp_sum                  : std_logic_array48(DSP_INSTANCES-1 downto 0)   := (others => (others => '0'));
    signal temp_sum                 : std_logic_vector( 16 downto 0)                := (others => '0');
    signal temp_out                 : std_logic_vector( 47 downto 0)                := (others => '0');

    signal temp_round               : std_logic_vector( 16 downto 0)                := (others => '0');
    signal temp_satu                : std_logic_vector( 16 downto 0)                := (others => '0');

    constant p_satu_value           : std_logic_vector( 16 downto 0)                := '0'&x"7FFF";
    constant n_satu_value           : std_logic_vector( 16 downto 0)                := '0'&x"8000";

    signal srl_dly_a                : std_logic_vector(  3 downto 0)                := (others => '0');
    signal srl_dly_d                : std_logic_vector(  3 downto 0)                := (others => '0');
    signal srl_dly_ad               : std_logic_vector(  3 downto 0)                := (others => '0');

    signal data_a                   : std_logic_array16(DSP_INSTANCES-1 downto 0)   := (others => (others =>'0'));
    signal data_d                   : std_logic_array16(DSP_INSTANCES-1 downto 0)   := (others => (others =>'0'));


begin

    --rnd_const    <=    conv_std_logic_vector(2**RND_POINT,48);
-----------------------------------------------------------------------------------------------------------------
---------------------------------------------when HOVS = 1-------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
    G_MAPPING_HOVS_1 : if (HOVS = 1) generate begin

        process(RST , CLK)
        begin
            if RST = '1' then
                delayed_data(0)     <= (others => '0');
            elsif rising_edge(CLK) then
                delayed_data(0)     <= DATA_IN;            
            end if;
        end process;
       
        COEFFICIENT_MAPPING_1 : for I in 0 to DSP_INSTANCES-1 generate
            ex_coefficient(I)       <= sign_extension(coeff_hovs1(I),18);
        end generate;

        a_input_data(DSP_INSTANCES-1)<= sign_extension(delayed_data(0),30);
        d_input_data                 <= sign_extension(delayed_data(0),27);

        -------------------------------------------------------------------
        -----------------DSP primitives Mapping----------------------------
        -------------------------------------------------------------------
        DSP_BLOCK_GEN_1 : for I in DSP_INSTANCES-1 downto 0 generate
        begin
            DSP_PRIMITIVE_FIRST_1 : if (I = DSP_INSTANCES-1) generate
                U_DSP_A_1 : MONO_DSP48_A 
                generic map(HOVS)
                port map(RST,CLK,a_input_data(I),rnd_const,    ex_coefficient(I),d_input_data,"000110101",             a_input_data(I-1),dsp_sum(I));
                      -- RST CLK A               C             B                 D             OPMODE                  ACOUT             PCOUT         
            end generate;
            
            DSP_PRIMITIVE_MIDDLE_1 : if (I < DSP_INSTANCES-1) and (I > 0) generate
                U_DSP_B_1 : MONO_DSP48_B 
                generic map(HOVS)
                port map(RST,CLK,(others=>'0'),a_input_data(I),ex_coefficient(I),d_input_data,"000010101",dsp_sum(I+1),a_input_data(I-1),dsp_sum(I));
                      -- RST CLK A             ACIN            B                 D             OPMODE     PCIN         ACOUT             PCOUT
            end generate;

            DSP_PRIMITIVE_LAST_1 : if (I = 0) generate
                U_DSP_C_1 : MONO_DSP48_C
                generic map(HOVS)
                port map(RST,CLK,(others=>'0'),a_input_data(I),ex_coefficient(I),d_input_data,"000010101",dsp_sum(I+1),                  dsp_sum(I));
                      -- RST CLK A             ACIN            B                 D             OPMODE     PCIN                           PCOUT
            end generate;
        end generate;
       
    end generate;

--------------------------------------------------------------------------------------------------------------------
------------------------------------------------when HOVS = 2-------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
    G_MAPPING_HOVS_2 : if (HOVS = 2) generate begin
        process(RST , CLK)
        begin
            if RST = '1' then
                delayed_data(0)         <= (others => '0');
            elsif rising_edge(CLK) then
                case (VALID_IN) is
                    when '1' => 
                        delayed_data(0) <= DATA_IN;
                    when others =>
                        delayed_data(0) <= delayed_data(0);
                end case;
            end if;
        end process;
        
        DELAY_GENERATE : for I in 0 to 1 generate begin
            process(RST,CLK)
            begin
                if RST = '1' then
                    delayed_data(I+1)  <= (others => '0');
                elsif rising_edge(CLK) then
                    delayed_data(I+1)  <= delayed_data(I);
                end if;
            end process;
        end generate;

        ------------------------------------------------------------------------------------
        --------------------coefficient mapping and bit extension---------------------------
        ------------------------------------------------------------------------------------

        COEFF_MAPPING_2 : for I in 0 to DSP_INSTANCES-1 generate
            coefficient(I)          <= coeff_hovs2(I*2) when VALID_IN = '1' else coeff_hovs2(I*2+1);
            ex_coefficient(I)       <= sign_extension(coefficient(I),18);
        end generate;

        DATA_DELAY_2 : process(RST, CLK)
        begin
            if RST = '1' then
                srl_dly_a               <= (others => '0');
                srl_dly_d               <= (others => '0');
                srl_dly_ad              <= (others => '0');
            elsif rising_edge(CLK) then
                case(VALID_IN) is
                    when '1' =>
                        srl_dly_a       <= x"1";
                        srl_dly_d       <= x"5";
                        srl_dly_ad      <= x"4";
                    when others =>
                        srl_dly_a       <= x"1";
                        srl_dly_d       <= x"5";
                        srl_dly_ad      <= x"1";
                end case;
            end if;
        end process;

        ---------------------------------------------------------------------------------------------
        --------------------------------A,B delay aligning-------------------------------------------
        ---------------------------------------------------------------------------------------------
        data_a(0)                   <= delayed_data(2);

        DATA_MAPPING_2 : for I in 0 to DSP_INSTANCES-1 generate
        begin
            
            FOR_AND_REV : if ( I < DSP_INSTANCES-1 )
            generate
                FORWARD  : DELAY_SRL16E port map(RST , CLK , data_a(I)                 , srl_dly_a  , data_a(I+1));
                REVERSE  : DELAY_SRL16E port map(RST , CLK , data_d(DSP_INSTANCES-1-I) , srl_dly_d  , data_d(DSP_INSTANCES-2-I));
            end generate;

            CEN : if ( I = DSP_INSTANCES-1 )
            generate
                CENTER   : DELAY_SRL16E port map(RST , CLK , data_a(I)                 , srl_dly_ad , data_d(I));
            end generate;



        -----------------------------------------------------------------------------------------
        --------------------------------bit extension--------------------------------------------
        -----------------------------------------------------------------------------------------
            BIT_EXTENSION : process(RST,CLK)
            begin
                if RST = '1' then
                    ex_a_input(I)   <= (others => '0');
                    ex_d_input(I)   <= (others => '0');
                elsif rising_edge(CLK) then
                    ex_a_input(I)   <= sign_extension(data_a(I),30);
                    ex_d_input(I)   <= sign_extension(data_d(I),27);

                end if;
            end process;

        end generate;
        -----------------------------------------------------------------------------------
        -----------------------------OPMODE setting----------------------------------------
        -----------------------------------------------------------------------------------
        OPMODE_CONTROL : process(RST, CLK) 
        begin
            if RST = '1' then
                opmode_a            <= (others => '0');
                opmode              <= (others => '0');
            elsif rising_edge(CLK) then
                case (VALID_IN) is
                    when '1' => 
                        opmode_a    <= "000110101"; -- C    calculate		    
                        opmode      <= "000010101"; -- PCIN calculate		    
                    when others => 
                        opmode_a    <= "000100101"; -- Internal P calculate		  
                        opmode      <= "000100101"; -- Internal P calculaate        
                end case;
            end if;
        end process;

        -------------------------------------------------------------------------------------
        --------------------------DSP primitives Mapping-------------------------------------
        -------------------------------------------------------------------------------------
        DSP_BLOCK_GEN_2 : for I in DSP_INSTANCES-1 downto 0 generate
        begin
            DSP_PRIMITIVE_FIRST_2 : if (I = DSP_INSTANCES-1) generate
                U_DSP_A_2 : MONO_DSP48_A
                generic map(HOVS)
                port map(RST,CLK,ex_a_input(I),rnd_const,    ex_coefficient(I),ex_d_input(I),opmode_a,             open,dsp_sum(I));
            end generate;

            DSP_PRIMITIVE_MIDDLE_2 : if (I < DSP_INSTANCES-1) and (I > 0) generate
                U_DSP_B_2 : MONO_DSP48_B
                generic map(HOVS)
                port map(RST,CLK,ex_a_input(I),(others=>'0'),ex_coefficient(I),ex_d_input(I),opmode  ,dsp_sum(I+1),open,dsp_sum(I));
            end generate;

            DSP_PRIMITIVE_LAST_2 : if (I = 0) generate
                U_DSP_C_2 : MONO_DSP48_C
                generic map(HOVS)
                port map(RST,CLK,ex_a_input(I),(others=>'0'),ex_coefficient(I),ex_d_input(I),opmode  ,dsp_sum(I+1),     dsp_sum(I));
            end generate;

        end generate;

    end generate;

    ---------------------------------------------------------------------------
    ----------------------------valid duration check---------------------------
    ---------------------------------------------------------------------------
    process(RST , CLK)
    begin
        if RST = '1' then
            temp_sum                <= (others => '0');
        elsif rising_edge(CLK) then
            case (VALID_IN) is
                when '1' => 
                    --temp_sum        <= dsp_sum(0)(32 downto 16);
                    temp_sum        <= dsp_sum(0)(RND_POINT+17 downto RND_POINT+1);
                when others =>
                    temp_sum        <= temp_sum;
            end case;
        end if;
    end process;

-----------------------------------------------------------------------------------------------
-------------------------saturation process----------------------------------------------------
-----------------------------------------------------------------------------------------------
    saturation : process(CLK, RST)
    begin
        if RST = '1' then
            temp_satu               <= (others => '0');
        elsif rising_edge(CLK) then
            if temp_sum(16) = '0' then
                if temp_sum(15) = '0' then
                    temp_satu       <= temp_sum;
                else
                    temp_satu       <= p_satu_value;
                end if;
            else
                if temp_sum(15) = '1' then
                    temp_satu       <= temp_sum;
                else
                    temp_satu       <= n_satu_value;
                end if;
            end if;
        end if;
    end process;

    DATA_OUT                        <= temp_satu(15 downto 0);

end arc_RTL;

