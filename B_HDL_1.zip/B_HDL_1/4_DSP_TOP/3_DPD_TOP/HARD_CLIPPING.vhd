-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name : HARD_CLIPPING 
-- Project    : 

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
use IEEE.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

-- Total processing delay =  (IQ_demuxing(1.5clocks) + HC_stage0(15clocks)) x Clock period 
--   cordic_mapper  = 2 clocks
--   cordic_stage_0 = 1 clocks
--   cordic_stage_1 = 1 clocks
--   cordic_stage_2 = 1 clocks
--   cordic_stage_3 = 1 clocks
--   cordic_stage_4 = 1 clocks
--   cordic_stage_5 = 1 clocks
--   cordic_gain = 3 clocks | lut = 1 clocks
--                          | cordic_demapper = 2 clocks
-- magnitude delay : 2+6+3 = 11 
-- sin,cos   delay : 2+8+2 = 12 
-- sin, cos multiplexing delay : 5
-- output = 1 clocks
-- others = 2 clocks
---------------------------------------------------------------------------
-- Total_delay = 12 + 5 + 1 + 2 = 20 clocks

entity HARD_CLIPPING is
generic(
    DEVICE     : string  := "7SERIES" -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    );
port(
    RST        : in  std_logic;
    CLK        : in  std_logic;

    DATA_I_IN  : in  std_logic_vector(15 downto 0);
    DATA_Q_IN  : in  std_logic_vector(15 downto 0);

    THRESHOLD  : in  std_logic_vector(15 downto 0);

    DATA_I_OUT : out std_logic_vector(15 downto 0);
    DATA_Q_OUT : out std_logic_vector(15 downto 0);
  
    HC_EN      : in  std_logic;
    HC_ON      : out std_logic
    );
end HARD_CLIPPING;

architecture arc_HARD_CLIPPING of HARD_CLIPPING is

component RST_SYNC is
generic(
    DLY_NUM                      : natural := 3;    -- Number of delay.
    MAX_FANOUT_NUM               : integer := 200   -- Number of maximum fanout
    );
port(
    RST_IN                       : in  std_logic;   -- Active high asynchronous reset
    CLK                          : in  std_logic;   -- clock to be sync'ed to
    RST_OUT                      : out std_logic    -- "Synchronised" reset signal
    );         
end component;

component CORDIC is
generic(
    HS_MODE            : boolean :=  TRUE ; -- High Speed Mode (Operating Clock > 307.2MHz)

    STAGE_NUM          : natural :=     6 ;
    MAGN               : boolean :=  TRUE ;
    ANGLE              : boolean := FALSE
    );
port(
    CLK                : in  std_logic;

    DATA_I             : in  std_logic_vector(15 downto 0);
    DATA_Q             : in  std_logic_vector(15 downto 0);

    MAGNITUDE_OUT      : out std_logic_vector(15 downto 0);
    SIN_OUT            : out std_logic_vector(13 downto 0);
    COS_OUT            : out std_logic_vector(13 downto 0)
    );
end component;

component DSP48E1_MULTIPLIER is
generic(
    AIN_BITWIDTH : natural; -- AIN bitwidth : 0 to 29
    BIN_BITWIDTH : natural; -- BIN bitwidth : 0 to 17
    RND_EN       : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT      : natural; -- Rounding bit  
    OUTPUT_WIDTH : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
    AIN          : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
    BIN          : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
    P            : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
    );
end component;

component DSP48E2_MULTIPLIER is
generic(
    AIN_BITWIDTH : natural; -- AIN bitwidth : 0 to 29
    BIN_BITWIDTH : natural; -- BIN bitwidth : 0 to 17
    RND_EN       : boolean; -- "TRUE": Using Rounding, "FALSE": Nonusing Rounding 
    RND_BIT      : natural; -- Rounding bit  
    OUTPUT_WIDTH : natural  -- Result bitwidth : 0 to 47
    );
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;
    AIN          : in  std_logic_vector(AIN_BITWIDTH-1 downto 0);
    BIN          : in  std_logic_vector(BIN_BITWIDTH-1 downto 0);
    P            : out std_logic_vector((OUTPUT_WIDTH+RND_BIT-1) downto RND_BIT)
    );
end component;

component SRLC32E_DLY is
generic(
    DEVICE    : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HS_MODE   : boolean :=        TRUE ;

    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    CLK       : IN  STD_LOGIC;
    DATA_IN   : IN  STD_LOGIC_VECTOR(BIT_WIDTH-1 downto 0);
    DATA_COUT : OUT STD_LOGIC_VECTOR(BIT_WIDTH-1 downto 0); -- SRLC32E Chain, 32clock Delayed DATA
    DATA_OUT  : OUT STD_LOGIC_VECTOR(BIT_WIDTH-1 downto 0)  -- Delayed DATA
    );
end component;

component SAT_SIGN is
generic(
    HS_MODE    : boolean := TRUE;
    INPUT_BIT  : natural;
    OUTPUT_BIT : natural
);
port( 
    RST        : in  std_logic;
    CLK        : in  std_logic;
    DATA_IN    : in  std_logic_vector(INPUT_BIT-1  downto 0);
    DATA_OUT   : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

signal rst_synch     : std_logic;

signal magnitude     : std_logic_vector(15 downto 0);
signal magnitude_dly : std_logic_vector(15 downto 0);
signal sin           : std_logic_vector(13 downto 0);
signal cos           : std_logic_vector(13 downto 0);

signal se_sin        : std_logic_vector(17 downto 0);
signal se_cos        : std_logic_vector(17 downto 0);

signal hc_thres      : std_logic_vector(17 downto 0);

signal rnd_cos       : std_logic_vector(18 downto 0);
signal rnd_sin       : std_logic_vector(18 downto 0);

signal clipped_I_i   : std_logic_vector(15 downto 0); 
signal clipped_Q_i   : std_logic_vector(15 downto 0); 

signal hc_en_sh      : std_logic_vector( 2 downto 0);

signal clipped_I     : std_logic_vector(15 downto 0); 
signal clipped_Q     : std_logic_vector(15 downto 0); 

signal data_i_dly    : std_logic_vector(15 downto 0);
signal data_q_dly    : std_logic_vector(15 downto 0);

signal compare_flg   : std_logic;

attribute KEEP       : string;
attribute KEEP of compare_flg  : signal is "TRUE";

begin

    U_RST_SYNC : RST_SYNC generic map(4, 200) port map(RST, CLK, rst_synch);

    U_Cordic   : CORDIC generic map(TRUE, 6, TRUE, TRUE) port map(CLK, DATA_I_IN, DATA_Q_IN, magnitude, sin, cos);

    -- Sign Extention
    se_sin <= sin(13)& sin(13)& sin(13)& sin(13)& sin;
    se_cos <= cos(13)& cos(13)& cos(13)& cos(13)& cos;

    -- adjustment of threshold value
    -- threshold + threshold*(1/2^8)

    P_Adjust_threshold_value : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            hc_thres <= ("00"&THRESHOLD) + ("000000000"&THRESHOLD(15 downto 8));
        end if;
    end process;

    G_7Series_DSP48E1 : if (DEVICE = "7SERIES") generate begin
        U_DSP48E1_Cos_Multiple : DSP48E1_MULTIPLIER generic map(18,18,TRUE,13,19) port map(rst_synch, CLK, hc_thres, se_cos, rnd_cos);
        U_DSP48E1_Sin_Multiple : DSP48E1_MULTIPLIER generic map(18,18,TRUE,13,19) port map(rst_synch, CLK, hc_thres, se_sin, rnd_sin);
    end generate;                                                                             
                                                                                              
    G_UltraScale_DSP48E2 : if (DEVICE = "ULTRASCALE") generate begin                          
        U_DSP48E2_Cos_Multiple : DSP48E2_MULTIPLIER generic map(18,18,TRUE,13,19) port map(rst_synch, CLK, hc_thres, se_cos, rnd_cos);
        U_DSP48E2_Sin_Multiple : DSP48E2_MULTIPLIER generic map(18,18,TRUE,13,19) port map(rst_synch, CLK, hc_thres, se_sin, rnd_sin);
    end generate;

    -- 16bits Saturation
    U_SAT_I : SAT_SIGN generic map(TRUE, 19, 16)port map (rst_synch, CLK, rnd_cos, clipped_I_i);
    U_SAT_Q : SAT_SIGN generic map(TRUE, 19, 16)port map (rst_synch, CLK, rnd_sin, clipped_Q_i);

    U_Clocking : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            clipped_I <= clipped_I_i;
            clipped_Q <= clipped_Q_i;
        end if;
    end process;

    -- Comparator
    -- sin, cos multiplexing delay : 5
    -- magnitude delay should be 6
    U_magnitude_DELAY : SRLC32E_DLY generic map(DEVICE, TRUE, 16,  6) port map(CLK, magnitude, open, magnitude_dly); 

    P_HC_EN_DC : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            hc_en_sh <= hc_en_sh(1 downto 0) & HC_EN;      
        end if;
    end process;

    P_Compare_Flag : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (("00"&magnitude_dly) > hc_thres) then
                compare_flg <= hc_en_sh(2); 
            else
                compare_flg <= '0'; 
            end if;
        end if;
    end process;

    --Total Delay Compensation 
    DATA_I_DELAY1 : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 25) port map(CLK, DATA_I_IN, open, data_i_dly); 
    DATA_Q_DELAY1 : SRLC32E_DLY generic map(DEVICE, TRUE, 16, 25) port map(CLK, DATA_Q_IN, open, data_q_dly); 

    P_Hard_Clipper : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (compare_flg = '1') then
                DATA_I_OUT <= clipped_I;
                DATA_Q_OUT <= clipped_Q;
                HC_ON      <= '1' ;
            else
                DATA_I_OUT <= data_i_dly;
                DATA_Q_OUT <= data_q_dly;
                HC_ON      <= '0' ;
            end if;
        end if;
    end process;

end arc_HARD_CLIPPING;
