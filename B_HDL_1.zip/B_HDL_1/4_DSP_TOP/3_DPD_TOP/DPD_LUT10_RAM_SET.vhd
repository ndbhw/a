library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity DPD_LUT10_RAM_SET is
generic(
    DEVICE                   : string  := "ULTRASCALE"; -- "7SERIESE": DSP48E1, "ULTRASCALE" : DSP48E2 
    TX_ANT_NUM               : natural :=           4 ;
    HS_MODE                  : boolean :=       FALSE ;
    HOVS                     : natural :=           1 ;
    LUT_OPTIMIZED            : boolean :=       FALSE ;
    LUT_MEM_DEPTH            : string  :=       "FULL"; -- "FULL": 32x512x2, "HALF": 32x256x2
    LUT_RBTEST               : boolean :=       FALSE ;
    LUT_RAM_NUM              : natural :=          20 
    );
port(
    RST_CPU                  : in  std_logic;
    CLK_CPU                  : in  std_logic;

    LUT_SWITCH_IN            : in  std_logic_vector(TX_ANT_NUM-1 downto 0);
    LUT_ENA_IN               : in  std_logic_array20(TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path
    LUT_WREN_IN              : in  std_logic_array20(TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path
    LUT_WADDR_IN             : in  std_logic_array9( TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path
    LUT_WDATA_IN             : in  std_logic_array32(TX_ANT_NUM downto 0);   -- #Antenna_Path + #CPU_Control_Path
    LUT_RBDATA_OUT           : out std_logic_array20_array32(TX_ANT_NUM downto 0);

    RST_DPD                  : in  std_logic;
    CLK_DPD                  : in  std_logic;

    LUT_RADDR_IN             : in  std_logic_array20_array9( TX_ANT_NUM downto 0);
    LUT_RDATA_OUT            : out std_logic_array20_array32(TX_ANT_NUM downto 0)
    );
end DPD_LUT10_RAM_SET;

architecture arc_DPD_LUT10_RAM_SET of DPD_LUT10_RAM_SET is

component TRUE_DPRAM_DUALCLK is
generic(
    RAM_INIT_VALUE           : integer := 0;

    DATA_WIDTH               : natural := 32;
    ADDR_WIDTH               : natural := 10 
    );
port(
    CLK_A                    : in  std_logic;
    EN_A                     : in  std_logic := '1';
    WE_A                     : in  std_logic := '1';
    ADDR_A                   : in  std_logic_vector((ADDR_WIDTH-1) downto 0);
    DATA_A                   : in  std_logic_vector((DATA_WIDTH-1) downto 0);
    Q_A	                     : out std_logic_vector((DATA_WIDTH-1) downto 0);

    CLK_B                    : in  std_logic;
    EN_B                     : in  std_logic := '1';
    WE_B                     : in  std_logic := '1';
    ADDR_B                   : in  std_logic_vector((ADDR_WIDTH-1) downto 0);
    DATA_B                   : in  std_logic_vector((DATA_WIDTH-1) downto 0);
    Q_B	                     : out std_logic_vector((DATA_WIDTH-1) downto 0)
    );
end component;

component SIMPLE_DPRAM_DUALCLK is
generic(
    RAM_STYLE                : string  := "BLOCK"; -- DISTRIBUTED or BLOCK
    RAM_INIT_VALUE           : integer := 0; 

    DATA_WIDTH               : natural := 8;
    ADDR_WIDTH               : natural := 6
    );
port(
    CLKA                     : in  std_logic;
    ENA                      : in  std_logic;
    WEA                      : in  std_logic;
    ADDRA                    : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATAA                    : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    CLKB                     : in  std_logic;
    ENB                      : in  std_logic;
    ADDRB                    : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    DATAB                    : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end component;

component SRL16E_DLY is
generic(
    DEVICE                   : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    HS_MODE                  : boolean :=        TRUE ;

    BIT_WIDTH                : natural; -- 2 to 64
    DELAY_NUM                : natural
    );
port(
    CLK                      : in  std_logic;

    DATA_IN                  : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT                 : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end component;

constant lut0_init_value     : integer := 536870912;

signal lut_raddr_dly         : std_logic_array20_array9( TX_ANT_NUM downto 0);

signal lut_switch_sh         : std_logic_array2( TX_ANT_NUM-1 downto 0);
signal lut_waddr             : std_logic_array10(TX_ANT_NUM-1 downto 0);
signal lut_raddr             : std_logic_array20_array10(TX_ANT_NUM-1 downto 0);
signal lut_rdata             : std_logic_array20_array32(TX_ANT_NUM downto 0);
signal lut_rdata_d1          : std_logic_array20_array32(TX_ANT_NUM downto 0);
signal lut_rdata_dly         : std_logic_array20_array32(TX_ANT_NUM downto 0);

begin

    G_LUT_Non_Optimized : if (LUT_OPTIMIZED = FALSE) generate begin

        lut_raddr_dly(TX_ANT_NUM)  <= (others => (others => '0'));
        lut_rdata(TX_ANT_NUM)      <= (others => (others => '0'));
        lut_rdata_d1(TX_ANT_NUM)   <= (others => (others => '0'));
        lut_rdata_dly(TX_ANT_NUM)  <= (others => (others => '0'));

        LUT_RBDATA_OUT(TX_ANT_NUM) <= (others => (others => '0'));

        G_LUT_Non_OPD_TX_GEN : for I in 0 to (TX_ANT_NUM-1) generate begin
            G_LUT_Update_Switch_DC_Nomal_Operation : if (HS_MODE = FALSE) generate begin	    
                P_LUT_Update_Switch_Double_Clocking_NM : process(RST_DPD, CLK_DPD) begin
                    if (RST_DPD = '1') then
                        lut_switch_sh(I) <= (others => '0');
                    elsif (CLK_DPD'event) and (CLK_DPD = '1') then
                        lut_switch_sh(I) <= lut_switch_sh(I)(0) & (not LUT_SWITCH_IN(I));
                    end if;
                end process;
            end generate;

            G_LUT_Update_Switch_DC_High_Speed_Mode : if (HS_MODE = TRUE) generate begin	    
                P_LUT_Update_Switch_Double_Clocking_HS : process(CLK_DPD) begin
                    if (CLK_DPD'event) and (CLK_DPD = '1') then
                        lut_switch_sh(I) <= lut_switch_sh(I)(0) & (not LUT_SWITCH_IN(I));
                    end if;
                end process;
            end generate;

            G_LUT_Memory_Full_Depth : if (LUT_MEM_DEPTH = "FULL") generate begin
                lut_waddr(I) <= LUT_SWITCH_IN(I) & LUT_WADDR_IN(I);

                G_LUT_Depth : for J in 0 to (LUT_RAM_NUM-1) generate begin

                    U_LUT_RADDR_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 9, HOVS) port map (CLK_DPD, LUT_RADDR_IN(I)(J), lut_raddr_dly(I)(J));

                    lut_raddr(I)(J) <= lut_switch_sh(I)(1) & lut_raddr_dly(I)(J);

                    G_LUT_ReadBack_Test_Enable : if (LUT_RBTEST = TRUE) generate begin 
                        G_1st_LUT : if (J = 0) generate begin
                            U_1st_LUT : TRUE_DPRAM_DUALCLK 
                            generic map(
                                RAM_INIT_VALUE           => lut0_init_value     ,
                            
                                DATA_WIDTH               => 32                  ,
                                ADDR_WIDTH               => 10                   
                                )
                            port map(
                                CLK_A                    => CLK_CPU             , 
                                EN_A                     => LUT_ENA_IN(I)(J)    , 
                                WE_A                     => LUT_WREN_IN(I)(J)   , 
                                ADDR_A                   => lut_waddr(I)        , 
                                DATA_A                   => LUT_WDATA_IN(I)     , 
                                Q_A                      => LUT_RBDATA_OUT(I)(J), 
                            
                                CLK_B                    => CLK_DPD             , 
                                EN_B                     => '1'                 , 
                                WE_B                     => '0'                 , 
                                ADDR_B                   => lut_raddr(I)(J)     , 
                                DATA_B                   => (others => '0')     , 
                                Q_B                      => lut_rdata(I)(J)       
                                );
                        end generate;

                        G_nth_LUT : if (J > 0) generate begin
                            U_nth_LUT : TRUE_DPRAM_DUALCLK 
                            generic map(
                                RAM_INIT_VALUE           =>  0                  ,
                            
                                DATA_WIDTH               => 32                  ,
                                ADDR_WIDTH               => 10                   
                                )
                            port map(
                                CLK_A                    => CLK_CPU             , 
                                EN_A                     => LUT_ENA_IN(I)(J)    , 
                                WE_A                     => LUT_WREN_IN(I)(J)   , 
                                ADDR_A                   => lut_waddr(I)        , 
                                DATA_A                   => LUT_WDATA_IN(I)     , 
                                Q_A                      => LUT_RBDATA_OUT(I)(J), 
                            
                                CLK_B                    => CLK_DPD             , 
                                EN_B                     => '1'                 , 
                                WE_B                     => '0'                 , 
                                ADDR_B                   => lut_raddr(I)(J)     , 
                                DATA_B                   => (others => '0')     , 
                                Q_B                      => lut_rdata(I)(J)       
                                );
                        end generate;
                    end generate;

                    G_LUT_ReadBack_Test_Disable : if (LUT_RBTEST = FALSE) generate begin 

                        LUT_RBDATA_OUT(I)(J) <= (others => '0');

                        G_1st_LUT : if (J = 0) generate begin
                            U_1st_LUT : SIMPLE_DPRAM_DUALCLK 
                            generic map(
                                RAM_STYLE                => "BLOCK"             , 
                                RAM_INIT_VALUE           => lut0_init_value     , 
                            
                                DATA_WIDTH               => 32                  , 
                                ADDR_WIDTH               => 10                    
                                )
                            port map(
                                CLKA                     => CLK_CPU             , 
                                ENA                      => LUT_ENA_IN(I)(J)    , 
                                WEA                      => LUT_WREN_IN(I)(J)   , 
                                ADDRA                    => lut_waddr(I)        ,
                                DATAA                    => LUT_WDATA_IN(I)     ,
                            
                                CLKB                     => CLK_DPD             ,
                                ENB                      => '1'                 ,
                                ADDRB                    => lut_raddr(I)(J)     ,
                                DATAB                    => lut_rdata(I)(J)       
                                );
                        end generate;

                        G_nth_LUT : if (J > 0) generate begin
                            U_nth_LUT : SIMPLE_DPRAM_DUALCLK
                            generic map(
                                RAM_STYLE                => "BLOCK"             , 
                                RAM_INIT_VALUE           =>  0                  , 
                            
                                DATA_WIDTH               => 32                  , 
                                ADDR_WIDTH               => 10                    
                                )
                            port map(
                                CLKA                     => CLK_CPU             , 
                                ENA                      => LUT_ENA_IN(I)(J)    , 
                                WEA                      => LUT_WREN_IN(I)(J)   , 
                                ADDRA                    => lut_waddr(I)        ,
                                DATAA                    => LUT_WDATA_IN(I)     ,
                            
                                CLKB                     => CLK_DPD             ,
                                ENB                      => '1'                 ,
                                ADDRB                    => lut_raddr(I)(J)     ,
                                DATAB                    => lut_rdata(I)(J)       
                                );
                        end generate;

                    end generate;

                    G_LUT_Rdata_Clocking_Normal_Operation : if (HS_MODE = FALSE) generate begin
                        P_LUT_Rdata_Clocking_NM : process(RST_DPD, CLK_DPD) begin
                            if (RST_DPD = '1') then
                                lut_rdata_d1(I)(J) <= (others => '0');
                            elsif (CLK_DPD'event) and (CLK_DPD = '1') then
                                lut_rdata_d1(I)(J) <= lut_rdata(I)(J);
                            end if;
                        end process;
                    end generate;

                    G_LUT_Rdata_Clocking_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                        P_LUT_Rdata_Clocking_HS : process(CLK_DPD) begin
                            if (CLK_DPD'event) and (CLK_DPD = '1') then
                                lut_rdata_d1(I)(J) <= lut_rdata(I)(J);
                            end if;
                        end process;
                    end generate;

                    U_LUT_IQ_DLY : SRL16E_DLY generic map (DEVICE, HS_MODE, 32, HOVS) port map (CLK_DPD, lut_rdata_d1(I)(J), lut_rdata_dly(I)(J));

                end generate;
            end generate;

            G_LUT_Memory_Half_Depth : if (LUT_MEM_DEPTH = "HALF") generate begin
                lut_waddr(I) <= '0'&LUT_SWITCH_IN(I) & LUT_WADDR_IN(I)(7 downto 0);

                G_LUT_Depth : for J in 0 to (LUT_RAM_NUM-1) generate begin

                    U_LUT_RADDR_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 9, HOVS) port map (CLK_DPD, LUT_RADDR_IN(I)(J), lut_raddr_dly(I)(J));

                    lut_raddr(I)(J) <= '0'& lut_switch_sh(I)(1) & lut_raddr_dly(I)(J)(7 downto 0);

                    G_LUT_ReadBack_Test_Enable : if (LUT_RBTEST = TRUE) generate begin 
                        G_1st_LUT : if (J = 0) generate begin
                            U_1st_LUT : TRUE_DPRAM_DUALCLK 
                            generic map(
                                RAM_INIT_VALUE           => lut0_init_value            ,
                            
                                DATA_WIDTH               => 32                         ,
                                ADDR_WIDTH               =>  9                          
                                )
                            port map(
                                CLK_A                    => CLK_CPU                    , 
                                EN_A                     => LUT_ENA_IN(I)(J)           , 
                                WE_A                     => LUT_WREN_IN(I)(J)          , 
                                ADDR_A                   => lut_waddr(I)(8 downto 0)   , 
                                DATA_A                   => LUT_WDATA_IN(I)            , 
                                Q_A                      => LUT_RBDATA_OUT(I)(J)       , 
                            
                                CLK_B                    => CLK_DPD                    , 
                                EN_B                     => '1'                        , 
                                WE_B                     => '0'                        , 
                                ADDR_B                   => lut_raddr(I)(J)(8 downto 0), 
                                DATA_B                   => (others => '0')            , 
                                Q_B                      => lut_rdata(I)(J)       
                                );
                        end generate;

                        G_nth_LUT : if (J > 0) generate begin
                            U_nth_LUT : TRUE_DPRAM_DUALCLK 
                            generic map(
                                RAM_INIT_VALUE           =>  0                         ,
                            
                                DATA_WIDTH               => 32                         ,
                                ADDR_WIDTH               =>  9                          
                                )
                            port map(
                                CLK_A                    => CLK_CPU                    , 
                                EN_A                     => LUT_ENA_IN(I)(J)           , 
                                WE_A                     => LUT_WREN_IN(I)(J)          , 
                                ADDR_A                   => lut_waddr(I)(8 downto 0)   , 
                                DATA_A                   => LUT_WDATA_IN(I)            , 
                                Q_A                      => LUT_RBDATA_OUT(I)(J)       , 
                            
                                CLK_B                    => CLK_DPD                    , 
                                EN_B                     => '1'                        , 
                                WE_B                     => '0'                        , 
                                ADDR_B                   => lut_raddr(I)(J)(8 downto 0), 
                                DATA_B                   => (others => '0')            , 
                                Q_B                      => lut_rdata(I)(J)       
                                );
                        end generate;
                    end generate;

                    G_LUT_ReadBack_Test_Disable : if (LUT_RBTEST = FALSE) generate begin 

                        LUT_RBDATA_OUT(I)(J) <= (others => '0');

                        G_1st_LUT : if (J = 0) generate begin
                            U_1st_LUT : SIMPLE_DPRAM_DUALCLK 
                            generic map(
                                RAM_STYLE                => "BLOCK"                    , 
                                RAM_INIT_VALUE           => lut0_init_value            , 
                            
                                DATA_WIDTH               => 32                         , 
                                ADDR_WIDTH               =>  9                           
                                )
                            port map(
                                CLKA                     => CLK_CPU                    , 
                                ENA                      => LUT_ENA_IN(I)(J)           , 
                                WEA                      => LUT_WREN_IN(I)(J)          , 
                                ADDRA                    => lut_waddr(I)(8 downto 0)   ,
                                DATAA                    => LUT_WDATA_IN(I)            ,
                            
                                CLKB                     => CLK_DPD                    ,
                                ENB                      => '1'                        ,
                                ADDRB                    => lut_raddr(I)(J)(8 downto 0),
                                DATAB                    => lut_rdata(I)(J)       
                                );
                        end generate;

                        G_nth_LUT : if (J > 0) generate begin
                            U_nth_LUT : SIMPLE_DPRAM_DUALCLK
                            generic map(
                                RAM_STYLE                => "BLOCK"                    , 
                                RAM_INIT_VALUE           =>  0                         , 
                            
                                DATA_WIDTH               => 32                         , 
                                ADDR_WIDTH               =>  9                          
                                )
                            port map(
                                CLKA                     => CLK_CPU                    , 
                                ENA                      => LUT_ENA_IN(I)(J)           , 
                                WEA                      => LUT_WREN_IN(I)(J)          , 
                                ADDRA                    => lut_waddr(I)(8 downto 0)   ,
                                DATAA                    => LUT_WDATA_IN(I)            ,
                            
                                CLKB                     => CLK_DPD                    ,
                                ENB                      => '1'                        ,
                                ADDRB                    => lut_raddr(I)(J)(8 downto 0),
                                DATAB                    => lut_rdata(I)(J)       
                                );
                        end generate;

                    end generate;

                    G_LUT_Rdata_Clocking_Normal_Operation : if (HS_MODE = FALSE) generate begin
                        P_LUT_Rdata_Clocking_NM : process(RST_DPD, CLK_DPD) begin
                            if (RST_DPD = '1') then
                                lut_rdata_d1(I)(J) <= (others => '0');
                            elsif (CLK_DPD'event) and (CLK_DPD = '1') then
                                lut_rdata_d1(I)(J) <= lut_rdata(I)(J);
                            end if;
                        end process;
                    end generate;

                    G_LUT_Rdata_Clocking_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                        P_LUT_Rdata_Clocking_HS : process(CLK_DPD) begin
                            if (CLK_DPD'event) and (CLK_DPD = '1') then
                                lut_rdata_d1(I)(J) <= lut_rdata(I)(J);
                            end if;
                        end process;
                    end generate;

                    U_LUT_IQ_DLY : SRL16E_DLY generic map (DEVICE, HS_MODE, 32, HOVS) port map (CLK_DPD, lut_rdata_d1(I)(J), lut_rdata_dly(I)(J));

                end generate;
            end generate;

        end generate;

    end generate;

    G_LUT_Optimized : if (LUT_OPTIMIZED = TRUE) generate begin

        G_LUT_Non_OPD_TX_GEN : for I in 0 to (TX_ANT_NUM) generate begin
            G_LUT_Depth : for J in 0 to (LUT_RAM_NUM-1) generate begin
                U_LUT_RADDR_DLY : SRL16E_DLY generic map(DEVICE, HS_MODE, 9, HOVS) port map (CLK_DPD, LUT_RADDR_IN(I)(J), lut_raddr_dly(I)(J));

                G_LUT_Memory_Full_Depth : if (LUT_MEM_DEPTH = "FULL") generate begin
                    G_1st_LUT : if (J = 0) generate begin
                        U_1st_LUT : SIMPLE_DPRAM_DUALCLK 
                        generic map(
                            RAM_STYLE      => "BLOCK"                , 
                            RAM_INIT_VALUE => lut0_init_value        , 
                                                                     
                            DATA_WIDTH     => 32                     , 
                            ADDR_WIDTH     =>  9                       
                            )
                        port map(
                            CLKA           => CLK_CPU                , 
                            ENA            => LUT_ENA_IN(I)(J)       , 
                            WEA            => LUT_WREN_IN(I)(J)      , 
                            ADDRA          => LUT_WADDR_IN(I)        , 
                            DATAA          => LUT_WDATA_IN(I)        , 
                        
                            CLKB           => CLK_DPD                ,
                            ENB            => '1'                    ,
                            ADDRB          => lut_raddr_dly(I)(J)    ,
                            DATAB          => lut_rdata(I)(J)         
                            );

                    end generate;

                    G_nth_LUT : if (J > 0) generate begin
                        U_1st_LUT : SIMPLE_DPRAM_DUALCLK 
                        generic map(
                            RAM_STYLE      => "BLOCK"                , 
                            RAM_INIT_VALUE =>  0                     , 
                                                                     
                            DATA_WIDTH     => 32                     , 
                            ADDR_WIDTH     =>  9                       
                            )
                        port map(
                            CLKA           => CLK_CPU                , 
                            ENA            => LUT_ENA_IN(I)(J)       , 
                            WEA            => LUT_WREN_IN(I)(J)      , 
                            ADDRA          => LUT_WADDR_IN(I)        , 
                            DATAA          => LUT_WDATA_IN(I)        , 
                        
                            CLKB           => CLK_DPD                ,
                            ENB            => '1'                    ,
                            ADDRB          => lut_raddr_dly(I)(J)    ,
                            DATAB          => lut_rdata(I)(J)         
                            );

                    end generate;
                end generate;

                G_LUT_Memory_Half_Depth : if (LUT_MEM_DEPTH = "HALF") generate begin
                    G_1st_LUT : if (J = 0) generate begin
                        U_1st_LUT : SIMPLE_DPRAM_DUALCLK 
                        generic map(
                            RAM_STYLE      => "BLOCK"                        , 
                            RAM_INIT_VALUE => lut0_init_value                , 
                                                                             
                            DATA_WIDTH     => 32                             , 
                            ADDR_WIDTH     =>  8                               
                            )
                        port map(
                            CLKA           => CLK_CPU                        , 
                            ENA            => LUT_ENA_IN(I)(J)               , 
                            WEA            => LUT_WREN_IN(I)(J)              , 
                            ADDRA          => LUT_WADDR_IN(I)(7 downto 0)    , 
                            DATAA          => LUT_WDATA_IN(I)                , 
                        
                            CLKB           => CLK_DPD                        ,
                            ENB            => '1'                            ,
                            ADDRB          => lut_raddr_dly(I)(J)(7 downto 0),
                            DATAB          => lut_rdata(I)(J)         
                            );

                    end generate;

                    G_nth_LUT : if (J > 0) generate begin
                        U_1st_LUT : SIMPLE_DPRAM_DUALCLK 
                        generic map(
                            RAM_STYLE      => "BLOCK"                        , 
                            RAM_INIT_VALUE =>  0                             , 
                                                                             
                            DATA_WIDTH     => 32                             , 
                            ADDR_WIDTH     =>  8                       
                            )
                        port map(
                            CLKA           => CLK_CPU                        , 
                            ENA            => LUT_ENA_IN(I)(J)               , 
                            WEA            => LUT_WREN_IN(I)(J)              , 
                            ADDRA          => LUT_WADDR_IN(I)(7 downto 0)    , 
                            DATAA          => LUT_WDATA_IN(I)                , 
                        
                            CLKB           => CLK_DPD                        ,
                            ENB            => '1'                            ,
                            ADDRB          => lut_raddr_dly(I)(J)(7 downto 0),
                            DATAB          => lut_rdata(I)(J)         
                            );

                    end generate;
                end generate;

                G_LUT_Rdata_Clocking_Normal_Operation : if (HS_MODE = FALSE) generate begin
                    P_LUT_Rdata_Clocking_NM : process(RST_DPD, CLK_DPD) begin
                        if (RST_DPD = '1') then
                            lut_rdata_d1(I)(J) <= (others => '0');
                        elsif (CLK_DPD'event) and (CLK_DPD = '1') then
                            lut_rdata_d1(I)(J) <= lut_rdata(I)(J);
                        end if;
                    end process;
                end generate;

                G_LUT_Rdata_Clocking_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
                    P_LUT_Rdata_Clocking_HS : process(CLK_DPD) begin
                        if (CLK_DPD'event) and (CLK_DPD = '1') then
                            lut_rdata_d1(I)(J) <= lut_rdata(I)(J);
                        end if;
                    end process;
                end generate;

                G_LUT_ReadBack_Test_EN : if (LUT_RBTEST = TRUE) generate begin 
                    LUT_RBDATA_OUT(I)(J) <= lut_rdata(I)(J);
                end generate;

                G_LUT_ReadBack_Test_Disable : if (LUT_RBTEST = FALSE) generate begin 
                    LUT_RBDATA_OUT(I)(J) <= (others => '0');
                end generate;

                U_LUT_IQ_DLY : SRL16E_DLY generic map (DEVICE, HS_MODE, 32, HOVS) port map (CLK_DPD, lut_rdata_d1(I)(J), lut_rdata_dly(I)(J));

            end generate;
        end generate;

        lut_switch_sh <= (others => (others => '0'));

        lut_waddr     <= (others => (others => '0'));
        lut_raddr     <= (others => (others => (others => '0')));
    end generate;

    LUT_RDATA_OUT <= lut_rdata_dly;

end arc_DPD_LUT10_RAM_SET;

