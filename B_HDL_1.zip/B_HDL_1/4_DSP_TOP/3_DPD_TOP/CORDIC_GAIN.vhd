library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;

-- Latency : 7 Clock
entity CORDIC_GAIN is
generic(
    HS_MODE            : boolean :=  TRUE  -- High Speed Mode (Operating Clock > 307.2MHz)
    );
port(
    RST                : in  std_logic;
    CLK                : in  std_logic; 

    MAGNITUDE_IN       : in  std_logic_vector(18 downto 0); 
    MAGNITUDE_GAIN_OUT : out std_logic_vector(15 downto 0)
    );
end CORDIC_GAIN;

architecture arc_CORDIC_GAIN of CORDIC_GAIN is

-- Latency 3 Clocks
component SAT_UNSIGN is
generic(
    HS_MODE            : boolean :=  TRUE;  -- High Speed Mode (Operating Clock > 307.2MHz)
    INPUT_BIT          : natural;
    OUTPUT_BIT         : natural
    );
port( 
    RST                : in  std_logic;
    CLK                : in  std_logic;
    DATA_IN            : in  std_logic_vector( INPUT_BIT-1 downto 0);
    DATA_OUT           : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

signal mag_se28           : std_logic_vector(27 downto 0);
signal acc_256_minus_1    : std_logic_vector(27 downto 0);
signal acc_64_minus_8     : std_logic_vector(27 downto 0);
signal compensated_sum_28 : std_logic_vector(27 downto 0);
signal compensated_mag_19 : std_logic_vector(18 downto 0);
signal compensated_sat_17 : std_logic_vector(16 downto 0);
signal magnitude_gain     : std_logic_vector(15 downto 0);

begin

-- Cordic Gain Compensation --
-- The gain correction module multiplies the magnitude estimate by (311/512) = 0.607 to
-- compensate for the CORDIC gain of -1.647. The multiply is implemented using a canonical
-- sign digit approach (shifts and adds) based on the fact that 311 = 256 + 64 - 8 - 1.


    -- Input Magnitude + 9 Bit Extend --------
    
    G_Normal_Operation : if (HS_MODE = FALSE) generate begin
        -- 1st Clock
        P_Sign_Extention_NM : process(RST, CLK) begin
            if (RST = '1') then
                mag_se28 <= (others => '0');           
            elsif (CLK'event) and (CLK = '1') then
                mag_se28 <= MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN;           
            end if;
        end process;

        -- MAGNITUDE*2^8 - MAGNITUDE 
        -- MAGNITUDE*2^8 - MAGNITUDE*2^3 
        -- 2nd Clock 
        P_Stage1_NM : process(RST, CLK) begin
            if (RST = '1') then
                acc_256_minus_1 <= (others => '0');
                acc_64_minus_8  <= (others => '0');   
            elsif (CLK'event) and (CLK = '1') then
                acc_256_minus_1 <=  mag_se28(19 downto 0) & "00000000" -  mag_se28;                       -- MAGNITUDE*(256 - 1)
                acc_64_minus_8  <= (mag_se28(21 downto 0) & "000000")  - (mag_se28(24 downto 0) & "000"); -- MAGNITUDE*(64 - 8)  
            end if;
        end process;
        
        -- compensated_sum_28 =  MAGNITUDE*2^8 - MAGNITUDE + MAGNITUDE*2^8 - MAGNITUDE*2^3 
        -- 3rd Clock
        P_Stage2_NM : process(RST, CLK) begin
            if (RST = '1') then
                compensated_sum_28 <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                compensated_sum_28 <= acc_256_minus_1 + acc_64_minus_8; 
            end if;
        end process;

        ---- compensated_sum_28 / 512 
        -- 4th Clock
        P_Stage3_NM : process(RST, CLK) begin
            if (RST = '1') then
                compensated_mag_19 <= (others => '0'); 
            elsif (CLK'event) and (CLK = '1') then
                compensated_mag_19 <= compensated_sum_28(27 downto 9); --compensated_sum = MAGNITUDE/1.64568891575725
            end if;
        end process;
        
        -- 16 bits saturation only positive area in 2's complement region.
        -- Latency 3
        U_UNSIGNED_SAT_NM : SAT_UNSIGN generic map(HS_MODE, 19, 17) port map(RST, CLK, compensated_mag_19, compensated_sat_17);
        
        -- 8th Clock
        P_Output_Assgin_NM : process(RST, CLK) begin
            if (RST = '1') then
                magnitude_gain <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                magnitude_gain <= compensated_sat_17(15 downto 0);
            end if;
        end process;
    end generate;

    G_High_Speed_Mode : if (HS_MODE = TRUE) generate begin
        -- 1st Clock 
        P_Sign_Extention_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                mag_se28 <= MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN(18)&MAGNITUDE_IN;           
            end if;
        end process;

        -- MAGNITUDE*2^8 - MAGNITUDE 
        -- MAGNITUDE*2^8 - MAGNITUDE*2^3 
        -- 2nd Clock 
        P_Stage1_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                acc_256_minus_1 <=  mag_se28(19 downto 0) & "00000000" -  mag_se28;                       -- MAGNITUDE*(256 - 1)
                acc_64_minus_8  <= (mag_se28(21 downto 0) & "000000")  - (mag_se28(24 downto 0) & "000"); -- MAGNITUDE*(64 - 8)  
            end if;
        end process;
        
        -- compensated_sum_28 =  MAGNITUDE*2^8 - MAGNITUDE + MAGNITUDE*2^8 - MAGNITUDE*2^3 
        -- 3rd Clock
        P_Stage2_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                compensated_sum_28 <= acc_256_minus_1 + acc_64_minus_8; 
            end if;
        end process;

        ---- compensated_sum_28 / 512 
        -- 4th Clock
        P_Stage3_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                compensated_mag_19 <= compensated_sum_28(27 downto 9); --compensated_sum = MAGNITUDE/1.64568891575725
            end if;
        end process;
        
        -- 16 bits saturation only positive area in 2's complement region.
        -- Latency 3
        U_UNSIGNED_SAT_HS : SAT_UNSIGN generic map(HS_MODE, 19, 17) port map(RST, CLK, compensated_mag_19, compensated_sat_17);
        
        -- 8th Clock
        P_Output_Assgin_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                magnitude_gain <= compensated_sat_17(15 downto 0);
            end if;
        end process;
    end generate;

    MAGNITUDE_GAIN_OUT <= magnitude_gain;

end arc_CORDIC_GAIN;

