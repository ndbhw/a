--Half-band interpolation filter with passband 80M
--27tap,
--HOVS1 ONLY
--Processing delay : 122.88Msps -> 245.76Msps - 23 clk @ 245.76Msps

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity hbf_i_comm is
generic(
    HOVS                        : integer
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    INPUT_FRAME                 : in  std_logic;
    INPUT_VALID                 : in  std_logic;
    INPUT_DATA_I                : in  std_logic_vector(15 downto 0);
    INPUT_DATA_Q                : in  std_logic_vector(15 downto 0);

    OUTPUT_FRAME                : out std_logic;
    OUTPUT_VALID                : out std_logic;
    OUTPUT_DATA_I               : out std_logic_vector(15 downto 0);
    OUTPUT_DATA_Q               : out std_logic_vector(15 downto 0)
);
end hbf_i_comm;

architecture Behavioral of hbf_i_comm is

component RST_SYNC is
generic(
    DLY_NUM                     : natural := 3;    -- Number of delay.
    MAX_FANOUT_NUM              : integer := 200   -- Number of maximum fanout
    );
port(
    RST_IN                      : in  std_logic;   -- Active high asynchronous reset
    CLK                         : in  std_logic;   -- clock to be sync'ed to
    RST_OUT                     : out std_logic    -- "Synchronised" reset signal
    );         
end component;

component pim_ser is
generic(
    CHANNEL_NUMBER              : integer := 20;
    HOVS                        : integer := 20;
    WIDTH_IN                    : integer := 16
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN*CHANNEL_NUMBER-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

component fir_i_comm is
generic (
    VENDOR                      : string:="XILINX";
    HOVS                        : integer;
    ORDER                       : integer;

    CHANNEL_NUMBERS             : integer;

    WIDTH_IN                    : integer:=16;
    WIDTH_COEFF                 : integer:=16;
    WIDTH_OUT                   : integer:=16;
    WIDTH_RESULT                : integer:=34;
    BINARY_POINT                : integer:=15
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT_0                : out std_logic_vector(WIDTH_OUT-1  downto 0);
    FILTER_OUT_1                : out std_logic_vector(WIDTH_OUT-1  downto 0)
);
end component;


constant CHANNEL_NUMBERS        : integer := 2;
--constant HOVS                   : integer := 1;
constant ORDER                  : integer := 14;

constant WIDTH_IN               : integer:=16;
constant WIDTH_COEFF            : integer:=16;
constant WIDTH_OUT              : integer:=16;
constant WIDTH_RESULT           : integer:=34;
constant BINARY_POINT           : integer:=14;

signal rst_synch                : std_logic;

signal data_parallel            : std_logic_vector(WIDTH_IN*CHANNEL_NUMBERS-1 downto 0);

signal frame_serial             : std_logic;
signal valid_serial             : std_logic;
signal data_serial              : std_logic_vector(WIDTH_IN-1 downto 0);

signal fir_frame                : std_logic;
signal fir_valid                : std_logic;
signal fir_data0                : std_logic_vector(WIDTH_OUT-1 downto 0);
signal fir_data1                : std_logic_vector(WIDTH_OUT-1 downto 0);

signal fir_frame_cnt            : std_logic_vector(1 downto 0);
signal fir_data0_sh             : std_logic_array16(2 downto 0);


begin

    U_RST_SYNC : RST_SYNC generic map(4, 200) port map(RST, CLK, rst_synch);

    data_parallel <= INPUT_DATA_Q & INPUT_DATA_I;

    -- parallel to serial conversion
    u_dduc_ser : pim_ser
    generic map(
        CHANNEL_NUMBER              => CHANNEL_NUMBERS              ,--: integer := 20;
        HOVS                        => HOVS                         ,--: integer := 20;
        WIDTH_IN                    => WIDTH_IN                      --: integer := 16
    )
    port map(
        RST                         => rst_synch                    ,--: in  std_logic;
        CLK                         => CLK                          ,--: in  std_logic;

        FRAME_I                     => INPUT_FRAME                  ,--: in  std_logic;
        VALID_I                     => INPUT_VALID                  ,--: in  std_logic;
        FILTER_IN                   => data_parallel                ,--: in  std_logic_vector(WIDTH_IN*CHANNEL_NUMBER-1 downto 0);

        FRAME_O                     => frame_serial                 ,--: out std_logic;
        VALID_O                     => valid_serial                 ,--: out std_logic;
        FILTER_OUT                  => data_serial                   --: out std_logic_vector(WIDTH_IN-1 downto 0)
    );

    -- x2 interpolation FIR filter
    u_fir_i_comm : fir_i_comm
    generic map(
        VENDOR                      => "XILINX",
        HOVS                        => HOVS,
        ORDER                       => ORDER,

        CHANNEL_NUMBERS             => CHANNEL_NUMBERS,

        WIDTH_IN                    => WIDTH_IN    ,
        WIDTH_OUT                   => WIDTH_COEFF ,
        WIDTH_COEFF                 => WIDTH_OUT   ,
        WIDTH_RESULT                => WIDTH_RESULT,
        BINARY_POINT                => BINARY_POINT
    )
    port map(
        RST                         => rst_synch,
        CLK                         => CLK,

        FRAME_I                     => frame_serial,
        VALID_I                     => valid_serial,
        FILTER_IN                   => data_serial,

        FRAME_O                     => fir_frame,
        VALID_O                     => fir_valid,
        FILTER_OUT_0                => fir_data0,
        FILTER_OUT_1                => fir_data1
    );

g_HOVS1 : if HOVS=1 generate
    fir_frame_cnt <= (others=> '0');
    fir_data0_sh  <= (others=>(others=>'0'));

    OUTPUT_FRAME  <= fir_frame;
    OUTPUT_VALID  <= fir_valid;
    OUTPUT_DATA_I <= fir_data0;
    OUTPUT_DATA_Q <= fir_data1;
end generate;

g_HOVS2 : if HOVS=2 generate
    process(rst_synch, CLK)
    begin
        if rst_synch='1' then
            fir_frame_cnt <= (others=> '0');
            fir_data0_sh  <= (others=>(others=>'0'));
            OUTPUT_FRAME  <= '0';
            OUTPUT_VALID  <= '0';
            OUTPUT_DATA_I <= (others=> '0');
            OUTPUT_DATA_Q <= (others=> '0');
        elsif CLK'event and CLK='1' then
            if fir_frame='1' then
                fir_frame_cnt <= (others=>'0');
            else
                fir_frame_cnt <= fir_frame_cnt + '1';
            end if;

            fir_data0_sh  <= fir_data0_sh(1 downto 0) & fir_data0;

            if fir_frame_cnt(0)='1' then
                if fir_frame_cnt(1)='0' then
                    OUTPUT_FRAME  <= '1';
                    OUTPUT_DATA_I <= fir_data0_sh(1);
                    OUTPUT_DATA_Q <= fir_data0;
                else
                    OUTPUT_FRAME  <= '0';
                    OUTPUT_DATA_I <= fir_data0_sh(2);
                    OUTPUT_DATA_Q <= fir_data0_sh(0);
                end if;
                OUTPUT_VALID  <= '1';
            else
                OUTPUT_FRAME  <= '0';
                OUTPUT_VALID  <= '0';
            end if;
        end if;
    end process;
end generate;


end Behavioral;
