Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

Library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity CMULT_FUNC is
generic(
    DEVICE                      : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    OPTIMIZATION                : string  :=        "DSP"; -- "DSP" : 3 DSPs, 3 Adders, 2 PreAdders, "LUT" : 4 DSPs, 2 Adders, HOVS1 Only
    HOVS                        : natural :=           1 ;
    
    RND_EN                      : boolean :=        TRUE ;
    RND_BIT                     : natural :=          15 ;

    INPUT_PIPELINING            : boolean :=        TRUE ;
    IN_A_BITWIDTH               : natural :=          16 ;  -- (same : max ~18, diff: max ~27 when "DSP")
    IN_B_BITWIDTH               : natural :=          16 ;  -- (same : max ~18, diff: max ~18 when "DSP")
    OUT_BITWIDTH                : natural :=          16
    );
port(
    CLK                         : in  std_logic;
    
    DATA_VLD_IN                 : in  std_logic;
    ADATA_I_IN                  : in  std_logic_vector(IN_A_BITWIDTH-1 downto 0);
    ADATA_Q_IN                  : in  std_logic_vector(IN_A_BITWIDTH-1 downto 0);

    BDATA_I_IN                  : in  std_logic_vector(IN_B_BITWIDTH-1 downto 0);
    BDATA_Q_IN                  : in  std_logic_vector(IN_B_BITWIDTH-1 downto 0);

    DATA_VLD_OUT                : out std_logic;
    DATA_I_OUT                  : out std_logic_vector(OUT_BITWIDTH+RND_BIT-1 downto RND_BIT);
    DATA_Q_OUT                  : out std_logic_vector(OUT_BITWIDTH+RND_BIT-1 downto RND_BIT)
    );
end CMULT_FUNC;

architecture arc_CMULT_FUNC of CMULT_FUNC is

constant LUT_DSP_OPT            : integer := ternary_func(OPTIMIZATION = "DSP", 1, 0);
constant INPUT_PIPELINING_OPT   : integer := ternary_func(INPUT_PIPELINING = TRUE, 1, 0);
constant PIPELINING_DLY         : integer := LUT_DSP_OPT * INPUT_PIPELINING_OPT;

component DSP48E_MULT is
generic(
    DEVICE                      : string  := "ULTRASCALE";
    DSP48_MODECTRL              : boolean :=       FALSE ;
    DSP48_PREADDER_USE          : boolean :=        TRUE ;
    DSP48_PREADDER_MODE         : string  :=        "ADD";  -- "ADD" or "SUB" 
    DSP48_PCIN_USE              : boolean :=       FALSE ;
    DSP48_PCOUT_USE             : boolean :=       FALSE ;

    A_nREG                      : integer :=           2 ;  -- 0, 1, 2
    B_nREG                      : integer :=           2 ;  -- 0, 1, 2

    C_EN                        : boolean :=        TRUE ;
    RND_SYMMETRY                : boolean :=       FALSE 
    );
port(
    CLK                         : in  std_logic;

    ALUMODE_IN                  : in  std_logic_vector( 3 downto 0);
    OPMODE_IN                   : in  std_logic_vector( 8 downto 0);

    C_IN                        : in  std_logic_vector(47 downto 0);
    A_IN                        : in  std_logic_vector(29 downto 0);
    D_IN                        : in  std_logic_vector(26 downto 0);
    B_IN                        : in  std_logic_vector(17 downto 0);

    P_CIN                       : in  std_logic_vector(47 downto 0);
    P_COUT                      : out std_logic_vector(47 downto 0);

    P_OUT                       : out std_logic_vector(47 downto 0);
    CRRY_OUT                    : out std_logic
    );
end component;

component SRL_DLY is
generic(
    HS_MODE   : boolean := FALSE; 

    BIT_WIDTH                   : natural;
    DELAY_NUM                   : natural
    );
port(
    CLK                         : in  std_logic;
    
    DATA_IN                     : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_COUT                   : out std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT                    : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end component;

constant zeros                  : std_logic_vector(47 downto 0) := (others => '0');

signal rnd_qpoint               : std_logic_vector(47 downto 0);

signal a_i                      : std_logic_vector(IN_A_BITWIDTH-1 downto 0) := (others => '0');
signal a_q                      : std_logic_vector(IN_A_BITWIDTH-1 downto 0) := (others => '0');
                                                               
signal b_i                      : std_logic_vector(IN_B_BITWIDTH-1 downto 0) := (others => '0');
signal b_q                      : std_logic_vector(IN_B_BITWIDTH-1 downto 0) := (others => '0');

signal se30_a_i                 : std_logic_vector(29 downto 0) := (others => '0');
signal se27_a_i                 : std_logic_vector(26 downto 0) := (others => '0');
signal se18_a_i                 : std_logic_vector(17 downto 0) := (others => '0');
signal se30_a_q                 : std_logic_vector(29 downto 0) := (others => '0');
signal se27_a_q                 : std_logic_vector(26 downto 0) := (others => '0');

signal se30_b_i                 : std_logic_vector(29 downto 0) := (others => '0');
signal se18_b_i                 : std_logic_vector(17 downto 0) := (others => '0');
signal se27_b_q                 : std_logic_vector(26 downto 0) := (others => '0');
signal se18_b_q                 : std_logic_vector(17 downto 0) := (others => '0');

signal p                        : std_logic_vector(47 downto 0) := (others => '0');
signal m                        : std_logic_vector(47 downto 0) := (others => '0');
signal n                        : std_logic_vector(47 downto 0) := (others => '0');

signal ai_bi                    : std_logic_vector(47 downto 0) := (others => '0');
signal aq_bq                    : std_logic_vector(47 downto 0) := (others => '0');
signal ai_bq                    : std_logic_vector(47 downto 0) := (others => '0');
signal aq_bi                    : std_logic_vector(47 downto 0) := (others => '0');


signal ai_align                 : std_logic_vector(15 downto 0) := (others => '0');
signal aq_align                 : std_logic_vector(15 downto 0) := (others => '0');

signal bi_align                 : std_logic_vector(15 downto 0) := (others => '0');
signal bq_align                 : std_logic_vector(15 downto 0) := (others => '0');

signal a_iq                     : std_logic_vector(15 downto 0) := (others => '0');
signal b_iq                     : std_logic_vector(15 downto 0) := (others => '0');
signal b_qi                     : std_logic_vector(15 downto 0) := (others => '0');

signal se_a_iq                  : std_logic_vector(29 downto 0) := (others => '0');
signal se_b_iq                  : std_logic_vector(17 downto 0) := (others => '0');
signal se_b_qi                  : std_logic_vector(17 downto 0) := (others => '0');

signal alumode_i                : std_logic_vector( 3 downto 0) := (others => '0');
signal alumode_q                : std_logic_vector( 3 downto 0) := (others => '0');
signal opmode                   : std_logic_vector( 8 downto 0) := (others => '0');

signal i_acmbd                  : std_logic_vector(47 downto 0) := (others => '0'); 
signal q_adpbc                  : std_logic_vector(47 downto 0) := (others => '0'); 

signal result_i                 : std_logic_vector(48 downto 0) := (others => '0');
signal result_q                 : std_logic_vector(48 downto 0) := (others => '0');

signal rnd_i                    : std_logic_vector(OUT_BITWIDTH+RND_BIT-1 downto RND_BIT);
signal rnd_q                    : std_logic_vector(OUT_BITWIDTH+RND_BIT-1 downto RND_BIT);

signal data_in_vld              : std_logic_vector( 0 downto 0);
signal data_vld_dly             : std_logic_vector( 0 downto 0);
signal se18_b_iq                : std_logic_vector( 17 downto 0);
signal se19_b_iq                : std_logic_vector( 18 downto 0);
signal se48_cin                 : std_logic_vector( 47 downto 0);
signal se27_cin                 : std_logic_vector( 26 downto 0);
signal se30_a_i_tmp             : std_logic_vector( 29 downto 0);
signal se27_cin_d               : std_logic_vector( 26 downto 0);
signal se31_cin                 : std_logic_vector( 30 downto 0);
signal mux_sel                  : std_logic_vector( 1 downto 0) := "00";

begin

    -- Binary Point 
    G_Qpoint : if (RND_EN = TRUE) generate begin
        G_RND_0bit : if (RND_BIT = 0) generate begin
            rnd_qpoint <= zeros;
        end generate;

        G_RND_1bit : if (RND_BIT = 1) generate begin
            rnd_qpoint <= zeros(47 downto RND_BIT) & '1';
        end generate;

        G_RND_Nbit : if (RND_BIT > 1) generate begin
            rnd_qpoint <= zeros(47 downto RND_BIT) & '1' & zeros(RND_BIT-2 downto 0);
        end generate;
    end generate;

    G_Zero_Qpoint : if (RND_EN = FALSE) generate begin
        rnd_qpoint <= zeros;
    end generate;

    -- *******************************************************************************
    --   HOVS1
    -- *******************************************************************************
    G_HOVS1 : if (HOVS = 1) generate begin
        G_InputPP : if (INPUT_PIPELINING = TRUE) generate begin
            P_A_B_Data_CLKing : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    a_i <= ADATA_I_IN;
                    a_q <= ADATA_Q_IN;
                                     
                    b_i <= BDATA_I_IN;
                    b_q <= BDATA_Q_IN;
                end if;
            end process;
        end generate;

        G_InputAssign : if (INPUT_PIPELINING = FALSE) generate begin
            a_i <= ADATA_I_IN;
            a_q <= ADATA_Q_IN;
                             
            b_i <= BDATA_I_IN;
            b_q <= BDATA_Q_IN;
        end generate;

        -- Sign Extension
        se30_a_i    <= sign_extension(a_i, 30);
                                         
        se30_b_i    <= sign_extension(b_i, 30);
        se18_b_i    <= sign_extension(b_i, 18);
        se27_b_q    <= sign_extension(b_q, 27);
        se18_b_q    <= sign_extension(b_q, 18);

        G_Opt_DSP : if (OPTIMIZATION = "DSP" and (IN_A_BITWIDTH = IN_B_BITWIDTH) ) generate begin                
            -- ************************************************************************
            -- A = Ar*I + Aj*Q
            -- B = Br*I + Bj*Q
            -- A * B = (Ar*I + Aj*Q)*(Br*I + Bj*Q) 
            --             = (Ar*Br-Aj*Bj)*I + (Ar*Bj+Aj*Br)*Q
            --             = [Ar*(Br+Bj) - (Ar+Aj)*Bj]*I + [Ar*(Br+Bj) + (-Ar+Aj)Br)*Q
            --           P = Ar*(Br+Bj)
            --           M = (+Ar+Aj)*Bj
            --           N = (-Ar+Aj)*Br
            -- 
            --           I = P - M
            --           Q = P + N
            -- ************************************************************************
            se18_a_i    <= sign_extension(a_i, 18);
            se27_a_q    <= sign_extension(a_q, 27);
            U_HOVS1_P : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,2,2,RND_EN,FALSE) port map(CLK,x"0",(others=>'0'),rnd_qpoint    ,se30_b_i,se27_b_q,se18_a_i,(others=>'0'),open,p,open);
            U_HOVS1_M : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,2,2,FALSE ,FALSE) port map(CLK,x"0",(others=>'0'),(others =>'0'),se30_a_i,se27_a_q,se18_b_q,(others=>'0'),open,m,open);
            U_HOVS1_N : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"SUB",FALSE,FALSE,2,2,FALSE ,FALSE) port map(CLK,x"0",(others=>'0'),(others =>'0'),se30_a_i,se27_a_q,se18_b_i,(others=>'0'),open,n,open);

            -- I = P - M
            -- Q = P + N
            P_Complex_Calculate : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    result_i <= (p(47)&p)-(m(47)&m);
                    result_q <= (p(47)&p)+(n(47)&n);
                end if;
            end process;
        end generate;
        
        G_Opt_DSP_DIV : if ( OPTIMIZATION = "DSP" and (IN_B_BITWIDTH < 18) and (IN_A_BITWIDTH /= IN_B_BITWIDTH) ) generate begin                
            -- ************************************************************************
            -- A = Ar*I + Aj*Q
            -- B = Br*I + Bj*Q
            -- A * B = (Ar*I + Aj*Q)*(Br*I + Bj*Q) 
            --             = (Ar*Br-Aj*Bj)*I + (Ar*Bj+Aj*Br)*Q
            --             = [Ar*(Br+Bj) - (Ar+Aj)*Bj]*I + [Ar*(Br+Bj) + (-Ar+Aj)Br)*Q
            --           P = Ar*(Br+Bj)
            --           M = (+Ar+Aj)*Bj
            --           N = (-Ar+Aj)*Br
            -- 
            --           I = P - M
            --           Q = P + N
            -- ************************************************************************
            se27_a_q    <= sign_extension(a_q, 27);
            se18_b_iq   <= se18_b_q + se18_b_i;
            U_HOVS1_P : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,2,2,RND_EN,FALSE) port map(CLK,x"0",(others=>'0'),rnd_qpoint    ,se30_a_i,(others=>'0'),se18_b_iq,(others=>'0'),open,p,open);
            U_HOVS1_M : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,2,2,FALSE ,FALSE) port map(CLK,x"0",(others=>'0'),(others =>'0'),se30_a_i,se27_a_q,se18_b_q,(others=>'0'),open,m,open);
            U_HOVS1_N : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"SUB",FALSE,FALSE,2,2,FALSE ,FALSE) port map(CLK,x"0",(others=>'0'),(others =>'0'),se30_a_i,se27_a_q,se18_b_i,(others=>'0'),open,n,open);

            -- I = P - M
            -- Q = P + N
            P_Complex_Calculate : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    result_i <= (p(47)&p)-(m(47)&m);
                    result_q <= (p(47)&p)+(n(47)&n);
                end if;
            end process;
        end generate;

        G_Opt_DSP_DIV_18 : if ( OPTIMIZATION = "DSP" and (IN_B_BITWIDTH = 18) and (IN_A_BITWIDTH /= IN_B_BITWIDTH) ) generate begin                
            -- only for 18bit-B-data input 
            se27_a_i        <= sign_extension(a_i, 27);
            se30_a_i_tmp    <= sign_extension(se27_a_i, 30);
            se27_a_q        <= sign_extension(a_q, 27);
            se19_b_iq       <= (se18_b_q(17)&se18_b_q) + (se18_b_i(17)&se18_b_i);
            se18_b_iq       <= se19_b_iq(18)&se19_b_iq(16 downto 0);
            mux_sel         <=  se19_b_iq(18 downto 17);
            se27_cin        <= (others=>'0')           when (mux_sel = "00") else
                               se27_a_i                when (mux_sel = "01") else
                               ( (not se27_a_i) +'1')  when (mux_sel = "10") else
                               (others=>'0');
            
            U_PCIN_DLY : SRL_DLY generic map(TRUE, 27, 3) port map(CLK, se27_cin, open, se27_cin_d);
            se31_cin   <= sign_extension(se27_cin_d, 31);
            se48_cin   <= se31_cin & (x"0000"&'0');

            U_HOVS1_P : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD", TRUE,FALSE,2,2,RND_EN,FALSE) port map(CLK,x"0",(others=>'0'),rnd_qpoint    ,se30_a_i_tmp,(others=>'0'),se18_b_iq,se48_cin,open,p,open);
            U_HOVS1_M : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"ADD",FALSE,FALSE,2,2,FALSE ,FALSE) port map(CLK,x"0",(others=>'0'),(others =>'0'),se30_a_i_tmp,se27_a_q,se18_b_q,(others=>'0'),open,m,open);
            U_HOVS1_N : DSP48E_MULT generic map(DEVICE,FALSE,TRUE,"SUB",FALSE,FALSE,2,2,FALSE ,FALSE) port map(CLK,x"0",(others=>'0'),(others =>'0'),se30_a_i_tmp,se27_a_q,se18_b_i,(others=>'0'),open,n,open);

            -- I = P - M
            -- Q = P + N
            P_Complex_Calculate : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    result_i <= (p(47)&p)-(m(47)&m);
                    result_q <= (p(47)&p)+(n(47)&n);
                end if;
            end process;
        end generate;

        G_Opt_LUT : if (OPTIMIZATION = "LUT") generate begin                

            -- Sign Extension
            se30_a_i    <= sign_extension(a_i, 30);
            se30_a_q    <= sign_extension(a_q, 30);
                                             
            se18_b_i    <= sign_extension(b_i, 18);
            se18_b_q    <= sign_extension(b_q, 18);

            -- ************************************************************************
            -- A = Ar*I + Aj*Q
            -- B = Br*I + Bj*Q
            -- A * B = (Ar*I + Aj*Q)*(Br*I + Bj*Q) 
            --             = (Ar*Br-Aj*Bj)*I + (Ar*Bj+Aj*Br)*Q
            -- 
            --           I = Ar*Br-Aj*Bj
            --           Q = Ar*Bj+Aj*Br
            -- ************************************************************************

            U_HOVS1_ArBr : DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",FALSE,FALSE,2,2,RND_EN,FALSE) port map(CLK,x"0",(others=>'0'),rnd_qpoint   ,se30_a_i,(others=>'0'),se18_b_i,(others=>'0'),open,ai_bi,open);
            U_HOVS1_AjBj : DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",FALSE,FALSE,2,2,FALSE ,FALSE) port map(CLK,x"0",(others=>'0'),(others=>'0'),se30_a_q,(others=>'0'),se18_b_q,(others=>'0'),open,aq_bq,open);

            U_HOVS1_ArBj : DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",FALSE,FALSE,2,2,RND_EN,FALSE) port map(CLK,x"0",(others=>'0'),rnd_qpoint   ,se30_a_i,(others=>'0'),se18_b_q,(others=>'0'),open,ai_bq,open);
            U_HOVS1_AjBr : DSP48E_MULT generic map(DEVICE,FALSE,FALSE,"ADD",FALSE,FALSE,2,2,FALSE ,FALSE) port map(CLK,x"0",(others=>'0'),(others=>'0'),se30_a_q,(others=>'0'),se18_b_i,(others=>'0'),open,aq_bi,open);

            -- I = Ar*Br-Aj*Bj
            -- Q = Ar*Bj+Aj*Br
            P_Complex_Calculate : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    result_i <= (ai_bi(47)&ai_bi)-(aq_bq(47)&aq_bq);
                    result_q <= (ai_bq(47)&ai_bq)+(aq_bi(47)&aq_bi);
                end if;
            end process;
        end generate;

    end generate;

    -- *******************************************************************************
    --   HOVS2
    -- *******************************************************************************
    G_HOVS2 : if (HOVS = 2) generate begin

        P_Input_Align : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (DATA_VLD_IN = '1') then            
                    ai_align <= ADATA_I_IN;
                    aq_align <= ADATA_Q_IN;
                                          
                    bi_align <= BDATA_I_IN;
                    bq_align <= BDATA_Q_IN;
               end if;
            end if;
        end process;

        P_IQ_Time_MUX : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (DATA_VLD_IN = '0') then
                    a_iq <= ai_align;
                    b_iq <= bi_align;
                    b_qi <= bq_align;
                else
                    a_iq <= aq_align;
                    b_iq <= bq_align;
                    b_qi <= bi_align;
                end if;
            end if;
        end process;

        se_a_iq  <= sign_extension(a_iq, 30); 
        se_b_iq  <= sign_extension(b_iq, 18); 
        se_b_qi  <= sign_extension(b_qi, 18); 

        P_DSP48_Time_CTRL : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                alumode_q <= "0000";

                if (DATA_VLD_IN = '0') then
                    alumode_i <= "0000"; -- A*B
                    opmode    <= "000110101"; -- Rounding, RND_IN Calculation
                else
                    alumode_i <= "0011"; -- P-A*B
                    opmode    <= "000100101"; -- Internal P Calculation
                end if;
            end if;
        end process;

        U_DSP48E_HOVS2_I : DSP48E_MULT generic map(DEVICE,TRUE,FALSE,"ADD",FALSE,FALSE,2,2,RND_EN,FALSE) port map(CLK,alumode_i,opmode,rnd_qpoint,se_a_iq,(others=>'0'),se_b_iq,(others=>'0'),open,i_acmbd,open); --(A_i*B_i)-(A_q*B_q)+RND
        U_DSP48E_HOVS2_Q : DSP48E_MULT generic map(DEVICE,TRUE,FALSE,"ADD",FALSE,FALSE,2,2,RND_EN,FALSE) port map(CLK,alumode_q,opmode,rnd_qpoint,se_a_iq,(others=>'0'),se_b_qi,(others=>'0'),open,q_adpbc,open); --(A_i*B_q)-(A_q*B_i)+RND

        P_Result_Align : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (DATA_VLD_IN = '0') then
                    result_i <= i_acmbd(47) & i_acmbd;
                    result_q <= q_adpbc(47) & q_adpbc;
                end if;
            end if;
        end process;
    end generate;

    P_RND : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            rnd_i <= result_i(OUT_BITWIDTH+RND_BIT-1 downto RND_BIT);
            rnd_q <= result_q(OUT_BITWIDTH+RND_BIT-1 downto RND_BIT);
        end if;
    end process;

    -- *******************************************************************************
    --  Data Valid Delay : Latency Compensation
    -- *******************************************************************************
    data_in_vld(0) <= DATA_VLD_IN;

    G_DLY_COMP_HOVS1 : if (HOVS = 1) generate begin
        U_DLY_COMP : SRL_DLY generic map(TRUE, 1, PIPELINING_DLY+6) port map(CLK, data_in_vld, open, data_vld_dly);
    end generate;

    G_DLY_COMP_HOVS2 : if (HOVS = 2) generate begin
        U_DLY_COMP : SRL_DLY generic map(TRUE, 1, 9) port map(CLK, data_in_vld, open, data_vld_dly);
    end generate;

    DATA_VLD_OUT <= data_vld_dly(0);    
    DATA_I_OUT   <= rnd_i;
    DATA_Q_OUT   <= rnd_q;

end arc_CMULT_FUNC;
