library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity fir_i_comm is
generic (
    VENDOR                      : string:="XILINX";
    HOVS                        : integer;
    ORDER                       : integer;

    CHANNEL_NUMBERS             : integer;

    WIDTH_IN                    : integer:=16;
    WIDTH_COEFF                 : integer:=16;
    WIDTH_OUT                   : integer:=16;
    WIDTH_RESULT                : integer:=34;
    BINARY_POINT                : integer:=15
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT_0                : out std_logic_vector(WIDTH_OUT-1  downto 0);
    FILTER_OUT_1                : out std_logic_vector(WIDTH_OUT-1  downto 0)
);
end fir_i_comm;

architecture rtl of fir_i_comm is

component dduc_delay_chain is
generic(
    BUFF_DEPTH                  : natural:= 16;-- SRL16E
    DIRECTION                   : natural:= 1; -- 1:forward, 0:reverse
    WIDTH_IN                    : natural:= 16 -- Input data width
);
port(
    CLK                         : in  std_logic;
    DATA_SEL                    : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

component dduc_dsp is
generic(
    PCIN_EN                     : boolean := FALSE;
    D_EN                        : boolean := FALSE;
    C_EN                        : boolean := FALSE;

    WIDTH_A                     : integer := 16;
    WIDTH_D                     : integer := 16;
    WIDTH_B                     : integer := 16;
    WIDTH_C                     : integer := 16;
    WIDTH_PCIN                  : integer := 48;
    WIDTH_PCOUT                 : integer := 48;
    WIDTH_P                     : integer := 48
);
port(
    CLK                         : in  std_logic;

    SEL                         : in  std_logic;
    CEP                         : in  std_logic;
    DSP_A_INV                   : in  std_logic;

    DSP_A                       : in  std_logic_vector(WIDTH_A-1 downto 0);
    DSP_D                       : in  std_logic_vector(WIDTH_D-1 downto 0);
    DSP_B                       : in  std_logic_vector(WIDTH_B-1 downto 0);
    DSP_C                       : in  std_logic_vector(WIDTH_C-1 downto 0);

    DSP_PCIN                    : in  std_logic_vector(WIDTH_PCIN-1 downto 0);
    DSP_PCOUT                   : out std_logic_vector(WIDTH_PCOUT-1 downto 0);
    DSP_P                       : out std_logic_vector(WIDTH_P-1 downto 0)
);
end component;

constant DSP_MULT_NUM           : integer := 1; -- Number of multiplier per DSP resource
constant DSP_INSTANCES          : integer := ORDER/(2*DSP_MULT_NUM*HOVS)+ternary_func(ORDER mod (2*DSP_MULT_NUM*HOVS) = 0 , 0, 1);-- /2 for symmetric
constant DELAY_MEM_DEPTH        : integer := CHANNEL_NUMBERS*HOVS*2;-- *2 for waddr/raddr collision avoid
constant DELAY_MEM_NUM          : integer := ORDER/HOVS+ternary_func(ORDER mod HOVS = 0 , 0, 1);
constant DSP_INPUT_NUM          : integer := 2*DSP_INSTANCES;-- each DSP has 2 data input
constant DSP_COEF_NUM           : integer := HOVS;-- each multiplier has HOVS coefficient set
constant VDSP                   : integer := 4;-- DSP Valid latency(3) + DSP48 in register(2) - 1 (for DSP input registering)
constant PROC_DELAY             : integer := 4+(HOVS-1)+2;-- DSP latency(4) + (HOVS) CLK(final accumulated data + 1) + DSP48 in(2) register delay
constant WIDTH_DSP              : integer := 48;
constant WIDTH_BINARY           : integer := BINARY_POINT+2;-- +1 for signed bit
constant CENTER_VALID_CNT       : integer := ternary_func((ORDER/2) mod HOVS = 0, HOVS, (ORDER/2) mod HOVS);
--CENTER_CLK_DLY = DSP latency(4) + 1(DSP in)+(HOVS-1, depend on filter structure )+1(next to filter output)
constant CENTER_CLK_DLY         : integer := 6+ternary_func(DSP_INSTANCES=1, 0, HOVS-1);
constant CENTER_SAMPLE_DLY      : integer := ternary_func(DSP_INSTANCES=1, 1, DSP_INSTANCES-1);-- reverse path sample delay
--constant COEFF                  : integer_array(ORDER/2-1 downto 0) :=
--                                ternary_func(ORDER = DUC_FILTER_ORDER_HBF0 , DUC_FIRHB_COEFF_HBF0,
--                                ternary_func(ORDER = DUC_FILTER_ORDER_HBF1 , DUC_FIRHB_COEFF_HBF1, DUC_FIRHB_COEFF_HBF2));
constant COEFF                  : integer_array(ORDER/2-1 downto 0) := (20503,-5942,2674,-1214,491,-158,33);

type data_array                 is array(natural range <>) of std_logic_vector(WIDTH_IN-1 downto 0);
type coef_array                 is array(natural range <>) of std_logic_vector(WIDTH_COEFF-1 downto 0);
type chain_array                is array(natural range <>) of std_logic_vector(WIDTH_DSP-1 downto 0);
type binary_array               is array(natural range <>) of std_logic_vector(WIDTH_BINARY-1 downto 0);
type hovs_array                 is array(natural range <>) of std_logic_vector(ternary_func(HOVS=1, 1, log2(HOVS))-1 downto 0);
type delay_sel_array            is array(natural range <>) of std_logic_vector(log2(DELAY_MEM_DEPTH)-1 downto 0);
type delay_sel_hovs_array       is array(natural range <>) of delay_sel_array(HOVS-1 downto 0);
type coeff_array                is array(natural range <>) of integer_array(DSP_COEF_NUM-1 downto 0);

signal frame_o_d                : std_logic_vector(PROC_DELAY-1 downto 0);
signal valid_o_d                : std_logic_vector(PROC_DELAY-1 downto 0);
signal valid_dsp_i              : std_logic;

signal ovs                      : hovs_array(DSP_INSTANCES-1 downto 0);

signal delay_data_valid         : std_logic_vector(DELAY_MEM_NUM-1 downto 0);
signal delay_data_sel           : delay_sel_array(DELAY_MEM_NUM-1 downto 0);
signal delay_data_in            : data_array(DELAY_MEM_NUM-1 downto 0);
signal delay_data_out           : data_array(DELAY_MEM_NUM-1 downto 0);
signal dsp_data_in              : data_array(DSP_INPUT_NUM-1 downto 0);

signal sel                      : std_logic;
signal dsp_a                    : data_array(DSP_INSTANCES-1 downto 0);
signal dsp_d                    : data_array(DSP_INSTANCES-1 downto 0);
signal dsp_b                    : coef_array(DSP_INSTANCES-1 downto 0);
signal dsp_c                    : binary_array(DSP_INSTANCES-1 downto 0);
signal dsp_pcin                 : chain_array(DSP_INSTANCES-1 downto 0);
signal dsp_pcout                : chain_array(DSP_INSTANCES-1 downto 0);
signal dsp_p                    : chain_array(DSP_INSTANCES-1 downto 0);

signal result                   : std_logic_vector(WIDTH_RESULT-1 downto 0);

signal valid_center             : std_logic;
signal data_center              : std_logic_vector(WIDTH_IN-1 downto 0);
signal center_delay_comp        : std_logic_vector(WIDTH_IN-1 downto 0);
signal delay_data               : std_logic_vector(WIDTH_IN-1 downto 0);

signal is_even                  : std_logic;
signal i_filter_out_odd         : std_logic_vector(WIDTH_OUT-1 downto 0);
signal i_filter_out_odd_d       : std_logic_vector(WIDTH_OUT-1 downto 0);
signal i_filter_out_even        : std_logic_vector(WIDTH_OUT-1 downto 0);
signal i_frame_o_d              : std_logic;
signal i_frame_o_dd             : std_logic;

signal i_frame_o                : std_logic;
signal i_valid_o                : std_logic;
signal i_filter_out             : std_logic_vector(WIDTH_OUT-1 downto 0);

signal i_valid_o_d              : std_logic;
signal i_filter_out_d           : std_logic_vector(WIDTH_OUT-1 downto 0);

attribute KEEP                  : string;
attribute KEEP                  of ovs : signal is "TRUE";

-- Coefficient mapping function for DSP internal coefficient rom data
function coeff_init return coeff_array is
    variable result : coeff_array(DSP_MULT_NUM*DSP_INSTANCES-1 downto 0);
begin
    DSP_loop: for N in 0 to DSP_MULT_NUM*DSP_INSTANCES-1 loop-- each DSP has 2 coeff. set
        COEF_Loop: for M in 0 to DSP_COEF_NUM-1 loop
--            if HOVS*N+M < ORDER/2 then
            if M < HOVS then                        -- only #HOVS coefficients are valid
                if HOVS*N+M < ORDER/2 then          -- first, place coefficients in DSP, forward
                    result(N)(M) := COEFF(HOVS*N+M);
                else                                -- if last DSP has invalid HOVS cycle, fill it as symmetric HOVS cycle, reverse
                    result(N)(M) := COEFF((ORDER/2-1)-((HOVS*N+M) mod (ORDER/2)));
                end if;
            else
                result(N)(M) := 0;
            end if;
        end loop;
    end loop;
    return result;
end function coeff_init;

constant DSP_COEFF              : coeff_array(DSP_MULT_NUM*DSP_INSTANCES-1 downto 0) := coeff_init;

-- HOVS address mapping function for DSP internal coefficient rom data
function data_sel_init return delay_sel_hovs_array is
    variable result : delay_sel_hovs_array(DELAY_MEM_NUM-1 downto 0);
begin
    MEM_LOOP : for M in 0 to DELAY_MEM_NUM-1 loop
        HOVS_LOOP : for H in 0 to HOVS-1 loop
            if H = 0 then
                if M = 0  then
                    result(M)(H) :=  std_logic_vector(to_unsigned(1-1                       , log2(DELAY_MEM_DEPTH)));-- first delay chain, -1 for zero indexing (0)
                elsif M <= (DELAY_MEM_NUM-1)/2 and M /= DELAY_MEM_NUM-1 then-- if #mem is 2, no compensation, go to (H*C)
                    result(M)(H) :=  std_logic_vector(to_unsigned(CHANNEL_NUMBERS-1-1       , log2(DELAY_MEM_DEPTH)));-- forward path 1st (C-1)
                elsif M = DELAY_MEM_NUM/2 then
                    result(M)(H) :=  std_logic_vector(to_unsigned(CHANNEL_NUMBERS*HOVS-1    , log2(DELAY_MEM_DEPTH)));-- center delay (H*C)
                else
                    result(M)(H) :=  std_logic_vector(to_unsigned(CHANNEL_NUMBERS*HOVS+1-1  , log2(DELAY_MEM_DEPTH)));-- reverse path 1st (H*C+1)
                end if;
            else
                if M <= (DELAY_MEM_NUM-1)/2 then
                    result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))+CHANNEL_NUMBERS , log2(DELAY_MEM_DEPTH)));-- forward path 2nd (+C)
                elsif M = DELAY_MEM_NUM/2 then
                    result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))-CHANNEL_NUMBERS , log2(DELAY_MEM_DEPTH)));-- reverse path 2nd (-C)
                else
                    if (DELAY_MEM_NUM mod 2 = 0) and (H = 1) then -- +1 CLK compensation (valid_o_d(0)), careful!!!
                        result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))-CHANNEL_NUMBERS+1, log2(DELAY_MEM_DEPTH)));-- reverse path (-C)
                    else
                        result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))-CHANNEL_NUMBERS  , log2(DELAY_MEM_DEPTH)));-- reverse path (-C)
                    end if;
                end if;
            end if;
        end loop;
    end loop;
    return result;
end function data_sel_init;

constant DELAY_HOVS_SEL         : delay_sel_hovs_array(DELAY_MEM_NUM-1 downto 0) := data_sel_init;

begin

    -- Input delay
    process(CLK,RST)
    begin
        if RST='1' then
            frame_o_d   <= (others=> '0');
            valid_o_d   <= (others=> '0');
            valid_dsp_i <= '0';
        elsif CLK'event and CLK='1' then
            frame_o_d   <= frame_o_d(PROC_DELAY-2 downto 0) & FRAME_I;
            valid_o_d   <= valid_o_d(PROC_DELAY-2 downto 0) & VALID_I;
            valid_dsp_i <= or_reduce(valid_o_d(VDSP-1+(HOVS-1) downto VDSP-1));
        end if;
    end process;

    -- HOVS selection
    process(CLK,RST)
    begin
        if RST='1' then
            sel <= '0';
        elsif CLK'event and CLK='1' then
            -- DSP opcode selection
            if HOVS = 1 then
                sel <= '0';
            elsif valid_o_d(2) = '1' then                                          -- only 1 cycle for adding PCIN, +2 CLK after DSP input data
                sel <= '0';
            elsif or_reduce(valid_o_d(VDSP-1+(HOVS-2) downto VDSP-1)) = '1' then-- Valid dsp - 1 CLK cycle (HOVS cycle - 1)
                sel <= '1';
            else
                sel <= '0';
            end if;
        end if;
    end process;

    DELAY_GEN : for N in 0 to DELAY_MEM_NUM-1 generate
    begin
        DELAY_GEN_0 : if N = 0 generate
        begin
            delay_data_valid(N) <= VALID_I;-- write first data
            delay_data_in(N)    <= FILTER_IN;
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS)));
        end generate DELAY_GEN_0;
        DELAY_GEN_1 : if N > 0 and N <= DELAY_MEM_NUM/2-1 and N /= DELAY_MEM_NUM-1 generate
        begin
            delay_data_valid(N) <= valid_o_d(HOVS-1);-- write only (HOVS)th data
            delay_data_in(N)    <= delay_data_out(N-1);
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS)));
        end generate DELAY_GEN_1;
        DELAY_GEN_N2 : if N = DELAY_MEM_NUM/2 generate-- #N/2
        begin
            delay_data_valid(N) <= valid_o_d(HOVS-1);-- write only (HOVS)th data
            delay_data_in(N)    <= delay_data_out(N-1);
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS/2)));-- /2 : # of delay mem/2 = # of DSP
        end generate DELAY_GEN_N2;
        DELAY_GEN_N2P1 : if N = DELAY_MEM_NUM/2+1 generate-- #N/2+1
        begin
            -- if #mem is odd, first reverse mem should latch HOVSth data
            delay_data_valid(N) <= ternary_func(DELAY_MEM_NUM mod 2 = 0, valid_o_d(0), valid_o_d(HOVS-1));
            delay_data_in(N)    <= delay_data_out(N-1);
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS/2)));-- /2 : # of delay mem/2 = # of DSP
        end generate DELAY_GEN_N2P1;
        DELAY_GEN_N : if N > DELAY_MEM_NUM/2+1 and N <= DELAY_MEM_NUM-1 generate
        begin
            delay_data_valid(N) <= valid_o_d(0);-- reverse mem should latch only 1st data
            delay_data_in(N)    <= delay_data_out(N-1);
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS/2)));-- /2 : # of delay mem/2 = # of DSP
        end generate DELAY_GEN_N;

    u_dduc_delay_chain : dduc_delay_chain
    generic map(
        BUFF_DEPTH                  => DELAY_MEM_DEPTH              ,--: natural:= 16;-- SRL16E
        DIRECTION                   => ternary_func(N <= DELAY_MEM_NUM/2, 1, 0),--: natural:= 1: -- 1:forward, 0:reverse
        WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
    )
    port map(
        CLK                         => CLK                        ,--: in  std_logic;
        DATA_SEL                    => delay_data_sel(N)            ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
        VALID_I                     => delay_data_valid(N)          ,--: in  std_logic;
        FILTER_IN                   => delay_data_in(N)             ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
        FILTER_OUT                  => delay_data_out(N)             --: out std_logic_vector(WIDTH_IN-1 downto 0)
    );
    end generate DELAY_GEN;

    -- DSP input data generation
    DSP_IN_DATA_GEN : for N in 0  to DSP_INPUT_NUM-1  generate
        -- number of valid data = filter order
        DSP_DATA_VALID_GEN : if N <= DELAY_MEM_NUM-1 generate
            -- Even path
            DSP_DATA_GEN_EVEN : if N mod 2 = 0 generate
                dsp_data_in(N) <= delay_data_out(N/2);
            end generate DSP_DATA_GEN_EVEN;
            -- Odd path
            DSP_DATA_GEN_ODD : if N mod 2 = 1 generate
                dsp_data_in(N) <= delay_data_out((DELAY_MEM_NUM-1)-N/2);
            end generate DSP_DATA_GEN_ODD;
        end generate DSP_DATA_VALID_GEN;
        -- mask zero to invalid DSP input
        DSP_DATA_INVALID_GEN : if N > DELAY_MEM_NUM-1 generate
            dsp_data_in(N) <= (others => '0');
        end generate DSP_DATA_INVALID_GEN;
    end generate DSP_IN_DATA_GEN;

    DSP_BLOCK_GEN : for N in 0  to DSP_INSTANCES-1  generate
    begin
        -- HOVS selection, each DSP use seperated ovs signal for performance
        process(CLK,RST)
        begin
            if RST='1' then
                ovs(N)  <= (others=> '0');
            elsif CLK'event and CLK='1' then
                if HOVS = 1  then
                    ovs(N)  <= (others=> '0');
                elsif VALID_I = '1' then
                    ovs(N)  <= (others=> '0');
                elsif or_reduce(valid_o_d(HOVS-2 downto 0)) = '1' then
                    ovs(N)  <= ovs(N) + '1';
                end if;
            end if;
        end process;

        -- DSP Input(A/D/B) registering
        process(CLK,RST)
        begin
            if RST = '1' then
                dsp_a(N) <= (others => '0');
                dsp_d(N) <= (others => '0');
                dsp_b(N) <= (others => '0');
            elsif CLK'event and CLK='1' then
                dsp_a(N) <= dsp_data_in(2*N);
                dsp_d(N) <= dsp_data_in(2*N+1);
                dsp_b(N) <= sign_extension(DSP_COEFF(N)(conv_integer(ovs(N))),WIDTH_COEFF);
            end if;
        end process;

        -- DSP #0 Signal Generation
        DSP_SIG_GEN_0 : if N = 0 generate
            DSP_INS_1 : if DSP_INSTANCES = 1 generate
                dsp_c(N)    <= sign_extension(2**(BINARY_POINT), WIDTH_BINARY);
                dsp_pcin(N) <= (others => '0');
            end generate DSP_INS_1;
            DSP_INS_N : if DSP_INSTANCES > 1 generate
                dsp_c(N)    <= (others => '0');
                dsp_pcin(N) <= dsp_pcout(N+1);
            end generate DSP_INS_N;
        end generate DSP_SIG_GEN_0;

        DSP_SIG_GEN_N : if N > 0 and N < DSP_INSTANCES-1 generate
            dsp_c(N)    <= (others => '0');
            dsp_pcin(N) <= dsp_pcout(N+1);
        end generate DSP_SIG_GEN_N;

        DSP_SIG_GEN_LAST : if N > 0 and N = DSP_INSTANCES-1 generate
            dsp_c(N)    <= sign_extension(2**(BINARY_POINT), WIDTH_BINARY);
            dsp_pcin(N) <= (others => '0');
        end generate DSP_SIG_GEN_LAST;

       u_dduc_dsp : dduc_dsp
        generic map(
            PCIN_EN                     => ternary_func(N=DSP_INSTANCES-1,FALSE,TRUE) ,--: boolean := FALSE;
            D_EN                        => TRUE                         ,--: boolean := FALSE;
            C_EN                        => ternary_func(N=DSP_INSTANCES-1,TRUE,FALSE) ,--: boolean := FALSE;

            WIDTH_A                     => WIDTH_IN                     ,--: integer := 16;
            WIDTH_D                     => WIDTH_IN                     ,--: integer := 16;
            WIDTH_B                     => WIDTH_COEFF                  ,--: integer := 16;
            WIDTH_C                     => WIDTH_BINARY                 ,--: integer := 16;
            WIDTH_PCIN                  => WIDTH_DSP                    ,--: integer := 48;
            WIDTH_PCOUT                 => WIDTH_DSP                    ,--: integer := 48;
            WIDTH_P                     => WIDTH_DSP                     --: integer := 48
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;

            SEL                         => sel                          ,--: in  std_logic;
            CEP                         => valid_dsp_i                  ,--: in  std_logic;
            DSP_A_INV                   => '0'                          ,--: in  std_logic;

            DSP_A                       => dsp_a(N)                     ,--: in  std_logic_vector(WIDTH_A-1 downto 0);
            DSP_D                       => dsp_d(N)                     ,--: in  std_logic_vector(WIDTH_D-1 downto 0);
            DSP_B                       => dsp_b(N)                     ,--: in  std_logic_vector(WIDTH_B-1 downto 0);
            DSP_C                       => dsp_c(N)                     ,--: in  std_logic_vector(WIDTH_C-1 downto 0);

            DSP_PCIN                    => dsp_pcin(N)                  ,--: in  std_logic_vector(WIDTH_PCIN-1 downto 0);
            DSP_PCOUT                   => dsp_pcout(N)                 ,--: out std_logic_vector(WIDTH_PCOUT-1 downto 0);
            DSP_P                       => dsp_p(N)                      --: out std_logic_vector(WIDTH_P-1 downto 0)
        );
    end generate DSP_BLOCK_GEN;

    i_frame_o    <= frame_o_d(PROC_DELAY-1);
    i_valid_o    <= valid_o_d(PROC_DELAY-1);
    i_filter_out <= dsp_p(0)(WIDTH_OUT+BINARY_POINT downto BINARY_POINT+1);

    -- center tap sample delay, no RST for using LUT resource, delay compensation
    -- HOVS/2 th sample will be center tap sample, compensation delay for (C-1)
--    valid_center <= ternary_func(DELAY_MEM_NUM mod 2 = 0, VALID_I, valid_o_d(CENTER_VALID_CNT-1));
    valid_center <= valid_o_d(HOVS-1);
    data_center  <= delay_data_out((DELAY_MEM_NUM-1)/2);

    CENTER_DLY_COMP_1 :if DSP_INSTANCES = 1 generate
        center_delay_comp <= data_center when valid_center = '1' else (others => '0');
    end generate CENTER_DLY_COMP_1;

    CENTER_DLY_COMP_2 :if DSP_INSTANCES = 2 generate
        process(CLK)
        begin
            if CLK'event and CLK='1' then
                if valid_center = '1' then
                    center_delay_comp <= data_center;
                end if;
            end if;
        end process;
    end generate CENTER_DLY_COMP_2;

    CENTER_DLY_COMP_N :if DSP_INSTANCES > 2 generate
        u_center_dly_comp : dduc_delay_chain
        generic map(
            BUFF_DEPTH                  => CENTER_SAMPLE_DLY            ,--: natural:= 16;-- SRL16E
            DIRECTION                   => 0                            ,--: natural:= 1: -- 1:forward, 0:reverse
            WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
        )
        port map(
            CLK                         => CLK                        ,--: in  std_logic;
            DATA_SEL                    => std_logic_vector(to_unsigned(CENTER_SAMPLE_DLY-1, log2(CENTER_SAMPLE_DLY))),
            VALID_I                     => valid_center                 ,--: in  std_logic;
            FILTER_IN                   => data_center                  ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
            FILTER_OUT                  => center_delay_comp             --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );
    end generate CENTER_DLY_COMP_N;

    -- center tap CLK delay, no RST for using LUT resource
    u_center_clk_dly_comp : dduc_delay_chain
    generic map(
        BUFF_DEPTH                  => CENTER_CLK_DLY               ,--: natural:= 16;-- SRL16E
        DIRECTION                   => 0                            ,--: natural:= 1: -- 1:forward, 0:reverse
        WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
    )
    port map(
        CLK                         => CLK                        ,--: in  std_logic;
        DATA_SEL                    => std_logic_vector(to_unsigned(CENTER_CLK_DLY-1, log2(CENTER_CLK_DLY))),
        VALID_I                     => '1'                          ,--: in  std_logic;
        FILTER_IN                   => center_delay_comp            ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
        FILTER_OUT                  => delay_data                    --: out std_logic_vector(WIDTH_IN-1 downto 0)
    );

    -- If HOVS = 1, all output #0/1 port should be used
    OUT_GEN_HOVS_1 :if HOVS = 1 generate
        process(CLK,RST)
        begin
            if RST='1' then
                is_even <= '0';
            elsif CLK'event and CLK='1' then
                if i_frame_o = '1' then
                    is_even <= '1';
                else
                    is_even <= not is_even;
                end if;
            end if;
        end process;

        -- Output conversion : Apostrophe(') means center tap sample
        -- i_filter_out : I(CH0) , Q(CH1) , I(CH2) , Q(CH3) , ...
        -- delay_data   : I(CH0)', Q(CH1)', I(CH2)', Q(CH3)', ...
        -- FILTER_OUT_0 : I(CH0) , I(CH0)', I(CH2) , I(CH2)', ...
        -- FILTER_OUT_1 : Q(CH1) , Q(CH1)', Q(CH3) , Q(CH3)', ...
        FILTER_OUT_0 <= i_filter_out_odd_d;
        FILTER_OUT_1 <= i_filter_out_even;
        process(CLK,RST)
        begin
            if RST='1' then
                i_filter_out_odd  <= (others => '0');
                i_filter_out_odd_d<= (others => '0');
                i_filter_out_even <= (others => '0');
            elsif CLK'event and CLK='1' then
                if is_even = '0' then         -- 1st : filter output
                    i_filter_out_odd <= i_filter_out;
                    i_filter_out_even<= delay_data;
                else
                    i_filter_out_odd <= delay_data;
                    i_filter_out_even<= i_filter_out;
                end if;
                i_filter_out_odd_d<= i_filter_out_odd;
            end if;
        end process;

        -- output
        FRAME_O <= i_frame_o_dd;
        VALID_O <= '1';
        process(CLK,RST)
        begin
            if RST='1' then
                i_frame_o_d  <= '0';
                i_frame_o_dd <= '0';
            elsif CLK'event and CLK='1' then
                i_frame_o_d  <= i_frame_o;
                i_frame_o_dd <= i_frame_o_d;
            end if;
        end process;
    end generate OUT_GEN_HOVS_1;

    -- If HOVS >= 2, output #0 port is enough
    OUT_GEN_HOVS_N :if HOVS >= 2 generate
        process(CLK,RST)
        begin
            if RST='1' then
                i_valid_o_d     <= '0';
                i_filter_out_d  <= (others => '0');
            elsif CLK'event and CLK='1' then
                i_valid_o_d     <= i_valid_o;
                if i_valid_o = '1' then         -- 1st : filter output
                    i_filter_out_d <= i_filter_out;
                elsif i_valid_o_d = '1' then    -- 2nd : delay output
                    i_filter_out_d <= delay_data;
                else
                    i_filter_out_d <= (others => '0');
                end if;
            end if;
        end process;

        -- output
        process(CLK,RST)
        begin
            if RST='1' then
                FRAME_O    <= '0';
                VALID_O    <= '0';
            elsif CLK'event and CLK='1' then
                FRAME_O    <= i_frame_o;
                VALID_O    <= (i_valid_o or i_valid_o_d);
            end if;
        end process;
        FILTER_OUT_0 <= i_filter_out_d;
        FILTER_OUT_1 <= (others => '0');
    end generate OUT_GEN_HOVS_N;


end rtl;

