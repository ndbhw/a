-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name : FBSW_CTRL 

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity FBSW_CTRL is
generic(    
    TX_ANT_NUM                : natural :=      4  ;
    FB_PATH_NUM               : natural :=      2  ;
    RX_ANT_NUM                : natural :=      4  ;
    SC_HOVS                   : natural :=      1  ;

    DPD_PATH_PHASE            : string  :=  "MONO" ; -- "MONO" or "POLY"
    PIM_IMPLEMENTATION        : boolean :=   TRUE  ; -- R ?.?.? PIM 
    PIMD_BLK_TYPE             : string  := "INTER" ; -- "INTER" or "INTRA"

    FB_ATTEN_IMPLEMENTATION   : boolean :=   TRUE  ; -- TRUE : Using FB_ATTEN, FALSE : FB_ATTEN not implemented
    SC_IMPLEMENTATION         : boolean :=   TRUE    -- TRUE : Using SC      , FALSE : SC       not implemented
    );
port(
    RST                       : in  std_logic;                                -- Active high
    CLK                       : in  std_logic; 
    
    FBSW_CNT_IN               : in  std_logic_vector( 4 downto 0);            -- Feedback Switch Counter
    FB_VC_OUT                 : out std_logic_vector( 4 downto 0);

    FBSW_START_TRIG_IN        : in  std_logic;
    FBSW_START_RPLS_OUT       : out std_logic;

    FBSW_SC_PATH_SEL_IN       : in  std_logic_vector( 4 downto 0);

    AUTO_MODE_DONE_IN         : in  std_logic_vector( FB_PATH_NUM-1 downto 0);

    FB_VLD_IN                 : in  std_logic_vector( FB_PATH_NUM-1 downto 0);
    FB_MONO_I_IN              : in  std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_MONO_Q_IN              : in  std_logic_array16(FB_PATH_NUM-1 downto 0);

    FB_MONO_NCO_I_IN          : in  std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_MONO_NCO_Q_IN          : in  std_logic_array16(FB_PATH_NUM-1 downto 0);

    FB_POLY_EVEN_I_IN         : in  std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_POLY_EVEN_Q_IN         : in  std_logic_array16(FB_PATH_NUM-1 downto 0);

    FB_POLY_ODD_I_IN          : in  std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_POLY_ODD_Q_IN          : in  std_logic_array16(FB_PATH_NUM-1 downto 0);

    FB_VLD_OUT                : out std_logic_vector( FB_PATH_NUM-1 downto 0);
    FB_MONO_I_OUT             : out std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_MONO_Q_OUT             : out std_logic_array16(FB_PATH_NUM-1 downto 0);

    FB_POLY_EVEN_I_OUT        : out std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_POLY_EVEN_Q_OUT        : out std_logic_array16(FB_PATH_NUM-1 downto 0);

    FB_POLY_ODD_I_OUT         : out std_logic_array16(FB_PATH_NUM-1 downto 0);
    FB_POLY_ODD_Q_OUT         : out std_logic_array16(FB_PATH_NUM-1 downto 0);

    -- For PATH_DGATT
    FB_FWD_DGATT_VALUE_IN     : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    FB_RVS_DGATT_VALUE_IN     : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    FB_DGATT_OUT              : out std_logic_array16(FB_PATH_NUM-1 downto 0);

    -- For FB_LOOPBACK 
    SC_LOOPBACK_ON_IN         : in  std_logic;                                -- Loopback Enable for Smart Capture Test, Test Only

    DL_DACIF_MONO_I_IN        : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    DL_DACIF_MONO_Q_IN        : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    DL_DACIF_POLY_EVEN_I_IN   : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    DL_DACIF_POLY_EVEN_Q_IN   : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    DL_DACIF_POLY_ODD_I_IN    : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    DL_DACIF_POLY_ODD_Q_IN    : in  std_logic_array16(TX_ANT_NUM-1 downto 0);

    -- For SC
    SC_DPDFB_PIM_MODE_SEL_IN  : in  std_logic;

    DL_CFR_MONO_I_IN          : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_CFR_MONO_Q_IN          : in  std_logic_array16( TX_ANT_NUM-1 downto 0);

    DL_CFR_POLY_EVEN_I_IN     : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_CFR_POLY_EVEN_Q_IN     : in  std_logic_array16( TX_ANT_NUM-1 downto 0);

    DL_CFR_POLY_ODD_I_IN      : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_CFR_POLY_ODD_Q_IN      : in  std_logic_array16( TX_ANT_NUM-1 downto 0);


    DL_DPD_MONO_I_IN          : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_DPD_MONO_Q_IN          : in  std_logic_array16( TX_ANT_NUM-1 downto 0);

    DL_DPD_POLY_EVEN_I_IN     : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_DPD_POLY_EVEN_Q_IN     : in  std_logic_array16( TX_ANT_NUM-1 downto 0);

    DL_DPD_POLY_ODD_I_IN      : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_DPD_POLY_ODD_Q_IN      : in  std_logic_array16( TX_ANT_NUM-1 downto 0);


    DL_FB_ATT_MONO_I_IN       : in  std_logic_array16(FB_PATH_NUM-1 downto 0);  -- user rf2239
    DL_FB_ATT_MONO_Q_IN       : in  std_logic_array16(FB_PATH_NUM-1 downto 0);  -- user rf2239

    DL_FB_ATT_POLY_EVEN_I_IN  : in  std_logic_array16(FB_PATH_NUM-1 downto 0);
    DL_FB_ATT_POLY_EVEN_Q_IN  : in  std_logic_array16(FB_PATH_NUM-1 downto 0);

    DL_FB_ATT_POLY_ODD_I_IN   : in  std_logic_array16(FB_PATH_NUM-1 downto 0);
    DL_FB_ATT_POLY_ODD_Q_IN   : in  std_logic_array16(FB_PATH_NUM-1 downto 0);


    DL_PIM_3RD_IM_MIXER_I_IN  : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_PIM_3RD_IM_MIXER_Q_IN  : in  std_logic_array16( TX_ANT_NUM-1 downto 0);

    UL_PIM_ERROR_I_IN         : in  std_logic_array16( RX_ANT_NUM-1 downto 0);
    UL_PIM_ERROR_Q_IN         : in  std_logic_array16( RX_ANT_NUM-1 downto 0);

    UL_PIM_TARGET_I_IN        : in  std_logic_array16( RX_ANT_NUM-1 downto 0);
    UL_PIM_TARGET_Q_IN        : in  std_logic_array16( RX_ANT_NUM-1 downto 0);

    DL_PIM_CFR_I_IN           : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_PIM_CFR_Q_IN           : in  std_logic_array16( TX_ANT_NUM-1 downto 0);

    DL_PIM_INTER_DUC_DLY_I_IN : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DL_PIM_INTER_DUC_DLY_Q_IN : in  std_logic_array16( TX_ANT_NUM-1 downto 0);

    UL_PIM_DBG_I_IN           : in  std_logic_array16( TX_ANT_NUM-1 downto 0); 
    UL_PIM_DBG_Q_IN           : in  std_logic_array16( TX_ANT_NUM-1 downto 0); 

    DBG_PIM_MIXPS_I_IN        : in  std_logic_array16( TX_ANT_NUM-1 downto 0);
    DBG_PIM_MIXPS_Q_IN        : in  std_logic_array16( TX_ANT_NUM-1 downto 0);

    SC_REF_VLD_OUT            : out std_logic;

    SC_REF_I_OUT              : out std_logic_vector(15 downto 0);
    SC_REF_Q_OUT              : out std_logic_vector(15 downto 0);

    SC_DPD_I_OUT              : out std_logic_vector(15 downto 0);
    SC_DPD_Q_OUT              : out std_logic_vector(15 downto 0);

    SC_FB_I_OUT               : out std_logic_vector(15 downto 0);
    SC_FB_Q_OUT               : out std_logic_vector(15 downto 0);

    SC_PIM_SRC0_I_OUT         : out std_logic_vector(15 downto 0);
    SC_PIM_SRC0_Q_OUT         : out std_logic_vector(15 downto 0);

    SC_PIM_SRC1_I_OUT         : out std_logic_vector(15 downto 0);
    SC_PIM_SRC1_Q_OUT         : out std_logic_vector(15 downto 0);

    SC_PIM_DBG_I_OUT          : out std_logic_vector(15 downto 0);
    SC_PIM_DBG_Q_OUT          : out std_logic_vector(15 downto 0)

    );
end FBSW_CTRL;

architecture arc_FBSW_CTRL of FBSW_CTRL is

component RST_SYNC is
generic(
    DLY_NUM                   : natural := 3;    -- Number of delay.
    MAX_FANOUT_NUM            : integer := 200   -- Number of maximum fanout
    );
port(
    RST_IN                    : in  std_logic;   -- Active high asynchronous reset
    CLK                       : in  std_logic;   -- clock to be sync'ed to
    RST_OUT                   : out std_logic    -- "Synchronised" reset signal
    );         
end component;

signal rst_synch              : std_logic;

signal fbsw_start_sh          : std_logic_vector(2 downto 0);
signal fbsw_start_rpls        : std_logic;

signal fbsw_cnt_d1            : std_logic_vector( 4 downto 0);
-- signal fbsw_cnt_l             : std_logic_vector( 4 downto 0);
-- signal fbsw_cnt_h             : std_logic_vector( 1 downto 0);
-- signal fbsw_cnt               : std_logic_vector( 6 downto 0);
-- signal fbsw_80ms_pls          : std_logic;
-- signal fbsw_80ms_pls_sh       : std_logic_vector(15 downto 0);
-- signal fbsw_round_dn_pls      : std_logic;

signal fbsw_sc_path_sel       : std_logic_vector(3 downto 0);

signal fb_vc                  : std_logic_vector( 3 downto 0);

signal sc_disable             : std_logic;
signal sc_disable_path        : std_logic;
signal sc_disable_time        : std_logic;

signal ssd_disable            : std_logic;

signal sc_lb_on_sh            : std_logic_vector( 2 downto 0);


signal dlfb_lb_mono_i         : std_logic_array16(FB_PATH_NUM-1 downto 0);
signal dlfb_lb_mono_q         : std_logic_array16(FB_PATH_NUM-1 downto 0);

signal dlfb_lb_poly_even_i    : std_logic_array16(FB_PATH_NUM-1 downto 0);
signal dlfb_lb_poly_even_q    : std_logic_array16(FB_PATH_NUM-1 downto 0);

signal dlfb_lb_poly_odd_i     : std_logic_array16(FB_PATH_NUM-1 downto 0);
signal dlfb_lb_poly_odd_q     : std_logic_array16(FB_PATH_NUM-1 downto 0);


signal dpd_cfr_mono_i         : std_logic_vector(15 downto 0);
signal dpd_cfr_mono_q         : std_logic_vector(15 downto 0);

signal dpd_dpd_mono_i         : std_logic_vector(15 downto 0);
signal dpd_dpd_mono_q         : std_logic_vector(15 downto 0);

signal dpd_fb_mono_i          : std_logic_vector(15 downto 0);
signal dpd_fb_mono_q          : std_logic_vector(15 downto 0);

signal dpd_cfr_poly_even_i    : std_logic_vector(15 downto 0);
signal dpd_cfr_poly_even_q    : std_logic_vector(15 downto 0);

signal dpd_cfr_poly_odd_i     : std_logic_vector(15 downto 0);
signal dpd_cfr_poly_odd_q     : std_logic_vector(15 downto 0);

signal dpd_dpd_poly_even_i    : std_logic_vector(15 downto 0);
signal dpd_dpd_poly_even_q    : std_logic_vector(15 downto 0);

signal dpd_dpd_poly_odd_i     : std_logic_vector(15 downto 0);
signal dpd_dpd_poly_odd_q     : std_logic_vector(15 downto 0);

signal dpd_fb_poly_even_i     : std_logic_vector(15 downto 0);
signal dpd_fb_poly_even_q     : std_logic_vector(15 downto 0);

signal dpd_fb_poly_odd_i      : std_logic_vector(15 downto 0);
signal dpd_fb_poly_odd_q      : std_logic_vector(15 downto 0);

signal pim_mixps_i            : std_logic_vector(15 downto 0) := (others => '0');
signal pim_mixps_q            : std_logic_vector(15 downto 0) := (others => '0');


signal dl_pim_3rd_im_mixer_i  : std_logic_vector(15 downto 0);
signal dl_pim_3rd_im_mixer_q  : std_logic_vector(15 downto 0);

signal ul_pim_error_i         : std_logic_vector(15 downto 0);
signal ul_pim_error_q         : std_logic_vector(15 downto 0);

signal ul_pim_target_i        : std_logic_vector(15 downto 0);
signal ul_pim_target_q        : std_logic_vector(15 downto 0);
 
signal dl_pim_cfr_i           : std_logic_vector(15 downto 0);
signal dl_pim_cfr_q           : std_logic_vector(15 downto 0);
 
signal dl_pim_inter_duc_dly_i : std_logic_vector(15 downto 0);
signal dl_pim_inter_duc_dly_q : std_logic_vector(15 downto 0);

signal ul_pim_dbg_i           : std_logic_vector(15 downto 0); 
signal ul_pim_dbg_q           : std_logic_vector(15 downto 0); 

signal sc_pim_mode_sel_sh     : std_logic_vector( 1 downto 0);

signal sc_clk_div_cnt         : std_logic_vector(log2(SC_HOVS) downto 0);
signal sc_ref_vld             : std_logic := '0';
signal sc_ref_vld_d1          : std_logic := '0';


signal sc_ref_i               : std_logic_vector(15 downto 0) := (others=>'0');
signal sc_ref_q               : std_logic_vector(15 downto 0) := (others=>'0');

signal sc_dpd_i               : std_logic_vector(15 downto 0) := (others=>'0');
signal sc_dpd_q               : std_logic_vector(15 downto 0) := (others=>'0');

signal sc_fb_i                : std_logic_vector(15 downto 0) := (others=>'0');
signal sc_fb_q                : std_logic_vector(15 downto 0) := (others=>'0');
                                                                                
signal sc_pim_src0_i          : std_logic_vector(15 downto 0) := (others=>'0');
signal sc_pim_src0_q          : std_logic_vector(15 downto 0) := (others=>'0');

signal sc_pim_src1_i          : std_logic_vector(15 downto 0) := (others=>'0');
signal sc_pim_src1_q          : std_logic_vector(15 downto 0) := (others=>'0');
                                                                                
signal sc_pim_dbg_i           : std_logic_vector(15 downto 0) := (others=>'0');
signal sc_pim_dbg_q           : std_logic_vector(15 downto 0) := (others=>'0');


attribute KEEP : string;
attribute KEEP of fb_vc         : signal is "TRUE";
attribute KEEP of sc_lb_on_sh   : signal is "TRUE";
attribute KEEP of sc_ref_vld_d1 : signal is "TRUE";

attribute MAX_FANOUT : integer;
attribute MAX_FANOUT of fb_vc         : signal is 50;
attribute MAX_FANOUT of sc_lb_on_sh   : signal is 50;
attribute MAX_FANOUT of sc_ref_vld_d1 : signal is 75;


begin

    U_RST_SYNC : RST_SYNC generic map(4, 200) port map(RST, CLK, rst_synch);

    -- *************************************************************************************
    -- Generate FB_VC
    -- *************************************************************************************

    P_FBSW_CNT_Clocking : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            fbsw_cnt_d1 <= FBSW_CNT_IN(4 downto 0);
        end if;
    end process;

    P_FBSW_Start_Pulse : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (fbsw_cnt_d1 = FBSW_CNT_IN(4 downto 0)) then
                fbsw_start_rpls <= '0';
            else
                if (FBSW_CNT_IN(3 downto 0) = x"0") then
                    fbsw_start_rpls <= '1';
                else
                    fbsw_start_rpls <= '0';
                end if;
            end if;
        end if;
    end process;

    P_FBSW_SC_Path_SEL : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (RST = '1') then
                fbsw_sc_path_sel <= (others => '0');
            else
                if (fbsw_start_rpls = '1') then
                    fbsw_sc_path_sel <= FBSW_SC_PATH_SEL_IN(3 downto 0);
                else
                    fbsw_sc_path_sel <= fbsw_sc_path_sel;
                end if;
            end if;
        end if;
    end process;

    P_FB_VC : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            case (FBSW_CNT_IN(3 downto 0)) is
                when x"0"   => fb_vc <= b"0000";               -- PWRMSR FWD A
                when x"1"   => fb_vc <= b"0001";               -- PWRMSR RVS A
                when x"2"   => fb_vc <= fbsw_sc_path_sel;      -- DPD Selection
                when x"3"   => fb_vc <= b"0010";               -- PWRMSR FWD B
                when x"4"   => fb_vc <= b"0011";               -- PWRMSR RVS B
                when x"5"   => fb_vc <= fbsw_sc_path_sel;      -- DPD Selection
                when others => fb_vc <= fb_vc;
            end case;
        end if;
    end process;

    P_SC_Disable : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            case ( FBSW_CNT_IN(3 downto 0) ) is
                when x"2"   => sc_disable <= '0';
                when x"5"   => sc_disable <= '0';
                when others => sc_disable <= '1';
            end case;
        end if;
    end process;
            
    P_SSD_Disable : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            ssd_disable     <= '1';
        end if;
    end process;
    
    -- *************************************************************************************
    -- FB_ATTEN Value Control
    -- *************************************************************************************

    -- FB_VC
    -- 0000  : FWD antenna #A
    -- 0001  : RVS antenna #A
    -- 0010  : FWD antenna #B
    -- 0011  : RVS antenna #B

    G_Using_FB_Atten : if (FB_ATTEN_IMPLEMENTATION = TRUE) generate begin 
        G_DL2_FB1_Path_Atten : if ((TX_ANT_NUM = 2) and (FB_PATH_NUM = 1)) generate begin
            P_FB1_Atten_Ctrl_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    if (rst_synch = '1') then
                        FB_DGATT_OUT(0) <= x"8000";
                    else
                        case (fb_vc(1 downto 0)) is
                            when "00"   => FB_DGATT_OUT(0) <= FB_FWD_DGATT_VALUE_IN(0); -- FWD. A
                            when "01"   => FB_DGATT_OUT(0) <= FB_RVS_DGATT_VALUE_IN(0); -- RVS. A
                            when "10"   => FB_DGATT_OUT(0) <= FB_FWD_DGATT_VALUE_IN(1); -- FWD. B
                            when "11"   => FB_DGATT_OUT(0) <= FB_RVS_DGATT_VALUE_IN(1); -- RVS. B
                            when others => FB_DGATT_OUT(0) <= x"8000";
                        end case;
                    end if;
                end if;
            end process;
        end generate;
    end generate;

    G_Unusing_FB_Atten : if (FB_ATTEN_IMPLEMENTATION = FALSE) generate begin 
        FB_DGATT_OUT <= (others => (others => '0')); 
    end generate;

    -- *************************************************************************************
    -- Switching DL Traffic for DL to FB Loopback 
    -- *************************************************************************************

    P_SC_LB_ON_Double_Clocking_HS : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            sc_lb_on_sh <= sc_lb_on_sh(1 downto 0) & SC_LOOPBACK_ON_IN; 
        end if;
    end process;

    P_Feedback_Ouput_Valid_HS : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            FB_VLD_OUT <= FB_VLD_IN;                           
        end if;
    end process;

    G_DL_to_FB_Loopback_MonoPhase_HS : if (DPD_PATH_PHASE = "MONO") generate begin             

        dlfb_lb_poly_even_i <= (others => (others => '0'));
        dlfb_lb_poly_even_q <= (others => (others => '0'));
                                                        
        dlfb_lb_poly_odd_i  <= (others => (others => '0'));
        dlfb_lb_poly_odd_q  <= (others => (others => '0'));

        FB_POLY_EVEN_I_OUT  <= (others => (others => '0'));
        FB_POLY_EVEN_Q_OUT  <= (others => (others => '0'));

        FB_POLY_ODD_I_OUT   <= (others => (others => '0'));
        FB_POLY_ODD_Q_OUT   <= (others => (others => '0'));

        G_MonoPhase_RFIC_LoopBack : if (TX_ANT_NUM/2 = FB_PATH_NUM) generate begin
            P_DL_to_RFIC_FB_LB_MONO_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    for I in 0 to (FB_PATH_NUM-1) loop
                        if (fb_vc(1) = '0') then
                            dlfb_lb_mono_i(I) <= DL_DACIF_MONO_I_IN(2*I);
                            dlfb_lb_mono_q(I) <= DL_DACIF_MONO_Q_IN(2*I);
                        else
                            dlfb_lb_mono_i(I) <= DL_DACIF_MONO_I_IN(2*I+1);
                            dlfb_lb_mono_q(I) <= DL_DACIF_MONO_Q_IN(2*I+1);
                        end if;
                    end loop;
                end if;
            end process;
        end generate;

        G_MonoPhase_RFDAC_LoopBack : if (TX_ANT_NUM/2 /= FB_PATH_NUM) generate begin
            P_DL_to_RFDAC_FB_LB_MONO_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    case (fb_vc(2 downto 1)) is
                        when "00" =>
                            dlfb_lb_mono_i(0) <= DL_DACIF_MONO_I_IN(0);
                            dlfb_lb_mono_q(0) <= DL_DACIF_MONO_Q_IN(0);
                        when "01" =>
                            dlfb_lb_mono_i(0) <= DL_DACIF_MONO_I_IN(1);
                            dlfb_lb_mono_q(0) <= DL_DACIF_MONO_Q_IN(1);
                        when "10" =>
                            dlfb_lb_mono_i(0) <= DL_DACIF_MONO_I_IN(2);
                            dlfb_lb_mono_q(0) <= DL_DACIF_MONO_Q_IN(2);
                        when others =>
                            dlfb_lb_mono_i(0) <= DL_DACIF_MONO_I_IN(3);
                            dlfb_lb_mono_q(0) <= DL_DACIF_MONO_Q_IN(3);
                    end case;
                end if;
            end process;
        end generate;

        P_DL_to_FB_LB_MONO_EN_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (sc_lb_on_sh(2) = '1') then
                    FB_MONO_I_OUT <= dlfb_lb_mono_i;
                    FB_MONO_Q_OUT <= dlfb_lb_mono_q;
                else
                    FB_MONO_I_OUT <= FB_MONO_I_IN;
                    FB_MONO_Q_OUT <= FB_MONO_Q_IN;
                end if;
            end if;
        end process;
    end generate;

    G_DL_to_FB_Loopback_PolyPhase_HS : if (DPD_PATH_PHASE = "POLY") generate begin             

        dlfb_lb_mono_i <= (others => (others => '0'));
        dlfb_lb_mono_q <= (others => (others => '0'));

        FB_MONO_I_OUT <= (others => (others => '0'));
        FB_MONO_Q_OUT <= (others => (others => '0'));

        G_PolyPhase_RFIC_LoopBack : if (TX_ANT_NUM/2 = FB_PATH_NUM) generate begin
            P_DL_to_RFIC_FB_LB_POLY_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    for I in 0 to (FB_PATH_NUM-1) loop
                        if (fb_vc(1) = '0') then
                            dlfb_lb_poly_even_i(I) <= DL_DACIF_POLY_EVEN_I_IN(2*I);
                            dlfb_lb_poly_even_q(I) <= DL_DACIF_POLY_EVEN_Q_IN(2*I);
                                                                                  
                            dlfb_lb_poly_odd_i(I)  <= DL_DACIF_POLY_ODD_I_IN(2*I);
                            dlfb_lb_poly_odd_q(I)  <= DL_DACIF_POLY_ODD_Q_IN(2*I);
                        else
                            dlfb_lb_poly_even_i(I) <= DL_DACIF_POLY_EVEN_I_IN(2*I+1);
                            dlfb_lb_poly_even_q(I) <= DL_DACIF_POLY_EVEN_Q_IN(2*I+1);
                                                                                  
                            dlfb_lb_poly_odd_i(I)  <= DL_DACIF_POLY_ODD_I_IN(2*I+1);
                            dlfb_lb_poly_odd_q(I)  <= DL_DACIF_POLY_ODD_Q_IN(2*I+1);
                        end if;
                    end loop;
                end if;
            end process;
        end generate;

        G_PolyPhase_RFDAC_LoopBack : if (TX_ANT_NUM/2 = FB_PATH_NUM) generate begin
            P_DL_to_RFDAC_FB_LB_POLY_HS : process(CLK) begin
                if (CLK'event) and (CLK = '1') then
                    case (fb_vc(2 downto 1)) is
                        when "00" =>
                            dlfb_lb_poly_even_i(0) <= DL_DACIF_POLY_EVEN_I_IN(0);
                            dlfb_lb_poly_even_q(0) <= DL_DACIF_POLY_EVEN_Q_IN(0);
                                                                                  
                            dlfb_lb_poly_odd_i(0)  <= DL_DACIF_POLY_ODD_I_IN(0);
                            dlfb_lb_poly_odd_q(0)  <= DL_DACIF_POLY_ODD_Q_IN(0);
                        when "01" =>
                            dlfb_lb_poly_even_i(0) <= DL_DACIF_POLY_EVEN_I_IN(1);
                            dlfb_lb_poly_even_q(0) <= DL_DACIF_POLY_EVEN_Q_IN(1);
                                                        
                            dlfb_lb_poly_odd_i(0)  <= DL_DACIF_POLY_ODD_I_IN(1);
                            dlfb_lb_poly_odd_q(0)  <= DL_DACIF_POLY_ODD_Q_IN(1);
                        when "10" =>
                            dlfb_lb_poly_even_i(0) <= DL_DACIF_POLY_EVEN_I_IN(2);
                            dlfb_lb_poly_even_q(0) <= DL_DACIF_POLY_EVEN_Q_IN(2);
                                                        
                            dlfb_lb_poly_odd_i(0)  <= DL_DACIF_POLY_ODD_I_IN(2);
                            dlfb_lb_poly_odd_q(0)  <= DL_DACIF_POLY_ODD_Q_IN(2);
                        when others =>
                            dlfb_lb_poly_even_i(0) <= DL_DACIF_POLY_EVEN_I_IN(3);
                            dlfb_lb_poly_even_q(0) <= DL_DACIF_POLY_EVEN_Q_IN(3);
                                                        
                            dlfb_lb_poly_odd_i(0)  <= DL_DACIF_POLY_ODD_I_IN(3);
                            dlfb_lb_poly_odd_q(0)  <= DL_DACIF_POLY_ODD_Q_IN(3);
                    end case;
                end if;
            end process;
        end generate;

        P_DL_to_FB_Loopback_Enable_HS : process(CLK) begin
            if (CLK'event) and (CLK = '1') then
                if (sc_lb_on_sh(2) = '1') then
                    FB_POLY_EVEN_I_OUT  <= dlfb_lb_poly_even_i;
                    FB_POLY_EVEN_Q_OUT  <= dlfb_lb_poly_even_q;
                                                               
                    FB_POLY_ODD_I_OUT   <= dlfb_lb_poly_odd_i;
                    FB_POLY_ODD_Q_OUT   <= dlfb_lb_poly_odd_q;
                else
                    FB_POLY_EVEN_I_OUT  <= FB_POLY_EVEN_I_IN;
                    FB_POLY_EVEN_Q_OUT  <= FB_POLY_EVEN_Q_IN;
                                                               
                    FB_POLY_ODD_I_OUT   <= FB_POLY_ODD_I_IN;
                    FB_POLY_ODD_Q_OUT   <= FB_POLY_ODD_Q_IN;
                end if;
            end if;
        end process;
    end generate;

    -- *************************************************************************************
    -- Switching Traffic for Smart Capture 
    -- *************************************************************************************

    -- FB_VC
    -- 0000  : FWD antenna #A
    -- 0001  : RVS antenna #A
    -- 0010  : FWD antenna #B
    -- 0011  : RVS antenna #B

    G_Using_Smart_Capture : if (SC_IMPLEMENTATION =  TRUE) generate begin   

        P_SC_Clock_Divide_Count : process(rst_synch, CLK) begin 
            if (rst_synch = '1') then
                sc_clk_div_cnt <= (others => '0');
            elsif (CLK'event) and (CLK = '1') then
                if (sc_clk_div_cnt = SC_HOVS-1) then 
                    sc_clk_div_cnt <= (others => '0');
                else
                    sc_clk_div_cnt <= sc_clk_div_cnt + '1';
                end if;
            end if;
        end process;

        sc_ref_vld <= '1' when (sc_clk_div_cnt = SC_HOVS-1) else '0';

        G_ANT_2Path_HS : if ((TX_ANT_NUM = 2) and (FB_PATH_NUM = 1) and (RX_ANT_NUM = 2)) generate begin

            G_CAPTURE_SW_2PATH_MONO_HS : if (DPD_PATH_PHASE = "MONO") generate begin             

                dpd_cfr_poly_even_i  <= (others => '0');
                dpd_cfr_poly_even_q  <= (others => '0');
                                     
                dpd_cfr_poly_odd_i   <= (others => '0');
                dpd_cfr_poly_odd_q   <= (others => '0');
                                     
                dpd_dpd_poly_even_i  <= (others => '0');
                dpd_dpd_poly_even_q  <= (others => '0');
                                     
                dpd_dpd_poly_odd_i   <= (others => '0');
                dpd_dpd_poly_odd_q   <= (others => '0');
                                     
                dpd_fb_poly_even_i   <= (others => '0');
                dpd_fb_poly_even_q   <= (others => '0');
                                     
                dpd_fb_poly_odd_i    <= (others => '0');
                dpd_fb_poly_odd_q    <= (others => '0');

                P_DPD_SW_2Path_MONO_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (fb_vc(1)) is
                            when '0' =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(0); dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(0); pim_mixps_i <= DBG_PIM_MIXPS_I_IN(0);
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(0); dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(0); pim_mixps_q <= DBG_PIM_MIXPS_Q_IN(0);
                            when others =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(1); dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(1); pim_mixps_i <= DBG_PIM_MIXPS_I_IN(1);
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(1); dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(1); pim_mixps_q <= DBG_PIM_MIXPS_Q_IN(1);
                        end case;

                        dpd_fb_mono_i <= DL_FB_ATT_MONO_I_IN(0); 
                        dpd_fb_mono_q <= DL_FB_ATT_MONO_Q_IN(0);
                    end if;
                end process;
            end generate;

            G_CAPTURE_SW_2PATH_POLY_HS : if (DPD_PATH_PHASE = "POLY") generate begin             
                dpd_cfr_mono_i <= (others => '0');
                dpd_cfr_mono_q <= (others => '0');
                
                dpd_dpd_mono_i <= (others => '0');
                dpd_dpd_mono_q <= (others => '0');
                
                dpd_fb_mono_i  <= (others => '0');
                dpd_fb_mono_q  <= (others => '0');

                pim_mixps_i    <= (others => '0');
                pim_mixps_q    <= (others => '0');

                P_DPD_SW_2Path_MONO_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (fb_vc(1)) is
                            when '0' =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(0); dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(0);
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(0) ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(0) ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(0); dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(0);
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(0) ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(0) ;
                            when others =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(1); dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(1);
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(1) ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(1) ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(1); dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(1);
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(1) ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(1) ;
                        end case;

                        dpd_fb_poly_even_i <= DL_FB_ATT_POLY_EVEN_I_IN(0); 
                        dpd_fb_poly_even_q <= DL_FB_ATT_POLY_EVEN_Q_IN(0);

                        dpd_fb_poly_odd_i  <= DL_FB_ATT_POLY_ODD_I_IN(0) ; 
                        dpd_fb_poly_odd_q  <= DL_FB_ATT_POLY_ODD_Q_IN(0) ;
                    end if;
                end process;
            end generate;

            G_2Path_SC_DPD_PIM_HS : if (PIM_IMPLEMENTATION = TRUE) generate begin

                P_2Path_PIM_SW_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (fb_vc(1)) is
                            when '0' =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(0) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(0);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(0); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(0);
                            when others =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(1) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(1);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(1); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(1);
                        end case;
                    end if;
                end process;

                G_2Path_INTER_PIM_SW_HS : if (PIMD_BLK_TYPE /= "INTRA") generate begin
                    P_2Path_INTER_PIM_SW_HS : process(CLK) begin
                        if (CLK'event) and (CLK = '1') then
                            case (fb_vc(1)) is
                                when '0' =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(0)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(0)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(0)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(0)           ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(0) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(0) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(0)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(0)           ; 
                                when others =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(1)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(1)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(1)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(1)           ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(1) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(1) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(1)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(1)           ; 
                            end case;
                        end if;
                    end process;
                end generate;

                G_2Path_INTRA_PIM_SW_HS : if (PIMD_BLK_TYPE = "INTRA") generate begin

                    dl_pim_3rd_im_mixer_i  <= (others => '0');
                    dl_pim_3rd_im_mixer_q  <= (others => '0');
                    
                    dl_pim_cfr_i           <= (others => '0');
                    dl_pim_cfr_q           <= (others => '0');
                    
                    dl_pim_inter_duc_dly_i <= (others => '0');
                    dl_pim_inter_duc_dly_q <= (others => '0');
                    
                    ul_pim_dbg_i           <= (others => '0'); 
                    ul_pim_dbg_q           <= (others => '0'); 

                end generate;
            end generate;

            G_2path_SC_DPD_Only_HS : if (PIM_IMPLEMENTATION = FALSE) generate begin

                dl_pim_3rd_im_mixer_i  <= (others => '0');
                dl_pim_3rd_im_mixer_q  <= (others => '0');
                
                ul_pim_error_i         <= (others => '0');
                ul_pim_error_q         <= (others => '0');
                
                ul_pim_target_i        <= (others => '0');
                ul_pim_target_q        <= (others => '0');
                
                dl_pim_cfr_i           <= (others => '0');
                dl_pim_cfr_q           <= (others => '0');
                
                dl_pim_inter_duc_dly_i <= (others => '0');
                dl_pim_inter_duc_dly_q <= (others => '0');
                
                ul_pim_dbg_i           <= (others => '0'); 
                ul_pim_dbg_q           <= (others => '0'); 

            end generate;
        end generate;

        G_ANT_4Path_FB1_HS : if ((TX_ANT_NUM = 4) and (FB_PATH_NUM = 1) and (RX_ANT_NUM = 4)) generate begin

            G_CAPTURE_SW_4PATH_FB1_MONO_HS : if (DPD_PATH_PHASE = "MONO") generate begin             

                dpd_cfr_poly_even_i  <= (others => '0');
                dpd_cfr_poly_even_q  <= (others => '0');
                                     
                dpd_cfr_poly_odd_i   <= (others => '0');
                dpd_cfr_poly_odd_q   <= (others => '0');
                                     
                dpd_dpd_poly_even_i  <= (others => '0');
                dpd_dpd_poly_even_q  <= (others => '0');
                                     
                dpd_dpd_poly_odd_i   <= (others => '0');
                dpd_dpd_poly_odd_q   <= (others => '0');
                                     
                dpd_fb_poly_even_i   <= (others => '0');
                dpd_fb_poly_even_q   <= (others => '0');
                                     
                dpd_fb_poly_odd_i    <= (others => '0');
                dpd_fb_poly_odd_q    <= (others => '0');

                P_DPD_SW_4Path_FB1_MONO_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        dpd_fb_mono_i  <= DL_FB_ATT_MONO_I_IN(0); 
                        dpd_fb_mono_q  <= DL_FB_ATT_MONO_Q_IN(0);

                        case (fb_vc(2 downto 1)) is
                            when "00" =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(0); dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(0); pim_mixps_i <= DBG_PIM_MIXPS_I_IN(0);
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(0); dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(0); pim_mixps_q <= DBG_PIM_MIXPS_Q_IN(0);
                            when "01" =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(1); dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(1); pim_mixps_i <= DBG_PIM_MIXPS_I_IN(1);
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(1); dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(1); pim_mixps_q <= DBG_PIM_MIXPS_Q_IN(1);
                            when "10" =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(2); dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(2); pim_mixps_i <= DBG_PIM_MIXPS_I_IN(2);
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(2); dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(2); pim_mixps_q <= DBG_PIM_MIXPS_Q_IN(2);
                            when others =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(3); dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(3); pim_mixps_i <= DBG_PIM_MIXPS_I_IN(3);
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(3); dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(3); pim_mixps_q <= DBG_PIM_MIXPS_Q_IN(3);
                        end case;
                    end if;
                end process;
            end generate;

            G_CAPTURE_SW_4PATH_FB1_POLY_HS : if (DPD_PATH_PHASE = "POLY") generate begin             
                dpd_cfr_mono_i <= (others => '0');
                dpd_cfr_mono_q <= (others => '0');
                
                dpd_dpd_mono_i <= (others => '0');
                dpd_dpd_mono_q <= (others => '0');
                
                dpd_fb_mono_i  <= (others => '0');
                dpd_fb_mono_q  <= (others => '0');

                pim_mixps_i    <= (others => '0');
                pim_mixps_q    <= (others => '0');


                P_DPD_SW_4Path_FB1_MONO_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        dpd_fb_poly_even_i   <= DL_FB_ATT_POLY_EVEN_I_IN(0); 
                        dpd_fb_poly_even_q   <= DL_FB_ATT_POLY_EVEN_Q_IN(0);

                        dpd_fb_poly_odd_i    <= DL_FB_ATT_POLY_ODD_I_IN(0) ; 
                        dpd_fb_poly_odd_q    <= DL_FB_ATT_POLY_ODD_Q_IN(0) ;

                        case (fb_vc(2 downto 1)) is
                            when "00" =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(0)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(0)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(0)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(0)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(0)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(0)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(0)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(0)    ;
                            when "01" =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(1)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(1)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(1)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(1)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(1)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(1)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(1)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(1)    ;
                            when "10" =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(2)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(2)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(2)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(2)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(2)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(2)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(2)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(2)    ;
                            when others =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(3)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(3)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(3)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(3)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(3)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(3)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(3)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(3)    ;
                        end case;
                    end if;
                end process;
            end generate;

            G_4Path_FB1_SC_DPD_PIM_HS : if (PIM_IMPLEMENTATION = TRUE) generate begin

                P_4Path_FB1_PIM_SW_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (fb_vc(2 downto 1)) is
                            when "00" =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(0) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(0);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(0); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(0);
                            when "01" =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(1) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(1);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(1); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(1);
                            when "10" =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(2) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(2);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(2); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(2);
                            when others =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(3) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(3);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(3); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(3);
                        end case;
                    end if;
                end process;

                G_4Path_FB1_INTER_PIM_SW_HS : if (PIMD_BLK_TYPE /= "INTRA") generate begin
                    P_4Path_FB1_INTER_PIM_SW_HS : process(CLK) begin
                        if (CLK'event) and (CLK = '1') then
                            case (fb_vc(2 downto 1)) is
                                when "00" =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(0)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(0)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(0)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(0)       ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(0) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(0) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(0)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(0)           ; 
                                when "01" =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(1)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(1)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(1)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(1)       ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(1) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(1) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(1)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(1)           ; 
                                when "10" =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(2)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(2)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(2)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(2)       ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(2) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(2) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(2)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(2)           ; 
                                when others =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(3)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(3)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(3)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(3)       ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(3) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(3) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(3)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(3)           ; 
                            end case;
                        end if;
                    end process;
                end generate;

                G_4Path_FB1_INTRA_PIM_SW_HS : if (PIMD_BLK_TYPE = "INTRA") generate begin

                    dl_pim_3rd_im_mixer_i  <= (others => '0');
                    dl_pim_3rd_im_mixer_q  <= (others => '0');
                    
                    dl_pim_cfr_i           <= (others => '0');
                    dl_pim_cfr_q           <= (others => '0');
                    
                    dl_pim_inter_duc_dly_i <= (others => '0');
                    dl_pim_inter_duc_dly_q <= (others => '0');
                    
                    ul_pim_dbg_i           <= (others => '0'); 
                    ul_pim_dbg_q           <= (others => '0'); 

                end generate;
            end generate;

            G_4path_FB1_SC_DPD_Only_HS : if (PIM_IMPLEMENTATION = FALSE) generate begin

                dl_pim_3rd_im_mixer_i  <= (others => '0');
                dl_pim_3rd_im_mixer_q  <= (others => '0');
                
                ul_pim_error_i         <= (others => '0');
                ul_pim_error_q         <= (others => '0');
                
                ul_pim_target_i        <= (others => '0');
                ul_pim_target_q        <= (others => '0');
                
                dl_pim_cfr_i           <= (others => '0');
                dl_pim_cfr_q           <= (others => '0');
                
                dl_pim_inter_duc_dly_i <= (others => '0');
                dl_pim_inter_duc_dly_q <= (others => '0');
                
                ul_pim_dbg_i           <= (others => '0'); 
                ul_pim_dbg_q           <= (others => '0'); 

            end generate;
        end generate;


        G_ANT_4Path_HS : if ((TX_ANT_NUM = 4) and (FB_PATH_NUM = 2) and (RX_ANT_NUM = 4)) generate begin

            G_CAPTURE_SW_4PATH_MONO_HS : if (DPD_PATH_PHASE = "MONO") generate begin             

                dpd_cfr_poly_even_i  <= (others => '0');
                dpd_cfr_poly_even_q  <= (others => '0');
                                     
                dpd_cfr_poly_odd_i   <= (others => '0');
                dpd_cfr_poly_odd_q   <= (others => '0');
                                     
                dpd_dpd_poly_even_i  <= (others => '0');
                dpd_dpd_poly_even_q  <= (others => '0');
                                     
                dpd_dpd_poly_odd_i   <= (others => '0');
                dpd_dpd_poly_odd_q   <= (others => '0');
                                     
                dpd_fb_poly_even_i   <= (others => '0');
                dpd_fb_poly_even_q   <= (others => '0');
                                     
                dpd_fb_poly_odd_i    <= (others => '0');
                dpd_fb_poly_odd_q    <= (others => '0');

                P_DPD_SW_2Path_MONO_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (fb_vc(2 downto 1)) is
                            when "00" =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(0)   ; dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(0)   ;
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(0)   ; dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(0)   ;
                               dpd_fb_mono_i  <= DL_FB_ATT_MONO_I_IN(0); dpd_fb_mono_q  <= DL_FB_ATT_MONO_Q_IN(0);
                               pim_mixps_i    <= DBG_PIM_MIXPS_I_IN(0) ; pim_mixps_q    <= DBG_PIM_MIXPS_Q_IN(0);
                            when "01" =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(1)   ; dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(1)   ;
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(1)   ; dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(1)   ;
                               dpd_fb_mono_i  <= DL_FB_ATT_MONO_I_IN(0); dpd_fb_mono_q  <= DL_FB_ATT_MONO_Q_IN(0);
                               pim_mixps_i    <= DBG_PIM_MIXPS_I_IN(1) ; pim_mixps_q    <= DBG_PIM_MIXPS_Q_IN(1);
                            when "10" =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(2)   ; dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(2)   ;
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(2)   ; dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(2)   ;
                               dpd_fb_mono_i  <= DL_FB_ATT_MONO_I_IN(1); dpd_fb_mono_q  <= DL_FB_ATT_MONO_Q_IN(1);
                               pim_mixps_i    <= DBG_PIM_MIXPS_I_IN(2) ; pim_mixps_q    <= DBG_PIM_MIXPS_Q_IN(2);
                            when others =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(3)   ; dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(3)   ;
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(3)   ; dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(3)   ;
                               dpd_fb_mono_i  <= DL_FB_ATT_MONO_I_IN(1); dpd_fb_mono_q  <= DL_FB_ATT_MONO_Q_IN(1);
                               pim_mixps_i    <= DBG_PIM_MIXPS_I_IN(3) ; pim_mixps_q    <= DBG_PIM_MIXPS_Q_IN(3);
                        end case;
                    end if;
                end process;
            end generate;

            G_CAPTURE_SW_4PATH_POLY_HS : if (DPD_PATH_PHASE = "POLY") generate begin             
                dpd_cfr_mono_i <= (others => '0');
                dpd_cfr_mono_q <= (others => '0');
                
                dpd_dpd_mono_i <= (others => '0');
                dpd_dpd_mono_q <= (others => '0');
                
                dpd_fb_mono_i  <= (others => '0');
                dpd_fb_mono_q  <= (others => '0');

                pim_mixps_i    <= (others => '0');
                pim_mixps_q    <= (others => '0');


                P_DPD_SW_4Path_MONO_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (fb_vc(2 downto 1)) is
                            when "00" =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(0)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(0)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(0)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(0)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(0)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(0)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(0)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(0)    ;
                                dpd_fb_poly_even_i   <= DL_FB_ATT_POLY_EVEN_I_IN(0); dpd_fb_poly_even_q   <= DL_FB_ATT_POLY_EVEN_Q_IN(0);
                                dpd_fb_poly_odd_i    <= DL_FB_ATT_POLY_ODD_I_IN(0) ; dpd_fb_poly_odd_q    <= DL_FB_ATT_POLY_ODD_Q_IN(0) ;
                            when "01" =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(1)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(1)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(1)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(1)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(1)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(1)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(1)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(1)    ;
                                dpd_fb_poly_even_i   <= DL_FB_ATT_POLY_EVEN_I_IN(0); dpd_fb_poly_even_q   <= DL_FB_ATT_POLY_EVEN_Q_IN(0);
                                dpd_fb_poly_odd_i    <= DL_FB_ATT_POLY_ODD_I_IN(0) ; dpd_fb_poly_odd_q    <= DL_FB_ATT_POLY_ODD_Q_IN(0) ;
                            when "10" =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(2)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(2)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(2)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(2)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(2)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(2)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(2)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(2)    ;
                                dpd_fb_poly_even_i   <= DL_FB_ATT_POLY_EVEN_I_IN(1); dpd_fb_poly_even_q   <= DL_FB_ATT_POLY_EVEN_Q_IN(1);
                                dpd_fb_poly_odd_i    <= DL_FB_ATT_POLY_ODD_I_IN(1) ; dpd_fb_poly_odd_q    <= DL_FB_ATT_POLY_ODD_Q_IN(1) ;
                            when others =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(3)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(3)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(3)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(3)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(3)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(3)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(3)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(3)    ;
                                dpd_fb_poly_even_i   <= DL_FB_ATT_POLY_EVEN_I_IN(1); dpd_fb_poly_even_q   <= DL_FB_ATT_POLY_EVEN_Q_IN(1);
                                dpd_fb_poly_odd_i    <= DL_FB_ATT_POLY_ODD_I_IN(1) ; dpd_fb_poly_odd_q    <= DL_FB_ATT_POLY_ODD_Q_IN(1) ;
                        end case;
                    end if;
                end process;
            end generate;

            G_4Path_SC_DPD_PIM_HS : if (PIM_IMPLEMENTATION = TRUE) generate begin

                P_4Path_PIM_SW_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (fb_vc(2 downto 1)) is
                            when "00" =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(0) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(0);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(0); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(0);
                            when "01" =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(1) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(1);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(1); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(1);
                            when "10" =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(2) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(2);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(2); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(2);
                            when others =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(3) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(3);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(3); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(3);
                        end case;
                    end if;
                end process;

                G_4Path_INTER_PIM_SW_HS : if (PIMD_BLK_TYPE /= "INTRA") generate begin
                    P_4Path_INTER_PIM_SW_HS : process(CLK) begin
                        if (CLK'event) and (CLK = '1') then
                            case (fb_vc(2 downto 1)) is
                                when "00" =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(0)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(0)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(0)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(0)       ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(0) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(0) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(0)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(0)           ; 
                                when "01" =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(1)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(1)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(1)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(1)       ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(1) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(1) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(1)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(1)           ; 
                                when "10" =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(2)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(2)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(2)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(2)       ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(2) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(2) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(2)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(2)           ; 
                                when others =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(3)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(3)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(3)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(3)       ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(3) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(3) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(3)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(3)           ; 
                            end case;
                        end if;
                    end process;
                end generate;

                G_4Path_INTRA_PIM_SW_HS : if (PIMD_BLK_TYPE = "INTRA") generate begin

                    dl_pim_3rd_im_mixer_i  <= (others => '0');
                    dl_pim_3rd_im_mixer_q  <= (others => '0');
                    
                    dl_pim_cfr_i           <= (others => '0');
                    dl_pim_cfr_q           <= (others => '0');
                    
                    dl_pim_inter_duc_dly_i <= (others => '0');
                    dl_pim_inter_duc_dly_q <= (others => '0');
                    
                    ul_pim_dbg_i           <= (others => '0'); 
                    ul_pim_dbg_q           <= (others => '0'); 

                end generate;
            end generate;

            G_4path_SC_DPD_Only_HS : if (PIM_IMPLEMENTATION = FALSE) generate begin

                dl_pim_3rd_im_mixer_i  <= (others => '0');
                dl_pim_3rd_im_mixer_q  <= (others => '0');
                
                ul_pim_error_i         <= (others => '0');
                ul_pim_error_q         <= (others => '0');
                
                ul_pim_target_i        <= (others => '0');
                ul_pim_target_q        <= (others => '0');
                
                dl_pim_cfr_i           <= (others => '0');
                dl_pim_cfr_q           <= (others => '0');
                
                dl_pim_inter_duc_dly_i <= (others => '0');
                dl_pim_inter_duc_dly_q <= (others => '0');
                
                ul_pim_dbg_i           <= (others => '0'); 
                ul_pim_dbg_q           <= (others => '0'); 

            end generate;
        end generate;


        G_ANT_8Path_HS : if ((TX_ANT_NUM = 8) and (FB_PATH_NUM = 4) and (RX_ANT_NUM = 8)) generate begin

            G_CAPTURE_SW_8PATH_MONO_HS : if (DPD_PATH_PHASE = "MONO") generate begin             

                dpd_cfr_poly_even_i  <= (others => '0');
                dpd_cfr_poly_even_q  <= (others => '0');
                                     
                dpd_cfr_poly_odd_i   <= (others => '0');
                dpd_cfr_poly_odd_q   <= (others => '0');
                                     
                dpd_dpd_poly_even_i  <= (others => '0');
                dpd_dpd_poly_even_q  <= (others => '0');
                                     
                dpd_dpd_poly_odd_i   <= (others => '0');
                dpd_dpd_poly_odd_q   <= (others => '0');
                                     
                dpd_fb_poly_even_i   <= (others => '0');
                dpd_fb_poly_even_q   <= (others => '0');
                                     
                dpd_fb_poly_odd_i    <= (others => '0');
                dpd_fb_poly_odd_q    <= (others => '0');

                P_DPD_SW_8Path_MONO_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (fb_vc(3 downto 1)) is
                            when "000" =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(0)   ; dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(0)   ;
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(0)   ; dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(0)   ;
                               dpd_fb_mono_i  <= DL_FB_ATT_MONO_I_IN(0); dpd_fb_mono_q  <= DL_FB_ATT_MONO_Q_IN(0);
                               pim_mixps_i    <= DBG_PIM_MIXPS_I_IN(0) ; pim_mixps_q    <= DBG_PIM_MIXPS_Q_IN(0);
                            when "001" =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(1)   ; dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(1)   ;
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(1)   ; dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(1)   ;
                               dpd_fb_mono_i  <= DL_FB_ATT_MONO_I_IN(0); dpd_fb_mono_q  <= DL_FB_ATT_MONO_Q_IN(0);
                               pim_mixps_i    <= DBG_PIM_MIXPS_I_IN(1) ; pim_mixps_q    <= DBG_PIM_MIXPS_Q_IN(1);
                            when "010" =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(2)   ; dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(2)   ;
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(2)   ; dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(2)   ;
                               dpd_fb_mono_i  <= DL_FB_ATT_MONO_I_IN(1); dpd_fb_mono_q  <= DL_FB_ATT_MONO_Q_IN(1);
                               pim_mixps_i    <= DBG_PIM_MIXPS_I_IN(2) ; pim_mixps_q    <= DBG_PIM_MIXPS_Q_IN(2);
                            when "011" =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(3)   ; dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(3)   ;
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(3)   ; dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(3)   ;
                               dpd_fb_mono_i  <= DL_FB_ATT_MONO_I_IN(1); dpd_fb_mono_q  <= DL_FB_ATT_MONO_Q_IN(1);
                               pim_mixps_i    <= DBG_PIM_MIXPS_I_IN(3) ; pim_mixps_q    <= DBG_PIM_MIXPS_Q_IN(3);
                            when "100" =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(4)   ; dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(4)   ;
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(4)   ; dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(4)   ;
                               dpd_fb_mono_i  <= DL_FB_ATT_MONO_I_IN(2); dpd_fb_mono_q  <= DL_FB_ATT_MONO_Q_IN(2);
                               pim_mixps_i    <= DBG_PIM_MIXPS_I_IN(4) ; pim_mixps_q    <= DBG_PIM_MIXPS_Q_IN(4);
                            when "101" =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(5)   ; dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(5)   ;
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(5)   ; dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(5)   ;
                               dpd_fb_mono_i  <= DL_FB_ATT_MONO_I_IN(2); dpd_fb_mono_q  <= DL_FB_ATT_MONO_Q_IN(2);
                               pim_mixps_i    <= DBG_PIM_MIXPS_I_IN(5) ; pim_mixps_q    <= DBG_PIM_MIXPS_Q_IN(5);
                            when "110" =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(6)   ; dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(6)   ;
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(6)   ; dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(6)   ;
                               dpd_fb_mono_i  <= DL_FB_ATT_MONO_I_IN(3); dpd_fb_mono_q  <= DL_FB_ATT_MONO_Q_IN(3);
                               pim_mixps_i    <= DBG_PIM_MIXPS_I_IN(6) ; pim_mixps_q    <= DBG_PIM_MIXPS_Q_IN(6);
                            when others =>
                               dpd_cfr_mono_i <= DL_CFR_MONO_I_IN(7)   ; dpd_cfr_mono_q <= DL_CFR_MONO_Q_IN(7)   ;
                               dpd_dpd_mono_i <= DL_DPD_MONO_I_IN(7)   ; dpd_dpd_mono_q <= DL_DPD_MONO_Q_IN(7)   ;
                               dpd_fb_mono_i  <= DL_FB_ATT_MONO_I_IN(3); dpd_fb_mono_q  <= DL_FB_ATT_MONO_Q_IN(3);
                               pim_mixps_i    <= DBG_PIM_MIXPS_I_IN(7) ; pim_mixps_q    <= DBG_PIM_MIXPS_Q_IN(7);
                        end case;
                    end if;
                end process;
            end generate;

            G_CAPTURE_SW_8PATH_POLY_HS : if (DPD_PATH_PHASE = "POLY") generate begin             
                dpd_cfr_mono_i <= (others => '0');
                dpd_cfr_mono_q <= (others => '0');
                
                dpd_dpd_mono_i <= (others => '0');
                dpd_dpd_mono_q <= (others => '0');
                
                dpd_fb_mono_i  <= (others => '0');
                dpd_fb_mono_q  <= (others => '0');

                pim_mixps_i    <= (others => '0');
                pim_mixps_q    <= (others => '0');

                P_DPD_SW_8Path_MONO_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (fb_vc(3 downto 1)) is
                            when "000" =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(0)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(0)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(0)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(0)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(0)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(0)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(0)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(0)    ;
                                dpd_fb_poly_even_i   <= DL_FB_ATT_POLY_EVEN_I_IN(0); dpd_fb_poly_even_q   <= DL_FB_ATT_POLY_EVEN_Q_IN(0);
                                dpd_fb_poly_odd_i    <= DL_FB_ATT_POLY_ODD_I_IN(0) ; dpd_fb_poly_odd_q    <= DL_FB_ATT_POLY_ODD_Q_IN(0) ;
                            when "001" =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(1)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(1)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(1)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(1)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(1)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(1)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(1)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(1)    ;
                                dpd_fb_poly_even_i   <= DL_FB_ATT_POLY_EVEN_I_IN(0); dpd_fb_poly_even_q   <= DL_FB_ATT_POLY_EVEN_Q_IN(0);
                                dpd_fb_poly_odd_i    <= DL_FB_ATT_POLY_ODD_I_IN(0) ; dpd_fb_poly_odd_q    <= DL_FB_ATT_POLY_ODD_Q_IN(0) ;
                            when "010" =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(2)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(2)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(2)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(2)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(2)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(2)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(2)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(2)    ;
                                dpd_fb_poly_even_i   <= DL_FB_ATT_POLY_EVEN_I_IN(1); dpd_fb_poly_even_q   <= DL_FB_ATT_POLY_EVEN_Q_IN(1);
                                dpd_fb_poly_odd_i    <= DL_FB_ATT_POLY_ODD_I_IN(1) ; dpd_fb_poly_odd_q    <= DL_FB_ATT_POLY_ODD_Q_IN(1) ;
                            when "011" =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(3)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(3)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(3)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(3)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(3)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(3)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(3)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(3)    ;
                                dpd_fb_poly_even_i   <= DL_FB_ATT_POLY_EVEN_I_IN(1); dpd_fb_poly_even_q   <= DL_FB_ATT_POLY_EVEN_Q_IN(1);
                                dpd_fb_poly_odd_i    <= DL_FB_ATT_POLY_ODD_I_IN(1) ; dpd_fb_poly_odd_q    <= DL_FB_ATT_POLY_ODD_Q_IN(1) ;
                            when "100" =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(4)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(4)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(4)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(4)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(4)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(4)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(4)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(4)    ;
                                dpd_fb_poly_even_i   <= DL_FB_ATT_POLY_EVEN_I_IN(2); dpd_fb_poly_even_q   <= DL_FB_ATT_POLY_EVEN_Q_IN(2);
                                dpd_fb_poly_odd_i    <= DL_FB_ATT_POLY_ODD_I_IN(2) ; dpd_fb_poly_odd_q    <= DL_FB_ATT_POLY_ODD_Q_IN(2) ;
                            when "101" =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(5)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(5)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(5)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(5)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(5)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(5)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(5)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(5)    ;
                                dpd_fb_poly_even_i   <= DL_FB_ATT_POLY_EVEN_I_IN(2); dpd_fb_poly_even_q   <= DL_FB_ATT_POLY_EVEN_Q_IN(2);
                                dpd_fb_poly_odd_i    <= DL_FB_ATT_POLY_ODD_I_IN(2) ; dpd_fb_poly_odd_q    <= DL_FB_ATT_POLY_ODD_Q_IN(2) ;
                            when "110" =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(6)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(6)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(6)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(6)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(6)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(6)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(6)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(6)    ;
                                dpd_fb_poly_even_i   <= DL_FB_ATT_POLY_EVEN_I_IN(3); dpd_fb_poly_even_q   <= DL_FB_ATT_POLY_EVEN_Q_IN(3);
                                dpd_fb_poly_odd_i    <= DL_FB_ATT_POLY_ODD_I_IN(3) ; dpd_fb_poly_odd_q    <= DL_FB_ATT_POLY_ODD_Q_IN(3) ;
                            when others =>
                                dpd_cfr_poly_even_i  <= DL_CFR_POLY_EVEN_I_IN(7)   ; dpd_cfr_poly_even_q  <= DL_CFR_POLY_EVEN_Q_IN(7)   ;
                                dpd_cfr_poly_odd_i   <= DL_CFR_POLY_ODD_I_IN(7)    ; dpd_cfr_poly_odd_q   <= DL_CFR_POLY_ODD_Q_IN(7)    ;
                                dpd_dpd_poly_even_i  <= DL_DPD_POLY_EVEN_I_IN(7)   ; dpd_dpd_poly_even_q  <= DL_DPD_POLY_EVEN_Q_IN(7)   ;
                                dpd_dpd_poly_odd_i   <= DL_DPD_POLY_ODD_I_IN(7)    ; dpd_dpd_poly_odd_q   <= DL_DPD_POLY_ODD_Q_IN(7)    ;
                                dpd_fb_poly_even_i   <= DL_FB_ATT_POLY_EVEN_I_IN(3); dpd_fb_poly_even_q   <= DL_FB_ATT_POLY_EVEN_Q_IN(3);
                                dpd_fb_poly_odd_i    <= DL_FB_ATT_POLY_ODD_I_IN(3) ; dpd_fb_poly_odd_q    <= DL_FB_ATT_POLY_ODD_Q_IN(3) ;
                        end case;
                    end if;
                end process;
            end generate;

            G_8Path_SC_DPD_PIM_HS : if (PIM_IMPLEMENTATION = TRUE) generate begin

                P_8Path_PIM_SW_HS : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        case (fb_vc(3 downto 1)) is
                            when "000" =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(0) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(0);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(0); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(0);
                            when "001" =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(1) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(1);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(1); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(1);
                            when "010" =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(2) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(2);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(2); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(2);
                            when "011" =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(3) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(3);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(3); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(3);
                            when "100" =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(4) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(4);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(4); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(4);
                            when "101" =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(5) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(5);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(5); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(5);
                            when "110" =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(6) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(6);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(6); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(6);
                            when others =>
                                ul_pim_error_i  <= UL_PIM_ERROR_I_IN(7) ; ul_pim_error_q  <= UL_PIM_ERROR_Q_IN(7);
                                ul_pim_target_i <= UL_PIM_TARGET_I_IN(7); ul_pim_target_q <= UL_PIM_TARGET_Q_IN(7);
                        end case;
                    end if;
                end process;

                G_8Path_INTER_PIM_SW_HS : if (PIMD_BLK_TYPE /= "INTRA") generate begin
                    P_8Path_INTER_PIM_SW_HS : process(CLK) begin
                        if (CLK'event) and (CLK = '1') then
                            case (fb_vc(3 downto 1)) is
                                when "000" =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(0)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(0)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(0)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(0)           ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(0) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(0) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(0)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(0)           ; 
                                when "001" =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(1)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(1)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(1)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(1)           ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(1) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(1) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(1)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(1)           ; 
                                when "010" =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(2)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(2)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(2)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(2)           ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(2) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(2) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(2)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(2)           ; 
                                when "011" =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(3)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(3)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(3)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(3)           ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(3) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(3) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(3)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(3)           ; 
                                when "100" =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(4)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(4)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(4)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(4)           ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(4) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(4) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(4)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(4)           ; 
                                when "101" =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(5)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(5)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(5)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(5)           ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(5) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(5) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(5)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(5)           ; 
                                when "110" =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(6)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(6)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(6)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(6)           ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(6) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(6) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(6)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(6)           ; 
                                when others =>
                                    dl_pim_3rd_im_mixer_i  <= DL_PIM_3RD_IM_MIXER_I_IN(7)  ; dl_pim_3rd_im_mixer_q  <= DL_PIM_3RD_IM_MIXER_Q_IN(7)  ;
                                    dl_pim_cfr_i           <= DL_PIM_CFR_I_IN(7)           ; dl_pim_cfr_q           <= DL_PIM_CFR_Q_IN(7)           ;
                                    dl_pim_inter_duc_dly_i <= DL_PIM_INTER_DUC_DLY_I_IN(7) ; dl_pim_inter_duc_dly_q <= DL_PIM_INTER_DUC_DLY_Q_IN(7) ;
                                    ul_pim_dbg_i           <= UL_PIM_DBG_I_IN(7)           ; ul_pim_dbg_q           <= UL_PIM_DBG_Q_IN(7)           ; 
                            end case;
                        end if;
                    end process;
                end generate;

                G_8Path_INTRA_PIM_SW_HS : if (PIMD_BLK_TYPE = "INTRA") generate begin

                    dl_pim_3rd_im_mixer_i  <= (others => '0');
                    dl_pim_3rd_im_mixer_q  <= (others => '0');
                    
                    dl_pim_cfr_i           <= (others => '0');
                    dl_pim_cfr_q           <= (others => '0');
                    
                    dl_pim_inter_duc_dly_i <= (others => '0');
                    dl_pim_inter_duc_dly_q <= (others => '0');
                    
                    ul_pim_dbg_i           <= (others => '0'); 
                    ul_pim_dbg_q           <= (others => '0'); 

                end generate;
            end generate;

            G_8path_SC_DPD_Only_HS : if (PIM_IMPLEMENTATION = FALSE) generate begin

                dl_pim_3rd_im_mixer_i  <= (others => '0');
                dl_pim_3rd_im_mixer_q  <= (others => '0');
                
                ul_pim_error_i         <= (others => '0');
                ul_pim_error_q         <= (others => '0');
                
                ul_pim_target_i        <= (others => '0');
                ul_pim_target_q        <= (others => '0');
                
                dl_pim_cfr_i           <= (others => '0');
                dl_pim_cfr_q           <= (others => '0');
                
                dl_pim_inter_duc_dly_i <= (others => '0');
                dl_pim_inter_duc_dly_q <= (others => '0');
                
                ul_pim_dbg_i           <= (others => '0'); 
                ul_pim_dbg_q           <= (others => '0'); 

            end generate;
        end generate;
    end generate;

    G_Unusing_Smart_Capture : if (SC_IMPLEMENTATION =  FALSE) generate begin   

        sc_clk_div_cnt         <= (others => '0');
        sc_ref_vld             <= '0';              

        dpd_cfr_mono_i         <= (others => '0'); 
        dpd_cfr_mono_q         <= (others => '0'); 
        
        dpd_dpd_mono_i         <= (others => '0'); 
        dpd_dpd_mono_q         <= (others => '0'); 
        
        dpd_fb_mono_i          <= (others => '0'); 
        dpd_fb_mono_q          <= (others => '0'); 
        
        dpd_cfr_poly_even_i    <= (others => '0'); 
        dpd_cfr_poly_even_q    <= (others => '0'); 
        
        dpd_cfr_poly_odd_i     <= (others => '0'); 
        dpd_cfr_poly_odd_q     <= (others => '0'); 
        
        dpd_dpd_poly_even_i    <= (others => '0'); 
        dpd_dpd_poly_even_q    <= (others => '0'); 
        
        dpd_dpd_poly_odd_i     <= (others => '0'); 
        dpd_dpd_poly_odd_q     <= (others => '0'); 
        
        dpd_fb_poly_even_i     <= (others => '0'); 
        dpd_fb_poly_even_q     <= (others => '0'); 
        
        dpd_fb_poly_odd_i      <= (others => '0'); 
        dpd_fb_poly_odd_q      <= (others => '0'); 
        
        
        dl_pim_3rd_im_mixer_i  <= (others => '0'); 
        dl_pim_3rd_im_mixer_q  <= (others => '0'); 
        
        ul_pim_error_i         <= (others => '0'); 
        ul_pim_error_q         <= (others => '0'); 
        
        ul_pim_target_i        <= (others => '0'); 
        ul_pim_target_q        <= (others => '0'); 
        
        dl_pim_cfr_i           <= (others => '0'); 
        dl_pim_cfr_q           <= (others => '0'); 
        
        dl_pim_inter_duc_dly_i <= (others => '0'); 
        dl_pim_inter_duc_dly_q <= (others => '0'); 
        
        ul_pim_dbg_i           <= (others => '0'); 
        ul_pim_dbg_q           <= (others => '0'); 

    end generate;

    G_SC_DPD_PIM_MODE : if (SC_IMPLEMENTATION = TRUE) generate begin
        G_SC_DPD_Only : if (PIM_IMPLEMENTATION = FALSE) generate begin        

            sc_pim_mode_sel_sh <= (others => '0'); 

            G_SC_DPD_MONO : if (DPD_PATH_PHASE = "MONO") generate begin           
                sc_pim_src0_i <= (others => '0');
                sc_pim_src0_q <= (others => '0');
                
                sc_pim_src1_i <= (others => '0');
                sc_pim_src1_q <= (others => '0');
                
                sc_pim_dbg_i  <= (others => '0');
                sc_pim_dbg_q  <= (others => '0');

                P_SC_DPD_MONO : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        sc_ref_vld_d1 <= sc_ref_vld;
                        if (sc_ref_vld = '1') then
                            sc_ref_i  <= dpd_cfr_mono_i;
                            sc_ref_q  <= dpd_cfr_mono_q;
                                         
                            sc_dpd_i  <= dpd_dpd_mono_i;
                            sc_dpd_q  <= dpd_dpd_mono_q;
                                         
                            sc_fb_i   <= dpd_fb_mono_i ;
                            sc_fb_q   <= dpd_fb_mono_q ;
                        else
                            sc_ref_i  <= sc_ref_i;
                            sc_ref_q  <= sc_ref_q;
                                                 
                            sc_dpd_i  <= sc_dpd_i;
                            sc_dpd_q  <= sc_dpd_q;
                                                 
                            sc_fb_i   <= sc_fb_i ;
                            sc_fb_q   <= sc_fb_q ;
                        end if;
                    end if;
                end process;

            end generate;

            G_SC_DPD_POLY : if (DPD_PATH_PHASE = "POLY") generate begin           
                P_SC_DPD_POLY : process(CLK) begin
                    if (CLK'event) and (CLK = '1') then
                        sc_ref_vld_d1 <= sc_ref_vld;
                        if (sc_ref_vld = '1') then
                            sc_ref_i      <= dpd_cfr_poly_even_i;
                            sc_ref_q      <= dpd_cfr_poly_even_q;
                                             
                            sc_dpd_i      <= dpd_dpd_poly_even_i;
                            sc_dpd_q      <= dpd_dpd_poly_even_q;
                                             
                            sc_fb_i       <= dpd_fb_poly_even_i ;
                            sc_fb_q       <= dpd_fb_poly_even_q ;
                                             
                            sc_pim_src0_i <= dpd_cfr_poly_odd_i ;
                            sc_pim_src0_q <= dpd_cfr_poly_odd_q ;
                                             
                            sc_pim_src1_i <= dpd_dpd_poly_odd_i ;
                            sc_pim_src1_q <= dpd_dpd_poly_odd_q ;
                                             
                            sc_pim_dbg_i  <= dpd_fb_poly_odd_i  ;
                            sc_pim_dbg_q  <= dpd_fb_poly_odd_q  ;

                        else
                            sc_ref_i      <= sc_ref_i     ;
                            sc_ref_q      <= sc_ref_q     ;
                                                          
                            sc_dpd_i      <= sc_dpd_i     ;
                            sc_dpd_q      <= sc_dpd_q     ;
                                                          
                            sc_fb_i       <= sc_fb_i      ;
                            sc_fb_q       <= sc_fb_q      ;
                                                          
                            sc_pim_src0_i <= sc_pim_src0_i;
                            sc_pim_src0_q <= sc_pim_src0_q;
                                                          
                            sc_pim_src1_i <= sc_pim_src1_i;
                            sc_pim_src1_q <= sc_pim_src1_q;
                                                          
                            sc_pim_dbg_i  <= sc_pim_dbg_i ;
                            sc_pim_dbg_q  <= sc_pim_dbg_q ;
                        end if;
                    end if;
                end process;

            end generate;
        end generate;

        G_SC_DPD_PIM : if (PIM_IMPLEMENTATION = TRUE) generate begin        

            P_2Path_SC_PIM_Mode_SEL_DC : process(CLK) begin 
                if (CLK'event) and (CLK = '1') then
                    sc_pim_mode_sel_sh <= sc_pim_mode_sel_sh(0) & SC_DPDFB_PIM_MODE_SEL_IN; 
                end if;
            end process;

            G_SC_DPD_MONO : if (DPD_PATH_PHASE = "MONO") generate begin           
                G_DPD_MONO_INTRA_PIM : if (PIMD_BLK_TYPE = "INTRA") generate begin             
                    sc_pim_src0_i <= (others => '0');
                    sc_pim_src0_q <= (others => '0');
                    
                    sc_pim_src1_i <= (others => '0');
                    sc_pim_src1_q <= (others => '0');
                    
                    P_DPD_MONO_INTRA_PIM : process(CLK) begin
                        if (CLK'event) and (CLK = '1') then
                            sc_ref_vld_d1 <= sc_ref_vld;

                            if (sc_ref_vld = '1') then
                                sc_ref_i     <= dpd_cfr_mono_i;
                                sc_ref_q     <= dpd_cfr_mono_q;

                                sc_pim_dbg_i <= pim_mixps_i;
                                sc_pim_dbg_q <= pim_mixps_q;

                                    
                                if (sc_pim_mode_sel_sh(1) = '1') then
                                    sc_dpd_i <= ul_pim_error_i ;
                                    sc_dpd_q <= ul_pim_error_q ;
                                                
                                    sc_fb_i  <= ul_pim_target_i;
                                    sc_fb_q  <= ul_pim_target_q;
                                else
                                    sc_dpd_i <= dpd_dpd_mono_i;
                                    sc_dpd_q <= dpd_dpd_mono_q;
                                                
                                    sc_fb_i  <= dpd_fb_mono_i;
                                    sc_fb_q  <= dpd_fb_mono_q;
                                end if;
                            else
                                sc_ref_i <= sc_ref_i ;
                                sc_ref_q <= sc_ref_q ;
                                            
                                sc_dpd_i <= sc_dpd_i ;
                                sc_dpd_q <= sc_dpd_q ;
                                            
                                sc_fb_i  <= sc_fb_i  ;
                                sc_fb_q  <= sc_fb_q  ;

                                sc_pim_dbg_i <= sc_pim_dbg_i;
                                sc_pim_dbg_q <= sc_pim_dbg_q;

                            end if;
                        end if;
                    end process;
                end generate;

                G_DPD_MONO_INTER_PIM : if (PIMD_BLK_TYPE /= "INTRA") generate begin             
                    P_DPD_MONO_INTER_PIM : process(CLK) begin
                        if (CLK'event) and (CLK = '1') then
                            sc_ref_vld_d1 <= sc_ref_vld;
                            if (sc_ref_vld = '1') then
                                sc_pim_src0_i <= dl_pim_cfr_i;
                                sc_pim_src0_q <= dl_pim_cfr_q;
                                                 
                                sc_pim_src1_i <= dl_pim_inter_duc_dly_i;
                                sc_pim_src1_q <= dl_pim_inter_duc_dly_q;
                                                 
                                sc_pim_dbg_i  <= ul_pim_dbg_i;
                                sc_pim_dbg_q  <= ul_pim_dbg_q;

                                if (sc_pim_mode_sel_sh(1) = '1') then
                                    sc_ref_i  <= dl_pim_3rd_im_mixer_i;
                                    sc_ref_q  <= dl_pim_3rd_im_mixer_q;
                                                 
                                    sc_dpd_i  <= ul_pim_error_i;
                                    sc_dpd_q  <= ul_pim_error_q;
                                                 
                                    sc_fb_i   <= ul_pim_target_i;
                                    sc_fb_q   <= ul_pim_target_q;
                                else
                                    sc_ref_i  <= dpd_cfr_mono_i;
                                    sc_ref_q  <= dpd_cfr_mono_q;
                                                 
                                    sc_dpd_i  <= dpd_dpd_mono_i;
                                    sc_dpd_q  <= dpd_dpd_mono_q;
                                                 
                                    sc_fb_i   <= dpd_fb_mono_i ;
                                    sc_fb_q   <= dpd_fb_mono_q ;
                                end if;
                            else
                                sc_ref_i      <= sc_ref_i      ;
                                sc_ref_q      <= sc_ref_q      ;
                                                               
                                sc_dpd_i      <= sc_dpd_i      ;
                                sc_dpd_q      <= sc_dpd_q      ;
                                                               
                                sc_fb_i       <= sc_fb_i       ;
                                sc_fb_q       <= sc_fb_q       ;
                                                               
                                sc_pim_src0_i <= sc_pim_src0_i ;
                                sc_pim_src0_q <= sc_pim_src0_q ;
                                                               
                                sc_pim_src1_i <= sc_pim_src1_i ;
                                sc_pim_src1_q <= sc_pim_src1_q ;
                                                               
                                sc_pim_dbg_i  <= sc_pim_dbg_i  ;
                                sc_pim_dbg_q  <= sc_pim_dbg_q  ;
                            end if;
                        end if;
                    end process;
                end generate;
            end generate;

            G_SC_DPD_POLY : if (DPD_PATH_PHASE = "POLY") generate begin           
                G_DPD_POLY_INTRA_PIM : if (PIMD_BLK_TYPE = "INTRA") generate begin             
                    P_DPD_POLY_INTRA_PIM : process(CLK) begin
                        if (CLK'event) and (CLK = '1') then
                            sc_ref_vld_d1 <= sc_ref_vld;
                            if (sc_ref_vld = '1') then
                                sc_ref_i      <= dpd_cfr_poly_even_i;
                                sc_ref_q      <= dpd_cfr_poly_even_q;
                                                 
                                sc_pim_src0_i <= dpd_cfr_poly_odd_i ;
                                sc_pim_src0_q <= dpd_cfr_poly_odd_q ;
                                                 
                                sc_pim_src1_i <= dpd_dpd_poly_odd_i ;
                                sc_pim_src1_q <= dpd_dpd_poly_odd_q ;
                                                 
                                sc_pim_dbg_i  <= dpd_fb_poly_odd_i  ;
                                sc_pim_dbg_q  <= dpd_fb_poly_odd_q  ;

                                if (sc_pim_mode_sel_sh(1) = '1') then
                                    sc_dpd_i <= ul_pim_error_i ;
                                    sc_dpd_q <= ul_pim_error_q ;
                                                
                                    sc_fb_i  <= ul_pim_target_i;
                                    sc_fb_q  <= ul_pim_target_q;
                                else
                                    sc_dpd_i <= dpd_dpd_poly_even_i;
                                    sc_dpd_q <= dpd_dpd_poly_even_q;
                                                
                                    sc_fb_i  <= dpd_fb_poly_even_i ;
                                    sc_fb_q  <= dpd_fb_poly_even_q ;
                                end if;
                            else
                                sc_ref_i      <= sc_ref_i      ;
                                sc_ref_q      <= sc_ref_q      ;
                                                 
                                sc_dpd_i      <= sc_dpd_i      ;
                                sc_dpd_q      <= sc_dpd_q      ;
                                                 
                                sc_fb_i       <= sc_fb_i       ;
                                sc_fb_q       <= sc_fb_q       ;
                                                               
                                sc_pim_src0_i <= sc_pim_src0_i ;
                                sc_pim_src0_q <= sc_pim_src0_q ;
                                                 
                                sc_pim_src1_i <= sc_pim_src1_i ;
                                sc_pim_src1_q <= sc_pim_src1_q ;
                                                 
                                sc_pim_dbg_i  <= sc_pim_dbg_i  ;
                                sc_pim_dbg_q  <= sc_pim_dbg_q  ;
                            end if;
                        end if;
                    end process;

                end generate;

                G_DPD_POLY_INTER_PIM : if (PIMD_BLK_TYPE /= "INTRA") generate begin             
                    P_DPD_POLY_INTER_PIM : process(CLK) begin
                        if (CLK'event) and (CLK = '1') then
                            sc_ref_vld_d1 <= sc_ref_vld;
                            if (sc_ref_vld = '1') then
                                if (sc_pim_mode_sel_sh(1) = '1') then
                                    sc_ref_i      <= dl_pim_3rd_im_mixer_i  ;
                                    sc_ref_q      <= dl_pim_3rd_im_mixer_q  ;
                                                     
                                    sc_dpd_i      <= ul_pim_error_i         ;
                                    sc_dpd_q      <= ul_pim_error_q         ;
                                                     
                                    sc_fb_i       <= ul_pim_target_i        ;
                                    sc_fb_q       <= ul_pim_target_q        ;

                                    sc_pim_src0_i <= dl_pim_cfr_i           ;
                                    sc_pim_src0_q <= dl_pim_cfr_q           ;
                                                     
                                    sc_pim_src1_i <= dl_pim_inter_duc_dly_i ;
                                    sc_pim_src1_q <= dl_pim_inter_duc_dly_q ;
                                                     
                                    sc_pim_dbg_i  <= ul_pim_dbg_i           ;
                                    sc_pim_dbg_q  <= ul_pim_dbg_q           ;
                                else
                                    sc_ref_i      <= dpd_cfr_poly_even_i;
                                    sc_ref_q      <= dpd_cfr_poly_even_q;
                                                     
                                    sc_dpd_i      <= dpd_dpd_poly_even_i;
                                    sc_dpd_q      <= dpd_dpd_poly_even_q;
                                                     
                                    sc_fb_i       <= dpd_fb_poly_even_i ;
                                    sc_fb_q       <= dpd_fb_poly_even_q ;
                                                     
                                    sc_pim_src0_i <= dpd_cfr_poly_odd_i ;
                                    sc_pim_src0_q <= dpd_cfr_poly_odd_q ;
                                                     
                                    sc_pim_src1_i <= dpd_dpd_poly_odd_i ;
                                    sc_pim_src1_q <= dpd_dpd_poly_odd_q ;
                                                     
                                    sc_pim_dbg_i  <= dpd_fb_poly_odd_i  ;
                                    sc_pim_dbg_q  <= dpd_fb_poly_odd_q  ;
                                end if;
                            end if;
                        end if;
                    end process;

                end generate;
            end generate;
        end generate;
    end generate;

    -- *************************************************************************************
    -- Output Assign 
    -- *************************************************************************************

    FB_VC_OUT                <= sc_disable & fb_vc; 

    FBSW_START_RPLS_OUT      <= fbsw_start_rpls; 

    SC_REF_VLD_OUT           <= sc_ref_vld_d1; 
                                             
    SC_REF_I_OUT             <= sc_ref_i; 
    SC_REF_Q_OUT             <= sc_ref_q; 
                                
    SC_DPD_I_OUT             <= sc_dpd_i; 
    SC_DPD_Q_OUT             <= sc_dpd_q; 
                                
    SC_FB_I_OUT              <= sc_fb_i; 
    SC_FB_Q_OUT              <= sc_fb_q; 

    SC_PIM_SRC0_I_OUT        <= sc_pim_src0_i; 
    SC_PIM_SRC0_Q_OUT        <= sc_pim_src0_q; 
                                
    SC_PIM_SRC1_I_OUT        <= sc_pim_src1_i; 
    SC_PIM_SRC1_Q_OUT        <= sc_pim_src1_q; 
                                               
    SC_PIM_DBG_I_OUT         <= sc_pim_dbg_i;  
    SC_PIM_DBG_Q_OUT         <= sc_pim_dbg_q;  

end arc_FBSW_CTRL;

