-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_signed.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity DEMAPPING_V2 is

		port (
					RESET						: in	std_logic;
					CLK							: in	std_logic;
					
					SIN_IN					:	in	std_logic_vector(13 downto 0);
					COS_IN					:	in	std_logic_vector(13 downto 0);
					
					SIGN_I					: in	std_logic;
					SIGN_Q					: in	std_logic;
					SWAP_IQ					:	in	std_logic;
					
					COS_OUT					:	out	std_logic_vector(13 downto 0);
					SIN_OUT					:	out	std_logic_vector(13 downto 0)
					);
end DEMAPPING_V2;

architecture arc_DEMAPPING_V2 of DEMAPPING_V2 is

signal i_sin_out				: std_logic_vector(13 downto 0);
signal i_cos_out				: std_logic_vector(13 downto 0);
signal sign_i_d					: std_logic;
signal sign_q_d					: std_logic;

begin

process(RESET,CLK)
begin
	if RESET = '1' then
		i_sin_out <= (others => '0');
		i_cos_out <= (others => '0');
	elsif (CLK'event and CLK='1') then
		if SWAP_IQ = '1' then
			i_cos_out <= SIN_IN;
			i_sin_out <= COS_IN;
		else
			i_cos_out <= COS_IN;
			i_sin_out <= SIN_IN;
		end if;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		sign_i_d <= '0';
		sign_q_d <= '0';
	elsif (CLK'event and CLK='1') then
		sign_i_d <= SIGN_I;
		sign_q_d <= SIGN_Q;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		COS_OUT <= (others => '0');
		SIN_OUT <= (others => '0');
	elsif (CLK'event and CLK='1') then
		if sign_q_d = '1' then
			SIN_OUT <= -i_sin_out;
		else
			SIN_OUT <= i_sin_out;
		end if;
		
		if sign_i_d = '1' then
			COS_OUT <= -i_cos_out;
		else
			COS_OUT <= i_cos_out;
		end if;
	end if;
end process;

end arc_DEMAPPING_V2;