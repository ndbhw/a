library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

Library UNISIM;
use UNISIM.vcomponents.all;

entity CFR_OPD_PWR  is
   port (
          RESET             : in  std_logic;
          CLK               : in  std_logic;
          
          FS_10M            : in  std_logic;
          
          CFROUT_I          : in  std_logic_vector(15 downto 0);
          CFROUT_Q          : in  std_logic_vector(15 downto 0);
          
          OPD_PWR_UPDATE    : out std_logic;
          OPD_PWR           : out std_logic_vector(31 downto 0)
        );
end CFR_OPD_PWR;

architecture arc_CFR_OPD_PWR of CFR_OPD_PWR is

signal i_fs_10m_f           : std_logic;
signal i_fs_10m_ff          : std_logic;
signal i_fs_10m_p           : std_logic;
signal i_fs_10m_pd          : std_logic;

signal i_IAIN               : std_logic_vector(29 downto 0);
signal i_IBIN               : std_logic_vector(17 downto 0);
signal i_QAIN               : std_logic_vector(29 downto 0);
signal i_QBIN               : std_logic_vector(17 downto 0);

--signal i_cnt_500us          : std_logic_vector(16 downto 0); --"11101111111111111" 122879 samples in 245.76Msps
signal i_cnt_500us          : std_logic_vector(17 downto 0); --"100101011111111111" 153600 samples in 307.2Msps
signal i_500us_tog          : std_logic;
signal i_pwr_updata         : std_logic;
signal i_pwr_updata_d       : std_logic;
SIGNAL i_pwr_updata_dd      : std_logic;

signal i_opmode             : std_logic_vector(6 downto 0);

signal i_inphase_pwr        : std_logic_vector(47 downto 0);
signal i_quphase_pwr        : std_logic_vector(47 downto 0);
signal i_pwr_sum            : std_logic_vector(48 downto 0);
signal i_pwr_307            : std_logic_vector(31 downto 0);

constant i_inmode           : std_logic_vector(4 downto 0) := "10001";
constant i_alumode          : std_logic_vector(3 downto 0) := "0000";

begin

process(RESET,CLK)
begin
  if RESET = '1' then
    i_fs_10m_f <= '0';
    i_fs_10m_ff <= '0';
    i_fs_10m_p <= '0';
  elsif rising_edge(CLK) then
    i_fs_10m_f <= FS_10M;
    i_fs_10m_ff <= i_fs_10m_f;
    
    if (i_fs_10m_f = '1') and (i_fs_10m_ff = '0') then
      i_fs_10m_p <= '1';
    else
      i_fs_10m_p <= '0';
    end if;
  end if;
end process;

process(RESET,CLK)
begin
  if RESET = '1' then
    i_cnt_500us <= (others => '0');
    i_500us_tog <= '0';
    i_pwr_updata <= '0';
    i_pwr_updata_d <= '0';
    i_pwr_updata_dd <= '0'; -- only 307.2
  elsif rising_edge(CLK) then
    --if (i_fs_10m_p = '1') or (i_cnt_500us = "11101111111111111") then
    if (i_fs_10m_p = '1') or (i_cnt_500us = "100101011111111111") then
       i_cnt_500us <= (others => '0');
    else
       i_cnt_500us <= i_cnt_500us + 1;
    end if;
    
    --if i_cnt_500us = "11101111111111111" then
    if i_cnt_500us = "100101011111111111" then
       i_500us_tog <= '1';
    else
       i_500us_tog <= '0';
    end if;
    
    i_pwr_updata <= i_500us_tog;
    i_pwr_updata_d <= i_pwr_updata;
    i_pwr_updata_dd <= i_pwr_updata_d; -- only 307.2
  end if;
end process;

process(RESET,CLK)
begin
  if RESET = '1' then
    i_opmode <= "0000000";
  elsif rising_edge(CLK) then
    if (i_fs_10m_p = '1') or (i_500us_tog = '1') then
      i_opmode <= "0000101"; -- I^2 + Q^2 only
    else
      i_opmode <= "0100101"; -- P + (I^2 + Q^2) acc. mode
    end if;
  end if;
end process;

i_IAIN <= sign_extension(CFROUT_I, 30);
i_IBIN <= sign_extension(CFROUT_I, 18);
i_QAIN <= sign_extension(CFROUT_Q, 30);
i_QBIN <= sign_extension(CFROUT_Q, 18);

--========================================================================
u_IPWR_MULTACC : DSP48E1
   generic map (
      -- Feature Control Attributes: Data Path Selection
      A_INPUT => "DIRECT",               -- Selects A input source, "DIRECT" (A port) or "CASCADE" (ACIN port)
      B_INPUT => "DIRECT",               -- Selects B input source, "DIRECT" (B port) or "CASCADE" (BCIN port)
      USE_DPORT => FALSE,                -- Select D port usage (TRUE or FALSE)
      USE_MULT => "MULTIPLY",            -- Select multiplier usage ("MULTIPLY", "DYNAMIC", or "NONE")
      USE_SIMD => "ONE48",               -- SIMD selection ("ONE48", "TWO24", "FOUR12")
      -- Pattern Detector Attributes: Pattern Detection Configuration
      AUTORESET_PATDET => "NO_RESET",    -- "NO_RESET", "RESET_MATCH", "RESET_NOT_MATCH" 
      MASK => X"3fffffffffff",           -- 48-bit mask value for pattern detect (1=ignore)
      PATTERN => X"000000000000",        -- 48-bit pattern match for pattern detect
      SEL_MASK => "MASK",                -- "C", "MASK", "ROUNDING_MODE1", "ROUNDING_MODE2" 
      SEL_PATTERN => "PATTERN",          -- Select pattern value ("PATTERN" or "C")
      USE_PATTERN_DETECT => "NO_PATDET", -- Enable pattern detect ("PATDET" or "NO_PATDET")
      -- Register Control Attributes: Pipeline Register Configuration
      ACASCREG => 1,                     -- Number of pipeline stages between A/ACIN and ACOUT (0, 1 or 2)
      ADREG => 1,                        -- Number of pipeline stages for pre-adder (0 or 1)
      ALUMODEREG => 1,                   -- Number of pipeline stages for ALUMODE (0 or 1)
      AREG => 1,                         -- Number of pipeline stages for A (0, 1 or 2)
      BCASCREG => 1,                     -- Number of pipeline stages between B/BCIN and BCOUT (0, 1 or 2)
      BREG => 1,                         -- Number of pipeline stages for B (0, 1 or 2)
      CARRYINREG => 1,                   -- Number of pipeline stages for CARRYIN (0 or 1)
      CARRYINSELREG => 1,                -- Number of pipeline stages for CARRYINSEL (0 or 1)
      CREG => 1,                         -- Number of pipeline stages for C (0 or 1)
      DREG => 1,                         -- Number of pipeline stages for D (0 or 1)
      INMODEREG => 1,                    -- Number of pipeline stages for INMODE (0 or 1)
      MREG => 1,                         -- Number of multiplier pipeline stages (0 or 1)
      OPMODEREG => 1,                    -- Number of pipeline stages for OPMODE (0 or 1)
      PREG => 1                          -- Number of pipeline stages for P (0 or 1)
   )
   port map (
      -- Cascade: 30-bit (each) output: Cascade Ports
      ACOUT => open,                   -- 30-bit output: A port cascade output
      BCOUT => open,                   -- 18-bit output: B port cascade output
      CARRYCASCOUT => open,     -- 1-bit output: Cascade carry output
      MULTSIGNOUT => open,       -- 1-bit output: Multiplier sign cascade output
      PCOUT => open,                   -- 48-bit output: Cascade output
      -- Control: 1-bit (each) output: Control Inputs/Status Bits
      OVERFLOW => open,             -- 1-bit output: Overflow in add/acc output
      PATTERNBDETECT => open, -- 1-bit output: Pattern bar detect output
      PATTERNDETECT => open,   -- 1-bit output: Pattern detect output
      UNDERFLOW => open,           -- 1-bit output: Underflow in add/acc output
      -- Data: 4-bit (each) output: Data Ports
      CARRYOUT => open,             -- 4-bit output: Carry output
      P => i_inphase_pwr,                           -- 48-bit output: Primary data output
      -- Cascade: 30-bit (each) input: Cascade Ports
      ACIN => (others => '0'),                     -- 30-bit input: A cascade data input
      BCIN => (others => '0'),                     -- 18-bit input: B cascade input
      CARRYCASCIN => '0',       -- 1-bit input: Cascade carry input
      MULTSIGNIN => '0',         -- 1-bit input: Multiplier sign input
      PCIN => (others => '0'),                     -- 48-bit input: P cascade input
      -- Control: 4-bit (each) input: Control Inputs/Status Bits
      ALUMODE => i_alumode,               -- 4-bit input: ALU control input
      CARRYINSEL => (others => '0'),         -- 3-bit input: Carry select input
      CLK => CLK,                       -- 1-bit input: Clock input
      INMODE => i_inmode,                 -- 5-bit input: INMODE control input
      OPMODE => i_opmode,                 -- 7-bit input: Operation mode input
      -- Data: 30-bit (each) input: Data Ports
      A => i_IAIN,                           -- 30-bit input: A data input
      B => i_IBIN,                           -- 18-bit input: B data input
      C => (others => '0'),                           -- 48-bit input: C data input
      CARRYIN => '0',               -- 1-bit input: Carry input signal
      D => (others => '0'),                           -- 25-bit input: D data input
      -- Reset/Clock Enable: 1-bit (each) input: Reset/Clock Enable Inputs
      CEA1 => '1',                     -- 1-bit input: Clock enable input for 1st stage AREG
      CEA2 => '1',                     -- 1-bit input: Clock enable input for 2nd stage AREG
      CEAD => '1',                     -- 1-bit input: Clock enable input for ADREG
      CEALUMODE => '1',           -- 1-bit input: Clock enable input for ALUMODE
      CEB1 => '1',                     -- 1-bit input: Clock enable input for 1st stage BREG
      CEB2 => '1',                     -- 1-bit input: Clock enable input for 2nd stage BREG
      CEC => '0',                       -- 1-bit input: Clock enable input for CREG
      CECARRYIN => '0',           -- 1-bit input: Clock enable input for CARRYINREG
      CECTRL => '1',                 -- 1-bit input: Clock enable input for OPMODEREG and CARRYINSELREG
      CED => '0',                       -- 1-bit input: Clock enable input for DREG
      CEINMODE => '1',             -- 1-bit input: Clock enable input for INMODEREG
      CEM => '1',                       -- 1-bit input: Clock enable input for MREG
      CEP => '1',                       -- 1-bit input: Clock enable input for PREG
      RSTA => '0',                     -- 1-bit input: Reset input for AREG
      RSTALLCARRYIN => '0',   -- 1-bit input: Reset input for CARRYINREG
      RSTALUMODE => '0',         -- 1-bit input: Reset input for ALUMODEREG
      RSTB => '0',                     -- 1-bit input: Reset input for BREG
      RSTC => '0',                     -- 1-bit input: Reset input for CREG
      RSTCTRL => '0',               -- 1-bit input: Reset input for OPMODEREG and CARRYINSELREG
      RSTD => '0',                     -- 1-bit input: Reset input for DREG and ADREG
      RSTINMODE => '0',           -- 1-bit input: Reset input for INMODEREG
      RSTM => '0',                     -- 1-bit input: Reset input for MREG
      RSTP => '0'                      -- 1-bit input: Reset input for PREG
   );
   
u_QPWR_MULTACC : DSP48E1
   generic map (
      -- Feature Control Attributes: Data Path Selection
      A_INPUT => "DIRECT",               -- Selects A input source, "DIRECT" (A port) or "CASCADE" (ACIN port)
      B_INPUT => "DIRECT",               -- Selects B input source, "DIRECT" (B port) or "CASCADE" (BCIN port)
      USE_DPORT => FALSE,                -- Select D port usage (TRUE or FALSE)
      USE_MULT => "MULTIPLY",            -- Select multiplier usage ("MULTIPLY", "DYNAMIC", or "NONE")
      USE_SIMD => "ONE48",               -- SIMD selection ("ONE48", "TWO24", "FOUR12")
      -- Pattern Detector Attributes: Pattern Detection Configuration
      AUTORESET_PATDET => "NO_RESET",    -- "NO_RESET", "RESET_MATCH", "RESET_NOT_MATCH" 
      MASK => X"3fffffffffff",           -- 48-bit mask value for pattern detect (1=ignore)
      PATTERN => X"000000000000",        -- 48-bit pattern match for pattern detect
      SEL_MASK => "MASK",                -- "C", "MASK", "ROUNDING_MODE1", "ROUNDING_MODE2" 
      SEL_PATTERN => "PATTERN",          -- Select pattern value ("PATTERN" or "C")
      USE_PATTERN_DETECT => "NO_PATDET", -- Enable pattern detect ("PATDET" or "NO_PATDET")
      -- Register Control Attributes: Pipeline Register Configuration
      ACASCREG => 1,                     -- Number of pipeline stages between A/ACIN and ACOUT (0, 1 or 2)
      ADREG => 1,                        -- Number of pipeline stages for pre-adder (0 or 1)
      ALUMODEREG => 1,                   -- Number of pipeline stages for ALUMODE (0 or 1)
      AREG => 1,                         -- Number of pipeline stages for A (0, 1 or 2)
      BCASCREG => 1,                     -- Number of pipeline stages between B/BCIN and BCOUT (0, 1 or 2)
      BREG => 1,                         -- Number of pipeline stages for B (0, 1 or 2)
      CARRYINREG => 1,                   -- Number of pipeline stages for CARRYIN (0 or 1)
      CARRYINSELREG => 1,                -- Number of pipeline stages for CARRYINSEL (0 or 1)
      CREG => 1,                         -- Number of pipeline stages for C (0 or 1)
      DREG => 1,                         -- Number of pipeline stages for D (0 or 1)
      INMODEREG => 1,                    -- Number of pipeline stages for INMODE (0 or 1)
      MREG => 1,                         -- Number of multiplier pipeline stages (0 or 1)
      OPMODEREG => 1,                    -- Number of pipeline stages for OPMODE (0 or 1)
      PREG => 1                          -- Number of pipeline stages for P (0 or 1)
   )
   port map (
      -- Cascade: 30-bit (each) output: Cascade Ports
      ACOUT => open,                   -- 30-bit output: A port cascade output
      BCOUT => open,                   -- 18-bit output: B port cascade output
      CARRYCASCOUT => open,     -- 1-bit output: Cascade carry output
      MULTSIGNOUT => open,       -- 1-bit output: Multiplier sign cascade output
      PCOUT => open,                   -- 48-bit output: Cascade output
      -- Control: 1-bit (each) output: Control Inputs/Status Bits
      OVERFLOW => open,             -- 1-bit output: Overflow in add/acc output
      PATTERNBDETECT => open, -- 1-bit output: Pattern bar detect output
      PATTERNDETECT => open,   -- 1-bit output: Pattern detect output
      UNDERFLOW => open,           -- 1-bit output: Underflow in add/acc output
      -- Data: 4-bit (each) output: Data Ports
      CARRYOUT => open,             -- 4-bit output: Carry output
      P => i_quphase_pwr,                           -- 48-bit output: Primary data output
      -- Cascade: 30-bit (each) input: Cascade Ports
      ACIN => (others => '0'),                     -- 30-bit input: A cascade data input
      BCIN => (others => '0'),                     -- 18-bit input: B cascade input
      CARRYCASCIN => '0',       -- 1-bit input: Cascade carry input
      MULTSIGNIN => '0',         -- 1-bit input: Multiplier sign input
      PCIN => (others => '0'),                     -- 48-bit input: P cascade input
      -- Control: 4-bit (each) input: Control Inputs/Status Bits
      ALUMODE => i_alumode,               -- 4-bit input: ALU control input
      CARRYINSEL => (others => '0'),         -- 3-bit input: Carry select input
      CLK => CLK,                       -- 1-bit input: Clock input
      INMODE => i_inmode,                 -- 5-bit input: INMODE control input
      OPMODE => i_opmode,                 -- 7-bit input: Operation mode input
      -- Data: 30-bit (each) input: Data Ports
      A => i_QAIN,                           -- 30-bit input: A data input
      B => i_QBIN,                           -- 18-bit input: B data input
      C => (others => '0'),                           -- 48-bit input: C data input
      CARRYIN => '0',               -- 1-bit input: Carry input signal
      D => (others => '0'),                           -- 25-bit input: D data input
      -- Reset/Clock Enable: 1-bit (each) input: Reset/Clock Enable Inputs
      CEA1 => '1',                     -- 1-bit input: Clock enable input for 1st stage AREG
      CEA2 => '1',                     -- 1-bit input: Clock enable input for 2nd stage AREG
      CEAD => '1',                     -- 1-bit input: Clock enable input for ADREG
      CEALUMODE => '1',           -- 1-bit input: Clock enable input for ALUMODE
      CEB1 => '1',                     -- 1-bit input: Clock enable input for 1st stage BREG
      CEB2 => '1',                     -- 1-bit input: Clock enable input for 2nd stage BREG
      CEC => '0',                       -- 1-bit input: Clock enable input for CREG
      CECARRYIN => '0',           -- 1-bit input: Clock enable input for CARRYINREG
      CECTRL => '1',                 -- 1-bit input: Clock enable input for OPMODEREG and CARRYINSELREG
      CED => '0',                       -- 1-bit input: Clock enable input for DREG
      CEINMODE => '1',             -- 1-bit input: Clock enable input for INMODEREG
      CEM => '1',                       -- 1-bit input: Clock enable input for MREG
      CEP => '1',                       -- 1-bit input: Clock enable input for PREG
      RSTA => '0',                     -- 1-bit input: Reset input for AREG
      RSTALLCARRYIN => '0',   -- 1-bit input: Reset input for CARRYINREG
      RSTALUMODE => '0',         -- 1-bit input: Reset input for ALUMODEREG
      RSTB => '0',                     -- 1-bit input: Reset input for BREG
      RSTC => '0',                     -- 1-bit input: Reset input for CREG
      RSTCTRL => '0',               -- 1-bit input: Reset input for OPMODEREG and CARRYINSELREG
      RSTD => '0',                     -- 1-bit input: Reset input for DREG and ADREG
      RSTINMODE => '0',           -- 1-bit input: Reset input for INMODEREG
      RSTM => '0',                     -- 1-bit input: Reset input for MREG
      RSTP => '0'                      -- 1-bit input: Reset input for PREG
   );
   
--=======================================================================================

process(RESET,CLK)
begin
  if RESET = '1' then
    i_pwr_sum <= (others => '0');
  elsif rising_edge(CLK) then
    if i_pwr_updata = '1' then
      i_pwr_sum <= ('0' & i_inphase_pwr) + ('0'& i_quphase_pwr);
    end if;
  end if;
end process;

process(RESET,CLK)
begin
  if RESET = '1' then
    i_pwr_307 <= (others => '0');
    OPD_PWR_UPDATE <= '0';
    OPD_PWR <= (others => '0');
  elsif rising_edge(CLK) then
    if i_pwr_updata_d = '1' then
      --OPD_PWR <= i_pwr_sum(48 downto 17);
      i_pwr_307 <= i_pwr_sum(48 downto 17);
    end if;
    
    OPD_PWR <= i_pwr_307 - ("000" & i_pwr_307(31 downto 3));
 
    --OPD_PWR_UPDATE <= i_pwr_updata_d;
    OPD_PWR_UPDATE <= i_pwr_updata_dd;
  end if;
end process;

end arc_CFR_OPD_PWR;
