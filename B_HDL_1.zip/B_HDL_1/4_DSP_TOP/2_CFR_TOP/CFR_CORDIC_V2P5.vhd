-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity CFR_CORDIC_V2P5 is

		port (
						RESET				    :	in	std_logic;
						CLK					    : in	std_logic;
						CLOCK_UNSTABLE	: in	std_logic;
						
						SIGNAL_I		    : in	std_logic_vector(15 downto 0);
						SIGNAL_Q		    : in	std_logic_vector(15 downto 0);
						
						MAGNITUDE_PRE		:	out	std_logic_vector(15 downto 0);
						MAGNITUDE		    :	out	std_logic_vector(15 downto 0);
						COS					    :	out	std_logic_vector(13 downto 0);
						SIN					    :	out	std_logic_vector(13 downto 0)
						
					);
end CFR_CORDIC_V2P5;

architecture arc_CFR_CORDIC_V2P5 of CFR_CORDIC_V2P5 is

component MAPPING_V2
		port (
						RESET				: in	std_logic;
						CLK					: in	std_logic;
						
						SIGNAL_I		: in	std_logic_vector(15 downto 0);
						SIGNAL_Q		: in	std_logic_vector(15 downto 0);
						
						SIGNAL_I_OUT	: out	std_logic_vector(15 downto 0);
						SIGNAL_Q_OUT	: out	std_logic_vector(15 downto 0);
						
						SIGN_I			: out	std_logic;
						SIGN_Q			: out	std_logic;
						SWAP_IQ			: out	std_logic
						
					);
end component;

component GAIN_COMPENSATION_V2
			port (
						RESET 							: in	std_logic;
						CLK									: in	std_logic;
						
						CORDIC_AMPLITUDE		: in	std_logic_vector(17 downto 0);
						
						COMPENSATED_AMPLITUDE_PRE	: out	std_logic_vector(15 downto 0);
						COMPENSATED_AMPLITUDE	    : out	std_logic_vector(15 downto 0)
						);
end component;

component ALL_STAGE_V2
			port (
						RESET 							: in	std_logic;
						CLK									: in	std_logic;
						
						SIGNAL_I_IN					:	in	std_logic_vector(15 downto 0);
						SIGNAL_Q_IN					:	in	std_logic_vector(15 downto 0);
						
						CORDIC_MAGNITUDE		:	out	std_logic_vector(17 downto 0);
						
						OUTPUT_STAGE_1			: out	std_logic;
						OUTPUT_STAGE_2			: out	std_logic;
						OUTPUT_STAGE_3			: out	std_logic;
						OUTPUT_STAGE_4			: out	std_logic;
						OUTPUT_STAGE_5			: out	std_logic
						);
end component;

component SINCOS_V2P5
			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							CLOCK_UNSTABLE					: in	std_logic;
							
							CORDIC_STAGE_1		:	in	std_logic;
							CORDIC_STAGE_2		:	in	std_logic;
							CORDIC_STAGE_3		:	in	std_logic;
							CORDIC_STAGE_4		:	in	std_logic;
							CORDIC_STAGE_5		:	in	std_logic;
							
							SIN_OUT						:	out	std_logic_vector(13 downto 0);
							COS_OUT						:	out	std_logic_vector(13 downto 0)
						);
end component;

component DEMAPPING_V2
		port (
					RESET						: in	std_logic;
					CLK							: in	std_logic;
					
					SIN_IN					:	in	std_logic_vector(13 downto 0);
					COS_IN					:	in	std_logic_vector(13 downto 0);
					
					SIGN_I					: in	std_logic;
					SIGN_Q					: in	std_logic;
					SWAP_IQ					:	in	std_logic;
					
					COS_OUT					:	out	std_logic_vector(13 downto 0);
					SIN_OUT					:	out	std_logic_vector(13 downto 0)
					);
end component;

signal i_map_out	: std_logic_vector(15 downto 0);
signal q_map_out	: std_logic_vector(15 downto 0);
signal i_sign_out	: std_logic;
signal q_sign_out	: std_logic;
signal swap_iq_sig	: std_logic;

signal cordic_mag_sig	: std_logic_vector(17 downto 0);
signal out_stage_1	: std_logic;
signal out_stage_2	: std_logic;
signal out_stage_3	: std_logic;
signal out_stage_4	: std_logic;
signal out_stage_5	: std_logic;

signal sig_sin			: std_logic_vector(13 downto 0);
signal sig_cos			: std_logic_vector(13 downto 0);

begin

u_map_blk :  MAPPING_V2
		port map(
						RESET				=> RESET, --: in	std_logic;
						CLK					=> CLK, --: in	std_logic;
						
						SIGNAL_I		=> SIGNAL_I, --: in	std_logic_vector(15 downto 0);
						SIGNAL_Q		=> SIGNAL_Q, --: in	std_logic_vector(15 downto 0);
						
						SIGNAL_I_OUT	=> i_map_out, --: out	std_logic_vector(15 downto 0);
						SIGNAL_Q_OUT	=> q_map_out, --: out	std_logic_vector(15 downto 0);
						
						SIGN_I			=> i_sign_out, --: out	std_logic;
						SIGN_Q			=> q_sign_out, --: out	std_logic;
						SWAP_IQ			=> swap_iq_sig --: out	std_logic
						
					);


u_gain_comp_blk : GAIN_COMPENSATION_V2
			port map(
						RESET 							=> RESET, --: in	std_logic;
						CLK									=> CLK, --: in	std_logic;
						
						CORDIC_AMPLITUDE		=> cordic_mag_sig, --: in	std_logic_vector(17 downto 0);
						
						COMPENSATED_AMPLITUDE_PRE	=> MAGNITUDE_PRE,  --: out	std_logic_vector(15 downto 0);
						COMPENSATED_AMPLITUDE	    => MAGNITUDE  --: out	std_logic_vector(15 downto 0)
						);


u_all_stage_blk : ALL_STAGE_V2
			port map(
						RESET 							=> RESET, --: in	std_logic;
						CLK									=> CLK, --: in	std_logic;
						
						SIGNAL_I_IN					=> i_map_out, --:	in	std_logic_vector(15 downto 0);
						SIGNAL_Q_IN					=> q_map_out, --:	in	std_logic_vector(15 downto 0);
						
						CORDIC_MAGNITUDE		=> cordic_mag_sig, --:	out	std_logic_vector(17 downto 0);
						
						OUTPUT_STAGE_1			=> out_stage_1, --: out	std_logic;
						OUTPUT_STAGE_2			=> out_stage_2, --: out	std_logic;
						OUTPUT_STAGE_3			=> out_stage_3, --: out	std_logic;
						OUTPUT_STAGE_4			=> out_stage_4, --: out	std_logic;
						OUTPUT_STAGE_5			=> out_stage_5  --: out	std_logic
						);


u_sincos_lut_blk : SINCOS_V2P5
			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK, --: in	std_logic;
							CLOCK_UNSTABLE		=> CLOCK_UNSTABLE,  --			: in	std_logic;
							
							CORDIC_STAGE_1		=> out_stage_1, --:	in	std_logic;
							CORDIC_STAGE_2		=> out_stage_2, --:	in	std_logic;
							CORDIC_STAGE_3		=> out_stage_3, --:	in	std_logic;
							CORDIC_STAGE_4		=> out_stage_4, --:	in	std_logic;
							CORDIC_STAGE_5		=> out_stage_5, --:	in	std_logic;
							
							SIN_OUT						=> sig_sin, --:	out	std_logic_vector(13 downto 0);
							COS_OUT						=> sig_cos  --:	out	std_logic_vector(13 downto 0)
						);


u_demap_blk : DEMAPPING_V2
		port map(
					RESET						=> RESET, --: in	std_logic;
					CLK							=> CLK, --: in	std_logic;
					
					SIN_IN					=> sig_sin, --:	in	std_logic_vector(13 downto 0);
					COS_IN					=> sig_cos, --:	in	std_logic_vector(13 downto 0);
					
					SIGN_I					=> i_sign_out, --: in	std_logic;
					SIGN_Q					=> q_sign_out, --: in	std_logic;
					SWAP_IQ					=> swap_iq_sig, --:	in	std_logic;
					
					COS_OUT					=> COS, --:	out	std_logic_vector(13 downto 0);
					SIN_OUT					=> SIN  --:	out	std_logic_vector(13 downto 0)
					);

end arc_CFR_CORDIC_V2P5;