-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
library UNISIM;
use UNISIM.VComponents.all;

entity COMPLEX_MULT_V2P5 is

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM         : in  std_logic;
							INPUTA_REAL				: in	std_logic_vector(15 downto 0);
							INPUTA_IMAG				: in	std_logic_vector(15 downto 0);
							INPUTB_REAL				: in	std_logic_vector(15 downto 0);
							INPUTB_IMAG				: in	std_logic_vector(15 downto 0);
							
							OUT_REAL					: out	std_logic_vector(16 downto 0);
							OUT_IMAG					: out	std_logic_vector(16 downto 0)
						);
end COMPLEX_MULT_V2P5;

architecture arc_COMPLEX_MULT_V2P5 of COMPLEX_MULT_V2P5 is

--component cfr_compmult_16x16_v2
--  PORT (
--    aclk : IN STD_LOGIC;
--    s_axis_a_tvalid : IN STD_LOGIC;
--    s_axis_a_tdata : IN STD_LOGIC_VECTOR(31 DOWNTO 0);
--    s_axis_b_tvalid : IN STD_LOGIC;
--    s_axis_b_tdata : IN STD_LOGIC_VECTOR(31 DOWNTO 0);
--    m_axis_dout_tvalid : OUT STD_LOGIC;
--    m_axis_dout_tdata : OUT STD_LOGIC_VECTOR(79 DOWNTO 0)
--  );
--END component;

COMPONENT cfr_compmult_16x16_v2p5
  PORT (
    aclk : IN STD_LOGIC;
    s_axis_a_tvalid : IN STD_LOGIC;
    s_axis_a_tdata : IN STD_LOGIC_VECTOR(31 DOWNTO 0);
    s_axis_b_tvalid : IN STD_LOGIC;
    s_axis_b_tdata : IN STD_LOGIC_VECTOR(31 DOWNTO 0);
    m_axis_dout_tvalid : OUT STD_LOGIC;
    m_axis_dout_tdata : OUT STD_LOGIC_VECTOR(79 DOWNTO 0)
  );
END COMPONENT;

--component cfr_compmult_16x16_v2
--  PORT (
--    ar: in std_logic_vector(15 downto 0);
--	  ai: in std_logic_vector(15 downto 0);
--	  br: in std_logic_vector(15 downto 0);
--	  bi: in std_logic_vector(15 downto 0);
--	  clk: in std_logic;
--	  pr: out std_logic_vector(32 downto 0);
--	  pi: out std_logic_vector(32 downto 0)
--  );
--END component;

component ROUNDING
   generic(
      i_bit : integer;
      o_bit : integer
   );
   port( 
      RESET : in  std_logic;
      CLK   : in  std_logic;
      IND   : in  std_logic_vector(i_bit-1 downto 0);
      RES   : out std_logic_vector(o_bit-1 downto 0)
   );
end component;

component SAT
   generic(
      i_bit : integer;
      o_bit : integer
   );
   port( 
      RESET : in  std_logic;
      CLK   : in  std_logic;
      IND   : in  std_logic_vector(i_bit-1 downto 0);
      RES   : out std_logic_vector(o_bit-1 downto 0)
   );
end component;

signal in_tog			: std_logic;

signal round_ip_real	: std_logic_vector(18 downto 0);
signal round_ip_imag	: std_logic_vector(18 downto 0);
signal round_ip_real_sat	: std_logic_vector(15 downto 0);
signal round_ip_imag_sat	: std_logic_vector(15 downto 0);
signal round_ip_real_d	: std_logic_vector(16 downto 0);
signal round_ip_imag_d	: std_logic_vector(16 downto 0);

--signal ip_preal      : std_logic_vector(32 downto 0);
--signal ip_pimag      : std_logic_vector(32 downto 0);

signal temp_A_32, temp_B_32	: std_logic_vector(31 downto 0);

signal axi_tdata_out	: std_logic_vector(79 downto 0);

begin

temp_A_32 <= INPUTA_IMAG & INPUTA_REAL;
temp_B_32 <= INPUTB_IMAG & INPUTB_REAL;
	
--u_ip_comp_mult : cfr_compmult_16x16_v2
--  PORT map(
--    aclk => CLK, --: IN STD_LOGIC;
--    s_axis_a_tvalid => '1', --: IN STD_LOGIC;
--    s_axis_a_tdata => temp_A_32, --: IN STD_LOGIC_VECTOR(31 DOWNTO 0);
--    s_axis_b_tvalid => '1', --: IN STD_LOGIC;
--    s_axis_b_tdata => temp_B_32, --: IN STD_LOGIC_VECTOR(31 DOWNTO 0);
--    m_axis_dout_tvalid => open, --: OUT STD_LOGIC;
--    m_axis_dout_tdata => axi_tdata_out  --: OUT STD_LOGIC_VECTOR(79 DOWNTO 0)
--  );
  
u_ip_comp_mult : cfr_compmult_16x16_v2p5
  PORT MAP (
    aclk => CLK,
    s_axis_a_tvalid => '1',
    s_axis_a_tdata => temp_A_32,
    s_axis_b_tvalid => '1',
    s_axis_b_tdata => temp_B_32,
    m_axis_dout_tvalid => open,
    m_axis_dout_tdata => axi_tdata_out
  );

process(RESET,CLK)
begin
	if RESET = '1' then
		in_tog <= '0';
	elsif (CLK'event and CLK='1') then
		in_tog <= not in_tog;
	end if;
end process;
   
u_round_ipreal : ROUNDING
   generic map(
      i_bit => 33, --: integer;
      o_bit => 19  --: integer
   )
   port map( 
      RESET => RESET, --: in  std_logic;
      CLK   => CLK, --: in  std_logic;
      IND   => axi_tdata_out(32 downto 0), --ip_preal, --: in  std_logic_vector(i_bit-1 downto 0);
      RES   => round_ip_real  --: out std_logic_vector(o_bit-1 downto 0)
   );
   
u_round_ipimag : ROUNDING
   generic map(
      i_bit => 33, --: integer;
      o_bit => 19  --: integer
   )
   port map( 
      RESET => RESET, --: in  std_logic;
      CLK   => CLK, --: in  std_logic;
      IND   => axi_tdata_out(72 downto 40), --ip_pimag, --: in  std_logic_vector(i_bit-1 downto 0);
      RES   => round_ip_imag  --: out std_logic_vector(o_bit-1 downto 0)
   );
   
u_sat_ip_real : SAT
   generic map(
      i_bit => 19, --: integer;
      o_bit => 16  --: integer
   )
   port map( 
      RESET => RESET, --: in  std_logic;
      CLK   => CLK, --: in  std_logic;
      IND   => round_ip_real, --: in  std_logic_vector(i_bit-1 downto 0);
      RES   => round_ip_real_sat  --: out std_logic_vector(o_bit-1 downto 0)
   );
   
u_sat_ip_imag : SAT
   generic map(
      i_bit => 19, --: integer;
      o_bit => 16  --: integer
   )
   port map( 
      RESET => RESET, --: in  std_logic;
      CLK   => CLK, --: in  std_logic;
      IND   => round_ip_imag, --: in  std_logic_vector(i_bit-1 downto 0);
      RES   => round_ip_imag_sat  --: out std_logic_vector(o_bit-1 downto 0)
   );
   
--process(RESET,CLK)
--begin
--  if RESET = '1' then
--    round_ip_real_d <= (others => '0');
--    round_ip_imag_d <= (others => '0');
--    OUT_REAL <= (others => '0');
--    OUT_IMAG <= (others => '0');
--  elsif (CLK'event and CLK='1') then
--    round_ip_real_d <= round_ip_real_sat(15) & round_ip_real_sat;
--    round_ip_imag_d <= round_ip_imag_sat(15) & round_ip_imag_sat;
--    
--    if in_tog = '1' then  --INPUT_TOGGLE
--      OUT_REAL <= (round_ip_real_sat(15) & round_ip_real_sat) + round_ip_real_d;
--      OUT_IMAG <= (round_ip_imag_sat(15) & round_ip_imag_sat) + round_ip_imag_d;
--    end if;
--  end if;
--end process;

OUT_REAL <= round_ip_real_sat(15) & round_ip_real_sat;
OUT_IMAG <= round_ip_imag_sat(15) & round_ip_imag_sat;
   
end arc_COMPLEX_MULT_V2P5;
