library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_signed.all;

entity SAT is
   generic(
      i_bit : integer;
      o_bit : integer
   );
   port( 
      RESET : in  std_logic;
      CLK   : in  std_logic;
      IND   : in  std_logic_vector(i_bit-1 downto 0);
      RES   : out std_logic_vector(o_bit-1 downto 0)
   );
end SAT;

architecture ARC_SAT of SAT is
   signal posmax : std_logic_vector(i_bit-1 downto 0) := (others => '0');
   signal negmax : std_logic_vector(i_bit-1 downto 0) := (others => '1');
begin

   G_proc : for I in 0 to o_bit-2 generate
      posmax(I) <= '1'; negmax(I) <= '0';
   end generate;

   process(RESET,CLK) begin
      if(RESET = '1') then
         RES <= (others=>'0');
      elsif(CLK'event and CLK='1') then
         if   (IND > posmax) then RES <= posmax(o_bit-1 downto 0);
         elsif(IND < negmax) then RES <= negmax(o_bit-1 downto 0);
         else                     RES <= IND(o_bit-1 downto 0);
         end if;
      end if;
   end process;

end ARC_SAT;
