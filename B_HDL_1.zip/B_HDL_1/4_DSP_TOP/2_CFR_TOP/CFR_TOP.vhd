----------------------------------------------------------------------------------
-- Company       : Samsung Electronics  
-- Engineer      : SHT Lab. 2Part. WG4
-- 
-- Create Date   : 2016.09.22 
-- Design Name   : CFR_TOP
-- Module Name   : CFR_TOP - arc_CFR_TOP 
-- Project Name  : FD-MIMO, 8T8R (4 Traffic FPGAs, 32T32R) 
-- Target Devices: Kintex UltraScale+ ku9p, Xilinx
-- Tool versions : Vivado 2016.2, Xilinx
-- Description   :   
--
-- Dependencies  :  
--   
-- Revision      : 16.09.22 - v00. First Release
--        
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity CFR_TOP is
--generic (
--    TX_CFR_ANT_NUM                  : integer                       :=           8  -- The Number of TX Antenna Paths
--    FB_PATH_NUM                 : integer                       :=           4   -- The Number of FB Paths
--    );
            
port(
    CFR_INFO_OUT                : out std_logic_vector(31 downto 0);
    CFR_DATE_OUT                : out std_logic_vector(31 downto 0);
    CFR_STRUCT_OUT              : out std_logic_vector(31 downto 0);
    
    RST_CFR                     : in  std_logic;
    CLK_SYS                     : in  std_logic;                                 -- System Clock :  30.72 MHz
    CLK_SYSX2                   : in  std_logic;                                 --  2x(CLK_SYS) :  61.44 MHz
    CLK_SYSX3                   : in  std_logic;                                 --  3x(CLK_SYS) :  92.16 MHz
    CLK_SYSX4                   : in  std_logic;                                 --  4x(CLK_SYS) : 122.88 MHz
    CLK_SYSX5                   : in  std_logic;                                 --  5x(CLK_SYS) : 153.60 MHz
    CLK_SYSX6                   : in  std_logic;                                 --  6x(CLK_SYS) : 184.32 MHz
    CLK_SYSX8                   : in  std_logic;                                 --  8x(CLK_SYS) : 245.76 MHz
    CLK_SYSX10                  : in  std_logic;                                 -- 10x(CLK_SYS) : 307.20 MHz
    CLK_SYSX12                  : in  std_logic;                                 -- 12x(CLK_SYS) : 368.64 MHz
    CLK_SYSX16                  : in  std_logic;                                 -- 16x(CLK_SYS) : 491.52 MHz
    CLK_SYSX20                  : in  std_logic;                                 -- 20x(CLK_SYS) : 614.40 MHz
    
    INT_SYSPLL_LOCK_IN          : in  std_logic;
    
    DL_BFN_STRB_IN              : in  std_logic; -- 10msec frame sync
    DL_SSB_STRB_IN              : in  std_logic; -- SSB strb
    DL_BFN_STRB_OUT             : out std_logic; -- 10msec frame sync delayed out
    DL_SSB_STRB_OUT             : out std_logic; -- 10msec frame sync delayed out
    DL_TDD_IN                   : in  std_logic; -- TDD strobe signal in
    DL_TDD_OUT                  : out std_logic; -- Delayed TDD strobe signal out
    
    DL_BCF_ENB_IN               : in  std_logic; -- Beamforming calibration
    DL_BCF_ENB_OUT              : out std_logic;
    
    FBSW_AUTO_MODE_DONE_IN      : in  std_logic_vector(FB_PATH_NUM-1 downto 0); -- Feedback Switch Automode operation done flag
    
    CFR_PROC_DLY_OUT            : out std_logic_vector(31 downto 0);
    
    CFR_BYPASS_IN               : in  std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    
    CFR_TRSHD_IN                : in  std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    CFR_PEAK_SPACING_IN         : in  std_logic_array8(TX_CFR_ANT_NUM-1 downto 0);
    
    CFR_COEFF_UDT_ENB_IN        : in  std_logic_vector(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
    CFR_COEFF_WEN_IN            : in  std_logic_vector(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
    CFR_COEFF_WRADDR_IN         : in  std_logic_array10(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
    CFR_COEFF_WRDATA_IN         : in  std_logic_array32(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
    
    CFR_TAP_NUM_IN              : in  std_logic_array10(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
   
    DL_SYNC_IN                  : in  std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    DL_I_IN                     : in  std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    DL_Q_IN                     : in  std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    
    DL_SYNC_OUT                 : out std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    DL_I_OUT                    : out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    DL_Q_OUT                    : out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
                                                                                   
    DL_PIM_SYNC_OUT             : out std_logic;
    DL_PIM_I_OUT                : out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    DL_PIM_Q_OUT                : out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);

    CFR_HC_TRSHD_IN             : in  std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    CFR_HC_EN_IN                : in  std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    
    CFR_PWR_MSR_UDT_OUT         : out std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    CFR_PWR_OUT                 : out std_logic_array32(TX_CFR_ANT_NUM-1 downto 0);
    
    OPD_TRSHD_IN                : in  std_logic_array32(TX_CFR_ANT_NUM-1 downto 0);
    OPD_PWR_OUT                 : out std_logic_array32(TX_CFR_ANT_NUM-1 downto 0);
    SIG_SUS_FLAG_OUT            : out std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    
    DUMP_BFN_STRB_OUT           : out std_logic_vector(1 downto 0);
    DUMP_DATA_OUT               : out std_logic_array32(1 downto 0);
    DUMP_DVLD_OUT               : out std_logic_vector(1 downto 0);
    
    TEST_DATA_IN                : in  std_logic_array16(1 downto 0);
    TEST_ENB_OUT                : out std_logic_vector(1 downto 0);
    
    DBG_SIG_OUT                 : out std_logic_array32(1 downto 0)   

    );
end CFR_TOP;

architecture arc_CFR_TOP of CFR_TOP is




component CFR_LTE_WRAPPER is
--generic (
--    TX_CFR_ANT_NUM                  : natural := 4 
--    FB_PATH_NUM                 : natural := 2
--    );
port(
    CFR_INFO_OUT                : out std_logic_vector(31 downto 0);
    CFR_DATE_OUT                : out std_logic_vector(31 downto 0);
    CFR_STRUCT_OUT              : out std_logic_vector(31 downto 0);
    
    RST_CFR                     : in  std_logic;
    CLK_CFR                     : in std_logic;  -- CFR block operation clock
    TRAFFIC_PLL_LOCK_IN         : in  std_logic;
    
    FS_10MS_IN                  : in  std_logic; -- 10msec frame sync
    FS_SSB_IN                   : in  std_logic; -- SSB frame sync
    FS_10MS_DLY_OUT             : out std_logic; -- 10msec frame sync delayed out
    FS_SSB_DLY_OUT              : out std_logic; -- SSB frame sync delayed out
    TDD_STRB_DLY_IN             : in  std_logic; -- TDD strobe signal in
    TDD_STRB_DLY_OUT            : out std_logic; -- Delayed TDD strobe signal out

    --BCF_ENB_IN                : in  std_logic; -- Beamforming calibration
    --BCF_ENB_OUT               : out std_logic;
    
    AUTO_MODE_DONE_IN           : in  std_logic_vector(FB_PATH_NUM-1 downto 0); -- Feedback Switch Automode operation done flag
    
    CFR_PROC_DLY_OUT            : out std_logic_vector(31 downto 0);
    
    CFR_BYPASS                  : in std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    
    CFR_THRESHOLD               : in std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    CFR_PEAK_SPACING            : in std_logic_array8(TX_CFR_ANT_NUM-1 downto 0);
    
    CFR_COEFF_UPDATE_EN         : in std_logic_vector(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
    CFR_COEFF_WE                : in std_logic_vector(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
    CFR_COEFF_WRADDR            : in std_logic_array10(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
    CFR_COEFF_WRDATA            : in std_logic_array32(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
    
    CFR_TAP_NUM                 : in std_logic_array10(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
    
    CFR_INPUT_SYNC              : in  std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    CFR_INPUT_I                 : in std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    CFR_INPUT_Q                 : in std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    
    CFR_OUTPUT_SYNC             : out std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    CFR_OUTPUT_I                : out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    CFR_OUTPUT_Q                : out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    
    CFR_PIM_SYNC_OUT            : out std_logic; -- 10msec frame sync delayed out
    CFR_PIM_OUTPUT_I            : out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    CFR_PIM_OUTPUT_Q            : out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);

    CFR_HC_THRES                : in std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    CFR_HC_EN                   : in  std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    
    CFR_PWR_MSR_DONE            : out std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    CFR_PWR_OUT                 : out std_logic_array32(TX_CFR_ANT_NUM-1 downto 0);
    
    OPD_TH                      : in  std_logic_array32(TX_CFR_ANT_NUM-1 downto 0);
    OPD_PWR_OUT                 : out std_logic_array32(TX_CFR_ANT_NUM-1 downto 0);
    OPD_FLAG                    : out std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    
    DUMP_BFN_STRB_OUT           : out std_logic_vector( 1 downto 0);
    DUMP_DATA_OUT               : out std_logic_array32(1 downto 0);
    DUMP_DVLD_OUT               : out std_logic_vector(1 downto 0);
    
    DBG_SIG_OUT                 : out std_logic_array32(1 downto 0)    
);
end component;


signal i_clk_vector             : std_logic_vector(19 downto 0);
signal i_clk_cfr                : std_logic;


begin

    i_clk_vector <= CLK_SYSX20&'0'&'0'&'0'&CLK_SYSX16&'0'&'0'&'0'&CLK_SYSX12&'0'&CLK_SYSX10&'0'&CLK_SYSX8&'0'&CLK_SYSX6&CLK_SYSX5&CLK_SYSX4&CLK_SYSX3&CLK_SYSX2&CLK_SYS;  
    i_clk_cfr    <= i_clk_vector(CFR_CLK_SEL-1);
    
    TEST_ENB_OUT <= "00";

    u_cfr_lte_wrapper : CFR_LTE_WRAPPER
    --generic map(
    --    TX_CFR_ANT_NUM                  => TX_CFR_ANT_NUM,  --: natural := 4;
    --    FB_PATH_NUM                 => FB_PATH_NUM  --: natural :=  2    -- Number of Feedback path 
    --    )
    port map(
        CFR_INFO_OUT                        => CFR_INFO_OUT, --: out std_logic_vector(31 downto 0);
        CFR_DATE_OUT                        => CFR_DATE_OUT, --: out std_logic_vector(31 downto 0);
        CFR_STRUCT_OUT                      => CFR_STRUCT_OUT, --: out std_logic_vector(31 downto 0);
        
        RST_CFR                             => RST_CFR,  --: in  std_logic;
        CLK_CFR                             => i_clk_cfr,  --: in std_logic;  -- CFR block operation clock
        TRAFFIC_PLL_LOCK_IN                 => INT_SYSPLL_LOCK_IN,  --: in  std_logic;
        
        FS_10MS_IN                          => DL_BFN_STRB_IN,  --: in  std_logic; -- 10msec frame sync
        FS_SSB_IN                           => DL_SSB_STRB_IN,  --: in  std_logic; -- SSB frame sync
        FS_10MS_DLY_OUT                     => DL_BFN_STRB_OUT,  --: out std_logic; -- 10msec frame sync delayed out
        FS_SSB_DLY_OUT                      => DL_SSB_STRB_OUT,  --: out std_logic; -- SSB frame sync delayed out
        TDD_STRB_DLY_IN                     => DL_TDD_IN,  --: in  std_logic; -- TDD strobe signal in
        TDD_STRB_DLY_OUT                    => DL_TDD_OUT,  --: out std_logic; -- Delayed TDD strobe signal out
         

        --BCF_ENB_IN                          => DL_BCF_ENB_IN, --: in  std_logic; -- Beamforming calibration
        --BCF_ENB_OUT                         => DL_BCF_ENB_OUT, --: out std_logic;
        
        AUTO_MODE_DONE_IN                   => FBSW_AUTO_MODE_DONE_IN,  --: in  std_logic_vector(FB_PATH_NUM-1 downto 0); -- Feedback Switch Automode operation done flag
        
        CFR_PROC_DLY_OUT                    => CFR_PROC_DLY_OUT,  --: out std_logic_vector(31 downto 0);
        
        CFR_BYPASS                          => CFR_BYPASS_IN,  --: in std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);

        CFR_THRESHOLD                       => CFR_TRSHD_IN,  --: in std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
        CFR_PEAK_SPACING                    => CFR_PEAK_SPACING_IN,  --: in std_logic_array8(TX_CFR_ANT_NUM-1 downto 0);
        

        CFR_COEFF_UPDATE_EN                 => CFR_COEFF_UDT_ENB_IN,  --: in std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
        CFR_COEFF_WE                        => CFR_COEFF_WEN_IN,  --: in std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
        CFR_COEFF_WRADDR                    => CFR_COEFF_WRADDR_IN,  --: in std_logic_array10(TX_CFR_ANT_NUM-1 downto 0);
        CFR_COEFF_WRDATA                    => CFR_COEFF_WRDATA_IN,  --: in std_logic_array32(TX_CFR_ANT_NUM-1 downto 0);
        
        CFR_TAP_NUM                         => CFR_TAP_NUM_IN,  --: in std_logic_array10(TX_CFR_ANT_NUM-1 downto 0);
        
        CFR_INPUT_SYNC                      => DL_SYNC_IN,   --: in  std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
        CFR_INPUT_I                         => DL_I_IN,      --: in std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
        CFR_INPUT_Q                         => DL_Q_IN,      --: in std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
                                               
        CFR_OUTPUT_SYNC                     => DL_SYNC_OUT,  --: out std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
        CFR_OUTPUT_I                        => DL_I_OUT,     --: out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
        CFR_OUTPUT_Q                        => DL_Q_OUT,     --: out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
        
        CFR_PIM_SYNC_OUT                    => DL_PIM_SYNC_OUT,  --: out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
        CFR_PIM_OUTPUT_I                    => DL_PIM_I_OUT,  --: out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
        CFR_PIM_OUTPUT_Q                    => DL_PIM_Q_OUT,  --: out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
        
        CFR_HC_THRES                        => CFR_HC_TRSHD_IN,  --: in std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
        CFR_HC_EN                           => CFR_HC_EN_IN,  --: in  std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
        
        CFR_PWR_MSR_DONE                    => CFR_PWR_MSR_UDT_OUT,  --: out std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
        CFR_PWR_OUT                         => CFR_PWR_OUT,  --: out std_logic_array32(TX_CFR_ANT_NUM-1 downto 0);
        
        OPD_TH                              => OPD_TRSHD_IN,  --: in  std_logic_array32(TX_CFR_ANT_NUM-1 downto 0);
        OPD_PWR_OUT                         => OPD_PWR_OUT,  --: out std_logic_array32(TX_CFR_ANT_NUM-1 downto 0);
        OPD_FLAG                            => SIG_SUS_FLAG_OUT,  --: out std_logic_vector(TX_CFR_ANT_NUM-1 downto 0)
        
        DUMP_BFN_STRB_OUT                   => open,  --: out std_logic_vector(1 downto 0);
        DUMP_DATA_OUT                       => open,  --: out std_logic_array32(1 downto 0);
        DUMP_DVLD_OUT                       => open,  --: out std_logic_vector(1 downto 0);
        
        DBG_SIG_OUT                         => open   --: out std_logic_array32(1 downto 0)     
        );
    


    
end arc_CFR_TOP;
