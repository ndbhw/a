-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_CONFIG.all;
use work.RU_FPGA_FNC.all;

entity CFR_X2_RTL is  --hbf_i_comm 
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    INPUT_VALID                 : in  std_logic;
    INPUT_DATA_I                : in  std_logic_vector(15 downto 0);
    INPUT_DATA_Q                : in  std_logic_vector(15 downto 0);

    OUTPUT_VALID                : out std_logic;
    OUTPUT_DATA_I               : out std_logic_vector(15 downto 0);
    OUTPUT_DATA_Q               : out std_logic_vector(15 downto 0)
);
end CFR_X2_RTL;

architecture Behavioral of CFR_X2_RTL is

component cfr_x2_ser is
generic(
    CHANNEL_NUMBER              : integer := 20;
    HOVS                        : integer := 20;
    WIDTH_IN                    : integer := 16
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN*CHANNEL_NUMBER-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

component cfr_x2_fir is
generic (
    VENDOR                      : string:="XILINX";
    HOVS                        : integer;
    ORDER                       : integer;
    COEFF                       : integer_array(12/2-1 downto 0);
--    COEFF                       : integer_array(20/2-1 downto 0);

    CHANNEL_NUMBERS             : integer;

    WIDTH_IN                    : integer:=16;
    WIDTH_COEFF                 : integer:=16;
    WIDTH_OUT                   : integer:=16;
    WIDTH_RESULT                : integer:=34;
    BINARY_POINT                : integer:=15
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT_0                : out std_logic_vector(WIDTH_OUT-1  downto 0);
    FILTER_OUT_1                : out std_logic_vector(WIDTH_OUT-1  downto 0)
);
end component;

constant CHANNEL_NUMBERS        : integer := 2;
constant HOVS                   : integer := 1;
constant ORDER                  : integer := 12;
constant COEFF                  : integer_array(ORDER/2-1 downto 0) := (20401, -5678, 2343, -916, 288, -57);  -- new
--constant COEFF                  : integer_array(ORDER/2-1 downto 0) := (20637, -6187, 2980, -1499, 693, -281);
--constant ORDER                  : integer := 20;
--constant COEFF                  : integer_array(ORDER/2-1 downto 0) := (20690, -6456, 3388, -1971, 1155, -652, 343, -162, 64, -19);

constant WIDTH_IN               : integer:=16;
constant WIDTH_COEFF            : integer:=16;
constant WIDTH_OUT              : integer:=16;
constant WIDTH_RESULT           : integer:=33;
constant BINARY_POINT           : integer:=14;

signal frame_serial             : std_logic;
signal valid_serial             : std_logic;
signal data_parallel            : std_logic_vector(WIDTH_IN*CHANNEL_NUMBERS-1 downto 0);
signal data_serial              : std_logic_vector(WIDTH_IN-1 downto 0);

begin

    data_parallel <= INPUT_DATA_Q & INPUT_DATA_I;

    -- parallel to serial conversion
    u_dduc_ser : cfr_x2_ser
    generic map(
        CHANNEL_NUMBER              => CHANNEL_NUMBERS              ,--: integer := 20;
        HOVS                        => HOVS                         ,--: integer := 20;
        WIDTH_IN                    => WIDTH_IN                      --: integer := 16
    )
    port map(
        RST                         => RST                          ,--: in  std_logic;
        CLK                         => CLK                          ,--: in  std_logic;

        FRAME_I                     => INPUT_VALID                  ,--: in  std_logic;
        VALID_I                     => INPUT_VALID                  ,--: in  std_logic;
        FILTER_IN                   => data_parallel                ,--: in  std_logic_vector(WIDTH_IN*CHANNEL_NUMBER-1 downto 0);

        FRAME_O                     => frame_serial                 ,--: out std_logic;
        VALID_O                     => valid_serial                 ,--: out std_logic;
        FILTER_OUT                  => data_serial                   --: out std_logic_vector(WIDTH_IN-1 downto 0)
    );

    -- x2 interpolation FIR filter
    u_fir_i_comm : cfr_x2_fir
    generic map(
        VENDOR                      => "XILINX",
        HOVS                        => HOVS,
        ORDER                       => ORDER,
        COEFF                       => COEFF,

        CHANNEL_NUMBERS             => CHANNEL_NUMBERS,

        WIDTH_IN                    => WIDTH_IN    ,
        WIDTH_OUT                   => WIDTH_COEFF ,
        WIDTH_COEFF                 => WIDTH_OUT   ,
        WIDTH_RESULT                => WIDTH_RESULT,
        BINARY_POINT                => BINARY_POINT
    )
    port map(
        RST                         => RST,
        CLK                         => CLK,

        FRAME_I                     => frame_serial,
        VALID_I                     => valid_serial,
        FILTER_IN                   => data_serial,

        FRAME_O                     => open,
        VALID_O                     => OUTPUT_VALID,
        FILTER_OUT_0                => OUTPUT_DATA_I,
        FILTER_OUT_1                => OUTPUT_DATA_Q
    );


end Behavioral;
