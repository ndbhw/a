-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

entity INPUT_MUX_V2 is
   port(
   
        RESET                 : in  std_logic;
        CLK                   : in  std_logic;
        
        DATA_EN               : in std_logic;
        PATH_0_I              : in  std_logic_vector(15 downto 0);
        PATH_0_Q              : in  std_logic_vector(15 downto 0);
        PATH_1_I              : in  std_logic_vector(15 downto 0);
        PATH_1_Q              : in  std_logic_vector(15 downto 0);

        MUXED_I               : out std_logic_vector(15 downto 0);
        MUXED_Q               : out std_logic_vector(15 downto 0)
        
        );
end INPUT_MUX_V2;

architecture arc_INPUT_MUX_V2 of INPUT_MUX_V2 is

signal i_tog, i_tog_d         : std_logic;
signal i_path0_I              : std_logic_vector(15 downto 0);
signal i_path0_Q              : std_logic_vector(15 downto 0);
signal i_path1_I              : std_logic_vector(15 downto 0);
signal i_path1_Q              : std_logic_vector(15 downto 0);

begin

process(RESET,CLK)
begin
   if RESET = '1' then
      i_tog <= '0';
   elsif rising_edge(CLK) then
      i_tog <= not i_tog;
   end if;
end process;

process(RESET,CLK)
begin
   if RESET = '1' then
      i_path0_I <= (others => '0');
      i_path0_Q <= (others => '0');
      i_path1_I <= (others => '0');
      i_path1_Q <= (others => '0');
   elsif rising_edge(CLK) then
      if i_tog_d = '1' then
         i_path0_I <= PATH_0_I;
         i_path0_Q <= PATH_0_Q;
         i_path1_I <= PATH_1_I;
         i_path1_Q <= PATH_1_Q;
      end if;
   end if;
end process;

process(RESET,CLK)
begin
   if RESET = '1' then
      MUXED_I <= (others => '0');
      MUXED_Q <= (others => '0');
   elsif rising_edge(CLK) then
      if DATA_EN = '1' then
        if i_tog = '1' then
           MUXED_I <= i_path0_I;
           MUXED_Q <= i_path0_Q;
        else
           MUXED_I <= i_path1_I;
           MUXED_Q <= i_path1_Q;
        end if;
      else
        MUXED_I <= (others => '0');
        MUXED_Q <= (others => '0');
      end if;
   end if;
end process;

process(RESET,CLK)
begin
   if RESET = '1' then
      i_tog_d <= '0';
   elsif rising_edge(CLK) then
      i_tog_d <= i_tog;
   end if;
end process;

end arc_INPUT_MUX_V2;