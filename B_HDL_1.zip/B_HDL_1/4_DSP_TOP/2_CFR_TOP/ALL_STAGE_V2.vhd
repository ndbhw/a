-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ALL_STAGE_V2 is
			port (
						RESET 							: in	std_logic;
						CLK									: in	std_logic;
						
						SIGNAL_I_IN					:	in	std_logic_vector(15 downto 0);
						SIGNAL_Q_IN					:	in	std_logic_vector(15 downto 0);
						
						CORDIC_MAGNITUDE		:	out	std_logic_vector(17 downto 0);
						
						OUTPUT_STAGE_1			: out	std_logic;
						OUTPUT_STAGE_2			: out	std_logic;
						OUTPUT_STAGE_3			: out	std_logic;
						OUTPUT_STAGE_4			: out	std_logic;
						OUTPUT_STAGE_5			: out	std_logic
						);
end ALL_STAGE_V2;

architecture arc_ALL_STAGE_V2 of ALL_STAGE_V2 is

signal temp_i_in			: std_logic_vector(17 downto 0);
signal temp_q_in			: std_logic_vector(17 downto 0);

signal cs_1_out_i			: std_logic_vector(17 downto 0);
signal cs_1_out_q			: std_logic_vector(17 downto 0);
signal cs_2_out_i			: std_logic_vector(17 downto 0);
signal cs_2_out_q			: std_logic_vector(17 downto 0);
signal cs_3_out_i			: std_logic_vector(17 downto 0);
signal cs_3_out_q			: std_logic_vector(17 downto 0);
signal cs_4_out_i			: std_logic_vector(17 downto 0);
signal cs_4_out_q			: std_logic_vector(17 downto 0);
signal cs_5_out_i			: std_logic_vector(17 downto 0);
signal cs_5_out_q			: std_logic_vector(17 downto 0);
signal cs_6_out_i			: std_logic_vector(17 downto 0);
signal cs_6_out_q			: std_logic_vector(17 downto 0);

begin

temp_i_in	<= SIGNAL_I_IN(15) & SIGNAL_I_IN(15) & SIGNAL_I_IN;
temp_q_in	<= SIGNAL_Q_IN(15) & SIGNAL_Q_IN(15) & SIGNAL_Q_IN;

OUTPUT_STAGE_1 <= cs_1_out_q(17);
OUTPUT_STAGE_2 <= cs_2_out_q(17);
OUTPUT_STAGE_3 <= cs_3_out_q(17);
OUTPUT_STAGE_4 <= cs_4_out_q(17);
OUTPUT_STAGE_5 <= cs_5_out_q(17);

CORDIC_MAGNITUDE <= cs_6_out_i;

--=========== cordic stage 1 ======================================

process(RESET,CLK)
begin
	if RESET = '1' then
		cs_1_out_i <= (others => '0');
		cs_1_out_q <= (others => '0');
	elsif (CLK'event and CLK='1') then
		cs_1_out_i <= temp_i_in + temp_q_in;
		cs_1_out_q <= temp_q_in - temp_i_in;
	end if;
end process;

--=========== cordic stage 2 =======================================
process(RESET,CLK)
begin
	if RESET = '1' then
		cs_2_out_i <= (others => '0');
		cs_2_out_q <= (others => '0');
	elsif (CLK'event and CLK='1') then
		if cs_1_out_q(17) = '1' then
			cs_2_out_i <= cs_1_out_i - (cs_1_out_q(17) & cs_1_out_q(17 downto 1));
			cs_2_out_q <= cs_1_out_q + (cs_1_out_i(17) & cs_1_out_i(17 downto 1));
		else
			cs_2_out_i <= cs_1_out_i + (cs_1_out_q(17) & cs_1_out_q(17 downto 1));
			cs_2_out_q <= cs_1_out_q - (cs_1_out_i(17) & cs_1_out_i(17 downto 1));
		end if;
	end if;
end process;

--============ cordic stage 3 ========================================
process(RESET,CLK)
begin
	if RESET = '1' then
		cs_3_out_i <= (others => '0');
		cs_3_out_q <= (others => '0');
	elsif (CLK'event and CLK='1') then
		if cs_2_out_q(17) = '1' then
			cs_3_out_i <= cs_2_out_i - (cs_2_out_q(17) & cs_2_out_q(17) & cs_2_out_q(17 downto 2));
			cs_3_out_q <= cs_2_out_q + (cs_2_out_i(17) & cs_2_out_i(17) & cs_2_out_i(17 downto 2));
		else
			cs_3_out_i <= cs_2_out_i + (cs_2_out_q(17) & cs_2_out_q(17) & cs_2_out_q(17 downto 2));
			cs_3_out_q <= cs_2_out_q - (cs_2_out_i(17) & cs_2_out_i(17) & cs_2_out_i(17 downto 2));
		end if;
	end if;
end process;

--============ cordic stage 4 ========================================
process(RESET,CLK)
begin
	if RESET = '1' then
		cs_4_out_i <= (others => '0');
		cs_4_out_q <= (others => '0');
	elsif (CLK'event and CLK='1') then
		if cs_3_out_q(17) = '1' then
			cs_4_out_i <= cs_3_out_i - (cs_3_out_q(17) & cs_3_out_q(17) & cs_3_out_q(17) & cs_3_out_q(17 downto 3));
			cs_4_out_q <= cs_3_out_q + (cs_3_out_i(17) & cs_3_out_i(17) & cs_3_out_i(17) & cs_3_out_i(17 downto 3));
		else
			cs_4_out_i <= cs_3_out_i + (cs_3_out_q(17) & cs_3_out_q(17) & cs_3_out_q(17) & cs_3_out_q(17 downto 3));
			cs_4_out_q <= cs_3_out_q - (cs_3_out_i(17) & cs_3_out_i(17) & cs_3_out_i(17) & cs_3_out_i(17 downto 3));
		end if;
	end if;
end process;

--============ cordic stage 5 ========================================
process(RESET,CLK)
begin
	if RESET = '1' then
		cs_5_out_i <= (others => '0');
		cs_5_out_q <= (others => '0');
	elsif (CLK'event and CLK='1') then
		if cs_4_out_q(17) = '1' then
			cs_5_out_i <= cs_4_out_i - (cs_4_out_q(17) & cs_4_out_q(17) & cs_4_out_q(17) & cs_4_out_q(17) & cs_4_out_q(17 downto 4));
			cs_5_out_q <= cs_4_out_q + (cs_4_out_i(17) & cs_4_out_i(17) & cs_4_out_i(17) & cs_4_out_i(17) & cs_4_out_i(17 downto 4));
		else
			cs_5_out_i <= cs_4_out_i + (cs_4_out_q(17) & cs_4_out_q(17) & cs_4_out_q(17) & cs_4_out_q(17) & cs_4_out_q(17 downto 4));
			cs_5_out_q <= cs_4_out_q - (cs_4_out_i(17) & cs_4_out_i(17) & cs_4_out_i(17) & cs_4_out_i(17) & cs_4_out_i(17 downto 4));
		end if;
	end if;
end process;

--============ cordic stage 6 ========================================
process(RESET,CLK)
begin
	if RESET = '1' then
		cs_6_out_i <= (others => '0');
		cs_6_out_q <= (others => '0');
	elsif (CLK'event and CLK='1') then
		if cs_5_out_q(17) = '1' then
			cs_6_out_i <= cs_5_out_i - (cs_5_out_q(17) & cs_5_out_q(17) & cs_5_out_q(17) & cs_5_out_q(17) & cs_5_out_q(17) & cs_5_out_q(17 downto 5));
			cs_6_out_q <= cs_5_out_q + (cs_5_out_i(17) & cs_5_out_i(17) & cs_5_out_i(17) & cs_5_out_i(17) & cs_5_out_i(17) & cs_5_out_i(17 downto 5));
		else
			cs_6_out_i <= cs_5_out_i + (cs_5_out_q(17) & cs_5_out_q(17) & cs_5_out_q(17) & cs_5_out_q(17) & cs_5_out_q(17) & cs_5_out_q(17 downto 5));
			cs_6_out_q <= cs_5_out_q - (cs_5_out_i(17) & cs_5_out_i(17) & cs_5_out_i(17) & cs_5_out_i(17) & cs_5_out_i(17) & cs_5_out_i(17 downto 5));
		end if;
	end if;
end process;

end arc_ALL_STAGE_V2;