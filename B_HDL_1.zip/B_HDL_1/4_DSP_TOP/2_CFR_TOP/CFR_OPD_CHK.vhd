library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

Library UNISIM;
use UNISIM.vcomponents.all;

entity CFR_OPD_CHK  is
   port (
          RESET             : in  std_logic;
          CLK               : in  std_logic;
          
          FS_10M            : in  std_logic;
          OPD_THRES         : in  std_logic_vector(31 downto 0);
          
          CFROUT_I          : in  std_logic_vector(15 downto 0);
          CFROUT_Q          : in  std_logic_vector(15 downto 0);
          
          OPD_DETECT_FLAG   : out std_logic;
          DETECT_OPD_PWR    : out std_logic_vector(31 downto 0)
        );
end CFR_OPD_CHK;

architecture arc_CFR_OPD_CHK of CFR_OPD_CHK is

component CFR_OPD_PWR
   port (
          RESET             : in  std_logic;
          CLK               : in  std_logic;
          
          FS_10M            : in  std_logic;
          
          CFROUT_I          : in  std_logic_vector(15 downto 0);
          CFROUT_Q          : in  std_logic_vector(15 downto 0);
          
          OPD_PWR_UPDATE    : out std_logic;
          OPD_PWR           : out std_logic_vector(31 downto 0)
        );
end component;

signal i_pwr_update         : std_logic;
signal i_pwr_opd            : std_logic_vector(31 downto 0);

begin

u_opd_pwr : CFR_OPD_PWR
   port map(
          RESET             => RESET, --: in  std_logic;
          CLK               => CLK, --: in  std_logic;
          
          FS_10M            => FS_10M, --: in  std_logic;
          
          CFROUT_I          => CFROUT_I, --: in  std_logic_vector(15 downto 0);
          CFROUT_Q          => CFROUT_Q, --: in  std_logic_vector(15 downto 0);
          
          OPD_PWR_UPDATE    => i_pwr_update, --: out std_logic;
          OPD_PWR           => i_pwr_opd  --: out std_logic_vector(31 downto 0)
        );

process(RESET,CLK)
begin
  if RESET = '1' then
    OPD_DETECT_FLAG <= '0';
  elsif rising_edge(CLK) then
    if i_pwr_update = '1' then
      if i_pwr_opd >= OPD_THRES then
        OPD_DETECT_FLAG <= '1';
      else
        OPD_DETECT_FLAG <= '0';
      end if;
    end if;
  end if;
end process;

process(RESET,CLK)
begin
  if RESET = '1' then
    DETECT_OPD_PWR <= (others => '0');
  elsif rising_edge(CLK) then
    if i_pwr_update = '1' then
      if i_pwr_opd >= OPD_THRES then
        DETECT_OPD_PWR <= i_pwr_opd;
      end if;
    end if;
  end if;
end process;
      
end arc_CFR_OPD_CHK;
