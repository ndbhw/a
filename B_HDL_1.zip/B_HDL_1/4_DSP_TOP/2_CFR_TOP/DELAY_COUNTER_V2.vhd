-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity DELAY_COUNTER_V2 is

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM            : in std_logic;
							RST_SEARCH				: in	std_logic;
							NEW_MAX						: in	std_logic;
							
							PEAK_DELAY_0			: out	std_logic_vector(6 downto 0);
							PEAK_DELAY_1			: out	std_logic_vector(6 downto 0);
							PEAK_INDICATOR		: out	std_logic
						);
end DELAY_COUNTER_V2;

architecture arc_DELAY_COUNTER_V2 of DELAY_COUNTER_V2 is

signal i_ch_num						            : std_logic;
signal delay_cnt_rst			            : std_logic;
signal ch0_dly_cnt_en                 : std_logic;
signal ch1_dly_cnt_en                 : std_logic;
signal delay_cnt_en				            : std_logic;
signal delay_cnt_0				            : std_logic_vector(6 downto 0);
signal delay_cnt_1				            : std_logic_vector(6 downto 0);
signal cnt_msb_d, cnt_msb_dd	        : std_logic;
signal cnt_msb_red  			            : std_logic;  -- red : rising edge detector  :)
signal rst_search_d, rst_search_dd	  : std_logic;
signal rst_search_red		              : std_logic;
signal new_max_d_0, new_max_d_1	      : std_logic;
signal temp0, temp1, temp2            : std_logic;

signal i_tog            : std_logic;

signal new_max_d_0_d, new_max_d_0_rpls	      : std_logic;

signal new_max_d_1_d, new_max_d_1_rpls	      : std_logic;



begin

process(RESET,CLK)
begin
   if RESET = '1' then
      i_tog <= '0';
   elsif rising_edge(CLK) then
      i_tog <= not i_tog;
   end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		delay_cnt_rst <= '0';
		i_ch_num <= '0';
		ch0_dly_cnt_en <= '0';
		ch1_dly_cnt_en <= '0';
	elsif (CLK'event and CLK='1') then
	  delay_cnt_rst <= RST_SEARCH or NEW_MAX;
	  --i_ch_num <= CH_NUM;
	  i_ch_num <= i_tog;
	  ch0_dly_cnt_en <= not(NEW_MAX or delay_cnt_0(6));
    ch1_dly_cnt_en <= not(NEW_MAX or delay_cnt_1(6));
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		delay_cnt_0 <= (others => '0');
	elsif (CLK'event and CLK='1') then
		if (delay_cnt_rst = '1') and (i_ch_num = '0') then
		  delay_cnt_0 <= (others => '0');
		else
			if (ch0_dly_cnt_en = '1') and (i_ch_num = '0') then
				  delay_cnt_0 <= delay_cnt_0 + 1;
			end if;
		end if;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		delay_cnt_1 <= (others => '0');
	elsif (CLK'event and CLK='1') then
		if (delay_cnt_rst = '1') and (i_ch_num = '1') then
		  delay_cnt_1 <= (others => '0');
		else
			if (ch1_dly_cnt_en = '1') and (i_ch_num = '1') then
				  delay_cnt_1 <= delay_cnt_1 + 1;
			end if;
		end if;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		cnt_msb_d <= '0';
		cnt_msb_dd <= '0';
		cnt_msb_red <= '0';
	elsif (CLK'event and CLK='1') then
	  --if CH_NUM = '1' then
	  if i_tog = '1' then
		  cnt_msb_d <= not(delay_cnt_1(6));
		  cnt_msb_red <= delay_cnt_1(6) and cnt_msb_dd;
		else
		  cnt_msb_d <= not(delay_cnt_0(6));
		  cnt_msb_red <= delay_cnt_0(6) and cnt_msb_dd;
		end if;
		
		cnt_msb_dd <= cnt_msb_d;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		rst_search_d <= '0';
		rst_search_dd <= '0';
		rst_search_red <= '0';
	elsif (CLK'event and CLK='1') then
		rst_search_d <= not RST_SEARCH;
		rst_search_dd <= rst_search_d;
		rst_search_red <= RST_SEARCH and rst_search_dd;
	end if;
end process;
		
process(RESET,CLK)
begin
	if RESET = '1' then
		new_max_d_0 <= '0';
	elsif (CLK'event and CLK='1') then
		if (rst_search_red = '1') and (i_ch_num = '0') then --INPUT_TOGGLE
			new_max_d_0 <= '0';
		else
			if i_ch_num = '1' then
			  new_max_d_0 <= (NEW_MAX or new_max_d_0);
			end if;
		end if;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		new_max_d_1 <= '0';
	elsif (CLK'event and CLK='1') then
		if (rst_search_red = '1') and (i_ch_num = '1') then --INPUT_TOGGLE
			new_max_d_1 <= '0';
		else
			if i_ch_num = '0' then
			  new_max_d_1 <= (NEW_MAX or new_max_d_1);
			end if;
		end if;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
	  temp0 <= '0';
	  temp1 <= '0';
	  PEAK_DELAY_0 <= (others => '0');
		PEAK_DELAY_1 <= (others => '0');
	elsif (CLK'event and CLK='1') then
	  if i_ch_num = '1' then
	    if (cnt_msb_red and new_max_d_1) = '1' then
	      temp0 <= '1';
	      PEAK_DELAY_1 <= delay_cnt_1;
	    else
	      temp0 <= '0';
	    end if;
	    
	    if ((not delay_cnt_1(6)) and rst_search_red and new_max_d_1) = '1' then
	      temp1 <= '1';
	      PEAK_DELAY_1 <= delay_cnt_1;
	    else
	      temp1 <= '0';
	    end if;
	  else
	    if (cnt_msb_red and new_max_d_0) = '1' then
	      temp0 <= '1';
	      PEAK_DELAY_0 <= delay_cnt_0;
	    else
	      temp0 <= '0';
	    end if;
	    
	    if ((not delay_cnt_0(6)) and rst_search_red and new_max_d_0) = '1' then
	      temp1 <= '1';
	      PEAK_DELAY_0 <= delay_cnt_0;
	    else
	      temp1 <= '0';
	    end if;
	  end if;
  end if;
end process; 

--PEAK_INDICATOR <= temp0 or temp1;



PEAK_INDICATOR <=  '0'         when new_max_d_0_rpls = '1' else
                   '0'         when new_max_d_1_rpls = '1' else
                  temp0 or temp1;





process(RESET,CLK)
begin
	if RESET = '1' then
		new_max_d_0_d <= '0';
		new_max_d_0_rpls <= '0';
	elsif (CLK'event and CLK='1') then
        if new_max_d_0_d = '0' and new_max_d_0 = '1' then
            new_max_d_0_rpls <= '1';
        else
            new_max_d_0_rpls <= '0';
 	    end if;
        new_max_d_0_d <= new_max_d_0;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		new_max_d_1_d <= '0';
		new_max_d_1_rpls <= '0';
	elsif (CLK'event and CLK='1') then
        if new_max_d_1_d = '0' and new_max_d_1 = '1' then
            new_max_d_1_rpls <= '1';
        else
            new_max_d_1_rpls <= '0';
 	    end if;
        new_max_d_1_d <= new_max_d_1;
	end if;
end process;




end arc_DELAY_COUNTER_V2;
