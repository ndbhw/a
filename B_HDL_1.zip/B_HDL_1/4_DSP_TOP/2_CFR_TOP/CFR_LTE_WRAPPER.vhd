-- Dependencies:
--
-- Revision: 19.12.05
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_CONFIG.all;
use work.RU_FPGA_FNC.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity CFR_LTE_WRAPPER is
--generic (
--    TX_CFR_ANT_NUM                  : natural := 4; 
--    FB_PATH_NUM                 : natural := 2
--    );
port(
    CFR_INFO_OUT                : out std_logic_vector(31 downto 0);
    CFR_DATE_OUT                : out std_logic_vector(31 downto 0);
    CFR_STRUCT_OUT              : out std_logic_vector(31 downto 0);
    
    RST_CFR                     : in  std_logic;
    CLK_CFR                     : in std_logic;  -- CFR block operation clock
    TRAFFIC_PLL_LOCK_IN         : in  std_logic;
    
    FS_10MS_IN                  : in  std_logic; -- 10msec frame sync
    FS_SSB_IN                   : in  std_logic; -- SSB frame sync
    FS_10MS_DLY_OUT             : out std_logic; -- 10msec frame sync delayed out
    FS_SSB_DLY_OUT              : out std_logic; -- SSB frame sync delayed out
    TDD_STRB_DLY_IN             : in  std_logic; -- TDD strobe signal in
    TDD_STRB_DLY_OUT            : out std_logic; -- Delayed TDD strobe signal out


    --BCF_ENB_IN                : in  std_logic; -- Beamforming calibration
    --BCF_ENB_OUT               : out std_logic;
    
    AUTO_MODE_DONE_IN           : in  std_logic_vector(FB_PATH_NUM-1 downto 0); -- Feedback Switch Automode operation done flag
    
    CFR_PROC_DLY_OUT            : out std_logic_vector(31 downto 0);
    
    CFR_BYPASS                  : in std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    
    CFR_THRESHOLD               : in std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    CFR_PEAK_SPACING            : in std_logic_array8(TX_CFR_ANT_NUM-1 downto 0);
    
    CFR_COEFF_UPDATE_EN         : in std_logic_vector(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
    CFR_COEFF_WE                : in std_logic_vector(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
    CFR_COEFF_WRADDR            : in std_logic_array10(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
    CFR_COEFF_WRDATA            : in std_logic_array32(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
    
    CFR_TAP_NUM                 : in std_logic_array10(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
    
    CFR_INPUT_SYNC              : in  std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    CFR_INPUT_I                 : in std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    CFR_INPUT_Q                 : in std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    
    CFR_OUTPUT_SYNC             : out std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    CFR_OUTPUT_I                : out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    CFR_OUTPUT_Q                : out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    
    CFR_PIM_SYNC_OUT            : out std_logic; -- 10msec frame sync delayed out
    CFR_PIM_OUTPUT_I            : out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    CFR_PIM_OUTPUT_Q            : out std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);

    CFR_HC_THRES                : in std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
    CFR_HC_EN                   : in  std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    
    CFR_PWR_MSR_DONE            : out std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    CFR_PWR_OUT                 : out std_logic_array32(TX_CFR_ANT_NUM-1 downto 0);
    
    OPD_TH                      : in  std_logic_array32(TX_CFR_ANT_NUM-1 downto 0);
    OPD_PWR_OUT                 : out std_logic_array32(TX_CFR_ANT_NUM-1 downto 0);
    OPD_FLAG                    : out std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);
    
    DUMP_BFN_STRB_OUT           : out std_logic_vector( 1 downto 0);
    DUMP_DATA_OUT               : out std_logic_array32(1 downto 0);
    DUMP_DVLD_OUT               : out std_logic_vector(1 downto 0);
    
    DBG_SIG_OUT                 : out std_logic_array32(1 downto 0)    
);
end CFR_LTE_WRAPPER;

architecture arc_CFR_LTE_WRAPPER of CFR_LTE_WRAPPER is

--component reset_synchronizer is
--port (
--    reset_in                    : in  std_logic;    -- Active high asynchronous reset
--    clk                         : in  std_logic;    -- clock to be sync'ed to
--    reset_out                   : out std_logic     -- "Synchronised" reset signal
--    );         
--end component;

--    component csl_reset_synchronizer 
--    port (
--      reset_in                              : in  std_logic;          -- Active high asynchronous reset
--      clk                                   : in  std_logic;          -- clock to be sync'ed to
--      reset_out                             : out std_logic);         -- "Synchronised" reset signal
--    end component;

component RST_SYNC is
generic(
    DLY_NUM                     : natural := 4;    -- Number of delay.
    MAX_FANOUT_NUM              : integer := 200   -- Number of maximum fanout
);
port(
    RST_IN                      : in  std_logic;          -- Active high asynchronous reset
    CLK                         : in  std_logic;          -- clock to be sync'ed to
    RST_OUT                     : out std_logic           -- "Synchronised" reset signal
);         
end component;

component RESETn_SYNC 
generic(
    RESET_VALUE                 : std_logic;
    RELEASE_VALUE               : std_logic
);
port(
    EXT_RESET_N                 : in  std_logic;
    CLOCK                       : in  std_logic;
    nRESET_SYNC                 : out std_logic 
);
end component;

component TDD_STRB_DLY
generic(
    CLK_CNTDLY                  : integer
);
port(
    RST                         : in  std_logic; -- Active high reset
    CLK                         : in  std_logic; -- Clock
    
    BLK_BYPASS_IN               : in  std_logic; -- '0' normal mode, '1' bypass mode
    
    BFN_STROBE_IN               : in  std_logic;
    TDD_STROBE_IN               : in  std_logic;

    BFNSTRB_DLY_OUT             : out std_logic;
    TDDSTRB_DLY_OUT             : out std_logic
    );
end component;

component LTE_SEC_PC_CFR_TOP_V2P5 is
generic(
    FRAC_DLY_FILTER_EN          : boolean := TRUE;
    UPSAMPLE_MODE_EN            : boolean := TRUE
);
port(
    CFR_DATE_OUT                : out std_logic_vector(31 downto 0);
    CFR_VER_OUT                 : out std_logic_vector(7 downto 0);

    RESET                       : in  std_logic;
    CLK                         : in  std_logic;
    CLOCK_UNSTABLE              : in  std_logic;
    
    CFR_BYPASS                  : in  std_logic_vector(1 downto 0); 

    CFR_THRESHOLD_0             : in  std_logic_vector(15 downto 0);
    CFR_THRESHOLD_1             : in  std_logic_vector(15 downto 0);
    CFR_PEAK_SPACING_0          : in  std_logic_vector(7 downto 0);
    CFR_PEAK_SPACING_1          : in  std_logic_vector(7 downto 0);

    CFR_COEFF_UPDATE_EN         : in  std_logic;
    CFR_COEFF_WE                : in  std_logic;
    CFR_COEFF_WRADDR            : in  std_logic_vector(9 downto 0);
    CFR_COEFF_WRDATA            : in  std_logic_vector(31 downto 0);

    CFR_TAP_NUM                 : in  std_logic_vector(9 downto 0);

    CFR_0_INPUT_I               : in  std_logic_vector(15 downto 0);
    CFR_0_INPUT_Q               : in  std_logic_vector(15 downto 0);
    CFR_1_INPUT_I               : in  std_logic_vector(15 downto 0);
    CFR_1_INPUT_Q               : in  std_logic_vector(15 downto 0);

    CFR_0_OUTPUT_I              : out std_logic_vector(15 downto 0);
    CFR_0_OUTPUT_Q              : out std_logic_vector(15 downto 0);
    CFR_1_OUTPUT_I              : out std_logic_vector(15 downto 0);
    CFR_1_OUTPUT_Q              : out std_logic_vector(15 downto 0);
 
    PIM_CFR_0_OUTPUT_I          : out std_logic_vector(15 downto 0);
    PIM_CFR_0_OUTPUT_Q          : out std_logic_vector(15 downto 0);
    PIM_CFR_1_OUTPUT_I          : out std_logic_vector(15 downto 0);
    PIM_CFR_1_OUTPUT_Q          : out std_logic_vector(15 downto 0)
);
end component;

component HARD_CLIPPING is
generic(
    DEVICE                      : string  := "7SERIES" -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    );
port(
    RST                         : in  std_logic;                     -- active high
    CLK                         : in  std_logic;                    
    --sample_en                   : in  std_logic;                  -- Channel BW Sampling rate
    DATA_I_IN                   : in  std_logic_vector(15 downto 0);
    DATA_Q_IN                   : in  std_logic_vector(15 downto 0);

    THRESHOLD                   : in  std_logic_vector(15 downto 0);

    DATA_I_OUT                  : out std_logic_vector(15 downto 0);
    DATA_Q_OUT                  : out std_logic_vector(15 downto 0);
  
    HC_EN                       : in  std_logic;
    HC_ON                       : out std_logic
);
end component;

--component dif_pwr_meas_opd is
--generic(
--    CLK_DIV                     : natural:= 1; -- CLK_DIV = clock rate/data rate 
--    ACCUM_NUM_WIDTH             : natural:= 20;-- Number of samples to be averaged = 2^ACCUM_NUM_WIDTH
--    DATA_WIDTH                  : natural:= 16;-- Data bits width
--
--    -- for OPD 
--    OPD_ACCUM_NUM_WIDTH         : natural:= 16 -- Number of samples to be averaged(OPD) = 2^ACCUM_NUM_WIDTH_OPD
--);
--port(
--    RESET                       : in  std_logic;
--    CLK                         : in  std_logic;
--
--    FRAME_SYNC                  : in  std_logic;-- 10ms strobe
--
--    DATA_IN_I                   : in  std_logic_vector(DATA_WIDTH-1 downto 0); 
--    DATA_IN_Q                   : in  std_logic_vector(DATA_WIDTH-1 downto 0);
--    
--    PWR_UPDATE_DONE             : out std_logic;    
--    PWR_OUT                     : out std_logic_vector(2*DATA_WIDTH-1 downto 0);
--
--    -- for OPD
--    OPD_TH                      : in  std_logic_vector(2*DATA_WIDTH-1 downto 0); 
--    OPD_PWR_OUT                 : out std_logic_vector(2*DATA_WIDTH-1 downto 0);
--    OPD_PWR_UPDATE_DONE         : out std_logic;    
--    OPD_FLAG                    : out std_logic
--);
--end component;

component CFR_OPD_CHK
port(
    RESET                       : in  std_logic;
    CLK                         : in  std_logic;
    
    FS_10M                      : in  std_logic;
    OPD_THRES                   : in  std_logic_vector(31 downto 0);
    
    CFROUT_I                    : in  std_logic_vector(15 downto 0);
    CFROUT_Q                    : in  std_logic_vector(15 downto 0);
    
    OPD_DETECT_FLAG             : out std_logic;
    DETECT_OPD_PWR              : out std_logic_vector(31 downto 0)
);
end component;

component PWRMEAS_MANTISSA
generic(
    DEVICE                      : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    CLK_DIV                     : natural :=  2; -- CLK_DIV = (Clock Rate)/(Data Rate)
    DATA_WIDTH                  : natural := 16  -- Data bit width
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    
    FRAME_SYNC_IN               : in  std_logic; -- BFN 10ms strobe
    TDD_SIG_IN                  : in  std_logic; -- TDD strobe, DL : '1', UL : '0', when FDD mode, always set high

    DATA_I_IN                   : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    DATA_Q_IN                   : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    PWR_UPDATE_DONE_OUT         : out std_logic;
    PWR_OUT                     : out std_logic_vector(31 downto 0)
);
end component;


--================================ internal signals ===================================
signal i_cfr_date                   : std_logic_array32((TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
signal i_cfr_ver                    : std_logic_array8((TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);

signal i_cfr_proc_dly_1_stage       : std_logic_vector(23 downto 0) := (others => '0') ;
signal i_cfr_proc_dly_all           : std_logic_vector(23 downto 0) := (others => '0') ;

signal i_clk_unstable               : std_logic;
signal rst_cfr_all                  : std_logic; 
signal rst_cfr_all_n                : std_logic;
signal i_rst_cfr                    : std_logic_vector((TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0); 
signal i_rst_cfr_hc                 : std_logic_vector(TX_CFR_ANT_NUM-1 downto 0); 
signal i_rst_cfr_pwr                : std_logic_vector(TX_CFR_ANT_NUM-1 downto 0);

signal i_coeff_update_en            : std_logic_vector((TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
signal i_coeff_we                   : std_logic_vector((TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
signal i_coeff_addr                 : std_logic_array10((TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
signal i_coeff_wrdata               : std_logic_array32((TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
signal i_cfr_tap_num                : std_logic_array10((TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);

signal i_cfr_out_I                  : std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
signal i_cfr_out_Q                  : std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
signal i_cfr_hc_out_I               : std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
signal i_cfr_hc_out_Q               : std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);

--=======================add pim_output  19.12.05
signal i_pim_cfr_out_I              : std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
signal i_pim_cfr_out_Q              : std_logic_array16(TX_CFR_ANT_NUM-1 downto 0);
--===============================================

signal i_tdd_strb_dly               : std_logic;
signal i_fs_10ms_dly                : std_logic;

signal i_fs_ssb_d                   : std_logic;
signal i_fs_ssb_dd                  : std_logic;
signal i_fs_ssb_dly                 : std_logic;
signal i_pim_sync_dly               : std_logic;

signal i_pwrmeas_sync               : std_logic;

signal i_tog                        : std_logic;
signal i_tog_d                      : std_logic:= '0';

constant CLK_MULTIPLE_FACTOR        : integer := integer(CFR_OPR_CLK/30.72);
constant CLK_MULT_FACTOR_STDLOGIC   : std_logic_vector(5 downto 0) := std_logic_vector(to_unsigned(CLK_MULTIPLE_FACTOR,  6));
constant CFR_FRAC_EN_VAL            : integer := ternary_func((CFR_FRAC_DLY_FILTER_EN = TRUE), 1, 0);
constant CFR_UPSAMPLE_EN_VAL        : integer := ternary_func((CFR_UPSAMPLE_MODE_EN = TRUE), 1, 0);
constant CFR_HC_IMPL_EN_VAL         : integer := ternary_func((CFR_HC_IMPL_EN = TRUE), 1, 0);
--constant CFR_DELAY_VAL_INT          : integer := 2 + CFR_STAGE_NUM*(520+(CFR_CONFIG_TAP_NUM-351)) + CFR_FRAC_EN_VAL*18 + CFR_UPSAMPLE_EN_VAL*29 + CFR_HC_IMPL_EN_VAL*20 + 2 + 2;  
constant CFR_DELAY_VAL_INT          : integer := 3 + (CFR_STAGE_NUM*(CFR_CONFIG_TAP_NUM + 169)) + CFR_FRAC_EN_VAL*16 + CFR_UPSAMPLE_EN_VAL*23 + CFR_HC_IMPL_EN_VAL*26 + 2 + 2;  -- new
constant CFR_DELAY_VAL              : integer := 3 + CFR_FRAC_EN_VAL*16 + CFR_UPSAMPLE_EN_VAL*23 + CFR_HC_IMPL_EN_VAL*26 + 2 + 2;  -- new
                                      -- input_mux +  frac + upsample + hc + bypass_sel + output_demux
constant CFR_PIM_DELAY_VAL_INT      : integer := 3 + (CFR_STAGE_NUM-1)*(CFR_CONFIG_TAP_NUM + 169) + CFR_FRAC_EN_VAL*16 + 2 + 2 ;



constant CFR_DELAY_VAL_STDLOGIC     : std_logic_vector(23 downto 0) := std_logic_vector(to_unsigned(CFR_DELAY_VAL,  24));
--constant CFR_DELAY_VAL_2p6G         : std_logic_vector(31 downto 0) :=     x"1"   &   x"000" & x"0869";  -- num_tap : 351, 4stage, frac on, upsampler on, HC on
--constant CFR_DELAY_VAL_700M         : std_logic_vector(31 downto 0) :=     x"0"   &   x"000" & x"084C";  -- num_tap : 351, 4stage, frac on, upsampler off, HC on
constant CFR_MODULE_NUM             : std_logic_vector(3 downto 0) := std_logic_vector(to_unsigned(TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE,  4));
constant CFR_STAGE_NUM_STDLOGIC     : std_logic_vector(3 downto 0) := std_logic_vector(to_unsigned(CFR_STAGE_NUM,  4));
constant CFR_FRAC_EN_STDLOGIC       : std_logic := ternary_func((CFR_FRAC_DLY_FILTER_EN = TRUE), '1', '0');
constant CFR_UPSAMPLE_EN_STDLOGIC   : std_logic := ternary_func((CFR_UPSAMPLE_MODE_EN = TRUE), '1', '0');
constant CFR_HC_IMPL_EN_STDLOGIC    : std_logic := ternary_func((CFR_HC_IMPL_EN = TRUE), '1', '0');

attribute KEEP                      : string;
attribute KEEP                      of rst_cfr_all      : signal is "TRUE";
attribute KEEP                      of rst_cfr_all_n    : signal is "TRUE";
attribute KEEP                      of i_rst_cfr        : signal is "TRUE";
attribute KEEP                      of i_rst_cfr_hc     : signal is "TRUE";
attribute KEEP                      of i_rst_cfr_pwr    : signal is "TRUE";

attribute MAX_FANOUT                : integer;
attribute MAX_FANOUT                of rst_cfr_all      : signal is 200;
attribute MAX_FANOUT                of rst_cfr_all_n    : signal is 200;
attribute MAX_FANOUT                of i_rst_cfr        : signal is 200;
attribute MAX_FANOUT                of i_rst_cfr_hc     : signal is 200;
attribute MAX_FANOUT                of i_rst_cfr_pwr    : signal is 200;

--=====================================================================================

begin

    CFR_DATE_OUT <= i_cfr_date(0);
    CFR_INFO_OUT <= CFR_MODULE_MAIN_TYPE & CFR_MODULE_SUB_TYPE & x"00" & i_cfr_ver(0);
    CFR_STRUCT_OUT <= x"00" & CFR_CPG_MULT_TYPE & CFR_COEFF_MEM_ACCESS_TYPE & CFR_PHY_MEM_DEPTH_FACTOR & CFR_MODULE_NUM & CFR_STAGE_NUM_STDLOGIC & '0' & CFR_HC_IMPL_EN_STDLOGIC & CFR_UPSAMPLE_EN_STDLOGIC & CFR_FRAC_EN_STDLOGIC;
    
    process(rst_cfr_all,CLK_CFR)
    begin
        if rst_cfr_all = '1' then
            i_cfr_proc_dly_1_stage <= (others => '0') ;
            i_cfr_proc_dly_all     <= (others => '0') ;
        elsif rising_edge(CLK_CFR) then
            i_cfr_proc_dly_1_stage <= (x"000" & "00" & CFR_TAP_NUM(0)) + x"0000A9" ;
            i_cfr_proc_dly_all     <= (i_cfr_proc_dly_1_stage(21 downto 0) & "00") + CFR_DELAY_VAL_STDLOGIC ;
        end if;
    end process;
    
--    CFR_PROC_DLY_OUT <= "00" & CLK_MULT_FACTOR_STDLOGIC & CFR_DELAY_VAL_STDLOGIC;
    CFR_PROC_DLY_OUT <= "00" & CLK_MULT_FACTOR_STDLOGIC & i_cfr_proc_dly_all;
    
    i_clk_unstable  <= not TRAFFIC_PLL_LOCK_IN;
    
    u_rst_cfr_all : RST_SYNC generic map(8, 200) port map(RST_CFR, CLK_CFR, rst_cfr_all);
    rst_cfr_all_n <= not rst_cfr_all;
    
    TX_GSM_ANT_NUM_RST_GEN : for i in 0 to TX_CFR_ANT_NUM-1 generate
        u_rst_cfr_pwr : RST_SYNC generic map(8, 200) port map(rst_cfr_all, CLK_CFR, i_rst_cfr_pwr(i));
        u_rst_cfr_hc  : RST_SYNC generic map(8, 200) port map(rst_cfr_all, CLK_CFR, i_rst_cfr_hc(i));
    end generate;
    
    CFR_RST_GEN : for q in (TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0 generate
        u_rst_cfr : RST_SYNC generic map(8, 200) port map(rst_cfr_all, CLK_CFR, i_rst_cfr(q));
    end generate;

    GEN_CFR_BLK : for i in (TX_CFR_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0 generate

    --i_coeff_update_en(i) <= CFR_COEFF_UPDATE_EN(i*2);
    --i_coeff_we(i) <= CFR_COEFF_WE(i*2);
    --i_coeff_addr(i) <= CFR_COEFF_WRADDR(i*2);
    --i_coeff_wrdata(i) <= CFR_COEFF_WRDATA(i*2);
    --i_cfr_tap_num(i) <= CFR_TAP_NUM(i*2);
    
    i_coeff_update_en(i) <= CFR_COEFF_UPDATE_EN(i);
    i_coeff_we(i) <= CFR_COEFF_WE(i);
    i_coeff_addr(i) <= CFR_COEFF_WRADDR(i)(9 downto 0);
    i_coeff_wrdata(i) <= CFR_COEFF_WRDATA(i);
    i_cfr_tap_num(i) <= CFR_TAP_NUM(i);

    u_LTE_SEC_PC_CFR_TOP_V2P5 : LTE_SEC_PC_CFR_TOP_V2P5
    generic map(
        FRAC_DLY_FILTER_EN                  => CFR_FRAC_DLY_FILTER_EN       ,--      : boolean := TRUE;
        UPSAMPLE_MODE_EN                    => CFR_UPSAMPLE_MODE_EN          --      : boolean := TRUE
    )
    port map(
        CFR_DATE_OUT                        => i_cfr_date(i)                ,--: out std_logic_vector(31 downto 0);
        CFR_VER_OUT                         => i_cfr_ver(i)                 ,--: out std_logic_vector(7 downto 0);
    
        RESET                               => i_rst_cfr(i)                 ,--: in  std_logic;
        CLK                                 => CLK_CFR                      ,--: in  std_logic;
        CLOCK_UNSTABLE                      => i_clk_unstable               ,--: in  std_logic;
        
        CFR_BYPASS                          => CFR_BYPASS((i*2)+1 downto i*2)     ,--: in  std_logic_vector(1 downto 0); 
    
        CFR_THRESHOLD_0                     => CFR_THRESHOLD(i*2)           ,--: in  std_logic_vector(15 downto 0);
        CFR_THRESHOLD_1                     => CFR_THRESHOLD((i*2)+1)       ,--: in  std_logic_vector(15 downto 0);
        CFR_PEAK_SPACING_0                  => CFR_PEAK_SPACING(i*2)        ,--: in  std_logic_vector(7 downto 0);
        CFR_PEAK_SPACING_1                  => CFR_PEAK_SPACING((i*2)+1)    ,--: in  std_logic_vector(7 downto 0);
    
        CFR_COEFF_UPDATE_EN                 => i_coeff_update_en(i)         ,--: in  std_logic;
        CFR_COEFF_WE                        => i_coeff_we(i)                ,--: in  std_logic;
        CFR_COEFF_WRADDR                    => i_coeff_addr(i)              ,--: in  std_logic_vector(9 downto 0);
        CFR_COEFF_WRDATA                    => i_coeff_wrdata(i)            ,--: in  std_logic_vector(31 downto 0);
    
        CFR_TAP_NUM                         => i_cfr_tap_num(i)             ,--: in  std_logic_vector(9 downto 0);
    
        CFR_0_INPUT_I                       => CFR_INPUT_I(i*2)             ,--: in  std_logic_vector(15 downto 0);
        CFR_0_INPUT_Q                       => CFR_INPUT_Q(i*2)             ,--: in  std_logic_vector(15 downto 0);
        CFR_1_INPUT_I                       => CFR_INPUT_I((i*2)+1)         ,--: in  std_logic_vector(15 downto 0);
        CFR_1_INPUT_Q                       => CFR_INPUT_Q((i*2)+1)         ,--: in  std_logic_vector(15 downto 0);
    
        CFR_0_OUTPUT_I                      => i_cfr_out_I(i*2)             ,--: out std_logic_vector(15 downto 0);
        CFR_0_OUTPUT_Q                      => i_cfr_out_Q(i*2)             ,--: out std_logic_vector(15 downto 0);
        CFR_1_OUTPUT_I                      => i_cfr_out_I((i*2)+1)         ,--: out std_logic_vector(15 downto 0);
        CFR_1_OUTPUT_Q                      => i_cfr_out_Q((i*2)+1)         , --: out std_logic_vector(15 downto 0)
    
        PIM_CFR_0_OUTPUT_I                  => i_pim_cfr_out_I(i*2)             ,--: out std_logic_vector(15 downto 0);
        PIM_CFR_0_OUTPUT_Q                  => i_pim_cfr_out_Q(i*2)             ,--: out std_logic_vector(15 downto 0);
        PIM_CFR_1_OUTPUT_I                  => i_pim_cfr_out_I((i*2)+1)         ,--: out std_logic_vector(15 downto 0);
        PIM_CFR_1_OUTPUT_Q                  => i_pim_cfr_out_Q((i*2)+1)          --: out std_logic_vector(15 downto 0)
    
    );
    end generate;

    CFR_HC_GEN : for k in TX_CFR_ANT_NUM-1 downto 0 generate
        u_CFR_HC : HARD_CLIPPING
        generic map(
            DEVICE                              => DEVICE                        --: string  := "7SERIES" -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
            )
        port map(
            RST                                 => i_rst_cfr_hc(k)              ,--: in  std_logic;                     -- active high
            --nRESET                              => i_rst_cfr_hc_n(k)            ,--: in  std_logic;                    -- active low
            CLK                                 => CLK_CFR                      ,--: in  std_logic;                    
            --sample_en                         =>                              ,--  : in  std_logic;                  -- Channel BW Sampling rate
            DATA_I_IN                           => i_cfr_out_I(k)               ,--: in  std_logic_vector(15 downto 0);    -- input signal
            DATA_Q_IN                           => i_cfr_out_Q(k)               ,--: in  std_logic_vector(15 downto 0);    -- input signal
        
            THRESHOLD                           => CFR_HC_THRES(k)              ,--: in  std_logic_vector(15 downto 0);    -- clipping threshold(u16)
        
            DATA_I_OUT                          => i_cfr_hc_out_I(k)            ,--: out std_logic_vector(15 downto 0);    -- output(clipped) signal
            DATA_Q_OUT                          => i_cfr_hc_out_Q(k)            ,--: out std_logic_vector(15 downto 0);    -- output(clipped) signal
        
            HC_EN                               => CFR_HC_EN(k)                 ,--: in  std_logic;                    -- 
            HC_ON                               => open                          --: out std_logic
        );
    end generate;

--u_dif_pwr_meas_opd : dif_pwr_meas_opd
--generic map(
--    CLK_DIV                     => CLK_DIV                      ,--: natural:= 2; -- CLK_DIV = clock rate/data rate 
--    ACCUM_NUM_WIDTH             => ACCUM_NUM_WIDTH              ,--: natural:= 20;-- Number of samples to be averaged = 2^ACCUM_NUM_WIDTH
--    DATA_WIDTH                  => DATA_WIDTH                   ,--: natural:= 16;-- Data bits width
--
--    -- for OPD 
--    OPD_ACCUM_NUM_WIDTH         => OPD_ACCUM_NUM_WIDTH           --: natural:= 16 -- Number of samples to be averaged(OPD) = 2^ACCUM_NUM_WIDTH_OPD
--)
--port map(
--    RESET                       => i_rst_cfr_pwr(m)             ,--: in  std_logic;
--    CLK                         => CLK_CFR                      ,--: in  std_logic;
--
--    FRAME_SYNC                  => i_fs_10ms_dly                ,--: in  std_logic;-- 10ms strobe
--
--    DATA_IN_I                   => i_cfr_hc_out_I(m)            ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0); 
--    DATA_IN_Q                   => i_cfr_hc_out_Q(m)            ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
--    
--    PWR_UPDATE_DONE             => open                         ,--: out std_logic;    
--    PWR_OUT                     => CFR_PWR_OUT(m)               ,--: out std_logic_vector(2*DATA_WIDTH-1 downto 0);
--
--    -- for OPD
--    OPD_TH                      => OPD_TH                       ,--: in  std_logic_vector(2*DATA_WIDTH-1 downto 0); 
--    OPD_PWR_OUT                 => OPD_PWR_OUT(m)               ,--: out std_logic_vector(2*DATA_WIDTH-1 downto 0);
--    OPD_PWR_UPDATE_DONE         => open                         ,--: out std_logic;    
--    OPD_FLAG                    => OPD_FLAG(m)               --: out std_logic
--);

    process(CLK_CFR)
    begin
        if rising_edge(CLK_CFR) then
            i_fs_ssb_d   <=  FS_SSB_IN  ;
            i_fs_ssb_dd  <=  i_fs_ssb_d ;
        end if;
    end process;

    i_pwrmeas_sync  <= i_fs_ssb_dd and i_fs_10ms_dly ;

    CFR_PWR_MSR_GEN : for m in TX_CFR_ANT_NUM-1 downto 0 generate
        u_cfrout_pwr_msr_tdd : PWRMEAS_MANTISSA
        generic map(
            DEVICE                              => DEVICE     , --: string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
            CLK_DIV                             => CFR_CLK_DIV,  --: natural :=  2; -- CLK_DIV = (Clock Rate)/(Data Rate)
            DATA_WIDTH                          => CFR_DATA_WIDTH  --: natural := 16  -- Data bit width
            )
        port map(
            RST                                 => i_rst_cfr_pwr(m)             ,--: in  std_logic;
            CLK                                 => CLK_CFR                      ,--: in  std_logic;
            
--            FRAME_SYNC_IN                       => i_fs_ssb_dly                 , --i_fs_10ms_dly                ,--: in  std_logic; -- BFN 10ms strobe
            FRAME_SYNC_IN                       => i_pwrmeas_sync               , --i_fs_10ms_dly                ,--: in  std_logic; -- BFN 10ms strobe
            TDD_SIG_IN                          => i_tdd_strb_dly               ,--: in  std_logic; -- TDD strobe, DL : '1', UL : '0', when FDD mode, always set high
        
            DATA_I_IN                           => i_cfr_hc_out_I(m)            ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
            DATA_Q_IN                           => i_cfr_hc_out_Q(m)            ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
        
            PWR_UPDATE_DONE_OUT                 => CFR_PWR_MSR_DONE(m)          ,--: out std_logic;
            PWR_OUT                             => CFR_PWR_OUT(m)                --: out std_logic_vector(31 downto 0)
        );
    
        u_dif_pwr_meas_opd : CFR_OPD_CHK
        port map(
            RESET                               => i_rst_cfr_pwr(m)             ,--: in  std_logic;
            CLK                                 => CLK_CFR                      ,--: in  std_logic;
            
            FS_10M                              => i_fs_10ms_dly                ,--: in  std_logic;
            OPD_THRES                           => OPD_TH(m)                    ,--: in  std_logic_vector(31 downto 0);
            
            CFROUT_I                            => i_cfr_hc_out_I(m)            ,--: in  std_logic_vector(15 downto 0);
            CFROUT_Q                            => i_cfr_hc_out_Q(m)            ,--: in  std_logic_vector(15 downto 0);
            
            OPD_DETECT_FLAG                     => OPD_FLAG(m)                  ,--: out std_logic;
            DETECT_OPD_PWR                      => OPD_PWR_OUT(m)                --: out std_logic_vector(31 downto 0)
        );
    
    end generate;

    CFR_WRAP_OUT_GEN : for n in TX_CFR_ANT_NUM-1 downto 0 generate
    CFR_OUTPUT_I(n) <= i_cfr_hc_out_I(n);
    CFR_OUTPUT_Q(n) <= i_cfr_hc_out_Q(n);
    end generate;




    CFR_WRAP_PIM_OUT_GEN : for n in TX_CFR_ANT_NUM-1 downto 0 generate
        CFR_PIM_OUTPUT_I(n) <= i_pim_cfr_out_I(n);
        CFR_PIM_OUTPUT_Q(n) <= i_pim_cfr_out_Q(n);
    end generate;



    u_CFR_TDD_DLY_GEN : TDD_STRB_DLY
    generic map(
        CLK_CNTDLY                          => CFR_DELAY_VAL_INT            --1019                          --: integer
    )
    port map(
        RST                                 => i_rst_cfr(0)                 ,--: in  std_logic; -- Active high reset
        CLK                                 => CLK_CFR                      ,--: in  std_logic; -- Clock
        
        BLK_BYPASS_IN                       => CFR_BYPASS(0)                ,--: in  std_logic; -- '0' normal mode, '1' bypass mode
        
        BFN_STROBE_IN                       => FS_10MS_IN                   ,--: in  std_logic;
        TDD_STROBE_IN                       => TDD_STRB_DLY_IN              ,--: in  std_logic;
    
        BFNSTRB_DLY_OUT                     => i_fs_10ms_dly                ,--: out std_logic;
        TDDSTRB_DLY_OUT                     => i_tdd_strb_dly                --: out std_logic
    );
    
    u_CFR_PIM_SYNC_DLY_GEN : TDD_STRB_DLY
    generic map(
        CLK_CNTDLY                          => CFR_PIM_DELAY_VAL_INT            --1019                          --: integer
    )
    port map(
        RST                                 => i_rst_cfr(0)                 ,--: in  std_logic; -- Active high reset
        CLK                                 => CLK_CFR                      ,--: in  std_logic; -- Clock
        
        BLK_BYPASS_IN                       => CFR_BYPASS(0)                ,--: in  std_logic; -- '0' normal mode, '1' bypass mode
        
        BFN_STROBE_IN                       => FS_10MS_IN                   ,--: in  std_logic;
        TDD_STROBE_IN                       => TDD_STRB_DLY_IN              ,--: in  std_logic;    
        
        BFNSTRB_DLY_OUT                     => i_pim_sync_dly               ,--: out std_logic;
        TDDSTRB_DLY_OUT                     => open                          --: out std_logic
       
      );
   
    u_CFR_SSBSTRB_DLY_GEN : TDD_STRB_DLY
    generic map(
        CLK_CNTDLY                          => CFR_DELAY_VAL_INT            --1019                          --: integer
    )
    port map(
        RST                                 => i_rst_cfr(0)                 ,--: in  std_logic; -- Active high reset
        CLK                                 => CLK_CFR                      ,--: in  std_logic; -- Clock
        
        BLK_BYPASS_IN                       => CFR_BYPASS(0)                ,--: in  std_logic; -- '0' normal mode, '1' bypass mode
        
        BFN_STROBE_IN                       => FS_SSB_IN                    ,--: in  std_logic;
        TDD_STROBE_IN                       => '0'                          ,--: in  std_logic;
    
        BFNSTRB_DLY_OUT                     => i_fs_ssb_dly                 ,--: out std_logic;
        TDDSTRB_DLY_OUT                     => open                          --: out std_logic
    );
   

--u_CFR_BCF_DLY_GEN : TDD_STRB_DLY
--generic map(
--    CLK_CNTDLY                  => CFR_DELAY_VAL_INT            --1019                          --: integer
--    )
--port map(
--    RST                         => i_rst_cfr(0)                 ,--: in  std_logic; -- Active high reset
--    CLK                         => CLK_CFR                      ,--: in  std_logic; -- Clock
--    
--    BLK_BYPASS_IN               => CFR_BYPASS(0)                ,--: in  std_logic; -- '0' normal mode, '1' bypass mode
--    
--    BFN_STROBE_IN               => BCF_ENB_IN                   ,--: in  std_logic;
--    TDD_STROBE_IN               => '0'                          ,--: in  std_logic;
--
--    BFNSTRB_DLY_OUT             => BCF_ENB_OUT                  ,--: out std_logic;
--    TDDSTRB_DLY_OUT             => open                          --: out std_logic
--    );
    
    FS_10MS_DLY_OUT             <= i_fs_10ms_dly;
    TDD_STRB_DLY_OUT            <= i_tdd_strb_dly;
    FS_SSB_DLY_OUT              <= i_fs_ssb_dly;
    
    process(rst_cfr_all,CLK_CFR)
    begin
        if rst_cfr_all = '1' then
            i_tog <= '0';
        elsif rising_edge(CLK_CFR) then
            i_tog <= not i_tog;
            i_tog_d <= i_tog;
        end if;
    end process;

    CFR_OUTPUT_GEN : if CFR_UPSAMPLE_MODE_EN = TRUE generate
        CFR_OUTPUT_SYNC_GEN : for n in TX_CFR_ANT_NUM-1 downto 0 generate
            CFR_OUTPUT_SYNC(n) <= '1';
        end generate;
    end generate;

    CFR_OUTPUT_BR_GEN : if CFR_UPSAMPLE_MODE_EN = FALSE generate
        CFR_OUTPUT_SYNC_GEN : for n in TX_CFR_ANT_NUM-1 downto 0 generate
            CFR_OUTPUT_SYNC(n) <= i_tog_d;
        end generate;
    end generate;


     
    DUMP_BFN_STRB_OUT <= (others => '0');
    DUMP_DATA_OUT     <= (others => (others => '0'));
    
    DUMP_VLD_GEN : if CFR_UPSAMPLE_MODE_EN = TRUE generate
        DUMP_DVLD_OUT(0) <= '1';
        DUMP_DVLD_OUT(1) <= '1';
    end generate;
    
    DUMP_VLD_BR_GEN : if CFR_UPSAMPLE_MODE_EN = FALSE generate
        DUMP_DVLD_OUT(0) <= i_tog;
        DUMP_DVLD_OUT(1) <= i_tog;
    end generate;
    
    DBG_SIG_OUT <= (others => (others => '0'));
    
    CFR_PIM_SYNC_OUT <= i_pim_sync_dly;

end arc_CFR_LTE_WRAPPER;
