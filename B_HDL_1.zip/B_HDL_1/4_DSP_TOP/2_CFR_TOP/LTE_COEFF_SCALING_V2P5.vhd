-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
library UNISIM;
use UNISIM.VComponents.all;

entity LTE_COEFF_SCALING_V2P5 is

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							CLOCK_UNSTABLE		: in	std_logic;
							
							CFR_COEFF_UPDATE_EN			: in	std_logic;
							COEFF_WE					: in	std_logic;
							COEFF_WR_ADDR			: in	std_logic_vector(9 downto 0);
							COEFF_WR_DATA			: in	std_logic_vector(31 downto 0);  -- MSB 16 bit : Q , LSB 16 bit : I
							
							READ_DIR          : in  std_logic;
							READ_ADDRESS			: in	std_logic_vector(9 downto 0);
							
							--CH_NUM            : in  std_logic;
							PEAK_I						: in	std_logic_vector(15 downto 0);
							PEAK_Q						: in	std_logic_vector(15 downto 0);
							
							CALCELLATION_I		: out	std_logic_vector(16 downto 0);
							CALCELLATION_Q		: out	std_logic_vector(16 downto 0)
						);
end LTE_COEFF_SCALING_V2P5;

architecture arc_LTE_COEFF_SCALING_V2P5 of LTE_COEFF_SCALING_V2P5 is

--============= Xilinx Simple Dual port Ram core =====================================
component CFR_COEFF_DPRAM_32x512
  PORT (
    clka : IN STD_LOGIC;
    ena : IN STD_LOGIC;
    wea : IN STD_LOGIC_VECTOR(0 DOWNTO 0);
    addra : IN STD_LOGIC_VECTOR(8 DOWNTO 0);
    dina : IN STD_LOGIC_VECTOR(31 DOWNTO 0);
    clkb : IN STD_LOGIC;
    enb : IN STD_LOGIC;
    addrb : IN STD_LOGIC_VECTOR(8 DOWNTO 0);
    doutb : OUT STD_LOGIC_VECTOR(31 DOWNTO 0)
  );
end component;



component CFR_COEFF_DPRAM_32x1024
  PORT (
    clka : IN STD_LOGIC;
    ena : IN STD_LOGIC;
    wea : IN STD_LOGIC_VECTOR(0 DOWNTO 0);
    addra : IN STD_LOGIC_VECTOR(9 DOWNTO 0);
    dina : IN STD_LOGIC_VECTOR(31 DOWNTO 0);
    clkb : IN STD_LOGIC;
    enb : IN STD_LOGIC;
    addrb : IN STD_LOGIC_VECTOR(9 DOWNTO 0);
    doutb : OUT STD_LOGIC_VECTOR(31 DOWNTO 0)
  );
end component;








component COMPLEX_MULT_V2P5

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM            : in  std_logic;
							INPUTA_REAL				: in	std_logic_vector(15 downto 0);
							INPUTA_IMAG				: in	std_logic_vector(15 downto 0);
							INPUTB_REAL				: in	std_logic_vector(15 downto 0);
							INPUTB_IMAG				: in	std_logic_vector(15 downto 0);
							
							OUT_REAL					: out	std_logic_vector(16 downto 0);
							OUT_IMAG					: out	std_logic_vector(16 downto 0)
						);
end component;

signal mem_coeff_out		: std_logic_vector(31 downto 0);
signal we_s							: std_logic_vector(0 downto 0);
signal clk_norm_f, clk_norm_ff : std_logic;
signal cpu_port_en_f, cpu_port_en_ff : std_logic;
signal mem_port_en      : std_logic;
signal i_read_dir       : std_logic;
signal i_read_dir_d     : std_logic;
signal i_coeff_inph     : std_logic_vector(15 downto 0);
--signal i_coeff_quad_bypass     : std_logic_vector(15 downto 0);
--signal i_coeff_quad_2scomp     : std_logic_vector(15 downto 0);
signal i_coeff_quad     : std_logic_vector(15 downto 0);











begin

we_s(0) <= COEFF_WE;

process(RESET,CLK)
begin
	if RESET = '1' then
		clk_norm_f <= '0';
		clk_norm_ff <= '0';
		cpu_port_en_f <= '0';
		cpu_port_en_ff <= '0';
	elsif (CLK'event and CLK='1') then
		clk_norm_f <= not CLOCK_UNSTABLE;
		clk_norm_ff <= clk_norm_f;
		cpu_port_en_f <= CFR_COEFF_UPDATE_EN;
		cpu_port_en_ff <= cpu_port_en_f;
		
		mem_port_en <= cpu_port_en_ff and clk_norm_ff;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		i_read_dir <= '1';
		i_read_dir_d <= '1';
		i_coeff_inph <= (others => '0');
		i_coeff_quad <= (others => '0');
		--i_coeff_quad_2scomp <= (others => '0');
		--i_coeff_quad_bypass <= (others => '0');
	elsif (CLK'event and CLK='1') then
	  i_read_dir <= READ_DIR;
	  i_read_dir_d <= i_read_dir;
	  i_coeff_inph <= mem_coeff_out(15 downto 0);
	  
	  if i_read_dir_d = '1' then
	    i_coeff_quad<= (not (mem_coeff_out(31 downto 16))) + 1;
	  else
	    i_coeff_quad <= mem_coeff_out(31 downto 16);
	  end if;
	end if;
end process;

--i_coeff_quad <= i_coeff_quad_2scomp when i_read_dir = '1' else i_coeff_quad_bypass;

--   u_cfr_coeff_mem : CFR_COEFF_DPRAM_32x512
--   	port map(
--   	clka			=> CLK, --: in std_logic;
--   	ena				=> mem_port_en,
--   	wea				=> we_s, --: in std_logic_vector(0 downto 0);
--   	addra			=> COEFF_WR_ADDR, --: in std_logic_vector(8 downto 0);
--   	dina			=> COEFF_WR_DATA, --: in std_logic_vector(31 downto 0);
--   	clkb			=> CLK, --: in std_logic;
--   	enb				=> clk_norm_ff,
--   	addrb			=> READ_ADDRESS(8 downto 0), --: in std_logic_vector(8 downto 0);
--   	doutb			=> mem_coeff_out  --: out std_logic_vector(31 downto 0)
--   	);



u_cfr_coeff_mem : CFR_COEFF_DPRAM_32x1024
	port map(
	clka			=> CLK, --: in std_logic;
	ena				=> mem_port_en,
	wea				=> we_s, --: in std_logic_vector(0 downto 0);
	addra			=> COEFF_WR_ADDR, --: in std_logic_vector(8 downto 0);
	dina			=> COEFF_WR_DATA, --: in std_logic_vector(31 downto 0);
	clkb			=> CLK, --: in std_logic;
	enb				=> clk_norm_ff,
	addrb			=> READ_ADDRESS, --: in std_logic_vector(8 downto 0);
	doutb			=> mem_coeff_out  --: out std_logic_vector(31 downto 0)
	);









u_comp_mult_blk : COMPLEX_MULT_V2P5

			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK, --: in	std_logic;
							
							--CH_NUM            => CH_NUM, --: in  std_logic;
							INPUTA_REAL				=> i_coeff_inph,  --mem_coeff_out(15 downto 0), --: in	std_logic_vector(15 downto 0);
							INPUTA_IMAG				=> i_coeff_quad,  --mem_coeff_out(31 downto 16), --: in	std_logic_vector(15 downto 0);
							INPUTB_REAL				=> PEAK_I, --: in	std_logic_vector(15 downto 0);
							INPUTB_IMAG				=> PEAK_Q, --: in	std_logic_vector(15 downto 0);
							
							OUT_REAL					=> CALCELLATION_I, --: out	std_logic_vector(16 downto 0);
							OUT_IMAG					=> CALCELLATION_Q  --: out	std_logic_vector(16 downto 0)
						);

end arc_LTE_COEFF_SCALING_V2P5;
