-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

entity CFR_BYPASS_SEL_V2 is
   port(
   
        RESET                 : in  std_logic;
        CLK                   : in  std_logic;
        
        CFR_BYPASS            : in  std_logic_vector(1 downto 0);
        
        --CH_NUM                : in  std_logic;
        CFR_I_IN              : in  std_logic_vector(15 downto 0); -- from input mux block
        CFR_Q_IN              : in  std_logic_vector(15 downto 0); -- from input mux block
        
        ITR_I_DATA            : in  std_logic_vector(15 downto 0); -- from last cfr stage block
        ITR_Q_DATA            : in  std_logic_vector(15 downto 0); -- from last cfr stage block
        
        SEL_IOUT              : out std_logic_vector(15 downto 0);
        SEL_QOUT              : out std_logic_vector(15 downto 0)    
        );
end CFR_BYPASS_SEL_V2;

architecture arc_CFR_BYPASS_SEL_V2 of CFR_BYPASS_SEL_V2 is

signal i_tog            : std_logic;
signal i_cfr_bypass_f   : std_logic_vector(1 downto 0);
signal i_cfr_bypass_ff  : std_logic_vector(1 downto 0);
signal i_sel_idata      : std_logic_vector(15 downto 0);
signal i_sel_qdata      : std_logic_vector(15 downto 0);

begin

process(RESET,CLK)
begin
   if RESET = '1' then
      i_tog <= '0';
   elsif rising_edge(CLK) then
      i_tog <= not i_tog;
   end if;
end process;

process(RESET,CLK)
begin
   if RESET = '1' then
      i_cfr_bypass_f <= (others => '0');
      i_cfr_bypass_ff <= (others => '0');
   elsif rising_edge(CLK) then
      i_cfr_bypass_f <= CFR_BYPASS;
      i_cfr_bypass_ff <= i_cfr_bypass_f;
   end if;
end process;

process(RESET,CLK)
begin
   if RESET = '1' then
      i_sel_idata <= (others => '0');
      i_sel_qdata <= (others => '0');
   elsif rising_edge(CLK) then
      if i_tog = '1' then
         if i_cfr_bypass_ff(1) = '1' then
            i_sel_idata <= CFR_I_IN;
            i_sel_qdata <= CFR_Q_IN;
         else
            i_sel_idata <= ITR_I_DATA;
            i_sel_qdata <= ITR_Q_DATA;
         end if;
      else
         if i_cfr_bypass_ff(0) = '1' then
            i_sel_idata <= CFR_I_IN;
            i_sel_qdata <= CFR_Q_IN;
         else
            i_sel_idata <= ITR_I_DATA;
            i_sel_qdata <= ITR_Q_DATA;
         end if;
      end if;
   end if;
end process;

process(RESET,CLK)
begin
   if RESET = '1' then
      SEL_IOUT <= (others => '0');
      SEL_QOUT <= (others => '0');
   elsif rising_edge(CLK) then
      SEL_IOUT <= i_sel_idata;
      SEL_QOUT <= i_sel_qdata;
   end if;
end process;

end arc_CFR_BYPASS_SEL_V2;