-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity CPG_COUNTER_V2P5 is

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM            : in  std_logic;
							TRIG_ALLOCATION		: in	std_logic;
							TAPS_NUMBER				: in	std_logic_vector(9 downto 0);
							MIN_NUMBER				: in	std_logic_vector(9 downto 0);
							
							--CURRENT_ADDR			: out	std_logic_vector(9 downto 0);
							ADDR_DIR          : out std_logic;
							CURRENT_ADDR			: out	std_logic_vector(9 downto 0);
							ALLOC_FLAG				: out	std_logic;
							INTERRUPT_FLAG		: out	std_logic
						);
end CPG_COUNTER_V2P5;

architecture arc_CPG_COUNTER_V2P5 of CPG_COUNTER_V2P5 is

signal i_tog            : std_logic;
--signal addr_cnt_0				: std_logic_vector(9 downto 0);
--signal addr_cnt_1				: std_logic_vector(9 downto 0);
signal addr_cnt_0				: std_logic_vector(8 downto 0);
signal addr_cnt_1				: std_logic_vector(8 downto 0);

signal i_cnt0_direc     : std_logic;
signal i_cnt1_direc     : std_logic;
signal i_cnt0_progress  : std_logic;
signal i_cnt1_progress  : std_logic;
signal i_center_tap     : std_logic_vector(8 downto 0);

signal i_interrupt_flag_0 : std_logic;
signal i_interrupt_flag_1 : std_logic;

--attribute max_fanout : string;
--attribute max_fanout of i_taps_number : signal is "30";
--attribute max_fanout of i_min_number : signal is "30";
--attribute max_fanout of i_max_number : signal is "30";

begin

i_center_tap <= (others => '0') when TAPS_NUMBER(9 downto 1) = "000000000" 
                else (TAPS_NUMBER(9 downto 1) - 1);

process(RESET,CLK)
begin
   if RESET = '1' then
      i_tog <= '0';
   elsif rising_edge(CLK) then
      i_tog <= not i_tog;
   end if;
end process;

--------------------------- generate direction -----------------------------
process(RESET,CLK)
begin
	if RESET = '1' then
		i_cnt1_direc <= '1';
	elsif (CLK'event and CLK='1') then
	  if i_tog = '1' then               -- ch.1
	    if TRIG_ALLOCATION = '1' then
	      i_cnt1_direc <= '0';
	    else
	      if addr_cnt_1 = i_center_tap then
	        i_cnt1_direc <= '1';
	      end if;
	    end if;
	  end if;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		i_cnt0_direc <= '1';
	elsif (CLK'event and CLK='1') then
	  if i_tog = '0' then               -- ch.0
	    if TRIG_ALLOCATION = '1' then
	      i_cnt0_direc <= '0';
	    else
	      if addr_cnt_0 = i_center_tap then
	        i_cnt0_direc <= '1';
	      end if;
	    end if;
	  end if;
	end if;
end process;
-----------------------------------------------------------------------------

--------------------------- generate counter progress signals ---------------
process(RESET,CLK)
begin
	if RESET = '1' then
		i_cnt1_progress <= '0';
	elsif (CLK'event and CLK='1') then
	  if i_tog = '1' then               -- ch.1
	    if TRIG_ALLOCATION = '1' then
	      i_cnt1_progress <= '1';
	    else
	      if (i_cnt1_direc = '1') and (addr_cnt_1 = "000000000") then
	        i_cnt1_progress <= '0';
	      end if;
	    end if;
	  end if;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		i_cnt0_progress <= '0';
	elsif (CLK'event and CLK='1') then
	  if i_tog = '0' then               -- ch.0
	    if TRIG_ALLOCATION = '1' then
	      i_cnt0_progress <= '1';
	    else
	      if (i_cnt0_direc = '1') and (addr_cnt_0 = "000000000") then
	        i_cnt0_progress <= '0';
	      end if;
	    end if;
	  end if;
	end if;
end process;

-----------------------------------------------------------------------------

------------------------- Generate address counter --------------------------
process(RESET,CLK)
begin
	if RESET = '1' then
		addr_cnt_1 <= (others => '1');
	elsif (CLK'event and CLK='1') then
	  --if CH_NUM = '1' then
	  if i_tog = '1' then
		  if TRIG_ALLOCATION = '1' then
		  	addr_cnt_1 <= (others => '0');
		  else
		  	--if (TAPS_NUMBER > addr_cnt_1) then
		  	if i_cnt1_progress = '1' then
		  	  if i_cnt1_direc = '1' then
			      addr_cnt_1 <= addr_cnt_1 - 1;
			    else
			      addr_cnt_1 <= addr_cnt_1 + 1;
          end if;
        else
          addr_cnt_1 <= (others => '1');
        end if;
		  end if;
		end if;		
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		addr_cnt_0 <= (others => '1');
	elsif (CLK'event and CLK='1') then
	  --if CH_NUM = '0' then
	  if i_tog = '0' then
		  if TRIG_ALLOCATION = '1' then
		  	addr_cnt_0 <= (others => '0');
		  else
		  	--if (TAPS_NUMBER > addr_cnt_0) then
		  	if i_cnt0_progress = '1' then
		  	  if i_cnt0_direc = '1' then
			      addr_cnt_0 <= addr_cnt_0 - 1;
			    else
			      addr_cnt_0 <= addr_cnt_0 + 1;
          end if;
        else
          addr_cnt_0 <= (others => '1');
        end if;
		  end if;
		end if;		
	end if;
end process;
-----------------------------------------------------------------------------

process(RESET,CLK)
begin
  if RESET = '1' then
    i_interrupt_flag_0 <= '1';
    i_interrupt_flag_1 <= '1';
		INTERRUPT_FLAG <= '1';
  elsif (CLK'event and CLK='1') then
     if i_tog = '1' then
        if TRIG_ALLOCATION = '1' then
           i_interrupt_flag_1 <= '1';
        end if;
        
        --else
        if (addr_cnt_0 = "111111111")then
	         i_interrupt_flag_0 <= '1';
	      else
	         if (MIN_NUMBER) = ("0" & addr_cnt_0) then
	            if i_cnt0_direc = '1' then
	               i_interrupt_flag_0 <= '1';
	            else
	               i_interrupt_flag_0 <= '0';
	            end if;
	         end if;
	      end if;
	      --end if;
	   else
	      if TRIG_ALLOCATION = '1' then
           i_interrupt_flag_0 <= '1';
        end if;
        
        --else
        if (addr_cnt_1 = "111111111")then
           i_interrupt_flag_1 <= '1';
        else
           if (MIN_NUMBER) = ("0" & addr_cnt_1) then
	            if i_cnt1_direc = '1' then
	               i_interrupt_flag_1 <= '1';
	            else
	               i_interrupt_flag_1 <= '0';
	            end if;
	         end if;
	      end if;
	      --end if;
	   end if;
	   
	   if i_tog = '1' then
	     INTERRUPT_FLAG <= i_interrupt_flag_0;
	   else
	     INTERRUPT_FLAG <= i_interrupt_flag_1;
	   end if;
  end if;
end process;

--INTERRUPT_FLAG <= i_interrupt_flag_1 when i_tog = '1' else i_interrupt_flag_0;

process(RESET,CLK)
begin
	if RESET = '1' then
		ALLOC_FLAG <= '0';
	elsif (CLK'event and CLK='1') then
		 --if CH_NUM = '1' then
		 if i_tog = '1' then
		   --if (TAPS_NUMBER > addr_cnt_0) then
		   --   ALLOC_FLAG <= '1';
		   --else
		   --   ALLOC_FLAG <= '0';
		   --end if;
		   ALLOC_FLAG <= i_cnt0_progress;
		 else
		   --if (TAPS_NUMBER > addr_cnt_1) then
		   --   ALLOC_FLAG <= '1';
		   --else
		   --   ALLOC_FLAG <= '0';
		   --end if;
		   ALLOC_FLAG <= i_cnt1_progress;
		 end if;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		CURRENT_ADDR <= (others => '0');
	elsif (CLK'event and CLK='1') then
		 --if CH_NUM = '1' then
		 if i_tog = '1' then
		   CURRENT_ADDR <= '0' & addr_cnt_0;
		 else
		   CURRENT_ADDR <= '1' & addr_cnt_1;
		 end if;
	end if;
end process;












process(RESET,CLK)
begin
	if RESET = '1' then
		ADDR_DIR <= '1';
	elsif (CLK'event and CLK='1') then
		 if i_tog = '1' then
		   ADDR_DIR <= i_cnt0_direc;
		 else
		   ADDR_DIR <= i_cnt1_direc;
		 end if;
	end if;
end process;

end arc_CPG_COUNTER_V2P5;
