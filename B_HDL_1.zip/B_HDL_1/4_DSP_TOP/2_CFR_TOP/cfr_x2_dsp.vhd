------------------------------------------------------------------
-- round stage
------------------------------------------------------------------
-- 2013.11.01, vyacheslav : 1st release, system verilog
-- 2014.01.29, wj311.kim  : convert system_verilog to vhdl
-- 2014.06.15, wj311.kim  : Ver.2, processing delay is 3 CLK(fixed)
------------------------------------------------------------------
-----------------------------------------------------------------------------
--Fixed Round stage with one input and one ouput bus
--VAR_WIDTH         - width of bit shift value for variable gain control
--FIXED_GAIN        - whether gain fixed or not
--WIDTH_IN          - input data width
--WIDTH_OUT         - output data width
--BINARY_POINT      - position of binary point
--ROUNDING          - "FULL_PRECISION","TRUNCATE","ROUND_INF", "ROUND_EVEN"
--OVERFLOW          - "WRAP", "SATURATE"
-----------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_CONFIG.all;
use work.RU_FPGA_FNC.all;

Library UNISIM;
use UNISIM.vcomponents.all;

entity cfr_x2_dsp is --dduc_dsp
generic(
    PCIN_EN                     : boolean := FALSE;
    D_EN                        : boolean := FALSE;
    C_EN                        : boolean := FALSE;

    WIDTH_A                     : integer := 16;
    WIDTH_D                     : integer := 16;
    WIDTH_B                     : integer := 16;
    WIDTH_C                     : integer := 16;
    WIDTH_PCIN                  : integer := 48;
    WIDTH_PCOUT                 : integer := 48;
    WIDTH_P                     : integer := 48
);
port(
    CLK                         : in  std_logic;

    SEL                         : in  std_logic;    
    CEP                         : in  std_logic;    
    DSP_A_INV                   : in  std_logic;    

    DSP_A                       : in  std_logic_vector(WIDTH_A-1 downto 0);
    DSP_D                       : in  std_logic_vector(WIDTH_D-1 downto 0);
    DSP_B                       : in  std_logic_vector(WIDTH_B-1 downto 0);
    DSP_C                       : in  std_logic_vector(WIDTH_C-1 downto 0);

    DSP_PCIN                    : in  std_logic_vector(WIDTH_PCIN-1 downto 0);
    DSP_PCOUT                   : out std_logic_vector(WIDTH_PCOUT-1 downto 0);
    DSP_P                       : out std_logic_vector(WIDTH_P-1 downto 0)
);
end cfr_x2_dsp;

architecture Behavioral of cfr_x2_dsp is

constant A_INT_WIDTH            : integer := 30;
constant D_INT_WIDTH            : integer := 25;
constant B_INT_WIDTH            : integer := 18;
constant C_INT_WIDTH            : integer := 48;
constant P_INT_WIDTH            : integer := 48;

constant CEC                    : std_logic := ternary_func(C_EN = TRUE, '1', '0');
constant RSTC                   : std_logic := ternary_func(C_EN = TRUE, '0', '1');

constant ALUMODE                : std_logic_vector(3 downto 0) := "0000"; -- for Z+X+Y+CIN
constant ZERO                   : std_logic_vector(P_INT_WIDTH-1 downto 0):= (others => '0'); 

signal INMODE0                  : std_logic := ternary_func(D_EN = TRUE, '1', '0');-- for pre-adder D+A1 or A2
signal INMODE1                  : std_logic := '0';-- for pre-adder D+A1 or A2
signal INMODE2                  : std_logic := ternary_func(D_EN = TRUE, '1', '0');-- for pre-adder D+A1 or A2
signal INMODE3                  : std_logic := '0';-- for pre-adder D+A1 or A2
signal INMODE4                  : std_logic := '0';-- multiplier B port, '0' : B2, '1' : B1

signal OPMODE0                  : std_logic := '1';-- for X Multiplexer output to be M 
signal OPMODE1                  : std_logic := '0';-- for X Multiplexer output to be M  
signal OPMODE2                  : std_logic := '1';-- for Y Multiplexer output to be M 
signal OPMODE3                  : std_logic := '0';-- for Y Multiplexer output to be M  
signal OPMODE4                  : std_logic := ternary_func(PCIN_EN = TRUE, '1', '0');-- for Z Multiplexer output to be PCIN or P
signal OPMODE5                  : std_logic := '0';-- for Z Multiplexer output to be PCIN or P
signal OPMODE6                  : std_logic := '0';-- for Z Multiplexer output to be PCIN or P

signal INMODE                   : std_logic_vector(4 downto 0);
signal OPMODE                   : std_logic_vector(6 downto 0);

signal PCOUT                    : std_logic_vector(P_INT_WIDTH-1 downto 0); 
signal P                        : std_logic_vector(P_INT_WIDTH-1 downto 0); 
signal PCIN                     : std_logic_vector(P_INT_WIDTH-1 downto 0); 
signal A                        : std_logic_vector(A_INT_WIDTH-1 downto 0); 
signal B                        : std_logic_vector(B_INT_WIDTH-1 downto 0); 
signal C                        : std_logic_vector(P_INT_WIDTH-1 downto 0); 
signal D                        : std_logic_vector(D_INT_WIDTH-1 downto 0); 

attribute DONT_TOUCH : string;
attribute DONT_TOUCH of DSP48E1_inst : label is "TRUE";

begin

DSP_PCOUT   <= PCOUT(WIDTH_PCOUT-1 downto 0);
DSP_P       <= P(WIDTH_P-1 downto 0);

PCIN        <= sign_extension(DSP_PCIN, P_INT_WIDTH); -- 48-bit input: P cascade input

A           <= sign_extension(DSP_A, A_INT_WIDTH);   -- 8  bit scale-up for unused bits disabled(low bits)
D           <= sign_extension(DSP_D, D_INT_WIDTH);   -- 8  bit scale-up for unused bits disabled(low bits)
B           <= sign_extension(DSP_B, B_INT_WIDTH);   -- 1  bit scale-up for unused bits disabled(low bits)
C           <= sign_extension(DSP_C, C_INT_WIDTH);   -- 10 bit scale-up for unused bits disabled(low bits)


INMODE0     <= ternary_func(D_EN = TRUE, '1', '0');-- for pre-adder D+A1 or A2
INMODE1     <= '0';
INMODE2     <= ternary_func(D_EN = TRUE, '1', '0');-- for pre-adder D+A1 or A2
INMODE3     <= DSP_A_INV;-- for invert A1 
INMODE4     <= '0';


INMODE      <= INMODE4
             & INMODE3
             & INMODE2
             & INMODE1
             & INMODE0;

OPMODE0     <= '1';
OPMODE1     <= '0';
OPMODE2     <= '1';
OPMODE3     <= '0';
OPMODE4     <= '0'      when PCIN_EN = FALSE and C_EN = FALSE else -- '0'  or P
               (not SEL)when PCIN_EN = TRUE  and C_EN = FALSE else -- PCIN or P
               (not SEL)when PCIN_EN = FALSE and C_EN = TRUE  else -- C    or P
               '0';
OPMODE5     <= SEL      when PCIN_EN = FALSE and C_EN = FALSE else -- '0'  or P
               SEL      when PCIN_EN = TRUE  and C_EN = FALSE else -- PCIN or P
               '1'      when PCIN_EN = FALSE and C_EN = TRUE  else -- C    or P
               '0';
OPMODE6     <= '0';

OPMODE      <= OPMODE6
             & OPMODE5
             & OPMODE4
             & OPMODE3
             & OPMODE2
             & OPMODE1
             & OPMODE0;

   -- DSP48E1: 48-bit Multi-Functional Arithmetic Block
   --          Kintex-7
   -- Xilinx HDL Language Template, version 2014.4
   DSP48E1_inst : DSP48E1
   generic map (
      -- Feature Control Attributes: Data Path Selection
      A_INPUT => "DIRECT",               -- Selects A input source, "DIRECT" (A port) or "CASCADE" (ACIN port)
      B_INPUT => "DIRECT",               -- Selects B input source, "DIRECT" (B port) or "CASCADE" (BCIN port)
      USE_DPORT => D_EN,                 -- Select D port usage (TRUE or FALSE)
      USE_MULT => "MULTIPLY",            -- Select multiplier usage ("MULTIPLY", "DYNAMIC", or "NONE")
      USE_SIMD => "ONE48",               -- SIMD selection ("ONE48", "TWO24", "FOUR12")
      -- Pattern Detector Attributes: Pattern Detection Configuration
      AUTORESET_PATDET => "NO_RESET",    -- "NO_RESET", "RESET_MATCH", "RESET_NOT_MATCH" 
      MASK => X"3fffffffffff",           -- 48-bit mask value for pattern detect (1=ignore)
      PATTERN => X"000000000000",        -- 48-bit pattern match for pattern detect
      SEL_MASK => "MASK",                -- "C", "MASK", "ROUNDING_MODE1", "ROUNDING_MODE2" 
      SEL_PATTERN => "PATTERN",          -- Select pattern value ("PATTERN" or "C")
      USE_PATTERN_DETECT => "NO_PATDET", -- Enable pattern detect ("PATDET" or "NO_PATDET")
      -- Register Control Attributes: Pipeline Register Configuration
      ACASCREG => 2,                     -- Number of pipeline stages between A/ACIN and ACOUT (0, 1 or 2)
      ADREG => 1,                        -- Number of pipeline stages for pre-adder (0 or 1)
      ALUMODEREG => 1,                   -- Number of pipeline stages for ALUMODE (0 or 1)
      AREG => 2,                         -- Number of pipeline stages for A (0, 1 or 2)
      BCASCREG => 1,                     -- Number of pipeline stages between B/BCIN and BCOUT (0, 1 or 2)
      BREG => 2,                         -- Number of pipeline stages for B (0, 1 or 2)
      CARRYINREG => 1,                   -- Number of pipeline stages for CARRYIN (0 or 1)
      CARRYINSELREG => 1,                -- Number of pipeline stages for CARRYINSEL (0 or 1)
      CREG => 1,                         -- Number of pipeline stages for C (0 or 1)
      DREG => 1,                         -- Number of pipeline stages for D (0 or 1)
      INMODEREG => 1,                    -- Number of pipeline stages for INMODE (0 or 1)
      MREG => 1,                         -- Number of multiplier pipeline stages (0 or 1)
      OPMODEREG => 1,                    -- Number of pipeline stages for OPMODE (0 or 1)
      PREG => 1                          -- Number of pipeline stages for P (0 or 1)
   )
   port map (
      -- Cascade: 30-bit (each) output: Cascade Ports
      ACOUT => open,                    -- 30-bit output: A port cascade output
      BCOUT => open,                    -- 18-bit output: B port cascade output
      CARRYCASCOUT => open,             -- 1-bit output: Cascade carry output
      MULTSIGNOUT => open,              -- 1-bit output: Multiplier sign cascade output
      PCOUT => PCOUT,                   -- 48-bit output: Cascade output
      -- Control: 1-bit (each) output: Control Inputs/Status Bits
      OVERFLOW => open,                 -- 1-bit output: Overflow in add/acc output
      PATTERNBDETECT => open,           -- 1-bit output: Pattern bar detect output
      PATTERNDETECT => open,            -- 1-bit output: Pattern detect output
      UNDERFLOW => open,                -- 1-bit output: Underflow in add/acc output
      -- Data: 4-bit (each) output: Data Ports
      CARRYOUT => open,                 -- 4-bit output: Carry output
      P => P,                           -- 48-bit output: Primary data output
      -- Cascade: 30-bit (each) input: Cascade Ports
      ACIN => (others => '0'),          -- 30-bit input: A cascade data input
      BCIN => (others => '0'),          -- 18-bit input: B cascade input
      CARRYCASCIN => '0',               -- 1-bit input: Cascade carry input
      MULTSIGNIN => '0',                -- 1-bit input: Multiplier sign input
      PCIN => PCIN,                     -- 48-bit input: P cascade input
      -- Control: 4-bit (each) input: Control Inputs/Status Bits
      ALUMODE => ALUMODE,               -- 4-bit input: ALU control input
      CARRYINSEL => (others => '0'),    -- 3-bit input: Carry select input
      CLK => CLK,                       -- 1-bit input: Clock input
      INMODE => INMODE,                 -- 5-bit input: INMODE control input
      OPMODE => OPMODE,                 -- 7-bit input: Operation mode input
      -- Data: 30-bit (each) input: Data Ports
      A => A,                           -- 30-bit input: A data input
      B => B,                           -- 18-bit input: B data input
      C => C,                           -- 48-bit input: C data input
      CARRYIN => '0',                   -- 1-bit input: Carry input signal
      D => D,                           -- 25-bit input: D data input
      -- Reset/Clock Enable: 1-bit (each) input: Reset/Clock Enable Inputs
      CEA1 => '1',                      -- 1-bit input: Clock enable input for 1st stage AREG
      CEA2 => '1',                      -- 1-bit input: Clock enable input for 1st stage AREG
      CEAD => '1',                      -- 1-bit input: Clock enable input for ADREG
      CEALUMODE => '1',                 -- 1-bit input: Clock enable input for ALUMODE
      CEB1 => '1',                      -- 1-bit input: Clock enable input for 1st stage BREG
      CEB2 => '1',                      -- 1-bit input: Clock enable input for 2nd stage BREG
      CEC => CEC,                       -- 1-bit input: Clock enable input for CREG
      CECARRYIN => '0',                 -- 1-bit input: Clock enable input for CARRYINREG
      CECTRL => '1',                    -- 1-bit input: Clock enable input for OPMODEREG and CARRYINSELREG
      CED => '1',                       -- 1-bit input: Clock enable input for DREG
      CEINMODE => '1',                  -- 1-bit input: Clock enable input for INMODEREG
      CEM => '1',                       -- 1-bit input: Clock enable input for MREG
      CEP => CEP,                       -- 1-bit input: Clock enable input for PREG
      RSTA => '0',                      -- 1-bit input: Reset input for AREG
--      RSTALLCARRYIN => '1',             -- 1-bit input: Reset input for CARRYINREG
      RSTALLCARRYIN => '0',             -- 1-bit input: Reset input for CARRYINREG
      RSTALUMODE => '0',                -- 1-bit input: Reset input for ALUMODEREG
      RSTB => '0',                      -- 1-bit input: Reset input for BREG
      RSTC => RSTC,                     -- 1-bit input: Reset input for CREG
      RSTCTRL => '0',                   -- 1-bit input: Reset input for OPMODEREG and CARRYINSELREG
      RSTD => '0',                      -- 1-bit input: Reset input for DREG and ADREG
      RSTINMODE => '0',                 -- 1-bit input: Reset input for INMODEREG
      RSTM => '0',                      -- 1-bit input: Reset input for MREG
      RSTP => '0'                       -- 1-bit input: Reset input for PREG
   );

   -- End of DSP48E1_inst instantiation
                
            


end Behavioral;
