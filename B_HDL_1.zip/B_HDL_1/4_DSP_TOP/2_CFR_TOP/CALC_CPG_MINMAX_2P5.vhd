-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

entity CALC_CPG_MINMAX_2P5 is
   port(
   	
   			RESET											: in	std_logic;
   			CLK												: in	std_logic;
   			
   			CFR_TAP_NUM								: in	std_logic_vector(9 downto 0);
   			
   			CPG_MIN_NUM								:	out	std_logic_vector(9 downto 0)   			
   			);
end CALC_CPG_MINMAX_2P5;

architecture arc_CALC_CPG_MINMAX_2P5 of CALC_CPG_MINMAX_2P5 is

	signal tap_num_msb8	: std_logic_vector(9 downto 0);
	signal tap_num_msb5	: std_logic_vector(9 downto 0);
	--signal tap_num_min	: std_logic_vector(9 downto 0);
		
begin

	tap_num_msb8 <= "00" & CFR_TAP_NUM(9 downto 2);
	tap_num_msb5 <= "00000" & CFR_TAP_NUM(9 downto 5);
	
	process(RESET,CLK)
	begin
		if RESET = '1' then
			CPG_MIN_NUM <= "0001100001";  --(others => '0');
		elsif(CLK'event and CLK='1') then
			CPG_MIN_NUM <= tap_num_msb8 + tap_num_msb5 - 1;
		end if;
	end process;

end arc_CALC_CPG_MINMAX_2P5;