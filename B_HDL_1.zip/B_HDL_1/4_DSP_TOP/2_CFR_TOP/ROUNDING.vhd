library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

entity ROUNDING is
   generic(
      i_bit : integer;
      o_bit : integer
   );
   port( 
      RESET : in  std_logic;
      CLK   : in  std_logic;
      IND   : in  std_logic_vector(i_bit-1 downto 0);
      RES   : out std_logic_vector(o_bit-1 downto 0)
   );
end ROUNDING;

architecture arc_ROUNDING of ROUNDING is

signal int_part		: std_logic_vector((o_bit - 1) downto 0);
signal sum_bits		: std_logic_vector((o_bit - 1) downto 0);
signal zeros     : std_logic_vector((o_bit - 2) downto 0);

begin
zeros <= (others => '0');
int_part <= IND(i_bit-1) & IND((i_bit-1) downto (i_bit - o_bit + 1));
sum_bits <= zeros & IND(i_bit - o_bit);
--sum_bits <= "00000000000000000000" & IND(i_bit - o_bit);

process(RESET,CLK)
begin
	if RESET = '1' then
		RES <= (others => '0');
	elsif (CLK'event and CLK='1') then
		RES <= int_part + sum_bits;
	end if;
end process;

end arc_ROUNDING;