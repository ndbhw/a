--*****************************************************************************
--FIR with hardware oversampling(currently only with hovs=2 and channels>2 working!!!)
-- with hardware oversampling
--application:
--Pulse shape FIR filter
--PARAMETERS:
--VAR_WIDTH         - width of gain correction
--CHANNEL_NUMBERS   - enabled channel numbers
--CH_ENABLE_START   - number of starting channel
--CH_ENABLE_END     - number of last channel
--WIDTH_IN          - input data width
--WIDTH_OUT         - output data width
--FIXED_GAIN        - whether GAIN is fixed or not
--ROUNDING          - "FULL_PRECISION","TRUNCATE","ROUND_INF", "ROUND_EVEN"
--OVERFLOW          - "WRAP", "SATURATE"
--WIDTH_COEFF       - coefficients width
--WIDTH_RESULT      - result width
--HOVS              - Hardware oversampling ratio
--INSAMPLE_ALL_TS   - inputs sample rate occupies all time slots(no idle timeslots!)
--*****************************************************************************
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_CONFIG.all;
use work.RU_FPGA_FNC.all;

entity cfr_fir_pfir is
generic(
    VENDOR                      : string := "XILINX";
    DDUC_SEL                    : integer:= 0;-- 0 : DUC, 1 : DDC
    CHANNEL_NUMBERS             : integer:= 4;

    WIDTH_IN                    : integer:= 16;
    WIDTH_OUT                   : integer:= 16;
    WIDTH_COEFF                 : integer:= 16;

    WIDTH_RESULT                : integer:= 32;
    BINARY_POINT                : integer:= 15;

    HOVS                        : integer:= 2;
    ORDER                       : integer:= 96
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    MODE                        : in  std_logic_vector(2 downto 0); 

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1  downto 0)
);
end cfr_fir_pfir;

architecture rtl of cfr_fir_pfir is

component cfr_delay_chain is
generic(
    BUFF_DEEPTH                 : natural:= 16;-- SRL16E
    DIRECTION                   : natural:= 1; -- 1:forward, 0:reverse
    WIDTH_IN                    : natural:= 16 -- Input data width
);
port(
    CLK                         : in  std_logic;
    DATA_SEL                    : in  std_logic_vector(log2(BUFF_DEEPTH)-1 downto 0); 
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);        
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)        
);
end component;

component  cfr_fir_dsp
port (
    CLK                         : in std_logic;
    SEL                         : in std_logic_vector(0 downto 0);
    PCIN                        : in std_logic_vector(47 downto 0);
    A                           : in std_logic_vector(15 downto 0);
    B                           : in std_logic_vector(15 downto 0);
    D                           : in std_logic_vector(15 downto 0);
    PCOUT                       : out std_logic_vector(47 downto 0);
    P                           : out std_logic_vector(47 downto 0);
    CEP                         : in std_logic
);
end component;

component  cfr_fir_dsp_last
port (
    CLK                         : in std_logic;
    SEL                         : in std_logic_vector(0 downto 0);
    A                           : in std_logic_vector(15 downto 0);
    B                           : in std_logic_vector(15 downto 0);
    D                           : in std_logic_vector(15 downto 0);
    PCOUT                       : out std_logic_vector(47 downto 0);
    P                           : out std_logic_vector(47 downto 0);
    CEP                         : in std_logic
);
end component;

component cfr_rnd_sat is
generic(
    VAR_WIDTH                   : natural:= 5;
    FIXED_GAIN                  : natural:= 0;         --gain is fixed or not
    WIDTH_IN                    : natural:= 64;
    WIDTH_OUT                   : natural:= 32;
    BINARY_POINT                : natural:= 31;
    ROUNDING                    : string:= "ROUND_INF";--"FULL_PRECISION", "TRUNCATE","ROUND_INF", "ROUND_EVEN"
    OVERFLOW                    : string:= "WRAP"      --"SATURATE"
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    BIT_SHIFT_VALUE             : in  std_logic_vector(VAR_WIDTH-1 downto 0);

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1 downto 0)
);
end component;

constant ORDER_ODD              : integer := ternary_func((ORDER mod 2 = 1),1,0);
constant DSP_INSTANCES          : integer := ORDER/(2*HOVS)+ORDER_ODD;
constant DELAY_MEM_NUM          : integer := ORDER/HOVS;
constant DELAY_MEM_DEPTH        : integer := ternary_func(2*CHANNEL_NUMBERS*HOVS<16, 16, 2*CHANNEL_NUMBERS*HOVS);
constant VDSP                   : integer := 4;-- DSP Valid latency(3) + DSP48 in register(2) - 1 (for DSP input registering)
constant PROC_DELAY             : integer := 4+(HOVS-1)+2;-- DSP latency(4) + (HOVS - 1) CLK(DSP loopback cycle) + DSP48 in register(2)
constant COEFF                  : integer_array(ORDER/2-1 downto 0) := (20061, -4846, 1439, -283);

type data_array                 is array(natural range <>) of std_logic_vector(15 downto 0);
type chain_array                is array(natural range <>) of std_logic_vector(47 downto 0);
type hovs_array                 is array(natural range <>) of std_logic_vector(ternary_func(HOVS=1, 1, log2(HOVS))-1 downto 0);
type delay_sel_array            is array(natural range <>) of std_logic_vector(log2(DELAY_MEM_DEPTH)-1 downto 0);
type delay_sel_hovs_array       is array(natural range <>) of delay_sel_array(HOVS-1 downto 0);

--signal coeff                    : integer_array(ORDER/2-1 downto 0);

signal frame_o_d                : std_logic_vector(PROC_DELAY-1 downto 0);
signal valid_o_d                : std_logic_vector(PROC_DELAY-1 downto 0);
signal valid_dsp_i              : std_logic;

signal ovs                      : hovs_array(DSP_INSTANCES-1 downto 0);

signal delay_data_valid         : std_logic_vector(DELAY_MEM_NUM-1 downto 0);
signal delay_data_sel           : delay_sel_array(DELAY_MEM_NUM-1 downto 0);        
signal delay_data_in            : data_array(DELAY_MEM_NUM-1 downto 0);        
signal delay_data_out           : data_array(DELAY_MEM_NUM-1 downto 0);         

signal b_wire                   : data_array(DSP_INSTANCES-1 downto 0);

signal ain_wire                 : data_array(DSP_INSTANCES-1 downto 0);
signal din_wire                 : data_array(DSP_INSTANCES-1 downto 0);

signal chain                    : chain_array(DSP_INSTANCES-1 downto 0);
signal p                        : chain_array(DSP_INSTANCES-1 downto 0);

signal sel_oper                 : std_logic;

signal sel                      : std_logic_vector(DSP_INSTANCES-1  downto 0);
signal result                   : std_logic_vector(WIDTH_RESULT-1 downto 0);

attribute KEEP                  : string;
attribute KEEP                  of ovs : signal is "TRUE";

-- Coefficient mapping function for DSP internal coefficient rom data
function data_sel_init return delay_sel_hovs_array is
    variable result : delay_sel_hovs_array(DELAY_MEM_NUM-1 downto 0);
begin
    MEM_LOOP : for M in 0 to DELAY_MEM_NUM-1 loop
        HOVS_LOOP : for H in 0 to HOVS-1 loop
            if H = 0 then
                if M = 0  then
                    result(M)(H) :=  std_logic_vector(to_unsigned(0                         , log2(DELAY_MEM_DEPTH)));-- first delay chain
                elsif M <= DELAY_MEM_NUM/2-1 then
                    result(M)(H) :=  std_logic_vector(to_unsigned(CHANNEL_NUMBERS-1-1       , log2(DELAY_MEM_DEPTH)));-- forward path 1st
                elsif M = DELAY_MEM_NUM/2 then
                    result(M)(H) :=  std_logic_vector(to_unsigned(CHANNEL_NUMBERS*HOVS-1    , log2(DELAY_MEM_DEPTH)));-- center delay
                else
                    result(M)(H) :=  std_logic_vector(to_unsigned(CHANNEL_NUMBERS*HOVS      , log2(DELAY_MEM_DEPTH)));-- reverse path 1st
                end if;
            else
                if M <= DELAY_MEM_NUM/2-1 then
                    result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))+CHANNEL_NUMBERS , log2(DELAY_MEM_DEPTH)));-- forward path 2nd
                elsif M = DELAY_MEM_NUM/2 then
                    result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))-CHANNEL_NUMBERS , log2(DELAY_MEM_DEPTH)));-- reverse path 2nd
                else
                    if H = 1 then
                        result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))-CHANNEL_NUMBERS+1, log2(DELAY_MEM_DEPTH)));-- reverse path HOVS cnt =2
                    else
                        result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))-CHANNEL_NUMBERS  , log2(DELAY_MEM_DEPTH)));-- reverse path HOVS cnt >2
                    end if;
                end if;
            end if;
        end loop;
    end loop;
    return result;
end function data_sel_init;

constant DELAY_HOVS_SEL         : delay_sel_hovs_array(DELAY_MEM_NUM-1 downto 0) := data_sel_init;   

begin

--    COEFF_GEN_DUC : if DDUC_SEL = 0 generate
--        coeff <= DUC_PFIR_COEFF_5    when MODE = "000" else
--                 DUC_PFIR_COEFF_10   when MODE = "001" else
--                 DUC_PFIR_COEFF_15   when MODE = "010" else
--                 DUC_PFIR_COEFF_20   when MODE = "011" else
--                 DUC_PFIR_COEFF_UMTS;
--    end generate;
--
--    COEFF_GEN_DDC : if DDUC_SEL = 1 generate
--        coeff <= DDC_PFIR_COEFF_5    when MODE = "000" else
--                 DDC_PFIR_COEFF_10   when MODE = "001" else
--                 DDC_PFIR_COEFF_15   when MODE = "010" else
--                 DDC_PFIR_COEFF_20   when MODE = "011" else
--                 DDC_PFIR_COEFF_UMTS;
--    end generate;

    -- Input delay 
    process(CLK,RST)
    begin
        if RST='1' then
            frame_o_d   <= (others=> '0');
            valid_o_d   <= (others=> '0');
            valid_dsp_i <= '0';
        elsif CLK'event and CLK='1' then
            frame_o_d   <= frame_o_d(PROC_DELAY-2 downto 0) & FRAME_I;
            valid_o_d   <= valid_o_d(PROC_DELAY-2 downto 0) & VALID_I;
            valid_dsp_i <= or_reduce(valid_o_d(VDSP-1+(HOVS-1) downto VDSP-1));
        end if;
    end process;

    -- HOVS selection
    process(CLK,RST)
    begin
        if RST='1' then
            sel_oper    <= '0';
        elsif CLK'event and CLK='1' then
            -- DSP opcode selection
            if HOVS = 1 then
                sel_oper    <= '0';
            elsif valid_o_d(2) = '1' then                                          -- only 1 cycle for adding PCIN, +2 CLK after DSP input data
                sel_oper    <= '0';
            elsif or_reduce(valid_o_d(VDSP-1+(HOVS-2) downto VDSP-1)) = '1' then-- Valid dsp - 1 CLK cycle (HOVS cycle - 1)
                sel_oper    <= '1';
            else
                sel_oper    <= '0';
            end if;
        end if;
    end process;

    DELAY_GEN : for N in 0 to DELAY_MEM_NUM-1 generate
    begin
        DELAY_GEN_0 : if N = 0 generate
        begin
            delay_data_valid(N) <= VALID_I;
            delay_data_in(N)    <= FILTER_IN;
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS)));
        end generate DELAY_GEN_0;
        DELAY_GEN_1 : if N >= 1 and N <= DELAY_MEM_NUM/2-1 generate
        begin
            delay_data_valid(N) <= VALID_I;-- write only (HOVS)th data
            delay_data_in(N)    <= delay_data_out(N-1);
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS)));
        end generate DELAY_GEN_1;
        DELAY_GEN_N2 : if N = DELAY_MEM_NUM/2 generate
        begin
            delay_data_valid(N) <= VALID_I;-- write only (HOVS)th data
            delay_data_in(N)    <= delay_data_out(N-1);
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS/2)));-- /2 : # of delay mem/2 = # of DSP
        end generate DELAY_GEN_N2;
        DELAY_GEN_N : if N >= DELAY_MEM_NUM/2+1 and N <= DELAY_MEM_NUM-1 generate
        begin
            delay_data_valid(N) <= valid_o_d(0);-- write only 1st data
            delay_data_in(N)    <= delay_data_out(N-1);
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS/2)));-- /2 : # of delay mem/2 = # of DSP
        end generate DELAY_GEN_N;

    u_cfr_delay_chain : cfr_delay_chain
    generic map(
        BUFF_DEEPTH                 => DELAY_MEM_DEPTH              ,--: natural:= 16;-- SRL16E
        DIRECTION                   => ternary_func(N <= DELAY_MEM_NUM/2, 1, 0),--: natural:= 1: -- 1:forward, 0:reverse
        WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
    )
    port map(
        CLK                         => CLK                        ,--: in  std_logic;

        DATA_SEL                    => delay_data_sel(N)            ,--: in  std_logic_vector(log2(BUFF_DEEPTH)-1 downto 0); 

        VALID_I                     => delay_data_valid(N)          ,--: in  std_logic;
        FILTER_IN                   => delay_data_in(N)             ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);

        FILTER_OUT                  => delay_data_out(N)             --: out std_logic_vector(WIDTH_IN-1 downto 0)
    );
    end generate DELAY_GEN;

    DSP_BLOCK_GEN : for i in 0 to DSP_INSTANCES-1  generate
    begin
        -- HOVS selection, each DSP use seperated ovs signal for performance
        process(CLK,RST)
        begin
            if RST='1' then
                ovs(i)  <= (others=> '0');
            elsif CLK'event and CLK='1' then
                if HOVS = 1  then
                    ovs(i)  <= (others=> '0');
                elsif VALID_I = '1' then 
                    ovs(i)  <= (others=> '0');
                elsif or_reduce(valid_o_d(HOVS-2 downto 0)) = '1' then 
                    ovs(i)  <= ovs(i) + 1;
                end if;
            end if;
        end process;

        -- DSP Input Registering
        sel(i)      <= sel_oper;
        process(RST, CLK)
        begin
            if RST='1' then
                ain_wire(i) <= (others => '0'); 
                din_wire(i) <= (others => '0'); 
                b_wire(i)   <= (others => '0'); 
            elsif CLK'event and CLK='1' then
                ain_wire(i) <= delay_data_out(i);
                din_wire(i) <= delay_data_out((DELAY_MEM_NUM-1)-i);
                b_wire(i)   <= sign_extension(coeff(i*HOVS+ conv_integer(ovs(i))),16);
            end if;
        end process;

        DSP_GEN:if i < DSP_INSTANCES-1 generate
        begin
            u_cfr_fir_dsp : cfr_fir_dsp
            port map (
                CLK    =>CLK,-- IN STD_LOGIC;
                SEL(0) =>sel(i),-- IN STD_LOGIC_VECTOR(0 DOWNTO 0;
                PCIN   =>chain(i+1),-- IN STD_LOGIC_VECTOR(33 DOWNTO 0;
                PCOUT  =>chain(i),-- OUT STD_LOGIC_VECTOR(33 DOWNTO 0;
                B      =>b_wire(i),-- IN STD_LOGIC_VECTOR(15 DOWNTO 0;
                A      =>ain_wire(i),-- IN STD_LOGIC_VECTOR(15 DOWNTO 0;
                D      =>din_wire(i),-- IN STD_LOGIC_VECTOR(15 DOWNTO 0;
                CEP    =>valid_dsp_i,-- IN STD_LOGIC
                P      =>p(i)-- OUT STD_LOGIC_VECTOR(47 DOWNTO 0;
            );
        end generate;

        DSP_GEN_LAST:if i = DSP_INSTANCES-1 generate
        begin
            u_cfr_fir_dsp_last : cfr_fir_dsp_last
            port map (
                CLK    =>CLK,-- IN STD_LOGIC;
                SEL(0) =>sel(i),-- IN STD_LOGIC_VECTOR(0 DOWNTO 0;
                PCOUT  =>chain(i),-- OUT STD_LOGIC_VECTOR(33 DOWNTO 0;
                B      =>b_wire(i),-- IN STD_LOGIC_VECTOR(15 DOWNTO 0;
                A      =>ain_wire(i),-- IN STD_LOGIC_VECTOR(15 DOWNTO 0;
                D      =>din_wire(i),-- IN STD_LOGIC_VECTOR(15 DOWNTO 0;
                CEP    =>valid_dsp_i,-- IN STD_LOGIC
                P      =>p(i)-- OUT STD_LOGIC_VECTOR(33 DOWNTO 0;
            );
        end generate;

    end generate DSP_BLOCK_GEN;

    result<= sign_copy(p(0),WIDTH_RESULT);

    cfr_rnd_sat_ins: cfr_rnd_sat
    generic map(
        VAR_WIDTH       => 1,
        FIXED_GAIN      => 1,
        WIDTH_IN        => WIDTH_RESULT,
        WIDTH_OUT       => WIDTH_OUT,
        BINARY_POINT    => BINARY_POINT,
        ROUNDING        => "ROUND_INF",
        OVERFLOW        => "SATURATE"
    )
    port map(
        CLK             => CLK,
        RST             => RST,
        BIT_SHIFT_VALUE => (others => '0'),

        FRAME_I         => frame_o_d(PROC_DELAY-1),
        VALID_I         => valid_o_d(PROC_DELAY-1),
        FILTER_IN       => result,

        FRAME_O         => FRAME_O,
        VALID_O         => VALID_O,
        FILTER_OUT      => FILTER_OUT
    );

end rtl;
