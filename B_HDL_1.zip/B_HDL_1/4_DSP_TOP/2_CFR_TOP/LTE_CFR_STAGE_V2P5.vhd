-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity LTE_CFR_STAGE_V2P5 is
   port(
   				RESET										: in	std_logic;
   				CLK											: in	std_logic;
   				CLOCK_UNSTABLE					: in	std_logic;
   				
   				CFR_THRESHOLD_0					: in	std_logic_vector(15 downto 0);
   				CFR_THRESHOLD_1					: in	std_logic_vector(15 downto 0);
   				CFR_PEAK_SPACING_0			:	in	std_logic_vector(7 downto 0);
   				CFR_PEAK_SPACING_1			:	in	std_logic_vector(7 downto 0);
   				
   				CFR_COEFF_UPDATE_EN			: in	std_logic;
   				CFR_COEFF_WE						: in	std_logic;
   				CFR_COEFF_WRADDR				: in	std_logic_vector(9 downto 0);
   				CFR_COEFF_WRDATA				: in	std_logic_vector(31 downto 0);
   				
   				MIN_NUM									:	in	std_logic_vector(9 downto 0);
   				
   				CFR_TAP_NUM							: in	std_logic_vector(9 downto 0);
   				
   				SIG_DELAY_VALUE					: in	std_logic_vector(8 downto 0);  -- until logic fixed!
   				FLAG_DELAY_VALUE				: in	std_logic_vector(6 downto 0);  -- until logic fixed!
   				
   				CFR_INPUT_I							: in	std_logic_vector(15 downto 0);
   				CFR_INPUT_Q							: in	std_logic_vector(15 downto 0);
   				
   				CFRSTAGE_OUT_I					: out	std_logic_vector(15 downto 0);
   				CFRSTAGE_OUT_Q					: out	std_logic_vector(15 downto 0)
   				
   		);
end LTE_CFR_STAGE_V2P5;

architecture arc_LTE_CFR_STAGE_V2P5 of LTE_CFR_STAGE_V2P5 is

component SIGNAL_DELAY_BUFFER_V2
   port(
   				RESET										: in	std_logic;
   				CLK											: in	std_logic;

   				DELAY_VALUE							:	in	std_logic_vector(8 downto 0);
   				
   				--CH_NUM                  : in	std_logic;
   				INPUT_I									: in	std_logic_vector(15 downto 0);
   				INPUT_Q									: in	std_logic_vector(15 downto 0);
   				
   				OUTPUT_I								: out	std_logic_vector(15 downto 0);
   				OUTPUT_Q								: out	std_logic_vector(15 downto 0)
   				
   		);
end component;

component THRES_MUX_V2

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							THRESHOLD_0				: in	std_logic_vector(15 downto 0);
							THRESHOLD_1				: in	std_logic_vector(15 downto 0);
							--CH_NUM            :	in	std_logic;

							MUX_THRES					: out	std_logic_vector(15 downto 0)
							
						);
end component;

component CALC_THRES2_V2
   port(
   	
   			RESET											: in	std_logic;
   			CLK												: in	std_logic;
   			
   			--CH_NUM                    : in  std_logic;                      -- '0' : path#0 , '1' : path#1
   			CFR_THRESHOLD_P0					: in	std_logic_vector(15 downto 0);  -- Path #0 threshold
   			CFR_THRESHOLD_P1					: in	std_logic_vector(15 downto 0);  -- Path #1 threshold
   			
   			CFR_THRESHOLD2						:	out	std_logic_vector(16 downto 0)   -- Muxed threshold value
   			);
end component;

component CFR_CORDIC_V2P5
		port (
						RESET				:	in	std_logic;
						CLK					: in	std_logic;
						CLOCK_UNSTABLE					: in	std_logic;
						
						SIGNAL_I		: in	std_logic_vector(15 downto 0);
						SIGNAL_Q		: in	std_logic_vector(15 downto 0);
						
						MAGNITUDE_PRE		:	out	std_logic_vector(15 downto 0);
						MAGNITUDE		:	out	std_logic_vector(15 downto 0);
						COS					:	out	std_logic_vector(13 downto 0);
						SIN					:	out	std_logic_vector(13 downto 0)
						
					);
end component;

component PEAK_SCALE_V2
			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM            : in  std_logic;
							MAGNITUDE					:	in	std_logic_vector(15 downto 0);
							THRESHOLD					:	in	std_logic_vector(15 downto 0);

							COS								: in	std_logic_vector(13 downto 0);
							SIN								: in	std_logic_vector(13 downto 0);
							
							PEAK_I						:	out	std_logic_vector(15 downto 0);
							PEAK_Q						:	out	std_logic_vector(15 downto 0)
							
						);
end component;

component MAX_DETECT_V2
			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							PEAK_SPACING_0		: in	std_logic_vector(7 downto 0);   -- Muxed 2ch.
							PEAK_SPACING_1		: in	std_logic_vector(7 downto 0);   -- Muxed 2ch.
							THRESHOLD					: in	std_logic_vector(15 downto 0);  -- Muxed 2ch.
							THRESHOLD_2				: in	std_logic_vector(16 downto 0);  -- Muxed 2ch.
							MAGNITUDE					:	in	std_logic_vector(15 downto 0);  -- Muxed 2ch.
							
							RST_SEARCH				: out	std_logic;
							NEW_MAX						: out	std_logic
							
						);
end component;

component DELAY_COUNTER_V2
			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM            : in std_logic;
							RST_SEARCH				: in	std_logic;
							NEW_MAX						: in	std_logic;
							
							PEAK_DELAY_0			: out	std_logic_vector(6 downto 0);
							PEAK_DELAY_1			: out	std_logic_vector(6 downto 0);
							PEAK_INDICATOR		: out	std_logic
						);
end component;

component FLAG_DELAY_BUFFER_V2
   port(
   				RESET										: in	std_logic;
   				CLK											: in	std_logic;

   				--CH_NUM                  : in  std_logic;
   				FLAG_DELAY_VALUE				:	in	std_logic_vector(6 downto 0);
   				
   				INPUT_FLAG							: in	std_logic;
   				OUTPUT_FLAG							: out	std_logic   				
   		);
end component;

component LTE_CPG_PROCESSOR_V2P5
			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							--CH_NUM    				: in	std_logic;
							CLOCK_UNSTABLE		: in	std_logic;
							
							TAPS_NUMBER				: in	std_logic_vector(9 downto 0);
							MIN_NUMBER				: in	std_logic_vector(9 downto 0);
							
							PEAK_I						: in	std_logic_vector(15 downto 0);
							PEAK_Q						: in	std_logic_vector(15 downto 0);
							
							PEAK_INDICATOR		: in	std_logic;
							PEAK_MAGNITUDE		: in	std_logic_vector(15 downto 0);
							
							CFR_COEFF_UPDATE_EN			: in	std_logic;
							COEFF_WE					: in	std_logic;
							COEFF_WADDR				: in	std_logic_vector(9 downto 0);
							COEFF_DATA				: in	std_logic_vector(31 downto 0);
							
							CP_I							: out	std_logic_vector(17 downto 0);
							CP_Q							: out	std_logic_vector(17 downto 0)

						);
end component;

component INTERNAL_DATA_DELAY_MAG
			generic(
      data_delay : std_logic_vector(6 downto 0)
   		);
			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM            : in	std_logic;
							DATA_IN						: in	std_logic_vector(15 downto 0);
							DATA_OUT					: out	std_logic_vector(15 downto 0)
						);
end component;

component INTERNAL_DATA_DELAY_PIQ
			generic(
      data_delay : std_logic_vector(6 downto 0)
   		);
			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM            : in	std_logic;
							DATA_IN_I					: in	std_logic_vector(15 downto 0);
							DATA_IN_Q					: in	std_logic_vector(15 downto 0);
							
							DATA_OUT_I				: out	std_logic_vector(15 downto 0);
							DATA_OUT_Q				: out	std_logic_vector(15 downto 0)
						);
end component;

component SAT
   generic(
      i_bit : integer;
      o_bit : integer
   );
   port( 
      RESET : in  std_logic;
      CLK   : in  std_logic;
      IND   : in  std_logic_vector(i_bit-1 downto 0);
      RES   : out std_logic_vector(o_bit-1 downto 0)
   );
end component;

---- Signals -------------------------------------------------------
signal i_sig_delay_val						: std_logic_vector(8 downto 0);
signal i_signal_delayed_I					: std_logic_vector(15 downto 0);
signal i_signal_delayed_Q					: std_logic_vector(15 downto 0);
signal i_signal_delayed_I_exp			: std_logic_vector(18 downto 0);
signal i_signal_delayed_Q_exp			: std_logic_vector(18 downto 0);

signal i_cordic_mag								: std_logic_vector(15 downto 0);
signal i_cordic_mag_pre           : std_logic_vector(15 downto 0);
signal i_cordic_cos								: std_logic_vector(13 downto 0);
signal i_cordic_sin								: std_logic_vector(13 downto 0);

signal i_scaled_peak_i						: std_logic_vector(15 downto 0);
signal i_scaled_peak_q						: std_logic_vector(15 downto 0);

signal i_delayed_peak_i						: std_logic_vector(15 downto 0);
signal i_delayed_peak_q						: std_logic_vector(15 downto 0);
signal i_delayed_mag							: std_logic_vector(15 downto 0);

signal i_rst_serch								: std_logic;
signal i_newmax										: std_logic;

signal i_peak_delay_0, i_peak_delay_1								: std_logic_vector(6 downto 0);
signal i_peak_delay_sub						: std_logic_vector(6 downto 0);
signal i_peak_indicator						: std_logic;
signal i_delayed_flag							: std_logic;

signal i_cp_i, i_cp_q						: std_logic_vector(17 downto 0);
signal i_sum_i, i_sum_q						: std_logic_vector(18 downto 0);

signal i_mux_thres2               : std_logic_vector(16 downto 0);
signal i_mux_thres                : std_logic_vector(15 downto 0);

signal i_tog            : std_logic;
signal i_tog_d            : std_logic;

begin

process(RESET,CLK)
begin
	if RESET = '1' then
		i_sig_delay_val <= (others => '0');
	elsif (CLK'event and CLK='1') then
		--i_sig_delay_val <= SIG_DELAY_VALUE + ('0' & CFR_TAP_NUM(9 downto 1));
		i_sig_delay_val <= SIG_DELAY_VALUE + CFR_TAP_NUM(9 downto 1);
		--i_sig_delay_val <= SIG_DELAY_VALUE + ('0' & CFR_TAP_NUM(8 downto 1));
	end if;
end process;

u_signal_delay_buffer : SIGNAL_DELAY_BUFFER_V2
   port map(
   				RESET										=> RESET, --: in	std_logic;
   				CLK											=> CLK, --: in	std_logic;

   				DELAY_VALUE							=> i_sig_delay_val, --:	in	std_logic_vector(9 downto 0);
   				
   				--CH_NUM                  => i_ch_num,  --: in	std_logic;
   				INPUT_I									=> CFR_INPUT_I, --: in	std_logic_vector(15 downto 0);
   				INPUT_Q									=> CFR_INPUT_Q, --: in	std_logic_vector(15 downto 0);
   				
   				OUTPUT_I								=> i_signal_delayed_I, --: out	std_logic_vector(15 downto 0);
   				OUTPUT_Q								=> i_signal_delayed_Q  --: out	std_logic_vector(15 downto 0)
   				
   		);

u_thres_mux : THRES_MUX_V2

			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK, --: in	std_logic;
							
							THRESHOLD_0				=> CFR_THRESHOLD_0,  --: in	std_logic_vector(15 downto 0);
							THRESHOLD_1				=> CFR_THRESHOLD_1,  --: in	std_logic_vector(15 downto 0);
							--CH_NUM            => i_ch_num,  --:	in	std_logic;

							MUX_THRES					=> i_mux_thres  --: out	std_logic_vector(15 downto 0)
							
						);

u_calc_th2_mux :  CALC_THRES2_V2
   port map(
   	
   			RESET											=> RESET, --: in	std_logic;
   			CLK												=> CLK, --: in	std_logic;
   			
   			--CH_NUM                    => i_ch_num,  --: in  std_logic;                      -- '0' : path#0 , '1' : path#1
   			CFR_THRESHOLD_P0					=> CFR_THRESHOLD_0,  --: in	std_logic_vector(15 downto 0);  -- Path #0 threshold
   			CFR_THRESHOLD_P1					=> CFR_THRESHOLD_1,  --: in	std_logic_vector(15 downto 0);  -- Path #1 threshold
   			
   			CFR_THRESHOLD2						=> i_mux_thres2  --:	out	std_logic_vector(16 downto 0)   -- Muxed threshold value
   			);
   			
   		
u_cordic_blk : CFR_CORDIC_V2P5
		port map(
						RESET				          => RESET, --:	in	std_logic;
						CLK					          => CLK, --: in	std_logic;
						CLOCK_UNSTABLE	      => CLOCK_UNSTABLE, -- : in	std_logic;
						
						SIGNAL_I		          => CFR_INPUT_I, --: in	std_logic_vector(15 downto 0);
						SIGNAL_Q		          => CFR_INPUT_Q, --: in	std_logic_vector(15 downto 0);
						
						MAGNITUDE_PRE		      => i_cordic_mag_pre,   --:	out	std_logic_vector(15 downto 0);
						MAGNITUDE		          => i_cordic_mag, --:	out	std_logic_vector(15 downto 0);
						COS					          => i_cordic_cos, --:	out	std_logic_vector(13 downto 0);
						SIN					          => i_cordic_sin  --:	out	std_logic_vector(13 downto 0)
					);
					
u_peak_scale_blk : PEAK_SCALE_V2
			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK, --: in	std_logic;
							
							--CH_NUM            => i_ch_num,  --: in  std_logic;
							MAGNITUDE					=> i_cordic_mag_pre, --:	in	std_logic_vector(15 downto 0);
							THRESHOLD					=> i_mux_thres, --:	in	std_logic_vector(15 downto 0);

							COS								=> i_cordic_cos, --: in	std_logic_vector(13 downto 0);
							SIN								=> i_cordic_sin, --: in	std_logic_vector(13 downto 0);
							
							PEAK_I						=> i_scaled_peak_i, --:	out	std_logic_vector(15 downto 0);
							PEAK_Q						=> i_scaled_peak_q  --:	out	std_logic_vector(15 downto 0)
						);
						

u_int_delay_blk_spmag : INTERNAL_DATA_DELAY_MAG
			generic map(
      data_delay => "1000100"   --"1000011"  -- : std_logic_vector(6 downto 0)
   		)
			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK, --: in	std_logic;
							
							--CH_NUM            => i_ch_num,  --: in	std_logic;
							DATA_IN						=> i_cordic_mag, --: in	std_logic_vector(15 downto 0);
							DATA_OUT					=> i_delayed_mag  --: out	std_logic_vector(15 downto 0)
						);
						
u_int_delay_blk_spiq : INTERNAL_DATA_DELAY_PIQ
			generic map(
      data_delay => "1000100"   --"1000011"  --: std_logic_vector(6 downto 0)
   		)
			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK, --: in	std_logic;
							
							--CH_NUM            => i_ch_num,  --: in	std_logic;
							DATA_IN_I					=> i_scaled_peak_i, --: in	std_logic_vector(15 downto 0);
							DATA_IN_Q					=> i_scaled_peak_q, --: in	std_logic_vector(15 downto 0);
							
							DATA_OUT_I				=> i_delayed_peak_i,  --: out	std_logic_vector(15 downto 0);
							DATA_OUT_Q				=> i_delayed_peak_q   --: out	std_logic_vector(15 downto 0)
						);

						
u_maxdetect_blk : MAX_DETECT_V2
			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK, --: in	std_logic;
							
							PEAK_SPACING_0		=> CFR_PEAK_SPACING_0, --: in	std_logic_vector(7 downto 0);
							PEAK_SPACING_1		=> CFR_PEAK_SPACING_1, --: in	std_logic_vector(7 downto 0);
							THRESHOLD					=> i_mux_thres, --: in	std_logic_vector(15 downto 0);
							THRESHOLD_2				=> i_mux_thres2, --: in	std_logic_vector(16 downto 0);
							MAGNITUDE					=> i_cordic_mag, --:	in	std_logic_vector(15 downto 0);
							
							RST_SEARCH				=> i_rst_serch, --: out	std_logic;
							NEW_MAX						=> i_newmax  --: out	std_logic
						);
						

u_delay_cnt_blk : DELAY_COUNTER_V2
			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK, --: in	std_logic;

							--CH_NUM         => i_ch_num,  --   : in std_logic;
							RST_SEARCH				=> i_rst_serch, --: in	std_logic;
							NEW_MAX						=> i_newmax,  --: in	std_logic;

							PEAK_DELAY_0				=> i_peak_delay_0, --: out	std_logic_vector(6 downto 0);
							PEAK_DELAY_1				=> i_peak_delay_1, --
							PEAK_INDICATOR		=> i_peak_indicator  --: out	std_logic
						);
						
						
--=======================================================================
-- for new delay_counter block test
--=======================================================================
process(RESET,CLK)
begin
   if RESET = '1' then
      i_tog <= '0';
   elsif rising_edge(CLK) then
      i_tog <= not i_tog;
      i_tog_d <= i_tog;
   end if;
end process;
						
process (RESET,CLK)
begin
	if RESET = '1' then
		i_peak_delay_sub <= (others => '0');
	elsif (CLK'event and CLK='1') then
	  --if i_ch_num = '1' then
	  if i_tog = '1' then
		  i_peak_delay_sub <= FLAG_DELAY_VALUE - i_peak_delay_1;
		else
		  i_peak_delay_sub <= FLAG_DELAY_VALUE - i_peak_delay_0;
		end if;
	end if;
end process;


u_flag_delay_blk : FLAG_DELAY_BUFFER_V2
   port map(
   				RESET										=> RESET, --: in	std_logic;
   				CLK											=> CLK, --: in	std_logic;

   				--CH_NUM              => i_ch_num, --    : in  std_logic;
   				FLAG_DELAY_VALUE				=> i_peak_delay_sub, --:	in	std_logic_vector(6 downto 0);
   				
   				INPUT_FLAG							=> i_peak_indicator, --: in	std_logic;
   				OUTPUT_FLAG							=> i_delayed_flag  --: out	std_logic_vector(15 downto 0)   				
   		);
   		
   		
u_cpg_proc_blk : LTE_CPG_PROCESSOR_V2P5
			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK, --: in	std_logic;

							CLOCK_UNSTABLE		=> CLOCK_UNSTABLE, --: in	std_logic;
							
							TAPS_NUMBER				=> CFR_TAP_NUM, --: in	std_logic_vector(9 downto 0);
							MIN_NUMBER				=> MIN_NUM, --: in	std_logic_vector(9 downto 0);
							
							PEAK_I						=> i_delayed_peak_i, --: in	std_logic_vector(15 downto 0);
							PEAK_Q						=> i_delayed_peak_q, --: in	std_logic_vector(15 downto 0);
							
							PEAK_INDICATOR		=> i_delayed_flag, --: in	std_logic;  i_delayed_flag
							PEAK_MAGNITUDE		=> i_delayed_mag, --: in	std_logic_vector(15 downto 0);
							
							CFR_COEFF_UPDATE_EN	=> CFR_COEFF_UPDATE_EN, --		: in	std_logic;
							COEFF_WE					=> CFR_COEFF_WE, --: in	std_logic;
							COEFF_WADDR				=> CFR_COEFF_WRADDR, --: in	std_logic_vector(8 downto 0);
							COEFF_DATA				=> CFR_COEFF_WRDATA, --: in	std_logic_vector(31 downto 0);
							
							CP_I							=> i_cp_i, --: out	std_logic_vector(17 downto 0);
							CP_Q							=> i_cp_q  --: out	std_logic_vector(17 downto 0)
						);

i_signal_delayed_I_exp <= i_signal_delayed_I(15) & i_signal_delayed_I(15) & i_signal_delayed_I(15) & i_signal_delayed_I;
i_signal_delayed_Q_exp <= i_signal_delayed_Q(15) & i_signal_delayed_Q(15) & i_signal_delayed_Q(15) & i_signal_delayed_Q;
						
process(RESET,CLK)
begin
	if RESET = '1' then
		i_sum_i <= (others => '0');
		i_sum_q <= (others => '0');
	elsif (CLK'event and CLK='1') then
		i_sum_i <= i_signal_delayed_I_exp - (i_cp_i(17) & i_cp_i);
		i_sum_q <= i_signal_delayed_Q_exp - (i_cp_q(17) & i_cp_q);
	end if;
end process;

u_stageout_sat_i : SAT
   generic map(
      i_bit => 19, --: integer;
      o_bit => 16  --: integer
   )
   port map( 
      RESET 	=> RESET, --: in  std_logic;
      CLK   	=> CLK, --: in  std_logic;
      IND   	=> i_sum_i, --: in  std_logic_vector(i_bit-1 downto 0);
      RES   	=> CFRSTAGE_OUT_I  --: out std_logic_vector(o_bit-1 downto 0)
   );
   
u_stageout_sat_q : SAT
   generic map(
      i_bit => 19, --: integer;
      o_bit => 16  --: integer
   )
   port map( 
      RESET 	=> RESET, --: in  std_logic;
      CLK   	=> CLK, --: in  std_logic;
      IND   	=> i_sum_q, --: in  std_logic_vector(i_bit-1 downto 0);
      RES   	=> CFRSTAGE_OUT_Q  --: out std_logic_vector(o_bit-1 downto 0)
   );
		
end arc_LTE_CFR_STAGE_V2P5;
