-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
library UNISIM;
use UNISIM.VComponents.all;

entity PEAK_SCALE_V2 is

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM            : in  std_logic;
							MAGNITUDE					:	in	std_logic_vector(15 downto 0);
							THRESHOLD					:	in	std_logic_vector(15 downto 0);

							COS								: in	std_logic_vector(13 downto 0);
							SIN								: in	std_logic_vector(13 downto 0);
							
							PEAK_I						:	out	std_logic_vector(15 downto 0);
							PEAK_Q						:	out	std_logic_vector(15 downto 0)
							
						);
end PEAK_SCALE_V2;

architecture arc_PEAK_SCALE_V2 of PEAK_SCALE_V2 is

--=============== xilinx multiplier ===============================
component cfr_mult_17x14
	port (
	clk: in std_logic;
	a: in std_logic_vector(16 downto 0);
	b: in std_logic_vector(13 downto 0);
	p: out std_logic_vector(30 downto 0));
end component;
--=================================================================

component ROUNDING
   generic(
      i_bit : integer;
      o_bit : integer
   );
   port( 
      RESET : in  std_logic;
      CLK   : in  std_logic;
      IND   : in  std_logic_vector(i_bit-1 downto 0);
      RES   : out std_logic_vector(o_bit-1 downto 0)
   );
end component;

component SAT
   generic(
      i_bit : integer;
      o_bit : integer
   );
   port( 
      RESET : in  std_logic;
      CLK   : in  std_logic;
      IND   : in  std_logic_vector(i_bit-1 downto 0);
      RES   : out std_logic_vector(o_bit-1 downto 0)
   );
end component;

signal i_threshold  		: std_logic_vector(15 downto 0);
signal mag_subs_thres		: std_logic_vector(16 downto 0);
signal cos_mult_out   	: std_logic_vector(30 downto 0);
signal sin_mult_out   	: std_logic_vector(30 downto 0);
signal cos_round_out		: std_logic_vector(18 downto 0);
signal sin_round_out		: std_logic_vector(18 downto 0);
signal cos_sat_peak			: std_logic_vector(15 downto 0);
signal sin_sat_peak			: std_logic_vector(15 downto 0);

begin

process(RESET,CLK)
begin
	if RESET = '1' then
		i_threshold <= (others => '0');
	elsif (CLK'event and CLK='1') then
		i_threshold <= THRESHOLD;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		mag_subs_thres <= (others => '0');
	elsif (CLK'event and CLK='1') then
		--mag_subs_thres <= (MAGNITUDE(15) & MAGNITUDE) - (THRESHOLD(15) & THRESHOLD);
		mag_subs_thres <= ('0' & MAGNITUDE) - ('0' & i_threshold);
	end if;
end process;

--=============== xilinx multiplier ===============================
u_mult_cos_peakscale : cfr_mult_17x14
	port map(
	clk			=> CLK, --: in std_logic;
	a				=> mag_subs_thres, --: in std_logic_vector(16 downto 0);
	b				=> COS, --: in std_logic_vector(13 downto 0);
	p				=> cos_mult_out  --: out std_logic_vector(30 downto 0)
	);
	
u_mult_sin_peakscale : cfr_mult_17x14
	port map(
	clk			=> CLK, --: in std_logic;
	a				=> mag_subs_thres, --: in std_logic_vector(16 downto 0);
	b				=> SIN, --: in std_logic_vector(13 downto 0);
	p				=> sin_mult_out  --: out std_logic_vector(30 downto 0)
	);
--==================================================================

u_cos_rnd_ps : ROUNDING
   generic map(
      i_bit => 31,  --: integer;
      o_bit => 19   --: integer
   )
   port map( 
      RESET => RESET, --: in  std_logic;
      CLK   => CLK, --: in  std_logic;
      IND   => cos_mult_out, --: in  std_logic_vector(i_bit-1 downto 0);
      RES   => cos_round_out  --: out std_logic_vector(o_bit-1 downto 0)
   );
   
u_cos_sat_ps : SAT
   generic map(
      i_bit => 19, --: integer;
      o_bit => 16  --: integer
   )
   port map( 
      RESET => RESET, --: in  std_logic;
      CLK   => CLK, --: in  std_logic;
      IND   => cos_round_out, --: in  std_logic_vector(i_bit-1 downto 0);
      RES   => cos_sat_peak  --: out std_logic_vector(o_bit-1 downto 0)
   );

u_sin_rnd_ps : ROUNDING
   generic map(
      i_bit => 31,  --: integer;
      o_bit => 19   --: integer
   )
   port map( 
      RESET => RESET, --: in  std_logic;
      CLK   => CLK, --: in  std_logic;
      IND   => sin_mult_out, --: in  std_logic_vector(i_bit-1 downto 0);
      RES   => sin_round_out  --: out std_logic_vector(o_bit-1 downto 0)
   );
   
u_sin_sat_ps : SAT
   generic map(
      i_bit => 19, --: integer;
      o_bit => 16  --: integer
   )
   port map( 
      RESET => RESET, --: in  std_logic;
      CLK   => CLK, --: in  std_logic;
      IND   => sin_round_out, --: in  std_logic_vector(i_bit-1 downto 0);
      RES   => sin_sat_peak  --: out std_logic_vector(o_bit-1 downto 0)
   );

PEAK_I <= cos_sat_peak;
PEAK_Q <= sin_sat_peak;

end arc_PEAK_SCALE_V2;