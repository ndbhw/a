-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity GAIN_COMPENSATION_V2 is
			port (
						RESET 							: in	std_logic;
						CLK									: in	std_logic;
						
						CORDIC_AMPLITUDE		: in	std_logic_vector(17 downto 0);
						
						COMPENSATED_AMPLITUDE_PRE	: out	std_logic_vector(15 downto 0);
						COMPENSATED_AMPLITUDE	    : out	std_logic_vector(15 downto 0)
						);
end GAIN_COMPENSATION_V2;

architecture arc_GAIN_COMPENSATION_V2 of GAIN_COMPENSATION_V2 is

signal sign_ext_in					: std_logic_vector(27 downto 0);
signal add8zeros_lsb				: std_logic_vector(27 downto 0);
signal add6zeros_lsb				: std_logic_vector(27 downto 0);
signal add3zeros_lsb				: std_logic_vector(27 downto 0);

signal add_0								: std_logic_vector(27 downto 0);
signal add_1								: std_logic_vector(27 downto 0);
signal result_28b						: std_logic_vector(27 downto 0);
signal trunc_19b						: std_logic_vector(18 downto 0);

--signal max_value						: std_logic_vector(15 downto 0);
signal comp_out_ff    : std_logic_vector(15 downto 0);
--signal sat_flag							: std_logic;
--signal lsb_16b							: std_logic_vector(15 downto 0);

begin

sign_ext_in <= CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE;
add8zeros_lsb <= CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE & "00000000";
add6zeros_lsb <= CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE & "000000";
add3zeros_lsb <= CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE(17) & CORDIC_AMPLITUDE & "000";

process(RESET,CLK)
begin
	if RESET = '1' then
		add_0 <= (others => '0');
		add_1 <= (others => '0');
		result_28b <= (others => '0');
	elsif (CLK'event and CLK='1') then
		add_0 <= add8zeros_lsb + add6zeros_lsb;
		add_1 <= sign_ext_in + add3zeros_lsb;
		result_28b <= add_0 - add_1;
	end if;
end process;

trunc_19b <= result_28b(27 downto 9);

process(RESET,CLK)
begin
	if RESET = '1' then
	  comp_out_ff <= (others => '0');
		COMPENSATED_AMPLITUDE <= (others => '0');
	elsif (CLK'event and CLK='1') then
	   if (trunc_19b(18) or trunc_19b(17) or trunc_19b(16)) = '1' then
	      if trunc_19b(18) = '1' then
	         comp_out_ff <= (others => '0');
	      else
	         comp_out_ff <= x"FFFF";
	      end if;
	   else
	      comp_out_ff <= trunc_19b(15 downto 0);
	   end if;
	   
	   COMPENSATED_AMPLITUDE <= comp_out_ff;
	end if;
end process;

COMPENSATED_AMPLITUDE_PRE <= comp_out_ff;

end arc_GAIN_COMPENSATION_V2;