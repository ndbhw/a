-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
library UNISIM;
use UNISIM.VComponents.all;

entity SINCOS_V2P5 is

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							CLOCK_UNSTABLE		: in	std_logic;  -- '0' : stable , '1' : unstable
							
							CORDIC_STAGE_1		:	in	std_logic;
							CORDIC_STAGE_2		:	in	std_logic;
							CORDIC_STAGE_3		:	in	std_logic;
							CORDIC_STAGE_4		:	in	std_logic;
							CORDIC_STAGE_5		:	in	std_logic;
							
							SIN_OUT						:	out	std_logic_vector(13 downto 0);
							COS_OUT						:	out	std_logic_vector(13 downto 0)
						);
end SINCOS_V2P5;

architecture arc_SINCOS_V2P5 of SINCOS_V2P5 is

-- for Xilinx Simple Dual port RAM -----------
--component SIN_LUT_ROM
--	port (
--	clka: in std_logic;
--	ena: in std_logic;
--	addra: in std_logic_vector(4 downto 0);
--	douta: out std_logic_vector(13 downto 0));
--end component;
--
--component COS_LUT_ROM
--	port (
--	clka: in std_logic;
--	ena: in std_logic;
--	addra: in std_logic_vector(4 downto 0);
--	douta: out std_logic_vector(13 downto 0));
--end component;

-----------------------------------------------------
COMPONENT COS_LUT_ROM_V2P5
  PORT (
    a : IN STD_LOGIC_VECTOR(4 DOWNTO 0);
    clk : IN STD_LOGIC;
    qspo : OUT STD_LOGIC_VECTOR(13 DOWNTO 0)
  );
END COMPONENT;

COMPONENT SIN_LUT_ROM_V2P5
  PORT (
    a : IN STD_LOGIC_VECTOR(4 DOWNTO 0);
    clk : IN STD_LOGIC;
    qspo : OUT STD_LOGIC_VECTOR(13 DOWNTO 0)
  );
END COMPONENT;
--------------------------------------------------

signal lut_addr			: std_logic_vector(4 downto 0);
signal s1_delay   : std_logic_vector(4 downto 0);
signal s2_delay   : std_logic_vector(3 downto 0);
signal s3_delay   : std_logic_vector(2 downto 0);
signal s4_delay   : std_logic_vector(1 downto 0);
signal s5_delay   : std_logic;
--signal rom_cos_out : std_logic_vector(13 downto 0);
--signal rom_sin_out : std_logic_vector(13 downto 0);
--signal rom_cos_out_ff : std_logic_vector(13 downto 0);
--signal rom_sin_out_ff : std_logic_vector(13 downto 0);
signal rom_en_f, rom_en_ff : std_logic;

--signal test_out_cos : std_logic_vector(13 downto 0);
--signal test_out_sin : std_logic_vector(13 downto 0);

begin
  
process(RESET,CLK)
begin
	if RESET = '1' then
	  s1_delay <= (others => '0');
	  s2_delay <= (others => '0');
	  s3_delay <= (others => '0');
	  s4_delay <= (others => '0');
	  s5_delay <= '0';
	elsif (CLK'event and CLK='1') then
	  s1_delay <= s1_delay(3 downto 0) & CORDIC_STAGE_1;
	  s2_delay <= s2_delay(2 downto 0) & CORDIC_STAGE_2;
	  s3_delay <= s3_delay(1 downto 0) & CORDIC_STAGE_3;
	  s4_delay <= s4_delay(0) & CORDIC_STAGE_4;
	  s5_delay <= CORDIC_STAGE_5;
	end if;
end process;

lut_addr <= s1_delay(4) & s2_delay(3) & s3_delay(2) & s4_delay(1) & s5_delay;

process(RESET,CLK)
begin
	if RESET = '1' then
		rom_en_f <= '0';
		rom_en_ff <= '0';
	elsif (CLK'event and CLK='1') then
		rom_en_f <= not CLOCK_UNSTABLE;
		rom_en_ff <= rom_en_f;
	end if;
end process;

--u_cos_lut_rom : COS_LUT_ROM
--		port map (
--			clka => CLK,
--			ena => rom_en_ff,
--			addra => lut_addr,
--			douta => COS_OUT);
--			
--u_sin_lut_rom : SIN_LUT_ROM
--		port map (
--			clka => CLK,
--			ena => rom_en_ff,
--			addra => lut_addr,
--			douta => SIN_OUT);

----------------------------------------------
u_cos_lut_rom : COS_LUT_ROM_V2P5
  PORT MAP (
    a => lut_addr,
    clk => CLK,
    qspo => COS_OUT
  );
  
u_sin_lut_rom : SIN_LUT_ROM_V2P5
  PORT MAP (
    a => lut_addr,
    clk => CLK,
    qspo => SIN_OUT
  );

end arc_SINCOS_V2P5;