-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

entity OUTPUT_DEMUX_V2 is
   port(
   
        RESET                 : in  std_logic;
        CLK                   : in  std_logic;
        
        --CH_NUM                : in  std_logic;
        MUXED_IIN             : in  std_logic_vector(15 downto 0);
        MUXED_QIN             : in  std_logic_vector(15 downto 0);
        
        PATH_0_IOUT           : out std_logic_vector(15 downto 0);
        PATH_0_QOUT           : out std_logic_vector(15 downto 0);
        PATH_1_IOUT           : out std_logic_vector(15 downto 0);
        PATH_1_QOUT           : out std_logic_vector(15 downto 0)    
        );
end OUTPUT_DEMUX_V2;

architecture arc_OUTPUT_DEMUX_V2 of OUTPUT_DEMUX_V2 is

signal i_mux_I_d              : std_logic_vector(15 downto 0);
signal i_mux_Q_d              : std_logic_vector(15 downto 0);

signal i_tog            : std_logic;

begin

process(RESET,CLK)
begin
   if RESET = '1' then
      i_tog <= '0';
   elsif rising_edge(CLK) then
      i_tog <= not i_tog;
   end if;
end process;

process(RESET,CLK)
begin
   if RESET = '1' then
      i_mux_I_d <= (others => '0');
      i_mux_Q_d <= (others => '0');
   elsif rising_edge(CLK) then
      i_mux_I_d <= MUXED_IIN;
      i_mux_Q_d <= MUXED_QIN;
   end if;
end process;

process(RESET,CLK)
begin
   if RESET = '1' then
      PATH_0_IOUT <= (others => '0');
      PATH_0_QOUT <= (others => '0');
      PATH_1_IOUT <= (others => '0');
      PATH_1_QOUT <= (others => '0');
   elsif rising_edge(CLK) then
      --if CH_NUM = '1' then
      if i_tog = '1' then
         PATH_0_IOUT <= i_mux_I_d;
         PATH_1_IOUT <= MUXED_IIN;
         PATH_0_QOUT <= i_mux_Q_d;
         PATH_1_QOUT <= MUXED_QIN;
      end if;
   end if;
end process;

end arc_OUTPUT_DEMUX_V2;