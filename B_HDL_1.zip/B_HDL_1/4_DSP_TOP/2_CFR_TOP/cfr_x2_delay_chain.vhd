------------------------------------------------------------------
-- channel swap
------------------------------------------------------------------
-- 2013.11.01, vyacheslav : 1st release, system verilog
-- 2014.01.29, wj311.kim  : convert system_verilog to vhdl
------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

Library UNISIM;
use UNISIM.vcomponents.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_CONFIG.all;
use work.RU_FPGA_FNC.all;

entity cfr_x2_delay_chain is  --dduc_delay_chain
generic(
    BUFF_DEPTH                  : natural:= 64;-- SRL16E
    DIRECTION                   : natural:= 0; -- 1:forward, 0:reverse, 0 for general delay block
    WIDTH_IN                    : natural:= 16 -- Input data width
);
port(
    CLK                         : in  std_logic;
    DATA_SEL                    : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0); 
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);     
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)        
);
end cfr_x2_delay_chain;

architecture Behavioral of cfr_x2_delay_chain is

-- forward path memory only need (Channel number*HOVS) depth
constant BUFF_DEPTH_INTERNAL    : integer := ternary_func(DIRECTION=1, BUFF_DEPTH/2, BUFF_DEPTH);

signal i_data_sel               : std_logic_vector(3 downto 0); 
signal srl_out_0                : std_logic_vector(WIDTH_IN-1 downto 0); 
signal srl_out_1                : std_logic_vector(WIDTH_IN-1 downto 0); 
signal srl_out_2                : std_logic_vector(WIDTH_IN-1 downto 0); 
signal srl_out_3                : std_logic_vector(WIDTH_IN-1 downto 0); 
signal srl_cascade_0            : std_logic_vector(WIDTH_IN-1 downto 0); 
signal srl_cascade_1            : std_logic_vector(WIDTH_IN-1 downto 0); 
signal srl_cascade_2            : std_logic_vector(WIDTH_IN-1 downto 0); 
signal muxf7_out_0              : std_logic_vector(WIDTH_IN-1 downto 0); 
signal muxf7_out_1              : std_logic_vector(WIDTH_IN-1 downto 0); 

begin

    BUF_GEN_1 : if BUFF_DEPTH_INTERNAL = 1 generate
        process(CLK)
        begin
            if rising_edge(CLK) then
                if VALID_I = '1' then
                    FILTER_OUT <= FILTER_IN;
                end if;
            end if;
        end process;
    end generate BUF_GEN_1;

    BUF_GEN_16 : if BUFF_DEPTH_INTERNAL > 1 and BUFF_DEPTH_INTERNAL <= 16 generate
        -- selection generation
        SEL_GEN : for N in 0 to 3 generate
            SEL_VALID : if N <= log2(BUFF_DEPTH_INTERNAL)-1 generate
                i_data_sel(N) <=  DATA_SEL(N);
            end generate SEL_VALID;
            SEL_INVALID : if N > log2(BUFF_DEPTH_INTERNAL)-1 generate
                i_data_sel(N) <=  '0';
            end generate SEL_INVALID;
        end generate SEL_GEN;
        -- SRL16E generation
        SRL16E_GEN : for N in 0 to WIDTH_IN-1 generate
            SRL16E_inst : SRL16E
            generic map (
                INIT    => X"0000")
            port map (
                Q       => FILTER_OUT(N),   -- SRL data output
                A0      => i_data_sel(0),   -- Select[0] input
                A1      => i_data_sel(1),   -- Select[1] input
                A2      => i_data_sel(2),   -- Select[2] input
                A3      => i_data_sel(3),   -- Select[3] input
                CE      => VALID_I,         -- Clock enable input
                CLK     => CLK,             -- Clock input
                D       => FILTER_IN(N)     -- SRL data input
            );
        end generate SRL16E_GEN;
    end generate BUF_GEN_16;

    BUF_GEN_32 : if BUFF_DEPTH_INTERNAL > 16 and BUFF_DEPTH_INTERNAL <= 32 generate
        SRL32E_GEN : for N in 0 to WIDTH_IN-1 generate
           SRLC32E_inst : SRLC32E
           generic map (
              INIT => X"00000000")
           port map (
              Q         => FILTER_OUT(N),       -- SRL data output
              Q31       => open,                -- SRL cascade output pin
              A         => DATA_SEL(4 downto 0),-- 5-bit shift depth select input
              CE        => VALID_I,             -- Clock enable input
              CLK       => CLK,                 -- Clock input
              D         => FILTER_IN(N)         -- SRL data input
           );
        end generate SRL32E_GEN;
    end generate BUF_GEN_32;

    BUF_GEN_64 : if BUFF_DEPTH_INTERNAL > 32 and BUFF_DEPTH_INTERNAL <= 64 generate
--        FILTER_OUT <= srl_out_0 when DATA_SEL(5) = '0' else srl_out_1;

        SRL32E_2X_GEN : for N in 0 to WIDTH_IN-1 generate
           MUXF7_L_inst : MUXF7_L
           port map (
              LO        => FILTER_OUT(N),       -- Output of MUX to local routing
              I0        => srl_out_0(N),        -- Input (tie to LUT6 O6 pin)
              I1        => srl_out_1(N),        -- Input (tie to LUT6 O6 pin)
              S         => DATA_SEL(5)          -- Input select to MUX
           );

           SRLC32E_inst_0 : SRLC32E
           generic map (
              INIT => X"00000000")
           port map (
              Q         => srl_out_0(N),        -- SRL data output
              Q31       => srl_cascade_0(N),    -- SRL cascade output pin
              A         => DATA_SEL(4 downto 0),-- 5-bit shift depth select input
              CE        => VALID_I,             -- Clock enable input
              CLK       => CLK,                 -- Clock input
              D         => FILTER_IN(N)         -- SRL data input
           );
           
           SRLC32E_inst_1 : SRLC32E
           generic map (
              INIT => X"00000000")
           port map (
              Q         => srl_out_1(N),        -- SRL data output
              Q31       => open,                -- SRL cascade output pin
              A         => DATA_SEL(4 downto 0),-- 5-bit shift depth select input
              CE        => VALID_I,             -- Clock enable input
              CLK       => CLK,                 -- Clock input
              D         => srl_cascade_0(N)     -- SRL data input
           );
        end generate SRL32E_2X_GEN;
    end generate BUF_GEN_64;


    BUF_GEN_128 : if BUFF_DEPTH_INTERNAL > 64 and BUFF_DEPTH_INTERNAL <= 128 generate
--        FILTER_OUT <= srl_out_0 when DATA_SEL(5) = '0' else srl_out_1;

        SRL32E_4X_GEN : for N in 0 to WIDTH_IN-1 generate
           MUXF7_L_inst_0 : MUXF7_L
           port map (
              LO        => muxf7_out_0(N),      -- Output of MUX to local routing
              I0        => srl_out_0(N),        -- Input (tie to LUT6 O6 pin)
              I1        => srl_out_1(N),        -- Input (tie to LUT6 O6 pin)
              S         => DATA_SEL(5)          -- Input select to MUX
           );

           MUXF7_L_inst_1 : MUXF7_L
           port map (
              LO        => muxf7_out_1(N),      -- Output of MUX to local routing
              I0        => srl_out_2(N),        -- Input (tie to LUT6 O6 pin)
              I1        => srl_out_3(N),        -- Input (tie to LUT6 O6 pin)
              S         => DATA_SEL(5)          -- Input select to MUX
           );

           MUXF8_L_inst : MUXF8_L
           port map (
              LO        => FILTER_OUT(N),       -- Output of MUX to local routing
              I0        => muxf7_out_0(N),      -- Input (tie to LUT6 O6 pin)
              I1        => muxf7_out_1(N),      -- Input (tie to LUT6 O6 pin)
              S         => DATA_SEL(6)          -- Input select to MUX
           );

           SRLC32E_inst_0 : SRLC32E
           generic map (
              INIT => X"00000000")
           port map (
              Q         => srl_out_0(N),        -- SRL data output
              Q31       => srl_cascade_0(N),    -- SRL cascade output pin
              A         => DATA_SEL(4 downto 0),-- 5-bit shift depth select input
              CE        => VALID_I,             -- Clock enable input
              CLK       => CLK,                 -- Clock input
              D         => FILTER_IN(N)         -- SRL data input
           );
           
           SRLC32E_inst_1 : SRLC32E
           generic map (
              INIT => X"00000000")
           port map (
              Q         => srl_out_1(N),        -- SRL data output
              Q31       => srl_cascade_1(N),    -- SRL cascade output pin
              A         => DATA_SEL(4 downto 0),-- 5-bit shift depth select input
              CE        => VALID_I,             -- Clock enable input
              CLK       => CLK,                 -- Clock input
              D         => srl_cascade_0(N)     -- SRL data input
           );

           SRLC32E_inst_2 : SRLC32E
           generic map (
              INIT => X"00000000")
           port map (
              Q         => srl_out_2(N),        -- SRL data output
              Q31       => srl_cascade_2(N),    -- SRL cascade output pin
              A         => DATA_SEL(4 downto 0),-- 5-bit shift depth select input
              CE        => VALID_I,             -- Clock enable input
              CLK       => CLK,                 -- Clock input
              D         => srl_cascade_1(N)     -- SRL data input
           );
           
           SRLC32E_inst_3 : SRLC32E
           generic map (
              INIT => X"00000000")
           port map (
              Q         => srl_out_3(N),        -- SRL data output
              Q31       => open,                -- SRL cascade output pin
              A         => DATA_SEL(4 downto 0),-- 5-bit shift depth select input
              CE        => VALID_I,             -- Clock enable input
              CLK       => CLK,                 -- Clock input
              D         => srl_cascade_2(N)     -- SRL data input
           );

        end generate SRL32E_4X_GEN;
    end generate BUF_GEN_128;

end Behavioral;
