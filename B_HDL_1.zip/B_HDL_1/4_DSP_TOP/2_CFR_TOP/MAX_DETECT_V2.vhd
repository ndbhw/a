-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
library UNISIM;
use UNISIM.VComponents.all;

entity MAX_DETECT_V2 is

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							PEAK_SPACING_0		: in	std_logic_vector(7 downto 0);   -- Muxed 2ch.
							PEAK_SPACING_1		: in	std_logic_vector(7 downto 0);   -- Muxed 2ch.
							THRESHOLD					: in	std_logic_vector(15 downto 0);  -- Muxed 2ch.
							THRESHOLD_2				: in	std_logic_vector(16 downto 0);  -- Muxed 2ch.
							MAGNITUDE					:	in	std_logic_vector(15 downto 0);  -- Muxed 2ch.
							
							RST_SEARCH				: out	std_logic;
							NEW_MAX						: out	std_logic
							
						);
end MAX_DETECT_V2;

architecture arc_MAX_DETECT_V2 of MAX_DETECT_V2 is

component HANG_OVER_V2
			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							INPUT_FLAG				: in	std_logic;
							PEAK_SPACING_0			: in	std_logic_vector(7 downto 0);
							PEAK_SPACING_1			: in	std_logic_vector(7 downto 0);
							
							OUTPUT_FLAG				:	out	std_logic							
						);
end component;

signal i_input_flag				: std_logic;
signal i_output_flag			: std_logic;
signal i_output_flag_d	: std_logic;
signal magnitude_delayed  : std_logic_vector(15 downto 0);
signal peak_mux						: std_logic_vector(16 downto 0);
signal magnitude_ext					: std_logic_vector(16 downto 0);
signal magnitude_ext_d				: std_logic_vector(16 downto 0);
signal max_latch_en				: std_logic;
signal reg_max_0					: std_logic_vector(16 downto 0);
signal reg_max_1					: std_logic_vector(16 downto 0);
signal i_newmax						: std_logic;
signal i_ch_num      : std_logic;
signal i_btmax_0     : std_logic;
signal i_btmax_1     : std_logic;

signal i_tog            : std_logic;

begin

u_srl16_inst_gen : for i in 15 downto 0 generate
u_srl16_inst : SRL16E   -- for 3 clk delay
generic map (
  INIT => x"0000"
  )
port map (
  Q    => magnitude_delayed(i),
  A0   => '0',
  A1   => '1',  --'0',
  A2   => '0',  --'1',
  A3   => '0',
  CE   => '1',
  CLK  => CLK,
  D    => MAGNITUDE(i)
  );
end generate u_srl16_inst_gen;

magnitude_ext_d <= magnitude_delayed(15) & magnitude_delayed;
NEW_MAX <= i_newmax;

process(RESET,CLK)
begin
   if RESET = '1' then
      i_tog <= '0';
   elsif rising_edge(CLK) then
      i_tog <= not i_tog;
   end if;
end process;

process(RESET,CLK)
begin
   if RESET = '1' then
      i_ch_num <= '0';
   elsif (CLK'event and CLK='1') then
      i_ch_num <= i_tog;
   end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		i_input_flag <= '1';
	elsif (CLK'event and CLK='1') then
		if THRESHOLD > MAGNITUDE then
			i_input_flag <= '1';
		else
			i_input_flag <= '0';
		end if;
	end if;
end process;

u_hangover_blk : HANG_OVER_V2
			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK, --: in	std_logic;
							
							INPUT_FLAG				=> i_input_flag, --: in	std_logic;
							PEAK_SPACING_0		=> PEAK_SPACING_0, --: in	std_logic_vector(7 downto 0);
							PEAK_SPACING_1		=> PEAK_SPACING_1, --: in	std_logic_vector(7 downto 0);
							
							OUTPUT_FLAG				=> i_output_flag  --:	out	std_logic							
						);
						
process(RESET,CLK)
begin
	if RESET = '1' then
		peak_mux <= (others => '0');
	elsif (CLK'event and CLK='1') then
		if i_output_flag = '1' then
			peak_mux <= THRESHOLD_2;
		else
			peak_mux <= magnitude_ext_d;
		end if;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		i_newmax <= '0';
	elsif (CLK'event and CLK='1') then
	  if i_ch_num = '1' then
		   if (magnitude_ext_d >= reg_max_1) and (i_output_flag = '0') then
		   	i_newmax <= '1';
		   else
		   	i_newmax <= '0';
		   end if;
		else
		   if (magnitude_ext_d >= reg_max_0) and (i_output_flag = '0') then
		   	i_newmax <= '1';
		   else
		   	i_newmax <= '0';
		   end if;
		end if;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
	  i_btmax_0 <= '0';
	  i_btmax_1 <= '0';
	elsif (CLK'event and CLK='1') then
	  if i_ch_num = '1' then
	    if magnitude_ext_d >= reg_max_1 then
	      i_btmax_1 <= '1';
	    else
	      i_btmax_1 <= '0';
	    end if;
	  else
	    if magnitude_ext_d >= reg_max_0 then
	      i_btmax_0 <= '1';
	    else
	      i_btmax_0 <= '0';
	    end if;
	  end if;
	end if;
end process;


process(RESET,CLK)
begin
	if RESET = '1' then
		reg_max_0 <= (others => '0');
		reg_max_1 <= (others => '0');
	elsif (CLK'event and CLK='1') then
	  if i_ch_num = '1' then
		   if (i_btmax_0 = '1') or (i_output_flag_d = '1') then
			   reg_max_0 <= peak_mux;
		   end if;
		else
		   if (i_btmax_1 = '1') or (i_output_flag_d = '1') then
			   reg_max_1 <= peak_mux;
		   end if;
		end if;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
	  i_output_flag_d <= '1';
	elsif (CLK'event and CLK='1') then
	  i_output_flag_d <= i_output_flag;
	end if;
end process;

RST_SEARCH <= i_output_flag_d;

end arc_MAX_DETECT_V2;