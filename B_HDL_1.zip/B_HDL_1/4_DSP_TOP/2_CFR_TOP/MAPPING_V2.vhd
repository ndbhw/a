-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity MAPPING_V2 is
		port (
						RESET				: in	std_logic;
						CLK					: in	std_logic;
						
						SIGNAL_I		: in	std_logic_vector(15 downto 0);
						SIGNAL_Q		: in	std_logic_vector(15 downto 0);
						
						SIGNAL_I_OUT	: out	std_logic_vector(15 downto 0);
						SIGNAL_Q_OUT	: out	std_logic_vector(15 downto 0);
						
						SIGN_I			: out	std_logic;
						SIGN_Q			: out	std_logic;
						SWAP_IQ			: out	std_logic
						
					);
end MAPPING_V2;

architecture arc_MAPPING_V2 of MAPPING_V2 is

signal i_signal_in			: std_logic_vector(15 downto 0);
signal q_signal_in			: std_logic_vector(15 downto 0);
signal i_sign_d					: std_logic_vector(8 downto 0);
signal q_sign_d					: std_logic_vector(8 downto 0);
--signal i_sign_d					: std_logic_vector(10 downto 0);
--signal q_sign_d					: std_logic_vector(10 downto 0);
signal int_swap					: std_logic;
signal int_swap_d				: std_logic_vector(6 downto 0);
--signal int_swap_d				: std_logic_vector(8 downto 0);

begin

process(RESET,CLK)
begin
	if RESET = '1' then
		i_signal_in <= (others => '0');
		q_signal_in <= (others => '0');
	elsif (CLK'event and CLK = '1') then
		if SIGNAL_I(15) = '1' then
			i_signal_in <= not SIGNAL_I;
		else
			i_signal_in <= SIGNAL_I;
		end if;
		
		if SIGNAL_Q(15) = '1' then
			q_signal_in <= not SIGNAL_Q;
		else
			q_signal_in <= SIGNAL_Q;
		end if;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		SIGNAL_I_OUT <= (others => '0');
		SIGNAL_Q_OUT <= (others => '0');
		int_swap <= '0';
	elsif (CLK'event and CLK = '1') then
		if q_signal_in >= i_signal_in then
			SIGNAL_I_OUT <= q_signal_in;
			SIGNAL_Q_OUT <= i_signal_in;
			int_swap <= '1';
		else
			SIGNAL_I_OUT <= i_signal_in;
			SIGNAL_Q_OUT <= q_signal_in;
			int_swap <= '0';
		end if;
	end if;
end process;


-- Delayed sign, swap bit needed because of all stage , sincos table block latency
process(RESET,CLK)
begin
	if RESET = '1' then
		SIGN_I <= '0';
		SIGN_Q <= '0';
		SWAP_IQ <= '0';
		
		i_sign_d <= (others => '0');
		q_sign_d <= (others => '0');
		int_swap_d <= (others => '0');
	elsif (CLK'event and CLK = '1') then
		i_sign_d <= i_sign_d(7 downto 0) & SIGNAL_I(15);
		q_sign_d <= q_sign_d(7 downto 0) & SIGNAL_Q(15);
		--i_sign_d <= i_sign_d(9 downto 0) & SIGNAL_I(15);
		--q_sign_d <= q_sign_d(9 downto 0) & SIGNAL_Q(15);
		
		SIGN_I <= i_sign_d(8);
		SIGN_Q <= q_sign_d(8);
		--SIGN_I <= i_sign_d(10);
		--SIGN_Q <= q_sign_d(10);
		
		int_swap_d <= int_swap_d(5 downto 0) & int_swap;
		SWAP_IQ <= int_swap_d(6);
		--int_swap_d <= int_swap_d(7 downto 0) & int_swap;
		--SWAP_IQ <= int_swap_d(8);
	end if;
end process;

end arc_MAPPING_V2;