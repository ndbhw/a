-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
library UNISIM;
use UNISIM.VComponents.all;

entity FLAG_DELAY_BUFFER_V2 is
   port(
   				RESET										: in	std_logic;
   				CLK											: in	std_logic;

   				--CH_NUM                  : in  std_logic;
   				FLAG_DELAY_VALUE  			:	in	std_logic_vector(6 downto 0);  -- muxed flag delay value, 1 clock late compared to input flag / CH_NUM (6x - org. delay value)
   				   				
   				INPUT_FLAG							: in	std_logic;
   				OUTPUT_FLAG							: out	std_logic   				
   		);
end FLAG_DELAY_BUFFER_V2;

architecture arc_FLAG_DELAY_BUFFER_V2 of FLAG_DELAY_BUFFER_V2 is

-- when make dpram ip core , use common clock and check "read first mode" --

-- for Xilinx True Dual port RAM -----------
component tdpram_flag_delay_buffer
	port (
	clka: in std_logic;
	wea: in std_logic_vector(0 downto 0);
	addra: in std_logic_vector(6 downto 0);
	dina: in std_logic_vector(0 downto 0);
	douta: out std_logic_vector(0 downto 0);
	clkb: in std_logic;
	web: in std_logic_vector(0 downto 0);
	addrb: in std_logic_vector(6 downto 0);
	dinb: in std_logic_vector(0 downto 0);
	doutb: out std_logic_vector(0 downto 0));
end component;
----------------------------------------------

------------ Signals -------------------------
signal i_ch_num			  : std_logic;
signal input_flag_d   : std_logic;
signal wr_en_a_0			: std_logic_vector(0 downto 0);
signal wr_en_a_1			: std_logic_vector(0 downto 0);
signal addr_a				  : std_logic_vector(6 downto 0);
signal wr_data_a		  : std_logic_vector(0 downto 0);

signal wr_en_b_0			: std_logic_vector(0 downto 0);
signal wr_en_b_1			: std_logic_vector(0 downto 0);
signal addr_b_0				: std_logic_vector(6 downto 0);
signal addr_b_1				: std_logic_vector(6 downto 0);
signal wr_data_b	  	: std_logic_vector(0 downto 0);
signal rd_data_b_0		: std_logic_vector(0 downto 0);
signal rd_data_b_1		: std_logic_vector(0 downto 0);

signal i_tog            : std_logic;

begin

process(RESET,CLK)
begin
   if RESET = '1' then
      i_tog <= '0';
   elsif rising_edge(CLK) then
      i_tog <= not i_tog;
   end if;
end process;

-- for Xilinx True Dual port RAM -----------
u_flag_delay_dpram_0 : tdpram_flag_delay_buffer
		port map (
			clka => CLK,
			wea => wr_en_a_0,
			addra => addr_a,  --addr_a,
			dina => wr_data_a,
			douta => open,
			clkb => CLK,
			web => wr_en_b_0,
			addrb =>addr_b_0,  --addr_b,
			dinb => wr_data_b,
			doutb => rd_data_b_0);
			
u_flag_delay_dpram_1 : tdpram_flag_delay_buffer
		port map (
			clka => CLK,
			wea => wr_en_a_1,
			addra => addr_a,  --addr_a,
			dina => wr_data_a,
			douta => open,
			clkb => CLK,
			web => wr_en_b_1,
			addrb =>addr_b_1,  --addr_b,
			dinb => wr_data_b,
			doutb => rd_data_b_1);
----------------------------------------------
wr_data_b <= "0";

wr_en_a_0(0) <= i_ch_num;
--wr_en_a_1(0) <= CH_NUM;
wr_en_a_1(0) <= i_tog;
wr_en_b_0(0) <= i_ch_num;
--wr_en_b_1(0) <= CH_NUM;
wr_en_b_1(0) <= i_tog;

process(RESET,CLK)
begin
	if RESET = '1' then
		i_ch_num <= '0';
	elsif (CLK'event and CLK='1') then
		--i_ch_num <= CH_NUM;
		i_ch_num <= i_tog;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		addr_a <= (others => '0');
		input_flag_d <= '0';
		wr_data_a <= "0";
	elsif (CLK'event and CLK='1') then
	  addr_a <= addr_b_0 + FLAG_DELAY_VALUE;
		
		input_flag_d <= INPUT_FLAG;
		wr_data_a(0) <= input_flag_d;
	end if;
end process;



process(RESET,CLK)
begin
	if RESET = '1' then
		addr_b_0 <= (others => '0');
		addr_b_1 <= (others => '0');
		OUTPUT_FLAG <= '0';
	elsif (CLK'event and CLK='1') then
		if i_ch_num = '1' then  --INPUT_TOGGLE
    		addr_b_0 <= addr_b_0 + 1;
		end if;
		
		addr_b_1 <= addr_b_0;
		
		--if CH_NUM = '1' then
		if i_tog = '1' then
		  OUTPUT_FLAG <= rd_data_b_0(0);
		else
		  OUTPUT_FLAG <= rd_data_b_1(0);
		end if;
	end if;
end process;

end arc_FLAG_DELAY_BUFFER_V2;