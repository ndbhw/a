-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity CPG_TRIG_V2P5_3 is

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM            : in std_logic;
							PEAK_I						: in	std_logic_vector(15 downto 0);
							PEAK_Q						: in	std_logic_vector(15 downto 0);
							PEAK_MAG					: in	std_logic_vector(15 downto 0);
							
							INTERRUPT_FLAG_CPG_3	: in	std_logic;
							ALL_BUSY							: in	std_logic;
							CPG_0_CAN_INTRT				: in	std_logic;
							CPG_1_CAN_INTRT				: in	std_logic;
							CPG_2_CAN_INTRT				: in	std_logic;
							ALLOCATION_FLAG_CPG_0	: in	std_logic;
							ALLOCATION_FLAG_CPG_1	: in	std_logic;
							ALLOCATION_FLAG_CPG_2	: in	std_logic;
							ALLOCATION_FLAG_CPG_3	: in	std_logic;
							PEAK_INDICATOR				: in	std_logic;
							
							CPG_3_PEAK_I			: out	std_logic_vector(15 downto 0);
							CPG_3_PEAK_Q			: out	std_logic_vector(15 downto 0);
							
							TRIG_ALLOC_CPG_3	: out	std_logic

						);
end CPG_TRIG_V2P5_3;

architecture arc_CPG_TRIG_V2P5_3 of CPG_TRIG_V2P5_3 is

signal latch_en					    : std_logic;
signal peak_mag_d				    : std_logic_vector(15 downto 0);
signal peak_mag_latch_0			: std_logic_vector(15 downto 0);
signal peak_mag_latch_1			: std_logic_vector(15 downto 0);
signal peak_I_latch_0       : std_logic_vector(15 downto 0);
signal peak_Q_latch_0       : std_logic_vector(15 downto 0);
signal peak_I_latch_1       : std_logic_vector(15 downto 0);
signal peak_Q_latch_1       : std_logic_vector(15 downto 0);
signal temp0, temp1, temp2  : std_logic :='0';
signal temp0_1              : std_logic :='0';
signal i_peak_ind           : std_logic :='0';
signal i_int_flag_3         : std_logic :='0';
signal i_latch_en_dly       : std_logic_vector(2 downto 0) :="000";

signal i_tog            : std_logic;

begin

process(RESET,CLK)
begin
   if RESET = '1' then
      i_tog <= '0';
   elsif rising_edge(CLK) then
      i_tog <= not i_tog;
   end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
    temp0 <= '0';
	elsif (CLK'event and CLK='1') then
    --if CH_NUM = '1' then
    if i_tog = '1' then
      if PEAK_MAG > peak_mag_latch_1 then
        temp0 <= '1';
      else
        temp0 <= '0';
      end if;
    else
      if PEAK_MAG > peak_mag_latch_0 then
        temp0 <= '1';
      else
        temp0 <= '0';
      end if;
    end if;
	end if;
end process;

process(RESET,CLK)
begin
	if (CLK'event and CLK='1') then
	  i_int_flag_3 <= INTERRUPT_FLAG_CPG_3;
	end if;
end process;

process(RESET,CLK)
begin
	if (CLK'event and CLK='1') then
	  i_peak_ind <= PEAK_INDICATOR;
	end if;
end process;

process(RESET,CLK)
begin
	if (CLK'event and CLK='1') then
	  temp2 <= (not ALLOCATION_FLAG_CPG_3) and ALLOCATION_FLAG_CPG_2 and ALLOCATION_FLAG_CPG_1 and ALLOCATION_FLAG_CPG_0;
	end if;
end process;

temp0_1 <= i_int_flag_3 and ALL_BUSY and (not CPG_0_CAN_INTRT) and (not CPG_1_CAN_INTRT) and (not CPG_2_CAN_INTRT);
temp1 <= temp0 and temp0_1;
latch_en <= (temp1 or temp2) and i_peak_ind;

process(RESET,CLK)
begin
	if RESET = '1' then
		peak_mag_d <= (others => '0');
		peak_mag_latch_0 <= (others => '0');
		peak_mag_latch_1 <= (others => '0');
	elsif (CLK'event and CLK='1') then
		peak_mag_d <= PEAK_MAG;
		
		if (latch_en = '1') then
		  --if CH_NUM = '1' then
		  if i_tog = '1' then
  			peak_mag_latch_0 <= peak_mag_d;
  		else
  		  peak_mag_latch_1 <= peak_mag_d;
  		end if;
		end if;

	end if;
end process;

process(RESET,CLK)
begin
	if (CLK'event and CLK='1') then
	  i_latch_en_dly <= i_latch_en_dly(1 downto 0) & latch_en;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		peak_I_latch_0 <= (others => '0');
		peak_Q_latch_0 <= (others => '0');
		peak_I_latch_1 <= (others => '0');
		peak_Q_latch_1 <= (others => '0');
	elsif (CLK'event and CLK='1') then
		if i_latch_en_dly(2) = '1' then
		  --if CH_NUM = '1' then
		  if i_tog = '1' then
  			peak_I_latch_1 <= PEAK_I;
  			peak_Q_latch_1 <= PEAK_Q;
  		else
  		  peak_I_latch_0 <= PEAK_I;
  			peak_Q_latch_0 <= PEAK_Q;
  		end if;
		end if;
	end if;
end process;

--process(RESET,CLK)
--begin
--	if RESET = '1' then
--		CPG_3_PEAK_I <= (others => '0');
--		CPG_3_PEAK_Q <= (others => '0');
--	elsif (CLK'event and CLK='1') then
--	  --if CH_NUM = '1' then
--	  if i_tog = '1' then
--	     CPG_3_PEAK_I <= peak_I_latch_0;
--	     CPG_3_PEAK_Q <= peak_Q_latch_0;
--	  else
--	     CPG_3_PEAK_I <= peak_I_latch_1;
--	     CPG_3_PEAK_Q <= peak_Q_latch_1;
--	  end if;
--  end if;
--end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		CPG_3_PEAK_I <= (others => '0');
		CPG_3_PEAK_Q <= (others => '0');
	elsif (CLK'event and CLK='1') then
	  --if CH_NUM = '1' then
	  if i_tog = '1' then
	     CPG_3_PEAK_I <= peak_I_latch_1;
	     CPG_3_PEAK_Q <= peak_Q_latch_1;
	  else
	     CPG_3_PEAK_I <= peak_I_latch_0;
	     CPG_3_PEAK_Q <= peak_Q_latch_0;
	  end if;
  end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		--latch_en <= '0';
		TRIG_ALLOC_CPG_3 <= '0';
	elsif (CLK'event and CLK='1') then
		--latch_en <= (temp1 or temp2) and PEAK_INDICATOR;
		TRIG_ALLOC_CPG_3 <= latch_en;
	end if;
end process;

end arc_CPG_TRIG_V2P5_3;