-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
library UNISIM;
use UNISIM.VComponents.all;

entity INTERNAL_DATA_DELAY_PIQ is
			generic(
      data_delay : std_logic_vector(6 downto 0)
   		);
			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM            : in	std_logic;
							DATA_IN_I					: in	std_logic_vector(15 downto 0);
							DATA_IN_Q					: in	std_logic_vector(15 downto 0);
							
							DATA_OUT_I				: out	std_logic_vector(15 downto 0);
							DATA_OUT_Q				: out	std_logic_vector(15 downto 0)
						);
end INTERNAL_DATA_DELAY_PIQ;

architecture arc_INTERNAL_DATA_DELAY_PIQ of INTERNAL_DATA_DELAY_PIQ is

--component cfr_mem_16x128
--	port (
--	clka: in std_logic;
--	wea: in std_logic_vector(0 downto 0);
--	addra: in std_logic_vector(6 downto 0);
--	dina: in std_logic_vector(15 downto 0);
--	clkb: in std_logic;
--	addrb: in std_logic_vector(6 downto 0);
--	doutb: out std_logic_vector(15 downto 0));
--end component;

component cfr_mem_32x256
	port (
	clka: in std_logic;
	wea: in std_logic_vector(0 downto 0);
	addra: in std_logic_vector(7 downto 0);
	dina: in std_logic_vector(31 downto 0);
	clkb: in std_logic;
	addrb: in std_logic_vector(7 downto 0);
	doutb: out std_logic_vector(31 downto 0));
end component;

signal we_s				  : std_logic_vector(0 downto 0);
signal wr_addr_cnt  : std_logic_vector(6 downto 0);
signal wr_addr		  : std_logic_vector(7 downto 0);
signal wr_data      : std_logic_vector(31 downto 0);
signal rd_addr_cnt 	: std_logic_vector(6 downto 0);
signal rd_addr	  	: std_logic_vector(7 downto 0);
signal rd_data	  	: std_logic_vector(31 downto 0);
signal i_ch_num			: std_logic;

signal i_tog            : std_logic;

begin

we_s <= "1";

process(RESET,CLK)
begin
   if RESET = '1' then
      i_tog <= '0';
   elsif rising_edge(CLK) then
      i_tog <= not i_tog;
   end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		i_ch_num <= '0';
	elsif (CLK'event and CLK='1') then
		--i_ch_num <= CH_NUM;
		i_ch_num <= i_tog;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		wr_addr_cnt <= (others => '0');
	elsif (CLK'event and CLK='1') then
	  if i_ch_num = '1' then  --INPUT_TOGGLE
		  wr_addr_cnt <= wr_addr_cnt + 1;
		end if;
	end if;
end process;

wr_addr <= wr_addr_cnt & i_ch_num;
wr_data <= DATA_IN_I & DATA_IN_Q;

process(RESET,CLK)
begin
	if RESET = '1' then
		rd_addr_cnt <= (others => '0');
	elsif (CLK'event and CLK='1') then
		if i_ch_num = '1' then  --INPUT_TOGGLE
			rd_addr_cnt <= wr_addr_cnt - data_delay;
		end if;
	end if;
end process;

rd_addr <= rd_addr_cnt & i_ch_num;

--u_delay_mem_blk : cfr_mem_16x128
--	port map(
--	clka		=> CLK, --: in std_logic;
--	wea			=> we_s, --: in std_logic_vector(0 downto 0);
--	addra		=> wr_addr, --: in std_logic_vector(6 downto 0);
--	dina		=> wr_data, --: in std_logic_vector(15 downto 0);
--	clkb		=> CLK, --: in std_logic;
--	addrb		=> rd_addr, --: in std_logic_vector(6 downto 0);
--	doutb		=> rd_data  --: out std_logic_vector(15 downto 0)
--	);
	
u_delay_mem_blk : cfr_mem_32x256
	port map(
	clka		=> CLK, --: in std_logic;
	wea			=> we_s, --: in std_logic_vector(0 downto 0);
	addra		=> wr_addr, --: in std_logic_vector(6 downto 0);
	dina		=> wr_data, --: in std_logic_vector(15 downto 0);
	clkb		=> CLK, --: in std_logic;
	addrb		=> rd_addr, --: in std_logic_vector(6 downto 0);
	doutb		=> rd_data  --: out std_logic_vector(15 downto 0)
	);
	
process(RESET,CLK)
begin
	if RESET = '1' then
		DATA_OUT_I <= (others => '0');
		DATA_OUT_Q <= (others => '0');
	elsif (CLK'event and CLK='1') then
		DATA_OUT_I <= rd_data(31 downto 16);
		DATA_OUT_Q <= rd_data(15 downto 0);
	end if;
end process;
	
end arc_INTERNAL_DATA_DELAY_PIQ;