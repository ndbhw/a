-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision: 19.12.05 
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity LTE_SEC_PC_CFR_TOP_V2P5 is
generic (
    FRAC_DLY_FILTER_EN          : boolean := TRUE;
    UPSAMPLE_MODE_EN            : boolean := TRUE
);
port(
    CFR_DATE_OUT                : out std_logic_vector(31 downto 0);
    CFR_VER_OUT                 : out std_logic_vector(7 downto 0);
    
    RESET                       : in std_logic;
    CLK                         : in std_logic;
    CLOCK_UNSTABLE              : in std_logic;
    
    CFR_BYPASS                  : in std_logic_vector(1 downto 0);
    
    CFR_THRESHOLD_0             : in std_logic_vector(15 downto 0);
    CFR_THRESHOLD_1             : in std_logic_vector(15 downto 0);
    CFR_PEAK_SPACING_0          : in std_logic_vector(7 downto 0);
    CFR_PEAK_SPACING_1          : in std_logic_vector(7 downto 0);
    
    CFR_COEFF_UPDATE_EN         : in std_logic;
    CFR_COEFF_WE                : in std_logic;
    CFR_COEFF_WRADDR            : in std_logic_vector(9 downto 0);
    CFR_COEFF_WRDATA            : in std_logic_vector(31 downto 0);
    
    CFR_TAP_NUM                 : in std_logic_vector(9 downto 0);
    
    CFR_0_INPUT_I               : in std_logic_vector(15 downto 0);
    CFR_0_INPUT_Q               : in std_logic_vector(15 downto 0);
    CFR_1_INPUT_I               : in std_logic_vector(15 downto 0);
    CFR_1_INPUT_Q               : in std_logic_vector(15 downto 0);
          
    CFR_0_OUTPUT_I              : out std_logic_vector(15 downto 0);
    CFR_0_OUTPUT_Q              : out std_logic_vector(15 downto 0);
    CFR_1_OUTPUT_I              : out std_logic_vector(15 downto 0);
    CFR_1_OUTPUT_Q              : out std_logic_vector(15 downto 0);
    
    PIM_CFR_0_OUTPUT_I          : out std_logic_vector(15 downto 0);
    PIM_CFR_0_OUTPUT_Q          : out std_logic_vector(15 downto 0);
    PIM_CFR_1_OUTPUT_I          : out std_logic_vector(15 downto 0);
    PIM_CFR_1_OUTPUT_Q          : out std_logic_vector(15 downto 0)
);
end LTE_SEC_PC_CFR_TOP_V2P5;

architecture arch_LTE_SEC_PC_CFR_TOP_V2P5 of LTE_SEC_PC_CFR_TOP_V2P5 is

component CALC_CPG_MINMAX_2P5
port(
    RESET                       : in std_logic;
    CLK                         : in std_logic;
    
    CFR_TAP_NUM                 : in std_logic_vector(9 downto 0);
    
    CPG_MIN_NUM                 : out std_logic_vector(9 downto 0)
);
end component;

component INPUT_MUX_V2
port(
    RESET                       : in  std_logic;
    CLK                         : in  std_logic;
    
    DATA_EN                     : in std_logic;
    PATH_0_I                    : in  std_logic_vector(15 downto 0);
    PATH_0_Q                    : in  std_logic_vector(15 downto 0);
    PATH_1_I                    : in  std_logic_vector(15 downto 0);
    PATH_1_Q                    : in  std_logic_vector(15 downto 0);
    
    --CH_NUM                      : out std_logic;
    MUXED_I                     : out std_logic_vector(15 downto 0);
    MUXED_Q                     : out std_logic_vector(15 downto 0)
);
end component;

component LTE_CFR_STAGE_V2P5
port(
    RESET                       : in std_logic;
    CLK                         : in std_logic;
    CLOCK_UNSTABLE              : in std_logic;
    
    CFR_THRESHOLD_0             : in std_logic_vector(15 downto 0);
    CFR_THRESHOLD_1             : in std_logic_vector(15 downto 0);
    CFR_PEAK_SPACING_0          : in std_logic_vector(7 downto 0);
    CFR_PEAK_SPACING_1          : in std_logic_vector(7 downto 0);
    
    CFR_COEFF_UPDATE_EN         : in std_logic;
    CFR_COEFF_WE                : in std_logic;
    CFR_COEFF_WRADDR            : in std_logic_vector(9 downto 0);
    CFR_COEFF_WRDATA            : in std_logic_vector(31 downto 0);
    
    MIN_NUM                     : in std_logic_vector(9 downto 0);
    
    CFR_TAP_NUM                 : in std_logic_vector(9 downto 0);
    
    SIG_DELAY_VALUE             : in std_logic_vector(8 downto 0);  -- until logic fixed!
    FLAG_DELAY_VALUE            : in std_logic_vector(6 downto 0);  -- until logic fixed!
    
    CFR_INPUT_I                 : in std_logic_vector(15 downto 0);
    CFR_INPUT_Q                 : in std_logic_vector(15 downto 0);
    
    CFRSTAGE_OUT_I              : out std_logic_vector(15 downto 0);
    CFRSTAGE_OUT_Q              : out std_logic_vector(15 downto 0)
);
end component;

component FRAC_DLY_FILTER_RTL_V2
port(
    RESET                       : in std_logic;
    CLK                         : in std_logic;
    
    --INPUT_TOGGLE : in std_logic;
    INPUT_DATA_I                : in std_logic_vector(15 downto 0);
    INPUT_DATA_Q                : in std_logic_vector(15 downto 0);
    
    --OUTPUT_TOGGLE : out std_logic;
    OUTPUT_DATA_I               : out std_logic_vector(15 downto 0);
    OUTPUT_DATA_Q               : out std_logic_vector(15 downto 0)
);
end component;

component CFR_BYPASS_SEL_V2
port(
    RESET                       : in  std_logic;
    CLK                         : in  std_logic;
    
    CFR_BYPASS                  : in  std_logic_vector(1 downto 0);
    
    --CH_NUM                      : in  std_logic;
    CFR_I_IN                    : in  std_logic_vector(15 downto 0); -- from input mux block
    CFR_Q_IN                    : in  std_logic_vector(15 downto 0); -- from input mux block
    
    ITR_I_DATA                  : in  std_logic_vector(15 downto 0); -- from last cfr stage block
    ITR_Q_DATA                  : in  std_logic_vector(15 downto 0); -- from last cfr stage block
    
    SEL_IOUT                    : out std_logic_vector(15 downto 0);
    SEL_QOUT                    : out std_logic_vector(15 downto 0)    
);
end component;

component OUTPUT_DEMUX_V2
port(
    RESET                       : in  std_logic;
    CLK                         : in  std_logic;
    
    --CH_NUM                      : in  std_logic;
    MUXED_IIN                   : in  std_logic_vector(15 downto 0);
    MUXED_QIN                   : in  std_logic_vector(15 downto 0);
    
    PATH_0_IOUT                 : out std_logic_vector(15 downto 0);
    PATH_0_QOUT                 : out std_logic_vector(15 downto 0);
    PATH_1_IOUT                 : out std_logic_vector(15 downto 0);
    PATH_1_QOUT                 : out std_logic_vector(15 downto 0)     
);
end component;

--component X2_INTP_FILTER
--   port(
--       RESET     : in std_logic;
--       CLK      : in std_logic;
--       
--       INPUT_DATA_I : in std_logic_vector(15 downto 0);
--       INPUT_DATA_Q : in std_logic_vector(15 downto 0);
--       
--       OUTPUT_DATA_I : out std_logic_vector(15 downto 0);
--       OUTPUT_DATA_Q : out std_logic_vector(15 downto 0)
--      );
--end component;

component CFR_X2_RTL
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    INPUT_VALID                 : in  std_logic;
    INPUT_DATA_I                : in  std_logic_vector(15 downto 0);
    INPUT_DATA_Q                : in  std_logic_vector(15 downto 0);

    OUTPUT_VALID                : out std_logic;
    OUTPUT_DATA_I               : out std_logic_vector(15 downto 0);
    OUTPUT_DATA_Q               : out std_logic_vector(15 downto 0)
);
end component;

component RST_SYNC is
generic (
    DLY_NUM                     : natural := 4;    -- Number of delay.
    MAX_FANOUT_NUM              : integer := 200   -- Number of maximum fanout
);
port (
    RST_IN                      : in  std_logic;          -- Active high asynchronous reset
    CLK                         : in  std_logic;          -- clock to be sync'ed to
    RST_OUT                     : out std_logic           -- "Synchronised" reset signal
);         
end component;


component LTE_CFR_SIGNAL_DELAY_BUFFER is
    port(
    RESET										: in	std_logic;
    CLK											: in	std_logic;

   	DELAY_VALUE							:	in	std_logic_vector(9 downto 0);
   	
   	--CH_NUM                  : in	std_logic;
   	INPUT_I									: in	std_logic_vector(15 downto 0);
   	INPUT_Q									: in	std_logic_vector(15 downto 0);
   	
   	OUTPUT_I								: out	std_logic_vector(15 downto 0);
   	OUTPUT_Q								: out	std_logic_vector(15 downto 0)
   		);
end component;


















--=============== internal signal ======================================
--signal i_cfr_rst_f, i_cfr_rst_ff, i_cfr_rst_fff, i_cfr_rst_ffff : std_logic;
signal i_cfr_rst_sh                 : std_logic_vector(12 downto 0);
signal i_cfr_rst                    : std_logic;
signal i_cfr_threshold2             : std_logic_vector(16 downto 0);
signal i_cpg_min_num                : std_logic_vector(9 downto 0);

signal i_int_toggle, i_int_toggle_d : std_logic;
signal i_init_cnt                   : std_logic_vector(3 downto 0);
signal i_data_accept_en             : std_logic;

--attribute MAX_FANOUT : string;
--attribute MAX_FANOUT of i_cfr_rst_f, i_cfr_rst_ff, i_cfr_rst_fff, i_cfr_rst_ffff : signal is "REDUCE";

--attribute EQUIVALENT_REGISTER_REMOVAL : string;
--attribute EQUIVALENT_REGISTER_REMOVAL of i_cfr_rst_f, i_cfr_rst_ff, i_cfr_rst_fff, i_cfr_rst_ffff : signal is "NO";

signal i_ch_num                     : std_logic;
signal i_mux_IDATA                  : std_logic_vector(15 downto 0);
signal i_mux_QDATA                  : std_logic_vector(15 downto 0);
signal i_cfr_v2_1st_i_out           : std_logic_vector(15 downto 0);
signal i_cfr_v2_1st_q_out           : std_logic_vector(15 downto 0);
signal i_cfr_v2_2nd_i_out           : std_logic_vector(15 downto 0);
signal i_cfr_v2_2nd_q_out           : std_logic_vector(15 downto 0);
signal i_cfr_v2_3rd_i_out           : std_logic_vector(15 downto 0);
signal i_cfr_v2_3rd_q_out           : std_logic_vector(15 downto 0);
signal i_cfr_v2_4th_i_out           : std_logic_vector(15 downto 0);
signal i_cfr_v2_4th_q_out           : std_logic_vector(15 downto 0);

signal i_cfr_v2_4th_i_dly_out       : std_logic_vector(15 downto 0);
signal i_cfr_v2_4th_q_dly_out       : std_logic_vector(15 downto 0);







signal i_cfr_v2_frac_i_out          : std_logic_vector(15 downto 0);
signal i_cfr_v2_frac_q_out          : std_logic_vector(15 downto 0);
signal i_demux_out_path0_I          : std_logic_vector(15 downto 0);
signal i_demux_out_path0_Q          : std_logic_vector(15 downto 0);
signal i_demux_out_path1_I          : std_logic_vector(15 downto 0);
signal i_demux_out_path1_Q          : std_logic_vector(15 downto 0);
signal i_cfr_v2_x2_i_out            : std_logic_vector(15 downto 0);
signal i_cfr_v2_x2_q_out            : std_logic_vector(15 downto 0);

signal i_bypass_sel_iout            : std_logic_vector(15 downto 0);
signal i_bypass_sel_qout            : std_logic_vector(15 downto 0);




signal i_DELAY_VALUE                : std_logic_vector(9 downto 0) := "1010111010";  --  = (175x4) - 2     stage dly value 175, 4 stage, read clk value (-2)  
   

       

--======================================add output 3rd_i,p output PIM source signal -19.12.05

signal pim_cfr_out_i                : std_logic_vector(15 downto 0):= (others => '0');
signal pim_cfr_out_q                : std_logic_vector(15 downto 0):= (others => '0');
signal pim_cfr_out_i_d              : std_logic_vector(15 downto 0):= (others => '0');
signal pim_cfr_out_q_d              : std_logic_vector(15 downto 0):= (others => '0');


signal pim_demux_out_path0_I        : std_logic_vector(15 downto 0):= (others => '0');
signal pim_demux_out_path0_Q        : std_logic_vector(15 downto 0):= (others => '0');
signal pim_demux_out_path1_I        : std_logic_vector(15 downto 0):= (others => '0');
signal pim_demux_out_path1_Q        : std_logic_vector(15 downto 0):= (others => '0');

--=================================================================================





attribute KEEP : string;
attribute KEEP of i_cfr_rst_sh      : signal is "true";

--attribute max_fanout : string;
--attribute max_fanout of i_cfr_rst   : signal is "1200";

begin

    CFR_DATE_OUT <= x"20191205";
    CFR_VER_OUT <= x"25";
--TP_EN <= i_int_toggle_d;  -- A path data to TP
--===================== reset gen. =============================================================
--process(RESET,CLK)
--begin
-- if RESET = '1' then
--  i_cfr_rst_f <= '1';
--  i_cfr_rst_ff <= '1';
--  i_cfr_rst_fff <= '1';
--  i_cfr_rst_ffff <= '1';
-- elsif (CLK'event and CLK = '1') then
--  i_cfr_rst_f <= '0';
--  i_cfr_rst_ff <= i_cfr_rst_f;
--  i_cfr_rst_fff <= i_cfr_rst_ff;
--  i_cfr_rst_ffff <= i_cfr_rst_fff;
-- end if;
--end process;

--===================== reset gen. =============================================================

-- process(RESET,CLK)
-- begin
--     if RESET = '1' then
--        i_cfr_rst_sh <= (others => '1');
--        i_cfr_rst <= '1';
--     elsif (CLK'event and CLK = '1') then
--        i_cfr_rst_sh <= i_cfr_rst_sh(11 downto 0) & '0';
--        i_cfr_rst <= i_cfr_rst_sh(12);
--     end if;
-- end process;


    U_CFR_Core_Reset : RST_SYNC generic map(8, 200) port map(RESET, CLK, i_cfr_rst);

--===================== I/Q data accept enable after reset release =============================
    process(i_cfr_rst,CLK)
    begin
        if i_cfr_rst = '1' then
            i_int_toggle <= '0';
            i_int_toggle_d <= '0';
        elsif (CLK'event and CLK = '1') then
            i_int_toggle <= not i_int_toggle;
            i_int_toggle_d <= i_int_toggle;
        end if;
    end process;

    process(i_cfr_rst,CLK)
    begin
        if i_cfr_rst = '1' then
            i_init_cnt <= (others => '0');
            i_data_accept_en <= '0';
        elsif (CLK'event and CLK = '1') then
            if i_int_toggle_d = '1' then
                if i_init_cnt = "1111" then
                    i_init_cnt <= i_init_cnt;
                else
                    i_init_cnt <= i_init_cnt + 1;
                end if;
          
                if i_init_cnt = "1111" then
                    i_data_accept_en <= '1';
                else
                    i_data_accept_en <= '0';
                end if;
            end if;
        end if;
    end process;

--===============================================================================================
              
    u_calc_cpg_minmax : CALC_CPG_MINMAX_2P5
    port map(
        RESET                               => i_cfr_rst, --: in std_logic;
        CLK                                 => CLK, --: in std_logic;
        
        CFR_TAP_NUM                         => CFR_TAP_NUM, --: in std_logic_vector(9 downto 0);
        
        CPG_MIN_NUM                         => i_cpg_min_num --: out std_logic_vector(9 downto 0);      
        );

    u_inputdata_mux : INPUT_MUX_V2
    port map(
        RESET                               => i_cfr_rst, --: in  std_logic;
        CLK                                 => CLK, --: in  std_logic;
        DATA_EN                             => i_data_accept_en,  --: in std_logic;
        PATH_0_I                            => CFR_0_INPUT_I, --: in  std_logic_vector(15 downto 0);
        PATH_0_Q                            => CFR_0_INPUT_Q, --: in  std_logic_vector(15 downto 0);
        PATH_1_I                            => CFR_1_INPUT_I,  --: in  std_logic_vector(15 downto 0);
        PATH_1_Q                            => CFR_1_INPUT_Q,  --: in  std_logic_vector(15 downto 0);
        
        MUXED_I                             => i_mux_IDATA,  --: out std_logic_vector(15 downto 0);
        MUXED_Q                             => i_mux_QDATA   --: out std_logic_vector(15 downto 0)
        );
     
    u_lte_cfrstage_1st_v2 : LTE_CFR_STAGE_V2P5
    port map(
        RESET                               => i_cfr_rst,  --: in std_logic;
        CLK                                 => CLK, --: in std_logic;
        CLOCK_UNSTABLE                      => CLOCK_UNSTABLE, --: in std_logic;
        
        CFR_THRESHOLD_0                     => CFR_THRESHOLD_0, --: in std_logic_vector(15 downto 0);
        CFR_THRESHOLD_1                     => CFR_THRESHOLD_1, --: in std_logic_vector(15 downto 0);
        CFR_PEAK_SPACING_0                  => CFR_PEAK_SPACING_0, --: in std_logic_vector(7 downto 0);
        CFR_PEAK_SPACING_1                  => CFR_PEAK_SPACING_1, --: in std_logic_vector(7 downto 0);
        
        CFR_COEFF_UPDATE_EN                 => CFR_COEFF_UPDATE_EN, -- : in std_logic;
        CFR_COEFF_WE                        => CFR_COEFF_WE, --: in std_logic;
        CFR_COEFF_WRADDR                    => CFR_COEFF_WRADDR, --: in std_logic_vector(8 downto 0);
        CFR_COEFF_WRDATA                    => CFR_COEFF_WRDATA, --: in std_logic_vector(31 downto 0);
        
        MIN_NUM                             => i_cpg_min_num, --: in std_logic_vector(9 downto 0);
        
        CFR_TAP_NUM                         => CFR_TAP_NUM, --: in std_logic_vector(9 downto 0);
        
        SIG_DELAY_VALUE                     => "001010010",  --"001010001", -- until logic fixed!
        FLAG_DELAY_VALUE                    => "1000001", --: in std_logic_vector(6 downto 0);  -- until logic fixed!

        CFR_INPUT_I                         => i_mux_IDATA, --: in std_logic_vector(15 downto 0);
        CFR_INPUT_Q                         => i_mux_QDATA,  --: in std_logic_vector(15 downto 0);
        
        CFRSTAGE_OUT_I                      => i_cfr_v2_1st_i_out,  -- : out std_logic_vector(15 downto 0);
        CFRSTAGE_OUT_Q                      => i_cfr_v2_1st_q_out   -- : out std_logic_vector(15 downto 0)
    );


    u_lte_cfrstage_2nd_v2 : LTE_CFR_STAGE_V2P5
    port map(
        RESET                               => i_cfr_rst,  --: in std_logic;
        CLK                                 => CLK, --: in std_logic;
        CLOCK_UNSTABLE                      => CLOCK_UNSTABLE, --: in std_logic;
        
        CFR_THRESHOLD_0                     => CFR_THRESHOLD_0, --: in std_logic_vector(15 downto 0);
        CFR_THRESHOLD_1                     => CFR_THRESHOLD_1, --: in std_logic_vector(15 downto 0);
        CFR_PEAK_SPACING_0                  => CFR_PEAK_SPACING_0, --: in std_logic_vector(7 downto 0);
        CFR_PEAK_SPACING_1                  => CFR_PEAK_SPACING_1, --: in std_logic_vector(7 downto 0);
        
        CFR_COEFF_UPDATE_EN                 => CFR_COEFF_UPDATE_EN, -- : in std_logic;
        CFR_COEFF_WE                        => CFR_COEFF_WE, --: in std_logic;
        CFR_COEFF_WRADDR                    => CFR_COEFF_WRADDR, --: in std_logic_vector(8 downto 0);
        CFR_COEFF_WRDATA                    => CFR_COEFF_WRDATA, --: in std_logic_vector(31 downto 0);
        
        MIN_NUM                             => i_cpg_min_num, --: in std_logic_vector(9 downto 0);
        
        CFR_TAP_NUM                         => CFR_TAP_NUM, --: in std_logic_vector(9 downto 0);
        
        SIG_DELAY_VALUE                     => "001010010",  --"001010001", -- until logic fixed!
        FLAG_DELAY_VALUE                    => "1000001", --: in std_logic_vector(6 downto 0);  -- until logic fixed!

        CFR_INPUT_I                         => i_cfr_v2_1st_i_out, --: in std_logic_vector(15 downto 0);
        CFR_INPUT_Q                         => i_cfr_v2_1st_q_out,  --: in std_logic_vector(15 downto 0)
        
        CFRSTAGE_OUT_I                      => i_cfr_v2_2nd_i_out,  -- : out std_logic_vector(15 downto 0);
        CFRSTAGE_OUT_Q                      => i_cfr_v2_2nd_q_out   -- : out std_logic_vector(15 downto 0)
    );
     
      
    FRAC_GEN : if FRAC_DLY_FILTER_EN = TRUE generate     
        u_rtl_frac_v2_blk :  FRAC_DLY_FILTER_RTL_V2
        port map(
            RESET                               => i_cfr_rst,  --: in std_logic;
            CLK                                 => CLK, --: in std_logic;

            INPUT_DATA_I                        => i_cfr_v2_2nd_i_out,  --: in std_logic_vector(15 downto 0);
            INPUT_DATA_Q                        => i_cfr_v2_2nd_q_out,  --: in std_logic_vector(15 downto 0);

            OUTPUT_DATA_I                       => i_cfr_v2_frac_i_out,  --, --: out std_logic_vector(15 downto 0);
            OUTPUT_DATA_Q                       => i_cfr_v2_frac_q_out   --  --: out std_logic_vector(15 downto 0)
        );
    end generate;

    BR_SIG_GEN : if FRAC_DLY_FILTER_EN = FALSE generate
        i_cfr_v2_frac_i_out <= i_cfr_v2_2nd_i_out;
        i_cfr_v2_frac_q_out <= i_cfr_v2_2nd_q_out;
    end generate;
      
      
    u_lte_cfrstage_3rd_v2 : LTE_CFR_STAGE_V2P5
    port map(
        RESET                           => i_cfr_rst,  --: in std_logic;
        CLK                             => CLK, --: in std_logic;
        CLOCK_UNSTABLE                  => CLOCK_UNSTABLE, --: in std_logic;
        
        CFR_THRESHOLD_0                 => CFR_THRESHOLD_0, --: in std_logic_vector(15 downto 0);
        CFR_THRESHOLD_1                 => CFR_THRESHOLD_1, --: in std_logic_vector(15 downto 0);
        CFR_PEAK_SPACING_0              => CFR_PEAK_SPACING_0, --: in std_logic_vector(7 downto 0);
        CFR_PEAK_SPACING_1              => CFR_PEAK_SPACING_1, --: in std_logic_vector(7 downto 0);
        
        CFR_COEFF_UPDATE_EN             => CFR_COEFF_UPDATE_EN, -- : in std_logic;
        CFR_COEFF_WE                    => CFR_COEFF_WE, --: in std_logic;
        CFR_COEFF_WRADDR                => CFR_COEFF_WRADDR, --: in std_logic_vector(8 downto 0);
        CFR_COEFF_WRDATA                => CFR_COEFF_WRDATA, --: in std_logic_vector(31 downto 0);
        
        MIN_NUM                         => i_cpg_min_num, --: in std_logic_vector(9 downto 0);
        
        CFR_TAP_NUM                     => CFR_TAP_NUM, --: in std_logic_vector(9 downto 0);
        
        SIG_DELAY_VALUE                 => "001010010",  --"001010001", -- until logic fixed!
        FLAG_DELAY_VALUE                => "1000001", --: in std_logic_vector(6 downto 0);  -- until logic fixed!
        
        CFR_INPUT_I                     => i_cfr_v2_frac_i_out, --: in std_logic_vector(15 downto 0);
        CFR_INPUT_Q                     => i_cfr_v2_frac_q_out,  --: in std_logic_vector(15 downto 0)
        
        CFRSTAGE_OUT_I                  => i_cfr_v2_3rd_i_out,  -- : out std_logic_vector(15 downto 0);
        CFRSTAGE_OUT_Q                  => i_cfr_v2_3rd_q_out   -- : out std_logic_vector(15 downto 0)
    );


    process(i_cfr_rst,CLK)
    begin
        if i_cfr_rst = '1' then
            pim_cfr_out_i <= (others => '0');
            pim_cfr_out_q <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            pim_cfr_out_i <= i_cfr_v2_3rd_i_out;
            pim_cfr_out_q <= i_cfr_v2_3rd_q_out;
            pim_cfr_out_i_d <= pim_cfr_out_i;
            pim_cfr_out_q_d <= pim_cfr_out_q;


        end if;
    end process;


    u_pim_outmux_v2_blk : OUTPUT_DEMUX_V2
    port map(
        RESET                               => i_cfr_rst,  --: in  std_logic;
        CLK                                 => CLK, --: in  std_logic;

        MUXED_IIN                           => pim_cfr_out_i_d,  --: out std_logic_vector(15 downto 0);
        MUXED_QIN                           => pim_cfr_out_q_d,  --: out std_logic_vector(15 downto 0);
        
        PATH_0_IOUT                         => pim_demux_out_path0_I,  --: in  std_logic_vector(15 downto 0);
        PATH_0_QOUT                         => pim_demux_out_path0_Q,  --: in  std_logic_vector(15 downto 0);
        PATH_1_IOUT                         => pim_demux_out_path1_I,  --: in  std_logic_vector(15 downto 0);
        PATH_1_QOUT                         => pim_demux_out_path1_Q   --: in  std_logic_vector(15 downto 0);      
    );




    u_lte_cfrstage_4th_v2 : LTE_CFR_STAGE_V2P5
    port map(
        RESET                               => i_cfr_rst,  --: in std_logic;
        CLK                                 => CLK, --: in std_logic;
        CLOCK_UNSTABLE                      => CLOCK_UNSTABLE, --: in std_logic;
        
        CFR_THRESHOLD_0                     => CFR_THRESHOLD_0, --: in std_logic_vector(15 downto 0);
        CFR_THRESHOLD_1                     => CFR_THRESHOLD_1, --: in std_logic_vector(15 downto 0);
        CFR_PEAK_SPACING_0                  => CFR_PEAK_SPACING_0, --: in std_logic_vector(7 downto 0);
        CFR_PEAK_SPACING_1                  => CFR_PEAK_SPACING_1, --: in std_logic_vector(7 downto 0);
        
        CFR_COEFF_UPDATE_EN                 => CFR_COEFF_UPDATE_EN, -- : in std_logic;
        CFR_COEFF_WE                        => CFR_COEFF_WE, --: in std_logic;
        CFR_COEFF_WRADDR                    => CFR_COEFF_WRADDR, --: in std_logic_vector(8 downto 0);
        CFR_COEFF_WRDATA                    => CFR_COEFF_WRDATA, --: in std_logic_vector(31 downto 0);
        
        MIN_NUM                             => i_cpg_min_num, --: in std_logic_vector(9 downto 0);
        
        CFR_TAP_NUM                         => CFR_TAP_NUM, --: in std_logic_vector(9 downto 0);
        
        SIG_DELAY_VALUE                     => "001010010",  --"001010001", -- until logic fixed!
        FLAG_DELAY_VALUE                    => "1000001", --: in std_logic_vector(6 downto 0);  -- until logic fixed!

        CFR_INPUT_I                         => i_cfr_v2_3rd_i_out, --: in std_logic_vector(15 downto 0);
        CFR_INPUT_Q                         => i_cfr_v2_3rd_q_out,  --: in std_logic_vector(15 downto 0)
        
        CFRSTAGE_OUT_I                      => i_cfr_v2_4th_i_out,  -- : out std_logic_vector(15 downto 0);
        CFRSTAGE_OUT_Q                      => i_cfr_v2_4th_q_out   -- : out std_logic_vector(15 downto 0)
    );
     



--    u_LTE_CFR_SIGNAL_DELAY_BUFFER : LTE_CFR_SIGNAL_DELAY_BUFFER
--    port map(
--        RESET                                => i_cfr_rst, --: in	std_logic;
--        CLK	                                 => CLK, --: in	std_logic;
--        
--        DELAY_VALUE	                         => i_DELAY_VALUE, --:	in	std_logic_vector(9 downto 0);
--        
--        --CH_NUM                  => i_ch_num,  --: in	std_logic;
--        INPUT_I								 => i_cfr_v2_4th_i_out, --: in	std_logic_vector(15 downto 0);
--        INPUT_Q								 => i_cfr_v2_4th_q_out, --: in	std_logic_vector(15 downto 0);
--        
--        OUTPUT_I							 => i_cfr_v2_4th_i_dly_out, --: out	std_logic_vector(15 downto 0);
--        OUTPUT_Q							 => i_cfr_v2_4th_q_dly_out  --: out	std_logic_vector(15 downto 0)
--    );









    u_bypass_sel_blk : CFR_BYPASS_SEL_V2
    port map(
        RESET                               => i_cfr_rst,  --: in  std_logic;
        CLK                                 => CLK, --: in  std_logic;
        
        CFR_BYPASS                          => CFR_BYPASS, --: in  std_logic_vector(1 downto 0);
        
        --CH_NUM                              : in  std_logic;
        CFR_I_IN                            => i_mux_IDATA,  --: in  std_logic_vector(15 downto 0); -- from input mux block
        CFR_Q_IN                            => i_mux_QDATA,  --: in  std_logic_vector(15 downto 0); -- from input mux block
        
--        ITR_I_DATA                          => i_cfr_v2_4th_i_dly_out, --i_cfr_v2_4th_i_out,  --: in  std_logic_vector(15 downto 0); -- from last cfr stage block
--        ITR_Q_DATA                          => i_cfr_v2_4th_q_dly_out, --i_cfr_v2_4th_q_out,  --: in  std_logic_vector(15 downto 0); -- from last cfr stage block
        
        ITR_I_DATA                          => i_cfr_v2_4th_i_out, --i_cfr_v2_4th_i_out,  --: in  std_logic_vector(15 downto 0); -- from last cfr stage block
        ITR_Q_DATA                          => i_cfr_v2_4th_q_out, --i_cfr_v2_4th_q_out,  --: in  std_logic_vector(15 downto 0); -- from last cfr stage block
        SEL_IOUT                            => i_bypass_sel_iout,   --: out std_logic_vector(15 downto 0);
        SEL_QOUT                            => i_bypass_sel_qout    --: out std_logic_vector(15 downto 0)    
    );

    u_outmux_v2_blk : OUTPUT_DEMUX_V2
    port map(
        RESET                               => i_cfr_rst,  --: in  std_logic;
        CLK                                 => CLK, --: in  std_logic;

        MUXED_IIN                           => i_bypass_sel_iout,  --: out std_logic_vector(15 downto 0);
        MUXED_QIN                           => i_bypass_sel_qout,  --: out std_logic_vector(15 downto 0);
        
        PATH_0_IOUT                         => i_demux_out_path0_I,  --: in  std_logic_vector(15 downto 0);
        PATH_0_QOUT                         => i_demux_out_path0_Q,  --: in  std_logic_vector(15 downto 0);
        PATH_1_IOUT                         => i_demux_out_path1_I,  --: in  std_logic_vector(15 downto 0);
        PATH_1_QOUT                         => i_demux_out_path1_Q   --: in  std_logic_vector(15 downto 0);      
    );


    X2_INTP_FIL_GEN : if UPSAMPLE_MODE_EN = TRUE generate
        u_x2_intp_filter0_V2 : CFR_X2_RTL
        port map(
            RST                                 => i_cfr_rst,  --: in  std_logic;
            CLK                                 => CLK, --: in  std_logic;

            INPUT_VALID                         => i_int_toggle, --: in  std_logic;
            INPUT_DATA_I                        => i_demux_out_path0_I, --: in  std_logic_vector(15 downto 0);
            INPUT_DATA_Q                        => i_demux_out_path0_Q, --: in  std_logic_vector(15 downto 0);

            OUTPUT_VALID                        => open,  --: out std_logic;
            OUTPUT_DATA_I                       => CFR_0_OUTPUT_I, --: out std_logic_vector(15 downto 0);
            OUTPUT_DATA_Q                       => CFR_0_OUTPUT_Q  --: out std_logic_vector(15 downto 0)
        );

        u_x2_intp_filter1_V2 : CFR_X2_RTL
        port map(
            RST                                 => i_cfr_rst,  --: in  std_logic;
            CLK                                 => CLK, --: in  std_logic;
    
            INPUT_VALID                         => i_int_toggle, --: in  std_logic;
            INPUT_DATA_I                        => i_demux_out_path1_I, --: in  std_logic_vector(15 downto 0);
            INPUT_DATA_Q                        => i_demux_out_path1_Q, --: in  std_logic_vector(15 downto 0);
    
            OUTPUT_VALID                        => open,  --: out std_logic;
            OUTPUT_DATA_I                       => CFR_1_OUTPUT_I, --: out std_logic_vector(15 downto 0);
            OUTPUT_DATA_Q                       => CFR_1_OUTPUT_Q  --: out std_logic_vector(15 downto 0)
        );
    end generate;

    BR_SIG_UP_GEN : if UPSAMPLE_MODE_EN = FALSE generate
        CFR_0_OUTPUT_I <= i_demux_out_path0_I;
        CFR_0_OUTPUT_Q <= i_demux_out_path0_Q;
        CFR_1_OUTPUT_I <= i_demux_out_path1_I;
        CFR_1_OUTPUT_Q <= i_demux_out_path1_Q;
    end generate;


    PIM_CFR_0_OUTPUT_I <= pim_demux_out_path0_I;
    PIM_CFR_0_OUTPUT_Q <= pim_demux_out_path0_Q;
    PIM_CFR_1_OUTPUT_I <= pim_demux_out_path1_I;
    PIM_CFR_1_OUTPUT_Q <= pim_demux_out_path1_Q;

end arch_LTE_SEC_PC_CFR_TOP_V2P5;
