-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- incleased 2 clock latency compared to Pavel's doc.
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
library UNISIM;
use UNISIM.VComponents.all;

entity SIGNAL_DELAY_BUFFER_V2 is
   port(
   				RESET										: in	std_logic;
   				CLK											: in	std_logic;

   				DELAY_VALUE							:	in	std_logic_vector(8 downto 0);
   				
   				--CH_NUM                  : in	std_logic;
   				INPUT_I									: in	std_logic_vector(15 downto 0);
   				INPUT_Q									: in	std_logic_vector(15 downto 0);
   				
   				OUTPUT_I								: out	std_logic_vector(15 downto 0);
   				OUTPUT_Q								: out	std_logic_vector(15 downto 0)
   				
   		);
end SIGNAL_DELAY_BUFFER_V2;

architecture arc_SIGNAL_DELAY_BUFFER_V2 of SIGNAL_DELAY_BUFFER_V2 is

-- when make dpram ip core , use common clock and check "read first mode" --

-- for Xilinx Simple Dual port RAM -----------
component cfr_signal_delay_buffer_32x1024
	port (
	clka: in std_logic;
	wea: in std_logic_vector(0 downto 0);
	addra: in std_logic_vector(9 downto 0);
	dina: in std_logic_vector(31 downto 0);
	clkb: in std_logic;
	addrb: in std_logic_vector(9 downto 0);
	doutb: out std_logic_vector(31 downto 0));
end component;
----------------------------------------------

------------ Signals -------------------------
signal i_ch_num_d   : std_logic;
signal wr_en				: std_logic_vector(0 downto 0);
signal wr_addr_cnt	: std_logic_vector(8 downto 0);
signal wr_addr			: std_logic_vector(9 downto 0);
signal wr_data			: std_logic_vector(31 downto 0);

signal rd_addr			: std_logic_vector(9 downto 0);
signal rd_data   : std_logic_vector(31 downto 0);

signal i_tog            : std_logic;

begin

-- for Xilinx Simple Dual port RAM -----------
u_signal_delay_dpram : cfr_signal_delay_buffer_32x1024
	port map(
	clka		=> CLK, --: in std_logic;
	wea			=> wr_en, --: in std_logic_vector(0 downto 0);
	addra		=> wr_addr, --: in std_logic_vector(9 downto 0);
	dina		=> wr_data, --: in std_logic_vector(31 downto 0);
	clkb		=> CLK, --: in std_logic;
	addrb		=> rd_addr, --: in std_logic_vector(9 downto 0);
	doutb		=> rd_data  --: out std_logic_vector(31 downto 0)
	);
----------------------------------------------
process(RESET,CLK)
begin
   if RESET = '1' then
      i_tog <= '0';
   elsif rising_edge(CLK) then
      i_tog <= not i_tog;
   end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		i_ch_num_d <= '0';
	elsif (CLK'event and CLK='1') then
		--i_ch_num_d <= CH_NUM;
		i_ch_num_d <= i_tog;
	end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
		wr_en <= "0";
		wr_addr_cnt <= (others => '0');
		wr_data <= (others => '0');
	elsif (CLK'event and CLK='1') then
		wr_en <= "1";
		wr_data <= INPUT_I & INPUT_Q;
		if i_ch_num_d = '1' then
		  wr_addr_cnt <= wr_addr_cnt + 1;    	
		end if;
	end if;
end process;

wr_addr <= wr_addr_cnt & i_ch_num_d;

process(RESET,CLK)
begin
	if RESET = '1' then
		rd_addr <= (others => '0');
	elsif (CLK'event and CLK='1') then
		rd_addr <= (wr_addr_cnt - DELAY_VALUE) & i_ch_num_d;
	end if;
end process;

OUTPUT_I <= rd_data(31 downto 16);
OUTPUT_Q <= rd_data(15 downto 0);

end arc_SIGNAL_DELAY_BUFFER_V2;