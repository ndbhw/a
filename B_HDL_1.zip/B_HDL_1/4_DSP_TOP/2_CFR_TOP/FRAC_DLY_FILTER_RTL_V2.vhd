-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments: Hard ware oversample rate = 2, processing delay = 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

entity FRAC_DLY_FILTER_RTL_V2 is
port(
    RESET                       : in  std_logic;
    CLK                         : in  std_logic;

    INPUT_DATA_I                : in  std_logic_vector(15 downto 0);
    INPUT_DATA_Q                : in  std_logic_vector(15 downto 0);

    OUTPUT_DATA_I               : out std_logic_vector(15 downto 0);
    OUTPUT_DATA_Q               : out std_logic_vector(15 downto 0)
);
end FRAC_DLY_FILTER_RTL_V2;

architecture arc_FRAC_DLY_FILTER_RTL_V2 of FRAC_DLY_FILTER_RTL_V2 is
    
component cfr_fir_pfir is
generic(
    VENDOR                      : string := "XILINX";
    DDUC_SEL                    : integer:= 0;-- 0 : DUC, 1 : DDC
    CHANNEL_NUMBERS             : integer:= 4;

    WIDTH_IN                    : integer:= 16;
    WIDTH_OUT                   : integer:= 16;
    WIDTH_COEFF                 : integer:= 16;

    WIDTH_RESULT                : integer:= 32;
    BINARY_POINT                : integer:= 15;

    HOVS                        : integer:= 2;
    ORDER                       : integer:= 96
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    MODE                        : in  std_logic_vector(2 downto 0); 

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1  downto 0)
);
end component;

signal i_output_data_i          : std_logic_vector(15 downto 0); 
signal i_output_data_q          : std_logic_vector(15 downto 0); 

begin

    -- 1 clock delay for total 10 clock delay (filter delay 9 clock, not filter center output, just first output)
    process(RESET, CLK)
    begin
        if RESET='1' then
            OUTPUT_DATA_I <= (others=> '0');
            OUTPUT_DATA_Q <= (others=> '0');
        elsif CLK'event and CLK='1' then
            OUTPUT_DATA_I <= i_output_data_i;
            OUTPUT_DATA_Q <= i_output_data_q;
        end if;
    end process;

u_cfr_fir_pfir_i : cfr_fir_pfir
generic map(
    VENDOR                      => "XILINX"                     ,--: string := "XILINX";
    DDUC_SEL                    => 0                            ,--: integer:= 0;-- 0 : DUC, 1 : DDC
    CHANNEL_NUMBERS             => 2                            ,--: integer:= 4;

    WIDTH_IN                    => 16                           ,--: integer:= 16;
    WIDTH_OUT                   => 16                           ,--: integer:= 16;
    WIDTH_COEFF                 => 16                           ,--: integer:= 16;

    WIDTH_RESULT                => 32                           ,--: integer:= 32;
    BINARY_POINT                => 14                           ,--: integer:= 15;

    HOVS                        => 1                            ,--: integer:= 2;
    ORDER                       => 8                             --: integer:= 96
)
port map(
    RST                         => RESET                        ,--: in  std_logic;
    CLK                         => CLK                          ,--: in  std_logic;

    MODE                        => (others => '0')              ,--: in  std_logic_vector(2 downto 0); 

    FRAME_I                     => '1'                          ,--: in  std_logic;
    VALID_I                     => '1'                          ,--: in  std_logic;
    FILTER_IN                   => INPUT_DATA_I                 ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     => open                         ,--: out std_logic;
    VALID_O                     => open                         ,--: out std_logic;
    FILTER_OUT                  => i_output_data_i               --: out std_logic_vector(WIDTH_OUT-1  downto 0)
);

u_cfr_fir_pfir_q : cfr_fir_pfir
generic map(
    VENDOR                      => "XILINX"                     ,--: string := "XILINX";
    DDUC_SEL                    => 0                            ,--: integer:= 0;-- 0 : DUC, 1 : DDC
    CHANNEL_NUMBERS             => 2                            ,--: integer:= 4;

    WIDTH_IN                    => 16                           ,--: integer:= 16;
    WIDTH_OUT                   => 16                           ,--: integer:= 16;
    WIDTH_COEFF                 => 16                           ,--: integer:= 16;

    WIDTH_RESULT                => 32                           ,--: integer:= 32;
    BINARY_POINT                => 14                           ,--: integer:= 15;

    HOVS                        => 1                            ,--: integer:= 2;
    ORDER                       => 8                             --: integer:= 96
)
port map(
    RST                         => RESET                        ,--: in  std_logic;
    CLK                         => CLK                          ,--: in  std_logic;

    MODE                        => (others => '0')              ,--: in  std_logic_vector(2 downto 0); 

    FRAME_I                     => '1'                          ,--: in  std_logic;
    VALID_I                     => '1'                          ,--: in  std_logic;
    FILTER_IN                   => INPUT_DATA_Q                 ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     => open                         ,--: out std_logic;
    VALID_O                     => open                         ,--: out std_logic;
    FILTER_OUT                  => i_output_data_q               --: out std_logic_vector(WIDTH_OUT-1  downto 0)
);

end arc_FRAC_DLY_FILTER_RTL_V2;
