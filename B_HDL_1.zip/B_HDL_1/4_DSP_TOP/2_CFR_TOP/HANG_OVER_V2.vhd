-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
library UNISIM;
use UNISIM.VComponents.all;

entity HANG_OVER_V2 is

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							INPUT_FLAG				: in	std_logic;
							PEAK_SPACING_0		: in	std_logic_vector(7 downto 0);
							PEAK_SPACING_1		: in	std_logic_vector(7 downto 0);
							
							OUTPUT_FLAG				:	out	std_logic							
						);
end HANG_OVER_V2;

architecture arc_HANG_OVER_V2 of HANG_OVER_V2 is

signal cnt_rst				: std_logic;
signal cnt_hang_0 		: std_logic_vector(7 downto 0);
signal cnt_hang_1 		: std_logic_vector(7 downto 0);
signal i_input_flag_d : std_logic_vector(1 downto 0);
signal below_peak_space_0	: std_logic;
signal below_peak_space_1	: std_logic;
signal i_output_flag_0 : std_logic;
signal i_output_flag_1 : std_logic;

signal i_tog,i_tog_d   : std_logic;

begin

cnt_rst <= not INPUT_FLAG;

process(RESET,CLK)
begin
   if RESET = '1' then
      i_tog <= '0';
      i_tog_d <= '0';
   elsif rising_edge(CLK) then
      i_tog <= not i_tog;
      i_tog_d <= i_tog;
   end if;
end process;

process(RESET,CLK)
begin
   if RESET = '1' then
      i_input_flag_d <= "11";
   elsif rising_edge(CLK) then
      i_input_flag_d <= i_input_flag_d(0) & INPUT_FLAG;
   end if;
end process;

process(RESET,CLK)
begin
	if RESET = '1' then
	  cnt_hang_0 <= (others => '0');
	  cnt_hang_1 <= (others => '0');
	elsif (CLK'event and CLK='1') then
	  if cnt_rst = '1' then
	     if i_tog_d = '1' then
          cnt_hang_1 <= (others => '0');
       else
          cnt_hang_0 <= (others => '0');
       end if;
	  else
	     if i_tog_d = '1' then
	        if PEAK_SPACING_1 > cnt_hang_1 then
	           cnt_hang_1 <= cnt_hang_1 + 1;
	        end if;
	     else
	        if PEAK_SPACING_0 > cnt_hang_0 then
	           cnt_hang_0 <= cnt_hang_0 + 1;
	        end if;
	     end if;
		end if;
	end if;
end process;

-- PEAK_SPACING MUX : ch.0 => path0 peal spacing value , ch.1 => path1 peal spacing value
process(RESET,CLK)
begin
	if RESET = '1' then
		below_peak_space_0 <= '1';
		below_peak_space_1 <= '1';
	elsif (CLK'event and CLK='1') then
	  if i_tog_d = '1' then
		   if PEAK_SPACING_0 > cnt_hang_0 then
		    	below_peak_space_0 <= '1';
		   else
			   below_peak_space_0 <= '0';
		   end if;
		else
		   if PEAK_SPACING_1 > cnt_hang_1 then
		    	below_peak_space_1 <= '1';
		   else
			   below_peak_space_1 <= '0';
		   end if;
		end if;
	end if;
end process;

process(RESET,CLK)
begin
   if RESET = '1' then
      i_output_flag_0 <= '1';
      i_output_flag_1 <= '1';
   elsif rising_edge(CLK) then
      if i_tog = '1' then
         i_output_flag_0 <= (not below_peak_space_0) and INPUT_FLAG;
      else
         i_output_flag_1 <= (not below_peak_space_1) and INPUT_FLAG;
      end if;
   end if;
end process;

process(RESET,CLK)
begin
   if RESET = '1' then
      OUTPUT_FLAG <= '1';
   elsif rising_edge(CLK) then
      if i_tog = '1' then
         OUTPUT_FLAG <= i_output_flag_1;
      else
         OUTPUT_FLAG <= i_output_flag_0;
      end if;
   end if;
end process;

end arc_HANG_OVER_V2;