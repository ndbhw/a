-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

entity CALC_THRES2_V2 is
   port(
   	
   			RESET											: in	std_logic;
   			CLK												: in	std_logic;
   			
   			--CH_NUM                    : in  std_logic;                      -- '0' : path#0 , '1' : path#1
   			CFR_THRESHOLD_P0					: in	std_logic_vector(15 downto 0);  -- Path #0 threshold
   			CFR_THRESHOLD_P1					: in	std_logic_vector(15 downto 0);  -- Path #1 threshold
   			
   			CFR_THRESHOLD2						:	out	std_logic_vector(16 downto 0)   -- Muxed threshold value
   			);
end CALC_THRES2_V2;

architecture arc_CALC_THRES2_V2 of CALC_THRES2_V2 is

	signal i_tog            : std_logic;
	signal cfr_thres_org_0	: std_logic_vector(16 downto 0);
	signal cfr_thres_org_1	: std_logic_vector(16 downto 0);
	signal cfr_thres_0_msb8	: std_logic_vector(16 downto 0);
	signal cfr_thres_1_msb8	: std_logic_vector(16 downto 0);
	signal cfr_thres_scale	: std_logic_vector(16 downto 0);
	
begin

	cfr_thres_org_0 <= '0' & CFR_THRESHOLD_P0;
	cfr_thres_0_msb8 <= "000000000" & CFR_THRESHOLD_P0(15 downto 8);
	
	cfr_thres_org_1 <= '0' & CFR_THRESHOLD_P1;
	cfr_thres_1_msb8 <= "000000000" & CFR_THRESHOLD_P1(15 downto 8);
	
	CFR_THRESHOLD2 <= cfr_thres_scale;
	
process(RESET,CLK)
begin
  if RESET = '1' then
     i_tog <= '0';
  elsif rising_edge(CLK) then
     i_tog <= not i_tog;
  end if;
end process;
	
	process(RESET,CLK)
	begin
		if RESET = '1' then
			cfr_thres_scale <= (others => '1');
		elsif(CLK'event and CLK='1') then
			--if CH_NUM = '1' then
			if i_tog = '1' then
			   cfr_thres_scale <= cfr_thres_org_1 + cfr_thres_1_msb8;
			else
			   cfr_thres_scale <= cfr_thres_org_0 + cfr_thres_0_msb8;
			end if;
		end if;
	end process;

end arc_CALC_THRES2_V2;