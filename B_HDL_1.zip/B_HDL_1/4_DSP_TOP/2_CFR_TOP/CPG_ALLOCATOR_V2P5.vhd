-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity CPG_ALLOCATOR_V2P5 is

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							TAPS_NUMBER				: in	std_logic_vector(9 downto 0);
							MIN_NUMBER				: in	std_logic_vector(9 downto 0);
							
							--CH_NUM            : in  std_logic;
							
							--INPUT_TOGGLE : in std_logic;
							PEAK_I						: in	std_logic_vector(15 downto 0);
							PEAK_Q						: in	std_logic_vector(15 downto 0);
							
							PEAK_INDICATOR		: in	std_logic;
							PEAK_MAGNITUDE		: in	std_logic_vector(15 downto 0);
							
							CPG_0_ADDR				: out	std_logic_vector(9 downto 0);
							CPG_1_ADDR				: out	std_logic_vector(9 downto 0);
							CPG_2_ADDR				: out	std_logic_vector(9 downto 0);
							CPG_3_ADDR				: out	std_logic_vector(9 downto 0);
							
							ADDR_DIR_0        : out std_logic;
							ADDR_DIR_1        : out std_logic;
							ADDR_DIR_2        : out std_logic;
							ADDR_DIR_3        : out std_logic;
							
							CPG_0_PEAK_I			: out	std_logic_vector(15 downto 0);
							CPG_1_PEAK_I			: out	std_logic_vector(15 downto 0);
							CPG_2_PEAK_I			: out	std_logic_vector(15 downto 0);
							CPG_3_PEAK_I			: out	std_logic_vector(15 downto 0);
							
							CPG_0_PEAK_Q			: out	std_logic_vector(15 downto 0);
							CPG_1_PEAK_Q			: out	std_logic_vector(15 downto 0);
							CPG_2_PEAK_Q			: out	std_logic_vector(15 downto 0);
							CPG_3_PEAK_Q			: out	std_logic_vector(15 downto 0)

						);
end CPG_ALLOCATOR_V2P5;

architecture arc_CPG_ALLOCATOR_V2P5 of CPG_ALLOCATOR_V2P5 is

component CPG_COUNTER_V2P5

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM            : in  std_logic;
							TRIG_ALLOCATION		: in	std_logic;
							TAPS_NUMBER				: in	std_logic_vector(9 downto 0);
							MIN_NUMBER				: in	std_logic_vector(9 downto 0);
							
							ADDR_DIR          : out std_logic;
							CURRENT_ADDR			: out	std_logic_vector(9 downto 0);
							ALLOC_FLAG				: out	std_logic;
							INTERRUPT_FLAG		: out	std_logic
						);
end component;

component CPG_TRIG_V2P5_0

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM            : in  std_logic;
							PEAK_I						: in	std_logic_vector(15 downto 0);
							PEAK_Q						: in	std_logic_vector(15 downto 0);
							PEAK_MAG					: in	std_logic_vector(15 downto 0);
							
							INTERRUPT_FLAG_CPG_0	: in	std_logic;
							ALL_BUSY							: in	std_logic;
							ALLOCATION_FLAG_CPG_0	: in	std_logic;
							PEAK_INDICATOR				: in	std_logic;
							
							CPG_0_PEAK_I			: out	std_logic_vector(15 downto 0);
							CPG_0_PEAK_Q			: out	std_logic_vector(15 downto 0);
							
							CPG_0_CAN_INTRT		: out	std_logic;
							TRIG_ALLOC_CPG_0	: out	std_logic

						);
end component;

component CPG_TRIG_V2P5_1

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM            : in  std_logic;
							PEAK_I						: in	std_logic_vector(15 downto 0);
							PEAK_Q						: in	std_logic_vector(15 downto 0);
							PEAK_MAG					: in	std_logic_vector(15 downto 0);
							
							INTERRUPT_FLAG_CPG_1	: in	std_logic;
							ALL_BUSY							: in	std_logic;
							CPG_0_CAN_INTRT				: in	std_logic;
							ALLOCATION_FLAG_CPG_0	: in	std_logic;
							ALLOCATION_FLAG_CPG_1	: in	std_logic;
							PEAK_INDICATOR				: in	std_logic;
							
							CPG_1_PEAK_I			: out	std_logic_vector(15 downto 0);
							CPG_1_PEAK_Q			: out	std_logic_vector(15 downto 0);
							
							CPG_1_CAN_INTRT		: out	std_logic;
							TRIG_ALLOC_CPG_1	: out	std_logic

						);
end component;

component CPG_TRIG_V2P5_2

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM            : in  std_logic;
							PEAK_I						: in	std_logic_vector(15 downto 0);
							PEAK_Q						: in	std_logic_vector(15 downto 0);
							PEAK_MAG					: in	std_logic_vector(15 downto 0);
							
							INTERRUPT_FLAG_CPG_2	: in	std_logic;
							ALL_BUSY							: in	std_logic;
							CPG_0_CAN_INTRT				: in	std_logic;
							CPG_1_CAN_INTRT				: in	std_logic;
							ALLOCATION_FLAG_CPG_0	: in	std_logic;
							ALLOCATION_FLAG_CPG_1	: in	std_logic;
							ALLOCATION_FLAG_CPG_2	: in	std_logic;
							PEAK_INDICATOR				: in	std_logic;
							
							CPG_2_PEAK_I			: out	std_logic_vector(15 downto 0);
							CPG_2_PEAK_Q			: out	std_logic_vector(15 downto 0);
							
							CPG_2_CAN_INTRT		: out	std_logic;
							TRIG_ALLOC_CPG_2	: out	std_logic

						);
end component;

component CPG_TRIG_V2P5_3

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							--CH_NUM            : in  std_logic;
							PEAK_I						: in	std_logic_vector(15 downto 0);
							PEAK_Q						: in	std_logic_vector(15 downto 0);
							PEAK_MAG					: in	std_logic_vector(15 downto 0);
							
							INTERRUPT_FLAG_CPG_3	: in	std_logic;
							ALL_BUSY							: in	std_logic;
							CPG_0_CAN_INTRT				: in	std_logic;
							CPG_1_CAN_INTRT				: in	std_logic;
							CPG_2_CAN_INTRT				: in	std_logic;
							ALLOCATION_FLAG_CPG_0	: in	std_logic;
							ALLOCATION_FLAG_CPG_1	: in	std_logic;
							ALLOCATION_FLAG_CPG_2	: in	std_logic;
							ALLOCATION_FLAG_CPG_3	: in	std_logic;
							PEAK_INDICATOR				: in	std_logic;
							
							CPG_3_PEAK_I			: out	std_logic_vector(15 downto 0);
							CPG_3_PEAK_Q			: out	std_logic_vector(15 downto 0);
							
							TRIG_ALLOC_CPG_3	: out	std_logic

						);
end component;

signal i_cpg0_trig, i_cpg1_trig, i_cpg2_trig, i_cpg3_trig		: std_logic;
signal i_cpg0_alloc, i_cpg1_alloc, i_cpg2_alloc, i_cpg3_alloc : std_logic;
signal i_cpg0_inter, i_cpg1_inter, i_cpg2_inter, i_cpg3_inter : std_logic;
signal i_all_busy	: std_logic;
signal i_cpg0_can, i_cpg1_can, i_cpg2_can	: std_logic;

begin

process(RESET,CLK)
begin
  if RESET = '1' then
    i_all_busy <= '0';
  elsif (CLK'event and CLK='1') then
    i_all_busy <= i_cpg0_alloc and i_cpg1_alloc and i_cpg2_alloc and i_cpg3_alloc;
  end if;
end process;

u_cpg0_cnt_blk : CPG_COUNTER_V2P5
			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK,  --: in	std_logic;
							
							--CH_NUM            => CH_NUM, --: in  std_logic;
							TRIG_ALLOCATION		=> i_cpg0_trig, --: in	std_logic;
							TAPS_NUMBER				=> TAPS_NUMBER, --: in	std_logic_vector(9 downto 0);
							MIN_NUMBER				=> MIN_NUMBER, --: in	std_logic_vector(9 downto 0);
							
              ADDR_DIR          => ADDR_DIR_0,  --: out std_logic;
							CURRENT_ADDR			=> CPG_0_ADDR, --: out	std_logic_vector(8 downto 0);
							ALLOC_FLAG				=> i_cpg0_alloc, --: out	std_logic;
							INTERRUPT_FLAG		=> i_cpg0_inter  --: out	std_logic
						);
						
u_cpg1_cnt_blk : CPG_COUNTER_V2P5
			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK,  --: in	std_logic;
							
							--CH_NUM            => CH_NUM, --: in  std_logic;
							TRIG_ALLOCATION		=> i_cpg1_trig, --: in	std_logic;
							TAPS_NUMBER				=> TAPS_NUMBER, --: in	std_logic_vector(9 downto 0);
							MIN_NUMBER				=> MIN_NUMBER, --: in	std_logic_vector(9 downto 0);
							
							ADDR_DIR          => ADDR_DIR_1,  --: out std_logic;
							CURRENT_ADDR			=> CPG_1_ADDR, --: out	std_logic_vector(8 downto 0);
							ALLOC_FLAG				=> i_cpg1_alloc, --: out	std_logic;
							INTERRUPT_FLAG		=> i_cpg1_inter  --: out	std_logic
						);

u_cpg2_cnt_blk : CPG_COUNTER_V2P5
			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK,  --: in	std_logic;
							
							--CH_NUM            => CH_NUM, --: in  std_logic;
							TRIG_ALLOCATION		=> i_cpg2_trig, --: in	std_logic;
							TAPS_NUMBER				=> TAPS_NUMBER, --: in	std_logic_vector(9 downto 0);
							MIN_NUMBER				=> MIN_NUMBER, --: in	std_logic_vector(9 downto 0);
							
							ADDR_DIR          => ADDR_DIR_2,  --: out std_logic;
							CURRENT_ADDR			=> CPG_2_ADDR, --: out	std_logic_vector(8 downto 0);
							ALLOC_FLAG				=> i_cpg2_alloc, --: out	std_logic;
							INTERRUPT_FLAG		=> i_cpg2_inter  --: out	std_logic
						);
						
u_cpg3_cnt_blk : CPG_COUNTER_V2P5
			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK,  --: in	std_logic;
							
							--CH_NUM            => CH_NUM, --: in  std_logic;
							TRIG_ALLOCATION		=> i_cpg3_trig, --: in	std_logic;
							TAPS_NUMBER				=> TAPS_NUMBER, --: in	std_logic_vector(9 downto 0);
							MIN_NUMBER				=> MIN_NUMBER, --: in	std_logic_vector(9 downto 0);
							
							ADDR_DIR          => ADDR_DIR_3,  --: out std_logic;
							CURRENT_ADDR			=> CPG_3_ADDR, --: out	std_logic_vector(8 downto 0);
							ALLOC_FLAG				=> i_cpg3_alloc, --: out	std_logic;
							INTERRUPT_FLAG		=> i_cpg3_inter  --: out	std_logic
						);
						
u_cpg_trig0_blk : CPG_TRIG_V2P5_0

			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK,  --: in	std_logic;
							
							--CH_NUM            => CH_NUM, --: in  std_logic;
							PEAK_I						=> PEAK_I, --: in	std_logic_vector(15 downto 0);
							PEAK_Q						=> PEAK_Q, --: in	std_logic_vector(15 downto 0);
							PEAK_MAG					=> PEAK_MAGNITUDE, --: in	std_logic_vector(15 downto 0);
							
							INTERRUPT_FLAG_CPG_0	=> i_cpg0_inter, --: in	std_logic;
							ALL_BUSY							=> i_all_busy, --: in	std_logic;
							ALLOCATION_FLAG_CPG_0	=> i_cpg0_alloc, --: in	std_logic;
							PEAK_INDICATOR				=> PEAK_INDICATOR, --: in	std_logic;
							
							CPG_0_PEAK_I			=> CPG_0_PEAK_I, --: out	std_logic_vector(15 downto 0);
							CPG_0_PEAK_Q			=> CPG_0_PEAK_Q, --: out	std_logic_vector(15 downto 0);
							
							CPG_0_CAN_INTRT		=> i_cpg0_can, --: out	std_logic;
							TRIG_ALLOC_CPG_0	=> i_cpg0_trig --: out	std_logic

						);

u_cpg_trig1_blk :  CPG_TRIG_V2P5_1

			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK,  --: in	std_logic;
							
							--CH_NUM            => CH_NUM, --: in  std_logic;
							PEAK_I						=> PEAK_I, --: in	std_logic_vector(15 downto 0);
							PEAK_Q						=> PEAK_Q, --: in	std_logic_vector(15 downto 0);
							PEAK_MAG					=> PEAK_MAGNITUDE, --: in	std_logic_vector(15 downto 0);
							
							INTERRUPT_FLAG_CPG_1	=> i_cpg1_inter, --: in	std_logic;
							ALL_BUSY							=> i_all_busy, --: in	std_logic;
							CPG_0_CAN_INTRT				=> i_cpg0_can, --: in	std_logic;
							ALLOCATION_FLAG_CPG_0	=> i_cpg0_alloc, --: in	std_logic;
							ALLOCATION_FLAG_CPG_1	=> i_cpg1_alloc, --: in	std_logic;
							PEAK_INDICATOR				=> PEAK_INDICATOR, --: in	std_logic;
							
							CPG_1_PEAK_I			=> CPG_1_PEAK_I, --: out	std_logic_vector(15 downto 0);
							CPG_1_PEAK_Q			=> CPG_1_PEAK_Q, --: out	std_logic_vector(15 downto 0);
							
							CPG_1_CAN_INTRT		=> i_cpg1_can, --: out	std_logic;
							TRIG_ALLOC_CPG_1	=> i_cpg1_trig --: out	std_logic

						);

u_cpg_trig2_blk :  CPG_TRIG_V2P5_2

			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK,  --: in	std_logic;
							
							--CH_NUM            => CH_NUM, --: in  std_logic;
							PEAK_I						=> PEAK_I, --: in	std_logic_vector(15 downto 0);
							PEAK_Q						=> PEAK_Q, --: in	std_logic_vector(15 downto 0);
							PEAK_MAG					=> PEAK_MAGNITUDE, --: in	std_logic_vector(15 downto 0);
							
							INTERRUPT_FLAG_CPG_2	=> i_cpg2_inter, --: in	std_logic;
							ALL_BUSY							=> i_all_busy, --: in	std_logic;
							CPG_0_CAN_INTRT				=> i_cpg0_can, --: in	std_logic;
							CPG_1_CAN_INTRT				=> i_cpg1_can, --: in	std_logic;
							ALLOCATION_FLAG_CPG_0	=> i_cpg0_alloc, --: in	std_logic;
							ALLOCATION_FLAG_CPG_1	=> i_cpg1_alloc, --: in	std_logic;
							ALLOCATION_FLAG_CPG_2	=> i_cpg2_alloc, --: in	std_logic;
							PEAK_INDICATOR				=> PEAK_INDICATOR, --: in	std_logic;
							
							CPG_2_PEAK_I			=> CPG_2_PEAK_I, --: out	std_logic_vector(15 downto 0);
							CPG_2_PEAK_Q			=> CPG_2_PEAK_Q, --: out	std_logic_vector(15 downto 0);
							
							CPG_2_CAN_INTRT		=> i_cpg2_can, --: out	std_logic;
							TRIG_ALLOC_CPG_2	=> i_cpg2_trig --: out	std_logic

						);

u_cpg_trig3_blk :  CPG_TRIG_V2P5_3

			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK,  --: in	std_logic;
							
							--CH_NUM            => CH_NUM, --: in  std_logic;
							PEAK_I						=> PEAK_I, --: in	std_logic_vector(15 downto 0);
							PEAK_Q						=> PEAK_Q, --: in	std_logic_vector(15 downto 0);
							PEAK_MAG					=> PEAK_MAGNITUDE, --: in	std_logic_vector(15 downto 0);
							
							INTERRUPT_FLAG_CPG_3	=> i_cpg3_inter, --: in	std_logic;
							ALL_BUSY							=> i_all_busy, --: in	std_logic;
							CPG_0_CAN_INTRT				=> i_cpg0_can, --: in	std_logic;
							CPG_1_CAN_INTRT				=> i_cpg1_can, --: in	std_logic;
							CPG_2_CAN_INTRT				=> i_cpg2_can, --: in	std_logic;
							ALLOCATION_FLAG_CPG_0	=> i_cpg0_alloc, --: in	std_logic;
							ALLOCATION_FLAG_CPG_1	=> i_cpg1_alloc, --: in	std_logic;
							ALLOCATION_FLAG_CPG_2	=> i_cpg2_alloc, --: in	std_logic;
							ALLOCATION_FLAG_CPG_3	=> i_cpg3_alloc, --: in	std_logic;
							PEAK_INDICATOR				=> PEAK_INDICATOR, --: in	std_logic;
							
							CPG_3_PEAK_I			=> CPG_3_PEAK_I, --: out	std_logic_vector(15 downto 0);
							CPG_3_PEAK_Q			=> CPG_3_PEAK_Q, --: out	std_logic_vector(15 downto 0);
							
							TRIG_ALLOC_CPG_3	=> i_cpg3_trig --: out	std_logic

						);


end arc_CPG_ALLOCATOR_V2P5;
