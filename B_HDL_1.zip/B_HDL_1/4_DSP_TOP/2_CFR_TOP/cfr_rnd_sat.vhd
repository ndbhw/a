------------------------------------------------------------------
-- round stage
------------------------------------------------------------------
-- 2013.11.01, vyacheslav : 1st release, system verilog
-- 2014.01.29, wj311.kim  : convert system_verilog to vhdl
-- 2014.06.15, wj311.kim  : Ver.2, processing delay is 3 CLK(fixed)
------------------------------------------------------------------
-----------------------------------------------------------------------------
--Fixed Round stage with one input and one ouput bus
--VAR_WIDTH         - width of bit shift value for variable gain control
--FIXED_GAIN        - whether gain fixed or not
--WIDTH_IN          - input data width
--WIDTH_OUT         - output data width
--BINARY_POINT      - position of binary point
--ROUNDING          - "FULL_PRECISION","TRUNCATE","ROUND_INF", "ROUND_EVEN"
--OVERFLOW          - "WRAP", "SATURATE"
-----------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_CONFIG.all;
use work.RU_FPGA_FNC.all;

entity cfr_rnd_sat is
generic(
    VAR_WIDTH                   : natural:= 5;
    FIXED_GAIN                  : natural:= 0;         --gain is fixed or not
    WIDTH_IN                    : natural:= 64;
    WIDTH_OUT                   : natural:= 32;
    BINARY_POINT                : natural:= 31;        -- DATA OUT = ROUNDING(DATA IN)/2^(BINARY_POINT+1) 
    ROUNDING                    : string:= "ROUND_INF";--"FULL_PRECISION", "TRUNCATE","ROUND_INF", "ROUND_EVEN"
    OVERFLOW                    : string:= "SATURATE"  --"WRAP or "SATURATE"
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    BIT_SHIFT_VALUE             : in  std_logic_vector(VAR_WIDTH-1 downto 0);

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1 downto 0)
);
end cfr_rnd_sat;

architecture Behavioral of cfr_rnd_sat is
-- it is used only for simulation
--and should not include for synthesys or PnR!
component log
generic(
    CHANNEL_WIDTH               :  natural:= 3;
    WIDTH_IN                    : natural:= 64;
    WIDTH_OUT                   : natural:= 32;
    WIDTH_IN_CARRY_SHIFTED      : natural:= 15;
    MAXIMUM                     : integer:= 7;
    MINIMUM                     : integer:=-8
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    frame_i                     : in  std_logic;
    valid_i                     : in  std_logic;
    filter_in                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    filter_in_w_carry_shifted   : in  std_logic_vector(WIDTH_IN_CARRY_SHIFTED-1 downto 0);

    frame_o                     : in std_logic;
    valid_o                     : in std_logic;
    filter_out                  : in std_logic_vector(WIDTH_OUT-1 downto 0)
);
end component;

constant OFFSET_PLUS            : std_logic_vector(WIDTH_IN downto 0):=std_logic_vector(to_unsigned(2**(BINARY_POINT),  WIDTH_IN+1));-- +0.5
constant OFFSET_MINUS           : std_logic_vector(WIDTH_IN downto 0):=std_logic_vector(to_unsigned(2**(BINARY_POINT)-1,WIDTH_IN+1));-- +0.4999..

constant ALL_ZERO               : std_logic_vector(WIDTH_IN-BINARY_POINT-WIDTH_OUT-1 downto 0) := (others => '0'); 
constant ALL_ONE                : std_logic_vector(WIDTH_IN-BINARY_POINT-WIDTH_OUT-1 downto 0) := (others => '1'); 
constant ZERO_OUT               : std_logic_vector(WIDTH_OUT-2 downto 0) := (others => '0'); 
constant ONE_OUT                : std_logic_vector(WIDTH_OUT-2 downto 0) := (others => '1'); 

signal filter_in_d              : std_logic_vector(WIDTH_IN-1 downto 0);
signal filter_in_ext            : std_logic_vector(WIDTH_IN downto 0);
signal sign_ext                 : std_logic;
signal filter_in_rounded        : std_logic_vector(WIDTH_IN downto 0);
signal sign_truncated           : std_logic;
signal filter_in_truncated      : std_logic_vector(WIDTH_IN-BINARY_POINT-1 downto 0);

signal frame_o_d                : std_logic_vector(2 downto 0); 
signal valid_o_d                : std_logic_vector(2 downto 0); 

signal filter_out_r             : std_logic_vector(WIDTH_OUT-1 downto 0);


begin

    -- Input data latch
    sign_ext        <= filter_in_d(WIDTH_IN-1);
    filter_in_ext   <= filter_in_d(WIDTH_IN-1) & filter_in_d;-- sign extension for rounding
    process(CLK, RST)
    begin
        if RST = '1' then
            filter_in_d <= (others => '0');
        elsif rising_edge(CLK) then
            if FIXED_GAIN = 1 then
                filter_in_d <= FILTER_IN;
            else
                filter_in_d <= asl(FILTER_IN,to_integer(unsigned(BIT_SHIFT_VALUE)));
            end if;
        end if;
    end process;

    -- rounding up
    sign_truncated        <= filter_in_rounded(WIDTH_IN);
    filter_in_truncated   <= filter_in_rounded(WIDTH_IN downto BINARY_POINT + 1);-- binary point truncation 
    process(CLK, RST)
    begin
        if RST = '1' then
            filter_in_rounded <= (others => '0'); 
        elsif rising_edge(CLK) then
            filter_in_rounded <= filter_in_ext + OFFSET_PLUS;     -- Positive case, Input data + 0.5
        end if;
    end process;

    -- Symmetric rounding
--    sign_truncated        <= filter_in_rounded(WIDTH_IN);
--    filter_in_truncated   <= filter_in_rounded(WIDTH_IN downto BINARY_POINT + 1);-- binary point truncation 
--    process(CLK, RST)
--    begin
--        if RST = '1' then
--            filter_in_rounded <= (others => '0'); 
--        elsif rising_edge(CLK) then
--            if sign_ext = '0' then 
--                filter_in_rounded <= filter_in_ext + OFFSET_PLUS;     -- Positive case, Input data + 0.5
--            else
--                filter_in_rounded <= filter_in_ext + OFFSET_MINUS;    -- Negative case, Input data + 0.4999....
--            end if;
--        end if;
--    end process;

    -- Output data with overflow operation, wrap around or saturation
    FILTER_OUT<= filter_out_r;
    process(CLK, RST)
    begin
        if RST = '1' then
            filter_out_r <= (others => '0');
        elsif rising_edge(CLK) then
            -- Wrap around mode (OVERFLOW = "WRAP")
            if OVERFLOW = "WRAP" then
                filter_out_r <= filter_in_truncated(WIDTH_OUT-1 downto 0);
            -- Saturation  mode (OVERFLOW = "SATURATE")
            else
                -- positive case ---------------------------------
                if sign_truncated = '0' then
                    -- bypass, if filter_in_truncated <= 2^(WIDTH_OUT-1)-1 (Postive Maximum Value)
                    if filter_in_truncated(WIDTH_IN-BINARY_POINT-2 downto WIDTH_OUT-1) = ALL_ZERO then  
                        filter_out_r <= '0' & filter_in_truncated(WIDTH_OUT-2 downto 0);
                    -- positive saturation
                    else                                                                               
                        filter_out_r <= '0' & ONE_OUT;                                                  
                    end if;
                -- negative case ---------------------------------
                else
                    -- bypass, if filter_in_truncated >= -2^(WIDTH_OUT-1) (Negative Minimum Value)
                    if filter_in_truncated(WIDTH_IN-BINARY_POINT-2 downto WIDTH_OUT-1) = ALL_ONE then   
                        filter_out_r <= '1' & filter_in_truncated(WIDTH_OUT-2 downto 0);
                    -- negative saturation
                    else                                                                                
                        filter_out_r <= '1' & ZERO_OUT;
                    end if;
                end if;
            end if;
        end if;
    end process;

    -- Output data with saturation/wrap around
    VALID_O   <= valid_o_d(2);
    FRAME_O   <= frame_o_d(2);
    process(CLK, RST)
    begin
        if RST = '1' then
            frame_o_d <= (others => '0'); 
            valid_o_d <= (others => '0'); 
        elsif rising_edge(CLK) then
            -- 3 CLK delay for valid/channel
            frame_o_d <= frame_o_d(1 downto 0) & FRAME_I;
            valid_o_d <= valid_o_d(1 downto 0) & VALID_I;
        end if;
    end process;

--synthesis translate_off
--log_ins: log
--generic map(
--    CHANNEL_WIDTH               => CHANNEL_WIDTH            ,
--    WIDTH_IN                    => WIDTH_IN                 ,
--    WIDTH_OUT                   => WIDTH_OUT                ,
--    WIDTH_IN_CARRY_SHIFTED      => WIDTH_IN-BINARY_POINT    ,
--    MAXIMUM                     => 2**(WIDTH_OUT-1)-1       ,--(Postive  Maximum Value)
--    MINIMUM                     => -2**(WIDTH_OUT-1)         --(Negative Minimum Value)
--)
--port map(
--    RST                         => RST                      ,--: in  std_logic;
--    CLK                         => CLK                      ,--: in  std_logic;
--    frame_i                     => frame_i                  ,--: in  std_logic;
--    valid_i                     => valid_i                  ,--: in  std_logic;
--    filter_in                   => filter_in                ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
--    filter_in_w_carry_shifted   => filter_in_truncated      ,
--
--    frame_o                     => frame_o_r                ,--: in std_logic;
--    valid_o                     => valid_o_r                ,--: in std_logic;
--    filter_out                  => filter_out_r              --: in std_logic_vector(WIDTH_OUT-1 downto 0)
--);
--synthesis translate_on

end Behavioral;
