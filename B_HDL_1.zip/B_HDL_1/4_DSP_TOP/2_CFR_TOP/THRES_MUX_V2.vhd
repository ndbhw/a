-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity THRES_MUX_V2 is

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							THRESHOLD_0				: in	std_logic_vector(15 downto 0);
							THRESHOLD_1				: in	std_logic_vector(15 downto 0);
							--CH_NUM            :	in	std_logic;

							MUX_THRES					: out	std_logic_vector(15 downto 0)
							
						);
end THRES_MUX_V2;

architecture arc_THRES_MUX_V2 of THRES_MUX_V2 is

signal i_tog            : std_logic;

begin

process(RESET,CLK)
begin
   if RESET = '1' then
      i_tog <= '0';
   elsif rising_edge(CLK) then
      i_tog <= not i_tog;
   end if;
end process;

process(RESET,CLK)
begin
   if RESET = '1' then
      MUX_THRES <= (others => '1');
   elsif (CLK'event and CLK='1') then
      --if CH_NUM = '1' then
      if i_tog = '1' then
         MUX_THRES <= THRESHOLD_0;
      else
         MUX_THRES <= THRESHOLD_1;
      end if;
   end if;
end process;

end arc_THRES_MUX_V2;