-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity LTE_CPG_PROCESSOR_V2P5 is

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							--CH_NUM    				: in	std_logic;
							CLOCK_UNSTABLE		: in	std_logic;
							
							TAPS_NUMBER				: in	std_logic_vector(9 downto 0);
							MIN_NUMBER				: in	std_logic_vector(9 downto 0);
							
							PEAK_I						: in	std_logic_vector(15 downto 0);
							PEAK_Q						: in	std_logic_vector(15 downto 0);
							
							PEAK_INDICATOR		: in	std_logic;
							PEAK_MAGNITUDE		: in	std_logic_vector(15 downto 0);
							
							CFR_COEFF_UPDATE_EN			: in	std_logic;
							COEFF_WE					: in	std_logic;
							COEFF_WADDR				: in	std_logic_vector(9 downto 0);
							COEFF_DATA				: in	std_logic_vector(31 downto 0);
							
							CP_I							: out	std_logic_vector(17 downto 0);
							CP_Q							: out	std_logic_vector(17 downto 0)

						);
end LTE_CPG_PROCESSOR_V2P5;

architecture arc_LTE_CPG_PROCESSOR_V2P5 of LTE_CPG_PROCESSOR_V2P5 is

component CPG_ALLOCATOR_V2P5
			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							
							TAPS_NUMBER				: in	std_logic_vector(9 downto 0);
							MIN_NUMBER				: in	std_logic_vector(9 downto 0);
							
							--CH_NUM            : in  std_logic;
							
							--INPUT_TOGGLE : in std_logic;
							PEAK_I						: in	std_logic_vector(15 downto 0);
							PEAK_Q						: in	std_logic_vector(15 downto 0);
							
							PEAK_INDICATOR		: in	std_logic;
							PEAK_MAGNITUDE		: in	std_logic_vector(15 downto 0);
							
							CPG_0_ADDR				: out	std_logic_vector(9 downto 0);
							CPG_1_ADDR				: out	std_logic_vector(9 downto 0);
							CPG_2_ADDR				: out	std_logic_vector(9 downto 0);
							CPG_3_ADDR				: out	std_logic_vector(9 downto 0);
							
							ADDR_DIR_0        : out std_logic;
							ADDR_DIR_1        : out std_logic;
							ADDR_DIR_2        : out std_logic;
							ADDR_DIR_3        : out std_logic;
							
							CPG_0_PEAK_I			: out	std_logic_vector(15 downto 0);
							CPG_1_PEAK_I			: out	std_logic_vector(15 downto 0);
							CPG_2_PEAK_I			: out	std_logic_vector(15 downto 0);
							CPG_3_PEAK_I			: out	std_logic_vector(15 downto 0);
							
							CPG_0_PEAK_Q			: out	std_logic_vector(15 downto 0);
							CPG_1_PEAK_Q			: out	std_logic_vector(15 downto 0);
							CPG_2_PEAK_Q			: out	std_logic_vector(15 downto 0);
							CPG_3_PEAK_Q			: out	std_logic_vector(15 downto 0)

						);
end component;

component LTE_COEFF_SCALING_V2P5

			port (
							RESET							: in	std_logic;
							CLK								: in	std_logic;
							CLOCK_UNSTABLE		: in	std_logic;
							
							CFR_COEFF_UPDATE_EN			: in	std_logic;
							COEFF_WE					: in	std_logic;
							COEFF_WR_ADDR			: in	std_logic_vector(9 downto 0);
							COEFF_WR_DATA			: in	std_logic_vector(31 downto 0);  -- MSB 16 bit : Q , LSB 16 bit : I
							
							READ_DIR          : in  std_logic;
							READ_ADDRESS			: in	std_logic_vector(9 downto 0);
							
							--CH_NUM            : in  std_logic;
							PEAK_I						: in	std_logic_vector(15 downto 0);
							PEAK_Q						: in	std_logic_vector(15 downto 0);
							
							CALCELLATION_I		: out	std_logic_vector(16 downto 0);
							CALCELLATION_Q		: out	std_logic_vector(16 downto 0)
						);
end component;

signal in_tog							: std_logic;
signal i_cpg0_addr, i_cpg1_addr, i_cpg2_addr, i_cpg3_addr	: std_logic_vector(9 downto 0);
signal i_cpg0_peak_i, i_cpg1_peak_i, i_cpg2_peak_i, i_cpg3_peak_i	: std_logic_vector(15 downto 0);
signal i_cpg0_peak_q, i_cpg1_peak_q, i_cpg2_peak_q, i_cpg3_peak_q	: std_logic_vector(15 downto 0);

signal cancel_0_i_ser, cancel_0_q_ser	: std_logic_vector(16 downto 0);
signal cancel_1_i_ser, cancel_1_q_ser	: std_logic_vector(16 downto 0);
signal cancel_2_i_ser, cancel_2_q_ser	: std_logic_vector(16 downto 0);
signal cancel_3_i_ser, cancel_3_q_ser	: std_logic_vector(16 downto 0);

signal i_cp_sum_I                     : std_logic_vector(17 downto 0);
signal i_cp_sum_Q                     : std_logic_vector(17 downto 0);

signal i_addr_dir_0                   : std_logic;
signal i_addr_dir_1                   : std_logic;
signal i_addr_dir_2                   : std_logic;
signal i_addr_dir_3                   : std_logic;

begin

u_cpg_alloc_blk : CPG_ALLOCATOR_V2P5
			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK, --: in	std_logic;
							
							TAPS_NUMBER				=> TAPS_NUMBER, --: in	std_logic_vector(9 downto 0);
							MIN_NUMBER				=> MIN_NUMBER, --: in	std_logic_vector(9 downto 0);
							
							--CH_NUM            => CH_NUM,  --: in  std_logic;
							
							--INPUT_TOGGLE => MUX_TOGGLE, --: in std_logic;
							PEAK_I						=> PEAK_I, --: in	std_logic_vector(15 downto 0);
							PEAK_Q						=> PEAK_Q, --: in	std_logic_vector(15 downto 0);
							
							PEAK_INDICATOR		=> PEAK_INDICATOR, --: in	std_logic;
							PEAK_MAGNITUDE		=> PEAK_MAGNITUDE, --: in	std_logic_vector(15 downto 0);
							
							CPG_0_ADDR				=> i_cpg0_addr, --: out	std_logic_vector(8 downto 0);
							CPG_1_ADDR				=> i_cpg1_addr, --: out	std_logic_vector(8 downto 0);
							CPG_2_ADDR				=> i_cpg2_addr, --: out	std_logic_vector(8 downto 0);
							CPG_3_ADDR				=> i_cpg3_addr, --: out	std_logic_vector(8 downto 0);
							
							ADDR_DIR_0        => i_addr_dir_0,  --: out std_logic;
							ADDR_DIR_1        => i_addr_dir_1,  --: out std_logic;
							ADDR_DIR_2        => i_addr_dir_2,  --: out std_logic;
							ADDR_DIR_3        => i_addr_dir_3,  --: out std_logic;
							
							CPG_0_PEAK_I			=> i_cpg0_peak_i, --: out	std_logic_vector(15 downto 0);
							CPG_1_PEAK_I			=> i_cpg1_peak_i, --: out	std_logic_vector(15 downto 0);
							CPG_2_PEAK_I			=> i_cpg2_peak_i, --: out	std_logic_vector(15 downto 0);
							CPG_3_PEAK_I			=> i_cpg3_peak_i, --: out	std_logic_vector(15 downto 0);
							
							CPG_0_PEAK_Q			=> i_cpg0_peak_q, --: out	std_logic_vector(15 downto 0);
							CPG_1_PEAK_Q			=> i_cpg1_peak_q, --: out	std_logic_vector(15 downto 0);
							CPG_2_PEAK_Q			=> i_cpg2_peak_q, --: out	std_logic_vector(15 downto 0);
							CPG_3_PEAK_Q			=> i_cpg3_peak_q  --: out	std_logic_vector(15 downto 0)

						);


u_coeff_scale_0_blk : LTE_COEFF_SCALING_V2P5

			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK, --: in	std_logic;
							CLOCK_UNSTABLE		=> CLOCK_UNSTABLE, --: in	std_logic;
							
							CFR_COEFF_UPDATE_EN => CFR_COEFF_UPDATE_EN, --
							COEFF_WE					=> COEFF_WE, --: in	std_logic;
							COEFF_WR_ADDR			=> COEFF_WADDR, --: in	std_logic_vector(8 downto 0);
							COEFF_WR_DATA			=> COEFF_DATA, --: in	std_logic_vector(31 downto 0);  -- MSB 16 bit : Q , LSB 16 bit : I
							
							READ_DIR          => i_addr_dir_0,  --: in  std_logic;
							READ_ADDRESS			=> i_cpg0_addr, --: in	std_logic_vector(8 downto 0);
							
							--CH_NUM            => CH_NUM,  --: in  std_logic;
							PEAK_I						=> i_cpg0_peak_i, --: in	std_logic_vector(15 downto 0);
							PEAK_Q						=> i_cpg0_peak_q, --: in	std_logic_vector(15 downto 0);
							
							CALCELLATION_I		=> cancel_0_i_ser, --: out	std_logic_vector(16 dwonto 0);
							CALCELLATION_Q		=> cancel_0_q_ser  --: out	std_logic_vector(16 dwonto 0)
						);
						
u_coeff_scale_1_blk : LTE_COEFF_SCALING_V2P5

			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK, --: in	std_logic;
							CLOCK_UNSTABLE		=> CLOCK_UNSTABLE, --: in	std_logic;
							
							CFR_COEFF_UPDATE_EN => CFR_COEFF_UPDATE_EN, --
							COEFF_WE					=> COEFF_WE, --: in	std_logic;
							COEFF_WR_ADDR			=> COEFF_WADDR, --: in	std_logic_vector(8 downto 0);
							COEFF_WR_DATA			=> COEFF_DATA, --: in	std_logic_vector(31 downto 0);  -- MSB 16 bit : Q , LSB 16 bit : I
							
							READ_DIR          => i_addr_dir_1,  --: in  std_logic;
							READ_ADDRESS			=> i_cpg1_addr, --: in	std_logic_vector(8 downto 0);
							
							--CH_NUM            => CH_NUM,  --
							PEAK_I						=> i_cpg1_peak_i, --: in	std_logic_vector(15 downto 0);
							PEAK_Q						=> i_cpg1_peak_q, --: in	std_logic_vector(15 downto 0);
							
							CALCELLATION_I		=> cancel_1_i_ser, --: out	std_logic_vector(16 dwonto 0);
							CALCELLATION_Q		=> cancel_1_q_ser  --: out	std_logic_vector(16 dwonto 0)
						);
						
u_coeff_scale_2_blk : LTE_COEFF_SCALING_V2P5

			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK, --: in	std_logic;
							CLOCK_UNSTABLE		=> CLOCK_UNSTABLE, --: in	std_logic;
							
							CFR_COEFF_UPDATE_EN => CFR_COEFF_UPDATE_EN, --
							COEFF_WE					=> COEFF_WE, --: in	std_logic;
							COEFF_WR_ADDR			=> COEFF_WADDR, --: in	std_logic_vector(8 downto 0);
							COEFF_WR_DATA			=> COEFF_DATA, --: in	std_logic_vector(31 downto 0);  -- MSB 16 bit : Q , LSB 16 bit : I
							
							READ_DIR          => i_addr_dir_2,  --: in  std_logic;
							READ_ADDRESS			=> i_cpg2_addr, --: in	std_logic_vector(8 downto 0);
							
							--CH_NUM            => CH_NUM,  --: in  std_logic;
							PEAK_I						=> i_cpg2_peak_i, --: in	std_logic_vector(15 downto 0);
							PEAK_Q						=> i_cpg2_peak_q, --: in	std_logic_vector(15 downto 0);
							
							CALCELLATION_I		=> cancel_2_i_ser, --: out	std_logic_vector(16 dwonto 0);
							CALCELLATION_Q		=> cancel_2_q_ser  --: out	std_logic_vector(16 dwonto 0)
						);
						
u_coeff_scale_3_blk : LTE_COEFF_SCALING_V2P5

			port map(
							RESET							=> RESET, --: in	std_logic;
							CLK								=> CLK, --: in	std_logic;
							CLOCK_UNSTABLE		=> CLOCK_UNSTABLE, --: in	std_logic;
							
							CFR_COEFF_UPDATE_EN => CFR_COEFF_UPDATE_EN, --
							COEFF_WE					=> COEFF_WE, --: in	std_logic;
							COEFF_WR_ADDR			=> COEFF_WADDR, --: in	std_logic_vector(8 downto 0);
							COEFF_WR_DATA			=> COEFF_DATA, --: in	std_logic_vector(31 downto 0);  -- MSB 16 bit : Q , LSB 16 bit : I
							
							READ_DIR          => i_addr_dir_3,  --: in  std_logic;
							READ_ADDRESS			=> i_cpg3_addr, --: in	std_logic_vector(8 downto 0);
							
							--CH_NUM            => CH_NUM,  --
							PEAK_I						=> i_cpg3_peak_i, --: in	std_logic_vector(15 downto 0);
							PEAK_Q						=> i_cpg3_peak_q, --: in	std_logic_vector(15 downto 0);
							
							CALCELLATION_I		=> cancel_3_i_ser, --: out	std_logic_vector(16 dwonto 0);
							CALCELLATION_Q		=> cancel_3_q_ser  --: out	std_logic_vector(16 dwonto 0)
						);
						
						
process(RESET,CLK)
begin
	if RESET = '1' then
		i_cp_sum_I <= (others => '0');
		i_cp_sum_Q <= (others => '0');
	elsif (CLK'event and CLK='1') then
		i_cp_sum_I <= (cancel_0_i_ser(16) & cancel_0_i_ser) + (cancel_1_i_ser(16) & cancel_1_i_ser) + (cancel_2_i_ser(16) & cancel_2_i_ser) + (cancel_3_i_ser(16) & cancel_3_i_ser);
		i_cp_sum_Q <= (cancel_0_q_ser(16) & cancel_0_q_ser) + (cancel_1_q_ser(16) & cancel_1_q_ser) + (cancel_2_q_ser(16) & cancel_2_q_ser) + (cancel_3_q_ser(16) & cancel_3_q_ser);
	end if;
end process;


--process(RESET,CLK)
--begin
--	if RESET = '1' then
--		CP_I <= (others => '0');
--		CP_Q <= (others => '0');
--	elsif (CLK'event and CLK='1') then
		CP_I <= i_cp_sum_I;
		CP_Q <= i_cp_sum_Q;
--	end if;
--end process;

end arc_LTE_CPG_PROCESSOR_V2P5;
