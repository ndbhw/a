library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;
use work.dduc_pkg.all;

entity DSP_TOP is
    port(
        -- Internal PLL Lock
        INT_SYSPLL_LOCK_IN              : in  std_logic;                                    -- Internal System PLL Lock

        -- System Reset & Clock
        RST_DDUC                        : in  std_logic;                                    -- DDUC_TOP Reset, '1': Reset
        RST_CFR                         : in  std_logic;                                    -- CFR_TOP Reset,  '1': Reset
        RST_DPD                         : in  std_logic;                                    -- DPD_TOP Reset,  '1': Reset
        RST_PIM                         : in  std_logic;

        CLK_SYS                         : in  std_logic;                                    -- System Clock :  30.72 MHz
        CLK_SYSX2                       : in  std_logic;                                    --  2x(CLK_SYS) :  61.44 MHz
        CLK_SYSX3                       : in  std_logic;                                    --  3x(CLK_SYS) :  92.16 MHz
        CLK_SYSX4                       : in  std_logic;                                    --  4x(CLK_SYS) : 122.88 MHz
        CLK_SYSX5                       : in  std_logic;                                    --  5x(CLK_SYS) : 153.60 MHz
        CLK_SYSX6                       : in  std_logic;                                    --  6x(CLK_SYS) : 184.32 MHz
        CLK_SYSX8                       : in  std_logic;                                    --  8x(CLK_SYS) : 245.76 MHz
        CLK_SYSX10                      : in  std_logic;                                    -- 10x(CLK_SYS) : 307.20 MHz
        CLK_SYSX12                      : in  std_logic;                                    -- 12x(CLK_SYS) : 368.64 MHz
        CLK_SYSX16                      : in  std_logic;                                    -- 16x(CLK_SYS) : 491.52 MHz
        CLK_SYSX20                      : in  std_logic;                                    -- 20x(CLK_SYS) : 614.40 MHz

        -- CPU Reset & Clock
        RST_CPUIF                       : in  std_logic;                                    -- CPUIF Reset, '1': Reset
        CLK_CPUIF                       : in  std_logic;                                    -- CPUIF Clock, Faster than iclk/oclk
        RST_DPDIF                       : in  std_logic;                                    -- CPUIF Reset, '1': Reset
        CLK_DPDIF                       : in  std_logic;                                    -- CPUIF Clock, Faster than iclk/oclk

        -- CPUIF_TOP  (Except DPD)
        ADDR_CPUIF_IN                   : in  std_logic_vector(ADDR_WIDTH-1 downto 0);      -- CPUIF Address Input, WORD Address
        WDATA_CPUIF_IN                  : in  std_logic_vector(WDATA_WIDTH-1 downto 0);     -- CPUIF Data Input
        RDATA_CPUIF_OUT                 : out std_logic_vector(RDATA_WIDTH-1 downto 0);     -- CPUIF DATA Output
        WREN_CPUIF_IN                   : in  std_logic;                                    -- CPUIF Write Enable,    '1': Active, Synchronous with iclk
        RDEN_CPUIF_IN                   : in  std_logic;                                    -- CPUIF Read Enable,     '1': Active,
        RDVLD_CPUIF_OUT                 : out std_logic;                                    -- CPUIF Read Data Valid, '1': Active, Synchronous with clk_cpu

        -- CPUIF DPD
        ADDR_DPDIF_IN                   : in  std_logic_vector( ADDR_WIDTH-1 downto 0);     -- CPUIF Address Input, WORD Address
        WDATA_DPDIF_IN                  : in  std_logic_vector(WDATA_WIDTH-1 downto 0);     -- CPUIF Data Input
        RDATA_DPDIF_OUT                 : out std_logic_vector(RDATA_WIDTH-1 downto 0);     -- CPUIF DATA Output
        WREN_DPDIF_IN                   : in  std_logic;                                    -- CPUIF Write Enable,    '1': Active, Synchronous with iclk
        RDEN_DPDIF_IN                   : in  std_logic;                                    -- CPUIF Read Enable,     '1': Active,
        RDVLD_DPDIF_OUT                 : out std_logic;                                    -- CPUIF Read Data Valid, '1': Active, Synchronous with clk_cpu

        -- BBCTRL_TOP Interface      
        DL_CHBW_IN                      : in  std_logic_array4(DL_BBIQARY_NUM-1 downto 0);  -- 0x0: 5M,  0x1: 10M, 0x2: 15M, 0x3: 20M
        UL_CHBW_IN                      : in  std_logic_array4(UL_BBIQARY_NUM-1 downto 0);  -- 0x0: 5M,  0x1: 10M, 0x2: 15M, 0x3: 20M
        
        DL_BFN_STRB_IN                  : in  std_logic;                                    -- Downlink 10ms Frame Sync Strobe
        DL_SSB_STRB_IN                  : in  std_logic;                                    -- Downlink SSB period Strobe (20/40/80/160msec)
        DL_TDD_IN                       : in  std_logic;                                    -- Downlink TDD Strobe

        UL_BFN_STRB_OUT                 : out std_logic;                                    -- Delayed Uplink 10ms Frame Sync Strobe as UL Path Latency
        UL_TDD_OUT                      : out std_logic;                                    -- Delayed Uplink TDD Strobe as UL Path Latency

        BCF_ENB_IN                      : in  std_logic;
       
        DL_SYNC_IN                      : in  std_logic_vector(DL_BBIQARY_NUM-1 downto 0);  -- DUC IQ Data Sync
        DL_IQ_IN                        : in  std_logic_array16(DL_BBIQARY_NUM-1 downto 0); -- DUC IQ Data

        UL_SYNC_OUT                     : out std_logic_vector(UL_BBIQARY_NUM-1 downto 0);  -- DDC IQ Data Sync
        UL_IQ_OUT                       : out std_logic_array16(UL_BBIQARY_NUM-1 downto 0); -- DDC IQ Data

        -- DACIF_TOP Interface
        DL_BFN_STRB_OUT                 : out std_logic;                                    -- Delayed Downlink 10ms Frame Sync Strobe as DL Path Latency
        DL_SSB_STRB_OUT                 : out std_logic;                                    -- Delayed Downlink 10ms Frame Sync Strobe as DL Path Latency
        DL_TDD_OUT                      : out std_logic;                                    -- Delayed Downlink TDD Strobe as DL Path Latency

        FB_BFN_STRB_IN                  : in  std_logic;                                    -- Feedback 10ms Frame Sync Strobe
        FB_TDD_IN                       : in  std_logic;                                    -- Feedback TDD Strobe
        FB_SSB_STRB_IN                  : in  std_logic;                                    -- 40ms sync signal for SSB power measurment, 19.10.03

        UL_BFN_STRB_IN                  : in  std_logic;                                    -- Uplink 10ms Frame Sync Strobe
        UL_TDD_IN                       : in  std_logic;                                    -- Uplink TDD Strobe

        BCF_ENB_OUT                     : out std_logic;

        -- Traffic IQ
        DL_SYNC_OUT                     : out std_logic;                                    -- DSP_TOP output IQ sample valid
        DL_I_OUT                        : out std_logic_array16(TX_ANT_NUM-1 downto 0);     -- DSP_TOP output I data
        DL_Q_OUT                        : out std_logic_array16(TX_ANT_NUM-1 downto 0);     -- DSP_TOP output Q data

        FB_SYNC_IN                      : in  std_logic;                                    -- Feedback Path IQ sample valid
        FB_I_IN                         : in  std_logic_array16(FB_PATH_NUM-1 downto 0);    -- Feedback Path I data
        FB_Q_IN                         : in  std_logic_array16(FB_PATH_NUM-1 downto 0);    -- Feedback Path Q data

        UL_SYNC_IN                      : in  std_logic;                                    -- DSP_TOP Input IQ sample valid
        UL_I_IN                         : in  std_logic_array16(RX_ANT_NUM-1 downto 0);     -- DSP_TOP Input I data
        UL_Q_IN                         : in  std_logic_array16(RX_ANT_NUM-1 downto 0);     -- DSP_TOP Input Q data
    
        -- MISC_TOP Interface
        FBSW_SSB_IND_FLAG_DSP           : in  std_logic;

        FBSW_START_TRIG_IN              : in  std_logic;                                    -- Start Pulse of Feedback Switch Period
        FBSW_CNT_IN                     : in  std_logic_vector(7-1 downto 0);               -- Feedback Switch Counter
        FBSW_AUTO_MODE_DONE_IN          : in  std_logic_vector(FB_PATH_NUM-1 downto 0);     -- Feedback Switch Automode Done Flag, '0': Auto Mode
        FBSW_PWR_MSR_UDT_IN             : in  std_logic;                                    -- Feedback Switch Measure Done, Feedback Power Measure Update Enable
        FBSW_MANUAL_MODE_IN             : in  std_logic;                                    -- Feedback Switch Manual Mode, '1': Manual Mode
        FBSW_SC_PATH_SEL_OUT            : out std_logic_vector(5-1 downto 0);
        PWR_MSR_FB_SYNC_IN              : in  std_logic;                                    -- Feedback Power Measure Feedback Sync / 20ms sync
        PWR_MSR_EN_IN                   : in  std_logic;                                    -- Feedback Power Measure Enable

        -- Signal Suspension
        SIG_SUS_FLAG_OUT                : out std_logic_vector(TX_ANT_NUM-1 downto 0);       -- OPD Detect Flag
        SIG_SUS_DLOFF_IN                : in  std_logic_vector(TX_ANT_NUM-1 downto 0);       -- Wave-Stop Flag

        -- IQ/Clock Status
        DL_IQ_ISZERO_OUT                : out std_logic_vector(TX_ANT_NUM-1 downto 0);       -- '1': IQ is Zero, '0': IQ is Non-Zero
        DL_CLK_ISZERO_OUT               : out std_logic_vector(TX_ANT_NUM-1 downto 0);

        -- Dump
        DUMP_BFN_STRB_OUT               : out std_logic_vector(2-1 downto 0);                -- Delayed 10ms Frame Sync Strobe for DUMP
        DUMP_DVLD_OUT                   : out std_logic_vector(2-1 downto 0);                -- Dump Sample Valid
        DUMP_DATA_OUT                   : out std_logic_array32(2-1 downto 0)                -- Dump Sample
    );
end DSP_TOP;

architecture arc_DSP_TOP of DSP_TOP is

    component CPUIF_DSP_COMMON is
        generic(
            ADDR_WIDTH                          : natural                       :=          16 ;      -- CPU Address Bitwidth
            WDATA_WIDTH                         : natural                       :=          32 ;      -- CPU Write Data Bitwidth
            RDATA_WIDTH                         : natural                       :=          32        -- CPU Read  Data Bitwidth
        );
        port(
            -- Reset & Clock
            RST_CPUIF                           : in  std_logic;                                      -- CPUIF Reset, '1': Reset
            CLK_CPUIF                           : in  std_logic;                                      -- CPUIF Clock, faster than iclk/oclk
    
            CLK_SYS                             : in  std_logic;                                      -- System Clock :  30.72 MHz
            CLK_SYSX2                           : in  std_logic;                                      --  2x(CLK_SYS) :  61.44 MHz
            CLK_SYSX3                           : in  std_logic;                                      --  3x(CLK_SYS) :  92.16 MHz
            CLK_SYSX4                           : in  std_logic;                                      --  4x(CLK_SYS) : 122.88 MHz
            CLK_SYSX5                           : in  std_logic;                                      --  5x(CLK_SYS) : 153.60 MHz
            CLK_SYSX6                           : in  std_logic;                                      --  6x(CLK_SYS) : 184.32 MHz
            CLK_SYSX8                           : in  std_logic;                                      --  8x(CLK_SYS) : 245.76 MHz
            CLK_SYSX10                          : in  std_logic;                                      -- 10x(CLK_SYS) : 307.20 MHz
            CLK_SYSX12                          : in  std_logic;                                      -- 12x(CLK_SYS) : 368.64 MHz
            CLK_SYSX16                          : in  std_logic;                                      -- 16x(CLK_SYS) : 491.52 MHz
            CLK_SYSX20                          : in  std_logic;                                      -- 20x(CLK_SYS) : 614.40 MHz
    
            -- CPU Interface
            ADDR_CPUIF_IN                       : in  std_logic_vector( ADDR_WIDTH-1 downto 0);       -- CPUIF Address Input, WORD Address
            WDATA_CPUIF_IN                      : in  std_logic_vector(WDATA_WIDTH-1 downto 0);       -- CPUIF Data Input
            RDATA_CPUIF_OUT                     : out std_logic_vector(RDATA_WIDTH-1 downto 0);       -- CPUIF DATA Output
            WREN_CPUIF_IN                       : in  std_logic;                                      -- CPUIF Write Enable,    '1': Active, Synchronous with iclk
            RDEN_CPUIF_IN                       : in  std_logic;                                      -- CPUIF Read Enable,     '1': Active,
            RDVLD_CPUIF_OUT                     : out std_logic;                                      -- CPUIF Read Data Valid, '1': Active, Synchronous with clk_cpu
    
            -- TDD/FS Strobe
            DL_BFN_STRB_IN                      : in  std_logic;                                      -- Downlink 10ms Frame Sync Strobe
            FB_BFN_STRB_IN                      : in  std_logic;                                      -- Feedback 10ms Frame Sync Strobe
    
            -- Feedback Switch
            FBSW_AUTO_MODE_DONE_IN              : in  std_logic_vector(FB_PATH_NUM-1 downto 0);       -- Feedback Switch Automode Done Flag, '0': Auto Mode
            FBSW_CNT_IN                         : in  std_logic_vector(5-1 downto 0);                 -- Feedback Switch Counter
            FBSW_VALUE_IN                       : in  std_logic_vector(4-1 downto 0);                 -- Feedback Switch Encoded Value
            FBSW_PWR_MSR_UDT_IN                 : in  std_logic;                                      -- Feedback Switch Measure Done, Feedback Power Measure Update Enable
    
            -- DSP_TOP Version & Test
            DSP_TOP_MODULE_INFO_IN              : in  std_logic_vector(32-1 downto 0);                -- DSP_TOP Module Information
            DSP_TOP_MODULE_STRUCT_IN            : in  std_logic_vector(32-1 downto 0);                -- DSP_TOP Module Structure Information
            DSP_TOP_MODULE_DATE_IN              : in  std_logic_vector(32-1 downto 0);                -- DSP_TOP Module Date
    
            DSP_DUMP_SEL_STRB_OUT               : out std_logic;                                      -- DSP_TOP Dump Selection Strobe
            DSP_DUMP_SEL_OUT                    : out std_logic_vector(8-1 downto 0);                 -- DSP_TOP Dump Selection
    
            -- DDUC Control & Status
            DDUC_TOP_MODULE_INFO_IN             : in  std_logic_vector(32-1 downto 0);                -- DDUC_TOP Module Information
            DDUC_TOP_MODULE_STRUCT_IN           : in  std_logic_vector(32-1 downto 0);                -- DDUC_TOP Module Structure Information
            DDUC_TOP_MODULE_DATE_IN             : in  std_logic_vector(32-1 downto 0);                -- DDUC_TOP Module Date
    
            DDUC_DL_PROC_DLY_IN                 : in  std_logic_vector(32-1 downto 0);                -- DDUC_TOP DownLink Path Latency
            DDUC_UL_PROC_DLY_IN                 : in  std_logic_vector(32-1 downto 0);                -- DDUC_TOP UpLink   Path Latency
     
            DDUC_DL_PATH_ATT_OUT                : out std_logic_array16(TX_ANT_NUM-1 downto 0);
            DDUC_DL_PATH_DLY_OUT                : out std_logic_array12(TX_ANT_NUM-1 downto 0);
            DDUC_UL_PATH_DLY_OUT                : out std_logic_array12(RX_ANT_NUM-1 downto 0);
    
            DDUC_DUC_NCO_WEN_OUT                : out std_logic_vector(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);
            DDUC_DUC_NCO_DATA_OUT               : out std_logic_array32(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);
            DDUC_DUC_GAIN_OUT                   : out std_logic_array16(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);
    
            DDUC_DUC_TO_ANT_SUM_MODE_OUT        : out std_logic_vector((TX_ANT_NUM*DL_BBIQARY_NUM/2)-1 downto 0);
            DDUC_DUC_TO_ANT_SEL_OUT             : out std_logic_vector((TX_ANT_NUM*DL_BBIQARY_NUM/2)*2*TX_ANT_NUM-1 downto 0);
    
            DDUC_DDC_NCO_WEN_OUT                : out std_logic_vector(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);
            DDUC_DDC_NCO_DATA_OUT               : out std_logic_array32(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);
            DDUC_DDC_GAIN_OUT                   : out std_logic_array16(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);
    
            DDUC_UL_TO_ANT_SEL_OUT              : out std_logic_array8((RX_ANT_NUM*UL_BBIQARY_NUM)/2-1 downto 0);
    
            -- DDUC_UL_NCO_WEN_OUT                 : out std_logic;
            -- DDUC_UL_NCO_DATA_OUT                : out std_logic_vector(32-1 downto 0);
    
            DDUC_UL_ADC_PWR_IN                  : in  std_logic_array32(RX_ANT_NUM-1 downto 0);
    
            -- CFR Control & Status
            CFR_TOP_MODULE_INFO_IN              : in  std_logic_vector(31 downto 0);
            CFR_TOP_MODULE_STRUCT_IN            : in  std_logic_vector(31 downto 0);
            CFR_TOP_MODULE_DATE_IN              : in  std_logic_vector(31 downto 0);
    
            CFR_DL_PROC_DLY_IN                  : in  std_logic_vector(31 downto 0);
            CFR_CORE_BYPASS_OUT                 : out std_logic_vector(TX_ANT_NUM-1 downto 0);
            
            CFR_THRSD_OUT                       : out std_logic_array16(TX_ANT_NUM-1 downto 0);
            CFR_PEAK_SPACING_OUT                : out std_logic_array8(TX_ANT_NUM-1 downto 0);
            CFR_HC_THRSD_OUT                    : out std_logic_array16(TX_ANT_NUM-1 downto 0);
            CFR_HC_ENB_OUT                      : out std_logic_vector(TX_ANT_NUM-1 downto 0);
    
            CFR_TAP_NUM_OUT                     : out std_logic_array10((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
            CFR_COEF_UPDATE_ENB_OUT             : out std_logic_vector((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
            CFR_COEF_ADDR_OUT                   : out std_logic_array10((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
            CFR_COEF_WDATA_OUT                  : out std_logic_array32((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
            CFR_COEF_WEN_OUT                    : out std_logic_vector((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
    
            CFR_PWR_MSR_UDT_IN                  : in  std_logic_vector(TX_ANT_NUM-1 downto 0);
            CFR_PWR_IN                          : in  std_logic_array32(TX_ANT_NUM-1 downto 0);
    
            CFR_OPD_TRSHD_OUT                   : out std_logic_array32(TX_ANT_NUM-1 downto 0);
            CFR_OPD_FLAG_IN                     : in  std_logic_vector(TX_ANT_NUM-1 downto 0);
            CFR_OPD_PWR_IN                      : in  std_logic_array32(TX_ANT_NUM-1 downto 0);
    
            -- DPD/FB Control & Status
            DPD_TOP_MODULE_INFO_IN              : in  std_logic_vector(32-1 downto 0);                  -- DPD_TOP Module Information
            DPD_TOP_MODULE_STRUCT_IN            : in  std_logic_vector(32-1 downto 0);                  -- DPD_TOP Module Structure Information
            DPD_TOP_MODULE_DATE_IN              : in  std_logic_vector(32-1 downto 0);                  -- DPD_TOP Module Date
    
            DPD_DL_PROC_DLY_IN                  : in  std_logic_vector(32-1 downto 0);                  -- DPD_TOP DownLink Path Latency
            DPD_FB_PROC_DLY_IN                  : in  std_logic_vector(32-1 downto 0);                  -- DPD_TOP FeedBack Path Latency
            DPD_UL_PROC_DLY_IN                  : in  std_logic_vector(32-1 downto 0);                  -- DPD_TOP UpLink   Path Latency
    
            DPD_DL_BULK_NCO_WEN_OUT             : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DownLink Bulk NCO Word Write Enable
            DPD_DL_BULK_NCO_WORD_OUT            : out std_logic_array32(TX_ANT_NUM-1 downto 0);                  -- DPD_TOP DownLink Bulk NCO Word
    
            DPD_CORE_BYPASS_OUT                 : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP Core Bypass
    
            DPD_HC_THRSD_CDC_STRB_OUT           : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP Hard-Clipper Threshold CDC Strobe
            DPD_HC_THRSD_OUT                    : out std_logic_array16(TX_ANT_NUM-1 downto 0);         -- DPD_TOP Hard-Clipper Threshold
    
            DPD_HC_FLAG_IN                      : in  std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD Hard-Clipping Flag
    
            DPD_DL_ATT_CDC_STRB_OUT             : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DL Attenuator Value CDC Strobe
            DPD_DL_ATT_OUT                      : out std_logic_array16(TX_ANT_NUM-1 downto 0);         -- DPD_TOP DL Attenuator Value
    
            DPD_OUTFILTER_BYPASS_OUT            : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DPD Output Filter Bypass
            DPD_OUTFILTER_COEF_WEN_OUT          : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DPD Output Filter Coefficients Write Enable (Indirect Write/Read)
            DPD_OUTFILTER_COEF_REN_OUT          : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DPD Output Filter Coefficients Read  Enable (Indirect Write/Read)
            DPD_OUTFILTER_COEF_WRDN_OUT         : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DPD Output Filter Coefficients Write Done   (Indirect Write/Read)
            DPD_OUTFILTER_COEF_ADDR_OUT         : out std_logic_vector(8-1 downto 0);                   -- DPD_TOP DPD Output Filter Coefficients Address      (Indirect Write/Read)
            DPD_OUTFILTER_COEF_WDATA_OUT        : out std_logic_vector(16-1 downto 0);                  -- DPD_TOP DPD Output Filter Coefficients Write Data   (Indirect Write/Read)
            DPD_OUTFILTER_COEF_RDATA_IN         : in  std_logic_vector(16-1 downto 0);                  -- DPD_TOP DPD Output Filter Coefficients Read  Data   (Indirect Write/Read)
    
            DPD_DACIF_ONOFF_BYPASS_OUT          : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DACIF_IQ_ONOFF Bypass
            DPD_DACIF_ONOFF_ON_OUT              : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DACIF_IQ_ONOFF On
    
            DPD_FB_BULK_NCO_WEN_OUT             : out std_logic_vector(FB_PATH_NUM-1 downto 0);         -- DPD_TOP FeedBack Bulk NCO Word Write Enable
            DPD_FB_BULK_NCO_WORD_OUT            : out std_logic_array32(FB_PATH_NUM-1 downto 0);        -- DPD_TOP FeedBack Bulk NCO Word
    
            DPD_FB_FILTER_BYPASS_OUT            : out std_logic_vector(FB_PATH_NUM-1 downto 0);         -- DPD_TOP FeedBack Filter Bypass
    
            DPD_FB_PWR_MSR_DONE_IN              : in  std_logic_vector(FB_PATH_NUM-1 downto 0);         -- DPD_TOP Feedback Power Measurement Done Flag
            DPD_FB_PWR_IN                       : in  std_logic_array32(FB_PATH_NUM-1 downto 0);        -- DPD_TOP Feedback Power (Mantissa Format)
            DPD_DL_PWR_IN                       : in  std_logic_array32(TX_ANT_NUM-1 downto 0);
    
            DPD_FB_ATT_CDC_STRB_OUT             : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP Feedback Forward & Reverse Attenuator Value CDC Storbe
            DPD_FB_FWD_ATT_OUT                  : out std_logic_array16(TX_ANT_NUM-1 downto 0);         -- DPD_TOP Feedback Forward Attenuator Value
            DPD_FB_RVS_ATT_OUT                  : out std_logic_array16(TX_ANT_NUM-1 downto 0);         -- DPD_TOP Feedback Reverse Attenuator Value
    
            -- PIM Control & Status
            PIM_DETECTOR_ON_OUT                 : out std_logic_vector(RX_ANT_NUM-1 downto 0);
            PIM_MITIGATOR_ON_OUT                : out std_logic_vector(RX_ANT_NUM-1 downto 0);
            PIM_CFR_REF_SEL_OUT                 : out std_logic_vector(RX_ANT_NUM-1 downto 0);
    
            PIM_INTERB_DUC_GAIN_STRB_OUT        : out std_logic;
            PIM_INTERB_DUC_GAIN_OUT             : out std_logic_array16(RX_ANT_NUM-1 downto 0);
    
            PIM_PNPC_SEL_STRB_OUT               : out std_logic;
            PIM_PNPC_SEL_OUT                    : out std_logic_array2(RX_ANT_NUM-1 downto 0);
    
            DPD_PIM_CORE_BYPASS_OUT             : out std_logic_vector(RX_ANT_NUM-1 downto 0);          -- DPD_TOP PIM Core Bypass
    
            DPD_PIM_BULK_NCO_WEN_OUT            : out std_logic;                                        -- DPD_TOP DownLink Bulk NCO Word Write Enable
            DPD_PIM_BULK_NCO_WORD_OUT           : out std_logic_vector(31 downto 0);                    -- DPD_TOP DownLink Bulk NCO Word
    
            DPD_PIM_LPF_BYPASS_OUT              : out std_logic_vector(RX_ANT_NUM-1 downto 0);          -- DPD_TOP PIM LowPassFilter Bypass
            DPD_PIM_LPF_COEF_WEN_OUT            : out std_logic_vector(RX_ANT_NUM-1 downto 0);          -- DPD_TOP PIM LowPassFilter Coefficients Write Enable (Indirect Write/Read)
            DPD_PIM_LPF_COEF_REN_OUT            : out std_logic_vector(RX_ANT_NUM-1 downto 0);          -- DPD_TOP PIM LowPassFilter Coefficients Read  Enable (Indirect Write/Read)
            DPD_PIM_LPF_COEF_WRDN_OUT           : out std_logic_vector(RX_ANT_NUM-1 downto 0);          -- DPD_TOP PIM LowPassFilter Coefficients Write Done   (Indirect Write/Read)
            DPD_PIM_LPF_COEF_ADDR_OUT           : out std_logic_vector(8-1 downto 0);                   -- DPD_TOP PIM LowPassFilter Coefficients Address      (Indirect Write/Read)
            DPD_PIM_LPF_COEF_WDATA_OUT          : out std_logic_vector(16-1 downto 0);                  -- DPD_TOP PIM LowPassFilter Coefficients Write Data   (Indirect Write/Read)
            DPD_PIM_LPF_COEF_RDATA_IN           : in  std_logic_vector(16-1 downto 0);                  -- DPD_TOP PIM LowPassFilter Coefficients Read  Data   (Indirect Write/Read)
    
            DPD_UL_PIM_NCO_WREN_OUT             : out std_logic;
            DPD_UL_PIM_NCO_WORD_OUT             : out std_logic_vector(32-1 downto 0);
    
            -- LoopBack/Dump/TestPattern
            DPD_SC_LB_TEST_ON_OUT               : out std_logic;
            DSP_TEST_LB_OUT                     : out std_logic
        );
    end component;

    component DDUC_TOP is
        generic(
            DUPLEX_TYPE                 : string :="TDD";
            VENDOR                      : string :="XILINX";
            PBA_NAME                    : string :="X";
            ADDR_WIDTH                  : natural:=0;
            WDATA_WIDTH                 : natural:=0;
            RDATA_WIDTH                 : natural:=0
        );
        port(
            --MODULE RST IF
            RST_DDUC                            : in  std_logic;
            --SYSCLK IF
            CLK_SYS                             : in  std_logic;
            CLK_SYSX2                           : in  std_logic;
            CLK_SYSX3                           : in  std_logic;
            CLK_SYSX4                           : in  std_logic;
            CLK_SYSX5                           : in  std_logic;
            CLK_SYSX6                           : in  std_logic;
            CLK_SYSX8                           : in  std_logic;
            CLK_SYSX10                          : in  std_logic;
            CLK_SYSX12                          : in  std_logic;
            CLK_SYSX16                          : in  std_logic;
            CLK_SYSX20                          : in  std_logic;
            INT_SYSPLL_LOCK_IN                  : in  std_logic;
            --MODULE INFO IF
            DDUC_INFO_OUT                       : out std_logic_vector(31 downto 0);
            DDUC_STRUCT_OUT                     : out std_logic_vector(31 downto 0);
            DDUC_DATE_OUT                       : out std_logic_vector(31 downto 0);
            --MODULE DLY IF
            DUC_PROC_DLY_OUT                    : out std_logic_vector(31 downto 0);
            DDC_PROC_DLY_OUT                    : out std_logic_vector(31 downto 0);
            --DLY CTRL IF
            DL_CRR_DLY_IN                       : in  std_logic_array12(TX_ANT_NUM-1 downto 0);
            UL_CRR_DLY_IN                       : in  std_logic_array12(RX_ANT_NUM-1 downto 0);
            --ATT CTRL IF
            DL_PATH_ATT_IN                      : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
            --DUC CTRL IF
            DUC_NCO_WEN_IN                      : in  std_logic_vector(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);
            DUC_NCO_DATA_IN                     : in  std_logic_array32(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);
            DUC_GAIN_IN                         : in  std_logic_array16(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);
            DUC2ANT_SEL_IN                      : in  std_logic_vector((TX_ANT_NUM*DL_BBIQARY_NUM/2)*2*TX_ANT_NUM-1 downto 0);
            DUC2ANT_SUM_MODE_IN                 : in  std_logic_vector((TX_ANT_NUM*DL_BBIQARY_NUM/2)-1 downto 0);
            --DDC CTRL IF
            DDC_NCO_WEN_IN                      : in  std_logic_vector(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);
            DDC_NCO_DATA_IN                     : in  std_logic_array32(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);
            DDC_GAIN_IN                         : in  std_logic_array16(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);
            UL_ANT_SEL_IN                       : in  std_logic_array8((RX_ANT_NUM*UL_BBIQARY_NUM/2)-1 downto 0);
            --UL CTRL IF
            UL_ADC_PWR_OUT                      : out std_logic_array32(RX_ANT_NUM-1 downto 0);
            --BBCTRL 2 DSP IF
            DL_SSB_STRB_IN                      : in  std_logic;
            DL_BFN_STRB_IN                      : in  std_logic;
            DL_TDD_IN                           : in  std_logic;            
            DL_CHBW_IN                          : in  std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
            DL_SYNC_IN                          : in  std_logic_vector(DL_BBIQARY_NUM-1 downto 0);
            DL_IQ_IN                            : in  std_logic_array16(DL_BBIQARY_NUM-1 downto 0);
            BCF_ENB_IN                          : in  std_logic;
            --DSP 2 BBCTRL IF
            UL_BFN_STRB_OUT                     : out std_logic;
            UL_TDD_OUT                          : out std_logic;
            UL_CHBW_IN                          : in  std_logic_array4(UL_BBIQARY_NUM-1 downto 0);
            UL_SYNC_OUT                         : out std_logic_vector(UL_BBIQARY_NUM-1 downto 0);
            UL_IQ_OUT                           : out std_logic_array16(UL_BBIQARY_NUM-1 downto 0);
            --DL IQ OUT IF
            DL_SSB_STRB_OUT                     : out std_logic;
            DL_BFN_STRB_OUT                     : out std_logic;
            DL_TDD_OUT                          : out std_logic;
            DL_SYNC_OUT                         : out std_logic_vector(TX_ANT_NUM-1 downto 0);
            DL_I_OUT                            : out std_logic_array16(TX_ANT_NUM-1 downto 0);
            DL_Q_OUT                            : out std_logic_array16(TX_ANT_NUM-1 downto 0);
            BCF_ENB_OUT                         : out std_logic;
            --UL IQ IN IF
            UL_BFN_STRB_IN                      : in  std_logic;
            UL_TDD_IN                           : in  std_logic;
            UL_SYNC_IN                          : in  std_logic_vector (RX_ANT_NUM-1 downto 0);
            UL_I_IN                             : in  std_logic_array16(RX_ANT_NUM-1 downto 0);
            UL_Q_IN                             : in  std_logic_array16(RX_ANT_NUM-1 downto 0);
            --MISC IF
            DL_CLK_ISZERO_OUT                   : out std_logic_vector(TX_ANT_NUM-1 downto 0);
            DL_IQ_ISZERO_OUT                    : out std_logic_vector(TX_ANT_NUM-1 downto 0);
            SIG_SUS_FLAG_OUT                    : out std_logic_vector(TX_ANT_NUM-1 downto 0);
            SIG_SUS_DLOFF_IN                    : in  std_logic_vector(TX_ANT_NUM-1 downto 0);
            --DUMP IF
            DUMP_POINT_SEL_STRB_IN              : in  std_logic;
            DUMP_POINT_SEL_IN                   : in  std_logic_vector(8-1 downto 0);
            DUMP_BFN_STRB_OUT                   : out std_logic_vector(2-1 downto 0);
            DUMP_DVLD_OUT                       : out std_logic_vector(2-1 downto 0);
            DUMP_DATA_OUT                       : out std_logic_array32(2-1 downto 0)
        );
    end component;

    component CFR_TOP is
        port(
            CFR_INFO_OUT                : out std_logic_vector(31 downto 0);
            CFR_DATE_OUT                : out std_logic_vector(31 downto 0);
            CFR_STRUCT_OUT              : out std_logic_vector(31 downto 0);
            
            RST_CFR                     : in  std_logic;
            CLK_SYS                     : in  std_logic;                                 -- System Clock :  30.72 MHz
            CLK_SYSX2                   : in  std_logic;                                 --  2x(CLK_SYS) :  61.44 MHz
            CLK_SYSX3                   : in  std_logic;                                 --  3x(CLK_SYS) :  92.16 MHz
            CLK_SYSX4                   : in  std_logic;                                 --  4x(CLK_SYS) : 122.88 MHz
            CLK_SYSX5                   : in  std_logic;                                 --  5x(CLK_SYS) : 153.60 MHz
            CLK_SYSX6                   : in  std_logic;                                 --  6x(CLK_SYS) : 184.32 MHz
            CLK_SYSX8                   : in  std_logic;                                 --  8x(CLK_SYS) : 245.76 MHz
            CLK_SYSX10                  : in  std_logic;                                 -- 10x(CLK_SYS) : 307.20 MHz
            CLK_SYSX12                  : in  std_logic;                                 -- 12x(CLK_SYS) : 368.64 MHz
            CLK_SYSX16                  : in  std_logic;                                 -- 16x(CLK_SYS) : 491.52 MHz
            CLK_SYSX20                  : in  std_logic;                                 -- 20x(CLK_SYS) : 614.40 MHz
            
            INT_SYSPLL_LOCK_IN          : in  std_logic;
            
            DL_BFN_STRB_IN              : in  std_logic; -- 10msec frame sync
            DL_SSB_STRB_IN              : in  std_logic; -- SSB strb
            DL_BFN_STRB_OUT             : out std_logic; -- 10msec frame sync delayed out
            DL_SSB_STRB_OUT             : out std_logic; -- 10msec frame sync delayed out
            DL_TDD_IN                   : in  std_logic; -- TDD strobe signal in
            DL_TDD_OUT                  : out std_logic; -- Delayed TDD strobe signal out
            
            DL_BCF_ENB_IN               : in  std_logic; -- Beamforming calibration
            DL_BCF_ENB_OUT              : out std_logic;
            
            FBSW_AUTO_MODE_DONE_IN      : in  std_logic_vector(FB_PATH_NUM-1 downto 0); -- Feedback Switch Automode operation done flag
            
            CFR_PROC_DLY_OUT            : out std_logic_vector(31 downto 0);
            
            CFR_BYPASS_IN               : in  std_logic_vector(TX_ANT_NUM-1 downto 0);
            
            CFR_TRSHD_IN                : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
            CFR_PEAK_SPACING_IN         : in  std_logic_array8(TX_ANT_NUM-1 downto 0);
            
            CFR_COEFF_UDT_ENB_IN        : in  std_logic_vector(TX_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
            CFR_COEFF_WEN_IN            : in  std_logic_vector(TX_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
            CFR_COEFF_WRADDR_IN         : in  std_logic_array10(TX_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
            CFR_COEFF_WRDATA_IN         : in  std_logic_array32(TX_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
            
            CFR_TAP_NUM_IN              : in  std_logic_array10(TX_ANT_NUM/CFR_PATH_PER_MODULE-1 downto 0);
            
            DL_SYNC_IN                  : in  std_logic_vector(TX_ANT_NUM-1 downto 0);
            DL_I_IN                     : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
            DL_Q_IN                     : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
            
            DL_SYNC_OUT                 : out std_logic_vector(TX_ANT_NUM-1 downto 0);
            DL_I_OUT                    : out std_logic_array16(TX_ANT_NUM-1 downto 0);
            DL_Q_OUT                    : out std_logic_array16(TX_ANT_NUM-1 downto 0);
        
            DL_PIM_SYNC_OUT             : out std_logic;
            DL_PIM_I_OUT                : out std_logic_array16(TX_ANT_NUM-1 downto 0);
            DL_PIM_Q_OUT                : out std_logic_array16(TX_ANT_NUM-1 downto 0);

            CFR_HC_TRSHD_IN             : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
            CFR_HC_EN_IN                : in  std_logic_vector(TX_ANT_NUM-1 downto 0);
            
            CFR_PWR_MSR_UDT_OUT         : out std_logic_vector(TX_ANT_NUM-1 downto 0);
            CFR_PWR_OUT                 : out std_logic_array32(TX_ANT_NUM-1 downto 0);
            
            OPD_TRSHD_IN                : in  std_logic_array32(TX_ANT_NUM-1 downto 0);
            OPD_PWR_OUT                 : out std_logic_array32(TX_ANT_NUM-1 downto 0);
            SIG_SUS_FLAG_OUT            : out std_logic_vector(TX_ANT_NUM-1 downto 0);
            
            DUMP_BFN_STRB_OUT           : out std_logic_vector(1 downto 0);
            DUMP_DATA_OUT               : out std_logic_array32(1 downto 0);
            DUMP_DVLD_OUT               : out std_logic_vector(1 downto 0);
            
            TEST_DATA_IN                : in  std_logic_array16(1 downto 0);
            TEST_ENB_OUT                : out std_logic_vector(1 downto 0);
            
            DBG_SIG_OUT                 : out std_logic_array32(1 downto 0)    
        );
    end component;

    component DPD_TOP is        
        port(
            -- CPU Interface       
            RST_CPUIF                                 : in  std_logic;                                 -- CPUIF Reset, '1': Reset
            CLK_CPUIF                                 : in  std_logic;                                 -- CPUIF Clock, Faster than iclk/oclk
            ADDR_CPUIF_IN                             : in  std_logic_vector(ADDR_WIDTH-1  downto 0);  -- CPUIF Address Input, Word Address
            WDATA_CPUIF_IN                            : in  std_logic_vector(WDATA_WIDTH-1 downto 0);  -- CPUIF Data Input
            RDATA_CPUIF_OUT                           : out std_logic_vector(RDATA_WIDTH-1 downto 0);  -- CPUIF Data Output
            WREN_CPUIF_IN                             : in  std_logic;                                 -- CPUIF Write Enable, '1': Active, Synchronous with iclk
            RDEN_CPUIF_IN                             : in  std_logic;                                 -- CPUIF Read  Enable, '1': Active
            RDVLD_CPUIF_OUT                           : out std_logic;                                 -- CPUIF Read Valid,   '1': Active, Synchronous with clk_cpu
    
            -- Reset & Clock                          
            RST_DPD                                   : in  std_logic;                                 -- DPD_TOP Reset, '1': Reset
            RST_PIM                                   : in  std_logic;                                 -- DPD_TOP Reset, '1': Reset
            CLK_SYS                                   : in  std_logic;                                 -- System Clock :  30.72 MHz
            CLK_SYSX2                                 : in  std_logic;                                 --  2x(CLK_SYS) :  61.44 MHz
            CLK_SYSX3                                 : in  std_logic;                                 --  3x(CLK_SYS) :  92.16 MHz
            CLK_SYSX4                                 : in  std_logic;                                 --  4x(CLK_SYS) : 122.88 MHz
            CLK_SYSX5                                 : in  std_logic;                                 --  5x(CLK_SYS) : 153.60 MHz
            CLK_SYSX6                                 : in  std_logic;                                 --  6x(CLK_SYS) : 184.32 MHz
            CLK_SYSX8                                 : in  std_logic;                                 --  8x(CLK_SYS) : 245.76 MHz
            CLK_SYSX10                                : in  std_logic;                                 -- 10x(CLK_SYS) : 307.20 MHz
            CLK_SYSX12                                : in  std_logic;                                 -- 12x(CLK_SYS) : 368.64 MHz
            CLK_SYSX16                                : in  std_logic;                                 -- 16x(CLK_SYS) : 491.52 MHz
            CLK_SYSX20                                : in  std_logic;                                 -- 20x(CLK_SYS) : 614.40 MHz
    
            -- PLL Lock
            INT_SYSPLL_LOCK_IN                        : in  std_logic;                                 -- Internal System PLL Lock 
    
            -- DL/FB Latency
            DPD_DL_PROC_DLY_OUT                       : out std_logic_vector(31 downto 0);             -- Downlink Latency Information (Unit : Clock)
            DPD_FB_PROC_DLY_OUT                       : out std_logic_vector(31 downto 0);             -- Feedback Latency Information (Unit : Clock)
            DPD_UL_PROC_DLY_OUT                       : out std_logic_vector(31 downto 0);             -- Uplink   Latency Information (Unit : Clock)
            
            -- TDD/FS Strobe 
            DL_BFN_STRB_IN                            : in  std_logic;                                 -- Downlink 10ms Frame Sync Strobe
            DL_TDD_IN                                 : in  std_logic;                                 -- Downlink TDD Strobe
            DL_SSB_STRB_IN                            : in  std_logic;                                 -- 40ms sync signal for SSB power measurement
            
            DL_BFN_STRB_OUT                           : out std_logic;                                 -- Delayed Downlink 10ms Frame Sync Strobe as DL Path Latency 
            DL_TDD_OUT                                : out std_logic;                                 -- Delayed Downlink TDD Strobe as DL Path Latency 
            DL_SSB_STRB_OUT                           : out std_logic;                                 -- 40ms sync signal for SSB power measurement
            
            FB_BFN_STRB_IN                            : in  std_logic;                                 -- Feedback 10ms Frame Sync Strobe
            FB_TDD_IN                                 : in  std_logic;                                 -- Feedback TDD Strobe
            FB_SSB_STRB_IN                            : in  std_logic;                                 -- 40ms sync signal for SSB power measurement
            
            UL_BFN_STRB_IN                            : in  std_logic;                                 -- Uplink 10ms Frame Sync Strobe
            UL_TDD_IN                                 : in  std_logic;                                 -- Uplink TDD Strobe
            
            UL_BFN_STRB_OUT                           : out std_logic;                                 -- Delayed Uplink 10ms Frame Sync Strobe as UL Path Latency 
            UL_TDD_OUT                                : out std_logic;                                 -- Delayed Uplink TDD Strobe as DL Path Latency 
    
            DL_BCF_ENB_IN                             : in  std_logic;
            DL_BCF_ENB_OUT                            : out std_logic;
    
            UL_BCF_ENB_IN                             : in  std_logic;
            UL_BCF_ENB_OUT                            : out std_logic;
    
            -- Traffic IQ
            DL_SYNC_IN                                : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- CFR-HC output IQ sample valid
            DL_I_IN                                   : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- CFR-HC output I data
            DL_Q_IN                                   : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- CFR-HC output Q data
    
            DL_INTERBAND_SYNC_IN                      : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- InterBand PIM DUC output IQ sample valid
            DL_INTERBAND_I_IN                         : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- InterBand PIM DUC output I data
            DL_INTERBAND_Q_IN                         : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- InterBand PIM DUC output Q data
    
            DL_SYNC_OUT                               : out std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output IQ sample valid
            DL_I_OUT                                  : out std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output I data
            DL_Q_OUT                                  : out std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DL_DPD_TOP output Q data
    
    
            FB_SYNC_IN                                : in  std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback Path IQ sample valid
            FB_I_IN                                   : in  std_logic_array16(FB_PATH_NUM-1 downto 0); -- Feedback Path I data
            FB_Q_IN                                   : in  std_logic_array16(FB_PATH_NUM-1 downto 0); -- Feedback Path Q data
    
            UL_SYNC_IN                                : in  std_logic_vector( RX_ANT_NUM-1 downto 0);  -- UL DACIF output IQ sample valid
            UL_I_IN                                   : in  std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DACIF output I data
            UL_Q_IN                                   : in  std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DACIF output Q data
    
            UL_SYNC_OUT                               : out std_logic_vector( RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output IQ sample valid
            UL_I_OUT                                  : out std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output I data
            UL_Q_OUT                                  : out std_logic_array16(RX_ANT_NUM-1 downto 0);  -- UL DPD_TOP output Q data
    
            -- Feedback Switch
            FBSW_START_TRIG_IN                        : in  std_logic;                                 -- Start Pulse of Feedback Switch Period
            FBSW_AUTO_MODE_DONE_IN                    : in  std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback Switch Automode Done Flag, '0': Auto Mode
            FBSW_MANUAL_MODE_IN                       : in  std_logic;                                 -- Feedback Switch Manual Mode, '1': Manual Mode
            FBSW_CNT_IN                               : in  std_logic_vector( 4 downto 0);             -- Feedback Switch Counter
            FBSW_VAL_OUT                              : out std_logic_vector( 3 downto 0);             -- Encoded Feedback Switch Value
    
            FBSW_SC_PATH_SEL_OUT                      : out std_logic_vector( 4 downto 0);
            PWR_MSR_FB_SYNC_IN                        : in  std_logic;
            PWR_MSR_EN_IN                             : in  std_logic;
    
            FBSW_SSB_IND_FLAG                         : in  std_logic;
    
            -- Control & Status
            SIG_SUS_DLOFF_IN                          : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- Wave-Stop Flag
    
            DL_NCO_WEN_IN                             : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- Downlink NCO (before DPD) Word Write Enable
            DL_NCO_DATA_IN                            : in  std_logic_array32(TX_ANT_NUM-1 downto 0);  -- Downlink NCO (before DPD) Word Value 
    
            DPD_BYPASS_IN                             : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DPD-CORE Bypass '1': Bypass 
            DPD_HC_TRSHD_IN                           : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DPD-HC Threshold Value
            DPD_HC_FLAG_OUT                           : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- DPD Hard-Clipping Flag
            DPD_DATT_IN                               : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- DPD-Digital Attenuator Atten Value
            DPD_FILTER_BYPASS_IN                      : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Bypass '1': Bypass 
    
            COEF_WREN_IN                              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Coefficient Write Enable
            COEF_RDEN_IN                              : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Coefficient Read  Enable
            COEF_WR_DONE_IN                           : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DPD-OutFilter Coefficient Write Done 
            COEF_ADDR_IN                              : in  std_logic_vector( 7 downto 0);             -- DPD-OutFilter Coefficient Write/Read Address
            COEF_WR_DATA_IN                           : in  std_logic_vector(15 downto 0);             -- DPD-OutFilter Coefficient Write Data
            COEF_RD_DATA_OUT                          : out std_logic_vector(15 downto 0);             -- DPD-OutFilter Coefficient Read  Data
    
            DACIF_BYPASS_IN                           : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DACIF_ON Block Bypass
            DACIF_ON_IN                               : in  std_logic_vector( TX_ANT_NUM-1 downto 0);  -- DACIF_ON Block Control Register form CPU 
    
            FB_NCO_WEN_IN                             : in  std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback NCO Word Write Enable
            FB_NCO_WORD_IN                            : in  std_logic_array32(FB_PATH_NUM-1 downto 0); -- Feedback NCO Word Value
    
            FB_FILTER_BYPASS_IN                       : in  std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback Filter Bypass
    
            FB_PWR_MSR_BFN_STRB_OUT                   : out std_logic;                                 -- Feedback Power Measure Input BFN Strobe
            FB_PWR_MSR_DONE_OUT                       : out std_logic_vector( FB_PATH_NUM-1 downto 0); -- Feedback Power Measure Done Flag
            FB_PWR_OUT                                : out std_logic_array32(FB_PATH_NUM-1 downto 0); -- Power Value(Mantissa Format) at Feedback Path
    
            DL_PWR_OUT                                : out std_logic_array32(TX_ANT_NUM-1 downto 0); 
    
            FB_FWD_DATT_IN                            : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- Feedback Forward Side Digital Atten Value
            FB_RVS_DATT_IN                            : in  std_logic_array16(TX_ANT_NUM-1 downto 0);  -- Feedback Reverse Side Digital Atten Value
    
            PIM_DETECTOR_ON_IN                        : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
            PIM_MITIGATOR_ON_IN                       : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
            PIM_CFR_REF_SEL_IN                        : in  std_logic_vector( RX_ANT_NUM-1 downto 0);
    
            PIM_PNPC_SEL_IN                           : in  std_logic_array2( RX_ANT_NUM-1 downto 0);
            
            PIM_CORE_BYPASS_IN                        : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM Core Bypass
    
            PIM_FILTER_BYPASS_IN                      : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM Low Pass Filter Bypass
            PIM_FILTER_COEF_WR_EN_IN                  : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM LPF coefficient write enable(indirect)
            PIM_FILTER_COEF_RD_EN_IN                  : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM LPF coefficient read  enable(indirect)
            PIM_FILTER_COEF_WR_DN_IN                  : in  std_logic_vector( RX_ANT_NUM-1 downto 0); -- PIM LPF coefficient write done(indirect)
            PIM_FILTER_COEF_ADDR_IN                   : in  std_logic_vector( 7 downto 0);            -- PIM LPF coefficient write address
            PIM_FILTER_COEF_WR_DATA_IN                : in  std_logic_vector(15 downto 0);            -- PIM LPF coefficient write data(indirect) 
            PIM_FILTER_COEF_RD_DATA_OUT               : out std_logic_vector(15 downto 0);            -- PIM LPF coefficient read  data(indirect) 
    
            PIM_NCO_WREN_IN                           : in  std_logic;
            PIM_NCO_WORD_IN                           : in  std_logic_vector(31 downto 0);
    
            PIM_INTERBAND_DUC_GAIN_IN                 : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
    
            UL_PIM_NCO_WREN_IN                        : in  std_logic;
            UL_PIM_NCO_WORD_IN                        : in  std_logic_vector(31 downto 0);
    
            DPD_INFO_OUT                              : out std_logic_vector(31 downto 0);             -- DPD_TOP Information
            DPD_STRUCT_OUT                            : out std_logic_vector(31 downto 0);             -- DPD_TOP Structure Information 
            DPD_DATE_OUT                              : out std_logic_vector(31 downto 0);             -- DPD_TOP Date
    
            -- Dump & Test
            SC_LB_ON_IN                               : in  std_logic;                                 -- Loopback Enable for Smart Capture Test, Test Only
    
            DACIF_PHTEST_ENB_IN                       : in  std_logic;                                 -- '1': Phase test enable, '0': disable
            DACIF_PHTEST_REF_SEL_IN                   : in  std_logic;                                 -- '1': BFN_STRB, '0': TDD 
            DACIF_PHTEST_PATH_AB_SWAP_IN              : in  std_logic;                                 -- '1': Swap A/B, '0': normal
            DACIF_PHTEST_PATH_REVERSE_IN              : in  std_logic;                                 -- '1': Reverse 0 <-> (TX_ANT_NUM-1), '0': normal
            DACIF_PHTEST_REPEAT_ENB_IN                : in  std_logic;                                 -- '1': Repeat enable, '0': repeat disable
            DACIF_PHTEST_DACIF_DEFAULT_IN             : in  std_logic_vector(TX_ANT_NUM-1 downto 0);   -- DACIF default value for phase test
    
            DACIF_PHTEST_OFFSET_IN                    : in  std_logic_vector(23 downto 0);             -- Offset from BFN_STRB/TDD
            DACIF_PHTEST_PERIOD_IN                    : in  std_logic_vector(23 downto 0);             -- Period on/off for one path
            DACIF_PHTEST_ON_DURATION_IN               : in  std_logic_vector(23 downto 0);             -- On duration of one period
    
            DBG_SIG_OUT                               : out std_logic_array32(1 downto 0);             -- For Block Debugging, Reserved Output
    
            DUMP_POINT_SEL_STRB_IN                    : in  std_logic;
            DUMP_POINT_SEL_IN                         : in  std_logic_vector( 7 downto 0);             -- Dump Point Selection
            DUMP_BFN_STRB_OUT                         : out std_logic_vector( 1 downto 0);             -- Delayed 10ms Frame Sync Strobe for DUMP                 
            DUMP_DVLD_OUT                             : out std_logic_vector( 1 downto 0);             -- Dump Sample Valid
            DUMP_DATA_OUT                             : out std_logic_array32(1 downto 0)              -- Dump Sample            
        );         
    end component;

    component DSP_DUMP_MUX is
        generic(
            DUMP_CLK0_SEL                 : natural :=  8;                     -- (Operation_Clock)/30.72MHz
            DUMP_CLK1_SEL                 : natural := 10                      -- (Operation_Clock)/30.72MHz
            );
        port(
            RST_CPU                       : in  std_logic;                     -- Reset, Active High

            CLK_SYS                       : in  std_logic;                     -- System Clock :  30.72 MHz
            CLK_SYSX2                     : in  std_logic;                     --  2x(CLK_SYS) :  61.44 MHz
            CLK_SYSX3                     : in  std_logic;                     --  3x(CLK_SYS) :  92.16 MHz
            CLK_SYSX4                     : in  std_logic;                     --  4x(CLK_SYS) : 122.88 MHz
            CLK_SYSX5                     : in  std_logic;                     --  5x(CLK_SYS) : 153.60 MHz
            CLK_SYSX6                     : in  std_logic;                     --  6x(CLK_SYS) : 184.32 MHz
            CLK_SYSX8                     : in  std_logic;                     --  8x(CLK_SYS) : 245.76 MHz
            CLK_SYSX10                    : in  std_logic;                     -- 10x(CLK_SYS) : 307.20 MHz
            CLK_SYSX12                    : in  std_logic;                     -- 12x(CLK_SYS) : 368.64 MHz
            CLK_SYSX16                    : in  std_logic;                     -- 16x(CLK_SYS) : 491.52 MHz
            CLK_SYSX20                    : in  std_logic;                     -- 20x(CLK_SYS) : 614.40 MHz

            DUMP_POINT_SEL_STRB_IN        : in  std_logic;
            DUMP_POINT_SEL_IN             : in  std_logic_vector( 7 downto 0); -- Dump Point Selection

            DUMP_DDUC_BFN_STRB_IN          : in  std_logic_vector( 1 downto 0); -- Delayed 10ms Frame Sync Strobe for DUMP DDUC
            DUMP_DDUC_DVLD_IN              : in  std_logic_vector( 1 downto 0); -- Dump DDUC Sample Valid
            DUMP_DDUC_DATA_IN              : in  std_logic_array32(1 downto 0); -- Dump DDUC Sample

            DUMP_CFR_BFN_STRB_IN          : in  std_logic_vector( 1 downto 0); -- Delayed 10ms Frame Sync Strobe for DUMP CFR
            DUMP_CFR_DVLD_IN              : in  std_logic_vector( 1 downto 0); -- Dump CFR Sample Valid
            DUMP_CFR_DATA_IN              : in  std_logic_array32(1 downto 0); -- Dump CFR Sample

            DUMP_DPD_BFN_STRB_IN          : in  std_logic_vector( 1 downto 0); -- Delayed 10ms Frame Sync Strobe for DUMP DPD
            DUMP_DPD_DVLD_IN              : in  std_logic_vector( 1 downto 0); -- Dump DPD Sample Valid
            DUMP_DPD_DATA_IN              : in  std_logic_array32(1 downto 0); -- Dump DPD Sample

            DUMP_DSP_BFN_STRB_OUT         : out std_logic_vector( 1 downto 0); -- Delayed 10ms Frame Sync Strobe for DUMP
            DUMP_DSP_DVLD_OUT             : out std_logic_vector( 1 downto 0); -- Dump DSP Sample Valid
            DUMP_DSP_DATA_OUT             : out std_logic_array32(1 downto 0)  -- Dump DSP Sample
        );
    end component;

    constant ZEROS                              : std_logic_vector(31 downto 0) := (others => '0');
    constant DSP_TOP_ID                         : std_logic_vector( 7 downto 0) := x"40";        -- DSP TOP ID : 0x40, Fixed
    constant CODE_ID                            : std_logic_vector( 3 downto 0) := x"0" ;        -- SEC : 0x0, SRC : 0x1
    constant CODE_REVISION                      : std_logic_vector( 3 downto 0) := x"0" ;

    constant DSP_INFO                           : std_logic_vector(31 downto 0) := DSP_TOP_ID&CODE_ID&CODE_REVISION&ZEROS(15 downto 0);
    constant DSP_STRUCT                         : std_logic_vector(31 downto 0) := DSP_TOP_ID&CODE_ID&CODE_REVISION&ZEROS(15 downto 0);
    constant DSP_DATE                           : std_logic_vector(31 downto 0) := x"2023_0913";

    signal dsp_info_dsp                         : std_logic_vector(31 downto 0);
    signal dsp_struct_dsp                       : std_logic_vector(31 downto 0);
    signal dsp_date_dsp                         : std_logic_vector(31 downto 0);

    signal dduc_info_dduc                       : std_logic_vector(31 downto 0);
    signal dduc_struct_dduc                     : std_logic_vector(31 downto 0);
    signal dduc_date_dduc                       : std_logic_vector(31 downto 0);

    signal cfr_info_cfr                         : std_logic_vector(31 downto 0);
    signal cfr_struct_cfr                       : std_logic_vector(31 downto 0);
    signal cfr_date_cfr                         : std_logic_vector(31 downto 0);

    signal dpd_info_dpd                         : std_logic_vector(31 downto 0);
    signal dpd_struct_dpd                       : std_logic_vector(31 downto 0);
    signal dpd_date_dpd                         : std_logic_vector(31 downto 0);

    signal duc_proc_dly_dduc                    : std_logic_vector(31 downto 0);
    signal ddc_proc_dly_dduc                    : std_logic_vector(31 downto 0);
    signal cfr_proc_dly_cfr                     : std_logic_vector(31 downto 0);

    signal dpd_dl_proc_dly_dpd                  : std_logic_vector(31 downto 0);
    signal dpd_fb_proc_dly_dpd                  : std_logic_vector(31 downto 0);
    signal dpd_ul_proc_dly_dpd                  : std_logic_vector(31 downto 0);

    signal duc_nco_wen_dduc                     : std_logic_vector(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);
    signal duc_nco_data_dduc                    : std_logic_array32(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);
    signal duc_gain_dduc                        : std_logic_array16(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);

    signal duc2ant_sel_cpuif                    : std_logic_vector((TX_ANT_NUM*DL_BBIQARY_NUM/2)*2*TX_ANT_NUM-1 downto 0);
    signal duc2ant_sum_mode_cpuif               : std_logic_vector((TX_ANT_NUM*DL_BBIQARY_NUM/2)-1 downto 0);
    signal dl_path_att_cpuif                    : std_logic_array16(TX_ANT_NUM-1 downto 0);

    signal dl_path_dly_cpuif                    : std_logic_array12(TX_ANT_NUM-1 downto 0);
    signal ul_path_dly_cpuif                    : std_logic_array12(RX_ANT_NUM-1 downto 0);

    signal ddc_nco_wen_cpuif                    : std_logic_vector(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);
    signal ddc_nco_data_cpuif                   : std_logic_array32(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);
    signal ddc_gain_cpuif                       : std_logic_array16(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);

    signal ul_ant_sel_cpuif                     : std_logic_array8((RX_ANT_NUM*UL_BBIQARY_NUM)/2-1 downto 0);

    signal ul_adc_pwr_dduc                      : std_logic_array32(RX_ANT_NUM-1 downto 0);
    
    -- CFR Control & Status
    signal cfr_bypass_cpuif                     : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal cfr_thrsd_cpuif                      : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal cfr_peak_spacing_cpuif               : std_logic_array8(TX_ANT_NUM-1 downto 0);
    signal cfr_hc_thrsd_cpuif                   : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal cfr_hc_en_cpuif                      : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal cfr_tap_num_cpuif                    : std_logic_array10((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
    signal cfr_coeff_update_enb_cpuif           : std_logic_vector((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
    signal cfr_coeff_wraddr_cpuif               : std_logic_array10((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
    signal cfr_coeff_wrdata_cpuif               : std_logic_array32((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
    signal cfr_coeff_wen_cpuif                  : std_logic_vector((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
    signal cfr_pwr_msr_udt_cfr                  : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal cfr_pwr_cfr                          : std_logic_array32(TX_ANT_NUM-1 downto 0);
    signal opd_thrsd_cpuif                      : std_logic_array32(TX_ANT_NUM-1 downto 0);
    signal opd_pwr_cfr                          : std_logic_array32(TX_ANT_NUM-1 downto 0);
    signal sig_sus_flag_cfr                     : std_logic_vector(TX_ANT_NUM-1 downto 0);

    -- DPD Control & Status
    signal dl_nco_wen_cpuif                     : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal dl_nco_data_cpuif                    : std_logic_array32(TX_ANT_NUM-1 downto 0);

    signal dpd_bypass_cpuif                     : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal dpd_hc_trshd_cdc_strb_cpuif          : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal dpd_hc_trshd_cpuif                   : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal dpd_hc_flag_dpd                      : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal dpd_datt_cdc_strb_cpuif              : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal dpd_datt_cpuif                       : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal dpd_filter_bypass_cpuif              : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal coef_wren_cpuif                      : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal coef_rden_cpuif                      : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal coef_wr_done_cpuif                   : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal coef_addr_cpuif                      : std_logic_vector(8-1 downto 0);
    signal coef_wr_data_cpuif                   : std_logic_vector(16-1 downto 0);
    signal coef_rd_data_dpd                     : std_logic_vector(16-1 downto 0);

    signal dacif_bypass_cpuif                   : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal dacif_on_cpuif                       : std_logic_vector(TX_ANT_NUM-1 downto 0);

    signal fbsw_val_dpd                         : std_logic_vector(4-1 downto 0);
    signal fb_nco_wen_cpuif                     : std_logic_vector(FB_PATH_NUM-1 downto 0);
    signal fb_nco_word_cpuif                    : std_logic_array32(FB_PATH_NUM-1 downto 0);
    signal fb_filter_bypass_cpuif               : std_logic_vector(FB_PATH_NUM-1 downto 0);

    signal fb_pwr_msr_bfn_strb_dpd              : std_logic;
    signal fb_pwr_msr_done_dpd                  : std_logic_vector(FB_PATH_NUM-1 downto 0);
    signal fb_pwr_dpd                           : std_logic_array32(FB_PATH_NUM-1 downto 0);
    signal dl_pwr_dpd                           : std_logic_array32(TX_ANT_NUM-1 downto 0);

    signal fb_datt_strb_cpuif                   : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal fb_fwd_datt_cpuif                    : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal fb_rvs_datt_cpuif                    : std_logic_array16(TX_ANT_NUM-1 downto 0);

    signal pim_detector_on_cpuif                : std_logic_vector(RX_ANT_NUM-1 downto 0);
    signal pim_mitigator_on_cpuif               : std_logic_vector(RX_ANT_NUM-1 downto 0);
    signal pim_cfr_ref_sel_cpuif                : std_logic_vector(RX_ANT_NUM-1 downto 0);
    signal pim_interb_duc_gain_strb             : std_logic;
    signal pim_interb_duc_gain                  : std_logic_array16(RX_ANT_NUM-1 downto 0);
    signal pim_pnpc_sel_strb_cpuif              : std_logic;
    signal pim_pnpc_sel_in_cpuif                : std_logic_array2(RX_ANT_NUM-1 downto 0);
    signal pim_core_bypass_cpuif                : std_logic_vector(RX_ANT_NUM-1 downto 0);
    signal pim_nco_wren_cpuif                   : std_logic;
    signal pim_nco_word_cpuif                   : std_logic_vector(32-1 downto 0);

    signal pim_filter_bypass_cpuif              : std_logic_vector(RX_ANT_NUM-1 downto 0);
    signal pim_filter_coef_wr_en_cpuif          : std_logic_vector(RX_ANT_NUM-1 downto 0);
    signal pim_filter_coef_rd_en_cpuif          : std_logic_vector(RX_ANT_NUM-1 downto 0);
    signal pim_filter_coef_wr_dn_cpuif          : std_logic_vector(RX_ANT_NUM-1 downto 0);
    signal pim_filter_coef_addr_cpuif           : std_logic_vector(8-1 downto 0);
    signal pim_filter_coef_wr_data_cpuif        : std_logic_vector(16-1 downto 0);
    signal pim_filter_coef_rd_data_cpuif        : std_logic_vector(16-1 downto 0);

    signal ul_pim_nco_wren_cpuif                : std_logic;
    signal ul_pim_nco_word_cpuif                : std_logic_vector(32-1 downto 0);

    signal sc_lb_on_cpuif                       : std_logic;
    signal dsp_test_lb_test                     : std_logic;
    signal dsp_test_lb_test_1d                  : std_logic;
    signal dsp_test_lb_test_2d                  : std_logic;

    signal dl_bfn_strb_dduc                     : std_logic;
    signal dl_tdd_dduc                          : std_logic;    

    signal dl_bfn_strb_cfr                      : std_logic;
    signal dl_tdd_cfr                           : std_logic;
    signal dl_ssb_strb_cfr                      : std_logic; -- 40ms sync signal for SSB power measurment, 19.10.03

    signal ul_bfn_strb_pim                      : std_logic;
    signal ul_tdd_pim                           : std_logic;

    signal bcf_enb_dduc                         : std_logic;
    signal bcf_enb_cfr                          : std_logic;

    signal dl_sync_dduc                         : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal dl_i_dduc                            : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal dl_q_dduc                            : std_logic_array16(TX_ANT_NUM-1 downto 0);

    signal dl_sync_cfr                          : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal dl_i_cfr                             : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal dl_q_cfr                             : std_logic_array16(TX_ANT_NUM-1 downto 0);

    signal pim_ul_sync                          : std_logic_vector(RX_ANT_NUM-1 downto 0);
    signal pim_ul_i                             : std_logic_array16(RX_ANT_NUM-1 downto 0);
    signal pim_ul_q                             : std_logic_array16(RX_ANT_NUM-1 downto 0);

    signal in_pim_ul_i                          : std_logic_array16(RX_ANT_NUM-1 downto 0);
    signal in_pim_ul_q                          : std_logic_array16(RX_ANT_NUM-1 downto 0);
    
    -- *******************************
    -- DUMPIF Signals
    -- *******************************
    signal dump_point_sel_strb_cpuif            : std_logic;
    signal dump_point_sel_cpuif                 : std_logic_vector(8-1 downto 0);

    signal dump_bfn_strb_dduc                   : std_logic_vector( 1 downto 0);
    signal dump_dvld_dduc                       : std_logic_vector( 1 downto 0);
    signal dump_data_dduc                       : std_logic_array32(1 downto 0);

    signal dump_bfn_strb_cfr                    : std_logic_vector( 1 downto 0);
    signal dump_dvld_cfr                        : std_logic_vector( 1 downto 0);
    signal dump_data_cfr                        : std_logic_array32(1 downto 0);

    signal dump_bfn_strb_dpd                    : std_logic_vector( 1 downto 0);
    signal dump_dvld_dpd                        : std_logic_vector( 1 downto 0);
    signal dump_data_dpd                        : std_logic_array32(1 downto 0);

    -- attribute mark_debug : string;

begin

-- DSP Version
    dsp_info_dsp                     <=  DSP_INFO;
    dsp_struct_dsp                   <=  DSP_STRUCT;
    dsp_date_dsp                     <=  DSP_DATE;

-- *************************************************************************************
-- CPU Interface - DSP Block(DDUC/CFR/DPD) Control
-- *************************************************************************************
    U_CPUIF_DSP : CPUIF_DSP_COMMON
        generic map(
            ADDR_WIDTH                   => ADDR_WIDTH                   , -- CPU Address Bitwidth
            WDATA_WIDTH                  => WDATA_WIDTH                  , -- CPU Write Data Bitwidth
            RDATA_WIDTH                  => RDATA_WIDTH                    -- CPU Read  Data Bitwidth
        )
        port map(
            -- Reset & Clock
            RST_CPUIF                    => RST_CPUIF                    , -- CPUIF Reset, '1': Reset
            CLK_CPUIF                    => CLK_CPUIF                    , -- CPUIF Clock, faster than iclk/oclk

            CLK_SYS                      => CLK_SYS                      , -- System Clock :  30.72 MHz
            CLK_SYSX2                    => CLK_SYSX2                    , --  2x(CLK_SYS) :  61.44 MHz
            CLK_SYSX3                    => CLK_SYSX3                    , --  3x(CLK_SYS) :  92.16 MHz
            CLK_SYSX4                    => CLK_SYSX4                    , --  4x(CLK_SYS) : 122.88 MHz
            CLK_SYSX5                    => CLK_SYSX5                    , --  5x(CLK_SYS) : 153.60 MHz
            CLK_SYSX6                    => CLK_SYSX6                    , --  6x(CLK_SYS) : 184.32 MHz
            CLK_SYSX8                    => CLK_SYSX8                    , --  8x(CLK_SYS) : 245.76 MHz
            CLK_SYSX10                   => CLK_SYSX10                   , -- 10x(CLK_SYS) : 307.20 MHz
            CLK_SYSX12                   => CLK_SYSX12                   , -- 12x(CLK_SYS) : 368.64 MHz
            CLK_SYSX16                   => CLK_SYSX16                   , -- 16x(CLK_SYS) : 491.52 MHz
            CLK_SYSX20                   => CLK_SYSX20                   , -- 20x(CLK_SYS) : 614.40 MHz

            -- CPU Interface
            ADDR_CPUIF_IN                => ADDR_CPUIF_IN                , -- CPUIF Address Input, WORD Address
            WDATA_CPUIF_IN               => WDATA_CPUIF_IN               , -- CPUIF Data Input
            RDATA_CPUIF_OUT              => RDATA_CPUIF_OUT              , -- CPUIF DATA Output
            WREN_CPUIF_IN                => WREN_CPUIF_IN                , -- CPUIF Write Enable,    '1': Active, Synchronous with iclk
            RDEN_CPUIF_IN                => RDEN_CPUIF_IN                , -- CPUIF Read Enable,     '1': Active,
            RDVLD_CPUIF_OUT              => RDVLD_CPUIF_OUT              , -- CPUIF Read Data Valid, '1': Active, Synchronous with clk_cpu

            -- TDD/FS Strobe
            DL_BFN_STRB_IN               => dl_bfn_strb_cfr              , -- Downlink 10ms Frame Sync Strobe
            FB_BFN_STRB_IN               => fb_pwr_msr_bfn_strb_dpd      , -- Feedback 10ms Frame Sync Strobe

            -- Feedback Switch
            FBSW_AUTO_MODE_DONE_IN       => FBSW_AUTO_MODE_DONE_IN       , -- Feedback Switch Automode Done Flag, '0': Auto Mode
            FBSW_CNT_IN                  => FBSW_CNT_IN(4 downto 0)      , -- Feedback Switch Counter
            FBSW_VALUE_IN                => fbsw_val_dpd                 , -- Feedback Switch Encoded Value
            FBSW_PWR_MSR_UDT_IN          => FBSW_PWR_MSR_UDT_IN          , -- Feedback Switch Measure Done, Feedback Power Measure Update Enable

            -- DSP_TOP Version & Test
            DSP_TOP_MODULE_INFO_IN       => dsp_info_dsp                 , -- DSP_TOP Module Information
            DSP_TOP_MODULE_STRUCT_IN     => dsp_struct_dsp               , -- DSP_TOP Module Structure Information
            DSP_TOP_MODULE_DATE_IN       => dsp_date_dsp                 , -- DSP_TOP Module Date

            DSP_DUMP_SEL_STRB_OUT        => dump_point_sel_strb_cpuif    , -- DSP_TOP Dump Selection Strobe
            DSP_DUMP_SEL_OUT             => dump_point_sel_cpuif         , -- DSP_TOP Dump Selection

            -- DDUC Control & Status
            DDUC_TOP_MODULE_INFO_IN      => dduc_info_dduc               , -- DDUC_TOP Module Information
            DDUC_TOP_MODULE_STRUCT_IN    => dduc_struct_dduc             , -- DDUC_TOP Module Structure Information
            DDUC_TOP_MODULE_DATE_IN      => dduc_date_dduc               , -- DDUC_TOP Module Date

            DDUC_DL_PROC_DLY_IN          => duc_proc_dly_dduc            , -- DDUC_TOP DownLink Path Latency
            DDUC_UL_PROC_DLY_IN          => ddc_proc_dly_dduc            , -- DDUC_TOP UpLink   Path Latency

            DDUC_DL_PATH_ATT_OUT         => dl_path_att_cpuif            ,
            DDUC_DL_PATH_DLY_OUT         => dl_path_dly_cpuif            ,
            DDUC_UL_PATH_DLY_OUT         => ul_path_dly_cpuif            ,

            DDUC_DUC_NCO_WEN_OUT         => duc_nco_wen_dduc             ,
            DDUC_DUC_NCO_DATA_OUT        => duc_nco_data_dduc            ,
            DDUC_DUC_GAIN_OUT            => duc_gain_dduc                ,

            DDUC_DUC_TO_ANT_SUM_MODE_OUT => duc2ant_sum_mode_cpuif       ,
            DDUC_DUC_TO_ANT_SEL_OUT      => duc2ant_sel_cpuif            ,

            DDUC_DDC_NCO_WEN_OUT         => ddc_nco_wen_cpuif            ,
            DDUC_DDC_NCO_DATA_OUT        => ddc_nco_data_cpuif           ,
            DDUC_DDC_GAIN_OUT            => ddc_gain_cpuif               ,

            DDUC_UL_TO_ANT_SEL_OUT       => ul_ant_sel_cpuif             ,

            DDUC_UL_ADC_PWR_IN           => ul_adc_pwr_dduc              ,

            -- CFR Control & Status
            CFR_TOP_MODULE_INFO_IN       => cfr_info_cfr                 ,
            CFR_TOP_MODULE_STRUCT_IN     => cfr_struct_cfr               ,
            CFR_TOP_MODULE_DATE_IN       => cfr_date_cfr                 ,

            CFR_DL_PROC_DLY_IN           => cfr_proc_dly_cfr             ,
            CFR_CORE_BYPASS_OUT          => cfr_bypass_cpuif             ,        

            CFR_THRSD_OUT                => cfr_thrsd_cpuif              ,
            CFR_PEAK_SPACING_OUT         => cfr_peak_spacing_cpuif       ,
            CFR_HC_THRSD_OUT             => cfr_hc_thrsd_cpuif           ,
            CFR_HC_ENB_OUT               => cfr_hc_en_cpuif              ,

            CFR_TAP_NUM_OUT              => cfr_tap_num_cpuif            ,
            CFR_COEF_UPDATE_ENB_OUT      => cfr_coeff_update_enb_cpuif   ,
            CFR_COEF_ADDR_OUT            => cfr_coeff_wraddr_cpuif       ,
            CFR_COEF_WDATA_OUT           => cfr_coeff_wrdata_cpuif       ,
            CFR_COEF_WEN_OUT             => cfr_coeff_wen_cpuif          ,

            CFR_PWR_MSR_UDT_IN           => cfr_pwr_msr_udt_cfr          ,
            CFR_PWR_IN                   => cfr_pwr_cfr                  ,

            CFR_OPD_TRSHD_OUT            => opd_thrsd_cpuif              ,
            CFR_OPD_FLAG_IN              => sig_sus_flag_cfr             ,
            CFR_OPD_PWR_IN               => opd_pwr_cfr                  ,

            -- DPD/FB Control & Status
            DPD_TOP_MODULE_INFO_IN       => dpd_info_dpd                 , -- DPD_TOP Module Information
            DPD_TOP_MODULE_STRUCT_IN     => dpd_struct_dpd               , -- DPD_TOP Module Structure Information
            DPD_TOP_MODULE_DATE_IN       => dpd_date_dpd                 , -- DPD_TOP Module Date

            DPD_DL_PROC_DLY_IN           => dpd_dl_proc_dly_dpd          , -- DPD_TOP DownLink Path Latency
            DPD_FB_PROC_DLY_IN           => dpd_fb_proc_dly_dpd          , -- DPD_TOP FeedBack Path Latency
            DPD_UL_PROC_DLY_IN           => dpd_ul_proc_dly_dpd          , -- Uplink   Latency Information (Unit : Clock)

            DPD_DL_BULK_NCO_WEN_OUT      => dl_nco_wen_cpuif             , -- DPD_TOP DownLink Bulk NCO Word Write Enable
            DPD_DL_BULK_NCO_WORD_OUT     => dl_nco_data_cpuif            , -- DPD_TOP DownLink Bulk NCO Word

            DPD_CORE_BYPASS_OUT          => dpd_bypass_cpuif             , -- DPD_TOP Core Bypass

            DPD_HC_THRSD_CDC_STRB_OUT    => dpd_hc_trshd_cdc_strb_cpuif  , -- DPD-HC Threshold Value CDC Strobe
            DPD_HC_THRSD_OUT             => dpd_hc_trshd_cpuif           , -- DPD_TOP Hard-Clipper Threshold

            DPD_HC_FLAG_IN               => dpd_hc_flag_dpd              , -- DPD Hard-Clipping Flag
            DPD_DL_ATT_CDC_STRB_OUT      => dpd_datt_cdc_strb_cpuif      , -- DPD-Digital Attenuator Atten Value CDC Strobe
            DPD_DL_ATT_OUT               => dpd_datt_cpuif               , -- DPD_TOP DL Attenuator Value

            DPD_OUTFILTER_BYPASS_OUT     => dpd_filter_bypass_cpuif      , -- DPD_TOP DPD Output Filter Bypass
            DPD_OUTFILTER_COEF_WEN_OUT   => coef_wren_cpuif              , -- DPD_TOP DPD Output Filter Coefficients Write Enable (Indirect Write/Read)
            DPD_OUTFILTER_COEF_REN_OUT   => coef_rden_cpuif              , -- DPD_TOP DPD Output Filter Coefficients Read  Enable (Indirect Write/Read)
            DPD_OUTFILTER_COEF_WRDN_OUT  => coef_wr_done_cpuif           , -- DPD_TOP DPD Output Filter Coefficients Write Done   (Indirect Write/Read)
            DPD_OUTFILTER_COEF_ADDR_OUT  => coef_addr_cpuif              , -- DPD_TOP DPD Output Filter Coefficients Address      (Indirect Write/Read)
            DPD_OUTFILTER_COEF_WDATA_OUT => coef_wr_data_cpuif           , -- DPD_TOP DPD Output Filter Coefficients Write Data   (Indirect Write/Read)
            DPD_OUTFILTER_COEF_RDATA_IN  => coef_rd_data_dpd             , -- DPD_TOP DPD Output Filter Coefficients Read  Data   (Indirect Write/Read)

            DPD_DACIF_ONOFF_BYPASS_OUT   => dacif_bypass_cpuif           , -- DPD_TOP DACIF_IQ_ONOFF Bypass
            DPD_DACIF_ONOFF_ON_OUT       => dacif_on_cpuif               , -- DPD_TOP DACIF_IQ_ONOFF On

            DPD_FB_BULK_NCO_WEN_OUT      => fb_nco_wen_cpuif             , -- DPD_TOP FeedBack Bulk NCO Word Write Enable
            DPD_FB_BULK_NCO_WORD_OUT     => fb_nco_word_cpuif            , -- DPD_TOP FeedBack Bulk NCO Word

            DPD_FB_FILTER_BYPASS_OUT     => fb_filter_bypass_cpuif       , -- DPD_TOP FeedBack Filter Bypass

            DPD_FB_PWR_MSR_DONE_IN       => fb_pwr_msr_done_dpd          , -- DPD_TOP Feedback Power Measurement Done Flag
            DPD_FB_PWR_IN                => fb_pwr_dpd                   , -- DPD_TOP Feedback Power (Mantissa Format)
            DPD_DL_PWR_IN                => dl_pwr_dpd                   ,

            DPD_FB_ATT_CDC_STRB_OUT      => fb_datt_strb_cpuif           , -- Feedback Digital Atten Value CDC Strobe
            DPD_FB_FWD_ATT_OUT           => fb_fwd_datt_cpuif            , -- DPD_TOP Feedback Forward Attenuator Value
            DPD_FB_RVS_ATT_OUT           => fb_rvs_datt_cpuif            , -- DPD_TOP Feedback Reverse Attenuator Value

            PIM_DETECTOR_ON_OUT          => pim_detector_on_cpuif        ,
            PIM_MITIGATOR_ON_OUT         => pim_mitigator_on_cpuif       ,
            PIM_CFR_REF_SEL_OUT          => pim_cfr_ref_sel_cpuif        ,

            PIM_INTERB_DUC_GAIN_STRB_OUT => pim_interb_duc_gain_strb     ,
            PIM_INTERB_DUC_GAIN_OUT      => pim_interb_duc_gain          ,

            PIM_PNPC_SEL_STRB_OUT        => pim_pnpc_sel_strb_cpuif      ,
            PIM_PNPC_SEL_OUT             => pim_pnpc_sel_in_cpuif        ,

            DPD_PIM_CORE_BYPASS_OUT      => pim_core_bypass_cpuif        , -- PIM Core Bypass

            DPD_PIM_BULK_NCO_WEN_OUT     => pim_nco_wren_cpuif           ,
            DPD_PIM_BULK_NCO_WORD_OUT    => pim_nco_word_cpuif           ,

            DPD_PIM_LPF_BYPASS_OUT       => pim_filter_bypass_cpuif      , -- PA Protection Filter Bypass
            DPD_PIM_LPF_COEF_WEN_OUT     => pim_filter_coef_wr_en_cpuif  , -- coefficient write enable(indirect)
            DPD_PIM_LPF_COEF_REN_OUT     => pim_filter_coef_rd_en_cpuif  , -- coefficient read  enable(indirect)
            DPD_PIM_LPF_COEF_WRDN_OUT    => pim_filter_coef_wr_dn_cpuif  , -- coefficient write done(indirect)
            DPD_PIM_LPF_COEF_ADDR_OUT    => pim_filter_coef_addr_cpuif   , -- coefficient write address
            DPD_PIM_LPF_COEF_WDATA_OUT   => pim_filter_coef_wr_data_cpuif, -- coefficient write data(indirect)
            DPD_PIM_LPF_COEF_RDATA_IN    => pim_filter_coef_rd_data_cpuif, -- coefficient read  data(indirect)

            DPD_UL_PIM_NCO_WREN_OUT      => ul_pim_nco_wren_cpuif        ,
            DPD_UL_PIM_NCO_WORD_OUT      => ul_pim_nco_word_cpuif        ,

            -- LoopBack/Dump/TestPattern
            DPD_SC_LB_TEST_ON_OUT        => sc_lb_on_cpuif               ,  -- DPD_TOP DL to FB LoopBack On
            DSP_TEST_LB_OUT              => dsp_test_lb_test                --: out std_logic
        );

    -- *************************************************************************************
    -- DUC & DDC & DL-UL
    -- *************************************************************************************

    U_DDUC_TOP : DDUC_TOP
        generic map(
            DUPLEX_TYPE                  => DUPLEX_TYPE                  ,
            VENDOR                       => VENDOR                       ,
            PBA_NAME                     => PBA_NAME                     ,
            ADDR_WIDTH                   => ADDR_WIDTH                   ,
            WDATA_WIDTH                  => WDATA_WIDTH                  ,
            RDATA_WIDTH                  => RDATA_WIDTH                              
        )
        port map(
            --MODULE RST IF
            RST_DDUC                     => RST_DDUC                     ,
            --SYSCLK IF
            CLK_SYS                      => CLK_SYS                      ,
            CLK_SYSX2                    => CLK_SYSX2                    ,
            CLK_SYSX3                    => CLK_SYSX3                    ,
            CLK_SYSX4                    => CLK_SYSX4                    ,
            CLK_SYSX5                    => CLK_SYSX5                    ,
            CLK_SYSX6                    => CLK_SYSX6                    ,
            CLK_SYSX8                    => CLK_SYSX8                    ,
            CLK_SYSX10                   => CLK_SYSX10                   ,
            CLK_SYSX12                   => CLK_SYSX12                   ,
            CLK_SYSX16                   => CLK_SYSX16                   ,
            CLK_SYSX20                   => CLK_SYSX20                   ,
            INT_SYSPLL_LOCK_IN           => INT_SYSPLL_LOCK_IN           ,
            --MODULE INFO IF
            DDUC_INFO_OUT                => dduc_info_dduc               ,
            DDUC_STRUCT_OUT              => dduc_struct_dduc             ,
            DDUC_DATE_OUT                => dduc_date_dduc               ,
            --MODULE DLY IF
            DUC_PROC_DLY_OUT             => duc_proc_dly_dduc            ,
            DDC_PROC_DLY_OUT             => ddc_proc_dly_dduc            ,
            --DLY CTRL IF
            DL_CRR_DLY_IN                => dl_path_dly_cpuif            ,
            UL_CRR_DLY_IN                => ul_path_dly_cpuif            ,
            --ATT CTRL IF
            DL_PATH_ATT_IN               => dl_path_att_cpuif            ,
            --DUC CTRL IF
            DUC_NCO_WEN_IN               => duc_nco_wen_dduc             ,
            DUC_NCO_DATA_IN              => duc_nco_data_dduc            ,
            DUC_GAIN_IN                  => duc_gain_dduc                ,
            DUC2ANT_SEL_IN               => duc2ant_sel_cpuif            ,
            DUC2ANT_SUM_MODE_IN          => duc2ant_sum_mode_cpuif       ,
            --DDC CTRL IF
            DDC_NCO_WEN_IN               => ddc_nco_wen_cpuif            ,
            DDC_NCO_DATA_IN              => ddc_nco_data_cpuif           ,
            DDC_GAIN_IN                  => ddc_gain_cpuif               ,
            UL_ANT_SEL_IN                => ul_ant_sel_cpuif             ,
            --UL CTRL IF
            UL_ADC_PWR_OUT               => ul_adc_pwr_dduc              ,
            --BBCTRL 2 DSP IF
            DL_SSB_STRB_IN               => DL_SSB_STRB_IN               ,
            DL_BFN_STRB_IN               => DL_BFN_STRB_IN               ,
            DL_TDD_IN                    => '1'                          ,
            DL_CHBW_IN                   => DL_CHBW_IN                   ,
            DL_SYNC_IN                   => DL_SYNC_IN                   ,
            DL_IQ_IN                     => DL_IQ_IN                     ,
            BCF_ENB_IN                   => BCF_ENB_IN                   ,
            --DSP 2 BBCTRL IF
            UL_BFN_STRB_OUT              => UL_BFN_STRB_OUT              ,
            UL_TDD_OUT                   => UL_TDD_OUT                   ,
            UL_CHBW_IN                   => UL_CHBW_IN                   ,
            UL_SYNC_OUT                  => UL_SYNC_OUT                  ,
            UL_IQ_OUT                    => UL_IQ_OUT                    ,
            --DL IQ OUT IF
            DL_SSB_STRB_OUT              => open,
            DL_BFN_STRB_OUT              => dl_bfn_strb_dduc             ,
            DL_TDD_OUT                   => dl_tdd_dduc                  ,
            DL_SYNC_OUT                  => dl_sync_dduc                 ,
            DL_I_OUT                     => dl_i_dduc                    ,
            DL_Q_OUT                     => dl_q_dduc                    ,
            BCF_ENB_OUT                  => bcf_enb_dduc                 ,
            --UL IQ IN IF
            UL_BFN_STRB_IN               => ul_bfn_strb_pim              ,
            UL_TDD_IN                    => ul_tdd_pim                   ,
            UL_SYNC_IN                   => (others=>'0')                ,
            UL_I_IN                      => pim_ul_i                     ,
            UL_Q_IN                      => pim_ul_q                     ,
            --MISC IF
            DL_CLK_ISZERO_OUT            => DL_CLK_ISZERO_OUT            ,
            DL_IQ_ISZERO_OUT             => DL_IQ_ISZERO_OUT             ,
            SIG_SUS_FLAG_OUT             => open                         ,
            SIG_SUS_DLOFF_IN             => (others=>'0')                ,

            --DUMP IF
            DUMP_POINT_SEL_STRB_IN       => dump_point_sel_strb_cpuif    ,
            DUMP_POINT_SEL_IN            => dump_point_sel_cpuif         ,
            DUMP_BFN_STRB_OUT            => dump_bfn_strb_dduc           ,
            DUMP_DVLD_OUT                => dump_dvld_dduc               ,
            DUMP_DATA_OUT                => dump_data_dduc
        );
   
-- *************************************************************************************
-- CFR
-- *************************************************************************************

    U_CFR_TOP : CFR_TOP
        port map(
            CFR_INFO_OUT                 => cfr_info_cfr                 ,
            CFR_STRUCT_OUT               => cfr_struct_cfr               ,
            CFR_DATE_OUT                 => cfr_date_cfr                 ,

            RST_CFR                      => RST_CFR                      ,
            CLK_SYS                      => CLK_SYS                      , -- System Clock :  30.72 MHz
            CLK_SYSX2                    => CLK_SYSX2                    , --  2x(CLK_SYS) :  61.44 MHz
            CLK_SYSX3                    => CLK_SYSX3                    , --  3x(CLK_SYS) :  92.16 MHz
            CLK_SYSX4                    => CLK_SYSX4                    , --  4x(CLK_SYS) : 122.88 MHz
            CLK_SYSX5                    => CLK_SYSX5                    , --  5x(CLK_SYS) : 153.60 MHz
            CLK_SYSX6                    => CLK_SYSX6                    , --  6x(CLK_SYS) : 184.32 MHz
            CLK_SYSX8                    => CLK_SYSX8                    , --  8x(CLK_SYS) : 245.76 MHz
            CLK_SYSX10                   => CLK_SYSX10                   , -- 10x(CLK_SYS) : 307.20 MHz
            CLK_SYSX12                   => CLK_SYSX12                   , -- 12x(CLK_SYS) : 368.64 MHz
            CLK_SYSX16                   => CLK_SYSX16                   , -- 16x(CLK_SYS) : 491.52 MHz
            CLK_SYSX20                   => CLK_SYSX20                   , -- 20x(CLK_SYS) : 614.40 MHz

            INT_SYSPLL_LOCK_IN           => INT_SYSPLL_LOCK_IN           ,

            DL_BFN_STRB_IN               => dl_bfn_strb_dduc             , -- 10msec frame sync
            DL_SSB_STRB_IN               => FBSW_SSB_IND_FLAG_DSP        , -- SSB strb
            DL_BFN_STRB_OUT              => dl_bfn_strb_cfr              , -- 10msec frame sync delayed out
            DL_SSB_STRB_OUT              => dl_ssb_strb_cfr              , -- 10msec frame sync delayed out
            DL_TDD_IN                    => '1'                          , -- TDD strobe signal in
            DL_TDD_OUT                   => dl_tdd_cfr                   , -- Delayed TDD strobe signal out

            DL_BCF_ENB_IN                => bcf_enb_dduc                 ,
            DL_BCF_ENB_OUT               => bcf_enb_cfr                  ,

            FBSW_AUTO_MODE_DONE_IN       => FBSW_AUTO_MODE_DONE_IN       , -- Feedback Switch Automode operation done flag

            CFR_PROC_DLY_OUT             => cfr_proc_dly_cfr             ,

            CFR_BYPASS_IN                => cfr_bypass_cpuif             ,

            CFR_TRSHD_IN                 => cfr_thrsd_cpuif              ,
            CFR_PEAK_SPACING_IN          => cfr_peak_spacing_cpuif       ,

            CFR_COEFF_UDT_ENB_IN         => cfr_coeff_update_enb_cpuif   ,
            CFR_COEFF_WEN_IN             => cfr_coeff_wen_cpuif          ,
            CFR_COEFF_WRADDR_IN          => cfr_coeff_wraddr_cpuif       ,
            CFR_COEFF_WRDATA_IN          => cfr_coeff_wrdata_cpuif       ,

            CFR_TAP_NUM_IN               => cfr_tap_num_cpuif            ,

            DL_SYNC_IN                   => dl_sync_dduc                 ,
            DL_I_IN                      => dl_i_dduc                    ,
            DL_Q_IN                      => dl_q_dduc                    ,

            DL_SYNC_OUT                  => open                         ,
            DL_I_OUT                     => dl_i_cfr                     ,
            DL_Q_OUT                     => dl_q_cfr                     ,

            DL_PIM_SYNC_OUT              => open                         ,
            DL_PIM_I_OUT                 => open                         ,
            DL_PIM_Q_OUT                 => open                         ,

            CFR_HC_TRSHD_IN              => cfr_hc_thrsd_cpuif           ,
            CFR_HC_EN_IN                 => cfr_hc_en_cpuif              ,

            CFR_PWR_MSR_UDT_OUT          => cfr_pwr_msr_udt_cfr          ,
            CFR_PWR_OUT                  => cfr_pwr_cfr                  ,

            OPD_TRSHD_IN                 => opd_thrsd_cpuif              ,
            OPD_PWR_OUT                  => opd_pwr_cfr                  ,
            SIG_SUS_FLAG_OUT             => sig_sus_flag_cfr             ,

            DUMP_BFN_STRB_OUT            => dump_bfn_strb_cfr            ,
            DUMP_DATA_OUT                => dump_data_cfr                ,
            DUMP_DVLD_OUT                => dump_dvld_cfr                ,

            TEST_DATA_IN                 => (others => (others => '0'))  ,
            TEST_ENB_OUT                 => open                         ,

            DBG_SIG_OUT                  => open
        );

    SIG_SUS_FLAG_OUT                    <= sig_sus_flag_cfr;
   
    DL_SYNC_OUT                         <=  '1';   

    process(CLK_SYSX10)
    begin
        if (rising_edge(CLK_SYSX10)) then
            dsp_test_lb_test_1d         <=  dsp_test_lb_test;
            dsp_test_lb_test_2d         <=  dsp_test_lb_test_1d;
            if (dsp_test_lb_test_2d = '1') then
                in_pim_ul_i             <=  dl_i_dduc;
                in_pim_ul_q             <=  dl_q_dduc;
            else
                in_pim_ul_i             <=  UL_I_IN;
                in_pim_ul_q             <=  UL_Q_IN;
            end if;
        end if;
    end process;
    
-- *************************************************************************************
-- DPD & Feedback
-- *************************************************************************************
  
    U_DPD_TOP : DPD_TOP
        port map(
            -- CPU Interface
            RST_CPUIF                       => RST_CPUIF                     ,
            CLK_CPUIF                       => CLK_CPUIF                     ,

            ADDR_CPUIF_IN                   => ADDR_DPDIF_IN                 ,
            WDATA_CPUIF_IN                  => WDATA_DPDIF_IN                ,
            RDATA_CPUIF_OUT                 => RDATA_DPDIF_OUT               ,
            WREN_CPUIF_IN                   => WREN_DPDIF_IN                 ,
            RDEN_CPUIF_IN                   => RDEN_DPDIF_IN                 ,
            RDVLD_CPUIF_OUT                 => RDVLD_DPDIF_OUT               ,

            -- Reset & Clock
            RST_DPD                         => RST_DPD                      ,
            RST_PIM                         => RST_PIM                      ,
            CLK_SYS                         => CLK_SYS                      ,
            CLK_SYSX2                       => CLK_SYSX2                    ,
            CLK_SYSX3                       => CLK_SYSX3                    ,
            CLK_SYSX4                       => CLK_SYSX4                    ,
            CLK_SYSX5                       => CLK_SYSX5                    ,
            CLK_SYSX6                       => CLK_SYSX6                    ,
            CLK_SYSX8                       => CLK_SYSX8                    ,
            CLK_SYSX10                      => CLK_SYSX10                   ,
            CLK_SYSX12                      => CLK_SYSX12                   ,
            CLK_SYSX16                      => CLK_SYSX16                   ,
            CLK_SYSX20                      => CLK_SYSX20                   ,

            -- PLL Lock
            INT_SYSPLL_LOCK_IN              => INT_SYSPLL_LOCK_IN           ,

            -- DL/FB Latency
            DPD_DL_PROC_DLY_OUT             => dpd_dl_proc_dly_dpd          ,
            DPD_FB_PROC_DLY_OUT             => dpd_fb_proc_dly_dpd          ,
            DPD_UL_PROC_DLY_OUT             => dpd_ul_proc_dly_dpd          ,

            -- TDD/FS Strobe
            DL_BFN_STRB_IN                  => dl_bfn_strb_cfr              ,
            DL_TDD_IN                       => dl_tdd_cfr                   ,
            DL_SSB_STRB_IN                  => '0'                          ,

            DL_BFN_STRB_OUT                 => DL_BFN_STRB_OUT              ,
            DL_TDD_OUT                      => DL_TDD_OUT                   ,
            DL_SSB_STRB_OUT                 => DL_SSB_STRB_OUT              , -- 40ms sync signal for SSB power measurement

            FB_BFN_STRB_IN                  => FB_BFN_STRB_IN               ,
            FB_TDD_IN                       => FB_TDD_IN                    ,
            FB_SSB_STRB_IN                  => FB_SSB_STRB_IN               , -- 40ms sync signal for SSB power measurement

            UL_BFN_STRB_IN                  => UL_BFN_STRB_IN               ,
            UL_TDD_IN                       => UL_TDD_IN                    ,

            UL_BFN_STRB_OUT                 => ul_bfn_strb_pim              ,
            UL_TDD_OUT                      => ul_tdd_pim                   ,

            DL_BCF_ENB_IN                   => bcf_enb_cfr                  ,
            DL_BCF_ENB_OUT                  => BCF_ENB_OUT                  ,

            UL_BCF_ENB_IN                   => '0'                          ,
            UL_BCF_ENB_OUT                  => open                         ,

            -- Traffic IQ
            DL_SYNC_IN                      => (others =>'0')               ,
            DL_I_IN                         => dl_i_cfr                     ,
            DL_Q_IN                         => dl_q_cfr                     ,

            DL_INTERBAND_SYNC_IN            => (others => '0')              ,
            DL_INTERBAND_I_IN               => dl_i_cfr                     ,
            DL_INTERBAND_Q_IN               => dl_q_cfr                     ,

            DL_SYNC_OUT                     => open                         ,
            DL_I_OUT                        => DL_I_OUT                     ,
            DL_Q_OUT                        => DL_Q_OUT                     ,

            FB_SYNC_IN(0)                   => FB_SYNC_IN                   ,
            FB_I_IN                         => FB_I_IN                      ,
            FB_Q_IN                         => FB_Q_IN                      ,

            UL_SYNC_IN                      => (others=>'1')                ,
            UL_I_IN                         => in_pim_ul_i                  ,
            UL_Q_IN                         => in_pim_ul_q                  ,

            UL_SYNC_OUT                     => pim_ul_sync                  ,
            UL_I_OUT                        => pim_ul_i                     ,
            UL_Q_OUT                        => pim_ul_q                     ,

            -- Feedback Switch
            FBSW_START_TRIG_IN              => FBSW_START_TRIG_IN           ,
            FBSW_AUTO_MODE_DONE_IN          => FBSW_AUTO_MODE_DONE_IN       ,
            FBSW_MANUAL_MODE_IN             => FBSW_MANUAL_MODE_IN          ,
            FBSW_CNT_IN                     => FBSW_CNT_IN(4 downto 0)      ,
            FBSW_VAL_OUT                    => fbsw_val_dpd                 ,
            FBSW_SC_PATH_SEL_OUT            => FBSW_SC_PATH_SEL_OUT         ,
            PWR_MSR_FB_SYNC_IN              => PWR_MSR_FB_SYNC_IN           ,
            PWR_MSR_EN_IN                   => PWR_MSR_EN_IN                ,

            FBSW_SSB_IND_FLAG               => FBSW_SSB_IND_FLAG_DSP        ,

            -- Control & Status
            SIG_SUS_DLOFF_IN                => SIG_SUS_DLOFF_IN             ,

            DL_NCO_WEN_IN                   => dl_nco_wen_cpuif             ,
            DL_NCO_DATA_IN                  => dl_nco_data_cpuif            ,

            DPD_BYPASS_IN                   => dpd_bypass_cpuif             ,
            DPD_HC_TRSHD_IN                 => dpd_hc_trshd_cpuif           ,
            DPD_HC_FLAG_OUT                 => dpd_hc_flag_dpd              ,
            DPD_DATT_IN                     => dpd_datt_cpuif               ,
            DPD_FILTER_BYPASS_IN            => dpd_filter_bypass_cpuif      ,

            COEF_WREN_IN                    => coef_wren_cpuif              ,
            COEF_RDEN_IN                    => coef_rden_cpuif              ,
            COEF_WR_DONE_IN                 => coef_wr_done_cpuif           ,
            COEF_ADDR_IN                    => coef_addr_cpuif              ,
            COEF_WR_DATA_IN                 => coef_wr_data_cpuif           ,
            COEF_RD_DATA_OUT                => coef_rd_data_dpd             ,

            DACIF_BYPASS_IN                 => dacif_bypass_cpuif           ,
            DACIF_ON_IN                     => dacif_on_cpuif               ,

            FB_NCO_WEN_IN                   => fb_nco_wen_cpuif             ,
            FB_NCO_WORD_IN                  => fb_nco_word_cpuif            ,

            FB_FILTER_BYPASS_IN             => fb_filter_bypass_cpuif       ,

            FB_PWR_MSR_BFN_STRB_OUT         => fb_pwr_msr_bfn_strb_dpd      ,
            FB_PWR_MSR_DONE_OUT             => fb_pwr_msr_done_dpd          ,
            FB_PWR_OUT                      => fb_pwr_dpd                   ,

            DL_PWR_OUT                      => dl_pwr_dpd                   ,

            FB_FWD_DATT_IN                  => fb_fwd_datt_cpuif            ,
            FB_RVS_DATT_IN                  => fb_rvs_datt_cpuif            ,

            PIM_DETECTOR_ON_IN              => pim_detector_on_cpuif        ,
            PIM_MITIGATOR_ON_IN             => pim_mitigator_on_cpuif       ,
            PIM_CFR_REF_SEL_IN              => pim_cfr_ref_sel_cpuif        ,

            PIM_PNPC_SEL_IN                 => pim_pnpc_sel_in_cpuif        ,

            PIM_CORE_BYPASS_IN              => pim_core_bypass_cpuif        ,

            PIM_FILTER_BYPASS_IN            => pim_filter_bypass_cpuif      ,
            PIM_FILTER_COEF_WR_EN_IN        => pim_filter_coef_wr_en_cpuif  ,
            PIM_FILTER_COEF_RD_EN_IN        => pim_filter_coef_rd_en_cpuif  ,
            PIM_FILTER_COEF_WR_DN_IN        => pim_filter_coef_wr_dn_cpuif  ,
            PIM_FILTER_COEF_ADDR_IN         => pim_filter_coef_addr_cpuif   ,
            PIM_FILTER_COEF_WR_DATA_IN      => pim_filter_coef_wr_data_cpuif,
            PIM_FILTER_COEF_RD_DATA_OUT     => pim_filter_coef_rd_data_cpuif,

            PIM_NCO_WREN_IN                 => pim_nco_wren_cpuif           ,
            PIM_NCO_WORD_IN                 => pim_nco_word_cpuif           ,

            PIM_INTERBAND_DUC_GAIN_IN       => pim_interb_duc_gain          ,

            UL_PIM_NCO_WREN_IN              => ul_pim_nco_wren_cpuif        ,
            UL_PIM_NCO_WORD_IN              => ul_pim_nco_word_cpuif        ,

            DPD_INFO_OUT                    => dpd_info_dpd                 ,
            DPD_STRUCT_OUT                  => dpd_struct_dpd               ,
            DPD_DATE_OUT                    => dpd_date_dpd                 ,

            -- Dump & Test
            SC_LB_ON_IN                     => sc_lb_on_cpuif               ,

            DACIF_PHTEST_ENB_IN             => '0'                          ,
            DACIF_PHTEST_REF_SEL_IN         => '0'                          ,
            DACIF_PHTEST_PATH_AB_SWAP_IN    => '0'                          ,
            DACIF_PHTEST_PATH_REVERSE_IN    => '0'                          ,
            DACIF_PHTEST_REPEAT_ENB_IN      => '0'                          ,
            DACIF_PHTEST_DACIF_DEFAULT_IN   => (others => '0')             ,

            DACIF_PHTEST_OFFSET_IN          => (others => '0')              ,
            DACIF_PHTEST_PERIOD_IN          => (others => '0')              ,
            DACIF_PHTEST_ON_DURATION_IN     => (others => '0')              ,

            DBG_SIG_OUT                     => open                         ,

            DUMP_POINT_SEL_STRB_IN          => dump_point_sel_strb_cpuif    ,
            DUMP_POINT_SEL_IN               => dump_point_sel_cpuif         ,
            DUMP_BFN_STRB_OUT               => dump_bfn_strb_dpd            ,
            DUMP_DVLD_OUT                   => dump_dvld_dpd                ,
            DUMP_DATA_OUT                   => dump_data_dpd
        );
        
-- *************************************************************************************
-- Dump
-- *************************************************************************************
    U_DSP_DUMP_MUX : DSP_DUMP_MUX
        generic map(
            DUMP_CLK0_SEL                => DDUC_CLK_SEL                 , -- (Operation_Clock)/30.72MHz
            DUMP_CLK1_SEL                => DPD_CLK_SEL                    -- (Operation_Clock)/30.72MHz
        )
        port map(
            RST_CPU                      => RST_CPUIF                    , -- Reset, Active High

            CLK_SYS                      => CLK_SYS                      , -- System Clock :  30.72 MHz
            CLK_SYSX2                    => CLK_SYSX2                    , --  2x(CLK_SYS) :  61.44 MHz
            CLK_SYSX3                    => CLK_SYSX3                    , --  3x(CLK_SYS) :  92.16 MHz
            CLK_SYSX4                    => CLK_SYSX4                    , --  4x(CLK_SYS) : 122.88 MHz
            CLK_SYSX5                    => CLK_SYSX5                    , --  5x(CLK_SYS) : 153.60 MHz
            CLK_SYSX6                    => CLK_SYSX6                    , --  6x(CLK_SYS) : 184.32 MHz
            CLK_SYSX8                    => CLK_SYSX8                    , --  8x(CLK_SYS) : 245.76 MHz
            CLK_SYSX10                   => CLK_SYSX10                   , -- 10x(CLK_SYS) : 307.20 MHz
            CLK_SYSX12                   => CLK_SYSX12                   , -- 12x(CLK_SYS) : 368.64 MHz
            CLK_SYSX16                   => CLK_SYSX16                   , -- 16x(CLK_SYS) : 491.52 MHz
            CLK_SYSX20                   => CLK_SYSX20                   , -- 20x(CLK_SYS) : 614.40 MHz

            DUMP_POINT_SEL_STRB_IN       => dump_point_sel_strb_cpuif    ,
            DUMP_POINT_SEL_IN            => dump_point_sel_cpuif         , -- Dump Point Selection

            DUMP_DDUC_BFN_STRB_IN        => dump_bfn_strb_dduc           , -- Delayed 10ms Frame Sync Strobe for DUMP DDUC
            DUMP_DDUC_DVLD_IN            => dump_dvld_dduc               , -- Dump DDUC Sample Valid
            DUMP_DDUC_DATA_IN            => dump_data_dduc               , -- Dump DDUC Sample

            DUMP_CFR_BFN_STRB_IN         => dump_bfn_strb_cfr            , -- Delayed 10ms Frame Sync Strobe for DUMP CFR
            DUMP_CFR_DVLD_IN             => dump_dvld_cfr                , -- Dump CFR Sample Valid
            DUMP_CFR_DATA_IN             => dump_data_cfr                , -- Dump CFR Sample

            DUMP_DPD_BFN_STRB_IN         => dump_bfn_strb_dpd            , -- Delayed 10ms Frame Sync Strobe for DUMP DPD
            DUMP_DPD_DVLD_IN             => dump_dvld_dpd                , -- Dump DPD Sample Valid
            DUMP_DPD_DATA_IN             => dump_data_dpd                , -- Dump DPD Sample

            DUMP_DSP_BFN_STRB_OUT        => DUMP_BFN_STRB_OUT            , -- Delayed 10ms Frame Sync Strobe for DUMP
            DUMP_DSP_DVLD_OUT            => DUMP_DVLD_OUT                , -- Dump DSP Sample Valid
            DUMP_DSP_DATA_OUT            => DUMP_DATA_OUT                  -- Dump DSP Sample
        );

end arc_DSP_TOP;
