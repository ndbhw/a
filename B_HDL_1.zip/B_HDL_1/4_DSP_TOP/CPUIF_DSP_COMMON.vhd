-------------------------------------------------------------------------------
-- File name : CPUIF_DSP_COMMON.vhd
-- Purpose   : CPUIF for DSP_TOP
-------------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity CPUIF_DSP_COMMON is
    generic(
        ADDR_WIDTH                          : natural                       :=          16 ;      -- CPU Address Bitwidth
        WDATA_WIDTH                         : natural                       :=          32 ;      -- CPU Write Data Bitwidth
        RDATA_WIDTH                         : natural                       :=          32        -- CPU Read  Data Bitwidth        
    );
    port(
        -- Reset & Clock
        RST_CPUIF                           : in  std_logic;                                      -- CPUIF Reset, '1': Reset
        CLK_CPUIF                           : in  std_logic;                                      -- CPUIF Clock, faster than iclk/oclk

        CLK_SYS                             : in  std_logic;                                      -- System Clock :  30.72 MHz
        CLK_SYSX2                           : in  std_logic;                                      --  2x(CLK_SYS) :  61.44 MHz
        CLK_SYSX3                           : in  std_logic;                                      --  3x(CLK_SYS) :  92.16 MHz
        CLK_SYSX4                           : in  std_logic;                                      --  4x(CLK_SYS) : 122.88 MHz
        CLK_SYSX5                           : in  std_logic;                                      --  5x(CLK_SYS) : 153.60 MHz
        CLK_SYSX6                           : in  std_logic;                                      --  6x(CLK_SYS) : 184.32 MHz
        CLK_SYSX8                           : in  std_logic;                                      --  8x(CLK_SYS) : 245.76 MHz
        CLK_SYSX10                          : in  std_logic;                                      -- 10x(CLK_SYS) : 307.20 MHz
        CLK_SYSX12                          : in  std_logic;                                      -- 12x(CLK_SYS) : 368.64 MHz
        CLK_SYSX16                          : in  std_logic;                                      -- 16x(CLK_SYS) : 491.52 MHz
        CLK_SYSX20                          : in  std_logic;                                      -- 20x(CLK_SYS) : 614.40 MHz

        -- CPU Interface
        ADDR_CPUIF_IN                       : in  std_logic_vector(ADDR_WIDTH-1 downto 0);       -- CPUIF Address Input, WORD Address
        WDATA_CPUIF_IN                      : in  std_logic_vector(WDATA_WIDTH-1 downto 0);       -- CPUIF Data Input
        RDATA_CPUIF_OUT                     : out std_logic_vector(RDATA_WIDTH-1 downto 0);       -- CPUIF DATA Output
        WREN_CPUIF_IN                       : in  std_logic;                                      -- CPUIF Write Enable,    '1': Active, Synchronous with iclk
        RDEN_CPUIF_IN                       : in  std_logic;                                      -- CPUIF Read Enable,     '1': Active,
        RDVLD_CPUIF_OUT                     : out std_logic;                                      -- CPUIF Read Data Valid, '1': Active, Synchronous with clk_cpu

        -- TDD/FS Strobe
        DL_BFN_STRB_IN                      : in  std_logic;                                      -- Downlink 10ms Frame Sync Strobe
        FB_BFN_STRB_IN                      : in  std_logic;                                      -- Feedback 10ms Frame Sync Strobe

        -- Feedback Switch
        FBSW_AUTO_MODE_DONE_IN              : in  std_logic_vector(FB_PATH_NUM-1 downto 0);       -- Feedback Switch Automode Done Flag, '0': Auto Mode
        FBSW_CNT_IN                         : in  std_logic_vector(5-1 downto 0);                 -- Feedback Switch Counter
        FBSW_VALUE_IN                       : in  std_logic_vector(4-1 downto 0);                 -- Feedback Switch Encoded Value
        FBSW_PWR_MSR_UDT_IN                 : in  std_logic;                                      -- Feedback Switch Measure Done, Feedback Power Measure Update Enable

        -- DSP_TOP Version & Test
        DSP_TOP_MODULE_INFO_IN              : in  std_logic_vector(32-1 downto 0);                -- DSP_TOP Module Information
        DSP_TOP_MODULE_STRUCT_IN            : in  std_logic_vector(32-1 downto 0);                -- DSP_TOP Module Structure Information
        DSP_TOP_MODULE_DATE_IN              : in  std_logic_vector(32-1 downto 0);                -- DSP_TOP Module Date

        DSP_DUMP_SEL_STRB_OUT               : out std_logic;                                      -- DSP_TOP Dump Selection Strobe
        DSP_DUMP_SEL_OUT                    : out std_logic_vector(8-1 downto 0);                 -- DSP_TOP Dump Selection

        -- DDUC Control & Status
        DDUC_TOP_MODULE_INFO_IN             : in  std_logic_vector(32-1 downto 0);                -- DDUC_TOP Module Information
        DDUC_TOP_MODULE_STRUCT_IN           : in  std_logic_vector(32-1 downto 0);                -- DDUC_TOP Module Structure Information
        DDUC_TOP_MODULE_DATE_IN             : in  std_logic_vector(32-1 downto 0);                -- DDUC_TOP Module Date

        DDUC_DL_PROC_DLY_IN                 : in  std_logic_vector(32-1 downto 0);                -- DDUC_TOP DownLink Path Latency
        DDUC_UL_PROC_DLY_IN                 : in  std_logic_vector(32-1 downto 0);                -- DDUC_TOP UpLink   Path Latency
 
        DDUC_DL_PATH_ATT_OUT                : out std_logic_array16(TX_ANT_NUM-1 downto 0);
        DDUC_DL_PATH_DLY_OUT                : out std_logic_array12(TX_ANT_NUM-1 downto 0);
        DDUC_UL_PATH_DLY_OUT                : out std_logic_array12(RX_ANT_NUM-1 downto 0);

        DDUC_DUC_NCO_WEN_OUT                : out std_logic_vector(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);
        DDUC_DUC_NCO_DATA_OUT               : out std_logic_array32(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);
        DDUC_DUC_GAIN_OUT                   : out std_logic_array16(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);

        DDUC_DUC_TO_ANT_SUM_MODE_OUT        : out std_logic_vector((TX_ANT_NUM*DL_BBIQARY_NUM/2)-1 downto 0);
        DDUC_DUC_TO_ANT_SEL_OUT             : out std_logic_vector((TX_ANT_NUM*DL_BBIQARY_NUM/2)*2*TX_ANT_NUM-1 downto 0);

        DDUC_DDC_NCO_WEN_OUT                : out std_logic_vector(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);
        DDUC_DDC_NCO_DATA_OUT               : out std_logic_array32(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);
        DDUC_DDC_GAIN_OUT                   : out std_logic_array16(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);

        DDUC_UL_TO_ANT_SEL_OUT              : out std_logic_array8((RX_ANT_NUM*UL_BBIQARY_NUM)/2-1 downto 0);

        DDUC_UL_ADC_PWR_IN                  : in  std_logic_array32(RX_ANT_NUM-1 downto 0);

        -- CFR Control & Status
        CFR_TOP_MODULE_INFO_IN              : in  std_logic_vector(31 downto 0);
        CFR_TOP_MODULE_STRUCT_IN            : in  std_logic_vector(31 downto 0);
        CFR_TOP_MODULE_DATE_IN              : in  std_logic_vector(31 downto 0);

        CFR_DL_PROC_DLY_IN                  : in  std_logic_vector(31 downto 0);
        CFR_CORE_BYPASS_OUT                 : out std_logic_vector(TX_ANT_NUM-1 downto 0);        

        CFR_THRSD_OUT                       : out std_logic_array16(TX_ANT_NUM-1 downto 0);
        CFR_PEAK_SPACING_OUT                : out std_logic_array8(TX_ANT_NUM-1 downto 0);
        CFR_HC_THRSD_OUT                    : out std_logic_array16(TX_ANT_NUM-1 downto 0);
        CFR_HC_ENB_OUT                      : out std_logic_vector(TX_ANT_NUM-1 downto 0);

        CFR_TAP_NUM_OUT                     : out std_logic_array10((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
        CFR_COEF_UPDATE_ENB_OUT             : out std_logic_vector((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
        CFR_COEF_ADDR_OUT                   : out std_logic_array10((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
        CFR_COEF_WDATA_OUT                  : out std_logic_array32((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
        CFR_COEF_WEN_OUT                    : out std_logic_vector((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);

        CFR_PWR_MSR_UDT_IN                  : in  std_logic_vector(TX_ANT_NUM-1 downto 0);
        CFR_PWR_IN                          : in  std_logic_array32(TX_ANT_NUM-1 downto 0);

        CFR_OPD_TRSHD_OUT                   : out std_logic_array32(TX_ANT_NUM-1 downto 0);
        CFR_OPD_FLAG_IN                     : in  std_logic_vector(TX_ANT_NUM-1 downto 0);
        CFR_OPD_PWR_IN                      : in  std_logic_array32(TX_ANT_NUM-1 downto 0);

        -- DPD/FB Control & Status
        DPD_TOP_MODULE_INFO_IN              : in  std_logic_vector(32-1 downto 0);                  -- DPD_TOP Module Information
        DPD_TOP_MODULE_STRUCT_IN            : in  std_logic_vector(32-1 downto 0);                  -- DPD_TOP Module Structure Information
        DPD_TOP_MODULE_DATE_IN              : in  std_logic_vector(32-1 downto 0);                  -- DPD_TOP Module Date

        DPD_DL_PROC_DLY_IN                  : in  std_logic_vector(32-1 downto 0);                  -- DPD_TOP DownLink Path Latency
        DPD_FB_PROC_DLY_IN                  : in  std_logic_vector(32-1 downto 0);                  -- DPD_TOP FeedBack Path Latency
        DPD_UL_PROC_DLY_IN                  : in  std_logic_vector(32-1 downto 0);                  -- DPD_TOP UpLink   Path Latency

        DPD_DL_BULK_NCO_WEN_OUT             : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DownLink Bulk NCO Word Write Enable
        DPD_DL_BULK_NCO_WORD_OUT            : out std_logic_array32(TX_ANT_NUM-1 downto 0);         -- DPD_TOP DownLink Bulk NCO Word

        DPD_CORE_BYPASS_OUT                 : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP Core Bypass

        DPD_HC_THRSD_CDC_STRB_OUT           : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP Hard-Clipper Threshold CDC Strobe
        DPD_HC_THRSD_OUT                    : out std_logic_array16(TX_ANT_NUM-1 downto 0);         -- DPD_TOP Hard-Clipper Threshold

        DPD_HC_FLAG_IN                      : in  std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD Hard-Clipping Flag

        DPD_DL_ATT_CDC_STRB_OUT             : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DL Attenuator Value CDC Strobe
        DPD_DL_ATT_OUT                      : out std_logic_array16(TX_ANT_NUM-1 downto 0);         -- DPD_TOP DL Attenuator Value

        DPD_OUTFILTER_BYPASS_OUT            : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DPD Output Filter Bypass
        DPD_OUTFILTER_COEF_WEN_OUT          : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DPD Output Filter Coefficients Write Enable (Indirect Write/Read)
        DPD_OUTFILTER_COEF_REN_OUT          : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DPD Output Filter Coefficients Read  Enable (Indirect Write/Read)
        DPD_OUTFILTER_COEF_WRDN_OUT         : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DPD Output Filter Coefficients Write Done   (Indirect Write/Read)
        DPD_OUTFILTER_COEF_ADDR_OUT         : out std_logic_vector(8-1 downto 0);                   -- DPD_TOP DPD Output Filter Coefficients Address      (Indirect Write/Read)
        DPD_OUTFILTER_COEF_WDATA_OUT        : out std_logic_vector(16-1 downto 0);                  -- DPD_TOP DPD Output Filter Coefficients Write Data   (Indirect Write/Read)
        DPD_OUTFILTER_COEF_RDATA_IN         : in  std_logic_vector(16-1 downto 0);                  -- DPD_TOP DPD Output Filter Coefficients Read  Data   (Indirect Write/Read)

        DPD_DACIF_ONOFF_BYPASS_OUT          : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DACIF_IQ_ONOFF Bypass
        DPD_DACIF_ONOFF_ON_OUT              : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP DACIF_IQ_ONOFF On

        DPD_FB_BULK_NCO_WEN_OUT             : out std_logic_vector(FB_PATH_NUM-1 downto 0);         -- DPD_TOP FeedBack Bulk NCO Word Write Enable
        DPD_FB_BULK_NCO_WORD_OUT            : out std_logic_array32(FB_PATH_NUM-1 downto 0);        -- DPD_TOP FeedBack Bulk NCO Word

        DPD_FB_FILTER_BYPASS_OUT            : out std_logic_vector(FB_PATH_NUM-1 downto 0);         -- DPD_TOP FeedBack Filter Bypass

        DPD_FB_PWR_MSR_DONE_IN              : in  std_logic_vector(FB_PATH_NUM-1 downto 0);         -- DPD_TOP Feedback Power Measurement Done Flag
        DPD_FB_PWR_IN                       : in  std_logic_array32(FB_PATH_NUM-1 downto 0);        -- DPD_TOP Feedback Power (Mantissa Format)
        DPD_DL_PWR_IN                       : in  std_logic_array32(TX_ANT_NUM-1 downto 0);

        DPD_FB_ATT_CDC_STRB_OUT             : out std_logic_vector(TX_ANT_NUM-1 downto 0);          -- DPD_TOP Feedback Forward & Reverse Attenuator Value CDC Storbe
        DPD_FB_FWD_ATT_OUT                  : out std_logic_array16(TX_ANT_NUM-1 downto 0);         -- DPD_TOP Feedback Forward Attenuator Value
        DPD_FB_RVS_ATT_OUT                  : out std_logic_array16(TX_ANT_NUM-1 downto 0);         -- DPD_TOP Feedback Reverse Attenuator Value

        -- PIM Control & Status
        PIM_DETECTOR_ON_OUT                 : out std_logic_vector(RX_ANT_NUM-1 downto 0);
        PIM_MITIGATOR_ON_OUT                : out std_logic_vector(RX_ANT_NUM-1 downto 0);
        PIM_CFR_REF_SEL_OUT                 : out std_logic_vector(RX_ANT_NUM-1 downto 0);

        PIM_INTERB_DUC_GAIN_STRB_OUT        : out std_logic;
        PIM_INTERB_DUC_GAIN_OUT             : out std_logic_array16(RX_ANT_NUM-1 downto 0);

        PIM_PNPC_SEL_STRB_OUT               : out std_logic;
        PIM_PNPC_SEL_OUT                    : out std_logic_array2(RX_ANT_NUM-1 downto 0);

        DPD_PIM_CORE_BYPASS_OUT             : out std_logic_vector(RX_ANT_NUM-1 downto 0);          -- DPD_TOP PIM Core Bypass

        DPD_PIM_BULK_NCO_WEN_OUT            : out std_logic;                                        -- DPD_TOP DownLink Bulk NCO Word Write Enable
        DPD_PIM_BULK_NCO_WORD_OUT           : out std_logic_vector(31 downto 0);                    -- DPD_TOP DownLink Bulk NCO Word

        DPD_PIM_LPF_BYPASS_OUT              : out std_logic_vector(RX_ANT_NUM-1 downto 0);          -- DPD_TOP PIM LowPassFilter Bypass
        DPD_PIM_LPF_COEF_WEN_OUT            : out std_logic_vector(RX_ANT_NUM-1 downto 0);          -- DPD_TOP PIM LowPassFilter Coefficients Write Enable (Indirect Write/Read)
        DPD_PIM_LPF_COEF_REN_OUT            : out std_logic_vector(RX_ANT_NUM-1 downto 0);          -- DPD_TOP PIM LowPassFilter Coefficients Read  Enable (Indirect Write/Read)
        DPD_PIM_LPF_COEF_WRDN_OUT           : out std_logic_vector(RX_ANT_NUM-1 downto 0);          -- DPD_TOP PIM LowPassFilter Coefficients Write Done   (Indirect Write/Read)
        DPD_PIM_LPF_COEF_ADDR_OUT           : out std_logic_vector(8-1 downto 0);                   -- DPD_TOP PIM LowPassFilter Coefficients Address      (Indirect Write/Read)
        DPD_PIM_LPF_COEF_WDATA_OUT          : out std_logic_vector(16-1 downto 0);                  -- DPD_TOP PIM LowPassFilter Coefficients Write Data   (Indirect Write/Read)
        DPD_PIM_LPF_COEF_RDATA_IN           : in  std_logic_vector(16-1 downto 0);                  -- DPD_TOP PIM LowPassFilter Coefficients Read  Data   (Indirect Write/Read)

        DPD_UL_PIM_NCO_WREN_OUT             : out std_logic;
        DPD_UL_PIM_NCO_WORD_OUT             : out std_logic_vector(32-1 downto 0);

        -- LoopBack/Dump/TestPattern
        DPD_SC_LB_TEST_ON_OUT               : out std_logic;
        DSP_TEST_LB_OUT                     : out std_logic
    );
end CPUIF_DSP_COMMON;

architecture arc_CPUIF_DSP_COMMON of CPUIF_DSP_COMMON is

    component RST_SYNC is
        generic (
            DLY_NUM         : natural := 4;    -- Number of delay.
            MAX_FANOUT_NUM  : integer := 200   -- Number of maximum fanout
            );
        port(
            RST_IN          : in  std_logic;   -- Active high asynchronous reset
            CLK             : in  std_logic;   -- clock to be sync'ed to
            RST_OUT         : out std_logic    -- "Synchronised" reset signal
        );
    end component;

    component REG32_WRITE is
        generic(
            BIT_ENABLE      : std_logic_vector(31 downto 0) := (others => '1');
            REG_ADDR        : std_logic_vector( 7 downto 0) := (others => '0'); -- Register address
            REG_DATA        : std_logic_vector(31 downto 0) := (others => '0')  -- Default value
            );
        port(
            RST             : in  std_logic;                                    -- reset, '1': reset
            CLK             : in  std_logic;                                    -- clock

            EN              : in  std_logic;                                    -- Write enable
            ADDR            : in  std_logic_vector( 7 downto 0);                -- Input Address
            DATA_IN         : in  std_logic_vector(31 downto 0);                -- Data input
            DATA_OUT        : out std_logic_vector(31 downto 0)                 -- Data output
        );
    end component;

    component REG32_LATCH is
        generic(
            BIT_ENABLE      : std_logic_vector(31 downto 0) := (others => '1');
            REG_ADDR        : std_logic_vector( 7 downto 0) := (others => '0')
            );
        port(
            RST             : in  std_logic;
            CLK             : in  std_logic;

            CLR_IN          : in  std_logic;
            ADDR_IN         : in  std_logic_vector( 7 downto 0);
            DATA_IN         : in  std_logic_vector(31 downto 0);
            DATA_OUT        : out std_logic_vector(31 downto 0);
            FLAG_OUT        : out std_logic_vector(31 downto 0)
        );
    end component;

    component HIGHCNT is
        generic(
            CNT_WIDTH       : natural                                        -- COUNTER Bit Width
        );
        port(
            RST             : in std_logic;                                   -- Active High Reset.
            CLK             : in std_logic;                                   -- Clock for Count
            EVENT           : in std_logic;                                   -- Event Pulse one or more clock
            CLR             : in std_logic;                                   -- Active High Clear.
            CNT             : out std_logic_vector(CNT_WIDTH - 1 downto 0)    -- Latch Output for EVENT.
        );
    end component;

    -- Signals --------------------------------------------------------------------------
    type std_logic_array_2TxANT is array(natural range <>) of std_logic_vector(2*TX_ANT_NUM-1 downto 0);

    constant zeros                          : std_logic_vector(RDATA_WIDTH-1 downto 0) := (others => '0');
    constant DDUC_UL_PWRMSR_SR_FACTOR       : std_logic_vector( 7 downto 0) := std_logic_vector(to_unsigned(UL_PWR_MSR_SR_FACTOR , 8));
    constant CFR_DL_PWRMSR_SR_FACTOR        : std_logic_vector( 7 downto 0) := std_logic_vector(to_unsigned(CFR_PWR_MSR_SR_FACTOR, 8));
    constant DPD_FB_PWRMSR_SR_FACTOR        : std_logic_vector( 7 downto 0) := std_logic_vector(to_unsigned(FB_PWR_MSR_SR_FACTOR , 8));

    constant FWDPWR_C_UPT_CNT               : std_logic_vector( 3 downto 0) := std_logic_vector(to_unsigned(0 , 4));
    constant FWDPWR_D_UPT_CNT               : std_logic_vector( 3 downto 0) := std_logic_vector(to_unsigned(0  , 4));
    constant RVSPWR_C_UPT_CNT               : std_logic_vector( 3 downto 0) := std_logic_vector(to_unsigned(0 , 4));
    constant RVSPWR_D_UPT_CNT               : std_logic_vector( 3 downto 0) := std_logic_vector(to_unsigned(0  , 4));
    constant FWDPWR_A_UPT_CNT               : std_logic_vector( 3 downto 0) := std_logic_vector(to_unsigned(1 , 4));
    constant FWDPWR_B_UPT_CNT               : std_logic_vector( 3 downto 0) := std_logic_vector(to_unsigned(4  , 4));
    constant RVSPWR_A_UPT_CNT               : std_logic_vector( 3 downto 0) := std_logic_vector(to_unsigned(2 , 4));
    constant RVSPWR_B_UPT_CNT               : std_logic_vector( 3 downto 0) := std_logic_vector(to_unsigned(5  , 4));
    --constant FB_PWR_UPT_CNT                 : std_logic_vector(31 downto 0) := "000"& RVSPWR_ODD_UPT_CNT & "000"& RVSPWR_EVEN_UPT_CNT &"000"& FWDPWR_ODD_UPT_CNT &"000"& FWDPWR_EVEN_UPT_CNT;
    constant FB_PWR_UPT_CNT                 : std_logic_vector(31 downto 0) :=( RVSPWR_D_UPT_CNT & RVSPWR_C_UPT_CNT  &  RVSPWR_B_UPT_CNT & RVSPWR_A_UPT_CNT  &  FWDPWR_D_UPT_CNT& FWDPWR_C_UPT_CNT  &  FWDPWR_B_UPT_CNT & FWDPWR_A_UPT_CNT );
                                                                                --31 downto 28       27 downto 24        23 downto 20        19 downto 16          15 downto 12     11 downto 8            7 downto 4        3 downto 0
    signal RST_DDUC                         : std_logic;
    signal RST_CFR                          : std_logic;
    signal RST_DPD                          : std_logic;
    signal RST_DPDFB                        : std_logic;

    signal CLK_VECTOR                       : std_logic_vector(20-1 downto 0);
    signal CLK_DDUC                         : std_logic;
    signal CLK_CFR                          : std_logic;
    signal CLK_DPD                          : std_logic;
    signal CLK_FB                           : std_logic;

    signal addr_h8                          : std_logic_vector(8-1 downto 0);
    signal addr_l8                          : std_logic_vector(8-1 downto 0);

    signal dl_cfr_pwrmsr_update_cfrclk_sh   : std_logic_vector(2 downto 0);
    signal dl_cfr_pwrmsr_update_cfrclk_rpls : std_logic;

    signal reg_pwr_update_num               : std_logic_vector(31 downto 0);
    signal pwr_update_num_cdc_cfrclk        : std_logic_vector(31 downto 0);

    signal fwd_pwr_update_flag_cfrclk       : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal rvs_pwr_update_flag_cfrclk       : std_logic_vector(TX_ANT_NUM-1 downto 0);

    signal reg_cfr_fwd_pwr                  : std_logic_array32(TX_ANT_NUM-1 downto 0);
    signal reg_cfr_rvs_pwr                  : std_logic_array32(TX_ANT_NUM-1 downto 0);

    signal fwd_rvs_pwrudt_test_sh_dpdclk    : std_logic_vector(2 downto 0);    
    signal pwr_update_num_cdc_dpdclk        : std_logic_vector(31 downto 0);

    signal dl_fb_pwrmsr_update_dpdclk_sh    : std_logic_vector(2 downto 0);
    signal dl_fb_pwrmsr_update_dpdclk_rpls  : std_logic;

    signal fwd_pwr_update_flag_dpdclk       : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal rvs_pwr_update_flag_dpdclk       : std_logic_vector(TX_ANT_NUM-1 downto 0);

    signal reg_fb_fwd_pwr_udt_pls           : std_logic_vector(  7 downto 0);
    signal reg_fb_rvs_pwr_udt_pls           : std_logic_vector( 15 downto 0);
    signal reg_fb_fwd_pwr                   : std_logic_array32( 7 downto 0);
    signal reg_fb_rvs_pwr                   : std_logic_array32(15 downto 0);
    signal reg_dpd_dl_pwr                   : std_logic_array32( 7 downto 0);

    signal fbsw_value_cfrclk                : std_logic_vector( 4 downto 0);
    signal fbsw_value_dpdclk                : std_logic_vector( 4 downto 0);

    -- CPU Domain --
    signal wren_cpu_clk_sh                  : std_logic_vector( 1 downto 0);
    signal wren_cpu_clk_rpls                : std_logic;
    signal rden_cpu_clk_sh                  : std_logic_vector( 5 downto 0);
    signal rden_d2_cpu_clk_rpls             : std_logic;
    signal rden_d6_cpu_clk_rpls             : std_logic;
    signal rdvld_cpu_clk                    : std_logic;
    signal reg_rdata_cpuclk                 : std_logic_vector(RDATA_WIDTH-1 downto 0);

    signal wren_dsp_50_cpuclk               : std_logic;
    signal wren_dduc_54_cpuclk              : std_logic;
    signal wren_cfr_58_cpuclk               : std_logic;

    signal reg_dsp_top_module_info          : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dsp_top_module_struct        : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dsp_top_module_date          : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dsp_test_ctrl_0              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dsp_lb_ctrl_0                : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dsp_test_ctrl_0_strb         : std_logic;

    signal reg_dduc_top_module_info         : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dduc_top_module_struct       : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dduc_top_module_date         : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dduc_ul_pwrmsr_sr_factor     : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dduc_dl_proc_dly             : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dduc_ul_proc_dly             : std_logic_vector(RDATA_WIDTH-1 downto 0);

    signal reg_cfr_top_module_info          : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_cfr_top_module_struct        : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_cfr_top_module_date          : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_cfr_dl_pwrmsr_sr_factor      : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_cfr_dl_proc_dly              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_cfr_test_ctrl_1              : std_logic_vector(RDATA_WIDTH-1 downto 0);    

    signal reg_dpd_top_module_info          : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_top_module_struct        : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_top_module_date          : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_fb_pwrmsr_sr_factor      : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_dl_proc_dly              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_fb_proc_dly              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_ul_proc_dly              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_test_ctrl_1              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_test_ctrl_2              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_test_ctrl_3              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_handshake_1              : std_logic_vector(RDATA_WIDTH-1 downto 0); -- dpd sw, ru sw handshake
    signal reg_dpd_handshake_2              : std_logic_vector(RDATA_WIDTH-1 downto 0); -- dpd sw, ru sw handshake

    signal fwd_rvs_pwrudt_test_sh_cfrclk    : std_logic_vector(2 downto 0);

    -- DDUC_TOP --
    signal wren_dduc_clk_sh                 : std_logic_vector( 5 downto 0);
    signal wren_dduc_clk_rpls               : std_logic;
    signal rden_dduc_clk_sh                 : std_logic_vector( 4 downto 0);
    signal rden_dduc_clk_rpls               : std_logic;

    signal wren_dduc_55_dducclk             : std_logic;
    signal wren_dduc_56_dducclk             : std_logic;
    signal wren_dduc_57_dducclk             : std_logic;

    signal rden_dduc_55_dducclk             : std_logic;
    signal rden_dduc_56_dducclk             : std_logic;
    signal rden_dduc_57_dducclk             : std_logic;

    signal reg_rdata_55_dducclk             : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_rdata_56_dducclk             : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_rdata_57_dducclk             : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_rdata_59_dducclk             : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_rdata_5A_dducclk             : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_rdata_5B_dducclk             : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_rdata_dducclk                : std_logic_vector(RDATA_WIDTH-1 downto 0);

    signal reg_dduc_path_dl_att             : std_logic_array32(TX_ANT_NUM-1 downto 0);
    signal reg_dduc_path_dl_dly             : std_logic_array32(TX_ANT_NUM-1 downto 0);
    signal reg_dduc_path_ul_dly             : std_logic_array32(RX_ANT_NUM-1 downto 0);

    signal reg_dduc_duc_nco_wen             : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dduc_duc_nco_data            : std_logic_array32(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);
    signal reg_dduc_duc_gain                : std_logic_array32(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);

    signal reg_dduc_duc_to_ant_sum_mode     : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dduc_duc_to_ant_sel          : std_logic_array32((TX_ANT_NUM*DL_BBIQARY_NUM/2)-1 downto 0);
    signal dduc_duc_to_ant_sel              : std_logic_array_2TxANT((TX_ANT_NUM*DL_BBIQARY_NUM/2)-1 downto 0);

    signal reg_dduc_ddc_nco_wen             : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dduc_ddc_nco_data            : std_logic_array32(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);
    signal reg_dduc_ddc_gain                : std_logic_array32(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);

    signal reg_dduc_ul_to_ant_sel           : std_logic_array32((RX_ANT_NUM*UL_BBIQARY_NUM/2)-1 downto 0);

    signal reg_dduc_ul_adc_pwr              : std_logic_array32(RX_ANT_NUM-1 downto 0);    

    -- CFR_TOP --
    signal wren_cfr_clk_sh                  : std_logic_vector( 5 downto 0);
    signal wren_cfr_clk_rpls                : std_logic;
    signal rden_cfr_clk_sh                  : std_logic_vector( 3 downto 0);
    signal rden_cfr_clk_rpls                : std_logic;
    signal lcen_cfr_clk_rpls                : std_logic;
    signal reg_rdata_59_cfrclk              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_rdata_5A_cfrclk              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_rdata_5B_cfrclk              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_rdata_cfrclk                 : std_logic_vector(RDATA_WIDTH-1 downto 0);

    signal wren_cfr_59_cfrclk               : std_logic;
    signal wren_cfr_5A_cfrclk               : std_logic;
    signal wren_cfr_5B_cfrclk               : std_logic;
    signal lcen_cfr_59_cfrclk               : std_logic;
    signal lcen_cfr_5A_cfrclk               : std_logic;
    signal lcen_cfr_5B_cfrclk               : std_logic;
    signal rden_cfr_59_cfrclk               : std_logic;
    signal rden_cfr_5A_cfrclk               : std_logic;
    signal rden_cfr_5B_cfrclk               : std_logic;

    signal cfr_opd_flag_d1                  : std_logic_vector( TX_ANT_NUM-1 downto 0);
    signal cfr_opd_flag_d2                  : std_logic_vector( TX_ANT_NUM-1 downto 0);
    signal cfr_opd_flag_f_d1                : std_logic_vector( TX_ANT_NUM-1 downto 0);
    signal cfr_opd_flag_f_d2                : std_logic_vector( TX_ANT_NUM-1 downto 0);
    signal cfr_opd_flag_f_rpls              : std_logic_vector( TX_ANT_NUM-1 downto 0);
    signal reg_cfr_opd_flag_w               : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_cfr_opd_flag_f               : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_cfr_opd_flag_s               : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_cfr_opd_pwr                  : std_logic_array32(TX_ANT_NUM-1 downto 0);

    signal reg_cfr_thrsd                    : std_logic_array32(TX_ANT_NUM-1 downto 0);
    signal reg_cfr_peak_spacing             : std_logic_array32(TX_ANT_NUM-1 downto 0);
    signal reg_cfr_hc_thrsd                 : std_logic_array32(TX_ANT_NUM-1 downto 0);
    signal reg_cfr_hc_enb                   : std_logic_array32(TX_ANT_NUM-1 downto 0);

    signal reg_cfr_tap_num                  : std_logic_array32((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
    signal reg_cfr_coef_update_enb          : std_logic_array32((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
    signal reg_cfr_coef_addr                : std_logic_array32((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
    signal reg_cfr_coef_wdata               : std_logic_array32((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
    signal reg_cfr_coef_wen                 : std_logic_array32((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1 downto 0);
    signal reg_cfr_opd_thrsd                : std_logic_array32(TX_ANT_NUM-1 downto 0);

    -- DPD_TOP --
    signal rden_dpd_cpuclk_sh               : std_logic_vector( 3 downto 0);
    signal rden_dpd_cpuclk_rpls             : std_logic;
    signal lcen_dpd_cpuclk_rpls             : std_logic;
    signal reg_rdata_5C_cpuclk              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_rdata_5D_cpuclk              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_rdata_5E_cpuclk              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_rdata_5F_cpuclk              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_rdata_cpuclk             : std_logic_vector(RDATA_WIDTH-1 downto 0);

    signal wren_dpd_5C_cpuclk               : std_logic;
    signal wren_dpd_5D_cpuclk               : std_logic;
    signal wren_dpd_5E_cpuclk               : std_logic;
    signal wren_dpd_5F_cpuclk               : std_logic;
    signal wren_dpd_5D_cpuclk_d1            : std_logic;
    signal wren_dpd_5F_cpuclk_d1            : std_logic;

    signal lcen_dpd_5C_cpuclk               : std_logic;
    signal lcen_dpd_5D_cpuclk               : std_logic;
    signal lcen_dpd_5E_cpuclk               : std_logic;
    signal lcen_dpd_5F_cpuclk               : std_logic;

    signal rden_dpd_5C_cpuclk               : std_logic;
    signal rden_dpd_5D_cpuclk               : std_logic;
    signal rden_dpd_5E_cpuclk               : std_logic;
    signal rden_dpd_5F_cpuclk               : std_logic;

    signal reg_dpd_dlmixer_wren             : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_dlmixer_word             : std_logic_array32(TX_ANT_NUM-1 downto 0);

    signal reg_dpd_dlhc_thrsd_cdc_strb      : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal reg_dpd_dlhc_thrsd               : std_logic_array32(TX_ANT_NUM-1 downto 0);
    signal reg_dpd_dlatt_cdc_strb           : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal reg_dpd_dlatt_value              : std_logic_array32(TX_ANT_NUM-1 downto 0);
    signal reg_dpd_dlhc_on_w                : std_logic_vector(RDATA_WIDTH-1 downto 0) := (others => '0');
    signal reg_dpd_dlhc_on_s                : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_dlhc_on_f                : std_logic_vector(RDATA_WIDTH-1 downto 0);

    signal clr_dpdhc_cnt                    : std_logic_vector(7 downto 0) := (others => '0');
    signal clr_dpdhc_cnt_sh                 : std_logic_array2(7 downto 0);
    signal reg_dpdhc_cnt                    : std_logic_array32(7 downto 0) := (others => (others => '0'));

    signal reg_dpd_dlfilter_coef_wren       : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_dlfilter_coef_rden       : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_dlfilter_coef_wrdn       : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_dlfilter_coef_addr       : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_dlfilter_coef_wdata      : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_dlfilter_coef_rdata      : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_dldacif_on               : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_fbatt_cdc_strb           : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_fbatt_value              : std_logic_array32(TX_ANT_NUM-1 downto 0);

    signal reg_dpd_fbmixer_wren             : std_logic_vector(32-1 downto 0);
    signal reg_dpd_fbmixer_word             : std_logic_array32(FB_PATH_NUM-1 downto 0);

    -- PIM_TOP --
    signal wren_pim_60_cpuclk                   : std_logic;
    signal wren_pim_60_cpuclk_d1                : std_logic;
    signal reg_dpd_pim_sample_dly_strb          : std_logic;
    signal rden_pim_cpuclk_sh                   : std_logic_vector( 3 downto 0);
    signal rden_pim_cpuclk_rpls                 : std_logic;
    signal rden_pim_60_cpuclk                   : std_logic;
    signal reg_pim_rdata_60_cpuclk              : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_pim_rdata_cpuclk                 : std_logic_vector(RDATA_WIDTH-1 downto 0);

    signal reg_dpd_pim_mode_on                  : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_pim_cfr_ref_sel              : std_logic_vector(RDATA_WIDTH-1 downto 0);

    signal reg_dpd_pim_pnpc_cdc_strb            : std_logic;
    signal reg_dpd_pim_pnpc_sel                 : std_logic_vector(RDATA_WIDTH-1 downto 0);

    signal reg_pim_interb_duc_gain_cdc_strb     : std_logic;
    signal reg_pim_interb_duc_gain              : std_logic_array32(RX_ANT_NUM-1 downto 0);

    signal reg_dpd_pim_mixer_wren               : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_pim_mixer_word               : std_logic_vector(RDATA_WIDTH-1 downto 0);

    signal reg_dpd_pim_lpf_coef_wren            : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_pim_lpf_coef_rden            : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_pim_lpf_coef_wrdn            : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_pim_lpf_coef_addr            : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_pim_lpf_coef_wdata           : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_pim_lpf_coef_rdata           : std_logic_vector(RDATA_WIDTH-1 downto 0);

    signal reg_dpd_pim_ul_mixer_wren            : std_logic_vector(RDATA_WIDTH-1 downto 0);
    signal reg_dpd_pim_ul_mixer_word0           : std_logic_vector(RDATA_WIDTH-1 downto 0);    

    -- Attribute ------------------------------------------------------------------------
    --attribute KEEP : string;

begin

-- *************************************************************************************
-- Operation Clock Assign
-- *************************************************************************************
    CLK_VECTOR <= CLK_SYSX20&'0'&'0'&'0'&CLK_SYSX16&'0'&'0'&'0'&CLK_SYSX12&'0'&CLK_SYSX10&'0'&CLK_SYSX8&'0'&CLK_SYSX6&CLK_SYSX5&CLK_SYSX4&CLK_SYSX3&CLK_SYSX2&CLK_SYS;

    CLK_DDUC   <= CLK_VECTOR(DDUC_CLK_SEL-1);
    CLK_CFR    <= CLK_VECTOR(CFR_CLK_SEL -1);
    CLK_DPD    <= CLK_VECTOR(DPD_CLK_SEL -1);
    CLK_FB     <= CLK_VECTOR(FB_CLK_SEL-1);

-- *************************************************************************************
-- Reset Synchronize and Distribute
-- *************************************************************************************
    U_DDUC_RESET : RST_SYNC generic map(4, 200) port map(RST_CPUIF, CLK_DDUC, RST_DDUC );
    U_CFR_RESET  : RST_SYNC generic map(4, 200) port map(RST_CPUIF, CLK_CFR , RST_CFR  );
    U_DPD_RESET  : RST_SYNC generic map(4, 200) port map(RST_CPUIF, CLK_DPD , RST_DPD  );
    U_FB_RESET   : RST_SYNC generic map(4, 200) port map(RST_CPUIF, CLK_FB  , RST_DPDFB);

-- *************************************************************************************
-- Input Assign
-- *************************************************************************************
    addr_h8 <= ADDR_CPUIF_IN(15 downto 8);
    addr_l8 <= ADDR_CPUIF_IN( 7 downto 0);

    reg_dduc_ul_pwrmsr_sr_factor <=  zeros(31 downto 8)&DDUC_UL_PWRMSR_SR_FACTOR;
    reg_cfr_dl_pwrmsr_sr_factor  <=  zeros(31 downto 8)&CFR_DL_PWRMSR_SR_FACTOR ;
    reg_dpd_fb_pwrmsr_sr_factor  <=  zeros(31 downto 8)&DPD_FB_PWRMSR_SR_FACTOR ;

    -- DSP_TOP
    reg_dsp_top_module_info     <= DSP_TOP_MODULE_INFO_IN;
    reg_dsp_top_module_struct   <= DSP_TOP_MODULE_STRUCT_IN;
    reg_dsp_top_module_date     <= DSP_TOP_MODULE_DATE_IN;

    -- DDUC_TOP
    reg_dduc_top_module_info    <= DDUC_TOP_MODULE_INFO_IN;
    reg_dduc_top_module_struct  <= DDUC_TOP_MODULE_STRUCT_IN;
    reg_dduc_top_module_date    <= DDUC_TOP_MODULE_DATE_IN;

    reg_dduc_dl_proc_dly        <= DDUC_DL_PROC_DLY_IN;
    reg_dduc_ul_proc_dly        <= DDUC_UL_PROC_DLY_IN;

    reg_dduc_ul_adc_pwr         <= DDUC_UL_ADC_PWR_IN;

    -- CFR_TOP
    reg_cfr_top_module_info     <= CFR_TOP_MODULE_INFO_IN;
    reg_cfr_top_module_struct   <= CFR_TOP_MODULE_STRUCT_IN;
    reg_cfr_top_module_date     <= CFR_TOP_MODULE_DATE_IN;

    reg_cfr_dl_proc_dly         <= CFR_DL_PROC_DLY_IN;

    G_DL_Path_OPD_Flag_N_Power : for I in 0 to (TX_ANT_NUM-1) generate begin
        P_OPD_Flag_Double_Clocking : process(RST_CFR, CLK_CFR) begin
            if (RST_CFR = '1') then
                cfr_opd_flag_d1(I) <= '0';
                cfr_opd_flag_d2(I) <= '0';
            elsif (CLK_CFR'event) and (CLK_CFR = '1') then
                cfr_opd_flag_d1(I) <= CFR_OPD_FLAG_IN(I);
                cfr_opd_flag_d2(I) <= cfr_opd_flag_d1(I);
            end if;
        end process;

        P_OPD_Flag_Rising_Pulse : process(RST_CFR, CLK_CFR) begin
            if (RST_CFR = '1') then
                cfr_opd_flag_f_d1(I)   <= '0';
                cfr_opd_flag_f_d2(I)   <= '0';
                cfr_opd_flag_f_rpls(I) <= '0';
            elsif (CLK_CFR'event) and (CLK_CFR = '1') then
                cfr_opd_flag_f_d1(I)   <= reg_cfr_opd_flag_f(I);
                cfr_opd_flag_f_d2(I)   <= cfr_opd_flag_f_d1(I);
                cfr_opd_flag_f_rpls(I) <= cfr_opd_flag_f_d1(I) and (not cfr_opd_flag_f_d2(I));
            end if;
        end process;

        P_Over_Power_Latch : process(RST_CFR, CLK_CFR) begin
            if (RST_CFR = '1') then
                reg_cfr_opd_pwr(I) <= (others => '0');
            elsif (CLK_CFR'event) and (CLK_CFR = '1') then
                if (cfr_opd_flag_f_rpls(I) = '1') then
                    reg_cfr_opd_pwr(I) <= CFR_OPD_PWR_IN(I);
                else
                    reg_cfr_opd_pwr(I) <= reg_cfr_opd_pwr(I);
                end if;
            end if;
        end process;

    end generate;

    -- CFR Power Measure Update
    P_CFR_CLK_CDC : process(RST_CFR, CLK_CFR) begin
        if (RST_CFR = '1') then
            fwd_rvs_pwrudt_test_sh_cfrclk <= (others => '0');
	        pwr_update_num_cdc_cfrclk     <= FB_PWR_UPT_CNT;
        elsif (CLK_CFR'event) and (CLK_CFR = '1') then
            fwd_rvs_pwrudt_test_sh_cfrclk <= fwd_rvs_pwrudt_test_sh_cfrclk(1 downto 0) & reg_dpd_test_ctrl_2(1);

            if (addr_l8 = x"D0") and (wren_dpd_5D_cpuclk_d1 = '1') then
                pwr_update_num_cdc_cfrclk <= reg_pwr_update_num;
            else
                pwr_update_num_cdc_cfrclk <= pwr_update_num_cdc_cfrclk;
            end if;
        end if;
    end process;

    P_CFR_Power_Update_Pulse : process(RST_CFR, CLK_CFR) begin
        if (RST_CFR = '1') then
            dl_cfr_pwrmsr_update_cfrclk_sh   <= (others => '0');
            dl_cfr_pwrmsr_update_cfrclk_rpls <= '0';
        elsif (CLK_CFR'event) and (CLK_CFR = '1') then
            dl_cfr_pwrmsr_update_cfrclk_sh   <= dl_cfr_pwrmsr_update_cfrclk_sh(1 downto 0)&FBSW_PWR_MSR_UDT_IN;
            dl_cfr_pwrmsr_update_cfrclk_rpls <= dl_cfr_pwrmsr_update_cfrclk_sh(1) and (not dl_cfr_pwrmsr_update_cfrclk_sh(2));
        end if;
    end process;

    P_FBSW_Encoding_CFR_CLK : process(RST_CFR, CLK_CFR) begin
        if (RST_CFR = '1') then
            fbsw_value_cfrclk <= (others => '0');
        elsif (CLK_CFR'event) and (CLK_CFR = '1') then
            fbsw_value_cfrclk <= FBSW_CNT_IN(4 downto 0);
        end if;
    end process;

    G_FWD_RVS_CFRPWR_SYNC_Update : for I in 0 to (FB_PATH_NUM-1) generate begin
        P_FWD_RVS_CFRPWR_SYNC_Update : process(RST_CFR, CLK_CFR) begin
            if (RST_CFR = '1') then
                fwd_pwr_update_flag_cfrclk(I)   <= '0';
                fwd_pwr_update_flag_cfrclk(I+1) <= '0';
                rvs_pwr_update_flag_cfrclk(I)   <= '0';
                rvs_pwr_update_flag_cfrclk(I+1) <= '0';
                
            elsif (CLK_CFR'event) and (CLK_CFR = '1') then
                if (pwr_update_num_cdc_cfrclk( 3 downto 0) = fbsw_value_cfrclk(3 downto 0)) then
                    -- FWD A
                    fwd_pwr_update_flag_cfrclk(4*I)   <= '1';
                elsif (pwr_update_num_cdc_cfrclk( 11 downto 8) = fbsw_value_cfrclk(3 downto 0)) then
                    -- FWD C
                    fwd_pwr_update_flag_cfrclk(4*I)   <= '0';
                else
                    fwd_pwr_update_flag_cfrclk(4*I)   <= '0';
                end if;

                if (pwr_update_num_cdc_cfrclk(7 downto 4) = fbsw_value_cfrclk(3 downto 0)) then
                    -- FWD B
                    fwd_pwr_update_flag_cfrclk(4*I+1) <= '1';
                elsif (pwr_update_num_cdc_cfrclk(15 downto 12) = fbsw_value_cfrclk(3 downto 0)) then
                    -- FWD D
                    fwd_pwr_update_flag_cfrclk(4*I+1) <= '0';
                else
                    fwd_pwr_update_flag_cfrclk(4*I+1) <= '0';
                end if;

                if (pwr_update_num_cdc_cfrclk(19 downto 16) = fbsw_value_cfrclk(3 downto 0)) then
                    -- REV A
                    rvs_pwr_update_flag_cfrclk(4*I)   <= '1';
                elsif (pwr_update_num_cdc_cfrclk(27 downto 24) = fbsw_value_cfrclk(3 downto 0)) then
                    -- REV C
                    rvs_pwr_update_flag_cfrclk(4*I)   <= '0';
                else
                    rvs_pwr_update_flag_cfrclk(4*I)   <= '0';
                end if;

                if (pwr_update_num_cdc_cfrclk(23 downto 20) = fbsw_value_cfrclk(3 downto 0)) then
                    -- REV B
                    rvs_pwr_update_flag_cfrclk(4*I+1) <= '1';
                elsif (pwr_update_num_cdc_cfrclk(31 downto 28) = fbsw_value_cfrclk(3 downto 0)) then
                    -- REV D
                    rvs_pwr_update_flag_cfrclk(4*I+1) <= '0';
                else
                    rvs_pwr_update_flag_cfrclk(4*I+1) <= '0';
                end if;
            end if;
        end process;
    end generate;

    G_FWD_RVS_CFRPWR_Update : for I in 0 to (TX_ANT_NUM-1) generate begin
        P_DL_CFR_Power_Update : process(RST_CFR, CLK_CFR) begin
            if (RST_CFR = '1') then
                reg_cfr_fwd_pwr(I) <= (others => '0');
                reg_cfr_rvs_pwr(I) <= (others => '0');
            elsif (CLK_CFR'event) and (CLK_CFR = '1') then
                if (dl_cfr_pwrmsr_update_cfrclk_rpls = '1') then
                    if (fwd_pwr_update_flag_cfrclk(I) = '1') then
                        if (fwd_rvs_pwrudt_test_sh_cfrclk(2) = '1') then
                            reg_cfr_fwd_pwr(I) <= zeros(31 downto 5) & fbsw_value_cfrclk;
                        else
                            reg_cfr_fwd_pwr(I) <= CFR_PWR_IN(I);
                        end if;
                    else
                        reg_cfr_fwd_pwr(I) <= reg_cfr_fwd_pwr(I);
                    end if;
                else
                    reg_cfr_fwd_pwr(I) <= reg_cfr_fwd_pwr(I);
                end if;

                if (dl_cfr_pwrmsr_update_cfrclk_rpls = '1') then
                    if (rvs_pwr_update_flag_cfrclk(I) = '1') then
                        if (fwd_rvs_pwrudt_test_sh_cfrclk(2) = '1') then
                            reg_cfr_rvs_pwr(I) <= zeros(31 downto 5) & fbsw_value_cfrclk;
                        else
                            reg_cfr_rvs_pwr(I) <= CFR_PWR_IN(I);
                        end if;
                    else
                        reg_cfr_rvs_pwr(I) <= reg_cfr_rvs_pwr(I);
                    end if;
                else
                    reg_cfr_rvs_pwr(I) <= reg_cfr_rvs_pwr(I);
                end if;
            end if;
        end process;
    end generate;


    -- DPD_TOP
    reg_dpd_dlfilter_coef_rdata <= zeros(31 downto 16) & DPD_OUTFILTER_COEF_RDATA_IN;

    G_DPDHC_FLAG : for I in 0 to (TX_ANT_NUM-1) generate begin
        reg_dpd_dlhc_on_w(I)    <= DPD_HC_FLAG_IN(I);
    end generate;

    reg_dpd_top_module_info     <= DPD_TOP_MODULE_INFO_IN;
    reg_dpd_top_module_struct   <= DPD_TOP_MODULE_STRUCT_IN;
    reg_dpd_top_module_date     <= DPD_TOP_MODULE_DATE_IN;

    reg_dpd_dl_proc_dly         <= DPD_DL_PROC_DLY_IN;
    reg_dpd_fb_proc_dly         <= DPD_FB_PROC_DLY_IN;
    reg_dpd_ul_proc_dly         <= DPD_UL_PROC_DLY_IN;

    reg_dpd_pim_lpf_coef_rdata  <= zeros(31 downto 16) & DPD_PIM_LPF_COEF_RDATA_IN;

    -- FB Power Measure Update

    P_DPD_CLK_CDC : process(RST_DPDFB, CLK_FB) begin
        if (RST_DPDFB = '1') then
            fwd_rvs_pwrudt_test_sh_dpdclk <= (others => '0');
            pwr_update_num_cdc_dpdclk     <= FB_PWR_UPT_CNT;
        elsif (CLK_FB'event) and (CLK_FB = '1') then
            fwd_rvs_pwrudt_test_sh_dpdclk <= fwd_rvs_pwrudt_test_sh_dpdclk(1 downto 0) & reg_dpd_test_ctrl_2(1);

            if (addr_l8 = x"D0") and (wren_dpd_5D_cpuclk_d1 = '1') then
                pwr_update_num_cdc_dpdclk <= reg_pwr_update_num;
            else
                pwr_update_num_cdc_dpdclk <= pwr_update_num_cdc_dpdclk;
            end if;
        end if;
    end process;

    P_FB_Power_Update_Pulse : process(RST_DPDFB, CLK_FB) begin
        if (RST_DPDFB = '1') then
            dl_fb_pwrmsr_update_dpdclk_sh   <= (others => '0');
            dl_fb_pwrmsr_update_dpdclk_rpls <= '0';
        elsif (CLK_FB'event) and (CLK_FB = '1') then
            dl_fb_pwrmsr_update_dpdclk_sh   <= dl_fb_pwrmsr_update_dpdclk_sh(1 downto 0)&FBSW_PWR_MSR_UDT_IN;
            dl_fb_pwrmsr_update_dpdclk_rpls <= dl_fb_pwrmsr_update_dpdclk_sh(1) and (not dl_fb_pwrmsr_update_dpdclk_sh(2));
        end if;
    end process;

    P_FBSW_Encoding_DPD_CLK : process(RST_DPDFB, CLK_FB) begin
        if (RST_DPDFB = '1') then
            fbsw_value_dpdclk <= (others => '0');
        elsif (CLK_FB'event) and (CLK_FB = '1') then
            fbsw_value_dpdclk <= FBSW_CNT_IN(4 downto 0);
        end if;
    end process;

    G_FWD_RVS_FBPWR_SYNC_Update : for I in 0 to (FB_PATH_NUM-1) generate begin
        P_FWD_RVS_FBPWR_SYNC_Update : process(RST_DPDFB, CLK_FB) begin
            if (RST_DPDFB = '1') then
                fwd_pwr_update_flag_dpdclk(I)   <= '0';
                fwd_pwr_update_flag_dpdclk(I+1) <= '0';
                
                rvs_pwr_update_flag_dpdclk(I)   <= '0';
                rvs_pwr_update_flag_dpdclk(I+1) <= '0';
                
            elsif (CLK_FB'event) and (CLK_FB = '1') then
                if (pwr_update_num_cdc_dpdclk(3 downto 0) = fbsw_value_dpdclk(3 downto 0)) then
                    -- FWD A
                    fwd_pwr_update_flag_dpdclk(4*I)   <= '1';
                else
                    fwd_pwr_update_flag_dpdclk(4*I)   <= '0';
                end if;

                if (pwr_update_num_cdc_dpdclk(7 downto 4) = fbsw_value_dpdclk(3 downto 0)) then
                    -- FWD B
                    fwd_pwr_update_flag_dpdclk(4*I+1) <= '1';
                else
                    fwd_pwr_update_flag_dpdclk(4*I+1) <= '0';
                end if;

                if (pwr_update_num_cdc_dpdclk(19 downto 16) = fbsw_value_dpdclk(3 downto 0)) then
                    -- REV A
                    rvs_pwr_update_flag_dpdclk(4*I)   <= '1';
                else
                    rvs_pwr_update_flag_dpdclk(4*I)   <= '0';
                end if;

                if (pwr_update_num_cdc_dpdclk(23 downto 20) = fbsw_value_dpdclk(3 downto 0)) then
                    -- REV B
                    rvs_pwr_update_flag_dpdclk(4*I+1) <= '1';
                else
                    rvs_pwr_update_flag_dpdclk(4*I+1) <= '0';
                end if;
            end if;
        end process;
    end generate;

   P_DL_FB_Power_Update0 : process(RST_DPDFB, CLK_FB) begin
       if (RST_DPDFB = '1') then
           reg_fb_fwd_pwr(0) <= (others => '0');
           reg_fb_rvs_pwr(0) <= (others => '0');
       elsif (CLK_FB'event) and (CLK_FB = '1') then
           if (dl_fb_pwrmsr_update_dpdclk_rpls = '1') then
               if (fwd_pwr_update_flag_dpdclk(0) = '1') then
                   if (fwd_rvs_pwrudt_test_sh_dpdclk(2) = '1') then
                       reg_fb_fwd_pwr(0) <= zeros(31 downto 5) & fbsw_value_dpdclk;
                   else
                       reg_fb_fwd_pwr(0) <= DPD_FB_PWR_IN(0);
                   end if;
               else
                   reg_fb_fwd_pwr(0) <= reg_fb_fwd_pwr(0);
               end if;
           else
               reg_fb_fwd_pwr(0) <= reg_fb_fwd_pwr(0);
           end if;

           if (dl_fb_pwrmsr_update_dpdclk_rpls = '1') then
               if (rvs_pwr_update_flag_dpdclk(0) = '1') then
                   if (fwd_rvs_pwrudt_test_sh_dpdclk(2) = '1') then
                       reg_fb_rvs_pwr(0) <= zeros(31 downto 5) & fbsw_value_dpdclk;
                   else
                       reg_fb_rvs_pwr(0) <= DPD_FB_PWR_IN(0);
                   end if;
               else
                   reg_fb_rvs_pwr(0) <= reg_fb_rvs_pwr(0);
               end if;
           else
               reg_fb_rvs_pwr(0) <= reg_fb_rvs_pwr(0);
           end if;
       end if;
   end process;

   P_DL_FB_Power_Update1 : process(RST_DPDFB, CLK_FB) begin
       if (RST_DPDFB = '1') then
           reg_fb_fwd_pwr(1) <= (others => '0');
           reg_fb_rvs_pwr(1) <= (others => '0');
       elsif (CLK_FB'event) and (CLK_FB = '1') then
           if (dl_fb_pwrmsr_update_dpdclk_rpls = '1') then
               if (fwd_pwr_update_flag_dpdclk(1) = '1') then
                   if (fwd_rvs_pwrudt_test_sh_dpdclk(2) = '1') then
                       reg_fb_fwd_pwr(1) <= zeros(31 downto 5) & fbsw_value_dpdclk;
                   else
                       reg_fb_fwd_pwr(1) <= DPD_FB_PWR_IN(0);
                   end if;
               else
                   reg_fb_fwd_pwr(1) <= reg_fb_fwd_pwr(1);
               end if;
           else
               reg_fb_fwd_pwr(1) <= reg_fb_fwd_pwr(1);
           end if;

           if (dl_fb_pwrmsr_update_dpdclk_rpls = '1') then
               if (rvs_pwr_update_flag_dpdclk(1) = '1') then
                   if (fwd_rvs_pwrudt_test_sh_dpdclk(2) = '1') then
                       reg_fb_rvs_pwr(1) <= zeros(31 downto 5) & fbsw_value_dpdclk;
                   else
                       reg_fb_rvs_pwr(1) <= DPD_FB_PWR_IN(0);
                   end if;
               else
                   reg_fb_rvs_pwr(1) <= reg_fb_rvs_pwr(1);
               end if;
           else
               reg_fb_rvs_pwr(1) <= reg_fb_rvs_pwr(1);
           end if;
       end if;
   end process;

   G_DL_DPDPWR_Update : for I in 0 to (TX_ANT_NUM-1) generate begin
       P_DL_DPD_Power_Update0 : process(RST_DPDFB, CLK_FB) begin
           if (RST_DPDFB = '1') then
               reg_dpd_dl_pwr(I) <= (others => '0');
           elsif (CLK_FB'event) and (CLK_FB = '1') then
               if (dl_fb_pwrmsr_update_dpdclk_rpls = '1') then
                   if (fwd_pwr_update_flag_dpdclk(I) = '1') then
                       if (fwd_rvs_pwrudt_test_sh_dpdclk(2) = '1') then
                           reg_dpd_dl_pwr(I) <= zeros(31 downto 5) & fbsw_value_dpdclk;
                       else
                           reg_dpd_dl_pwr(I) <= DPD_DL_PWR_IN(I);
                       end if;
                   else
                       reg_dpd_dl_pwr(I) <= reg_dpd_dl_pwr(I);
                   end if;
               else
                   reg_dpd_dl_pwr(I) <= reg_dpd_dl_pwr(I);
               end if;
           end if;
       end process;
    end generate;

-- *************************************************************************************
-- CPU Clock Domain : Read Side, DSP Block Test Register
-- *************************************************************************************

    P_Write_Enable : process(RST_CPUIF, CLK_CPUIF) begin
        if (RST_CPUIF = '1') then
            wren_cpu_clk_sh   <= (others => '0');
            wren_cpu_clk_rpls <= '0';
        elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
            wren_cpu_clk_sh   <= wren_cpu_clk_sh(0) & WREN_CPUIF_IN;
            wren_cpu_clk_rpls <= wren_cpu_clk_sh(0) and (not wren_cpu_clk_sh(1));
        end if;
    end process;

    P_WREN_Address_Decoding_CPU_Domain : process(RST_CPUIF, CLK_CPUIF) begin
        if (RST_CPUIF = '1') then
            wren_dsp_50_cpuclk  <= '0';
            wren_dduc_54_cpuclk <= '0';
            wren_cfr_58_cpuclk  <= '0';
        elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
            if (wren_cpu_clk_rpls = '1') then
                case (addr_h8) is
                    when x"50"  => wren_dsp_50_cpuclk  <= '1'; wren_dduc_54_cpuclk <= '0'; wren_cfr_58_cpuclk  <= '0';
                    when x"54"  => wren_dsp_50_cpuclk  <= '0'; wren_dduc_54_cpuclk <= '1'; wren_cfr_58_cpuclk  <= '0';
                    when x"58"  => wren_dsp_50_cpuclk  <= '0'; wren_dduc_54_cpuclk <= '0'; wren_cfr_58_cpuclk  <= '1';
                    when x"5C"  => wren_dsp_50_cpuclk  <= '0'; wren_dduc_54_cpuclk <= '0'; wren_cfr_58_cpuclk  <= '0';
                    when others => wren_dsp_50_cpuclk  <= '0'; wren_dduc_54_cpuclk <= '0'; wren_cfr_58_cpuclk  <= '0';
                end case;
            else
                wren_dsp_50_cpuclk  <= '0'; wren_dduc_54_cpuclk <= '0'; wren_cfr_58_cpuclk  <= '0';
            end if;
        end if;
    end process;

    -- DSP_TOP Test Register
    REG_WR_0x0500C : REG32_WRITE generic map(x"01FF01FF", x"0C", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dsp_50_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dsp_test_ctrl_0);

    REG_WR_0x0500F : REG32_WRITE generic map(x"00000001", x"0F", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dsp_50_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dsp_lb_ctrl_0);

    -- CFR_TOP Test Register
    REG_WR_0x0580D : REG32_WRITE generic map(x"000000FF", x"0D", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_cfr_58_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_test_ctrl_1);

    P_Read_Valid_Generate : process(RST_CPUIF, CLK_CPUIF) begin
        if (RST_CPUIF = '1') then
            rden_cpu_clk_sh      <= (others => '0');
            rden_d2_cpu_clk_rpls <= '0';
            rden_d6_cpu_clk_rpls <= '0';
            rdvld_cpu_clk        <= '0';
        elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
            rden_cpu_clk_sh      <= rden_cpu_clk_sh(4 downto 0) & RDEN_CPUIF_IN;
            rden_d2_cpu_clk_rpls <= RDEN_CPUIF_IN and (not rden_cpu_clk_sh(0));
            rden_d6_cpu_clk_rpls <= rden_cpu_clk_sh(4) and (not rden_cpu_clk_sh(5));
            rdvld_cpu_clk        <= rden_d6_cpu_clk_rpls;
        end if;
    end process;

    P_Read_REG_CPU_Domain : process(RST_CPUIF, CLK_CPUIF) begin
        if (RST_CPUIF = '1') then
            reg_rdata_cpuclk <= (others => '0');
        elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
            if (rden_d2_cpu_clk_rpls = '1') then
                case (addr_h8) is
                    when x"50"  =>
                        case (addr_l8) is
                            when x"00"  => reg_rdata_cpuclk <= reg_dsp_top_module_info;
                            when x"01"  => reg_rdata_cpuclk <= reg_dsp_top_module_struct;
                            when x"02"  => reg_rdata_cpuclk <= reg_dsp_top_module_date;
                            when x"0C"  => reg_rdata_cpuclk <= reg_dsp_test_ctrl_0;
                            when x"0F"  => reg_rdata_cpuclk <= reg_dsp_lb_ctrl_0;

                            when others => reg_rdata_cpuclk <= (others => '0');
                        end case;
                    when x"54"  =>
                        case (addr_l8) is
                            when x"00"  => reg_rdata_cpuclk <= reg_dduc_top_module_info;
                            when x"01"  => reg_rdata_cpuclk <= reg_dduc_top_module_struct;
                            when x"02"  => reg_rdata_cpuclk <= reg_dduc_top_module_date;
                            when x"03"  => reg_rdata_cpuclk <= reg_dduc_ul_pwrmsr_sr_factor;
                            when x"04"  => reg_rdata_cpuclk <= reg_dduc_dl_proc_dly;
                            when x"05"  => reg_rdata_cpuclk <= reg_dduc_ul_proc_dly;
                            when others => reg_rdata_cpuclk <= (others => '0');
                        end case;
                    when x"58"  =>
                        case (addr_l8) is
                            when x"00"  => reg_rdata_cpuclk <= reg_cfr_top_module_info;
                            when x"01"  => reg_rdata_cpuclk <= reg_cfr_top_module_struct;
                            when x"02"  => reg_rdata_cpuclk <= reg_cfr_top_module_date;
                            when x"03"  => reg_rdata_cpuclk <= reg_cfr_dl_pwrmsr_sr_factor;
                            when x"04"  => reg_rdata_cpuclk <= reg_cfr_dl_proc_dly;
                            when x"0D"  => reg_rdata_cpuclk <= reg_cfr_test_ctrl_1;                            
                            when others => reg_rdata_cpuclk <= (others => '0');
                        end case;
                    when x"5C"  =>
                        case (addr_l8) is
                            when x"00"  => reg_rdata_cpuclk <= reg_dpd_top_module_info;
                            when x"01"  => reg_rdata_cpuclk <= reg_dpd_top_module_struct;
                            when x"02"  => reg_rdata_cpuclk <= reg_dpd_top_module_date;
                            when x"03"  => reg_rdata_cpuclk <= reg_dpd_fb_pwrmsr_sr_factor;
                            when x"04"  => reg_rdata_cpuclk <= reg_dpd_dl_proc_dly;
                            when x"05"  => reg_rdata_cpuclk <= reg_dpd_fb_proc_dly;
                            when x"06"  => reg_rdata_cpuclk <= reg_dpd_ul_proc_dly;
                            when x"0D"  => reg_rdata_cpuclk <= reg_dpd_test_ctrl_1;
                            when x"0E"  => reg_rdata_cpuclk <= reg_dpd_test_ctrl_2;
							when x"0F"  => reg_rdata_cpuclk <= reg_dpd_test_ctrl_3;
                            when x"10"  => reg_rdata_cpuclk <= reg_dpd_handshake_1;
                            when x"11"  => reg_rdata_cpuclk <= reg_dpd_handshake_2;
                            when others => reg_rdata_cpuclk <= (others => '0');
                        end case;
                    when others =>
                        reg_rdata_cpuclk <= (others => '0');
                end case;
            else
                reg_rdata_cpuclk <= reg_rdata_cpuclk;
            end if;
        end if;
    end process;

-- *************************************************************************************
-- CPU Interface Bus Signal Processing : DDUC
-- *************************************************************************************
    P_Write_Enable_Strobe_DDUC_Clock : process(RST_DDUC, CLK_DDUC) begin
        if (RST_DDUC = '1') then
            wren_dduc_clk_sh   <= (others => '0');
            wren_dduc_clk_rpls <= '0';
            rden_dduc_clk_sh   <= (others => '0');
            rden_dduc_clk_rpls <= '0';
        elsif (CLK_DDUC'event) and (CLK_DDUC = '1') then
            wren_dduc_clk_sh   <= wren_dduc_clk_sh(4 downto 0) & WREN_CPUIF_IN;
            wren_dduc_clk_rpls <= wren_dduc_clk_sh(4) and (not wren_dduc_clk_sh(5));
            rden_dduc_clk_sh   <= rden_dduc_clk_sh(3 downto 0) & RDEN_CPUIF_IN;
            rden_dduc_clk_rpls <= rden_dduc_clk_sh(3) and (not rden_dduc_clk_sh(4));
        end if;
    end process;

    P_DDUC_REG_Write_Enable_DDUC_CLK : process(RST_DDUC, CLK_DDUC) begin
        if (RST_DDUC = '1') then            
            wren_dduc_55_dducclk <= '0';
            wren_dduc_56_dducclk <= '0';
            wren_dduc_57_dducclk <= '0';
        elsif (CLK_DDUC'event) and (CLK_DDUC = '1') then
            if (wren_dduc_clk_rpls = '1') then
                case (addr_h8) is                    
                    when x"55"  => wren_dduc_55_dducclk <= '1'; wren_dduc_56_dducclk <= '0'; wren_dduc_57_dducclk <= '0';
                    when x"56"  => wren_dduc_55_dducclk <= '0'; wren_dduc_56_dducclk <= '1'; wren_dduc_57_dducclk <= '0';
                    when x"57"  => wren_dduc_55_dducclk <= '0'; wren_dduc_56_dducclk <= '0'; wren_dduc_57_dducclk <= '1';
                    when others => wren_dduc_55_dducclk <= '0'; wren_dduc_56_dducclk <= '0'; wren_dduc_57_dducclk <= '0';
                end case;
            else                
                wren_dduc_55_dducclk <= '0';
                wren_dduc_56_dducclk <= '0';
                wren_dduc_57_dducclk <= '0';
            end if;
        end if;
    end process;

    G_REG_DUC_DL_BBIQARY2 : if (DL_BBIQARY_NUM = 2 and TX_ANT_NUM = 2) generate begin
        REG_WR_0x05500 : REG32_WRITE generic map(x"00FFFFFF", x"00", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_nco_wen        );
        REG_WR_0x05501 : REG32_WRITE generic map(x"FFFFFFFF", x"01", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_nco_data( 0)   );
        REG_WR_0x05502 : REG32_WRITE generic map(x"FFFFFFFF", x"02", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_nco_data( 1)   );
        REG_WR_0x05503 : REG32_WRITE generic map(x"FFFFFFFF", x"03", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_nco_data( 2)   );
        REG_WR_0x05504 : REG32_WRITE generic map(x"FFFFFFFF", x"04", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_nco_data( 3)   );

        REG_WR_0x05540 : REG32_WRITE generic map(x"0000FFFF", x"40", x"00008000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_gain(0)        );
        REG_WR_0x05541 : REG32_WRITE generic map(x"0000FFFF", x"41", x"00008000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_gain(1)        );
        REG_WR_0x05542 : REG32_WRITE generic map(x"0000FFFF", x"42", x"00008000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_gain(2)        );
        REG_WR_0x05543 : REG32_WRITE generic map(x"0000FFFF", x"43", x"00008000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_gain(3)        );

        REG_WR_0x05580 : REG32_WRITE generic map(x"00000FFF", x"80", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_to_ant_sum_mode);
        REG_WR_0x05581 : REG32_WRITE generic map(x"0000FFFF", x"81", x"00009999") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_to_ant_sel( 0) );
        REG_WR_0x05582 : REG32_WRITE generic map(x"0000FFFF", x"82", x"00009999") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_to_ant_sel( 1) );
    end generate;

    G_REG_DDC_UL_BBIQARY2 : if (UL_BBIQARY_NUM = 2 and RX_ANT_NUM = 2) generate begin
        REG_WR_0x05600 : REG32_WRITE generic map(x"00FFFFFF", x"00", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ddc_nco_wen        );
        REG_WR_0x05601 : REG32_WRITE generic map(x"FFFFFFFF", x"01", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ddc_nco_data( 0)   );
        REG_WR_0x05602 : REG32_WRITE generic map(x"FFFFFFFF", x"02", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ddc_nco_data( 1)   );
        REG_WR_0x05603 : REG32_WRITE generic map(x"FFFFFFFF", x"03", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ddc_nco_data( 2)   );
        REG_WR_0x05604 : REG32_WRITE generic map(x"FFFFFFFF", x"04", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ddc_nco_data( 3)   );

        REG_WR_0x05640 : REG32_WRITE generic map(x"0000FFFF", x"40", x"00000400") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ddc_gain( 0)       );
        REG_WR_0x05641 : REG32_WRITE generic map(x"0000FFFF", x"41", x"00000400") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ddc_gain( 1)       );
        REG_WR_0x05642 : REG32_WRITE generic map(x"0000FFFF", x"42", x"00000400") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ddc_gain( 2)       );
        REG_WR_0x05643 : REG32_WRITE generic map(x"0000FFFF", x"43", x"00000400") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ddc_gain( 3)       );

        REG_WR_0x05680 : REG32_WRITE generic map(x"000000FF", x"80", x"00000010") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ul_to_ant_sel(0)   );
        REG_WR_0x05681 : REG32_WRITE generic map(x"000000FF", x"81", x"00000010") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ul_to_ant_sel(1)   );
    end generate;

    G_REG_DUC_DL_BBIQARY1 : if (DL_BBIQARY_NUM = 1 and TX_ANT_NUM = 2) generate begin
        REG_WR_0x05500 : REG32_WRITE generic map(x"00FFFFFF", x"00", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_nco_wen        );
        REG_WR_0x05501 : REG32_WRITE generic map(x"FFFFFFFF", x"01", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_nco_data( 0)   );
        REG_WR_0x05502 : REG32_WRITE generic map(x"FFFFFFFF", x"02", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_nco_data( 1)   );

        REG_WR_0x05540 : REG32_WRITE generic map(x"0000FFFF", x"40", x"00008000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_gain(0)        );
        REG_WR_0x05541 : REG32_WRITE generic map(x"0000FFFF", x"41", x"00008000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_gain(1)        );

        REG_WR_0x05580 : REG32_WRITE generic map(x"00000FFF", x"80", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_to_ant_sum_mode);
        REG_WR_0x05581 : REG32_WRITE generic map(x"0000FFFF", x"81", x"00009999") port map(RST_DDUC, CLK_DDUC, wren_dduc_55_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_duc_to_ant_sel( 0) );
    end generate;

    G_REG_DDC_UL_BBIQARY1 : if (UL_BBIQARY_NUM = 1 and RX_ANT_NUM = 2) generate begin
        REG_WR_0x05600 : REG32_WRITE generic map(x"00FFFFFF", x"00", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ddc_nco_wen        );
        REG_WR_0x05601 : REG32_WRITE generic map(x"FFFFFFFF", x"01", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ddc_nco_data( 0)   );
        REG_WR_0x05602 : REG32_WRITE generic map(x"FFFFFFFF", x"02", x"00000000") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ddc_nco_data( 1)   );

        REG_WR_0x05640 : REG32_WRITE generic map(x"0000FFFF", x"40", x"00000400") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ddc_gain( 0)       );
        REG_WR_0x05641 : REG32_WRITE generic map(x"0000FFFF", x"41", x"00000400") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ddc_gain( 1)       );

        REG_WR_0x05680 : REG32_WRITE generic map(x"000000FF", x"80", x"00000010") port map(RST_DDUC, CLK_DDUC, wren_dduc_56_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_ul_to_ant_sel(0)   );
    end generate;

    G_REG_DUC_PATH_ATTEN_DL2 : if (TX_ANT_NUM = 2) generate begin
        REG_WR_0x05700 : REG32_WRITE generic map(x"0000FFFF", x"00", x"00004000") port map(RST_DDUC, CLK_DDUC, wren_dduc_57_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_path_dl_att(0));
        REG_WR_0x05701 : REG32_WRITE generic map(x"0000FFFF", x"01", x"00004000") port map(RST_DDUC, CLK_DDUC, wren_dduc_57_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_path_dl_att(1));

        REG_WR_0x05740 : REG32_WRITE generic map(x"000000FF", x"40", x"0000007b") port map(RST_DDUC, CLK_DDUC, wren_dduc_57_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_path_dl_dly(0));
        REG_WR_0x05741 : REG32_WRITE generic map(x"000000FF", x"41", x"0000007b") port map(RST_DDUC, CLK_DDUC, wren_dduc_57_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_path_dl_dly(1));

        REG_WR_0x05760 : REG32_WRITE generic map(x"000000FF", x"60", x"0000007b") port map(RST_DDUC, CLK_DDUC, wren_dduc_57_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_path_ul_dly(0));
        REG_WR_0x05761 : REG32_WRITE generic map(x"000000FF", x"61", x"0000007b") port map(RST_DDUC, CLK_DDUC, wren_dduc_57_dducclk, addr_l8, WDATA_CPUIF_IN, reg_dduc_path_ul_dly(1));
    end generate;

    P_DDUC_REG_Read_Enable : process(RST_DDUC, CLK_DDUC) begin
        if (RST_DDUC = '1') then            
            rden_dduc_55_dducclk <= '0';
            rden_dduc_56_dducclk <= '0';
            rden_dduc_57_dducclk <= '0';
        elsif (CLK_DDUC'event) and (CLK_DDUC = '1') then
            if (rden_dduc_clk_rpls = '1') then
                case (addr_h8) is                    
                    when x"55"  => rden_dduc_55_dducclk <= '1'; rden_dduc_56_dducclk <= '0'; rden_dduc_57_dducclk <= '0';
                    when x"56"  => rden_dduc_55_dducclk <= '0'; rden_dduc_56_dducclk <= '1'; rden_dduc_57_dducclk <= '0';
                    when x"57"  => rden_dduc_55_dducclk <= '0'; rden_dduc_56_dducclk <= '0'; rden_dduc_57_dducclk <= '1';
                    when others => rden_dduc_55_dducclk <= '0'; rden_dduc_56_dducclk <= '0'; rden_dduc_57_dducclk <= '0';
                end case;
            else                
                rden_dduc_55_dducclk <= '0';
                rden_dduc_56_dducclk <= '0';
                rden_dduc_57_dducclk <= '0';
            end if;
        end if;
    end process;

    G_DL_BBIQARY2_DDUC_REG_0x55XX : if (DL_BBIQARY_NUM = 2 and TX_ANT_NUM = 2) generate begin
        P_DL_BBIQARY2_DDUC_REG_0x55XX : process(RST_DDUC, CLK_DDUC) begin
            if (RST_DDUC = '1') then
                reg_rdata_55_dducclk <= (others => '0');
            elsif (CLK_DDUC'event) and (CLK_DDUC = '1') then
                if (rden_dduc_55_dducclk = '1') then
                    case (addr_l8) is
                        when x"00"  => reg_rdata_55_dducclk <= reg_dduc_duc_nco_wen;
                        when x"01"  => reg_rdata_55_dducclk <= reg_dduc_duc_nco_data( 0);
                        when x"02"  => reg_rdata_55_dducclk <= reg_dduc_duc_nco_data( 1);
                        when x"03"  => reg_rdata_55_dducclk <= reg_dduc_duc_nco_data( 2);
                        when x"04"  => reg_rdata_55_dducclk <= reg_dduc_duc_nco_data( 3);

                        when x"40"  => reg_rdata_55_dducclk <= reg_dduc_duc_gain( 0);
                        when x"41"  => reg_rdata_55_dducclk <= reg_dduc_duc_gain( 1);
                        when x"42"  => reg_rdata_55_dducclk <= reg_dduc_duc_gain( 2);
                        when x"43"  => reg_rdata_55_dducclk <= reg_dduc_duc_gain( 3);

                        when x"80"  => reg_rdata_55_dducclk <= reg_dduc_duc_to_ant_sum_mode;
                        when x"81"  => reg_rdata_55_dducclk <= reg_dduc_duc_to_ant_sel( 0);
                        when x"82"  => reg_rdata_55_dducclk <= reg_dduc_duc_to_ant_sel( 1);

                        when others => reg_rdata_55_dducclk <= (others => '0');
                    end case;
                else
                    reg_rdata_55_dducclk <= reg_rdata_55_dducclk;
                end if;
            end if;
        end process;
    end generate;

    G_UL_BBIQARY2_DDUC_REG_0x56XX : if (UL_BBIQARY_NUM = 2 and RX_ANT_NUM = 2) generate begin
        P_UL_BBIQARY2_DDUC_REG_0x56XX : process(RST_DDUC, CLK_DDUC) begin
            if (RST_DDUC = '1') then
                reg_rdata_56_dducclk <= (others => '0');
            elsif (CLK_DDUC'event) and (CLK_DDUC = '1') then
                if (rden_dduc_56_dducclk = '1') then
                    case (addr_l8) is
                        when x"00"  => reg_rdata_56_dducclk <= reg_dduc_ddc_nco_wen;
                        when x"01"  => reg_rdata_56_dducclk <= reg_dduc_ddc_nco_data( 0);
                        when x"02"  => reg_rdata_56_dducclk <= reg_dduc_ddc_nco_data( 1);
                        when x"03"  => reg_rdata_56_dducclk <= reg_dduc_ddc_nco_data( 2);
                        when x"04"  => reg_rdata_56_dducclk <= reg_dduc_ddc_nco_data( 3);

                        when x"40"  => reg_rdata_56_dducclk <= reg_dduc_ddc_gain( 0);
                        when x"41"  => reg_rdata_56_dducclk <= reg_dduc_ddc_gain( 1);
                        when x"42"  => reg_rdata_56_dducclk <= reg_dduc_ddc_gain( 2);
                        when x"43"  => reg_rdata_56_dducclk <= reg_dduc_ddc_gain( 3);

                        when x"80"  => reg_rdata_56_dducclk <= reg_dduc_ul_to_ant_sel( 0);
                        when x"81"  => reg_rdata_56_dducclk <= reg_dduc_ul_to_ant_sel( 1);

                        when others => reg_rdata_56_dducclk <= (others => '0');
                    end case;
                else
                    reg_rdata_56_dducclk <= reg_rdata_56_dducclk;
                end if;
            end if;
        end process;
    end generate;

    G_DL_BBIQARY1_DDUC_REG_0x55XX : if (DL_BBIQARY_NUM = 1 and TX_ANT_NUM = 2) generate begin
        P_DL_BBIQARY1_DDUC_REG_0x55XX : process(RST_DDUC, CLK_DDUC) begin
            if (RST_DDUC = '1') then
                reg_rdata_55_dducclk <= (others => '0');
            elsif (CLK_DDUC'event) and (CLK_DDUC = '1') then
                if (rden_dduc_55_dducclk = '1') then
                    case (addr_l8) is
                        when x"00"  => reg_rdata_55_dducclk <= reg_dduc_duc_nco_wen;
                        when x"01"  => reg_rdata_55_dducclk <= reg_dduc_duc_nco_data( 0);
                        when x"02"  => reg_rdata_55_dducclk <= reg_dduc_duc_nco_data( 1);
                        when x"40"  => reg_rdata_55_dducclk <= reg_dduc_duc_gain( 0);
                        when x"41"  => reg_rdata_55_dducclk <= reg_dduc_duc_gain( 1);
                        when x"80"  => reg_rdata_55_dducclk <= reg_dduc_duc_to_ant_sum_mode;
                        when x"81"  => reg_rdata_55_dducclk <= reg_dduc_duc_to_ant_sel( 0);
                        when others => reg_rdata_55_dducclk <= (others => '0');
                    end case;
                else
                    reg_rdata_55_dducclk <= reg_rdata_55_dducclk;
                end if;
            end if;
        end process;
    end generate;

    G_UL_BBIQARY1_DDUC_REG_0x56XX : if (UL_BBIQARY_NUM = 1 and RX_ANT_NUM = 2) generate begin
        P_UL_BBIQARY1_DDUC_REG_0x56XX : process(RST_DDUC, CLK_DDUC) begin
            if (RST_DDUC = '1') then
                reg_rdata_56_dducclk <= (others => '0');
            elsif (CLK_DDUC'event) and (CLK_DDUC = '1') then
                if (rden_dduc_56_dducclk = '1') then
                    case (addr_l8) is
                        when x"00"  => reg_rdata_56_dducclk <= reg_dduc_ddc_nco_wen;
                        when x"01"  => reg_rdata_56_dducclk <= reg_dduc_ddc_nco_data( 0);
                        when x"02"  => reg_rdata_56_dducclk <= reg_dduc_ddc_nco_data( 1);
                        when x"40"  => reg_rdata_56_dducclk <= reg_dduc_ddc_gain( 0);
                        when x"41"  => reg_rdata_56_dducclk <= reg_dduc_ddc_gain( 1);
                        when x"80"  => reg_rdata_56_dducclk <= reg_dduc_ul_to_ant_sel( 0);
                        when others => reg_rdata_56_dducclk <= (others => '0');
                    end case;
                else
                    reg_rdata_56_dducclk <= reg_rdata_56_dducclk;
                end if;
            end if;
        end process;
    end generate;

    G_UL2_DDUC_REG_0x57XX : if (RX_ANT_NUM = 2) generate begin
        P_UL2_DDUC_REG_0x57XX : process(RST_DDUC, CLK_DDUC) begin
            if (RST_DDUC = '1') then
                reg_rdata_57_dducclk <= (others => '0');
            elsif (CLK_DDUC'event) and (CLK_DDUC = '1') then
                if (rden_dduc_57_dducclk = '1') then
                    case (addr_l8) is
                        when x"00"  => reg_rdata_57_dducclk <= reg_dduc_path_dl_att(0);
                        when x"01"  => reg_rdata_57_dducclk <= reg_dduc_path_dl_att(1);

                        when x"40"  => reg_rdata_57_dducclk <= reg_dduc_path_dl_dly(0);
                        when x"41"  => reg_rdata_57_dducclk <= reg_dduc_path_dl_dly(1);

                        when x"60"  => reg_rdata_57_dducclk <= reg_dduc_path_ul_dly(0);
                        when x"61"  => reg_rdata_57_dducclk <= reg_dduc_path_ul_dly(1);

                        when x"C0"  => reg_rdata_57_dducclk <= reg_dduc_ul_adc_pwr(0);
                        when x"C1"  => reg_rdata_57_dducclk <= reg_dduc_ul_adc_pwr(1);
                        when others => reg_rdata_57_dducclk <= (others => '0');
                    end case;
                else
                    reg_rdata_57_dducclk <= reg_rdata_57_dducclk;
                end if;
            end if;
        end process;
    end generate;    

    reg_rdata_dducclk <= reg_rdata_55_dducclk when (addr_h8 = x"55") else
                         reg_rdata_56_dducclk when (addr_h8 = x"56") else
                         reg_rdata_57_dducclk when (addr_h8 = x"57") else
                         (others => '0');

-- *************************************************************************************
-- CPU Interface Bus Signal Processing : CFR
-- *************************************************************************************
    P_Write_Enable_Strobe_CFR_Clock : process(RST_CFR, CLK_CFR) begin
        if (RST_CFR = '1') then
            wren_cfr_clk_sh   <= (others => '0');
            wren_cfr_clk_rpls <= '0';
            rden_cfr_clk_sh   <= (others => '0');
            rden_cfr_clk_rpls <= '0';
            lcen_cfr_clk_rpls <= '0';
        elsif (CLK_CFR'event) and (CLK_CFR = '1') then
            wren_cfr_clk_sh   <= wren_cfr_clk_sh(4 downto 0) & WREN_CPUIF_IN;
            wren_cfr_clk_rpls <= wren_cfr_clk_sh(4) and (not wren_cfr_clk_sh(5));
            rden_cfr_clk_sh   <= rden_cfr_clk_sh(2 downto 0) & RDEN_CPUIF_IN;
            rden_cfr_clk_rpls <= rden_cfr_clk_sh(2) and (not rden_cfr_clk_sh(3));
            lcen_cfr_clk_rpls <= rden_cfr_clk_sh(1) and (not rden_cfr_clk_sh(2));
        end if;
    end process;

    P_CFR_REG_Write_Enable_CFR_CLK : process(RST_CFR, CLK_CFR) begin
        if (RST_CFR = '1') then
            wren_cfr_59_cfrclk <= '0';
            wren_cfr_5A_cfrclk <= '0';
            wren_cfr_5B_cfrclk <= '0';
        elsif (CLK_CFR'event) and (CLK_CFR = '1') then
            if (wren_cfr_clk_rpls = '1') then
                case (addr_h8) is
                    when x"59"  => wren_cfr_59_cfrclk <= '1'; wren_cfr_5A_cfrclk <= '0'; wren_cfr_5B_cfrclk <= '0';
                    when x"5A"  => wren_cfr_59_cfrclk <= '0'; wren_cfr_5A_cfrclk <= '1'; wren_cfr_5B_cfrclk <= '0';
                    when x"5B"  => wren_cfr_59_cfrclk <= '0'; wren_cfr_5A_cfrclk <= '0'; wren_cfr_5B_cfrclk <= '1';
                    when others => wren_cfr_59_cfrclk <= '0'; wren_cfr_5A_cfrclk <= '0'; wren_cfr_5B_cfrclk <= '0';
                end case;
            else
                wren_cfr_59_cfrclk <= '0';
                wren_cfr_5A_cfrclk <= '0';
                wren_cfr_5B_cfrclk <= '0';
            end if;
        end if;
    end process;

    G_DL2_CFR_TOP_Control_Write_REG : if (TX_ANT_NUM = 2) generate begin
        REG_WR_0x05A00 : REG32_WRITE generic map(x"0000FFFF", x"00", x"00007FFF") port map(RST_CFR, CLK_CFR, wren_cfr_5A_cfrclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_thrsd(0)          );
        REG_WR_0x05A01 : REG32_WRITE generic map(x"0000FFFF", x"01", x"00007FFF") port map(RST_CFR, CLK_CFR, wren_cfr_5A_cfrclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_thrsd(1)          );

        REG_WR_0x05A10 : REG32_WRITE generic map(x"000000FF", x"10", x"00000000") port map(RST_CFR, CLK_CFR, wren_cfr_5A_cfrclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_peak_spacing(0)   );
        REG_WR_0x05A11 : REG32_WRITE generic map(x"000000FF", x"11", x"00000000") port map(RST_CFR, CLK_CFR, wren_cfr_5A_cfrclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_peak_spacing(1)   );

        REG_WR_0x05A20 : REG32_WRITE generic map(x"0000FFFF", x"20", x"00007FFF") port map(RST_CFR, CLK_CFR, wren_cfr_5A_cfrclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_hc_thrsd(0)       );
        REG_WR_0x05A21 : REG32_WRITE generic map(x"0000FFFF", x"21", x"00007FFF") port map(RST_CFR, CLK_CFR, wren_cfr_5A_cfrclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_hc_thrsd(1)       );

        REG_WR_0x05A30 : REG32_WRITE generic map(x"00000001", x"30", x"00000000") port map(RST_CFR, CLK_CFR, wren_cfr_5A_cfrclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_hc_enb(0)         );
        REG_WR_0x05A31 : REG32_WRITE generic map(x"00000001", x"31", x"00000000") port map(RST_CFR, CLK_CFR, wren_cfr_5A_cfrclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_hc_enb(1)         );

   G_CFR_2Path_Per_Moudule2_Core_Write_REG : if (CFR_PATH_PER_MODULE = 2) generate begin
            REG_WR_0x059A0 : REG32_WRITE generic map(x"000003FF", x"40", x"000001FD") port map(RST_CFR, CLK_CFR, wren_cfr_5A_cfrclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_tap_num(0)        );
            REG_WR_0x059A1 : REG32_WRITE generic map(x"00000001", x"41", x"00000000") port map(RST_CFR, CLK_CFR, wren_cfr_5A_cfrclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_coef_update_enb(0));
            REG_WR_0x059A2 : REG32_WRITE generic map(x"000003FF", x"42", x"00000000") port map(RST_CFR, CLK_CFR, wren_cfr_5A_cfrclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_coef_addr(0)      );
            REG_WR_0x059A3 : REG32_WRITE generic map(x"FFFFFFFF", x"43", x"00000000") port map(RST_CFR, CLK_CFR, wren_cfr_5A_cfrclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_coef_wdata(0)     );
            REG_WR_0x059A4 : REG32_WRITE generic map(x"00000001", x"44", x"00000000") port map(RST_CFR, CLK_CFR, wren_cfr_5A_cfrclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_coef_wen(0)       );
        end generate;

        REG_WR_0x05B00 : REG32_WRITE generic map(x"FFFFFFFF", x"00", x"FFFFFFFF") port map(RST_CFR, CLK_CFR, wren_cfr_5B_cfrclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_opd_thrsd(0)      );
        REG_WR_0x05B01 : REG32_WRITE generic map(x"FFFFFFFF", x"01", x"FFFFFFFF") port map(RST_CFR, CLK_CFR, wren_cfr_5B_cfrclk, addr_l8, WDATA_CPUIF_IN, reg_cfr_opd_thrsd(1)      );
    end generate;

    P_REG_Latch_N_Clear_Enable_CFRCLK : process(RST_CFR, CLK_CFR) begin
        if (RST_CFR = '1') then
            lcen_cfr_59_cfrclk <= '0';
            lcen_cfr_5A_cfrclk <= '0';
            lcen_cfr_5B_cfrclk <= '0';
        elsif (CLK_CFR'event) and(CLK_CFR = '1') then
            if (lcen_cfr_clk_rpls = '1') then
                case (addr_h8) is
                    when x"59"  => lcen_cfr_59_cfrclk <= '1'; lcen_cfr_5A_cfrclk <= '0'; lcen_cfr_5B_cfrclk <= '0';
                    when x"5A"  => lcen_cfr_59_cfrclk <= '0'; lcen_cfr_5A_cfrclk <= '1'; lcen_cfr_5B_cfrclk <= '0';
                    when x"5B"  => lcen_cfr_59_cfrclk <= '0'; lcen_cfr_5A_cfrclk <= '0'; lcen_cfr_5B_cfrclk <= '1';
                    when others => lcen_cfr_59_cfrclk <= '0'; lcen_cfr_5A_cfrclk <= '0'; lcen_cfr_5B_cfrclk <= '0';
                end case;
            else
                lcen_cfr_59_cfrclk <= '0';
                lcen_cfr_5A_cfrclk <= '0';
                lcen_cfr_5B_cfrclk <= '0';
            end if;
        end if;
    end process;

    reg_cfr_opd_flag_w <= zeros(RDATA_WIDTH-1 downto TX_ANT_NUM) & cfr_opd_flag_d2;

    REG_RC_0x05B10 : REG32_LATCH generic map(x"000000FF", x"10") port map(RST_CFR, CLK_CFR, lcen_cfr_5B_cfrclk, addr_l8, reg_cfr_opd_flag_w, reg_cfr_opd_flag_s, reg_cfr_opd_flag_f);

    P_CFR_REG_Read_Enable_CFR_CLK : process(RST_CFR, CLK_CFR) begin
        if (RST_CFR = '1') then
            rden_cfr_59_cfrclk <= '0';
            rden_cfr_5A_cfrclk <= '0';
            rden_cfr_5B_cfrclk <= '0';
        elsif (CLK_CFR'event) and (CLK_CFR = '1') then
            if (rden_cfr_clk_rpls = '1') then
                case (addr_h8) is
                    when x"59"  => rden_cfr_59_cfrclk <= '1'; rden_cfr_5A_cfrclk <= '0'; rden_cfr_5B_cfrclk <= '0';
                    when x"5A"  => rden_cfr_59_cfrclk <= '0'; rden_cfr_5A_cfrclk <= '1'; rden_cfr_5B_cfrclk <= '0';
                    when x"5B"  => rden_cfr_59_cfrclk <= '0'; rden_cfr_5A_cfrclk <= '0'; rden_cfr_5B_cfrclk <= '1';
                    when others => rden_cfr_59_cfrclk <= '0'; rden_cfr_5A_cfrclk <= '0'; rden_cfr_5B_cfrclk <= '0';
                end case;
            else
                rden_cfr_59_cfrclk <= '0';
                rden_cfr_5A_cfrclk <= '0';
                rden_cfr_5B_cfrclk <= '0';
            end if;
        end if;
    end process;

    G_DL2_CFR_REG_0x59XX : if (TX_ANT_NUM = 2) generate begin
        P_DL2_CFR_REG_0x59XX : process(RST_CFR, CLK_CFR) begin
            if (RST_CFR = '1') then
                reg_rdata_59_cfrclk <= (others => '0');
            elsif (CLK_CFR'event) and (CLK_CFR = '1') then
                if (rden_cfr_59_cfrclk = '1') then
                    case (addr_l8) is
                        when x"00"  => reg_rdata_59_cfrclk <= CFR_PWR_IN(0)             ;
                        when x"01"  => reg_rdata_59_cfrclk <= CFR_PWR_IN(1)             ;

                        when x"10"  => reg_rdata_59_cfrclk <= reg_cfr_fwd_pwr(0)        ;
                        when x"11"  => reg_rdata_59_cfrclk <= reg_cfr_fwd_pwr(1)        ;

                        when x"20"  => reg_rdata_59_cfrclk <= reg_cfr_rvs_pwr(0)        ;
                        when x"21"  => reg_rdata_59_cfrclk <= reg_cfr_rvs_pwr(1)        ;

                        when others => reg_rdata_59_cfrclk <= (others => '0');
                    end case;
                else
                    reg_rdata_59_cfrclk <= reg_rdata_59_cfrclk ;
                end if;
            end if;
        end process;
    end generate;

    G_DL2_CFR_Core_Module2_CFR_REG_0x5AXX : if (TX_ANT_NUM = 2) and (CFR_PATH_PER_MODULE = 2) generate begin
        P_DL2_CFR_REG_0x5AXX : process(RST_CFR, CLK_CFR) begin
            if (RST_CFR = '1') then
                reg_rdata_5A_cfrclk <= (others => '0');
            elsif (CLK_CFR'event) and (CLK_CFR = '1') then
                if (rden_cfr_5A_cfrclk = '1') then
                    case (addr_l8) is
                        when x"00"  => reg_rdata_5A_cfrclk <= reg_cfr_thrsd(0)          ;
                        when x"01"  => reg_rdata_5A_cfrclk <= reg_cfr_thrsd(1)          ;

                        when x"10"  => reg_rdata_5A_cfrclk <= reg_cfr_peak_spacing(0)   ;
                        when x"11"  => reg_rdata_5A_cfrclk <= reg_cfr_peak_spacing(1)   ;

                        when x"20"  => reg_rdata_5A_cfrclk <= reg_cfr_hc_thrsd(0)       ;
                        when x"21"  => reg_rdata_5A_cfrclk <= reg_cfr_hc_thrsd(1)       ;

                        when x"30"  => reg_rdata_5A_cfrclk <= reg_cfr_hc_enb(0)         ;
                        when x"31"  => reg_rdata_5A_cfrclk <= reg_cfr_hc_enb(1)         ;

                        when x"40"  => reg_rdata_5A_cfrclk <= reg_cfr_tap_num(0)        ;
                        when x"41"  => reg_rdata_5A_cfrclk <= reg_cfr_coef_update_enb(0);
                        when x"42"  => reg_rdata_5A_cfrclk <= reg_cfr_coef_addr(0)      ;
                        when x"43"  => reg_rdata_5A_cfrclk <= reg_cfr_coef_wdata(0)     ;
                        when x"44"  => reg_rdata_5A_cfrclk <= reg_cfr_coef_wen(0)       ;

                        when others => reg_rdata_5A_cfrclk <= (others => '0');
                    end case;
                else
                    reg_rdata_5A_cfrclk <= reg_rdata_5A_cfrclk ;
                end if;
            end if;
        end process;
    end generate;

    G_DL2_CFR_REG_0x5BXX : if (TX_ANT_NUM = 2) generate begin
        P_DL2_CFR_REG_0x5BXX : process(RST_CFR, CLK_CFR) begin
            if (RST_CFR = '1') then
                reg_rdata_5B_cfrclk <= (others => '0');
            elsif (CLK_CFR'event) and (CLK_CFR = '1') then
                if (rden_cfr_5B_cfrclk = '1') then
                    case (addr_l8) is
                        when x"00"  => reg_rdata_5B_cfrclk <= reg_cfr_opd_thrsd(0);
                        when x"01"  => reg_rdata_5B_cfrclk <= reg_cfr_opd_thrsd(1);

                        when x"10"  => reg_rdata_5B_cfrclk <= reg_cfr_opd_flag_f  ;
                        when x"11"  => reg_rdata_5B_cfrclk <= reg_cfr_opd_flag_s  ;

                        when x"20"  => reg_rdata_5B_cfrclk <= reg_cfr_opd_pwr(0)  ;
                        when x"21"  => reg_rdata_5B_cfrclk <= reg_cfr_opd_pwr(1)  ;

                        when others => reg_rdata_5B_cfrclk <= (others => '0');
                    end case;
                else
                    reg_rdata_5B_cfrclk <= reg_rdata_5B_cfrclk ;
                end if;
            end if;
        end process;
    end generate;
    
    reg_rdata_cfrclk <= reg_rdata_59_cfrclk when (addr_h8 = x"59") else
                        reg_rdata_5A_cfrclk when (addr_h8 = x"5A") else
                        reg_rdata_5B_cfrclk when (addr_h8 = x"5B") else
                        (others => '0');

-- *************************************************************************************
-- CPU Interface Bus Signal Processing : DPD
-- *************************************************************************************

    P_DPD_Read_Enable_Strobe_CPU_Clock : process(RST_CPUIF, CLK_CPUIF) begin
        if (RST_CPUIF = '1') then
            rden_dpd_cpuclk_sh   <= (others => '0');
            rden_dpd_cpuclk_rpls <= '0';
            lcen_dpd_cpuclk_rpls <= '0';
        elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
            rden_dpd_cpuclk_sh   <= rden_dpd_cpuclk_sh(2 downto 0) & RDEN_CPUIF_IN;
            rden_dpd_cpuclk_rpls <= rden_dpd_cpuclk_sh(0) and (not rden_dpd_cpuclk_sh(1));
            lcen_dpd_cpuclk_rpls <= rden_dpd_cpuclk_sh(0) and (not rden_dpd_cpuclk_sh(1));
        end if;
    end process;

    P_DPD_REG_Write_Enable_DPD_CLK : process(RST_CPUIF, CLK_CPUIF) begin
        if (RST_CPUIF = '1') then
            wren_dpd_5C_cpuclk    <= '0';
            wren_dpd_5D_cpuclk    <= '0';
            wren_dpd_5E_cpuclk    <= '0';
            wren_dpd_5F_cpuclk    <= '0';

            wren_dpd_5D_cpuclk_d1 <= '0';
            wren_dpd_5F_cpuclk_d1 <= '0';

        elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
            if (wren_cpu_clk_rpls = '1') then
                case (addr_h8) is
                    when x"5C"  => wren_dpd_5C_cpuclk <= '1'; wren_dpd_5D_cpuclk <= '0'; wren_dpd_5E_cpuclk <= '0'; wren_dpd_5F_cpuclk <= '0';
                    when x"5D"  => wren_dpd_5C_cpuclk <= '0'; wren_dpd_5D_cpuclk <= '1'; wren_dpd_5E_cpuclk <= '0'; wren_dpd_5F_cpuclk <= '0';
                    when x"5E"  => wren_dpd_5C_cpuclk <= '0'; wren_dpd_5D_cpuclk <= '0'; wren_dpd_5E_cpuclk <= '1'; wren_dpd_5F_cpuclk <= '0';
                    when x"5F"  => wren_dpd_5C_cpuclk <= '0'; wren_dpd_5D_cpuclk <= '0'; wren_dpd_5E_cpuclk <= '0'; wren_dpd_5F_cpuclk <= '1';
                    when others => wren_dpd_5C_cpuclk <= '0'; wren_dpd_5D_cpuclk <= '0'; wren_dpd_5E_cpuclk <= '0'; wren_dpd_5F_cpuclk <= '0';
                end case;
            else
                wren_dpd_5C_cpuclk <= '0';
                wren_dpd_5D_cpuclk <= '0';
                wren_dpd_5E_cpuclk <= '0';
                wren_dpd_5F_cpuclk <= '0';
            end if;

            wren_dpd_5D_cpuclk_d1 <= wren_dpd_5D_cpuclk;
            wren_dpd_5F_cpuclk_d1 <= wren_dpd_5F_cpuclk;
        end if;
    end process;

    P_DPD_Control_Register_CDC_Stobe : process(RST_CPUIF, CLK_CPUIF) begin
        if (RST_CPUIF = '1') then
            reg_dpd_dlhc_thrsd_cdc_strb <= (others=>'0');
            reg_dpd_dlatt_cdc_strb      <= (others=>'0');
            reg_dpd_fbatt_cdc_strb      <= (others=>'0');
        elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
            for i in TX_ANT_NUM-1 downto 0 loop
                if (addr_l8(7 downto 4) = x"1"  and addr_l8(3 downto 0)=i) then
                    reg_dpd_dlhc_thrsd_cdc_strb(i) <= wren_dpd_5F_cpuclk_d1;
                else
                    reg_dpd_dlhc_thrsd_cdc_strb(i) <= '0';
                end if;

                if (addr_l8(7 downto 4) = x"0"  and addr_l8(3 downto 0)=i) then
                    reg_dpd_dlatt_cdc_strb(i)      <= wren_dpd_5D_cpuclk_d1;
                else
                    reg_dpd_dlatt_cdc_strb(i)      <= '0';
                end if;

                if (addr_l8(7 downto 4) = x"4" and addr_l8(3 downto 0)=i) then
                    reg_dpd_fbatt_cdc_strb(i)      <= wren_dpd_5D_cpuclk_d1;
                else
                    reg_dpd_fbatt_cdc_strb(i)      <= '0';
                end if;
            end loop;
        end if;
    end process;

    -- DPD_TOP Test Register
    REG_WR_0x05C0D : REG32_WRITE generic map(x"0FFFFFFF", x"0D", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5C_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_test_ctrl_1);
    REG_WR_0x05C0E : REG32_WRITE generic map(x"FFFFFF03", x"0E", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5C_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_test_ctrl_2);
	REG_WR_0x05C0F : REG32_WRITE generic map(x"0000000F", x"0F", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5C_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_test_ctrl_3);
    REG_WR_0x05C10 : REG32_WRITE generic map(x"0000000F", x"10", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5C_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_handshake_1);
    REG_WR_0x05C11 : REG32_WRITE generic map(x"0000000F", x"11", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5C_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_handshake_2);

    -- DPD_TOP Control Register
    G_Using_DACIF_ON : if (DACIF_ONOFF_IMPLEMENTATION = TRUE) generate begin
        REG_WR_0x05C80 : REG32_WRITE generic map(x"000000FF", x"80", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5C_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_dldacif_on);
    end generate;

    G_Unusing_DACIF_ON : if (DACIF_ONOFF_IMPLEMENTATION = FALSE) generate begin
        reg_dpd_dldacif_on <= (others => '0');
    end generate;

    G_Using_DL_ATT : if (DPD_ATT_IMPLEMENTATION = TRUE) generate begin
        G_DL2_ATT : if (TX_ANT_NUM = 2) generate begin
            REG_WR_0x05D00 : REG32_WRITE generic map(x"0000FFFF", x"00", x"00008000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5D_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_dlatt_value(0));
            REG_WR_0x05D01 : REG32_WRITE generic map(x"0000FFFF", x"01", x"00008000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5D_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_dlatt_value(1));
        end generate;
    end generate;

    G_Unusing_DL_ATT : if (DPD_ATT_IMPLEMENTATION = FALSE) generate begin
        reg_dpd_dlatt_value <= (others => (others => '0'));
    end generate;

    G_Using_FB_Path : if (USING_FB_PATH = TRUE) generate begin

        G_Using_FB_ATT : if (FB_ATTEN_IMPLEMENTATION = TRUE) generate begin
            G_DL2_FBATT : if (TX_ANT_NUM = 2) generate begin
                REG_WR_0x05D40 : REG32_WRITE generic map(x"FFFFFFFF", x"40", x"80008000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5D_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_fbatt_value(0));
                REG_WR_0x05D41 : REG32_WRITE generic map(x"FFFFFFFF", x"41", x"80008000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5D_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_fbatt_value(1));
            end generate;
        end generate;

        G_Unusing_FB_ATT : if (FB_ATTEN_IMPLEMENTATION = FALSE) generate begin
            reg_dpd_fbatt_value <= (others => (others => '0'));
        end generate;

    end generate;

    G_Unusing_FB_Path : if (USING_FB_PATH = FALSE) generate begin
        reg_dpd_fbatt_value <= (others => (others => '0'));
    end generate;

    -- SVR20C
    REG_WR_0x05DD0 : REG32_WRITE generic map(x"FFFFFFFF", x"D0", FB_PWR_UPT_CNT) port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5D_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_pwr_update_num);

    G_Using_DL_Mixer : if (DL_MIXER_IMPLEMENTATION = TRUE) generate begin
        REG_WR_0x05F00 : REG32_WRITE generic map(x"000000FF", x"00", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5F_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_dlmixer_wren);
        REG_WR_0x05F01 : REG32_WRITE generic map(x"FFFFFFFF", x"01", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5F_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_dlmixer_word(0));
        REG_WR_0x05F02 : REG32_WRITE generic map(x"FFFFFFFF", x"02", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5F_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_dlmixer_word(1));
    end generate;

    G_Unusing_DL_Mixer : if (DL_MIXER_IMPLEMENTATION = FALSE) generate begin
        reg_dpd_dlmixer_wren <= (others => '0');
        reg_dpd_dlmixer_word <= (others => (others => '0'));
    end generate;

    G_Using_DPD_HC : if (DPD_HC_IMPLEMENTATION = TRUE) generate begin
        G_DL2_HC : if (TX_ANT_NUM = 2) generate begin
            REG_WR_0x05F10 : REG32_WRITE generic map(x"0000FFFF", x"10", x"00007530") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5F_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_dlhc_thrsd(0));
            REG_WR_0x05F11 : REG32_WRITE generic map(x"0000FFFF", x"11", x"00007530") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5F_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_dlhc_thrsd(1));
        end generate;
    end generate;

    G_Unusing_DPD_HC : if (DPD_HC_IMPLEMENTATION = FALSE) generate begin
        reg_dpd_dlhc_thrsd <= (others => (others => '0'));
    end generate;

    G_Using_DL_Filter : if (DPD_FILTER_IMPLEMENTATION = TRUE) generate begin
        REG_WR_0x05F30 : REG32_WRITE generic map(x"000000FF", x"30", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5F_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_dlfilter_coef_wren );
        REG_WR_0x05F31 : REG32_WRITE generic map(x"000000FF", x"31", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5F_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_dlfilter_coef_rden );
        REG_WR_0x05F32 : REG32_WRITE generic map(x"000000FF", x"32", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5F_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_dlfilter_coef_wrdn );
        REG_WR_0x05F33 : REG32_WRITE generic map(x"000000FF", x"33", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5F_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_dlfilter_coef_addr );
        REG_WR_0x05F34 : REG32_WRITE generic map(x"0000FFFF", x"34", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5F_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_dlfilter_coef_wdata);
    end generate;

    G_Unusing_DL_Filter : if (DPD_FILTER_IMPLEMENTATION = FALSE) generate begin
        reg_dpd_dlfilter_coef_wren  <= (others => '0');
        reg_dpd_dlfilter_coef_rden  <= (others => '0');
        reg_dpd_dlfilter_coef_wrdn  <= (others => '0');
        reg_dpd_dlfilter_coef_addr  <= (others => '0');
        reg_dpd_dlfilter_coef_wdata <= (others => '0');
    end generate;

    REG_WR_0x05F50 : REG32_WRITE generic map(x"000000FF", x"50", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5F_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_fbmixer_wren);
    REG_WR_0x05F51 : REG32_WRITE generic map(x"FFFFFFFF", x"51", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_dpd_5F_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_fbmixer_word(0));    

    P_DPD_REG_Latch_Clear_Enable_CPU_CLK : process(RST_CPUIF, CLK_CPUIF) begin
        if (RST_CPUIF = '1') then
            lcen_dpd_5C_cpuclk <= '0';
            lcen_dpd_5D_cpuclk <= '0';
            lcen_dpd_5E_cpuclk <= '0';
            lcen_dpd_5F_cpuclk <= '0';
        elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
            if (lcen_dpd_cpuclk_rpls = '1') then
                case (addr_h8) is
                    when x"5C"  => lcen_dpd_5C_cpuclk <= '1'; lcen_dpd_5D_cpuclk <= '0'; lcen_dpd_5E_cpuclk <= '0'; lcen_dpd_5F_cpuclk <= '0';
                    when x"5D"  => lcen_dpd_5C_cpuclk <= '0'; lcen_dpd_5D_cpuclk <= '1'; lcen_dpd_5E_cpuclk <= '0'; lcen_dpd_5F_cpuclk <= '0';
                    when x"5E"  => lcen_dpd_5C_cpuclk <= '0'; lcen_dpd_5D_cpuclk <= '0'; lcen_dpd_5E_cpuclk <= '1'; lcen_dpd_5F_cpuclk <= '0';
                    when x"5F"  => lcen_dpd_5C_cpuclk <= '0'; lcen_dpd_5D_cpuclk <= '0'; lcen_dpd_5E_cpuclk <= '0'; lcen_dpd_5F_cpuclk <= '1';
                    when others => lcen_dpd_5C_cpuclk <= '0'; lcen_dpd_5D_cpuclk <= '0'; lcen_dpd_5E_cpuclk <= '0'; lcen_dpd_5F_cpuclk <= '0';
                end case;
            else
                lcen_dpd_5F_cpuclk <= '0';
            end if;
        end if;
    end process;

    REG_RC_0x05F18 : REG32_LATCH generic map(x"000000FF", x"18") port map(RST_DPD, CLK_DPD, lcen_dpd_5F_cpuclk, addr_l8, reg_dpd_dlhc_on_w, reg_dpd_dlhc_on_s, reg_dpd_dlhc_on_f);

    G_DPDHC_FLAG_CNT : for I in 0 to (TX_ANT_NUM-1) generate begin
        U_DPDHC_FLAG_CNT : HIGHCNT generic map(RDATA_WIDTH) port map(RST_DPD, CLK_DPD, reg_dpd_dlhc_on_w(I), clr_dpdhc_cnt_sh(I)(1), reg_dpdhc_cnt(I));     
    end generate;

    P_HC_FLAGCNT_CLR_DC : process(CLK_DPD) begin
        if (CLK_DPD'event) and (CLK_DPD = '1') then
            for I in 0 to (TX_ANT_NUM-1) loop
                clr_dpdhc_cnt_sh(I) <= clr_dpdhc_cnt_sh(I)(0) & clr_dpdhc_cnt(I);
            end loop;
        end if;
    end process;

    P_DPD_REG_Read_Enable_CPU_CLK : process(RST_CPUIF, CLK_CPUIF) begin
        if (RST_CPUIF = '1') then
            rden_dpd_5C_cpuclk <= '0';
            rden_dpd_5D_cpuclk <= '0';
            rden_dpd_5E_cpuclk <= '0';
            rden_dpd_5F_cpuclk <= '0';
        elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
            if (rden_dpd_cpuclk_rpls = '1') then
                case (addr_h8) is
                    when x"5C"  => rden_dpd_5C_cpuclk <= '1'; rden_dpd_5D_cpuclk <= '0'; rden_dpd_5E_cpuclk <= '0'; rden_dpd_5F_cpuclk <= '0';
                    when x"5D"  => rden_dpd_5C_cpuclk <= '0'; rden_dpd_5D_cpuclk <= '1'; rden_dpd_5E_cpuclk <= '0'; rden_dpd_5F_cpuclk <= '0';
                    when x"5E"  => rden_dpd_5C_cpuclk <= '0'; rden_dpd_5D_cpuclk <= '0'; rden_dpd_5E_cpuclk <= '1'; rden_dpd_5F_cpuclk <= '0';
                    when x"5F"  => rden_dpd_5C_cpuclk <= '0'; rden_dpd_5D_cpuclk <= '0'; rden_dpd_5E_cpuclk <= '0'; rden_dpd_5F_cpuclk <= '1';
                    when others => rden_dpd_5C_cpuclk <= '0'; rden_dpd_5D_cpuclk <= '0'; rden_dpd_5E_cpuclk <= '0'; rden_dpd_5F_cpuclk <= '0';
                end case;
            else
                rden_dpd_5C_cpuclk <= '0';
                rden_dpd_5D_cpuclk <= '0';
                rden_dpd_5E_cpuclk <= '0';
                rden_dpd_5F_cpuclk <= '0';
            end if;
        end if;
    end process;

    P_DL_DPD_REG_Read_0x5CXX : process(RST_CPUIF, CLK_CPUIF) begin
        if (RST_CPUIF = '1') then
            reg_rdata_5C_cpuclk <= (others => '0');
        elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
            if (rden_dpd_5C_cpuclk = '1') then
                case (addr_l8) is
                    when x"80"   => reg_rdata_5C_cpuclk <= reg_dpd_dldacif_on;
                    when others  => reg_rdata_5C_cpuclk <= (others => '0');
                end case;
            else
                reg_rdata_5C_cpuclk <= reg_rdata_5C_cpuclk;
            end if;
        end if;
    end process;

    G_DL2_DPD_REG_Read_0x5DXX : if (TX_ANT_NUM = 2) generate begin
        P_DL2_DPD_REG_Read_0x5DXX : process(RST_CPUIF, CLK_CPUIF) begin
            if (RST_CPUIF = '1') then
                reg_rdata_5D_cpuclk <= (others => '0');
            elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
                if (rden_dpd_5D_cpuclk = '1') then
                    case (addr_l8) is
                        when x"00"  => reg_rdata_5D_cpuclk <= reg_dpd_dlatt_value(0);
                        when x"01"  => reg_rdata_5D_cpuclk <= reg_dpd_dlatt_value(1);

                        when x"40"  => reg_rdata_5D_cpuclk <= reg_dpd_fbatt_value(0);
                        when x"41"  => reg_rdata_5D_cpuclk <= reg_dpd_fbatt_value(1);

                        when x"80"  => reg_rdata_5D_cpuclk <= reg_fb_fwd_pwr(0);
                        when x"81"  => reg_rdata_5D_cpuclk <= reg_fb_fwd_pwr(1);

                        when x"C0"  => reg_rdata_5D_cpuclk <= reg_fb_rvs_pwr(0);
                        when x"C1"  => reg_rdata_5D_cpuclk <= reg_fb_rvs_pwr(1);

                        when x"D0"  => reg_rdata_5D_cpuclk <= reg_pwr_update_num;

                        when x"E0"  => reg_rdata_5D_cpuclk <= reg_dpd_dl_pwr(0);
                        when x"E1"  => reg_rdata_5D_cpuclk <= reg_dpd_dl_pwr(1);

                        when x"F0"  => reg_rdata_5D_cpuclk <= DPD_FB_PWR_IN(0);

                        when others => reg_rdata_5D_cpuclk <= (others => '0');
                    end case;
                else
                    reg_rdata_5D_cpuclk <= reg_rdata_5D_cpuclk;
                end if;
            end if;
        end process;
    end generate;
	
    G_DL2_DPD_REG_Read_0x5FXX : if (TX_ANT_NUM = 2) generate begin
        P_DL2_DPD_REG_Read_0x5FXX : process(RST_CPUIF, CLK_CPUIF) begin
            if (RST_CPUIF = '1') then
                clr_dpdhc_cnt       <= (others => '0');
                reg_rdata_5F_cpuclk <= (others => '0');
            elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
                clr_dpdhc_cnt       <= (others => '0');

                if (rden_dpd_5F_cpuclk = '1') then
                    case (addr_l8) is
                        when x"00"   => reg_rdata_5F_cpuclk <= reg_dpd_dlmixer_wren;
                        when x"01"   => reg_rdata_5F_cpuclk <= reg_dpd_dlmixer_word(0);
                        when x"02"   => reg_rdata_5F_cpuclk <= reg_dpd_dlmixer_word(1);

                        when x"10"   => reg_rdata_5F_cpuclk <= reg_dpd_dlhc_thrsd(0);
                        when x"11"   => reg_rdata_5F_cpuclk <= reg_dpd_dlhc_thrsd(1);

                        when x"18"   => reg_rdata_5F_cpuclk <= reg_dpd_dlhc_on_f;
                        when x"19"   => reg_rdata_5F_cpuclk <= reg_dpd_dlhc_on_s;

                        when x"20"   => reg_rdata_5F_cpuclk <= reg_dpdhc_cnt(0); clr_dpdhc_cnt(0) <= '1';
                        when x"21"   => reg_rdata_5F_cpuclk <= reg_dpdhc_cnt(1); clr_dpdhc_cnt(1) <= '1';

                        when x"30"   => reg_rdata_5F_cpuclk <= reg_dpd_dlfilter_coef_wren ;
                        when x"31"   => reg_rdata_5F_cpuclk <= reg_dpd_dlfilter_coef_rden ;
                        when x"32"   => reg_rdata_5F_cpuclk <= reg_dpd_dlfilter_coef_wrdn ;
                        when x"33"   => reg_rdata_5F_cpuclk <= reg_dpd_dlfilter_coef_addr ;
                        when x"34"   => reg_rdata_5F_cpuclk <= reg_dpd_dlfilter_coef_wdata;
                        when x"35"   => reg_rdata_5F_cpuclk <= reg_dpd_dlfilter_coef_rdata;
						
						when x"50"   => reg_rdata_5F_cpuclk <= reg_dpd_fbmixer_wren;
                        when x"51"   => reg_rdata_5F_cpuclk <= reg_dpd_fbmixer_word(0);

                        when others  => reg_rdata_5F_cpuclk <= (others => '0');
                    end case;
                else
                    reg_rdata_5F_cpuclk <= reg_rdata_5F_cpuclk;
                end if;
            end if;
        end process;
    end generate;

    reg_dpd_rdata_cpuclk <= reg_rdata_5C_cpuclk when (addr_h8 = x"5C") else
                            reg_rdata_5D_cpuclk when (addr_h8 = x"5D") else
                            reg_rdata_5E_cpuclk when (addr_h8 = x"5E") else
                            reg_rdata_5F_cpuclk when (addr_h8 = x"5F") else
                            (others => '0');

-- *************************************************************************************
-- PIM Block Control Register
-- *************************************************************************************

    P_PIM_REG_Write_Enable_PIM_CLK : process(RST_CPUIF, CLK_CPUIF) begin
        if (RST_CPUIF = '1') then
            wren_pim_60_cpuclk    <= '0';
            wren_pim_60_cpuclk_d1 <= '0';
        elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
            if (wren_cpu_clk_rpls = '1') then
                case (addr_h8) is
                    when x"60"  => wren_pim_60_cpuclk <= '1';
                    when others => wren_pim_60_cpuclk <= '0';
                end case;
            else
                wren_pim_60_cpuclk <= '0';
            end if;

            wren_pim_60_cpuclk_d1 <= wren_pim_60_cpuclk;
        end if;
    end process;

    G_Using_PIM_Block : if (PIM_IMPLEMENTATION = TRUE) generate begin
    P_PIM_Control_Register_CDC_Stobe : process(RST_CPUIF, CLK_CPUIF) begin
            if (RST_CPUIF = '1') then
                reg_dpd_pim_pnpc_cdc_strb <= '0';
                    reg_pim_interb_duc_gain_cdc_strb <= '0';
            elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
                if (addr_l8 = x"01") then
                    reg_dpd_pim_pnpc_cdc_strb  <= wren_pim_60_cpuclk_d1;
                else
                    reg_dpd_pim_pnpc_cdc_strb  <= '0';
                end if;

                if (addr_l8(7 downto 4) = x"5") then
                    reg_pim_interb_duc_gain_cdc_strb  <= wren_pim_60_cpuclk_d1;
                else
                    reg_pim_interb_duc_gain_cdc_strb  <= '0';
                end if;
            end if;
        end process;

        REG_WR_0x06000 : REG32_WRITE generic map(x"00FF00FF", x"00", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pim_60_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_pim_mode_on);
        REG_WR_0x06001 : REG32_WRITE generic map(x"0000FFFF", x"01", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pim_60_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_pim_pnpc_sel);

        REG_WR_0x06010 : REG32_WRITE generic map(x"00000001", x"10", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pim_60_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_pim_mixer_wren);
        REG_WR_0x06011 : REG32_WRITE generic map(x"FFFFFFFF", x"11", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pim_60_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_pim_mixer_word);

        REG_WR_0x06020 : REG32_WRITE generic map(x"000000FF", x"20", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pim_60_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_pim_lpf_coef_wren );
        REG_WR_0x06021 : REG32_WRITE generic map(x"000000FF", x"21", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pim_60_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_pim_lpf_coef_rden );
        REG_WR_0x06022 : REG32_WRITE generic map(x"000000FF", x"22", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pim_60_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_pim_lpf_coef_wrdn );
        REG_WR_0x06023 : REG32_WRITE generic map(x"000000FF", x"23", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pim_60_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_pim_lpf_coef_addr );
        REG_WR_0x06024 : REG32_WRITE generic map(x"0000FFFF", x"24", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pim_60_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_pim_lpf_coef_wdata);

        REG_WR_0x06030 : REG32_WRITE generic map(x"00000003", x"30", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pim_60_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_pim_ul_mixer_wren);
        REG_WR_0x06031 : REG32_WRITE generic map(x"FFFFFFFF", x"31", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pim_60_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_pim_ul_mixer_word0);        

        REG_WR_0x06040 : REG32_WRITE generic map(x"000000FF", x"40", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pim_60_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_dpd_pim_cfr_ref_sel  );
        
        -- RX ANT NUM = 2
        REG_WR_0x06050 : REG32_WRITE generic map(x"0000FFFF", x"50", x"00004000") port map(RST_CPUIF, CLK_CPUIF, wren_pim_60_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_pim_interb_duc_gain(0));
        REG_WR_0x06051 : REG32_WRITE generic map(x"0000FFFF", x"51", x"00004000") port map(RST_CPUIF, CLK_CPUIF, wren_pim_60_cpuclk, addr_l8, WDATA_CPUIF_IN, reg_pim_interb_duc_gain(1));
    end generate;

    G_Unusing_PIM_Block : if (PIM_IMPLEMENTATION = FALSE) generate begin
        reg_dpd_pim_mode_on                     <= (others => '0');
        reg_dpd_pim_cfr_ref_sel                 <= (others => '0');
        reg_dpd_pim_pnpc_cdc_strb               <= '0';
        reg_dpd_pim_pnpc_sel                    <= (others => '0');
        reg_pim_interb_duc_gain_cdc_strb        <= '0';
        reg_pim_interb_duc_gain                 <= (others => (others => '0'));

        reg_dpd_pim_mixer_wren                  <= (others => '0');
        reg_dpd_pim_mixer_word                  <= (others => '0');

        reg_dpd_pim_lpf_coef_wren               <= (others => '0');
        reg_dpd_pim_lpf_coef_rden               <= (others => '0');
        reg_dpd_pim_lpf_coef_wrdn               <= (others => '0');
        reg_dpd_pim_lpf_coef_addr               <= (others => '0');
        reg_dpd_pim_lpf_coef_wdata              <= (others => '0');

        reg_dpd_pim_ul_mixer_wren               <= (others => '0');
        reg_dpd_pim_ul_mixer_word0              <= (others => '0');        
    end generate;

    P_PIM_Read_Enable_Strobe_CPU_Clock : process(RST_CPUIF, CLK_CPUIF) begin
        if (RST_CPUIF = '1') then
            rden_pim_cpuclk_sh   <= (others => '0');
            rden_pim_cpuclk_rpls <= '0';
        elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
            rden_pim_cpuclk_sh   <= rden_pim_cpuclk_sh(2 downto 0) & RDEN_CPUIF_IN;
            rden_pim_cpuclk_rpls <= rden_pim_cpuclk_sh(0) and (not rden_pim_cpuclk_sh(1));
        end if;
    end process;

    P_PIM_REG_Read_Enable_CPU_CLK : process(RST_CPUIF, CLK_CPUIF) begin
        if (RST_CPUIF = '1') then
            rden_pim_60_cpuclk <= '0';
        elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
            if (rden_pim_cpuclk_rpls = '1') then
                case (addr_h8) is
                    when x"60"  => rden_pim_60_cpuclk <= '1';
                    when others => rden_pim_60_cpuclk <= '0';
                end case;
            else
                rden_pim_60_cpuclk <= '0';
            end if;
        end if;
    end process;

    P_PIM_REG_Read_0x60XX : process(RST_CPUIF, CLK_CPUIF) begin
        if (RST_CPUIF = '1') then
            reg_pim_rdata_60_cpuclk <= (others => '0');
        elsif (CLK_CPUIF'event) and (CLK_CPUIF = '1') then
            if (rden_pim_60_cpuclk = '1') then
                case (addr_l8) is
                    when x"00"  => reg_pim_rdata_60_cpuclk <= reg_dpd_pim_mode_on;
                    when x"01"  => reg_pim_rdata_60_cpuclk <= reg_dpd_pim_pnpc_sel;

                    when x"10"  => reg_pim_rdata_60_cpuclk <= reg_dpd_pim_mixer_wren;
                    when x"11"  => reg_pim_rdata_60_cpuclk <= reg_dpd_pim_mixer_word;

                    when x"20"  => reg_pim_rdata_60_cpuclk <= reg_dpd_pim_lpf_coef_wren;
                    when x"21"  => reg_pim_rdata_60_cpuclk <= reg_dpd_pim_lpf_coef_rden;
                    when x"22"  => reg_pim_rdata_60_cpuclk <= reg_dpd_pim_lpf_coef_wrdn;
                    when x"23"  => reg_pim_rdata_60_cpuclk <= reg_dpd_pim_lpf_coef_addr;
                    when x"24"  => reg_pim_rdata_60_cpuclk <= reg_dpd_pim_lpf_coef_wdata;
                    when x"25"  => reg_pim_rdata_60_cpuclk <= reg_dpd_pim_lpf_coef_rdata;

                    when x"30"  => reg_pim_rdata_60_cpuclk <= reg_dpd_pim_ul_mixer_wren;
                    when x"31"  => reg_pim_rdata_60_cpuclk <= reg_dpd_pim_ul_mixer_word0;                    

                    when x"40"  => reg_pim_rdata_60_cpuclk <= reg_dpd_pim_cfr_ref_sel;

                    when x"50"  => reg_pim_rdata_60_cpuclk <= reg_pim_interb_duc_gain(0);
                    when x"51"  => reg_pim_rdata_60_cpuclk <= reg_pim_interb_duc_gain(1);

                    when others => reg_pim_rdata_60_cpuclk <= (others => '0');
                end case;
            else
                reg_pim_rdata_60_cpuclk <= reg_pim_rdata_60_cpuclk;
            end if;
        end if;
    end process;

    reg_pim_rdata_cpuclk <=  reg_pim_rdata_60_cpuclk when (ADDR_CPUIF_IN(15 downto 8) = x"60") else
                             (others => '0');

-- *************************************************************************************
-- Output Assign
-- *************************************************************************************

    RDVLD_CPUIF_OUT               <= rdvld_cpu_clk;

    RDATA_CPUIF_OUT               <= reg_rdata_cpuclk     when (addr_h8 = x"50") else
                                     reg_rdata_cpuclk     when (ADDR_CPUIF_IN(15 downto 4) = x"540") else
                                     reg_rdata_cpuclk     when (addr_h8 = x"58") else
                                     reg_rdata_cpuclk     when (ADDR_CPUIF_IN(15 downto 4) = x"5C0") else
									 reg_rdata_cpuclk     when (ADDR_CPUIF_IN(15 downto 4) = x"5C1") else
									 reg_rdata_dducclk    when (ADDR_CPUIF_IN(15 downto 4) = x"543") else
                                     reg_rdata_dducclk    when (ADDR_CPUIF_IN(15 downto 4) = x"544") else
                                     reg_rdata_dducclk    when (ADDR_CPUIF_IN(15 downto 4) = x"545") else
                                     reg_rdata_dducclk    when (ADDR_CPUIF_IN(15 downto 4) = x"546") else
                                     reg_rdata_dducclk    when (ADDR_CPUIF_IN(15 downto 4) = x"547") else
                                     reg_rdata_dducclk    when (ADDR_CPUIF_IN(15 downto 4) = x"548") else
                                     reg_rdata_dducclk    when (ADDR_CPUIF_IN(15 downto 4) = x"54C") else
                                     reg_rdata_dducclk    when (addr_h8 = x"55") else
                                     reg_rdata_dducclk    when (addr_h8 = x"56") else
                                     reg_rdata_dducclk    when (addr_h8 = x"57") else
                                     reg_rdata_cfrclk     when (addr_h8 = x"59") else
                                     reg_rdata_cfrclk     when (addr_h8 = x"5A") else
                                     reg_rdata_cfrclk     when (addr_h8 = x"5B") else
                                     reg_dpd_rdata_cpuclk when (ADDR_CPUIF_IN(15 downto 4) = x"5C8") else
                                     reg_dpd_rdata_cpuclk when (addr_h8 = x"5D") else
                                     reg_dpd_rdata_cpuclk when (addr_h8 = x"5E") else
                                     reg_dpd_rdata_cpuclk when (addr_h8 = x"5F") else
                                     reg_pim_rdata_cpuclk when (addr_h8 = x"60") else
                                     (others => '0');

    -- DSP_TOP Register
    P_DSPTOP_REG_Test_CTRL_STRB : process(RST_CPUIF, CLK_CPUIF) begin
        if (RST_CPUIF = '1') then
            reg_dsp_test_ctrl_0_strb <= '0';
        elsif (CLK_CPUiF'event) and (CLK_CPUIF = '1') then
            reg_dsp_test_ctrl_0_strb <= wren_dsp_50_cpuclk;
        end if;
    end process;

    DSP_DUMP_SEL_STRB_OUT           <= reg_dsp_test_ctrl_0_strb;
    DSP_DUMP_SEL_OUT                <= reg_dsp_test_ctrl_0( 7 downto  0);
    DSP_TEST_LB_OUT                 <= reg_dsp_lb_ctrl_0(0);

    -- DDUC Register
    G_DUC_ATTEN : for I in 0 to (TX_ANT_NUM-1) generate begin
        DDUC_DL_PATH_ATT_OUT(I)     <= reg_dduc_path_dl_att(I)(15 downto 0);
        DDUC_DL_PATH_DLY_OUT(I)     <= reg_dduc_path_dl_dly(I)(11 downto 0);
    end generate;

    G_DDC_DLY : for I in 0 to (RX_ANT_NUM-1) generate begin
        DDUC_UL_PATH_DLY_OUT(I)     <= reg_dduc_path_ul_dly(I)(11 downto 0);
    end generate; 

    G_DUC_Mixer_Block_Gain : for I in 0 to (TX_ANT_NUM*DL_BBIQARY_NUM-1) generate begin
        DDUC_DUC_NCO_WEN_OUT(I)     <= reg_dduc_duc_nco_wen(I);
        DDUC_DUC_NCO_DATA_OUT(I)    <= reg_dduc_duc_nco_data(I);
        DDUC_DUC_GAIN_OUT(I)        <= reg_dduc_duc_gain(I)(15 downto 0);
    end generate;

    DDUC_DUC_TO_ANT_SUM_MODE_OUT    <= reg_dduc_duc_to_ant_sum_mode((TX_ANT_NUM*DL_BBIQARY_NUM/2)-1 downto 0);

    G_DUC_to_DL_ANT_SEL_Register : for I in 0 to ((TX_ANT_NUM*DL_BBIQARY_NUM/2)-1) generate begin
        dduc_duc_to_ant_sel(I)      <= reg_dduc_duc_to_ant_sel(I)(2*TX_ANT_NUM-1 downto 0);
    end generate;

    G_DL_BBIQARY2_DUC_to_DL_ANT_SEL : if (DL_BBIQARY_NUM = 2 and TX_ANT_NUM = 2) generate begin
        DDUC_DUC_TO_ANT_SEL_OUT     <= dduc_duc_to_ant_sel(1) & dduc_duc_to_ant_sel(0);
    end generate;

    G_DL_BBIQARY1_DUC_to_DL_ANT_SEL : if (DL_BBIQARY_NUM = 1 and TX_ANT_NUM = 2) generate begin
        DDUC_DUC_TO_ANT_SEL_OUT     <= dduc_duc_to_ant_sel(0);
    end generate;

    G_DDC_Mixer_Block_Gain : for I in 0 to (RX_ANT_NUM*UL_BBIQARY_NUM-1) generate begin
        DDUC_DDC_NCO_WEN_OUT(I)     <= reg_dduc_ddc_nco_wen(I);
        DDUC_DDC_NCO_DATA_OUT(I)    <= reg_dduc_ddc_nco_data(I);
        DDUC_DDC_GAIN_OUT(I)        <= reg_dduc_ddc_gain(I)(15 downto 0);
    end generate;

    G_DDC_to_UL_ANT_SEL_Register : for I in 0 to ((RX_ANT_NUM*UL_BBIQARY_NUM/2)-1) generate begin
        DDUC_UL_TO_ANT_SEL_OUT(I)   <= reg_dduc_ul_to_ant_sel(I)(7 downto 0);
    end generate;

    -- CFR Register
    CFR_CORE_BYPASS_OUT          <= reg_cfr_test_ctrl_1(TX_ANT_NUM-1 downto 0);

    G_DL_CFR_REG_Output_Assign : for I in 0 to (TX_ANT_NUM-1) generate begin
        CFR_THRSD_OUT(I)        <= reg_cfr_thrsd(I)(15 downto 0);
        CFR_PEAK_SPACING_OUT(I) <= reg_cfr_peak_spacing(I)(7 downto 0);
        CFR_HC_THRSD_OUT(I)     <= reg_cfr_hc_thrsd(I)(15 downto 0);
        CFR_OPD_TRSHD_OUT(I)    <= reg_cfr_opd_thrsd(I);
    end generate;

    G_DL_CFR_Core_Module_REG_Output_Assign : for I in 0 to ((TX_ANT_NUM/CFR_PATH_PER_MODULE)-1) generate begin
        CFR_TAP_NUM_OUT(I)      <= reg_cfr_tap_num(I)(9 downto 0);
        CFR_COEF_ADDR_OUT(I)    <= reg_cfr_coef_addr(I)(9 downto 0);
        CFR_COEF_WDATA_OUT(I)   <= reg_cfr_coef_wdata(I);
    end generate;

    G_DL2_CFR_REG_Enable_Assign : if (TX_ANT_NUM = 2) generate begin
        CFR_HC_ENB_OUT           <= reg_cfr_hc_enb(1)(0)&reg_cfr_hc_enb(0)(0);

        G_CFR_Core_Module2_REG_Enable_Assign : if (CFR_PATH_PER_MODULE = 2) generate begin
            CFR_COEF_UPDATE_ENB_OUT(0) <= reg_cfr_coef_update_enb(0)(0);
            CFR_COEF_WEN_OUT(0)        <= reg_cfr_coef_wen(0)(0);
        end generate;

    end generate;
   
    -- DPD Register
    DPD_DL_BULK_NCO_WEN_OUT      <= reg_dpd_dlmixer_wren(TX_ANT_NUM-1 downto 0);
    DPD_DL_BULK_NCO_WORD_OUT     <= reg_dpd_dlmixer_word;

    DPD_CORE_BYPASS_OUT          <= reg_dpd_test_ctrl_1(TX_ANT_NUM-1 downto 0);

    DPD_HC_THRSD_CDC_STRB_OUT    <= reg_dpd_dlhc_thrsd_cdc_strb(TX_ANT_NUM-1 downto 0);
    DPD_DL_ATT_CDC_STRB_OUT      <= reg_dpd_dlatt_cdc_strb(TX_ANT_NUM-1 downto 0);

    G_DL_THRSD_ATT_Value_Assign : for I in 0 to (TX_ANT_NUM-1) generate begin
        DPD_HC_THRSD_OUT(I)      <= reg_dpd_dlhc_thrsd(I)(15 downto 0);
        DPD_DL_ATT_OUT(I)        <= reg_dpd_dlatt_value(I)(15 downto 0);
    end generate;

    DPD_OUTFILTER_BYPASS_OUT     <= reg_dpd_test_ctrl_1(TX_ANT_NUM+8-1 downto 8);
    DPD_OUTFILTER_COEF_WEN_OUT   <= reg_dpd_dlfilter_coef_wren(TX_ANT_NUM-1 downto 0);
    DPD_OUTFILTER_COEF_REN_OUT   <= reg_dpd_dlfilter_coef_rden(TX_ANT_NUM-1 downto 0);
    DPD_OUTFILTER_COEF_WRDN_OUT  <= reg_dpd_dlfilter_coef_wrdn(TX_ANT_NUM-1 downto 0);
    DPD_OUTFILTER_COEF_ADDR_OUT  <= reg_dpd_dlfilter_coef_addr( 7 downto 0);
    DPD_OUTFILTER_COEF_WDATA_OUT <= reg_dpd_dlfilter_coef_wdata(15 downto 0);

    DPD_DACIF_ONOFF_BYPASS_OUT   <= reg_dpd_test_ctrl_1(TX_ANT_NUM+16-1 downto 16);
    DPD_DACIF_ONOFF_ON_OUT       <= reg_dpd_dldacif_on(TX_ANT_NUM-1 downto 0);

    DPD_FB_BULK_NCO_WEN_OUT      <= reg_dpd_fbmixer_wren(FB_PATH_NUM-1 downto 0);
    DPD_FB_BULK_NCO_WORD_OUT     <= reg_dpd_fbmixer_word;

    DPD_FB_FILTER_BYPASS_OUT     <= reg_dpd_test_ctrl_1(24+FB_PATH_NUM-1 downto 24);
    DPD_SC_LB_TEST_ON_OUT        <= reg_dpd_test_ctrl_2( 0);

    DPD_FB_ATT_CDC_STRB_OUT      <= reg_dpd_fbatt_cdc_strb(TX_ANT_NUM-1 downto 0);

    G_FBATT_Value_Assign : for I in 0 to (TX_ANT_NUM-1) generate begin
        DPD_FB_FWD_ATT_OUT(I)    <= reg_dpd_fbatt_value(I)(15 downto  0);
        DPD_FB_RVS_ATT_OUT(I)    <= reg_dpd_fbatt_value(I)(31 downto 16);
    end generate;

    -- PIM Register
    PIM_DETECTOR_ON_OUT          <= reg_dpd_pim_mode_on(16+TX_ANT_NUM-1 downto 16);
    PIM_MITIGATOR_ON_OUT         <= reg_dpd_pim_mode_on(   TX_ANT_NUM-1 downto  0);
    PIM_CFR_REF_SEL_OUT          <= reg_dpd_pim_cfr_ref_sel(TX_ANT_NUM-1 downto  0);

    PIM_PNPC_SEL_STRB_OUT        <= reg_dpd_pim_pnpc_cdc_strb;
    PIM_INTERB_DUC_GAIN_STRB_OUT <= reg_pim_interb_duc_gain_cdc_strb;

    G_PIM_PNPC_SEL_Assign : for I in 0 to (RX_ANT_NUM-1) generate begin
        PIM_PNPC_SEL_OUT(I)          <= reg_dpd_pim_pnpc_sel(2*I+1 downto 2*I);
        PIM_INTERB_DUC_GAIN_OUT(I)   <= reg_pim_interb_duc_gain(I)(15 downto 0);
    end generate;

    DPD_PIM_CORE_BYPASS_OUT      <= reg_dpd_test_ctrl_2(8+TX_ANT_NUM-1 downto 8);

    DPD_PIM_BULK_NCO_WEN_OUT     <= reg_dpd_pim_mixer_wren(0);
    DPD_PIM_BULK_NCO_WORD_OUT    <= reg_dpd_pim_mixer_word;

    DPD_PIM_LPF_BYPASS_OUT       <= reg_dpd_test_ctrl_2(16+RX_ANT_NUM-1 downto 16);
    DPD_PIM_LPF_COEF_WEN_OUT     <= reg_dpd_pim_lpf_coef_wren(RX_ANT_NUM-1 downto 0);
    DPD_PIM_LPF_COEF_REN_OUT     <= reg_dpd_pim_lpf_coef_rden(RX_ANT_NUM-1 downto 0);
    DPD_PIM_LPF_COEF_WRDN_OUT    <= reg_dpd_pim_lpf_coef_wrdn(RX_ANT_NUM-1 downto 0);
    DPD_PIM_LPF_COEF_ADDR_OUT    <= reg_dpd_pim_lpf_coef_addr( 7 downto 0);
    DPD_PIM_LPF_COEF_WDATA_OUT   <= reg_dpd_pim_lpf_coef_wdata(15 downto 0);

    DPD_UL_PIM_NCO_WREN_OUT      <= reg_dpd_pim_ul_mixer_wren(0);
    DPD_UL_PIM_NCO_WORD_OUT      <= reg_dpd_pim_ul_mixer_word0;

end arc_CPUIF_DSP_COMMON;
