library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity DSP_DUMP_MUX is
generic(
    DUMP_CLK0_SEL                  : natural :=  8;                     -- (Operation_Clock)/30.72MHz 
    DUMP_CLK1_SEL                  : natural := 10                      -- (Operation_Clock)/30.72MHz 
    );                             
port(                              
    RST_CPU                        : in  std_logic;                     -- Reset, Active High
                                   
    CLK_SYS                        : in  std_logic;                     -- System Clock :  30.72 MHz
    CLK_SYSX2                      : in  std_logic;                     --  2x(CLK_SYS) :  61.44 MHz
    CLK_SYSX3                      : in  std_logic;                     --  3x(CLK_SYS) :  92.16 MHz
    CLK_SYSX4                      : in  std_logic;                     --  4x(CLK_SYS) : 122.88 MHz
    CLK_SYSX5                      : in  std_logic;                     --  5x(CLK_SYS) : 153.60 MHz
    CLK_SYSX6                      : in  std_logic;                     --  6x(CLK_SYS) : 184.32 MHz
    CLK_SYSX8                      : in  std_logic;                     --  8x(CLK_SYS) : 245.76 MHz
    CLK_SYSX10                     : in  std_logic;                     -- 10x(CLK_SYS) : 307.20 MHz
    CLK_SYSX12                     : in  std_logic;                     -- 12x(CLK_SYS) : 368.64 MHz
    CLK_SYSX16                     : in  std_logic;                     -- 16x(CLK_SYS) : 491.52 MHz
    CLK_SYSX20                     : in  std_logic;                     -- 20x(CLK_SYS) : 614.40 MHz
                                   
    DUMP_POINT_SEL_STRB_IN         : in  std_logic;
    DUMP_POINT_SEL_IN              : in  std_logic_vector( 7 downto 0); -- Dump Point Selection
                                   
    DUMP_DDUC_BFN_STRB_IN          : in  std_logic_vector( 1 downto 0); -- Delayed 10ms Frame Sync Strobe for DUMP DDUC                
    DUMP_DDUC_DVLD_IN              : in  std_logic_vector( 1 downto 0); -- Dump DDUC Sample Valid
    DUMP_DDUC_DATA_IN              : in  std_logic_array32(1 downto 0); -- Dump DDUC Sample                                   

    DUMP_CFR_BFN_STRB_IN           : in  std_logic_vector( 1 downto 0); -- Delayed 10ms Frame Sync Strobe for DUMP CFR                
    DUMP_CFR_DVLD_IN               : in  std_logic_vector( 1 downto 0); -- Dump CFR Sample Valid
    DUMP_CFR_DATA_IN               : in  std_logic_array32(1 downto 0); -- Dump CFR Sample
                                   
    DUMP_DPD_BFN_STRB_IN           : in  std_logic_vector( 1 downto 0); -- Delayed 10ms Frame Sync Strobe for DUMP DPD                
    DUMP_DPD_DVLD_IN               : in  std_logic_vector( 1 downto 0); -- Dump DPD Sample Valid
    DUMP_DPD_DATA_IN               : in  std_logic_array32(1 downto 0); -- Dump DPD Sample
                                   
    DUMP_DSP_BFN_STRB_OUT          : out std_logic_vector( 1 downto 0); -- Delayed 10ms Frame Sync Strobe for DUMP                 
    DUMP_DSP_DVLD_OUT              : out std_logic_vector( 1 downto 0); -- Dump DSP Sample Valid
    DUMP_DSP_DATA_OUT              : out std_logic_array32(1 downto 0)  -- Dump DSP Sample
    );
end DSP_DUMP_MUX;

architecture arc_DSP_DUMP_MUX of DSP_DUMP_MUX is

component RST_SYNC is
generic (
    DLY_NUM        : natural := 4;    -- Number of delay.
    MAX_FANOUT_NUM : integer := 200   -- Number of maximum fanout
    );
port(
    RST_IN         : in  std_logic;   -- Active high asynchronous reset
    CLK            : in  std_logic;   -- clock to be sync'ed to
    RST_OUT        : out std_logic    -- "Synchronised" reset signal
    );         
end component;

signal RST_DUMP              : std_logic_vector( 1 downto 0);

signal CLK_VECTOR            : std_logic_vector(19 downto 0);
signal CLK_DUMP              : std_logic_vector( 1 downto 0);

signal dump_sel_strb         : std_logic_array3( 1 downto 0);
signal dump_sel_strb_rpls    : std_logic_vector( 1 downto 0);
signal dump_sel              : std_logic_array8( 1 downto 0);

signal dump_dsp_bfn_strb_mux : std_logic_vector( 1 downto 0); -- Delayed 10ms Frame Sync Strobe for DUMP                 
signal dump_dsp_dvld_mux     : std_logic_vector( 1 downto 0); -- Dump DSP Sample Valid
signal dump_dsp_data_mux     : std_logic_array32(1 downto 0); -- Dump DSP Sample

attribute KEEP               : string;
attribute KEEP of RST_DUMP   : signal is "TRUE";


begin

    CLK_VECTOR <= CLK_SYSX20&'0'&'0'&'0'&CLK_SYSX16&'0'&'0'&'0'&CLK_SYSX12&'0'&CLK_SYSX10&'0'&CLK_SYSX8&'0'&CLK_SYSX6&CLK_SYSX5&CLK_SYSX4&CLK_SYSX3&CLK_SYSX2&CLK_SYS;  
    CLK_DUMP(0) <= CLK_VECTOR(DUMP_CLK0_SEL-1);
    CLK_DUMP(1) <= CLK_VECTOR(DUMP_CLK1_SEL-1);

    G_DSP_Dump_Domain : for I in 1 downto 0 generate begin

        G_Only_Dump_DSP_CLK0 : if (DUMP_CLK0_SEL = DUMP_CLK1_SEL) generate begin

            G_DSP_Dump_Domain1 : if (I = 0) generate begin
                RST_DUMP(I)                     <= '0';

                dump_sel_strb(I)                <= (others => '0'); 
                dump_sel_strb_rpls(I)           <= '0';

                dump_dsp_bfn_strb_mux(I)        <= '0';
                dump_dsp_dvld_mux(I)            <= '0';
                dump_dsp_data_mux(I)            <= (others => '0');
            end generate;

            G_DSP_Dump_Domain0 : if (I = 1) generate begin

                U_RST_DUMP0 : RST_SYNC generic map(8, 200) port map(RST_CPU, CLK_DUMP(I), RST_DUMP(I));

                P_Dump_0_SEL_CDC : process(RST_DUMP(I), CLK_DUMP(I)) begin
                    if (RST_DUMP(I) = '1') then
                        dump_sel_strb(I)        <= (others => '0'); 
                        dump_sel_strb_rpls(I)   <= '0';
                        dump_sel(I)             <= (others => '0');
                    elsif (CLK_DUMP(I)'event) and (CLK_DUMP(I) = '1') then
                        dump_sel_strb(I)        <= dump_sel_strb(I)(1 downto 0) & DUMP_POINT_SEL_STRB_IN;
                        dump_sel_strb_rpls(I)   <= dump_sel_strb(I)(1) and (not dump_sel_strb(I)(2));

			        if (dump_sel_strb_rpls(I) = '1') then
                            dump_sel(I)         <= DUMP_POINT_SEL_IN;
                        else
                            dump_sel(I)         <= dump_sel(I);
                        end if;
                    end if;
                end process;

                P_DSP_Dump_MUX_0 : process(RST_DUMP(I), CLK_DUMP(I)) begin 
                    if (RST_DUMP(I) = '1') then 
                        dump_dsp_bfn_strb_mux(I) <= '0';
                        dump_dsp_dvld_mux(I)     <= '0'; 
                        dump_dsp_data_mux(I)     <= (others => '0'); 
                    elsif (CLK_DUMP(I)'event) and (CLK_DUMP(I) = '1') then
                        case (dump_sel(I)(7 downto 4)) is
                            when x"0" =>
                                dump_dsp_bfn_strb_mux(I) <= DUMP_DDUC_BFN_STRB_IN(I);
                                dump_dsp_dvld_mux(I)     <= DUMP_DDUC_DVLD_IN(I);
                                dump_dsp_data_mux(I)     <= DUMP_DDUC_DATA_IN(I);
                            when x"8" =>
                                dump_dsp_bfn_strb_mux(I) <= DUMP_DPD_BFN_STRB_IN(I);
                                dump_dsp_dvld_mux(I)     <= DUMP_DPD_DVLD_IN(I);
                                dump_dsp_data_mux(I)     <= DUMP_DPD_DATA_IN(I);
                            when x"9" =>
                                dump_dsp_bfn_strb_mux(I) <= DUMP_DPD_BFN_STRB_IN(I);
                                dump_dsp_dvld_mux(I)     <= DUMP_DPD_DVLD_IN(I);
                                dump_dsp_data_mux(I)     <= DUMP_DPD_DATA_IN(I);
                            when x"A" =>
                                dump_dsp_bfn_strb_mux(I) <= DUMP_DPD_BFN_STRB_IN(I);
                                dump_dsp_dvld_mux(I)     <= DUMP_DPD_DVLD_IN(I);
                                dump_dsp_data_mux(I)     <= DUMP_DPD_DATA_IN(I);
                            when others =>
                                dump_dsp_bfn_strb_mux(I) <= '0';
                                dump_dsp_dvld_mux(I)     <= '0'; 
                                dump_dsp_data_mux(I)     <= (others => '0'); 
                        end case;
                    end if;
                end process;

            end generate;

        end generate;

        G_Dump_DSP_CLK : if (DUMP_CLK0_SEL /= DUMP_CLK1_SEL) generate begin                   

            U_RST_DUMP : RST_SYNC generic map(8, 200) port map(RST_CPU, CLK_DUMP(I), RST_DUMP(I));

            P_Dump_SEL_CDC : process(RST_DUMP(I), CLK_DUMP(I)) begin
                if (RST_DUMP(I) = '1') then
                    dump_sel_strb(I)      <= (others => '0'); 
                    dump_sel_strb_rpls(I) <= '0';
                    dump_sel(I)           <= (others => '0');             
                elsif (CLK_DUMP(I)'event) and (CLK_DUMP(I) = '1') then
                    dump_sel_strb(I)      <= dump_sel_strb(I)(1 downto 0) & DUMP_POINT_SEL_STRB_IN; 
                    dump_sel_strb_rpls(I) <= dump_sel_strb(I)(1) and (not dump_sel_strb(I)(2));

	    	if (dump_sel_strb_rpls(I) = '1') then  
                        dump_sel(I) <= DUMP_POINT_SEL_IN;             
                    else           
                        dump_sel(I) <= dump_sel(I);             
                    end if;
                end if;
            end process;

            G_DSP_Dump_Domain0 : if (I = 0) generate begin

                P_DSP_Dump_MUX_0 : process(RST_DUMP(I), CLK_DUMP(I)) begin 
                    if (RST_DUMP(I) = '1') then 
                        dump_dsp_bfn_strb_mux(I) <= '0';           
                        dump_dsp_dvld_mux(I)     <= '0'; 
                        dump_dsp_data_mux(I)     <= (others => '0'); 
                    elsif (CLK_DUMP(I)'event) and (CLK_DUMP(I) = '1') then
                        case (dump_sel(I)(7 downto 4)) is
                            when x"0" => 
                                dump_dsp_bfn_strb_mux(I) <= DUMP_DDUC_BFN_STRB_IN(I);           
                                dump_dsp_dvld_mux(I)     <= DUMP_DDUC_DVLD_IN(I); 
                                dump_dsp_data_mux(I)     <= DUMP_DDUC_DATA_IN(I); 
                            when x"1" => 
                                dump_dsp_bfn_strb_mux(I) <= DUMP_DDUC_BFN_STRB_IN(I);           
                                dump_dsp_dvld_mux(I)     <= DUMP_DDUC_DVLD_IN(I); 
                                dump_dsp_data_mux(I)     <= DUMP_DDUC_DATA_IN(I); 
                            when others => 	
                                dump_dsp_bfn_strb_mux(I) <= '0';           
                                dump_dsp_dvld_mux(I)     <= '0'; 
                                dump_dsp_data_mux(I)     <= (others => '0'); 
                        end case;
                    end if;
                end process;

            end generate;

            G_DSP_Dump_Domain1 : if (I = 1) generate begin

                P_DSP_Dump_MUX_1 : process(RST_DUMP(I), CLK_DUMP(I)) begin 
                    if (RST_DUMP(I) = '1') then 
                        dump_dsp_bfn_strb_mux(I) <= '0';           
                        dump_dsp_dvld_mux(I)     <= '0'; 
                        dump_dsp_data_mux(I)     <= (others => '0'); 
                    elsif (CLK_DUMP(I)'event) and (CLK_DUMP(I) = '1') then
                        case (dump_sel(I)(7 downto 4)) is
                            when x"2" =>
                                dump_dsp_bfn_strb_mux(I) <= DUMP_DDUC_BFN_STRB_IN(I);           
                                dump_dsp_dvld_mux(I)     <= DUMP_DDUC_DVLD_IN(I); 
                                dump_dsp_data_mux(I)     <= DUMP_DDUC_DATA_IN(I); 
                            when x"8" =>
                                dump_dsp_bfn_strb_mux(I) <= DUMP_DPD_BFN_STRB_IN(I);           
                                dump_dsp_dvld_mux(I)     <= DUMP_DPD_DVLD_IN(I); 
                                dump_dsp_data_mux(I)     <= DUMP_DPD_DATA_IN(I); 
                            when x"9" =>
                                dump_dsp_bfn_strb_mux(I) <= DUMP_DPD_BFN_STRB_IN(I);           
                                dump_dsp_dvld_mux(I)     <= DUMP_DPD_DVLD_IN(I); 
                                dump_dsp_data_mux(I)     <= DUMP_DPD_DATA_IN(I); 
                            when x"A" =>
                                dump_dsp_bfn_strb_mux(I) <= DUMP_DPD_BFN_STRB_IN(I);           
                                dump_dsp_dvld_mux(I)     <= DUMP_DPD_DVLD_IN(I); 
                                dump_dsp_data_mux(I)     <= DUMP_DPD_DATA_IN(I); 
                            when others =>
                                dump_dsp_bfn_strb_mux(I) <= '0';           
                                dump_dsp_dvld_mux(I)     <= '0'; 
                                dump_dsp_data_mux(I)     <= (others => '0'); 
                        end case;
                    end if;
                end process;

            end generate;
        end generate;
    end generate;

    DUMP_DSP_BFN_STRB_OUT <= dump_dsp_bfn_strb_mux;              
    DUMP_DSP_DVLD_OUT     <= dump_dsp_dvld_mux;  
    DUMP_DSP_DATA_OUT     <= dump_dsp_data_mux;  

end arc_DSP_DUMP_MUX;
