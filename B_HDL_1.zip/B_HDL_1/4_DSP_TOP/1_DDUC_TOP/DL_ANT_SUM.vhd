-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- Maximum Carrier Number is restricted by 4
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity DL_ANT_SUM is
    generic (
        DUC_NUM                 : integer -- max 4 DUCs
    );
    port (
        RESET                   : in std_logic;
        CLK                     : in std_logic; -- DUC operation clock

        IDATA_I                 : in std_logic_array16(DUC_NUM-1 downto 0);
        IDATA_Q                 : in std_logic_array16(DUC_NUM-1 downto 0);

        ODATA_I                 : out std_logic_vector(15 downto 0);
        ODATA_Q                 : out std_logic_vector(15 downto 0)
        );
end DL_ANT_SUM;

architecture arc_DL_ANT_SUM of DL_ANT_SUM is


    signal in_data_i                : std_logic_array16(23 downto 0);
    signal in_data_q                : std_logic_array16(23 downto 0);

    signal sum_I_1                  : std_logic_vector(16 downto 0);
    signal sum_Q_1                  : std_logic_vector(16 downto 0);
    signal sum_I_2                  : std_logic_vector(16 downto 0);
    signal sum_Q_2                  : std_logic_vector(16 downto 0);
    signal sum_I_3                  : std_logic_vector(16 downto 0);
    signal sum_Q_3                  : std_logic_vector(16 downto 0);
    signal sum_I_4                  : std_logic_vector(16 downto 0);
    signal sum_Q_4                  : std_logic_vector(16 downto 0);
    signal sum_I_5                  : std_logic_vector(16 downto 0);
    signal sum_Q_5                  : std_logic_vector(16 downto 0);
    signal sum_I_6                  : std_logic_vector(16 downto 0);
    signal sum_Q_6                  : std_logic_vector(16 downto 0);
    signal sum_I_12                 : std_logic_vector(17 downto 0);
    signal sum_Q_12                 : std_logic_vector(17 downto 0);
    signal sum_I_34                 : std_logic_vector(17 downto 0);
    signal sum_Q_34                 : std_logic_vector(17 downto 0);
    signal sum_I_56                 : std_logic_vector(17 downto 0);
    signal sum_Q_56                 : std_logic_vector(17 downto 0);
    signal sum_I_1234               : std_logic_vector(18 downto 0);
    signal sum_Q_1234               : std_logic_vector(18 downto 0);
    signal sum_I_56xx               : std_logic_vector(18 downto 0);
    signal sum_Q_56xx               : std_logic_vector(18 downto 0);
    signal tot_sum_I                : std_logic_vector(19 downto 0);
    signal tot_sum_Q                : std_logic_vector(19 downto 0);


begin


g_VALID : for i in DUC_NUM-1 downto 0 generate
    in_data_i(i) <= IDATA_I(i);
    in_data_q(i) <= IDATA_Q(i);
end generate;

g_INVALID : for i in 23 downto DUC_NUM generate
    in_data_i(i) <= (others=>'0');
    in_data_q(i) <= (others=>'0');
end generate;

    process(RESET,CLK)
    begin
       if RESET = '1' then
          sum_I_1 <= (others => '0');
          sum_Q_1 <= (others => '0');
          sum_I_2 <= (others => '0');
          sum_Q_2 <= (others => '0');
          sum_I_3 <= (others => '0');
          sum_Q_3 <= (others => '0');
          sum_I_4 <= (others => '0');
          sum_Q_4 <= (others => '0');
          sum_I_5 <= (others => '0');
          sum_Q_5 <= (others => '0');
          sum_I_6 <= (others => '0');
          sum_Q_6 <= (others => '0');
       elsif (CLK'event and CLK = '1') then
          sum_I_1 <= (in_data_i(0)(15)  & in_data_i(0))  + (in_data_i(1)(15)  & in_data_i(1));
          sum_Q_1 <= (in_data_q(0)(15)  & in_data_q(0))  + (in_data_q(1)(15)  & in_data_q(1));
          sum_I_2 <= (in_data_i(2)(15)  & in_data_i(2))  + (in_data_i(3)(15)  & in_data_i(3));
          sum_Q_2 <= (in_data_q(2)(15)  & in_data_q(2))  + (in_data_q(3)(15)  & in_data_q(3));
          sum_I_3 <= (in_data_i(4)(15)  & in_data_i(4))  + (in_data_i(5)(15)  & in_data_i(5));
          sum_Q_3 <= (in_data_q(4)(15)  & in_data_q(4))  + (in_data_q(5)(15)  & in_data_q(5));
          sum_I_4 <= (in_data_i(6)(15)  & in_data_i(6))  + (in_data_i(7)(15)  & in_data_i(7));
          sum_Q_4 <= (in_data_q(6)(15)  & in_data_q(6))  + (in_data_q(7)(15)  & in_data_q(7));
          sum_I_5 <= (in_data_i(8)(15)  & in_data_i(8))  + (in_data_i(9)(15)  & in_data_i(9));
          sum_Q_5 <= (in_data_q(8)(15)  & in_data_q(8))  + (in_data_q(9)(15)  & in_data_q(9));
          sum_I_6 <= (in_data_i(10)(15) & in_data_i(10)) + (in_data_i(11)(15) & in_data_i(11));
          sum_Q_6 <= (in_data_q(10)(15) & in_data_q(10)) + (in_data_q(11)(15) & in_data_q(11));
       end if;
    end process;

    process(RESET,CLK)
    begin
       if RESET = '1' then
          sum_I_12 <= (others => '0');
          sum_Q_12 <= (others => '0');
          sum_I_34 <= (others => '0');
          sum_Q_34 <= (others => '0');
          sum_I_56 <= (others => '0');
          sum_Q_56 <= (others => '0');
       elsif (CLK'event and CLK = '1') then
          sum_I_12 <= (sum_I_1(16) & sum_I_1) + (sum_I_2(16) & sum_I_2);
          sum_Q_12 <= (sum_Q_1(16) & sum_Q_1) + (sum_Q_2(16) & sum_Q_2);
          sum_I_34 <= (sum_I_3(16) & sum_I_3) + (sum_I_4(16) & sum_I_4);
          sum_Q_34 <= (sum_Q_3(16) & sum_Q_3) + (sum_Q_4(16) & sum_Q_4);
          sum_I_56 <= (sum_I_5(16) & sum_I_5) + (sum_I_6(16) & sum_I_6);
          sum_Q_56 <= (sum_Q_5(16) & sum_Q_5) + (sum_Q_6(16) & sum_Q_6);
       end if;
    end process;

    process(RESET,CLK)
    begin
       if RESET = '1' then
          sum_I_1234 <= (others => '0');
          sum_Q_1234 <= (others => '0');
          sum_I_56xx <= (others => '0');
          sum_Q_56xx <= (others => '0');
       elsif (CLK'event and CLK = '1') then
          sum_I_1234 <= (sum_I_12(17) & sum_I_12) + (sum_I_34(17) & sum_I_34);
          sum_Q_1234 <= (sum_Q_12(17) & sum_Q_12) + (sum_Q_34(17) & sum_Q_34);
          sum_I_56xx <= (sum_I_56(17) & sum_I_56);
          sum_Q_56xx <= (sum_Q_56(17) & sum_Q_56);
       end if;
    end process;

    process(RESET,CLK)
    begin
       if RESET = '1' then
          tot_sum_I <= (others => '0');
          tot_sum_Q <= (others => '0');
       elsif (CLK'event and CLK = '1') then
          tot_sum_I <= (sum_I_1234(18) & sum_I_1234) + (sum_I_56xx(18) & sum_I_56xx);
          tot_sum_Q <= (sum_Q_1234(18) & sum_Q_1234) + (sum_Q_56xx(18) & sum_Q_56xx);
       end if;
    end process;

    ODATA_I <= tot_sum_I(15 downto 0);
    ODATA_Q <= tot_sum_Q(15 downto 0);

    --u_sum_sat_I : SAT
    --   generic map(
    --      i_bit => 18,  --: integer;
    --      o_bit => 16   --: integer
    --   )
    --   port map(
    --      RESET => RESET,      --: in  std_logic;
    --      CLK   => CLK,        --: in  std_logic;
    --      IND   => tot_sum_I,  --: in  std_logic_vector(i_bit-1 downto 0);
    --      RES   => ODATA_I     --: out std_logic_vector(o_bit-1 downto 0)
    --   );
    --
    --u_sum_sat_Q : SAT
    --   generic map(
    --      i_bit => 18,  --: integer;
    --      o_bit => 16   --: integer
    --   )
    --   port map(
    --      RESET => RESET,      --: in  std_logic;
    --      CLK   => CLK,        --: in  std_logic;
    --      IND   => tot_sum_Q,  --: in  std_logic_vector(i_bit-1 downto 0);
    --      RES   => ODATA_Q     --: out std_logic_vector(o_bit-1 downto 0)
    --   );

end arc_DL_ANT_SUM;
