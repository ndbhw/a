------------------------------------------------------------------
-- channel swap
------------------------------------------------------------------
-- 2013.11.01, vyacheslav : 1st release, system verilog
-- 2014.01.29, wj311.kim  : convert system_verilog to vhdl
------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity channel_swap_hbf_d is
generic(
    CHANNEL_NUMBERS             : natural:= 4;
    HOVS                        : natural:= 2;
    WIDTH_IN                    : natural:= 16
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);        -- 2 continuous data per each channel, x1 rate

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)         -- 1 data per each channel, x2 rate
);
end channel_swap_hbf_d;

architecture Behavioral of channel_swap_hbf_d is

component dduc_dist_ram
generic(
    BUFF_DEPTH                  : natural:= 16;
    WIDTH_IN                    : natural:= 16
);
port(
    CLK                         : in  std_logic;
    WE                          : in  std_logic;
    WADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    RADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_IN                     : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_OUT                    : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

constant BUFFER_DEPTH           : integer := CHANNEL_NUMBERS*2*2;-- *2 for even/odd sample, *2 for buffering
constant SAMPLE_CLK_CNT         : integer := 2*HOVS*CHANNEL_NUMBERS;
constant CLK_CNT_WIDTH          : integer := log2(2*CHANNEL_NUMBERS*HOVS);
constant RAM_DELAY              : integer := 2;
constant PROC_DELAY             : integer := RAM_DELAY+3;-- processing delay = 5 clock + 2 sample period

type addr_array                 is array(natural range <>) of std_logic_vector(log2(BUFFER_DEPTH)-1 downto 0);

signal frame_in_d               : std_logic_vector(PROC_DELAY-1 downto 0);
signal valid_in_d               : std_logic;
signal filter_in_d              : std_logic_vector(WIDTH_IN-1 downto 0);
signal waddr                    : std_logic_vector(log2(BUFFER_DEPTH)-1 downto 0);
signal raddr                    : addr_array(1 downto 0);
signal raddr_mux                : std_logic_vector(log2(BUFFER_DEPTH)-1 downto 0);
signal sample_mux_cnt           : std_logic_vector(log2(SAMPLE_CLK_CNT)-1 downto 0);
signal valid_out_r              : std_logic;
signal valid_out_d              : std_logic_vector(RAM_DELAY-1 downto 0);

begin

    -- input registering
    FRAME_O <= frame_in_d(frame_in_d'high);
    process(RST, CLK)
    begin
        if RST = '1' then
            frame_in_d  <= (others => '0');
            valid_in_d  <= '0';
            filter_in_d <= (others => '0');
        elsif rising_edge(CLK) then
            frame_in_d  <= frame_in_d(frame_in_d'length-2 downto 0) & FRAME_I;
            valid_in_d  <= VALID_I;
            filter_in_d <= FILTER_IN;
        end if;
    end process;

    -- write address
    process(RST, CLK)
    begin
        if RST = '1' then
            waddr <= (others => '0');
        elsif rising_edge(CLK) then
            if FRAME_I = '1' then
                waddr <= (others => '0');
            elsif VALID_I = '1' then
                waddr <= waddr + 1;
            end if;
        end if;
    end process;

    -- sample clock counter for output
    process(RST, CLK)
    begin
        if RST = '1' then
            sample_mux_cnt <= (others => '0');
        elsif rising_edge(CLK) then
            if frame_in_d(0) = '1' then-- resync
                sample_mux_cnt <= (others => '0');
            else
                sample_mux_cnt <= sample_mux_cnt + 1;
            end if;
        end if;
    end process;

    -- write address
    RADDR_GEN : for N in 0 to 1 generate -- raddr (0) : 0, 2, 4th sample, raddr(1) : 1, 3, 5th sample
    process(RST, CLK)
    begin
        if RST = '1' then
            raddr(N) <= (others => '0');
        elsif rising_edge(CLK) then
            if sample_mux_cnt = SAMPLE_CLK_CNT-1 then-- resync
                raddr(N) <= waddr - CHANNEL_NUMBERS*(2-N);
            elsif sample_mux_cnt(log2(2*HOVS)-1 downto 0) =  (2*HOVS-1) then
                raddr(N) <= raddr(N) + 1;
            end if;
        end if;
    end process;
    end generate RADDR_GEN;

    -- read address mux
    process(RST, CLK)
    begin
        if RST = '1' then
            raddr_mux <= (others => '0');
        elsif rising_edge(CLK) then
            if sample_mux_cnt(0) = '0' then
                raddr_mux <= raddr(0);
            else
                raddr_mux <= raddr(1);
            end if;
        end if;
    end process;

    VALID_O <= valid_out_d(valid_out_d'high);
    process(RST, CLK)
    begin
        if RST = '1' then
            valid_out_r <= '0';
            valid_out_d <= (others => '0');
        elsif rising_edge(CLK) then
            if sample_mux_cnt(log2(2*HOVS)-1 downto 0) = 0 then
                valid_out_r <= '1';
            else
                valid_out_r <= '0';
            end if;
            valid_out_d <= valid_out_d(valid_out_d'length-2) & valid_out_r;
        end if;
    end process;

u_dduc_dist_ram : dduc_dist_ram
generic map(
    BUFF_DEPTH                  => BUFFER_DEPTH                 ,--: natural:= 16;
    WIDTH_IN                    => WIDTH_IN                      --: natural:= 16
)
port map(
    CLK                         => CLK                          ,--: in  std_logic;
    WE                          => valid_in_d                   ,--: in  std_logic;
    WADDR                       => waddr                        ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    RADDR                       => raddr_mux                    ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_IN                     => filter_in_d                  ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_OUT                    => FILTER_OUT                    --: out std_logic_vector(WIDTH_IN-1 downto 0)
);

end Behavioral;
