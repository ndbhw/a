------------------------------------------------------------------
-- channel swap
------------------------------------------------------------------
-- 2013.11.01, vyacheslav : 1st release, system verilog
-- 2014.01.29, wj311.kim  : convert system_verilog to vhdl
------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

Library UNISIM;
use UNISIM.vcomponents.all;
library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity dduc_sdpram is
generic(
    BUFF_DEPTH                  : integer := 16;
    WIDTH_IN                    : integer := 16
);
port(
    CLK_W                       : in  std_logic;
    CLK_R                       : in  std_logic;
    WE                          : in  std_logic;
    ADDR_W                      : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    ADDR_R                      : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_W                      : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_R                      : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end dduc_sdpram;

architecture Behavioral of dduc_sdpram is

constant RAM_DEPTH              : integer := 2**log2(BUFF_DEPTH);
type ram_type                   is array (RAM_DEPTH-1 downto 0) of std_logic_vector(WIDTH_IN-1 downto 0);
signal RAM                      : ram_type := (others => (others => '0'));
signal ram_out                  : std_logic_vector(WIDTH_IN-1 downto 0);

attribute RAM_STYLE             : string;
attribute RAM_STYLE of RAM      : signal is ternary_func(BUFF_DEPTH<=32,"DISTRIBUTED","BLOCK");
--attribute RAM_STYLE of RAM      : signal is "BLOCK";

begin

    process (CLK_W)
    begin
    if rising_edge(CLK_W) then
        if WE = '1' then
            RAM(conv_integer(ADDR_W)) <= DATA_W;
        end if;
    end if;
    end process;

    process (CLK_R)
    begin
    if rising_edge(CLK_R) then
        ram_out <= RAM(conv_integer(ADDR_R));
    end if;
    end process;

    process (CLK_R)
    begin
    if rising_edge(CLK_R) then
        DATA_R <= ram_out;-- for high performance, in BRAM primitive (no fabric)
    end if;
    end process;

end Behavioral;
