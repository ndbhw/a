------------------------------------------------------------------
-- Digital IF Power Measure (For RX ADC Output Power Measure
------------------------------------------------------------------
-- 2014.06.10, wj311.kim  : 1st release
------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity dduc_sync_delay is
generic(
    DATA_WIDTH                  : integer:= 2;
    DELAY                       : integer:= 128
);
port(
    CLK                         : in  std_logic;
    BYPASS                      : in  std_logic;
    DATA_IN                     : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    DATA_OUT                    : out std_logic_vector(DATA_WIDTH-1 downto 0)
);
end dduc_sync_delay;

architecture Behavioral of dduc_sync_delay is

     component dduc_delay_chain is
     generic(
         BUFF_DEPTH                  : natural:= 64;-- SRL16E
         DIRECTION                   : natural:= 0; -- 1:forward, 0:reverse, 0 for general delay block
         WIDTH_IN                    : natural:= 16 -- Input data width
     );
     port(
         CLK                         : in  std_logic;
         DATA_SEL                    : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
         VALID_I                     : in  std_logic;
         FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
         FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
     );
     end component;

     component dduc_bram is
     generic(
         BUFF_DEPTH                  : integer := 1024;
         WIDTH_IN                    : integer := 16
     );
     port(
         CLK                         : in  std_logic;
         WE                          : in  std_logic;
         WADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
         RADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
         DATA_IN                     : in  std_logic_vector(WIDTH_IN-1 downto 0);
         DATA_OUT                    : out std_logic_vector(WIDTH_IN-1 downto 0)
     );
     end component;

     constant BRAM_DEPTH             : integer := 2**log2(DELAY);
     constant BRAM_PROC_DELAY        : integer := 4;-- 2 clock for BRAM read processing delay + 1 clock output selection register + 1 clock write/read address min diff
     constant DELAY_SRL              : integer := DELAY;-- 1 clock output selection register
     constant DELAY_BRAM             : integer := ternary_func(DELAY=BRAM_DEPTH-1, BRAM_DEPTH-2-BRAM_PROC_DELAY, DELAY-BRAM_PROC_DELAY);

     signal dly_out                  : std_logic_vector(DATA_WIDTH-1 downto 0);

     signal waddr                    : std_logic_vector(log2(BRAM_DEPTH)-1 downto 0):=(others=>'0');
     signal raddr_sync               : std_logic:='0';
     signal raddr                    : std_logic_vector(log2(BRAM_DEPTH)-1 downto 0):=(others=>'0');

begin

    -- Output register
    process(CLK)
    begin
        if rising_edge(CLK) then
            if BYPASS = '1' then
                DATA_OUT <= DATA_IN;
            else
                DATA_OUT <= dly_out;
            end if;
        end if;
    end process;

    DELAY_GEN_SRL : if BRAM_DEPTH <= 256 generate
        u_dduc_delay_chain : dduc_delay_chain
        generic map(
            BUFF_DEPTH                  => BRAM_DEPTH                   ,--: natural:= 64;-- SRL16E
            DIRECTION                   => 0                            ,--: natural:= 0; -- 1:forward, 0:reverse, 0 for general delay block
            WIDTH_IN                    => DATA_WIDTH                    --: natural:= 16 -- Input data width
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;
            DATA_SEL                    => std_logic_vector(to_unsigned(DELAY_SRL-2, log2(DELAY_SRL))),
            VALID_I                     => '1'                          ,--: in  std_logic;
            FILTER_IN                   => DATA_IN                      ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
            FILTER_OUT                  => dly_out                       --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );
    end generate DELAY_GEN_SRL;

    DELAY_GEN_BRAM : if BRAM_DEPTH > 256 generate
        -- write address
        process(CLK)
        begin
            if rising_edge(CLK) then
                waddr <= waddr + '1';
            end if;
        end process;

        process(CLK)
        begin
            if rising_edge(CLK) then
                if waddr = DELAY_BRAM-1 then
                    raddr_sync <= '1';
                else
                    raddr_sync <= '0';
                end if;
            end if;
        end process;

        -- read address
        process(CLK)
        begin
            if rising_edge(CLK) then
                if raddr_sync = '1' then
                    raddr <= (others => '0');
                else
                    raddr <= raddr + '1';
                end if;
            end if;
        end process;

        u_dduc_bram : dduc_bram
        generic map(
            BUFF_DEPTH                  => BRAM_DEPTH                   ,--: integer := 1024;
            WIDTH_IN                    => DATA_WIDTH                    --: integer := 16
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;
            WE                          => '1'                          ,--: in  std_logic;
            WADDR                       => waddr                        ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
            RADDR                       => raddr                        ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
            DATA_IN                     => DATA_IN                      ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
            DATA_OUT                    => dly_out                       --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );
    end generate DELAY_GEN_BRAM;

end Behavioral;
