-- SOFTBANK 700M RF2239

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;
use work.dduc_pkg.all;

entity DDUC_TOP is
    generic(
        DUPLEX_TYPE                         : string :="TDD";
        VENDOR                              : string :="XILINX";
        PBA_NAME                            : string :="X";
        ADDR_WIDTH                          : natural:=0;
        WDATA_WIDTH                         : natural:=0;
        RDATA_WIDTH                         : natural:=0
    );  
    port(
        --MODULE RST IF
        RST_DDUC                            : in  std_logic;
        --SYSCLK IF
        CLK_SYS                             : in  std_logic;
        CLK_SYSX2                           : in  std_logic;
        CLK_SYSX3                           : in  std_logic;
        CLK_SYSX4                           : in  std_logic;
        CLK_SYSX5                           : in  std_logic;
        CLK_SYSX6                           : in  std_logic;
        CLK_SYSX8                           : in  std_logic;
        CLK_SYSX10                          : in  std_logic;
        CLK_SYSX12                          : in  std_logic;
        CLK_SYSX16                          : in  std_logic;
        CLK_SYSX20                          : in  std_logic;
        INT_SYSPLL_LOCK_IN                  : in  std_logic;
        --MODULE INFO IF
        DDUC_INFO_OUT                       : out std_logic_vector(31 downto 0);
        DDUC_STRUCT_OUT                     : out std_logic_vector(31 downto 0);
        DDUC_DATE_OUT                       : out std_logic_vector(31 downto 0);
        --MODULE DLY IF
        DUC_PROC_DLY_OUT                    : out std_logic_vector(31 downto 0);
        DDC_PROC_DLY_OUT                    : out std_logic_vector(31 downto 0);
        --DLY CTRL IF (path delay)
        DL_CRR_DLY_IN                       : in  std_logic_array12(TX_ANT_NUM-1 downto 0);
        UL_CRR_DLY_IN                       : in  std_logic_array12(RX_ANT_NUM-1 downto 0);
        --ATT CTRL IF
        DL_PATH_ATT_IN                      : in  std_logic_array16(TX_ANT_NUM-1 downto 0);
        --DUC CTRL IF
        DUC_NCO_WEN_IN                      : in  std_logic_vector(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);
        DUC_NCO_DATA_IN                     : in  std_logic_array32(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);
        DUC_GAIN_IN                         : in  std_logic_array16(TX_ANT_NUM*DL_BBIQARY_NUM-1 downto 0);
        DUC2ANT_SEL_IN                      : in  std_logic_vector((TX_ANT_NUM*DL_BBIQARY_NUM)/2*2*TX_ANT_NUM-1 downto 0);
        DUC2ANT_SUM_MODE_IN                 : in  std_logic_vector((TX_ANT_NUM*DL_BBIQARY_NUM)/2-1 downto 0);
        --DDC CTRL IF
        DDC_NCO_WEN_IN                      : in  std_logic_vector(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);
        DDC_NCO_DATA_IN                     : in  std_logic_array32(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);
        DDC_GAIN_IN                         : in  std_logic_array16(RX_ANT_NUM*UL_BBIQARY_NUM-1 downto 0);
        UL_ANT_SEL_IN                       : in  std_logic_array8((RX_ANT_NUM*UL_BBIQARY_NUM)/2-1 downto 0);
        --UL CTRL IF
        UL_ADC_PWR_OUT                      : out std_logic_array32(RX_ANT_NUM-1 downto 0);
        --BBCTRL 2 DSP IF
        DL_SSB_STRB_IN                      : in  std_logic;
        DL_BFN_STRB_IN                      : in  std_logic;
        DL_TDD_IN                           : in  std_logic;
        DL_CHBW_IN                          : in  std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
        DL_SYNC_IN                          : in  std_logic_vector(DL_BBIQARY_NUM-1 downto 0);
        DL_IQ_IN                            : in  std_logic_array16(DL_BBIQARY_NUM-1 downto 0);
        BCF_ENB_IN                          : in  std_logic;
        --DSP 2 BBCTRL IF
        UL_BFN_STRB_OUT                     : out std_logic;
        UL_TDD_OUT                          : out std_logic;
        UL_CHBW_IN                          : in  std_logic_array4(UL_BBIQARY_NUM-1 downto 0);
        UL_SYNC_OUT                         : out std_logic_vector(UL_BBIQARY_NUM-1 downto 0);
        UL_IQ_OUT                           : out std_logic_array16(UL_BBIQARY_NUM-1 downto 0);
        --DL IQ OUT IF
        DL_SSB_STRB_OUT                     : out std_logic;
        DL_BFN_STRB_OUT                     : out std_logic;
        DL_TDD_OUT                          : out std_logic;
        DL_SYNC_OUT                         : out std_logic_vector(TX_ANT_NUM-1 downto 0);
        DL_I_OUT                            : out std_logic_array16(TX_ANT_NUM-1 downto 0);
        DL_Q_OUT                            : out std_logic_array16(TX_ANT_NUM-1 downto 0);
        BCF_ENB_OUT                         : out std_logic;
        --UL IQ IN IF
        UL_BFN_STRB_IN                      : in  std_logic;
        UL_TDD_IN                           : in  std_logic;
        UL_SYNC_IN                          : in  std_logic_vector(RX_ANT_NUM-1 downto 0);
        UL_I_IN                             : in  std_logic_array16(RX_ANT_NUM-1 downto 0);
        UL_Q_IN                             : in  std_logic_array16(RX_ANT_NUM-1 downto 0);
        --MISC IF
        DL_CLK_ISZERO_OUT                   : out std_logic_vector(TX_ANT_NUM-1 downto 0);
        DL_IQ_ISZERO_OUT                    : out std_logic_vector(TX_ANT_NUM-1 downto 0);
        SIG_SUS_FLAG_OUT                    : out std_logic_vector(TX_ANT_NUM-1 downto 0);
        SIG_SUS_DLOFF_IN                    : in  std_logic_vector(TX_ANT_NUM-1 downto 0);
        --DUMP IF
        DUMP_POINT_SEL_STRB_IN              : in  std_logic;
        DUMP_POINT_SEL_IN                   : in  std_logic_vector(8-1 downto 0);
        DUMP_BFN_STRB_OUT                   : out std_logic_vector(2-1 downto 0);
        DUMP_DVLD_OUT                       : out std_logic_vector(2-1 downto 0);
        DUMP_DATA_OUT                       : out std_logic_array32(2-1 downto 0)
    );
end DDUC_TOP;

architecture Behavioral of DDUC_TOP is

    component RST_SYNC is
        generic (
            DLY_NUM                     : natural := 4;    -- Number of delay.
            MAX_FANOUT_NUM              : integer := 200   -- Number of maximum fanout
        );
        port (
            RST_IN                      : in  std_logic;   -- Active high asynchronous reset
            CLK                         : in  std_logic;   -- clock to be sync'ed to
            RST_OUT                     : out std_logic    -- "Synchronised" reset signal
        );
    end component;

    component dduc_sync_delay is
        generic(
            DATA_WIDTH                  : integer:= 2;
            DELAY                       : integer:= 128
        );
        port(
            CLK                         : in  std_logic;
            BYPASS                      : in  std_logic;
            DATA_IN                     : in  std_logic_vector(DATA_WIDTH-1 downto 0);
            DATA_OUT                    : out std_logic_vector(DATA_WIDTH-1 downto 0)
        );
    end component;

    component BBIQARY_TO_DXC is
        generic(
            DL_BBIQARY_NUM              : natural:=2;
            UL_BBIQARY_NUM              : natural:=2;
            DUC_NUM                     : natural:=2;
            DDC_NUM                     : natural:=2
        );
        port(
            RST                         : in  std_logic;
            CLK                         : in  std_logic;
            --BBCTRL 2 DSP IF
            DL_CHBW_IN                  : in  std_logic_array4 (DL_BBIQARY_NUM-1 downto 0);
            DL_BBSYNC_IN                : in  std_logic_vector (DL_BBIQARY_NUM-1 downto 0);
            DL_BBDATA_IN                : in  std_logic_array16(DL_BBIQARY_NUM-1 downto 0);
            --DUC IF
            DL_CHBW_OUT                 : out std_logic_array4 (DUC_NUM-1 downto 0);
            DL_BBSYNC_OUT               : out std_logic_vector (DUC_NUM-1 downto 0);
            DL_BBDATA_OUT               : out std_logic_array16(DUC_NUM-1 downto 0);
            --DDC IF
            UL_CHBW_OUT                 : out std_logic_array4 (DDC_NUM-1 downto 0);
            UL_BBSYNC_IN                : in  std_logic_vector (DDC_NUM-1 downto 0);
            UL_BBDATA_IN                : in  std_logic_array16(DDC_NUM-1 downto 0);
            --DSP 2 BBCTRL IF
            UL_CHBW_IN                  : in  std_logic_array4 (UL_BBIQARY_NUM-1 downto 0);
            UL_BBSYNC_OUT               : out std_logic_vector (UL_BBIQARY_NUM-1 downto 0);
            UL_BBDATA_OUT               : out std_logic_array16(UL_BBIQARY_NUM-1 downto 0)
        );
    end component;

    component umts_lte_duc
        port(
            CLOCK                       : in  std_logic;
            CLOCK_307                   : in  std_logic;
            DUC_RESET                   : in  std_logic;
            DUC_RESET_307               : in  std_logic;

            MODE                        : in  std_logic_vector(3 downto 0);

            --DUC IF
            DUC_SYNC                    : in  std_logic;
            DUC_IN                      : in  std_logic_vector(15 downto 0);

            --NCOS FOR UMTS/LTE DUC
            DUC_NCO_WREN                : in  std_logic_vector(1 downto 0);
            DUC_NCO0                    : in  std_logic_vector(30 downto 0);
            DUC_NCO1                    : in  std_logic_vector(30 downto 0);

            --GAIN FOR UMTS/LTE
            DUC_GAIN0                   : in  std_logic_vector(15 downto 0);
            DUC_GAIN1                   : in  std_logic_vector(15 downto 0);

            --DUC IF
            S_DUC_OUT                   : out std_logic;
            I_DUC_OUT0                  : out std_logic_vector(15 downto 0);
            Q_DUC_OUT0                  : out std_logic_vector(15 downto 0);
            I_DUC_OUT1                  : out std_logic_vector(15 downto 0);
            Q_DUC_OUT1                  : out std_logic_vector(15 downto 0);
            --PIM IF
            PIM_FRAME_O                 : out std_logic;
            PIM_VALID_O                 : out std_logic;
            PIM_OUT                     : out std_logic_array16(1 downto 0)
        );
    end component;

    component DUC_TO_ANT_SW
        generic(
            ANT_NUM                     : natural := 2
        );
        port(
            RESET                       : in  std_logic;
            CLK                         : in  std_logic; -- DUC operation clock

            IN_DATA_0_I                 : in  std_logic_vector(15 downto 0);
            IN_DATA_0_Q                 : in  std_logic_vector(15 downto 0);
            IN_DATA_1_I                 : in  std_logic_vector(15 downto 0);
            IN_DATA_1_Q                 : in  std_logic_vector(15 downto 0);

            ANT_OUT_CONTROL             : in  std_logic_vector(2*ANT_NUM-1 downto 0);
            DUCOUT_SUM_MODE_ON          : in  std_logic;

            ODATA_I                     : out std_logic_array16(ANT_NUM-1 downto 0);
            ODATA_Q                     : out std_logic_array16(ANT_NUM-1 downto 0)
        );
    end component;

    component DL_ANT_SUM
        generic (
            DUC_NUM                     : integer -- max 4 DUCs
        );
        port (
            RESET                       : in  std_logic;
            CLK                         : in  std_logic; -- DUC operation clock

            IDATA_I                     : in std_logic_array16(DUC_NUM-1 downto 0);
            IDATA_Q                     : in std_logic_array16(DUC_NUM-1 downto 0);

            ODATA_I                     : out std_logic_vector(15 downto 0);
            ODATA_Q                     : out std_logic_vector(15 downto 0)
        );
    end component;

    component dduc_ant_delay is
        generic(
            DATA_WIDTH                  : integer:=  16;
            BUF_DEPTH                   : integer:= 512;
            BUF_RES                     : integer:=   1
        );
        port(
            RST                         : in  std_logic;
            CLK                         : in  std_logic;
            DELAY                       : in  std_logic_vector(log2(BUF_DEPTH)-1 downto 0);
            I_IN                        : in  std_logic_vector(DATA_WIDTH-1 downto 0);
            Q_IN                        : in  std_logic_vector(DATA_WIDTH-1 downto 0);
            I_OUT                       : out std_logic_vector(DATA_WIDTH-1 downto 0);
            Q_OUT                       : out std_logic_vector(DATA_WIDTH-1 downto 0)
        );
    end component;

    component pwr_meas_switch is
        generic(
            PATH_NUM                    : natural:= 4;
            CLK_DIV                     : natural:= 2; -- CLK_DIV = clock rate/data rate
            ACCUM_NUM_WIDTH             : natural:= 20;-- Number of samples to be averaged = 2^ACCUM_NUM_WIDTH
            DATA_WIDTH                  : natural:= 16 -- Data bits width
        );
        port(
            RESET                       : in  std_logic;
            CLK                         : in  std_logic;

            FRAME_10MS                  : in  std_logic;
            FRAME_TDD                   : in  std_logic;

            DATA_IN_I                   : in  std_logic_array16(PATH_NUM-1 downto 0);
            DATA_IN_Q                   : in  std_logic_array16(PATH_NUM-1 downto 0);

            PWR_OUT                     : out std_logic_array32(PATH_NUM-1 downto 0)
        );
    end component;

    component dduc_atten is
        generic(
            CHANNEL_NUMBERS             : natural:=4;
            DATA_WIDTH                  : natural:=16;
            GAIN_WIDTH                  : natural:=16;
            BINARY_POINT                : natural:=16
        );
        port(
            RST                         : in  std_logic;
            CLK                         : in  std_logic;
            GAIN                        : in  std_logic_array16(CHANNEL_NUMBERS-1 downto 0);--MUST be positive always!!

            FRAME_I                     : in  std_logic;
            VALID_I                     : in  std_logic;
            FILTER_IN                   : in  std_logic_vector(DATA_WIDTH-1 downto 0);

            FRAME_O                     : out std_logic;
            VALID_O                     : out std_logic;
            FILTER_OUT                  : out std_logic_vector(DATA_WIDTH-1 downto 0)
        );
    end component;

    component UL_ANT_DDC_SW
        generic(
            ANT_NUM                     : natural := 4
        );
        port (
            RESET                       : in  std_logic;
            CLK                         : in  std_logic; -- DUC operation clock

            UL_ANT_IN_DATA_I            : in  std_logic_array16(ANT_NUM-1 downto 0);
            UL_ANT_IN_DATA_Q            : in  std_logic_array16(ANT_NUM-1 downto 0);

            -- "00" ant.#0 , "01" ant#1 , "10" ant.#2 , "11" ant#3  max. antenna number 4.     if 6 or 8 => (3*DDC_NUM-1 downto 0)
            UL_ANT_IN_CONTROL           : in  std_logic_vector(7 downto 0);

            ODATA_0_I                   : out std_logic_vector(15 downto 0);
            ODATA_0_Q                   : out std_logic_vector(15 downto 0);
            ODATA_1_I                   : out std_logic_vector(15 downto 0);
            ODATA_1_Q                   : out std_logic_vector(15 downto 0)
        );
    end component;

    component nco_ram_dither is
        generic(
            VENDOR                      : string :="XILINX";
            ACCU_VAL                    : natural:=12288;
            WIDTH                       : natural:=16;
            HOVS                        : natural:=1;
            CHANNEL_NUMBERS             : natural:=1
        );
        port(
            RST                         :in  std_logic;
            CLK                         :in  std_logic;

            FS                          :in  std_logic;         -- fs=1 then restart channel number from 0 to channel_numbers-1

            NCO_WREN                    :in  std_logic_vector(CHANNEL_NUMBERS-1 downto 0);
            FREQ_OFF                    :in  std_logic_vector(CHANNEL_NUMBERS*log2(ACCU_VAL)-1 downto 0);-- offset

            COS_O                       :out std_logic_vector(WIDTH-1 downto 0);
            SIN_O                       :out std_logic_vector(WIDTH-1 downto 0)
        );
    end component;

    component dduc_complex_mult is
        generic(
            VENDOR                      : string    := "XILINX";    -- "XILINX", "ALTERA"

            WIDTH_IN                    : natural   := 16;
            NCO_WIDTH_IN                : natural   := 16;
            WIDTH_OUT                   : natural   := 16;
            BINARY_POINT                : natural   := 15;          -- BINARY_POINT = WIDTH_IN+NCO_WIDTH_IN-WIDTH_OUT-1

            ROUNDING                    : string    := "ROUND_INF"; --"FULL_PRECISION","TRUNCATE","ROUND_INF", "ROUND_EVEN"
            OVERFLOW                    : string    := "SATURATE";  --"WRAP","SATURATE"
            SUM_EN                      : natural   := 0;           -- 1 : I+I, Q+Q for DUC output summation mode, 0 : bypass
            HOVS                        : natural   := 1
        );
        port(
            RST                         : in  std_logic;
            CLK                         : in  std_logic;

            SINE_CONJUGATE              : in  std_logic;

            FRAME_I                     : in  std_logic;
            VALID_I                     : in  std_logic;

            DATA_IN_I                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
            DATA_IN_Q                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
            DATA_IN_COS                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);
            DATA_IN_SIN                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);

            FRAME_O                     : out std_logic;
            VALID_O                     : out std_logic;
            DATA_OUT_I                  : out std_logic_vector(WIDTH_OUT-1 downto 0);
            DATA_OUT_Q                  : out std_logic_vector(WIDTH_OUT-1 downto 0)
        );
    end component;

    component umts_lte_ddc
        generic (
            DDC_IN_HOVS                 : integer
        );
        port(
            CLOCK                       : in std_logic;
            CLOCK_307                   : in std_logic;
            DDC_RESET                   : in std_logic;
            DDC_RESET_307               : in std_logic;

            MODE                        : in  std_logic_vector(3 downto 0);

            --DDC IF
            SYNC_10MS                   : in  std_logic;
            I_DDC_IN0                   : in  std_logic_vector(15 downto 0);
            Q_DDC_IN0                   : in  std_logic_vector(15 downto 0);
            I_DDC_IN1                   : in  std_logic_vector(15 downto 0);
            Q_DDC_IN1                   : in  std_logic_vector(15 downto 0);

            --NCOS FOR UMTS/LTE DDC
            DDC_NCO_WREN                : in  std_logic_vector(1 downto 0);
            DDC_NCO0                    : in  std_logic_vector(30 downto 0);
            DDC_NCO1                    : in  std_logic_vector(30 downto 0);

            --DDC GAIN
            DDC_GAIN0                   : in  std_logic_vector(15 downto 0);
            DDC_GAIN1                   : in  std_logic_vector(15 downto 0);

            DDC_SYNC                    : out std_logic;
            DDC_OUT                     : out std_logic_vector(15 downto 0)
        );
    end component;

    constant DUC_NUM                    : natural := DL_BBIQARY_NUM;  -- 2ANT
    constant DDC_NUM                    : natural := UL_BBIQARY_NUM;  -- 2ANT

    constant DUC_DELAY_122p88M          : integer := 12+(579+16*DUC_ORDER_PFIR+129)+11+148;         -- 2011 clk @ 245.76MHz
    constant DUC_DELAY_061p44M          : integer := 12+(555+16*DUC_ORDER_PFIR)+5;              -- ternary_func(DUC_NUM=2*DL_BBIQARY_NUM,5,0);

    constant DDC_DELAY_245p76M          : integer := 1+(570+224+16*DDC_ORDER_PFIR)+0+48+13;     -- ternary_func(DDC_NUM=2*UL_BBIQARY_NUM,1,0);
    constant DDC_DELAY_122p88M          : integer := 1+(570+16*DDC_ORDER_PFIR)+147;             -- 1870 clk @ 245.76MHz
    constant DDC_DELAY_061p44M          : integer := 1+(545+16*DDC_ORDER_PFIR)+1;    -- ternary_func(DDC_NUM=2*UL_BBIQARY_NUM,1,0);
    constant DDC_DELAY_030p72M          : integer := 1+(486+16*DDC_ORDER_PFIR)+1;    -- ternary_func(DDC_NUM=2*UL_BBIQARY_NUM,1,0);

    constant RES_TX_DELAY_X8            : integer := 22;-- 0.4xTap + 6(245.76MHz)
    constant RES_TX_DELAY_X10           : integer := 18;-- 18(307.2MHz)
    constant RES_RX_DELAY_X10           : integer := 35;-- 8+1+0.4xTap+9+1(307.2MHz)
    constant RES_RX_DELAY_X8            : integer := 16;-- 16(245.76MHz)

    constant DUC_DELAY                  : integer := ternary_func(DUC_HB_N_OUT=1, DUC_DELAY_122p88M, DUC_DELAY_061p44M);
    constant DDC_DELAY                  : integer := ternary_func(DDC_IN_HOVS=1, DDC_DELAY_245p76M, ternary_func(DDC_IN_HOVS =2, DDC_DELAY_122p88M, ternary_func(DDC_IN_HOVS=4, DDC_DELAY_061p44M, DDC_DELAY_030p72M)));
    constant DDC_SA_NBIOT_DLY           : integer := 14023;
    constant RES_TX_DELAY               : integer := RES_TX_DELAY_X8       + RES_TX_DELAY_X10*8/10;
    constant RES_RX_DELAY               : integer := RES_RX_DELAY_X10*8/10 + RES_RX_DELAY_X8;

    signal dl_duc_sync_delay            : std_logic_vector(3 downto 0);
    signal dl_duc_sync_delay_1d         : std_logic_vector(3 downto 0);
    signal dl_duc_sync_delay_2d         : std_logic_vector(3 downto 0);
    signal dl_duc_sync_delay0_sh        : std_logic;
    signal dl_bfn_strobe                : std_logic;

    signal i_clk_unstable               : std_logic;
    signal clk_dump1                    : std_logic;
    signal rst_dsp_245                  : std_logic;
    signal rst_dsp_307                  : std_logic;
    signal rst_txant_307                : std_logic_vector(TX_ANT_NUM-1 downto 0):=(others=>'1');
    signal rst_rxant_307                : std_logic_vector(RX_ANT_NUM-1 downto 0):=(others=>'1');    
    signal rst_dduc_all                 : std_logic;
    signal rst_dump1                    : std_logic;
    signal i_rst_duc                    : std_logic_vector(DUC_NUM-1 downto 0);
    signal i_rst_duc_307                : std_logic_vector(DUC_NUM-1 downto 0);
    signal i_rst_ddc                    : std_logic_vector(DDC_NUM-1 downto 0);
    signal i_rst_ddc_307                : std_logic_vector(DDC_NUM-1 downto 0);

    signal i_duc_bw                     : std_logic_array4(DUC_NUM-1 downto 0);
    signal i_ddc_bw                     : std_logic_array4(DDC_NUM-1 downto 0);
    signal i_duc_sync_in                : std_logic_vector(DUC_NUM-1 downto 0);
    signal i_duc_data_in                : std_logic_array16(DUC_NUM-1 downto 0);    

    type   duc_ant_sw_out_ary       is array(natural range <>) of std_logic_array16(TX_ANT_NUM-1 downto 0);
    type   ant_duc_sw_out_ary       is array(natural range <>) of std_logic_array16(DUC_NUM-1 downto 0);

    signal i_duc_ant_sw_out_I           : duc_ant_sw_out_ary(DUC_NUM-1 downto 0)    := (others => (others => x"0000"));
    signal i_duc_ant_sw_out_Q           : duc_ant_sw_out_ary(DUC_NUM-1 downto 0)    := (others => (others => x"0000"));
    signal i_ant_duc_sw_out_I           : ant_duc_sw_out_ary(TX_ANT_NUM-1 downto 0) := (others => (others => x"0000"));
    signal i_ant_duc_sw_out_Q           : ant_duc_sw_out_ary(TX_ANT_NUM-1 downto 0) := (others => (others => x"0000"));

    signal i_ant_sum_I                  : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal i_ant_sum_Q                  : std_logic_array16(TX_ANT_NUM-1 downto 0);
    
    signal i_duc_x8_out_i               : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal i_duc_x8_out_q               : std_logic_array16(TX_ANT_NUM-1 downto 0);

    signal i_ant_dly_i                  : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal i_ant_dly_q                  : std_logic_array16(TX_ANT_NUM-1 downto 0);
    
    signal i_hbf_comm_in_I              : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal i_hbf_comm_in_Q              : std_logic_array16(TX_ANT_NUM-1 downto 0);

    signal i_dl_path_att_i              : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal i_dl_path_att_q              : std_logic_array16(TX_ANT_NUM-1 downto 0);
    
    signal i_dl_path_att_i_1d           : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal i_dl_path_att_q_1d           : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal i_dl_path_att_i_2d           : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal i_dl_path_att_q_2d           : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal i_dl_path_att_i_3d           : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal i_dl_path_att_q_3d           : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal i_dl_path_att_i_4d           : std_logic_array16(TX_ANT_NUM-1 downto 0);
    signal i_dl_path_att_q_4d           : std_logic_array16(TX_ANT_NUM-1 downto 0);
    
    signal i_duc_out_s                  : std_logic_vector(DUC_NUM-1 downto 0);
    signal i_duc_out_s_sh               : std_logic;
    signal i_duc_out_0_I                : std_logic_array16(DUC_NUM-1 downto 0):= (others=>x"0000");
    signal i_duc_out_0_Q                : std_logic_array16(DUC_NUM-1 downto 0):= (others=>x"0000");
    signal i_duc_out_1_I                : std_logic_array16(DUC_NUM-1 downto 0):= (others=>x"0000");
    signal i_duc_out_1_Q                : std_logic_array16(DUC_NUM-1 downto 0):= (others=>x"0000");
    constant DUMP_DUC_NUM               : natural := 2;
    signal dump_duc_out_0_I             : std_logic_array16(DUMP_DUC_NUM-1 downto 0);
    signal dump_duc_out_0_Q             : std_logic_array16(DUMP_DUC_NUM-1 downto 0);
    signal dump_duc_out_1_I             : std_logic_array16(DUMP_DUC_NUM-1 downto 0);
    signal dump_duc_out_1_Q             : std_logic_array16(DUMP_DUC_NUM-1 downto 0);

    signal ul_dly_i                     : std_logic_array16(RX_ANT_NUM-1 downto 0);
    signal ul_dly_q                     : std_logic_array16(RX_ANT_NUM-1 downto 0);

    signal i_ddc0_in_I                  : std_logic_array16(DDC_NUM-1 downto 0) := (others=>x"0000");
    signal i_ddc0_in_Q                  : std_logic_array16(DDC_NUM-1 downto 0) := (others=>x"0000");
    signal i_ddc1_in_I                  : std_logic_array16(DDC_NUM-1 downto 0) := (others=>x"0000");
    signal i_ddc1_in_Q                  : std_logic_array16(DDC_NUM-1 downto 0) := (others=>x"0000");

    signal i_ddc_sync_out               : std_logic_vector(DDC_NUM-1 downto 0):= (others=>'0');
    signal i_ddc_data_out               : std_logic_array16(DDC_NUM-1 downto 0):=(others=>x"0000");
    
    signal s_dl_ant_sum_in_I_A          : std_logic_array16(DDC_NUM-1 downto 0):= (others=>x"0000");
    signal s_dl_ant_sum_in_Q_B          : std_logic_array16(DDC_NUM-1 downto 0):= (others=>x"0000");

    signal dump_point_sel_strb_x10_sh    : std_logic_vector(1 downto 0);
    signal dump_point_sel_x10            : std_logic_vector(7 downto 0);
    signal dump_toggle_x8               : std_logic_vector(1 downto 0);
    
    signal dump_toggle_x10              : std_logic_vector(1 downto 0);

    signal s_ul_sync_out                : std_logic_vector (UL_BBIQARY_NUM-1 downto 0);
    signal s_ul_iq_out                  : std_logic_array16(UL_BBIQARY_NUM-1 downto 0);
    signal s_ul_iq_out_1d               : std_logic_array16(UL_BBIQARY_NUM-1 downto 0);
    signal s_ul_sync_out_1d             : std_logic_vector (UL_BBIQARY_NUM-1 downto 0);
    signal s_ul_sync_out_2d             : std_logic_vector (UL_BBIQARY_NUM-1 downto 0);
    signal s_ul_sync_out_3d             : std_logic_vector (UL_BBIQARY_NUM-1 downto 0);

    signal ul_bfn_strb_in_reg           : std_logic_vector(3-1 downto 0);
    signal ul_bfn_strb_in_d             : std_logic;
    signal ul_bfn_strb_in_dd            : std_logic;
    
    signal ul_tdd_in_reg                : std_logic_vector(3-1 downto 0);
    signal ul_tdd_in_d                  : std_logic;
    signal ul_tdd_in_dd                 : std_logic;

begin

    g_DUMP_DUC : for i in 0 to DUMP_DUC_NUM-1 generate
        g_USED : if i < DUC_NUM generate
            dump_duc_out_0_I(i) <= i_duc_out_0_I(i);
            dump_duc_out_0_Q(i) <= i_duc_out_0_Q(i);
            dump_duc_out_1_I(i) <= i_duc_out_1_I(i);
            dump_duc_out_1_Q(i) <= i_duc_out_1_Q(i);
        end generate;
        g_UNUSED : if i >= DUC_NUM generate
            dump_duc_out_0_I(i) <= (others => '0');
            dump_duc_out_0_Q(i) <= (others => '0');
            dump_duc_out_1_I(i) <= (others => '0');
            dump_duc_out_1_Q(i) <= (others => '0');
        end generate;
    end generate;

    DDUC_INFO_OUT               <= x"41000000";
    DDUC_STRUCT_OUT             <= x"AFEAAF00";    -- [23:20]=atten 0dB 0xf:2^15, 0xe:2^14
    DDUC_DATE_OUT               <= x"20230913";

    DUC_PROC_DLY_OUT            <= x"08" & std_logic_vector(to_unsigned(DUC_DELAY_122p88M, 24)) when RESAMPLER_EN_TX=FALSE and DUC_HB_N_OUT=1 else
                                   x"08" & std_logic_vector(to_unsigned(DUC_DELAY_061p44M, 24)) when RESAMPLER_EN_TX=FALSE and DUC_HB_N_OUT=2 else
                                   x"08" & std_logic_vector(to_unsigned(DUC_DELAY_122p88M+RES_TX_DELAY, 24));
    DDC_PROC_DLY_OUT            <= x"08" & std_logic_vector(to_unsigned(DDC_DELAY_245p76M, 24)) when RESAMPLER_EN_RX=FALSE and DDC_IN_HOVS=1 else
                                   x"08" & std_logic_vector(to_unsigned(DDC_DELAY_122p88M, 24)) when RESAMPLER_EN_RX=FALSE and DDC_IN_HOVS=2 else
                                   x"08" & std_logic_vector(to_unsigned(DDC_DELAY_061p44M, 24)) when RESAMPLER_EN_RX=FALSE and DDC_IN_HOVS=4 else
                                   x"08" & std_logic_vector(to_unsigned(DDC_DELAY_030p72M, 24)) when RESAMPLER_EN_RX=FALSE and DDC_IN_HOVS=8 else
                                   x"08" & std_logic_vector(to_unsigned(DDC_DELAY_122p88M+RES_RX_DELAY, 24));

    i_clk_unstable              <= not INT_SYSPLL_LOCK_IN;

    clk_dump1                   <= CLK_SYSX8;
    rst_dump1                   <= rst_dsp_245;

    u_rst_dsp_245   : RST_SYNC generic map(8,64) port map(i_clk_unstable, CLK_SYSX8, rst_dsp_245);
    u_rst_dsp_307   : RST_SYNC generic map(8,64) port map(i_clk_unstable, CLK_SYSX10, rst_dsp_307);
    u_rst_dduc_all  : RST_SYNC generic map(8,64) port map(RST_DDUC,       CLK_SYSX8, rst_dduc_all);

    u_dl_duc_sync_delay : dduc_sync_delay
        generic map(
            DATA_WIDTH                  => 4                            ,--: integer:= 2;
            DELAY                       => DUC_DELAY-8                   --: integer:= 128
        )
        port map(
            CLK                         => CLK_SYSX8                    ,--: in  std_logic;
            BYPASS                      => '0'                          ,--: in  std_logic;
            DATA_IN(3)                  => DL_SSB_STRB_IN               ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
            DATA_IN(2)                  => BCF_ENB_IN                   ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
            DATA_IN(1)                  => DL_TDD_IN                    ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
            DATA_IN(0)                  => DL_BFN_STRB_IN               ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
            DATA_OUT                    => dl_duc_sync_delay             --: out std_logic_vector(DATA_WIDTH-1 downto 0)
        );
    
    process(CLK_SYSX10)
    begin
        if (rising_edge(CLK_SYSX10)) then
            dl_duc_sync_delay_1d        <=  dl_duc_sync_delay;
            dl_duc_sync_delay_2d        <=  dl_duc_sync_delay_1d;
        end if;
    end process;

    u_dl_res_sync_delay : dduc_sync_delay
        generic map(
            DATA_WIDTH                  => 4                            ,--: integer:= 2;
            DELAY                       => 8                             --: integer:= 128
        )
        port map(
            CLK                         => CLK_SYSX10                   ,--: in  std_logic;
            BYPASS                      => '0'                          ,--: in  std_logic;
            DATA_IN                     => dl_duc_sync_delay_2d         ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
            DATA_OUT(3)                 => DL_SSB_STRB_OUT              ,--: out std_logic_vector(DATA_WIDTH-1 downto 0)
            DATA_OUT(2)                 => BCF_ENB_OUT                  ,--: out std_logic_vector(DATA_WIDTH-1 downto 0)
            DATA_OUT(1)                 => DL_TDD_OUT                   ,--: out std_logic_vector(DATA_WIDTH-1 downto 0)
            DATA_OUT(0)                 => dl_bfn_strobe                 --: out std_logic_vector(DATA_WIDTH-1 downto 0)
        );

    DL_BFN_STRB_OUT                     <= dl_bfn_strobe;

    process(rst_dsp_245, CLK_SYSX8)
    begin
        if (rst_dsp_245 = '1') then
            ul_bfn_strb_in_d                    <= '0';
        elsif (rising_edge(CLK_SYSX8)) then
            ul_bfn_strb_in_reg(0)               <= UL_BFN_STRB_IN;
            ul_bfn_strb_in_reg(2 downto 1)      <= ul_bfn_strb_in_reg(1 downto 0);
            
            if (ul_bfn_strb_in_reg = b"011") then
                ul_bfn_strb_in_d                <= '1';
            elsif (ul_bfn_strb_in_reg = b"100") then
                ul_bfn_strb_in_d                <= '0';
            else
                ul_bfn_strb_in_d                <= ul_bfn_strb_in_d;
            end if;
            ul_bfn_strb_in_dd                   <= ul_bfn_strb_in_d;
        end if;
    end process;

    DUPLEX_TDD : if (DUPLEX_TYPE = "TDD") generate
        process(rst_dsp_245, CLK_SYSX8)
        begin
            if (rst_dsp_245 = '1') then
                ul_tdd_in_d                         <= '0';
            elsif (rising_edge(CLK_SYSX8)) then
                ul_tdd_in_reg(0)                    <= UL_TDD_IN;
                ul_tdd_in_reg(2 downto 1)           <= ul_tdd_in_reg(1 downto 0);
                
                if (ul_tdd_in_reg = b"011") then
                    ul_tdd_in_d                     <= '1';
                elsif (ul_tdd_in_reg = b"100") then
                    ul_tdd_in_d                     <= '0';
                else
                    ul_tdd_in_d                     <= ul_tdd_in_d;
                end if;
                ul_tdd_in_dd                        <= ul_tdd_in_d;
            end if;
        end process;
    end generate;

    DUPLEX_FDD : if (DUPLEX_TYPE = "FDD") generate
        ul_tdd_in_dd                                <=  '1';
    end generate;

    u_ul_res_sync_delay : dduc_sync_delay
        generic map(
            DATA_WIDTH                  => 2                            ,--: integer:= 2;
            DELAY                       => DDC_DELAY-2                   --: integer:= 128
        )
        port map(
            CLK                         => CLK_SYSX8                    ,--: in  std_logic;
            BYPASS                      => '0'                          ,--: in  std_logic;
            DATA_IN(1)                  => ul_tdd_in_dd                 ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
            DATA_IN(0)                  => ul_bfn_strb_in_dd            ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
            DATA_OUT(1)                 => UL_TDD_OUT                   ,--: out std_logic_vector(DATA_WIDTH-1 downto 0)
            DATA_OUT(0)                 => UL_BFN_STRB_OUT               --: out std_logic_vector(DATA_WIDTH-1 downto 0)
        );

    u_BBIQARY_TO_DXC : BBIQARY_TO_DXC
        generic map(
            DL_BBIQARY_NUM              => DL_BBIQARY_NUM               ,--: natural:=2;
            UL_BBIQARY_NUM              => UL_BBIQARY_NUM               ,--: natural:=2;
            DUC_NUM                     => DUC_NUM                      ,--: natural:=4;
            DDC_NUM                     => DDC_NUM                       --: natural:=4
        )
        port map(
            RST                         => rst_dsp_245                  ,--: in  std_logic;
            CLK                         => CLK_SYSX8                    ,--: in  std_logic;
            --BBCTRL 2 DSP IF
            DL_CHBW_IN                  => DL_CHBW_IN                   ,--: in  std_logic_array4 (DL_BBIQARY_NUM-1 downto 0);
            DL_BBSYNC_IN                => DL_SYNC_IN                   ,--: in  std_logic_vector (DL_BBIQARY_NUM-1 downto 0);
            DL_BBDATA_IN                => DL_IQ_IN                     ,--: in  std_logic_array16(DL_BBIQARY_NUM-1 downto 0);
            --DUC IF
            DL_CHBW_OUT                 => i_duc_bw                     ,--: out std_logic_array4 (DUC_NUM-1 downto 0);
            DL_BBSYNC_OUT               => i_duc_sync_in                ,--: out std_logic_vector (DUC_NUM-1 downto 0);
            DL_BBDATA_OUT               => i_duc_data_in                ,--: out std_logic_array16(DUC_NUM-1 downto 0);
            --DSP 2 BBCTRL IF
            UL_CHBW_OUT                 => i_ddc_bw                     ,--: out std_logic_array4 (DDC_NUM-1 downto 0);
            UL_BBSYNC_IN                => i_ddc_sync_out               ,--: in  std_logic_vector (DDC_NUM-1 downto 0);
            UL_BBDATA_IN                => i_ddc_data_out               ,--: in  std_logic_array16(DDC_NUM-1 downto 0);
            --UL IQ IN IF
            UL_CHBW_IN                  => UL_CHBW_IN                   ,--: in  std_logic_array4 (UL_BBIQARY_NUM-1 downto 0);
            UL_BBSYNC_OUT               => s_ul_sync_out                ,--: out std_logic_vector (UL_BBIQARY_NUM-1 downto 0);
            UL_BBDATA_OUT               => s_ul_iq_out                   --: out std_logic_array16(UL_BBIQARY_NUM-1 downto 0)
        );

    UL_SYNC_OUT                         <= s_ul_sync_out;
    UL_IQ_OUT                           <= s_ul_iq_out;

    ------------------------------------------------------------------------
    -- DL ------------------------------------------------------------------
    ------------------------------------------------------------------------

    g_DUC_BLK : for i in DUC_NUM-1 downto 0 generate
        u_rst_duc       : RST_SYNC generic map(8,64) port map(rst_dduc_all, CLK_SYSX8, i_rst_duc(i));
        u_rst_duc_307   : RST_SYNC generic map(8,64) port map(rst_dduc_all, CLK_SYSX10, i_rst_duc_307(i));

        u_duc_nr_lte : umts_lte_duc
            port map(
                clock                       => CLK_SYSX8                            ,--:in std_logic;
                CLOCK_307                   => CLK_SYSX10                           ,--: in  std_logic;
                DUC_RESET                   => i_rst_duc(i)                         ,--:in std_logic;
                DUC_RESET_307               => i_rst_duc_307(i)                     ,--:in std_logic;
            
                mode                        => i_duc_bw(i)                          ,--:in std_logic_vector(3 downto 0);
            
                --duc if
                duc_sync                    => i_duc_sync_in(i)                     ,--:in std_logic;
                duc_in                      => i_duc_data_in(i)                     ,--:in std_logic_vector(15 downto 0);
            
                --NCOs for UMTS/LTE DUC
                duc_nco_wren                => DUC_NCO_WEN_IN(2*i+1 downto 2*i)     ,--:in std_logic;
                DUC_NCO0                    => DUC_NCO_DATA_IN(2*i)(30 downto 0)    ,--:in std_logic_vector(30 downto 0);
                DUC_NCO1                    => DUC_NCO_DATA_IN(2*i+1)(30 downto 0)  ,--:in std_logic_vector(30 downto 0);
            
                --gain for UMTS/LTE
                duc_gain0                   => DUC_GAIN_IN(2*i)                     ,--:in std_logic_vector(15 downto 0);
                duc_gain1                   => DUC_GAIN_IN(2*i+1)                   ,--:in std_logic_vector(15 downto 0);
            
                --duc if
                S_DUC_OUT                   => i_duc_out_s(i)                       ,--: out std_logic;
                I_duc_out0                  => i_duc_out_0_I(i)                     ,--: out std_logic_vector(15 downto 0);
                Q_duc_out0                  => i_duc_out_0_Q(i)                     ,--: out std_logic_vector(15 downto 0);
                I_duc_out1                  => i_duc_out_1_I(i)                     ,--:out std_logic_vector(15 downto 0);
                Q_duc_out1                  => i_duc_out_1_Q(i)                     ,--:out std_logic_vector(15 downto 0);

                --PIM IF
                PIM_FRAME_O                 => open                                 ,--: out std_logic;
                PIM_VALID_O                 => open                                 ,--: out std_logic;
                PIM_OUT                     => open                                  --: out std_logic_array16(1 downto 0)
            );

        u_duc_to_ant_sw : DUC_TO_ANT_SW
            generic map   (
                ANT_NUM                     => TX_ANT_NUM                    --: natural := 2
            )
            port map(
                RESET                       => i_rst_duc_307(i)             ,--: in std_logic;
                CLK                         => CLK_SYSX10                   ,--: in std_logic; -- DUC operation clock

                IN_DATA_0_I                 => i_duc_out_0_I(i)             ,--: in std_logic_vector(15 downto 0);
                IN_DATA_0_Q                 => i_duc_out_0_Q(i)             ,--: in std_logic_vector(15 downto 0);
                IN_DATA_1_I                 => i_duc_out_1_I(i)             ,--: in std_logic_vector(15 downto 0);
                IN_DATA_1_Q                 => i_duc_out_1_Q(i)             ,--: in std_logic_vector(15 downto 0);

                ANT_OUT_CONTROL             => DUC2ANT_SEL_IN(2*TX_ANT_NUM*(i+1)-1 downto 2*TX_ANT_NUM*i),--: in  std_logic_vector(2*TX_ANT_NUM-1 downto 0);
                DUCOUT_SUM_MODE_ON          => DUC2ANT_SUM_MODE_IN(i)       ,--: in std_logic;

                ODATA_I                     => i_duc_ant_sw_out_I(i)        ,--: out duc_ant_sw_out_ary(DUC_NUM-1 downto 0);
                ODATA_Q                     => i_duc_ant_sw_out_Q(i)         --: out duc_ant_sw_out_ary(DUC_NUM-1 downto 0)
            );
    end generate;

    g_REORDER_DUC_NUM : for i in DUC_NUM-1 downto 0 generate
        g_REORDER_ANT_NUM : for j in TX_ANT_NUM-1 downto 0 generate
            i_ant_duc_sw_out_I(j)(i)        <= i_duc_ant_sw_out_I(i)(j);
            i_ant_duc_sw_out_Q(j)(i)        <= i_duc_ant_sw_out_Q(i)(j);
        end generate;
    end generate;

    g_TX_ANT : for i in TX_ANT_NUM-1 downto 0 generate
        u_rst_txant_307   : RST_SYNC generic map(8,64) port map(rst_dsp_307, CLK_SYSX10, rst_txant_307(i));

        u_dl_ant_sum : DL_ANT_SUM
            generic map(
                DUC_NUM                     => DUC_NUM                    --: natural; (2T2R)
            )
            port map(
                RESET                       => rst_txant_307(i)             ,--: in std_logic;
                CLK                         => CLK_SYSX10                   ,--: in std_logic; -- DUC operation clock

                IDATA_I                     => i_ant_duc_sw_out_I(i)        ,--: in std_logic_array16(DUC_NUM-1 downto 0);
                IDATA_Q                     => i_ant_duc_sw_out_Q(i)        ,--: in std_logic_array16(DUC_NUM-1 downto 0);

                ODATA_I                     => i_ant_sum_I(i)               ,--: out std_logic_vector(15 downto 0);
                ODATA_Q                     => i_ant_sum_Q(i)                --: out std_logic_vector(15 downto 0)
            );

        u_dl_ant_dly : dduc_ant_delay
            generic map(
                DATA_WIDTH                  => 16                               ,--: integer:=  16;
                BUF_DEPTH                   => 512                              ,--: integer:= 256;
                BUF_RES                     => 1                                 --: integer:=   1
            )
            port map(
                RST                         => rst_txant_307(i)                 ,--: in  std_logic;
                CLK                         => CLK_SYSX10                       ,--: in  std_logic;
                DELAY(8 downto 1)           => DL_CRR_DLY_IN(i)(7 downto 0)     ,--: in  std_logic_vector(log2(BUF_DEPTH)-1 downto 0);
                DELAY(0)                    => '0'                              ,--: in  std_logic_vector(log2(BUF_DEPTH)-1 downto 0);
                I_IN                        => i_ant_sum_I(i)                   ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
                Q_IN                        => i_ant_sum_Q(i)                   ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
                I_OUT                       => i_ant_dly_i(i)                   ,--: out std_logic_vector(DATA_WIDTH-1 downto 0)
                Q_OUT                       => i_ant_dly_q(i)                    --: out std_logic_vector(DATA_WIDTH-1 downto 0)
            );

        g_DL_PATH_ATT_T : if DL_PATH_ATT_EN = TRUE generate
            u_dl_path_att_i : dduc_atten
                generic map(
                    CHANNEL_NUMBERS             => 1                            ,--: natural:=4;
                    DATA_WIDTH                  => 16                           ,--: natural:=16;
                    GAIN_WIDTH                  => 16                           ,--: natural:=16;
                    BINARY_POINT                => 13                            --: natural:=16
                )
                port map(
                    RST                         => rst_txant_307(i)             ,--: in  std_logic;
                    CLK                         => CLK_SYSX10                   ,--: in  std_logic;
                    GAIN(0)                     => DL_PATH_ATT_IN(i)            ,--: in  std_logic_array16(CHANNEL_NUMBERS-1 downto 0);--MUST be positive always!!

                    FRAME_I                     => '1'                          ,--: in  std_logic;
                    VALID_I                     => '1'                          ,--: in  std_logic;
                    FILTER_IN                   => i_ant_dly_i(i)               ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);

                    FRAME_O                     => open                         ,--: out std_logic;
                    VALID_O                     => open                         ,--: out std_logic;
                    FILTER_OUT                  => i_dl_path_att_i(i)            --: out std_logic_vector(DATA_WIDTH-1 downto 0)
                );

            u_dl_path_att_q : dduc_atten
                generic map(
                    CHANNEL_NUMBERS             => 1                            ,--: natural:=4;
                    DATA_WIDTH                  => 16                           ,--: natural:=16;
                    GAIN_WIDTH                  => 16                           ,--: natural:=16;
                    BINARY_POINT                => 13                            --: natural:=16
                )
                port map(
                    RST                         => rst_txant_307(i)             ,--: in  std_logic;
                    CLK                         => CLK_SYSX10                   ,--: in  std_logic;
                    GAIN(0)                     => DL_PATH_ATT_IN(i)            ,--: in  std_logic_array16(CHANNEL_NUMBERS-1 downto 0);--MUST be positive always!!

                    FRAME_I                     => '1'                          ,--: in  std_logic;
                    VALID_I                     => '1'                          ,--: in  std_logic;
                    FILTER_IN                   => i_ant_dly_q(i)               ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);

                    FRAME_O                     => open                         ,--: out std_logic;
                    VALID_O                     => open                         ,--: out std_logic;
                    FILTER_OUT                  => i_dl_path_att_q(i)            --: out std_logic_vector(DATA_WIDTH-1 downto 0)
                );
        end generate;

        g_DL_PATH_ATT_F : if DL_PATH_ATT_EN = FALSE generate
            i_dl_path_att_i(i)                  <= i_ant_sum_I(i);
            i_dl_path_att_q(i)                  <= i_ant_sum_Q(i);
        end generate;

        process(rst_txant_307(i),CLK_SYSX10)
        begin
            if rst_txant_307(i)='1' then
                DL_IQ_ISZERO_OUT(i)             <= '1';
            elsif CLK_SYSX10'event and CLK_SYSX10='1' then
                if (i_dl_path_att_i(i)=0 and i_dl_path_att_q(i)=0) then
                    DL_IQ_ISZERO_OUT(i)         <= '1';
                else
                    DL_IQ_ISZERO_OUT(i)         <= '0';
                end if;
            end if;
        end process;
        DL_CLK_ISZERO_OUT(i)                    <= CLK_SYSX10;
        SIG_SUS_FLAG_OUT(i)                     <= '0';
    end generate;

    g_TX_RES_SYNC_E : if (DUC_DELAY-ternary_func(DUC_NUM=2*DL_BBIQARY_NUM,5,0)) mod 2 = 1 generate
        i_duc_out_s_sh              <= i_duc_out_s(0);
    end generate;

    g_TX_RES_SYNC_O : if (DUC_DELAY-ternary_func(DUC_NUM=2*DL_BBIQARY_NUM,5,0)) mod 2 = 0 generate
        process(rst_dsp_307,CLK_SYSX10)
        begin
            if (rst_dsp_307='1') then
                i_duc_out_s_sh      <= '0';
            elsif (CLK_SYSX10'event and CLK_SYSX10='1') then
                i_duc_out_s_sh      <= i_duc_out_s(0);
            end if;
        end process;
    end generate;

    process(rst_dsp_307,CLK_SYSX10)
    begin
        if (rst_dsp_307='1') then
            i_dl_path_att_i_1d                  <= (others=>x"0000");
            i_dl_path_att_q_1d                  <= (others=>x"0000"); 
            i_dl_path_att_i_2d                  <= (others=>x"0000"); 
            i_dl_path_att_q_2d                  <= (others=>x"0000"); 
            i_dl_path_att_i_3d                  <= (others=>x"0000"); 
            i_dl_path_att_q_3d                  <= (others=>x"0000"); 
            i_dl_path_att_i_4d                  <= (others=>x"0000"); 
            i_dl_path_att_q_4d                  <= (others=>x"0000"); 
        elsif (CLK_SYSX10'event and CLK_SYSX10='1') then
            i_dl_path_att_i_1d                  <= i_dl_path_att_i;
            i_dl_path_att_q_1d                  <= i_dl_path_att_q;
            i_dl_path_att_i_2d                  <= i_dl_path_att_i_1d;
            i_dl_path_att_q_2d                  <= i_dl_path_att_q_1d;
            i_dl_path_att_i_3d                  <= i_dl_path_att_i_2d;
            i_dl_path_att_q_3d                  <= i_dl_path_att_q_2d;
            i_dl_path_att_i_4d                  <= i_dl_path_att_i_3d;
            i_dl_path_att_q_4d                  <= i_dl_path_att_q_3d;
        end if;
    end process;
    
    DL_I_OUT                                    <= i_dl_path_att_i_4d;
    DL_Q_OUT                                    <= i_dl_path_att_q_4d;
    DL_SYNC_OUT                                 <= (others=>'0');

    ------------------------------------------------------------------------
    -- UL ------------------------------------------------------------------
    ------------------------------------------------------------------------

    g_UL_PATH_DLY : for i in RX_ANT_NUM-1 downto 0 generate
        u_rst_rxant_307   : RST_SYNC generic map(8,64) port map(rst_dsp_307, CLK_SYSX10, rst_rxant_307(i));

        u_ul_ant_dly : dduc_ant_delay
        generic map(
            DATA_WIDTH                  => 16                               ,--: integer:=  16;
            BUF_DEPTH                   => 512                              ,--: integer:= 256;
            BUF_RES                     => 1                                 --: integer:=   1
        )
        port map(
            RST                         => rst_rxant_307(i)                 ,--: in  std_logic;
            CLK                         => CLK_SYSX10                       ,--: in  std_logic;
            DELAY(8 downto 1)           => UL_CRR_DLY_IN(i)(7 downto 0)     ,--: in  std_logic_vector(log2(BUF_DEPTH)-1 downto 0);
            DELAY(0)                    => '0'                              ,--: in  std_logic_vector(log2(BUF_DEPTH)-1 downto 0);
            I_IN                        => UL_I_IN(i)                       ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
            Q_IN                        => UL_Q_IN(i)                       ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
            I_OUT                       => ul_dly_i(i)                      ,--: out std_logic_vector(DATA_WIDTH-1 downto 0)
            Q_OUT                       => ul_dly_q(i)                       --: out std_logic_vector(DATA_WIDTH-1 downto 0)
        );
    end generate;

    g_UL_PWR_MEAS_T : if UL_PWR_MEAS_EN = TRUE generate
        u_pwr_meas_switch : pwr_meas_switch
        generic map(
            PATH_NUM                    => RX_ANT_NUM                   ,--: natural:= 2
            CLK_DIV                     => 1                            ,--: natural:= 2; -- CLK_DIV = clock rate/data rate
            ACCUM_NUM_WIDTH             => 20                           ,--: natural:= 20;-- Number of samples to be averaged = 2^ACCUM_NUM_WIDTH
            DATA_WIDTH                  => 16                            --: natural:= 16 -- Data bits width
        )
        port map(
            RESET                       => rst_dsp_307                  ,--: in  std_logic;
            CLK                         => CLK_SYSX10                   ,--: in  std_logic;            

            FRAME_10MS                  => UL_BFN_STRB_IN               ,--: in  std_logic;
            FRAME_TDD                   => UL_TDD_IN                    ,--: in  std_logic;

            DATA_IN_I                   => ul_dly_i                     ,--: in  std_logic_array16(PATH_NUM-1 downto 0);
            DATA_IN_Q                   => ul_dly_q                     ,--: in  std_logic_array16(PATH_NUM-1 downto 0);

            PWR_OUT                     => UL_ADC_PWR_OUT                --: out std_logic_array32(PATH_NUM-1 downto 0)
        );
    end generate;

    g_UL_PWR_MEAS_F : if UL_PWR_MEAS_EN = FALSE generate
        UL_ADC_PWR_OUT                  <= (others=>(others=>'0'));
    end generate;

    g_DDC_BLK : for i in DDC_NUM-1 downto 0 generate
        u_rst_ddc       : RST_SYNC generic map(8,64) port map(rst_dduc_all, CLK_SYSX8, i_rst_ddc(i));
        u_rst_ddc_307   : RST_SYNC generic map(8,64) port map(rst_dduc_all, CLK_SYSX10, i_rst_ddc_307(i));

        u_UL_ant_sw : UL_ANT_DDC_SW
            generic map (
                ANT_NUM                     => RX_ANT_NUM                    --: natural := 4;
            )
            port map(
                RESET                       => i_rst_ddc_307(i)             ,--: in std_logic;
                CLK                         => CLK_SYSX10                   ,--: in std_logic; -- DUC operation clock

                UL_ANT_IN_DATA_I            => ul_dly_i                     ,--: in std_logic_array16(RX_ANT_NUM-1 downto 0);
                UL_ANT_IN_DATA_Q            => ul_dly_q                     ,--: in std_logic_array16(RX_ANT_NUM-1 downto 0);

                -- "00" ant.#0 , "01" ant#1 , "10" ant.#2 , "11" ant#3  max. antenna number 4.     if 6 or 8 => (3*DDC_NUM-1 downto 0)
                UL_ANT_IN_CONTROL           => UL_ANT_SEL_IN(i)             ,--: in std_logic_vector(7 downto 0);

                ODATA_0_I                   => i_ddc0_in_I(i)               ,--: out std_logic_array16(DDC_NUM-1 downto 0);
                ODATA_0_Q                   => i_ddc0_in_Q(i)               ,--: out std_logic_array16(DDC_NUM-1 downto 0);
                ODATA_1_I                   => i_ddc1_in_I(i)               ,--: out std_logic_array16(DDC_NUM-1 downto 0);
                ODATA_1_Q                   => i_ddc1_in_Q(i)                --: out std_logic_array16(DDC_NUM-1 downto 0);
            );

        u_umts_lte_ddc : umts_lte_ddc
            generic map(
                DDC_IN_HOVS                 => DDC_IN_HOVS                   --: integer := 2
            )
            port map(
                CLOCK                       => CLK_SYSX8                    ,--:in std_logic;
                CLOCK_307                   => CLK_SYSX10                   ,--:in std_logic; : in  std_logic;
                DDC_RESET                   => i_rst_ddc(i)                 ,--:in std_logic;
                DDC_RESET_307               => i_rst_ddc_307(i)             ,--:in std_logic;
            
                MODE                        => i_ddc_bw(i)                  ,--:in std_logic_vector(2 downto 0);
            
                --ddc if
                SYNC_10MS                   => UL_BFN_STRB_IN               ,--:in std_logic;
                I_DDC_IN0                   => i_ddc0_in_I(i)               ,--:in std_logic_vector(15 downto 0);
                Q_DDC_IN0                   => i_ddc0_in_Q(i)               ,--:in std_logic_vector(15 downto 0);
                I_DDC_IN1                   => i_ddc1_in_I(i)               ,--:in std_logic_vector(15 downto 0);
                Q_DDC_IN1                   => i_ddc1_in_Q(i)               ,--:in std_logic_vector(15 downto 0);
            
                --NCOs for UMTS/LTE DDC
                DDC_NCO_WREN                => DDC_NCO_WEN_IN(2*i+1 downto 2*i)    ,--:in std_logic;
                DDC_NCO0                    => DDC_NCO_DATA_IN(2*i)(30 downto 0)   ,--:in std_logic_vector(30 downto 0);
                DDC_NCO1                    => DDC_NCO_DATA_IN(2*i+1)(30 downto 0) ,--:in std_logic_vector(30 downto 0);
            
                --ddc gain
                DDC_GAIN0                   => DDC_GAIN_IN(2*i)             ,--:in std_logic_vector(15 downto 0);
                DDC_GAIN1                   => DDC_GAIN_IN(2*i+1)           ,--:in std_logic_vector(15 downto 0);
            
                DDC_SYNC                    => i_ddc_sync_out(i)            ,--:out std_logic;
                DDC_OUT                     => i_ddc_data_out(i)             --:out std_logic_vector(15 downto 0);
            );
    end generate;

    ----------------------------------------------------------------------------------------------------------------------
    -- dump

    process(rst_dsp_307, CLK_SYSX10)
    begin
        if (rst_dsp_307='1') then
            dump_toggle_x10             <= (others=>'0');
        elsif (CLK_SYSX10'event and CLK_SYSX10='1') then
            if (dl_duc_sync_delay0_sh = '0' and dl_bfn_strobe = '1') then
                dump_toggle_x10         <= (others=>'0');
            else
                dump_toggle_x10         <= dump_toggle_x10 + '1';
            end if;
        end if;
    end process;

    process(rst_dsp_307,CLK_SYSX10)
    begin
        if (rst_dsp_307='1') then
            dump_point_sel_strb_x10_sh   <= (others=>'0');
            dump_point_sel_x10           <= (others=>'0');
            dl_duc_sync_delay0_sh        <= '0';
            DUMP_DVLD_OUT(1)             <= '0';
            DUMP_DATA_OUT(1)             <= (others=>'0');
        elsif (CLK_SYSX10'event and CLK_SYSX10='1') then
            dump_point_sel_strb_x10_sh   <= dump_point_sel_strb_x10_sh(0) & DUMP_POINT_SEL_STRB_IN;

            if (dump_point_sel_strb_x10_sh(1)='1') then dump_point_sel_x10 <= DUMP_POINT_SEL_IN; end if;

            dl_duc_sync_delay0_sh        <= dl_bfn_strobe;
            s_ul_sync_out_1d             <= s_ul_sync_out;
            s_ul_sync_out_2d             <= s_ul_sync_out_1d;
            s_ul_sync_out_3d             <= s_ul_sync_out_2d;
            s_ul_iq_out_1d               <= s_ul_iq_out;

            case (dump_point_sel_x10(5 downto 0)) is
                when "000000" => DUMP_DVLD_OUT(1) <= dump_toggle_x10(0);  DUMP_DATA_OUT(1) <= dump_duc_out_0_I(0)   & dump_duc_out_0_Q(0);  -- FA#0 A (2T2R)
                when "000001" => DUMP_DVLD_OUT(1) <= dump_toggle_x10(0);  DUMP_DATA_OUT(1) <= dump_duc_out_1_I(0)   & dump_duc_out_1_Q(0);  -- FA#0 B (2T2R)                
                when "000010" => DUMP_DVLD_OUT(1) <= dump_toggle_x10(0);  DUMP_DATA_OUT(1) <= dump_duc_out_0_I(1)   & dump_duc_out_0_Q(1);  -- FA#1 A (2T2R)
                when "000011" => DUMP_DVLD_OUT(1) <= dump_toggle_x10(0);  DUMP_DATA_OUT(1) <= dump_duc_out_1_I(1)   & dump_duc_out_1_Q(1);  -- FA#1 B (2T2R)
                when "000100" => DUMP_DVLD_OUT(1) <= dump_toggle_x10(0);  DUMP_DATA_OUT(1) <= i_dl_path_att_i(0) & i_dl_path_att_q(0);
                when "000101" => DUMP_DVLD_OUT(1) <= dump_toggle_x10(0);  DUMP_DATA_OUT(1) <= i_dl_path_att_i(1) & i_dl_path_att_q(1);

                when "000110" => DUMP_DVLD_OUT(1) <= dump_toggle_x10(0);  DUMP_DATA_OUT(1) <= UL_I_IN(0)         & UL_Q_IN(0);
                when "000111" => DUMP_DVLD_OUT(1) <= dump_toggle_x10(0);  DUMP_DATA_OUT(1) <= UL_I_IN(1)         & UL_Q_IN(1);
                -- when "001000" => DUMP_DVLD_OUT(0) <= s_ul_sync_out_1d(0); DUMP_DATA_OUT(0) <= s_ul_iq_out_1d(0)  & s_ul_iq_out(0);  -- FA#0 A path
                -- when "001001" => DUMP_DVLD_OUT(0) <= s_ul_sync_out_3d(0); DUMP_DATA_OUT(0) <= s_ul_iq_out_1d(0)  & s_ul_iq_out(0);  -- FA#0 B path
                -- when "001010" => DUMP_DVLD_OUT(0) <= s_ul_sync_out_1d(0); DUMP_DATA_OUT(0) <= s_ul_iq_out_1d(1)  & s_ul_iq_out(1);  -- FA#1 A path
                -- when "001011" => DUMP_DVLD_OUT(0) <= s_ul_sync_out_3d(0); DUMP_DATA_OUT(0) <= s_ul_iq_out_1d(1)  & s_ul_iq_out(1);  -- FA#1 A path

                when others  => DUMP_DVLD_OUT(1) <= '0'              ; DUMP_DATA_OUT(1) <= (others=>'0');
            end case;
        end if;
    end process;

    DUMP_BFN_STRB_OUT(1) <= dl_duc_sync_delay0_sh;

end Behavioral;
