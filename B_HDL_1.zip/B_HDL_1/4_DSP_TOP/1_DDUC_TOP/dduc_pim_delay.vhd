--DDUC pim delay
--Operating clock : 245.76MHz
--Sampling rate   : 122.88Msps
--Resolution      : 122.88Msps
--Max depth       : 512
--DELAY value     : 4-512


library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity dduc_pim_delay is
generic(
    DATA_WIDTH                  : integer:=  16;--fixed
    BUF_DEPTH                   : integer:= 512;--fixed
    BUF_RES                     : integer:=   1 --fixed
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    SYNC                        : in  std_logic;
    DELAY0                      : in  std_logic_vector(log2(BUF_DEPTH)-1 downto 0);
    DELAY1                      : in  std_logic_vector(log2(BUF_DEPTH)-1 downto 0);
    I_IN                        : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    Q_IN                        : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    I_OUT                       : out std_logic_vector(DATA_WIDTH-1 downto 0);
    Q_OUT                       : out std_logic_vector(DATA_WIDTH-1 downto 0)
);
end dduc_pim_delay;

architecture Behavioral of dduc_pim_delay is

    component dduc_bram is
    generic(
        BUFF_DEPTH                  : integer;
        WIDTH_IN                    : integer
    );
    port(
        CLK                         : in  std_logic;
        WE                          : in  std_logic;
        WADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
        RADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
        DATA_IN                     : in  std_logic_vector(WIDTH_IN-1 downto 0);
        DATA_OUT                    : out std_logic_vector(WIDTH_IN-1 downto 0)
    );
    end component;

    signal waddr                    : std_logic_vector(log2(BUF_DEPTH*BUF_RES*2)-1 downto 0);
    signal delay_r0                 : std_logic_vector(log2(BUF_DEPTH)-1 downto 0);
    signal delay_r1                 : std_logic_vector(log2(BUF_DEPTH)-1 downto 0);
    signal raddr0                   : std_logic_vector(log2(BUF_DEPTH*BUF_RES)-1 downto 0);
    signal raddr1                   : std_logic_vector(log2(BUF_DEPTH*BUF_RES)-1 downto 0);
    signal raddr                    : std_logic_vector(log2(BUF_DEPTH*BUF_RES*2)-1 downto 0);
    signal zeros                    : std_logic_vector(log2(BUF_RES)-1 downto 0):=(others=>'0');

begin

    process(CLK)
    begin
        if CLK'event and CLK='1' then
            if RST='1' then
                waddr(log2(BUF_DEPTH*BUF_RES*2)-1 downto 6) <= (others=>'0');
            elsif SYNC='1' then
                waddr(log2(BUF_DEPTH*BUF_RES*2)-1 downto 6) <= waddr(log2(BUF_DEPTH*BUF_RES*2)-1 downto 6) + '1';
            end if;

            if RST='1' then
                waddr(5 downto 0) <= (others=>'0');
--            elsif waddr=BUF_DEPTH-1 then
--                waddr <= (others=>'0');
            elsif SYNC='1' then
                waddr(5 downto 0) <= (others=>'0');
            else
                waddr(5 downto 0) <= waddr(5 downto 0) + '1';
            end if;
        end if;
    end process;

    process(CLK)
    begin
        if CLK'event and CLK='1' then
            if DELAY0<=2 then
                delay_r0 <= conv_std_logic_vector(2,log2(BUF_DEPTH));
--            elsif DELAY0>=BUF_DEPTH-1 then
--                delay_r0 <= conv_std_logic_vector(BUF_DEPTH-1,log2(BUF_DEPTH));
            else
                delay_r0 <= DELAY0;
            end if;

            if DELAY1<=2 then
                delay_r1 <= conv_std_logic_vector(2,log2(BUF_DEPTH));
--            elsif DELAY1>=BUF_DEPTH-1 then
--                delay_r1 <= conv_std_logic_vector(BUF_DEPTH-1,log2(BUF_DEPTH));
            else
                delay_r1 <= DELAY1;
            end if;

            if RST='1' then
                raddr0 <= conv_std_logic_vector(BUF_DEPTH/2*2-1,log2(BUF_DEPTH*BUF_RES));
            elsif waddr(0)='0' then
                if waddr(log2(BUF_DEPTH*BUF_RES*2)-1 downto log2(2)) = delay_r0-"10" then
                    raddr0 <= (others=>'0');
                else
                    raddr0 <= raddr0 + '1';
                end if;
            end if;

            if RST='1' then
                raddr1 <= conv_std_logic_vector(BUF_DEPTH/2*2-1,log2(BUF_DEPTH*BUF_RES));
            elsif waddr(0)='1' then
                if waddr(log2(BUF_DEPTH*BUF_RES*2)-1 downto log2(2)) = delay_r1-"10" then
                    raddr1 <= (others=>'0');
                else
                    raddr1 <= raddr1 + '1';
                end if;
            end if;

            if RST='1' then
                raddr <= (others=>'0');
            elsif waddr(0)='1' then
                raddr <= raddr0 & '0';
            else
                raddr <= raddr1 & '1';
            end if;
        end if;
    end process;

    u_dduc_bram : dduc_bram
    generic map(
        BUFF_DEPTH                  => BUF_DEPTH*2                      ,--: integer := 1024;
        WIDTH_IN                    => DATA_WIDTH*2                      --: integer := 16
    )
    port map(
        CLK                         => CLK                              ,--: in  std_logic;
        WE                          => '1'                              ,--: in  std_logic;
        WADDR                       => waddr                            ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
        RADDR                       => raddr                            ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
        DATA_IN(29 downto 15)       => I_IN                             ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
        DATA_IN(14 downto 0)        => Q_IN                             ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
        DATA_OUT(29 downto 15)      => I_OUT                            ,--: out std_logic_vector(WIDTH_IN-1 downto 0)
        DATA_OUT(14 downto 0)       => Q_OUT                             --: out std_logic_vector(WIDTH_IN-1 downto 0)
    );

end Behavioral;
