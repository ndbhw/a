--*****************************************************************************
--Compelx multiplier
--*****************************************************************************
------------------------------------------------------------------
-- 2014.11.26, wj311.kim  : Arria 10 Complex multiplier inferring
------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity dduc_comp_mult_a10 is
generic(
    WIDTH_IN                    : natural := 16;
    NCO_WIDTH_IN                : natural := 16;
    SUM_EN                      : natural := 0;
    HOVS                        : natural := 1
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    DATA_IN_I                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_IN_Q                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_IN_COS                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);
    DATA_IN_SIN                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    DATA_OUT_I                  : out std_logic_vector(WIDTH_IN+NCO_WIDTH_IN-1 downto 0);
    DATA_OUT_Q                  : out std_logic_vector(WIDTH_IN+NCO_WIDTH_IN-1 downto 0)
);
end dduc_comp_mult_a10;

architecture Behavioral of dduc_comp_mult_a10 is

constant COMM_WAIT_DELAY        : integer := 0;-- wait 2 clock for calculating common term(HOPS=2), wait time mux iq(HOVS=1), Altera not support
constant DSP_LATENCY            : integer := 2+HOVS+COMM_WAIT_DELAY;-- 3+HOVS : DSP input to output processing delay
constant WIDTH_OUT              : integer:= WIDTH_IN+NCO_WIDTH_IN;

signal frame_in_d               : std_logic_vector(DSP_LATENCY-1 downto 0);
signal valid_in_d               : std_logic_vector(DSP_LATENCY-1 downto 0);

signal data_in_0_i_d            : signed(WIDTH_IN-1 downto 0);
signal data_in_0_q_d            : signed(WIDTH_IN-1 downto 0);
signal data_in_0_cos_d          : signed(WIDTH_IN-1 downto 0);
signal data_in_0_sin_d          : signed(WIDTH_IN-1 downto 0);
signal data_in_0_i_r            : signed(WIDTH_IN-1 downto 0);
signal data_in_0_q_r            : signed(WIDTH_IN-1 downto 0);
signal data_in_0_cos_r          : signed(WIDTH_IN-1 downto 0);
signal data_in_0_sin_r          : signed(WIDTH_IN-1 downto 0);

signal data_in_1_i_d            : signed(WIDTH_IN-1 downto 0);
signal data_in_1_q_d            : signed(WIDTH_IN-1 downto 0);
signal data_in_1_cos_d          : signed(WIDTH_IN-1 downto 0);
signal data_in_1_sin_d          : signed(WIDTH_IN-1 downto 0);
signal data_in_1_i_r            : signed(WIDTH_IN-1 downto 0);
signal data_in_1_q_r            : signed(WIDTH_IN-1 downto 0);
signal data_in_1_cos_r          : signed(WIDTH_IN-1 downto 0);
signal data_in_1_sin_r          : signed(WIDTH_IN-1 downto 0);

signal data_out_i_r             : signed(WIDTH_IN+NCO_WIDTH_IN-1 downto 0);
signal data_out_q_r             : signed(WIDTH_IN+NCO_WIDTH_IN-1 downto 0);

begin

    -- Frame/Valid delay
    FRAME_O <= frame_in_d(frame_in_d'high);
    VALID_O <= ternary_func(SUM_EN=1, frame_in_d(frame_in_d'high), valid_in_d(valid_in_d'high));-- if HOVS=2, divide valid signal rate by 2
    process(RST, CLK)
    begin
        if RST = '1' then
            frame_in_d <= (others => '0');
            valid_in_d <= (others => '0');
        elsif rising_edge(CLK) then
            frame_in_d <= frame_in_d(frame_in_d'length-2 downto 0) & FRAME_I;
            valid_in_d <= valid_in_d(valid_in_d'length-2 downto 0) & VALID_I;
        end if;
    end process;

    -- DSP input registering
    process(CLK)
    begin
        if rising_edge(CLK) then
            data_in_0_i_d     <= signed(DATA_IN_I);
            data_in_0_q_d     <= signed(DATA_IN_Q);
            data_in_0_cos_d   <= signed(DATA_IN_COS);
            data_in_0_sin_d   <= signed(DATA_IN_SIN);
            data_in_1_i_d     <= signed(DATA_IN_I);
            data_in_1_q_d     <= signed(DATA_IN_Q);
            data_in_1_cos_d   <= signed(DATA_IN_COS);
            data_in_1_sin_d   <= signed(DATA_IN_SIN);
            data_in_0_i_r     <= data_in_0_i_d;
            data_in_0_q_r     <= data_in_0_q_d;
            data_in_0_cos_r   <= data_in_0_cos_d;
            data_in_0_sin_r   <= data_in_0_sin_d;
            data_in_1_i_r     <= data_in_1_i_d;
            data_in_1_q_r     <= data_in_1_q_d;
            data_in_1_cos_r   <= data_in_1_cos_d;
            data_in_1_sin_r   <= data_in_1_sin_d;
        end if;
    end process;

    -- Complex multiplier
    DATA_OUT_I <= std_logic_vector(data_out_i_r);
    DATA_OUT_Q <= std_logic_vector(data_out_q_r);
   process(CLK)
   begin
      if rising_edge(CLK) then
            -- Calculate both the real and imaginary parts of the product
            data_out_i_r <= resize(data_in_0_i_r * data_in_0_cos_r, WIDTH_OUT) - resize(data_in_0_q_r * data_in_0_sin_r, WIDTH_OUT);
            data_out_q_r <= resize(data_in_1_i_r * data_in_1_sin_r, WIDTH_OUT) + resize(data_in_1_q_r * data_in_1_cos_r, WIDTH_OUT);
      end if;
   end process;

end Behavioral;
