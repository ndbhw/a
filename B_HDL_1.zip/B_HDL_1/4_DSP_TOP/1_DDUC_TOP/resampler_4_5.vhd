library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity resampler_4_5 is
generic(
    VENDOR                      : string := "XILINX";
    UP_RATE                     : integer:= 4;
    DOWN_RATE                   : integer:= 5;
    WIDTH_IN                    : integer:= 16;
    WIDTH_OUT                   : integer:= 16;
    WIDTH_COEFF                 : integer:= 16;
    BINARY_POINT                : integer:= 14;
    HOVS                        : integer:= 2;
    ORDER                       : integer:= 56
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    VALID_IN                    : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    VALID_OUT                   : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1  downto 0)
);
end resampler_4_5;

architecture rtl of resampler_4_5 is


    component dduc_delay_chain is
    generic(
        BUFF_DEPTH                  : natural:= 16;-- SRL16E
        DIRECTION                   : natural:= 1; -- 1:forward, 0:reverse
        WIDTH_IN                    : natural:= 16 -- Input data width
    );
    port(
        CLK                         : in  std_logic;
        DATA_SEL                    : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
        VALID_I                     : in  std_logic;
        FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
        FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
    );
    end component;

    component dduc_dsp is
    generic(
        PCIN_EN                     : boolean := FALSE;
        D_EN                        : boolean := FALSE;
        C_EN                        : boolean := FALSE;

        WIDTH_A                     : integer := 16;
        WIDTH_D                     : integer := 16;
        WIDTH_B                     : integer := 16;
        WIDTH_C                     : integer := 16;
        WIDTH_PCIN                  : integer := 48;
        WIDTH_PCOUT                 : integer := 48;
        WIDTH_P                     : integer := 48
    );
    port(
        CLK                         : in  std_logic;

        SEL                         : in  std_logic;
        CEP                         : in  std_logic;
        DSP_A_INV                   : in  std_logic;

        DSP_A                       : in  std_logic_vector(WIDTH_A-1 downto 0);
        DSP_D                       : in  std_logic_vector(WIDTH_D-1 downto 0);
        DSP_B                       : in  std_logic_vector(WIDTH_B-1 downto 0);
        DSP_C                       : in  std_logic_vector(WIDTH_C-1 downto 0);

        DSP_PCIN                    : in  std_logic_vector(WIDTH_PCIN-1 downto 0);
        DSP_PCOUT                   : out std_logic_vector(WIDTH_PCOUT-1 downto 0);
        DSP_P                       : out std_logic_vector(WIDTH_P-1 downto 0)
    );
    end component;

--LTE, 40/122.88, 30tap
--    constant COEFF                  : integer_array(ORDER-1 downto 0):= (0,0,62,184,333,373,104,-616,-1696,-2679,-2781,-1148,2729,8625,15451,21512,25082,25082,21512,15451,8625,2729,-1148,-2781,-2679,-1696,-616,104,373,333,184,62);
--LTE, 50/122.88, 40tap
    constant COEFF                  : integer_array(ORDER-1 downto 0):= (0,0,-32,-62,-72,-15,146,398,646,718,420,-359,-1526,-2715,-3320,-2657,-215,4090,9762,15778,20832,23719,23719,20832,15778,9762,4090,-215,-2657,-3320,-2715,-1526,-359,420,718,646,398,146,-15,-72,-62,-32);
--LTE, 60/122.88, 40tap
--    constant COEFF                  : integer_array(ORDER-1 downto 0):= (0,0,-42,-100,-158,-150,-8,298,698,996,922,253,-1019,-2562,-3692,-3547,-1399,2998,9174,15959,21777,25138,25138,21777,15959,9174,2998,-1399,-3547,-3692,-2562,-1019,253,922,996,698,298,-8,-150,-158,-100,-42);
--LTE, 60/122.88, 36tap
--    constant COEFF                  : integer_array(ORDER-1 downto 0):= (0,0,0,0,0,0,10,89,231,437,618,622,283,-494,-1616,-2732,-3262,-2550,-97,4176,9790,15738,20734,23589,23589,20734,15738,9790,4176,-97,-2550,-3262,-2732,-1616,-494,283,622,618,437,231,89,10);
--5G, 50/153.6, 72tap
--    constant COEFF                  : integer_array(ORDER-1 downto 0):= (0,0,-28,-42,-57,-56,-27,35,123,217,280,275,170,-41,-326,-617,-814,-816,-552,-18,702,1435,1952,2019,1474,297,-1345,-3095,-4454,-4880,-3914,-1307,2884,8269,14159,19692,23989,26337,26337,23989,19692,14159,8269,2884,-1307,-3914,-4880,-4454,-3095,-1345,297,1474,2019,1952,1435,702,-18,-552,-816,-814,-617,-326,-41,170,275,280,217,123,35,-27,-56,-57,-42,-28);
--5G, 45/153.6, 48tap
--    constant COEFF                  : integer_array(ORDER-1 downto 0):= (-113,-178,-245,-245,-128,134,519,940,1253,1283,881,-10,-1297,-2715,-3845,-4188,-3291,-867,3086,8234,13933,19337,23562,25880,25880,23562,19337,13933,8234,3086,-867,-3291,-4188,-3845,-2715,-1297,-10,881,1283,1253,940,519,134,-128,-245,-245,-178,-113);
--2/3, 70M, 30tap
--    constant COEFF                  : integer_array(ORDER-1 downto 0):= (0,0,0,-61,-190,-276,-93,453,1014,851,-518,-2475,-3154,-553,5696,13381,18693,18693,13381,5696,-553,-3154,-2475,-518,851,1014,453,-93,-276,-190,-61,0);

    constant CHANNEL_NUMBERS        : integer := 1;
    constant DSP_INSTANCES          : integer := ORDER/(UP_RATE*HOVS);
    constant DSP_MAX_COEF_NUM       : integer := 2**log2(DOWN_RATE*HOVS);
    constant DELAY_MEM_NUM          : integer := ORDER/(UP_RATE*HOVS);
    constant DELAY_MEM_DEPTH        : integer := ternary_func(2*CHANNEL_NUMBERS*HOVS<16, 16, 2*CHANNEL_NUMBERS*HOVS);
    constant VDSP                   : integer := 4;-- DSP Valid latency(3) + DSP48 in register(2) - 1 (for DSP input registering)
    -- DSP latency(4) + (HOVS - 1) CLK(DSP loopback cycle) + DSP48 in register(2)+DSP(n-1) delay (all DSP delay except 1st DSP)
    constant PROC_DELAY             : integer := 4+(HOVS-1)+2+HOVS*(DSP_INSTANCES-1);
    constant VALID_OUT_DELAY        : integer := PROC_DELAY-2;-- minus 2 clock =  Valid input 1 clock + down_cnt 1 clock
    constant WIDTH_DSP              : integer := 48;
    constant WIDTH_BINARY           : integer := BINARY_POINT+2;-- +1 for signed bit


    type data_array                 is array(natural range <>) of std_logic_vector(WIDTH_IN-1 downto 0);
    type coef_array                 is array(natural range <>) of std_logic_vector(WIDTH_COEFF-1 downto 0);
    type chain_array                is array(natural range <>) of std_logic_vector(WIDTH_DSP-1 downto 0);
    type hovs_array                 is array(natural range <>) of std_logic_vector(ternary_func(HOVS=1, 1, log2(HOVS))-1 downto 0);
    type delay_sel_array            is array(natural range <>) of std_logic_vector(log2(DELAY_MEM_DEPTH)-1 downto 0);
    type delay_sel_hovs_array       is array(natural range <>) of delay_sel_array(HOVS-1 downto 0);
    type dsp_coef_array             is array(natural range <>) of integer_array(DSP_MAX_COEF_NUM-1 downto 0);
    type dsp_coef_sel_array         is array(natural range <>) of std_logic_vector(log2(DSP_MAX_COEF_NUM)-1 downto 0);

    signal down_cnt                 : std_logic_vector(log2(DOWN_RATE)-1 downto 0);
    signal valid_in_d               : std_logic_vector(PROC_DELAY-1 downto 0);
    signal i_valid_out              : std_logic;
    signal i_valid_out_d            : std_logic_vector(VALID_OUT_DELAY-1 downto 0);
--    signal i_valid_anded            : std_logic;

    signal ovs                      : hovs_array(DSP_INSTANCES-1 downto 0);

    signal delay_data_valid         : std_logic_vector(DELAY_MEM_NUM-1 downto 0);
    signal delay_data_sel           : delay_sel_array(DELAY_MEM_NUM-1 downto 0);
    signal delay_data_in            : data_array(DELAY_MEM_NUM-1 downto 0);
    signal delay_data_out           : data_array(DELAY_MEM_NUM-1 downto 0);

    signal coef_sel                 : dsp_coef_sel_array(DSP_INSTANCES-1 downto 0);
    signal sel                      : std_logic_vector(DSP_INSTANCES-1 downto 0);
    signal dsp_a                    : data_array(DSP_INSTANCES-1 downto 0);
    signal dsp_d                    : data_array(DSP_INSTANCES-1 downto 0);
    signal dsp_b                    : coef_array(DSP_INSTANCES-1 downto 0);
    signal dsp_c                    : data_array(DSP_INSTANCES-1 downto 0);
    signal dsp_pcin                 : chain_array(DSP_INSTANCES-1 downto 0);
    signal dsp_pcout                : chain_array(DSP_INSTANCES-1 downto 0);
    signal dsp_p                    : chain_array(DSP_INSTANCES-1 downto 0);

    attribute KEEP                           : string;
    attribute KEEP of ovs                    : signal is "TRUE";
    attribute KEEP of delay_data_in          : signal is "TRUE";
    attribute KEEP of delay_data_valid       : signal is "TRUE";
    attribute KEEP of delay_data_sel         : signal is "TRUE";
    attribute KEEP of dsp_a                  : signal is "TRUE";
    attribute MAX_FANOUT                     : integer;
    attribute MAX_FANOUT of delay_data_valid : signal is 32;
    attribute MAX_FANOUT of delay_data_sel   : signal is 8;

    -- Coefficient mapping function for DSP internal coefficient rom data
    function data_sel_init return delay_sel_hovs_array is
        variable result : delay_sel_hovs_array(DELAY_MEM_NUM-1 downto 0);
    begin
        MEM_LOOP : for M in 0 to DELAY_MEM_NUM-1 loop
            HOVS_LOOP : for H in 0 to HOVS-1 loop
                if H = 0 then
                    if M = 0  then
                        result(M)(H) :=  std_logic_vector(to_unsigned(0                     , log2(DELAY_MEM_DEPTH)));-- first delay chain
                    else
                        result(M)(H) :=  std_logic_vector(to_unsigned(CHANNEL_NUMBERS+1-1   , log2(DELAY_MEM_DEPTH)));
                    end if;
                else
                    result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))+CHANNEL_NUMBERS , log2(DELAY_MEM_DEPTH)));
                end if;
            end loop;
        end loop;
        return result;
    end function data_sel_init;
    constant DELAY_HOVS_SEL         : delay_sel_hovs_array(DELAY_MEM_NUM-1 downto 0) := data_sel_init;

    -- Coefficient mapping function for DSP internal coefficient rom data
    function coeff_init return dsp_coef_array is
        variable result : dsp_coef_array(DSP_INSTANCES-1 downto 0);
    begin
        M_LOOP : for M in 0 to DSP_INSTANCES-1 loop
            N_LOOP : for N in 0 to DSP_MAX_COEF_NUM-1 loop
                if N <= UP_RATE-1 then
                    result(M)(N) :=  COEFF(UP_RATE*HOVS*M+N);
                elsif N >= UP_RATE*HOVS and N <= UP_RATE*(HOVS+1)-1 then
                    result(M)(N) :=  COEFF(UP_RATE*HOVS*M+N-UP_RATE);
--          elsif N >= 4*HOVS and N <= 4*HOVS+UP_RATE-1 then
--                    result(M)(N) :=  COEFF(UP_RATE*HOVS*M+(N+2)-UP_RATE);
                else
                    result(M)(N) :=  0;
                end if;
            end loop;
        end loop;
        return result;
    end function coeff_init;
    constant COEFF_REGEN            : dsp_coef_array(DSP_INSTANCES-1 downto 0) := coeff_init;


begin

    -- Input delay, no reset for shift register implementation
    process(CLK)
    begin
        if CLK'event and CLK='1' then
            valid_in_d  <= valid_in_d(valid_in_d'length-2 downto 0) & VALID_IN;
        end if;
    end process;

    -- downsample counter
    process(CLK,RST)
    begin
        if RST='1' then
            down_cnt <= (others => '0');
        elsif CLK'event and CLK='1' then
            if VALID_IN = '1' then
                if down_cnt = DOWN_RATE-1 then
                    down_cnt <= (others => '0');
                else
                    down_cnt <= down_cnt + 1;
                end if;
            end if;
        end if;
    end process;

    -- output valid generation
    process(CLK,RST)
    begin
        if RST='1' then
            i_valid_out <= '0';
        elsif CLK'event and CLK='1' then
            if down_cnt = DOWN_RATE-1 then
                i_valid_out <= '0';
            else
                i_valid_out <= '1';
            end if;
        end if;
    end process;

    -- valid out delay, no reset for shift register implementation
    process(CLK)
    begin
        if CLK'event and CLK='1' then
            i_valid_out_d <= i_valid_out_d(i_valid_out_d'length-2 downto 0) & i_valid_out;
        end if;
    end process;

DELAY_GEN : for N in 0 to DELAY_MEM_NUM-1 generate
begin
    DELAY_GEN_0 : if N = 0 generate
    begin
        delay_data_valid(N) <= VALID_IN;-- write only 1st data
        delay_data_in(N)    <= FILTER_IN;
        delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS)));
    end generate DELAY_GEN_0;
    DELAY_GEN_N : if N > 0 generate
    begin
        delay_data_valid(N) <= VALID_IN;-- write only (HOVS)th data
        delay_data_in(N)    <= delay_data_out(N-1);
        delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS)));
    end generate DELAY_GEN_N;

    u_dduc_delay_chain : dduc_delay_chain
    generic map(
        BUFF_DEPTH                  => DELAY_MEM_DEPTH              ,--: natural:= 16;-- SRL16E
        DIRECTION                   => 0                            ,--: natural:= 1: -- 1:forward, 0:reverse
        WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
    )
    port map(
        CLK                         => CLK                          ,--: in  std_logic;

        DATA_SEL                    => delay_data_sel(N)            ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);

        VALID_I                     => delay_data_valid(N)          ,--: in  std_logic;
        FILTER_IN                   => delay_data_in(N)             ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);

        FILTER_OUT                  => delay_data_out(N)             --: out std_logic_vector(WIDTH_IN-1 downto 0)
    );
end generate DELAY_GEN;

DSP_BLOCK_GEN : for N in 0 to DSP_INSTANCES-1  generate
begin
    -- HOVS selection
    process(CLK)
    begin
        if CLK'event and CLK='1' then
            if HOVS = 1 then
                sel(N) <= '0';
            elsif valid_in_d(3) = '1' then                                          -- only 1 cycle for adding PCIN, +2 CLK after DSP input data
                sel(N) <= '0';
            elsif or_reduce(valid_in_d(VDSP-1+(HOVS-2) downto VDSP-1)) = '1' then-- Valid dsp - 1 CLK cycle (HOVS cycle - 1)
                sel(N) <= '1';
            else
                sel(N) <= '0';
            end if;
        end if;
    end process;

    -- HOVS selection, each DSP use seperated ovs signal for performance
    process(CLK,RST)
    begin
        if RST='1' then
            ovs(N)  <= (others=> '0');
        elsif CLK'event and CLK='1' then
            if HOVS = 1  then
                ovs(N)  <= (others=> '0');
            elsif VALID_IN = '1' then
                ovs(N)  <= (others=> '0');
            elsif or_reduce(valid_in_d(HOVS-2 downto 0)) = '1' then
                ovs(N)  <= ovs(N) + '1';
            end if;
        end if;
    end process;

    -- DSP Input(A/D/B) registering
    process(CLK,RST)
    begin
        if RST = '1' then
            dsp_a(N) <= (others => '0');
            dsp_b(N) <= (others => '0');
        elsif CLK'event and CLK='1' then
            dsp_a(N) <= delay_data_out(N);
            dsp_b(N) <= sign_extension(COEFF_REGEN(N)(conv_integer(coef_sel(N))), WIDTH_COEFF);
        end if;
    end process;
    dsp_d(N) <= (others => '0');

    -- DSP #0 Signal Generation
    DSP_SIG_GEN_FIRST : if N = 0 generate
        coef_sel(N) <= VALID_IN & down_cnt;
        dsp_c(N)    <= sign_extension(2**(BINARY_POINT), WIDTH_BINARY);
        dsp_pcin(N) <= (others => '0');
    end generate DSP_SIG_GEN_FIRST;

    DSP_SIG_GEN_N : if N > 0 generate
        u_delay_coeff_sel : dduc_delay_chain
        generic map(
            BUFF_DEPTH                  => HOVS                         ,--: natural:= 16;-- SRL16E
            DIRECTION                   => 0                            ,--: natural:= 1: -- 1:forward, 0:reverse
            WIDTH_IN                    => log2(DSP_MAX_COEF_NUM)        --: natural:= 16 -- Input data width
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;
            DATA_SEL                    => std_logic_vector(to_unsigned(HOVS-1, log2(HOVS))),
            VALID_I                     => '1'                          ,--: in  std_logic;
            FILTER_IN                   => coef_sel(N-1)                ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
            FILTER_OUT                  => coef_sel(N)                   --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );
        dsp_c(N)    <= (others=>'0');
        dsp_pcin(N) <= dsp_pcout(N-1);
    end generate DSP_SIG_GEN_N;

    u_dduc_dsp : dduc_dsp
    generic map(
        PCIN_EN                     => ternary_func(N=0,FALSE,TRUE) ,--: boolean := FALSE;
        D_EN                        => FALSE                        ,--: boolean := FALSE;
        C_EN                        => ternary_func(N=0,TRUE,FALSE) ,--: boolean := FALSE;

        WIDTH_A                     => WIDTH_IN                     ,--: integer := 16;
        WIDTH_D                     => WIDTH_IN                     ,--: integer := 16;
        WIDTH_B                     => WIDTH_COEFF                  ,--: integer := 16;
        WIDTH_C                     => WIDTH_BINARY                 ,--: integer := 16;
        WIDTH_PCIN                  => WIDTH_DSP                    ,--: integer := 48;
        WIDTH_PCOUT                 => WIDTH_DSP                    ,--: integer := 48;
        WIDTH_P                     => WIDTH_DSP                     --: integer := 48
    )
    port map(
        CLK                         => CLK                          ,--: in  std_logic;

        SEL                         => sel(N)                       ,--: in  std_logic;
        CEP                         => '1'                          ,--: in  std_logic;
        DSP_A_INV                   => '0'                          ,--: in  std_logic;

        DSP_A                       => dsp_a(N)                     ,--: in  std_logic_vector(WIDTH_A-1 downto 0);
        DSP_D                       => dsp_d(N)                     ,--: in  std_logic_vector(WIDTH_D-1 downto 0);
        DSP_B                       => dsp_b(N)                     ,--: in  std_logic_vector(WIDTH_B-1 downto 0);
        DSP_C                       => dsp_c(N)                     ,--: in  std_logic_vector(WIDTH_C-1 downto 0);

        DSP_PCIN                    => dsp_pcin(N)                  ,--: in  std_logic_vector(WIDTH_PCIN-1 downto 0);
        DSP_PCOUT                   => dsp_pcout(N)                 ,--: out std_logic_vector(WIDTH_PCOUT-1 downto 0);
        DSP_P                       => dsp_p(N)                      --: out std_logic_vector(WIDTH_P-1 downto 0)
    );
end generate DSP_BLOCK_GEN;

    VALID_OUT  <= valid_in_d(valid_in_d'high) and i_valid_out_d(i_valid_out_d'high);
    FILTER_OUT <= dsp_p(DSP_INSTANCES-1)(WIDTH_OUT+BINARY_POINT downto BINARY_POINT+1);


--    round_stage_ins: round_stage
--    generic map(
--        VAR_WIDTH       => 1,
--        FIXED_GAIN      => 1,
--        WIDTH_IN        => WIDTH_RESULT,
--        WIDTH_OUT       => WIDTH_OUT,
--        BINARY_POINT    => BINARY_POINT,
--        ROUNDING        => "ROUND_INF",
--        OVERFLOW        => "SATURATE"
--    )
--    port map(
--        CLK             => CLK,
--        RST             => RST,
--        BIT_SHIFT_VALUE => (others => '0'),
--
--        FRAME_I         => '0',
--        VALID_I         => i_valid_anded,
--        FILTER_IN       => result,
--
--        FRAME_O         => open,
--        VALID_O         => VALID_OUT,
--        FILTER_OUT      => FILTER_OUT
--    );

end rtl;


