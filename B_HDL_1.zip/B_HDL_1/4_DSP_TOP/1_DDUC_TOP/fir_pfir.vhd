library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;
use work.dduc_pkg.all;

entity fir_pfir is
generic(
    VENDOR                      : string := "XILINX";
    DDUC_SEL                    : integer:= 0;-- 0 : DUC, 1 : DDC
    CHANNEL_NUMBERS             : integer:= 4;

    WIDTH_IN                    : integer:= 16;
    WIDTH_OUT                   : integer:= 16;
    WIDTH_COEFF                 : integer:= 16;

    WIDTH_RESULT                : integer:= 32;
    BINARY_POINT                : integer:= 15;

    HOVS                        : integer:= 2;
    ORDER                       : integer:= 96
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    MODE                        : in  std_logic_vector(3 downto 0);

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1  downto 0)
);
end fir_pfir;

architecture rtl of fir_pfir is

component dduc_delay_chain is
generic(
    BUFF_DEPTH                  : natural:= 16;-- SRL16E
    DIRECTION                   : natural:= 1; -- 1:forward, 0:reverse
    WIDTH_IN                    : natural:= 16 -- Input data width
);
port(
    CLK                         : in  std_logic;
    DATA_SEL                    : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

component dduc_dsp is
generic(
    PCIN_EN                     : boolean := FALSE;
    D_EN                        : boolean := FALSE;
    C_EN                        : boolean := FALSE;

    WIDTH_A                     : integer := 16;
    WIDTH_D                     : integer := 16;
    WIDTH_B                     : integer := 16;
    WIDTH_C                     : integer := 16;
    WIDTH_PCIN                  : integer := 48;
    WIDTH_PCOUT                 : integer := 48;
    WIDTH_P                     : integer := 48
);
port(
    CLK                         : in  std_logic;

    SEL                         : in  std_logic;
    CEP                         : in  std_logic;
    DSP_A_INV                   : in  std_logic;

    DSP_A                       : in  std_logic_vector(WIDTH_A-1 downto 0);
    DSP_D                       : in  std_logic_vector(WIDTH_D-1 downto 0);
    DSP_B                       : in  std_logic_vector(WIDTH_B-1 downto 0);
    DSP_C                       : in  std_logic_vector(WIDTH_C-1 downto 0);

    DSP_PCIN                    : in  std_logic_vector(WIDTH_PCIN-1 downto 0);
    DSP_PCOUT                   : out std_logic_vector(WIDTH_PCOUT-1 downto 0);
    DSP_P                       : out std_logic_vector(WIDTH_P-1 downto 0)
);
end component;

component round_stage is
generic(
    VAR_WIDTH                   : natural:= 5;
    FIXED_GAIN                  : natural:= 0;         --gain is fixed or not
    WIDTH_IN                    : natural:= 64;
    WIDTH_OUT                   : natural:= 32;
    BINARY_POINT                : natural:= 31;
    ROUNDING                    : string:= "ROUND_INF";--"FULL_PRECISION", "TRUNCATE","ROUND_INF", "ROUND_EVEN"
    OVERFLOW                    : string:= "WRAP"      --"SATURATE"
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    BIT_SHIFT_VALUE             : in  std_logic_vector(VAR_WIDTH-1 downto 0);

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1 downto 0)
);
end component;

constant ORDER_ODD              : integer := ternary_func((ORDER mod 2 = 1),1,0);
constant DSP_INSTANCES          : integer := ORDER/(2*HOVS)+ORDER_ODD;
constant DELAY_MEM_NUM          : integer := ORDER/HOVS;
constant DELAY_MEM_DEPTH        : integer := ternary_func(2*CHANNEL_NUMBERS*HOVS<16, 16, 2*CHANNEL_NUMBERS*HOVS);
constant VDSP                   : integer := 4;-- DSP Valid latency(3) + DSP48 in register(2) - 1 (for DSP input registering)
constant PROC_DELAY             : integer := 4+(HOVS-1)+2;-- DSP latency(4) + (HOVS - 1) CLK(DSP loopback cycle) + DSP48 in register(2)
constant WIDTH_DSP              : integer := 48;
constant WIDTH_BINARY           : integer := BINARY_POINT+2;-- +1 for signed bit

type data_array                 is array(natural range <>) of std_logic_vector(WIDTH_IN-1 downto 0);
type coef_array                 is array(natural range <>) of std_logic_vector(WIDTH_COEFF-1 downto 0);
type chain_array                is array(natural range <>) of std_logic_vector(WIDTH_DSP-1 downto 0);
type binary_array               is array(natural range <>) of std_logic_vector(WIDTH_BINARY-1 downto 0);
type hovs_array                 is array(natural range <>) of std_logic_vector(ternary_func(HOVS=1, 1, log2(HOVS))-1 downto 0);
type delay_sel_array            is array(natural range <>) of std_logic_vector(log2(DELAY_MEM_DEPTH)-1 downto 0);
type delay_sel_hovs_array       is array(natural range <>) of delay_sel_array(HOVS-1 downto 0);

signal coeff_duc                : integer_array(DUC_ORDER_PFIR/2-1 downto 0);
signal coeff_ddc                : integer_array(DDC_ORDER_PFIR/2-1 downto 0);
signal coeff                    : integer_array(ternary_func(DDUC_SEL=0, DUC_ORDER_PFIR, DDC_ORDER_PFIR)/2-1 downto 0);

signal frame_o_d                : std_logic_vector(PROC_DELAY-1 downto 0);
signal valid_o_d                : std_logic_vector(PROC_DELAY-1 downto 0);
signal valid_dsp_i              : std_logic_vector(DSP_INSTANCES-1 downto 0);

signal ovs                      : hovs_array(DSP_INSTANCES-1 downto 0);

signal delay_data_valid         : std_logic_vector(DELAY_MEM_NUM-1 downto 0);
signal delay_data_sel           : delay_sel_array(DELAY_MEM_NUM-1 downto 0);
signal delay_data_in            : data_array(DELAY_MEM_NUM-1 downto 0);
signal delay_data_out           : data_array(DELAY_MEM_NUM-1 downto 0);

signal sel                      : std_logic_vector(DSP_INSTANCES-1 downto 0);
signal dsp_a                    : data_array(DSP_INSTANCES-1 downto 0);
signal dsp_d                    : data_array(DSP_INSTANCES-1 downto 0);
signal dsp_b                    : coef_array(DSP_INSTANCES-1 downto 0);
signal dsp_c                    : binary_array(DSP_INSTANCES-1 downto 0);
signal dsp_pcin                 : chain_array(DSP_INSTANCES-1 downto 0);
signal dsp_pcout                : chain_array(DSP_INSTANCES-1 downto 0);
signal dsp_p                    : chain_array(DSP_INSTANCES-1 downto 0);


--signal result                   : std_logic_vector(WIDTH_RESULT-1 downto 0);

attribute KEEP                  : string;
attribute KEEP                  of ovs : signal is "TRUE";
attribute MAX_FANOUT            : integer;
attribute MAX_FANOUT of ovs     : signal is 32;
attribute MAX_FANOUT of valid_o_d : signal is 32;

-- Coefficient mapping function for DSP internal coefficient rom data
function data_sel_init return delay_sel_hovs_array is
    variable result : delay_sel_hovs_array(DELAY_MEM_NUM-1 downto 0);
begin
    MEM_LOOP : for M in 0 to DELAY_MEM_NUM-1 loop
        HOVS_LOOP : for H in 0 to HOVS-1 loop
            if H = 0 then
                if M = 0  then
                    result(M)(H) :=  std_logic_vector(to_unsigned(0                         , log2(DELAY_MEM_DEPTH)));-- first delay chain
                elsif M <= DELAY_MEM_NUM/2-1 then
                    result(M)(H) :=  std_logic_vector(to_unsigned(CHANNEL_NUMBERS-1-1       , log2(DELAY_MEM_DEPTH)));-- forward path 1st
                elsif M = DELAY_MEM_NUM/2 then
                    result(M)(H) :=  std_logic_vector(to_unsigned(CHANNEL_NUMBERS*HOVS-1    , log2(DELAY_MEM_DEPTH)));-- center delay
                else
                    result(M)(H) :=  std_logic_vector(to_unsigned(CHANNEL_NUMBERS*HOVS      , log2(DELAY_MEM_DEPTH)));-- reverse path 1st
                end if;
            else
                if M <= DELAY_MEM_NUM/2-1 then
                    result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))+CHANNEL_NUMBERS , log2(DELAY_MEM_DEPTH)));-- forward path 2nd
                elsif M = DELAY_MEM_NUM/2 then
                    result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))-CHANNEL_NUMBERS , log2(DELAY_MEM_DEPTH)));-- reverse path 2nd
                else
                    if H = 1 then
                        result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))-CHANNEL_NUMBERS+1, log2(DELAY_MEM_DEPTH)));-- reverse path HOVS cnt =2
                    else
                        result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))-CHANNEL_NUMBERS  , log2(DELAY_MEM_DEPTH)));-- reverse path HOVS cnt >2
                    end if;
                end if;
            end if;
        end loop;
    end loop;
    return result;
end function data_sel_init;

constant DELAY_HOVS_SEL         : delay_sel_hovs_array(DELAY_MEM_NUM-1 downto 0) := data_sel_init;

begin
    
    coeff_ddc   <=  DDC_PFIR_COEFF_5(DDC_ORDER_PFIR_MAX/2-1 downto (DDC_ORDER_PFIR_MAX-DDC_ORDER_PFIR)/2)     when MODE(3 downto 0) = "0010" else
                    DDC_PFIR_COEFF_10(DDC_ORDER_PFIR_MAX/2-1 downto (DDC_ORDER_PFIR_MAX-DDC_ORDER_PFIR)/2)    when MODE(3 downto 0) = "0011" else
                     DDC_PFIR_COEFF_15(DDC_ORDER_PFIR_MAX/2-1 downto (DDC_ORDER_PFIR_MAX-DDC_ORDER_PFIR)/2)    when MODE(3 downto 0) = "0100" else
                    -- DDC_PFIR_COEFF_20(DDC_ORDER_PFIR_MAX/2-1 downto (DDC_ORDER_PFIR_MAX-DDC_ORDER_PFIR)/2)    when MODE(3 downto 0) = "0101" else
                    DDC_PFIR_COEFF_10(DDC_ORDER_PFIR_MAX/2-1 downto (DDC_ORDER_PFIR_MAX-DDC_ORDER_PFIR)/2);
    

    coeff_duc   <=  DUC_PFIR_COEFF_5(DUC_ORDER_PFIR_MAX/2-1 downto (DUC_ORDER_PFIR_MAX-DUC_ORDER_PFIR)/2)           when MODE(3 downto 0) = "0010" else
                    DUC_PFIR_COEFF_10(DUC_ORDER_PFIR_MAX/2-1 downto (DUC_ORDER_PFIR_MAX-DUC_ORDER_PFIR)/2)          when MODE(3 downto 0) = "0011" else
                     DUC_PFIR_COEFF_15(DUC_ORDER_PFIR_MAX/2-1 downto (DUC_ORDER_PFIR_MAX-DUC_ORDER_PFIR)/2)          when MODE(3 downto 0) = "0100" else
                    -- DUC_PFIR_COEFF_20(DUC_ORDER_PFIR_MAX/2-1 downto (DUC_ORDER_PFIR_MAX-DUC_ORDER_PFIR)/2)          when MODE(3 downto 0) = "0101" else
		            DUC_PFIR_COEFF_10(DUC_ORDER_PFIR_MAX/2-1 downto (DUC_ORDER_PFIR_MAX-DUC_ORDER_PFIR)/2);




    coeff <= coeff_duc when DDUC_SEL = 0 else coeff_ddc;

    -- Input delay
    process(CLK,RST)
    begin
        if RST='1' then
            frame_o_d   <= (others=> '0');
            valid_o_d   <= (others=> '0');
        elsif CLK'event and CLK='1' then
            frame_o_d   <= frame_o_d(PROC_DELAY-2 downto 0) & FRAME_I;
            valid_o_d   <= valid_o_d(PROC_DELAY-2 downto 0) & VALID_I;
        end if;
    end process;

    DELAY_GEN : for N in 0 to DELAY_MEM_NUM-1 generate
    begin
        DELAY_GEN_0 : if N = 0 generate
        begin
            delay_data_valid(N) <= VALID_I;
            delay_data_in(N)    <= FILTER_IN;
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS)));
        end generate DELAY_GEN_0;
        DELAY_GEN_1 : if N >= 1 and N <= DELAY_MEM_NUM/2-1 generate
        begin
            delay_data_valid(N) <= VALID_I;-- write only (HOVS)th data
            delay_data_in(N)    <= delay_data_out(N-1);
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS)));
        end generate DELAY_GEN_1;
        DELAY_GEN_N2 : if N = DELAY_MEM_NUM/2 generate
        begin
            delay_data_valid(N) <= VALID_I;-- write only (HOVS)th data
            delay_data_in(N)    <= delay_data_out(N-1);
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS/2)));-- /2 : # of delay mem/2 = # of DSP
        end generate DELAY_GEN_N2;
        DELAY_GEN_N : if N >= DELAY_MEM_NUM/2+1 and N <= DELAY_MEM_NUM-1 generate
        begin
            delay_data_valid(N) <= valid_o_d(0);-- write only 1st data
            delay_data_in(N)    <= delay_data_out(N-1);
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS/2)));-- /2 : # of delay mem/2 = # of DSP
        end generate DELAY_GEN_N;

    u_dduc_delay_chain : dduc_delay_chain
    generic map(
        BUFF_DEPTH                  => DELAY_MEM_DEPTH              ,--: natural:= 16;-- SRL16E
        DIRECTION                   => ternary_func(N <= DELAY_MEM_NUM/2, 1, 0),--: natural:= 1: -- 1:forward, 0:reverse
        WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
    )
    port map(
        CLK                         => CLK                          ,--: in  std_logic;

        DATA_SEL                    => delay_data_sel(N)            ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);

        VALID_I                     => delay_data_valid(N)          ,--: in  std_logic;
        FILTER_IN                   => delay_data_in(N)             ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);

        FILTER_OUT                  => delay_data_out(N)             --: out std_logic_vector(WIDTH_IN-1 downto 0)
    );
    end generate DELAY_GEN;

    DSP_BLOCK_GEN : for N in 0 to DSP_INSTANCES-1  generate
    begin
         -- HOVS selection
        process(CLK)
        begin
            if CLK'event and CLK='1' then
                valid_dsp_i(N) <= or_reduce(valid_o_d(VDSP-1+(HOVS-1) downto VDSP-1));

                if HOVS = 1 then
                    sel(N) <= '0';
                elsif valid_o_d(VDSP-2) = '1' then                                          -- only 1 cycle for adding PCIN, +2 CLK after DSP input data
                    sel(N) <= '0';
                elsif or_reduce(valid_o_d(VDSP-1+(HOVS-2) downto VDSP-1)) = '1' then-- Valid dsp - 1 CLK cycle (HOVS cycle - 1)
                    sel(N) <= '1';
                else
                    sel(N) <= '0';
                end if;
            end if;
        end process;

        -- HOVS selection, each DSP use seperated ovs signal for performance
        process(CLK,RST)
        begin
            if RST='1' then
                ovs(N)     <= (others=> '0');
            elsif CLK'event and CLK='1' then
                if HOVS = 1  then
                    ovs(N)    <= (others=> '0');
                elsif VALID_I = '1' then
                    ovs(N)    <= (others=> '0');
                elsif or_reduce(valid_o_d(HOVS-2 downto 0)) = '1' then
                    ovs(N)    <= ovs(N) + '1';
                end if;
            end if;
        end process;

        -- DSP Input(A/D/B) registering
        process(CLK,RST)
        begin
            if RST = '1' then
                dsp_a(N) <= (others => '0');
                dsp_d(N) <= (others => '0');
                dsp_b(N) <= (others => '0');
            elsif CLK'event and CLK='1' then
                dsp_a(N) <= delay_data_out(N);
                dsp_d(N) <= delay_data_out((DELAY_MEM_NUM-1)-N);
                dsp_b(N) <= sign_extension(coeff(N*HOVS+ conv_integer(ovs(N))), WIDTH_COEFF);
            end if;
        end process;

        -- DSP #0 Signal Generation
        DSP_SIG_GEN_0 : if N = 0 and DSP_INSTANCES /= 1 generate
            dsp_c(N)    <= (others => '0');
            dsp_pcin(N) <= dsp_pcout(N+1);
        end generate DSP_SIG_GEN_0;

        DSP_SIG_GEN_0_1 : if N = 0 and DSP_INSTANCES = 1 generate
            dsp_c(N)    <= sign_extension(2**(BINARY_POINT), WIDTH_BINARY);
            dsp_pcin(N) <= (others => '0');
        end generate DSP_SIG_GEN_0_1;

        DSP_SIG_GEN_N : if N > 0 and N < DSP_INSTANCES-1 generate
            dsp_c(N)    <= (others => '0');
            dsp_pcin(N) <= dsp_pcout(N+1);
        end generate DSP_SIG_GEN_N;

        DSP_SIG_GEN_LAST : if N = DSP_INSTANCES-1 generate
            dsp_c(N)    <= sign_extension(2**(BINARY_POINT), WIDTH_BINARY);
            dsp_pcin(N) <= (others => '0');
        end generate DSP_SIG_GEN_LAST;

        u_dduc_dsp : dduc_dsp
        generic map(
            PCIN_EN                     => ternary_func(N=DSP_INSTANCES-1,FALSE,TRUE) ,--: boolean := FALSE;
            D_EN                        => TRUE                         ,--: boolean := FALSE;
            C_EN                        => ternary_func(N=DSP_INSTANCES-1,TRUE,FALSE) ,--: boolean := FALSE;

            WIDTH_A                     => WIDTH_IN                     ,--: integer := 16;
            WIDTH_D                     => WIDTH_IN                     ,--: integer := 16;
            WIDTH_B                     => WIDTH_COEFF                  ,--: integer := 16;
            WIDTH_C                     => WIDTH_BINARY                 ,--: integer := 16;
            WIDTH_PCIN                  => WIDTH_DSP                    ,--: integer := 48;
            WIDTH_PCOUT                 => WIDTH_DSP                    ,--: integer := 48;
            WIDTH_P                     => WIDTH_DSP                     --: integer := 48
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;

            SEL                         => sel(N)                       ,--: in  std_logic;
            CEP                         => valid_dsp_i(N)               ,--: in  std_logic;
            DSP_A_INV                   => '0'                          ,--: in  std_logic;

            DSP_A                       => dsp_a(N)                     ,--: in  std_logic_vector(WIDTH_A-1 downto 0);
            DSP_D                       => dsp_d(N)                     ,--: in  std_logic_vector(WIDTH_D-1 downto 0);
            DSP_B                       => dsp_b(N)                     ,--: in  std_logic_vector(WIDTH_B-1 downto 0);
            DSP_C                       => dsp_c(N)                     ,--: in  std_logic_vector(WIDTH_C-1 downto 0);

            DSP_PCIN                    => dsp_pcin(N)                  ,--: in  std_logic_vector(WIDTH_PCIN-1 downto 0);
            DSP_PCOUT                   => dsp_pcout(N)                 ,--: out std_logic_vector(WIDTH_PCOUT-1 downto 0);
            DSP_P                       => dsp_p(N)                      --: out std_logic_vector(WIDTH_P-1 downto 0)
        );
    end generate DSP_BLOCK_GEN;

    FRAME_O    <= frame_o_d(PROC_DELAY-1);
    VALID_O    <= valid_o_d(PROC_DELAY-1);
    FILTER_OUT <= dsp_p(0)(WIDTH_OUT+BINARY_POINT downto BINARY_POINT+1);

--    result<= sign_copy(dsp_p(0),WIDTH_RESULT);

--    round_stage_ins: round_stage
--    generic map(
--        VAR_WIDTH       => 1,
--        FIXED_GAIN      => 1,
--        WIDTH_IN        => WIDTH_RESULT,
--        WIDTH_OUT       => WIDTH_OUT,
--        BINARY_POINT    => BINARY_POINT,
--        ROUNDING        => "ROUND_INF",
--        OVERFLOW        => "SATURATE"
--    )
--    port map(
--        CLK             => CLK,
--        RST             => RST,
--        BIT_SHIFT_VALUE => (others => '0'),
--
--        FRAME_I         => frame_o_d(PROC_DELAY-1),
--        VALID_I         => valid_o_d(PROC_DELAY-1),
--        FILTER_IN       => result,
--
--        FRAME_O         => FRAME_O,
--        VALID_O         => VALID_O,
--        FILTER_OUT      => FILTER_OUT
--    );
end rtl;
