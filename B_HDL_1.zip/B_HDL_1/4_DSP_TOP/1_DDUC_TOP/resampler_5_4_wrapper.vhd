library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity resampler_5_4_wrapper is
generic(
    ANT_NUM                     : integer:= 2
);
port(
    RST_245                     : in  std_logic_vector(ANT_NUM-1 downto 0);
    RST_307                     : in  std_logic_vector(ANT_NUM-1 downto 0);
    CLK_245                     : in  std_logic;-- 245.76 MHz clock
    CLK_307                     : in  std_logic;-- 307.2  MHz clock

    DATA_IN_VALID               : in  std_logic;
    DATA_IN_I                   : in  std_logic_array16(ANT_NUM-1 downto 0);
    DATA_IN_Q                   : in  std_logic_array16(ANT_NUM-1 downto 0);

    BUF_COLLISION_FLAG          : out std_logic_vector(ANT_NUM-1 downto 0);
    DATA_OUT_VALID              : out std_logic_vector(ANT_NUM-1 downto 0);
    DATA_OUT_I                  : out std_logic_array16(ANT_NUM-1 downto 0);
    DATA_OUT_Q                  : out std_logic_array16(ANT_NUM-1 downto 0)
);
end resampler_5_4_wrapper;

architecture rtl of resampler_5_4_wrapper is

    component resampler_5_4 is
    generic(
        VENDOR                      : string := "XILINX";

        UP_RATE                     : integer:= 5;
        DOWN_RATE                   : integer:= 4;

        WIDTH_IN                    : integer:= 16;
        WIDTH_OUT                   : integer:= 16;
        WIDTH_COEFF                 : integer:= 17;

        BINARY_POINT                : integer:= 14;

        HOVS                        : integer:= 2;
        ORDER                       : integer:= 55
    );
    port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        VALID_IN                    : in  std_logic;
        FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

        VALID_OUT                   : out std_logic;
        FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1  downto 0)
    );
    end component;

    component resampler_cdc_buf is
    port(
        RST_W                       : in  std_logic;-- CLK_W synchronized reset
        RST_R                       : in  std_logic;
        CLK_W                       : in  std_logic;
        CLK_R                       : in  std_logic;

        DATA_IN_VALID               : in  std_logic;
        DATA_IN_I                   : in  std_logic_vector(15 downto 0);
        DATA_IN_Q                   : in  std_logic_vector(15 downto 0);

        BUF_COLLISION_FLAG          : out std_logic;
        DATA_OUT_VALID              : out std_logic;
        DATA_OUT_I                  : out std_logic_vector(15 downto 0);
        DATA_OUT_Q                  : out std_logic_vector(15 downto 0)
    );
    end component;

    constant VENDOR                 : string := "XILINX";
    constant UP_RATE                : integer:= 5;--5,6
    constant DOWN_RATE              : integer:= 4;--4,5
    constant WIDTH_IN               : integer:= 16;
    constant WIDTH_OUT              : integer:= 16;
    constant WIDTH_COEFF            : integer:= 16;
    constant WIDTH_RESULT           : integer:= 34;
    constant BINARY_POINT           : integer:= 14;
    constant HOVS                   : integer:= 2;
    constant ORDER                  : integer:= 40;--40,72


--    signal valid_in_d               : std_logic_vector(1 downto 0);
--    signal valid_in_r               : std_logic_vector(2*ANT_NUM-1 downto 0);
    signal buf_in_valid             : std_logic_vector(ANT_NUM-1 downto 0);
    signal buf_in_i                 : std_logic_array16(ANT_NUM-1 downto 0);
    signal buf_in_q                 : std_logic_array16(ANT_NUM-1 downto 0);
    signal valid_out                : std_logic_vector(2*ANT_NUM-1 downto 0);
    signal filter_in                : std_logic_array16(2*ANT_NUM-1 downto 0);
    signal filter_out               : std_logic_array16(2*ANT_NUM-1 downto 0);


begin


--    process(RST_245(0), CLK_245)
--    begin
--        if RST_245(0)='1' then
--            valid_in_d <= (others => '0');
--            valid_in_r <= (others => '0');
--        elsif rising_edge(CLK_245) then
--            valid_in_d <= valid_in_d(0) & DATA_IN_VALID;
--            for i in 2*ANT_NUM-1 downto 0 loop
--                if valid_in_d = "01" then
--                    valid_in_r(i) <= '1';
--                else
--                    valid_in_r(i) <= not valid_in_r(i);-- generate valid in signal even DATA_IN_VALID is always zero
--                end if;
--            end loop;
--        end if;
--    end process;

GEN_RESAMPLER : for N in 0 to 2*ANT_NUM-1 generate
    u_resampler_5_4 : resampler_5_4
    generic map(
        VENDOR                      => VENDOR                       ,--: string := "XILINX";

        UP_RATE                     => UP_RATE                      ,--: integer:= 4;
        DOWN_RATE                   => DOWN_RATE                    ,--: integer:= 5;

        WIDTH_IN                    => WIDTH_IN                     ,--: integer:= 16;
        WIDTH_OUT                   => WIDTH_OUT                    ,--: integer:= 16;
        WIDTH_COEFF                 => WIDTH_COEFF                  ,--: integer:= 17;

        BINARY_POINT                => BINARY_POINT                 ,--: integer:= 14;

        HOVS                        => HOVS                         ,--: integer:= 2;
        ORDER                       => ORDER                         --: integer:= 56
    )
    port map(
        RST                         => RST_245(N/2)                 ,--: in  std_logic;
        CLK                         => CLK_245                      ,--: in  std_logic;

        VALID_IN                    => DATA_IN_VALID,--valid_in_r(N),--: in  std_logic;
        FILTER_IN                   => filter_in(N)                 ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);

        VALID_OUT                   => valid_out(N)                 ,--: out std_logic;
        FILTER_OUT                  => filter_out(N)                 --: out std_logic_vector(WIDTH_OUT-1  downto 0)
    );
end generate GEN_RESAMPLER;

GEN_IQ: for N in 0 to ANT_NUM-1 generate
    filter_in(2*N)  <= DATA_IN_I(N);
    filter_in(2*N+1)<= DATA_IN_Q(N);
    process(RST_245(N),CLK_245)
    begin
        if RST_245(N)='1' then
            buf_in_valid(N) <= '0';
            buf_in_i(N)     <= (others=>'0');
            buf_in_q(N)     <= (others=>'0');
        elsif CLK_245'event and CLK_245='1' then
            buf_in_valid(N) <= valid_out(N);
            buf_in_i(N)     <= filter_out(2*N);
            buf_in_q(N)     <= filter_out(2*N+1);
        end if;
    end process;
end generate GEN_IQ;

BUF_GEN : for N in 0 to ANT_NUM-1 generate
    u_resampler_cdc_buf : resampler_cdc_buf
    port map(
        RST_W                       => RST_245(N)                   ,--: in  std_logic;-- CLK_307 synchronized reset
        RST_R                       => RST_307(N)                   ,--: in  std_logic;
        CLK_W                       => CLK_245                      ,--: in  std_logic;
        CLK_R                       => CLK_307                      ,--: in  std_logic;

        DATA_IN_VALID               => buf_in_valid(N)              ,--: in  std_logic;
        DATA_IN_I                   => buf_in_i(N)                  ,--: in  std_logic_vector(15 downto 0);
        DATA_IN_Q                   => buf_in_q(N)                  ,--: in  std_logic_vector(15 downto 0);

        BUF_COLLISION_FLAG          => BUF_COLLISION_FLAG(N)        ,--: out std_logic;
        DATA_OUT_VALID              => DATA_OUT_VALID(N)            ,--: out std_logic;
        DATA_OUT_I                  => DATA_OUT_I(N)                ,--: out std_logic_vector(15 downto 0);
        DATA_OUT_Q                  => DATA_OUT_Q(N)                 --: out std_logic_vector(15 downto 0)
    );
end generate;

end rtl;


