----------------------------------------
--top level of duc core
--LTE scalable core 5/10/15/20 MHz 2 C
-- OR
--UMTS 2 C
--Operating Frequency 245.76 MHz
--FPGA :
--Revision : 2014/11/26 - wj311.kim
-----------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;
use work.dduc_pkg.all;

entity umts_lte_duc is
    port(
        CLOCK                       : in  std_logic;
        CLOCK_307                   : in  std_logic;
        DUC_RESET                   : in  std_logic;
        DUC_RESET_307               : in  std_logic;

        MODE                        : in  std_logic_vector(3 downto 0);

        --DUC IF
        DUC_SYNC                    : in  std_logic;
        DUC_IN                      : in  std_logic_vector(15 downto 0);

        --NCOS FOR UMTS/LTE DUC
        DUC_NCO_WREN                : in  std_logic_vector(1 downto 0);
        DUC_NCO0                    : in  std_logic_vector(30 downto 0);
        DUC_NCO1                    : in  std_logic_vector(30 downto 0);

        --GAIN FOR UMTS/LTE
        DUC_GAIN0                   : in  std_logic_vector(15 downto 0);
        DUC_GAIN1                   : in  std_logic_vector(15 downto 0);

        --DUC IF
        S_DUC_OUT                   : out std_logic;
        I_DUC_OUT0                  : out std_logic_vector(15 downto 0);
        Q_DUC_OUT0                  : out std_logic_vector(15 downto 0);
        I_DUC_OUT1                  : out std_logic_vector(15 downto 0);
        Q_DUC_OUT1                  : out std_logic_vector(15 downto 0);
        --PIM IF
        PIM_FRAME_O                 : out std_logic;
        PIM_VALID_O                 : out std_logic;
        PIM_OUT                     : out std_logic_array16(1 downto 0)
    );
end umts_lte_duc;

architecture rtl of umts_lte_duc is

component dduc_atten is
generic(
    CHANNEL_NUMBERS             : natural:=4;
    DATA_WIDTH                  : natural:=16;
    GAIN_WIDTH                  : natural:=16;
    BINARY_POINT                : natural:=15
);
port(
    CLK                         : in  std_logic;
    RST                         : in  std_logic;
    GAIN                        : in  std_logic_array16(CHANNEL_NUMBERS-1 downto 0);--MUST be positive always!!

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(DATA_WIDTH-1 downto 0)
);
end component;

component dduc_delay is
generic(
    DATA_WIDTH                  : integer:= 16;
    CHANNEL_NUMBER              : integer:= 4;
    MAX_DELAY_SAMPLE            : integer:= 256;
    MAX_DELAY_CLOCK             : integer:= 16
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    DLY_SAMPLE                  : in  std_logic_vector(log2(MAX_DELAY_SAMPLE)-1 downto 0);
    DLY_CLOCK                   : in  std_logic_vector(log2(MAX_DELAY_CLOCK)-1 downto 0);

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    DATA_IN                     : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    DATA_OUT                    : out std_logic_vector(DATA_WIDTH-1 downto 0)
);
end component;

component duc_composite is
port(
    RST_307                     : in  std_logic;
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    CLK_307                     : in  std_logic;

    MODE                        : in  std_logic_vector(3 downto 0);
    NCO_WREN                    : in  std_logic_vector(DUC_NCO_CHANNELS-1 downto 0);
    NCO_FREQ_WORD               : in  std_logic_vector(DUC_NCO_CHANNELS*(log2(DUC_NCO_ACCU_VAL/DUC_HB_N_OUT))-1 downto 0);

    DUC_FRAME_I                 : in  std_logic;
    DUC_VALID_I                 : in  std_logic;
    DUC_IN                      : in  std_logic_vector(DUC_WIDTH_I-1 downto 0);

    DUC_FRAME_O                 : out std_logic;
    DUC_VALID_O                 : out std_logic;
    DUC_OUT                     : out duc_output_type;
    PIM_FRAME_O                 : out std_logic;
    PIM_VALID_O                 : out std_logic;
    PIM_OUT                     : out duc_output_type
);
end component;

constant MAX_DELAY_SAMPLE       : integer := 512;
constant MAX_DELAY_CLOCK        : integer := 16;
constant DELAY_SAMPLE_WIDTH     : integer := log2(MAX_DELAY_SAMPLE);
constant DELAY_CLOCK_WIDTH      : integer := log2(MAX_DELAY_CLOCK);
constant DLY_S_5M_122p88M       : std_logic_vector(DELAY_SAMPLE_WIDTH-1 downto 0) := std_logic_vector(to_unsigned(0,   DELAY_SAMPLE_WIDTH));
constant DLY_S_10M_122p88M      : std_logic_vector(DELAY_SAMPLE_WIDTH-1 downto 0) := std_logic_vector(to_unsigned(18+DUC_ORDER_PFIR/2,   DELAY_SAMPLE_WIDTH));--66
constant DLY_S_20M_122p88M      : std_logic_vector(DELAY_SAMPLE_WIDTH-1 downto 0) := std_logic_vector(to_unsigned(56+DUC_ORDER_PFIR/2*3, DELAY_SAMPLE_WIDTH));--197
constant DLY_C_5M_122p88M       : std_logic_vector(DELAY_CLOCK_WIDTH-1 downto 0)  := std_logic_vector(to_unsigned(0,   DELAY_CLOCK_WIDTH));
--constant DLY_C_10M_122p88M      : std_logic_vector(DELAY_CLOCK_WIDTH-1 downto 0)  := std_logic_vector(to_unsigned(12,  DELAY_CLOCK_WIDTH));--12
constant DLY_C_10M_122p88M      : std_logic_vector(DELAY_CLOCK_WIDTH-1 downto 0)  := std_logic_vector(to_unsigned(10,  DELAY_CLOCK_WIDTH));--10, type01
constant DLY_C_20M_122p88M      : std_logic_vector(DELAY_CLOCK_WIDTH-1 downto 0)  := std_logic_vector(to_unsigned(7,   DELAY_CLOCK_WIDTH));--0
constant DLY_S_5M_061p44M       : std_logic_vector(DELAY_SAMPLE_WIDTH-1 downto 0) := std_logic_vector(to_unsigned(0,   DELAY_SAMPLE_WIDTH));
constant DLY_S_10M_061p44M      : std_logic_vector(DELAY_SAMPLE_WIDTH-1 downto 0) := std_logic_vector(to_unsigned(18+DUC_ORDER_PFIR/2,   DELAY_SAMPLE_WIDTH));--66
constant DLY_S_20M_061p44M      : std_logic_vector(DELAY_SAMPLE_WIDTH-1 downto 0) := std_logic_vector(to_unsigned(56+DUC_ORDER_PFIR/2*3, DELAY_SAMPLE_WIDTH));--197
constant DLY_C_5M_061p44M       : std_logic_vector(DELAY_CLOCK_WIDTH-1 downto 0)  := std_logic_vector(to_unsigned(0,   DELAY_CLOCK_WIDTH));
constant DLY_C_10M_061p44M      : std_logic_vector(DELAY_CLOCK_WIDTH-1 downto 0)  := std_logic_vector(to_unsigned(10,  DELAY_CLOCK_WIDTH));--12
constant DLY_C_20M_061p44M      : std_logic_vector(DELAY_CLOCK_WIDTH-1 downto 0)  := std_logic_vector(to_unsigned(5,   DELAY_CLOCK_WIDTH));--0

signal mode_r0                  : std_logic_vector(3 downto 0);
signal mode_r1                  : std_logic_vector(3 downto 0);
signal mode_r2                  : std_logic_vector(3 downto 0);
signal mode_d1                  : std_logic_vector(3 downto 0);
signal mode_w                   : std_logic_vector(2 downto 0);
signal mode_change_flag         : std_logic;

signal sync_fail                : std_logic;
signal sync_fail_2              : std_logic;
signal sync_fail_sh0            : std_logic;
signal sync_fail_sh1            : std_logic;

signal stable_cnt               : std_logic_vector(14 downto 0);
signal stable_flag              : std_logic;
signal stable_flag_sh0          : std_logic;
signal stable_flag_sh1          : std_logic;
signal resync_en                : std_logic;

signal fail_flag                : std_logic_vector(1 downto 0);

signal duc_in_r                 : std_logic_vector(15 downto 0);
type   buf_type                 is array(integer range <>) of std_logic_vector(15 downto 0);
signal duc_in_buf               : buf_type(2 downto 0);
signal duc_frame_i              : std_logic;
signal duc_valid_i              : std_logic;
signal duc_cnt                  : natural range 0 to 31;
signal duc_sync_d               : std_logic;

signal duc_frame_o              : std_logic;
signal duc_valid_o              : std_logic;
signal duc_frame_valid          : std_logic;
signal duc_nframe_valid         : std_logic;

signal duc_out                  : duc_output_type;

signal duc_gain_ab              : std_logic_array16(CHANNEL_NUMBERS-1 downto 0);

signal att_in_frame_i           : std_logic;
signal att_in_valid_i           : std_logic;
signal att_in_in                : std_logic_vector(15 downto 0);

signal att_duc_frame_i          : std_logic;
signal att_duc_valid_i          : std_logic;
signal att_duc_in               : std_logic_vector(15 downto 0);

signal dly_frame                : std_logic;
signal dly_valid                : std_logic;
signal dly_data                 : std_logic_vector(15 downto 0);

signal dly_sample               : std_logic_vector(log2(MAX_DELAY_SAMPLE)-1 downto 0);
signal dly_clock                : std_logic_vector(log2(MAX_DELAY_CLOCK)-1 downto 0);

signal I_duc_out_w0             : std_logic_vector(15 downto 0):=(others=>'0');
signal Q_duc_out_w0             : std_logic_vector(15 downto 0):=(others=>'0');

signal duc_nco_fcw              : std_logic_vector(DUC_NCO_CHANNELS*(log2(DUC_NCO_ACCU_VAL/DUC_HB_N_OUT))-1 downto 0);

attribute KEEP                  : string;
attribute KEEP                  of mode_d1 : signal is "TRUE";
attribute MAX_FANOUT            : integer;
attribute MAX_FANOUT of mode_d1          : signal is 64;
attribute MAX_FANOUT of fail_flag        : signal is 16;
attribute MAX_FANOUT of duc_frame_o      : signal is 16;
attribute MAX_FANOUT of duc_valid_o      : signal is 16;
attribute MAX_FANOUT of duc_frame_valid  : signal is 16;
attribute MAX_FANOUT of duc_nframe_valid : signal is 16;
attribute MAX_FANOUT of duc_cnt          : signal is 16;

--attribute mark_debug : string;
--attribute mark_debug of duc_gain_ab         : signal is "true";
--attribute mark_debug of dly_frame           : signal is "true";
--attribute mark_debug of dly_valid           : signal is "true";
--attribute mark_debug of dly_data            : signal is "true";
--attribute mark_debug of mode_d1             : signal is "true";

begin

    duc_nco_fcw <= DUC_NCO1(log2(DUC_NCO_ACCU_VAL/DUC_HB_N_OUT)-1 downto 0) & DUC_NCO0(log2(DUC_NCO_ACCU_VAL/DUC_HB_N_OUT)-1 downto 0);

    mode_w          <= mode_d1(2 downto 0);

    -- mode control registering
    process(CLOCK,DUC_RESET)
    begin
        if DUC_RESET='1' then
            mode_r0 <=(others => '0');
            mode_r1 <=(others => '0');
            mode_r2 <=(others => '0');
            mode_d1 <=(others => '0');
        elsif CLOCK'event and CLOCK='1' then
            mode_r0 <= MODE;
            mode_r1 <= mode_r0;
            mode_r2 <= mode_r1;
            if resync_en = '1' then
                mode_d1<= mode_r2;
            end if;
        end if;
    end process;

    --  mode change flag for flusing internal data
    process(CLOCK,DUC_RESET)
    begin
        if DUC_RESET='1' then
            mode_change_flag <= '0';
        elsif CLOCK'event and CLOCK='1' then
            if mode_r2/=mode_r1 then
                mode_change_flag <= '1';
            else
                mode_change_flag <= '0';
            end if;
        end if;
    end process;

    -- Input sync fail deteciton for internal data flushing
    process(CLOCK,DUC_RESET)
    begin
        if DUC_RESET = '1' then
            sync_fail    <= '1';
            sync_fail_sh0 <= '1';
            sync_fail_sh1 <= '1';
        elsif rising_edge(CLOCK)  then
            -- input sync. monitoring
            if stable_flag = '1' then
                if DUC_SYNC='1' and duc_sync_d='0' then
                    if duc_cnt = 0 then
                        sync_fail <= '0';       -- normal
                    else
                        sync_fail <= '1';       -- fail
                    end if;
                elsif duc_cnt = 0 then          -- sync signal detection
                    if DUC_SYNC='1' and duc_sync_d='0' then
                        sync_fail <= '0';       -- normal
                    else
                        sync_fail <= '1';       -- fail (thers is no sync signal)
                    end if;
                end if;
            else
                sync_fail <= '0';               -- wait for flushing
            end if;
            sync_fail_sh0 <= sync_fail;
            sync_fail_sh1 <= sync_fail_sh0;
        end if;
    end process;

    -- Simulation mode
    process(CLOCK,DUC_RESET)
    begin
        if DUC_RESET = '1' then
            stable_cnt      <= (others => '0');
            resync_en       <= '0';
            stable_flag     <= '0';
            stable_flag_sh0  <= '0';
            stable_flag_sh1  <= '0';
        elsif rising_edge(CLOCK)  then
            if sync_fail = '1' or mode_change_flag = '1' then
--            if sync_fail = '1' then
                stable_cnt <= (others => '0');
            else
                if stable_cnt(10) = '1' then -- 66 us stable count for longer than processing delay
                    stable_cnt <= stable_cnt;
                else
                    stable_cnt <= stable_cnt + '1';
                end if;
            end if;
            if stable_cnt(10 downto 9) = "01" then
                resync_en <= '1';
            else
                resync_en <= '0';
            end if;
            stable_flag     <= stable_cnt(10);
            stable_flag_sh0  <= stable_flag;
            stable_flag_sh1  <= stable_flag_sh0;
        end if;
    end process;

    -- duc sync counter
    process(CLOCK,DUC_RESET)
    begin
        if DUC_RESET = '1' then
            duc_sync_d <= '0';
            duc_cnt    <=  0 ;
        elsif rising_edge(CLOCK)  then
            duc_sync_d <= DUC_SYNC;
            if (DUC_SYNC='1' and duc_sync_d='0' and resync_en = '1') or duc_cnt = 0 then
                if mode_w(2) = '1' then                                 -- 15/20MHz
                    duc_cnt <= 7;
                elsif mode_w(1) = '1' and mode_w(0) = '1' then          -- 10MHz
                    duc_cnt <= 15;
                else                                                    -- 5/3/1.4MHz
                    duc_cnt <= 31;
                end if;
            else
                duc_cnt<=duc_cnt-1;
            end if;
        end if;
    end process;

    --conversion to duc format - frame
    process(CLOCK,DUC_RESET)
    begin
        if DUC_RESET='1' then
            duc_frame_i <='0';
        elsif CLOCK'event and CLOCK='1' then
            if duc_cnt = 0 then
                duc_frame_i <= '1';
            else
                duc_frame_i <= '0';
            end if;
        end if;
    end process;

    --conversion to duc format - channel valid
    process(CLOCK,DUC_RESET)
    begin
        if DUC_RESET='1' then
            duc_valid_i <='0';
        elsif CLOCK'event and CLOCK='1' then
            case duc_cnt is
                when 24     => duc_valid_i <= '1';
                when 16     => duc_valid_i <= '1';
                when 12     => duc_valid_i <= ternary_func(mode_w =3, '1', duc_valid_i);
                when  8     => duc_valid_i <= '1';
                when  6     => duc_valid_i <= ternary_func(mode_w>=4, '1', duc_valid_i);--ternary_func(mode_w>=2, ternary_func(mode_w<4, '1', duc_valid_i), duc_valid_i);
                when  4     => duc_valid_i <= ternary_func(mode_w>=3, '1', duc_valid_i);--ternary_func(mode_w> 0, ternary_func(mode_w<4, '1', duc_valid_i), duc_valid_i);
                when  2     => duc_valid_i <= ternary_func(mode_w>=4, '1', duc_valid_i);--ternary_func(mode_w>=2, ternary_func(mode_w<4, '1', duc_valid_i), duc_valid_i);
                when  0     => duc_valid_i <= '1';
                when others => duc_valid_i <= '0';
            end case;
        end if;
    end process;

    --conversion to duc format - channel data buffer
    process(CLOCK,DUC_RESET)
    begin
        if DUC_RESET='1' then
            duc_in_buf <= (others=>(others=>'0'));
        elsif CLOCK'event and CLOCK='1' then
            case duc_cnt is
                when 31     => duc_in_buf(0) <= DUC_IN;
                when 30     => duc_in_buf(1) <= DUC_IN;
                when 29     => duc_in_buf(2) <= DUC_IN;
                when 15     => duc_in_buf(0) <= ternary_func(mode_w =3, DUC_IN, duc_in_buf(0));--ternary_func(mode_w =1, DUC_IN                                       , duc_in_buf(0));
                when 14     => duc_in_buf(1) <= ternary_func(mode_w =3, DUC_IN, duc_in_buf(1));--ternary_func(mode_w =1, DUC_IN                                       , duc_in_buf(1));
                when 13     => duc_in_buf(2) <= ternary_func(mode_w =3, DUC_IN, duc_in_buf(2));--ternary_func(mode_w =1, DUC_IN                                       , duc_in_buf(2));
                when  7     => duc_in_buf(0) <= ternary_func(mode_w>=4, DUC_IN, duc_in_buf(0));--ternary_func(mode_w>=2, ternary_func(mode_w<4, DUC_IN, duc_in_buf(0)), duc_in_buf(0));
                when  6     => duc_in_buf(1) <= ternary_func(mode_w>=4, DUC_IN, duc_in_buf(1));--ternary_func(mode_w>=2, ternary_func(mode_w<4, DUC_IN, duc_in_buf(1)), duc_in_buf(1));
                when  5     => duc_in_buf(2) <= ternary_func(mode_w>=4, DUC_IN, duc_in_buf(2));--ternary_func(mode_w>=2, ternary_func(mode_w<4, DUC_IN, duc_in_buf(2)), duc_in_buf(2));
                when others => null;
            end case;
        end if;
    end process;

    --conversion to duc format - channel data
    process(CLOCK,DUC_RESET)
    begin
        if DUC_RESET='1' then
            duc_in_r   <= (others=>'0');
        elsif CLOCK'event and CLOCK='1' then
            case duc_cnt is
                when 24     => duc_in_r <= duc_in_buf(0);
                when 16     => duc_in_r <= duc_in_buf(1);
                when 12     => duc_in_r <= ternary_func(mode_w =3, duc_in_buf(0), duc_in_r);                                        --ternary_func(mode_w =1, duc_in_buf(0)                                  , duc_in_r                                             );
                when  8     => duc_in_r <= ternary_func(mode_w<=2, duc_in_buf(2), duc_in_buf(1));                                    --ternary_func(mode_w =0, duc_in_buf(2)                                  , ternary_func(mode_w>=4, duc_in_buf(2), duc_in_buf(1)));
                when  6     => duc_in_r <= ternary_func(mode_w>=4, duc_in_buf(0), duc_in_r);                                        --ternary_func(mode_w>=2, ternary_func(mode_w<4 ,duc_in_buf(0) ,duc_in_r), duc_in_r                                             );
                when  4     => duc_in_r <= ternary_func(mode_w =3, duc_in_buf(2), ternary_func(mode_w>=4, duc_in_buf(1), duc_in_r));--ternary_func(mode_w =1, duc_in_buf(2)                                  , ternary_func(mode_w>=2, duc_in_buf(1), duc_in_r     ));
                when  2     => duc_in_r <= ternary_func(mode_w>=4, duc_in_buf(2), duc_in_r);                                        --ternary_func(mode_w>=2, ternary_func(mode_w<4 ,duc_in_buf(2) ,duc_in_r), duc_in_r                                             );
                when  0     => duc_in_r <= DUC_IN;
                when others => duc_in_r <= duc_in_r;
            end case;
        end if;
    end process;

    -- Input data masking when abnormal status
    process(CLOCK,DUC_RESET)
    begin
        if DUC_RESET = '1' then
            fail_flag(0)    <= '1';
            att_in_frame_i  <= '0';
            att_in_valid_i  <= '0';
            att_in_in       <= (others => '0');
        elsif rising_edge(CLOCK)  then
            fail_flag(0) <= (not stable_flag_sh0) or sync_fail_sh0;
            att_in_frame_i  <= duc_frame_i;
            att_in_valid_i  <= duc_valid_i;
            if fail_flag(0)='0' then
                att_in_in       <= duc_in_r;
            else
                att_in_in       <= (others => '0');-- if it is unstable status, flush duc input data
            end if;
        end if;
    end process;

    --DUC gain disable
    GAIN_GEN_EN_0 : if DUC_ATT_EN = 0 generate
        att_duc_frame_i <= att_in_frame_i;
        att_duc_valid_i <= att_in_valid_i;
        att_duc_in      <= att_in_in;
    end generate GAIN_GEN_EN_0;

    --DUC gain enable
    GAIN_GEN_EN_1 : if DUC_ATT_EN = 1 generate
        duc_gain_ab(0)<= DUC_GAIN0;
        duc_gain_ab(1)<= DUC_GAIN0;
        duc_gain_ab(2)<= DUC_GAIN1;
        duc_gain_ab(3)<= DUC_GAIN1;

        -- @245.76MHz
        duc_atten : dduc_atten
        generic map(
            CHANNEL_NUMBERS             => CHANNEL_NUMBERS              ,--:natural:=4;
            DATA_WIDTH                  => DUC_WIDTH_I                  ,--:natural:=16;
            GAIN_WIDTH                  => DUC_ATT_WIDTH                ,--:natural:=16;
            BINARY_POINT                => DUC_ATT_BIN_POINT             --:natural:=15
        )
        port map(
            RST                         => DUC_RESET                    ,--:in std_logic;
            CLK                         => CLOCK                        ,--:in std_logic;

            GAIN                        => duc_gain_ab                  ,--:in std_logic_array16(CHANNEL_NUMBERS-1 downto 0);--MUST be positive always!!

            FRAME_I                     => att_in_frame_i               ,--:in std_logic;
            VALID_I                     => att_in_valid_i               ,--:in std_logic;
            FILTER_IN                   => att_in_in                    ,--:in std_logic_vector(DATA_WIDTH-1 downto 0);

            FRAME_O                     => att_duc_frame_i              ,--:out std_logic;
            VALID_O                     => att_duc_valid_i              ,--:out std_logic;
            FILTER_OUT                  => att_duc_in                    --:out std_logic_vector(DATA_WIDTH-1 downto 0)
        );
    end generate GAIN_GEN_EN_1;

    DLY_122p88M : if DUC_HB_N_OUT = 1 generate
        dly_sample <= DLY_S_20M_122p88M  when  mode_w(2) = '1'                      else
                    DLY_S_10M_122p88M  when (mode_w(1) = '1' and mode_w(0) = '1') else
                    DLY_S_5M_122p88M;

        dly_clock  <= DLY_C_20M_122p88M  when  mode_w(2) = '1'                      else
                    DLY_C_10M_122p88M  when (mode_w(1) = '1' and mode_w(0) = '1') else
                    DLY_C_5M_122p88M;
    end generate;

    DLY_061p44M : if DUC_HB_N_OUT = 2 generate
        dly_sample <= DLY_S_20M_061p44M when  mode_w(2) = '1'                      else
                    DLY_S_10M_061p44M when (mode_w(1) = '1' and mode_w(0) = '1') else
                    DLY_S_5M_061p44M;

        dly_clock  <= DLY_C_20M_061p44M when  mode_w(2) = '1'                      else
                    DLY_C_10M_061p44M when (mode_w(1) = '1' and mode_w(0) = '1') else
                    DLY_C_5M_061p44M;
    end generate;

    -- @245.76MHz
    u_dduc_delay : dduc_delay
        generic map(
            DATA_WIDTH                  => DUC_WIDTH_I                  ,--: integer:= 16;
            CHANNEL_NUMBER              => CHANNEL_NUMBERS              ,--: integer:= 4;
            MAX_DELAY_SAMPLE            => MAX_DELAY_SAMPLE             ,--: integer:= 256;
            MAX_DELAY_CLOCK             => MAX_DELAY_CLOCK               --: integer:= 16
        )
        port map(
            RST                         => DUC_RESET                    ,--: in  std_logic;
            CLK                         => CLOCK                        ,--: in  std_logic;

            DLY_SAMPLE                  => dly_sample                   ,--: in  std_logic_vector(log2(MAX_DELAY_SAMPLE)-1 downto 0);
            DLY_CLOCK                   => dly_clock                    ,--: in  std_logic_vector(log2(MAX_DELAY_CLOCK)-1 downto 0);

            FRAME_I                     => att_duc_frame_i              ,--: in  std_logic;
            VALID_I                     => att_duc_valid_i              ,--: in  std_logic;
            DATA_IN                     => att_duc_in                   ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);

            FRAME_O                     => dly_frame                    ,--: out std_logic;
            VALID_O                     => dly_valid                    ,--: out std_logic;
            DATA_OUT                    => dly_data                      --: out std_logic_vector(DATA_WIDTH-1 downto 0)
        );

    u_duc_composite : duc_composite
        port map(
            RST_307                     => DUC_RESET_307                ,--: in  std_logic;
            RST                         => DUC_RESET                    ,--: in  std_logic;
            CLK                         => CLOCK                        ,--: in  std_logic;
            CLK_307                     => CLOCK_307                    ,--: in  std_logic;

            MODE                        => mode_d1                      ,--: in  std_logic_vector(4 downto 0);
            NCO_WREN                    => DUC_NCO_WREN                 ,--: in  std_logic_vector(DUC_NCO_CHANNELS-1 downto 0);
            NCO_FREQ_WORD               => duc_nco_fcw                  ,--: in  std_logic_vector(DUC_NCO_CHANNELS*(log2(DUC_NCO_ACCU_VAL/DUC_HB_N_OUT))-1 downto 0);

            DUC_FRAME_I                 => dly_frame                    ,--: in  std_logic;
            DUC_VALID_I                 => dly_valid                    ,--: in  std_logic;
            DUC_IN                      => dly_data                     ,--: in  std_logic_vector(DUC_WIDTH_I-1 downto 0);

            DUC_FRAME_O                 => duc_frame_o                  ,--: out std_logic;
            DUC_VALID_O                 => duc_valid_o                  ,--: out std_logic;
            DUC_OUT                     => duc_out                      ,--: out duc_output_type;
            PIM_FRAME_O                 => PIM_FRAME_O                  ,--: out std_logic;
            PIM_VALID_O                 => PIM_VALID_O                  ,--: out std_logic;
            PIM_OUT(0)                  => PIM_OUT(0)                   ,--: out duc_output_type
            PIM_OUT(1)                  => PIM_OUT(1)                    --: out duc_output_type
        );

    -- @307.2MHz -----------------------------------------------------------------------------------------------

    -- AxC #0/1 output should have same processing delay
    duc_frame_valid                     <= '1' when (duc_frame_o = '1' and duc_valid_o = '1') else '0';
    duc_nframe_valid                    <= '1' when (duc_frame_o = '0' and duc_valid_o = '1') else '0';

    process(DUC_RESET_307, CLOCK_307)
    begin
        if (DUC_RESET_307='1') then
            I_duc_out_w0                <=(others=>'0');
            Q_duc_out_w0                <=(others=>'0');
        elsif (rising_edge(CLOCK_307)) then
            if (duc_frame_valid = '1') then
                I_duc_out_w0            <= duc_out(0);
                Q_duc_out_w0            <= duc_out(1);  -- 2 path mux
            end if;
        end if;
    end process;

    process(DUC_RESET_307, CLOCK_307)
    begin
        if (DUC_RESET_307='1') then        
            S_DUC_OUT                   <= '0';
            I_DUC_OUT0                  <=(others=>'0');
            Q_DUC_OUT0                  <=(others=>'0');
            I_DUC_OUT1                  <=(others=>'0');
            Q_DUC_OUT1                  <=(others=>'0');
        elsif (rising_edge(CLOCK_307)) then
            if (duc_nframe_valid = '1') then
                I_DUC_OUT0              <= I_duc_out_w0;   -- A path
                Q_DUC_OUT0              <= Q_duc_out_w0;
                I_DUC_OUT1              <= duc_out(0);     -- B path
                Q_DUC_OUT1              <= duc_out(1);
            end if;

            if (duc_nframe_valid = '1') then
                S_DUC_OUT               <= '1';
            else
                S_DUC_OUT               <= '0';
            end if;
        end if;
    end process;

end rtl;
