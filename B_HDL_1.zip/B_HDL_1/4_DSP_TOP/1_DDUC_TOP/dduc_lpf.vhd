-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2023, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2023.11.14 v1.0] Initial release
-- *****************************************************************************

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity dduc_lpf is
    generic (
        DDUC_TYPE                           : string := "DUC";  -- "DUC" or "DDC"
        DATA_WIDTH                          : integer := 16;
        BINARY_POINT                        : integer := 15
    );
    Port (
        i_rst_307                           : in std_logic;
        i_clk_307                           : in std_logic;
        
        -- 76.8MHz, 4 channel
        i_upsample_rearrange_frame          : in std_logic;
        i_upsample_rearrange_valid          : in std_logic;
        i_upsample_rearrange_data           : in std_logic_vector(DATA_WIDTH-1 downto 0);

        -- 76.8MHz, 4 channel
        o_lpf_frame                         : out std_logic;
        o_lpf_valid                         : out std_logic;
        o_lpf_data                          : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end dduc_lpf;

architecture Behavioral of dduc_lpf is
    
    component dduc_delay_chain is
        generic(
            BUFF_DEPTH                      : natural:= 16;         -- SRL16E
            DIRECTION                       : natural:= 1;          -- 1:forward, 0:reverse
            WIDTH_IN                        : natural:= 16          -- Input data width
        );
        port(
            CLK                             : in  std_logic;
            DATA_SEL                        : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
            VALID_I                         : in  std_logic;
            FILTER_IN                       : in  std_logic_vector(WIDTH_IN-1 downto 0);
            FILTER_OUT                      : out std_logic_vector(WIDTH_IN-1 downto 0)
        );
    end component;

    component lib_adder_multi_c_pcin_dsp2 is
		generic(
			width_a                         : integer := 30;		-- max 30
			width_d                         : integer := 27;		-- max 27
			width_b                         : integer := 18;		-- max 18
			width_c						    : integer := 48;    	-- max 48
			width_p                         : integer := 48;		-- max 48
			
			pcin_use					    : std_logic := '0';		-- '0' : not use, '1' : use
			A_INPUT						    : string := "DIRECT";   -- "DIRECT" or "CASCADE"
			B_INPUT						    : string := "DIRECT";   -- "DIRECT" or "CASCADE"
			pre_add_minus				    : std_logic := '0';		-- '0' : add, '1' : sub
			c_add_minus					    : std_logic := '0'		-- '0' : add, '1' : sub
		);
		port(
			i_clk                           : in std_logic;
		
			dsp_a                           : in std_logic_vector(width_a-1 downto 0);
			dsp_d                           : in std_logic_vector(width_d-1 downto 0);
			dsp_b						    : in std_logic_vector(width_b-1 downto 0);
			dsp_c						    : in std_logic_vector(width_c-1 downto 0);
			dsp_acin					    : in std_logic_vector(30-1 downto 0);
			dsp_bcin					    : in std_logic_vector(18-1 downto 0);
			dsp_pcin					    : in std_logic_vector(48-1 downto 0);
			
			dsp_acout					    : out std_logic_vector(30-1 downto 0);
			dsp_bcout					    : out std_logic_vector(18-1 downto 0);
			dsp_pcout					    : out std_logic_vector(48-1 downto 0);
			dsp_p                           : out std_logic_vector(width_p-1 downto 0)
		);
	end component lib_adder_multi_c_pcin_dsp2;

    constant ROUND          				: std_logic_vector(48-1 downto 0) := conv_std_logic_vector(2**(BINARY_POINT), 48);

    -- EVEN ORDER
    constant NUM_COEFF                      : integer := 54;
    constant LPF_DDC_COEFF                  : integer_array(NUM_COEFF/2-1 downto 0) := (12429,10869,8127,4845,1733,-627,-1929,-2185,-1668,-782,80,649,833,691,373,41,-190,-279,-246,-147,-42,32,62,59,39,19,3);
--    constant LPF_DDC_COEFF                  : integer_array(NUM_COEFF/2-1 downto 0) := (10823,9509,7195,4415,1761,-284,-1462,-1774,-1437,-773,-97,376,566,509,313,92,-71,-143,-138,-90,-34,5,22,21,13,5,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);--(10823,9509,7195,4415,1761,-284,-1462,-1774,-1437,-773,-97,376,566,509,313,92,-71,-143,-138,-90,-34,5,22,21,13,5,1);

  --  constant LPF_DUC_COEFF                  : integer_array(NUM_COEFF/2-1 downto 0) := (58289, 55893, 51279, 44793, 36910, 28196, 19259, 10692, 3026, -3310, -8026, -10984, -12202, -11842, -10184, -7593, -4476, -1241, 1740, 4167, 5832, 6635, 6577, 5758, 4349, 2572, 668, -1132, -2628, -3676, -4196, -4176, -3666, -2771, -1629, -396, 775, 1753, 2441, 2781, 2765, 2426, 1831, 1072, 254, -523, -1171, -1624, -1846, -1832, -1604, -1208, -706, -166, 345, 770, 1067, 1212, 1204, 1058, 805, 484, 141, -181, -448, -632, -721, -712, -617, -455, -251, -32, 176, 351, 477, 548, 561, 523, 446, 341, 225, 112, 12, -67, -119, -145, -148, -133, -231);--Linh29/04(67092, 63220, 55913, 45981, 34495, 22633, 11525, 2112, -4967, -9423, -11319, -11018, -9091, -6213, -3040, -131, 2123, 3529, 4071, 3882, 3185, 2236, 1267, 455, -101, -375, -1168);--anh nguoc(67754, 52590, 28518, 4907, -10294, -14005, -8679, -117, 6023, 7001, 3660, -944, -3828, -3748, -1514, 1033, 2312, 1932, 534, -762, -1277, -894, -157, 502, 665, 562, 244);--(62145,54345,40635,24225,8665,-3135,-9645,-10925,-8340,-3910,400,3245,4165,3455,1865,205,-950,-1395,-1230,-735,-210,160,310,295,195,95,15);
    constant LPF_DUC_COEFF                  : integer_array(NUM_COEFF/2-1 downto 0) := (62145,55226,42871,27640,12503,83,-7936,-11108,-10150,-6569,-2129,1659,3882,4332,3382,1724,68,-1084,-1538,-1382,-871,-292,145,353,358,246,114);
    
    constant MODULE_LATENCY                 : integer := (NUM_COEFF*4)+(NUM_COEFF/2)+2;
    constant MOD_NUM                        : real := 307.2/153.6;--76.8;
    constant DLY_CNT                        : integer := (MODULE_LATENCY mod integer(MOD_NUM));
    
    type std_logic_data                     is array(natural range <>) of std_logic_vector(DATA_WIDTH-1 downto 0);
    -- signal data_delay                       : std_logic_data(NUM_COEFF*4+(NUM_COEFF/2)-1 downto 0);

    signal dly_dsp_a                        : std_logic_data(NUM_COEFF/2-1 downto 0);
    signal dly_dsp_d                        : std_logic_data(NUM_COEFF/2-1 downto 0);

    signal dsp_a_in                         : std_logic_data(NUM_COEFF/2-1 downto 0);
    signal dsp_b_in                         : std_logic_array18(NUM_COEFF/2-1 downto 0);
    signal dsp_d_in                         : std_logic_data(NUM_COEFF/2-1 downto 0);

    signal dsp_pcout                        : std_logic_array48(NUM_COEFF/2-1 downto 0);
    signal dsp_p                            : std_logic_array48(NUM_COEFF/2-1 downto 0);

    signal dsp_p_round                      : std_logic_vector(48-1 downto 0);
    signal lpf_frame                        : std_logic_vector(DLY_CNT-1 downto 0);

begin

    process(i_clk_307)
    begin
        if (rising_edge(i_clk_307)) then
            lpf_frame                           <=  lpf_frame(DLY_CNT-2 downto 0) & i_upsample_rearrange_frame;
        end if;
    end process;

    -- process(i_clk_307)
    -- begin
    --     if (rising_edge(i_clk_307)) then
    --         data_delay                          <=  data_delay(NUM_COEFF*4+(NUM_COEFF/2)-2 downto 0) & i_upsample_rearrange_data;
    --     end if;
    -- end process;

    GEN_TAP_OREDER : for i in 0 to NUM_COEFF/2-1 generate
        DDC_0 : if (DDUC_TYPE = "DDC") generate
            dsp_b_in(i)                             <=  b"00" & conv_std_logic_vector(LPF_DDC_COEFF(NUM_COEFF/2-1-i),16);
        end generate;

        DUC_0 : if (DDUC_TYPE = "DUC") generate
            dsp_b_in(i)                             <=  conv_std_logic_vector(LPF_DUC_COEFF(NUM_COEFF/2-1-i),18);
        end generate;

        -- process(i_clk_307)
        -- begin
        --     if (rising_edge(i_clk_307)) then
        --         dsp_a_in(i)                 <=  data_delay(((NUM_COEFF/2)*4)-(3*i)-4);
        --         dsp_d_in(i)                 <=  data_delay((((NUM_COEFF/2)*4))+(5*i));
        --     end if;
        -- end process;

        u_delay_chain_A : dduc_delay_chain
            generic map(
                BUFF_DEPTH                      =>  ((NUM_COEFF/2)*4)-((3*i)+4)+1,              --: natural:= 16;         -- SRL16E
                DIRECTION                       =>  0,                                          --: natural:= 1;          -- 1:forward, 0:reverse
                WIDTH_IN                        =>  16                                          --: natural:= 16          -- Input data width
            )
            port map(
                CLK                             =>  i_clk_307,                                  --: in  std_logic;
                DATA_SEL                        =>  conv_std_logic_vector(((NUM_COEFF/2)*4)-((3*i)+4),log2(((NUM_COEFF/2)*4)-((3*i)+4)+1)),   --: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
                VALID_I                         =>  '1',                                        --: in  std_logic;
                FILTER_IN                       =>  i_upsample_rearrange_data,                  --: in  std_logic_vector(WIDTH_IN-1 downto 0);
                FILTER_OUT                      =>  dly_dsp_a(i)                                --: out std_logic_vector(WIDTH_IN-1 downto 0)
            );
        
        u_delay_chain_D : dduc_delay_chain
            generic map(
                BUFF_DEPTH                      =>  (((NUM_COEFF/2)*4))+(5*i)+1,                --: natural:= 16;         -- SRL16E
                DIRECTION                       =>  0,                                          --: natural:= 1;          -- 1:forward, 0:reverse
                WIDTH_IN                        =>  16                                          --: natural:= 16          -- Input data width
            )
            port map(
                CLK                             =>  i_clk_307,                                  --: in  std_logic;
                DATA_SEL                        =>  conv_std_logic_vector((((NUM_COEFF/2)*4))+(5*i),log2((((NUM_COEFF/2)*4))+(5*i)+1)),   --: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
                VALID_I                         =>  '1',                                        --: in  std_logic;
                FILTER_IN                       =>  i_upsample_rearrange_data,                  --: in  std_logic_vector(WIDTH_IN-1 downto 0);
                FILTER_OUT                      =>  dly_dsp_d(i)                                --: out std_logic_vector(WIDTH_IN-1 downto 0)
            );
    end generate GEN_TAP_OREDER;

    process(i_clk_307)
    begin
        if (rising_edge(i_clk_307)) then
            dsp_a_in                            <=  dly_dsp_a;
            dsp_d_in                            <=  dly_dsp_d;
        end if;
    end process;


    DDC_1 : if (DDUC_TYPE = "DDC") generate
        -- latency 4 clk
        lpf_1st : lib_adder_multi_c_pcin_dsp2 generic map(DATA_WIDTH,DATA_WIDTH,16,48,48,'0',"DIRECT","DIRECT",'0','0')
        port map(i_clk_307,dsp_a_in(0),dsp_d_in(0),dsp_b_in(0)(15 downto 0),(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),open,open,dsp_pcout(0),open);

        lpf_nth : for i in 1 to NUM_COEFF/2-1 generate	
            gen : lib_adder_multi_c_pcin_dsp2 generic map(DATA_WIDTH,DATA_WIDTH,16,48,48,'1',"DIRECT","DIRECT",'0','0')
            port map(i_clk_307,dsp_a_in(i),dsp_d_in(i),dsp_b_in(i)(15 downto 0),(others=>'0'),(others=>'0'),(others=>'0'),dsp_pcout(i-1),open,open,dsp_pcout(i),dsp_p(i));		
        end generate;
    end generate;

    DUC_1 : if (DDUC_TYPE = "DUC") generate
        -- latency 4 clk
        lpf_1st : lib_adder_multi_c_pcin_dsp2 generic map(DATA_WIDTH,DATA_WIDTH,18,48,48,'0',"DIRECT","DIRECT",'0','0')
        port map(i_clk_307,dsp_a_in(0),dsp_d_in(0),dsp_b_in(0),(others=>'0'),(others=>'0'),(others=>'0'),(others=>'0'),open,open,dsp_pcout(0),open);

        lpf_nth : for i in 1 to NUM_COEFF/2-1 generate	
            gen : lib_adder_multi_c_pcin_dsp2 generic map(DATA_WIDTH,DATA_WIDTH,18,48,48,'1',"DIRECT","DIRECT",'0','0')
            port map(i_clk_307,dsp_a_in(i),dsp_d_in(i),dsp_b_in(i),(others=>'0'),(others=>'0'),(others=>'0'),dsp_pcout(i-1),open,open,dsp_pcout(i),dsp_p(i));		
        end generate;
    end generate;

    -- ROUND up
    -- 1 clk
    process(i_clk_307)
    begin
        if (rising_edge(i_clk_307)) then
            if ((dsp_p(NUM_COEFF/2-1)(DATA_WIDTH+BINARY_POINT) = '1') and (dsp_p(NUM_COEFF/2-1)(BINARY_POINT downto 0) = ROUND(BINARY_POINT downto 0))) then
                dsp_p_round                 <=  dsp_p(NUM_COEFF/2-1);
             else
                dsp_p_round                 <=  dsp_p(NUM_COEFF/2-1) + ROUND;
            end if;
        end if;
    end process;

    -- 1 clk
    process(i_clk_307)
    begin
        if (rising_edge(i_clk_307)) then
            o_lpf_frame                     <=  lpf_frame(DLY_CNT-1);
            o_lpf_valid                     <=  '1';
            o_lpf_data                      <=  dsp_p_round(DATA_WIDTH+BINARY_POINT downto BINARY_POINT+1);
        end if;
    end process;
    
end Behavioral;
