-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2023, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2023.11.14 v1.0] Initial release
-- *****************************************************************************

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

entity upsamplex5_rearrange is
    generic (
        DATA_WIDTH                          : integer := 16
    );
    Port (
        i_clk_307                           : in std_logic;
        
        -- 15.36MHz
        i_cdc_15_36_frame                   : in std_logic;
        i_cdc_15_36_valid                   : in std_logic;
        i_cdc_15_36_data                    : in std_logic_vector(DATA_WIDTH-1 downto 0);

        -- 76.8MHz
        o_76_8_rearrange_frame              : out std_logic;
        o_76_8_rearrange_valid              : out std_logic;
        o_76_8_rearrange_data_i             : out std_logic_vector(DATA_WIDTH-1 downto 0);
        o_76_8_rearrange_data_q             : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end upsamplex5_rearrange;

architecture Behavioral of upsamplex5_rearrange is

    signal i_cdc_15_36_valid_d              : std_logic;
    signal i_array_wt_data                  : std_logic_vector(DATA_WIDTH+1-1 downto 0);
    
    type std_logic_data                     is array(natural range <>) of std_logic_vector(DATA_WIDTH+1-1 downto 0);
    signal data_array                       : std_logic_data(4-1 downto 0) := (others=>(others=>'0'));

    signal wt_cnt4                          : std_logic_vector(2-1 downto 0);
    signal rd_cnt4                          : std_logic_vector(2-1 downto 0);
    signal rd_flag_reg                      : std_logic_vector(3-1 downto 0);

    signal rd_data                          : std_logic_vector(DATA_WIDTH+1-1 downto 0) := (others=>'0');
    signal rd_data_1d                       : std_logic_vector(DATA_WIDTH+1-1 downto 0) := (others=>'0');
    
    signal rd_data_q                        : std_logic_vector(DATA_WIDTH+1-1 downto 0) := (others=>'0');
    signal rd_data_1d_q                     : std_logic_vector(DATA_WIDTH+1-1 downto 0) := (others=>'0');

    signal frame_cnt4                       : std_logic_vector(2-1 downto 0) := (others=>'0');
    signal frame_cnt2                       : std_logic_vector(1-1 downto 0) := (others=>'0');
    
    -- test
    signal test_cnt4                        : std_logic_vector(2-1 downto 0);
    signal test_data                        : std_logic_vector(DATA_WIDTH-1 downto 0) := (others=>'0');

begin

    process(i_clk_307)
    begin
        if (rising_edge(i_clk_307)) then
            i_cdc_15_36_valid_d             <=  i_cdc_15_36_valid;
            i_array_wt_data                 <=  i_cdc_15_36_frame & i_cdc_15_36_data;

            if (i_cdc_15_36_frame = '1') then
                wt_cnt4                     <=  (others=>'0');
            elsif (i_cdc_15_36_valid = '1') then
                wt_cnt4                     <=  wt_cnt4 + '1';
            else
                wt_cnt4                     <=  wt_cnt4;
            end if;
        end if;
    end process;

    process(i_clk_307)
    begin
        if (rising_edge(i_clk_307)) then
            if (i_cdc_15_36_valid_d = '1') then
                case (wt_cnt4) is
                    when b"00"  => data_array(0)    <=  i_array_wt_data;
                    when b"01"  => data_array(1)    <=  i_array_wt_data;
                    when b"10"  => data_array(2)    <=  i_array_wt_data;
                    when others => data_array(3)    <=  i_array_wt_data;
                end case;
            end if;
        end if;
    end process;

    process(i_clk_307)
    begin
        if (rising_edge(i_clk_307)) then
            if (i_cdc_15_36_valid_d = '1' and wt_cnt4 = b"11") then
                rd_cnt4                     <=  (others=>'0');
                rd_flag_reg(0)              <=  '1';
            elsif (rd_cnt4 = b"01") then
                rd_cnt4                     <=  rd_cnt4;
                rd_flag_reg(0)              <=  '0';
            else
                rd_cnt4                     <=  rd_cnt4 + '1';
                rd_flag_reg(0)              <=  rd_flag_reg(0);
            end if;
            rd_flag_reg(2 downto 1)         <=  rd_flag_reg(1 downto 0);
        end if;
    end process;

    process(i_clk_307)
    begin
        if (rising_edge(i_clk_307)) then
            case (rd_cnt4) is
                when b"00"  => rd_data      <=  data_array(0); 
                               rd_data_q    <=  data_array(1);
                when b"01"  => rd_data      <=  data_array(2);
                               rd_data_q    <=  data_array(3);
                when b"10"  => rd_data      <=  data_array(2);
                when others => rd_data      <=  data_array(3);
            end case;
        end if;
    end process;

    process(i_clk_307)
    begin
        if (rising_edge(i_clk_307)) then
            rd_data_1d                      <=  rd_data;
            rd_data_1d_q                    <=  rd_data_q;
            if (rd_data(DATA_WIDTH+1-1) = '1') then
                frame_cnt2                  <=  (others=>'0');
            else
                frame_cnt2                  <=  frame_cnt2 + '1';
            end if;

            if (frame_cnt2 = 0) then
                o_76_8_rearrange_frame      <=  '1';
            else
                o_76_8_rearrange_frame      <=  '0';
            end if;

            o_76_8_rearrange_valid          <=  '1';
        end if;
    end process;

    process(i_clk_307)
    begin
        if (rising_edge(i_clk_307)) then
            if (rd_flag_reg(2) = '1') then
                o_76_8_rearrange_data_i     <=  rd_data_1d  (DATA_WIDTH+1-2 downto 0);
                o_76_8_rearrange_data_q     <=  rd_data_1d_q(DATA_WIDTH+1-2 downto 0);
            else
                o_76_8_rearrange_data_i     <=  (others=>'0');
                o_76_8_rearrange_data_q     <=  (others=>'0');
            end if;
        end if;
    end process;

    -- -- test ----------------------------------------------------------------------------------------------
    -- process(i_clk_307)
    -- begin
    --     if (rising_edge(i_clk_307)) then
    --         if (rd_data_1d(16) = '0' and rd_data(16) = '1') then
    --             test_cnt4                   <=  (others=>'0');
    --         else
    --             test_cnt4                   <=  test_cnt4 + '1';
    --         end if;

    --         if (test_cnt4 = b"11" and test_data = conv_std_logic_vector(4,16)) then
    --             test_data                   <=  (others=>'0');
    --         elsif (test_cnt4 = b"11") then
    --             test_data                   <=  test_data + '1';
    --         else
    --             test_data                   <=  test_data;
    --         end if;
    --     end if;
    -- end process;

    -- process(i_clk_307)
    -- begin
    --     if (rising_edge(i_clk_307)) then
    --         o_76_8_rearrange_data           <=  rd_data_1d(DATA_WIDTH+1-2 downto 0) + test_data;
    --     end if;
    -- end process;

end Behavioral;

 
 
  