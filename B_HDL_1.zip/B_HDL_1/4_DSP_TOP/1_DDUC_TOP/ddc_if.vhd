------------------------------------------------------------------
-- channel swap
------------------------------------------------------------------
-- 2013.11.01, vyacheslav : 1st release, system verilog
-- 2014.01.29, wj311.kim  : convert system_verilog to vhdl
------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity ddc_if is
generic(
    CHANNEL_NUMBERS             : natural:= 4;
    WIDTH_IN                    : natural:= 16
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    DDC_SYNC                    : out std_logic;
    DDC_OUT                     : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end ddc_if;

architecture Behavioral of ddc_if is

component dduc_bram
generic(
    BUFF_DEPTH                  : natural:= 16;
    WIDTH_IN                    : natural:= 16
);
port(
    CLK                         : in  std_logic;
    WE                          : in  std_logic;
    WADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    RADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_IN                     : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_OUT                    : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

component dduc_dist_ram
generic(
    BUFF_DEPTH                  : natural:= 16;
    WIDTH_IN                    : natural:= 16
);
port(
    CLK                         : in  std_logic;
    WE                          : in  std_logic;
    WADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    RADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_IN                     : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_OUT                    : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

constant BUFFER_DEPTH           : integer := CHANNEL_NUMBERS*2;-- *2 for buffering

signal valid_in_r               : std_logic;
signal filter_in_r              : std_logic_vector(WIDTH_IN-1 downto 0);
signal waddr                    : std_logic_vector(log2(BUFFER_DEPTH)-1 downto 0);
signal waddr_msb                : std_logic;
signal waddr_half               : std_logic_vector(log2(BUFFER_DEPTH)-2 downto 0);
signal raddr                    : std_logic_vector(log2(BUFFER_DEPTH)-1 downto 0);
signal raddr_msb                : std_logic;
signal raddr_half               : std_logic_vector(log2(BUFFER_DEPTH)-2 downto 0);
signal ddc_sync_r               : std_logic;
signal ddc_sync_d               : std_logic_vector(CHANNEL_NUMBERS-1 downto 0);
signal i_ddc_out                : std_logic_vector(WIDTH_IN-1 downto 0);

begin

    -- input registering
    process(RST, CLK)
    begin
        if RST = '1' then
            valid_in_r  <= '0';
            filter_in_r <= (others => '0');
        elsif rising_edge(CLK) then
            valid_in_r  <= VALID_I;
            filter_in_r <= FILTER_IN;
        end if;
    end process;

    waddr <= waddr_msb & waddr_half;
    process(RST, CLK)
    begin
        if RST = '1' then
            waddr_msb <= '0';
            waddr_half<= (others => '0');
        elsif rising_edge(CLK) then
            if FRAME_I = '1' then-- When channel start
                waddr_msb <= not waddr_msb;
                waddr_half<= (others => '0');
            elsif VALID_I = '1' then
                if waddr_half = CHANNEL_NUMBERS-1 then
                    waddr_msb <= not waddr_msb;
                    waddr_half<= (others => '0');
                else
                    waddr_half <= waddr_half + 1;
                end if;
            end if;
        end if;
    end process;

    -- read address
    raddr <= raddr_msb & raddr_half;
    process(RST, CLK)
    begin
        if RST = '1' then
            raddr_msb  <= '0';
            raddr_half <= (others => '0');
        elsif rising_edge(CLK) then
            raddr_msb  <= not waddr_msb;
            if valid_in_r = '1' and waddr_half = 0 then
                raddr_half <= (others => '0');
            elsif raddr_half = CHANNEL_NUMBERS-1 then
                raddr_half <= raddr_half;
            else
                raddr_half <= raddr_half+1;
            end if;
        end if;
    end process;

    DDC_SYNC <= ddc_sync_d(1);-- RAM delay 2 clock + 1 output register
    process(RST, CLK)
    begin
        if RST = '1' then
            ddc_sync_r  <= '0';
            ddc_sync_d  <= (others => '0');
        elsif rising_edge(CLK) then
            if raddr_half = 0 then
                ddc_sync_r  <= '1';
            else
                ddc_sync_r  <= '0';
            end if;
            ddc_sync_d  <= ddc_sync_d(ddc_sync_d'length-2 downto 0) & ddc_sync_r;
        end if;
    end process;


    process(RST, CLK)
    begin
        if RST = '1' then
            DDC_OUT  <= (others => '0');
        elsif rising_edge(CLK) then
            if ddc_sync_d = 0 then
                DDC_OUT <= (others => '0');
            else
                DDC_OUT <= i_ddc_out;
            end if;
        end if;
    end process;

    -- Distributed RAM generation (LUT Memory)
    DIST_RAM_GEN : if BUFFER_DEPTH <= 64 generate
        u_dduc_dist_ram : dduc_dist_ram
        generic map(
            BUFF_DEPTH                  => BUFFER_DEPTH                 ,--: natural:= 16;-- SRL16E
            WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;
            WE                          => valid_in_r                   ,--: in  std_logic;
            WADDR                       => waddr                        ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
            RADDR                       => raddr                        ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
            DATA_IN                     => filter_in_r                  ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
            DATA_OUT                    => i_ddc_out                     --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );
    end generate DIST_RAM_GEN;

    -- Block RAM generation (M18K or M36K or M20k)
    BLOCK_RAM_GEN : if BUFFER_DEPTH > 64 generate
        u_dduc_bram : dduc_bram
        generic map(
            BUFF_DEPTH                  => BUFFER_DEPTH                 ,--: natural:= 16;-- SRL16E
            WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;
            WE                          => valid_in_r                   ,--: in  std_logic;
            WADDR                       => waddr                        ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
            RADDR                       => raddr                        ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
            DATA_IN                     => filter_in_r                  ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
            DATA_OUT                    => i_ddc_out                     --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );
    end generate BLOCK_RAM_GEN;

end Behavioral;
