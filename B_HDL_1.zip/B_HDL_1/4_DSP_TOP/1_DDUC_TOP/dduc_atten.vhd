-------------------------------------------------------------------------------
-- program description
-- project name     : DUC/DDC core
-------------------------------------------------------------------------------
-- Organization     : Samsung
-- Created          : 2013/05/06
-------------------------------------------------------------------------------
-- Last update      : 2014/11/26
-- Revision state   : 0.1
-- Designer         : Wonjong Kim (wj311.kim@samsung.com)
-- Simulation       :
-- Synthesis        :
-- Target           : Xilinx 7 series
-------------------------------------------------------------------------------
-- Revision History
--0.1 Initial
--0.2 Pluse gain range modified (3 dB -> 36 dB)

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity dduc_atten is
generic(
    CHANNEL_NUMBERS             : natural:=4;
    DATA_WIDTH                  : natural:=16;
    GAIN_WIDTH                  : natural:=16;
    BINARY_POINT                : natural:=16
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    GAIN                        : in  std_logic_array16(CHANNEL_NUMBERS-1 downto 0);--MUST be positive always!!

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(DATA_WIDTH-1 downto 0)
);
end dduc_atten;

architecture rtl of dduc_atten is

component dduc_mult_16x17
generic(
    BINARY_POINT                : integer := 16
);
PORT(
    CLK                         : in std_logic;
    A_DATA                      : in std_logic_vector(15 downto 0);
    B_DATA                      : in std_logic_vector(16 downto 0);
    RESULT                      : out std_logic_vector(32 downto 0)
);
END component;

component round_stage is
generic(
    VAR_WIDTH                   : natural:= 5;
    FIXED_GAIN                  : natural:= 0;         --gain is fixed or not
    WIDTH_IN                    : natural:= 64;
    WIDTH_OUT                   : natural:= 32;
    BINARY_POINT                : natural:= 31;        -- DATA OUT = ROUNDING(DATA IN)/2^(BINARY_POINT+1)
    ROUNDING                    : string:= "ROUND_INF";--"FULL_PRECISION", "TRUNCATE","ROUND_INF", "ROUND_EVEN"
    OVERFLOW                    : string:= "WRAP"      --"WRAP or "SATURATE"
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    BIT_SHIFT_VALUE             : in  std_logic_vector(VAR_WIDTH-1 downto 0);

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1 downto 0)
);
end component;

constant DELAY                  : natural := 5; -- 3(multiplier) +2 (input reg) --+1 (output reg)

signal ch_cnt                   : std_logic_vector(log2(CHANNEL_NUMBERS)-1 downto 0);

signal filter_in_d              : std_logic_vector(DATA_WIDTH-1 downto 0);
signal filter_in_dd             : std_logic_vector(DATA_WIDTH-1 downto 0);
signal gain_d                   : std_logic_vector(GAIN_WIDTH downto 0);
signal mult_out                 : std_logic_vector(DATA_WIDTH+GAIN_WIDTH downto 0);

signal frame_d                  : std_logic_vector(DELAY-1 downto 0);
signal valid_d                  : std_logic_vector(DELAY-1 downto 0);


begin

CH_NUM_1_GEN : if CHANNEL_NUMBERS = 1 generate
    filter_in_dd    <= FILTER_IN;
    gain_d          <='0' & gain(0);-- always signed gain value
end generate CH_NUM_1_GEN;

CH_NUM_N_GEN : if CHANNEL_NUMBERS > 1 generate
    process(RST, CLK)
    begin
        if RST='1' then
            ch_cnt <= (others => '0');
        elsif rising_edge(CLK) then
            if FRAME_I = '1' then
                ch_cnt <= (others => '0');
            elsif VALID_I = '1' then
                if ch_cnt = CHANNEL_NUMBERS-1 then
                    ch_cnt <= (others => '0');
                else
                    ch_cnt <= ch_cnt + '1';
                end if;
            end if;
        end if;
    end process;

    -- Input data latch
    process( CLK)
    begin
        if rising_edge(CLK) then
            filter_in_d <= FILTER_IN;
            filter_in_dd<= filter_in_d;
            gain_d      <='0' & gain(conv_integer(ch_cnt));-- always signed gain value
        end if;
    end process;
end generate CH_NUM_N_GEN;

    -- Valid & channel should be aligned with data
    FRAME_O <= frame_d(DELAY-1);
    VALID_O <= valid_d(DELAY-1);
    process(CLK)
    begin
        if rising_edge(CLK) then
            frame_d <= frame_d(DELAY-2 downto 0) & FRAME_I;
            valid_d <= valid_d(DELAY-2 downto 0) & VALID_I;
        end if;
    end process;

-- 16x17 multiplier, 3 CLK delay
--    process( CLK)
--    begin
--        if rising_edge(CLK) then
            FILTER_OUT <= mult_out(16+BINARY_POINT downto BINARY_POINT+1);
--        end if;
--    end process;

u_dduc_mult_16x17 : dduc_mult_16x17
generic map(
    BINARY_POINT                => BINARY_POINT                 --: integer := 16
)
port map(
    CLK                         => CLK                          ,-- input ,:
    A_DATA                      => filter_in_dd                 ,-- input [(15 : 0);
    B_DATA                      => gain_d                       ,-- input [(16 : 0);
    RESULT                      => mult_out                      -- output[(32 : 0)
);

-- rounding, 3 CLK delay
--u_round_stage : round_stage
--generic map(
--    VAR_WIDTH                   => 0                            ,--: natural:= 5;
--    FIXED_GAIN                  => 1                            ,--: natural:= 0;         --gain is fixed or not
--    WIDTH_IN                    => 32                           ,--: natural:= 64;
--    WIDTH_OUT                   => 16                           ,--: natural:= 32;
--    BINARY_POINT                => BINARY_POINT                 ,--: natural:= 31;        -- DATA OUT = ROUNDING(DATA IN)/2^(BINARY_POINT+1)
--    ROUNDING                    => "ROUND_INF"                  ,--: string:= "ROUND_INF";--"FULL_PRECISION", "TRUNCATE","ROUND_INF", "ROUND_EVEN"
--    OVERFLOW                    => "SATURATE"                    --: string:= "WRAP";     --"WRAP or "SATURATE"
--)
--port map(
--    RST                         => RST                          ,--: in  std_logic;
--    CLK                         => CLK                          ,--: in  std_logic;
--    BIT_SHIFT_VALUE             => (others => '0')              ,--: in  std_logic_vector(VAR_WIDTH-1 downto 0);
--
--    FRAME_I                     => '0'                          ,--: in  std_logic;
--    VALID_I                     => '0'                          ,--: in  std_logic;
--    FILTER_IN                   => mult_out(31 downto 0)        ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
--
--    FRAME_O                     => open                         ,--: out std_logic;
--    VALID_O                     => open                         ,--: out std_logic;
--    FILTER_OUT                  => FILTER_OUT                    --: out std_logic_vector(WIDTH_OUT-1 downto 0)
--);

end rtl;
