library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity resampler_5_4 is
generic(
    VENDOR                      : string := "XILINX";
    UP_RATE                     : integer:= 5;
    DOWN_RATE                   : integer:= 4;
    WIDTH_IN                    : integer:= 16;
    WIDTH_OUT                   : integer:= 16;
    WIDTH_COEFF                 : integer:= 16;
    BINARY_POINT                : integer:= 15;
    HOVS                        : integer:= 2;
    ORDER                       : integer:= 55
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    VALID_IN                    : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    VALID_OUT                   : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1  downto 0)
);
end resampler_5_4;

architecture rtl of resampler_5_4 is


    component dduc_dsp is
    generic(
        PCIN_EN                     : boolean := FALSE;
        D_EN                        : boolean := FALSE;
        C_EN                        : boolean := FALSE;

        WIDTH_A                     : integer := 16;
        WIDTH_D                     : integer := 16;
        WIDTH_B                     : integer := 16;
        WIDTH_C                     : integer := 16;
        WIDTH_PCIN                  : integer := 48;
        WIDTH_PCOUT                 : integer := 48;
        WIDTH_P                     : integer := 48
    );
    port(
        CLK                         : in  std_logic;

        SEL                         : in  std_logic;
        CEP                         : in  std_logic;
        DSP_A_INV                   : in  std_logic;

        DSP_A                       : in  std_logic_vector(WIDTH_A-1 downto 0);
        DSP_D                       : in  std_logic_vector(WIDTH_D-1 downto 0);
        DSP_B                       : in  std_logic_vector(WIDTH_B-1 downto 0);
        DSP_C                       : in  std_logic_vector(WIDTH_C-1 downto 0);

        DSP_PCIN                    : in  std_logic_vector(WIDTH_PCIN-1 downto 0);
        DSP_PCOUT                   : out std_logic_vector(WIDTH_PCOUT-1 downto 0);
        DSP_P                       : out std_logic_vector(WIDTH_P-1 downto 0)
    );
    end component;

    component dduc_delay_chain is
    generic(
        BUFF_DEPTH                  : natural:= 16;-- SRL16E
        DIRECTION                   : natural:= 1; -- 1:forward, 0:reverse
        WIDTH_IN                    : natural:= 16 -- Input data width
    );
    port(
        CLK                         : in  std_logic;
        DATA_SEL                    : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
        VALID_I                     : in  std_logic;
        FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
        FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
    );
    end component;

--LTE, 40/122.88, 30tap
--    constant COEFF                  : integer_array(ORDER-1 downto 0):= (77,229,416,466,129,-771,-2120,-3349,-3477,-1435,3412,10782,19316,26891,31355,31355,26891,19316,10782,3412,-1435,-3477,-3349,-2120,-771,129,466,416,229,77);
--LTE, 50/122.88, 40tap
    constant COEFF                  : integer_array(ORDER-1 downto 0):= (-40,-77,-90,-18,183,497,807,898,525,-449,-1907,-3393,-4150,-3321,-268,5112,12202,19722,26039,29648,29648,26039,19722,12202,5112,-268,-3321,-4150,-3393,-1907,-449,525,898,807,497,183,-18,-90,-77,-40);
--LTE, 60/122.88, 45tap
--    constant COEFF                  : integer_array(ORDER-1 downto 0):= (-25,-98,-179,-257,-248,-87,263,743,1190,1350,967,-88,-1694,-3413,-4537,-4259,-1932,2654,9105,16420,23196,27989,29720,27989,23196,16420,9105,2654,-1932,-4259,-4537,-3413,-1694,-88,967,1350,1190,743,263,-87,-248,-257,-179,-98,-25);
--LTE, 60/122.88, 36tap
--    constant COEFF                  : integer_array(ORDER-1 downto 0):= (0,0,0,0,13,111,289,546,772,778,354,-618,-2020,-3415,-4078,-3187,-121,5220,12237,19672,25917,29486,29486,25917,19672,12237,5220,-121,-3187,-4078,-3415,-2020,-618,354,778,772,546,289,111,13);
--5G, 50/153.6, 72tap
--    constant COEFF                  : integer_array(ORDER-1 downto 0):= (-33,-51,-69,-67,-33,42,148,260,337,330,204,-49,-391,-740,-977,-979,-663,-22,842,1722,2343,2423,1769,357,-1614,-3714,-5344,-5856,-4697,-1569,3461,9922,16991,23630,28787,31604,31604,28787,23630,16991,9922,3461,-1569,-4697,-5856,-5344,-3714,-1614,357,1769,2423,2343,1722,842,-22,-663,-979,-977,-740,-391,-49,204,330,337,260,148,42,-33,-67,-69,-51,-33);
--5G, 45/153.6, 48tap
--    constant COEFF                  : integer_array(ORDER-1 downto 0):= (-136,-213,-294,-294,-153,161,622,1128,1504,1540,1057,-12,-1557,-3259,-4613,-5026,-3949,-1040,3703,9881,16720,23204,28274,31056,31056,28274,23204,16720,9881,3703,-1040,-3949,-5026,-4613,-3259,-1557,-12,1057,1540,1504,1128,622,161,-153,-294,-294,-213,-136);
--LTE, 20/122.88, 25tap
--    constant COEFF                  : integer_array(ORDER-1 downto 0):= (-113,-390,-871,-1437,-1754,-1295,506,4004,9097,15097,20836,24988,26504,24988,20836,15097,9097,4004,506,-1295,-1754,-1437,-871,-390,-113);
--3/2, 70M, 30tap
--    constant COEFF                  : integer_array(ORDER-1 downto 0):= (1,-91,-284,-414,-140,679,1520,1276,-778,-3712,-4731,-830,8544,20071,28041,28041,20071,8544,-830,-4731,-3712,-778,1276,1520,679,-140,-414,-284,-91,1);


    constant DSP_INSTANCES          : integer := ORDER/UP_RATE;
    constant DSP_MAX_COEF_NUM       : integer := DOWN_RATE*HOVS;
    constant ORDER_REGEN            : integer := DSP_INSTANCES*DSP_MAX_COEF_NUM;
    constant VDSP                   : integer := 4;-- DSP Valid latency(3) + DSP48 in register(2) - 1 (for DSP input registering)
    constant PROC_DELAY             : integer := DSP_INSTANCES+3;--+3 for input delay
    constant WIDTH_DSP              : integer := 48;
    constant WIDTH_BINARY           : integer := BINARY_POINT+2;-- +1 for signed bit


    type data_array                 is array(natural range <>) of std_logic_vector(WIDTH_IN-1 downto 0);
    type coef_array                 is array(natural range <>) of std_logic_vector(WIDTH_COEFF-1 downto 0);
    type chain_array                is array(natural range <>) of std_logic_vector(WIDTH_DSP-1 downto 0);
    type binary_array               is array(natural range <>) of std_logic_vector(WIDTH_BINARY-1 downto 0);
    type dsp_coef_array             is array(natural range <>) of integer_array(DSP_MAX_COEF_NUM-1 downto 0);
    type dsp_coef_sel_array         is array(natural range <>) of std_logic_vector(log2(DSP_MAX_COEF_NUM)-1 downto 0);


    signal valid_in_d               : std_logic;
    signal down_cnt                 : std_logic_vector(log2(DOWN_RATE)-1 downto 0);

    signal delay_data               : data_array(DSP_INSTANCES-1 downto 0);
    signal coef_sel                 : dsp_coef_sel_array(DSP_INSTANCES-1 downto 0);
    signal dsp_a                    : data_array(DSP_INSTANCES-1 downto 0);
    signal dsp_d                    : data_array(DSP_INSTANCES-1 downto 0);
    signal dsp_b                    : coef_array(DSP_INSTANCES-1 downto 0);
    signal dsp_c                    : binary_array(DSP_INSTANCES-1 downto 0);
    signal dsp_pcin                 : chain_array(DSP_INSTANCES-1 downto 0);
    signal dsp_pcout                : chain_array(DSP_INSTANCES-1 downto 0);
    signal dsp_p                    : chain_array(DSP_INSTANCES-1 downto 0);

    signal filter_in_d              : std_logic_vector(WIDTH_IN-1 downto 0);
    signal valid_out_r              : std_logic;
    signal valid_out_d              : std_logic_vector(PROC_DELAY-1 downto 0);


    -- Coefficient mapping function for DSP internal coefficient rom data
    function coeff_init return dsp_coef_array is
        variable result : dsp_coef_array(DSP_INSTANCES-1 downto 0);
    begin
        M_LOOP : for M in 0 to DSP_INSTANCES-1 loop
            N_LOOP : for N in 0 to DSP_MAX_COEF_NUM-1 loop
                if N < HOVS then
                    result(M)(N) :=  COEFF(UP_RATE*M+DOWN_RATE*N);
                elsif N >= HOVS and (N mod HOVS = 0) then
                    result(M)(N) :=  COEFF(UP_RATE*M+DOWN_RATE-(N/HOVS));
                else
                    result(M)(N) :=  0;
                end if;
            end loop;
        end loop;
        return result;
    end function coeff_init;

    constant COEFF_REGEN            : dsp_coef_array(DSP_INSTANCES-1 downto 0) := coeff_init;


begin

    -- input sync
    process(CLK,RST)
    begin
        if RST='1' then
            valid_in_d <= '0';
        elsif CLK'event and CLK='1' then
            if VALID_IN = '1' then
                valid_in_d <= '0';
            else
                valid_in_d <= not valid_in_d;-- always toggle, even when VALID_IN has no driver
            end if;
        end if;
    end process;

    -- input data latch
    process(CLK,RST)
    begin
        if RST='1' then
            filter_in_d <= (others => '0');
        elsif CLK'event and CLK='1' then
            if valid_in_d = '1' then
                filter_in_d <= FILTER_IN;
            end if;
        end if;
    end process;

    -- downsample counter
    process(CLK,RST)
    begin
        if RST='1' then
            down_cnt <= (others => '0');
        elsif CLK'event and CLK='1' then
            if valid_in_d = '1' then
                if down_cnt = DOWN_RATE-1 then
                    down_cnt <= (others => '0');
                else
                    down_cnt <= down_cnt + '1';
                end if;
            end if;
        end if;
    end process;

DSP_BLOCK_GEN : for N in 0 to DSP_INSTANCES-1  generate
    DSP_GEN_0 : if N = 0 generate
        delay_data(N) <= filter_in_d;
        dsp_d(N)      <= (others => '0');
        coef_sel(N)   <= down_cnt & valid_in_d;
        process(CLK)
        begin
            if CLK'event and CLK='1' then
                dsp_a(N)    <= filter_in_d;
                dsp_b(N)    <= sign_extension(COEFF_REGEN(N)(conv_integer(coef_sel(N))), WIDTH_COEFF);
            end if;
        end process;
        dsp_c(N)    <= sign_extension(2**(BINARY_POINT)-1, WIDTH_BINARY);
        dsp_pcin(N) <= (others => '0');
    end generate DSP_GEN_0;

    DSP_GEN_N : if N > 0 and N <= DSP_INSTANCES-1 generate
        u_delay_data : dduc_delay_chain
        generic map(
            BUFF_DEPTH                  => 3                            ,--: natural:= 16;-- SRL16E
            DIRECTION                   => 0                            ,--: natural:= 1: -- 1:forward, 0:reverse
            WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;
            DATA_SEL                    => std_logic_vector(to_unsigned(3-1, log2(3))),
            VALID_I                     => '1'                          ,--: in  std_logic;
            FILTER_IN                   => delay_data(N-1)              ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
            FILTER_OUT                  => delay_data(N)                 --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );
        dsp_d(N)    <= (others => '0');
        process(CLK)
        begin
            if CLK'event and CLK='1' then
                dsp_a(N)    <= delay_data(N);
                coef_sel(N) <= coef_sel(N-1);
                dsp_b(N)    <= sign_extension(COEFF_REGEN(N)(conv_integer(coef_sel(N))), WIDTH_COEFF);
            end if;
        end process;
        dsp_c(N)    <= (others => '0');
        dsp_pcin(N) <= dsp_pcout(N-1);
    end generate DSP_GEN_N;

    u_dduc_dsp : dduc_dsp
    generic map(
        PCIN_EN                     => ternary_func(N=0,FALSE,TRUE) ,--: boolean := FALSE;
        D_EN                        => FALSE                        ,--: boolean := FALSE;
        C_EN                        => ternary_func(N=0,TRUE,FALSE) ,--: boolean := FALSE;
        WIDTH_A                     => WIDTH_IN                     ,--: integer := 16;
        WIDTH_D                     => WIDTH_IN                     ,--: integer := 16;
        WIDTH_B                     => WIDTH_COEFF                  ,--: integer := 16;
        WIDTH_C                     => WIDTH_BINARY                 ,--: integer := 16;
        WIDTH_PCIN                  => WIDTH_DSP                    ,--: integer := 48;
        WIDTH_PCOUT                 => WIDTH_DSP                    ,--: integer := 48;
        WIDTH_P                     => WIDTH_DSP                     --: integer := 48
    )
    port map(
        CLK                         => CLK                          ,--: in  std_logic;

        SEL                         => '0'                          ,--: in  std_logic;
        CEP                         => '1'                          ,--: in  std_logic;
        DSP_A_INV                   => '0'                          ,--: in  std_logic;

        DSP_A                       => dsp_a(N)                     ,--: in  std_logic_vector(WIDTH_A-1 downto 0);
        DSP_D                       => dsp_d(N)                     ,--: in  std_logic_vector(WIDTH_D-1 downto 0);
        DSP_B                       => dsp_b(N)                     ,--: in  std_logic_vector(WIDTH_B-1 downto 0);
        DSP_C                       => dsp_c(N)                     ,--: in  std_logic_vector(WIDTH_C-1 downto 0);

        DSP_PCIN                    => dsp_pcin(N)                  ,--: in  std_logic_vector(WIDTH_PCIN-1 downto 0);
        DSP_PCOUT                   => dsp_pcout(N)                 ,--: out std_logic_vector(WIDTH_PCOUT-1 downto 0);
        DSP_P                       => dsp_p(N)                      --: out std_logic_vector(WIDTH_P-1 downto 0)
    );
end generate DSP_BLOCK_GEN;

    -- output valid
    process(CLK,RST)
    begin
        if RST='1' then
            valid_out_r <= '0';
            valid_out_d <= (others => '0');
        elsif CLK'event and CLK='1' then
            if valid_in_d = '0' or down_cnt = 0 then
                valid_out_r <= '1';
            else
                valid_out_r <= '0';
            end if;
            valid_out_d <= valid_out_d(valid_out_d'length-2 downto 0) & valid_out_r;
        end if;
    end process;

    VALID_OUT  <= valid_out_d(valid_out_d'high);
    FILTER_OUT <= dsp_p(DSP_INSTANCES-1)(WIDTH_OUT+BINARY_POINT downto BINARY_POINT+1);


end rtl;


