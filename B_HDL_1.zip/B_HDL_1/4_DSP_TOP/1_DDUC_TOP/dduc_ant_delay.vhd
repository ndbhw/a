--DDUC ant delay
--Operating clock : 245.76MHz
--Sampling rate   : 122.88Msps
--Resolution      : 122.88Msps
--Max depth       : 512
--DELAY value     : 4-512


library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity dduc_ant_delay is
generic(
    DATA_WIDTH                  : integer:=  16;--fixed
    BUF_DEPTH                   : integer:= 512;--fixed
    BUF_RES                     : integer:=   1 --fixed
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    DELAY                       : in  std_logic_vector(log2(BUF_DEPTH)-1 downto 0);
    I_IN                        : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    Q_IN                        : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    I_OUT                       : out std_logic_vector(DATA_WIDTH-1 downto 0);
    Q_OUT                       : out std_logic_vector(DATA_WIDTH-1 downto 0)
);
end dduc_ant_delay;

architecture Behavioral of dduc_ant_delay is

component dduc_bram is
generic(
    BUFF_DEPTH                  : integer;
    WIDTH_IN                    : integer
);
port(
    CLK                         : in  std_logic;
    WE                          : in  std_logic;
    WADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    RADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_IN                     : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_OUT                    : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

    signal waddr                    : std_logic_vector(log2(BUF_DEPTH*BUF_RES)-1 downto 0):=(others=>'0');
    signal delay_r                  : std_logic_vector(log2(BUF_DEPTH)-1 downto 0);
    signal raddr                    : std_logic_vector(log2(BUF_DEPTH*BUF_RES)-1 downto 0);
    signal zeros                    : std_logic_vector(log2(BUF_RES)-1 downto 0):=(others=>'0');

begin

    process(CLK)
    begin
        if CLK'event and CLK='1' then
            if RST='1' then
                waddr <= (others=>'0');
--            elsif waddr=BUF_DEPTH-1 then
--                waddr <= (others=>'0');
            else
                waddr <= waddr + '1';
            end if;
        end if;
    end process;

    process(CLK)
    begin
        if CLK'event and CLK='1' then
            if DELAY<=4 then
                delay_r <= conv_std_logic_vector(4,log2(BUF_DEPTH));
--            elsif DELAY>=BUF_DEPTH-1 then
--                delay_r <= conv_std_logic_vector(BUF_DEPTH-1,log2(BUF_DEPTH));
            else
                delay_r <= DELAY;
            end if;

            if RST='1' then
                raddr <= conv_std_logic_vector(BUF_DEPTH/2-1,log2(BUF_DEPTH*BUF_RES));
            elsif (BUF_RES=1 and waddr = delay_r-"11") then--or (BUF_RES/=1 and waddr = (delay_r & zeros)-'1') then
                raddr <= (others=>'0');
            else
                raddr <= raddr + '1';
            end if;
        end if;
    end process;

    u_dduc_bram : dduc_bram
    generic map(
        BUFF_DEPTH                  => BUF_DEPTH                        ,--: integer := 1024;
        WIDTH_IN                    => DATA_WIDTH*2                      --: integer := 16
    )
    port map(
        CLK                         => CLK                              ,--: in  std_logic;
        WE                          => '1'                              ,--: in  std_logic;
        WADDR                       => waddr(log2(512*1)-1 downto log2(1)),--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
        RADDR                       => raddr(log2(512*1)-1 downto log2(1)),--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
        DATA_IN(31 downto 16)       => I_IN                             ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
        DATA_IN(15 downto 0)        => Q_IN                             ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
        DATA_OUT(31 downto 16)      => I_OUT                            ,--: out std_logic_vector(WIDTH_IN-1 downto 0)
        DATA_OUT(15 downto 0)       => Q_OUT                             --: out std_logic_vector(WIDTH_IN-1 downto 0)
    );

end Behavioral;
