library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

Library UNISIM;
use UNISIM.vcomponents.all;

entity dduc_cmult_h1_q is
port(
    CLK                         : in std_logic;
    SINE_CONJUGATE              : in std_logic;
    A_DATA                      : in std_logic_vector(15 downto 0);
    B_DATA                      : in std_logic_vector(15 downto 0);
    C_DATA                      : in std_logic_vector(31 downto 0);
    D_DATA                      : in std_logic_vector(15 downto 0);
    RESULT                      : out std_logic_vector(32 downto 0)
);
end dduc_cmult_h1_q;

architecture Behavioral of dduc_cmult_h1_q is

constant A_INT_WIDTH            : integer := 30;
constant D_INT_WIDTH            : integer := 27;
constant B_INT_WIDTH            : integer := 18;
constant C_INT_WIDTH            : integer := 48;
constant P_INT_WIDTH            : integer := 48;

constant ALUMODE                : std_logic_vector(3 downto 0) := "0011"; -- for Z-(X+Y+CIN)
constant ZERO                   : std_logic_vector(P_INT_WIDTH-1 downto 0):= (others => '0');

constant INMODE0                : std_logic := '1';-- for D-A1
constant INMODE1                : std_logic := '0';-- for D-A1
constant INMODE2                : std_logic := '1';-- for D-A1
--constant INMODE3                : std_logic := SINE_CONJUGATE;-- for D-A1
constant INMODE4                : std_logic := '0';-- multiplier B port, '0' : B2, '1' : B1

constant OPMODE0                : std_logic := '1';-- for X Multiplexer output to be M
constant OPMODE1                : std_logic := '0';-- for X Multiplexer output to be M
constant OPMODE2                : std_logic := '1';-- for Y Multiplexer output to be M
constant OPMODE3                : std_logic := '0';-- for Y Multiplexer output to be M
constant OPMODE4                : std_logic := '1';-- for Z Multiplexer output to be C
constant OPMODE5                : std_logic := '1';-- for Z Multiplexer output to be C
constant OPMODE6                : std_logic := '0';-- for Z Multiplexer output to be C
constant OPMODE7                : std_logic := '0';-- for Z Multiplexer output to be C
constant OPMODE8                : std_logic := '0';-- for Z Multiplexer output to be C

signal INMODE                   : std_logic_vector(4 downto 0);
signal OPMODE                   : std_logic_vector(8 downto 0);

signal PCOUT                    : std_logic_vector(P_INT_WIDTH-1 downto 0);
signal P                        : std_logic_vector(P_INT_WIDTH-1 downto 0);
signal PCIN                     : std_logic_vector(P_INT_WIDTH-1 downto 0);
signal A                        : std_logic_vector(A_INT_WIDTH-1 downto 0);
signal B                        : std_logic_vector(B_INT_WIDTH-1 downto 0);
signal C                        : std_logic_vector(P_INT_WIDTH-1 downto 0);
signal D                        : std_logic_vector(D_INT_WIDTH-1 downto 0);

begin

PCIN        <= ZERO; -- 48-bit input: P cascade input

A           <= sign_extension(A_DATA, A_INT_WIDTH);
D           <= sign_extension(D_DATA, D_INT_WIDTH);
B           <= sign_extension(B_DATA, B_INT_WIDTH);
C           <= sign_extension(C_DATA, C_INT_WIDTH);
RESULT      <= P(32 downto 0);

INMODE      <= INMODE4
             & SINE_CONJUGATE--INMODE3
             & INMODE2
             & INMODE1
             & INMODE0;

OPMODE      <= OPMODE8
             & OPMODE7
             & OPMODE6
             & OPMODE5
             & OPMODE4
             & OPMODE3
             & OPMODE2
             & OPMODE1
             & OPMODE0;

   -- DSP48E2: 48-bit Multi-Functional Arithmetic Block
   --          Kintex UltraScale+
   -- Xilinx HDL Language Template, version 2016.1
   DSP48E2_inst : DSP48E2
   generic map (
      -- Feature Control Attributes: Data Path Selection
      AMULTSEL => "AD",                  -- Selects A input to multiplier (A, AD)
      A_INPUT => "DIRECT",               -- Selects A input source, "DIRECT" (A port) or "CASCADE" (ACIN port)
      BMULTSEL => "B",                   -- Selects B input to multiplier (AD, B)
      B_INPUT => "DIRECT",               -- Selects B input source, "DIRECT" (B port) or "CASCADE" (BCIN port)
      PREADDINSEL => "A",                -- Selects input to pre-adder (A, B)
      RND => X"000000000000",            -- Rounding Constant
      USE_MULT => "MULTIPLY",            -- Select multiplier usage (DYNAMIC, MULTIPLY, NONE)
      USE_SIMD => "ONE48",               -- SIMD selection (FOUR12, ONE48, TWO24)
      USE_WIDEXOR => "FALSE",            -- Use the Wide XOR function (FALSE, TRUE)
      XORSIMD => "XOR24_48_96",          -- Mode of operation for the Wide XOR (XOR12, XOR24_48_96)
      -- Pattern Detector Attributes: Pattern Detection Configuration
      AUTORESET_PATDET => "NO_RESET",    -- NO_RESET, RESET_MATCH, RESET_NOT_MATCH
      AUTORESET_PRIORITY => "RESET",     -- Priority of AUTORESET vs. CEP (CEP, RESET).
      MASK => X"3fffffffffff",           -- 48-bit mask value for pattern detect (1=ignore)
      PATTERN => X"000000000000",        -- 48-bit pattern match for pattern detect
      SEL_MASK => "MASK",                -- C, MASK, ROUNDING_MODE1, ROUNDING_MODE2
      SEL_PATTERN => "PATTERN",          -- Select pattern value (C, PATTERN)
      USE_PATTERN_DETECT => "NO_PATDET", -- Enable pattern detect (NO_PATDET, PATDET)
      -- Programmable Inversion Attributes: Specifies built-in programmable inversion on specific pins
      IS_ALUMODE_INVERTED => "0000",     -- Optional inversion for ALUMODE
      IS_CARRYIN_INVERTED => '0',        -- Optional inversion for CARRYIN
      IS_CLK_INVERTED => '0',            -- Optional inversion for CLK
      IS_INMODE_INVERTED => "00000",     -- Optional inversion for INMODE
      IS_OPMODE_INVERTED => "000000000", -- Optional inversion for OPMODE
      IS_RSTALLCARRYIN_INVERTED => '0',  -- Optional inversion for RSTALLCARRYIN
      IS_RSTALUMODE_INVERTED => '0',     -- Optional inversion for RSTALUMODE
      IS_RSTA_INVERTED => '0',           -- Optional inversion for RSTA
      IS_RSTB_INVERTED => '0',           -- Optional inversion for RSTB
      IS_RSTCTRL_INVERTED => '0',        -- Optional inversion for RSTCTRL
      IS_RSTC_INVERTED => '0',           -- Optional inversion for RSTC
      IS_RSTD_INVERTED => '0',           -- Optional inversion for RSTD
      IS_RSTINMODE_INVERTED => '0',      -- Optional inversion for RSTINMODE
      IS_RSTM_INVERTED => '0',           -- Optional inversion for RSTM
      IS_RSTP_INVERTED => '0',           -- Optional inversion for RSTP
      -- Register Control Attributes: Pipeline Register Configuration
      ACASCREG => 1,                     -- Number of pipeline stages between A/ACIN and ACOUT (0-2)
      ADREG => 1,                        -- Pipeline stages for pre-adder (0-1)
      ALUMODEREG => 1,                   -- Pipeline stages for ALUMODE (0-1)
      AREG => 1,                         -- Pipeline stages for A (0-2)
      BCASCREG => 2,                     -- Number of pipeline stages between B/BCIN and BCOUT (0-2)
      BREG => 2,                         -- Pipeline stages for B (0-2)
      CARRYINREG => 1,                   -- Pipeline stages for CARRYIN (0-1)
      CARRYINSELREG => 1,                -- Pipeline stages for CARRYINSEL (0-1)
      CREG => 1,                         -- Pipeline stages for C (0-1)
      DREG => 1,                         -- Pipeline stages for D (0-1)
      INMODEREG => 1,                    -- Pipeline stages for INMODE (0-1)
      MREG => 1,                         -- Multiplier pipeline stages (0-1)
      OPMODEREG => 1,                    -- Pipeline stages for OPMODE (0-1)
      PREG => 1                          -- Number of pipeline stages for P (0-1)
   )
   port map (
      -- Cascade outputs: Cascade Ports
      ACOUT => open,                    -- 30-bit output: A port cascade
      BCOUT => open,                    -- 18-bit output: B cascade
      CARRYCASCOUT => open,             -- 1-bit output: Cascade carry
      MULTSIGNOUT => open,              -- 1-bit output: Multiplier sign cascade
      PCOUT => PCOUT,                   -- 48-bit output: Cascade output
      -- Control outputs: Control Inputs/Status Bits
      OVERFLOW => open,                 -- 1-bit output: Overflow in add/acc
      PATTERNBDETECT => open,           -- 1-bit output: Pattern bar detect
      PATTERNDETECT => open,            -- 1-bit output: Pattern detect
      UNDERFLOW => open,                -- 1-bit output: Underflow in add/acc
      -- Data outputs: Data Ports
      CARRYOUT => open,                 -- 4-bit output: Carry
      P => P,                           -- 48-bit output: Primary data
      XOROUT => open,                   -- 8-bit output: XOR data
      -- Cascade inputs: Cascade Ports
      ACIN => (others => '0'),          -- 30-bit input: A cascade data
      BCIN => (others => '0'),          -- 18-bit input: B cascade
      CARRYCASCIN => '0',               -- 1-bit input: Cascade carry
      MULTSIGNIN => '0',                -- 1-bit input: Multiplier sign cascade
      PCIN => PCIN,                     -- 48-bit input: P cascade
      -- Control inputs: Control Inputs/Status Bits
      ALUMODE => ALUMODE,               -- 4-bit input: ALU control
      CARRYINSEL => (others => '0'),    -- 3-bit input: Carry select
      CLK => CLK,                       -- 1-bit input: Clock
      INMODE => INMODE,                 -- 5-bit input: INMODE control
      OPMODE => OPMODE,                 -- 9-bit input: Operation mode
      -- Data inputs: Data Ports
      A => A,                           -- 30-bit input: A data
      B => B,                           -- 18-bit input: B data
      C => C,                           -- 48-bit input: C data
      CARRYIN => '0',                   -- 1-bit input: Carry-in
      D => D,                           -- 27-bit input: D data
      -- Reset/Clock Enable inputs: Reset/Clock Enable Inputs
      CEA1 => '1',                      -- 1-bit input: Clock enable for 1st stage AREG
      CEA2 => '0',                      -- 1-bit input: Clock enable for 2nd stage AREG
      CEAD => '1',                      -- 1-bit input: Clock enable for ADREG
      CEALUMODE => '1',                 -- 1-bit input: Clock enable for ALUMODE
      CEB1 => '1',                      -- 1-bit input: Clock enable for 1st stage BREG
      CEB2 => '1',                      -- 1-bit input: Clock enable for 2nd stage BREG
      CEC => '1',                       -- 1-bit input: Clock enable for CREG
      CECARRYIN => '0',                 -- 1-bit input: Clock enable for CARRYINREG
      CECTRL => '1',                    -- 1-bit input: Clock enable for OPMODEREG and CARRYINSELREG
      CED => '1',                       -- 1-bit input: Clock enable for DREG
      CEINMODE => '1',                  -- 1-bit input: Clock enable for INMODEREG
      CEM => '1',                       -- 1-bit input: Clock enable for MREG
      CEP => '1',                       -- 1-bit input: Clock enable for PREG
      RSTA => '0',                      -- 1-bit input: Reset for AREG
      RSTALLCARRYIN => '1',             -- 1-bit input: Reset for CARRYINREG
      RSTALUMODE => '0',                -- 1-bit input: Reset for ALUMODEREG
      RSTB => '0',                      -- 1-bit input: Reset for BREG
      RSTC => '0',                      -- 1-bit input: Reset for CREG
      RSTCTRL => '0',                   -- 1-bit input: Reset for OPMODEREG and CARRYINSELREG
      RSTD => '0',                      -- 1-bit input: Reset for DREG and ADREG
      RSTINMODE => '0',                 -- 1-bit input: Reset for INMODEREG
      RSTM => '0',                      -- 1-bit input: Reset for MREG
      RSTP => '0'                       -- 1-bit input: Reset for PREG
   );

   -- End of DSP48E1_inst instantiation




end Behavioral;
