-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2023, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2023.11.14 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;

Library xpm;
use xpm.vcomponents.all;

entity lib_xpm_sdpram is
    generic (
        MEMORY_TYPE                     : string := "block";
        CLOCK_MODE                      : string := "independent_clock";  -- "independent_clock" or "common_clock"
        RD_LATENCY                      : integer := 2;
        WT_DATA_WIDTH                   : integer := 16;
        RD_DATA_WIDTH                   : integer := 16;
        WT_ADDR_WIDTH                   : integer := 3;
        RD_ADDR_WIDTH                   : integer := 3
    );
    Port (
        i_clk_a                         : in std_logic;
        i_clk_b                         : in std_logic;
        
        i_wt_enable                     : in std_logic;
        i_wt_addra                      : in std_logic_vector(WT_ADDR_WIDTH-1 downto 0);
        i_wt_data                       : in std_logic_vector(WT_DATA_WIDTH-1 downto 0);
        
        i_rd_addrb                      : in std_logic_vector(RD_ADDR_WIDTH-1 downto 0);
        o_rd_doutb                      : out std_logic_vector(RD_DATA_WIDTH-1 downto 0)
    );
end lib_xpm_sdpram;

architecture Behavioral of lib_xpm_sdpram is

    constant MEM_SIZE                   : integer := (2**(WT_ADDR_WIDTH))*WT_DATA_WIDTH;

begin

    xpm_memory_sdpram_inst : xpm_memory_sdpram
        generic map (
            ADDR_WIDTH_A                => WT_ADDR_WIDTH,           -- DECIMAL
            ADDR_WIDTH_B                => WT_ADDR_WIDTH,           -- DECIMAL
            AUTO_SLEEP_TIME             => 0,                       -- DECIMAL
            BYTE_WRITE_WIDTH_A          => WT_DATA_WIDTH,           -- DECIMAL
            CASCADE_HEIGHT              => 0,                       -- DECIMAL
            CLOCKING_MODE               => CLOCK_MODE,              -- String
            ECC_MODE                    => "no_ecc",                -- String
            MEMORY_INIT_FILE            => "none",                  -- String
            MEMORY_INIT_PARAM           => "0",                     -- String
            MEMORY_OPTIMIZATION         => "true",                  -- String
            MEMORY_PRIMITIVE            => MEMORY_TYPE,             -- String
            MEMORY_SIZE                 => MEM_SIZE,                -- DECIMAL
            MESSAGE_CONTROL             => 0,                       -- DECIMAL
            READ_DATA_WIDTH_B           => RD_DATA_WIDTH,           -- DECIMAL
            READ_LATENCY_B              => RD_LATENCY,              -- DECIMAL
            READ_RESET_VALUE_B          => "0",                     -- String
            RST_MODE_A                  => "SYNC",                  -- String
            RST_MODE_B                  => "SYNC",                  -- String
            SIM_ASSERT_CHK              => 0,                       -- DECIMAL; 0=disable simulation messages, 1=enable simulation messages
            USE_EMBEDDED_CONSTRAINT     => 0,                       -- DECIMAL
            USE_MEM_INIT                => 1,                       -- DECIMAL
            USE_MEM_INIT_MMI            => 0,                       -- DECIMAL
            WAKEUP_TIME                 => "disable_sleep",         -- String
            WRITE_DATA_WIDTH_A          => WT_DATA_WIDTH,           -- DECIMAL
            WRITE_MODE_B                => "read_first",            -- String
            WRITE_PROTECT               => 1                        -- DECIMAL
        )
        port map (
            dbiterrb                    => open,                    -- 1-bit output: Status signal to indicate double bit error occurrence
                                                                    -- on the data output of port B.

            doutb                       => o_rd_doutb,              -- READ_DATA_WIDTH_B-bit output: Data output for port B read operations.
            sbiterrb                    => open,                    -- 1-bit output: Status signal to indicate single bit error occurrence
                                                                    -- on the data output of port B.

            addra                       => i_wt_addra,              -- ADDR_WIDTH_A-bit input: Address for port A write operations.
            addrb                       => i_rd_addrb,              -- ADDR_WIDTH_B-bit input: Address for port B read operations.
            clka                        => i_clk_a,                 -- 1-bit input: Clock signal for port A. Also clocks port B when
                                                                    -- parameter CLOCKING_MODE is "common_clock".

            clkb                        => i_clk_b,                 -- 1-bit input: Clock signal for port B when parameter CLOCKING_MODE is
                                                                    -- "independent_clock". Unused when parameter CLOCKING_MODE is
                                                                    -- "common_clock".

            dina                        => i_wt_data,               -- WRITE_DATA_WIDTH_A-bit input: Data input for port A write operations.
            ena                         => '1',                     -- 1-bit input: Memory enable signal for port A. Must be high on clock
                                                                    -- cycles when write operations are initiated. Pipelined internally.

            enb                         => '1',                     -- 1-bit input: Memory enable signal for port B. Must be high on clock
                                                                    -- cycles when read operations are initiated. Pipelined internally.

            injectdbiterra              => '0',                     -- 1-bit input: Controls double bit error injection on input data when
                                                                    -- ECC enabled (Error injection capability is not available in
                                                                    -- "decode_only" mode).

            injectsbiterra              => '0',                     -- 1-bit input: Controls single bit error injection on input data when
                                                                    -- ECC enabled (Error injection capability is not available in
                                                                    -- "decode_only" mode).

            regceb                      => '1',                     -- 1-bit input: Clock Enable for the last register stage on the output
                                                                    -- data path.

            rstb                        => '0',                     -- 1-bit input: Reset signal for the final port B output register
                                                                    -- stage. Synchronously resets output port doutb to the value specified
                                                                    -- by parameter READ_RESET_VALUE_B.

            sleep                       => '0',                     -- 1-bit input: sleep signal to enable the dynamic power saving feature.
            wea(0)                      => i_wt_enable              -- WRITE_DATA_WIDTH_A/BYTE_WRITE_WIDTH_A-bit input: Write enable vector
                                                                    -- for port A input data port dina. 1 bit wide when word-wide writes
                                                                    -- are used. In byte-wide write configurations, each bit controls the
                                                                    -- writing one byte of dina to address addra. For example, to
                                                                    -- synchronously write only bits [15-8] of dina when WRITE_DATA_WIDTH_A
                                                                    -- is 32, wea would be 4'b0010.
        );

end Behavioral;