----------------------------------------
--top level of ddc/duc core
--LTE scalable core 5/10/15/20 MHz 2 C
-- OR
--UMTS 2 C
--Operating Frequency 245.76 MHz
-----------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;
use work.dduc_pkg.all;

entity umts_lte_ddc is
    generic (
        DDC_IN_HOVS                 : integer := 2
    );
    port(
        CLOCK                       : in std_logic;
        CLOCK_307                   : in std_logic;
        DDC_RESET                   : in std_logic;
        DDC_RESET_307               : in std_logic;

        MODE                        :in std_logic_vector(3 downto 0);

        --DDC IF
        SYNC_10MS                   :in std_logic;
        I_DDC_IN0                   :in std_logic_vector(15 downto 0);
        Q_DDC_IN0                   :in std_logic_vector(15 downto 0);
        I_DDC_IN1                   :in std_logic_vector(15 downto 0);
        Q_DDC_IN1                   :in std_logic_vector(15 downto 0);

        --NCOS for UMTS/LTE DDC
        DDC_NCO_WREN                :in std_logic_vector(1 downto 0);
        DDC_NCO0                    :in std_logic_vector(30 downto 0);
        DDC_NCO1                    :in std_logic_vector(30 downto 0);

        --DDC GAIN
        DDC_GAIN0                   :in std_logic_vector(15 downto 0);
        DDC_GAIN1                   :in std_logic_vector(15 downto 0);

        DDC_SYNC                    :out std_logic;
        DDC_OUT                     :out std_logic_vector(15 downto 0)
    );
end umts_lte_ddc;

architecture rtl of umts_lte_ddc is
 
component channel_swap_hbf_d is
generic(
    CHANNEL_NUMBERS             : natural:= 4;
    HOVS                        : natural:= 2;
    WIDTH_IN                    : natural:= 16
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);        -- 2 continuous data per each channel, x1 rate

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)         -- 1 data per each channel, x2 rate
);
end component;

component fir_d is
generic (
    VENDOR                      : string:="XILINX";
    HOVS                        : integer:=2;
    ORDER                       : integer:=12;

    CHANNEL_NUMBERS             : integer:=8;

    WIDTH_IN                    : integer:=16;
    WIDTH_OUT                   : integer:=16;
    WIDTH_COEFF                 : integer:=16;
    WIDTH_RESULT                : integer:=33;
    BINARY_POINT                : integer:=15
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN_0                 : in  std_logic_vector(WIDTH_IN-1 downto 0);
    FILTER_IN_1                 : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1  downto 0)
);
end component;

component dduc_atten is
generic(
    CHANNEL_NUMBERS             : natural:=4;
    DATA_WIDTH                  : natural:=16;
    GAIN_WIDTH                  : natural:=16;
    BINARY_POINT                : natural:=14
);
port(
    CLK                         : in  std_logic;
    RST                         : in  std_logic;
    GAIN                        : in  std_logic_array16(CHANNEL_NUMBERS-1 downto 0);--MUST be positive always!!

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUt                  : out std_logic_vector(DATA_WIDTH-1 downto 0)
);
end component;

component ddc_composite is
generic (
    DDC_IN_HOVS                 : integer
);
port(
    RST                         : in  std_logic;
    RST_307                     : in  std_logic;
    CLK                         : in  std_logic;
    CLK_307                     : in  std_logic;

    MODE                        : in  std_logic_vector(3 downto 0);
    NCO_WREN                    : in  std_logic_vector(DDC_NCO_CHANNELS-1 downto 0);
    NCO_FREQ_WORD               : in  std_logic_vector(DDC_NCO_CHANNELS*(log2(DDC_NCO_ACCU_VAL)-DDC_IN_HOVS/4)-1 downto 0);

    DDC_FRAME_I                 : in  std_logic;
    DDC_VALID_I                 : in  std_logic;
    DDC_IN                      : in  ddc_input_type;

    DDC_SYNC                    : out std_logic;
    DDC_OUT                     : out std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0)
);
end component;

type  buf_type                  is array(integer range <>) of std_logic_vector(15 downto 0);

signal mode_d0                  : std_logic_vector(3 downto 0);
signal mode_d1                  : std_logic_vector(3 downto 0);

signal clk_cnt                  : std_logic_vector(5 downto 0);-- 3.84MHz = 245.76MHz/64
signal clk_cnt0                 : std_logic;
signal clk_cnt1                 : std_logic;
signal clk_cnt2                 : std_logic;
signal sync_10ms_d              : std_logic_vector(2 downto 0);
signal frame_sync               : std_logic;
signal frame_sync_d             : std_logic;
signal att_frame_sync           : std_logic;

signal valid_sync               : std_logic;
signal att_valid_sync           : std_logic;

signal i_ddc_in0_r              : std_logic_vector(15 downto 0);
signal q_ddc_in0_r              : std_logic_vector(15 downto 0);
signal i_ddc_in1_r              : std_logic_vector(15 downto 0);
signal q_ddc_in1_r              : std_logic_vector(15 downto 0);

signal ddc_in                   : buf_type(1 downto 0);
signal ddc_out_buf              : buf_type(3 downto 0);

signal ddc_cnt                  : std_logic_vector(1 downto 0);

signal ddc_gain_ab              : std_logic_array16(CHANNEL_NUMBERS-1 downto 0);
signal att_ddc_in               : ddc_input_type;

signal ddc_nco_fcw              : std_logic_vector(DDC_NCO_CHANNELS*(log2(DDC_NCO_ACCU_VAL)-DDC_IN_HOVS/4)-1 downto 0);

signal chip_sync_out            : std_logic:='0';
signal chip_sync_out_1d         : std_logic:='0';
signal chip_sync_cnt            : std_logic_vector(6 downto 0):=(others=>'0');
signal valid_out                : std_logic:='0';
signal data_i_out               : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal data_q_out               : std_logic_array16(RX_ANT_NUM-1 downto 0);

signal hbf_frame_out_x4         : std_logic;  
signal hbf_frame_out_x4_1d      : std_logic;
signal hbf_frame_out_x4_2d      : std_logic;
signal hbf_valid_out_x4         : std_logic;  
signal hbf_data_out_x4          : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal hbf_data_out_x4_1d       : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal hbf_data_out_x4_2d       : std_logic_array16(RX_ANT_NUM-1 downto 0);
signal hbf_data_out_x4_3d       : std_logic_array16(RX_ANT_NUM-1 downto 0);

attribute KEEP                  : string;
attribute KEEP of mode_d1       : signal is "TRUE";
attribute KEEP of clk_cnt0      : signal is "TRUE";
attribute KEEP of clk_cnt1      : signal is "TRUE";
attribute KEEP of clk_cnt2      : signal is "TRUE";
attribute MAX_FANOUT            : integer;
attribute MAX_FANOUT of mode_d1 : signal is 64;
attribute MAX_FANOUT of clk_cnt0 : signal is 32;
attribute MAX_FANOUT of clk_cnt1 : signal is 32;
attribute MAX_FANOUT of clk_cnt2 : signal is 32;

begin


    ddc_nco_fcw <= DDC_NCO1(log2(DDC_NCO_ACCU_VAL)-DDC_IN_HOVS/4-1 downto 0) & DDC_NCO0(log2(DDC_NCO_ACCU_VAL)-DDC_IN_HOVS/4-1 downto 0);

    process(CLOCK, DDC_RESET)
    begin
        if DDC_RESET='1' then
            mode_d0                 <= (others => '0');
            mode_d1                 <= (others => '0');
        elsif CLOCK'event and CLOCK='1' then
            mode_d0                 <= MODE;
            mode_d1                 <= mode_d0;
        end if;
    end process;

    process(CLOCK_307, DDC_RESET_307)
    begin
        if (DDC_RESET_307 = '1') then
            sync_10ms_d             <= (others => '0');
            clk_cnt                 <= (others => '0');
            frame_sync              <= '0';
        elsif (CLOCK_307'event and CLOCK_307='1') then
            -- CLOCK counter for 10ms synchonization (3.84MHz)
            sync_10ms_d             <= sync_10ms_d(1 downto 0) & SYNC_10MS;

            if (sync_10ms_d(2 downto 1) = b"01") then
                clk_cnt             <= (others => '0');
            else
                clk_cnt             <= clk_cnt + '1';
            end if;

            -- 3.84MHz frame sync signal (synchronized with 10ms)
            if (clk_cnt = 0) then
                frame_sync          <= '1';
            else
                frame_sync          <= '0';
            end if;
        end if;
    end process;

    -- DDC input latch
    clk_cnt0            <= '1' when (clk_cnt(log2(DDC_IN_HOVS)-1 downto 0) = 0) else '0';    -- toggle
    clk_cnt1            <= '1' when (clk_cnt(log2(DDC_IN_HOVS)-1 downto 0) = 1) else '0';    -- inverse toggle
--    clk_cnt2            <= '1' when (clk_cnt(log2(DDC_IN_HOVS)-2 downto 0) = 1) else '0';

    g_ddc_in_122p88m : if (ddc_in_hovs = 2) generate
        process(CLOCK_307,DDC_RESET_307)
        begin
            if (DDC_RESET_307 = '1') then
                i_ddc_in0_r         <= (others => '0');
                q_ddc_in0_r         <= (others => '0');
                i_ddc_in1_r         <= (others => '0');
                q_ddc_in1_r         <= (others => '0');

                frame_sync_d        <= '0';
            elsif (CLOCK_307'event and CLOCK_307='1') then
                if (clk_cnt0 = '1') then
                    i_ddc_in0_r     <= I_DDC_IN0;   -- A
                    q_ddc_in0_r     <= Q_DDC_IN0;
                    i_ddc_in1_r     <= I_DDC_IN1;   -- B
                    q_ddc_in1_r     <= Q_DDC_IN1;
                end if;
                
                frame_sync_d        <= frame_sync;
            end if;
        end process;
        
        --conversion to ddc input format--
        process(CLOCK_307,DDC_RESET_307)
        begin
            if (DDC_RESET_307='1') then
                ddc_in(0)           <= (others => '0');
                ddc_in(1)           <= (others => '0');
            elsif (CLOCK_307'event and CLOCK_307='1') then
                --input to DDC
                if (clk_cnt1 = '1') then
                    ddc_in(0)       <= i_ddc_in0_r;
                    ddc_in(1)       <= q_ddc_in0_r;
                else
                    ddc_in(0)       <= i_ddc_in1_r;
                    ddc_in(1)       <= q_ddc_in1_r;
                end if;
            end if;
        end process;
    end generate;

    --conversion to ddc input format--
    process(CLOCK_307,DDC_RESET_307)
    begin
        if (DDC_RESET_307='1') then
            valid_sync              <= '0';
        elsif (CLOCK_307'event and CLOCK_307='1') then
            --input to DDC
            if (DDC_IN_HOVS=1 or DDC_IN_HOVS = 2) then
--                valid_sync          <= '1';
--            elsif (clk_cnt2 = '1') then
                valid_sync          <= '1';
            else
                valid_sync          <= '0';
            end if;
        end if;
    end process;

    --DDC gain disable
    GAIN_GEN_EN_0 : if (DUC_ATT_EN = 0) generate
        att_frame_sync              <= frame_sync_d;
        att_valid_sync              <= valid_sync;
        att_ddc_in(0)               <= ddc_in(0);
        att_ddc_in(1)               <= ddc_in(1);
    end generate GAIN_GEN_EN_0;

    --DDC gain enable
    GAIN_GEN_EN_1 : if (DUC_ATT_EN = 1) generate
        ddc_gain_ab(0)              <= DDC_GAIN0;
        ddc_gain_ab(1)              <= DDC_GAIN1;
        ddc_gain_ab(2)              <= DDC_GAIN0;
        ddc_gain_ab(3)              <= DDC_GAIN1;

        ddc_atten_a : dduc_atten
            generic map(
                CHANNEL_NUMBERS             => CHANNEL_NUMBERS              ,--:natural:=4;
                DATA_WIDTH                  => DDC_WIDTH_I                  ,--:natural:=16;
                GAIN_WIDTH                  => DDC_ATT_WIDTH                ,--:natural:=16;
                BINARY_POINT                => DDC_ATT_BIN_POINT             --:natural:=15
            )
            port map(
                CLK                         => CLOCK_307                    ,--: in  std_logic;
                RST                         => DDC_RESET_307                ,--: in  std_logic;
                GAIN                        => ddc_gain_ab                  ,--: in  std_logic_array16(CHANNEL_NUMBERS-1 downto 0);--MUST be positive always!!

                FRAME_I                     => frame_sync_d                 ,--: in  std_logic;
                VALID_I                     => valid_sync                   ,--: in  std_logic;
                FILTER_IN                   => ddc_in(0)                    ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);

                FRAME_O                     => att_frame_sync               ,--: out std_logic;
                VALID_O                     => att_valid_sync               ,--: out std_logic;
                FILTER_OUT                  => att_ddc_in(0)                 --: out std_logic_vector(DATA_WIDTH-1 downto 0)
            );

        ddc_atten_b : dduc_atten
            generic map(
                CHANNEL_NUMBERS             => CHANNEL_NUMBERS              ,--:natural:=4;
                DATA_WIDTH                  => DDC_WIDTH_I                  ,--:natural:=16;
                GAIN_WIDTH                  => DDC_ATT_WIDTH                ,--:natural:=16;
                BINARY_POINT                => DDC_ATT_BIN_POINT             --:natural:=15
            )
            port map(
                CLK                         => CLOCK_307                    ,--: in  std_logic;
                RST                         => DDC_RESET_307                ,--: in  std_logic;
                GAIN                        => ddc_gain_ab                  ,--: in  std_logic_array16(CHANNEL_NUMBERS-1 downto 0);--MUST be positive always!!

                FRAME_I                     => frame_sync_d                 ,--: in  std_logic;
                VALID_I                     => valid_sync                   ,--: in  std_logic;
                FILTER_IN                   => ddc_in(1)                    ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);

                FRAME_O                     => open                         ,--: out std_logic;
                VALID_O                     => open                         ,--: out std_logic;
                FILTER_OUT                  => att_ddc_in(1)                 --: out std_logic_vector(DATA_WIDTH-1 downto 0)
            );
    end generate GAIN_GEN_EN_1;

    u_ddc_composite : ddc_composite
        generic map(
            DDC_IN_HOVS                 => ternary_func(DDC_IN_HOVS=1, 2, DDC_IN_HOVS)                       --: integer := 2
        )
        port map(
            RST                         => DDC_RESET                        ,--: in  std_logic;
            RST_307                     => DDC_RESET_307                    ,--: in  std_logic;
            CLK                         => CLOCK                            ,--: in  std_logic;
            CLK_307                     => CLOCK_307                        ,--: in  std_logic;

            MODE                        => mode_d1                          ,--: in  std_logic_vector(3 downto 0);
            NCO_WREN                    => DDC_NCO_WREN                     ,--: in  std_logic_vector(DDC_NCO_CHANNELS-1 downto 0);
            NCO_FREQ_WORD               => ddc_nco_fcw                      ,--: in  std_logic_vector(DDC_NCO_CHANNELS*(log2(DDC_NCO_ACCU_VAL)-DDC_IN_HOVS/4)-1 downto 0);

            DDC_FRAME_I                 => att_frame_sync                   ,--: in  std_logic;
            DDC_VALID_I                 => att_valid_sync                   ,--: in  std_logic;
            DDC_IN                      => att_ddc_in                       ,--: in  ddc_input_type;

            DDC_SYNC                    => DDC_SYNC                         ,--: out std_logic;
            DDC_OUT                     => DDC_OUT                           --: out std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0)
        );

end rtl;
