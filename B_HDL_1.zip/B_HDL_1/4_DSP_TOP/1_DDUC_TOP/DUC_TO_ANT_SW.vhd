-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity DUC_TO_ANT_SW is
    generic    (
        ANT_NUM             : natural := 4
                );

    port (
        RESET                  : in std_logic;
        CLK                    : in std_logic; -- DUC operation clock

        IN_DATA_0_I            : in std_logic_vector(15 downto 0);
        IN_DATA_0_Q            : in std_logic_vector(15 downto 0);
        IN_DATA_1_I            : in std_logic_vector(15 downto 0);
        IN_DATA_1_Q            : in std_logic_vector(15 downto 0);

        ANT_OUT_CONTROL        : in std_logic_vector(2*ANT_NUM-1 downto 0);
        DUCOUT_SUM_MODE_ON     : in std_logic;

        ODATA_I                : out std_logic_array16(ANT_NUM-1 downto 0);
        ODATA_Q                : out std_logic_array16(ANT_NUM-1 downto 0)
        );
end DUC_TO_ANT_SW;

architecture arc_DUC_TO_ANT_SW of DUC_TO_ANT_SW is

signal i_sum_0_I                 : std_logic_vector(16 downto 0);
signal i_sum_0_Q                 : std_logic_vector(16 downto 0);
signal i_sum_1_I                 : std_logic_vector(16 downto 0);
signal i_sum_1_Q                 : std_logic_vector(16 downto 0);
signal i_sum_0_sat_I             : std_logic_vector(15 downto 0);
signal i_sum_0_sat_Q             : std_logic_vector(15 downto 0);
signal i_sum_1_sat_I             : std_logic_vector(15 downto 0);
signal i_sum_1_sat_Q             : std_logic_vector(15 downto 0);
signal i_cnt_out_ctrl            : std_logic_array2(ANT_NUM-1 downto 0);

begin

--process(RESET,CLK)
--begin
--    if RESET = '1' then
--        i_sum_0_I <= (others => '0');
--        i_sum_0_Q <= (others => '0');
--    elsif (CLK'event and CLK = '1') then
--        if DUCOUT_SUM_MODE_ON = '1' then
--             i_sum_0_I <= (IN_DATA_0_I(15) & IN_DATA_0_I) + (IN_DATA_1_I(15) & IN_DATA_1_I);
--             i_sum_0_Q <= (IN_DATA_0_Q(15) & IN_DATA_0_Q) + (IN_DATA_1_Q(15) & IN_DATA_1_Q);
--        else
             i_sum_0_I <= IN_DATA_0_I(15) & IN_DATA_0_I;
             i_sum_0_Q <= IN_DATA_0_Q(15) & IN_DATA_0_Q;
--        end if;
--    end if;
--end process;

--process(RESET,CLK)
--begin
--    if RESET = '1' then
--        i_sum_1_I <= (others => '0');
--        i_sum_1_Q <= (others => '0');
--    elsif (CLK'event and CLK = '1') then
--        if DUCOUT_SUM_MODE_ON = '1' then
--            i_sum_1_I <= (others => '0');
--            i_sum_1_Q <= (others => '0');
--        else
            i_sum_1_I <= IN_DATA_1_I(15) & IN_DATA_1_I;
            i_sum_1_Q <= IN_DATA_1_Q(15) & IN_DATA_1_Q;
--        end if;
--    end if;
--end process;

--process(RESET,CLK)
--begin
--    if RESET = '1' then
--        i_sum_0_sat_I <= (others => '0');
--        i_sum_0_sat_Q <= (others => '0');
--    elsif (CLK'event and CLK = '1') then
--        if i_sum_0_I(16) = '0' then
--            if i_sum_0_I(15) = '0' then
                i_sum_0_sat_I <= i_sum_0_I(15 downto 0);
--            else
--                i_sum_0_sat_I <= "0111111111111111";
--            end if;
--        else
--            if i_sum_0_I(15) = '1' then
--                i_sum_0_sat_I <= i_sum_0_I(15 downto 0);
--            else
--                i_sum_0_sat_I <= "1000000000000000";
--            end if;
--        end if;
--
--        if i_sum_0_Q(16) = '0' then
--            if i_sum_0_Q(15) = '0' then
                i_sum_0_sat_Q <= i_sum_0_Q(15 downto 0);
--            else
--                i_sum_0_sat_Q <= "0111111111111111";
--            end if;
--        else
--            if i_sum_0_Q(15) = '1' then
--                i_sum_0_sat_Q <= i_sum_0_Q(15 downto 0);
--            else
--                i_sum_0_sat_Q <= "1000000000000000";
--            end if;
--        end if;
--    end if;
--end process;

--process(RESET,CLK)
--begin
--    if RESET = '1' then
--        i_sum_1_sat_I <= (others => '0');
--        i_sum_1_sat_Q <= (others => '0');
--    elsif (CLK'event and CLK = '1') then
--        if i_sum_1_I(16) = '0' then
--            if i_sum_1_I(15) = '0' then
              i_sum_1_sat_I <= i_sum_1_I(15 downto 0);
--            else
--              i_sum_1_sat_I <= "0111111111111111";
--            end if;
--        else
--            if i_sum_1_I(15) = '1' then
--              i_sum_1_sat_I <= i_sum_1_I(15 downto 0);
--            else
--              i_sum_1_sat_I <= "1000000000000000";
--            end if;
--        end if;
--
--        if i_sum_1_Q(16) = '0' then
--            if i_sum_1_Q(15) = '0' then
              i_sum_1_sat_Q <= i_sum_1_Q(15 downto 0);
--            else
--              i_sum_1_sat_Q <= "0111111111111111";
--            end if;
--        else
--            if i_sum_1_Q(15) = '1' then
--              i_sum_1_sat_Q <= i_sum_1_Q(15 downto 0);
--            else
--              i_sum_1_sat_Q <= "1000000000000000";
--            end if;
--        end if;
--    end if;
--end process;

-- 2bit per 1 path Antenna out, "00""11" : 0 data out(no assignment) , "01" : no#0 CC I/Q data , "10" : no#1 CC I/Q data

ant_out_bus_gen : for i in 0 to ANT_NUM-1 generate
    i_cnt_out_ctrl(i) <= ANT_OUT_CONTROL((2*i + 1) downto (2*i));

    process(RESET,CLK)
    begin
        if RESET = '1' then
            ODATA_I(i) <= (others => '0');
            ODATA_Q(i) <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            case i_cnt_out_ctrl(i) is
                when "00" =>
                    ODATA_I(i) <= (others => '0');
                    ODATA_Q(i) <= (others => '0');
                when "01" =>
                    ODATA_I(i) <= i_sum_0_sat_I;
                    ODATA_Q(i) <= i_sum_0_sat_Q;
                when "10" =>
                    ODATA_I(i) <= i_sum_1_sat_I;
                    ODATA_Q(i) <= i_sum_1_sat_Q;
                when others =>
                    ODATA_I(i) <= (others => '0');
                    ODATA_Q(i) <= (others => '0');
            end case;
        end if;
    end process;
end generate;

end arc_DUC_TO_ANT_SW;
