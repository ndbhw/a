--*****************************************************************************
--Compelx multiplier
--*****************************************************************************
------------------------------------------------------------------
-- 2014.11.26, wj311.kim  : for Arria 10
------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity dduc_complex_mult is
generic(
    VENDOR                      : string    := "XILINX";    -- "XILINX", "ALTERA"

    WIDTH_IN                    : natural   := 16;
    NCO_WIDTH_IN                : natural   := 16;
    WIDTH_OUT                   : natural   := 16;
    BINARY_POINT                : natural   := 15;          -- BINARY_POINT = WIDTH_IN+NCO_WIDTH_IN-WIDTH_OUT-1

    ROUNDING                    : string    := "ROUND_INF"; --"FULL_PRECISION","TRUNCATE","ROUND_INF", "ROUND_EVEN"
    OVERFLOW                    : string    := "SATURATE";  --"WRAP","SATURATE"
    SUM_EN                      : natural   := 0;           -- 1 : I+I, Q+Q for DUC output summation mode, 0 : bypass
    HOVS                        : natural   := 1
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    SINE_CONJUGATE              : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;

    DATA_IN_I                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_IN_Q                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_IN_COS                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);
    DATA_IN_SIN                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    DATA_OUT_I                  : out std_logic_vector(WIDTH_OUT-1 downto 0);
    DATA_OUT_Q                  : out std_logic_vector(WIDTH_OUT-1 downto 0)
);
end dduc_complex_mult;

architecture Behavioral of dduc_complex_mult is

component dduc_comp_mult_x7 is
generic(
    WIDTH_IN                    : natural := 16;
    NCO_WIDTH_IN                : natural := 16;
    SUM_EN                      : natural := 0;
    HOVS                        : natural := 1;
    BINARY_POINT                : natural   := 15
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    SINE_CONJUGATE              : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    DATA_IN_I                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_IN_Q                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_IN_COS                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);
    DATA_IN_SIN                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    DATA_OUT_I                  : out std_logic_vector(WIDTH_IN+NCO_WIDTH_IN-1 downto 0);
    DATA_OUT_Q                  : out std_logic_vector(WIDTH_IN+NCO_WIDTH_IN-1 downto 0)
);
end component;

component dduc_comp_mult_a10 is
generic(
    WIDTH_IN                    : natural := 16;
    NCO_WIDTH_IN                : natural := 16;
    SUM_EN                      : natural := 0;
    HOVS                        : natural := 1
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    DATA_IN_I                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_IN_Q                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_IN_COS                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);
    DATA_IN_SIN                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    DATA_OUT_I                  : out std_logic_vector(WIDTH_IN+NCO_WIDTH_IN-1 downto 0);
    DATA_OUT_Q                  : out std_logic_vector(WIDTH_IN+NCO_WIDTH_IN-1 downto 0)
);
end component;

component round_stage is
generic(
    VAR_WIDTH                   : natural:= 5;
    FIXED_GAIN                  : natural:= 1;         --gain is fixed or not
    WIDTH_IN                    : natural:= 34;
    WIDTH_OUT                   : natural:= 16;
    BINARY_POINT                : natural:= 15;        -- DATA OUT = ROUNDING(DATA IN)/2^(BINARY_POINT+1)
    ROUNDING                    : string:= "ROUND_INF";--"FULL_PRECISION", "TRUNCATE","ROUND_INF", "ROUND_EVEN"
    OVERFLOW                    : string:= "SATURATE"  --"WRAP or "SATURATE"
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    BIT_SHIFT_VALUE             : in  std_logic_vector(VAR_WIDTH-1 downto 0);

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1 downto 0)
);
end component;

signal cmult_frame              : std_logic;
signal cmult_valid              : std_logic;
signal cmult_out_i              : std_logic_vector(WIDTH_IN+NCO_WIDTH_IN-1 downto 0);
signal cmult_out_q              : std_logic_vector(WIDTH_IN+NCO_WIDTH_IN-1 downto 0);

begin

g_X : if VENDOR="XILINX" generate
    u_dduc_comp_mult_x7 : dduc_comp_mult_x7
    generic map(
        WIDTH_IN                    => WIDTH_IN                     ,--: natural   := 16;
        NCO_WIDTH_IN                => NCO_WIDTH_IN                 ,--: natural   := 16
        SUM_EN                      => SUM_EN                       ,--: natural   := 0;
        HOVS                        => HOVS                         ,--: natural   := 16
        BINARY_POINT                => BINARY_POINT                  --: natural   := 15
    )
    port map(
        RST                         => RST                          ,--: in  std_logic;
        CLK                         => CLK                          ,--: in  std_logic;

        SINE_CONJUGATE              => SINE_CONJUGATE               ,--: in  std_logic;

        FRAME_I                     => FRAME_I                      ,--: in  std_logic;
        VALID_I                     => VALID_I                      ,--: in  std_logic;
        DATA_IN_I                   => DATA_IN_I                    ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
        DATA_IN_Q                   => DATA_IN_Q                    ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
        DATA_IN_COS                 => DATA_IN_COS                  ,--: in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);
        DATA_IN_SIN                 => DATA_IN_SIN                  ,--: in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);

        FRAME_O                     => cmult_frame                  ,--: out std_logic;
        VALID_O                     => cmult_valid                  ,--: out std_logic;
        DATA_OUT_I                  => cmult_out_i                  ,--: out std_logic_vector(WIDTH_IN+NCO_WIDTH_IN downto 0);
        DATA_OUT_Q                  => cmult_out_q                   --: out std_logic_vector(WIDTH_IN+NCO_WIDTH_IN downto 0)
    );

    FRAME_O     <= cmult_frame;
    VALID_O     <= cmult_valid;
    DATA_OUT_I  <= cmult_out_i(WIDTH_OUT+BINARY_POINT downto BINARY_POINT+1);
    DATA_OUT_Q  <= cmult_out_q(WIDTH_OUT+BINARY_POINT downto BINARY_POINT+1);

    -- Symmetric rounding to infinity
--    u_round_stage_i : round_stage
--    generic map(
--        VAR_WIDTH                   => 1                            ,--: natural:= 5;
--        FIXED_GAIN                  => 1                            ,--: natural:= 1;         --gain is fixed or not
--        WIDTH_IN                    => WIDTH_IN+NCO_WIDTH_IN        ,
--        WIDTH_OUT                   => WIDTH_OUT                    ,--: natural:= 16;
--        BINARY_POINT                => BINARY_POINT                 ,--: natural:= 15;        -- DATA OUT = ROUNDING(DATA IN)/2^(BINARY_POINT+1)
--        ROUNDING                    => "ROUND_INF"                  ,--: string:= "ROUND_INF";--"FULL_PRECISION", "TRUNCATE","ROUND_INF", "ROUND_EVEN"
--        OVERFLOW                    => "SATURATE"                    --: string:= "SATURATE"  --"WRAP or "SATURATE"
--    )
--    port map(
--        RST                         => RST                          ,--: in  std_logic;
--        CLK                         => CLK                          ,--: in  std_logic;
--        bit_shift_value             => (others => '0')              ,--: in  std_logic_vector(VAR_WIDTH-1 downto 0);
--
--        frame_i                     => cmult_frame                  ,--: in  std_logic;
--        valid_i                     => cmult_valid                  ,--: in  std_logic;
--        filter_in                   => cmult_out_i                  ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
--
--        frame_o                     => FRAME_O                      ,--: out std_logic;
--        valid_o                     => VALID_O                      ,--: out std_logic;
--        filter_out                  => DATA_OUT_I                    --: out std_logic_vector(WIDTH_OUT-1 downto 0)
--    );
--
--    u_round_stage_q : round_stage
--    generic map(
--        VAR_WIDTH                   => 1                            ,--: natural:= 5;
--        FIXED_GAIN                  => 1                            ,--: natural:= 1;         --gain is fixed or not
--        WIDTH_IN                    => WIDTH_IN+NCO_WIDTH_IN         ,
--        WIDTH_OUT                   => WIDTH_OUT                    ,--: natural:= 16;
--        BINARY_POINT                => BINARY_POINT                 ,--: natural:= 15;        -- DATA OUT = ROUNDING(DATA IN)/2^(BINARY_POINT+1)
--        ROUNDING                    => "ROUND_INF"                  ,--: string:= "ROUND_INF";--"FULL_PRECISION", "TRUNCATE","ROUND_INF", "ROUND_EVEN"
--        OVERFLOW                    => "SATURATE"                    --: string:= "SATURATE"  --"WRAP or "SATURATE"
--    )
--    port map(
--        RST                         => RST                          ,--: in  std_logic;
--        CLK                         => CLK                          ,--: in  std_logic;
--        bit_shift_value             => (others => '0')              ,--: in  std_logic_vector(VAR_WIDTH-1 downto 0);
--
--        frame_i                     => cmult_frame                  ,--: in  std_logic;
--        valid_i                     => cmult_valid                  ,--: in  std_logic;
--        filter_in                   => cmult_out_q                  ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
--
--        frame_o                     => open                         ,--: out std_logic;
--        valid_o                     => open                         ,--: out std_logic;
--        filter_out                  => DATA_OUT_Q                    --: out std_logic_vector(WIDTH_OUT-1 downto 0)
--    );
end generate;

g_A : if VENDOR="ALTERA" generate
    u_dduc_comp_mult_a10 : dduc_comp_mult_a10
    generic map(
        WIDTH_IN                    => WIDTH_IN                     ,--: natural   := 16;
        NCO_WIDTH_IN                => NCO_WIDTH_IN                 ,--: natural   := 16
        SUM_EN                      => SUM_EN                       ,--: natural   := 0;
        HOVS                        => HOVS                          --: natural   := 16
    )
    port map(
        RST                         => RST                          ,--: in  std_logic;
        CLK                         => CLK                          ,--: in  std_logic;

        FRAME_I                     => FRAME_I                      ,--: in  std_logic;
        VALID_I                     => VALID_I                      ,--: in  std_logic;
        DATA_IN_I                   => DATA_IN_I                    ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
        DATA_IN_Q                   => DATA_IN_Q                    ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
        DATA_IN_COS                 => DATA_IN_COS                  ,--: in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);
        DATA_IN_SIN                 => DATA_IN_SIN                  ,--: in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);

        FRAME_O                     => cmult_frame                  ,--: out std_logic;
        VALID_O                     => cmult_valid                  ,--: out std_logic;
        DATA_OUT_I                  => cmult_out_i                  ,--: out std_logic_vector(WIDTH_IN+NCO_WIDTH_IN downto 0);
        DATA_OUT_Q                  => cmult_out_q                   --: out std_logic_vector(WIDTH_IN+NCO_WIDTH_IN downto 0)
    );

        -- Symmetric rounding to infinity
    u_round_stage_i : round_stage
    generic map(
        VAR_WIDTH                   => 1                            ,--: natural:= 5;
        FIXED_GAIN                  => 1                            ,--: natural:= 1;         --gain is fixed or not
        WIDTH_IN                    => WIDTH_IN+NCO_WIDTH_IN        ,
        WIDTH_OUT                   => WIDTH_OUT                    ,--: natural:= 16;
        BINARY_POINT                => BINARY_POINT                 ,--: natural:= 15;        -- DATA OUT = ROUNDING(DATA IN)/2^(BINARY_POINT+1)
        ROUNDING                    => "ROUND_INF"                  ,--: string:= "ROUND_INF";--"FULL_PRECISION", "TRUNCATE","ROUND_INF", "ROUND_EVEN"
        OVERFLOW                    => "SATURATE"                    --: string:= "SATURATE"  --"WRAP or "SATURATE"
    )
    port map(
        RST                         => RST                          ,--: in  std_logic;
        CLK                         => CLK                          ,--: in  std_logic;
        bit_shift_value             => (others => '0')              ,--: in  std_logic_vector(VAR_WIDTH-1 downto 0);

        frame_i                     => cmult_frame                  ,--: in  std_logic;
        valid_i                     => cmult_valid                  ,--: in  std_logic;
        filter_in                   => cmult_out_i                  ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);

        frame_o                     => FRAME_O                      ,--: out std_logic;
        valid_o                     => VALID_O                      ,--: out std_logic;
        filter_out                  => DATA_OUT_I                    --: out std_logic_vector(WIDTH_OUT-1 downto 0)
    );

    u_round_stage_q : round_stage
    generic map(
        VAR_WIDTH                   => 1                            ,--: natural:= 5;
        FIXED_GAIN                  => 1                            ,--: natural:= 1;         --gain is fixed or not
        WIDTH_IN                    => WIDTH_IN+NCO_WIDTH_IN         ,
        WIDTH_OUT                   => WIDTH_OUT                    ,--: natural:= 16;
        BINARY_POINT                => BINARY_POINT                 ,--: natural:= 15;        -- DATA OUT = ROUNDING(DATA IN)/2^(BINARY_POINT+1)
        ROUNDING                    => "ROUND_INF"                  ,--: string:= "ROUND_INF";--"FULL_PRECISION", "TRUNCATE","ROUND_INF", "ROUND_EVEN"
        OVERFLOW                    => "SATURATE"                    --: string:= "SATURATE"  --"WRAP or "SATURATE"
    )
    port map(
        RST                         => RST                          ,--: in  std_logic;
        CLK                         => CLK                          ,--: in  std_logic;
        bit_shift_value             => (others => '0')              ,--: in  std_logic_vector(VAR_WIDTH-1 downto 0);

        frame_i                     => cmult_frame                  ,--: in  std_logic;
        valid_i                     => cmult_valid                  ,--: in  std_logic;
        filter_in                   => cmult_out_q                  ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);

        frame_o                     => open                         ,--: out std_logic;
        valid_o                     => open                         ,--: out std_logic;
        filter_out                  => DATA_OUT_Q                    --: out std_logic_vector(WIDTH_OUT-1 downto 0)
    );
end generate;


end Behavioral;
