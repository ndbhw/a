------------------------------------------------------------------
-- channel swap
------------------------------------------------------------------
-- 2013.11.01, vyacheslav : 1st release, system verilog
-- 2014.01.29, wj311.kim  : convert system_verilog to vhdl
------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

Library UNISIM;
use UNISIM.vcomponents.all;
--LIBRARY altera_lnsim;
--USE altera_lnsim.altera_lnsim_components.all;

entity dduc_dist_ram is
generic(
    BUFF_DEPTH                  : natural:= 16;
    WIDTH_IN                    : natural:= 16
);
port(
    CLK                         : in  std_logic;
    WE                          : in  std_logic;
    WADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    RADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_IN                     : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_OUT                    : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end dduc_dist_ram;

architecture Behavioral of dduc_dist_ram is

constant RAM_DEPTH              : integer := 2**log2(BUFF_DEPTH);
type ram_type is array (RAM_DEPTH-1 downto 0) of std_logic_vector(WIDTH_IN-1 downto 0);
signal RAM                      : ram_type := (others => (others => '0'));
signal raddr_r                  : std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);

attribute RAM_STYLE             : string;
attribute RAM_STYLE of RAM      : signal is "DISTRIBUTED";

begin

g_X : if VENDOR = "XILINX" generate
    process (CLK)
    begin
    if rising_edge(CLK) then
        if WE = '1' then
            RAM(conv_integer(WADDR)) <= DATA_IN;
        end if;
    end if;
    end process;

    process (CLK)
    begin
    if rising_edge(CLK) then
        raddr_r <= RADDR;
    end if;
    end process;

    process (CLK)
    begin
    if rising_edge(CLK) then
        DATA_OUT <= RAM(conv_integer(raddr_r));
    end if;
    end process;
end generate;

--g_A : if VENDOR = "ALTERA" generate
--    altera_syncram_component : altera_syncram
--    GENERIC MAP (
--        address_aclr_b          => "NONE",
--        address_reg_b           => "CLOCK0",
--        clock_enable_input_a    => "BYPASS",
--        clock_enable_input_b    => "BYPASS",
--        clock_enable_output_b   => "BYPASS",
--        intended_device_family  => "Arria 10",
--        lpm_type                => "altera_syncram",
--        numwords_a              => BUFF_DEPTH,
--        numwords_b              => BUFF_DEPTH,
--        operation_mode          => "DUAL_PORT",
--        outdata_aclr_b          => "NONE",
--        outdata_reg_b           => "CLOCK0",
--        power_up_uninitialized  => "FALSE",
--        ram_block_type          => "MLAB",
--        read_during_write_mode_mixed_ports  => "DONT_CARE",
--        widthad_a               => log2(BUFF_DEPTH),
--        widthad_b               => log2(BUFF_DEPTH),
--        width_a                 => WIDTH_IN,
--        width_b                 => WIDTH_IN,
--        width_byteena_a         => 1
--    )
--    PORT MAP (
--        address_a               => WADDR,
--        address_b               => RADDR,
--        clock0                  => CLK,
--        data_a                  => DATA_IN,
--        wren_a                  => WE,
--        q_b                     => DATA_OUT,
--        aclr0                   => '0',
--        aclr1                   => '0',
--        addressstall_a          => '0',
--        addressstall_b          => '0',
--        byteena_a               => "1",
--        byteena_b               => "1",
--        clock1                  => '1',
--        clocken0                => '1',
--        clocken1                => '1',
--        clocken2                => '1',
--        clocken3                => '1',
--        data_b                  => (others => '1'),
--        eccstatus               => open,
--        q_a                     => open,
--        rden_a                  => '1',
--        rden_b                  => '1',
--        wren_b                  => '0'
--    );
--end generate;

end Behavioral;
