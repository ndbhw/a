------------------------------------------------------------------
-- Digital IF Power Measure (For RX ADC Output Power Measure
------------------------------------------------------------------
-- 2014.06.10, wj311.kim  : 1st release
------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity dduc_delay is
generic(
    DATA_WIDTH                  : integer:= 16;
    CHANNEL_NUMBER              : integer:= 4;
    MAX_DELAY_SAMPLE            : integer:= 256;
    MAX_DELAY_CLOCK             : integer:= 16
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    DLY_SAMPLE                  : in  std_logic_vector(log2(MAX_DELAY_SAMPLE)-1 downto 0);
    DLY_CLOCK                   : in  std_logic_vector(log2(MAX_DELAY_CLOCK)-1 downto 0);

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    DATA_IN                     : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    DATA_OUT                    : out std_logic_vector(DATA_WIDTH-1 downto 0)
);
end dduc_delay;

architecture Behavioral of dduc_delay is

component dduc_bram is
generic(
    BUFF_DEPTH                  : integer := 1024;
    WIDTH_IN                    : integer := 16
);
port(
    CLK                         : in  std_logic;
    WE                          : in  std_logic;
    WADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    RADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_IN                     : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_OUT                    : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

component dduc_delay_chain is
generic(
    BUFF_DEPTH                  : natural:= 16;-- SRL16E
    DIRECTION                   : natural:= 0; -- 1:forward, 0:reverse, 0 for general delay block
    WIDTH_IN                    : natural:= 16 -- Input data width
);
port(
    CLK                         : in  std_logic;
    DATA_SEL                    : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

constant BRAM_DEPTH             : integer := CHANNEL_NUMBER*MAX_DELAY_SAMPLE;
constant BRAM_DELAY             : integer := 3;-- BRAM read processing delay, 2 clock
constant SRL_DEPTH              : integer := MAX_DELAY_CLOCK;
constant ONES                   : std_logic_vector(log2(MAX_DELAY_SAMPLE)-1 downto 0) := (others => '1');

signal frame_i_d                : std_logic_vector(BRAM_DELAY downto 0);
signal valid_i_d                : std_logic_vector(BRAM_DELAY downto 0);
signal data_in_d0               : std_logic_vector(DATA_WIDTH-1 downto 0);
signal data_in_d1               : std_logic_vector(DATA_WIDTH-1 downto 0);
signal bram_out                 : std_logic_vector(DATA_WIDTH-1 downto 0);

signal dly_sample_r             : std_logic_vector(log2(MAX_DELAY_SAMPLE)-1 downto 0);
signal delay_sync               : std_logic;

signal sample_sync              : std_logic;
signal sample_cnt               : std_logic_vector(log2(MAX_DELAY_SAMPLE)-1 downto 0);
signal sample_cnt_d             : std_logic_vector(log2(MAX_DELAY_SAMPLE)-1 downto 0);
signal ch_cnt                   : std_logic_vector(log2(CHANNEL_NUMBER)-1 downto 0);
signal ch_cnt_sh                : std_logic_vector(log2(CHANNEL_NUMBER)-1 downto 0);
signal waddr                    : std_logic_vector(log2(BRAM_DEPTH)-1 downto 0);
signal raddr                    : std_logic_vector(log2(BRAM_DEPTH)-1 downto 0);

signal srl_in                   : std_logic_vector(DATA_WIDTH+2-1 downto 0);
signal srl_out                  : std_logic_vector(DATA_WIDTH+2-1 downto 0);

begin

    -- input registering
    process(CLK)
    begin
        if rising_edge(CLK) then
            frame_i_d   <= frame_i_d(frame_i_d'length-2 downto 0) & FRAME_I;
            valid_i_d   <= valid_i_d(valid_i_d'length-2 downto 0) & VALID_I;
            data_in_d0  <= DATA_IN;
            data_in_d1  <= data_in_d0;
        end if;
    end process;

    dly_sample_r <= ONES - 1 when DLY_SAMPLE = ONES else DLY_SAMPLE;

    -- channel counter
    process(RST, CLK)
    begin
        if RST='1' then
            ch_cnt <= (others => '0');
        elsif rising_edge(CLK) then
            if FRAME_I = '1' then
                ch_cnt <= (others => '0');
            elsif VALID_I = '1' then
                if ch_cnt = CHANNEL_NUMBER-1 then
                    ch_cnt <= (others => '0');
                else
                    ch_cnt <= ch_cnt + '1';
                end if;
            end if;
        end if;
    end process;

    process(RST, CLK)
    begin
        if RST='1' then
            ch_cnt_sh <= (others => '0');
        elsif rising_edge(CLK) then
            ch_cnt_sh <= ch_cnt;
        end if;
    end process;

    process(RST, CLK)
    begin
        if RST='1' then
            sample_sync <= '0';
            delay_sync  <= '1';
        elsif rising_edge(CLK) then
            if (VALID_I = '1' and ch_cnt = CHANNEL_NUMBER-1) then
                sample_sync <= '1';
            else
                sample_sync <= '0';
            end if;
            if sample_cnt = dly_sample_r then
                delay_sync <= '1';
            else
                delay_sync <= '0';
            end if;
        end if;
    end process;

    -- sample counter for write address
    process(RST, CLK)
    begin
        if RST = '1' then
            sample_cnt <= (others => '0');
        elsif rising_edge(CLK) then
            if sample_sync = '1' then
                if sample_cnt = MAX_DELAY_SAMPLE-1 then
                    sample_cnt <= (others => '0');
                else
                    sample_cnt <= sample_cnt + '1';
                end if;
            end if;
        end if;
    end process;

    -- sample counter for read address
    process(RST, CLK)
    begin
        if RST = '1' then
            sample_cnt_d <= (others => '1');
        elsif rising_edge(CLK) then
            if sample_sync = '1' then
                if delay_sync = '1' then
                    sample_cnt_d <= (others => '0');
                else
                    sample_cnt_d <= sample_cnt_d + '1';
                end if;
            end if;
        end if;
    end process;

    waddr <= sample_cnt   & ch_cnt_sh;
    raddr <= sample_cnt_d & ch_cnt_sh;

u_dduc_bram : dduc_bram
generic map(
    BUFF_DEPTH                  => BRAM_DEPTH                   ,--: integer := 1024;
    WIDTH_IN                    => DATA_WIDTH                    --: integer := 16
)
port map(
    CLK                         => CLK                          ,--: in  std_logic;
    WE                          => valid_i_d(1)                 ,--: in  std_logic;
    WADDR                       => waddr                        ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    RADDR                       => raddr                        ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_IN                     => data_in_d1                   ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_OUT                    => bram_out                      --: out std_logic_vector(WIDTH_IN-1 downto 0)
);

--process(CLK)
--begin
--    if rising_edge(CLK) then
        srl_in  <= frame_i_d(frame_i_d'high) & valid_i_d(valid_i_d'high) & bram_out;
--    end if;
--end process;

u_dduc_delay_chain : dduc_delay_chain
generic map(
    BUFF_DEPTH                  => SRL_DEPTH                    ,--: natural:= 16;-- SRL16E
    DIRECTION                   => 0                            ,--: natural:= 0; -- 1:forward, 0:reverse, 0 for general delay block
    WIDTH_IN                    => DATA_WIDTH+2                  --: natural:= 16 -- Input data width
)
port map(
    CLK                         => CLK                          ,--: in  std_logic;
    DATA_SEL                    => DLY_CLOCK                    ,
    VALID_I                     => '1'                          ,--: in  std_logic;
    FILTER_IN                   => srl_in                       ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
    FILTER_OUT                  => srl_out                       --: out std_logic_vector(WIDTH_IN-1 downto 0)
);

--process(CLK)
--begin
--    if rising_edge(CLK) then
        FRAME_O <= srl_out(srl_out'high);
        VALID_O <= srl_out(srl_out'high-1);
        DATA_OUT<= srl_out(srl_out'high-2 downto 0);
--    end if;
--end process;

end Behavioral;
