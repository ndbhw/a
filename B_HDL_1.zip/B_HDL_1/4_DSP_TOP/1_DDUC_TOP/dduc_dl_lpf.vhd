-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2023, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2023.11.14 v1.0] Initial release
-- *****************************************************************************

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

--library UNISIM;
--use UNISIM.VCOMPONENTS.ALL;
Library xpm;
use xpm.vcomponents.all;

entity dduc_dl_lpf is
    generic (
        DDUC_TYPE                           : string := "DUC";  -- "DUC" or "DDC"
        DATA_WIDTH                          : integer := 16;
        BINARY_POINT                        : integer := 15
    );
    Port (
        i_rst_307                           : in std_logic;
        i_clk_307                           : in std_logic;
        
        -- 153.MHz, 4 channel
        i_upsample_rearrange_frame          : in std_logic;
        i_upsample_rearrange_valid          : in std_logic;
        i_upsample_rearrange_data           : in std_logic_vector(DATA_WIDTH-1 downto 0);

        -- 76.8MHz, 4 channel
        o_lpf_frame                         : out std_logic;
        o_lpf_valid                         : out std_logic;
        o_lpf_data                          : out std_logic_vector(40-1 downto 0);
        o_fir_ready                         : out std_logic
    );
end dduc_dl_lpf;

architecture Behavioral of dduc_dl_lpf is
    
    component fir_dl_lpf_1 is
    Port( 
        aresetn             : IN STD_LOGIC; 
        aclk                : IN STD_LOGIC;
                                         
        s_axis_data_tvalid  : IN STD_LOGIC;                   
        s_axis_data_tready  : OUT STD_LOGIC;                  
        s_axis_data_tuser   : IN STD_LOGIC_VECTOR(0 DOWNTO 0);
        s_axis_data_tdata   : IN STD_LOGIC_VECTOR(15 DOWNTO 0);
                
        m_axis_data_tvalid  : OUT STD_LOGIC;                  
        m_axis_data_tuser   : OUT STD_LOGIC_VECTOR(0 DOWNTO 0);
        m_axis_data_tdata   : OUT STD_LOGIC_VECTOR(39 DOWNTO 0)
        );
    end component;
    
    signal o_fir_lpf_ready              : std_logic;
    signal o_fir_lpf_valid              : std_logic;
    signal o_fir_lpf_data_DUC           : std_logic_vector(39 downto 0);
    signal o_fir_lpf_data               : std_logic_vector(39 downto 0);
    signal o_data_tuser                 : std_logic;
    signal reset_fir                    : std_logic;
    
    signal In_upsample_rearrange_valid  : std_logic;
    signal In_upsample_rearrange_frame  : std_logic;
    signal In_upsample_rearrange_data   : std_logic_vector (15 downto 0);
    
    signal d_reset                      : std_logic;
    signal dd_reset                     : std_logic;

begin

    
    xpm_cdc_async_rst_inst : xpm_cdc_async_rst
    generic map (
           DEST_SYNC_FF => 4,    -- DECIMAL; range: 2-10 
           INIT_SYNC_FF => 0,    -- DECIMAL; 0=disable simulation init values, 1=enable simulation init values
           RST_ACTIVE_HIGH => 0  -- DECIMAL; 0=active low reset, 1=active high reset
        )
        port map (
           dest_arst => d_reset, -- 1-bit output: src_arst asynchronous reset signal synchronized to destination
                                   -- clock domain. This output is registered. NOTE: Signal asserts asynchronously
                                   -- but deasserts synchronously to dest_clk. Width of the reset signal is at least
                                   -- (DEST_SYNC_FF*dest_clk) period.

           dest_clk => i_clk_307,   -- 1-bit input: Destination clock.
           src_arst => i_rst_307--src_arst    -- 1-bit input: Source asynchronous reset signal.
        );
        
   FIR_DUC : if (DDUC_TYPE = "DUC") generate
    u_test_fir_lpf : fir_dl_lpf_1
    port map(
        aresetn             => dd_reset,
        aclk                =>  i_clk_307,--CLK_307,--reset_fir,--RST_307,
        --data_in
        s_axis_data_tvalid  =>  I_upsample_rearrange_valid      ,
        s_axis_data_tready  =>  o_fir_lpf_ready                 ,
        s_axis_data_tuser(0)   =>  i_upsample_rearrange_frame   ,
        s_axis_data_tdata   =>  I_upsample_rearrange_data       ,
        
        m_axis_data_tvalid  =>  o_fir_lpf_valid                 ,
        m_axis_data_tuser(0)   =>  o_data_tuser                 ,
        m_axis_data_tdata   =>  o_fir_lpf_data_DUC              
        
        );
        
     process(i_clk_307)
     begin
         if (rising_edge(i_clk_307)) then
             o_fir_lpf_data                             <=  o_fir_lpf_data_DUC;--(31 downto 16);--o_fir_lpf_data_DUC(30 downto 15); --29-14
         end if;
     end process;
     
      -- 1 clk
     process(i_clk_307)
        begin   
            if (rising_edge(i_clk_307)) then
                o_lpf_frame                     <=  o_data_tuser;--lpf_frame(DLY_CNT-1);
                o_lpf_valid                     <=  o_fir_lpf_valid;--'1';
                o_lpf_data                      <=  o_fir_lpf_data_DUC;--(31 downto 16);
                o_fir_ready                     <=  o_fir_lpf_ready;
                
                --o_lpf_data                      <=  dsp_p_round(DATA_WIDTH+BINARY_POINT downto BINARY_POINT+1);
                
                dd_reset <= not d_reset;
            end if;
        end process;
     
    end generate ;
    
end Behavioral;
