------------------------------------------------------------------
-- Digital IF Power Measure (For RX ADC Output Power Measure
------------------------------------------------------------------
-- 2014.06.10, wj311.kim  : 1st release
------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity pwr_meas_switch is
generic(
    PATH_NUM                    : natural:= 4;
    CLK_DIV                     : natural:= 2; -- CLK_DIV = clock rate/data rate
    ACCUM_NUM_WIDTH             : natural:= 20;-- Number of samples to be averaged = 2^ACCUM_NUM_WIDTH
    DATA_WIDTH                  : natural:= 16 -- Data bits width
);
port(
    RESET                       : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_10MS                  : in  std_logic;
    FRAME_TDD                   : in  std_logic;

    DATA_IN_I                   : in  std_logic_array16(PATH_NUM-1 downto 0);
    DATA_IN_Q                   : in  std_logic_array16(PATH_NUM-1 downto 0);

    PWR_OUT                     : out std_logic_array32(PATH_NUM-1 downto 0)
);
end pwr_meas_switch;

architecture Behavioral of pwr_meas_switch is

--component dduc_pwr_meas is
--generic(
--    CLK_DIV                     : natural:= 2; -- CLK_DIV = clock rate/data rate
--    ACCUM_NUM_WIDTH             : natural:= 20;-- Number of samples to be averaged = 2^ACCUM_NUM_WIDTH
--    DATA_WIDTH                  : natural:= 16 -- Data bits width
--);
--port(
--    RESET                       : in  std_logic;
--    CLK                         : in  std_logic;
--
--    FRAME_SYNC                  : in  std_logic;-- 10ms strobe
--
--    DATA_IN_I                   : in  std_logic_vector(DATA_WIDTH-1 downto 0);
--    DATA_IN_Q                   : in  std_logic_vector(DATA_WIDTH-1 downto 0);
--
--    PWR_UPDATE_DONE             : out std_logic;
--    PWR_OUT                     : out std_logic_vector(2*DATA_WIDTH-1 downto 0)
--);
--end component;

component PWRMEAS_MANTISSA is
generic(
    DEVICE              : string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    CLK_DIV             : natural :=  2; -- CLK_DIV = (Clock Rate)/(Data Rate)
    DATA_WIDTH          : natural := 16  -- Data bit width
    );
port(
    RST                 : in  std_logic;
    CLK                 : in  std_logic;

    FRAME_SYNC_IN       : in  std_logic; -- BFN 10ms strobe
    TDD_SIG_IN          : in  std_logic; -- TDD strobe, DL : '1', UL : '0', when FDD mode, always set high

    DATA_I_IN           : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    DATA_Q_IN           : in  std_logic_vector(DATA_WIDTH-1 downto 0);

    PWR_UPDATE_DONE_OUT : out std_logic;
    PWR_OUT             : out std_logic_vector(31 downto 0)
    );
end component;

signal i_frame_10ms             : std_logic;

signal frame_10ms_d             : std_logic_vector(7 downto 0);
signal frame_10ms_dly           : std_logic;
signal frame_tdd_d              : std_logic_vector(7 downto 0);
signal frame_tdd_dly            : std_logic;
signal path_cnt                 : std_logic_vector(log2(PATH_NUM)-1 downto 0);

signal i_data_in_i              : std_logic_array16(PATH_NUM-1 downto 0);
signal i_data_in_q              : std_logic_array16(PATH_NUM-1 downto 0);
signal sw_data_out_i            : std_logic_vector(15 downto 0);
signal sw_data_out_q            : std_logic_vector(15 downto 0);

signal pwr_update_done          : std_logic;
signal i_pwr_out                : std_logic_vector(31 downto 0);

begin

    frame_10ms_dly <= frame_10ms_d(7);
    frame_tdd_dly  <= frame_tdd_d(7);
    process(CLK, RESET)
    begin
        if RESET = '1' then
            frame_10ms_d<= (others => '0');
            frame_tdd_d<= (others => '0');
        elsif rising_edge(CLK) then
            frame_10ms_d <= frame_10ms_d(6 downto 0) & FRAME_10MS;
            frame_tdd_d  <= frame_tdd_d(6 downto 0)  & FRAME_TDD;
        end if;
    end process;

    process(CLK, RESET)
    begin
        if RESET = '1' then
            path_cnt <= (others => '0');
        elsif rising_edge(CLK) then
            if frame_10ms_d(2 downto 1) = "01" then
                if path_cnt = PATH_NUM - 1 then
                    path_cnt <= (others => '0');
                else
                    path_cnt <= path_cnt + '1';
                end if;
            end if;
        end if;
    end process;

    process(CLK, RESET)
    begin
        if RESET = '1' then
            i_data_in_i <= (others => (others => '0'));
            i_data_in_q <= (others => (others => '0'));
        elsif rising_edge(CLK) then
            i_data_in_i <= DATA_IN_I;
            i_data_in_q <= DATA_IN_Q;
        end if;
    end process;

    process(CLK, RESET)
    begin
        if RESET = '1' then
            sw_data_out_i <= (others => '0');
            sw_data_out_q <= (others => '0');
        elsif rising_edge(CLK) then
            sw_data_out_i <= i_data_in_i(conv_integer(path_cnt));
            sw_data_out_q <= i_data_in_q(conv_integer(path_cnt));
        end if;
    end process;

    process(CLK, RESET)
    begin
        if RESET = '1' then
            PWR_OUT <= (others => (others => '0'));
        elsif rising_edge(CLK) then
            if pwr_update_done = '1' then
                PWR_OUT(conv_integer(path_cnt-'1')) <= i_pwr_out;
            end if;
        end if;
    end process;


u_PWRMEAS_MANTISSA : PWRMEAS_MANTISSA
generic map(
    DEVICE                      => DEVICE                       ,--: string  := "7SERIES"; -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    CLK_DIV                     => CLK_DIV                      ,--: natural :=  2; -- CLK_DIV = (Clock Rate)/(Data Rate)
    DATA_WIDTH                  => DATA_WIDTH                    --: natural := 16  -- Data bit width
)
port map(
    RST                         => RESET                        ,--: in  std_logic;
    CLK                         => CLK                          ,--: in  std_logic;

    FRAME_SYNC_IN               => frame_10ms_dly               ,--: in  std_logic; -- BFN 10ms strobe
    TDD_SIG_IN                  => frame_tdd_dly                ,--: in  std_logic; -- TDD strobe, DL : '1', UL : '0', when FDD mode, always set high

    DATA_I_IN                   => sw_data_out_i                ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
    DATA_Q_IN                   => sw_data_out_q                ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);

    PWR_UPDATE_DONE_OUT         => pwr_update_done              ,--: out std_logic;
    PWR_OUT                     => i_pwr_out                     --: out std_logic_vector(31 downto 0)
    );

--u_dduc_pwr_meas : dduc_pwr_meas
--generic map(
--    CLK_DIV                     => CLK_DIV                      ,--: natural:= 2; -- CLK_DIV = clock rate/data rate
--    ACCUM_NUM_WIDTH             => ACCUM_NUM_WIDTH              ,--: natural:= 20;-- Number of samples to be averaged = 2^ACCUM_NUM_WIDTH
--    DATA_WIDTH                  => DATA_WIDTH                    --: natural:= 16 -- Data bits width
--)
--port map(
--    RESET                       => RESET                        ,--: in  std_logic;
--    CLK                         => CLK                          ,--: in  std_logic;
--
--    FRAME_SYNC                  => frame_sync_dly               ,--: in  std_logic;-- 10ms strobe
--
--    DATA_IN_I                   => sw_data_out_i                ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
--    DATA_IN_Q                   => sw_data_out_q                ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);
--
--    PWR_UPDATE_DONE             => pwr_update_done              ,--: out std_logic;
--    PWR_OUT                     => i_pwr_out                     --: out std_logic_vector(2*DATA_WIDTH-1 downto 0)
--);

end Behavioral;
