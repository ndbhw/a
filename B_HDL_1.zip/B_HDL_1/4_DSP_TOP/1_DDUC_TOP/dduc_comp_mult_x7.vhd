--*****************************************************************************
--Compelx multiplier
--*****************************************************************************
------------------------------------------------------------------
-- 2014.11.26, wj311.kim  : Arria 10 Complex multiplier inferring
------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity dduc_comp_mult_x7 is
generic(
    WIDTH_IN                    : natural := 16;
    NCO_WIDTH_IN                : natural := 16;
    SUM_EN                      : natural := 0;
    HOVS                        : natural := 1;
    BINARY_POINT                : natural := 15
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    SINE_CONJUGATE              : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    DATA_IN_I                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_IN_Q                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_IN_COS                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);
    DATA_IN_SIN                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    DATA_OUT_I                  : out std_logic_vector(WIDTH_IN+NCO_WIDTH_IN-1 downto 0);
    DATA_OUT_Q                  : out std_logic_vector(WIDTH_IN+NCO_WIDTH_IN-1 downto 0)
);
end dduc_comp_mult_x7;

architecture Behavioral of dduc_comp_mult_x7 is

component dduc_delay_chain is
generic(
    BUFF_DEPTH                  : natural:= 16;-- SRL16E
    DIRECTION                   : natural:= 1; -- 1:forward, 0:reverse
    WIDTH_IN                    : natural:= 16 -- Input data width
);
port(
    CLK                         : in  std_logic;
    DATA_SEL                    : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

component dduc_cmult_h1_p
generic (
    BINARY_POINT                : natural   := 15
);
port(
    CLK                         : in std_logic;
    A_DATA                      : in std_logic_vector(15 downto 0);
    B_DATA                      : in std_logic_vector(15 downto 0);
    D_DATA                      : in std_logic_vector(15 downto 0);
    RESULT                      : out std_logic_vector(31 downto 0)
);
end component;

component dduc_cmult_h1_i
port(
    CLK                         : in std_logic;
    SINE_CONJUGATE              : in std_logic;
    A_DATA                      : in std_logic_vector(15 downto 0);
    B_DATA                      : in std_logic_vector(15 downto 0);
    C_DATA                      : in std_logic_vector(31 downto 0);
    D_DATA                      : in std_logic_vector(15 downto 0);
    RESULT                      : out std_logic_vector(32 downto 0)
);
end component;

component dduc_cmult_h1_q
port(
    CLK                         : in std_logic;
    SINE_CONJUGATE              : in std_logic;
    A_DATA                      : in std_logic_vector(15 downto 0);
    B_DATA                      : in std_logic_vector(15 downto 0);
    C_DATA                      : in std_logic_vector(31 downto 0);
    D_DATA                      : in std_logic_vector(15 downto 0);
    RESULT                      : out std_logic_vector(32 downto 0)
);
end component;

component dduc_cmult_h2_i IS
port(
    CLK                         : in std_logic;
    SEL                         : in std_logic_vector(1 downto 0);
    A_DATA                      : in std_logic_vector(15 downto 0);
    B_DATA                      : in std_logic_vector(15 downto 0);
    RESULT                      : out std_logic_vector(32 downto 0)
);
end component;

component dduc_cmult_h2_q IS
port(
    CLK                         : in std_logic;
    SEL                         : in std_logic_vector(1 downto 0);
    A_DATA                      : in std_logic_vector(15 downto 0);
    B_DATA                      : in std_logic_vector(15 downto 0);
    RESULT                      : out std_logic_vector(32 downto 0)
);
end component;

component dduc_cmult_h4_iq IS
port(
    CLK                         : in std_logic;
    SEL                         : in std_logic_vector(1 downto 0);
    A_DATA                      : in std_logic_vector(15 downto 0);
    B_DATA                      : in std_logic_vector(15 downto 0);
    RESULT                      : out std_logic_vector(32 downto 0)
);
end component;

constant COMM_WAIT_DELAY        : integer := 2;-- wait 2 clock for calculating common term(HOPS=2), wait time mux iq(HOVS=1)
constant HOVS_INT               : integer := ternary_func(HOVS=1,1,ternary_func(HOVS=2,2,4));
constant DSP_LATENCY            : integer := 3+HOVS_INT+COMM_WAIT_DELAY+ternary_func(HOVS=1,2,0);-- 3+HOVS : DSP input to output processing delay

signal frame_in_d               : std_logic_vector(DSP_LATENCY-1 downto 0);
signal valid_in_d               : std_logic_vector(DSP_LATENCY-1 downto 0);

signal data_in_i_sh             : std_logic_vector(WIDTH_IN-1 downto 0);
signal data_in_q_sh             : std_logic_vector(WIDTH_IN-1 downto 0);
signal data_in_cos_sh           : std_logic_vector(WIDTH_IN-1 downto 0);
signal data_in_sin_sh           : std_logic_vector(WIDTH_IN-1 downto 0);
signal data_in_i_d              : std_logic_vector(WIDTH_IN-1 downto 0);
signal data_in_q_d              : std_logic_vector(WIDTH_IN-1 downto 0);
signal data_in_cos_d            : std_logic_vector(WIDTH_IN-1 downto 0);
signal data_in_sin_d            : std_logic_vector(WIDTH_IN-1 downto 0);
signal data_in_i_d_sh           : std_logic_vector(WIDTH_IN-1 downto 0);
signal data_in_q_d_sh           : std_logic_vector(WIDTH_IN-1 downto 0);
signal data_in_cos_d_sh         : std_logic_vector(WIDTH_IN-1 downto 0);
signal data_in_sin_d_sh         : std_logic_vector(WIDTH_IN-1 downto 0);
signal p1                       : std_logic_vector(31 downto 0);
signal p1_sh                    : std_logic_vector(31 downto 0);
signal i_out                    : std_logic_vector(32 downto 0);
signal q_out                    : std_logic_vector(32 downto 0);
signal n_sine_conjugate         : std_logic;

signal dsp_i_out_temp           : std_logic_vector(WIDTH_IN+NCO_WIDTH_IN-1 downto 0);
signal dsp_i_out                : std_logic_vector(32 downto 0);
signal dsp_q_out                : std_logic_vector(32 downto 0);

signal dsp_i_in_a               : std_logic_vector(WIDTH_IN-1 downto 0);
signal dsp_i_in_b               : std_logic_vector(WIDTH_IN-1 downto 0);
signal dsp_q_in_a               : std_logic_vector(WIDTH_IN-1 downto 0);
signal dsp_q_in_b               : std_logic_vector(WIDTH_IN-1 downto 0);
signal dsp_sel_init             : std_logic;
signal dsp_sel                  : std_logic_vector(1 downto 0);

signal dsp_iq_in_a              : std_logic_vector(WIDTH_IN-1 downto 0);
signal dsp_iq_in_b              : std_logic_vector(WIDTH_IN-1 downto 0);
signal dsp_iq_out               : std_logic_vector(32 downto 0);

begin

    -- Frame/Valid delay
    FRAME_O <= frame_in_d(frame_in_d'high);
    VALID_O <= ternary_func(SUM_EN=1, frame_in_d(frame_in_d'high), valid_in_d(valid_in_d'high));-- if HOVS=2, divide valid signal rate by 2
    process(RST, CLK)
    begin
        if RST = '1' then
            frame_in_d <= (others => '0');
            valid_in_d <= (others => '0');
        elsif rising_edge(CLK) then
            frame_in_d <= frame_in_d(frame_in_d'length-2 downto 0) & FRAME_I;
            valid_in_d <= valid_in_d(valid_in_d'length-2 downto 0) & VALID_I;
        end if;
    end process;

    process(CLK, RST)
    begin
        if RST = '1' then
            data_in_i_sh   <= (others=>'0');
            data_in_q_sh   <= (others=>'0');
            data_in_cos_sh <= (others=>'0');
            data_in_sin_sh <= (others=>'0');
        elsif rising_edge(CLK) then
            if VALID_I = '1' then
                data_in_i_sh   <= DATA_IN_I;
                data_in_q_sh   <= DATA_IN_Q;
                data_in_cos_sh <= DATA_IN_COS;
                data_in_sin_sh <= DATA_IN_SIN;
            end if;
        end if;
    end process;

    GEN_HOVS_1 : if HOVS = 1 generate
        u_delay_i : dduc_delay_chain
        generic map(
            BUFF_DEPTH                  => 16                           ,--: natural:= 16;-- SRL16E
            DIRECTION                   => 0                            ,--: natural:= 1: -- 1:forward, 0:reverse
            WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;
            DATA_SEL                    => std_logic_vector(to_unsigned(COMM_WAIT_DELAY-1, 4)),--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
            VALID_I                     => '1'                          ,--: in  std_logic;
            FILTER_IN                   => data_in_i_sh                 ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
            FILTER_OUT                  => data_in_i_d                   --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );

        u_delay_q : dduc_delay_chain
        generic map(
            BUFF_DEPTH                  => 16                           ,--: natural:= 16;-- SRL16E
            DIRECTION                   => 0                            ,--: natural:= 1: -- 1:forward, 0:reverse
            WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;
            DATA_SEL                    => std_logic_vector(to_unsigned(COMM_WAIT_DELAY-1, 4)),--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
            VALID_I                     => '1'                          ,--: in  std_logic;
            FILTER_IN                   => data_in_q_sh                 ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
            FILTER_OUT                  => data_in_q_d                   --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );

        u_delay_cos : dduc_delay_chain
        generic map(
            BUFF_DEPTH                  => 16                           ,--: natural:= 16;-- SRL16E
            DIRECTION                   => 0                            ,--: natural:= 1: -- 1:forward, 0:reverse
            WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;
            DATA_SEL                    => std_logic_vector(to_unsigned(COMM_WAIT_DELAY-1, 4)),--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
            VALID_I                     => '1'                          ,--: in  std_logic;
            FILTER_IN                   => data_in_cos_sh               ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
            FILTER_OUT                  => data_in_cos_d                 --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );

        u_delay_sin : dduc_delay_chain
        generic map(
            BUFF_DEPTH                  => 16                           ,--: natural:= 16;-- SRL16E
            DIRECTION                   => 0                            ,--: natural:= 1: -- 1:forward, 0:reverse
            WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;
            DATA_SEL                    => std_logic_vector(to_unsigned(COMM_WAIT_DELAY-1, 4)),--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
            VALID_I                     => '1'                          ,--: in  std_logic;
            FILTER_IN                   => data_in_sin_sh               ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
            FILTER_OUT                  => data_in_sin_d                 --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );

        -- P1=cos*(I+Q) -> C*(A+B)
        u_dduc_cmult_h1_p : dduc_cmult_h1_p
        generic map(
            BINARY_POINT                => BINARY_POINT                  --: std_logic := '1'
        )
        port map (
            CLK                         => CLK                          ,--: in std_logic;
            A_DATA                      => data_in_q_sh                 ,--: in std_logic_vector(15 downto 0);
            B_DATA                      => data_in_cos_sh               ,--: in std_logic_vector(15 downto 0);
            D_DATA                      => data_in_i_sh                 ,--: in std_logic_vector(15 downto 0);
            RESULT                      => p1                            --: out std_logic_vector(31 downto 0)
        );

        process(CLK, RST)
        begin
            if RST = '1' then
                p1_sh <= (others=>'0');
                data_in_i_d_sh   <= (others=>'0');
                data_in_q_d_sh   <= (others=>'0');
                data_in_cos_d_sh <= (others=>'0');
                data_in_sin_d_sh <= (others=>'0');
            elsif rising_edge(CLK) then
                p1_sh <= p1;
                data_in_i_d_sh   <= data_in_i_d;
                data_in_q_d_sh   <= data_in_q_d;
                data_in_cos_d_sh <= data_in_cos_d;
                data_in_sin_d_sh <= data_in_sin_d;
            end if;
        end process;

        -- I=P1-Q*(cos+sin) -> P1-B*(C+D)
        u_dduc_cmult_h1_i : dduc_cmult_h1_i
        port map (
            CLK                         => CLK                          ,--: in std_logic;
            SINE_CONJUGATE              => SINE_CONJUGATE               ,--: in std_logic;
            A_DATA                      => data_in_sin_d_sh             ,--: in std_logic_vector(15 downto 0);
            B_DATA                      => data_in_q_d_sh               ,--: in std_logic_vector(15 downto 0);
            C_DATA                      => p1_sh                        ,--: in std_logic_vector(31 downto 0);
            D_DATA                      => data_in_cos_d_sh             ,--: in std_logic_vector(15 downto 0);
            RESULT                      => i_out                         --: out std_logic_vector(32 downto 0)
        );

        -- Q=P1-I*(cos-sin)
        n_sine_conjugate <= not SINE_CONJUGATE;

        u_dduc_cmult_h1_q : dduc_cmult_h1_q
        port map (
            CLK                         => CLK                          ,--: in std_logic;
            SINE_CONJUGATE              => n_sine_conjugate             ,--: in std_logic;
            A_DATA                      => data_in_sin_d_sh             ,--: in std_logic_vector(15 downto 0);
            B_DATA                      => data_in_i_d_sh               ,--: in std_logic_vector(15 downto 0);
            C_DATA                      => p1_sh                        ,--: in std_logic_vector(31 downto 0);
            D_DATA                      => data_in_cos_d_sh             ,--: in std_logic_vector(15 downto 0);
            RESULT                      => q_out                         --: out std_logic_vector(32 downto 0)
        );

        DATA_OUT_I <= sign_copy(i_out, WIDTH_IN+NCO_WIDTH_IN);
        DATA_OUT_Q <= sign_copy(q_out, WIDTH_IN+NCO_WIDTH_IN);

    end generate GEN_HOVS_1;

    GEN_HOVS_2 : if HOVS = 2 generate
        -- DSP I data input
        process(CLK, RST)
        begin
            if RST = '1' then
                dsp_i_in_a <= (others => '0');
                dsp_i_in_b <= (others => '0');
            elsif rising_edge(CLK) then
                if valid_in_d(0) = '1' then
                    dsp_i_in_a <= data_in_i_sh;
                    dsp_i_in_b <= data_in_cos_sh;
                else
                    dsp_i_in_a <= data_in_q_sh;
                    dsp_i_in_b <= data_in_sin_sh;
                end if;
            end if;
        end process;

        -- DSP Q data input
        process(CLK, RST)
        begin
            if RST = '1' then
                dsp_q_in_a <= (others => '0');
                dsp_q_in_b <= (others => '0');
            elsif rising_edge(CLK) then
                if valid_in_d(0) = '1' then
                    dsp_q_in_a <= data_in_i_sh;
                    dsp_q_in_b <= data_in_sin_sh;
                else
                    dsp_q_in_a <= data_in_q_sh;
                    dsp_q_in_b <= data_in_cos_sh;
                end if;
            end if;
        end process;

        dsp_sel_init <= ternary_func(SUM_EN=1, frame_in_d(2), valid_in_d(2));
        process(CLK, RST)
        begin
            if RST = '1' then
                dsp_sel    <= (others => '0');
            elsif rising_edge(CLK) then
                if dsp_sel_init = '1' then
                    dsp_sel <= (others => '0');
                else
                    dsp_sel <= dsp_sel + 1;
                end if;
            end if;
        end process;

        DATA_OUT_I <= sign_copy(dsp_i_out, WIDTH_IN+NCO_WIDTH_IN);
        DATA_OUT_Q <= sign_copy(dsp_q_out, WIDTH_IN+NCO_WIDTH_IN);

        u_dduc_cmult_h2_i : dduc_cmult_h2_i
        port map(
            CLK                         => CLK                          ,--: in std_logic;
            SEL                         => dsp_sel                      ,--: in std_logic_vector(1 downto 0);
            A_DATA                      => dsp_i_in_a                   ,--: in std_logic_vector(15 downto 0);
            B_DATA                      => dsp_i_in_b                   ,--: in std_logic_vector(15 downto 0);
            RESULT                      => dsp_i_out                     --: out std_logic_vector(32 downto 0)
        );

        u_dduc_cmult_h2_q : dduc_cmult_h2_q
        port map(
            CLK                         => CLK                          ,--: in std_logic;
            SEL                         => dsp_sel                      ,--: in std_logic_vector(1 downto 0);
            A_DATA                      => dsp_q_in_a                   ,--: in std_logic_vector(15 downto 0);
            B_DATA                      => dsp_q_in_b                   ,--: in std_logic_vector(15 downto 0);
            RESULT                      => dsp_q_out                     --: out std_logic_vector(32 downto 0)
        );
    end generate GEN_HOVS_2;

    GEN_HOVS_4 : if HOVS >= 4 generate
        -- DSP I data input
        process(CLK, RST)
        begin
            if RST = '1' then
                dsp_iq_in_a <= (others => '0');
                dsp_iq_in_b <= (others => '0');
            elsif rising_edge(CLK) then
                if valid_in_d(0) = '1' then
                    dsp_iq_in_a <= data_in_i_sh;
                    dsp_iq_in_b <= data_in_cos_sh;
                elsif valid_in_d(1) = '1' then
                    dsp_iq_in_a <= data_in_q_sh;
                    dsp_iq_in_b <= data_in_sin_sh;
                elsif valid_in_d(2) = '1' then
                    dsp_iq_in_a <= data_in_i_sh;
                    dsp_iq_in_b <= data_in_sin_sh;
                elsif valid_in_d(3) = '1' then
                    dsp_iq_in_a <= data_in_q_sh;
                    dsp_iq_in_b <= data_in_cos_sh;
                end if;
            end if;
        end process;

        dsp_sel_init <= ternary_func(SUM_EN=1, frame_in_d(2), valid_in_d(2));

        process(CLK, RST)
        begin
            if RST = '1' then
                dsp_sel    <= (others => '0');
            elsif rising_edge(CLK) then
                if dsp_sel_init = '1' then
                    dsp_sel <= (others => '0');
                else
                    dsp_sel <= dsp_sel + 1;
                end if;
            end if;
        end process;

        DATA_OUT_I <= dsp_i_out_temp;
        DATA_OUT_Q <= sign_copy(dsp_iq_out, WIDTH_IN+NCO_WIDTH_IN);
        process(CLK, RST)
        begin
            if RST = '1' then
                dsp_i_out_temp <= (others => '0');
            elsif rising_edge(CLK) then
                if valid_in_d(DSP_LATENCY-1-HOVS_INT/2) = '1' then-- i data latch
                    dsp_i_out_temp <= sign_copy(dsp_iq_out, WIDTH_IN+NCO_WIDTH_IN);
                end if;
            end if;
        end process;

        u_dduc_cmult_h4_iq : dduc_cmult_h4_iq
        port map(
            CLK                         => CLK                          ,--: in std_logic;
            SEL                         => dsp_sel                      ,--: in std_logic_vector(1 downto 0);
            A_DATA                      => dsp_iq_in_a                  ,--: in std_logic_vector(15 downto 0);
            B_DATA                      => dsp_iq_in_b                  ,--: in std_logic_vector(15 downto 0);
            RESULT                      => dsp_iq_out                    --: out std_logic_vector(32 downto 0)
        );
    end generate GEN_HOVS_4;

end Behavioral;
