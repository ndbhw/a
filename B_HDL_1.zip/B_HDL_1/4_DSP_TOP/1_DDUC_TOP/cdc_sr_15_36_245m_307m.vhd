-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2023, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2023.11.14 v1.0] Initial release
-- *****************************************************************************

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

entity cdc_sr_15_36_245m_307m is
    generic (
        DATA_WIDTH                          : integer := 16
    );
    Port ( 
        i_rst_245                           : in std_logic;
        i_clk_245                           : in std_logic;
        i_clk_307                           : in std_logic;

        i_mode                              : in std_logic_vector(4-1 downto 0);

        -- case BW5, BW10
        i_hbf_frame                         : in std_logic;
        i_hbf_valid                         : in std_logic;
        i_hbf_data                          : in std_logic_vector(DATA_WIDTH-1 downto 0);

        -- case BW15, BW20
        i_pfir_frame                        : in std_logic;
        i_pfir_valid                        : in std_logic;
        i_pfir_data                         : in std_logic_vector(DATA_WIDTH-1 downto 0);

        -- 15.36MHz, 4 channel
        o_cdc_15_36_frame                   : out std_logic;
        o_cdc_15_36_valid                   : out std_logic;
        o_cdc_15_36_data                    : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end cdc_sr_15_36_245m_307m;

architecture Behavioral of cdc_sr_15_36_245m_307m is

    component lib_xpm_sdpram is
        generic (
            MEMORY_TYPE                     : string := "block";
            CLOCK_MODE                      : string := "independent_clock";  -- "independent_clock" or "common_clock"
            RD_LATENCY                      : integer := 2;
            WT_DATA_WIDTH                   : integer := 16;
            RD_DATA_WIDTH                   : integer := 16;
            WT_ADDR_WIDTH                   : integer := 3;
            RD_ADDR_WIDTH                   : integer := 3
        );
        Port (
            i_clk_a                         : in std_logic;
            i_clk_b                         : in std_logic;
            
            i_wt_enable                     : in std_logic;
            i_wt_addra                      : in std_logic_vector(WT_ADDR_WIDTH-1 downto 0);
            i_wt_data                       : in std_logic_vector(WT_DATA_WIDTH-1 downto 0);
            
            i_rd_addrb                      : in std_logic_vector(RD_ADDR_WIDTH-1 downto 0);
            o_rd_doutb                      : out std_logic_vector(RD_DATA_WIDTH-1 downto 0)
        );
    end component;

    constant MEM_LATENCY                    : integer := 2;
    constant MEM_ADDR_W                     : integer := 10;
    constant MEM_DATA_W                     : integer := DATA_WIDTH+2;

    signal i_hbf_frame_d                    : std_logic;
    signal i_hbf_valid_d                    : std_logic;
    signal i_hbf_data_d                     : std_logic_vector(DATA_WIDTH-1 downto 0);

    signal i_pfir_frame_d                   : std_logic;
    signal i_pfir_valid_d                   : std_logic;
    signal i_pfir_data_d                    : std_logic_vector(DATA_WIDTH-1 downto 0);

    signal wt_enable                        : std_logic;
    signal wt_addra                         : std_logic_vector(MEM_ADDR_W-1 downto 0);
    signal wt_data                          : std_logic_vector(MEM_DATA_W-1 downto 0);
    
    signal rd_flag                          : std_logic;
    signal cnt_5                            : std_logic_vector(3-1 downto 0);
    signal rd_flag_reg                      : std_logic_vector(2-1 downto 0);
    signal rd_valid_reg                     : std_logic_vector(MEM_LATENCY downto 0);
    signal rd_addrb                         : std_logic_vector(MEM_ADDR_W-1 downto 0);
    signal rd_doutb                         : std_logic_vector(MEM_DATA_W-1 downto 0);
    
    signal cdc_15_36_frame                  : std_logic;
        
    signal mode_d                           : std_logic_vector(3 downto 0);

begin

    process(i_clk_245)
    begin
        if (rising_edge(i_clk_245)) then
            i_hbf_frame_d                   <=  i_hbf_frame;
            i_hbf_valid_d                   <=  i_hbf_valid;
            i_hbf_data_d                    <=  i_hbf_data;

            i_pfir_frame_d                  <=  i_pfir_frame;
            i_pfir_valid_d                  <=  i_pfir_valid;
            i_pfir_data_d                   <=  i_pfir_data;
        end if;
    end process;

    process(i_rst_245, i_clk_245)
    begin
        if (i_rst_245 = '1') then
            wt_enable                       <=  '0';
        elsif (rising_edge(i_clk_245)) then
            mode_d                          <=  i_mode;
            case (mode_d) is
                when X"2" => -- BW5
                    wt_enable               <=  i_hbf_valid_d;
                    wt_data                 <=  i_hbf_frame_d & i_hbf_valid_d & i_hbf_data_d;

                when X"3" => -- BW10
                    wt_enable               <=  i_hbf_valid_d;
                    wt_data                 <=  i_hbf_frame_d & i_hbf_valid_d & i_hbf_data_d;

                when X"4" => -- BW15
                    wt_enable               <=  i_pfir_valid_d;
                    wt_data                 <=  i_pfir_frame_d & i_pfir_valid_d & i_pfir_data_d;
                    
                when X"5" => -- BW20
                    wt_enable               <=  i_pfir_valid_d;
                    wt_data                 <=  i_pfir_frame_d & i_pfir_valid_d & i_pfir_data_d;
                    
                when others =>
                    wt_enable               <=  '0';
                    wt_data                 <=  (others=>'0');
            end case;
        end if;
    end process;

    process(i_rst_245, i_clk_245)
    begin
        if (i_rst_245 = '1') then
            wt_addra                        <=  (others=>'0');
        elsif (rising_edge(i_clk_245)) then
            if (wt_enable = '1') then                                   -- addr count up every 4clk @ 245.76MHz
                wt_addra                    <=  wt_addra + '1';
            else
                wt_addra                    <=  wt_addra;
            end if;

            if (wt_addra = conv_std_logic_vector(8,MEM_ADDR_W)) then
                rd_flag                     <=  '1';
            else
                rd_flag                     <=  '0';
            end if;
        end if;
    end process;

    process(i_clk_307)
    begin
        if (rising_edge(i_clk_307)) then
            rd_flag_reg                             <=  rd_flag_reg(0) & rd_flag;
            rd_valid_reg(MEM_LATENCY downto 1)     <=  rd_valid_reg(MEM_LATENCY-1 downto 0);

            if (rd_flag_reg = b"01" or cnt_5(2) = '1') then
                cnt_5                       <=  (others=>'0');
                rd_valid_reg(0)             <=  '1';
            else
                cnt_5                       <=  cnt_5 + '1';
                rd_valid_reg(0)             <=  '0';
            end if;

            if (rd_flag_reg = b"01") then
                rd_addrb                    <=  (others=>'0');
            elsif ((cnt_5(0) = '1')) then          --old cnt_5(2)                       -- addr count up every 5clk @ 307.2MHz
                rd_addrb                    <=  rd_addrb + '1';
            else
                rd_addrb                    <=  rd_addrb;
            end if;
        end if;
    end process;

    cdc_buffer : lib_xpm_sdpram generic map ("block","independent_clock",MEM_LATENCY,MEM_DATA_W,MEM_DATA_W,MEM_ADDR_W,MEM_ADDR_W)
        Port map (
            i_clk_a                         =>  i_clk_245,              --: in std_logic;
            i_clk_b                         =>  i_clk_307,              --: in std_logic;
            
            i_wt_enable                     =>  wt_enable,              --: in std_logic;
            i_wt_addra                      =>  wt_addra,               --: in std_logic_vector(WT_ADDR_WIDTH-1 downto 0);
            i_wt_data                       =>  wt_data,                --: in std_logic_vector(WT_DATA_WIDTH-1 downto 0);
            
            i_rd_addrb                      =>  rd_addrb,               --: in std_logic_vector(RD_ADDR_WIDTH-1 downto 0);
            o_rd_doutb                      =>  rd_doutb                --: out std_logic_vector(RD_DATA_WIDTH-1 downto 0)
        );

    process(i_clk_307)
    begin
        if (rising_edge(i_clk_307)) then
            -- bram latency n clk
            if ((rd_valid_reg(0) = '1') or (rd_valid_reg(2) = '1')) then 
                o_cdc_15_36_frame           <=  rd_doutb(MEM_DATA_W-1);
                cdc_15_36_frame             <=  rd_doutb(MEM_DATA_W-1);
                o_cdc_15_36_valid           <=  rd_doutb(MEM_DATA_W-2);
                o_cdc_15_36_data            <=  rd_doutb(MEM_DATA_W-3 downto 0);
            else
                o_cdc_15_36_frame           <=  '0';
                o_cdc_15_36_valid           <=  '0';
                o_cdc_15_36_data            <=  (others=>'0');          -- upsample x5
            end if;
        end if;
    end process;

end Behavioral;
