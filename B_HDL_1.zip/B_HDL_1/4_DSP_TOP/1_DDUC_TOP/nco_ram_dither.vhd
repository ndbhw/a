library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
use ieee.numeric_std.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;
use work.pkg_prbs.all;

entity nco_ram_dither is
generic(
    VENDOR          :string :="XILINX";
    ACCU_VAL        :natural:=122880;
    WIDTH           :natural:=16;
    PRBS_SEL        :natural:=20;
    HOVS            :natural:=1;
    CHANNEL_NUMBERS :natural:=1
);
port(
    RST             :in  std_logic;
    CLK             :in  std_logic;

    FS              :in  std_logic;         -- fs=1 then restart channel number from 0 to channel_numbers-1

    NCO_WREN        :in  std_logic_vector(CHANNEL_NUMBERS-1 downto 0);
    FREQ_OFF        :in  std_logic_vector(CHANNEL_NUMBERS*log2(ACCU_VAL)-1 downto 0);-- offset

    COS_O           :out std_logic_vector(WIDTH-1 downto 0);
    SIN_O           :out std_logic_vector(WIDTH-1 downto 0)
);
end nco_ram_dither;

architecture rtl of nco_ram_dither is

component dduc_delay_chain is
    generic(
        BUFF_DEPTH                  : natural:= 16;-- SRL16E
        DIRECTION                   : natural:= 1; -- 1:forward, 0:reverse
        WIDTH_IN                    : natural:= 16 -- Input data width
    );
    port(
        CLK                         : in  std_logic;
        DATA_SEL                    : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
        VALID_I                     : in  std_logic;
        FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
        FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
    );
    end component;
    
    component nco_ram_x_122_dither is
    generic(
        DATA_WIDTH                  : natural := 15;
        ADDR_WIDTH                  : natural := 12
    );
    port(
        CLK                         : in  std_logic;
        ADDR_A                      : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
        ADDR_B                      : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
        Q_A                         : out std_logic_vector((DATA_WIDTH -1) downto 0);
        Q_B                         : out std_logic_vector((DATA_WIDTH -1) downto 0)
    );
    end component;
    
    component nco_ram_x_153_dither is
    generic(
        DATA_WIDTH                  : natural := 15;
        ADDR_WIDTH                  : natural := 12
    );
    port(
        CLK                         : in  std_logic;
        ADDR_A                      : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
        ADDR_B                      : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
        Q_A                         : out std_logic_vector((DATA_WIDTH -1) downto 0);
        Q_B                         : out std_logic_vector((DATA_WIDTH -1) downto 0)
    );
    end component;
    
    component nco_ram_a_122_dither is
    generic(
        DATA_WIDTH                  : natural := 15;
        ADDR_WIDTH                  : natural := 12
    );
    port(
        CLK                         : in  std_logic;
        ADDR_A                      : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
        ADDR_B                      : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
        Q_A                         : out std_logic_vector((DATA_WIDTH -1) downto 0);
        Q_B                         : out std_logic_vector((DATA_WIDTH -1) downto 0)
    );
    end component;
    
    constant HOVS_CH_WIDTH          : integer := ternary_func(HOVS*CHANNEL_NUMBERS=1, 1, log2(HOVS*CHANNEL_NUMBERS));
    constant RAM_DEPTH_WIDTH        : integer := 14;
    constant PRBS_WIDTH             : integer := log2(ACCU_VAL)-RAM_DEPTH_WIDTH;
    constant PROC_DELAY             : integer := 9;--(processing delay  8 CLK + channel number 1 CLK advanced)
    constant ones                   : std_logic_vector(RAM_DEPTH_WIDTH-3 downto 0):=(others => '1');
    constant CH_INIT_VALUE          : std_logic_vector(HOVS_CH_WIDTH-1 downto 0):= std_logic_vector(to_unsigned((PROC_DELAY mod (HOVS*CHANNEL_NUMBERS)), HOVS_CH_WIDTH));
    constant ROM_DLY                : integer := 3+2;
    
    type accu_wdith_ary             is array(natural range <>) of std_logic_vector(log2(ACCU_VAL)-1 downto 0);
    type accu_wdith_ary_p1          is array(natural range <>) of std_logic_vector(log2(ACCU_VAL)+1-1 downto 0);
    
    signal ram_out_sin              : std_logic_vector(WIDTH-2 downto 0);
    signal ram_out_cos              : std_logic_vector(WIDTH-2 downto 0);
    
    --signal sin                      : std_logic_vector(WIDTH-1 downto 0);
    --signal cos                      : std_logic_vector(WIDTH-1 downto 0);
    signal sin_p                    : std_logic_vector(WIDTH-1 downto 0);
    signal cos_p                    : std_logic_vector(WIDTH-1 downto 0);
    signal sin_n                    : std_logic_vector(WIDTH-1 downto 0);
    signal cos_n                    : std_logic_vector(WIDTH-1 downto 0);
    
    signal hovs_ch_cnt              : std_logic_vector(HOVS_CH_WIDTH-1 downto 0);
    signal re_sync                  : std_logic;
    
    signal angle_tmp                : std_logic_vector(RAM_DEPTH_WIDTH+PRBS_WIDTH-1 downto 0);
    signal angle_mod_bf             : std_logic_vector(RAM_DEPTH_WIDTH+PRBS_WIDTH-1 downto 0);
    signal angle_mod                : std_logic_vector(RAM_DEPTH_WIDTH+PRBS_WIDTH-1 downto 0);
    signal angle                    : std_logic_vector(RAM_DEPTH_WIDTH-1 downto 0);
    signal angle90                  : std_logic_vector(RAM_DEPTH_WIDTH-3 downto 0);
    signal ch_numi                  : std_logic_vector(ternary_func(CHANNEL_NUMBERS=1, 1, log2(CHANNEL_NUMBERS))-1 downto 0);
    
    signal accumulator              : accu_wdith_ary_p1(CHANNEL_NUMBERS-1 downto 0);
        
    signal prbs                     : std_logic_vector(19 downto 0);
    signal dither                   : std_logic_vector(19 downto 0);
    
    signal quadrant                 : std_logic_vector(1 downto 0);
    --signal quadrant_sh              : std_logic_vector(1 downto 0);
    
    signal addr_sin                 : std_logic_vector(RAM_DEPTH_WIDTH-3 downto 0);
    signal addr_cos                 : std_logic_vector(RAM_DEPTH_WIDTH-3 downto 0);
    
    signal w_addr_sin               : std_logic_vector(RAM_DEPTH_WIDTH-3 downto 0);
    signal w_addr_cos               : std_logic_vector(RAM_DEPTH_WIDTH-3 downto 0);
    
    signal nco_wren_d               : std_logic_array3(CHANNEL_NUMBERS-1 downto 0);
    signal nco_wren_auto_rec        : std_logic_vector(31 downto 0);
    
    signal nco_wren_fs              : std_logic_vector(CHANNEL_NUMBERS-1 downto 0);
    signal nco_update_sync          : std_logic_vector(CHANNEL_NUMBERS-1 downto 0);
    signal nco_update               : std_logic_vector(CHANNEL_NUMBERS-1 downto 0);
    signal nco_update_sh            : std_logic_vector(CHANNEL_NUMBERS-1 downto 0);
    signal freq_off_i               : accu_wdith_ary(CHANNEL_NUMBERS-1 downto 0);
    signal freq_off_i_d             : accu_wdith_ary(CHANNEL_NUMBERS-1 downto 0);
    
    signal unsigned_freq_off        : accu_wdith_ary(CHANNEL_NUMBERS-1 downto 0);
    signal unsigned_freq_off_d      : accu_wdith_ary(CHANNEL_NUMBERS-1 downto 0);
    signal freq_word_s              : std_logic_vector(log2(ACCU_VAL)-1 downto 0);
    signal freq_word_s_1d           : std_logic_vector(log2(ACCU_VAL)-1 downto 0);
    signal freq_word_s_2d           : std_logic_vector(log2(ACCU_VAL)-1 downto 0);
    signal hovs_start               : std_logic;
    
    signal flag_accumulator_over    : std_logic;
begin

    process(RST, CLK)
    begin
        if (RST = '1') then
            nco_wren_auto_rec           <= x"0000FFFF";
        elsif (rising_edge(CLK)) then
            nco_wren_auto_rec           <= nco_wren_auto_rec(30 downto 0) & '0';
        end if;
    end process;

    CH_DATA_GEN : for N in 0 to CHANNEL_NUMBERS-1 generate
        -- When RST, NCO freq_word should be updated
        -- Automatical wren generation
        process(RST, CLK)
        begin
            if (RST = '1') then
                nco_wren_d(N)           <= (others => '0');
                nco_wren_fs(N)          <= '0';
            elsif (rising_edge(CLK)) then
                nco_wren_d(N)           <= nco_wren_d(N)(1 downto 0) & (nco_wren_auto_rec(31) or NCO_WREN(N));
                -- nco write enable, synchronized with 'fs'
                if (nco_wren_d(N)(2 downto 1) = b"01") then
                    nco_wren_fs(N)      <= '1';
                elsif (hovs_ch_cnt = HOVS*CHANNEL_NUMBERS-1) then
                    nco_wren_fs(N)      <= '0';
                end if;
            end if;
        end process;

        -- nco_update_sync should be asserted for only 1 fs time (start/end after fs assertion)
        process(RST, CLK)
        begin
            if (RST = '1') then
                nco_update_sync(N)          <= '0';
            elsif (rising_edge(CLK)) then
                if (hovs_ch_cnt = HOVS*CHANNEL_NUMBERS-1) then
                    if (nco_wren_fs(N) = '1') then
                        nco_update_sync(N)  <= '1';
                    else
                        nco_update_sync(N)  <= '0';
                    end if;
                end if;
            end if;
        end process;

        -- nco update 1 CLK pulse generation
        process(RST, CLK)
        begin
            if (RST = '1') then
                nco_update(N)               <= '0';
            elsif (rising_edge(CLK)) then
                if (ch_numi = N and nco_update_sync(N) = '1') then
                    nco_update(N)           <= '1';
                else
                    nco_update(N)           <= '0';
                end if;
            end if;
        end process;

        -- freq_off_i(N) <= FREQ_OFF(log2(ACCU_VAL)*(N+1)-1 downto log2(ACCU_VAL)*N);
        process(RST, CLK)
        begin
            if (RST = '1') then
                unsigned_freq_off(N)        <= (others => '0');
            elsif (rising_edge(CLK)) then
                freq_off_i(N)               <= FREQ_OFF(log2(ACCU_VAL)*(N+1)-1 downto log2(ACCU_VAL)*N);
                freq_off_i_d(N)             <= freq_off_i(N);

                if (nco_update(N) = '1') then
                    unsigned_freq_off(N)    <= freq_off_i_d(N);
                end if;

                unsigned_freq_off_d(N)      <= unsigned_freq_off(N);
            end if;
        end process;
    end generate CH_DATA_GEN;

    -- HOVS/channel counter
    process(CLK, RST)
    begin
        if (RST = '1') then
            hovs_ch_cnt             <= (others => '0');
        elsif rising_edge(CLK) then
            if FS = '1' then
                hovs_ch_cnt         <= CH_INIT_VALUE;
            else
                hovs_ch_cnt         <= hovs_ch_cnt + '1';
            end if;
        end if;
    end process;

    process(CLK, RST)
    begin
        if (RST = '1') then
            re_sync                 <= '0';
        elsif rising_edge(CLK) then
            if (HOVS = 1) then
                re_sync             <= '0';
            elsif (FS = '1') then
                if (hovs_ch_cnt = CH_INIT_VALUE-1) then
                    re_sync         <= '0';-- normal
                else
                    re_sync         <= '1';-- abnormal
                end if;
            end if;
        end if;
    end process;

    ch_numi <= (others => '0') when CHANNEL_NUMBERS = 1 else hovs_ch_cnt(HOVS_CH_WIDTH-1 downto log2(HOVS));

    process(CLK, RST)
    begin
        if RST = '1' then
            freq_word_s             <= (others => '0');
        elsif rising_edge(CLK) then
            if (CHANNEL_NUMBERS = 1) then
                freq_word_s         <= unsigned_freq_off_d(0);
            else
                freq_word_s         <= unsigned_freq_off_d(conv_integer(ch_numi));
            end if;
            freq_word_s_1d          <= freq_word_s;
            freq_word_s_2d          <= freq_word_s_1d;
        end if;
    end process;

    process(CLK, RST)
    begin
        if (RST = '1') then
            hovs_start <= '0';
        elsif (rising_edge(CLK)) then
            if (HOVS = 1) then
                hovs_start <= '1';
            elsif (hovs_ch_cnt(log2(HOVS)-1 downto 0) = HOVS-1) then
                hovs_start <= '1';
            else
                hovs_start <= '0';
            end if;
        end if;
    end process;

    process(CLK, RST)
    begin
        if RST = '1' then
            nco_update_sh       <= (others=>'0');
            accumulator         <= (others => (others => '0'));
        elsif rising_edge(CLK) then
            nco_update_sh       <= nco_update;
            -- Accumulator
            if (nco_update_sh /= 0 or re_sync = '1') then
                accumulator(0) <= (others => '0');
            elsif (hovs_start = '1') then
--                if accumulator(CHANNEL_NUMBERS-1) + freq_word_s_2d >= ACCU_VAL then
                if flag_accumulator_over = '1' then
                    accumulator(0) <= accumulator(CHANNEL_NUMBERS-1) + ('0' & freq_word_s_2d) - ACCU_VAL;
                else
                    accumulator(0) <= accumulator(CHANNEL_NUMBERS-1) + ('0' & freq_word_s_2d);
                end if;
            end if;
            -- Multi-Channel Accumulator
            if CHANNEL_NUMBERS > 1 and hovs_start = '1' then -- accumulator channel shift
                accumulator(CHANNEL_NUMBERS-1 downto 1) <= accumulator(CHANNEL_NUMBERS-2 downto 0);
                
                if accumulator(CHANNEL_NUMBERS-2) + freq_word_s_2d >= ACCU_VAL then
                    flag_accumulator_over <= '1';
                else
                    flag_accumulator_over <= '0';
                end if;
            end if;
        end if;
    end process;

    --prbs generation
    prbs <= prbs20_20b(dither) when PRBS_SEL=20 else
            prbs15_20b(dither) when PRBS_SEL=15 else
            prbs10_20b(dither) when PRBS_SEL=10 else
            prbs7_20b(dither);

    process(CLK, RST)
    begin
        if RST = '1' then
            dither <= x"00001";
        elsif rising_edge(CLK) then
            dither <= prbs;
        end if;
    end process;

    U_PRBS_WIDTH_0 : if (PRBS_WIDTH = 0) generate
        process(CLK)
        begin
            if (rising_edge(CLK)) then
                angle_tmp       <= accumulator(0)(log2(ACCU_VAL)-1 downto log2(ACCU_VAL)-(RAM_DEPTH_WIDTH+PRBS_WIDTH));
            end if;
        end process;
    end generate;

    U_PRBS_WIDTH_not_0 : if (PRBS_WIDTH /= 0) generate
        process(CLK)
        begin
            if (rising_edge(CLK)) then
                angle_tmp       <= accumulator(0)(log2(ACCU_VAL)-1 downto log2(ACCU_VAL)-(RAM_DEPTH_WIDTH+PRBS_WIDTH)) + dither(20-1 downto 20-PRBS_WIDTH);
            end if;
        end process;
    end generate;

    process(CLK, RST)
    begin
        if RST = '1' then
            angle_mod_bf        <= (others => '0');
        elsif rising_edge(CLK) then
            if (angle_tmp >= ACCU_VAL) then
                angle_mod_bf    <= angle_tmp - ACCU_VAL;
            else
                angle_mod_bf    <= angle_tmp;
            end if;

            angle_mod           <=  angle_mod_bf;
        end if;
    end process;

    process(CLK, RST)
    begin
        if RST = '1' then
            angle   <= (others => '0');
            angle90 <= (others => '1');
        elsif rising_edge(CLK) then
--            angle   <= angle_mod;--accumulator(0);--
--            angle90 <= not angle_mod;--accumulator(0);--

            if angle_mod < ACCU_VAL/2 then
                angle(RAM_DEPTH_WIDTH-1) <= '0';
            else
                angle(RAM_DEPTH_WIDTH-1) <= '1';
            end if;

            if angle_mod < ACCU_VAL/4 or (angle_mod >= ACCU_VAL/2 and angle_mod < ACCU_VAL*3/4) then
                angle(RAM_DEPTH_WIDTH-2) <= '0';
            else
                angle(RAM_DEPTH_WIDTH-2) <= '1';
            end if;

            if angle_mod < ACCU_VAL/4 then
                angle(  RAM_DEPTH_WIDTH-3 downto 0) <=                                  angle_mod(RAM_DEPTH_WIDTH+PRBS_WIDTH-3 downto PRBS_WIDTH);
                angle90(RAM_DEPTH_WIDTH-3 downto 0) <= (ACCU_VAL*1/4/(2**PRBS_WIDTH)) - angle_mod(RAM_DEPTH_WIDTH+PRBS_WIDTH-3 downto PRBS_WIDTH);   -- 1920 - angle_mod
            elsif angle_mod >= ACCU_VAL*1/4 and angle_mod < ACCU_VAL*2/4 then
                angle(  RAM_DEPTH_WIDTH-3 downto 0) <=                                  angle_mod(RAM_DEPTH_WIDTH+PRBS_WIDTH-3 downto PRBS_WIDTH) - ACCU_VAL*1/4/(2**PRBS_WIDTH);   -- angle_mod - 1920
                angle90(RAM_DEPTH_WIDTH-3 downto 0) <= (ACCU_VAL*2/4/(2**PRBS_WIDTH)) - angle_mod(RAM_DEPTH_WIDTH+PRBS_WIDTH-3 downto PRBS_WIDTH);  -- 3840 - angle_mod
            elsif angle_mod >= ACCU_VAL*2/4 and angle_mod < ACCU_VAL*3/4 then
                angle(  RAM_DEPTH_WIDTH-3 downto 0) <=                                  angle_mod(RAM_DEPTH_WIDTH+PRBS_WIDTH-3 downto PRBS_WIDTH) - ACCU_VAL*2/4/(2**PRBS_WIDTH);   -- angle_mod - 3840
                angle90(RAM_DEPTH_WIDTH-3 downto 0) <= (ACCU_VAL*3/4/(2**PRBS_WIDTH)) - angle_mod(RAM_DEPTH_WIDTH+PRBS_WIDTH-3 downto PRBS_WIDTH);  -- 5760 - angle_mod
            else
                angle(  RAM_DEPTH_WIDTH-3 downto 0) <=                                  angle_mod(RAM_DEPTH_WIDTH+PRBS_WIDTH-3 downto PRBS_WIDTH) - ACCU_VAL*3/4/(2**PRBS_WIDTH);   -- angle_mod - 5760
                angle90(RAM_DEPTH_WIDTH-3 downto 0) <= (ACCU_VAL*4/4/(2**PRBS_WIDTH)) - angle_mod(RAM_DEPTH_WIDTH+PRBS_WIDTH-3 downto PRBS_WIDTH);  -- 7680 - angle_mod
            end if;
        end if;
    end process;

    process(CLK)
    begin
        if (rising_edge(CLK)) then
            w_addr_sin      <= angle(  RAM_DEPTH_WIDTH-3 downto 0);
            w_addr_cos      <= angle90(RAM_DEPTH_WIDTH-3 downto 0);

            addr_sin        <= w_addr_sin;
            addr_cos        <= w_addr_cos;
        end if;
    end process;

    -- 2 CLK delay
    g_X : if VENDOR = "XILINX" generate
        g_122 : if ACCU_VAL = 12288 or ACCU_VAL = 24576 or ACCU_VAL = 49152 or ACCU_VAL = 98304 or ACCU_VAL = 122880 generate
            u_nco_ram : nco_ram_x_122_dither
            generic map(
                DATA_WIDTH                  => WIDTH-1                      ,--: natural := 15;
--                ADDR_WIDTH                  => 10                            --: natural := 12
                ADDR_WIDTH                  => 11                            --: natural := 12
            )
            port map(
                CLK                         => CLK                          ,--: in  std_logic;
                ADDR_A                      => addr_sin                     ,--: in  std_logic_vector(ADDR_WIDTH-1 downto 0);
                ADDR_B                      => addr_cos                     ,--: in  std_logic_vector(ADDR_WIDTH-1 downto 0);
                Q_A                         => ram_out_sin                  ,--: out std_logic_vector((DATA_WIDTH -1) downto 0);
                Q_B                         => ram_out_cos                   --: out std_logic_vector((DATA_WIDTH -1) downto 0)
            );
        end generate;

        g_153 : if ACCU_VAL = 153600 generate
            u_nco_ram : nco_ram_x_153_dither
            generic map(
                DATA_WIDTH                  => WIDTH-1                      ,--: natural := 15;
                ADDR_WIDTH                  => 12                            --: natural := 12
            )
            port map(
                CLK                         => CLK                          ,--: in  std_logic;
                ADDR_A                      => addr_sin                     ,--: in  std_logic_vector(ADDR_WIDTH-1 downto 0);
                ADDR_B                      => addr_cos                     ,--: in  std_logic_vector(ADDR_WIDTH-1 downto 0);
                Q_A                         => ram_out_sin                  ,--: out std_logic_vector((DATA_WIDTH -1) downto 0);
                Q_B                         => ram_out_cos                   --: out std_logic_vector((DATA_WIDTH -1) downto 0)
            );
        end generate;
    end generate;

    g_A : if VENDOR = "ALTERA" generate
        u_nco_ram : nco_ram_a_122_dither
        generic map(
            DATA_WIDTH                  => WIDTH-1                      ,--: natural := 15;
--            ADDR_WIDTH                  => 10                            --: natural := 12
            ADDR_WIDTH                  => 11                            --: natural := 12
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;
            ADDR_A                      => addr_sin                     ,--: in  std_logic_vector(ADDR_WIDTH-1 downto 0);
            ADDR_B                      => addr_cos                     ,--: in  std_logic_vector(ADDR_WIDTH-1 downto 0);
            Q_A                         => ram_out_sin                  ,--: out std_logic_vector((DATA_WIDTH -1) downto 0);
            Q_B                         => ram_out_cos                   --: out std_logic_vector((DATA_WIDTH -1) downto 0)
        );
    end generate;

    process(CLK, RST)
    begin
        if RST = '1' then
            sin_p <= (others => '0');
            cos_p <= (others => '0');
            sin_n <= (others => '0');
            cos_n <= (others => '0');
        elsif rising_edge(CLK) then
            sin_p <= '0' & ram_out_sin;
            cos_p <= '0' & ram_out_cos;
            sin_n <= ('1' & not ram_out_sin) + '1';
            cos_n <= ('1' & not ram_out_cos) + '1';
        end if;
    end process;

    -- wait ROM output
    u_dduc_delay_chain : dduc_delay_chain
    generic map(
        BUFF_DEPTH                  => ROM_DLY                      ,--: natural:= 16;-- SRL16E
        DIRECTION                   => 0                            ,--: natural:= 1: -- 1:forward, 0:reverse
        WIDTH_IN                    => 2                             --: natural:= 16 -- Input data width
    )
    port map(
        CLK                         => CLK                          ,--: in  std_logic;
        DATA_SEL                    => std_logic_vector(to_unsigned(ROM_DLY-1, log2(ROM_DLY))),
        VALID_I                     => '1'                          ,--: in  std_logic;
        FILTER_IN                   => angle(RAM_DEPTH_WIDTH-1 downto RAM_DEPTH_WIDTH-2),--: in  std_logic_vector(WIDTH_IN-1 downto 0);
        FILTER_OUT                  => quadrant                      --: out std_logic_vector(WIDTH_IN-1 downto 0)
    );

    process(CLK, RST)
    begin
        if RST = '1' then
--            quadrant_sh <= (others=>'0');
            SIN_O <= (others => '0');
            COS_O <= (others => '0');
        elsif rising_edge(CLK) then
--            quadrant_sh <= quadrant;
            case quadrant is
                when "00" => SIN_O <= sin_p;  COS_O <= cos_p;
                when "01" => SIN_O <= cos_p;  COS_O <= sin_n;
                when "10" => SIN_O <= sin_n;  COS_O <= cos_n;
                when "11" => SIN_O <= cos_n;  COS_O <= sin_p;
                when others => null;
            end case;
        end if;
    end process;
        
end rtl;
