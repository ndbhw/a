library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;
use work.dduc_pkg.all;

entity duc_composite is
port(
    RST                         : in  std_logic;
    RST_307                     : in  std_logic;
    CLK                         : in  std_logic;
    CLK_307                     : in  std_logic;

    MODE                        : in  std_logic_vector(3 downto 0);
    NCO_WREN                    : in  std_logic_vector(DUC_NCO_CHANNELS-1 downto 0);
    NCO_FREQ_WORD               : in  std_logic_vector(DUC_NCO_CHANNELS*(log2(DUC_NCO_ACCU_VAL/DUC_HB_N_OUT))-1 downto 0);

    DUC_FRAME_I                 : in  std_logic;
    DUC_VALID_I                 : in  std_logic;
    DUC_IN                      : in  std_logic_vector(DUC_WIDTH_I-1 downto 0);

    DUC_FRAME_O                 : out std_logic;
    DUC_VALID_O                 : out std_logic;
    DUC_OUT                     : out duc_output_type;
    PIM_FRAME_O                 : out std_logic;
    PIM_VALID_O                 : out std_logic;
    PIM_OUT                     : out duc_output_type
);
end duc_composite;

architecture rtl of duc_composite is

component reset_block is
generic(
    CLEAR_SAMPLES               : integer:= 16;
    WIDTH_IN                    : integer:= 16
);
port(
    RST                         :in  std_logic;
    CLK                         :in  std_logic;
    FRAME_I                     :in  std_logic;
    VALID_I                     :in  std_logic;
    FILTER_IN                   :in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     :out std_logic;
    VALID_O                     :out std_logic;
    FILTER_OUT                  :out std_logic_vector(WIDTH_IN-1  downto 0);
    --SPECAIL for CIC
    CLR_O                       :out std_logic:='1';
    --SPECAIL for FIR
    RES_O                       :out std_logic:='1'
);
end component;

component fir_pfir is
generic(
    VENDOR                      : string:="XILINX";
    DDUC_SEL                    : integer:= 0;-- 0 : DUC, 1 : DDC
    CHANNEL_NUMBERS             : integer:= 4;

    WIDTH_IN                    : integer:= 16;
    WIDTH_OUT                   : integer:= 16;
    WIDTH_COEFF                 : integer:= 16;

    WIDTH_RESULT                : integer:= 32;
    BINARY_POINT                : integer:= 15;

    HOVS                        : integer:= 2;
    ORDER                       : integer:= 96
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    MODE                        : in  std_logic_vector(3 downto 0);

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1  downto 0)
);
end component;

component fir_i is
generic (
    VENDOR                      : string:="XILINX";
    HOVS                        : integer:=2;
    ORDER                       : integer:=12;

    CHANNEL_NUMBERS             : integer:=4;

    WIDTH_IN                    : integer:=16;
    WIDTH_COEFF                 : integer:=16;
    WIDTH_OUT                   : integer:=16;
    WIDTH_RESULT                : integer:=34;
    BINARY_POINT                : integer:=15
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT_0                : out std_logic_vector(WIDTH_OUT-1  downto 0);
    FILTER_OUT_1                : out std_logic_vector(WIDTH_OUT-1  downto 0)
);
end component;

component channel_swap_hbf_i is
generic(
    CHANNEL_NUMBERS             : natural:= 4;
    HOVS                        : natural:= 4;
    WIDTH_IN                    : natural:= 16
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);        -- 2 continuous data per each channel, x1 rate

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)         -- 1 data per each channel, x2 rate
);
end component;

component channel_demux is
generic(
    COPY_MODE_EN                : natural:= 1;
    HOVS                        : natural:= 2;
    WIDTH_IN                    : natural:= 16
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);        -- 2 continuous data per each channel, x1 rate

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT_0                : out std_logic_vector(WIDTH_IN-1 downto 0);        -- 1 data per each channel, x2 rate
    FILTER_OUT_1                : out std_logic_vector(WIDTH_IN-1 downto 0)         -- 1 data per each channel, x2 rate
);
end component;

component nco_ram_dither is
generic(
    VENDOR                      : string :="XILINX";
    ACCU_VAL                    : natural:=12288;
    WIDTH                       : natural:=16;
    PRBS_SEL                    : natural:=20;
    HOVS                        : natural:=1;
    CHANNEL_NUMBERS             : natural:=1
);
port(
    RST                         :in  std_logic;
    CLK                         :in  std_logic;

    FS                          :in  std_logic;         -- fs=1 then restart channel number from 0 to channel_numbers-1

    NCO_WREN                    :in  std_logic_vector(CHANNEL_NUMBERS-1 downto 0);
    FREQ_OFF                    :in  std_logic_vector(CHANNEL_NUMBERS*log2(ACCU_VAL)-1 downto 0);-- offset

    COS_O                       :out std_logic_vector(WIDTH-1 downto 0);
    SIN_O                       :out std_logic_vector(WIDTH-1 downto 0)
);
end component;

component dduc_complex_mult is
generic(
    VENDOR                      : string    := "XILINX";    -- "XILINX", "ALTERA"

    WIDTH_IN                    : natural   := 16;
    NCO_WIDTH_IN                : natural   := 16;
    WIDTH_OUT                   : natural   := 16;
    BINARY_POINT                : natural   := 15;          -- BINARY_POINT = WIDTH_IN+NCO_WIDTH_IN-WIDTH_OUT-1

    ROUNDING                    : string    := "ROUND_INF"; --"FULL_PRECISION","TRUNCATE","ROUND_INF", "ROUND_EVEN"
    OVERFLOW                    : string    := "SATURATE";  --"WRAP","SATURATE"
    SUM_EN                      : natural   := 0;           -- 1 : I+I, Q+Q for DUC output summation mode, 0 : bypass
    HOVS                        : natural   := 1
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    SINE_CONJUGATE              : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;

    DATA_IN_I                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_IN_Q                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_IN_COS                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);
    DATA_IN_SIN                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    DATA_OUT_I                  : out std_logic_vector(WIDTH_OUT-1 downto 0);
    DATA_OUT_Q                  : out std_logic_vector(WIDTH_OUT-1 downto 0)
);
end component;

component cdc_sr_15_36_245m_307m is
    generic (
        DATA_WIDTH                          : integer := 16
    );    
    Port (
        i_rst_245                           : in std_logic;
        i_clk_245                           : in std_logic;
        i_clk_307                           : in std_logic;

        i_mode                              : in std_logic_vector(4-1 downto 0);

         -- case BW5, BW10   
        i_hbf_frame                         : in std_logic;
        i_hbf_valid                         : in std_logic;
        i_hbf_data                          : in std_logic_vector(DATA_WIDTH-1 downto 0);

        -- case BW15, BW20   
        i_pfir_frame                        : in std_logic;
        i_pfir_valid                        : in std_logic;
        i_pfir_data                         : in std_logic_vector(DATA_WIDTH-1 downto 0);

        -- 76.8MHz, 4 channel
        o_cdc_15_36_frame                   : out std_logic;
        o_cdc_15_36_valid                   : out std_logic;
        o_cdc_15_36_data                    : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end component;

component upsamplex5_rearrange is
    generic (
        DATA_WIDTH                          : integer := 16
    );
    Port (
        i_clk_307                           : in std_logic;
        
        -- 15.36MHz
        i_cdc_15_36_frame                   : in std_logic;
        i_cdc_15_36_valid                   : in std_logic;
        i_cdc_15_36_data                    : in std_logic_vector(DATA_WIDTH-1 downto 0);

        -- 76.8MHz
        o_76_8_rearrange_frame              : out std_logic;
        o_76_8_rearrange_valid              : out std_logic;
        o_76_8_rearrange_data_i             : out std_logic_vector(DATA_WIDTH-1 downto 0); 
        o_76_8_rearrange_data_q             : out std_logic_vector(DATA_WIDTH-1 downto 0)  
    );
end component;

component dduc_lpf is
    generic (
        DDUC_TYPE                           : string := "DUC";  -- "DUC" or "DDC"
        DATA_WIDTH                          : integer := 16;
        BINARY_POINT                        : integer := 15
    );
    Port (
        i_rst_307                           : in std_logic;
        i_clk_307                           : in std_logic;
        
        -- 76.8MHz, 4 channel
        i_upsample_rearrange_frame          : in std_logic;
        i_upsample_rearrange_valid          : in std_logic;
        i_upsample_rearrange_data           : in std_logic_vector(DATA_WIDTH-1 downto 0);

        -- 76.8MHz, 4 channel
        o_lpf_frame                         : out std_logic;
        o_lpf_valid                         : out std_logic;
        o_lpf_data                          : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end component;

component PFIR_out_write 
    generic(
        file_name :string := "out3.txt";
        bitwidth  : integer:= 32;
        in_out : integer:= 1
    );
    port(
        clock          : in std_logic;
        reset          : in std_logic;
        w_en           : in std_logic;
        frame_sync     : in std_logic;
        IQ_in          : in std_logic_vector(31 downto 0)
    );
    end component;
    
        component DUC_out_write 
    generic(
        file_name :string := "out3.txt"
    );
    port(
        clock          : in std_logic;
        reset          : in std_logic;
        w_en           : in std_logic;
        frame_sync     : in std_logic;
        IQ_in          : in std_logic_vector(31 downto 0)
    );
    end component;

component ylib_shiftd_rnd 
    generic(
        NUM_STREAM : integer := 2;
        SHIFTD_BW  : integer := 4;
        IO_BW      : integer := 15
    );
    port(
        i_clk        : in std_logic;
        i_in_en      : in std_logic_vector  (0 downto 0);
        i_in         : in std_logic_vector  (NUM_STREAM*IO_BW-1 downto 0);
        i_shiftd     : in std_logic_vector  (SHIFTD_BW-1 downto 0 );
        o_out_en     : out std_logic_vector (0 downto 0);
        o_out        : out std_logic_vector (NUM_STREAM*IO_BW-1 downto 0)
    );
end component;

component ylib_sat 
    generic(
        NUM_STREAM  : integer := 2;
        DI_BW       : integer := 4;
        DO_BW       : integer := 15;
        SAT_TYPE    : string := "SYMMETRIC" 
    );
    port(
        i_clk       : in std_logic;
        i_in_en     : in std_logic_vector  (0 downto 0);                 
        i_in        : in std_logic_vector  (NUM_STREAM*DI_BW-1 downto 0);
        o_out_en    : out std_logic_vector  (0 downto 0                );
        o_out       : out std_logic_vector (NUM_STREAM*DO_BW-1 downto 0)
    );
end component;


signal clr_r                    :std_logic;
signal res_r                    :std_logic;

signal reset_frame              :std_logic;
signal reset_valid              :std_logic;
signal reset_data               :std_logic_vector(DUC_WIDTH_I-1 downto 0);
signal reset_data_d             :std_logic_vector(DUC_WIDTH_I-1 downto 0);
signal reset_data_dd            :std_logic_vector(DUC_WIDTH_I-1 downto 0);

signal pfir_frame               : std_logic;
signal pfir_valid               : std_logic;
signal pfir_data                : std_logic_vector(DUC_WIDTH_O_PFIR-1 downto 0);

signal pfir_data_d              : std_logic_vector(DUC_WIDTH_O_PFIR-1 downto 0);
signal pfir_data_dd             : std_logic_vector(DUC_WIDTH_O_PFIR-1 downto 0);

signal hbf2nd_frame               : std_logic;
signal hbf2nd_valid               : std_logic;
signal hbf2nd_data                : std_logic_vector(DUC_WIDTH_O_PFIR-1 downto 0);

signal hbf_frame_out            : std_logic_vector(DUC_HB_N-1 downto 0);
signal hbf_valid_out            : std_logic_vector(DUC_HB_N-1 downto 0);
signal hbf_data_out             : duc_hb_type(DUC_HB_N-1 downto 0);

signal ch_swap_frame_out        : std_logic_vector(DUC_HB_N-1 downto 0);
signal ch_swap_valid_out        : std_logic_vector(DUC_HB_N-1 downto 0);
signal ch_swap_data_out         : duc_hb_type(DUC_HB_N-1 downto 0);

signal nco_sin                  : std_logic_vector(DUC_NCO_WIDTH_IN-1 downto 0);
signal nco_cos                  : std_logic_vector(DUC_NCO_WIDTH_IN-1 downto 0);

signal mult_frame_out           : std_logic;
signal mult_valid_out           : std_logic;
signal mult_data_out            : duc_output_type;

signal cdc_15_36_frame          : std_logic;
signal cdc_15_36_valid          : std_logic;
signal cdc_15_36_data           : std_logic_vector(DUC_WIDTH_O_PFIR-1 downto 0);

signal upsample_rearrange_frame : std_logic;
signal upsample_rearrange_valid : std_logic;
signal upsample_rearrange_data_i  : std_logic_vector(DUC_WIDTH_O_PFIR-1 downto 0);
signal upsample_rearrange_data_q  : std_logic_vector(DUC_WIDTH_O_PFIR-1 downto 0);

signal lpf_frame                : std_logic_vector(1 downto 0);
signal lpf_valid                : std_logic_vector(1 downto 0);
signal lpf_valid_shift                : std_logic_vector(1 downto 0);
signal lpf_valid_rnd                : std_logic_vector(1 downto 0);
signal lpf_data_i               : std_logic_vector(DUC_WIDTH_O_PFIR-1 downto 0);
signal lpf_data_q               : std_logic_vector(DUC_WIDTH_O_PFIR-1 downto 0);
signal lpf_data_i_d               : std_logic_vector(40-1 downto 0);
signal lpf_data_q_d               : std_logic_vector(40-1 downto 0);
signal lpf_data_i_shift         : std_logic_vector(40-1 downto 0);
signal lpf_data_q_shift         : std_logic_vector(40-1 downto 0);

signal lpf_data_i_shift2         : std_logic_vector(DUC_WIDTH_O_PFIR-1 downto 0);
signal lpf_data_q_shift2         : std_logic_vector(DUC_WIDTH_O_PFIR-1 downto 0);

signal lpf_data_i_shift_d       : std_logic_vector(40-1 downto 0);
signal lpf_data_q_shift_d       : std_logic_vector(40-1 downto 0);
signal lpf_valid_rnd_d              : std_logic_vector(1 downto 0);
signal NCO_FS                   : std_logic;


signal lpf_data_i_dd               : std_logic_vector(40-1 downto 0);
signal lpf_data_q_dd               : std_logic_vector(40-1 downto 0);
signal lpf_valid_shift_d               : std_logic_vector(1 downto 0);

signal lpf_valid_rnd_i                : std_logic_vector(0 downto 0);
signal lpf_valid_rnd_q                : std_logic_vector(0 downto 0);

signal iq_cmult_iq : std_logic_vector(31 downto 0);

--  signal cnt_start : std_logic_vector (31 downto 0);
--  signal en_write  : std_logic;
--  signal IQ_FIR_write : std_logic_vector (31 downto 0);
--  signal IQ_in_FIR_write : std_logic_vector (31 downto 0);

--  signal cnt_start307 : std_logic_vector (31 downto 0);
--  signal en_write307  : std_logic;

--  signal IQ_OUT_LPF_write : std_logic_vector (31 downto 0);
--  signal IQ_in_LPF_write : std_logic_vector (31 downto 0);
  
  signal lpf_valid_sat             : std_logic_vector(0 downto 0);

component dduc_dl_lpf is
    generic (
        DDUC_TYPE                           : string := "DUC";  -- "DUC" or "DDC"
        DATA_WIDTH                          : integer := 16;
        BINARY_POINT                        : integer := 15
    );
    Port (
        i_rst_307                           : in std_logic;
        i_clk_307                           : in std_logic;
        
        -- 76.8MHz, 4 channel
        i_upsample_rearrange_frame          : in std_logic;
        i_upsample_rearrange_valid          : in std_logic;
        i_upsample_rearrange_data           : in std_logic_vector(DATA_WIDTH-1 downto 0);

        -- 76.8MHz, 4 channel
        o_lpf_frame                         : out std_logic;
        o_lpf_valid                         : out std_logic;
        o_lpf_data                          : out std_logic_vector(40-1 downto 0);
        o_fir_ready                         : out std_logic
    );
end component;


component ulfe_lib_r_shift_symm_sat is
	generic (		
		i_shift_num					: integer := 15;
		d_i_width					: integer := 31;
		d_o_width					: integer := 15
	);
	Port (
		i_clk						: in std_logic;		
		data_i						: in std_logic_vector(d_i_width-1 downto 0);		
		data_o						: out std_logic_vector(d_o_width-1 downto 0)
	);
end component;

signal d_I_upsample_rearrange_valid   : std_logic;
signal d_I_upsample_rearrange_frame  : std_logic;
signal d_I_upsample_rearrange_data    : std_logic_vector (15 downto 0);
signal o_fir_lpf_ready              : std_logic;
signal o_fir_lpf_ready_1              : std_logic;
signal o_fir_lpf_ready_2              : std_logic;
signal o_fir_lpf_ready_1d              : std_logic;
signal o_fir_lpf_ready_2d              : std_logic;
signal o_fir_lpf_shift_en_1              : std_logic;
signal o_fir_lpf_shift_en_2              : std_logic;
--signal o_fir_lpf_valid              : std_logic;
--signal o_fir_lpf_data               : std_logic_vector(39 downto 0);
--signal o_data_tuser                 : std_logic;
--signal reset_fir                    : std_logic;
signal flag_take_data : std_logic;
signal upsample_rearrange_dly_frame : std_logic;
signal upsample_rearrange_dly_valid : std_logic;
signal upsample_rearrange_dly_data_i  : std_logic_vector(DUC_WIDTH_O_PFIR-1 downto 0);
signal upsample_rearrange_dly_data_q  : std_logic_vector(DUC_WIDTH_O_PFIR-1 downto 0);

signal d_I_upsample_rearrange_data_i  : std_logic_vector(DUC_WIDTH_O_PFIR-1 downto 0);
signal d_I_upsample_rearrange_data_q  : std_logic_vector(DUC_WIDTH_O_PFIR-1 downto 0);
begin


    RESET_STAGE : reset_block
        generic map(
            CLEAR_SAMPLES           => 128,
            WIDTH_IN                => DUC_WIDTH_I
        )
        port map(
            RST                     => RST,
            CLK                     => CLK,

            FRAME_I                 => DUC_FRAME_I,
            VALID_I                 => DUC_VALID_I,
            FILTER_IN               => DUC_IN,

            FRAME_O                 => reset_frame,
            VALID_O                 => reset_valid,
            FILTER_OUT              => reset_data,
            CLR_O                   => clr_r,
            RES_O                   => res_r
        );

    PFIR_GEN: fir_pfir
        generic map(
            VENDOR                  => VENDOR,
            DDUC_SEL                => 0,
            CHANNEL_NUMBERS         => CHANNEL_NUMBERS,

            WIDTH_IN                => DUC_WIDTH_I,
            WIDTH_OUT               => DUC_WIDTH_O_PFIR,
            WIDTH_COEFF             => DUC_WIDTH_COEFF_PFIR,

            WIDTH_RESULT            => DUC_WIDTH_RESULT_PFIR,
            BINARY_POINT            => DUC_BINARY_POINT_PFIR,

            HOVS                    => DUC_HOVS_PFIR,
            ORDER                   => DUC_ORDER_PFIR
        )
        port map(
            RST                     => res_r,
            CLK                     => CLK,

            MODE                    => MODE,

            FRAME_I                 => reset_frame,
            VALID_I                 => reset_valid,
            FILTER_IN               => reset_data,

            FRAME_O                 => pfir_frame,
            VALID_O                 => pfir_valid,
            FILTER_OUT              => pfir_data
        );
        
        
     u_hbf_1st : fir_i
        generic map(
            VENDOR                  => VENDOR,
            HOVS                    => DUC_HOVS_HB(0),
            ORDER                   => DUC_HBF_ORDER(0),

            CHANNEL_NUMBERS         => CHANNEL_NUMBERS,

            WIDTH_IN                => DUC_WIDTH_O_PFIR,
            WIDTH_OUT               => DUC_WIDTH_O_HB,
            WIDTH_COEFF             => DUC_WIDTH_COEFF_HB,
            WIDTH_RESULT            => DUC_WIDTH_RESULT_HB,
            BINARY_POINT            => DUC_BINARY_POINT_HB
        )
        port map(
            RST                     => res_r,
            CLK                     => CLK,

            FRAME_I                 => pfir_frame,
            VALID_I                 => pfir_valid,
            FILTER_IN               => pfir_data,
            FRAME_O                 => hbf_frame_out(0),
            VALID_O                 => hbf_valid_out(0),
            FILTER_OUT_0            => hbf_data_out(0),
            FILTER_OUT_1            => open
        );

    u_channel_swap_1st : channel_swap_hbf_i
        generic map(
            CHANNEL_NUMBERS         => CHANNEL_NUMBERS         ,--: natural:= 4;
            HOVS                    => DUC_HOVS_HB(0)/2        ,--: natural:= 4;
            WIDTH_IN                => DUC_WIDTH_O_HB           --: natural:= 16
        )
        port map(
            RST                     => res_r                   ,--: in  std_logic;
            CLK                     => CLK                     ,--: in  std_logic;

            FRAME_I                 => hbf_frame_out(0)        ,--: in  std_logic;
            VALID_I                 => hbf_valid_out(0)        ,--: in  std_logic;
            FILTER_IN               => hbf_data_out(0)         ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);        -- 2 continuous data per each channel, x1 rate

            FRAME_O                 => ch_swap_frame_out(0)    ,--: out std_logic;
            VALID_O                 => ch_swap_valid_out(0)    ,--: out std_logic;
            FILTER_OUT              => ch_swap_data_out(0)      --: out std_logic_vector(WIDTH_IN-1 downto 0)         -- 1 data per each channel, x2 rate
        );
        

        process(res_r,CLK)
        begin
            if res_r='1' then
                hbf2nd_frame <= '0';
                hbf2nd_valid <= '0';
                hbf2nd_data  <= (others => '0');
              
                
            elsif CLK'event and CLK='1' then
                if MODE = "0010" then 
                    hbf2nd_frame <=   ch_swap_frame_out(0) ;
                    hbf2nd_valid <=   ch_swap_valid_out(0) ;
                    hbf2nd_data  <=   ch_swap_data_out(0)  ;
                else
                    hbf2nd_frame <=   pfir_frame;
                    hbf2nd_valid <=   pfir_valid;
                    hbf2nd_data  <=   pfir_data;  
                end if;   
            end if;
        end process;
    
        
    u_hbf_2nd : fir_i
        generic map(
            VENDOR                  => VENDOR,
            HOVS                    => DUC_HOVS_HB(1),
            ORDER                   => DUC_HBF_ORDER(0),

            CHANNEL_NUMBERS         => CHANNEL_NUMBERS,

            WIDTH_IN                => DUC_WIDTH_O_PFIR,
            WIDTH_OUT               => DUC_WIDTH_O_HB,
            WIDTH_COEFF             => DUC_WIDTH_COEFF_HB,
            WIDTH_RESULT            => DUC_WIDTH_RESULT_HB,
            BINARY_POINT            => DUC_BINARY_POINT_HB
        )
        port map(
            RST                     => res_r,
            CLK                     => CLK,

            FRAME_I                 => hbf2nd_frame,
            VALID_I                 => hbf2nd_valid,
            FILTER_IN               => hbf2nd_data ,
            FRAME_O                 => hbf_frame_out(1),
            VALID_O                 => hbf_valid_out(1),
            FILTER_OUT_0            => hbf_data_out(1),
            FILTER_OUT_1            => open
        );

    u_channel_swap_2nd : channel_swap_hbf_i
        generic map(
            CHANNEL_NUMBERS         => CHANNEL_NUMBERS         ,--: natural:= 4;
            HOVS                    => DUC_HOVS_HB(1)/2        ,--: natural:= 4;
            WIDTH_IN                => DUC_WIDTH_O_HB           --: natural:= 16
        )
        port map(
            RST                     => res_r                   ,--: in  std_logic;
            CLK                     => CLK                     ,--: in  std_logic;

            FRAME_I                 => hbf_frame_out(1)    ,--: in  std_logic;
            VALID_I                 => hbf_valid_out(1)    ,--: in  std_logic;
            FILTER_IN               => hbf_data_out(1)     ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);        -- 2 continuous data per each channel, x1 rate

            FRAME_O                 => ch_swap_frame_out(1)    ,--: out std_logic;
            VALID_O                 => ch_swap_valid_out(1)    ,--: out std_logic;
            FILTER_OUT              => ch_swap_data_out(1)      --: out std_logic_vector(WIDTH_IN-1 downto 0)         -- 1 data per each channel, x2 rate
        );
        
    
--    u_hbf_1st : fir_i
--        generic map(
--            VENDOR                  => VENDOR,
--            HOVS                    => DUC_HOVS_HB(0),
--            ORDER                   => DUC_HBF_ORDER(0),

--            CHANNEL_NUMBERS         => CHANNEL_NUMBERS,

--            WIDTH_IN                => DUC_WIDTH_O_PFIR,
--            WIDTH_OUT               => DUC_WIDTH_O_HB,
--            WIDTH_COEFF             => DUC_WIDTH_COEFF_HB,
--            WIDTH_RESULT            => DUC_WIDTH_RESULT_HB,
--            BINARY_POINT            => DUC_BINARY_POINT_HB
--        )
--        port map(
--            RST                     => res_r,
--            CLK                     => CLK,

--            FRAME_I                 => pfir_frame,
--            VALID_I                 => pfir_valid,
--            FILTER_IN               => pfir_data,
--            FRAME_O                 => hbf_frame_out(0),
--            VALID_O                 => hbf_valid_out(0),
--            FILTER_OUT_0            => hbf_data_out(0),
--            FILTER_OUT_1            => open
--        );

--    u_channel_swap_1st : channel_swap_hbf_i
--        generic map(
--            CHANNEL_NUMBERS         => CHANNEL_NUMBERS         ,--: natural:= 4;
--            HOVS                    => DUC_HOVS_HB(0)/2        ,--: natural:= 4;
--            WIDTH_IN                => DUC_WIDTH_O_HB           --: natural:= 16
--        )
--        port map(
--            RST                     => res_r                   ,--: in  std_logic;
--            CLK                     => CLK                     ,--: in  std_logic;

--            FRAME_I                 => hbf_frame_out(0)        ,--: in  std_logic;
--            VALID_I                 => hbf_valid_out(0)        ,--: in  std_logic;
--            FILTER_IN               => hbf_data_out(0)         ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);        -- 2 continuous data per each channel, x1 rate

--            FRAME_O                 => ch_swap_frame_out(0)    ,--: out std_logic;
--            VALID_O                 => ch_swap_valid_out(0)    ,--: out std_logic;
--            FILTER_OUT              => ch_swap_data_out(0)      --: out std_logic_vector(WIDTH_IN-1 downto 0)         -- 1 data per each channel, x2 rate
--        );

    ------------------------------------------------------------------------------------------------------------------
    -- CDC, 15.36MHz
    u_cdc_sr_15_36_245m_307m : cdc_sr_15_36_245m_307m generic map(DUC_WIDTH_O_PFIR)
        Port map ( 
            i_rst_245                   =>  RST,                        --: in std_logic;
            i_clk_245                   =>  CLK,                        --: in std_logic;
            i_clk_307                   =>  CLK_307,                    --: in std_logic;

            i_mode                      =>  MODE,                       --: in std_logic_vector(4-1 downto 0);

            -- case BW5, BW10
            i_hbf_frame                 =>  ch_swap_frame_out(1),       --: in std_logic;
            i_hbf_valid                 =>  ch_swap_valid_out(1),       --: in std_logic;
            i_hbf_data                  =>  ch_swap_data_out(1),        --: in std_logic_vector(DATA_WIDTH-1 downto 0);

            -- case BW15, BW20
            i_pfir_frame                =>  pfir_frame,                 --: in std_logic;
            i_pfir_valid                =>  pfir_valid,                 --: in std_logic;
            i_pfir_data                 =>  pfir_data,                  --: in std_logic_vector(DATA_WIDTH-1 downto 0);

            -- 15.36MHz, 4 channel
            o_cdc_15_36_frame           =>  cdc_15_36_frame,            --: out std_logic;
            o_cdc_15_36_valid           =>  cdc_15_36_valid,            --: out std_logic;
            o_cdc_15_36_data            =>  cdc_15_36_data              --: out std_logic_vector(DATA_WIDTH-1 downto 0)
        );

    -- upsamplex5(76.8Mhz), rearrange
    u_upsamplex5_rearrange : upsamplex5_rearrange generic map(DUC_WIDTH_O_PFIR)
        Port map (
            i_clk_307                   =>  CLK_307,                    --: in std_logic;

            -- 15.36MHz, 4 channel
            i_cdc_15_36_frame           =>  cdc_15_36_frame,            --: in std_logic;
            i_cdc_15_36_valid           =>  cdc_15_36_valid,            --: in std_logic;
            i_cdc_15_36_data            =>  cdc_15_36_data,             --: in std_logic_vector(DATA_WIDTH-1 downto 0);

            -- 76.8MHz, 4 channel
            o_76_8_rearrange_frame      =>  upsample_rearrange_frame,   --: out std_logic;
            o_76_8_rearrange_valid      =>  upsample_rearrange_valid,   --: out std_logic;
            o_76_8_rearrange_data_i     => upsample_rearrange_data_i,
            o_76_8_rearrange_data_q     => upsample_rearrange_data_q
        );
    
    
    u_dduc_lpf1 : dduc_dl_lpf generic map("DUC",DUC_WIDTH_O_PFIR,15)
        Port map (
            i_rst_307                   =>  RST_307,                    --: in std_logic;
            i_clk_307                   =>  CLK_307,                    --: in std_logic;
            
            -- 76.8MHz, 4 channel
            i_upsample_rearrange_frame  =>  d_I_upsample_rearrange_frame,--upsample_rearrange_frame,   --: in std_logic;
            i_upsample_rearrange_valid  =>  d_I_upsample_rearrange_valid,--upsample_rearrange_valid,   --: in std_logic;
            i_upsample_rearrange_data   =>  d_I_upsample_rearrange_data_i, --upsample_rearrange_data_i,    --: in std_logic_vector(DATA_WIDTH-1 downto 0);

            -- 76.8MHz, 4 channel
            o_lpf_frame                 =>  lpf_frame(0),                  --: out std_logic;
            o_lpf_valid                 =>  lpf_valid_shift(0),                  --: out std_logic;
            o_lpf_data                  =>  lpf_data_i_d,                    --: out std_logic_vector(DATA_WIDTH-1 downto 0)
            o_fir_ready                 =>  o_fir_lpf_ready_1d
        );

    u_dduc_lpf2 : dduc_dl_lpf generic map("DUC",DUC_WIDTH_O_PFIR,15)
        Port map (
            i_rst_307                   =>  RST_307,                    --: in std_logic;
            i_clk_307                   =>  CLK_307,                    --: in std_logic;
            
            -- 76.8MHz, 4 channel
            i_upsample_rearrange_frame  =>  d_I_upsample_rearrange_frame,--upsample_rearrange_frame,   --: in std_logic;
            i_upsample_rearrange_valid  =>  d_I_upsample_rearrange_valid,--upsample_rearrange_valid,   --: in std_logic;
            i_upsample_rearrange_data   =>  d_I_upsample_rearrange_data_q,--upsample_rearrange_data_q,    --: in std_logic_vector(DATA_WIDTH-1 downto 0);

            -- 76.8MHz, 4 channel
            o_lpf_frame                 =>  lpf_frame(1),                  --: out std_logic;
            o_lpf_valid                 =>  lpf_valid_shift(1),                  --: out std_logic;
            o_lpf_data                  =>  lpf_data_q_d,                    --: out std_logic_vector(DATA_WIDTH-1 downto 0)
            o_fir_ready                 =>  o_fir_lpf_ready_2d
        );
        
        process(RST_307,CLK_307)
        begin
            if RST_307 = '1' then 
                lpf_data_i_dd     <= (others => '0');
                lpf_data_q_dd     <= (others => '0');
                lpf_valid_shift_d <= (others => '0');
            elsif CLK_307'event and CLK_307='1' then
            
                lpf_data_i_dd <= lpf_data_i_d;
                lpf_data_q_dd <= lpf_data_q_d;
                lpf_valid_shift_d <= lpf_valid_shift;
            end if;
        end process;
        
        ylib_shiftd_rnd_lpf_xilinx_I : ylib_shiftd_rnd
        generic map(
            NUM_STREAM => 1 ,
            SHIFTD_BW  => 5 ,
            IO_BW      => 40
            )
        port map(
            i_clk    => CLK_307,
            i_in_en(0)  => lpf_valid_shift_d(0),--o_fir_lpf_ready_1d,
            i_in     => lpf_data_i_dd,
            i_shiftd => "01111",
            o_out_en=> lpf_valid_rnd_i,
            o_out    => lpf_data_i_shift
        );
        
        ylib_shiftd_rnd_lpf_xilinx_Q : ylib_shiftd_rnd
        generic map(
            NUM_STREAM => 1 ,
            SHIFTD_BW  => 5 ,
            IO_BW      => 40
            )
        port map(
            i_clk    => CLK_307,
            i_in_en(0)  => lpf_valid_shift_d(1),-- o_fir_lpf_ready_2d,
            i_in     => lpf_data_q_dd,
            i_shiftd => "01111", -- up 12db
            o_out_en => lpf_valid_rnd_q,
            o_out    => lpf_data_q_shift
        );
        
        
--        process(RST_307,CLK_307)
--        begin
--            if RST_307 = '1' then 
--                lpf_data_q_shift_d     <= (others => '0');
--                lpf_data_i_shift_d     <= (others => '0');
--                lpf_valid_rnd_d        <= (others => '0');
--            elsif CLK_307'event and CLK_307='1' then
            
--                lpf_data_q_shift_d  <= lpf_data_q_shift; 
--                lpf_data_i_shift_d  <= lpf_data_i_shift;
--                lpf_valid_rnd_d     <= lpf_valid_rnd;    
--            end if;
--        end process;
        
        ylib_sat_I : ylib_sat
        generic map(
            NUM_STREAM => 1,
            DI_BW      => 40,
            DO_BW      => 16
        )
        port map(
           i_clk       => CLK_307,
           i_in_en => lpf_valid_rnd_i,
           i_in        => lpf_data_i_shift,
           o_out_en => lpf_valid_sat,--o_fir_lpf_ready_1,
           o_out       => lpf_data_i
        );
        
        ylib_sat_Q : ylib_sat
        generic map(
            NUM_STREAM => 1,
            DI_BW      => 40,
            DO_BW      => 16
        )
        port map(
           i_clk       => CLK_307,
           i_in_en  => lpf_valid_rnd_q,
           i_in        => lpf_data_q_shift,
           o_out_en => open,--o_fir_lpf_ready_2,
           o_out       => lpf_data_q
        );
        
        
        
       
--    u_hbf_final : fir_i
--        generic map(
--            VENDOR                      => VENDOR,
--            HOVS                        => 1,
--            ORDER                       => DUC_HBF_ORDER(3),

--            CHANNEL_NUMBERS             => CHANNEL_NUMBERS,

--            WIDTH_IN                    => DUC_WIDTH_O_PFIR,
--            WIDTH_OUT                   => DUC_WIDTH_O_HB,
--            WIDTH_COEFF                 => DUC_WIDTH_COEFF_HB,
--            WIDTH_RESULT                => DUC_WIDTH_RESULT_HB,
--            BINARY_POINT                => DUC_BINARY_POINT_HB
--        )
--        port map(
--            RST                         => RST_307,
--            CLK                         => CLK_307,

--            FRAME_I                     => lpf_frame,
--            VALID_I                     => lpf_valid,
--            FILTER_IN                   => lpf_data,
--            FRAME_O                     => hbf_frame_out(3),
--            VALID_O                     => hbf_valid_out(3),
--            FILTER_OUT_0                => hbf_data_out(3),
--            FILTER_OUT_1                => hbf_data_out(4)
--        );

--    u_channel_swap_final_i : channel_swap_hbf_i
--        generic map(
--            CHANNEL_NUMBERS         => CHANNEL_NUMBERS/2        ,--: natural:= 4;
--            HOVS                    => 1                        ,--: natural:= 4;
--            WIDTH_IN                => DUC_WIDTH_O_HB            --: natural:= 16
--        )
--        port map(
--            RST                     => RST_307                  ,--: in  std_logic;
--            CLK                     => CLK_307                  ,--: in  std_logic;

--            FRAME_I                 => hbf_frame_out(3)         ,--: in  std_logic;
--            VALID_I                 => hbf_valid_out(3)         ,--: in  std_logic;
--            FILTER_IN               => hbf_data_out(3)          ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);        -- 2 continuous data per each channel, x1 rate

--            FRAME_O                 => ch_swap_frame_out(3)     ,--: out std_logic;
--            VALID_O                 => ch_swap_valid_out(3)     ,--: out std_logic;
--            FILTER_OUT              => ch_swap_data_out(3)       --: out std_logic_vector(WIDTH_IN-1 downto 0)         -- 1 data per each channel, x2 rate
--        );

--    u_channel_swap_final_q : channel_swap_hbf_i
--        generic map(
--            CHANNEL_NUMBERS         => CHANNEL_NUMBERS/2        ,--: natural:= 4;
--            HOVS                    => 1                        ,--: natural:= 4;
--            WIDTH_IN                => DUC_WIDTH_O_HB            --: natural:= 16
--        )
--        port map(
--            RST                     => RST_307                  ,--: in  std_logic;
--            CLK                     => CLK_307                  ,--: in  std_logic;

--            FRAME_I                 => hbf_frame_out(3)         ,--: in  std_logic;
--            VALID_I                 => hbf_valid_out(3)         ,--: in  std_logic;
--            FILTER_IN               => hbf_data_out(4)          ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);        -- 2 continuous data per each channel, x1 rate

--            FRAME_O                 => ch_swap_frame_out(4)     ,--: out std_logic;
--            VALID_O                 => ch_swap_valid_out(4)     ,--: out std_logic;
--            FILTER_OUT              => ch_swap_data_out(4)       --: out std_logic_vector(WIDTH_IN-1 downto 0)         -- 1 data per each channel, x2 rate
--        );

    ------------------------------------------------------------------------------------------------------------------
    
--    process(CLK_307) begin
--        if rising_edge(CLK_307) then
--            if RST_307 = '1' then
--                NCO_FS <= '0';
--            else
--                if ch_swap_frame_out(4) = '1' then
--                    NCO_FS <= '1';
--                else
--                    NCO_FS <= '0';
--                end if;
--            end if;
--        end if;
--    end process;
    
    process(CLK_307) begin
        if rising_edge(CLK_307) then
        
            if RST_307 = '1' then
                NCO_FS <= '0';
                d_I_upsample_rearrange_valid <= '0';
                d_I_upsample_rearrange_frame <= '0';
                d_I_upsample_rearrange_data  <= (others => '0');
--                o_fir_lpf_valid <= '0';            
--                o_fir_lpf_data  <= (others => '0');
                flag_take_data <= '0';
                upsample_rearrange_dly_frame <= '0';
                upsample_rearrange_dly_valid <= '0';
                upsample_rearrange_dly_data_i <= (others => '0');
                upsample_rearrange_dly_data_q <= (others => '0');
--                o_fir_lpf_ready <= '0';
                
            else
                
                upsample_rearrange_dly_frame <= upsample_rearrange_frame;   
                upsample_rearrange_dly_valid <= upsample_rearrange_valid; 
                upsample_rearrange_dly_data_i  <= upsample_rearrange_data_i; 
                upsample_rearrange_dly_data_q  <= upsample_rearrange_data_q;   
                 
--                if(o_fir_lpf_ready = '1' and upsample_rearrange_frame = '1' and upsample_rearrange_valid = '1') then
                if(o_fir_lpf_ready_1d = '1'and o_fir_lpf_ready_2d = '1' and upsample_rearrange_frame = '1' and upsample_rearrange_valid = '1') then
                    flag_take_data <= '1';
                end if;
                
                if(flag_take_data = '1') then
                    d_I_upsample_rearrange_frame <= upsample_rearrange_dly_frame;   
                    d_I_upsample_rearrange_valid <= upsample_rearrange_dly_valid; 
                    d_I_upsample_rearrange_data_i  <= upsample_rearrange_dly_data_i; 
                    d_I_upsample_rearrange_data_q  <= upsample_rearrange_dly_data_q;
                else   
                    --I_upsample_rearrange_frame <= '0';
                    --I_upsample_rearrange_valid <= '0';
                    d_I_upsample_rearrange_valid <= '0';
                    d_I_upsample_rearrange_frame <= '0';
                    d_I_upsample_rearrange_data_i  <= (others => '0');
                    d_I_upsample_rearrange_data_q  <= (others => '0');
                    
                end if;
                if ch_swap_frame_out(4) = '1' then
                    NCO_FS <= '1';
                else
                    NCO_FS <= '0';
                end if;
            end if;
        end if;
    end process;
    
    -- NCO
    NCO_DUC: nco_ram_dither
        generic map(
            VENDOR                      => VENDOR,
            ACCU_VAL                    => DUC_NCO_ACCU_VAL/DUC_HB_N_OUT,
            WIDTH                       => DUC_NCO_WIDTH_IN,
            PRBS_SEL                    => 20,                                        --:natural:=20;
            HOVS                        => 1+(DUC_HB_N_OUT-1),
            CHANNEL_NUMBERS             => DUC_NCO_CHANNELS
        )
        port map(
            RST                         => RST_307,
            CLK                         => CLK_307,

            FS                          => ch_swap_frame_out(4), --NCO_FS,             --: in  std_logic;-- fs=1 then restart channel number from 0 to channel_numbers-1

            NCO_WREN                    => NCO_WREN,
            FREQ_OFF                    => NCO_FREQ_WORD,

            COS_O                       => nco_cos,
            SIN_O                       => nco_sin
        );
        
    --complex mult
    CMULT_STAGE : dduc_complex_mult
        generic map(
            VENDOR                      => VENDOR,

            WIDTH_IN                    => DUC_WIDTH_O_HB,
            NCO_WIDTH_IN                => DUC_NCO_WIDTH_IN,
            WIDTH_OUT                   => DUC_WIDTH_O_CMULT,
            BINARY_POINT                => DUC_BINARY_POINT_CMULT,

            ROUNDING                    => "ROUND_INF",
            OVERFLOW                    => "SATURATE",
            SUM_EN                      => 0,
            HOVS                        => 1+(DUC_HB_N_OUT-1)
        )
        port map(
            CLK                        => CLK_307,
            RST                        => RST_307,

            SINE_CONJUGATE             => '0'                      ,--: in  std_logic;

            FRAME_I                    => lpf_frame(0)              ,--ch_swap_frame_out(4)     ,--: in  std_logic;
            VALID_I                    => lpf_valid_sat(0)              ,--ch_swap_valid_out(4)     ,--: in  std_logic;

            DATA_IN_I                  => lpf_data_i                ,--ch_swap_data_out(3)      ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
            DATA_IN_Q                  => lpf_data_q                ,--ch_swap_data_out(4)      ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
            DATA_IN_COS                => nco_cos                  ,--: in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);
            DATA_IN_SIN                => nco_sin                  ,--: in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);

            FRAME_O                    => mult_frame_out           ,--: out std_logic;
            VALID_O                    => mult_valid_out           ,--: out std_logic;
            DATA_OUT_I                 => mult_data_out(0)         ,--: out std_logic_vector(WIDTH_OUT-1 downto 0);
            DATA_OUT_Q                 => mult_data_out(1)          --: out std_logic_vector(WIDTH_OUT-1 downto 0)
        );

    -- OUT
    process(RST_307, CLK_307)
    begin
        if RST_307 = '1' then
            DUC_FRAME_O            <= '0';
            DUC_VALID_O            <= '0';
            DUC_OUT                <= (others => (others => '0'));

            PIM_FRAME_O            <= '0';
            PIM_VALID_O            <= '0';
            PIM_OUT                <= (others => (others => '0'));
        elsif (rising_edge(CLK_307)) then
            DUC_FRAME_O            <= mult_frame_out;
            DUC_VALID_O            <= mult_valid_out;
            DUC_OUT                <= mult_data_out;

            PIM_FRAME_O            <= mult_frame_out;
            PIM_VALID_O            <= mult_valid_out;
            PIM_OUT                <= mult_data_out;
        end if;
    end process;

end rtl;
