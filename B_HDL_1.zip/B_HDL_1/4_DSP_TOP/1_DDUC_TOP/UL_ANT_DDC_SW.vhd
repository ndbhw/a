-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity UL_ANT_DDC_SW is
    generic    (
        ANT_NUM             : natural := 4
    );
    port (
        RESET                       : in std_logic;
        CLK                         : in std_logic; -- DUC operation clock

        UL_ANT_IN_DATA_I            : in std_logic_array16(ANT_NUM-1 downto 0);
        UL_ANT_IN_DATA_Q            : in std_logic_array16(ANT_NUM-1 downto 0);

        UL_ANT_IN_CONTROL           : in std_logic_vector(7 downto 0);  -- "00" ant.#0 , "01" ant#1 , "10" ant.#2 , "11" ant#3  max. antenna number 4.     if 6 or 8 => (3*DDC_NUM-1 downto 0)

        ODATA_0_I                   : out std_logic_vector(15 downto 0);
        ODATA_0_Q                   : out std_logic_vector(15 downto 0);
        ODATA_1_I                   : out std_logic_vector(15 downto 0);
        ODATA_1_Q                   : out std_logic_vector(15 downto 0)
        );
end UL_ANT_DDC_SW;

architecture arc_UL_ANT_DDC_SW of UL_ANT_DDC_SW is

    signal ul_in_i : std_logic_array16(7 downto 0);
    signal ul_in_q : std_logic_array16(7 downto 0);

begin


g_VALID : for i in ANT_NUM-1 downto 0 generate
    ul_in_i(i) <= UL_ANT_IN_DATA_I(i);
    ul_in_q(i) <= UL_ANT_IN_DATA_Q(i);
end generate;

g_INVALID : for i in 7 downto ANT_NUM generate
    ul_in_i(i) <= (others=>'0');
    ul_in_q(i) <= (others=>'0');
end generate;

process(RESET,CLK)
begin
   if RESET = '1' then
      ODATA_0_I <= (others => '0');
      ODATA_0_Q <= (others => '0');
   elsif (CLK'event and CLK = '1') then
      case UL_ANT_IN_CONTROL(2 downto 0) is
         when "000" =>
             ODATA_0_I <= ul_in_i(0);
             ODATA_0_Q <= ul_in_q(0);
         when "001" =>
             ODATA_0_I <= ul_in_i(1);
             ODATA_0_Q <= ul_in_q(1);
         when "010" =>
             ODATA_0_I <= ul_in_i(2);
             ODATA_0_Q <= ul_in_q(2);
         when "011" =>
             ODATA_0_I <= ul_in_i(3);
             ODATA_0_Q <= ul_in_q(3);
         when "100" =>
             ODATA_0_I <= ul_in_i(4);
             ODATA_0_Q <= ul_in_q(4);
         when "101" =>
             ODATA_0_I <= ul_in_i(5);
             ODATA_0_Q <= ul_in_q(5);
         when "110" =>
             ODATA_0_I <= ul_in_i(6);
             ODATA_0_Q <= ul_in_q(6);
         when "111" =>
             ODATA_0_I <= ul_in_i(7);
             ODATA_0_Q <= ul_in_q(7);
         when others =>
             ODATA_0_I <= (others => '0');
             ODATA_0_Q <= (others => '0');
      end case;
   end if;
end process;

process(RESET,CLK)
begin
   if RESET = '1' then
      ODATA_1_I <= (others => '0');
      ODATA_1_Q <= (others => '0');
   elsif (CLK'event and CLK = '1') then
      case UL_ANT_IN_CONTROL(6 downto 4) is
         when "000" =>
             ODATA_1_I <= ul_in_i(0);
             ODATA_1_Q <= ul_in_q(0);
         when "001" =>
             ODATA_1_I <= ul_in_i(1);
             ODATA_1_Q <= ul_in_q(1);
         when "010" =>
             ODATA_1_I <= ul_in_i(2);
             ODATA_1_Q <= ul_in_q(2);
         when "011" =>
             ODATA_1_I <= ul_in_i(3);
             ODATA_1_Q <= ul_in_q(3);
         when "100" =>
             ODATA_1_I <= ul_in_i(4);
             ODATA_1_Q <= ul_in_q(4);
         when "101" =>
             ODATA_1_I <= ul_in_i(5);
             ODATA_1_Q <= ul_in_q(5);
         when "110" =>
             ODATA_1_I <= ul_in_i(6);
             ODATA_1_Q <= ul_in_q(6);
         when "111" =>
             ODATA_1_I <= ul_in_i(7);
             ODATA_1_Q <= ul_in_q(7);
         when others =>
             ODATA_1_I <= (others => '0');
             ODATA_1_Q <= (others => '0');
      end case;
   end if;
end process;

end arc_UL_ANT_DDC_SW;
