-- Warning!!!!!!!!!!!!!!
-- Should be used only LTE BW 20M 4T4R 2 carrier case
-- Warning!!!!!!!!!!!!!!
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

library UNISIM;
use UNISIM.VComponents.all;

entity BBIQARY_TO_DXC is
    generic(
        DL_BBIQARY_NUM              : natural:=2;
        UL_BBIQARY_NUM              : natural:=2;
        DUC_NUM                     : natural:=4;
        DDC_NUM                     : natural:=4
    );
    port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;
        --BBCTRL 2 DSP IF
        DL_CHBW_IN                  : in  std_logic_array4 (DL_BBIQARY_NUM-1 downto 0);
        DL_BBSYNC_IN                : in  std_logic_vector (DL_BBIQARY_NUM-1 downto 0);
        DL_BBDATA_IN                : in  std_logic_array16(DL_BBIQARY_NUM-1 downto 0);
        --DUC IF
        DL_CHBW_OUT                 : out std_logic_array4 (DUC_NUM-1 downto 0);
        DL_BBSYNC_OUT               : out std_logic_vector (DUC_NUM-1 downto 0);
        DL_BBDATA_OUT               : out std_logic_array16(DUC_NUM-1 downto 0);
        --DDC IF
        UL_CHBW_OUT                 : out std_logic_array4 (DDC_NUM-1 downto 0);
        UL_BBSYNC_IN                : in  std_logic_vector (DDC_NUM-1 downto 0);
        UL_BBDATA_IN                : in  std_logic_array16(DDC_NUM-1 downto 0);
        --DSP 2 BBCTRL IF
        UL_CHBW_IN                  : in  std_logic_array4 (UL_BBIQARY_NUM-1 downto 0);
        UL_BBSYNC_OUT               : out std_logic_vector (UL_BBIQARY_NUM-1 downto 0);
        UL_BBDATA_OUT               : out std_logic_array16(UL_BBIQARY_NUM-1 downto 0)
    );
end BBIQARY_TO_DXC;

architecture ARC_BBIQARY_TO_DXC of BBIQARY_TO_DXC is

    signal i_dl_data                : std_logic_array17(DL_BBIQARY_NUM-1 downto 0);
    signal i_dl_data_dly            : std_logic_array17(DL_BBIQARY_NUM-1 downto 0);

    signal i_ul_cnt                 : std_logic_array3(UL_BBIQARY_NUM-1 downto 0);
    signal i_ul_data_dly            : std_logic_array16(UL_BBIQARY_NUM-1 downto 0);

begin

    --=================== DL side ==========================================
    g_DL_1X : if DUC_NUM = DL_BBIQARY_NUM generate
        DL_BBSYNC_OUT               <= DL_BBSYNC_IN  ;
        DL_BBDATA_OUT               <= DL_BBDATA_IN  ;
        i_dl_data                   <= (others=>(others=>'0'));
        i_dl_data_dly               <= (others=>(others=>'0'));
        DL_CHBW_OUT                 <= DL_CHBW_IN   ;
    end generate;

    g_DL_2X : if DUC_NUM = 2*DL_BBIQARY_NUM generate  
        g_DL_N : for i in DL_BBIQARY_NUM-1 downto 0 generate
            i_dl_data(i) <= DL_BBSYNC_IN(i) & DL_BBDATA_IN(i);

            g_SRL16E_DL_DATA : for n in 16 downto 0 generate
                SRL16E_inst : SRL16E
                generic map (
                    INIT => X"0000",
                    IS_CLK_INVERTED => '0')
                port map (
                    Q   => i_dl_data_dly(i)(n),                             -- SRL data output
                    A0  => '1',                                             -- Select[0] input
                    A1  => '1',                                             -- Select[1] input
                    A2  => '0',                                             -- Select[2] input
                    A3  => '0',                                             -- Select[3] input
                    CE  => '1',                                             -- Clock enable input
                    CLK => CLK,                                             -- Clock input
                    D   => i_dl_data(i)(n)                                  -- SRL data input
                );
            end generate;

            process(RST,CLK)
            begin
                if RST = '1' then
                    DL_BBSYNC_OUT(2*i)   <= '0';
                    DL_BBSYNC_OUT(2*i+1) <= '0';
                    DL_BBDATA_OUT(2*i)   <= (others => '0');
                    DL_BBDATA_OUT(2*i+1) <= (others => '0');
                elsif rising_edge(CLK) then
                    DL_BBSYNC_OUT(2*i)   <= i_dl_data_dly(i)(16);
                    DL_BBSYNC_OUT(2*i+1) <= i_dl_data_dly(i)(16);
                    DL_BBDATA_OUT(2*i)   <= i_dl_data_dly(i)(15 downto 0);
                    DL_BBDATA_OUT(2*i+1) <= DL_BBDATA_IN(i);
                end if;
            end process;

            DL_CHBW_OUT(2*i)        <= DL_CHBW_IN(i);
            DL_CHBW_OUT(2*i+1)      <= DL_CHBW_IN(i);
        end generate;
    end generate;

    --=================== UL side ==========================================
    g_UL_1X : if DDC_NUM = UL_BBIQARY_NUM generate
        UL_BBSYNC_OUT       <= UL_BBSYNC_IN  ;
        UL_BBDATA_OUT       <= UL_BBDATA_IN  ;
        i_ul_cnt            <= (others=>(others=>'0'));
        i_ul_data_dly       <= (others=>(others=>'0'));
        UL_CHBW_OUT         <= UL_CHBW_IN   ;
    end generate;

    g_UL_2X : if DDC_NUM = 2*UL_BBIQARY_NUM  generate        
        g_UL_N : for i in UL_BBIQARY_NUM-1 downto 0 generate
            process(RST,CLK)
            begin
            if RST = '1' then
                i_ul_cnt(i) <= (others => '1');
            elsif rising_edge(CLK) then
                if UL_BBSYNC_IN(2*i) = '1' then
                    i_ul_cnt(i) <= "001";
                else
                    i_ul_cnt(i) <= i_ul_cnt(i) + '1';  -- 0 ~ 7   Should be used only LTE BW 20M 4T4R 2 carrier case
                end if;
            end if;
            end process;

            SRL16E_UL_BB1_GEN : for n in 15 downto 0 generate
                SRL16E_inst : SRL16E
                generic map (
                    INIT => X"0000",
                    IS_CLK_INVERTED => '0')
                port map (
                    Q   => i_ul_data_dly(i)(n),   -- SRL data output
                    A0  => '1',                   -- Select[0] input
                    A1  => '1',                   -- Select[1] input
                    A2  => '0',                   -- Select[2] input
                    A3  => '0',                   -- Select[3] input
                    CE  => '1',                   -- Clock enable input
                    CLK => CLK,                   -- Clock input
                    D   => UL_BBDATA_IN(2*i+1)(n) -- SRL data input
                );
            end generate;

            process(RST,CLK)
            begin
                if RST = '1' then
                    UL_BBSYNC_OUT(i) <= '0';
                    UL_BBDATA_OUT(i) <= (others => '0');
                elsif rising_edge(CLK) then
                    UL_BBSYNC_OUT(i) <= UL_BBSYNC_IN(2*i);
                    if i_ul_cnt(i)(2) = '0' then
                        UL_BBDATA_OUT(i) <= UL_BBDATA_IN(2*i);
                    else
                        UL_BBDATA_OUT(i) <= i_ul_data_dly(i);
                    end if;
                end if;
            end process;

            UL_CHBW_OUT(2*i)        <= UL_CHBW_IN(i);
            UL_CHBW_OUT(2*i+1)      <= UL_CHBW_IN(i);
        end generate;
    end generate;

end ARC_BBIQARY_TO_DXC;