library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

package dduc_pkg is
    --DDUC common
    constant     db_1chip                 : boolean:= TRUE;

    constant     UL_TO_DL_LB_EN           : boolean:= false;
    constant     DL_PATH_ATT_EN           : boolean:= TRUE;
    constant     UL_PWR_MEAS_EN           : boolean:= TRUE;

    constant     DUC_HB_N_IN              : integer:= 0;                        --0:7.68Msps, 1:15.36Msps, 2:30.72Msps
    constant     DUC_ORDER_PFIR           : integer:= 124; -- Linh org 80;                       --24A 10M
    constant     DUC_HB_N_IN_MAX          : integer:= 2;                        --0:7.68Msps, 1:15.36Msps, 2:30.72Msps
    constant     DUC_HB_N_OUT             : integer:= 1;                        --0:245.76Msps, 1:122.88Msps, 2:61.44Msps

    constant     DDC_HB_N_OUT             : integer:= 0;                        --0:7.68Msps, 1:15.36Msps, 2:30.72Msps
    constant     DDC_HB_N_OUT_MAX         : integer:= 2;                        --0:7.68Msps, 1:15.36Msps, 2:30.72Msps
    constant     DDC_ORDER_PFIR           : integer:= 124;-- linh org 72;    

    constant     CHANNEL_NUMBERS          : integer:= 4;

    --DUC
    constant     DUC_WIDTH_I              : integer:= 16;
    constant     DUC_ATT_EN               : integer:= 1;                        -- 1:enable
    constant     DUC_ATT_WIDTH            : integer:= 16;
    constant     DUC_ATT_BIN_POINT        : integer:= 14;

    constant     DUC_HOVS_PFIR            : integer:= 2**(3-DUC_HB_N_IN_MAX);   --hardware oversampling
--    constant     DUC_ORDER_PFIR_MAX       : integer:= 80;                      --24A 10M
    constant     DUC_ORDER_PFIR_MAX       : integer:= 124;                      --24A 10M --100 Linh
    
    constant     DUC_WIDTH_COEFF_PFIR     : integer:= 16;
    constant     DUC_WIDTH_O_PFIR         : integer:= 16;
    constant     DUC_WIDTH_RESULT_PFIR    : integer:= 34;
    constant     DUC_BINARY_POINT_PFIR    : integer:= 14;

    constant     HBF1_FILTER_ORDER        : integer:= 16;
    constant     HBF2_FILTER_ORDER        : integer:= 8;    
    constant     HBF4_FILTER_ORDER        : integer:= 14; 

    constant     DUC_HB_N                 : integer:= 5;                        --number of half band filters
    type         duc_hb_n_ary             is array(DUC_HB_N-1 downto 0) of integer;       
    constant     DUC_HBF_ORDER            : integer_array(DUC_HB_N-1 downto 0) := (HBF4_FILTER_ORDER,HBF2_FILTER_ORDER,HBF2_FILTER_ORDER,HBF1_FILTER_ORDER,HBF1_FILTER_ORDER);
    constant     DUC_HOVS_HB              : duc_hb_n_ary:= (2,2,2,4,8);         -- comm/comm/10MHz/5MHz

    constant     DUC_WIDTH_COEFF_HB       : integer:= 16;
    constant     DUC_WIDTH_O_HB           : integer:= 16;
    constant     DUC_WIDTH_RESULT_HB      : integer:= 34;
    constant     DUC_BINARY_POINT_HB      : integer:= 14;                       --DUC_WIDTH_O_PFIR+DUC_WIDTH_COEFF_HB-DUC_WIDTH_O_HB-1;

    constant     DUC_NCO_N                : integer:= 1;                        --number of NCOs for DUC
    constant     DUC_NCO_CHANNELS         : integer:= 2;                        --channels in one NCO
    constant     DUC_NCO_WIDTH_IN         : integer:= 16;
    constant     DUC_NCO_ACCU_VAL         : integer:= 153600;                   -- 1K resolution
    constant     DUC_CMULT_N              : integer:= 1;                        -- number of complex multipliers
    constant     DUC_WIDTH_O_CMULT        : integer:= 16;
    constant     DUC_BINARY_POINT_CMULT   : integer:= DUC_WIDTH_O_HB+DUC_NCO_WIDTH_IN-DUC_WIDTH_O_CMULT-2;

    type         duc_hb_type              is array(natural range <>) of std_logic_vector(DUC_WIDTH_O_HB-1 downto 0);
    type         duc_output_type          is array(2*DUC_CMULT_N-1 downto 0) of std_logic_vector(DUC_WIDTH_O_CMULT-1 downto 0);

    --DDC
    constant     DDC_IN_N                 : integer:= 2;                        --number of input buses
    constant     DDC_WIDTH_I              : integer:= 16;
    constant     DDC_NCO_N                : integer:= 1;                        --number of NCOs for DDC
    constant     DDC_NCO_CHANNELS         : integer:= 2;                        --channels in one NCO
    constant     DDC_NCO_WIDTH_IN         : integer:= 16;
    constant     DDC_NCO_ACCU_VAL         : integer:= 153600;

    constant     DDC_ATT_EN               : integer:= 1;
    constant     DDC_ATT_WIDTH            : integer:= 16;
    constant     DDC_ATT_BIN_POINT        : integer:= 9;
    constant     DDC_WIDTH_O_MULT         : integer:= 16;
    constant     DDC_BINARY_POINT_MULT    : integer:= DDC_WIDTH_I+DDC_NCO_WIDTH_IN-DDC_WIDTH_O_MULT-2;

    constant     DDC_HB_N                 : integer:= 5;                        --number of half band filters
    type         ddc_hb_n_ary             is array(DDC_HB_N-1 downto 0) of integer;
    constant     DDC_HBF_ORDER            : integer_array(DDC_HB_N-1 downto 0):=(HBF1_FILTER_ORDER,HBF1_FILTER_ORDER,HBF2_FILTER_ORDER,HBF2_FILTER_ORDER,HBF4_FILTER_ORDER);
    constant     DDC_HOVS_HB              : ddc_hb_n_ary:=(8,4,2,2,2);          -- 5MHz/10MHz/comm/comm

    constant     DDC_WIDTH_COEFF_HB       : integer:= 16;
    constant     DDC_WIDTH_O_HB           : integer:= 16;
    constant     DDC_WIDTH_RESULT_HB      : integer:= 34;
    constant     DDC_BINARY_POINT_HB      : integer:= 15;

    constant     DDC_ORDER_PFIR_MAX       : integer:= 124; --linh org 72;
    constant     DDC_HOVS_PFIR            : integer:= 2**(3-DDC_HB_N_OUT_MAX);  --hardware oversampling

    constant     DDC_WIDTH_COEFF_PFIR     : integer:= 17;
    constant     DDC_WIDTH_O_PFIR         : integer:= 16;
    constant     DDC_WIDTH_RESULT_PFIR    : integer:= 34;
    constant     DDC_BINARY_POINT_PFIR    : integer:= 15;

    type         ddc_input_type           is array(DDC_IN_N-1 downto 0) of std_logic_vector(DDC_WIDTH_I-1 downto 0);
    type         ddc_hb_type              is array(natural range <>) of std_logic_vector(DDC_WIDTH_O_HB-1 downto 0);

    -- DUC LTE/NR PFIR  
    constant duc_pfir_coeff_5:integer_array(DUC_ORDER_PFIR_MAX/2-1 downto 0):=    
--    (17365,1304,-4043,1665,1208,-1785,341,1033,-939,-140,811,-448,-325,575,-144,-359,359,29,-314,182,110,-246,39,166,-302,156,0,0,0,0,0,0,0,0,0,0,0,0,0,0);                         -- rf2239 24A pkg
--    (17675,1585,-4206,1509,1454,-1804,116,1216,-858,-378,912,-297,-538,593,45,-518,305,224,-403,80,278,-255,-65,250,-117,-133,178,-15,-143,97,41,-116,30,58,-77,-14,47,-44,-36,70);
    (17675,1410,-4163,1652,1320,-1856,284,1154,-979,-233,932,-450,-450,683,-100,-504,436,122,-457,217,239,-355,44,274,-231,-74,251,-113,-137,193,-18,-153,123,45,-136,56,76,-101,6,80,-59,-27,69,-28,-34,42,4,-49,64,64,0,0,0,0,0,0,0,0,0,0,0,0);
    constant duc_pfir_coeff_10:integer_array(DUC_ORDER_PFIR_MAX/2-1 downto 0):=     
--    (17553,974,-3982,1945,936,-1857,660,865,-1123,161,765,-703,-92,647,-417,-222,521,-213,-277,395,-69,-284,278,27,-259,177,84,-217,94,112,-170,27,123,-134,-51,170,-268,116,0,0);  -- rf2239 24A pkg
--    (17675,1585,-4206,1509,1454,-1804,116,1216,-858,-378,912,-297,-538,593,45,-518,305,224,-403,80,278,-255,-65,250,-117,-133,178,-15,-143,97,41,-116,30,58,-77,-14,47,-44,-36,70);
    (17675,1410,-4163,1652,1320,-1856,284,1154,-979,-233,932,-450,-450,683,-100,-504,436,122,-457,217,239,-355,44,274,-231,-74,251,-113,-137,193,-18,-153,123,45,-136,56,76,-101,6,80,-59,-27,69,-28,-34,42,4,-49,64,64,0,0,0,0,0,0,0,0,0,0,0,0);
    
    constant duc_pfir_coeff_15:integer_array(DUC_ORDER_PFIR_MAX/2-1 downto 0):=   
    (14282,5352,-2452,-2505,1114,1700,-588,-1301,303,1051,-125,-872,5,733,80,-619,-141,522,184,-437,-213,363,232,-296,-242,237,245,-185,-242,138,235,-98,-224,62,210,-32,-194,6,176,15,-158,-32,140,46,-121,-56,103,64,-86,-70,70,76,-54,-85,40,109,-29,-193,301,-70,0,0);  -- nr
    -- DDC LTE/NR PFIR
    constant ddc_pfir_coeff_5:integer_array(DDC_ORDER_PFIR_MAX/2-1 downto 0):=    
    (35422,1297,-7596,4171,1193,-3299,1598,1005,-1817,634,766,-1010,185,513,-531,-22,270,-280,-100,180,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);                                            -- rf2239 24A pkg
    constant ddc_pfir_coeff_10:integer_array(DDC_ORDER_PFIR_MAX/2-1 downto 0):=    
    (35350,1486,-7788,4191,1429,-3610,1663,1320,-2215,692,1170,-1442,197,991,-929,-69,800,-568,-201,612,-314,-246,439,-143,-237,292,-37,-197,177,16,-146,102,36,-202,-66,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);        -- rf2239 24A pkg
    
    constant ddc_pfir_coeff_15:integer_array(DDC_ORDER_PFIR_MAX/2-1 downto 0):=    
    (28679,10598,-5025,-4915,2358,3314,-1311,-2527,747,2038,-394,-1692,155,1426,14,-1209,-135,1026,222,-868,-283,730,324,-607,-348,499,359,-403,-360,318,351,-244,-336,180,316,-125,-292,79,265,-41,-237,11,208,13,-180,-31,152,43,-127,-51,103,54,-82,-54,66,52,-56,-47,61,153,35,0);        
    
    -- HBF
    constant HBF1_DDC_COEFF : integer_array(HBF1_FILTER_ORDER/2-1 downto 0) := (8136,6032,3040,627,-498,-587,-293,-69);
    constant HBF1_COEFF : integer_array(HBF1_FILTER_ORDER/2-1 downto 0) := (20502,-5942,2674,-1214,491,-158,33,0);
    -- constant HBF2_COEFF : integer_array(HBF2_FILTER_ORDER/2-1 downto 0) := (19446,-3594,535,0);
    constant HBF2_COEFF : integer_array(HBF2_FILTER_ORDER/2-1 downto 0) := (19240,-3261,405,0);
    constant HBF4_COEFF : integer_array(HBF4_FILTER_ORDER/2-1 downto 0) := (20502,-5942,2674,-1214,491,-158,33);

end dduc_pkg;

package body dduc_pkg is

end dduc_pkg;
