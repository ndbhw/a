library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;
use work.dduc_pkg.all;

entity fir_d is
generic (
    VENDOR                      : string:="XILINX";
    HOVS                        : integer:=2;
    ORDER                       : integer:=12;

    CHANNEL_NUMBERS             : integer:=4;

    WIDTH_IN                    : integer:=16;
    WIDTH_COEFF                 : integer:=16;
    WIDTH_OUT                   : integer:=16;
    WIDTH_RESULT                : integer:=34;
    BINARY_POINT                : integer:=15
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN_0                 : in  std_logic_vector(WIDTH_IN-1 downto 0);
    FILTER_IN_1                 : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1  downto 0)
);
end fir_d;

architecture rtl of fir_d is

component dduc_delay_chain is
generic(
    BUFF_DEPTH                  : natural:= 16;-- SRL16E
    DIRECTION                   : natural:= 1; -- 1:forward, 0:reverse
    WIDTH_IN                    : natural:= 16 -- Input data width
);
port(
    CLK                         : in  std_logic;
    DATA_SEL                    : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

component dduc_dsp is
generic(
    PCIN_EN                     : boolean := FALSE;
    D_EN                        : boolean := FALSE;
    C_EN                        : boolean := FALSE;

    WIDTH_A                     : integer := 16;
    WIDTH_D                     : integer := 16;
    WIDTH_B                     : integer := 16;
    WIDTH_C                     : integer := 16;
    WIDTH_PCIN                  : integer := 48;
    WIDTH_PCOUT                 : integer := 48;
    WIDTH_P                     : integer := 48
);
port(
    CLK                         : in  std_logic;

    SEL                         : in  std_logic;
    CEP                         : in  std_logic;
    DSP_A_INV                   : in  std_logic;

    DSP_A                       : in  std_logic_vector(WIDTH_A-1 downto 0);
    DSP_D                       : in  std_logic_vector(WIDTH_D-1 downto 0);
    DSP_B                       : in  std_logic_vector(WIDTH_B-1 downto 0);
    DSP_C                       : in  std_logic_vector(WIDTH_C-1 downto 0);

    DSP_PCIN                    : in  std_logic_vector(WIDTH_PCIN-1 downto 0);
    DSP_PCOUT                   : out std_logic_vector(WIDTH_PCOUT-1 downto 0);
    DSP_P                       : out std_logic_vector(WIDTH_P-1 downto 0)
);
end component;

component round_stage is
generic(
    VAR_WIDTH                   : natural:= 5;
    FIXED_GAIN                  : natural:= 0;         --gain is fixed or not
    WIDTH_IN                    : natural:= 64;
    WIDTH_OUT                   : natural:= 32;
    BINARY_POINT                : natural:= 31;
    ROUNDING                    : string:= "ROUND_INF";--"FULL_PRECISION", "TRUNCATE","ROUND_INF", "ROUND_EVEN"
    OVERFLOW                    : string:= "WRAP"      --"SATURATE"
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    BIT_SHIFT_VALUE             : in  std_logic_vector(VAR_WIDTH-1 downto 0);

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1 downto 0)
);
end component;

constant DSP_MULT_NUM           : integer := 1; -- Number of multiplier per DSP resource
constant DSP_INSTANCES          : integer := ORDER/(2*DSP_MULT_NUM*HOVS)+ternary_func(ORDER mod (2*DSP_MULT_NUM*HOVS) = 0 , 0, 1);-- /2 for symmetric
constant DELAY_MEM_DEPTH        : integer := CHANNEL_NUMBERS*HOVS*2;-- *2 for waddr/raddr collision avoid
constant DELAY_MEM_NUM          : integer := ORDER/HOVS+ternary_func(ORDER mod HOVS = 0 , 0, 1);
constant DSP_INPUT_NUM          : integer := 2*DSP_INSTANCES;-- each DSP has 2 data input
constant DSP_COEF_NUM           : integer := HOVS;-- each multiplier has HOVS coefficient set
constant VDSP                   : integer := 4;-- DSP Valid latency(3) + DSP48 in register(2) - 1 (for DSP input registering), start from valid_odd
constant PROC_DELAY             : integer := 4+(HOVS-1)+2;-- DSP Valid latency(4) + HOVS (DSP Loopback cycle-1, last data aligned) + DSP48 in register(2)
constant WIDTH_DSP              : integer := 48;
constant WIDTH_C                : integer := 32;
constant BUFF_DEPTH_ODD         : integer := CHANNEL_NUMBERS*(ORDER/2-1)-(DSP_INSTANCES-1)+1;-- +1 to start zero index
constant BUFF_DEPTH_ODD_CLK     : integer := 3;-- +2(compensation DSP C input path) +1(compensation DSP A/B 1 registering) -- -1(register pipeline)
constant COEFF                  : integer_array(ORDER/2-1 downto 0) :=
                                  ternary_func(ORDER = HBF1_FILTER_ORDER , HBF1_COEFF,
                                  ternary_func(ORDER = HBF2_FILTER_ORDER , HBF2_COEFF, HBF4_COEFF)); 
                                --   ternary_func(ORDER = HBF3_FILTER_ORDER , HBF3_COEFF, HBF4_COEFF)));                                
                                
constant BINARY_VALUE           : std_logic_vector(BINARY_POINT-1 downto 0) := std_logic_vector(to_unsigned(2**(BINARY_POINT)-1,  BINARY_POINT));-- 0.499...

type data_array                 is array(natural range <>) of std_logic_vector(WIDTH_IN-1 downto 0);
type data_c_array               is array(natural range <>) of std_logic_vector(WIDTH_C-1 downto 0);
type coef_array                 is array(natural range <>) of std_logic_vector(WIDTH_COEFF-1 downto 0);
type chain_array                is array(natural range <>) of std_logic_vector(WIDTH_DSP-1 downto 0);
type hovs_array                 is array(natural range <>) of std_logic_vector(ternary_func(HOVS=1, 1, log2(HOVS))-1 downto 0);
type delay_sel_array            is array(natural range <>) of std_logic_vector(log2(DELAY_MEM_DEPTH)-1 downto 0);
type delay_sel_hovs_array       is array(natural range <>) of delay_sel_array(HOVS-1 downto 0);
type coeff_array                is array(natural range <>) of integer_array(DSP_COEF_NUM-1 downto 0);

signal frame_d                  : std_logic;
signal frame_dd                 : std_logic;
signal valid_d                  : std_logic;
signal odd_latch_0              : std_logic_vector(WIDTH_IN-1 downto 0);
signal odd_latch_1              : std_logic_vector(WIDTH_IN-1 downto 0);
signal even_latch_0             : std_logic_vector(WIDTH_IN-1 downto 0);

signal frame_odd                : std_logic;
signal valid_odd                : std_logic;
signal frame_even               : std_logic;
signal valid_even               : std_logic;

signal frame_o_d                : std_logic_vector(PROC_DELAY-1 downto 0);
signal valid_o_d                : std_logic_vector(PROC_DELAY-1 downto 0);

signal even_data                : std_logic_vector(WIDTH_IN-1 downto 0);
signal odd_data                 : std_logic_vector(WIDTH_IN-1 downto 0);
signal odd_sample_delay         : std_logic_vector(WIDTH_IN-1 downto 0);
signal odd_clk_delay            : std_logic_vector(WIDTH_IN-1 downto 0);

signal valid_dsp_i              : std_logic_vector(DSP_INSTANCES-1 downto 0);

signal ovs                      : hovs_array(DSP_INSTANCES-1 downto 0);
signal cin_r                    : std_logic_vector(31 downto 0);

signal delay_data_valid         : std_logic_vector(DELAY_MEM_NUM-1 downto 0);
signal delay_data_sel           : delay_sel_array(DELAY_MEM_NUM-1 downto 0);
signal delay_data_in            : data_array(DELAY_MEM_NUM-1 downto 0);
signal delay_data_out           : data_array(DELAY_MEM_NUM-1 downto 0);
signal dsp_data_in              : data_array(DSP_INPUT_NUM-1 downto 0);

signal sel                      : std_logic_vector(DSP_INSTANCES-1 downto 0);
signal dsp_a                    : data_array(DSP_INSTANCES-1 downto 0);
signal dsp_d                    : data_array(DSP_INSTANCES-1 downto 0);
signal dsp_b                    : coef_array(DSP_INSTANCES-1 downto 0);
signal dsp_c                    : data_c_array(DSP_INSTANCES-1 downto 0);
signal dsp_pcin                 : chain_array(DSP_INSTANCES-1 downto 0);
signal dsp_pcout                : chain_array(DSP_INSTANCES-1 downto 0);
signal dsp_p                    : chain_array(DSP_INSTANCES-1 downto 0);

--signal result                   : std_logic_vector(WIDTH_RESULT-1 downto 0);
signal valid_rnd                : std_logic;

attribute KEEP                  : string;
attribute KEEP of ovs                    : signal is "TRUE";
attribute KEEP of delay_data_in          : signal is "TRUE";
attribute KEEP of delay_data_valid       : signal is "TRUE";
attribute KEEP of delay_data_sel         : signal is "TRUE";
--attribute KEEP of delay_data_out_sh      : signal is "TRUE";
attribute KEEP of dsp_a                  : signal is "TRUE";
attribute KEEP of dsp_d                  : signal is "TRUE";
attribute MAX_FANOUT                     : integer;
attribute MAX_FANOUT of valid_o_d        : signal is 32;

-- Coefficient mapping function for DSP internal coefficient rom data
function coeff_init return coeff_array is
    variable result : coeff_array(DSP_MULT_NUM*DSP_INSTANCES-1 downto 0);
begin
    DSP_loop: for N in 0 to DSP_MULT_NUM*DSP_INSTANCES-1 loop-- each DSP has 2 coeff. set
        COEF_Loop: for M in 0 to DSP_COEF_NUM-1 loop
--            if HOVS*N+M < ORDER/2 then
            if M < HOVS then                        -- only #HOVS coefficients are valid
                if HOVS*N+M < ORDER/2 then          -- first, place coefficients in DSP, forward
                    result(N)(M) := COEFF(HOVS*N+M);
                else                                -- if last DSP has invalid HOVS cycle, fill it as symmetric HOVS cycle, reverse
                    result(N)(M) := COEFF((ORDER/2-1)-((HOVS*N+M) mod (ORDER/2)));
                end if;
            else
                result(N)(M) := 0;
            end if;
        end loop;
    end loop;
    return result;
end function coeff_init;

constant DSP_COEFF              : coeff_array(DSP_MULT_NUM*DSP_INSTANCES-1 downto 0) := coeff_init;

-- HOVS address mapping function for DSP internal coefficient rom data
function data_sel_init return delay_sel_hovs_array is
    variable result : delay_sel_hovs_array(DELAY_MEM_NUM-1 downto 0);
begin
    MEM_LOOP : for M in 0 to DELAY_MEM_NUM-1 loop
        HOVS_LOOP : for H in 0 to HOVS-1 loop
            if H = 0 then
                if M = 0  then
                    result(M)(H) :=  std_logic_vector(to_unsigned(1-1                       , log2(DELAY_MEM_DEPTH)));-- first delay chain, -1 for zero indexing (0)
                elsif M <= (DELAY_MEM_NUM-1)/2 and M /= DELAY_MEM_NUM-1 then-- if #mem is 2, no compensation, go to (H*C)
                    result(M)(H) :=  std_logic_vector(to_unsigned(CHANNEL_NUMBERS-1-1       , log2(DELAY_MEM_DEPTH)));-- forward path 1st (C-1)
                elsif M = DELAY_MEM_NUM/2 then
                    result(M)(H) :=  std_logic_vector(to_unsigned(CHANNEL_NUMBERS*HOVS-1    , log2(DELAY_MEM_DEPTH)));-- center delay (H*C)
                else
                    result(M)(H) :=  std_logic_vector(to_unsigned(CHANNEL_NUMBERS*HOVS+1-1  , log2(DELAY_MEM_DEPTH)));-- reverse path 1st (H*C+1)
                end if;
            else
                if M <= (DELAY_MEM_NUM-1)/2 then
                    result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))+CHANNEL_NUMBERS , log2(DELAY_MEM_DEPTH)));-- forward path 2nd (+C)
                elsif M = DELAY_MEM_NUM/2 then
                    result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))-CHANNEL_NUMBERS , log2(DELAY_MEM_DEPTH)));-- reverse path 2nd (-C)
                else
                    if (DELAY_MEM_NUM mod 2 = 0) and (H = 1) then -- +1 CLK compensation (valid_o_d(0)), careful!!!
                        result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))-CHANNEL_NUMBERS+1, log2(DELAY_MEM_DEPTH)));-- reverse path (-C)
                    else
                        result(M)(H) :=  std_logic_vector(to_unsigned(conv_integer(result(M)(H-1))-CHANNEL_NUMBERS  , log2(DELAY_MEM_DEPTH)));-- reverse path (-C)
                    end if;
                end if;
            end if;
        end loop;
    end loop;
    return result;
end function data_sel_init;

constant DELAY_HOVS_SEL         : delay_sel_hovs_array(DELAY_MEM_NUM-1 downto 0) := data_sel_init;

begin

    IN_GEN_HOVS_1 :if HOVS = 1 generate
        -- Input conversion : Apostrophe(') means even sample
        -- FILTER_IN_0 : I(CH0) , I(CH0)', I(CH2) , I(CH2)', ...
        -- FILTER_IN_1 : Q(CH1) , Q(CH1)', Q(CH3) , Q(CH3)', ...
        -- odd_data    : I(CH0) , Q(CH1) , I(CH2) , Q(CH3) , ...
        -- even_data   : I(CH0)', Q(CH1)', I(CH2)', Q(CH3)', ...
        process(CLK,RST)
        begin
            if RST='1' then
                frame_d  <= '0';
                frame_dd <= '0';
                valid_d  <= '0';
            elsif CLK'event and CLK='1' then
                frame_d  <= FRAME_I;
                frame_dd <= frame_d;
                valid_d  <= VALID_I;
            end if;
        end process;

        process(CLK,RST)
        begin
            if RST='1' then
                odd_latch_0 <= (others => '0');
                odd_latch_1 <= (others => '0');
            elsif CLK'event and CLK='1' then
                if VALID_I = '1' then
                    odd_latch_0 <= FILTER_IN_0;
                    odd_latch_1 <= FILTER_IN_1;
                end if;
            end if;
        end process;

       process(CLK,RST)
        begin
            if RST='1' then
                even_latch_0 <= (others => '0');
            elsif CLK'event and CLK='1' then
                if valid_d = '1' then
                    even_latch_0 <= FILTER_IN_1;
                end if;
            end if;
        end process;

        process(CLK,RST)
        begin
            if RST='1' then
                odd_data  <= (others => '0');
                even_data <= (others => '0');
            elsif CLK'event and CLK='1' then
                if valid_d = '1' then
                    odd_data <= odd_latch_0;
                    even_data<= FILTER_IN_0;
                else
                    odd_data <= odd_latch_1;
                    even_data<= even_latch_0;
                end if;
            end if;
        end process;

        frame_odd <= frame_dd;  -- 2 clock delay (synchronized with odd_data)
        valid_odd <= '1';       -- if HOVS=1, valid signal always should be '1'(full rate)
        frame_even<= frame_dd;
        valid_even<= '1';
    end generate IN_GEN_HOVS_1;

    IN_GEN_HOVS_N :if HOVS >= 2 generate
        odd_data  <= FILTER_IN_0;
        even_data <= FILTER_IN_0;

        frame_odd <= FRAME_I;
        valid_odd <= VALID_I;-- 1st sample = odd  sample
        process(CLK,RST)
        begin
            if RST='1' then
                frame_even<= '0';
                valid_even<= '0';
            elsif CLK'event and CLK='1' then
                frame_even<= frame_odd;-- aligened with valid_even
                valid_even<= valid_odd;
            end if;
        end process;
    end generate IN_GEN_HOVS_N;

    -- Delay for synchronization
    process(CLK,RST)
    begin
        if RST='1' then
            frame_o_d   <= (others => '0');
            valid_o_d   <= (others => '0');
        elsif CLK'event and CLK='1' then
            frame_o_d   <= frame_o_d(PROC_DELAY-2 downto 0) & frame_even;
            valid_o_d   <= valid_o_d(PROC_DELAY-2 downto 0) & valid_even;
        end if;
    end process;

    -- Even path delay
    DELAY_GEN : for N in 0 to DELAY_MEM_NUM-1 generate
    begin
        DELAY_GEN_0 : if N = 0 generate
        begin
            delay_data_valid(N) <= valid_o_d(HOVS-1);-- write only (HOVS)th data
            delay_data_in(N)    <= even_data;
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS)));
        end generate DELAY_GEN_0;
        DELAY_GEN_1 : if N > 0 and N <= DELAY_MEM_NUM/2-1 and N /= DELAY_MEM_NUM-1 generate
        begin
            delay_data_valid(N) <= valid_o_d(HOVS-1);-- write only (HOVS)th data
            delay_data_in(N)    <= delay_data_out(N-1);
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS)));
        end generate DELAY_GEN_1;
        DELAY_GEN_N2 : if N = DELAY_MEM_NUM/2 generate-- #N/2
        begin
            delay_data_valid(N) <= valid_o_d(HOVS-1);-- write only (HOVS)th data
            delay_data_in(N)    <= delay_data_out(N-1);
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS/2)));-- /2 : # of delay mem/2 = # of DSP
        end generate DELAY_GEN_N2;
        DELAY_GEN_N2P1 : if N = DELAY_MEM_NUM/2+1 generate-- #N/2+1
        begin
            -- if #mem is odd, first reverse mem should latch HOVSth data
            delay_data_valid(N) <= ternary_func(DELAY_MEM_NUM mod 2 = 0, valid_o_d(0), valid_o_d(HOVS-1));
            delay_data_in(N)    <= delay_data_out(N-1);
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS/2)));-- /2 : # of delay mem/2 = # of DSP
        end generate DELAY_GEN_N2P1;
        DELAY_GEN_N : if N > DELAY_MEM_NUM/2+1 and N <= DELAY_MEM_NUM-1 generate
        begin
            delay_data_valid(N) <= valid_o_d(0);-- reverse mem should latch only 1st data
            delay_data_in(N)    <= delay_data_out(N-1);
            delay_data_sel(N)   <= DELAY_HOVS_SEL(N)(conv_integer(ovs(N/HOVS/2)));-- /2 : # of delay mem/2 = # of DSP
        end generate DELAY_GEN_N;

    u_delay_chain_even : dduc_delay_chain
    generic map(
        BUFF_DEPTH                  => DELAY_MEM_DEPTH              ,--: natural:= 16;-- SRL16E
        DIRECTION                   => ternary_func(N <= DELAY_MEM_NUM/2, 1, 0),--: natural:= 1: -- 1:forward, 0:reverse
        WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
    )
    port map(
        CLK                         => CLK                          ,--: in  std_logic;
        DATA_SEL                    => delay_data_sel(N)            ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
        VALID_I                     => delay_data_valid(N)          ,--: in  std_logic;
        FILTER_IN                   => delay_data_in(N)             ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
        FILTER_OUT                  => delay_data_out(N)             --: out std_logic_vector(WIDTH_IN-1 downto 0)
    );
    end generate DELAY_GEN;

    -- DSP input data generation
    DSP_IN_DATA_GEN : for N in 0  to DSP_INPUT_NUM-1  generate
        -- number of valid data = filter order
        DSP_DATA_VALID_GEN : if N <= DELAY_MEM_NUM-1 generate
            -- Even path
            DSP_DATA_GEN_EVEN : if N mod 2 = 0 generate
                dsp_data_in(N) <= delay_data_out(N/2);
            end generate DSP_DATA_GEN_EVEN;
            -- Odd path
            DSP_DATA_GEN_ODD : if N mod 2 = 1 generate
                dsp_data_in(N) <= delay_data_out((DELAY_MEM_NUM-1)-N/2);
            end generate DSP_DATA_GEN_ODD;
        end generate DSP_DATA_VALID_GEN;
        -- mask zero to invalid DSP input
        DSP_DATA_INVALID_GEN : if N > DELAY_MEM_NUM-1 generate
            dsp_data_in(N) <= (others => '0');
        end generate DSP_DATA_INVALID_GEN;
    end generate DSP_IN_DATA_GEN;

    -- Odd path delay
    u_delay_sample_odd : dduc_delay_chain
    generic map(
        BUFF_DEPTH                  => BUFF_DEPTH_ODD               ,--: natural:= 16;-- SRL16E
        DIRECTION                   => 0                            ,--: natural:= 1: -- 1:forward, 0:reverse
        WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
    )
    port map(
        CLK                         => CLK                          ,--: in  std_logic;
        DATA_SEL                    => std_logic_vector(to_unsigned(BUFF_DEPTH_ODD-1, log2(BUFF_DEPTH_ODD))),
        VALID_I                     => valid_odd                    ,--: in  std_logic;
        FILTER_IN                   => odd_data                     ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
        FILTER_OUT                  => odd_sample_delay              --: out std_logic_vector(WIDTH_IN-1 downto 0)
    );

    u_delay_CLK_odd : dduc_delay_chain
    generic map(
        BUFF_DEPTH                  => BUFF_DEPTH_ODD_CLK           ,--: natural:= 16;-- SRL16E
        DIRECTION                   => 0                            ,--: natural:= 1: -- 1:forward, 0:reverse
        WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
    )
    port map(
        CLK                         => CLK                          ,--: in  std_logic;
        DATA_SEL                    => std_logic_vector(to_unsigned(BUFF_DEPTH_ODD_CLK-1, log2(BUFF_DEPTH_ODD_CLK))),
        VALID_I                     => '1'                          ,--: in  std_logic;
        FILTER_IN                   => odd_sample_delay             ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
        FILTER_OUT                  => odd_clk_delay                 --: out std_logic_vector(WIDTH_IN-1 downto 0)
    );

--    cin_r       <= asl(sign_extension(odd_clk_delay,32),15);-- synchronization for DSP input register 1 CLK
--    process(CLK,RST)
--    begin
--        if RST='1' then
--            cin_r       <= (others=>'0');
--        elsif CLK'event and CLK='1' then
            cin_r       <= sign_extension(odd_clk_delay,17) & BINARY_VALUE;-- synchronization for DSP input register 1 CLK
--        end if;
--    end process;

    DSP_BLOCK_GEN : for N in 0  to DSP_INSTANCES-1  generate
    begin
        -- DSP opcode
        process(CLK)
        begin
            if CLK'event and CLK='1' then
                valid_dsp_i(N) <= or_reduce(valid_o_d(VDSP-1+(HOVS-1) downto VDSP-1));

                if HOVS = 1 then
                    sel(N) <= '0';
                elsif valid_o_d(VDSP-2) = '1' then                                       -- only 1 cycle for adding PCIN, +2 CLK after DSP input data
                    sel(N) <= '0';--B*(A+D)+PCIN
                elsif or_reduce(valid_o_d(VDSP-1+(HOVS-2) downto VDSP-1)) = '1' then-- Valid dsp - 1 CLK cycle (HOVS cycle - 1)
                    sel(N) <= '1';
                else
                    sel(N) <= '0';
                end if;
            end if;
        end process;

        -- HOVS selection, each DSP use seperated ovs signal for performance
        process(CLK,RST)
        begin
            if RST='1' then
                ovs(N) <= (others=> '0');
            elsif CLK'event and CLK='1' then
                if HOVS = 1  then
                    ovs(N) <= (others=> '0');
                elsif valid_even = '1' then
                    ovs(N) <= (others=> '0');
                elsif or_reduce(valid_o_d(HOVS-2 downto 0)) = '1' then
                    ovs(N) <= ovs(N) + '1';
                end if;
            end if;
        end process;

        -- DSP Input(A/D/B) registering
        process(CLK,RST)
        begin
            if RST = '1' then
                dsp_a(N) <= (others => '0');
                dsp_d(N) <= (others => '0');
                dsp_b(N) <= (others => '0');
            elsif CLK'event and CLK='1' then
                dsp_a(N) <= dsp_data_in(2*N);
                dsp_d(N) <= dsp_data_in(2*N+1);
                dsp_b(N) <= sign_extension(DSP_COEFF(N)(conv_integer(ovs(N))),WIDTH_COEFF);
            end if;
        end process;

        -- DSP #0 Signal Generation
        DSP_SIG_GEN_N : if N < DSP_INSTANCES-1 generate
            dsp_c(N)    <= (others => '0');
            dsp_pcin(N) <= dsp_pcout(N+1);
        end generate DSP_SIG_GEN_N;

        DSP_SIG_GEN_LAST : if N = DSP_INSTANCES-1 generate
            dsp_c(N)    <= cin_r;
            dsp_pcin(N) <= (others => '0');
        end generate DSP_SIG_GEN_LAST;

        u_dduc_dsp : dduc_dsp
        generic map(
            PCIN_EN                     => ternary_func(N=DSP_INSTANCES-1,FALSE,TRUE) ,--: boolean := FALSE;
            D_EN                        => TRUE                         ,--: boolean := FALSE;
            C_EN                        => ternary_func(N=DSP_INSTANCES-1,TRUE,FALSE) ,--: boolean := FALSE;

            WIDTH_A                     => WIDTH_IN                     ,--: integer := 16;
            WIDTH_D                     => WIDTH_IN                     ,--: integer := 16;
            WIDTH_B                     => WIDTH_COEFF                  ,--: integer := 16;
            WIDTH_C                     => WIDTH_C                      ,--: integer := 16;
            WIDTH_PCIN                  => WIDTH_DSP                    ,--: integer := 48;
            WIDTH_PCOUT                 => WIDTH_DSP                    ,--: integer := 48;
            WIDTH_P                     => WIDTH_DSP                     --: integer := 48
        )
        port map(
            CLK                         => CLK                          ,--: in  std_logic;

            SEL                         => sel(N)                       ,--: in  std_logic;
            DSP_A_INV                   => '0'                          ,--: in  std_logic;
            CEP                         => valid_dsp_i(N)               ,--: in  std_logic;

            DSP_A                       => dsp_a(N)                     ,--: in  std_logic_vector(WIDTH_A-1 downto 0);
            DSP_D                       => dsp_d(N)                     ,--: in  std_logic_vector(WIDTH_D-1 downto 0);
            DSP_B                       => dsp_b(N)                     ,--: in  std_logic_vector(WIDTH_B-1 downto 0);
            DSP_C                       => dsp_c(N)                     ,--: in  std_logic_vector(WIDTH_C-1 downto 0);

            DSP_PCIN                    => dsp_pcin(N)                  ,--: in  std_logic_vector(WIDTH_PCIN-1 downto 0);
            DSP_PCOUT                   => dsp_pcout(N)                 ,--: out std_logic_vector(WIDTH_PCOUT-1 downto 0);
            DSP_P                       => dsp_p(N)                      --: out std_logic_vector(WIDTH_P-1 downto 0)
        );
    end generate DSP_BLOCK_GEN;

--    result<= sign_copy(dsp_p(0),WIDTH_RESULT);

    valid_rnd <= ternary_func(HOVS=1, '1', valid_o_d(PROC_DELAY-1));-- if HOVS=1, valid signal should be muxed, always '1' for full rate

    FRAME_O <= frame_o_d(PROC_DELAY-1);
    VALID_O <= valid_rnd;
    FILTER_OUT <= dsp_p(0)(WIDTH_OUT+BINARY_POINT downto BINARY_POINT+1);

--    round_stage_ins: round_stage
--    generic map(
--        VAR_WIDTH       => 1,
--        FIXED_GAIN      => 1,
--        WIDTH_IN        => WIDTH_RESULT,
--        WIDTH_OUT       => WIDTH_OUT,
--        BINARY_POINT    => BINARY_POINT,
--        ROUNDING        => "ROUND_INF",
--        OVERFLOW        => "SATURATE"
--    )
--    port map(
--        CLK             => CLK,
--        RST             => RST,
--        bit_shift_value => (others => '0'),
--        frame_i         => frame_o_d(PROC_DELAY-1),
--        valid_i         => valid_rnd,
--        filter_in       => result,
--        frame_o         => FRAME_O,
--        valid_o         => VALID_O,
--        filter_out      => FILTER_OUT
--    );

end rtl;
