-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2023, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2023.11.14 v1.0] Initial release
-- *****************************************************************************

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

entity cdc_sr_15_36_307m_245m is
    generic (
        DATA_WIDTH                          : integer := 16
    );
    Port ( 
        i_rst_307                           : in std_logic;
        i_clk_307                           : in std_logic;
        i_clk_245                           : in std_logic;

        -- 15.36MHz, 4 channel
        i_cdc_15_36_frame_307               : in std_logic;
        i_cdc_15_36_valid_307               : in std_logic;
        i_cdc_15_36_data_307                : in std_logic_vector(DATA_WIDTH-1 downto 0);

        -- 15.36MHz, 4 channel
        o_cdc_15_36_frame_245               : out std_logic;
        o_cdc_15_36_valid_245               : out std_logic;
        o_cdc_15_36_data_245                : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end cdc_sr_15_36_307m_245m;

architecture Behavioral of cdc_sr_15_36_307m_245m is

    component lib_xpm_sdpram is
        generic (
            MEMORY_TYPE                     : string := "block";
            CLOCK_MODE                      : string := "independent_clock";  -- "independent_clock" or "common_clock"
            RD_LATENCY                      : integer := 2;
            WT_DATA_WIDTH                   : integer := 16;
            RD_DATA_WIDTH                   : integer := 16;
            WT_ADDR_WIDTH                   : integer := 3;
            RD_ADDR_WIDTH                   : integer := 3
        );
        Port (
            i_clk_a                         : in std_logic;
            i_clk_b                         : in std_logic;
            
            i_wt_enable                     : in std_logic;
            i_wt_addra                      : in std_logic_vector(WT_ADDR_WIDTH-1 downto 0);
            i_wt_data                       : in std_logic_vector(WT_DATA_WIDTH-1 downto 0);
            
            i_rd_addrb                      : in std_logic_vector(RD_ADDR_WIDTH-1 downto 0);
            o_rd_doutb                      : out std_logic_vector(RD_DATA_WIDTH-1 downto 0)
        );
    end component;

    constant MEM_LATENCY                    : integer := 2;
    constant MEM_ADDR_W                     : integer := 10;
    constant MEM_DATA_W                     : integer := DATA_WIDTH+1;

    signal i_cdc_15_36_frame_307_d          : std_logic;
    signal i_cdc_15_36_valid_307_d          : std_logic;
    signal i_cdc_15_36_data_307_d           : std_logic_vector(DATA_WIDTH-1 downto 0);
    
    signal wt_enable                        : std_logic;
    signal wt_addra                         : std_logic_vector(MEM_ADDR_W-1 downto 0);
    signal wt_data                          : std_logic_vector(MEM_DATA_W-1 downto 0);
    signal rd_flag_reg_307                  : std_logic_vector(2-1 downto 0);
    signal rd_flag_307_1d                   : std_logic;
    signal rd_flag_reg_245                  : std_logic_vector(3-1 downto 0);
    signal cnt_4                            : std_logic_vector(2-1 downto 0);
    signal rd_valid_reg                     : std_logic_vector(MEM_LATENCY downto 0);
    signal rd_addrb                         : std_logic_vector(MEM_ADDR_W-1 downto 0);
    signal rd_doutb                         : std_logic_vector(MEM_DATA_W-1 downto 0);
        
begin

    ------------------------------------------------------------------------------------------------------------------------------------
    -- @ 307.2MHz

    process(i_clk_307)
    begin
        if (rising_edge(i_clk_307)) then
            i_cdc_15_36_frame_307_d         <=  i_cdc_15_36_frame_307;
            i_cdc_15_36_valid_307_d         <=  i_cdc_15_36_valid_307;
            i_cdc_15_36_data_307_d          <=  i_cdc_15_36_data_307;
        end if;
    end process;

    process(i_rst_307, i_clk_307)
    begin
        if (i_rst_307 = '1') then
            wt_enable                       <=  '0';
        elsif (rising_edge(i_clk_307)) then
            wt_enable                       <=  i_cdc_15_36_valid_307_d;
            wt_data                         <=  i_cdc_15_36_frame_307_d & i_cdc_15_36_data_307_d;
        end if;
    end process;

    process(i_rst_307, i_clk_307)
    begin
        if (i_rst_307 = '1') then
            wt_addra                        <=  (others=>'0');
        elsif (rising_edge(i_clk_307)) then
            if (wt_enable = '1') then
                wt_addra                    <=  wt_addra + '1';
            else
                wt_addra                    <=  wt_addra;
            end if;

            if (wt_addra = conv_std_logic_vector(7,MEM_ADDR_W) or wt_addra = conv_std_logic_vector(8,MEM_ADDR_W)) then
                rd_flag_reg_307(0)          <=  '1';
            else
                rd_flag_reg_307(0)          <=  '0';
            end if;
            rd_flag_reg_307(1)              <=  rd_flag_reg_307(0);
        end if;
    end process;

    cdc_buffer : lib_xpm_sdpram generic map ("block","independent_clock",MEM_LATENCY,MEM_DATA_W,MEM_DATA_W,MEM_ADDR_W,MEM_ADDR_W)
        Port map (
            i_clk_a                         =>  i_clk_307,              --: in std_logic;
            i_clk_b                         =>  i_clk_245,              --: in std_logic;
            
            i_wt_enable                     =>  wt_enable,              --: in std_logic;
            i_wt_addra                      =>  wt_addra,               --: in std_logic_vector(WT_ADDR_WIDTH-1 downto 0);
            i_wt_data                       =>  wt_data,                --: in std_logic_vector(WT_DATA_WIDTH-1 downto 0);
            
            i_rd_addrb                      =>  rd_addrb,               --: in std_logic_vector(RD_ADDR_WIDTH-1 downto 0);
            o_rd_doutb                      =>  rd_doutb                --: out std_logic_vector(RD_DATA_WIDTH-1 downto 0)
        );

    ------------------------------------------------------------------------------------------------------------------------------------
    -- @ 245.76MHz

    process(i_clk_245)
    begin
        if (rising_edge(i_clk_245)) then
            rd_flag_reg_245                         <=  rd_flag_reg_245(1 downto 0) & rd_flag_reg_307(1);
            rd_valid_reg(MEM_LATENCY downto 1)      <=  rd_valid_reg(MEM_LATENCY-1 downto 0);

            if (rd_flag_reg_245(2 downto 1) = b"01" or cnt_4 = b"11") then
                cnt_4                       <=  (others=>'0');
                rd_valid_reg(0)             <=  '1';
            else
                cnt_4                       <=  cnt_4 + '1';
                rd_valid_reg(0)             <=  '0';
            end if;

            if (rd_flag_reg_245(2 downto 1) = b"01") then
                rd_addrb                    <=  (others=>'0');
            elsif (cnt_4 = b"11") then
                rd_addrb                    <=  rd_addrb + '1';
            else
                rd_addrb                    <=  rd_addrb;
            end if;
        end if;
    end process;

    process(i_clk_245)
    begin
        if (rising_edge(i_clk_245)) then
            -- bram latency n clk
            if (rd_valid_reg(MEM_LATENCY) = '1') then 
                o_cdc_15_36_frame_245       <=  rd_doutb(MEM_DATA_W-1);
            else
                o_cdc_15_36_frame_245       <=  '0';
            end if;
            o_cdc_15_36_valid_245       <=  rd_valid_reg(MEM_LATENCY);
            o_cdc_15_36_data_245        <=  rd_doutb(MEM_DATA_W-2 downto 0);
        end if;
    end process;

end Behavioral;