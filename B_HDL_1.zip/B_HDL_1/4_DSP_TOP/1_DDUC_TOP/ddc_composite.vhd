--top level of ddc core
--structure is reset->mult->CIC decim /2, /4, /8->HB fir /2->channel mux->pfir
--must be configured properly by parameters!!!
--

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;
use work.dduc_pkg.all;

entity ddc_composite is
generic (
    DDC_IN_HOVS                 : integer
);
port(
    RST                         : in  std_logic;
    RST_307                     : in  std_logic;
    CLK                         : in  std_logic;
    CLK_307                     : in  std_logic;

    MODE                        : in  std_logic_vector(3 downto 0);
    NCO_WREN                    : in  std_logic_vector(DDC_NCO_CHANNELS-1 downto 0);
    NCO_FREQ_WORD               : in  std_logic_vector(DDC_NCO_CHANNELS*(log2(DDC_NCO_ACCU_VAL)-DDC_IN_HOVS/4)-1 downto 0);

    DDC_FRAME_I                 : in  std_logic;
    DDC_VALID_I                 : in  std_logic;
    DDC_IN                      : in  ddc_input_type;

    DDC_SYNC                    : out std_logic;
    DDC_OUT                     : out std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0)
);
end ddc_composite;

architecture rtl of ddc_composite is

    component reset_block is
    generic(
        CLEAR_SAMPLES               : integer:= 16;
        WIDTH_IN                    : integer:= 16
    );
    port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;
        FRAME_I                     : in  std_logic;
        VALID_I                     : in  std_logic;
        FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

        FRAME_O                     : out std_logic;
        VALID_O                     : out std_logic;
        FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1  downto 0);
        --SPECAIL for CIC
        CLR_O                       : out std_logic:='1';
        --SPECAIL for FIR
        RES_O                       : out std_logic:='1'
    );
    end component;

    component channel_swap_hbf_d is
    generic(
        CHANNEL_NUMBERS             : natural:= 4;
        HOVS                        : natural:= 2;
        WIDTH_IN                    : natural:= 16
    );
    port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        FRAME_I                     : in  std_logic;
        VALID_I                     : in  std_logic;
        FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);        -- 2 continuous data per each channel, x1 rate

        FRAME_O                     : out std_logic;
        VALID_O                     : out std_logic;
        FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)         -- 1 data per each channel, x2 rate
    );
    end component;

    component nco_ram_dither is
    generic(
        VENDOR                      : string :="XILINX";
        ACCU_VAL                    : natural:=12288;
        WIDTH                       : natural:=16;
        PRBS_SEL                    : natural:=20;
        HOVS                        : natural:=1;
        CHANNEL_NUMBERS             : natural:=1
    );
    port(
        RST                         :in  std_logic;
        CLK                         :in  std_logic;

        FS                          :in  std_logic;         -- fs=1 then restart channel number from 0 to channel_numbers-1

        NCO_WREN                    :in  std_logic_vector(CHANNEL_NUMBERS-1 downto 0);
        FREQ_OFF                    :in  std_logic_vector(CHANNEL_NUMBERS*log2(ACCU_VAL)-1 downto 0);-- offset

        SIN_O                       :out std_logic_vector(WIDTH-1 downto 0);
        COS_O                       :out std_logic_vector(WIDTH-1 downto 0)
    );
    end component;

    component dduc_complex_mult is
    generic(
        VENDOR                      : string    := "XILINX";    -- "XILINX", "ALTERA"

        WIDTH_IN                    : natural   := 16;
        NCO_WIDTH_IN                : natural   := 16;
        WIDTH_OUT                   : natural   := 16;
        BINARY_POINT                : natural   := 15;           -- BINARY_POINT = WIDTH_IN+NCO_WIDTH_IN-WIDTH_OUT-1

        ROUNDING                    : string    := "ROUND_INF"; --"FULL_PRECISION","TRUNCATE","ROUND_INF", "ROUND_EVEN"
        OVERFLOW                    : string    := "SATURATE";  --"WRAP","SATURATE"
        SUM_EN                      : natural   := 0;           -- 1 : I+I, Q+Q for DUC output summation mode, 0 : bypass
        HOVS                        : natural   := 1
    );
    port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        SINE_CONJUGATE              : in  std_logic;

        FRAME_I                     : in  std_logic;
        VALID_I                     : in  std_logic;

        DATA_IN_I                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
        DATA_IN_Q                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
        DATA_IN_COS                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);
        DATA_IN_SIN                 : in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);

        FRAME_O                     : out std_logic;
        VALID_O                     : out std_logic;
        DATA_OUT_I                  : out std_logic_vector(WIDTH_OUT-1 downto 0);
        DATA_OUT_Q                  : out std_logic_vector(WIDTH_OUT-1 downto 0)
    );
    end component;

    component fir_d is
    generic (
        VENDOR                      : string:="XILINX";
        HOVS                        : integer:=2;
        ORDER                       : integer:=12;

        CHANNEL_NUMBERS             : integer:=8;

        WIDTH_IN                    : integer:=16;
        WIDTH_OUT                   : integer:=16;
        WIDTH_COEFF                 : integer:=16;
        WIDTH_RESULT                : integer:=33;
        BINARY_POINT                : integer:=15
    );
    port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        FRAME_I                     : in  std_logic;
        VALID_I                     : in  std_logic;
        FILTER_IN_0                 : in  std_logic_vector(WIDTH_IN-1 downto 0);
        FILTER_IN_1                 : in  std_logic_vector(WIDTH_IN-1 downto 0);

        FRAME_O                     : out std_logic;
        VALID_O                     : out std_logic;
        FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1  downto 0)
    );
    end component;

    component channel_mux is
    generic(
        HOVS                        : natural:= 4;
        WIDTH_IN                    : natural:= 16
    );
    port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        FRAME_I                     : in  std_logic;
        VALID_I                     : in  std_logic;
        FILTER_IN                   : in  std_logic_vector(2*WIDTH_IN-1 downto 0);

        FRAME_O                     : out std_logic;
        VALID_O                     : out std_logic;
        FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
    );
    end component;

    component fir_pfir is
    generic(
        VENDOR                      : string := "XILINX";
        DDUC_SEL                    : integer:= 0;-- 0 : DUC, 1 : DDC
        CHANNEL_NUMBERS             : integer:= 4;

        WIDTH_IN                    : integer:= 16;
        WIDTH_OUT                   : integer:= 16;
        WIDTH_COEFF                 : integer:= 16;

        WIDTH_RESULT                : integer:= 32;
        BINARY_POINT                : integer:= 15;

        HOVS                        : integer:= 2;
        ORDER                       : integer:= 96
    );
    port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        MODE                        : in  std_logic_vector(3 downto 0);

        FRAME_I                     : in  std_logic;
        VALID_I                     : in  std_logic;
        FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

        FRAME_O                     : out std_logic;
        VALID_O                     : out std_logic;
        FILTER_OUT                  : out std_logic_vector(WIDTH_OUT-1  downto 0)
    );
    end component;

    component dduc_delay is
    generic(
        DATA_WIDTH                  : integer:= 16;
        CHANNEL_NUMBER              : integer:= 4;
        MAX_DELAY_SAMPLE            : integer:= 256;
        MAX_DELAY_CLOCK             : integer:= 16
    );
    port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        DLY_SAMPLE                  : in  std_logic_vector(log2(MAX_DELAY_SAMPLE)-1 downto 0);
        DLY_CLOCK                   : in  std_logic_vector(log2(MAX_DELAY_CLOCK)-1 downto 0);

        FRAME_I                     : in  std_logic;
        VALID_I                     : in  std_logic;
        DATA_IN                     : in  std_logic_vector(DATA_WIDTH-1 downto 0);

        FRAME_O                     : out std_logic;
        VALID_O                     : out std_logic;
        DATA_OUT                    : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
    end component;

    component ddc_if is
    generic(
        CHANNEL_NUMBERS             : natural:= 4;
        WIDTH_IN                    : natural:= 16
    );
    port(
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        FRAME_I                     : in  std_logic;
        VALID_I                     : in  std_logic;
        FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

        DDC_SYNC                    : out std_logic;
        DDC_OUT                     : out std_logic_vector(WIDTH_IN-1 downto 0)
    );
    end component;

    component dduc_lpf is
        generic (
            DDUC_TYPE                           : string := "DUC";  -- "DUC" or "DDC"
            DATA_WIDTH                          : integer := 16;
            BINARY_POINT                        : integer := 15
        );
        Port (
            i_rst_307                           : in std_logic;
            i_clk_307                           : in std_logic;
            
            -- 76.8MHz, 4 channel
            i_upsample_rearrange_frame          : in std_logic;
            i_upsample_rearrange_valid          : in std_logic;
            i_upsample_rearrange_data           : in std_logic_vector(DATA_WIDTH-1 downto 0);
    
            -- 76.8MHz, 4 channel
            o_lpf_frame                         : out std_logic;
            o_lpf_valid                         : out std_logic;
            o_lpf_data                          : out std_logic_vector(DATA_WIDTH-1 downto 0)
        );
    end component;

    component cdc_sr_15_36_307m_245m is
        generic (
            DATA_WIDTH                          : integer := 16
        );
        Port ( 
            i_rst_307                           : in std_logic;
            i_clk_307                           : in std_logic;
            i_clk_245                           : in std_logic;
    
            -- 15.36MHz, 4 channel
            i_cdc_15_36_frame_307               : in std_logic;
            i_cdc_15_36_valid_307               : in std_logic;
            i_cdc_15_36_data_307                : in std_logic_vector(DATA_WIDTH-1 downto 0);
    
            -- 15.36MHz, 4 channel
            o_cdc_15_36_frame_245               : out std_logic;
            o_cdc_15_36_valid_245               : out std_logic;
            o_cdc_15_36_data_245                : out std_logic_vector(DATA_WIDTH-1 downto 0)
        );
    end component;

    constant MAX_DELAY_SAMPLE       : integer := 512;
    constant MAX_DELAY_CLOCK        : integer := 16;
    constant DELAY_SAMPLE_WIDTH     : integer := log2(MAX_DELAY_SAMPLE);
    constant DELAY_CLOCK_WIDTH      : integer := log2(MAX_DELAY_CLOCK);
    constant DLY_S_5M_HOVS2         : std_logic_vector(DELAY_SAMPLE_WIDTH-1 downto 0) := std_logic_vector(to_unsigned(0,   DELAY_SAMPLE_WIDTH));
    constant DLY_S_10M_HOVS2        : std_logic_vector(DELAY_SAMPLE_WIDTH-1 downto 0) := std_logic_vector(to_unsigned(18+DDC_ORDER_PFIR/2,   DELAY_SAMPLE_WIDTH));
    constant DLY_S_20M_HOVS2        : std_logic_vector(DELAY_SAMPLE_WIDTH-1 downto 0) := std_logic_vector(to_unsigned(56+DDC_ORDER_PFIR/2*3, DELAY_SAMPLE_WIDTH));
    
    constant DLY_C_5M_HOVS2         : std_logic_vector(DELAY_CLOCK_WIDTH-1 downto 0)  := std_logic_vector(to_unsigned(0,   DELAY_CLOCK_WIDTH));
    constant DLY_C_10M_HOVS2        : std_logic_vector(DELAY_CLOCK_WIDTH-1 downto 0)  := std_logic_vector(to_unsigned(12,   DELAY_CLOCK_WIDTH));
    constant DLY_C_20M_HOVS2        : std_logic_vector(DELAY_CLOCK_WIDTH-1 downto 0)  := std_logic_vector(to_unsigned(3+7,   DELAY_CLOCK_WIDTH));

    signal clr_r                    : std_logic;
    signal res_r                    : std_logic;
    signal clr_r_245                : std_logic;
    signal res_r_245                : std_logic;

    signal nco_sin                  : std_logic_vector(DDC_NCO_WIDTH_IN-1 downto 0);
    signal nco_cos                  : std_logic_vector(DDC_NCO_WIDTH_IN-1 downto 0);

    signal mult_frame_out           : std_logic;
    signal mult_valid_out           : std_logic;
    signal mult_data_out            : ddc_input_type;
    signal mult_data_TEST            : ddc_input_type;

    signal ch_swap_frame            : std_logic_vector(DDC_HB_N-1 downto 0);
    signal ch_swap_valid            : std_logic_vector(DDC_HB_N-1 downto 0);
    signal ch_swap_data             : ddc_hb_type(DDC_HB_N-1 downto 0);

    signal hbf_frame_in             : std_logic_vector(DDC_HB_N-1 downto 0);
    signal hbf_valid_in             : std_logic_vector(DDC_HB_N-1 downto 0);
    signal hbf_data_in              : ddc_hb_type(DDC_HB_N-1 downto 0);

    signal hbf_frame_out            : std_logic_vector(DDC_HB_N-1 downto 0);
    signal hbf_valid_out            : std_logic_vector(DDC_HB_N-1 downto 0);
    signal hbf_data_out             : ddc_hb_type(DDC_HB_N-1 downto 0);

    signal ch_mux_frame_in          : std_logic;
    signal ch_mux_valid_in          : std_logic;
    signal ch_mux_data_in           : std_logic_vector(2*DDC_WIDTH_O_HB-1 downto 0);-- 1 data per each channel, x2 rate

    signal pfir_frame               : std_logic;
    signal pfir_valid               : std_logic;
    signal pfir_data                : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);

    signal i_ddc_frame_o            : std_logic;
    signal i_ddc_valid_o            : std_logic;
    signal i_ddc_out                : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);

    signal dly_frame                : std_logic;
    signal dly_valid                : std_logic;
    signal dly_data                 : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);

    signal dly_sample               : std_logic_vector(log2(MAX_DELAY_SAMPLE)-1 downto 0);
    signal dly_clock                : std_logic_vector(log2(MAX_DELAY_CLOCK)-1 downto 0);

    signal i_ddc_if_sync            : std_logic;
    signal i_ddc_if_out             : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    signal cnt2                     : std_logic_vector(1-1 downto 0);
    signal cnt4                     : std_logic_vector(2-1 downto 0);
    signal cnt5                     : std_logic_vector(3-1 downto 0);
    signal cnt5_2                   : std_logic_vector(3-1 downto 0);
    signal lpf_frame_in             : std_logic;
    signal lpf_valid_in             : std_logic;
    signal lpf_data_in              : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    
    signal lpf_frame_in1            : std_logic;
    signal lpf_valid_in1            : std_logic;
    signal lpf_data_in1             : ddc_input_type;--std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);

    signal lpf_frame                : std_logic;
    signal lpf_valid                : std_logic;
    signal lpf_data                 : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    
    signal lpf_frame_I              : std_logic;
    signal lpf_valid_I              : std_logic;
    signal lpf_data_I               : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    
    signal lpf_frame_Q              : std_logic;
    signal lpf_valid_Q              : std_logic;
    signal lpf_data_Q               : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);

    signal lpf_frame_1d             : std_logic;
    signal lpf_valid_1d             : std_logic;
    signal lpf_data_1d              : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    
    signal lpf_frame_1d_I           : std_logic;
    signal lpf_valid_1d_I           : std_logic;
    signal lpf_data_1d_I            : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    signal lpf_data_1d_Q            : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);

    signal downsample_frame         : std_logic;
    signal downsample_valid         : std_logic;
    signal downsample_data          : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    
    signal downsample_frame_I       : std_logic;
    signal downsample_valid_I       : std_logic;
    signal downsample_data_I        : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    signal downsample_data_Q        : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);

    signal frame_15_36              : std_logic;
    signal valid_15_36              : std_logic;
    signal data_15_36               : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    
    signal frame_15_36_I            : std_logic;
    signal valid_15_36_I            : std_logic;
    signal data_15_36_I             : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    
    signal frame_15_36_Q            : std_logic;
    signal valid_15_36_Q            : std_logic;
    signal data_15_36_Q             : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);

    signal ctn4_2                   : std_logic_vector(2-1 downto 0);
    signal ctn4_3                   : std_logic_vector(3-1 downto 0);
    signal frame_15_36_d            : std_logic;
    signal valid_15_36_d            : std_logic;
    signal data_15_36_d             : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    signal NCO_FS                   : std_logic_vector(2 downto 0);
    
    signal downsample_valid_I_d     : std_logic;
    signal downsample_frame_I_d     : std_logic;
    
    signal frame_15_36_d_I          : std_logic;
    signal valid_15_36_d_I          : std_logic;
    signal valid_15_36_d_IQ         : std_logic;
    signal valid_15_36_d_Q          : std_logic;
    signal data_15_36_d_I           : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    signal data_15_36_d_Q           : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    signal data_15_36_dd_Q          : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    signal data_15_36_ddd_Q         : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    signal valid_15_36_dd_Q         : std_logic;
    signal valid_15_36_ddd_Q        : std_logic;
    signal data_15_36_d_IQ           : std_logic_vector(DDC_WIDTH_O_PFIR-1 downto 0);
    
    signal cnt_IQ                   : std_logic_vector(1 downto 0);

begin

    -- reset block -----------------------------------------------------------------------------------------
    RESET_STAGE_307 : reset_block
        generic map(
            CLEAR_SAMPLES                   => 8192,                --+100 for ETC
            WIDTH_IN                        => DDC_WIDTH_I
        )
        port map(
            RST                             => RST_307,
            CLK                             => CLK_307,

            FRAME_I                         => '1',
            VALID_I                         => '1',
            FILTER_IN                       => (others => '0'),

            FRAME_O                         => open,
            VALID_O                         => open,
            FILTER_OUT                      => open,
            CLR_O                           => clr_r,
            RES_O                           => res_r
        );
    
    RESET_STAGE_245 : reset_block
        generic map(
            CLEAR_SAMPLES                   => 8192,                --+100 for ETC
            WIDTH_IN                        => DDC_WIDTH_I
        )
        port map(
            RST                             => RST,
            CLK                             => CLK,

            FRAME_I                         => '1',
            VALID_I                         => '1',
            FILTER_IN                       => (others => '0'),

            FRAME_O                         => open,
            VALID_O                         => open,
            FILTER_OUT                      => open,
            CLR_O                           => clr_r_245,
            RES_O                           => res_r_245
        );
        
    process(CLK_307) begin               -- donghn: sync for NCO
    if rising_edge(CLK_307) then
        if RST_307 = '1' then
            NCO_FS <= (others => '0');
        else               
            NCO_FS(0) <= DDC_FRAME_I;              
            NCO_FS(2 downto 1) <= NCO_FS(1 downto 0);
        end if;
    end if;
end process;

    -- NCO block -----------------------------------------------------------------------------------------
    NCO_DDC : nco_ram_dither
        generic map(
            VENDOR                          => "XILINX",
            ACCU_VAL                        => DDC_NCO_ACCU_VAL/(DDC_IN_HOVS/2),
            WIDTH                           => DDC_NCO_WIDTH_IN,
            PRBS_SEL                        => 20                                       ,--:natural:=20;
            HOVS                            => DDC_IN_HOVS/2,
            CHANNEL_NUMBERS                 => DDC_NCO_CHANNELS
        )
        port map(
            RST                             => RST_307,
            CLK                             => CLK_307,

            FS                              => DDC_FRAME_I,

            NCO_WREN                        => NCO_WREN,
            FREQ_OFF                        => NCO_FREQ_WORD,

            SIN_O                           => nco_sin,
            COS_O                           => nco_cos
        );
    
    --input port I :   A_I / B_I
    --input port Q :   A_Q / B_Q
    CMULT_STAGE : dduc_complex_mult
        generic map(
            VENDOR                          => VENDOR,

            WIDTH_IN                        => DDC_WIDTH_I,
            NCO_WIDTH_IN                    => DDC_NCO_WIDTH_IN,
            WIDTH_OUT                       => DDC_WIDTH_O_MULT,
            BINARY_POINT                    => DDC_BINARY_POINT_MULT,

            ROUNDING                        => "ROUND_INF",
            OVERFLOW                        => "SATURATE",--"SATURATE"
            SUM_EN                          => 0,
            HOVS                            => DDC_IN_HOVS/2
        )
        port map(
            RST                             => res_r,
            CLK                             => CLK_307,

            SINE_CONJUGATE                  => '0'                      ,--: in  std_logic;

            FRAME_I                         => DDC_FRAME_I              ,--: in  std_logic;
            VALID_I                         => DDC_VALID_I              ,--: in  std_logic;
            
            -- (0) i I I
            -- (1) Q Q Q
            DATA_IN_I                       => DDC_IN(0)                ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
            DATA_IN_Q                       => DDC_IN(1)                ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);    
    
            DATA_IN_COS                     => nco_cos                  ,--: in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);
            DATA_IN_SIN                     => nco_sin                  ,--: in  std_logic_vector(NCO_WIDTH_IN-1 downto 0);

            FRAME_O                         => mult_frame_out           ,--: out std_logic;
            VALID_O                         => mult_valid_out           ,--: out std_logic;
            DATA_OUT_I                      => mult_data_out(0)         ,--: out std_logic_vector(WIDTH_OUT-1 downto 0);
            DATA_OUT_Q                      => mult_data_out(1)          --: out std_logic_vector(WIDTH_OUT-1 downto 0)
        );
        
    --DOANH
    process(CLK_307)
    begin
        if (rising_edge(CLK_307)) then
            if (mult_frame_out = '1') then cnt2 <= (others=>'0'); else cnt2 <= cnt2 + '1'; end if;

            if (mult_frame_out = '1' or cnt2 = b"1") then lpf_frame_in1 <= '1'; else lpf_frame_in1 <= '0'; end if;

            lpf_valid_in1                    <=  mult_valid_out;
            --lpf_data_in1                     <=  mult_data_TEST;
            lpf_data_in1                     <=  mult_data_out;
        end if;
    end process;
    
    
    process(CLK_307)
    begin
		if res_r = '1' then 
			mult_data_TEST <= (others => (others => '0'));
			
        elsif (rising_edge(CLK_307)) then
            
                mult_data_TEST(0)               <=  mult_data_TEST(0) + 2;
				mult_data_TEST(1)               <=  mult_data_TEST(0) + 1;

           
        end if;
    end process;

    ch_swap_frame(0)                        <= mult_frame_out;
    ch_swap_valid(0)                        <= mult_valid_out;
    ch_swap_data(0)                         <= mult_data_out(0);
    ch_swap_frame(1)                        <= mult_frame_out;
    ch_swap_valid(1)                        <= mult_valid_out;
    ch_swap_data(1)                         <= mult_data_out(1);

--    -- HBF2 block -----------------------------------------------------------------------------------------
--    HBF_GEN_1st : for  N in 0 to 1 generate
--        u_channel_swap_hbf_d : channel_swap_hbf_d
--            generic map(
--                CHANNEL_NUMBERS             => CHANNEL_NUMBERS/2            ,--: natural:= 4;
--                HOVS                        => DDC_HOVS_HB(N)/2             ,--: natural:= 2;
--                WIDTH_IN                    => DDC_WIDTH_I                   --: natural:= 16
--            )
--            port map(
--                RST                         => res_r                        ,--: in  std_logic;
--                CLK                         => CLK_307                      ,--: in  std_logic;

--                FRAME_I                     => ch_swap_frame(N)             ,--: in  std_logic;
--                VALID_I                     => ch_swap_valid(N)             ,--: in  std_logic;
--                FILTER_IN                   => ch_swap_data(N)              ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);

--                FRAME_O                     => hbf_frame_in(N)              ,--: out std_logic;
--                VALID_O                     => hbf_valid_in(N)              ,--: out std_logic;
--                FILTER_OUT                  => hbf_data_in(N)                --: out std_logic_vector(WIDTH_IN-1 downto 0)
--            );

--        HBF_1 : if N = 1 generate
--            HBF_D: fir_d
--            generic map(
--                VENDOR                      => VENDOR,
--                HOVS                        => DDC_HOVS_HB(N)/2,
--                ORDER                       => DDC_HBF_ORDER(N),

--                CHANNEL_NUMBERS             => CHANNEL_NUMBERS,

--                WIDTH_IN                    => DDC_WIDTH_O_MULT,
--                WIDTH_OUT                   => DDC_WIDTH_O_HB,
--                WIDTH_COEFF                 => DDC_WIDTH_COEFF_HB,
--                WIDTH_RESULT                => DDC_WIDTH_RESULT_HB,
--                BINARY_POINT                => DDC_BINARY_POINT_HB
--            )
--            port map(
--                RST                         => res_r,
--                CLK                         => CLK_307,

--                FRAME_I                     => hbf_frame_in(N),
--                VALID_I                     => hbf_valid_in(N),
--                FILTER_IN_0                 => hbf_data_in(N-1),
--                FILTER_IN_1                 => hbf_data_in(N),

--                FRAME_O                     => hbf_frame_out(N),
--                VALID_O                     => hbf_valid_out(N),
--                FILTER_OUT                  => hbf_data_out(N)
--            );
--        end generate;
--    end generate;

    -- LPF block -----------------------------------------------------------------------------------------
--    process(CLK_307)
--    begin
--        if (rising_edge(CLK_307)) then
--            if (hbf_frame_out(1) = '1') then cnt4 <= (others=>'0'); else cnt4 <= cnt4 + '1'; end if;

--            if (hbf_frame_out(1) = '1' or cnt4 = b"11") then lpf_frame_in <= '1'; else lpf_frame_in <= '0'; end if;

--            lpf_valid_in                    <=  hbf_valid_out(1);
--            lpf_data_in                     <=  hbf_data_out(1);
--        end if;
--    end process;

--    -- Lowpassfilter (tap num = 54)    
--    u_dduc_lpf : dduc_lpf generic map("DDC",DDC_WIDTH_O_PFIR,15)
--        Port map (
--            i_rst_307                       =>  res_r,                      --: in std_logic;
--            i_clk_307                       =>  CLK_307,                    --: in std_logic;
            
--            -- 76.8MHz, 4 channel
--            i_upsample_rearrange_frame      =>  lpf_frame_in,               --: in std_logic;
--            i_upsample_rearrange_valid      =>  lpf_valid_in,               --: in std_logic;
--            i_upsample_rearrange_data       =>  lpf_data_in,                --: in std_logic_vector(DATA_WIDTH-1 downto 0);

--            -- 76.8MHz, 4 channel
--            o_lpf_frame                     =>  lpf_frame,                  --: out std_logic;
--            o_lpf_valid                     =>  lpf_valid,                  --: out std_logic;
--            o_lpf_data                      =>  lpf_data                    --: out std_logic_vector(DATA_WIDTH-1 downto 0)
--        );
        
        u_dduc_lpf_no_hbf_i : dduc_lpf generic map("DDC",DDC_WIDTH_O_PFIR,15)
        Port map (
            i_rst_307                       =>  res_r,                      --: in std_logic;
            i_clk_307                       =>  CLK_307,                    --: in std_logic;
            
            -- 76.8MHz, 4 channel
            i_upsample_rearrange_frame      =>  lpf_frame_in1,               --: in std_logic;
            i_upsample_rearrange_valid      =>  lpf_valid_in1,               --: in std_logic;
            i_upsample_rearrange_data       =>  lpf_data_in1(0),                --: in std_logic_vector(DATA_WIDTH-1 downto 0);

            -- 76.8MHz, 4 channel
            o_lpf_frame                     =>  lpf_frame_I,                  --: out std_logic;
            o_lpf_valid                     =>  lpf_valid_I,                  --: out std_logic;
            o_lpf_data                      =>  lpf_data_I                    --: out std_logic_vector(DATA_WIDTH-1 downto 0)
        );
        
        u_dduc_lpf_no_hbf_q : dduc_lpf generic map("DDC",DDC_WIDTH_O_PFIR,15)
        Port map (
            i_rst_307                       =>  res_r,                      --: in std_logic;
            i_clk_307                       =>  CLK_307,                    --: in std_logic;
            
            -- 76.8MHz, 4 channel
            i_upsample_rearrange_frame      =>  lpf_frame_in1,               --: in std_logic;
            i_upsample_rearrange_valid      =>  lpf_valid_in1,               --: in std_logic;
            i_upsample_rearrange_data       =>  lpf_data_in1(1),                --: in std_logic_vector(DATA_WIDTH-1 downto 0);

            -- 76.8MHz, 4 channel
            o_lpf_frame                     =>  lpf_frame_Q,                  --: out std_logic;
            o_lpf_valid                     =>  lpf_valid_Q,                  --: out std_logic;
            o_lpf_data                      =>  lpf_data_Q                    --: out std_logic_vector(DATA_WIDTH-1 downto 0)
        );

--    process(res_r, CLK_307)
--    begin
--        if (res_r = '1') then
--            cnt5                            <=  (others=>'0');
--        elsif (rising_edge(CLK_307)) then
--            if (lpf_frame = '1' and cnt5(2) = '1') then
--                cnt5                        <= (others=>'0');
--            elsif (lpf_frame = '1') then
--                cnt5                        <= cnt5 + '1';
--            else
--                cnt5                        <= cnt5;
--            end if;
--        end if;
--    end process;
    
    process(res_r, CLK_307)
    begin
        if (res_r = '1') then
            cnt5_2                          <=  (others=>'0');
        elsif (rising_edge(CLK_307)) then
            if (lpf_frame_I = '1' and cnt5_2(2) = '1') then
                cnt5_2                        <= (others=>'0');
            elsif (lpf_frame_I = '1') then
                cnt5_2                        <= cnt5_2 + '1';
            else
                cnt5_2                        <= cnt5_2;
            end if;
        end if;
    end process;

    -- downsample /5 -------------------------------------------------------------------------------------
--    process(CLK_307)
--    begin
--        if (rising_edge(CLK_307)) then
--            lpf_frame_1d                    <=  lpf_frame;
--            lpf_valid_1d                    <=  lpf_valid;
--            lpf_data_1d                     <=  lpf_data;

--            if (cnt5(2) = '1') then
--                downsample_frame            <=  lpf_frame_1d;
--                downsample_valid            <=  lpf_valid_1d;
--                downsample_data             <=  lpf_data_1d;
--            else
--                downsample_frame            <=  '0';
--                downsample_valid            <=  '0';
--                downsample_data             <=  (others=>'0');
--            end if;
--        end if;
--    end process;
    
    process(CLK_307)
    begin
        if (rising_edge(CLK_307)) then
            lpf_frame_1d_I                    <=  lpf_frame_I;
            lpf_valid_1d_I                    <=  lpf_valid_I;
            lpf_data_1d_I                     <=  lpf_data_I;
            lpf_data_1d_Q                     <=  lpf_data_Q;
            
            if (cnt5_2(2) = '1') then
                downsample_frame_I            <=  lpf_frame_1d_I;
                downsample_valid_I            <=  lpf_valid_1d_I;
                downsample_data_I             <=  lpf_data_1d_I;
                downsample_data_Q             <=  lpf_data_1d_Q;
            else
                downsample_frame_I            <=  '0';
                downsample_valid_I            <=  '0';
                downsample_data_I             <=  (others=>'0');
                downsample_data_Q             <=  (others=>'0');
            end if;
        end if;
    end process;
    
    --downsample_data_Q             <=  downsample_data_I+1;

    -- CDC block -----------------------------------------------------------------------------------------
--    u_cdc_sr_15_36_307m_245m : cdc_sr_15_36_307m_245m generic map (DDC_WIDTH_O_PFIR)
--        Port map ( 
--            i_rst_307                       =>  res_r,              --: in std_logic;
--            i_clk_307                       =>  CLK_307,            --: in std_logic;
--            i_clk_245                       =>  CLK,                --: in std_logic;
    
--            -- 15.36MHz, 4 channel
--            i_cdc_15_36_frame_307           =>  downsample_frame,   --: in std_logic;
--            i_cdc_15_36_valid_307           =>  downsample_valid,   --: in std_logic;
--            i_cdc_15_36_data_307            =>  downsample_data,    --: in std_logic_vector(DATA_WIDTH-1 downto 0);
    
--            -- 15.36MHz, 4 channel
--            o_cdc_15_36_frame_245           =>  frame_15_36,        --: out std_logic;
--            o_cdc_15_36_valid_245           =>  valid_15_36,        --: out std_logic;
--            o_cdc_15_36_data_245            =>  data_15_36          --: out std_logic_vector(DATA_WIDTH-1 downto 0)
--        );
        
        u_cdc_sr_15_36_307m_245m_i : cdc_sr_15_36_307m_245m generic map (DDC_WIDTH_O_PFIR)
        Port map ( 
            i_rst_307                       =>  res_r,              --: in std_logic;
            i_clk_307                       =>  CLK_307,            --: in std_logic;
            i_clk_245                       =>  CLK,                --: in std_logic;
    
            -- 15.36MHz, 4 channel
            i_cdc_15_36_frame_307           =>  downsample_frame_I,   --: in std_logic;
            i_cdc_15_36_valid_307           =>  downsample_valid_I,   --: in std_logic;
            i_cdc_15_36_data_307            =>  downsample_data_I,    --: in std_logic_vector(DATA_WIDTH-1 downto 0);
    
            -- 15.36MHz, 4 channel
            o_cdc_15_36_frame_245           =>  frame_15_36_I,        --: out std_logic;
            o_cdc_15_36_valid_245           =>  valid_15_36_I,        --: out std_logic;
            o_cdc_15_36_data_245            =>  data_15_36_I          --: out std_logic_vector(DATA_WIDTH-1 downto 0)
        );
        
        u_cdc_sr_15_36_307m_245m_q : cdc_sr_15_36_307m_245m generic map (DDC_WIDTH_O_PFIR)
        Port map ( 
            i_rst_307                       =>  res_r,              --: in std_logic;
            i_clk_307                       =>  CLK_307,            --: in std_logic;
            i_clk_245                       =>  CLK,                --: in std_logic;
    
            -- 15.36MHz, 4 channel
            i_cdc_15_36_frame_307           =>  downsample_frame_I,   --: in std_logic;
            i_cdc_15_36_valid_307           =>  downsample_valid_I,   --: in std_logic;
            i_cdc_15_36_data_307            =>  downsample_data_Q,    --: in std_logic_vector(DATA_WIDTH-1 downto 0);
    
            -- 15.36MHz, 4 channel
            o_cdc_15_36_frame_245           =>  frame_15_36_Q,        --: out std_logic;
            o_cdc_15_36_valid_245           =>  valid_15_36_Q,        --: out std_logic;
            o_cdc_15_36_data_245            =>  data_15_36_Q          --: out std_logic_vector(DATA_WIDTH-1 downto 0)
        );
    
    -- @ 245.76MHz ----------------------------------------------------------------------------------------

    process(res_r_245,CLK)
    begin
        if (res_r_245 = '1') then
            ctn4_2                          <=  (others=>'0');
        elsif (rising_edge(CLK)) then
            if (frame_15_36 = '1') then
                ctn4_2                      <= ctn4_2 + '1';
            else
                ctn4_2                      <= ctn4_2;
            end if;

            if (ctn4_2 = 0) then frame_15_36_d <= frame_15_36; else frame_15_36_d <= '0'; end if;

            valid_15_36_d                   <= valid_15_36;
            data_15_36_d                    <= data_15_36; 
        end if;
    end process;
    
    process(res_r_245,CLK)
    begin
        if (res_r_245 = '1') then
            ctn4_3                          <=  (others=>'0');
        elsif (rising_edge(CLK)) then
            if (frame_15_36_I = '1') then
                ctn4_3                      <= ctn4_3 + '1';
            else
                ctn4_3                      <= ctn4_3;
            end if;

            if (ctn4_3 = 0) then 
                frame_15_36_d_I <= frame_15_36_I; 
            else frame_15_36_d_I <= '0'; 
            end if;           
            
            valid_15_36_d_I                   <= valid_15_36_I;
            valid_15_36_d_Q                   <= valid_15_36_Q;
            valid_15_36_dd_Q                   <= valid_15_36_d_Q;
            
            data_15_36_d_I                    <= data_15_36_I; 
            data_15_36_d_Q                    <= data_15_36_Q; 
            data_15_36_dd_Q                   <= data_15_36_d_Q; 
            
        end if;
    end process;
    
    
    process(res_r_245,CLK)
    begin
        if (res_r_245 = '1') then
            data_15_36_d_IQ       <=  (others=>'0');
            valid_15_36_d_IQ      <=  '0';
            cnt_IQ                <=  (others=>'0');
        elsif (rising_edge(CLK)) then
            if (frame_15_36_I = '1') then
                cnt_IQ   <= "00";
            else
                cnt_IQ   <= cnt_IQ+1;
            end if;
            
            
            if (cnt_IQ = "11") then 
                valid_15_36_d_IQ <= valid_15_36_I;
                data_15_36_d_IQ  <= data_15_36_I;
            elsif (cnt_IQ = "01") then
                valid_15_36_d_IQ <= valid_15_36_dd_Q;
                data_15_36_d_IQ  <= data_15_36_dd_Q;
            else valid_15_36_d_IQ     <=  '0';
            end if;
            

        end if;
    end process;

    -- HBF1 block -----------------------------------------------------------------------------------------
    u_channel_swap_hbf_d_30_15 : channel_swap_hbf_d
        generic map(
            CHANNEL_NUMBERS                 => CHANNEL_NUMBERS              ,--: natural:= 4;
            HOVS                            => DDC_HOVS_HB(3)/2             ,--: natural:= 2;
            WIDTH_IN                        => DDC_WIDTH_I                   --: natural:= 16
        )
        port map(
            RST                             => res_r_245                    ,--: in  std_logic;
            CLK                             => CLK                          ,--: in  std_logic;

            FRAME_I                         => frame_15_36_d_I  ,--frame_15_36_d                ,--: in  std_logic;
            VALID_I                         => valid_15_36_d_IQ  ,--valid_15_36_d                ,--: in  std_logic;
            FILTER_IN                       => data_15_36_d_IQ  ,--data_15_36_d                 ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);

            FRAME_O                         => hbf_frame_in(3)              ,--: out std_logic;
            VALID_O                         => hbf_valid_in(3)              ,--: out std_logic;
            FILTER_OUT                      => hbf_data_in(3)                --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );

    HBF_D_30_15: fir_d
        generic map(
            VENDOR                          => VENDOR,
            HOVS                            => DDC_HOVS_HB(3),
            ORDER                           => DDC_HBF_ORDER(3),

            CHANNEL_NUMBERS                 => CHANNEL_NUMBERS,

            WIDTH_IN                        => DDC_WIDTH_O_MULT,
            WIDTH_OUT                       => DDC_WIDTH_O_HB,
            WIDTH_COEFF                     => DDC_WIDTH_COEFF_HB,
            WIDTH_RESULT                    => DDC_WIDTH_RESULT_HB,
            BINARY_POINT                    => DDC_BINARY_POINT_HB
        )
        port map(
            RST                             => res_r_245,
            CLK                             => CLK,

            FRAME_I                         => hbf_frame_in(3),
            VALID_I                         => hbf_valid_in(3),
            FILTER_IN_0                     => hbf_data_in(3),
            FILTER_IN_1                     => (others => '0'),

            FRAME_O                         => hbf_frame_out(3),
            VALID_O                         => hbf_valid_out(3),
            FILTER_OUT                      => hbf_data_out(3)
        );
        
        
    -- HBF2 block -----------------------------------------------------------------------------------------
    u_channel_swap_hbf_d_15_7 : channel_swap_hbf_d
        generic map(
            CHANNEL_NUMBERS                 => CHANNEL_NUMBERS              ,--: natural:= 4;
            HOVS                            => DDC_HOVS_HB(4)/2             ,--: natural:= 2;
            WIDTH_IN                        => DDC_WIDTH_I                   --: natural:= 16
        )
        port map(
            RST                             => res_r_245                    ,--: in  std_logic;
            CLK                             => CLK                          ,--: in  std_logic;

            FRAME_I                         => hbf_frame_out(3),--frame_15_36_d                ,--: in  std_logic;
            VALID_I                         => hbf_valid_out(3),--valid_15_36_d                ,--: in  std_logic;
            FILTER_IN                       => hbf_data_out(3) , --data_15_36_d                 ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);

            FRAME_O                         => hbf_frame_in(4)              ,--: out std_logic;
            VALID_O                         => hbf_valid_in(4)              ,--: out std_logic;
            FILTER_OUT                      => hbf_data_in(4)                --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );

    HBF_D_15_7: fir_d
        generic map(
            VENDOR                          => VENDOR,
            HOVS                            => DDC_HOVS_HB(4),
            ORDER                           => DDC_HBF_ORDER(4),

            CHANNEL_NUMBERS                 => CHANNEL_NUMBERS,

            WIDTH_IN                        => DDC_WIDTH_O_MULT,
            WIDTH_OUT                       => DDC_WIDTH_O_HB,
            WIDTH_COEFF                     => DDC_WIDTH_COEFF_HB,
            WIDTH_RESULT                    => DDC_WIDTH_RESULT_HB,
            BINARY_POINT                    => DDC_BINARY_POINT_HB
        )
        port map(
            RST                             => res_r_245,
            CLK                             => CLK,

            FRAME_I                         => hbf_frame_in(4),
            VALID_I                         => hbf_valid_in(4),
            FILTER_IN_0                     => hbf_data_in(4),
            FILTER_IN_1                     => (others => '0'),

            FRAME_O                         => hbf_frame_out(4),
            VALID_O                         => hbf_valid_out(4),
            FILTER_OUT                      => hbf_data_out(4)
        );
          

    -- PFIR block ----------------------------------------------------------------------------------------
    process(res_r_245,CLK)
    begin
        if (res_r_245='1') then
            pfir_frame                      <= '0';
            pfir_valid                      <= '0';
            pfir_data                       <= (others=>'0');
        elsif (CLK'event and CLK='1') then
            if (MODE = X"2") then
                pfir_frame                  <= hbf_frame_out(4);
                pfir_valid                  <= hbf_valid_out(4);
                pfir_data                   <= hbf_data_out(4);
            elsif (MODE = X"3") then
                pfir_frame                  <= hbf_frame_out(3);
                pfir_valid                  <= hbf_valid_out(3);
                pfir_data                   <= hbf_data_out(3); 
            elsif (MODE = X"4") or (MODE = X"5") then
                pfir_frame                  <= frame_15_36_d_I ;
                pfir_valid                  <= valid_15_36_d_IQ;
                pfir_data                   <= data_15_36_d_IQ ;
            else
                pfir_frame                  <= '0';
                pfir_valid                  <= '0';
                pfir_data                   <= (others=>'0');
            end if;
        end if;
    end process;

    -- PFIR    
    PFIR_GEN: fir_pfir
        generic map(
            VENDOR                          => VENDOR,
            DDUC_SEL                        => 1,
            CHANNEL_NUMBERS                 => CHANNEL_NUMBERS,

            WIDTH_IN                        => DDC_WIDTH_O_HB,
            WIDTH_OUT                       => DDC_WIDTH_O_PFIR,
            WIDTH_COEFF                     => DDC_WIDTH_COEFF_PFIR,

            WIDTH_RESULT                    => DDC_WIDTH_RESULT_PFIR,
            BINARY_POINT                    => DDC_BINARY_POINT_PFIR,

            HOVS                            => DDC_HOVS_PFIR,
            ORDER                           => DDC_ORDER_PFIR
        )
        port map(
            RST                             => res_r_245,
            CLK                             => CLK,

            MODE                            => MODE,

            frame_i                         => pfir_frame, --frame_15_36_d_I,
            valid_i                         => pfir_valid, --valid_15_36_d_IQ,
            filter_in                       => pfir_data,  --data_15_36_d_IQ,

            frame_o                         => i_ddc_frame_o,
            valid_o                         => i_ddc_valid_o,
            filter_out                      => i_ddc_out
        );


    DLY_HOVS_2 : if DDC_IN_HOVS = 2 generate
        dly_sample <= DLY_S_20M_HOVS2 when MODE(2) = '1' else
                      DLY_S_10M_HOVS2 when MODE(1) = '1' and MODE(0) = '1' else
                      DLY_S_5M_HOVS2;

        dly_clock  <= DLY_C_20M_HOVS2 when MODE(2) = '1' else
                      DLY_C_10M_HOVS2 when MODE(1) = '1' and MODE(0) = '1' else
                      DLY_C_5M_HOVS2;
    end generate;

    -- for 5/10/15/20M BW has same processing delay
    u_dduc_delay : dduc_delay
        generic map(
            DATA_WIDTH                  => DDC_WIDTH_O_PFIR             ,--: integer:= 16;
            CHANNEL_NUMBER              => CHANNEL_NUMBERS              ,--: integer:= 4;
            MAX_DELAY_SAMPLE            => MAX_DELAY_SAMPLE             ,--: integer:= 256;
            MAX_DELAY_CLOCK             => MAX_DELAY_CLOCK               --: integer:= 16
        )
        port map(
            RST                         => RST                          ,--: in  std_logic;
            CLK                         => CLK                          ,--: in  std_logic;

            DLY_SAMPLE                  => dly_sample                   ,--: in  std_logic_vector(log2(MAX_DELAY_SAMPLE)-1 downto 0);
            DLY_CLOCK                   => dly_clock                    ,--: in  std_logic_vector(log2(MAX_DELAY_CLOCK)-1 downto 0);

            FRAME_I                     => i_ddc_frame_o                ,--: in  std_logic;
            VALID_I                     => i_ddc_valid_o                ,--: in  std_logic;
            DATA_IN                     => i_ddc_out                    ,--: in  std_logic_vector(DATA_WIDTH-1 downto 0);

            FRAME_O                     => dly_frame                    ,--: out std_logic;
            VALID_O                     => dly_valid                    ,--: out std_logic;
            DATA_OUT                    => dly_data                      --: out std_logic_vector(DATA_WIDTH-1 downto 0)
        );

    u_ddc_if : ddc_if
        generic map(
            CHANNEL_NUMBERS             => CHANNEL_NUMBERS              ,--: natural:= 4;
            WIDTH_IN                    => DDC_WIDTH_O_PFIR              --: natural:= 16
        )
        port map(
            RST                         => res_r_245                    ,--: in  std_logic;
            CLK                         => CLK                          ,--: in  std_logic;

            FRAME_I                     => dly_frame                    ,--: in  std_logic;
            VALID_I                     => dly_valid                    ,--: in  std_logic;
            FILTER_IN                   => dly_data                     ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);

            DDC_SYNC                    => i_ddc_if_sync                ,--: out std_logic;
            DDC_OUT                     => i_ddc_if_out                  --: out std_logic_vector(WIDTH_IN-1 downto 0)
        );

    -- Valid/CH data should be aligned with ddc_out
    process(CLK, res_r_245)
    begin
        if res_r_245 = '1' then
            DDC_SYNC <= '0';
        elsif rising_edge(CLK) then
            DDC_SYNC <= i_ddc_if_sync;
        end if;
    end process;

    -- Clear data
    process(CLK, clr_r_245)
    begin
        if (clr_r_245 = '1') then
            DDC_OUT <= (others => '0');
        elsif rising_edge(CLK) then
            DDC_OUT <= i_ddc_if_out;
        end if;
    end process;

end rtl;
