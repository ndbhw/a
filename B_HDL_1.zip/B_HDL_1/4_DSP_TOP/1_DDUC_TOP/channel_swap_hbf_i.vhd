------------------------------------------------------------------
-- channel swap, DUC interpolation HBF output formatting
------------------------------------------------------------------
-- 2014.11.25, wj311.kim
------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity channel_swap_hbf_i is
generic(
    CHANNEL_NUMBERS             : natural:= 4;
    HOVS                        : natural:= 1;
    WIDTH_IN                    : natural:= 16
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);        -- 2 continuous data per each channel, x1 rate

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)         -- 1 data per each channel, x2 rate
);
end channel_swap_hbf_i;

architecture Behavioral of channel_swap_hbf_i is

component dduc_dist_ram
generic(
    BUFF_DEPTH                  : natural:= 16;
    WIDTH_IN                    : natural:= 16
);
port(
    CLK                         : in  std_logic;
    WE                          : in  std_logic;
    WADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    RADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_IN                     : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_OUT                    : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

constant BUFFER_DEPTH           : integer := CHANNEL_NUMBERS*2*2;-- *2 for interpolated sample, *2 for buffering
constant CLK_CNT_WIDTH          : integer := log2(2*CHANNEL_NUMBERS*HOVS);
constant PROC_DELAY             : integer := 2;-- processing delay = 2 sample period + 2 clock

signal valid_in_d               : std_logic;
signal filter_in_r              : std_logic_vector(WIDTH_IN-1 downto 0);
signal clk_cnt_out              : std_logic_vector(CLK_CNT_WIDTH-1 downto 0);
signal waddr                    : std_logic_vector(log2(BUFFER_DEPTH)-1 downto 0);
signal waddr_msb                : std_logic;
signal waddr_half               : std_logic_vector(log2(BUFFER_DEPTH)-2 downto 0);
signal raddr                    : std_logic_vector(log2(BUFFER_DEPTH)-1 downto 0);
signal valid_out_r              : std_logic;
signal valid_out_d              : std_logic_vector(PROC_DELAY-1 downto 0);
signal frame_out_r              : std_logic;
signal frame_out_d              : std_logic_vector(PROC_DELAY-1 downto 0);

begin

    -- input registering
    process(RST, CLK)
    begin
        if RST = '1' then
            valid_in_d  <= '0';
            filter_in_r <= (others => '0');
        elsif rising_edge(CLK) then
            valid_in_d  <= VALID_I;
            filter_in_r <= FILTER_IN;
        end if;
    end process;

    -- sample index for latch
    waddr <= waddr_msb & waddr_half;
    process(RST, CLK)
    begin
        if RST = '1' then
            waddr_msb  <= '0';
            waddr_half <= (others => '0');
        elsif rising_edge(CLK) then
            if FRAME_I = '1' then-- When channel start
                waddr_msb  <= not waddr_msb;
                waddr_half <= (others => '0');
            elsif VALID_I = '1' then
                waddr_half <= waddr_half + 1;
            end if;
        end if;
    end process;

    -- clock counter for output data formatting
    process(RST, CLK)
    begin
        if RST = '1' then
            clk_cnt_out <= (others => '0');
        elsif rising_edge(CLK) then
            if FRAME_I = '1' then-- When channel start
                clk_cnt_out <= (others => '0');
            else
                clk_cnt_out <= clk_cnt_out + 1;
            end if;
        end if;
    end process;

    VALID_O <= valid_out_d(valid_out_d'high);
    process(RST, CLK)
    begin
        if RST = '1' then
            valid_out_r <= '0';
            valid_out_d <= (others => '0');
        elsif rising_edge(CLK) then
            if HOVS = 1 then
                valid_out_r <= '1';
            elsif clk_cnt_out(log2(HOVS)-1 downto 0) = 0 then
                valid_out_r <= '1';
            else
                valid_out_r <= '0';
            end if;
            valid_out_d <= valid_out_d(valid_out_d'length-2 downto 0) & valid_out_r;
        end if;
    end process;

    FRAME_O <= frame_out_d(frame_out_d'high);
    process(RST, CLK)
    begin
        if RST = '1' then
            frame_out_r <= '0';
            frame_out_d <= (others => '0');
        elsif rising_edge(CLK) then
            if clk_cnt_out(CLK_CNT_WIDTH-2 downto 0) = 0 then
                frame_out_r <= '1';
            else
                frame_out_r <= '0';
            end if;
            frame_out_d <= frame_out_d(frame_out_d'length-2 downto 0) & frame_out_r;
        end if;
    end process;

    -- read address
    process(RST, CLK)
    begin
        if RST = '1' then
            raddr <= (others => '0');
        elsif rising_edge(CLK) then-- raddr = 0,2,4,6,1,3,5,7...
            raddr <= (not waddr_msb) & clk_cnt_out(CLK_CNT_WIDTH-2 downto log2(HOVS)) & clk_cnt_out(CLK_CNT_WIDTH-1);
        end if;
    end process;

u_dduc_dist_ram : dduc_dist_ram
generic map(
    BUFF_DEPTH                  => BUFFER_DEPTH                 ,--: natural:= 16;-- SRL16E
    WIDTH_IN                    => WIDTH_IN                      --: natural:= 16 -- Input data width
)
port map(
    CLK                         => CLK                          ,--: in  std_logic;
    WE                          => valid_in_d                   ,--: in  std_logic;
    WADDR                       => waddr                        ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    RADDR                       => raddr                        ,--: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_IN                     => filter_in_r                  ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_OUT                    => FILTER_OUT                    --: out std_logic_vector(WIDTH_IN-1 downto 0)
);

end Behavioral;
