------------------------------------------------------------------
-- channel swap
------------------------------------------------------------------
-- 2013.11.01, vyacheslav : 1st release, system verilog
-- 2014.01.29, wj311.kim  : convert system_verilog to vhdl
------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

Library UNISIM;
use UNISIM.vcomponents.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity dduc_bram is
generic(
    BUFF_DEPTH                  : integer := 8192;
    WIDTH_IN                    : integer := 1
);
port(
    CLK                         : in  std_logic;
    WE                          : in  std_logic;
    WADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    RADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_IN                     : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_OUT                    : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end dduc_bram;

architecture Behavioral of dduc_bram is

constant RAM_DEPTH              : integer := 2**log2(BUFF_DEPTH);
type ram_type                   is array (RAM_DEPTH-1 downto 0) of std_logic_vector(WIDTH_IN-1 downto 0);
signal RAM                      : ram_type := (others => (others => '0'));
signal ram_out                  : std_logic_vector(WIDTH_IN-1 downto 0);

attribute RAM_STYLE             : string;
--attribute RAM_STYLE of RAM      : signal is "DISTRIBUTED";
attribute RAM_STYLE of RAM      : signal is "BLOCK";
--attribute RAM_STYLE of RAM      : signal is "M20K";

begin

    process (CLK)
    begin
    if rising_edge(CLK) then
        if WE = '1' then
            RAM(conv_integer(WADDR)) <= DATA_IN;
        end if;
    end if;
    end process;

    process (CLK)
    begin
    if rising_edge(CLK) then
        ram_out <= RAM(conv_integer(RADDR));
    end if;
    end process;

    process (CLK)
    begin
    if rising_edge(CLK) then
        DATA_OUT <= ram_out;-- for high performance, in BRAM primitive (no fabric)
    end if;
    end process;

end Behavioral;
