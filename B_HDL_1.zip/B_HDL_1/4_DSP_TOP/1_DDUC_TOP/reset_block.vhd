--*********************************************************************************************
--Rseet for duc/ddc
--WIDTH_IN          - input data width
--CHANNEL_WIDTH     - width of channel input
--CHANNEL_NUMBERS   - total enabled channels
--*********************************************************************************************
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity reset_block is
generic(
    CLEAR_SAMPLES               : integer:= 16;
    WIDTH_IN                    : integer:= 16
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;
    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1  downto 0);
    --SPECAIL for CIC
    CLR_O                       : out std_logic;
    --SPECAIL for FIR
    RES_O                       : out std_logic
);
end reset_block;

architecture rtl of reset_block is

signal clr_r            : std_logic;
signal res_r            : std_logic;
signal res_r_sh         : std_logic_vector(2 downto 0);

signal  cycle_counter:std_logic_vector(log2(CLEAR_SAMPLES) downto 0);

attribute MAX_FANOUT    : integer;
attribute MAX_FANOUT of res_r_sh : signal is 64;
attribute MAX_FANOUT of RES_O    : signal is 64;
attribute MAX_FANOUT of VALID_O  : signal is 32;

begin

    process(CLK,RST)
    begin
        if RST='1' then
            res_r_sh <= (others=>'0');
            CLR_O <= '1';
            RES_O <= '1';
        elsif CLK'event and CLK='1' then
            res_r_sh <= res_r_sh(1 downto 0) & res_r;
            CLR_O <= clr_r;
            RES_O <= res_r_sh(2);
        end if;
    end process;

    process(CLK,RST)
    begin
        if RST='1' then
            FRAME_O<='0';
            VALID_O<='0';
        elsif CLK'event and CLK='1' then
            FRAME_O<=FRAME_I;
            VALID_O<=VALID_I;
        end if;
    end process;


    process(CLK,RST)
    begin
        if RST='1' then
            FILTER_OUT      <= (others=>'0');
            cycle_counter   <= (others=>'0');
            clr_r           <= '1';
            res_r           <= '1';
        elsif CLK'event and CLK='1' then
            if cycle_counter > 4 then
                res_r       <= '0';
            end if;
            if cycle_counter(cycle_counter'high) = '1' then--bypassing
                clr_r       <= '0';
                FILTER_OUT  <= FILTER_IN;
            else
                clr_r       <= '1';
                FILTER_OUT  <= (others=>'0');
                if FRAME_I = '1' then
                    cycle_counter<=cycle_counter + '1';
                end if;
            end if;
        end if;
    end process;

end rtl;
