------------------------------------------------------------------
-- channel mux
------------------------------------------------------------------
-- 2013.11.01, vyacheslav : 1st release, system verilog
-- 2014.01.29, wj311.kim  : convert system_verilog to vhdl
-- 2014.04.14, wj311.kim  : modifiy MUX for KDDI Dualband UL(no CIC)
------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity channel_mux is
generic(
    HOVS                        : natural:= 4;
    WIDTH_IN                    : natural:= 16
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(2*WIDTH_IN-1 downto 0);

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end channel_mux;

architecture Behavioral of channel_mux is

component dduc_delay_chain is
generic(
    BUFF_DEPTH                  : natural:= 16;-- SRL16E
    DIRECTION                   : natural:= 1; -- 1:forward, 0:reverse
    WIDTH_IN                    : natural:= 16 -- Input data width
);
port(
    CLK                         : in  std_logic;
    DATA_SEL                    : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);
    FILTER_OUT                  : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

constant DELAY_DEPTH        : integer := HOVS/2;

type  data_width_array      is array(integer range <>) of std_logic_vector(WIDTH_IN-1 downto 0);

-- buffer for each I/Q data, store 4 sample for 2 sample mux
signal i_filter_in          : data_width_array(1 downto 0);
signal valid_d              : std_logic_vector(DELAY_DEPTH-1 downto 0);
signal delay_data           : std_logic_vector(WIDTH_IN-1 downto 0);

begin

    -- Input Data Indexing
    FILTER_IN_GEN : for i in 0 to 1 generate
        i_filter_in(i) <= FILTER_IN(WIDTH_IN*(i+1)-1 downto WIDTH_IN*i);
    end generate;

    -- Delay 1 clock
    DELAY_GEN_1 : if DELAY_DEPTH = 1 generate
        process(CLK, RST)
        begin
            if RST = '1' then
                valid_d(DELAY_DEPTH-1) <= '0';
            elsif rising_edge(CLK) then
                valid_d(DELAY_DEPTH-1) <= VALID_I;
            end if;
        end process;
    end generate DELAY_GEN_1;

    -- Delay N clock
    DELAY_GEN_N : if DELAY_DEPTH > 1 generate
        process(CLK, RST)
        begin
            if RST = '1' then
                valid_d <= (others => '0');
            elsif rising_edge(CLK) then
                valid_d <= valid_d(DELAY_DEPTH-2 downto 0) & VALID_I;
            end if;
        end process;
    end generate DELAY_GEN_N;

    -- Frame output
    process(CLK, RST)
    begin
        if RST = '1' then
            FRAME_O <= '0';
        elsif rising_edge(CLK) then
            FRAME_O <= FRAME_I;
        end if;
    end process;

    -- Data output
    process(CLK, RST)
    begin
        if RST = '1' then
            VALID_O <= '0';
        elsif rising_edge(CLK) then
            if HOVS = 2 then
                VALID_O <= '1';
            else
                VALID_O <= VALID_I or valid_d(DELAY_DEPTH-1);
            end if;
        end if;
    end process;

    -- Data output
    process(CLK, RST)
    begin
        if RST = '1' then
            FILTER_OUT <= (others => '0');
        elsif rising_edge(CLK) then
            if VALID_I = '1' then
                FILTER_OUT <= i_filter_in(0);
            elsif valid_d(DELAY_DEPTH-1) = '1' then
                FILTER_OUT <= delay_data;
            end if;
        end if;
    end process;

u_dduc_delay_chain : dduc_delay_chain
generic map(
    BUFF_DEPTH                  => DELAY_DEPTH              ,--: natural:= 16;-- SRL16E
    DIRECTION                   => 0                        ,--: natural:= 1; -- 1:forward, 0:reverse
    WIDTH_IN                    => WIDTH_IN                  --: natural:= 16 -- Input data width
)
port map(
    CLK                         => CLK                      ,--: in  std_logic;
    DATA_SEL                    => std_logic_vector(to_unsigned(DELAY_DEPTH-1, log2(DELAY_DEPTH))),
    VALID_I                     => '1'                      ,--: in  std_logic;
    FILTER_IN                   => i_filter_in(1)           ,--: in  std_logic_vector(WIDTH_IN-1 downto 0);
    FILTER_OUT                  => delay_data                --: out std_logic_vector(WIDTH_IN-1 downto 0)
);

end Behavioral;
