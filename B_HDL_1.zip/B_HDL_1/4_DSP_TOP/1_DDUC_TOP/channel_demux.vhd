------------------------------------------------------------------
-- channel demux for interpolated data demuxing
------------------------------------------------------------------
-- 2014.11.26, wj311.kim  : DUC
------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

entity channel_demux is
generic(
    COPY_MODE_EN                : natural:= 1;
    HOVS                        : natural:= 2;
    WIDTH_IN                    : natural:= 16
);
port(
    RST                         : in  std_logic;
    CLK                         : in  std_logic;

    FRAME_I                     : in  std_logic;
    VALID_I                     : in  std_logic;
    FILTER_IN                   : in  std_logic_vector(WIDTH_IN-1 downto 0);        -- 2 continuous data per each channel, x1 rate

    FRAME_O                     : out std_logic;
    VALID_O                     : out std_logic;
    FILTER_OUT_0                : out std_logic_vector(WIDTH_IN-1 downto 0);        -- 1 data per each channel, x2 rate
    FILTER_OUT_1                : out std_logic_vector(WIDTH_IN-1 downto 0)         -- 1 data per each channel, x2 rate
);
end channel_demux;

architecture Behavioral of channel_demux is

constant PROC_DELAY             : integer := 1+HOVS;-- 1(input latch)+HOVS(wait even sample)

signal frame_i_d                : std_logic_vector(PROC_DELAY-1 downto 0);
signal valid_i_d                : std_logic_vector(PROC_DELAY-1 downto 0);
signal valid_odd                : std_logic;
signal filter_in_odd            : std_logic_vector(WIDTH_IN-1 downto 0);

begin

    FRAME_O         <= frame_i_d(frame_i_d'high);
    VALID_O         <= valid_i_d(valid_i_d'high);
    process(RST, CLK)
    begin
        if RST = '1' then
            frame_i_d <= (others => '0');
            valid_i_d <= (others => '0');
        elsif rising_edge(CLK) then
            frame_i_d <= frame_i_d(frame_i_d'length-2 downto 0) & FRAME_I;
            if COPY_MODE_EN = 1 then
                valid_i_d <= valid_i_d(valid_i_d'length-2 downto 0) & VALID_I;-- output valid rate = input valid rate
            else
                valid_i_d <= valid_i_d(valid_i_d'length-2 downto 0) & (VALID_I and valid_odd);-- output valid rate = input valid rate/2
            end if;
        end if;
    end process;

    -- valid_odd for odd data latch
    process(RST, CLK)
    begin
        if RST = '1' then
            valid_odd <= '0';
        elsif rising_edge(CLK) then
            if FRAME_I = '1' then
                valid_odd <= '0';
            elsif VALID_I = '1' then
                valid_odd <= not valid_odd;
            end if;
        end if;
    end process;

    -- odd data latch
    process(RST, CLK)
    begin
        if RST = '1' then
            filter_in_odd <= (others => '0');
        elsif rising_edge(CLK) then
            if VALID_I = '1' and valid_odd = '1' then
                filter_in_odd <= FILTER_IN;
            end if;
        end if;
    end process;

    -- output data
    process(RST, CLK)
    begin
        if RST = '1' then
            FILTER_OUT_0 <= (others => '0');
            FILTER_OUT_1 <= (others => '0');
        elsif rising_edge(CLK) then
            if VALID_I = '1' and valid_odd = '0' then
                FILTER_OUT_0 <= filter_in_odd;
                FILTER_OUT_1 <= FILTER_IN;
            end if;
        end if;
    end process;


end Behavioral;
