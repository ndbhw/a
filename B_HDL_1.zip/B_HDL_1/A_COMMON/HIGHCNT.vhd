------------------------------------------------------------
-- Date      : 2005.08.31
-- Designer  : wisetree choi
-- Code Name : HIGHCNT.vhd
-- Function  : Pulse Counter.
--             CLR : Clear Pulse, longger than a CLK Period.
-- Revision History
-- 1. Initial Coding 2005.08.31
-------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity HIGHCNT is
generic(
    CNT_WIDTH       : natural                                        -- COUNTER Bit Width
);
port(
    RST            : in std_logic;                                   -- Active High Reset.
    CLK            : in std_logic;                                   -- Clock for Count
    EVENT          : in std_logic;                                   -- Event Pulse one or more clock
    CLR            : in std_logic;                                   -- Active High Clear.
    CNT            : out std_logic_vector(CNT_WIDTH - 1 downto 0)    -- Latch Output for EVENT.
);
end HIGHCNT;

architecture ARC_HIGHCNT of HIGHCNT is
signal CNT_S : std_logic_vector(CNT_WIDTH - 1 downto 0);

begin

-- EVENT Count/Clear
CNT_PROC0: process(RST, CLR, CLK)
begin
if (RST = '1') then
    CNT_S <= (others => '0');
elsif CLK = '1' and CLK'event then
    if (CLR = '1') then
        CNT_S <= (others => '0');
    elsif EVENT = '1' then
        CNT_S <= CNT_S + '1';
    end if;
end if;
end process;

-- Counter Output
CNT <= CNT_S;
end ARC_HIGHCNT;
