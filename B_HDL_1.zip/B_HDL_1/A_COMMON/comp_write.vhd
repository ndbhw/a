--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2013, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Writable Register (Component, 32-bit)                         --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2013.09.05 (2014.03.28)                                       --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
--   v1.0 - initial release                                                   --
--   v1.1 - decrease warning messages when synthesize                         --
--   v1.2 - logic optimized                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity COMP_WRITE is
    generic (
        BIT_ENABLE                  : std_logic_vector(31 downto 0) := (others => '1');
        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0');
        REG_DATA                    : std_logic_vector(31 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        EN                          : in  std_logic;
        ADDR                        : in  std_logic_vector(7 downto 0);
        DATA_IN                     : in  std_logic_vector(31 downto 0);
        DATA_OUT                    : out std_logic_vector(31 downto 0)
    );
end COMP_WRITE;

architecture BEHAVE of COMP_WRITE is

begin

    process (RESET, CLK)
    begin
        if (RESET = '1') then
            DATA_OUT <= REG_DATA;
        elsif (CLK'event and CLK = '1') then
            for i in 31 downto 0 loop
            if ((EN = '1') and (ADDR = REG_ADDR)) then
                DATA_OUT(i) <= DATA_IN(i) and BIT_ENABLE(i);
            end if;
            end loop;
        end if;
    end process;

end BEHAVE;
