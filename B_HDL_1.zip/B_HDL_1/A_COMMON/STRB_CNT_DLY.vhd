-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name : STRB_CNT_DLY 
-- Project    : CP10_42A, 3.5G KDDI Low power
-- Structure  : 

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

entity STRB_CNT_DLY is
port(
    RST        : in  std_logic;
    CLK        : in  std_logic;
    
    DLYCNT_IN  : in  std_logic_vector(11 downto 0);
    SIGNAL_IN  : in  std_logic;
    
    SIGNAL_OUT : out std_logic
    );
end STRB_CNT_DLY;

architecture arc_STRB_CNT_DLY of STRB_CNT_DLY is

signal dlycnt_minus_1 : std_logic_vector(11 downto 0);
signal dlycnt_minus_7 : std_logic_vector(11 downto 0);

signal sig_sh         : std_logic_vector(2 downto 0);
signal sig_rpls       : std_logic;
signal sig_fpls       : std_logic;

signal sig_rpls_d     : std_logic;
signal sig_fpls_d     : std_logic;
signal dly_sig        : std_logic;

signal rpls_dly_cnt   : std_logic_vector(11 downto 0);
signal fpls_dly_cnt   : std_logic_vector(11 downto 0);

signal state          : std_logic;

begin

    P_Delay_Count_Clocking : process(RST, CLK) begin
        if (RST = '1') then
            dlycnt_minus_1 <= (others => '0'); 
            dlycnt_minus_7 <= (others => '0'); 
        elsif (CLK'event) and (CLK = '1') then
            dlycnt_minus_1 <= DLYCNT_IN - 1; 
            dlycnt_minus_7 <= DLYCNT_IN - 7; 
        end if;
    end process;

    P_Edge_Detect : process(RST, CLK) begin
        if (RST = '1') then    
            sig_sh   <= (others => '0');
            sig_rpls <= '0';
            sig_fpls <= '0';
        elsif (CLK'event) and (CLK = '1') then
            sig_sh   <= sig_sh(1 downto 0) & SIGNAL_IN;
            sig_rpls <= sig_sh(1) and (not sig_sh(2));
            sig_fpls <= (not sig_sh(1)) and sig_sh(2);
        end if;
    end process;

    P_Pulse_count_delay : process(RST, CLK) begin
        if (RST = '1') then
            rpls_dly_cnt <= (others => '1');  
            fpls_dly_cnt <= (others => '1');  
        elsif (CLK'event) and (CLK = '1') then
            if (sig_rpls = '1') then               -- Rising edge pulse
                rpls_dly_cnt <= (others => '0');   -- count init
            elsif (rpls_dly_cnt = dlycnt_minus_1) then
                rpls_dly_cnt <= rpls_dly_cnt;
            else
                rpls_dly_cnt <= rpls_dly_cnt + '1';
            end if;
        
            if (sig_fpls = '1') then               -- Falling edge pulse
                fpls_dly_cnt <= (others => '0');   -- count init
            elsif (fpls_dly_cnt = dlycnt_minus_1) then
                fpls_dly_cnt <= fpls_dly_cnt;
            else
                fpls_dly_cnt <= fpls_dly_cnt + '1';
            end if;
        end if;
    end process;

    P_Delayed_Pulse : process(RST, CLK) begin
        if (RST = '1') then
            sig_rpls_d <= '0';
            sig_fpls_d <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (rpls_dly_cnt = dlycnt_minus_7) then
                sig_rpls_d <= '1';
            else
                sig_rpls_d <= '0';
            end if;

            if (fpls_dly_cnt = dlycnt_minus_7) then
                sig_fpls_d <= '1';
            else
                sig_fpls_d <= '0';
            end if;
        end if;
    end process;

    P_State_Define : process(RST, CLK) begin
        if (RST = '1') then
            state   <= '0';
            dly_sig <= '0'; 
        elsif (CLK'event) and (CLK = '1') then
            case (state) is
                when '0' =>
                     state <= '1';
                     if (sig_sh(2) = '0') then 
                         dly_sig <= '0';
                     else                   
                         dly_sig <= '1';
                     end if;
                when '1' =>
                     state <= state;
                     if ((dly_sig = '0') and (sig_rpls_d = '1')) then
                          dly_sig <= '1';
                     elsif ((dly_sig = '1') and (sig_fpls_d = '1')) then
                          dly_sig <= '0';
                     else
                          dly_sig <= dly_sig;
                     end if;
                when others =>
                     state   <= state;
                     dly_sig <= dly_sig;
            end case;
        end if;
    end process;

    SIGNAL_OUT <= dly_sig;

end arc_STRB_CNT_DLY;

