-------------------------------------------------------------------------------
-- File Name  : CTRL_GEN2.vhd
-- Author(s)  : wistreechoi.
-- Company    : Samsung Electronics.
-- Created    : 2016-10-13
-------------------------------------------------------------------------------
-- Description: 
-- 1. Control signal generation module using catagory address
-- 2. 
-------------------------------------------------------------------------------
-- CDC Info.
-- 1. There are no CDC problems.
-- 2. 
-------------------------------------------------------------------------------
-- Revision  :
-- Date      : Description
-- 2016.10.13: Initial coding.
-------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity CTRL_GEN2 is
generic (
    ADDR_WIDTH    : natural := 8  -- Input address bit width 
);
port (
    RST           : in  std_logic; -- Active High Reset.
    CLK           : in  std_logic; -- Clock

    ADDR_MIN      : in  std_logic_vector(ADDR_WIDTH-1 downto 0); -- Input address minimun
    ADDR_MAX      : in  std_logic_vector(ADDR_WIDTH-1 downto 0); -- Input address maximum
    ADDR_IN       : in  std_logic_vector(ADDR_WIDTH-1 downto 0); -- Address Input 
    CTRL_IN       : in  std_logic_vector(1 downto 0); -- Control Signal Input
    CTRL_OUT      : out std_logic_vector(1 downto 0)  -- Control Signal Output
);
end CTRL_GEN2;

architecture BEHAVE of CTRL_GEN2 is

begin

CTRL_GEN_PROC0:process (RST, CLK)
begin
    if (RST = '1') then
        CTRL_OUT <= (others => '0');
    elsif (CLK'event and CLK = '1') then
        if (ADDR_IN >= ADDR_MIN) and (ADDR_IN <= ADDR_MAX) then
            CTRL_OUT <= CTRL_IN;
        else
            CTRL_OUT <= (others => '0');
        end if;
    end if;
end process;

end BEHAVE;
