-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name : TDD_STRB_CNTDLY 
-- Project    : CP10_42A, 3.5G KDDI Low power
-- Structure  : 

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

entity TDD_STRB_CNTDLY is
port(
    RST             : in  std_logic; -- Active high reset
    CLK             : in  std_logic; -- Clock
    
    BLK_BYPASS_IN   : in  std_logic; -- '0' normal mode, '1' bypass mode
    DLYCNT_IN       : in  std_logic_vector(11 downto 0); -- Delay Count value, Resolution : 1/(clock frequency)
    
    BFN_STROBE_IN   : in  std_logic;
    TDD_STROBE_IN   : in  std_logic;

    BFNSTRB_DLY_OUT : out std_logic;
    TDDSTRB_DLY_OUT : out std_logic
    );
end TDD_STRB_CNTDLY;

architecture arc_TDD_STRB_CNTDLY of TDD_STRB_CNTDLY is

component STRB_CNT_DLY is
port(
    RST        : in  std_logic;
    CLK        : in  std_logic;
    
    DLYCNT_IN  : in  std_logic_vector(11 downto 0);
    SIGNAL_IN  : in  std_logic;
    
    SIGNAL_OUT : out std_logic
    );
end component;

signal delay_count      : std_logic_vector(11 downto 0); 

signal bypass_sh        : std_logic_vector( 2 downto 0);

signal bfn_strb_reg_dly : std_logic_vector( 6 downto 0);
signal tdd_strb_reg_dly : std_logic_vector( 6 downto 0);

signal bfn_strb_cntdly  : std_logic;
signal tdd_strb_cntdly  : std_logic;

signal bfnstrb_dly      : std_logic;
signal tddstrb_dly      : std_logic;

signal dly_cnt          : std_logic_vector(11 downto 0);


--attribute MARK_DEBUG : string;
--attribute MARK_DEBUG of delay_count         : signal is "TRUE";

--attribute MARK_DEBUG of bypass_sh           : signal is "TRUE";

--attribute MARK_DEBUG of bfn_strb_reg_dly    : signal is "TRUE";
--attribute MARK_DEBUG of tdd_strb_reg_dly    : signal is "TRUE";

--attribute MARK_DEBUG of bfn_strb_cntdly     : signal is "TRUE";
--attribute MARK_DEBUG of tdd_strb_cntdly     : signal is "TRUE";

--attribute MARK_DEBUG of bfnstrb_dly         : signal is "TRUE";
--attribute MARK_DEBUG of tddstrb_dly         : signal is "TRUE";

--attribute MARK_DEBUG of dly_cnt             : signal is "TRUE";

--attribute MARK_DEBUG of BLK_BYPASS_IN       : signal is "TRUE";
--attribute MARK_DEBUG of DLYCNT_IN           : signal is "TRUE";

--attribute MARK_DEBUG of BFN_STROBE_IN       : signal is "TRUE";
--attribute MARK_DEBUG of TDD_STROBE_IN       : signal is "TRUE";

--attribute MARK_DEBUG of BFNSTRB_DLY_OUT     : signal is "TRUE";
--attribute MARK_DEBUG of TDDSTRB_DLY_OUT     : signal is "TRUE"; 






begin

    P_Delay_Count_Clocking : process(RST, CLK) begin
        if (RST = '1') then
            delay_count <= (others => '0');            
        elsif (CLK'event) and (CLK = '1') then
            delay_count <= DLYCNT_IN - '1';            
        end if;
    end process;

    P_Block_Bypass_DC : process(RST, CLK) begin
        if (RST = '1') then
            bypass_sh <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            bypass_sh <= bypass_sh(1 downto 0) & BLK_BYPASS_IN;
        end if;
    end process;

    P_STRB_DLY_register : process(RST, CLK) begin
        if (RST = '1') then
            bfn_strb_reg_dly <= (others => '0');
            tdd_strb_reg_dly <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            bfn_strb_reg_dly <= bfn_strb_reg_dly(5 downto 0) & BFN_STROBE_IN;
            tdd_strb_reg_dly <= tdd_strb_reg_dly(5 downto 0) & TDD_STROBE_IN;
        end if;
    end process;

    P_Limit_Delay_Count : process(RST, CLK) begin
        if (RST = '1') then
            dly_cnt <= x"007";
        elsif (CLK'event) and (CLK = '1') then
            case (delay_count) is
                when x"000"  => dly_cnt <= x"007";
                when x"001"  => dly_cnt <= x"007";
                when x"002"  => dly_cnt <= x"007";
                when x"003"  => dly_cnt <= x"007";
                when x"004"  => dly_cnt <= x"007";
                when x"005"  => dly_cnt <= x"007";
                when x"006"  => dly_cnt <= x"007";
                when x"007"  => dly_cnt <= x"007";
                when others => dly_cnt <= delay_count;
            end case;
        end if;
    end process;

    U_BFN_Strobe_delay : STRB_CNT_DLY port map(RST, CLK, dly_cnt, BFN_STROBE_IN, bfn_strb_cntdly); -- Considered Bypass
    U_TDD_Strobe_delay : STRB_CNT_DLY port map(RST, CLK, dly_cnt, TDD_STROBE_IN, tdd_strb_cntdly); -- Considered Bypass

    P_MUX : process(RST, CLK) begin
        if (RST = '1') then
            bfnstrb_dly <= '0';
            tddstrb_dly <= '0';
        elsif (CLK'event) and (CLK = '1') then
            case (delay_count) is
                when x"000" =>
                    bfnstrb_dly <= bfn_strb_reg_dly(1);
                    tddstrb_dly <= tdd_strb_reg_dly(1);
                when x"001" =>
                    bfnstrb_dly <= bfn_strb_reg_dly(1);
                    tddstrb_dly <= tdd_strb_reg_dly(1);
                when x"002" =>
                    bfnstrb_dly <= bfn_strb_reg_dly(1);
                    tddstrb_dly <= tdd_strb_reg_dly(1);
                when x"003" =>
                    bfnstrb_dly <= bfn_strb_reg_dly(1);
                    tddstrb_dly <= tdd_strb_reg_dly(1);
                when x"004" =>
                    bfnstrb_dly <= bfn_strb_reg_dly(1);
                    tddstrb_dly <= tdd_strb_reg_dly(1);
                when x"005" =>
                    bfnstrb_dly <= bfn_strb_reg_dly(2);
                    tddstrb_dly <= tdd_strb_reg_dly(2);
                when x"006" =>
                    bfnstrb_dly <= bfn_strb_reg_dly(3);
                    tddstrb_dly <= tdd_strb_reg_dly(3);
                when x"007" =>
                    bfnstrb_dly <= bfn_strb_reg_dly(4);
                    tddstrb_dly <= tdd_strb_reg_dly(4);
                when others =>
                    bfnstrb_dly <= bfn_strb_cntdly;
                    tddstrb_dly <= tdd_strb_cntdly;
            end case;
        end if;
    end process;

    P_STRB_Bypass : process(RST, CLK) begin 
        if (RST = '1') then
            BFNSTRB_DLY_OUT <= '0'; 
            TDDSTRB_DLY_OUT <= '0'; 
        elsif (CLK'event) and (CLK = '1') then
            if (bypass_sh(2) = '1') then
                BFNSTRB_DLY_OUT <= bfn_strb_reg_dly(1); 
                TDDSTRB_DLY_OUT <= tdd_strb_reg_dly(1); 
            else
                BFNSTRB_DLY_OUT <= bfnstrb_dly; 
                TDDSTRB_DLY_OUT <= tddstrb_dly; 
            end if;
        end if;
    end process;

end arc_TDD_STRB_CNTDLY;
