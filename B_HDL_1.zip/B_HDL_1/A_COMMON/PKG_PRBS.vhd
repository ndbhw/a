
--------------------------------------------------------------------------------------------------------
-- PKG_PRBS.vhd ----------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
-- Revision History ------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--Please keep the following revision history format
--[2016.10.12_A, wisetreechoi]
----01. Revision-1
----02. Revision-2
--------------------------------------------------------------------------------------------------------
--[2016.10.12_B, wisetreechoi]
----01. add "type std_logic_array256".
--------------------------------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

--use work.PKG_PRBS.all;

package PKG_PRBS is

    --
    --    Fast Parallel PRBS
    --
    function prbs4(   i : std_logic_vector ) return std_logic_vector;
    function prbs8(   i : std_logic_vector ) return std_logic_vector;
    function prbs10(  i : std_logic_vector ) return std_logic_vector;
    function prbs16(  i : std_logic_vector ) return std_logic_vector;
    function prbs20(  i : std_logic_vector ) return std_logic_vector;
    function prbs32(  i : std_logic_vector ) return std_logic_vector;
    function prbs60(  i : std_logic_vector ) return std_logic_vector;
    function prbs64(  i : std_logic_vector ) return std_logic_vector;
    function prbs128( i : std_logic_vector ) return std_logic_vector;

    -- Main PRBS funciton.  This calls all the other size specific functions
    function prbs( iprbs : std_logic_vector ) return std_logic_vector;

    --
    --    PRBS derived from typicall serial PRBS equations
    --
    function prbs32_40b( i : std_logic_vector ) return std_logic_vector;
    function prbs31_40b( i : std_logic_vector ) return std_logic_vector;
    function prbs23_40b( i : std_logic_vector ) return std_logic_vector;
    function prbs20_40b( i : std_logic_vector ) return std_logic_vector;
    function prbs15_40b( i : std_logic_vector ) return std_logic_vector;
    function prbs10_40b( i : std_logic_vector ) return std_logic_vector;
    function prbs7_40b( i : std_logic_vector ) return std_logic_vector;
    function prbs5_40b( i : std_logic_vector ) return std_logic_vector;

    function prbs31_36b( i : std_logic_vector ) return std_logic_vector;
    function prbs23_36b( i : std_logic_vector ) return std_logic_vector;
    function prbs20_36b( i : std_logic_vector ) return std_logic_vector;
    function prbs15_36b( i : std_logic_vector ) return std_logic_vector;
    function prbs10_36b( i : std_logic_vector ) return std_logic_vector;
    function prbs7_36b( i : std_logic_vector ) return std_logic_vector;
    function prbs5_36b( i : std_logic_vector ) return std_logic_vector;

    function prbs20_20b( i : std_logic_vector ) return std_logic_vector;
    function prbs15_20b( i : std_logic_vector ) return std_logic_vector;
    function prbs10_20b( i : std_logic_vector ) return std_logic_vector;
    function prbs7_20b( i : std_logic_vector ) return std_logic_vector;
    function prbs5_20b( i : std_logic_vector ) return std_logic_vector;

    function prbs10_10b( i : std_logic_vector ) return std_logic_vector;
    function prbs7_10b( i : std_logic_vector ) return std_logic_vector;
    function prbs5_10b( i : std_logic_vector ) return std_logic_vector;

    function prbs31_32b( i : std_logic_vector ) return std_logic_vector;
    function prbs23_32b( i : std_logic_vector ) return std_logic_vector;
    function prbs20_32b( i : std_logic_vector ) return std_logic_vector;
    function prbs15_32b( i : std_logic_vector ) return std_logic_vector;
    function prbs10_32b( i : std_logic_vector ) return std_logic_vector;
    function prbs7_32b( i : std_logic_vector ) return std_logic_vector;
    function prbs5_32b( i : std_logic_vector ) return std_logic_vector;

    function prbs15_16b( i : std_logic_vector ) return std_logic_vector;
    function prbs10_16b( i : std_logic_vector ) return std_logic_vector;
    function prbs7_16b( i : std_logic_vector ) return std_logic_vector;
    function prbs5_16b( i : std_logic_vector ) return std_logic_vector;
    
--crc32 = x32_x26_x23_x22_x16_x12_x11_x10_x8_x7_x5_x4_x2_x_1
    function crc32 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector;
--crc16 = x16_x12_x5_1
    function crc16 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector;    
--crc8 = x16_x12_x5_1
    function crc_x8 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector;    
--crc8 = x8+x2+x+1    
    function crc8 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector;

end PKG_PRBS;

------------------------------------------------
package body PKG_PRBS is

    -------------------------------------
    --    Parallel PRBS for width: Automatic
    -------------------------------------
    function prbs( iprbs : std_logic_vector )
    return std_logic_vector is
        constant w : integer := iprbs'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin

        case w is
            when   8 => oprbs := prbs8(  iprbs);
            when  10 => oprbs := prbs10( iprbs);
            when  16 => oprbs := prbs16( iprbs);
            when  20 => oprbs := prbs20( iprbs);
            when  32 => oprbs := prbs32( iprbs);
            when  60 => oprbs := prbs60( iprbs);
            when  64 => oprbs := prbs64( iprbs);
            when 128 => oprbs := prbs128(iprbs);
            when others => oprbs := (others => 'U');
        end case;

        return oprbs;
    end;

    -------------------------------------
    --    Parallel PRBS for width: 4
    --    c4 c1
    -------------------------------------
    function prbs4( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(0) := i(0) xor i(3);
        oprbs(1) := i(0) xor i(1) xor i(3);
        oprbs(2) := i(1) xor i(2);
        oprbs(3) := i(2) xor i(3);

        return oprbs;
    end;

    -------------------------------------
    --    Parallel PRBS for width: 8
    --    c8 c6 c5 c1
    -------------------------------------
    function prbs8( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(0) := i(0) xor i(2) xor i(3) xor i(4);
        oprbs(1) := i(0) xor i(1) xor i(2) xor i(5);
        oprbs(2) := i(1) xor i(2) xor i(3) xor i(6);
        oprbs(3) := i(2) xor i(3) xor i(4) xor i(7);
        oprbs(4) := i(3) xor i(4) xor i(5);
        oprbs(5) := i(0) xor i(2) xor i(3) xor i(5) xor i(6);
        oprbs(6) := i(0) xor i(1) xor i(2) xor i(6) xor i(7);
        oprbs(7) := i(1) xor i(2) xor i(3) xor i(7);

        return oprbs;
    end;

    -------------------------------------
    --    Parallel PRBS for width: 10
    --    c10 c3
    -------------------------------------
    function prbs10( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(0) := i(0) xor i(7);
        oprbs(1) := i(1) xor i(8);
        oprbs(2) := i(2) xor i(9);
        oprbs(3) := i(0) xor i(3) xor i(7);
        oprbs(4) := i(1) xor i(4) xor i(8);
        oprbs(5) := i(2) xor i(5) xor i(9);
        oprbs(6) := i(3) xor i(6);
        oprbs(7) := i(4) xor i(7);
        oprbs(8) := i(5) xor i(8);
        oprbs(9) := i(6) xor i(9);

        return oprbs;
    end;

    -------------------------------------
    --    Parallel PRBS for width: 16
    --    c16 c5 c3 c2
    -------------------------------------
    function prbs16( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin

        oprbs(0) := i(0) xor i(11) xor i(13) xor i(14);
        oprbs(1) := i(1) xor i(12) xor i(14) xor i(15);
        oprbs(2) := i(0) xor i(2) xor i(11) xor i(14) xor i(15);
        oprbs(3) := i(0) xor i(1) xor i(3) xor i(11) xor i(12) xor i(13) xor i(14) xor i(15);
        oprbs(4) := i(1) xor i(2) xor i(4) xor i(12) xor i(13) xor i(14) xor i(15);
        oprbs(5) := i(0) xor i(2) xor i(3) xor i(5) xor i(11) xor i(15);
        oprbs(6) := i(1) xor i(3) xor i(4) xor i(6) xor i(12);
        oprbs(7) := i(2) xor i(4) xor i(5) xor i(7) xor i(13);
        oprbs(8) := i(3) xor i(5) xor i(6) xor i(8) xor i(14);
        oprbs(9) := i(4) xor i(6) xor i(7) xor i(9) xor i(15);
        oprbs(10) := i(5) xor i(7) xor i(8) xor i(10);
        oprbs(11) := i(6) xor i(8) xor i(9) xor i(11);
        oprbs(12) := i(7) xor i(9) xor i(10) xor i(12);
        oprbs(13) := i(8) xor i(10) xor i(11) xor i(13);
        oprbs(14) := i(9) xor i(11) xor i(12) xor i(14);
        oprbs(15) := i(10) xor i(12) xor i(13) xor i(15);

        return oprbs;
    end;

    -------------------------------------
    --    Parallel PRBS for width: 20
    --    c20 c3
    -------------------------------------
    function prbs20( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin

        oprbs(0) := i(0) xor i(17);
        oprbs(1) := i(1) xor i(18);
        oprbs(2) := i(2) xor i(19);
        oprbs(3) := i(0) xor i(3) xor i(17);
        oprbs(4) := i(1) xor i(4) xor i(18);
        oprbs(5) := i(2) xor i(5) xor i(19);
        oprbs(6) := i(3) xor i(6);
        oprbs(7) := i(4) xor i(7);
        oprbs(8) := i(5) xor i(8);
        oprbs(9) := i(6) xor i(9);
        oprbs(10) := i(7) xor i(10);
        oprbs(11) := i(8) xor i(11);
        oprbs(12) := i(9) xor i(12);
        oprbs(13) := i(10) xor i(13);
        oprbs(14) := i(11) xor i(14);
        oprbs(15) := i(12) xor i(15);
        oprbs(16) := i(13) xor i(16);
        oprbs(17) := i(14) xor i(17);
        oprbs(18) := i(15) xor i(18);
        oprbs(19) := i(16) xor i(19);

        return oprbs;
    end;

    -------------------------------------
    --    Parallel PRBS for width: 32
    --    c32 c28 c27 c1
    -------------------------------------
    function prbs32( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin

        oprbs(0) := i(0) xor i(4) xor i(5) xor i(8) xor i(10) xor i(12) xor i(13) xor i(14) xor i(15) xor i(16) xor i(21) xor i(25) xor i(26) xor i(29);
        oprbs(1) := i(0) xor i(1) xor i(4) xor i(6) xor i(8) xor i(9) xor i(10) xor i(11) xor i(12) xor i(17) xor i(21) xor i(22) xor i(25) xor i(27) xor i(29) xor i(30);
        oprbs(2) := i(1) xor i(2) xor i(5) xor i(7) xor i(9) xor i(10) xor i(11) xor i(12) xor i(13) xor i(18) xor i(22) xor i(23) xor i(26) xor i(28) xor i(30) xor i(31);
        oprbs(3) := i(2) xor i(3) xor i(6) xor i(8) xor i(10) xor i(11) xor i(12) xor i(13) xor i(14) xor i(19) xor i(23) xor i(24) xor i(27) xor i(29) xor i(31);
        oprbs(4) := i(3) xor i(4) xor i(7) xor i(9) xor i(11) xor i(12) xor i(13) xor i(14) xor i(15) xor i(20) xor i(24) xor i(25) xor i(28) xor i(30);
        oprbs(5) := i(4) xor i(5) xor i(8) xor i(10) xor i(12) xor i(13) xor i(14) xor i(15) xor i(16) xor i(21) xor i(25) xor i(26) xor i(29) xor i(31);
        oprbs(6) := i(5) xor i(6) xor i(9) xor i(11) xor i(13) xor i(14) xor i(15) xor i(16) xor i(17) xor i(22) xor i(26) xor i(27) xor i(30);
        oprbs(7) := i(6) xor i(7) xor i(10) xor i(12) xor i(14) xor i(15) xor i(16) xor i(17) xor i(18) xor i(23) xor i(27) xor i(28) xor i(31);
        oprbs(8) := i(7) xor i(8) xor i(11) xor i(13) xor i(15) xor i(16) xor i(17) xor i(18) xor i(19) xor i(24) xor i(28) xor i(29);
        oprbs(9) := i(8) xor i(9) xor i(12) xor i(14) xor i(16) xor i(17) xor i(18) xor i(19) xor i(20) xor i(25) xor i(29) xor i(30);
        oprbs(10) := i(9) xor i(10) xor i(13) xor i(15) xor i(17) xor i(18) xor i(19) xor i(20) xor i(21) xor i(26) xor i(30) xor i(31);
        oprbs(11) := i(10) xor i(11) xor i(14) xor i(16) xor i(18) xor i(19) xor i(20) xor i(21) xor i(22) xor i(27) xor i(31);
        oprbs(12) := i(11) xor i(12) xor i(15) xor i(17) xor i(19) xor i(20) xor i(21) xor i(22) xor i(23) xor i(28);
        oprbs(13) := i(12) xor i(13) xor i(16) xor i(18) xor i(20) xor i(21) xor i(22) xor i(23) xor i(24) xor i(29);
        oprbs(14) := i(13) xor i(14) xor i(17) xor i(19) xor i(21) xor i(22) xor i(23) xor i(24) xor i(25) xor i(30);
        oprbs(15) := i(14) xor i(15) xor i(18) xor i(20) xor i(22) xor i(23) xor i(24) xor i(25) xor i(26) xor i(31);
        oprbs(16) := i(15) xor i(16) xor i(19) xor i(21) xor i(23) xor i(24) xor i(25) xor i(26) xor i(27);
        oprbs(17) := i(16) xor i(17) xor i(20) xor i(22) xor i(24) xor i(25) xor i(26) xor i(27) xor i(28);
        oprbs(18) := i(17) xor i(18) xor i(21) xor i(23) xor i(25) xor i(26) xor i(27) xor i(28) xor i(29);
        oprbs(19) := i(18) xor i(19) xor i(22) xor i(24) xor i(26) xor i(27) xor i(28) xor i(29) xor i(30);
        oprbs(20) := i(19) xor i(20) xor i(23) xor i(25) xor i(27) xor i(28) xor i(29) xor i(30) xor i(31);
        oprbs(21) := i(20) xor i(21) xor i(24) xor i(26) xor i(28) xor i(29) xor i(30) xor i(31);
        oprbs(22) := i(21) xor i(22) xor i(25) xor i(27) xor i(29) xor i(30) xor i(31);
        oprbs(23) := i(22) xor i(23) xor i(26) xor i(28) xor i(30) xor i(31);
        oprbs(24) := i(23) xor i(24) xor i(27) xor i(29) xor i(31);
        oprbs(25) := i(24) xor i(25) xor i(28) xor i(30);
        oprbs(26) := i(25) xor i(26) xor i(29) xor i(31);
        oprbs(27) := i(0) xor i(4) xor i(5) xor i(8) xor i(10) xor i(12) xor i(13) xor i(14) xor i(15) xor i(16) xor i(21) xor i(25) xor i(27) xor i(29) xor i(30);
        oprbs(28) := i(0) xor i(1) xor i(4) xor i(6) xor i(8) xor i(9) xor i(10) xor i(11) xor i(12) xor i(17) xor i(21) xor i(22) xor i(25) xor i(28) xor i(29) xor i(30) xor i(31);
        oprbs(29) := i(1) xor i(2) xor i(5) xor i(7) xor i(9) xor i(10) xor i(11) xor i(12) xor i(13) xor i(18) xor i(22) xor i(23) xor i(26) xor i(29) xor i(30) xor i(31);
        oprbs(30) := i(2) xor i(3) xor i(6) xor i(8) xor i(10) xor i(11) xor i(12) xor i(13) xor i(14) xor i(19) xor i(23) xor i(24) xor i(27) xor i(30) xor i(31);
        oprbs(31) := i(3) xor i(4) xor i(7) xor i(9) xor i(11) xor i(12) xor i(13) xor i(14) xor i(15) xor i(20) xor i(24) xor i(25) xor i(28) xor i(31);

        return oprbs;
    end;

    -------------------------------------
    --    Parallel PRBS for width: 60
    --    c60 c1
    -------------------------------------
    function prbs60( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin

        oprbs(0) := i(0) xor i(59);
        oprbs(1) := i(0) xor i(1) xor i(59);
        oprbs(2) := i(1) xor i(2);
        oprbs(3) := i(2) xor i(3);
        oprbs(4) := i(3) xor i(4);
        oprbs(5) := i(4) xor i(5);
        oprbs(6) := i(5) xor i(6);
        oprbs(7) := i(6) xor i(7);
        oprbs(8) := i(7) xor i(8);
        oprbs(9) := i(8) xor i(9);
        oprbs(10) := i(9) xor i(10);
        oprbs(11) := i(10) xor i(11);
        oprbs(12) := i(11) xor i(12);
        oprbs(13) := i(12) xor i(13);
        oprbs(14) := i(13) xor i(14);
        oprbs(15) := i(14) xor i(15);
        oprbs(16) := i(15) xor i(16);
        oprbs(17) := i(16) xor i(17);
        oprbs(18) := i(17) xor i(18);
        oprbs(19) := i(18) xor i(19);
        oprbs(20) := i(19) xor i(20);
        oprbs(21) := i(20) xor i(21);
        oprbs(22) := i(21) xor i(22);
        oprbs(23) := i(22) xor i(23);
        oprbs(24) := i(23) xor i(24);
        oprbs(25) := i(24) xor i(25);
        oprbs(26) := i(25) xor i(26);
        oprbs(27) := i(26) xor i(27);
        oprbs(28) := i(27) xor i(28);
        oprbs(29) := i(28) xor i(29);
        oprbs(30) := i(29) xor i(30);
        oprbs(31) := i(30) xor i(31);
        oprbs(32) := i(31) xor i(32);
        oprbs(33) := i(32) xor i(33);
        oprbs(34) := i(33) xor i(34);
        oprbs(35) := i(34) xor i(35);
        oprbs(36) := i(35) xor i(36);
        oprbs(37) := i(36) xor i(37);
        oprbs(38) := i(37) xor i(38);
        oprbs(39) := i(38) xor i(39);
        oprbs(40) := i(39) xor i(40);
        oprbs(41) := i(40) xor i(41);
        oprbs(42) := i(41) xor i(42);
        oprbs(43) := i(42) xor i(43);
        oprbs(44) := i(43) xor i(44);
        oprbs(45) := i(44) xor i(45);
        oprbs(46) := i(45) xor i(46);
        oprbs(47) := i(46) xor i(47);
        oprbs(48) := i(47) xor i(48);
        oprbs(49) := i(48) xor i(49);
        oprbs(50) := i(49) xor i(50);
        oprbs(51) := i(50) xor i(51);
        oprbs(52) := i(51) xor i(52);
        oprbs(53) := i(52) xor i(53);
        oprbs(54) := i(53) xor i(54);
        oprbs(55) := i(54) xor i(55);
        oprbs(56) := i(55) xor i(56);
        oprbs(57) := i(56) xor i(57);
        oprbs(58) := i(57) xor i(58);
        oprbs(59) := i(58) xor i(59);

        return oprbs;
    end;

    -------------------------------------
    --    Parallel PRBS for width: 64
    --    c64 c4 c3 c1
    -------------------------------------
    function prbs64( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin

        oprbs(0) := i(0) xor i(60) xor i(61) xor i(63);
        oprbs(1) := i(0) xor i(1) xor i(60) xor i(62) xor i(63);
        oprbs(2) := i(1) xor i(2) xor i(61) xor i(63);
        oprbs(3) := i(0) xor i(2) xor i(3) xor i(60) xor i(61) xor i(62) xor i(63);
        oprbs(4) := i(0) xor i(1) xor i(3) xor i(4) xor i(60) xor i(62);
        oprbs(5) := i(1) xor i(2) xor i(4) xor i(5) xor i(61) xor i(63);
        oprbs(6) := i(2) xor i(3) xor i(5) xor i(6) xor i(62);
        oprbs(7) := i(3) xor i(4) xor i(6) xor i(7) xor i(63);
        oprbs(8) := i(4) xor i(5) xor i(7) xor i(8);
        oprbs(9) := i(5) xor i(6) xor i(8) xor i(9);
        oprbs(10) := i(6) xor i(7) xor i(9) xor i(10);
        oprbs(11) := i(7) xor i(8) xor i(10) xor i(11);
        oprbs(12) := i(8) xor i(9) xor i(11) xor i(12);
        oprbs(13) := i(9) xor i(10) xor i(12) xor i(13);
        oprbs(14) := i(10) xor i(11) xor i(13) xor i(14);
        oprbs(15) := i(11) xor i(12) xor i(14) xor i(15);
        oprbs(16) := i(12) xor i(13) xor i(15) xor i(16);
        oprbs(17) := i(13) xor i(14) xor i(16) xor i(17);
        oprbs(18) := i(14) xor i(15) xor i(17) xor i(18);
        oprbs(19) := i(15) xor i(16) xor i(18) xor i(19);
        oprbs(20) := i(16) xor i(17) xor i(19) xor i(20);
        oprbs(21) := i(17) xor i(18) xor i(20) xor i(21);
        oprbs(22) := i(18) xor i(19) xor i(21) xor i(22);
        oprbs(23) := i(19) xor i(20) xor i(22) xor i(23);
        oprbs(24) := i(20) xor i(21) xor i(23) xor i(24);
        oprbs(25) := i(21) xor i(22) xor i(24) xor i(25);
        oprbs(26) := i(22) xor i(23) xor i(25) xor i(26);
        oprbs(27) := i(23) xor i(24) xor i(26) xor i(27);
        oprbs(28) := i(24) xor i(25) xor i(27) xor i(28);
        oprbs(29) := i(25) xor i(26) xor i(28) xor i(29);
        oprbs(30) := i(26) xor i(27) xor i(29) xor i(30);
        oprbs(31) := i(27) xor i(28) xor i(30) xor i(31);
        oprbs(32) := i(28) xor i(29) xor i(31) xor i(32);
        oprbs(33) := i(29) xor i(30) xor i(32) xor i(33);
        oprbs(34) := i(30) xor i(31) xor i(33) xor i(34);
        oprbs(35) := i(31) xor i(32) xor i(34) xor i(35);
        oprbs(36) := i(32) xor i(33) xor i(35) xor i(36);
        oprbs(37) := i(33) xor i(34) xor i(36) xor i(37);
        oprbs(38) := i(34) xor i(35) xor i(37) xor i(38);
        oprbs(39) := i(35) xor i(36) xor i(38) xor i(39);
        oprbs(40) := i(36) xor i(37) xor i(39) xor i(40);
        oprbs(41) := i(37) xor i(38) xor i(40) xor i(41);
        oprbs(42) := i(38) xor i(39) xor i(41) xor i(42);
        oprbs(43) := i(39) xor i(40) xor i(42) xor i(43);
        oprbs(44) := i(40) xor i(41) xor i(43) xor i(44);
        oprbs(45) := i(41) xor i(42) xor i(44) xor i(45);
        oprbs(46) := i(42) xor i(43) xor i(45) xor i(46);
        oprbs(47) := i(43) xor i(44) xor i(46) xor i(47);
        oprbs(48) := i(44) xor i(45) xor i(47) xor i(48);
        oprbs(49) := i(45) xor i(46) xor i(48) xor i(49);
        oprbs(50) := i(46) xor i(47) xor i(49) xor i(50);
        oprbs(51) := i(47) xor i(48) xor i(50) xor i(51);
        oprbs(52) := i(48) xor i(49) xor i(51) xor i(52);
        oprbs(53) := i(49) xor i(50) xor i(52) xor i(53);
        oprbs(54) := i(50) xor i(51) xor i(53) xor i(54);
        oprbs(55) := i(51) xor i(52) xor i(54) xor i(55);
        oprbs(56) := i(52) xor i(53) xor i(55) xor i(56);
        oprbs(57) := i(53) xor i(54) xor i(56) xor i(57);
        oprbs(58) := i(54) xor i(55) xor i(57) xor i(58);
        oprbs(59) := i(55) xor i(56) xor i(58) xor i(59);
        oprbs(60) := i(56) xor i(57) xor i(59) xor i(60);
        oprbs(61) := i(57) xor i(58) xor i(60) xor i(61);
        oprbs(62) := i(58) xor i(59) xor i(61) xor i(62);
        oprbs(63) := i(59) xor i(60) xor i(62) xor i(63);

        return oprbs;
    end;

    -------------------------------------
    --    Parallel PRBS for width: 128
    --    c128 c29 c27 c2
    -------------------------------------
    function prbs128( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin

        oprbs(0) := i(0) xor i(99) xor i(101) xor i(126);
        oprbs(1) := i(1) xor i(100) xor i(102) xor i(127);
        oprbs(2) := i(0) xor i(2) xor i(99) xor i(103) xor i(126);
        oprbs(3) := i(1) xor i(3) xor i(100) xor i(104) xor i(127);
        oprbs(4) := i(2) xor i(4) xor i(101) xor i(105);
        oprbs(5) := i(3) xor i(5) xor i(102) xor i(106);
        oprbs(6) := i(4) xor i(6) xor i(103) xor i(107);
        oprbs(7) := i(5) xor i(7) xor i(104) xor i(108);
        oprbs(8) := i(6) xor i(8) xor i(105) xor i(109);
        oprbs(9) := i(7) xor i(9) xor i(106) xor i(110);
        oprbs(10) := i(8) xor i(10) xor i(107) xor i(111);
        oprbs(11) := i(9) xor i(11) xor i(108) xor i(112);
        oprbs(12) := i(10) xor i(12) xor i(109) xor i(113);
        oprbs(13) := i(11) xor i(13) xor i(110) xor i(114);
        oprbs(14) := i(12) xor i(14) xor i(111) xor i(115);
        oprbs(15) := i(13) xor i(15) xor i(112) xor i(116);
        oprbs(16) := i(14) xor i(16) xor i(113) xor i(117);
        oprbs(17) := i(15) xor i(17) xor i(114) xor i(118);
        oprbs(18) := i(16) xor i(18) xor i(115) xor i(119);
        oprbs(19) := i(17) xor i(19) xor i(116) xor i(120);
        oprbs(20) := i(18) xor i(20) xor i(117) xor i(121);
        oprbs(21) := i(19) xor i(21) xor i(118) xor i(122);
        oprbs(22) := i(20) xor i(22) xor i(119) xor i(123);
        oprbs(23) := i(21) xor i(23) xor i(120) xor i(124);
        oprbs(24) := i(22) xor i(24) xor i(121) xor i(125);
        oprbs(25) := i(23) xor i(25) xor i(122) xor i(126);
        oprbs(26) := i(24) xor i(26) xor i(123) xor i(127);
        oprbs(27) := i(0) xor i(25) xor i(27) xor i(99) xor i(101) xor i(124) xor i(126);
        oprbs(28) := i(1) xor i(26) xor i(28) xor i(100) xor i(102) xor i(125) xor i(127);
        oprbs(29) := i(0) xor i(2) xor i(27) xor i(29) xor i(99) xor i(103);
        oprbs(30) := i(1) xor i(3) xor i(28) xor i(30) xor i(100) xor i(104);
        oprbs(31) := i(2) xor i(4) xor i(29) xor i(31) xor i(101) xor i(105);
        oprbs(32) := i(3) xor i(5) xor i(30) xor i(32) xor i(102) xor i(106);
        oprbs(33) := i(4) xor i(6) xor i(31) xor i(33) xor i(103) xor i(107);
        oprbs(34) := i(5) xor i(7) xor i(32) xor i(34) xor i(104) xor i(108);
        oprbs(35) := i(6) xor i(8) xor i(33) xor i(35) xor i(105) xor i(109);
        oprbs(36) := i(7) xor i(9) xor i(34) xor i(36) xor i(106) xor i(110);
        oprbs(37) := i(8) xor i(10) xor i(35) xor i(37) xor i(107) xor i(111);
        oprbs(38) := i(9) xor i(11) xor i(36) xor i(38) xor i(108) xor i(112);
        oprbs(39) := i(10) xor i(12) xor i(37) xor i(39) xor i(109) xor i(113);
        oprbs(40) := i(11) xor i(13) xor i(38) xor i(40) xor i(110) xor i(114);
        oprbs(41) := i(12) xor i(14) xor i(39) xor i(41) xor i(111) xor i(115);
        oprbs(42) := i(13) xor i(15) xor i(40) xor i(42) xor i(112) xor i(116);
        oprbs(43) := i(14) xor i(16) xor i(41) xor i(43) xor i(113) xor i(117);
        oprbs(44) := i(15) xor i(17) xor i(42) xor i(44) xor i(114) xor i(118);
        oprbs(45) := i(16) xor i(18) xor i(43) xor i(45) xor i(115) xor i(119);
        oprbs(46) := i(17) xor i(19) xor i(44) xor i(46) xor i(116) xor i(120);
        oprbs(47) := i(18) xor i(20) xor i(45) xor i(47) xor i(117) xor i(121);
        oprbs(48) := i(19) xor i(21) xor i(46) xor i(48) xor i(118) xor i(122);
        oprbs(49) := i(20) xor i(22) xor i(47) xor i(49) xor i(119) xor i(123);
        oprbs(50) := i(21) xor i(23) xor i(48) xor i(50) xor i(120) xor i(124);
        oprbs(51) := i(22) xor i(24) xor i(49) xor i(51) xor i(121) xor i(125);
        oprbs(52) := i(23) xor i(25) xor i(50) xor i(52) xor i(122) xor i(126);
        oprbs(53) := i(24) xor i(26) xor i(51) xor i(53) xor i(123) xor i(127);
        oprbs(54) := i(25) xor i(27) xor i(52) xor i(54) xor i(124);
        oprbs(55) := i(26) xor i(28) xor i(53) xor i(55) xor i(125);
        oprbs(56) := i(27) xor i(29) xor i(54) xor i(56) xor i(126);
        oprbs(57) := i(28) xor i(30) xor i(55) xor i(57) xor i(127);
        oprbs(58) := i(29) xor i(31) xor i(56) xor i(58);
        oprbs(59) := i(30) xor i(32) xor i(57) xor i(59);
        oprbs(60) := i(31) xor i(33) xor i(58) xor i(60);
        oprbs(61) := i(32) xor i(34) xor i(59) xor i(61);
        oprbs(62) := i(33) xor i(35) xor i(60) xor i(62);
        oprbs(63) := i(34) xor i(36) xor i(61) xor i(63);
        oprbs(64) := i(35) xor i(37) xor i(62) xor i(64);
        oprbs(65) := i(36) xor i(38) xor i(63) xor i(65);
        oprbs(66) := i(37) xor i(39) xor i(64) xor i(66);
        oprbs(67) := i(38) xor i(40) xor i(65) xor i(67);
        oprbs(68) := i(39) xor i(41) xor i(66) xor i(68);
        oprbs(69) := i(40) xor i(42) xor i(67) xor i(69);
        oprbs(70) := i(41) xor i(43) xor i(68) xor i(70);
        oprbs(71) := i(42) xor i(44) xor i(69) xor i(71);
        oprbs(72) := i(43) xor i(45) xor i(70) xor i(72);
        oprbs(73) := i(44) xor i(46) xor i(71) xor i(73);
        oprbs(74) := i(45) xor i(47) xor i(72) xor i(74);
        oprbs(75) := i(46) xor i(48) xor i(73) xor i(75);
        oprbs(76) := i(47) xor i(49) xor i(74) xor i(76);
        oprbs(77) := i(48) xor i(50) xor i(75) xor i(77);
        oprbs(78) := i(49) xor i(51) xor i(76) xor i(78);
        oprbs(79) := i(50) xor i(52) xor i(77) xor i(79);
        oprbs(80) := i(51) xor i(53) xor i(78) xor i(80);
        oprbs(81) := i(52) xor i(54) xor i(79) xor i(81);
        oprbs(82) := i(53) xor i(55) xor i(80) xor i(82);
        oprbs(83) := i(54) xor i(56) xor i(81) xor i(83);
        oprbs(84) := i(55) xor i(57) xor i(82) xor i(84);
        oprbs(85) := i(56) xor i(58) xor i(83) xor i(85);
        oprbs(86) := i(57) xor i(59) xor i(84) xor i(86);
        oprbs(87) := i(58) xor i(60) xor i(85) xor i(87);
        oprbs(88) := i(59) xor i(61) xor i(86) xor i(88);
        oprbs(89) := i(60) xor i(62) xor i(87) xor i(89);
        oprbs(90) := i(61) xor i(63) xor i(88) xor i(90);
        oprbs(91) := i(62) xor i(64) xor i(89) xor i(91);
        oprbs(92) := i(63) xor i(65) xor i(90) xor i(92);
        oprbs(93) := i(64) xor i(66) xor i(91) xor i(93);
        oprbs(94) := i(65) xor i(67) xor i(92) xor i(94);
        oprbs(95) := i(66) xor i(68) xor i(93) xor i(95);
        oprbs(96) := i(67) xor i(69) xor i(94) xor i(96);
        oprbs(97) := i(68) xor i(70) xor i(95) xor i(97);
        oprbs(98) := i(69) xor i(71) xor i(96) xor i(98);
        oprbs(99) := i(70) xor i(72) xor i(97) xor i(99);
        oprbs(100) := i(71) xor i(73) xor i(98) xor i(100);
        oprbs(101) := i(72) xor i(74) xor i(99) xor i(101);
        oprbs(102) := i(73) xor i(75) xor i(100) xor i(102);
        oprbs(103) := i(74) xor i(76) xor i(101) xor i(103);
        oprbs(104) := i(75) xor i(77) xor i(102) xor i(104);
        oprbs(105) := i(76) xor i(78) xor i(103) xor i(105);
        oprbs(106) := i(77) xor i(79) xor i(104) xor i(106);
        oprbs(107) := i(78) xor i(80) xor i(105) xor i(107);
        oprbs(108) := i(79) xor i(81) xor i(106) xor i(108);
        oprbs(109) := i(80) xor i(82) xor i(107) xor i(109);
        oprbs(110) := i(81) xor i(83) xor i(108) xor i(110);
        oprbs(111) := i(82) xor i(84) xor i(109) xor i(111);
        oprbs(112) := i(83) xor i(85) xor i(110) xor i(112);
        oprbs(113) := i(84) xor i(86) xor i(111) xor i(113);
        oprbs(114) := i(85) xor i(87) xor i(112) xor i(114);
        oprbs(115) := i(86) xor i(88) xor i(113) xor i(115);
        oprbs(116) := i(87) xor i(89) xor i(114) xor i(116);
        oprbs(117) := i(88) xor i(90) xor i(115) xor i(117);
        oprbs(118) := i(89) xor i(91) xor i(116) xor i(118);
        oprbs(119) := i(90) xor i(92) xor i(117) xor i(119);
        oprbs(120) := i(91) xor i(93) xor i(118) xor i(120);
        oprbs(121) := i(92) xor i(94) xor i(119) xor i(121);
        oprbs(122) := i(93) xor i(95) xor i(120) xor i(122);
        oprbs(123) := i(94) xor i(96) xor i(121) xor i(123);
        oprbs(124) := i(95) xor i(97) xor i(122) xor i(124);
        oprbs(125) := i(96) xor i(98) xor i(123) xor i(125);
        oprbs(126) := i(97) xor i(99) xor i(124) xor i(126);
        oprbs(127) := i(98) xor i(100) xor i(125) xor i(127);

        return oprbs;
    end;

    --###########################################################################
    --    PRBS derived from typicall serial PRBS equations
    --




    ------------------------------------------------
    --    Parallel PRBS prbs32_40b. Bus Size 40
    --    X^32 + X^31 + X^30; X^10 + 1
    ------------------------------------------------
    function prbs32_40b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(39) := i(9) xor i(29) xor i(30) xor i(31);
        oprbs(38) := i(8) xor i(28) xor i(29) xor i(30);
        oprbs(37) := i(7) xor i(27) xor i(28) xor i(29);
        oprbs(36) := i(6) xor i(26) xor i(27) xor i(28);
        oprbs(35) := i(5) xor i(25) xor i(26) xor i(27);
        oprbs(34) := i(4) xor i(24) xor i(25) xor i(26);
        oprbs(33) := i(3) xor i(23) xor i(24) xor i(25);
        oprbs(32) := i(2) xor i(22) xor i(23) xor i(24);
        oprbs(31) := i(1) xor i(21) xor i(22) xor i(23);
        oprbs(30) := i(0) xor i(20) xor i(21) xor i(22);
        oprbs(29) := i(9) xor i(19) xor i(20) xor i(21) xor i(29) xor i(30) xor i(31);
        oprbs(28) := i(8) xor i(18) xor i(19) xor i(20) xor i(28) xor i(29) xor i(30);
        oprbs(27) := i(7) xor i(17) xor i(18) xor i(19) xor i(27) xor i(28) xor i(29);
        oprbs(26) := i(6) xor i(16) xor i(17) xor i(18) xor i(26) xor i(27) xor i(28);
        oprbs(25) := i(5) xor i(15) xor i(16) xor i(17) xor i(25) xor i(26) xor i(27);
        oprbs(24) := i(4) xor i(14) xor i(15) xor i(16) xor i(24) xor i(25) xor i(26);
        oprbs(23) := i(3) xor i(13) xor i(14) xor i(15) xor i(23) xor i(24) xor i(25);
        oprbs(22) := i(2) xor i(12) xor i(13) xor i(14) xor i(22) xor i(23) xor i(24);
        oprbs(21) := i(1) xor i(11) xor i(12) xor i(13) xor i(21) xor i(22) xor i(23);
        oprbs(20) := i(0) xor i(10) xor i(11) xor i(12) xor i(20) xor i(21) xor i(22);
        oprbs(19) := i(10) xor i(11) xor i(19) xor i(20) xor i(21) xor i(29) xor i(30) xor i(31);
        oprbs(18) := i(9) xor i(10) xor i(18) xor i(19) xor i(20) xor i(28) xor i(29) xor i(30);
        oprbs(17) := i(8) xor i(9) xor i(17) xor i(18) xor i(19) xor i(27) xor i(28) xor i(29);
        oprbs(16) := i(7) xor i(8) xor i(16) xor i(17) xor i(18) xor i(26) xor i(27) xor i(28);
        oprbs(15) := i(6) xor i(7) xor i(15) xor i(16) xor i(17) xor i(25) xor i(26) xor i(27);
        oprbs(14) := i(5) xor i(6) xor i(14) xor i(15) xor i(16) xor i(24) xor i(25) xor i(26);
        oprbs(13) := i(4) xor i(5) xor i(13) xor i(14) xor i(15) xor i(23) xor i(24) xor i(25);
        oprbs(12) := i(3) xor i(4) xor i(12) xor i(13) xor i(14) xor i(22) xor i(23) xor i(24);
        oprbs(11) := i(2) xor i(3) xor i(11) xor i(12) xor i(13) xor i(21) xor i(22) xor i(23);
        oprbs(10) := i(1) xor i(2) xor i(10) xor i(11) xor i(12) xor i(20) xor i(21) xor i(22);
        oprbs(9) := i(0) xor i(1) xor i(9) xor i(10) xor i(11) xor i(19) xor i(20) xor i(21);
        oprbs(8) := i(0) xor i(8) xor i(10) xor i(18) xor i(19) xor i(20) xor i(29) xor i(30) xor i(31);
        oprbs(7) := i(7) xor i(17) xor i(18) xor i(19) xor i(28) xor i(31);
        oprbs(6) := i(6) xor i(16) xor i(17) xor i(18) xor i(27) xor i(30);
        oprbs(5) := i(5) xor i(15) xor i(16) xor i(17) xor i(26) xor i(29);
        oprbs(4) := i(4) xor i(14) xor i(15) xor i(16) xor i(25) xor i(28);
        oprbs(3) := i(3) xor i(13) xor i(14) xor i(15) xor i(24) xor i(27);
        oprbs(2) := i(2) xor i(12) xor i(13) xor i(14) xor i(23) xor i(26);
        oprbs(1) := i(1) xor i(11) xor i(12) xor i(13) xor i(22) xor i(25);
        oprbs(0) := i(0) xor i(10) xor i(11) xor i(12) xor i(21) xor i(24);
        return oprbs;
    end;

    ------------------------------------------------
    --    Parallel PRBS prbs31_40b. Bus Size 40
    --    X^31 + X^28 + 1
    ------------------------------------------------
    function prbs31_40b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(39) := i(27) xor i(30);
        oprbs(38) := i(26) xor i(29);
        oprbs(37) := i(25) xor i(28);
        oprbs(36) := i(24) xor i(27);
        oprbs(35) := i(23) xor i(26);
        oprbs(34) := i(22) xor i(25);
        oprbs(33) := i(21) xor i(24);
        oprbs(32) := i(20) xor i(23);
        oprbs(31) := i(19) xor i(22);
        oprbs(30) := i(18) xor i(21);
        oprbs(29) := i(17) xor i(20);
        oprbs(28) := i(16) xor i(19);
        oprbs(27) := i(15) xor i(18);
        oprbs(26) := i(14) xor i(17);
        oprbs(25) := i(13) xor i(16);
        oprbs(24) := i(12) xor i(15);
        oprbs(23) := i(11) xor i(14);
        oprbs(22) := i(10) xor i(13);
        oprbs(21) := i(9) xor i(12);
        oprbs(20) := i(8) xor i(11);
        oprbs(19) := i(7) xor i(10);
        oprbs(18) := i(6) xor i(9);
        oprbs(17) := i(5) xor i(8);
        oprbs(16) := i(4) xor i(7);
        oprbs(15) := i(3) xor i(6);
        oprbs(14) := i(2) xor i(5);
        oprbs(13) := i(1) xor i(4);
        oprbs(12) := i(0) xor i(3);
        oprbs(11) := i(2) xor i(27) xor i(30);
        oprbs(10) := i(1) xor i(26) xor i(29);
        oprbs(9) := i(0) xor i(25) xor i(28);
        oprbs(8) := i(24) xor i(30);
        oprbs(7) := i(23) xor i(29);
        oprbs(6) := i(22) xor i(28);
        oprbs(5) := i(21) xor i(27);
        oprbs(4) := i(20) xor i(26);
        oprbs(3) := i(19) xor i(25);
        oprbs(2) := i(18) xor i(24);
        oprbs(1) := i(17) xor i(23);
        oprbs(0) := i(16) xor i(22);
        return oprbs;
    end;

    ------------------------------------------------
    --    Parallel PRBS prbs23_40b. Bus Size 40
    --    X^23 + X^18 + 1
    ------------------------------------------------
    function prbs23_40b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(39) := i(17) xor i(22);
        oprbs(38) := i(16) xor i(21);
        oprbs(37) := i(15) xor i(20);
        oprbs(36) := i(14) xor i(19);
        oprbs(35) := i(13) xor i(18);
        oprbs(34) := i(12) xor i(17);
        oprbs(33) := i(11) xor i(16);
        oprbs(32) := i(10) xor i(15);
        oprbs(31) := i(9) xor i(14);
        oprbs(30) := i(8) xor i(13);
        oprbs(29) := i(7) xor i(12);
        oprbs(28) := i(6) xor i(11);
        oprbs(27) := i(5) xor i(10);
        oprbs(26) := i(4) xor i(9);
        oprbs(25) := i(3) xor i(8);
        oprbs(24) := i(2) xor i(7);
        oprbs(23) := i(1) xor i(6);
        oprbs(22) := i(0) xor i(5);
        oprbs(21) := i(4) xor i(17) xor i(22);
        oprbs(20) := i(3) xor i(16) xor i(21);
        oprbs(19) := i(2) xor i(15) xor i(20);
        oprbs(18) := i(1) xor i(14) xor i(19);
        oprbs(17) := i(0) xor i(13) xor i(18);
        oprbs(16) := i(12) xor i(22);
        oprbs(15) := i(11) xor i(21);
        oprbs(14) := i(10) xor i(20);
        oprbs(13) := i(9) xor i(19);
        oprbs(12) := i(8) xor i(18);
        oprbs(11) := i(7) xor i(17);
        oprbs(10) := i(6) xor i(16);
        oprbs(9) := i(5) xor i(15);
        oprbs(8) := i(4) xor i(14);
        oprbs(7) := i(3) xor i(13);
        oprbs(6) := i(2) xor i(12);
        oprbs(5) := i(1) xor i(11);
        oprbs(4) := i(0) xor i(10);
        oprbs(3) := i(9) xor i(17) xor i(22);
        oprbs(2) := i(8) xor i(16) xor i(21);
        oprbs(1) := i(7) xor i(15) xor i(20);
        oprbs(0) := i(6) xor i(14) xor i(19);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs20_40b. Bus Size 40
    --    X^20 + X^17 + 1
    ------------------------------------------------
    function prbs20_40b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(39) := i(16) xor i(19);
        oprbs(38) := i(15) xor i(18);
        oprbs(37) := i(14) xor i(17);
        oprbs(36) := i(13) xor i(16);
        oprbs(35) := i(12) xor i(15);
        oprbs(34) := i(11) xor i(14);
        oprbs(33) := i(10) xor i(13);
        oprbs(32) := i(9) xor i(12);
        oprbs(31) := i(8) xor i(11);
        oprbs(30) := i(7) xor i(10);
        oprbs(29) := i(6) xor i(9);
        oprbs(28) := i(5) xor i(8);
        oprbs(27) := i(4) xor i(7);
        oprbs(26) := i(3) xor i(6);
        oprbs(25) := i(2) xor i(5);
        oprbs(24) := i(1) xor i(4);
        oprbs(23) := i(0) xor i(3);
        oprbs(22) := i(2) xor i(16) xor i(19);
        oprbs(21) := i(1) xor i(15) xor i(18);
        oprbs(20) := i(0) xor i(14) xor i(17);
        oprbs(19) := i(13) xor i(19);
        oprbs(18) := i(12) xor i(18);
        oprbs(17) := i(11) xor i(17);
        oprbs(16) := i(10) xor i(16);
        oprbs(15) := i(9) xor i(15);
        oprbs(14) := i(8) xor i(14);
        oprbs(13) := i(7) xor i(13);
        oprbs(12) := i(6) xor i(12);
        oprbs(11) := i(5) xor i(11);
        oprbs(10) := i(4) xor i(10);
        oprbs(9) := i(3) xor i(9);
        oprbs(8) := i(2) xor i(8);
        oprbs(7) := i(1) xor i(7);
        oprbs(6) := i(0) xor i(6);
        oprbs(5) := i(5) xor i(16) xor i(19);
        oprbs(4) := i(4) xor i(15) xor i(18);
        oprbs(3) := i(3) xor i(14) xor i(17);
        oprbs(2) := i(2) xor i(13) xor i(16);
        oprbs(1) := i(1) xor i(12) xor i(15);
        oprbs(0) := i(0) xor i(11) xor i(14);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs15_40b. Bus Size 40
    --    X^15 + X^14 + 1
    ------------------------------------------------
    function prbs15_40b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(39) := i(13) xor i(14);
        oprbs(38) := i(12) xor i(13);
        oprbs(37) := i(11) xor i(12);
        oprbs(36) := i(10) xor i(11);
        oprbs(35) := i(9) xor i(10);
        oprbs(34) := i(8) xor i(9);
        oprbs(33) := i(7) xor i(8);
        oprbs(32) := i(6) xor i(7);
        oprbs(31) := i(5) xor i(6);
        oprbs(30) := i(4) xor i(5);
        oprbs(29) := i(3) xor i(4);
        oprbs(28) := i(2) xor i(3);
        oprbs(27) := i(1) xor i(2);
        oprbs(26) := i(0) xor i(1);
        oprbs(25) := i(0) xor i(13) xor i(14);
        oprbs(24) := i(12) xor i(14);
        oprbs(23) := i(11) xor i(13);
        oprbs(22) := i(10) xor i(12);
        oprbs(21) := i(9) xor i(11);
        oprbs(20) := i(8) xor i(10);
        oprbs(19) := i(7) xor i(9);
        oprbs(18) := i(6) xor i(8);
        oprbs(17) := i(5) xor i(7);
        oprbs(16) := i(4) xor i(6);
        oprbs(15) := i(3) xor i(5);
        oprbs(14) := i(2) xor i(4);
        oprbs(13) := i(1) xor i(3);
        oprbs(12) := i(0) xor i(2);
        oprbs(11) := i(1) xor i(13) xor i(14);
        oprbs(10) := i(0) xor i(12) xor i(13);
        oprbs(9) := i(11) xor i(12) xor i(13) xor i(14);
        oprbs(8) := i(10) xor i(11) xor i(12) xor i(13);
        oprbs(7) := i(9) xor i(10) xor i(11) xor i(12);
        oprbs(6) := i(8) xor i(9) xor i(10) xor i(11);
        oprbs(5) := i(7) xor i(8) xor i(9) xor i(10);
        oprbs(4) := i(6) xor i(7) xor i(8) xor i(9);
        oprbs(3) := i(5) xor i(6) xor i(7) xor i(8);
        oprbs(2) := i(4) xor i(5) xor i(6) xor i(7);
        oprbs(1) := i(3) xor i(4) xor i(5) xor i(6);
        oprbs(0) := i(2) xor i(3) xor i(4) xor i(5);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs10_40b. Bus Size 40
    --    X^10 + X^7 + 1
    ------------------------------------------------
    function prbs10_40b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(39) := i(6) xor i(9);
        oprbs(38) := i(5) xor i(8);
        oprbs(37) := i(4) xor i(7);
        oprbs(36) := i(3) xor i(6);
        oprbs(35) := i(2) xor i(5);
        oprbs(34) := i(1) xor i(4);
        oprbs(33) := i(0) xor i(3);
        oprbs(32) := i(2) xor i(6) xor i(9);
        oprbs(31) := i(1) xor i(5) xor i(8);
        oprbs(30) := i(0) xor i(4) xor i(7);
        oprbs(29) := i(3) xor i(9);
        oprbs(28) := i(2) xor i(8);
        oprbs(27) := i(1) xor i(7);
        oprbs(26) := i(0) xor i(6);
        oprbs(25) := i(5) xor i(6) xor i(9);
        oprbs(24) := i(4) xor i(5) xor i(8);
        oprbs(23) := i(3) xor i(4) xor i(7);
        oprbs(22) := i(2) xor i(3) xor i(6);
        oprbs(21) := i(1) xor i(2) xor i(5);
        oprbs(20) := i(0) xor i(1) xor i(4);
        oprbs(19) := i(0) xor i(3) xor i(6) xor i(9);
        oprbs(18) := i(2) xor i(5) xor i(6) xor i(8) xor i(9);
        oprbs(17) := i(1) xor i(4) xor i(5) xor i(7) xor i(8);
        oprbs(16) := i(0) xor i(3) xor i(4) xor i(6) xor i(7);
        oprbs(15) := i(2) xor i(3) xor i(5) xor i(9);
        oprbs(14) := i(1) xor i(2) xor i(4) xor i(8);
        oprbs(13) := i(0) xor i(1) xor i(3) xor i(7);
        oprbs(12) := i(0) xor i(2) xor i(9);
        oprbs(11) := i(1) xor i(6) xor i(8) xor i(9);
        oprbs(10) := i(0) xor i(5) xor i(7) xor i(8);
        oprbs(9) := i(4) xor i(7) xor i(9);
        oprbs(8) := i(3) xor i(6) xor i(8);
        oprbs(7) := i(2) xor i(5) xor i(7);
        oprbs(6) := i(1) xor i(4) xor i(6);
        oprbs(5) := i(0) xor i(3) xor i(5);
        oprbs(4) := i(2) xor i(4) xor i(6) xor i(9);
        oprbs(3) := i(1) xor i(3) xor i(5) xor i(8);
        oprbs(2) := i(0) xor i(2) xor i(4) xor i(7);
        oprbs(1) := i(1) xor i(3) xor i(9);
        oprbs(0) := i(0) xor i(2) xor i(8);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs7_40b. Bus Size 40
    --    X^7 + X^6 + 1
    ------------------------------------------------
    function prbs7_40b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(39) := i(5) xor i(6);
        oprbs(38) := i(4) xor i(5);
        oprbs(37) := i(3) xor i(4);
        oprbs(36) := i(2) xor i(3);
        oprbs(35) := i(1) xor i(2);
        oprbs(34) := i(0) xor i(1);
        oprbs(33) := i(0) xor i(5) xor i(6);
        oprbs(32) := i(4) xor i(6);
        oprbs(31) := i(3) xor i(5);
        oprbs(30) := i(2) xor i(4);
        oprbs(29) := i(1) xor i(3);
        oprbs(28) := i(0) xor i(2);
        oprbs(27) := i(1) xor i(5) xor i(6);
        oprbs(26) := i(0) xor i(4) xor i(5);
        oprbs(25) := i(3) xor i(4) xor i(5) xor i(6);
        oprbs(24) := i(2) xor i(3) xor i(4) xor i(5);
        oprbs(23) := i(1) xor i(2) xor i(3) xor i(4);
        oprbs(22) := i(0) xor i(1) xor i(2) xor i(3);
        oprbs(21) := i(0) xor i(1) xor i(2) xor i(5) xor i(6);
        oprbs(20) := i(0) xor i(1) xor i(4) xor i(6);
        oprbs(19) := i(0) xor i(3) xor i(6);
        oprbs(18) := i(2) xor i(6);
        oprbs(17) := i(1) xor i(5);
        oprbs(16) := i(0) xor i(4);
        oprbs(15) := i(3) xor i(5) xor i(6);
        oprbs(14) := i(2) xor i(4) xor i(5);
        oprbs(13) := i(1) xor i(3) xor i(4);
        oprbs(12) := i(0) xor i(2) xor i(3);
        oprbs(11) := i(1) xor i(2) xor i(5) xor i(6);
        oprbs(10) := i(0) xor i(1) xor i(4) xor i(5);
        oprbs(9) := i(0) xor i(3) xor i(4) xor i(5) xor i(6);
        oprbs(8) := i(2) xor i(3) xor i(4) xor i(6);
        oprbs(7) := i(1) xor i(2) xor i(3) xor i(5);
        oprbs(6) := i(0) xor i(1) xor i(2) xor i(4);
        oprbs(5) := i(0) xor i(1) xor i(3) xor i(5) xor i(6);
        oprbs(4) := i(0) xor i(2) xor i(4) xor i(6);
        oprbs(3) := i(1) xor i(3) xor i(6);
        oprbs(2) := i(0) xor i(2) xor i(5);
        oprbs(1) := i(1) xor i(4) xor i(5) xor i(6);
        oprbs(0) := i(0) xor i(3) xor i(4) xor i(5);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs5_40b. Bus Size 40
    --    X^5 + X^3 + 1
    ------------------------------------------------
    function prbs5_40b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(39) := i(2) xor i(4);
        oprbs(38) := i(1) xor i(3);
        oprbs(37) := i(0) xor i(2);
        oprbs(36) := i(1) xor i(2) xor i(4);
        oprbs(35) := i(0) xor i(1) xor i(3);
        oprbs(34) := i(0) xor i(4);
        oprbs(33) := i(2) xor i(3) xor i(4);
        oprbs(32) := i(1) xor i(2) xor i(3);
        oprbs(31) := i(0) xor i(1) xor i(2);
        oprbs(30) := i(0) xor i(1) xor i(2) xor i(4);
        oprbs(29) := i(0) xor i(1) xor i(2) xor i(3) xor i(4);
        oprbs(28) := i(0) xor i(1) xor i(3) xor i(4);
        oprbs(27) := i(0) xor i(3) xor i(4);
        oprbs(26) := i(3) xor i(4);
        oprbs(25) := i(2) xor i(3);
        oprbs(24) := i(1) xor i(2);
        oprbs(23) := i(0) xor i(1);
        oprbs(22) := i(0) xor i(2) xor i(4);
        oprbs(21) := i(1) xor i(2) xor i(3) xor i(4);
        oprbs(20) := i(0) xor i(1) xor i(2) xor i(3);
        oprbs(19) := i(0) xor i(1) xor i(4);
        oprbs(18) := i(0) xor i(2) xor i(3) xor i(4);
        oprbs(17) := i(1) xor i(3) xor i(4);
        oprbs(16) := i(0) xor i(2) xor i(3);
        oprbs(15) := i(1) xor i(4);
        oprbs(14) := i(0) xor i(3);
        oprbs(13) := i(4);
        oprbs(12) := i(3);
        oprbs(11) := i(2);
        oprbs(10) := i(1);
        oprbs(9) := i(0);
        oprbs(8) := i(2) xor i(4);
        oprbs(7) := i(1) xor i(3);
        oprbs(6) := i(0) xor i(2);
        oprbs(5) := i(1) xor i(2) xor i(4);
        oprbs(4) := i(0) xor i(1) xor i(3);
        oprbs(3) := i(0) xor i(4);
        oprbs(2) := i(2) xor i(3) xor i(4);
        oprbs(1) := i(1) xor i(2) xor i(3);
        oprbs(0) := i(0) xor i(1) xor i(2);
        return oprbs;
    end;

    ------------------------------------------------
    --    Parallel PRBS prbs31_36b. Bus Size 36
    --    X^31 + X^28 + 1
    ------------------------------------------------
    function prbs31_36b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(35) := i(27) xor i(30);
        oprbs(34) := i(26) xor i(29);
        oprbs(33) := i(25) xor i(28);
        oprbs(32) := i(24) xor i(27);
        oprbs(31) := i(23) xor i(26);
        oprbs(30) := i(22) xor i(25);
        oprbs(29) := i(21) xor i(24);
        oprbs(28) := i(20) xor i(23);
        oprbs(27) := i(19) xor i(22);
        oprbs(26) := i(18) xor i(21);
        oprbs(25) := i(17) xor i(20);
        oprbs(24) := i(16) xor i(19);
        oprbs(23) := i(15) xor i(18);
        oprbs(22) := i(14) xor i(17);
        oprbs(21) := i(13) xor i(16);
        oprbs(20) := i(12) xor i(15);
        oprbs(19) := i(11) xor i(14);
        oprbs(18) := i(10) xor i(13);
        oprbs(17) := i(9) xor i(12);
        oprbs(16) := i(8) xor i(11);
        oprbs(15) := i(7) xor i(10);
        oprbs(14) := i(6) xor i(9);
        oprbs(13) := i(5) xor i(8);
        oprbs(12) := i(4) xor i(7);
        oprbs(11) := i(3) xor i(6);
        oprbs(10) := i(2) xor i(5);
        oprbs(9) := i(1) xor i(4);
        oprbs(8) := i(0) xor i(3);
        oprbs(7) := i(2) xor i(27) xor i(30);
        oprbs(6) := i(1) xor i(26) xor i(29);
        oprbs(5) := i(0) xor i(25) xor i(28);
        oprbs(4) := i(24) xor i(30);
        oprbs(3) := i(23) xor i(29);
        oprbs(2) := i(22) xor i(28);
        oprbs(1) := i(21) xor i(27);
        oprbs(0) := i(20) xor i(26);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs23_36b. Bus Size 36
    --    X^23 + X^18 + 1
    ------------------------------------------------
    function prbs23_36b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(35) := i(17) xor i(22);
        oprbs(34) := i(16) xor i(21);
        oprbs(33) := i(15) xor i(20);
        oprbs(32) := i(14) xor i(19);
        oprbs(31) := i(13) xor i(18);
        oprbs(30) := i(12) xor i(17);
        oprbs(29) := i(11) xor i(16);
        oprbs(28) := i(10) xor i(15);
        oprbs(27) := i(9) xor i(14);
        oprbs(26) := i(8) xor i(13);
        oprbs(25) := i(7) xor i(12);
        oprbs(24) := i(6) xor i(11);
        oprbs(23) := i(5) xor i(10);
        oprbs(22) := i(4) xor i(9);
        oprbs(21) := i(3) xor i(8);
        oprbs(20) := i(2) xor i(7);
        oprbs(19) := i(1) xor i(6);
        oprbs(18) := i(0) xor i(5);
        oprbs(17) := i(4) xor i(17) xor i(22);
        oprbs(16) := i(3) xor i(16) xor i(21);
        oprbs(15) := i(2) xor i(15) xor i(20);
        oprbs(14) := i(1) xor i(14) xor i(19);
        oprbs(13) := i(0) xor i(13) xor i(18);
        oprbs(12) := i(12) xor i(22);
        oprbs(11) := i(11) xor i(21);
        oprbs(10) := i(10) xor i(20);
        oprbs(9) := i(9) xor i(19);
        oprbs(8) := i(8) xor i(18);
        oprbs(7) := i(7) xor i(17);
        oprbs(6) := i(6) xor i(16);
        oprbs(5) := i(5) xor i(15);
        oprbs(4) := i(4) xor i(14);
        oprbs(3) := i(3) xor i(13);
        oprbs(2) := i(2) xor i(12);
        oprbs(1) := i(1) xor i(11);
        oprbs(0) := i(0) xor i(10);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs20_36b. Bus Size 36
    --    X^20 + X^17 + 1
    ------------------------------------------------
    function prbs20_36b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(35) := i(16) xor i(19);
        oprbs(34) := i(15) xor i(18);
        oprbs(33) := i(14) xor i(17);
        oprbs(32) := i(13) xor i(16);
        oprbs(31) := i(12) xor i(15);
        oprbs(30) := i(11) xor i(14);
        oprbs(29) := i(10) xor i(13);
        oprbs(28) := i(9) xor i(12);
        oprbs(27) := i(8) xor i(11);
        oprbs(26) := i(7) xor i(10);
        oprbs(25) := i(6) xor i(9);
        oprbs(24) := i(5) xor i(8);
        oprbs(23) := i(4) xor i(7);
        oprbs(22) := i(3) xor i(6);
        oprbs(21) := i(2) xor i(5);
        oprbs(20) := i(1) xor i(4);
        oprbs(19) := i(0) xor i(3);
        oprbs(18) := i(2) xor i(16) xor i(19);
        oprbs(17) := i(1) xor i(15) xor i(18);
        oprbs(16) := i(0) xor i(14) xor i(17);
        oprbs(15) := i(13) xor i(19);
        oprbs(14) := i(12) xor i(18);
        oprbs(13) := i(11) xor i(17);
        oprbs(12) := i(10) xor i(16);
        oprbs(11) := i(9) xor i(15);
        oprbs(10) := i(8) xor i(14);
        oprbs(9) := i(7) xor i(13);
        oprbs(8) := i(6) xor i(12);
        oprbs(7) := i(5) xor i(11);
        oprbs(6) := i(4) xor i(10);
        oprbs(5) := i(3) xor i(9);
        oprbs(4) := i(2) xor i(8);
        oprbs(3) := i(1) xor i(7);
        oprbs(2) := i(0) xor i(6);
        oprbs(1) := i(5) xor i(16) xor i(19);
        oprbs(0) := i(4) xor i(15) xor i(18);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs15_36b. Bus Size 36
    --    X^15 + X^14 + 1
    ------------------------------------------------
    function prbs15_36b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(35) := i(13) xor i(14);
        oprbs(34) := i(12) xor i(13);
        oprbs(33) := i(11) xor i(12);
        oprbs(32) := i(10) xor i(11);
        oprbs(31) := i(9) xor i(10);
        oprbs(30) := i(8) xor i(9);
        oprbs(29) := i(7) xor i(8);
        oprbs(28) := i(6) xor i(7);
        oprbs(27) := i(5) xor i(6);
        oprbs(26) := i(4) xor i(5);
        oprbs(25) := i(3) xor i(4);
        oprbs(24) := i(2) xor i(3);
        oprbs(23) := i(1) xor i(2);
        oprbs(22) := i(0) xor i(1);
        oprbs(21) := i(0) xor i(13) xor i(14);
        oprbs(20) := i(12) xor i(14);
        oprbs(19) := i(11) xor i(13);
        oprbs(18) := i(10) xor i(12);
        oprbs(17) := i(9) xor i(11);
        oprbs(16) := i(8) xor i(10);
        oprbs(15) := i(7) xor i(9);
        oprbs(14) := i(6) xor i(8);
        oprbs(13) := i(5) xor i(7);
        oprbs(12) := i(4) xor i(6);
        oprbs(11) := i(3) xor i(5);
        oprbs(10) := i(2) xor i(4);
        oprbs(9) := i(1) xor i(3);
        oprbs(8) := i(0) xor i(2);
        oprbs(7) := i(1) xor i(13) xor i(14);
        oprbs(6) := i(0) xor i(12) xor i(13);
        oprbs(5) := i(11) xor i(12) xor i(13) xor i(14);
        oprbs(4) := i(10) xor i(11) xor i(12) xor i(13);
        oprbs(3) := i(9) xor i(10) xor i(11) xor i(12);
        oprbs(2) := i(8) xor i(9) xor i(10) xor i(11);
        oprbs(1) := i(7) xor i(8) xor i(9) xor i(10);
        oprbs(0) := i(6) xor i(7) xor i(8) xor i(9);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs10_36b. Bus Size 36
    --    X^10 + X^7 + 1
    ------------------------------------------------
    function prbs10_36b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(35) := i(6) xor i(9);
        oprbs(34) := i(5) xor i(8);
        oprbs(33) := i(4) xor i(7);
        oprbs(32) := i(3) xor i(6);
        oprbs(31) := i(2) xor i(5);
        oprbs(30) := i(1) xor i(4);
        oprbs(29) := i(0) xor i(3);
        oprbs(28) := i(2) xor i(6) xor i(9);
        oprbs(27) := i(1) xor i(5) xor i(8);
        oprbs(26) := i(0) xor i(4) xor i(7);
        oprbs(25) := i(3) xor i(9);
        oprbs(24) := i(2) xor i(8);
        oprbs(23) := i(1) xor i(7);
        oprbs(22) := i(0) xor i(6);
        oprbs(21) := i(5) xor i(6) xor i(9);
        oprbs(20) := i(4) xor i(5) xor i(8);
        oprbs(19) := i(3) xor i(4) xor i(7);
        oprbs(18) := i(2) xor i(3) xor i(6);
        oprbs(17) := i(1) xor i(2) xor i(5);
        oprbs(16) := i(0) xor i(1) xor i(4);
        oprbs(15) := i(0) xor i(3) xor i(6) xor i(9);
        oprbs(14) := i(2) xor i(5) xor i(6) xor i(8) xor i(9);
        oprbs(13) := i(1) xor i(4) xor i(5) xor i(7) xor i(8);
        oprbs(12) := i(0) xor i(3) xor i(4) xor i(6) xor i(7);
        oprbs(11) := i(2) xor i(3) xor i(5) xor i(9);
        oprbs(10) := i(1) xor i(2) xor i(4) xor i(8);
        oprbs(9) := i(0) xor i(1) xor i(3) xor i(7);
        oprbs(8) := i(0) xor i(2) xor i(9);
        oprbs(7) := i(1) xor i(6) xor i(8) xor i(9);
        oprbs(6) := i(0) xor i(5) xor i(7) xor i(8);
        oprbs(5) := i(4) xor i(7) xor i(9);
        oprbs(4) := i(3) xor i(6) xor i(8);
        oprbs(3) := i(2) xor i(5) xor i(7);
        oprbs(2) := i(1) xor i(4) xor i(6);
        oprbs(1) := i(0) xor i(3) xor i(5);
        oprbs(0) := i(2) xor i(4) xor i(6) xor i(9);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs7_36b. Bus Size 36
    --    X^7 + X^6 + 1
    ------------------------------------------------
    function prbs7_36b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(35) := i(5) xor i(6);
        oprbs(34) := i(4) xor i(5);
        oprbs(33) := i(3) xor i(4);
        oprbs(32) := i(2) xor i(3);
        oprbs(31) := i(1) xor i(2);
        oprbs(30) := i(0) xor i(1);
        oprbs(29) := i(0) xor i(5) xor i(6);
        oprbs(28) := i(4) xor i(6);
        oprbs(27) := i(3) xor i(5);
        oprbs(26) := i(2) xor i(4);
        oprbs(25) := i(1) xor i(3);
        oprbs(24) := i(0) xor i(2);
        oprbs(23) := i(1) xor i(5) xor i(6);
        oprbs(22) := i(0) xor i(4) xor i(5);
        oprbs(21) := i(3) xor i(4) xor i(5) xor i(6);
        oprbs(20) := i(2) xor i(3) xor i(4) xor i(5);
        oprbs(19) := i(1) xor i(2) xor i(3) xor i(4);
        oprbs(18) := i(0) xor i(1) xor i(2) xor i(3);
        oprbs(17) := i(0) xor i(1) xor i(2) xor i(5) xor i(6);
        oprbs(16) := i(0) xor i(1) xor i(4) xor i(6);
        oprbs(15) := i(0) xor i(3) xor i(6);
        oprbs(14) := i(2) xor i(6);
        oprbs(13) := i(1) xor i(5);
        oprbs(12) := i(0) xor i(4);
        oprbs(11) := i(3) xor i(5) xor i(6);
        oprbs(10) := i(2) xor i(4) xor i(5);
        oprbs(9) := i(1) xor i(3) xor i(4);
        oprbs(8) := i(0) xor i(2) xor i(3);
        oprbs(7) := i(1) xor i(2) xor i(5) xor i(6);
        oprbs(6) := i(0) xor i(1) xor i(4) xor i(5);
        oprbs(5) := i(0) xor i(3) xor i(4) xor i(5) xor i(6);
        oprbs(4) := i(2) xor i(3) xor i(4) xor i(6);
        oprbs(3) := i(1) xor i(2) xor i(3) xor i(5);
        oprbs(2) := i(0) xor i(1) xor i(2) xor i(4);
        oprbs(1) := i(0) xor i(1) xor i(3) xor i(5) xor i(6);
        oprbs(0) := i(0) xor i(2) xor i(4) xor i(6);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs5_36b. Bus Size 36
    --    X^5 + X^3 + 1
    ------------------------------------------------
    function prbs5_36b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(35) := i(2) xor i(4);
        oprbs(34) := i(1) xor i(3);
        oprbs(33) := i(0) xor i(2);
        oprbs(32) := i(1) xor i(2) xor i(4);
        oprbs(31) := i(0) xor i(1) xor i(3);
        oprbs(30) := i(0) xor i(4);
        oprbs(29) := i(2) xor i(3) xor i(4);
        oprbs(28) := i(1) xor i(2) xor i(3);
        oprbs(27) := i(0) xor i(1) xor i(2);
        oprbs(26) := i(0) xor i(1) xor i(2) xor i(4);
        oprbs(25) := i(0) xor i(1) xor i(2) xor i(3) xor i(4);
        oprbs(24) := i(0) xor i(1) xor i(3) xor i(4);
        oprbs(23) := i(0) xor i(3) xor i(4);
        oprbs(22) := i(3) xor i(4);
        oprbs(21) := i(2) xor i(3);
        oprbs(20) := i(1) xor i(2);
        oprbs(19) := i(0) xor i(1);
        oprbs(18) := i(0) xor i(2) xor i(4);
        oprbs(17) := i(1) xor i(2) xor i(3) xor i(4);
        oprbs(16) := i(0) xor i(1) xor i(2) xor i(3);
        oprbs(15) := i(0) xor i(1) xor i(4);
        oprbs(14) := i(0) xor i(2) xor i(3) xor i(4);
        oprbs(13) := i(1) xor i(3) xor i(4);
        oprbs(12) := i(0) xor i(2) xor i(3);
        oprbs(11) := i(1) xor i(4);
        oprbs(10) := i(0) xor i(3);
        oprbs(9) := i(4);
        oprbs(8) := i(3);
        oprbs(7) := i(2);
        oprbs(6) := i(1);
        oprbs(5) := i(0);
        oprbs(4) := i(2) xor i(4);
        oprbs(3) := i(1) xor i(3);
        oprbs(2) := i(0) xor i(2);
        oprbs(1) := i(1) xor i(2) xor i(4);
        oprbs(0) := i(0) xor i(1) xor i(3);
        return oprbs;
    end;

    ------------------------------------------------
    --    Parallel PRBS prbs20_20b. Bus Size 20
    --    X^20 + X^17 + 1
    ------------------------------------------------
    function prbs20_20b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(19) := i(16) xor i(19);
        oprbs(18) := i(15) xor i(18);
        oprbs(17) := i(14) xor i(17);
        oprbs(16) := i(13) xor i(16);
        oprbs(15) := i(12) xor i(15);
        oprbs(14) := i(11) xor i(14);
        oprbs(13) := i(10) xor i(13);
        oprbs(12) := i(9) xor i(12);
        oprbs(11) := i(8) xor i(11);
        oprbs(10) := i(7) xor i(10);
        oprbs(9) := i(6) xor i(9);
        oprbs(8) := i(5) xor i(8);
        oprbs(7) := i(4) xor i(7);
        oprbs(6) := i(3) xor i(6);
        oprbs(5) := i(2) xor i(5);
        oprbs(4) := i(1) xor i(4);
        oprbs(3) := i(0) xor i(3);
        oprbs(2) := i(2) xor i(16) xor i(19);
        oprbs(1) := i(1) xor i(15) xor i(18);
        oprbs(0) := i(0) xor i(14) xor i(17);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs15_20b. Bus Size 20
    --    X^15 + X^14 + 1
    ------------------------------------------------
    function prbs15_20b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(19) := i(13) xor i(14);
        oprbs(18) := i(12) xor i(13);
        oprbs(17) := i(11) xor i(12);
        oprbs(16) := i(10) xor i(11);
        oprbs(15) := i(9) xor i(10);
        oprbs(14) := i(8) xor i(9);
        oprbs(13) := i(7) xor i(8);
        oprbs(12) := i(6) xor i(7);
        oprbs(11) := i(5) xor i(6);
        oprbs(10) := i(4) xor i(5);
        oprbs(9) := i(3) xor i(4);
        oprbs(8) := i(2) xor i(3);
        oprbs(7) := i(1) xor i(2);
        oprbs(6) := i(0) xor i(1);
        oprbs(5) := i(0) xor i(13) xor i(14);
        oprbs(4) := i(12) xor i(14);
        oprbs(3) := i(11) xor i(13);
        oprbs(2) := i(10) xor i(12);
        oprbs(1) := i(9) xor i(11);
        oprbs(0) := i(8) xor i(10);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs10_20b. Bus Size 20
    --    X^10 + X^7 + 1
    ------------------------------------------------
    function prbs10_20b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(19) := i(6) xor i(9);
        oprbs(18) := i(5) xor i(8);
        oprbs(17) := i(4) xor i(7);
        oprbs(16) := i(3) xor i(6);
        oprbs(15) := i(2) xor i(5);
        oprbs(14) := i(1) xor i(4);
        oprbs(13) := i(0) xor i(3);
        oprbs(12) := i(2) xor i(6) xor i(9);
        oprbs(11) := i(1) xor i(5) xor i(8);
        oprbs(10) := i(0) xor i(4) xor i(7);
        oprbs(9) := i(3) xor i(9);
        oprbs(8) := i(2) xor i(8);
        oprbs(7) := i(1) xor i(7);
        oprbs(6) := i(0) xor i(6);
        oprbs(5) := i(5) xor i(6) xor i(9);
        oprbs(4) := i(4) xor i(5) xor i(8);
        oprbs(3) := i(3) xor i(4) xor i(7);
        oprbs(2) := i(2) xor i(3) xor i(6);
        oprbs(1) := i(1) xor i(2) xor i(5);
        oprbs(0) := i(0) xor i(1) xor i(4);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs7_20b. Bus Size 20
    --    X^7 + X^6 + 1
    ------------------------------------------------
    function prbs7_20b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(19) := i(5) xor i(6);
        oprbs(18) := i(4) xor i(5);
        oprbs(17) := i(3) xor i(4);
        oprbs(16) := i(2) xor i(3);
        oprbs(15) := i(1) xor i(2);
        oprbs(14) := i(0) xor i(1);
        oprbs(13) := i(0) xor i(5) xor i(6);
        oprbs(12) := i(4) xor i(6);
        oprbs(11) := i(3) xor i(5);
        oprbs(10) := i(2) xor i(4);
        oprbs(9) := i(1) xor i(3);
        oprbs(8) := i(0) xor i(2);
        oprbs(7) := i(1) xor i(5) xor i(6);
        oprbs(6) := i(0) xor i(4) xor i(5);
        oprbs(5) := i(3) xor i(4) xor i(5) xor i(6);
        oprbs(4) := i(2) xor i(3) xor i(4) xor i(5);
        oprbs(3) := i(1) xor i(2) xor i(3) xor i(4);
        oprbs(2) := i(0) xor i(1) xor i(2) xor i(3);
        oprbs(1) := i(0) xor i(1) xor i(2) xor i(5) xor i(6);
        oprbs(0) := i(0) xor i(1) xor i(4) xor i(6);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs5_20b. Bus Size 20
    --    X^5 + X^3 + 1
    ------------------------------------------------
    function prbs5_20b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(19) := i(2) xor i(4);
        oprbs(18) := i(1) xor i(3);
        oprbs(17) := i(0) xor i(2);
        oprbs(16) := i(1) xor i(2) xor i(4);
        oprbs(15) := i(0) xor i(1) xor i(3);
        oprbs(14) := i(0) xor i(4);
        oprbs(13) := i(2) xor i(3) xor i(4);
        oprbs(12) := i(1) xor i(2) xor i(3);
        oprbs(11) := i(0) xor i(1) xor i(2);
        oprbs(10) := i(0) xor i(1) xor i(2) xor i(4);
        oprbs(9) := i(0) xor i(1) xor i(2) xor i(3) xor i(4);
        oprbs(8) := i(0) xor i(1) xor i(3) xor i(4);
        oprbs(7) := i(0) xor i(3) xor i(4);
        oprbs(6) := i(3) xor i(4);
        oprbs(5) := i(2) xor i(3);
        oprbs(4) := i(1) xor i(2);
        oprbs(3) := i(0) xor i(1);
        oprbs(2) := i(0) xor i(2) xor i(4);
        oprbs(1) := i(1) xor i(2) xor i(3) xor i(4);
        oprbs(0) := i(0) xor i(1) xor i(2) xor i(3);
        return oprbs;
    end;

    ------------------------------------------------
    --    Parallel PRBS prbs10_10b. Bus Size 10
    --    X^10 + X^7 + 1
    ------------------------------------------------
    function prbs10_10b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(9) := i(6) xor i(9);
        oprbs(8) := i(5) xor i(8);
        oprbs(7) := i(4) xor i(7);
        oprbs(6) := i(3) xor i(6);
        oprbs(5) := i(2) xor i(5);
        oprbs(4) := i(1) xor i(4);
        oprbs(3) := i(0) xor i(3);
        oprbs(2) := i(2) xor i(6) xor i(9);
        oprbs(1) := i(1) xor i(5) xor i(8);
        oprbs(0) := i(0) xor i(4) xor i(7);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs7_10b. Bus Size 10
    --    X^7 + X^6 + 1
    ------------------------------------------------
    function prbs7_10b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(9) := i(5) xor i(6);
        oprbs(8) := i(4) xor i(5);
        oprbs(7) := i(3) xor i(4);
        oprbs(6) := i(2) xor i(3);
        oprbs(5) := i(1) xor i(2);
        oprbs(4) := i(0) xor i(1);
        oprbs(3) := i(0) xor i(5) xor i(6);
        oprbs(2) := i(4) xor i(6);
        oprbs(1) := i(3) xor i(5);
        oprbs(0) := i(2) xor i(4);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs5_10b. Bus Size 10
    --    X^5 + X^3 + 1
    ------------------------------------------------
    function prbs5_10b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(9) := i(2) xor i(4);
        oprbs(8) := i(1) xor i(3);
        oprbs(7) := i(0) xor i(2);
        oprbs(6) := i(1) xor i(2) xor i(4);
        oprbs(5) := i(0) xor i(1) xor i(3);
        oprbs(4) := i(0) xor i(4);
        oprbs(3) := i(2) xor i(3) xor i(4);
        oprbs(2) := i(1) xor i(2) xor i(3);
        oprbs(1) := i(0) xor i(1) xor i(2);
        oprbs(0) := i(0) xor i(1) xor i(2) xor i(4);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs31_32b. Bus Size 32
    --    X^31 + X^28 + 1
    ------------------------------------------------
    function prbs31_32b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(31) := i(27) xor i(30);
        oprbs(30) := i(26) xor i(29);
        oprbs(29) := i(25) xor i(28);
        oprbs(28) := i(24) xor i(27);
        oprbs(27) := i(23) xor i(26);
        oprbs(26) := i(22) xor i(25);
        oprbs(25) := i(21) xor i(24);
        oprbs(24) := i(20) xor i(23);
        oprbs(23) := i(19) xor i(22);
        oprbs(22) := i(18) xor i(21);
        oprbs(21) := i(17) xor i(20);
        oprbs(20) := i(16) xor i(19);
        oprbs(19) := i(15) xor i(18);
        oprbs(18) := i(14) xor i(17);
        oprbs(17) := i(13) xor i(16);
        oprbs(16) := i(12) xor i(15);
        oprbs(15) := i(11) xor i(14);
        oprbs(14) := i(10) xor i(13);
        oprbs(13) := i(9) xor i(12);
        oprbs(12) := i(8) xor i(11);
        oprbs(11) := i(7) xor i(10);
        oprbs(10) := i(6) xor i(9);
        oprbs(9) := i(5) xor i(8);
        oprbs(8) := i(4) xor i(7);
        oprbs(7) := i(3) xor i(6);
        oprbs(6) := i(2) xor i(5);
        oprbs(5) := i(1) xor i(4);
        oprbs(4) := i(0) xor i(3);
        oprbs(3) := i(2) xor i(27) xor i(30);
        oprbs(2) := i(1) xor i(26) xor i(29);
        oprbs(1) := i(0) xor i(25) xor i(28);
        oprbs(0) := i(24) xor i(30);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs23_32b. Bus Size 32
    --    X^23 + X^18 + 1
    ------------------------------------------------
    function prbs23_32b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(31) := i(17) xor i(22);
        oprbs(30) := i(16) xor i(21);
        oprbs(29) := i(15) xor i(20);
        oprbs(28) := i(14) xor i(19);
        oprbs(27) := i(13) xor i(18);
        oprbs(26) := i(12) xor i(17);
        oprbs(25) := i(11) xor i(16);
        oprbs(24) := i(10) xor i(15);
        oprbs(23) := i(9) xor i(14);
        oprbs(22) := i(8) xor i(13);
        oprbs(21) := i(7) xor i(12);
        oprbs(20) := i(6) xor i(11);
        oprbs(19) := i(5) xor i(10);
        oprbs(18) := i(4) xor i(9);
        oprbs(17) := i(3) xor i(8);
        oprbs(16) := i(2) xor i(7);
        oprbs(15) := i(1) xor i(6);
        oprbs(14) := i(0) xor i(5);
        oprbs(13) := i(4) xor i(17) xor i(22);
        oprbs(12) := i(3) xor i(16) xor i(21);
        oprbs(11) := i(2) xor i(15) xor i(20);
        oprbs(10) := i(1) xor i(14) xor i(19);
        oprbs(9) := i(0) xor i(13) xor i(18);
        oprbs(8) := i(12) xor i(22);
        oprbs(7) := i(11) xor i(21);
        oprbs(6) := i(10) xor i(20);
        oprbs(5) := i(9) xor i(19);
        oprbs(4) := i(8) xor i(18);
        oprbs(3) := i(7) xor i(17);
        oprbs(2) := i(6) xor i(16);
        oprbs(1) := i(5) xor i(15);
        oprbs(0) := i(4) xor i(14);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs20_32b. Bus Size 32
    --    X^20 + X^17 + 1
    ------------------------------------------------
    function prbs20_32b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(31) := i(16) xor i(19);
        oprbs(30) := i(15) xor i(18);
        oprbs(29) := i(14) xor i(17);
        oprbs(28) := i(13) xor i(16);
        oprbs(27) := i(12) xor i(15);
        oprbs(26) := i(11) xor i(14);
        oprbs(25) := i(10) xor i(13);
        oprbs(24) := i(9) xor i(12);
        oprbs(23) := i(8) xor i(11);
        oprbs(22) := i(7) xor i(10);
        oprbs(21) := i(6) xor i(9);
        oprbs(20) := i(5) xor i(8);
        oprbs(19) := i(4) xor i(7);
        oprbs(18) := i(3) xor i(6);
        oprbs(17) := i(2) xor i(5);
        oprbs(16) := i(1) xor i(4);
        oprbs(15) := i(0) xor i(3);
        oprbs(14) := i(2) xor i(16) xor i(19);
        oprbs(13) := i(1) xor i(15) xor i(18);
        oprbs(12) := i(0) xor i(14) xor i(17);
        oprbs(11) := i(13) xor i(19);
        oprbs(10) := i(12) xor i(18);
        oprbs(9) := i(11) xor i(17);
        oprbs(8) := i(10) xor i(16);
        oprbs(7) := i(9) xor i(15);
        oprbs(6) := i(8) xor i(14);
        oprbs(5) := i(7) xor i(13);
        oprbs(4) := i(6) xor i(12);
        oprbs(3) := i(5) xor i(11);
        oprbs(2) := i(4) xor i(10);
        oprbs(1) := i(3) xor i(9);
        oprbs(0) := i(2) xor i(8);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs15_32b. Bus Size 32
    --    X^15 + X^14 + 1
    ------------------------------------------------
    function prbs15_32b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(31) := i(13) xor i(14);
        oprbs(30) := i(12) xor i(13);
        oprbs(29) := i(11) xor i(12);
        oprbs(28) := i(10) xor i(11);
        oprbs(27) := i(9) xor i(10);
        oprbs(26) := i(8) xor i(9);
        oprbs(25) := i(7) xor i(8);
        oprbs(24) := i(6) xor i(7);
        oprbs(23) := i(5) xor i(6);
        oprbs(22) := i(4) xor i(5);
        oprbs(21) := i(3) xor i(4);
        oprbs(20) := i(2) xor i(3);
        oprbs(19) := i(1) xor i(2);
        oprbs(18) := i(0) xor i(1);
        oprbs(17) := i(0) xor i(13) xor i(14);
        oprbs(16) := i(12) xor i(14);
        oprbs(15) := i(11) xor i(13);
        oprbs(14) := i(10) xor i(12);
        oprbs(13) := i(9) xor i(11);
        oprbs(12) := i(8) xor i(10);
        oprbs(11) := i(7) xor i(9);
        oprbs(10) := i(6) xor i(8);
        oprbs(9) := i(5) xor i(7);
        oprbs(8) := i(4) xor i(6);
        oprbs(7) := i(3) xor i(5);
        oprbs(6) := i(2) xor i(4);
        oprbs(5) := i(1) xor i(3);
        oprbs(4) := i(0) xor i(2);
        oprbs(3) := i(1) xor i(13) xor i(14);
        oprbs(2) := i(0) xor i(12) xor i(13);
        oprbs(1) := i(11) xor i(12) xor i(13) xor i(14);
        oprbs(0) := i(10) xor i(11) xor i(12) xor i(13);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs10_32b. Bus Size 32
    --    X^10 + X^7 + 1
    ------------------------------------------------
    function prbs10_32b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(31) := i(6) xor i(9);
        oprbs(30) := i(5) xor i(8);
        oprbs(29) := i(4) xor i(7);
        oprbs(28) := i(3) xor i(6);
        oprbs(27) := i(2) xor i(5);
        oprbs(26) := i(1) xor i(4);
        oprbs(25) := i(0) xor i(3);
        oprbs(24) := i(2) xor i(6) xor i(9);
        oprbs(23) := i(1) xor i(5) xor i(8);
        oprbs(22) := i(0) xor i(4) xor i(7);
        oprbs(21) := i(3) xor i(9);
        oprbs(20) := i(2) xor i(8);
        oprbs(19) := i(1) xor i(7);
        oprbs(18) := i(0) xor i(6);
        oprbs(17) := i(5) xor i(6) xor i(9);
        oprbs(16) := i(4) xor i(5) xor i(8);
        oprbs(15) := i(3) xor i(4) xor i(7);
        oprbs(14) := i(2) xor i(3) xor i(6);
        oprbs(13) := i(1) xor i(2) xor i(5);
        oprbs(12) := i(0) xor i(1) xor i(4);
        oprbs(11) := i(0) xor i(3) xor i(6) xor i(9);
        oprbs(10) := i(2) xor i(5) xor i(6) xor i(8) xor i(9);
        oprbs(9) := i(1) xor i(4) xor i(5) xor i(7) xor i(8);
        oprbs(8) := i(0) xor i(3) xor i(4) xor i(6) xor i(7);
        oprbs(7) := i(2) xor i(3) xor i(5) xor i(9);
        oprbs(6) := i(1) xor i(2) xor i(4) xor i(8);
        oprbs(5) := i(0) xor i(1) xor i(3) xor i(7);
        oprbs(4) := i(0) xor i(2) xor i(9);
        oprbs(3) := i(1) xor i(6) xor i(8) xor i(9);
        oprbs(2) := i(0) xor i(5) xor i(7) xor i(8);
        oprbs(1) := i(4) xor i(7) xor i(9);
        oprbs(0) := i(3) xor i(6) xor i(8);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs7_32b. Bus Size 32
    --    X^7 + X^6 + 1
    ------------------------------------------------
    function prbs7_32b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(31) := i(5) xor i(6);
        oprbs(30) := i(4) xor i(5);
        oprbs(29) := i(3) xor i(4);
        oprbs(28) := i(2) xor i(3);
        oprbs(27) := i(1) xor i(2);
        oprbs(26) := i(0) xor i(1);
        oprbs(25) := i(0) xor i(5) xor i(6);
        oprbs(24) := i(4) xor i(6);
        oprbs(23) := i(3) xor i(5);
        oprbs(22) := i(2) xor i(4);
        oprbs(21) := i(1) xor i(3);
        oprbs(20) := i(0) xor i(2);
        oprbs(19) := i(1) xor i(5) xor i(6);
        oprbs(18) := i(0) xor i(4) xor i(5);
        oprbs(17) := i(3) xor i(4) xor i(5) xor i(6);
        oprbs(16) := i(2) xor i(3) xor i(4) xor i(5);
        oprbs(15) := i(1) xor i(2) xor i(3) xor i(4);
        oprbs(14) := i(0) xor i(1) xor i(2) xor i(3);
        oprbs(13) := i(0) xor i(1) xor i(2) xor i(5) xor i(6);
        oprbs(12) := i(0) xor i(1) xor i(4) xor i(6);
        oprbs(11) := i(0) xor i(3) xor i(6);
        oprbs(10) := i(2) xor i(6);
        oprbs(9) := i(1) xor i(5);
        oprbs(8) := i(0) xor i(4);
        oprbs(7) := i(3) xor i(5) xor i(6);
        oprbs(6) := i(2) xor i(4) xor i(5);
        oprbs(5) := i(1) xor i(3) xor i(4);
        oprbs(4) := i(0) xor i(2) xor i(3);
        oprbs(3) := i(1) xor i(2) xor i(5) xor i(6);
        oprbs(2) := i(0) xor i(1) xor i(4) xor i(5);
        oprbs(1) := i(0) xor i(3) xor i(4) xor i(5) xor i(6);
        oprbs(0) := i(2) xor i(3) xor i(4) xor i(6);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs5_32b. Bus Size 32
    --    X^5 + X^3 + 1
    ------------------------------------------------
    function prbs5_32b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(31) := i(2) xor i(4);
        oprbs(30) := i(1) xor i(3);
        oprbs(29) := i(0) xor i(2);
        oprbs(28) := i(1) xor i(2) xor i(4);
        oprbs(27) := i(0) xor i(1) xor i(3);
        oprbs(26) := i(0) xor i(4);
        oprbs(25) := i(2) xor i(3) xor i(4);
        oprbs(24) := i(1) xor i(2) xor i(3);
        oprbs(23) := i(0) xor i(1) xor i(2);
        oprbs(22) := i(0) xor i(1) xor i(2) xor i(4);
        oprbs(21) := i(0) xor i(1) xor i(2) xor i(3) xor i(4);
        oprbs(20) := i(0) xor i(1) xor i(3) xor i(4);
        oprbs(19) := i(0) xor i(3) xor i(4);
        oprbs(18) := i(3) xor i(4);
        oprbs(17) := i(2) xor i(3);
        oprbs(16) := i(1) xor i(2);
        oprbs(15) := i(0) xor i(1);
        oprbs(14) := i(0) xor i(2) xor i(4);
        oprbs(13) := i(1) xor i(2) xor i(3) xor i(4);
        oprbs(12) := i(0) xor i(1) xor i(2) xor i(3);
        oprbs(11) := i(0) xor i(1) xor i(4);
        oprbs(10) := i(0) xor i(2) xor i(3) xor i(4);
        oprbs(9) := i(1) xor i(3) xor i(4);
        oprbs(8) := i(0) xor i(2) xor i(3);
        oprbs(7) := i(1) xor i(4);
        oprbs(6) := i(0) xor i(3);
        oprbs(5) := i(4);
        oprbs(4) := i(3);
        oprbs(3) := i(2);
        oprbs(2) := i(1);
        oprbs(1) := i(0);
        oprbs(0) := i(2) xor i(4);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs15_16b. Bus Size 16
    --    X^15 + X^14 + 1
    ------------------------------------------------
    function prbs15_16b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(15) := i(13) xor i(14);
        oprbs(14) := i(12) xor i(13);
        oprbs(13) := i(11) xor i(12);
        oprbs(12) := i(10) xor i(11);
        oprbs(11) := i(9) xor i(10);
        oprbs(10) := i(8) xor i(9);
        oprbs(9) := i(7) xor i(8);
        oprbs(8) := i(6) xor i(7);
        oprbs(7) := i(5) xor i(6);
        oprbs(6) := i(4) xor i(5);
        oprbs(5) := i(3) xor i(4);
        oprbs(4) := i(2) xor i(3);
        oprbs(3) := i(1) xor i(2);
        oprbs(2) := i(0) xor i(1);
        oprbs(1) := i(0) xor i(13) xor i(14);
        oprbs(0) := i(12) xor i(14);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs10_16b. Bus Size 16
    --    X^10 + X^7 + 1
    ------------------------------------------------
    function prbs10_16b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(15) := i(6) xor i(9);
        oprbs(14) := i(5) xor i(8);
        oprbs(13) := i(4) xor i(7);
        oprbs(12) := i(3) xor i(6);
        oprbs(11) := i(2) xor i(5);
        oprbs(10) := i(1) xor i(4);
        oprbs(9) := i(0) xor i(3);
        oprbs(8) := i(2) xor i(6) xor i(9);
        oprbs(7) := i(1) xor i(5) xor i(8);
        oprbs(6) := i(0) xor i(4) xor i(7);
        oprbs(5) := i(3) xor i(9);
        oprbs(4) := i(2) xor i(8);
        oprbs(3) := i(1) xor i(7);
        oprbs(2) := i(0) xor i(6);
        oprbs(1) := i(5) xor i(6) xor i(9);
        oprbs(0) := i(4) xor i(5) xor i(8);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs7_16b. Bus Size 16
    --    X^7 + X^6 + 1
    ------------------------------------------------
    function prbs7_16b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(15) := i(5) xor i(6);
        oprbs(14) := i(4) xor i(5);
        oprbs(13) := i(3) xor i(4);
        oprbs(12) := i(2) xor i(3);
        oprbs(11) := i(1) xor i(2);
        oprbs(10) := i(0) xor i(1);
        oprbs(9) := i(0) xor i(5) xor i(6);
        oprbs(8) := i(4) xor i(6);
        oprbs(7) := i(3) xor i(5);
        oprbs(6) := i(2) xor i(4);
        oprbs(5) := i(1) xor i(3);
        oprbs(4) := i(0) xor i(2);
        oprbs(3) := i(1) xor i(5) xor i(6);
        oprbs(2) := i(0) xor i(4) xor i(5);
        oprbs(1) := i(3) xor i(4) xor i(5) xor i(6);
        oprbs(0) := i(2) xor i(3) xor i(4) xor i(5);
        return oprbs;
    end;


    ------------------------------------------------
    --    Parallel PRBS prbs5_16b. Bus Size 16
    --    X^5 + X^3 + 1
    ------------------------------------------------
    function prbs5_16b( i : std_logic_vector )
    return std_logic_vector is
        constant w : integer := i'length;
        variable oprbs : std_logic_vector(w-1 downto 0);
    begin
        oprbs(15) := i(2) xor i(4);
        oprbs(14) := i(1) xor i(3);
        oprbs(13) := i(0) xor i(2);
        oprbs(12) := i(1) xor i(2) xor i(4);
        oprbs(11) := i(0) xor i(1) xor i(3);
        oprbs(10) := i(0) xor i(4);
        oprbs(9) := i(2) xor i(3) xor i(4);
        oprbs(8) := i(1) xor i(2) xor i(3);
        oprbs(7) := i(0) xor i(1) xor i(2);
        oprbs(6) := i(0) xor i(1) xor i(2) xor i(4);
        oprbs(5) := i(0) xor i(1) xor i(2) xor i(3) xor i(4);
        oprbs(4) := i(0) xor i(1) xor i(3) xor i(4);
        oprbs(3) := i(0) xor i(3) xor i(4);
        oprbs(2) := i(3) xor i(4);
        oprbs(1) := i(2) xor i(3);
        oprbs(0) := i(1) xor i(2);
        return oprbs;
    end;




--crc16 = x16_x12_x5_1

function crc16 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector is
    variable result : std_logic_vector(dih'range);

begin

        result(15) := dih(15) xor dih(11) xor dih( 7)             xor dil( 7) xor dil( 3);
        result(14) := dih(14) xor dih(10) xor dih( 6)             xor dil( 6) xor dil( 2);
        result(13) := dih(13) xor dih( 9) xor dih( 5)             xor dil( 5) xor dil( 1);
        result(12) := dih(15) xor dih(12) xor dih( 8) xor dih( 4) xor dil( 7) xor dil( 4) xor dil( 0);
        result(11) := dih(14) xor dih( 3)                         xor dil( 6);
        result(10) := dih(13) xor dih( 2)                         xor dil( 5);
        result( 9) := dih(12) xor dih( 1)                         xor dil( 4);
        result( 8) := dih(15) xor dih(11) xor dih( 0)             xor dil( 7) xor dil( 3);
        result( 7) := dih(15) xor dih(14) xor dih(10)             xor dil( 7) xor dil( 6) xor dil( 2);
        result( 6) := dih(14) xor dih(13) xor dih( 9)             xor dil( 6) xor dil( 5) xor dil( 1);
        result( 5) := dih(13) xor dih(12) xor dih( 8)             xor dil( 5) xor dil( 4) xor dil( 0);
        result( 4) := dih(12)                                     xor dil( 4);
        result( 3) := dih(15) xor dih(11)                         xor dil( 7) xor dil( 3);
        result( 2) := dih(14) xor dih(10)                         xor dil( 6) xor dil( 2);
        result( 1) := dih(13) xor dih( 9)                         xor dil( 5) xor dil( 1);
        result( 0) := dih(12) xor dih( 8)                         xor dil( 4) xor dil( 0);
    
        return result;

end crc16;

--crc32 = x32_x26_x23_x22_x16_x12_x11_x10_x8_x7_x5_x4_x2_x_1
function crc32 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector is
    variable result : std_logic_vector(dih'range);
begin
    if (dih'length /= (dil'length * 4)) then
        assert FALSE
        report "arguments of overloaded 'and' operator are not of the same length"
        severity failure;
    else
        result(31) := dih(29) xor dih(23)                         xor dil( 5);
        result(30) := dih(31) xor dih(28) xor dih(22)             xor dil( 7) xor dil( 4);
        result(29) := dih(31) xor dih(30) xor dih(27) xor dih(21) xor dil( 7) xor dil( 6) xor dil( 3);
        result(28) := dih(30) xor dih(29) xor dih(26) xor dih(20) xor dil( 6) xor dil( 5) xor dil( 2);
        result(27) := dih(31) xor dih(29) xor dih(28) xor dih(25) xor dil( 7) xor dil( 5) xor dil( 4) xor
                      dih(19)                                     xor dil( 1);
        result(26) := dih(30) xor dih(28) xor dih(27) xor dih(24) xor dil( 6) xor dil( 4) xor dil( 3) xor
                      dih(18)                                     xor dil( 0);
        result(25) := dih(27) xor dih(26) xor dih(17)             xor dil( 3) xor dil( 2);
        result(24) := dih(31) xor dih(26) xor dih(25) xor dih(16) xor dil( 7) xor dil( 2) xor dil( 1);
        result(23) := dih(30) xor dih(25) xor dih(24) xor dih(15) xor dil( 6) xor dil( 1) xor dil( 0);
        result(22) := dih(24) xor dih(14)                         xor dil( 0);
        result(21) := dih(29) xor dih(13)                         xor dil( 5);
        result(20) := dih(28) xor dih(12)                         xor dil( 4);
        result(19) := dih(31) xor dih(27) xor dih(11)             xor dil( 7) xor dil( 3);
        result(18) := dih(31) xor dih(30) xor dih(26) xor dih(10) xor dil( 7) xor dil( 6) xor dil( 2);
        result(17) := dih(30) xor dih(29) xor dih(25) xor dih( 9) xor dil( 6) xor dil( 5) xor dil( 1);
        result(16) := dih(29) xor dih(28) xor dih(24) xor dih( 8) xor dil( 5) xor dil( 4) xor dil( 0);
        result(15) := dih(31) xor dih(29) xor dih(28) xor dih(27) xor dil( 7) xor dil( 5) xor dil( 4) xor
                      dih( 7)                                     xor dil( 3);
        result(14) := dih(31) xor dih(30) xor dih(28) xor dih(27) xor dil( 7) xor dil( 6) xor dil( 4) xor
                      dih(26) xor dih( 6)                         xor dil( 3) xor dil( 2);
        result(13) := dih(31) xor dih(30) xor dih(29) xor dih(27) xor dil( 7) xor dil( 6) xor dil( 5) xor
                      dih(26) xor dih(25) xor dih( 5)             xor dil( 3) xor dil( 2) xor dil( 1);
        result(12) := dih(30) xor dih(29) xor dih(28) xor dih(26) xor dil( 6) xor dil( 5) xor dil( 4) xor
                      dih(25) xor dih(24) xor dih(4)              xor dil( 2) xor dil( 1) xor dil( 0);
        result(11) := dih(28) xor dih(27) xor dih(25) xor dih(24) xor dil( 4) xor dil( 3) xor dil( 1) xor
                      dih( 3)                                     xor dil( 0);
        result(10) := dih(29) xor dih(27) xor dih(26) xor dih(24) xor dil( 5) xor dil( 3) xor dil( 2) xor
                      dih( 2)                                     xor dil( 0);
        result( 9) := dih(29) xor dih(28) xor dih(26) xor dih(25) xor dil( 5) xor dil( 4) xor dil( 2) xor
                      dih( 1)                                     xor dil( 1);
        result( 8) := dih(28) xor dih(27) xor dih(25) xor dih(24) xor dil( 4) xor dil( 3) xor dil( 1) xor
                      dih( 0)                                     xor dil( 0);
        result( 7) := dih(31) xor dih(29) xor dih(27) xor dih(26) xor dil( 7) xor dil( 5) xor dil( 3) xor
                      dih(24)                                     xor dil( 2) xor dil( 0);
        result( 6) := dih(31) xor dih(30) xor dih(29) xor dih(28) xor dil( 7) xor dil( 6) xor dil( 5) xor
                      dih(26) xor dih(25)                         xor dil( 4) xor dil( 2) xor dil( 1);
        result( 5) := dih(31) xor dih(30) xor dih(29) xor dih(28) xor dil( 7) xor dil( 6) xor dil( 5) xor
                      dih(27) xor dih(25) xor dih(24)             xor dil( 4) xor dil( 3) xor dil( 1) xor
                                                                      dil( 0);
        result( 4) := dih(30) xor dih(28) xor dih(27) xor dih(26) xor dil( 6) xor dil( 4) xor dil( 3) xor
                      dih(24)                                     xor dil( 2) xor dil( 0);
        result( 3) := dih(31) xor dih(27) xor dih(26) xor dih(25) xor dil( 7) xor dil( 3) xor dil( 2) xor
                                                                      dil( 1);
        result( 2) := dih(31) xor dih(30) xor dih(26) xor dih(25) xor dil( 7) xor dil( 6) xor dil( 2) xor
                      dih(24)                                     xor dil( 1) xor dil( 0);
        result( 1) := dih(31) xor dih(30) xor dih(25) xor dih(24) xor dil( 7) xor dil( 6) xor dil( 1) xor
                                                                      dil( 0);
        result( 0) := dih(30) xor dih(24)                         xor dil( 6) xor dil( 0);
    end if;
    return result;
end crc32;



--crc8 = x7+x3+1
function crc_x8 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector is
    variable result : std_logic_vector(dih'range);
begin
        result(7) := dih(7) xor dih(6) xor dih(3) xor dil(7);
        result(6) := dih(6) xor dih(5) xor dih(2) xor dil(6);
        result(5) := dih(5) xor dih(4) xor dih(1) xor dil(5);
        result(4) := dih(4) xor dih(3) xor dih(0) xor dil(4);
        result(3) := dih(6) xor dih(2)            xor dil(3);
        result(2) := dih(5) xor dih(1)            xor dil(2);
        result(1) := dih(7) xor dih(4) xor dih(0) xor dil(1);
        result(0) :=                                  dil(0);
        return result;
end crc_x8;

function crc8 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector is
    variable result : std_logic_vector(dih'range);
begin
    if (dih'length /= dil'length) then
        assert FALSE
        report "arguments of overloaded 'and' operator are not of the same length"
        severity failure;
    else
        result(7) := dih(7) xor dih(6) xor dih(5)            xor dil(7) xor dil(6) xor dil(5)           ;
        result(6) := dih(6) xor dih(5) xor dih(4)            xor dil(6) xor dil(5) xor dil(4)           ;
        result(5) := dih(5) xor dih(4) xor dih(3)            xor dil(5) xor dil(4) xor dil(3)           ;
        result(4) := dih(4) xor dih(3) xor dih(2)            xor dil(4) xor dil(3) xor dil(2)           ;
        result(3) := dih(7) xor dih(3) xor dih(2) xor dih(1) xor dil(7) xor dil(3) xor dil(2) xor dil(1);
        result(2) := dih(6) xor dih(2) xor dih(1) xor dih(0) xor dil(6) xor dil(2) xor dil(1) xor dil(0);
        result(1) := dih(6) xor dih(1) xor dih(0)            xor dil(6) xor dil(1) xor dil(0)           ;
        result(0) := dih(7) xor dih(6) xor dih(0)            xor dil(7) xor dil(6) xor dil(0)           ;
    end if;
    return result;
end crc8;


end PKG_PRBS;
