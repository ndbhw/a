module dump_core (
    input  wire         axi_aclk   ,
    input  wire         axi_aresetn,
            
    input  wire [15:0]  rd_addr    ,
    output reg  [31:0]  rd_data    ,
                                    
    input  wire [15:0]  wr_addr    ,
    input  wire [31:0]  wr_data    ,
    input  wire         wr_stb     ,
            
    input  wire         sysx4_clk  ,                
    input  wire         dlif_sync  ,
    input  wire         dlif_valid ,
    input  wire [15:0]  dlif_I     ,
    input  wire [15:0]  dlif_Q     ,
    
    input  wire         dlbb_sync  ,
    input  wire         dlbb_valid ,
    input  wire [15:0]  dlbb_I     ,
    input  wire [15:0]  dlbb_Q     ,
        
    input  wire         sysx8_clk  ,                
    input  wire         dli_sync   ,
    input  wire         dli_valid  ,
    input  wire [15:0]  dli_I      ,
    input  wire [15:0]  dli_Q      ,
    
    input  wire         dlo_sync   ,
    input  wire         dlo_valid  ,
    input  wire [15:0]  dlo_I      ,
    input  wire [15:0]  dlo_Q      
);

    wire        sysx4_resetn;
    wire        sysx8_resetn;

    reg         reg_reset            ;
    reg         reg_Dump_Enable      ;    
    reg  [31:0] reg_Index_OffsetStart;
    reg  [31:0] reg_Index_OffsetStop ;
    reg  [15:0] reg_Mem_Addr         ;
    
    wire [31:0] cpu_DLI_Data         ;
    wire [31:0] cpu_DLO_Data         ;
    wire [31:0] cpu_DLBB_Data        ;
    wire [31:0] cpu_DLIF_Data        ;
    
    wire        cpu_clk              ;
    wire        cpu_reset            ;
    wire        cpu_areset           ;
    wire        cpu_aresetn          ;
                                     
    wire        x8_Dump_Enable       ;
    wire [31:0] x8_Index_OffsetStart ;
    wire [31:0] x8_Index_OffsetStop  ;
    
    wire        x4_Dump_Enable       ;
    wire [31:0] x4_Index_OffsetStart ;
    wire [31:0] x4_Index_OffsetStop  ;
    
    assign cpu_areset  = reg_reset ;
    assign cpu_aresetn = ~reg_reset;
    assign cpu_clk     = axi_aclk  ;
        
    xpm_cdc_async_rst #(
        .DEST_SYNC_FF   (2),    
        .INIT_SYNC_FF   (0),    
        .RST_ACTIVE_HIGH(0)  
    )
    sysx8_resetn_inst (
        .dest_arst(sysx8_resetn), 
        .dest_clk (sysx8_clk   ),   
        .src_arst (cpu_aresetn )    
    );

    xpm_cdc_async_rst #(
        .DEST_SYNC_FF   (2),    
        .INIT_SYNC_FF   (0),    
        .RST_ACTIVE_HIGH(0)  
    )
    sysx4_resetn_inst (
        .dest_arst(sysx4_resetn), 
        .dest_clk (sysx4_clk   ),   
        .src_arst (cpu_aresetn )    
    );
    
    xpm_cdc_async_rst #(
        .DEST_SYNC_FF   (2),    
        .INIT_SYNC_FF   (0),    
        .RST_ACTIVE_HIGH(0)  
    )
    cpu_reset_inst (
        .dest_arst(cpu_reset   ), 
        .dest_clk (axi_aclk    ),   
        .src_arst (cpu_areset  )    
    );
    
    always @(posedge axi_aclk) begin
        if(axi_aresetn == 1'b0) begin   
            reg_reset             <= 'd0;
            reg_Dump_Enable       <= 'd0;
            
            reg_Index_OffsetStart <= 'd0;
            reg_Index_OffsetStop  <= 'd0;
            
            reg_Mem_Addr          <= 'd0;
        end
        else begin
            if(wr_stb == 'b1) begin
                case (wr_addr)  
                    'h0004 : reg_reset             <= wr_data[0]   ;
                    'h000C : reg_Dump_Enable       <= wr_data[0]   ;
                    'h0010 : reg_Index_OffsetStart <= wr_data[31:0];
                    'h0014 : reg_Index_OffsetStop  <= wr_data[31:0];                    
                    'h001C : reg_Mem_Addr          <= wr_data[15:0];                     
                endcase  
            end
        end
    end    
    
    always @(posedge axi_aclk) begin
        if(axi_aresetn == 1'b0) begin            
            rd_data              <= 'd0;               
        end
        else begin
            case (rd_addr)  
                'h0000 : rd_data <= {8'h23, 8'h11, 16'h2024};
                'h0004 : rd_data <= {31'd0, reg_reset      };
                'h000C : rd_data <= {31'd0, reg_Dump_Enable};                  
                'h0010 : rd_data <= reg_Index_OffsetStart   ;
                'h0014 : rd_data <= reg_Index_OffsetStop    ;                
                'h001C : rd_data <= {15'd0, reg_Mem_Addr   }; 
                'h0020 : rd_data <= cpu_DLI_Data            ;
                'h0024 : rd_data <= cpu_DLO_Data            ;
                'h0028 : rd_data <= cpu_DLBB_Data           ;                     
                'h002C : rd_data <= cpu_DLIF_Data           ;                 
            endcase  
        end
    end 
    
    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          ( 1)           
    )
    cdc_x4_Dump_Enable_inst (
        .dest_out(x4_Dump_Enable        ),     
        .dest_clk(sysx4_clk             ), 
        .src_clk (axi_aclk              ),   
        .src_in  (reg_Dump_Enable       )      
    );

    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          (32)           
    )
    cdc_x4_Index_OffsetStart_inst (
        .dest_out(x4_Index_OffsetStart   ),     
        .dest_clk(sysx4_clk              ), 
        .src_clk (axi_aclk               ),   
        .src_in  (reg_Index_OffsetStart  )      
    );
    
    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          (32)           
    )
    cdc_x4_Index_OffsetStop_inst (
        .dest_out(x4_Index_OffsetStop    ),     
        .dest_clk(sysx4_clk              ), 
        .src_clk (axi_aclk               ),   
        .src_in  (reg_Index_OffsetStop   )      
    );

    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          ( 1)           
    )
    cdc_x8_Dump_Enable_inst (
        .dest_out(x8_Dump_Enable        ),     
        .dest_clk(sysx8_clk             ), 
        .src_clk (axi_aclk              ),   
        .src_in  (reg_Dump_Enable       )      
    );

    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          (32)           
    )
    cdc_x8_Index_OffsetStart_inst (
        .dest_out(x8_Index_OffsetStart   ),     
        .dest_clk(sysx8_clk              ), 
        .src_clk (axi_aclk               ),   
        .src_in  (reg_Index_OffsetStart  )      
    );
    
    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          (32)           
    )
    cdc_x8_Index_OffsetStop_inst (
        .dest_out(x8_Index_OffsetStop    ),     
        .dest_clk(sysx8_clk              ), 
        .src_clk (axi_aclk               ),   
        .src_in  (reg_Index_OffsetStop   )      
    );

    reg             buff_dli_sync       ;
    reg             buff_dli_valid      ;
    reg  [31:0]     buff_dli_index      ;
    reg  [15:0]     buff_dli_I          ;
    reg  [15:0]     buff_dli_Q          ;
                            
    reg             buff_dlo_sync       ;
    reg             buff_dlo_valid      ;
    reg  [31:0]     buff_dlo_index      ;
    reg  [15:0]     buff_dlo_I          ;
    reg  [15:0]     buff_dlo_Q          ;
    
    reg             buff_dlif_sync      ;
    reg             buff_dlif_valid     ;
    reg  [31:0]     buff_dlif_index     ;
    reg  [15:0]     buff_dlif_I         ;
    reg  [15:0]     buff_dlif_Q         ;
                            
    reg             buff_dlbb_sync      ;
    reg             buff_dlbb_valid     ;
    reg  [31:0]     buff_dlbb_index     ;
    reg  [15:0]     buff_dlbb_I         ;
    reg  [15:0]     buff_dlbb_Q         ;
                            
    
    always @(posedge sysx4_clk) begin
        if(sysx4_resetn == 1'b0) begin            
            buff_dlif_sync    <= 'd0;    
            buff_dlif_valid   <= 'd0;  
            buff_dlif_index   <= 'd0;  
            buff_dlif_I       <= 'd0;  
            buff_dlif_Q       <= 'd0;  
                            
            buff_dlbb_sync    <= 'd0;  
            buff_dlbb_valid   <= 'd0;  
            buff_dlbb_index   <= 'd0;  
            buff_dlbb_I       <= 'd0;  
            buff_dlbb_Q       <= 'd0;  
        end
        else begin
            buff_dlif_sync    <= dlif_sync ;
            buff_dlif_valid   <= dlif_valid; 
            buff_dlif_I       <= dlif_I    ; 
            buff_dlif_Q       <= dlif_Q    ; 
                                           
            buff_dlbb_sync    <= dlbb_sync ;
            buff_dlbb_valid   <= dlbb_valid; 
            buff_dlbb_I       <= dlbb_I    ; 
            buff_dlbb_Q       <= dlbb_Q    ; 
                
            if(dlif_sync == 'b1 && buff_dlif_sync == 'b0) begin
                buff_dlif_index <= 'd0;
            end
            else begin
                buff_dlif_index <= buff_dlif_index + 'd1;
            end
            
            if(dlbb_sync == 'b1 && buff_dlbb_sync == 'b0) begin
                buff_dlbb_index <= 'd0;
            end
            else begin
                buff_dlbb_index <= buff_dlbb_index + 'd1;
            end            
        end
    end 
    
    always @(posedge sysx8_clk) begin
        if(sysx8_resetn == 1'b0) begin            
            buff_dli_sync    <= 'd0;    
            buff_dli_valid   <= 'd0;  
            buff_dli_index   <= 'd0;  
            buff_dli_I       <= 'd0;  
            buff_dli_Q       <= 'd0;  
                            
            buff_dlo_sync    <= 'd0;  
            buff_dlo_valid   <= 'd0;  
            buff_dlo_index   <= 'd0;  
            buff_dlo_I       <= 'd0;  
            buff_dlo_Q       <= 'd0;  
        end
        else begin
            buff_dli_sync    <= dli_sync ;
            buff_dli_valid   <= dli_valid; 
            buff_dli_I       <= dli_I    ; 
            buff_dli_Q       <= dli_Q    ; 
                                           
            buff_dlo_sync    <= dlo_sync ;
            buff_dlo_valid   <= dlo_valid; 
            buff_dlo_I       <= dlo_I    ; 
            buff_dlo_Q       <= dlo_Q    ; 
                
            if(dli_sync == 'b1 && buff_dli_sync == 'b0 && dli_valid == 'b1) begin
                buff_dli_index <= 'd0;
            end
            else if(buff_dli_sync == 'b1 && dli_valid == 'b1) begin
                buff_dli_index <= 'd0;
            end 
            else if(dli_valid == 'b1) begin
                buff_dli_index <= buff_dli_index + 'd1;
            end
            else begin
                buff_dli_index <= buff_dli_index;
            end
            
            if(dlo_sync == 'b1 && buff_dlo_sync == 'b0 && dlo_valid == 'b1) begin
                buff_dlo_index <= 'd0;
            end
            else if(buff_dlo_sync == 'b1 && dlo_valid == 'b1) begin
                buff_dlo_index <= 'd0;
            end 
            else if(dlo_valid == 'b1) begin
                buff_dlo_index <= buff_dlo_index + 'd1;
            end
            else begin
                buff_dlo_index <= buff_dlo_index;
            end       
        end
    end 
    
//    dump_action_x8 dump_action_dli_inst(
//        .data_clk              (sysx8_clk            ),
//        .data_resetn           (sysx8_resetn         ),
//        .data_dump_enable      (x8_Dump_Enable       ),
//        .data_Index_OffsetStart(x8_Index_OffsetStart ),
//        .data_Index_OffsetStop (x8_Index_OffsetStop  ),
        
//        .data_sync             (buff_dli_sync        ),
//        .data_valid            (buff_dli_valid       ),
//        .data_index            (buff_dli_index       ),
//        .data_I                (buff_dli_I           ),
//        .data_Q                (buff_dli_Q           ),
     
//        .cpu_clk               (cpu_clk              ),
//        .cpu_reset             (cpu_reset            ),
//        .cpu_mem_addr          (reg_Mem_Addr         ),
//        .cpu_mem_data          (cpu_DLI_Data         )
//    );
    
    dump_action_x8 dump_action_dlo_inst(
        .data_clk              (sysx8_clk            ),
        .data_resetn           (sysx8_resetn         ),
        .data_dump_enable      (x8_Dump_Enable       ),
        .data_Index_OffsetStart(x8_Index_OffsetStart ),
        .data_Index_OffsetStop (x8_Index_OffsetStop  ),
        
        .data_sync             (buff_dlo_sync        ),
        .data_valid            (buff_dlo_valid       ),
        .data_index            (buff_dlo_index       ),
        .data_I                (buff_dlo_I           ),
        .data_Q                (buff_dlo_Q           ),
     
        .cpu_clk               (cpu_clk              ),
        .cpu_reset             (cpu_reset            ),
        .cpu_mem_addr          (reg_Mem_Addr         ),
        .cpu_mem_data          (cpu_DLO_Data         )
    );
    
    dump_action_x4 dump_action_dlif_inst(
        .data_clk              (sysx4_clk            ),
        .data_resetn           (sysx4_resetn         ),
        .data_dump_enable      (x4_Dump_Enable       ),
        .data_Index_OffsetStart(x4_Index_OffsetStart ),
        .data_Index_OffsetStop (x4_Index_OffsetStop  ),
        
        .data_sync             (buff_dlif_sync       ),
        .data_valid            (buff_dlif_valid      ),
        .data_index            (buff_dlif_index      ),
        .data_I                (buff_dlif_I          ),
        .data_Q                (buff_dlif_Q          ),
     
        .cpu_clk               (cpu_clk              ),
        .cpu_reset             (cpu_reset            ),
        .cpu_mem_addr          (reg_Mem_Addr         ),
        .cpu_mem_data          (cpu_DLIF_Data        )
    );
    
//    dump_action_x4 dump_action_dlbb_inst(
//        .data_clk              (sysx4_clk            ),
//        .data_resetn           (sysx4_resetn         ),
//        .data_dump_enable      (x4_Dump_Enable       ),
//        .data_Index_OffsetStart(x4_Index_OffsetStart ),
//        .data_Index_OffsetStop (x4_Index_OffsetStop  ),
        
//        .data_sync             (buff_dlbb_sync       ),
//        .data_valid            (buff_dlbb_valid      ),
//        .data_index            (buff_dlbb_index      ),
//        .data_I                (buff_dlbb_I          ),
//        .data_Q                (buff_dlbb_Q          ),
     
//        .cpu_clk               (cpu_clk              ),
//        .cpu_reset             (cpu_reset            ),
//        .cpu_mem_addr          (reg_Mem_Addr         ),
//        .cpu_mem_data          (cpu_DLBB_Data        )
//    );
    
endmodule
