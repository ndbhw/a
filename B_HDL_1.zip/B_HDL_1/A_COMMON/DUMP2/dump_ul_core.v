module dump_ul_core (
    input  wire          axi_aclk         ,
    input  wire          axi_aresetn      ,
                                          
    input  wire [15:0]   rd_addr          ,
    output reg  [31:0]   rd_data          ,
                                           
    input  wire [15:0]   wr_addr          ,
    input  wire [31:0]   wr_data          ,
    input  wire          wr_stb           ,
                                          
    input  wire          sysx8_clk        ,    
                                          
    input  wire          uli_sync         ,
    input  wire          uli_valid        ,
    input  wire [15:0]   uli_I            ,
    input  wire [15:0]   uli_Q            ,
    
    input  wire [16-1:0] rin_filter_idx   ,
    input  wire [16-1:0] rin_time_offset  ,
    input  wire [08-1:0] rin_frame_struct ,
    input  wire [16-1:0] rin_cp_length    ,
    input  wire [24-1:0] rin_freq_offset  ,
    input  wire [04-1:0] rin_num_psymbol  ,
    input  wire [03-1:0] rin_num_ro       ,
    input  wire [08-1:0] rin_num_prbc     ,
    input  wire [08-1:0] rout_frame_idx   ,    
    input  wire [04-1:0] rout_subfrm_idx  ,    
    input  wire [06-1:0] rout_slot_idx    ,    
    input  wire [06-1:0] rout_symbol_idx  ,    
    input  wire [16-1:0] rout_start_re_idx,    
    
    input  wire          ulo_sync          ,
    input  wire          ulo_valid         ,
    input  wire [15:0]   ulo_I             ,
    input  wire [15:0]   ulo_Q             
);

    wire        sysx8_resetn;

    reg         reg_reset            ;
    reg         reg_Dump_Enable      ;    
    reg  [31:0] reg_Index_OffsetStart;
    reg  [31:0] reg_Index_OffsetStop ;
    reg  [15:0] reg_Mem_Addr         ;
    
    wire [31:0] cpu_DLI_Data         ;
    wire [31:0] cpu_DLO_Data         ;
    
    wire        cpu_clk              ;
    wire        cpu_reset            ;
    wire        cpu_areset           ;
    wire        cpu_aresetn          ;
                                     
    wire        x8_Dump_Enable       ;
    wire [31:0] x8_Index_OffsetStart ;
    wire [31:0] x8_Index_OffsetStop  ;
    
//    (* ASYNC_REG="true" *) reg  [04-1:0] reg_rin_filter_idx   ;
//    (* ASYNC_REG="true" *) reg  [16-1:0] reg_rin_time_offset  ;
//    (* ASYNC_REG="true" *) reg  [08-1:0] reg_rin_frame_struct ;
//    (* ASYNC_REG="true" *) reg  [16-1:0] reg_rin_cp_length    ;
//    (* ASYNC_REG="true" *) reg  [24-1:0] reg_rin_freq_offset  ;
//    (* ASYNC_REG="true" *) reg  [04-1:0] reg_rin_num_psymbol  ;
//    (* ASYNC_REG="true" *) reg  [03-1:0] reg_rin_num_ro       ;
//    (* ASYNC_REG="true" *) reg  [08-1:0] reg_rin_num_prbc     ;
//    (* ASYNC_REG="true" *) reg  [08-1:0] reg_rout_frame_idx   ;    
//    (* ASYNC_REG="true" *) reg  [04-1:0] reg_rout_subfrm_idx  ;    
//    (* ASYNC_REG="true" *) reg  [06-1:0] reg_rout_slot_idx    ;    
//    (* ASYNC_REG="true" *) reg  [06-1:0] reg_rout_symbol_idx  ;    
//    (* ASYNC_REG="true" *) reg  [16-1:0] reg_rout_start_re_idx; 
    
    reg  [16-1:0] reg_rin_filter_idx   ;
    reg  [16-1:0] reg_rin_time_offset  ;
    reg  [08-1:0] reg_rin_frame_struct ;
    reg  [16-1:0] reg_rin_cp_length    ;
    reg  [24-1:0] reg_rin_freq_offset  ;
    reg  [04-1:0] reg_rin_num_psymbol  ;
    reg  [03-1:0] reg_rin_num_ro       ;
    reg  [08-1:0] reg_rin_num_prbc     ;
    reg  [08-1:0] reg_rout_frame_idx   ;    
    reg  [04-1:0] reg_rout_subfrm_idx  ;    
    reg  [06-1:0] reg_rout_slot_idx    ;    
    reg  [06-1:0] reg_rout_symbol_idx  ;    
    reg  [16-1:0] reg_rout_start_re_idx;
    
    wire        buff_uli_capture;
    wire        buff_ulo_capture;
        
    assign cpu_areset  = reg_reset ;
    assign cpu_aresetn = ~reg_reset;
    assign cpu_clk     = axi_aclk  ;
        
    xpm_cdc_async_rst #(
        .DEST_SYNC_FF   (2),    
        .INIT_SYNC_FF   (0),    
        .RST_ACTIVE_HIGH(0)  
    )
    sysx8_resetn_inst (
        .dest_arst(sysx8_resetn), 
        .dest_clk (sysx8_clk   ),   
        .src_arst (cpu_aresetn )    
    );

    xpm_cdc_async_rst #(
        .DEST_SYNC_FF   (2),    
        .INIT_SYNC_FF   (0),    
        .RST_ACTIVE_HIGH(0)  
    )
    cpu_reset_inst (
        .dest_arst(cpu_reset   ), 
        .dest_clk (axi_aclk    ),   
        .src_arst (cpu_areset  )    
    );
    
    always @(posedge axi_aclk) begin
        if(axi_aresetn == 1'b0) begin   
            reg_reset             <= 'd0;
            reg_Dump_Enable       <= 'd0;
            
            reg_Index_OffsetStart <= 'd0;
            reg_Index_OffsetStop  <= 'd0;
            
            reg_Mem_Addr          <= 'd0;
        end
        else begin
            if(wr_stb == 'b1) begin
                case (wr_addr)  
                    'h0004 : reg_reset             <= wr_data[0]   ;
                    'h000C : reg_Dump_Enable       <= wr_data[0]   ;
                    'h0010 : reg_Index_OffsetStart <= wr_data[31:0];
                    'h0014 : reg_Index_OffsetStop  <= wr_data[31:0];                    
                    'h001C : reg_Mem_Addr          <= wr_data[15:0];                     
                endcase  
            end
        end
    end    
    
    always @(posedge axi_aclk) begin
        if(axi_aresetn == 1'b0) begin            
            rd_data              <= 'd0;               
        end
        else begin
            case (rd_addr)  
                'h0000 : rd_data <= {8'h23, 8'h11, 16'h2024};
                'h0004 : rd_data <= {31'd0, reg_reset      };
                'h000C : rd_data <= {31'd0, reg_Dump_Enable};                  
                'h0010 : rd_data <= reg_Index_OffsetStart   ;
                'h0014 : rd_data <= reg_Index_OffsetStop    ;                
                'h001C : rd_data <= {15'd0, reg_Mem_Addr   }; 
                'h0020 : rd_data <= cpu_DLI_Data            ;
                'h0024 : rd_data <= cpu_DLO_Data            ; 

                'h0030 : rd_data <= {16'd0, reg_rin_filter_idx   };
                'h0034 : rd_data <= {16'd0, reg_rin_time_offset  };
                'h0038 : rd_data <= {24'd0, reg_rin_frame_struct };
                'h003C : rd_data <= {16'd0, reg_rin_cp_length    };
                'h0040 : rd_data <= {24'd0, reg_rin_freq_offset  };
                'h0044 : rd_data <= {28'd0, reg_rin_num_psymbol  };
                'h0048 : rd_data <= {29'd0, reg_rin_num_ro       };
                'h004C : rd_data <= {24'd0, reg_rin_num_prbc     };
                                                                 
                'h0050 : rd_data <= {24'd0, reg_rout_frame_idx   };
                'h0054 : rd_data <= {28'd0, reg_rout_subfrm_idx  };
                'h0058 : rd_data <= {26'd0, reg_rout_slot_idx    };
                'h005C : rd_data <= {26'd0, reg_rout_symbol_idx  };                
                'h0060 : rd_data <= {16'd0, reg_rout_start_re_idx};                
            endcase  
        end
    end 

    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          ( 1)           
    )
    cdc_x8_Dump_Enable_inst (
        .dest_out(x8_Dump_Enable        ),     
        .dest_clk(sysx8_clk             ), 
        .src_clk (axi_aclk              ),   
        .src_in  (reg_Dump_Enable       )      
    );

    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          (32)           
    )
    cdc_x8_Index_OffsetStart_inst (
        .dest_out(x8_Index_OffsetStart   ),     
        .dest_clk(sysx8_clk              ), 
        .src_clk (axi_aclk               ),   
        .src_in  (reg_Index_OffsetStart  )      
    );
    
    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          (32)           
    )
    cdc_x8_Index_OffsetStop_inst (
        .dest_out(x8_Index_OffsetStop    ),     
        .dest_clk(sysx8_clk              ), 
        .src_clk (axi_aclk               ),   
        .src_in  (reg_Index_OffsetStop   )      
    );

    reg             buff_uli_sync       ;
    reg             buff_uli_valid      ;
    reg  [31:0]     buff_uli_index      ;
    reg  [15:0]     buff_uli_I          ;
    reg  [15:0]     buff_uli_Q          ;
                            
    reg             buff_ulo_sync       ;
    reg             buff_ulo_valid      ;
    reg  [31:0]     buff_ulo_index      ;
    reg  [15:0]     buff_ulo_I          ;
    reg  [15:0]     buff_ulo_Q          ;
    
    always @(posedge sysx8_clk) begin
        if(sysx8_resetn == 1'b0) begin            
            buff_uli_sync    <= 'd0;    
            buff_uli_valid   <= 'd0;  
            buff_uli_index   <= 'd0;  
            buff_uli_I       <= 'd0;  
            buff_uli_Q       <= 'd0;  
                            
            buff_ulo_sync    <= 'd0;  
            buff_ulo_valid   <= 'd0;  
            buff_ulo_index   <= 'd0;  
            buff_ulo_I       <= 'd0;  
            buff_ulo_Q       <= 'd0;  
        end
        else begin
            buff_uli_sync    <= uli_sync ;
            buff_uli_valid   <= uli_valid; 
            buff_uli_I       <= uli_I    ; 
            buff_uli_Q       <= uli_Q    ; 
                                           
            buff_ulo_sync    <= ulo_sync ;
            buff_ulo_valid   <= ulo_valid; 
            buff_ulo_I       <= ulo_I    ; 
            buff_ulo_Q       <= ulo_Q    ; 
                
            if(uli_sync == 'b1 && buff_uli_sync == 'b0 && uli_valid == 'b1) begin
                buff_uli_index <= 'd0;
            end
            else if(buff_uli_sync == 'b1 && uli_valid == 'b1) begin
                buff_uli_index <= 'd0;
            end 
            else if(uli_valid == 'b1) begin
                buff_uli_index <= buff_uli_index + 'd1;
            end
            else begin
                buff_uli_index <= buff_uli_index;
            end
            
            if(ulo_sync == 'b1 && buff_ulo_sync == 'b0 && ulo_valid == 'b1) begin
                buff_ulo_index <= 'd0;
            end
            else if(buff_ulo_sync == 'b1 && ulo_valid == 'b1) begin
                buff_ulo_index <= 'd0;
            end 
            else if(ulo_valid == 'b1) begin
                buff_ulo_index <= buff_ulo_index + 'd1;
            end
            else begin
                buff_ulo_index <= buff_ulo_index;
            end       
        end
    end 
    
    dump_action_x8 dump_action_uli_inst(
        .data_clk              (sysx8_clk            ),
        .data_resetn           (sysx8_resetn         ),
        .data_dump_enable      (x8_Dump_Enable       ),
        .data_Index_OffsetStart(x8_Index_OffsetStart ),
        .data_Index_OffsetStop (x8_Index_OffsetStop  ),
        
        .data_capture          (buff_uli_capture     ),
      
        .data_sync             (buff_uli_sync        ),
        .data_valid            (buff_uli_valid       ),
        .data_index            (buff_uli_index       ),
        .data_I                (buff_uli_I           ),
        .data_Q                (buff_uli_Q           ),
   
        .cpu_clk               (cpu_clk              ),
        .cpu_reset             (cpu_reset            ),
        .cpu_mem_addr          (reg_Mem_Addr         ),
        .cpu_mem_data          (cpu_DLI_Data         )
    );
    
    always @(posedge sysx8_clk) begin
        if(sysx8_resetn == 1'b0) begin            
            reg_rin_filter_idx     <= 'd0;    
            reg_rin_time_offset    <= 'd0;  
            reg_rin_frame_struct   <= 'd0;  
            reg_rin_cp_length      <= 'd0;  
            reg_rin_freq_offset    <= 'd0;  
            reg_rin_num_psymbol    <= 'd0;
            reg_rin_num_ro         <= 'd0;
            reg_rin_num_prbc       <= 'd0;  
        end
        else begin
            if(buff_uli_capture == 'b1) begin
                reg_rin_filter_idx     <= rin_filter_idx  ;    
                reg_rin_time_offset    <= rin_time_offset ;  
                reg_rin_frame_struct   <= rin_frame_struct;  
                reg_rin_cp_length      <= rin_cp_length   ;  
                reg_rin_freq_offset    <= rin_freq_offset ;  
                reg_rin_num_psymbol    <= rin_num_psymbol ;
                reg_rin_num_ro         <= rin_num_ro      ;
                reg_rin_num_prbc       <= rin_num_prbc    ; 
            end
            else begin
                reg_rin_filter_idx     <= reg_rin_filter_idx  ;    
                reg_rin_time_offset    <= reg_rin_time_offset ;  
                reg_rin_frame_struct   <= reg_rin_frame_struct;  
                reg_rin_cp_length      <= reg_rin_cp_length   ;  
                reg_rin_freq_offset    <= reg_rin_freq_offset ;  
                reg_rin_num_psymbol    <= reg_rin_num_psymbol ;
                reg_rin_num_ro         <= reg_rin_num_ro      ;
                reg_rin_num_prbc       <= reg_rin_num_prbc    ;
            end
        end
    end 
    
    dump_action_x8 dump_action_ulo_inst(
        .data_clk              (sysx8_clk            ),
        .data_resetn           (sysx8_resetn         ),
        .data_dump_enable      (x8_Dump_Enable       ),
        .data_Index_OffsetStart(x8_Index_OffsetStart ),
        .data_Index_OffsetStop (x8_Index_OffsetStop  ),
        
        .data_capture          (buff_ulo_capture     ),
        
        .data_sync             (buff_ulo_sync        ),
        .data_valid            (buff_ulo_valid       ),
        .data_index            (buff_ulo_index       ),
        .data_I                (buff_ulo_I           ),
        .data_Q                (buff_ulo_Q           ),
     
        .cpu_clk               (cpu_clk              ),
        .cpu_reset             (cpu_reset            ),
        .cpu_mem_addr          (reg_Mem_Addr         ),
        .cpu_mem_data          (cpu_DLO_Data         )
    );
    
    always @(posedge sysx8_clk) begin
        if(sysx8_resetn == 1'b0) begin            
            reg_rout_frame_idx    <= 'd0;    
            reg_rout_subfrm_idx   <= 'd0;  
            reg_rout_slot_idx     <= 'd0;  
            reg_rout_symbol_idx   <= 'd0;  
            reg_rout_start_re_idx <= 'd0;   
        end
        else begin
            if(buff_ulo_capture == 'b1) begin
                reg_rout_frame_idx    <= rout_frame_idx   ;    
                reg_rout_subfrm_idx   <= rout_subfrm_idx  ;  
                reg_rout_slot_idx     <= rout_slot_idx    ;  
                reg_rout_symbol_idx   <= rout_symbol_idx  ;  
                reg_rout_start_re_idx <= rout_start_re_idx;  
            end
            else begin
                reg_rout_frame_idx    <= reg_rout_frame_idx   ;    
                reg_rout_subfrm_idx   <= reg_rout_subfrm_idx  ;  
                reg_rout_slot_idx     <= reg_rout_slot_idx    ;  
                reg_rout_symbol_idx   <= reg_rout_symbol_idx  ;  
                reg_rout_start_re_idx <= reg_rout_start_re_idx; 
            end
        end
    end 
    
    
endmodule
