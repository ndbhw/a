module dump_action_x4 (
    input  wire         data_clk              ,
    input  wire         data_resetn           ,
    input  wire         data_dump_enable      ,
    input  wire [31:0]  data_Index_OffsetStart,
    input  wire [31:0]  data_Index_OffsetStop ,
                                              
    input  wire         data_sync             ,
    input  wire         data_valid            ,
    input  wire [31:0]  data_index            ,
    input  wire [15:0]  data_I                ,
    input  wire [15:0]  data_Q                ,
                                              
    input  wire         cpu_clk               ,
    input  wire         cpu_reset             ,
    input  wire [15:0]  cpu_mem_addr          ,
    output wire [31:0]  cpu_mem_data          
);
    
    reg           data_dump_enable_dly ;
    reg           data_dump_ena        ;  
    reg           data_dump_safe       ;
    reg           data_dump_act        ;
                                      
    reg           mem_data_write_wea   ;
    reg  [15:0]   mem_data_write_addr  ;
    reg  [31:0]   mem_data_write_data  ;
    wire [15:0]   mem_data_read_addr   ;
    wire [31:0]   mem_data_read_data   ;
                                      
    reg           data_safe_valid      ;  
    reg  [31:0]   data_safe_data       ; 
    
    reg           data_dump_act_ext1   ;
    reg           data_dump_act_ext2   ;
    
    reg           data_act_valid       ;  
    reg  [31:0]   data_act_data        ;
    
        
    always @(posedge data_clk) begin
        if(data_resetn == 1'b0) begin            
            data_dump_enable_dly <= 'd0;  
        end
        else begin
            data_dump_enable_dly <= data_dump_enable;
        end
    end
    
    always @(posedge data_clk) begin
        if(data_resetn == 1'b0) begin            
            data_dump_ena <= 'd0;  
        end
        else begin
            if(data_dump_ena == 'b1 && data_dump_act == 'b1 && data_Index_OffsetStop == data_index) begin
                data_dump_ena <= 'd0;  
            end
            else if(data_dump_enable == 'b1 && data_dump_enable_dly == 'b0) begin
                data_dump_ena <= 'd1;
            end
            else begin
                data_dump_ena <= data_dump_ena;
            end
        end
    end
    
    always @(posedge data_clk) begin
        if(data_resetn == 1'b0) begin            
            data_dump_safe <= 'd0;  
        end
        else begin
            if(data_dump_ena == 'b1 && data_dump_act == 'b1 && data_Index_OffsetStop == data_index) begin
                data_dump_safe <= 'd0;  
            end
            else if(data_dump_ena == 'b1 && data_Index_OffsetStart == data_index) begin
                data_dump_safe <= 'd1;
            end
            else begin
                data_dump_safe <= data_dump_safe;
            end
        end
    end
    
    always @(posedge data_clk) begin
        if(data_resetn == 1'b0) begin            
            data_dump_act <= 'd0;  
        end
        else begin
            if(data_dump_ena == 'b1 && data_dump_act == 'b1 && data_Index_OffsetStop == data_index) begin
                data_dump_act <= 'd0;  
            end
            else if(data_dump_ena == 'b1 && data_safe_valid == 'b1 && data_dump_safe == 'b1 && data_Index_OffsetStart == data_index) begin
                data_dump_act <= 'd1;
            end
            else begin
                data_dump_act <= data_dump_act;
            end
        end
    end
    
    always @(posedge data_clk) begin
        if(data_resetn == 1'b0) begin            
            data_dump_act_ext1 <= 'd0;
            data_dump_act_ext2 <= 'd0;
        end
        else begin
            data_dump_act_ext1 <= data_dump_act;
            data_dump_act_ext2 <= data_dump_act_ext1;
        end
    end
    
    always @(posedge data_clk) begin
        if(data_resetn == 1'b0) begin            
            data_safe_valid <= 'd0;  
            data_safe_data  <= 'd0;  
        end
        else begin
            if(data_dump_safe == 'b1) begin
                data_safe_valid <= data_valid;  
                data_safe_data  <= {data_I, data_Q};    
            end
            else begin
                data_safe_valid <= 'd0;  
                data_safe_data  <= 'd0;  
            end
        end
    end

    
    always @(posedge data_clk) begin
        if(data_resetn == 1'b0) begin            
            data_act_valid <= 'd0;  
            data_act_data  <= 'd0;  
        end
        else begin
            if(data_safe_valid == 'b1) begin
                data_act_valid <= 'b1;  
                data_act_data  <= data_safe_data;    
            end
            else begin
                data_act_valid <= 'd0;  
                data_act_data  <= 'd0;  
            end
        end
    end
    
    always @(posedge data_clk) begin
        if(data_resetn == 1'b0) begin            
            mem_data_write_wea  <= 'd0;    
            mem_data_write_addr <= 'd0;  
            mem_data_write_data <= 'd0; 
        end
        else begin
            if(data_dump_act_ext1 == 'b1 || data_dump_act_ext2 == 'b1) begin                
                if(data_act_valid == 'b1) begin
                    mem_data_write_wea  <= 'b1; 
                    mem_data_write_addr <= mem_data_write_addr + 'd1;                                        
                    mem_data_write_data <= data_act_data; 
                end
                else begin
                    mem_data_write_wea  <= 'b0; 
                    mem_data_write_addr <= mem_data_write_addr;
                    mem_data_write_data <= mem_data_write_data; 
                end
            end
            else begin
                mem_data_write_wea  <= 'b0; 
                mem_data_write_addr <= 'd65535; 
                mem_data_write_data <= 'd0;
            end            
        end
    end 
    
    xpm_memory_sdpram #(
        .ADDR_WIDTH_A             (                     16), 
        .ADDR_WIDTH_B             (                     16), 
        .AUTO_SLEEP_TIME          (                      0), 
        .BYTE_WRITE_WIDTH_A       (                     32), 
        .CLOCKING_MODE            ("independent_clock"    ), 
        .ECC_MODE                 ("no_ecc"               ), 
        .MEMORY_INIT_FILE         ("none"                 ), 
        .MEMORY_INIT_PARAM        ("0"                    ), 
        .MEMORY_OPTIMIZATION      ("true"                 ),  
        .MEMORY_PRIMITIVE         ("auto"                 ),  
        .MEMORY_SIZE              (                2097152),
        .MESSAGE_CONTROL          (                      0),    
        .READ_DATA_WIDTH_B        (                     32),    
        .READ_LATENCY_B           (                      1),    
        .READ_RESET_VALUE_B       ("0"                    ),      
        .RST_MODE_A               ("SYNC"                 ),      
        .RST_MODE_B               ("SYNC"                 ),      
        .USE_EMBEDDED_CONSTRAINT  (                      0),   
        .USE_MEM_INIT             (                      0),      
        .WAKEUP_TIME              ("disable_sleep"        ),  
        .WRITE_DATA_WIDTH_A       (                     32),  
        .WRITE_MODE_B             ("no_change"            )   
    ) xpm_memory_data_inst (
        .clka                     (data_clk               ),  
        .ena                      (                    'b1),
        .wea                      (mem_data_write_wea     ),
        .addra                    (mem_data_write_addr    ),
        .dina                     (mem_data_write_data    ),
                                  
        .clkb                     (cpu_clk                ),
        .enb                      (                    'b1),
        .rstb                     (cpu_reset              ), 
        .addrb                    (mem_data_read_addr     ),
        .doutb                    (mem_data_read_data     ), 
                                  
        .injectdbiterra           (                    'b0),
        .injectsbiterra           (                    'b0),
        .regceb                   (                    'b1),
        .dbiterrb                 (                       ), 
        .sbiterrb                 (                       ),
                                  
        .sleep                    (                    'b0)           
    );
    
    assign mem_data_read_addr = cpu_mem_addr      ;
    assign cpu_mem_data       = mem_data_read_data;
    

endmodule
