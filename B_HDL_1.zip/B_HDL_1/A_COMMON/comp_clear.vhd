--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2016, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Write and clear (Component, 32-bit)                           --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2016.10.11                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
--   v1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity COMP_CLEAR is
    generic (
        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;
        CLK_TARGET                  : in  std_logic;

        EN                          : in  std_logic;
        ADDR                        : in  std_logic_vector(7 downto 0);
        DATA_OUT                    : out std_logic
    );
end COMP_CLEAR;

architecture BEHAVE of COMP_CLEAR is

    signal enable                   : std_logic;
    signal retiming                 : std_logic_vector(2 downto 0) := (others => '0');
    signal clear                    : std_logic := '0';

begin

    process (RESET, CLK)
    begin
        if (RESET = '1') then
            enable <= '0';
        elsif (CLK'event and CLK = '1') then
            if (ADDR = REG_ADDR) then
                enable <= EN;
            else
                enable <= '0';
            end if;
        end if;
    end process;

    process (CLK_TARGET)
    begin
        if (CLK_TARGET'event and CLK_TARGET = '1') then
            retiming <= retiming(1 downto 0) & enable;
        end if;
    end process;

    process (CLK_TARGET)
    begin
        if (CLK_TARGET'event and CLK_TARGET = '1') then
            if (retiming(2 downto 1) = "01") then
                clear <= '1';
            else
                clear <= '0';
            end if;
        end if;
    end process;

    DATA_OUT <= clear;

end BEHAVE;
