library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity CNT_1ms is
generic(
    CLK_FREQ             : real := 245.760 -- MHz
    );
port(
    RST                  : in  std_logic;
    CLK                  : in  std_logic;

    BFN_10ms_IN          : in  std_logic;
    
    CNT_1ms_OUT          : out std_logic_vector(3 downto 0)
    );
end CNT_1ms;

architecture arc_CNT_1ms of CNT_1ms is

constant COUNT_1ms       : natural := natural(CLK_FREQ*1000.00);    
constant CNT_WIDTH       : natural := log2(COUNT_1ms);       
constant COUNT_1ms_VALUE : std_logic_vector(CNT_WIDTH downto 0) := conv_std_logic_vector(COUNT_1ms-1, CNT_WIDTH+1);    

signal bfn_10ms_d1       : std_logic;
signal rpls_10ms         : std_logic;
signal rpls_10ms_sh      : std_logic_vector(1 downto 0);
signal rpls_1ms          : std_logic;

signal clk_cnt           : std_logic_vector(CNT_WIDTH downto 0) := (others => '0');
signal cnt_1_ms          : std_logic_vector(3 downto 0) := (others => '0');

begin

    P_RPLS_10ms : process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            bfn_10ms_d1  <= BFN_10ms_IN; 
            rpls_10ms    <= BFN_10ms_IN and (not bfn_10ms_d1); 
            rpls_10ms_sh <= rpls_10ms_sh(0) & rpls_10ms;
        end if;
    end process;

    P_CLK_CNT : process(RST, CLK) begin
        if (RST = '1') then
            clk_cnt <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (rpls_10ms = '1') then
                clk_cnt  <= (others => '0');
            else
                if (clk_cnt = COUNT_1ms_VALUE) then
                    clk_cnt <= (others => '0');
                else
                    clk_cnt <= clk_cnt + '1'; 
                end if;
            end if;
        end if;
    end process;

    P_RPLS_1ms :process(CLK) begin
        if (CLK'event) and (CLK = '1') then
            if (clk_cnt = 0) then
                rpls_1ms <= '1';
            else
                rpls_1ms <= '0';
            end if;
        end if;
    end process;

    P_1ms_CNT : process(RST, CLK) begin
        if (RST = '1') then
            cnt_1_ms  <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (rpls_1ms = '1') then
                if (rpls_10ms_sh(1) = '1') then
                    cnt_1_ms  <= (others => '0');
                else
                    cnt_1_ms  <= cnt_1_ms + '1';
                end if;
            end if;
        end if;
    end process;

    CNT_1ms_OUT <= cnt_1_ms;

end arc_CNT_1ms;
