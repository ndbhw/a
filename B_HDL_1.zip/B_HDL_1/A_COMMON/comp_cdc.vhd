--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2013, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : CDC Register (Component, max 32-bits)                         --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2013.10.21 (2014.03.28)                                       --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
--   v1.0 - initial release                                                   --
--   v1.1 - decrease warning messages when synthesize                         --
--   v1.2 - add initial value                                                 --
--   v1.3 - logic optimized                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity COMP_CDC is
    generic (
        BIT_ENABLE                  : std_logic_vector(31 downto 0) := (others => '1');
        REG_DATA                    : std_logic_vector(31 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK_IN                      : in  std_logic;
        CLK_OUT                     : in  std_logic;

        DATA_IN                     : in  std_logic_vector(31 downto 0);
        DATA_OUT                    : out std_logic_vector(31 downto 0)
    );
end COMP_CDC;

architecture BEHAVE of COMP_CDC is

    signal change                   : std_logic_vector(7 downto 0);
    signal data_in_pre              : std_logic_vector(31 downto 0);
    signal data_in_buf              : std_logic_vector(31 downto 0);
    signal sreset                   : std_logic_vector(2 downto 0);
    signal stable                   : std_logic_vector(3 downto 0);

begin

    process (RESET, CLK_IN)
    begin
        if (RESET = '1') then
            data_in_pre <= REG_DATA;
            data_in_buf <= REG_DATA;
            change      <= (others => '0');
        elsif (CLK_IN'event and CLK_IN = '1') then
            data_in_pre <= DATA_IN and BIT_ENABLE;
            if (DATA_IN /= data_in_pre) then
                data_in_buf <= DATA_IN;
                change      <= "00001111";
            else
                change      <= change(6 downto 0) & change(7);
            end if;
        end if;
    end process;

    process (RESET, CLK_OUT)
    begin
        if (RESET = '1') then
            sreset <= (others => '1');
        elsif (CLK_OUT'event and CLK_OUT = '1') then
            sreset <= sreset(1 downto 0) & '0';
        end if;
    end process;

    process (sreset(1), CLK_OUT)
    begin
        if (sreset(1) = '1') then
            stable <= (others => '0');
        elsif (CLK_OUT'event and CLK_OUT = '1') then
            stable <= stable(2 downto 0) & change(7);
        end if;
    end process;

    process (sreset(1), CLK_OUT)
    begin
        if (sreset(1) = '1') then
            DATA_OUT <= REG_DATA;
        elsif (CLK_OUT'event and CLK_OUT = '1') then
            for i in 31 downto 0 loop
            if (stable(3 downto 2) = "01") then
                DATA_OUT(i) <= data_in_buf(i) and BIT_ENABLE(i);
            end if;
            end loop;
        end if;
    end process;

end BEHAVE;
