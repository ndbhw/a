library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use IEEE.numeric_std.all;

library work;
--use work.ARRAY_TYPE.all;
--use work.RU_FPGA_FNC.all;

entity BCF_FRSYNC_MON is
port(
    RST_BLK                     : in  std_logic;
    CLK_BLK                     : in  std_logic;

    BCF_EN_BLKCLK_IN            : in  std_logic;
    FRSYNC_BLKCLK_IN            : in  std_logic;
    
    BCF_EN_FSCNT_CLR_EN_IN      : in  std_logic; -- RPLS operation

    BCF_FS_ERR_FLAG_BLKCLK_OUT  : out std_logic_vector( 1 downto 0); -- BCF <-> FRSYNC Align Check, 0b1 : ERR, 0b0 : Normal
                                                                     -- [0] : RPLS, [1] : FPLS
    BCF_EN_FSCNT_BLKCLK_OUT     : out std_logic_vector(31 downto 0); -- 10ms Count Value during BCF_EN high section

    BCF_RPLS_CLKCNT_BLKCLK_OUT  : out std_logic_vector(31 downto 0); -- BCF RPLS Stamp on 10ms Counter

    BCF_EN_SFNCNT_BLKCLK_OUT    : out std_logic_vector(31 downto 0); -- BCF SFNBLK Counter


    RST_CPU                     : in  std_logic;
    CLK_CPU                     : in  std_logic;

    BCF_FS_ERR_FLAG_CPUCLK_OUT  : out std_logic_vector( 1 downto 0); -- BCF <-> FRSYNC Align Check, 0b1 : ERR, 0b0 : Normal
                                                                     -- [0] : RPLS, [1] : FPLS
    BCF_EN_FSCNT_CPUCLK_OUT     : out std_logic_vector(31 downto 0); -- 10ms Count Value during BCF_EN high section

    BCF_RPLS_CLKCNT_CPUCLK_OUT  : out std_logic_vector(31 downto 0);  -- BCF RPLS Stamp on 10ms Counter

    BCF_EN_SFNCNT_CPUCLK_OUT    : out std_logic_vector(31 downto 0) -- BCF SFNBLK Counter
    );
end BCF_FRSYNC_MON;

architecture arc_BCF_FRSYNC_MON of BCF_FRSYNC_MON is

-- BLKCLK
signal bcf_en_sh_blkclk         : std_logic_vector( 3 downto 0) := (others => '0');
signal frsync_sh_blkclk         : std_logic_vector( 1 downto 0) := (others => '0');
    
signal bcf_en_rpls_blkclk       : std_logic := '0';
signal bcf_en_fpls_blkclk       : std_logic := '0';
signal frsync_rpls_blkclk       : std_logic := '0';

signal rpls_err_pls_blkclk      : std_logic := '0';
signal fpls_err_pls_blkclk      : std_logic := '0';

signal rpls_err_pls_sh_blkclk   : std_logic_vector( 7 downto 0) := (others => '0');
signal fpls_err_pls_sh_blkclk   : std_logic_vector( 7 downto 0) := (others => '0');
    
signal rpls_err_flag_blkclk     : std_logic := '0';
signal fpls_err_flag_blkclk     : std_logic := '0';


signal clr_en_sh_blkclk         : std_logic_vector( 2 downto 0) := (others => '0');
signal clr_en_rpls_blkclk       : std_logic := '0';
signal clr_en_latch_blkclk      : std_logic := '0';
signal clr_en_latch_d1_blkclk   : std_logic := '0';
signal clr_en_latch_fpls_blkclk : std_logic := '0';

signal bcf_frsync_and_pls_blkclk: std_logic := '0';
signal bcf_en_frcnt_blkclk      : std_logic_vector(31 downto 0) := (others => '0');
signal bcf_en_frcnt_latch_blkclk: std_logic_vector(31 downto 0) := (others => '0');

signal frsync_clkcnt_blkclk     : std_logic_vector(31 downto 0) := (others => '0');
signal bcf_rpls_clkcnt_blkclk   : std_logic_vector(31 downto 0) := (others => '0');

signal bcf_en_rpls_counter      : std_logic_vector(15 downto 0) := (others => '0');
signal bcf_en_fpls_counter      : std_logic_vector(15 downto 0) := (others => '0');

-- CPUCLK
signal rpls_err_flag_sh_cpuclk  : std_logic_vector( 2 downto 0) := (others => '0');
signal fpls_err_flag_sh_cpuclk  : std_logic_vector( 2 downto 0) := (others => '0');


begin

    -- Block Clock Domain
    P_PLS_DETECT_BLKCLK : process(CLK_BLK) begin
        if (CLK_BLK'event) and (CLK_BLK = '1') then
            bcf_en_sh_blkclk   <= bcf_en_sh_blkclk(2 downto 0) & BCF_EN_BLKCLK_IN; 
            frsync_sh_blkclk   <= frsync_sh_blkclk(0) & FRSYNC_BLKCLK_IN; 

            bcf_en_rpls_blkclk <= bcf_en_sh_blkclk(0) and (not bcf_en_sh_blkclk(1)); 
            bcf_en_fpls_blkclk <= bcf_en_sh_blkclk(1) and (not bcf_en_sh_blkclk(0)); 
            frsync_rpls_blkclk <= frsync_sh_blkclk(0) and (not frsync_sh_blkclk(1)); 
        end if;
    end process;
    
    P_BCF_FRSYNC_ALIGN_CHK_BLKCLK : process(CLK_BLK) begin
        if (CLK_BLK'event) and (CLK_BLK = '1') then
            if (bcf_en_rpls_blkclk = '1') then
                if (frsync_rpls_blkclk = '1') then 
                    rpls_err_pls_blkclk <= '0';
                else
                    rpls_err_pls_blkclk <= '1';
                end if;
            else
                rpls_err_pls_blkclk <= '0';
            end if;

            if (bcf_en_fpls_blkclk = '1') then
                if (frsync_rpls_blkclk = '1') then 
                    fpls_err_pls_blkclk <= '0'; 
                else
                    fpls_err_pls_blkclk <= '1'; 
                end if;
            else
                fpls_err_pls_blkclk <= '0'; 
            end if;

            rpls_err_pls_sh_blkclk <= rpls_err_pls_sh_blkclk(6 downto 0) & rpls_err_pls_blkclk; 
            fpls_err_pls_sh_blkclk <= fpls_err_pls_sh_blkclk(6 downto 0) & fpls_err_pls_blkclk; 

            if (rpls_err_pls_sh_blkclk = x"00") then 
                rpls_err_flag_blkclk <= '0'; 
            else
                rpls_err_flag_blkclk <= '1'; 
            end if;

            if (fpls_err_pls_sh_blkclk = x"00") then 
                fpls_err_flag_blkclk <= '0'; 
            else
                fpls_err_flag_blkclk <= '1'; 
            end if;
        end if;
    end process;

    BCF_FS_ERR_FLAG_BLKCLK_OUT  <= fpls_err_flag_blkclk & rpls_err_flag_blkclk; 

    P_FRCNT_CLR_EN : process(CLK_BLK) begin
        if (CLK_BLK'event) and (CLK_BLK = '1') then
            clr_en_sh_blkclk   <= clr_en_sh_blkclk(1 downto 0) & BCF_EN_FSCNT_CLR_EN_IN; 
            clr_en_rpls_blkclk <= clr_en_sh_blkclk(1) and (not clr_en_sh_blkclk(2)); 

            if (clr_en_rpls_blkclk = '1') then 
                clr_en_latch_blkclk <= '1';
            else
                if (bcf_en_sh_blkclk(2) = '0') then 
                    if (frsync_rpls_blkclk = '1') then 
                        clr_en_latch_blkclk <= '0';
                    end if;
                end if;
            end if;

            clr_en_latch_d1_blkclk   <= clr_en_latch_blkclk; 
            clr_en_latch_fpls_blkclk <= (not clr_en_latch_blkclk) and clr_en_latch_d1_blkclk; 
        end if;
    end process;

    P_BCF_EN_FRCNT_BLKCLK : process(RST_BLK, CLK_BLK) begin
        if (RST_BLK = '1') then 
            bcf_en_frcnt_blkclk       <= (others => '0');
            bcf_en_frcnt_latch_blkclk <= (others => '0');
            bcf_frsync_and_pls_blkclk <= '0';
        elsif (CLK_BLK'event) and (CLK_BLK = '1') then
            bcf_frsync_and_pls_blkclk <= bcf_en_sh_blkclk(1) and frsync_rpls_blkclk;

            if (clr_en_latch_fpls_blkclk = '1') then 
                bcf_en_frcnt_blkclk <= (others => '0');
            elsif (bcf_frsync_and_pls_blkclk = '1') then   
                bcf_en_frcnt_blkclk <= bcf_en_frcnt_blkclk + '1';
            end if;
 
            if (bcf_en_fpls_blkclk = '1') then 
                bcf_en_frcnt_latch_blkclk <= bcf_en_frcnt_blkclk; 
            end if;
        end if;
    end process;

    BCF_EN_FSCNT_BLKCLK_OUT <= bcf_en_frcnt_latch_blkclk; 

-- kee82 added
    P_BCF_EN_SFNBLKCNT_BLKCLK : process(RST_BLK, CLK_BLK) begin
        if (RST_BLK = '1') then 
            bcf_en_rpls_counter       <= (others => '0');
            bcf_en_fpls_counter       <= (others => '0');
        elsif (CLK_BLK'event) and (CLK_BLK = '1') then
            if (clr_en_latch_fpls_blkclk = '1') then 
                bcf_en_rpls_counter <= (others => '0');
            elsif (bcf_en_rpls_blkclk = '1') then
                bcf_en_rpls_counter <= bcf_en_rpls_counter + 1;
            else
                bcf_en_rpls_counter <= bcf_en_rpls_counter;  
            end if;

            if (clr_en_latch_fpls_blkclk = '1') then 
                bcf_en_fpls_counter <= (others => '0');
            elsif (bcf_en_fpls_blkclk = '1') then
                bcf_en_fpls_counter <= bcf_en_fpls_counter + 1;
            else
                bcf_en_fpls_counter <= bcf_en_fpls_counter;  
            end if;
        end if;
    end process;

    BCF_EN_SFNCNT_BLKCLK_OUT <= bcf_en_fpls_counter & bcf_en_rpls_counter; 


    P_FRSYNC_CLKCNT_BLKCLK : process(RST_BLK, CLK_BLK) begin
        if (RST_BLK = '1') then
            frsync_clkcnt_blkclk <= (others => '0');
        elsif (CLK_BLK'event) and (CLK_BLK = '1') then
            if (frsync_rpls_blkclk = '1') then 
                frsync_clkcnt_blkclk <= (others => '0');
            else
                frsync_clkcnt_blkclk <= frsync_clkcnt_blkclk + '1';
            end if;
        end if;
    end process;

    P_BCF_RPLS_CLKCNT_BLKCLK : process(CLK_BLK) begin
        if (CLK_BLK'event) and (CLk_BLK = '1') then
            if (bcf_en_sh_blkclk(3 downto 2) = "01") then
                bcf_rpls_clkcnt_blkclk <= frsync_clkcnt_blkclk; 
            end if;
        end if;
    end process;

    BCF_RPLS_CLKCNT_BLKCLK_OUT <= bcf_rpls_clkcnt_blkclk; 

    -- CPU Domain
    P_ERR_FLAG_CDC_CPUCLK : process(CLK_CPU) begin
        if (CLK_CPU'event) and (CLK_CPU = '1') then
            rpls_err_flag_sh_cpuclk <= rpls_err_flag_sh_cpuclk(1 downto 0) & rpls_err_flag_blkclk; 
            fpls_err_flag_sh_cpuclk <= fpls_err_flag_sh_cpuclk(1 downto 0) & fpls_err_flag_blkclk; 
        end if;
    end process;

    BCF_FS_ERR_FLAG_CPUCLK_OUT  <= fpls_err_flag_sh_cpuclk(2) & rpls_err_flag_sh_cpuclk(2); 
    BCF_EN_FSCNT_CPUCLK_OUT     <= bcf_en_frcnt_latch_blkclk; 
    BCF_RPLS_CLKCNT_CPUCLK_OUT  <= bcf_rpls_clkcnt_blkclk; 
    BCF_EN_SFNCNT_CPUCLK_OUT    <= bcf_en_fpls_counter & bcf_en_rpls_counter;  

end arc_BCF_FRSYNC_MON;
