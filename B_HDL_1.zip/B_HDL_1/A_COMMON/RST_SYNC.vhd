-----------------------------------------------------------------------
-- Title      : Reset Synchronizer
-- Project    : FD-MIMO
-----------------------------------------------------------------------
-- File       : RST_SYNC.vhd
-- Author     : wisetreechoi
-----------------------------------------------------------------------
-- Revision History
-- [2016.10.13_A] Initial coding
-----------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;

entity RST_SYNC is
    generic (
        DLY_NUM        : natural := 4;    -- Number of delay.
        MAX_FANOUT_NUM : integer := 200   -- Number of maximum fanout
    );
    port (
        RST_IN  : in  std_logic;          -- Active high asynchronous reset
        CLK     : in  std_logic;          -- clock to be sync'ed to
        RST_OUT : out std_logic           -- "Synchronised" reset signal
    );         
end RST_SYNC;

-------------------------------------------------------------------------------

architecture rtl of RST_SYNC is
signal rst_synch   : std_logic_vector(DLY_NUM-1 downto 0);

attribute MAX_FANOUT : integer;
attribute MAX_FANOUT of rst_synch : signal is MAX_FANOUT_NUM;
--attribute MAX_FANOUT of rst_synch(DLY_NUM-1) : signal is MAX_FANOUT_NUM;

attribute KEEP : string;
attribute KEEP of rst_synch : signal is "TRUE";

begin

  -- Synchronizer process.
SYNC_PROC0 : process (clk, rst_in)
begin
    if rst_in = '1' then
        rst_synch(0) <= '1';
    elsif clk'event and clk = '1' then
        rst_synch(0) <= '0';
    end if;
end process;

SYNC_PROC1: if (DLY_NUM >= 2) generate
    SYNC_PROC1 : process (clk, rst_in)
    begin
        if rst_in = '1' then
            rst_synch(DLY_NUM-1 downto 1) <= (others => '1');
        elsif clk'event and clk = '1' then
            rst_synch(DLY_NUM-1 downto 1) <= rst_synch(DLY_NUM-2 downto 0);
        end if;
    end process;
end generate;

rst_out <= rst_synch(DLY_NUM-1);

end rtl;

