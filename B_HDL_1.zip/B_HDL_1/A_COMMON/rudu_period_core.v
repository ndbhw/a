module rudu_period_core (
    input  wire         axi_aclk     ,
    input  wire         axi_aresetn  ,
                                     
    input  wire [15:0]  rd_addr      ,
    output reg  [31:0]  rd_data      ,
                                      
    input  wire [15:0]  wr_addr      ,
    input  wire [31:0]  wr_data      ,
    input  wire         wr_stb       ,
                                     
    input  wire         du_clk       ,
    input  wire         ru_clk       
);

    reg         reg_resetn          ;
    wire        reg_timer_valid     ;  
    reg         reg_timer_clear     ;  
    wire [31:0] reg_timer_data      ;
    reg  [31:0] reg_clock_period    ;
                                    
    wire        cpu_clk             ;
    wire        cpu_areset          ;
    wire        cpu_aresetn         ;
                                    
    wire        du_resetn           ;
    wire [31:0] du_period           ;
    reg  [31:0] du_counter          ;
    reg         du_pps              ;
                                    
    wire        ru_resetn           ;
    wire        ru_pps              ;
    reg         ru_pps_dly          ;
    reg         ru_pps_ris          ;
    
    reg  [31:0] ru_counter          ;
    reg  [31:0] ru_timer_data       ;
    reg         ru_timer_valid      ;    
    wire        ru_timer_clear      ;
    
    assign cpu_clk     = axi_aclk  ;
        
    xpm_cdc_async_rst #(
        .DEST_SYNC_FF   (2),    
        .INIT_SYNC_FF   (0),    
        .RST_ACTIVE_HIGH(0)  
    )
    du_resetn_inst (
        .dest_arst(du_resetn   ), 
        .dest_clk (du_clk      ),   
        .src_arst (reg_resetn  )    
    );
    
    xpm_cdc_async_rst #(
        .DEST_SYNC_FF   (2),    
        .INIT_SYNC_FF   (0),    
        .RST_ACTIVE_HIGH(0)  
    )
    ru_resetn_inst (
        .dest_arst(ru_resetn   ), 
        .dest_clk (ru_clk      ),   
        .src_arst (reg_resetn  )    
    );
    
    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          (32)           
    )
    cdc_clock_period_inst (
        .dest_out(du_period          ),     
        .dest_clk(du_clk             ), 
        .src_clk (cpu_clk            ),   
        .src_in  (reg_clock_period   )      
    );

    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          (32)           
    )
    cdc_timer_data_inst (
        .dest_out(reg_timer_data     ),     
        .dest_clk(cpu_clk            ), 
        .src_clk (ru_clk             ),   
        .src_in  (ru_timer_data      )      
    );
    
    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          ( 1)           
    )
    cdc_timer_valid_inst (
        .dest_out(reg_timer_valid    ),     
        .dest_clk(cpu_clk            ), 
        .src_clk (ru_clk             ),   
        .src_in  (     )      
    );
    
    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          ( 1)           
    )
    cdc_timer_clear_inst (
        .dest_out(ru_timer_clear     ),     
        .dest_clk(ru_clk             ), 
        .src_clk (cpu_clk            ),   
        .src_in  (reg_timer_clear    )      
    );
        
    always @(posedge axi_aclk) begin
        if(axi_aresetn == 1'b0) begin   
            reg_resetn          <= 'd0;
            reg_timer_clear     <= 'd0;            
            reg_clock_period    <= 'd0;
        end                     
        else begin
            if(wr_stb == 'b1) begin
                case (wr_addr)  
                    'h0004 : reg_resetn            <= wr_data[   0]; 
                    'h0010 : reg_timer_clear       <= wr_data[   0];
                    'h0014 : reg_clock_period      <= wr_data[31:0];
                endcase  
            end
        end
    end    
    
    always @(posedge axi_aclk) begin
        if(axi_aresetn == 1'b0) begin            
            rd_data              <= 'd0;               
        end
        else begin
            case (rd_addr)  
                'h0000 : rd_data <= {8'h22, 8'h01, 16'h2025          };
                'h0004 : rd_data <= {31'd0, reg_resetn               };
                'h0008 : rd_data <= {31'd0, reg_timer_valid          };   
                'h000C : rd_data <= reg_timer_data                    ;  
                'h0010 : rd_data <= {31'd0, reg_timer_clear          }; 
                'h0014 : rd_data <= reg_clock_period                  ;                 
            endcase  
        end
    end 
    
    always @(posedge du_clk) begin
        if(du_resetn == 'b0) begin
            du_counter <= 'd0;
        end
        else begin
            if(du_counter >= du_period) begin
                du_counter <= 'd0;
            end
            else begin
                du_counter <= du_counter + 'd1;
            end            
        end
    end
    
    always @(posedge du_clk) begin
        if(du_resetn == 'b0) begin
            du_pps <= 'b0;
        end
        else begin
            if(du_counter > du_period - 'd100) begin
                du_pps <= 'b1;
            end
            else begin
                du_pps <= 'b0;
            end            
        end
    end
    
    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          ( 1)           
    )
    cdc_pps_inst (
        .dest_out(ru_pps),     
        .dest_clk(ru_clk), 
        .src_clk (du_clk),   
        .src_in  (du_pps)      
    );
    
    always @(posedge ru_clk) begin
        if(ru_resetn == 'b0) begin
            ru_pps_dly <= 'b0;
        end
        else begin
            ru_pps_dly <= ru_pps;          
        end
    end
    
    always @(posedge ru_clk) begin
        if(ru_resetn == 'b0) begin
            ru_pps_ris <= 'b0;
        end
        else begin
            if(ru_pps == 'b1 && ru_pps_dly == 'b0) begin
                ru_pps_ris <= 'b1;
            end
            else begin
                ru_pps_ris <= 'b0;
            end
        end
    end
    
    always @(posedge ru_clk) begin
        if(ru_resetn == 'b0) begin
            ru_counter <= 'd0;
        end
        else begin
            if(ru_pps_ris == 'b1) begin
                ru_counter <= 'd0;
            end
            else begin
                ru_counter <= ru_counter + 'd1;
            end            
        end
    end
    
    always @(posedge ru_clk) begin
        if(ru_resetn == 'b0) begin
            ru_timer_valid <= 'd0;
            ru_timer_data  <= 'd0;            
        end
        else begin
            if(ru_timer_clear == 'b1) begin
                ru_timer_valid <= 'd0;
                ru_timer_data  <= 'd0;
            end
            else if(ru_pps_ris == 'b1) begin
                ru_timer_valid <= 'd1;
                ru_timer_data  <= ru_counter;
            end   
            else begin
                ru_timer_valid <= ru_timer_valid;
                ru_timer_data  <= ru_timer_data ; 
            end
        end
    end
    
endmodule 

