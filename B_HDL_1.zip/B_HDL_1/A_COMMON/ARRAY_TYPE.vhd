--***************************************
-- multi-uni function library
--***************************************
--------------------------------------------------------------------------------------------------------
-- Revision History ------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--Please keep the following revision history format
--[2016.10.12_A, wisetreechoi]
----01. Revision-1
----02. Revision-2
--------------------------------------------------------------------------------------------------------
--[2016.10.12_B, wisetreechoi]
----01. add "type std_logic_array256".
--[2016.11.13_A, wisetreechoi]
----01. change "natural_array" definition
--[2016.11.17_A, jinoo.bae]
----01. add. "std_logic_array2_array32, std_logic_array2_array15, std_logic_array2_array19" 
--[2016.11.18_A, seulkee.kim]
----01. add "std_logic_array8_array1, std_logic_array8_array7"
--[2016.11.26_A, k1340.heo]
----01. add "std_logic_array2_array16"
--[2016.12.16_A, k1340.heo]
----01. add "std_logic_array4_array1"
--[2017.03.03_A, k1340.heo]
----01. add "std_logic_array14_array16", "std_logic_array32_array32"
--------------------------------------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.numeric_std.all;

package ARRAY_TYPE is

    -- Boolean array
    type boolean_array                          is array(natural range <>) of boolean;
    type natural_array                          is array(natural range <>) of natural;

    -- 2 Dimension Vector Array 
    type std_logic_array1                       is array(natural range <>) of std_logic_vector(  0 downto 0);
    type std_logic_array2                       is array(natural range <>) of std_logic_vector(  1 downto 0);
    type std_logic_array3                       is array(natural range <>) of std_logic_vector(  2 downto 0);
    type std_logic_array4                       is array(natural range <>) of std_logic_vector(  3 downto 0);
    type std_logic_array5                       is array(natural range <>) of std_logic_vector(  4 downto 0);
    type std_logic_array6                       is array(natural range <>) of std_logic_vector(  5 downto 0);
    type std_logic_array7                       is array(natural range <>) of std_logic_vector(  6 downto 0);
    type std_logic_array8                       is array(natural range <>) of std_logic_vector(  7 downto 0);
    type std_logic_array9                       is array(natural range <>) of std_logic_vector(  8 downto 0);
    type std_logic_array10                      is array(natural range <>) of std_logic_vector(  9 downto 0);
    type std_logic_array11                      is array(natural range <>) of std_logic_vector( 10 downto 0);
    type std_logic_array12                      is array(natural range <>) of std_logic_vector( 11 downto 0);
    type std_logic_array13                      is array(natural range <>) of std_logic_vector( 12 downto 0);
    type std_logic_array14                      is array(natural range <>) of std_logic_vector( 13 downto 0);
    type std_logic_array15                      is array(natural range <>) of std_logic_vector( 14 downto 0);
    type std_logic_array16                      is array(natural range <>) of std_logic_vector( 15 downto 0);
    type std_logic_array17                      is array(natural range <>) of std_logic_vector( 16 downto 0);
    type std_logic_array18                      is array(natural range <>) of std_logic_vector( 17 downto 0);
    type std_logic_array19                      is array(natural range <>) of std_logic_vector( 18 downto 0);
    type std_logic_array20                      is array(natural range <>) of std_logic_vector( 19 downto 0);
    type std_logic_array21                      is array(natural range <>) of std_logic_vector( 20 downto 0);
    type std_logic_array22                      is array(natural range <>) of std_logic_vector( 21 downto 0);
    type std_logic_array23                      is array(natural range <>) of std_logic_vector( 22 downto 0);
    type std_logic_array24                      is array(natural range <>) of std_logic_vector( 23 downto 0);
    type std_logic_array25                      is array(natural range <>) of std_logic_vector( 24 downto 0);
    type std_logic_array26                      is array(natural range <>) of std_logic_vector( 25 downto 0);
    type std_logic_array27                      is array(natural range <>) of std_logic_vector( 26 downto 0);
    type std_logic_array28                      is array(natural range <>) of std_logic_vector( 27 downto 0);
    type std_logic_array29                      is array(natural range <>) of std_logic_vector( 28 downto 0);
    type std_logic_array30                      is array(natural range <>) of std_logic_vector( 29 downto 0);
    type std_logic_array31                      is array(natural range <>) of std_logic_vector( 30 downto 0);
    type std_logic_array32                      is array(natural range <>) of std_logic_vector( 31 downto 0);
    type std_logic_array33                      is array(natural range <>) of std_logic_vector( 32 downto 0);
    type std_logic_array34                      is array(natural range <>) of std_logic_vector( 33 downto 0);
    type std_logic_array35                      is array(natural range <>) of std_logic_vector( 34 downto 0);
    type std_logic_array36                      is array(natural range <>) of std_logic_vector( 35 downto 0);
    type std_logic_array37                      is array(natural range <>) of std_logic_vector( 36 downto 0);
    type std_logic_array40                      is array(natural range <>) of std_logic_vector( 39 downto 0);
    type std_logic_array41                      is array(natural range <>) of std_logic_vector( 40 downto 0);
    type std_logic_array42                      is array(natural range <>) of std_logic_vector( 41 downto 0);
    type std_logic_array44                      is array(natural range <>) of std_logic_vector( 43 downto 0);
    type std_logic_array45                      is array(natural range <>) of std_logic_vector( 44 downto 0);
    type std_logic_array46                      is array(natural range <>) of std_logic_vector( 45 downto 0);
    type std_logic_array48                      is array(natural range <>) of std_logic_vector( 47 downto 0);
    type std_logic_array50                      is array(natural range <>) of std_logic_vector( 49 downto 0);
    type std_logic_array51                      is array(natural range <>) of std_logic_vector( 50 downto 0);
    type std_logic_array52                      is array(natural range <>) of std_logic_vector( 51 downto 0);
    type std_logic_array53                      is array(natural range <>) of std_logic_vector( 52 downto 0);
    type std_logic_array54                      is array(natural range <>) of std_logic_vector( 53 downto 0);
    type std_logic_array60                      is array(natural range <>) of std_logic_vector( 59 downto 0);
    type std_logic_array64                      is array(natural range <>) of std_logic_vector( 63 downto 0);
    type std_logic_array72                      is array(natural range <>) of std_logic_vector( 71 downto 0);
    type std_logic_array96                      is array(natural range <>) of std_logic_vector( 95 downto 0);
    type std_logic_array100                     is array(natural range <>) of std_logic_vector( 99 downto 0);
    type std_logic_array128                     is array(natural range <>) of std_logic_vector(127 downto 0);
    type std_logic_array160                     is array(natural range <>) of std_logic_vector(159 downto 0);
    type std_logic_array256                     is array(natural range <>) of std_logic_vector(255 downto 0);
    type std_logic_array512                     is array(natural range <>) of std_logic_vector(511 downto 0);
    
    -- 3 Dimension Vector Array 
    type std_logic_array4_array1                is array(natural range <>) of std_logic_array1( 3 downto 0);
    type std_logic_array8_array1                is array(natural range <>) of std_logic_array1( 7 downto 0);
    
    type std_logic_array3_array2                is array(natural range <>) of std_logic_array2( 2 downto 0);
    type std_logic_array4_array2                is array(natural range <>) of std_logic_array2( 3 downto 0);
    type std_logic_array12_array2               is array(natural range <>) of std_logic_array2(11 downto 0);

    type std_logic_array8_array3                is array(natural range <>) of std_logic_array8( 2 downto 0);
    type std_logic_array12_array3               is array(natural range <>) of std_logic_array3(11 downto 0);
    type std_logic_array15_array3               is array(natural range <>) of std_logic_array15(2 downto 0);
    type std_logic_array16_array3               is array(natural range <>) of std_logic_array16(2 downto 0);
    
    type std_logic_array2_array4                is array(natural range <>) of std_logic_array4( 1 downto 0);
    type std_logic_array3_array4                is array(natural range <>) of std_logic_array4( 2 downto 0);
    type std_logic_array5_array4                is array(natural range <>) of std_logic_array4( 4 downto 0);
    type std_logic_array8_array4                is array(natural range <>) of std_logic_array4( 7 downto 0);
    type std_logic_array12_array4               is array(natural range <>) of std_logic_array4(11 downto 0);
    type std_logic_array64_array4               is array(natural range <>) of std_logic_array4(63 downto 0);

    type std_logic_array3_array5                is array(natural range <>) of std_logic_array5( 2 downto 0);
    type std_logic_array5_array5                is array(natural range <>) of std_logic_array5( 4 downto 0);
    type std_logic_array8_array5                is array(natural range <>) of std_logic_array5( 7 downto 0);
    type std_logic_array12_array5               is array(natural range <>) of std_logic_array5(11 downto 0);
    type std_logic_array64_array5               is array(natural range <>) of std_logic_array5(63 downto 0);
    
    type std_logic_array2_array6                is array(natural range <>) of std_logic_array6( 1 downto 0);
    type std_logic_array3_array6                is array(natural range <>) of std_logic_array6( 2 downto 0);
    
    type std_logic_array2_array7                is array(natural range <>) of std_logic_array7( 1 downto 0);
    type std_logic_array3_array7                is array(natural range <>) of std_logic_array7( 2 downto 0);
    type std_logic_array8_array7                is array(natural range <>) of std_logic_array7( 7 downto 0);
    type std_logic_array12_array7               is array(natural range <>) of std_logic_array7(11 downto 0);
    
    type std_logic_array2_array8                is array(natural range <>) of std_logic_array8( 1 downto 0);
    type std_logic_array3_array8                is array(natural range <>) of std_logic_array8( 2 downto 0);
    type std_logic_array4_array8                is array(natural range <>) of std_logic_array8( 3 downto 0);
    type std_logic_array5_array8                is array(natural range <>) of std_logic_array8( 4 downto 0);
    type std_logic_array7_array8                is array(natural range <>) of std_logic_array8( 6 downto 0);
	type std_logic_array10_array8               is array(natural range <>) of std_logic_array8( 9 downto 0);
    type std_logic_array12_array8               is array(natural range <>) of std_logic_array8(11 downto 0);
    type std_logic_array16_array8               is array(natural range <>) of std_logic_array8(15 downto 0);
    type std_logic_array64_array8               is array(natural range <>) of std_logic_array8(63 downto 0);
    
    type std_logic_array3_array9                is array(natural range <>) of std_logic_array9( 2 downto 0);
    type std_logic_array4_array9                is array(natural range <>) of std_logic_array9( 3 downto 0);
    type std_logic_array5_array9                is array(natural range <>) of std_logic_array9( 4 downto 0);
    type std_logic_array6_array9                is array(natural range <>) of std_logic_array9( 5 downto 0);
    type std_logic_array7_array9                is array(natural range <>) of std_logic_array9( 6 downto 0);
    type std_logic_array8_array9                is array(natural range <>) of std_logic_array9( 7 downto 0);
    type std_logic_array9_array9                is array(natural range <>) of std_logic_array9( 8 downto 0);
    type std_logic_array10_array9               is array(natural range <>) of std_logic_array9( 9 downto 0);
    type std_logic_array11_array9               is array(natural range <>) of std_logic_array9(10 downto 0);
    type std_logic_array13_array9               is array(natural range <>) of std_logic_array9(12 downto 0);
    type std_logic_array14_array9               is array(natural range <>) of std_logic_array9(13 downto 0);
    type std_logic_array15_array9               is array(natural range <>) of std_logic_array9(14 downto 0);
    type std_logic_array16_array9               is array(natural range <>) of std_logic_array9(15 downto 0);
    type std_logic_array17_array9               is array(natural range <>) of std_logic_array9(16 downto 0);
    type std_logic_array20_array9               is array(natural range <>) of std_logic_array9(19 downto 0);
    type std_logic_array32_array9               is array(natural range <>) of std_logic_array9(31 downto 0);
    type std_logic_array35_array9               is array(natural range <>) of std_logic_array9(34 downto 0);
    type std_logic_array41_array9               is array(natural range <>) of std_logic_array9(40 downto 0);
    type std_logic_array44_array9               is array(natural range <>) of std_logic_array9(43 downto 0);
    
    type std_logic_array2_array10               is array(natural range <>) of std_logic_array10( 1 downto 0);
    type std_logic_array3_array10               is array(natural range <>) of std_logic_array10( 2 downto 0);
    type std_logic_array5_array10               is array(natural range <>) of std_logic_array10( 4 downto 0);
    type std_logic_array6_array10               is array(natural range <>) of std_logic_array10( 5 downto 0);
    type std_logic_array7_array10               is array(natural range <>) of std_logic_array10( 6 downto 0);
    type std_logic_array8_array10               is array(natural range <>) of std_logic_array10( 7 downto 0);
    type std_logic_array9_array10               is array(natural range <>) of std_logic_array10( 8 downto 0);
    type std_logic_array10_array10              is array(natural range <>) of std_logic_array10( 9 downto 0);
    type std_logic_array12_array10              is array(natural range <>) of std_logic_array10(11 downto 0);
    type std_logic_array16_array10              is array(natural range <>) of std_logic_array10(15 downto 0);
    type std_logic_array17_array10              is array(natural range <>) of std_logic_array10(16 downto 0);
    type std_logic_array20_array10              is array(natural range <>) of std_logic_array10(19 downto 0);
    type std_logic_array32_array10              is array(natural range <>) of std_logic_array10(31 downto 0);
    type std_logic_array35_array10              is array(natural range <>) of std_logic_array10(34 downto 0);
    type std_logic_array41_array10              is array(natural range <>) of std_logic_array10(40 downto 0);
    type std_logic_array44_array10              is array(natural range <>) of std_logic_array10(43 downto 0);
    type std_logic_array64_array10              is array(natural range <>) of std_logic_array10(63 downto 0);

    type std_logic_array2_array11               is array(natural range <>) of std_logic_array11( 1 downto 0);
    type std_logic_array3_array11               is array(natural range <>) of std_logic_array11( 2 downto 0);
    type std_logic_array8_array11               is array(natural range <>) of std_logic_array11( 7 downto 0);
    type std_logic_array16_array11              is array(natural range <>) of std_logic_array11(15 downto 0);
    type std_logic_array64_array11              is array(natural range <>) of std_logic_array11(63 downto 0);
    
    type std_logic_array2_array12               is array(natural range <>) of std_logic_array12( 1 downto 0);
    type std_logic_array3_array12               is array(natural range <>) of std_logic_array12( 2 downto 0);
    type std_logic_array4_array12               is array(natural range <>) of std_logic_array12( 3 downto 0);
    type std_logic_array5_array12               is array(natural range <>) of std_logic_array12( 4 downto 0);
    type std_logic_array12_array12              is array(natural range <>) of std_logic_array12(11 downto 0);
    type std_logic_array32_array12              is array(natural range <>) of std_logic_array12(31 downto 0);
    
    type std_logic_array2_array13               is array(natural range <>) of std_logic_array13( 1 downto 0);
    type std_logic_array3_array13               is array(natural range <>) of std_logic_array13( 2 downto 0);
    type std_logic_array5_array13               is array(natural range <>) of std_logic_array13( 4 downto 0);
    
    type std_logic_array2_array14               is array(natural range <>) of std_logic_array14( 1 downto 0);
    type std_logic_array3_array14               is array(natural range <>) of std_logic_array14( 2 downto 0);
    type std_logic_array5_array14               is array(natural range <>) of std_logic_array14( 4 downto 0);
    type std_logic_array16_array14              is array(natural range <>) of std_logic_array14(15 downto 0);
    
    type std_logic_array2_array15               is array(natural range <>) of std_logic_array15( 1 downto 0);
    type std_logic_array3_array15               is array(natural range <>) of std_logic_array15( 2 downto 0);
    type std_logic_array4_array15               is array(natural range <>) of std_logic_array15( 3 downto 0);
    type std_logic_array5_array15               is array(natural range <>) of std_logic_array15( 4 downto 0);
    type std_logic_array6_array15               is array(natural range <>) of std_logic_array15( 5 downto 0);
    type std_logic_array7_array15               is array(natural range <>) of std_logic_array15( 6 downto 0);
    type std_logic_array8_array15               is array(natural range <>) of std_logic_array15( 7 downto 0);
    type std_logic_array16_array15              is array(natural range <>) of std_logic_array16(14 downto 0);
    
    type std_logic_array2_array16               is array(natural range <>) of std_logic_array16( 1 downto 0);    
    type std_logic_array3_array16               is array(natural range <>) of std_logic_array16( 2 downto 0);
    type std_logic_array4_array16               is array(natural range <>) of std_logic_array16( 3 downto 0);
    type std_logic_array5_array16               is array(natural range <>) of std_logic_array16( 4 downto 0);
    type std_logic_array6_array16               is array(natural range <>) of std_logic_array16( 5 downto 0);
    type std_logic_array7_array16               is array(natural range <>) of std_logic_array16( 6 downto 0);
    type std_logic_array8_array16               is array(natural range <>) of std_logic_array16( 7 downto 0);
    type std_logic_array10_array16              is array(natural range <>) of std_logic_array16( 9 downto 0);
    type std_logic_array12_array16              is array(natural range <>) of std_logic_array16(11 downto 0);
    type std_logic_array13_array16              is array(natural range <>) of std_logic_array16(12 downto 0);
    type std_logic_array14_array16              is array(natural range <>) of std_logic_array16(13 downto 0);
    type std_logic_array15_array16              is array(natural range <>) of std_logic_array16(14 downto 0);
    type std_logic_array16_array16              is array(natural range <>) of std_logic_array16(15 downto 0);
    type std_logic_array17_array16              is array(natural range <>) of std_logic_array16(16 downto 0);
    type std_logic_array20_array16              is array(natural range <>) of std_logic_array16(19 downto 0);
    type std_logic_array29_array16              is array(natural range <>) of std_logic_array16(28 downto 0);
    type std_logic_array32_array16              is array(natural range <>) of std_logic_array16(31 downto 0);
    type std_logic_array35_array16              is array(natural range <>) of std_logic_array16(34 downto 0);
    type std_logic_array41_array16              is array(natural range <>) of std_logic_array16(40 downto 0);
    type std_logic_array44_array16              is array(natural range <>) of std_logic_array16(43 downto 0);
    type std_logic_array48_array16              is array(natural range <>) of std_logic_array16(47 downto 0);
    type std_logic_array64_array16              is array(natural range <>) of std_logic_array16(63 downto 0);
    
    type std_logic_array2_array17               is array(natural range <>) of std_logic_array17( 1 downto 0);
    type std_logic_array3_array17               is array(natural range <>) of std_logic_array17( 2 downto 0);
    type std_logic_array5_array17               is array(natural range <>) of std_logic_array17( 4 downto 0);
    
    type std_logic_array5_array18               is array(natural range <>) of std_logic_array18( 4 downto 0);

    type std_logic_array2_array19               is array(natural range <>) of std_logic_array19( 1 downto 0);
    type std_logic_array5_array19               is array(natural range <>) of std_logic_array19( 4 downto 0);
                               
    type std_logic_array2_array20               is array(natural range <>) of std_logic_array20( 1 downto 0);
    type std_logic_array3_array20               is array(natural range <>) of std_logic_array20( 2 downto 0);
    type std_logic_array4_array20               is array(natural range <>) of std_logic_array20( 3 downto 0);
    type std_logic_array5_array20               is array(natural range <>) of std_logic_array20( 4 downto 0);
    type std_logic_array9_array20               is array(natural range <>) of std_logic_array20( 8 downto 0);
    type std_logic_array12_array20              is array(natural range <>) of std_logic_array20(11 downto 0);
    
    type std_logic_array5_array22               is array(natural range <>) of std_logic_array22( 4 downto 0);
    type std_logic_array16_array22              is array(natural range <>) of std_logic_array22(15 downto 0);
    
    type std_logic_array8_array24               is array(natural range <>) of std_logic_array24( 7 downto 0);
    
    type std_logic_array3_array25               is array(natural range <>) of std_logic_array25( 2 downto 0);
    type std_logic_array5_array25               is array(natural range <>) of std_logic_array25( 4 downto 0);
    
    type std_logic_array2_array26               is array(natural range <>) of std_logic_array26( 1 downto 0);
    type std_logic_array3_array26               is array(natural range <>) of std_logic_array26( 2 downto 0);
    
    type std_logic_array2_array27               is array(natural range <>) of std_logic_array27( 1 downto 0);
    type std_logic_array3_array27               is array(natural range <>) of std_logic_array27( 2 downto 0);
    type std_logic_array4_array27               is array(natural range <>) of std_logic_array27( 3 downto 0);
    type std_logic_array7_array27               is array(natural range <>) of std_logic_array27( 6 downto 0);
    type std_logic_array8_array27               is array(natural range <>) of std_logic_array27( 7 downto 0);
    type std_logic_array10_array27              is array(natural range <>) of std_logic_array27( 9 downto 0);
    type std_logic_array13_array27              is array(natural range <>) of std_logic_array27(12 downto 0);
    type std_logic_array14_array27              is array(natural range <>) of std_logic_array27(13 downto 0);
    type std_logic_array29_array27              is array(natural range <>) of std_logic_array27(28 downto 0);
    type std_logic_array2_array28               is array(natural range <>) of std_logic_array28( 1 downto 0);
    type std_logic_array4_array28               is array(natural range <>) of std_logic_array28( 3 downto 0);
    
    type std_logic_array2_array29               is array(natural range <>) of std_logic_array29( 1 downto 0);
    type std_logic_array3_array29               is array(natural range <>) of std_logic_array29( 2 downto 0);
    
    type std_logic_array16_array30              is array(natural range <>) of std_logic_array30(15 downto 0);

    type std_logic_array5_array31               is array(natural range <>) of std_logic_array31( 4 downto 0);
    
    type std_logic_array2_array32               is array(natural range <>) of std_logic_array32( 1 downto 0);
    type std_logic_array4_array32               is array(natural range <>) of std_logic_array32( 3 downto 0);
    type std_logic_array6_array32               is array(natural range <>) of std_logic_array32( 5 downto 0);
    type std_logic_array8_array32               is array(natural range <>) of std_logic_array32( 7 downto 0);
    type std_logic_array10_array32              is array(natural range <>) of std_logic_array32( 9 downto 0);
    type std_logic_array12_array32              is array(natural range <>) of std_logic_array32(11 downto 0);
    type std_logic_array16_array32              is array(natural range <>) of std_logic_array32(15 downto 0);
    type std_logic_array17_array32              is array(natural range <>) of std_logic_array32(16 downto 0);
    type std_logic_array20_array32              is array(natural range <>) of std_logic_array32(19 downto 0);
    type std_logic_array32_array32              is array(natural range <>) of std_logic_array32(31 downto 0);
    type std_logic_array35_array32              is array(natural range <>) of std_logic_array32(34 downto 0);
    type std_logic_array41_array32              is array(natural range <>) of std_logic_array32(40 downto 0);
    type std_logic_array44_array32              is array(natural range <>) of std_logic_array32(43 downto 0);
    type std_logic_array64_array32              is array(natural range <>) of std_logic_array32(63 downto 0);

    type std_logic_array5_array34               is array(natural range <>) of std_logic_array34( 4 downto 0);

    type std_logic_array16_array35              is array(natural range <>) of std_logic_array35(15 downto 0);
   
    type std_logic_array16_array60              is array(natural range <>) of std_logic_array60(15 downto 0);
    
    type std_logic_array5_array64               is array(natural range <>) of std_logic_array64( 4 downto 0);
    type std_logic_array8_array64               is array(natural range <>) of std_logic_array64( 7 downto 0);
    
    type std_logic_array10_array26              is array(natural range <>) of std_logic_array26(9 downto 0);
    type std_logic_array3_array18               is array(natural range <>) of std_logic_array18(2 downto 0);
    type std_logic_array2_array31               is array(natural range <>) of std_logic_array31(1 downto 0);
    type std_logic_array14_array12_array4       is array(natural range <>) of std_logic_array12_array4(13 downto 0);
    type std_logic_array50_array10_array8       is array(natural range <>) of std_logic_array10_array8(49 downto 0);
end ARRAY_TYPE;

package body ARRAY_TYPE is

end ARRAY_TYPE;
