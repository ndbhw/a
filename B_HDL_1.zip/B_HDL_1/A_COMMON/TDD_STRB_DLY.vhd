-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name : TDD_STRB_DLY 
-- Project    : CP10_42A, 3.5G KDDI Low power
-- Structure  : 

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity TDD_STRB_DLY is
generic(
    CLK_CNTDLY      : integer        -- 0 ~ 8191 clock
    );
port(
    RST             : in  std_logic; -- Active high reset
    CLK             : in  std_logic; -- Clock
    
    BLK_BYPASS_IN   : in  std_logic; -- '0' normal mode, '1' bypass mode
    
    BFN_STROBE_IN   : in  std_logic;
    TDD_STROBE_IN   : in  std_logic;

    BFNSTRB_DLY_OUT : out std_logic;
    TDDSTRB_DLY_OUT : out std_logic
    );
end TDD_STRB_DLY;

architecture arc_TDD_STRB_DLY of TDD_STRB_DLY is

component CNTDLY is
generic(
    CLK_CNTDLY : integer  -- 0 ~ 8191
    );
port(
    RST        : in  std_logic;
    CLK        : in  std_logic;
    
    SIGNAL_IN  : in  std_logic;
    
    SIGNAL_OUT : out std_logic
    );
end component;

component SRL_DLY is
generic(
    BIT_WIDTH : natural;
    DELAY_NUM : natural
    );
port(
    RST       : in  std_logic; -- Active high
    CLK       : in  std_logic;
    
    DATA_IN   : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_COUT : out std_logic_vector(BIT_WIDTH-1 downto 0);
    DATA_OUT  : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end component;

constant dly_value   : std_logic_vector(12 downto 0) := (conv_std_logic_vector(CLK_CNTDLY, 13));

signal bfn_strb_sh   : std_logic_vector( 1 downto 0);
signal tdd_strb_sh   : std_logic_vector( 1 downto 0);

signal bfn_strb_srl  : std_logic_array1( 6 downto 0);
signal tdd_strb_srl  : std_logic_array1( 6 downto 0);

signal bfn_strb_dly  : std_logic;
signal tdd_strb_dly  : std_logic;

signal blk_bypass_sh : std_logic_vector( 3 downto 0);

begin

    P_Double_Clocking : process(RST, CLK) begin
        if (RST = '1') then
            bfn_strb_sh <= (others => '0');
            tdd_strb_sh <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            bfn_strb_sh <= bfn_strb_sh(0) & BFN_STROBE_IN;
            tdd_strb_sh <= tdd_strb_sh(0) & TDD_STROBE_IN;
        end if;
    end process;

    bfn_strb_srl(0)(0) <= BFN_STROBE_IN; 
    tdd_strb_srl(0)(0) <= TDD_STROBE_IN; 

    G_SRL16E_Delay : if (CLK_CNTDLY < 161) generate begin

        G_REMAIN_0 : if (CLK_CNTDLY mod 32) = 0 generate begin
            G_QUOTIENT_0 : if (CLK_CNTDLY/32 = 0) generate begin
                bfn_strb_srl(6) <= bfn_strb_srl(0) ; 
                tdd_strb_srl(6) <= tdd_strb_srl(0) ; 
            end generate;

            G_QUOTIENT_1 : if (CLK_CNTDLY/32 = 1) generate begin
                U_BFN_STRB_SRLDLY_1 : SRL_DLY generic map(1, 31) port map(RST, CLK, bfn_strb_srl(0), open, bfn_strb_srl(6));
                U_TDD_STRB_SRLDLY_1 : SRL_DLY generic map(1, 31) port map(RST, CLK, tdd_strb_srl(0), open, tdd_strb_srl(6));
            end generate;

            G_QUOTIENT_N : if (CLK_CNTDLY/32 > 1) generate begin
                 G_STAGE : for I in 0 to ((CLK_CNTDLY/32)-1) generate begin
                     G_STAGE_NORMAL : if (I < (CLK_CNTDLY/32)-1) generate begin
                        U_BFN_STRB_SRLDLY_STG : SRL_DLY generic map(1, 32) port map(RST, CLK, bfn_strb_srl(I), bfn_strb_srl(I+1), open);
                        U_TDD_STRB_SRLDLY_STG : SRL_DLY generic map(1, 32) port map(RST, CLK, tdd_strb_srl(I), tdd_strb_srl(I+1), open);
                     end generate;

                     G_STAGE_FILNAL : if (I = (CLK_CNTDLY/32)-1) generate begin
                        U_BFN_STRB_SRL_DLY_FIN : SRL_DLY generic map(1, 31) port map(RST, CLK, bfn_strb_srl(I), open, bfn_strb_srl(6));
                        U_TDD_STRB_SRL_DLY_FIN : SRL_DLY generic map(1, 31) port map(RST, CLK, tdd_strb_srl(I), open, tdd_strb_srl(6));
                     end generate;

                 end generate;
             end generate;
        end generate;

        G_REMAIN_R : if (CLK_CNTDLY mod 32) > 0 generate begin
            G_QUOTIENT_0 : if (CLK_CNTDLY/32 = 0) generate begin
                U_BFN_STRB_SRLDLY_0 : SRL_DLY generic map(1, (CLK_CNTDLY mod 32)-1) port map(RST, CLK, bfn_strb_srl(0), open, bfn_strb_srl(6));
                U_TDD_STRB_SRLDLY_0 : SRL_DLY generic map(1, (CLK_CNTDLY mod 32)-1) port map(RST, CLK, tdd_strb_srl(0), open, tdd_strb_srl(6));
            end generate;

            G_QUOTIENT_N : if (CLK_CNTDLY/32 > 0) generate begin
                 G_STAGE : for I in 0 to ((CLK_CNTDLY/32)-1) generate begin
                     U_BFN_STRB_SRLDLY_STG : SRL_DLY generic map(1, 32) port map(RST, CLK, bfn_strb_srl(I), bfn_strb_srl(I+1), open);
                     U_TDD_STRB_SRLDLY_STG : SRL_DLY generic map(1, 32) port map(RST, CLK, tdd_strb_srl(I), tdd_strb_srl(I+1), open);
                 end generate;

                 U_BFN_STRB_SRLDLY_FIN : SRL_DLY generic map(1, (CLK_CNTDLY mod 32)-1) port map(RST, CLK, bfn_strb_srl(CLK_CNTDLY/32), open, bfn_strb_srl(6));
                 U_TDD_STRB_SRLDLY_FIN : SRL_DLY generic map(1, (CLK_CNTDLY mod 32)-1) port map(RST, CLK, tdd_strb_srl(CLK_CNTDLY/32), open, tdd_strb_srl(6));

             end generate;
        end generate;

        bfn_strb_dly <= bfn_strb_srl(6)(0);
        tdd_strb_dly <= tdd_strb_srl(6)(0);
    end generate;

    G_CLKCNT_Delay : if (CLK_CNTDLY > 160) generate begin
        U_BFN_STRB_CNT_DLY : CNTDLY generic map(CLK_CNTDLY-1) port map(RST, CLK, BFN_STROBE_IN, bfn_strb_dly);
        U_TDD_STRB_CNT_DLY : CNTDLY generic map(CLK_CNTDLY-1) port map(RST, CLK, TDD_STROBE_IN, tdd_strb_dly);
    end generate;

    P_Bypass_PipeLining : process(RST, CLK) begin
        if (RST = '1') then        
            blk_bypass_sh <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            blk_bypass_sh <= blk_bypass_sh(2 downto 0) & BLK_BYPASS_IN;
        end if;
    end process;

    P_STRB_DLY_Out : process(RST, CLK) begin
        if (RST = '1') then
            BFNSTRB_DLY_OUT <= '0';
            TDDSTRB_DLY_OUT <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (blk_bypass_sh(3) = '1') then                -- Bypass mode
                BFNSTRB_DLY_OUT <= BFN_STROBE_IN;
                TDDSTRB_DLY_OUT <= TDD_STROBE_IN;
            else
                case (dly_value) is
                    when "0000000000000" =>
                        BFNSTRB_DLY_OUT <= bfn_strb_sh(1);
                        TDDSTRB_DLY_OUT <= tdd_strb_sh(1);
                    when "0000000000001" =>
                        BFNSTRB_DLY_OUT <= bfn_strb_sh(1);
                        TDDSTRB_DLY_OUT <= tdd_strb_sh(1);
                    when "0000000000010" =>
                        BFNSTRB_DLY_OUT <= bfn_strb_sh(1);
                        TDDSTRB_DLY_OUT <= tdd_strb_sh(1);
                    when others =>
                        BFNSTRB_DLY_OUT <= bfn_strb_dly;
                        TDDSTRB_DLY_OUT <= tdd_strb_dly;
                end case;
            end if;
        end if;
    end process;

end arc_TDD_STRB_DLY;


