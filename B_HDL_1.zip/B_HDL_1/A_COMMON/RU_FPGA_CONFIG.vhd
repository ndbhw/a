--------------------------------------------------------------------------------------------------------
-- RU_FPGA_CONFIG.vhd -------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------
-- Revision History ------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--Please keep the following revision history format
--[2017.05.09_A, chany.lee]
--  first_draft
--  01. RF_BAND_INDICATOR parameter added

--[2017.05.16_A, wykim]
-- SADUMP update
-- GPIO update
--[2017.05.18_A, sh3945.kim]
-- added PIMSPHY_TOP parameters
--[2017.05.19_A, seulki.kim]
-- added DCIF parameters
--[2017.05.19_A, chany.lee]
-- add TXIC_NUM, RXIC_NUM constant
--[2017.05.24_A, sh3945.kim]
--  01. PIMSPHY parameter modified
-- [2017.05.23_A, k1340.heo]
---- 01. Added DPD/PIM Q point selection Parameter
--[2017.05.24_B, hr.son]
--  01. DSPTOP/DDUC parameter modified
-- [2017.05.25_A, k1340.heo]
---- 01. Modified DPD/PIM Parameters
-- [2017.05.25_A, k1340.heo]
---- 01. Added DPD/PIM Q point selection Parameter
-- [2017.05.28_A, k1340.heo]
---- 01. Added OPR_CLK_UL_PATH Parameter
-- [2017.06.07_A, sh3945.kim]
---- 01. Changed SBIFPHY/PIMSPHY parameters
-- [2017.06.07_B, wy7916.kim]
---- 01. SADUMP parameter change
-- [2017.06.07_C, chany.lee]
---- 01. FB_PATH_NUM parameter change 2 => 1
-- [2017.06.24A, k1340.heo]
---- 01. Added DPD/PIM_CORE LUT ReadbackTest Enable/Disable Parameter
-- [2017.07.21A, hr.son]
---- 01. removed PIM_SRC_SEL
-- [2019.02.15A, k1340.heo]
---- 01. Changed PIM Structure : Inter -> Intra
--------------------------------------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.numeric_std.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

package RU_FPGA_CONFIG is

--******************************************************************
-- RU System Information
--******************************************************************
    constant C_SYSCTRL_IMG_DATE             : std_logic_vector(31 downto 0):= X"2023_1211";
    constant C_SYSCTRL_IMG_VER              : std_logic_vector(31 downto 0):= X"C830_9103";
    constant C_SYSCTRL_SYSTEM_INFO0         : std_logic_vector(31 downto 0):= X"0000_0001";     -- air_tech[3:0]
    constant C_SYSCTRL_SYSTEM_INFO1         : std_logic_vector(31 downto 0):= X"0000_0B11";     -- freq_band[7:0]
    constant C_SYSCTRL_SYSTEM_INFO2         : std_logic_vector(31 downto 0):= X"0000_0000";     -- freq_band[7:0]
    constant C_SYSCTRL_SYSTEM_INFO3         : std_logic_vector(31 downto 0):= X"0204_0402";     -- fb_path_num, rx_ant_num, tx_ant_num,cpri_num
    constant C_SYSCTRL_PBA_INFO             : std_logic_vector(31 downto 0):= X"0000_0000";
    constant C_SYSCTRL_DEV_INFO             : std_logic_vector(31 downto 0):= X"0000_0000";
    constant C_SYSCTRL_MODULE_INFO          : std_logic_vector(31 downto 0):= X"0000_0001";
    constant C_SYSCTRL_STRUCT_INFO          : std_logic_vector(31 downto 0):= X"0000_0000";
    constant C_SYSCTRL_MODULE_DATE          : std_logic_vector(31 downto 0):= X"2023_0913";

    constant C_ANNEX_MODULE_INFO            : std_logic_vector(31 DOWNTO 0):= X"FF00_0001";
    constant C_ANNEX_MODULE_DATE            : std_logic_vector(31 DOWNTO 0):= X"2016_1010";

    constant PBA_NAME                       : string  :="RF2240_11B";
    constant VENDOR                         : string  :="XILINX";
    constant FAMILY                         : string  :="KINTEXULTRASCALEPLUS";
    constant PART_NO                        : string  :="XCZU15EG-L1FFVB1156I";
    constant RF_BAND_INDICATOR              : string  :="B11";

    constant DUPLEX_TYPE                    : string  := "FDD";
    constant RFIC_NUM                       : natural :=  1;
    constant TXIC_NUM                       : natural :=  1;
    constant RXIC_NUM                       : natural :=  1;
    constant LED_NUM                        : natural :=  4;      -- Number of LEDs
    constant CPRI_NUM                       : natural :=  2;
	constant ECPRIPHY_NUM                   : natural :=  2;
    constant AURORA_NUM                     : natural :=  1;
    constant BBTOP_NUM                      : natural :=  1;
    constant IQCOMP_NUM                     : natural :=  1;
    constant SBIF_NUM                       : natural :=  1;
    constant PIM_SBIF_NUM                   : natural :=  1;
    constant CSREF_NUM                      : natural :=  2;
    constant SSREF_NUM                      : natural :=  1;
    constant JSREF_NUM                      : natural :=  1;       -- Number of SERDES reference for JESD interface
    constant ASREF_NUM                      : natural :=  1;

    constant TX_ANT_NUM                     : natural :=  2;
    constant RX_ANT_NUM                     : natural :=  2;
    constant FB_PATH_NUM                    : natural :=  1;

--******************************************************************
-- Configuration : LPHY_TOP
--******************************************************************
    constant CELL_NUM                       : natural := 2 ;
    constant DL_MAX_CC                      : natural := 1 ;
    constant DL_NUM_CC                      : natural := 1 ;
    constant UL_MAX_CC                      : natural := 1 ;
    constant UL_NUM_CC                      : natural := 1 ;
    constant DL_NUM_LAYER                   : natural := 2 ;
    constant PATH_NUM                       : natural := 2 ;
    constant DL_NUM_ANT                     : natural := 2 ;
    constant UL_NUM_PATH                    : natural := 2 ;
    constant UL_NUM_ANT                     : natural := 2 ;
    constant TOP_DIO_BW                     : natural := 16;
    constant CPUIF_ADDR_BW                  : natural := 16;
    constant CPUIF_DATA_BW                  : natural := 32;

--******************************************************************
-- RFIC Interface GPIO Assign
--******************************************************************
    constant RXIC0_B2_ADC_HB2_OVRG_A        : natural := 13;
    constant RXIC0_B2_ADC_HB2_OVRG_B        : natural :=  9;
    constant RXIC1_B2_ADC_HB2_OVRG_C        : natural := 13;
    constant RXIC1_B2_ADC_HB2_OVRG_D        : natural :=  9;
    constant RFIC_B13_ORX_TRIGGER           : natural :=  9;
    constant RFIC_B13_TXOBS_SELECT          : natural := 13;
    constant RFIC_B13_ORXMODE0              : natural := 16;
    constant RFIC_B13_ORXMODE1              : natural := 17;
    constant RFIC_B13_ORXMODE2              : natural := 18;
    constant RFIC_B13_RX_ADC_HB2_OVRG_A     : natural :=  5;
    constant RFIC_B13_RX_ADC_HB2_OVRG_B     : natural :=  1;
    constant RFIC_UPPER_LEVEL_BLOCKER_0     : natural :=  6;
    constant RFIC_UPPER_LEVEL_BLOCKER_1     : natural :=  2;
--******************************************************************
-- Configuration : CPU_TOP
--******************************************************************
    constant EMAC_NUM                       : natural :=  2;      -- Number of Ethernet MACs
    constant EPHY_NUM                       : natural :=  2;      -- The Number of Ethernet PHY
    constant QSPI_NUM                       : natural :=  1;      -- Number of QSPI IPs
    constant SPI_NUM                        : natural :=  5;      -- Number of SPI IPs, 4
    constant IIC_NUM                        : natural :=  6;      -- Number of IIC IPs
    constant UART_NUM                       : natural :=  2;      -- Number of UART IPs
    constant GPIO_CPU_NUM                   : natural :=  0;      -- Number of GPIO PS ports
    constant GPIO_IP_NUM                    : natural := 14;      -- Number of GPIO IP ports

    constant JESD_TX_LINK_NUM               : natural :=  1;      -- Number of TX Links
    constant JESD_RX_LINK_NUM               : natural :=  1;      -- Number of RX Links
    constant JESD_FB_LINK_NUM               : natural :=  1;      -- Number of FB Links
    constant JESD_TX_LANE_NUM               : natural :=  4;      -- Number of TX Lanes
    constant JESD_RX_LANE_NUM               : natural :=  2;      -- Number of RX Lanes
    constant JESD_FB_LANE_NUM               : natural :=  2;      -- Number of FB Lanes

    constant ADDR_WIDTH                     : natural := 16 ;    -- CPU Address Bitwidth
    constant WDATA_WIDTH                    : natural := 32 ;    -- CPU Write Data Bitwidth
    constant RDATA_WIDTH                    : natural := 32 ;    -- CPU Read  Data Bitwidth

--******************************************************************
-- Configuration : CPUIF_TOP
--******************************************************************

--******************************************************************
-- Configuration : SYSCTRL_TOP
--******************************************************************
    constant USAGE_CLK_SYS                  : boolean := true;
    constant USAGE_CLK_SYSX2                : boolean := false;
    constant USAGE_CLK_SYSX3                : boolean := false;
    constant USAGE_CLK_SYSX4                : boolean := true;
    constant USAGE_CLK_SYSX5                : boolean := false;
    constant USAGE_CLK_SYSX6                : boolean := false;
    constant USAGE_CLK_SYSX8                : boolean := true;
    constant USAGE_CLK_SYSX10               : boolean := false;
    constant USAGE_CLK_SYSX12               : boolean := false;
    constant USAGE_CLK_SYSX16               : boolean := false;
    constant USAGE_CLK_SYSX20               : boolean := false;

--******************************************************************
-- Configuration : CPRIPHY_TOP
--******************************************************************
    -- CPRIPHY_TOP/SBIFPHY_TOP Common
    constant CPRIPHY_MAXFANOUT              : integer                       := 200;             -- Attribute for RST_SYNC Module MAXFANOUT

    -- CPRIPHY_TOP!!!
    -- Project/PBA Type
    constant CPRIPHY_PBA_TYPE               : std_logic_vector( 7 downto 0) := x"05";           -- Gbps SI Setting

    -- Port-related
    constant CPRIPHY_IBERT_IMP              : std_logic_vector(11 downto 0) := "000000000000";  -- In System IBERT Implementation
    constant CPRIPHY_UEB_USAGE              : std_logic_vector(11 downto 0) := "111111111111";  -- User Elastic Buffer
    constant CPRIPHY_TX_POLARITY_INVERT     : std_logic_vector(11 downto 0) := "000000000000";  -- TX Polarity Invert
    constant CPRIPHY_QPLL_USED              : std_logic_vector(11 downto 0) := "111111111111";  -- Xilinx Quad PLL
    constant CPRIPHY_QPLL_IMP               : std_logic_vector( 2 downto 0) := "111";           -- QPLL Implementation

    -- etc.
    constant CPRIPHY_ADDR                   : std_logic_vector( 1 downto 0) := "11";            -- Address 0x000 ~ 0x7FF

    -- SBIFPHY_TOP!!!
    -- Project/PBA Type
    constant SBIFPHY_PBA_TYPE               : std_logic_vector( 7 downto 0) := x"0A";           -- Gbps SI Setting
    constant PIMSPHY_PBA_TYPE               : std_logic_vector( 7 downto 0) := x"0A";           -- Gbps SI Setting

    -- Port-related
    constant SBIFPHY_IBERT_IMP              : std_logic_vector(11 downto 0) := "000000000000";  -- In System IBERT Implementation
    constant SBIFPHY_UEB_USAGE              : std_logic_vector(11 downto 0) := "000000000000";  -- User Elastic Buffer
    constant SBIFPHY_TX_POLARITY_INVERT     : std_logic_vector(11 downto 0) := "000000000000";  -- TX Polarity Invert
    constant SBIFPHY_QPLL_USED              : std_logic_vector(11 downto 0) := "111111111111";  -- Xilinx Quad PLL
    constant SBIFPHY_QPLL_IMP               : std_logic_vector( 2 downto 0) := "000";           -- QPLL Implementation

    constant PIMSPHY_IBERT_IMP              : std_logic_vector(11 downto 0) := "000000000000";  -- In System IBERT Implementation
    constant PIMSPHY_UEB_USAGE              : std_logic_vector(11 downto 0) := "000000000000";  -- User Elastic Buffer
    constant PIMSPHY_TX_POLARITY_INVERT     : std_logic_vector(11 downto 0) := "000000000000";  -- TX Polarity Invert
    constant PIMSPHY_QPLL_USED              : std_logic_vector(11 downto 0) := "111111111111";  -- Xilinx Quad PLL
    constant PIMSPHY_QPLL_IMP               : std_logic_vector( 2 downto 0) := "111";           -- QPLL Implementation

    -- etc.
    constant SBIFPHY_ADDR                   : std_logic_vector( 1 downto 0) := "00";            -- Address 0x800 ~ 0xFFF
    constant PIMSPHY_ADDR                   : std_logic_vector( 1 downto 0) := "01";            -- Address 0xC00 ~ 0x3FF

--******************************************************************
-- Configuration : CPRI_TOP/CPRI_CORE
--******************************************************************


--******************************************************************
-- Configuration : CPRI_TOP/CPRI_CORE
--******************************************************************

--******************************************************************
-- Configuration : CPRI_TOP/ETHMUX_TOP
--******************************************************************

--******************************************************************
-- Configuration : CPRI_TOP/IQCOMP_TOP
--******************************************************************

--******************************************************************
-- Configuration : xRAN_TOP
--******************************************************************
    constant NUM_ORAN                       : natural :=  2;                    -- Number of L0
    
--******************************************************************
-- Configuration : BB_TOP
--******************************************************************
    constant MAX_CC                         : natural := 1;

--******************************************************************
-- Configuration : BBCTRL_TOP
--******************************************************************
    constant TOTAL_MAP_NUM                  : natural := 2;

    constant DL_BBIQARY_NUM                 : natural := 1 ;                    -- The Number of Downlink IQ Data Array
    constant UL_BBIQARY_NUM                 : natural := 1 ;                    -- The Number of Uplink IQ Data Array
   
    constant COMP_NUM                       : natural := 0;
    constant CPRI_COMP_EN                   : boolean_array(0 to 1)    := (false, false);

    constant CC_NUM                         : natural := 1;
--******************************************************************
--******************************************************************
-- Configuration : DSP_TOP
--******************************************************************
    constant DEVICE                         : string    := "ULTRASCALE";        -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    constant DSP_PIM_DUC_SEL                : boolean   :=       FALSE ;        -- "TRUE"  :  DSP_PIM_DUC_SEL,  "FALSE"  :  DSP_PIM_CFR_STAGE#3_SEL

--******************************************************************
-- Configuration : DSP_TOP/DDUC_TOP
--******************************************************************
    constant DDUC_OPR_CLK                   : real      :=      307.2 ;
    constant DDUC_CLK_SEL                   : natural   := natural(DDUC_OPR_CLK/30.72);
    constant DDC_IN_SAMPLE_RATE             : real      :=      153.6 ;
    constant RESAMPLER_EN_TX                : boolean   :=       FALSE ;
    constant RESAMPLER_EN_RX                : boolean   :=       FALSE ;
    constant DDC_IN_HOVS                    : integer   := integer(DDUC_OPR_CLK/DDC_IN_SAMPLE_RATE);
    constant UL_PWR_MSR_SR_FACTOR           : natural   := natural(DDC_IN_SAMPLE_RATE/30.72);

--******************************************************************
-- Configuration : DSP_TOP/CFR_TOP
--******************************************************************
    constant TX_CFR_ANT_NUM                 : natural :=  2;

    constant CFR_MODULE_MAIN_TYPE           : std_logic_vector(7 downto 0) := "01000010";   -- 0x"42"
    constant CFR_MODULE_SUB_TYPE            : std_logic_vector(7 downto 0) := "00000000";   -- modify after determined
    constant CFR_OPR_CLK                    : real      :=       307.2 ;                    -- CFR_TOP Operation Clock, Unit : MHz
    constant CFR_CLK_SEL                    : natural   := natural(CFR_OPR_CLK/30.72);
    constant CFR_IN_SAMPLE_RATE             : real      :=       153.6 ;                    -- CFR Input data Sample Rate, Unit : MHz
    constant CFR_OUT_SAMPLE_RATE            : real      :=       307.2 ;                    -- CFR Output data Sample Rate, Unit : MHz
    constant CFR_STAGE_NUM                  : natural   :=           4 ;                    -- CFR STAGE NUMBER
    constant CFR_CONFIG_TAP_NUM             : integer   :=         509 ;                    -- CFR TAP NUMBER / 8 = 1023/8
    constant CFR_FRAC_DLY_FILTER_EN         : boolean   :=        TRUE ;
    constant CFR_UPSAMPLE_MODE_EN           : boolean   := ternary_func((natural(CFR_OUT_SAMPLE_RATE/CFR_IN_SAMPLE_RATE) = 2),TRUE,FALSE);
    constant CFR_HC_IMPL_EN                 : boolean   :=        TRUE ;
    constant CFR_CLK_DIV                    : natural   := natural(CFR_OPR_CLK/CFR_OUT_SAMPLE_RATE); -- clock rate/data rate
    constant CFR_PATH_PER_MODULE            : natural   :=           2 ;                    -- Number of path per 1 CFR module
    constant CFR_ACCUM_NUM_WIDTH            : natural   :=          20 ;                    -- Number of samples to be averaged = 2^ACCUM_NUM_WIDTH
    constant CFR_DATA_WIDTH                 : natural   :=          16 ;                    -- Data bits width
    constant CFR_OPD_ACCUM_NUM_WIDTH        : natural   :=          16 ;                    -- Number of samples to be averaged(OPD) = 2^ACCUM_NUM_WIDTH_OPD
    constant CFR_PWR_MSR_SR_FACTOR          : natural   := natural(CFR_OUT_SAMPLE_RATE/30.72);
    constant CFR_CPG_MULT_TYPE              : std_logic_vector( 3 downto 0) := "0001";      -- "0001" : complex , "0000" : Real
    constant CFR_COEFF_MEM_ACCESS_TYPE      : std_logic_vector( 3 downto 0) := "0001";      -- "0001" : Folded , "0000" : Unfolded
    constant CFR_PHY_MEM_DEPTH_FACTOR       : std_logic_vector( 3 downto 0) := "0001";      -- Physical Coeff. Memory Depth Factor per Antenna Path  (Factor Value * 256)

--******************************************************************
-- Configuration : DSP_TOP/DPD_TOP
--******************************************************************
    constant USING_FB_PATH                  : boolean   :=        TRUE ;                    -- Determine Feedback Path Implementation

    constant DPD_HS_MODE                    : boolean   :=        TRUE ;
    constant DL_HS_MODE                     : boolean   :=        TRUE ;
    constant FB_HS_MODE                     : boolean   :=        TRUE ;
    constant UL_HS_MODE                     : boolean   :=        TRUE ;

    constant OPR_CLK_DPD_BLK                : real      :=      307.2 ;                    -- DPD_TOP Downlink Path Operation Clock, Unit : MHz
    constant OPR_CLK_DPD_TOP                : real      :=      307.2 ;                    -- DPD_TOP Feedback Path Operation Clock, Unit : MHz
    constant OPR_CLK_UL_PATH                : real      :=      307.2 ;                    -- DPD_TOP Uplink   Path Operation Clock, Unit : MHz

    constant DPD_DPD_SAMPLE_RATE            : real      :=      307.2 ;                    -- DPD_TOP Downlink Path Sampling Rate,   Unit : Msps
    constant DPD_DL_SAMPLE_RATE             : real      :=      307.2 ;                    -- DPD_TOP Downlink Path Sampling Rate,   Unit : Msps
    constant DPD_FB_SAMPLE_RATE             : real      :=      307.2 ;                    -- DPD_TOP Feedback Path Sampling Rate,   Unit : Msps
    constant DPD_UL_SAMPLE_RATE             : real      :=      153.6 ;                    -- DPD_TOP Uplink   Path Sampling Rate,   Unit : Msps

    constant DPD_HOVS                       : natural   :=   natural(OPR_CLK_DPD_BLK/DPD_DPD_SAMPLE_RATE); -- HOVS : (Clock Frequency)/(Sampling_Rate)
    constant DL_HOVS                        : natural   :=   natural(OPR_CLK_DPD_TOP/DPD_DL_SAMPLE_RATE ); -- HOVS : (Clock Frequency)/(Sampling_Rate)
    constant FB_HOVS                        : natural   :=   natural(OPR_CLK_DPD_TOP/DPD_FB_SAMPLE_RATE ); -- HOVS : (Clock Frequency)/(Sampling_Rate)
    constant UL_HOVS                        : natural   :=   natural(OPR_CLK_UL_PATH/DPD_UL_SAMPLE_RATE ); -- HOVS : (Clock Frequency)/(Sampling_Rate)

    constant DPD_CLK_SEL                    : natural   :=   natural(OPR_CLK_DPD_BLK/30.72);
    constant DL_CLK_SEL                     : natural   :=   natural(OPR_CLK_DPD_TOP/30.72);
    constant FB_CLK_SEL                     : natural   :=   natural(OPR_CLK_DPD_TOP/30.72);
    constant UL_CLK_SEL                     : natural   :=   natural(OPR_CLK_UL_PATH/30.72);

    constant FB_PWR_MSR_SR_FACTOR           : natural   :=   natural(DPD_FB_SAMPLE_RATE/30.72);

    --*******************************************
    -- RU-FPGA-R8.9 DPD
    --*******************************************
    -- R8.9.1 LUT
    -- -------------------------------------------
    -- | DPD_LUT_NUM | DPD_LUT0_NUM | DPD_TAP_NUM |
    -- --------------------------------------------
    -- |      4      |      0       |      2      |
    -- --------------------------------------------
    -- |      8      |      1       |      4      |
    -- --------------------------------------------
    -- |     16      |      2       |      8      |
    -- --------------------------------------------
    -- |     32      |      5       |     14      |
    -- --------------------------------------------
    -- |     37      |      5       |     19      |
    -- --------------------------------------------
    constant DPD_CORE_IMPLEMENTATION        : boolean   :=        TRUE ; -- TRUE : DPD_CORE Implementation,       FALSE : DPD_CORE Not Implemented
    constant DPD_CORE_LUT_OPTIMIZED         : boolean   :=       FALSE ; -- TRUE : DPD_CORE LUT Path Shared       FALSE : DPD_CORE LUT Non Optimized
    constant DPD_CORE_LUT_MEM_DEPTH         : string    :=       "HALF"; -- "FULL": 32x512x2, "HALF": 32x256x2
    constant DPD_CORE_LUT_RBTEST            : boolean   :=       FALSE ; -- TRUE : DPD_CORE LUT RBTEST Enable     FALSE : DPD_CORE LUT RBTEST Disable
    constant DPD_CORE_LUT_DIMENSION         : string    :=        "3D" ; -- "2D" or "3D"

    constant DPD_CORE_QPOINT_SEL            : boolean   :=       FALSE ; -- TRUE : DPD_CORE Qpoint Selectable     FALSE : DPD_CORE Qpoint Fixed
    constant DPD_CORE_LUT_NUM               : natural   :=          41 ; -- The Number of DPD_CORE LUTs
    constant DPD_CORE_TAP_NUM               : natural   :=          13 ; -- The Number of DPD_CORE TAPs
    constant DPD_CORE_LUT0_NUM              : natural   :=           3 ; -- Sync LUT TAP Indicator

    -- R8.9.3 Hard-Clipping
    constant DPD_HC_IMPLEMENTATION          : boolean   :=        TRUE ; -- TRUE : DPD_HC Implementation,         FALSE : DPD_HC Not Implemented

    -- R8.9.4 Smart Capture
    constant SC_IMPLEMENTATION              : boolean   :=        TRUE ; -- TRUE : SMART_CAPTURE Implementation,  FALSE : SMART_CAPTURE Not Implemented

    -- R8.9.6 Filtering Function on DPD output
    constant DPD_FILTER_IMPLEMENTATION      : boolean   :=        TRUE ; -- TRUE : DPD_FILTER Implementation,     FALSE : DPD_FILTER Not Implemented
    constant DPD_FILTER_COEF_NUM            : natural   :=          39 ;

    -- R8.9.7 Bulk NCO and Complex mixer before DPD Block
    constant DL_MIXER_IMPLEMENTATION        : boolean   :=        TRUE ; -- TRUE : DL_MIXER Implementation,       FALSE : DL_MIXER Not Implemented


    --*******************************************
    -- RU-FPGA-R8.16 Feedback
    --*******************************************
    -- R8.16.3 FB Filter
    constant FB_FILTER_IMPLEMENTATION       : boolean   :=        TRUE ; -- TRUE : FB_FILTER Implementation,      FALSE : FB_FILTER Not Implemented
    constant FB_FILTER_RND_POINT            : natural   :=          15 ; -- The Rounding Point of Multiplier
    constant FB_FILTER_TAP_NUM              : natural   :=          32 ; -- The Number of FB FILTER TAPs

    -- R8.16.4 Power Measurement
    constant FB_PWRMEAS_IMPLEMENTATION      : boolean   :=        TRUE ; -- TRUE : FB_PWRMEAS Implementation,     FALSE : FB_PWRMEAS Not Implemented


    --*******************************************
    -- RU-FPGA-R10.2 AMP Protection
    --*******************************************
    -- R10.2.5 Signal On/Off Control
    constant DACIF_ONOFF_IMPLEMENTATION     : boolean   :=        TRUE ; -- TRUE : DACIF_IQ_ONOFF Implementation, FALSE : DACIF_IQ_ONOFF Not Implemented
    constant DACIF_PH_TESTOR_IMPLEMENTATION : boolean   :=       FALSE ;


    --*******************************************
    -- RU-FPGA-R11.1 DIgital Signal Power Contorl
    --*******************************************
    -- R11.1.1 Attenuation and Gain Control in TX Path
    constant DPD_ATT_IMPLEMENTATION         : boolean   :=        TRUE ; -- TRUE : DPD_ATTEN Implementation,      FALSE : DPD_ATTEN Not Implemented

    -- R11.1.3 Attenuation and Gain Control in FB Path
    constant FB_ATTEN_IMPLEMENTATION        : boolean   :=        TRUE ; -- TRUE : FB_ATTEN Implementation,       FALSE : FB_ATTEN Not Implemented
    constant FB_ATTEN_INPUT                 : string    :=     "FB_ADC"; -- "FB_ADC": FB_ADC output to FB_ATTEN,  "FB_FILTER": FB_FILTER output to FB_ATTEN

    -- R?.?.? PIM Mitigator Core
    constant PIM_IMPLEMENTATION             : boolean   :=        TRUE ;

    constant PIM_BLK_TYPE                   : string    := "SELECTABLE"; -- "INTER" or "INTRA" or "SELECTABLE"
    constant PIM_SRC_NUM                    : natural   :=           1 ; -- 2: self-conj, 3: the others conj

    constant PIMD_CORE_LUT_OPTIMIZED        : boolean   :=       FALSE ; -- TRUE : PIMD_CORE LUT Path Shared       FALSE : PIMD_CORE LUT Non Optimized
    constant PIMD_CORE_LUT_MEM_DEPTH        : string    :=       "HALF"; -- "FULL": 32x512x2, "HALF": 32x256x2
    constant PIMD_CORE_LUT_RBTEST           : boolean   :=       FALSE ; -- TRUE : PIMD_CORE LUT RBTEST Enable     FALSE : PIMD_CORE LUT RBTEST Disable
    constant PIMD_CORE_QPOINT_SEL           : boolean   :=        TRUE ; -- TRUE : PIMD_CORE Qpoint Selectable     FALSE : PIMD_CORE Qpoint Fixed
    constant PIMD_CORE_LUT_DIMENSION        : string  :=           "2D"; -- "2D" or "3D"
    constant PIMD_CORE_LUT_NUM              : natural   :=          10 ;
    constant PIMD_CORE_TAP_NUM              : natural   :=          10 ;

    -- R?.?.? VSWR measure at RX only mode
    constant RX_SSD_IMPLEMENTATION          : boolean   :=        TRUE ;


--******************************************************************
-- Configuration : SBIF_M_TOP
--******************************************************************
	constant SBIF_SIM                       : boolean   :=       FALSE ; -- TRUE : Simulation mode,         FALSE : Implementation  mode


--******************************************************************
-- Configuration : DCIF_TOP
--******************************************************************
    constant JSERDES_NUM                    : natural := 8;      -- Number of SERDES for JESD interface
    constant JSERDES_QUAD_NUM               : natural := 2;       -- Number of QUAD for JESD interface


--******************************************************************
-- Configuration : MISC_TOP
--******************************************************************

--******************************************************************
-- Configuration : MISC_TOP/SADUMP
--******************************************************************
    constant DUMP_BUF_NUM                   : natural := 2     ;    -- Number of Memory for DUMP
    constant SA_USAGE                       : boolean := TRUE  ;    -- Spectrum Analyzer Function Usage
    constant NPI_PTN_USAGE                  : boolean := TRUE  ;    -- NPI Test Pattern Generator Usage
    constant FIXED_PTN_USAGE                : boolean := FALSE ;    -- Fixed Test Pattern Generator Usage
    constant DUAL_DUMP_USAGE                : boolean := FALSE ;    -- 2 point Dual Dump Usage ( add 1 memory )
    constant POLY_PHASE_USAGE               : boolean := FALSE ;    -- Poly Phase Support for DPD output
--******************************************************************
-- Configuration : MISC_TOP/DPA
--******************************************************************

--******************************************************************
-- Configuration : MISC_TOP/SIGSUS
--******************************************************************
    constant SIG_SUS_PBA_TYPE               : std_logic_vector(7 downto 0)  := x"08";   -- Verizon MPSOC(ZU9P)
--******************************************************************
-- Configuration : MISC_TOP/FBSWCTRL
--******************************************************************

--******************************************************************
-- Configuration : MISC_TOP/TDDCTRL
--******************************************************************

--******************************************************************
-- Configuration : MISC_TOP/EXTDEVCTRL
--******************************************************************

--******************************************************************
-- Configuration : MISC_TOP/INTADC
--******************************************************************

end RU_FPGA_CONFIG;

package body RU_FPGA_CONFIG is

end RU_FPGA_CONFIG;
