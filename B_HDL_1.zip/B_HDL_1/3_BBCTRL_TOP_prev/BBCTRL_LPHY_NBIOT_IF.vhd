library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity BBCTRL_LPHY_NBIOT_IF is
port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        I_BW_SEL                    : in  std_logic_vector(3 downto 0);        

--------------------------------------------------------------------------------
-- BB_TOP
--------------------------------------------------------------------------------

        O_UL_FSYNC                  :out std_logic;    -- 1 clock frame(10ms) sync   
        O_UL_TDD                    :out std_logic;       
        O_UL_VLD                    :out std_logic_vector( 1 downto 0);    
        O_UL_DATA_I                 :out std_logic_array16(1 downto 0);      
        O_UL_DATA_Q                 :out std_logic_array16(1 downto 0);      

--------------------------------------------------------------------------------
-- FORMATTER
--------------------------------------------------------------------------------

        I_UL_FSYNC                  : in  std_logic;
        I_UL_TDD                    : in  std_logic;
        I_UL_SYNC                   : in  std_logic;
        I_UL_DATA                   : in  std_logic_vector(15 downto 0) 
    );
end BBCTRL_LPHY_NBIOT_IF;

architecture BEHAVE of BBCTRL_LPHY_NBIOT_IF is

       signal ul_clk_cnt                 : std_logic_vector(4 downto 0) := (others => '0');
       signal ul_data_mux_d              : std_logic_vector(15 downto 0) := (others => '0');
       signal ul_fsync_d                 : std_logic := '0';
       signal ul_fsync_rpls              : std_logic := '0'; 
       signal ul_fsync_rpls_d            : std_logic_vector(8 downto 0) := (others => '0');
       signal ul_data_i                  : std_logic_array16(1 downto 0) := (others => (others => '0'));    -- 16b idata path per one ant path.  
       signal ul_data_q                  : std_logic_array16(1 downto 0) := (others => (others => '0'));    -- 16b qdata path per one ant path.  
       signal ul_sync_d                  : std_logic := '0';
       signal ul_data_i_out              : std_logic_array16(1 downto 0) := (others => (others => '0'));    -- 16b idata path per one ant path.  
       signal ul_data_q_out              : std_logic_array16(1 downto 0) := (others => (others => '0'));    -- 16b qdata path per one ant path.  


begin

    PROCESSING_DELAY_UL <= conv_std_logic_vector(10, 24);

    O_UL_FSYNC  <= ul_fsync_rpls_d(8); 
    O_UL_TDD    <= I_UL_TDD; 
    O_UL_VLD    <= (others => '1');
    O_UL_DATA_I <= ul_data_i_out;
    O_UL_DATA_Q <= ul_data_q_out;
 
    --UL map interface (lphy -> formatter)
    process(CLK_SYSX8) begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            ul_data_mux_d <= I_UL_DATA;
        end if;
    end process;

    process(CLK_SYSX8) begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            ul_sync_d <= I_UL_SYNC;
            if (ul_sync_d = '1') then
                ul_clk_cnt <= (others => '0');
            else
                ul_clk_cnt <= ul_clk_cnt + 1;
            end if;
        end if;
    end process;

    process(CLK_SYSX8) begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            case ul_clk_cnt(1 downto 0) is
                when "00"   => ul_data_i(0) <= ul_data_mux_d;
                when "01"   => ul_data_q(0) <= ul_data_mux_d;
                when "10"   => ul_data_i(1) <= ul_data_mux_d;
                when "11"   => ul_data_q(1) <= ul_data_mux_d;
                when others => ul_data_i    <= (others => (others => '0'));
                               ul_data_q    <= (others => (others => '0'));                               
            end case;
        end if;
    end process;

    process(CLK_SYSX8) begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (ul_clk_cnt(4 downto 2) = "000") then
                ul_data_i_out <= ul_data_i;
                ul_data_q_out <= ul_data_q;
            else
                ul_data_i_out <= ul_data_i_out;
                ul_data_q_out <= ul_data_q_out;
            end if;       
        end if;
    end process;
    
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            ul_fsync_d      <= I_UL_FSYNC;
            ul_fsync_rpls   <= I_UL_FSYNC and (not ul_fsync_d);
            ul_fsync_rpls_d <= ul_fsync_rpls_d(7 downto 0) & ul_fsync_rpls;
        end if;
    end process;

end BEHAVE;







