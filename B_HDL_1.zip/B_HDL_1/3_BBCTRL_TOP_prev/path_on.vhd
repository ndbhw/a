--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : PATH on/off (Formatter component)                             --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2021.12.28                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------
-- Processing delay -clocks                                                  --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;

entity PATH_ON is
    generic (
        ANT_NUM                     : natural := 4
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

        PATH_ON                     : in  std_logic_vector(ANT_NUM-1 downto 0);

        IN_10MS                     : in  std_logic;
        IN_TDD                      : in  std_logic;
        IN_SYNC                     : in  std_logic;
        IN_DATA                     : in  std_logic_vector(15 downto 0);

        OUT_10MS                    : out std_logic;
        OUT_TDD                     : out std_logic;
        OUT_SYNC                    : out std_logic;
        OUT_DATA                    : out std_logic_vector(15 downto 0)
    );
end PATH_ON;

architecture BEHAVE of PATH_ON is

    signal in_10ms_d                  : std_logic_vector(  7 downto 0) := (others => '0');
    signal in_tdd_d                   : std_logic_vector(  7 downto 0) := (others => '0');
    signal in_sync_d                  : std_logic_vector(  7 downto 0) := (others => '0');
    signal cnt_sync                   : std_logic_vector(  7 downto 0) := (others => '0');
    signal cnt_sync_d                 : std_logic_vector(  6 downto 0) := (others => '0');
    signal cnt_sync_d2                : std_logic_vector(  6 downto 0) := (others => '0');
    signal data_out                   : std_logic_array16(ANT_NUM-1 downto 0) := (others => (others => '0'));

begin

    PROCESSING_DELAY <= x"000003";

    OUT_10MS <= in_10ms_d(1); 
    OUT_TDD  <= in_tdd_d (1); 
    OUT_SYNC <= in_sync_d(1); 
    
--    OUT_10MS <= in_10ms_d(2); 
--    OUT_TDD  <= in_tdd_d (2); 
--    OUT_SYNC <= in_sync_d(2); 

    -- buffering
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            in_10ms_d <= in_10ms_d(6 downto 0) & IN_10MS;
            in_tdd_d  <= in_tdd_d(6 downto 0)  & IN_TDD;
            in_sync_d <= in_sync_d(6 downto 0) & IN_SYNC;
        end if;
    end process;

    -- synchronization
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_SYNC = '1') then
                cnt_sync <= (others => '0');
            else
                cnt_sync <= cnt_sync + 1;
            end if;
            cnt_sync_d  <= cnt_sync(7 downto 1);
            cnt_sync_d2 <= cnt_sync_d;
        end if;
    end process;

    G_ANT_NUM : for i in ANT_NUM-1 downto 0 generate

    -- path on/off
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (PATH_ON(i) = '1') then
                data_out(i) <= IN_DATA;
            else
                data_out(i) <= (others => '0');
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
--            case cnt_sync_d2 is
            case cnt_sync_d is
                when "0000000" => OUT_DATA <= data_out(0);
                when "0000001" => OUT_DATA <= data_out(1);
--                when "0000010" => OUT_DATA <= data_out(2);
--                when "0000011" => OUT_DATA <= data_out(3);
                when "0001000" => OUT_DATA <= data_out(0);
                when "0001001" => OUT_DATA <= data_out(1);
--                when "0001010" => OUT_DATA <= data_out(2);
--                when "0001011" => OUT_DATA <= data_out(3);
                when "0010000" => OUT_DATA <= data_out(0);
                when "0010001" => OUT_DATA <= data_out(1);
--                when "0010010" => OUT_DATA <= data_out(2);
--                when "0010011" => OUT_DATA <= data_out(3);
                when "0011000" => OUT_DATA <= data_out(0);
                when "0011001" => OUT_DATA <= data_out(1);
--                when "0011010" => OUT_DATA <= data_out(2);
--                when "0011011" => OUT_DATA <= data_out(3);
                when others    => OUT_DATA <= (others => '0');
            end case;
        end if;
    end process;

    end generate;


end BEHAVE;
