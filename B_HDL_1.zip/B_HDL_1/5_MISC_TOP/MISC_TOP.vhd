library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity MISC_TOP is
    port(
        ----------------------------------------------------------------------------
        -- CPU_TOP I/F
        ----------------------------------------------------------------------------
        CLK_CPUIF                          : in  std_logic ;
        RST_CPUIF                          : in  std_logic ;
        AXI_TIMEOUT_IN                     : in  std_logic ;
        ADDR_CPUIF_IN                      : in  std_logic_vector(15 downto 0) ;
        RDATA_CPUIF_OUT                    : out std_logic_vector(31 downto 0) ;
        RDEN_CPUIF_IN                      : in  std_logic ;
        RDVAL_CPUIF_OUT                    : out std_logic ;
        WDATA_CPUIF_IN                     : in  std_logic_vector(31 downto 0) ;
        WREN_CPUIF_IN                      : in  std_logic ;

        DMA_RDCLK_OUT                      : out std_logic ;
        DMA_RDRDY_IN                       : in  std_logic ;
        DMA_RDEPT_IN                       : in  std_logic ;
        DMA_RDFULL_IN                      : in  std_logic ;
        DMA_RDEN_OUT                       : out std_logic ;
        DMA_RDATA_IN                       : in  std_logic_vector(31 downto 0) ;

        DMA_WRCLK_OUT                      : out std_logic ;
        DMA_WRRDY_IN                       : in  std_logic ;
        DMA_WREPT_IN                       : in  std_logic ;
        DMA_WRFULL_IN                      : in  std_logic ;
        DMA_WREN_OUT                       : out std_logic ;
        DMA_WDATA_OUT                      : out std_logic_vector(31 downto 0) ;

        --SYSCTRL_TOP
        CLK_MISC3                          : in std_logic ; -- 200.00 MHz
        RST_MISC                           : in std_logic ;

        CLK_SYS                            : in std_logic ; --  30.72 MHz
        CLK_SYSX2                          : in std_logic ; --  61.44 MHz 
        CLK_SYSX3                          : in std_logic ; --  92.16 MHz 
        CLK_SYSX4                          : in std_logic ; -- 122.88 MHz 
        CLK_SYSX5                          : in std_logic ; -- 153.60 MHz 
        CLK_SYSX6                          : in std_logic ; -- 184.32 MHz 
        CLK_SYSX8                          : in std_logic ; -- 245.76 MHz 
        CLK_SYSX10                         : in std_logic ; -- 307.20 MHz 
        CLK_SYSX12                         : in std_logic ; -- 368.64 MHz 
        CLK_SYSX16                         : in std_logic ; -- 491.52 MHz 
        CLK_SYSX20                         : in std_logic ; -- 614.14 MHz 

        RX_BFN_STRB_SYSCTRL_IN             : in std_logic_vector(CPRI_NUM-1 downto 0) ; -- connected to SADUMP 
        TX_BFN_STRB_SYSCTRL_IN             : in std_logic_vector(CPRI_NUM-1 downto 0) ; -- connected to SADUMP
        RX_BFN_STRB_CPRI_IN                : in std_logic_vector(CPRI_NUM-1 downto 0) ; -- connected to SADUMP

        --CPRIPHY_TOP
        SIG_SUS_FLAG_CPRIPHY_IN            : in  std_logic_vector(CPRI_NUM-1 downto 0) ; -- connected to SADUMP
        SIG_SUS_DLOFF_CPRIPHY_OUT          : out std_logic_vector(CPRI_NUM-1 downto 0) ; -- connected to SADUMP

        DUMP_BFN_STRB_CPRIPHY_IN           : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP
        DUMP_DATA_CPRIPHY_IN               : in  std_logic_array32(1 downto 0) ; -- connected to SADUMP
        DUMP_DVLD_CPRIPHY_IN               : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP
        TEST_DATA_CPRIPHY_OUT              : out std_logic_array32(1 downto 0) ; -- connected to SADUMP
        TEST_ENB_CPRIPHY_IN                : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP

        --CPRI_TOP
        SIG_SUS_FLAG_CPRI_IN               : in std_logic_vector(CPRI_NUM-1 downto 0) ; -- connected to SADUMP
        IS_MASTER_CPRI_IN                  : in std_logic_vector(CPRI_NUM-1 downto 0) ; -- connected to SADUMP

        DUMP_BFN_STRB_CPRI_IN              : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP
        DUMP_DATA_CPRI_IN                  : in  std_logic_array32(1 downto 0) ; -- connected to SADUMP
        DUMP_DVLD_CPRI_IN                  : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP
        TEST_DATA_CPRI_OUT                 : out std_logic_array32(1 downto 0) ; -- connected to SADUMP
        TEST_ENB_CPRI_IN                   : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP

        --SBIF_TOP
        SIG_SUS_FLAG_SBIF_IN               : in  std_logic_vector(SBIF_NUM-1 downto 0) ; -- connected to SADUMP
        SIG_SUS_DLOFF_SBIF_OUT             : out std_logic_vector(SBIF_NUM-1 downto 0) ; -- connected to SADUMP

        DUMP_BFN_STRB_SBIF_IN              : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP
        DUMP_DATA_SBIF_IN                  : in  std_logic_array32(1 downto 0) ; -- connected to SADUMP
        DUMP_DVLD_SBIF_IN                  : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP
        TEST_DATA_SBIF_OUT                 : out std_logic_array32(1 downto 0) ; -- connected to SADUMP
        TEST_ENB_SBIF_IN                   : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP

        --SBIFPHY_TOP
        SIG_SUS_FLAG_SBIFPHY_IN            : in  std_logic_vector(SBIF_NUM-1 downto 0) ; -- connected to SADUMP
        SIG_SUS_DLOFF_SBIFPHY_OUT          : out std_logic_vector(SBIF_NUM-1 downto 0) ; -- connected to SADUMP

        DUMP_BFN_STRB_SBIFPHY_IN           : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP
        DUMP_DATA_SBIFPHY_IN               : in  std_logic_array32(1 downto 0) ; -- connected to SADUMP
        DUMP_DVLD_SBIFPHY_IN               : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP
        TEST_DATA_SBIFPHY_OUT              : out std_logic_array32(1 downto 0) ; -- connected to SADUMP
        TEST_ENB_SBIFPHY_IN                : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP

        -- BBCTRL_TOP
        SIG_SUS_FLAG_BBCTRL_IN             : in  std_logic_vector(DL_BBIQARY_NUM-1 downto 0) ; -- connected to SADUMP
        SIG_SUS_DLOFF_BBCTRL_OUT           : out std_logic_vector(CPRI_NUM-1 downto 0) ;       -- connected to SADUMP

        DUMP_BFN_STRB_BBCTRL_IN            : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP
        DUMP_DATA_BBCTRL_IN                : in  std_logic_array32(1 downto 0) ; -- connected to SADUMP
        DUMP_DVLD_BBCTRL_IN                : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP
        TEST_DATA_BBCTRL_OUT               : out std_logic_array32(1 downto 0) ; -- connected to SADUMP
        TEST_ENB_BBCTRL_IN                 : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP

        -- DSP_TOP
        SIG_SUS_FLAG_DSP_IN                : in  std_logic_vector(TX_ANT_NUM-1 downto 0) ; -- connected to SADUMP
        SIG_SUS_DLOFF_DSP_OUT              : out std_logic_vector(TX_ANT_NUM-1 downto 0) ; -- connected to SADUMP

        DUMP_BFN_STRB_DSP_IN               : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP
        DUMP_DATA_DSP_IN                   : in  std_logic_array32(1 downto 0) ; -- connected to SADUMP
        DUMP_DVLD_DSP_IN                   : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP
        TEST_DATA_DSP_OUT                  : out std_logic_array32(1 downto 0) ; -- connected to SADUMP
        TEST_ENB_DSP_IN                    : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP

        DL_IQ_ISZERO_IN                    : in std_logic_vector(TX_ANT_NUM-1 downto 0) ; -- connected to SADUMP
        DL_CLK_ISZERO_IN                   : in std_logic_vector(TX_ANT_NUM-1 downto 0) ; -- connected to SADUMP

        -- DCIF_TOP
        SIG_SUS_FBFLAG_DCIF_IN             : in std_logic_vector(JESD_FB_LINK_NUM-1 downto 0) ; -- connected to SADUMP
        SIG_SUS_ULFLAG_DCIF_IN             : in std_logic_vector(JESD_RX_LINK_NUM-1 downto 0) ; -- connected to SADUMP
        SIG_SUS_DLFLAG_DCIF_IN             : in std_logic_vector(JESD_TX_LINK_NUM-1 downto 0) ; -- connected to SADUMP

        DUMP_BFN_STRB_DCIF_IN              : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP
        DUMP_DATA_DCIF_IN                  : in  std_logic_array32(1 downto 0) ; -- connected to SADUMP
        DUMP_DVLD_DCIF_IN                  : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP
        TEST_DATA_DCIF_OUT                 : out std_logic_array32(1 downto 0) ; -- connected to SADUMP
        TEST_ENB_DCIF_IN                   : in  std_logic_vector( 1 downto 0) ; -- connected to SADUMP

        DL_SSB_STRB_DCIF_IN                : in  std_logic ;
        DL_BFN_STRB_DCIF_IN                : in  std_logic ;
        DL_TDD_DCIF_IN                     : in  std_logic ;
        DL_SSB_STRB_1PPS_OUT               : out std_logic ;
        DL_BFN_STRB_1PPS_OUT               : out std_logic ;

        SYNC_1PPS_10MS_IN                  : in  std_logic ;
        UL_TDD_1PPS_IN                     : in  std_logic ;
        UL_BFN_STRB_DCIF_OUT               : out std_logic ;
        UL_TDD_DCIF_OUT                    : out std_logic ;

        FB_BFN_STRB_DCIF_OUT               : out std_logic ;
        FB_TDD_DCIF_OUT                    : out std_logic ;

        -- SIG_SUS_TOP
        SIG_SUS_DLOFF_OTRX_OUT             : out std_logic ;
        EXT_SYSPLL_LOCK_IN                 : in  std_logic ;
        INT_SYSPLL_LOCK_IN                 : in  std_logic ;
        VSS_RMT_RST_CPRI_IN                : in  std_logic ;
        HWWDT_FLAG_IN                      : in  std_logic ;
        SWWDT_FLAG_IN                      : in  std_logic ;

        --------------------------------
        -- Feedback Switch
        --------------------------------
        FBSW_START_TRIG_OUT                : out std_logic ;
        FBSW_CNT_245P76M_OUT               : out std_logic_vector(5 downto 0) ;
        FBSW_CNT_307P20M_OUT               : out std_logic_vector(5 downto 0) ;
        FBSW_AUTO_MODE_DONE_OUT            : out std_logic_vector(RFIC_NUM-1 downto 0) ;

        FBSW_PWR_MSR_UPT_OUT               : out std_logic ;              -- tick per every 10ms.  clock domain : 122.88MHz
        -- new port
        SSB_OFFSET                         : in  std_logic_vector(3 downto 0) ;
        ADV_SFN_MOD                        : in  std_logic_vector(3 downto 0) ;
        ADV_SFN_STRB                       : in  std_logic ;
        CPRI_CONN_OK                       : in  std_logic ;
        SSB_EXIST_OUT                      : out std_logic ;
        FB_SW_MEASURE_DONE_80MS            : out std_logic ;
        --------------------------------
        -- Ports on Schemetics
        --------------------------------
        --------------------------------
        -- RF TX Switch Control
        --------------------------------
        TX_B13_A_SW_OUT                    : out std_logic ; -- ZUFPGA : use       / KUFPGA : use
        TX_B13_B_SW_OUT                    : out std_logic ; -- ZUFPGA : use       / KUFPGA : use
        TX_B13_C_SW_OUT                    : out std_logic ; -- ZUFPGA : use       / KUFPGA : use
        TX_B13_D_SW_OUT                    : out std_logic ; -- ZUFPGA : use       / KUFPGA : use

        ISPPAC_CTRL_OUT                    : out std_logic_vector(2 downto 0) ; -- ZUFPGA : use       / KUFPGA : don't use
        UDA_IN                             : in  std_logic_vector(3 downto 0) ; -- ZUFPGA : use       / KUFPGA : don't use
        UDA_D                              : in  std_logic_vector( 7 downto 0) ;
        UDA_D_TX                           : out std_logic_vector( 3 downto 0) ;

        B13_AMP_EN_OUT                     : out std_logic_vector(TX_ANT_NUM-1 downto 0) ; -- ZUFPGA : use       / KUFPGA : use

        OOK_B13_A_TXIN                     : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use
        OOK_B13_A_RXOUT                    : in  std_logic ; -- ZUFPGA : use       / KUFPGA : don't use
        OOK_B13_A_DIR_IN                   : in  std_logic ; -- ZUFPGA : use       / KUFPGA : don't use
        OOK_B13_A_DIRMD1_OUT               : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use
        OOK_B13_A_DIRMD2_OUT               : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use
        BIAS_T_B13_A_ONOFF_OUT             : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use
        FPGA_PSB_AMP_48V_ONOFF             : out std_logic;

        OOK_B13_C_TXIN                     : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use
        OOK_B13_C_RXOUT                    : in  std_logic ; -- ZUFPGA : use       / KUFPGA : don't use
        OOK_B13_C_DIR_IN                   : in  std_logic ; -- ZUFPGA : use       / KUFPGA : don't use
        OOK_B13_C_DIRMD1_OUT               : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use
        OOK_B13_C_DIRMD2_OUT               : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use
        BIAS_T_B13_C_ONOFF_OUT             : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use

        LED_CTRL_SYSCTRL_IN                : in  std_logic_array5(LED_NUM-1 downto 0) ;
        LED_RED_OUT                        : out std_logic_vector(LED_NUM-1 downto 0) ; -- ZUFPGA : use       / KUFPGA : don't use
        LED_GREEN_OUT                      : out std_logic_vector(LED_NUM-1 downto 0) ; -- ZUFPGA : use       / KUFPGA : don't use
        LED_BLUE_OUT                       : out std_logic_vector(LED_NUM-1 downto 0) ; -- ZUFPGA : use       / KUFPGA : don't use

        UDE_ETH_nRESET                     : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use

        EXT_EN_5p0V_OUT                    : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use
        RET_ONOFF_OUT                      : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use
        BIAST_3P3V_EN                      : out std_logic;
        TRX_RF_EN_5P0V                     : out std_logic;
        RET_UART_TXD_OUT                   : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use 
        RET_DE_OUT                         : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use 
        RET_nRE_OUT                        : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use 
        RET_UART_RXD_IN                    : in  std_logic ; -- ZUFPGA : use       / KUFPGA : don't use 

        UART0_MP_IN                        : in  std_logic ; -- ZUFPGA : use       / KUFPGA : don't use 
        UART0_MP_OUT                       : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use 
        UART1_MP_IN                        : in  std_logic ; -- ZUFPGA : use       / KUFPGA : don't use 
        UART1_MP_OUT                       : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use 
        UART2_MP_IN                        : in  std_logic ; -- ZUFPGA : use       / KUFPGA : don't use 
        UART2_MP_OUT                       : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use 

        CLK_PLL_LOS_IN                     : in  std_logic ; -- ZUFPGA : use       / KUFPGA : don't use
        CLK_PLL_LD_IN                      : in  std_logic ; -- ZUFPGA : use       / KUFPGA : use
        CLK_PLL_LD_RSVD_IN                 : in  std_logic ; -- ZUFPGA : use       / KUFPGA : use
        CLK_PLL_RESET_OUT                  : out std_logic ; -- ZUFPGA : use       / KUFPGA : don't use

        UV_ALARM_IN                        : in std_logic ; -- ZUFPGA : use       / KUFPGA : use
        TRX_DC_NORMAL_IN                   : in std_logic ; -- ZUFPGA : use       / KUFPGA : use
        FPGA_PWR_STATUS_IN                 : in std_logic ; -- ZUFPGA : use       / KUFPGA : use
        PWR55_NORMAL_IN                    : in std_logic ; -- ZUFPGA : use       / KUFPGA : dont' use

        PG_0P85V_MFPGA                     : in std_logic; -- ZUFPGA : use       / KUFPGA : use
        PG_1P8V_MFPGA                      : in std_logic; -- ZUFPGA : use       / KUFPGA : use
        PG_1P3V_RFIC_JESD                  : in std_logic; -- ZUFPGA : use       / KUFPGA : use
        PG_5P5V                            : in std_logic; -- ZUFPGA : use       / KUFPGA : use
        PG_1P2V_DDR4                       : in std_logic; -- ZUFPGA : use       / KUFPGA : use
        PG_3P3V_CLK                        : in std_logic; -- ZUFPGA : use       / KUFPGA : use
        PG_3P3V                            : in std_logic; -- ZUFPGA : use       / KUFPGA : use
        PG_0P9V_MFPGA_MGT                  : in std_logic; -- ZUFPGA : use       / KUFPGA : use
        PG_1P2V_MFPGA_MGT                  : in std_logic; -- ZUFPGA : use       / KUFPGA : use
        PG_1P3V_RFIC0_DIGITAL              : in std_logic; -- ZUFPGA : use       / KUFPGA : use
        PG_1P3V_RFIC0_ANALOG               : in std_logic; -- ZUFPGA : use       / KUFPGA : use

        AMP_AMC_RST1_OUT                   : out std_logic ; -- ZUFPGA : use       / KUFPGA : use
        AMP_AMC_RST2_OUT                   : out std_logic ; -- ZUFPGA : use       / KUFPGA : use

        RFIC_B13_TX_EN_OUT                 : out std_logic_array2(RFIC_NUM-1 downto 0) ; -- ZUFPGA : use       / KUFPGA : use
        RFIC_B13_RESETB_OUT                : out std_logic_vector(RFIC_NUM-1 downto 0) ; -- ZUFPGA : use       / KUFPGA : use
        RFIC_TRI_ENB                       : out std_logic_vector(RFIC_NUM-1 downto 0) ; -- ZUFPGA : use       / KUFPGA : use
        RFIC_B13_GP_INTERRUPT_IN           : in  std_logic_vector(RFIC_NUM-1 downto 0) ; -- ZUFPGA : use       / KUFPGA : use

        RFIC_GPIO_IN                       : in  std_logic_array19(RFIC_NUM-1 downto 0) ; -- ZUFPGA : use       / KUFPGA : use
        RFIC_GPIO_OUT                      : out std_logic_array19(RFIC_NUM-1 downto 0) ; -- ZUFPGA : use       / KUFPGA : use

        RFIC_AB_EN_OUT                     : out std_logic_vector(2 downto 0) ; -- ZUFPGA : don't use / KUFPGA : use
        PM2_RFIC_PWR_OFF                   : out std_logic ;
        RF_B13_AB_EN_OUT                   : out std_logic ; -- ZUFPGA : don't use / KUFPGA : use
        RF_B13_CD_EN_OUT                   : out std_logic ; -- ZUFPGA : don't use / KUFPGA : use

        KUFPGA_FUNCTION_FAIL_IN            : in  std_logic ; -- ZUFPGA :  IN       / KUFPGA :  OUT
        FUNCTION_FAIL_OUT                  : out std_logic;

        --------------------------------
        -- Board ID
        --------------------------------
        BOARD_ID_IN                        : in std_logic_vector(2 downto 0);

        -- FB_SW
        DDUC_DL_BFN_STRB                   : in  std_logic;
        DPD_SC_PATH_SEL_IN                 : in  std_logic_vector(3 downto 0);

        FPGA_AMP_FBSW_PATH_SEL             : out std_logic;
        FPGA_AMP_FBSW_EN_0                 : out std_logic;
        FPGA_AMP_FBSW_EN_1                 : out std_logic;
        FPGA_AMP_FBSW_FB_REV_SEL           : out std_logic;
        
        FPGA_RFIC_ORX_TRIGGER              : out std_logic;
        RFIC_FPGA_TXOBS_SELECT             : in  std_logic;
        FPGA_RFIC_ORXMODE_0                : out std_logic;
        FPGA_RFIC_ORXMODE_1                : out std_logic;
        FPGA_RFIC_ORXMODE_2                : out std_logic;
        
        PA_DRV_ONOFF                    : out std_logic;
        
        SUPPER_SLEEP_POUT                  : out std_logic_vector(  0 downto 0)
    );
end MISC_TOP;

architecture arc_MISC_TOP of MISC_TOP is

    component RST_SYNC is
        generic(
            DLY_NUM        : natural := 4;
            MAX_FANOUT_NUM : integer := 200
        );
        port(
            RST_IN  : in  std_logic;
            CLK     : in  std_logic;
            RST_OUT : out std_logic
        );
    end component;

    component CPUIF_MISC is
        port(
            ------------------------------------------------------------------------------------------
            -- Common port
            ------------------------------------------------------------------------------------------
            RST_CPU : in std_logic ; -- cpuif reset, '1': Reset
            CLK_CPU : in std_logic ; -- cpuif clock, faster than iclk/oclk

            AXI_TIMEOUT_IN : in std_logic ;

            CLK_SYSX4  : in std_logic ; -- 122.88 MHz
            CLK_SYSX8  : in std_logic ; -- 245.76 MHz
            CLK_SYSX10 : in std_logic ; -- 307.20 MHz

            CLK_MISC3 : in std_logic ; -- 200.00 MHz

            ADDR_CPU_IN   : in  std_logic_vector(15 downto 0) ; -- cpuif address input, word address.
            WDATA_CPU_IN  : in  std_logic_vector(31 downto 0) ; -- cpuif data input
            RDATA_CPU_OUT : out std_logic_vector(31 downto 0) ; -- cpuif data output
            WREN_CPU_IN   : in  std_logic ;                     -- cpuif write enable, '1': active, synchronous with iclk
            RDEN_CPU_IN   : in  std_logic ;                     -- cpuif read enable, '1': active.
            RDVAL_CPU_OUT : out std_logic ;                     -- cpuif read data valid, '1': active, synchronous with clk_cpu.

            ----------------------------
            -- MISC
            ----------------------------
            TP_SEL   : out std_logic;
            RST_CTRL : out std_logic_vector( 7 downto 0) ;

            BOARD_ID_IN : in std_logic_vector( 2 downto 0) ;

            ----------------------------
            -- SA_N_DUMP
            ----------------------------
            SADUMP_VAL_OUT : out std_logic ;

            RX_SYSCTRL_STRB_SEL_OUT : out std_logic_vector( 7 downto 0) ;
            TX_SYSCTRL_STRB_SEL_OUT : out std_logic_vector( 7 downto 0) ;
            RX_CPRI_STRB_SEL_OUT    : out std_logic_vector( 7 downto 0) ;
            MODULE_STRB_SEL_OUT     : out std_logic_vector( 7 downto 0) ;

            DUMP_STARTDLY_OUT : out std_logic_vector(11 downto 0) ;
            DUMP_BUF_SEL_OUT  : out std_logic_vector( 1 downto 0) ;
            DUMP_DATASEL_OUT  : out std_logic_vector( 7 downto 0) ;

            DUMP_START_OUT : out std_logic ;
            DUMP_DONE_IN   : in  std_logic ;

            SA_ENB_OUT           : out std_logic ;
            FB_SW_CNT_INFO_OUT   : out std_logic_vector( 1 downto 0) ;
            TXSA_CLKDLYVALUE_OUT : out std_logic_vector(23 downto 0) ;

            PHASE_SEL_OUT : out std_logic ;

            FIXED_PTN_BLK_SEL_OUT : out std_logic_vector( 7 downto 0) ;
            FIXED_PTN_LENGTH_OUT  : out std_logic_vector(12 downto 0) ;
            FIXED_PTN_ENB_OUT     : out std_logic ;
            FIXED_PTN_START_OUT   : out std_logic ;

            DMA_WR_ENB           : out std_logic ;
            DMA_WR_BLK_SEL_OUT   : out std_logic_vector( 7 downto 0) ;
            DMA_RD_ENB           : out std_logic ;
            DMA_RD_BLK_SEL_OUT   : out std_logic_vector( 7 downto 0) ;
            DMA_BFN_STRB_SEL_OUT : out std_logic_vector( 7 downto 0) ;
            DMA_DLY_VALUE_OUT    : out std_logic_vector(23 downto 0) ;

            TEST_PTN_SEL_OUT : out std_logic_vector( 1 downto 0) ;

            DMA_RD_FULL_IN  : in std_logic ;
            DMA_RD_EMPTY_IN : in std_logic ;
            DMA_WR_FULL_IN  : in std_logic ;
            DMA_WR_EMPTY_IN : in std_logic ;

            SADUMP_ADDR_OUT  : out std_logic_vector(15 downto 0) ;
            SADUMP_WDATA_OUT : out std_logic_vector(31 downto 0) ;
            SADUMP_WREN_OUT  : out std_logic ;
            SADUMP_RDEN_OUT  : out std_logic ;
            SADUMP_RDVAL_IN  : in  std_logic ;
            SADUMP_RDATA_IN  : in  std_logic_vector(31 downto 0) ;

            ----------------------------
            -- DPA
            ----------------------------
            DPA_EN : out std_logic_vector(TX_ANT_NUM-1 downto 0) ; -- Dynamic PA on/off enable

            DPA_TRX_DATA_DELAY_TIME : out std_logic_vector(15 downto 0) ; -- resolution 1/245.76MHz
            DPA_RISE_RESP_TIME      : out std_logic_vector(15 downto 0) ; -- resolution 1/245.76MHz
            DPA_FALL_RESP_TIME      : out std_logic_vector(15 downto 0) ; -- resolution 1/245.76MHz
            DPA_OFF_MON_TIME        : out std_logic_vector(15 downto 0) ; -- resolution 1/245.76MHz

            ----------------------------
            -- SIG_SUS
            ----------------------------
            WAVESTOP_DISABLE_OUT  : out std_logic ;
            ALM_DEB_CNT_OUT       : out std_logic_vector(19 downto 0) ;
            CPRI_LINK_ANT_OUT     : out std_logic_array8( 7 downto 0) ;
            RF_SW_OFF_RELEASE_OUT : out std_logic_vector( 7 downto 0) ;

            UV_ALM_POST_IN  : in std_logic ; -- '1': On          , '0': Off          ; PowerPAC Control Flag
            RFIC_OFF_SEQ_IN : in std_logic ; -- '1': On          , '0': Off
            HW_WDT_RST_IN   : in std_logic ; -- '1': On          , '0': Off          ; PowerPAC Control Flag

            LOG_CPRIPHY_IN : in std_logic_vector( 7 downto 0) ; -- '1': Alarm       , '0': No Alarm
            LOG_SBIFPHY_IN : in std_logic_vector( 7 downto 0) ; -- '1': Alarm       , '0': No Alarm
            LOG_CPRI_IN    : in std_logic_vector( 7 downto 0) ; -- '1': Alarm       , '0': No Alarm
            LOG_SBIF_IN    : in std_logic_vector( 7 downto 0) ; -- '1': Alarm       , '0': No Alarm
            LOG_BBCTRL_IN  : in std_logic_vector( 7 downto 0) ; -- '1': Alarm       , '0': No Alarm
            LOG_DSP_IN     : in std_logic_vector( 7 downto 0) ; -- '1': Alarm       , '0': No Alarm
            LOG_DCIF_DL_IN : in std_logic_vector( 7 downto 0) ; -- '1': Alarm       , '0': No Alarm
            LOG_DCIF_UL_IN : in std_logic_vector( 7 downto 0) ; -- '1': Alarm       , '0': No Alarm
            LOG_DCIF_FB_IN : in std_logic_vector( 7 downto 0) ; -- '1': Alarm       , '0': No Alarm

            LOG_CLK_IN        : in std_logic_vector( 1 downto 0) ; -- '1': Alarm       , '0': No Alarm
            LOG_RFIC_IN       : in std_logic_vector( 3 downto 0) ; -- '1': Alarm       , '0': No Alarm
            LOG_VOLTAGE_IN    : in std_logic_vector(31 downto 0) ; -- '1': Alarm       , '0': No Alarm
            LOG_DAC_OFF_IN    : in std_logic_vector( 7 downto 0) ; -- '1': Alarm       , '0': No Alarm
            LOG_WDT_IN        : in std_logic_vector( 1 downto 0) ;

            SIG_SUS_MAIN_TYPE_IN : in std_logic_vector( 7 downto 0);
            SIG_SUS_SUB_TYPE_IN  : in std_logic_vector( 7 downto 0);
            SIG_SUS_VER_IN       : in std_logic_vector( 7 downto 0);
            SIG_SUS_STRUCT_IN    : in std_logic_vector(31 downto 0);
            SIG_SUS_DATE_IN      : in std_logic_vector(31 downto 0);

            ALM_OFF_VOLT_OUT : out std_logic ; -- '1': Forced Alarm-off, '0': No Force

            ALM_EN_CPRIPHY_OUT : out std_logic_vector( 7 downto 0) ; -- '1': Forced Alarm, '0': No Force
            ALM_EN_SBIFPHY_OUT : out std_logic_vector( 7 downto 0) ; -- '1': Forced Alarm, '0': No Force
            ALM_EN_CPRI_OUT    : out std_logic_vector( 7 downto 0) ; -- '1': Forced Alarm, '0': No Force
            ALM_EN_SBIF_OUT    : out std_logic_vector( 7 downto 0) ; -- '1': Forced Alarm, '0': No Force
            ALM_EN_BBCTRL_OUT  : out std_logic_vector( 7 downto 0) ; -- '1': Forced Alarm, '0': No Force
            ALM_EN_DSP_OUT     : out std_logic_vector( 7 downto 0) ; -- '1': Forced Alarm, '0': No Force
            ALM_EN_DCIF_DL_OUT : out std_logic_vector( 7 downto 0) ; -- '1': Forced Alarm, '0': No Force
            ALM_EN_DCIF_UL_OUT : out std_logic_vector( 7 downto 0) ; -- '1': Forced Alarm, '0': No Force
            ALM_EN_DCIF_FB_OUT : out std_logic_vector( 7 downto 0) ; -- '1': Forced Alarm, '0': No Force
            ALM_EN_VOLT_OUT    : out std_logic_vector( 7 downto 0) ; -- '1': Forced Alarm, '0': No Force
            ALM_EN_PG_OUT      : out std_logic_vector(31 downto 0) ; -- '1': Forced Alarm, '0': No Force
            ALM_EN_OTHERS_OUT  : out std_logic_vector(31 downto 0) ; -- '1': Forced Alarm, '0': No Force

            DL_OFF_CPRIPHY_OUT : out std_logic_vector( 7 downto 0) ; -- '1': Forced DL Off, '0': No Force
            DL_OFF_SBIFPHY_OUT : out std_logic_vector( 7 downto 0) ; -- '1': Forced DL Off, '0': No Force
            DL_OFF_SBIF_OUT    : out std_logic_vector( 7 downto 0) ; -- '1': Forced DL Off, '0': No Force
            DL_OFF_BBCTRL_OUT  : out std_logic_vector( 7 downto 0) ; -- '1': Forced DL Off, '0': No Force
            DL_OFF_DSP_OUT     : out std_logic_vector( 7 downto 0) ; -- '1': Forced DL Off, '0': No Force
            DL_OFF_DCIF_OUT    : out std_logic_vector( 7 downto 0) ; -- '1': Forced DL Off, '0': No Force

            -- AMP Protection Timer
            I_t_dl_dly        : out std_logic_vector( 10 downto 0);
            I_t_pa_off        : out std_logic_vector( 10 downto 0);
            I_t_rf_swoff      : out std_logic_vector( 10 downto 0);
             ----------------------------
             -- FBSW_CTRL
             ----------------------------
            SW_MANUAL_SET   : out std_logic ;                        -- '1' : manual operation by user, '0' : normal operation   
            SW_MANUAL_VALUE : out std_logic_vector(6 downto 0) ;

            FB_SW_MODE : out std_logic_array2(RFIC_NUM-1 downto 0) ; -- reg

            RESYNC_MANUAL_OUT    : out std_logic ;                     -- 
            RESYNC_ENABLE_OUT    : out std_logic ;                     -- 
            RESYNC_STATUS_REG_IN : in  std_logic_vector(31 downto 0) ; -- 
                                                                       --        ORX_SW_REG                  : out std_logic_vector(3 downto 0)                  ; -- reg 
                                                                       --        ORX_SW_INVT_REG             : out std_logic_vector(3 downto 0)                  ; -- ORX_SW invert control
                                                                       --        REV_SW_0_REG                : out std_logic_vector(3 downto 0)                  ; -- reg 
                                                                       --        REV_SW_0_INVT_REG           : out std_logic_vector(3 downto 0)                  ; -- REV_SW invert control
                                                                       --        FB_REV_SW_0_REG             : out std_logic                                     ; -- reg 

            FB_SW_CTRL_VALUE_REG : out std_logic_array3(RFIC_NUM-1 downto 0) ; -- reg
            RFIC_ORX_TRIGGER_REG : out std_logic ;                             -- reg 
            RFIC_ORX_MODE_REG    : out std_logic_vector(2 downto 0) ;          -- reg 
            ----------------------------
            -- TDD_CTRL
            ----------------------------
            EQUIP_OFFSET : out std_logic_vector(18 downto 0) ;
            EQUIP_ON     : out std_logic_vector(14 downto 0) ;
            EQUIP_OFF    : out std_logic_vector(14 downto 0) ;

            TRXSW_TX_OFFSET : out std_logic_vector(18 downto 0) ;
            TRXSW_TX_ON     : out std_logic_vector(14 downto 0) ;
            TRXSW_TX_OFF    : out std_logic_vector(14 downto 0) ;

            TRXSW_RX_OFFSET : out std_logic_vector(18 downto 0) ;
            TRXSW_RX_ON     : out std_logic_vector(14 downto 0) ;
            TRXSW_RX_OFF    : out std_logic_vector(14 downto 0) ;

            RFIC_TXA_SW_OFFSET : out std_logic_array19(RFIC_NUM-1 downto 0) ;
            RFIC_TXA_SW_ON     : out std_logic_array15(RFIC_NUM-1 downto 0) ;
            RFIC_TXA_SW_OFF    : out std_logic_array15(RFIC_NUM-1 downto 0) ;

            RFIC_TXB_SW_OFFSET : out std_logic_array19(RFIC_NUM-1 downto 0) ;
            RFIC_TXB_SW_ON     : out std_logic_array15(RFIC_NUM-1 downto 0) ;
            RFIC_TXB_SW_OFF    : out std_logic_array15(RFIC_NUM-1 downto 0) ;

            AMP_EN_OFFSET : out std_logic_array19(TX_ANT_NUM-1 downto 0) ;
            AMP_EN_ON     : out std_logic_array15(TX_ANT_NUM-1 downto 0) ;
            AMP_EN_OFF    : out std_logic_array15(TX_ANT_NUM-1 downto 0) ;

            RFIC_TX_EN_OFFSET : out std_logic_array2_array19(RFIC_NUM-1 downto 0) ;
            RFIC_TX_EN_ON     : out std_logic_array2_array15(RFIC_NUM-1 downto 0) ;
            RFIC_TX_EN_OFF    : out std_logic_array2_array15(RFIC_NUM-1 downto 0) ;

            RFIC_RX_EN_OFFSET : out std_logic_array2_array19(RFIC_NUM-1 downto 0) ;
            RFIC_RX_EN_ON     : out std_logic_array2_array15(RFIC_NUM-1 downto 0) ;
            RFIC_RX_EN_OFF    : out std_logic_array2_array15(RFIC_NUM-1 downto 0) ;

            RFIC_PRE_TRIG_OFFSET : out std_logic_array19(RFIC_NUM-1 downto 0) ;
            RFIC_PRE_TRIG_ON     : out std_logic_array15(RFIC_NUM-1 downto 0) ;
            RFIC_PRE_TRIG_OFF    : out std_logic_array15(RFIC_NUM-1 downto 0) ;

            TX_CAL_SEL0_OFFSET : out std_logic_vector(18 downto 0) ;
            TX_CAL_SEL0_ON     : out std_logic_vector(14 downto 0) ;
            TX_CAL_SEL0_OFF    : out std_logic_vector(14 downto 0) ;

            RX_CAL_SEL0_OFFSET : out std_logic_vector(18 downto 0) ;
            RX_CAL_SEL0_ON     : out std_logic_vector(14 downto 0) ;
            RX_CAL_SEL0_OFF    : out std_logic_vector(14 downto 0) ;

            CAL_PATH_SEL_OFFSET : out std_logic_array19(1 downto 0) ;
            CAL_PATH_SEL_ON     : out std_logic_array15(1 downto 0) ;
            CAL_PATH_SEL_OFF    : out std_logic_array15(1 downto 0) ;

            CAL_SP4T_RESERVED_OFFSET : out std_logic_array19(2 downto 0) ;
            CAL_SP4T_RESERVED_ON     : out std_logic_array15(2 downto 0) ;
            CAL_SP4T_RESERVED_OFF    : out std_logic_array15(2 downto 0) ;

            TDD_AND_CTRL     : out std_logic_array32(6 downto 0) ;
            TDD_OR_CTRL      : out std_logic_array32(6 downto 0) ;
            EQUIP_TDD_SELECT : out std_logic_vector( 3 downto 0) ;
            ----------------------------
            -- EXT_CTRL
            ----------------------------
            UDE_ETHPHY_RST  : out std_logic ;
            CLK_PLL_RST     : out std_logic ;
            DLMK_RST        : out std_logic ;
            DLMK_SYNC       : out std_logic ;
            TDD_OUT_DIR     : out std_logic ;
            EXT_CLK_DIR     : out std_logic ;
            KUFPGA_RST_CTRL : out std_logic ;
            AMP_ENB_CTRL    : out std_logic_vector(TX_ANT_NUM-1 downto 0) ;
            TRX_SW_CTRL     : out std_logic_vector( 1 downto 0) ;
            TRX_TQL_9092_ON : out std_logic ;
            BIAST_3P3V_EN   : out std_logic;
            TRX_RF_EN_5P0V  : out std_logic;
            ISPPAC_CTRL     : out std_logic_vector( 2 downto 0) ;
            FPGA_PWR_STATUS : in  std_logic ;

            ANALOG_DL_DLY_BYPASS : out std_logic ;
            ANALOG_DL_DLY        : out std_logic_vector(11 downto 0) ;
            ANALOG_UL_DLY_BYPASS : out std_logic ;
            ANALOG_UL_DLY        : out std_logic_vector(11 downto 0) ;
            ANALOG_FB_DLY_BYPASS : out std_logic ;
            ANALOG_FB_DLY        : out std_logic_vector(11 downto 0) ;

            FUNC_FAIL_MASKING : out std_logic ;
            EXT_ENB_CTRL      : out std_logic ;

            UDA      : in  std_logic_vector( 3 downto 0) ;
            UDA_D    : in  std_logic_vector( 7 downto 0) ;
            UDA_D_TX : out std_logic_vector( 3 downto 0) ;

            CLK_PLL_LOS     : in std_logic ;
            CLK_PLL_LD      : in std_logic ;
            CLK_PLL_LD_RSVD : in std_logic ;

            AMP_AMC_RST1 : out std_logic ;
            AMP_AMC_RST2 : out std_logic ;
            FPGA_PSB_AMP_48V_ONOFF : out std_logic;
            ----------------------------
            -- RF TX Switch Control
            ----------------------------
            RF_TX_SW_CTRL : out std_logic_vector(TX_ANT_NUM-1 downto 0) ;
            RF_EN_CTRL    : out std_logic_vector( 1 downto 0) ;

            ----------------------------
            -- RX Attenuation Control
            ----------------------------
            RXATT_ENB    : out std_logic_vector(3 downto 0) ;
            RXATT_WORD_A : out std_logic_vector(6 downto 0) ;
            RXATT_WORD_B : out std_logic_vector(6 downto 0) ;
            RXATT_WORD_C : out std_logic_vector(6 downto 0) ;
            RXATT_WORD_D : out std_logic_vector(6 downto 0) ;

            ----------------------------
            -- RFIC_CTRL
            ----------------------------
            RFIC_RST_CTRL    : out std_logic_vector( RFIC_NUM-1 downto 0) ;
            RFIC_TRI_ENB     : out std_logic_vector( RFIC_NUM-1 downto 0) ;
            RFIC_PWR_ON      : out std_logic_vector( 2 downto 0) ;
            PM2_RFIC_PWR_OFF : out std_logic ;
            RFIC_TX_EN       : out std_logic_array2( RFIC_NUM-1 downto 0) ;
            RFIC_RX_EN       : out std_logic_array2( RFIC_NUM-1 downto 0) ;

            RFIC_GPIO_IN  : in  std_logic_array19(RFIC_NUM-1 downto 0) ;
            RFIC_GPIO_OUT : out std_logic_array19(RFIC_NUM-1 downto 0) ;

            RFIC_GP_INTERRUPT : in std_logic_vector( RFIC_NUM-1 downto 0) ;

            ----------------------------
            -- INTADC
            ----------------------------
            INTADC_TEMP       : in std_logic_vector( 15 downto 0) ;
            INTADC_VCCINT     : in std_logic_vector( 15 downto 0) ;
            INTADC_VCCPSINTLP : in std_logic_Vector( 15 downto 0) ;
            INTADC_VCCPSINTFP : in std_logic_Vector( 15 downto 0) ;
            INTADC_AUX        : in std_logic_array16(15 downto 0) ;

            ------------------------
            -- RET & Bias-T Control
            ------------------------
            RET_UART_CTRL_OUT        : out std_logic_vector( 15 downto 0) ;
            RET_TX_UART_START_CNT_IN : in  std_logic_vector( 15 downto 0) ;
            RET_TX_UART_ERR_CNT_IN   : in  std_logic_vector( 15 downto 0) ;
            RET_RX_UART_START_CNT_IN : in  std_logic_vector( 15 downto 0) ;
            RET_RX_UART_ERR_CNT_IN   : in  std_logic_vector( 15 downto 0) ;
            RET_ONOFF_CTRL_OUT       : out std_logic ;

            OOK_A_UART_CTRL_OUT        : out std_logic_vector( 15 downto 0) ;
            OOK_A_DIR_IN               : in  std_logic ;
            OOK_A_DIRMD1_OUT           : out std_logic ;
            OOK_A_DIRMD2_OUT           : out std_logic ;
            BIAS_T_A_ONOFF_OUT         : out std_logic ;
            OOK_A_TX_UART_START_CNT_IN : in  std_logic_vector( 15 downto 0) ;
            OOK_A_TX_UART_ERR_CNT_IN   : in  std_logic_vector( 15 downto 0) ;
            OOK_A_RX_UART_START_CNT_IN : in  std_logic_vector( 15 downto 0) ;
            OOK_A_RX_UART_ERR_CNT_IN   : in  std_logic_vector( 15 downto 0) ;

            OOK_C_UART_CTRL_OUT        : out std_logic_vector( 15 downto 0) ;
            OOK_C_DIR_IN               : in  std_logic ;
            OOK_C_DIRMD1_OUT           : out std_logic ;
            OOK_C_DIRMD2_OUT           : out std_logic ;
            BIAS_T_C_ONOFF_OUT         : out std_logic ;
            OOK_C_TX_UART_START_CNT_IN : in  std_logic_vector( 15 downto 0) ;
            OOK_C_TX_UART_ERR_CNT_IN   : in  std_logic_vector( 15 downto 0) ;
            OOK_C_RX_UART_START_CNT_IN : in  std_logic_vector( 15 downto 0) ;
            OOK_C_RX_UART_ERR_CNT_IN   : in  std_logic_vector( 15 downto 0) ;

            --------------------------------
            -- ETM MEMORY I/F
            --------------------------------
            ETM_MEM_PORT_EN : out std_logic;
            ETM_MEM_WR_EN   : out std_logic;
            ETM_MEM_WR_ADDR : out std_logic_vector(14 downto 0) ;
            ETM_MEM_WR_DATA : out std_logic_vector(31 downto 0) ;

            ------------------------
            -- Module Information
            ------------------------
            MISC_MODULE_INFO_IN : in std_logic_vector(31 downto 0) ;
            MISC_STRUCT_INFO_IN : in std_logic_vector(31 downto 0) ;
            MISC_MODULE_DATE_IN : in std_logic_vector(31 downto 0) ;

            SADUMP_MODULE_INFO_IN : in std_logic_vector(31 downto 0) ;
            SADUMP_STRUCT_INFO_IN : in std_logic_vector(31 downto 0) ;
            SADUMP_MODULE_DATE_IN : in std_logic_vector(31 downto 0) ;
            
            PA_DRV_ONOFF                    : out std_logic;
            
            SUPPER_SLEEP_POUT     : out std_logic_vector(  0 downto 0)

        );
    end component;

    component LTE_ETM_1MS_TP
        port (
            RST  : in std_logic;
            WCLK : in std_logic; -- CPUIF_MISC Clock domain
            RCLK : in std_logic; -- 245.76MHz Clock domain

            TP_MEM_PEN    : in std_logic; -- A/B port enable
            TP_MEM_AWEN   : in std_logic; -- A port write enable
            TP_MEM_WRADDR : in std_logic_vector(14 downto 0);
            TP_MEM_WRDATA : in std_logic_vector(31 downto 0); -- 31..16 : Q data, 15..0 : I data

            SAMPLE_ENB : in std_logic; -- Sample period tick, activated only 1 cpri core clock per sample

            TP_OUT : out std_logic_vector(31 downto 0)
        );
    end component;

    component DUMPBLK_TOP is
        generic(
            DUMP_BUF_NUM     : natural := 1 ;
            CPRI_NUM         : natural := 3 ;
            SA_USAGE         : boolean := TRUE ;
            NPI_PTN_USAGE    : boolean := FALSE ;
            FIXED_PTN_USAGE  : boolean := FALSE ;
            DUAL_DUMP_USAGE  : boolean := FALSE ;
            POLY_PHASE_USAGE : boolean := TRUE
        );
        port(
            RST_MISC : in std_logic ;
            CLK_CPU  : in std_logic ;

            CLK_DUMP0 : in std_logic ;
            CLK_DUMP1 : in std_logic ;

            ADDR_CPU_IN   : in  std_logic_vector(15 downto 0) ;
            WDATA_CPU_IN  : in  std_logic_vector(31 downto 0) ;
            WREN_CPU_IN   : in  std_logic ;
            RDEN_CPU_IN   : in  std_logic ;
            RDVAL_CPU_OUT : out std_logic ;
            RDATA_CPU_OUT : out std_logic_vector(31 downto 0) ;

            --CPRIPHY_TOP(CFPGA)
            DUMP_BFN_STRB_CPRIPHY_IN : in std_logic_vector( 1 downto 0) ;
            DUMP_DATA_CPRIPHY_IN     : in std_logic_array32(1 downto 0) ;
            DUMP_DVLD_CPRIPHY_IN     : in std_logic_vector( 1 downto 0) ;

            TEST_ENB_CPRIPHY_IN   : in  std_logic_vector( 1 downto 0) ;
            TEST_DATA_CPRIPHY_OUT : out std_logic_array32(1 downto 0) ;

            --CPRI_TOP(CFPGA,DFPGA)
            DUMP_BFN_STRB_CPRI_IN : in std_logic_vector( 1 downto 0) ;
            DUMP_DATA_CPRI_IN     : in std_logic_array32(1 downto 0) ;
            DUMP_DVLD_CPRI_IN     : in std_logic_vector( 1 downto 0) ;

            TEST_ENB_CPRI_IN   : in  std_logic_vector( 1 downto 0) ;
            TEST_DATA_CPRI_OUT : out std_logic_array32(1 downto 0) ;

            --SBIF_TOP(CFPGA,DFPGA)
            DUMP_BFN_STRB_SBIF_IN : in std_logic_vector( 1 downto 0) ;
            DUMP_DATA_SBIF_IN     : in std_logic_array32(1 downto 0) ;
            DUMP_DVLD_SBIF_IN     : in std_logic_vector( 1 downto 0) ;

            TEST_ENB_SBIF_IN   : in  std_logic_vector( 1 downto 0) ;
            TEST_DATA_SBIF_OUT : out std_logic_array32(1 downto 0) ;

            --SBIFPHY_TOP(CFPGA,DFPGA)
            DUMP_BFN_STRB_SBIFPHY_IN : in std_logic_vector( 1 downto 0) ;
            DUMP_DATA_SBIFPHY_IN     : in std_logic_array32(1 downto 0) ;
            DUMP_DVLD_SBIFPHY_IN     : in std_logic_vector( 1 downto 0) ;

            TEST_ENB_SBIFPHY_IN   : in  std_logic_vector( 1 downto 0) ;
            TEST_DATA_SBIFPHY_OUT : out std_logic_array32(1 downto 0) ;

            --BBCTRL_TOP(DFPGA)
            DUMP_BFN_STRB_BBCTRL_IN : in std_logic_vector( 1 downto 0) ;
            DUMP_DATA_BBCTRL_IN     : in std_logic_array32(1 downto 0) ;
            DUMP_DVLD_BBCTRL_IN     : in std_logic_vector( 1 downto 0) ;

            TEST_ENB_BBCTRL_IN   : in  std_logic_vector( 1 downto 0) ;
            TEST_DATA_BBCTRL_OUT : out std_logic_array32(1 downto 0) ;

            --DSP_TOP(DFPGA)
            DUMP_BFN_STRB_DSP_IN : in std_logic_vector( 1 downto 0) ;
            DUMP_DATA_DSP_IN     : in std_logic_array32(1 downto 0) ;
            DUMP_DVLD_DSP_IN     : in std_logic_vector( 1 downto 0) ;

            TEST_ENB_DSP_IN   : in  std_logic_vector( 1 downto 0) ;
            TEST_DATA_DSP_OUT : out std_logic_array32(1 downto 0) ;

            --DCIF_TOP(DFPGA)
            DUMP_BFN_STRB_DCIF_IN : in std_logic_vector( 1 downto 0) ;
            DUMP_DATA_DCIF_IN     : in std_logic_array32(1 downto 0) ;
            DUMP_DVLD_DCIF_IN     : in std_logic_vector( 1 downto 0) ;

            TEST_ENB_DCIF_IN   : in  std_logic_vector( 1 downto 0) ;
            TEST_DATA_DCIF_OUT : out std_logic_array32(1 downto 0) ;

            --External Device
            EXT_TRIGGER_IN : in std_logic ;

            --SYSCTRL_TOP
            RX_BFNSTRB_SYSCTRL_IN : in std_logic_vector(CPRI_NUM-1 downto 0) ;
            TX_BFNSTRB_SYSCTRL_IN : in std_logic_vector(CPRI_NUM-1 downto 0) ;

            --CPRI_TOP
            RX_BFNSTRB_CPRI_IN : in std_logic_vector(CPRI_NUM-1 downto 0) ;

            --DMA interface
            DMA_RDCLK_OUT : out std_logic ;
            DMA_RDRDY_IN  : in  std_logic ;
            DMA_RDEN_OUT  : out std_logic ;
            DMA_RDATA_IN  : in  std_logic_vector(31 downto 0) ;
            DMA_RDEPT_IN  : in  std_logic ;

            DMA_WRCLK_OUT : out std_logic ;
            DMA_WRRDY_IN  : in  std_logic ;
            DMA_WREN_OUT  : out std_logic ;
            DMA_WDATA_OUT : out std_logic_vector(31 downto 0) ;
            DMA_WRFULL_IN : in  std_logic ;

            -- DUMP
            RX_SYSCTRL_STRB_SEL_IN : in std_logic_vector( 7 downto 0) ;
            TX_SYSCTRL_STRB_SEL_IN : in std_logic_vector( 7 downto 0) ;
            RX_CPRI_STRB_SEL_IN    : in std_logic_vector( 7 downto 0) ;
            MODULE_STRB_SEL_IN     : in std_logic_vector( 7 downto 0) ; -- DUMPFSSEL_IN

            DUMP_BUF_SEL_IN : in std_logic_vector( 1 downto 0) ; -- DUMPBUF_SEL_IN
            DUMP_DATASEL_IN : in std_logic_vector( 7 downto 0) ; -- DUMPBLKSEL_IN

            DUMP_STARTDLY_IN : in  std_logic_vector(11 downto 0) ; -- BFNSTRBDLY_IN
            DUMP_START_IN    : in  std_logic ;
            DUMP_DONE_OUT    : out std_logic ;

            -- Dual DUMP
            RX_SYSCTRL_STRB_SEL_2ND_IN : in std_logic_vector( 7 downto 0) ;
            TX_SYSCTRL_STRB_SEL_2ND_IN : in std_logic_vector( 7 downto 0) ;
            RX_CPRI_STRB_SEL_2ND_IN    : in std_logic_vector( 7 downto 0) ;
            MODULE_STRB_SEL_2ND_IN     : in std_logic_vector( 7 downto 0) ; -- DUMPFSSEL_IN

            DUMP_BUF_SEL_2ND_IN : in std_logic_vector( 1 downto 0) ; -- DUMPBUF_SEL_IN
            DUMP_DATASEL_2ND_IN : in std_logic_vector( 7 downto 0) ; -- DUMPBLKSEL_IN

            DUMP_STARTDLY_2ND_IN : in  std_logic_vector(11 downto 0) ; -- BFNSTRBDLY_IN
            DUMP_DONE_2ND_OUT    : out std_logic ;

            RDATA_MEMORY_SEL_IN : in std_logic ;

            -- Poly Phase Dump
            PHASE_SEL_IN : in std_logic ;

            -- Spectrum Analyzer
            FBSW_CNT_IN       : in std_logic_vector( 5 downto 0) ;
            AUTO_MODE_DONE_IN : in std_logic ;
            SSB_EXIST_IN      : in std_logic ; -- SSB Exist Indicator, 19.10.07

            FBSW_MANUAL_IN        : in std_logic ; -- from FBSW_CTRL : '1' : manual operation by user, '0' : normal operation
            FB_SW_CNT_INFO_IN     : in std_logic_vector( 1 downto 0) ;
            FB_SW_CNT_INFO_2ND_IN : in std_logic_vector( 1 downto 0) ;

            TXSA_ENB_IN             : in std_logic ;
            TXSA_ENB_2ND_IN         : in std_logic ;
            TXSA_CLKDLYVALUE_IN     : in std_logic_vector(23 downto 0) ; -- CLKDLYVALUE_IN
            TXSA_CLKDLYVALUE_2ND_IN : in std_logic_vector(23 downto 0) ; -- CLKDLYVALUE_IN

            -- Fixed ptn generator
            FIXED_PTN_GEN_EN_IN  : in std_logic ;
            FIXED_PTN_START_IN   : in std_logic ;
            FIXED_PTN_BLK_SEL_IN : in std_logic_vector( 7 downto 0) ;
            FIXED_PTN_LENGTH_IN  : in std_logic_vector(12 downto 0) ;

            -- NPI interface
            DMA_RDEN_IN          : in std_logic ;
            DMA_WREN_IN          : in std_logic ;
            DMA_READ_BLK_SEL_IN  : in std_logic_vector( 7 downto 0) ;
            DMA_WRITE_BLK_SEL_IN : in std_logic_vector( 7 downto 0) ;
            DMA_BFN_STRB_SEL_IN  : in std_logic_vector( 7 downto 0) ;
            DMA_DLY_VALUE_IN     : in std_logic_vector(23 downto 0) ;

            TEST_PTN_SEL_IN    : in  std_logic_vector( 1 downto 0) ;
            TEST_PTN_VALID_OUT : out std_logic_vector( 1 downto 0) ;

            -- Module information
            SADUMP_MODULE_INFO_OUT : out std_logic_vector(31 downto 0) ;
            SADUMP_STRUCT_INFO_OUT : out std_logic_vector(31 downto 0) ;
            SADUMP_MODULE_DATE_OUT : out std_logic_vector(31 downto 0)

        );
    end component;

    component INTADC_TOP_SYSMONE4 is
        port(
            RST_XADC : in std_logic; -- XADC Synchronous Reset (100MHz)
            CLK      : in std_logic; -- 100MHz Register Map Clock

            XADC_CHANNEL_P : in std_logic_vector(15 downto 0); -- AUX_P[15:0]
            XADC_CHANNEL_N : in std_logic_vector(15 downto 0); -- AUX_N[15:0]

            XADC_VP_IN : in std_logic; -- Dedicated Analog Input Pair - P
            XADC_VN_IN : in std_logic; -- Dedicated Analog Input Pair - N

            XADC_TEMP       : out std_logic_vector(15 downto 0); -- XADC Temperature output
            XADC_VCCINT     : out std_logic_vector(15 downto 0); -- XADC VCCINT      output
            XADC_VCCPSINTLP : out std_logic_vector(15 downto 0); -- XADC VCC PS INT LP output
            XADC_VCCPSINTFP : out std_logic_vector(15 downto 0); -- XADC VCC PS INT FP output
            XADC_AUX        : out std_logic_array16(15 downto 0) -- XADC AUX #0~15  output
        );
    end component;

    component LEDCTRL3 is
        port (
            RESET        : in  std_logic;
            NCLK         : in  std_logic;
            LEDSEL       : in  std_logic_vector(4 downto 0);
            SOLID_RED_ON : in  std_logic;
            RLED         : out std_logic;
            GLED         : out std_logic;
            BLED         : out std_logic
        );
    end component LEDCTRL3;

    --component RX_ATT is
    --generic(
    --OUT_RATE                        : in  integer                                -- Period of output Clock 
    --                                                                             -- Period = (2^out_rate) * 2 * 10 ns
    --);
    --port(
    --RST                             : in  std_logic                            ; -- RST_CPU               : Input Reset from CPU, Active High
    --CLK                             : in  std_logic                            ; -- CLK_CPU               : Input Clock for RX Attenuator

    --ATT_EN                          : in  std_logic_vector(         3 downto 0);
    --ATT_WORD                        : in  std_logic_array7(         3 downto 0);

    --RXATT_AB_CLK                    : out std_logic                            ;
    --RXATT_AB_DI                     : out std_logic                            ;
    --RXATT_A_LE                      : out std_logic                            ;
    --RXATT_B_LE                      : out std_logic                            ;

    --RXATT_CD_CLK                    : out std_logic                            ;
    --RXATT_CD_DI                     : out std_logic                            ;
    --RXATT_C_LE                      : out std_logic                            ;
    --RXATT_D_LE                      : out std_logic
    --);
    --end component;

    component FB_SW_CTRL IS
        PORT (
            RESET_122P88M                           : in  std_logic;
            RESET_245P76M                           : in  std_logic;
            RESET_307P2M                            : in  std_logic;

            CLK_122P88M                             : in  std_logic;
            CLK_245P76M                             : in  std_logic;
            CLK_307P2M                              : in  std_logic;
            
            RX_BFN_STROBE                           : in  std_logic;                            -- BFN signal from CPRI(or..)(1 basic frame advanced signal), synchronized 122.88MHz clock, pulse width 3.84MHz
            
            -- TEST MODE
            SW_MANUAL_SET                           : in  std_logic;                            -- '1' : manual operation by user, '0' : normal operation
            SW_MANUAL_VALUE                         : in  std_logic_vector(6 downto 0);
            MANUAL_FB_SW_CTRL_VALUE                 : in  std_logic_vector(2 downto 0);
            MANUAL_RFIC_ORX_TRIGGER                 : in  std_logic; 
            MANUAL_RFIC_ORX_MODE                    : in  std_logic_vector(2 downto 0);
            
            -- FW MODE
            FB_SW_MODE                              : in  std_logic_vector(1 downto 0);

            TX_A_SW                                 : in  std_logic;
            TX_B_SW                                 : in  std_logic;

            --OUTPUT--
            AUTO_MODE_DONE                          : out std_logic;

            AMP_FBSW_PATH_SEL                       : out std_logic;
            AMP_FBSW_EN_0                           : out std_logic;
            AMP_FBSW_EN_1                           : out std_logic;
            AMP_FBSW_FB_REV_SEL                     : out std_logic;

            RFIC_ORX_TRIGGER                        : out std_logic;
            FPGA_TXOBS_SELECT                       : in  std_logic;
            RFIC_ORXMODE_0                          : out std_logic;
            RFIC_ORXMODE_1                          : out std_logic;
            RFIC_ORXMODE_2                          : out std_logic;
            
            DPA_PATH_EN                             : in std_logic_vector(2-1 downto 0);        -- FOR 2ANT

            -- new port
            UV_ALM_IN                               : in  std_logic;
            SSB_OFFSET                              : in  std_logic_vector(3 downto 0);
            ADV_SFN_MOD                             : in  std_logic_vector(3 downto 0);
            ADV_SFN_STRB                            : in  std_logic;
            SSB_IND_FLAG                            : out std_logic;
            RESYNC_STATUS_REG_OUT                   : out std_logic_vector(31 downto 0);

            FB_SW_MEASURE_DONE                      : out std_logic;                            -- tick per every 10ms.
            FB_SW_START_TRIG                        : out std_logic;
            FB_SW_CNT_245P76M                       : out std_logic_vector(5 downto 0);         -- 10ms period cnt by 245.76MHz cdc
            FB_SW_CNT_307P2M                        : out std_logic_vector(5 downto 0);         -- 10ms period cnt by 307.2MHz cdc

            DPD_SC_PATH_SEL_IN                      : in  std_logic_vector(3 downto 0)
        );
    END component;

    component DYNAMIC_PA_ONOFF is
        port(
            RESET : in std_logic; -- DDUC CLK Sync.Reset                        
            CLK   : in std_logic; -- DDUC CLK 245.76MHz

            DPA_EN : in std_logic; -- Dynamic PA on/off enable

            CPU_PA_EN : in std_logic; -- PA enable

            DPA_TRX_DATA_DELAY_TIME : in std_logic_vector(15 downto 0); -- resolution 1/245.76MHz
            DPA_RISE_RESP_TIME      : in std_logic_vector(15 downto 0); -- resolution 1/245.76MHz
            DPA_FALL_RESP_TIME      : in std_logic_vector(15 downto 0); -- resolution 1/245.76MHz
            DPA_OFF_MON_TIME        : in std_logic_vector(15 downto 0); -- resolution 1/245.76MHz

            IQ_ZERO_DET : in std_logic; -- '1':IQ zero

            DPA_EN_CTRL : out std_logic -- '0': off, '1': on
        );
    end component;

    component SIG_SUS_TOP is
        port(
            -- Reset
            RST_CPUIF     : in std_logic; -- Reset of 100 MHz
            RST_CLK_MISC3 : in std_logic; -- Reset of 200 MHz
            RST_CLK_SYSX8 : in std_logic; -- Reset of 245.76 MHz

            -- Clock
            CLK_CPU   : in std_logic; -- CPU CLK 100MHz, not CPU_PLL Clock
            CLK_MISC3 : in std_logic; -- Clock.   200 MHz
            CLK_SYSX8 : in std_logic; -- Clock.   245.76 MHz

            -- Signal Suspension On/Off
            WAVESTOP_DISABLE_IN  : in std_logic;                      -- 100MHz CPU Clock Domain... wave stop disable control, except vss rst, for test
            ALM_DEB_CNT_IN       : in std_logic_vector( 19 downto 0); -- Alarm Debouncing Count
            RF_SW_OFF_RELEASE_IN : in std_logic_vector( 7 downto 0);  -- RF SW Off Release;   '0'->'1' : Release,  Others : No action

            -- Link Information
            IS_MASTER_CPRI_IN : in std_logic_vector( CPRI_NUM-1 downto 0); -- '1': Master      , '0': Slave        ; When Master, ignore in wave stop process.
            LINK_ANT_RELATION : in std_logic_array8( 7 downto 0);          -- '1': Related     , '0': No           ; CPRI Link Antenna Releation

            -- Signal Suspension Alarms - Blocks
            SIG_SUS_FLAG_CPRIPHY_IN : in std_logic_vector( CPRI_NUM-1 downto 0);        -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_CPRI_IN    : in std_logic_vector( CPRI_NUM-1 downto 0);        -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_SBIFPHY_IN : in std_logic_vector( SBIF_NUM-1 downto 0);        -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_SBIF_IN    : in std_logic_vector( SBIF_NUM-1 downto 0);        -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_BBCTRL_IN  : in std_logic_vector( DL_BBIQARY_NUM-1 downto 0);  -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_DSP_IN     : in std_logic_vector( TX_ANT_NUM-1 downto 0);      -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_DCIF_DL_IN : in std_logic_vector(JESD_TX_LINK_NUM-1 downto 0); -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_DCIF_UL_IN : in std_logic_vector(JESD_RX_LINK_NUM-1 downto 0); -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_DCIF_FB_IN : in std_logic_vector(JESD_FB_LINK_NUM-1 downto 0); -- '1': Abnormal    , '0': Normal

            -- Signal Suspension Alarms - Voltages
            UV_ALM_IN            : in std_logic;                      -- '1': Abnormal    , '0': Normal
            TRX_DC_IN_VD_FAIL_IN : in std_logic;                      -- '1': Normal      , '0': Abnormal
            FPGA_PWR_STATUS_IN   : in std_logic;                      -- '1': Normal      , '0': Abnormal
            NPWR55_VD_FAIL_IN    : in std_logic;                      -- '1': Normal      , '0': Abnormal
            PG_NORMAL_IN         : in std_logic_vector( 31 downto 0); -- '1': Normal      , '0': Abnormal

            -- Signal Suspension Alarms - Others
            EXT_PLL_LOCK_IN      : in std_logic;                     -- '1': Normal      , '0': Abnormal     ; LMK Lock
            SYS_PLL_LOCK_IN      : in std_logic;                     -- '1': Normal      , '0': Abnormal     ; System PLL Lock in FPGA
            RFIC_GP_INTERRUPT_IN : in std_logic_vector( 3 downto 0); -- '1': Abnormal    , '0': Normal       ; RFIC_GP_INTERRRUPT GPIO
            VSS_RMT_RST_CPRI_IN  : in std_logic;                     -- '1': Abnormal    , '0': Normal       ; From CPRI Core, Latched
            HWWDT_FLAG_IN        : in std_logic;                     -- '1': Abnormal    , '0': Normal       ; From Watchdog
            SWWDT_FLAG_IN        : in std_logic;                     -- '1': Abnormal    , '0': Normal       ; From CPU

            -- Signal Suspension - Blocks
            SIG_SUS_DLOFF_CPRIPHY_OUT : out std_logic_vector( CPRI_NUM-1 downto 0);   -- '1': DL Off      , '0': Normal
            SIG_SUS_DLOFF_SBIFPHY_OUT : out std_logic_vector( SBIF_NUM-1 downto 0);   -- '1': DL Off      , '0': Normal
            SIG_SUS_DLOFF_SBIF_OUT    : out std_logic_vector( SBIF_NUM-1 downto 0);   -- '1': DL Off      , '0': Normal
            SIG_SUS_DLOFF_BBCTRL_OUT  : out std_logic_vector( CPRI_NUM-1 downto 0);   -- '1': DL Off      , '0': Normal
            SIG_SUS_DLOFF_DSP_OUT     : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- '1': DL Off      , '0': Normal

            -- Signal Suspension Controls
            TX_SW_ON_OUT     : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- '1': TX SW On    , '0': TX SW Off    ;
            PA_EN_OUT        : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- '1': PA On       , '0': PA Off
            OPT_TX_DIS_OUT   : out std_logic;                                -- '1': Disable     ; '0': Enable
            AMC_RST_OUT      : out std_logic;                                -- '1': Reset       , '0': Reset-release; AMC7812
            SOLID_RED_ON_OUT : out std_logic;                                -- '1': On          , '0': Off
            UV_ALM_POST_OUT  : out std_logic;                                -- '1': On          , '0': Off          ; PowerPAC Control Flag
            RFIC_OFF_SEQ_OUT : out std_logic;                                -- '1': On          , '0': Off
            HW_WDT_RST_OUT   : out std_logic;                                -- '1': On          , '0': Off          ; PowerPAC Control Flag

            -- Monitoring - Blocks
            LOG_CPRIPHY_OUT : out std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
            LOG_SBIFPHY_OUT : out std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
            LOG_CPRI_OUT    : out std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
            LOG_SBIF_OUT    : out std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
            LOG_BBCTRL_OUT  : out std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
            LOG_DSP_OUT     : out std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
            LOG_DCIF_DL_OUT : out std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
            LOG_DCIF_UL_OUT : out std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
            LOG_DCIF_FB_OUT : out std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm

            -- Monitoring - Others
            LOG_CLK_OUT     : out std_logic_vector( 1 downto 0);  -- '1': Alarm       , '0': No Alarm
            LOG_RFIC_OUT    : out std_logic_vector( 3 downto 0);  -- '1': Alarm       , '0': No Alarm
            LOG_VOLTAGE_OUT : out std_logic_vector( 31 downto 0); -- '1': Alarm       , '0': No Alarm
            LOG_DAC_OFF_OUT : out std_logic_vector( 7 downto 0);  -- '1': Alarm       , '0': No Alarm
            LOG_WDT_OUT     : out std_logic_vector( 1 downto 0);  

            -- History
            HIS_MAIN_TYPE_OUT : out std_logic_vector( 7 downto 0);
            HIS_SUB_TYPE_OUT  : out std_logic_vector( 7 downto 0);
            HIS_VER_OUT       : out std_logic_vector( 7 downto 0);
            HIS_STRUCT_OUT    : out std_logic_vector( 31 downto 0);
            HIS_DATE_OUT      : out std_logic_vector( 31 downto 0);

            -- Test Function - Voltage Alarm Off
            ALM_DIS_VOLT_IN : in std_logic; -- '1': Forced Alarm-off, '0': No Force

            -- Test Function - Alarm Enable
            ALM_EN_CPRIPHY_IN : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_SBIFPHY_IN : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_CPRI_IN    : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_SBIF_IN    : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_BBCTRL_IN  : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_DSP_IN     : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_DCIF_DL_IN : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_DCIF_UL_IN : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_DCIF_FB_IN : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_VOLT_IN    : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_PG_IN      : in std_logic_vector( 31 downto 0); -- '1': Forced Alarm, '0': No Force
            ALM_EN_OTHERS_IN  : in std_logic_vector( 31 downto 0); -- '1': Forced Alarm, '0': No Force

            -- Test Function - DL Off
            DL_OFF_CPRIPHY_IN : in std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
            DL_OFF_SBIFPHY_IN : in std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
            DL_OFF_SBIF_IN    : in std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
            DL_OFF_BBCTRL_IN  : in std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
            DL_OFF_DSP_IN     : in std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
            DL_OFF_DCIF_IN    : in std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
            -- AMP Protection Timer
            I_t_dl_dly        : in std_logic_vector( 10 downto 0);
            I_t_pa_off        : in std_logic_vector( 10 downto 0);
            I_t_rf_swoff      : in std_logic_vector( 10 downto 0)
        );
    end component SIG_SUS_TOP;

    component retcb
        port(
            RST         : in std_logic ;
            CLK_SYS     : in std_logic ;
            UART1_TX    : in std_logic ;
            UART1_RX_IN : in std_logic ;
            RET_TEST_EN : in std_logic ;
            LSBorMSB    : in std_logic ;

            UART1_TX_OUT      : out std_logic ;
            UART1_RX          : out std_logic ;
            RET_nRE           : out std_logic ;
            RET_DE            : out std_logic ;
            TX_UART_START_CNT : out std_logic_vector(15 downto 0) ;
            TX_UART_ERR_CNT   : out std_logic_vector(15 downto 0) ;
            RX_UART_START_CNT : out std_logic_vector(15 downto 0) ;
            RX_UART_ERR_CNT   : out std_logic_vector(15 downto 0) ;
            UART_CLK          : out std_logic ;
            UART1_TX_BUFF     : out std_logic_vector( 7 downto 0)
        );
    end component;

    component TDD_STRB_CNTDLY is
        port(
            RST : in std_logic; -- Active high reset
            CLK : in std_logic; -- Clock

            BLK_BYPASS_IN : in std_logic;                     -- '0' normal mode, '1' bypass mode
            DLYCNT_IN     : in std_logic_vector(11 downto 0); -- Delay Count value, Resolution : 1/(clock frequency)

            BFN_STROBE_IN : in std_logic;
            TDD_STROBE_IN : in std_logic;

            BFNSTRB_DLY_OUT : out std_logic;
            TDDSTRB_DLY_OUT : out std_logic
        );
    end component ;

    component pdm_gen is
        port (
            Reset  : in  std_logic;
            Clk    : in  std_logic;
            DACin  : in  std_logic_vector(15 downto 0);
            DACout : out std_logic
        );
    end component;

    component pd_pll is
        generic(
            LOOP_CNT_MAX : integer := 24999999 --change this value according to the frequency of ck50MHz pin, For 50MHz : 24999999,  for 30.72MHz : 15359999
        );
        port(
            reset    : in std_logic;                          --active high reset (reset duration > 100ns)
            pll_ref  : in std_logic;                          --reference 1PPS (1Hz) signal divided from local pll output clock (LMK PLL)
            ck250MHz : in std_logic;                          --250MHz (or 245.76MHz) clock generated from TCXO 30.72MHz with MMCM
            ck50MHz  : in std_logic;                          --50MHz clock generated from TCXO 30.72MHz
                                                              --if you want to change this to 30.72, then counter for generating loop_1hz should be changed
            pll_pd_irq   : out std_logic;                     --interrupt signal sent to CPU
            pll_pd_sign  : out std_logic;                     --sign of pll_pd value, 0 : positive sign, 1: negative sign
            pll_pd       : out std_logic_vector(28 downto 0); --phase error (unsigned integer) of rising edge between two clocks, resolution = 4ns for 250MHz clock, 4.069ns for 245.76MHz clock
            loop_clk_out : out std_logic
        );
    end component ;

    ------------------------------------
    -- MISC_TOP module information
    ------------------------------------
    constant ZEROS : std_logic_vector(31 downto 0) := (others => '0');

    constant MISC_TOP_ID     : std_logic_vector( 7 downto 0) := x"60"; -- MISC_TOP ID : 0x60
    constant MISC_CODE_ID    : std_logic_vector( 7 downto 0) := x"00"; -- SEC : 0x00, SRC : 0x01
    constant MISC_VERSION_ID : std_logic_vector( 7 downto 0) := x"01"; -- Revision Version

    constant MISC_MODULE_INFO : std_logic_vector(31 downto 0) := MISC_TOP_ID & MISC_CODE_ID & ZEROS(15 downto 8) & MISC_VERSION_ID;
    constant MISC_STRUCT_INFO : std_logic_vector(31 downto 0) := ZEROS;
    constant MISC_MODULE_DATE : std_logic_vector(31 downto 0) := x"2017_0518";

    ------------------------------------

    signal RST_FUNC_SADUMP  : std_logic := '0';
    signal RST_FUNC_DPA     : std_logic := '0';
    signal RST_FUNC_SIGSUS  : std_logic := '0';
    signal RST_FUNC_EXTCTRL : std_logic := '0';
    signal RST_FUNC_INTADC  : std_logic := '0';
    signal RST_FUNC_RETCB   : std_logic := '0';

    signal rst_sadump      : std_logic := '0';
    signal rst_dpa         : std_logic := '0';
    signal rst_sigsus      : std_logic := '0';
    signal rst_extctrl_x4  : std_logic := '0';
    signal rst_extctrl_x5  : std_logic := '0';
    signal rst_extctrl_x8  : std_logic := '0';
    signal rst_extctrl_x10 : std_logic := '0';
    signal rst_intadc      : std_logic := '0';
    signal rst_retcb       : std_logic := '0';

    signal i_rst_ctrl_test : std_logic_vector( 7 downto 0) := (others => '0');

    -- SADUMP
    signal i_rx_sysctrl_strb_sel : std_logic_vector( 7 downto 0);
    signal i_tx_sysctrl_strb_sel : std_logic_vector( 7 downto 0);
    signal i_rx_cpri_strb_sel    : std_logic_vector( 7 downto 0);
    signal i_module_strb_sel     : std_logic_vector( 7 downto 0);

    signal i_dump_buf_sel : std_logic_vector( 1 downto 0);
    signal i_dump_datasel : std_logic_vector( 7 downto 0);

    signal i_phase_sel : std_logic;

    signal i_dump_startdly : std_logic_vector(11 downto 0);
    signal i_dump_start    : std_logic;
    signal i_dump_done     : std_logic;

    signal i_dma_wren         : std_logic;
    signal i_dma_wr_blk_sel   : std_logic_vector( 7 downto 0);
    signal i_dma_rden         : std_logic;
    signal i_dma_rd_blk_sel   : std_logic_vector( 7 downto 0);
    signal i_dma_bfn_strb_sel : std_logic_vector( 7 downto 0);
    signal i_dma_dly_value    : std_logic_vector(23 downto 0);

    signal i_test_ptn_sel : std_logic_vector( 1 downto 0);

    signal i_sadump_addr  : std_logic_vector(15 downto 0);
    signal i_sadump_wdata : std_logic_vector(31 downto 0);
    signal i_sadump_wren  : std_logic;
    signal i_sadump_rden  : std_logic;
    signal i_sadump_rdval : std_logic;
    signal i_sadump_rdata : std_logic_vector(31 downto 0);

    signal i_led_red   : std_logic_vector(LED_NUM-1 downto 0);
    signal i_led_green : std_logic_vector(LED_NUM-1 downto 0);
    signal i_led_blue  : std_logic_vector(LED_NUM-1 downto 0);

    -- NPI interface
    signal i_dma_rdclk_out : std_logic_vector(1 downto 0);
    signal i_dma_rdrdy_in  : std_logic;
    signal i_dma_rden_out  : std_logic_vector(1 downto 0);
    signal i_dma_rdata_in  : std_logic_array32(1 downto 0);
    signal i_dma_wrclk_out : std_logic_vector(1 downto 0);
    signal i_dma_wrrdy_in  : std_logic;
    signal i_dma_wren_out  : std_logic_vector(1 downto 0);
    signal i_dma_wdata_out : std_logic_array32(1 downto 0);

    -- XADC interface
    signal i_xadc_temp        : std_logic_vector(15 downto 0);
    signal i_xadc_vccint      : std_logic_vector(15 downto 0);
    signal i_xadc_vccpsint_lp : std_logic_vector(15 downto 0);
    signal i_xadc_vccpsint_fp : std_logic_vector(15 downto 0);
    signal i_xadc_aux         : std_logic_array16(15 downto 0);
    signal i_xadc_channel_p   : std_logic_vector(15 downto 0);
    signal i_xadc_channel_n   : std_logic_vector(15 downto 0);

    signal i_dl_ssb_strb_dcif     : std_logic;
    signal i_dl_bfn_strb_dcif     : std_logic;
    signal i_dl_tdd_dcif          : std_logic;
    signal i_dl_ssb_strb_dcif_out : std_logic;
    signal i_dl_bfn_strb_dcif_out : std_logic;
    signal i_dl_tdd_dcif_out      : std_logic;

    signal i_sync_1pps_10ms_in  : std_logic;
    signal i_sync_1pps_10ms_in_d2  : std_logic;
    signal i_sync_1pps_10ms_in_d1  : std_logic;
    signal i_sync_1pps_10ms_in_d3  : std_logic;
    
    signal i_ul_tdd_dcif_out : std_logic;
    signal i_fb_tdd_dcif_out : std_logic;

    signal i_analog_dl_dly_bypass : std_logic;
    signal i_analog_dl_dly        : std_logic_vector(11 downto 0);
    signal i_analog_ul_dly_bypass : std_logic;
    signal i_analog_ul_dly        : std_logic_vector(11 downto 0);
    signal i_analog_fb_dly_bypass : std_logic;
    signal i_analog_fb_dly        : std_logic_vector(11 downto 0);

    -- RF Control
    signal i_rf_enb_ctrl   : std_logic_vector( 1 downto 0);
    signal i_rf_tx_sw_ctrl : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal i_tx_a_switch   : std_logic;
    signal i_tx_b_switch   : std_logic;
    signal i_tx_c_switch   : std_logic;
    signal i_tx_d_switch   : std_logic;

    -- Rx Attenuation
    signal i_rxatt_enb    : std_logic_vector(3 downto 0);
    signal i_rxatt_word_a : std_logic_vector(6 downto 0);
    signal i_rxatt_word_b : std_logic_vector(6 downto 0);
    signal i_rxatt_word_c : std_logic_vector(6 downto 0);
    signal i_rxatt_word_d : std_logic_vector(6 downto 0);

    -- Feedback Switch Control
    signal sw_manual_set   : std_logic;
    signal sw_manual_value : std_logic_vector(6 downto 0);

    signal fb_sw_mode : std_logic_array2(RFIC_NUM-1 downto 0);

    signal rfic_tx_obs_select : std_logic_vector(RFIC_NUM-1 downto 0);

    signal rfic_orx_mode    : std_logic_array3(RFIC_NUM-1 downto 0);
    signal rfic_orx_trigger : std_logic_vector(RFIC_NUM-1 downto 0);

    signal i_fb_sw_ctrl_value_0 : std_logic_vector( 2 downto 0);
    signal i_fb_sw_ctrl_value_1 : std_logic_vector( 2 downto 0);

    signal tx_a_ss : std_logic_vector(RFIC_NUM-1 downto 0);
    signal tx_b_ss : std_logic_vector(RFIC_NUM-1 downto 0);

    --signal rfic_tx0_en                  : std_logic_vector(RFIC_NUM-1 downto 0);  
    --signal rfic_tx1_en                  : std_logic_vector(RFIC_NUM-1 downto 0);  

    --signal orx_sw_reg                   : std_logic_vector(3 downto 0);               
    --signal orx_sw_invt_reg              : std_logic_vector(3 downto 0); -- ORX_SW invert control
    --signal rev_sw_0_reg                 : std_logic_vector(3 downto 0);               
    --signal rev_sw_0_invt_reg            : std_logic_vector(3 downto 0); -- REV_SW invert control
    --signal fb_rev_sw_0_reg              : std_logic;                                  

    signal fb_sw_ctrl_value_reg : std_logic_array3(RFIC_NUM-1 downto 0);
    signal rfic_orx_trigger_reg : std_logic;
    signal rfic_orx_mode_reg    : std_logic_vector( 2 downto 0);

    signal i_rfic_rst_ctrl : std_logic_vector(RFIC_NUM-1 downto 0);
    signal i_rfic_tri_enb  : std_logic_vector(RFIC_NUM-1 downto 0);
    signal i_rfic_pwr_on   : std_logic_vector( 2 downto 0);
    signal i_rfic_tx_en    : std_logic_array2(RFIC_NUM-1 downto 0);
    signal i_rfic_rx_en    : std_logic_array2(RFIC_NUM-1 downto 0);

    signal i_rfic_gpio_in  : std_logic_array19(RFIC_NUM-1 downto 0);
    signal i_rfic_gpio_out : std_logic_array19(RFIC_NUM-1 downto 0);

    signal rfic_pre_trig : std_logic_vector(RFIC_NUM - 1 downto 0);

    signal rfic_tx_tdd : std_logic_array2(RFIC_NUM-1 downto 0);
    signal rfic_rx_tdd : std_logic_array2(RFIC_NUM-1 downto 0);

    signal i_amp_enb_ctrl : std_logic_vector(TX_ANT_NUM - 1 downto 0);

    signal i_rfic_txa_sw_out : std_logic_vector(RFIC_NUM-1 downto 0);
    signal i_rfic_txb_sw_out : std_logic_vector(RFIC_NUM-1 downto 0);

    signal cal_path_sel      : std_logic_vector(1 downto 0);
    signal cal_sp4t_reserved : std_logic_vector(2 downto 0);

    signal ul_dl_config   : std_logic_vector(2 downto 0);
    signal ssf_config     : std_logic_vector(3 downto 0);
    signal dl_cp_extended : std_logic;
    signal ul_cp_extended : std_logic;

    signal trx_sw_ctrl : std_logic_vector(1 downto 0);

    signal equip_offset : std_logic_vector(18 downto 0);
    signal equip_on     : std_logic_vector(14 downto 0);
    signal equip_off    : std_logic_vector(14 downto 0);

    signal trxsw_tx_offset : std_logic_vector(18 downto 0);
    signal trxsw_tx_on     : std_logic_vector(14 downto 0);
    signal trxsw_tx_off    : std_logic_vector(14 downto 0);

    signal trxsw_rx_offset : std_logic_vector(18 downto 0);
    signal trxsw_rx_on     : std_logic_vector(14 downto 0);
    signal trxsw_rx_off    : std_logic_vector(14 downto 0);

    signal rfic_txa_sw_offset : std_logic_array19(RFIC_NUM - 1 downto 0);
    signal rfic_txa_sw_on     : std_logic_array15(RFIC_NUM - 1 downto 0);
    signal rfic_txa_sw_off    : std_logic_array15(RFIC_NUM - 1 downto 0);

    signal rfic_txb_sw_offset : std_logic_array19(RFIC_NUM - 1 downto 0);
    signal rfic_txb_sw_on     : std_logic_array15(RFIC_NUM - 1 downto 0);
    signal rfic_txb_sw_off    : std_logic_array15(RFIC_NUM - 1 downto 0);

    signal amp_en_offset : std_logic_array19(TX_ANT_NUM - 1 downto 0);
    signal amp_en_on     : std_logic_array15(TX_ANT_NUM - 1 downto 0);
    signal amp_en_off    : std_logic_array15(TX_ANT_NUM - 1 downto 0);

    signal rfic_tx_en_offset : std_logic_array2_array19(RFIC_NUM - 1 downto 0);
    signal rfic_tx_en_on     : std_logic_array2_array15(RFIC_NUM - 1 downto 0);
    signal rfic_tx_en_off    : std_logic_array2_array15(RFIC_NUM - 1 downto 0);

    signal rfic_rx_en_offset : std_logic_array2_array19(RFIC_NUM - 1 downto 0);
    signal rfic_rx_en_on     : std_logic_array2_array15(RFIC_NUM - 1 downto 0);
    signal rfic_rx_en_off    : std_logic_array2_array15(RFIC_NUM - 1 downto 0);

    signal rfic_pre_trig_offset : std_logic_array19(RFIC_NUM - 1 downto 0);
    signal rfic_pre_trig_on     : std_logic_array15(RFIC_NUM - 1 downto 0);
    signal rfic_pre_trig_off    : std_logic_array15(RFIC_NUM - 1 downto 0);

    signal tx_cal_sel0        : std_logic;
    signal tx_cal_sel0_offset : std_logic_vector(18 downto 0);
    signal tx_cal_sel0_on     : std_logic_vector(14 downto 0);
    signal tx_cal_sel0_off    : std_logic_vector(14 downto 0);

    signal rx_cal_sel0        : std_logic;
    signal rx_cal_sel0_offset : std_logic_vector(18 downto 0);
    signal rx_cal_sel0_on     : std_logic_vector(14 downto 0);
    signal rx_cal_sel0_off    : std_logic_vector(14 downto 0);

    signal cal_path_sel_offset : std_logic_array19(1 downto 0);
    signal cal_path_sel_on     : std_logic_array15(1 downto 0);
    signal cal_path_sel_off    : std_logic_array15(1 downto 0);

    signal cal_sp4t_reserved_offset : std_logic_array19(2 downto 0);
    signal cal_sp4t_reserved_on     : std_logic_array15(2 downto 0);
    signal cal_sp4t_reserved_off    : std_logic_array15(2 downto 0);

    signal tdd_and_ctrl : std_logic_array32(6 downto 0);
    signal tdd_or_ctrl  : std_logic_array32(6 downto 0);
    signal equip_tdd_r  : std_logic;

    signal equip_tdd_select : std_logic_vector(3 downto 0);
    -- DPA
    signal i_dpa_en                  : std_logic_vector(TX_ANT_NUM-1 downto 0); -- Dynamic PA on/off enable
    signal i_dpa_trx_data_delay_time : std_logic_vector(15 downto 0);           -- resolution 1/245.76MHz
    signal i_dpa_rise_resp_time      : std_logic_vector(15 downto 0);           -- resolution 1/245.76MHz
    signal i_dpa_fall_resp_time      : std_logic_vector(15 downto 0);           -- resolution 1/245.76MHz
    signal i_dpa_off_mon_time        : std_logic_vector(15 downto 0);           -- resolution 1/245.76MHz
    signal i_dpa_en_ctrl             : std_logic_vector(TX_ANT_NUM-1 downto 0); -- '0': off, '1': on


    -- SIG_SUS_TOP
    signal i_wavestop_disable   : std_logic;
    signal i_alm_deb_cnt        : std_logic_vector(19 downto 0);
    signal i_rf_sw_off_release  : std_logic_vector( 7 downto 0);
    signal i_link_ant_releation : std_logic_array8( 7 downto 0);

    signal i_uv_alm            : std_logic;
    signal i_trx_dc_in_vd_fail : std_logic;
    signal i_fpga_pwr_status   : std_logic;
    signal i_npwr55_vd_fail    : std_logic;
    signal i_pg_normal         : std_logic_vector(31 downto 0);

    signal i_tx_sw_on      : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal i_sig_sus_pa_en : std_logic_vector(TX_ANT_NUM-1 downto 0);
    signal i_opt_tx_dis    : std_logic;
    signal i_amc_rst       : std_logic;
    signal i_solid_red_on  : std_logic;
    signal i_uv_alm_post   : std_logic;
    signal i_rfic_off_seq  : std_logic;
    signal i_hw_wdt_rst    : std_logic;

    signal i_log_cpriphy : std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
    signal i_log_sbifphy : std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
    signal i_log_cpri    : std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
    signal i_log_sbif    : std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
    signal i_log_bbctrl  : std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
    signal i_log_dsp     : std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
    signal i_log_dcif_dl : std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
    signal i_log_dcif_ul : std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
    signal i_log_dcif_fb : std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm

    signal i_log_clk        : std_logic_vector( 1 downto 0); -- '1': Alarm       , '0': No Alarm
    signal i_log_rfic       : std_logic_vector( 3 downto 0); -- '1': Alarm       , '0': No Alarm
    signal i_log_voltage    : std_logic_vector(31 downto 0); -- '1': Alarm       , '0': No Alarm
    signal i_log_dac_off    : std_logic_vector( 7 downto 0); -- '1': Alarm       , '0': No Alarm
    signal i_log_wdt_out    : std_logic_vector( 1 downto 0); -- '1': Alarm       , '0': No Alarm
    signal i_log_rst_reason : std_logic_vector( 2 downto 0);
    signal i_alm_off_volt   : std_logic; -- '1': Force Alarm-off, '0': No Force

    signal i_sig_sus_main_type : std_logic_vector( 7 downto 0);
    signal i_sig_sus_sub_type  : std_logic_vector( 7 downto 0);
    signal i_sig_sus_ver       : std_logic_vector( 7 downto 0);
    signal i_sig_sus_struct    : std_logic_vector(31 downto 0);
    signal i_sig_sus_date      : std_logic_vector(31 downto 0);

    signal i_alm_en_cpriphy : std_logic_vector( 7 downto 0); -- '1': Forced Alarm, '0': No Force
    signal i_alm_en_sbifphy : std_logic_vector( 7 downto 0); -- '1': Forced Alarm, '0': No Force
    signal i_alm_en_cpri    : std_logic_vector( 7 downto 0); -- '1': Forced Alarm, '0': No Force
    signal i_alm_en_sbif    : std_logic_vector( 7 downto 0); -- '1': Forced Alarm, '0': No Force
    signal i_alm_en_bbctrl  : std_logic_vector( 7 downto 0); -- '1': Forced Alarm, '0': No Force
    signal i_alm_en_dsp     : std_logic_vector( 7 downto 0); -- '1': Forced Alarm, '0': No Force
    signal i_alm_en_dcif_dl : std_logic_vector( 7 downto 0); -- '1': Forced Alarm, '0': No Force
    signal i_alm_en_dcif_ul : std_logic_vector( 7 downto 0); -- '1': Forced Alarm, '0': No Force
    signal i_alm_en_dcif_fb : std_logic_vector( 7 downto 0); -- '1': Forced Alarm, '0': No Force
    signal i_alm_en_volt    : std_logic_vector( 7 downto 0); -- '1': Forced Alarm, '0': No Force
    signal i_alm_en_pg      : std_logic_vector(31 downto 0); -- '1': Forced Alarm, '0': No Force
    signal i_alm_en_others  : std_logic_vector(31 downto 0); -- '1': Forced Alarm, '0': No Force

    signal i_dl_off_cpriphy : std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
    signal i_dl_off_sbifphy : std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
    signal i_dl_off_sbif    : std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
    signal i_dl_off_bbctrl  : std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
    signal i_dl_off_dsp     : std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
    signal i_dl_off_dcif    : std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force

    -- Spectrum Analyzer
    signal i_fb_sw_cnt_245p76m   : std_logic_vector( 5 downto 0) ;
    signal i_fb_sw_cnt_307p20m   : std_logic_vector( 5 downto 0) ;
    signal i_fbsw_pwr_msr_upt    : std_logic ;
    signal i_fbsw_auto_mode_done : std_logic_vector(RFIC_NUM-1 downto 0);
    signal ssb_exist             : std_logic;

    signal i_sa_enb           : std_logic ;
    signal i_txsa_clkdlyvalue : std_logic_vector(23 downto 0) ;
    signal i_fb_sw_cnt_info   : std_logic_vector( 1 downto 0) ;

    -- fixed ptn
    signal i_fixed_ptn_blk_sel : std_logic_vector( 7 downto 0);
    signal i_fixed_ptn_length  : std_logic_vector(12 downto 0);
    signal i_fixed_ptn_enb     : std_logic ;
    signal i_fixed_ptn_start   : std_logic ;


    signal i_sadump_module_info : std_logic_vector(31 downto 0);
    signal i_sadump_struct_info : std_logic_vector(31 downto 0);
    signal i_sadump_module_date : std_logic_vector(31 downto 0);

    -- ret & bias-T control
    signal i_ret_uart_ctrl         : std_logic_vector(15 downto 0);
    signal i_ret_tx_uart_start_cnt : std_logic_vector(15 downto 0);
    signal i_ret_tx_uart_err_cnt   : std_logic_vector(15 downto 0);
    signal i_ret_rx_uart_start_cnt : std_logic_vector(15 downto 0);
    signal i_ret_rx_uart_err_cnt   : std_logic_vector(15 downto 0);
    signal i_ret_onoff_ctrl        : std_logic ;

    signal i_ook_a_uart_ctrl         : std_logic_vector(15 downto 0);
    signal i_ook_a_tx_uart_start_cnt : std_logic_vector(15 downto 0);
    signal i_ook_a_tx_uart_err_cnt   : std_logic_vector(15 downto 0);
    signal i_ook_a_rx_uart_start_cnt : std_logic_vector(15 downto 0);
    signal i_ook_a_rx_uart_err_cnt   : std_logic_vector(15 downto 0);

    signal i_ook_c_uart_ctrl         : std_logic_vector(15 downto 0);
    signal i_ook_c_tx_uart_start_cnt : std_logic_vector(15 downto 0);
    signal i_ook_c_tx_uart_err_cnt   : std_logic_vector(15 downto 0);
    signal i_ook_c_rx_uart_start_cnt : std_logic_vector(15 downto 0);
    signal i_ook_c_rx_uart_err_cnt   : std_logic_vector(15 downto 0);

    -- function fail
    signal i_ff_masking : std_logic;
    signal ru_ff_status : std_logic;

    signal i_ext_enb_ctrl : std_logic;

    signal s_resync_manual     : std_logic;
    signal s_resync_enable     : std_logic;
    signal s_resync_status_reg : std_logic_vector(31 downto 0);

    signal i_etm_mem_port_en : std_logic;
    signal i_etm_mem_wr_en   : std_logic;
    signal i_etm_mem_wr_addr : std_logic_vector(14 downto 0);
    signal i_etm_mem_wr_data : std_logic_vector(31 downto 0);
    signal i_tp_cpriout      : std_logic_vector(31 downto 0);

    signal i_npi_cpri_out : std_logic_array32(1 downto 0);
    signal i_tp_sel       : std_logic;

    signal rst_pdm : std_logic                    := '0';
    signal rst_pd  : std_logic_vector(1 downto 0) := "00";

    signal pdm_cnt_update    : std_logic;
    signal pdm_cnt_update_sh : std_logic_vector(2 downto 0);
    signal pdm_cnt           : std_logic_vector(15 downto 0);
    signal pdm_cnt_limit     : std_logic_vector(15 downto 0);
    signal pdm_cnt_sh        : std_logic_vector(15 downto 0);

    signal lmk_1pps_cnt    : std_logic_vector(27 downto 0);
    signal lmk_1pps        : std_logic;
    signal pll_pd          : std_logic_vector(30 downto 0);
    signal pll_pd30_sh     : std_logic;
    signal pll_pd_lat      : std_logic_vector(28 downto 0);
    signal pll_pd_irq_cnt  : std_logic_vector(5 downto 0);
    signal pll_pd_60s      : std_logic_vector(28 downto 0);
    signal RST_FUNC_PDNPDM : std_logic := '0';
    signal PD_LOOP_CLK     : std_logic;

    -- AMP Protection Timer
    signal i_t_dl_dly      : std_logic_vector( 10 downto 0);
    signal i_t_pa_off      : std_logic_vector( 10 downto 0);
    signal i_t_rf_swoff    : std_logic_vector( 10 downto 0);
--    attribute MARK_DEBUG : string;
--attribute MARK_DEBUG of FB_BFN_STRB_DCIF_OUT  : signal is "TRUE";
--attribute MARK_DEBUG of i_sync_1pps_10ms_in   : signal is "TRUE";
--attribute MARK_DEBUG of SYNC_1PPS_10MS_IN     : signal is "TRUE";

begin
    --------------------------------------
    ---- TDD signal mapping
    --------------------------------------
    --U_EQUIP_TDD_CTRL_FPGA_ASSIGN : if (PBA_NAME = "XTMD-07") generate 
    --   EQUIP_TDD           <= equip_tdd_r;
    --end generate;
    --
    --U_EQUIP_TDD_FPGA_FPGA_ASSIGN : if (PBA_NAME = "XTMC-07") generate 
    --   EQUIP_TDD           <= DFPGA_TDD(0) when equip_tdd_select(0) = '1' else 
    --                          DFPGA_TDD(1) when equip_tdd_select(1) = '1' else  
    --                          DFPGA_TDD(2) when equip_tdd_select(2) = '1' else   
    --                          DFPGA_TDD(3) when equip_tdd_select(3) = '1' else  
    --                          DFPGA_TDD(0) ;
    --end generate;
    --
    --    ul_dl_config                    <= TDD_CTRL_IN(2 downto 0);
    --    ssf_config                      <= TDD_CTRL_IN(11 downto 8);
    --    dl_cp_extended                  <= TDD_CTRL_IN(16);
    --    ul_cp_extended                  <= TDD_CTRL_IN(17);

    --------------------------------------
    ---- FeedBack switch mapping 
    --------------------------------------
    --    FBSW_MANUAL_MODE_OUT            <= sw_manual_set;               --: out std_logic;

    --    CAL_PATH_SEL_0_OUT              <= cal_path_sel(0);             --: out std_logic;
    --    CAL_PATH_SEL_1_OUT              <= cal_path_sel(1);             --: out std_logic;
    --    CAL_SP4T_0_RESERVED_OUT         <= cal_sp4t_reserved(0);        --: out std_logic;
    --    CAL_SP4T_1_RESERVED_OUT         <= cal_sp4t_reserved(1);        --: out std_logic;
    --    CAL_SP2T_0_RESERVED_OUT         <= cal_sp4t_reserved(2);        --: out std_logic;

    SSB_EXIST_OUT           <= ssb_exist;

    FBSW_CNT_245P76M_OUT    <= i_fb_sw_cnt_245p76m ;
    FBSW_CNT_307P20M_OUT    <= i_fb_sw_cnt_307p20m ;
    FBSW_AUTO_MODE_DONE_OUT <= i_fbsw_auto_mode_done;
    FBSW_PWR_MSR_UPT_OUT    <= i_fbsw_pwr_msr_upt ;
    ------------------------------------
    -- RFIC CTRL mapping 
    ------------------------------------
    U_RFIC_GPIO_MAPPING : for I in 0 to (RFIC_NUM - 1) generate
        RFIC_GPIO_OUT(I)(18 downto 16) <= rfic_orx_mode(I);
        RFIC_GPIO_OUT(I)(15 downto 10) <= i_rfic_gpio_out(I)(15 downto 10);
        RFIC_GPIO_OUT(I)(9)            <= rfic_orx_trigger(I);
        RFIC_GPIO_OUT(I)(8 downto 0)   <= i_rfic_gpio_out(I)(8 downto 0);

        i_rfic_gpio_in(I)(18 downto 14) <= RFIC_GPIO_IN(I)(18 downto 14);
        i_rfic_gpio_in(I)(13)           <= RFIC_GPIO_IN(I)(13);
        rfic_tx_obs_select(I)           <= RFIC_GPIO_IN(I)(13);
        i_rfic_gpio_in(I)(12 downto 0)  <= RFIC_GPIO_IN(I)(12 downto 0);
    end generate;

    --U_RFIC_TX_MAPPING : for I in 0 to (RFIC_NUM - 1) generate
    --    RFIC_TX_EN_OUT(I) <= rfic_tx_en(I) and rfic_tx_tdd(I);
    --    RFIC_RX_EN_OUT(I) <= rfic_rx_en(I) and rfic_rx_tdd(I);
    --end generate;

    ------------------------------------
    -- RFIC CTRL mapping 
    ------------------------------------
    U_AMP_EN_MAPPING : for I in 0 to (TX_ANT_NUM - 1) generate
        B13_AMP_EN_OUT(I) <= i_dpa_en_ctrl(I) and i_sig_sus_pa_en(I);
    end generate;



    --U_RF_SW_MAPPING: for I in 0 to (RFIC_NUM - 1) generate
    --    RFIC_TXA_SW_OUT(I) <= not ((i_rfic_txa_sw_out(I)) and (i_tx_sw_on(I*2   )));
    --    RFIC_TXB_SW_OUT(I) <= not ((i_rfic_txb_sw_out(I)) and (i_tx_sw_on(I*2 +1)));
    --end generate;    
    --
    --U_TX_SIGNAL_SUSPEND_MAPPING: for I in 0 to (RFIC_NUM - 1) generate
    --    tx_a_ss(I) <=  i_tx_sw_on(I*2   );   
    --    tx_b_ss(I) <=  i_tx_sw_on(I*2 +1);   
    --end generate; 

    ------------------------------------
    -- RF TX Switch Control
    ------------------------------------
    i_tx_a_switch <= i_tx_sw_on(0) and i_rf_tx_sw_ctrl(0);
    i_tx_b_switch <= i_tx_sw_on(1) and i_rf_tx_sw_ctrl(1);
    --i_tx_c_switch                       <= i_tx_sw_on(2) and i_rf_tx_sw_ctrl(2);
    --i_tx_d_switch                       <= i_tx_sw_on(3) and i_rf_tx_sw_ctrl(3);

    ------------------------------------
    -- Function Fail Check
    ------------------------------------
    ru_ff_status      <= '1'          when ((i_amp_enb_ctrl(0) = '0') and (i_amp_enb_ctrl(1) = '0')) else '0';
    FUNCTION_FAIL_OUT <= ru_ff_status when i_ff_masking = '0' else '0';

    -----------------------------------------------------------------------------------------------
    -- Reset Resynchronizer for each block
    -----------------------------------------------------------------------------------------------
    RST_FUNC_SADUMP  <= RST_MISC or i_rst_ctrl_test(0);
    RST_FUNC_DPA     <= RST_MISC or i_rst_ctrl_test(1);
    RST_FUNC_SIGSUS  <= RST_MISC or i_rst_ctrl_test(2);
    RST_FUNC_EXTCTRL <= RST_MISC or i_rst_ctrl_test(5);
    RST_FUNC_INTADC  <= RST_MISC or i_rst_ctrl_test(6);
    RST_FUNC_RETCB   <= RST_MISC or i_rst_ctrl_test(7);

    U_RST_SYNC_SADUMP   : RST_SYNC generic map( 4, 200 ) port map( RST_FUNC_SADUMP , CLK_SYSX8 , rst_sadump );
    U_RST_SYNC_DPA      : RST_SYNC generic map( 4, 200 ) port map( RST_FUNC_DPA , CLK_SYSX8 , rst_dpa );
    U_RST_SYNC_SIGSUS   : RST_SYNC generic map( 4, 200 ) port map( RST_FUNC_SIGSUS , CLK_SYSX8 , rst_sigsus );
    U_RST_SYNC_EXTCTRL0 : RST_SYNC generic map( 4, 200 ) port map( RST_FUNC_EXTCTRL , CLK_SYSX4 , rst_extctrl_x4 );
    U_RST_SYNC_EXTCTRL1 : RST_SYNC generic map( 4, 200 ) port map( RST_FUNC_EXTCTRL , CLK_SYSX5 , rst_extctrl_x5 );
    U_RST_SYNC_EXTCTRL2 : RST_SYNC generic map( 4, 200 ) port map( RST_FUNC_EXTCTRL , CLK_SYSX8 , rst_extctrl_x8 );
    U_RST_SYNC_EXTCTRL3 : RST_SYNC generic map( 4, 200 ) port map( RST_FUNC_EXTCTRL , CLK_SYSX10 , rst_extctrl_x10 );
    U_RST_SYNC_INTADC   : RST_SYNC generic map( 4, 200 ) port map( RST_FUNC_INTADC , CLK_SYSX8 , rst_intadc );
    U_RST_SYNC_RETCB    : RST_SYNC generic map( 4, 200 ) port map( RST_FUNC_RETCB , CLK_CPUIF , rst_retcb );
    U_RST_SYNC_PD1      : RST_SYNC generic map( 4, 200 ) port map( RST_MISC , CLK_CPUIF , rst_pd(1) );


    TEST_DATA_CPRI_OUT(0) <= i_tp_cpriout    when (i_tp_sel = '1') else i_npi_cpri_out(0);
    TEST_DATA_CPRI_OUT(1) <= (others => '0') when (i_tp_sel = '1') else i_npi_cpri_out(1);

    u_led_array : for I in LED_NUM-1 downto 0 generate
        LED_RED_OUT (i)  <= i_led_red (i);
        LED_GREEN_OUT(i) <= i_led_green(i);
        LED_BLUE_OUT (i) <= i_led_blue (i);

        U_LEDCTRL3_I : LEDCTRL3
            port map(
                RESET        => RST_CPUIF ,
                NCLK         => CLK_CPUIF , -- 100MHz
                LEDSEL       => LED_CTRL_SYSCTRL_IN (i) ,
                SOLID_RED_ON => '0' ,

                RLED => i_led_red (i) ,
                GLED => i_led_green (i) ,
                BLED => i_led_blue (i)
            );
    end generate;


    U_CPUIF_MISC : CPUIF_MISC
        port map(
            RST_CPU => RST_CPUIF , --: in  std_logic;  -- cpuif reset, '1': Reset
            CLK_CPU => CLK_CPUIF , --: in  std_logic;  -- cpuif clock, faster than iclk/oclk

            AXI_TIMEOUT_IN => AXI_TIMEOUT_IN , --: in  std_logic                                     ;

            CLK_SYSX4  => CLK_SYSX4 ,  --: in  std_logic;  -- 122.88 MHz
            CLK_SYSX8  => CLK_SYSX8 ,  --: in  std_logic;  -- 245.76 MHz
            CLK_SYSX10 => CLK_SYSX10 , --: in  std_logic;  -- 307.20 MHz

            CLK_MISC3 => CLK_MISC3 , --: in  std_logic;  -- 200.00 MHz

            ADDR_CPU_IN   => ADDR_CPUIF_IN ,   --: in  std_logic_vector(15 downto 0); -- cpuif address input, word address.
            WDATA_CPU_IN  => WDATA_CPUIF_IN ,  --: in  std_logic_vector(31 downto 0); -- cpuif data input
            RDATA_CPU_OUT => RDATA_CPUIF_OUT , --: out std_logic_vector(31 downto 0); -- cpuif data output
            WREN_CPU_IN   => WREN_CPUIF_IN ,   --: in  std_logic;  -- cpuif write enable, '1': active, synchronous with iclk
            RDEN_CPU_IN   => RDEN_CPUIF_IN ,   --: in  std_logic;  -- cpuif read enable, '1': active.
            RDVAL_CPU_OUT => RDVAL_CPUIF_OUT , --: out std_logic;  -- cpuif read data valid, '1': active, synchronous with clk_cpu.

            ----------------------------
            -- MISC
            ----------------------------
            RST_CTRL    => i_rst_ctrl_test , --: out std_logic_vector( 7 downto 0);
            BOARD_ID_IN => BOARD_ID_IN ,     -- : in  std_logic                                     ;

            ----------------------------
            -- SA_N_DUMP
            ----------------------------
            TP_SEL         => i_tp_sel ,
            SADUMP_VAL_OUT => open , --: out std_logic;    

            RX_SYSCTRL_STRB_SEL_OUT => i_rx_sysctrl_strb_sel , --: out std_logic_vector( 7 downto 0);
            TX_SYSCTRL_STRB_SEL_OUT => i_tx_sysctrl_strb_sel , --: out std_logic_vector( 7 downto 0);
            RX_CPRI_STRB_SEL_OUT    => i_rx_cpri_strb_sel ,    --: out std_logic_vector( 7 downto 0);
            MODULE_STRB_SEL_OUT     => i_module_strb_sel ,     --: out std_logic_vector( 7 downto 0);

            DUMP_STARTDLY_OUT => i_dump_startdly , --: out std_logic_vector(11 downto 0);
            DUMP_BUF_SEL_OUT  => i_dump_buf_sel ,  --: out std_logic_vector( 1 downto 0);
            DUMP_DATASEL_OUT  => i_dump_datasel ,  --: out std_logic_vector( 7 downto 0);

            DUMP_START_OUT => i_dump_start , --: out std_logic;
            DUMP_DONE_IN   => i_dump_done ,  --: in  std_logic;

            SA_ENB_OUT           => i_sa_enb ,           --: out std_logic;
            FB_SW_CNT_INFO_OUT   => i_fb_sw_cnt_info ,   --: out std_logic_vector( 5 downto 0);
            TXSA_CLKDLYVALUE_OUT => i_txsa_clkdlyvalue , --: out std_logic_vector(23 downto 0);

            PHASE_SEL_OUT => i_phase_sel , --: out std_logic;

            FIXED_PTN_BLK_SEL_OUT => i_fixed_ptn_blk_sel , --: out std_logic_vector( 7 downto 0);
            FIXED_PTN_LENGTH_OUT  => i_fixed_ptn_length ,  --: out std_logic_vector(12 downto 0);
            FIXED_PTN_ENB_OUT     => i_fixed_ptn_enb ,     --: out std_logic                    ;
            FIXED_PTN_START_OUT   => i_fixed_ptn_start ,   --: out std_logic                    ;

            DMA_WR_ENB           => i_dma_wren ,         --: out std_logic; 
            DMA_WR_BLK_SEL_OUT   => i_dma_wr_blk_sel ,   --: out std_logic_vector( 7 downto 0); 
            DMA_RD_ENB           => i_dma_rden ,         --: out std_logic; 
            DMA_RD_BLK_SEL_OUT   => i_dma_rd_blk_sel ,   --: out std_logic_vector( 7 downto 0);
            DMA_BFN_STRB_SEL_OUT => i_dma_bfn_strb_sel , --: out std_logic_vector( 7 downto 0);
            DMA_DLY_VALUE_OUT    => i_dma_dly_value ,    --: out std_logic_vector(23 downto 0);

            TEST_PTN_SEL_OUT => i_test_ptn_sel , --: out std_logic_vector( 1 downto 0);

            DMA_RD_FULL_IN  => DMA_RDFULL_IN , --: in  std_logic;
            DMA_RD_EMPTY_IN => DMA_RDEPT_IN ,  --: in  std_logic;
            DMA_WR_FULL_IN  => DMA_WRFULL_IN , --: in  std_logic;
            DMA_WR_EMPTY_IN => DMA_WREPT_IN ,  --: in  std_logic;

            SADUMP_ADDR_OUT  => i_sadump_addr ,  --: out std_logic_vector(15 downto 0);
            SADUMP_WDATA_OUT => i_sadump_wdata , --: out std_logic_vector(31 downto 0);
            SADUMP_WREN_OUT  => i_sadump_wren ,  --: out std_logic;
            SADUMP_RDEN_OUT  => i_sadump_rden ,  --: out std_logic;
            SADUMP_RDVAL_IN  => i_sadump_rdval , --: in  std_logic;
            SADUMP_RDATA_IN  => i_sadump_rdata , --: in  std_logic_vector(31 downto 0);    

            ----------------------------
            -- DPA
            ----------------------------
            DPA_EN => i_dpa_en , -- : out std_logic_vector(TX_ANT_NUM-1 downto 0); -- Dynamic PA on/off enable

            DPA_TRX_DATA_DELAY_TIME => i_dpa_trx_data_delay_time , -- : out std_logic_vector(15 downto 0); -- resolution 1/245.76MHz
            DPA_RISE_RESP_TIME      => i_dpa_rise_resp_time ,      -- : out std_logic_vector(15 downto 0); -- resolution 1/245.76MHz
            DPA_FALL_RESP_TIME      => i_dpa_fall_resp_time ,      -- : out std_logic_vector(15 downto 0); -- resolution 1/245.76MHz
            DPA_OFF_MON_TIME        => i_dpa_off_mon_time ,        -- : out std_logic_vector(15 downto 0); -- resolution 1/245.76MHz

            ----------------------------
            -- SIG_SUS
            ----------------------------
            WAVESTOP_DISABLE_OUT  => i_wavestop_disable ,   --: out std_logic;
            ALM_DEB_CNT_OUT       => i_alm_deb_cnt ,        --: out std_logic_vector( 19 downto 0);
            CPRI_LINK_ANT_OUT     => i_link_ant_releation , --: out std_logic_array8( 7 downto 0);
            RF_SW_OFF_RELEASE_OUT => i_rf_sw_off_release ,  --: out  std_logic_vector( 7 downto 0);

            UV_ALM_POST_IN  => i_uv_alm_post ,  --: in   std_logic;       -- '1': On          , '0': Off          ; PowerPAC Control Flag
            RFIC_OFF_SEQ_IN => i_rfic_off_seq , --: in   std_logic;       -- '1': On          , '0': Off
            HW_WDT_RST_IN   => i_hw_wdt_rst ,   --: in   std_logic;       -- '1': On          , '0': Off          ; PowerPAC Control Flag

            LOG_CPRIPHY_IN => i_log_cpriphy , --: in   std_logic_vector( 7 downto 0);  -- '1': Alarm       , '0': No Alarm
            LOG_SBIFPHY_IN => i_log_sbifphy , --: in   std_logic_vector( 7 downto 0);  -- '1': Alarm       , '0': No Alarm
            LOG_CPRI_IN    => i_log_cpri ,    --: in   std_logic_vector( 7 downto 0);  -- '1': Alarm       , '0': No Alarm
            LOG_SBIF_IN    => i_log_sbif ,    --: in   std_logic_vector( 7 downto 0);  -- '1': Alarm       , '0': No Alarm
            LOG_BBCTRL_IN  => i_log_bbctrl ,  --: in   std_logic_vector( 7 downto 0);  -- '1': Alarm       , '0': No Alarm
            LOG_DSP_IN     => i_log_dsp ,     --: in   std_logic_vector( 7 downto 0);  -- '1': Alarm       , '0': No Alarm
            LOG_DCIF_DL_IN => i_log_dcif_dl , --: in   std_logic_vector( 7 downto 0);  -- '1': Alarm       , '0': No Alarm
            LOG_DCIF_UL_IN => i_log_dcif_ul , --: in   std_logic_vector( 7 downto 0);  -- '1': Alarm       , '0': No Alarm
            LOG_DCIF_FB_IN => i_log_dcif_fb , --: in   std_logic_vector( 7 downto 0);  -- '1': Alarm       , '0': No Alarm

            LOG_CLK_IN        => i_log_clk ,        --: in   std_logic_vector( 1 downto 0);  -- '1': Alarm       , '0': No Alarm
            LOG_RFIC_IN       => i_log_rfic ,       --: in   std_logic_vector( 3 downto 0);  -- '1': Alarm       , '0': No Alarm
            LOG_VOLTAGE_IN    => i_log_voltage ,    --: in   std_logic_vector(31 downto 0);  -- '1': Alarm       , '0': No Alarm
            LOG_DAC_OFF_IN    => i_log_dac_off ,    --: in   std_logic_vector( 7 downto 0);  -- '1': Alarm       , '0': No Alarm
            LOG_WDT_IN        => i_log_wdt_out ,    --: in   std_logic_vector( 2 downto 0);

            SIG_SUS_MAIN_TYPE_IN => i_sig_sus_main_type , --: in   std_logic_vector( 7 downto 0);
            SIG_SUS_SUB_TYPE_IN  => i_sig_sus_sub_type ,  --: in   std_logic_vector( 7 downto 0);
            SIG_SUS_VER_IN       => i_sig_sus_ver ,       --: in   std_logic_vector( 7 downto 0);
            SIG_SUS_STRUCT_IN    => i_sig_sus_struct ,    --: in   std_logic_vector(31 downto 0);
            SIG_SUS_DATE_IN      => i_sig_sus_date ,      --: in   std_logic_vector(31 downto 0);

            ALM_OFF_VOLT_OUT => i_alm_off_volt , --: out  std_logic;                      -- '1': Forced Alarm-off, '0': No Force

            ALM_EN_CPRIPHY_OUT => i_alm_en_cpriphy , --: out  std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_SBIFPHY_OUT => i_alm_en_sbifphy , --: out  std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_CPRI_OUT    => i_alm_en_cpri ,    --: out  std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_SBIF_OUT    => i_alm_en_sbif ,    --: out  std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_BBCTRL_OUT  => i_alm_en_bbctrl ,  --: out  std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_DSP_OUT     => i_alm_en_dsp ,     --: out  std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_DCIF_DL_OUT => i_alm_en_dcif_dl , --: out  std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_DCIF_UL_OUT => i_alm_en_dcif_ul , --: out  std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_DCIF_FB_OUT => i_alm_en_dcif_fb , --: out  std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_VOLT_OUT    => i_alm_en_volt ,    --: out  std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_PG_OUT      => i_alm_en_pg ,      --: out  std_logic_vector(31 downto 0);  -- '1': Forced Alarm, '0': No Force
            ALM_EN_OTHERS_OUT  => i_alm_en_others ,  --: out  std_logic_vector(31 downto 0);  -- '1': Forced Alarm, '0': No Force

            DL_OFF_CPRIPHY_OUT => i_dl_off_cpriphy , --: out  std_logic_vector( 7 downto 0);  -- '1': Forced DL Off, '0': No Force
            DL_OFF_SBIFPHY_OUT => i_dl_off_sbifphy , --: out  std_logic_vector( 7 downto 0);  -- '1': Forced DL Off, '0': No Force
            DL_OFF_SBIF_OUT    => i_dl_off_sbif ,    --: out  std_logic_vector( 7 downto 0);  -- '1': Forced DL Off, '0': No Force
            DL_OFF_BBCTRL_OUT  => i_dl_off_bbctrl ,  --: out  std_logic_vector( 7 downto 0);  -- '1': Forced DL Off, '0': No Force
            DL_OFF_DSP_OUT     => i_dl_off_dsp ,     --: out  std_logic_vector( 7 downto 0);  -- '1': Forced DL Off, '0': No Force
            DL_OFF_DCIF_OUT    => i_dl_off_dcif ,    --: out  std_logic_vector( 7 downto 0)   -- '1': Forced DL Off, '0': No Force
                    -- AMP Protection Timer
            I_t_dl_dly         => i_t_dl_dly,        --: in std_logic_vector( 10 downto 0);
            I_t_pa_off         => i_t_pa_off,        --: in std_logic_vector( 10 downto 0);
            I_t_rf_swoff       => i_t_rf_swoff,      --: in std_logic_vector( 10 downto 0)
             ----------------------------
             -- FBSW_CTRL
             ----------------------------
            SW_MANUAL_SET   => sw_manual_set ,       --: out std_logic;                          -- '1' : manual operation by user, '0' : normal operation   
            SW_MANUAL_VALUE => sw_manual_value ,     --: out std_logic_vector(5 downto 0);                                                                   

            FB_SW_MODE => fb_sw_mode , --: out std_logic_array2(RFIC_NUM-1 downto 0);  -- reg

            RESYNC_MANUAL_OUT    => s_resync_manual ,     --          
            RESYNC_ENABLE_OUT    => s_resync_enable ,     --          
            RESYNC_STATUS_REG_IN => s_resync_status_reg , --           
                                                          --        ORX_SW_REG                  => orx_sw_reg                               , --: out std_logic_vector(3 downto 0); -- reg
                                                          --        ORX_SW_INVT_REG             => orx_sw_invt_reg                          , --: out std_logic_vector(3 downto 0); -- ORX_SW invert control
                                                          --        REV_SW_0_REG                => rev_sw_0_reg                             , --: out std_logic_vector(3 downto 0); -- reg 
                                                          --        REV_SW_0_INVT_REG           => rev_sw_0_invt_reg                        , --: out std_logic_vector(3 downto 0); -- REV_SW invert control
                                                          --        FB_REV_SW_0_REG             => fb_rev_sw_0_reg                          , --: out std_logic;                    -- reg 

            FB_SW_CTRL_VALUE_REG => fb_sw_ctrl_value_reg , --: out std_logic_array3(RFIC_NUM-1 downto 0);                                                                                                                        
            RFIC_ORX_TRIGGER_REG => rfic_orx_trigger_reg , --: out std_logic;                    -- reg 
            RFIC_ORX_MODE_REG    => rfic_orx_mode_reg ,    --: out std_logic_vector(2 downto 0); -- reg 

            ----------------------------
            -- TDD_CTRL
            ----------------------------
            EQUIP_OFFSET => equip_offset , --: out std_logic_vector(18 downto 0);                      
            EQUIP_ON     => equip_on ,     --: out std_logic_vector(14 downto 0);                      
            EQUIP_OFF    => equip_off ,    --: out std_logic_vector(14 downto 0);                      

            TRXSW_TX_OFFSET => trxsw_tx_offset , --: out std_logic_vector(18 downto 0);                      
            TRXSW_TX_ON     => trxsw_tx_on ,     --: out std_logic_vector(14 downto 0);                      
            TRXSW_TX_OFF    => trxsw_tx_off ,    --: out std_logic_vector(14 downto 0);                      

            TRXSW_RX_OFFSET => trxsw_rx_offset , --: out std_logic_vector(18 downto 0);                      
            TRXSW_RX_ON     => trxsw_rx_on ,     --: out std_logic_vector(14 downto 0);                      
            TRXSW_RX_OFF    => trxsw_rx_off ,    --: out std_logic_vector(14 downto 0);                      

            RFIC_TXA_SW_OFFSET => rfic_txa_sw_offset , --: out std_logic_array19(RFIC_NUM - 1 downto 0);           
            RFIC_TXA_SW_ON     => rfic_txa_sw_on ,     --: out std_logic_array15(RFIC_NUM - 1 downto 0);           
            RFIC_TXA_SW_OFF    => rfic_txa_sw_off ,    --: out std_logic_array15(RFIC_NUM - 1 downto 0);           

            RFIC_TXB_SW_OFFSET => rfic_txb_sw_offset , --: out std_logic_array19(RFIC_NUM - 1 downto 0);           
            RFIC_TXB_SW_ON     => rfic_txb_sw_on ,     --: out std_logic_array15(RFIC_NUM - 1 downto 0);           
            RFIC_TXB_SW_OFF    => rfic_txb_sw_off ,    --: out std_logic_array15(RFIC_NUM - 1 downto 0);           

            AMP_EN_OFFSET => amp_en_offset , --: out std_logic_array19(TX_ANT_NUM - 1 downto 0);         
            AMP_EN_ON     => amp_en_on ,     --: out std_logic_array15(TX_ANT_NUM - 1 downto 0);         
            AMP_EN_OFF    => amp_en_off ,    --: out std_logic_array15(TX_ANT_NUM - 1 downto 0);         

            RFIC_TX_EN_OFFSET => rfic_tx_en_offset , --: out std_logic_array2_array19(RFIC_NUM - 1 downto 0);    
            RFIC_TX_EN_ON     => rfic_tx_en_on ,     --: out std_logic_array2_array15(RFIC_NUM - 1 downto 0);    
            RFIC_TX_EN_OFF    => rfic_tx_en_off ,    --: out std_logic_array2_array15(RFIC_NUM - 1 downto 0);    

            RFIC_RX_EN_OFFSET => rfic_rx_en_offset , --: out std_logic_array2_array19(RFIC_NUM - 1 downto 0);    
            RFIC_RX_EN_ON     => rfic_rx_en_on ,     --: out std_logic_array2_array15(RFIC_NUM - 1 downto 0);    
            RFIC_RX_EN_OFF    => rfic_rx_en_off ,    --: out std_logic_array2_array15(RFIC_NUM - 1 downto 0);    

            RFIC_PRE_TRIG_OFFSET => rfic_pre_trig_offset , --: out std_logic_array19(RFIC_NUM - 1 downto 0);
            RFIC_PRE_TRIG_ON     => rfic_pre_trig_on ,     --: out std_logic_array15(RFIC_NUM - 1 downto 0);
            RFIC_PRE_TRIG_OFF    => rfic_pre_trig_off ,    --: out std_logic_array15(RFIC_NUM - 1 downto 0);        

            TX_CAL_SEL0_OFFSET => tx_cal_sel0_offset , --: out std_logic_vector(18 downto 0);                      
            TX_CAL_SEL0_ON     => tx_cal_sel0_on ,     --: out std_logic_vector(14 downto 0);                      
            TX_CAL_SEL0_OFF    => tx_cal_sel0_off ,    --: out std_logic_vector(14 downto 0);                      

            RX_CAL_SEL0_OFFSET => rx_cal_sel0_offset , --: out std_logic_vector(18 downto 0);                      
            RX_CAL_SEL0_ON     => rx_cal_sel0_on ,     --: out std_logic_vector(14 downto 0);                      
            RX_CAL_SEL0_OFF    => rx_cal_sel0_off ,    --: out std_logic_vector(14 downto 0);                      

            CAL_PATH_SEL_OFFSET => cal_path_sel_offset , --: out std_logic_array19(1 downto 0);                      
            CAL_PATH_SEL_ON     => cal_path_sel_on ,     --: out std_logic_array15(1 downto 0);                      
            CAL_PATH_SEL_OFF    => cal_path_sel_off ,    --: out std_logic_array15(1 downto 0);                      

            CAL_SP4T_RESERVED_OFFSET => cal_sp4t_reserved_offset , --: out std_logic_array19(2 downto 0);                      
            CAL_SP4T_RESERVED_ON     => cal_sp4t_reserved_on ,     --: out std_logic_array15(2 downto 0);                      
            CAL_SP4T_RESERVED_OFF    => cal_sp4t_reserved_off ,    --: out std_logic_array15(2 downto 0);                      

            TDD_AND_CTRL     => tdd_and_ctrl , --: out std_logic_array32(6 downto 0);                      
            TDD_OR_CTRL      => tdd_or_ctrl ,  --: out std_logic_array32(6 downto 0)                       
            EQUIP_TDD_SELECT => equip_tdd_select ,
            ----------------------------
            -- EXT_CTRL
            ----------------------------
            UDE_ETHPHY_RST  => UDE_ETH_nRESET ,    --: out std_logic;
            CLK_PLL_RST     => CLK_PLL_RESET_OUT , --: out std_logic;
            DLMK_RST        => open ,              --: out std_logic;
            DLMK_SYNC       => open ,              --: out std_logic;
            TDD_OUT_DIR     => open ,              --: out std_logic;
            EXT_CLK_DIR     => open ,              --: out std_logic
            KUFPGA_RST_CTRL => open ,              --: out std_logic;
            AMP_ENB_CTRL    => i_amp_enb_ctrl ,    --: out std_logic_vector(TX_ANT_NUM-1 downto 0);
            TRX_SW_CTRL     => open ,              --: out std_logic_vector(1 downto 0);
            TRX_TQL_9092_ON => open ,              --: out std_logic;
            BIAST_3P3V_EN   => BIAST_3P3V_EN,
            TRX_RF_EN_5P0V  => TRX_RF_EN_5P0V,
            ISPPAC_CTRL     => ISPPAC_CTRL_OUT ,    --: out std_logic_vector( 2 downto 0);
            FPGA_PWR_STATUS => FPGA_PWR_STATUS_IN , --: in  std_logic;

            ANALOG_DL_DLY_BYPASS => i_analog_dl_dly_bypass , --: out std_logic                              ;
            ANALOG_DL_DLY        => i_analog_dl_dly ,        --: out std_logic_vector(11 downto 0)          ;
            ANALOG_UL_DLY_BYPASS => i_analog_ul_dly_bypass , --: out std_logic                              ;
            ANALOG_UL_DLY        => i_analog_ul_dly ,        --: out std_logic_vector(11 downto 0)          ;
            ANALOG_FB_DLY_BYPASS => i_analog_fb_dly_bypass , --: out std_logic                              ;
            ANALOG_FB_DLY        => i_analog_fb_dly ,        --: out std_logic_vector(11 downto 0)          ;

            FUNC_FAIL_MASKING => i_ff_masking ,   --: out std_logic                              ;
            EXT_ENB_CTRL      => i_ext_enb_ctrl , --: out std_logic                              ;
            UDA               => UDA_IN,          --: in  std_logic_vector( 3 downto 0)        ;
            UDA_D             => UDA_D,           -- : in  std_logic_vector( 7 downto 0)       ;
            UDA_D_TX          => UDA_D_TX,        -- : out std_logic_vector( 3 downto 0)       ;

            CLK_PLL_LOS     => CLK_PLL_LOS_IN ,     --: in  std_logic                              ;
            CLK_PLL_LD      => CLK_PLL_LD_IN ,      --: in  std_logic                              ;
            CLK_PLL_LD_RSVD => CLK_PLL_LD_RSVD_IN , --: in  std_logic                                     ;

            AMP_AMC_RST1 => AMP_AMC_RST1_OUT , --: out std_logic                                     ; 
            AMP_AMC_RST2 => AMP_AMC_RST2_OUT , --: out std_logic                                     ; 

            ----------------------------
            -- RF TX Switch Control
            ----------------------------
            RF_TX_SW_CTRL => i_rf_tx_sw_ctrl , --: out std_logic_vector(TX_ANT_NUM-1 downto 0)       ;
            RF_EN_CTRL    => i_rf_enb_ctrl ,   --: out std_logic_vector(           1 downto 0)       ;

            ----------------------------
            -- RX Attenuation Control
            ----------------------------
            RXATT_ENB    => i_rxatt_enb ,    --: out std_logic                                     ;
            RXATT_WORD_A => i_rxatt_word_a , --: out std_logic_vector(6 downto 0)                  ;
            RXATT_WORD_B => i_rxatt_word_b , --: out std_logic_vector(6 downto 0)                  ;
            RXATT_WORD_C => i_rxatt_word_c , --: out std_logic_vector(6 downto 0)                  ;
            RXATT_WORD_D => i_rxatt_word_d , --: out std_logic_vector(6 downto 0)                  ;

            ----------------------------
            -- RFIC_CTRL
            ----------------------------
            RFIC_RST_CTRL    => i_rfic_rst_ctrl , --: out std_logic_vector(RFIC_NUM-1 downto 0);
            RFIC_TRI_ENB     => i_rfic_tri_enb ,  --: out std_logic_vector( RFIC_NUM-1 downto 0)        ;
            RFIC_PWR_ON      => i_rfic_pwr_on ,   --: out std_logic_vector(2 downto 0);
            PM2_RFIC_PWR_OFF => PM2_RFIC_PWR_OFF ,
            RFIC_TX_EN       => i_rfic_tx_en , --: out std_logic_array2(RFIC_NUM-1 downto 0);
            RFIC_RX_EN       => i_rfic_rx_en , --: out std_logic_array2(RFIC_NUM-1 downto 0);

            RFIC_GPIO_IN  => i_rfic_gpio_in ,  --: in  std_logic_array19(RFIC_NUM-1 downto 0);
            RFIC_GPIO_OUT => i_rfic_gpio_out , --: out std_logic_array19(RFIC_NUM-1 downto 0);

            RFIC_GP_INTERRUPT => RFIC_B13_GP_INTERRUPT_IN , --: in  std_logic_vector( RFIC_NUM-1 downto 0);

            ----------------------------
            -- INTADC
            ----------------------------
            INTADC_TEMP       => i_xadc_temp ,        --: in  std_logic_vector(15 downto 0);
            INTADC_VCCINT     => i_xadc_vccint ,      --: in  std_logic_vector(15 downto 0);
            INTADC_VCCPSINTLP => i_xadc_vccpsint_lp , --: in  std_logic_vector(15 downto 0);
            INTADC_VCCPSINTFP => i_xadc_vccpsint_fp , --: in  std_logic_vector(15 downto 0);
            INTADC_AUX        => i_xadc_aux ,         --: in  std_logic_array16(15 downto 0); 

            ----------------------------
            -- RET & Bias-T Control
            ----------------------------
            RET_UART_CTRL_OUT        => i_ret_uart_ctrl ,         --: out std_logic_vector( 15 downto 0);
            RET_TX_UART_START_CNT_IN => i_ret_tx_uart_start_cnt , --: in  std_logic_vector( 15 downto 0);
            RET_TX_UART_ERR_CNT_IN   => i_ret_tx_uart_err_cnt ,   --: in  std_logic_vector( 15 downto 0);
            RET_RX_UART_START_CNT_IN => i_ret_rx_uart_start_cnt , --: in  std_logic_vector( 15 downto 0);
            RET_RX_UART_ERR_CNT_IN   => i_ret_rx_uart_err_cnt ,   --: in  std_logic_vector( 15 downto 0);
            RET_ONOFF_CTRL_OUT       => i_ret_onoff_ctrl ,        --: out std_logic                                     ;

            OOK_A_UART_CTRL_OUT        => i_ook_a_uart_ctrl ,         --: out std_logic_vector( 15 downto 0);
            OOK_A_DIR_IN               => OOK_B13_A_DIR_IN ,          --: in  std_logic;
            OOK_A_DIRMD1_OUT           => OOK_B13_A_DIRMD1_OUT ,      --: out std_logic;
            OOK_A_DIRMD2_OUT           => OOK_B13_A_DIRMD2_OUT ,      --: out std_logic;
            BIAS_T_A_ONOFF_OUT         => BIAS_T_B13_A_ONOFF_OUT ,    --: out std_logic;
            OOK_A_TX_UART_START_CNT_IN => i_ook_a_tx_uart_start_cnt , --: in  std_logic_vector( 15 downto 0);
            OOK_A_TX_UART_ERR_CNT_IN   => i_ook_a_tx_uart_err_cnt ,   --: in  std_logic_vector( 15 downto 0);
            OOK_A_RX_UART_START_CNT_IN => i_ook_a_rx_uart_start_cnt , --: in  std_logic_vector( 15 downto 0);
            OOK_A_RX_UART_ERR_CNT_IN   => i_ook_a_rx_uart_err_cnt ,   --: in  std_logic_vector( 15 downto 0);

            OOK_C_UART_CTRL_OUT        => i_ook_c_uart_ctrl ,         --: out std_logic_vector( 15 downto 0);
            OOK_C_DIR_IN               => OOK_B13_C_DIR_IN ,          --: in  std_logic;
            OOK_C_DIRMD1_OUT           => OOK_B13_C_DIRMD1_OUT ,      --: out std_logic;
            OOK_C_DIRMD2_OUT           => OOK_B13_C_DIRMD2_OUT ,      --: out std_logic;
            BIAS_T_C_ONOFF_OUT         => BIAS_T_B13_C_ONOFF_OUT ,    --: out std_logic;
            OOK_C_TX_UART_START_CNT_IN => i_ook_c_tx_uart_start_cnt , --: in  std_logic_vector( 15 downto 0);
            OOK_C_TX_UART_ERR_CNT_IN   => i_ook_c_tx_uart_err_cnt ,   --: in  std_logic_vector( 15 downto 0);
            OOK_C_RX_UART_START_CNT_IN => i_ook_c_rx_uart_start_cnt , --: in  std_logic_vector( 15 downto 0);
            OOK_C_RX_UART_ERR_CNT_IN   => i_ook_c_rx_uart_err_cnt ,   --: in  std_logic_vector( 15 downto 0);
            FPGA_PSB_AMP_48V_ONOFF     => FPGA_PSB_AMP_48V_ONOFF,
            --------------------------------
            -- ETM MEMORY I/F
            --------------------------------
            ETM_MEM_PORT_EN => i_etm_mem_port_en , --: out std_logic;
            ETM_MEM_WR_EN   => i_etm_mem_wr_en ,   --: out std_logic;
            ETM_MEM_WR_ADDR => i_etm_mem_wr_addr , --: out std_logic_vector(14 downto 0)             ;
            ETM_MEM_WR_DATA => i_etm_mem_wr_data , --: out std_logic_vector(31 downto 0)             ;

            ----------------------------
            -- Module Information
            ----------------------------
            MISC_MODULE_INFO_IN => MISC_MODULE_INFO , --: in  std_logic_vector(31 downto 0);
            MISC_STRUCT_INFO_IN => MISC_STRUCT_INFO , --: in  std_logic_vector(31 downto 0);
            MISC_MODULE_DATE_IN => MISC_MODULE_DATE , --: in  std_logic_vector(31 downto 0);

            SADUMP_MODULE_INFO_IN => i_sadump_module_info , --: in  std_logic_vector(31 downto 0);
            SADUMP_STRUCT_INFO_IN => i_sadump_struct_info , --: in  std_logic_vector(31 downto 0);
            SADUMP_MODULE_DATE_IN => i_sadump_module_date , --: in  std_logic_vector(31 downto 0)
            
            PA_DRV_ONOFF    =>   PA_DRV_ONOFF, --              : out std_logic;
            
            SUPPER_SLEEP_POUT => SUPPER_SLEEP_POUT
        );


    --U_TP_MEM_BLK : LTE_ETM_1MS_TP
    --port map(
    --      RST                       => rst_sadump                               , --: in  std_logic;
    --      WCLK                      => CLK_SYSX8                                , --: in  std_logic;    -- CPUIF_MISC Clock domain
    --      RCLK                      => CLK_SYSX8                                , --: in  std_logic;    -- 245.76MHz Clock domain

    --      TP_MEM_PEN                => i_etm_mem_port_en                        ,  --: in  std_logic;    -- A/B port enable
    --      TP_MEM_AWEN               => i_etm_mem_wr_en                          ,  --: in  std_logic;    -- A port write enable
    --      TP_MEM_WRADDR             => i_etm_mem_wr_addr                        ,  --: in  std_logic_vector(14 downto 0);
    --      TP_MEM_WRDATA             => i_etm_mem_wr_data                        ,  --: in  std_logic_vector(31 downto 0);  -- 31..16 : Q data, 15..0 : I data

    --      SAMPLE_ENB                => TEST_ENB_CPRI_IN(0)                      , --: in  std_logic;    -- Sample period tick, activated only 1 cpri core clock per sample

    --      TP_OUT                    => i_tp_cpriout                               --: out std_logic_vector(31 downto 0)
    --     );


    U_DUMPBLK_TOP : DUMPBLK_TOP
        generic map(
            DUMP_BUF_NUM     => DUMP_BUF_NUM ,    --: natural := 1                                      ;
            CPRI_NUM         => CPRI_NUM ,        --: natural := 3                                      ;
            SA_USAGE         => SA_USAGE ,        --: boolean := TRUE                                   ;
            NPI_PTN_USAGE    => NPI_PTN_USAGE ,   --: boolean := FALSE                                  ;
            FIXED_PTN_USAGE  => FIXED_PTN_USAGE , --: boolean := FALSE                                  ;
            DUAL_DUMP_USAGE  => DUAL_DUMP_USAGE , --: boolean := FALSE                                  ;
            POLY_PHASE_USAGE => POLY_PHASE_USAGE  --: boolean := TRUE 
        )
        port map(
            RST_MISC => rst_sadump , --: in  std_logic                             ;
            CLK_CPU  => CLK_CPUIF ,  --: in  std_logic                             ;

            CLK_DUMP0 => CLK_SYSX8 ,  --: in  std_logic                             ;
            CLK_DUMP1 => CLK_SYSX10 , --: in  std_logic                             ;

            ADDR_CPU_IN   => i_sadump_addr ,  --: in  std_logic_vector(15 downto 0)         ;
            WDATA_CPU_IN  => i_sadump_wdata , --: in  std_logic_vector(31 downto 0)         ;
            WREN_CPU_IN   => i_sadump_wren ,  --: in  std_logic                             ;
            RDEN_CPU_IN   => i_sadump_rden ,  --: in  std_logic                             ;
            RDVAL_CPU_OUT => i_sadump_rdval , --: out std_logic                             ;
            RDATA_CPU_OUT => i_sadump_rdata , --: out std_logic_vector(31 downto 0)         ;

            --CPRIPHY_TOP(CFPGA)                                          
            DUMP_BFN_STRB_CPRIPHY_IN => DUMP_BFN_STRB_CPRIPHY_IN , --: in  std_logic_vector( 1 downto 0)         ;
            DUMP_DATA_CPRIPHY_IN     => DUMP_DATA_CPRIPHY_IN ,     --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_CPRIPHY_IN     => DUMP_DVLD_CPRIPHY_IN ,     --: in  std_logic_vector( 1 downto 0)         ;

            TEST_ENB_CPRIPHY_IN   => TEST_ENB_CPRIPHY_IN ,   --: in  std_logic_vector( 1 downto 0)         ;
            TEST_DATA_CPRIPHY_OUT => TEST_DATA_CPRIPHY_OUT , --: out std_logic_array32(1 downto 0)         ;

            --CPRI_TOP(CFPGA,DFPGA)                                       
            DUMP_BFN_STRB_CPRI_IN => DUMP_BFN_STRB_CPRI_IN , --: in  std_logic_vector( 1 downto 0)         ;
            DUMP_DATA_CPRI_IN     => DUMP_DATA_CPRI_IN ,     --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_CPRI_IN     => DUMP_DVLD_CPRI_IN ,     --: in  std_logic_vector( 1 downto 0)         ;

            TEST_ENB_CPRI_IN   => TEST_ENB_CPRI_IN , --: in  std_logic_vector( 1 downto 0)         ;
            TEST_DATA_CPRI_OUT => i_npi_cpri_out ,   --: out std_logic_array32(1 downto 0)         ;

            --SBIF_TOP(CFPGA,DFPGA)                                       
            DUMP_BFN_STRB_SBIF_IN => DUMP_BFN_STRB_SBIF_IN , --: in  std_logic_vector( 1 downto 0)         ;
            DUMP_DATA_SBIF_IN     => DUMP_DATA_SBIF_IN ,     --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_SBIF_IN     => DUMP_DVLD_SBIF_IN ,     --: in  std_logic_vector( 1 downto 0)         ;

            TEST_ENB_SBIF_IN   => TEST_ENB_SBIF_IN ,   --: in  std_logic_vector( 1 downto 0)         ;
            TEST_DATA_SBIF_OUT => TEST_DATA_SBIF_OUT , --: out std_logic_array32(1 downto 0)         ;

            --SBIFPHY_TOP(CFPGA,DFPGA)                                    
            DUMP_BFN_STRB_SBIFPHY_IN => DUMP_BFN_STRB_SBIFPHY_IN , --: in  std_logic_vector( 1 downto 0)         ;
            DUMP_DATA_SBIFPHY_IN     => DUMP_DATA_SBIFPHY_IN ,     --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_SBIFPHY_IN     => DUMP_DVLD_SBIFPHY_IN ,     --: in  std_logic_vector( 1 downto 0)         ;

            TEST_ENB_SBIFPHY_IN   => TEST_ENB_SBIFPHY_IN ,   --: in  std_logic_vector( 1 downto 0)         ;
            TEST_DATA_SBIFPHY_OUT => TEST_DATA_SBIFPHY_OUT , --: out std_logic_array32(1 downto 0)         ;

            --BBCTRL_TOP(DFPGA)
            DUMP_BFN_STRB_BBCTRL_IN => DUMP_BFN_STRB_BBCTRL_IN , --: in  std_logic_vector(1 downto 0)          ;
            DUMP_DATA_BBCTRL_IN     => DUMP_DATA_BBCTRL_IN ,     --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_BBCTRL_IN     => DUMP_DVLD_BBCTRL_IN ,     --: in  std_logic_vector(1 downto 0)          ;

            TEST_ENB_BBCTRL_IN   => TEST_ENB_BBCTRL_IN ,   --: in  std_logic_vector(1 downto 0)          ;
            TEST_DATA_BBCTRL_OUT => TEST_DATA_BBCTRL_OUT , --: out std_logic_array32(1 downto 0)         ;

            --DSP_TOP(DFPGA)                                              
            DUMP_BFN_STRB_DSP_IN => DUMP_BFN_STRB_DSP_IN , --: in  std_logic_vector( 1 downto 0)         ;
            DUMP_DATA_DSP_IN     => DUMP_DATA_DSP_IN ,     --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_DSP_IN     => DUMP_DVLD_DSP_IN ,     --: in  std_logic_vector( 1 downto 0)         ;

            TEST_ENB_DSP_IN   => TEST_ENB_DSP_IN ,   --: in  std_logic_vector(1 downto 0)          ;
            TEST_DATA_DSP_OUT => TEST_DATA_DSP_OUT , --: out std_logic_array32(1 downto 0)         ;

            --DCIF_TOP(DFPGA)
            DUMP_BFN_STRB_DCIF_IN => DUMP_BFN_STRB_DCIF_IN , --: in  std_logic_vector(1 downto 0)          ;
            DUMP_DATA_DCIF_IN     => DUMP_DATA_DCIF_IN ,     --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_DCIF_IN     => DUMP_DVLD_DCIF_IN ,     --: in  std_logic_vector(1 downto 0)          ;

            TEST_ENB_DCIF_IN   => TEST_ENB_DCIF_IN ,   --: in  std_logic_vector(1 downto 0)          ;
            TEST_DATA_DCIF_OUT => TEST_DATA_DCIF_OUT , --: out std_logic_array32(1 downto 0)         ;

            --External Device
            EXT_TRIGGER_IN => '0' , --: in  std_logic                             ;

            --SYSCTRL_TOP
            RX_BFNSTRB_SYSCTRL_IN => RX_BFN_STRB_SYSCTRL_IN , --: in  std_logic_vector(CPRI_NUM-1 downto 0) ;
            TX_BFNSTRB_SYSCTRL_IN => TX_BFN_STRB_SYSCTRL_IN , --: in  std_logic_vector(CPRI_NUM-1 downto 0) ;

            --CPRI_TOP
            RX_BFNSTRB_CPRI_IN => RX_BFN_STRB_CPRI_IN , --: in  std_logic_vector(CPRI_NUM-1 downto 0) ;

            --DMA interface
            DMA_RDCLK_OUT => DMA_RDCLK_OUT , --: out std_logic                             ;
            DMA_RDRDY_IN  => DMA_RDRDY_IN ,  --: in  std_logic                             ;
            DMA_RDEN_OUT  => DMA_RDEN_OUT ,  --: out std_logic                             ;
            DMA_RDATA_IN  => DMA_RDATA_IN ,  --: in  std_logic_vector(31 downto 0)         ;
            DMA_RDEPT_IN  => DMA_RDEPT_IN ,  --: in  std_logic                             ;

            DMA_WRCLK_OUT => DMA_WRCLK_OUT , --: out std_logic                             ;
            DMA_WRRDY_IN  => DMA_WRRDY_IN ,  --: in  std_logic                             ;
            DMA_WREN_OUT  => DMA_WREN_OUT ,  --: out std_logic                             ;
            DMA_WDATA_OUT => DMA_WDATA_OUT , --: out std_logic_vector(31 downto 0)         ;
            DMA_WRFULL_IN => DMA_WRFULL_IN , --: in  std_logic                             ;

            -- DUMP
            RX_SYSCTRL_STRB_SEL_IN => i_rx_sysctrl_strb_sel , --: in  std_logic_vector( 7 downto 0)         ;
            TX_SYSCTRL_STRB_SEL_IN => i_tx_sysctrl_strb_sel , --: in  std_logic_vector( 7 downto 0)         ;
            RX_CPRI_STRB_SEL_IN    => i_rx_cpri_strb_sel ,    --: in  std_logic_vector( 7 downto 0)         ;
            MODULE_STRB_SEL_IN     => i_module_strb_sel ,     --: in  std_logic_vector( 7 downto 0)         ; -- DUMPFSSEL_IN

            DUMP_BUF_SEL_IN => i_dump_buf_sel , --: in  std_logic_vector( 1 downto 0)         ; -- DUMPBUF_SEL_IN
            DUMP_DATASEL_IN => i_dump_datasel , --: in  std_logic_vector( 7 downto 0)         ; -- DUMPBLKSEL_IN

            DUMP_STARTDLY_IN => i_dump_startdly , --: in  std_logic_vector(11 downto 0)         ; -- BFNSTRBDLY_IN
            DUMP_START_IN    => i_dump_start ,    --: in  std_logic                             ;
            DUMP_DONE_OUT    => i_dump_done ,     --: out std_logic                             ;

            -- Dual Dump
            RX_SYSCTRL_STRB_SEL_2ND_IN => (others => '0') , --: in  std_logic_vector( 7 downto 0)                 ;
            TX_SYSCTRL_STRB_SEL_2ND_IN => (others => '0') , --: in  std_logic_vector( 7 downto 0)                 ;
            RX_CPRI_STRB_SEL_2ND_IN    => (others => '0') , --: in  std_logic_vector( 7 downto 0)                 ;
            MODULE_STRB_SEL_2ND_IN     => (others => '0') , --: in  std_logic_vector( 7 downto 0)                 ; -- DUMPFSSEL_IN

            DUMP_BUF_SEL_2ND_IN => (others => '0') , --: in  std_logic_vector( 1 downto 0)                 ; -- DUMPBUF_SEL_IN
            DUMP_DATASEL_2ND_IN => (others => '0') , --: in  std_logic_vector( 7 downto 0)                 ; -- DUMPBLKSEL_IN

            DUMP_STARTDLY_2ND_IN => (others => '0') , --: in  std_logic_vector(11 downto 0)                 ; -- BFNSTRBDLY_IN
            DUMP_DONE_2ND_OUT    => open ,            --: out std_logic                                     ;

            RDATA_MEMORY_SEL_IN => '0' , --: in  std_logic                                     ;

            -- Poly Phase Dump
            PHASE_SEL_IN => i_phase_sel , --: in  std_logic                             ;

            -- Spectrum Analyzer
            FBSW_CNT_IN       => i_fb_sw_cnt_307p20m ,      --: in  std_logic_vector( 5 downto 0)         ;
            AUTO_MODE_DONE_IN => i_fbsw_auto_mode_done(0) , --: in  std_logic                             ;
            SSB_EXIST_IN      => ssb_exist ,                --: in  std_logic                             ; -- SSB Exist Indicator, 19.10.07

            FBSW_MANUAL_IN        => sw_manual_set ,    --: in  std_logic                             ;
            FB_SW_CNT_INFO_IN     => i_fb_sw_cnt_info , --: in  std_logic_vector( 1 downto 0)         ;
            FB_SW_CNT_INFO_2ND_IN => (others => '0') ,  --: in  std_logic_vector( 1 downto 0)         ;

            TXSA_ENB_IN             => i_sa_enb ,           --: in  std_logic                             ;
            TXSA_ENB_2ND_IN         => '0' ,                --: in  std_logic                             ;
            TXSA_CLKDLYVALUE_IN     => i_txsa_clkdlyvalue , --: in  std_logic_vector(23 downto 0)         ; -- CLKDLYVALUE_IN
            TXSA_CLKDLYVALUE_2ND_IN => (others => '0') ,    --: in  std_logic_vector(23 downto 0)         ; -- CLKDLYVALUE_IN

            -- Fixed ptn generator
            FIXED_PTN_GEN_EN_IN  => i_fixed_ptn_enb ,     --: in  std_logic                             ;
            FIXED_PTN_START_IN   => i_fixed_ptn_start ,   --: in  std_logic                             ;
            FIXED_PTN_BLK_SEL_IN => i_fixed_ptn_blk_sel , --: in  std_logic_vector( 7 downto 0)         ;
            FIXED_PTN_LENGTH_IN  => i_fixed_ptn_length ,  --: in  std_logic_vector(12 downto 0)         ;

            -- NPI interface
            DMA_RDEN_IN          => i_dma_rden ,         --: in  std_logic                             ;
            DMA_WREN_IN          => i_dma_wren ,         --: in  std_logic                             ;
            DMA_READ_BLK_SEL_IN  => i_dma_rd_blk_sel ,   --: in  std_logic_vector( 7 downto 0)         ;
            DMA_WRITE_BLK_SEL_IN => i_dma_wr_blk_sel ,   --: in  std_logic_vector( 7 downto 0)         ;
            DMA_BFN_STRB_SEL_IN  => i_dma_bfn_strb_sel , --: in  std_logic_vector( 7 downto 0)         ;
            DMA_DLY_VALUE_IN     => i_dma_dly_value ,    --: in  std_logic_vector(23 downto 0)         ;

            TEST_PTN_SEL_IN    => i_test_ptn_sel , --: in  std_logic_vector( 1 downto 0)         ;
            TEST_PTN_VALID_OUT => open ,           --: out std_logic_vector( 1 downto 0)         ;

            -- Module information
            SADUMP_MODULE_INFO_OUT => i_sadump_module_info , --: out std_logic_vector(31 downto 0)         ;
            SADUMP_STRUCT_INFO_OUT => i_sadump_struct_info , --: out std_logic_vector(31 downto 0)         ;
            SADUMP_MODULE_DATE_OUT => i_sadump_module_date   --: out std_logic_vector(31 downto 0)

        );


    U_FB_SW_CTRL_GEN : FB_SW_CTRL
        port map (
            RESET_122P88M                   => rst_extctrl_x4,              --: in  std_logic;
            RESET_245P76M                   => rst_extctrl_x8,              --: in  std_logic;
            RESET_307P2M                    => rst_extctrl_x10,             --: in  std_logic;
            
            CLK_122P88M                     => CLK_SYSX4,                   --: in  std_logic;
            CLK_245P76M                     => CLK_SYSX8,                   --: in  std_logic;
            CLK_307P2M                      => CLK_SYSX10,                  --: in  std_logic;
            
            RX_BFN_STROBE                   => DDUC_DL_BFN_STRB,            --: in  std_logic;

            -- TEST MODE
            SW_MANUAL_SET                   => sw_manual_set,               --: in  std_logic;                              -- '1' : manual operation by user, '0' : normal operation   
            SW_MANUAL_VALUE                 => sw_manual_value,             --: in  std_logic_vector(5 downto 0);
            MANUAL_FB_SW_CTRL_VALUE         => fb_sw_ctrl_value_reg(0),     --: in  std_logic_vector(2 downto 0);
            MANUAL_RFIC_ORX_TRIGGER         => rfic_orx_trigger_reg,        --: in  std_logic; 
            MANUAL_RFIC_ORX_MODE            => rfic_orx_mode_reg,           --: in  std_logic_vector(2 downto 0);

            -- FW MODE
            FB_SW_MODE                      => fb_sw_mode(0),               --: in  std_logic_vector(1 downto 0);
            
            TX_A_SW                         => i_tx_sw_on(0),               --: in  std_logic;
            TX_B_SW                         => i_tx_sw_on(1),               --: in  std_logic;

            -- OUTPUT
            AUTO_MODE_DONE                  => i_fbsw_auto_mode_done(0),    --: out std_logic;

            AMP_FBSW_PATH_SEL               => FPGA_AMP_FBSW_PATH_SEL,      --: out std_logic;
            AMP_FBSW_EN_0                   => FPGA_AMP_FBSW_EN_0,          --: out std_logic;
            AMP_FBSW_EN_1                   => FPGA_AMP_FBSW_EN_1,          --: out std_logic;
            AMP_FBSW_FB_REV_SEL             => FPGA_AMP_FBSW_FB_REV_SEL,    --: out std_logic;
        
            RFIC_ORX_TRIGGER                => FPGA_RFIC_ORX_TRIGGER,       --: out std_logic;
            FPGA_TXOBS_SELECT               => RFIC_FPGA_TXOBS_SELECT,      --: in  std_logic;
            RFIC_ORXMODE_0                  => FPGA_RFIC_ORXMODE_0,         --: out std_logic;
            RFIC_ORXMODE_1                  => FPGA_RFIC_ORXMODE_1,         --: out std_logic;
            RFIC_ORXMODE_2                  => FPGA_RFIC_ORXMODE_2,         --: out std_logic;

            DPA_PATH_EN                     => i_dpa_en_ctrl,               --: in std_logic_vector(2-1 downto 0);        -- FOR 2ANT

            -- new port
            UV_ALM_IN                       => UV_ALARM_IN,                 --: in  std_logic;
            SSB_OFFSET                      => SSB_OFFSET,                  --: in  std_logic_vector(3 downto 0);
            ADV_SFN_MOD                     => ADV_SFN_MOD,                 --: in  std_logic_vector(3 downto 0);
            ADV_SFN_STRB                    => ADV_SFN_STRB,                --: in  std_logic;
            SSB_IND_FLAG                    => ssb_exist,                   --: out std_logic;
            RESYNC_STATUS_REG_OUT           => s_resync_status_reg,         --: out std_logic_vector(31 downto 0);

            --OUTPUT--
            FB_SW_MEASURE_DONE              => i_fbsw_pwr_msr_upt,          --: out std_logic;                             -- tick per every 10ms.  clock domain 
            FB_SW_START_TRIG                => FBSW_START_TRIG_OUT,         --: out std_logic;
            FB_SW_CNT_245P76M               => i_fb_sw_cnt_245p76m,         --: out std_logic_vector(5 downto 0);          -- 10ms period cnt by 245.76MHz cdc   
            FB_SW_CNT_307P2M                => i_fb_sw_cnt_307p20m,         --: out std_logic_vector(5 downto 0);          -- 10ms period cnt by 307.2MHz cdc

            DPD_SC_PATH_SEL_IN              => DPD_SC_PATH_SEL_IN           --: in  std_logic_vector(3 downto 0)
        );

    DPA_GEN : for i in 0 to (TX_ANT_NUM-1) generate
        U_DPA_ONOFF : DYNAMIC_PA_ONOFF
            port map(
                RESET => rst_dpa ,   -- : in  std_logic; -- DDUC CLK Sync.Reset                       
                CLK   => CLK_SYSX10 , -- : in  std_logic; -- DDUC CLK 245.76MHz

                DPA_EN => i_dpa_en(i) , -- : in  std_logic; -- Dynamic PA on/off enable

                CPU_PA_EN => i_amp_enb_ctrl(i) , -- : in  std_logic; -- PA enable

                DPA_TRX_DATA_DELAY_TIME => i_dpa_trx_data_delay_time , -- : in  std_logic_vector(15 downto 0); -- resolution 1/245.76MHz
                DPA_RISE_RESP_TIME      => i_dpa_rise_resp_time ,      -- : in  std_logic_vector(15 downto 0); -- resolution 1/245.76MHz
                DPA_FALL_RESP_TIME      => i_dpa_fall_resp_time ,      -- : in  std_logic_vector(15 downto 0); -- resolution 1/245.76MHz
                DPA_OFF_MON_TIME        => i_dpa_off_mon_time ,        -- : in  std_logic_vector(15 downto 0); -- resolution 1/245.76MHz

                IQ_ZERO_DET => DL_IQ_ISZERO_IN(i) , -- : in  std_logic; -- '1':IQ zero

                DPA_EN_CTRL => i_dpa_en_ctrl(i) -- : out std_logic -- '0': off, '1': on
            );
    end generate;



    U_SIG_SUS_TOP : SIG_SUS_TOP
        port map (
            -- Reset
            RST_CPUIF     => RST_CPUIF ,  --: in    std_logic;                                      -- Reset of 100 MHz
            RST_CLK_MISC3 => rst_sigsus , --: in    std_logic;                                      -- Reset of 200 MHz
            RST_CLK_SYSX8 => rst_sigsus , --: in    std_logic;                                      -- Reset of 245.76 MHz

            -- Clock
            CLK_CPU   => CLK_CPUIF , --: in    std_logic;                                      -- CPU CLK 100MHz, not CPU_PLL Clock
            CLK_MISC3 => CLK_MISC3 , --: in    std_logic;                                      -- Clock.   200 MHz
            CLK_SYSX8 => CLK_SYSX8 , --: in    std_logic;                                      -- Clock.   245.76 MHz

            -- Signal Suspension On/Off
            WAVESTOP_DISABLE_IN  => i_wavestop_disable ,  --: in    std_logic;                                      -- 100MHz CPU Clock Domain... wave stop disable control, except vss rst, for test
            ALM_DEB_CNT_IN       => i_alm_deb_cnt ,       --: in    std_logic_vector(                19 downto 0);  -- Alarm Debouncing Count
            RF_SW_OFF_RELEASE_IN => i_rf_sw_off_release , --: in    std_logic_vector(                 7 downto 0);  -- RF SW Off Release;   '0'->'1' : Release,  Others : No action

            -- Link Information
            IS_MASTER_CPRI_IN => IS_MASTER_CPRI_IN ,    --: in    std_logic_vector(        CPRI_NUM-1 downto 0);  -- '1': Master      , '0': Slave        ; When Master, ignore in wave stop process.
            LINK_ANT_RELATION => i_link_ant_releation , --: in    std_logic_array8(                 7 downto 0);  -- '1': Related     , '0': No           ; CPRI Link Antenna Releation

            -- Signal Suspension Alarms - Blocks
            SIG_SUS_FLAG_CPRIPHY_IN => SIG_SUS_FLAG_CPRIPHY_IN , --: in    std_logic_vector(        CPRI_NUM-1 downto 0);  -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_CPRI_IN    => SIG_SUS_FLAG_CPRI_IN ,    --: in    std_logic_vector(        CPRI_NUM-1 downto 0);  -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_SBIFPHY_IN => SIG_SUS_FLAG_SBIFPHY_IN , --: in    std_logic_vector(        SBIF_NUM-1 downto 0);  -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_SBIF_IN    => SIG_SUS_FLAG_SBIF_IN ,    --: in    std_logic_vector(        SBIF_NUM-1 downto 0);  -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_BBCTRL_IN  => SIG_SUS_FLAG_BBCTRL_IN ,  --: in    std_logic_vector(  DL_BBIQARY_NUM-1 downto 0);  -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_DSP_IN     => SIG_SUS_FLAG_DSP_IN ,     --: in    std_logic_vector(      TX_ANT_NUM-1 downto 0);  -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_DCIF_DL_IN => SIG_SUS_DLFLAG_DCIF_IN ,  --: in    std_logic_vector(JESD_TX_LINK_NUM-1 downto 0);  -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_DCIF_UL_IN => SIG_SUS_ULFLAG_DCIF_IN ,  --: in    std_logic_vector(JESD_RX_LINK_NUM-1 downto 0);  -- '1': Abnormal    , '0': Normal
            SIG_SUS_FLAG_DCIF_FB_IN => SIG_SUS_FBFLAG_DCIF_IN ,  --: in    std_logic_vector(JESD_FB_LINK_NUM-1 downto 0);  -- '1': Abnormal    , '0': Normal

            -- Signal Suspension Alarms - Voltages
            UV_ALM_IN            => UV_ALARM_IN ,        --: in    std_logic;                                      -- '1': Abnormal    , '0': Normal
            TRX_DC_IN_VD_FAIL_IN => TRX_DC_NORMAL_IN ,   --: in    std_logic;                                      -- '1': Normal      , '0': Abnormal
            FPGA_PWR_STATUS_IN   => FPGA_PWR_STATUS_IN , --: in    std_logic;                                      -- '1': Normal      , '0': Abnormal
            NPWR55_VD_FAIL_IN    => PWR55_NORMAL_IN ,    --: in    std_logic;                                      -- '1': Normal      , '0': Abnormal
            PG_NORMAL_IN         => i_pg_normal ,        --: in    std_logic_vector(                31 downto 0);  -- '1': Normal      , '0': Abnormal

            -- Signal Suspension Alarms - Others
            EXT_PLL_LOCK_IN                  => EXT_SYSPLL_LOCK_IN ,       --: in    std_logic;
            SYS_PLL_LOCK_IN                  => INT_SYSPLL_LOCK_IN ,       --: in    std_logic;
            RFIC_GP_INTERRUPT_IN(0 downto 0) => RFIC_B13_GP_INTERRUPT_IN , --: in    std_logic_vector(                 3 downto 0);
            RFIC_GP_INTERRUPT_IN(3 downto 1) => "000" ,                    --: in    std_logic_vector(                 3 downto 0);
            VSS_RMT_RST_CPRI_IN              => VSS_RMT_RST_CPRI_IN ,      --: in    std_logic;
            HWWDT_FLAG_IN                    => HWWDT_FLAG_IN ,            --: in    std_logic;
            SWWDT_FLAG_IN                    => SWWDT_FLAG_IN ,            --: in    std_logic;

            -- Signal Suspension - Blocks
            SIG_SUS_DLOFF_CPRIPHY_OUT => SIG_SUS_DLOFF_CPRIPHY_OUT , --: out   std_logic_vector(        SIG_CPRI-1 downto 0); 
            SIG_SUS_DLOFF_SBIFPHY_OUT => SIG_SUS_DLOFF_SBIFPHY_OUT , --: out   std_logic_vector(        SIG_SBIF-1 downto 0); 
            SIG_SUS_DLOFF_SBIF_OUT    => SIG_SUS_DLOFF_SBIF_OUT ,    --: out   std_logic_vector(        SIG_SBIF-1 downto 0); 
            SIG_SUS_DLOFF_BBCTRL_OUT  => SIG_SUS_DLOFF_BBCTRL_OUT ,  --: out   std_logic_vector(        SIG_CPRI-1 downto 0); 
            SIG_SUS_DLOFF_DSP_OUT     => SIG_SUS_DLOFF_DSP_OUT ,     --: out   std_logic_vector(      SIG_TX_ANT-1 downto 0); 

            -- Signal Suspension Controls
            TX_SW_ON_OUT     => i_tx_sw_on ,             --: out   std_logic_vector(                 7 downto 0);
            PA_EN_OUT        => i_sig_sus_pa_en ,        --: out   std_logic_vector(                 7 downto 0);
            OPT_TX_DIS_OUT   => SIG_SUS_DLOFF_OTRX_OUT , --: out   std_logic;
            AMC_RST_OUT      => i_amc_rst ,              --: out   std_logic;
            SOLID_RED_ON_OUT => i_solid_red_on ,         --: out   std_logic;
            UV_ALM_POST_OUT  => i_uv_alm_post ,          --: out   std_logic;
            RFIC_OFF_SEQ_OUT => i_rfic_off_seq ,         --: out   std_logic;
            HW_WDT_RST_OUT   => i_hw_wdt_rst ,           --: out   std_logic;

            -- Monitoring - Blocks
            LOG_CPRIPHY_OUT => i_log_cpriphy , --: out   std_logic_vector(                 7 downto 0); 
            LOG_SBIFPHY_OUT => i_log_sbifphy , --: out   std_logic_vector(                 7 downto 0); 
            LOG_CPRI_OUT    => i_log_cpri ,    --: out   std_logic_vector(                 7 downto 0); 
            LOG_SBIF_OUT    => i_log_sbif ,    --: out   std_logic_vector(                 7 downto 0); 
            LOG_BBCTRL_OUT  => i_log_bbctrl ,  --: out   std_logic_vector(                 7 downto 0); 
            LOG_DSP_OUT     => i_log_dsp ,     --: out   std_logic_vector(                 7 downto 0); 
            LOG_DCIF_DL_OUT => i_log_dcif_dl , --: out   std_logic_vector(                 7 downto 0); 
            LOG_DCIF_UL_OUT => i_log_dcif_ul , --: out   std_logic_vector(                 7 downto 0); 
            LOG_DCIF_FB_OUT => i_log_dcif_fb , --: out   std_logic_vector(                 7 downto 0); 

            -- Monitoring - Others
            LOG_CLK_OUT     => i_log_clk ,     --: out   std_logic_vector(                 1 downto 0); 
            LOG_RFIC_OUT    => i_log_rfic ,    --: out   std_logic_vector(                 3 downto 0); 
            LOG_VOLTAGE_OUT => i_log_voltage , --: out   std_logic_vector(                31 downto 0); 
            LOG_DAC_OFF_OUT => i_log_dac_off , --: out   std_logic_vector(                 7 downto 0); 
            LOG_WDT_OUT     => i_log_wdt_out , --: out   std_logic_vector(                 1 downto 0); 

            -- History
            HIS_MAIN_TYPE_OUT => i_sig_sus_main_type , --: out   std_logic_vector(                 7 downto 0);
            HIS_SUB_TYPE_OUT  => i_sig_sus_sub_type ,  --: out   std_logic_vector(                 7 downto 0);
            HIS_VER_OUT       => i_sig_sus_ver ,       --: out   std_logic_vector(                 7 downto 0);
            HIS_STRUCT_OUT    => i_sig_sus_struct ,    --: out   std_logic_vector(                31 downto 0);
            HIS_DATE_OUT      => i_sig_sus_date ,      --: out   std_logic_vector(                31 downto 0);

            -- Test Function - Voltage Alarm Off
            ALM_DIS_VOLT_IN => i_alm_off_volt , --: in    std_logic;                                      -- '1': Forced Alarm-off, '0': No Force

            -- Test Function - Alarm Enable
            ALM_EN_CPRIPHY_IN => i_alm_en_cpriphy , --: in    std_logic_vector(                 7 downto 0); 
            ALM_EN_SBIFPHY_IN => i_alm_en_sbifphy , --: in    std_logic_vector(                 7 downto 0); 
            ALM_EN_CPRI_IN    => i_alm_en_cpri ,    --: in    std_logic_vector(                 7 downto 0); 
            ALM_EN_SBIF_IN    => i_alm_en_sbif ,    --: in    std_logic_vector(                 7 downto 0); 
            ALM_EN_BBCTRL_IN  => i_alm_en_bbctrl ,  --: in    std_logic_vector(                 7 downto 0); 
            ALM_EN_DSP_IN     => i_alm_en_dsp ,     --: in    std_logic_vector(                 7 downto 0); 
            ALM_EN_DCIF_DL_IN => i_alm_en_dcif_dl , --: in    std_logic_vector(                 7 downto 0); 
            ALM_EN_DCIF_UL_IN => i_alm_en_dcif_ul , --: in    std_logic_vector(                 7 downto 0); 
            ALM_EN_DCIF_FB_IN => i_alm_en_dcif_fb , --: in    std_logic_vector(                 7 downto 0); 
            ALM_EN_VOLT_IN    => i_alm_en_volt ,    --: in    std_logic_vector(                 7 downto 0); 
            ALM_EN_PG_IN      => i_alm_en_pg ,      --: in    std_logic_vector(                31 downto 0); 
            ALM_EN_OTHERS_IN  => i_alm_en_others ,  --: in    std_logic_vector(                31 downto 0); 

            -- Test Function - DL Off
            DL_OFF_CPRIPHY_IN => i_dl_off_cpriphy , --: in    std_logic_vector(                 7 downto 0); 
            DL_OFF_SBIFPHY_IN => i_dl_off_sbifphy , --: in    std_logic_vector(                 7 downto 0); 
            DL_OFF_SBIF_IN    => i_dl_off_sbif ,    --: in    std_logic_vector(                 7 downto 0); 
            DL_OFF_BBCTRL_IN  => i_dl_off_bbctrl ,  --: in    std_logic_vector(                 7 downto 0); 
            DL_OFF_DSP_IN     => i_dl_off_dsp ,     --: in    std_logic_vector(                 7 downto 0); 
            DL_OFF_DCIF_IN    => i_dl_off_dcif,     --: in    std_logic_vector(                 7 downto 0);

            -- AMP Protection Timer
            I_t_dl_dly    => i_t_dl_dly,            --: in std_logic_vector( 10 downto 0);
            I_t_pa_off    => i_t_pa_off,            --: in std_logic_vector( 10 downto 0);
            I_t_rf_swoff  => i_t_rf_swoff           --: in std_logic_vector( 10 downto 0)
        );

    i_pg_normal( 0) <= PG_0P85V_MFPGA;
    i_pg_normal( 1) <= '0';
    i_pg_normal( 2) <= PG_1P8V_MFPGA;
    i_pg_normal( 3) <= '0';
    i_pg_normal( 4) <= PG_1P2V_MFPGA_MGT;
    i_pg_normal( 5) <= '0';
    i_pg_normal( 6) <= PG_5P5V;
    i_pg_normal( 7) <= '0';
    i_pg_normal( 8) <= PG_1P2V_DDR4;
    i_pg_normal( 9) <= '0';
    i_pg_normal(10) <= PG_3P3V_CLK;
    i_pg_normal(11) <= '0';
    i_pg_normal(12) <= PG_3P3V;
    i_pg_normal(13) <= '0';
    i_pg_normal(14) <= PG_0P9V_MFPGA_MGT;
    i_pg_normal(15) <= '0';
    i_pg_normal(16) <= PG_1P3V_RFIC_JESD;
    i_pg_normal(17) <= '0';
    i_pg_normal(18) <= PG_1P3V_RFIC0_DIGITAL;
    i_pg_normal(19) <= '0';
    i_pg_normal(20) <= PG_1P3V_RFIC0_ANALOG;

    i_pg_normal(31 downto 21) <= (others => '1');

    RFIC_TRI_ENB <= i_rfic_tri_enb;

    --------------------------------
    -- RET Control Block
    --------------------------------
    U_RET_CTRL : RETCB
        port map(
            RST         => rst_retcb ,          -- : in  std_logic                                     ;
            CLK_SYS     => CLK_CPUIF ,          -- : in  std_logic                                     ;
            UART1_TX    => UART0_MP_IN ,        -- : in  std_logic                                     ;
            UART1_RX_IN => RET_UART_RXD_IN ,    -- : in  std_logic                                     ;
            RET_TEST_EN => i_ret_uart_ctrl(0) , -- : in  std_logic                                     ;
            LSBorMSB    => i_ret_uart_ctrl(4) , -- : in  std_logic                                     ;

            UART1_TX_OUT      => RET_UART_TXD_OUT ,        -- : out std_logic                                     ;
            UART1_RX          => UART0_MP_OUT ,            -- : out std_logic                                     ;
            RET_nRE           => RET_nRE_OUT ,             -- : out std_logic                                     ;
            RET_DE            => RET_DE_OUT ,              -- : out std_logic                                     ;
            TX_UART_START_CNT => i_ret_tx_uart_start_cnt , -- : out std_logic_vector(15 downto 0)                 ;
            TX_UART_ERR_CNT   => i_ret_tx_uart_err_cnt ,   -- : out std_logic_vector(15 downto 0)                 ;
            RX_UART_START_CNT => i_ret_rx_uart_start_cnt , -- : out std_logic_vector(15 downto 0)                 ;
            RX_UART_ERR_CNT   => i_ret_rx_uart_err_cnt ,   -- : out std_logic_vector(15 downto 0)                 ;
            UART_CLK          => open ,                    -- : out std_logic                                     ;
            UART1_TX_BUFF     => open                      -- : out std_logic_vector(7 downto 0)
        );

    --------------------------------
    -- Bias-T Control Block
    --------------------------------
    U_BIAS_T_A : RETCB
        port map(
            RST         => rst_retcb ,            -- : in  std_logic                                     ;
            CLK_SYS     => CLK_CPUIF ,            -- : in  std_logic                                     ;
            UART1_TX    => UART1_MP_IN ,          -- : in  std_logic                                     ;
            UART1_RX_IN => OOK_B13_A_RXOUT ,      -- : in  std_logic                                     ;
            RET_TEST_EN => i_ook_a_uart_ctrl(0) , -- : in  std_logic                                     ;
            LSBorMSB    => i_ook_a_uart_ctrl(4) , -- : in  std_logic                                     ;

            UART1_TX_OUT      => OOK_B13_A_TXIN ,            -- : out std_logic                                     ;
            UART1_RX          => UART1_MP_OUT ,              -- : out std_logic                                     ;
            RET_nRE           => open ,                      -- : out std_logic                                     ;
            RET_DE            => open ,                      -- : out std_logic                                     ;
            TX_UART_START_CNT => i_ook_a_tx_uart_start_cnt , -- : out std_logic_vector(15 downto 0)                 ;
            TX_UART_ERR_CNT   => i_ook_a_tx_uart_err_cnt ,   -- : out std_logic_vector(15 downto 0)                 ;
            RX_UART_START_CNT => i_ook_a_rx_uart_start_cnt , -- : out std_logic_vector(15 downto 0)                 ;
            RX_UART_ERR_CNT   => i_ook_a_rx_uart_err_cnt ,   -- : out std_logic_vector(15 downto 0)                 ;
            UART_CLK          => open ,                      -- : out std_logic                                     ;
            UART1_TX_BUFF     => open                        -- : out std_logic_vector(7 downto 0)
        );


    U_BIAS_T_C : RETCB
        port map(
            RST         => rst_retcb ,            -- : in  std_logic                                     ;
            CLK_SYS     => CLK_CPUIF ,            -- : in  std_logic                                     ;
            UART1_TX    => UART2_MP_IN ,          -- : in  std_logic                                     ;
            UART1_RX_IN => OOK_B13_C_RXOUT ,      -- : in  std_logic                                     ;
            RET_TEST_EN => i_ook_c_uart_ctrl(0) , -- : in  std_logic                                     ;
            LSBorMSB    => i_ook_c_uart_ctrl(4) , -- : in  std_logic                                     ;

            UART1_TX_OUT      => OOK_B13_C_TXIN ,            -- : out std_logic                                     ;
            UART1_RX          => UART2_MP_OUT ,              -- : out std_logic                                     ;
            RET_nRE           => open ,                      -- : out std_logic                                     ;
            RET_DE            => open ,                      -- : out std_logic                                     ;
            TX_UART_START_CNT => i_ook_c_tx_uart_start_cnt , -- : out std_logic_vector(15 downto 0)                 ;
            TX_UART_ERR_CNT   => i_ook_c_tx_uart_err_cnt ,   -- : out std_logic_vector(15 downto 0)                 ;
            RX_UART_START_CNT => i_ook_c_rx_uart_start_cnt , -- : out std_logic_vector(15 downto 0)                 ;
            RX_UART_ERR_CNT   => i_ook_c_rx_uart_err_cnt ,   -- : out std_logic_vector(15 downto 0)                 ;
            UART_CLK          => open ,                      -- : out std_logic                                     ;
            UART1_TX_BUFF     => open                        -- : out std_logic_vector(7 downto 0)
        );

    --------------------------------
    -- Analog Processing Delay
    --------------------------------
    i_dl_ssb_strb_dcif <= DL_SSB_STRB_DCIF_IN ;
    i_dl_bfn_strb_dcif <= DL_BFN_STRB_DCIF_IN ;
    i_dl_tdd_dcif      <= DL_TDD_DCIF_IN ;

    U_DL_Analog_Delay : TDD_STRB_CNTDLY
        port map(
            RST => rst_extctrl_x4 , --: in  std_logic;
            CLK => CLK_SYSX4 ,      --: in  std_logic;

            BLK_BYPASS_IN => i_analog_dl_dly_bypass , --: in  std_logic;
            DLYCNT_IN     => i_analog_dl_dly ,        --: in  std_logic_vector(11 downto 0);

            BFN_STROBE_IN => i_dl_bfn_strb_dcif , --: in  std_logic;
            TDD_STROBE_IN => i_dl_tdd_dcif ,      --: in  std_logic;

            BFNSTRB_DLY_OUT => i_dl_bfn_strb_dcif_out , --: out std_logic;
            TDDSTRB_DLY_OUT => i_dl_tdd_dcif_out        --: out std_logic
        );

    U_DL_Analog_Delay_SSB : TDD_STRB_CNTDLY
        port map(
            RST => rst_extctrl_x4 , --: in  std_logic;
            CLK => CLK_SYSX4 ,      --: in  std_logic;

            BLK_BYPASS_IN => i_analog_dl_dly_bypass , --: in  std_logic;
            DLYCNT_IN     => i_analog_dl_dly ,        --: in  std_logic_vector(11 downto 0);

            BFN_STROBE_IN => i_dl_ssb_strb_dcif , --: in  std_logic;
            TDD_STROBE_IN => '0' ,                --: in  std_logic;

            BFNSTRB_DLY_OUT => i_dl_ssb_strb_dcif_out , --: out std_logic;
            TDDSTRB_DLY_OUT => open                     --: out std_logic
        );
    
    --i_sync_1pps_10ms_in <= SYNC_1PPS_10MS_IN;
    i_sync_1pps_10ms_in <= SYNC_1PPS_10MS_IN or i_sync_1pps_10ms_in_d1 or i_sync_1pps_10ms_in_d2;
    
    process(rst_extctrl_x8, CLK_SYSX8) begin
        if (rst_extctrl_x8 = '1') then
            
            i_sync_1pps_10ms_in_d2 <=  '0';
            i_sync_1pps_10ms_in_d1 <=  '0';
            --i_sync_1pps_10ms_in_d3 <=  '0';
            
        elsif (CLK_SYSX8'event) and (CLK_SYSX8 = '1') then
            i_sync_1pps_10ms_in_d1 <= SYNC_1PPS_10MS_IN;
            i_sync_1pps_10ms_in_d2 <= i_sync_1pps_10ms_in_d1;
            --i_sync_1pps_10ms_in_d3 <= i_sync_1pps_10ms_in_d2;
        end if;
    end process;

    U_UL_Analog_Delay : TDD_STRB_CNTDLY
        port map(
            RST => rst_extctrl_x4 , --: in  std_logic;
            CLK => CLK_SYSX4 ,      --: in  std_logic;

            BLK_BYPASS_IN => i_analog_ul_dly_bypass , --: in  std_logic;
            DLYCNT_IN     => i_analog_ul_dly ,        --: in  std_logic_vector(11 downto 0);

            BFN_STROBE_IN => i_sync_1pps_10ms_in , --: in  std_logic;
            TDD_STROBE_IN => UL_TDD_1PPS_IN ,      --: in  std_logic;

            BFNSTRB_DLY_OUT => UL_BFN_STRB_DCIF_OUT , --: out std_logic;
            TDDSTRB_DLY_OUT => i_ul_tdd_dcif_out      --: out std_logic
        );

    U_FB_Analog_Delay : TDD_STRB_CNTDLY
        port map(
            RST => rst_extctrl_x4 , --: in  std_logic;
            CLK => CLK_SYSX4 ,      --: in  std_logic;

            BLK_BYPASS_IN => i_analog_fb_dly_bypass , --: in  std_logic;
            DLYCNT_IN     => i_analog_fb_dly ,        --: in  std_logic_vector(11 downto 0);

            BFN_STROBE_IN => i_sync_1pps_10ms_in , --: in  std_logic;
            TDD_STROBE_IN => i_dl_tdd_dcif_out ,      --: in  std_logic;

            BFNSTRB_DLY_OUT => FB_BFN_STRB_DCIF_OUT , --: out std_logic;
            TDDSTRB_DLY_OUT => i_fb_tdd_dcif_out      --: out std_logic
        );

    TDD_SIG_SET0 : if (DUPLEX_TYPE = "FDD") generate
        UL_TDD_DCIF_OUT <= '1';
        FB_TDD_DCIF_OUT <= '1';
    end generate;

    TDD_SIG_SET1 : if (DUPLEX_TYPE = "TDD") generate
        UL_TDD_DCIF_OUT <= i_ul_tdd_dcif_out;
        FB_TDD_DCIF_OUT <= i_fb_tdd_dcif_out;
    end generate;

    ----------------------------
    -- Ports on Schemetics
    ----------------------------
    TX_B13_A_SW_OUT <= i_tx_a_switch; --: out std_logic                                     ;
    TX_B13_B_SW_OUT <= i_tx_b_switch; --: out std_logic                                     ;
    TX_B13_C_SW_OUT <= i_tx_c_switch; --: out std_logic                                     ;
    TX_B13_D_SW_OUT <= i_tx_d_switch; --: out std_logic                                     ;

    EXT_EN_5p0V_OUT <= i_ext_enb_ctrl;   --: out std_logic                                     ;
    RET_ONOFF_OUT   <= i_ret_onoff_ctrl; --: out std_logic                                     ;

    RFIC_B13_TX_EN_OUT  <= i_rfic_tx_en;    --: out std_logic_array2(RFIC_NUM-1 downto 0)         ;
    RFIC_B13_RESETB_OUT <= i_rfic_rst_ctrl; --: out std_logic_vector(RFIC_NUM-1 downto 0)         ;

    RFIC_AB_EN_OUT   <= i_rfic_pwr_on;    --: out std_logic_vector(2 downto 0)                  ;
    RF_B13_AB_EN_OUT <= i_rf_enb_ctrl(0); --: out std_logic                                     ;
    RF_B13_CD_EN_OUT <= i_rf_enb_ctrl(1); --: out std_logic                                     ;


end arc_MISC_TOP;
