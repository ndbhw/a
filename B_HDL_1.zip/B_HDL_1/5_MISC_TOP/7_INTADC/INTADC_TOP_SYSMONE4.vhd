library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity INTADC_TOP_SYSMONE4 is
port(
    RST_XADC                        : in  std_logic;                        -- XADC Synchronous Reset (100MHz)
    CLK                             : in  std_logic;                        -- 100MHz Register Map Clock

    XADC_CHANNEL_P                  : in  std_logic_vector(15 downto 0);    -- AUX_P[15:0]
    XADC_CHANNEL_N                  : in  std_logic_vector(15 downto 0);    -- AUX_N[15:0]

    XADC_VP_IN                      : in  std_logic;                        -- Dedicated Analog Input Pair - P
    XADC_VN_IN                      : in  std_logic;                        -- Dedicated Analog Input Pair - N

    XADC_TEMP                       : out std_logic_vector(15 downto 0);    -- XADC Temperature output
    XADC_VCCINT                     : out std_logic_vector(15 downto 0);    -- XADC VCCINT      output
    XADC_VCCPSINTLP                 : out std_logic_vector(15 downto 0);    -- XADC VCC PS INT LP output
    XADC_VCCPSINTFP                 : out std_logic_vector(15 downto 0);    -- XADC VCC PS INT FP output
    XADC_AUX                        : out std_logic_array16(15 downto 0)    -- XADC AUX #0~15  output
    );
end INTADC_TOP_SYSMONE4;

architecture arc_INTADC_TOP_SYSMONE4 of INTADC_TOP_SYSMONE4 is

    component INTADC_WRAPPER_SYSMONE4 is
    port(
        RST                             : in  std_logic;                      -- 100MHz Synchronous Reset
        CLK                             : in  std_logic;                      -- 100MHz Register Map Clock
    
        VP_IN                           : in  std_logic;                      -- Dedicated Analog Input Pair
        VN_IN                           : in  std_logic;
        AUX_P                           : in  std_logic_vector(15 downto 0);  -- AUX_P[15:0]
        AUX_N                           : in  std_logic_vector(15 downto 0);  -- AUX_N[15:0]
    
        TEMPERATURE_XADC                : out std_logic_vector(15 downto 0);  -- Temperature
        VCCINT                          : out std_logic_vector(15 downto 0);  -- VCCINT
        VCCAUX                          : out std_logic_vector(15 downto 0);  -- VCCAUX
        VPN                             : out std_logic_vector(15 downto 0);  -- VPN 
        VREF_P                          : out std_logic_vector(15 downto 0);  -- VREF_P 
        VREF_N                          : out std_logic_vector(15 downto 0);  -- VREF_N
        VCCBRAM                         : out std_logic_vector(15 downto 0);  -- VCCBRAM
        XADC_CAL                        : out std_logic_vector(15 downto 0);  -- XADC_CAL 
        VCC_PSINTLP                     : out std_logic_vector(15 downto 0);  -- VCC PS INT LP
        VCC_PSINTFP                     : out std_logic_vector(15 downto 0);  -- VCC PS INT FP
        VCC_PSAUX                       : out std_logic_vector(15 downto 0);  -- VCC PS AUX 
        AUX_CONV_OUT                    : out std_logic_array16(15 downto 0)  -- AUX[15:0] digital output
        );
    end component;

    component RST_SYNC is
    generic(
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port(
        RST_IN                      : in  std_logic;    -- Active high asynchronous reset
        CLK                         : in  std_logic;    -- clock to be sync'ed to
        RST_OUT                     : out std_logic     -- "Synchronised" reset signal
        );         
    end component;

signal s_rst_xadc                   : std_logic;    

signal i_xadc_temp                  : std_logic_vector(15 downto 0);
signal i_xadc_vccint                : std_logic_vector(15 downto 0);
signal i_xadc_vccpint               : std_logic_vector(15 downto 0);
signal i_xadc_aux_dig_out           : std_logic_array16(15 downto 0);
signal i_xadc_vccpsint_lp           : std_logic_vector(15 downto 0); 
signal i_xadc_vccpsint_fp           : std_logic_vector(15 downto 0);

begin
    
    -- reset synchronizer
    u_rst_xadc : RST_SYNC generic map(4, 200) port map(RST_XADC, CLK, s_rst_xadc);      

--    XADC sensor output
--    XADC_VCCAUX  <= (others => '0');       
--    XADC_VPN     <= (others => '0'); 
--    XADC_VREF_P  <= (others => '0');          
--    XADC_VREF_N  <= (others => '0'); 
--    XADC_VCCBRAM <= (others => '0');         
--    XADC_CAL     <= (others => '0'); 
--    XADC_VCCPAUX <= (others => '0');          
--    XADC_VCCDDRO <= (others => '0'); 


    u_intadc_wrapper : INTADC_WRAPPER_SYSMONE4
    port map(
        RST                         => s_rst_xadc         , -- 100MHz Synchronous Reset
        CLK                         => CLK                , -- 100MHz Register Map Clock
    
        VP_IN                       => XADC_VP_IN         , -- Dedicated Analog Input Pair
        VN_IN                       => XADC_VN_IN         , 
        AUX_P                       => XADC_CHANNEL_P     , -- AUX_P[15:0]
        AUX_N                       => XADC_CHANNEL_N     , -- AUX_N[15:0]
    
        TEMPERATURE_XADC            => i_xadc_temp        , -- Temperature
        VCCINT                      => i_xadc_vccint      , -- VCCINT
        VCCAUX                      => open               , -- VCCAUX
        VPN                         => open               , -- VPN 
        VREF_P                      => open               , -- VREF_P 
        VREF_N                      => open               , -- VREF_N
        VCCBRAM                     => open               , -- VCCBRAM
        XADC_CAL                    => open               , -- XADC_CAL
        VCC_PSINTLP                 => i_xadc_vccpsint_lp , -- VCC PS INT LP
        VCC_PSINTFP                 => i_xadc_vccpsint_fp , -- VCC PS INT FP
        VCC_PSAUX                   => open               , -- VCCPAUX
        AUX_CONV_OUT                => i_xadc_aux_dig_out   -- AUX[15:0] digital output
        );

    P_XADC_Output : process(CLK, s_rst_xadc) 
    begin
        if (s_rst_xadc) = '1' then
            XADC_TEMP               <= (others => '0'); 
            XADC_VCCINT             <= (others => '0');
            XADC_VCCPSINTLP         <= (others => '0');
            XADC_VCCPSINTFP         <= (others => '0');
            XADC_AUX                <= (others => (others => '0')); 
        elsif (CLK'event) and (CLK = '1') then
            XADC_TEMP               <= i_xadc_temp;
            XADC_VCCINT             <= i_xadc_vccint;
            XADC_VCCPSINTLP         <= i_xadc_vccpsint_lp;
            XADC_VCCPSINTFP         <= i_xadc_vccpsint_fp;
            XADC_AUX                <= i_xadc_aux_dig_out;
        end if;
    end process;

end arc_INTADC_TOP_SYSMONE4;
