library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity INTADC_WRAPPER_SYSMONE4 is
port(
    RST                             : in  std_logic;                      -- 100MHz Synchronous Reset
    CLK                             : in  std_logic;                      -- 100MHz Register Map Clock

    VP_IN                           : in  std_logic;                      -- Dedicated Analog Input Pair
    VN_IN                           : in  std_logic;
    AUX_P                           : in  std_logic_vector(15 downto 0);  -- AUX_P[15:0]
    AUX_N                           : in  std_logic_vector(15 downto 0);  -- AUX_N[15:0]

    TEMPERATURE_XADC                : out std_logic_vector(15 downto 0);  -- Temperature
    VCCINT                          : out std_logic_vector(15 downto 0);  -- VCCINT
    VCCAUX                          : out std_logic_vector(15 downto 0);  -- VCCAUX
    VPN                             : out std_logic_vector(15 downto 0);  -- VPN 
    VREF_P                          : out std_logic_vector(15 downto 0);  -- VREF_P 
    VREF_N                          : out std_logic_vector(15 downto 0);  -- VREF_N
    VCCBRAM                         : out std_logic_vector(15 downto 0);  -- VCCBRAM
    XADC_CAL                        : out std_logic_vector(15 downto 0);  -- XADC_CAL 
    VCC_PSINTLP                     : out std_logic_vector(15 downto 0);  -- VCCINT
    VCC_PSINTFP                     : out std_logic_vector(15 downto 0);  -- VCCPAUX
    VCC_PSAUX                       : out std_logic_vector(15 downto 0);  -- VCCDDRO
    AUX_CONV_OUT                    : out std_logic_array16(15 downto 0)  -- AUX[15:0] digital output
    );
end INTADC_WRAPPER_SYSMONE4;

architecture arc_INTADC_WRAPPER_SYSMONE4 of INTADC_WRAPPER_SYSMONE4 is

    component intadc_sysmone4 is
    port(
        DADDR_IN                    : in  std_logic_vector( 7 downto 0);    -- Address bus for the dynamic reconfiguration port
        DEN_IN                      : in  std_logic;                        -- Enable Signal for the dynamic reconfiguration port
        DI_IN                       : in  std_logic_vector(15 downto 0);    -- Input data bus for the dynamic reconfiguration port
        DWE_IN                      : in  std_logic;                        -- Write Enable for the dynamic reconfiguration port
        DO_OUT                      : out std_logic_vector(15 downto 0);    -- Output data bus for dynamic reconfiguration port
        DRDY_OUT                    : out std_logic;                        -- Data ready signal for the dynamic reconfiguration port
        DCLK_IN                     : in  std_logic;                        -- Clock input for the dynamic reconfiguration port
        RESET_IN                    : in  std_logic;                        -- Reset signal for the System Monitor control logic
    
        AUX_CH_P                    : in  std_logic_vector(15 downto 0);
        AUX_CH_N                    : in  std_logic_vector(15 downto 0);
    
        BUSY_OUT                    : out std_logic;                         -- ADC Busy signal
        CHANNEL_OUT                 : out std_logic_vector( 5 downto 0);     -- Channel Selection Outputs
        EOC_OUT                     : out std_logic;                         -- End of Conversion Signal
        EOS_OUT                     : out std_logic;                         -- End of Sequence Signal
        OT_OUT                      : out std_logic;                         -- Over-Temperature alarm output
    
        USER_TEMP_ALARM_OUT         : out std_logic;                         -- Temperature-sensor alarm output
        VCCINT_ALARM_OUT            : out std_logic;                         -- VCCINT-sensor alarm output
        VCCAUX_ALARM_OUT            : out std_logic;                         -- VCCAUX-sensor alarm output
        VCCPSINTFP_ALARAM_OUT       : out std_logic;                         -- VCC PS INT FP-sensor alarm output 
        VCCPSINTLP_ALARAM_OUT       : out std_logic;                         -- VCC PS INT LP-sensor alarm output 
        ALARM_OUT                   : out std_logic;                         -- OR'ed output of all the Alarms
    
        VP_IN                       : in  std_logic;                         -- Dedicated Analog Input Pair
        VN_IN                       : in  std_logic
    );
    end component;

signal daddr                        : std_logic_vector(7 downto 0); 
signal den                          : std_logic;                     
signal di                           : std_logic_vector(15 downto 0);
signal dwe                          : std_logic;                     

signal channel_out                  : std_logic_vector(5 downto 0);  
signal do_out                       : std_logic_vector(15 downto 0); 
signal drdy_out                     : std_logic;    
signal eoc_out                      : std_logic;                      

signal temperature_xadc_r           : std_logic_vector(15 downto 0) := (others => '0');    
signal vccint_r                     : std_logic_vector(15 downto 0) := (others => '0');    
signal vccaux_r                     : std_logic_vector(15 downto 0) := (others => '0');    
signal vpn_r                        : std_logic_vector(15 downto 0) := (others => '0');    
signal vrefp_r                      : std_logic_vector(15 downto 0) := (others => '0');    
signal verfn_r                      : std_logic_vector(15 downto 0) := (others => '0');    
signal vccbram_r                    : std_logic_vector(15 downto 0) := (others => '0');    
signal xadc_cal_r                   : std_logic_vector(15 downto 0) := (others => '0');    
signal vcc_psint_lp                 : std_logic_vector(15 downto 0) := (others => '0');    
signal vcc_psint_fp                 : std_logic_vector(15 downto 0) := (others => '0');    
signal vcc_ps_aux                   : std_logic_vector(15 downto 0) := (others => '0');    
signal aux_r                        : std_logic_array16(15 downto 0) := (others => (others => '0'));
signal v_user_supply_0              : std_logic_vector(15 downto 0) := (others => '0'); 
signal v_user_supply_1              : std_logic_vector(15 downto 0) := (others => '0'); 
signal v_user_supply_2              : std_logic_vector(15 downto 0) := (others => '0'); 
signal v_user_supply_3              : std_logic_vector(15 downto 0) := (others => '0'); 

begin

    u_SYSMONE4 : intadc_sysmone4
    port map(
        DADDR_IN                    => daddr       , --: in  std_logic_vector( 7 downto 0);    -- Address bus for the dynamic reconfiguration port
        DEN_IN                      => den         , --: in  std_logic;                        -- Enable Signal for the dynamic reconfiguration port
        DI_IN                       => di          , --: in  std_logic_vector(15 downto 0);    -- Input data bus for the dynamic reconfiguration port
        DWE_IN                      => dwe         , --: in  std_logic;                        -- Write Enable for the dynamic reconfiguration port
        DO_OUT                      => do_out      , --: out std_logic_vector(15 downto 0);    -- Output data bus for dynamic reconfiguration port
        DRDY_OUT                    => drdy_out    , --: out std_logic;                        -- Data ready signal for the dynamic reconfiguration port
        DCLK_IN                     => CLK         , --: in  std_logic;                        -- Clock input for the dynamic reconfiguration port
        RESET_IN                    => RST         , --: in  std_logic;                        -- Reset signal for the System Monitor control logic
    
        AUX_CH_P                    => AUX_P       , --: in  std_logic_vector(15 downto 0);
        AUX_CH_N                    => AUX_N       , --: in  std_logic_vector(15 downto 0);
    
        BUSY_OUT                    => open        , --: out std_logic;                         -- ADC Busy signal
        CHANNEL_OUT                 => channel_out , --: out std_logic_vector( 5 downto 0);     -- Channel Selection Outputs
        EOC_OUT                     => eoc_out     , --: out std_logic;                         -- End of Conversion Signal
        EOS_OUT                     => open        , --: out std_logic;                         -- End of Sequence Signal
        OT_OUT                      => open        , --: out std_logic;                         -- Over-Temperature alarm output
    
        USER_TEMP_ALARM_OUT         => open        , --: out std_logic;                         -- Temperature-sensor alarm output
        VCCINT_ALARM_OUT            => open        , --: out std_logic;                         -- VCCINT-sensor alarm output
        VCCAUX_ALARM_OUT            => open        , --: out std_logic;                         -- VCCAUX-sensor alarm output
        VCCPSINTFP_ALARAM_OUT       => open        , --: out std_logic;                         -- VCC PS INT FP-sensor alarm output 
        VCCPSINTLP_ALARAM_OUT       => open        , --: out std_logic;                         -- VCC PS INT LP-sensor alarm output 
        ALARM_OUT                   => open        , --: out std_logic;                         -- OR'ed output of all the Alarms
    
        VP_IN                       => VP_IN       , --: in  std_logic;                         -- Dedicated Analog Input Pair
        VN_IN                       => VN_IN         --: in  std_logic
    );
    
    -- XADC Read operatoin, don't use write operation
    daddr <= "00" & channel_out;      
    den   <= eoc_out;        
    di    <= (others => '0'); 
    dwe   <= '0';      

    P_XADC_Demuxing : process(CLK, RST) begin
        if (RST = '1') then
            temperature_xadc_r      <= (others => '0');   
            vccint_r                <= (others => '0');   
            vccaux_r                <= (others => '0');   
            vpn_r                   <= (others => '0');   
            vrefp_r                 <= (others => '0');   
            verfn_r                 <= (others => '0');   
            vccbram_r               <= (others => '0');   
            xadc_cal_r              <= (others => '0');   
            vcc_psint_lp            <= (others => '0');   
            vcc_psint_fp            <= (others => '0');   
            vcc_ps_aux              <= (others => '0');   
            aux_r                   <= (others => (others => '0'));
            v_user_supply_0         <= (others => '0'); 
            v_user_supply_1         <= (others => '0'); 
            v_user_supply_2         <= (others => '0'); 
            v_user_supply_3         <= (others => '0'); 
        elsif (CLK'event) and (CLK = '1') then
            if (drdy_out = '1') then
                case (channel_out) is
                    when "000000"   => temperature_xadc_r <= do_out;   -- Temperature
                    when "000001"   => vccint_r           <= do_out;   -- Avg on-chip VCCINT
                    when "000010"   => vccaux_r           <= do_out;   -- Avg on-chip VCCAUX
                    when "000011"   => vpn_r              <= do_out;   -- VP/VN
                    when "000100"   => vrefp_r            <= do_out;   -- VREFP(1.25V)
                    when "000101"   => verfn_r            <= do_out;   -- VREFN(   0V)
                    when "000110"   => vccbram_r          <= do_out;   -- Avg on-chip VCCBRAM
                 -- when "000111"   =>                    <= do_out;   -- Invalid channel selection
                    when "001000"   => xadc_cal_r         <= do_out;   -- Carry out a SYSMON calibration
                 -- when "001001"   =>                    <= do_out;   -- Invalid channel selection
                 -- when "001010"   =>                    <= do_out;   -- Invalid channel selection
                 -- when "001011"   =>                    <= do_out;   -- Invalid channel selection
                 -- when "001100"   =>                    <= do_out;   -- Invalid channel selection
                    when "001101"   => vcc_psint_lp       <= do_out;   -- VCC_PSINTLP (Zynq Ultra Scale+ MPSoC only)
                    when "001110"   => vcc_psint_fp       <= do_out;   -- VCC_PSINTFP (Zynq Ultra Scale+ MPSoC only)
                    when "001111"   => vcc_ps_aux         <= do_out;   -- VCC_PSAUX (Zynq Ultra Scale+ MPSoC only)
                    when "010000"   => aux_r(0)           <= do_out;   -- AUX[ 0]
                    when "010001"   => aux_r(1)           <= do_out;   -- AUX[ 1]
                    when "010010"   => aux_r(2)           <= do_out;   -- AUX[ 2]
                    when "010011"   => aux_r(3)           <= do_out;   -- AUX[ 3]
                    when "010100"   => aux_r(4)           <= do_out;   -- AUX[ 4]
                    when "010101"   => aux_r(5)           <= do_out;   -- AUX[ 5]
                    when "010110"   => aux_r(6)           <= do_out;   -- AUX[ 6]
                    when "010111"   => aux_r(7)           <= do_out;   -- AUX[ 7]
                    when "011000"   => aux_r(8)           <= do_out;   -- AUX[ 8]
                    when "011001"   => aux_r(9)           <= do_out;   -- AUX[ 9]
                    when "011010"   => aux_r(10)          <= do_out;   -- AUX[10]
                    when "011011"   => aux_r(11)          <= do_out;   -- AUX[11]
                    when "011100"   => aux_r(12)          <= do_out;   -- AUX[12]
                    when "011101"   => aux_r(13)          <= do_out;   -- AUX[13]
                    when "011110"   => aux_r(14)          <= do_out;   -- AUX[14]
                    when "011111"   => aux_r(15)          <= do_out;   -- AUX[15]
                    when "100000"   => v_user_supply_0    <= do_out;   -- User Supply 0 
                    when "100001"   => v_user_supply_1    <= do_out;   -- User Supply 1 
                    when "100010"   => v_user_supply_2    <= do_out;   -- User Supply 2 
                    when "100011"   => v_user_supply_3    <= do_out;   -- User Supply 3 
                    when others     => null;
                end case;
            end if;
        end if;
    end process;

    -- XADC digital output
    TEMPERATURE_XADC  <= temperature_xadc_r;
    VCCINT            <= vccint_r;
    VCCAUX            <= vccaux_r; 
    VPN               <= vpn_r; 
    VREF_P            <= vrefp_r;
    VREF_N            <= verfn_r; 
    VCCBRAM           <= vccbram_r;         
    XADC_CAL          <= xadc_cal_r;            
    VCC_PSINTLP       <= vcc_psint_lp;
    VCC_PSINTFP       <= vcc_psint_fp;             
    VCC_PSAUX         <= vcc_ps_aux;                  
    AUX_CONV_OUT      <= aux_r;

end arc_INTADC_WRAPPER_SYSMONE4;






