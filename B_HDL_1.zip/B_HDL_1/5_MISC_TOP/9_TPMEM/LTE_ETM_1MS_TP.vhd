
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;
use WORK.RU_FPGA_FNC.ALL;

Entity LTE_ETM_1MS_TP  is
   port (
          RST                  : in  std_logic;
          WCLK                 : in  std_logic;    -- CPUIF_MISC Clock domain
          RCLK                 : in  std_logic;    -- 245.76MHz Clock domain
          
          TP_MEM_PEN           : in  std_logic;    -- A/B port enable
          TP_MEM_AWEN          : in  std_logic;    -- A port write enable
          TP_MEM_WRADDR        : in  std_logic_vector(14 downto 0);
          TP_MEM_WRDATA        : in  std_logic_vector(31 downto 0);  -- 31..16 : Q data, 15..0 : I data

          SAMPLE_ENB           : in  std_logic;    -- Sample period tick, activated only 1 cpri core clock per sample
          
          TP_OUT               : out std_logic_vector(31 downto 0)
         );
end LTE_ETM_1MS_TP;

architecture arc_LTE_ETM_1MS_TP of LTE_ETM_1MS_TP is

component opt7_buf
generic(
    BUF_STYLE                   : string  := "BLOCK";--"DISTRIBUTED","BLOCK","ultra","M20K"
    BUFF_DEPTH                  : integer := 8192;
    WIDTH_IN                    : integer := 1
);
port(
    WCLK                        : in  std_logic;
    RCLK                        : in  std_logic;
    WE                          : in  std_logic;
    ENB                         : in  std_logic;
    WADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    RADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_IN                     : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_OUT                    : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

component RST_SYNC
    generic (
        DLY_NUM        : natural := 4;    -- Number of delay.
        MAX_FANOUT_NUM : integer := 200   -- Number of maximum fanout
    );
    port (
        RST_IN  : in  std_logic;          -- Active high asynchronous reset
        CLK     : in  std_logic;          -- clock to be sync'ed to
        RST_OUT : out std_logic           -- "Synchronised" reset signal
    );         
end component;

signal reset                    : std_logic;
signal rd_addr                  : std_logic_vector(14 downto 0);
signal rd_addr_d                : std_logic_vector(14 downto 0);
signal rd_addr_dd               : std_logic_vector(14 downto 0);
signal rd_out_data              : std_logic_vector(31 downto 0);

begin

u_RESET : RST_SYNC
generic map(
    DLY_NUM                     => 4                                       ,--: natural := 4;
    MAX_FANOUT_NUM              => 200                                      --: integer := 200
)
port map(
    RST_IN                      => RST                                     ,--: in  std_logic;
    CLK                         => RCLK                                    ,--: in  std_logic;
    RST_OUT                     => reset                                    --: out std_logic
);

u_tp_mem : opt7_buf
generic map(
    BUF_STYLE                   => "ultra"          , --: string  := "ultra";--"DISTRIBUTED","BLOCK","ultra","M20K"
    BUFF_DEPTH                  => 30720            , --: integer := 30720;
    WIDTH_IN                    => 32                 --: integer := 32
)
port map(
    WCLK                        => WCLK             , --: in  std_logic;
    RCLK                        => RCLK             , --: in  std_logic;
    WE                          => TP_MEM_AWEN      , --: in  std_logic;
    ENB                         => TP_MEM_PEN       , --: in  std_logic;
    WADDR                       => TP_MEM_WRADDR    , --: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    RADDR                       => rd_addr_dd       , --: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_IN                     => TP_MEM_WRDATA    , --: in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_OUT                    => rd_out_data        --: out std_logic_vector(WIDTH_IN-1 downto 0)
);

process(reset,RCLK)
begin
   if reset = '1' then
      rd_addr    <= (others => '0');
      rd_addr_d  <= (others => '0');
      rd_addr_dd <= (others => '0');
   elsif rising_edge(RCLK) then
      if SAMPLE_ENB = '1' then
         if rd_addr = "111011111111111" then
            rd_addr <= (others => '0');
         else
            rd_addr <= rd_addr + '1';
         end if;
      end if;
      
      rd_addr_d  <= rd_addr;
      rd_addr_dd <= rd_addr_d;
   end if;
end process;

process(reset,RCLK)
begin
   if reset = '1' then
      TP_OUT <= (others => '0');
   elsif rising_edge(RCLK) then
      TP_OUT <= rd_out_data;
   end if;
end process;

end arc_LTE_ETM_1MS_TP;