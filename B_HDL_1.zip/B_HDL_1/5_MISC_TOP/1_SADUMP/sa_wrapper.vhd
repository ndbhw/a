library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity SA_WRAPPER is
port(
    RST                             : in  std_logic                    ; -- RST_CPU               : Input Reset from CPU, Active High
    CLK_SA                          : in  std_logic                    ; -- CLK_SA                : Input Clock for Spectrum Analyzer

    FS_IN                           : in  std_logic                    ; -- FS_IN                 : RX_BFN_STROBE, Period 10ms, duration 260 ns

    TXSA_CLKDLYVALUE_IN             : in  std_logic_vector(23 downto 0); -- CLKDLYVALUE_IN        : 1 clock = CLK_SA
    
    DUMP_BUF_SEL_IN                 : in  std_logic                    ; -- DUMPBUFSEL_IN         : Buffer select
    DUMP_START_IN                   : in  std_logic                    ; -- DUMPSTART_IN          : Dumpstart signal
    SA_ENB_IN                       : in  std_logic                    ; -- SA_EN_IN              : SA enable
    DUMPDONE_IN                     : in  std_logic                    ; 

    FB_SW_CNT_INFO_IN               : in  std_logic_vector( 1 downto 0);


    FBSW_CNT_IN                     : in  std_logic_vector( 5 downto 0); -- FBSW_CNT_IN           : 10ms period cnt 307.2MHz cdc
    AUTO_MODE_DONE_IN               : in  std_logic                    ; -- AUTO_MODE_DONE_IN     : Feedback switch automode flag
    SSB_EXIST_IN                    : in  std_logic                    ; -- SSB Exist Indicator, 19.10.07
    
    FBSW_MANUAL_IN                  : in  std_logic                    ; -- FBSW_MANUAL_IN        : '1' : manual operation by user, '0' : normal operation

    CLK_FS_DLY_OUT                  : out std_logic                      -- CLK_FS_DLY_OUT        : RX_BFN_STROBE_FM clock delay signal

    );
end SA_WRAPPER;

architecture arc_SA_WRAPPER of SA_WRAPPER is

--<Component>--
component RST_SYNC is
generic (
    DLY_NUM                     : natural := 4;    -- Number of delay.
    MAX_FANOUT_NUM              : integer := 200   -- Number of maximum fanout
);
port (
    RST_IN                      : in  std_logic;   -- Active high asynchronous reset
    CLK                         : in  std_logic;   -- clock to be sync'ed to
    RST_OUT                     : out std_logic    -- "Synchronised" reset signal
);         
end component;

component START_CLKOFFSET 
port(
    RST                             : in  std_logic;                                              
    CLK                             : in  std_logic;                                              
    BFN_STROBE_IN                   : in  std_logic;                                             
    TXSA_CLKDLYVALUE_IN             : in  std_logic_vector(23 downto 0);                          
    FS_DLY_OUT                      : out std_logic
    );
end component;

component SA_CTRL_ADV 
port(
    RST                             : in  std_logic;
    CLK                             : in  std_logic;

    SA_ST_CONDITION_IN              : in  std_logic; -- SA_ST_CONTDITION_IN  : Spectrum Analyzer Start condition

    FBSW_VALID_IN                   : in  std_logic;
    FS_CNT_IN                       : in  std_logic_vector(5 downto 0);

    SA_VALID_OUT                    : out std_logic
    );
end component;

component FBSW_FSCNT 
port(
    RST                             : in  std_logic;
    CLK                             : in  std_logic;

    FB_SW_CNT_INFO_IN               : in  std_logic_vector(1 downto 0)  ;
    FBSW_MANUAL_IN                  : in  std_logic                     ;

    FB_SW_CNT_IN                    : in  std_logic_vector(5 downto 0)  ;

    FS_IN                           : in  std_logic                     ;

    FBSW_VALID_OUT                  : out std_logic                     ;
    FS_CNT_OUT                      : out std_logic_vector(5 downto 0)
    );
end component;

--component FBSW_LAT 
--port(
--    RST                             : in  std_logic                     ;
--    CLK                             : in  std_logic                     ;
--    FB_SW_CNT_INFO_IN               : in  std_logic_vector(6 downto 0)  ;
--
--    AUTO_MODE_DONE_IN               : in  std_logic                     ; -- AUTO_MODE_DONE_IN : Feed Back Switch Auto mode Done flag 
--    DUMP_START_IN                   : in  std_logic                     ;
--    SA_START_IN                     : in  std_logic                     ;
--    SA_DONE_IN                      : in  std_logic                     ;
--    FS_CNT_IN                       : in  std_logic_vector(6 downto 0)  ; -- SA_DONE_IN        : Spectrum Analyzer Done signal in
--
--    SAST_FBSW_OUT                   : out std_logic_vector(6 downto 0)  ;
--    SAST_FBSWDONE_OUT               : out std_logic_vector(1 downto 0)  ; -- SAST_FBSWDONE_OUT : When start '1', Auto Mode Done info.
--    SAST_FSCNT_OUT                  : out std_logic_vector(6 downto 0)  ; -- SAST_FBSW_OUT     : When start '1', FBSW info.  
--    SADN_FBSW_OUT                   : out std_logic_vector(6 downto 0)  ;
--    SADN_FBSWDONE_OUT               : out std_logic_vector(1 downto 0)  ; -- SAST_FBSWDONE_OUT : When start '1', Auto Mode Done info.
--    SADN_FSCNT_OUT                  : out std_logic_vector(6 downto 0)    -- SAST_FBSW_OUT     : When start '1', FBSW info.  
--
--    );
--end component;

signal rst_sa                       : std_logic;
signal dumpbufsel_sh                : std_logic_vector( 2 downto 0);
signal fbsw_manual_sh               : std_logic_vector( 2 downto 0);
signal dumpstart_sh                 : std_logic_vector( 2 downto 0);
signal sa_en_sh                     : std_logic_vector( 2 downto 0);
signal fs_sh                        : std_logic_vector( 2 downto 0);
signal auto_mode_done_sh            : std_logic_vector( 2 downto 0);

signal fs_sh_f1                     : std_logic;
signal fs_sh_rpls                   : std_logic;
signal fs_sh_lat                    : std_logic;

signal bfnstrb_clkdly_d             : std_logic_vector(23 downto 0);
signal clkdlycomp                   : std_logic;
signal clkdlyvalue                  : std_logic_vector(23 downto 0);

signal fb_valid                     : std_logic;
signal fb_valid_f1                  : std_logic;
signal fb_valid_rpls                : std_logic;
signal fb_valid_fpls                : std_logic;

signal sa_st_condition              : std_logic;

signal fb_sw_cnt_info_d             : std_logic_vector( 1 downto 0);
signal sa_start                     : std_logic;

signal clk_fs_dly                   : std_logic;

signal fb_sw_cnt_d                  : std_logic_vector( 5 downto 0);
signal fs_cnt_value                 : std_logic_vector( 5 downto 0);

signal ssb_exist_sh                 : std_logic_vector( 1 downto 0); -- 19.09.02

begin

    U_RST_SYNC : RST_SYNC generic map(4 , 200 ) port map(RST, CLK_SA, rst_sa);

    P_DC : process(rst_sa, CLK_SA) begin
        if (rst_sa = '1') then
            dumpbufsel_sh           <= (others => '0'); 
            fbsw_manual_sh          <= (others => '0'); 
            dumpstart_sh            <= (others => '0'); 
            sa_en_sh                <= (others => '0'); 
            fs_sh                   <= (others => '0'); 
            auto_mode_done_sh       <= (others => '0'); 
            ssb_exist_sh            <= (others => '0');
        elsif (CLK_SA'event) and (CLK_SA = '1') then
            dumpbufsel_sh           <= dumpbufsel_sh(1 downto 0) & DUMP_BUF_SEL_IN; 
            fbsw_manual_sh          <= fbsw_manual_sh(1 downto 0) & FBSW_MANUAL_IN; 
            dumpstart_sh            <= dumpstart_sh(1 downto 0) & DUMP_START_IN; 
            sa_en_sh                <= sa_en_sh(1 downto 0) & SA_ENB_IN; 
            fs_sh                   <= fs_sh(1 downto 0) & FS_IN; 
            auto_mode_done_sh       <= auto_mode_done_sh(1 downto 0) & AUTO_MODE_DONE_IN; 
            --ssb_exist_sh            <= ssb_exist_sh(1 downto 0) & SSB_EXIST_IN; -- 19.09.02
            ssb_exist_sh            <= ssb_exist_sh(0) & SSB_EXIST_IN; -- 19.09.02
        end if;
    end process;

    -- DUMPSTART, SA Enable CDC : 100MHz -> 307.2MHz
    P_CLKDLY_CDC : process(rst_sa, CLK_SA) begin
        if (rst_sa = '1') then
            bfnstrb_clkdly_d        <= (others => '0');
        elsif (CLK_SA'event) and (CLK_SA = '1') then
            if (dumpstart_sh(2) = '0') and (dumpstart_sh(1) = '1') then		
                bfnstrb_clkdly_d    <= TXSA_CLKDLYVALUE_IN;
            else
                bfnstrb_clkdly_d    <= bfnstrb_clkdly_d;
            end if;
        end if;
    end process;

    DUMP_CLK_DLY_COMP : process(rst_sa, CLK_SA)
    begin
        if (rst_sa = '1') then
            clkdlycomp              <= '0';
        elsif (CLK_SA'event) and (CLK_SA = '1') then
            if (dumpbufsel_sh(2) = '1') then
                if (bfnstrb_clkdly_d > x"2EC000") then
                    clkdlycomp      <= '1';
                else
                    clkdlycomp      <= '0';
                end if;
            else
                clkdlycomp          <= '0';
            end if;
        end if;
    end process;

    DUMP_CLK_DLY_Point : process(rst_sa, CLK_SA)
    begin
        if (rst_sa = '1') then
            clkdlyvalue             <= (others => '0');
        elsif (CLK_SA'event) and (CLK_SA = '1') then
            if (dumpbufsel_sh(2) = '1') then
                if (clkdlycomp = '1') then
                    clkdlyvalue     <= x"2EC000";
                else
                    clkdlyvalue     <= bfnstrb_clkdly_d;
                end if;
            else
                clkdlyvalue         <= (others => '0');
            end if;
        end if;
    end process;

    FS_RISING_EDGE_DETECT : process(rst_sa, CLK_SA)
    begin
        if (rst_sa = '1') then
            fs_sh_f1                <= '0';
            fs_sh_rpls              <= '0';
        elsif (CLK_SA'event) and (CLK_SA = '1') then
            fs_sh_f1                <= fs_sh(2);
            fs_sh_rpls              <= fs_sh(2) and (not fs_sh_f1);
        end if;
    end process;	

    -- AUTO_MODE_DONE_SIGNAL_Processing

    Feedback_Valid_SIG_PROC : process(rst_sa, CLK_SA)
    begin
        if (rst_sa = '1') then
            fb_valid_f1             <= '0'; -- : std_logic;
            fb_valid_rpls           <= '0'; -- : std_logic;
            fb_valid_fpls           <= '0'; -- : std_logic;
        elsif (CLK_SA'event) and (CLK_SA = '1') then
            fb_valid_f1             <= fb_valid; -- : std_logic;
            fb_valid_rpls           <= fb_valid and (not fb_valid_f1); -- : std_logic; 
            fb_valid_fpls           <= (not fb_valid) and fb_valid_f1; -- : std_logic;
        end if;
    end process;
        
    -- Spectrum Analyzer Start Condition generate
    Latch_and_Clear : process(rst_sa, CLK_SA)
    begin
        if (rst_sa = '1') then
            sa_st_condition         <= '0';
        elsif (CLK_SA'event) and (CLK_SA = '1') then
            if (fb_valid_fpls = '1') then                    
                sa_st_condition     <= '0';                         -- clear
            elsif (fb_valid_rpls = '1') then                 
                sa_st_condition     <= dumpstart_sh(2) and sa_en_sh(2) and (not auto_mode_done_sh(2)); -- set
            else
                sa_st_condition     <= sa_st_condition;             -- latch
            end if;
        end if;
    end process;
            
    -- Feedback Switch
    process(rst_sa, CLK_SA) begin
        if (rst_sa = '1') then
            fb_sw_cnt_d             <= (others => '0');
        elsif (CLK_SA'event) and (CLK_SA = '1') then
            fb_sw_cnt_d             <= FBSW_CNT_IN;
        end if;
    end process;

    process(rst_sa, CLK_SA) begin
        if (rst_sa = '1') then
            fb_sw_cnt_info_d        <= (others => '0');
        elsif (CLK_SA'event) and (CLK_SA = '1') then
            if sa_en_sh(2 downto 1) = "01" then
                fb_sw_cnt_info_d    <= FB_SW_CNT_INFO_IN;
            else
                fb_sw_cnt_info_d    <= fb_sw_cnt_info_d;
            end if;
        end if;
    end process;

    
    U_FBSW_FS_COUNT :  FBSW_FSCNT 
    port map(
        RST                         => rst_sa               , -- : in std_logic;
        CLK                         => CLK_SA               , -- : in std_logic;
    
        FB_SW_CNT_INFO_IN           => fb_sw_cnt_info_d     , -- : in std_logic_vector(1 downto 0)  ;
        FBSW_MANUAL_IN              => fbsw_manual_sh(2)    , -- : in std_logic                     ;
        FB_SW_CNT_IN                => fb_sw_cnt_d          , -- : in std_logic_vector(5 downto 0)  ;
        FS_IN                       => fs_sh(2)             , -- : in std_logic                     ;
    
        FBSW_VALID_OUT              => fb_valid             , -- : out std_logic                    ;
        FS_CNT_OUT                  => fs_cnt_value           -- : out std_logic_vector(5 downto 0)
        );

    -- SA condition check and control
    U_SA_START_CTRL : SA_CTRL_ADV 
    port map(
        RST                         => rst_sa               , -- : in std_logic;
        CLK                         => CLK_SA               , -- : in std_logic;
    
        SA_ST_CONDITION_IN          => sa_st_condition      , -- : in std_logic;
    
        FBSW_VALID_IN               => fb_valid             , -- : in std_logic;
        FS_CNT_IN                   => fs_cnt_value         , -- : in std_logic_vector(5 downto 0);
    
        SA_VALID_OUT                => sa_start               -- : out std_logic
        );

    -- FS delay signal generate
    FS_LATCH : process(rst_sa, CLK_SA)
    begin
        if (rst_sa = '1') then
            fs_sh_lat               <= '0';
        elsif (CLK_SA'event) and (CLK_SA = '1') then
            if (sa_start = '1') then
                if (fs_sh_rpls = '1') then
                    fs_sh_lat       <= '1';
                else
                    fs_sh_lat       <= fs_sh_lat;
                end if;
            else
                fs_sh_lat           <= '0';
            end if;
        end if;
    end process;

    U_SA_START_CLK_OFFSET : START_CLKOFFSET 
    port map(
        RST                         => rst_sa               , -- : in std_logic;                                              
        CLK                         => CLK_SA               , -- : in std_logic;                                              
        BFN_STROBE_IN               => fs_sh_lat            , -- : in std_logic;                                              
        TXSA_CLKDLYVALUE_IN         => clkdlyvalue          , -- : in std_logic_vector(23 downto 0);                          
        FS_DLY_OUT                  => clk_fs_dly             -- : out std_logic
        );

    process(rst_sa, CLK_SA)
    begin
        if (rst_sa = '1') then
            CLK_FS_DLY_OUT          <= '0';
        elsif (CLK_SA'event) and (CLK_SA = '1') then
            CLK_FS_DLY_OUT          <= clk_fs_dly and sa_start;
--            CLK_FS_DLY_OUT          <= clk_fs_dly and sa_start and ssb_exist_sh(1);
        end if;
    end process;

end arc_SA_WRAPPER;
