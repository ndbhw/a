library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity DUMPBLK_TOP is
generic(
    DUMP_BUF_NUM                    : natural := 1    ;
    CPRI_NUM                        : natural := 3    ;
    SA_USAGE                        : boolean := TRUE ;
    NPI_PTN_USAGE                   : boolean := FALSE;
    FIXED_PTN_USAGE                 : boolean := TRUE ;
    DUAL_DUMP_USAGE                 : boolean := FALSE;
    POLY_PHASE_USAGE                : boolean := TRUE 
    );
port(
    RST_MISC                        : in  std_logic                             ;
    CLK_CPU                         : in  std_logic                             ;
    
    CLK_DUMP0                       : in  std_logic                             ;
    CLK_DUMP1                       : in  std_logic                             ;

    ADDR_CPU_IN                     : in  std_logic_vector(15 downto 0)         ;
    WDATA_CPU_IN                    : in  std_logic_vector(31 downto 0)         ;
    WREN_CPU_IN                     : in  std_logic                             ;
    RDEN_CPU_IN                     : in  std_logic                             ;
    RDVAL_CPU_OUT                   : out std_logic                             ;
    RDATA_CPU_OUT                   : out std_logic_vector(31 downto 0)         ;

    --CPRIPHY_TOP(CFPGA)
    DUMP_BFN_STRB_CPRIPHY_IN        : in  std_logic_vector( 1 downto 0)         ;
    DUMP_DATA_CPRIPHY_IN            : in  std_logic_array32(1 downto 0)         ;
    DUMP_DVLD_CPRIPHY_IN            : in  std_logic_vector( 1 downto 0)         ;

    TEST_ENB_CPRIPHY_IN             : in  std_logic_vector( 1 downto 0)         ;
    TEST_DATA_CPRIPHY_OUT           : out std_logic_array32(1 downto 0)         ;

    --CPRI_TOP(CFPGA,DFPGA)
    DUMP_BFN_STRB_CPRI_IN           : in  std_logic_vector( 1 downto 0)         ;
    DUMP_DATA_CPRI_IN               : in  std_logic_array32(1 downto 0)         ;
    DUMP_DVLD_CPRI_IN               : in  std_logic_vector( 1 downto 0)         ;

    TEST_ENB_CPRI_IN                : in  std_logic_vector( 1 downto 0)         ;
    TEST_DATA_CPRI_OUT              : out std_logic_array32(1 downto 0)         ;

    --SBIF_TOP(CFPGA,DFPGA)
    DUMP_BFN_STRB_SBIF_IN           : in  std_logic_vector( 1 downto 0)         ;
    DUMP_DATA_SBIF_IN               : in  std_logic_array32(1 downto 0)         ;
    DUMP_DVLD_SBIF_IN               : in  std_logic_vector( 1 downto 0)         ;

    TEST_ENB_SBIF_IN                : in  std_logic_vector( 1 downto 0)         ;
    TEST_DATA_SBIF_OUT              : out std_logic_array32(1 downto 0)         ;

    --SBIFPHY_TOP(CFPGA,DFPGA)
    DUMP_BFN_STRB_SBIFPHY_IN        : in  std_logic_vector( 1 downto 0)         ;
    DUMP_DATA_SBIFPHY_IN            : in  std_logic_array32(1 downto 0)         ;
    DUMP_DVLD_SBIFPHY_IN            : in  std_logic_vector( 1 downto 0)         ;

    TEST_ENB_SBIFPHY_IN             : in  std_logic_vector( 1 downto 0)         ;
    TEST_DATA_SBIFPHY_OUT           : out std_logic_array32(1 downto 0)         ;

    --BBCTRL_TOP(DFPGA)
    DUMP_BFN_STRB_BBCTRL_IN         : in  std_logic_vector( 1 downto 0)         ;
    DUMP_DATA_BBCTRL_IN             : in  std_logic_array32(1 downto 0)         ;
    DUMP_DVLD_BBCTRL_IN             : in  std_logic_vector( 1 downto 0)         ;

    TEST_ENB_BBCTRL_IN              : in  std_logic_vector( 1 downto 0)         ;
    TEST_DATA_BBCTRL_OUT            : out std_logic_array32(1 downto 0)         ;

    --DSP_TOP(DFPGA)
    DUMP_BFN_STRB_DSP_IN            : in  std_logic_vector( 1 downto 0)         ;
    DUMP_DATA_DSP_IN                : in  std_logic_array32(1 downto 0)         ;
    DUMP_DVLD_DSP_IN                : in  std_logic_vector( 1 downto 0)         ;

    TEST_ENB_DSP_IN                 : in  std_logic_vector( 1 downto 0)         ;
    TEST_DATA_DSP_OUT               : out std_logic_array32(1 downto 0)         ;

    --DCIF_TOP(DFPGA)
    DUMP_BFN_STRB_DCIF_IN           : in  std_logic_vector( 1 downto 0)         ;
    DUMP_DATA_DCIF_IN               : in  std_logic_array32(1 downto 0)         ;
    DUMP_DVLD_DCIF_IN               : in  std_logic_vector( 1 downto 0)         ;

    TEST_ENB_DCIF_IN                : in  std_logic_vector( 1 downto 0)         ;
    TEST_DATA_DCIF_OUT              : out std_logic_array32(1 downto 0)         ;

    --External Device
    EXT_TRIGGER_IN                  : in  std_logic                             ;

    --SYSCTRL_TOP
    RX_BFNSTRB_SYSCTRL_IN           : in  std_logic_vector(CPRI_NUM-1 downto 0) ;
    TX_BFNSTRB_SYSCTRL_IN           : in  std_logic_vector(CPRI_NUM-1 downto 0) ;

    --CPRI_TOP
    RX_BFNSTRB_CPRI_IN              : in  std_logic_vector(CPRI_NUM-1 downto 0) ;

    --DMA interface
    DMA_RDCLK_OUT                   : out std_logic                             ;
    DMA_RDRDY_IN                    : in  std_logic                             ;
    DMA_RDEN_OUT                    : out std_logic                             ;
    DMA_RDATA_IN                    : in  std_logic_vector(31 downto 0)         ;
    DMA_RDEPT_IN                    : in  std_logic                             ;
    
    DMA_WRCLK_OUT                   : out std_logic                             ;
    DMA_WRRDY_IN                    : in  std_logic                             ;
    DMA_WREN_OUT                    : out std_logic                             ;
    DMA_WDATA_OUT                   : out std_logic_vector(31 downto 0)         ;
    DMA_WRFULL_IN                   : in  std_logic                             ;

    -- DUMP
    RX_SYSCTRL_STRB_SEL_IN          : in  std_logic_vector( 7 downto 0)         ;
    TX_SYSCTRL_STRB_SEL_IN          : in  std_logic_vector( 7 downto 0)         ;
    RX_CPRI_STRB_SEL_IN             : in  std_logic_vector( 7 downto 0)         ;
    MODULE_STRB_SEL_IN              : in  std_logic_vector( 7 downto 0)         ;

    DUMP_BUF_SEL_IN                 : in  std_logic_vector( 1 downto 0)         ;
    DUMP_DATASEL_IN                 : in  std_logic_vector( 7 downto 0)         ;

    DUMP_STARTDLY_IN                : in  std_logic_vector(11 downto 0)         ;
    DUMP_START_IN                   : in  std_logic                             ;
    DUMP_DONE_OUT                   : out std_logic                             ;

    -- Dual DUMP
    RX_SYSCTRL_STRB_SEL_2ND_IN      : in  std_logic_vector( 7 downto 0)         ;
    TX_SYSCTRL_STRB_SEL_2ND_IN      : in  std_logic_vector( 7 downto 0)         ;
    RX_CPRI_STRB_SEL_2ND_IN         : in  std_logic_vector( 7 downto 0)         ;
    MODULE_STRB_SEL_2ND_IN          : in  std_logic_vector( 7 downto 0)         ;

    DUMP_BUF_SEL_2ND_IN             : in  std_logic_vector( 1 downto 0)         ;
    DUMP_DATASEL_2ND_IN             : in  std_logic_vector( 7 downto 0)         ;

    DUMP_STARTDLY_2ND_IN            : in  std_logic_vector(11 downto 0)         ;
    DUMP_DONE_2ND_OUT               : out std_logic                             ;

    RDATA_MEMORY_SEL_IN             : in  std_logic                             ;

    -- Poly Phase Dump
    PHASE_SEL_IN                    : in  std_logic                             ;

    -- Spectrum Analyzer
    FBSW_CNT_IN                     : in  std_logic_vector( 5 downto 0)         ;
    AUTO_MODE_DONE_IN               : in  std_logic                             ;
    SSB_EXIST_IN                    : in  std_logic                             ; -- SSB Exist Indicator, 19.10.07

    FBSW_MANUAL_IN                  : in  std_logic                             ; -- from FBSW_CTRL : '1' : manual operation by user, '0' : normal operation
    FB_SW_CNT_INFO_IN               : in  std_logic_vector( 1 downto 0)         ;
    FB_SW_CNT_INFO_2ND_IN           : in  std_logic_vector( 1 downto 0)         ;

    TXSA_ENB_IN                     : in  std_logic                             ;
    TXSA_ENB_2ND_IN                 : in  std_logic                             ;
    TXSA_CLKDLYVALUE_IN             : in  std_logic_vector(23 downto 0)         ;
    TXSA_CLKDLYVALUE_2ND_IN         : in  std_logic_vector(23 downto 0)         ;

    -- fixed ptn generator
    FIXED_PTN_GEN_EN_IN             : in  std_logic                             ;
    FIXED_PTN_START_IN              : in  std_logic                             ;
    FIXED_PTN_BLK_SEL_IN            : in  std_logic_vector( 7 downto 0)         ;
    FIXED_PTN_LENGTH_IN             : in  std_logic_vector(12 downto 0)         ;

    -- NPI interface
    DMA_RDEN_IN                     : in  std_logic                             ;
    DMA_WREN_IN                     : in  std_logic                             ;
    DMA_READ_BLK_SEL_IN             : in  std_logic_vector( 7 downto 0)         ;
    DMA_WRITE_BLK_SEL_IN            : in  std_logic_vector( 7 downto 0)         ;
    DMA_BFN_STRB_SEL_IN             : in  std_logic_vector( 7 downto 0)         ;
    DMA_DLY_VALUE_IN                : in  std_logic_vector(23 downto 0)         ;

    TEST_PTN_SEL_IN                 : in  std_logic_vector( 1 downto 0)         ;
    TEST_PTN_VALID_OUT              : out std_logic_vector( 1 downto 0)         ;

    -- Module information
    SADUMP_MODULE_INFO_OUT          : out std_logic_vector(31 downto 0)         ;
    SADUMP_STRUCT_INFO_OUT          : out std_logic_vector(31 downto 0)         ;
    SADUMP_MODULE_DATE_OUT          : out std_logic_vector(31 downto 0)
    
    );
end DUMPBLK_TOP;

architecture behave of DUMPBLK_TOP is

    component RST_SYNC is
    generic (
        DLY_NUM                     : natural := 4;    -- Number of delay.
        MAX_FANOUT_NUM              : integer := 200   -- Number of maximum fanout
    );
    port (
        RST_IN                      : in  std_logic;   -- Active high asynchronous reset
        CLK                         : in  std_logic;   -- clock to be sync'ed to
        RST_OUT                     : out std_logic    -- "Synchronised" reset signal
    );         
    end component;

    component DATAPATH_SEL is
    generic(
        DUMP_BUF_NUM                : natural := 2                              ;
        CPRI_NUM                    : natural := 7                              ;
        POLY_PHASE_USAGE            : boolean := FALSE
        );
    port(
        RST                         : in std_logic                              ;
        CLK_DUMP0                   : in std_logic                              ;
        CLK_DUMP1                   : in std_logic                              ;

        --External Device
        EXT_TRIGGER_IN              : in  std_logic                             ;
    
        --SYSCTRL_TOP
        RX_BFNSTRB_SYSCTRL_IN       : in  std_logic_vector(CPRI_NUM-1 downto 0) ;
        TX_BFNSTRB_SYSCTRL_IN       : in  std_logic_vector(CPRI_NUM-1 downto 0) ;
    
        --CPRI_TOP
        RX_BFNSTRB_CPRI_IN          : in  std_logic_vector(CPRI_NUM-1 downto 0) ;

        --CPRIPHY_TOP(CFPGA)
        DUMP_BFN_STRB_CPRIPHY_IN    : in  std_logic_vector(1 downto 0)          ;
        DUMP_DATA_CPRIPHY_IN        : in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_CPRIPHY_IN        : in  std_logic_vector(1 downto 0)          ;

        --CPRI_TOP(CFPGA,DFPGA)
        DUMP_BFN_STRB_CPRI_IN       : in  std_logic_vector(1 downto 0)          ;
        DUMP_DATA_CPRI_IN           : in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_CPRI_IN           : in  std_logic_vector(1 downto 0)          ;

        --SBIF_TOP(CFPGA,DFPGA)
        DUMP_BFN_STRB_SBIF_IN       : in  std_logic_vector(1 downto 0)          ;
        DUMP_DATA_SBIF_IN           : in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_SBIF_IN           : in  std_logic_vector(1 downto 0)          ;

        --SBIFPHY_TOP(CFPGA,DFPGA)
        DUMP_BFN_STRB_SBIFPHY_IN    : in  std_logic_vector(1 downto 0)          ;
        DUMP_DATA_SBIFPHY_IN        : in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_SBIFPHY_IN        : in  std_logic_vector(1 downto 0)          ;

        --BBCTRL_TOP(DFPGA)
        DUMP_BFN_STRB_BBCTRL_IN     : in  std_logic_vector(1 downto 0)          ;
        DUMP_DATA_BBCTRL_IN         : in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_BBCTRL_IN         : in  std_logic_vector(1 downto 0)          ;

        --DSP_TOP(DFPGA)
        DUMP_BFN_STRB_DSP_IN        : in  std_logic_vector(1 downto 0)          ;
        DUMP_DATA_DSP_IN            : in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_DSP_IN            : in  std_logic_vector(1 downto 0)          ;

        --DCIF_TOP(DFPGA)
        DUMP_BFN_STRB_DCIF_IN       : in  std_logic_vector(1 downto 0)          ;
        DUMP_DATA_DCIF_IN           : in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_DCIF_IN           : in  std_logic_vector(1 downto 0)          ;

        DUMP_START_IN               : in  std_logic                             ;
        DUMP_DATASEL_IN             : in  std_logic_vector(7 downto 0)          ;

        RX_SYSCTRL_STRB_SEL_IN      : in  std_logic_vector( 7 downto 0)         ;
        TX_SYSCTRL_STRB_SEL_IN      : in  std_logic_vector( 7 downto 0)         ;
        RX_CPRI_STRB_SEL_IN         : in  std_logic_vector( 7 downto 0)         ;
        MODULE_STRB_SEL_IN          : in  std_logic_vector( 7 downto 0)         ;
   
        WRSTRB_OUT                  : out std_logic_array1( DUMP_BUF_NUM-1 downto 0);
        WRDATA_OUT                  : out std_logic_array32(             1 downto 0);
        WRVAL_OUT                   : out std_logic_array1( DUMP_BUF_NUM-1 downto 0)
        );
    end component;

    component TESTPTNPATH_SEL is
        generic(
        DUMP_BUF_NUM                : natural := 2
        );
        port(
        RST                         : in std_logic                              ;
        CLK_DUMP0                   : in std_logic                              ;
        CLK_DUMP1                   : in std_logic                              ;

        TEST_ENB_CPRIPHY_IN         : in std_logic_vector(1 downto 0)           ;
        TEST_ENB_CPRI_IN            : in std_logic_vector(1 downto 0)           ;
        TEST_ENB_SBIF_IN            : in std_logic_vector(1 downto 0)           ;
        TEST_ENB_SBIFPHY_IN         : in std_logic_vector(1 downto 0)           ;
        TEST_ENB_BBCTRL_IN          : in std_logic_vector(1 downto 0)           ;
        TEST_ENB_DSP_IN             : in std_logic_vector(1 downto 0)           ;
        TEST_ENB_DCIF_IN            : in std_logic_vector(1 downto 0)           ;

        FIXED_PTN_START_IN          : in std_logic                              ;
        FIXED_PTN_BLK_SEL_IN        : in std_logic_vector(7 downto 0)           ;

        TEST_ENB_OUT                : out std_logic_array1(DUMP_BUF_NUM-1 downto 0)
       );
    end component;

    component DMA_WRAPPER is
    generic(
        DUMP_BUF_NUM                : natural := 2                              ;
        CPRI_NUM                    : natural := 7
    );
    port(
        RST                         : in  std_logic                             ;
        CLK_DUMP0                   : in  std_logic                             ;
        CLK_DUMP1                   : in  std_logic                             ;
    
        DMA_RDEN_IN                 : in  std_logic                             ;
        DMA_WREN_IN                 : in  std_logic                             ;
        DMA_READ_BLK_SEL_IN         : in  std_logic_vector( 7 downto 0)         ;
        DMA_WRITE_BLK_SEL_IN        : in  std_logic_vector( 7 downto 0)         ;
        DMA_BFN_STRB_SEL_IN         : in  std_logic_vector( 7 downto 0)         ;
        DMA_DLY_VALUE_IN            : in  std_logic_vector(23 downto 0)         ;
    
        -- DMA Interface
        DMA_RDCLK_OUT               : out std_logic                             ;
        DMA_RDRDY_IN                : in  std_logic                             ;
        DMA_RDEN_OUT                : out std_logic                             ;
        DMA_RDATA_IN                : in  std_logic_vector(31 downto 0)         ;
        DMA_RDEPT_IN                : in  std_logic                             ;
    
        DMA_WRCLK_OUT               : out std_logic                             ;
        DMA_WRRDY_IN                : in  std_logic                             ;
        DMA_WREN_OUT                : out std_logic                             ;
        DMA_WDATA_OUT               : out std_logic_vector(31 downto 0)         ;
        DMA_WRFULL_IN               : in  std_logic                             ;
    
        DMA_READ_PTN                : out std_logic_array32(DUMP_BUF_NUM-1 downto 0);

        RX_BFNSTRB_SYSCTRL_IN       : in  std_logic_vector(CPRI_NUM-1 downto 0) ;
        TX_BFNSTRB_SYSCTRL_IN       : in  std_logic_vector(CPRI_NUM-1 downto 0) ;
        RX_BFNSTRB_CPRI_IN          : in  std_logic_vector(CPRI_NUM-1 downto 0) ;

         --CPRIPHY_TOP(CFPGA)
        DUMP_DATA_CPRIPHY_IN        : in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_CPRIPHY_IN        : in  std_logic_vector(1 downto 0)          ;
    
        TEST_ENB_CPRIPHY_IN         : in  std_logic_vector(1 downto 0)          ;
    
        --CPRI_TOP(CFPGA,DFPGA)
        DUMP_DATA_CPRI_IN           : in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_CPRI_IN           : in  std_logic_vector(1 downto 0)          ;
    
        TEST_ENB_CPRI_IN            : in  std_logic_vector(1 downto 0)          ;
    
        --SBIF_TOP(CFPGA,DFPGA)
        DUMP_DATA_SBIF_IN           : in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_SBIF_IN           : in  std_logic_vector(1 downto 0)          ;
    
        TEST_ENB_SBIF_IN            : in  std_logic_vector(1 downto 0)          ;
    
        --SBIFPHY_TOP(CFPGA,DFPGA)
        DUMP_DATA_SBIFPHY_IN        : in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_SBIFPHY_IN        : in  std_logic_vector(1 downto 0)          ;
    
        TEST_ENB_SBIFPHY_IN         : in  std_logic_vector(1 downto 0)          ;

        --BBCTRL_TOP(DFPGA)
        DUMP_DATA_BBCTRL_IN         : in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_BBCTRL_IN         : in  std_logic_vector(1 downto 0)          ;

        TEST_ENB_BBCTRL_IN          : in  std_logic_vector(1 downto 0)          ;

        --DSP_TOP(DFPGA)
        DUMP_DATA_DSP_IN            : in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_DSP_IN            : in  std_logic_vector(1 downto 0)          ;

        TEST_ENB_DSP_IN             : in  std_logic_vector(1 downto 0)          ;

        --DCIF_TOP(DFPGA)
        DUMP_DATA_DCIF_IN           : in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_DCIF_IN           : in  std_logic_vector(1 downto 0)          ;
 
        TEST_ENB_DCIF_IN            : in  std_logic_vector(1 downto 0)         
        );
    end component;

    component STARTOFFSET_WRAPPER is
        port(
        RST                         : in  std_logic                             ;
        CLK                         : in  std_logic                             ;
    
        FS_IN                       : in  std_logic                             ;
        DUMP_STARTDLY_IN            : in  std_logic_vector(11 downto 0)         ;
        DUMP_START_IN               : in  std_logic                             ;
        DUMP_BUF_SEL_IN             : in  std_logic                             ;
    
        SAMPLE_FSDLY_OUT            : out std_logic
        );
    end component;
    
    component BUFFER_WRAPPER is
        generic(
        FIXED_PTN_USAGE             : boolean                                   ;
        POLY_PHASE_USAGE            : boolean 
        );
        port(
        RST                         : in  std_logic                             ;                    
        CLK_CPU                     : in  std_logic                             ;
        CLK_DUMP                    : in  std_logic                             ;                    
    
        DUMP_BUF_SEL_IN             : in  std_logic                             ;                    
        DUMP_START_IN               : in  std_logic                             ;                    
    
        FS_DLY_IN                   : in  std_logic                             ;                    
        DUMPDONE_OUT                : out std_logic                             ;

        FIXED_PTN_VALID_IN          : in  std_logic                             ;
        FIXED_PTN_GEN_EN_IN         : in  std_logic                             ;
        FIXED_PTN_START_IN          : in  std_logic                             ;
        FIXED_PTN_LENGTH_IN         : in  std_logic_vector(12 downto 0)         ;
        PHASE_SEL_IN                : in  std_logic                             ;
    
        TEST_PTN_VALID_OUT          : out std_logic                             ;
        GEN_RDATA_OUT               : out std_logic_vector(31 downto 0)         ;

        DUMP_WRVAL_IN               : in  std_logic                             ;
        DUMP_WRDATA_IN              : in  std_logic_vector(31 downto 0)         ;
        DUMP_ODD_WRDATA_IN          : in  std_logic_vector(31 downto 0)         ;

        RDATA_MEMORY_SEL_IN         : in  std_logic                             ;
        WREN_CPU_IN                 : in  std_logic                             ;
        RDEN_CPU_IN                 : in  std_logic                             ;                    
        WDATA_CPU_IN                : in  std_logic_vector(31 downto 0)         ;
        ADDRL13B_IN                 : in  std_logic_vector(12 downto 0)         ;
        RDATA_CPU_OUT               : out std_logic_vector(31 downto 0)
        );
    end component;
    
    component SA_WRAPPER is
        port(
        RST                         : in  std_logic                             ;
        CLK_SA                      : in  std_logic                             ;
    
        FS_IN                       : in  std_logic                             ;
    
        TXSA_CLKDLYVALUE_IN         : in  std_logic_vector(23 downto 0)         ; 
        
        DUMP_BUF_SEL_IN             : in  std_logic                             ; 
        DUMP_START_IN               : in  std_logic                             ; 
        SA_ENB_IN                   : in  std_logic                             ; 
        DUMPDONE_IN                 : in  std_logic                             ; 
    
        FB_SW_CNT_INFO_IN           : in  std_logic_vector(1 downto 0)          ;
                                                                                 
        FBSW_CNT_IN                 : in  std_logic_vector(5 downto 0)          ; 
        AUTO_MODE_DONE_IN           : in  std_logic                             ; 
        SSB_EXIST_IN                : in  std_logic                             ; -- SSB Exist Indicator, 19.10.07
        
        FBSW_MANUAL_IN              : in  std_logic                             ;
    
        CLK_FS_DLY_OUT              : out std_logic
        );
    end component;

    constant ZEROS                  : std_logic_vector(31 downto 0) := (others => '0');

    constant SADUMP_TOP_ID          : std_logic_vector( 7 downto 0) := x"61";       -- SADUMP_TOP ID : 0x61
    constant SADUMP_CODE_ID         : std_logic_vector( 7 downto 0) := x"00";       -- SEC : 0x00, SRC : 0x01
    constant SADUMP_VERSION_ID      : std_logic_vector( 7 downto 0) := x"02";       -- Revision Version
    constant SADUMP_MODULE_INFO     : std_logic_vector(31 downto 0) := SADUMP_TOP_ID & SADUMP_CODE_ID & ZEROS(15 downto 8) & SADUMP_VERSION_ID;
    
    constant SADUMP_BUF_NUM         : std_logic_vector( 3 downto 0) := x"1";       -- number of buffer
    constant SADUMP_SA_USAGE        : std_logic_vector( 3 downto 0) := x"1";       -- Spectrum Analyzer - 0x0 : not used   , 0x1 : used
    constant SADUMP_FIXED_PTN_USAGE : std_logic_vector( 3 downto 0) := x"0";       -- Pattern Generator - 0x0 : not used   , 0x1 : used
    constant SADUMP_NPI_PTN_USAGE   : std_logic_vector( 3 downto 0) := x"0";       -- Pattern Generator - 0x0 : not used   , 0x1 : used
    constant SADUMP_PHASE_TYPE      : std_logic_vector( 3 downto 0) := x"0";       -- DSP output Type   - 0x0 : mono phase , 0x1 : poly phase
    constant SADUMP_DUAL_DUMP_USAGE : std_logic_vector( 3 downto 0) := x"0";       -- 2 point dual dump - 0x0 : not used   , 0x1 : used
    constant SADUMP_STRUCT_INFO     : std_logic_vector(31 downto 0) :=
             x"00" & SADUMP_DUAL_DUMP_USAGE & SADUMP_PHASE_TYPE & SADUMP_NPI_PTN_USAGE & SADUMP_FIXED_PTN_USAGE & SADUMP_SA_USAGE & SADUMP_BUF_NUM;
    constant SADUMP_MODULE_DATE     : std_logic_vector(31 downto 0) := x"2017_0518";

    -- CLK_CPU domain signal
    signal ADDRL13B                 : std_logic_vector(             12 downto 0);
    signal RDEN_DLY                 : std_logic_vector(              7 downto 0);
    signal RDVAL_PLS                : std_logic                                 ;
    signal RST_DUMP                 : std_logic_vector( DUMP_BUF_NUM-1 downto 0);

    -- DUMP signal
    signal dumpdone                 : std_logic                                 ;
    signal rdata_out                : std_logic_vector(             31 downto 0);
    signal rdata                    : std_logic_array32(DUMP_BUF_NUM-1 downto 0);
    
    signal dumpbufsel               : std_logic                                 ; -- used only when BUF_NUM = 1
    signal sample_fs_dly            : std_logic_vector( DUMP_BUF_NUM-1 downto 0);
    signal dump_wrstrb              : std_logic_array1( DUMP_BUF_NUM-1 downto 0);
    signal dump_wrval               : std_logic_array1( DUMP_BUF_NUM-1 downto 0);
    signal dump_wrdata              : std_logic_array32(             1 downto 0);
    signal dump_done                : std_logic_vector( DUMP_BUF_NUM-1 downto 0);
    signal dump_done_sh             : std_logic_array3( DUMP_BUF_NUM-1 downto 0);

    -- Dual Dump Signal
    signal dumpdone_2nd             : std_logic                                  := '0'                        ;
    signal rdata_out_2nd            : std_logic_vector(             31 downto 0) := (others => '0')            ; 
    signal rdata_2nd                : std_logic_array32(DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));

    signal sample_fs_dly_2nd        : std_logic_vector( DUMP_BUF_NUM-1 downto 0) := (others => '0')            ;
    signal dump_wrstrb_2nd          : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dump_wrval_2nd           : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dump_wrdata_2nd          : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal dump_done_2nd            : std_logic_vector( DUMP_BUF_NUM-1 downto 0) := (others => '0')            ;
    signal dump_done_2nd_sh         : std_logic_array3( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));

    signal i_rdata_mem_sel_p        : std_logic                                  := '0'                        ;
    signal i_rdata_mem_sel_n        : std_logic                                  := '0'                        ;


    -- FIXED PATTERN GENERATOR
    signal test_ptn_valid           : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal i_fixed_ptn_data         : std_logic_array32(DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal fixed_ptn_start_dc       : std_logic_array3( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal fixed_ptn_blk_sel        : std_logic_array8( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));

    signal fixed_ptn_cpriphy        : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal fixed_ptn_cpri           : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal fixed_ptn_bbctrl         : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal fixed_ptn_dsp            : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal fixed_ptn_dcif           : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal fixed_ptn_sbif           : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal fixed_ptn_sbifphy        : std_logic_array32(             1 downto 0) := (others => (others => '0'));

    signal test_ptn_cpriphy         : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal test_ptn_cpri            : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal test_ptn_bbctrl          : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal test_ptn_dsp             : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal test_ptn_dcif            : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal test_ptn_sbif            : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal test_ptn_sbifphy         : std_logic_array32(             1 downto 0) := (others => (others => '0'));

    -- DMA interfacd
    signal i_dma_read_ptn           : std_logic_array32(DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dma_rden_dc              : std_logic_array3( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dma_rd_blk_sel           : std_logic_array8( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));

    signal dma_read_ptn_cpriphy     : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal dma_read_ptn_cpri        : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal dma_read_ptn_bbctrl      : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal dma_read_ptn_dsp         : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal dma_read_ptn_dcif        : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal dma_read_ptn_sbif        : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    signal dma_read_ptn_sbifphy     : std_logic_array32(             1 downto 0) := (others => (others => '0'));

    -- TEST PTN SEL
    signal test_ptn_sel_strb        : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0')); 
    signal test_ptn_sel_strb_dc     : std_logic_array3( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0')); 
    signal test_ptn_sel             : std_logic_array2( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0')); 

    -- SA signal
    signal sa_en_sh                 : std_logic_vector(              2 downto 0) := (others => '0');
    signal fs_dly                   : std_logic_vector( DUMP_BUF_NUM-1 downto 0) := (others => '0');
    signal clk_fs_dly               : std_logic                                  := '0'            ;

    signal sa_en_sh_2nd             : std_logic_vector(              2 downto 0) := (others => '0');
    signal fs_dly_2nd               : std_logic_vector( DUMP_BUF_NUM-1 downto 0) := (others => '0');
    signal clk_fs_dly_2nd           : std_logic                                  := '0'            ;

begin
    ----------------------------------------------------------------------------------------------
    -- Module information
    ----------------------------------------------------------------------------------------------
    SADUMP_MODULE_INFO_OUT          <= SADUMP_MODULE_INFO;
    SADUMP_STRUCT_INFO_OUT          <= SADUMP_STRUCT_INFO;
    SADUMP_MODULE_DATE_OUT          <= SADUMP_MODULE_DATE;

    ----------------------------------------------------------------------------------------------
    -- CPU read side : 100MHz domain 
    ----------------------------------------------------------------------------------------------
    ----------------------------------------------------------------------------------------------
    -- Read Data Valid Signal Generation, 5 Clock Latency
    ----------------------------------------------------------------------------------------------
    ADDRL13B <= ADDR_CPU_IN(12 downto 0);

    RDVAL_GEN0: process(RST_MISC, CLK_CPU)
    begin
        if (RST_MISC = '1') then
            RDEN_DLY                <= (others => '0');
            RDVAL_PLS               <= '0';
        elsif (CLK_CPU'event and CLK_CPU = '1') then
            RDEN_DLY                <= RDEN_DLY(6 downto 0) & RDEN_CPU_IN;
            if (RDEN_DLY(3) = '1' and RDEN_DLY(4) = '0') then -- 1 Clock Duration
                RDVAL_PLS           <= '1';
            else
                RDVAL_PLS           <= '0';
            end if;
        end if;
    end process;

    RDVAL_CPU_OUT <= RDVAL_PLS;

    G_Output_of_A_Buffer : if (DUMP_BUF_NUM = 1) generate 
    begin
        dumpdone                    <= dump_done_sh(0)(2);
        dumpdone_2nd                <= dump_done_2nd_sh(0)(2);
        rdata_out                   <= rdata(0);
        rdata_out_2nd               <= rdata_2nd(0);
    end generate;

    G_Output_of_Two_Buffers : if (DUMP_BUF_NUM = 2) generate 
    begin
        process(RST_MISC, CLK_CPU)
        begin
            if (RST_MISC = '1') then
                dumpdone <= '0';
                dumpdone_2nd <= '0';
                rdata_out <= (others => '0');
                rdata_out_2nd <= (others => '0');
            elsif (CLK_CPU'event and CLK_CPU = '1') then
                if (DUMP_BUF_SEL_IN = "01") then
                    dumpdone <= dump_done_sh(0)(2);
                    dumpdone_2nd <= dump_done_2nd_sh(0)(2);                    
                    rdata_out <= rdata(0);
                    rdata_out_2nd <= rdata_2nd(0);
                elsif(DUMP_BUF_SEL_IN = "10") then
                    dumpdone <= dump_done_sh(1)(2);
                    dumpdone_2nd <= dump_done_2nd_sh(1)(2);
                    rdata_out <= rdata(1);
                    rdata_out_2nd <= rdata_2nd(1);

                else
                    dumpdone <= '1';
                    dumpdone_2nd <= '1';
                    rdata_out <= (others => '0');
                    rdata_out_2nd <= (others => '0');
                end if;
            end if;
        end process;

        --dumpdone                    <= dump_done_sh(0)(2)     when (DUMP_BUF_SEL_IN = "01") else
        --                               dump_done_sh(1)(2)     when (DUMP_BUF_SEL_IN = "10") else
        --                               '1';

        --dumpdone_2nd                <= dump_done_2nd_sh(0)(2) when (DUMP_BUF_SEL_2ND_IN = "01") else
        --                               dump_done_2nd_sh(1)(2) when (DUMP_BUF_SEL_2ND_IN = "10") else
        --                               '1';

        --rdata_out                   <= rdata(0)               when (DUMP_BUF_SEL_IN = "01") else
        --                               rdata(1)               when (DUMP_BUF_SEL_IN = "10") else
        --                               (others => '0');

        --rdata_out_2nd               <= rdata_2nd(0)           when (DUMP_BUF_SEL_2ND_IN = "01") else
        --                               rdata_2nd(1)           when (DUMP_BUF_SEL_2ND_IN = "10") else
        --                               (others => '0');
    end generate;

    DUMP_DONE_OUT                   <= dumpdone;
    DUMP_DONE_2ND_OUT               <= dumpdone_2nd;
    RDATA_CPU_OUT                   <= rdata_out              when (RDATA_MEMORY_SEL_IN = '0') else 
                                       rdata_out_2nd; 


    process(RST_MISC, CLK_CPU)
    begin
        if (RST_MISC = '1') then
            i_rdata_mem_sel_p       <= '0';
            i_rdata_mem_sel_n       <= '0';
        elsif (CLK_CPU'event and CLK_CPU = '1') then
            i_rdata_mem_sel_p       <=     ( RDATA_MEMORY_SEL_IN );
            i_rdata_mem_sel_n       <= not ( RDATA_MEMORY_SEL_IN );
        end if;
    end process;
    ----------------------------------------------------------------------------------------------
    -- DUMP side   
    ----------------------------------------------------------------------------------------------
    G_CLK_N_RST1 : if (DUMP_BUF_NUM = 1) generate 
    begin

        U_RST_SYNC : RST_SYNC generic map(4 , 200 ) port map(RST_MISC, CLK_DUMP0, RST_DUMP(0));
    end generate;

    G_CLK_N_RST2 : if (DUMP_BUF_NUM = 2) generate 
    begin

        U_RST_SYNC1 : RST_SYNC generic map(4 , 200 ) port map(RST_MISC, CLK_DUMP0, RST_DUMP(0));
        U_RST_SYNC2 : RST_SYNC generic map(4 , 200 ) port map(RST_MISC, CLK_DUMP1, RST_DUMP(1));
    end generate;


    U_DATAPATH_SEL : DATAPATH_SEL
    generic map(
        DUMP_BUF_NUM                => DUMP_BUF_NUM                             , --: natural := 1
        CPRI_NUM                    => CPRI_NUM                                 , --: natural := 7
        POLY_PHASE_USAGE            => POLY_PHASE_USAGE                           --: boolean := FALSE
        )
    port map(
        RST                         => RST_MISC                                 , --: in std_logic                              ;
        CLK_DUMP0                   => CLK_DUMP0                                , --: in std_logic                              ;
        CLK_DUMP1                   => CLK_DUMP1                                , --: in std_logic                              ;

        --External Device
        EXT_TRIGGER_IN              => EXT_TRIGGER_IN                           , --: in  std_logic                             ;
    
        --SYSCTRL_TOP
        RX_BFNSTRB_SYSCTRL_IN       => RX_BFNSTRB_SYSCTRL_IN                    , --: in  std_logic_array1(CPRI_NUM-1 downto 0) ;
        TX_BFNSTRB_SYSCTRL_IN       => TX_BFNSTRB_SYSCTRL_IN                    , --: in  std_logic_array1(CPRI_NUM-1 downto 0) ;
    
        --CPRI_TOP
        RX_BFNSTRB_CPRI_IN          => RX_BFNSTRB_CPRI_IN                       , --: in  std_logic_array1(CPRI_NUM-1 downto 0) ;

        --BBCTRL_TOP
        DUMP_BFN_STRB_BBCTRL_IN     => DUMP_BFN_STRB_BBCTRL_IN                  , --: in  std_logic_array1(1 downto 0)          ;
        DUMP_DATA_BBCTRL_IN         => DUMP_DATA_BBCTRL_IN                      , --: in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_BBCTRL_IN         => DUMP_DVLD_BBCTRL_IN                      , --: in  std_logic_array1(1 downto 0)          ;
                                                               
        --CPRI_TOP
        DUMP_BFN_STRB_CPRI_IN       => DUMP_BFN_STRB_CPRI_IN                    , --: in  std_logic_array1(1 downto 0)          ;
        DUMP_DATA_CPRI_IN           => DUMP_DATA_CPRI_IN                        , --: in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_CPRI_IN           => DUMP_DVLD_CPRI_IN                        , --: in  std_logic_array1(1 downto 0)          ;
                                                               
        --CPRIPHY_TOP
        DUMP_BFN_STRB_CPRIPHY_IN    => DUMP_BFN_STRB_CPRIPHY_IN                 , --: in  std_logic_array1(1 downto 0)          ;
        DUMP_DATA_CPRIPHY_IN        => DUMP_DATA_CPRIPHY_IN                     , --: in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_CPRIPHY_IN        => DUMP_DVLD_CPRIPHY_IN                     , --: in  std_logic_array1(1 downto 0)          ;
                                                               
        --DCIF_TOP
        DUMP_BFN_STRB_DCIF_IN       => DUMP_BFN_STRB_DCIF_IN                    , --: in  std_logic_array1(1 downto 0)          ;
        DUMP_DATA_DCIF_IN           => DUMP_DATA_DCIF_IN                        , --: in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_DCIF_IN           => DUMP_DVLD_DCIF_IN                        , --: in  std_logic_array1(1 downto 0)          ;
                                                               
        --DSP_TOP
        DUMP_BFN_STRB_DSP_IN        => DUMP_BFN_STRB_DSP_IN                     , --: in  std_logic_array1(1 downto 0)          ;
        DUMP_DATA_DSP_IN            => DUMP_DATA_DSP_IN                         , --: in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_DSP_IN            => DUMP_DVLD_DSP_IN                         , --: in  std_logic_array1(1 downto 0)          ;

        --SBIF_TOP
        DUMP_BFN_STRB_SBIF_IN       => DUMP_BFN_STRB_SBIF_IN                    , --: in  std_logic_array1(1 downto 0)          ;
        DUMP_DATA_SBIF_IN           => DUMP_DATA_SBIF_IN                        , --: in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_SBIF_IN           => DUMP_DVLD_SBIF_IN                        , --: in  std_logic_array1(1 downto 0)          ;

        --SBIFPHY_TOP
        DUMP_BFN_STRB_SBIFPHY_IN    => DUMP_BFN_STRB_SBIFPHY_IN                 , --: in  std_logic_array1(1 downto 0)          ;
        DUMP_DATA_SBIFPHY_IN        => DUMP_DATA_SBIFPHY_IN                     , --: in  std_logic_array32(1 downto 0)         ;
        DUMP_DVLD_SBIFPHY_IN        => DUMP_DVLD_SBIFPHY_IN                     , --: in  std_logic_array1(1 downto 0)          ;
                                                               
        DUMP_START_IN               => DUMP_START_IN                            , --: in  std_logic                             ;
        DUMP_DATASEL_IN             => DUMP_DATASEL_IN                          , --: in  std_logic_vector(7 downto 0)          ;

        RX_SYSCTRL_STRB_SEL_IN      => RX_SYSCTRL_STRB_SEL_IN                   , --: in  std_logic_vector( 7 downto 0)         ;
        TX_SYSCTRL_STRB_SEL_IN      => TX_SYSCTRL_STRB_SEL_IN                   , --: in  std_logic_vector( 7 downto 0)         ;
        RX_CPRI_STRB_SEL_IN         => RX_CPRI_STRB_SEL_IN                      , --: in  std_logic_vector( 7 downto 0)         ;
        MODULE_STRB_SEL_IN          => MODULE_STRB_SEL_IN                       , --: in  std_logic_vector( 7 downto 0)         ;
                                                               
        WRSTRB_OUT                  => dump_wrstrb                              , --: out std_logic_array1( DUMP_BUF_NUM-1 downto 0);
        WRDATA_OUT                  => dump_wrdata                              , --: out std_logic_array32(DUMP_BUF_NUM-1 downto 0);
        WRVAL_OUT                   => dump_wrval                                 --: out std_logic_array1( DUMP_BUF_NUM-1 downto 0)
        );

    G_DATAPATH_SEL_of_DualDump : if (DUAL_DUMP_USAGE = TRUE) generate
    begin

        U_DATAPATH_SEL_of_DualDump : DATAPATH_SEL
        generic map(
            DUMP_BUF_NUM            => DUMP_BUF_NUM                             , --: natural := 1
            CPRI_NUM                => CPRI_NUM                                 , --: natural := 7
            POLY_PHASE_USAGE        => FALSE                                      --: boolean := FALSE
            )
        port map(
            RST                     => RST_MISC                                 , --: in std_logic                              ;
            CLK_DUMP0               => CLK_DUMP0                                , --: in std_logic                              ;
            CLK_DUMP1               => CLK_DUMP1                                , --: in std_logic                              ;

            --External Device
            EXT_TRIGGER_IN          => EXT_TRIGGER_IN                           , --: in  std_logic                             ;
        
            --SYSCTRL_TOP
            RX_BFNSTRB_SYSCTRL_IN   => RX_BFNSTRB_SYSCTRL_IN                    , --: in  std_logic_array1(CPRI_NUM-1 downto 0) ;
            TX_BFNSTRB_SYSCTRL_IN   => TX_BFNSTRB_SYSCTRL_IN                    , --: in  std_logic_array1(CPRI_NUM-1 downto 0) ;
        
            --CPRI_TOP
            RX_BFNSTRB_CPRI_IN      => RX_BFNSTRB_CPRI_IN                       , --: in  std_logic_array1(CPRI_NUM-1 downto 0) ;

            --BBCTRL_TOP
            DUMP_BFN_STRB_BBCTRL_IN => DUMP_BFN_STRB_BBCTRL_IN                  , --: in  std_logic_array1(1 downto 0)          ;
            DUMP_DATA_BBCTRL_IN     => DUMP_DATA_BBCTRL_IN                      , --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_BBCTRL_IN     => DUMP_DVLD_BBCTRL_IN                      , --: in  std_logic_array1(1 downto 0)          ;
                                                               
            --CPRI_TOP
            DUMP_BFN_STRB_CPRI_IN   => DUMP_BFN_STRB_CPRI_IN                    , --: in  std_logic_array1(1 downto 0)          ;
            DUMP_DATA_CPRI_IN       => DUMP_DATA_CPRI_IN                        , --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_CPRI_IN       => DUMP_DVLD_CPRI_IN                        , --: in  std_logic_array1(1 downto 0)          ;
                                                               
            --CPRIPHY_TOP
            DUMP_BFN_STRB_CPRIPHY_IN=> DUMP_BFN_STRB_CPRIPHY_IN                 , --: in  std_logic_array1(1 downto 0)          ;
            DUMP_DATA_CPRIPHY_IN    => DUMP_DATA_CPRIPHY_IN                     , --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_CPRIPHY_IN    => DUMP_DVLD_CPRIPHY_IN                     , --: in  std_logic_array1(1 downto 0)          ;
                                                               
            --DCIF_TOP
            DUMP_BFN_STRB_DCIF_IN   => DUMP_BFN_STRB_DCIF_IN                    , --: in  std_logic_array1(1 downto 0)          ;
            DUMP_DATA_DCIF_IN       => DUMP_DATA_DCIF_IN                        , --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_DCIF_IN       => DUMP_DVLD_DCIF_IN                        , --: in  std_logic_array1(1 downto 0)          ;
                                                               
            --DSP_TOP
            DUMP_BFN_STRB_DSP_IN    => DUMP_BFN_STRB_DSP_IN                     , --: in  std_logic_array1(1 downto 0)          ;
            DUMP_DATA_DSP_IN        => DUMP_DATA_DSP_IN                         , --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_DSP_IN        => DUMP_DVLD_DSP_IN                         , --: in  std_logic_array1(1 downto 0)          ;

            --SBIF_TOP
            DUMP_BFN_STRB_SBIF_IN   => DUMP_BFN_STRB_SBIF_IN                    , --: in  std_logic_array1(1 downto 0)          ;
            DUMP_DATA_SBIF_IN       => DUMP_DATA_SBIF_IN                        , --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_SBIF_IN       => DUMP_DVLD_SBIF_IN                        , --: in  std_logic_array1(1 downto 0)          ;

            --SBIFPHY_TOP
            DUMP_BFN_STRB_SBIFPHY_IN=> DUMP_BFN_STRB_SBIFPHY_IN                 , --: in  std_logic_array1(1 downto 0)          ;
            DUMP_DATA_SBIFPHY_IN    => DUMP_DATA_SBIFPHY_IN                     , --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_SBIFPHY_IN    => DUMP_DVLD_SBIFPHY_IN                     , --: in  std_logic_array1(1 downto 0)          ;
                                                               
            DUMP_START_IN           => DUMP_START_IN                            , --: in  std_logic                             ;
            DUMP_DATASEL_IN         => DUMP_DATASEL_2ND_IN                      , --: in  std_logic_vector(7 downto 0)          ;

            RX_SYSCTRL_STRB_SEL_IN  => RX_SYSCTRL_STRB_SEL_2ND_IN               , --: in  std_logic_vector( 7 downto 0)         ;
            TX_SYSCTRL_STRB_SEL_IN  => TX_SYSCTRL_STRB_SEL_2ND_IN               , --: in  std_logic_vector( 7 downto 0)         ;
            RX_CPRI_STRB_SEL_IN     => RX_CPRI_STRB_SEL_2ND_IN                  , --: in  std_logic_vector( 7 downto 0)         ;
            MODULE_STRB_SEL_IN      => MODULE_STRB_SEL_2ND_IN                   , --: in  std_logic_vector( 7 downto 0)         ;
                                                               
            WRSTRB_OUT              => dump_wrstrb_2nd                          , --: out std_logic_array1( DUMP_BUF_NUM-1 downto 0);
            WRDATA_OUT              => dump_wrdata_2nd                          , --: out std_logic_array32(DUMP_BUF_NUM-1 downto 0);
            WRVAL_OUT               => dump_wrval_2nd                             --: out std_logic_array1( DUMP_BUF_NUM-1 downto 0)
            );
    end generate;


    U_TEST_PTN_PATH_SEL : TESTPTNPATH_SEL
    generic map(
        DUMP_BUF_NUM                => DUMP_BUF_NUM                              --: natural := 1
        )
    port map(
        RST                         => RST_MISC                                 , --: in std_logic                              ;
        CLK_DUMP0                   => CLK_DUMP0                                , --: in std_logic                              ;
        CLK_DUMP1                   => CLK_DUMP1                                , --: in std_logic                              ;

        TEST_ENB_CPRIPHY_IN         => TEST_ENB_CPRIPHY_IN                      , --: in std_logic_array1(1 downto 0)           ;
        TEST_ENB_CPRI_IN            => TEST_ENB_CPRI_IN                         , --: in std_logic_array1(1 downto 0)           ;
        TEST_ENB_SBIF_IN            => TEST_ENB_SBIF_IN                         , --: in std_logic_array1(1 downto 0)           ;
        TEST_ENB_SBIFPHY_IN         => TEST_ENB_SBIFPHY_IN                      , --: in std_logic_array1(1 downto 0)           ;
        TEST_ENB_BBCTRL_IN          => TEST_ENB_BBCTRL_IN                       , --: in std_logic_array1(1 downto 0)           ;
        TEST_ENB_DSP_IN             => TEST_ENB_DSP_IN                          , --: in std_logic_array1(1 downto 0)           ;
        TEST_ENB_DCIF_IN            => TEST_ENB_DCIF_IN                         , --: in std_logic_array1(1 downto 0)           ;

        FIXED_PTN_START_IN          => FIXED_PTN_START_IN                       , --: in std_logic                              ;
        FIXED_PTN_BLK_SEL_IN        => FIXED_PTN_BLK_SEL_IN                     , --: in std_logic_vector(7 downto 0)           ;

        TEST_ENB_OUT                => test_ptn_valid                             --: out std_logic_array1(DUMP_BUF_NUM-1 downto 0)
        );

    NPI_GEN_ENABLE : if (NPI_PTN_USAGE = TRUE) generate
    begin 

        U_DMA_WRAPPER_0 : DMA_WRAPPER
        generic map(
            DUMP_BUF_NUM            => DUMP_BUF_NUM                             , --: natural := 2
            CPRI_NUM                => CPRI_NUM                                   --: natural := 7
        )
        port map(
            RST                     => RST_MISC                                 , --: in  std_logic                             ;
            CLK_DUMP0               => CLK_DUMP0                                , --: in  std_logic                             ;
            CLK_DUMP1               => CLK_DUMP1                                , --: in  std_logic                             ;
        
            DMA_RDEN_IN             => DMA_RDEN_IN                              , --: in  std_logic                             ;
            DMA_WREN_IN             => DMA_WREN_IN                              , --: in  std_logic                             ;
            DMA_READ_BLK_SEL_IN     => DMA_READ_BLK_SEL_IN                      , --: in  std_logic_vector( 7 downto 0)         ;
            DMA_WRITE_BLK_SEL_IN    => DMA_WRITE_BLK_SEL_IN                     , --: in  std_logic_vector( 7 downto 0)         ;
            DMA_BFN_STRB_SEL_IN     => DMA_BFN_STRB_SEL_IN                      , --: in  std_logic_vector( 7 downto 0)         ;
            DMA_DLY_VALUE_IN        => DMA_DLY_VALUE_IN                         , --: in  std_logic_vector(23 downto 0)         ;
        
            DMA_RDCLK_OUT           => DMA_RDCLK_OUT                            , --: out std_logic_array1(1 downto 0)          ;
            DMA_RDRDY_IN            => DMA_RDRDY_IN                             , --: in  std_logic                             ;
            DMA_RDEN_OUT            => DMA_RDEN_OUT                             , --: out std_logic_array1(1 downto 0)          ;
            DMA_RDATA_IN            => DMA_RDATA_IN                             , --: in  std_logic_array32(1 downto 0)         ;
            DMA_RDEPT_IN            => DMA_RDEPT_IN                             , --: in  std_logic                             ;
        
            DMA_WRCLK_OUT           => DMA_WRCLK_OUT                            , --: out std_logic_array1(1 downto 0)          ;
            DMA_WRRDY_IN            => DMA_WRRDY_IN                             , --: in  std_logic                             ;
            DMA_WREN_OUT            => DMA_WREN_OUT                             , --: out std_logic_array1(1 downto 0)          ;
            DMA_WDATA_OUT           => DMA_WDATA_OUT                            , --: out std_logic_array32(1 downto 0)         ;
            DMA_WRFULL_IN           => DMA_WRFULL_IN                            , --: in  std_logic                             ;
        
            DMA_READ_PTN            => i_dma_read_ptn                           , --: out std_logic_array32(1 downto 0)         ;
        
            RX_BFNSTRB_SYSCTRL_IN   => RX_BFNSTRB_SYSCTRL_IN                    , --: in  std_logic_vector(CPRI_NUM-1 downto 0) ;
            TX_BFNSTRB_SYSCTRL_IN   => TX_BFNSTRB_SYSCTRL_IN                    , --: in  std_logic_vector(CPRI_NUM-1 downto 0) ;
            RX_BFNSTRB_CPRI_IN      => RX_BFNSTRB_CPRI_IN                       , --: in  std_logic_vector(CPRI_NUM-1 downto 0) ;

            DUMP_DATA_CPRIPHY_IN    => DUMP_DATA_CPRIPHY_IN                     , --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_CPRIPHY_IN    => DUMP_DVLD_CPRIPHY_IN                     , --: in  std_logic_array1(1 downto 0)          ;

            TEST_ENB_CPRIPHY_IN     => TEST_ENB_CPRIPHY_IN                      , --: in  std_logic_array1(1 downto 0)          ;

            DUMP_DATA_CPRI_IN       => DUMP_DATA_CPRI_IN                        , --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_CPRI_IN       => DUMP_DVLD_CPRI_IN                        , --: in  std_logic_array1(1 downto 0)          ;

            TEST_ENB_CPRI_IN        => TEST_ENB_CPRI_IN                         , --: in  std_logic_array1(1 downto 0)          ;

            DUMP_DATA_SBIF_IN       => DUMP_DATA_SBIF_IN                        , --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_SBIF_IN       => DUMP_DVLD_SBIF_IN                        , --: in  std_logic_array1(1 downto 0)          ;
                                                           
            TEST_ENB_SBIF_IN        => TEST_ENB_SBIF_IN                         , --: in  std_logic_array1(1 downto 0)          ;

            DUMP_DATA_SBIFPHY_IN    => DUMP_DATA_SBIFPHY_IN                     , --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_SBIFPHY_IN    => DUMP_DVLD_SBIFPHY_IN                     , --: in  std_logic_array1(1 downto 0)          ;

            TEST_ENB_SBIFPHY_IN     => TEST_ENB_SBIFPHY_IN                      , --: in  std_logic_array1(1 downto 0)          ;

            DUMP_DATA_BBCTRL_IN     => DUMP_DATA_BBCTRL_IN                      , --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_BBCTRL_IN     => DUMP_DVLD_BBCTRL_IN                      , --: in  std_logic_vector(1 downto 0)          ;

            TEST_ENB_BBCTRL_IN      => TEST_ENB_BBCTRL_IN                       , --: in  std_logic_vector(1 downto 0)          ;

            DUMP_DATA_DSP_IN        => DUMP_DATA_DSP_IN                    , --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_DSP_IN        => DUMP_DVLD_DSP_IN                         , --: in  std_logic_vector(1 downto 0)          ;
                                                          
            TEST_ENB_DSP_IN         => TEST_ENB_DSP_IN                          , --: in  std_logic_vector(1 downto 0)          ;
                                    
            DUMP_DATA_DCIF_IN       => DUMP_DATA_DCIF_IN                        , --: in  std_logic_array32(1 downto 0)         ;
            DUMP_DVLD_DCIF_IN       => DUMP_DVLD_DCIF_IN                        , --: in  std_logic_vector(1 downto 0)          ;
                                                          
            TEST_ENB_DCIF_IN        => TEST_ENB_DCIF_IN                           --: in  std_logic_vector(1 downto 0)         
            );
    end generate NPI_GEN_ENABLE;

    NPI_GEN_DISABLE : if (NPI_PTN_USAGE = FALSE) generate
    begin

        DMA_RDCLK_OUT               <= '0'; 
        DMA_RDEN_OUT                <= '0'; 
 
        DMA_WRCLK_OUT               <= '0'; 
        DMA_WREN_OUT                <= '0'; 
        DMA_WDATA_OUT               <= (others => '0'); 

        i_dma_read_ptn              <= (others => (others => '0'));

    end generate NPI_GEN_DISABLE;

----------------------------------------------------------------------------------------------------------------------------------------
---- case ) DUMP_BUF_NUM = 1
----------------------------------------------------------------------------------------------------------------------------------------

    G_DUMP_Function_BUF_1 : if (DUMP_BUF_NUM = 1) generate
    begin
        dumpbufsel                  <= DUMP_BUF_SEL_IN(1) or DUMP_BUF_SEL_IN(0);

        U_STARTOFFSET : STARTOFFSET_WRAPPER
        port map(
        RST                         => RST_DUMP(0)                              , --: in  std_logic                             ;
        CLK                         => CLK_DUMP0                                , --: in  std_logic                             ;
    
        FS_IN                       => dump_wrstrb(0)(0)                        , --: in  std_logic                             ;
        DUMP_STARTDLY_IN            => DUMP_STARTDLY_IN                         , --: in  std_logic_vector(11 downto 0)         ;
        DUMP_START_IN               => DUMP_START_IN                            , --: in  std_logic                             ;
        DUMP_BUF_SEL_IN             => dumpbufsel                               , --: in  std_logic                             ;
    
        SAMPLE_FSDLY_OUT            => sample_fs_dly(0)                           --: out std_logic
        );


        G_START_OFFSET_of_DualDump : if (DUAL_DUMP_USAGE = TRUE) generate
        begin

            U_STARTOFFSET_2nd : STARTOFFSET_WRAPPER
            Port map(
            RST                     => RST_DUMP(0)                              , --: in  std_logic                             ;
            CLK                     => CLK_DUMP0                                , --: in  std_logic                             ;
    
            FS_IN                   => dump_wrstrb_2nd(0)(0)                    , --: in  std_logic                             ;
            DUMP_STARTDLY_IN        => DUMP_STARTDLY_2ND_IN                     , --: in  std_logic_vector(11 downto 0)         ;
            DUMP_START_IN           => DUMP_START_IN                            , --: in  std_logic                             ;
            DUMP_BUF_SEL_IN         => dumpbufsel                               , --: in  std_logic                             ;
    
            SAMPLE_FSDLY_OUT        => sample_fs_dly_2nd(0)                       --: out std_logic
            );
        end generate;

        G_SA_GENERATE : if (SA_USAGE = TRUE) generate
        begin

            U_SA_FUNCTION_1st : SA_WRAPPER
            port map(
            RST                     => RST_DUMP(0)                              , --: in  std_logic                             ;
            CLK_SA                  => CLK_DUMP0                                , --: in  std_logic                             ;
    
            FS_IN                   => dump_wrstrb(0)(0)                        , --: in  std_logic                             ;
    
            TXSA_CLKDLYVALUE_IN     => TXSA_CLKDLYVALUE_IN                      , --: in  std_logic_vector(23 downto 0)         ; 
            
            DUMP_BUF_SEL_IN         => dumpbufsel                               , --: in  std_logic                             ; 
            DUMP_START_IN           => DUMP_START_IN                            , --: in  std_logic                             ; 
            SA_ENB_IN               => TXSA_ENB_IN                              , --: in  std_logic                             ; 
            DUMPDONE_IN             => dump_done(0)                             , --: in  std_logic                             ; 
    
            FB_SW_CNT_INFO_IN       => FB_SW_CNT_INFO_IN                        , --: in  std_logic_vector(5 downto 0)          ;
            FBSW_CNT_IN             => FBSW_CNT_IN                              , --: in  std_logic_vector(5 downto 0)          ; 
            AUTO_MODE_DONE_IN       => AUTO_MODE_DONE_IN                        , --: in  std_logic                             ; 
            SSB_EXIST_IN            => SSB_EXIST_IN                             , --: in  std_logic                             ; 

            FBSW_MANUAL_IN          => FBSW_MANUAL_IN                           , --: in  std_logic                             ;
    
            CLK_FS_DLY_OUT          => clk_fs_dly                                 --: out std_logic                             ;
    
            );

            G_SA_of_DualDump : if (DUAL_DUMP_USAGE = TRUE) generate
            begin
                
                U_SA_FUNCTION_2nd : SA_WRAPPER
                port map(
                RST                 => RST_DUMP(0)                              , --: in  std_logic                             ;
                CLK_SA              => CLK_DUMP0                                , --: in  std_logic                             ;
    
                FS_IN               => dump_wrstrb_2nd(0)(0)                    , --: in  std_logic                             ;
    
                TXSA_CLKDLYVALUE_IN => TXSA_CLKDLYVALUE_2ND_IN                  , --: in  std_logic_vector(23 downto 0)         ; 
                
                DUMP_BUF_SEL_IN     => dumpbufsel                               , --: in  std_logic                             ; 
                DUMP_START_IN       => DUMP_START_IN                            , --: in  std_logic                             ; 
                SA_ENB_IN           => TXSA_ENB_2ND_IN                          , --: in  std_logic                             ; 
                DUMPDONE_IN         => dump_done_2nd(0)                         , --: in  std_logic                             ; 
    
                FB_SW_CNT_INFO_IN   => FB_SW_CNT_INFO_2ND_IN                    , --: in  std_logic_vector(1 downto 0)          ;
                FBSW_CNT_IN         => FBSW_CNT_IN                              , --: in  std_logic_vector(5 downto 0)          ; 
                AUTO_MODE_DONE_IN   => AUTO_MODE_DONE_IN                        , --: in  std_logic                             ; 
                SSB_EXIST_IN        => SSB_EXIST_IN                             , --: in  std_logic                             ; 

                FBSW_MANUAL_IN      => FBSW_MANUAL_IN                           , --: in  std_logic                             ;
    
                CLK_FS_DLY_OUT      => clk_fs_dly_2nd                             --: out std_logic                             ;
    
                );
            end generate;

            P_SA_EN_DC : process(RST_DUMP(0), CLK_DUMP0) 
            begin
                if (RST_DUMP(0) = '1') then
                    sa_en_sh        <= (others => '0');
                    sa_en_sh_2nd    <= (others => '0');
                elsif (CLK_DUMP0'event) and (CLK_DUMP0 = '1') then
                    sa_en_sh        <= sa_en_sh(1 downto 0)     & TXSA_ENB_IN;
                    sa_en_sh_2nd    <= sa_en_sh_2nd(1 downto 0) & TXSA_ENB_2ND_IN;
                end if;
            end process;

            P_MODE_SWITCH : process(RST_DUMP(0), CLK_DUMP0) 
            begin
                if (RST_DUMP(0) = '1') then
                    fs_dly(0)       <= '0';
                    fs_dly_2nd(0)   <= '0';
                elsif (CLK_DUMP0'event) and (CLK_DUMP0 = '1') then
                    if (sa_en_sh(2) = '1') then
                        fs_dly(0)   <= clk_fs_dly;
                    else
                        fs_dly(0)   <= sample_fs_dly(0);
                    end if;

                    if (sa_en_sh_2nd(2) = '1') then
                        fs_dly_2nd(0)   <= clk_fs_dly_2nd;
                    else
                        fs_dly_2nd(0)   <= sample_fs_dly_2nd(0);
                    end if;

                end if;
            end process;

            P_DumpDone_DC : process(RST_MISC, CLK_CPU) 
            begin
                if (RST_MISC = '1') then
                    dump_done_sh(0)     <= (others => '0');
                    dump_done_2nd_sh(0) <= (others => '0');
                elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                    dump_done_sh(0)     <= dump_done_sh(0)(1 downto 0)     & dump_done(0);
                    dump_done_2nd_sh(0) <= dump_done_2nd_sh(0)(1 downto 0) & dump_done_2nd(0);
                end if;
            end process;

        end generate;

        G_SA_NON_GENERATE : if (SA_USAGE = FALSE) generate
        begin
            fs_dly(0)               <= sample_fs_dly(0);
            fs_dly_2nd(0)           <= sample_fs_dly_2nd(0);
        end generate;

        U_BUFFER_WRAPPER : BUFFER_WRAPPER
        generic map(
        FIXED_PTN_USAGE             => FIXED_PTN_USAGE                          , --: boolean 
        POLY_PHASE_USAGE            => POLY_PHASE_USAGE                           --: boolean  
        )
        port map(
        RST                         => RST_DUMP(0)                              , --: in  std_logic                             ;                    
        CLK_CPU                     => CLK_CPU                                  , --: in  std_logic                             ;
        CLK_DUMP                    => CLK_DUMP0                                , --: in  std_logic                             ;                    
    
        DUMP_BUF_SEL_IN             => dumpbufsel                               , --: in  std_logic                             ;                    
        DUMP_START_IN               => DUMP_START_IN                            , --: in  std_logic                             ;                    
    
        FS_DLY_IN                   => fs_dly(0)                                , --: in  std_logic                             ;                    
        DUMPDONE_OUT                => dump_done(0)                             , --: out std_logic                             ;

        FIXED_PTN_VALID_IN          => test_ptn_valid(0)(0)                     , --: in  std_logic_vector( 0 downto 0)         ;
        FIXED_PTN_GEN_EN_IN         => FIXED_PTN_GEN_EN_IN                      , --: in  std_logic                             ;
        FIXED_PTN_START_IN          => FIXED_PTN_START_IN                       , --: in  std_logic                             ;
        FIXED_PTN_LENGTH_IN         => FIXED_PTN_LENGTH_IN                      , --: in  std_logic_vector(12 downto 0)         ;
        PHASE_SEL_IN                => PHASE_SEL_IN                             , --: in  std_logic                             ;
    
        TEST_PTN_VALID_OUT          => TEST_PTN_VALID_OUT(0)                    , --: out std_logic                             ;
        GEN_RDATA_OUT               => i_fixed_ptn_data(0)                      , --: out std_logic_vector(31 downto 0)         ;

        DUMP_WRVAL_IN               => dump_wrval(0)(0)                         , --: in  std_logic_vector( 0 downto 0)         ;
        DUMP_WRDATA_IN              => dump_wrdata(0)                           , --: in  std_logic_vector(31 downto 0)         ;
        DUMP_ODD_WRDATA_IN          => dump_wrdata(1)                           , --: in  std_logic_vector(31 downto 0)         ;
            
        RDATA_MEMORY_SEL_IN         => i_rdata_mem_sel_n                        , --: in  std_logic                             ;
        WREN_CPU_IN                 => WREN_CPU_IN                              , --: in  std_logic                             ;
        RDEN_CPU_IN                 => RDEN_CPU_IN                              , --: in  std_logic                             ;                    
        WDATA_CPU_IN                => WDATA_CPU_IN                             , --: in  std_logic_vector(31 downto 0)         ;
        ADDRL13B_IN                 => ADDRL13B                                 , --: in  std_logic_vector(12 downto 0)         ;
        RDATA_CPU_OUT               => rdata(0)                                   --: out std_logic_vector(31 downto 0)
        );

        TEST_PTN_VALID_OUT(1)       <= '0';
	
        G_BUFFER_of_DualDump : if (DUAL_DUMP_USAGE = TRUE) generate
        begin
            U_BUFFER_of_DualDump : BUFFER_WRAPPER
            generic map(
            FIXED_PTN_USAGE         => FALSE                                    , --: boolean                                   ;
            POLY_PHASE_USAGE        => FALSE                                      --: boolean                                   ;
            )
            port map(
            RST                     => RST_DUMP(0)                              , --: in  std_logic                             ;                    
            CLK_CPU                 => CLK_CPU                                  , --: in  std_logic                             ;
            CLK_DUMP                => CLK_DUMP0                                , --: in  std_logic                             ;                    
    
            DUMP_BUF_SEL_IN         => dumpbufsel                               , --: in  std_logic                             ;                    
            DUMP_START_IN           => DUMP_START_IN                            , --: in  std_logic                             ;                    
    
            FS_DLY_IN               => fs_dly_2nd(0)                            , --: in  std_logic                             ;                    
            DUMPDONE_OUT            => dump_done_2nd(0)                         , --: out std_logic                             ;

            FIXED_PTN_VALID_IN      => '0'                                      , --: in  std_logic_vector( 0 downto 0)         ;
            FIXED_PTN_GEN_EN_IN     => '0'                                      , --: in  std_logic                             ;
            FIXED_PTN_START_IN      => '0'                                      , --: in  std_logic                             ;
            FIXED_PTN_LENGTH_IN     => (others => '0')                          , --: in  std_logic_vector(12 downto 0)         ;
            PHASE_SEL_IN            => PHASE_SEL_IN                             , --: in  std_logic                             ;
    
            TEST_PTN_VALID_OUT      => open                                     , --: out std_logic                             ;
            GEN_RDATA_OUT           => open                                     , --: out std_logic_vector(31 downto 0)         ;

            DUMP_WRVAL_IN           => dump_wrval_2nd(0)(0)                     , --: in  std_logic_vector( 0 downto 0)         ;
            DUMP_WRDATA_IN          => dump_wrdata_2nd(0)                       , --: in  std_logic_vector(31 downto 0)         ;
            DUMP_ODD_WRDATA_IN      => (others => '0')                          , --: in  std_logic_vector(31 downto 0)         ;
                
            RDATA_MEMORY_SEL_IN     => i_rdata_mem_sel_p                        , --: in  std_logic                             ;
            WREN_CPU_IN             => WREN_CPU_IN                              , --: in  std_logic                             ;
            RDEN_CPU_IN             => RDEN_CPU_IN                              , --: in  std_logic                             ;                    
            WDATA_CPU_IN            => WDATA_CPU_IN                             , --: in  std_logic_vector(31 downto 0)         ;
            ADDRL13B_IN             => ADDRL13B                                 , --: in  std_logic_vector(12 downto 0)         ;
            RDATA_CPU_OUT           => rdata_2nd(0)                               --: out std_logic_vector(31 downto 0)
            );
        end generate;

    end generate;

----------------------------------------------------------------------------------------------------------------------------------------
---- case ) DUMP_BUF_NUM = 2
----------------------------------------------------------------------------------------------------------------------------------------

    G_Dump_Function_BUF_2 : if (DUMP_BUF_NUM = 2) generate
    begin

        G_Function_generate : for I in 0 to (DUMP_BUF_NUM-1) generate
        begin
            G_STARTOFFSET_GEN_1 : if (I = 0) generate
            begin
                U_STARTOFFSET_WRAPPER : STARTOFFSET_WRAPPER
                port map(
                RST                     => RST_DUMP(I)                              , --: in  std_logic                             ;
                CLK                     => CLK_DUMP0                                , --: in  std_logic                             ;
    
                FS_IN                   => dump_wrstrb(I)(0)                        , --: in  std_logic                             ;
                DUMP_STARTDLY_IN        => DUMP_STARTDLY_IN                         , --: in  std_logic_vector(11 downto 0)         ;
                DUMP_START_IN           => DUMP_START_IN                            , --: in  std_logic                             ;
                DUMP_BUF_SEL_IN         => DUMP_BUF_SEL_IN(I)                       , --: in  std_logic                             ;
    
                SAMPLE_FSDLY_OUT        => sample_fs_dly(I)                           --: out std_logic
                );
            end generate;


            G_STARTOFFSET_GEN_2 : if (I = 1) generate
            begin
                U_STARTOFFSET_WRAPPER : STARTOFFSET_WRAPPER
                port map(
                RST                     => RST_DUMP(I)                              , --: in  std_logic                             ;
                CLK                     => CLK_DUMP1                                , --: in  std_logic                             ;
    
                FS_IN                   => dump_wrstrb(I)(0)                        , --: in  std_logic                             ;
                DUMP_STARTDLY_IN        => DUMP_STARTDLY_IN                         , --: in  std_logic_vector(11 downto 0)         ;
                DUMP_START_IN           => DUMP_START_IN                            , --: in  std_logic                             ;
                DUMP_BUF_SEL_IN         => DUMP_BUF_SEL_IN(I)                       , --: in  std_logic                             ;
    
                SAMPLE_FSDLY_OUT        => sample_fs_dly(I)                           --: out std_logic
                );
            end generate;

            G_PATTERN_GENERATOR_BUFFER_1 : if (I = 0) generate
            begin
                U_BUFFER_WRAPPER : BUFFER_WRAPPER 
                generic map(
                FIXED_PTN_USAGE     => FIXED_PTN_USAGE                          ,
                POLY_PHASE_USAGE    => FALSE
            )
                port map(
                RST                 => RST_DUMP(I)                              ,
                CLK_CPU             => CLK_CPU                                  , 
                CLK_DUMP            => CLK_DUMP0                                , 
                
                DUMP_BUF_SEL_IN     => DUMP_BUF_SEL_IN(I)                       , 
                DUMP_START_IN       => DUMP_START_IN                            , 
                
                FS_DLY_IN           => fs_dly(I)                                , 
                DUMPDONE_OUT        => dump_done(I)                             ,

                FIXED_PTN_VALID_IN  => test_ptn_valid(I)(0)                     ,
                FIXED_PTN_GEN_EN_IN => FIXED_PTN_GEN_EN_IN                      , 
                FIXED_PTN_START_IN  => FIXED_PTN_START_IN                       , 
                FIXED_PTN_LENGTH_IN => FIXED_PTN_LENGTH_IN                      ,
                PHASE_SEL_IN        => PHASE_SEL_IN                             ,

                TEST_PTN_VALID_OUT  => TEST_PTN_VALID_OUT(I)                    ,
                GEN_RDATA_OUT       => i_fixed_ptn_data(I)                      ,

                DUMP_WRVAL_IN       => dump_wrval(I)(0)                         , 
                DUMP_WRDATA_IN      => dump_wrdata(I)                           , 
                DUMP_ODD_WRDATA_IN  => (others => '0')                          , 
                                
                RDATA_MEMORY_SEL_IN => i_rdata_mem_sel_n                        ,
                WREN_CPU_IN         => WREN_CPU_IN                              , 
                RDEN_CPU_IN         => RDEN_CPU_IN                              , 
                WDATA_CPU_IN        => WDATA_CPU_IN                             , 
                ADDRL13B_IN         => ADDRL13B                                 , 
                RDATA_CPU_OUT       => rdata(I)  
                );

            end generate;

            G_PATTERN_GENERATOR_BUFFER_2 : if (I = 1) generate 
            begin
                U_BUFFER_WRAPPER : BUFFER_WRAPPER 
                generic map(
                FIXED_PTN_USAGE     => FIXED_PTN_USAGE                          ,
                POLY_PHASE_USAGE    => FALSE
                )
                port map(
                RST                 => RST_DUMP(I)                              ,
                CLK_CPU             => CLK_CPU                                  ,
                CLK_DUMP            => CLK_DUMP1                                ,
                
                DUMP_BUF_SEL_IN     => DUMP_BUF_SEL_IN(I)                       ,
                DUMP_START_IN       => DUMP_START_IN                            ,
                
                FS_DLY_IN           => fs_dly(I)                                ,
                DUMPDONE_OUT        => dump_done(I)                             ,

                FIXED_PTN_VALID_IN  => test_ptn_valid(I)(0)                     ,
                FIXED_PTN_GEN_EN_IN => FIXED_PTN_GEN_EN_IN                      ,
                FIXED_PTN_START_IN  => FIXED_PTN_START_IN                       ,
                FIXED_PTN_LENGTH_IN => FIXED_PTN_LENGTH_IN                      ,
                PHASE_SEL_IN        => PHASE_SEL_IN                             ,
                                                         
                TEST_PTN_VALID_OUT  => TEST_PTN_VALID_OUT(I)                    ,
                GEN_RDATA_OUT       => i_fixed_ptn_data(I)                      ,

                DUMP_WRVAL_IN       => dump_wrval(I)(0)                         ,
                DUMP_WRDATA_IN      => dump_wrdata(I)                           ,
                DUMP_ODD_WRDATA_IN  => (others => '0')                          ,
                                
                RDATA_MEMORY_SEL_IN => i_rdata_mem_sel_n                        ,
                WREN_CPU_IN         => WREN_CPU_IN                              ,
                RDEN_CPU_IN         => RDEN_CPU_IN                              ,
                WDATA_CPU_IN        => WDATA_CPU_IN                             ,
                ADDRL13B_IN         => ADDRL13B                                 ,
                RDATA_CPU_OUT       => rdata(I)                                  
                );

            end generate;

            P_DumpDone_DC : process(RST_MISC, CLK_CPU) 
            begin
                if (RST_MISC = '1') then
                    dump_done_sh(I)     <= (others => '0');
                    dump_done_2nd_sh(I) <= (others => '0');
                elsif (CLK_CPU'event) and (CLK_CPU = '1') then
                    dump_done_sh(I)     <= dump_done_sh(I)(1 downto 0)     & dump_done(I);
                    dump_done_2nd_sh(I) <= dump_done_2nd_sh(I)(1 downto 0) & dump_done_2nd(I);
                end if;
            end process;

        end generate;

        G_STARTOFFSET_n_BUFFER_of_DualDump : if (DUAL_DUMP_USAGE = TRUE) generate
        begin  -- If there is Resampler , Dual Dump support only 307.2 clk domain block
            U_STARTOFFSET_WRAPPER_DualDump : STARTOFFSET_WRAPPER
            port map(
            RST                     => RST_DUMP(1)                              , --: in  std_logic                             ;
            CLK                     => CLK_DUMP1                                , --: in  std_logic                             ;
    
            FS_IN                   => dump_wrstrb_2nd(1)(0)                    , --: in  std_logic                             ;
            DUMP_STARTDLY_IN        => DUMP_STARTDLY_2ND_IN                     , --: in  std_logic_vector(11 downto 0)         ;
            DUMP_START_IN           => DUMP_START_IN                            , --: in  std_logic                             ;
            DUMP_BUF_SEL_IN         => DUMP_BUF_SEL_2ND_IN(1)                   , --: in  std_logic                             ;
    
            SAMPLE_FSDLY_OUT        => sample_fs_dly_2nd(1)                       --: out std_logic
            );

            U_BUFFER_WRAPPER_DualDump : BUFFER_WRAPPER
            generic map(
            FIXED_PTN_USAGE         => FALSE                                    , --: boolean 
            POLY_PHASE_USAGE        => FALSE                                      --: boolean 
            )
            port map(
            RST                     => RST_DUMP(1)                              , --: in  std_logic                             ;                    
            CLK_CPU                 => CLK_CPU                                  , --: in  std_logic                             ;
            CLK_DUMP                => CLK_DUMP1                                , --: in  std_logic                             ;                    
    
            DUMP_BUF_SEL_IN         => DUMP_BUF_SEL_2ND_IN(1)                   , --: in  std_logic                             ;                    
            DUMP_START_IN           => DUMP_START_IN                            , --: in  std_logic                             ;                    
    
            FS_DLY_IN               => fs_dly_2nd(1)                            , --: in  std_logic                             ;                    
            DUMPDONE_OUT            => dump_done_2nd(1)                         , --: out std_logic                             ;

            FIXED_PTN_VALID_IN      => '0'                                      , --: in  std_logic_vector( 0 downto 0)         ;
            FIXED_PTN_GEN_EN_IN     => '0'                                      , --: in  std_logic                             ;
            FIXED_PTN_START_IN      => '0'                                      , --: in  std_logic                             ;
            FIXED_PTN_LENGTH_IN     => (others => '0')                          , --: in  std_logic_vector(12 downto 0)         ;
            PHASE_SEL_IN            => '0'                                      , --: in  std_logic                             ;
    
            TEST_PTN_VALID_OUT      => open                                     , --: out std_logic                             ;
            GEN_RDATA_OUT           => open                                     , --: out std_logic_vector(31 downto 0)         ;

            DUMP_WRVAL_IN           => dump_wrval_2nd(1)(0)                     , --: in  std_logic_vector( 0 downto 0)         ;
            DUMP_WRDATA_IN          => dump_wrdata_2nd(1)                       , --: in  std_logic_vector(31 downto 0)         ;
            DUMP_ODD_WRDATA_IN      => (others => '0')                          , --: in  std_logic_vector(31 downto 0)         ;
                
            RDATA_MEMORY_SEL_IN     => i_rdata_mem_sel_p                        , --: in  std_logic                             ;
            WREN_CPU_IN             => WREN_CPU_IN                              , --: in  std_logic                             ;
            RDEN_CPU_IN             => RDEN_CPU_IN                              , --: in  std_logic                             ;                    
            WDATA_CPU_IN            => WDATA_CPU_IN                             , --: in  std_logic_vector(31 downto 0)         ;
            ADDRL13B_IN             => ADDRL13B                                 , --: in  std_logic_vector(12 downto 0)         ;
            RDATA_CPU_OUT           => rdata_2nd(1)                               --: out std_logic_vector(31 downto 0)
            );
        end generate;

        G_SA_GENERATE : if (SA_USAGE = TRUE) generate
        begin

            U_SA_FUNCTION : SA_WRAPPER
            port map(
            RST                     => RST_DUMP(1)                              , --: in  std_logic                             ;
            CLK_SA                  => CLK_DUMP1                                , --: in  std_logic                             ;
    
            FS_IN                   => dump_wrstrb(1)(0)                        , --: in  std_logic                             ;
    
            TXSA_CLKDLYVALUE_IN     => TXSA_CLKDLYVALUE_IN                      , --: in  std_logic_vector(23 downto 0)         ; 
            
            DUMP_BUF_SEL_IN         => DUMP_BUF_SEL_IN(1)                       , --: in  std_logic                             ; 
            DUMP_START_IN           => DUMP_START_IN                            , --: in  std_logic                             ; 
            SA_ENB_IN               => TXSA_ENB_IN                              , --: in  std_logic                             ; 
            DUMPDONE_IN             => dump_done(1)                             , --: in  std_logic                             ; 
    
            FB_SW_CNT_INFO_IN       => FB_SW_CNT_INFO_IN                        , --: in  std_logic_vector(1 downto 0)          ;
            FBSW_CNT_IN             => FBSW_CNT_IN                              , --: in  std_logic_vector(5 downto 0)          ; 
            AUTO_MODE_DONE_IN       => AUTO_MODE_DONE_IN                        , --: in  std_logic                             ; 
            SSB_EXIST_IN            => SSB_EXIST_IN                             , --: in  std_logic                             ;
            FBSW_MANUAL_IN          => FBSW_MANUAL_IN                           , --: in  std_logic                             ;
    
            CLK_FS_DLY_OUT          => clk_fs_dly                                 --: out std_logic                             ;
    
            );

            G_SA_of_DualDump : if (DUAL_DUMP_USAGE = TRUE) generate
            begin
                U_SA_DualDump : SA_WRAPPER
                port map(
                RST                 => RST_DUMP(1)                              , --: in  std_logic                             ;
                CLK_SA              => CLK_DUMP1                                , --: in  std_logic                             ;
    
                FS_IN               => dump_wrstrb_2nd(1)(0)                    , --: in  std_logic                             ;
    
                TXSA_CLKDLYVALUE_IN => TXSA_CLKDLYVALUE_2ND_IN                  , --: in  std_logic_vector(23 downto 0)         ; 
                
                DUMP_BUF_SEL_IN     => DUMP_BUF_SEL_2ND_IN(1)                   , --: in  std_logic                             ; 
                DUMP_START_IN       => DUMP_START_IN                            , --: in  std_logic                             ; 
                SA_ENB_IN           => TXSA_ENB_2ND_IN                          , --: in  std_logic                             ; 
                DUMPDONE_IN         => dump_done_2nd(1)                         , --: in  std_logic                             ; 
    
                FB_SW_CNT_INFO_IN   => FB_SW_CNT_INFO_2ND_IN                    , --: in  std_logic_vector(1 downto 0)          ;
                FBSW_CNT_IN         => FBSW_CNT_IN                              , --: in  std_logic_vector(5 downto 0)          ; 
                AUTO_MODE_DONE_IN   => AUTO_MODE_DONE_IN                        , --: in  std_logic                             ; 
                SSB_EXIST_IN        => SSB_EXIST_IN                             , --: in  std_logic                             ;
                FBSW_MANUAL_IN      => FBSW_MANUAL_IN                           , --: in  std_logic                             ;
    
                CLK_FS_DLY_OUT      => clk_fs_dly_2nd                             --: out std_logic                             ;
                );
            end generate;

            fs_dly(0)               <= sample_fs_dly(0);
            fs_dly_2nd(0)           <= sample_fs_dly_2nd(0);

            P_MODE_SWITCH1 : process(RST_DUMP(1), CLK_DUMP1) 
            begin
                if (RST_DUMP(1) = '1') then
                    fs_dly(1)       <= '0';
                    fs_dly_2nd(1)   <= '0';
                elsif (CLK_DUMP1'event) and (CLK_DUMP1 = '1') then

                    if (sa_en_sh(2) = '1') then
                        fs_dly(1)   <= clk_fs_dly;
                    else
                        fs_dly(1)   <= sample_fs_dly(1);
                    end if;

                    if (sa_en_sh_2nd(2) = '1') then
                        fs_dly_2nd(1)<= clk_fs_dly_2nd;
                    else
                        fs_dly_2nd(1)<= sample_fs_dly_2nd(1);
                    end if;

                end if;
            end process;

            P_DC : process(RST_DUMP(1), CLK_DUMP1) 
            begin
                if (RST_DUMP(1) = '1') then
                    sa_en_sh        <= (others => '0');
                    sa_en_sh_2nd    <= (others => '0');
                elsif (CLK_DUMP1'event) and (CLK_DUMP1 = '1') then
                    sa_en_sh        <= sa_en_sh(1 downto 0)     & TXSA_ENB_IN;
                    sa_en_sh_2nd    <= sa_en_sh_2nd(1 downto 0) & TXSA_ENB_2ND_IN;
                end if;
            end process;

        end generate;

        G_SA_NON_GENERATE : if (SA_USAGE = FALSE) generate
        begin
            fs_dly(0)               <= sample_fs_dly(0);
            fs_dly(1)               <= sample_fs_dly(1);
            fs_dly_2nd(0)           <= sample_fs_dly_2nd(0);
            fs_dly_2nd(1)           <= sample_fs_dly_2nd(1);
        end generate;

    end generate;
    
    ---------------------------------------------------------------------------------------------
    -- DMA interface READ Data Process
    ---------------------------------------------------------------------------------------------
    G_DMA_Interface_1_domain : if (DUMP_BUF_NUM = 1) generate
        DMA_RDEN_DC0 : process(RST_DUMP(0), CLK_DUMP0)
        begin
            if RST_DUMP(0) = '1' then
                dma_rden_dc(0)          <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                dma_rden_dc(0)          <= dma_rden_dc(0)(1 downto 0) & DMA_RDEN_IN;
            end if;
        end process;

        DMA_READ_BLOCK_SEL_CDC0 : process(RST_DUMP(0), CLK_DUMP0)
        begin
            if RST_DUMP(0) = '1' then
                dma_rd_blk_sel(0)       <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if (dma_rden_dc(0)(2) = '0') and (dma_rden_dc(0)(1) = '1') then
                    dma_rd_blk_sel(0)   <= DMA_READ_BLK_SEL_IN;
                else
                    dma_rd_blk_sel(0)   <= dma_rd_blk_sel(0);
                end if;
            end if;
        end process;
        
        DMA_PTN_DISTRIBUTE0 : process(RST_DUMP(0), CLK_DUMP0) 
        begin
            if RST_DUMP(0) = '1' then
                dma_read_ptn_cpriphy <= (others => (others => '0'));
                dma_read_ptn_cpri    <= (others => (others => '0'));
                dma_read_ptn_bbctrl  <= (others => (others => '0'));
                dma_read_ptn_dsp     <= (others => (others => '0'));
                dma_read_ptn_dcif    <= (others => (others => '0'));
                dma_read_ptn_sbif    <= (others => (others => '0'));
                dma_read_ptn_sbifphy <= (others => (others => '0'));
            elsif rising_edge(CLK_DUMP0) then
                case (dma_rd_blk_sel(0)) is
                    when  x"10"     =>  dma_read_ptn_cpriphy(0) <= i_dma_read_ptn(0);
                    when  x"11"     =>  dma_read_ptn_cpriphy(1) <= i_dma_read_ptn(0);
                    when  x"20"     =>  dma_read_ptn_cpri(0)    <= i_dma_read_ptn(0);
                    when  x"21"     =>  dma_read_ptn_cpri(1)    <= i_dma_read_ptn(0);
                    when  x"30"     =>  dma_read_ptn_bbctrl(0)  <= i_dma_read_ptn(0);
                    when  x"31"     =>  dma_read_ptn_bbctrl(1)  <= i_dma_read_ptn(0);
                    when  x"40"     =>  dma_read_ptn_dsp(0)     <= i_dma_read_ptn(0);
                    when  x"41"     =>  dma_read_ptn_dsp(1)     <= i_dma_read_ptn(0);
                    when  x"50"     =>  dma_read_ptn_dcif(0)    <= i_dma_read_ptn(0);
                    when  x"51"     =>  dma_read_ptn_dcif(1)    <= i_dma_read_ptn(0);
                    when  x"60"     =>  dma_read_ptn_sbif(0)    <= i_dma_read_ptn(0);
                    when  x"61"     =>  dma_read_ptn_sbif(1)    <= i_dma_read_ptn(0);
                    when  x"70"     =>  dma_read_ptn_sbifphy(0) <= i_dma_read_ptn(0);
                    when  x"71"     =>  dma_read_ptn_sbifphy(1) <= i_dma_read_ptn(0);
                    when others     =>  dma_read_ptn_cpriphy    <= (others => (others => '0'));
                                        dma_read_ptn_cpri       <= (others => (others => '0'));
                                        dma_read_ptn_bbctrl     <= (others => (others => '0'));
                                        dma_read_ptn_dsp        <= (others => (others => '0'));
                                        dma_read_ptn_dcif       <= (others => (others => '0'));
                                        dma_read_ptn_sbif       <= (others => (others => '0'));
                                        dma_read_ptn_sbifphy    <= (others => (others => '0'));
                end case;
            end if;
        end process;
    end generate;
    G_DMA_Interface_2_domain : if (DUMP_BUF_NUM = 2) generate
    DMA_RDEN_DC0 : process(RST_DUMP(0), CLK_DUMP0)
    begin
        if RST_DUMP(0) = '1' then
            dma_rden_dc(0)          <= (others => '0');
        elsif rising_edge(CLK_DUMP0) then
            dma_rden_dc(0)          <= dma_rden_dc(0)(1 downto 0) & DMA_RDEN_IN;
        end if;
    end process;

    DMA_READ_BLOCK_SEL_CDC0 : process(RST_DUMP(0), CLK_DUMP0)
    begin
        if RST_DUMP(0) = '1' then
            dma_rd_blk_sel(0)       <= (others => '0');
        elsif rising_edge(CLK_DUMP0) then
            if (dma_rden_dc(0)(2) = '0') and (dma_rden_dc(0)(1) = '1') then
                dma_rd_blk_sel(0)   <= DMA_READ_BLK_SEL_IN;
            else
                dma_rd_blk_sel(0)   <= dma_rd_blk_sel(0);
            end if;
        end if;
    end process;

    DMA_RDEN_DC1: process(RST_DUMP(1), CLK_DUMP1)
    begin
        if RST_DUMP(1) = '1' then
            dma_rden_dc(1)          <= (others => '0');
        elsif rising_edge(CLK_DUMP1) then
            dma_rden_dc(1)          <= dma_rden_dc(1)(1 downto 0) & DMA_RDEN_IN;
        end if;
    end process;

    DMA_READ_BLOCK_SEL_CDC1 : process(RST_DUMP(1), CLK_DUMP1)
    begin
        if RST_DUMP(1) = '1' then
            dma_rd_blk_sel(1)       <= (others => '0');
        elsif rising_edge(CLK_DUMP1) then
            if (dma_rden_dc(1)(2) = '0') and (dma_rden_dc(1)(1) = '1') then
                dma_rd_blk_sel(1)   <= DMA_READ_BLK_SEL_IN;
            else
                dma_rd_blk_sel(1)   <= dma_rd_blk_sel(1);
            end if;
        end if;
    end process;

    DMA_PTN_DISTRIBUTE0 : process(RST_DUMP(0), CLK_DUMP0) 
    begin
        if RST_DUMP(0) = '1' then
            dma_read_ptn_cpriphy(0) <= (others => '0');
            dma_read_ptn_cpri(0)    <= (others => '0');
            dma_read_ptn_bbctrl(0)  <= (others => '0');
            dma_read_ptn_dsp(0)     <= (others => '0');
            dma_read_ptn_dcif(0)    <= (others => '0');
            dma_read_ptn_sbif(0)    <= (others => '0');
            dma_read_ptn_sbifphy(0) <= (others => '0');
        elsif rising_edge(CLK_DUMP0) then
            case (dma_rd_blk_sel(0)) is
                when  x"10"         =>  dma_read_ptn_cpriphy(0) <= i_dma_read_ptn(0);
                when  x"20"         =>  dma_read_ptn_cpri(0)    <= i_dma_read_ptn(0);
                when  x"30"         =>  dma_read_ptn_bbctrl(0)  <= i_dma_read_ptn(0);
                when  x"40"         =>  dma_read_ptn_dsp(0)     <= i_dma_read_ptn(0);
                when  x"50"         =>  dma_read_ptn_dcif(0)    <= i_dma_read_ptn(0);
                when  x"60"         =>  dma_read_ptn_sbif(0)    <= i_dma_read_ptn(0);
                when  x"70"         =>  dma_read_ptn_sbifphy(0) <= i_dma_read_ptn(0);

                when others         =>  dma_read_ptn_cpriphy(0) <= (others => '0');
                                        dma_read_ptn_cpri(0)    <= (others => '0');
                                        dma_read_ptn_bbctrl(0)  <= (others => '0');
                                        dma_read_ptn_dsp(0)     <= (others => '0');
                                        dma_read_ptn_dcif(0)    <= (others => '0');
                                        dma_read_ptn_sbif(0)    <= (others => '0');
                                        dma_read_ptn_sbifphy(0) <= (others => '0');
            end case;
        end if;
    end process;

    DMA_PTN_DISTRIBUTE1 : process(RST_DUMP(1), CLK_DUMP1) 
    begin
        if RST_DUMP(1) = '1' then
            dma_read_ptn_cpriphy(1) <= (others => '0');
            dma_read_ptn_cpri(1)    <= (others => '0');
            dma_read_ptn_bbctrl(1)  <= (others => '0');
            dma_read_ptn_dsp(1)     <= (others => '0');
            dma_read_ptn_dcif(1)    <= (others => '0');
            dma_read_ptn_sbif(1)    <= (others => '0');
            dma_read_ptn_sbifphy(1) <= (others => '0');
        elsif rising_edge(CLK_DUMP1) then
            case (dma_rd_blk_sel(1)) is
                when  x"11"         =>  dma_read_ptn_cpriphy(1) <= i_dma_read_ptn(1);
                when  x"21"         =>  dma_read_ptn_cpri(1)    <= i_dma_read_ptn(1);
                when  x"31"         =>  dma_read_ptn_bbctrl(1)  <= i_dma_read_ptn(1);
                when  x"41"         =>  dma_read_ptn_dsp(1)     <= i_dma_read_ptn(1);
                when  x"51"         =>  dma_read_ptn_dcif(1)    <= i_dma_read_ptn(1);
                when  x"61"         =>  dma_read_ptn_sbif(1)    <= i_dma_read_ptn(1);
                when  x"71"         =>  dma_read_ptn_sbifphy(1) <= i_dma_read_ptn(1);
                when others         =>  dma_read_ptn_cpriphy(1) <= (others => '0');
                                        dma_read_ptn_cpri(1)    <= (others => '0');
                                        dma_read_ptn_bbctrl(1)  <= (others => '0');
                                        dma_read_ptn_dsp(1)     <= (others => '0');
                                        dma_read_ptn_dcif(1)    <= (others => '0');
                                        dma_read_ptn_sbif(1)    <= (others => '0');
                                        dma_read_ptn_sbifphy(1) <= (others => '0');
            end case;
        end if;
    end process;

    end generate;
    ---------------------------------------------------------------------------------------------
    -- Fixed Pattern Genarated Data Process
    ---------------------------------------------------------------------------------------------
    G_FIXED_PTN_SELECTION_1_domain : if (DUMP_BUF_NUM = 1) generate

        FIXED_PTN_START_DC0 : process(RST_DUMP(0), CLK_DUMP0)
        begin
            if RST_DUMP(0) = '1' then
                fixed_ptn_start_dc(0)   <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                fixed_ptn_start_dc(0)   <= fixed_ptn_start_dc(0)(1 downto 0) & FIXED_PTN_START_IN;
            end if;
        end process;

        FIXED_PTN_BLOCK_SEL_CDC0 : process(RST_DUMP(0), CLK_DUMP0)
        begin
            if RST_DUMP(0) = '1' then
                fixed_ptn_blk_sel(0)    <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if (fixed_ptn_start_dc(0)(2) = '0') and (fixed_ptn_start_dc(0)(1) = '1') then
                    fixed_ptn_blk_sel(0)<= FIXED_PTN_BLK_SEL_IN;
                else
                    fixed_ptn_blk_sel(0)<= fixed_ptn_blk_sel(0);
                end if;
            end if;
        end process;

        TEST_PTN_DISTRIBUTE0 : process(RST_DUMP(0), CLK_DUMP0) 
        begin
            if RST_DUMP(0) = '1' then
                fixed_ptn_cpriphy   <= (others => (others => '0'));
                fixed_ptn_cpri      <= (others => (others => '0'));
                fixed_ptn_bbctrl    <= (others => (others => '0'));
                fixed_ptn_dsp       <= (others => (others => '0'));
                fixed_ptn_dcif      <= (others => (others => '0'));
                fixed_ptn_sbif      <= (others => (others => '0'));
                fixed_ptn_sbifphy   <= (others => (others => '0'));
            elsif rising_edge(CLK_DUMP0) then
                case (fixed_ptn_blk_sel(0)) is
                    when  x"10"     => fixed_ptn_cpriphy(0) <= i_fixed_ptn_data(0);
                    when  x"11"     => fixed_ptn_cpriphy(1) <= i_fixed_ptn_data(0);
                    when  x"20"     => fixed_ptn_cpri(0)    <= i_fixed_ptn_data(0);
                    when  x"21"     => fixed_ptn_cpri(1)    <= i_fixed_ptn_data(0);
                    when  x"30"     => fixed_ptn_bbctrl(0)  <= i_fixed_ptn_data(0);
                    when  x"31"     => fixed_ptn_bbctrl(1)  <= i_fixed_ptn_data(0);
                    when  x"40"     => fixed_ptn_dsp(0)     <= i_fixed_ptn_data(0);
                    when  x"41"     => fixed_ptn_dsp(1)     <= i_fixed_ptn_data(0);
                    when  x"50"     => fixed_ptn_dcif(0)    <= i_fixed_ptn_data(0);
                    when  x"51"     => fixed_ptn_dcif(1)    <= i_fixed_ptn_data(0);
                    when  x"60"     => fixed_ptn_sbif(0)    <= i_fixed_ptn_data(0);
                    when  x"61"     => fixed_ptn_sbif(1)    <= i_fixed_ptn_data(0);
                    when  x"70"     => fixed_ptn_sbifphy(0) <= i_fixed_ptn_data(0);
                    when  x"71"     => fixed_ptn_sbifphy(1) <= i_fixed_ptn_data(0);

                    when others     => fixed_ptn_cpriphy <= (others => (others => '0'));
                                       fixed_ptn_cpri    <= (others => (others => '0'));
                                       fixed_ptn_bbctrl  <= (others => (others => '0'));
                                       fixed_ptn_dsp     <= (others => (others => '0'));
                                       fixed_ptn_dcif    <= (others => (others => '0'));
                                       fixed_ptn_sbif    <= (others => (others => '0'));
                                       fixed_ptn_sbifphy <= (others => (others => '0'));
                end case;
            end if;
        end process;
    end generate;

    G_FIXED_PTN_SELECTION_2_domain : if (DUMP_BUF_NUM = 2) generate

        FIXED_PTN_START_DC0 : process(RST_DUMP(0), CLK_DUMP0)
        begin
            if RST_DUMP(0) = '1' then
                fixed_ptn_start_dc(0)   <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                fixed_ptn_start_dc(0)   <= fixed_ptn_start_dc(0)(1 downto 0) & FIXED_PTN_START_IN;
            end if;
        end process;

        FIXED_PTN_BLOCK_SEL_CDC0 : process(RST_DUMP(0), CLK_DUMP0)
        begin
            if RST_DUMP(0) = '1' then
                fixed_ptn_blk_sel(0)    <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if (fixed_ptn_start_dc(0)(2) = '0') and (fixed_ptn_start_dc(0)(1) = '1') then
                    fixed_ptn_blk_sel(0)<= FIXED_PTN_BLK_SEL_IN;
                else
                    fixed_ptn_blk_sel(0)<= fixed_ptn_blk_sel(0);
                end if;
            end if;
        end process;

        FIXED_PTN_START_DC1: process(RST_DUMP(1), CLK_DUMP1)
        begin
            if RST_DUMP(1) = '1' then
                fixed_ptn_start_dc(1)   <= (others => '0');
            elsif rising_edge(CLK_DUMP1) then
                fixed_ptn_start_dc(1)   <= fixed_ptn_start_dc(1)(1 downto 0) & FIXED_PTN_START_IN;
            end if;
        end process;

        FIXED_PTN_BLOCK_SEL_CDC1 : process(RST_DUMP(1), CLK_DUMP1)
        begin
            if RST_DUMP(1) = '1' then
                fixed_ptn_blk_sel(1)    <= (others => '0');
            elsif rising_edge(CLK_DUMP1) then
                if (fixed_ptn_start_dc(1)(2) = '0') and (fixed_ptn_start_dc(1)(1) = '1') then
                    fixed_ptn_blk_sel(1)<= FIXED_PTN_BLK_SEL_IN;
                else
                    fixed_ptn_blk_sel(1)<= fixed_ptn_blk_sel(1);
                end if;
            end if;
        end process;

        TEST_PTN_DISTRIBUTE0 : process(RST_DUMP(0), CLK_DUMP0) 
        begin
            if RST_DUMP(0) = '1' then
                fixed_ptn_cpriphy(0)    <= (others => '0');
                fixed_ptn_cpri(0)       <= (others => '0');
                fixed_ptn_bbctrl(0)     <= (others => '0');
                fixed_ptn_dsp(0)        <= (others => '0');
                fixed_ptn_dcif(0)       <= (others => '0');
                fixed_ptn_sbif(0)       <= (others => '0');
                fixed_ptn_sbifphy(0)    <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                case (fixed_ptn_blk_sel(0)) is
                    when  x"10"         => fixed_ptn_cpriphy(0) <= i_fixed_ptn_data(0);
                    when  x"20"         => fixed_ptn_cpri(0)    <= i_fixed_ptn_data(0);
                    when  x"30"         => fixed_ptn_bbctrl(0)  <= i_fixed_ptn_data(0);
                    when  x"40"         => fixed_ptn_dsp(0)     <= i_fixed_ptn_data(0);
                    when  x"50"         => fixed_ptn_dcif(0)    <= i_fixed_ptn_data(0);
                    when  x"60"         => fixed_ptn_sbif(0)    <= i_fixed_ptn_data(0);
                    when  x"70"         => fixed_ptn_sbifphy(0) <= i_fixed_ptn_data(0);

                    when others         => fixed_ptn_cpriphy(0) <= (others => '0');
                                           fixed_ptn_cpri(0)    <= (others => '0');
                                           fixed_ptn_bbctrl(0)  <= (others => '0');
                                           fixed_ptn_dsp(0)     <= (others => '0');
                                           fixed_ptn_dcif(0)    <= (others => '0');
                                           fixed_ptn_sbif(0)    <= (others => '0');
                                           fixed_ptn_sbifphy(0) <= (others => '0');
                end case;
            end if;
        end process;

        TEST_PTN_DISTRIBUTE1 : process(RST_DUMP(1), CLK_DUMP1) 
        begin
            if RST_DUMP(1) = '1' then
                fixed_ptn_cpriphy(1)    <= (others => '0');
                fixed_ptn_cpri(1)       <= (others => '0');
                fixed_ptn_bbctrl(1)     <= (others => '0');
                fixed_ptn_dsp(1)        <= (others => '0');
                fixed_ptn_dcif(1)       <= (others => '0');
                fixed_ptn_sbif(1)       <= (others => '0');
                fixed_ptn_sbifphy(1)    <= (others => '0');
            elsif rising_edge(CLK_DUMP1) then
                case (fixed_ptn_blk_sel(1)) is
                    when  x"11"         => fixed_ptn_cpriphy(1) <= i_fixed_ptn_data(1);
                    when  x"21"         => fixed_ptn_cpri(1)    <= i_fixed_ptn_data(1);
                    when  x"31"         => fixed_ptn_bbctrl(1)  <= i_fixed_ptn_data(1);
                    when  x"41"         => fixed_ptn_dsp(1)     <= i_fixed_ptn_data(1);
                    when  x"51"         => fixed_ptn_dcif(1)    <= i_fixed_ptn_data(1);
                    when  x"61"         => fixed_ptn_sbif(1)    <= i_fixed_ptn_data(1);
                    when  x"71"         => fixed_ptn_sbifphy(1) <= i_fixed_ptn_data(1);

                    when others         => fixed_ptn_cpriphy(1) <= (others => '0');
                                           fixed_ptn_cpri(1)    <= (others => '0');
                                           fixed_ptn_bbctrl(1)  <= (others => '0');
                                           fixed_ptn_dsp(1)     <= (others => '0');
                                           fixed_ptn_dcif(1)    <= (others => '0');
                                           fixed_ptn_sbif(1)    <= (others => '0');
                                           fixed_ptn_sbifphy(1) <= (others => '0');
                end case;
            end if;
        end process;

    end generate;
----------------------------------------------------------------------------------------------------------------
    -- Pattern Selection Process
----------------------------------------------------------------------------------------------------------------
    ------------------------------------------------------------------------------------------------------------
    -- Case 1) DUMP_BUF_NUM = 1
    ------------------------------------------------------------------------------------------------------------
    G_Pattern_Selection_1_Domain : if (DUMP_BUF_NUM = 1) generate
        TEST_PTN_SEL_DC0 : process(RST_DUMP(0), CLK_DUMP0)
        begin
            if RST_DUMP(0) = '1' then
                test_ptn_sel_strb(0)    <= (others => '0');
                test_ptn_sel_strb_dc(0) <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                test_ptn_sel_strb(0)(0) <= DMA_RDEN_IN or FIXED_PTN_START_IN;
                test_ptn_sel_strb_dc(0) <= test_ptn_sel_strb_dc(0)(1 downto 0) & test_ptn_sel_strb(0);
            end if;
        end process;

        TEST_PTN_BLOCK_SEL_CDC0 : process(RST_DUMP(0), CLK_DUMP0)
        begin
            if RST_DUMP(0) = '1' then
                test_ptn_sel(0)       <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if (test_ptn_sel_strb_dc(0)(2) = '0') and (test_ptn_sel_strb_dc(0)(1) = '1') then
                    test_ptn_sel(0)   <= TEST_PTN_SEL_IN;
                else
                    test_ptn_sel(0)   <= test_ptn_sel(0);
                end if;
            end if;
        end process;

        PATTERN_SELECTION0 : process(RST_DUMP(0), CLK_DUMP0) 
        begin
            if RST_DUMP(0) = '1' then
                test_ptn_cpriphy     <= (others => (others => '0')); 
                test_ptn_cpri        <= (others => (others => '0'));
                test_ptn_bbctrl      <= (others => (others => '0'));
                test_ptn_dsp         <= (others => (others => '0'));
                test_ptn_dcif        <= (others => (others => '0')); 
                test_ptn_sbif        <= (others => (others => '0')); 
                test_ptn_sbifphy     <= (others => (others => '0')); 
            elsif rising_edge(CLK_DUMP0) then
                if (test_ptn_sel(0) = "01") then
                    test_ptn_cpriphy <= fixed_ptn_cpriphy;
                    test_ptn_cpri    <= fixed_ptn_cpri;
                    test_ptn_bbctrl  <= fixed_ptn_bbctrl; 
                    test_ptn_dsp     <= fixed_ptn_dsp; 
                    test_ptn_dcif    <= fixed_ptn_dcif; 
                    test_ptn_sbif    <= fixed_ptn_sbif;
                    test_ptn_sbifphy <= fixed_ptn_sbifphy;
                elsif (test_ptn_sel(0) = "10") then
                    test_ptn_cpriphy <= dma_read_ptn_cpriphy;
                    test_ptn_cpri    <= dma_read_ptn_cpri;
                    test_ptn_bbctrl  <= dma_read_ptn_bbctrl; 
                    test_ptn_dsp     <= dma_read_ptn_dsp; 
                    test_ptn_dcif    <= dma_read_ptn_dcif; 
                    test_ptn_sbif    <= dma_read_ptn_sbif;
                    test_ptn_sbifphy <= dma_read_ptn_sbifphy;
                else
                    test_ptn_cpriphy <= (others => (others => '0')); 
                    test_ptn_cpri    <= (others => (others => '0')); 
                    test_ptn_bbctrl  <= (others => (others => '0')); 
                    test_ptn_dsp     <= (others => (others => '0'));
                    test_ptn_dcif    <= (others => (others => '0'));
                    test_ptn_sbif    <= (others => (others => '0')); 
                    test_ptn_sbifphy <= (others => (others => '0')); 
                end if;
            end if;
        end process;
    end generate;
    ------------------------------------------------------------------------------------------------------------
    -- Case 1) DUMP_BUF_NUM = 2
    ------------------------------------------------------------------------------------------------------------
    G_Pattern_Selection_2_Domain : if (DUMP_BUF_NUM = 2) generate

        TEST_PTN_SEL_DC0 : process(RST_DUMP(0), CLK_DUMP0)
        begin
            if RST_DUMP(0) = '1' then
                test_ptn_sel_strb(0)    <= (others => '0');
                test_ptn_sel_strb_dc(0) <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                test_ptn_sel_strb(0)(0) <= DMA_RDEN_IN or FIXED_PTN_START_IN;
                test_ptn_sel_strb_dc(0) <= test_ptn_sel_strb_dc(0)(1 downto 0) & test_ptn_sel_strb(0);
            end if;
        end process;

        TEST_PTN_SEL_DC1 : process(RST_DUMP(1), CLK_DUMP1)
        begin
            if RST_DUMP(1) = '1' then
                test_ptn_sel_strb(1)    <= (others => '0');
                test_ptn_sel_strb_dc(1) <= (others => '0');
            elsif rising_edge(CLK_DUMP1) then
                test_ptn_sel_strb(1)(0) <= DMA_RDEN_IN or FIXED_PTN_START_IN;
                test_ptn_sel_strb_dc(1) <= test_ptn_sel_strb_dc(1)(1 downto 0) & test_ptn_sel_strb(1);
            end if;
        end process;

        TEST_PTN_BLOCK_SEL_CDC0 : process(RST_DUMP(0), CLK_DUMP0)
        begin
            if RST_DUMP(0) = '1' then
                test_ptn_sel(0)       <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if (test_ptn_sel_strb_dc(0)(2) = '0') and (test_ptn_sel_strb_dc(0)(1) = '1') then
                        test_ptn_sel(0)   <= TEST_PTN_SEL_IN;
                else
                    test_ptn_sel(0)   <= test_ptn_sel(0);
                end if;
            end if;
        end process;

        TEST_PTN_BLOCK_SEL_CDC1 : process(RST_DUMP(1), CLK_DUMP1)
        begin
            if RST_DUMP(1) = '1' then
                test_ptn_sel(1)       <= (others => '0');
            elsif rising_edge(CLK_DUMP1) then
                if (test_ptn_sel_strb_dc(1)(2) = '0') and (test_ptn_sel_strb_dc(1)(1) = '1') then
                        test_ptn_sel(1)   <= TEST_PTN_SEL_IN;
                else
                    test_ptn_sel(1)   <= test_ptn_sel(1);
                end if;
            end if;
        end process;

        PATTERN_SELECTION0 : process(RST_DUMP(0), CLK_DUMP0) 
        begin
            if RST_DUMP(0) = '1' then
                test_ptn_cpriphy(0)     <= (others => '0');
                test_ptn_cpri(0)        <= (others => '0');
                test_ptn_bbctrl(0)      <= (others => '0');
                test_ptn_dsp(0)         <= (others => '0');
                test_ptn_dcif(0)        <= (others => '0');
                test_ptn_sbif(0)        <= (others => '0');
                test_ptn_sbifphy(0)     <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if (test_ptn_sel(0) = "01") then
                    test_ptn_cpriphy(0) <= fixed_ptn_cpriphy(0);
                    test_ptn_cpri(0)    <= fixed_ptn_cpri(0);
                    test_ptn_bbctrl(0)  <= fixed_ptn_bbctrl(0); 
                    test_ptn_dsp(0)     <= fixed_ptn_dsp(0); 
                    test_ptn_dcif(0)    <= fixed_ptn_dcif(0); 
                    test_ptn_sbif(0)    <= fixed_ptn_sbif(0);
                    test_ptn_sbifphy(0) <= fixed_ptn_sbifphy(0);
                elsif (test_ptn_sel(0) = "10") then
                    test_ptn_cpriphy(0) <= dma_read_ptn_cpriphy(0);
                    test_ptn_cpri(0)    <= dma_read_ptn_cpri(0);
                    test_ptn_bbctrl(0)  <= dma_read_ptn_bbctrl(0); 
                    test_ptn_dsp(0)     <= dma_read_ptn_dsp(0); 
                    test_ptn_dcif(0)    <= dma_read_ptn_dcif(0); 
                    test_ptn_sbif(0)    <= dma_read_ptn_sbif(0);
                    test_ptn_sbifphy(0) <= dma_read_ptn_sbifphy(0);
                else
                    test_ptn_cpriphy(0) <= (others => '0'); 
                    test_ptn_cpri(0)    <= (others => '0'); 
                    test_ptn_bbctrl(0)  <= (others => '0');
                    test_ptn_dsp(0)     <= (others => '0');
                    test_ptn_dcif(0)    <= (others => '0');
                    test_ptn_sbif(0)    <= (others => '0'); 
                    test_ptn_sbifphy(0) <= (others => '0'); 
                end if;
            end if;
        end process;

        PATTERN_SELECTION1 : process(RST_DUMP(1), CLK_DUMP1) 
        begin
            if RST_DUMP(1) = '1' then
                test_ptn_cpriphy(1)     <= (others => '0'); 
                test_ptn_cpri(1)        <= (others => '0'); 
                test_ptn_bbctrl(1)      <= (others => '0');
                test_ptn_dsp(1)         <= (others => '0');
                test_ptn_dcif(1)        <= (others => '0'); 
                test_ptn_sbif(1)        <= (others => '0'); 
                test_ptn_sbifphy(1)     <= (others => '0'); 
            elsif rising_edge(CLK_DUMP1) then
                if (test_ptn_sel(1) = "01") then
                    test_ptn_cpriphy(1) <= fixed_ptn_cpriphy(1);
                    test_ptn_cpri(1)    <= fixed_ptn_cpri(1);
                    test_ptn_bbctrl(1)  <= fixed_ptn_bbctrl(1);
                    test_ptn_dsp(1)     <= fixed_ptn_dsp(1); 
                    test_ptn_dcif(1)    <= fixed_ptn_dcif(1); 
                    test_ptn_sbif(1)    <= fixed_ptn_sbif(1);
                    test_ptn_sbifphy(1) <= fixed_ptn_sbifphy(1);
                elsif (test_ptn_sel(1) = "10") then
                    test_ptn_cpriphy(1) <= dma_read_ptn_cpriphy(1);
                    test_ptn_cpri(1)    <= dma_read_ptn_cpri(1);
                    test_ptn_bbctrl(1)  <= dma_read_ptn_bbctrl(1);
                    test_ptn_dsp(1)     <= dma_read_ptn_dsp(1); 
                    test_ptn_dcif(1)    <= dma_read_ptn_dcif(1); 
                    test_ptn_sbif(1)    <= dma_read_ptn_sbif(1);
                    test_ptn_sbifphy(1) <= dma_read_ptn_sbifphy(1);
                else
                    test_ptn_cpriphy(1) <= (others => '0'); 
                    test_ptn_cpri(1)    <= (others => '0'); 
                    test_ptn_sbif(1)    <= (others => '0'); 
                    test_ptn_sbifphy(1) <= (others => '0'); 
                end if;
            end if;
        end process;

    end generate;
    
    TEST_DATA_CPRIPHY_OUT           <= test_ptn_cpriphy;
    TEST_DATA_CPRI_OUT              <= test_ptn_cpri;
    TEST_DATA_BBCTRL_OUT            <= test_ptn_bbctrl;
    TEST_DATA_DSP_OUT               <= test_ptn_dsp;
    TEST_DATA_DCIF_OUT              <= test_ptn_dcif;
    TEST_DATA_SBIF_OUT              <= test_ptn_sbif;
    TEST_DATA_SBIFPHY_OUT           <= test_ptn_sbifphy;

    
end behave;
