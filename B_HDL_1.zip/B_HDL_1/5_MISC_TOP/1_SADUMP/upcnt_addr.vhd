library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity UPCNT_ADDR is
port(
    RST             : in std_logic                      ; -- RST           : Input Reset, Active high
    CLK             : in std_logic                      ; -- CLK           : Input Clock

    DUMPVAL_IN      : in std_logic_vector(1 downto 0)   ; -- DUMPVAL_IN    : DUMPVAL_IN signal
    WRVAL_SIG_IN    : in std_logic                      ; -- WRVAL_SIG_IN  : Write Valid signal
    DUMP_BUF_SEL_IN : in std_logic	                    ; -- DUMPBUFSEL_IN : Dump Buffer(#0~#1) Select signal

    WREN_OUT        : out std_logic                     ;
    ADDR_DUMP_OUT   : out std_logic_vector(12 downto 0)   -- ADDR_DUMP_OUT : For DUMP Address
    );
end UPCNT_ADDR;

architecture arc_UPCNT_ADDR of UPCNT_ADDR is

signal addr_dump    : std_logic_vector(12 downto 0)     ; -- addr_dump     : Address Dump
signal cnt_valid    : std_logic_vector(1 downto 0)      ; -- cnt_valid     : When insert first valid signal, address value is all zero.
signal wren         : std_logic                         ; -- wren_0        : Write Enable #0

attribute KEEP : string;
attribute KEEP of WRVAL_SIG_IN  : signal is "TRUE"; 

attribute MAX_FANOUT : integer;
attribute MAX_FANOUT of WRVAL_SIG_IN  : signal is 50; 


begin

    CNT_VALID_SIGNAL : process(RST, CLK)
    begin
        if (RST = '1') then
            cnt_valid <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (DUMPVAL_IN = 0) then
                cnt_valid <= (others => '0');
            elsif (DUMPVAL_IN = 1) then
                if (cnt_valid = 0) and (WRVAL_SIG_IN = '1') then
                    cnt_valid <= "01";
                elsif (cnt_valid = 1) and (WRVAL_SIG_IN = '1') then
                    cnt_valid <= "11";
                elsif (cnt_valid = 3) and (WRVAL_SIG_IN = '1') then
                    cnt_valid <= "10";
                else
                    cnt_valid <= cnt_valid;
                end if;
            else
                cnt_valid <= cnt_valid;
            end if;
        end if;
    end process;

    Up_Count_Address : process(RST, CLK)
    begin
        if (RST = '1') then
            addr_dump <= (others => '1');
        elsif (CLK'event) and (CLK = '1') then
            if (DUMP_BUF_SEL_IN = '1') then 
                if (DUMPVAL_IN = 1) then
                    if (cnt_valid = 1) then
                        addr_dump <= (others => '0');
                    elsif (cnt_valid = 2) then
                        if (WRVAL_SIG_IN = '1') then
                            if (addr_dump = 8191) then
                                addr_dump <= addr_dump;
                            else
                                addr_dump <= addr_dump + '1';
                            end if;
                        else
                            addr_dump <= addr_dump;
                        end if;
                    else
                        addr_dump <= addr_dump;
                    end if;
                else
                    addr_dump <= addr_dump;
                end if;
            else
                addr_dump <= (others => '1');
            end if;
        end if;
    end process;  

    ADDR_DUMP_OUT <= addr_dump;

    -- When dump done, set valid signal is zero
    CTRL_WRVAL_signal : process(RST, CLK)
    begin
        if (RST = '1') then
            wren <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (addr_dump = 8191) then
            	wren <= '0';
            else
                wren <= WRVAL_SIG_IN;
            end if;
        end if;
    end process;

    WREN_OUT <= wren;

end arc_UPCNT_ADDR;
