library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

--< Entity >--------------------------------------------------------------------
entity START_OFFSET is
----< Generic >----
--generic(
--    );
----< Port >----
port(
    --< RESET >--
    RST           : in std_logic;                                              -- RST : Reset, Active high

    --< Clock >--
    CLK           : in std_logic;                                              -- CLK : Input clock

    --< Time Information >--
    BFN_STROBE_IN : in std_logic;                                              -- BFN_STROBE_IN : sync 122.88MHz, Period 10ms, pulsewidth 3.84MHz

    --< CPU Offset >--
    DLYVALUE_IN   : in std_logic_vector(11 downto 0);                          -- DLYVALUE_IN   : Delay value

    FS_DLY_OUT    : out std_logic
    );
end START_OFFSET;

--< Architecture >-------------------------------------------------------------
architecture arc_START_OFFSET of START_OFFSET is

----< Signal >----
-- _f#  : #number clk delay signal by filp-flop or register
-- pls  : 1 clock pulse
-- rpls : 1 clock rising edge pulse
-- npls : 1 clock negative edge pulse
-- _lat : Latch signal

signal FS_IN_f                      : std_logic_vector(2 downto 0);
signal fs_rpls_f2                   : std_logic;

signal clk_cnt                      : std_logic_vector(12 downto 0);
signal pls_8k                       : std_logic;
signal clk_cnt_8k                   : std_logic_vector(11 downto 0);

signal fs_dly                       : std_logic;

----< Process >----
begin

    FS_Clocking : process(RST, CLK)
    begin
        if (RST = '1') then
            FS_IN_f                 <= (others => '0');
        elsif rising_edge(CLK) then
            FS_IN_f                 <= FS_IN_f(1 downto 0) & BFN_STROBE_IN;
        end if;
    end process;

    GEN_FS_pulse : process(RST, CLK)
    begin
        if (RST = '1') then
            fs_rpls_f2              <= '0';
        elsif rising_edge(CLK) then
            fs_rpls_f2              <= FS_IN_f(1) and (not FS_IN_f(2));
        end if;
    end process;

    CLK_COUNT : process(RST, CLK)
    begin
        if (RST = '1') then
            clk_cnt                 <= (others => '1');
        elsif rising_edge(CLK) then
            if (fs_rpls_f2 = '1') then
                clk_cnt             <= (others => '0');
            else
                clk_cnt             <= clk_cnt + '1';
            end if;
        end if;
    end process; 

    GEN_8k_Pulse : process(RST, CLK)
    begin
        if (RST = '1') then
            pls_8k                  <= '0';
        elsif rising_edge(CLK) then
            if (clk_cnt = 2**13-1) then
                if (BFN_STROBE_IN = '1') then
                    pls_8k          <= '1';
                else
                    pls_8k          <= '0';
                end if;
            else
                pls_8k              <= '0';
            end if;
        end if;
    end process;

    CLK_COUNT_8K : process(RST, CLK)
    begin
        if (RST = '1') then
            clk_cnt_8k              <= (others => '1');
        elsif rising_edge(CLK) then
            if (fs_rpls_f2 = '1') then
                clk_cnt_8k          <= (others => '0');
            else
                if (pls_8k = '1') then

                    if (clk_cnt_8k = 2**12-1) then
                        clk_cnt_8k  <= clk_cnt_8k;
                    else
                        clk_cnt_8k  <= clk_cnt_8k + '1';
                    end if;

                else
                    clk_cnt_8k      <= clk_cnt_8k;
                end if;
            end if;
        end if;
    end process;

    GEN_DLY_SIG : process(RST, CLK)
    begin
        if (RST = '1') then
            fs_dly                  <= '0';
        elsif rising_edge(CLK) then
            if (DLYVALUE_IN = 0) then
                fs_dly              <= fs_rpls_f2;
            elsif (pls_8k = '1') then
                if (DLYVALUE_IN = clk_cnt_8k + 1) then
                    fs_dly          <= '1';
                else
                    fs_dly          <= '0';
                end if;
            else
                fs_dly              <= '0';
            end if;
        end if;
    end process;

    FS_DLY_OUT                      <= fs_dly;

end arc_START_OFFSET;
