library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

----< Entity >---------------------------------------------------------------------------------------------------------------------------
entity DUMPDONE_BLK is
port(
    RST                : in std_logic                     ; -- RST             : Input RESET, Active high
    CLK                : in std_logic                     ; -- CLK        : Input Clock

    DUMP_START_IN      : in std_logic                     ; -- DUMPSTART_IN    : DUMPSTART signal
    ADDR_DUMP          : in std_logic_vector(12 downto 0) ; -- ADDR_DUMP       : DUMP Address
    WRVAL              : in stD_logic                     ; -- WRVAL           : Write Valid signal

    DUMPDONE_OUT       : out std_logic                      -- DUMPDONE_OUT    : DUMPDONE signal
    );
end DUMPDONE_BLK;

----< Architecture >---------------------------------------------------------------------------------------------------------------------
architecture arc_DUMPDONE_BLK of DUMPDONE_BLK is

--< Signal >--
signal f_dumpstart     : std_logic                        ; -- f_dumpstart     : 1 Clock delayed DUMP_START_IN signal
signal dumpstart_rpls  : std_logic                        ; -- dumpstart_rpls  : 1 Clock pulse Dumpstart

signal dumpdone        : std_logic                        ; -- dumpdone        : dumpdone signal
signal addr_buf0       : std_logic_vector(12 downto 0)    ; -- addr_buf        : Address buffer0
signal addr_buf1       : std_logic_vector(12 downto 0)    ; -- addr_buf        : Address buffer1
signal buf_plag        : std_logic                        ; -- buf_plag        : Buffer Plag

--< Process >--
begin

    GEN_PULSE_DUMPSTART : process(RST, CLK)
    begin
        if (RST = '1') then
            f_dumpstart             <= '0';
            dumpstart_rpls          <= '0';
        elsif (CLK'event) and (CLK = '1') then
            f_dumpstart             <= DUMP_START_IN;
            dumpstart_rpls          <= DUMP_START_IN and (not f_dumpstart);
        end if;
    end process;

    ADDRESS_BUFFER : process(RST, CLK)
    begin
        if (RST = '1') then
            addr_buf0 <= (others => '0');
            addr_buf1 <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (WRVAL = '1') then
                addr_buf0 <= ADDR_DUMP;
                addr_buf1 <= addr_buf0;
            else
                addr_buf0 <= addr_buf0;
                addr_buf1 <= addr_buf1;
            end if;
        end if;
    end process;

    GEN_BUF_PLAG : process(RST, CLK)
    begin
        if (RST = '1') then
            buf_plag <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if ((addr_buf0 = 8191) and (addr_buf1 = 8190)) then
                buf_plag <= '1';
            else
                buf_plag <= '0';
            end if;
        end if;
    end process;

    Gen_DUMPDONE : process(RST, CLK)
    begin
        if (RST = '1') then
            dumpdone <= '1';
        elsif (CLK'event) and (CLK = '1') then
            if (dumpstart_rpls = '1') then
                dumpdone <= '0';
            elsif (dumpdone = '0') then
                if (buf_plag = '1') then
                    dumpdone <= '1';
                else
                    dumpdone <= '0';
                end if;
            else
                dumpdone <= dumpdone;
            end if;
        end if;
    end process;	
	    
    Output_FROM_FF : process(RST, CLK)
    begin
        if (RST = '1') then
            DUMPDONE_OUT <= '1';
        elsif (CLK'event) and (CLK = '1') then
            DUMPDONE_OUT <= dumpdone;
        end if;
    end process;

end arc_DUMPDONE_BLK;

