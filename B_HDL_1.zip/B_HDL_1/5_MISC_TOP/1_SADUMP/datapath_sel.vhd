library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity DATAPATH_SEL is
    generic(
        DUMP_BUF_NUM                : natural := 2;
        CPRI_NUM                    : natural := 7;
        POLY_PHASE_USAGE            : boolean := FALSE
        );
    port(
        RST                         : in  std_logic;
        CLK_DUMP0                   : in  std_logic;
        CLK_DUMP1                   : in  std_logic;

        --External Device
        EXT_TRIGGER_IN              : in  std_logic;

        --SYSCTRL_TOP
        RX_BFNSTRB_SYSCTRL_IN       : in  std_logic_vector(CPRI_NUM-1 downto 0);
        TX_BFNSTRB_SYSCTRL_IN       : in  std_logic_vector(CPRI_NUM-1 downto 0);

        --CPRI_TOP
        RX_BFNSTRB_CPRI_IN          : in  std_logic_vector(CPRI_NUM-1 downto 0);

        --CPRIPHY_TOP(CFPGA)
        DUMP_BFN_STRB_CPRIPHY_IN    : in  std_logic_vector( 1 downto 0);
        DUMP_DATA_CPRIPHY_IN        : in  std_logic_array32(1 downto 0);
        DUMP_DVLD_CPRIPHY_IN        : in  std_logic_vector( 1 downto 0);

        --CPRI_TOP(CFPGA,DFPGA)
        DUMP_BFN_STRB_CPRI_IN       : in  std_logic_vector( 1 downto 0);
        DUMP_DATA_CPRI_IN           : in  std_logic_array32(1 downto 0);
        DUMP_DVLD_CPRI_IN           : in  std_logic_vector( 1 downto 0);

        --SBIF_TOP(CFPGA,DFPGA)
        DUMP_BFN_STRB_SBIF_IN       : in  std_logic_vector( 1 downto 0);
        DUMP_DATA_SBIF_IN           : in  std_logic_array32(1 downto 0);
        DUMP_DVLD_SBIF_IN           : in  std_logic_vector( 1 downto 0);

        --SBIFPHY_TOP(CFPGA,DFPGA)
        DUMP_BFN_STRB_SBIFPHY_IN    : in  std_logic_vector( 1 downto 0);
        DUMP_DATA_SBIFPHY_IN        : in  std_logic_array32(1 downto 0);
        DUMP_DVLD_SBIFPHY_IN        : in  std_logic_vector( 1 downto 0);

        --BBCTRL_TOP(DFPGA)
        DUMP_BFN_STRB_BBCTRL_IN     : in  std_logic_vector( 1 downto 0);
        DUMP_DATA_BBCTRL_IN         : in  std_logic_array32(1 downto 0);
        DUMP_DVLD_BBCTRL_IN         : in  std_logic_vector( 1 downto 0);

        --DSP_TOP(DFPGA)
        DUMP_BFN_STRB_DSP_IN        : in  std_logic_vector( 1 downto 0);
        DUMP_DATA_DSP_IN            : in  std_logic_array32(1 downto 0);
        DUMP_DVLD_DSP_IN            : in  std_logic_vector( 1 downto 0);

        --DCIF_TOP(DFPGA)
        DUMP_BFN_STRB_DCIF_IN       : in  std_logic_vector( 1 downto 0);
        DUMP_DATA_DCIF_IN           : in  std_logic_array32(1 downto 0);
        DUMP_DVLD_DCIF_IN           : in  std_logic_vector( 1 downto 0);

        DUMP_START_IN               : in  std_logic                    ;  -- DUMPSTART_IN
        DUMP_DATASEL_IN             : in  std_logic_vector( 7 downto 0);  -- DUMPBLKSEL_IN

        RX_SYSCTRL_STRB_SEL_IN      : in  std_logic_vector( 7 downto 0);
        TX_SYSCTRL_STRB_SEL_IN      : in  std_logic_vector( 7 downto 0);
        RX_CPRI_STRB_SEL_IN         : in  std_logic_vector( 7 downto 0);
        MODULE_STRB_SEL_IN          : in  std_logic_vector( 7 downto 0);
   
        WRSTRB_OUT                  : out std_logic_array1( DUMP_BUF_NUM-1 downto 0);
        WRDATA_OUT                  : out std_logic_array32(             1 downto 0);
        WRVAL_OUT                   : out std_logic_array1( DUMP_BUF_NUM-1 downto 0)
    );
    end DATAPATH_SEL;

    architecture arc_DATAPATH_SEL of DATAPATH_SEL is

    component RST_SYNC is
    generic(
        DLY_NUM                     : natural := 4  ;
        MAX_FANOUT_NUM              : integer := 200
    );
    port(
        RST_IN                      : in std_logic  ; -- RST      : Reset, Active high 
        CLK                         : in std_logic  ; -- CLK      : Clock
        RST_OUT                     : out std_logic   -- RST_SYNC : Synchronous Reset
    );	
    end component;
    
    --< Signal >--
    signal RST_DUMP                 : std_logic_vector(DUMP_BUF_NUM-1 downto 0);

    signal dvld_cpriphy             : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dvld_cpri                : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dvld_bbctrl              : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dvld_dsp                 : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dvld_dcif                : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dvld_sbif                : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dvld_sbifphy             : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));

    signal data_cpriphy             : std_logic_array32(DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));   
    signal data_cpri                : std_logic_array32(DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));   
    signal data_bbctrl              : std_logic_array32(DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));   
    signal data_dsp                 : std_logic_array32(             1 downto 0) := (others => (others => '0'));   
    signal data_dcif                : std_logic_array32(DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));   
    signal data_sbif                : std_logic_array32(DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));   
    signal data_sbifphy             : std_logic_array32(DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));   

    signal strb_cpriphy             : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal strb_cpri                : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal strb_bbctrl              : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal strb_dsp                 : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal strb_dcif                : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal strb_sbif                : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal strb_sbifphy             : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));

    signal wrstrb                   : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal wrval                    : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal wrdata                   : std_logic_array32(             1 downto 0) := (others => (others => '0'));
    
    signal dumpenable_sh            : std_logic_array3( 1 downto 0);
    signal dumpblk_sel              : std_logic_array8( 1 downto 0);
    signal module_strb_sel          : std_logic_array8( 1 downto 0);
    signal rx_sysctrl_strb_sel      : std_logic_vector( 7 downto 0);
    signal tx_sysctrl_strb_sel      : std_logic_vector( 7 downto 0);
    signal rx_cpri_strb_sel         : std_logic_vector( 7 downto 0);

    signal module_wrstrb            : std_logic_array1( DUMP_BUF_NUM-1 downto 0);
    signal rx_sysctrl_wrstrb        : std_logic;
    signal tx_sysctrl_wrstrb        : std_logic;
    signal rx_cpri_wrstrb           : std_logic;
    
    signal rx_bfnstrb_sysctrl       : std_logic_vector( 7 downto 0);
    signal tx_bfnstrb_sysctrl       : std_logic_vector( 7 downto 0);
    signal rx_bfnstrb_cpri          : std_logic_vector( 7 downto 0);

    signal i_dump_bfn_strb_cpriphy  : std_logic_vector( 1 downto 0);
    signal i_dump_data_cpriphy      : std_logic_array32(1 downto 0);
    signal i_dump_dvld_cpriphy      : std_logic_vector( 1 downto 0);

    signal i_dump_bfn_strb_cpri     : std_logic_vector( 1 downto 0);
    signal i_dump_data_cpri         : std_logic_array32(1 downto 0);
    signal i_dump_dvld_cpri         : std_logic_vector( 1 downto 0);

    signal i_dump_bfn_strb_sbif     : std_logic_vector( 1 downto 0);
    signal i_dump_data_sbif         : std_logic_array32(1 downto 0);
    signal i_dump_dvld_sbif         : std_logic_vector( 1 downto 0);

    signal i_dump_bfn_strb_sbifphy  : std_logic_vector( 1 downto 0);
    signal i_dump_data_sbifphy      : std_logic_array32(1 downto 0);
    signal i_dump_dvld_sbifphy      : std_logic_vector( 1 downto 0);

    signal i_dump_bfn_strb_bbctrl   : std_logic_vector( 1 downto 0);
    signal i_dump_data_bbctrl       : std_logic_array32(1 downto 0);
    signal i_dump_dvld_bbctrl       : std_logic_vector( 1 downto 0);

    signal i_dump_bfn_strb_dsp      : std_logic_vector( 1 downto 0);
    signal i_dump_data_dsp          : std_logic_array32(1 downto 0);
    signal i_dump_dvld_dsp          : std_logic_vector( 1 downto 0);

    signal i_dump_bfn_strb_dcif     : std_logic_vector( 1 downto 0);
    signal i_dump_data_dcif         : std_logic_array32(1 downto 0);
    signal i_dump_dvld_dcif         : std_logic_vector( 1 downto 0);

--< Process >--
begin
    G_BFN_STRB_CPRI_NUM_Generate : for I in 0 to (CPRI_NUM-1) generate
    begin
        rx_bfnstrb_sysctrl(I)       <= RX_BFNSTRB_SYSCTRL_IN(I);
        tx_bfnstrb_sysctrl(I)       <= TX_BFNSTRB_SYSCTRL_IN(I);
        rx_bfnstrb_cpri(I)          <= RX_BFNSTRB_CPRI_IN(I);
    end generate;
    G_BFN_STRB_CPRI_NUM_Remain_Generate : for I in (CPRI_NUM) to 7 generate
    begin
        rx_bfnstrb_sysctrl(I)       <= '0';
        tx_bfnstrb_sysctrl(I)       <= '0';
        rx_bfnstrb_cpri(I)          <= '0';
    end generate;

    ----------------------------------------------------------------------------------------------
    -- DUMP_BUF_NUM = 1
    ----------------------------------------------------------------------------------------------
    G_1_CLK_DOMAIN : if (DUMP_BUF_NUM = 1) generate 
    begin

        U_RST_SYNC : RST_SYNC generic map( 4 , 200) port map(RST, CLK_DUMP0, RST_DUMP(0));

        P_DumpStart_DC : process(RST_DUMP(0), CLK_DUMP0) 
        begin
            if (RST_DUMP(0) = '1') then
                dumpenable_sh(0)    <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                dumpenable_sh(0)    <= dumpenable_sh(0)(1 downto 0) & DUMP_START_IN;
            end if;
        end process;

        Timing_Meet : process(RST_DUMP(0), CLK_DUMP0)
        begin
            if RST_DUMP(0) = '1' then
                i_dump_bfn_strb_cpriphy     <= (others => '0');  
                i_dump_data_cpriphy         <= (others => (others => '0'));  
                i_dump_dvld_cpriphy         <= (others => '0');  
                
                i_dump_bfn_strb_cpri        <= (others => '0');  
                i_dump_data_cpri            <= (others => (others => '0'));  
                i_dump_dvld_cpri            <= (others => '0');  
                
                i_dump_bfn_strb_sbif        <= (others => '0');  
                i_dump_data_sbif            <= (others => (others => '0'));  
                i_dump_dvld_sbif            <= (others => '0');  
                
                i_dump_bfn_strb_sbifphy     <= (others => '0');  
                i_dump_data_sbifphy         <= (others => (others => '0'));  
                i_dump_dvld_sbifphy         <= (others => '0');  
                
                i_dump_bfn_strb_bbctrl      <= (others => '0');  
                i_dump_data_bbctrl          <= (others => (others => '0'));  
                i_dump_dvld_bbctrl          <= (others => '0');  
                
                i_dump_bfn_strb_dsp         <= (others => '0');  
                i_dump_data_dsp             <= (others => (others => '0'));  
                i_dump_dvld_dsp             <= (others => '0');  
                
                i_dump_bfn_strb_dcif        <= (others => '0');  
                i_dump_data_dcif            <= (others => (others => '0'));  
                i_dump_dvld_dcif            <= (others => '0');

            elsif rising_edge(CLK_DUMP0) then
                i_dump_bfn_strb_cpriphy     <= DUMP_BFN_STRB_CPRIPHY_IN;
                i_dump_data_cpriphy         <= DUMP_DATA_CPRIPHY_IN;
                i_dump_dvld_cpriphy         <= DUMP_DVLD_CPRIPHY_IN;

                i_dump_bfn_strb_cpri        <= DUMP_BFN_STRB_CPRI_IN;
                i_dump_data_cpri            <= DUMP_DATA_CPRI_IN;
                i_dump_dvld_cpri            <= DUMP_DVLD_CPRI_IN;

                i_dump_bfn_strb_sbif        <= DUMP_BFN_STRB_SBIF_IN;
                i_dump_data_sbif            <= DUMP_DATA_SBIF_IN;
                i_dump_dvld_sbif            <= DUMP_DVLD_SBIF_IN;
   
                i_dump_bfn_strb_sbifphy     <= DUMP_BFN_STRB_SBIFPHY_IN;
                i_dump_data_sbifphy         <= DUMP_DATA_SBIFPHY_IN;
                i_dump_dvld_sbifphy         <= DUMP_DVLD_SBIFPHY_IN;

                i_dump_bfn_strb_bbctrl      <= DUMP_BFN_STRB_BBCTRL_IN;
                i_dump_data_bbctrl          <= DUMP_DATA_BBCTRL_IN;
                i_dump_dvld_bbctrl          <= DUMP_DVLD_BBCTRL_IN;
 
                i_dump_bfn_strb_dsp         <= DUMP_BFN_STRB_DSP_IN;
                i_dump_data_dsp             <= DUMP_DATA_DSP_IN;
                i_dump_dvld_dsp             <= DUMP_DVLD_DSP_IN;

                i_dump_bfn_strb_dcif        <= DUMP_BFN_STRB_DCIF_IN;
                i_dump_data_dcif            <= DUMP_DATA_DCIF_IN;
                i_dump_dvld_dcif            <= DUMP_DVLD_DCIF_IN;
            end if;
        end process;



        P_DumpBlock_SEL_CDC : process(RST_DUMP(0), CLK_DUMP0) 
        begin
            if (RST_DUMP(0) = '1') then
                dumpblk_sel(0)              <= (others => '0');
                module_strb_sel(0)          <= (others => '0');
                rx_sysctrl_strb_sel         <= (others => '0');
                tx_sysctrl_strb_sel         <= (others => '0');
                rx_cpri_strb_sel            <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if (dumpenable_sh(0)(2) = '0') and (dumpenable_sh(0)(1) = '1') then
                    dumpblk_sel(0)          <= DUMP_DATASEL_IN;
                    module_strb_sel(0)      <= MODULE_STRB_SEL_IN;
                    rx_sysctrl_strb_sel     <= RX_SYSCTRL_STRB_SEL_IN;
                    tx_sysctrl_strb_sel     <= TX_SYSCTRL_STRB_SEL_IN;
                    rx_cpri_strb_sel        <= RX_CPRI_STRB_SEL_IN;
                else
                    dumpblk_sel(0)          <= dumpblk_sel(0);
                    module_strb_sel(0)      <= module_strb_sel(0);
                    rx_sysctrl_strb_sel     <= rx_sysctrl_strb_sel;
                    tx_sysctrl_strb_sel     <= tx_sysctrl_strb_sel;
                    rx_cpri_strb_sel        <= rx_cpri_strb_sel;
                end if;
            end if;
        end process;

        PATH_SEL_STRB_n_VALID : process(RST_DUMP(0), CLK_DUMP0) 
        begin
            if (RST_DUMP(0) = '1') then
                dvld_cpriphy(0)     <= (others => '0');
                dvld_cpri(0)        <= (others => '0');
                dvld_bbctrl(0)      <= (others => '0');
                dvld_dsp(0)         <= (others => '0');
                dvld_dcif(0)        <= (others => '0');
                dvld_sbif(0)        <= (others => '0');
                dvld_sbifphy(0)     <= (others => '0');

                strb_cpriphy(0)     <= (others => '0');
                strb_cpri(0)        <= (others => '0');
                strb_bbctrl(0)      <= (others => '0');
                strb_dsp(0)         <= (others => '0');
                strb_dcif(0)        <= (others => '0');
                strb_sbif(0)        <= (others => '0');
                strb_sbifphy(0)     <= (others => '0');

                wrval(0)            <= (others => '0');
                module_wrstrb(0)    <= (others => '0');
                rx_sysctrl_wrstrb   <= '0';
                tx_sysctrl_wrstrb   <= '0';
                rx_cpri_wrstrb      <= '0';

            elsif rising_edge(CLK_DUMP0) then
                case (dumpblk_sel(0)(0)) is
                    when '0'        => dvld_cpriphy(0)(0)   <= i_dump_dvld_cpriphy(0);
                                       dvld_cpri(0)(0)      <= i_dump_dvld_cpri(0);
                                       dvld_bbctrl(0)(0)    <= i_dump_dvld_bbctrl(0);
                                       dvld_dsp(0)(0)       <= i_dump_dvld_dsp(0);
                                       dvld_dcif(0)(0)      <= i_dump_dvld_dcif(0);
                                       dvld_sbif(0)(0)      <= i_dump_dvld_sbif(0);
                                       dvld_sbifphy(0)(0)   <= i_dump_dvld_sbifphy(0);
  
                    when others     => dvld_cpriphy(0)(0)   <= i_dump_dvld_cpriphy(1);
                                       dvld_cpri(0)(0)      <= i_dump_dvld_cpri(1);
                                       dvld_bbctrl(0)(0)    <= i_dump_dvld_bbctrl(1);
                                       dvld_dsp(0)(0)       <= i_dump_dvld_dsp(1);
                                       dvld_dcif(0)(0)      <= i_dump_dvld_dcif(1);
                                       dvld_sbif(0)(0)      <= i_dump_dvld_sbif(1);
                                       dvld_sbifphy(0)(0)   <= i_dump_dvld_sbifphy(1);                    
                end case;

                case(dumpblk_sel(0)(7 downto 4)) is
                    when x"1"       => wrval(0)(0)          <= dvld_cpriphy(0)(0);
                    when x"2"       => wrval(0)(0)          <= dvld_cpri(0)(0)   ;
                    when x"3"       => wrval(0)(0)          <= dvld_bbctrl(0)(0) ;
                    when x"4"       => wrval(0)(0)          <= dvld_dsp(0)(0)    ;
                    when x"5"       => wrval(0)(0)          <= dvld_dcif(0)(0)   ;
                    when x"6"       => wrval(0)(0)          <= dvld_sbif(0)(0)   ;
                    when x"7"       => wrval(0)(0)          <= dvld_sbifphy(0)(0);
                    when others     => wrval(0)             <= (others => '0');
                end case;

                case (module_strb_sel(0)(0)) is
                    when '0'        => strb_cpriphy(0)(0)   <= i_dump_bfn_strb_cpriphy(0);
                                       strb_cpri(0)(0)      <= i_dump_bfn_strb_cpri(0);
                                       strb_bbctrl(0)(0)    <= i_dump_bfn_strb_bbctrl(0);
                                       strb_dsp(0)(0)       <= i_dump_bfn_strb_dsp(0);
                                       strb_dcif(0)(0)      <= i_dump_bfn_strb_dcif(0);
                                       strb_sbif(0)(0)      <= i_dump_bfn_strb_sbif(0);
                                       strb_sbifphy(0)(0)   <= i_dump_bfn_strb_sbifphy(0);
  
                    when others     => strb_cpriphy(0)(0)   <= i_dump_bfn_strb_cpriphy(1);
                                       strb_cpri(0)(0)      <= i_dump_bfn_strb_cpri(1);
                                       strb_bbctrl(0)(0)    <= i_dump_bfn_strb_bbctrl(1);
                                       strb_dsp(0)(0)       <= i_dump_bfn_strb_dsp(1);
                                       strb_dcif(0)(0)      <= i_dump_bfn_strb_dcif(1);
                                       strb_sbif(0)(0)      <= i_dump_bfn_strb_sbif(1);
                                       strb_sbifphy(0)(0)   <= i_dump_bfn_strb_sbifphy(1);
                end case;

                case(module_strb_sel(0)(7 downto 4)) is
                    when x"1"       => module_wrstrb(0)(0)  <= strb_cpriphy(0)(0)   ;
                    when x"2"       => module_wrstrb(0)(0)  <= strb_cpri(0)(0)      ;
                    when x"3"       => module_wrstrb(0)(0)  <= strb_bbctrl(0)(0)    ;
                    when x"4"       => module_wrstrb(0)(0)  <= strb_dsp(0)(0)       ;
                    when x"5"       => module_wrstrb(0)(0)  <= strb_dcif(0)(0)      ;
                    when x"6"       => module_wrstrb(0)(0)  <= strb_sbif(0)(0)      ;
                    when x"7"       => module_wrstrb(0)(0)  <= strb_sbifphy(0)(0)   ;
                    when others     => module_wrstrb(0)     <= (others => '0');
                end case;


                case (rx_sysctrl_strb_sel) is
                    when "00000001" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(0); --RX_BFNSTRB_SYSCTRL_IN(0);   
                    when "00000010" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(1); --RX_BFNSTRB_SYSCTRL_IN(1);   
                    when "00000100" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(2); --RX_BFNSTRB_SYSCTRL_IN(2);   
                    when "00001000" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(3); --RX_BFNSTRB_SYSCTRL_IN(3);   
                    when "00010000" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(4); --RX_BFNSTRB_SYSCTRL_IN(4);   
                    when "00100000" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(5); --RX_BFNSTRB_SYSCTRL_IN(5);   
                    when "01000000" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(6); --RX_BFNSTRB_SYSCTRL_IN(6);   
                    when "10000000" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(7); --RX_BFNSTRB_SYSCTRL_IN(7);   
                    when others     => rx_sysctrl_wrstrb    <= '0';
                end case;

                case (tx_sysctrl_strb_sel) is
                    when "00000001" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(0); -- TX_BFNSTRB_SYSCTRL_IN(0);   
                    when "00000010" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(1); -- TX_BFNSTRB_SYSCTRL_IN(1);  
                    when "00000100" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(2); -- TX_BFNSTRB_SYSCTRL_IN(2);  
                    when "00001000" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(3); -- TX_BFNSTRB_SYSCTRL_IN(3);  
                    when "00010000" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(4); -- TX_BFNSTRB_SYSCTRL_IN(4);  
                    when "00100000" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(5); -- TX_BFNSTRB_SYSCTRL_IN(5);  
                    when "01000000" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(6); -- TX_BFNSTRB_SYSCTRL_IN(6);  
                    when "10000000" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(7); -- TX_BFNSTRB_SYSCTRL_IN(7);  
                    when others     => tx_sysctrl_wrstrb    <= '0';
                end case;

                case (rx_cpri_strb_sel) is
                    when "00000001" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(0);    -- RX_BFNSTRB_CPRI_IN(0);            
                    when "00000010" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(1);    -- RX_BFNSTRB_CPRI_IN(1);          
                    when "00000100" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(2);    -- RX_BFNSTRB_CPRI_IN(2);          
                    when "00001000" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(3);    -- RX_BFNSTRB_CPRI_IN(3);          
                    when "00010000" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(4);    -- RX_BFNSTRB_CPRI_IN(4);          
                    when "00100000" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(5);    -- RX_BFNSTRB_CPRI_IN(5);          
                    when "01000000" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(6);    -- RX_BFNSTRB_CPRI_IN(6);          
                    when "10000000" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(7);    -- RX_BFNSTRB_CPRI_IN(7);        
                    when others     => rx_cpri_wrstrb       <= '0';
                end case;

            end if;
        end process;
        
        wrstrb(0)(0) <= module_wrstrb(0)(0) or rx_sysctrl_wrstrb or tx_sysctrl_wrstrb or rx_cpri_wrstrb;


        G_Poly_Phase_Type : if (POLY_PHASE_USAGE = TRUE) generate
        begin

            PATH_SEL_DATA : process(RST_DUMP(0), CLK_DUMP0) 
            begin
                if (RST_DUMP(0) = '1') then
                    data_cpriphy(0)     <= (others => '0');   
                    data_cpri(0)        <= (others => '0');   
                    data_bbctrl(0)      <= (others => '0');   
                    data_dsp(0)         <= (others => '0');   
                    data_dsp(1)         <= (others => '0');   
                    data_dcif(0)        <= (others => '0');   
                    data_sbif(0)        <= (others => '0');   
                    data_sbifphy(0)     <= (others => '0');   

                    wrdata(0)           <= (others => '0');
                    wrdata(1)           <= (others => '0');

                elsif rising_edge(CLK_DUMP0) then
                    case (dumpblk_sel(0)(0)) is
                        when '0'        => data_cpriphy(0)      <= i_dump_data_cpriphy(0)   ;
                                           data_cpri(0)         <= i_dump_data_cpri(0)      ;
                                           data_bbctrl(0)       <= i_dump_data_bbctrl(0)    ;
                                           data_dsp(0)          <= i_dump_data_dsp(0)       ;
                                           data_dsp(1)          <= i_dump_data_dsp(1)       ;
                                           data_dcif(0)         <= i_dump_data_dcif(0)      ;
                                           data_sbif(0)         <= i_dump_data_sbif(0)      ;
                                           data_sbifphy(0)      <= i_dump_data_sbifphy(0)   ;
  
                        when others     => data_cpriphy(0)      <= (others => '0')          ;
                                           data_cpri(0)         <= (others => '0')          ;
                                           data_bbctrl(0)       <= (others => '0')          ;
                                           data_dsp(0)          <= (others => '0')          ;
                                           data_dsp(1)          <= (others => '0')          ;
                                           data_dcif(0)         <= (others => '0')          ;
                                           data_sbif(0)         <= (others => '0')          ;
                                           data_sbifphy(0)      <= (others => '0')          ;
                    end case;

                    case(dumpblk_sel(0)(7 downto 4)) is
                        when x"1"       => wrdata(0)            <= data_cpriphy(0)          ;
                        when x"2"       => wrdata(0)            <= data_cpri(0)             ;
                        when x"3"       => wrdata(0)            <= data_bbctrl(0)           ;
                        when x"4"       => wrdata(0)            <= data_dsp(0)              ;
                                           wrdata(1)            <= data_dsp(1)              ;
                        when x"5"       => wrdata(0)            <= data_dcif(0)             ;
                        when x"6"       => wrdata(0)            <= data_sbif(0)             ;
                        when x"7"       => wrdata(0)            <= data_sbifphy(0)          ;
                        when others     => wrdata(0)            <= (others => '0')          ;
                    end case;
                end if;
            end process;
        end generate;

        G_Mono_Phase_Type : if (POLY_PHASE_USAGE = FALSE) generate
        begin

            PATH_SEL_DATA : process(RST_DUMP(0), CLK_DUMP0) 
            begin
                if (RST_DUMP(0) = '1') then
                    data_cpriphy(0)     <= (others => '0');   
                    data_cpri(0)        <= (others => '0');   
                    data_bbctrl(0)      <= (others => '0');   
                    data_dsp(0)         <= (others => '0');   
                    data_dcif(0)        <= (others => '0');   
                    data_sbif(0)        <= (others => '0');   
                    data_sbifphy(0)     <= (others => '0');   

                    wrdata(0)           <= (others => '0');

                elsif rising_edge(CLK_DUMP0) then
                    case (dumpblk_sel(0)(0)) is
                        when '0'        => data_cpriphy(0)      <= i_dump_data_cpriphy(0)   ;
                                           data_cpri(0)         <= i_dump_data_cpri(0)      ;
                                           data_bbctrl(0)       <= i_dump_data_bbctrl(0)    ;
                                           data_dsp(0)          <= i_dump_data_dsp(0)       ;
                                           data_dcif(0)         <= i_dump_data_dcif(0)      ;
                                           data_sbif(0)         <= i_dump_data_sbif(0)      ;
                                           data_sbifphy(0)      <= i_dump_data_sbifphy(0)   ;
  
                        when others     => data_cpriphy(0)      <= (others => '0')          ;
                                           data_cpri(0)         <= (others => '0')          ;
                                           data_bbctrl(0)       <= (others => '0')          ;
                                           data_dsp(0)          <= (others => '0')          ;
                                           data_dcif(0)         <= (others => '0')          ;
                                           data_sbif(0)         <= (others => '0')          ;
                                           data_sbifphy(0)      <= (others => '0')          ;
                    end case;

                    case(dumpblk_sel(0)(7 downto 4)) is
                        when x"1"       => wrdata(0)            <= data_cpriphy(0)          ;
                        when x"2"       => wrdata(0)            <= data_cpri(0)             ;
                        when x"3"       => wrdata(0)            <= data_bbctrl(0)           ;
                        when x"4"       => wrdata(0)            <= data_dsp(0)              ;
                        when x"5"       => wrdata(0)            <= data_dcif(0)             ;
                        when x"6"       => wrdata(0)            <= data_sbif(0)             ;
                        when x"7"       => wrdata(0)            <= data_sbifphy(0)          ;
                        when others     => wrdata(0)            <= (others => '0')          ;
                    end case;
                end if;
            end process;
        end generate;


    end generate;
    ----------------------------------------------------------------------------------------------
    -- DUMP_BUF_NUM = 2
    ----------------------------------------------------------------------------------------------

    G_2_CLK_Domain : if (DUMP_BUF_NUM = 2) generate 
    begin

        U_RST_SYNC_0 : RST_SYNC generic map( 4 , 200) port map(RST, CLK_DUMP0, RST_DUMP(0));
        U_RST_SYNC_1 : RST_SYNC generic map( 4 , 200) port map(RST, CLK_DUMP1, RST_DUMP(1));

        Timing_Meet0 : process(RST_DUMP(0), CLK_DUMP0)
        begin
            if RST_DUMP(0) = '1' then
                i_dump_bfn_strb_cpriphy(0)  <= '0';  
                i_dump_data_cpriphy(0)      <= (others => '0');  
                i_dump_dvld_cpriphy(0)      <= '0';  
                
                i_dump_bfn_strb_cpri(0)     <= '0';  
                i_dump_data_cpri(0)         <= (others => '0');  
                i_dump_dvld_cpri(0)         <= '0';  
                
                i_dump_bfn_strb_sbif(0)     <= '0';  
                i_dump_data_sbif(0)         <= (others => '0');  
                i_dump_dvld_sbif(0)         <= '0';  
                
                i_dump_bfn_strb_sbifphy(0)  <= '0';  
                i_dump_data_sbifphy(0)      <= (others => '0');  
                i_dump_dvld_sbifphy(0)      <= '0';  
                
                i_dump_bfn_strb_bbctrl(0)   <= '0';  
                i_dump_data_bbctrl(0)       <= (others => '0');  
                i_dump_dvld_bbctrl(0)       <= '0';  
                
                i_dump_bfn_strb_dsp(0)      <= '0';  
                i_dump_data_dsp(0)          <= (others => '0');  
                i_dump_dvld_dsp(0)          <= '0';  
                
                i_dump_bfn_strb_dcif(0)     <= '0';  
                i_dump_data_dcif(0)         <= (others => '0');  
                i_dump_dvld_dcif(0)         <= '0';

            elsif rising_edge(CLK_DUMP0) then
                i_dump_bfn_strb_cpriphy(0)  <= DUMP_BFN_STRB_CPRIPHY_IN(0);
                i_dump_data_cpriphy(0)      <= DUMP_DATA_CPRIPHY_IN(0);
                i_dump_dvld_cpriphy(0)      <= DUMP_DVLD_CPRIPHY_IN(0);

                i_dump_bfn_strb_cpri(0)     <= DUMP_BFN_STRB_CPRI_IN(0);
                i_dump_data_cpri(0)         <= DUMP_DATA_CPRI_IN(0);
                i_dump_dvld_cpri(0)         <= DUMP_DVLD_CPRI_IN(0);

                i_dump_bfn_strb_sbif(0)     <= DUMP_BFN_STRB_SBIF_IN(0);
                i_dump_data_sbif(0)         <= DUMP_DATA_SBIF_IN(0);
                i_dump_dvld_sbif(0)         <= DUMP_DVLD_SBIF_IN(0);
   
                i_dump_bfn_strb_sbifphy(0)  <= DUMP_BFN_STRB_SBIFPHY_IN(0);
                i_dump_data_sbifphy(0)      <= DUMP_DATA_SBIFPHY_IN(0);
                i_dump_dvld_sbifphy(0)      <= DUMP_DVLD_SBIFPHY_IN(0);

                i_dump_bfn_strb_bbctrl(0)   <= DUMP_BFN_STRB_BBCTRL_IN(0);
                i_dump_data_bbctrl(0)       <= DUMP_DATA_BBCTRL_IN(0);
                i_dump_dvld_bbctrl(0)       <= DUMP_DVLD_BBCTRL_IN(0);
 
                i_dump_bfn_strb_dsp(0)      <= DUMP_BFN_STRB_DSP_IN(0);
                i_dump_data_dsp(0)          <= DUMP_DATA_DSP_IN(0);
                i_dump_dvld_dsp(0)          <= DUMP_DVLD_DSP_IN(0);

                i_dump_bfn_strb_dcif(0)     <= DUMP_BFN_STRB_DCIF_IN(0);
                i_dump_data_dcif(0)         <= DUMP_DATA_DCIF_IN(0);
                i_dump_dvld_dcif(0)         <= DUMP_DVLD_DCIF_IN(0);
            end if;
        end process;

        Timing_Meet1 : process(RST_DUMP(1), CLK_DUMP1)
        begin
            if RST_DUMP(1) = '1' then
                i_dump_bfn_strb_cpriphy(1)  <= '0';  
                i_dump_data_cpriphy(1)      <= (others => '0');  
                i_dump_dvld_cpriphy(1)      <= '0';  
                
                i_dump_bfn_strb_cpri(1)     <= '0';  
                i_dump_data_cpri(1)         <= (others => '0');  
                i_dump_dvld_cpri(1)         <= '0';  
                
                i_dump_bfn_strb_sbif(1)     <= '0';  
                i_dump_data_sbif(1)         <= (others => '0');  
                i_dump_dvld_sbif(1)         <= '0';  
                
                i_dump_bfn_strb_sbifphy(1)  <= '0';  
                i_dump_data_sbifphy(1)      <= (others => '0');  
                i_dump_dvld_sbifphy(1)      <= '0';  
                
                i_dump_bfn_strb_bbctrl(1)   <= '0';  
                i_dump_data_bbctrl(1)       <= (others => '0');  
                i_dump_dvld_bbctrl(1)       <= '0';  
                
                i_dump_bfn_strb_dsp(1)      <= '0';  
                i_dump_data_dsp(1)          <= (others => '0');  
                i_dump_dvld_dsp(1)          <= '0';  
                
                i_dump_bfn_strb_dcif(1)     <= '0';  
                i_dump_data_dcif(1)         <= (others => '0');  
                i_dump_dvld_dcif(1)         <= '0';

            elsif rising_edge(CLK_DUMP1) then
                i_dump_bfn_strb_cpriphy(1)  <= DUMP_BFN_STRB_CPRIPHY_IN(1);
                i_dump_data_cpriphy(1)      <= DUMP_DATA_CPRIPHY_IN(1);
                i_dump_dvld_cpriphy(1)      <= DUMP_DVLD_CPRIPHY_IN(1);

                i_dump_bfn_strb_cpri(1)     <= DUMP_BFN_STRB_CPRI_IN(1);
                i_dump_data_cpri(1)         <= DUMP_DATA_CPRI_IN(1);
                i_dump_dvld_cpri(1)         <= DUMP_DVLD_CPRI_IN(1);

                i_dump_bfn_strb_sbif(1)     <= DUMP_BFN_STRB_SBIF_IN(1);
                i_dump_data_sbif(1)         <= DUMP_DATA_SBIF_IN(1);
                i_dump_dvld_sbif(1)         <= DUMP_DVLD_SBIF_IN(1);
   
                i_dump_bfn_strb_sbifphy(1)  <= DUMP_BFN_STRB_SBIFPHY_IN(1);
                i_dump_data_sbifphy(1)      <= DUMP_DATA_SBIFPHY_IN(1);
                i_dump_dvld_sbifphy(1)      <= DUMP_DVLD_SBIFPHY_IN(1);

                i_dump_bfn_strb_bbctrl(1)   <= DUMP_BFN_STRB_BBCTRL_IN(1);
                i_dump_data_bbctrl(1)       <= DUMP_DATA_BBCTRL_IN(1);
                i_dump_dvld_bbctrl(1)       <= DUMP_DVLD_BBCTRL_IN(1);
 
                i_dump_bfn_strb_dsp(1)      <= DUMP_BFN_STRB_DSP_IN(1);
                i_dump_data_dsp(1)          <= DUMP_DATA_DSP_IN(1);
                i_dump_dvld_dsp(1)          <= DUMP_DVLD_DSP_IN(1);

                i_dump_bfn_strb_dcif(1)     <= DUMP_BFN_STRB_DCIF_IN(1);
                i_dump_data_dcif(1)         <= DUMP_DATA_DCIF_IN(1);
                i_dump_dvld_dcif(1)         <= DUMP_DVLD_DCIF_IN(1);
            end if;
        end process;

        P_DumpStart_DC0 : process(RST_DUMP(0), CLK_DUMP0) 
        begin
            if (RST_DUMP(0) = '1') then
                dumpenable_sh(0)            <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                dumpenable_sh(0)            <= dumpenable_sh(0)(1 downto 0) & DUMP_START_IN;
            end if;
        end process;

        P_DumpStart_DC1 : process(RST_DUMP(1), CLK_DUMP1) 
        begin
            if (RST_DUMP(1) = '1') then
                dumpenable_sh(1)            <= (others => '0');
            elsif rising_edge(CLK_DUMP1) then
                dumpenable_sh(1)            <= dumpenable_sh(1)(1 downto 0) & DUMP_START_IN;
            end if;
        end process;

        P_DumpBlock_SEL0_CDC : process(RST_DUMP(0), CLK_DUMP0) 
        begin
            if (RST_DUMP(0) = '1') then
                dumpblk_sel(0)              <= (others => '0');
                module_strb_sel(0)          <= (others => '0');
                rx_sysctrl_strb_sel         <= (others => '0');
                tx_sysctrl_strb_sel         <= (others => '0');
                rx_cpri_strb_sel            <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if (dumpenable_sh(0)(2) = '0') and (dumpenable_sh(0)(1) = '1') then
                    dumpblk_sel(0)          <= DUMP_DATASEL_IN;
                    module_strb_sel(0)      <= MODULE_STRB_SEL_IN;
                    rx_sysctrl_strb_sel     <= RX_SYSCTRL_STRB_SEL_IN;
                    tx_sysctrl_strb_sel     <= TX_SYSCTRL_STRB_SEL_IN;
                    rx_cpri_strb_sel        <= RX_CPRI_STRB_SEL_IN;
                else
                    dumpblk_sel(0)          <= dumpblk_sel(0);
                    module_strb_sel(0)      <= module_strb_sel(0);
                    rx_sysctrl_strb_sel     <= rx_sysctrl_strb_sel;
                    tx_sysctrl_strb_sel     <= tx_sysctrl_strb_sel;
                    rx_cpri_strb_sel        <= rx_cpri_strb_sel;
                end if;
            end if;
        end process;

        P_DumpBlock_SEL1_CDC : process(RST_DUMP(1), CLK_DUMP1)
        begin
            if (RST_DUMP(1) = '1') then
                dumpblk_sel(1)              <= (others => '0');
                module_strb_sel(1)          <= (others => '0');
            elsif rising_edge(CLK_DUMP1) then
                if (dumpenable_sh(1)(2) = '0') and (dumpenable_sh(1)(1) = '1') then
                    dumpblk_sel(1)          <= DUMP_DATASEL_IN;
                    module_strb_sel(1)      <= MODULE_STRB_SEL_IN;
                else
                    dumpblk_sel(1)          <= dumpblk_sel(1);
                    module_strb_sel(1)      <= module_strb_sel(1);
                end if;
            end if;
        end process;

        P_PATH_SEL0 : process(RST_DUMP(0), CLK_DUMP0) 
        begin
            if (RST_DUMP(0) = '1') then
                data_cpriphy(0)     <= (others => '0');   
                data_cpri(0)        <= (others => '0');   
                data_bbctrl(0)      <= (others => '0');   
                data_dsp(0)         <= (others => '0');   
                data_dcif(0)        <= (others => '0');   
                data_sbif(0)        <= (others => '0');   
                data_sbifphy(0)     <= (others => '0');   

                dvld_cpriphy(0)     <= (others => '0');
                dvld_cpri(0)        <= (others => '0');
                dvld_bbctrl(0)      <= (others => '0');
                dvld_dsp(0)         <= (others => '0');
                dvld_dcif(0)        <= (others => '0');
                dvld_sbif(0)        <= (others => '0');
                dvld_sbifphy(0)     <= (others => '0');

                strb_cpriphy(0)     <= (others => '0');
                strb_cpri(0)        <= (others => '0');
                strb_bbctrl(0)      <= (others => '0');
                strb_dsp(0)         <= (others => '0');
                strb_dcif(0)        <= (others => '0');
                strb_sbif(0)        <= (others => '0');
                strb_sbifphy(0)     <= (others => '0');

                wrdata(0)           <= (others => '0');
                wrval(0)            <= (others => '0');
                module_wrstrb(0)    <= (others => '0');
                rx_sysctrl_wrstrb   <= '0';
                tx_sysctrl_wrstrb   <= '0';
                rx_cpri_wrstrb      <= '0';
            elsif rising_edge(CLK_DUMP0) then
                case (dumpblk_sel(0)(0)) is
                    when '0'        => data_cpriphy(0)      <= i_dump_data_cpriphy(0);
                                       data_cpri(0)         <= i_dump_data_cpri(0);
                                       data_bbctrl(0)       <= i_dump_data_bbctrl(0);
                                       data_dsp(0)          <= i_dump_data_dsp(0);
                                       data_dcif(0)         <= i_dump_data_dcif(0);
                                       data_sbif(0)         <= i_dump_data_sbif(0);
                                       data_sbifphy(0)      <= i_dump_data_sbifphy(0);
  
                                       dvld_cpriphy(0)(0)   <= i_dump_dvld_cpriphy(0);
                                       dvld_cpri(0)(0)      <= i_dump_dvld_cpri(0);
                                       dvld_bbctrl(0)(0)    <= i_dump_dvld_bbctrl(0);
                                       dvld_dsp(0)(0)       <= i_dump_dvld_dsp(0);
                                       dvld_dcif(0)(0)      <= i_dump_dvld_dcif(0);
                                       dvld_sbif(0)(0)      <= i_dump_dvld_sbif(0);
                                       dvld_sbifphy(0)(0)   <= i_dump_dvld_sbifphy(0);
  
                    when others     => data_cpriphy(0)      <= (others => '0'); 
                                       data_cpri(0)         <= (others => '0'); 
                                       data_bbctrl(0)       <= (others => '0'); 
                                       data_dsp(0)          <= (others => '0'); 
                                       data_dcif(0)         <= (others => '0'); 
                                       data_sbif(0)         <= (others => '0'); 
                                       data_sbifphy(0)      <= (others => '0'); 

                                       dvld_cpriphy(0)      <= (others => '0'); 
                                       dvld_cpri(0)         <= (others => '0'); 
                                       dvld_bbctrl(0)       <= (others => '0'); 
                                       dvld_dsp(0)          <= (others => '0'); 
                                       dvld_dcif(0)         <= (others => '0'); 
                                       dvld_sbif(0)         <= (others => '0'); 
                                       dvld_sbifphy(0)      <= (others => '0'); 
                end case;

                case(dumpblk_sel(0)(7 downto 4)) is
                    when x"1"       => wrdata(0)            <= data_cpriphy(0)   ;
                                       wrval(0)(0)          <= dvld_cpriphy(0)(0);
                    when x"2"       => wrdata(0)            <= data_cpri(0)      ;
                                       wrval(0)(0)          <= dvld_cpri(0)(0)   ;
                    when x"3"       => wrdata(0)            <= data_bbctrl(0)    ;
                                       wrval(0)(0)          <= dvld_bbctrl(0)(0) ;
                    when x"4"       => wrdata(0)            <= data_dsp(0)       ;
                                       wrval(0)(0)          <= dvld_dsp(0)(0)    ;
                    when x"5"       => wrdata(0)            <= data_dcif(0)      ;
                                       wrval(0)(0)          <= dvld_dcif(0)(0)   ;
                    when x"6"       => wrdata(0)            <= data_sbif(0)      ;
                                       wrval(0)(0)          <= dvld_sbif(0)(0)   ;
                    when x"7"       => wrdata(0)            <= data_sbifphy(0)   ;
                                       wrval(0)(0)          <= dvld_sbifphy(0)(0);
                    when others     => wrdata(0)            <= (others => '0'); 
                                       wrval(0)             <= (others => '0');
                end case;

                case (module_strb_sel(0)(0)) is
                    when '0'        => strb_cpriphy(0)(0)   <= i_dump_bfn_strb_cpriphy(0);
                                       strb_cpri(0)(0)      <= i_dump_bfn_strb_cpri(0);
                                       strb_bbctrl(0)(0)    <= i_dump_bfn_strb_bbctrl(0);
                                       strb_dsp(0)(0)       <= i_dump_bfn_strb_dsp(0);
                                       strb_dcif(0)(0)      <= i_dump_bfn_strb_dcif(0);
                                       strb_sbif(0)(0)      <= i_dump_bfn_strb_sbif(0);
                                       strb_sbifphy(0)(0)   <= i_dump_bfn_strb_sbifphy(0);
  
                    when others     => strb_cpriphy(0)      <= (others => '0'); 
                                       strb_cpri(0)         <= (others => '0');
                                       strb_bbctrl(0)       <= (others => '0');
                                       strb_dsp(0)          <= (others => '0');
                                       strb_dcif(0)         <= (others => '0');
                                       strb_sbif(0)         <= (others => '0');
                                       strb_sbifphy(0)      <= (others => '0');
                end case;

                case(module_strb_sel(0)(7 downto 4)) is
                    when x"1"       => module_wrstrb(0)(0)  <= strb_cpriphy(0)(0)   ;
                    when x"2"       => module_wrstrb(0)(0)  <= strb_cpri(0)(0)      ;
                    when x"3"       => module_wrstrb(0)(0)  <= strb_bbctrl(0)(0)    ;
                    when x"4"       => module_wrstrb(0)(0)  <= strb_dsp(0)(0)       ;
                    when x"5"       => module_wrstrb(0)(0)  <= strb_dcif(0)(0)      ;
                    when x"6"       => module_wrstrb(0)(0)  <= strb_sbif(0)(0)      ;
                    when x"7"       => module_wrstrb(0)(0)  <= strb_sbifphy(0)(0)   ;
                    when others     => module_wrstrb(0)     <= (others => '0');                
                end case;

                case (rx_sysctrl_strb_sel) is
                    when "00000001" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(0);
                    when "00000010" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(1);
                    when "00000100" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(2);
                    when "00001000" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(3);
                    when "00010000" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(4);
                    when "00100000" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(5);
                    when "01000000" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(6);
                    when "10000000" => rx_sysctrl_wrstrb    <= rx_bfnstrb_sysctrl(7);
                    when others     => rx_sysctrl_wrstrb    <= '0';
                end case;

                case (tx_sysctrl_strb_sel) is
                    when "00000001" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(0); 
                    when "00000010" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(1);
                    when "00000100" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(2);
                    when "00001000" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(3);
                    when "00010000" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(4);
                    when "00100000" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(5);
                    when "01000000" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(6);
                    when "10000000" => tx_sysctrl_wrstrb    <= tx_bfnstrb_sysctrl(7);
                    when others     => tx_sysctrl_wrstrb    <= '0';
                end case;

                case (rx_cpri_strb_sel) is
                    when "00000001" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(0);    
                    when "00000010" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(1);  
                    when "00000100" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(2);  
                    when "00001000" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(3);  
                    when "00010000" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(4);  
                    when "00100000" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(5);  
                    when "01000000" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(6);  
                    when "10000000" => rx_cpri_wrstrb       <= rx_bfnstrb_cpri(7);
                    when others     => rx_cpri_wrstrb       <= '0';
                end case;

            end if;
        end process;

        P_PATH_SEL1 : process(RST_DUMP(1), CLK_DUMP1) begin
            if (RST_DUMP(1) = '1') then
                data_cpriphy(1)     <= (others => '0');   
                data_cpri(1)        <= (others => '0');   
                data_bbctrl(1)      <= (others => '0');   
                data_dsp(1)         <= (others => '0');   
                data_dcif(1)        <= (others => '0');   
                data_sbif(1)        <= (others => '0');   
                data_sbifphy(1)     <= (others => '0');   

                dvld_cpriphy(1)     <= (others => '0');
                dvld_cpri(1)        <= (others => '0');
                dvld_bbctrl(1)      <= (others => '0');
                dvld_dsp(1)         <= (others => '0');
                dvld_dcif(1)        <= (others => '0');
                dvld_sbif(1)        <= (others => '0');
                dvld_sbifphy(1)     <= (others => '0');

                strb_cpriphy(1)     <= (others => '0');
                strb_cpri(1)        <= (others => '0');
                strb_bbctrl(1)      <= (others => '0');
                strb_dsp(1)         <= (others => '0');
                strb_dcif(1)        <= (others => '0');
                strb_sbif(1)        <= (others => '0');
                strb_sbifphy(1)     <= (others => '0');

                wrdata(1)           <= (others => '0');
                wrval(1)            <= (others => '0');
                module_wrstrb(1)    <= (others => '0');

            elsif rising_edge(CLK_DUMP1) then

                case (dumpblk_sel(1)(0)) is
                    when '1'        => data_cpriphy(1)      <= i_dump_data_cpriphy(1);
                                       data_cpri(1)         <= i_dump_data_cpri(1);
                                       data_bbctrl(1)       <= i_dump_data_bbctrl(1);
                                       data_dsp(1)          <= i_dump_data_dsp(1);
                                       data_dcif(1)         <= i_dump_data_dcif(1);
                                       data_sbif(1)         <= i_dump_data_sbif(1);
                                       data_sbifphy(1)      <= i_dump_data_sbifphy(1);
  
                                       dvld_cpriphy(1)(0)   <= i_dump_dvld_cpriphy(1);
                                       dvld_cpri(1)(0)      <= i_dump_dvld_cpri(1);
                                       dvld_bbctrl(1)(0)    <= i_dump_dvld_bbctrl(1);
                                       dvld_dsp(1)(0)       <= i_dump_dvld_dsp(1);
                                       dvld_dcif(1)(0)      <= i_dump_dvld_dcif(1);
                                       dvld_sbif(1)(0)      <= i_dump_dvld_sbif(1);
                                       dvld_sbifphy(1)(0)   <= i_dump_dvld_sbifphy(1);
  
                    when others     => data_cpriphy(1)      <= (others => '0'); 
                                       data_cpri(1)         <= (others => '0'); 
                                       data_bbctrl(1)       <= (others => '0'); 
                                       data_dsp(1)          <= (others => '0'); 
                                       data_dcif(1)         <= (others => '0'); 
                                       data_sbif(1)         <= (others => '0'); 
                                       data_sbifphy(1)      <= (others => '0'); 

                                       dvld_cpriphy(1)      <= (others => '0'); 
                                       dvld_cpri(1)         <= (others => '0'); 
                                       dvld_bbctrl(1)       <= (others => '0'); 
                                       dvld_dsp(1)          <= (others => '0'); 
                                       dvld_dcif(1)         <= (others => '0'); 
                                       dvld_sbif(1)         <= (others => '0'); 
                                       dvld_sbifphy(1)      <= (others => '0'); 
                end case;

                case(dumpblk_sel(1)(7 downto 4)) is
                    when x"1"       => wrdata(1)            <= data_cpriphy(1)   ;
                                       wrval(1)(0)          <= dvld_cpriphy(1)(0);
                    when x"2"       => wrdata(1)            <= data_cpri(1)      ;
                                       wrval(1)(0)          <= dvld_cpri(1)(0)   ;
                    when x"3"       => wrdata(1)            <= data_bbctrl(1)    ;
                                       wrval(1)(0)          <= dvld_bbctrl(1)(0) ;
                    when x"4"       => wrdata(1)            <= data_dsp(1)       ;
                                       wrval(1)(0)          <= dvld_dsp(1)(0)    ;
                    when x"5"       => wrdata(1)            <= data_dcif(1)      ;
                                       wrval(1)(0)          <= dvld_dcif(1)(0)   ;
                    when x"6"       => wrdata(1)            <= data_sbif(1)      ;
                                       wrval(1)(0)          <= dvld_sbif(1)(0)   ;
                    when x"7"       => wrdata(1)            <= data_sbifphy(1)   ;
                                       wrval(1)(0)          <= dvld_sbifphy(1)(0);
                    when others     => wrdata(1)            <= (others => '0'); 
                                       wrval(1)             <= (others => '0');
                end case;                

                case (module_strb_sel(1)(0)) is
                    when '1'        => strb_cpriphy(1)(0)   <= i_dump_bfn_strb_cpriphy(1);
                                       strb_cpri(1)(0)      <= i_dump_bfn_strb_cpri(1);
                                       strb_bbctrl(1)(0)    <= i_dump_bfn_strb_bbctrl(1);
                                       strb_dsp(1)(0)       <= i_dump_bfn_strb_dsp(1);
                                       strb_dcif(1)(0)      <= i_dump_bfn_strb_dcif(1);
                                       strb_sbif(1)(0)      <= i_dump_bfn_strb_sbif(1);
                                       strb_sbifphy(1)(0)   <= i_dump_bfn_strb_sbifphy(1);
  
                    when others     => strb_cpriphy(1)      <= (others => '0'); 
                                       strb_cpri(1)         <= (others => '0'); 
                                       strb_bbctrl(1)       <= (others => '0'); 
                                       strb_dsp(1)          <= (others => '0'); 
                                       strb_dcif(1)         <= (others => '0'); 
                                       strb_sbif(1)         <= (others => '0'); 
                                       strb_sbifphy(1)      <= (others => '0'); 
                end case;

                case(module_strb_sel(1)(7 downto 4)) is
                    when x"1"       => module_wrstrb(1)(0)  <= strb_cpriphy(1)(0)   ;
                    when x"2"       => module_wrstrb(1)(0)  <= strb_cpri(1)(0)      ;
                    when x"3"       => module_wrstrb(1)(0)  <= strb_bbctrl(1)(0)    ;
                    when x"4"       => module_wrstrb(1)(0)  <= strb_dsp(1)(0)       ;
                    when x"5"       => module_wrstrb(1)(0)  <= strb_dcif(1)(0)      ;
                    when x"6"       => module_wrstrb(1)(0)  <= strb_sbif(1)(0)      ;
                    when x"7"       => module_wrstrb(1)(0)  <= strb_sbifphy(1)(0)   ;
                    when others     => module_wrstrb(1)     <= (others => '0');
                end case;
                
            end if;
        end process;

    wrstrb(0)(0) <= module_wrstrb(0)(0) or rx_sysctrl_wrstrb or tx_sysctrl_wrstrb or rx_cpri_wrstrb;
    wrstrb(1)    <= module_wrstrb(1);

    end generate;

    

    WRSTRB_OUT                      <= wrstrb;
    WRVAL_OUT                       <= wrval;
    WRDATA_OUT                      <= wrdata;

end arc_DATAPATH_SEL;	

