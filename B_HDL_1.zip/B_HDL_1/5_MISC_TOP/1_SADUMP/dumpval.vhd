library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity DUMPVAL is
port(
    RST          : in std_logic                    ; -- RST          : Input Reset, Active High
    CLK          : in std_logic                    ; -- CLK          : Input CPU Clock, 100 MHz

    DUMP_START_IN: in std_logic                    ; -- DUMPSTART_IN : DUMP start
    FS_DLY_IN    : in std_logic                    ; -- FS_DLY_IN    : Delayed Frame Sync signal
    DUMPDONE_IN  : in std_logic                    ; -- DUMPDONE_IN  : Dumpdone

    DUMPVAL_OUT  : out std_logic_vector(1 downto 0)  -- DUMPVAL_OUT  : DUMP Valid signal	
    );
end DUMPVAL;

architecture arc_DUMPVAL of DUMPVAL is

signal dumpstart_f1   : std_logic;
signal dumpstart_rpls : std_logic;
signal fs_dly_f1      : std_logic;
signal fs_dly_rpls    : std_logic;
signal dumpdone_f1    : std_logic;
signal dumpdone_rpls  : std_logic;

signal dumpvalid      : std_logic_vector(1 downto 0);     -- dumpvaild

begin

    GEN_Rising_Pulse : process(RST, CLK)
    begin
        if (RST = '1') then
            dumpstart_f1   <= '0';
            dumpstart_rpls <= '0';
            fs_dly_f1      <= '0';
            fs_dly_rpls    <= '0';
            dumpdone_f1    <= '0';
            dumpdone_rpls  <= '0';
        elsif (CLK'event) and (CLK = '1') then
            dumpstart_f1   <= DUMP_START_IN;
            dumpstart_rpls <= DUMP_START_IN and (not dumpstart_f1);
            fs_dly_f1      <= FS_DLY_IN;
            fs_dly_rpls    <= FS_DLY_IN and (not fs_dly_f1);
            dumpdone_f1    <= DUMPDONE_IN;
            dumpdone_rpls  <= DUMPDONE_IN and (not dumpdone_f1);
        end if;
    end process;

    DUMP_Valid : process(RST, CLK)
    begin
        if (RST = '1') then
            dumpvalid <= "10";
        elsif (CLK'event) and (CLK = '1') then
            if (dumpstart_rpls = '1') then
                dumpvalid <= (others => '0');
            elsif (dumpvalid = "00") and (fs_dly_rpls = '1') then
                dumpvalid <= "01";
            elsif (dumpvalid = "01") and (dumpdone_rpls = '1') then
                dumpvalid <= "11";
            else
                dumpvalid <= dumpvalid;
            end if;
        end if;
    end process;

    DUMPVAL_OUT <= dumpvalid;

end arc_DUMPVAL;
