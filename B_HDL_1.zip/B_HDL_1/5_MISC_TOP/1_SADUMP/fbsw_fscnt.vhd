library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

-----------------------------------
-- FB_SW_CNT_INFO value description
-----------------------------------
-- 0b00 = Foward  A/C
-- 0b01 = Reverse A/C
-- 0b10 = Foward  B/D
-- 0b11 = Reverse B/D
-----------------------------------

entity FBSW_FSCNT is
port(
    RST                             : in std_logic;
    CLK                             : in std_logic;

    FB_SW_CNT_INFO_IN               : in  std_logic_vector( 1 downto 0);
    FBSW_MANUAL_IN                  : in  std_logic                    ;
    FB_SW_CNT_IN                    : in  std_logic_vector( 5 downto 0);
    FS_IN                           : in  std_logic                    ;

    FBSW_VALID_OUT                  : out std_logic                    ;
    FS_CNT_OUT                      : out std_logic_vector( 5 downto 0)
    );
end FBSW_FSCNT;

architecture arc_FBSW_FSCNT of FBSW_FSCNT is

--< Signal >--
-- Signal
-- _cnt : Counter
-- _flg : Flag
-- _dly : Delay
-- _f#  : Number # clocking
-- _pls : Pulse (Pulse width : 1 clock)

signal fb_sw_info_f1                : std_logic_vector(5 downto 0)  ;
signal fb_section                   : std_logic                     ;
signal fb_valid                     : std_logic                     ;

signal fb_valid1                    : std_logic                     ;
signal fb_valid2                    : std_logic                     ;

signal fs_f1                        : std_logic                     ;
signal fs_rpls                      : std_logic                     ;

signal fs_cnt1                      : std_logic_vector(5 downto 0)  ;
signal fs_cnt2                      : std_logic_vector(5 downto 0)  ;
signal fs_cnt                       : std_logic_vector(5 downto 0)  ;

begin


    Frame_Sync_Rising_Edge : process(RST, CLK)
    begin
        if (RST = '1') then	    
            fs_f1                   <= '0';
            fs_rpls                 <= '0';
        elsif (CLK'event) and (CLK = '1') then
            fs_f1                   <= FS_IN;
            fs_rpls                 <= FS_IN and (not fs_f1);
        end if;
    end process;

    CLOCKING_FB_SW_SEL : process(RST, CLK)
    begin
        if (RST = '1') then
            fb_sw_info_f1           <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            fb_sw_info_f1           <= FB_SW_CNT_IN;
        end if;
    end process;

    DETECT_TRANSITION_FB_SECTION : process(RST, CLK)
    begin
        if (RST = '1') then
            fb_section              <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (FB_SW_CNT_IN = fb_sw_info_f1) then
                fb_section          <= '0';
            else
                fb_section          <= '1';
            end if;
        end if;
    end process;	

    FB_VALID_SIG : process(RST, CLK)
    begin
        if (RST = '1') then
            fb_valid1               <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (fb_section = '1') then
                -- if (FB_SW_CNT_IN = FB_SW_CNT_INFO_IN) then          -- Massive MIMO version ( FB_SW_CNT_INFO_IN = 6 bit )
                -- if (FB_SW_CNT_IN(4 downto 3) = FB_SW_CNT_INFO_IN) then -- Verizon version ( FB_SW_CNT_INFO_IN = 2 bit )
                if ((FB_SW_CNT_IN(2 downto 1) = FB_SW_CNT_INFO_IN) and (FB_SW_CNT_IN(0) = FB_SW_CNT_INFO_IN(0))) then    -- rf2239 version ( FB_SW_CNT_INFO_IN = 2 bit )
                    fb_valid1       <= '1';
                else
                    fb_valid1       <= '0';
                end if;
            else
                fb_valid1           <= fb_valid1; 
            end if;
        end if;
    end process;

    FB_VALID_SIG_TEST : process(RST, CLK)
    begin
        if (RST = '1') then
            fb_valid2               <= '0';
        elsif (CLK'event) and (CLK = '1') then
            -- if (FB_SW_CNT_IN = FB_SW_CNT_INFO_IN) then          -- Massive MIMO version ( FB_SW_CNT_INFO_IN = 6 bit )
            -- if (FB_SW_CNT_IN(4 downto 3) = FB_SW_CNT_INFO_IN) then -- Verizon version ( FB_SW_CNT_INFO_IN = 2 bit )
            if ((FB_SW_CNT_IN(2 downto 1) = FB_SW_CNT_INFO_IN) and (FB_SW_CNT_IN(0) = FB_SW_CNT_INFO_IN(0))) then    -- rf2239 version ( FB_SW_CNT_INFO_IN = 2 bit )
                fb_valid2           <= '1';
            else
                fb_valid2           <= '0';
            end if;
        end if;
    end process;

    FRAME_SYNC_CNT : process(RST, CLK)
    begin	
        if (RST ='1') then
            fs_cnt1                 <= (others => '0');
        elsif (CLK'event) and (CLK = '1')then
            fs_cnt1                 <= FB_SW_CNT_IN;
        end if;
    end process;

    FRAME_SYNC_CNT_MANUAL : process(RST, CLK)
    begin	
        if (RST ='1') then
            fs_cnt2                 <= (others => '0');
        elsif (CLK'event) and (CLK = '1')then
            if (fs_rpls = '1') then
                fs_cnt2             <= fs_cnt2 + '1';
            else
                fs_cnt2             <= fs_cnt2;
            end if;
        end if;
    end process;

    MODE_SEL : process(RST, CLK)
    begin
        if (RST = '1') then
            fb_valid                <= '0';
            fs_cnt                  <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (FBSW_MANUAL_IN = '1') then
                fb_valid            <= fb_valid2; -- manual operation by user
                fs_cnt              <= fs_cnt2;
            else
                fb_valid            <= fb_valid1; -- normal operation
                fs_cnt              <= fs_cnt1;
            end if;
        end if;
    end process;

    FBSW_VALID_OUT                  <= fb_valid;
    FS_CNT_OUT                      <= fs_cnt  ;

end arc_FBSW_FSCNT;


