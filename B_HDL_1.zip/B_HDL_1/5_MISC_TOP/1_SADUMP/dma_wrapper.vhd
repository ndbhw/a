library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity DMA_WRAPPER is
generic(
    DUMP_BUF_NUM                    : natural := 2                              ;
    CPRI_NUM                        : natural := 7
);
port(
    RST                             : in  std_logic                             ;
    CLK_DUMP0                       : in  std_logic                             ;
    CLK_DUMP1                       : in  std_logic                             ;

    DMA_RDEN_IN                     : in  std_logic                             ;
    DMA_WREN_IN                     : in  std_logic                             ;
    DMA_READ_BLK_SEL_IN             : in  std_logic_vector( 7 downto 0)         ;
    DMA_WRITE_BLK_SEL_IN            : in  std_logic_vector( 7 downto 0)         ;
    DMA_BFN_STRB_SEL_IN             : in  std_logic_vector( 7 downto 0)         ;
    DMA_DLY_VALUE_IN                : in  std_logic_vector(23 downto 0)         ;

    -- DMA Interface
    DMA_RDCLK_OUT                   : out std_logic                             ;
    DMA_RDRDY_IN                    : in  std_logic                             ;
    DMA_RDEN_OUT                    : out std_logic                             ;
    DMA_RDATA_IN                    : in  std_logic_vector(31 downto 0)         ;
    DMA_RDEPT_IN                    : in  std_logic                             ;

    DMA_WRCLK_OUT                   : out std_logic                             ;
    DMA_WRRDY_IN                    : in  std_logic                             ;
    DMA_WREN_OUT                    : out std_logic                             ;
    DMA_WDATA_OUT                   : out std_logic_vector(31 downto 0)         ;
    DMA_WRFULL_IN                   : in  std_logic                             ;

    DMA_READ_PTN                    : out std_logic_array32(DUMP_BUF_NUM-1 downto 0);


    RX_BFNSTRB_SYSCTRL_IN           : in  std_logic_vector(CPRI_NUM-1 downto 0) ;
    TX_BFNSTRB_SYSCTRL_IN           : in  std_logic_vector(CPRI_NUM-1 downto 0) ;
    RX_BFNSTRB_CPRI_IN              : in  std_logic_vector(CPRI_NUM-1 downto 0) ;

     --CPRIPHY_TOP(CFPGA)
    DUMP_DATA_CPRIPHY_IN            : in  std_logic_array32(1 downto 0)         ;
    DUMP_DVLD_CPRIPHY_IN            : in  std_logic_vector(1 downto 0)          ;

    TEST_ENB_CPRIPHY_IN             : in  std_logic_vector(1 downto 0)          ;

    --CPRI_TOP(CFPGA,DFPGA)
    DUMP_DATA_CPRI_IN               : in  std_logic_array32(1 downto 0)         ;
    DUMP_DVLD_CPRI_IN               : in  std_logic_vector(1 downto 0)          ;

    TEST_ENB_CPRI_IN                : in  std_logic_vector(1 downto 0)          ;

    --SBIF_TOP(CFPGA,DFPGA)
    DUMP_DATA_SBIF_IN               : in  std_logic_array32(1 downto 0)         ;
    DUMP_DVLD_SBIF_IN               : in  std_logic_vector(1 downto 0)          ;

    TEST_ENB_SBIF_IN                : in  std_logic_vector(1 downto 0)          ;

    --SBIFPHY_TOP(CFPGA,DFPGA)
    DUMP_DATA_SBIFPHY_IN            : in  std_logic_array32(1 downto 0)         ;
    DUMP_DVLD_SBIFPHY_IN            : in  std_logic_vector(1 downto 0)          ;

    TEST_ENB_SBIFPHY_IN             : in  std_logic_vector(1 downto 0)          ;

    --BBCTRL_TOP(DFPGA)
    DUMP_DATA_BBCTRL_IN             : in  std_logic_array32(1 downto 0)         ;
    DUMP_DVLD_BBCTRL_IN             : in  std_logic_vector(1 downto 0)          ;

    TEST_ENB_BBCTRL_IN              : in  std_logic_vector(1 downto 0)          ;

    --DSP_TOP(DFPGA)
    DUMP_DATA_DSP_IN                : in  std_logic_array32(1 downto 0)         ;
    DUMP_DVLD_DSP_IN                : in  std_logic_vector(1 downto 0)          ;

    TEST_ENB_DSP_IN                 : in  std_logic_vector(1 downto 0)          ;

    --DCIF_TOP(DFPGA)
    DUMP_DATA_DCIF_IN               : in  std_logic_array32(1 downto 0)         ;
    DUMP_DVLD_DCIF_IN               : in  std_logic_vector(1 downto 0)          ;
 
    TEST_ENB_DCIF_IN                : in  std_logic_vector(1 downto 0)          

    );
end DMA_WRAPPER;


architecture arc_DMA_WRAPPER of DMA_WRAPPER is

component DMA_STARTOFFSET is
port(
    RST                             : in std_logic                     ; -- RST_CPU         : Input Reset from CPU, Active High
    CLK                             : in std_logic                     ; -- CLK             : READ domain clock

    DMA_BFN_STRB_IN                 : in std_logic                     ; -- FS_IN           : BFN_STROBE, Period 10ms, Duration 260ns
    DMA_DLY_VALUE_IN                : in std_logic_vector(23 downto 0) ; -- BFNSTROBEDLY_IN : 8191 sample frame sync strobe delay
    DMA_READ_ENB_IN                 : in std_logic                     ; -- DUMPSTART_IN    : Dump start 

    DELAYED_BFN_STRB_OUT            : out std_logic
    );
end component;

    signal dma_rd_ready_dc          : std_logic_array3( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dma_rd_empty_dc          : std_logic_array3( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dma_rd_enable_dc         : std_logic_array3( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dma_rd_ready_flag        : std_logic_vector( DUMP_BUF_NUM-1 downto 0) := (others => '0');
    signal dma_rd_empty_flag        : std_logic_vector( DUMP_BUF_NUM-1 downto 0) := (others => '0');
    signal dma_rd_enable_flag       : std_logic_vector( DUMP_BUF_NUM-1 downto 0) := (others => '0');

    signal dma_wr_ready_dc          : std_logic_array3( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dma_wr_full_dc           : std_logic_array3( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dma_wr_enable_dc         : std_logic_array3( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dma_wr_ready_flag        : std_logic_vector( DUMP_BUF_NUM-1 downto 0) := (others => '0');
    signal dma_wr_full_flag         : std_logic_vector( DUMP_BUF_NUM-1 downto 0) := (others => '0');
    signal dma_wr_enable_flag       : std_logic_vector( DUMP_BUF_NUM-1 downto 0) := (others => '0');

    signal dma_rd_blk_sel           : std_logic_array8( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dma_read_en              : std_logic_array1( DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dma_read_data            : std_logic_array32(DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dma_read_data_sh1        : std_logic_array32(DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dma_read_data_sh2        : std_logic_array32(DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));
    signal dma_read_data_sh3        : std_logic_array32(DUMP_BUF_NUM-1 downto 0) := (others => (others => '0'));

    signal dma_wr_blk_sel           : std_logic_array8( DUMP_BUF_NUM-1 downto 0);
    signal dma_write_dvld           : std_logic_array1( DUMP_BUF_NUM-1 downto 0);
    signal dma_write_data           : std_logic_array32(DUMP_BUF_NUM-1 downto 0);

    signal dma_bfn_strb_sel         : std_logic_array8( DUMP_BUF_NUM-1 downto 0);
    signal dma_bfn_strb             : std_logic;
    signal dma_delayed_bfn          : std_logic;

    signal clk_cnt_245p76           : std_logic_vector(2 downto 0);
    signal clk_cnt_307p2            : std_logic_vector(2 downto 0);

begin
    

----------------------------------------------------------------------------------------------------
    -- Case 1) DUMP_BUF_NUM = 1
----------------------------------------------------------------------------------------------------
    G_1_CLK_DOMAIN : if (DUMP_BUF_NUM = 1) generate
    begin

    -------------------------------------------------------------------------------------------
    -- DMA READ process
    -------------------------------------------------------------------------------------------

        DMA_READ_SIG_DC0 : process(RST, CLK_DUMP0)
        begin
            if RST = '1' then
                dma_rd_ready_dc(0)  <= (others => '0');
                dma_rd_empty_dc(0)  <= (others => '0');
                dma_rd_enable_dc(0) <= (others => '0');
                dma_rd_ready_flag(0)<= '0';
                dma_rd_empty_flag(0)<= '0';
                dma_rd_enable_flag(0)<= '0';

            elsif rising_edge(CLK_DUMP0) then
                dma_rd_ready_dc(0)  <= dma_rd_ready_dc(0)(1 downto 0) & DMA_RDRDY_IN; 
                dma_rd_empty_dc(0)  <= dma_rd_empty_dc(0)(1 downto 0) & DMA_RDEPT_IN;
                dma_rd_enable_dc(0) <= dma_rd_enable_dc(0)(1 downto 0) & DMA_RDEN_IN;

                if dma_rd_ready_dc(0)(2 downto 1) = "01" then
                    dma_rd_ready_flag(0)    <= '1';
                elsif dma_rd_ready_dc(0)(2 downto 1) = "10" then
                    dma_rd_ready_flag(0)    <= '0';
                else
                    dma_rd_ready_flag(0)    <= dma_rd_ready_flag(0);
                end if;

                if dma_rd_empty_dc(0)(2 downto 1) = "01" then
                    dma_rd_empty_flag(0)    <= '1';
                elsif dma_rd_empty_dc(0)(2 downto 1) = "10" then
                    dma_rd_empty_flag(0)    <= '0';
                else
                    dma_rd_empty_flag(0)    <= dma_rd_empty_flag(0);
                end if;

                if dma_rd_enable_dc(0)(2 downto 1) = "01" then
                    dma_rd_enable_flag(0)   <= '1';
                elsif dma_rd_enable_Dc(0)(2 downto 1) = "10" then
                    dma_rd_enable_flag(0)   <= '0';
                else
                    dma_rd_enable_flag(0)   <= dma_rd_enable_flag(0);
                end if;

            end if;
        end process;

        DMA_READ_BLK_SEL_CDC : process(RST, CLK_DUMP0)
        begin
            if RST = '1' then
                dma_rd_blk_sel(0)       <= (others => '0');
                dma_bfn_strb_sel(0)     <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if dma_rd_enable_flag(0) = '1' then
                    dma_rd_blk_sel(0)   <= DMA_READ_BLK_SEL_IN;
                    dma_bfn_strb_sel(0) <= DMA_BFN_STRB_SEL_IN;
                else
                    dma_rd_blk_sel(0)   <= dma_rd_blk_sel(0);
                    dma_bfn_strb_sel(0) <= dma_bfn_strb_sel(0);
                end if;
            end if;
        end process;

        READ_PATH_SEL : process(RST, CLK_DUMP0) 
        begin
            if RST = '1' then
                dma_read_en(0)      <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                case (dma_rd_blk_sel(0)) is
                    when  x"10"     => dma_read_en(0)(0) <= TEST_ENB_CPRIPHY_IN(0);
                    when  x"11"     => dma_read_en(0)(0) <= TEST_ENB_CPRIPHY_IN(1);
                    when  x"20"     => dma_read_en(0)(0) <= TEST_ENB_CPRI_IN(0);
                    when  x"21"     => dma_read_en(0)(0) <= TEST_ENB_CPRI_IN(1);
                    when  x"30"     => dma_read_en(0)(0) <= TEST_ENB_BBCTRL_IN(0);
                    when  x"31"     => dma_read_en(0)(0) <= TEST_ENB_BBCTRL_IN(1);
                    when  x"40"     => dma_read_en(0)(0) <= TEST_ENB_DSP_IN(0);
                    when  x"41"     => dma_read_en(0)(0) <= TEST_ENB_DSP_IN(1);
                    when  x"50"     => dma_read_en(0)(0) <= TEST_ENB_DCIF_IN(0);    
                    when  x"51"     => dma_read_en(0)(0) <= TEST_ENB_DCIF_IN(1);    
                    when  x"60"     => dma_read_en(0)(0) <= TEST_ENB_SBIF_IN(0);
                    when  x"61"     => dma_read_en(0)(0) <= TEST_ENB_SBIF_IN(1);
                    when  x"70"     => dma_read_en(0)(0) <= TEST_ENB_SBIFPHY_IN(0);
                    when  x"71"     => dma_read_en(0)(0) <= TEST_ENB_SBIFPHY_IN(1);


                    when others     => dma_read_en(0)    <= (others =>'0');
                end case;
            end if;
        end process;


        
        process(RST,CLK_DUMP0)
        begin
            if RST = '1' then
                dma_read_data(0)    <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if dma_rd_ready_flag(0) = '1' and dma_rd_empty_flag(0) = '0' then
                    dma_read_data(0)<= DMA_RDATA_IN;
                else
                    dma_read_data(0)<= (others => '0');
                end if;
            end if;
        end process;

        -- Delay Configure --
        
        Process(RST,CLK_DUMP0)
        begin
            if RST = '1' then
                dma_read_data_sh1(0)<= (others => '0');
                dma_read_data_sh2(0)<= (others => '0');
                dma_read_data_sh3(0)<= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                dma_read_data_sh1(0)<= dma_read_data(0);
                dma_read_data_sh2(0)<= dma_read_data_sh1(0);
                dma_read_data_sh3(0)<= dma_read_data_sh2(0);
            end if;
        end process;

    -------------------------------------------------------------------------------------------
    -- DMA Start Offset process
    -------------------------------------------------------------------------------------------
        DMA_START_OFFSET : process(RST, CLK_DUMP0)
        begin
            if RST = '1' then
                dma_bfn_strb        <= '0';
            elsif rising_edge(CLK_DUMP0) then
                case (dma_bfn_strb_sel(0)) is
                    when  x"10"     => dma_bfn_strb   <= TX_BFNSTRB_SYSCTRL_IN(0);
                    when  x"11"     => dma_bfn_strb   <= TX_BFNSTRB_SYSCTRL_IN(1);
                    --when  x"12"     => dma_bfn_strb   <= TX_BFNSTRB_SYSCTRL_IN(2);
                    --when  x"13"     => dma_bfn_strb   <= TX_BFNSTRB_SYSCTRL_IN(3);
                    --when  x"14"     => dma_bfn_strb   <= TX_BFNSTRB_SYSCTRL_IN(4);
                    --when  x"15"     => dma_bfn_strb   <= TX_BFNSTRB_SYSCTRL_IN(5);
                    
                    when  x"20"     => dma_bfn_strb   <= RX_BFNSTRB_SYSCTRL_IN(0);
                    when  x"21"     => dma_bfn_strb   <= RX_BFNSTRB_SYSCTRL_IN(1);
                    --when  x"22"     => dma_bfn_strb   <= RX_BFNSTRB_SYSCTRL_IN(2);
                    --when  x"23"     => dma_bfn_strb   <= RX_BFNSTRB_SYSCTRL_IN(3);
                    --when  x"24"     => dma_bfn_strb   <= RX_BFNSTRB_SYSCTRL_IN(4);
                    --when  x"25"     => dma_bfn_strb   <= RX_BFNSTRB_SYSCTRL_IN(5);

                    when  x"30"     => dma_bfn_strb   <= RX_BFNSTRB_CPRI_IN(0);
                    when  x"31"     => dma_bfn_strb   <= RX_BFNSTRB_CPRI_IN(1);
                    --when  x"32"     => dma_bfn_strb   <= RX_BFNSTRB_CPRI_IN(2);
                    --when  x"33"     => dma_bfn_strb   <= RX_BFNSTRB_CPRI_IN(3);
                    --when  x"34"     => dma_bfn_strb   <= RX_BFNSTRB_CPRI_IN(4);
                    --when  x"35"     => dma_bfn_strb   <= RX_BFNSTRB_CPRI_IN(5);

                    when others     => dma_bfn_strb   <= '0';
                end case;
            end if;
        end process;

        u_DMA_STRB_SEL : DMA_STARTOFFSET
        port map(
            RST                     => RST                              , --: in std_logic                     ;
            CLK                     => CLK_DUMP0                        , --: in std_logic                     ;
        
            DMA_BFN_STRB_IN         => dma_bfn_strb                     , --: in std_logic                     ;
            DMA_DLY_VALUE_IN        => DMA_DLY_VALUE_IN                 , --: in std_logic_vector(11 downto 0) ;
            DMA_READ_ENB_IN         => DMA_RDEN_IN                      , --: in std_logic                     ;
        
            DELAYED_BFN_STRB_OUT    => dma_delayed_bfn                    --: out std_logic
            );

        DMA_RDCLK_OUT               <= CLK_DUMP0                            ;
        DMA_RDEN_OUT                <= dma_read_en(0)(0) and dma_delayed_bfn;
        DMA_READ_PTN                <= dma_read_data_sh3                    ;


    -------------------------------------------------------------------------------------------
    -- WRITE process
    -------------------------------------------------------------------------------------------
        DMA_WRITE_SIG_DC0 : process(RST, CLK_DUMP0)
        begin
            if RST = '1' then
                dma_wr_ready_dc(0)  <= (others => '0');
                dma_wr_full_dc(0)   <= (others => '0');
                dma_wr_enable_dc(0) <= (others => '0');
                dma_wr_ready_flag(0)<= '0';
                dma_wr_full_flag(0) <= '0';
                dma_wr_enable_flag(0)<= '0';

            elsif rising_edge(CLK_DUMP0) then
                dma_wr_ready_dc(0)  <= dma_wr_ready_dc(0)(1 downto 0) & DMA_WRRDY_IN; 
                dma_wr_full_dc(0)   <= dma_wr_full_dc(0)(1 downto 0) & DMA_WRFULL_IN;
                dma_wr_enable_dc(0) <= dma_wr_enable_dc(0)(1 downto 0) & DMA_WREN_IN;

                if dma_wr_ready_dc(0)(2 downto 1) = "01" then
                    dma_wr_ready_flag(0)    <= '1';
                elsif dma_wr_ready_dc(0)(2 downto 1) = "10" then
                    dma_wr_ready_flag(0)    <= '0';
                else
                    dma_wr_ready_flag(0)    <= dma_wr_ready_flag(0);
                end if;

                if dma_wr_full_dc(0)(2 downto 1) = "01" then
                    dma_wr_full_flag(0)     <= '1';
                elsif dma_wr_full_dc(0)(2 downto 1) = "10" then
                    dma_wr_full_flag(0)     <= '0';
                else
                    dma_wr_full_flag(0)     <= dma_wr_full_flag(0);
                end if;

                if dma_wr_enable_dc(0)(2 downto 1) = "01" then
                    dma_wr_enable_flag(0)   <= '1';
                elsif dma_wr_enable_dc(0)(2 downto 1) = "10" then
                    dma_wr_enable_flag(0)   <= '0';
                else
                    dma_wr_enable_flag(0)   <= dma_wr_enable_flag(0);
                end if;

            end if;
        end process;

        DMA_WRITE_BLK_SEL_CDC : process(RST, CLK_DUMP0)
        begin
            if RST = '1' then
                dma_wr_blk_sel(0)       <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if dma_wr_enable_flag(0) = '1' then
                    dma_wr_blk_sel(0)   <= DMA_WRITE_BLK_SEL_IN;
                else             
                    dma_wr_blk_sel(0)   <= dma_wr_blk_sel(0);
                end if;
            end if;
        end process;

        WRITE_PATH_SEL : process(RST, CLK_DUMP0)
        begin
            if RST = '1' then
                dma_write_data(0)   <= (others => '0');
                dma_write_dvld(0)   <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                case (dma_wr_blk_sel(0)) is
                    when  x"10"     => dma_write_data(0)   <= DUMP_DATA_CPRIPHY_IN(0);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_CPRIPHY_IN(0);
                    when  x"11"     => dma_write_data(0)   <= DUMP_DATA_CPRIPHY_IN(1);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_CPRIPHY_IN(1);
                    when  x"20"     => dma_write_data(0)   <= DUMP_DATA_CPRI_IN(0);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_CPRI_IN(0);
                    when  x"21"     => dma_write_data(0)   <= DUMP_DATA_CPRI_IN(1);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_CPRI_IN(1);                                       
                    when  x"30"     => dma_write_data(0)   <= DUMP_DATA_BBCTRL_IN(0);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_BBCTRL_IN(0);
                    when  x"31"     => dma_write_data(0)   <= DUMP_DATA_BBCTRL_IN(1);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_BBCTRL_IN(1);                                       
                    when  x"40"     => dma_write_data(0)   <= DUMP_DATA_DSP_IN(0);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_DSP_IN(0);
                    when  x"41"     => dma_write_data(0)   <= DUMP_DATA_DSP_IN(1);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_DSP_IN(1);                                       
                    when  x"50"     => dma_write_data(0)   <= DUMP_DATA_DCIF_IN(0);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_DCIF_IN(0);
                    when  x"51"     => dma_write_data(0)   <= DUMP_DATA_DCIF_IN(1);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_DCIF_IN(1);                                       
                    when  x"60"     => dma_write_data(0)   <= DUMP_DATA_SBIF_IN(0);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_SBIF_IN(0);
                    when  x"61"     => dma_write_data(0)   <= DUMP_DATA_SBIF_IN(1);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_SBIF_IN(1);                                       
                    when  x"70"     => dma_write_data(0)   <= DUMP_DATA_SBIFPHY_IN(0);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_SBIFPHY_IN(0);
                    when  x"71"     => dma_write_data(0)   <= DUMP_DATA_SBIFPHY_IN(1);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_SBIFPHY_IN(1);                                       
                    when others     => dma_write_data(0)   <= (others => '0');
                                       dma_write_dvld(0)   <= (others => '0');
                end case;
            end if;
        end process;
        


        DMA_WRCLK_OUT               <= CLK_DUMP0           ; --: out std_logic                             ;
        DMA_WREN_OUT                <= dma_write_dvld(0)(0); --: out std_logic                             ;
        DMA_WDATA_OUT               <= dma_write_data(0)   ; --: out std_logic_vector(31 downto 0)         ;

    end generate;

----------------------------------------------------------------------------------------------------
    -- Case 2) DUMP_BUF_NUM = 2
----------------------------------------------------------------------------------------------------

    G_2_CLK_DOMAIN : if (DUMP_BUF_NUM = 2) generate
    begin

    -------------------------------------------------------------------------------------------
    -- DMA READ process
    -------------------------------------------------------------------------------------------

        DMA_READ_SIG_DC0 : process(RST, CLK_DUMP0)
        begin
            if RST = '1' then
                dma_rd_ready_dc(0)  <= (others => '0');
                dma_rd_empty_dc(0)  <= (others => '0');
                dma_rd_enable_dc(0) <= (others => '0');
                dma_rd_ready_flag(0)<= '0';
                dma_rd_empty_flag(0)<= '0';
                dma_rd_enable_flag(0)<= '0';

            elsif rising_edge(CLK_DUMP0) then
                dma_rd_ready_dc(0)  <= dma_rd_ready_dc(0)(1 downto 0) & DMA_RDRDY_IN; 
                dma_rd_empty_dc(0)  <= dma_rd_empty_dc(0)(1 downto 0) & DMA_RDEPT_IN;
                dma_rd_enable_dc(0) <= dma_rd_enable_dc(0)(1 downto 0) & DMA_RDEN_IN;

                if dma_rd_ready_dc(0)(2 downto 1) = "01" then
                    dma_rd_ready_flag(0)    <= '1';
                elsif dma_rd_ready_dc(0)(2 downto 1) = "10" then
                    dma_rd_ready_flag(0)    <= '0';
                else
                    dma_rd_ready_flag(0)    <= dma_rd_ready_flag(0);
                end if;

                if dma_rd_empty_dc(0)(2 downto 1) = "01" then
                    dma_rd_empty_flag(0)    <= '1';
                elsif dma_rd_empty_dc(0)(2 downto 1) = "10" then
                    dma_rd_empty_flag(0)    <= '0';
                else
                    dma_rd_empty_flag(0)    <= dma_rd_empty_flag(0);
                end if;

                if dma_rd_enable_dc(0)(2 downto 1) = "01" then
                    dma_rd_enable_flag(0)   <= '1';
                elsif dma_rd_enable_dc(0)(2 downto 1) = "10" then
                    dma_rd_enable_flag(0)   <= '0';
                else
                    dma_rd_enable_flag(0)   <= dma_rd_enable_flag(0);
                end if;

            end if;
        end process;

        DMA_READ_BLK_SEL_CDC0 : process(RST, CLK_DUMP0)
        begin
            if RST = '1' then
                dma_rd_blk_sel(0)       <= (others => '0');
                dma_bfn_strb_sel(0)     <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if dma_rd_enable_flag(0) = '1' then
                    dma_rd_blk_sel(0)   <= DMA_READ_BLK_SEL_IN;
                    dma_bfn_strb_sel(0) <= DMA_BFN_STRB_SEL_IN;
                else
                    dma_rd_blk_sel(0)   <= dma_rd_blk_sel(0);
                    dma_bfn_strb_sel(0) <= dma_bfn_strb_sel(0);
                end if;
            end if;
        end process;

        READ_PATH_SEL0 : process(RST, CLK_DUMP0) 
        begin
            if RST = '1' then
                dma_read_en(0)      <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                case (dma_rd_blk_sel(0)) is
                    when  x"10"     => dma_read_en(0)(0)  <= TEST_ENB_CPRIPHY_IN(0);
                    when  x"20"     => dma_read_en(0)(0)  <= TEST_ENB_CPRI_IN(0);
                    when  x"30"     => dma_read_en(0)(0)  <= TEST_ENB_BBCTRL_IN(0);
                    when  x"40"     => dma_read_en(0)(0)  <= TEST_ENB_DSP_IN(0);
                    when  x"50"     => dma_read_en(0)(0)  <= TEST_ENB_DCIF_IN(0);
                    when  x"60"     => dma_read_en(0)(0)  <= TEST_ENB_SBIF_IN(0);
                    when  x"70"     => dma_read_en(0)(0)  <= TEST_ENB_SBIFPHY_IN(0);

                    when others     => dma_read_en(0)     <= (others => '0');
                end case;
            end if;
        end process;

        process(RST,CLK_DUMP0)
        begin
            if RST = '1' then
                dma_read_data(0)    <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if dma_rd_ready_flag(0) = '1' and dma_rd_empty_flag(0) = '0' then
                    dma_read_data(0)<= DMA_RDATA_IN;
                else
                    dma_read_data(0)<= (others => '0');
                end if;
            end if;
        end process;

        Process(RST,CLK_DUMP0)
        begin
            if RST = '1' then
                dma_read_data_sh1(0)<= (others => '0');
                dma_read_data_sh2(0)<= (others => '0');
                dma_read_data_sh3(0)<= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                dma_read_data_sh1(0)<= dma_read_data(0);
                dma_read_data_sh2(0)<= dma_read_data_sh1(0);
                dma_read_data_sh3(0)<= dma_read_data_sh2(0);
            end if;
        end process;
        
        DMA_START_OFFSET : process(RST, CLK_DUMP0)
        begin
            if RST = '1' then
                dma_bfn_strb        <= '0';
            elsif rising_edge(CLK_DUMP0) then
                case (dma_bfn_strb_sel(0)) is
                    when  x"10"     => dma_bfn_strb   <= TX_BFNSTRB_SYSCTRL_IN(0);
                    when  x"11"     => dma_bfn_strb   <= TX_BFNSTRB_SYSCTRL_IN(1);
                    --when  x"12"     => dma_bfn_strb   <= TX_BFNSTRB_SYSCTRL_IN(2);
                    --when  x"13"     => dma_bfn_strb   <= TX_BFNSTRB_SYSCTRL_IN(3);
                    --when  x"14"     => dma_bfn_strb   <= TX_BFNSTRB_SYSCTRL_IN(4);
                    --when  x"15"     => dma_bfn_strb   <= TX_BFNSTRB_SYSCTRL_IN(5);
                    
                    when  x"20"     => dma_bfn_strb   <= RX_BFNSTRB_SYSCTRL_IN(0);
                    when  x"21"     => dma_bfn_strb   <= RX_BFNSTRB_SYSCTRL_IN(1);
                    --when  x"22"     => dma_bfn_strb   <= RX_BFNSTRB_SYSCTRL_IN(2);
                    --when  x"23"     => dma_bfn_strb   <= RX_BFNSTRB_SYSCTRL_IN(3);
                    --when  x"24"     => dma_bfn_strb   <= RX_BFNSTRB_SYSCTRL_IN(4);
                    --when  x"25"     => dma_bfn_strb   <= RX_BFNSTRB_SYSCTRL_IN(5);

                    when  x"30"     => dma_bfn_strb   <= RX_BFNSTRB_CPRI_IN(0);
                    when  x"31"     => dma_bfn_strb   <= RX_BFNSTRB_CPRI_IN(1);
                    --when  x"32"     => dma_bfn_strb   <= RX_BFNSTRB_CPRI_IN(2);
                    --when  x"33"     => dma_bfn_strb   <= RX_BFNSTRB_CPRI_IN(3);
                    --when  x"34"     => dma_bfn_strb   <= RX_BFNSTRB_CPRI_IN(4);
                    --when  x"35"     => dma_bfn_strb   <= RX_BFNSTRB_CPRI_IN(5);

                    when others     => dma_bfn_strb   <= '0';
                end case;
            end if;
        end process;

        u_DMA_STRB_SEL : DMA_STARTOFFSET
        port map(
            RST                     => RST                              , --: in std_logic                     ;
            CLK                     => CLK_DUMP0                        , --: in std_logic                     ;
        
            DMA_BFN_STRB_IN         => dma_bfn_strb                     , --: in std_logic                     ;
            DMA_DLY_VALUE_IN        => DMA_DLY_VALUE_IN                 , --: in std_logic_vector(11 downto 0) ;
            DMA_READ_ENB_IN         => DMA_RDEN_IN                      , --: in std_logic                     ;
        
            DELAYED_BFN_STRB_OUT    => dma_delayed_bfn                    --: out std_logic
            );


        DMA_RDCLK_OUT               <= CLK_DUMP0                            ;
        DMA_RDEN_OUT                <= dma_read_en(0)(0) and dma_delayed_bfn;
        DMA_READ_PTN                <= dma_read_data_sh3                    ;

    -------------------------------------------------------------------------------------------
    -- WRITE process
    -------------------------------------------------------------------------------------------
        DMA_WRITE_SIG_DC0 : process(RST, CLK_DUMP0)
        begin
            if RST = '1' then
                dma_wr_ready_dc(0)  <= (others => '0');
                dma_wr_full_dc(0)   <= (others => '0');
                dma_wr_enable_dc(0) <= (others => '0');
                dma_wr_ready_flag(0)<= '0';
                dma_wr_full_flag(0) <= '0';
                dma_wr_enable_flag(0)<= '0';

            elsif rising_edge(CLK_DUMP0) then
                dma_wr_ready_dc(0)  <= dma_wr_ready_dc(0)(1 downto 0) & DMA_WRRDY_IN; 
                dma_wr_full_dc(0)   <= dma_wr_full_dc(0)(1 downto 0) & DMA_WRFULL_IN;
                dma_wr_enable_dc(0) <= dma_wr_enable_dc(0)(1 downto 0) & DMA_WREN_IN;

                if dma_wr_ready_dc(0)(2 downto 1) = "01" then
                    dma_wr_ready_flag(0)    <= '1';
                elsif dma_wr_ready_dc(0)(2 downto 1) = "10" then
                    dma_wr_ready_flag(0)    <= '0';
                else
                    dma_wr_ready_flag(0)    <= dma_wr_ready_flag(0);
                end if;

                if dma_wr_full_dc(0)(2 downto 1) = "01" then
                    dma_wr_full_flag(0)     <= '1';
                elsif dma_wr_full_dc(0)(2 downto 1) = "10" then
                    dma_wr_full_flag(0)     <= '0';
                else
                    dma_wr_full_flag(0)     <= dma_wr_full_flag(0);
                end if;

                if dma_wr_enable_dc(0)(2 downto 1) = "01" then
                    dma_wr_enable_flag(0)   <= '1';
                elsif dma_wr_enable_dc(0)(2 downto 1) = "10" then
                    dma_wr_enable_flag(0)   <= '0';
                else
                    dma_wr_enable_flag(0)   <= dma_wr_enable_flag(0);
                end if;

            end if;
        end process;

        DMA_WRITE_BLK_SEL_CDC0 : process(RST, CLK_DUMP0)
        begin
            if RST = '1' then
                dma_wr_blk_sel(0)       <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if dma_wr_enable_flag(0) = '1' then
                    dma_wr_blk_sel(0)   <= DMA_WRITE_BLK_SEL_IN;
                else             
                    dma_wr_blk_sel(0)   <= dma_wr_blk_sel(0);
                end if;
            end if;
        end process;

        --DMA_WRITE_SIG_DC1 : process(RST, CLK_DUMP1)
        --begin
        --    if RST = '1' then
        --        dma_wr_ready_dc(1)  <= (others => '0');
        --        dma_wr_full_dc(1)   <= (others => '0');
        --        dma_wr_enable_dc(1) <= (others => '0');
        --        dma_wr_ready_flag(1)<= '0';
        --        dma_wr_full_flag(1) <= '0';
        --        dma_wr_enable_flag(1)<= '0';

        --    elsif rising_edge(CLK_DUMP1) then
        --        dma_wr_ready_dc(1)  <= dma_wr_ready_dc(1)(1 downto 0) & DMA_WRRDY_IN; 
        --        dma_wr_full_dc(1)   <= dma_wr_full_dc(1)(1 downto 0) & DMA_WRFULL_IN;
        --        dma_wr_enable_dc(1) <= dma_wr_enable_dc(1)(1 downto 0) & DMA_WREN_IN;

        --        if dma_wr_ready_dc(1)(2 downto 1) = "01" then
        --            dma_wr_ready_flag(1)    <= '1';
        --        elsif dma_wr_ready_dc(1)(2 downto 1) = "10" then
        --            dma_wr_ready_flag(1)    <= '0';
        --        else
        --            dma_wr_ready_flag(1)    <= dma_wr_ready_flag(1);
        --        end if;

        --        if dma_wr_full_dc(1)(2 downto 1) = "01" then
        --            dma_wr_full_flag(1)     <= '1';
        --        elsif dma_wr_full_dc(1)(2 downto 1) = "10" then
        --            dma_wr_full_flag(1)     <= '0';
        --        else
        --            dma_wr_full_flag(1)     <= dma_wr_full_flag(1);
        --        end if;

        --        if dma_wr_enable_dc(1)(2 downto 1) = "01" then
        --            dma_wr_enable_flag(1)   <= '1';
        --        elsif dma_wr_enable_dc(1)(2 downto 1) = "10" then
        --            dma_wr_enable_flag(1)   <= '0';
        --        else
        --            dma_wr_enable_flag(1)   <= dma_wr_enable_flag(1);
        --        end if;

        --        --if dma_wr_ready_flag(0) = '1' and dma_wr_full_flag(0) = '0' then
        --        --    dma_wren_dc(0)  <= dma_wren_dc(0)(1 downto 0) <= DMA_WREN_IN;
        --        --else
        --        --    dma_wren_dc(0)  <= (others => '0');
        --        --end if;

        --    end if;
        --end process;

        --DMA_WRITE_BLK_SEL_CDC1 : process(RST, CLK_DUMP1)
        --begin
        --    if RST = '1' then
        --        dma_wr_blk_sel(1)       <= (others => '0');
        --    elsif rising_edge(CLK_DUMP1) then
        --        if dma_wr_enable_flag(1) = '1' then
        --            dma_wr_blk_sel(1)   <= DMA_WRITE_BLK_SEL_IN;
        --        else             
        --            dma_wr_blk_sel(1)   <= dma_wr_blk_sel(1);
        --        end if;
        --    end if;
        --end process;


        WRITE_PATH_SEL0 : process(RST, CLK_DUMP0) 
        begin
            if RST = '1' then
                dma_write_data(0)   <= (others => '0');
                dma_write_dvld(0)   <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                case (dma_wr_blk_sel(0)) is
                    when  x"10"     => dma_write_data(0)   <= DUMP_DATA_CPRIPHY_IN(0);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_CPRIPHY_IN(0); 
                    when  x"20"     => dma_write_data(0)   <= DUMP_DATA_CPRI_IN(0);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_CPRI_IN(0);
                    when  x"30"     => dma_write_data(0)   <= DUMP_DATA_BBCTRL_IN(0);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_BBCTRL_IN(0); 
                    when  x"40"     => dma_write_data(0)   <= DUMP_DATA_DSP_IN(0);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_DSP_IN(0);
                    when  x"50"     => dma_write_data(0)   <= DUMP_DATA_DCIF_IN(0);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_DCIF_IN(0); 
                    when  x"60"     => dma_write_data(0)   <= DUMP_DATA_SBIF_IN(0);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_SBIF_IN(0); 
                    when  x"70"     => dma_write_data(0)   <= DUMP_DATA_SBIFPHY_IN(0);
                                       dma_write_dvld(0)(0)<= DUMP_DVLD_SBIFPHY_IN(0); 
                    when others     => dma_write_data(0)   <= (others => '0');
                                       dma_write_dvld(0)   <= (others => '0'); 
                end case;
            end if;
        end process;

        --WRITE_PATH_SEL1 : process(RST, CLK_DUMP1)
        --begin
        --    if RST = '1' then
        --        dma_write_data(1)   <= (others => '0');
        --        dma_write_dvld(1)   <= (others => '0');
        --    elsif rising_edge(CLK_DUMP1) then
        --        case (dma_wr_blk_sel(1)) is
        --            when  x"11"     => dma_write_data(1)   <= DUMP_DATA_CPRIPHY_IN(1);
        --                               dma_write_dvld(1)(0)<= DUMP_DVLD_CPRIPHY_IN(1); 
        --            when  x"21"     => dma_write_data(1)   <= DUMP_DATA_CPRI_IN(1);
        --                               dma_write_dvld(1)(0)<= DUMP_DVLD_CPRI_IN(1);
        --            when  x"31"     => dma_write_data(1)   <= DUMP_DATA_BBCTRL_IN(1);
        --                               dma_write_dvld(1)(0)<= DUMP_DVLD_BBCTRL_IN(1); 
        --            when  x"41"     => dma_write_data(1)   <= DUMP_DATA_DSP_IN(1);
        --                               dma_write_dvld(1)(0)<= DUMP_DVLD_DSP_IN(1);
        --            when  x"51"     => dma_write_data(1)   <= DUMP_DATA_DCIF_IN(1);
        --                               dma_write_dvld(1)(0)<= DUMP_DVLD_DCIF_IN(1);
        --            when  x"61"     => dma_write_data(1)   <= DUMP_DATA_SBIF_IN(1);
        --                               dma_write_dvld(1)(0)<= DUMP_DVLD_SBIF_IN(1); 
        --            when  x"71"     => dma_write_data(1)   <= DUMP_DATA_SBIFPHY_IN(1);
        --                               dma_write_dvld(1)(0)<= DUMP_DVLD_SBIFPHY_IN(1); 
        --            when others     => dma_write_data(1)   <= (others => '0');
        --                               dma_write_dvld(1)   <= (others => '0'); 
        --        end case;
        --    end if;
        --end process;

        DMA_WRCLK_OUT               <= CLK_DUMP0            ;--when dma_wr_blk_sel(1)(0) = '0' else CLK_DUMP1;
        DMA_WREN_OUT                <= dma_write_dvld(0)(0) ;--when dma_wr_blk_sel(1)(0) = '0' else dma_write_dvld(1)(0);
        DMA_WDATA_OUT               <= dma_write_data(0)    ;--when dma_wr_blk_sel(1)(0) = '0' else dma_write_data(1);


    end generate;

end arc_DMA_WRAPPER;
