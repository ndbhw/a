library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity SA_CTRL_ADV is
port(
    RST                : in std_logic;
    CLK                : in std_logic;

    SA_ST_CONDITION_IN : in std_logic; --    SA_ST_CONTDITION_IN  : Spectrim Analyzer Start condition

    FBSW_VALID_IN      : in std_logic;
    FS_CNT_IN          : in std_logic_vector(5 downto 0);

    SA_VALID_OUT       : out std_logic
    );
end SA_CTRL_ADV;

architecture arc_SA_CTRL_ADV of SA_CTRL_ADV is

signal sa_valid : std_logic;

begin

    DECISION_SA : process(RST, CLK)
    begin
        if (RST = '1') then
            sa_valid <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (SA_ST_CONDITION_IN = '0') then
                sa_valid <= '0';
            else
                sa_valid <= FBSW_VALID_IN;
            end if;
        end if;
    end process;

    SA_VALID_OUT <= sa_valid; 

end arc_SA_CTRL_ADV;
