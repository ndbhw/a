library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

--< Entity >--------------------------------------------------------------------
entity DMA_DLY_SET is
----< Generic >----
--generic(
--    );
----< Port >----
port(
    --< RESET >--
    RST           : in std_logic;                                              -- RST : Reset, Active high

    --< Clock >--
    CLK           : in std_logic;                                              -- CLK : Input clock

    --< Time Information >--
    BFN_STROBE_IN : in std_logic;                                              -- BFN_STROBE_IN : sync 122.88MHz, Period 10ms, pulsewidth 3.84MHz

    --< CPU Offset >--
    DLYVALUE_IN   : in std_logic_vector(23 downto 0);                          -- DLYVALUE_IN   : Delay value

    FS_DLY_OUT    : out std_logic
    );
end DMA_DLY_SET;

--< Architecture >-------------------------------------------------------------
architecture arc_DMA_DLY_SET of DMA_DLY_SET is

----< Signal >----
-- _f#  : #number clk delay signal by filp-flop or register
-- pls  : 1 clock pulse
-- rpls : 1 clock rising edge pulse
-- npls : 1 clock negative edge pulse
-- _lat : Latch signal

signal FS_IN_f        : std_logic_vector(2 downto 0);
signal fs_rpls_f2     : std_logic;
signal fs_rpls_f2_flag: std_logic;
signal fs_flag        : std_logic;

signal cnt_10ms       : std_logic_vector(21 downto 0);

signal fs_dly         : std_logic;
signal i_fs_dly       : std_logic;




----< Process >----
begin

    FS_Clocking : process(RST, CLK)
    begin
        if (RST = '1') then
            FS_IN_f <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            FS_IN_f <= FS_IN_f(1 downto 0) & BFN_STROBE_IN;
        end if;
    end process;

    Frame_Sync_Flag : process(RST ,CLK)
    begin
        if RST = '1' then
            fs_flag <= '0';
        elsif rising_edge(CLK) then
            if fs_rpls_f2 = '1' then
                fs_flag <= '1';
            else
                fs_flag <= fs_flag;
            end if;
        end if;
    end process;


    GEN_FS_pulse : process(RST, CLK)
    begin
        if (RST = '1') then
            fs_rpls_f2 <= '0';
            fs_rpls_f2_flag <= '0';
        elsif (CLK'event) and (CLK = '1') then
            fs_rpls_f2 <= FS_IN_f(1) and (not FS_IN_f(2));
            if fs_rpls_f2 = '1' then
                fs_rpls_f2_flag <= '1';
            else
                fs_rpls_f2_flag <= fs_rpls_f2_flag;
            end if;
        end if;
    end process;

    COUNT_8K : process(RST, CLK)
    begin
        if (RST = '1') then
            cnt_10ms <= (others => '1');
        elsif (CLK'event) and (CLK = '1') then
            if (fs_rpls_f2_flag = '1') then
                if fs_rpls_f2 = '1' then
                    cnt_10ms <= (others => '0');
                else
                    cnt_10ms <= cnt_10ms + '1';
                end if;
            else
                cnt_10ms <= (others => '0');
            end if;
        end if;
    end process; 

    GEN_DLY_SIG : process(RST, CLK)
    begin
        if (RST = '1') then
            fs_dly <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if fs_rpls_f2_flag = '1' then
                if DLYVALUE_IN = cnt_10ms then
                    fs_dly <= '1';
                else
                    fs_dly <= '0';
                end if;
            else
                fs_dly <= '0';
            end if;
        end if;
    end process;

    process(RST, CLK)
    begin
        if RST = '1' then
            i_fs_dly <= '0';
        elsif rising_edge(CLK) then
            if fs_dly = '1' then
                i_fs_dly <= '1';
            else
                i_fs_dly <= i_fs_dly;
            end if;
        end if;
    end process;

                        

    FS_DLY_OUT <= i_fs_dly;

end arc_DMA_DLY_SET;
