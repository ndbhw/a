library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity BUFFER_WRAPPER is
generic(
    FIXED_PTN_USAGE                 : boolean                               ;
    POLY_PHASE_USAGE                : boolean
    );
port(
    RST                             : in  std_logic                         ;
    CLK_CPU                         : in  std_logic                         ;
    CLK_DUMP                        : in  std_logic                         ;

    DUMP_BUF_SEL_IN                 : in  std_logic                         ;
    DUMP_START_IN                   : in  std_logic                         ;

    FS_DLY_IN                       : in  std_logic                         ;
    DUMPDONE_OUT                    : out std_logic                         ;

    FIXED_PTN_VALID_IN              : in  std_logic                         ;
    FIXED_PTN_GEN_EN_IN             : in  std_logic                         ;
    FIXED_PTN_START_IN              : in  std_logic                         ;
    FIXED_PTN_LENGTH_IN             : in  std_logic_vector(12 downto 0)     ;
    PHASE_SEL_IN                    : in  std_logic                         ;

    TEST_PTN_VALID_OUT              : out std_logic                         ;
    GEN_RDATA_OUT                   : out std_logic_vector(31 downto 0)     ;

    DUMP_WRVAL_IN                   : in  std_logic                         ;
    DUMP_WRDATA_IN                  : in  std_logic_vector(31 downto 0)     ;
    DUMP_ODD_WRDATA_IN              : in  std_logic_vector(31 downto 0)     ;

    RDATA_MEMORY_SEL_IN             : in  std_logic                         ;
    WREN_CPU_IN                     : in  std_logic                         ;
    RDEN_CPU_IN                     : in  std_logic                         ;
    WDATA_CPU_IN                    : in  std_logic_vector(31 downto 0)     ;
    ADDRL13B_IN                     : in  std_logic_vector(12 downto 0)     ;
    RDATA_CPU_OUT                   : out std_logic_vector(31 downto 0)
    );
end BUFFER_WRAPPER;

architecture arc_BUFFER_WRAPPER of BUFFER_WRAPPER is

component RST_SYNC is
generic (
    DLY_NUM                          : natural := 4;    -- Number of delay.
    MAX_FANOUT_NUM                   : integer := 200   -- Number of maximum fanout
);
port (
    RST_IN                           : in  std_logic;   -- Active high asynchronous reset
    CLK                              : in  std_logic;   -- clock to be sync'ed to
    RST_OUT                          : out std_logic    -- "Synchronised" reset signal
);         
end component;

component DUMPVAL 
port(
    RST                             : in std_logic; 
    CLK                             : in std_logic; 
    DUMP_START_IN                   : in std_logic; 
    FS_DLY_IN                       : in std_logic; 
    DUMPDONE_IN                     : in std_logic; 

    DUMPVAL_OUT                     : out std_logic_vector(1 downto 0)  
    );
end component;

component UPCNT_ADDR 
port(
    RST                             : in std_logic; 
    CLK                             : IN STD_LOGIC;
    DUMPVAL_IN                      : in std_logic_vector(1 downto 0); 
    WRVAL_SIG_IN                    : in std_logic; 
    DUMP_BUF_SEL_IN                 : in std_logic; 

    WREN_OUT                        : out std_logic;
    ADDR_DUMP_OUT                   : out std_logic_vector(12 downto 0)       
    );
END component;

component DUMPDONE_BLK 
port(
    RST                             : in std_logic; 
    CLK                             : in std_logic; 
    DUMP_START_IN                   : in std_logic; 
    ADDR_DUMP                       : in std_logic_vector(12 downto 0); 
    WRVAL                           : in std_logic; 

    DUMPDONE_OUT                    : out std_logic                      
    );
end component;

component TEST_PTN_ADDR_GEN is
port(
    RST                             : in  std_logic;
    CLK                             : in  std_logic;
    
    TEST_ENB_IN                     : in  std_logic;
    TEST_PTN_GEN_ENB                : in  std_logic;
    TEST_PTN_START                  : in  std_logic;
    TEST_PTN_LENGTH                 : in  std_logic_vector(12 downto 0);

    TEST_PTN_VALID_DLY              : out std_logic_vector( 0 downto 0);

    PTN_GEN_ADDR                    : out std_logic_vector(12 downto 0)
    );
end component;

component TRUE_DPRAM_DUALCLK is
generic(
    DATA_WIDTH                      : natural := 32;
    ADDR_WIDTH                      : natural := 10 
    );
port(
    CLK_A                           : in  std_logic;
    EN_A                            : in  std_logic := '1';
    WE_A                            : in  std_logic := '1';
    ADDR_A                          : in  std_logic_vector((ADDR_WIDTH-1) downto 0);
    DATA_A                          : in  std_logic_vector((DATA_WIDTH-1) downto 0);
    Q_A	                            : out std_logic_vector((DATA_WIDTH-1) downto 0);

    CLK_B                           : in  std_logic;
    EN_B                            : in  std_logic := '1';
    WE_B                            : in  std_logic := '1';
    ADDR_B                          : in  std_logic_vector((ADDR_WIDTH-1) downto 0);
    DATA_B                          : in  std_logic_vector((DATA_WIDTH-1) downto 0);
    Q_B	                            : out std_logic_vector((DATA_WIDTH-1) downto 0)
    );
end component;

    signal rst_dump                 : std_logic;
    signal bufsel_sh                : std_logic_vector( 2 downto 0);
    --signal buf_a_en                 : std_logic := '0';
    
    signal dumpstart_sh             : std_logic_vector( 2 downto 0);
    
    signal dump_wren                : std_logic                     :=            '0' ;
    signal dump_addr                : std_logic_vector(12 downto 0) := (others => '0');
    signal dump_done                : std_logic                     :=            '0' ;
    signal dump_val                 : std_logic_vector( 1 downto 0) := (others => '0');
    
    signal ptn_gen_en_sh            : std_logic_vector( 2 downto 0) := (others => '0');
    signal ptn_gen_en               : std_logic := '0';
    signal ptn_gen_en_rpls          : std_logic := '0';
    signal ptn_length_cdc           : std_logic_vector(12 downto 0) := (others => '0');
    signal ptn_start_sh             : std_logic_vector( 2 downto 0) := (others => '0');
    
    signal ptn_valid_d              : std_logic_vector( 0 downto 0) := (others => '0');
    signal ptn_addr                 : std_logic_vector(12 downto 0) := (others => '0');

    signal i_dump_wrdata            : std_logic_vector(31 downto 0);
    signal i_dump_odd_wrdata        : std_logic_vector(31 downto 0);
    
    signal sw_dump_start            : std_logic                    ;
    
    signal sw_dump_rd_en            : std_logic                    ;
    signal sw_dump_wr_en            : std_logic                    ;
    signal sw_dump_addr             : std_logic_vector(12 downto 0);
    signal sw_dump_wr_data          : std_logic_vector(31 downto 0);
    signal sw_dump_wr_odd_data      : std_logic_vector(31 downto 0);
    signal sw_dump_rd_data          : std_logic_vector(31 downto 0);
    signal sw_dump_rd_odd_data      : std_logic_vector(31 downto 0);
    
    signal sw_cpu_en                : std_logic := '0';
    
    signal sw_cpu_wr_en             : std_logic;
    signal sw_cpu_addr              : std_logic_vector(12 downto 0);
    signal sw_cpu_wr_data           : std_logic_vector(31 downto 0);
    signal sw_cpu_rd_data           : std_logic_vector(31 downto 0);

    -- Support Poly Phase signal
    signal sw_cpu_rd_data_odd       : std_logic_vector(31 downto 0) := (others => '0');
    signal i_cpu_rd_data_poly       : std_logic_vector(31 downto 0) := (others => '0');

    signal i_addrl13b_d1            : std_logic_vector(12 downto 0) := (others => '0');
    signal i_addrl13b_d2            : std_logic_vector(12 downto 0) := (others => '0');
    signal i_sw_cpu_en_d1           : std_logic                     :=            '0' ;
    signal i_sw_cpu_en_d2           : std_logic                     :=            '0' ;

begin

    U_RST_SYNC : RST_SYNC generic map(4 , 200 ) port map(RST, CLK_DUMP, rst_dump);


    process(rst_dump, CLK_DUMP) 
    begin
        if (rst_dump = '1') then
            bufsel_sh               <= (others => '0');
            dumpstart_sh            <= (others => '0');
        elsif (CLK_DUMP'event) and (CLK_DUMP = '1') then
            bufsel_sh               <= bufsel_sh(1 downto 0) & DUMP_BUF_SEL_IN;
            dumpstart_sh            <= dumpstart_sh(1 downto 0) & DUMP_START_IN;
        end if;
    end process;

    DATA_VALID_SYNC : process(rst_dump, CLK_DUMP) 
    begin
        if (rst_dump = '1') then
            i_dump_wrdata           <= (others => '0');
            i_dump_odd_wrdata       <= (others => '0');
        elsif (CLK_DUMP'event) and (CLK_DUMP = '1') then
            i_dump_wrdata           <= DUMP_WRDATA_IN    ;
            i_dump_odd_wrdata       <= DUMP_ODD_WRDATA_IN;
        end if;
    end process;

    U_DUMPSTATE0_GEN : DUMPVAL 
    port map(
        RST                         => rst_dump                 , -- : in std_logic                   
        CLK                         => CLK_DUMP                 , -- : in std_logic                   
        
        DUMP_START_IN               => sw_dump_start            , -- : in std_logic                   
        FS_DLY_IN                   => FS_DLY_IN                , -- : in std_logic                   
        DUMPDONE_IN                 => dump_done                , -- : in std_logic                   
        
        DUMPVAL_OUT                 => dump_val                   -- : out std_logic_vector(1 downto 0) 
        );

    U_DUMP_ADDRESS_UP_COUNT : UPCNT_ADDR 
    port map(
        RST                         => rst_dump                 , --: in std_logic                      
        CLK                         => CLK_DUMP                 , --: in std_logic                      
        
        DUMPVAL_IN                  => dump_val                 , --: in std_logic_vector(1 downto 0)                      
        WRVAL_SIG_IN                => DUMP_WRVAL_IN            , --: in std_logic_vector(0 downto 0)   
        DUMP_BUF_SEL_IN             => bufsel_sh(2)             , --: in std_logic	                  
        
        WREN_OUT                    => dump_wren                , --: out std_logic_vector(0 downto 0)	
        ADDR_DUMP_OUT               => dump_addr                  --: out std_logic_vector(12 downto 0) 
        );

    U_DUMPDONE_SIG0_PROCESSING : DUMPDONE_BLK 
    port map(
        RST                         => rst_dump                 , -- : in std_logic                     
    	CLK                         => CLK_DUMP                 , -- : in std_logic                     
    
        DUMP_START_IN               => sw_dump_start            , -- : in std_logic                     
        ADDR_DUMP                   => dump_addr                , -- : in std_logic_vector(12 downto 0) 
        WRVAL                       => DUMP_WRVAL_IN            , -- : in std_logic_vector(0 downto 0)  
    
        DUMPDONE_OUT                => dump_done                  -- : out std_logic                    
        );

    DUMPDONE_OUT <= dump_done;

    G_Fixed_Pattern_Enable : if (FIXED_PTN_USAGE = TRUE) generate 
    begin
        P_test_Pattern_Command_CDC : process(rst_dump, CLK_DUMP) begin
            if (rst_dump = '1') then
                ptn_gen_en_sh       <= (others => '0')          ; --: std_logic_vector( 2 downto 0);
                ptn_gen_en          <= '0'                      ;
                ptn_gen_en_rpls     <= '0'                      ;             --: std_logic;
                ptn_length_cdc      <= (others => '0')          ; --: std_logic_vector(15 downto 0);
                ptn_start_sh        <= (others => '0')          ; --: std_logic_vector( 2 downto 0);

            elsif (CLK_DUMP'event) and (CLK_DUMP = '1') then
                ptn_gen_en_sh       <= ptn_gen_en_sh(1 downto 0) & FIXED_PTN_GEN_EN_IN; 
                ptn_gen_en          <= ptn_gen_en_sh(2) and dump_done;
                ptn_start_sh        <= ptn_start_sh(1 downto 0) & FIXED_PTN_START_IN; 
                ptn_gen_en_rpls     <= ptn_gen_en_sh(1) and (not ptn_gen_en_sh(2)); 

                if (ptn_gen_en_rpls = '1')then 
                    ptn_length_cdc  <= FIXED_PTN_LENGTH_IN(12 downto 0); 
                else
                    ptn_length_cdc  <= ptn_length_cdc; 
                end if;
            end if;
        end process;

        U_Test_Pattern_Address_Gen : TEST_PTN_ADDR_GEN
        port map(
            RST                     => rst_dump                 , --: in  std_logic;
            CLK                     => CLK_DUMP                 , --: in  std_logic;
        
            TEST_ENB_IN             => FIXED_PTN_VALID_IN       , --: in  std_logic;
            TEST_PTN_GEN_ENB        => ptn_gen_en_sh(2)         , --: in  std_logic;
            TEST_PTN_START          => ptn_start_sh(2)          , --: in  std_logic;
            TEST_PTN_LENGTH         => ptn_length_cdc           , --: in  std_logic_vector(12 downto 0);
        
            TEST_PTN_VALID_DLY      => ptn_valid_d              , --: out std_logic_vector( 0 downto 0);
        
            PTN_GEN_ADDR            => ptn_addr                   --: out std_logic_vector(12 downto 0)
            );

        TEST_PTN_VALID_OUT          <= ptn_valid_d(0);

        sw_cpu_en                   <= WREN_CPU_IN or (RDEN_CPU_IN and RDATA_MEMORY_SEL_IN); 

        P_DUMP_PTNGEN_Switching_DUMPCLK : process(rst_dump, CLK_DUMP) 
        begin
            
            if (rst_dump = '1') then
                sw_dump_start               <= '0';
                
                sw_dump_wr_en               <= '0';
                sw_dump_addr                <= (others => '0');
                sw_dump_wr_data             <= (others => '0');
                sw_dump_wr_odd_data         <= (others => '0');
                GEN_RDATA_OUT               <= (others => '0');
            elsif (CLK_DUMP'event) and (CLK_DUMP = '1') then
                if (ptn_gen_en = '1') then -- Pattern generate operation
                    sw_dump_start           <= '0';
                    
                    sw_dump_rd_en           <= FIXED_PTN_VALID_IN;
                    sw_dump_wr_en           <= '0';
                    sw_dump_addr            <= ptn_addr;
                    sw_dump_wr_data         <= (others => '0');
                    sw_dump_wr_odd_data     <= (others => '0');
                    GEN_RDATA_OUT           <= sw_dump_rd_data ;
                else
                    sw_dump_start           <= dumpstart_sh(2);
                    
                    sw_dump_rd_en           <= dump_wren; 
                    sw_dump_wr_en           <= dump_wren;
                    sw_dump_addr            <= dump_addr;
                    sw_dump_wr_data         <= i_dump_wrdata;
                    sw_dump_wr_odd_data     <= i_dump_odd_wrdata;
                    GEN_RDATA_OUT           <= (others => '0');
                end if;
            end if;
        end process;

        --  P_DUMP_PTNGEN_Switching_CPUCLK
        sw_cpu_wr_en                <= WREN_CPU_IN    when (FIXED_PTN_GEN_EN_IN = '1')  else '0';
        sw_cpu_addr                 <= ADDRL13B_IN    when (PHASE_SEL_IN = '0')         else "0" & ADDRL13B_IN(12 downto 1);
        sw_cpu_wr_data              <= WDATA_CPU_IN   when (FIXED_PTN_GEN_EN_IN = '1')  else (others => '0'); 
        RDATA_CPU_OUT               <= sw_cpu_rd_data when (PHASE_SEL_IN = '0')         else i_cpu_rd_data_poly; 
    end generate;

    G_Fixed_Pattern_Disable : if (FIXED_PTN_USAGE = FALSE) generate 
    begin
        sw_dump_start               <= dumpstart_sh(2)                      ;
        
        sw_dump_wr_en               <= dump_wren                            ;
        sw_dump_addr                <= dump_addr                            ;
        sw_dump_wr_data             <= i_dump_wrdata                        ;
        sw_dump_wr_odd_data         <= i_dump_odd_wrdata                    ;
        GEN_RDATA_OUT               <= (others => '0')                      ;

        sw_cpu_en                   <= RDEN_CPU_IN and (RDATA_MEMORY_SEL_IN); 
        sw_cpu_wr_en                <= '0'                                  ; 
        sw_cpu_addr                 <= ADDRL13B_IN    when (PHASE_SEL_IN = '0') else "0" & ADDRL13B_IN(12 downto 1); 
        sw_cpu_wr_data              <= (others => '0')      ; 
        RDATA_CPU_OUT               <= sw_cpu_rd_data when (PHASE_SEL_IN = '0') else i_cpu_rd_data_poly; 
        TEST_PTN_VALID_OUT          <= '0'                  ;
    end generate; 

    --buf_a_en <= bufsel_sh(2) or ptn_start_sh(2);  

    U_True_DPRAM : TRUE_DPRAM_DUALCLK
    generic map(
        DATA_WIDTH                  => 32                   , 
        ADDR_WIDTH                  => 13                     
        )
    port map(
        CLK_A                       => CLK_DUMP             , 
        --EN_A                        => buf_a_en             , 
        --EN_A                        => sw_dump_wr_en        , 
        EN_A                        => sw_dump_rd_en        , 
        WE_A                        => sw_dump_wr_en        , 
        ADDR_A                      => sw_dump_addr         ,
        DATA_A                      => sw_dump_wr_data      ,
        Q_A                         => sw_dump_rd_data      ,
    
        CLK_B                       => CLK_CPU              ,
        EN_B                        => sw_cpu_en            ,
        WE_B                        => sw_cpu_wr_en         ,
        ADDR_B                      => sw_cpu_addr          ,
        DATA_B                      => sw_cpu_wr_data       ,
        Q_B                         => sw_cpu_rd_data    
        );

    G_ODD_PHASE_DPRAM : if (POLY_PHASE_USAGE = TRUE) generate
    begin
        U_True_DPRAM_2nd : TRUE_DPRAM_DUALCLK
        generic map(
            DATA_WIDTH              => 32                   ,
            ADDR_WIDTH              => 13                    
            )
        port map(
            CLK_A                   => CLK_DUMP             ,
            --EN_A                    => sw_dump_wr_en        ,
            --EN_A                    => buf_a_en             , 
            EN_A                    => sw_dump_rd_en        , 
            WE_A                    => sw_dump_wr_en        ,
            ADDR_A                  => sw_dump_addr         ,
            DATA_A                  => sw_dump_wr_odd_data  ,
            Q_A                     => sw_dump_rd_odd_data  ,
        
            CLK_B                   => CLK_CPU              ,
            EN_B                    => sw_cpu_en            ,
            WE_B                    => sw_cpu_wr_en         ,
            ADDR_B                  => sw_cpu_addr          ,
            DATA_B                  => sw_cpu_wr_data       ,
            Q_B                     => sw_cpu_rd_data_odd   
            );

        process(rst_dump , CLK_CPU)
        begin
            if rst_dump = '1' then
                i_cpu_rd_data_poly          <= (others => '0');
                i_addrl13b_d1               <= (others => '0');
                i_addrl13b_d2               <= (others => '0');
                i_sw_cpu_en_d1              <= '0';
                i_sw_cpu_en_d2              <= '0';
            elsif rising_edge(CLK_CPU) then

                i_addrl13b_d1               <= ADDRL13B_IN;
                i_addrl13b_d2               <= i_addrl13b_d1;
                i_sw_cpu_en_d1              <= sw_cpu_en;
                i_sw_cpu_en_d2              <= i_sw_cpu_en_d1;

                if PHASE_SEL_IN = '1' then
                    if (i_sw_cpu_en_d2 = '1') and (i_addrl13b_d2(0) = '0') then
                        i_cpu_rd_data_poly  <= sw_cpu_rd_data;
                    elsif (i_sw_cpu_en_d2 = '1') and (i_addrl13b_d2(0) = '1') then
                        i_cpu_rd_data_poly  <= sw_cpu_rd_data_odd;
                    else
                        i_cpu_rd_data_poly  <= i_cpu_rd_data_poly;
                    end if;
                end if;
            end if;
        end process;


    end generate;


end arc_BUFFER_WRAPPER;

