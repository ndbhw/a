library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity DMA_STARTOFFSET is
port(
    RST                             : in std_logic                     ; -- RST_CPU         : Input Reset from CPU, Active High
    CLK                             : in std_logic                     ; -- CLK             : READ domain clock

    DMA_BFN_STRB_IN                 : in std_logic                     ; -- FS_IN           : BFN_STROBE, Period 10ms, Duration 260ns
    DMA_DLY_VALUE_IN                : in std_logic_vector(23 downto 0) ; -- BFNSTROBEDLY_IN : 8191 sample frame sync strobe delay
    DMA_READ_ENB_IN                 : in std_logic                     ; -- DUMPSTART_IN    : Dump start 

    DELAYED_BFN_STRB_OUT            : out std_logic
    );
end DMA_STARTOFFSET;

architecture arc_DMA_STARTOFFSET of DMA_STARTOFFSET is

component dma_dly_set
port(
    RST                             : in std_logic;                                              
    CLK                             : in std_logic;                                              
    BFN_STROBE_IN                   : in std_logic;                                             
    DLYVALUE_IN                     : in std_logic_vector(23 downto 0);                          

    FS_DLY_OUT                      : out std_logic
    );
end component;


signal dma_rd_enable_dc             : std_logic_vector( 2 downto 0);
signal dma_bfn_strb_dc              : std_logic_vector( 2 downto 0);
signal dma_rd_enable_flag           : std_logic;
signal fs_lat                       : std_logic;

signal bfnstrb_sampledly_d          : std_logic_vector(23 downto 0);

signal dlyvalue                     : std_logic_vector(23 downto 0);

signal fs_dly                       : std_logic;

begin
    
    P_DC : process(RST, CLK) 
    begin
        if (RST = '1') then
            dma_rd_enable_dc        <= (others => '0');
            dma_bfn_strb_dc         <= (others => '0');
            dma_rd_enable_flag      <= '0';
        elsif rising_edge(CLK) then
            dma_rd_enable_dc        <= dma_rd_enable_dc(1 downto 0) & DMA_READ_ENB_IN;
            dma_bfn_strb_dc         <= dma_bfn_strb_dc(1 downto 0) & DMA_BFN_STRB_IN;

            if dma_rd_enable_dc(2 downto 1) = "01" then
                dma_rd_enable_flag  <= '1';
            elsif dma_rd_enable_dc(2 downto 1) = "10" then
                dma_rd_enable_flag  <= '0';
            else
                dma_rd_enable_flag  <= dma_rd_enable_flag;
            end if;

        end if;
    end process;

    P_Multibit_CDC : process(RST, CLK) 
    begin
        if RST = '1' then
            bfnstrb_sampledly_d     <= (others => '0');
        elsif rising_edge(CLK) then
            if dma_rd_enable_flag = '1' then
                bfnstrb_sampledly_d <= DMA_DLY_VALUE_IN;
            else
                bfnstrb_sampledly_d <= bfnstrb_sampledly_d;
            end if;
        end if;
    end process;

    BFNSTRB_DLY_Point : process(RST, CLK)
    begin
        if (RST = '1') then
            dlyvalue                <= (others => '0');
        elsif rising_edge(CLK) then
            if bfnstrb_sampledly_d >= x"257DA9" then
                dlyvalue        <= x"257DA9";
            else
                dlyvalue        <= bfnstrb_sampledly_d;
            end if;
        end if;
    end process;
 
    P_Frame_Sync_Latch : process(RST, CLK) 
    begin
        if RST = '1' then
            fs_lat                  <= '0';
        elsif rising_edge(CLK) then
            if dma_bfn_strb_dc(2 downto 1) = "01" then 
                fs_lat              <= '1';
            else
                fs_lat              <= '0';
            end if;
        end if;
    end process;

    U_DMA_START_POINT_OFFSET : dma_dly_set
    port map(
        RST           => RST      , --: in std_logic;                                              
        CLK           => CLK      , --: in std_logic;                                              
        BFN_STROBE_IN => fs_lat   , --: in std_logic;                                             
        DLYVALUE_IN   => dlyvalue , --: in std_logic_vector(11 downto );                          
        FS_DLY_OUT    => fs_dly     --: out std_logic
        );
 
    DELAYED_BFN_STRB_OUT <= fs_dly;

end arc_DMA_STARTOFFSET;
