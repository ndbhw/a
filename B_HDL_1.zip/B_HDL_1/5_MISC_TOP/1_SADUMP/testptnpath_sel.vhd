library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity TESTPTNPATH_SEL is
    generic(
    DUMP_BUF_NUM                    : natural := 2
    );
    port(
    RST                             : in  std_logic                              ;
    CLK_DUMP0                       : in  std_logic                              ;
    CLK_DUMP1                       : in  std_logic                              ;

    TEST_ENB_CPRIPHY_IN             : in  std_logic_vector(1 downto 0)           ;
    TEST_ENB_CPRI_IN                : in  std_logic_vector(1 downto 0)           ;
    TEST_ENB_SBIF_IN                : in  std_logic_vector(1 downto 0)           ;
    TEST_ENB_SBIFPHY_IN             : in  std_logic_vector(1 downto 0)           ;
    TEST_ENB_BBCTRL_IN              : in  std_logic_vector(1 downto 0)           ;
    TEST_ENB_DSP_IN                 : in  std_logic_vector(1 downto 0)           ;
    TEST_ENB_DCIF_IN                : in  std_logic_vector(1 downto 0)           ;

    --FIXED_PTN_GEN_EN_IN             : in  std_logic                              ;
    FIXED_PTN_START_IN              : in  std_logic                              ;
    FIXED_PTN_BLK_SEL_IN            : in  std_logic_vector(7 downto 0)           ;

    TEST_ENB_OUT                    : out std_logic_array1(DUMP_BUF_NUM-1 downto 0)
    );
end TESTPTNPATH_SEL;

architecture arc_TESTPTNPATH_SEL of TESTPTNPATH_SEL is

component RST_SYNC is
generic (
    DLY_NUM                         : natural := 4;    -- Number of delay.
    MAX_FANOUT_NUM                  : integer := 200   -- Number of maximum fanout
);
port (
    RST_IN                          : in  std_logic;   -- Active high asynchronous reset
    CLK                             : in  std_logic;   -- clock to be sync'ed to
    RST_OUT                         : out std_logic    -- "Synchronised" reset signal
);         
end component;

--< Signal >--
signal RST_DUMP                     : std_logic_vector(DUMP_BUF_NUM-1 downto 0);

signal ptn_en                       : std_logic_array1(DUMP_BUF_NUM-1 downto 0);

signal test_ptn_en_sh               : std_logic_array3(DUMP_BUF_NUM-1 downto 0);
signal testblk_sel                  : std_logic_array8(DUMP_BUF_NUM-1 downto 0);

--< Process >--
begin
    --------------------------------------------------------------------------------------
    -- Case 1 ) DUMP_BUF_NUMP = 1
    --------------------------------------------------------------------------------------

    G_1_CLK_DOMAIN : if (DUMP_BUF_NUM = 1) generate
    begin

        U_RST_SYNC : RST_SYNC generic map(4,200) port map(RST, CLK_DUMP0, RST_DUMP(0));

        P_DumpStart_DC : process(RST_DUMP(0), CLK_DUMP0)
        begin
            if (RST_DUMP(0) = '1') then
                test_ptn_en_sh(0) <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                test_ptn_en_sh(0) <= test_ptn_en_sh(0)(1 downto 0) & FIXED_PTN_START_IN;
            end if;
        end process;

        P_DumpBlock_SEL_CDC : process(RST_DUMP(0), CLK_DUMP0)
        begin
            if (RST_DUMP(0) = '1') then
                testblk_sel(0) <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if (test_ptn_en_sh(0)(2) = '0') and (test_ptn_en_sh(0)(1) = '1') then
                    testblk_sel(0) <= FIXED_PTN_BLK_SEL_IN;
                else
                    testblk_sel(0) <= testblk_sel(0);
                end if;
            end if;
        end process;

        P_PATH_SEL : process(RST_DUMP(0), CLK_DUMP0) 
        begin
            if (RST_DUMP(0) = '1') then
                ptn_en(0)           <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                case (testblk_sel(0)) is
                    when  x"10" => ptn_en(0)(0) <= TEST_ENB_CPRIPHY_IN(0);
                    when  x"11" => ptn_en(0)(0) <= TEST_ENB_CPRIPHY_IN(1);
                    when  x"20" => ptn_en(0)(0) <= TEST_ENB_CPRI_IN(0);
                    when  x"21" => ptn_en(0)(0) <= TEST_ENB_CPRI_IN(1);
                    when  x"30" => ptn_en(0)(0) <= TEST_ENB_BBCTRL_IN(0);
                    when  x"31" => ptn_en(0)(0) <= TEST_ENB_BBCTRL_IN(1);
                    when  x"40" => ptn_en(0)(0) <= TEST_ENB_DSP_IN(0);
                    when  x"41" => ptn_en(0)(0) <= TEST_ENB_DSP_IN(1);
                    when  x"50" => ptn_en(0)(0) <= TEST_ENB_DCIF_IN(0);
                    when  x"51" => ptn_en(0)(0) <= TEST_ENB_DCIF_IN(1);
                    when  x"60" => ptn_en(0)(0) <= TEST_ENB_SBIF_IN(0);
                    when  x"61" => ptn_en(0)(0) <= TEST_ENB_SBIF_IN(1);
                    when  x"70" => ptn_en(0)(0) <= TEST_ENB_SBIFPHY_IN(0);
                    when  x"71" => ptn_en(0)(0) <= TEST_ENB_SBIFPHY_IN(1);
                    when others => ptn_en(0)    <= (others => '0');
                end case;
            end if;
        end process;
    end generate;
    --------------------------------------------------------------------------------------
    -- Case 2 ) DUMP_BUF_NUMP = 2
    --------------------------------------------------------------------------------------

    G_2_CLK_Domain : if (DUMP_BUF_NUM = 2) generate 
    begin

        U_RST_SYNC_0 : RST_SYNC generic map(4,200) port map(RST, CLK_DUMP0, RST_DUMP(0));
        U_RST_SYNC_1 : RST_SYNC generic map(4,200) port map(RST, CLK_DUMP1, RST_DUMP(1));

        P_DumpStart_DC0 : process(RST_DUMP(0), CLK_DUMP0) 
        begin
            if (RST_DUMP(0) = '1') then
                test_ptn_en_sh(0)   <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                test_ptn_en_sh(0)   <= test_ptn_en_sh(0)(1 downto 0) & FIXED_PTN_START_IN;
            end if;
        end process;

        P_DumpStart_DC1 : process(RST_DUMP(1), CLK_DUMP1) 
        begin
            if (RST_DUMP(1) = '1') then
                test_ptn_en_sh(1)   <= (others => '0');
            elsif rising_edge(CLK_DUMP1) then
                test_ptn_en_sh(1)   <= test_ptn_en_sh(1)(1 downto 0) & FIXED_PTN_START_IN;
            end if;
        end process;

        P_DumpBlock_SEL0_CDC : process(RST_DUMP(0), CLK_DUMP0) 
        begin
            if (RST_DUMP(0) = '1') then
                testblk_sel(0)      <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                if (test_ptn_en_sh(0)(2) = '0') and (test_ptn_en_sh(0)(1) = '1') then
                    testblk_sel(0)  <= FIXED_PTN_BLK_SEL_IN;
                else
                    testblk_sel(0)  <= testblk_sel(0);
                end if;
            end if;
        end process;

        P_DumpBlock_SEL1_CDC : process(RST_DUMP(1), CLK_DUMP1) 
        begin
            if (RST_DUMP(1) = '1') then
                testblk_sel(1)      <= (others => '0');
            elsif rising_edge(CLK_DUMP1) then
                if (test_ptn_en_sh(1)(2) = '0') and (test_ptn_en_sh(1)(1) = '1') then
                    testblk_sel(1)  <= FIXED_PTN_BLK_SEL_IN;
                else
                    testblk_sel(1)  <= testblk_sel(1);
                end if;
            end if;
        end process;

        P_PATH_SEL0 : process(RST_DUMP(0), CLK_DUMP0) 
        begin
            if (RST_DUMP(0) = '1') then
                ptn_en(0)           <= (others => '0');
            elsif rising_edge(CLK_DUMP0) then
                case (testblk_sel(0)) is
                    when  x"10"     => ptn_en(0)(0) <= TEST_ENB_CPRIPHY_IN(0);
                    when  x"20"     => ptn_en(0)(0) <= TEST_ENB_CPRI_IN(0);
                    when  x"30"     => ptn_en(0)(0) <= TEST_ENB_BBCTRL_IN(0);
                    when  x"40"     => ptn_en(0)(0) <= TEST_ENB_DSP_IN(0);
                    when  x"50"     => ptn_en(0)(0) <= TEST_ENB_DCIF_IN(0);
                    when  x"60"     => ptn_en(0)(0) <= TEST_ENB_SBIF_IN(0);
                    when  x"70"     => ptn_en(0)(0) <= TEST_ENB_SBIFPHY_IN(0);
                    when others     => ptn_en(0)    <= (others => '0');
                        
                end case;
            end if;
        end process;

        P_PATH_SEL1 : process(RST_DUMP(1), CLK_DUMP1)
        begin
            if (RST_DUMP(1) = '1') then
                ptn_en(1)           <= (others => '0');
            elsif rising_edge(CLK_DUMP1) then
                case (testblk_sel(1)) is
                    when  x"11"     => ptn_en(1)(0) <= TEST_ENB_CPRIPHY_IN(1);
                    when  x"21"     => ptn_en(1)(0) <= TEST_ENB_CPRI_IN(1);
                    when  x"31"     => ptn_en(1)(0) <= TEST_ENB_BBCTRL_IN(1);
                    when  x"41"     => ptn_en(1)(0) <= TEST_ENB_DSP_IN(1);
                    when  x"51"     => ptn_en(1)(0) <= TEST_ENB_DCIF_IN(1);
                    when  x"61"     => ptn_en(1)(0) <= TEST_ENB_SBIF_IN(1);
                    when  x"71"     => ptn_en(1)(0) <= TEST_ENB_SBIFPHY_IN(1);
                    when others     => ptn_en(1)    <= (others => '0');
                end case;
            end if;
        end process;

    end generate;

    TEST_ENB_OUT                   <= ptn_en;

end arc_TESTPTNPATH_SEL;	
