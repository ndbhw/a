library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

--< Entity >--------------------------------------------------------------------
entity START_CLKOFFSET is
port(
    RST                : in std_logic;                                              -- RST : Reset, Active high
    CLK                : in std_logic;                                              -- CLK : Input clock
    BFN_STROBE_IN      : in std_logic;                                              -- BFN_STROBE_IN : sync 122.88MHz, Period 10ms, pulsewidth 3.84MHz
    TXSA_CLKDLYVALUE_IN: in std_logic_vector(23 downto 0);                          -- DLYVALUE_IN   : Delay value

    FS_DLY_OUT         : out std_logic
    );
end START_CLKOFFSET;

--< Architecture >-------------------------------------------------------------
architecture arc_START_CLKOFFSET of START_CLKOFFSET is

----< Signal >----
-- _f#  : #number clk delay signal by filp-flop or register
-- pls  : 1 clock pulse
-- rpls : 1 clock rising edge pulse
-- npls : 1 clock negative edge pulse
-- _lat : Latch signal

signal fs_dc          : std_logic_vector( 2 downto 0);
signal fs_rpls        : std_logic;

signal cnt_dly        : std_logic_vector(23 downto 0);
signal cnt_flag2      : std_logic;
signal fs_dly         : std_logic;


----< Process >----
begin

    Count_Clock_Delay : process(RST, CLK)
    begin
        if (RST = '1')then
            cnt_flag2               <= '0';
            cnt_dly                 <= (others => '1');
        elsif (CLK'event) and (CLK = '1') then
            if BFN_STROBE_IN = '0' then
                cnt_flag2           <= '0';
                cnt_dly             <= (others => '0');
            else
                if (cnt_dly = TXSA_CLKDLYVALUE_IN - '1') then
                    cnt_flag2   <= '1';
                    cnt_dly     <= cnt_dly;
                else
                    cnt_flag2   <= '0';
                    cnt_dly     <= cnt_dly + '1';
                end if;
            end if;
        end if;
    end process;

    Clock_Delay_pulse : process(RST, CLK)
    begin
        if (RST = '1') then
            fs_dly  <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (TXSA_CLKDLYVALUE_IN = 0) then
                fs_dly  <= BFN_STROBE_IN;
            else
                if (cnt_flag2 = '1') then
                    fs_dly  <= '1';
                else
                    fs_dly  <= '0';
                end if;
            end if;
        end if;
    end process; 

    FS_DLY_OUT <= fs_dly;                                

end arc_START_CLKOFFSET;
