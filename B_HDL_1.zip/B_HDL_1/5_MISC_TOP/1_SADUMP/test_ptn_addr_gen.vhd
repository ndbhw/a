library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity TEST_PTN_ADDR_GEN is
port(
    RST                             : in  std_logic;
    CLK                             : in  std_logic;

    TEST_ENB_IN                     : in  std_logic;
    TEST_PTN_GEN_ENB                : in  std_logic;
    TEST_PTN_START                  : in  std_logic;
    TEST_PTN_LENGTH                 : in  std_logic_vector(12 downto 0);

    --TEST_PTN_VALID                  : in  std_logic;
    TEST_PTN_VALID_DLY              : out std_logic_vector( 0 downto 0);

    PTN_GEN_ADDR                    : out std_logic_vector(12 downto 0)
    );
end TEST_PTN_ADDR_GEN;

architecture arc_TEST_PTN_ADDR_GEN of TEST_PTN_ADDR_GEN is

--signal cnt_valid                    : std_logic_vector(1 downto 0); -- cnt_valid     : When insert first valid signal, address value is all zero.
signal test_ptn_start_sig           : std_logic;

signal test_ptn_gen_addr            : std_logic_vector(12 downto 0);
signal test_ptn_valid_sh            : std_logic_vector( 2 downto 0);

begin

    P_Test_Pattern_Start_Enable : process(RST, CLK) 
    begin
        if (RST = '1') then
            test_ptn_start_sig      <= '0';
        elsif (CLK'event) and (CLK = '1') then
            test_ptn_start_sig      <= TEST_PTN_GEN_ENB and TEST_PTN_START;
        end if;
    end process;

    P_Test_Pattern_Address_Gen : process(RST, CLK) 
    begin
        if (RST = '1') then
            test_ptn_gen_addr       <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (TEST_ENB_IN = '1') and (test_ptn_start_sig = '1') then
                if (test_ptn_gen_addr = TEST_PTN_LENGTH) then
                    test_ptn_gen_addr <= (others => '0'); 
                else
                    test_ptn_gen_addr <= test_ptn_gen_addr + '1'; 
                end if;
            else
                test_ptn_gen_addr <= test_ptn_gen_addr; 
            end if;
        end if;
    end process;

    P_Valid_Delay : process(RST, CLK) 
    begin
        if (RST = '1') then
            test_ptn_valid_sh       <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            test_ptn_valid_sh       <= test_ptn_valid_sh(1 downto 0)& TEST_ENB_IN;
        end if;
    end process;
    
    TEST_PTN_VALID_DLY(0)  <= test_ptn_valid_sh(2);
    PTN_GEN_ADDR           <= test_ptn_gen_addr;

end arc_TEST_PTN_ADDR_GEN;

    
