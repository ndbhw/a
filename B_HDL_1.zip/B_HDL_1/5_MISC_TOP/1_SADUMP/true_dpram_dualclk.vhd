library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.numeric_std.all;

entity TRUE_DPRAM_DUALCLK is
generic(
    DATA_WIDTH : natural := 32;
    ADDR_WIDTH : natural := 10 
    );
port(
    CLK_A      : in  std_logic;
    EN_A       : in  std_logic := '1';
    WE_A       : in  std_logic := '1';
    ADDR_A     : in  std_logic_vector((ADDR_WIDTH-1) downto 0);
    DATA_A     : in  std_logic_vector((DATA_WIDTH-1) downto 0);
    Q_A	       : out std_logic_vector((DATA_WIDTH-1) downto 0);

    CLK_B      : in  std_logic;
    EN_B       : in  std_logic := '1';
    WE_B       : in  std_logic := '1';
    ADDR_B     : in  std_logic_vector((ADDR_WIDTH-1) downto 0);
    DATA_B     : in  std_logic_vector((DATA_WIDTH-1) downto 0);
    Q_B	       : out std_logic_vector((DATA_WIDTH-1) downto 0)
    );
end TRUE_DPRAM_DUALCLK;

architecture arc_TRUE_DPRAM_DUALCLK of TRUE_DPRAM_DUALCLK is

-- Build a 2-D array type for the RAM
subtype word_t is std_logic_vector((DATA_WIDTH-1) downto 0);
type memory_t is array(2**ADDR_WIDTH-1 downto 0) of word_t;

-- Declare the RAM 
shared variable ram : memory_t := (others => (others => '0'));
-- signal ram : memory_t;

signal qa : std_logic_vector((DATA_WIDTH -1) downto 0);
signal qb : std_logic_vector((DATA_WIDTH -1) downto 0);

begin

    -- Port A
    P_PortA_Write : process(CLK_A) begin
        if (rising_edge(CLK_A)) then 
            if (EN_A = '1') then
                if (WE_A = '1') then
                    ram(conv_integer(ADDR_A)) := DATA_A;
                    -- ram(conv_integer(ADDR_A)) <= DATA_A;
                end if; 
            end if;
        end if;
    end process;
    
    P_PortA_Read : process(CLK_A) begin
        if (rising_edge(CLK_A)) then 
            if (EN_A = '1') then
                qa <= ram(conv_integer(ADDR_A));
            end if;
        end if;
    end process;
    
    P_PortA_Clocking : process(CLK_A) begin
        if (rising_edge(CLK_A)) then 
            Q_A <= qa;
        end if;
    end process;
    
    -- Port B 
    P_PortB_Write : process(CLK_B) begin
        if (rising_edge(CLK_B)) then 
            if (EN_B = '1') then
                if (WE_B = '1') then
                    ram(conv_integer(ADDR_B)) := DATA_B;
                    -- ram(conv_integer(ADDR_B)) <= DATA_B;
                end if;
            end if;
        end if;
    end process;

    P_PortB_Read : process(CLK_B) begin
        if (rising_edge(CLK_B)) then 
            if (EN_B = '1') then
                qb <= ram(conv_integer(ADDR_B));
            end if;
        end if;
    end process;
    
    P_PortB_Clocking : process(CLK_B) begin
        if (rising_edge(CLK_B)) then 
            Q_B <= qb;
        end if;
    end process;
    
end arc_TRUE_DPRAM_DUALCLK;

