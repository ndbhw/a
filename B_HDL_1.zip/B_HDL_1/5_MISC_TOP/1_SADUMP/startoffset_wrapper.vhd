library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity STARTOFFSET_WRAPPER is
port(
    RST                             : in std_logic                     ; -- RST_CPU         : Input Reset from CPU, Active High
    CLK                             : in std_logic                     ; -- CLK             : Write domain clock

    FS_IN                           : in std_logic                     ; -- FS_IN           : RX_BFN_STROBE, Period 10ms, Duration 260ns
    DUMP_STARTDLY_IN                : in std_logic_vector(11 downto 0) ; -- BFNSTROBEDLY_IN : 8191 sample frame sync strobe delay
    DUMP_START_IN                   : in std_logic                     ; -- DUMPSTART_IN    : Dump start 
    DUMP_BUF_SEL_IN                 : in std_logic                     ; -- DUMPBUFSEL_IN   : Dump buffer(#0/#1) selection

    SAMPLE_FSDLY_OUT                : out std_logic                      -- SAMPLE_FSDLY_OUT: Sample FS delay 
    );
end STARTOFFSET_WRAPPER;

architecture arc_STARTOFFSET_WRAPPER of STARTOFFSET_WRAPPER is

component START_OFFSET 
port(
    RST                             : in std_logic;                                              
    CLK                             : in std_logic;                                              
    BFN_STROBE_IN                   : in std_logic;                                             
    DLYVALUE_IN                     : in std_logic_vector(11 downto 0);                          

    FS_DLY_OUT                      : out std_logic
    );
end component;

--< Signal >--
-- _cnt : Counter
-- _flg : Flag
-- _dly : Delay
-- _f#  : Number # clocking
-- _pls : Pulse (pulse width : 1 clock)

signal dumpbufsel_sh  : std_logic_vector( 2 downto 0);
signal fs_sh          : std_logic_vector( 2 downto 0);
signal fs_lat         : std_logic;
signal dumpstart_sh   : std_logic_vector( 2 downto 0);

signal bfnstrb_sampledly_d : std_logic_vector(11 downto 0);

signal dlycomp        : std_logic;
signal dlyvalue       : std_logic_vector(11 downto 0);

signal fs_dly         : std_logic;

begin
    
    P_DC : process(RST, CLK) begin
        if (RST = '1') then
            dumpbufsel_sh  <= (others => '0'); 
            fs_sh          <= (others => '0'); 
            dumpstart_sh   <= (others => '0'); 
        elsif (CLK'event) and (CLK = '1') then
            dumpbufsel_sh  <= dumpbufsel_sh(1 downto 0) & DUMP_BUF_SEL_IN; 
            fs_sh          <= fs_sh(1 downto 0) & FS_IN; 
            dumpstart_sh   <= dumpstart_sh (1 downto 0) & DUMP_START_IN; 
        end if;
    end process;

    P_Multibit_CDC : process(RST, CLK) begin
        if (RST = '1') then
            bfnstrb_sampledly_d <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (dumpstart_sh(2) = '0') and (dumpstart_sh(1) = '1') then
                bfnstrb_sampledly_d <= DUMP_STARTDLY_IN;
            else
                bfnstrb_sampledly_d <= bfnstrb_sampledly_d;
            end if;
        end if;
    end process;

    DUMP_Sample_DLY_COMP : process(RST, CLK)
    begin
        if (RST = '1') then
            dlycomp <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (dumpbufsel_sh(2) = '1') then
                if (bfnstrb_sampledly_d > 299) then
                    dlycomp <= '1';
                else
                    dlycomp <= '0';
                end if;
            else
                dlycomp <= '0';
            end if;
        end if;
    end process;
 
    DUMP_Sample_DLY_Point : process(RST, CLK)
    begin
        if (RST = '1') then
            dlyvalue <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (dumpbufsel_sh(2) = '1') then
                if (dlycomp = '1') then
                    dlyvalue <= x"12B";
                else
                    dlyvalue <= bfnstrb_sampledly_d;
                end if;
            else
                dlyvalue <= (others => '0');
            end if;
        end if;
    end process;
 
    P_Frame_Sync_Latch : process(RST, CLK) begin
        if (RST = '1') then
            fs_lat <= '0';
        elsif (CLK'event) and (CLK = '1') then
            if (dumpstart_sh(2) = '1') then	
                if (fs_sh(2 downto 1) = "01") then 
                    fs_lat <= '1';
                else
                    fs_lat <= fs_lat;
                end if;
            else
                fs_lat <= '0';
            end if;
        end if;
    end process;

    U_DUMPSTART_POINT_OFFSET : START_OFFSET 
    port map(
        RST           => RST      , --: in std_logic;                                              
        CLK           => CLK      , --: in std_logic;                                              
        BFN_STROBE_IN => fs_lat   , --: in std_logic;                                             
        DLYVALUE_IN   => dlyvalue , --: in std_logic_vector(11 downto );                          
        FS_DLY_OUT    => fs_dly     --: out std_logic
        );
 
    SAMPLE_FSDLY_OUT <= fs_dly;

end arc_STARTOFFSET_WRAPPER;
    
