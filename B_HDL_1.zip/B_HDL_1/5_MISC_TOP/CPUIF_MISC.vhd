library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity CPUIF_MISC is
    port(
    --------------------------------
    -- Common port
    --------------------------------
    RST_CPU                         : in  std_logic                                     ; -- cpuif reset, '1': Reset
    CLK_CPU                         : in  std_logic                                     ; -- cpuif clock, faster than iclk/oclk

    AXI_TIMEOUT_IN                  : in  std_logic                                     ;
    
    CLK_SYSX4                       : in  std_logic                                     ; -- 122.88 MHz
    CLK_SYSX8                       : in  std_logic                                     ; -- 245.76 MHz
    CLK_SYSX10                      : in  std_logic                                     ; -- 307.20 MHz

    CLK_MISC3                       : in  std_logic                                     ; -- 200.00 MHz

    ADDR_CPU_IN                     : in  std_logic_vector(15 downto 0)                 ; -- cpuif address input, word address.
    WDATA_CPU_IN                    : in  std_logic_vector(31 downto 0)                 ; -- cpuif data input
    RDATA_CPU_OUT                   : out std_logic_vector(31 downto 0)                 ; -- cpuif data output
    WREN_CPU_IN                     : in  std_logic                                     ; -- cpuif write enable, '1': active, synchronous with iclk
    RDEN_CPU_IN                     : in  std_logic                                     ; -- cpuif read enable, '1': active.
    RDVAL_CPU_OUT                   : out std_logic                                     ; -- cpuif read data valid, '1': active, synchronous with clk_cpu.

    --------------------------------
    -- MISC
    --------------------------------
    TP_SEL                          : out std_logic;                              
    RST_CTRL                        : out std_logic_vector( 7 downto 0)                 ;
    BOARD_ID_IN                     : in  std_logic_vector(2 downto 0)                  ;

    --------------------------------
    -- SA_N_DUMP
    --------------------------------
    SADUMP_VAL_OUT                  : out std_logic                                     ;

    RX_SYSCTRL_STRB_SEL_OUT         : out std_logic_vector( 7 downto 0)                 ;
    TX_SYSCTRL_STRB_SEL_OUT         : out std_logic_vector( 7 downto 0)                 ;
    RX_CPRI_STRB_SEL_OUT            : out std_logic_vector( 7 downto 0)                 ;
    MODULE_STRB_SEL_OUT             : out std_logic_vector( 7 downto 0)                 ;

    DUMP_STARTDLY_OUT               : out std_logic_vector(11 downto 0)                 ;
    DUMP_BUF_SEL_OUT                : out std_logic_vector( 1 downto 0)                 ;
    DUMP_DATASEL_OUT                : out std_logic_vector( 7 downto 0)                 ;

    DUMP_DONE_IN                    : in  std_logic                                     ;
    DUMP_START_OUT                  : out std_logic                                     ;

    SA_ENB_OUT                      : out std_logic                                     ;
    FB_SW_CNT_INFO_OUT              : out std_logic_vector( 1 downto 0)                 ;
    TXSA_CLKDLYVALUE_OUT            : out std_logic_vector(23 downto 0)                 ;

    PHASE_SEL_OUT                   : out std_logic                                     ;

    FIXED_PTN_BLK_SEL_OUT           : out std_logic_vector( 7 downto 0)                 ;
    FIXED_PTN_LENGTH_OUT            : out std_logic_vector(12 downto 0)                 ;
    FIXED_PTN_ENB_OUT               : out std_logic                                     ;
    FIXED_PTN_START_OUT             : out std_logic                                     ;

    DMA_WR_ENB                      : out std_logic                                     ;
    DMA_RD_ENB                      : out std_logic                                     ;
    DMA_RD_BLK_SEL_OUT              : out std_logic_vector( 7 downto 0)                 ;
    DMA_WR_BLK_SEL_OUT              : out std_logic_vector( 7 downto 0)                 ;
    DMA_BFN_STRB_SEL_OUT            : out std_logic_vector( 7 downto 0)                 ;
    TEST_PTN_SEL_OUT                : out std_logic_vector( 1 downto 0)                 ;

    DMA_DLY_VALUE_OUT               : out std_logic_vector(23 downto 0)                 ;

    DMA_RD_FULL_IN                  : in  std_logic                                     ;
    DMA_RD_EMPTY_IN                 : in  std_logic                                     ;
    DMA_WR_FULL_IN                  : in  std_logic                                     ;
    DMA_WR_EMPTY_IN                 : in  std_logic                                     ;

    SADUMP_ADDR_OUT                 : out std_logic_vector(15 downto 0)                 ;
    SADUMP_WDATA_OUT                : out std_logic_vector(31 downto 0)                 ;
    SADUMP_WREN_OUT                 : out std_logic                                     ;
    SADUMP_RDEN_OUT                 : out std_logic                                     ;
    SADUMP_RDVAL_IN                 : in  std_logic                                     ;
    SADUMP_RDATA_IN                 : in  std_logic_vector(31 downto 0)                 ;

    --------------------------------
    -- DPA
    --------------------------------
    DPA_EN                          : out std_logic_vector(TX_ANT_NUM-1 downto 0)       ; -- Dynamic PA on/off enable

    DPA_TRX_DATA_DELAY_TIME         : out std_logic_vector(15 downto 0)                 ; -- resolution 1/245.76MHz
    DPA_RISE_RESP_TIME              : out std_logic_vector(15 downto 0)                 ; -- resolution 1/245.76MHz
    DPA_FALL_RESP_TIME              : out std_logic_vector(15 downto 0)                 ; -- resolution 1/245.76MHz
    DPA_OFF_MON_TIME                : out std_logic_vector(15 downto 0)                 ; -- resolution 1/245.76MHz

    --------------------------------
    -- SIG_SUS
    --------------------------------
    WAVESTOP_DISABLE_OUT            : out  std_logic                                    ;
    ALM_DEB_CNT_OUT                 : out  std_logic_vector( 19 downto 0)               ;
    CPRI_LINK_ANT_OUT               : out  std_logic_array8( 7 downto 0);
    RF_SW_OFF_RELEASE_OUT           : out  std_logic_vector( 7 downto 0);
    HW_WDT_RST_IN                   : in   std_logic;                       -- '1': On          , '0': Off          ; PowerPAC Control Flag

    UV_ALM_POST_IN                  : in   std_logic;                       -- '1': On          , '0': Off          ; PowerPAC Control Flag
    RFIC_OFF_SEQ_IN                 : in   std_logic;                       -- '1': On          , '0': Off

    LOG_CPRIPHY_IN                  : in   std_logic_vector(  7 downto 0);  -- '1': Alarm       , '0': No Alarm
    LOG_SBIFPHY_IN                  : in   std_logic_vector(  7 downto 0);  -- '1': Alarm       , '0': No Alarm
    LOG_CPRI_IN                     : in   std_logic_vector(  7 downto 0);  -- '1': Alarm       , '0': No Alarm
    LOG_SBIF_IN                     : in   std_logic_vector(  7 downto 0);  -- '1': Alarm       , '0': No Alarm
    LOG_BBCTRL_IN                   : in   std_logic_vector(  7 downto 0);  -- '1': Alarm       , '0': No Alarm
    LOG_DSP_IN                      : in   std_logic_vector(  7 downto 0);  -- '1': Alarm       , '0': No Alarm
    LOG_DCIF_DL_IN                  : in   std_logic_vector(  7 downto 0);  -- '1': Alarm       , '0': No Alarm
    LOG_DCIF_UL_IN                  : in   std_logic_vector(  7 downto 0);  -- '1': Alarm       , '0': No Alarm
    LOG_DCIF_FB_IN                  : in   std_logic_vector(  7 downto 0);  -- '1': Alarm       , '0': No Alarm

    LOG_CLK_IN                      : in   std_logic_vector(  1 downto 0)               ;  -- '1': Alarm       , '0': No Alarm
    LOG_RFIC_IN                     : in   std_logic_vector(  3 downto 0)               ;  -- '1': Alarm       , '0': No Alarm
    LOG_VOLTAGE_IN                  : in   std_logic_vector( 31 downto 0)               ;  -- '1': Alarm       , '0': No Alarm
    LOG_DAC_OFF_IN                  : in   std_logic_vector(  7 downto 0)               ;  -- '1': Alarm       , '0': No Alarm
    LOG_WDT_IN                      : in   std_logic_vector(  1 downto 0)               ;

    SIG_SUS_MAIN_TYPE_IN            : in   std_logic_vector( 7 downto 0);
    SIG_SUS_SUB_TYPE_IN             : in   std_logic_vector( 7 downto 0);
    SIG_SUS_VER_IN                  : in   std_logic_vector( 7 downto 0);
    SIG_SUS_STRUCT_IN               : in   std_logic_vector(31 downto 0);
    SIG_SUS_DATE_IN                 : in   std_logic_vector(31 downto 0);

    ALM_OFF_VOLT_OUT                : out  std_logic                                    ;  -- '1': Forced Alarm-off, '0': No Force

    ALM_EN_CPRIPHY_OUT              : out  std_logic_vector(  7 downto 0);  -- '1': Forced Alarm, '0': No Force
    ALM_EN_SBIFPHY_OUT              : out  std_logic_vector(  7 downto 0);  -- '1': Forced Alarm, '0': No Force
    ALM_EN_CPRI_OUT                 : out  std_logic_vector(  7 downto 0);  -- '1': Forced Alarm, '0': No Force
    ALM_EN_SBIF_OUT                 : out  std_logic_vector(  7 downto 0);  -- '1': Forced Alarm, '0': No Force
    ALM_EN_BBCTRL_OUT               : out  std_logic_vector(  7 downto 0);  -- '1': Forced Alarm, '0': No Force
    ALM_EN_DSP_OUT                  : out  std_logic_vector(  7 downto 0);  -- '1': Forced Alarm, '0': No Force
    ALM_EN_DCIF_DL_OUT              : out  std_logic_vector(  7 downto 0);  -- '1': Forced Alarm, '0': No Force
    ALM_EN_DCIF_UL_OUT              : out  std_logic_vector(  7 downto 0);  -- '1': Forced Alarm, '0': No Force
    ALM_EN_DCIF_FB_OUT              : out  std_logic_vector(  7 downto 0);  -- '1': Forced Alarm, '0': No Force
    ALM_EN_VOLT_OUT                 : out  std_logic_vector(  7 downto 0);  -- '1': Forced Alarm, '0': No Force
    ALM_EN_PG_OUT                   : out  std_logic_vector( 31 downto 0);  -- '1': Forced Alarm, '0': No Force
    ALM_EN_OTHERS_OUT               : out  std_logic_vector( 31 downto 0);  -- '1': Forced Alarm, '0': No Force

    DL_OFF_CPRIPHY_OUT              : out  std_logic_vector(  7 downto 0);  -- '1': Forced DL Off, '0': No Force
    DL_OFF_SBIFPHY_OUT              : out  std_logic_vector(  7 downto 0);  -- '1': Forced DL Off, '0': No Force
    DL_OFF_SBIF_OUT                 : out  std_logic_vector(  7 downto 0);  -- '1': Forced DL Off, '0': No Force
    DL_OFF_BBCTRL_OUT               : out  std_logic_vector(  7 downto 0);  -- '1': Forced DL Off, '0': No Force
    DL_OFF_DSP_OUT                  : out  std_logic_vector(  7 downto 0);  -- '1': Forced DL Off, '0': No Force
    DL_OFF_DCIF_OUT                 : out  std_logic_vector(  7 downto 0)               ;  -- '1': Forced DL Off, '0': No Force

    -- AMP Protection Timer
    I_t_dl_dly                      : out std_logic_vector( 10 downto 0);
    I_t_pa_off                      : out std_logic_vector( 10 downto 0);
    I_t_rf_swoff                    : out std_logic_vector( 10 downto 0);

    --------------------------------
    -- FBSW_CTRL
    --------------------------------
    SW_MANUAL_SET                   : out std_logic                                     ; -- '1' : manual operation by user, '0' : normal operation
    SW_MANUAL_VALUE                 : out std_logic_vector( 6 downto 0)                 ;

    FB_SW_MODE                      : out std_logic_array2(RFIC_NUM-1 downto 0)         ;

    RESYNC_MANUAL_OUT               : out std_logic                                     ; -- 
    RESYNC_ENABLE_OUT               : out std_logic                                     ; -- 
    RESYNC_STATUS_REG_IN            : in  std_logic_vector(31 downto 0)                 ; -- 
--    ORX_SW_REG                      : out std_logic_vector(3 downto 0)                  ;
--    ORX_SW_INVT_REG                 : out std_logic_vector(3 downto 0)                  ; -- ORX_SW invert control
--    REV_SW_0_REG                    : out std_logic_vector(3 downto 0)                  ;
--    REV_SW_0_INVT_REG               : out std_logic_vector(3 downto 0)                  ; -- REV_SW invert control
--    FB_REV_SW_0_REG                 : out std_logic                                     ;

    FB_SW_CTRL_VALUE_REG            : out std_logic_array3(RFIC_NUM-1 downto 0)         ; -- reg
    RFIC_ORX_TRIGGER_REG            : out std_logic                                     ;
    RFIC_ORX_MODE_REG               : out std_logic_vector(2 downto 0)                  ;

    --RFIC_CAL_MODE_CHG_RI_CNT        : out std_logic_vector(20 downto 0)                 ;
    --RFIC_CAL_MODE_CHG_FA_CNT        : out std_logic_vector(20 downto 0)                 ;

    --------------------------------
    -- TDD_CTRL
    --------------------------------
    EQUIP_OFFSET                    : out std_logic_vector(18 downto 0)                 ;
    EQUIP_ON                        : out std_logic_vector(14 downto 0)                 ;
    EQUIP_OFF                       : out std_logic_vector(14 downto 0)                 ;

    TRXSW_TX_OFFSET                 : out std_logic_vector(18 downto 0)                 ;
    TRXSW_TX_ON                     : out std_logic_vector(14 downto 0)                 ;
    TRXSW_TX_OFF                    : out std_logic_vector(14 downto 0)                 ;

    TRXSW_RX_OFFSET                 : out std_logic_vector(18 downto 0)                 ;
    TRXSW_RX_ON                     : out std_logic_vector(14 downto 0)                 ;
    TRXSW_RX_OFF                    : out std_logic_vector(14 downto 0)                 ;

    RFIC_TXA_SW_OFFSET              : out std_logic_array19(RFIC_NUM-1 downto 0)        ;
    RFIC_TXA_SW_ON                  : out std_logic_array15(RFIC_NUM-1 downto 0)        ;
    RFIC_TXA_SW_OFF                 : out std_logic_array15(RFIC_NUM-1 downto 0)        ;

    RFIC_TXB_SW_OFFSET              : out std_logic_array19(RFIC_NUM-1 downto 0)        ;
    RFIC_TXB_SW_ON                  : out std_logic_array15(RFIC_NUM-1 downto 0)        ;
    RFIC_TXB_SW_OFF                 : out std_logic_array15(RFIC_NUM-1 downto 0)        ;

    AMP_EN_OFFSET                   : out std_logic_array19(TX_ANT_NUM-1 downto 0)      ;
    AMP_EN_ON                       : out std_logic_array15(TX_ANT_NUM-1 downto 0)      ;
    AMP_EN_OFF                      : out std_logic_array15(TX_ANT_NUM-1 downto 0)      ;

    RFIC_TX_EN_OFFSET               : out std_logic_array2_array19(RFIC_NUM-1 downto 0) ;
    RFIC_TX_EN_ON                   : out std_logic_array2_array15(RFIC_NUM-1 downto 0) ;
    RFIC_TX_EN_OFF                  : out std_logic_array2_array15(RFIC_NUM-1 downto 0) ;

    RFIC_RX_EN_OFFSET               : out std_logic_array2_array19(RFIC_NUM-1 downto 0) ;
    RFIC_RX_EN_ON                   : out std_logic_array2_array15(RFIC_NUM-1 downto 0) ;
    RFIC_RX_EN_OFF                  : out std_logic_array2_array15(RFIC_NUM-1 downto 0) ;

    RFIC_PRE_TRIG_OFFSET            : out std_logic_array19(RFIC_NUM-1 downto 0)        ;
    RFIC_PRE_TRIG_ON                : out std_logic_array15(RFIC_NUM-1 downto 0)        ;
    RFIC_PRE_TRIG_OFF               : out std_logic_array15(RFIC_NUM-1 downto 0)        ;

    TX_CAL_SEL0_OFFSET              : out std_logic_vector(18 downto 0)                 ;
    TX_CAL_SEL0_ON                  : out std_logic_vector(14 downto 0)                 ;
    TX_CAL_SEL0_OFF                 : out std_logic_vector(14 downto 0)                 ;

    RX_CAL_SEL0_OFFSET              : out std_logic_vector(18 downto 0)                 ;
    RX_CAL_SEL0_ON                  : out std_logic_vector(14 downto 0)                 ;
    RX_CAL_SEL0_OFF                 : out std_logic_vector(14 downto 0)                 ;

    CAL_PATH_SEL_OFFSET             : out std_logic_array19(1 downto 0)                 ;
    CAL_PATH_SEL_ON                 : out std_logic_array15(1 downto 0)                 ;
    CAL_PATH_SEL_OFF                : out std_logic_array15(1 downto 0)                 ;

    CAL_SP4T_RESERVED_OFFSET        : out std_logic_array19(2 downto 0)                 ;
    CAL_SP4T_RESERVED_ON            : out std_logic_array15(2 downto 0)                 ;
    CAL_SP4T_RESERVED_OFF           : out std_logic_array15(2 downto 0)                 ;

    TDD_AND_CTRL                    : out std_logic_array32(6 downto 0)                 ;
    TDD_OR_CTRL                     : out std_logic_array32(6 downto 0)                 ;
    EQUIP_TDD_SELECT                : out std_logic_vector( 3 downto 0)                 ;
    --------------------------------
    -- EXT_CTRL
    --------------------------------
    UDE_ETHPHY_RST                  : out std_logic                                     ;
    CLK_PLL_RST                     : out std_logic                                     ;
    DLMK_RST                        : out std_logic                                     ;
    DLMK_SYNC                       : out std_logic                                     ;
    TDD_OUT_DIR                     : out std_logic                                     ;
    EXT_CLK_DIR                     : out std_logic                                     ;
    KUFPGA_RST_CTRL                 : out std_logic                                     ;
    AMP_ENB_CTRL                    : out std_logic_vector(TX_ANT_NUM-1 downto 0)       ;
    TRX_SW_CTRL                     : out std_logic_vector(1 downto 0)                  ;
    TRX_TQL_9092_ON                 : out std_logic                                     ;
    BIAST_3P3V_EN                   : out std_logic;
    TRX_RF_EN_5P0V                  : out std_logic;
    ISPPAC_CTRL                     : out std_logic_vector(2 downto 0)                  ;
    FPGA_PWR_STATUS                 : in  std_logic                                     ;

    ANALOG_DL_DLY_BYPASS            : out std_logic                                     ;
    ANALOG_DL_DLY                   : out std_logic_vector(11 downto 0)                 ;
    ANALOG_UL_DLY_BYPASS            : out std_logic                                     ;
    ANALOG_UL_DLY                   : out std_logic_vector(11 downto 0)                 ;
    ANALOG_FB_DLY_BYPASS            : out std_logic                                     ;
    ANALOG_FB_DLY                   : out std_logic_vector(11 downto 0)                 ;

    FUNC_FAIL_MASKING               : out std_logic                                     ;
    EXT_ENB_CTRL                    : out std_logic                                     ;

    UDA                             : in  std_logic_vector( 3 downto 0)                 ;
    UDA_D                           : in  std_logic_vector( 7 downto 0)                 ;
    UDA_D_TX                        : out std_logic_vector( 3 downto 0)                 ;
    CLK_PLL_LOS                     : in  std_logic                                     ;
    CLK_PLL_LD                      : in  std_logic                                     ;
    CLK_PLL_LD_RSVD                 : in  std_logic                                     ;

    AMP_AMC_RST1                    : out std_logic                                     ;
    AMP_AMC_RST2                    : out std_logic                                     ;

    --------------------------------
    -- RF Control
    --------------------------------
    RF_TX_SW_CTRL                   : out std_logic_vector(TX_ANT_NUM-1 downto 0)       ;
    RF_EN_CTRL                      : out std_logic_vector(           1 downto 0)       ;

    --------------------------------
    -- RX Attenuation Control
    --------------------------------
    RXATT_ENB                       : out std_logic_vector(3 downto 0)                  ;
    RXATT_WORD_A                    : out std_logic_vector(6 downto 0)                  ;
    RXATT_WORD_B                    : out std_logic_vector(6 downto 0)                  ;
    RXATT_WORD_C                    : out std_logic_vector(6 downto 0)                  ;
    RXATT_WORD_D                    : out std_logic_vector(6 downto 0)                  ;

    --------------------------------
    -- RFIC_CTRL
    --------------------------------
    RFIC_RST_CTRL                   : out std_logic_vector( RFIC_NUM-1 downto 0)        ;
    RFIC_TRI_ENB                    : out std_logic_vector( RFIC_NUM-1 downto 0)        ;
    RFIC_PWR_ON                     : out std_logic_vector( 2 downto 0)                 ;

    RFIC_TX_EN                      : out std_logic_array2( RFIC_NUM-1 downto 0)        ;
    RFIC_RX_EN                      : out std_logic_array2( RFIC_NUM-1 downto 0)        ;

    RFIC_GPIO_IN                    : in  std_logic_array19(RFIC_NUM-1 downto 0)        ;
    RFIC_GPIO_OUT                   : out std_logic_array19(RFIC_NUM-1 downto 0)        ;
    RFIC_GP_INTERRUPT               : in  std_logic_vector( RFIC_NUM-1 downto 0)        ;

    PM2_RFIC_PWR_OFF                : out std_logic                                     ;

    --------------------------------
    -- INTADC
    --------------------------------
    INTADC_TEMP                     : in  std_logic_vector(15 downto 0)                 ;
    INTADC_VCCINT                   : in  std_logic_vector(15 downto 0)                 ;
    INTADC_VCCPSINTLP               : in  std_logic_Vector(15 downto 0)                 ;
    INTADC_VCCPSINTFP               : in  std_logic_Vector(15 downto 0)                 ;
    INTADC_AUX                      : in  std_logic_array16(15 downto 0)                ;

    --------------------------------
    -- RET & Bias-T Control
    --------------------------------
    RET_UART_CTRL_OUT               : out std_logic_vector( 15 downto 0)            ;
    RET_TX_UART_START_CNT_IN        : in  std_logic_vector( 15 downto 0)            ;
    RET_TX_UART_ERR_CNT_IN          : in  std_logic_vector( 15 downto 0)            ;
    RET_RX_UART_START_CNT_IN        : in  std_logic_vector( 15 downto 0)            ;
    RET_RX_UART_ERR_CNT_IN          : in  std_logic_vector( 15 downto 0)            ;
    RET_ONOFF_CTRL_OUT              : out std_logic                                 ;

    OOK_A_UART_CTRL_OUT             : out std_logic_vector( 15 downto 0)            ;
    OOK_A_DIR_IN                    : in  std_logic                                 ;
    OOK_A_DIRMD1_OUT                : out std_logic                                 ;
    OOK_A_DIRMD2_OUT                : out std_logic                                 ;
    BIAS_T_A_ONOFF_OUT              : out std_logic                                 ;
    OOK_A_TX_UART_START_CNT_IN      : in  std_logic_vector( 15 downto 0)            ;
    OOK_A_TX_UART_ERR_CNT_IN        : in  std_logic_vector( 15 downto 0)            ;
    OOK_A_RX_UART_START_CNT_IN      : in  std_logic_vector( 15 downto 0)            ;
    OOK_A_RX_UART_ERR_CNT_IN        : in  std_logic_vector( 15 downto 0)            ;

    OOK_C_UART_CTRL_OUT             : out std_logic_vector( 15 downto 0)            ;
    OOK_C_DIR_IN                    : in  std_logic                                 ;
    OOK_C_DIRMD1_OUT                : out std_logic                                 ;
    OOK_C_DIRMD2_OUT                : out std_logic                                 ;
    BIAS_T_C_ONOFF_OUT              : out std_logic                                 ;
    OOK_C_TX_UART_START_CNT_IN      : in  std_logic_vector( 15 downto 0)            ;
    OOK_C_TX_UART_ERR_CNT_IN        : in  std_logic_vector( 15 downto 0)            ;
    OOK_C_RX_UART_START_CNT_IN      : in  std_logic_vector( 15 downto 0)            ;
    OOK_C_RX_UART_ERR_CNT_IN        : in  std_logic_vector( 15 downto 0)            ;

    FPGA_PSB_AMP_48V_ONOFF          : out std_logic                                 ;
    --------------------------------
    -- ETM MEMORY I/F
    --------------------------------
    ETM_MEM_PORT_EN                 : out std_logic;
    ETM_MEM_WR_EN                   : out std_logic;
    ETM_MEM_WR_ADDR                 : out std_logic_vector(14 downto 0)             ;
    ETM_MEM_WR_DATA                 : out std_logic_vector(31 downto 0)             ;
    
    --------------------------------
    -- Module information
    --------------------------------
    MISC_MODULE_INFO_IN             : in  std_logic_vector( 31 downto 0)            ;
    MISC_STRUCT_INFO_IN             : in  std_logic_vector( 31 downto 0)            ;
    MISC_MODULE_DATE_IN             : in  std_logic_vector( 31 downto 0)            ;

    SADUMP_MODULE_INFO_IN           : in  std_logic_vector( 31 downto 0)            ;
    SADUMP_STRUCT_INFO_IN           : in  std_logic_vector( 31 downto 0)            ;
    SADUMP_MODULE_DATE_IN           : in  std_logic_vector( 31 downto 0)            ;
    
    SUPPER_SLEEP_POUT               : out std_logic_vector(  0 downto 0)            ;
    PA_DRV_ONOFF                    : out std_logic

    );
end CPUIF_MISC;

architecture ARC_CPUIF_MISC of CPUIF_MISC is

    component RST_SYNC
    generic (
        DLY_NUM                     : natural := 4;    -- Number of delay.
        MAX_FANOUT_NUM              : integer := 200   -- Number of maximum fanout
    );
    port (
        RST_IN                      : in  std_logic;          -- Active high asynchronous reset
        CLK                         : in  std_logic;          -- clock to be sync'ed to
        RST_OUT                     : out std_logic           -- "Synchronised" reset signal
    );
    end component;

    component REG32_WRITE is
    generic(
        BIT_ENABLE                  : std_logic_vector(31 downto 0) := (others => '1');
        REG_ADDR                    : std_logic_vector( 7 downto 0) := (others => '0'); -- Register address
        REG_DATA                    : std_logic_vector(31 downto 0) := (others => '0')  -- Default value
        );
    port(
        RST                         : in  std_logic;                                    -- reset, '1': reset
        CLK                         : in  std_logic;                                    -- clock

        EN                          : in  std_logic;                                    -- Write enable
        ADDR                        : in  std_logic_vector( 7 downto 0);                -- Input Address
        DATA_IN                     : in  std_logic_vector(31 downto 0);                -- Data input
        DATA_OUT                    : out std_logic_vector(31 downto 0)                 -- Data output
    );
    end component;

    component REG32_LATCH
    generic (
        BIT_ENABLE                  : std_logic_vector(31 downto 0) := (others => '1');
        REG_ADDR                    : std_logic_vector( 7 downto 0) := (others => '0')
    );
    port (
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        CLR_IN                      : in  std_logic;
        ADDR_IN                     : in  std_logic_vector(7 downto 0);
        DATA_IN                     : in  std_logic_vector(31 downto 0);
        DATA_OUT                    : out std_logic_vector(31 downto 0);
        FLAG_OUT                    : out std_logic_vector(31 downto 0)
    );
    end component;

    component LATNCLR is
    generic(
        BIT_WIDTH                   : natural                                         -- EVENT & LATCH Bit Width.
    );
    port(
        RST                         : in  std_logic;                                  -- Active High Reset, '1': Reset
        CLK                         : in  std_logic;                                  -- Clock for EVENT
        CLR_FE_IN                   : in  std_logic;                                  -- Clear at falling edge
        CLR_RE_IN                   : in  std_logic;                                  -- Clear at rising edge
        EVENT_IN                    : in  std_logic_vector(BIT_WIDTH - 1 downto 0);   -- Event Pulse more than one clock
        LATCH_OUT                   : out std_logic_vector(BIT_WIDTH - 1 downto 0)    -- LATCH Output for EVENT.
    );
    end component;


    constant VERSION_INFO           : std_logic_vector(31 downto 0) := x"20160520";
    constant zeros                  : std_logic_vector(31 downto 0) := (others => '0');
    signal RDEN_DLY                 : std_logic_vector(7 downto 0); -- Read Enable Signal Delay
    signal ADDRL8B                  : std_logic_vector(7 downto 0); -- Address Low 8Bit
    signal WDATA                    : std_logic_vector(31 downto 0); -- CPU Write Data
    signal RDATA_100                : std_logic_vector(31 downto 0); -- CPU Read Data
    signal RDATA_SYSCLK_X4          : std_logic_vector(31 downto 0); -- CPU Read Data
    signal RDATA_SYSCLK_X8          : std_logic_vector(31 downto 0); -- CPU Read Data
    signal RDATA_SYSCLK_X10         : std_logic_vector(31 downto 0); -- CPU Read Data
    signal RDATA_MISC_X3            : std_logic_vector(31 downto 0); -- CPU Read Data
    signal WREN_D1_100              : std_logic; -- 1-Clock Delayed Write Enable
    signal WREN_D2_100              : std_logic; -- 2-Clock Delayed Write Enable
    signal wren_d1_sysx4            : std_logic; -- 1-Clock Delayed Write Enable
    signal wren_d2_sysx4            : std_logic; -- 2-Clock Delayed Write Enable
    signal wren_d3_sysx4            : std_logic; -- 2-Clock Delayed Write Enable
    signal wren_d1_sysx8            : std_logic; -- 1-Clock Delayed Write Enable
    signal wren_d2_sysx8            : std_logic; -- 2-Clock Delayed Write Enable
    signal wren_d3_sysx8            : std_logic; -- 2-Clock Delayed Write Enable
    signal wren_d1_sysx10           : std_logic; -- 1-Clock Delayed Write Enable
    signal wren_d2_sysx10           : std_logic; -- 2-Clock Delayed Write Enable
    signal wren_d3_sysx10           : std_logic; -- 2-Clock Delayed Write Enable
    signal wren_d1_misc3            : std_logic; -- 1-Clock Delayed Write Enable
    signal wren_d2_misc3            : std_logic; -- 2-Clock Delayed Write Enable
    signal wren_d3_misc3            : std_logic; -- 2-Clock Delayed Write Enable

    signal WREN_PLS                 : std_logic; -- Write Enable 1-Clock Pulse
    signal RDEN_D1_100              : std_logic; -- 1-Clock Delayed Read Enable
    signal RDEN_STROBE_100          : std_logic; -- 2-Clock Delayed Read Strobe
    signal RDEN_D1_SYSX4            : std_logic; -- 1-Clock Delayed Read Enable
    signal RDEN_STRB_SYSX4          : std_logic; -- 2-Clock Delayed Read Strobe
    signal RDEN_D1_SYSX8            : std_logic; -- 1-Clock Delayed Read Enable
    signal RDEN_STRB_SYSX8          : std_logic; -- 2-Clock Delayed Read Strobe
    signal RDEN_D1_SYSX10           : std_logic; -- 1-Clock Delayed Read Enable
    signal RDEN_STRB_SYSX10         : std_logic; -- 2-Clock Delayed Read Strobe
    signal RDEN_D1_MISC3            : std_logic; -- 1-Clock Delayed Read Enable
    signal RDEN_STRB_MISC3          : std_logic; -- 2-Clock Delayed Read Strobe
    signal RDVAL_PLS                : std_logic; -- Read Data Valud Pulse


    --naming rule of write enable pulse : wren_pls_"ADDRESS MSB 8bit"
    signal wren_pls_A0              : std_logic;
    signal wren_pls_A2              : std_logic;
    signal wren_pls_A4              : std_logic;
    signal wren_pls_A6              : std_logic;
    signal wren_pls_A8              : std_logic;
    signal wren_pls_AA              : std_logic;
    signal wren_pls_AE              : std_logic;
    signal wren_pls_B0              : std_logic;
    signal wren_pls_B1              : std_logic;
    signal wren_pls_B4              : std_logic;
    signal wren_pls_B6              : std_logic;

    signal rden_pls_A2              : std_logic;
    signal rden_pls_A6              : std_logic;
    signal rden_pls_B0              : std_logic;
    signal rden_pls_B4              : std_logic;

    signal i_sysclk_x4_rst          : std_logic;
    signal i_sysclk_x8_rst          : std_logic;
    signal i_sysclk_x10_rst         : std_logic;
    signal i_miscclk_x3             : std_logic;

    signal dma_enable_pls           : std_logic;
    signal dma_enable_pls_d         : std_logic;
    signal dma_enable_pls_d2        : std_logic;


    --register
    signal rst_ctrl_test_reg_100            : std_logic_vector(31 downto 0);
    signal i_tp_sel                         : std_logic_vector(31 downto 0);
    
    signal sadump_start_point_sel_reg_100   : std_logic_vector(31 downto 0);
    signal sadump_module_set_reg_100        : std_logic_vector(31 downto 0);
    signal sadump_cap_status_reg_100        : std_logic_vector(31 downto 0);
    signal sadump_txsa_set_reg_100          : std_logic_vector(31 downto 0);
    signal sadump_txsa_clkdlyvalue_reg_100  : std_logic_vector(31 downto 0);
    signal sadump_txsa_status_reg_100       : std_logic_vector(31 downto 0);
    signal sadump_fixed_ptn_set_reg_100     : std_logic_vector(31 downto 0);
    signal sadump_fixed_ptn_status_reg_100  : std_logic_vector(31 downto 0);
    signal sadump_dma_set_reg_100           : std_logic_vector(31 downto 0);
    signal sadump_dma_start_point_set_reg_100: std_logic_vector(31 downto 0);

    signal sadump_dump_operating_mode_reg_100: std_logic_vector(31 downto 0);

    signal npi_wr_ept_sts_w                 : std_logic_vector(31 downto 0);
    signal npi_wr_ful_sts_w                 : std_logic_vector(31 downto 0);
    signal npi_rd_ept_sts_w                 : std_logic_vector(31 downto 0);
    signal npi_rd_ful_sts_w                 : std_logic_vector(31 downto 0);

    signal npi_wr_ept_sts_s                 : std_logic_vector(31 downto 0);
    signal npi_wr_ful_sts_s                 : std_logic_vector(31 downto 0);
    signal npi_rd_ept_sts_s                 : std_logic_vector(31 downto 0);
    signal npi_rd_ful_sts_s                 : std_logic_vector(31 downto 0);

    signal npi_wr_ept_sts_f                 : std_logic_vector(31 downto 0);
    signal npi_wr_ful_sts_f                 : std_logic_vector(31 downto 0);
    signal npi_rd_ept_sts_f                 : std_logic_vector(31 downto 0);
    signal npi_rd_ful_sts_f                 : std_logic_vector(31 downto 0);

    signal rst_ext_phy_reg_100              : std_logic_vector(31 downto 0);
    signal rst_ext_pll_reg_100              : std_logic_vector(31 downto 0);
    signal ext_dlmk_sync_reg_100            : std_logic_vector(31 downto 0);
    signal ext_enb_ctrl_reg_100             : std_logic_vector(31 downto 0);
    signal ext_amp_amc_rst_reg_100          : std_logic_vector(31 downto 0);
    signal ext_tdd_dir_reg_100              : std_logic_vector(31 downto 0);
    signal ext_clk_dir_reg_100              : std_logic_vector(31 downto 0);

    signal ext_fpga_rst_reg_100             : std_logic_vector(31 downto 0);
    signal ext_isppac_ctrl_reg_100          : std_logic_vector(31 downto 0);
    
    signal board_id_reg_100                 : std_logic_vector(31 downto 0);

    signal vss_rst_d1                       : std_logic;
    signal vss_rst_d2                       : std_logic;
    signal uv_alarm_d1                      : std_logic;
    signal uv_alarm_d2                      : std_logic;
    signal hw_wdt_rst_d1                    : std_logic;
    signal hw_wdt_rst_d2                    : std_logic;

    -- RF Control
    signal ext_tx_sw_ctrl_reg_100           : std_logic_vector(31 downto 0);
    signal ext_amp_48v_onoff_reg_100        : std_logic_vector(31 downto 0);
    signal ext_rf_enb_ctrl_reg_100          : std_logic_vector(31 downto 0);

    -- RX ATT Control
    signal ext_rxatt_enb_reg_100            : std_logic_vector(31 downto 0);
    signal ext_rxatt_word_a_reg_100         : std_logic_vector(31 downto 0);
    signal ext_rxatt_word_b_reg_100         : std_logic_vector(31 downto 0);
    signal ext_rxatt_word_c_reg_100         : std_logic_vector(31 downto 0);
    signal ext_rxatt_word_d_reg_100         : std_logic_vector(31 downto 0);

    signal ext_amp_enb_ctrl_reg_100         : std_logic_vector(31 downto 0);
    signal ext_analog_dl_dly_reg_100        : std_logic_vector(31 downto 0);
    signal ext_analog_ul_dly_reg_100        : std_logic_vector(31 downto 0);
    signal ext_analog_fb_dly_reg_100        : std_logic_vector(31 downto 0);
    signal ext_trx_sw_ctrl_reg_100          : std_logic_vector(31 downto 0);
    signal ext_trx_tql_9092_on_reg_100      : std_logic_vector(31 downto 0);
    signal ext_func_fail_masking_reg_100    : std_logic_vector(31 downto 0);
    signal ext_bcf_en_dly_reg_100           : std_logic_vector(31 downto 0);

    -- ETC
    signal fpga_pwr_status_d1               : std_logic;
    signal fpga_pwr_status_d2               : std_logic;
    signal ext_fpga_pwr_sts_w               : std_logic_vector(31 downto 0);
    signal ext_fpga_pwr_sts_s               : std_logic_vector(31 downto 0);
    signal ext_fpga_pwr_sts_f               : std_logic_vector(31 downto 0);

    signal eth_phy_uda_w                    : std_logic_vector(31 downto 0);
    signal eth_phy_uda_s                    : std_logic_vector(31 downto 0);
    signal eth_phy_uda_f                    : std_logic_vector(31 downto 0);

    signal docomo_uda_w                     : std_logic_vector(31 downto 0);
    signal docomo_uda_s                     : std_logic_vector(31 downto 0);
    signal docomo_uda_f                     : std_logic_vector(31 downto 0);
    signal docomo_uda_tx                    : std_logic_vector(31 downto 0);

    signal clk_pll_los_w                    : std_logic_vector(31 downto 0);
    signal clk_pll_los_s                    : std_logic_vector(31 downto 0);
    signal clk_pll_los_f                    : std_logic_vector(31 downto 0);

    signal clk_pll_ld_w                     : std_logic_vector(31 downto 0);
    signal clk_pll_ld_s                     : std_logic_vector(31 downto 0);
    signal clk_pll_ld_f                     : std_logic_vector(31 downto 0);

    signal clk_pll_ld_rsvd_w                : std_logic_vector(31 downto 0);
    signal clk_pll_ld_rsvd_s                : std_logic_vector(31 downto 0);
    signal clk_pll_ld_rsvd_f                : std_logic_vector(31 downto 0);

    -- RET & Bias-T Control
    signal ext_ret_uart_ctrl                : std_logic_vector(31 downto 0);
    signal ext_ret_onoff_ctrl               : std_logic_vector(31 downto 0);

    signal ext_ook_a_uart_ctrl              : std_logic_vector(31 downto 0);
    signal ext_bias_t_a_ctrl_w              : std_logic_vector(31 downto 0);
    signal ext_bias_t_a_ctrl_r              : std_logic_vector(31 downto 0);
    signal i_ook_a_dir_lat_clr              : std_logic                    ;
    signal i_ook_a_dir_lat                  : std_logic_vector( 0 downto 0);

    signal ext_ook_c_uart_ctrl              : std_logic_vector(31 downto 0);
    signal ext_bias_t_c_ctrl_w              : std_logic_vector(31 downto 0);
    signal ext_bias_t_c_ctrl_r              : std_logic_vector(31 downto 0);
    signal i_ook_c_dir_lat_clr              : std_logic                    ;
    signal i_ook_c_dir_lat                  : std_logic_vector( 0 downto 0);

    -- signal for RFIC control
    signal rfic_rst_ctrl_reg_100            : std_logic_vector(31 downto 0);
    signal rfic_pwr_ctrl_reg_100            : std_logic_vector(31 downto 0);

    signal rfic_tx_enb_ctrl_reg_100         : std_logic_vector(31 downto 0);
    signal rfic_rx_enb_ctrl_reg_100         : std_logic_vector(31 downto 0);

    signal rfic_intr_gpio_set0_reg_100      : std_logic_vector(31 downto 0);
    signal rfic_intr_gpio_set1_reg_100      : std_logic_vector(31 downto 0);
    signal rfic_intr_gpio_set2_reg_100      : std_logic_vector(31 downto 0);
    signal rfic_intr_gpio_set3_reg_100      : std_logic_vector(31 downto 0);

    signal rfic_gpio_in_d1                  : std_logic_array19(RFIC_NUM-1 downto 0);
    signal rfic_gpio_in_d2                  : std_logic_array19(RFIC_NUM-1 downto 0);
    signal rfic_intr_d1                     : std_logic_vector( RFIC_NUM-1 downto 0);
    signal rfic_intr_d2                     : std_logic_vector( RFIC_NUM-1 downto 0);

    signal rfic_intr_gpio_w                 : std_logic_array32(RFIC_NUM-1 downto 0) := (others => (others => '0'));
    signal rfic_intr_gpio_s                 : std_logic_array32(RFIC_NUM-1 downto 0) := (others => (others => '0'));
    signal rfic_intr_gpio_f                 : std_logic_array32(RFIC_NUM-1 downto 0) := (others => (others => '0'));

    -- signal for sadump
    signal sadump_mem_rden                  : std_logic;
    signal sadump_mem_raddr                 : std_logic_vector(15 downto 0);
    signal sadump_mem_rdata                 : std_logic_vector(31 downto 0);
    signal sadump_mem_rdval                 : std_logic;
    signal sadump_capture_data              : std_logic_vector(31 downto 0);
    signal sadump_capture_rdval             : std_logic;

    signal sadump_mem_wren                  : std_logic;
    signal sadump_mem_waddr                 : std_logic_vector(15 downto 0);
    signal sadump_mem_wdata                 : std_logic_vector(31 downto 0);
    signal sadump_write_data                : std_logic_vector(31 downto 0);

------------------------------------------- DPA REG

    signal dpa_en_r                         : std_logic_vector(31 downto 0);
    signal dpa_trx_data_dly_time_r          : std_logic_vector(31 downto 0);
    signal dpa_rise_resp_time_r             : std_logic_vector(31 downto 0);
    signal dpa_fall_resp_time_r             : std_logic_vector(31 downto 0);
    signal dpa_off_mon_time_r               : std_logic_vector(31 downto 0);

------------------------------------------- FBSW REG
    signal sw_manual_set_r                  : std_logic_vector(31 downto 0);
    signal sw_manual_value_r                : std_logic_vector(31 downto 0);
--    signal manual_orx_sw_reg_r              : std_logic_vector(31 downto 0);

--    signal manual_rev_sw_0_reg_r            : std_logic_vector(31 downto 0);
--    signal manual_fb_rev_sw_0_reg_r         : std_logic_vector(31 downto 0);
    signal manual_fb_sw_ctrl_value_reg_r    : std_logic_vector(31 downto 0);

    signal manual_rfic_orx_mode_reg_r       : std_logic_vector(31 downto 0);
--    signal manual_orx_rev_sw_invt_reg_r     : std_logic_vector(31 downto 0);
    signal manual_rfic_orx_trigger_reg_r    : std_logic_vector(31 downto 0);

--    signal bfn_cnt_reg_r                    : std_logic_vector(31 downto 0);

--    signal rfic_cal_mode_chg_ri_cnt_reg     : std_logic_vector(31 downto 0);
--    signal rfic_cal_mode_chg_fa_cnt_reg     : std_logic_vector(31 downto 0);

    signal fb_sw_mode_r                     : std_logic_array32(RFIC_NUM - 1 downto 0);

    signal equip_offset_r                   : std_logic_vector(31 downto 0);
    signal equip_onoff_r                    : std_logic_vector(31 downto 0);

    signal trxsw_tx_offset_r                : std_logic_vector(31 downto 0);
    signal trxsw_tx_onoff_r                 : std_logic_vector(31 downto 0);

    signal trxsw_rx_offset_r                : std_logic_vector(31 downto 0);
    signal trxsw_rx_onoff_r                 : std_logic_vector(31 downto 0);

    signal rfic_txa_sw_offset_r             : std_logic_array32(RFIC_NUM - 1 downto 0);
    signal rfic_txa_sw_onoff_r              : std_logic_array32(RFIC_NUM - 1 downto 0);

    signal rfic_txb_sw_offset_r             : std_logic_array32(RFIC_NUM - 1 downto 0);
    signal rfic_txb_sw_onoff_r              : std_logic_array32(RFIC_NUM - 1 downto 0);

    signal amp_en_offset_r                  : std_logic_array32(TX_ANT_NUM - 1 downto 0);
    signal amp_en_onoff_r                   : std_logic_array32(TX_ANT_NUM - 1 downto 0);

    signal rfic_tx_en_offset_r              : std_logic_array2_array32(RFIC_NUM - 1 downto 0);
    signal rfic_tx_en_onoff_r               : std_logic_array2_array32(RFIC_NUM - 1 downto 0);

    signal rfic_rx_en_offset_r              : std_logic_array2_array32(RFIC_NUM - 1 downto 0);
    signal rfic_rx_en_onoff_r               : std_logic_array2_array32(RFIC_NUM - 1 downto 0);

    signal rfic_pre_trig_offset_r           : std_logic_array32(RFIC_NUM - 1 downto 0);
    signal rfic_pre_trig_onoff_r            : std_logic_array32(RFIC_NUM - 1 downto 0);

    signal tx_cal_sel0_offset_r             : std_logic_vector(31 downto 0);
    signal tx_cal_sel0_onoff_r              : std_logic_vector(31 downto 0);

    signal rx_cal_sel0_offset_r             : std_logic_vector(31 downto 0);
    signal rx_cal_sel0_onoff_r              : std_logic_vector(31 downto 0);

    signal cal_path_sel_offset_r            : std_logic_array32(1 downto 0);
    signal cal_path_sel_onoff_r             : std_logic_array32(1 downto 0);

    signal cal_sp4t_reserved_offset_r       : std_logic_array32(2 downto 0);
    signal cal_sp4t_reserved_onoff_r        : std_logic_array32(2 downto 0);

    signal tdd_and_ctrl_r                   : std_logic_array32(6 downto 0);
    signal tdd_or_ctrl_r                    : std_logic_array32(6 downto 0);
    
    signal supper_sleep_r                   : std_logic_vector(31 downto 0);
    
    -- SIG_SUS_TOP
    signal sig_sus_amp_protect_on           : std_logic_vector(31 downto 0);
    signal alm_deb_cnt                      : std_logic_vector(31 downto 0);
    signal rf_sw_off_release                : std_logic_vector(31 downto 0);
    signal sig_sus_cpri_link_ant            : std_logic_array32( 7 downto 0);

    signal alm_en_cpriphy                   : std_logic_vector(31 downto 0);
    signal alm_en_sbifphy                   : std_logic_vector(31 downto 0);
    signal alm_en_cpri                      : std_logic_vector(31 downto 0);
    signal alm_en_sbif                      : std_logic_vector(31 downto 0);
    signal alm_en_bbctrl                    : std_logic_vector(31 downto 0);
    signal alm_en_dsp                       : std_logic_vector(31 downto 0);
    signal alm_en_dcif_dl                   : std_logic_vector(31 downto 0);
    signal alm_en_dcif_ul                   : std_logic_vector(31 downto 0);
    signal alm_en_dcif_fb                   : std_logic_vector(31 downto 0);
    signal alm_en_volt                      : std_logic_vector(31 downto 0);
    signal alm_en_pg                        : std_logic_vector(31 downto 0);
    signal alm_en_others                    : std_logic_vector(31 downto 0);
    signal dl_off_cpriphy                   : std_logic_vector(31 downto 0);
    signal dl_off_sbifphy                   : std_logic_vector(31 downto 0);
    signal dl_off_sbif                      : std_logic_vector(31 downto 0);
    signal dl_off_bbctrl                    : std_logic_vector(31 downto 0);
    signal dl_off_dsp                       : std_logic_vector(31 downto 0);
    signal dl_off_dcif                      : std_logic_vector(31 downto 0);
    signal alm_off_volt                     : std_logic_vector(31 downto 0);

    signal w_log_cpriphy                    : std_logic_vector(31 downto 0);
    signal w_log_sbifphy                    : std_logic_vector(31 downto 0);
    signal w_log_cpri                       : std_logic_vector(31 downto 0);
    signal w_log_sbif                       : std_logic_vector(31 downto 0);
    signal w_log_bbctrl                     : std_logic_vector(31 downto 0);
    signal w_log_dsp                        : std_logic_vector(31 downto 0);
    signal w_log_dcif_dl                    : std_logic_vector(31 downto 0);
    signal w_log_dcif_ul                    : std_logic_vector(31 downto 0);
    signal w_log_dcif_fb                    : std_logic_vector(31 downto 0);
    signal w_log_clk                        : std_logic_vector(31 downto 0);
    signal w_log_rfic                       : std_logic_vector(31 downto 0);
    signal w_log_voltage                    : std_logic_vector(31 downto 0);
    signal w_log_dac_off                    : std_logic_vector(31 downto 0);
    signal w_log_wdt                        : std_logic_vector(31 downto 0);

    signal s_log_cpriphy                    : std_logic_vector(31 downto 0);
    signal s_log_sbifphy                    : std_logic_vector(31 downto 0);
    signal s_log_cpri                       : std_logic_vector(31 downto 0);
    signal s_log_sbif                       : std_logic_vector(31 downto 0);
    signal s_log_bbctrl                     : std_logic_vector(31 downto 0);
    signal s_log_dsp                        : std_logic_vector(31 downto 0);
    signal s_log_dcif_dl                    : std_logic_vector(31 downto 0);
    signal s_log_dcif_ul                    : std_logic_vector(31 downto 0);
    signal s_log_dcif_fb                    : std_logic_vector(31 downto 0);
    signal s_log_clk                        : std_logic_vector(31 downto 0);
    signal s_log_rfic                       : std_logic_vector(31 downto 0);
    signal s_log_voltage                    : std_logic_vector(31 downto 0);
    signal s_log_dac_off                    : std_logic_vector(31 downto 0);
    signal s_log_wdt                        : std_logic_vector(31 downto 0);

    signal f_log_cpriphy                    : std_logic_vector(31 downto 0);
    signal f_log_sbifphy                    : std_logic_vector(31 downto 0);
    signal f_log_cpri                       : std_logic_vector(31 downto 0);
    signal f_log_sbif                       : std_logic_vector(31 downto 0);
    signal f_log_bbctrl                     : std_logic_vector(31 downto 0);
    signal f_log_dsp                        : std_logic_vector(31 downto 0);
    signal f_log_dcif_dl                    : std_logic_vector(31 downto 0);
    signal f_log_dcif_ul                    : std_logic_vector(31 downto 0);
    signal f_log_dcif_fb                    : std_logic_vector(31 downto 0);
    signal f_log_clk                        : std_logic_vector(31 downto 0);
    signal f_log_rfic                       : std_logic_vector(31 downto 0);
    signal f_log_voltage                    : std_logic_vector(31 downto 0);
    signal f_log_dac_off                    : std_logic_vector(31 downto 0);
    signal f_log_wdt                        : std_logic_vector(31 downto 0);

    signal r_t_dl_dly                       : std_logic_vector(31 downto 0);
    signal r_t_pa_off                       : std_logic_vector(31 downto 0);
    signal r_t_rf_swoff                     : std_logic_vector(31 downto 0);

    signal equip_tdd_select_r               : std_logic_vector(31 downto 0);

    signal resync_manual_r                  : std_logic_vector(31 downto 0);             
    signal resync_enable_r                  : std_logic_vector(31 downto 0);             
    signal resync_status_r                  : std_logic_vector(31 downto 0);             

    signal i_axi_timeout_w                  : std_logic_vector(31 downto 0);
    signal i_axi_timeout_s                  : std_logic_vector(31 downto 0);
    signal i_axi_timeout_f                  : std_logic_vector(31 downto 0);
    signal i_sw_timeout_control             : std_logic_vector(31 downto 0);
    
    signal i_to_rst                         : std_logic;
    
    signal etm_tp_mem_port_en               : std_logic_vector(31 downto 0);
    signal etm_tp_mem_wr_en                 : std_logic_vector(31 downto 0);
    signal etm_tp_mem_wraddr                : std_logic_vector(31 downto 0);
    signal etm_tp_mem_wrdata                : std_logic_vector(31 downto 0);
    
    signal pa_drv_onoff_r                   : std_logic_vector(31 downto 0);
    
       
begin
----------------------------------
  
    RESYNC_MANUAL_OUT       <=   resync_manual_r(0);
    RESYNC_ENABLE_OUT       <=   resync_enable_r(0);
    resync_status_r         <=   RESYNC_STATUS_REG_IN  ;  

    ADDRL8B  <= ADDR_CPU_IN(7 downto 0);
    WDATA    <= WDATA_CPU_IN;

    i_axi_timeout_w <= zeros(31 downto 1) & AXI_TIMEOUT_IN;
    i_to_rst <= i_axi_timeout_w(0) when i_sw_timeout_control(0) = '0' else '0';
    
    u_reset_cpuif_122p88 : RST_SYNC
    generic map(
        DLY_NUM                     => 4                        , --: natural := 4;    -- Number of delay.
        MAX_FANOUT_NUM              => 200                     --: string := 200 -- Number of maximum fanout
        )
    port map(
        RST_IN                      => RST_CPU                  , -- : in  std_logic;  -- Active high asynchronous reset
        CLK                         => CLK_SYSX4                , -- : in  std_logic;  -- clock to be sync'ed to
        RST_OUT                     => i_sysclk_x4_rst            -- : out std_logic); -- "Synchronised" reset signal
        );

    u_reset_cpuif_245p76 : RST_SYNC
    generic map(
        DLY_NUM                     => 4                        , --: natural := 4;    -- Number of delay.
        MAX_FANOUT_NUM              => 200                     --: string := 200 -- Number of maximum fanout
        )
    port map(
        RST_IN                      => RST_CPU                  , -- : in  std_logic;  -- Active high asynchronous reset
        CLK                         => CLK_SYSX8                , -- : in  std_logic;  -- clock to be sync'ed to
        RST_OUT                     => i_sysclk_x8_rst            -- : out std_logic); -- "Synchronised" reset signal
        );

    u_reset_cpuif_307p2 : RST_SYNC
    generic map(
        DLY_NUM                     => 4                        , --: natural := 4;    -- Number of delay.
        MAX_FANOUT_NUM              => 200                     --: string := 200 -- Number of maximum fanout
        )
    port map(
        RST_IN                      => RST_CPU                  , -- : in  std_logic;  -- Active high asynchronous reset
        CLK                         => CLK_SYSX10               , -- : in  std_logic;  -- clock to be sync'ed to
        RST_OUT                     => i_sysclk_x10_rst           -- : out std_logic); -- "Synchronised" reset signal
        );

    u_reset_cpuif_200 : RST_SYNC
    generic map(
        DLY_NUM                     => 4                        , --: natural := 4;    -- Number of delay.
        MAX_FANOUT_NUM              => 200                     --: string := 200 -- Number of maximum fanout
        )
    port map(
        RST_IN                      => RST_CPU                  , -- : in  std_logic;  -- Active high asynchronous reset
        CLK                         => CLK_MISC3                , -- : in  std_logic;  -- clock to be sync'ed to
        RST_OUT                     => i_miscclk_x3            -- : out std_logic); -- "Synchronised" reset signal
        );

    ----------------------------------------------------------------------------------------------
    -- Read Data Valid Signal Generation, 5 Clock Latency
    ----------------------------------------------------------------------------------------------
    RDVAL_GEN0: process(RST_CPU, CLK_CPU)
    begin
        if (RST_CPU = '1') then
            RDEN_DLY                <= (others => '0');
            RDVAL_PLS               <= '0';
        elsif (CLK_CPU'event and CLK_CPU = '1') then
            RDEN_DLY                <= RDEN_DLY(6 downto 0) & RDEN_CPU_IN;
            if (RDEN_DLY(3) = '1' and RDEN_DLY(4) = '0') then -- 1 Clock Duration
                RDVAL_PLS           <= '1';
            else
                RDVAL_PLS           <= '0';
            end if;
        end if;
    end process;
    RDVAL_CPU_OUT <= RDVAL_PLS;

    ---------------------------------------------------------------------------------------
    -- SADUMP CPU BUS MUXIGN ( READ Process )
    ---------------------------------------------------------------------------------------

    sadump_capture_data             <= SADUMP_RDATA_IN;
    sadump_capture_rdval            <= SADUMP_RDVAL_IN;

    SADUMP_Read_Enable : process(RST_CPU, CLK_CPU)
    begin
        if (RST_CPU = '1') then
            sadump_mem_rden         <= '0';
            sadump_mem_raddr        <= (others => '0');
            sadump_mem_rdata        <= (others => '0');
        elsif (CLK_CPU'event) and (CLK_CPU = '1') then
            if (RDEN_CPU_IN = '1') and (ADDR_CPU_IN(15 downto 13) = "110") then
                sadump_mem_rden     <= '1';
                sadump_mem_rdata    <= sadump_capture_data;
                sadump_mem_rdval    <= sadump_capture_rdval;

                sadump_mem_raddr    <= ADDR_CPU_IN(15 downto 0);
            else
                sadump_mem_rden     <= '0';
                sadump_mem_rdata    <= (others => '0');

                sadump_mem_raddr    <= sadump_mem_raddr;
            end if;

        end if;
    end process;


    ---------------------------------------------------------------------------------------
    -- SADUMP CPU BUS MUXIGN ( WRITE Process )
    ---------------------------------------------------------------------------------------

    sadump_write_data               <= WDATA_CPU_IN;

    SADUMP_Write_Enable : process(RST_CPU, CLK_CPU)
    begin
        if (RST_CPU = '1') then
            sadump_mem_wren         <= '0';
            sadump_mem_waddr        <= (others => '0');
            sadump_mem_wdata        <= (others => '0');
        elsif (CLK_CPU'event) and (CLK_CPU = '1') then
            if ((WREN_CPU_IN = '1') and (ADDR_CPU_IN(15 downto 13) = "110")) then
                sadump_mem_wren     <= '1';
                sadump_mem_wdata    <= sadump_write_data;

                sadump_mem_waddr    <= ADDR_CPU_IN(15 downto 0);
            else
                sadump_mem_wren     <= '0';
                sadump_mem_wdata    <= (others => '0');

                sadump_mem_waddr    <= sadump_mem_waddr;
            end if;

        end if;
    end process;

    SADUMP_ADDR_OUT                 <= sadump_mem_raddr when (sadump_mem_rden = '1') else
                                       sadump_mem_waddr when (sadump_mem_wren = '1') else
                                       (others => '0');

    SADUMP_RDEN_OUT                 <= sadump_mem_rden;
    SADUMP_WREN_OUT                 <= sadump_mem_wren;

    SADUMP_WDATA_OUT                <= sadump_mem_wdata;



    ---------------------------------------------------------------------------------------
    -- ispPAC Control (copy from RF90-05E)
    ---------------------------------------------------------------------------------------
    Input_Alarm_Double_Clocking : process(RST_CPU, CLK_CPU) begin
        if RST_CPU = '1' then
            vss_rst_d1              <= '0';
            vss_rst_d2              <= '0';

            uv_alarm_d1             <= '0';
            uv_alarm_d2             <= '0';

            hw_wdt_rst_d1           <= '0';
            hw_wdt_rst_d2           <= '0';

        elsif rising_edge(CLK_CPU) then
            vss_rst_d1              <= RFIC_OFF_SEQ_IN;
            vss_rst_d2              <= vss_rst_d1     ;

            uv_alarm_d1             <= UV_ALM_POST_IN;
            uv_alarm_d2             <= uv_alarm_d1   ;

            hw_wdt_rst_d1           <= HW_WDT_RST_IN;
            hw_wdt_rst_d2           <= hw_wdt_rst_d1;
        end if;
    end process;

--    P_ispPAC_Control : process(RST_CPU, CLK_CPU)
--    begin
--        if (RST_CPU = '1') then
--            ISPPAC_CTRL             <= "001"; -- Bit[1] polarity inversion by wisetree
--        elsif rising_edge(CLK_CPU) then
--            if ext_isppac_ctrl_reg_100(4) = '1' then
--                ISPPAC_CTRL         <= ext_isppac_ctrl_reg_100(2 downto 0);
--            else
--                if (vss_rst_d2 = '1') or (uv_alarm_d2 = '1') or (i_to_rst = '1') then
--                --if (vss_rst_d2 = '1') then
--                    ISPPAC_CTRL     <= "101"; -- ispPAC Power Off / VSS RST - Power RST
--                elsif (hw_wdt_rst_d2 = '1') then
--                    ISPPAC_CTRL     <= "011"; -- ispPAC Power Off / WDT RST - Warm RST
--                end if;
--            end if;
--        end if;
--    end process;
    
    ---- 2024/04/08: Power tean request use bit [0] of ISPPAC_CTRL for Supper Sleep Mode 
    ---- Control [0] by RUSW
    P_ispPAC_Control : process(RST_CPU, CLK_CPU)
    begin
        if (RST_CPU = '1') then
            ISPPAC_CTRL             <= "000"; -- Bit[1] polarity inversion by wisetree
        elsif rising_edge(CLK_CPU) then
            ISPPAC_CTRL(0) <= ext_isppac_ctrl_reg_100(0);
            
            if ext_isppac_ctrl_reg_100(4) = '1' then
                ISPPAC_CTRL         <= ext_isppac_ctrl_reg_100(2 downto 0);
            else                
                if (vss_rst_d2 = '1') or (uv_alarm_d2 = '1') or (i_to_rst = '1') then
                --if (vss_rst_d2 = '1') then
                    ISPPAC_CTRL(2 downto 1)     <= "10"; -- ispPAC Power Off / VSS RST - Power RST
                elsif (hw_wdt_rst_d2 = '1') then
                    ISPPAC_CTRL(2 downto 1)     <= "01"; -- ispPAC Power Off / WDT RST - Warm RST
                end if;
            end if;
        end if;
    end process;


    -------------------------------------------------------------------------------------------
    -------------------------------------- Output Assign --------------------------------------
    -------------------------------------------------------------------------------------------

    --------------------------------
    -- MISC TOP
    --------------------------------
    TP_SEL                          <= i_tp_sel(0);                 
    RST_CTRL                        <= rst_ctrl_test_reg_100(7 downto 0);
    --------------------------------
    -- SA N DUMP
    --------------------------------
    RX_SYSCTRL_STRB_SEL_OUT         <= sadump_start_point_sel_reg_100(31 downto 24);
    TX_SYSCTRL_STRB_SEL_OUT         <= sadump_start_point_sel_reg_100(23 downto 16);
    RX_CPRI_STRB_SEL_OUT            <= sadump_start_point_sel_reg_100(15 downto  8);
    MODULE_STRB_SEL_OUT             <= sadump_start_point_sel_reg_100( 7 downto  0);

    DUMP_STARTDLY_OUT               <= sadump_module_set_reg_100(27 downto 16);
    DUMP_BUF_SEL_OUT                <= sadump_module_set_reg_100( 9 downto  8);
    DUMP_DATASEL_OUT                <= sadump_module_set_reg_100( 7 downto  0);
    DUMP_START_OUT                  <= sadump_cap_status_reg_100(0);

    PHASE_SEL_OUT                   <= sadump_dump_operating_mode_reg_100(0);

    SA_ENB_OUT                      <= sadump_txsa_set_reg_100(8);
    FB_SW_CNT_INFO_OUT              <= sadump_txsa_set_reg_100(1 downto 0);
    TXSA_CLKDLYVALUE_OUT            <= sadump_txsa_clkdlyvalue_reg_100(23 downto 0);

    FIXED_PTN_BLK_SEL_OUT           <= sadump_fixed_ptn_set_reg_100( 7 downto 0);
    FIXED_PTN_LENGTH_OUT            <= sadump_fixed_ptn_set_reg_100(20 downto 8);

    FIXED_PTN_ENB_OUT               <= sadump_fixed_ptn_status_reg_100(8);
    FIXED_PTN_START_OUT             <= sadump_fixed_ptn_status_reg_100(0);

    DMA_WR_ENB                      <= dma_enable_pls_d2;
    DMA_RD_ENB                      <= dma_enable_pls_d2;

    DMA_RD_BLK_SEL_OUT              <= sadump_dma_set_reg_100( 7 downto  0);
    DMA_WR_BLK_SEL_OUT              <= sadump_dma_set_reg_100(15 downto  8);
    DMA_BFN_STRB_SEL_OUT            <= sadump_dma_set_reg_100(23 downto 16);
    TEST_PTN_SEL_OUT                <= sadump_dma_set_reg_100(25 downto 24);

    DMA_DLY_VALUE_OUT               <= sadump_dma_start_point_set_reg_100(23 downto 0);

    --------------------------------
    -- External Device
    --------------------------------
    UDE_ETHPHY_RST                  <= rst_ext_phy_reg_100(0);
    CLK_PLL_RST                     <= rst_ext_pll_reg_100(0);
    DLMK_RST                        <= rst_ext_pll_reg_100(1);
    DLMK_SYNC                       <= ext_dlmk_sync_reg_100(0);
    TDD_OUT_DIR                     <= ext_tdd_dir_reg_100(0);
    EXT_CLK_DIR                     <= ext_clk_dir_reg_100(0);
    KUFPGA_RST_CTRL                 <= ext_fpga_rst_reg_100(0);
    AMP_ENB_CTRL                    <= ext_amp_enb_ctrl_reg_100(TX_ANT_NUM-1 downto 0);
    TRX_SW_CTRL                     <= ext_trx_sw_ctrl_reg_100(1 downto 0);
    TRX_TQL_9092_ON                 <= ext_trx_tql_9092_on_reg_100(0);

    ANALOG_DL_DLY_BYPASS            <= ext_analog_dl_dly_reg_100(16)         ;
    ANALOG_DL_DLY                   <= ext_analog_dl_dly_reg_100(11 downto 0);
    ANALOG_UL_DLY_BYPASS            <= ext_analog_ul_dly_reg_100(16)         ;
    ANALOG_UL_DLY                   <= ext_analog_ul_dly_reg_100(11 downto 0);
    ANALOG_FB_DLY_BYPASS            <= ext_analog_fb_dly_reg_100(16)         ;
    ANALOG_FB_DLY                   <= ext_analog_fb_dly_reg_100(11 downto 0);

    FUNC_FAIL_MASKING               <= ext_func_fail_masking_reg_100(0) ;
    EXT_ENB_CTRL                    <= ext_enb_ctrl_reg_100(0)          ;

    AMP_AMC_RST1                    <= ext_amp_amc_rst_reg_100(0)       ;
    AMP_AMC_RST2                    <= ext_amp_amc_rst_reg_100(4)       ;
    
    board_id_reg_100(2 downto 0)    <= BOARD_ID_IN;

    --------------------------------
    -- EXTDEV_PSU_AMP_48V_ONOFF
    --------------------------------
    FPGA_PSB_AMP_48V_ONOFF          <= ext_amp_48v_onoff_reg_100(0);

    --------------------------------
    -- RF TX Switch Control
    --------------------------------
    RF_TX_SW_CTRL                   <= ext_tx_sw_ctrl_reg_100(1 downto 0)   ;
    RF_EN_CTRL                      <= ext_rf_enb_ctrl_reg_100(1 downto 0)  ;

    --------------------------------
    -- RX Attenuation Control
    --------------------------------
    RXATT_ENB                       <= ext_rxatt_enb_reg_100(3 downto 0);
    RXATT_WORD_A                    <= ext_rxatt_word_a_reg_100( 6 downto 0);
    RXATT_WORD_B                    <= ext_rxatt_word_b_reg_100( 6 downto 0);
    RXATT_WORD_C                    <= ext_rxatt_word_c_reg_100( 6 downto 0);
    RXATT_WORD_D                    <= ext_rxatt_word_d_reg_100( 6 downto 0);

    --------------------------------
    -- DPA
    --------------------------------

    DPA_GEN : for i in 0 to TX_ANT_NUM-1 generate
    DPA_EN(i) <= dpa_en_r(i);
    end generate;

    DPA_TRX_DATA_DELAY_TIME <= dpa_trx_data_dly_time_r(15 downto 0);
    DPA_RISE_RESP_TIME      <= dpa_rise_resp_time_r(15 downto 0);
    DPA_FALL_RESP_TIME      <= dpa_fall_resp_time_r(15 downto 0);
    DPA_OFF_MON_TIME        <= dpa_off_mon_time_r(15 downto 0);

    --------------------------------
    -- RFIC control
    --------------------------------
    RFIC_RST_CTRL                   <= rfic_rst_ctrl_reg_100(RFIC_NUM-1 downto 0);
    RFIC_TRI_ENB                    <= rfic_pwr_ctrl_reg_100(RFIC_NUM-1+16 downto 16);
    RFIC_PWR_ON                     <= rfic_pwr_ctrl_reg_100(2 downto 0);
    PM2_RFIC_PWR_OFF                <= rfic_pwr_ctrl_reg_100(8);
    RFIC_TX_EN(0)                   <= rfic_tx_enb_ctrl_reg_100( 1) & rfic_tx_enb_ctrl_reg_100( 0);
    --RFIC_TX_EN(1)                   <= rfic_tx_enb_ctrl_reg_100( 5) & rfic_tx_enb_ctrl_reg_100( 4);

    RFIC_RX_EN(0)                   <= rfic_rx_enb_ctrl_reg_100( 1) & rfic_rx_enb_ctrl_reg_100( 0);
    --RFIC_RX_EN(1)                   <= rfic_rx_enb_ctrl_reg_100( 5) & rfic_rx_enb_ctrl_reg_100( 4);

    RFIC_GPIO_OUT(0)                <= rfic_intr_gpio_set0_reg_100(18 downto 0);
    --RFIC_GPIO_OUT(1)                <= rfic_intr_gpio_set1_reg_100(18 downto 0);

    SW_MANUAL_SET                   <= sw_manual_set_r(0);
    SW_MANUAL_VALUE                 <= sw_manual_value_r(6 downto 0);

    U_FB_SW_MODE_MAPPING : for I in 0 to (RFIC_NUM - 1) generate
        FB_SW_MODE(I) <= fb_sw_mode_r(I)(1 downto 0);
    end generate;

--    ORX_SW_REG        <= manual_orx_sw_reg_r(3 downto 0);
--    REV_SW_0_REG      <= manual_rev_sw_0_reg_r(3 downto 0);
--    FB_REV_SW_0_REG   <= manual_fb_rev_sw_0_reg_r(0);

    RFIC_ORX_TRIGGER_REG <= manual_rfic_orx_trigger_reg_r(0);
    RFIC_ORX_MODE_REG    <= manual_rfic_orx_mode_reg_r(2 downto 0);

    FBSW_CTRL_REG : for I in 0 to (RFIC_NUM - 1) generate
        FB_SW_CTRL_VALUE_REG(I) <= manual_fb_sw_ctrl_value_reg_r(2 downto 0);
    end generate;


--    ORX_SW_INVT_REG    <= manual_orx_rev_sw_invt_reg_r(3 downto 0);
--    REV_SW_0_INVT_REG  <= manual_orx_rev_sw_invt_reg_r(11 downto 8);

    --BFN_CNT_REG        <= bfn_cnt_reg_r(20 downto 0);

    --P_For_Timing : process(i_sysclk_x8_rst, CLK_SYSX8) begin
    --    if (i_sysclk_x8_rst = '1') then
    --        RFIC_CAL_MODE_CHG_RI_CNT <= (others => '0');
    --        RFIC_CAL_MODE_CHG_FA_CNT <= (others => '0');
    --    elsif (CLK_SYSX8'event) and (CLK_SYSX8 = '1') then
    --        RFIC_CAL_MODE_CHG_RI_CNT <= rfic_cal_mode_chg_ri_cnt_reg(20 downto 0);
    --        RFIC_CAL_MODE_CHG_FA_CNT <= rfic_cal_mode_chg_fa_cnt_reg(20 downto 0);
    --    end if;
    --end process;

    --------------------------------
    -- TDD control
    --------------------------------
    EQUIP_OFFSET                    <= equip_offset_r(18 downto 0)    ;
    EQUIP_ON                        <= equip_onoff_r(14 downto 0)     ;
    EQUIP_OFF                       <= equip_onoff_r(30 downto 16)    ;

    TRXSW_TX_OFFSET                 <= trxsw_tx_offset_r(18 downto 0) ;
    TRXSW_TX_ON                     <= trxsw_tx_onoff_r(14 downto 0)  ;
    TRXSW_TX_OFF                    <= trxsw_tx_onoff_r(30 downto 16) ;

    TRXSW_RX_OFFSET                 <= trxsw_rx_offset_r(18 downto 0) ;
    TRXSW_RX_ON                     <= trxsw_rx_onoff_r(14 downto 0)  ;
    TRXSW_RX_OFF                    <= trxsw_rx_onoff_r(30 downto 16) ;

    U_RFIC_TX_MAPPING : for I in 0 to (RFIC_NUM - 1) generate
        RFIC_TXA_SW_OFFSET(I)       <= rfic_txa_sw_offset_r(I)(18 downto 0) ;
        RFIC_TXA_SW_ON(I)           <= rfic_txa_sw_onoff_r(I)(14 downto 0)  ;
        RFIC_TXA_SW_OFF(I)          <= rfic_txa_sw_onoff_r(I)(30 downto 16) ;

        RFIC_TXB_SW_OFFSET(I)       <= rfic_txb_sw_offset_r(I)(18 downto 0) ;
        RFIC_TXB_SW_ON(I)           <= rfic_txb_sw_onoff_r(I)(14 downto 0)  ;
        RFIC_TXB_SW_OFF(I)          <= rfic_txb_sw_onoff_r(I)(30 downto 16) ;
    end generate;

    U_AMP_EN_MAPPING : for I in 0 to (TX_ANT_NUM - 1) generate
        AMP_EN_OFFSET(I)            <= amp_en_offset_r(I)(18 downto 0) ;
        AMP_EN_ON(I)                <= amp_en_onoff_r(I)(14 downto 0)  ;
        AMP_EN_OFF(I)               <= amp_en_onoff_r(I)(30 downto 16) ;
    end generate;

    U_RFIC_PATH_MAPPING : for I in 0 to 1 generate
        U_RFIC_EN_MAPPING : for J in 0 to (RFIC_NUM - 1) generate
            RFIC_TX_EN_OFFSET(J)(I) <= rfic_tx_en_offset_r(J)(I)(18 downto 0)  ;
            RFIC_TX_EN_ON(J)(I)     <= rfic_tx_en_onoff_r(J)(I)(14 downto 0)   ;
            RFIC_TX_EN_OFF(J)(I)    <= rfic_tx_en_onoff_r(J)(I)(30 downto 16)  ;

            RFIC_RX_EN_OFFSET(J)(I) <= rfic_rx_en_offset_r(J)(I)(18 downto 0)  ;
            RFIC_RX_EN_ON(J)(I)     <= rfic_rx_en_onoff_r(J)(I)(14 downto 0)   ;
            RFIC_RX_EN_OFF(J)(I)    <= rfic_rx_en_onoff_r(J)(I)(30 downto 16)  ;
        end generate;
end generate;

U_RFIC_PRE_TRIG_MAPPING : for I in 0 to (RFIC_NUM - 1) generate
    RFIC_PRE_TRIG_OFFSET(I)  <= rfic_pre_trig_offset_r(I)(18 downto 0) ;
    RFIC_PRE_TRIG_ON(I)      <= rfic_pre_trig_onoff_r(I)(14 downto 0)  ;
    RFIC_PRE_TRIG_OFF(I)     <= rfic_pre_trig_onoff_r(I)(30 downto 16) ;
end generate;

    TX_CAL_SEL0_OFFSET              <= tx_cal_sel0_offset_r(18 downto 0)  ;
    TX_CAL_SEL0_ON                  <= tx_cal_sel0_onoff_r(14 downto 0)   ;
    TX_CAL_SEL0_OFF                 <= tx_cal_sel0_onoff_r(30 downto 16)  ;

    RX_CAL_SEL0_OFFSET              <= rx_cal_sel0_offset_r(18 downto 0)  ;
    RX_CAL_SEL0_ON                  <= rx_cal_sel0_onoff_r(14 downto 0)   ;
    RX_CAL_SEL0_OFF                 <= rx_cal_sel0_onoff_r(30 downto 16)  ;

    U_CAL_PATH_SEL_MAPPING : for I in 0 to 1 generate
        CAL_PATH_SEL_OFFSET(I)      <= cal_path_sel_offset_r(I)(18 downto 0) ;
        CAL_PATH_SEL_ON(I)          <= cal_path_sel_onoff_r(I)(14 downto 0)  ;
        CAL_PATH_SEL_OFF(I)         <= cal_path_sel_onoff_r(I)(30 downto 16) ;
    end generate;


    U_CALSP4T_RESERVED_MAPPING : for I in 0 to 2 generate
        CAL_SP4T_RESERVED_OFFSET(I) <= cal_sp4t_reserved_offset_r(I)(18 downto 0) ;
        CAL_SP4T_RESERVED_ON(I)     <= cal_sp4t_reserved_onoff_r(I)(14 downto 0)  ;
        CAL_SP4T_RESERVED_OFF(I)    <= cal_sp4t_reserved_onoff_r(I)(30 downto 16) ;
    end generate;

U_TDD_ANT_CTR_MAPPING : for I in 0 to 6 generate
        TDD_AND_CTRL(I)             <= tdd_and_ctrl_r(I);
        TDD_OR_CTRL(I)              <= tdd_or_ctrl_r(I);
    end generate;

    EQUIP_TDD_SELECT <= equip_tdd_select_r(3 downto 0);

    ETM_MEM_PORT_EN                   <= etm_tp_mem_port_en(0);
    ETM_MEM_WR_EN                     <= etm_tp_mem_wr_en(0);
    ETM_MEM_WR_ADDR                   <= etm_tp_mem_wraddr(14 downto 0);
    ETM_MEM_WR_DATA                   <= etm_tp_mem_wrdata;
    
    --------------------------------
    -- RET & Bias-T Control
    --------------------------------

    U_LATNCLK_OOK_DIR_A : LATNCLR
    generic map(
        BIT_WIDTH                   => 1                                  --: natural
    )
    port map(
        RST                         => RST_CPU                          , --: in  std_logic;
        CLK                         => CLK_CPU                          , --: in  std_logic;
        CLR_FE_IN                   => i_ook_a_dir_lat_clr              , --: in  std_logic;
        CLR_RE_IN                   => '0'                              , --: in  std_logic;
        EVENT_IN(0)                 => OOK_A_DIR_IN                     , --: in  std_logic_vector(BIT_WIDTH - 1 downto 0);
        LATCH_OUT                   => i_ook_a_dir_lat                    --: out std_logic_vector(BIT_WIDTH - 1 downto 0);
    );

    U_LATNCLK_OOK_DIR_C : LATNCLR
    generic map(
        BIT_WIDTH                   => 1                                  --: natural
    )
    port map(
        RST                         => RST_CPU                          , --: in  std_logic;
        CLK                         => CLK_CPU                          , --: in  std_logic;
        CLR_FE_IN                   => i_ook_c_dir_lat_clr              , --: in  std_logic;
        CLR_RE_IN                   => '0'                              , --: in  std_logic;
        EVENT_IN(0)                 => OOK_C_DIR_IN                     , --: in  std_logic_vector(BIT_WIDTH - 1 downto 0);
        LATCH_OUT                   => i_ook_c_dir_lat                    --: out std_logic_vector(BIT_WIDTH - 1 downto 0);
    );


    RET_UART_CTRL_OUT               <= ext_ret_uart_ctrl(15 downto 0)   ;
    RET_ONOFF_CTRL_OUT              <= ext_ret_onoff_ctrl(0)            ;
    OOK_A_UART_CTRL_OUT             <= ext_ook_a_uart_ctrl(15 downto 0) ;
    OOK_C_UART_CTRL_OUT             <= ext_ook_c_uart_ctrl(15 downto 0) ;


    BIAS_T_A_ONOFF_OUT              <= ext_bias_t_a_ctrl_w(8)           ;
    OOK_A_DIRMD1_OUT                <= ext_bias_t_a_ctrl_w(9)           ;
    OOK_A_DIRMD2_OUT                <= ext_bias_t_a_ctrl_w(10)          ;

    BIAS_T_C_ONOFF_OUT              <= ext_bias_t_c_ctrl_w(8)           ;
    OOK_C_DIRMD1_OUT                <= ext_bias_t_c_ctrl_w(9)           ;
    OOK_C_DIRMD2_OUT                <= ext_bias_t_c_ctrl_w(10)          ;
    BIAST_3P3V_EN                   <= ext_bias_t_a_ctrl_w(12)          ;
    TRX_RF_EN_5P0V                  <= ext_bias_t_a_ctrl_w(13)          ;

    ext_bias_t_a_ctrl_r(10 downto 0)    <= ext_bias_t_a_ctrl_w(10 downto 0) ;
    ext_bias_t_a_ctrl_r(11)             <= i_ook_a_dir_lat(0)               ;
    ext_bias_t_a_ctrl_r(31 downto 12)   <= ext_bias_t_a_ctrl_w(31 downto 12);

    ext_bias_t_c_ctrl_r(10 downto 0)    <= ext_bias_t_c_ctrl_w(10 downto 0) ;
    ext_bias_t_c_ctrl_r(11)             <= i_ook_c_dir_lat(0)               ;
    ext_bias_t_c_ctrl_r(31 downto 12)   <= ext_bias_t_c_ctrl_w(31 downto 12);

    I_t_rf_swoff    <= r_t_rf_swoff(10 downto 0);
    I_t_dl_dly      <= r_t_dl_dly(10 downto 0);
    I_t_pa_off      <= r_t_pa_off(10 downto 0);
    
                 
    PA_DRV_ONOFF <= pa_drv_onoff_r(0);
    -------------------------------------------------------------------------------------------
    -------------------------------------- Input Assign ---------------------------------------
    -------------------------------------------------------------------------------------------
    eth_phy_uda_w(0)                    <= UDA(0);
    eth_phy_uda_w(4)                    <= UDA(1);
    eth_phy_uda_w(8)                    <= UDA(2);
    eth_phy_uda_w(12)                   <= UDA(3);

    docomo_uda_w(0)                     <= UDA_D(0);
    docomo_uda_w(4)                     <= UDA_D(1);
    docomo_uda_w(8)                     <= UDA_D(2);
    docomo_uda_w(12)                    <= UDA_D(3);
    docomo_uda_w(16)                    <= UDA_D(4);
    docomo_uda_w(20)                    <= UDA_D(5);
    docomo_uda_w(24)                    <= UDA_D(6);
    docomo_uda_w(28)                    <= UDA_D(7);



    clk_pll_los_w(0)                    <= CLK_PLL_LOS;
    clk_pll_ld_w(0)                     <= CLK_PLL_LD;
    clk_pll_ld_rsvd_w(0)                <= CLK_PLL_LD_RSVD;

    -- GPIO
    GPIO_INPUT_DC_and_MAPPING : for I in 0 to (RFIC_NUM-1) generate
    begin
        process(RST_CPU, CLK_CPU)
        begin
            if RST_CPU = '1' then
                rfic_gpio_in_d1(I)  <= (others => '0');
                rfic_gpio_in_d2(I)  <= (others => '0');

                rfic_intr_d1(I)     <= '0';
                rfic_intr_d2(I)     <= '0';

            elsif rising_edge(CLK_CPU) then
                rfic_gpio_in_d1(I)  <= RFIC_GPIO_IN(I);
                rfic_gpio_in_d2(I)  <= rfic_gpio_in_d1(I);

                rfic_intr_d1(I)     <= RFIC_GP_INTERRUPT(I);
                rfic_intr_d2(I)     <= rfic_intr_d1(I);
            end if;
        end process;



        rfic_intr_gpio_w(0)(5)     <= rfic_gpio_in_d2(0)(5);    -- 5
        rfic_intr_gpio_w(0)(1)     <= rfic_gpio_in_d2(0)(1);    -- 1
        rfic_intr_gpio_w(0)(6)     <= rfic_gpio_in_d2(0)(6);    -- 6
        rfic_intr_gpio_w(0)(2)     <= rfic_gpio_in_d2(0)(2);    -- 2
        rfic_intr_gpio_w(I)(RFIC_B13_TXOBS_SELECT)          <= rfic_gpio_in_d2(I)(RFIC_B13_TXOBS_SELECT);         --13
        rfic_intr_gpio_w(I)(28)                            <= rfic_intr_d2(I);

    end generate;

    process(RST_CPU, CLK_CPU)
    begin
        if RST_CPU = '1' then
            fpga_pwr_status_d1      <= '0';
            fpga_pwr_status_d2      <= '0';
        elsif rising_edge(CLK_CPU) then
            fpga_pwr_status_d1      <= FPGA_PWR_STATUS ;
            fpga_pwr_status_d2      <= fpga_pwr_status_d1;

        end if;
    end process;

    ext_fpga_pwr_sts_w              <= zeros(31 downto 1) & fpga_pwr_status_d2;

    --NPI Status
    npi_wr_ept_sts_w                <= zeros(31 downto 1) & DMA_WR_EMPTY_IN ;
    npi_wr_ful_sts_w                <= zeros(31 downto 1) & DMA_WR_FULL_IN ;
    npi_rd_ept_sts_w                <= zeros(31 downto 1) & DMA_RD_EMPTY_IN ;
    npi_rd_ful_sts_w                <= zeros(31 downto 1) & DMA_RD_FULL_IN ;


    ----------------------------------------------------------------------------------------------

    process(RST_CPU, CLK_CPU)
    begin
        if (RST_CPU = '1') then
            SADUMP_VAL_OUT          <= '0';
        elsif (CLK_CPU'event and CLK_CPU = '1') then
            if (ADDR_CPU_IN(15 downto 8) = x"A2") then
                SADUMP_VAL_OUT      <= WREN_CPU_IN;
            else
                SADUMP_VAL_OUT      <= '0';
            end if;
        end if;
    end process;

-----------------------------------------------------------------------------------------------
-- STROBE Signal Generation for Register Write between different Clock domain
-----------------------------------------------------------------------------------------------
    WREN_DLY_GEN_100: process(RST_CPU, CLK_CPU)
    begin
        if (RST_CPU = '1') then
            wren_d1_100             <= '0';
            wren_d2_100             <= '0';
        elsif (CLK_CPU'event and CLK_CPU = '1') then
            wren_d1_100             <= WREN_CPU_IN;
            wren_d2_100             <= wren_d1_100;
        end if;
    end process;

    WREN_DLY_GEN_122p88: process(i_sysclk_x4_rst, CLK_SYSX4)   -- sysx4 : 122.88 MHz
    begin
        if (i_sysclk_x4_rst = '1') then
            wren_d1_sysx4           <= '0';
            wren_d2_sysx4           <= '0';
            wren_d3_sysx4           <= '0';
        elsif (CLK_SYSX4'event and CLK_SYSX4 = '1') then
            wren_d1_sysx4           <= WREN_CPU_IN;
            wren_d2_sysx4           <= wren_d1_sysx4;
            wren_d3_sysx4           <= wren_d2_sysx4;
        end if;
    end process;

    WREN_DLY_GEN_245p76 : process(i_sysclk_x8_rst, CLK_SYSX8)   -- sysx8 : 245.76 MHz
    begin
        if (i_sysclk_x8_rst = '1') then
            wren_d1_sysx8           <= '0';
            wren_d2_sysx8           <= '0';
            wren_d3_sysx8           <= '0';
        elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            wren_d1_sysx8           <= WREN_CPU_IN;
            wren_d2_sysx8           <= wren_d1_sysx8;
            wren_d3_sysx8           <= wren_d2_sysx8;
        end if;
    end process;

    WREN_DLY_GEN_307p2 : process(i_sysclk_x10_rst, CLK_SYSX10)    -- sysx10 : 307.2 MHz
    begin
        if (i_sysclk_x10_rst = '1') then
            wren_d1_sysx10          <= '0';
            wren_d2_sysx10          <= '0';
            wren_d3_sysx10          <= '0';
        elsif (CLK_SYSX10'event and CLK_SYSX10 = '1') then
            wren_d1_sysx10          <= WREN_CPU_IN;
            wren_d2_sysx10          <= wren_d1_sysx10;
            wren_d3_sysx10          <= wren_d2_sysx10;
        end if;
    end process;

    WREN_DLY_GEN_200 : process(i_miscclk_x3, CLK_MISC3)      -- misc3 : 200 MHz
    begin
        if (i_miscclk_x3 = '1') then
            wren_d1_misc3          <= '0';
            wren_d2_misc3          <= '0';
            wren_d3_misc3          <= '0';
        elsif (CLK_MISC3'event and CLK_MISC3 = '1') then
            wren_d1_misc3          <= WREN_CPU_IN;
            wren_d2_misc3          <= wren_d1_misc3;
            wren_d3_misc3          <= wren_d2_misc3;
        end if;
    end process;

    WREN_PLS_GEN_100 : process(RST_CPU, CLK_CPU)
    begin
        if (RST_CPU = '1') then
            wren_pls_A0             <= '0';
            wren_pls_A2             <= '0';
            wren_pls_A6             <= '0';
            wren_pls_B0             <= '0';
            wren_pls_B1             <= '0';
            wren_pls_B4             <= '0';
        elsif (CLK_CPU'event and CLK_CPU = '1') then
            if (wren_d1_100 = '1' and wren_d2_100 = '0') then -- rising edge detection
                case ADDR_CPU_IN(15 downto 8) is
                    when x"A0"      => wren_pls_A0 <= '1'; wren_pls_A2 <= '0'; wren_pls_A6 <= '0'; wren_pls_B0 <= '0'; wren_pls_B1 <= '0'; wren_pls_B4 <= '0';
                    when x"A2"      => wren_pls_A0 <= '0'; wren_pls_A2 <= '1'; wren_pls_A6 <= '0'; wren_pls_B0 <= '0'; wren_pls_B1 <= '0'; wren_pls_B4 <= '0';
                    when x"A6"      => wren_pls_A0 <= '0'; wren_pls_A2 <= '0'; wren_pls_A6 <= '1'; wren_pls_B0 <= '0'; wren_pls_B1 <= '0'; wren_pls_B4 <= '0';
                    when x"B0"      => wren_pls_A0 <= '0'; wren_pls_A2 <= '0'; wren_pls_A6 <= '0'; wren_pls_B0 <= '1'; wren_pls_B1 <= '0'; wren_pls_B4 <= '0';
                    when x"B1"      => wren_pls_A0 <= '0'; wren_pls_A2 <= '0'; wren_pls_A6 <= '0'; wren_pls_B0 <= '0'; wren_pls_B1 <= '1'; wren_pls_B4 <= '0';
                    when x"B4"      => wren_pls_A0 <= '0'; wren_pls_A2 <= '0'; wren_pls_A6 <= '0'; wren_pls_B0 <= '0'; wren_pls_B1 <= '0'; wren_pls_B4 <= '1';
                    when others     => wren_pls_A0 <= '0'; wren_pls_A2 <= '0'; wren_pls_A6 <= '0'; wren_pls_B0 <= '0'; wren_pls_B1 <= '0'; wren_pls_B4 <= '0';
                end case;
            else
                wren_pls_A0 <= '0';
                wren_pls_A2 <= '0';
                wren_pls_A6 <= '0';
                wren_pls_B0 <= '0';
                wren_pls_B1 <= '0';
                wren_pls_B4 <= '0';
            end if;
        end if;
    end process;

    DMA_PLS_GEN_100 : process(RST_CPU, CLK_CPU)
    begin
        if (RST_CPU = '1') then
            dma_enable_pls          <= '0';
            dma_enable_pls_d        <= '0';
            dma_enable_pls_d2       <= '0';
        elsif (CLK_CPU'event and CLK_CPU = '1') then

            dma_enable_pls_d        <= dma_enable_pls;
            dma_enable_pls_d2       <= dma_enable_pls_d;

            if (wren_d1_100 = '1' and wren_d2_100 = '0') then -- rising edge detection
                case ADDR_CPU_IN is
                    when x"A218"    => dma_enable_pls   <= '1';
                    when others     => dma_enable_pls   <= '0';
                end case;
            else
                dma_enable_pls <= '0';
            end if;
        end if;
    end process;

    WREN_PLS_GEN_122p88: process(i_sysclk_x4_rst, CLK_SYSX4)
    begin
        if (i_sysclk_x4_rst = '1') then
            wren_pls_A8 <= '0';
        elsif (CLK_SYSX4'event and CLK_SYSX4 = '1') then
            if (wren_d2_sysx4 = '1' and wren_d3_sysx4 = '0') then -- rising edge detection
                case ADDR_CPU_IN(15 downto 8) is
                    when x"A8"  => wren_pls_A8 <= '1';
                    when others => wren_pls_A8 <= '0';
                end case;
            else
                wren_pls_A8 <= '0';
            end if;
        end if;
    end process;

    WREN_PLS_GEN_245p76: process(i_sysclk_x8_rst, CLK_SYSX8)
    begin
        if (i_sysclk_x8_rst = '1') then
            wren_pls_A4 <= '0';
            wren_pls_AA <= '0';
            wren_pls_AE <= '0';
            wren_pls_B6 <= '0';
        elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (wren_d2_sysx8 = '1' and wren_d3_sysx8 = '0') then -- rising edge
                case ADDR_CPU_IN(15 downto 8) is
                    when x"A4"      => wren_pls_A4 <= '1'; wren_pls_AA <= '0'; wren_pls_AE <= '0'; wren_pls_B6 <= '0';
                    when x"AA"      => wren_pls_A4 <= '0'; wren_pls_AA <= '1'; wren_pls_AE <= '0'; wren_pls_B6 <= '0';
                    when x"AE"      => wren_pls_A4 <= '0'; wren_pls_AA <= '0'; wren_pls_AE <= '1'; wren_pls_B6 <= '0';
                    when x"B6"      => wren_pls_A4 <= '0'; wren_pls_AA <= '0'; wren_pls_AE <= '0'; wren_pls_B6 <= '1';
                    when others     => wren_pls_A4 <= '0'; wren_pls_AA <= '0'; wren_pls_AE <= '0'; wren_pls_B6 <= '0';
                end case;
            else
                wren_pls_A4 <= '0';
                wren_pls_AA <= '0';
                wren_pls_AE <= '0';
                wren_pls_B6 <= '0';
            end if;
        end if;
    end process;

    --
    --WREN_PLS_GEN_307p2: process(i_sysclk_x10_rst, CLK_SYSX10)
    --begin
    --    if (i_sysclk_x10_rst = '1') then
    --    elsif (CLK_SYSX10'event and CLK_SYSX10 = '1') then
    --        if (wren_d2_sysx10 = '1' and wren_d3_sysx10 = '0') then -- rising edge
    --            case ADDR_CPU_IN(15 downto 8) is
    --                when x"??"  =>
    --                when others =>
    --            end case;
    --        else
    --        end if;
    --    end if;
    --end process;

--    WREN_PLS_GEN_200: process(i_miscclk_x3, CLK_MISC3)
--    begin
--        if (i_miscclk_x3 = '1') then
--            wren_pls_A6 <= '0';
--        elsif (CLK_MISC3'event and CLK_MISC3 = '1') then
--            if (wren_d2_misc3 = '1' and wren_d3_misc3 = '0') then -- rising edge
--                case ADDR_CPU_IN(15 downto 8) is
--                    when x"A6"      => wren_pls_A6 <= '1';
--                    when others     => wren_pls_A6 <= '0';
--                end case;
--            else
--                wren_pls_A6 <= '0';
--            end if;
--        end if;
--    end process;

---------------------------------------------------------------------------------------------------------------------------------------------------------
-- Register Write  -- 100 MHz domain
---------------------------------------------------------------------------------------------------------------------------------------------------------
--MISC
REG32_WRITE_0xA00D : REG32_WRITE generic map(x"00000001", x"0D", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A0,ADDRL8B,WDATA,i_tp_sel);
REG32_WRITE_0xA00E : REG32_WRITE generic map(x"000000FF", x"0E", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A0,ADDRL8B,WDATA,rst_ctrl_test_reg_100);


--SA & DUMP
REG32_WRITE_0xA210 : REG32_WRITE generic map(x"FFFFFFFF", x"10", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A2,ADDRL8B,WDATA,sadump_start_point_sel_reg_100);
REG32_WRITE_0xA211 : REG32_WRITE generic map(x"0FFF03FF", x"11", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A2,ADDRL8B,WDATA,sadump_module_set_reg_100);
REG32_WRITE_0xA212 : REG32_WRITE generic map(x"00000001", x"12", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A2,ADDRL8B,WDATA,sadump_cap_status_reg_100);
REG32_WRITE_0xA213 : REG32_WRITE generic map(x"000001FF", x"13", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A2,ADDRL8B,WDATA,sadump_txsa_set_reg_100);
REG32_WRITE_0xA214 : REG32_WRITE generic map(x"00FFFFFF", x"14", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A2,ADDRL8B,WDATA,sadump_txsa_clkdlyvalue_reg_100);
REG32_WRITE_0xA216 : REG32_WRITE generic map(x"001FFFFF", x"16", x"001FFF00") port map(RST_CPU,CLK_CPU,wren_pls_A2,ADDRL8B,WDATA,sadump_fixed_ptn_set_reg_100);
REG32_WRITE_0xA217 : REG32_WRITE generic map(x"00000101", x"17", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A2,ADDRL8B,WDATA,sadump_fixed_ptn_status_reg_100);
REG32_WRITE_0xA218 : REG32_WRITE generic map(x"03FFFFFF", x"18", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A2,ADDRL8B,WDATA,sadump_dma_set_reg_100);
REG32_WRITE_0xA21A : REG32_WRITE generic map(x"00FFFFFF", x"1A", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A2,ADDRL8B,WDATA,sadump_dma_start_point_set_reg_100);

REG32_WRITE_0xA220 : REG32_WRITE generic map(x"0000000F", x"20", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A2,ADDRL8B,WDATA,sadump_dump_operating_mode_reg_100);

-- Optional external device
REG32_WRITE_0xB010 : REG32_WRITE generic map(x"00000001", x"10", x"00000001") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,rst_ext_phy_reg_100);
REG32_WRITE_0xB011 : REG32_WRITE generic map(x"00000003", x"11", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,rst_ext_pll_reg_100);
REG32_WRITE_0xB012 : REG32_WRITE generic map(x"00000001", x"12", x"00000001") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_dlmk_sync_reg_100);
REG32_WRITE_0xB013 : REG32_WRITE generic map(x"00000001", x"13", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_enb_ctrl_reg_100);
REG32_WRITE_0xB014 : REG32_WRITE generic map(x"00000011", x"14", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_amp_amc_rst_reg_100);

-- EXTDEV_PSU_AMP_48V_ONOFF
REG32_WRITE_0xB030 : REG32_WRITE generic map(x"0000000F", x"30", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_amp_48v_onoff_reg_100);

-- RF TX Switch Control
REG32_WRITE_0xB0D0 : REG32_WRITE generic map(x"0000000F", x"D0", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_tx_sw_ctrl_reg_100);
REG32_WRITE_0xB0D1 : REG32_WRITE generic map(x"0000000F", x"D1", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_rf_enb_ctrl_reg_100);

REG32_WRITE_0xB0DC : REG32_WRITE generic map(x"00000001", x"DC", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,i_sw_timeout_control);

-- RX Attenuation Control
REG32_WRITE_0xB0E0 : REG32_WRITE generic map(x"0000000F", x"E0", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_rxatt_enb_reg_100);
REG32_WRITE_0xB0E1 : REG32_WRITE generic map(x"000000FF", x"E1", x"0000007F") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_rxatt_word_a_reg_100);
REG32_WRITE_0xB0E2 : REG32_WRITE generic map(x"000000FF", x"E2", x"0000007F") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_rxatt_word_b_reg_100);
REG32_WRITE_0xB0E3 : REG32_WRITE generic map(x"000000FF", x"E3", x"0000007F") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_rxatt_word_c_reg_100);
REG32_WRITE_0xB0E4 : REG32_WRITE generic map(x"000000FF", x"E4", x"0000007F") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_rxatt_word_d_reg_100);

-- Optional Control
REG32_WRITE_0xB0F0 : REG32_WRITE generic map(x"00000001", x"F0", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_tdd_dir_reg_100);
REG32_WRITE_0xB0F1 : REG32_WRITE generic map(x"00000001", x"F1", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_clk_dir_reg_100);
REG32_WRITE_0xB0F2 : REG32_WRITE generic map(x"0000000F", x"F2", x"0000000F") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_fpga_rst_reg_100);
REG32_WRITE_0xB0F3 : REG32_WRITE generic map(x"000000FF", x"F3", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_isppac_ctrl_reg_100);
REG32_WRITE_0xB0F6 : REG32_WRITE generic map(x"000000FF", x"F6", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_amp_enb_ctrl_reg_100);

REG32_WRITE_0xB0F7 : REG32_WRITE generic map(x"00010FFF", x"F7", x"00010008") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_analog_dl_dly_reg_100);
REG32_WRITE_0xB0F8 : REG32_WRITE generic map(x"00010FFF", x"F8", x"00010008") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_analog_ul_dly_reg_100);
REG32_WRITE_0xB0F9 : REG32_WRITE generic map(x"00010FFF", x"F9", x"00010008") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_analog_fb_dly_reg_100);
REG32_WRITE_0xB0FA : REG32_WRITE generic map(x"000000FF", x"FA", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_trx_sw_ctrl_reg_100);
REG32_WRITE_0xB0FB : REG32_WRITE generic map(x"0000000F", x"FB", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_trx_tql_9092_on_reg_100);
REG32_WRITE_0xB0FC : REG32_WRITE generic map(x"0000000F", x"FC", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_func_fail_masking_reg_100);
REG32_WRITE_0xB0FD : REG32_WRITE generic map(x"00010FFF", x"FD", x"00010008") port map(RST_CPU,CLK_CPU,wren_pls_B0,ADDRL8B,WDATA,ext_bcf_en_dly_reg_100);

-- RET & Bias-T Control
REG32_WRITE_0xB100 : REG32_WRITE generic map(x"FFFFFFFF", x"00", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B1,ADDRL8B,WDATA,ext_ret_uart_ctrl);
REG32_WRITE_0xB105 : REG32_WRITE generic map(x"FFFFFFFF", x"05", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B1,ADDRL8B,WDATA,ext_ret_onoff_ctrl);
REG32_WRITE_0xB110 : REG32_WRITE generic map(x"FFFFFFFF", x"10", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B1,ADDRL8B,WDATA,ext_ook_a_uart_ctrl);
REG32_WRITE_0xB115 : REG32_WRITE generic map(x"FFFFFFFF", x"15", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B1,ADDRL8B,WDATA,ext_bias_t_a_ctrl_w);
REG32_WRITE_0xB120 : REG32_WRITE generic map(x"FFFFFFFF", x"20", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B1,ADDRL8B,WDATA,ext_ook_c_uart_ctrl);
REG32_WRITE_0xB125 : REG32_WRITE generic map(x"FFFFFFFF", x"25", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B1,ADDRL8B,WDATA,ext_bias_t_c_ctrl_w);

-- RFIC control
REG32_WRITE_0xB410 : REG32_WRITE generic map(x"0000000F", x"10", x"0000000F") port map(RST_CPU,CLK_CPU,wren_pls_B4,ADDRL8B,WDATA,rfic_rst_ctrl_reg_100);
REG32_WRITE_0xB411 : REG32_WRITE generic map(x"FFFFFFFF", x"11", x"00030000") port map(RST_CPU,CLK_CPU,wren_pls_B4,ADDRL8B,WDATA,rfic_pwr_ctrl_reg_100);
REG32_WRITE_0xB412 : REG32_WRITE generic map(x"00003333", x"12", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B4,ADDRL8B,WDATA,rfic_tx_enb_ctrl_reg_100);
REG32_WRITE_0xB413 : REG32_WRITE generic map(x"00003333", x"13", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B4,ADDRL8B,WDATA,rfic_rx_enb_ctrl_reg_100);

REG32_WRITE_0xB416 : REG32_WRITE generic map(x"00070200", x"16", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B4,ADDRL8B,WDATA,rfic_intr_gpio_set0_reg_100);
REG32_WRITE_0xB41C : REG32_WRITE generic map(x"00070200", x"1C", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B4,ADDRL8B,WDATA,rfic_intr_gpio_set1_reg_100);
REG32_WRITE_0xB422 : REG32_WRITE generic map(x"00070200", x"22", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B4,ADDRL8B,WDATA,rfic_intr_gpio_set2_reg_100);
REG32_WRITE_0xB428 : REG32_WRITE generic map(x"00070200", x"28", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B4,ADDRL8B,WDATA,rfic_intr_gpio_set3_reg_100);


REG32_WRITE_0xB126 : REG32_WRITE generic map(x"00000001", x"26", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_B1,ADDRL8B,WDATA,pa_drv_onoff_r);




---------------------------------------------------------------------------------------------------------------------------------------------------------
-- Register Write  -- 122.88 MHz domain
---------------------------------------------------------------------------------------------------------------------------------------------------------
REG32_WRITE_0xA804 : REG32_WRITE generic map(x"FFFFFFFF", x"04", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,sw_manual_set_r);
REG32_WRITE_0xA805 : REG32_WRITE generic map(x"FFFFFFFF", x"05", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,sw_manual_value_r);
--REG32_WRITE_0xA806 : REG32_WRITE generic map(x"FFFFFFFF", x"06", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,manual_orx_sw_reg_r);

--REG32_WRITE_0xA807 : REG32_WRITE generic map(x"FFFFFFFF", x"07", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,manual_rev_sw_0_reg_r);
--REG32_WRITE_0xA808 : REG32_WRITE generic map(x"FFFFFFFF", x"08", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,manual_fb_rev_sw_0_reg_r);
REG32_WRITE_0xA809 : REG32_WRITE generic map(x"FFFFFFFF", x"09", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,manual_rfic_orx_trigger_reg_r);
REG32_WRITE_0xA80A : REG32_WRITE generic map(x"FFFFFFFF", x"0A", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,manual_rfic_orx_mode_reg_r);
--REG32_WRITE_0xA80B : REG32_WRITE generic map(x"FFFFFFFF", x"0B", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,manual_orx_rev_sw_invt_reg_r);
REG32_WRITE_0xA80C : REG32_WRITE generic map(x"FFFFFFFF", x"0C", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,manual_fb_sw_ctrl_value_reg_r);


REG32_WRITE_0xA810 : REG32_WRITE generic map(x"FFFFFFFF", x"10", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,fb_sw_mode_r(0));
--REG32_WRITE_0xA811 : REG32_WRITE generic map(x"FFFFFFFF", x"11", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,fb_sw_mode_r(1));
--REG32_WRITE_0xA812 : REG32_WRITE generic map(x"FFFFFFFF", x"12", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,fb_sw_mode_r(2));
--REG32_WRITE_0xA813 : REG32_WRITE generic map(x"FFFFFFFF", x"13", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,fb_sw_mode_r(3));

REG32_WRITE_0xA814 : REG32_WRITE generic map(x"0000000F", x"14", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,resync_manual_r);
REG32_WRITE_0xA815 : REG32_WRITE generic map(x"0000000F", x"15", x"00000001") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,resync_enable_r);
--REG32_WRITE_0xA816 : REG32_WRITE generic map(x"FFFFFFFF", x"16", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,resync_status_r); -- read only

--REG32_WRITE_0xA820 : REG32_WRITE generic map(x"FFFFFFFF", x"20", x"000061A8") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,bfn_cnt_reg_r);
--REG32_WRITE_0xA821 : REG32_WRITE generic map(x"FFFFFFFF", x"21", x"00000000") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,rfic_cal_mode_chg_ri_cnt_reg);
--REG32_WRITE_0xA822 : REG32_WRITE generic map(x"FFFFFFFF", x"22", x"00000267") port map(i_sysclk_x4_rst,CLK_SYSX4,wren_pls_A8,ADDRL8B,WDATA,rfic_cal_mode_chg_fa_cnt_reg);

---------------------------------------------------------------------------------------------------------------------------------------------------------
-- Register Write  -- 245.76 MHz domain
---------------------------------------------------------------------------------------------------------------------------------------------------------
REG32_WRITE_0xA410 : REG32_WRITE generic map(x"FFFFFFFF", x"10", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_A4,ADDRL8B,WDATA,dpa_en_r);
REG32_WRITE_0xA411 : REG32_WRITE generic map(x"FFFFFFFF", x"11", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_A4,ADDRL8B,WDATA,dpa_trx_data_dly_time_r);
REG32_WRITE_0xA412 : REG32_WRITE generic map(x"FFFFFFFF", x"12", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_A4,ADDRL8B,WDATA,dpa_rise_resp_time_r);
REG32_WRITE_0xA413 : REG32_WRITE generic map(x"FFFFFFFF", x"13", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_A4,ADDRL8B,WDATA,dpa_fall_resp_time_r);
REG32_WRITE_0xA414 : REG32_WRITE generic map(x"FFFFFFFF", x"14", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_A4,ADDRL8B,WDATA,dpa_off_mon_time_r);


REG32_WRITE_0xB600 : REG32_WRITE generic map(x"FFFFFFFF", x"00", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_B6,ADDRL8B,WDATA,etm_tp_mem_port_en);
REG32_WRITE_0xB601 : REG32_WRITE generic map(x"FFFFFFFF", x"01", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_B6,ADDRL8B,WDATA,etm_tp_mem_wr_en);
REG32_WRITE_0xB602 : REG32_WRITE generic map(x"FFFFFFFF", x"02", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_B6,ADDRL8B,WDATA,etm_tp_mem_wraddr);
REG32_WRITE_0xB603 : REG32_WRITE generic map(x"FFFFFFFF", x"03", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_B6,ADDRL8B,WDATA,etm_tp_mem_wrdata);
---------------------------------------------------------------------------------------------------------------------------------------------------------

REG32_WRITE_0xAA10 : REG32_WRITE generic map(x"FFFFFFFF", x"10", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,equip_offset_r);
REG32_WRITE_0xAA11 : REG32_WRITE generic map(x"FFFFFFFF", x"11", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,equip_onoff_r);

REG32_WRITE_0xAA15 : REG32_WRITE generic map(x"FFFFFFFF", x"15", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,trxsw_tx_offset_r);
REG32_WRITE_0xAA16 : REG32_WRITE generic map(x"FFFFFFFF", x"16", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,trxsw_tx_onoff_r);
REG32_WRITE_0xAA17 : REG32_WRITE generic map(x"FFFFFFFF", x"17", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,trxsw_rx_offset_r);
REG32_WRITE_0xAA18 : REG32_WRITE generic map(x"FFFFFFFF", x"18", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,trxsw_rx_onoff_r);

REG32_WRITE_0xAA20 : REG32_WRITE generic map(x"FFFFFFFF", x"20", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txa_sw_offset_r(0));
REG32_WRITE_0xAA21 : REG32_WRITE generic map(x"FFFFFFFF", x"21", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txa_sw_onoff_r(0));
--REG32_WRITE_0xAA22 : REG32_WRITE generic map(x"FFFFFFFF", x"22", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txa_sw_offset_r(1));
--REG32_WRITE_0xAA23 : REG32_WRITE generic map(x"FFFFFFFF", x"23", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txa_sw_onoff_r(1));
--REG32_WRITE_0xAA24 : REG32_WRITE generic map(x"FFFFFFFF", x"24", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txa_sw_offset_r(2));
--REG32_WRITE_0xAA25 : REG32_WRITE generic map(x"FFFFFFFF", x"25", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txa_sw_onoff_r(2));
--REG32_WRITE_0xAA26 : REG32_WRITE generic map(x"FFFFFFFF", x"26", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txa_sw_offset_r(3));
--REG32_WRITE_0xAA27 : REG32_WRITE generic map(x"FFFFFFFF", x"27", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txa_sw_onoff_r(3));
---------------------------------------------------------------------------------------------------------------------------------------------------------

REG32_WRITE_0xAA30 : REG32_WRITE generic map(x"FFFFFFFF", x"30", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txb_sw_offset_r(0));
REG32_WRITE_0xAA31 : REG32_WRITE generic map(x"FFFFFFFF", x"31", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txb_sw_onoff_r(0));
--REG32_WRITE_0xAA32 : REG32_WRITE generic map(x"FFFFFFFF", x"32", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txb_sw_offset_r(1));
--REG32_WRITE_0xAA33 : REG32_WRITE generic map(x"FFFFFFFF", x"33", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txb_sw_onoff_r(1));
--REG32_WRITE_0xAA34 : REG32_WRITE generic map(x"FFFFFFFF", x"34", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txb_sw_offset_r(2));
--REG32_WRITE_0xAA35 : REG32_WRITE generic map(x"FFFFFFFF", x"35", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txb_sw_onoff_r(2));
--REG32_WRITE_0xAA36 : REG32_WRITE generic map(x"FFFFFFFF", x"36", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txb_sw_offset_r(3));
--REG32_WRITE_0xAA37 : REG32_WRITE generic map(x"FFFFFFFF", x"37", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_txb_sw_onoff_r(3));
---------------------------------------------------------------------------------------------------------------------------------------------------------
REG32_WRITE_0xAA40 : REG32_WRITE generic map(x"FFFFFFFF", x"40", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_offset_r(0));
REG32_WRITE_0xAA41 : REG32_WRITE generic map(x"FFFFFFFF", x"41", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_onoff_r(0));
REG32_WRITE_0xAA42 : REG32_WRITE generic map(x"FFFFFFFF", x"42", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_offset_r(1));
REG32_WRITE_0xAA43 : REG32_WRITE generic map(x"FFFFFFFF", x"43", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_onoff_r(1));
--REG32_WRITE_0xAA44 : REG32_WRITE generic map(x"FFFFFFFF", x"44", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_offset_r(2));
--REG32_WRITE_0xAA45 : REG32_WRITE generic map(x"FFFFFFFF", x"45", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_onoff_r(2));
--REG32_WRITE_0xAA46 : REG32_WRITE generic map(x"FFFFFFFF", x"46", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_offset_r(3));
--REG32_WRITE_0xAA47 : REG32_WRITE generic map(x"FFFFFFFF", x"47", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_onoff_r(3));
--REG32_WRITE_0xAA48 : REG32_WRITE generic map(x"FFFFFFFF", x"48", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_offset_r(4));
--REG32_WRITE_0xAA49 : REG32_WRITE generic map(x"FFFFFFFF", x"49", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_onoff_r(4));
--REG32_WRITE_0xAA4A : REG32_WRITE generic map(x"FFFFFFFF", x"4A", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_offset_r(5));
--REG32_WRITE_0xAA4B : REG32_WRITE generic map(x"FFFFFFFF", x"4B", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_onoff_r(5));
--REG32_WRITE_0xAA4C : REG32_WRITE generic map(x"FFFFFFFF", x"4C", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_offset_r(6));
--REG32_WRITE_0xAA4D : REG32_WRITE generic map(x"FFFFFFFF", x"4D", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_onoff_r(6));
--REG32_WRITE_0xAA4E : REG32_WRITE generic map(x"FFFFFFFF", x"4E", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_offset_r(7));
--REG32_WRITE_0xAA4F : REG32_WRITE generic map(x"FFFFFFFF", x"4F", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,amp_en_onoff_r(7));

REG32_WRITE_0xAA60 : REG32_WRITE generic map(x"FFFFFFFF", x"60", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_offset_r(0)(0));   -- std_logic_array2_array19(RFIC_NUM - 1 downto 0);
REG32_WRITE_0xAA61 : REG32_WRITE generic map(x"FFFFFFFF", x"61", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_onoff_r(0)(0));    -- (RFIC_NUM)(array2)(array32)
REG32_WRITE_0xAA62 : REG32_WRITE generic map(x"FFFFFFFF", x"62", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_offset_r(0)(1));
REG32_WRITE_0xAA63 : REG32_WRITE generic map(x"FFFFFFFF", x"63", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_onoff_r(0)(1));
--REG32_WRITE_0xAA64 : REG32_WRITE generic map(x"FFFFFFFF", x"64", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_offset_r(1)(0));
--REG32_WRITE_0xAA65 : REG32_WRITE generic map(x"FFFFFFFF", x"65", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_onoff_r(1)(0));
--REG32_WRITE_0xAA66 : REG32_WRITE generic map(x"FFFFFFFF", x"66", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_offset_r(1)(1));
--REG32_WRITE_0xAA67 : REG32_WRITE generic map(x"FFFFFFFF", x"67", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_onoff_r(1)(1));
--REG32_WRITE_0xAA68 : REG32_WRITE generic map(x"FFFFFFFF", x"68", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_offset_r(2)(0));
--REG32_WRITE_0xAA69 : REG32_WRITE generic map(x"FFFFFFFF", x"69", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_onoff_r(2)(0));
--REG32_WRITE_0xAA6A : REG32_WRITE generic map(x"FFFFFFFF", x"6A", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_offset_r(2)(1));
--REG32_WRITE_0xAA6B : REG32_WRITE generic map(x"FFFFFFFF", x"6B", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_onoff_r(2)(1));
--REG32_WRITE_0xAA6C : REG32_WRITE generic map(x"FFFFFFFF", x"6C", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_offset_r(3)(0));
--REG32_WRITE_0xAA6D : REG32_WRITE generic map(x"FFFFFFFF", x"6D", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_onoff_r(3)(0));
--REG32_WRITE_0xAA6E : REG32_WRITE generic map(x"FFFFFFFF", x"6E", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_offset_r(3)(1));
--REG32_WRITE_0xAA6F : REG32_WRITE generic map(x"FFFFFFFF", x"6F", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_tx_en_onoff_r(3)(1));

REG32_WRITE_0xAA80 : REG32_WRITE generic map(x"FFFFFFFF", x"80", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_offset_r(0)(0));   -- std_logic_array2_array19(RFIC_NUM - 1 downto 0);
REG32_WRITE_0xAA81 : REG32_WRITE generic map(x"FFFFFFFF", x"81", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_onoff_r(0)(0));    -- (RFIC_NUM)(array2)(array32)
REG32_WRITE_0xAA82 : REG32_WRITE generic map(x"FFFFFFFF", x"82", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_offset_r(0)(1));
REG32_WRITE_0xAA83 : REG32_WRITE generic map(x"FFFFFFFF", x"83", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_onoff_r(0)(1));
--REG32_WRITE_0xAA84 : REG32_WRITE generic map(x"FFFFFFFF", x"84", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_offset_r(1)(0));
--REG32_WRITE_0xAA85 : REG32_WRITE generic map(x"FFFFFFFF", x"85", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_onoff_r(1)(0));
--REG32_WRITE_0xAA86 : REG32_WRITE generic map(x"FFFFFFFF", x"86", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_offset_r(1)(1));
--REG32_WRITE_0xAA87 : REG32_WRITE generic map(x"FFFFFFFF", x"87", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_onoff_r(1)(1));
--REG32_WRITE_0xAA88 : REG32_WRITE generic map(x"FFFFFFFF", x"88", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_offset_r(2)(0));
--REG32_WRITE_0xAA89 : REG32_WRITE generic map(x"FFFFFFFF", x"89", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_onoff_r(2)(0));
--REG32_WRITE_0xAA8A : REG32_WRITE generic map(x"FFFFFFFF", x"8A", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_offset_r(2)(1));
--REG32_WRITE_0xAA8B : REG32_WRITE generic map(x"FFFFFFFF", x"8B", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_onoff_r(2)(1));
--REG32_WRITE_0xAA8C : REG32_WRITE generic map(x"FFFFFFFF", x"8C", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_offset_r(3)(0));
--REG32_WRITE_0xAA8D : REG32_WRITE generic map(x"FFFFFFFF", x"8D", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_onoff_r(3)(0));
--REG32_WRITE_0xAA8E : REG32_WRITE generic map(x"FFFFFFFF", x"8E", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_offset_r(3)(1));
--REG32_WRITE_0xAA8F : REG32_WRITE generic map(x"FFFFFFFF", x"8F", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_rx_en_onoff_r(3)(1));

REG32_WRITE_0xAAA0 : REG32_WRITE generic map(x"FFFFFFFF", x"A0", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_pre_trig_offset_r(0));
REG32_WRITE_0xAAA1 : REG32_WRITE generic map(x"FFFFFFFF", x"A1", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_pre_trig_onoff_r(0));
--REG32_WRITE_0xAAA2 : REG32_WRITE generic map(x"FFFFFFFF", x"A2", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_pre_trig_offset_r(1));
--REG32_WRITE_0xAAA3 : REG32_WRITE generic map(x"FFFFFFFF", x"A3", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_pre_trig_onoff_r(1));
--REG32_WRITE_0xAAA4 : REG32_WRITE generic map(x"FFFFFFFF", x"A4", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_pre_trig_offset_r(2));
--REG32_WRITE_0xAAA5 : REG32_WRITE generic map(x"FFFFFFFF", x"A5", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_pre_trig_onoff_r(2));
--REG32_WRITE_0xAAA6 : REG32_WRITE generic map(x"FFFFFFFF", x"A6", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_pre_trig_offset_r(3));
--REG32_WRITE_0xAAA7 : REG32_WRITE generic map(x"FFFFFFFF", x"A7", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rfic_pre_trig_onoff_r(3));

REG32_WRITE_0xAAB0 : REG32_WRITE generic map(x"FFFFFFFF", x"B0", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tx_cal_sel0_offset_r);
REG32_WRITE_0xAAB1 : REG32_WRITE generic map(x"FFFFFFFF", x"B1", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tx_cal_sel0_onoff_r);
REG32_WRITE_0xAAB2 : REG32_WRITE generic map(x"FFFFFFFF", x"B2", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rx_cal_sel0_offset_r);
REG32_WRITE_0xAAB3 : REG32_WRITE generic map(x"FFFFFFFF", x"B3", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,rx_cal_sel0_onoff_r);

REG32_WRITE_0xAAC0 : REG32_WRITE generic map(x"FFFFFFFF", x"C0", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,cal_path_sel_offset_r(0));
REG32_WRITE_0xAAC1 : REG32_WRITE generic map(x"FFFFFFFF", x"C1", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,cal_path_sel_onoff_r(0));
--REG32_WRITE_0xAAC2 : REG32_WRITE generic map(x"FFFFFFFF", x"C2", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,cal_path_sel_offset_r(1));
--REG32_WRITE_0xAAC3 : REG32_WRITE generic map(x"FFFFFFFF", x"C3", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,cal_path_sel_onoff_r(1));

REG32_WRITE_0xAAD8 : REG32_WRITE generic map(x"FFFFFFFF", x"D8", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,cal_sp4t_reserved_offset_r(0));
REG32_WRITE_0xAAD9 : REG32_WRITE generic map(x"FFFFFFFF", x"D9", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,cal_sp4t_reserved_onoff_r(0));
REG32_WRITE_0xAADA : REG32_WRITE generic map(x"FFFFFFFF", x"DA", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,cal_sp4t_reserved_offset_r(1));
REG32_WRITE_0xAADB : REG32_WRITE generic map(x"FFFFFFFF", x"DB", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,cal_sp4t_reserved_onoff_r(1));
REG32_WRITE_0xAADC : REG32_WRITE generic map(x"FFFFFFFF", x"DC", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,cal_sp4t_reserved_offset_r(2));
REG32_WRITE_0xAADD : REG32_WRITE generic map(x"FFFFFFFF", x"DD", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,cal_sp4t_reserved_onoff_r(2));

REG32_WRITE_0xAAE0 : REG32_WRITE generic map(x"FFFFFFFF", x"E0", x"11111111") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tdd_and_ctrl_r(0));
REG32_WRITE_0xAAE1 : REG32_WRITE generic map(x"FFFFFFFF", x"E1", x"11111111") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tdd_and_ctrl_r(1));
REG32_WRITE_0xAAE2 : REG32_WRITE generic map(x"FFFFFFFF", x"E2", x"11111111") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tdd_and_ctrl_r(2));
REG32_WRITE_0xAAE3 : REG32_WRITE generic map(x"FFFFFFFF", x"E3", x"11111111") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tdd_and_ctrl_r(3));
REG32_WRITE_0xAAE4 : REG32_WRITE generic map(x"FFFFFFFF", x"E4", x"11111111") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tdd_and_ctrl_r(4));
REG32_WRITE_0xAAE5 : REG32_WRITE generic map(x"FFFFFFFF", x"E5", x"11111111") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tdd_and_ctrl_r(5));
REG32_WRITE_0xAAE6 : REG32_WRITE generic map(x"FFFFFFFF", x"E6", x"11111111") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tdd_and_ctrl_r(6));

REG32_WRITE_0xAAF0 : REG32_WRITE generic map(x"FFFFFFFF", x"F0", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tdd_or_ctrl_r(0));
REG32_WRITE_0xAAF1 : REG32_WRITE generic map(x"FFFFFFFF", x"F1", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tdd_or_ctrl_r(1));
REG32_WRITE_0xAAF2 : REG32_WRITE generic map(x"FFFFFFFF", x"F2", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tdd_or_ctrl_r(2));
REG32_WRITE_0xAAF3 : REG32_WRITE generic map(x"FFFFFFFF", x"F3", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tdd_or_ctrl_r(3));
REG32_WRITE_0xAAF4 : REG32_WRITE generic map(x"FFFFFFFF", x"F4", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tdd_or_ctrl_r(4));
REG32_WRITE_0xAAF5 : REG32_WRITE generic map(x"FFFFFFFF", x"F5", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tdd_or_ctrl_r(5));
REG32_WRITE_0xAAF6 : REG32_WRITE generic map(x"FFFFFFFF", x"F6", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,tdd_or_ctrl_r(6));

REG32_WRITE_0xAAFF : REG32_WRITE generic map(x"FFFFFFFF", x"FF", x"00000000") port map(i_sysclk_x8_rst,CLK_SYSX8,wren_pls_AA,ADDRL8B,WDATA,equip_tdd_select_r);


---------------------------------------------------------------------------------------------------------------------------------------------------------
-- Register Write  -- 307.2 MHz domain
---------------------------------------------------------------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------------------------------------------------------------
-- Register Write  -- 200   MHz domain
---------------------------------------------------------------------------------------------------------------------------------------------------------
REG32_WRITE_0xA610 : REG32_WRITE generic map(x"00000001", x"10", x"00000001") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,sig_sus_amp_protect_on   );
REG32_WRITE_0xA611 : REG32_WRITE generic map(x"000FFFFF", x"11", x"00004E20") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,alm_deb_cnt              );
REG32_WRITE_0xA612 : REG32_WRITE generic map(x"000000FF", x"12", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,rf_sw_off_release        );


REG32_WRITE_0xA620 : REG32_WRITE generic map(x"000000FF", x"20", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,sig_sus_cpri_link_ant(0) );
REG32_WRITE_0xA621 : REG32_WRITE generic map(x"000000FF", x"21", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,sig_sus_cpri_link_ant(1) );
REG32_WRITE_0xA622 : REG32_WRITE generic map(x"000000FF", x"22", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,sig_sus_cpri_link_ant(2) );
REG32_WRITE_0xA623 : REG32_WRITE generic map(x"000000FF", x"23", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,sig_sus_cpri_link_ant(3) );
REG32_WRITE_0xA624 : REG32_WRITE generic map(x"000000FF", x"24", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,sig_sus_cpri_link_ant(4) );
REG32_WRITE_0xA625 : REG32_WRITE generic map(x"000000FF", x"25", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,sig_sus_cpri_link_ant(5) );
REG32_WRITE_0xA626 : REG32_WRITE generic map(x"000000FF", x"26", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,sig_sus_cpri_link_ant(6) );
REG32_WRITE_0xA627 : REG32_WRITE generic map(x"000000FF", x"27", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,sig_sus_cpri_link_ant(7) );

REG32_WRITE_0xA650 : REG32_WRITE generic map(x"FFFFFFFF", x"50", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,alm_en_cpriphy           );
REG32_WRITE_0xA651 : REG32_WRITE generic map(x"FFFFFFFF", x"51", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,alm_en_sbifphy           );
REG32_WRITE_0xA652 : REG32_WRITE generic map(x"FFFFFFFF", x"52", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,alm_en_cpri              );
REG32_WRITE_0xA653 : REG32_WRITE generic map(x"FFFFFFFF", x"53", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,alm_en_sbif              );
REG32_WRITE_0xA654 : REG32_WRITE generic map(x"FFFFFFFF", x"54", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,alm_en_bbctrl            );
REG32_WRITE_0xA655 : REG32_WRITE generic map(x"FFFFFFFF", x"55", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,alm_en_dsp               );
REG32_WRITE_0xA656 : REG32_WRITE generic map(x"FFFFFFFF", x"56", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,alm_en_dcif_dl           );
REG32_WRITE_0xA657 : REG32_WRITE generic map(x"FFFFFFFF", x"57", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,alm_en_dcif_ul           );
REG32_WRITE_0xA658 : REG32_WRITE generic map(x"FFFFFFFF", x"58", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,alm_en_dcif_fb           );
REG32_WRITE_0xA659 : REG32_WRITE generic map(x"FFFFFFFF", x"59", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,alm_en_volt              );
REG32_WRITE_0xA65A : REG32_WRITE generic map(x"FFFFFFFF", x"5A", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,alm_en_pg                );
REG32_WRITE_0xA65B : REG32_WRITE generic map(x"FFFFFFFF", x"5B", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,alm_en_others            );

REG32_WRITE_0xA660 : REG32_WRITE generic map(x"FFFFFFFF", x"60", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,dl_off_cpriphy           );
REG32_WRITE_0xA661 : REG32_WRITE generic map(x"FFFFFFFF", x"61", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,dl_off_sbifphy           );
REG32_WRITE_0xA662 : REG32_WRITE generic map(x"FFFFFFFF", x"62", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,dl_off_sbif              );
REG32_WRITE_0xA663 : REG32_WRITE generic map(x"FFFFFFFF", x"63", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,dl_off_bbctrl            );
REG32_WRITE_0xA664 : REG32_WRITE generic map(x"FFFFFFFF", x"64", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,dl_off_dsp               );
REG32_WRITE_0xA665 : REG32_WRITE generic map(x"FFFFFFFF", x"65", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,dl_off_dcif              );

REG32_WRITE_0xA670 : REG32_WRITE generic map(x"FFFFFFFF", x"70", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,alm_off_volt             );
REG32_WRITE_0xA671 : REG32_WRITE generic map(x"FFFFFFFF", x"71", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,docomo_uda_tx            );

REG32_WRITE_0xA672 : REG32_WRITE generic map(x"FFFFFFFF", x"72", x"00000000") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,supper_sleep_r           );
--------------------------------------------------------------------
-- r_t_rf_swoff default value : RF SW OFF after (0.04us + 3.47us + 2.5us)
-- refer to RF2239-28A FPGA F/L 4.7.2.4.2 (Figure.28 Timing diagram for UV alarm and VSS reset)
-- 0x4B2 = 1202 => CLK_MISC3(5ns) * 1202 = 6.010 us
--------------------------------------------------------------------
REG32_WRITE_0xA682 : REG32_WRITE generic map(x"FFFFFFFF", x"82", x"000004B2") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,r_t_rf_swoff             );
-- 0x2B6 = 694 => CLK_MISC3(5ns) * 694 = 3.470 us
REG32_WRITE_0xA683 : REG32_WRITE generic map(x"FFFFFFFF", x"83", x"000002B6") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,r_t_dl_dly               );
-- 0x1F4 = 500 => CLK_MISC3(5ns) * 500 = 2.500 us
REG32_WRITE_0xA684 : REG32_WRITE generic map(x"FFFFFFFF", x"84", x"000001F4") port map(RST_CPU,CLK_CPU,wren_pls_A6,ADDRL8B,WDATA,r_t_pa_off               );

SUPPER_SLEEP_POUT <= supper_sleep_r(0 downto 0);

WAVESTOP_DISABLE_OUT    <= (not sig_sus_amp_protect_on(0));
ALM_DEB_CNT_OUT         <= alm_deb_cnt(19 downto 0);
RF_SW_OFF_RELEASE_OUT   <= rf_sw_off_release(7 downto 0);
CPRI_LINK_ANT_OUT(0)    <= sig_sus_cpri_link_ant(0)(7 downto 0);
CPRI_LINK_ANT_OUT(1)    <= sig_sus_cpri_link_ant(1)(7 downto 0);
CPRI_LINK_ANT_OUT(2)    <= sig_sus_cpri_link_ant(2)(7 downto 0);
CPRI_LINK_ANT_OUT(3)    <= sig_sus_cpri_link_ant(3)(7 downto 0);
CPRI_LINK_ANT_OUT(4)    <= sig_sus_cpri_link_ant(4)(7 downto 0);
CPRI_LINK_ANT_OUT(5)    <= sig_sus_cpri_link_ant(5)(7 downto 0);
CPRI_LINK_ANT_OUT(6)    <= sig_sus_cpri_link_ant(6)(7 downto 0);
CPRI_LINK_ANT_OUT(7)    <= sig_sus_cpri_link_ant(7)(7 downto 0);

ALM_OFF_VOLT_OUT        <= alm_off_volt(0)              ; --        : out  std_logic;                                      -- '1': Forced Alarm-off, '0': No Force
UDA_D_TX                <= docomo_uda_tx(3 downto 0)    ;
ALM_EN_CPRIPHY_OUT      <= alm_en_cpriphy(7 downto 0)   ; --        : out  std_logic_vector(                 7 downto 0);  -- '1': Forced Alarm, '0': No Force
ALM_EN_SBIFPHY_OUT      <= alm_en_sbifphy(7 downto 0)   ; --        : out  std_logic_vector(                 7 downto 0);  -- '1': Forced Alarm, '0': No Force
ALM_EN_CPRI_OUT         <= alm_en_cpri(7 downto 0)      ; --        : out  std_logic_vector(                 7 downto 0);  -- '1': Forced Alarm, '0': No Force
ALM_EN_SBIF_OUT         <= alm_en_sbif(7 downto 0)      ; --        : out  std_logic_vector(                 7 downto 0);  -- '1': Forced Alarm, '0': No Force
ALM_EN_BBCTRL_OUT       <= alm_en_bbctrl(7 downto 0)    ; --        : out  std_logic_vector(                 7 downto 0);  -- '1': Forced Alarm, '0': No Force
ALM_EN_DSP_OUT          <= alm_en_dsp(7 downto 0)       ; --        : out  std_logic_vector(                 7 downto 0);  -- '1': Forced Alarm, '0': No Force
ALM_EN_DCIF_DL_OUT      <= alm_en_dcif_dl(7 downto 0)   ; --        : out  std_logic_vector(                 7 downto 0);  -- '1': Forced Alarm, '0': No Force
ALM_EN_DCIF_UL_OUT      <= alm_en_dcif_ul(7 downto 0)   ; --        : out  std_logic_vector(                 7 downto 0);  -- '1': Forced Alarm, '0': No Force
ALM_EN_DCIF_FB_OUT      <= alm_en_dcif_fb(7 downto 0)   ; --        : out  std_logic_vector(                 7 downto 0);  -- '1': Forced Alarm, '0': No Force
ALM_EN_VOLT_OUT         <= alm_en_volt(7 downto 0)      ; --        : out  std_logic_vector(                 7 downto 0);  -- '1': Forced Alarm, '0': No Force
ALM_EN_PG_OUT           <= alm_en_pg(31 downto 0)       ; --        : out  std_logic_vector(                31 downto 0);  -- '1': Forced Alarm, '0': No Force
ALM_EN_OTHERS_OUT       <= alm_en_others(31 downto 0)   ; --        : out  std_logic_vector(                31 downto 0);  -- '1': Forced Alarm, '0': No Force

DL_OFF_CPRIPHY_OUT      <= dl_off_cpriphy(7 downto 0)   ; --        : out  std_logic_vector(                 7 downto 0);  -- '1': Forced DL Off, '0': No Force
DL_OFF_SBIFPHY_OUT      <= dl_off_sbifphy(7 downto 0)   ; --        : out  std_logic_vector(                 7 downto 0);  -- '1': Forced DL Off, '0': No Force
DL_OFF_SBIF_OUT         <= dl_off_sbif(7 downto 0)      ; --        : out  std_logic_vector(                 7 downto 0);  -- '1': Forced DL Off, '0': No Force
DL_OFF_BBCTRL_OUT       <= dl_off_bbctrl(7 downto 0)    ; --        : out  std_logic_vector(                 7 downto 0);  -- '1': Forced DL Off, '0': No Force
DL_OFF_DSP_OUT          <= dl_off_dsp(7 downto 0)       ; --        : out  std_logic_vector(                 7 downto 0);  -- '1': Forced DL Off, '0': No Force
DL_OFF_DCIF_OUT         <= dl_off_dcif(7 downto 0)      ; --        : out  std_logic_vector(                 7 downto 0)   -- '1': Forced DL Off, '0': No Force

-----------------------------------------------------------------------------------------------
-- STROBE Signal Generation for Register Write between different Clock domain
-----------------------------------------------------------------------------------------------
    RDEN_DLY_GEN_100: process(RST_CPU, CLK_CPU)
    begin
        if (RST_CPU = '1') then
            rden_d1_100             <= '0';
            rden_strobe_100         <= '0';
        elsif (CLK_CPU'event and CLK_CPU = '1') then
            rden_d1_100             <= RDEN_CPU_IN;
            rden_strobe_100         <= rden_d1_100;
        end if;
    end process;

    RDEN_DLY_GEN_122p88 : process(i_sysclk_x4_rst, CLK_SYSX4)
    begin
        if (i_sysclk_x4_rst = '1') then
            RDEN_D1_SYSX4           <= '0';
            RDEN_STRB_SYSX4         <= '0';
        elsif (CLK_SYSX4'event and CLK_SYSX4 = '1') then
            RDEN_D1_SYSX4           <= RDEN_CPU_IN;
            RDEN_STRB_SYSX4         <= RDEN_D1_SYSX4;
        end if;
    end process;

    RDEN_DLY_GEN_245p76 : process(i_sysclk_x8_rst, CLK_SYSX8)
    begin
        if (i_sysclk_x8_rst = '1') then
            RDEN_D1_SYSX8           <= '0';
            RDEN_STRB_SYSX8         <= '0';
        elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            RDEN_D1_SYSX8           <= RDEN_CPU_IN;
            RDEN_STRB_SYSX8         <= RDEN_D1_SYSX8;
        end if;
    end process;

    RDEN_DLY_GEN_307p2 : process(i_sysclk_x10_rst, CLK_SYSX10)
    begin
        if (i_sysclk_x10_rst = '1') then
            RDEN_D1_SYSX10          <= '0';
            RDEN_STRB_SYSX10        <= '0';
        elsif (CLK_SYSX10'event and CLK_SYSX10 = '1') then
            RDEN_D1_SYSX10          <= RDEN_CPU_IN;
            RDEN_STRB_SYSX10        <= RDEN_D1_SYSX10;
        end if;
    end process;

    RDEN_DLY_GEN_200 : process(i_miscclk_x3, CLK_MISC3)
    begin
        if (i_miscclk_x3 = '1') then
            RDEN_D1_MISC3           <= '0';
            RDEN_STRB_MISC3         <= '0';
        elsif (CLK_MISC3'event and CLK_MISC3 = '1') then
            RDEN_D1_MISC3           <= RDEN_CPU_IN;
            RDEN_STRB_MISC3         <= RDEN_D1_MISC3 ;
        end if;
    end process;

    RDEN_LATCH_GEN0: process(RST_CPU, CLK_CPU)
    begin
        if (RST_CPU = '1') then
            rden_pls_A2             <= '0';
            rden_pls_A6             <= '0';
            rden_pls_B0             <= '0';
            rden_pls_B4             <= '0';
        elsif (CLK_CPU'event and CLK_CPU = '1') then
            if (RDEN_DLY(1) = '1' and RDEN_DLY(2) = '0') then
                case ADDR_CPU_IN(15 downto 8) is
                    when x"A2"   =>
                        rden_pls_A2 <= '1'; rden_pls_A6 <= '0'; rden_pls_B0 <= '0'; rden_pls_B4 <= '0';
                    when x"A6"   =>
                        rden_pls_A2 <= '0'; rden_pls_A6 <= '1'; rden_pls_B0 <= '0'; rden_pls_B4 <= '0';
                    when x"B0"   =>
                        rden_pls_A2 <= '0'; rden_pls_A6 <= '0'; rden_pls_B0 <= '1'; rden_pls_B4 <= '0';
                    when x"B4"   =>
                        rden_pls_A2 <= '0'; rden_pls_A6 <= '0'; rden_pls_B0 <= '0'; rden_pls_B4 <= '1';
                    when others  =>
                        rden_pls_A2 <= '0'; rden_pls_A6 <= '0'; rden_pls_B0 <= '0'; rden_pls_B4 <= '0';
                end case;
            else
                rden_pls_A2         <= '0';
                rden_pls_A6         <= '0';
                rden_pls_B0         <= '0';
                rden_pls_B4         <= '0';
           end if;
        end if;
    end process;

----------------------------------------------------------------------------------------------
-- Register Read  -- 100 MHz
----------------------------------------------------------------------------------------------
REG32_LATCH_0xA221 : REG32_LATCH generic map(x"00001111", x"21") port map(RST_CPU, CLK_CPU, rden_pls_A2, ADDRL8B, npi_wr_ept_sts_w , npi_wr_ept_sts_s , npi_wr_ept_sts_f );
REG32_LATCH_0xA222 : REG32_LATCH generic map(x"00001111", x"22") port map(RST_CPU, CLK_CPU, rden_pls_A2, ADDRL8B, npi_wr_ful_sts_w , npi_wr_ful_sts_s , npi_wr_ful_sts_f );
REG32_LATCH_0xA223 : REG32_LATCH generic map(x"00001111", x"23") port map(RST_CPU, CLK_CPU, rden_pls_A2, ADDRL8B, npi_rd_ept_sts_w , npi_rd_ept_sts_s , npi_rd_ept_sts_f );
REG32_LATCH_0xA224 : REG32_LATCH generic map(x"00001111", x"24") port map(RST_CPU, CLK_CPU, rden_pls_A2, ADDRL8B, npi_rd_ful_sts_w , npi_rd_ful_sts_s , npi_rd_ful_sts_f );

REG32_LATCH_0xB01E : REG32_LATCH generic map(x"FFFFFFFF", x"1E") port map(RST_CPU, CLK_CPU, rden_pls_B0, ADDRL8B, docomo_uda_w     , docomo_uda_s     , docomo_uda_f     );
REG32_LATCH_0xB020 : REG32_LATCH generic map(x"00001111", x"20") port map(RST_CPU, CLK_CPU, rden_pls_B0, ADDRL8B, eth_phy_uda_w    , eth_phy_uda_s    , eth_phy_uda_f    );
REG32_LATCH_0xB022 : REG32_LATCH generic map(x"00000001", x"22") port map(RST_CPU, CLK_CPU, rden_pls_B0, ADDRL8B, clk_pll_los_w    , clk_pll_los_s    , clk_pll_los_f    );
REG32_LATCH_0xB024 : REG32_LATCH generic map(x"00000001", x"24") port map(RST_CPU, CLK_CPU, rden_pls_B0, ADDRL8B, clk_pll_ld_w     , clk_pll_ld_s     , clk_pll_ld_f     );
REG32_LATCH_0xB026 : REG32_LATCH generic map(x"00000001", x"26") port map(RST_CPU, CLK_CPU, rden_pls_B0, ADDRL8B, clk_pll_ld_rsvd_w, clk_pll_ld_rsvd_s, clk_pll_ld_rsvd_f);



REG32_LATCH_0xB0F4 : REG32_LATCH generic map(x"00000101", x"F4") port map(RST_CPU, CLK_CPU, rden_pls_B0, ADDRL8B, ext_fpga_pwr_sts_w , ext_fpga_pwr_sts_s , ext_fpga_pwr_sts_f  );
REG32_LATCH_0xB414 : REG32_LATCH generic map(x"1007FFFF", x"14") port map(RST_CPU, CLK_CPU, rden_pls_B4, ADDRL8B, rfic_intr_gpio_w(0), rfic_intr_gpio_s(0), rfic_intr_gpio_f(0));
--REG32_LATCH_0xB41A : REG32_LATCH generic map(x"1007FFFF", x"1A") port map(RST_CPU, CLK_CPU, rden_pls_B4, ADDRL8B, rfic_intr_gpio_w(1), rfic_intr_gpio_s(1), rfic_intr_gpio_f(1));
--REG32_LATCH_0xB420 : REG32_LATCH generic map(x"1007FFFF", x"20") port map(RST_CPU, CLK_CPU, rden_pls_B4, ADDRL8B,  rfic_intr_gpio_w(2) , rfic_intr_gpio_s(2), rfic_intr_gpio_f(2));
--REG32_LATCH_0xB426 : REG32_LATCH generic map(x"1007FFFF", x"26") port map(RST_CPU, CLK_CPU, rden_pls_B4, ADDRL8B,  rfic_intr_gpio_w(3) , rfic_intr_gpio_s(3), rfic_intr_gpio_f(3));

REG32_LATCH_0xB0DA : REG32_LATCH generic map(x"00000001", x"DA") port map(RST_CPU, CLK_CPU, rden_pls_B0, ADDRL8B, i_axi_timeout_w, i_axi_timeout_s,i_axi_timeout_f);

----------------------------------------------------------------------------------------------
-- Register Read  -- 122.88 MHz
----------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------
-- Register Read  -- 245.76 MHz
----------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------
-- Register Read  -- 307.2 MHz
----------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------
-- Register Read  -- 200   MHz
----------------------------------------------------------------------------------------------
REG32_LATCH_0xA630 : REG32_LATCH generic map(x"FFFFFFFF", x"30") port map(RST_CPU, CLK_CPU, rden_pls_A6, ADDRL8B, w_log_cpriphy     , s_log_cpriphy     , f_log_cpriphy     );
REG32_LATCH_0xA631 : REG32_LATCH generic map(x"FFFFFFFF", x"31") port map(RST_CPU, CLK_CPU, rden_pls_A6, ADDRL8B, w_log_sbifphy     , s_log_sbifphy     , f_log_sbifphy     );
REG32_LATCH_0xA632 : REG32_LATCH generic map(x"FFFFFFFF", x"32") port map(RST_CPU, CLK_CPU, rden_pls_A6, ADDRL8B, w_log_cpri        , s_log_cpri        , f_log_cpri        );
REG32_LATCH_0xA633 : REG32_LATCH generic map(x"FFFFFFFF", x"33") port map(RST_CPU, CLK_CPU, rden_pls_A6, ADDRL8B, w_log_sbif        , s_log_sbif        , f_log_sbif        );
REG32_LATCH_0xA634 : REG32_LATCH generic map(x"FFFFFFFF", x"34") port map(RST_CPU, CLK_CPU, rden_pls_A6, ADDRL8B, w_log_bbctrl      , s_log_bbctrl      , f_log_bbctrl      );
REG32_LATCH_0xA635 : REG32_LATCH generic map(x"FFFFFFFF", x"35") port map(RST_CPU, CLK_CPU, rden_pls_A6, ADDRL8B, w_log_dsp         , s_log_dsp         , f_log_dsp         );
REG32_LATCH_0xA636 : REG32_LATCH generic map(x"FFFFFFFF", x"36") port map(RST_CPU, CLK_CPU, rden_pls_A6, ADDRL8B, w_log_dcif_dl     , s_log_dcif_dl     , f_log_dcif_dl     );
REG32_LATCH_0xA637 : REG32_LATCH generic map(x"FFFFFFFF", x"37") port map(RST_CPU, CLK_CPU, rden_pls_A6, ADDRL8B, w_log_dcif_ul     , s_log_dcif_ul     , f_log_dcif_ul     );
REG32_LATCH_0xA638 : REG32_LATCH generic map(x"FFFFFFFF", x"38") port map(RST_CPU, CLK_CPU, rden_pls_A6, ADDRL8B, w_log_dcif_fb     , s_log_dcif_fb     , f_log_dcif_fb     );
REG32_LATCH_0xA639 : REG32_LATCH generic map(x"FFFFFFFF", x"39") port map(RST_CPU, CLK_CPU, rden_pls_A6, ADDRL8B, w_log_clk         , s_log_clk         , f_log_clk         );
REG32_LATCH_0xA63A : REG32_LATCH generic map(x"FFFFFFFF", x"3A") port map(RST_CPU, CLK_CPU, rden_pls_A6, ADDRL8B, w_log_rfic        , s_log_rfic        , f_log_rfic        );
REG32_LATCH_0xA63B : REG32_LATCH generic map(x"FFFFFFFF", x"3B") port map(RST_CPU, CLK_CPU, rden_pls_A6, ADDRL8B, w_log_voltage     , s_log_voltage     , f_log_voltage     );
REG32_LATCH_0xA63C : REG32_LATCH generic map(x"FFFFFFFF", x"3C") port map(RST_CPU, CLK_CPU, rden_pls_A6, ADDRL8B, w_log_dac_off     , s_log_dac_off     , f_log_dac_off     );
REG32_LATCH_0xA63D : REG32_LATCH generic map(x"FFFFFFFF", x"3D") port map(RST_CPU, CLK_CPU, rden_pls_A6, ADDRL8B, w_log_wdt         , s_log_wdt         , f_log_wdt         );

w_log_cpriphy   <= x"000000" & LOG_CPRIPHY_IN           ;
w_log_sbifphy   <= x"000000" & LOG_SBIFPHY_IN           ;
w_log_cpri      <= x"000000" & LOG_CPRI_IN              ;
w_log_sbif      <= x"000000" & LOG_SBIF_IN              ;
w_log_bbctrl    <= x"000000" & LOG_BBCTRL_IN            ;
w_log_dsp       <= x"000000" & LOG_DSP_IN               ;
w_log_dcif_dl   <= x"000000" & LOG_DCIF_DL_IN           ;
w_log_dcif_ul   <= x"000000" & LOG_DCIF_UL_IN           ;
w_log_dcif_fb   <= x"000000" & LOG_DCIF_FB_IN           ;
w_log_clk       <= x"000000" & "000000" & LOG_CLK_IN    ;
w_log_rfic      <= x"000000" & x"0"     & LOG_RFIC_IN   ;
w_log_voltage   <= LOG_VOLTAGE_IN                       ;
w_log_dac_off   <= x"000000" & LOG_DAC_OFF_IN           ;
w_log_wdt       <= x"0000000"& "00" & LOG_WDT_IN        ;


-- Read Data Multiplexing
RDATA_CPU_OUT <=  RDATA_100         when ADDR_CPU_IN(15 downto  8) = x"A0" else
                  RDATA_100         when ADDR_CPU_IN(15 downto  8) = x"A2" else
                  RDATA_100         when ADDR_CPU_IN(15 downto  8) = x"A6" else
                  RDATA_100         when ADDR_CPU_IN(15 downto  8) = x"AC" else
                  sadump_mem_rdata  when ADDR_CPU_IN(15 downto 13) = "110" else
                  RDATA_SYSCLK_X8   when ADDR_CPU_IN(15 downto 8)  = x"A4" else
                  RDATA_SYSCLK_X8   when ADDR_CPU_IN(15 downto 8)  = x"AA" else
                  RDATA_SYSCLK_X4   when ADDR_CPU_IN(15 downto 8)  = x"A8" else
                  RDATA_SYSCLK_X8   when ADDR_CPU_IN(15 downto 8)  = x"AE" else
                  RDATA_SYSCLK_X8   when ADDR_CPU_IN(15 downto 8)  = x"B6" else
                  --RDATA_100 when ADDR_CPU_IN(15 downto 8) = x"??" else
                  --RDATA_SYSCLK_X4 when ADDR_CPU_IN(15 downto 8) = x"??" else
                  RDATA_100;


-- 100 MHz Domain --
RDATA_MUX_PROC0: process(RST_CPU, CLK_CPU)
begin
    if (RST_CPU = '1') then
        RDATA_100                   <= (others => '0');
        i_ook_a_dir_lat_clr         <= '0';
        i_ook_c_dir_lat_clr         <= '0';
    elsif (CLK_CPU'event and CLK_CPU = '1') then
        if (rden_strobe_100 = '1') then
            case ADDR_CPU_IN(15 downto 8) is
                when x"A0"  =>
                    case ADDRL8B is
                        when x"00"  => RDATA_100 <= MISC_MODULE_INFO_IN;
                        when x"01"  => RDATA_100 <= MISC_STRUCT_INFO_IN;
                        when x"02"  => RDATA_100 <= MISC_MODULE_DATE_IN;
                        when x"0D"  => RDATA_100 <= i_tp_sel;
                        when x"0E"  => RDATA_100 <= rst_ctrl_test_reg_100;
                        when others => RDATA_100 <= (others => '0');
                    end case;
                when x"A2"  =>
                    case ADDRL8B is
                        when x"00"  => RDATA_100 <= SADUMP_MODULE_INFO_IN;
                        when x"01"  => RDATA_100 <= SADUMP_STRUCT_INFO_IN;
                        when x"02"  => RDATA_100 <= SADUMP_MODULE_DATE_IN;

                        when x"10"  => RDATA_100 <= sadump_start_point_sel_reg_100;
                        when x"11"  => RDATA_100 <= sadump_module_set_reg_100;
                        when x"12"  => RDATA_100 <= x"0000" & "0000000" & DUMP_DONE_IN & "0000000" & sadump_cap_status_reg_100(0);
                        when x"13"  => RDATA_100 <= sadump_txsa_set_reg_100;
                        when x"14"  => RDATA_100 <= sadump_txsa_clkdlyvalue_reg_100;
                        when x"16"  => RDATA_100 <= sadump_fixed_ptn_set_reg_100;
                        when x"17"  => RDATA_100 <= sadump_fixed_ptn_status_reg_100;
                        when x"18"  => RDATA_100 <= sadump_dma_set_reg_100;
                        when x"19"  => RDATA_100 <= x"0000" & "000" & DMA_WR_EMPTY_IN & "000" & DMA_WR_FULL_IN & "000" & DMA_RD_EMPTY_IN & "000" & DMA_RD_FULL_IN;
                        when x"1A"  => RDATA_100 <= sadump_dma_start_point_set_reg_100;
                        when x"20"  => RDATA_100 <= sadump_dump_operating_mode_reg_100;

                        when x"21"  => RDATA_100 <= npi_wr_ept_sts_f;
                        when x"22"  => RDATA_100 <= npi_wr_ful_sts_f;
                        when x"23"  => RDATA_100 <= npi_rd_ept_sts_f;
                        when x"24"  => RDATA_100 <= npi_rd_ful_sts_f;

                        when x"25"  => RDATA_100 <= npi_wr_ept_sts_s;
                        when x"26"  => RDATA_100 <= npi_wr_ful_sts_s;
                        when x"27"  => RDATA_100 <= npi_rd_ept_sts_s;
                        when x"28"  => RDATA_100 <= npi_rd_ful_sts_s;


                        when others => RDATA_100 <= (others => '0');
                    end case;
                when x"A6"  =>
                    case ADDRL8B is
                          when x"00"  => RDATA_100 <= SIG_SUS_MAIN_TYPE_IN & SIG_SUS_SUB_TYPE_IN & x"00" & SIG_SUS_VER_IN;
                          when x"01"  => RDATA_100 <= SIG_SUS_STRUCT_IN;
                          when x"02"  => RDATA_100 <= SIG_SUS_DATE_IN;

                          when x"10"  => RDATA_100 <= sig_sus_amp_protect_on  ;
                          when x"11"  => RDATA_100 <= alm_deb_cnt             ;
                          when x"12"  => RDATA_100 <= rf_sw_off_release       ;

                          when x"20"  => RDATA_100 <= sig_sus_cpri_link_ant(0);
                          when x"21"  => RDATA_100 <= sig_sus_cpri_link_ant(1);
                          when x"22"  => RDATA_100 <= sig_sus_cpri_link_ant(2);
                          when x"23"  => RDATA_100 <= sig_sus_cpri_link_ant(3);
                          when x"24"  => RDATA_100 <= sig_sus_cpri_link_ant(4);
                          when x"25"  => RDATA_100 <= sig_sus_cpri_link_ant(5);
                          when x"26"  => RDATA_100 <= sig_sus_cpri_link_ant(6);
                          when x"27"  => RDATA_100 <= sig_sus_cpri_link_ant(7);

                          when x"30"  => RDATA_100 <= f_log_cpriphy   ;
                          when x"31"  => RDATA_100 <= f_log_sbifphy   ;
                          when x"32"  => RDATA_100 <= f_log_cpri      ;
                          when x"33"  => RDATA_100 <= f_log_sbif      ;
                          when x"34"  => RDATA_100 <= f_log_bbctrl    ;
                          when x"35"  => RDATA_100 <= f_log_dsp       ;
                          when x"36"  => RDATA_100 <= f_log_dcif_dl   ;
                          when x"37"  => RDATA_100 <= f_log_dcif_ul   ;
                          when x"38"  => RDATA_100 <= f_log_dcif_fb   ;
                          when x"39"  => RDATA_100 <= f_log_clk       ;
                          when x"3A"  => RDATA_100 <= f_log_rfic      ;
                          when x"3B"  => RDATA_100 <= f_log_voltage   ;
                          when x"3C"  => RDATA_100 <= f_log_dac_off   ;
                          when x"3D"  => RDATA_100 <= f_log_wdt       ;

                          when x"40"  => RDATA_100 <= s_log_cpriphy   ;
                          when x"41"  => RDATA_100 <= s_log_sbifphy   ;
                          when x"42"  => RDATA_100 <= s_log_cpri      ;
                          when x"43"  => RDATA_100 <= s_log_sbif      ;
                          when x"44"  => RDATA_100 <= s_log_bbctrl    ;
                          when x"45"  => RDATA_100 <= s_log_dsp       ;
                          when x"46"  => RDATA_100 <= s_log_dcif_dl   ;
                          when x"47"  => RDATA_100 <= s_log_dcif_ul   ;
                          when x"48"  => RDATA_100 <= s_log_dcif_fb   ;
                          when x"49"  => RDATA_100 <= s_log_clk       ;
                          when x"4A"  => RDATA_100 <= s_log_rfic      ;
                          when x"4B"  => RDATA_100 <= s_log_voltage   ;
                          when x"4C"  => RDATA_100 <= s_log_dac_off   ;
                          when x"4D"  => RDATA_100 <= s_log_wdt       ;

                          when x"50"  => RDATA_100 <= alm_en_cpriphy  ;
                          when x"51"  => RDATA_100 <= alm_en_sbifphy  ;
                          when x"52"  => RDATA_100 <= alm_en_cpri     ;
                          when x"53"  => RDATA_100 <= alm_en_sbif     ;
                          when x"54"  => RDATA_100 <= alm_en_bbctrl   ;
                          when x"55"  => RDATA_100 <= alm_en_dsp      ;
                          when x"56"  => RDATA_100 <= alm_en_dcif_dl  ;
                          when x"57"  => RDATA_100 <= alm_en_dcif_ul  ;
                          when x"58"  => RDATA_100 <= alm_en_dcif_fb  ;
                          when x"59"  => RDATA_100 <= alm_en_volt     ;
                          when x"5A"  => RDATA_100 <= alm_en_pg       ;
                          when x"5B"  => RDATA_100 <= alm_en_others   ;

                          when x"60"  => RDATA_100 <= dl_off_cpriphy  ;
                          when x"61"  => RDATA_100 <= dl_off_sbifphy  ;
                          when x"62"  => RDATA_100 <= dl_off_sbif     ;
                          when x"63"  => RDATA_100 <= dl_off_bbctrl   ;
                          when x"64"  => RDATA_100 <= dl_off_dsp      ;
                          when x"65"  => RDATA_100 <= dl_off_dcif     ;

                          when x"70"  => RDATA_100 <= alm_off_volt    ;
                          when x"71"  => RDATA_100 <= docomo_uda_tx   ;
                          
                          when x"72"  => RDATA_100 <= supper_sleep_r  ;

                          when others => RDATA_100 <= (others => '0');
                    end case;
                when x"AC" =>
                    case ADDRL8B is
                        when x"10"  => RDATA_100 <= x"0000" & INTADC_TEMP;
                        when x"11"  => RDATA_100 <= x"0000" & INTADC_VCCINT;
                        --when x"12"  => RDATA_100 <= x"0000" & INTADC_VCCPINT;
                        when x"19"  => RDATA_100 <= x"0000" & INTADC_VCCPSINTLP;
                        when x"1A"  => RDATA_100 <= x"0000" & INTADC_VCCPSINTFP;
                        when x"1B"  => RDATA_100 <= x"0000" & INTADC_AUX(0);
                        when x"1C"  => RDATA_100 <= x"0000" & INTADC_AUX(1);
                        when x"1D"  => RDATA_100 <= x"0000" & INTADC_AUX(2);
                        when x"1E"  => RDATA_100 <= x"0000" & INTADC_AUX(3);
                        when x"1F"  => RDATA_100 <= x"0000" & INTADC_AUX(4);
                        when x"20"  => RDATA_100 <= x"0000" & INTADC_AUX(5);
                        when x"21"  => RDATA_100 <= x"0000" & INTADC_AUX(6);
                        when x"22"  => RDATA_100 <= x"0000" & INTADC_AUX(7);
                        when x"23"  => RDATA_100 <= x"0000" & INTADC_AUX(8);
                        when x"24"  => RDATA_100 <= x"0000" & INTADC_AUX(9);
                        when x"25"  => RDATA_100 <= x"0000" & INTADC_AUX(10);
                        when x"26"  => RDATA_100 <= x"0000" & INTADC_AUX(11);
                        when x"27"  => RDATA_100 <= x"0000" & INTADC_AUX(12);
                        when x"28"  => RDATA_100 <= x"0000" & INTADC_AUX(13);
                        when x"29"  => RDATA_100 <= x"0000" & INTADC_AUX(14);
                        when x"2A"  => RDATA_100 <= x"0000" & INTADC_AUX(15);
                        when others => RDATA_100 <= (others => '0');
                    end case;
                when x"B0" =>
                    case ADDRL8B is
                        when x"10"  => RDATA_100 <= rst_ext_phy_reg_100;
                        when x"11"  => RDATA_100 <= rst_ext_pll_reg_100;
                        when x"12"  => RDATA_100 <= ext_dlmk_sync_reg_100;
                        when x"13"  => RDATA_100 <= ext_enb_ctrl_reg_100;
                        when x"14"  => RDATA_100 <= ext_amp_amc_rst_reg_100;

                        when x"1E"  => RDATA_100 <= docomo_uda_s;
                        when x"1F"  => RDATA_100 <= docomo_uda_f;
                        when x"20"  => RDATA_100 <= eth_phy_uda_f;
                        when x"21"  => RDATA_100 <= eth_phy_uda_s;
                        when x"22"  => RDATA_100 <= clk_pll_los_f;
                        when x"23"  => RDATA_100 <= clk_pll_los_s;
                        when x"24"  => RDATA_100 <= clk_pll_ld_f;
                        when x"25"  => RDATA_100 <= clk_pll_ld_s;
                        when x"26"  => RDATA_100 <= clk_pll_ld_rsvd_f;
                        when x"27"  => RDATA_100 <= clk_pll_ld_rsvd_s;
                        when x"30"  => RDATA_100 <= ext_amp_48v_onoff_reg_100;

                        when x"D0"  => RDATA_100 <= ext_tx_sw_ctrl_reg_100;
                        when x"D1"  => RDATA_100 <= ext_rf_enb_ctrl_reg_100;
                        when x"DA"  => RDATA_100 <= i_axi_timeout_f;
                        when x"DB"  => RDATA_100 <= i_axi_timeout_s;

                        when x"E0"  => RDATA_100 <= ext_rxatt_enb_reg_100;
                        when x"E1"  => RDATA_100 <= ext_rxatt_word_a_reg_100;
                        when x"E2"  => RDATA_100 <= ext_rxatt_word_b_reg_100;
                        when x"E3"  => RDATA_100 <= ext_rxatt_word_c_reg_100;
                        when x"E4"  => RDATA_100 <= ext_rxatt_word_d_reg_100;

                        when x"F0"  => RDATA_100 <= ext_tdd_dir_reg_100;
                        when x"F1"  => RDATA_100 <= ext_clk_dir_reg_100;
                        when x"F2"  => RDATA_100 <= ext_fpga_rst_reg_100;
                        when x"F3"  => RDATA_100 <= ext_isppac_ctrl_reg_100;
                        when x"F4"  => RDATA_100 <= ext_fpga_pwr_sts_f;
                        when x"F5"  => RDATA_100 <= ext_fpga_pwr_sts_s;
                        when x"F6"  => RDATA_100 <= ext_amp_enb_ctrl_reg_100;
                        when x"F7"  => RDATA_100 <= ext_analog_dl_dly_reg_100;
                        when x"F8"  => RDATA_100 <= ext_analog_ul_dly_reg_100;
                        when x"F9"  => RDATA_100 <= ext_analog_fb_dly_reg_100;
                        when x"FA"  => RDATA_100 <= ext_trx_sw_ctrl_reg_100;
                        when x"FB"  => RDATA_100 <= ext_trx_tql_9092_on_reg_100;
                        when x"FC"  => RDATA_100 <= ext_func_fail_masking_reg_100;
                        when x"FD"  => RDATA_100 <= ext_bcf_en_dly_reg_100;
                        when others => RDATA_100 <= (others => '0');
                    end case;
                when x"B1" =>
                    case ADDRL8B is
                        when x"00"  => RDATA_100 <= ext_ret_uart_ctrl                       ;
                        when x"01"  => RDATA_100 <= x"0000" & RET_TX_UART_START_CNT_IN      ;
                        when x"02"  => RDATA_100 <= x"0000" & RET_TX_UART_ERR_CNT_IN        ;
                        when x"03"  => RDATA_100 <= x"0000" & RET_RX_UART_START_CNT_IN      ;
                        when x"04"  => RDATA_100 <= x"0000" & RET_RX_UART_ERR_CNT_IN        ;
                        when x"05"  => RDATA_100 <= ext_ret_onoff_ctrl                      ;

                        when x"10"  => RDATA_100 <= ext_ook_a_uart_ctrl                     ;
                        when x"11"  => RDATA_100 <= x"0000" & OOK_A_TX_UART_START_CNT_IN    ;
                        when x"12"  => RDATA_100 <= x"0000" & OOK_A_TX_UART_ERR_CNT_IN      ;
                        when x"13"  => RDATA_100 <= x"0000" & OOK_A_RX_UART_START_CNT_IN    ;
                        when x"14"  => RDATA_100 <= x"0000" & OOK_A_RX_UART_ERR_CNT_IN      ;
                        when x"15"  => RDATA_100 <= ext_bias_t_a_ctrl_r                     ;
                                       i_ook_a_dir_lat_clr <= '1';


                        when x"20"  => RDATA_100 <= ext_ook_c_uart_ctrl                     ;
                        when x"21"  => RDATA_100 <= x"0000" & OOK_C_TX_UART_START_CNT_IN    ;
                        when x"22"  => RDATA_100 <= x"0000" & OOK_C_TX_UART_ERR_CNT_IN      ;
                        when x"23"  => RDATA_100 <= x"0000" & OOK_C_RX_UART_START_CNT_IN    ;
                        when x"24"  => RDATA_100 <= x"0000" & OOK_C_RX_UART_ERR_CNT_IN      ;
                        when x"25"  => RDATA_100 <= ext_bias_t_c_ctrl_r                     ;
                                       i_ook_c_dir_lat_clr <= '1';
                        when x"26"  => RDATA_100 <= pa_drv_onoff_r                     ;
                        when others => RDATA_100 <= (others => '0');
                    end case;
                when x"B4" =>
                    case ADDRL8B is
                        when x"10"  => RDATA_100 <= rfic_rst_ctrl_reg_100;
                        when x"11"  => RDATA_100 <= rfic_pwr_ctrl_reg_100;
                        when x"12"  => RDATA_100 <= rfic_tx_enb_ctrl_reg_100;
                        when x"13"  => RDATA_100 <= rfic_rx_enb_ctrl_reg_100;

                        when x"14"  => RDATA_100 <= rfic_intr_gpio_f(0);
                        when x"15"  => RDATA_100 <= rfic_intr_gpio_s(0);
                        when x"16"  => RDATA_100 <= rfic_intr_gpio_set0_reg_100;
                        --when x"1A"  => RDATA_100 <= rfic_intr_gpio_f(1);
                        --when x"1B"  => RDATA_100 <= rfic_intr_gpio_s(1);
                        --when x"1C"  => RDATA_100 <= rfic_intr_gpio_set1_reg_100;
                        --when x"20"  => RDATA_100 <= rfic_intr_gpio_f(2);
                        --when x"21"  => RDATA_100 <= rfic_intr_gpio_s(2);
                        --when x"22"  => RDATA_100 <= rfic_intr_gpio_set2_reg_100;
                        --when x"26"  => RDATA_100 <= rfic_intr_gpio_f(3);
                        --when x"27"  => RDATA_100 <= rfic_intr_gpio_s(3);
                        --when x"28"  => RDATA_100 <= rfic_intr_gpio_set3_reg_100;
                        when others => RDATA_100 <= (others => '0');
                    end case;

                when x"B5" =>
                    case ADDRL8B is
                        when x"37"  => RDATA_100 <= board_id_reg_100;
                        when others => RDATA_100 <= (others => '0');
                    end case;
                    
                when others => RDATA_100 <= (others => '0');
            end case;
        else
            RDATA_100 <= (others => '0');
            i_ook_a_dir_lat_clr <= '0';
            i_ook_c_dir_lat_clr <= '0';
        end if;
    end if;
end process;


-- 122.88 MHz Domain --
RDATA_MUX_PROC1: process(i_sysclk_x4_rst, CLK_SYSX4)
begin
    if (i_sysclk_x4_rst = '1') then
        RDATA_SYSCLK_X4 <= (others => '0');
    elsif (CLK_SYSX4'event and CLK_SYSX4 = '1') then
        if (RDEN_STRB_SYSX4 = '1') then

            case ADDR_CPU_IN(15 downto 8) is
                when x"A8"  =>
                    case ADDRL8B is
                          when x"04"  => RDATA_SYSCLK_X4 <= sw_manual_set_r;
                          when x"05"  => RDATA_SYSCLK_X4 <= sw_manual_value_r;

--                          when x"06"  => RDATA_SYSCLK_X4 <= manual_orx_sw_reg_r;

--                          when x"07"  => RDATA_SYSCLK_X4 <= manual_rev_sw_0_reg_r;
--                          when x"08"  => RDATA_SYSCLK_X4 <= manual_fb_rev_sw_0_reg_r;
                          when x"09"  => RDATA_SYSCLK_X4 <= manual_rfic_orx_trigger_reg_r;
                          when x"0A"  => RDATA_SYSCLK_X4 <= manual_rfic_orx_mode_reg_r;
--                          when x"0B"  => RDATA_SYSCLK_X4 <= manual_orx_rev_sw_invt_reg_r;
                          when x"0C"  => RDATA_SYSCLK_X4 <= manual_fb_sw_ctrl_value_reg_r;

                          when x"10"  => RDATA_SYSCLK_X4 <= fb_sw_mode_r(0);
                          --when x"11"  => RDATA_SYSCLK_X4 <= fb_sw_mode_r(1);
                          --when x"12"  => RDATA_SYSCLK_X4 <= fb_sw_mode_r(2);
                          --when x"13"  => RDATA_SYSCLK_X4 <= fb_sw_mode_r(3);
                          when x"14"  => RDATA_SYSCLK_X4 <= resync_manual_r;
                          when x"15"  => RDATA_SYSCLK_X4 <= resync_enable_r;
                          when x"16"  => RDATA_SYSCLK_X4 <= resync_status_r;

--                          when x"20"  => RDATA_SYSCLK_X4 <= bfn_cnt_reg_r;
--                          when x"21"  => RDATA_SYSCLK_X4 <= rfic_cal_mode_chg_ri_cnt_reg;
--                          when x"22"  => RDATA_SYSCLK_X4 <= rfic_cal_mode_chg_fa_cnt_reg;
                          when others => RDATA_SYSCLK_X4 <= (others => '0');
                    end case;
                when others => RDATA_SYSCLK_X4 <= (others => '0');
            end case;
        else
            RDATA_SYSCLK_X4 <= (others => '0');
        end if;
    end if;
end process;

-- 245.76 MHz Domain --
RDATA_MUX_PROC2: process(i_sysclk_x8_rst, CLK_SYSX8)
begin
    if (i_sysclk_x8_rst = '1') then
        RDATA_SYSCLK_X8 <= (others => '0');
    elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
        if (RDEN_STRB_SYSX8 = '1') then
            case ADDR_CPU_IN(15 downto 8) is
                when x"A4"  =>
                    case ADDRL8B is
                          when x"10"  => RDATA_SYSCLK_X8 <= dpa_en_r;
                          when x"11"  => RDATA_SYSCLK_X8 <= dpa_trx_data_dly_time_r;
                          when x"12"  => RDATA_SYSCLK_X8 <= dpa_rise_resp_time_r;
                          when x"13"  => RDATA_SYSCLK_X8 <= dpa_fall_resp_time_r;
                          when x"14"  => RDATA_SYSCLK_X8 <= dpa_off_mon_time_r;
                          when others => RDATA_SYSCLK_X8 <= (others => '0');
                    end case;
                when x"AA"  =>
                    case ADDRL8B is
                          when x"10"  => RDATA_SYSCLK_X8 <= equip_offset_r;
                          when x"11"  => RDATA_SYSCLK_X8 <= equip_onoff_r;

                          when x"15"  => RDATA_SYSCLK_X8 <= trxsw_tx_offset_r;
                          when x"16"  => RDATA_SYSCLK_X8 <= trxsw_tx_onoff_r;
                          when x"17"  => RDATA_SYSCLK_X8 <= trxsw_tx_offset_r;
                          when x"18"  => RDATA_SYSCLK_X8 <= trxsw_tx_onoff_r;

                          when x"20"  => RDATA_SYSCLK_X8 <= rfic_txa_sw_offset_r(0);
                          when x"21"  => RDATA_SYSCLK_X8 <= rfic_txa_sw_onoff_r(0);
                          --when x"22"  => RDATA_SYSCLK_X8 <= rfic_txa_sw_offset_r(1);
                          --when x"23"  => RDATA_SYSCLK_X8 <= rfic_txa_sw_onoff_r(1);
                          --when x"24"  => RDATA_SYSCLK_X8 <= rfic_txa_sw_offset_r(2);
                          --when x"25"  => RDATA_SYSCLK_X8 <= rfic_txa_sw_onoff_r(2);
                          --when x"26"  => RDATA_SYSCLK_X8 <= rfic_txa_sw_offset_r(3);
                          --when x"27"  => RDATA_SYSCLK_X8 <= rfic_txa_sw_onoff_r(3);

                          when x"30"  => RDATA_SYSCLK_X8 <= rfic_txb_sw_offset_r(0);
                          when x"31"  => RDATA_SYSCLK_X8 <= rfic_txb_sw_onoff_r(0);
                          --when x"32"  => RDATA_SYSCLK_X8 <= rfic_txb_sw_offset_r(1);
                          --when x"33"  => RDATA_SYSCLK_X8 <= rfic_txb_sw_onoff_r(1);
                          --when x"34"  => RDATA_SYSCLK_X8 <= rfic_txb_sw_offset_r(2);
                          --when x"35"  => RDATA_SYSCLK_X8 <= rfic_txb_sw_onoff_r(2);
                          --when x"36"  => RDATA_SYSCLK_X8 <= rfic_txb_sw_offset_r(3);
                          --when x"37"  => RDATA_SYSCLK_X8 <= rfic_txb_sw_onoff_r(3);

                          when x"40"  => RDATA_SYSCLK_X8 <= amp_en_offset_r(0);
                          when x"41"  => RDATA_SYSCLK_X8 <= amp_en_onoff_r(0);
                          when x"42"  => RDATA_SYSCLK_X8 <= amp_en_offset_r(1);
                          when x"43"  => RDATA_SYSCLK_X8 <= amp_en_onoff_r(1);
                          --when x"44"  => RDATA_SYSCLK_X8 <= amp_en_offset_r(2);
                          --when x"45"  => RDATA_SYSCLK_X8 <= amp_en_onoff_r(2);
                          --when x"46"  => RDATA_SYSCLK_X8 <= amp_en_offset_r(3);
                          --when x"47"  => RDATA_SYSCLK_X8 <= amp_en_onoff_r(3);
                          --when x"48"  => RDATA_SYSCLK_X8 <= amp_en_offset_r(4);
                          --when x"49"  => RDATA_SYSCLK_X8 <= amp_en_onoff_r(4);
                          --when x"4A"  => RDATA_SYSCLK_X8 <= amp_en_offset_r(5);
                          --when x"4B"  => RDATA_SYSCLK_X8 <= amp_en_onoff_r(5);
                          --when x"4C"  => RDATA_SYSCLK_X8 <= amp_en_offset_r(6);
                          --when x"4D"  => RDATA_SYSCLK_X8 <= amp_en_onoff_r(6);
                          --when x"4E"  => RDATA_SYSCLK_X8 <= amp_en_offset_r(7);
                          --when x"4F"  => RDATA_SYSCLK_X8 <= amp_en_onoff_r(7);

                          when x"60"  => RDATA_SYSCLK_X8 <= rfic_tx_en_offset_r(0)(0);
                          when x"61"  => RDATA_SYSCLK_X8 <= rfic_tx_en_onoff_r(0)(0);
                          when x"62"  => RDATA_SYSCLK_X8 <= rfic_tx_en_offset_r(0)(1);
                          when x"63"  => RDATA_SYSCLK_X8 <= rfic_tx_en_onoff_r(0)(1);
                          --when x"64"  => RDATA_SYSCLK_X8 <= rfic_tx_en_offset_r(1)(0);
                          --when x"65"  => RDATA_SYSCLK_X8 <= rfic_tx_en_onoff_r(1)(0);
                          --when x"66"  => RDATA_SYSCLK_X8 <= rfic_tx_en_offset_r(1)(1);
                          --when x"67"  => RDATA_SYSCLK_X8 <= rfic_tx_en_onoff_r(1)(1);
                          --when x"68"  => RDATA_SYSCLK_X8 <= rfic_tx_en_offset_r(2)(0);
                          --when x"69"  => RDATA_SYSCLK_X8 <= rfic_tx_en_onoff_r(2)(0);
                          --when x"6A"  => RDATA_SYSCLK_X8 <= rfic_tx_en_offset_r(2)(1);
                          --when x"6B"  => RDATA_SYSCLK_X8 <= rfic_tx_en_onoff_r(2)(1);
                          --when x"6C"  => RDATA_SYSCLK_X8 <= rfic_tx_en_offset_r(3)(0);
                          --when x"6D"  => RDATA_SYSCLK_X8 <= rfic_tx_en_onoff_r(3)(0);
                          --when x"6E"  => RDATA_SYSCLK_X8 <= rfic_tx_en_offset_r(3)(1);
                          --when x"6F"  => RDATA_SYSCLK_X8 <= rfic_tx_en_onoff_r(3)(1);

                          when x"80"  => RDATA_SYSCLK_X8 <= rfic_rx_en_offset_r(0)(0);
                          when x"81"  => RDATA_SYSCLK_X8 <= rfic_rx_en_onoff_r(0)(0);
                          when x"82"  => RDATA_SYSCLK_X8 <= rfic_rx_en_offset_r(0)(1);
                          when x"83"  => RDATA_SYSCLK_X8 <= rfic_rx_en_onoff_r(0)(1);
                          --when x"84"  => RDATA_SYSCLK_X8 <= rfic_rx_en_offset_r(1)(0);
                          --when x"85"  => RDATA_SYSCLK_X8 <= rfic_rx_en_onoff_r(1)(0);
                          --when x"86"  => RDATA_SYSCLK_X8 <= rfic_rx_en_offset_r(1)(1);
                          --when x"87"  => RDATA_SYSCLK_X8 <= rfic_rx_en_onoff_r(1)(1);
                          --when x"88"  => RDATA_SYSCLK_X8 <= rfic_rx_en_offset_r(2)(0);
                          --when x"89"  => RDATA_SYSCLK_X8 <= rfic_rx_en_onoff_r(2)(0);
                          --when x"8A"  => RDATA_SYSCLK_X8 <= rfic_rx_en_offset_r(2)(1);
                          --when x"8B"  => RDATA_SYSCLK_X8 <= rfic_rx_en_onoff_r(2)(1);
                          --when x"8C"  => RDATA_SYSCLK_X8 <= rfic_rx_en_offset_r(3)(0);
                          --when x"8D"  => RDATA_SYSCLK_X8 <= rfic_rx_en_onoff_r(3)(0);
                          --when x"8E"  => RDATA_SYSCLK_X8 <= rfic_rx_en_offset_r(3)(1);
                          --when x"8F"  => RDATA_SYSCLK_X8 <= rfic_rx_en_onoff_r(3)(1);

                          when x"A0"  => RDATA_SYSCLK_X8 <= rfic_pre_trig_offset_r(0);
                          when x"A1"  => RDATA_SYSCLK_X8 <= rfic_pre_trig_onoff_r(0);
                          --when x"A2"  => RDATA_SYSCLK_X8 <= rfic_pre_trig_offset_r(1);
                          --when x"A3"  => RDATA_SYSCLK_X8 <= rfic_pre_trig_onoff_r(1);
                          --when x"A4"  => RDATA_SYSCLK_X8 <= rfic_pre_trig_offset_r(2);
                          --when x"A5"  => RDATA_SYSCLK_X8 <= rfic_pre_trig_onoff_r(2);
                          --when x"A6"  => RDATA_SYSCLK_X8 <= rfic_pre_trig_offset_r(3);
                          --when x"A7"  => RDATA_SYSCLK_X8 <= rfic_pre_trig_onoff_r(3);

                          --when x"B0"  => RDATA_SYSCLK_X8 <= tx_cal_sel0_offset_r;
                          --when x"B1"  => RDATA_SYSCLK_X8 <= tx_cal_sel0_onoff_r;
                          --when x"B2"  => RDATA_SYSCLK_X8 <= rx_cal_sel0_offset_r;
                          --when x"B3"  => RDATA_SYSCLK_X8 <= rx_cal_sel0_onoff_r;

                          --when x"C0"  => RDATA_SYSCLK_X8 <= cal_path_sel_offset_r(0);
                          --when x"C1"  => RDATA_SYSCLK_X8 <= cal_path_sel_onoff_r(0);
                          --when x"C2"  => RDATA_SYSCLK_X8 <= cal_path_sel_offset_r(1);
                          --when x"C3"  => RDATA_SYSCLK_X8 <= cal_path_sel_onoff_r(1);

                          --when x"D8"  => RDATA_SYSCLK_X8 <= cal_sp4t_reserved_offset_r(0);
                          --when x"D9"  => RDATA_SYSCLK_X8 <= cal_sp4t_reserved_onoff_r(0);
                          --when x"DA"  => RDATA_SYSCLK_X8 <= cal_sp4t_reserved_offset_r(1);
                          --when x"DB"  => RDATA_SYSCLK_X8 <= cal_sp4t_reserved_onoff_r(1);
                          --when x"DC"  => RDATA_SYSCLK_X8 <= cal_sp4t_reserved_offset_r(2);
                          --when x"DD"  => RDATA_SYSCLK_X8 <= cal_sp4t_reserved_onoff_r(2);

                          --when x"E0"  => RDATA_SYSCLK_X8 <= tdd_and_ctrl_r(0);
                          --when x"E1"  => RDATA_SYSCLK_X8 <= tdd_and_ctrl_r(1);
                          --when x"E2"  => RDATA_SYSCLK_X8 <= tdd_and_ctrl_r(2);
                          --when x"E3"  => RDATA_SYSCLK_X8 <= tdd_and_ctrl_r(3);
                          --when x"E4"  => RDATA_SYSCLK_X8 <= tdd_and_ctrl_r(4);
                          --when x"E5"  => RDATA_SYSCLK_X8 <= tdd_and_ctrl_r(5);
                          --when x"E6"  => RDATA_SYSCLK_X8 <= tdd_and_ctrl_r(6);

                          --when x"F0"  => RDATA_SYSCLK_X8 <= tdd_or_ctrl_r(0);
                          --when x"F1"  => RDATA_SYSCLK_X8 <= tdd_or_ctrl_r(1);
                          --when x"F2"  => RDATA_SYSCLK_X8 <= tdd_or_ctrl_r(2);
                          --when x"F3"  => RDATA_SYSCLK_X8 <= tdd_or_ctrl_r(3);
                          --when x"F4"  => RDATA_SYSCLK_X8 <= tdd_or_ctrl_r(4);
                          --when x"F5"  => RDATA_SYSCLK_X8 <= tdd_or_ctrl_r(5);
                          --when x"F6"  => RDATA_SYSCLK_X8 <= tdd_or_ctrl_r(6);

                          --when x"FF"  => RDATA_SYSCLK_X8 <= equip_tdd_select_r;
                          when others => RDATA_SYSCLK_X8 <= (others => '0');
                    end case;
                    when x"B6"  =>
                        case ADDRL8B is
                              when x"00"  => RDATA_SYSCLK_X8 <= etm_tp_mem_port_en;
                              when x"01"  => RDATA_SYSCLK_X8 <= etm_tp_mem_wr_en;
                              when x"02"  => RDATA_SYSCLK_X8 <= etm_tp_mem_wraddr;
                              when x"03"  => RDATA_SYSCLK_X8 <= etm_tp_mem_wrdata;
                              when others => RDATA_SYSCLK_X8 <= (others => '0');
                        end case;
                when others => RDATA_SYSCLK_X8 <= (others => '0');
            end case;
        else
            RDATA_SYSCLK_X8 <= (others => '0');
        end if;
    end if;
end process;

---- 307.20 MHz Domain --
--RDATA_MUX_PROC3: process(i_sysclk_x10_rst, CLK_SYSX10)
--begin
--    if (i_sysclk_x10_rst = '1') then
--        RDATA_SYSCLK_X10 <= (others => '0');
--    elsif (CLK_SYSX10'event and CLK_SYSX10 = '1') then
--        if (RDEN_STRB_SYSX10 = '1') then
--            case ADDR_CPU_IN(15 downto 8) is
--                when x"??"  =>
--                    case ADDRL8B is
--                          when x"80"  => RDATA_SYSCLK_X10 <=                ;
--                          when x"81"  => RDATA_SYSCLK_X10 <=                ;
--                          when others => RDATA_SYSCLK_X10 <= (others => '0');
--                    end case;
--                when others => RDATA_SYSCLK_X10 <= (others => '0');
--            end case;
--        else
--            RDATA_SYSCLK_X10 <= (others => '0');
--        end if;
--    end if;
--end process;
-- 200 MHz Domain --
--RDATA_MUX_PROC4: process(i_miscclk_x3, CLK_MISC3)
--begin
--    if (i_miscclk_x3 = '1') then
--        RDATA_MISC_X3 <= (others => '0');
--    elsif (CLK_MISC3'event and CLK_MISC3 = '1') then
--        if (RDEN_STRB_MISC3 = '1') then
--            case ADDR_CPU_IN(15 downto 8) is
--                when x"A6"  =>
--                    case ADDRL8B is
--                          when x"00"  => RDATA_MISC_X3 <= SIG_SUS_MAIN_TYPE_IN & SIG_SUS_SUB_TYPE_IN & x"00" & SIG_SUS_VER_IN;
--                          when x"01"  => RDATA_MISC_X3 <= SIG_SUS_STRUCT_IN;
--                          when x"02"  => RDATA_MISC_X3 <= SIG_SUS_DATE_IN;
--
--                          when x"10"  => RDATA_MISC_X3 <= sig_sus_amp_protect_on  ;
--                          when x"11"  => RDATA_MISC_X3 <= alm_deb_cnt             ;
--                          when x"12"  => RDATA_MISC_X3 <= rf_sw_off_release       ;
--
--                          when x"20"  => RDATA_MISC_X3 <= sig_sus_cpri_link_ant(0);
--                          when x"21"  => RDATA_MISC_X3 <= sig_sus_cpri_link_ant(1);
--                          when x"22"  => RDATA_MISC_X3 <= sig_sus_cpri_link_ant(2);
--                          when x"23"  => RDATA_MISC_X3 <= sig_sus_cpri_link_ant(3);
--                          when x"24"  => RDATA_MISC_X3 <= sig_sus_cpri_link_ant(4);
--                          when x"25"  => RDATA_MISC_X3 <= sig_sus_cpri_link_ant(5);
--                          when x"26"  => RDATA_MISC_X3 <= sig_sus_cpri_link_ant(6);
--                          when x"27"  => RDATA_MISC_X3 <= sig_sus_cpri_link_ant(7);
--
--                          when x"30"  => RDATA_MISC_X3 <= f_log_cpriphy   ;
--                          when x"31"  => RDATA_MISC_X3 <= f_log_sbifphy   ;
--                          when x"32"  => RDATA_MISC_X3 <= f_log_cpri      ;
--                          when x"33"  => RDATA_MISC_X3 <= f_log_sbif      ;
--                          when x"34"  => RDATA_MISC_X3 <= f_log_bbctrl    ;
--                          when x"35"  => RDATA_MISC_X3 <= f_log_dsp       ;
--                          when x"36"  => RDATA_MISC_X3 <= f_log_dcif_dl   ;
--                          when x"37"  => RDATA_MISC_X3 <= f_log_dcif_ul   ;
--                          when x"38"  => RDATA_MISC_X3 <= f_log_dcif_fb   ;
--                          when x"39"  => RDATA_MISC_X3 <= f_log_clk       ;
--                          when x"3A"  => RDATA_MISC_X3 <= f_log_rfic      ;
--                          when x"3B"  => RDATA_MISC_X3 <= f_log_voltage   ;
--                          when x"3C"  => RDATA_MISC_X3 <= f_log_dac_off   ;
--                          when x"3D"  => RDATA_MISC_X3 <= f_log_wdt       ;
--
--                          when x"40"  => RDATA_MISC_X3 <= s_log_cpriphy   ;
--                          when x"41"  => RDATA_MISC_X3 <= s_log_sbifphy   ;
--                          when x"42"  => RDATA_MISC_X3 <= s_log_cpri      ;
--                          when x"43"  => RDATA_MISC_X3 <= s_log_sbif      ;
--                          when x"44"  => RDATA_MISC_X3 <= s_log_bbctrl    ;
--                          when x"45"  => RDATA_MISC_X3 <= s_log_dsp       ;
--                          when x"46"  => RDATA_MISC_X3 <= s_log_dcif_dl   ;
--                          when x"47"  => RDATA_MISC_X3 <= s_log_dcif_ul   ;
--                          when x"48"  => RDATA_MISC_X3 <= s_log_dcif_fb   ;
--                          when x"49"  => RDATA_MISC_X3 <= s_log_clk       ;
--                          when x"4A"  => RDATA_MISC_X3 <= s_log_rfic      ;
--                          when x"4B"  => RDATA_MISC_X3 <= s_log_voltage   ;
--                          when x"4C"  => RDATA_MISC_X3 <= s_log_dac_off   ;
--                          when x"4D"  => RDATA_MISC_X3 <= s_log_wdt       ;
--
--                          when x"50"  => RDATA_MISC_X3 <= alm_en_cpriphy  ;
--                          when x"51"  => RDATA_MISC_X3 <= alm_en_sbifphy  ;
--                          when x"52"  => RDATA_MISC_X3 <= alm_en_cpri     ;
--                          when x"53"  => RDATA_MISC_X3 <= alm_en_sbif     ;
--                          when x"54"  => RDATA_MISC_X3 <= alm_en_bbctrl   ;
--                          when x"55"  => RDATA_MISC_X3 <= alm_en_dsp      ;
--                          when x"56"  => RDATA_MISC_X3 <= alm_en_dcif_dl  ;
--                          when x"57"  => RDATA_MISC_X3 <= alm_en_dcif_ul  ;
--                          when x"58"  => RDATA_MISC_X3 <= alm_en_dcif_fb  ;
--                          when x"59"  => RDATA_MISC_X3 <= alm_en_volt     ;
--                          when x"5A"  => RDATA_MISC_X3 <= alm_en_pg       ;
--                          when x"5B"  => RDATA_MISC_X3 <= alm_en_others   ;
--
--                          when x"60"  => RDATA_MISC_X3 <= dl_off_cpriphy  ;
--                          when x"61"  => RDATA_MISC_X3 <= dl_off_sbifphy  ;
--                          when x"62"  => RDATA_MISC_X3 <= dl_off_sbif     ;
--                          when x"63"  => RDATA_MISC_X3 <= dl_off_bbctrl   ;
--                          when x"64"  => RDATA_MISC_X3 <= dl_off_dsp      ;
--                          when x"65"  => RDATA_MISC_X3 <= dl_off_dcif     ;
--
--                          when x"70"  => RDATA_MISC_X3 <= alm_off_volt    ;
--
--                          when others => RDATA_MISC_X3 <= (others => '0');
--                    end case;
--                when others => RDATA_MISC_X3 <= (others => '0');
--            end case;
--        else
--            RDATA_MISC_X3 <= (others => '0');
--        end if;
--    end if;
--end process;

end ARC_CPUIF_MISC;




