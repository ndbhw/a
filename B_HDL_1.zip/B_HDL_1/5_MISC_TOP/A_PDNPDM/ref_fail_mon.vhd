----------------------------------------------------------------------------------
-- Company:
-- Engineer:
--
-- Create Date:    18:51:12 01/30/2015
-- Design Name:
-- Module Name:    ref_fail_mon - Behavioral
-- Project Name:
-- Target Devices:
-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

use ieee. std_logic_arith.all ;
use ieee. std_logic_unsigned.all ;
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ref_fail_mon is
generic(
    CNT_LIMIT       : integer := 46080000;  --1.5sec, 30.72e6 + 15.35e6
    N_DIVIDE            : integer := 23         --Enter floor(log2(freq in Hz)), for 1PPS, enter '1'
);
port(
    ck30p72MHz          : in std_logic;

    ext_ref_in          : in std_logic;
    resetb              : in std_logic; --active low

    clock_fail          : out std_logic

);
end ref_fail_mon;

architecture Behavioral of ref_fail_mon is

    signal e_ref_in : std_logic := '0';

    signal e_ref_in_d1  : std_logic;
    signal e_ref_in_d2  : std_logic;
    signal e_ref_in_d3  : std_logic;
    signal e_ref_in_d4  : std_logic;

    signal rst_e            : std_logic;
    signal rst_l            : std_logic;

    signal dn_cnt           : std_logic_vector(27 downto 0) := (others => '0');
    signal up_cnt           : std_logic_vector(27 downto 0) := (others => '0');

    signal fail_clk     : std_logic ;

    signal div_cnt          : std_logic_vector(26 downto 0) := (others => '0');
    signal div_1pps     : std_logic;



begin
clock_fail <= fail_clk;


process(ext_ref_in) is
begin
    if ext_ref_in = '1' and ext_ref_in'event then
        div_cnt <= div_cnt + '1';
    end if;
end process;

e_ref_in <= div_cnt(N_DIVIDE-1);
--process(div_1pps, resetb)
--begin
--  if resetb = '0' then
--      e_ref_in    <= '0' ;
--  elsif rising_edge(div_1pps) then
--      e_ref_in    <= not e_ref_in ;
--  end if ;
--end process ;

process(ck30p72MHz) is
begin
    if ck30p72MHz = '1' and ck30p72MHz'event then
        e_ref_in_d1 <= e_ref_in;
        e_ref_in_d2 <= e_ref_in_d1;
        e_ref_in_d3 <= e_ref_in_d2;
        e_ref_in_d4 <= e_ref_in_d3;

        if e_ref_in_d3 = '1' and e_ref_in_d4 = '0' then
            rst_e <= '1';
        else
            rst_e <= '0';
        end if;

        if e_ref_in_d3 = '0' and e_ref_in_d4 = '1' then
            rst_l <= '1';
        else
            rst_l <= '0';
        end if;



    end if;
end process;

process(ck30p72MHz, resetb) is
begin
    if resetb = '1' then
        dn_cnt <= (others => '0');
        up_cnt <= (others => '0');
    elsif ck30p72MHz = '1' and ck30p72MHz'event then

        if rst_e = '1' then
            dn_cnt <= (others => '0');
        elsif e_ref_in_d4 = '1' then
            if dn_cnt < CNT_LIMIT then
                dn_cnt <= dn_cnt + '1';
            end if;
        end if;

        if rst_l = '1' then
            up_cnt <= (others => '0');
        elsif e_ref_in_d4 = '0' then
            if up_cnt < CNT_LIMIT then
                up_cnt <= up_cnt + '1';
            end if;
        end if;

    end if;
end process;

process(ck30p72MHz, resetb) is
begin
    if resetb = '1' then
        fail_clk <= '0';
    elsif ck30p72MHz = '1' and ck30p72MHz'event then
        if dn_cnt >= CNT_LIMIT or up_cnt >= CNT_LIMIT then
            fail_clk <= '1';
        else
            fail_clk <= '0';
        end if;
    end if;
end process;


end Behavioral;

