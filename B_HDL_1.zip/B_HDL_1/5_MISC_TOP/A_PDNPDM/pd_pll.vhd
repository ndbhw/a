library ieee ;
use ieee. std_logic_1164.all ;
use ieee. std_logic_arith.all ;
use ieee. std_logic_unsigned.all ;

entity pd_pll is
    generic(
        LOOP_CNT_MAX    : integer := 24999999   --change this value according to the frequency of ck50MHz pin, For 50MHz : 24999999,  for 30.72MHz : 15359999
    );
    port    (


        reset               : in std_logic; --active high reset (reset duration > 100ns)

        pll_ref         : in std_logic ;    --reference 1PPS (1Hz) signal divided from local pll output clock (LMK PLL)
        ck250MHz            : in std_logic ;    --250MHz (or 245.76MHz) clock generated from TCXO 30.72MHz with MMCM



        ck50MHz         : in std_logic ;    --50MHz clock generated from TCXO 30.72MHz
        --if you want to change this to 30.72, then counter for generating loop_1hz should be changed


        pll_pd_irq      : out std_logic ;   --interrupt signal sent to CPU

        pll_pd_sign     : out std_logic ;   --sign of pll_pd value, 0 : positive sign, 1: negative sign
        pll_pd          : out std_logic_vector(28 downto 0); --phase error (unsigned integer) of rising edge between two clocks, resolution = 4ns for 250MHz clock, 4.069ns for 245.76MHz clock



      loop_clk_out    : out std_logic

        ) ;
end pd_pll ;

architecture behav_pd_pll of pd_pll is


signal loop_clk_cnt : std_logic_vector(27 downto 0);


--signal pll_pd_clr : std_logic := '0';
--signal pll_pd_algn    : std_logic := '0';
signal algn : std_logic;
--signal pll_pd_en  : std_logic := '1';


signal loop_clk         : std_logic ;
--signal pd_cnt_clr_q       : std_logic_vector(1 downto 0) ;
signal cnt_clr_q            : std_logic_vector(1 downto 0) ;
signal cnt_clr              : std_logic ;
signal cntclr               : std_logic ;
--signal irq_clr_q          : std_logic_vector(3 downto 0) ;
--signal pd_irq_clr         : std_logic ;
signal ref_q                : std_logic ;
signal loop_q               : std_logic ;
signal pd_sign1         : std_logic ;
signal pd_sign2         : std_logic ;
signal pd_sign3         : std_logic ;
signal pd_buffer            : std_logic_vector(28 downto 0) ;
signal int_q                : std_logic_vector(4 downto 0) ;

--signal cnt625K                : std_logic_vector(6 downto 0) ;
--signal ck625K             : std_logic ;
--signal cnt2Hz             : std_logic_vector(18 downto 0) ;
--signal ck2Hz_co           : std_logic ;
--signal co_ck2Hz           : std_logic ;
--signal ck1Hz              : std_logic ;
--signal loop_1Hz           : std_logic ;
--signal loop_even          : std_logic ;
--signal even_loop          : std_logic ;
--signal ck100Hz                : std_logic ;
--signal algn_q1                : std_logic ;
--signal algn_q2                : std_logic ;
--signal algn_q3                : std_logic ;
signal algn_pd              : std_logic ;
signal start                : std_logic ;
--signal start_q                : std_logic ;
--signal start_flag         : std_logic ;
--signal dac_irq_cnt        : std_logic_vector(19 downto 0) ;
--signal dac_irq0           : std_logic ;

signal t_pd1                : std_logic_vector(28 downto 0) ;
signal rst1                 : std_logic ;
signal rst2                 : std_logic ;
signal rst3                 : std_logic ;
signal rst4                 : std_logic ;
signal fstart_q         : std_logic ;
signal ref_q_d0         : std_logic_vector(1 downto 0) ;

signal loop_q_d0            : std_logic_vector(1 downto 0) ;
--signal even_st                : std_logic ;


signal pll_ref_sw       : std_logic;
signal sel_ref          : std_logic;

signal temp_data        : std_logic_vector(23 downto 0);
signal pd_buffer_init   : std_logic_vector(28 downto 0) ;


signal ref_clr_flag     : std_logic;
signal int_q1               : std_logic_vector(4 downto 0);


signal pd_clear         : std_logic;
signal pd_update            : std_logic;

begin



algn <= reset;




algn_pd <= algn;



--------start---------
process(pll_ref, algn_pd)
begin
    if algn_pd = '1' then
        start   <= '0' ;
    elsif rising_edge(pll_ref) then

            start   <= '1' ;

    end if ;
end process ;


--
--constant LOOP_CNT_MAX : integer := 49999999;
--loop_clk
--
process(ck50Mhz, algn_pd)
begin
    if algn_pd = '1' then
        loop_clk_cnt <= (others => '0');
    elsif ck50Mhz = '1' and ck50Mhz'event then
        if start = '1' then
            if loop_clk_cnt = (2*LOOP_CNT_MAX + 1) then
                loop_clk_cnt <= (others => '0');
            else
                loop_clk_cnt <= loop_clk_cnt + '1';
            end if;
        end if;
    end if;
end process;

process(ck50Mhz,algn_pd)
begin
    if algn_pd = '1' then
        loop_clk <= '0';
    elsif ck50Mhz = '1' and ck50Mhz'event then
        if loop_clk_cnt < LOOP_CNT_MAX then
            loop_clk <= '1';
        else
            loop_clk <= '0';
        end if;
    end if;
end process;

-----------------------------------------------
--------co625KHZ---------
-----------------------------------------------
--process(ck50Mhz, algn_pd, start)
--begin
--  if algn_pd = '1' then
--      cnt625K <= (others => '0') ;
--      ck625K  <= '0' ;
--  elsif rising_edge(ck50Mhz) then
--      if start = '1' then
--          if cnt625K = "1001110" then
--              cnt625K <= cnt625K + '1' ;
--              ck625K  <= '1' ;
--          elsif cnt625K = "1001111" then
--              cnt625K <= (others => '0') ;
--              ck625K  <= '0' ;
--          else
--              cnt625K <= cnt625K + '1' ;
--              ck625K  <= '0' ;
--          end if ;
--      end if ;
--  end if ;
--end process ;
-----------------------------------------------
-----------CO2HZ & CK2HZ-----------
-----------------------------------------------
--process(ck625K, ck50Mhz, algn_pd)
--begin
--  if algn_pd = '1' then
--      cnt2Hz  <= (others => '0') ;
--      co_ck2Hz    <= '0' ;
--  elsif rising_edge(ck50Mhz) then
--      if ck625K = '1' then
--          if cnt2Hz = "1001100010010110010" then
--              co_ck2Hz    <= '1' ;
--              cnt2Hz<=    cnt2Hz + '1' ;
--          elsif cnt2Hz = "1001100010010110011" then
--              co_ck2Hz    <= '0' ;
--              cnt2Hz<=    (others => '0') ;
--          else
--              co_ck2Hz    <= '0' ;
--              cnt2Hz<=    cnt2Hz + '1' ;
--          end if ;
--      end if ;
--  end if ;
--end process ;
--
--ck2Hz_co  <= co_ck2Hz and ck625K ;
-----------------------------------------------
-----------CO1HZ & CK1HZ -----------
-----------------------------------------------
--process(ck2Hz_co, ck50Mhz, algn_pd)
--begin
--  if algn_pd = '1' then
--      ck1Hz   <= '0' ;
--  elsif rising_edge(ck50Mhz) then
--      if ck2Hz_co = '1' then
--          ck1Hz   <=  not ck1Hz ;
--      end if ;
--  end if ;
--end process ;
--
--process(ck50MHz, algn_pd, ck1Hz)
--begin
--  if algn_pd = '1' then
--      loop_1Hz    <= '0' ;
--  elsif rising_edge(ck50MHz) then
--      loop_1Hz    <= not ck1Hz ;
--  end if ;
--end process ;
--
--
--
-----####---
--process( loop_1Hz, ck50MHz,  algn_pd)
--begin
--  if algn_pd = '1' then
--      loop_clk    <= '0' ;
--  elsif rising_edge(ck50MHz) then
--      loop_clk    <= loop_1Hz ;
--
--  end if ;
--end process ;





















---####---
--------cnt_clr---------
process(ck50MHz, algn_pd)
begin
    if algn_pd = '1' then
        cnt_clr_q   <= (others => '0') ;
    elsif rising_edge(ck50MHz) then
        cnt_clr_q(0)    <= cntclr ;
        cnt_clr_q(1)    <= cnt_clr_q(0) ;
    end if ;
end process ;

cnt_clr <= (not cnt_clr_q(1)) and cnt_clr_q(0) ;



--------pd compare---------
process(algn_pd, ck50Mhz)
begin
    if algn_pd = '1' then
        rst1    <= '1' ;
    elsif rising_edge(ck50Mhz) then
        rst1    <= cnt_clr ;
    end if ;
end process ;


process(ck50MHz)
begin
    if rising_edge(ck50MHz) then
        int_q1  <= int_q1(3 downto 0) & loop_clk ;
    end if ;
end process ;
ref_clr_flag <= (not loop_clk) nand int_q1(4) ;




process(pll_ref, rst1,ref_clr_flag)
begin
    if (rst1 = '1') or (ref_clr_flag = '0') then
--  if (rst1 = '1') then
        ref_q   <= '0' ;
    elsif rising_edge(pll_ref) then
        if start = '1' then
            ref_q   <= '1' ;
        end if ;
    end if ;
end process ;
---####---
process(rst1, loop_clk, ref_clr_flag)
begin
    if (rst1 = '1') or (ref_clr_flag = '0') then
--  if (rst1 = '1') then
        loop_q  <= '0' ;
    elsif rising_edge(loop_clk) then
        if start = '1' then
            loop_q  <= '1' ;
        end if ;
    end if ;
end process ;
---####---
cntclr  <= ref_q and loop_q ;

process(ck250Mhz)
begin
--  if rst1 = '1' then
--      ref_q_d0        <= (others => '0') ;
--      loop_q_d0   <= (others => '0') ;
    if rising_edge(ck250MHz) then
        ref_q_d0(0)     <= ref_q ;
        ref_q_d0(1)     <= ref_q_d0(0) ;
        loop_q_d0(0)    <= loop_q ;
        loop_q_d0(1)    <= loop_q_d0(0) ;
    end if ;
end process ;

---------------------------------------------
--------pd gen.--------
---------------------------------------------

process(ck50MHz) is
begin
    if ck50MHz = '1' and ck50MHz'event then
        if int_q(3) = '1' and int_q(4) = '0' then
            pd_clear <= '1';
        else
            pd_clear <= '0';
        end if;

        if int_q(1) = '1' and int_q(2) = '0' then
            pd_update <= '1';
        else
            pd_update <= '0';
        end if;

    end if;

end process;


rst2 <= algn_pd;


process(ck250Mhz, rst2, pd_clear)
begin
    if rst2 = '1' or pd_clear = '1' then
        t_pd1   <= (others => '0') ;
    elsif rising_edge(ck250MHz) then
        if (ref_q_d0(1) xor loop_q_d0(1)) = '1' then
            t_pd1   <= t_pd1 + '1' ;
        end if ;
    end if ;
end process ;


process(algn_pd, ck50MHz)
begin
    if algn_pd = '1' then
        pd_buffer(28 downto 0)  <= (others => '0') ;
    elsif rising_edge(ck50Mhz) then
--      if pd_update = '1' then
            pd_buffer(28 downto 0)  <= t_pd1  ;
--      end if;
    end if ;
end process ;

process(loop_q, rst2, pd_clear)
begin
    if rst2 = '1' or pd_clear = '1' then
        pd_sign1    <= '0' ;
--      pd_sign1    <=  not gps_adelay_out(23);
    elsif rising_edge(loop_q) then
        pd_sign1    <= ref_q ;
    end if ;
end process ;

process(ck250Mhz, pd_sign1, rst2)
begin
    if rst2 = '1' then
        pd_sign2            <= '0' ;
        pd_sign3            <= '0' ;
        pll_pd_sign     <= '0' ;
    elsif rising_edge(ck250Mhz) then
        if pd_update = '1' then
            pd_sign2            <= pd_sign1 ;
            pd_sign3            <= pd_sign2 ;
            pll_pd_sign     <= pd_sign3 ;
        end if;
    end if;
end process ;


--pd_buffer_init <= ("00000" & gps_adelay_out) * 100;

process(ck50MHz, algn_pd)
begin
    if algn_pd = '1' then
        pll_pd  <= (others => '0');--pd_buffer_init ;
    elsif rising_edge(ck50Mhz) then
        if pd_update = '1' then
            pll_pd  <= pd_buffer ;
        end if;
    end if ;
end process ;

----------------------------------------------------------------------------------------
---------------------------------------------
--------pll interrupt gen.--------
---------------------------------------------
rst3 <= algn_pd;



process(loop_clk, ck50MHz, rst3)
begin
    if rst3 = '1' then
        int_q   <= (others =>'0') ;
    elsif rising_edge(ck50MHz) then
        int_q   <= int_q(3 downto 0) & loop_clk ;
    end if ;
end process ;





pll_pd_irq  <= (not loop_clk) nand int_q(4) ;



loop_clk_out <= loop_clk;

end behav_pd_pll ;