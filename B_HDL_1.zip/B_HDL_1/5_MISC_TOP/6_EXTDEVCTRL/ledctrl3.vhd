--======================================================================
--Title              :   Front LED Controller
--======================================================================

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

entity LEDCTRL3 is
port (  
   RESET       : in std_logic;
   NCLK        : in std_logic; -- 100MHz
   LEDSEL      : in std_logic_vector(4 downto 0);   -- LED color
                                                    -- [4]   Blink period          [3]   3 blink on/off
                                                    -- [2:0] 3'b001(RED) / 3'b010(GREEN) / 3'b100(BLUE) 
                        
   SOLID_RED_ON: in std_logic;

   RLED        : out std_logic;
   GLED        : out std_logic;
   BLED        : out std_logic
);
end LEDCTRL3;

architecture arc_LEDCTRL3 of LEDCTRL3 is
   signal bcnt         : std_logic_vector(25 downto 0);
   signal onoff        : std_logic;
begin

   -- blink period
   -- LEDSEL(4) : 0=300ms, 1=150ms
   process(RESET,NCLK)
   begin
      if RESET='1' then
         bcnt  <= (others=>'0');
         onoff <= '1';
      elsif NCLK'event and NCLK='1' then
         bcnt  <= bcnt + 1;

         if LEDSEL(4)='1' then
            onoff <= bcnt(25); -- 335ms blink
         else
            onoff <= bcnt(24); -- 165ms blink
         end if;
      end if;
   end process;

   process(RESET,NCLK)
   begin 
      if RESET='1' then
         RLED  <= '1';
         GLED  <= '0';
         BLED  <= '0';
      elsif NCLK'event and NCLK = '1' then
         if SOLID_RED_ON = '1' then
            RLED  <= '1';
            GLED  <= '0';
            BLED  <= '0';
         elsif LEDSEL(3)='1' then -- blink
            RLED <= LEDSEL(0) and onoff;
            GLED <= LEDSEL(1) and onoff;
            BLED <= LEDSEL(2) and onoff;
         else   -- solid 
            RLED <= LEDSEL(0);
            GLED <= LEDSEL(1);
            BLED <= LEDSEL(2);
         end if;
      end if;
   end process;        

end arc_LEDCTRL3;

--configuration CFG_LEDCTRL of LEDCTRL  is
--   for ARC_LEDCTRL
--   end for;
--end CFG_LEDCTRL;
