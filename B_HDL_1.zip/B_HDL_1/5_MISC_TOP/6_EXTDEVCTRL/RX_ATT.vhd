library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity RX_ATT is
    generic(
    OUT_RATE                        : in  integer                                -- Period of output Clock 
                                                                                 -- Period = (2^out_rate) * 2 * 10 ns
    );
    port(
    RST                             : in  std_logic                            ; -- RST_CPU               : Input Reset from CPU, Active High
    CLK                             : in  std_logic                            ; -- CLK_CPU               : Input Clock for RX Attenuator

    ATT_EN                          : in  std_logic_vector(         3 downto 0);
    ATT_WORD                        : in  std_logic_array7(         3 downto 0);

    RXATT_AB_CLK                    : out std_logic                            ;
    RXATT_AB_DI                     : out std_logic                            ;
    RXATT_A_LE                      : out std_logic                            ;
    RXATT_B_LE                      : out std_logic                            ;

    RXATT_CD_CLK                    : out std_logic                            ;
    RXATT_CD_DI                     : out std_logic                            ;
    RXATT_C_LE                      : out std_logic                            ;
    RXATT_D_LE                      : out std_logic

    );
end RX_ATT;

architecture arc_RX_ATT of RX_ATT is

signal cnt_100mhz                   : std_logic_vector(    OUT_RATE-1 downto 0);
signal sts_ref                      : std_logic                                ;
signal sts_cnt                      : std_logic_array8(             3 downto 0);

signal i_rxatt_clk                  : std_logic_vector(             3 downto 0);
signal i_rxatt_le                   : std_logic_vector(             3 downto 0);
signal i_rxatt_word                 : std_logic_array7(             3 downto 0);
signal ii_rxatt_word                : std_logic_vector(             3 downto 0);

begin

    ATT_WORD_GEN :for I in 0 to 3 generate

        ATT_WORD_n_PATH_SEL : process(RST,CLK)
        begin
            if RST = '1' then
                i_rxatt_word(I)     <= (others => '0');
            elsif rising_edge(CLK) then
                if sts_cnt(I) = x"00" then
                    i_rxatt_word(I) <= ATT_WORD(I);
                else
                    i_rxatt_word(I) <= i_rxatt_word(I);
                end if;
            end if;
        end process;

    end generate;

    Counter_Gen : process(RST,CLK)
    begin
        if RST = '1' then
            cnt_100mhz              <= (others => '0');
            sts_ref                 <= '0';
        elsif rising_edge(CLK) then
            cnt_100mhz              <= cnt_100mhz + '1';
            if cnt_100mhz = 2**OUT_RATE-1 then
                sts_ref             <= '1';
            else
                sts_ref             <= '0';
            end if;
        end if;
    end process;

    FSM_COUNTER_GEM : for I in 0 to 3 generate
    process(RST,CLK)
    begin
        if RST = '1' then
            sts_cnt(I)              <= (others => '0');
        elsif rising_edge(CLK) then
            if ATT_EN(I) = '1' then
                if sts_ref = '1' then
                    if sts_cnt(I) = x"13" then
                        sts_cnt(I)     <= sts_cnt(I);
                    else
                        sts_cnt(I)     <= sts_cnt(I) + '1';
                    end if;
                end if;
            else  -- corner case protect statement
                if sts_ref = '1' then
                    if sts_cnt(I) = x"00" then
                        sts_cnt(I)     <= (others => '0');
                    else
                        if sts_cnt(I) = x"13" then
                            sts_cnt(I) <= (others => '0');
                        else
                            sts_cnt(I) <= sts_cnt(I) + '1';
                        end if;
                    end if;
                end if;
            end if;
        end if;
    end process;
    end generate;

    FSM_GEN : for I in 0 to 3 generate

        process(RST,CLK)
        begin
            if RST = '1' then
                i_rxatt_clk(I)      <= '0';
                ii_rxatt_word(I)    <= '0';
                i_rxatt_le(I)       <= '0';
            elsif rising_edge(CLK) then
                case sts_cnt(I) is  -- CLK
                    when x"02"      => i_rxatt_clk(I)  <= '1';
                    when x"04"      => i_rxatt_clk(I)  <= '1';
                    when x"06"      => i_rxatt_clk(I)  <= '1';
                    when x"08"      => i_rxatt_clk(I)  <= '1';
                    when x"0A"      => i_rxatt_clk(I)  <= '1';
                    when x"0C"      => i_rxatt_clk(I)  <= '1';
                    when x"0E"      => i_rxatt_clk(I)  <= '1';
                    when x"10"      => i_rxatt_clk(I)  <= '1';
                    when others     => i_rxatt_clk(I)  <= '0';
                end case;

                case sts_cnt(I) is  -- Att_Word
                    when x"00"      => ii_rxatt_word(I) <= '0';
                    when x"01"      => ii_rxatt_word(I) <= i_rxatt_word(I)(0);
                    when x"03"      => ii_rxatt_word(I) <= i_rxatt_word(I)(1);
                    when x"05"      => ii_rxatt_word(I) <= i_rxatt_word(I)(2);
                    when x"07"      => ii_rxatt_word(I) <= i_rxatt_word(I)(3);
                    when x"09"      => ii_rxatt_word(I) <= i_rxatt_word(I)(4);
                    when x"0B"      => ii_rxatt_word(I) <= i_rxatt_word(I)(5);
                    when x"0D"      => ii_rxatt_word(I) <= i_rxatt_word(I)(6);
                    when x"0F"      => ii_rxatt_word(I) <= '0'               ; -- D(7) must be LOW
                    when others     => ii_rxatt_word(I) <= ii_rxatt_word(I)  ;
                end case;

                case sts_cnt(I) is  -- Load Enable
                    when x"11"      => i_rxatt_le(I)    <= '1';
                    when x"12"      => i_rxatt_le(I)    <= '1';
                    when others     => i_rxatt_le(I)    <= '0';
                end case;
        end if;
    end process;

    end generate;


    RXATT_AB_CLK                    <= i_rxatt_clk(0)   or i_rxatt_clk(1)   ;
    RXATT_CD_CLK                    <= i_rxatt_clk(2)   or i_rxatt_clk(3)   ;

    RXATT_AB_DI                     <= ii_rxatt_word(0) or ii_rxatt_word(1) ;
    RXATT_CD_DI                     <= ii_rxatt_word(2) or ii_rxatt_word(3) ;

    RXATT_A_LE                      <= i_rxatt_le(0)                        ;
    RXATT_B_LE                      <= i_rxatt_le(1)                        ;
    RXATT_C_LE                      <= i_rxatt_le(2)                        ;
    RXATT_D_LE                      <= i_rxatt_le(3)                        ;



end arc_RX_ATT;
