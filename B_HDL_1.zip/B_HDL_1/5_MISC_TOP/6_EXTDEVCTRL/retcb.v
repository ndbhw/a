`timescale 1 ns/1 ps
module retcb
    (RST                ,
    CLK_SYS             ,
    UART1_TX            ,
    UART1_RX_IN         ,
    RET_TEST_EN         ,
    LSBorMSB            ,

    UART1_TX_OUT        ,
    UART1_RX            ,
    RET_nRE             ,
    RET_DE              ,
    TX_UART_START_CNT   ,
    TX_UART_ERR_CNT     ,
    RX_UART_START_CNT   ,
    RX_UART_ERR_CNT     ,
    UART_CLK            ,
    UART1_TX_BUFF
    );
						
input RST;
input CLK_SYS;
input UART1_TX;
input UART1_RX_IN;
input RET_TEST_EN;
input LSBorMSB;

output UART1_TX_OUT;
output UART1_RX;
output RET_nRE;
output RET_DE;

//reg RET_nRE;
reg UART1_TX_OUT;
reg [1:0] ret_test_en_r;

output [15:0] TX_UART_START_CNT;
output [15:0] TX_UART_ERR_CNT;
output [15:0] RX_UART_START_CNT;
output [15:0] RX_UART_ERR_CNT;
output UART_CLK;
output UART1_TX_BUFF;
wire   UART_CLK;
//      start|<----- eight data bits ------->| stop bit(s)
//      (Low)                                  (High)
//  1----  S   -   -   -   -   -   -   -   -  --- ----
//       | T |   |   |   |   |   |   |   |   | S |
//       | A | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | T |
//       | R |   |   |   |   |   |   |   |   | O |
//       | T |   |   |   |   |   |   |   |   | P |
//  0     ---  -   -   -   -   -   -   -   -


// TX UART Direction Control
reg  [5:0] TX_BAUD_CNT;
reg  [7:0] TX_UART_CNT;
reg  [3:0] TX_UART_FRAME_CNT;
reg  TX_UART_START;
reg  RET_nRE;
reg  RET_DE;
reg  UART1_RX;
reg  UART1_TX_d ;
reg  UART1_TX_dd;
wire UART1_TX_SEL;

always @(posedge CLK_SYS or posedge RST) begin
    if (RST) begin
        UART1_TX_OUT      <= 0;
        TX_BAUD_CNT       <= 0;
        TX_UART_CNT       <= 0;
        TX_UART_FRAME_CNT <= 0;
        TX_UART_START     <= 0; 
    end	
    else begin // it's a posedge  of clk
        UART1_TX_OUT <= UART1_TX_SEL;
	if ((UART1_TX_SEL == 0) & (TX_UART_START == 0)) begin // UART TX Start Detection State
            TX_UART_START <= 1;
        end
        else if (TX_UART_START ==1) begin // UART Framing State
            if (TX_BAUD_CNT == 39) begin // 2.5MHz
                TX_BAUD_CNT <= 0;
                if (TX_UART_CNT == (256-1)) begin // 9.765625KHz
                    TX_UART_CNT  <= 0;
		    if (TX_UART_FRAME_CNT == 0) begin // UART Frame 0bit	
                        TX_UART_FRAME_CNT <= TX_UART_FRAME_CNT + 1;
                    end 
		    else if ((TX_UART_FRAME_CNT > 0) & (TX_UART_FRAME_CNT < 9)) begin // UART Frame 1~8bit
                        TX_UART_FRAME_CNT <= TX_UART_FRAME_CNT + 1;
                    end 
                    else if (TX_UART_FRAME_CNT == 9) begin // UART Frame 9bit : Start(1)+Data(8)+Stop(1)
                        TX_UART_FRAME_CNT <= 0;
                        TX_UART_START     <= 0;
                    end
                end
		else begin
                    TX_UART_CNT <= TX_UART_CNT + 1;
                end
            end
            else begin
                TX_BAUD_CNT <= TX_BAUD_CNT + 1;
            end
        end
        else begin //UART RX State or UART TX Ending/Watting
            TX_UART_START <= 0;
        end
    end
end
	
// TX UART Start Counter
reg [15:0] TX_UART_START_VALID_CNT;

always @(posedge CLK_SYS or posedge RST) begin 
    if (RST) begin
        TX_UART_START_VALID_CNT <= 0;
    end 
    else begin
        if (((TX_UART_FRAME_CNT == 0) & (TX_UART_CNT == 127)) & (TX_BAUD_CNT == 0)) begin
            if (UART1_TX_SEL == 0) begin // UART Start & Stop Rule Error Check
                TX_UART_START_VALID_CNT <= TX_UART_START_VALID_CNT + 1;   
            end
        end
    end
end
   
 // TX UART STOP Fail Counter
reg [15:0] TX_UART_STOP_RULE_ERR_CNT; 

always @(posedge CLK_SYS or posedge RST) begin 
    if (RST) begin
        TX_UART_STOP_RULE_ERR_CNT <= 0;
    end 
    else begin
        if (((TX_UART_FRAME_CNT == 9) & (TX_UART_CNT == 127)) & (TX_BAUD_CNT == 0)) begin
            if (UART1_TX_SEL == 0) begin // UART Start & Stop Rule Error Check
                TX_UART_STOP_RULE_ERR_CNT <= TX_UART_STOP_RULE_ERR_CNT + 1;   
            end
        end
    end
end

// assign RET_DE  = TX_UART_START;
// assign RET_nRE = ~TX_UART_START; 
// assign RET_nRE = TX_UART_START; 
// for Fast Output Register
always @(posedge CLK_SYS or posedge RST) begin 
    if (RST) begin
        RET_nRE <= 0;
    end
    else begin
        RET_nRE <= TX_UART_START;
    end
end
    
always @(posedge CLK_SYS or posedge RST) begin 
    if (RST) begin
	RET_DE <= 0;
    end
    else begin
        RET_DE <= TX_UART_START;
    end
end

    assign TX_UART_START_CNT = TX_UART_START_VALID_CNT;
    assign TX_UART_ERR_CNT   = TX_UART_STOP_RULE_ERR_CNT;
        	
// RX UART Direction Control
reg [5:0] RX_BAUD_CNT;
reg [7:0] RX_UART_CNT;
reg [3:0] RX_UART_FRAME_CNT;
reg RX_UART_START;

always @(posedge CLK_SYS or posedge RST) begin
    if (RST) begin
        RX_BAUD_CNT       <= 0;
        RX_UART_CNT       <= 0;
        RX_UART_FRAME_CNT <= 0;
        RX_UART_START     <= 0; 
    end
    else begin // it's a posedge  of clk
        if ((UART1_RX_IN == 0) & (RX_UART_START == 0)) // UART RX Start Detection State
            RX_UART_START <= 1;
        else if (RX_UART_START ==1) begin // UART Framing State
            if (RX_BAUD_CNT == 39) begin // 2.5MHz
                RX_BAUD_CNT <= 0;
                if (RX_UART_CNT == (256-1)) begin // 9.765625KHz
                    RX_UART_CNT  <= 0;
                    if (RX_UART_FRAME_CNT == 0) begin // UART Frame 0bit	
                        RX_UART_FRAME_CNT <= RX_UART_FRAME_CNT + 1;
                    end
                end
                else if ((RX_UART_FRAME_CNT > 0) & (RX_UART_FRAME_CNT < 9)) begin // UART Frame 1~8bit
                        RX_UART_FRAME_CNT <= RX_UART_FRAME_CNT + 1;
                end
                else if (RX_UART_FRAME_CNT == 9) begin // UART Frame 9bit : Start(1)+Data(8)+Stop(1)
                    RX_UART_FRAME_CNT <= 0;
                    RX_UART_START <= 0;
                end
                else begin
                    RX_UART_CNT <= RX_UART_CNT + 1;
                end
            end
            else begin
                RX_BAUD_CNT <= RX_BAUD_CNT + 1;
      	    end
        end
        else begin //UART RX State or UART TX Ending/Watting
            RX_UART_START <= 0;
        end
    end
end
	
// RX UART Start Counter
reg [15:0] RX_UART_START_VALID_CNT;

always @(posedge CLK_SYS or posedge RST) begin 
    if (RST) begin
        RX_UART_START_VALID_CNT <= 0;
    end
    else begin
        if (((RX_UART_FRAME_CNT == 0) & (RX_UART_CNT == 127)) & (RX_BAUD_CNT == 0)) begin
            if (UART1_RX_IN == 0) begin // UART Start & Stop Rule Error Check
                RX_UART_START_VALID_CNT <= RX_UART_START_VALID_CNT + 1;   
            end
        end
    end
end
   
// RX UART STOP Fail Counter
reg [15:0] RX_UART_STOP_RULE_ERR_CNT; 

always @(posedge CLK_SYS or posedge RST) begin 
    if (RST) begin
        RX_UART_STOP_RULE_ERR_CNT <= 0;
    end
    else begin
        if (((RX_UART_FRAME_CNT == 9) & (RX_UART_CNT == 127)) & (RX_BAUD_CNT == 0)) begin
            if (UART1_RX_IN == 0) begin // UART Start & Stop Rule Error Check
                RX_UART_STOP_RULE_ERR_CNT <= RX_UART_STOP_RULE_ERR_CNT + 1;   
            end
        end
    end
end

// assign UART1_RX	= UART1_RX_IN; 
always @(posedge CLK_SYS or posedge RST) begin 
    if (RST) begin
        UART1_RX <= 0;
    end
    else begin
        if (RET_nRE == 0) begin // if READ enabled 
            UART1_RX <= UART1_RX_IN;
        end
        else begin
            UART1_RX <= 1;
        end
	end
end

assign RX_UART_START_CNT = RX_UART_START_VALID_CNT;
assign RX_UART_ERR_CNT	 = RX_UART_STOP_RULE_ERR_CNT;   
 
									
 ///////////////////////////////////////////////////////////////////////////
reg [5:0] TEST_BAUD_CNT;
reg [7:0] TEST_UART_CNT;
reg [3:0] TEST_UART_FRAME_CNT; 
reg       RET_TEST_END;
reg [7:0] UART1_TX_BUFF;
reg UART1_TX_SERIAL;
reg [4:0] TEST_UART_FRAME_BYTE_CNT;
 
parameter s0 = 4'b0001,
          s1 = 4'b0010,
          s2 = 4'b0100,		  
          s3 = 4'b1000;

reg [3:0] state;

always @(posedge CLK_SYS or posedge RST) begin 
    if (RST) begin
        UART1_TX_d  <= 1;
        UART1_TX_dd <= 1;
    end 
    else begin
        UART1_TX_d  <= UART1_TX;
        UART1_TX_dd <= UART1_TX_d;
    end
end

assign UART1_TX_SEL = (state == s2) ? UART1_TX_SERIAL : UART1_TX_dd;
	
always @(posedge CLK_SYS or posedge RST) begin 
    if (RST) begin
        ret_test_en_r <= 2'b00;
    end
    else begin
        ret_test_en_r <= {ret_test_en_r[0],RET_TEST_EN};
    end
end
					 		     
					 		     
always @(posedge CLK_SYS or posedge RST) begin
    if (RST) begin
        RET_TEST_END  <= 0; 
        UART1_TX_BUFF <= 8'hFF;
    end
    else begin
        if (ret_test_en_r[1]) begin
            RET_TEST_END  <= 0; 
            UART1_TX_BUFF <= 8'hFF;
        end 
        else begin
            case(TEST_UART_FRAME_BYTE_CNT)	
                4'b0000 : UART1_TX_BUFF <= 8'h7E; //Flag
                4'b0001 : UART1_TX_BUFF <= 8'hFF; //Address 
                4'b0010 : UART1_TX_BUFF <= 8'hBF; //Control
                4'b0011 : UART1_TX_BUFF <= 8'h81; //Info : Format ID
                4'b0100 : UART1_TX_BUFF <= 8'hF0; //Info : User Defined parameter set
                4'b0101 : UART1_TX_BUFF <= 8'h04; //Info : Length in octets for the rest of the message
                4'b0110 : UART1_TX_BUFF <= 8'h01; //Info : Unique ID
                4'b0111 : UART1_TX_BUFF <= 8'h00; //Info : Length of PV Field in octets
                4'b1000 : UART1_TX_BUFF <= 8'h03; //Info : Bit mask
                4'b1001 : UART1_TX_BUFF <= 8'h00; //Info : Length of PV Field in octets
                4'b1010 : UART1_TX_BUFF <= 8'hA6; //CRC								
                4'b1011 : UART1_TX_BUFF <= 8'h58; //CRC
                4'b1100 : UART1_TX_BUFF <= 8'h7E; //7E
                4'b1101 : RET_TEST_END  <= 1; 
                default : UART1_TX_BUFF <= 8'hFF;
            endcase
        end
    end
end

always @(posedge CLK_SYS or posedge RST) begin
    if (RST) begin
        UART1_TX_SERIAL <= 1; 
    end
    else begin
        if (LSBorMSB) begin
            case(TEST_UART_FRAME_CNT)	
                4'b0000 : UART1_TX_SERIAL <= 0;
                4'b0001 : UART1_TX_SERIAL <= UART1_TX_BUFF[0];
                4'b0010 : UART1_TX_SERIAL <= UART1_TX_BUFF[1];
                4'b0011 : UART1_TX_SERIAL <= UART1_TX_BUFF[2];
                4'b0100 : UART1_TX_SERIAL <= UART1_TX_BUFF[3];
                4'b0101 : UART1_TX_SERIAL <= UART1_TX_BUFF[4];
                4'b0110 : UART1_TX_SERIAL <= UART1_TX_BUFF[5];
                4'b0111 : UART1_TX_SERIAL <= UART1_TX_BUFF[6];
                4'b1000 : UART1_TX_SERIAL <= UART1_TX_BUFF[7];												
                default : UART1_TX_SERIAL <= 1;
            endcase    		
        end
        else begin
            case(TEST_UART_FRAME_CNT)	
                4'b0000 : UART1_TX_SERIAL <= 0;
                4'b0001 : UART1_TX_SERIAL <= UART1_TX_BUFF[7];
                4'b0010 : UART1_TX_SERIAL <= UART1_TX_BUFF[6];
                4'b0011 : UART1_TX_SERIAL <= UART1_TX_BUFF[5];
                4'b0100 : UART1_TX_SERIAL <= UART1_TX_BUFF[4];
                4'b0101 : UART1_TX_SERIAL <= UART1_TX_BUFF[3];
                4'b0110 : UART1_TX_SERIAL <= UART1_TX_BUFF[2];
                4'b0111 : UART1_TX_SERIAL <= UART1_TX_BUFF[1];
                4'b1000 : UART1_TX_SERIAL <= UART1_TX_BUFF[0];												
                default : UART1_TX_SERIAL <= 1;
            endcase	    			    		
        end
    end
end
  
always @(posedge CLK_SYS or posedge RST) begin
    if (RST) begin
        TEST_BAUD_CNT            <= 0;
        TEST_UART_CNT            <= 0;
        TEST_UART_FRAME_CNT      <= 0;
        TEST_UART_FRAME_BYTE_CNT <= 0;
    end
    else begin// it's a posedge  of clk
        if (ret_test_en_r[1]) begin
            TEST_BAUD_CNT            <= 0;
            TEST_UART_CNT            <= 0;
            TEST_UART_FRAME_CNT      <= 0;
            TEST_UART_FRAME_BYTE_CNT <= 0;
        end 
        else if ((state == s1) || (state == s2)) begin// UART Framing State
            if (TEST_BAUD_CNT == 39) begin // 2.5MHz
                TEST_BAUD_CNT <= 0;
                if (TEST_UART_CNT == (256-1)) begin // 9.765625KHz
                    TEST_UART_CNT <= 0;
                    if (TEST_UART_FRAME_CNT == 15) begin// UART Frame 9bit : Start(1)+Data(8)+Stop(1)+wait(6)
                    	TEST_UART_FRAME_CNT      <= 0;
                    	TEST_UART_FRAME_BYTE_CNT <= TEST_UART_FRAME_BYTE_CNT + 1;
                    end
                    else begin
                        TEST_UART_FRAME_CNT <= TEST_UART_FRAME_CNT + 1;      					
                    end
                end 
                else begin
                    TEST_UART_CNT <= TEST_UART_CNT + 1;
                end
            end 
            else begin
                TEST_BAUD_CNT <= TEST_BAUD_CNT + 1;
            end
        end
    end
end
		  
always @(posedge CLK_SYS or posedge RST) begin
    if (RST) begin
        state <= s0;
    end
    else begin
        case(state)
            s0     : if (ret_test_en_r[1] == 1) begin
                         state <= s1;
                     end
                     else begin
                         state <= s0;
                     end
            s1     : state <= s2;
            s2     : if (RET_TEST_END == 1) begin 
                         state <= s3;
                     end
                     else begin
                         state <= s2;  	
                     end
            s3     : state <= s0; 
            default: state <= s0; 
        endcase
    end
end

reg [5:0] CLKOUT_BAUD_CNT;
reg [7:0] CLKOUT_UART_CNT;

always @(posedge CLK_SYS or posedge RST) begin
    if (RST) begin
        CLKOUT_BAUD_CNT <= 0;
        CLKOUT_UART_CNT <= 0;
    end 
    else begin
        if (CLKOUT_BAUD_CNT == 39) begin // 2.5MHz
            CLKOUT_BAUD_CNT <= 0;
            if (CLKOUT_UART_CNT == (256-1)) begin// 9.765625KHz
            //if (CLKOUT_UART_CNT == 77)  begin// 32KHz
                CLKOUT_UART_CNT  <= 0;
            end 
            else begin
                CLKOUT_UART_CNT <= CLKOUT_UART_CNT + 1;
            end
         end 
         else begin
             CLKOUT_BAUD_CNT <= CLKOUT_BAUD_CNT + 1;
         end 
    end
end
	
assign UART_CLK = CLKOUT_UART_CNT[5];

endmodule

