--======================================================================
--Title              :   Front LED Controller
--======================================================================

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

entity LEDCTRL2 is
port (  
   RESET       : in std_logic;
   NCLK        : in std_logic; -- 100MHz
   LEDSEL      : in std_logic_vector(3 downto 0);
   SOLID_RED_ON: in std_logic;

   RLED        : out std_logic;
   GLED        : out std_logic
);
end LEDCTRL2;

architecture arc_LEDCTRL2 of LEDCTRL2 is
   signal bcnt         : std_logic_vector(25 downto 0);
   signal onoff        : std_logic;
begin

   -- blink period
   -- LEDSEL(4) : 0=300ms, 1=150ms
   process(RESET,NCLK)
   begin
      if RESET='1' then
         bcnt  <= (others=>'0');
         onoff <= '1';
      elsif NCLK'event and NCLK='1' then
         bcnt  <= bcnt + 1;

         if LEDSEL(3)='1' then
            onoff <= bcnt(25); -- 335ms blink
         else
            onoff <= bcnt(24); -- 165ms blink
         end if;
      end if;
   end process;

   process(RESET,NCLK)
   begin 
      if RESET='1' then
         RLED  <= '1';
         GLED  <= '0';
      elsif NCLK'event and NCLK = '1' then
         if SOLID_RED_ON = '1' then
            RLED  <= '1';
            GLED  <= '0';
         elsif LEDSEL(2)='1' then -- blink
            RLED <= LEDSEL(0) and onoff;
            GLED <= LEDSEL(1) and onoff;
         else   -- solid 
            RLED <= LEDSEL(0);
            GLED <= LEDSEL(1);
         end if;
      end if;
   end process;        

end arc_LEDCTRL2;

--configuration CFG_LEDCTRL of LEDCTRL  is
--   for ARC_LEDCTRL
--   end for;
--end CFG_LEDCTRL;
