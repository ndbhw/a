library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

entity BFN_ADV is
port (
    RST                         : in  std_logic;
    CLK                         : in  std_logic;                                 --  8x(CLK_SYS) : 245.76 MHz
        
    ADV_VAL                     : in  std_logic_vector(21 downto 0);             -- advance value. resolution : 1 clock of 245.76MHz
    BFN_IN                      : in  std_logic;                                 -- 
    
    ADV_BFN                     : out std_logic
    );
end BFN_ADV;

architecture arc_BFN_ADV of BFN_ADV is

signal bf_ctrl_val              : std_logic_vector(15 downto 0);
signal bfn_sh                   : std_logic;
signal bfn_pls                  : std_logic;
signal bf_cnt                   : std_logic_vector(5 downto 0);
signal bf_num                   : std_logic_vector(15 downto 0);
signal int_adv_val              : std_logic_vector(21 downto 0);
signal r_pls_sh                 : std_logic_vector(62 downto 0);
signal r_pls                    : std_logic;
signal f_pls                    : std_logic;

begin

process(RST,CLK)
begin
   if RST = '1' then
      bfn_sh <= '0';
      bfn_pls <= '0';
   elsif rising_edge(CLK) then
      bfn_sh <= BFN_IN;
      bfn_pls <= BFN_IN and (not bfn_sh);
   end if;
end process;

process(RST,CLK)
begin
   if RST = '1' then
      bf_cnt <= (others => '1');
   elsif rising_edge(CLK) then
      if bfn_pls = '1' then
         bf_cnt <= (others => '1');
      else
         bf_cnt <= bf_cnt - '1';
      end if;
   end if;
end process;

process(RST,CLK)
begin
   if RST = '1' then
      bf_num <= "0100101011111111";  -- 38399/19199
   elsif rising_edge(CLK) then
      if bfn_pls = '1' then
         bf_num <= "0100101011111111";  -- 38399/19199
      else
         if bf_cnt = "000000" then
            if bf_num = "0000000000000000" then
               bf_num <= "0100101011111111";  -- 38399/19199
            else
               bf_num <= bf_num - '1';
            end if;
         end if;
      end if;
   end if;
end process;

process(RST,CLK)
begin
   if RST = '1' then
      int_adv_val <= "0100101011111111111100";  --2457596/1228796
      --int_fall_val <= (others => '0');
   elsif rising_edge(CLK) then
      if ADV_VAL > "0100101011111111111100" then  --2457596/1228796
         int_adv_val <= "0100101011111111111100";  --2457596/1228796
      else
         int_adv_val <= ADV_VAL + "11";
      end if;
      
      --int_fall_val <= int_adv_val - "100000";
   end if;
end process;

process(RST,CLK)
begin
   if RST = '1' then
      r_pls <= '0';
      r_pls_sh <= (others => '0');
      f_pls <= '0';
   elsif rising_edge(CLK) then
      if (bf_num = int_adv_val(21 downto 6)) and (bf_cnt = int_adv_val(5 downto 0)) then
         r_pls <= '1';
      else
         r_pls <= '0';
      end if;
      
      r_pls_sh <= r_pls_sh(61 downto 0) & r_pls;
   
      --if (bf_num = int_fall_val(21 downto 6)) and (bf_cnt = int_fall_val(5 downto 0)) then
      --if (bf_num = (int_adv_val(21 downto 6)-'1')) and (bf_cnt = int_adv_val(5 downto 0)) then
      f_pls <= r_pls_sh(62);
      --else
      --   f_pls <= '0';
      --end if;
   end if;
end process;

process(RST,CLK)
begin
   if RST = '1' then
      ADV_BFN <= '0';
   elsif rising_edge(CLK) then
      if r_pls = '1' then
         ADV_BFN <= '1';
      elsif f_pls = '1' then
         ADV_BFN <= '0';
      end if;
   end if;
end process;

end arc_BFN_ADV;
