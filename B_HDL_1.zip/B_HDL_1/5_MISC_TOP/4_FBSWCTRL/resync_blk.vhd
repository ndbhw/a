----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    14:22:08 10/10/2013 
-- Design Name: 
-- Module Name:    resync_blk - resync_blk_arc 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library ieee;

use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
use work.RU_FPGA_FNC.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity resync_blk is
generic (
        RISING_EDGE_RESYNC              : boolean := true; --false : falling edge resync
     -- Default latency is : 4 + RESYNC_LATENCY  CLK
        RESYNC_LATENCY                  : natural := 1 ;
        RESYNC_PULSE_WIDTH              : natural := 1  -- min. width 1
        );
port(
    RST                                 : in std_logic;
    CLK                                 : in std_logic;
    SIGNAL_IN                           : in std_logic;
    RESYNC_OUT                          : out std_logic  
);    
end resync_blk;

architecture resync_blk_arc of resync_blk is

signal edge_select                      : std_logic;
signal signal_sft                       : std_logic_vector(RESYNC_LATENCY + 1 downto 0);
signal resync_pulse                     : std_logic;
--signal resync_width                     : std_logic_vector(RESYNC_PULSE_WIDTH downto 0);
signal resync_rt                        : std_logic_vector(RESYNC_PULSE_WIDTH + 1 downto 0);
signal resync_or                        : std_logic_vector(RESYNC_PULSE_WIDTH + 1 downto 0);

begin

ri_edge :    if RISING_EDGE_RESYNC = true generate
        edge_select <= SIGNAL_IN ;
    end generate; 

fa_edge :    
    if RISING_EDGE_RESYNC = false generate
        edge_select <= not SIGNAL_IN ;
    end generate; 
    
generate_1clock_pulse : process(RST,CLK)
begin
    if RST='1' then
        signal_sft    <= (others =>'0'); 
        resync_pulse  <= '0'; 
    elsif CLK'event and CLK='1' then
        signal_sft    <= signal_sft(RESYNC_LATENCY  downto 0) & edge_select;    
            if signal_sft(RESYNC_LATENCY) = '1' and signal_sft(RESYNC_LATENCY + 1 ) = '0' then
                resync_pulse <= '1' ;
            else
                resync_pulse <= '0';
            end if;
        --resync_pulse  <= signal_sft(RESYNC_LATENCY) and (not signal_sft(RESYNC_LATENCY + 1 ));
     end if;
end process;


--resync : for i in RESYNC_PULSE_WIDTH downto 0 generate 
    process(RST,CLK)
    begin
        if RST='1' then
            resync_rt  <= (others =>'0');
        elsif CLK'event and CLK='1' then
            resync_rt(RESYNC_PULSE_WIDTH downto 0)  <= resync_rt(RESYNC_PULSE_WIDTH-1 downto 0) & resync_pulse ; 
        end if;
    end process;
--end generate ;

   process(RST,CLK)
    begin
        if RST='1' then
            RESYNC_OUT    <= '0';
        elsif CLK'event and CLK='1' then
            if  resync_rt(RESYNC_PULSE_WIDTH-1 downto 0) /= 0 then
                RESYNC_OUT <= '1';
            else
                RESYNC_OUT <= '0';
            end if;
        end if;
    end process;

end resync_blk_arc;

