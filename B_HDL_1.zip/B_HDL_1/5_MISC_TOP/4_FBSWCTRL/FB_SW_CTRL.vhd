-- Module Name:    fb_sw_ctrl - Behavioral
-- Project Name:   softbank rf2239

-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
----------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

-----------------------------
-- FB_SW_CNT_245P76M
-- X"0" : FWD A
-- X"1" : RVS A
-- X"2" : DPD SC
-- X"3" : FWD B
-- X"4" : RVS B
-- X"5" : DPD SC
-- X"6" : Calibration
-----------------------------

ENTITY FB_SW_CTRL IS
    PORT (
        RESET_122P88M                           : in  std_logic;
        RESET_245P76M                           : in  std_logic;
        RESET_307P2M                            : in  std_logic;

        CLK_122P88M                             : in  std_logic;
        CLK_245P76M                             : in  std_logic;
        CLK_307P2M                              : in  std_logic;
        
        RX_BFN_STROBE                           : in  std_logic;                            -- BFN signal from CPRI(or..)(1 basic frame advanced signal), synchronized 122.88MHz clock, pulse width 3.84MHz
        
        -- TEST MODE
        SW_MANUAL_SET                           : in  std_logic;                            -- '1' : manual operation by user, '0' : normal operation
        SW_MANUAL_VALUE                         : in  std_logic_vector(6 downto 0);
        MANUAL_FB_SW_CTRL_VALUE                 : in  std_logic_vector(2 downto 0);
        MANUAL_RFIC_ORX_TRIGGER                 : in  std_logic; 
        MANUAL_RFIC_ORX_MODE                    : in  std_logic_vector(2 downto 0);
        
        -- FW MODE
        FB_SW_MODE                              : in  std_logic_vector(1 downto 0);

        TX_A_SW                                 : in  std_logic;
        TX_B_SW                                 : in  std_logic;

        -- OUTPUT
        AUTO_MODE_DONE                          : out std_logic;

        AMP_FBSW_PATH_SEL                       : out std_logic;
        AMP_FBSW_EN_0                           : out std_logic;
        AMP_FBSW_EN_1                           : out std_logic;
        AMP_FBSW_FB_REV_SEL                     : out std_logic;

        RFIC_ORX_TRIGGER                        : out std_logic;
        FPGA_TXOBS_SELECT                       : in  std_logic;
        RFIC_ORXMODE_0                          : out std_logic;
        RFIC_ORXMODE_1                          : out std_logic;
        RFIC_ORXMODE_2                          : out std_logic;
        
        DPA_PATH_EN                             : in std_logic_vector(2-1 downto 0);        -- FOR 2ANT

        -- new port
        UV_ALM_IN                               : in  std_logic;
        SSB_OFFSET                              : in  std_logic_vector(3 downto 0);
        ADV_SFN_MOD                             : in  std_logic_vector(3 downto 0);
        ADV_SFN_STRB                            : in  std_logic;
        SSB_IND_FLAG                            : out std_logic;
        RESYNC_STATUS_REG_OUT                   : out std_logic_vector(31 downto 0);

        FB_SW_MEASURE_DONE                      : out std_logic;                            -- tick per every 10ms.
        FB_SW_START_TRIG                        : out std_logic;
        FB_SW_CNT_245P76M                       : out std_logic_vector(5 downto 0);         -- 10ms period cnt by 245.76MHz cdc
        FB_SW_CNT_307P2M                        : out std_logic_vector(5 downto 0);         -- 10ms period cnt by 307.2MHz cdc

        DPD_SC_PATH_SEL_IN                      : in  std_logic_vector(3 downto 0)
    );
END FB_SW_CTRL;

ARCHITECTURE FB_SW_CTRL_ARC of FB_SW_CTRL IS

    component RESYNC_BLK
        generic (
                RISING_EDGE_RESYNC              : boolean := true; --false : falling edge resync
            -- Default latency is : 4 + RESYNC_LATENCY  CLK
                RESYNC_LATENCY                  : natural := 1 ;
                RESYNC_PULSE_WIDTH              : natural := 1
                );
        port(
            RST                                 : in std_logic;
            CLK                                 : in std_logic;
            SIGNAL_IN                           : in std_logic;
            RESYNC_OUT                          : out std_logic
        );
    end component;

    component BFN_ADV
        port (
            RST                             : in  std_logic;
            CLK                             : in  std_logic;

            ADV_VAL                         : in  std_logic_vector(21 downto 0);
            BFN_IN                          : in  std_logic;
            
            ADV_BFN                         : out std_logic
        );
    end component;

    signal fb_sw_mode_d                         : std_logic_vector(1 downto 0);
    signal sync_ref_10ms_245p76m_1clk           : std_logic;
    signal sync_ref_10ms_122p88m_1clk           : std_logic;
    signal sync_ref_10ms_307p2m_1clk            : std_logic;

    signal rx_bfn_strobe_sft                    : std_logic_vector(2 downto 0);
    signal bfn_pre_en_sft                       : std_logic_vector(3 downto 0);
    signal bfn_cnt                              : std_logic_vector(20 downto 0);
 
    signal i_fb_sw_counter_122p88               : std_logic_vector(8-1 downto 0);
 
    signal rfic_tx_obs_select_d                 : std_logic_vector(1 downto 0);
 
    signal cal_mode_period_cnt                  : std_logic_vector(8-1 downto 0);
    signal count_3                              : std_logic_vector(2-1 downto 0);
 
    signal rfic_trig                            : std_logic;
 
    signal i_tx_a_sw_dly                        : std_logic_vector(1 downto 0);
    signal i_tx_b_sw_dly                        : std_logic_vector(1 downto 0);
    signal i_fb_sw_mode                         : std_logic_vector(1 downto 0);
    signal i_tx_ab_ss_onoff                     : std_logic;
    signal i_tx_ab_ss_onoff_dly                 : std_logic_vector(1 downto 0);
    signal tx_ab_ss_ri_detect                   : std_logic;
    signal tx_ab_ss_ri_cnt                      : std_logic_vector(8 downto 0);
    signal tx_ab_ss_fa_detect                   : std_logic;
    signal tx_ab_ss_fa_cnt                      : std_logic_vector(8 downto 0);
    signal tx_ab_ss_trig                        : std_logic;
 
    signal priority_ab_ss_trig                  : std_logic;
 
    signal cal_mode_start_en_dly                : std_logic_vector(15 downto 0);
    signal cal_mode_start_en                    : std_logic;
 
    signal i_adv_sfn_mod                        : std_logic_vector(3 downto 0);
    signal i_ssb_offset                         : std_logic_vector(3 downto 0);
 
    signal ssb_exist                            : std_logic;
 
    signal sfn_strb_adv                         : std_logic;
    signal adv_sfn_sbrb_sht                     : std_logic_vector(2 downto 0);
 
    signal align_resync_cnt                     : std_logic_vector(3 downto 0) := (others=>'0');
    signal resync_stataus                       : std_logic_vector(31 downto 0);

    signal dpd_sc_path_sel_in_d                 : std_logic_vector(3 downto 0);
    signal dpd_path_sel                         : std_logic_vector(2-1 downto 0);
    signal fb_sw_cnt                            : std_logic_vector(4-1 downto 0);
    signal fb_sw_cnt_d                          : std_logic_vector(4-1 downto 0);

    signal fb_sw_measure_done_d                 : std_logic; 
    signal check_flag                           : std_logic;
    signal done                                 : std_logic;

    signal amp_fbsw_path_sel_d                  : std_logic;
    signal amp_fbsw_fb_rev_sel_d                : std_logic;

    signal uv_alm_d                             : std_logic;
    signal uv_alarm_1usec_flag                  : std_logic;
    signal cnt_100usec                          : std_logic_vector(16-1 downto 0);

    signal i_dpa_path_en                        : std_logic_vector(2-1 downto 0);
    signal cal_rfic_trig                        : std_logic;
    signal cal_rfic_cnt                         : std_logic_vector(9-1 downto 0);

    signal rfic_orxmode_0_d                     : std_logic;
    signal rfic_orxmode_1_d                     : std_logic;
    signal rfic_orxmode_1_d_1d                  : std_logic;

BEGIN

	process(CLK_122P88M)
    begin
        if (CLK_122P88M'event and CLK_122P88M = '1') then
            resync_stataus              <=  uv_alarm_1usec_flag & b"00" & X"00" & ssb_exist & i_ssb_offset & i_adv_sfn_mod & align_resync_cnt & i_fb_sw_counter_122p88;
        end if;
    end process;

	sfn_strb_adv_pwr_masking :  BFN_ADV port map (RESET_122P88M,CLK_122p88M,conv_std_logic_vector(1230,22),ADV_SFN_STRB,sfn_strb_adv);

    process(CLK_122P88M)
    begin
        if (CLK_122P88M'event and CLK_122P88M = '1') then
            fb_sw_mode_d                <=  FB_SW_MODE;
            adv_sfn_sbrb_sht            <=  adv_sfn_sbrb_sht(1 downto 0) & sfn_strb_adv;
            i_dpa_path_en               <=  DPA_PATH_EN;

            if (adv_sfn_sbrb_sht(2 downto 1) = b"01") then
                i_adv_sfn_mod           <=  ADV_SFN_MOD;
                i_ssb_offset            <=  SSB_OFFSET;
            end if;
        end if;
    end process;

    process(CLK_122P88M)
    begin
        if (CLK_122P88M'event and CLK_122P88M = '1') then
            dpd_sc_path_sel_in_d        <=  DPD_SC_PATH_SEL_IN;
            case (dpd_sc_path_sel_in_d) is
                when X"0"    =>  dpd_path_sel       <=  b"00";           -- FWD A
                when X"1"    =>  dpd_path_sel       <=  b"10";           -- RVS A
                when X"2"    =>  dpd_path_sel       <=  b"01";           -- FWD B
                when X"3"    =>  dpd_path_sel       <=  b"11";           -- RVS B
                when others  =>  dpd_path_sel       <=  b"00";
            end case;
        end if;
    end process;

    -- fix ssb 160msec
    process(CLK_122P88M)
    begin
        if (CLK_122P88M'event and CLK_122P88M = '1') then
            if (i_adv_sfn_mod(1 downto 0) = (i_ssb_offset(1 downto 0) - '1')) then
            -- if (i_adv_sfn_mod(3 downto 0) = (i_ssb_offset - '1')) then
                ssb_exist               <=  '1';
            else
                ssb_exist               <=  '0';
            end if;
        end if;
    end process;

    RESYNC_STATUS_REG_OUT               <=  resync_stataus;
    SSB_IND_FLAG                        <=  ssb_exist;
    AUTO_MODE_DONE                      <=  done;

------------------------------- AB path signal suspension detect and process----------------------
    process(RESET_122P88M, CLK_122P88M)
    begin 
        if (RESET_122P88M = '1') then 
            i_tx_a_sw_dly               <=  (others => '0');
            i_tx_b_sw_dly               <=  (others => '0');
            
            i_fb_sw_mode                <=  (others => '0');
            
            i_tx_ab_ss_onoff            <=  '0';
            i_tx_ab_ss_onoff_dly        <=  (others => '0');
            
            tx_ab_ss_ri_detect          <=  '0';
            tx_ab_ss_ri_cnt             <=  (others => '0');
            
            tx_ab_ss_fa_detect          <=  '0';
            tx_ab_ss_fa_cnt             <=  (others => '0');
            
            tx_ab_ss_trig               <=  '0';
            priority_ab_ss_trig         <=  '0';
        elsif (CLK_122P88M'event and CLK_122P88M = '1') then 
            i_tx_a_sw_dly               <=  i_tx_a_sw_dly(0) & TX_A_SW;
            i_tx_b_sw_dly               <=  i_tx_b_sw_dly(0) & TX_B_SW;
            
            if (( i_tx_a_sw_dly(1) = '0' or i_tx_b_sw_dly(1) = '0') and fb_sw_mode_d /= b"01") then
                i_fb_sw_mode            <=  b"00";
                i_tx_ab_ss_onoff        <=  '1';
            else
                i_fb_sw_mode            <=  fb_sw_mode_d;
                i_tx_ab_ss_onoff        <=  '0';
            end if;           

            i_tx_ab_ss_onoff_dly        <=  i_tx_ab_ss_onoff_dly(0) & i_tx_ab_ss_onoff;

            ---------------------------------------------------------- case TX SW ON detect & ORX TRIG 3us count
            if (i_tx_ab_ss_onoff_dly(1 downto 0) = b"01") then
                tx_ab_ss_ri_detect      <=  '1';
                tx_ab_ss_ri_cnt         <=  (others => '0');   --512  * 8.138
            else 
                tx_ab_ss_ri_detect      <=  '0';
                
                if (tx_ab_ss_ri_cnt = conv_std_logic_vector(511,9)) then
                    tx_ab_ss_ri_cnt     <=  tx_ab_ss_ri_cnt;
                else
                    tx_ab_ss_ri_cnt     <=  tx_ab_ss_ri_cnt + '1';
                end if;
            end if;

            ---------------------------------------------------------- case TX SW OFF detect & ORX TRIG 3us count
            if (i_tx_ab_ss_onoff_dly(1 downto 0) = b"10") then 
                tx_ab_ss_fa_detect      <=  '1';
                tx_ab_ss_fa_cnt         <=  (others => '0');   --512  * 8.138
            else
                tx_ab_ss_fa_detect      <=  '0';

                if (tx_ab_ss_fa_cnt = 511) then 
                    tx_ab_ss_fa_cnt     <=  tx_ab_ss_fa_cnt;
                else
                    tx_ab_ss_fa_cnt     <=  tx_ab_ss_fa_cnt + 1;
                end if;
            end if;

            ---------------------------------------------------------- suspension signal priority & design ORX TRIG setup/hold
            if (tx_ab_ss_ri_cnt = 0 or tx_ab_ss_fa_cnt = 0) then
                tx_ab_ss_trig           <=  '0';
                priority_ab_ss_trig     <=  '1';
            elsif ((tx_ab_ss_ri_cnt = conv_std_logic_vector(123,9)) or tx_ab_ss_fa_cnt = 123) then
                tx_ab_ss_trig           <=  '1';
                priority_ab_ss_trig     <=  '1';
            elsif ((tx_ab_ss_ri_cnt = conv_std_logic_vector(369,9)) or tx_ab_ss_fa_cnt = 369) then
                tx_ab_ss_trig           <=  '0';
                priority_ab_ss_trig     <=  '0';
            else 
                tx_ab_ss_trig           <=  tx_ab_ss_trig;
                priority_ab_ss_trig     <=  priority_ab_ss_trig;
            end if;
            
        end if;
    end process;

    process(RESET_122P88M,CLK_122P88M)
    begin
        if (RESET_122P88M = '1') then
            rfic_tx_obs_select_d        <=  (others => '0');
            
            done                        <=  '1';

            amp_fbsw_path_sel_d         <=  '0';
            AMP_FBSW_EN_0               <=  '1';
            AMP_FBSW_EN_1               <=  '1';
            amp_fbsw_fb_rev_sel_d       <=  '0';

            RFIC_ORX_TRIGGER            <=  '0';
            rfic_orxmode_0_d            <=  '0';
            rfic_orxmode_1_d            <=  '0';
            RFIC_ORXMODE_2              <=  '0';

        elsif (CLK_122P88M'event and CLK_122P88M = '1') then
            rfic_tx_obs_select_d        <=  rfic_tx_obs_select_d(0) & FPGA_TXOBS_SELECT;

            AMP_FBSW_EN_0               <=  '0';
            AMP_FBSW_EN_1               <=  '0';
            RFIC_ORXMODE_2              <=  '0';

            if (SW_MANUAL_SET = '1') then
                amp_fbsw_fb_rev_sel_d   <=  MANUAL_FB_SW_CTRL_VALUE(1);
                amp_fbsw_path_sel_d     <=  MANUAL_FB_SW_CTRL_VALUE(0);
                
                done                    <=  '1';

                RFIC_ORX_TRIGGER        <=  MANUAL_RFIC_ORX_TRIGGER;
                rfic_orxmode_0_d        <=  MANUAL_RFIC_ORX_MODE(0);
                rfic_orxmode_1_d        <=  MANUAL_RFIC_ORX_MODE(1);
            else
                case i_fb_sw_mode is
                     -- AUTO_MODE
                     when "00"   => rfic_orxmode_0_d                    <=  '1';
                                    rfic_orxmode_1_d                    <=  '0';

                                    if (cal_mode_period_cnt = 0) then
                                        if (priority_ab_ss_trig = '1') then 
                                            RFIC_ORX_TRIGGER            <=  tx_ab_ss_trig;
                                        else
                                            RFIC_ORX_TRIGGER            <=  rfic_trig; 
                                        end if;
                                    else
                                        RFIC_ORX_TRIGGER                <=  tx_ab_ss_trig;
                                    end if;

                                    if (cal_mode_period_cnt(6 downto 4) = 0) then               -- < 16, FWD A
                                        amp_fbsw_fb_rev_sel_d           <=  '0';
                                        amp_fbsw_path_sel_d             <=  '0';

                                        done                            <=  '0';
                                    elsif (cal_mode_period_cnt(6 downto 4) = b"001") then       -- < 32, REV A
                                        amp_fbsw_fb_rev_sel_d           <=  '1';
                                        amp_fbsw_path_sel_d             <=  '0';

                                        done                            <=  '0';
                                    elsif (cal_mode_period_cnt(6 downto 4) = b"010") then       -- < 48, DPD
                                        amp_fbsw_fb_rev_sel_d           <=  dpd_path_sel(1);
                                        amp_fbsw_path_sel_d             <=  dpd_path_sel(0);

                                        done                            <=  '1';
                                    elsif (cal_mode_period_cnt(6 downto 4) = b"011") then       -- < 64, FWD B
                                        amp_fbsw_fb_rev_sel_d           <=  '0';
                                        amp_fbsw_path_sel_d             <=  '1';

                                        done                            <=  '0';
                                    elsif (cal_mode_period_cnt(6 downto 4) = b"100") then       -- < 80, REV B
                                        amp_fbsw_fb_rev_sel_d           <=  '1';
                                        amp_fbsw_path_sel_d             <=  '1';
                                        
                                        done                            <=  '0';
                                    else                                                        -- < 96, DPD
                                        amp_fbsw_fb_rev_sel_d           <=  dpd_path_sel(1);
                                        amp_fbsw_path_sel_d             <=  dpd_path_sel(0);

                                        done                            <=  '1';
                                    end if;

                     -- Mykonos Tracking calibration mode
                     when "01"   => done                                <=  '1';
                                    RFIC_ORX_TRIGGER                    <=  '0';
                                    rfic_orxmode_0_d                    <=  '0';
                                    rfic_orxmode_1_d                    <=  '0';

                                    if (rfic_tx_obs_select_d(1) = '0') then                     -- FWD A
                                        amp_fbsw_fb_rev_sel_d           <=  '0';
                                        amp_fbsw_path_sel_d             <=  '0';
                                    else                                                        -- FWD B
                                        amp_fbsw_fb_rev_sel_d           <=  '0';
                                        amp_fbsw_path_sel_d             <=  '1';
                                    end if;

                     -- Mykonos Tracking calibration mode
                     when "10"   => if (priority_ab_ss_trig = '1') then 
                                        RFIC_ORX_TRIGGER                <=  tx_ab_ss_trig;
                                    elsif (count_3 = 0) then
                                        RFIC_ORX_TRIGGER                <=  cal_rfic_trig;
                                    elsif (cal_mode_period_cnt = 0) then
                                        RFIC_ORX_TRIGGER                <=  rfic_trig;
                                    else
                                        RFIC_ORX_TRIGGER                <=  '0';
                                    end if;
                                    
                                    rfic_orxmode_0_d                    <=  '1';

                                    if (count_3 = 0) then                                       -- tracking calibration preriod
                                        done                            <=  '1';
                                        if (rfic_tx_obs_select_d(1) = '0') then                 -- FWD A
                                            amp_fbsw_fb_rev_sel_d       <=  '0';
                                            amp_fbsw_path_sel_d         <=  '0';
                                            if (i_dpa_path_en(0) = '1') then
                                                rfic_orxmode_1_d        <=  '1';
                                            else
                                                rfic_orxmode_1_d        <=  '0';
                                            end if;
                                        else                                                    -- FWD B
                                            amp_fbsw_fb_rev_sel_d       <=  '0';
                                            amp_fbsw_path_sel_d         <=  '1';
                                            if (i_dpa_path_en(1) = '1') then
                                                rfic_orxmode_1_d        <=  '1';
                                            else
                                                rfic_orxmode_1_d        <=  '0';
                                            end if;
                                        end if;
                                    else
                                        rfic_orxmode_1_d                <=  '0';
                                        if (cal_mode_period_cnt(6 downto 4) = 0) then           -- < 16, FWD A
                                            amp_fbsw_fb_rev_sel_d       <=  '0';
                                            amp_fbsw_path_sel_d         <=  '0';

                                            done                        <=  '0';
                                        elsif (cal_mode_period_cnt(6 downto 4) = b"001") then   -- < 32, REV A
                                            amp_fbsw_fb_rev_sel_d       <=  '1';
                                            amp_fbsw_path_sel_d         <=  '0';
                                        
                                            done                        <=  '0';
                                        elsif (cal_mode_period_cnt(6 downto 4) = b"010") then   -- < 48, DPD
                                            amp_fbsw_fb_rev_sel_d       <=  dpd_path_sel(1);
                                            amp_fbsw_path_sel_d         <=  dpd_path_sel(0);

                                            done                        <=  '1';
                                        elsif (cal_mode_period_cnt(6 downto 4) = b"011") then   -- < 64, FWD B
                                            amp_fbsw_fb_rev_sel_d       <=  '0';
                                            amp_fbsw_path_sel_d         <=  '1';

                                            done                        <=  '0';
                                        elsif (cal_mode_period_cnt(6 downto 4) = b"100") then   -- < 80, REV B
                                            amp_fbsw_fb_rev_sel_d       <=  '1';
                                            amp_fbsw_path_sel_d         <=  '1';

                                            done                        <=  '0';
                                        else                                                    -- < 96, DPD
                                            amp_fbsw_fb_rev_sel_d       <=  dpd_path_sel(1);
                                            amp_fbsw_path_sel_d         <=  dpd_path_sel(0);

                                            done                        <=  '1';
                                        end if;
                                    end if;

                     when others => done                                <=  '1';
                                    amp_fbsw_fb_rev_sel_d               <=  '0';
                                    amp_fbsw_path_sel_d                 <=  '0';
                                    
                                    RFIC_ORX_TRIGGER                    <=  '0';
                                    rfic_orxmode_0_d                    <=  '0';
                                    rfic_orxmode_1_d                    <=  '0';
                end case;
            end if;
        end if;
    end process;

    process(RESET_122P88M, CLK_122P88M)
    begin
        if (RESET_122P88M = '1') then
            fb_sw_cnt               <=  (others=>'1');
            fb_sw_cnt_d             <=  (others=>'1');
        elsif (rising_edge(CLK_122P88M)) then
            fb_sw_cnt_d             <=  fb_sw_cnt;

            if (i_fb_sw_mode = b"10" and count_3 = 0) then
                fb_sw_cnt               <=  X"6";                       -- calibration
            else
                if (cal_mode_period_cnt(6 downto 4) = 0) then           -- < 16, FWD A
                    fb_sw_cnt           <=  X"0";
                elsif (cal_mode_period_cnt(6 downto 4) = b"001") then   -- < 32, REV A
                    fb_sw_cnt           <=  X"1";
                elsif (cal_mode_period_cnt(6 downto 4) = b"010") then   -- < 48, DPD
                    fb_sw_cnt           <=  X"2";
                elsif (cal_mode_period_cnt(6 downto 4) = b"011") then   -- < 64, FWD B
                    fb_sw_cnt           <=  X"3";
                elsif (cal_mode_period_cnt(6 downto 4) = b"100") then   -- < 80, REV B
                    fb_sw_cnt           <=  X"4";
                else                                                    -- < 96, DPD
                    fb_sw_cnt           <=  X"5";
                end if;
            end if;
        end if;
    end process;

    ------------------------------------------------------------------------------------------------ KTY 140701

    process(RESET_122P88M, CLK_122P88M)
    begin
        if (RESET_122P88M = '1') then
            rx_bfn_strobe_sft               <=  (others => '0');
        elsif (CLK_122P88M'event and CLK_122P88M = '1') then
            rx_bfn_strobe_sft               <=  rx_bfn_strobe_sft(1 downto 0) & RX_BFN_STROBE;
        end if;
    end process;

    process(RESET_122P88M,CLK_122P88M)
    begin
        if (RESET_122P88M = '1') then
            bfn_cnt                         <=  (others =>'0');
        elsif (CLK_122P88M'event and CLK_122P88M = '1') then
            if ((rx_bfn_strobe_sft(1) = '1' and rx_bfn_strobe_sft(2) = '0') or (bfn_cnt = conv_std_logic_vector(1228799,21))) then
                bfn_cnt                     <=  (others =>'0');
            else
                bfn_cnt                     <=  bfn_cnt + '1';
            end if;
        end if;
    end process;

    process(RESET_122P88M,CLK_122P88M)
    begin
        if (RESET_122P88M = '1') then
            bfn_pre_en_sft                  <=  (others =>'0');
            rfic_trig                       <=  '0';
        elsif (CLK_122P88M'event and CLK_122P88M = '1') then
            if (bfn_cnt > conv_std_logic_vector(1228780,21)) then
                bfn_pre_en_sft              <=  bfn_pre_en_sft(2 downto 0) & '1';
            else
                bfn_pre_en_sft              <=  bfn_pre_en_sft(2 downto 0) & '0';
            end if;

            if (bfn_cnt = conv_std_logic_vector(200,21)) then
                rfic_trig                   <=  '1';
            elsif (bfn_cnt = conv_std_logic_vector(692,21)) then
                rfic_trig                   <=  '0';
            else
                rfic_trig                   <=  rfic_trig;
            end if;
        end if;
    end process;

    process(RESET_122P88M,CLK_122P88M)
    begin
        if (RESET_122P88M = '1') then
            cal_rfic_cnt                    <=  (others=>'0');
            cal_rfic_trig                   <=  '0';
        elsif (CLK_122P88M'event and CLK_122P88M = '1') then
            rfic_orxmode_1_d_1d             <=  rfic_orxmode_1_d;
            if (cal_rfic_trig = '0') then
                cal_rfic_cnt                <=  (others=>'0');
            else
                cal_rfic_cnt                <=  cal_rfic_cnt + '1';
            end if;

            if (rfic_orxmode_1_d_1d /= rfic_orxmode_1_d) then
                cal_rfic_trig               <=  '1';
            elsif (cal_rfic_cnt = conv_std_logic_vector(491,9)) then
                cal_rfic_trig               <=  '0';
            else
                cal_rfic_trig               <=  cal_rfic_trig;
            end if;
        end if;
    end process;

    process(RESET_122P88M,CLK_122P88M)
    begin
        if (RESET_122P88M = '1') then
            cal_mode_period_cnt             <=  (others=>'1');
            count_3                         <=  (others=>'0');
            align_resync_cnt                <=  (others=>'0');
        elsif (CLK_122P88M'event and CLK_122P88M = '1') then
            if (SW_MANUAL_SET = '1') then
                cal_mode_period_cnt         <=  '0' & SW_MANUAL_VALUE;
            elsif (fb_sw_mode_d = b"01") then
                cal_mode_period_cnt         <=  (others => '1');
            elsif ((bfn_pre_en_sft(1 downto 0) =  b"01") and cal_mode_period_cnt = conv_std_logic_vector(96-1,8)) then
                cal_mode_period_cnt         <= (others => '0');
                if (count_3(1) = '1') then
                    count_3                 <=  (others=>'0');
                else
                    count_3                 <=  count_3 + '1';
                end if;
            elsif ((bfn_pre_en_sft(1 downto 0) =  b"01") and (ssb_exist = '1' and (cal_mode_period_cnt(1 downto 0) /= i_ssb_offset(1 downto 0) - '1'))) then
                cal_mode_period_cnt         <=  b"00" & X"0" & i_ssb_offset(1 downto 0);
            -- elsif ((bfn_pre_en_sft(1 downto 0) =  b"01") and (ssb_exist = '1' and (cal_mode_period_cnt(3 downto 0) /= i_ssb_offset - '1'))) then
            --     cal_mode_period_cnt         <=  X"0" & i_ssb_offset;
                align_resync_cnt            <=  align_resync_cnt + '1';
            elsif (bfn_pre_en_sft(1 downto 0) =  b"01") then
                cal_mode_period_cnt         <=  cal_mode_period_cnt + '1';
            else
                cal_mode_period_cnt         <=  cal_mode_period_cnt;
            end if;
        end if;
    end process;

    process(RESET_122P88M,CLK_122P88M)
    begin
        if (RESET_122P88M = '1') then
            cal_mode_start_en               <=  '0';
        elsif (CLK_122P88M'event and CLK_122P88M = '1') then
            if (cal_mode_period_cnt = 0) then
                cal_mode_start_en           <=  '1';
            else
                cal_mode_start_en           <=  '0';
            end if;
        end if;
    end process;
            
    ------------------------------- modify dsp clock------------------------------------
      process (RESET_245P76M,CLK_245P76M)
      begin
        if (RESET_245P76M = '1') then
            cal_mode_start_en_dly           <=  (others => '0');
            FB_SW_START_TRIG                <=  '0';
        elsif (CLK_245P76M'event and CLK_245P76M = '1') then
            cal_mode_start_en_dly           <=  cal_mode_start_en_dly(14 downto 0) & cal_mode_start_en;
            
            if (cal_mode_start_en_dly(12) = '1' and cal_mode_start_en_dly(15) = '0' ) then
                FB_SW_START_TRIG            <=  '1';
            else
                FB_SW_START_TRIG            <=  '0';
            end if;
        end if;
    end process;
    ------------------------------------------------------------------------------------------------ KTY 140701

    process(RESET_122P88M,CLK_122P88M)
    begin
        if (RESET_122P88M = '1') then
            fb_sw_measure_done_d              <=  '0';
        elsif (CLK_122P88M'event and CLK_122P88M = '1') then
            if (bfn_cnt(20 downto 2) = b"0000000110000110101") then    -- modify 20170317 jinoo.bae 
                fb_sw_measure_done_d          <=  '1';
            else
                fb_sw_measure_done_d          <=  '0';
            end if;
        end if;
    end process;

    process(RESET_122P88M,CLK_122P88M)
    begin
        if (RESET_122P88M = '1') then
            check_flag                        <=  '0';
            FB_SW_MEASURE_DONE                <=  '0';
        elsif (CLK_122P88M'event and CLK_122P88M = '1') then
            if (fb_sw_cnt_d /= fb_sw_cnt) then
                check_flag                    <=  '1';
                FB_SW_MEASURE_DONE            <=  '0';
            elsif (check_flag = '1' and fb_sw_measure_done_d = '1' and ssb_exist = '1') then
                check_flag                    <=  '0';
                FB_SW_MEASURE_DONE            <=  '1';
            else
                check_flag                    <=  check_flag;
                FB_SW_MEASURE_DONE            <=  '0';
            end if;
        end if;
    end process;

	latch_10m_122_for_user : RESYNC_BLK generic map (true, 1,1) port map (RESET_122P88M,CLK_122P88M,bfn_pre_en_sft(1),sync_ref_10ms_122p88m_1clk);
    latch_10m_245_for_user : RESYNC_BLK generic map (true, 6,1) port map (RESET_245P76M,CLK_245P76M,bfn_pre_en_sft(1),sync_ref_10ms_245p76m_1clk);
    latch_10m_307_for_user : RESYNC_BLK generic map (true, 6,1) port map (RESET_307P2M,CLK_307P2M,bfn_pre_en_sft(1),sync_ref_10ms_307p2m_1clk);
   
    process (RESET_245P76M,CLK_245P76M)
    begin
        if (RESET_245P76M = '1') then
            FB_SW_CNT_245P76M               <=  (others =>'0');
        elsif (CLK_245P76M'event and CLK_245P76M = '1') then
            if (sync_ref_10ms_245p76m_1clk = '1') then
                FB_SW_CNT_245P76M           <=  b"00" & fb_sw_cnt;
            end if;
        end if;
    end process;
    
    process (RESET_122P88M,CLK_122P88M)
    begin
        if (RESET_122P88M = '1') then
            i_fb_sw_counter_122p88          <=  (others =>'0');
        elsif (CLK_122P88M'event and CLK_122P88M = '1') then
            if (sync_ref_10ms_122p88m_1clk = '1') then
                i_fb_sw_counter_122p88      <=  X"0" & fb_sw_cnt;
            end if;
        end if;
    end process;

    process (RESET_307P2M,CLK_307P2M)
    begin
        if (RESET_307P2M = '1') then
            FB_SW_CNT_307P2M               <=  (others =>'0');
        elsif (CLK_307P2M'event and CLK_307P2M = '1') then
            if (sync_ref_10ms_307p2m_1clk = '1') then
                FB_SW_CNT_307P2M           <=  b"00" & fb_sw_cnt;
            end if;
        end if;
    end process;

    -------------------------------------------------------------------------------------------
    process(RESET_122P88M,CLK_122P88M)
    begin
        if (RESET_122P88M = '1') then
            cnt_100usec                     <=  (others=>'0');
            uv_alarm_1usec_flag             <=  '0';
        elsif (rising_edge(CLK_122P88M)) then
            uv_alm_d                        <=  UV_ALM_IN;

            if (uv_alm_d = '0' and cnt_100usec = conv_std_logic_vector(12288-1,16)) then  -- 100 usec
                cnt_100usec                 <=  cnt_100usec;
                uv_alarm_1usec_flag         <=  '1';
            elsif (uv_alm_d = '0') then
                cnt_100usec                 <=  cnt_100usec + '1';
                uv_alarm_1usec_flag         <=  uv_alarm_1usec_flag;
            else
                cnt_100usec                 <=  (others=>'0');
                uv_alarm_1usec_flag         <=  uv_alarm_1usec_flag;
            end if;
        end if;
    end process;

    process(RESET_122P88M, CLK_122P88M)
    begin
        if (RESET_122P88M = '1') then
            AMP_FBSW_PATH_SEL               <=  '0';
            AMP_FBSW_FB_REV_SEL             <=  '0';

            RFIC_ORXMODE_0                  <=  '0';
            RFIC_ORXMODE_1                  <=  '0';
        elsif (rising_edge(CLK_122P88M)) then
            if (uv_alarm_1usec_flag = '1') then
                AMP_FBSW_PATH_SEL           <=  '0';
                AMP_FBSW_FB_REV_SEL         <=  '0';
            else               
                AMP_FBSW_PATH_SEL           <=  amp_fbsw_path_sel_d; 
                AMP_FBSW_FB_REV_SEL         <=  amp_fbsw_fb_rev_sel_d;
            end if;

            RFIC_ORXMODE_0                  <=  rfic_orxmode_0_d;
            RFIC_ORXMODE_1                  <=  rfic_orxmode_1_d;
        end if;
    end process;


END FB_SW_CTRL_ARC;