
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

library work;
use work.RU_FPGA_FNC.all;
--use work.PKG_FUNC.all;

entity alm_detect is
generic(
    DEB_CNT                     : integer := 128;
    ACTIVE_VALUE                : std_logic:= '0'
);
port(
    RESET                       : in std_logic;
    CLK                         : in std_logic;

    ERROR_IN                    : in std_logic; 
    ERROR_DEBOUNCED             : out std_logic
);
end alm_detect;

architecture Behavioral of alm_detect is

constant DEB_CNT_WIDTH          : integer := log2(DEB_CNT)+1;-- +1 for using MSB as maximum counter value

type state is (FAIL_STS, SUCCESS_STS);
attribute syn_encoding          : string;
attribute syn_encoding of state : type is "one-hot, safe";

signal error_in_1r              : std_logic;
signal error_in_2r              : std_logic;
signal alm_state                : state;
signal deb_cnt_r                : std_logic_vector(DEB_CNT_WIDTH-1 downto 0); 
signal alm_output               : std_logic;

begin

    -- alarm double clocking
    process(RESET, CLK)
    begin
        if(RESET = '1')then
            error_in_1r <= '0';
            error_in_2r <= '0';
        elsif(CLK'event and CLK = '1')then
            if ACTIVE_VALUE = '1' then
                error_in_1r <= ERROR_IN;
                error_in_2r <= error_in_1r;
            else
                error_in_1r <= not ERROR_IN;
                error_in_2r <= error_in_1r;
            end if;
        end if;
    end process;

    -- debounced alarm output
    ERROR_DEBOUNCED <= alm_output;
    process(RESET, CLK)
    begin
        if(RESET = '1')then
            deb_cnt_r <= (others => '0');
            alm_state <= FAIL_STS;
            alm_output<= '1';
        elsif(CLK'event and CLK = '1')then
            case alm_state is
                when FAIL_STS =>
                    -- if alarm is cleared for 128 clock, go to success status
                    if error_in_2r = '1' then
                        deb_cnt_r <= (others => '0');
                    elsif deb_cnt_r(DEB_CNT_WIDTH-1) = '1' then
                        deb_cnt_r <= (others => '0');
                    else
                        deb_cnt_r <= deb_cnt_r + 1;
                    end if;

                    -- if alarm is cleared for 128 clock, go to success status
                    if deb_cnt_r(DEB_CNT_WIDTH-1) = '1' then
                        alm_state <= SUCCESS_STS;
                    else
                        alm_state <= FAIL_STS;
                    end if;
                    alm_output<= '1';
                when SUCCESS_STS =>
                    -- if alarm is occured for 128 clock, go to success status
                    if error_in_2r = '0' then
                        deb_cnt_r <= (others => '0');
                    elsif deb_cnt_r(DEB_CNT_WIDTH-1) = '1' then
                        deb_cnt_r <= (others => '0');
                    else
                        deb_cnt_r <= deb_cnt_r + 1;
                    end if;

                    -- if alarm is occured for 128 clock, go to success status
                    if deb_cnt_r(DEB_CNT_WIDTH-1) = '1' then
                        alm_state <= FAIL_STS;
                    else
                        alm_state <= SUCCESS_STS;
                    end if;
                    alm_output<= '0';
                when others =>
                    deb_cnt_r <= (others => '0');
                    alm_state <= FAIL_STS;
                    alm_output<= '1';
            end case;
        end if;
    end process;

end Behavioral;

