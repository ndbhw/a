
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;


entity alm_synch is
generic(
    ACTIVE_VALUE                : std_logic-- '1' : Active High, '0' : Active Low
);
port(
    RESET                       : in std_logic;
    CLK                         : in std_logic;

    ALARM_IN                    : in std_logic; 
    ALARM_OUT                   : out std_logic
);
end alm_synch;

architecture Behavioral of alm_synch is

signal i_alarm_d                : std_logic := '0';    
signal i_alarm_dd               : std_logic := '0';    

begin

    ALARM_OUT <= i_alarm_dd;
    process(RESET, CLK)
    begin
        if(RESET = '1')then 
            i_alarm_d  <= '0';
            i_alarm_dd <= '0';
        elsif(CLK'event and CLK = '1')then
            if ACTIVE_VALUE = '1' then      
                i_alarm_d  <= ALARM_IN;     -- Active High
                i_alarm_dd <= i_alarm_d;
            else                           
                i_alarm_d  <= not ALARM_IN; -- Active Low
                i_alarm_dd <= i_alarm_d;
            end if;
        end if;
    end process;

end Behavioral;

