------------------------------------------------------------------------
--
--  Module Name: SIG_SUS_BLK_DL_OFF
--
--  Purpose
--      to generate block DL Off
--
--
--  Feature
--      This module collects all alarms of slave ports.
--      When a port is a master port, the alarms of the port is discarded.
--
--      Debouncing time of normal state : about 0.6 ms
--          Clock   : 200MHz -> 5 ns
--          Count   : 120000 = 0x1D4C0 -> 5 ns x 120000 = 0.6 ms
--
--      I/O description
--          generic
--              port_num        -> port number(1~8)
--
--
--      Signal Suspension Scheme
--          When all slave ports are abnormal or LMK is unlock status
--          -> master ports are suspended.
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--  History
--      1st - 2016.11.xx
--          First Release
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

use work.ARRAY_TYPE.all;





entity SIG_SUS_BLK_DL_OFF is
    generic (
        PORT_NUM                        : natural   := 6                                        -- Port Number
    );
    port (
        RST_IN                          : in    std_logic;                                      -- Reset
        CLK_IN                          : in    std_logic;                                      -- Clock;   200 MHz
        
        -- Port Information
        IS_MASTER_IN                    : in    std_logic_vector(PORT_NUM-1 downto 0);          -- '1': Master, '0': Slave  ; When a port is master, alarms of the port is invalid.
        
        -- alarm
        FLAG_CLOCK_IN                   : in    std_logic;                                      -- Alarm - PLL Unlock
        FLAG_LINK0_IN                   : in    std_logic_vector(PORT_NUM-1 downto 0);          -- Alarm - Link Flag #0
        FLAG_LINK1_IN                   : in    std_logic_vector(PORT_NUM-1 downto 0);          -- Alarm - Link Flag #1
        
        -- TXINHIBIT
        MANUAL_OFF_IN                   : in    std_logic;                                      -- Manual Off Mode. '1': DL-off is turned off, '0': On
        DL_OFF_OUT                      : out   std_logic_vector(PORT_NUM-1 downto 0)           -- DL-off
    );
end SIG_SUS_BLK_DL_OFF;










architecture ARC_SIG_SUS_BLK_DL_OFF of SIG_SUS_BLK_DL_OFF is



    component ALM_SYNCH is
    generic(
        ACTIVE_VALUE                    : std_logic                                             -- '1' : Active High, '0' : Active Low
    );
    port(
        RESET                           : in    std_logic;
        CLK                             : in    std_logic;
        
        ALARM_IN                        : in    std_logic;
        ALARM_OUT                       : out   std_logic
    );
    end component;
    
    
    signal w_port_fail                  : std_logic_vector(PORT_NUM-1 downto 0);
    signal s_port_fail                  : std_logic_vector(PORT_NUM-1 downto 0);
    
    signal s_is_master                  : std_logic_vector(PORT_NUM-1 downto 0);
    signal s_manual_off                 : std_logic;
    
    signal s_flag_clock                 : std_logic;
    signal s_flag_link0                 : std_logic_vector(PORT_NUM-1 downto 0);
    signal s_flag_link1                 : std_logic_vector(PORT_NUM-1 downto 0);
    
    signal port_ok                      : std_logic_vector(         7 downto 0);
    signal port_ok_cnt                  : std_logic_vector(        19 downto 0);
    signal any_port_ok                  : std_logic_vector(PORT_NUM-1 downto 0);
    
    constant cnt_max                    : std_logic_vector(        19 downto 0) :=x"1D4C0";
    
    -- Synthisis Attribute for Chipscope
--  attribute mark_debug : string;
--  attribute mark_debug of port_fail_sh    : signal is "true";







begin
    
    
    -- Not-used ports
    port_ok(7 downto PORT_NUM)  <= (others => '0');
    
    
    -- Retiming - Alarm - Clock
    U_AS_FLAG_CLOCK : ALM_SYNCH generic map('1') port map(RST_IN, CLK_IN, FLAG_CLOCK_IN     , s_flag_clock          );
    
    -- Retiming - Output Control
    U_AS_MANUAL_OFF : ALM_SYNCH generic map('1') port map(RST_IN, CLK_IN, MANUAL_OFF_IN     , s_manual_off          );
    
    
    PORT_ARY: for i in 0 to (PORT_NUM-1) generate
    
    -- Retiming - Configuration
    U_AS_IS_MASTER  : ALM_SYNCH generic map('1') port map(RST_IN, CLK_IN, IS_MASTER_IN(i)   , s_is_master(i)        );
    
    -- Retiming - Alarm : Link
    U_AS_FLAG_LINK0 : ALM_SYNCH generic map('1') port map(RST_IN, CLK_IN, FLAG_LINK0_IN(i)  , s_flag_link0(i)       );
    U_AS_FLAG_LINK1 : ALM_SYNCH generic map('1') port map(RST_IN, CLK_IN, FLAG_LINK1_IN(i)  , s_flag_link1(i)       );
    
    w_port_fail(i)  <= (s_flag_clock or s_flag_link0(i) or s_flag_link1(i) );
    
    U_AS_PORT_FAIL  : ALM_SYNCH generic map('1') port map(RST_IN, CLK_IN, w_port_fail(i)    , s_port_fail(i)       );
    
    
    GEN_PORT_OK: process(RST_IN, CLK_IN)
    begin
        if (RST_IN = '1') then
            port_ok(i)      <= '1';
            
        elsif rising_edge(CLK_IN) then
            
            if (s_is_master(i) = '0') then              -- Slave port
                port_ok(i)  <= (not s_port_fail(i));
            else                                        -- When master port, discard alarms
                port_ok(i)  <= '0';
            end if;
            
        end if;
    end process;
    end generate PORT_ARY;
    
    
    GEN_CNT: process(RST_IN, CLK_IN)
    begin
        if (RST_IN = '1') then
            port_ok_cnt <= x"00000";
            
        elsif rising_edge(CLK_IN) then
            if (port_ok /= 0) then                      -- When any port is normal
                if (port_ok_cnt = cnt_max) then         -- Debouncing Time = 600 us
                    port_ok_cnt <= port_ok_cnt;
                else
                    port_ok_cnt <= port_ok_cnt + '1';
                end if;
            else
                port_ok_cnt <= (others => '0');
            end if;
        end if;
    end process;
    
    
    OUTPUT_ARY: for i in 0 to (PORT_NUM-1) generate
    DECIDE_PA_PROTECT: process(RST_IN, CLK_IN)
    begin
        if (RST_IN = '1') then
            any_port_ok(i)     <= '1';
            
        elsif rising_edge(CLK_IN) then
        
            if (s_is_master(i) = '0') then          -- slave port
                any_port_ok(i)  <= '1';
            else
                if ( (port_ok_cnt > cnt_max) or (port_ok_cnt = cnt_max) ) then
                    any_port_ok(i)  <= '1';
                else
                    any_port_ok(i)  <= '0';
                end if;
            end if;
        end if;
    end process;
    
    
    GEN_DL_OFF: process(RST_IN, CLK_IN)
    begin
        if (RST_IN = '1') then
            DL_OFF_OUT(i)    <= '0';
        elsif rising_edge(CLK_IN) then
        
            if (s_manual_off = '1') then                -- DL-off is de-active.
                DL_OFF_OUT(i)    <= '0';
            elsif (any_port_ok(i) = '0') then           -- When all slave ports are abnormal, master ports are suspended.
                DL_OFF_OUT(i)    <= '1';
            else
                DL_OFF_OUT(i)    <= '0';
            end if;
        end if;
    end process;
    
    
    end generate OUTPUT_ARY;





end ARC_SIG_SUS_BLK_DL_OFF;