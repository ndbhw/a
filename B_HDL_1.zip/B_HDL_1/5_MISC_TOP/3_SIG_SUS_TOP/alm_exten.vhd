
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;


entity alm_exten is
generic(
    EXT_WIDTH                   : natural   := 32;
    ACTIVE_VALUE                : std_logic := '1'
);
port(
    RESET                       : in  std_logic;
    CLK                         : in  std_logic;
    
    ALARM_IN                    : in  std_logic;-- Active High or Low
    ALARM_OUT                   : out std_logic -- Active High
);
end alm_exten;

architecture Behavioral of alm_exten is

signal alarm_in_d               : std_logic;    
signal alarm_in_dd              : std_logic;    

signal alm_ext                  : std_logic_vector(EXT_WIDTH-1 downto 0); 
constant deactive_value         : std_logic := not ACTIVE_VALUE;

begin

    process(RESET, CLK)
    begin
        if(RESET = '1')then
            alarm_in_d  <= '0';
            alarm_in_dd <= '0';
        elsif(CLK'event and CLK = '1')then
            if ACTIVE_VALUE = '1' then      
                alarm_in_d  <= ALARM_IN;     -- Active High
                alarm_in_dd <= alarm_in_d;
            else                           
                alarm_in_d  <= not ALARM_IN; -- Active Low
                alarm_in_dd <= alarm_in_d;
            end if;
        end if;
    end process;

    -- CDC, DEB_CNT should be set before reset release
    ALARM_OUT <= alm_ext(EXT_WIDTH-1) or alarm_in_dd;-- oring for preventing 1 clock delay
    process(RESET, CLK)
    begin
        if(RESET = '1')then
            alm_ext <= (others => '1');   
        elsif(CLK'event and CLK = '1')then
            if alarm_in_dd = '1' then
                alm_ext <= (others => '1');-- extension
            else
                alm_ext <= alm_ext(EXT_WIDTH-2 downto 0) & '0';-- release
            end if;
        end if;
    end process;

end Behavioral;

