---------------------------------------------------------------------------------------------------
--
--  Module Name: SIG_SUS_TOP
--
--  Purpose
--      to protect amps.
--      to report alarms(to CPUIF_MISC)
--
--
--  Warning
--
--
--
--
--
--  Feature
--      Design Spec.(Max)
--          CPRI Port   : 2 ports
--          SBIF Port   : 2 ports
--          Antenna     : 4T
--      Currnet Target  : Verizon RFV01U-D2A/D1A
--          FPGA Type       | Generic                           | RFV01U-D2A    |
--          FPGA0(ZU9P)     | CPRI_NUM                          |       2       |
--          FPGA0(ZU9P)     | SBIF_NUM                          |       2       |
--          FPGA0(ZU9P)     | DL_BBIQARY_NUM                    |       6???    |
--          FPGA0(ZU9P)     | JESD_TX_LINK_NUM                  |       2       |
--          FPGA0(ZU9P)     | JESD_RX_LINK_NUM                  |       2       |
--          FPGA0(ZU9P)     | JESD_FB_LINK_NUM                  |       2       |
--          FPGA0(ZU9P)     | TX_ANT_NUM                        |       4       |
--          FPGA1(KU9P)     | CPRI_NUM                          |       0       |
--          FPGA1(KU9P)     | SBIF_NUM                          |       2       |
--          FPGA1(KU9P)     | DL_BBIQARY_NUM                    |       6???    |
--          FPGA1(KU9P)     | JESD_TX_LINK_NUM                  |       2       |
--          FPGA1(KU9P)     | JESD_RX_LINK_NUM                  |       2       |
--          FPGA1(KU9P)     | JESD_FB_LINK_NUM                  |       2       |
--          FPGA1(KU9P)     | TX_ANT_NUM                        |       4       |
--
--
--
--
--      SIG_SUS_PBA_TYPE
--          x"00"   : FD-MIMO UQ 32T32R, CFPGA(XTMC-07)
--          x"01"   : FD-MIMO UQ 32T32R, DFPGA(XTMD-07)
--          x"04"   : FD-MIMO Jio 64T64R, IFPGA(PTMC-40T)
--          x"06"   : FD-MIMO Jio 64T64R, DFPGA(PTMC-40T)
--          x"08"   : Verizon Dualband 700/850MHz, RFV01U-D2A FPGA#0, B13   , RFV01U-D1A FPGA#0, B2
--          x"0A"   : Verizon Dualband 700/850MHz, RFV01U-D2A FPGA#1, B5    , RFV01U-D1A FPGA#1, B66
--          x"0C"   : -
--          x"0E"   : -
--          x"10"   : -
--
--
--
--
--
--
--
--
--
--
--      Voltage Signal Assignment: Verizon Dualband 700/850MHz, RFV01U-D2A FPGA0(ZU9P), B13/B5
--      | Schematic                    | Port Name             | Alarm                 | FPGA_TOP Port         | Signal Suspension             | Register Name     | Register Address  |
--      | UV_ALARM                     | UV_ALM_IN             | High                  |                       | SS_B(All Path), PA Disable    |                   |                   |
--      | NPWR55_VD_FAIL               | NPWR55_VD_FAIL_IN     | Low                   |                       | SS_B(All Path)                |                   |                   |
--      | FPGA_PWR_STATUS              | FPGA_PWR_STATUS_IN    | Low                   | FPGA_PWR_STATUS       | SS_B(All Path)                |                   |                   |
--      | PG_1p3V_AB_DIGITAL_IN        | PG_NORMAL_IN[ 0]      | Low                   |                       | SS_R(AB Path)                 |                   |                   |
--      | PG_1p3V_CD_DIGITAL_IN        | PG_NORMAL_IN[ 2]      | Low                   |                       | SS_R(CD Path)                 |                   |                   |
--      | PG_RFIC_AB_PMIC_IN           | PG_NORMAL_IN[ 4]      | Low                   |                       | SS_R(AB Path)                 |                   |                   |
--      | PG_RFIC_CD_PMIC_IN           | PG_NORMAL_IN[ 6]      | Low                   |                       | SS_R(CD Path)                 |                   |                   |
--      | PG_1p3V_RFIC_B5_ANALOG_IN(0) | PG_NORMAL_IN[ 8]      | Low(200 MHz, 10 times)|                       | SS_R(AB Path)                 |                   |                   |
--      | PG_1p3V_RFIC_B5_ANALOG_IN(1) | PG_NORMAL_IN[10]      | Low(200 MHz, 10 times)|                       | SS_R(CD Path)                 |                   |                   |
--      | PG_0p72V_ZUFPGA_IN           | PG_NORMAL_IN[12]      | Low(200 MHz, 10 times)|                       | SS_B(All Path)                |                   |                   |
--      | PG_0p85V_ZUFPGA_IN           | PG_NORMAL_IN[14]      | Low(200 MHz, 10 times)|                       | SS_B(All Path)                |                   |                   |
--      | PG_0p9V_ZUFPGA_MGT_IN        | PG_NORMAL_IN[16]      | Low(200 MHz, 10 times)|                       | SS_B(All Path)                |                   |                   |
--      | PG_1p2V_ZUFPGA_MGT_IN        | PG_NORMAL_IN[18]      | Low(200 MHz, 10 times)|                       | SS_B(All Path)                |                   |                   |
--      | PG_1p8V_ZUFPGA_MGT_IN        | PG_NORMAL_IN[20]      | Low(200 MHz, 10 times)|                       | SS_B(All Path)                |                   |                   |
--      | PG_1p8V_ZUFPGA_VCC_IN        | PG_NORMAL_IN[22]      | Low(200 MHz, 10 times)|                       | SS_B(All Path)                |                   |                   |
--      | PG_1p35V_DDR3_IN             | PG_NORMAL_IN[24]      | Low(200 MHz, 10 times)|                       | SS_B(All Path)                |                   |                   |
--      | PG_1p2V_ZUFPGA_PSPLL         | PG_NORMAL_IN[26]      | Low(200 MHz, 10 times)|                       | SS_B(All Path)                |                   |                   |
--      | PG_0p85V_ZUFPGA_PSMGT        | PG_NORMAL_IN[28]      | Low(200 MHz, 10 times)|                       | SS_B(All Path)                |                   |                   |
--
--

--      Port Description - PG_NORMAL_IN
--      | Source                       | Port                  | Signal Suspension     | Remark        |
--      | PG_1p3V_AB_DIGITAL_IN        | PG_NORMAL_IN[ 0]      | SS_R(AB Path)         | FPGA0,1       |
--      | PG_1p3V_CD_DIGITAL_IN        | PG_NORMAL_IN[ 2]      | SS_R(CD Path)         | FPGA0,1       |
--      | PG_RFIC_AB_PMIC_IN           | PG_NORMAL_IN[ 4]      | SS_R(AB Path)         | FPGA0,1       |
--      | PG_RFIC_CD_PMIC_IN           | PG_NORMAL_IN[ 6]      | SS_R(CD Path)         | FPGA0,1       |
--      | PG_1p3V_RFIC_B5_ANALOG_IN(0) | PG_NORMAL_IN[ 8]      | SS_R(AB Path)         | FPGA0,1       |
--      | PG_1p3V_RFIC_B5_ANALOG_IN(1) | PG_NORMAL_IN[10]      | SS_R(CD Path)         | FPGA0,1       |
--      | PG_0p72V_ZUFPGA_IN           | PG_NORMAL_IN[12]      | SS_B(All Path)        | FPGA0,1       |
--      | PG_0p85V_ZUFPGA_IN           | PG_NORMAL_IN[14]      | SS_B(All Path)        | FPGA0,1       |
--      | PG_0p9V_ZUFPGA_MGT_IN        | PG_NORMAL_IN[16]      | SS_B(All Path)        | FPGA0,1       |
--      | PG_1p2V_ZUFPGA_MGT_IN        | PG_NORMAL_IN[18]      | SS_B(All Path)        | FPGA0,1       |
--      | PG_1p8V_ZUFPGA_MGT_IN        | PG_NORMAL_IN[20]      | SS_B(All Path)        | FPGA0,1       |
--      | PG_1p8V_ZUFPGA_VCC_IN        | PG_NORMAL_IN[22]      | SS_B(All Path)        | FPGA0,1       |
--      | PG_1p35V_DDR3_IN             | PG_NORMAL_IN[24]      | SS_B(All Path)        | FPGA0,1       |
--      | PG_1p2V_ZUFPGA_PSPLL         | PG_NORMAL_IN[26]      | SS_B(All Path)        | FPGA0,1       |
--      | PG_0p85V_ZUFPGA_PSMGT        | PG_NORMAL_IN[28]      | SS_B(All Path)        | FPGA0,1       |

--      Port Description - ALM_EN_OTHERS_IN
--      | Port                  | Matching              | Remark                |
--      | ALM_EN_OTHERS_IN[0]   | External PLL Unlock   |                       |
--      | ALM_EN_OTHERS_IN[1]   | Internal PLL Unlock   |                       |
--      | ALM_EN_OTHERS_IN[2]   | VSS Remote Reset      |                       |
--      | ALM_EN_OTHERS_IN[3]   | HW Watchdog Interrupt |                       |
--      | ALM_EN_OTHERS_IN[4]   | RFIC_GP_INTERRUPT[0]  |                       |
--      | ALM_EN_OTHERS_IN[5]   | RFIC_GP_INTERRUPT[1]  |                       |
--      | ALM_EN_OTHERS_IN[6]   | RFIC_GP_INTERRUPT[2]  |                       |
--      | ALM_EN_OTHERS_IN[7]   | RFIC_GP_INTERRUPT[3]  |                       |
--
--
--
--  History
--      1st - 2017.03.31
--          1st Release
--              New Feature
--                  CPRI to SBIF DL Off
--      2nd - 2017.03.31
--          changed DCIF Bitwidth
--              LINK*LANE -> LINK
--      3rd - 2017.07.11
--          changed JESD Feedback assignment.
--              Feedback 1 path / 2 Antenna
--      4th - 2017.07.14
--          changed PG mapping.
--      5th - 2017.07.28
--          changed JESD DL/UL mapping.
--
--
--
--
---------------------------------------------------------------------------------------------------


library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

use work.ARRAY_TYPE.all;
use work.RU_FPGA_CONFIG.all;

entity SIG_SUS_TOP is
    port (
        -- Reset
        RST_CPUIF     : in std_logic; -- Reset of 100 MHz
        RST_CLK_MISC3 : in std_logic; -- Reset of 200 MHz
        RST_CLK_SYSX8 : in std_logic; -- Reset of 245.76 MHz

        -- Clock
        CLK_CPU   : in std_logic; -- CPU CLK 100MHz, not CPU_PLL Clock
        CLK_MISC3 : in std_logic; -- Clock.   200 MHz
        CLK_SYSX8 : in std_logic; -- Clock.   245.76 MHz

        -- Signal Suspension On/Off
        WAVESTOP_DISABLE_IN  : in std_logic;                      -- 100MHz CPU Clock Domain... wave stop disable control, except vss rst, for test
        ALM_DEB_CNT_IN       : in std_logic_vector( 19 downto 0); -- Alarm Debouncing Count
        RF_SW_OFF_RELEASE_IN : in std_logic_vector( 7 downto 0);  -- RF SW Off Release;   '0'->'1' : Release,  Others : No action

        -- Link Information
        IS_MASTER_CPRI_IN : in std_logic_vector( CPRI_NUM-1 downto 0); -- '1': Master      , '0': Slave        ; When Master, ignore in wave stop process.
        LINK_ANT_RELATION : in std_logic_array8( 7 downto 0);          -- '1': Related     , '0': No           ; CPRI Link Antenna Releation

        -- Signal Suspension Alarms - Blocks
        SIG_SUS_FLAG_CPRIPHY_IN : in std_logic_vector( CPRI_NUM-1 downto 0);        -- '1': Abnormal    , '0': Normal
        SIG_SUS_FLAG_CPRI_IN    : in std_logic_vector( CPRI_NUM-1 downto 0);        -- '1': Abnormal    , '0': Normal
        SIG_SUS_FLAG_SBIFPHY_IN : in std_logic_vector( SBIF_NUM-1 downto 0);        -- '1': Abnormal    , '0': Normal
        SIG_SUS_FLAG_SBIF_IN    : in std_logic_vector( SBIF_NUM-1 downto 0);        -- '1': Abnormal    , '0': Normal
        SIG_SUS_FLAG_BBCTRL_IN  : in std_logic_vector( DL_BBIQARY_NUM-1 downto 0);  -- '1': Abnormal    , '0': Normal
        SIG_SUS_FLAG_DSP_IN     : in std_logic_vector( TX_ANT_NUM-1 downto 0);      -- '1': Abnormal    , '0': Normal
        SIG_SUS_FLAG_DCIF_DL_IN : in std_logic_vector(JESD_TX_LINK_NUM-1 downto 0); -- '1': Abnormal    , '0': Normal
        SIG_SUS_FLAG_DCIF_UL_IN : in std_logic_vector(JESD_RX_LINK_NUM-1 downto 0); -- '1': Abnormal    , '0': Normal
        SIG_SUS_FLAG_DCIF_FB_IN : in std_logic_vector(JESD_FB_LINK_NUM-1 downto 0); -- '1': Abnormal    , '0': Normal

        -- Signal Suspension Alarms - Voltages
        UV_ALM_IN            : in std_logic;                      -- '1': Abnormal    , '0': Normal
        TRX_DC_IN_VD_FAIL_IN : in std_logic;                      -- '1': Normal      , '0': Abnormal
        FPGA_PWR_STATUS_IN   : in std_logic;                      -- '1': Normal      , '0': Abnormal
        NPWR55_VD_FAIL_IN    : in std_logic;                      -- '1': Normal      , '0': Abnormal
        PG_NORMAL_IN         : in std_logic_vector( 31 downto 0); -- '1': Normal      , '0': Abnormal

        -- Signal Suspension Alarms - Others
        EXT_PLL_LOCK_IN      : in std_logic;                     -- '1': Normal      , '0': Abnormal     ; LMK Lock
        SYS_PLL_LOCK_IN      : in std_logic;                     -- '1': Normal      , '0': Abnormal     ; System PLL Lock in FPGA
        RFIC_GP_INTERRUPT_IN : in std_logic_vector( 3 downto 0); -- '1': Abnormal    , '0': Normal       ; RFIC_GP_INTERRRUPT GPIO
        VSS_RMT_RST_CPRI_IN  : in std_logic;                     -- '1': Abnormal    , '0': Normal       ; From CPRI Core, Latched
        HWWDT_FLAG_IN        : in std_logic;                     -- '1': Abnormal    , '0': Normal       ; From Watchdog
        SWWDT_FLAG_IN        : in std_logic;                     -- '1': Abnormal    , '0': Normal       ; From CPU


        -- Signal Suspension - Blocks
        SIG_SUS_DLOFF_CPRIPHY_OUT : out std_logic_vector( CPRI_NUM-1 downto 0);   -- '1': DL Off      , '0': Normal
        SIG_SUS_DLOFF_SBIFPHY_OUT : out std_logic_vector( SBIF_NUM-1 downto 0);   -- '1': DL Off      , '0': Normal
        SIG_SUS_DLOFF_SBIF_OUT    : out std_logic_vector( SBIF_NUM-1 downto 0);   -- '1': DL Off      , '0': Normal
        SIG_SUS_DLOFF_BBCTRL_OUT  : out std_logic_vector( CPRI_NUM-1 downto 0);   -- '1': DL Off      , '0': Normal
        SIG_SUS_DLOFF_DSP_OUT     : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- '1': DL Off      , '0': Normal

        -- Signal Suspension Controls
        TX_SW_ON_OUT  : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- '1': TX SW On    , '0': TX SW Off    ;
        PA_EN_OUT     : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- '1': PA On       , '0': PA Off
        SIG_SUS_B_OUT : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- '1': On          , '0': Off
        SIG_SUS_R_OUT : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- '1': On          , '0': Off          ; PowerPAC Control Flag

        OPT_TX_DIS_OUT   : out std_logic; -- '1': Disable     ; '0': Enable
        AMC_RST_OUT      : out std_logic; -- '1': Reset       , '0': Reset-release; AMC7812
        SOLID_RED_ON_OUT : out std_logic; -- '1': On          , '0': Off
        UV_ALM_POST_OUT  : out std_logic; -- '1': On          , '0': Off          ; PowerPAC Control Flag
        RFIC_OFF_SEQ_OUT : out std_logic; -- '1': On          , '0': Off
        HW_WDT_RST_OUT   : out std_logic; -- '1': On          , '0': Off          ; PowerPAC Control Flag

        -- Monitoring - Blocks
        LOG_CPRIPHY_OUT   : out std_logic_vector( 7 downto 0);            -- '1': Alarm       , '0': No Alarm
        LOG_SBIFPHY_OUT   : out std_logic_vector( 7 downto 0);            -- '1': Alarm       , '0': No Alarm
        LOG_CPRI_OUT      : out std_logic_vector( 7 downto 0);            -- '1': Alarm       , '0': No Alarm
        LOG_SBIF_OUT      : out std_logic_vector( 7 downto 0);            -- '1': Alarm       , '0': No Alarm
        LOG_BBCTRL_OUT    : out std_logic_vector( 7 downto 0);            -- '1': Alarm       , '0': No Alarm
        LOG_DSP_OUT       : out std_logic_vector( 7 downto 0);            -- '1': Alarm       , '0': No Alarm
        LOG_DCIF_DL_OUT   : out std_logic_vector( 7 downto 0);            -- '1': Alarm       , '0': No Alarm
        LOG_DCIF_UL_OUT   : out std_logic_vector( 7 downto 0);            -- '1': Alarm       , '0': No Alarm
        LOG_DCIF_FB_OUT   : out std_logic_vector( 7 downto 0);            -- '1': Alarm       , '0': No Alarm
        LOG_SIG_SUS_B_OUT : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- '1': Alarm       , '0': No Alarm
        LOG_SIG_SUS_R_OUT : out std_logic_vector( TX_ANT_NUM-1 downto 0); -- '1': Alarm       , '0': No Alarm

        -- Monitoring - Others
        LOG_CLK_OUT     : out std_logic_vector( 1 downto 0);  -- '1': Alarm       , '0': No Alarm
        LOG_RFIC_OUT    : out std_logic_vector( 3 downto 0);  -- '1': Alarm       , '0': No Alarm
        LOG_VOLTAGE_OUT : out std_logic_vector( 31 downto 0); -- '1': Alarm       , '0': No Alarm
        LOG_DAC_OFF_OUT : out std_logic_vector( 7 downto 0);  -- '1': Alarm       , '0': No Alarm
        LOG_WDT_OUT     : out std_logic_vector( 1 downto 0);
        -- History
        HIS_MAIN_TYPE_OUT : out std_logic_vector( 7 downto 0);
        HIS_SUB_TYPE_OUT  : out std_logic_vector( 7 downto 0);
        HIS_VER_OUT       : out std_logic_vector( 7 downto 0);
        HIS_STRUCT_OUT    : out std_logic_vector( 31 downto 0);
        HIS_DATE_OUT      : out std_logic_vector( 31 downto 0);

        -- Test Function - Voltage Alarm Off
        ALM_DIS_VOLT_IN : in std_logic; -- '1': Forced Alarm-off, '0': No Force

        -- Test Function - Alarm Enable
        ALM_EN_CPRIPHY_IN : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
        ALM_EN_SBIFPHY_IN : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
        ALM_EN_CPRI_IN    : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
        ALM_EN_SBIF_IN    : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
        ALM_EN_BBCTRL_IN  : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
        ALM_EN_DSP_IN     : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
        ALM_EN_DCIF_DL_IN : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
        ALM_EN_DCIF_UL_IN : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
        ALM_EN_DCIF_FB_IN : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
        ALM_EN_VOLT_IN    : in std_logic_vector( 7 downto 0);  -- '1': Forced Alarm, '0': No Force
        ALM_EN_PG_IN      : in std_logic_vector( 31 downto 0); -- '1': Forced Alarm, '0': No Force
        ALM_EN_OTHERS_IN  : in std_logic_vector( 31 downto 0); -- '1': Forced Alarm, '0': No Force

        -- Test Function - DL Off
        DL_OFF_CPRIPHY_IN : in std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
        DL_OFF_SBIFPHY_IN : in std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
        DL_OFF_SBIF_IN    : in std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
        DL_OFF_BBCTRL_IN  : in std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
        DL_OFF_DSP_IN     : in std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force
        DL_OFF_DCIF_IN    : in std_logic_vector( 7 downto 0); -- '1': Forced DL Off, '0': No Force

        -- AMP Protection Timer
        I_t_dl_dly   : in std_logic_vector( 10 downto 0);
        I_t_pa_off   : in std_logic_vector( 10 downto 0);
        I_t_rf_swoff : in std_logic_vector( 10 downto 0)

    );
end SIG_SUS_TOP;





architecture ARC_SIG_SUS_TOP of SIG_SUS_TOP is


    -- History
    constant SIG_SUS_HIS_MAIN_TYPE : std_logic_vector( 7 downto 0) := x"63";       -- History : Main Type - 0x63 : SIG_SUS_TOP
    constant SIG_SUS_HIS_SUB_TYPE  : std_logic_vector( 7 downto 0) := x"00";       -- Histroy : Sub Type  - 0x00 : Suwon
    constant SIG_SUS_HIS_VER       : std_logic_vector( 7 downto 0) := x"00";       -- History : Version   - 0x00
    constant SIG_SUS_HIS_STRUCT    : std_logic_vector(31 downto 0) := x"00000000"; -- History : Struct
    constant SIG_SUS_HIS_DATE      : std_logic_vector(31 downto 0) := x"20170728"; -- History : Date

    component RST_SYNC is
        generic (
            DLY_NUM        : natural := 4;  -- Number of delay.
            MAX_FANOUT_NUM : integer := 200 -- Number of maximum fanout
        );
        port (
            RST_IN  : in  std_logic; -- Active high asynchronous rst
            CLK     : in  std_logic; -- clock to be sync'ed to
            RST_OUT : out std_logic  -- "Synchronised" rst signal
        );
    end component RST_SYNC;


    component TRCV_RFSW_ONOFF
        port (
            RESET : in std_logic;
            CLK   : in std_logic;

            i_time_rf_switch : in std_logic_vector(10 downto 0);
            VSS_DAC_OFF      : in std_logic;
            DAC_OFF          : in std_logic;
            RFIC_ABN         : in std_logic;

            RF_SW_ONOFF : out std_logic
        );
    end component;


    component ALM_SYNCH is
        generic(
            ACTIVE_VALUE : std_logic -- '1' : Active High, '0' : Active Low
        );
        port(
            RESET : in std_logic;
            CLK   : in std_logic;

            ALARM_IN  : in  std_logic;
            ALARM_OUT : out std_logic
        );
    end component;


    component ALM_DFF is
        generic(
            ACTIVE_VALUE : std_logic -- '1' : Active High, '0' : Active Low
        );
        port(
            RESET : in std_logic;
            CLK   : in std_logic;

            ALARM_IN  : in  std_logic;
            ALARM_OUT : out std_logic
        );
    end component ALM_DFF;


    component ERR_DEBOUNCE is
        port(
            RESET   : in std_logic;
            CLK     : in std_logic;
            DEB_CNT : in std_logic_vector(19 downto 0);

            ERROR_IN        : in  std_logic;
            ERROR_DEBOUNCED : out std_logic
        );
    end component;


    component ALM_EXTEN is
        generic(
            EXT_WIDTH    : natural   := 32;
            ACTIVE_VALUE : std_logic := '1' -- '1' : Active High, '0' : Active Low
        );
        port(
            RESET : in std_logic;
            CLK   : in std_logic;

            ALARM_IN  : in  std_logic; -- Active High or Low
            ALARM_OUT : out std_logic  -- Active High
        );
    end component;


    component ALM_DETECT is
        generic(
            DEB_CNT      : integer   := 128;
            ACTIVE_VALUE : std_logic := '0'
        );
        port(
            RESET : in std_logic;
            CLK   : in std_logic;

            ERROR_IN        : in  std_logic;
            ERROR_DEBOUNCED : out std_logic
        );
    end component;


    component SIG_SUS_BLK_DL_OFF is
        generic (
            PORT_NUM : natural := 6 -- Port Number
        );
        port (
            RST_IN : in std_logic; -- Reset
            CLK_IN : in std_logic; -- Clock;   200 MHz

            -- Port Information
            IS_MASTER_IN : in std_logic_vector(PORT_NUM-1 downto 0); -- '1': Master, '0': Slave  ; When a port is master, alarms of the port is invalid.

            -- alarm
            FLAG_CLOCK_IN : in std_logic;                             -- Alarm - PLL Unlock
            FLAG_LINK0_IN : in std_logic_vector(PORT_NUM-1 downto 0); -- Alarm - Link Flag #0
            FLAG_LINK1_IN : in std_logic_vector(PORT_NUM-1 downto 0); -- Alarm - Link Flag #1

            -- TXINHIBIT
            MANUAL_OFF_IN : in  std_logic;                            -- Manual Off Mode. '1': DL-off is turned off, '0': On
            DL_OFF_OUT    : out std_logic_vector(PORT_NUM-1 downto 0) -- DL-off
        );
    end component SIG_SUS_BLK_DL_OFF;


    -- Operation Signals
    signal rst_cpuif_int : std_logic;
    signal rst           : std_logic;
    signal rst_r         : std_logic;

    -- Configuration Signals
    signal i_is_master      : std_logic_vector( 7 downto 0);
    signal i_link_releation : std_logic_array8( 7 downto 0);

    signal i_wavestop_disable : std_logic;

    -- Port -> Signal           : w_~
    signal w_flag_cpriphy   : std_logic_vector( 7 downto 0);
    signal w_flag_cpri      : std_logic_vector( 7 downto 0);
    signal w_flag_sbifphy   : std_logic_vector( 7 downto 0);
    signal w_flag_sbif      : std_logic_vector( 7 downto 0);
    signal w_flag_bbctrl    : std_logic_vector( 7 downto 0);
    signal w_flag_cpri_link : std_logic_vector( 7 downto 0);
    signal w_flag_sbif_link : std_logic_vector( 7 downto 0);

    signal w_flag_dcif_dl : std_logic_vector( 7 downto 0);
    signal w_flag_dcif_ul : std_logic_vector( 7 downto 0);
    signal w_flag_dcif_fb : std_logic_vector( 7 downto 0);
    signal w_rfic_gp_int  : std_logic_vector( 7 downto 0);
    signal w_flag_dsp     : std_logic_vector( 7 downto 0);

    signal w_ext_pll_unlock : std_logic;
    signal w_sys_pll_unlock : std_logic;
    signal w_vss_rmt_rst    : std_logic;
    signal w_hw_wdt_flag    : std_logic;
    signal w_sw_wdt_flag    : std_logic;

    -- Alarm Extension          : e_
    signal e_flag_dcif_dl : std_logic_vector( 7 downto 0);
    signal e_flag_dcif_ul : std_logic_vector( 7 downto 0);
    signal e_flag_dcif_fb : std_logic_vector( 7 downto 0);
    signal e_rfic_gp_int  : std_logic_vector( 7 downto 0);

    -- Alarm Synchronization    : s_
    signal s_flag_ext_pll : std_logic;
    signal s_flag_sys_pll : std_logic;
    signal s_vss_rmt_rst  : std_logic;
    signal s_hw_wdt_flag  : std_logic;
    signal s_sw_wdt_flag  : std_logic;

    signal s_flag_cpriphy : std_logic_vector( 7 downto 0);
    signal s_flag_cpri    : std_logic_vector( 7 downto 0);
    signal s_flag_sbifphy : std_logic_vector( 7 downto 0);
    signal s_flag_sbif    : std_logic_vector( 7 downto 0);
    signal s_flag_bbctrl  : std_logic_vector( 7 downto 0);

    signal s_flag_cpri_link : std_logic_vector( 7 downto 0);
    signal s_flag_sbif_link : std_logic_vector( 7 downto 0);

    signal s_flag_dcif_dl : std_logic_vector( 7 downto 0);
    signal s_flag_dcif_ul : std_logic_vector( 7 downto 0);
    signal s_flag_dcif_fb : std_logic_vector( 7 downto 0);
    signal s_rfic_gp_int  : std_logic_vector( 7 downto 0);

    signal s_flag_dsp : std_logic_vector( 7 downto 0);

    signal s_trx_dc_i   : std_logic;
    signal s_uv_alm_i   : std_logic;
    signal s_fpga_pwr_i : std_logic;
    signal s_npwr55_i   : std_logic;

    signal s_trx_dc_ii   : std_logic;
    signal s_uv_alm_ii   : std_logic;
    signal s_fpga_pwr_ii : std_logic;
    signal s_npwr55_ii   : std_logic;

    signal s_trx_dc   : std_logic;
    signal s_uv_alm   : std_logic;
    signal s_fpga_pwr : std_logic;
    signal s_npwr55   : std_logic;

    signal s_alm_en_pg    : std_logic_vector(31 downto 0);
    signal s_alm_en_volt  : std_logic_vector( 7 downto 0);
    signal s_alm_dis_volt : std_logic;

    signal s_force_dl_off_cpriphy : std_logic_vector( 7 downto 0);
    signal s_force_dl_off_sbifphy : std_logic_vector( 7 downto 0);
    signal s_force_dl_off_sbif    : std_logic_vector( 7 downto 0);
    signal s_force_dl_off_bbctrl  : std_logic_vector( 7 downto 0);
    signal s_force_dl_off_dsp     : std_logic_vector( 7 downto 0);
    signal s_force_dl_off_dcif    : std_logic_vector( 7 downto 0);

    -- Alarm Debouncing         : deb_
    signal deb_flag_ext_pll : std_logic;
    signal deb_flag_sys_pll : std_logic;

    signal deb_flag_cpri_link     : std_logic_vector( 7 downto 0);
    signal deb_flag_cpri_link_and : std_logic;
    signal deb_flag_sbif_link     : std_logic_vector( 7 downto 0);

    signal deb_flag_dcif_dl : std_logic_vector( 7 downto 0);
    signal deb_flag_dcif_ul : std_logic_vector( 7 downto 0);
    signal deb_flag_dcif_fb : std_logic_vector( 7 downto 0);
    signal deb_rfic_gp_int  : std_logic_vector( 7 downto 0);
    signal deb_rfic_fail    : std_logic_vector( 7 downto 0);

    signal link_fail_dac_off     : std_logic_array8( 7 downto 0);
    signal link_fail_dac_off_sum : std_logic_vector( 7 downto 0);

    signal dt_flag_pg_i  : std_logic_vector(31 downto 0);
    signal dt_flag_pg_ii : std_logic_vector(31 downto 0);
    signal dt_flag_pg    : std_logic_vector(31 downto 0);
    signal or_flag_pg    : std_logic_vector( 7 downto 0);

    signal or_dl_off_cpriphy : std_logic_vector( CPRI_NUM-1 downto 0);
    signal or_dl_off_sbifphy : std_logic_vector( SBIF_NUM-1 downto 0);
    signal or_dl_off_sbif    : std_logic_vector( SBIF_NUM-1 downto 0);
    signal or_dl_off_bbctrl  : std_logic_vector( CPRI_NUM-1 downto 0);
    signal or_dl_off_dsp     : std_logic_vector( TX_ANT_NUM-1 downto 0);

    signal i_dl_off_cpriphy : std_logic_vector( CPRI_NUM-1 downto 0);
    signal i_dl_off_sbifphy : std_logic_vector( SBIF_NUM-1 downto 0);
    signal i_dl_off_sbif    : std_logic_vector( SBIF_NUM-1 downto 0);
    signal i_dl_off_bbctrl  : std_logic_vector( CPRI_NUM-1 downto 0);
    signal i_dl_off_dsp     : std_logic_vector( TX_ANT_NUM-1 downto 0);

    signal i_volt_fail     : std_logic;
    signal i_volt_fail_deb : std_logic;

    signal wdt_flag_hw_ctrl_flag : std_logic;
    signal vss_sw_ctrl_wait_cnt  : std_logic_vector(13 downto 0); -- 10 sec
    signal vss_rst_hw_ctrl_flag  : std_logic;

    signal swinit_pre_post_sel : std_logic;
    --    signal pre_wdt_sh                   : std_logic_vector(1 downto 0);

    signal timer_1ms : std_logic_vector(17 downto 0);
    signal tick_1ms  : std_logic;

    signal state_num : std_logic_vector( 4 downto 0);

    signal func_fail        : std_logic;
    signal vss_dacoff       : std_logic;
    signal opt_disable      : std_logic;
    signal i_dac_off        : std_logic_vector( 7 downto 0);
    signal i_dac_off_deb    : std_logic_vector( 7 downto 0);
    signal i_dac_off_deb_sh : std_logic_vector( 7 downto 0);
    signal i_trcvout_sw     : std_logic_vector( 7 downto 0);
    signal i_dac_off_not_rf : std_logic_vector( 7 downto 0);
    signal flag_sig_sus_b   : std_logic_vector( 7 downto 0);
    signal flag_sig_sus_r   : std_logic_vector( 7 downto 0);
    signal sig_sus_b        : std_logic_vector( 7 downto 0);
    signal sig_sus_r        : std_logic_vector( 7 downto 0);


    signal uv_alm_flag  : std_logic;
    signal vss_rst_flag : std_logic;
    signal wdt_rst_flag : std_logic;
    signal uv_alm_post  : std_logic;
    signal ru_shutdown  : std_logic;
    signal wdt_reset    : std_logic;
    signal wdt_reset_sh : std_logic_vector(1 downto 0);
    signal i_amc_rst    : std_logic; -- Active High
    signal i_led_on     : std_logic; -- LED Indicator. Active High.
    signal cnt_5ms      : std_logic_vector( 2 downto 0);
    signal cnt_100ms    : std_logic_vector( 6 downto 0);
    signal pa_onoff     : std_logic_vector( 7 downto 0);

    signal cnt_dl_dly : std_logic_vector( 10 downto 0);
    signal cnt_paoff  : std_logic_vector( 10 downto 0);

    signal r_t_dl_dly     : std_logic_vector( 10 downto 0);
    signal r_t_pa_off     : std_logic_vector( 10 downto 0);
    signal r_t_rf_swoff   : std_logic_vector( 10 downto 0);

    signal rf_sw_off_release_d : std_logic_array3( 7 downto 0);
    signal rf_sw_off           : std_logic_vector( 7 downto 0);
    signal rf_sw_off_alarm     : std_logic_vector( 7 downto 0);

    signal i_trcvout_sw_sh : std_logic_array3( 7 downto 0);
    signal cnt_350us       : std_logic_array20( 7 downto 0);
    signal ss_b_release    : std_logic_vector( 7 downto 0);

    constant SEC_10 : std_logic_vector(13 downto 0) := "10011100010000";     -- 1ms * (10,000) = 10 sec  (1~10,000)
    constant MS_1   : std_logic_vector(17 downto 0) := "110000110100111111"; -- 1/200MHz * (200,000) = 1 ms (0~199,999)

    signal dl_off_is_master  : std_logic_vector( 1 downto 0);
    signal dl_off_flag_link0 : std_logic_array2(CPRI_NUM-1 downto 0);
    signal dl_off_flag_link1 : std_logic_array2(CPRI_NUM-1 downto 0);
    signal dl_off_out        : std_logic_array2(CPRI_NUM-1 downto 0);
    signal dl_off_out_link   : std_logic_array2(CPRI_NUM-1 downto 0);
    signal zeros             : std_logic_vector(31 downto 0);


    -- Synthisis Attribute for Chipscope
    --attribute mark_debug : string;
    --attribute mark_debug of w_ext_pll_unlock              : signal is "true";


begin


    -- History
    HIS_MAIN_TYPE_OUT <= SIG_SUS_HIS_MAIN_TYPE ; --: out   std_logic_vector(                 7 downto 0);
    HIS_SUB_TYPE_OUT  <= SIG_SUS_HIS_SUB_TYPE ;  --: out   std_logic_vector(                 7 downto 0);
    HIS_VER_OUT       <= SIG_SUS_HIS_VER ;       --: out   std_logic_vector(                 7 downto 0);
    HIS_STRUCT_OUT    <= SIG_SUS_HIS_STRUCT ;    --: out   std_logic_vector(                31 downto 0);
    HIS_DATE_OUT      <= SIG_SUS_HIS_DATE ;      --: out   std_logic_vector(                31 downto 0);

    zeros <= (others => '0');

        -- Synchronous Reset Generation
        U_RST_CPUIF : RST_SYNC generic map (8, 200) port map (RST_CLK_MISC3 , CLK_CPU , rst_cpuif_int);
        U_RST_MIIX8 : RST_SYNC generic map (8, 200) port map (RST_CLK_MISC3 , CLK_MISC3 , rst );
        U_RST_SYSX8 : RST_SYNC generic map (8, 200) port map (RST_CLK_SYSX8 , CLK_SYSX8 , rst_r );

    -- Configuration
    -- Master/Slave Mode
    IS_MS_ARY : for i in 0 to (CPRI_NUM-1) generate
            U_IS_MASTER : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, IS_MASTER_CPRI_IN(i) , i_is_master(i) );
    end generate IS_MS_ARY;

    -- Not-used port -> Master Setting
    IS_MS_ARY_OTHERS : for i in CPRI_NUM to 7 generate
        i_is_master(i) <= '1';
    end generate IS_MS_ARY_OTHERS;

    -- CPRI Link Antenna Relation
    LINK_ANT_ARY : for i in 0 to 7 generate
        LINK_ANT_ARY_SUB : for j in 0 to 7 generate
                U_LINK_ANT_REL : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, LINK_ANT_RELATION(i)(j) , i_link_releation(i)(j));
        end generate LINK_ANT_ARY_SUB;
    end generate LINK_ANT_ARY;

        -- Wavestop Synchronization
        U_AS_WAVESTOP : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, WAVESTOP_DISABLE_IN , i_wavestop_disable );


    -------------------- Alarm - Others : Start --------------------
    w_ext_pll_unlock <= ( (not EXT_PLL_LOCK_IN) or ALM_EN_OTHERS_IN(0) ) when i_wavestop_disable = '0' else '0';
    w_sys_pll_unlock <= ( (not SYS_PLL_LOCK_IN) or ALM_EN_OTHERS_IN(1) ) when i_wavestop_disable = '0' else '0';

    -- Interrput(VSS Remote rst, HW Watchdog) -> Except WAVESTOP_DISABLE_IN
    --  VSS Remote Reset, HW Watchdog Interrupt
    w_vss_rmt_rst <= ( VSS_RMT_RST_CPRI_IN or ALM_EN_OTHERS_IN(2) );
    w_hw_wdt_flag <= ( HWWDT_FLAG_IN or ALM_EN_OTHERS_IN(3) );
    w_sw_wdt_flag <= ( SWWDT_FLAG_IN or ALM_EN_OTHERS_IN(3) );

    -- RFIC #0 -> TX Antenna #0,1
    -- RFIC #1 -> TX Antenna #2,3
    -- RFIC #2 -> TX Antenna #4,5
    -- RFIC #3 -> TX Antenna #6,7
    w_rfic_gp_int(0) <= ( RFIC_GP_INTERRUPT_IN(0) or ALM_EN_OTHERS_IN(4) ) when i_wavestop_disable = '0' else '0';
    w_rfic_gp_int(2) <= ( RFIC_GP_INTERRUPT_IN(1) or ALM_EN_OTHERS_IN(5) ) when i_wavestop_disable = '0' else '0';
    w_rfic_gp_int(4) <= ( RFIC_GP_INTERRUPT_IN(2) or ALM_EN_OTHERS_IN(6) ) when i_wavestop_disable = '0' else '0';
    w_rfic_gp_int(6) <= ( RFIC_GP_INTERRUPT_IN(3) or ALM_EN_OTHERS_IN(7) ) when i_wavestop_disable = '0' else '0';

    w_rfic_gp_int(1) <= ( RFIC_GP_INTERRUPT_IN(0) or ALM_EN_OTHERS_IN(4) ) when i_wavestop_disable = '0' else '0';
    w_rfic_gp_int(3) <= ( RFIC_GP_INTERRUPT_IN(1) or ALM_EN_OTHERS_IN(5) ) when i_wavestop_disable = '0' else '0';
    w_rfic_gp_int(5) <= ( RFIC_GP_INTERRUPT_IN(2) or ALM_EN_OTHERS_IN(6) ) when i_wavestop_disable = '0' else '0';
    w_rfic_gp_int(7) <= ( RFIC_GP_INTERRUPT_IN(3) or ALM_EN_OTHERS_IN(7) ) when i_wavestop_disable = '0' else '0';
    -------------------- Alarm - Others : End --------------------


    -------------------- Alarm - Blocks : Start --------------------
    -- Array Generate : Used Signals
    CPRI_ARY : for i in 0 to (CPRI_NUM-1) generate
        w_flag_cpriphy(i) <= ( SIG_SUS_FLAG_CPRIPHY_IN(i) or ALM_EN_CPRIPHY_IN(i) ) when i_wavestop_disable = '0' else '0';
        w_flag_cpri(i)    <= ( SIG_SUS_FLAG_CPRI_IN(i) or ALM_EN_CPRI_IN(i) )       when i_wavestop_disable = '0' else '0';
    end generate CPRI_ARY;

    SBIF_ARY : for i in 0 to (SBIF_NUM-1) generate
        w_flag_sbifphy(i) <= ( SIG_SUS_FLAG_SBIFPHY_IN(i) or ALM_EN_SBIFPHY_IN(i) ) when i_wavestop_disable = '0' else '0';
        w_flag_sbif(i)    <= ( SIG_SUS_FLAG_SBIF_IN(i) or ALM_EN_SBIF_IN(i) )       when i_wavestop_disable = '0' else '0';
    end generate SBIF_ARY;

    BBCTRL_ARY : for i in 0 to (DL_BBIQARY_NUM-1) generate
        w_flag_bbctrl(i) <= ( SIG_SUS_FLAG_BBCTRL_IN(i) or ALM_EN_BBCTRL_IN(i) ) when i_wavestop_disable = '0' else '0';
    end generate BBCTRL_ARY;

    --  DCIF_DL_ARY: for i in 0 to (JESD_TX_LINK_NUM-1) generate
    --  w_flag_dcif_dl(i)   <= ( SIG_SUS_FLAG_DCIF_DL_IN(i) or ALM_EN_DCIF_DL_IN(i) )   when i_wavestop_disable = '0' else '0';
    --  end generate DCIF_DL_ARY;
    w_flag_dcif_dl(0) <= ( SIG_SUS_FLAG_DCIF_DL_IN(0) or ALM_EN_DCIF_DL_IN(0) ) when i_wavestop_disable = '0' else '0';
    w_flag_dcif_dl(1) <= ( SIG_SUS_FLAG_DCIF_DL_IN(0) or ALM_EN_DCIF_DL_IN(0) ) when i_wavestop_disable = '0' else '0';
    --w_flag_dcif_dl(2)   <= ( SIG_SUS_FLAG_DCIF_DL_IN(1) or ALM_EN_DCIF_DL_IN(1) )   when i_wavestop_disable = '0' else '0';
    --w_flag_dcif_dl(3)   <= ( SIG_SUS_FLAG_DCIF_DL_IN(1) or ALM_EN_DCIF_DL_IN(1) )   when i_wavestop_disable = '0' else '0';
    w_flag_dcif_dl(7 downto 2) <= (others => '0');

    --  DCIF_UL_ARY: for i in 0 to (JESD_RX_LINK_NUM-1) generate
    --  w_flag_dcif_ul(i)   <= ( SIG_SUS_FLAG_DCIF_UL_IN(i) or ALM_EN_DCIF_UL_IN(i) )   when i_wavestop_disable = '0' else '0';
    --  end generate DCIF_UL_ARY;
    w_flag_dcif_ul(0) <= ( SIG_SUS_FLAG_DCIF_UL_IN(0) or ALM_EN_DCIF_UL_IN(0) ) when i_wavestop_disable = '0' else '0';
    w_flag_dcif_ul(1) <= ( SIG_SUS_FLAG_DCIF_UL_IN(0) or ALM_EN_DCIF_UL_IN(0) ) when i_wavestop_disable = '0' else '0';
    --w_flag_dcif_ul(2)   <= ( SIG_SUS_FLAG_DCIF_UL_IN(1) or ALM_EN_DCIF_UL_IN(1) )   when i_wavestop_disable = '0' else '0';
    --w_flag_dcif_ul(3)   <= ( SIG_SUS_FLAG_DCIF_UL_IN(1) or ALM_EN_DCIF_UL_IN(1) )   when i_wavestop_disable = '0' else '0';
    w_flag_dcif_ul(7 downto 2) <= (others => '0');

    --  DCIF_FB_ARY: for i in 0 to (JESD_FB_LINK_NUM-1) generate
    --  w_flag_dcif_fb(i)   <= ( SIG_SUS_FLAG_DCIF_FB_IN(i) or ALM_EN_DCIF_FB_IN(i) )   when i_wavestop_disable = '0' else '0';
    --  end generate DCIF_FB_ARY;
    w_flag_dcif_fb(0) <= ( SIG_SUS_FLAG_DCIF_FB_IN(0) or ALM_EN_DCIF_FB_IN(0) ) when i_wavestop_disable = '0' else '0';
    w_flag_dcif_fb(1) <= ( SIG_SUS_FLAG_DCIF_FB_IN(0) or ALM_EN_DCIF_FB_IN(0) ) when i_wavestop_disable = '0' else '0';
    --w_flag_dcif_fb(2)   <= ( SIG_SUS_FLAG_DCIF_FB_IN(1) or ALM_EN_DCIF_FB_IN(1) )   when i_wavestop_disable = '0' else '0';
    --w_flag_dcif_fb(3)   <= ( SIG_SUS_FLAG_DCIF_FB_IN(1) or ALM_EN_DCIF_FB_IN(1) )   when i_wavestop_disable = '0' else '0';
    w_flag_dcif_fb(7 downto 2) <= (others => '0');

    DSP_ARY : for i in 0 to (TX_ANT_NUM-1) generate
        w_flag_dsp(i) <= ( SIG_SUS_FLAG_DSP_IN(i) or ALM_EN_DSP_IN(i) ) when i_wavestop_disable = '0' else '0';

    end generate DSP_ARY;

    LINK_FAIL_ARY : for i in 0 to 7 generate
        w_flag_cpri_link(i) <= ( w_flag_cpriphy(i) or w_flag_cpri(i) );
        w_flag_sbif_link(i) <= ( w_flag_sbifphy(i) or w_flag_sbif(i) );
    end generate LINK_FAIL_ARY;

    -- Array Generate : Not-used
    CPRI_ARY_OTHERS_IF : if (CPRI_NUM < 8) generate
        CPRI_ARY_OTHERS_FOR : for i in CPRI_NUM to 7 generate
            w_flag_cpriphy(i) <= '0';
            w_flag_cpri(i)    <= '0';
        end generate CPRI_ARY_OTHERS_FOR;
    end generate CPRI_ARY_OTHERS_IF;

    SBIF_ARY_OTHERS_IF : if (SBIF_NUM < 8) generate
        SBIF_ARY_OTHERS_FOR : for i in SBIF_NUM to 7 generate
            w_flag_sbifphy(i) <= '0';
            w_flag_sbif(i)    <= '0';
        end generate SBIF_ARY_OTHERS_FOR;
    end generate SBIF_ARY_OTHERS_IF;

    BBCTRL_ARY_OTHERS_IF : if (DL_BBIQARY_NUM < 8) generate
        BBCTRL_ARY_OTHERS_FOR : for i in DL_BBIQARY_NUM to 7 generate
            w_flag_bbctrl(i) <= '0';
        end generate BBCTRL_ARY_OTHERS_FOR;
    end generate BBCTRL_ARY_OTHERS_IF;

    --  DCIF_DL_ARY_OTHERS_IF : if (JESD_TX_LINK_NUM < 8) generate
    --  DCIF_DL_ARY_OTHERS_FOR: for i in JESD_TX_LINK_NUM to 7 generate
    --  w_flag_dcif_dl(i)   <= '0';
    --  end generate DCIF_DL_ARY_OTHERS_FOR;
    --  end generate DCIF_DL_ARY_OTHERS_IF;

    --  DCIF_UL_ARY_OTHERS_IF : if (JESD_RX_LINK_NUM < 8) generate
    --  DCIF_UL_ARY_OTHERS_FOR: for i in JESD_RX_LINK_NUM to 7 generate
    --  w_flag_dcif_ul(i)   <= '0';
    --  end generate DCIF_UL_ARY_OTHERS_FOR;
    --  end generate DCIF_UL_ARY_OTHERS_IF;

    --  DCIF_FB_ARY_OTHERS_IF : if (JESD_FB_LINK_NUM < 8) generate
    --  DCIF_FB_ARY_OTHERS_FOR: for i in JESD_FB_LINK_NUM to 7 generate
    --  w_flag_dcif_fb(i)   <= '0';
    --  end generate DCIF_FB_ARY_OTHERS_FOR;
    --  end generate DCIF_FB_ARY_OTHERS_IF;

    DSP_ARY_OTHERS_IF : if (TX_ANT_NUM < 8) generate
        DSP_ARY_OTHERS_FOR : for i in TX_ANT_NUM to 7 generate
            w_flag_dsp(i) <= '0';
        end generate DSP_ARY_OTHERS_FOR;
    end generate DSP_ARY_OTHERS_IF;

    -------------------- Alarm - Blocks : End --------------------


    -- Alarm Processing
    --  RFIC Alarm
    --      Extension in DSP Clock Domain   -> Retiming in 200 MHz Domain   -> Debouncing in 200 MHz Domain
    --  Link Alarm
    --                                         Retiming in 200 MHz Domain   -> Debouncing in 200 MHz Domain
    --  DSP Alarm
    --                                         Retiming in 200 MHz Domain

    ALM_PROC_ARY : for i in 0 to 7 generate
            -------------------- Alarm Extension --------------------
            -- RFIC         : Minimum Period = 1/307.2MHz       , Need to be extended & debounced
            U_AE_DCIF_DL : ALM_EXTEN generic map(32, '1') port map(rst_r, CLK_SYSX8, w_flag_dcif_dl(i) , e_flag_dcif_dl(i) );
            U_AE_DCIF_UL : ALM_EXTEN generic map(32, '1') port map(rst_r, CLK_SYSX8, w_flag_dcif_ul(i) , e_flag_dcif_ul(i) );
            U_AE_DCIF_FB : ALM_EXTEN generic map(32, '1') port map(rst_r, CLK_SYSX8, w_flag_dcif_fb(i) , e_flag_dcif_fb(i) );
            U_AE_RFIC_GP : ALM_EXTEN generic map(32, '1') port map(rst_r, CLK_SYSX8, w_rfic_gp_int(i) , e_rfic_gp_int(i) );

            -------------------- Alarm Double Clocking --------------------
            -- Link         : Minimum Period = 64*1/245.76MHz   , Need to be debounced
            U_AS_CPRIPHY   : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, w_flag_cpriphy(i) , s_flag_cpriphy(i) );
            U_AS_CPRI      : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, w_flag_cpri(i) , s_flag_cpri(i) );
            U_AS_SBIFPHY   : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, w_flag_sbifphy(i) , s_flag_sbifphy(i) );
            U_AS_SBIF      : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, w_flag_sbif(i) , s_flag_sbif(i) );
            U_AS_BBCTRL    : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, w_flag_bbctrl(i) , s_flag_bbctrl(i) );
            U_AS_CPRI_LINK : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, w_flag_cpri_link(i) , s_flag_cpri_link(i) );
            U_AS_SBIF_LINK : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, w_flag_sbif_link(i) , s_flag_sbif_link(i) );

            -- RFIC         : Minimum Period = 1/307.2MHz       , Need to be extended & debounced
            U_AS_DCIF_DL : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, e_flag_dcif_dl(i) , s_flag_dcif_dl(i) );
            U_AS_DCIF_UL : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, e_flag_dcif_ul(i) , s_flag_dcif_ul(i) );
            U_AS_DCIF_FB : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, e_flag_dcif_fb(i) , s_flag_dcif_fb(i) );
            U_AS_DCIF_GP : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, e_rfic_gp_int(i) , s_rfic_gp_int(i) );

            -- DSP(OPD)     : Minimum Period >= 500 us
            U_AS_DSP : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, w_flag_dsp(i) , s_flag_dsp(i) );

            -------------------- Alarm Debouncing --------------------
            U_DEB_CPRI_LINK : ERR_DEBOUNCE port map(rst, CLK_MISC3, ALM_DEB_CNT_IN, s_flag_cpri_link(i), deb_flag_cpri_link(i) );
            U_DEB_SBIF_LINK : ERR_DEBOUNCE port map(rst, CLK_MISC3, ALM_DEB_CNT_IN, s_flag_sbif_link(i), deb_flag_sbif_link(i) );

            U_DEB_DCIF_DL : ERR_DEBOUNCE port map(rst, CLK_MISC3, ALM_DEB_CNT_IN, s_flag_dcif_dl(i) , deb_flag_dcif_dl(i) );
            U_DEB_DCIF_UL : ERR_DEBOUNCE port map(rst, CLK_MISC3, ALM_DEB_CNT_IN, s_flag_dcif_ul(i) , deb_flag_dcif_ul(i) );
            U_DEB_DCIF_FB : ERR_DEBOUNCE port map(rst, CLK_MISC3, ALM_DEB_CNT_IN, s_flag_dcif_fb(i) , deb_flag_dcif_fb(i) );
            U_DEB_DCIF_GP : ERR_DEBOUNCE port map(rst, CLK_MISC3, ALM_DEB_CNT_IN, s_rfic_gp_int(i) , deb_rfic_gp_int(i) );
    end generate ALM_PROC_ARY;

        -- Clock        : Minimum Period = Unknown          , Need to be debounced
        U_AS_EXT_PLL : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, w_ext_pll_unlock , s_flag_ext_pll );
        U_AS_SYS_PLL : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, w_sys_pll_unlock , s_flag_sys_pll );

        U_DEB_EXT_PLL : ERR_DEBOUNCE port map(rst, CLK_MISC3, ALM_DEB_CNT_IN, s_flag_ext_pll, deb_flag_ext_pll);
        U_DEB_SYS_PLL : ERR_DEBOUNCE port map(rst, CLK_MISC3, ALM_DEB_CNT_IN, s_flag_sys_pll, deb_flag_sys_pll);

        -- Interrupt
        U_AS_VSS_RST : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, w_vss_rmt_rst , s_vss_rmt_rst );
        U_AS_HW_WDT  : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, w_hw_wdt_flag , s_hw_wdt_flag );
        U_AS_SW_WDT  : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, w_sw_wdt_flag , s_sw_wdt_flag );

    -------------------- Voltage Alarm --------------------
    --      Port Description - PG_NORMAL_IN
    --      | Source                       | Port                  | Signal Suspension     | Remark        |
    --      | PG_1p3V_AB_DIGITAL_IN        | PG_NORMAL_IN[ 0]      | SS_R(AB Path)         | FPGA0,1       |
    --      | PG_1p3V_CD_DIGITAL_IN        | PG_NORMAL_IN[ 2]      | SS_R(CD Path)         | FPGA0,1       |
    --      | PG_RFIC_AB_PMIC_IN           | PG_NORMAL_IN[ 4]      | SS_R(AB Path)         | FPGA0,1       |
    --      | PG_RFIC_CD_PMIC_IN           | PG_NORMAL_IN[ 6]      | SS_R(CD Path)         | FPGA0,1       |
    --      | PG_1p3V_RFIC_B5_ANALOG_IN(0) | PG_NORMAL_IN[ 8]      | SS_R(AB Path)         | FPGA0,1       |
    --      | PG_1p3V_RFIC_B5_ANALOG_IN(1) | PG_NORMAL_IN[10]      | SS_R(CD Path)         | FPGA0,1       |
    --      | PG_0p72V_ZUFPGA_IN           | PG_NORMAL_IN[12]      | SS_B(All Path)        | FPGA0,1       |
    --      | PG_0p85V_ZUFPGA_IN           | PG_NORMAL_IN[14]      | SS_B(All Path)        | FPGA0,1       |
    --      | PG_0p9V_ZUFPGA_MGT_IN        | PG_NORMAL_IN[16]      | SS_B(All Path)        | FPGA0,1       |
    --      | PG_1p2V_ZUFPGA_MGT_IN        | PG_NORMAL_IN[18]      | SS_B(All Path)        | FPGA0,1       |
    --      | PG_1p8V_ZUFPGA_MGT_IN        | PG_NORMAL_IN[20]      | SS_B(All Path)        | FPGA0,1       |
    --      | PG_1p8V_ZUFPGA_VCC_IN        | PG_NORMAL_IN[22]      | SS_B(All Path)        | FPGA0,1       |
    --      | PG_1p35V_DDR3_IN             | PG_NORMAL_IN[24]      | SS_B(All Path)        | FPGA0,1       |
    --      | PG_1p2V_ZUFPGA_PSPLL         | PG_NORMAL_IN[26]      | SS_B(All Path)        | FPGA0,1       |
    --      | PG_0p85V_ZUFPGA_PSMGT        | PG_NORMAL_IN[28]      | SS_B(All Path)        | FPGA0,1       |

    -- PG Alarm Debouncing
    PG_ARY : for i in 0 to 31 generate
            U_AD_PG        : ALM_DETECT generic map(128, '0') port map(rst, CLK_MISC3, PG_NORMAL_IN(i), dt_flag_pg_i(i));
            U_AS_ALM_EN_PG : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, ALM_EN_PG_IN(i), s_alm_en_pg(i) );
        dt_flag_pg(i) <= dt_flag_pg_ii(i) when (s_alm_en_pg(i) = '0') else '1';
    end generate PG_ARY;

    dt_flag_pg_ii <= dt_flag_pg_i when (s_alm_dis_volt = '0') else (others => '0');


    -- PG Alarm Mapping
    or_flag_pg(0) <= ( dt_flag_pg(16) or dt_flag_pg(18) or dt_flag_pg(20) );
    or_flag_pg(1) <= '0'; --( dt_flag_pg(16) or dt_flag_pg(18) or dt_flag_pg(20) );
    or_flag_pg(2) <= '0';
    or_flag_pg(3) <= '0';
    or_flag_pg(4) <= '0'; --( dt_flag_pg(0) or dt_flag_pg(2) or dt_flag_pg(4) or dt_flag_pg(6) or dt_flag_pg(8) or dt_flag_pg(12) );
    or_flag_pg(5) <= '0'; --( dt_flag_pg(0) or dt_flag_pg(2) or dt_flag_pg(4) or dt_flag_pg(6) or dt_flag_pg(8) or dt_flag_pg(12) );
    or_flag_pg(6) <= '0'; --( dt_flag_pg(0) or dt_flag_pg(2) or dt_flag_pg(4) or dt_flag_pg(6) or dt_flag_pg(8) or dt_flag_pg(12) );
    or_flag_pg(7) <= '0'; --( dt_flag_pg(0) or dt_flag_pg(2) or dt_flag_pg(4) or dt_flag_pg(6) or dt_flag_pg(8) or dt_flag_pg(12) );

        -- Voltage Fail : Minimum Period = Unknown  , Need to be debounced
        U_AS_UV_ALM   : ALM_SYNCH generic map('0') port map(rst, CLK_MISC3, UV_ALM_IN , s_uv_alm_i );
        U_AS_TRX_DC   : ALM_SYNCH generic map('0') port map(rst, CLK_MISC3, TRX_DC_IN_VD_FAIL_IN , s_trx_dc_i );
        U_AS_FPGA_STS : ALM_SYNCH generic map('0') port map(rst, CLK_MISC3, FPGA_PWR_STATUS_IN , s_fpga_pwr_i );
        U_AS_NPWR55   : ALM_SYNCH generic map('0') port map(rst, CLK_MISC3, NPWR55_VD_FAIL_IN , s_npwr55_i );

        U_AS_ALM_DIS : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, ALM_DIS_VOLT_IN , s_alm_dis_volt );

        U_AS_ALMEN_VOLT0 : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, ALM_EN_VOLT_IN(0) , s_alm_en_volt(0) );
        U_AS_ALMEN_VOLT1 : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, ALM_EN_VOLT_IN(1) , s_alm_en_volt(1) );
        U_AS_ALMEN_VOLT2 : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, ALM_EN_VOLT_IN(2) , s_alm_en_volt(2) );
        U_AS_ALMEN_VOLT3 : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, ALM_EN_VOLT_IN(3) , s_alm_en_volt(3) );
    s_alm_en_volt(7 downto 4) <= (others => '0');

    s_uv_alm_ii   <= s_uv_alm_i   when (s_alm_dis_volt = '0') else '0';
    s_trx_dc_ii   <= s_trx_dc_i   when (s_alm_dis_volt = '0') else '0';
    s_fpga_pwr_ii <= s_fpga_pwr_i when (s_alm_dis_volt = '0') else '0';
    s_npwr55_ii   <= s_npwr55_i   when (s_alm_dis_volt = '0') else '0';

    s_uv_alm   <= s_uv_alm_ii   when (s_alm_en_volt(0) = '0') else '1';
    s_trx_dc   <= s_trx_dc_ii   when (s_alm_en_volt(1) = '0') else '1';
    s_fpga_pwr <= s_fpga_pwr_ii when (s_alm_en_volt(2) = '0') else '1';
    s_npwr55   <= s_npwr55_ii   when (s_alm_en_volt(3) = '0') else '1';

    --i_volt_fail     <= (    s_uv_alm or
    --                        s_trx_dc or
    --                        s_fpga_pwr or
    --                        s_npwr55 or
    --                        dt_flag_pg(0) or
    --                        dt_flag_pg(2) or
    --                        dt_flag_pg(4) or
    --                        dt_flag_pg(6) or
    --                        dt_flag_pg(8) or
    --                        dt_flag_pg(10) or
    --                        dt_flag_pg(12) or
    --                        dt_flag_pg(14) or
    --                        dt_flag_pg(16) or
    --                        dt_flag_pg(18) or
    --                        dt_flag_pg(20)
    --                    );
    --
    i_volt_fail <= ( s_trx_dc or
            s_fpga_pwr or
            s_npwr55 or
            dt_flag_pg(0) or
            dt_flag_pg(2) or
            dt_flag_pg(4) or
            dt_flag_pg(6) or
            dt_flag_pg(8) or
            dt_flag_pg(10) or
            dt_flag_pg(12) or
            dt_flag_pg(14) or
            dt_flag_pg(16) or
            dt_flag_pg(18) or
            dt_flag_pg(20)
    );

    process(CLK_MISC3) begin
        if(rising_edge(CLK_MISC3)) then
            r_t_dl_dly     <= I_t_dl_dly ;
            r_t_pa_off     <= I_t_pa_off ;
            r_t_rf_swoff   <= I_t_rf_swoff ;
        end if;
    end process;

        U_DEB_VOLT_FAIL : ERR_DEBOUNCE port map(rst, CLK_MISC3, ALM_DEB_CNT_IN, i_volt_fail , i_volt_fail_deb );

    RF_SW_ARY : for i in 0 to 7 generate
        deb_rfic_fail(i)   <= ( deb_flag_dcif_dl(i) or deb_flag_dcif_fb(i) or deb_rfic_gp_int(i) or or_flag_pg(i) );
        rf_sw_off_alarm(i) <= deb_rfic_fail(i);
    end generate RF_SW_ARY;


    GEN_LINK_FAIL_ARY : for i in 0 to 7 generate
        GEN_LINK_FAIL : process(rst, CLK_MISC3)
        begin
            if (rst = '1') then
                link_fail_dac_off(i) <= (others => '0');

            elsif rising_edge(CLK_MISC3) then

                if (deb_flag_cpri_link(i) = '1') and (i_wavestop_disable = '0') and (i_is_master(i) = '0') then
                    link_fail_dac_off(i) <= i_link_releation(i);
                else
                    link_fail_dac_off(i) <= (others => '0');
                end if;
            end if;
        end process;
    end generate GEN_LINK_FAIL_ARY;

    deb_flag_cpri_link_and <= ( deb_flag_cpri_link(0) and deb_flag_cpri_link(1) and deb_flag_cpri_link(2) and deb_flag_cpri_link(3) and
            deb_flag_cpri_link(4) and deb_flag_cpri_link(5) and deb_flag_cpri_link(6) and deb_flag_cpri_link(7) );

    GEN_LINK_FAIL_SUM : process(rst, CLK_MISC3)
    begin
        if (rst = '1') then
            link_fail_dac_off_sum <= (others => '0');

        elsif rising_edge(CLK_MISC3) then
            link_fail_dac_off_sum <= ( link_fail_dac_off(0) or link_fail_dac_off(1) or link_fail_dac_off(2) or link_fail_dac_off(3) or
                    link_fail_dac_off(4) or link_fail_dac_off(5) or link_fail_dac_off(6) or link_fail_dac_off(7) );
        end if;
    end process;


    GEN_FUNC_FAIL : process(rst, CLK_MISC3)
    begin
        if (rst = '1') then
            func_fail <= '1';

        elsif rising_edge(CLK_MISC3) then
            func_fail <= ( deb_flag_ext_pll or deb_flag_sys_pll or deb_flag_cpri_link_and or i_volt_fail_deb );
        end if;
    end process;


    GEN_DAC_OFF : process(rst, CLK_MISC3)
    begin
        if (rst = '1') then
            i_dac_off        <= (others => '1');
            i_dac_off_not_rf <= (others => '1');

        elsif rising_edge(CLK_MISC3) then
            if ( (func_fail = '1') or (vss_dacoff = '1') ) then -- All Path
                i_dac_off        <= (others => '1');
                i_dac_off_not_rf <= (others => '1');
            else -- Case by Case
                i_dac_off        <= (link_fail_dac_off_sum or s_flag_dsp or rf_sw_off );
                i_dac_off_not_rf <= (link_fail_dac_off_sum or s_flag_dsp);
            end if;
        end if;
    end process;


    -------------------- VSS Remote Reset Flag Process --------------------
    GEN_VSS_RST_10S : process(rst,CLK_MISC3)
    begin
        if (rst = '1') then
            vss_sw_ctrl_wait_cnt <= (others => '0');
        elsif rising_edge(CLK_MISC3) then
            if (s_vss_rmt_rst = '1') then
                if (tick_1ms = '1') then
                    if (vss_sw_ctrl_wait_cnt = SEC_10) then
                        vss_sw_ctrl_wait_cnt <= vss_sw_ctrl_wait_cnt;
                    else
                        vss_sw_ctrl_wait_cnt <= vss_sw_ctrl_wait_cnt + 1;
                    end if;
                end if;
            else
                vss_sw_ctrl_wait_cnt <= (others => '0');
            end if;
        end if;
    end process;

    GEN_VSS_FLAG : process(rst,CLK_MISC3)
    begin
        if (rst = '1') then
            vss_rst_hw_ctrl_flag <= '0';
        elsif rising_edge(CLK_MISC3) then
            if (vss_sw_ctrl_wait_cnt = SEC_10) then
                vss_rst_hw_ctrl_flag <= '1';
            end if;
        end if;
    end process;

    GEN_WDT_FLAG : process(rst,CLK_MISC3)
    begin
        if (rst = '1') then
            wdt_flag_hw_ctrl_flag <= '0';
        elsif rising_edge(CLK_MISC3) then
            if (tick_1ms = '1') then -- for synchronized with tick
                wdt_flag_hw_ctrl_flag <= s_hw_wdt_flag;
            else
                wdt_flag_hw_ctrl_flag <= wdt_flag_hw_ctrl_flag;
            end if;
        end if;
    end process;
    -------------------- VSS Remote Reset Flag Process --------------------


    -------------------- Timer --------------------
    GEN_TIMER : process(rst,CLK_MISC3)
    begin
        if (rst = '1') then
            timer_1ms <= (others => '0');
            tick_1ms  <= '0';
        elsif (CLK_MISC3'event and CLK_MISC3 = '1') then
            if timer_1ms = MS_1 then -- 200MHz
                                     --        if timer_1ms = "1100011" then  -- 1 us for simulation
                timer_1ms <= (others => '0');
            else
                timer_1ms <= timer_1ms + 1;
            end if;

            if timer_1ms = MS_1 then -- 200MHz
                                     --        if timer_1ms = "1100011" then  -- 1 us for simulation
                tick_1ms <= '1';
            else
                tick_1ms <= '0';
            end if;
        end if;
    end process;
    -------------------- Timer --------------------


    -------------------- VSS Reset & Under Voltage Alarm FSM - Start --------------------
    process(rst,CLK_MISC3)
    begin
        if (rst = '1') then
            state_num    <= (others => '0');
            vss_dacoff   <= '0';
            opt_disable  <= '0';
            cnt_5ms      <= (others => '0');
            pa_onoff     <= (others => '1');
            cnt_100ms    <= (others => '0');
            cnt_paoff    <= (others => '0');
            cnt_dl_dly   <= (others => '0');
            uv_alm_flag  <= '0';
            vss_rst_flag <= '0';
            wdt_rst_flag <= '0';
            uv_alm_post  <= '0';
            ru_shutdown  <= '0';
            wdt_reset    <= '0';
            i_amc_rst    <= '0';
            i_led_on     <= '0';
        elsif (CLK_MISC3'event and CLK_MISC3 = '1') then
            case state_num is
                when "00000" =>
                    if vss_rst_hw_ctrl_flag = '1' then
                        uv_alm_flag  <= '0';
                        vss_rst_flag <= '1';
                        wdt_rst_flag <= '0';
                        vss_dacoff   <= '1';
                        opt_disable  <= '1';
                        state_num    <= "00001";
                    elsif wdt_flag_hw_ctrl_flag = '1' then
                        uv_alm_flag  <= '0';
                        vss_rst_flag <= '0';
                        wdt_rst_flag <= '1';
                        vss_dacoff   <= '1';
                        opt_disable  <= '1';
                        state_num    <= "00001";
                    elsif s_sw_wdt_flag = '1' then
                        uv_alm_flag  <= '0';
                        vss_rst_flag <= '0';
                        wdt_rst_flag <= '0';
                        vss_dacoff   <= '1';
                        opt_disable  <= '1';
                        state_num    <= "00001";
                    elsif s_uv_alm = '1' or s_trx_dc = '1' then
                        uv_alm_flag  <= '1';
                        vss_rst_flag <= '0';
                        wdt_rst_flag <= '0';
                        vss_dacoff   <= '1';
                        opt_disable  <= '1';
                        state_num    <= "00100"; -- Trcv rf sw off state
                    else
                        uv_alm_flag  <= '0';
                        vss_rst_flag <= '0';
                        wdt_rst_flag <= '0';
                        vss_dacoff   <= '0';
                        opt_disable  <= '0';
                        state_num    <= "00000";
                    end if;
                    i_amc_rst <= '0';
                    i_led_on  <= '0';
                when "00001" => -- wait 5 ms after DAC off, RF switch off will be controlled in RFCV_RFSW_ONOFF
                    if cnt_5ms = "101" then
                        state_num <= "00010";
                        pa_onoff  <= (others => '0');
                    else
                        if tick_1ms = '1' then
                            if cnt_5ms = "101" then
                                cnt_5ms <= cnt_5ms;
                            else
                                cnt_5ms <= cnt_5ms + 1;
                            end if;
                        end if;
                        pa_onoff <= (others => '1');
                    end if;
                    i_amc_rst <= '0';
                    i_led_on  <= '0';

                when "00010" => -- wait 100 msec after pa off
                    if cnt_100ms = "1100011" then
                        state_num <= "10000";
                    else
                        if tick_1ms = '1' then
                            if cnt_100ms = "1100011" then
                                cnt_100ms <= cnt_100ms;
                            else
                                cnt_100ms <= cnt_100ms + 1;
                            end if;
                        end if;
                        state_num <= "00010";
                    end if;
                    i_amc_rst <= '0';
                    i_led_on  <= '0';

                when "00100" =>
                    -- T_dl_dly time -> Default 3.47 us
                    if cnt_dl_dly = r_t_dl_dly then
                        cnt_dl_dly   <= cnt_dl_dly;
                        state_num <= "01000";
                    else
                        cnt_dl_dly <= cnt_dl_dly + 1;
                    end if;
                    i_amc_rst <= '0';
                    i_led_on  <= '0';

                when "01000" =>
                    -- T_pa_off = 2.56 us
                    if cnt_paoff = r_t_pa_off then
                        state_num <= "10000";
                    else
                        cnt_paoff <= cnt_paoff + 1;
                    end if;
                    pa_onoff  <= (others => '0');
                    i_amc_rst <= '0';
                    i_led_on  <= '0';

                when "10000" => -- RFIC LDO & PSU OFF available state
                    pa_onoff    <= (others => '0');
                    uv_alm_post <= uv_alm_flag;
                    ru_shutdown <= vss_rst_flag;
                    wdt_reset   <= wdt_rst_flag;
                    i_amc_rst   <= '1';
                    i_led_on    <= '1';

                when others =>
                    state_num    <= "00000";
                    vss_dacoff   <= '0';
                    cnt_5ms      <= (others => '0');
                    pa_onoff     <= (others => '1');
                    cnt_100ms    <= (others => '0');
                    cnt_paoff    <= (others => '0');
                    uv_alm_flag  <= '0';
                    vss_rst_flag <= '0';
                    uv_alm_post  <= '0';
                    ru_shutdown  <= '0';
                    wdt_reset    <= '0';
                    i_amc_rst    <= i_amc_rst;
                    i_led_on     <= i_led_on;
            end case;
        end if;
    end process;
    -------------------- VSS Reset & Under Voltage Alarm FSM - End --------------------

    -------------------- WDT control : before sig_sus_top reset releas & after release --
    process(rst_cpuif_int,CLK_CPU) -- 100MHz domain, rst released by RU SW !!!
    begin
        if (rst_cpuif_int = '1') then
            swinit_pre_post_sel <= '1'; -- '1': before logic initialized by RU Software  , '0' : after logic initialized by RU Software
        elsif rising_edge(CLK_CPU) then
            swinit_pre_post_sel <= '0';
        end if;
    end process;

    process(RST_CPUIF,CLK_CPU) -- 100MHz domain, rst_cpuif released by CPU_PLL lock !!!
    begin
        if (RST_CPUIF = '1') then
            wdt_reset_sh <= (others => '0');
        elsif rising_edge(CLK_CPU) then
            wdt_reset_sh <= wdt_reset_sh(0) & wdt_reset;
        end if;
    end process;

    --    process(RST_CPUIF,CLK_CPU)  -- 100MHz domain, rst_cpuif released by CPU_PLL lock !!!
    --    begin
    --        if (RST_CPUIF = '1') then
    --           pre_wdt_sh <= (others => '0');
    --        elsif rising_edge(CLK_CPU) then
    --           pre_wdt_sh <= pre_wdt_sh(0) & HWWDT_FLAG_IN;
    --        end if;
    --    end process;
    -------------------------------------------------------------------------------------


    -------------------- TRCV RF Switch Process - Start --------------------
    GEN_RF_SW_ARY : for i in 0 to 7 generate
        GEN_RF_SW_OFF_ARY : process(rst,CLK_MISC3)
        begin
            if (rst = '1') then
                rf_sw_off_release_d(i) <= (others => '0');
                rf_sw_off(i)           <= '0';
                flag_sig_sus_r(i)      <= '0';
            elsif rising_edge(CLK_MISC3) then
                rf_sw_off_release_d(i) <= rf_sw_off_release_d(i)(1 downto 0) & RF_SW_OFF_RELEASE_IN(i);

                if rf_sw_off_alarm(i) = '1' then
                    rf_sw_off(i)      <= '1';
                    flag_sig_sus_r(i) <= '1';

                elsif rf_sw_off_release_d(i)(2 downto 1) = "01" then
                    rf_sw_off(i)      <= '0';
                    flag_sig_sus_r(i) <= '0';

                end if;
            end if;
        end process;

        -- RF_SW_ONOFF Debouncing
        DEB_RF_SW_ONOFF : process(rst, CLK_MISC3)
        begin
            if (rst = '1') then
                i_trcvout_sw_sh(i) <= (others => '0'); -- Default: Off
                cnt_350us(i)       <= (others => '0');
                ss_b_release(i)    <= '0'; -- Default: Off
            elsif rising_edge(CLK_MISC3) then
                i_trcvout_sw_sh(i) <= i_trcvout_sw_sh(i)(1 downto 0) & i_trcvout_sw(i);

                -- Debouncing 350 us
                if (rf_sw_off_release_d(i)(2 downto 1) = "01") then -- SS_R : Release
                    cnt_350us(i) <= x"11170";
                elsif (i_trcvout_sw_sh(i)(2 downto 1) = "01") then -- SS_B : When RF SW is just turn on, rst the counter!
                    cnt_350us(i) <= (others => '0');
                elsif (i_trcvout_sw_sh(i)(2 downto 1) = "00") then -- SS_B : When RF SW Off, rst!
                    cnt_350us(i) <= (others => '0');
                elsif (cnt_350us(i) = x"11170") then -- When the counter is maximum value, stop!
                    cnt_350us(i) <= cnt_350us(i);
                else
                    cnt_350us(i) <= cnt_350us(i) + '1';
                end if;

                -- debounced flag
                if ( (cnt_350us(i) = x"11170") or (cnt_350us(i) > x"11170") ) then
                    ss_b_release(i) <= '1';
                else
                    ss_b_release(i) <= '0';
                end if;
            end if;
        end process;


        GEN_DAC_OFF_DEB : process(rst, CLK_MISC3)
        begin
            if (rst = '1') then
                i_dac_off_deb(i)    <= '1';
                i_dac_off_deb_sh(i) <= '1';
                sig_sus_b(i)        <= '0';
                sig_sus_r(i)        <= '0';
                flag_sig_sus_b(i)   <= '0';

            elsif rising_edge(CLK_MISC3) then

                -- SS_R
                --  SS_R Action : DAC Off, RF SW Off at same time
                --  SS_R Release: DAC on, RF SW On   at same time
                if (rf_sw_off(i) = '1') then
                    i_dac_off_deb_sh(i) <= '1'; -- SS_R -> at same time
                    sig_sus_r(i)        <= '1';

                else
                    i_dac_off_deb_sh(i) <= i_dac_off_deb(i);
                    if (flag_sig_sus_r(i) = '0' and i_dac_off_deb(i) = '0' ) then
                        sig_sus_r(i) <= i_dac_off_deb(i);
                    end if;

                    if (flag_sig_sus_b(i) = '1') then
                        sig_sus_b(i) <= '1';
                    elsif (i_dac_off_deb(i) = '0' ) then
                        sig_sus_b(i) <= i_dac_off_deb(i);
                    end if;


                end if;



                -- SS_B
                --  SS_B Actin  : DAC off ->  (Spec.: Min. 500 ns; Real: 2.56us ) -> RF SW Off
                --  SS_B Release: RF SW On -> (Spec.: Min. 310 us; Real: 350us  ) -> DAC On
                if (i_dac_off(i) = '1' or vss_dacoff = '1') then
                    i_dac_off_deb(i) <= '1';
                    if(i_dac_off_not_rf(i) = '1') then
                        flag_sig_sus_b(i) <= '1';
                    end if;


                elsif ( (i_dac_off(i) = '0') and (ss_b_release(i) = '1') ) then
                    i_dac_off_deb(i)  <= '0';
                    flag_sig_sus_b(i) <= '0';

                else
                    i_dac_off_deb(i) <= i_dac_off_deb(i);
                end if;
            end if;
        end process;
            --------------------------------------------------------------------
            -- r_t_rf_swoff default value : RF SW OFF after (0.04us + 3.47us + 2.5us)
            -- refer to RF2239-28A FPGA F/L 4.7.2.4.2 (Figure.28 Timing diagram for UV alarm and VSS reset)
            --------------------------------------------------------------------
            U_TRCV_SW_CTRL : TRCV_RFSW_ONOFF port map(rst, CLK_MISC3, r_t_rf_swoff, vss_dacoff, i_dac_off(i), rf_sw_off(i), i_trcvout_sw(i) );
    end generate GEN_RF_SW_ARY;

    i_dl_off_dsp <= i_dac_off_deb_sh(TX_ANT_NUM-1 downto 0);
    -------------------- TRCV RF Switch Process - End --------------------


    -- Monitoring - Blocks
    LOG_CPRIPHY_OUT <= s_flag_cpriphy ;
    LOG_SBIFPHY_OUT <= s_flag_sbifphy ;
    LOG_CPRI_OUT    <= s_flag_cpri ;
    LOG_SBIF_OUT    <= s_flag_sbif ;
    LOG_BBCTRL_OUT  <= s_flag_bbctrl ;
    LOG_DSP_OUT     <= s_flag_dsp ;
    LOG_DCIF_DL_OUT <= deb_flag_dcif_dl ;
    LOG_DCIF_UL_OUT <= deb_flag_dcif_ul ; -- Log Only. No Signal Suspension
    LOG_DCIF_FB_OUT <= deb_flag_dcif_fb ;

    -- Monitoring - Others
    LOG_CLK_OUT     <= ( deb_flag_sys_pll & deb_flag_ext_pll ) ;
    LOG_RFIC_OUT    <= ( deb_rfic_fail(3) & deb_rfic_fail(2) & deb_rfic_fail(1) & deb_rfic_fail(0) );
    LOG_WDT_OUT     <= s_sw_wdt_flag & s_hw_wdt_flag ;
    LOG_VOLTAGE_OUT <= ( "000000000"
            & dt_flag_pg(28) -- [22]
            & dt_flag_pg(26) -- [21]
            & dt_flag_pg(24) -- [20]
            & dt_flag_pg(22) -- [19]
            & dt_flag_pg(20) -- [18]
            & dt_flag_pg(18) -- [17]
            & dt_flag_pg(16) -- [16]
            & dt_flag_pg(14) -- [15]
            & dt_flag_pg(12) -- [14]
            & dt_flag_pg(10) -- [13]
            & dt_flag_pg(8)  -- [12]
            & dt_flag_pg(6)  -- [11]
            & dt_flag_pg(4)  -- [10]
            & dt_flag_pg(2)  -- [ 9]
            & dt_flag_pg(0)  -- [ 8]
            & '0'            -- [ 7]
            & s_npwr55       -- [ 6]
            & '0'            -- [ 5]
            & s_fpga_pwr     -- [ 4]
            & '0'            -- [ 3]
            & s_trx_dc       -- [ 2]
            & '0'            -- [ 1]
            & s_uv_alm       -- [ 0]
    );
    LOG_DAC_OFF_OUT <= i_dac_off_deb_sh;


    TX_SW_ON_OUT     <= i_trcvout_sw(TX_ANT_NUM-1 downto 0);
    PA_EN_OUT        <= pa_onoff(TX_ANT_NUM-1 downto 0);
    OPT_TX_DIS_OUT   <= opt_disable;
    AMC_RST_OUT      <= i_amc_rst;
    SOLID_RED_ON_OUT <= i_led_on;
    UV_ALM_POST_OUT  <= uv_alm_post;
    RFIC_OFF_SEQ_OUT <= ru_shutdown;
    --HW_WDT_RST_OUT      <= wdt_reset;
    HW_WDT_RST_OUT <= HWWDT_FLAG_IN when swinit_pre_post_sel = '1' else wdt_reset_sh(1);


    -------------------- Block DL Off --------------------

    -- Verizon RFV01U-D2A/D1A, FPGA#0
    --              CPRI_NUM                            : 2
    --              SBIF_NUM                            : 2
    --              DL_BBIQARY_NUM                      : 6???
    --              JESD_TX_LINK_NUM                    : 2
    --              JESD_RX_LINK_NUM                    : 2
    --              JESD_FB_LINK_NUM                    : 2
    --              TX_ANT_NUM                          : 4
    TYPE_08 : if (SIG_SUS_PBA_TYPE = x"08") generate
            -- When CPRI Port is master, DL Off
            DL_OFF_CPRIPHY : SIG_SUS_BLK_DL_OFF generic map(CPRI_NUM) port map(rst, CLK_MISC3, i_is_master(CPRI_NUM-1 downto 0), s_flag_ext_pll, s_flag_cpri(CPRI_NUM-1 downto 0), zeros(CPRI_NUM-1 downto 0), zeros(0), i_dl_off_cpriphy(CPRI_NUM-1 downto 0));
        --    i_dl_off_sbifphy   <= (others => '0');
        --    i_dl_off_sbif      <= (others => '0');

        dl_off_is_master <= "10";
        DL_OFF_BBCTRL_ARY : for i in 0 to (CPRI_NUM-1) generate
            dl_off_flag_link0(i) <= ('0' & s_flag_cpri(i) );
            dl_off_flag_link1(i) <= ('0' & s_flag_cpriphy(i) );
            dl_off_out_link(i)   <= (others => '0');

                -- When CPRI Link Abnormal, BBCTRL Off, SBIF Off
                DL_OFF_BBCTRL : SIG_SUS_BLK_DL_OFF generic map(2) port map(rst, CLK_MISC3, dl_off_is_master, s_flag_ext_pll, dl_off_flag_link0(i), dl_off_flag_link1(i), zeros(0), dl_off_out(i));
            i_dl_off_bbctrl(i) <= dl_off_out(i)(1);
        --i_dl_off_sbifphy(i)<= dl_off_out(i)(1);
        --i_dl_off_sbif(i)   <= dl_off_out(i)(1);
        end generate DL_OFF_BBCTRL_ARY;
    end generate TYPE_08;


    -- Verizon RFV01U-D2A/D1A, FPGA#1
    --              CPRI_NUM                            : 0
    --              SBIF_NUM                            : 2
    --              DL_BBIQARY_NUM                      : 6???
    --              JESD_TX_LINK_NUM                    : 2
    --              JESD_RX_LINK_NUM                    : 2
    --              JESD_FB_LINK_NUM                    : 2
    --              TX_ANT_NUM                          : 4
    TYPE_0A : if (SIG_SUS_PBA_TYPE = x"0A") generate
        i_dl_off_cpriphy <= (others => '0');

        dl_off_is_master <= "10";
        DL_OFF_SBIF_ARY : for i in 0 to (SBIF_NUM-1) generate

            -- If SBIF Cascade... Slave -> Master Off
            --    DL_OFF_SBIF     : SIG_SUS_BLK_DL_OFF generic map(2) port map(rst, CLK_MISC3, dl_off_is_master, s_flag_ext_pll, dl_off_flag_link0(i), dl_off_flag_link1(i), zeros(0), dl_off_out_link(i));
            i_dl_off_sbifphy(i) <= '0';
            i_dl_off_sbif(i)    <= '0';
        --    i_dl_off_sbifphy(i+3)  <= dl_off_out_link(i)(1);
        --    i_dl_off_sbif(i+3)     <= dl_off_out_link(i)(1);
        end generate DL_OFF_SBIF_ARY;


        DL_OFF_BBCTRL_ARY : for i in 0 to (CPRI_NUM-1) generate
            dl_off_flag_link0(i) <= ('0' & s_flag_sbif(i) );
            dl_off_flag_link1(i) <= ('0' & s_flag_sbifphy(i) );

                -- When SBIF Link Abnormal, BBCTRL Off
                DL_OFF_BBCTRL : SIG_SUS_BLK_DL_OFF generic map(2) port map(rst, CLK_MISC3, dl_off_is_master, s_flag_ext_pll, dl_off_flag_link0(i), dl_off_flag_link1(i), zeros(0), dl_off_out(i));
            i_dl_off_bbctrl(i) <= dl_off_out(i)(1);
        end generate DL_OFF_BBCTRL_ARY;
    end generate TYPE_0A;


    -------------------- Manual DL Off --------------------

    U_AS_FORCE_DL_OFF_ARY : for i in 0 to 7 generate
            U_AS_FORCE_DL_OFF_CPRIPHY : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, DL_OFF_CPRIPHY_IN(i) , s_force_dl_off_cpriphy(i) );
            U_AS_FORCE_DL_OFF_SBIFPHY : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, DL_OFF_SBIFPHY_IN(i) , s_force_dl_off_sbifphy(i) );
            U_AS_FORCE_DL_OFF_SBIF    : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, DL_OFF_SBIF_IN(i) , s_force_dl_off_sbif(i) );
            U_AS_FORCE_DL_OFF_BBCTRL  : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, DL_OFF_BBCTRL_IN(i) , s_force_dl_off_bbctrl(i) );
            U_AS_FORCE_DL_OFF_DSP     : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, DL_OFF_DSP_IN(i) , s_force_dl_off_dsp(i) );
            U_AS_FORCE_DL_OFF_DCIF    : ALM_SYNCH generic map('1') port map(rst, CLK_MISC3, DL_OFF_DCIF_IN(i) , s_force_dl_off_dcif(i) ); -- Not used
    end generate U_AS_FORCE_DL_OFF_ARY;

    DL_OFF_CPRI_NUM : for i in 0 to (CPRI_NUM-1) generate
        or_dl_off_cpriphy(i) <= ( i_dl_off_cpriphy(i) or s_force_dl_off_cpriphy(i) );
        or_dl_off_bbctrl(i)  <= ( i_dl_off_bbctrl(i) or s_force_dl_off_bbctrl(i) );
            U_AD_DL_OFF_CPRIPHY : ALM_DFF generic map('1') port map(rst, CLK_MISC3, or_dl_off_cpriphy(i) , SIG_SUS_DLOFF_CPRIPHY_OUT(i) );
            U_AD_DL_OFF_BBCTRL  : ALM_DFF generic map('1') port map(rst, CLK_MISC3, or_dl_off_bbctrl(i) , SIG_SUS_DLOFF_BBCTRL_OUT(i) );
    end generate DL_OFF_CPRI_NUM;

    DL_OFF_SBIF_NUM : for i in 0 to (SBIF_NUM-1) generate
        or_dl_off_sbifphy(i) <= ( i_dl_off_sbifphy(i) or s_force_dl_off_sbifphy(i) );
        or_dl_off_sbif(i)    <= ( i_dl_off_sbif(i) or s_force_dl_off_sbif(i) );
            U_AD_DL_OFF_SBIFPHY : ALM_DFF generic map('1') port map(rst, CLK_MISC3, or_dl_off_sbifphy(i) , SIG_SUS_DLOFF_SBIFPHY_OUT(i) );
            U_AD_DL_OFF_SBIF    : ALM_DFF generic map('1') port map(rst, CLK_MISC3, or_dl_off_sbif(i) , SIG_SUS_DLOFF_SBIF_OUT(i) );
    end generate DL_OFF_SBIF_NUM;

    DL_OFF_TXANT_NUM : for i in 0 to (TX_ANT_NUM-1) generate
        or_dl_off_dsp(i) <= ( i_dl_off_dsp(i) or s_force_dl_off_dsp(i) );
            U_AD_DL_OFF_DSP : ALM_DFF generic map('1') port map(rst, CLK_MISC3, or_dl_off_dsp(i) , SIG_SUS_DLOFF_DSP_OUT(i) );
    end generate DL_OFF_TXANT_NUM;

    SIG_SUS_B_OUT     <= sig_sus_b( TX_ANT_NUM-1 downto 0);
    SIG_SUS_R_OUT     <= sig_sus_r( TX_ANT_NUM-1 downto 0);
    LOG_SIG_SUS_B_OUT <= sig_sus_b( TX_ANT_NUM-1 downto 0);
    LOG_SIG_SUS_R_OUT <= sig_sus_r( TX_ANT_NUM-1 downto 0);





end ARC_SIG_SUS_TOP;
