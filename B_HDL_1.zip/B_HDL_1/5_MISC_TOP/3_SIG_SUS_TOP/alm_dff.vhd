
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;


entity alm_dff is
generic(
    ACTIVE_VALUE                : std_logic-- '1' : Active High, '0' : Active Low
);
port(
    RESET                       : in std_logic;
    CLK                         : in std_logic;

    ALARM_IN                    : in std_logic; 
    ALARM_OUT                   : out std_logic
);
end alm_dff;

architecture Behavioral of alm_dff is

signal i_alarm_d                : std_logic := '0';      

begin

    ALARM_OUT <= i_alarm_d;
    process(RESET, CLK)
    begin
        if(RESET = '1')then 
            i_alarm_d  <= '0';
        elsif(CLK'event and CLK = '1')then
            if ACTIVE_VALUE = '1' then      
                i_alarm_d  <= ALARM_IN;     -- Active High
            else                           
                i_alarm_d  <= not ALARM_IN; -- Active Low
            end if;
        end if;
    end process;

end Behavioral;

