-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
--use work.pkg_func.all;

entity RFIC_CAL_CTRL is
port (
    RESET                       : in  std_logic;
    CLK                         : in  std_logic;

    RF_SW_ON                    : in  std_logic;
    START_OF_TX                 : out std_logic;    
    END_OF_TX                   : out std_logic
);
end RFIC_CAL_CTRL;

architecture arc_RFIC_CAL_CTRL of RFIC_CAL_CTRL is

type state is                   (WAIT_RF_SW_ON, 
                                SET_START, 
                                WAIT_RF_SW_OFF, 
                                SET_END);
attribute syn_encoding          : string;
attribute syn_encoding of state : type is "one-hot, safe";
signal mon_state                : state;

signal clk_cnt                  : std_logic_vector(4 downto 0); -- for 16 clock counter
signal rf_sw_on_1d              : std_logic;
signal rf_sw_on_2d              : std_logic;

begin

process(RESET,CLK)
begin
    if RESET = '1' then
        rf_sw_on_1d <= '0';
        rf_sw_on_2d <= '0';
    elsif (CLK'event and CLK='1') then
        rf_sw_on_1d <= rf_sw_on_1d;
        rf_sw_on_2d <= RF_SW_ON;
    end if;
end process;

process(RESET,CLK)
begin
    if RESET = '1' then
        mon_state       <= WAIT_RF_SW_ON; 
        clk_cnt         <= (others => '0');
        START_OF_TX     <= '0';
        END_OF_TX       <= '0';
    elsif (CLK'event and CLK='1') then
        case mon_state is
        when WAIT_RF_SW_ON => -- init
            if rf_sw_on_2d = '1' then
                mon_state <= SET_START;
            end if;
            clk_cnt     <= (others => '0'); 
            START_OF_TX <= '0';
            END_OF_TX   <= '0';
        when SET_START => -- set cal start for 16 clock
            -- wait 16 clock for start minimum duration (16 clock)
            if clk_cnt(4) = '1' then
                mon_state <= WAIT_RF_SW_OFF;
            end if;
                
            if clk_cnt(4) = '1' then
                clk_cnt <= clk_cnt;
            else
                clk_cnt <= clk_cnt + 1;
            end if;
            START_OF_TX <= '1';
            END_OF_TX   <= '0';
        when WAIT_RF_SW_OFF => -- wait rf switch off for RFIC cal end signal
            if rf_sw_on_2d = '1' then
                mon_state <= WAIT_RF_SW_OFF;
            else
                mon_state <= SET_END;
            end if;
            clk_cnt     <= (others => '0'); 
            START_OF_TX <= '0';
            END_OF_TX   <= '0';
        when SET_END => 
            -- wait 16 clock for end minimum duration (16 clock)
            if clk_cnt(4) = '1' then
                mon_state <= WAIT_RF_SW_ON;
            end if;
                
            if clk_cnt(4) = '1' then
                clk_cnt <= clk_cnt;
            else
                clk_cnt <= clk_cnt + 1;
            end if;
            START_OF_TX <= '0';
            END_OF_TX   <= '1';
        when others =>
            mon_state       <= WAIT_RF_SW_ON; 
            clk_cnt         <= (others => '0');
            START_OF_TX     <= '0';
            END_OF_TX       <= '0';
        end case;
    end if;
end process;
   
end arc_RFIC_CAL_CTRL;
