
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;


entity err_debounce is
port(
    RESET                       : in std_logic;
    CLK                         : in std_logic;
    DEB_CNT                     : in std_logic_vector(19 downto 0); 

    ERROR_IN                    : in std_logic; 
    ERROR_DEBOUNCED             : out std_logic
);
end err_debounce;

architecture Behavioral of err_debounce is

type state is (IDLE_STATE, CATCH_STATE, LOCK_STATE);
attribute syn_encoding          : string;
attribute syn_encoding of state : type is "one-hot, safe";

signal unlock_detect_state      : state;

signal deb_cnt_r                : std_logic_vector(19 downto 0); 
signal detect_stay_cnt          : std_logic_vector(19 downto 0);

signal err_debounced_r          : std_logic;    

begin

    -- CDC, DEB_CNT should be set before reset release
    process(RESET, CLK)
    begin
        if(RESET = '1')then
            deb_cnt_r <= (others => '0');   
        elsif(CLK'event and CLK = '1')then
            deb_cnt_r <= DEB_CNT;   
        end if;
    end process;

    ERROR_DEBOUNCED     <= err_debounced_r or ERROR_IN;-- oring for preventing 1 clock delay
    process(RESET, CLK)
    begin
        if(RESET = '1')then
            unlock_detect_state <= IDLE_STATE;
            detect_stay_cnt     <= (others => '0');
            err_debounced_r     <= '0';
        elsif(CLK'event and CLK = '1')then
            case unlock_detect_state is
                when IDLE_STATE =>
                    if (ERROR_IN = '0')then
                        unlock_detect_state <= CATCH_STATE;
                    end if;
                    detect_stay_cnt     <= (others => '0');
                    err_debounced_r     <= '1';
                
                when CATCH_STATE =>
                    if(detect_stay_cnt = deb_cnt_r)then
                        detect_stay_cnt <= detect_stay_cnt;
                    else
                        detect_stay_cnt <= detect_stay_cnt + 1;
                    end if;
                    
                    if(ERROR_IN = '1')then
                        unlock_detect_state <= IDLE_STATE;
                        err_debounced_r     <= '1';                         
                    elsif(ERROR_IN = '0' and detect_stay_cnt = deb_cnt_r)then
                        unlock_detect_state <= LOCK_STATE;
                        err_debounced_r     <= '0';                         
                    end if;
                    
                when LOCK_STATE =>
                    if(ERROR_IN = '0')then
                        unlock_detect_state <= LOCK_STATE;
                        err_debounced_r     <= '0';                         
                    else
                        unlock_detect_state <= IDLE_STATE;
                        err_debounced_r     <= '1';
                    end if;

                    detect_stay_cnt     <= (others => '0');
                when others =>
                    unlock_detect_state <= IDLE_STATE;
                    detect_stay_cnt     <= (others => '0');
                    err_debounced_r     <= '1';
            end case;
        end if;
    end process;

end Behavioral;

