-- Tool versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
--use work.pkg_func.all;

entity TRCV_RFSW_ONOFF is
    port (
        RESET : in std_logic;
        CLK   : in std_logic;

        i_time_rf_switch : in std_logic_vector(10 downto 0);
        VSS_DAC_OFF      : in std_logic;
        DAC_OFF          : in std_logic;
        RFIC_ABN         : in std_logic;

        RF_SW_ONOFF : out std_logic
    );
end TRCV_RFSW_ONOFF;

architecture arc_TRCV_RFSW_ONOFF of TRCV_RFSW_ONOFF is

    signal r_time_rf_switch : std_logic_vector(10 downto 0);
    signal control_stat : std_logic_vector(2 downto 0);
    signal counter : std_logic_vector(10 downto 0); -- 2.56 usec, 200MHz
    signal i_rf_sw_onoff : std_logic;

begin

    RF_SW_ONOFF <= i_rf_sw_onoff;

    process(CLK)
    begin
        if (rising_edge(CLK)) then
            r_time_rf_switch <= i_time_rf_switch;
        end if;
    end process;
    process(RESET,CLK)
    begin
        if RESET = '1' then
            control_stat  <= "001"; -- off state
            counter       <= (others => '0');
            i_rf_sw_onoff <= '0';
        elsif (CLK'event and CLK='1') then
            case control_stat is
                when "001" => -- off state
                    if (VSS_DAC_OFF = '0') and (DAC_OFF = '0') and (RFIC_ABN = '0') then
                        control_stat <= "100";
                    else
                        control_stat <= "001";
                    end if;
                    counter       <= (others => '0');
                    i_rf_sw_onoff <= '0';

                when "100" => -- on state
                    if RFIC_ABN = '1' then
                        control_stat  <= "001";
                        i_rf_sw_onoff <= '0';
                    elsif DAC_OFF = '1' then
                        control_stat  <= "010";
                        i_rf_sw_onoff <= '1';
                    elsif VSS_DAC_OFF = '1' then
                        control_stat  <= "011";
                        i_rf_sw_onoff <= '1';
                    else
                        control_stat  <= control_stat;
                        i_rf_sw_onoff <= '1';
                    end if;
                    counter <= (others => '0');

                when "010" =>                -- off transition state (SS_B, SS_R)
                    if counter(9) = '1' then -- 2.56 us
                        control_stat <= "001";
                        counter      <= counter;
                    else
                        control_stat <= "010";
                        counter      <= counter + 1;
                    end if;
                    i_rf_sw_onoff <= '1';
                when "011" =>                          -- off transition state (uv alarm, watchdog)
                    if counter = r_time_rf_switch then -- 5.56 us (default value)
                        control_stat <= "001";
                        counter      <= counter;
                    else
                        control_stat <= "011";
                        counter      <= counter + 1;
                    end if;
                    i_rf_sw_onoff <= '1';

                when others =>
                    control_stat  <= "001"; -- off state
                    counter       <= (others => '0');
                    i_rf_sw_onoff <= '0';
            end case;
        end if;
    end process;


end arc_TRCV_RFSW_ONOFF;
