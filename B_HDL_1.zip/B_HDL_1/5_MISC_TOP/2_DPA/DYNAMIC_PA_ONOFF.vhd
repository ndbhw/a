--=================================================================================================
-- Designer            : seulkee.kim
-- Initial Coding Date : 
-- Revision Date       : 
-- Modification Date   : 
-- Description         : 
--=================================================================================================

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity DYNAMIC_PA_ONOFF is
	port(
    RESET                              : in  std_logic; -- DDUC CLK Sync.Reset						
    CLK                                : in  std_logic; -- DDUC CLK 245.76MHz

    DPA_EN                             : in  std_logic; -- Dynamic PA on/off enable

    CPU_PA_EN                          : in  std_logic; -- PA enable

    DPA_TRX_DATA_DELAY_TIME            : in  std_logic_vector(15 downto 0); -- resolution 1/245.76MHz
    DPA_RISE_RESP_TIME                 : in  std_logic_vector(15 downto 0); -- resolution 1/245.76MHz
    DPA_FALL_RESP_TIME                 : in  std_logic_vector(15 downto 0); -- resolution 1/245.76MHz
    DPA_OFF_MON_TIME                   : in  std_logic_vector(15 downto 0); -- resolution 1/245.76MHz

    IQ_ZERO_DET                        : in  std_logic; -- '1':IQ zero

    DPA_EN_CTRL                        : out std_logic -- '0': off, '1': on
	);
end DYNAMIC_PA_ONOFF;

architecture ARC_DYNAMIC_PA_ONOFF of DYNAMIC_PA_ONOFF is

    component dpram_1x8192 is
	PORT
	(
      clka                             : IN STD_LOGIC;
      ena                              : IN STD_LOGIC;
      wea                              : IN STD_LOGIC_VECTOR(0 DOWNTO 0);
      addra                            : IN STD_LOGIC_VECTOR(12 DOWNTO 0);
      dina                             : IN STD_LOGIC_VECTOR(0 DOWNTO 0);
      clkb                             : IN STD_LOGIC;
      enb                              : IN STD_LOGIC;
      addrb                            : IN STD_LOGIC_VECTOR(12 DOWNTO 0);
      doutb                            : OUT STD_LOGIC_VECTOR(0 DOWNTO 0)
	);
    end component;
    
    constant blk_processig_dly         : std_logic_vector(15 downto 0):=x"0006";

    signal dpa_en_r                    : std_logic_vector(1 downto 0);
    signal cpu_pa_en_r                 : std_logic_vector(1 downto 0);

    signal dpa_trx_data_delay_time_r   : std_logic_vector(15 downto 0);
    signal dpa_rise_resp_time_r        : std_logic_vector(15 downto 0);
    signal dpa_fall_resp_time_r        : std_logic_vector(15 downto 0);
    signal dpa_off_mon_time_r          : std_logic_vector(15 downto 0);

    signal dpa_trx_data_delay_time_val : std_logic_vector(15 downto 0);
    
    signal d_in_IQ_zero_det            : std_logic;
    signal d_in_IQ_zero_cnt            : std_logic_vector(15 downto 0);

    signal dynamic_pa_off              : std_logic;
    signal dynamic_pa_off_cnt          : std_logic_vector(15 downto 0);

    signal dpa_ctrl_dly_buf_d_in       : std_logic_vector(0 downto 0);
    signal dpa_ctrl_dly_buf_d_out      : std_logic_vector(0 downto 0);

    signal dpa_ctrl_dly_buf_wr_en      : std_logic_vector(0 downto 0);
    signal dpa_ctrl_dly_buf_waddr      : std_logic_vector(12 downto 0);
    signal dpa_ctrl_dly_buf_raddr      : std_logic_vector(12 downto 0);
    
begin

    process(RESET,CLK)
    begin
        if (RESET = '1') then
            dpa_en_r <= (others => '0');
            cpu_pa_en_r <= (others => '0');
        elsif rising_edge(CLK) then
            dpa_en_r <= dpa_en_r(0) & DPA_EN;
            cpu_pa_en_r <= cpu_pa_en_r(0) & CPU_PA_EN;
        end if;
    end process;
    

    process(RESET,CLK)
    begin
        if (RESET = '1') then
            dpa_trx_data_delay_time_r <= (others => '0');
            dpa_rise_resp_time_r <= (others => '0');
            dpa_fall_resp_time_r <= (others => '0');
            dpa_off_mon_time_r <= (others => '0');
        elsif rising_edge(CLK) then
            dpa_trx_data_delay_time_r <= DPA_TRX_DATA_DELAY_TIME;
            dpa_rise_resp_time_r <= DPA_RISE_RESP_TIME;
            dpa_fall_resp_time_r <= DPA_FALL_RESP_TIME;
            dpa_off_mon_time_r <= DPA_OFF_MON_TIME;
        end if;
    end process;

    process(RESET,CLK)
    begin
        if (RESET = '1') then
            dpa_trx_data_delay_time_val <= (others => '0');
        elsif rising_edge(CLK) then
            if (dpa_trx_data_delay_time_r(15 downto 3) = 0) then
                if (dpa_trx_data_delay_time_r(2 downto 0) < blk_processig_dly(2 downto 0)) then
                    dpa_trx_data_delay_time_val <= blk_processig_dly;
                else
                    dpa_trx_data_delay_time_val <= dpa_trx_data_delay_time_r;
                end if;
            else
                dpa_trx_data_delay_time_val <= dpa_trx_data_delay_time_r;
            end if;
        end if;
    end process;
    
    process(RESET,CLK)
    begin
        if (RESET = '1') then
            d_in_IQ_zero_det <= '0';
        elsif rising_edge(CLK) then
            if (dpa_en_r(1) = '1' and cpu_pa_en_r(1) = '1') then
                d_in_IQ_zero_det <= IQ_ZERO_DET;
            elsif (dpa_en_r(1) = '0' and cpu_pa_en_r(1) = '1') then
                d_in_IQ_zero_det <= '0';
            else
                d_in_IQ_zero_det <= '1';
            end if;
        end if;
    end process;

    process(RESET,CLK)
    begin
        if (RESET = '1') then
            d_in_IQ_zero_cnt <= (others => '0');
        elsif rising_edge(CLK) then
            if (d_in_IQ_zero_det = '1') then
                if (d_in_IQ_zero_cnt = dpa_off_mon_time_r + 1) then
                    d_in_IQ_zero_cnt <= d_in_IQ_zero_cnt;
                else
                    d_in_IQ_zero_cnt <= d_in_IQ_zero_cnt + 1;
                end if;
            else
                d_in_IQ_zero_cnt <= (others => '0');
            end if;
        end if;
    end process;

    process(RESET,CLK)
    begin
        if (RESET = '1') then
            dynamic_pa_off <= '0';
            dynamic_pa_off_cnt <= (others => '0');
        elsif rising_edge(CLK) then
            if (d_in_IQ_zero_cnt = dpa_off_mon_time_r + 1) then
                dynamic_pa_off <= '1';
                if (dynamic_pa_off_cnt = dpa_fall_resp_time_r) then
                    dynamic_pa_off_cnt <= dynamic_pa_off_cnt;
                else
                    dynamic_pa_off_cnt <= dynamic_pa_off_cnt + 1;
                end if;
            elsif (d_in_IQ_zero_cnt < dpa_fall_resp_time_r) then
                if (dynamic_pa_off_cnt = dpa_fall_resp_time_r) then
                    dynamic_pa_off_cnt <= dynamic_pa_off_cnt;
                    dynamic_pa_off <= '0';
                else
                    dynamic_pa_off_cnt <= dynamic_pa_off_cnt + 1;
                    dynamic_pa_off <= dynamic_pa_off;
                end if;
            else
                dynamic_pa_off_cnt <= (others => '0');
                dynamic_pa_off <= '0';
            end if;
        end if;
    end process;

    dpa_ctrl_dly_buf_d_in(0) <= not dynamic_pa_off;

    process(RESET,CLK)
    begin
        if (RESET = '1') then
            dpa_ctrl_dly_buf_wr_en <= (others => '0');
            dpa_ctrl_dly_buf_waddr <= (others => '0');
        elsif rising_edge(CLK) then
            dpa_ctrl_dly_buf_wr_en(0) <= '1';
            dpa_ctrl_dly_buf_waddr <= dpa_ctrl_dly_buf_waddr + 1;
        end if;
    end process;

    process(RESET,CLK)
    begin
        if (RESET = '1') then
            dpa_ctrl_dly_buf_raddr <= "1000000000000";
        elsif rising_edge(CLK) then
            if (dpa_ctrl_dly_buf_waddr = dpa_trx_data_delay_time_val(12 downto 0) - dpa_rise_resp_time_r(12 downto 0) - blk_processig_dly(12 downto 0)) then
                dpa_ctrl_dly_buf_raddr <= (others => '0');
            else
                dpa_ctrl_dly_buf_raddr <= dpa_ctrl_dly_buf_raddr + 1;
            end if;
        end if;
    end process;

    DPA_EN_CTRL <= dpa_ctrl_dly_buf_d_out(0);

    u_dpa_ctrl_dly_buf : dpram_1x8192 
	PORT map
	(
      clka                             => CLK                              , -- : IN STD_LOGIC;
      ena                              => '1'                              , -- : IN STD_LOGIC;
      wea                              => dpa_ctrl_dly_buf_wr_en           , -- : IN STD_LOGIC_VECTOR(0 DOWNTO 0);
      addra                            => dpa_ctrl_dly_buf_waddr           , -- : IN STD_LOGIC_VECTOR(12 DOWNTO 0);
      dina                             => dpa_ctrl_dly_buf_d_in            , -- : IN STD_LOGIC;
      clkb                             => CLK                              , -- : IN STD_LOGIC;
      enb                              => '1'                              , -- : IN STD_LOGIC;
      addrb                            => dpa_ctrl_dly_buf_raddr           , -- : IN STD_LOGIC_VECTOR(12 DOWNTO 0);
      doutb                            => dpa_ctrl_dly_buf_d_out             -- : OUT STD_LOGIC
	);
    

end ARC_DYNAMIC_PA_ONOFF;
