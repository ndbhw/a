# Core717 rev 1.91 → 1.92: các chỗ sửa phần TX và RX
Cũ: `in/Core717_ARINC717_AXI_Lite_Spec_rev1.91.docx` · Mới: `Core717_ARINC717_AXI_Lite_Spec_rev1.92.docx`. Kiểm tra: merge nhánh TX 1.91 (20 op) + TX 1 vòng + RX 1 vòng; regress TX 28 + RX 18 dòng PASS trên bản mới; mô hình model_717_tx / model_717_rx (rev 1.91 + sửa, SyncRx mới), replay TX 173 ô và RX 547 ô 0 FAIL; cases TX --big 19 PASS, RX --big 5 PASS; changelog 39 thay đổi, 0 ngoài danh sách sửa.
Cách đọc hình: mỗi cột = một sườn clock của miền đang xét (sample_tick / bit cell / core_clk / s_axi_clk / word / thao tác, ghi trong hình); hình "a" = hoạt động theo tài liệu cũ (vùng lỗ hổng tô đỏ, nét đứt xám = giá trị đúng), hình "b" = sau khi sửa (cùng kịch bản, cùng số cột). Số liệu trong hình đều được assert trong tools/fig_717_tx.py / fig_717_rx.py.

## Tóm tắt
| # | Issue | Phần | Vấn đề (1 dòng) | Loại | Mức | Section sửa (trang cũ → mới) | Hình |
|---|---|---|---|---|---|---|---|
| 1 | TX:I01 | TX | Resume giữa subframe sau underrun: RX lệch bit, word sai không cờ (hành vi) | SILENT_WRONG | TB | §3.1.4 (22 → 22), §3.2.4.7 (69 → 69) | [a](fig/TX_I01_a_old.svg) [b](fig/TX_I01_b_new.svg) |
| 2 | TX:I02 | TX | Figure 5: BPRZ chậm 1 cell so với HBP khi đọc đúng chữ (hình trái bảng) | SPEC | TB | §3.1.6 (29 → 29) | [a](fig/TX_I02_a_old.svg) [b](fig/TX_I02_b_new.svg) |
| 3 | TX:I03 | TX | "registered fifo_empty flag" mâu thuẫn với empty = (rptr == wptr_s) (xung đột + hành vi) | SPEC | TB | §3.1.4 (23 → 23) | [a](fig/TX_I03_a_old.svg) [b](fig/TX_I03_b_new.svg) |
| 4 | TX:I04 | TX | TX_BIT_CNT đếm cả bit_tick của underrun (con số sai) | C1 | Thấp | §7.3 (89 → 89) | [a](fig/TX_I04_a_old.svg) [b](fig/TX_I04_b_new.svg) |
| 5 | TX:I05 | TX | "exactly one sample period after entry" không rơi vào cạnh clock (con số) | C3 | Thấp | §3.1.4 (23 → 23) | [a](fig/TX_I05_a_old.svg) [b](fig/TX_I05_b_new.svg) |
| 6 | TX:I06 | TX | subframe_start là mức nhưng §3.1.3 viết như sự kiện (xung đột) | S-e | Thấp | §3.1.3 (21 → 21), §3.1.3 (21 → 21), §13.1 (113 → 113) | [a](fig/TX_I06_a_old.svg) [b](fig/TX_I06_b_new.svg) |
| 7 | TX:I07 | TX | INJ_START ngay sau TX_EN bị bỏ, firmware chờ INJ_DONE treo (hành vi) | C1,C2,C3 | Cao | §4.2.2 (78 → 78), §7.4 (92 → 92) | [a](fig/TX_I07_a_old.svg) [b](fig/TX_I07_b_new.svg) |
| 8 | TX:I08 | TX | "No underrun can occur between the last push and the end of the last word" sai khi push cuối muộn (xung đột) | C1,C3,C9 | TB | §3.1.7 (30 → 30), §13.5 (128 → 128), §13.6 (138 → 138) | [a](fig/TX_I08_a_old.svg) [b](fig/TX_I08_b_new.svg) |
| 9 | TX:I09 | TX | Table 71 bước 10 không xóa ST_UNDERRUN trước rate mới (thủ tục) | C8,C9 | TB | §13.6 (139 → 139) | [a](fig/TX_I09_a_old.svg) [b](fig/TX_I09_b_new.svg) |
| 10 | TX:I10 | TX | RX_RD_DATA "!EMPTY -> OKAY" thiếu CLR_BUSY / axi_ready (xung đột) | C1,C6 | TB | §7.6 (95 → 95), §11 (109 → 109), §13.1 (113 → 113) | [a](fig/TX_I10_a_old.svg) [b](fig/TX_I10_b_new.svg) |
| 11 | TX:I11 | TX | Ngưỡng đọc ST_UNDERRUN cuối stream là câu lặp nghĩa (bản trung gian của vòng TX trước) | S-e | Thấp | §3.1.7 (30 → 30) | [a](fig/TX_I11_a_old.svg) [b](fig/TX_I11_b_new.svg) |
| 12 | TX:I12 | TX | Sau merge: Table 71 bước 10 khác chữ bước 7–9 (xung đột trong bản merge) | C8,C9,S-b | TB | §13.6 (139 → 139) | [a](fig/TX_I12_a_old.svg) [b](fig/TX_I12_b_new.svg) |
| 13 | RX:I01 | RX | Table 63 "line dead for good": reason code 3 cho mọi chế độ (vector không thể pass) | C9,C1 | Cao | §13.3 (118 → 118), §13.5 (129 → 129) | [a](fig/RX_I01_a_old.svg) [b](fig/RX_I01_b_new.svg) |
| 14 | RX:I02 | RX | MATCH so "running word counter" ở Table 37 / §7.4 nhưng so word đang được nhận ở §3.2.3.1 (xung đột) | C1,C2 | TB | §7.4 (91 → 91), §7.4 (91 → 91) | [a](fig/RX_I02_a_old.svg) [b](fig/RX_I02_b_new.svg) |
| 15 | RX:I03 | RX | MATCH "at most one word-time" sai với lock word khi ERRCHK_ENB = 1 (con số) | C3,C9 | TB | §3.2.3.1 (61 → 61), §3.2.3.1 (62 → 63), §7.4 (91 → 91), §10.2 (105 → 105), §13.2 (116 → 116) | [a](fig/RX_I03_a_old.svg) [b](fig/RX_I03_b_new.svg) |
| 16 | RX:I04 | RX | NOSYNC: dây dừng sau data → word 0x000 thừa vào RX FIFO (hành vi chưa nêu) | C2,C8 | Cao | §3.2.2.4 (60 → 60) | [a](fig/RX_I04_a_old.svg) [b](fig/RX_I04_b_new.svg) |
| 17 | RX:I05 | RX | rxsel_eff (RXSEL OR rsel) chưa lan tới §2.2, TP4 và các test hai format (closure) | C1,C9 | TB | §2.2 (14 → 14), §13.4.2 (127 → 127), §13.5 (128 → 128), §13.5 (130 → 130), §13.5 (130 → 130), §13.5 (131 → 131) | [a](fig/RX_I05_a_old.svg) [b](fig/RX_I05_b_new.svg) |
| 18 | RX:I06 | RX | INSYNC rơi do rx_active vẫn được mô tả là mất sync (closure) | C1,C7 | TB | §7.4 (91 → 91), §8.2 (97 → 97), §10.5 (108 → 108), §13.2 (116 → 117) | [a](fig/RX_I06_a_old.svg) [b](fig/RX_I06_b_new.svg) |
| 19 | RX:I07 | RX | Watchdog làm INSYNC rơi ở tick (16 + MARGIN) × 12 × W + 1, test ghi "no later than (16 + MARGIN) × 12 × W" (con số) | C3,C9,S-c | TB | §3.2.4.8 (70 → 70), §13.5 (129 → 129) | [a](fig/RX_I07_a_old.svg) [b](fig/RX_I07_b_new.svg) |

---
## 1. TX:I01 — Resume giữa subframe sau underrun: RX lệch bit, word sai không cờ (hành vi)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 3.1.4 → trang 22:
> When the host later pushes new data into the FIFO, the Timing Generator resumes from the frozen count (mid-subframe or mid-frame) and the FSM continues transmission without forcing a return to subframe 0.

(B) Section 3.2.4.7 → trang 69:
> The sync word is the only word that is checked against a known value. A real bad bit in it changes the code and costs the lock; a new lock takes up to about 8 s. A flag set only by the back-dating of HBP (a bad first cell of the word after the sync word) does not matter when the code matches. Words between a bit shift and the next sync word check are still delivered without flag when the shift itself raised no error (for example a legal-looking glitch); the sync word check then finds it at the next subframe. Software therefore shall treat the words delivered since the last good sync word as suspect when ST_INSYNC_LOST is raised by the sync word check.

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I01a](fig/TX_I01_a_old.svg)
BPRZ, W = 64: FIFO rỗng sau word 0.38, word kế vào sau 1 cell. TX tiếp tục từ vị trí đã giữ, RX vẫn đếm bit cell → placeholder ở word 0.39 (có cờ), rồi word 0.40..0.63 lệch 1 bit (0.40 gửi 0x028, nhận 0x050) mà không có cờ; INSYNC chỉ rơi ở word 0 của subframe 1 (LOST_CAUSE 01). Tài liệu cũ không nói hệ quả này, §3.2.4.7 còn hứa "flags the words at the cut".

**Lý do sửa và cách sửa:** Người dùng chọn ghi rõ giới hạn, không đổi phần cứng (vòng TX trước). Sửa ở chỗ định nghĩa resume (§3.1.4) và ở danh sách giới hạn RX (§3.2.4.7); closure: 2 chỗ sửa, các chỗ còn lại nhất quán (TX-04, §3.1.7, TP3). Ops: K1-10; K1-11.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§3.1.4): When the host later … return to subframe 0. **The receiver sees the pause as a gap in the bit stream and keeps counting bit cells, so the words that follow up to the next sync word can be shifted and delivered without flag; the sync word check then ends INSYNC at the next subframe (Section 3.2.4.7).**
> When the host later pushes new data into the FIFO, the Timing Generator resumes from the frozen count (mid-subframe or mid-frame) and the FSM continues transmission without forcing a return to subframe 0. The receiver sees the pause as a gap in the bit stream and keeps counting bit cells, so the words that follow up to the next sync word can be shifted and delivered without flag; the sync word check then ends INSYNC at the next subframe (Section 3.2.4.7).
(trang 22)

Chỗ đổi (§3.2.4.7): The sync word is … (for example a legal-looking ~~glitch);~~ **glitch), and can be delivered without flag after a pause of the transmitter (underrun and resume, Section 3.1.4);** the sync word check … the sync word check.
> The sync word is the only word that is checked against a known value. A real bad bit in it changes the code and costs the lock; a new lock takes up to about 8 s. A flag set only by the back-dating of HBP (a bad first cell of the word after the sync word) does not matter when the code matches. Words between a bit shift and the next sync word check are still delivered without flag when the shift itself raised no error (for example a legal-looking glitch), and can be delivered without flag after a pause of the transmitter (underrun and resume, Section 3.1.4); the sync word check then finds it at the next subframe. Software therefore shall treat the words delivered since the last good sync word as suspect when ST_INSYNC_LOST is raised by the sync word check.
(trang 69)

**Hoạt động sau khi sửa:**
![Hình I01b](fig/TX_I01_b_new.svg)
Cùng kịch bản, cùng 24 word lệch; nay tài liệu nói rõ các word tới sync word kế có thể lệch và không cờ, và quy tắc phần mềm coi các word từ sync word tốt cuối là nghi ngờ khi ST_INSYNC_LOST.

**Kiểm chứng:** regress RI01-1,RI01-2 PASS (TX 28 + RX 18 dòng trên bản 1.92); sweep underrun 9648 ca: 4724 DETECTED, 240 OK, 4684 SILENT_WRONG (pause ≥ 11 sample; đúng giới hạn đã khai báo); cặp hình TX_I01 assert PASS.

---
## 2. TX:I02 — Figure 5: BPRZ chậm 1 cell so với HBP khi đọc đúng chữ (hình trái bảng)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 3.1.6 → trang 29:
> During the first half of the bit cell the encoder drives One if the data bit = 1, or Zero if the data bit = 0.

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I02a](fig/TX_I02_a_old.svg)
Word 0x247, 64 wps. Figure 5 cũ ghi "cell_start: BPRZ = tx_bit ? ONE : ZERO" cùng quy tắc "All registers update at the end of the clock": BPRZ thấy tx_bit trước LOAD → cell 0 là Zero (Table 61: One), cell 3 là One (Table 61: Zero); cell k mang bit k − 1.

**Lý do sửa và cách sửa:** Table 61 (vector tài liệu) quyết định thời điểm: sửa câu §3.1.6 ("the value that tx_bit takes at the cell_start of that cell") và vẽ lại Figure 5 (ảnh cũ `fig/doc_Figure5_rev1.91.png`, mới `fig/doc_Figure5_rev1.92.png`). Ops: K1-12.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§3.1.6): During the first half … data bit = 0. **The data bit is the value that tx_bit takes at the cell_start of that cell (Section 3.1.4, Figure 5).**
> During the first half of the bit cell the encoder drives One if the data bit = 1, or Zero if the data bit = 0. The data bit is the value that tx_bit takes at the cell_start of that cell (Section 3.1.4, Figure 5).
(trang 29)

Figure 5: cũ `fig/doc_Figure5_rev1.91.png` → mới `fig/doc_Figure5_rev1.92.png` (op K1-13).

**Hoạt động sau khi sửa:**
![Hình I02b](fig/TX_I02_b_new.svg)
Cell k mang bit k ở cả HBP và BPRZ: cell 0..4 = One One One Zero Zero như Table 61.

**Kiểm chứng:** regress RI02-1 PASS (TX 28 + RX 18 dòng trên bản 1.92); replay TX 173 ô 0 FAIL (Table 61), mutation bprz_old FAIL; cặp hình TX_I02 assert PASS.

---
## 3. TX:I03 — "registered fifo_empty flag" mâu thuẫn với empty = (rptr == wptr_s) (xung đột + hành vi)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 3.1.4 → trang 23:
> At word_tick the FSM and the Generator sample the same registered fifo_empty flag in the same clock cycle, so no extra handshake signal is needed (there is no tx_run or load_pulse).

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I03a](fig/TX_I03_a_old.svg)
4096 wps, TX_FIFO_CLEAR có hiệu lực 1 core_clk trước word_tick t. Đọc "registered" = một flop: ở clock t cờ còn 0 → LOAD đọc mem[0] = 0x247 cũ và pop trên FIFO rỗng; không underrun ở t, trái §5.2 "at the next word_tick the Generator sees fifo_empty = 1 and freezes".

**Lý do sửa và cách sửa:** Chỉ có một cờ: empty tổ hợp của §4.2.5. Sửa §3.1.4 thành "the same fifo_empty flag (the core-side empty of Section 4.2.5)"; closure: §4.2.5, §10.5 đã nhất quán. Ops: K1-14.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§3.1.4): At word_tick the FSM … Generator sample the same ~~registered~~  fifo_empty flag **(the core-side empty of Section 4.2.5)** in the same clock … no tx_run or load_pulse).
> At word_tick the FSM and the Generator sample the same fifo_empty flag (the core-side empty of Section 4.2.5) in the same clock cycle, so no extra handshake signal is needed (there is no tx_run or load_pulse).
(trang 23)

**Hoạt động sau khi sửa:**
![Hình I03b](fig/TX_I03_b_new.svg)
Cùng clock t: fifo_empty = 1 → underrun, GEN_FROZEN, không word nào bị phát sau clear.

**Kiểm chứng:** regress RI03-1 PASS (TX 28 + RX 18 dòng trên bản 1.92); cases F3; cặp hình TX_I03 assert PASS.

---
## 4. TX:I04 — TX_BIT_CNT đếm cả bit_tick của underrun (con số sai)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 7.3 → trang 89:
> TX word and bit counters (TX base + 0x30 to 0x38, address offset 0x0050 to 0x0058). TX_WORD_CNT counts the words started by the TX path: one count at every word_tick that loads a word, whether it comes from the TX FIFO or is a sync word inserted by hardware (SYNC_INS_MODE = 1). TX_BIT_CNT counts the bit cells started: one count at every bit_tick while a word is being sent. After the word_tick of word n the counters read TX_WORD_CNT = n and TX_BIT_CNT = 12 x (n - 1) + 1; after the last bit cell of word n, TX_BIT_CNT = 12 x n.

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I04a](fig/TX_I04_a_old.svg)
64 wps, 2 word rồi underrun, word 3 vào sau 1 cell. Câu cũ "one count at every bit_tick while a word is being sent": word_tick underrun là bit_tick ngay sau cell 11 của word 2 khi FSM còn SHIFT → TX_BIT_CNT = 25 ≠ 12 × 2; sau 4 cell của word 3 là 29 thay vì 28.

**Lý do sửa và cách sửa:** Định nghĩa theo cell_start (bảng §7.3 "Number of bit cells started"): "one count at every cell_start"; closure: TX-06, §13.5 nhất quán. Ops: K1-15.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§7.3): TX word and bit … one count at every ~~bit_tick while a word is being sent.~~ **cell_start (Section 3.1.4).** After the word_tick of … = 12 x n.
> TX word and bit counters (TX base + 0x30 to 0x38, address offset 0x0050 to 0x0058). TX_WORD_CNT counts the words started by the TX path: one count at every word_tick that loads a word, whether it comes from the TX FIFO or is a sync word inserted by hardware (SYNC_INS_MODE = 1). TX_BIT_CNT counts the bit cells started: one count at every cell_start (Section 3.1.4). After the word_tick of word n the counters read TX_WORD_CNT = n and TX_BIT_CNT = 12 x (n - 1) + 1; after the last bit cell of word n, TX_BIT_CNT = 12 x n.
(trang 89)

**Hoạt động sau khi sửa:**
![Hình I04b](fig/TX_I04_b_new.svg)
TX_BIT_CNT = 24 sau 2 word và 28 sau 4 cell của word 3.

**Kiểm chứng:** regress RI04-1,RI04-2 PASS (TX 28 + RX 18 dòng trên bản 1.92); cases C12; cặp hình TX_I04 assert PASS.

---
## 5. TX:I05 — "exactly one sample period after entry" không rơi vào cạnh clock (con số)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 3.1.4 → trang 23:
> GEN_RUN – strobes are generated. Entered from GEN_OFF or GEN_FROZEN when tx_active = 1 and fifo_empty = 0. On entry acc = 0, phase = 0, bit_cnt = 0, so the first sample_tick (and with it the first bit_tick and word_tick, which coincide) arrives exactly one sample period after entry. This latency is deterministic after every start and every resume.

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I05a](fig/TX_I05_a_old.svg)
64 wps: một sample period = 3906.25 core_clk. Mốc "exactly" kiểm tick ở e + 3906 thì acc = 47 996 928 < 48 000 000: không có tick; tick thật ở e + 3907.

**Lý do sửa và cách sửa:** Sửa §3.1.4: "one sample period after entry, rounded up to a whole core_clk (3907 clocks at 64 wps)", khớp Table 66. Ops: K1-16.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§3.1.4): GEN_RUN – strobes are … word_tick, which coincide) arrives ~~exactly~~  one sample period after ~~entry.~~ **entry, rounded up to a whole core_clk (3907 clocks at 64 wps).** This latency is deterministic … start and every resume.
> GEN_RUN – strobes are generated. Entered from GEN_OFF or GEN_FROZEN when tx_active = 1 and fifo_empty = 0. On entry acc = 0, phase = 0, bit_cnt = 0, so the first sample_tick (and with it the first bit_tick and word_tick, which coincide) arrives one sample period after entry, rounded up to a whole core_clk (3907 clocks at 64 wps). This latency is deterministic after every start and every resume.
(trang 23)

**Hoạt động sau khi sửa:**
![Hình I05b](fig/TX_I05_b_new.svg)
Tick đầu ở e + 3907 = ceil(3906.25) sau mỗi lần vào GEN_RUN.

**Kiểm chứng:** regress RI05-1 PASS (TX 28 + RX 18 dòng trên bản 1.92); cases C03, replay TX; cặp hình TX_I05 assert PASS.

---
## 6. TX:I06 — subframe_start là mức nhưng §3.1.3 viết như sự kiện (xung đột)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 3.1.3 → trang 21:
> When the TX Timing Generator asserts subframe_start and the TX FIFO is not empty, the TX FSM parallel-loads:

(B) Section 3.1.3 → trang 21:
> If the FIFO is empty at subframe_start, no sync is inserted and the Timing Generator freezes (see Section 3.1.4) until data arrives.

(C) Section 13.1 → trang 113:
> RX EMPTY pop -> SLVERR; !EMPTY -> OKAY + data.
> SYNC_INS_MODE=1 inserts SYNCx only if FIFO not empty at subframe_start.

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I06a](fig/TX_I06_a_old.svg)
SYNC_INS_MODE = 1, 64 wps: subframe_start = 1 suốt word 63. Đọc "When the TX Timing Generator asserts subframe_start ... parallel-loads" như cạnh lên → SYNC2 nạp đè word 63 (0x13F), subframe sau lệch 1 word.

**Lý do sửa và cách sửa:** LOAD chỉ xảy ra ở word_tick (§3.1.4): sửa §3.1.3 (2 câu) và checklist §13.1 thành "at a word_tick with subframe_start = 1". Ops: K1-17; K1-18; K1-09, K1-19.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§3.1.3): ~~When the TX Timing Generator asserts~~ **At a word_tick with** subframe_start **= 1 (Section 3.1.4)** and the TX FIFO ~~is~~  not empty, the TX FSM parallel-loads:
> At a word_tick with subframe_start = 1 (Section 3.1.4) and the TX FIFO not empty, the TX FSM parallel-loads:
(trang 21)

Chỗ đổi (§3.1.3): If the FIFO is empty at ~~subframe_start,~~ **that word_tick,** no sync is inserted … 3.1.4) until data arrives.
> If the FIFO is empty at that word_tick, no sync is inserted and the Timing Generator freezes (see Section 3.1.4) until data arrives.
(trang 21)

Chỗ đổi (§13.1): ~~RX EMPTY pop~~ **RX_RD_DATA read while EMPTY, CLR_BUSY = 1 or axi_ready = 0** -> ~~SLVERR; !EMPTY~~ **SLVERR, no pop; !EMPTY, CLR_BUSY = 0 and axi_ready = 1** -> OKAY + data.
Chỗ đổi (§13.1): SYNC_INS_MODE=1 inserts SYNCx only … FIFO not empty at ~~subframe_start.~~ **the word_tick with subframe_start = 1.**
> RX_RD_DATA read while EMPTY, CLR_BUSY = 1 or axi_ready = 0 -> SLVERR, no pop; !EMPTY, CLR_BUSY = 0 and axi_ready = 1 -> OKAY + data.
> SYNC_INS_MODE=1 inserts SYNCx only if FIFO not empty at the word_tick with subframe_start = 1.
(trang 113)

**Hoạt động sau khi sửa:**
![Hình I06b](fig/TX_I06_b_new.svg)
Word 63 phát đủ, SYNC2 là word 0 của subframe 1 đúng vị trí.

**Kiểm chứng:** regress RI06-1 PASS (TX 28 + RX 18 dòng trên bản 1.92); -; cặp hình TX_I06 assert PASS.

---
## 7. TX:I07 — INJ_START ngay sau TX_EN bị bỏ, firmware chờ INJ_DONE treo (hành vi)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 4.2.2 → trang 78:
> Write order (normative). The hardware does not hold an enable back, so software shall configure first and enable last: (1) write the bundle fields (TX_RATE, RX_RATE, the sync codes, WRDCNT, RX_ERR_LIMIT, RX_SYNC_WD); (2) write the single-bit controls (SYNC_INS_MODE, RXSEL, NOSYNC, SFTSYNC, TEST, ERRCHK_ENB, INJ_DST, INJ_MODE) in any order; (3) poll GLOBAL_STATUS.CFG_PENDING until it is 0; (4) write the enables (GLOBAL_EN, TX_EN, RX_EN and INJ_EN) in a later AXI write. If an enable is written before CFG_PENDING = 0, the path can start with the old TX_RATE or the old sync codes. INJ_DST shall be written before INJ_EN, and INJ_START shall be written after INJ_EN (Section 13.7.5); the start event is delayed by the same one core_clk as the enables, so it is always seen after the controls written before it.

(B) Section 7.4 → trang 92:
> 1 | INJ_START | 0 | Write 1 starts a run; always reads 0. INJ_START is not part of the configuration bundle: a write of 1 toggles inj_start_req, which the s_axi side sends to core_clk only when no configuration handshake is pending (GLOBAL_STATUS.CFG_PENDING = 0), and it is delayed by the same one core_clk as the enables (Section 4.2.2), so the start is always seen after the INJ_EN and INJ_DST values written before it; every write of 1 gives exactly one start event. Ignored if the applied INJ_EN = 0, INJ_BUSY = 1 or the destination path is inactive at the start event (tx_active = 0 for INJ_DST = 0, rx_active = 0 for INJ_DST = 1, Section 2.4): the start is not held and INJ_BUSY stays 0. The enable of the destination shall be set before the start (RX_EN for INJ_DST = 1, TX_EN for INJ_DST = 0).

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I07a](fig/TX_I07_a_old.svg)
INJ_DST = 0: hai 2FF giao TX_EN và INJ_START lệch 1 core_clk theo thứ tự ngược (§4.2.2). Start trễ "the same one core_clk as the enables" → sự kiện ở clock 5, tx_active lên ở clock 6 → "ignored ... not held", INJ_BUSY = 0 mãi.

**Lý do sửa và cách sửa:** Người dùng chọn sửa phần cứng: start trễ 2 core_clk, hơn enable 1. Sửa Table 38 và §4.2.2; số học: hai synchronizer lệch tối đa 1 core_clk. Ops: K1-02; K1-01.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§4.2.2): Write order (normative). The … event is delayed by ~~the same~~  one core_clk ~~as~~ **more than** the ~~enables,~~ **enables (Table 38),** so it is ~~always~~ **never** seen ~~after~~ **before** the controls **and the enables** written ~~before it.~~ **in earlier AXI writes.**
> Write order (normative). The hardware does not hold an enable back, so software shall configure first and enable last: (1) write the bundle fields (TX_RATE, RX_RATE, the sync codes, WRDCNT, RX_ERR_LIMIT, RX_SYNC_WD); (2) write the single-bit controls (SYNC_INS_MODE, RXSEL, NOSYNC, SFTSYNC, TEST, ERRCHK_ENB, INJ_DST, INJ_MODE) in any order; (3) poll GLOBAL_STATUS.CFG_PENDING until it is 0; (4) write the enables (GLOBAL_EN, TX_EN, RX_EN and INJ_EN) in a later AXI write. If an enable is written before CFG_PENDING = 0, the path can start with the old TX_RATE or the old sync codes. INJ_DST shall be written before INJ_EN, and INJ_START shall be written after INJ_EN (Section 13.7.5); the start event is delayed by one core_clk more than the enables (Table 38), so it is never seen before the controls and the enables written in earlier AXI writes.
(trang 78)

Chỗ đổi (§7.4): 1 | INJ_START | … (GLOBAL_STATUS.CFG_PENDING = 0), and **after its synchronizer** it is delayed by **two core_clk, one more than** the ~~same~~ **enables (tx_en_q, rx_en_q, Section 4.2.2), because the synchronizers of two AXI writes can deliver them** one core_clk ~~as~~ **apart in** the ~~enables (Section 4.2.2),~~ **opposite order;** so the start **event** is ~~always~~ **never** seen ~~after~~ **before** the INJ_EN and INJ_DST values **and the enables** written ~~before it;~~ **in earlier AXI writes;** every write of 1 … for INJ_DST = 0).
> 1 | INJ_START | 0 | Write 1 starts a run; always reads 0. INJ_START is not part of the configuration bundle: a write of 1 toggles inj_start_req, which the s_axi side sends to core_clk only when no configuration handshake is pending (GLOBAL_STATUS.CFG_PENDING = 0), and after its synchronizer it is delayed by two core_clk, one more than the enables (tx_en_q, rx_en_q, Section 4.2.2), because the synchronizers of two AXI writes can deliver them one core_clk apart in the opposite order; so the start event is never seen before the INJ_EN and INJ_DST values and the enables written in earlier AXI writes; every write of 1 gives exactly one start event. Ignored if the applied INJ_EN = 0, INJ_BUSY = 1 or the destination path is inactive at the start event (tx_active = 0 for INJ_DST = 0, rx_active = 0 for INJ_DST = 1, Section 2.4): the start is not held and INJ_BUSY stays 0. The enable of the destination shall be set before the start (RX_EN for INJ_DST = 1, TX_EN for INJ_DST = 0).
(trang 92)

**Hoạt động sau khi sửa:**
![Hình I07b](fig/TX_I07_b_new.svg)
Start ở clock 6, cùng clock tx_active = 1: run luôn bắt đầu.

**Kiểm chứng:** regress RI07-1,RI07-2,RI07-3 PASS (TX 28 + RX 18 dòng trên bản 1.92); -; cặp hình TX_I07 assert PASS.

---
## 8. TX:I08 — "No underrun can occur between the last push and the end of the last word" sai khi push cuối muộn (xung đột)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 3.1.7 → trang 30:
> The host shall keep the TX FIFO from running empty while a stream is being sent: if it is empty at a word_tick the transmitter pauses (underrun, GEN_FROZEN, Section 3.1.4) until the next word is written. After the last word of a finite stream the FIFO is empty at the next word_tick, so the transmitter freezes and ST_UNDERRUN is set: this is the normal end of a transmission, not a host error. No underrun can occur between the last push and the end of the last word, so software that checks for underruns reads ST_UNDERRUN right after the last push, and clears it by W1C before the next stream. At subframe boundaries the host is still responsible for supplying the correct sync mark as the first word of the new subframe.

(B) Section 13.5 → trang 128:
> TX-05 | S, B | TP1 -> TP3 | SYNC_INS_MODE = 1, firmware refill on ST_LOW (FIFO filled to FIFO_DEPTH/2 words or more before TX_EN and after every refill); RX_RATE = TX_RATE = 0110 (the highest required rate) | Host rule of Section 3.1.7: keep at least 2 words queued, fill to FIFO_DEPTH/2 words or more and refill on ST_LOW, 10 subframes. No underrun (no GEN_FROZEN) and no gap between words before the last word (ST_UNDERRUN = 0 read right after the last push); the freeze after the last word is the normal end of the stream (Section 3.1.7) | REQ-TX-06, REQ-TX-02

(C) Section 13.6 → trang 138:
> 3 | Push at least FIFO_DEPTH/2 words of S1 (ST_LOW is an edge), then set TX_EN (Section 3.1.7); send S1 (lead-in word, then 6 subframes of a sync word and 63 P_COUNT words, 385 words in all); keep at least 2 words queued and refill on ST_LOW back to FIFO_DEPTH/2 words or more, or poll TX_STATUS.HALF (REQ-TX-06) | No TX underrun before the last word of S1: ST_UNDERRUN (TX_IRQ_STATUS[3]) = 0 when read right after the last push (the underrun after the last word is the normal end of the stream, Section 3.1.7)

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I08a](fig/TX_I08_a_old.svg)
4096 wps: push cuối 2 core_clk trước word_tick t khi FIFO đã rỗng, qua CDC 3 clk → underrun ở t, trước word cuối. Đọc ST_UNDERRUN "right after the last push" (TX-05, Table 71 bước 3 cũ) ở t − 1 thấy 0: bỏ sót.

**Lý do sửa và cách sửa:** Điều kiện hóa câu §3.1.7 theo host rule và đổi điểm đọc thành "while the last word is being sent"; TX-05 và Table 71 bước 3 dùng cùng chữ. Ops: K1-03, K2-01; K1-04; K1-05.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§3.1.7): The host shall keep … not a host error. ~~No underrun can occur between~~ **If the host rule below is kept up to** the last ~~push and~~ **push, no underrun occurs before** the end of the … for underruns reads ST_UNDERRUN ~~right after~~ **while** the last ~~push,~~ **word is being sent: after TX_WORD_CNT has reached the number of words of the stream (sync words inserted by hardware included, Section 7.3)** and **before the end of that word, one word time after its word_tick (Table 5). It** clears ~~it~~ **ST_UNDERRUN** by W1C before the … of the new subframe.
> The host shall keep the TX FIFO from running empty while a stream is being sent: if it is empty at a word_tick the transmitter pauses (underrun, GEN_FROZEN, Section 3.1.4) until the next word is written. After the last word of a finite stream the FIFO is empty at the next word_tick, so the transmitter freezes and ST_UNDERRUN is set: this is the normal end of a transmission, not a host error. If the host rule below is kept up to the last push, no underrun occurs before the end of the last word, so software that checks for underruns reads ST_UNDERRUN while the last word is being sent: after TX_WORD_CNT has reached the number of words of the stream (sync words inserted by hardware included, Section 7.3) and before the end of that word, one word time after its word_tick (Table 5). It clears ST_UNDERRUN by W1C before the next stream. At subframe boundaries the host is still responsible for supplying the correct sync mark as the first word of the new subframe.
(trang 30)

Chỗ đổi (§13.5): TX-05 | S, B … (ST_UNDERRUN = 0 read ~~right after~~ **while** the last ~~push);~~ **word is being sent, Section 3.1.7);** the freeze after the … 3.1.7) | REQ-TX-06, REQ-TX-02
> TX-05 | S, B | TP1 -> TP3 | SYNC_INS_MODE = 1, firmware refill on ST_LOW (FIFO filled to FIFO_DEPTH/2 words or more before TX_EN and after every refill); RX_RATE = TX_RATE = 0110 (the highest required rate) | Host rule of Section 3.1.7: keep at least 2 words queued, fill to FIFO_DEPTH/2 words or more and refill on ST_LOW, 10 subframes. No underrun (no GEN_FROZEN) and no gap between words before the last word (ST_UNDERRUN = 0 read while the last word is being sent, Section 3.1.7); the freeze after the last word is the normal end of the stream (Section 3.1.7) | REQ-TX-06, REQ-TX-02
(trang 128)

Chỗ đổi (§13.6): 3 | Push at … = 0 when read ~~right after~~ **while** the last ~~push~~ **word of S1 is being sent** (the underrun after the … the stream, Section 3.1.7)
> 3 | Push at least FIFO_DEPTH/2 words of S1 (ST_LOW is an edge), then set TX_EN (Section 3.1.7); send S1 (lead-in word, then 6 subframes of a sync word and 63 P_COUNT words, 385 words in all); keep at least 2 words queued and refill on ST_LOW back to FIFO_DEPTH/2 words or more, or poll TX_STATUS.HALF (REQ-TX-06) | No TX underrun before the last word of S1: ST_UNDERRUN (TX_IRQ_STATUS[3]) = 0 when read while the last word of S1 is being sent (the underrun after the last word is the normal end of the stream, Section 3.1.7)
(trang 138)

**Hoạt động sau khi sửa:**
![Hình I08b](fig/TX_I08_b_new.svg)
Cùng stimulus: đọc trong word cuối thấy ST_UNDERRUN = 1 → vi phạm host rule được báo.

**Kiểm chứng:** regress RI08-1,RI08-2,RI08-3,RI08-4 PASS (TX 28 + RX 18 dòng trên bản 1.92); cases E1; cặp hình TX_I08 assert PASS.

---
## 9. TX:I09 — Table 71 bước 10 không xóa ST_UNDERRUN trước rate mới (thủ tục)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 13.6 → trang 139:
> 10 | Optional: repeat steps 2 - 5 for the other rates of Table 5 (TX_RATE and RX_RATE changed with the procedure of Section 2.4) | Lock and zero mismatches at every rate

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I09a](fig/TX_I09_a_old.svg)
Bước 10 cũ chỉ "repeat steps 2 - 5 for the other rates": ST_UNDERRUN từ cuối stream trước vẫn 1 → tiêu chí bước 3 (ST_UNDERRUN = 0) FAIL ở run sau dù không có underrun.

**Lý do sửa và cách sửa:** Bước 10 làm như bước 6: xóa TX_EN, RX_EN và W1C trước mỗi rate (vòng TX trước) — câu cuối cùng do I12 thống nhất với bước 7–9. Ops: K1-06, TX-K1-01.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§13.6): 10 | Optional: **before each rate clear TX_EN and RX_EN and clear the two sticky bits as in step 6, change TX_RATE and RX_RATE with the procedure of Section 2.4, then** repeat steps 2 - … rates of Table 5 ~~(TX_RATE and RX_RATE changed with the procedure of Section 2.4)~~  | Lock and zero mismatches at every rate
> 10 | Optional: before each rate clear TX_EN and RX_EN and clear the two sticky bits as in step 6, change TX_RATE and RX_RATE with the procedure of Section 2.4, then repeat steps 2 - 5 for the other rates of Table 5 | Lock and zero mismatches at every rate
(trang 139)

**Hoạt động sau khi sửa:**
![Hình I09b](fig/TX_I09_b_new.svg)
ST_UNDERRUN = 0 khi đọc trong word cuối của run B: PASS.

**Kiểm chứng:** regress RI09-1 PASS (TX 28 + RX 18 dòng trên bản 1.92); -; cặp hình TX_I09 assert PASS.

---
## 10. TX:I10 — RX_RD_DATA "!EMPTY -> OKAY" thiếu CLR_BUSY / axi_ready (xung đột)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 7.6 → trang 95:
> RX pop: On AR handshake sample read-side EMPTY. If EMPTY -> RRESP=SLVERR, RDATA=0, no pop. If !EMPTY -> capture RDATA, RRESP=OKAY; pop once when RVALID && RREADY complete.

(B) Section 11 → trang 109:
> RX pop = AXI read of RX_RD_DATA; pop once at RVALID && RREADY when !EMPTY. RX_RD_EN is optional and does not gate the pop.

(C) Section 13.1 → trang 113:
> RX EMPTY pop -> SLVERR; !EMPTY -> OKAY + data.
> SYNC_INS_MODE=1 inserts SYNCx only if FIFO not empty at subframe_start.

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I10a](fig/TX_I10_a_old.svg)
RX FIFO còn 1 word; ghi RX_FIFO_CLEAR → CLR_BUSY = 1; đọc RX_RD_DATA ở cạnh 5: theo §7.6 / §13.1 cũ trả OKAY + 0x247 và pop trong lúc clear, trái Table 25 / Table 48 và RS-01.

**Lý do sửa và cách sửa:** Viết lại §7.6, §11 và checklist §13.1 theo điều kiện của Table 25 (EMPTY, axi_ready = 0 hoặc CLR_BUSY = 1 → SLVERR, không pop). Ops: K1-07; K1-08; K1-09, K1-19.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§7.6): RX pop: On AR … sample read-side EMPTY. If ~~EMPTY~~ **EMPTY, axi_ready = 0 or CLR_BUSY = 1** -> RRESP=SLVERR, RDATA=0, no ~~pop. If !EMPTY ->~~ **pop (Table 25). Otherwise** capture RDATA, RRESP=OKAY; pop … RVALID && RREADY complete.
> RX pop: On AR handshake sample read-side EMPTY. If EMPTY, axi_ready = 0 or CLR_BUSY = 1 -> RRESP=SLVERR, RDATA=0, no pop (Table 25). Otherwise capture RDATA, RRESP=OKAY; pop once when RVALID && RREADY complete.
(trang 95)

Chỗ đổi (§11): RX pop = AXI … RVALID && RREADY when ~~!EMPTY.~~ **the read returns OKAY (Table 25).** RX_RD_EN is optional and … not gate the pop.
> RX pop = AXI read of RX_RD_DATA; pop once at RVALID && RREADY when the read returns OKAY (Table 25). RX_RD_EN is optional and does not gate the pop.
(trang 109)

Chỗ đổi (§13.1): ~~RX EMPTY pop~~ **RX_RD_DATA read while EMPTY, CLR_BUSY = 1 or axi_ready = 0** -> ~~SLVERR; !EMPTY~~ **SLVERR, no pop; !EMPTY, CLR_BUSY = 0 and axi_ready = 1** -> OKAY + data.
Chỗ đổi (§13.1): SYNC_INS_MODE=1 inserts SYNCx only … FIFO not empty at ~~subframe_start.~~ **the word_tick with subframe_start = 1.**
> RX_RD_DATA read while EMPTY, CLR_BUSY = 1 or axi_ready = 0 -> SLVERR, no pop; !EMPTY, CLR_BUSY = 0 and axi_ready = 1 -> OKAY + data.
> SYNC_INS_MODE=1 inserts SYNCx only if FIFO not empty at the word_tick with subframe_start = 1.
(trang 113)

**Hoạt động sau khi sửa:**
![Hình I10b](fig/TX_I10_b_new.svg)
SLVERR, RDATA = 0, rd_en = 0: clear không bị pop chen vào.

**Kiểm chứng:** regress RI10-1,RI10-2,RI10-3 PASS (TX 28 + RX 18 dòng trên bản 1.92); -; cặp hình TX_I10 assert PASS.

---
## 11. TX:I11 — Ngưỡng đọc ST_UNDERRUN cuối stream là câu lặp nghĩa (bản trung gian của vòng TX trước)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 3.1.7 → trang 30:
> The host shall keep the TX FIFO from running empty while a stream is being sent: if it is empty at a word_tick the transmitter pauses (underrun, GEN_FROZEN, Section 3.1.4) until the next word is written. After the last word of a finite stream the FIFO is empty at the next word_tick, so the transmitter freezes and ST_UNDERRUN is set: this is the normal end of a transmission, not a host error. No underrun can occur between the last push and the end of the last word, so software that checks for underruns reads ST_UNDERRUN right after the last push, and clears it by W1C before the next stream. At subframe boundaries the host is still responsible for supplying the correct sync mark as the first word of the new subframe.

(Câu lỗi nằm ở bản trung gian, không có trong rev 1.91: bản TX r1 của vòng TX trước.)

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I11a](fig/TX_I11_a_old.svg)
Câu trung gian "after TX_WORD_CNT has reached the number of words sent since the counters were cleared" luôn đúng; firmware dùng số word đã push (70) trong khi SYNC_INS_MODE = 1 chèn thêm 2 sync word → đọc ở TX_WORD_CNT = 70, trước underrun của chính stream.

**Lý do sửa và cách sửa:** Ngưỡng = "the number of words of the stream (sync words inserted by hardware included, Section 7.3)". Thay đổi này nằm trong cùng đoạn §3.1.7 với I08 (so với rev 1.91 chỉ thấy một thay đổi gộp). Ops: K1-03, K2-01.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§3.1.7): The host shall keep … not a host error. ~~No underrun can occur between~~ **If the host rule below is kept up to** the last ~~push and~~ **push, no underrun occurs before** the end of the … for underruns reads ST_UNDERRUN ~~right after~~ **while** the last ~~push,~~ **word is being sent: after TX_WORD_CNT has reached the number of words of the stream (sync words inserted by hardware included, Section 7.3)** and **before the end of that word, one word time after its word_tick (Table 5). It** clears ~~it~~ **ST_UNDERRUN** by W1C before the … of the new subframe.
> The host shall keep the TX FIFO from running empty while a stream is being sent: if it is empty at a word_tick the transmitter pauses (underrun, GEN_FROZEN, Section 3.1.4) until the next word is written. After the last word of a finite stream the FIFO is empty at the next word_tick, so the transmitter freezes and ST_UNDERRUN is set: this is the normal end of a transmission, not a host error. If the host rule below is kept up to the last push, no underrun occurs before the end of the last word, so software that checks for underruns reads ST_UNDERRUN while the last word is being sent: after TX_WORD_CNT has reached the number of words of the stream (sync words inserted by hardware included, Section 7.3) and before the end of that word, one word time after its word_tick (Table 5). It clears ST_UNDERRUN by W1C before the next stream. At subframe boundaries the host is still responsible for supplying the correct sync mark as the first word of the new subframe.
(trang 30)

**Hoạt động sau khi sửa:**
![Hình I11b](fig/TX_I11_b_new.svg)
Đọc trong word cuối (TX_WORD_CNT = 72) thấy ST_UNDERRUN = 1.

**Kiểm chứng:** regress RI11-1,RI11-2 PASS (TX 28 + RX 18 dòng trên bản 1.92); -; cặp hình TX_I11 assert PASS.

---
## 12. TX:I12 — Sau merge: Table 71 bước 10 khác chữ bước 7–9 (xung đột trong bản merge)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 13.6 → trang 139:
> 10 | Optional: repeat steps 2 - 5 for the other rates of Table 5 (TX_RATE and RX_RATE changed with the procedure of Section 2.4) | Lock and zero mismatches at every rate

(Câu lỗi nằm ở bản trung gian, không có trong rev 1.91: bản merge `../ALL/work/m.docx`, Table 71 bước 10: "Optional: before each rate clear TX_EN and RX_EN as in step 6, change TX_RATE and RX_RATE with the procedure of Section 2.4", trang 139.)

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I12a](fig/TX_I12_a_old.svg)
Trong bản merge (rev 1.91 + sửa TX), bước 7–9 ghi "clear TX_EN and RX_EN and clear the two sticky bits as in step 6", bước 10 chỉ "clear TX_EN and RX_EN as in step 6" → đọc là không xóa sticky: ST_UNDERRUN và ST_INSYNC_LOST của stream trước còn 1, bước 3 FAIL, bước 12 đếm thừa 1 lần mất INSYNC. (Lỗ hổng chỉ có trong bản merge trung gian; so với rev 1.91 nó nằm chung thay đổi C39 với I09.)

**Lý do sửa và cách sửa:** Dùng đúng câu của bước 7–9 cho bước 10 (cùng thực thể, cùng chữ). Ops: K1-06, TX-K1-01.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§13.6): 10 | Optional: **before each rate clear TX_EN and RX_EN and clear the two sticky bits as in step 6, change TX_RATE and RX_RATE with the procedure of Section 2.4, then** repeat steps 2 - … rates of Table 5 ~~(TX_RATE and RX_RATE changed with the procedure of Section 2.4)~~  | Lock and zero mismatches at every rate
> 10 | Optional: before each rate clear TX_EN and RX_EN and clear the two sticky bits as in step 6, change TX_RATE and RX_RATE with the procedure of Section 2.4, then repeat steps 2 - 5 for the other rates of Table 5 | Lock and zero mismatches at every rate
(trang 139)

**Hoạt động sau khi sửa:**
![Hình I12b](fig/TX_I12_b_new.svg)
Cả hai sticky bit = 0 trước run B: bước 3 PASS, bước 12 chỉ đếm lần mất INSYNC trong stream.

**Kiểm chứng:** regress RI12-1 RI12-2 RI09-1(widened) PASS (TX 28 + RX 18 dòng trên bản 1.92); -; cặp hình TX_I12 assert PASS.

---
## 13. RX:I01 — Table 63 "line dead for good": reason code 3 cho mọi chế độ (vector không thể pass)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 13.3 → trang 118:
> Line dead for good after lock (HBP, BPRZ; ERRCHK_ENB 0 and 1; limit 0 and 12; MARGIN 8, 5, 0); clean streams with bit cells of 18 samples (MARGIN 8, 5, 3) | INSYNC falls within (16 + MARGIN) x 12 x W samples of the last sync word (MARGIN = 0: stays 1 on a dead BPRZ line); no timeout with 18-sample cells; reason code 3 (watchdog) | sync watchdog (SY-08)

(B) Section 13.5 → trang 129:
> SY-08 | S | TP5 -> TP7 | HBP and BPRZ, 4-sync, locked; ERRCHK_ENB = 0 and 1; RX_ERR_LIMIT = 0 and 12; RX_SYNC_WD: MARGIN = 8 (reset), 5, 0, 1 and 2 | RX_SYNC_WD resets to 8 and reads back; MARGIN = 1 and 2 read back as written and behave as 3. The line is cut for good (idle level) after a sync word: INSYNC falls no later than (16 + MARGIN) x 12 x W sample_ticks after the last accepted sync word, ST_INSYNC_LOST is raised, the word being assembled is not written (in BPRZ with ERRCHK_ENB = 0 only the watchdog can do this). MARGIN = 0: the watchdog is off, INSYNC stays 1 in that case. A clean stream with bit cells of 18 samples (MARGIN = 8, 5 and 3): no loss of INSYNC. NOSYNC = 1: no watchdog (RTL simulation only) | REQ-SYNC-06

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I01a](fig/RX_I01_a_old.svg)
HBP, ERRCHK_ENB = 1, limit 12, MARGIN 8: dây đứng mức, decoder vẫn ra bit 0 có cờ mỗi cell, bit xấu thứ 12 → INSYNC rơi với LOST_CAUSE = 10 (2), không phải 11 (3) như vector. Mô hình 8 tổ hợp: 3 chỉ khi BPRZ + ERRCHK_ENB = 0; HBP còn lại và BPRZ + limit 0 cho 1.

**Lý do sửa và cách sửa:** Thân §3.2.3.1 (905) và §3.2.4.8 (1042) đã nói đúng; sửa vector Table 63 theo từng chế độ và câu MARGIN = 0 của SY-08 (chỉ BPRZ + ERRCHK_ENB = 0 giữ INSYNC). Ops: RX-K1-01; RX-K1-02, RX-K1-03.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§13.3): Line dead for good … 3) | INSYNC falls ~~within~~ **with reason code 2 (RX_ERR_LIMIT) when ERRCHK_ENB = 1 and the limit is 12, otherwise with reason code 1 at the next sync word; only with BPRZ and ERRCHK_ENB = 0 (no bit at all) the watchdog ends INSYNC, reason code 3,** (16 + MARGIN) x 12 x W **+ 1** samples ~~of~~ **after** the last **accepted** sync word (MARGIN = 0: **INSYNC** stays ~~1 on a dead BPRZ line);~~ **1);** no timeout with 18-sample ~~cells; reason code 3 (watchdog)~~ **cells** | sync watchdog (SY-08)
> Line dead for good after lock (HBP, BPRZ; ERRCHK_ENB 0 and 1; limit 0 and 12; MARGIN 8, 5, 0); clean streams with bit cells of 18 samples (MARGIN 8, 5, 3) | INSYNC falls with reason code 2 (RX_ERR_LIMIT) when ERRCHK_ENB = 1 and the limit is 12, otherwise with reason code 1 at the next sync word; only with BPRZ and ERRCHK_ENB = 0 (no bit at all) the watchdog ends INSYNC, reason code 3, (16 + MARGIN) x 12 x W + 1 samples after the last accepted sync word (MARGIN = 0: INSYNC stays 1); no timeout with 18-sample cells | sync watchdog (SY-08)
(trang 118)

Chỗ đổi (§13.5): SY-08 | S | … x 12 x W **+ 1** sample_ticks after the last … off, INSYNC stays 1 ~~in that case.~~ **with BPRZ and ERRCHK_ENB = 0.** A clean stream with … simulation only) | REQ-SYNC-06
> SY-08 | S | TP5 -> TP7 | HBP and BPRZ, 4-sync, locked; ERRCHK_ENB = 0 and 1; RX_ERR_LIMIT = 0 and 12; RX_SYNC_WD: MARGIN = 8 (reset), 5, 0, 1 and 2 | RX_SYNC_WD resets to 8 and reads back; MARGIN = 1 and 2 read back as written and behave as 3. The line is cut for good (idle level) after a sync word: INSYNC falls no later than (16 + MARGIN) x 12 x W + 1 sample_ticks after the last accepted sync word, ST_INSYNC_LOST is raised, the word being assembled is not written (in BPRZ with ERRCHK_ENB = 0 only the watchdog can do this). MARGIN = 0: the watchdog is off, INSYNC stays 1 with BPRZ and ERRCHK_ENB = 0. A clean stream with bit cells of 18 samples (MARGIN = 8, 5 and 3): no loss of INSYNC. NOSYNC = 1: no watchdog (RTL simulation only) | REQ-SYNC-06
(trang 129)

**Hoạt động sau khi sửa:**
![Hình I01b](fig/RX_I01_b_new.svg)
Vector mới khớp mô hình ở cả 8 tổ hợp: 2 / 1 / 3 tùy chế độ.

**Kiểm chứng:** regress RI01-1 RI01-2 RI01-3 PASS (TX 28 + RX 18 dòng trên bản 1.92); cases C22; cặp hình RX_I01 assert PASS.

---
## 14. RX:I02 — MATCH so "running word counter" ở Table 37 / §7.4 nhưng so word đang được nhận ở §3.2.3.1 (xung đột)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 7.4 → trang 91:
> 14:2 | WORD_CNT[12:0] | 0 | Target word count inside the selected subframe (0…8191). Compared against the running word counter when INSYNC is high.

(B) Section 7.4 → trang 91:
> When the running subframe index matches SUBFRAME[1:0] and the running word count matches WORD_CNT[12:0], the MATCH flag (RX_STATUS bit and external match pin) is asserted for one word-time. WORD_CNT >= W (words per subframe at the applied RX_RATE) never matches.

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I02a](fig/RX_I02_a_old.svg)
WRDCNT = (00, 5): word_in_subframe đang chạy = 5 ngay sau khi word 4 được ghi → theo Table 37 / §7.4 cũ MATCH cao trong lúc word 4 (0x004) vừa ghi, sớm 1 word so với §3.2.3.1.

**Lý do sửa và cách sửa:** §3.2.3.1 là chỗ định nghĩa: Table 37 và đoạn §7.4 dùng "the word index of the word being accepted" và tham chiếu Section 3.2.3.1. Ops: RX-K1-05; RX-K1-06.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§7.4): 14:2 | WORD_CNT[12:0] | … selected subframe (0…8191). Compared ~~against~~ **with** the ~~running~~  word ~~counter~~ **index of the word being accepted** when INSYNC is ~~high.~~ **high (Section 3.2.3.1).**
> 14:2 | WORD_CNT[12:0] | 0 | Target word count inside the selected subframe (0…8191). Compared with the word index of the word being accepted when INSYNC is high (Section 3.2.3.1).
(trang 91)

Chỗ đổi (§7.4): When the ~~running~~  subframe index ~~matches~~ **and the word index of the word being accepted match** SUBFRAME[1:0] and ~~the running word count matches~~  WORD_CNT[12:0], the MATCH flag … is asserted for one ~~word-time.~~ **word-time, one bit cell more for the lock word with ERRCHK_ENB = 1 (Section 3.2.3.1).** WORD_CNT >= W (words … applied RX_RATE) never matches.
> When the subframe index and the word index of the word being accepted match SUBFRAME[1:0] and WORD_CNT[12:0], the MATCH flag (RX_STATUS bit and external match pin) is asserted for one word-time, one bit cell more for the lock word with ERRCHK_ENB = 1 (Section 3.2.3.1). WORD_CNT >= W (words per subframe at the applied RX_RATE) never matches.
(trang 91)

**Hoạt động sau khi sửa:**
![Hình I02b](fig/RX_I02_b_new.svg)
MATCH cao từ lúc word 5 được nhận tới lúc word 6 được nhận.

**Kiểm chứng:** regress RI02-1 RI02-2 PASS (TX 28 + RX 18 dòng trên bản 1.92); SyncRx match (Hình I02); cặp hình RX_I02 assert PASS.

---
## 15. RX:I03 — MATCH "at most one word-time" sai với lock word khi ERRCHK_ENB = 1 (con số)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 3.2.3.1 → trang 61:
> Figure 26: RX timing after lock: bit_index, word_in_subframe, FIFO write, and the word-0 check at the start of a subframe

(B) Section 3.2.3.1 → trang 62:
> MATCH compares (subframe_index, word_in_subframe) of the word being accepted against WRDCNT; word 0 is the sync word. The match pin and RX_STATUS.MATCH are registered high in the clock where the matching word is accepted (its 12th bit has entered the window and, for word 0, the code check has passed), also when the word is dropped because the RX FIFO is full or being cleared, and stay high until the next word is accepted, INSYNC falls or rx_active falls, whichever comes first (at most one word-time); a one-clock event goes to the CPU IF for ST_MATCH. WORD_CNT >= W never matches. The MATCH bit and pin are at most one word-time wide (244 us at the highest required rate of Table 5), so software that shall not miss the event uses the sticky ST_MATCH bit and does not poll RX_STATUS.MATCH.

(C) Section 7.4 → trang 91:
> 7 | MATCH | 0 | 1 for at most one word-time when word-count/subframe matches WRDCNT. At most one word-time wide: use the sticky RX_IRQ_STATUS.ST_MATCH to catch it.
> 9:8 | LOST_CAUSE | 00 | Why INSYNC fell the last time (valid when ST_INSYNC_LOST is set): 00 = no loss yet, 01 = sync word (word 0) with a wrong code, 10 = RX_ERR_LIMIT bad bits in a row, 11 = sync watchdog (Section 3.2.3.1). Keeps the last cause; cleared by hardware reset, SOFT_RESET and when GLOBAL_EN AND RX_EN rises (not by RX_ERR_CLEAR).

(D) Section 10.2 → trang 105:
> match | Out | WRDCNT match pulse (at most one word-time)

(E) Section 13.2 → trang 116:
> REQ-RX-18 | MATCH: RX_STATUS.MATCH and the match pin are high for at most one word-time when the accepted word matches WRDCNT (subframe and word, Section 3.2.3.1); WORD_CNT >= W never matches; ST_MATCH is set once per match | 3.2.3.1, 7.4

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I03a](fig/RX_I03_a_old.svg)
WRDCNT = (00, 0), ERRCHK_ENB = 1: lock word ghi ngay ở clock lock, word 1 chờ hold một bit → được ghi 13 bit cell sau; MATCH cao 13 cell > "at most one word-time" (12). Figure 26 vẽ 12 bit giữa word 0 và word 1 (đúng với ERRCHK_ENB = 0).

**Lý do sửa và cách sửa:** Giữ quy tắc phần cứng, sửa con số ở mọi chỗ cùng chữ: "one bit cell more for the lock word with ERRCHK_ENB = 1" (§3.2.3.1 ×2, Table 36, §7.4, Table 55, REQ-RX-18) và chú thích Figure 26. Ops: RX-K1-12; RX-K1-07, RX-K1-08; RX-K1-09, RX-K1-20; RX-K1-10; RX-K1-11.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§3.2.3.1): Figure 26: RX timing … start of a subframe **(ERRCHK_ENB = 0; with ERRCHK_ENB = 1 every word after the lock word is written one bit cell later, Section 3.2.4.2)**
> Figure 26: RX timing after lock: bit_index, word_in_subframe, FIFO write, and the word-0 check at the start of a subframe (ERRCHK_ENB = 0; with ERRCHK_ENB = 1 every word after the lock word is written one bit cell later, Section 3.2.4.2)
(trang 61)

Chỗ đổi (§3.2.3.1): MATCH compares (subframe_index, word_in_subframe) … first (at most one ~~word-time);~~ **word-time, one bit cell more for the lock word with ERRCHK_ENB = 1, because the next word waits for the one-bit hold of Section 3.2.4.2);** a one-clock event goes … rate of Table 5), **one bit cell more for the lock word with ERRCHK_ENB = 1,** so software that shall … does not poll RX_STATUS.MATCH.
> MATCH compares (subframe_index, word_in_subframe) of the word being accepted against WRDCNT; word 0 is the sync word. The match pin and RX_STATUS.MATCH are registered high in the clock where the matching word is accepted (its 12th bit has entered the window and, for word 0, the code check has passed), also when the word is dropped because the RX FIFO is full or being cleared, and stay high until the next word is accepted, INSYNC falls or rx_active falls, whichever comes first (at most one word-time, one bit cell more for the lock word with ERRCHK_ENB = 1, because the next word waits for the one-bit hold of Section 3.2.4.2); a one-clock event goes to the CPU IF for ST_MATCH. WORD_CNT >= W never matches. The MATCH bit and pin are at most one word-time wide (244 us at the highest required rate of Table 5), one bit cell more for the lock word with ERRCHK_ENB = 1, so software that shall not miss the event uses the sticky ST_MATCH bit and does not poll RX_STATUS.MATCH.
(trang 63)

Chỗ đổi (§7.4): 7 | MATCH | … at most one word-time **(one bit cell more for the lock word with ERRCHK_ENB = 1, Section 3.2.3.1)** when word-count/subframe matches WRDCNT. ~~At most one word-time wide:~~ **Short level:** use the sticky RX_IRQ_STATUS.ST_MATCH to catch it.
Chỗ đổi (§7.4): 9:8 | LOST_CAUSE | 00 | Why INSYNC ~~fell~~ **was lost** the last time **while rx_active = 1** (valid when ST_INSYNC_LOST is ~~set):~~ **set; INSYNC cleared because rx_active falls does not change it, Section 3.2.3.1):** 00 = no loss … rises (not by RX_ERR_CLEAR).
> 7 | MATCH | 0 | 1 for at most one word-time (one bit cell more for the lock word with ERRCHK_ENB = 1, Section 3.2.3.1) when word-count/subframe matches WRDCNT. Short level: use the sticky RX_IRQ_STATUS.ST_MATCH to catch it.
> 9:8 | LOST_CAUSE | 00 | Why INSYNC was lost the last time while rx_active = 1 (valid when ST_INSYNC_LOST is set; INSYNC cleared because rx_active falls does not change it, Section 3.2.3.1): 00 = no loss yet, 01 = sync word (word 0) with a wrong code, 10 = RX_ERR_LIMIT bad bits in a row, 11 = sync watchdog (Section 3.2.3.1). Keeps the last cause; cleared by hardware reset, SOFT_RESET and when GLOBAL_EN AND RX_EN rises (not by RX_ERR_CLEAR).
(trang 91)

Chỗ đổi (§10.2): match | Out | … pulse (at most one ~~word-time)~~ **word-time, one bit cell more for the lock word with ERRCHK_ENB = 1)**
> match | Out | WRDCNT match pulse (at most one word-time, one bit cell more for the lock word with ERRCHK_ENB = 1)
(trang 105)

Chỗ đổi (§13.2): REQ-RX-18 | MATCH: RX_STATUS.MATCH … at most one word-time **(one bit cell more for the lock word with ERRCHK_ENB = 1)** when the accepted word … match | 3.2.3.1, 7.4
> REQ-RX-18 | MATCH: RX_STATUS.MATCH and the match pin are high for at most one word-time (one bit cell more for the lock word with ERRCHK_ENB = 1) when the accepted word matches WRDCNT (subframe and word, Section 3.2.3.1); WORD_CNT >= W never matches; ST_MATCH is set once per match | 3.2.3.1, 7.4
(trang 116)

**Hoạt động sau khi sửa:**
![Hình I03b](fig/RX_I03_b_new.svg)
Độ rộng 13 cell được nêu; các word khác 12 cell.

**Kiểm chứng:** regress RI03-1 RI03-2 PASS (TX 28 + RX 18 dòng trên bản 1.92); cases C23; cặp hình RX_I03 assert PASS.

---
## 16. RX:I04 — NOSYNC: dây dừng sau data → word 0x000 thừa vào RX FIFO (hành vi chưa nêu)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 3.2.2.4 → trang 60:
> When RX_CTRL.NOSYNC = 1 the trackers, the word-0 check and the sync watchdog are bypassed. INSYNC reads 1 while rx_active = 1. bit_index counts recovered bits from 0 at the first bit_valid after rx_active rises, so the word alignment is arbitrary and software shall locate subframe marks in the data. Every 12th recovered bit the assembled word is written to the RX FIFO. word_in_subframe and subframe_index do not run: SYNC[1:0] = 00, MATCH is never asserted and ST_INSYNC_LOST is not generated. The BPRZ placeholder bit (Section 3.2.4.4) is produced only after the first real bit since rx_active rose (bit_seen = 1): before it no bit is produced, so an idle line writes nothing to the RX FIFO and sets no ST_BIT_ERR (the HBP decoder produces no bit before it has acquired the line, Section 3.2.1.2).

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I04a](fig/RX_I04_a_old.svg)
NOSYNC, HBP, ERRCHK_ENB = 0: sau 12 word data dây đứng mức; phase counter vẫn ra bit 0 mỗi cell → cứ 12 bit một word 0x000 không cờ (EXTRA). §3.2.2.4 cũ chỉ nói dây rỗi TRƯỚC bit đầu không ghi gì.

**Lý do sửa và cách sửa:** Không có word-0 check, watchdog, RX_ERR_LIMIT trong NOSYNC nên phần cứng không thể dừng; ghi rõ hành vi trong §3.2.2.4 (HBP luôn, BPRZ khi ERRCHK_ENB = 1; BPRZ + ERRCHK_ENB = 0 không ghi). Ops: RX-K1-13.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§3.2.2.4): When RX_CTRL.NOSYNC = 1 … the line, Section 3.2.1.2). **A line that stops after data is not detected in this mode: the HBP decoder keeps delivering a bit 0 in every bit cell (flagged with ERRCHK_ENB = 1), and with ERRCHK_ENB = 1 the BPRZ decoder a placeholder bit 0 in every bit cell, so words 0x000 are written to the RX FIFO until rx_active falls; with BPRZ and ERRCHK_ENB = 0 nothing is written.**
> When RX_CTRL.NOSYNC = 1 the trackers, the word-0 check and the sync watchdog are bypassed. INSYNC reads 1 while rx_active = 1. bit_index counts recovered bits from 0 at the first bit_valid after rx_active rises, so the word alignment is arbitrary and software shall locate subframe marks in the data. Every 12th recovered bit the assembled word is written to the RX FIFO. word_in_subframe and subframe_index do not run: SYNC[1:0] = 00, MATCH is never asserted and ST_INSYNC_LOST is not generated. The BPRZ placeholder bit (Section 3.2.4.4) is produced only after the first real bit since rx_active rose (bit_seen = 1): before it no bit is produced, so an idle line writes nothing to the RX FIFO and sets no ST_BIT_ERR (the HBP decoder produces no bit before it has acquired the line, Section 3.2.1.2). A line that stops after data is not detected in this mode: the HBP decoder keeps delivering a bit 0 in every bit cell (flagged with ERRCHK_ENB = 1), and with ERRCHK_ENB = 1 the BPRZ decoder a placeholder bit 0 in every bit cell, so words 0x000 are written to the RX FIFO until rx_active falls; with BPRZ and ERRCHK_ENB = 0 nothing is written.
(trang 60)

**Hoạt động sau khi sửa:**
![Hình I04b](fig/RX_I04_b_new.svg)
Hành vi được nêu; phần mềm biết xóa RX_EN hoặc dùng ERRCHK_ENB = 1 để có cờ.

**Kiểm chứng:** regress RI04-1 PASS (TX 28 + RX 18 dòng trên bản 1.92); cases C24; cặp hình RX_I04 assert PASS.

---
## 17. RX:I05 — rxsel_eff (RXSEL OR rsel) chưa lan tới §2.2, TP4 và các test hai format (closure)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 2.2 → trang 14:
> RX HBP Internal Pattern / RX BPRZ Internal Pattern – the same ROM when INJ_DST = 1. It replaces the loopback tap or the synchronized pins at the input of Sample & Hold (test point TP5); RX_CTRL.RXSEL selects the HBP or the BPRZ pair.

(B) Section 13.4.2 → trang 127:
> Use as a receive stimulus: the sequence is applied at TP4 (RXSEL selects the format). Expected at TP6: the bits of all words, LSB first, from the first decoded cell after the decoder has locked (the lock cells at the start are dropped, Table 63). Expected at TP8: the 128 words of subframes 5 and 6 (SYNC1, 63 P_COUNT words, SYNC2, 63 P_COUNT words).

(C) Section 13.5 → trang 128:
> LB-03 | S, B | TP1 -> TP1 | TEST = 1, both formats | S1 with payload P_ZERO, P_ONES, P_ALT, P_WALK1, P_WALK0, P_POS, one run each. Zero word errors | REQ-RX-02, REQ-RX-05
> LB-04 | B | TP1 -> TP1 | TEST = 1, both formats | S1 with P_PRBS, at least 60 subframes. Zero word errors, no INSYNC loss before the last word of the stream (the loss after the end of the stream is expected, Section 13.6) | REQ-SYNC-03

(D) Section 13.5 → trang 130:
> IN-04 | S, B | TP5 -> TP7, TP8 | Injector, INJ_DST = 1, continuous mode, both formats | At least 10 subframes: no INSYNC loss, every delivered word follows the sync / P_BLK8 rule | REQ-SYNC-03, REQ-SYNC-04

(E) Section 13.5 → trang 130:
> IN-08 | S, B | TP3 -> TP5 -> TP7, TP8 | Injector, INJ_DST = 0, TEST = 1, TX_EN = 1, RX_EN = 1, TX_RATE = RX_RATE, run once, HBP and BPRZ (RXSEL), W = 64 | As IN-01: the receiver decodes the injector stream through the loopback tap, INSYNC at the 5th mark, 128 words delivered | REQ-INJ-02, REQ-RX-04

(F) Section 13.5 → trang 131:
> RT-01 | S | TP4 -> TP6 | Each required rate, RXSEL = 0 and 1, rx_path alone | Vector V-RATE as a core_clk-accurate line: 40 random words (first word 0x000), TX rate error 0, +1000 and -1000 ppm, RX tick clock started 0, 1, 7 and three random core_clk after the first TX tick. Bits at TP6 equal the sent bits; at most one framing error (at the start) | REQ-RX-05, REQ-TICK-02

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I05a](fig/RX_I05_a_old.svg)
Board có pin rsel = 1: rxsel_eff = 1 nên run "HBP" của LB-04 (TEST = 1, both formats) giải cặp BPRZ và PASS — đường HBP không được kiểm. §2.2 (TP5) và TP4 vẫn nói RXSEL tự chọn format.

**Lý do sửa và cách sửa:** Dùng rxsel_eff ở §2.2 và §13.4; LB-03, LB-04, IN-04, IN-08 ghi "HBP needs rsel = 0", RT-01 ghi "(rsel = 0)". Ops: RX-K1-14; RX-K1-15; RX-K1-23, RX-K1-24; RX-K1-16; RX-K1-17; RX-K1-18.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§2.2): RX HBP Internal Pattern … Hold (test point TP5); ~~RX_CTRL.RXSEL~~ **rxsel_eff (RX_CTRL.RXSEL OR rsel)** selects the HBP or the BPRZ pair.
> RX HBP Internal Pattern / RX BPRZ Internal Pattern – the same ROM when INJ_DST = 1. It replaces the loopback tap or the synchronized pins at the input of Sample & Hold (test point TP5); rxsel_eff (RX_CTRL.RXSEL OR rsel) selects the HBP or the BPRZ pair.
(trang 14)

Chỗ đổi (§13.4.2): Use as a receive … is applied at TP4 ~~(RXSEL~~ **(rxsel_eff = RXSEL OR rsel** selects the format). Expected … SYNC2, 63 P_COUNT words).
> Use as a receive stimulus: the sequence is applied at TP4 (rxsel_eff = RXSEL OR rsel selects the format). Expected at TP6: the bits of all words, LSB first, from the first decoded cell after the decoder has locked (the lock cells at the start are dropped, Table 63). Expected at TP8: the 128 words of subframes 5 and 6 (SYNC1, 63 P_COUNT words, SYNC2, 63 P_COUNT words).
(trang 127)

Chỗ đổi (§13.5): LB-03 | S, B … = 1, both formats **(HBP needs rsel = 0)** | S1 with payload … errors | REQ-RX-02, REQ-RX-05
Chỗ đổi (§13.5): LB-04 | B | … = 1, both formats **(HBP needs rsel = 0)** | S1 with P_PRBS, … Section 13.6) | REQ-SYNC-03
> LB-03 | S, B | TP1 -> TP1 | TEST = 1, both formats (HBP needs rsel = 0) | S1 with payload P_ZERO, P_ONES, P_ALT, P_WALK1, P_WALK0, P_POS, one run each. Zero word errors | REQ-RX-02, REQ-RX-05
> LB-04 | B | TP1 -> TP1 | TEST = 1, both formats (HBP needs rsel = 0) | S1 with P_PRBS, at least 60 subframes. Zero word errors, no INSYNC loss before the last word of the stream (the loss after the end of the stream is expected, Section 13.6) | REQ-SYNC-03
(trang 128)

Chỗ đổi (§13.5): IN-04 | S, B … continuous mode, both formats **(HBP needs rsel = 0)** | At least 10 … rule | REQ-SYNC-03, REQ-SYNC-04
> IN-04 | S, B | TP5 -> TP7, TP8 | Injector, INJ_DST = 1, continuous mode, both formats (HBP needs rsel = 0) | At least 10 subframes: no INSYNC loss, every delivered word follows the sync / P_BLK8 rule | REQ-SYNC-03, REQ-SYNC-04
(trang 130)

Chỗ đổi (§13.5): IN-08 | S, B … once, HBP and BPRZ ~~(RXSEL),~~ **(rxsel_eff; HBP needs rsel = 0),** W = 64 | … delivered | REQ-INJ-02, REQ-RX-04
> IN-08 | S, B | TP3 -> TP5 -> TP7, TP8 | Injector, INJ_DST = 0, TEST = 1, TX_EN = 1, RX_EN = 1, TX_RATE = RX_RATE, run once, HBP and BPRZ (rxsel_eff; HBP needs rsel = 0), W = 64 | As IN-01: the receiver decodes the injector stream through the loopback tap, INSYNC at the 5th mark, 128 words delivered | REQ-INJ-02, REQ-RX-04
(trang 130)

Chỗ đổi (§13.5): RT-01 | S | … RXSEL = 0 and ~~1,~~ **1 (rsel = 0),** rx_path alone | Vector … start) | REQ-RX-05, REQ-TICK-02
> RT-01 | S | TP4 -> TP6 | Each required rate, RXSEL = 0 and 1 (rsel = 0), rx_path alone | Vector V-RATE as a core_clk-accurate line: 40 random words (first word 0x000), TX rate error 0, +1000 and -1000 ppm, RX tick clock started 0, 1, 7 and three random core_clk after the first TX tick. Bits at TP6 equal the sent bits; at most one framing error (at the start) | REQ-RX-05, REQ-TICK-02
(trang 131)

**Hoạt động sau khi sửa:**
![Hình I05b](fig/RX_I05_b_new.svg)
Trên board rsel = 1 run HBP được đánh dấu không áp dụng; không còn PASS giả.

**Kiểm chứng:** regress RI05-1 RI05-2 PASS (TX 28 + RX 18 dòng trên bản 1.92); -; cặp hình RX_I05 assert PASS.

---
## 18. RX:I06 — INSYNC rơi do rx_active vẫn được mô tả là mất sync (closure)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 7.4 → trang 91:
> 7 | MATCH | 0 | 1 for at most one word-time when word-count/subframe matches WRDCNT. At most one word-time wide: use the sticky RX_IRQ_STATUS.ST_MATCH to catch it.
> 9:8 | LOST_CAUSE | 00 | Why INSYNC fell the last time (valid when ST_INSYNC_LOST is set): 00 = no loss yet, 01 = sync word (word 0) with a wrong code, 10 = RX_ERR_LIMIT bad bits in a row, 11 = sync watchdog (Section 3.2.3.1). Keeps the last cause; cleared by hardware reset, SOFT_RESET and when GLOBAL_EN AND RX_EN rises (not by RX_ERR_CLEAR).

(B) Section 8.2 → trang 97:
> Bit 5 – EN_INSYNC_LOST / ST_INSYNC_LOST (falling edge of INSYNC; the reason is in RX_STATUS.LOST_CAUSE)

(C) Section 10.5 → trang 108:
> rx_sync_detect | lost_cause[1:0] | out | 2 | Reason of the last INSYNC fall (1 = word 0, 2 = RX_ERR_LIMIT, 3 = watchdog); held stable with ev_insync_lost; loaded into RX_STATUS.LOST_CAUSE

(D) Section 13.2 → trang 116:
> REQ-SYNC-07 | RX_STATUS.LOST_CAUSE[1:0] gives the reason of the last INSYNC fall: 1 = wrong word 0, 2 = RX_ERR_LIMIT, 3 = sync watchdog (priority in this order of 2, 1, 3 when simultaneous); 00 after reset, cleared by GLOBAL_EN AND RX_EN rising and SOFT_RESET | 3.2.3.1, 7.4

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I06a](fig/RX_I06_a_old.svg)
LOST_CAUSE = 01 từ lần mất sync trước; phần mềm xóa RX_EN: INSYNC rơi theo rx_active. Theo §8.2 Bit 5 cũ ("falling edge of INSYNC") ISR chờ ST_INSYNC_LOST và đọc LOST_CAUSE 01 như lý do, trong khi §3.2.3.1 nói không đặt ST_INSYNC_LOST và không đổi LOST_CAUSE.

**Lý do sửa và cách sửa:** §3.2.3.1 là chỗ định nghĩa: thêm "while rx_active = 1" ở §8.2, Table 36, Table 58, REQ-SYNC-07. Ops: RX-K1-09, RX-K1-20; RX-K1-19; RX-K1-21; RX-K1-22.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§7.4): 7 | MATCH | … at most one word-time **(one bit cell more for the lock word with ERRCHK_ENB = 1, Section 3.2.3.1)** when word-count/subframe matches WRDCNT. ~~At most one word-time wide:~~ **Short level:** use the sticky RX_IRQ_STATUS.ST_MATCH to catch it.
Chỗ đổi (§7.4): 9:8 | LOST_CAUSE | 00 | Why INSYNC ~~fell~~ **was lost** the last time **while rx_active = 1** (valid when ST_INSYNC_LOST is ~~set):~~ **set; INSYNC cleared because rx_active falls does not change it, Section 3.2.3.1):** 00 = no loss … rises (not by RX_ERR_CLEAR).
> 7 | MATCH | 0 | 1 for at most one word-time (one bit cell more for the lock word with ERRCHK_ENB = 1, Section 3.2.3.1) when word-count/subframe matches WRDCNT. Short level: use the sticky RX_IRQ_STATUS.ST_MATCH to catch it.
> 9:8 | LOST_CAUSE | 00 | Why INSYNC was lost the last time while rx_active = 1 (valid when ST_INSYNC_LOST is set; INSYNC cleared because rx_active falls does not change it, Section 3.2.3.1): 00 = no loss yet, 01 = sync word (word 0) with a wrong code, 10 = RX_ERR_LIMIT bad bits in a row, 11 = sync watchdog (Section 3.2.3.1). Keeps the last cause; cleared by hardware reset, SOFT_RESET and when GLOBAL_EN AND RX_EN rises (not by RX_ERR_CLEAR).
(trang 91)

Chỗ đổi (§8.2): Bit 5 – EN_INSYNC_LOST … ST_INSYNC_LOST (falling edge of ~~INSYNC;~~ **INSYNC while rx_active = 1;** the reason is in RX_STATUS.LOST_CAUSE)
> Bit 5 – EN_INSYNC_LOST / ST_INSYNC_LOST (falling edge of INSYNC while rx_active = 1; the reason is in RX_STATUS.LOST_CAUSE)
(trang 97)

Chỗ đổi (§10.5): rx_sync_detect | lost_cause[1:0] | … Reason of the last **loss of** INSYNC ~~fall~~ **while rx_active = 1** (1 = word 0, … ev_insync_lost; loaded into RX_STATUS.LOST_CAUSE
> rx_sync_detect | lost_cause[1:0] | out | 2 | Reason of the last loss of INSYNC while rx_active = 1 (1 = word 0, 2 = RX_ERR_LIMIT, 3 = watchdog); held stable with ev_insync_lost; loaded into RX_STATUS.LOST_CAUSE
(trang 108)

Chỗ đổi (§13.2): REQ-SYNC-07 | RX_STATUS.LOST_CAUSE[1:0] gives … reason of the last **loss of** INSYNC ~~fall:~~ **while rx_active = 1:** 1 = wrong word … SOFT_RESET | 3.2.3.1, 7.4
> REQ-SYNC-07 | RX_STATUS.LOST_CAUSE[1:0] gives the reason of the last loss of INSYNC while rx_active = 1: 1 = wrong word 0, 2 = RX_ERR_LIMIT, 3 = sync watchdog (priority in this order of 2, 1, 3 when simultaneous); 00 after reset, cleared by GLOBAL_EN AND RX_EN rising and SOFT_RESET | 3.2.3.1, 7.4
(trang 117)

**Hoạt động sau khi sửa:**
![Hình I06b](fig/RX_I06_b_new.svg)
Không sự kiện khi tắt RX; LOST_CAUSE 01 được hiểu đúng là của lần mất sync trước.

**Kiểm chứng:** regress RI06-1 PASS (TX 28 + RX 18 dòng trên bản 1.92); -; cặp hình RX_I06 assert PASS.

---
## 19. RX:I07 — Watchdog làm INSYNC rơi ở tick (16 + MARGIN) × 12 × W + 1, test ghi "no later than (16 + MARGIN) × 12 × W" (con số)
**Tài liệu cũ nói gì (rev 1.91):**
(A) Section 3.2.4.8 → trang 70:
> BPRZ: a pulse that is lost is a bit that is lost. Every later bit moves by one place, without flag, until the next sync word comparison: INSYNC falls there (ST_INSYNC_LOST), up to one subframe (1 s) later (tests ER-19, ER-20). If the line stops for good, the BPRZ decoder produces no bit at all (there is no placeholder without the check), so no sync word can be compared; the sync watchdog (Section 3.2.3.1) then ends INSYNC within the watchdog time (default 1.5 subframes) after the last accepted sync word (test SY-08). In HBP the phase counter keeps delivering bits 0, so the sync word comparison fails within one subframe and INSYNC falls.

(B) Section 13.5 → trang 129:
> SY-08 | S | TP5 -> TP7 | HBP and BPRZ, 4-sync, locked; ERRCHK_ENB = 0 and 1; RX_ERR_LIMIT = 0 and 12; RX_SYNC_WD: MARGIN = 8 (reset), 5, 0, 1 and 2 | RX_SYNC_WD resets to 8 and reads back; MARGIN = 1 and 2 read back as written and behave as 3. The line is cut for good (idle level) after a sync word: INSYNC falls no later than (16 + MARGIN) x 12 x W sample_ticks after the last accepted sync word, ST_INSYNC_LOST is raised, the word being assembled is not written (in BPRZ with ERRCHK_ENB = 0 only the watchdog can do this). MARGIN = 0: the watchdog is off, INSYNC stays 1 in that case. A clean stream with bit cells of 18 samples (MARGIN = 8, 5 and 3): no loss of INSYNC. NOSYNC = 1: no watchdog (RTL simulation only) | REQ-SYNC-06

**Lỗ hổng khi hoạt động theo tài liệu cũ:**
![Hình I07a](fig/RX_I07_a_old.svg)
BPRZ, ERRCHK_ENB = 0, MARGIN = 8: bộ đếm về 0 ở tick nhận sync word; quy tắc "If it exceeds (16 + MARGIN) x 12 x W" → vượt ở 18 433. Ở hạn chót SY-08 (18 432) INSYNC vẫn 1: test đúng chữ FAIL.

**Lý do sửa và cách sửa:** Giữ quy tắc "exceeds" (§3.2.3.1), sửa SY-08, Table 63 và §3.2.4.8 thành "+ 1" / "one sample_tick after". Ops: RX-K1-04; RX-K1-02, RX-K1-03.

**Tài liệu mới (rev 1.92):**
Chỗ đổi (§3.2.4.8): BPRZ: a pulse that … 3.2.3.1) then ends INSYNC ~~within~~ **one sample_tick after** the watchdog time (default 1.5 subframes) ~~after~~ **from** the last accepted sync … subframe and INSYNC falls.
> BPRZ: a pulse that is lost is a bit that is lost. Every later bit moves by one place, without flag, until the next sync word comparison: INSYNC falls there (ST_INSYNC_LOST), up to one subframe (1 s) later (tests ER-19, ER-20). If the line stops for good, the BPRZ decoder produces no bit at all (there is no placeholder without the check), so no sync word can be compared; the sync watchdog (Section 3.2.3.1) then ends INSYNC one sample_tick after the watchdog time (default 1.5 subframes) from the last accepted sync word (test SY-08). In HBP the phase counter keeps delivering bits 0, so the sync word comparison fails within one subframe and INSYNC falls.
(trang 70)

Chỗ đổi (§13.5): SY-08 | S | … x 12 x W **+ 1** sample_ticks after the last … off, INSYNC stays 1 ~~in that case.~~ **with BPRZ and ERRCHK_ENB = 0.** A clean stream with … simulation only) | REQ-SYNC-06
> SY-08 | S | TP5 -> TP7 | HBP and BPRZ, 4-sync, locked; ERRCHK_ENB = 0 and 1; RX_ERR_LIMIT = 0 and 12; RX_SYNC_WD: MARGIN = 8 (reset), 5, 0, 1 and 2 | RX_SYNC_WD resets to 8 and reads back; MARGIN = 1 and 2 read back as written and behave as 3. The line is cut for good (idle level) after a sync word: INSYNC falls no later than (16 + MARGIN) x 12 x W + 1 sample_ticks after the last accepted sync word, ST_INSYNC_LOST is raised, the word being assembled is not written (in BPRZ with ERRCHK_ENB = 0 only the watchdog can do this). MARGIN = 0: the watchdog is off, INSYNC stays 1 with BPRZ and ERRCHK_ENB = 0. A clean stream with bit cells of 18 samples (MARGIN = 8, 5 and 3): no loss of INSYNC. NOSYNC = 1: no watchdog (RTL simulation only) | REQ-SYNC-06
(trang 129)

**Hoạt động sau khi sửa:**
![Hình I07b](fig/RX_I07_b_new.svg)
Tiêu chí 18 433 khớp quy tắc từng tick.

**Kiểm chứng:** regress RI07-1 RI07-2 PASS (TX 28 + RX 18 dòng trên bản 1.92); cases C22 (18 429 / 16 125 sample sau sync word cuối trên dây; 18 433 sau tick nhận); cặp hình RX_I07 assert PASS.

---
## Thay đổi không gắn với lỗ hổng hoạt động
- Revision History: thêm dòng 1.92 (trang 5): > 2026-10-28 | 1.92 | Closed-loop review of the TX and RX parts (rev 1.91 and the TX fixes of the parallel 1.91 branch). TX: Sections 3.1.3, 3.1.4 and 13.1: the hardware sync word is loaded at a word_tick with subframe_start = 1; the Generator and the FSM sample one fifo_empty flag (the core-side empt…
- §1.3: This document is revision ~~1.91~~ **1.92** of the Core717 (AXI-Lite … only this document changes. (trang 9)

## Đã kiểm tra, không sửa (DROP)
| ứng viên | lý do |
|---|---|
| RX sweep glitch: 103 / 4608 ca word sai không cờ (ERRCHK_ENB = 1) | bit lật có dạng hợp lệ: Table 14 "Not detected by the core", Table 16 "Not detected: BPRZ has no parity" |
| RX sweep cut: 276 / 576 ca word sai không cờ | toàn bộ ERRCHK_ENB = 0: "nothing is flagged or counted"; BPRZ lệch tới sync word kế (§3.2.4.8, ER-19, ER-20) |
| TX sweep underrun: 4684 SILENT_WRONG | là I01, giới hạn nay đã ghi ở §3.1.4 / §3.2.4.7 |
| Danh sách "Known refuted" của RX (word 0 có cờ không tính RX_WORD_ERR_CNT; RX_ERR_LIMIT trong NOSYNC; dwell INVALID) | đã bác ở vòng trước, không mở lại |

## Để lại (DEFER)
Không có. Câu hỏi thiết kế có thể cân nhắc (không chặn bản này): RX:I04 có thể sửa phần cứng (ví dụ dừng ghi FIFO sau N bit lỗi liên tiếp trong NOSYNC) thay vì chỉ ghi rõ hành vi.

## Giới hạn
- Mô hình mức sample/core_clk, không phải RTL; mô hình RX mới (SyncRx) được kiểm bằng ACQ_EX (Table 20) và các case, chưa có vector tài liệu cho MATCH/watchdog ở mức tick ngoài các case này.
- Rà câu chữ vòng này: TX rà có phạm vi các đoạn bị nhánh RX đổi (phần còn lại đã rà toàn bộ ở vòng trước); RX rà có trọng tâm theo 7 issue và kịch bản S11, S12, S18, S19, đọc Figure 25, 26; chưa đọc lại toàn bộ hình RX.
- Mutation hbpwin và bprzt17 không làm replay FAIL: vector của tài liệu (Table 64/65) không chạm biên 14 sample / t = 17.
- Hình TX I07, I09, I10, I12 và RX I05, I06 dùng mô hình nhỏ mức clock/thanh ghi trong script hình (quy tắc đọc từ văn bản).
- Số trang lấy bằng Word COM trên rev 1.91 (147 trang) và rev 1.92 (147 trang).

## Chạy lại
```
cd ../TX && python -I tools/regress.py ../ALL/work/final && python -I tools/cases_717_tx.py --big && python -I tools/figpair.py tx --png
cd ../RX && python -I tools/regress.py ../ALL/work/final && python -I tools/cases_717_rx.py --big && python -I tools/figpair.py rx --png
python -I ../TX/tools/changelog.py work/r0 work/final state/issues.tsv state/edits/all.json --out work/final/changes.md
```
