--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Formatter for NB-IoT UL path                                  --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2021.02.21                                                    --
-- Target     : Max 8-antennas                                                --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;

entity FORMATTER_8T is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        ARESET                      : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

--------------------------------------------------------------------------------
-- SBIF
--------------------------------------------------------------------------------

        UL_10MS                     : out std_logic;
        UL_TDD                      : out std_logic;
        UL_SYNC                     : out std_logic;
        UL_DATA                     : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- DDUC Side
--------------------------------------------------------------------------------

        DDC_10MS                    : in  std_logic;
        DDC_TDD                     : in  std_logic;
        DDC_SYNC                    : in  std_logic_vector(1 downto 0);
        DDC_DATA                    : in  std_logic_array16(1 downto 0);

--------------------------------------------------------------------------------
-- Path on/off and attenuation
--------------------------------------------------------------------------------

        UL_ON                       : in  std_logic_array4(1 downto 0);

        UL_ATT_0                    : in  std_logic_array20(1 downto 0); 
        UL_ATT_1                    : in  std_logic_array20(1 downto 0); 
        UL_ATT_2                    : in  std_logic_array20(1 downto 0); 
        UL_ATT_3                    : in  std_logic_array20(1 downto 0); 

--------------------------------------------------------------------------------
-- Power Measure (TSSI/RSSI)
--------------------------------------------------------------------------------

        RSSI_0                      : out std_logic_array32(1 downto 0);
        RSSI_1                      : out std_logic_array32(1 downto 0);
        RSSI_2                      : out std_logic_array32(1 downto 0);
        RSSI_3                      : out std_logic_array32(1 downto 0);

        SYNC_MISMATCH               : out std_logic;

--------------------------------------------------------------------------------
-- DUMP
--------------------------------------------------------------------------------

        DUMP_UL_10MS                : out std_logic;
        DUMP_UL_SYNC                : out std_logic;
        DUMP_UL_DATA                : out std_logic_vector(15 downto 0)
    );
end FORMATTER_8T;

architecture BEHAVE of FORMATTER_8T is

    signal ul_mux_delay             : std_logic_vector(23 downto 0) := (others => '0');
    signal ul_onoff_delay           : std_logic_vector(23 downto 0) := (others => '0');
    signal ul_att_delay             : std_logic_vector(23 downto 0) := (others => '0');

    signal ddc_10ms_sh              : std_logic := '0';
    signal ddc_tdd_sh               : std_logic := '0';
    signal ddc_data_sh              : std_logic_array16(1 downto 0) := (others => (others => '0'));

    component RST_SYNC is
    generic (
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port (
        RST_IN                      : in  std_logic;
        CLK                         : in  std_logic;
        RST_OUT                     : out std_logic
    );
    end component;

    signal reset                    : std_logic;

    component PATH_MUX_8T is
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);
        SYNC_MISMATCH               : out std_logic;

        UL_10MS                     : out std_logic;
        UL_TDD                      : out std_logic;
        UL_SYNC                     : out std_logic;
        UL_DATA                     : out std_logic_vector(15 downto 0);

        DDC_10MS                    : in  std_logic;
        DDC_TDD                     : in  std_logic;
        DDC_SYNC                    : in  std_logic_vector(1 downto 0);
        DDC_DATA                    : in  std_logic_array16(1 downto 0)
    );
    end component;

    signal sync_mismatch_err        : std_logic := '0';
    signal ul_mux_10ms              : std_logic;
    signal ul_mux_tdd               : std_logic;
    signal ul_mux_sync              : std_logic;
    signal ul_mux_data              : std_logic_vector(15 downto 0);

    component ATTENUATOR_8T is
    generic (
        RND_WIDTH                   : natural := 20;
        SAT_WIDTH                   : natural := 16
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

        PATH_ON                     : in  std_logic_array4(1 downto 0);
        PATH_ATT_0                  : in  std_logic_array20(1 downto 0); 
        PATH_ATT_1                  : in  std_logic_array20(1 downto 0); 
        PATH_ATT_2                  : in  std_logic_array20(1 downto 0); 
        PATH_ATT_3                  : in  std_logic_array20(1 downto 0); 

        ATT_IN_10MS                 : in  std_logic;
        ATT_IN_TDD                  : in  std_logic;
        ATT_IN_SYNC                 : in  std_logic;
        ATT_IN_DATA                 : in  std_logic_vector(15 downto 0);

        ATT_OUT_10MS                : out std_logic;
        ATT_OUT_TDD                 : out std_logic;
        ATT_OUT_SYNC                : out std_logic;
        ATT_OUT_DATA                : out std_logic_vector(SAT_WIDTH-1 downto 0)
    );
    end component;

    signal ul_att_10ms              : std_logic;
    signal ul_att_tdd               : std_logic;
    signal ul_att_sync              : std_logic;
    signal ul_att_sync_sh           : std_logic;
    signal ul_att_data              : std_logic_vector(15 downto 0);

    component XSSI_8T is    -- 1.92Msps NB-IoT 4T 2cell
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;     -- 491.52MHz

        I_MEAS_SYNC                 : in  std_logic;
        I_TDD                       : in  std_logic;
        I_DATA_SYNC                 : in  std_logic;
        I_DATA_IQ                   : in  std_logic_vector(15 downto 0);
        
        O_MEAS_DONE                 : out std_logic_array4( 1 downto 0); 
        O_XSSI_ANT0                 : out std_logic_array32(1 downto 0); 
        O_XSSI_ANT1                 : out std_logic_array32(1 downto 0); 
        O_XSSI_ANT2                 : out std_logic_array32(1 downto 0); 
        O_XSSI_ANT3                 : out std_logic_array32(1 downto 0)  
    );
    end component;

    signal rssi_done                : std_logic_array4( 1 downto 0);
    signal rssi_0_i                 : std_logic_array32(1 downto 0);
    signal rssi_1_i                 : std_logic_array32(1 downto 0);
    signal rssi_2_i                 : std_logic_array32(1 downto 0);
    signal rssi_3_i                 : std_logic_array32(1 downto 0);

    signal rssi_update_en           : std_logic_vector(3 downto 0);

    component PATH_ON is
    generic (
        ANT_NUM                     : natural := 4
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

        PATH_ON                     : in  std_logic_vector(ANT_NUM-1 downto 0);

        IN_10MS                     : in  std_logic;
        IN_TDD                      : in  std_logic;
        IN_SYNC                     : in  std_logic;
        IN_DATA                     : in  std_logic_vector(15 downto 0);

        OUT_10MS                    : out std_logic;
        OUT_TDD                     : out std_logic;
        OUT_SYNC                    : out std_logic;
        OUT_DATA                    : out std_logic_vector(15 downto 0)
    );
    end component;
    
    signal ul_onoff_10ms            : std_logic;
    signal ul_onoff_tdd             : std_logic;
    signal ul_onoff_sync            : std_logic;
    signal ul_onoff_sync_sh         : std_logic;
    signal ul_onoff_data            : std_logic_vector(15 downto 0);
    
begin

    PROCESSING_DELAY_UL <= ul_onoff_delay + ul_att_delay + ul_mux_delay + 2;

    -- DDC
    process (reset, CLK)
    begin
        if (reset = '1') then
            ddc_10ms_sh <= '0';
            ddc_tdd_sh  <= '0';
            ddc_data_sh <= (others => (others => '0'));
        elsif (CLK'event and CLK = '1') then
            ddc_10ms_sh <= DDC_10MS;
            ddc_tdd_sh  <= DDC_TDD;
            ddc_data_sh <= DDC_DATA;
        end if;
    end process;

    -- Mapper output
    process (reset, CLK)
    begin
        if (reset = '1') then
            UL_10MS <= '0';
            UL_TDD  <= '0';
            UL_SYNC <= '0';
            UL_DATA <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            ul_onoff_sync_sh <= ul_onoff_sync;
            UL_10MS <= ul_onoff_10ms;  
            UL_TDD  <= ul_onoff_tdd ;  
            UL_SYNC <= ul_onoff_sync_sh;  
            UL_DATA <= ul_onoff_data;  
        end if;
    end process;

    -- input sync mismatch err flag
    SYNC_MISMATCH <= sync_mismatch_err;

    -- Dump
    DUMP_UL_10MS <= ul_mux_10ms;
    DUMP_UL_SYNC <= ul_mux_sync;
    DUMP_UL_DATA <= ul_mux_data;

--------------------------------------------------------------------------------
-- Power measure
--------------------------------------------------------------------------------

    -- RSSI result update
    process (reset, CLK)
    begin
        if (reset = '1') then
            RSSI_0 <= (others => (others => '0'));
            RSSI_1 <= (others => (others => '0'));
            RSSI_2 <= (others => (others => '0'));
            RSSI_3 <= (others => (others => '0'));
        elsif (CLK'event and CLK = '1') then
            RSSI_0 <= rssi_0_i; 
            RSSI_1 <= rssi_1_i; 
            RSSI_2 <= rssi_2_i; 
            RSSI_3 <= rssi_3_i; 
        end if;
    end process;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_RESET : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => ARESET                                  ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;
        RST_OUT                     => reset                                    --: out std_logic
    );

--------------------------------------------------------------------------------
-- UL component mapping
--------------------------------------------------------------------------------

    U_UL_PATH_MUX : PATH_MUX_8T 
    port map(
        RESET                       => reset                                   ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;

        PROCESSING_DELAY_UL         => ul_mux_delay                            ,--: out std_logic_vector(23 downto 0);
        SYNC_MISMATCH               => sync_mismatch_err                       ,--: out std_logic;

        UL_10MS                     => ul_mux_10ms                             ,--: out std_logic;
        UL_TDD                      => ul_mux_tdd                              ,--: out std_logic;
        UL_SYNC                     => ul_mux_sync                             ,--: out std_logic;
        UL_DATA                     => ul_mux_data                             ,--: out std_logic_vector(15 downto 0);

        DDC_10MS                    => ddc_10ms_sh                             ,--: in  std_logic;
        DDC_TDD                     => ddc_tdd_sh                              ,--: in  std_logic;
        DDC_SYNC                    => DDC_SYNC                                ,--: in  std_logic_vector(1 downto 0);
        DDC_DATA                    => ddc_data_sh                              --: in  std_logic_array16(1 downto 0)
    );

    u_UL_ATT : ATTENUATOR_8T
    generic map(
        RND_WIDTH                   => 22                                      ,--: natural := 20;
        SAT_WIDTH                   => 16                                       --: natural := 16
    )
    port map(
        RESET                       => reset                                   ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;

        PROCESSING_DELAY            => ul_att_delay                            ,--: out std_logic_vector(23 downto 0);

        PATH_ON                     => (others => (others => '1'))             ,--: in  std_logic_array4(1 downto 0);
        PATH_ATT_0                  => UL_ATT_0                                ,--: in  std_logic_array20(1 downto 0);
        PATH_ATT_1                  => UL_ATT_1                                ,--: in  std_logic_array20(1 downto 0);
        PATH_ATT_2                  => UL_ATT_2                                ,--: in  std_logic_array20(1 downto 0);
        PATH_ATT_3                  => UL_ATT_3                                ,--: in  std_logic_array20(1 downto 0);

        ATT_IN_10MS                 => ul_mux_10ms                             ,--: in  std_logic;
        ATT_IN_TDD                  => ul_mux_tdd                              ,--: in  std_logic;
        ATT_IN_SYNC                 => ul_mux_sync                             ,--: in  std_logic;
        ATT_IN_DATA                 => ul_mux_data                             ,--: in  std_logic_vector(15 downto 0);

        ATT_OUT_10MS                => ul_att_10ms                             ,--: out std_logic;
        ATT_OUT_TDD                 => ul_att_tdd                              ,--: out std_logic;
        ATT_OUT_SYNC                => ul_att_sync                             ,--: out std_logic;
        ATT_OUT_DATA                => ul_att_data                              --: out std_logic_vector(SAT_WIDTH-1 downto 0)
    );

    U_UL_PATH_ON : PATH_ON 
    generic map(
        ANT_NUM                     => 8                                        --: natural := 4
    )
    port map(
        RESET                       => reset                                   ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;

        PROCESSING_DELAY            => ul_onoff_delay                          ,--: out std_logic_vector(23 downto 0);

        PATH_ON(3 downto 0)         => UL_ON(0)                                ,--: in  std_logic_vector(ANT_NUM-1 downto 0);
        PATH_ON(7 downto 4)         => UL_ON(1)                                ,--: in  std_logic_vector(ANT_NUM-1 downto 0);

        IN_10MS                     => ul_att_10ms                             ,--: in  std_logic;
        IN_TDD                      => ul_att_tdd                              ,--: in  std_logic;
        IN_SYNC                     => ul_att_sync                             ,--: in  std_logic;
        IN_DATA                     => ul_att_data                             ,--: in  std_logic_vector(15 downto 0);

        OUT_10MS                    => ul_onoff_10ms                           ,--: out std_logic;
        OUT_TDD                     => ul_onoff_tdd                            ,--: out std_logic;
        OUT_SYNC                    => ul_onoff_sync                           ,--: out std_logic;
        OUT_DATA                    => ul_onoff_data                            --: out std_logic_vector(15 downto 0)
    );
    
--------------------------------------------------------------------------------
-- Power measurement component mapping
--------------------------------------------------------------------------------

    U_RSSI : XSSI_8T 
    port map(
        RESET                      => reset                                   ,--: in  std_logic;
        CLK                        => CLK                                     ,--: in  std_logic;     -- 491.52MHz
                                            
        I_MEAS_SYNC                => ul_att_10ms                             ,--: in  std_logic;
        I_TDD                      => '1'                                     ,--: in  std_logic;
        I_DATA_SYNC                => ul_att_sync                             ,--: in  std_logic;
        I_DATA_IQ                  => ul_att_data                             ,--: in  std_logic_vector(15 downto 0);
        
        O_MEAS_DONE                => rssi_done                               ,--: out std_logic_array4( 1 downto 0);
        O_XSSI_ANT0                => rssi_0_i                                ,--: out std_logic_array32(1 downto 0);
        O_XSSI_ANT1                => rssi_1_i                                ,--: out std_logic_array32(1 downto 0);
        O_XSSI_ANT2                => rssi_2_i                                ,--: out std_logic_array32(1 downto 0);
        O_XSSI_ANT3                => rssi_3_i                                 --: out std_logic_array32(1 downto 0) 
    );


end BEHAVE;
