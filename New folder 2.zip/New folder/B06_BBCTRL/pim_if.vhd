--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : PIM interface                                                 --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity PIM_IF is
    generic (
        PIM_NUM                     : natural := 2
    );
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        CLK_SYSX8                   : in  std_logic;

--------------------------------------------------------------------------------
-- PIM_SBIF_TOP
--------------------------------------------------------------------------------

        PIM_SBIF_RX_ENB_IN          : in  std_logic_vector(PIM_NUM-1 downto 0);
        PIM_SBIF_RX_I_IN            : in  std_logic_array16(PIM_NUM-1 downto 0);
        PIM_SBIF_RX_Q_IN            : in  std_logic_array16(PIM_NUM-1 downto 0);

        PIM_SBIF_TX_VLD_OUT         : out std_logic_vector(PIM_NUM-1 downto 0);
        PIM_SBIF_TX_I_OUT           : out std_logic_array16(PIM_NUM-1 downto 0);
        PIM_SBIF_TX_Q_OUT           : out std_logic_array16(PIM_NUM-1 downto 0);

--------------------------------------------------------------------------------
-- DSP_TOP
--------------------------------------------------------------------------------

        PIM_SYNC_IN                 : in  std_logic_vector(PIM_NUM-1 downto 0);
        PIM_I_IN                    : in  std_logic_array15(PIM_NUM-1 downto 0);
        PIM_Q_IN                    : in  std_logic_array15(PIM_NUM-1 downto 0);

        PIM_SYNC_OUT                : out std_logic_vector(PIM_NUM-1 downto 0);
        PIM_I_OUT                   : out std_logic_array15(PIM_NUM-1 downto 0);
        PIM_Q_OUT                   : out std_logic_array15(PIM_NUM-1 downto 0)
    );
end PIM_IF;

architecture BEHAVE of PIM_IF is

    component CONV_16TO15 is
    port (
        CLK                         : in  std_logic;

        CONV_IN_10MS                : in  std_logic;
        CONV_IN_TDD                 : in  std_logic;
        CONV_IN_SYNC                : in  std_logic;
        CONV_IN_DATA_I              : in  std_logic_vector(15 downto 0);
        CONV_IN_DATA_Q              : in  std_logic_vector(15 downto 0);

        CONV_OUT_10MS               : out std_logic;
        CONV_OUT_TDD                : out std_logic;
        CONV_OUT_SYNC               : out std_logic;
        CONV_OUT_DATA_I             : out std_logic_vector(14 downto 0);
        CONV_OUT_DATA_Q             : out std_logic_vector(14 downto 0)
    );
    end component;

    component CONV_15TO16 is
    port (
        CLK                         : in  std_logic;

        LINE_RCF_CLKTYPE            : in  std_logic_vector(7 downto 0);
    
        CONV_IN_SYNC                : in  std_logic;
        CONV_IN_DATA_I              : in  std_logic_vector(14 downto 0);
        CONV_IN_DATA_Q              : in  std_logic_vector(14 downto 0);

        CONV_OUT_SYNC               : out std_logic;
        CONV_OUT_DATA_I             : out std_logic_vector(15 downto 0);
        CONV_OUT_DATA_Q             : out std_logic_vector(15 downto 0)
    );
    end component;

    signal pim_sync                 : std_logic_array7(PIM_NUM-1 downto 0) := (others => (others => '0'));

begin

    u_PORT : for i in PIM_NUM-1 downto 0 generate
    u_RX : CONV_16TO15
    port map(
        CLK                         => CLK_SYSX8                               ,--: in  std_logic;

        CONV_IN_10MS                => '0'                                     ,--: in  std_logic;
        CONV_IN_TDD                 => '0'                                     ,--: in  std_logic;
        CONV_IN_SYNC                => PIM_SBIF_RX_ENB_IN(i)                   ,--: in  std_logic;
        CONV_IN_DATA_I              => PIM_SBIF_RX_I_IN(i)                     ,--: in  std_logic_vector(15 downto 0);
        CONV_IN_DATA_Q              => PIM_SBIF_RX_Q_IN(i)                     ,--: in  std_logic_vector(15 downto 0);

        CONV_OUT_10MS               => open                                    ,--: out std_logic;
        CONV_OUT_TDD                => open                                    ,--: out std_logic;
        CONV_OUT_SYNC               => PIM_SYNC_OUT(i)                         ,--: out std_logic;
        CONV_OUT_DATA_I             => PIM_I_OUT(i)                            ,--: out std_logic_vector(14 downto 0);
        CONV_OUT_DATA_Q             => PIM_Q_OUT(i)                             --: out std_logic_vector(14 downto 0)
    );

    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            pim_sync(i) <= pim_sync(i)(5 downto 0) & PIM_SYNC_IN(i);
        end if;
    end process;

    PIM_SBIF_TX_VLD_OUT(i) <= pim_sync(i)(6);

    u_TX : CONV_15TO16
    port map(
        CLK                         => CLK_SYSX8                               ,--: in  std_logic;

        LINE_RCF_CLKTYPE            => x"40"                                   ,--: in  std_logic_vector(7 downto 0);
    
        CONV_IN_SYNC                => pim_sync(i)(6)                          ,--: in  std_logic;
        CONV_IN_DATA_I              => PIM_I_IN(i)                             ,--: in  std_logic_vector(14 downto 0);
        CONV_IN_DATA_Q              => PIM_Q_IN(i)                             ,--: in  std_logic_vector(14 downto 0);

        CONV_OUT_SYNC               => open                                    ,--: out std_logic;
        CONV_OUT_DATA_I             => PIM_SBIF_TX_I_OUT(i)                    ,--: out std_logic_vector(15 downto 0);
        CONV_OUT_DATA_Q             => PIM_SBIF_TX_Q_OUT(i)                     --: out std_logic_vector(15 downto 0)
    );
    end generate;

end BEHAVE;