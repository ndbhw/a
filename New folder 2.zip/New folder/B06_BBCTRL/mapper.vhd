--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Mapper                                                        --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity MAPPER is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        ARESET                      : in  std_logic;

        CLK_AUX                     : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        BW_SEL                      : in  std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- CPRI
--------------------------------------------------------------------------------

        RX_10MS                     : in  std_logic;
        RX_BFN                      : in  std_logic_vector(11 downto 0);
        RX_TDD                      : in  std_logic;
        RX_SYNC                     : in  std_logic;
        RX_DATA_I                   : in  std_logic_vector(15 downto 0);
        RX_DATA_Q                   : in  std_logic_vector(15 downto 0);

        TX_10MS                     : out std_logic;
        TX_TDD                      : out std_logic;
        TX_SYNC                     : in  std_logic;
        TX_DATA_I                   : out std_logic_vector(15 downto 0);
        TX_DATA_Q                   : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- Map switch
--------------------------------------------------------------------------------

        DL_10MS                     : out std_logic;
        DL_BFN                      : out std_logic_vector(11 downto 0);
        DL_TDD                      : out std_logic;
        DL_SYNC                     : out std_logic;
        DL_DATA                     : out std_logic_vector(15 downto 0);

        UL_10MS                     : in  std_logic;
        UL_TDD                      : in  std_logic;
        UL_SYNC                     : in  std_logic;
        UL_DATA                     : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- AxC control
--------------------------------------------------------------------------------

        DL_MAP_WR_EN                : in  std_logic;
        DL_MAP_WR_ADDR              : in  std_logic_vector(4 downto 0);
        DL_MAP_WR_DATA              : in  std_logic_vector(6 downto 0);
        DL_MAP_RD_DATA              : out std_logic_vector(6 downto 0);

        UL_MAP_WR_EN                : in  std_logic;
        UL_MAP_WR_ADDR              : in  std_logic_vector(5 downto 0);
        UL_MAP_WR_DATA              : in  std_logic_vector(6 downto 0);
        UL_MAP_RD_DATA              : out std_logic_vector(6 downto 0)
    );
end MAPPER;

architecture BEHAVE of MAPPER is

    signal rx_sync_buf              : std_logic := '0';
    signal tx_sync_buf              : std_logic_vector(5 downto 0) := (others => '0');
    signal delay_check              : std_logic_vector(2 downto 0) := (others => '0');

    component RST_SYNC is
    generic (
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port (
        RST_IN                      : in  std_logic;
        CLK                         : in  std_logic;
        RST_OUT                     : out std_logic
    );
    end component;

    signal reset                    : std_logic;

    component MAP_DL_ADDR_BUFFER is
    port (
        A                           : in  std_logic_vector(4 downto 0);
        D                           : in  std_logic_vector(6 downto 0);
        DPRA                        : in  std_logic_vector(4 downto 0);
        CLK                         : in  std_logic;
        WE                          : in  std_logic;
        QDPO_CLK                    : in  std_logic;
        QDPO                        : out std_logic_vector(6 downto 0)
    );
    end component;

    signal map_dl_resync            : std_logic_vector(2 downto 0) := (others => '0');
    signal map_dl_bank              : std_logic_vector(1 downto 0) := (others => '0');
    signal map_dl_mask              : std_logic_vector(2 downto 0) := (others => '0');
    signal map_dl_addr              : std_logic_vector(5 downto 0) := (others => '0');
    signal map_dl_data              : std_logic_vector(6 downto 0);

    component MAP_UL_ADDR_BUFFER is
    port (
        A                           : in  std_logic_vector(5 downto 0);
        D                           : in  std_logic_vector(6 downto 0);
        DPRA                        : in  std_logic_vector(5 downto 0);
        CLK                         : in  std_logic;
        WE                          : in  std_logic;
        QDPO_CLK                    : in  std_logic;
        QDPO                        : out std_logic_vector(6 downto 0)
    );
    end component;

    signal map_ul_resync            : std_logic_vector(2 downto 0) := (others => '0');
    signal map_ul_bank              : std_logic_vector(1 downto 0) := (others => '0');
    signal map_ul_mask              : std_logic_vector(2 downto 0) := (others => '0');
    signal map_ul_addr              : std_logic_vector(5 downto 0) := (others => '0');
    signal map_ul_data              : std_logic_vector(6 downto 0);

    component MAP_DATA_BUFFER is
    port (
        CLKA                        : in  std_logic;
        WEA                         : in  std_logic_vector(0 downto 0);
        ADDRA                       : in  std_logic_vector(7 downto 0);
        DINA                        : in  std_logic_vector(35 downto 0);
        CLKB                        : in  std_logic;
        ADDRB                       : in  std_logic_vector(7 downto 0);
        DOUTB                       : out std_logic_vector(35 downto 0)
    );
    end component;

    signal dl_addra                 : std_logic_vector(7 downto 0) := (others => '0');
    signal dl_dina                  : std_logic_vector(35 downto 0) := (others => '0');
    signal dl_addrb                 : std_logic_vector(7 downto 0) := (others => '0');
    signal dl_doutb                 : std_logic_vector(35 downto 0);
    signal ul_wea                   : std_logic_vector(0 downto 0) := (others => '0');
    signal ul_init                  : std_logic := '0';
    signal ul_addra                 : std_logic_vector(7 downto 0) := (others => '0');
    signal ul_dina                  : std_logic_vector(35 downto 0) := (others => '0');
    signal ul_addrb                 : std_logic_vector(7 downto 0) := (others => '0');
    signal ul_doutb                 : std_logic_vector(35 downto 0);


begin

    PROCESSING_DELAY_DL <= conv_std_logic_vector(137, 24);
    PROCESSING_DELAY_UL <= conv_std_logic_vector(144, 24);

--    process (CLK_SYSX8)
--    begin
--        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
--            delay_check <= delay_check(1 downto 0) & map_ul_bank(1);
--            PROCESSING_DELAY_UL(23 downto 8) <= (others => '0');
--            if (delay_check(2 downto 1) = "10") then
--                PROCESSING_DELAY_UL(7 downto 0)  <= ul_addra + 4;
--            end if;
--        end if;
--    end process;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_RESET : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => ARESET                                  ,--: in  std_logic;
        CLK                         => CLK_SYSX8                               ,--: in  std_logic;
        RST_OUT                     => reset                                    --: out std_logic
    );

--------------------------------------------------------------------------------
-- DL component mapping
--------------------------------------------------------------------------------

    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            rx_sync_buf <= RX_SYNC;
        end if;
    end process;

    -- DL write address
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (rx_sync_buf = '1') then
                dl_addra <= (dl_addra(7 downto 6) + 1) & "000000";
            else
                dl_addra <= dl_addra + 1;
            end if;
        end if;
    end process;

    -- DL write data
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            dl_dina(15 downto 0)  <= RX_DATA_I;
            dl_dina(31 downto 16) <= RX_DATA_Q;
            dl_dina(32)           <= RX_10MS;
            dl_dina(33)           <= RX_TDD;
            dl_dina(34)           <= '0';
            dl_dina(35)           <= '0';
        end if;
    end process;

    -- DL read address buffer
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            map_dl_resync <= map_dl_resync(1 downto 0) & dl_addra(7);
            if (map_dl_resync(2 downto 1) = "10") then
                map_dl_addr <= (others => '0');
            else
                map_dl_addr <= map_dl_addr + 1;
            end if;
            if (map_dl_resync(2 downto 1) = "10") then
                map_dl_bank <= "01";
            else
                if (map_dl_addr = 0) then
                    map_dl_bank <= map_dl_bank + 1;
                end if;
            end if;
            map_dl_mask(0) <= map_dl_data(6);
            map_dl_mask(1) <= map_dl_mask(0);
            map_dl_mask(2) <= map_dl_mask(1);
        end if;
    end process;

    -- DL read address
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
       --     if (map_dl_data = "1111111") then
       --         dl_addrb <= dl_addrb;
       --     else
                dl_addrb <= map_dl_bank & map_dl_data(5 downto 0);
       --     end if;
        end if;
    end process;

    -- BFN (Didn't be aligned to 10msec signal.)
    DL_BFN  <= RX_BFN;

    -- DL read data
    process (reset, CLK_SYSX8)
    begin
        if (reset = '1') then
            DL_10MS <= '0';
            DL_TDD  <= '0';
            DL_SYNC <= '0';
            DL_DATA <= (others => '0');
        elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (map_dl_addr = 4) then
                DL_10MS <= dl_doutb(32);
                DL_TDD  <= dl_doutb(33);
            end if;
            if (map_dl_addr = 3) then
                DL_SYNC <= '1';
            else
                DL_SYNC <= '0';
            end if;
            if (map_dl_mask(2) = '0') then
                if (map_dl_addr(0) = '0') then 
                    DL_DATA <= dl_doutb(15 downto 0);
                else
                    DL_DATA <= dl_doutb(31 downto 16);
                end if;
            else
                DL_DATA <= (others => '0');
            end if;
        end if;
    end process;

    u_DL_ADDR_BUF : MAP_DL_ADDR_BUFFER
    port map(
        A                           => DL_MAP_WR_ADDR                          ,--: in  std_logic_vector(4 downto 0);
        D                           => DL_MAP_WR_DATA                          ,--: in  std_logic_vector(6 downto 0);
        DPRA                        => map_dl_addr(5 downto 1)                 ,--: in  std_logic_vector(4 downto 0);
        CLK                         => CLK_AUX                                 ,--: in  std_logic;
        WE                          => DL_MAP_WR_EN                            ,--: in  std_logic;
        QDPO_CLK                    => CLK_SYSX8                               ,--: in  std_logic;
        QDPO                        => map_dl_data                              --: out std_logic_vector(6 downto 0)
    );

    u_DL_ADDR_READBACK : MAP_DL_ADDR_BUFFER
    port map(
        A                           => DL_MAP_WR_ADDR                          ,--: in  std_logic_vector(4 downto 0);
        D                           => DL_MAP_WR_DATA                          ,--: in  std_logic_vector(6 downto 0);
        DPRA                        => DL_MAP_WR_ADDR                          ,--: in  std_logic_vector(4 downto 0);
        CLK                         => CLK_AUX                                 ,--: in  std_logic;
        WE                          => DL_MAP_WR_EN                            ,--: in  std_logic;
        QDPO_CLK                    => CLK_AUX                                 ,--: in  std_logic;
        QDPO                        => DL_MAP_RD_DATA                           --: out std_logic_vector(6 downto 0)
    );

    u_DL_DATA_BUF : MAP_DATA_BUFFER
    port map(
        CLKA                        => CLK_SYSX8                               ,--: in  std_logic;
        WEA                         => "1"                                     ,--: in  std_logic_vector(0 downto 0);
        ADDRA                       => dl_addra                                ,--: in  std_logic_vector(7 downto 0);
        DINA                        => dl_dina                                 ,--: in  std_logic_vector(35 downto 0);
        CLKB                        => CLK_SYSX8                               ,--: in  std_logic;
        ADDRB                       => dl_addrb                                ,--: in  std_logic_vector(7 downto 0);
        DOUTB                       => dl_doutb                                 --: out std_logic_vector(35 downto 0)
    );

--------------------------------------------------------------------------------
-- UL component mapping
--------------------------------------------------------------------------------

    -- UL write enable
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            ul_wea(0) <= ul_addra(0);
        end if;
    end process;

    -- UL write address
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            map_ul_resync <= map_ul_resync(1 downto 0) & map_ul_bank(1);
            if (map_ul_resync(2 downto 1) = "01") then
                ul_init <= '1';
            elsif (UL_SYNC = '1') then
                ul_init <= '0';
            end if;
            if (UL_SYNC = '1' and ul_init = '1') then
                case BW_SEL is
                when "0010" => ul_addra <= "00011110";
                when "0011" => ul_addra <= "00001110";
                when others => ul_addra <= "00000110";
                end case;
            else
                ul_addra <= ul_addra + 1;
            end if;
        end if;
    end process;

    -- UL write data
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (ul_addra(0) = '0') then
                ul_dina(15 downto 0)  <= UL_DATA;
            end if;
            if (ul_addra(0) = '1') then
                ul_dina(31 downto 16) <= UL_DATA;
            end if;
            ul_dina(32) <= '0';
            ul_dina(33) <= '0';
            ul_dina(34) <= '0';
            ul_dina(35) <= '0';
        end if;
    end process;

    -- UL read address buffer
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (TX_SYNC = '1') then
                if (BW_SEL = x"2") then
                     map_ul_addr <= "000101";
                elsif (BW_SEL = x"3") then
                     map_ul_addr <= "000101";
                else
                     map_ul_addr <= "000101";
                end if;
            else
                map_ul_addr <= map_ul_addr + 1;
            end if;
            if (map_ul_addr = "000000") then
                map_ul_bank <= map_ul_bank + 1;
            end if;
            map_ul_mask(0) <= map_ul_data(6);
            map_ul_mask(1) <= map_ul_mask(0);
            map_ul_mask(2) <= map_ul_mask(1);
        end if;
    end process;

    -- UL read address
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (map_ul_data = "1111111") then
                ul_addrb <= ul_addrb;
            else
                ul_addrb <= '0' & map_ul_bank & map_ul_data(4 downto 0);
            end if;
        end if;
    end process;

    TX_10MS <= '0';
    TX_TDD  <= '0';

    -- UL read data
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (map_ul_mask(2) = '0') then
                TX_DATA_I <= ul_doutb(15 downto 0);
                TX_DATA_Q <= ul_doutb(31 downto 16);
            else
                TX_DATA_I <= (others => '0');
                TX_DATA_Q <= (others => '0');
            end if;
        end if;
    end process;

    u_UL_ADDR_BUF : MAP_UL_ADDR_BUFFER
    port map(
        A                           => UL_MAP_WR_ADDR                          ,--: in  std_logic_vector(5 downto 0);
        D                           => UL_MAP_WR_DATA                          ,--: in  std_logic_vector(6 downto 0);
        DPRA                        => map_ul_addr                             ,--: in  std_logic_vector(5 downto 0);
        CLK                         => CLK_AUX                                 ,--: in  std_logic;
        WE                          => UL_MAP_WR_EN                            ,--: in  std_logic;
        QDPO_CLK                    => CLK_SYSX8                               ,--: in  std_logic;
        QDPO                        => map_ul_data                              --: out std_logic_vector(6 downto 0)
    );

    u_UL_ADDR_READBACK : MAP_UL_ADDR_BUFFER
    port map(
        A                           => UL_MAP_WR_ADDR                          ,--: in  std_logic_vector(5 downto 0);
        D                           => UL_MAP_WR_DATA                          ,--: in  std_logic_vector(6 downto 0);
        DPRA                        => UL_MAP_WR_ADDR                          ,--: in  std_logic_vector(5 downto 0);
        CLK                         => CLK_AUX                                 ,--: in  std_logic;
        WE                          => UL_MAP_WR_EN                            ,--: in  std_logic;
        QDPO_CLK                    => CLK_AUX                                 ,--: in  std_logic;
        QDPO                        => UL_MAP_RD_DATA                           --: out std_logic_vector(6 downto 0)
    );

    u_UL_DATA_BUF : MAP_DATA_BUFFER
    port map(
        CLKA                        => CLK_SYSX8                               ,--: in  std_logic;
        WEA                         => ul_wea                                  ,--: in  std_logic_vector(0 downto 0);
        ADDRA(7)                    => '0'                                     ,--: in  std_logic_vector(7 downto 0);
        ADDRA(6 downto 0)           => ul_addra(7 downto 1)                    ,--: in  std_logic_vector(7 downto 0);
        DINA                        => ul_dina                                 ,--: in  std_logic_vector(35 downto 0);
        CLKB                        => CLK_SYSX8                               ,--: in  std_logic;
        ADDRB                       => ul_addrb                                ,--: in  std_logic_vector(7 downto 0);
        DOUTB                       => ul_doutb                                 --: out std_logic_vector(35 downto 0)
    );

end BEHAVE;
