--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Attenuator (Formatter component)                              --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------
-- Processing delay 9-clocks                                                  --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity GSM_ATTENUATOR is
    generic (
        ANT_NUM                     : natural := 16;
        RND_WIDTH                   : natural := 20;
        SAT_WIDTH                   : natural := 16
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

        PATH_ON                     : in  std_logic_vector(ANT_NUM-1 downto 0);
        PATH_ATT                    : in  std_logic_array20(ANT_NUM-1 downto 0);

        ATT_IN_120MS_SYNC           : in  std_logic;
        ATT_IN_TS16_SYNC            : in  std_logic;
        ATT_IN_TS_SYNC              : in  std_logic;
        ATT_IN_TS_GP_SYNC           : in  std_logic;

        ATT_IN_10MS                 : in  std_logic;
        ATT_IN_TDD                  : in  std_logic;
        ATT_IN_SYNC                 : in  std_logic;
        ATT_IN_DATA                 : in  std_logic_vector(15 downto 0);

        ATT_OUT_120MS_SYNC          : out std_logic;
        ATT_OUT_TS16_SYNC           : out std_logic;
        ATT_OUT_TS_SYNC             : out std_logic;
        ATT_OUT_TS_GP_SYNC          : out std_logic;

        ATT_OUT_10MS                : out std_logic;
        ATT_OUT_TDD                 : out std_logic;
        ATT_OUT_SYNC                : out std_logic;
        ATT_OUT_DATA                : out std_logic_vector(SAT_WIDTH-1 downto 0)
    );
end GSM_ATTENUATOR;

architecture BEHAVE of GSM_ATTENUATOR is

    signal in_120ms_sync            : std_logic_vector(7 downto 0) := (others => '0');
    signal in_ts16_sync             : std_logic_vector(7 downto 0) := (others => '0');
    signal in_ts_sync               : std_logic_vector(7 downto 0) := (others => '0');
    signal in_ts_gp_sync            : std_logic_vector(7 downto 0) := (others => '0');

    signal in_10ms                  : std_logic_vector(7 downto 0) := (others => '0');
    signal in_tdd                   : std_logic_vector(7 downto 0) := (others => '0');
    signal in_sync                  : std_logic_vector(7 downto 0) := (others => '0');
    signal cnt_sync                 : std_logic_vector(7 downto 0) := (others => '0');

    signal att                      : std_logic_array20(15 downto 0) := (others => (others => '0'));

    component MULT_16X21 is
    port (
        CLK                         : in  std_logic;
        A                           : in  std_logic_vector(15 downto 0);
        B                           : in  std_logic_vector(20 downto 0);
        P                           : out std_logic_vector(36 downto 0)
    );
    end component;

    signal a                        : std_logic_vector(15 downto 0);
    signal b                        : std_logic_vector(20 downto 0);
    signal p                        : std_logic_vector(36 downto 0);

    component ATT_ROD is
    generic (
        INPUT_WIDTH                 : natural := 32;
        OUTPUT_WIDTH                : natural := 20
    );
    port (
        CLK                         : in  std_logic;
        ROD_IN                      : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
        ROD_OUT                     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
    end component;

    signal data_rnd                 : std_logic_vector(RND_WIDTH-1 downto 0);

    component ATT_SAT is
    generic (
        INPUT_WIDTH                 : natural := 20;
        OUTPUT_WIDTH                : natural := 16
    );
    port (
        CLK                         : in  std_logic;
        SAT_IN                      : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
        SAT_OUT                     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
    end component;

    signal data_sat                 : std_logic_vector(SAT_WIDTH-1 downto 0);
    
begin

    PROCESSING_DELAY <= x"000009";

    -- buffering
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            in_120ms_sync <= in_120ms_sync(6 downto 0) & ATT_IN_120MS_SYNC; 
            in_ts16_sync  <= in_ts16_sync (6 downto 0) & ATT_IN_TS16_SYNC ; 
            in_ts_sync    <= in_ts_sync   (6 downto 0) & ATT_IN_TS_SYNC   ; 
            in_ts_gp_sync <= in_ts_gp_sync(6 downto 0) & ATT_IN_TS_GP_SYNC; 
            in_10ms       <= in_10ms(6 downto 0) & ATT_IN_10MS;
            in_tdd        <= in_tdd(6 downto 0)  & ATT_IN_TDD;
            in_sync       <= in_sync(6 downto 0) & ATT_IN_SYNC;
        end if;
    end process;

    -- synchronization
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (ATT_IN_SYNC = '1') then
                cnt_sync <= (others => '0');
            else
                cnt_sync <= cnt_sync + 1;
            end if;
        end if;
    end process;

    G_ANT_NUM : for i in 0 to ANT_NUM-1 generate

    -- path on/off
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (PATH_ON(i) = '1') then                  
                att(i) <= PATH_ATT(i);
            else                                      
                att(i) <= (others => '0');
            end if;
        end if;
    end process;

    end generate;

    -- multiplier input
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
                                                        a <= ATT_IN_DATA;
            if    (cnt_sync(4 downto 1) = 0) then       b <= '0' & att( 0);
            elsif (cnt_sync(4 downto 1) = 1) then       b <= '0' & att( 1);
            elsif (cnt_sync(4 downto 1) = 2) then       b <= '0' & att( 2);
            elsif (cnt_sync(4 downto 1) = 3) then       b <= '0' & att( 3);
            elsif (cnt_sync(4 downto 1) = 4) then       b <= '0' & att( 4);
            elsif (cnt_sync(4 downto 1) = 5) then       b <= '0' & att( 5);
            elsif (cnt_sync(4 downto 1) = 6) then       b <= '0' & att( 6);
            elsif (cnt_sync(4 downto 1) = 7) then       b <= '0' & att( 7);
            elsif (cnt_sync(4 downto 1) = 8) then       b <= '0' & att( 8);
            elsif (cnt_sync(4 downto 1) = 9) then       b <= '0' & att( 9);
            elsif (cnt_sync(4 downto 1) =10) then       b <= '0' & att(10);
            elsif (cnt_sync(4 downto 1) =11) then       b <= '0' & att(11);
            elsif (cnt_sync(4 downto 1) =12) then       b <= '0' & att(12);
            elsif (cnt_sync(4 downto 1) =13) then       b <= '0' & att(13);
            elsif (cnt_sync(4 downto 1) =14) then       b <= '0' & att(14);
            elsif (cnt_sync(4 downto 1) =15) then       b <= '0' & att(15);
            end if;
        end if;
    end process;

    -- output data
    process (RESET, CLK)
    begin
        if (RESET = '1') then
            ATT_OUT_10MS <= '0';
            ATT_OUT_TDD  <= '0';
            ATT_OUT_SYNC <= '0';
            ATT_OUT_DATA <= (others => '0');
            ATT_OUT_TS16_SYNC  <= '0'; 
            ATT_OUT_TS_SYNC    <= '0'; 
            ATT_OUT_TS_GP_SYNC <= '0'; 
        elsif (CLK'event and CLK = '1') then
            ATT_OUT_10ms <= in_10ms(7);
            ATT_OUT_TDD  <= in_tdd(7);
            ATT_OUT_SYNC <= in_sync(7);
            ATT_OUT_DATA <= data_sat;
            ATT_OUT_120MS_SYNC <= in_120ms_sync(7); 
            ATT_OUT_TS16_SYNC  <= in_ts16_sync (7); 
            ATT_OUT_TS_SYNC    <= in_ts_sync   (7); 
            ATT_OUT_TS_GP_SYNC <= in_ts_gp_sync(7); 
        end if;
    end process;
 
--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    -- latency : 3-clock
    u_MULT : MULT_16X21
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        A                           => a                                       ,--: in  std_logic_vector(15 downto 0);
        B                           => b                                       ,--: in  std_logic_vector(20 downto 0);
        P                           => p                                        --: out std_logic_vector(36 downto 0)
    );

    -- latency : 3-clocks
    u_ROUNDING : ATT_ROD
    generic map(
        INPUT_WIDTH                 => 36                                      ,--: natural := 32;
        OUTPUT_WIDTH                => RND_WIDTH                                --: natural := 20
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        ROD_IN                      => p(35 downto 0)                          ,--: in  std_logic_vector(INPUT_WIDTH-1 downto 0);
        ROD_OUT                     => data_rnd                                 --: out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );

    -- latency : 1-clock
    u_SATURATION : ATT_SAT
    generic map(
        INPUT_WIDTH                 => RND_WIDTH                               ,--: natural := 20;
        OUTPUT_WIDTH                => SAT_WIDTH                                --: natural := 16
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        SAT_IN                      => data_rnd                                ,--: in  std_logic_vector(INPUT_WIDTH-1 downto 0);
        SAT_OUT                     => data_sat                                 --: out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );

end BEHAVE;
