--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Zero Replacement Hard Clipper                                 --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

entity ZRHC is
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

        ZRHC_BYPASS                 : in  std_logic;
        ZRHC_THRESHOLD              : in  std_logic_vector(31 downto 0);
        ZRHC_OCCUR                  : out std_logic_vector(3 downto 0);

        ZRHC_IN_10MS                : in  std_logic;
        ZRHC_IN_TDD                 : in  std_logic;
        ZRHC_IN_SYNC                : in  std_logic;
        ZRHC_IN_DATA                : in  std_logic_vector(15 downto 0);

        ZRHC_OUT_10MS               : out std_logic;
        ZRHC_OUT_TDD                : out std_logic;
        ZRHC_OUT_SYNC               : out std_logic;
        ZRHC_OUT_DATA               : out std_logic_vector(15 downto 0)
  );
end ZRHC;

architecture BEHAVE of ZRHC is

    signal cnt_sync                 : std_logic_vector(2 downto 0) := (others => '0');
    signal sync_buffer              : Std_logic_vector(7 downto 0);
    type data_array is array(natural range <>) of std_logic_vector(15 downto 0);
    signal data_buffer              : data_array(6 downto 0) := (others => (others => '0'));
    signal cur_power                : std_logic_vector(31 downto 0);
    signal antenna_block            : std_logic;
    signal antenna0_block_buffer    : std_logic_vector(3 downto 0) := (others => '1');
    signal antenna1_block_buffer    : std_logic_vector(3 downto 0) := (others => '1');
    signal antenna2_block_buffer    : std_logic_vector(3 downto 0) := (others => '1');
    signal antenna3_block_buffer    : std_logic_vector(3 downto 0) := (others => '1');

    component MULT_16X16 is
    port (
    	CLK                        : in  std_logic;
    	A                          : in  std_logic_vector(15 downto 0);
    	B                          : in  std_logic_vector(15 downto 0);
    	P                          : out std_logic_vector(31 downto 0)
    );
    end component;

    signal a                       : std_logic_vector(15 downto 0);
    signal b                       : std_logic_vector(15 downto 0);
    signal p                       : std_logic_vector(31 downto 0);

begin

    PROCESSING_DELAY <= conv_std_logic_vector(8, 24);

    -- synchronization
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (ZRHC_IN_SYNC = '1') then
                cnt_sync <= (others => '0');
            else
                cnt_sync <= cnt_sync + 1;
            end if;
        end if;
    end process;

    -- multiplier input
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            a <= ZRHC_IN_DATA;
            b <= ZRHC_IN_DATA;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            sync_buffer <= sync_buffer(6 downto 0) & ZRHC_IN_SYNC;
            data_buffer <= data_buffer(5 downto 0) & ZRHC_IN_DATA;
        end if;
    end process;

    -- Calculate the power
    process (RESET, CLK)
    begin
        if (RESET = '1') then
            cur_power     <= (others => '0');
            antenna_block <= '1';
        elsif (CLK'event and CLK = '1') then
            case cnt_sync is
            when "000"  => cur_power <= p;
            when "001"  => cur_power <= cur_power + p;
            when "010"  => cur_power <= p;
            when "011"  => cur_power <= cur_power + p;
            when "100"  => cur_power <= p;
            when "101"  => cur_power <= cur_power + p;
            when "110"  => cur_power <= p;
            when "111"  => cur_power <= cur_power + p;
            when others => NULL;
            end case;
            if (cnt_sync(0) = '0') then
                if (cur_power > ZRHC_THRESHOLD) then
                    antenna_block <= '1';
                else
                    antenna_block <= '0';
                end if;
            end if;
        end if;
    end process;

    ZRHC_OUT_SYNC <= sync_buffer(7);

    -- Buffering for synchronization
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (sync_buffer(7) = '1') then
                ZRHC_OUT_10MS <= ZRHC_IN_10MS;
                ZRHC_OUT_TDD  <= ZRHC_IN_TDD;
            end if;
            if (antenna_block = '1' and ZRHC_BYPASS = '0') then
                ZRHC_OUT_DATA <= (others => '0');
            else
                ZRHC_OUT_DATA <= data_buffer(6);
            end if;
        end if;
    end process;

    -- Hold abnormal signal (4 * 1/245.76 MHz)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (antenna_block = '1') then
                case cnt_sync is
                when "000"  => antenna0_block_buffer <= (others => '1');
                when "001"  => antenna1_block_buffer <= (others => '1');
                when "010"  => antenna1_block_buffer <= (others => '1');
                when "011"  => antenna2_block_buffer <= (others => '1');
                when "100"  => antenna2_block_buffer <= (others => '1');
                when "101"  => antenna3_block_buffer <= (others => '1');
                when "110"  => antenna3_block_buffer <= (others => '1');
                when "111"  => antenna0_block_buffer <= (others => '1');
                when others => NULL;
                end case;
            else
                antenna0_block_buffer <= antenna0_block_buffer(2 downto 0) & '0';
                antenna1_block_buffer <= antenna1_block_buffer(2 downto 0) & '0';
                antenna2_block_buffer <= antenna2_block_buffer(2 downto 0) & '0';
                antenna3_block_buffer <= antenna3_block_buffer(2 downto 0) & '0';
            end if;
        end if;
    end process;

    ZRHC_OCCUR(0) <= antenna0_block_buffer(3);
    ZRHC_OCCUR(1) <= antenna1_block_buffer(3);
    ZRHC_OCCUR(2) <= antenna2_block_buffer(3);
    ZRHC_OCCUR(3) <= antenna3_block_buffer(3);

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_MULT : MULT_16X16 
    port map(
        CLK                        => CLK                                      ,--: in  std_logic;
        A                          => a                                        ,--: in  std_logic_vector(15 downto 0);
        B                          => b                                        ,--: in  std_logic_vector(15 downto 0);
        P                          => p                                         --: out std_logic_vector(31 downto 0)
    );

end BEHAVE;