-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2023, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2023.05.17 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

entity bbctrl_pulse_delay is
	Port ( 
		i_rst							: in std_logic;
		i_clk							: in std_logic;
		
		i_10ms_dly_value				: in std_logic_vector(16-1 downto 0);
		
		i_pulse							: in std_logic;
		o_pulse							: out std_logic
	);
end bbctrl_pulse_delay;

architecture Behavioral of bbctrl_pulse_delay is
	
	-- MIN DLY VALUE  : 3
	-- MAX DLY VALUE  : 32767 (133 usec)
	-- MODULE LATENCY : 3 clk
	
	signal  r_10ms_dly_value				: std_logic_vector(15-1 downto 0);
	
	signal  r_pulse							: std_logic;
	signal  delay_cnt						: std_logic_vector(15-1 downto 0);
	signal  high_period						: std_logic_vector(16-1 downto 0);
	signal  high_period_cnt					: std_logic_vector(16-1 downto 0);
	
	signal  status							: std_logic_vector(2-1 downto 0);
	
begin

	--------------------------------------------------------------------------------------------
	-- receive data	
	process(i_clk)
	begin
		if (rising_edge(i_clk)) then
			if (i_10ms_dly_value < conv_std_logic_vector(3, 16)) then
				r_10ms_dly_value			<=	conv_std_logic_vector(3, 15);
			elsif (i_10ms_dly_value > conv_std_logic_vector(32767, 16)) then
				r_10ms_dly_value			<=	conv_std_logic_vector(32767, 15);
			else
				r_10ms_dly_value			<=	i_10ms_dly_value(14 downto 0);
			end if;
			
			r_pulse							<=	i_pulse;
		end if;
	end process;
	
	--------------------------------------------------------------------------------------------
	-- count delay, high period
	process(i_clk)
	begin
		if (rising_edge(i_clk)) then
			if (r_pulse = '0' and i_pulse = '1') then
				delay_cnt					<=	(others=>'0');
			elsif (delay_cnt = r_10ms_dly_value) then
				delay_cnt					<=	delay_cnt;
			else
				delay_cnt					<=	delay_cnt + '1';
			end if;
			
			if (r_pulse = '0' and i_pulse = '1') then
				high_period					<=	(others=>'0');
			elsif (r_pulse = '1') then
				high_period					<=	high_period + '1';
			else
				high_period					<=	high_period;
			end if;
			
			if ((status = b"01" and delay_cnt = r_10ms_dly_value) or status = b"10") then
				high_period_cnt				<=	high_period_cnt + '1';
			else
				high_period_cnt				<=	(others=>'0');
			end if;
		end if;
	end process;

	--------------------------------------------------------------------------------------------
	-- status process
	process(i_rst, i_clk)
	begin
		if (i_rst = '1') then
			status							<=	(others=>'0');
		elsif (rising_edge(i_clk)) then
			if (r_pulse = '0' and i_pulse = '1') then
				status						<=	b"01";
			elsif (status = b"01" and delay_cnt = r_10ms_dly_value) then
				status						<=	b"10";
			elsif (status = b"10" and high_period_cnt = high_period) then
				status						<=	b"11";
			else
				status						<=	status;
			end if;
		end if;
	end process;

	--------------------------------------------------------------------------------------------
	-- output
	process(i_clk)
	begin
		if (rising_edge(i_clk)) then
			if (status = b"10") then
				o_pulse						<=	'1';
			else
				o_pulse						<=	'0';
			end if;
		end if;
	end process;

end Behavioral;