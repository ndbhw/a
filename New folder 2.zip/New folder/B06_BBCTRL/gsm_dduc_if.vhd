--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : DDUC_IF                                                       --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2021.11.08                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity GSM_DDUC_IF is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        ARESET                      : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

--------------------------------------------------------------------------------
-- BIT_CONV
--------------------------------------------------------------------------------

        I_RX_120MS                  : in  std_logic;
        I_RX_10MS                   : in  std_logic;
        I_RX_BFN                    : in  std_logic_vector(11 downto 0);
        I_RX_TDD                    : in  std_logic;
        I_RX_SYNC                   : in  std_logic;
        I_RX_DATA_I                 : in  std_logic_vector(15 downto 0);
        I_RX_DATA_Q                 : in  std_logic_vector(15 downto 0);

        O_TX_10MS                   : out std_logic;
        O_TX_TDD                    : out std_logic;
        I_TX_SYNC                   : in  std_logic;
        O_TX_DATA_I                 : out std_logic_vector(15 downto 0);
        O_TX_DATA_Q                 : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- FORMATTER
--------------------------------------------------------------------------------

        O_DL_120MS                  : out std_logic;
        O_DL_10MS                   : out std_logic;
        O_DL_BFN                    : out std_logic_vector(11 downto 0);
        O_DL_TDD                    : out std_logic;
        O_DL_SYNC                   : out std_logic;
        O_DL_DATA                   : out std_logic_vector(15 downto 0);

--        I_UL_10MS                   : in  std_logic;
        I_UL_120MS                  : in  std_logic;
        I_UL_TS_SYNC                : in  std_logic;
        I_UL_TDD                    : in  std_logic;
        I_UL_SYNC                   : in  std_logic;
        I_UL_DATA                   : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- ALC_ATT
--------------------------------------------------------------------------------

        I_ALC_DONE                  : in  std_logic;
        I_ALC_ATT_A                 : in  std_logic_vector(15 downto 0);
        I_ALC_ATT_B                 : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- DSP_TOP
--------------------------------------------------------------------------------

        O_DL_GAIN                   : out std_logic_array10(7 downto 0); 
        O_DL_ARFCN                  : out std_logic_array10(7 downto 0); 
        O_UL_ARFCN                  : out std_logic_array10(7 downto 0) 

    );
end GSM_DDUC_IF;

architecture BEHAVE of GSM_DDUC_IF is

    component GSM_DUC_IF is
    port (
        RESET                       : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);

        I_RX_120MS                  : in  std_logic;
        I_RX_10MS                   : in  std_logic;
        I_RX_BFN                    : in  std_logic_vector(11 downto 0);
        I_RX_TDD                    : in  std_logic;
        I_RX_SYNC                   : in  std_logic;
        I_RX_DATA_I                 : in  std_logic_vector(15 downto 0);
        I_RX_DATA_Q                 : in  std_logic_vector(15 downto 0);

        O_DL_120MS                  : out std_logic;
        O_DL_10MS                   : out std_logic;
        O_DL_BFN                    : out std_logic_vector(11 downto 0);
        O_DL_TDD                    : out std_logic;
        O_DL_SYNC                   : out std_logic;
        O_DL_DATA                   : out std_logic_vector(15 downto 0);

        O_DL_GAIN                   : out std_logic_array10(7 downto 0); 
        O_DL_ARFCN                  : out std_logic_array10(7 downto 0); 
        O_UL_ARFCN                  : out std_logic_array10(7 downto 0) 

    );
    end component;

    component GSM_DDC_IF is
    port (
        RESET                       : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        O_UL_FSYNC                  : out std_logic;
        O_UL_TDD                    : out std_logic;
        I_UL_TX_EN                  : in  std_logic;
        O_UL_DATA_I                 : out std_logic_vector(15 downto 0);
        O_UL_DATA_Q                 : out std_logic_vector(15 downto 0);

        I_ALC_DONE                  : in  std_logic;
        I_ALC_ATT_A                 : in  std_logic_vector(15 downto 0);
        I_ALC_ATT_B                 : in  std_logic_vector(15 downto 0);

--        I_UL_FSYNC                  : in  std_logic;
        I_UL_120MS                  : in  std_logic;
        I_UL_TS_SYNC                : in  std_logic;
        I_UL_TDD                    : in  std_logic;
        I_UL_SYNC                   : in  std_logic;
        I_UL_DATA                   : in  std_logic_vector(15 downto 0)

    );
    end component;

begin

    U_GSM_DUC_IF : GSM_DUC_IF 
    port map(
        RESET                       => ARESET                        , --: in  std_logic;
        CLK_SYSX8                   => CLK_SYSX8                     , --: in  std_logic;

        PROCESSING_DELAY_DL         => PROCESSING_DELAY_DL           , --: out std_logic_vector(23 downto 0);

        I_RX_120MS                  => I_RX_120MS                    , --: in  std_logic;
        I_RX_10MS                   => I_RX_10MS                     , --: in  std_logic;
        I_RX_BFN                    => I_RX_BFN                      , --: in  std_logic_vector(11 downto 0);
        I_RX_TDD                    => I_RX_TDD                      , --: in  std_logic;
        I_RX_SYNC                   => I_RX_SYNC                     , --: in  std_logic;
        I_RX_DATA_I                 => I_RX_DATA_I                   , --: in  std_logic_vector(15 downto 0);
        I_RX_DATA_Q                 => I_RX_DATA_Q                   , --: in  std_logic_vector(15 downto 0);

        O_DL_120MS                  => O_DL_120MS                    , --: out std_logic;
        O_DL_10MS                   => O_DL_10MS                     , --: out std_logic;
        O_DL_BFN                    => O_DL_BFN                      , --: out std_logic_vector(11 downto 0);
        O_DL_TDD                    => O_DL_TDD                      , --: out std_logic;
        O_DL_SYNC                   => O_DL_SYNC                     , --: out std_logic;
        O_DL_DATA                   => O_DL_DATA                     , --: out std_logic_vector(15 downto 0)

        O_DL_GAIN                   => O_DL_GAIN                     , --: out std_logic_array10(7 downto 0); 
        O_DL_ARFCN                  => O_DL_ARFCN                    , --: out std_logic_array10(7 downto 0); 
        O_UL_ARFCN                  => O_UL_ARFCN                      --: out std_logic_array10(7 downto 0) 
    );

    U_GSM_DDC_IF : GSM_DDC_IF
    port map(
        RESET                       => ARESET                        , --: in  std_logic;
        CLK_SYSX8                   => CLK_SYSX8                     , --: in  std_logic;

        PROCESSING_DELAY_UL         => PROCESSING_DELAY_UL           , --: out std_logic_vector(23 downto 0);

        O_UL_FSYNC                  => O_TX_10MS                     , --: out std_logic;
        O_UL_TDD                    => O_TX_TDD                      , --: out std_logic;
        I_UL_TX_EN                  => I_TX_SYNC                     , --: in  std_logic;
        O_UL_DATA_I                 => O_TX_DATA_I                   , --: out std_logic_vector(15 downto 0);
        O_UL_DATA_Q                 => O_TX_DATA_Q                   , --: out std_logic_vector(15 downto 0);

        I_ALC_DONE                  => I_ALC_DONE              , --: in  std_logic;
        I_ALC_ATT_A                 => I_ALC_ATT_A             , --: in  std_logic_vector(15 downto 0);
        I_ALC_ATT_B                 => I_ALC_ATT_B             , --: in  std_logic_vector(15 downto 0);

--        I_UL_FSYNC                  => I_UL_10MS                     , --: in  std_logic;
        I_UL_120MS                  => I_UL_120MS                    , --: in  std_logic;
        I_UL_TS_SYNC                => I_UL_TS_SYNC                  , --: in  std_logic;
        I_UL_TDD                    => I_UL_TDD                      , --: in  std_logic;
        I_UL_SYNC                   => I_UL_SYNC                     , --: in  std_logic;
        I_UL_DATA                   => I_UL_DATA                       --: in  std_logic_vector(15 downto 0)
    );
    

end BEHAVE;








