--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Pattern generator (CW)                                        --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.22                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity GSM_PT_GEN_CW is
    generic (
        NUM_ANTENNA                 : natural := 4
    );
    port (
        CLK                         : in  std_logic;
        ENABLE                      : in  std_logic;

        SINE_NCO                    : in  std_logic_vector(5 downto 0);

        IN_SYNC                     : in  std_logic;
        OUT_DATA                    : out std_logic_vector(15 downto 0)
    );
end GSM_PT_GEN_CW;

architecture BEHAVE of GSM_PT_GEN_CW is

    signal cnt_sync                 : std_logic_vector(6 downto 0) := (others => '0');

    component SINE_ROM is
    port (
        CLKA                        : in  std_logic;
        ADDRA                       : in  std_logic_vector(5 downto 0);
        DOUTA                       : out std_logic_vector(31 downto 0)
    );
    end component;

    signal sin_addr                 : std_logic_vector(6 downto 0);
    signal sin_tbl_addr             : std_logic_vector(6 downto 0);
    signal sin_tbl_data             : std_logic_vector(31 downto 0);

begin

    -- synchronization
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_SYNC = '1') then
                cnt_sync <= (others => '0');
            else
                cnt_sync <= cnt_sync + 1;
            end if;
        end if;
    end process;

    process ( CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (ENABLE = '1') then
                if (cnt_sync = 3) then
                    sin_addr <= sin_tbl_addr + ('0' & SINE_NCO);
                else
                    sin_addr <= sin_addr;
                end if;
            else
                sin_addr <= (others => '0');
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (ENABLE = '1') then
                if (sin_addr > 47) then
                    sin_tbl_addr <= sin_addr - 48;
                else
                    sin_tbl_addr <= sin_addr;
                end if;
            else
                sin_tbl_addr <= (others => '0');
            end if;
        end if;
    end process;

    -- output data
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (ENABLE = '1') then
                if (cnt_sync(6 downto 4) = "000") then
                    if (cnt_sync(0) = '0') then 
                        OUT_DATA <= sin_tbl_data(31 downto 16);
                    else
                        OUT_DATA <= sin_tbl_data(15 downto 0);
                    end if;
                else
                    OUT_DATA <= (others => '0');
                end if;
            end if;
        end if;
    end process;

--    process (CLK)
--    begin
--        if (CLK'event and CLK = '1') then
--            if (ENABLE = '1') then
--                if (NUM_ANTENNA = 1) then
--                    case cnt_sync is
--                    when "0000" => OUT_DATA <= sin_tbl_data(31 downto 16);
--                    when "0001" => OUT_DATA <= sin_tbl_data(15 downto 0);
--                    when others => OUT_DATA <= (others => '0');
--                    end case;
--                elsif (NUM_ANTENNA = 2) then
--                    case cnt_sync is
--                    when "0000" => OUT_DATA <= sin_tbl_data(31 downto 16);
--                    when "0001" => OUT_DATA <= sin_tbl_data(15 downto 0);
--                    when "0010" => OUT_DATA <= sin_tbl_data(31 downto 16);
--                    when "0011" => OUT_DATA <= sin_tbl_data(15 downto 0);
--                    when others => OUT_DATA <= (others => '0');
--                    end case;
--                elsif (NUM_ANTENNA = 3) then
--                    case cnt_sync is
--                    when "0000" => OUT_DATA <= sin_tbl_data(31 downto 16);
--                    when "0001" => OUT_DATA <= sin_tbl_data(15 downto 0);
--                    when "0010" => OUT_DATA <= sin_tbl_data(31 downto 16);
--                    when "0011" => OUT_DATA <= sin_tbl_data(15 downto 0);
--                    when "0100" => OUT_DATA <= sin_tbl_data(31 downto 16);
--                    when "0101" => OUT_DATA <= sin_tbl_data(15 downto 0);
--                    when others => OUT_DATA <= (others => '0');
--                    end case;
--                else
--                    case cnt_sync is
--                    when "0000" => OUT_DATA <= sin_tbl_data(31 downto 16);
--                    when "0001" => OUT_DATA <= sin_tbl_data(15 downto 0);
--                    when "0010" => OUT_DATA <= sin_tbl_data(31 downto 16);
--                    when "0011" => OUT_DATA <= sin_tbl_data(15 downto 0);
--                    when "0100" => OUT_DATA <= sin_tbl_data(31 downto 16);
--                    when "0101" => OUT_DATA <= sin_tbl_data(15 downto 0);
--                    when "0110" => OUT_DATA <= sin_tbl_data(31 downto 16);
--                    when "0111" => OUT_DATA <= sin_tbl_data(15 downto 0);
--                    when others => OUT_DATA <= (others => '0');
--                    end case;
--                end if;
--            else
--                OUT_DATA <= (others => '0');
--            end if;
--        end if;
--    end process;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_SIN_TBL : SINE_ROM
    port map(
        CLKA                        => CLK                                     ,--: in  std_logic;
        ADDRA                       => sin_tbl_addr(5 downto 0)                ,--: in  std_logic_vector(5 downto 0);
        DOUTA                       => sin_tbl_data                             --: out std_logic_vector(31 downto 0)
    );

end BEHAVE;
