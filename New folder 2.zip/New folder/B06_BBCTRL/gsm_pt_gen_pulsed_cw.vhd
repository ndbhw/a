--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Pattern generator (Pulsed CW)                                 --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.22                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                  
-- 1us rising time / 10us pulse on time / 488us off time
-- 10us per 500us
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

entity GSM_PT_GEN_PULSED_CW is
    generic (
        NUM_ANTENNA                 : natural := 4
    );
    port (
        CLK                         : in  std_logic;
        ENABLE                      : in  std_logic;

        IN_SYNC                     : in  std_logic;
        OUT_DATA                    : out std_logic_vector(15 downto 0)
    );
end GSM_PT_GEN_PULSED_CW;

architecture BEHAVE of GSM_PT_GEN_PULSED_CW is

    signal cnt_sync                 : std_logic_vector(6 downto 0) := (others => '0');
    signal cnt_frame                : std_logic_vector(13 downto 0) := (others => '0');
    signal ref_frame                : std_logic_vector(13 downto 0);

    signal count_en                 : std_logic := '0';
    signal cnt_sample               : std_logic_vector(13 downto 0) := (others => '0');
    signal ref_sample               : std_logic_vector(13 downto 0);
    signal cnt_pulse                : std_logic_vector(0 downto 0) := (others => '0');
    signal pulsed_cw                : std_logic_vector(15 downto 0) := (others => '0');

begin

    -- synchronization
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_SYNC = '1') then
                cnt_sync <= (others => '0');
            else
                cnt_sync <= cnt_sync + 1;
            end if;
        end if;
    end process;


--    ref_frame <= conv_std_logic_vector( 768-1, 12) when BW_SEL = "0010" else    --  5-MHz
--                 conv_std_logic_vector(1536-1, 12) when BW_SEL = "0011" else    -- 10-MHz
--                 conv_std_logic_vector(3072-1, 12);                             -- 20-MHz
--    ref_frame <= conv_std_logic_vector( 3840-1, 14) when BW_SEL = "0010" else    --  5-MHz
--                 conv_std_logic_vector( 7680-1, 14) when BW_SEL = "0011" else    -- 10-MHz
--                 conv_std_logic_vector(15360-1, 14);                             -- 20-MHz
    ref_frame <= conv_std_logic_vector( 960-1, 14);    --  1.92Msps

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (ENABLE = '1') then
                if (IN_SYNC = '1') then
                    if (cnt_frame = ref_frame) then
                        cnt_frame <= (others => '0');
                    else
                        cnt_frame <= cnt_frame + 1;
                    end if;
                end if;
            else
                cnt_frame <= (others => '0');
            end if;
            if (cnt_frame = 0) then
                count_en <= '0';
            else
                count_en <= '1';
            end if;
        end if;
    end process;

--    ref_sample <= conv_std_logic_vector( 39-1, 12) when BW_SEL = "0010" else    --  5-MHz
--                  conv_std_logic_vector( 78-1, 12) when BW_SEL = "0011" else    -- 10-MHz
--                  conv_std_logic_vector(156-1, 12);                             -- 20-MHz
--
--    ref_sample <= conv_std_logic_vector( 46-1, 14) when BW_SEL = "0010" else    --  5-MHz
--                  conv_std_logic_vector( 92-1, 14) when BW_SEL = "0011" else    -- 10-MHz
--                  conv_std_logic_vector(184-1, 14);                             -- 20-MHz
    ref_sample <= conv_std_logic_vector( 12-1, 14);    -- 1.92Msps

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (count_en = '1') then
                if (cnt_sync = 14) then
                    if (cnt_pulse = 0) then
                        if (cnt_sample = ref_sample) then
                            cnt_pulse  <= "1";
                        end if;
                    end if;
                    if (cnt_pulse = 0) then
                        if (cnt_sample = ref_sample) then
                            cnt_sample <= cnt_sample;
                        else
                            cnt_sample <= cnt_sample + 1;
                        end if;
                    else
                        if (cnt_sample = 0) then
                            cnt_sample <= (others => '0');
                        else
                            cnt_sample <= cnt_sample - 1;
                        end if;
                    end if;
                end if;
            else
                cnt_pulse  <= (others => '0');
                cnt_sample <= (others => '0');
            end if;
        end if;
    end process;

    -- Pulsed CW
    process (CLK) 
    begin
        if (CLK'event and CLK = '1') then
            case cnt_sample is
            when "00" & x"000" => pulsed_cw <= conv_std_logic_vector(   0, 16);
            when "00" & x"001" => pulsed_cw <= conv_std_logic_vector( 302, 16);
            when "00" & x"002" => pulsed_cw <= conv_std_logic_vector( 854, 16);
            when "00" & x"003" => pulsed_cw <= conv_std_logic_vector(1618, 16);
            when "00" & x"004" => pulsed_cw <= conv_std_logic_vector(2539, 16);
            when "00" & x"005" => pulsed_cw <= conv_std_logic_vector(3540, 16);
            when "00" & x"006" => pulsed_cw <= conv_std_logic_vector(4540, 16);
            when "00" & x"007" => pulsed_cw <= conv_std_logic_vector(5461, 16);
            when "00" & x"008" => pulsed_cw <= conv_std_logic_vector(6225, 16);
            when "00" & x"009" => pulsed_cw <= conv_std_logic_vector(6777, 16);
            when "00" & x"00A" => pulsed_cw <= conv_std_logic_vector(7079, 16);
            when others => pulsed_cw <= pulsed_cw;
            end case;
        end if;
    end process;

--    process (CLK) 
--    begin
--        if (CLK'event and CLK = '1') then
--            if (BW_SEL = "0010") then
--                case cnt_sample is
--                when "00" & x"000" => pulsed_cw <= conv_std_logic_vector(   0, 16);
--                when "00" & x"001" => pulsed_cw <= conv_std_logic_vector( 302, 16);
--                when "00" & x"002" => pulsed_cw <= conv_std_logic_vector( 854, 16);
--                when "00" & x"003" => pulsed_cw <= conv_std_logic_vector(1618, 16);
--                when "00" & x"004" => pulsed_cw <= conv_std_logic_vector(2539, 16);
--                when "00" & x"005" => pulsed_cw <= conv_std_logic_vector(3540, 16);
--                when "00" & x"006" => pulsed_cw <= conv_std_logic_vector(4540, 16);
--                when "00" & x"007" => pulsed_cw <= conv_std_logic_vector(5461, 16);
--                when "00" & x"008" => pulsed_cw <= conv_std_logic_vector(6225, 16);
--                when "00" & x"009" => pulsed_cw <= conv_std_logic_vector(6777, 16);
--                when "00" & x"00A" => pulsed_cw <= conv_std_logic_vector(7079, 16);
--                when others => pulsed_cw <= pulsed_cw;
--                end case;
--            elsif (BW_SEL = "0011") then
--                case cnt_sample is
--                when "00" & x"000" => pulsed_cw <= conv_std_logic_vector(   0, 16);
--                when "00" & x"002" => pulsed_cw <= conv_std_logic_vector( 302, 16);
--                when "00" & x"004" => pulsed_cw <= conv_std_logic_vector( 854, 16);
--                when "00" & x"006" => pulsed_cw <= conv_std_logic_vector(1618, 16);
--                when "00" & x"008" => pulsed_cw <= conv_std_logic_vector(2539, 16);
--                when "00" & x"00A" => pulsed_cw <= conv_std_logic_vector(3540, 16);
--                when "00" & x"00C" => pulsed_cw <= conv_std_logic_vector(4540, 16);
--                when "00" & x"00E" => pulsed_cw <= conv_std_logic_vector(5461, 16);
--                when "00" & x"010" => pulsed_cw <= conv_std_logic_vector(6225, 16);
--                when "00" & x"012" => pulsed_cw <= conv_std_logic_vector(6777, 16);
--                when "00" & x"014" => pulsed_cw <= conv_std_logic_vector(7079, 16);
--                when others => pulsed_cw <= pulsed_cw;
--                end case;
--            else                
--                case cnt_sample is
--                when "00" & x"000" => pulsed_cw <= conv_std_logic_vector(   0, 16);
--                when "00" & x"003" => pulsed_cw <= conv_std_logic_vector( 302, 16);
--                when "00" & x"006" => pulsed_cw <= conv_std_logic_vector( 854, 16);
--                when "00" & x"009" => pulsed_cw <= conv_std_logic_vector(1618, 16);
--                when "00" & x"00C" => pulsed_cw <= conv_std_logic_vector(2539, 16);
--                when "00" & x"00F" => pulsed_cw <= conv_std_logic_vector(3540, 16);
--                when "00" & x"012" => pulsed_cw <= conv_std_logic_vector(4540, 16);
--                when "00" & x"015" => pulsed_cw <= conv_std_logic_vector(5461, 16);
--                when "00" & x"018" => pulsed_cw <= conv_std_logic_vector(6225, 16);
--                when "00" & x"01B" => pulsed_cw <= conv_std_logic_vector(6777, 16);
--                when "00" & x"01E" => pulsed_cw <= conv_std_logic_vector(7079, 16);
--                when others => pulsed_cw <= pulsed_cw;
--                end case;
--            end if;
--        end if;
--    end process;
    
    -- output data
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (ENABLE = '1') then
                if (cnt_sync(6 downto 4) = "000") then
                    if (cnt_sync(0) = '0') then 
                        OUT_DATA <= pulsed_cw;
                    else
                        OUT_DATA <= pulsed_cw;
                    end if;
                else
                    OUT_DATA <= (others => '0');
                end if;
            end if;
        end if;
    end process;

--    process (CLK)
--    begin
--        if (CLK'event and CLK = '1') then
--            if (NUM_ANTENNA = 1) then
--                case cnt_sync is
--                when "0000" => OUT_DATA <= pulsed_cw;
--                when "0001" => OUT_DATA <= pulsed_cw;
--                when others => OUT_DATA <= (others => '0');
--                end case;
--            elsif (NUM_ANTENNA = 2) then
--                case cnt_sync is
--                when "0000" => OUT_DATA <= pulsed_cw;
--                when "0001" => OUT_DATA <= pulsed_cw;
--                when "0010" => OUT_DATA <= pulsed_cw;
--                when "0011" => OUT_DATA <= pulsed_cw;
--                when others => OUT_DATA <= (others => '0');
--                end case;
--            elsif (NUM_ANTENNA = 3) then
--                case cnt_sync is
--                when "0000" => OUT_DATA <= pulsed_cw;
--                when "0001" => OUT_DATA <= pulsed_cw;
--                when "0010" => OUT_DATA <= pulsed_cw;
--                when "0011" => OUT_DATA <= pulsed_cw;
--                when "0100" => OUT_DATA <= pulsed_cw;
--                when "0101" => OUT_DATA <= pulsed_cw;
--                when others => OUT_DATA <= (others => '0');
--                end case;
--            else
--                case cnt_sync is
--                when "0000" => OUT_DATA <= pulsed_cw;
--                when "0001" => OUT_DATA <= pulsed_cw;
--                when "0010" => OUT_DATA <= pulsed_cw;
--                when "0011" => OUT_DATA <= pulsed_cw;
--                when "0100" => OUT_DATA <= pulsed_cw;
--                when "0101" => OUT_DATA <= pulsed_cw;
--                when "0110" => OUT_DATA <= pulsed_cw;
--                when "0111" => OUT_DATA <= pulsed_cw;
--                when others => OUT_DATA <= (others => '0');
--                end case;
--            end if;
--        end if;

end BEHAVE;
