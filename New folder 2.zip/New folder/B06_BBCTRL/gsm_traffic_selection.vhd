--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Traffic selection                                             --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.22                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

entity GSM_TRAFFIC_SELECTION is
    generic (
        NUM_ANTENNA                 : natural := 4
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

        TEST_MODE                   : in  std_logic_vector(3 downto 0);

        TEST_DC_I                   : in  std_logic_vector(15 downto 0);
        TEST_DC_Q                   : in  std_logic_vector(15 downto 0);
        TEST_NCO                    : in  std_logic_vector(5 downto 0);

        TP_IN_120MS_SYNC            : in  std_logic;
        TP_IN_TS16_SYNC             : in  std_logic;
        TP_IN_TS_SYNC               : in  std_logic;
        TP_IN_TS_GP_SYNC            : in  std_logic;

        TP_IN_10MS                  : in  std_logic;
        TP_IN_TDD                   : in  std_logic;
        TP_IN_SYNC                  : in  std_logic;
        TP_IN_DATA                  : in  std_logic_vector(15 downto 0);

        TP_OUT_120MS_SYNC           : out std_logic;
        TP_OUT_TS16_SYNC            : out std_logic;
        TP_OUT_TS_SYNC              : out std_logic;
        TP_OUT_TS_GP_SYNC           : out std_logic;

        TP_OUT_10MS                 : out std_logic;
        TP_OUT_TDD                  : out std_logic;
        TP_OUT_SYNC                 : out std_logic;
        TP_OUT_DATA                 : out std_logic_vector(15 downto 0)
    );
end GSM_TRAFFIC_SELECTION;

architecture BEHAVE of GSM_TRAFFIC_SELECTION is

    signal tp_120ms_sync            : std_logic := '0';
    signal tp_ts16_sync             : std_logic := '0';
    signal tp_ts_sync               : std_logic := '0';
    signal tp_ts_gp_sync            : std_logic := '0';

    signal tp_10ms                  : std_logic := '0';
    signal tp_tdd                   : std_logic := '0';
    signal tp_sync                  : std_logic := '0';
    signal tp_data                  : std_logic_vector(15 downto 0) := (others => '0');

    component GSM_PT_GEN_DC is
    generic (
        NUM_ANTENNA                 : natural := 4
    );
    port (
        CLK                         : in  std_logic;
        ENABLE                      : in  std_logic;

        TEST_DC_I                   : in  std_logic_vector(15 downto 0);
        TEST_DC_Q                   : in  std_logic_vector(15 downto 0);

        IN_SYNC                     : in  std_logic;
        OUT_DATA                    : out std_logic_vector(15 downto 0)
    );
    end component;

    signal enable_dc                : std_logic;
    signal pattern_dc               : std_logic_vector(15 downto 0);

    component GSM_PT_GEN_PULSED_CW is
    generic (
        NUM_ANTENNA                 : natural := 4
    );
    port (
        CLK                         : in  std_logic;
        ENABLE                      : in  std_logic;

        IN_SYNC                     : in  std_logic;
        OUT_DATA                    : out std_logic_vector(15 downto 0)
    );
    end component;

    signal enable_pulsed_cw         : std_logic;
    signal pattern_pulsed_cw        : std_logic_vector(15 downto 0);

    component GSM_PT_GEN_CW is
    generic (
        NUM_ANTENNA                 : natural := 4
    );
    port (
        CLK                         : in  std_logic;
        ENABLE                      : in  std_logic;

        SINE_NCO                    : in  std_logic_vector(5 downto 0);

        IN_SYNC                     : in  std_logic;
        OUT_DATA                    : out std_logic_vector(15 downto 0)
    );
    end component;

    signal enable_cw                : std_logic;
    signal pattern_cw               : std_logic_vector(15 downto 0);

begin

    PROCESSING_DELAY <= conv_std_logic_vector(2, 24);

    -- buffering
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            tp_120ms_sync <= TP_IN_120MS_SYNC; 
            tp_ts16_sync  <= TP_IN_TS16_SYNC; 
            tp_ts_sync    <= TP_IN_TS_SYNC  ; 
            tp_ts_gp_sync <= TP_IN_TS_GP_SYNC;
            tp_10ms <= TP_IN_10MS;
            tp_tdd  <= TP_IN_TDD;
            tp_sync <= TP_IN_SYNC;
            tp_data <= TP_IN_DATA;
        end if;
    end process;

    -- enable/disable
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case TEST_MODE is
            when "0001" => enable_dc        <= '1';
                           enable_pulsed_cw <= '0';
                           enable_cw        <= '0';
            when "0010" => enable_dc        <= '0';
                           enable_pulsed_cw <= '1';
                           enable_cw        <= '0';
            when "0011" => enable_dc        <= '0';
                           enable_pulsed_cw <= '0';
                           enable_cw        <= '1';
            when others => enable_dc        <= '0';
                           enable_pulsed_cw <= '0';
                           enable_cw        <= '0';
            end case;
        end if;
    end process;

    -- traffic selection
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case TEST_MODE is
            when "0001" => TP_OUT_10MS <= tp_10ms;
                           TP_OUT_TDD  <= tp_tdd;
                           TP_OUT_SYNC <= tp_sync;
                           TP_OUT_DATA <= pattern_dc;
            when "0010" => TP_OUT_10MS <= tp_10ms;
                           TP_OUT_TDD  <= tp_tdd;
                           TP_OUT_SYNC <= tp_sync;
                           TP_OUT_DATA <= pattern_pulsed_cw;
            when "0011" => TP_OUT_10MS <= tp_10ms;
                           TP_OUT_TDD  <= tp_tdd;
                           TP_OUT_SYNC <= tp_sync;
                           TP_OUT_DATA <= pattern_cw;
            when others => TP_OUT_10MS <= tp_10ms;
                           TP_OUT_TDD  <= tp_tdd;
                           TP_OUT_SYNC <= tp_sync;
                           TP_OUT_DATA <= tp_data;
            end case;
            TP_OUT_120MS_SYNC <= tp_120ms_sync; 
            TP_OUT_TS16_SYNC  <= tp_ts16_sync ; 
            TP_OUT_TS_SYNC    <= tp_ts_sync   ; 
            TP_OUT_TS_GP_SYNC <= tp_ts_gp_sync; 
        end if;
    end process;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_DC : GSM_PT_GEN_DC
    generic map(
        NUM_ANTENNA                 => NUM_ANTENNA                              --: natural := 4
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        ENABLE                      => enable_dc                               ,--: in  std_logic;

        TEST_DC_I                   => TEST_DC_I                               ,--: in  std_logic_vector(15 downto 0);
        TEST_DC_Q                   => TEST_DC_Q                               ,--: in  std_logic_vector(15 downto 0);

        IN_SYNC                     => TP_IN_SYNC                              ,--: in  std_logic;
        OUT_DATA                    => pattern_dc                               --: out std_logic_vector(15 downto 0)
    );

    u_PULSED_CW : GSM_PT_GEN_PULSED_CW
    generic map(
        NUM_ANTENNA                 => NUM_ANTENNA                              --: natural := 4
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        ENABLE                      => enable_pulsed_cw                        ,--: in  std_logic;

        IN_SYNC                     => TP_IN_SYNC                              ,--: in  std_logic;
        OUT_DATA                    => pattern_pulsed_cw                        --: out std_logic_vector(15 downto 0)
    );

    u_CW : GSM_PT_GEN_CW
    generic map(
        NUM_ANTENNA                 => NUM_ANTENNA                              --: natural := 4
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        ENABLE                      => enable_cw                               ,--: in  std_logic;

        SINE_NCO                    => TEST_NCO                                ,--: in  std_logic_vector(5 downto 0);

        IN_SYNC                     => TP_IN_SYNC                              ,--: in  std_logic;
        OUT_DATA                    => pattern_cw                               --: out std_logic_vector(15 downto 0)
    );

end BEHAVE;
