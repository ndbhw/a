--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : DUC_MAP_IF                                                        --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2021.11.08                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity DUC_MAP_IF is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        ARESET                      : in  std_logic;

        CLK_AUX                     : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);

        BW_SEL                      : in  std_logic_array4(3 downto 0);
        ANT_SWAP                    : in  std_logic_array4(3 downto 0);  
--------------------------------------------------------------------------------
-- BIT_CONV
--------------------------------------------------------------------------------

        I_RX_10MS                   : in  std_logic;
        I_RX_BFN                    : in  std_logic_vector(11 downto 0);
        I_RX_TDD                    : in  std_logic;
        I_RX_SYNC                   : in  std_logic;
        I_RX_DATA_I                 : in  std_logic_vector(15 downto 0);
        I_RX_DATA_Q                 : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- FORMATTER
--------------------------------------------------------------------------------

        O_DL_10MS                   : out std_logic;
        O_DL_BFN                    : out std_logic_vector(11 downto 0);
        O_DL_TDD                    : out std_logic;
        O_DL_SYNC                   : out std_logic_vector(3 downto 0);
        O_DL_DATA                   : out std_logic_array16(3 downto 0)

    );
end DUC_MAP_IF;

architecture BEHAVE of DUC_MAP_IF is

    signal dl_10ms_d                : std_logic_vector(8 downto 0) := (others => '0');
    signal dl_tdd_d                 : std_logic_vector(8 downto 0) := (others => '0');
    signal cnt_clk                  : std_logic_vector(5 downto 0) := (others => '0');
    signal cnt_clk_r                : std_logic_vector(5 downto 0) := (others => '0');
    signal sample_sync              : std_logic_vector(3 downto 0) := (others => '0');
    signal chip_sync_r              : std_logic := '0';

    signal rx_data_i_d1             : std_logic_vector(15 downto 0) := (others => '0');
    signal rx_data_q_d1             : std_logic_vector(15 downto 0) := (others => '0');
    signal rx_data_q_d2             : std_logic_vector(15 downto 0) := (others => '0');
    signal i_data_0                 : std_logic_array16(3 downto 0) := (others => (others => '0'));
    signal i_data_1                 : std_logic_array16(3 downto 0) := (others => (others => '0'));
    signal q_data_0                 : std_logic_array16(3 downto 0) := (others => (others => '0'));
    signal q_data_1                 : std_logic_array16(3 downto 0) := (others => (others => '0'));
    signal data_mux                 : std_logic_array16(3 downto 0) := (others => (others => '0'));

begin

    PROCESSING_DELAY_DL <= conv_std_logic_vector(9,24);

    -- output port mapping
    O_DL_10MS <= dl_10ms_d(8);
    O_DL_BFN  <= I_RX_BFN;
    O_DL_TDD  <= dl_tdd_d(8);
    O_DL_SYNC <= sample_sync;
    O_DL_DATA <= data_mux;
 
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            dl_10ms_d <= dl_10ms_d(7 downto 0) & I_RX_10MS;
            dl_tdd_d  <= dl_tdd_d(7 downto 0) & I_RX_TDD;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            rx_data_i_d1 <= I_RX_DATA_I;
            rx_data_q_d1 <= I_RX_DATA_Q;
            rx_data_q_d2 <= rx_data_q_d1;
        end if;
    end process;

    -- count chip sync max 63
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (I_RX_SYNC = '1') then
                cnt_clk <= (others => '0');
            else
                cnt_clk <= cnt_clk + 1;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_clk = 7) then
                chip_sync_r <= '1';
            else
                chip_sync_r <= '0';
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (chip_sync_r = '1') then
                cnt_clk_r <= (others => '0');
            else
                cnt_clk_r <= cnt_clk_r + 1;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_clk(2 downto 0) = "000") then
                i_data_0(0) <= I_RX_DATA_I;
            elsif (cnt_clk(2 downto 0) = "010") then
                i_data_0(1) <= I_RX_DATA_I;
            elsif (cnt_clk(2 downto 0) = "100") then
                i_data_0(2) <= I_RX_DATA_I;
            elsif (cnt_clk(2 downto 0) = "110") then
                i_data_0(3) <= I_RX_DATA_I;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_clk(2 downto 0) = "000") then
                i_data_1(3) <= rx_data_i_d1;
            elsif (cnt_clk(2 downto 0) = "010") then
                i_data_1(0) <= rx_data_i_d1;
            elsif (cnt_clk(2 downto 0) = "100") then
                i_data_1(1) <= rx_data_i_d1;
            elsif (cnt_clk(2 downto 0) = "110") then
                i_data_1(2) <= rx_data_i_d1;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_clk(2 downto 0) = "001") then
                q_data_0(0) <= rx_data_q_d1;
            elsif (cnt_clk(2 downto 0) = "011") then
                q_data_0(1) <= rx_data_q_d1;
            elsif (cnt_clk(2 downto 0) = "101") then
                q_data_0(2) <= rx_data_q_d1;
            elsif (cnt_clk(2 downto 0) = "111") then
                q_data_0(3) <= rx_data_q_d1;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_clk(2 downto 0) = "001") then
                q_data_1(3) <= rx_data_q_d2;
            elsif (cnt_clk(2 downto 0) = "011") then
                q_data_1(0) <= rx_data_q_d2;
            elsif (cnt_clk(2 downto 0) = "101") then
                q_data_1(1) <= rx_data_q_d2;
            elsif (cnt_clk(2 downto 0) = "111") then
                q_data_1(2) <= rx_data_q_d2;
            end if;
        end if;
    end process;

    G_DATA_OUT : for i in 3 downto 0 generate

--    process(CLK_SYSX8)
--    begin
--        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
--            if (cnt_clk(2 downto 0) = "000") then
--                data_mux(i) <= i_data_0(i);
--            elsif (cnt_clk(2 downto 0) = "001") then
--                data_mux(i) <= q_data_0(i);
--            elsif (cnt_clk(2 downto 0) = "010") then
--                data_mux(i) <= i_data_1(i);
--            elsif (cnt_clk(2 downto 0) = "011") then
--                data_mux(i) <= q_data_1(i);
--            else
--                data_mux(i) <= (others => '0');
--            end if;
--        end if;
--    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (ANT_SWAP(i) = x"1") then
                if (cnt_clk(2 downto 0) = "000") then
                    data_mux(i) <= i_data_1(i);
                elsif (cnt_clk(2 downto 0) = "001") then
                    data_mux(i) <= q_data_1(i);
                elsif (cnt_clk(2 downto 0) = "010") then
                    data_mux(i) <= i_data_0(i);
                elsif (cnt_clk(2 downto 0) = "011") then
                    data_mux(i) <= q_data_0(i);
                else
                    data_mux(i) <= (others => '0');
                end if;
            else
                if (cnt_clk(2 downto 0) = "000") then
                    data_mux(i) <= i_data_0(i);
                elsif (cnt_clk(2 downto 0) = "001") then
                    data_mux(i) <= q_data_0(i);
                elsif (cnt_clk(2 downto 0) = "010") then
                    data_mux(i) <= i_data_1(i);
                elsif (cnt_clk(2 downto 0) = "011") then
                    data_mux(i) <= q_data_1(i);
                else
                    data_mux(i) <= (others => '0');
                end if;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (BW_SEL(i) = x"2") then
                if (cnt_clk_r(4 downto 0) = "11111") then
                    sample_sync(i) <= '1';
                else
                    sample_sync(i) <= '0';
                end if;
            elsif (BW_SEL(i) = x"3") then
                if (cnt_clk_r(3 downto 0) = "1111") then
                    sample_sync(i) <= '1';
                else
                    sample_sync(i) <= '0';
                end if;
            else
                if (cnt_clk_r(2 downto 0) = "111") then
                    sample_sync(i) <= '1';
                else
                    sample_sync(i) <= '0';
                end if;
            end if;
        end if;
    end process;
                
    end generate;

end BEHAVE;
