--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Test pattern generator                                        --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

entity TEST_PATTERN is
    generic (
        NUM_ANTENNA                 : natural := 4
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY            : out std_logic_vector(31 downto 0);

        BW_SEL                      : in  std_logic_vector(3 downto 0);

        TEST_MODE                   : in  std_logic_vector(3 downto 0);

        TEST_DC_I                   : in  std_logic_vector(15 downto 0);
        TEST_DC_Q                   : in  std_logic_vector(15 downto 0);

        TEST_IN_10MS                : in  std_logic;
        TEST_IN_TDD                 : in  std_logic;
        TEST_IN_SYNC                : in  std_logic;
        TEST_IN_DATA                : in  std_logic_vector(15 downto 0);

        TEST_OUT_10MS               : out std_logic;
        TEST_OUT_TDD                : out std_logic;
        TEST_OUT_SYNC               : out std_logic;
        TEST_OUT_DATA               : out std_logic_vector(15 downto 0)
    );
end TEST_PATTERN;

architecture BEHAVE of TEST_PATTERN is

    signal cnt_sync                 : std_logic_vector(3 downto 0) := (others => '0');

begin

    PROCESSING_DELAY <= conv_std_logic_vector(1, 32);

    -- synchronization
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (TEST_IN_SYNC = '1') then
                cnt_sync <= (others => '0');
            else
                if (cnt_sync = 8) then
                    cnt_sync <= cnt_sync;
                else
                    cnt_sync <= cnt_sync + 1;
                end if;
            end if;
        end if;
    end process;

    -- Buffering for synchronization
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            TEST_OUT_10MS <= TEST_IN_10MS;
            TEST_OUT_TDD  <= TEST_IN_TDD;
            TEST_OUT_SYNC <= TEST_IN_SYNC;
            if (TEST_MODE = "0001") then
                if (NUM_ANTENNA = 1) then
                    case cnt_sync is
                    when "0000" => TEST_OUT_DATA <= TEST_DC_I;
                    when "0001" => TEST_OUT_DATA <= TEST_DC_Q;
                    when others => TEST_OUT_DATA <= (others => '0');
                    end case;
                elsif (NUM_ANTENNA = 2) then
                    case cnt_sync is
                    when "0000" => TEST_OUT_DATA <= TEST_DC_I;
                    when "0001" => TEST_OUT_DATA <= TEST_DC_Q;
                    when "0010" => TEST_OUT_DATA <= TEST_DC_I;
                    when "0011" => TEST_OUT_DATA <= TEST_DC_Q;
                    when others => TEST_OUT_DATA <= (others => '0');
                    end case;
                elsif (NUM_ANTENNA = 3) then
                    case cnt_sync is
                    when "0000" => TEST_OUT_DATA <= TEST_DC_I;
                    when "0001" => TEST_OUT_DATA <= TEST_DC_Q;
                    when "0010" => TEST_OUT_DATA <= TEST_DC_I;
                    when "0011" => TEST_OUT_DATA <= TEST_DC_Q;
                    when "0100" => TEST_OUT_DATA <= TEST_DC_I;
                    when "0101" => TEST_OUT_DATA <= TEST_DC_Q;
                    when others => TEST_OUT_DATA <= (others => '0');
                    end case;
                else
                    case cnt_sync is
                    when "0000" => TEST_OUT_DATA <= TEST_DC_I;
                    when "0001" => TEST_OUT_DATA <= TEST_DC_Q;
                    when "0010" => TEST_OUT_DATA <= TEST_DC_I;
                    when "0011" => TEST_OUT_DATA <= TEST_DC_Q;
                    when "0100" => TEST_OUT_DATA <= TEST_DC_I;
                    when "0101" => TEST_OUT_DATA <= TEST_DC_Q;
                    when "0110" => TEST_OUT_DATA <= TEST_DC_I;
                    when "0111" => TEST_OUT_DATA <= TEST_DC_Q;
                    when others => TEST_OUT_DATA <= (others => '0');
                    end case;
                end if;
            else
                TEST_OUT_DATA <= TEST_IN_DATA;
            end if;
        end if;
    end process;

end BEHAVE;