--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Saturation (Formatter component)                              --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity ATT_SAT is
    generic (
        INPUT_WIDTH                 : natural := 20;
        OUTPUT_WIDTH                : natural := 16
    );
    port (
        CLK                         : in  std_logic;
        SAT_IN                      : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
        SAT_OUT                     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
end ATT_SAT;

architecture BEHAVE of ATT_SAT is

    constant vector_zero            : std_logic_vector(INPUT_WIDTH-OUTPUT_WIDTH-1 downto 0) := (others => '0');
    constant vector_one             : std_logic_vector(INPUT_WIDTH-OUTPUT_WIDTH-1 downto 0) := (others => '1');

begin

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then            
            if (SAT_IN(INPUT_WIDTH-1) = '0') then                               -- Positive
                if (SAT_IN(INPUT_WIDTH-2 downto OUTPUT_WIDTH-1) = vector_zero) then
                    SAT_OUT <= '0' & SAT_IN(OUTPUT_WIDTH-2 downto 0);
                else
                    SAT_OUT(OUTPUT_WIDTH-1) <= '0';
                    for i in OUTPUT_WIDTH-2 downto 0 loop
                    SAT_OUT(i)              <= '1';
                    end loop;
                end if;
            else                                                                -- Negative
                if (SAT_IN(INPUT_WIDTH-2 downto OUTPUT_WIDTH-1) = vector_one) then
                    SAT_OUT <= '1' & SAT_IN(OUTPUT_WIDTH-2 downto 0);
                else
                    SAT_OUT(OUTPUT_WIDTH-1) <= '1';
                    for i in OUTPUT_WIDTH-2 downto 0 loop
                    SAT_OUT(i)              <= '0';
                    end loop;
                end if;
            end if;      
        end if;
    end process;

end BEHAVE;