-- Designer   : Heo Kyoung (k1340.heo@samsung.com), SHT Lab. 2Part.
-- Block name : MANTISSA_FRAMER
-- Project    : CP10_42A, 3.5G KDDI Low power
-- Structure  : 

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

entity MANTISSA_FRAMER is
port(
    RST          : in  std_logic;
    CLK          : in  std_logic;

    START_IN     : in  std_logic;
    DATA_IN      : in  std_logic_vector(63 downto 0);
    
    DONE_OUT     : out std_logic;
    MANTISSA_OUT : out std_logic_vector(31 downto 0)
    );
end MANTISSA_FRAMER;

architecture arc_MANTISSA_FRAMER of MANTISSA_FRAMER is

signal start_sh     : std_logic_vector( 1 downto 0);
signal start_rpls   : std_logic;

signal data_sh      : std_logic_vector(59 downto 0);

signal exponent     : std_logic_vector( 5 downto 0);
signal mantissa     : std_logic_vector(23 downto 0);

signal done_cnt     : std_logic_vector( 5 downto 0);
signal done_rpls    : std_logic;

signal mant_frame   : std_logic_vector(31 downto 0);

begin

    P_START_RPLS : process(RST, CLK) begin
        if (RST = '1') then
            start_sh   <= (others => '0');
            start_rpls <= '0';
        elsif (CLK'event) and (CLK = '1') then
            start_sh   <= start_sh(0) & START_IN;
            start_rpls <= start_sh(0) and (not start_sh(1));
        end if;
    end process;

    P_MANTISSA : process(RST, CLK) begin
        if (RST = '1') then
            data_sh    <= (others => '0');
            exponent   <= "100100";
            mantissa   <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (start_rpls = '1') then
                data_sh    <= DATA_IN(59 downto 0);
                exponent   <= "100100";
                mantissa   <= (others => '0');
            else
                if (data_sh(59) = '1') then
                    data_sh    <= data_sh;
                    exponent   <= exponent;
                    mantissa   <= data_sh(59 downto 36);
                elsif (exponent = 0) then
                    data_sh    <= data_sh;
                    exponent   <= exponent;
                    mantissa   <= data_sh(59 downto 36);
                else
                    data_sh    <= data_sh(58 downto 0) & '0';
                    exponent   <= exponent - '1';
                    mantissa   <= mantissa;
                end if;
            end if;
        end if;
    end process;

    P_Clock_count : process(RST, CLK) begin
        if (RST = '1') then
            done_cnt <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (start_rpls = '1') then
                done_cnt <= (others => '0');
            else
                if (done_cnt = 63) then
                    done_cnt <= done_cnt;
                else
                    done_cnt <= done_cnt + '1';
                end if;
            end if;
        end if;
    end process;
 
    P_Gen_done_signal : process(RST, CLK) begin
        if (RST = '1') then
            done_rpls <= '1';
            DONE_OUT  <= '1'; 
        elsif (CLK'event) and (CLK = '1') then
            if (start_rpls = '1') then
                done_rpls <= '0';
            else
                if (done_cnt = 42) then
                    done_rpls <= '1';
                else
                    done_rpls <= '0';
		end if;
            end if;

            DONE_OUT     <= done_rpls; 
        end if;
    end process;

    P_Mantissa_framework : process(RST, CLK) begin
        if (RST = '1') then
	    mant_frame   <= (others => '0');
        elsif (CLK'event) and (CLK = '1') then
            if (done_rpls = '1') then
                mant_frame   <= "00" & exponent & mantissa;
            else
                mant_frame   <= mant_frame;
            end if;
        end if;
    end process;

    MANTISSA_OUT <= mant_frame; 

end arc_MANTISSA_FRAMER;
