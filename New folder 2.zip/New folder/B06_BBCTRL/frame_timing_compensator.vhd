--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Time compensator                                              --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
-- Target     : Max 4-antennas @ 245.76-MHz                                   --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------
-- Capable maximum delay : MAX_DATA_DELAY-9                                   --
-- Processing delay 9-clocks                                                  --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

entity FRAME_TIMING_COMPENSATOR is
    generic (
        NUM_ANTENNA                 : natural := 4;                             -- 2 or 4
        MAX_DATA_DELAY              : natural := 11264                          -- Buffer depth
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

        BW_SEL                      : in  std_logic_vector(3 downto 0);

        SYNC_DELAY_VALUE            : in  std_logic_vector(31 downto 0);
        DATA_DELAY_VALUE            : in  std_logic_vector(31 downto 0);

        FTC_IN_10MS                 : in  std_logic;
        FTC_IN_TDD                  : in  std_logic;
        FTC_IN_SYNC                 : in  std_logic;
        FTC_IN_DATA                 : in  std_logic_vector(15 downto 0);

        FTC_OUT_10MS                : out std_logic;
        FTC_OUT_TDD                 : out std_logic;
        FTC_OUT_SYNC                : out std_logic;
        FTC_OUT_DATA                : out std_logic_vector(15 downto 0)
    );
end FRAME_TIMING_COMPENSATOR;

architecture BEHAVE of FRAME_TIMING_COMPENSATOR is

    constant MAX_SYNC_DELAY         : natural := 2457600;

    function log2 (data_value : integer)
    return integer is
        variable result      : integer := 0;
        variable cnt         : integer := 1;
    begin
        if (data_value <= 1) then
            result     := 0;
        else
            while (cnt < data_value) loop
                result := result + 1;
                cnt    := cnt *2;
            end loop;
        end if;
        return result;
    end log2;

    signal limit_sync               : std_logic_vector(31 downto 0) := (others => '0');
    signal limit_data               : std_logic_vector(31 downto 0) := conv_std_logic_vector(MAX_DATA_DELAY-9, 32);

    signal delay_coarse             : std_logic_vector(15 downto 0) := (others => '1');
    signal delay_fine               : std_logic_vector(5 downto 0) := (others => '0');
    signal cnt_sync                 : std_logic_vector(5 downto 0) := (others => '0');
    signal sample_sync              : std_logic_vector(7 downto 0) := (others => '0');

    component DELAY_PULSE_ME is
    generic (
        DELAY_RANGE                 : natural := 32;                            -- Maximum bit width to set maximum value + 1
        TRANSITION                  : natural := 2
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;
        DELAY_VALUE                 : in  std_logic_vector(DELAY_RANGE-1 downto 0);
        SYNC_IN                     : in  std_logic;
        SYNC_OUT                    : out std_logic
    );
    end component;

    signal delay_value_10ms         : std_logic_vector(log2(MAX_SYNC_DELAY)-1 downto 0) := (others => '0');
    signal delay_value_tdd          : std_logic_vector(log2(MAX_SYNC_DELAY)-1 downto 0) := (others => '0');

--    component BUFFER_COARSE is
--    port (
--        CLKA                        : in  std_logic;
--        WEA                         : in  std_logic_vector(0 downto 0);
--        ADDRA                       : in  std_logic_vector(15 downto 0);
--        DINA                        : in  std_logic_vector(17 downto 0);
--        CLKB                        : in  std_logic;
--        ADDRB                       : in  std_logic_vector(15 downto 0);
--        DOUTB                       : out std_logic_vector(17 downto 0)
--    );
--    end component;

--    component bbctrl_buf is
--    generic(
--        BUF_STYLE                   : string  := "BLOCK";--"DISTRIBUTED","BLOCK","ultra","M20K"
--        BUFF_DEPTH                  : integer := 8192;
--        WIDTH_IN                    : integer := 1
--    );
--    port(
--        WCLK                        : in  std_logic;
--        RCLK                        : in  std_logic;
--        WE                          : in  std_logic;
--        ENB                         : in  std_logic;
--        WADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
--        RADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
--        DATA_IN                     : in  std_logic_vector(WIDTH_IN-1 downto 0);
--        DATA_OUT                    : out std_logic_vector(WIDTH_IN-1 downto 0)
--    );
--    end component;

    component bb_buf is
    generic(
        STYLE                       : string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
        NPIPE                       : integer := 6;
        DEPTH                       : integer := 8192;
        WIDTH                       : integer := 72
    );
    port(
        WCLK                        : in  std_logic;
        RCLK                        : in  std_logic;
        WE                          : in  std_logic;
        ENB                         : in  std_logic;
        WADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
        RADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
        WDATA                       : in  std_logic_vector(WIDTH-1 downto 0);
        RDATA                       : out std_logic_vector(WIDTH-1 downto 0)
    );
    end component;
    

    signal coarse_wea               : std_logic_vector(NUM_ANTENNA*2-1 downto 0) := (others => '0');
    signal coarse_addra             : std_logic_vector(15 downto 0) := (others => '0');
    signal coarse_dina              : std_logic_vector(17 downto 0);
    signal coarse_oea               : std_logic_vector(NUM_ANTENNA*2-1 downto 0) := (others => '0');
    signal coarse_addrb             : std_logic_vector(15 downto 0) := conv_std_logic_vector(MAX_DATA_DELAY-9, 16);
    signal coarse_doutb             : std_logic_vector(17 downto 0);

    component BUFFER_FINE is
    port (
        CLKA                        : in  std_logic;
        WEA                         : in  std_logic_vector(0 downto 0);
        ADDRA                       : in  std_logic_vector(5 downto 0);
        DINA                        : in  std_logic_vector(17 downto 0);
        CLKB                        : in  std_logic;
        ADDRB                       : in  std_logic_vector(5 downto 0);
        DOUTB                       : out std_logic_vector(17 downto 0)
    );
    end component;

    signal fine_addra               : std_logic_vector(5 downto 0) := (others => '0');
    signal fine_dina                : std_logic_vector(17 downto 0);
    signal fine_addrb               : std_logic_vector(5 downto 0) := (others => '0');
    signal fine_doutb               : std_logic_vector(17 downto 0);

begin

    PROCESSING_DELAY <= conv_std_logic_vector(15, 24);

    -- delay saturation
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (SYNC_DELAY_VALUE >= MAX_SYNC_DELAY-35) then
                limit_sync <= conv_std_logic_vector(MAX_SYNC_DELAY-35, 32);
            else
                limit_sync <= SYNC_DELAY_VALUE;
            end if;
            if (DATA_DELAY_VALUE >= MAX_DATA_DELAY-9) then
                limit_data <= conv_std_logic_vector(MAX_DATA_DELAY-9, 32);
            else
                limit_data <= DATA_DELAY_VALUE;
            end if;
        end if;
    end process;

    -- decoding delay value
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            delay_value_10ms <= limit_sync(log2(MAX_SYNC_DELAY)-1 downto 0) + conv_std_logic_vector(3, log2(MAX_SYNC_DELAY));
            delay_value_tdd  <= limit_sync(log2(MAX_SYNC_DELAY)-1 downto 0) + conv_std_logic_vector(3, log2(MAX_SYNC_DELAY));
            if (NUM_ANTENNA = 2) then
                case BW_SEL is
                when "0010" =>  -- 5-MHz
                    delay_coarse     <= "000" & limit_data(15 downto 5) & "00";
                    delay_fine       <= '0' & limit_data(4 downto 0);
                when "0011" =>  -- 10-MHz
                    delay_coarse     <= "00" & limit_data(15 downto 4) & "00";
                    delay_fine       <= "00" & limit_data(3 downto 0);
                when others =>  -- 15/20-MHz
                    delay_coarse     <= '0' & limit_data(15 downto 3) & "00";
                    delay_fine       <= "000" & limit_data(2 downto 0);
                end case;
            else
                case BW_SEL is
                when "0010" =>  -- 5-MHz
                    delay_coarse     <= "00" & limit_data(15 downto 5) & "000";
                    delay_fine       <= '0' & limit_data(4 downto 0);
                when "0011" =>  -- 10-MHz
                    delay_coarse     <= '0' & limit_data(15 downto 4) & "000";
                    delay_fine       <= "00" & limit_data(3 downto 0);
                when others =>  -- 15/20-MHz
                    delay_coarse     <= limit_data(15 downto 3) & "000";
                    delay_fine       <= "000" & limit_data(2 downto 0);
                end case;
            end if;
        end if;
    end process;

    -- chip to sample
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (FTC_IN_SYNC = '1') then
                cnt_sync <= (others => '0');
            else
                cnt_sync <= cnt_sync + 1;
            end if;
            case BW_SEL is
            when "0010" =>  -- 5-MHz
                if (cnt_sync(4 downto 0) = 31) then
                    sample_sync(0) <= '1';
                else
                    sample_sync(0) <= '0';
                end if;
            when "0011" =>  -- 10-MHz
                if (cnt_sync(3 downto 0) = 15) then
                    sample_sync(0) <= '1';
                else
                    sample_sync(0) <= '0';
                end if;
            when others =>  -- 15/20-MHz
                if (cnt_sync(2 downto 0) = 7) then
                    sample_sync(0) <= '1';
                else
                    sample_sync(0) <= '0';
                end if;
            end case;
            sample_sync(7 downto 1) <= sample_sync(6 downto 0);
        end if;
    end process;

--------------------------------------------------------------------------------
-- Coarse delay
--------------------------------------------------------------------------------

    -- write/read enable
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (sample_sync(0) = '1') then
                coarse_wea <= (others => '1');
            else
                coarse_wea <= coarse_wea(NUM_ANTENNA*2-2 downto 0) & '0';
            end if;
            if (sample_sync(7) = '1') then
                coarse_oea <= (others => '1');
            else
                coarse_oea <= coarse_oea(NUM_ANTENNA*2-2 downto 0) & '0';
            end if;
        end if;
    end process;

    -- address
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (coarse_wea(NUM_ANTENNA*2-1) = '1') then
                if (coarse_addra = MAX_DATA_DELAY-1) then
                    coarse_addra <= (others => '0');
                else
--                    if (sample_sync(1) = '1') then
--                        coarse_addra <= coarse_addra(log2(MAX_DATA_DELAY)-1 downto 3) & "001";
--                    else
                        coarse_addra <= coarse_addra + 1;
--                    end if;
                end if;
            end if;
            if (coarse_wea(NUM_ANTENNA*2-1) = '1') then
                if (coarse_addra = delay_coarse) then
                    coarse_addrb <= (others => '0');
                else
                    if (coarse_addrb = MAX_DATA_DELAY-1) then
                        coarse_addrb <= (others => '0');
                    else
                        coarse_addrb <= coarse_addrb + 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    -- data
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            coarse_dina(15 downto 0) <= FTC_IN_DATA;
            coarse_dina(16)          <= sample_sync(0);
            coarse_dina(17)          <= '0';
        end if;
    end process;

--------------------------------------------------------------------------------
-- Fine delay
--------------------------------------------------------------------------------

    -- address
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (fine_addra = 63) then
                fine_addra <= (others => '0');
            else
                fine_addra <= fine_addra + 1;
            end if;
            if (fine_addra = delay_fine) then
                fine_addrb <= (others => '0');
            else
                fine_addrb <= fine_addrb + 1;
            end if;
        end if;
    end process;

    -- data
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (coarse_oea(NUM_ANTENNA*2-1) = '1') then
                fine_dina <= coarse_doutb;
            else
                fine_dina <= (others => '0');
            end if;
        end if;
    end process;

    FTC_OUT_SYNC <= fine_doutb(16);

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            FTC_OUT_DATA <= fine_doutb(15 downto 0);
        end if;
    end process;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_10ms_DELAY : DELAY_PULSE_ME
    generic map(
        DELAY_RANGE                 => log2(MAX_SYNC_DELAY)                    ,--: natural := 32;
        TRANSITION                  => 1                                        --: natural := 2
    )
    port map(
        RESET                       => RESET                                   ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;
        DELAY_VALUE                 => delay_value_10ms                        ,--: in  std_logic_vector(DELAY_RANGE-1 downto 0);
        SYNC_IN                     => FTC_IN_10MS                             ,--: in  std_logic;
        SYNC_OUT                    => FTC_OUT_10MS                             --: out std_logic
    );

    u_TDD_DELAY : DELAY_PULSE_ME
    generic map(
        DELAY_RANGE                 => log2(MAX_SYNC_DELAY)                    ,--: natural := 32;
        TRANSITION                  => 2                                        --: natural := 2
    )
    port map(
        RESET                       => RESET                                   ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;
        DELAY_VALUE                 => delay_value_tdd                         ,--: in  std_logic_vector(DELAY_RANGE-1 downto 0);
        SYNC_IN                     => FTC_IN_TDD                              ,--: in  std_logic;
        SYNC_OUT                    => FTC_OUT_TDD                              --: out std_logic
    );

--    u_COARSE_DELAY_BUFFER : BUFFER_COARSE
--    port map(
--        CLKA                        => CLK                                     ,--: in  std_logic;
--        WEA(0)                      => coarse_wea(NUM_ANTENNA*2-1)             ,--: in  std_logic_vector(0 downto 0);
--        ADDRA                       => coarse_addra                            ,--: in  std_logic_vector(15 downto 0);
--        DINA                        => coarse_dina                             ,--: in  std_logic_vector(17 downto 0);
--        CLKB                        => CLK                                     ,--: in  std_logic;
--        ADDRB                       => coarse_addrb                            ,--: in  std_logic_vector(15 downto 0);
--        DOUTB                       => coarse_doutb                             --: out std_logic_vector(17 downto 0)
--    );

--    u_COARSE_DELAY_BUFFER : bbctrl_buf
--    generic map(
--        BUF_STYLE                    => "ultra"                                , --: string  := "BLOCK";--"DISTRIBUTED","BLOCK","ultra","M20K"
--        BUFF_DEPTH                   => 49152                                  , --: integer := 8192;
--        WIDTH_IN                     => 18                                       --: integer := 1
--    )
--    port map(
--        WCLK                         => CLK                                    , --: in  std_logic;
--        RCLK                         => CLK                                    , --: in  std_logic;
--        WE                           => coarse_wea(NUM_ANTENNA*2-1)            , --: in  std_logic;
--        ENB                          => '1'                                    , --: in  std_logic;
--        WADDR                        => coarse_addra                           , --: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
--        RADDR                        => coarse_addrb                           , --: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
--        DATA_IN                      => coarse_dina                            , --: in  std_logic_vector(WIDTH_IN-1 downto 0);
--        DATA_OUT                     => coarse_doutb                             --: out std_logic_vector(WIDTH_IN-1 downto 0)
--    );
--
    u_COARSE_DELAY_BUFFER : bb_buf 
    generic map(
        STYLE                         => "ultra"                               , --: string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
        NPIPE                         => 6                                     , --: integer := 6;
        DEPTH                         => 49152                                 , --: integer := 8192;
        WIDTH                         => 18                                      --: integer := 72
    )
    port map(
        WCLK                          => CLK                                   , --: in  std_logic;
        RCLK                          => CLK                                   , --: in  std_logic;
        WE                            => coarse_wea(NUM_ANTENNA*2-1)           , --: in  std_logic;
        ENB                           => '1'                                   , --: in  std_logic;
        WADDR                         => coarse_addra                          , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        RADDR                         => coarse_addrb                          , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        WDATA                         => coarse_dina                           , --: in  std_logic_vector(WIDTH-1 downto 0);
        RDATA                         => coarse_doutb                            --: out std_logic_vector(WIDTH-1 downto 0)
    );
    

    u_FINE_DELAY_BUFFER : BUFFER_FINE
    port map(
        CLKA                        => CLK                                     ,--: in  std_logic;
        WEA                         => "1"                                     ,--: in  std_logic_vector(0 downto 0);
        ADDRA                       => fine_addra                              ,--: in  std_logic_vector(5 downto 0);
        DINA                        => fine_dina                               ,--: in  std_logic_vector(17 downto 0);
        CLKB                        => CLK                                     ,--: in  std_logic;
        ADDRB                       => fine_addrb                              ,--: in  std_logic_vector(5 downto 0);
        DOUTB                       => fine_doutb                               --: out std_logic_vector(17 downto 0)
    );

end BEHAVE;