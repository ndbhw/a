--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : 15bits to 16bits                                              --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------
-- Processing delay 8-clocks                                                  --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity CONV_15TO16 is
    port (
        CLK                         : in  std_logic;

        LINE_RCF_CLKTYPE            : in  std_logic_vector(7 downto 0);
    
        CONV_IN_SYNC                : in  std_logic;
        CONV_IN_DATA_I              : in  std_logic_vector(14 downto 0);
        CONV_IN_DATA_Q              : in  std_logic_vector(14 downto 0);

        CONV_OUT_SYNC               : out std_logic;
        CONV_OUT_DATA_I             : out std_logic_vector(15 downto 0);
        CONV_OUT_DATA_Q             : out std_logic_vector(15 downto 0)
    );
end CONV_15TO16;

architecture BEHAVE of CONV_15TO16 is

    signal cnt_sync                 : std_logic_vector(5 downto 0) := (others => '0');

    signal buf_data_i               : std_logic_vector(74 downto 0) := (others => '0');
    signal buf_data_q               : std_logic_vector(74 downto 0) := (others => '0');

    signal sync                     : std_logic := '0';
    signal data_i                   : std_logic_vector(44 downto 0) := (others => '0');
    signal data_q                   : std_logic_vector(44 downto 0) := (others => '0');

begin

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (CONV_IN_SYNC = '1') then
                cnt_sync <= "000010";
            else
                case LINE_RCF_CLKTYPE is
                when x"20"  =>
                    if (cnt_sync = 31) then
                        cnt_sync <= (others => '0');
                    else
                        cnt_sync <= cnt_sync + 1;
                    end if;
                when others =>
                    cnt_sync <= cnt_sync + 1;
                end case;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            buf_data_i(74 downto 60) <= CONV_IN_DATA_I;
            buf_data_i(59 downto 45) <= buf_data_i(74 downto 60);
            buf_data_i(44 downto 30) <= buf_data_i(59 downto 45);
            buf_data_i(29 downto 15) <= buf_data_i(44 downto 30);
            buf_data_i(14 downto 0)  <= buf_data_i(29 downto 15);
            buf_data_q(74 downto 60) <= CONV_IN_DATA_Q;
            buf_data_q(59 downto 45) <= buf_data_q(74 downto 60);
            buf_data_q(44 downto 30) <= buf_data_q(59 downto 45);
            buf_data_q(29 downto 15) <= buf_data_q(44 downto 30);
            buf_data_q(14 downto 0)  <= buf_data_q(29 downto 15);
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (cnt_sync(5 downto 4) = "01") then        data_i <= buf_data_i(60 downto 16);
                                                            data_q <= buf_data_q(60 downto 16);
            elsif (cnt_sync(5 downto 4) = "10") then        data_i <= "00" & buf_data_i(74 downto 32);
                                                            data_q <= "00" & buf_data_q(74 downto 32);
            elsif (cnt_sync(5 downto 4) = "11") then        data_i <= "00" & x"0000" & buf_data_i(74 downto 48);
                                                            data_q <= "00" & x"0000" & buf_data_q(74 downto 48);
            else                                            data_i <= buf_data_i(44 downto 0);
                                                            data_q <= buf_data_q(44 downto 0);
            end if;
        end if;
    end process;

    CONV_OUT_SYNC <= sync;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case LINE_RCF_CLKTYPE is
            when x"20"  =>
                if (cnt_sync = 25) then
                    sync <= '1';
                else
                    sync <= '0';
                end if;
            when others =>
                if (cnt_sync = 57) then
                    sync <= '1';
                else
                    sync <= '0';
                end if;
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case cnt_sync(3 downto 0) is
            when "0000" => CONV_OUT_DATA_I <= data_i(30 downto 15);
            when "0001" => CONV_OUT_DATA_I <= data_i(15 downto 0);
            when "0010" => CONV_OUT_DATA_I <= data_i(16 downto 1);
            when "0011" => CONV_OUT_DATA_I <= data_i(17 downto 2);
            when "0100" => CONV_OUT_DATA_I <= data_i(18 downto 3);
            when "0101" => CONV_OUT_DATA_I <= data_i(19 downto 4);
            when "0110" => CONV_OUT_DATA_I <= data_i(20 downto 5);
            when "0111" => CONV_OUT_DATA_I <= data_i(21 downto 6);
            when "1000" => CONV_OUT_DATA_I <= data_i(22 downto 7);
            when "1001" => CONV_OUT_DATA_I <= data_i(23 downto 8);
            when "1010" => CONV_OUT_DATA_I <= data_i(24 downto 9);
            when "1011" => CONV_OUT_DATA_I <= data_i(25 downto 10);
            when "1100" => CONV_OUT_DATA_I <= data_i(26 downto 11);
            when "1101" => CONV_OUT_DATA_I <= data_i(27 downto 12);
            when "1110" => CONV_OUT_DATA_I <= data_i(28 downto 13);
            when others => CONV_OUT_DATA_I <= data_i(29 downto 14);
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case cnt_sync(3 downto 0) is
            when "0000" => CONV_OUT_DATA_Q <= data_q(30 downto 15);
            when "0001" => CONV_OUT_DATA_Q <= data_q(15 downto 0);
            when "0010" => CONV_OUT_DATA_Q <= data_q(16 downto 1);
            when "0011" => CONV_OUT_DATA_Q <= data_q(17 downto 2);
            when "0100" => CONV_OUT_DATA_Q <= data_q(18 downto 3);
            when "0101" => CONV_OUT_DATA_Q <= data_q(19 downto 4);
            when "0110" => CONV_OUT_DATA_Q <= data_q(20 downto 5);
            when "0111" => CONV_OUT_DATA_Q <= data_q(21 downto 6);
            when "1000" => CONV_OUT_DATA_Q <= data_q(22 downto 7);
            when "1001" => CONV_OUT_DATA_Q <= data_q(23 downto 8);
            when "1010" => CONV_OUT_DATA_Q <= data_q(24 downto 9);
            when "1011" => CONV_OUT_DATA_Q <= data_q(25 downto 10);
            when "1100" => CONV_OUT_DATA_Q <= data_q(26 downto 11);
            when "1101" => CONV_OUT_DATA_Q <= data_q(27 downto 12);
            when "1110" => CONV_OUT_DATA_Q <= data_q(28 downto 13);
            when others => CONV_OUT_DATA_Q <= data_q(29 downto 14);
            end case;
        end if;
    end process;

end BEHAVE;