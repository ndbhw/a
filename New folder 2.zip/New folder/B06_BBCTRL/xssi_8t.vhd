--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Power measure for tssi and rssi                               --
--                                                                            --
-- Author     : h_r.hong(h_r.hong@samsung.com)                                --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2020.03.16                                                    --
-- Target     :                                                               --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.all;
use IEEE.STD_LOGIC_UNSIGNED.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

Library UNISIM;
use UNISIM.vcomponents.all;
library UNIMACRO;
use unimacro.Vcomponents.all;


entity XSSI_8T is    -- 1.92Msps NB-IoT 4T 2cell
    port (
    RESET                 : in  std_logic;
    CLK                   : in  std_logic;     -- 491.52MHz

    I_MEAS_SYNC           : in  std_logic;
    I_TDD                 : in  std_logic;
    I_DATA_SYNC           : in  std_logic;
    I_DATA_IQ             : in  std_logic_vector(15 downto 0);
    
    O_MEAS_DONE           : out std_logic_array4( 1 downto 0);  --vector(3 downto 0);
    O_XSSI_ANT0           : out std_logic_array32(1 downto 0); --vector(31 downto 0);
    O_XSSI_ANT1           : out std_logic_array32(1 downto 0); --vector(31 downto 0);
    O_XSSI_ANT2           : out std_logic_array32(1 downto 0); --vector(31 downto 0);
    O_XSSI_ANT3           : out std_logic_array32(1 downto 0)  --vector(31 downto 0)
);
end XSSI_8T;


architecture ARC_XSSI_8T of XSSI_8T is 

    signal m_sync_r                    : std_logic := '0';
    signal m_sync_d                    : std_logic := '0'; 
    signal m_sync_rpls                 : std_logic := '0'; 
    signal m_sync_rpls_d               : std_logic_vector(17 downto 0) := (others => '0'); 
    signal tdd_d                       : std_logic := '0';

    signal sample_sync_d               : std_logic_vector(4 downto 0) := (others => '0');
    signal cnt_sync                    : std_logic_vector(6 downto 0) := (others => '0');
    signal cnt_sync_d                  : std_logic_vector(6 downto 0) := (others => '0');
    signal cnt_sync_d2                 : std_logic_vector(6 downto 0) := (others => '0');

    signal sample_en                   : std_logic := '0';
    signal sum_en                      : std_logic := '0';
    signal sum_clear                   : std_logic_vector(7 downto 0) := (others => '0');
    signal avg_pwr                     : std_logic_array64(7 downto 0) := (others => (others => '0'));
    signal sum_pwr                     : std_logic_array64(7 downto 0) := (others => (others => '0'));

    signal data_mult_out               : std_logic_vector(31 downto 0) := (others => '0'); 

    component MANTISSA_FRAMER is
    port(
    RST          : in  std_logic;
    CLK          : in  std_logic;

    START_IN     : in  std_logic;
    DATA_IN      : in  std_logic_vector(63 downto 0);
    
    DONE_OUT     : out std_logic;
    MANTISSA_OUT : out std_logic_vector(31 downto 0)
    );
    end component;

    signal pwr_conv_srt                 : std_logic_vector(7  downto 0);
    signal conv_done                    : std_logic_vector(7  downto 0);
    signal pwr_conv_out                 : std_logic_array32(7 downto 0);

    signal xssi_0                       : std_logic_array32(1 downto 0);
    signal xssi_1                       : std_logic_array32(1 downto 0);
    signal xssi_2                       : std_logic_array32(1 downto 0);
    signal xssi_3                       : std_logic_array32(1 downto 0);

begin

    -- rising pulse of measure sync (depend on ssb period)
    process(CLK)
    begin
        if (CLK'event and CLK ='1') then
          --  if (I_DATA_SYNC = '1') then
          --      m_sync_r <= I_MEAS_SYNC;
          --  end if;
            m_sync_d      <= I_MEAS_SYNC;
            m_sync_rpls   <= I_MEAS_SYNC and (not m_sync_d);
            m_sync_rpls_d <= m_sync_rpls_d(16 downto 0) & m_sync_rpls;
            tdd_d         <= I_TDD;
        end if;
    end process;

    -- sample sync couter
    process(CLK)
    begin
        if (CLK'event and CLK ='1') then
            sample_sync_d <= sample_sync_d(3 downto 0) & I_DATA_SYNC;

            if (sample_sync_d(1) = '1') then
                cnt_sync <= (others => '0');
            else 
                cnt_sync <= cnt_sync + 1;
            end if;
            cnt_sync_d  <= cnt_sync;
            cnt_sync_d2 <= cnt_sync_d;
        end if;
    end process;

    -- generate sum enable
    process(CLK)
    begin
        if (CLK'event and CLK = '1') then    
            if (cnt_sync(6 downto 4) = "0000") then 
                sample_en <= '1';
            else
                sample_en <= '0';
            end if;

            sum_en <= tdd_d and sample_en;
        end if;
    end process;

--    -- generate sum enable
--    process(CLK)
--    begin
--        if (CLK'event and CLK = '1') then    
--            if (I_BW_SEL = x"2") then        --5MHz
--                if (cnt_sync(4 downto 3) = "00") then
--                    sample_en <= '1';
--                else
--                    sample_en <= '0';
--                end if;
--            elsif (I_BW_SEL = x"3") then     --10MHz
--                if (cnt_sync(3) = '0') then
--                    sample_en <= '1';
--                else
--                    sample_en <= '0';
--                end if;
--            else                          --15/20MHz
--                sample_en <= '1';
--            end if;
--
--            sum_en <= tdd_d and sample_en;
--        end if;
--    end process;

    -- latancy : 4-clock
    mult_16x16_iq : MULT_MACRO
    generic map (
        DEVICE        => "7SERIES"       , -- Target Device: "VIRTEX5", "VIRTEX6", "SPARTAN6"
        LATENCY       => 4               , -- Desired clock cycle latency, 0-4
        WIDTH_A       => 16              , -- Multiplier A-input bus width, 1-25
        WIDTH_B       => 16                -- Multiplier B-input bus width, 1-18
        )
    port map (
        P             => data_mult_out   , -- Multiplier output bus, width determined by WIDTH_P generic
        A             => I_DATA_IQ       , -- Multiplier input A bus, width determined by WIDTH_A generic
        B             => I_DATA_IQ       , -- Multiplier input B bus, width determined by WIDTH_B generic
        CE            => '1'             , -- 1-bit active high input clock enable
        CLK           => CLK             , -- 1-bit positive edge clock input
        RST           => RESET             -- 1-bit input active high reset
        );
    

    G_PWR_MEASURE : for i in 7 downto 0 generate
    -- sum clear per path
    process(CLK)
    begin
        if (CLK'event and CLK = '1') then          
            if (m_sync_rpls_d(i*2+1) = '1') then
                sum_clear(i) <= '1';
            else
                sum_clear(i) <= '0';
            end if;
         end if;
    end process;
            
    process(CLK)
    begin
        if (CLK'event and CLK = '1') then          
            if (sum_clear(i) = '1') then
                avg_pwr(i) <= sum_pwr(i);
                if (tdd_d = '1') then
                    sum_pwr(i) <= x"00000000" & data_mult_out;
                else
                    sum_pwr(i) <= (others => '0');
                end if;
            else
                avg_pwr(i) <= avg_pwr(i);
                if (sum_en = '1') then
                    if (cnt_sync_d2(3 downto 1) = i) then
                        sum_pwr(i) <= sum_pwr(i) + (x"00000000" & data_mult_out);
                    end if;
                end if;
            end if;
        end if;
    end process;

    process(CLK)
    begin
        if (CLK'event and CLK ='1') then
            pwr_conv_srt(i) <= m_sync_rpls_d(17);
        end if;
    end process;
            
    u_pwr_conv_blk : MANTISSA_FRAMER 
    port map(
        RST                => RESET                   , --: in  std_logic;
        CLK                => CLK                     , --: in  std_logic;
        
        START_IN           => pwr_conv_srt(i)         , --: in  std_logic;
        DATA_IN            => avg_pwr(i)              , --: in  std_logic_vector(63 downto 0);
        
        DONE_OUT           => conv_done(i)            , --: out std_logic;
        MANTISSA_OUT       => pwr_conv_out(i)           --: out std_logic_vector(31 downto 0)
    );
    end generate;

    process(CLK)
    begin
        if (CLK'event and CLK = '1') then
            O_XSSI_ANT0(0)  <= pwr_conv_out(0);
            O_XSSI_ANT1(0)  <= pwr_conv_out(1);
            O_XSSI_ANT2(0)  <= pwr_conv_out(2);
            O_XSSI_ANT3(0)  <= pwr_conv_out(3);
            O_XSSI_ANT0(1)  <= pwr_conv_out(4);
            O_XSSI_ANT1(1)  <= pwr_conv_out(5);
            O_XSSI_ANT2(1)  <= pwr_conv_out(6);
            O_XSSI_ANT3(1)  <= pwr_conv_out(7);
        end if;
    end process;

    O_MEAS_DONE(0) <= conv_done(3 downto 0);        
    O_MEAS_DONE(1) <= conv_done(7 downto 4);        


end ARC_XSSI_8T; 

