/*******************************************************************************/
/* Ant Delay                                                                   */
/* 1. path per delay = 133.333 us                                              */
/* 2. Max ant number = 4                                                       */
/*******************************************************************************/
module ant_path_delay#(
    parameter ANT_NUM = 4
)(
    // clk and reset
    input  wire          I_CLK,
    input  wire          I_RST,
    // parameter
    input  wire [11:0]   I_ANT0_DELAY,
    input  wire [11:0]   I_ANT1_DELAY,
    input  wire [11:0]   I_ANT2_DELAY,
    input  wire [11:0]   I_ANT3_DELAY,
    output wire [11:0]   O_PROC_DELAY,
    // traffice interface
    input  wire          I_10MS,
    input  wire          I_TDD,
    input  wire          I_SYNC,
    input  wire [15:0]   I_DATA_IQ,
    output wire          O_10MS,
    output wire          O_TDD,
    output wire          O_SYNC,
    output wire [15:0]   O_DATA_IQ
);
    /*******************************************************************************/
    /* Parameter                                                                   */
    /*******************************************************************************/
    localparam PROC_DELAY  = 12;
    /*******************************************************************************/
    /* Signal latch                                                                */
    /*******************************************************************************/
    reg        r_10ms       [PROC_DELAY-1:0]   ;
    reg        r_tdd        [PROC_DELAY-1:0]   ;
    reg        r_sync       [PROC_DELAY-1:0]   ;
    reg [15:0] r_data_iq    [PROC_DELAY-1:0]   ;
    reg [11:0] r_ant_delay  [ANT_NUM-1:0]       ;

    generate
	for (genvar latch_idx = 0; latch_idx < PROC_DELAY; latch_idx = latch_idx + 1) begin : block
	    if(latch_idx == 0) begin
		always @(posedge I_CLK) begin
		    r_10ms   [0]   <= I_10MS;
		    r_tdd    [0]   <= I_TDD;
		    r_sync   [0]   <= I_SYNC;
		    r_data_iq[0]   <= I_DATA_IQ;
		end
	    end
	    else begin
		always @(posedge I_CLK) begin
		    r_10ms   [latch_idx]   <= r_10ms[latch_idx-1];
		    r_tdd    [latch_idx]   <= r_tdd[latch_idx-1];
		    r_sync   [latch_idx]   <= r_sync[latch_idx-1];
		    r_data_iq[latch_idx]   <= r_data_iq[latch_idx-1];
		end
	    end
	end
    endgenerate

    always @(posedge I_CLK) begin
	r_ant_delay[0]   <= I_ANT0_DELAY;
	r_ant_delay[1]   <= I_ANT1_DELAY;
	r_ant_delay[2]   <= I_ANT2_DELAY;
	r_ant_delay[3]   <= I_ANT3_DELAY;
    end

    /*******************************************************************************/
    /* Split ant path data                                                         */
    /*******************************************************************************/
    reg [ 5:0] r_ant_cnt;
    reg [15:0] r_ant0_i,r_ant1_i,r_ant2_i,r_ant3_i;
    reg [15:0] r_ant0_q,r_ant1_q,r_ant2_q,r_ant3_q;

    // 20M - 8clk
    // 10M - 16clk
    // ...
    // 3M  - 64clk
    always @(posedge I_CLK or posedge I_RST) begin
	if(I_RST == 1'b1) begin
	    r_ant_cnt <= 6'd0; // max 3M BW support
	end
	else begin
	    if(r_sync[0] == 1'b1) begin
		r_ant_cnt <= 3'd0;
	    end
	    else begin
		r_ant_cnt <= r_ant_cnt + 6'd1;
	    end
	end
    end

    always @(posedge I_CLK) begin
	case (r_ant_cnt)
	    6'd0 : begin
		r_ant0_i <= r_data_iq[0];
	    end
	    6'd1 : begin
		r_ant0_q <= r_data_iq[0];
	    end
	    6'd2 : begin
		r_ant1_i <= r_data_iq[0];
	    end
	    6'd3 : begin
		r_ant1_q <= r_data_iq[0];
	    end
	    6'd4 : begin
		r_ant2_i <= r_data_iq[0];
	    end
	    6'd5 : begin
		r_ant2_q <= r_data_iq[0];
	    end
	    6'd6 : begin
		r_ant3_i <= r_data_iq[0];
	    end
	    6'd7 : begin
		r_ant3_q <= r_data_iq[0];
	    end
	    default : begin
		r_ant0_i <= 16'd0;
		r_ant0_q <= 16'd0;
		r_ant1_i <= 16'd0;
		r_ant1_q <= 16'd0;
		r_ant2_i <= 16'd0;
		r_ant2_q <= 16'd0;
		r_ant3_i <= 16'd0;
		r_ant3_q <= 16'd0;
	    end
	endcase
    end

    /*******************************************************************************/
    /* Write ant path data @ URAM                                                  */
    /* Cancat iq data                                                              */
    /* Write enable and address using sync delay                                   */
    /* Read adress == Write address - ANT Delay                                    */
    /*******************************************************************************/
    reg  [31:0] r_ant_iq[3:0];
    reg  [11:0] r_wraddr[ANT_NUM-1:0];
    reg  [11:0] r_rdaddr[ANT_NUM-1:0];
    wire [31:0] w_rddata[3:0];

    generate
	for (genvar ant_idx = ANT_NUM; ant_idx < 4; ant_idx = ant_idx + 1) begin : except
	    assign w_rddata[ant_idx] = 32'd0;
	end
    endgenerate


    always @(posedge I_CLK) begin
	if(r_sync[3+2*0] == 1'b1) begin
	    r_ant_iq[0] <= {r_ant0_i,r_ant0_q};
	end
	if(r_sync[3+2*1] == 1'b1) begin
	    r_ant_iq[1] <= {r_ant1_i,r_ant1_q};
	end
	if(r_sync[3+2*2] == 1'b1) begin
	    r_ant_iq[2] <= {r_ant2_i,r_ant2_q};
	end
	if(r_sync[3+2*3] == 1'b1) begin
	    r_ant_iq[3] <= {r_ant3_i,r_ant3_q};
	end
    end

    generate
	for (genvar ant_idx = 0; ant_idx < ANT_NUM; ant_idx = ant_idx + 1) begin
	    always@(posedge I_CLK or posedge I_RST) begin
		if(I_RST == 1'b1) begin
		    r_wraddr[ant_idx] <= 12'd0;
		end
		else begin
		    if(r_sync[4+2*ant_idx] == 1'b1) begin
			r_wraddr[ant_idx] <= r_wraddr[ant_idx] + 12'd1;
		    end
		end
	    end

	    always@(posedge I_CLK or posedge I_RST) begin
		if(I_RST == 1'b1) begin
		    r_rdaddr[ant_idx] <= 12'd0;
		end
		else begin
		    if(r_sync[4+2*ant_idx] == 1'b1) begin
			r_rdaddr[ant_idx] <= r_wraddr[ant_idx] - r_ant_delay[ant_idx];
		    end
		end
	    end

	    bb_buf #(
		.STYLE           ("ultra"), //string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
		.NPIPE           (6), //integer := 6;
		.DEPTH           (4096), //integer := 8192;
		.WIDTH           (32) //integer := 72;
	    )
	    inst_ant_buf (
		.WCLK (I_CLK),
		.RCLK (I_CLK),
		.WE   (r_sync[4+2*ant_idx]),
		.ENB  (1'b1),
		.WADDR(r_wraddr[ant_idx]),
		.RADDR(r_rdaddr[ant_idx]),
		.WDATA(r_ant_iq[ant_idx]),
		.RDATA(w_rddata[ant_idx])
	    );
	end
    endgenerate

    /*******************************************************************************/
    /* Read date arrange(iq interleaving)                                          */
    /* Reference sync : Ant0 sync                                                  */
    /*******************************************************************************/
    // 20M - 8clk
    // 10M - 16clk
    // ...
    // 3M  - 64clk
    reg [ 5:0] r_rd_cnt;
    reg [15:0] r_rd_data_iq;

    always @(posedge I_CLK or posedge I_RST) begin
	if(I_RST == 1'b1) begin
	    r_rd_cnt <= 6'd0;
	end
	else begin
	    if(r_sync[10] == 1'b1) begin
		r_rd_cnt <= 6'd0;
	    end
	    else begin
		r_rd_cnt <= r_rd_cnt + 6'd1;
	    end
	end
    end

    always @(posedge I_CLK or posedge I_RST) begin
	if(I_RST == 1'b1) begin
	    r_rd_data_iq <= 6'd0;
	end
	else begin
	    case (r_rd_cnt)
		6'd0 : begin
		    r_rd_data_iq <= w_rddata[0][31:16];
		end
		6'd1 : begin
		    r_rd_data_iq <= w_rddata[0][15:0];
		end
		6'd2 : begin
		    r_rd_data_iq <= w_rddata[1][31:16];
		end
		6'd3 : begin
		    r_rd_data_iq <= w_rddata[1][15:0];
		end
		6'd4 : begin
		    r_rd_data_iq <= w_rddata[2][31:16];
		end
		6'd5 : begin
		    r_rd_data_iq <= w_rddata[2][15:0];
		end
		6'd6 : begin
		    r_rd_data_iq <= w_rddata[3][31:16];
		end
		6'd7 : begin
		    r_rd_data_iq <= w_rddata[3][15:0];
		end
		default : begin
		    r_rd_data_iq <= 16'd0;
		end
	    endcase
	end
    end

    /*******************************************************************************/
    /* Assign port mapping                                                         */
    /*******************************************************************************/
    assign O_PROC_DELAY = PROC_DELAY;
    assign O_10MS       = r_10ms[PROC_DELAY-1];
    assign O_TDD        = r_tdd[PROC_DELAY-1];
    assign O_SYNC       = (r_rd_cnt == 6'd0) ? 1'b1 : 1'b0;
    assign O_DATA_IQ    = r_rd_data_iq;


endmodule
