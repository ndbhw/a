--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : BBCTRL Top (GSM)                                       --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                             --
-- Department : FPGA part. (Network Division)                                   --
-- Release    : 2021.11.24                                                    --
-- Target     : RF2221D                                                --
--                                                                            --
--------------------------------------------------------------------------------
-- Feature (V3.0, 2017-05-17 based)                                           --
--------------------------------------------------------------------------------
--  1. Max SBIF port : 2                                                      --
--  2. Max mapper : -                                                         --
--  3. Max formatter : -                                                      --
--------------------------------------------------------------------------------
-- Revision History       
-- revision for gsm                                                    --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
-- Rev2.0 - remove nbiot & gsm                                                --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;
use WORK.RU_FPGA_CONFIG.ALL;

entity BBCTRL_TOP is
    port (
--------------------------------------------------------------------------------
-- SYSCTRL_TOP
--------------------------------------------------------------------------------

        RST_BBCTRL                  : in  std_logic;

        CLK_CPRI                    : in  std_logic_vector(SBIF_NUM-1 downto 0);

        CLK_SYS                     : in  std_logic;
        CLK_SYSX2                   : in  std_logic;
        CLK_SYSX3                   : in  std_logic;
        CLK_SYSX4                   : in  std_logic;
        CLK_SYSX5                   : in  std_logic;
        CLK_SYSX6                   : in  std_logic;
        CLK_SYSX8                   : in  std_logic;
        CLK_SYSX10                  : in  std_logic;
        CLK_SYSX12                  : in  std_logic;
        CLK_SYSX16                  : in  std_logic;
        CLK_SYSX20                  : in  std_logic;

        RX_120MS_STRB_IN            : in  std_logic_vector(SBIF_NUM-1 downto 0);
        RX_BFN_STRB_IN              : in  std_logic_vector(SBIF_NUM-1 downto 0);
        RX_BFN_NR_IN                : in  std_logic_array12(SBIF_NUM-1 downto 0);
        RX_TDD_IN                   : in  std_logic_vector(SBIF_NUM-1 downto 0);

        TX_BFN_STRB_IN              : in  std_logic_vector(SBIF_NUM-1 downto 0);
        TX_BFN_NR_IN                : in  std_logic_array12(SBIF_NUM-1 downto 0);
        TX_TDD_OUT                  : out std_logic_vector(SBIF_NUM-1 downto 0);
        TX_BFN_STRB_OUT             : out std_logic_vector(SBIF_NUM-1 downto 0);

        SSB_OFFSET                  : in  std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- CPU_TOP
--------------------------------------------------------------------------------

        RST_CPUIF                   : in  std_logic;
        CLK_CPUIF                   : in  std_logic;

--------------------------------------------------------------------------------
-- CPUIF_TOP
--------------------------------------------------------------------------------

        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);    
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             : out std_logic;

--------------------------------------------------------------------------------
-- SBIF_TOP
--------------------------------------------------------------------------------

        SBIF_RX_VLD_IN              : in  std_logic_vector(SBIF_NUM-1 downto 0);
        SBIF_RX_I_IN                : in  std_logic_array16(SBIF_NUM-1 downto 0);
        SBIF_RX_Q_IN                : in  std_logic_array16(SBIF_NUM-1 downto 0);

        SBIF_TX_ENB_IN              : in  std_logic_vector(SBIF_NUM-1 downto 0);
        SBIF_TX_I_OUT               : out std_logic_array16(SBIF_NUM-1 downto 0);
        SBIF_TX_Q_OUT               : out std_logic_array16(SBIF_NUM-1 downto 0);

--------------------------------------------------------------------------------
-- DSP_TOP
--------------------------------------------------------------------------------

        DL_BFN_OK                   : out std_logic;

        DL_AIRTECH_OUT              : out std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
        DL_CHBW_OUT                 : out std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
        DL_TDD_OUT                  : out std_logic;
        DL_40MS_OUT                 : out std_logic;
        DL_BFN_STRB_OUT             : out std_logic;
        DL_BFN_OUT                  : out std_logic_vector(11 downto 0);
        DL_SYNC_OUT                 : out std_logic_vector(DL_BBIQARY_NUM-1 downto 0);
        DL_IQ_OUT                   : out std_logic_array16(DL_BBIQARY_NUM-1 downto 0);

        UL_AIRTECH_OUT              : out std_logic_array4(UL_BBIQARY_NUM-1 downto 0);
        UL_CHBW_OUT                 : out std_logic_array4(UL_BBIQARY_NUM-1 downto 0);
        UL_TDD_IN                   : in  std_logic;
        UL_BFN_STRB_IN              : in  std_logic;
        UL_SYNC_IN                  : in  std_logic_vector(UL_BBIQARY_NUM-1 downto 0);
        UL_IQ_IN                    : in  std_logic_array16(UL_BBIQARY_NUM-1 downto 0);

--------------------------------------------------------------------------------
-- MISC_TOP
--------------------------------------------------------------------------------

        DUMP_BFN_STRB_OUT           : out std_logic_vector(1 downto 0);
        DUMP_DATA_OUT               : out std_logic_array32(1 downto 0);
        DUMP_DVLD_OUT               : out std_logic_vector(1 downto 0);

     -- fb_sw_new
        FBSW_CNT                    : in  std_logic_vector(3 downto 0);
        FBSW_SSB_IND_FLAG           : in  std_logic; 
        FBSW_MEAS_UPDATE            : in  std_logic
    );
end BBCTRL_TOP;

architecture BEHAVE of BBCTRL_TOP is

    constant NUM_CPRI               : natural := SBIF_NUM;
    constant NUM_FMT                : natural := UL_BBIQARY_NUM;
    constant NUM_MAP                : natural := TOTAL_MAP_NUM;

    signal dl_bit_conv_delay        : std_logic_vector(23 downto 0);
    signal dl_dduc_if_delay         : std_logic_vector(23 downto 0);
    signal dl_formatter_delay       : std_logic_array24(NUM_FMT-1 downto 0);

    signal ul_bit_conv_delay        : std_logic_vector(23 downto 0);
    signal ul_dduc_if_delay         : std_logic_vector(23 downto 0);
    signal ul_formatter_delay       : std_logic_array24(NUM_FMT-1 downto 0);

    component CPUIF_BBCTRL is
    generic (
        OFFSET                      : std_logic_vector(3 downto 0) := x"4";
        NUM_CPRI                    : natural := 8;
        NUM_MAP                     : natural := 8;
            NUM_FMT                     : natural := 8
    );
    port (
        CLK_AUX                     : in  std_logic;
        CLK_SYSX8                   : in  std_logic;
    
        RESET                       : in  std_logic;
    
        DL_BIT_CONV_DELAY           : in  std_logic_vector(23 downto 0);
        DL_DDUC_IF_DELAY            : in  std_logic_vector(23 downto 0);
        DL_FORMATTER_DELAY          : in  std_logic_array24(NUM_FMT-1 downto 0);
    
        UL_BIT_CONV_DELAY           : in  std_logic_vector(23 downto 0);
        UL_DDUC_IF_DELAY            : in  std_logic_vector(23 downto 0);
        UL_FORMATTER_DELAY          : in  std_logic_array24(NUM_FMT-1 downto 0);
    
        DUMP_EN                     : out std_logic;
        DUMP_SEL                    : out std_logic_vector(11 downto 0);
    
        BW_SEL                      : out std_logic_array4(NUM_FMT-1 downto 0);
        ANT_SWAP                    : out std_logic_array4(NUM_FMT-1 downto 0);
    
        DL_MAP_WR_EN                : out std_logic_vector(NUM_MAP-1 downto 0);
        DL_MAP_WR_ADDR              : out std_logic_vector(4 downto 0);
        DL_MAP_WR_DATA              : out std_logic_vector(6 downto 0);
        DL_MAP_RD_DATA              : in  std_logic_array7(NUM_MAP-1 downto 0);
    
        UL_MAP_WR_EN                : out std_logic_vector(NUM_MAP-1 downto 0);
        UL_MAP_WR_ADDR              : out std_logic_vector(5 downto 0);
        UL_MAP_WR_DATA              : out std_logic_vector(6 downto 0);
        UL_MAP_RD_DATA              : in  std_logic_array7(NUM_MAP-1 downto 0);
    
        MAP_CPRI                    : out std_logic_array8(NUM_MAP-1 downto 0);
    
        MAPPER_UL_MAP               : out std_logic_array16(NUM_MAP-1 downto 0);
        FORMATTER_DL_MAP            : out std_logic_array16(NUM_FMT-1 downto 0);
        CASCADE_UL_SUM              : out std_logic_array16(2 downto 0);
        
        SYNC_DELAY_VALUE            : out std_logic_array32(NUM_FMT-1 downto 0);
    
        DL_DELAY_VALUE              : out std_logic_array32(NUM_FMT-1 downto 0);
        UL_DELAY_VALUE              : out std_logic_array32(NUM_FMT-1 downto 0);
    
        ZRHC_BYPASS                 : out std_logic_vector(NUM_FMT-1 downto 0);
        ZRHC_THRESHOLD              : out std_logic_array32(NUM_FMT-1 downto 0);
        ZRHC_OCCUR                  : in  std_logic_array4(NUM_FMT-1 downto 0);
    
        DL_ON                       : out std_logic_array4(NUM_FMT-1 downto 0);
        UL_ON                       : out std_logic_array4(NUM_FMT-1 downto 0);
    
        DL_ATT_0                    : out std_logic_array20(NUM_FMT-1 downto 0);
        DL_ATT_1                    : out std_logic_array20(NUM_FMT-1 downto 0);
        DL_ATT_2                    : out std_logic_array20(NUM_FMT-1 downto 0);
        DL_ATT_3                    : out std_logic_array20(NUM_FMT-1 downto 0);
    
        UL_ATT_0                    : out std_logic_array20(NUM_FMT-1 downto 0);
        UL_ATT_1                    : out std_logic_array20(NUM_FMT-1 downto 0);
        UL_ATT_2                    : out std_logic_array20(NUM_FMT-1 downto 0);
        UL_ATT_3                    : out std_logic_array20(NUM_FMT-1 downto 0);
    
        TSSI_UPDATE_MODE            : out std_logic_vector(1 downto 0);
        TSSI_UPDATE_CNT_0           : out std_logic_array5(NUM_FMT-1 downto 0);
        TSSI_UPDATE_CNT_1           : out std_logic_array5(NUM_FMT-1 downto 0);
        TSSI_UPDATE_CNT_2           : out std_logic_array5(NUM_FMT-1 downto 0);
        TSSI_UPDATE_CNT_3           : out std_logic_array5(NUM_FMT-1 downto 0);
    
        RSSI_UPDATE_MODE            : out std_logic_vector(1 downto 0);
        RSSI_UPDATE_CNT_0           : out std_logic_array5(NUM_FMT-1 downto 0);
        RSSI_UPDATE_CNT_1           : out std_logic_array5(NUM_FMT-1 downto 0);
        RSSI_UPDATE_CNT_2           : out std_logic_array5(NUM_FMT-1 downto 0);
        RSSI_UPDATE_CNT_3           : out std_logic_array5(NUM_FMT-1 downto 0);
    
        TSSI_0                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        TSSI_1                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        TSSI_2                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        TSSI_3                      : in  std_logic_array32(NUM_FMT-1 downto 0);
    
        RSSI_0                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        RSSI_1                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        RSSI_2                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        RSSI_3                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        
        SCALE_FACTOR                : out std_logic_array3(5 downto 0);
        
        TEST_MODE                   : out std_logic_array4(NUM_FMT-1 downto 0);
    
        TEST_DC_I                   : out std_logic_vector(15 downto 0);
        TEST_DC_Q                   : out std_logic_vector(15 downto 0);
        TEST_NCO                    : out std_logic_vector(5 downto 0);
    
        --1ms tp
        TP_OFFSET                   : out std_logic_vector(14 downto 0);
        TP_OFFSET_EN                : out std_logic;
    
        TP_MEM_PEN                  : out std_logic;    -- A/B port enable
        TP_MEM_AWEN                 : out std_logic_vector(1 downto 0);    -- A port write enable, 0 : 10M BRAM, 1 : 15M BRAM
        TP_MEM_WRADDR               : out std_logic_vector(14 downto 0);
        TP_MEM_WRDATA               : out std_logic_vector(31 downto 0);  -- 31..16 : Q data, 15..0 : I data
        
        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);    
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             : out std_logic;
        
        DL_PATH_DELAY_0             : out std_logic_vector(11 downto 0);
        DL_PATH_DELAY_1             : out std_logic_vector(11 downto 0);
        DL_PATH_DELAY_2             : out std_logic_vector(11 downto 0);
        DL_PATH_DELAY_3             : out std_logic_vector(11 downto 0);
        UL_PATH_DELAY_0             : out std_logic_vector(11 downto 0);
        UL_PATH_DELAY_1             : out std_logic_vector(11 downto 0);
        UL_PATH_DELAY_2             : out std_logic_vector(11 downto 0);
        UL_PATH_DELAY_3             : out std_logic_vector(11 downto 0)
    );
    end component;

    signal dump_en                  : std_logic;
    signal dump_sel                 : std_logic_vector(11 downto 0);
    signal bw_sel                   : std_logic_array4(NUM_FMT-1 downto 0);
    signal dl_map_wr_en             : std_logic_vector(NUM_MAP-1 downto 0);
    signal dl_map_wr_addr           : std_logic_vector(4 downto 0);
    signal dl_map_wr_data           : std_logic_vector(6 downto 0);
    signal dl_map_rd_data           : std_logic_array7(NUM_MAP-1 downto 0);
    signal ul_map_wr_en             : std_logic_vector(NUM_MAP-1 downto 0);
    signal ul_map_wr_addr           : std_logic_vector(5 downto 0);
    signal ul_map_wr_data           : std_logic_vector(6 downto 0);
    signal ul_map_rd_data           : std_logic_array7(NUM_MAP-1 downto 0);
    signal map_cpri                 : std_logic_array8(NUM_MAP-1 downto 0);
    signal mapper_ul_map            : std_logic_array16(NUM_MAP-1 downto 0);
    signal formatter_dl_map         : std_logic_array16(NUM_FMT-1 downto 0);
    signal cascade_ul_sum           : std_logic_array16(2 downto 0);
    signal sync_delay_value         : std_logic_array32(NUM_FMT-1 downto 0);
    signal dl_delay_value           : std_logic_array32(NUM_FMT-1 downto 0);
    signal dl_antdly_0              : std_logic_array12(NUM_FMT-1 downto 0);
    signal dl_antdly_1              : std_logic_array12(NUM_FMT-1 downto 0);
    signal dl_antdly_2              : std_logic_array12(NUM_FMT-1 downto 0);
    signal dl_antdly_3              : std_logic_array12(NUM_FMT-1 downto 0);
    signal ul_delay_value           : std_logic_array32(NUM_FMT-1 downto 0);
    signal ul_antdly_0              : std_logic_array12(NUM_FMT-1 downto 0);
    signal ul_antdly_1              : std_logic_array12(NUM_FMT-1 downto 0);
    signal ul_antdly_2              : std_logic_array12(NUM_FMT-1 downto 0);
    signal ul_antdly_3              : std_logic_array12(NUM_FMT-1 downto 0);
    signal zrhc_bypass              : std_logic_vector(NUM_FMT-1 downto 0);
    
    -- Path delay signals from cpuif_bbctrl to FORMATTER
    signal dl_path_delay_0          : std_logic_vector(11 downto 0);
    signal dl_path_delay_1          : std_logic_vector(11 downto 0);
    signal dl_path_delay_2          : std_logic_vector(11 downto 0);
    signal dl_path_delay_3          : std_logic_vector(11 downto 0);
    signal ul_path_delay_0          : std_logic_vector(11 downto 0);
    signal ul_path_delay_1          : std_logic_vector(11 downto 0);
    signal ul_path_delay_2          : std_logic_vector(11 downto 0);
    signal ul_path_delay_3          : std_logic_vector(11 downto 0);
    signal zrhc_threshold           : std_logic_array32(NUM_FMT-1 downto 0);
    signal zrhc_occur               : std_logic_array4(NUM_FMT-1 downto 0);
    signal dl_on                    : std_logic_array4(NUM_FMT-1 downto 0);
    signal dl_on_max                : std_logic_array4(7 downto 0) := (others => (others => '0'));
    signal ul_on                    : std_logic_array4(NUM_FMT-1 downto 0);
    signal dl_att_0                 : std_logic_array20(NUM_FMT-1 downto 0);
    signal dl_att_1                 : std_logic_array20(NUM_FMT-1 downto 0);
    signal dl_att_2                 : std_logic_array20(NUM_FMT-1 downto 0);
    signal dl_att_3                 : std_logic_array20(NUM_FMT-1 downto 0);
    signal ul_att_0                 : std_logic_array20(NUM_FMT-1 downto 0);
    signal ul_att_1                 : std_logic_array20(NUM_FMT-1 downto 0);
    signal ul_att_2                 : std_logic_array20(NUM_FMT-1 downto 0);
    signal ul_att_3                 : std_logic_array20(NUM_FMT-1 downto 0);
    signal tssi_update_mode         : std_logic_vector(1 downto 0);
    signal tssi_update_cnt_0        : std_logic_array5(NUM_FMT-1 downto 0);
    signal tssi_update_cnt_1        : std_logic_array5(NUM_FMT-1 downto 0);
    signal tssi_update_cnt_2        : std_logic_array5(NUM_FMT-1 downto 0);
    signal tssi_update_cnt_3        : std_logic_array5(NUM_FMT-1 downto 0);
    signal rssi_update_mode         : std_logic_vector(1 downto 0);
    signal rssi_update_cnt_0        : std_logic_array5(NUM_FMT-1 downto 0);
    signal rssi_update_cnt_1        : std_logic_array5(NUM_FMT-1 downto 0);
    signal rssi_update_cnt_2        : std_logic_array5(NUM_FMT-1 downto 0);
    signal rssi_update_cnt_3        : std_logic_array5(NUM_FMT-1 downto 0);
    signal tssi_0                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal tssi_1                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal tssi_2                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal tssi_3                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal rssi_0                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal rssi_1                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal rssi_2                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal rssi_3                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal scale_factor             : std_logic_array3(5 downto 0);
    signal test_mode                : std_logic_array4(NUM_FMT-1 downto 0);
    signal test_dc_i                : std_logic_vector(15 downto 0);
    signal test_dc_q                : std_logic_vector(15 downto 0);
    signal test_nco                     : std_logic_vector(5 downto 0);    
    signal ant_swap                 : std_logic_array4(NUM_FMT-1 downto 0);    
    
    component BIT_CONV is
    port (

        CLK_CPRI                    : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        I_RX_TDD                    : in  std_logic;

        LINE_RCF_CLKTYPE            : in  std_logic_vector(7 downto 0);

        I_RX_BFN_STRB               : in  std_logic;
        I_RX_BFN                    : in  std_logic_vector(11 downto 0);
        I_RX_VLD                    : in  std_logic;
        I_RX_I                      : in  std_logic_vector(15 downto 0);
        I_RX_Q                      : in  std_logic_vector(15 downto 0);

        O_TX_10MS                   : out std_logic;
        O_TX_TDD                    : out std_logic;
        I_TX_ENB                    : in  std_logic;
        O_TX_I                      : out std_logic_vector(15 downto 0);
        O_TX_Q                      : out std_logic_vector(15 downto 0);

        O_RX_10MS                   : out std_logic;
        O_RX_BFN                    : out std_logic_vector(11 downto 0);
        O_RX_TDD                    : out std_logic;
        O_RX_SYNC                   : out std_logic;
        O_RX_DATA_I                 : out std_logic_vector(15 downto 0);
        O_RX_DATA_Q                 : out std_logic_vector(15 downto 0);

        I_TX_10MS                   : in  std_logic;
        I_TX_TDD                    : in  std_logic;
        O_TX_SYNC                   : out std_logic;
        I_TX_DATA_I                 : in  std_logic_vector(15 downto 0);
        I_TX_DATA_Q                 : in  std_logic_vector(15 downto 0)
    );
    end component;

    component emu_out_BIT_CONV is
    port (
        clk                         : in  std_logic;
        rst                         : in  std_logic;

        O_RX_10MS                   : out std_logic;
        O_RX_TDD                    : out std_logic;
        O_RX_SYNC                   : out std_logic;
        O_RX_DATA_I                 : out std_logic_vector(15 downto 0);
        O_RX_DATA_Q                 : out std_logic_vector(15 downto 0)
    );
    end component;

    signal rx_10ms                 : std_logic_vector(NUM_CPRI-1 downto 0);
    signal rx_bfn                   : std_logic_array12(NUM_CPRI-1 downto 0);
    signal rx_tdd                   : std_logic_vector(NUM_CPRI-1 downto 0);
    signal rx_sync                  : std_logic_vector(NUM_CPRI-1 downto 0);
    signal rx_data_i                : std_logic_array16(NUM_CPRI-1 downto 0);
    signal rx_data_q                : std_logic_array16(NUM_CPRI-1 downto 0);
    signal tx_10ms                  : std_logic_vector(NUM_CPRI-1 downto 0);
    signal tx_tdd                   : std_logic_vector(NUM_CPRI-1 downto 0);
    signal tx_sync                  : std_logic_vector(NUM_CPRI-1 downto 0);
    signal tx_data_i                : std_logic_array16(NUM_CPRI-1 downto 0);
    signal tx_data_q                : std_logic_array16(NUM_CPRI-1 downto 0);

    component LTE_ETM_1MS_TP_2CC is
    port (
        RST                  : in  std_logic;
        WCLK                 : in  std_logic;    -- CPUIF_MISC Clock domain
        RCLK                 : in  std_logic;    -- 245.76MHz Clock domain

        TP_MEM_PEN           : in  std_logic;    -- A/B port enable
        TP_MEM_AWEN          : in  std_logic_vector(1 downto 0);    -- A port write enable, 0 : 10M BRAM, 1 : 15M BRAM
        TP_MEM_WRADDR        : in  std_logic_vector(14 downto 0);
        TP_MEM_WRDATA        : in  std_logic_vector(31 downto 0);  -- 31..16 : I data, 15..0 : Q data

        SYNC                 : in  std_logic;
        SAMPLE_ENB           : in  std_logic_vector(1 downto 0);    -- Sample period tick, activated only 1 cpri core clock per sample, 0 : CC0(10M), 1 : CC1(15M)

        OFFSET_EN            : in  std_logic;
        OFFSET               : in  std_logic_vector(14 downto 0);
        
        TP_OUT               : out std_logic_vector(31 downto 0)
         );
    end component;
 
    signal tp_mem_pen                : std_logic;    -- A/B port enable
    signal tp_mem_awen               : std_logic_vector(1 downto 0);    -- A port write enable, 0 : 10M BRAM, 1 : 15M BRAM
    signal tp_mem_wraddr             : std_logic_vector(14 downto 0);
    signal tp_mem_wrdata             : std_logic_vector(31 downto 0);  -- 31..16 : I data, 15..0 : Q data

    signal tp_offset                 : std_logic_vector(14 downto 0);
    signal tp_offset_en              : std_logic;

    signal dl_tp_out                 : std_logic_vector(31 downto 0);
    signal dl_data_i_sel             : std_logic_vector(15 downto 0);
    signal dl_data_q_sel             : std_logic_vector(15 downto 0);

    component DDUC_MAP_IF is
    port (
        ARESET                      : in  std_logic;

        CLK_AUX                     : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        BW_SEL                      : in  std_logic_array4(3 downto 0);
        ANT_SWAP                    : in  std_logic_array4(3 downto 0);

        I_RX_10MS                   : in  std_logic;
        I_RX_BFN                    : in  std_logic_vector(11 downto 0);
        I_RX_TDD                    : in  std_logic;
        I_RX_SYNC                   : in  std_logic;
        I_RX_DATA_I                 : in  std_logic_vector(15 downto 0);
        I_RX_DATA_Q                 : in  std_logic_vector(15 downto 0);

        O_TX_10MS                   : out std_logic;
        O_TX_TDD                    : out std_logic;
        I_TX_SYNC                   : in  std_logic;
        O_TX_DATA_I                 : out std_logic_vector(15 downto 0);
        O_TX_DATA_Q                 : out std_logic_vector(15 downto 0);

        O_DL_10MS                   : out std_logic;
        O_DL_BFN                    : out std_logic_vector(11 downto 0);
        O_DL_TDD                    : out std_logic;
        O_DL_SYNC                   : out std_logic_vector(3 downto 0);
        O_DL_DATA                   : out std_logic_array16(3 downto 0);

        I_UL_10MS                   : in  std_logic;
        I_UL_TDD                    : in  std_logic;
        I_UL_SYNC                   : in  std_logic_vector(3 downto 0);
        I_UL_DATA                   : in  std_logic_array16(3 downto 0)
    );
    end component;

    signal dl_fmt_10ms              : std_logic;
    signal dl_fmt_bfn               : std_logic_vector(11 downto 0);
    signal dl_fmt_tdd               : std_logic;
    signal dl_fmt_sync              : std_logic_vector(3 downto 0);
    signal dl_fmt_data              : std_logic_array16(3 downto 0);

    signal kddi_dl_fmt_sync         : std_logic_vector(3 downto 0);
    signal kddi_dl_fmt_data         : std_logic_array16(3 downto 0);
                  
    signal ul_fmt_10ms              : std_logic_vector(3 downto 0);
    signal ul_fmt_tdd               : std_logic_vector(3 downto 0);
    signal ul_fmt_sync              : std_logic_vector(3 downto 0);
    signal ul_fmt_data              : std_logic_array16(3 downto 0);

    signal kddi_ul_fmt_sync         : std_logic_vector(3 downto 0);
    signal kddi_ul_fmt_data         : std_logic_array16(3 downto 0);
    signal kddi_bw_sel              : std_logic_array4(NUM_FMT-1 downto 0);

    component FORMATTER is
    generic (
            NUM_ANTENNA                 : natural := 4
    );
    port (
        ARESET                      : in  std_logic;

        CLK                         : in  std_logic;

        BW_SEL                      : in  std_logic_vector(3 downto 0);

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        SSB_OFFSET                  : in  std_logic_vector(3 downto 0);
        DL_DELAY_VALUE              : in  std_logic_vector(31 downto 0);
        UL_DELAY_VALUE              : in  std_logic_vector(31 downto 0);
        
        DL_PATH_DELAY_0             : in  std_logic_vector(11 downto 0);
        DL_PATH_DELAY_1             : in  std_logic_vector(11 downto 0);
        DL_PATH_DELAY_2             : in  std_logic_vector(11 downto 0);
        DL_PATH_DELAY_3             : in  std_logic_vector(11 downto 0);
        UL_PATH_DELAY_0             : in  std_logic_vector(11 downto 0);
        UL_PATH_DELAY_1             : in  std_logic_vector(11 downto 0);
        UL_PATH_DELAY_2             : in  std_logic_vector(11 downto 0);
        UL_PATH_DELAY_3             : in  std_logic_vector(11 downto 0);
        
        DL_10MS                     : in  std_logic;
        DL_BFN                      : in  std_logic_vector(11 downto 0);
        DL_TDD                      : in  std_logic;
        DL_SYNC                     : in  std_logic;
        DL_DATA                     : in  std_logic_vector(15 downto 0);

        UL_10MS                     : out std_logic;
        UL_TDD                      : out std_logic;
        UL_SYNC                     : out std_logic;
        UL_DATA                     : out std_logic_vector(15 downto 0);

        DUC_BFN_ABNORMAL            : out std_logic;

        DUC_AIRTECH                 : out std_logic_vector(3 downto 0);
        DUC_CHBW                    : out std_logic_vector(3 downto 0);
        DUC_40MS                    : out std_logic;
        DUC_10MS                    : out std_logic;
        DUC_BFN                     : out std_logic_vector(11 downto 0);
        DUC_TDD                     : out std_logic;
        DUC_SYNC                    : out std_logic;
        DUC_DATA                    : out std_logic_vector(15 downto 0);

        DDC_AIRTECH                 : out std_logic_vector(3 downto 0);
        DDC_CHBW                    : out std_logic_vector(3 downto 0);
        DDC_10MS                    : in  std_logic;
        DDC_TDD                     : in  std_logic;
        DDC_SYNC                    : in  std_logic;
        DDC_DATA                    : in  std_logic_vector(15 downto 0);

        ZRHC_BYPASS                 : in  std_logic;
        ZRHC_THRESHOLD              : in  std_logic_vector(31 downto 0);
        ZRHC_OCCUR                  : out std_logic_vector(3 downto 0);

        DL_ON                       : in  std_logic_vector(3 downto 0);
        UL_ON                       : in  std_logic_vector(3 downto 0);

        DL_ATT_0                    : in  std_logic_vector(19 downto 0);
        DL_ATT_1                    : in  std_logic_vector(19 downto 0);
        DL_ATT_2                    : in  std_logic_vector(19 downto 0);
        DL_ATT_3                    : in  std_logic_vector(19 downto 0);

        UL_ATT_0                    : in  std_logic_vector(19 downto 0);
        UL_ATT_1                    : in  std_logic_vector(19 downto 0);
        UL_ATT_2                    : in  std_logic_vector(19 downto 0);
        UL_ATT_3                    : in  std_logic_vector(19 downto 0);
        FBSW_CNT                    : in  std_logic_vector(3 downto 0);
        FBSW_SSB_IND_FLAG           : in  std_logic; 
        FBSW_MEAS_UPDATE            : in  std_logic; 

        TSSI_UPDATE_MODE            : in  std_logic_vector(1 downto 0);
        TSSI_UPDATE_CNT_0           : in  std_logic_vector(4 downto 0);
        TSSI_UPDATE_CNT_1           : in  std_logic_vector(4 downto 0);
        TSSI_UPDATE_CNT_2           : in  std_logic_vector(4 downto 0);
        TSSI_UPDATE_CNT_3           : in  std_logic_vector(4 downto 0);

        RSSI_UPDATE_MODE            : in  std_logic_vector(1 downto 0);
        RSSI_UPDATE_CNT_0           : in  std_logic_vector(4 downto 0);
        RSSI_UPDATE_CNT_1           : in  std_logic_vector(4 downto 0);
        RSSI_UPDATE_CNT_2           : in  std_logic_vector(4 downto 0);
        RSSI_UPDATE_CNT_3           : in  std_logic_vector(4 downto 0);

        TSSI_0                      : out std_logic_vector(31 downto 0);
        TSSI_1                      : out std_logic_vector(31 downto 0);
        TSSI_2                      : out std_logic_vector(31 downto 0);
        TSSI_3                      : out std_logic_vector(31 downto 0);

        RSSI_0                      : out std_logic_vector(31 downto 0);
        RSSI_1                      : out std_logic_vector(31 downto 0);
        RSSI_2                      : out std_logic_vector(31 downto 0);
        RSSI_3                      : out std_logic_vector(31 downto 0);

        TEST_MODE                   : in  std_logic_vector(3 downto 0);

        TEST_DC_I                   : in  std_logic_vector(15 downto 0);
        TEST_DC_Q                   : in  std_logic_vector(15 downto 0);
        TEST_NCO                    : in  std_logic_vector(5 downto 0);

        DUMP_DL_10MS                : out std_logic;
        DUMP_DL_SYNC                : out std_logic;
        DUMP_DL_DATA                : out std_logic_vector(15 downto 0);

        DUMP_UL_10MS                : out std_logic;
        DUMP_UL_SYNC                : out std_logic;
        DUMP_UL_DATA                : out std_logic_vector(15 downto 0)
    );
    end component;

    signal duc_bfn_abnormal         : std_logic_vector(NUM_FMT-1 downto 0);
    signal duc_bfn_normal_max       : std_logic_vector(7 downto 0) := (others => '0');
    signal duc_40ms                 : std_logic_vector(NUM_FMT-1 downto 0);
    signal duc_40ms_max             : std_logic_vector(7 downto 0) := (others => '0');
    signal duc_10ms                 : std_logic_vector(NUM_FMT-1 downto 0);
    signal duc_10ms_max             : std_logic_vector(7 downto 0) := (others => '0');
    signal duc_bfn                  : std_logic_array12(NUM_FMT-1 downto 0);
    signal duc_bfn_max              : std_logic_array12(7 downto 0) := (others => (others => '0'));
    signal duc_tdd                  : std_logic_vector(NUM_FMT-1 downto 0);
    signal duc_tdd_max              : std_logic_vector(7 downto 0) := (others => '0');
    signal ddc_10ms                 : std_logic_vector(NUM_FMT-1 downto 0);
    signal ddc_tdd                  : std_logic_vector(NUM_FMT-1 downto 0);

    signal dump_dl_10ms             : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_dl_sync             : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_dl_sync_sh          : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_dl_data             : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal dump_ul_10ms             : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_ul_sync             : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_ul_data             : std_logic_array16(7 downto 0) := (others => (others => '0'));

    signal dump_sel_dl_10ms         : std_logic := '0';
    signal dump_sel_dl_sync         : std_logic_vector(15 downto 0) := (others => '0');
    signal dump_sel_dl_data_i       : std_logic_vector(15 downto 0) := (others => '0');
    signal dump_sel_dl_data_q       : std_logic_vector(15 downto 0) := (others => '0');
    signal dump_sel_ul_10ms         : std_logic := '0';
    signal dump_sel_ul_sync         : std_logic_vector(31 downto 0) := (others => '0');
    signal dump_sel_ul_data_i       : std_logic_vector(15 downto 0) := (others => '0');
    signal dump_sel_ul_data_q       : std_logic_vector(15 downto 0) := (others => '0');

begin

--------------------------------------------------------------------------------
-- Port mapping
--------------------------------------------------------------------------------

    u_UL_FMT : for i in NUM_FMT-1 downto 0 generate
    ddc_10ms(i) <= UL_BFN_STRB_IN;
    ddc_tdd(i)  <= UL_TDD_IN;     

    dl_on_max(i)            <= dl_on(i);
    duc_bfn_normal_max(i)   <= not duc_bfn_abnormal(i);
    duc_40ms_max(i)         <= duc_40ms(i);
    duc_10ms_max(i)         <= duc_10ms(i);
    duc_bfn_max(i)          <= duc_bfn(i);
    duc_tdd_max(i)          <= duc_tdd(i);
    end generate;

    DL_BFN_OK       <= duc_bfn_normal_max(0) when dl_on_max(0) /= 0 else
                       duc_bfn_normal_max(1) when dl_on_max(1) /= 0 else
                       duc_bfn_normal_max(2) when dl_on_max(2) /= 0 else
                       duc_bfn_normal_max(3) when dl_on_max(3) /= 0 else
                       duc_bfn_normal_max(4) when dl_on_max(4) /= 0 else
                       duc_bfn_normal_max(5) when dl_on_max(5) /= 0 else
                       duc_bfn_normal_max(6) when dl_on_max(6) /= 0 else
                       duc_bfn_normal_max(7) when dl_on_max(7) /= 0 else
                       duc_bfn_normal_max(0);

    DL_TDD_OUT      <= duc_tdd_max(0) when dl_on_max(0) /= 0 else
                       duc_tdd_max(1) when dl_on_max(1) /= 0 else
                       duc_tdd_max(2) when dl_on_max(2) /= 0 else
                       duc_tdd_max(3) when dl_on_max(3) /= 0 else
                       duc_tdd_max(4) when dl_on_max(4) /= 0 else
                       duc_tdd_max(5) when dl_on_max(5) /= 0 else
                       duc_tdd_max(6) when dl_on_max(6) /= 0 else
                       duc_tdd_max(7) when dl_on_max(7) /= 0 else
                       duc_tdd_max(0);

    DL_40MS_OUT     <= duc_40ms_max(0) when dl_on_max(0) /= 0 else
                       duc_40ms_max(1) when dl_on_max(1) /= 0 else
                       duc_40ms_max(2) when dl_on_max(2) /= 0 else
                       duc_40ms_max(3) when dl_on_max(3) /= 0 else
                       duc_40ms_max(4) when dl_on_max(4) /= 0 else
                       duc_40ms_max(5) when dl_on_max(5) /= 0 else
                       duc_40ms_max(6) when dl_on_max(6) /= 0 else
                       duc_40ms_max(7) when dl_on_max(7) /= 0 else
                       duc_40ms_max(0);

    DL_BFN_STRB_OUT <= duc_10ms_max(0) when dl_on_max(0) /= 0 else
                       duc_10ms_max(1) when dl_on_max(1) /= 0 else
                       duc_10ms_max(2) when dl_on_max(2) /= 0 else
                       duc_10ms_max(3) when dl_on_max(3) /= 0 else
                       duc_10ms_max(4) when dl_on_max(4) /= 0 else
                       duc_10ms_max(5) when dl_on_max(5) /= 0 else
                       duc_10ms_max(6) when dl_on_max(6) /= 0 else
                       duc_10ms_max(7) when dl_on_max(7) /= 0 else
                       duc_10ms_max(0);

    DL_BFN_OUT      <= duc_bfn_max(0) when dl_on_max(0) /= 0 else
                       duc_bfn_max(1) when dl_on_max(1) /= 0 else
                       duc_bfn_max(2) when dl_on_max(2) /= 0 else
                       duc_bfn_max(3) when dl_on_max(3) /= 0 else
                       duc_bfn_max(4) when dl_on_max(4) /= 0 else
                       duc_bfn_max(5) when dl_on_max(5) /= 0 else
                       duc_bfn_max(6) when dl_on_max(6) /= 0 else
                       duc_bfn_max(7) when dl_on_max(7) /= 0 else
                       duc_bfn_max(0);

--------------------------------------------------------------------------------
-- Dump
--------------------------------------------------------------------------------

    -- Path selection (DL)
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
                dump_dl_sync_sh <= dump_dl_sync;
                for i in 7 downto 0 loop
                if (dump_sel(4 downto 2) = i) then
                    dump_sel_dl_10ms   <= dump_dl_10ms(i);
                    dump_sel_dl_sync   <= dump_sel_dl_sync(14 downto 0) & dump_dl_sync_sh(i);
                    dump_sel_dl_data_i <= dump_sel_dl_data_q;
                    dump_sel_dl_data_q <= dump_dl_data(i);
                end if;
                end loop;
            end if;
    end process;

    -- Path selection (UL)
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then            
                for i in 7 downto 0 loop
                if (dump_sel(4 downto 2) = i) then
                    dump_sel_ul_10ms   <= dump_ul_10ms(i);
                    dump_sel_ul_sync   <= dump_sel_ul_sync(30 downto 0) & dump_ul_sync(i);
                    dump_sel_ul_data_i <= dump_sel_ul_data_q;
                    dump_sel_ul_data_q <= dump_ul_data(i);
                end if;
            end loop;            
        end if;
    end process;

    -- DL/UL selection
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
                if (dump_sel(6) = '0') then
                    DUMP_BFN_STRB_OUT(0) <= dump_sel_dl_10ms;
                    DUMP_DATA_OUT(0)     <= dump_sel_dl_data_i & dump_sel_dl_data_q;
                    for i in 3 downto 0 loop
                    if (dump_sel(1 downto 0) = i) then
                        DUMP_DVLD_OUT(0) <= dump_sel_dl_sync(i*2+1);
                    end if;
                    end loop;
                else
                    DUMP_BFN_STRB_OUT(0) <= dump_sel_ul_10ms;
                    DUMP_DATA_OUT(0)     <= dump_sel_ul_data_i & dump_sel_ul_data_q;
                    for i in 3 downto 0 loop
                    if (dump_sel(1 downto 0) = i) then
                        DUMP_DVLD_OUT(0) <= dump_sel_ul_sync(i*2+1);
                    end if;
                    end loop;
                end if;
            -- end if;
        end if;
    end process;

    DUMP_BFN_STRB_OUT(1) <= '0';
    DUMP_DATA_OUT(1)     <= (others => '0');
    DUMP_DVLD_OUT(1)     <= '0';

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_CPUIF : CPUIF_BBCTRL
    generic map(
        OFFSET                      => x"4"                                    ,--: std_logic_vector(3 downto 0) := x"4";
        NUM_CPRI                    => NUM_CPRI                                ,--: natural := 8;
        NUM_MAP                     => NUM_MAP                                 ,--: natural := 8;
            NUM_FMT                     => NUM_FMT                                  --: natural := 8
    )
    port map(
        CLK_AUX                     => CLK_CPUIF                               ,--: in  std_logic;
        CLK_SYSX8                   => CLK_SYSX8                               ,--: in  std_logic;

        RESET                       => RST_CPUIF                               ,--: in  std_logic;

        DL_BIT_CONV_DELAY           => dl_bit_conv_delay                       ,--: in  std_logic_vector(23 downto 0);
        DL_DDUC_IF_DELAY            => dl_dduc_if_delay                        ,--: in  std_logic_vector(23 downto 0);
        DL_FORMATTER_DELAY          => dl_formatter_delay                      ,--: in  std_logic_array24(NUM_FMT-1 downto 0);
                                                             
        UL_BIT_CONV_DELAY           => ul_bit_conv_delay                       ,--: in  std_logic_vector(23 downto 0);
        UL_DDUC_IF_DELAY            => ul_dduc_if_delay                        ,--: in  std_logic_vector(23 downto 0);
        UL_FORMATTER_DELAY          => ul_formatter_delay                      ,--: in  std_logic_array24(NUM_FMT-1 downto 0);

        DUMP_EN                     => dump_en                                 ,--: out std_logic;
        DUMP_SEL                    => dump_sel                                ,--: out std_logic_vector(11 downto 0);

        BW_SEL                      => bw_sel                                  ,--: out std_logic_array4(NUM_FMT-1 downto 0);
            ANT_SWAP                    => open                                    ,--: out std_logic_array4(NUM_FMT-1 downto 0);

        DL_MAP_WR_EN                => dl_map_wr_en                            ,--: out std_logic_vector(NUM_MAP-1 downto 0);
        DL_MAP_WR_ADDR              => dl_map_wr_addr                          ,--: out std_logic_vector(4 downto 0);
        DL_MAP_WR_DATA              => dl_map_wr_data                          ,--: out std_logic_vector(6 downto 0);
        DL_MAP_RD_DATA              => dl_map_rd_data                          ,--: in  std_logic_array7(NUM_MAP-1 downto 0);

        UL_MAP_WR_EN                => ul_map_wr_en                            ,--: out std_logic_vector(NUM_MAP-1 downto 0);
        UL_MAP_WR_ADDR              => ul_map_wr_addr                          ,--: out std_logic_vector(5 downto 0);
        UL_MAP_WR_DATA              => ul_map_wr_data                          ,--: out std_logic_vector(6 downto 0);
        UL_MAP_RD_DATA              => ul_map_rd_data                          ,--: in  std_logic_array7(NUM_MAP-1 downto 0);

        MAP_CPRI                    => map_cpri                                ,--: out std_logic_array8(NUM_MAP-1 downto 0);

        MAPPER_UL_MAP               => mapper_ul_map                           ,--: out std_logic_array16(NUM_MAP-1 downto 0);
        FORMATTER_DL_MAP            => formatter_dl_map                        ,--: out std_logic_array16(NUM_FMT-1 downto 0);
            CASCADE_UL_SUM              => cascade_ul_sum                          ,--: out std_logic_array16(2 downto 0);        

        SYNC_DELAY_VALUE            => sync_delay_value                        ,--: out std_logic_array32(NUM_FMT-1 downto 0);

        DL_DELAY_VALUE              => dl_delay_value                          ,--: out std_logic_array32(NUM_FMT-1 downto 0);
        UL_DELAY_VALUE              => ul_delay_value                          ,--: out std_logic_array32(NUM_FMT-1 downto 0);

        ZRHC_BYPASS                 => zrhc_bypass                             ,--: out std_logic_vector(NUM_FMT-1 downto 0);
        ZRHC_THRESHOLD              => zrhc_threshold                          ,--: out std_logic_array32(NUM_FMT-1 downto 0);
        ZRHC_OCCUR                  => zrhc_occur                              ,--: in  std_logic_array4(NUM_FMT-1 downto 0);

        DL_ON                       => dl_on                                   ,--: out std_logic_array4(NUM_FMT-1 downto 0);
        UL_ON                       => ul_on                                   ,--: out std_logic_array4(NUM_FMT-1 downto 0);

        DL_ATT_0                    => dl_att_0                                ,--: out std_logic_array20(NUM_FMT-1 downto 0);
        DL_ATT_1                    => dl_att_1                                ,--: out std_logic_array20(NUM_FMT-1 downto 0);
        DL_ATT_2                    => dl_att_2                                ,--: out std_logic_array20(NUM_FMT-1 downto 0);
        DL_ATT_3                    => dl_att_3                                ,--: out std_logic_array20(NUM_FMT-1 downto 0);

        UL_ATT_0                    => ul_att_0                                ,--: out std_logic_array20(NUM_FMT-1 downto 0);
        UL_ATT_1                    => ul_att_1                                ,--: out std_logic_array20(NUM_FMT-1 downto 0);
        UL_ATT_2                    => ul_att_2                                ,--: out std_logic_array20(NUM_FMT-1 downto 0);
        UL_ATT_3                    => ul_att_3                                ,--: out std_logic_array20(NUM_FMT-1 downto 0);

        TSSI_UPDATE_MODE            => tssi_update_mode                        ,--: out std_logic_vector(1 downto 0);
        TSSI_UPDATE_CNT_0           => tssi_update_cnt_0                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
        TSSI_UPDATE_CNT_1           => tssi_update_cnt_1                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
        TSSI_UPDATE_CNT_2           => tssi_update_cnt_2                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
        TSSI_UPDATE_CNT_3           => tssi_update_cnt_3                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);

        RSSI_UPDATE_MODE            => rssi_update_mode                        ,--: out std_logic_vector(1 downto 0);
        RSSI_UPDATE_CNT_0           => rssi_update_cnt_0                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
        RSSI_UPDATE_CNT_1           => rssi_update_cnt_1                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
        RSSI_UPDATE_CNT_2           => rssi_update_cnt_2                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
        RSSI_UPDATE_CNT_3           => rssi_update_cnt_3                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);

        TSSI_0                      => tssi_0                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
        TSSI_1                      => tssi_1                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
        TSSI_2                      => tssi_2                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
        TSSI_3                      => tssi_3                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);

        RSSI_0                      => rssi_0                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
        RSSI_1                      => rssi_1                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
        RSSI_2                      => rssi_2                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
        RSSI_3                      => rssi_3                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);

        SCALE_FACTOR                => scale_factor                            ,--: out std_logic_array3(5 downto 0);

        TEST_MODE                   => test_mode                               ,--: out std_logic_array4(NUM_FMT-1 downto 0);

        TEST_DC_I                   => test_dc_i                               ,--: out std_logic_vector(15 downto 0);
        TEST_DC_Q                   => test_dc_q                               ,--: out std_logic_vector(15 downto 0);
        TEST_NCO                    => test_nco                                ,--: out std_logic_vector(5 downto 0);

        TP_OFFSET                   => tp_offset                               ,
        TP_OFFSET_EN                => tp_offset_en                            ,

        TP_MEM_PEN                  => tp_mem_pen                              ,--: out std_logic;    -- A/B port enable
        TP_MEM_AWEN                 => tp_mem_awen                             ,--: out std_logic;    -- A port write enable
        TP_MEM_WRADDR               => tp_mem_wraddr                           ,--: out std_logic_vector(14 downto 0);
        TP_MEM_WRDATA               => tp_mem_wrdata                           ,--: out std_logic_vector(31 downto 0);  -- 31..16 : Q data, 15..0 : I data

        WREN_CPUIF_IN               => WREN_CPUIF_IN                           ,--: in  std_logic;
        RDEN_CPUIF_IN               => RDEN_CPUIF_IN                           ,--: in  std_logic;
        ADDR_CPUIF_IN               => ADDR_CPUIF_IN                           ,--: in  std_logic_vector(15 downto 0);    
        WDATA_CPUIF_IN              => WDATA_CPUIF_IN                          ,--: in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             => RDATA_CPUIF_OUT                         ,--: out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             => RDVAL_CPUIF_OUT                         ,--: out std_logic;
        
        DL_PATH_DELAY_0             => dl_path_delay_0                        ,--: out std_logic_vector(11 downto 0);
        DL_PATH_DELAY_1             => dl_path_delay_1                        ,--: out std_logic_vector(11 downto 0);
        DL_PATH_DELAY_2             => dl_path_delay_2                        ,--: out std_logic_vector(11 downto 0);
        DL_PATH_DELAY_3             => dl_path_delay_3                        ,--: out std_logic_vector(11 downto 0);
        UL_PATH_DELAY_0             => ul_path_delay_0                        ,--: out std_logic_vector(11 downto 0);
        UL_PATH_DELAY_1             => ul_path_delay_1                        ,--: out std_logic_vector(11 downto 0);
        UL_PATH_DELAY_2             => ul_path_delay_2                        ,--: out std_logic_vector(11 downto 0);
        UL_PATH_DELAY_3             => ul_path_delay_3                         --: out std_logic_vector(11 downto 0)
    );

    -- lte/nr path(sbif#2)
--    U_SBIF_IF : BIT_CONV 
--    port map(
--        CLK_CPRI                    => CLK_SYSX8                              ,--: in  std_logic;
--        CLK_SYSX8                   => CLK_SYSX8                              ,--: in  std_logic;
--
--        PROCESSING_DELAY_DL         => dl_bit_conv_delay                      ,--: out std_logic_vector(23 downto 0);
--        PROCESSING_DELAY_UL         => ul_bit_conv_delay                      ,--: out std_logic_vector(23 downto 0);
--
--            I_RX_TDD                    => RX_TDD_IN(2)                           ,--: in  std_logic;
--
--        LINE_RCF_CLKTYPE            => x"40"                                  ,--: in  std_logic_vector(7 downto 0);
--
--            I_RX_BFN_STRB               => RX_BFN_STRB_IN(2)                      ,--: in  std_logic;
--            I_RX_BFN                    => RX_BFN_NR_IN(2)                        ,--: in  std_logic_vector(11 downto 0);
--            I_RX_VLD                    => SBIF_RX_VLD_IN(2)                      ,--: in  std_logic;
--            I_RX_I                      => SBIF_RX_I_IN(2)                        ,--: in  std_logic_vector(15 downto 0);
--            I_RX_Q                      => SBIF_RX_Q_IN(2)                        ,--: in  std_logic_vector(15 downto 0);
--                                                        
--            O_TX_10MS                   => TX_BFN_STRB_OUT(2)                     ,--: out std_logic;
--            O_TX_TDD                    => TX_TDD_OUT(2)                          ,--: out std_logic;
--            I_TX_ENB                    => SBIF_TX_ENB_IN(2)                      ,--: in  std_logic;
--            O_TX_I                      => SBIF_TX_I_OUT(2)                       ,--: out std_logic_vector(15 downto 0);
--            O_TX_Q                      => SBIF_TX_Q_OUT(2)                       ,--: out std_logic_vector(15 downto 0);
--
--            O_RX_10MS                   => rx_10ms(2)                             ,--: out std_logic;
--            O_RX_BFN                    => rx_bfn(2)                              ,--: out std_logic_vector(11 downto 0);
--            O_RX_TDD                    => rx_tdd(2)                              ,--: out std_logic;
--            O_RX_SYNC                   => rx_sync(2)                             ,--: out std_logic;
--            O_RX_DATA_I                 => rx_data_i(2)                           ,--: out std_logic_vector(15 downto 0);
--            O_RX_DATA_Q                 => rx_data_q(2)                           ,--: out std_logic_vector(15 downto 0);
--                                                   
--            I_TX_10MS                   => tx_10ms(2)                             ,--: in  std_logic;
--            I_TX_TDD                    => tx_tdd(2)                              ,--: in  std_logic;
--            O_TX_SYNC                   => tx_sync(2)                             ,--: out std_logic;
--            I_TX_DATA_I                 => tx_data_i(2)                           ,--: in  std_logic_vector(15 downto 0);
--            I_TX_DATA_Q                 => tx_data_q(2)                            --: in  std_logic_vector(15 downto 0)
--        );

    -- emulator thay cho U_SBIF_IF (Z1_sim/Env/emu_out_BIT_CONV.v)
    U_SBIF_IF : emu_out_BIT_CONV
    port map(
        clk                         => CLK_SYSX8                              ,--: in  std_logic;
        rst                         => RST_BBCTRL                             ,--: in  std_logic;

        O_RX_10MS                   => rx_10ms(2)                             ,--: out std_logic;
        O_RX_TDD                    => rx_tdd(2)                              ,--: out std_logic;
        O_RX_SYNC                   => rx_sync(2)                             ,--: out std_logic;
        O_RX_DATA_I                 => rx_data_i(2)                           ,--: out std_logic_vector(15 downto 0);
        O_RX_DATA_Q                 => rx_data_q(2)                            --: out std_logic_vector(15 downto 0)
    );



        

    U_LTE_1MS_TP : LTE_ETM_1MS_TP_2CC
    port map(
        RST                         => RST_BBCTRL                             ,--: in  std_logic;
        WCLK                        => CLK_SYSX8                              ,--: in  std_logic;    -- CPUIF_MISC Clock domain
        RCLK                        => CLK_SYSX8                              ,--: in  std_logic;    -- 245.76MHz Clock domain
        
        TP_MEM_PEN                  => tp_mem_pen                             ,--: in  std_logic;    -- A/B port enable
        TP_MEM_AWEN                 => tp_mem_awen                            ,--: in  std_logic_vector(1 downto 0);    -- A port write enable
        TP_MEM_WRADDR               => tp_mem_wraddr                          ,--: in  std_logic_vector(14 downto 0);
        TP_MEM_WRDATA               => tp_mem_wrdata                          ,--: in  std_logic_vector(31 downto 0);  -- 31..16 : I data, 15..0 : Q data

        SYNC                        => dl_fmt_10ms                            ,
        SAMPLE_ENB(0)               => dl_fmt_sync(0)                ,--: in  std_logic_vector(1 downto 0);    -- 0 : CC0(10M), 1 : CC1(15M)
        SAMPLE_ENB(1)               => dl_fmt_sync(1)                ,--: in  std_logic_vector(1 downto 0);    -- 0 : CC0(10M), 1 : CC1(15M)
       
        OFFSET_EN                   => tp_offset_en                           ,
        OFFSET                      => tp_offset                              ,

        TP_OUT                      => dl_tp_out                               --: out std_logic_vector(31 downto 0)
         );

    dl_data_i_sel <= dl_tp_out(31 downto 16) when test_mode(2) = x"4" else rx_data_i(2);
    dl_data_q_sel <= dl_tp_out(15 downto  0) when test_mode(2) = x"4" else rx_data_q(2);

   U_DDUC_MAP_IF : DDUC_MAP_IF 
   port map(
       ARESET                      => RST_BBCTRL                             ,--: in  std_logic;

       CLK_AUX                     => CLK_SYSX8                              ,--: in  std_logic;
       CLK_SYSX8                   => CLK_SYSX8                              ,--: in  std_logic;

       PROCESSING_DELAY_DL         => dl_dduc_if_delay                       ,--: out std_logic_vector(23 downto 0);
       PROCESSING_DELAY_UL         => ul_dduc_if_delay                       ,--: out std_logic_vector(23 downto 0);

       BW_SEL                      => kddi_bw_sel                            ,--: in  std_logic_array4(3 downto 0);
       ANT_SWAP                    => ant_swap                                   ,--: in  std_logic_array4(3 downto 0);

       I_RX_10MS                   => rx_10ms   (2)                          ,--: in  std_logic;
       I_RX_BFN                    => rx_bfn    (2)                          ,--: in  std_logic_vector(11 downto 0);
       I_RX_TDD                    => rx_tdd    (2)                          ,--: in  std_logic;
       I_RX_SYNC                   => rx_sync   (2)                          ,--: in  std_logic;
       I_RX_DATA_I                 => dl_data_i_sel                          ,--: in  std_logic_vector(15 downto 0);
       I_RX_DATA_Q                 => dl_data_q_sel                          ,--: in  std_logic_vector(15 downto 0);

       O_TX_10MS                   => tx_10ms   (2)                          ,--: out std_logic;
       O_TX_TDD                    => tx_tdd    (2)                          ,--: out std_logic;
       I_TX_SYNC                   => tx_sync   (2)                          ,--: in  std_logic;
       O_TX_DATA_I                 => tx_data_i (2)                          ,--: out std_logic_vector(15 downto 0);
       O_TX_DATA_Q                 => tx_data_q (2)                          ,--: out std_logic_vector(15 downto 0);

       O_DL_10MS                   => dl_fmt_10ms                            ,--: out std_logic;
       O_DL_BFN                    => dl_fmt_bfn                             ,--: out std_logic_vector(11 downto 0);
       O_DL_TDD                    => dl_fmt_tdd                             ,--: out std_logic;
       O_DL_SYNC                   => dl_fmt_sync                            ,--: out std_logic_vector(3 downto 0);
       O_DL_DATA                   => dl_fmt_data                            ,--: out std_logic_array16(3 downto 0);
                                              
       I_UL_10MS                   => ul_fmt_10ms(0)                         ,--: in  std_logic;
       I_UL_TDD                    => ul_fmt_tdd (0)                         ,--: in  std_logic;
       I_UL_SYNC                   => kddi_ul_fmt_sync                       ,--: in  std_logic_vector(3 downto 0);
       I_UL_DATA                   => kddi_ul_fmt_data                        --: in  std_logic_array16(3 downto 0)
   );

-- dl_fmt_sync(1) <= dl_fmt_sync(0);

-- sim_OUT_DUC_MAP: entity work.emu_out_DUC_MAP_IF

--     port map(
                    
--    clk           => CLK_SYSX8, 
--    rst           => RST_BBCTRL, 
                 
--    out_10ms_strb => dl_fmt_10ms, 
--    out_10ms      => open,
--    out_ENB       => open, 
--    out_csync     => dl_fmt_sync(0),
               
--    CC0           => dl_fmt_data(0),
--    CC1           => dl_fmt_data(1)
       
--     );


    -- ONLY FOR KDDI RF2225
    kddi_bw_sel(0)                  <= bw_sel(0);
    kddi_bw_sel(1)                  <= bw_sel(2);
    kddi_bw_sel(2)                  <= bw_sel(1);
    kddi_bw_sel(3)                  <= bw_sel(3);

    kddi_dl_fmt_sync(0)             <= dl_fmt_sync(0);
    kddi_dl_fmt_data(0)             <= dl_fmt_data(0);
    kddi_dl_fmt_sync(1)             <= '0';
    kddi_dl_fmt_data(1)             <= (others=>'0');
    kddi_dl_fmt_sync(2)             <= dl_fmt_sync(1);
    kddi_dl_fmt_data(2)             <= dl_fmt_data(1);
    kddi_dl_fmt_sync(3)             <= '0';
    kddi_dl_fmt_data(3)             <= (others=>'0');

    kddi_ul_fmt_sync(0)             <= ul_fmt_sync(0);
    kddi_ul_fmt_data(0)             <= ul_fmt_data(0);
    kddi_ul_fmt_sync(1)             <= ul_fmt_sync(2);
    kddi_ul_fmt_data(1)             <= ul_fmt_data(2);
    kddi_ul_fmt_sync(2)             <= '0';
    kddi_ul_fmt_data(2)             <= (others=>'0');
    kddi_ul_fmt_sync(3)             <= '0';
    kddi_ul_fmt_data(3)             <= (others=>'0');

    u_FMT_GEN : for i in NUM_FMT-1 downto 0 generate
    U_FORMATTER : FORMATTER 
    generic map(
                NUM_ANTENNA                 => 4                                       --: natural := 4                
    )
    port map(
        ARESET                      => RST_BBCTRL                             ,--: in  std_logic;
        CLK                         => CLK_SYSX8                              ,--: in  std_logic;
                                                            
        BW_SEL                      => bw_sel(i)                              ,--: in  std_logic_vector(3 downto 0);
                                                            
        PROCESSING_DELAY_DL         => dl_formatter_delay(i)                  ,--: out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         => ul_formatter_delay(i)                  ,--: out std_logic_vector(23 downto 0);
                                                            
        SSB_OFFSET                  => SSB_OFFSET                             ,--: in  std_logic_vector(3 downto 0);
        DL_DELAY_VALUE              => dl_delay_value(i)                      ,--: in  std_logic_vector(31 downto 0);
        UL_DELAY_VALUE              => ul_delay_value(i)                      ,--: in  std_logic_vector(31 downto 0);
        
        DL_PATH_DELAY_0             => dl_path_delay_0                        ,--: in  std_logic_vector(11 downto 0);
        DL_PATH_DELAY_1             => dl_path_delay_1                        ,--: in  std_logic_vector(11 downto 0);
        DL_PATH_DELAY_2             => dl_path_delay_2                        ,--: in  std_logic_vector(11 downto 0);
        DL_PATH_DELAY_3             => dl_path_delay_3                        ,--: in  std_logic_vector(11 downto 0);
        UL_PATH_DELAY_0             => ul_path_delay_0                        ,--: in  std_logic_vector(11 downto 0);
        UL_PATH_DELAY_1             => ul_path_delay_1                        ,--: in  std_logic_vector(11 downto 0);
        UL_PATH_DELAY_2             => ul_path_delay_2                        ,--: in  std_logic_vector(11 downto 0);
        UL_PATH_DELAY_3             => ul_path_delay_3                        ,--: in  std_logic_vector(11 downto 0);

        DL_10MS                     => dl_fmt_10ms                            ,--: in  std_logic;
        DL_BFN                      => dl_fmt_bfn                             ,--: in  std_logic_vector(11 downto 0);
        DL_TDD                      => dl_fmt_tdd                             ,--: in  std_logic;
        -- DL_SYNC                     => dl_fmt_sync(i)                         ,--: in  std_logic;
        -- DL_DATA                     => dl_fmt_data(i)                         ,--: in  std_logic_vector(15 downto 0);
        DL_SYNC                     => kddi_dl_fmt_sync(i)                    ,--: in  std_logic;
        DL_DATA                     => kddi_dl_fmt_data(i)                    ,--: in  std_logic_vector(15 downto 0);
                                                            
        UL_10MS                     => ul_fmt_10ms(i)                         ,--: out std_logic;
        UL_TDD                      => ul_fmt_tdd(i)                          ,--: out std_logic;
        UL_SYNC                     => ul_fmt_sync(i)                         ,--: out std_logic;
        UL_DATA                     => ul_fmt_data(i)                         ,--: out std_logic_vector(15 downto 0);
                                                            
        DUC_BFN_ABNORMAL            => duc_bfn_abnormal(i)                    ,--: out std_logic;
                                                            
        DUC_AIRTECH                 => DL_AIRTECH_OUT(i)                      ,--: out std_logic_vector(3 downto 0);
        DUC_CHBW                    => DL_CHBW_OUT(i)                         ,--: out std_logic_vector(3 downto 0);
        DUC_40MS                    => duc_40ms(i)                            ,--: out std_logic;
        DUC_10MS                    => duc_10ms(i)                            ,--: out std_logic;
        DUC_BFN                     => duc_bfn(i)                             ,--: out std_logic_vector(11 downto 0);
        DUC_TDD                     => duc_tdd(i)                             ,--: out std_logic;
        DUC_SYNC                    => DL_SYNC_OUT(i)                         ,--: out std_logic;
        DUC_DATA                    => DL_IQ_OUT(i)                           ,--: out std_logic_vector(15 downto 0);
                                                            
        DDC_AIRTECH                 => UL_AIRTECH_OUT(i)                      ,--: out std_logic_vector(3 downto 0);
        DDC_CHBW                    => UL_CHBW_OUT(i)                         ,--: out std_logic_vector(3 downto 0);
        DDC_10MS                    => ddc_10ms(i)                            ,--: in  std_logic;
        DDC_TDD                     => ddc_tdd(i)                             ,--: in  std_logic;
        DDC_SYNC                    => UL_SYNC_IN(i)                          ,--: in  std_logic;
        DDC_DATA                    => UL_IQ_IN(i)                            ,--: in  std_logic_vector(15 downto 0);

        ZRHC_BYPASS                 => zrhc_bypass(i)                         ,--: in  std_logic;
        ZRHC_THRESHOLD              => zrhc_threshold(i)                      ,--: in  std_logic_vector(31 downto 0);
        ZRHC_OCCUR                  => zrhc_occur(i)                          ,--: out std_logic_vector(3 downto 0);
                                                        
        DL_ON                       => dl_on(i)                               ,--: in  std_logic_vector(3 downto 0);
        UL_ON                       => ul_on(i)                               ,--: in  std_logic_vector(3 downto 0);
                                                        
        DL_ATT_0                    => dl_att_0(i)                            ,--: in  std_logic_vector(15 downto 0);
        DL_ATT_1                    => dl_att_1(i)                            ,--: in  std_logic_vector(15 downto 0);
        DL_ATT_2                    => dl_att_2(i)                            ,--: in  std_logic_vector(15 downto 0);
        DL_ATT_3                    => dl_att_3(i)                            ,--: in  std_logic_vector(15 downto 0);
                                                        
        UL_ATT_0                    => ul_att_0(i)                            ,--: in  std_logic_vector(15 downto 0);
        UL_ATT_1                    => ul_att_1(i)                            ,--: in  std_logic_vector(15 downto 0);
        UL_ATT_2                    => ul_att_2(i)                            ,--: in  std_logic_vector(15 downto 0);
        UL_ATT_3                    => ul_att_3(i)                            ,--: in  std_logic_vector(15 downto 0);

        FBSW_CNT                    => FBSW_CNT                               ,--: in  std_logic_vector(3 downto 0);
        FBSW_SSB_IND_FLAG           => FBSW_SSB_IND_FLAG                      ,--: in  std_logic; 
        FBSW_MEAS_UPDATE            => FBSW_MEAS_UPDATE                       ,--: in  std_logic; 

        TSSI_UPDATE_MODE            => tssi_update_mode                       ,--: in  std_logic_vector(1 downto 0);
        TSSI_UPDATE_CNT_0           => tssi_update_cnt_0(i)                   ,--: in  std_logic_vector(4 downto 0);
        TSSI_UPDATE_CNT_1           => tssi_update_cnt_1(i)                   ,--: in  std_logic_vector(4 downto 0);
        TSSI_UPDATE_CNT_2           => tssi_update_cnt_2(i)                   ,--: in  std_logic_vector(4 downto 0);
        TSSI_UPDATE_CNT_3           => tssi_update_cnt_3(i)                   ,--: in  std_logic_vector(4 downto 0);
                                                           
        RSSI_UPDATE_MODE            => rssi_update_mode                       ,--: in  std_logic_vector(1 downto 0);
        RSSI_UPDATE_CNT_0           => rssi_update_cnt_0(i)                   ,--: in  std_logic_vector(4 downto 0);
        RSSI_UPDATE_CNT_1           => rssi_update_cnt_1(i)                   ,--: in  std_logic_vector(4 downto 0);
        RSSI_UPDATE_CNT_2           => rssi_update_cnt_2(i)                   ,--: in  std_logic_vector(4 downto 0);
        RSSI_UPDATE_CNT_3           => rssi_update_cnt_3(i)                   ,--: in  std_logic_vector(4 downto 0);
                                                           
        TSSI_0                      => tssi_0(i)                              ,--: out std_logic_vector(31 downto 0);
        TSSI_1                      => tssi_1(i)                              ,--: out std_logic_vector(31 downto 0);
        TSSI_2                      => tssi_2(i)                              ,--: out std_logic_vector(31 downto 0);
        TSSI_3                      => tssi_3(i)                              ,--: out std_logic_vector(31 downto 0);
                                                           
        RSSI_0                      => rssi_0(i)                              ,--: out std_logic_vector(31 downto 0);
        RSSI_1                      => rssi_1(i)                              ,--: out std_logic_vector(31 downto 0);
        RSSI_2                      => rssi_2(i)                              ,--: out std_logic_vector(31 downto 0);
        RSSI_3                      => rssi_3(i)                              ,--: out std_logic_vector(31 downto 0);
                                                           
        TEST_MODE                   => test_mode(i)                           ,--: in  std_logic_vector(3 downto 0);
                                                           
        TEST_DC_I                   => test_dc_i                              ,--: in  std_logic_vector(15 downto 0);
        TEST_DC_Q                   => test_dc_q                              ,--: in  std_logic_vector(15 downto 0);
        TEST_NCO                    => test_nco                               ,--: in  std_logic_vector(5 downto 0);
                                                           
        DUMP_DL_10MS                => dump_dl_10ms(i)                        ,--: out std_logic;
        DUMP_DL_SYNC                => dump_dl_sync(i)                        ,--: out std_logic;
        DUMP_DL_DATA                => dump_dl_data(i)                        ,--: out std_logic_vector(15 downto 0);
                                                           
        DUMP_UL_10MS                => dump_ul_10ms(i)                        ,--: out std_logic;
        DUMP_UL_SYNC                => dump_ul_sync(i)                        ,--: out std_logic;
        DUMP_UL_DATA                => dump_ul_data(i)                         --: out std_logic_vector(15 downto 0)
    );

    end generate;

end BEHAVE;
