--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : GSM Formatter                                                 --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2021.11.17                                                    --
-- Target     : Max DL 8 ant / UL 16 ant                                      --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;

entity GSM_FORMATTER is
    generic (
        DL_ANT_NUM                  : natural := 8;
        UL_ANT_NUM                  : natural := 16
    );
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        ARESET                      : in  std_logic;

        CLK                         : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        SSB_OFFSET                  : in  std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- dduc_if /gsm_timer
--------------------------------------------------------------------------------

        DL_120MS_SYNC               : in  std_logic;    --add
        DL_TS16_SYNC                : in  std_logic;
        DL_TS_SYNC                  : in  std_logic;
        DL_TS_GP_SYNC               : in  std_logic;
        DL_TS_GP_START              : in  std_logic;

        DL_10MS                     : in  std_logic;
        DL_BFN                      : in  std_logic_vector(11 downto 0);
        DL_TDD                      : in  std_logic;
        DL_SYNC                     : in  std_logic;
        DL_DATA                     : in  std_logic_vector(15 downto 0);

--        UL_10MS                     : out std_logic;
        UL_120MS                    : out std_logic;
        UL_TS_SYNC                  : out std_logic;
        UL_TDD                      : out std_logic;
        UL_SYNC                     : out std_logic;
        UL_DATA                     : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- DDUC Side
--------------------------------------------------------------------------------

        DUC_BFN_ABNORMAL            : out std_logic;

        DUC_120MS_SYNC              : out std_logic;   --add
        DUC_TS16_SYNC               : out std_logic;
        DUC_TS_SYNC                 : out std_logic;
        DUC_TS_GP_SYNC              : out std_logic;

        DUC_AIRTECH                 : out std_logic_vector(3 downto 0);
        DUC_CHBW                    : out std_logic_vector(3 downto 0);
        DUC_40MS                    : out std_logic;
        DUC_10MS                    : out std_logic;
        DUC_BFN                     : out std_logic_vector(11 downto 0);
        DUC_TDD                     : out std_logic;
        DUC_SYNC                    : out std_logic;
        DUC_DATA                    : out std_logic_vector(15 downto 0);

        DDC_120MS_SYNC              : in  std_logic;    --add
        DDC_TS16_SYNC               : in  std_logic;
        DDC_TS_SYNC                 : in  std_logic;
        DDC_TS_GP_SYNC              : in  std_logic;

        DDC_AIRTECH                 : out std_logic_vector(3 downto 0);
        DDC_CHBW                    : out std_logic_vector(3 downto 0);
        DDC_10MS                    : in  std_logic;
        DDC_TDD                     : in  std_logic;
        DDC_SYNC                    : in  std_logic;
        DDC_DATA                    : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- Zero Replacement Hard Clipping
--------------------------------------------------------------------------------

        ZRHC_BYPASS                 : in  std_logic;
        ZRHC_THRESHOLD              : in  std_logic_vector(31 downto 0);
        ZRHC_OCCUR                  : out std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Path on/off and attenuation
--------------------------------------------------------------------------------

        DL_ON                       : in  std_logic_vector(7 downto 0);
        UL_ON                       : in  std_logic_vector(15 downto 0);

        DL_ATT                      : in  std_logic_array20(DL_ANT_NUM-1 downto 0);
        UL_ATT                      : in  std_logic_array20(UL_ANT_NUM-1 downto 0);

--------------------------------------------------------------------------------
-- Power Measure (TSSI/RSSI)
--------------------------------------------------------------------------------

--        FBSW_CNT                    : in  std_logic_vector(3 downto 0);
--        FBSW_SSB_IND_FLAG           : in  std_logic; 
--        FBSW_MEAS_UPDATE            : in  std_logic; 

--        TSSI_UPDATE_MODE            : in  std_logic_vector(1 downto 0);
--        TSSI_UPDATE_CNT             : in  std_logic_array5(DL_ANT_NUM-1 downto 0);
--
--        RSSI_UPDATE_MODE            : in  std_logic_vector(1 downto 0);
--        RSSI_UPDATE_CNT             : in  std_logic_array5(UL_ANT_NUM-1 downto 0);
    
        TSSI_UPDATE_EN              : in  std_logic;

        TSSI                        : out std_logic_array32(DL_ANT_NUM-1 downto 0);
        TSSI_MAX                    : out std_logic_array32(DL_ANT_NUM-1 downto 0);
        RSSI                        : out std_logic_array32(UL_ANT_NUM-1 downto 0);

--------------------------------------------------------------------------------
-- Test pattern
--------------------------------------------------------------------------------

        TEST_MODE                   : in  std_logic_vector(3 downto 0);

        TEST_DC_I                   : in  std_logic_vector(15 downto 0);
        TEST_DC_Q                   : in  std_logic_vector(15 downto 0);
        TEST_NCO                    : in  std_logic_vector(5 downto 0);

--------------------------------------------------------------------------------
-- DUMP
--------------------------------------------------------------------------------

        DUMP_DL_10MS                : out std_logic;
        DUMP_DL_SYNC                : out std_logic;
        DUMP_DL_DATA                : out std_logic_vector(15 downto 0);

        DUMP_UL_10MS                : out std_logic;
        DUMP_UL_SYNC                : out std_logic;
        DUMP_UL_DATA                : out std_logic_vector(15 downto 0)
    );
end GSM_FORMATTER;

architecture BEHAVE of GSM_FORMATTER is

    signal dl_ftc_delay             : std_logic_vector(23 downto 0) := (others => '0');
    signal dl_test_delay            : std_logic_vector(23 downto 0) := (others => '0');
    signal dl_zrhc_delay            : std_logic_vector(23 downto 0) := (others => '0');
    signal dl_att_delay             : std_logic_vector(23 downto 0) := (others => '0');

    signal ul_ftc_delay             : std_logic_vector(23 downto 0) := (others => '0');
    signal ul_att_delay             : std_logic_vector(23 downto 0) := (others => '0');

    signal dl_10ms_in               : std_logic := '0'; 
    signal dl_tdd_in                : std_logic := '0'; 
    signal dl_data_in               : std_logic_vector(15 downto 0) := (others => '0'); 
    signal dl_120ms_sync_in         : std_logic := '0';
    signal dl_ts16_sync_in          : std_logic := '0';
    signal dl_ts_sync_in            : std_logic := '0';
    signal dl_ts_gp_sync_in         : std_logic := '0';
    signal dl_ts_gp_start_in        : std_logic := '0';
    
    signal bfn                      : std_logic_vector(11 downto 0) := (others => '0');

    signal ddc_10ms_sh              : std_logic := '0';
    signal ddc_tdd_sh               : std_logic := '0';
    signal ddc_data_sh              : std_logic_vector(15 downto 0) := (others => '0');

    signal ddc_120ms_sync_sh        : std_logic := '0'; 
    signal ddc_ts16_sync_sh         : std_logic := '0'; 
    signal ddc_ts_sync_sh           : std_logic := '0'; 
    signal ddc_ts_gp_sync_sh        : std_logic := '0'; 

    signal dl_tp_10ms_d1            : std_logic := '0'; 
    signal free_run_bfn             : std_logic_vector(11 downto 0) := (others => '0');
    signal free_run_bfn_r           : std_logic_vector(11 downto 0) := (others => '0');
    signal bfn_abnormal             : std_logic := '0';      
    signal bfn_abnormal_lat         : std_logic := '0';      
    signal bfn_out                  : std_logic_vector(11 downto 0) := (others => '0');
    signal dl_att_10ms_d2           : std_logic := '0'; 

    component RST_SYNC is
    generic (
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port (
        RST_IN                      : in  std_logic;
        CLK                         : in  std_logic;
        RST_OUT                     : out std_logic
    );
    end component;

    signal reset                    : std_logic;

    signal dl_ftc_tdd               : std_logic;
    signal dl_ftc_10ms              : std_logic;
    signal dl_ftc_sync              : std_logic;
    signal dl_ftc_data              : std_logic_vector(15 downto 0);
    signal ul_ftc_tdd               : std_logic;
    signal ul_ftc_10ms              : std_logic;
    signal ul_ftc_sync              : std_logic;
    signal ul_ftc_data              : std_logic_vector(15 downto 0);

    component GSM_TRAFFIC_SELECTION is
    generic (
        NUM_ANTENNA                 : natural := 4
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

        TEST_MODE                   : in  std_logic_vector(3 downto 0);

        TEST_DC_I                   : in  std_logic_vector(15 downto 0);
        TEST_DC_Q                   : in  std_logic_vector(15 downto 0);
        TEST_NCO                    : in  std_logic_vector(5 downto 0);

        TP_IN_120MS_SYNC            : in  std_logic;
        TP_IN_TS16_SYNC             : in  std_logic;
        TP_IN_TS_SYNC               : in  std_logic;
        TP_IN_TS_GP_SYNC            : in  std_logic;

        TP_IN_10MS                  : in  std_logic;
        TP_IN_TDD                   : in  std_logic;
        TP_IN_SYNC                  : in  std_logic;
        TP_IN_DATA                  : in  std_logic_vector(15 downto 0);

        TP_OUT_120MS_SYNC           : out std_logic;
        TP_OUT_TS16_SYNC            : out std_logic;
        TP_OUT_TS_SYNC              : out std_logic;
        TP_OUT_TS_GP_SYNC           : out std_logic;

        TP_OUT_10MS                 : out std_logic;
        TP_OUT_TDD                  : out std_logic;
        TP_OUT_SYNC                 : out std_logic;
        TP_OUT_DATA                 : out std_logic_vector(15 downto 0)
    );
    end component;

    signal dl_tp_120ms_sync         : std_logic := '0';
    signal dl_tp_ts16_sync          : std_logic := '0';
    signal dl_tp_ts_sync            : std_logic := '0';
    signal dl_tp_ts_gp_sync         : std_logic := '0';
    signal dl_tp_ts_gp_start        : std_logic := '0';

    signal dl_tp_10ms               : std_logic := '0';
    signal dl_tp_tdd                : std_logic := '0';
    signal dl_tp_sync               : std_logic := '0';
    signal dl_tp_data               : std_logic_vector(15 downto 0) := (others => '0');

    component GSM_ZRHC is
    generic (
        ANT_NUM                     : natural := 16
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

        ZRHC_BYPASS                 : in  std_logic;
        ZRHC_THRESHOLD              : in  std_logic_vector(31 downto 0);
        ZRHC_OCCUR                  : out std_logic_vector(ANT_NUM-1 downto 0);

        ZRHC_IN_120MS_SYNC          : in  std_logic;
        ZRHC_IN_TS16_SYNC           : in  std_logic;
        ZRHC_IN_TS_SYNC             : in  std_logic;
        ZRHC_IN_TS_GP_SYNC          : in  std_logic;

        ZRHC_IN_10MS                : in  std_logic;
        ZRHC_IN_TDD                 : in  std_logic;
        ZRHC_IN_SYNC                : in  std_logic;
        ZRHC_IN_DATA                : in  std_logic_vector(15 downto 0);

        ZRHC_OUT_120MS_SYNC         : out std_logic;
        ZRHC_OUT_TS16_SYNC          : out std_logic;
        ZRHC_OUT_TS_SYNC            : out std_logic;
        ZRHC_OUT_TS_GP_SYNC         : out std_logic;

        ZRHC_OUT_10MS               : out std_logic;
        ZRHC_OUT_TDD                : out std_logic;
        ZRHC_OUT_SYNC               : out std_logic;
        ZRHC_OUT_DATA               : out std_logic_vector(15 downto 0)
    );
    end component;

    signal dl_zrhc_120ms_sync       : std_logic := '0';
    signal dl_zrhc_ts16_sync        : std_logic := '0';
    signal dl_zrhc_ts_sync          : std_logic := '0';
    signal dl_zrhc_ts_gp_sync       : std_logic := '0';

    signal dl_zrhc_10ms             : std_logic := '0';
    signal dl_zrhc_tdd              : std_logic := '0';
    signal dl_zrhc_sync             : std_logic := '0';
    signal dl_zrhc_data             : std_logic_vector(15 downto 0) := (others => '0');

    component GSM_ATTENUATOR is
    generic (
        ANT_NUM                     : natural := 16;
        RND_WIDTH                   : natural := 20;
        SAT_WIDTH                   : natural := 16
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

        PATH_ON                     : in  std_logic_vector(ANT_NUM-1 downto 0);
        PATH_ATT                    : in  std_logic_array20(ANT_NUM-1 downto 0);

        ATT_IN_120MS_SYNC           : in  std_logic;
        ATT_IN_TS16_SYNC            : in  std_logic;
        ATT_IN_TS_SYNC              : in  std_logic;
        ATT_IN_TS_GP_SYNC           : in  std_logic;

        ATT_IN_10MS                 : in  std_logic;
        ATT_IN_TDD                  : in  std_logic;
        ATT_IN_SYNC                 : in  std_logic;
        ATT_IN_DATA                 : in  std_logic_vector(15 downto 0);

        ATT_OUT_120MS_SYNC          : out std_logic;
        ATT_OUT_TS16_SYNC           : out std_logic;
        ATT_OUT_TS_SYNC             : out std_logic;
        ATT_OUT_TS_GP_SYNC          : out std_logic;

        ATT_OUT_10MS                : out std_logic;
        ATT_OUT_TDD                 : out std_logic;
        ATT_OUT_SYNC                : out std_logic;
        ATT_OUT_DATA                : out std_logic_vector(SAT_WIDTH-1 downto 0)
    );
    end component;
 
    signal dl_att_120ms_sync_out    : std_logic := '0';
    signal dl_att_ts16_sync_out     : std_logic := '0';
    signal dl_att_ts_sync_out       : std_logic := '0';
    signal dl_att_ts_gp_sync_out    : std_logic := '0';
    
    signal dl_att_10ms_out          : std_logic := '0';
    signal dl_att_tdd_out           : std_logic := '0';
    signal dl_att_sync_out          : std_logic := '0';
    signal dl_att_data_out          : std_logic_vector(15 downto 0) := (others => '0');

    signal dl_att_120ms_sync        : std_logic_vector(1 downto 0) := (others => '0');
    signal dl_att_ts16_sync         : std_logic_vector(1 downto 0) := (others => '0');
    signal dl_att_ts_sync           : std_logic_vector(1 downto 0) := (others => '0');
    signal dl_att_ts_gp_sync        : std_logic_vector(1 downto 0) := (others => '0');
    
    signal dl_att_10ms              : std_logic_vector(1 downto 0) := (others => '0');
    signal dl_att_tdd               : std_logic_vector(1 downto 0) := (others => '0');
    signal dl_att_sync              : std_logic_vector(2 downto 0) := (others => '0');
    signal dl_att_data              : std_logic_array16(1 downto 0) := (others => (others => '0'));

    signal ul_att_120ms_sync_out    : std_logic := '0';
    signal ul_att_120ms_sync_out_d  : std_logic := '0';
    signal ul_att_ts16_sync_out     : std_logic := '0';
    signal ul_att_ts_sync_out       : std_logic := '0';
    signal ul_att_ts_gp_sync_out    : std_logic := '0';
    
    signal ul_att_10ms              : std_logic := '0';
    signal ul_att_tdd               : std_logic := '0';
    signal ul_att_sync              : std_logic := '0';
    signal ul_att_sync_d            : std_logic := '0';
    signal ul_att_data              : std_logic_vector(15 downto 0) := (others => '0');

    component PATH_ON is
    generic (
        ANT_NUM                     : natural := 4
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

        PATH_ON                     : in  std_logic_vector(ANT_NUM-1 downto 0);

        IN_10MS                     : in  std_logic;
        IN_TDD                      : in  std_logic;
        IN_SYNC                     : in  std_logic;
        IN_DATA                     : in  std_logic_vector(15 downto 0);

        OUT_10MS                    : out std_logic;
        OUT_TDD                     : out std_logic;
        OUT_SYNC                    : out std_logic;
        OUT_DATA                    : out std_logic_vector(15 downto 0)
    );
    end component;
    
    signal ul_out_10ms              : std_logic := '0';
    signal ul_out_120ms             : std_logic := '0';
    signal ul_out_tdd               : std_logic := '0';
    signal ul_out_sync              : std_logic := '0';
    signal ul_out_sync_d            : std_logic := '0';
    signal ul_out_data              : std_logic_vector(15 downto 0) := (others => '0');

    component GSM_TSSI is
    generic (
        ANT_NUM                     : natural := 8
    );
    port (
        RESET                       : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

		I_120MS_SYNC                : in  std_logic;
        I_TS16_SYNC                 : in  std_logic;    
        I_TS_SYNC                   : in  std_logic;    

        I_UPDATE_EN                 : in  std_logic;

        I_DATA_SYNC                 : in  std_logic;   
        I_DATA_IQ                   : in  std_logic_vector(15 downto 0);

        O_TSSI                      : out std_logic_array32(ANT_NUM-1 downto 0);
		O_TSSI_MAX                  : out std_logic_array32(ANT_NUM-1 downto 0)
    );
    end component;

    signal tssi_out                 : std_logic_array32(DL_ANT_NUM-1 downto 0) := (others => (others => '0'));
    signal tssi_max_out             : std_logic_array32(DL_ANT_NUM-1 downto 0) := (others => (others => '0'));

    component GSM_RSSI is
    generic (
        ANT_NUM                     : natural := 8
    );
    port (
        RESET                       : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        I_TS16_SYNC                 : in  std_logic;    
        I_TS_SYNC                   : in  std_logic;    

        I_DATA_SYNC                 : in  std_logic;   
        I_DATA_IQ                   : in  std_logic_vector(15 downto 0);

        O_RSSI                      : out std_logic_array32(ANT_NUM-1 downto 0)
    );
    end component;

    signal rssi_out                 : std_logic_array32(UL_ANT_NUM-1 downto 0) := (others => (others => '0'));

begin

    PROCESSING_DELAY_DL <= dl_ftc_delay + dl_test_delay + dl_zrhc_delay + dl_att_delay + 2;
    PROCESSING_DELAY_UL <= ul_ftc_delay + ul_att_delay + 2;

    -- input Buffering
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            dl_10ms_in        <= DL_10MS; 
            dl_tdd_in         <= DL_TDD ; 
            dl_data_in        <= DL_DATA; 
            dl_120ms_sync_in  <= DL_120MS_SYNC  ; 
            dl_ts16_sync_in   <= DL_TS16_SYNC   ; 
            dl_ts_sync_in     <= DL_TS_SYNC     ; 
            dl_ts_gp_sync_in  <= DL_TS_GP_SYNC  ; 
            dl_ts_gp_start_in <= DL_TS_GP_START ; 
        end if;
    end process;

    -- output Buffering
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            dl_att_10ms <= dl_att_10ms(0) & dl_att_10ms_out;
            dl_att_tdd  <= dl_att_tdd (0) & dl_att_tdd_out;
            dl_att_sync <= dl_att_sync(1 downto 0) & dl_att_sync_out;
            dl_att_data <= dl_att_data(0) & dl_att_data_out;
            dl_tp_10ms_d1 <= dl_tp_10ms;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            dl_att_120ms_sync <= dl_att_120ms_sync(0) & dl_att_120ms_sync_out ;  
            dl_att_ts16_sync  <= dl_att_ts16_sync (0) & dl_att_ts16_sync_out ;  
            dl_att_ts_sync    <= dl_att_ts_sync   (0) & dl_att_ts_sync_out   ; 
            dl_att_ts_gp_sync <= dl_att_ts_gp_sync(0) & dl_att_ts_gp_sync_out; 
        end if;
    end process;


    -- DUC (BFN, 40ms)
    process (reset, CLK)
    begin
        if (reset = '1') then
            DUC_BFN_ABNORMAL <= '1';
            bfn              <= (others => '0');
            DUC_40MS         <= '0';
            bfn_abnormal     <= '1';
        elsif (CLK'event and CLK = '1') then
            if (dl_att_10ms(0) = '0' and dl_att_10ms_out = '1') then
                if (bfn = DL_BFN-1) then
                    DUC_BFN_ABNORMAL <= '0';
                    bfn_abnormal     <= '0';
                else
                    DUC_BFN_ABNORMAL <= '1';
                    bfn_abnormal     <= '1';
                end if;
            end if;
            if (dl_att_10ms(0) = '0' and dl_att_10ms_out = '1') then
                bfn              <= DL_BFN;
            end if;
            if (bfn_out(1 downto 0) = SSB_OFFSET(1 downto 0)) then
                DUC_40MS         <= dl_att_10ms(1);
            else
                DUC_40MS         <= '0';
            end if;
        end if;
    end process;

    process (reset, CLK)
    begin
        if (reset = '1') then
            bfn_out              <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            if (bfn_abnormal = '1') then
                bfn_out         <= free_run_bfn_r;
            else
                bfn_out         <= bfn;
            end if;
                DUC_BFN          <= bfn_out;
        end if;
    end process;


    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if(bfn_abnormal = '1') then
                bfn_abnormal_lat <= '1';
            end if;
        end if;
    end process;          


    -- bfn free running
    process (reset, CLK)
    begin
        if (reset = '1') then
            free_run_bfn     <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            if (bfn_abnormal_lat = '1') then
                if ((dl_tp_10ms and (not dl_tp_10ms_d1)) = '1') then
                    if (free_run_bfn = 4095) then
                        free_run_bfn <= (others => '0');
                    else
                        free_run_bfn <= free_run_bfn + 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    --free run BFN retiming
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (dl_att_10ms(0) = '0' and dl_att_10ms_out = '1') then
                free_run_bfn_r <= free_run_bfn;
            end if;
        end if;
    end process;


    -- DUC
    process (reset, CLK)
    begin
        if (reset = '1') then
            DUC_AIRTECH     <= (others => '0');
            DUC_CHBW        <= (others => '0');
            DUC_10MS        <= '0';
            DUC_TDD         <= '0';
            DUC_SYNC        <= '0';
            DUC_DATA        <= (others => '0');
            DUC_TS16_SYNC   <= '0'; 
            DUC_TS_SYNC     <= '0'; 
            DUC_TS_GP_SYNC  <= '0'; 
        elsif (CLK'event and CLK = '1') then
            DUC_AIRTECH     <= (others => '0');
            DUC_CHBW        <= (others => '0');
            DUC_10MS        <= dl_att_10ms(1);
            DUC_TDD         <= dl_att_tdd(1);
            DUC_SYNC        <= dl_att_sync(2);
            DUC_DATA        <= dl_att_data(1);
            DUC_120MS_SYNC  <= dl_att_120ms_sync(1);  
            DUC_TS16_SYNC   <= dl_att_ts16_sync(1);  
            DUC_TS_SYNC     <= dl_att_ts_sync(1);  
            DUC_TS_GP_SYNC  <= dl_att_ts_gp_sync(1);  
        end if;
    end process;

    -- DDC
    process (reset, CLK)
    begin
        if (reset = '1') then
            DDC_AIRTECH <= (others => '0');
            DDC_CHBW    <= (others => '0');
            ddc_10ms_sh <= '0';
            ddc_tdd_sh  <= '0';
            ddc_data_sh <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            DDC_AIRTECH <= (others => '0');
            DDC_CHBW    <= (others => '0');
            ddc_10ms_sh <= DDC_10MS;
            ddc_tdd_sh  <= DDC_TDD;
            ddc_data_sh <= DDC_DATA;
            ddc_120ms_sync_sh <= DDC_120MS_SYNC;    
            ddc_ts16_sync_sh  <= DDC_TS16_SYNC;    
            ddc_ts_sync_sh    <= DDC_TS_SYNC;    
            ddc_ts_gp_sync_sh <= DDC_TS_GP_SYNC; 
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            ul_att_120ms_sync_out_d <= ul_att_120ms_sync_out;
            ul_out_120ms <= ul_att_120ms_sync_out_d;
        end if; 
    end process;

    -- Mapper output
    process (reset, CLK)
    begin
        if (reset = '1') then
--            UL_10MS <= '0';
            UL_TDD  <= '0';
            UL_SYNC <= '0';
            UL_DATA <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            ul_out_sync_d <= ul_out_sync;  
--            UL_10MS       <= ul_out_10ms;  
            UL_120MS      <= ul_out_120ms;  
            UL_TDD        <= ul_out_tdd ;  
            UL_SYNC       <= ul_out_sync_d;  
            UL_DATA       <= ul_out_data;  
        end if;
    end process;

    TSSI     <= tssi_out; 
    TSSI_MAX <= tssi_max_out; 
    RSSI     <= rssi_out; 

    -- Dump
    DUMP_DL_10MS <= dl_zrhc_120ms_sync;
    DUMP_DL_SYNC <= dl_zrhc_sync;
    DUMP_DL_DATA <= dl_zrhc_data;

    DUMP_UL_10MS <= DDC_120MS_SYNC;
    DUMP_UL_SYNC <= DDC_SYNC;
    DUMP_UL_DATA <= DDC_DATA;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_RESET : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => ARESET                                  ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;
        RST_OUT                     => reset                                    --: out std_logic
    );

--------------------------------------------------------------------------------
-- DL component mapping
--------------------------------------------------------------------------------

    u_GSM_TRAFFIC_SELECTION : GSM_TRAFFIC_SELECTION
    generic map(
        NUM_ANTENNA                 => 8 --NUM_ANTENNA                              --: natural := 4
    )
    port map(
        RESET                       => reset                                   ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;

        PROCESSING_DELAY            => dl_test_delay                           ,--: out std_logic_vector(23 downto 0);

        TEST_MODE                   => TEST_MODE                               ,--: in  std_logic_vector(3 downto 0);

        TEST_DC_I                   => TEST_DC_I                               ,--: in  std_logic_vector(15 downto 0);
        TEST_DC_Q                   => TEST_DC_Q                               ,--: in  std_logic_vector(15 downto 0);
        TEST_NCO                    => TEST_NCO                                ,--: in  std_logic_vector(5 downto 0);

        TP_IN_120MS_SYNC            => dl_120ms_sync_in                        ,--: in  std_logic;
        TP_IN_TS16_SYNC             => dl_ts16_sync_in                         ,--: in  std_logic;
        TP_IN_TS_SYNC               => dl_ts_sync_in                           ,--: in  std_logic;
        TP_IN_TS_GP_SYNC            => dl_ts_gp_sync_in                        ,--: in  std_logic;

        TP_IN_10MS                  => dl_10ms_in                              ,--: in  std_logic;
        TP_IN_TDD                   => dl_tdd_in                               ,--: in  std_logic;
        TP_IN_SYNC                  => DL_SYNC                                 ,--: in  std_logic;
        TP_IN_DATA                  => dl_data_in                              ,--: in  std_logic_vector(15 downto 0);

        TP_OUT_120MS_SYNC           => dl_tp_120ms_sync                        ,--: out std_logic;
        TP_OUT_TS16_SYNC            => dl_tp_ts16_sync                         ,--: out std_logic;
        TP_OUT_TS_SYNC              => dl_tp_ts_sync                           ,--: out std_logic;
        TP_OUT_TS_GP_SYNC           => dl_tp_ts_gp_sync                        ,--: out std_logic;

        TP_OUT_10MS                 => dl_tp_10ms                              ,--: out std_logic;
        TP_OUT_TDD                  => dl_tp_tdd                               ,--: out std_logic;
        TP_OUT_SYNC                 => dl_tp_sync                              ,--: out std_logic;
        TP_OUT_DATA                 => dl_tp_data                               --: out std_logic_vector(15 downto 0)
    );

    U_GSM_ZRHC : GSM_ZRHC 
    generic map(
        ANT_NUM                     => DL_ANT_NUM                               --: natural := 16
    )
    port map(
        RESET                       => reset                                   ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;

        PROCESSING_DELAY            => dl_zrhc_delay                           ,--: out std_logic_vector(23 downto 0);

        ZRHC_BYPASS                 => ZRHC_BYPASS                             ,--: in  std_logic;
        ZRHC_THRESHOLD              => ZRHC_THRESHOLD                          ,--: in  std_logic_vector(31 downto 0);
        ZRHC_OCCUR                  => ZRHC_OCCUR                              ,--: out std_logic_vector(ANT_NUM-1 downto 0);

        ZRHC_IN_120MS_SYNC          => dl_tp_120ms_sync                        ,--: in  std_logic;
        ZRHC_IN_TS16_SYNC           => dl_tp_ts16_sync                         ,--: in  std_logic;
        ZRHC_IN_TS_SYNC             => dl_tp_ts_sync                           ,--: in  std_logic;
        ZRHC_IN_TS_GP_SYNC          => dl_tp_ts_gp_sync                        ,--: in  std_logic;

        ZRHC_IN_10MS                => dl_tp_10ms                              ,--: in  std_logic;
        ZRHC_IN_TDD                 => dl_tp_tdd                               ,--: in  std_logic;
        ZRHC_IN_SYNC                => dl_tp_sync                              ,--: in  std_logic;
        ZRHC_IN_DATA                => dl_tp_data                              ,--: in  std_logic_vector(15 downto 0);

        ZRHC_OUT_120MS_SYNC         => dl_zrhc_120ms_sync                      ,--: out std_logic;
        ZRHC_OUT_TS16_SYNC          => dl_zrhc_ts16_sync                       ,--: out std_logic;
        ZRHC_OUT_TS_SYNC            => dl_zrhc_ts_sync                         ,--: out std_logic;
        ZRHC_OUT_TS_GP_SYNC         => dl_zrhc_ts_gp_sync                      ,--: out std_logic;

        ZRHC_OUT_10MS               => dl_zrhc_10ms                            ,--: out std_logic;
        ZRHC_OUT_TDD                => dl_zrhc_tdd                             ,--: out std_logic;
        ZRHC_OUT_SYNC               => dl_zrhc_sync                            ,--: out std_logic;
        ZRHC_OUT_DATA               => dl_zrhc_data                             --: out std_logic_vector(15 downto 0)
  );
    
    U_GSM_DL_ATT : GSM_ATTENUATOR 
    generic map(
        ANT_NUM                     => DL_ANT_NUM                              ,--: natural := 16;
        RND_WIDTH                   => 22                                      ,--: natural := 20;
        SAT_WIDTH                   => 16                                       --: natural := 16
    )
    port map(
        RESET                       => reset                                   ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;

        PROCESSING_DELAY            => dl_att_delay                            ,--: out std_logic_vector(23 downto 0);

        PATH_ON                     => DL_ON                                   ,--: in  std_logic_vector(ANT_NUM-1 downto 0);
        PATH_ATT                    => DL_ATT                                  ,--: in  std_logic_array20(ANT_NUM-1 downto 0);

        ATT_IN_120MS_SYNC           => dl_zrhc_120ms_sync                      ,--: in  std_logic;
        ATT_IN_TS16_SYNC            => dl_zrhc_ts16_sync                       ,--: in  std_logic;
        ATT_IN_TS_SYNC              => dl_zrhc_ts_sync                         ,--: in  std_logic;
        ATT_IN_TS_GP_SYNC           => dl_zrhc_ts_gp_sync                      ,--: in  std_logic;

        ATT_IN_10MS                 => dl_zrhc_10ms                            ,--: in  std_logic;
        ATT_IN_TDD                  => dl_zrhc_tdd                             ,--: in  std_logic;
        ATT_IN_SYNC                 => dl_zrhc_sync                            ,--: in  std_logic;
        ATT_IN_DATA                 => dl_zrhc_data                            ,--: in  std_logic_vector(15 downto 0);

        ATT_OUT_120MS_SYNC          => dl_att_120ms_sync_out                   ,--: out std_logic;
        ATT_OUT_TS16_SYNC           => dl_att_ts16_sync_out                    ,--: out std_logic;
        ATT_OUT_TS_SYNC             => dl_att_ts_sync_out                      ,--: out std_logic;
        ATT_OUT_TS_GP_SYNC          => dl_att_ts_gp_sync_out                   ,--: out std_logic;

        ATT_OUT_10MS                => dl_att_10ms_out                         ,--: out std_logic;
        ATT_OUT_TDD                 => dl_att_tdd_out                          ,--: out std_logic;
        ATT_OUT_SYNC                => dl_att_sync_out                         ,--: out std_logic;
        ATT_OUT_DATA                => dl_att_data_out                          --: out std_logic_vector(SAT_WIDTH-1 downto 0)
    );

----------------------------------------------------------------------------------
---- UL component mapping
----------------------------------------------------------------------------------

    U_GSM_UL_ATT : GSM_ATTENUATOR 
    generic map(
        ANT_NUM                     => UL_ANT_NUM                              ,--: natural := 16;
        RND_WIDTH                   => 22                                      ,--: natural := 20;
        SAT_WIDTH                   => 16                                       --: natural := 16
    )
    port map(
        RESET                       => reset                                   ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;

        PROCESSING_DELAY            => ul_att_delay                            ,--: out std_logic_vector(23 downto 0);

        PATH_ON                     => (others => '1')                         ,--: in  std_logic_vector(ANT_NUM-1 downto 0);
        PATH_ATT                    => UL_ATT                                  ,--: in  std_logic_array20(ANT_NUM-1 downto 0);

        ATT_IN_120MS_SYNC           => ddc_120ms_sync_sh                       ,--: in  std_logic;
        ATT_IN_TS16_SYNC            => ddc_ts16_sync_sh                        ,--: in  std_logic;
        ATT_IN_TS_SYNC              => ddc_ts_sync_sh                          ,--: in  std_logic;
        ATT_IN_TS_GP_SYNC           => ddc_ts_gp_sync_sh                       ,--: in  std_logic;

        ATT_IN_10MS                 => ddc_10ms_sh                             ,--: in  std_logic;
        ATT_IN_TDD                  => ddc_tdd_sh                              ,--: in  std_logic;
        ATT_IN_SYNC                 => DDC_SYNC                                ,--: in  std_logic;
        ATT_IN_DATA                 => ddc_data_sh                             ,--: in  std_logic_vector(15 downto 0);

        ATT_OUT_120MS_SYNC          => ul_att_120ms_sync_out                   ,--: out std_logic;
        ATT_OUT_TS16_SYNC           => ul_att_ts16_sync_out                    ,--: out std_logic;
        ATT_OUT_TS_SYNC             => ul_att_ts_sync_out                      ,--: out std_logic;
        ATT_OUT_TS_GP_SYNC          => ul_att_ts_gp_sync_out                   ,--: out std_logic;

        ATT_OUT_10MS                => ul_att_10ms                             ,--: out std_logic;
        ATT_OUT_TDD                 => ul_att_tdd                              ,--: out std_logic;
        ATT_OUT_SYNC                => ul_att_sync                             ,--: out std_logic;
        ATT_OUT_DATA                => ul_att_data                              --: out std_logic_vector(SAT_WIDTH-1 downto 0)
    );

    U_GSM_UL_PATH_ONOFF : PATH_ON 
    generic map(
        ANT_NUM                     => 16                                       --: natural := 4
    )
    port map(
        RESET                       => reset                                   ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;

        PROCESSING_DELAY            => open                                    ,--: out std_logic_vector(23 downto 0);

        PATH_ON                     => UL_ON                                   ,--: in  std_logic_vector(ANT_NUM-1 downto 0);

        IN_10MS                     => ul_att_10ms                             ,--: in  std_logic;
        IN_TDD                      => ul_att_tdd                              ,--: in  std_logic;
        IN_SYNC                     => ul_att_sync                             ,--: in  std_logic;
        IN_DATA                     => ul_att_data                             ,--: in  std_logic_vector(15 downto 0);

        OUT_10MS                    => ul_out_10ms                             ,--: out std_logic;
        OUT_TDD                     => ul_out_tdd                              ,--: out std_logic;
        OUT_SYNC                    => ul_out_sync                             ,--: out std_logic;
        OUT_DATA                    => ul_out_data                              --: out std_logic_vector(15 downto 0)
    );
    
--------------------------------------------------------------------------------
-- Power measurement component mapping
--------------------------------------------------------------------------------
    
    U_GSM_TSSI : GSM_TSSI 
    generic map(
        ANT_NUM                     => DL_ANT_NUM                               --: natural := 8
    )
    port map(
        RESET                       => reset                                   ,--: in  std_logic;
        CLK_SYSX8                   => CLK                                     ,--: in  std_logic;


        I_120MS_SYNC                => dl_tp_120ms_sync                        ,--: in  std_logic;
        I_TS16_SYNC                 => dl_tp_ts16_sync                         ,--: in  std_logic;    
        I_TS_SYNC                   => dl_tp_ts_sync                           ,--: in  std_logic;    

        I_UPDATE_EN                 => TSSI_UPDATE_EN                          ,--: in  std_logic;

        I_DATA_SYNC                 => dl_tp_sync                              ,--: in  std_logic;   
        I_DATA_IQ                   => dl_tp_data                              ,--: in  std_logic_vector(15 downto 0);

        O_TSSI                      => tssi_out                                ,--: out std_logic_array32(ANT_NUM-1 downto 0)
		O_TSSI_MAX                  => tssi_max_out                             --: out std_logic_array32(ANT_NUM-1 downto 0)
 
    );

    U_GSM_RSSI : GSM_RSSI 
    generic map(
        ANT_NUM                     => UL_ANT_NUM                               --: natural := 8
    )
    port map(
        RESET                       => reset                                   ,--: in  std_logic;
        CLK_SYSX8                   => CLK                                     ,--: in  std_logic;

        I_TS16_SYNC                 => ul_att_ts16_sync_out                    ,--: in  std_logic;    
        I_TS_SYNC                   => ul_att_ts_sync_out                      ,--: in  std_logic;    

        I_DATA_SYNC                 => ul_att_sync                             ,--: in  std_logic;   
        I_DATA_IQ                   => ul_att_data                             ,--: in  std_logic_vector(15 downto 0);

        O_RSSI                      => rssi_out                                 --: out std_logic_array32(ANT_NUM-1 downto 0)
    );

end BEHAVE;
