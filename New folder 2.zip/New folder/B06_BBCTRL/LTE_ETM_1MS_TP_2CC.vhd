
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;
use WORK.RU_FPGA_FNC.ALL;

Entity LTE_ETM_1MS_TP_2CC  is
   port (
          RST                  : in  std_logic;
          WCLK                 : in  std_logic;    -- CPUIF_MISC Clock domain
          RCLK                 : in  std_logic;    -- 245.76MHz Clock domain

          TP_MEM_PEN           : in  std_logic;    -- A/B port enable
          TP_MEM_AWEN          : in  std_logic_vector(1 downto 0);    -- A port write enable, 0 : CC0(10M), 1 : CC1(15M)
          TP_MEM_WRADDR        : in  std_logic_vector(14 downto 0);
          TP_MEM_WRDATA        : in  std_logic_vector(31 downto 0);  -- 31..16 : I data, 15..0 : Q data

          SYNC                 : in  std_logic;
          SAMPLE_ENB           : in  std_logic_vector(1 downto 0);    -- Sample period tick, activated only 1 cpri core clock per sample, 0 : CC0(10M), 1 : CC1(15M)

          OFFSET_EN            : in  std_logic;
          OFFSET               : in  std_logic_vector(14 downto 0);

          TP_OUT               : out std_logic_vector(31 downto 0)
         );
end LTE_ETM_1MS_TP_2CC;

architecture arc_LTE_ETM_1MS_TP_2CC of LTE_ETM_1MS_TP_2CC is

component opt7_buf
generic(
    BUF_STYLE                   : string  := "BLOCK";--"DISTRIBUTED","BLOCK","ultra","M20K"
    BUFF_DEPTH                  : integer := 8192;
    WIDTH_IN                    : integer := 1
);
port(
    WCLK                        : in  std_logic;
    RCLK                        : in  std_logic;
    WE                          : in  std_logic;
    ENB                         : in  std_logic;
    WADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    RADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_IN                     : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_OUT                    : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end component;

component LTE_10M_TP_BRAM is
  Port (
    clka : in STD_LOGIC;
    ena : in STD_LOGIC;
    wea : in STD_LOGIC_VECTOR ( 0 to 0 );
    addra : in STD_LOGIC_VECTOR ( 14 downto 0 );
    dina : in STD_LOGIC_VECTOR ( 31 downto 0 );
    clkb : in STD_LOGIC;
    enb : in STD_LOGIC;
    addrb : in STD_LOGIC_VECTOR ( 14 downto 0 );
    doutb : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );
end component;

component LTE_15M_TP_BRAM is
  Port (
    clka : in STD_LOGIC;
    ena : in STD_LOGIC;
    wea : in STD_LOGIC_VECTOR ( 0 to 0 );
    addra : in STD_LOGIC_VECTOR ( 14 downto 0 );
    dina : in STD_LOGIC_VECTOR ( 31 downto 0 );
    clkb : in STD_LOGIC;
    enb : in STD_LOGIC;
    addrb : in STD_LOGIC_VECTOR ( 14 downto 0 );
    doutb : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );
end component;

component RST_SYNC
    generic (
        DLY_NUM        : natural := 4;    -- Number of delay.
        MAX_FANOUT_NUM : integer := 200   -- Number of maximum fanout
    );
    port (
        RST_IN  : in  std_logic;          -- Active high asynchronous reset
        CLK     : in  std_logic;          -- clock to be sync'ed to
        RST_OUT : out std_logic           -- "Synchronised" reset signal
    );
end component;

signal reset                   : std_logic;
signal rd_addr0                 : std_logic_vector(14 downto 0);
signal rd_addr1                 : std_logic_vector(14 downto 0);
signal rd_addr0_d               : std_logic_array15(2 downto 0);
signal rd_addr1_d               : std_logic_array15(2 downto 0);
--signal rd_addr_d                : std_logic_vector(14 downto 0);
--signal rd_addr_dd               : std_logic_vector(14 downto 0);
signal rd_out_data0             : std_logic_vector(31 downto 0);
signal rd_out_data1             : std_logic_vector(31 downto 0);

signal cnt_csync                : std_logic_vector(5 downto 0) := (others => '0');

signal sync_d                   : std_logic_vector(1 downto 0);
signal offset_en_d              : std_logic_vector(1 downto 0);

signal offset_d                 : std_logic_vector(14 downto 0);

signal init_sync                : std_logic;

begin

u_RESET : RST_SYNC
generic map(
    DLY_NUM                     => 4                                       ,--: natural := 4;
    MAX_FANOUT_NUM              => 200                                      --: integer := 200
)
port map(
    RST_IN                      => RST                                     ,--: in  std_logic;
    CLK                         => RCLK                                    ,--: in  std_logic;
    RST_OUT                     => reset                                    --: out std_logic
);

u_tp_mem0 : LTE_10M_TP_BRAM
  Port map(
    clka                        => WCLK                 ,--: in STD_LOGIC;
    ena                         => '1'                  ,--: in STD_LOGIC;
    wea(0)                      => TP_MEM_AWEN(0)       ,--: in STD_LOGIC_VECTOR ( 0 to 0 );
    addra                       => TP_MEM_WRADDR        ,--: in STD_LOGIC_VECTOR ( 14 downto 0 );
    dina                        => TP_MEM_WRDATA        ,--: in STD_LOGIC_VECTOR ( 31 downto 0 );
    clkb                        => RCLK                 ,--: in STD_LOGIC;
    enb                         => TP_MEM_PEN           ,--: in STD_LOGIC;
    addrb                       => rd_addr0_d(2)          ,--: in STD_LOGIC_VECTOR ( 14 downto 0 );
    doutb                       => rd_out_data0          --: out STD_LOGIC_VECTOR ( 31 downto 0 )
  );

u_tp_mem1 : LTE_15M_TP_BRAM
  Port map(
    clka                        => WCLK                 ,--: in STD_LOGIC;
    ena                         => '1'                  ,--: in STD_LOGIC;
    wea(0)                      => TP_MEM_AWEN(1)       ,--: in STD_LOGIC_VECTOR ( 0 to 0 );
    addra                       => TP_MEM_WRADDR        ,--: in STD_LOGIC_VECTOR ( 14 downto 0 );
    dina                        => TP_MEM_WRDATA        ,--: in STD_LOGIC_VECTOR ( 31 downto 0 );
    clkb                        => RCLK                 ,--: in STD_LOGIC;
    enb                         => TP_MEM_PEN           ,--: in STD_LOGIC;
    addrb                       => rd_addr1_d(2)          ,--: in STD_LOGIC_VECTOR ( 14 downto 0 );
    doutb                       => rd_out_data1          --: out STD_LOGIC_VECTOR ( 31 downto 0 )
  );


--u_tp_mem : opt7_buf
--generic map(
--    BUF_STYLE                   => "ultra"          , --: string  := "ultra";--"DISTRIBUTED","BLOCK","ultra","M20K"
--    BUFF_DEPTH                  => 30720            , --: integer := 30720;
--    WIDTH_IN                    => 32                 --: integer := 32
--)
--port map(
--    WCLK                        => WCLK             , --: in  std_logic;
--    RCLK                        => RCLK             , --: in  std_logic;
--    WE                          => TP_MEM_AWEN      , --: in  std_logic;
--    ENB                         => TP_MEM_PEN       , --: in  std_logic;
--    WADDR                       => TP_MEM_WRADDR    , --: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
--    RADDR                       => rd_addr          , --: in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
--    DATA_IN                     => TP_MEM_WRDATA    , --: in  std_logic_vector(WIDTH_IN-1 downto 0);
--    DATA_OUT                    => rd_out_data        --: out std_logic_vector(WIDTH_IN-1 downto 0)
--);

process(reset,RCLK)
begin
    if rising_edge(RCLK) then
        sync_d      <= sync_d(0) & SYNC;
        offset_en_d <= offset_en_d(0) & OFFSET_EN;
        offset_d    <= OFFSET;

        if sync_d(1) = '0' and sync_d(0) = '1' then
            cnt_csync <= conv_std_logic_vector(11, 6);
        else
            cnt_csync <= cnt_csync + '1';
        end if;
    end if;
end process;

process(reset,RCLK)
begin
   if reset = '1' then
      rd_addr0   <= (others => '0');
      rd_addr1   <= (others => '0');
      rd_addr0_d <= (others => (others => '0'));
      rd_addr1_d <= (others => (others => '0'));
      init_sync  <= '1';

   elsif rising_edge(RCLK) then
      if offset_en_d(1) = '0' and offset_en_d(0) = '1' then
          init_sync <= '1';
      elsif init_sync = '1' then
          if sync_d(1) = '0' and sync_d(0) = '1' then
              rd_addr0 <= offset_d;
              rd_addr1 <= offset_d;
              init_sync <= '0';
          end if;
      else
          if SAMPLE_ENB(0) = '1' then
              if rd_addr0 = "111011111111111" then
                 rd_addr0 <= (others => '0');
              else
                 rd_addr0 <= rd_addr0 + '1';
              end if;
          end if;
          if SAMPLE_ENB(1) = '1' then
              if rd_addr1 = "111011111111111" then
                 rd_addr1 <= (others => '0');
              else
                 rd_addr1 <= rd_addr1 + '1';
              end if;
          end if;
      end if;

      rd_addr0_d <= rd_addr0_d(1 downto 0) & rd_addr0;
      rd_addr1_d <= rd_addr1_d(1 downto 0) & rd_addr1;
--      rd_addr_dd <= rd_addr_d;
   end if;
end process;

-- CC0 CC0 CC1 CC1 0 0 0 0
process(reset,RCLK)
begin
   if reset = '1' then
      TP_OUT <= (others => '0');
   elsif rising_edge(RCLK) then
      case cnt_csync(2 downto 0) is
          when "000" | "001" => TP_OUT <= rd_out_data0;
          when "010" | "011" => TP_OUT <= rd_out_data1;
          when others        => TP_OUT <= (others => '0');
      end case;
   end if;
end process;

end arc_LTE_ETM_1MS_TP_2CC;
