--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : GSM_TSSI                                                       --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2021.11.08                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

Library UNISIM;
use UNISIM.vcomponents.all;
library UNIMACRO;
use unimacro.Vcomponents.all;

entity GSM_TSSI is
    generic (
        ANT_NUM                     : natural := 8
    );
    port (
        RESET                       : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

		I_120MS_SYNC                : in  std_logic;
        I_TS16_SYNC                 : in  std_logic;    
        I_TS_SYNC                   : in  std_logic;    -- 1 TS = 2216 or 2208 BF

        I_UPDATE_EN                 : in  std_logic;

        -- input data
        I_DATA_SYNC                 : in  std_logic;   -- chip sync
        I_DATA_IQ                   : in  std_logic_vector(15 downto 0);

        O_TSSI                      : out std_logic_array32(ANT_NUM-1 downto 0);
        O_TSSI_MAX                  : out std_logic_array32(ANT_NUM-1 downto 0)

    );
end GSM_TSSI;

architecture BEHAVE of GSM_TSSI is


    signal clk_cnt             : std_logic_vector(6 downto 0) := (others => '0');

	signal i_120ms_sync_d      : std_logic_vector(2 downto 0) := (others => '0'); 
    signal ts16_sync_d         : std_logic_vector(2 downto 0) := (others => '0'); 
    signal ts_sync_d           : std_logic_vector(2 downto 0) := (others => '0'); 
    signal i_120ms_sync_rpls   : std_logic := '0';
    signal i_120ms_sync_rpls_d : std_logic_vector(2 downto 0) := (others => '0'); 
    signal ts16_sync_rpls      : std_logic := '0'; 
    signal ts_sync_rpls        : std_logic := '0'; 
    signal ts16_cnt_start      : std_logic := '0';
    signal ts_cnt              : std_logic_vector(3 downto 0); 
    signal ts_sync_latch       : std_logic := '0';

    signal data_sync_d         : std_logic_vector( 2 downto 0) := (others => '0'); 
    signal data_iq_d           : std_logic_array16(2 downto 0) := (others => (others => '0')); 

    signal sample_cnt          : std_logic_vector(10 downto 0) := (others => '0');
    signal mult_in_data        : std_logic_vector(15 downto 0) := (others => '0');
    signal data_mult_out       : std_logic_vector(31 downto 0) := (others => '0');
    signal mult_out_42b        : std_logic_vector(41 downto 0) := (others => '0');
    signal sum_pwr             : std_logic_array42(7 downto 0) := (others => (others => '0'));
    signal sum_done            : std_logic_vector( 1 downto 0) := (others => '0');
    signal ts_pwr_accum        : std_logic_array37(7 downto 0) := (others => (others => '0'));
    signal ts_pwr_avg_d        : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal ts_pwr_avg_dd       : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal ts_max              : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal ts_max_latch        : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal ts_check            : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal tssi_for_r          : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal tssi_rev_r          : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal tssi_max_r          : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal update_reg_en_r     : std_logic_vector( 2 downto 0) := (others => '0'); -- update register enable signal from FB path switch control block
    signal sync_480ms_cnt      : std_logic_vector( 1 downto 0) := (others =>'0');
    signal sync_480ms          : std_logic :='0'; 
	signal sync_480ms_d        : std_logic :='0'; 



begin

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then

		    i_120ms_sync_d    <= i_120ms_sync_d(1 downto 0) & I_120MS_SYNC;
            ts16_sync_d       <= ts16_sync_d(1 downto 0)    & I_TS16_SYNC ;
            ts_sync_d         <= ts_sync_d(1 downto 0)      & I_TS_SYNC   ;
            i_120ms_sync_rpls <= I_120MS_SYNC     and (not i_120ms_sync_d(0)); 
            ts16_sync_rpls    <= I_TS16_SYNC      and (not ts16_sync_d(0));
            ts_sync_rpls      <= I_TS_SYNC        and (not ts_sync_d(0)  ); 
            update_reg_en_r   <= update_reg_en_r(1 downto 0) & I_UPDATE_EN;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            data_sync_d <= data_sync_d(1 downto 0) & I_DATA_SYNC;  
            data_iq_d   <= data_iq_d  (1 downto 0) & I_DATA_IQ;   
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (ts_sync_rpls = '1') then
                ts_sync_latch <= '1';
            elsif (data_sync_d(2) = '1') then
                ts_sync_latch <= '0';
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (data_sync_d(2) = '1') then
                clk_cnt <= (others => '0');
            else
                clk_cnt <= clk_cnt + 1;
            end if;
        end if;
    end process;

    -- sample count MAX 1024 
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (data_sync_d(2) = '1') then
                if (ts_sync_latch = '1') then
                    sample_cnt <= (others => '0');
                elsif (sample_cnt > 1024) then
                    sample_cnt <= sample_cnt;
                else
                    sample_cnt <= sample_cnt + 1;
                end if;
            end if;
        end if;
    end process;

    -- multiplier input
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (sample_cnt(10) = '0') then
                mult_in_data <= data_iq_d(2);
            else
                mult_in_data <= (others => '0');
            end if;
        end if;
    end process;

    mult_out_42b <= "0000000000" & data_mult_out;
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            for i in 0 to 7 loop
            if (ts_sync_rpls = '1') then
                sum_pwr(i) <= (others => '0');
            else
                if (clk_cnt(6 downto 1) = i+2) then
                    sum_pwr(i) <= sum_pwr(i) + mult_out_42b;
                else
                    sum_pwr(i) <= sum_pwr(i);
                end if;
            end if;
            end loop;
        end if;
    end process;


    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (sample_cnt(10) = '1') then
                if (sample_cnt = 1024 and clk_cnt = "1000000") then
                    sum_done(0) <= '1';
                else
                    sum_done(0) <= '0';
                end if;
            else
                sum_done(0) <= '0';
            end if;
            sum_done(1) <= sum_done(0);
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            -- 16 timeslot sync generation
            if ts16_sync_rpls = '1' then
                ts16_cnt_start <= '1';
            elsif sum_done = "01" then
                ts16_cnt_start <= '0';
            end if;
            -- start timeslot count at 1st sum done point(in 16TS period)
            if sum_done = "01" then
                if ts16_cnt_start = '1' then
                    ts_cnt <= "0001";
                else
                    ts_cnt <= ts_cnt + 1;
                end if;
            end if;
        end if;
	end process;

    -- Valid TS power sum
    TS_PWR_SUM_G : for i in 0 to 7 generate
	TS_PWR_SUM_GEN : process(RESET,CLK_SYSX8)
	begin
		if RESET = '1' then
            ts_pwr_accum(i)  <= (others => '0'); -- Non-selective Power measure
		elsif CLK_SYSX8 = '1' and CLK_SYSX8'event then
            if ts16_sync_rpls = '1' then  -- init
                ts_pwr_accum(i)  <= (others => '0');
            elsif sum_done = "01" then  -- accumulate 16 Timeslot power
                ts_pwr_accum(i) <= ts_pwr_accum(i) + sum_pwr(i)(41 downto 10);
            end if;
        end if;
		end process;
	end generate;

    -- 16 TS average power update
    OUT_G : for i in 0 to 7 generate
	OUT_GEN : process(RESET,CLK_SYSX8)
	begin
		if RESET = '1' then
            ts_pwr_avg_d(i)       <= (others=>'0');
            ts_pwr_avg_dd(i)      <= (others=>'0');
            tssi_for_r(i)         <= (others=>'0');
            tssi_rev_r(i)         <= (others=>'0');
		elsif CLK_SYSX8 = '1' and CLK_SYSX8'event then
            -- update every 16 TS sync
            if ts16_sync_rpls = '1' then -- update average power value
                ts_pwr_avg_d(i) <= ts_pwr_accum(i)(35 downto 4);
                ts_pwr_avg_dd(i)<= ts_pwr_avg_d(i);
            end if;

            -- update register value when FW latch enable is '0'
            --if update_reg_en_r(2 downto 1) = "01" then -- only update when 'UPDATE_REG_EN' high edge (RF reverse power measure end point)
                tssi_rev_r(i)   <= ts_pwr_avg_d(i);
                tssi_for_r(i)   <= ts_pwr_avg_dd(i);
            --end if;
        end if;
	end process;


STRB_480MS : process(RESET,CLK_SYSX8)
	begin
		if RESET = '1' then
            sync_480ms_cnt   <= (others=>'0');
            sync_480ms       <= '0';
			sync_480ms_d     <= '0';
		elsif CLK_SYSX8 = '1' and CLK_SYSX8'event then
            if i_120ms_sync_rpls = '1' then -- update average power value
                sync_480ms_cnt <=   sync_480ms_cnt  + '1';
            end if;

			if i_120ms_sync_rpls = '1' and sync_480ms_cnt = "11" then
			    sync_480ms <= '1';
			else
				sync_480ms <= '0';
			end if;

            sync_480ms_d <= sync_480ms;
		end if;
	end process;

OUT_MAX : process(RESET,CLK_SYSX8)
	begin
		if RESET = '1' then
            ts_check(i)           <= (others=>'0');
            ts_max(i)             <= (others=>'0');
            ts_max_latch(i)       <= (others=>'0');
		elsif CLK_SYSX8 = '1' and CLK_SYSX8'event then

            if sum_done = "01" then -- update average power value
                ts_check(i)<= sum_pwr(i)(41 downto 10);
            end if;
            -- update every 16 TS sync
			if sync_480ms_d = '1' then
			    ts_max(i) <= (others =>'0');
			else
    		    if ts_max(i) < ts_check(i)  then
                    ts_max(i) <= ts_check(i) ;
                else
    		        ts_max(i) <= ts_max(i) ;
    		    end if;
            end if;

			if sync_480ms = '1' then 
			    ts_max_latch(i)   <= ts_max(i); 
            end if; 
            tssi_max_r(i) <= ts_max_latch(i); 
            -- update register value when FW latch enable is '0'
            --if update_reg_en_r(2 downto 1) = "01" then -- only update when 'UPDATE_REG_EN' high edge (RF reverse power measure end point)
            --end if;
        end if;
	end process;


	end generate;
    
    O_TSSI     <= tssi_for_r;
    O_TSSI_MAX <= tssi_max_r;

    -- latancy : 3-clock
    mult_16x16_iq : MULT_MACRO
    generic map (
        DEVICE        => "7SERIES"       , -- Target Device: "VIRTEX5", "VIRTEX6", "SPARTAN6"
        LATENCY       => 3               , -- Desired clock cycle latency, 0-4
        WIDTH_A       => 16              , -- Multiplier A-input bus width, 1-25
        WIDTH_B       => 16                -- Multiplier B-input bus width, 1-18
        )
    port map (
        P             => data_mult_out   , -- Multiplier output bus, width determined by WIDTH_P generic
        A             => mult_in_data    , -- Multiplier input A bus, width determined by WIDTH_A generic
        B             => mult_in_data    , -- Multiplier input B bus, width determined by WIDTH_B generic
        CE            => '1'             , -- 1-bit active high input clock enable
        CLK           => CLK_SYSX8             , -- 1-bit positive edge clock input
        RST           => RESET             -- 1-bit input active high reset
        );
    





end BEHAVE;






