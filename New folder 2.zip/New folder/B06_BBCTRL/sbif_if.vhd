--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : SBIF interface                                                --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity SBIF_IF is
    generic (
        NUM_CPRI                    : natural := 2;
        NUM_SBIF                    : natural := 2
    );
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        CLK_CPRI                    : in  std_logic_vector(NUM_CPRI-1 downto 0);
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

--------------------------------------------------------------------------------
-- CPRI
--------------------------------------------------------------------------------

        CPRI_LOF                    : in  std_logic_vector(NUM_CPRI-1 downto 0);

        CPRI_RX_BFN_STRB            : in  std_logic_vector(NUM_CPRI-1 downto 0);
        CPRI_RX_BFN                 : in  std_logic_array12(NUM_CPRI-1 downto 0);
        CPRI_RX_VLD                 : in  std_logic_vector(NUM_CPRI-1 downto 0);
        CPRI_RX_I                   : in  std_logic_array16(NUM_CPRI-1 downto 0);
        CPRI_RX_Q                   : in  std_logic_array16(NUM_CPRI-1 downto 0);

        CPRI_TX_ENB                 : in  std_logic_vector(NUM_CPRI-1 downto 0);
        CPRI_TX_I                   : out std_logic_array16(NUM_CPRI-1 downto 0);
        CPRI_TX_Q                   : out std_logic_array16(NUM_CPRI-1 downto 0);

--------------------------------------------------------------------------------
-- SBIF
--------------------------------------------------------------------------------

        SBIF_LOF                    : in  std_logic_vector(NUM_SBIF-1 downto 0);

        SBIF_RX_10MS                : in  std_logic_vector(NUM_SBIF-1 downto 0);
        SBIF_RX_SYNC                : out std_logic_vector(NUM_SBIF-1 downto 0);
        SBIF_RX_I                   : in  std_logic_array16(NUM_SBIF-1 downto 0);
        SBIF_RX_Q                   : in  std_logic_array16(NUM_SBIF-1 downto 0);

        SBIF_TX_10MS                : out std_logic_vector(NUM_SBIF-1 downto 0);
        SBIF_TX_BFN                 : out std_logic_array12(NUM_SBIF-1 downto 0);
        SBIF_TX_SYNC                : out std_logic_vector(NUM_SBIF-1 downto 0);
        SBIF_TX_I                   : out std_logic_array16(NUM_SBIF-1 downto 0);
        SBIF_TX_Q                   : out std_logic_array16(NUM_SBIF-1 downto 0)
    );
end SBIF_IF;

architecture BEHAVE of SBIF_IF is

    signal cpri_tx_enb_cnt          : std_logic_array6(NUM_CPRI-1 downto 0) := (others => (others => '0'));

begin

    PROCESSING_DELAY_DL <= (others => '0');
    PROCESSING_DELAY_UL <= (others => '0');

    u_PORT : for i in NUM_SBIF-1 downto 0 generate
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (CPRI_LOF(i) = '1') then
                SBIF_TX_10MS(i) <= '0';
                SBIF_TX_BFN(i)  <= (others => '0');
                SBIF_TX_SYNC(i) <= '0';
                SBIF_TX_I(i)    <= (others => '0');
                SBIF_TX_Q(i)    <= (others => '0');
            else
                SBIF_TX_10MS(i) <= CPRI_RX_BFN_STRB(i);
                SBIF_TX_BFN(i)  <= CPRI_RX_BFN(i);
                SBIF_TX_SYNC(i) <= CPRI_RX_VLD(i);
                SBIF_TX_I(i)    <= CPRI_RX_I(i);
                SBIF_TX_Q(i)    <= CPRI_RX_Q(i);
            end if;
        end if;
    end process;

    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (CPRI_TX_ENB(i) = '1') then
                cpri_tx_enb_cnt(i) <= (others => '0');
            else
                cpri_tx_enb_cnt(i) <= cpri_tx_enb_cnt(i) + 1;
            end if;
        end if;
    end process;

    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cpri_tx_enb_cnt(i) = 61) then
                SBIF_RX_SYNC(i) <= '1';
            else
                SBIF_RX_SYNC(i) <= '0';
            end if;
        end if;
    end process;

    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (SBIF_LOF(i) = '1') then
                CPRI_TX_I(i) <= (others => '0');
                CPRI_TX_Q(i) <= (others => '0');
            else
                CPRI_TX_I(i) <= SBIF_RX_I(i);
                CPRI_TX_Q(i) <= SBIF_RX_Q(i);
            end if;
        end if;
    end process;
    end generate;

end BEHAVE;