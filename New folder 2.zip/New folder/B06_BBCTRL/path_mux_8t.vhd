--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : PATH_MUX_8T                                                   --
--              - align 2 path (max 4T) and share 1 path (8T)                 --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2021.02.17                                                    --
-- Target     : Max 4-antennas                                                --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;

entity PATH_MUX_8T is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);
        SYNC_MISMATCH               : out std_logic;

--------------------------------------------------------------------------------
-- Formatter
--------------------------------------------------------------------------------

        UL_10MS                     : out std_logic;
        UL_TDD                      : out std_logic;
        UL_SYNC                     : out std_logic;
        UL_DATA                     : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- DDUC Side
--------------------------------------------------------------------------------

        DDC_10MS                    : in  std_logic;
        DDC_TDD                     : in  std_logic;
        DDC_SYNC                    : in  std_logic_vector(1 downto 0);
        DDC_DATA                    : in  std_logic_array16(1 downto 0)

    );
end PATH_MUX_8T;

architecture BEHAVE of PATH_MUX_8T is

    signal ul_ftc_delay             : std_logic_vector(23 downto 0) := (others => '0');
    signal ul_att_delay             : std_logic_vector(23 downto 0) := (others => '0');

    signal ddc_10ms_sh              : std_logic := '0';
    signal ddc_tdd_sh               : std_logic := '0';
    signal ddc_sync_0_sh            : std_logic := '0';
    signal ddc_data_0_sh            : std_logic_vector(15 downto 0) := (others => '0');
    signal ddc_sync_1_sh            : std_logic := '0';
    signal ddc_data_1_sh            : std_logic_array16(8 downto 0) := (others => (others => '0'));

    signal sync_cnt                 : std_logic_vector(3 downto 0) := (others => '0');
    signal align_gap                : std_logic_vector(3 downto 0) := (others => '0');
    signal err_flag                 : std_logic := '0';

begin

    PROCESSING_DELAY_UL <= x"000002"; 

    SYNC_MISMATCH <= err_flag;

    process (RESET, CLK)
    begin
        if (RESET = '1') then
            ddc_10ms_sh   <= '0';
            ddc_tdd_sh    <= '0';
            ddc_sync_0_sh <= '0';
            ddc_data_0_sh <= (others => '0');
            ddc_data_1_sh <= (others => (others => '0'));
        elsif (CLK'event and CLK = '1') then
            ddc_10ms_sh   <= DDC_10MS;
            ddc_tdd_sh    <= DDC_TDD ;
            ddc_sync_0_sh <= DDC_SYNC(0);
            ddc_data_0_sh <= DDC_DATA(0);
            ddc_sync_1_sh <= DDC_SYNC(1);
            ddc_data_1_sh <= ddc_data_1_sh(7 downto 0) & DDC_DATA(1);
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            UL_10MS <= ddc_10ms_sh  ;           
            UL_TDD  <= ddc_tdd_sh   ;           
            UL_SYNC <= ddc_sync_0_sh;           
            UL_DATA <= ddc_data_0_sh or ddc_data_1_sh(8);
        end if;
    end process;

    --error detection
    process(RESET, CLK)
    begin
        if (RESET = '1') then
            sync_cnt <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            if (DDC_SYNC(0) = '1') then
                sync_cnt <= (others => '0');
            else
                sync_cnt <= sync_cnt + 1;
            end if;
        end if;
    end process;

    process(RESET, CLK)
    begin
        if (RESET = '1') then
            align_gap <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            if (ddc_sync_1_sh = '1') then
                align_gap <= sync_cnt;
            end if;
        end if;
    end process;

    process(CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (align_gap = 0) then
                err_flag <= '0';
            else
                err_flag <= '1';
            end if;
        end if;
    end process;

end BEHAVE;
