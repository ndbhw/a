--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : DDUC_MAP_IF                                                        --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                             --
-- Department : FPGA part. (Network Division)                                   --
-- Release    : 2021.11.08                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity DDUC_MAP_IF is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        ARESET                      : in  std_logic;

        CLK_AUX                     : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        BW_SEL                      : in  std_logic_array4(3 downto 0);
        ANT_SWAP                    : in  std_logic_array4(3 downto 0);

--------------------------------------------------------------------------------
-- BIT_CONV
--------------------------------------------------------------------------------

        I_RX_10MS                   : in  std_logic;
        I_RX_BFN                    : in  std_logic_vector(11 downto 0);
        I_RX_TDD                    : in  std_logic;
        I_RX_SYNC                   : in  std_logic;
        I_RX_DATA_I                 : in  std_logic_vector(15 downto 0);
        I_RX_DATA_Q                 : in  std_logic_vector(15 downto 0);

        O_TX_10MS                   : out std_logic;
        O_TX_TDD                    : out std_logic;
        I_TX_SYNC                   : in  std_logic;
        O_TX_DATA_I                 : out std_logic_vector(15 downto 0);
        O_TX_DATA_Q                 : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- FORMATTER
--------------------------------------------------------------------------------

        O_DL_10MS                   : out std_logic;
        O_DL_BFN                    : out std_logic_vector(11 downto 0);
        O_DL_TDD                    : out std_logic;
        O_DL_SYNC                   : out std_logic_vector(3 downto 0);
        O_DL_DATA                   : out std_logic_array16(3 downto 0);

        I_UL_10MS                   : in  std_logic;
        I_UL_TDD                    : in  std_logic;
        I_UL_SYNC                   : in  std_logic_vector(3 downto 0);
        I_UL_DATA                   : in  std_logic_array16(3 downto 0)

    );
end DDUC_MAP_IF;

architecture BEHAVE of DDUC_MAP_IF is

    component DUC_MAP_IF is
    port (
        ARESET                      : in  std_logic;

        CLK_AUX                     : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);

        BW_SEL                      : in  std_logic_array4(3 downto 0);
        ANT_SWAP                    : in  std_logic_array4(3 downto 0);

        I_RX_10MS                   : in  std_logic;
        I_RX_BFN                    : in  std_logic_vector(11 downto 0);
        I_RX_TDD                    : in  std_logic;
        I_RX_SYNC                   : in  std_logic;
        I_RX_DATA_I                 : in  std_logic_vector(15 downto 0);
        I_RX_DATA_Q                 : in  std_logic_vector(15 downto 0);

        O_DL_10MS                   : out std_logic;
        O_DL_BFN                    : out std_logic_vector(11 downto 0);
        O_DL_TDD                    : out std_logic;
        O_DL_SYNC                   : out std_logic_vector(3 downto 0);
        O_DL_DATA                   : out std_logic_array16(3 downto 0)

    );
    end component;

    component DDC_MAP_IF is
    port (
        ARESET                      : in  std_logic;

        CLK_AUX                     : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        BW_SEL                      : in  std_logic_array4(3 downto 0);

        O_TX_10MS                   : out std_logic;
        O_TX_TDD                    : out std_logic;
        I_TX_SYNC                   : in  std_logic;
        O_TX_DATA_I                 : out std_logic_vector(15 downto 0);
        O_TX_DATA_Q                 : out std_logic_vector(15 downto 0);

        I_UL_10MS                   : in  std_logic;
        I_UL_TDD                    : in  std_logic;
        I_UL_SYNC                   : in  std_logic_vector(3 downto 0);
        I_UL_DATA                   : in  std_logic_array16(3 downto 0)

    );
    end component;

begin

    U_DUC_MAP_IF : DUC_MAP_IF
    port map(
        ARESET                      => ARESET                 , --: in  std_logic;
                                                
        CLK_AUX                     => CLK_AUX                , --: in  std_logic;
        CLK_SYSX8                   => CLK_SYSX8              , --: in  std_logic;

        PROCESSING_DELAY_DL         => PROCESSING_DELAY_DL    , --: out std_logic_vector(23 downto 0);

        BW_SEL                      => BW_SEL                 , --: in  std_logic_array4(3 downto 0);
        ANT_SWAP                    => ANT_SWAP               , --: in  std_logic_array4(3 downto 0);

        I_RX_10MS                   => I_RX_10MS              , --: in  std_logic;
        I_RX_BFN                    => I_RX_BFN               , --: in  std_logic_vector(11 downto 0);
        I_RX_TDD                    => I_RX_TDD               , --: in  std_logic;
        I_RX_SYNC                   => I_RX_SYNC              , --: in  std_logic;
        I_RX_DATA_I                 => I_RX_DATA_I            , --: in  std_logic_vector(15 downto 0);
        I_RX_DATA_Q                 => I_RX_DATA_Q            , --: in  std_logic_vector(15 downto 0);

        O_DL_10MS                   => O_DL_10MS              , --: out std_logic;
        O_DL_BFN                    => O_DL_BFN               , --: out std_logic_vector(11 downto 0);
        O_DL_TDD                    => O_DL_TDD               , --: out std_logic;
        O_DL_SYNC                   => O_DL_SYNC              , --: out std_logic_vector(3 downto 0);
        O_DL_DATA                   => O_DL_DATA                --: out std_logic_array16(3 downto 0)

    );

    U_DDC_MAP_IF : DDC_MAP_IF 
    port map(
        ARESET                      => ARESET                 , --: in  std_logic;
                                                
        CLK_AUX                     => CLK_AUX                , --: in  std_logic;
        CLK_SYSX8                   => CLK_SYSX8              , --: in  std_logic;

        PROCESSING_DELAY_UL         => PROCESSING_DELAY_UL    , --: out std_logic_vector(23 downto 0);

        BW_SEL                      => BW_SEL                 , --: in  std_logic_array4(3 downto 0);

        O_TX_10MS                   => O_TX_10MS              , --: out std_logic;
        O_TX_TDD                    => O_TX_TDD               , --: out std_logic;
        I_TX_SYNC                   => I_TX_SYNC              , --: in  std_logic;
        O_TX_DATA_I                 => O_TX_DATA_I            , --: out std_logic_vector(15 downto 0);
        O_TX_DATA_Q                 => O_TX_DATA_Q            , --: out std_logic_vector(15 downto 0);

        I_UL_10MS                   => I_UL_10MS              , --: in  std_logic;
        I_UL_TDD                    => I_UL_TDD               , --: in  std_logic;
        I_UL_SYNC                   => I_UL_SYNC              , --: in  std_logic_vector(3 downto 0);
        I_UL_DATA                   => I_UL_DATA                --: in  std_logic_array16(3 downto 0)

    );

end BEHAVE;
