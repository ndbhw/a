--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Pattern generator (DC)                                        --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.22                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity PT_GEN_DC is
    generic (
        NUM_ANTENNA                 : natural := 4
    );
    port (
        CLK                         : in  std_logic;
        ENABLE                      : in  std_logic;

        TEST_DC_I                   : in  std_logic_vector(15 downto 0);
        TEST_DC_Q                   : in  std_logic_vector(15 downto 0);

        IN_SYNC                     : in  std_logic;
        OUT_DATA                    : out std_logic_vector(15 downto 0)
    );
end PT_GEN_DC;

architecture BEHAVE of PT_GEN_DC is

    signal cnt_sync                 : std_logic_vector(3 downto 0) := (others => '0');

begin

    -- synchronization
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_SYNC = '1') then
                cnt_sync <= (others => '0');
            else
                if (cnt_sync = 8) then
                    cnt_sync <= cnt_sync;
                else
                    cnt_sync <= cnt_sync + 1;
                end if;
            end if;
        end if;
    end process;

    -- output data
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (ENABLE = '1') then
                if (NUM_ANTENNA = 1) then
                    case cnt_sync is
                    when "0000" => OUT_DATA <= TEST_DC_I;
                    when "0001" => OUT_DATA <= TEST_DC_Q;
                    when others => OUT_DATA <= (others => '0');
                    end case;
                elsif (NUM_ANTENNA = 2) then
                    case cnt_sync is
                    when "0000" => OUT_DATA <= TEST_DC_I;
                    when "0001" => OUT_DATA <= TEST_DC_Q;
                    when "0010" => OUT_DATA <= TEST_DC_I;
                    when "0011" => OUT_DATA <= TEST_DC_Q;
                    when others => OUT_DATA <= (others => '0');
                    end case;
                elsif (NUM_ANTENNA = 3) then
                    case cnt_sync is
                    when "0000" => OUT_DATA <= TEST_DC_I;
                    when "0001" => OUT_DATA <= TEST_DC_Q;
                    when "0010" => OUT_DATA <= TEST_DC_I;
                    when "0011" => OUT_DATA <= TEST_DC_Q;
                    when "0100" => OUT_DATA <= TEST_DC_I;
                    when "0101" => OUT_DATA <= TEST_DC_Q;
                    when others => OUT_DATA <= (others => '0');
                    end case;
                else
                    case cnt_sync is
                    when "0000" => OUT_DATA <= TEST_DC_I;
                    when "0001" => OUT_DATA <= TEST_DC_Q;
                    when "0010" => OUT_DATA <= TEST_DC_I;
                    when "0011" => OUT_DATA <= TEST_DC_Q;
                    when "0100" => OUT_DATA <= TEST_DC_I;
                    when "0101" => OUT_DATA <= TEST_DC_Q;
                    when "0110" => OUT_DATA <= TEST_DC_I;
                    when "0111" => OUT_DATA <= TEST_DC_Q;
                    when others => OUT_DATA <= (others => '0');
                    end case;
                end if;
            else
                OUT_DATA <= (others => '0');
            end if;
        end if;
    end process;

end BEHAVE;