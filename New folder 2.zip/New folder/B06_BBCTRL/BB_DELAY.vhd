--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : BB delay                                                      --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2021.02.09                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

entity BB_DELAY is
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

        BW_SEL                      : in  std_logic_vector(3 downto 0);
        DATA_DELAY_VALUE            : in  std_logic_vector(31 downto 0);

        DLY_IN_10MS                 : in  std_logic;
        DLY_IN_TDD                  : in  std_logic;
        DLY_IN_SYNC                 : in  std_logic;
        DLY_IN_DATA                 : in  std_logic_vector(15 downto 0);

        DLY_OUT_10MS                : out std_logic;
        DLY_OUT_TDD                 : out std_logic;
        DLY_OUT_SYNC                : out std_logic;
        DLY_OUT_DATA                : out std_logic_vector(15 downto 0)
    );
end BB_DELAY;

architecture BEHAVE of BB_DELAY is

    function log2 (data_value : integer)
    return integer is
        variable result      : integer := 0;
        variable cnt         : integer := 1;
    begin
        if (data_value <= 1) then
            result     := 0;
        else
            while (cnt < data_value) loop
                result := result + 1;
                cnt    := cnt *2;
            end loop;
        end if;
        return result;
    end log2;

    signal clk_cnt                  : std_logic_vector(4 downto 0) := (others => '0');

    signal limit_dly_value          : std_logic_vector(31 downto 0) := (others => '0');

    component bb_buf is
    generic(
        STYLE                       : string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
        NPIPE                       : integer := 6;
        DEPTH                       : integer := 8192;
        WIDTH                       : integer := 72
    );
    port(
        WCLK                        : in  std_logic;
        RCLK                        : in  std_logic;
        WE                          : in  std_logic;
        ENB                         : in  std_logic;
        WADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
        RADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
        WDATA                       : in  std_logic_vector(WIDTH-1 downto 0);
        RDATA                       : out std_logic_vector(WIDTH-1 downto 0)
    );
    end component;

    --signal wr_addr                  : std_logic_vector( 4 downto 0) := (others => '0');
    signal wr_addr                  : std_logic_vector( 8 downto 0) := (others => '0');
    signal wr_data                  : std_logic_vector(18 downto 0) := (others => '0');
    --signal rd_addr                  : std_logic_vector( 4 downto 0) := (others => '0');
    signal rd_addr                  : std_logic_vector( 8 downto 0) := (others => '0');
    signal rd_data                  : std_logic_vector(18 downto 0) := (others => '0');

begin

    PROCESSING_DELAY <= conv_std_logic_vector(5, 24);

    --delay saturation
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            --if (DATA_DELAY_VALUE >= 31-4) then
            --    limit_dly_value <= conv_std_logic_vector(31-4, 32);
            if (DATA_DELAY_VALUE >= 511-4) then                     
                limit_dly_value <= conv_std_logic_vector(511-4, 32);
            else
                limit_dly_value <= DATA_DELAY_VALUE;
            end if;
        end if;
    end process;
            
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (BW_SEL = x"2") then        -- 5M
                if (DLY_IN_SYNC = '1') then
                    clk_cnt <= (others => '0');
                else
                    clk_cnt <= clk_cnt + 1;
                end if;
            elsif (BW_SEL = x"3") then    -- 10M
                if (DLY_IN_SYNC = '1') then
                    clk_cnt(4) <= not clk_cnt(4);
                    clk_cnt(3 downto 0) <= (others => '0');
                else
                    clk_cnt(4) <= clk_cnt(4);
                    clk_cnt(3 downto 0) <= clk_cnt(3 downto 0) + 1;
                end if;
            else                          -- 15/20M
                if (DLY_IN_SYNC = '1') then
                    clk_cnt(4 downto 3) <= clk_cnt(4 downto 3) + 1;
                    clk_cnt(2 downto 0) <= (others => '0');
                else
                    clk_cnt(4 downto 3) <= clk_cnt(4 downto 3);
                    clk_cnt(2 downto 0) <= clk_cnt(2 downto 0) + 1;
                end if;
            end if;
        end if;
    end process;
                    
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            wr_data <= DLY_IN_10MS & DLY_IN_TDD & DLY_IN_SYNC & DLY_IN_DATA;
            --if (wr_addr = 31) then
            if (wr_addr = 511) then
                wr_addr <= (others => '0');
            else
                wr_addr <= wr_addr + 1;
            end if;
            --if (wr_addr = limit_dly_value(4 downto 0)) then
            if (wr_addr = limit_dly_value(8 downto 0)) then
                rd_addr <= (others => '0');
            else
                rd_addr <= rd_addr + 1;
            end if;
        end if;
    end process;
    
    -- write data
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            wr_data <= DLY_IN_10MS & DLY_IN_TDD & DLY_IN_SYNC & DLY_IN_DATA;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            DLY_OUT_10MS <= rd_data(18); 
            DLY_OUT_TDD  <= rd_data(17);  
            DLY_OUT_SYNC <= rd_data(16);  
            DLY_OUT_DATA <= rd_data(15 downto 0); 
        end if;
    end process;


    u_delay_buf : bb_buf 
    generic map(
        STYLE                       => "BLOCK"      , --: string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
        NPIPE                       =>  2           , --: integer := 6;
        --DEPTH                       =>  32          , --: integer := 8192;
        DEPTH                       =>  512          , --: integer := 8192;
        WIDTH                       =>  19            --: integer := 72
    )
    port map(
        WCLK                        => CLK          , --: in  std_logic;
        RCLK                        => CLK          , --: in  std_logic;
        WE                          => '1'          , --: in  std_logic;
        ENB                         => '1'          , --: in  std_logic;
        WADDR                       => wr_addr      , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        RADDR                       => rd_addr      , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        WDATA                       => wr_data      , --: in  std_logic_vector(WIDTH-1 downto 0);
        RDATA                       => rd_data        --: out std_logic_vector(WIDTH-1 downto 0)
    );










end BEHAVE;
