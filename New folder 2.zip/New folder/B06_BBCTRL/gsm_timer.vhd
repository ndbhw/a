--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : GSM_TIMER                                                       --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2021.11.08                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity GSM_TIMER is
    port (
        RST                         : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);

        I_TS_ADV                    : in  std_logic_vector(17 downto 0);
        I_TS_GP_OFFSET              : in  std_logic_vector(12 downto 0);

        I_120MS_STRB                : in  std_logic;
        I_BFN_STRB                  : in  std_logic;
        I_BFN_NUM                   : in  std_logic_vector(11 downto 0);
        I_DATA_SYNC                 : in  std_logic;
        I_DATA_IQ                   : in  std_logic_vector(15 downto 0);

        O_120MS_STRB                : out std_logic;
        O_BFN_STRB                  : out std_logic;
        O_BFN_NUM                   : out std_logic_vector(11 downto 0);
        O_DATA_SYNC                 : out std_logic;
        O_DATA_IQ                   : out std_logic_vector(15 downto 0);

        O_TS16_SYNC                 : out std_logic;
        O_TS_SYNC                   : out std_logic;
        O_TS_GP_SYNC                : out std_logic;
        O_TS_GP_START               : out std_logic
    
    );
end GSM_TIMER;

architecture BEHAVE of GSM_TIMER is

    constant const_ts_clk_cnt       : std_logic_vector(17 downto 0) := "100010100111010111"; -- 141784 clock = 576.920 us = 1 TS
    constant gp_start_offset        : std_logic_vector(17 downto 0) := "100000110010011010"; -- 134298 clock = 546.459 us = Guard period start point

    signal data_sync_d              : std_logic_vector( 2 downto 0) := (others => '0'); 
    signal data_iq_d                : std_logic_array16(2 downto 0) := (others => (others => '0')); 
    signal bfn_strb_d               : std_logic_vector( 2 downto 0) := (others => '0'); 
    signal bfn_num_d                : std_logic_array12( 2 downto 0) := (others => (others => '0')); 

    signal strb_120ms_d             : std_logic_vector( 2 downto 0) := (others => '0');
    signal strb_120ms_rpls          : std_logic := '0';

    signal gsm_clk_cnt              : std_logic_vector(17 downto 0) := (others => '0');
    signal gsm_clk_ts_t             : std_logic_vector(17 downto 0) := (others => '0');
    signal gsm_ts_cnt               : std_logic_vector(3 downto 0); -- GSM  time slot counter
    signal tdma_ts_cnt              : std_logic_vector( 3 downto 0) := (others => '0');

    signal ts_adv_r                 : std_logic_vector(17 downto 0) := (others => '0');
    signal ts_adv_temp              : std_logic_vector(17 downto 0) := (others => '0');
    signal ts_gp_adv_temp           : std_logic_vector(18 downto 0) := (others => '0');
    signal ts_gp_start_adv_temp     : std_logic_vector(18 downto 0) := (others => '0');
    signal ts_gp_adv_r              : std_logic_vector(18 downto 0) := (others => '0');
    signal ts_gp_start_adv_r        : std_logic_vector(18 downto 0) := (others => '0');
    signal ts_gp_offset_r           : std_logic_vector(12 downto 0) := (others => '0');
    signal ts_gp_off_temp           : std_logic_vector(12 downto 0) := (others => '0');
    
    signal ts_sync_r                : std_logic := '0';
    signal ts_gp_sync_r             : std_logic := '0';
    signal ts_gp_start_r            : std_logic := '0';
    signal ts16_sync_r              : std_logic := '0';
    
begin

    PROCESSING_DELAY_DL <= conv_std_logic_vector(3,24);    

    O_TS_SYNC     <= ts_sync_r;
    O_TS_GP_SYNC  <= ts_gp_sync_r;
    O_TS_GP_START <= ts_gp_start_r;
    O_TS16_SYNC   <= ts16_sync_r;

    O_120MS_STRB <= strb_120ms_d(2); 
    O_BFN_STRB   <= bfn_strb_d(2); 
    O_BFN_NUM    <= bfn_num_d(2); 
    O_DATA_SYNC  <= data_sync_d(2); 
    O_DATA_IQ    <= data_iq_d(2); 

    process (RST,CLK_SYSX8)
    begin
        if (RST = '1') then
            data_sync_d <= (others => '0');
            data_iq_d   <= (others => (others => '0'));
        elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            data_sync_d <= data_sync_d(1 downto 0) & I_DATA_SYNC; 
            data_iq_d   <= data_iq_d  (1 downto 0) & I_DATA_IQ  ; 
        end if;
    end process;

    process (RST,CLK_SYSX8)
    begin
        if (RST = '1') then
            strb_120ms_d    <= (others => '0');
            strb_120ms_rpls <= '0';
            bfn_strb_d      <= (others => '0');
            bfn_num_d       <= (others => (others => '0'));
        elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            strb_120ms_d    <= strb_120ms_d(1 downto 0) & I_120MS_STRB;
            strb_120ms_rpls <= I_120MS_STRB and not strb_120ms_d(0);
            bfn_strb_d      <= bfn_strb_d(1 downto 0) & I_BFN_STRB;
            bfn_num_d       <= bfn_num_d(1 downto 0) & I_BFN_NUM;
        end if;
    end process;

    -- time slot sync count
    process (RST,CLK_SYSX8)
    begin
        if (RST = '1') then
            gsm_clk_cnt <= (others => '0');
            gsm_ts_cnt  <= (others => '0');
            tdma_ts_cnt <= (others => '0');
        elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (strb_120ms_rpls = '1') then
                gsm_clk_cnt <= (others => '0');
                gsm_ts_cnt  <= (others => '0');
                tdma_ts_cnt <= (others => '0');
            elsif gsm_clk_cnt = gsm_clk_ts_t then
                gsm_clk_cnt <= (others => '0');
                if gsm_ts_cnt = 12 then
                    gsm_ts_cnt <= (others => '0');
                else
                    gsm_ts_cnt <= gsm_ts_cnt + 1;
                end if;
                tdma_ts_cnt <= tdma_ts_cnt + 1;
            else
                gsm_clk_cnt <= gsm_clk_cnt + 1;
            end if;
        end if;
    end process;

    -- counting value per time slot
    process (RST,CLK_SYSX8)
    begin
        if (RST = '1') then
            gsm_clk_ts_t <= (others => '0');
        elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            case gsm_ts_cnt is -- 141784 * 4 + 141785 * 8 = 13 TS = 7.5ms
                when "0000" => gsm_clk_ts_t <= "100010100111011000"; -- 141784 for counting 141785 clock @ 245.76MHz
                when "0001" => gsm_clk_ts_t <= "100010100111010111"; -- 141783 for counting 141784 clock @ 245.76MHz
                when "0010" => gsm_clk_ts_t <= "100010100111011000"; -- 141784 
                when "0011" => gsm_clk_ts_t <= "100010100111010111"; -- 141783 
                when "0100" => gsm_clk_ts_t <= "100010100111011000"; -- 141784
                when "0101" => gsm_clk_ts_t <= "100010100111011000"; -- 141784 
                when "0110" => gsm_clk_ts_t <= "100010100111010111"; -- 141783 
                when "0111" => gsm_clk_ts_t <= "100010100111011000"; -- 141784 
                when "1000" => gsm_clk_ts_t <= "100010100111011000"; -- 141784
                when "1001" => gsm_clk_ts_t <= "100010100111010111"; -- 141783 
                when "1010" => gsm_clk_ts_t <= "100010100111011000"; -- 141784
                when "1011" => gsm_clk_ts_t <= "100010100111010111"; -- 141783
                when "1100" => gsm_clk_ts_t <= "100010100111011000"; -- 141784
                when others => gsm_clk_ts_t <= gsm_clk_ts_t;
            end case;
        end if;
    end process;

 
    -- time slot gp advance value
    process (RST,CLK_SYSX8)
    begin
        if (RST = '1') then
            ts_adv_r              <= (others => '0');
            ts_adv_temp           <= (others => '0');
            ts_gp_offset_r        <= (others => '0');
            ts_gp_off_temp        <= (others => '0');
            ts_gp_adv_r           <= (others => '0');
            ts_gp_adv_temp        <= (others => '0');
            ts_gp_start_adv_temp  <= (others => '0');
            ts_gp_start_adv_r     <= (others => '0');
        elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            ts_adv_temp <= I_TS_ADV;
            if ts_adv_temp >= const_ts_clk_cnt then -- max 141784 clock delay
                ts_adv_r <= const_ts_clk_cnt;
            else
                ts_adv_r <= ts_adv_temp;
            end if;

            ts_gp_off_temp <= I_TS_GP_OFFSET;
            if ts_gp_off_temp >= "1110100111010" then -- if greater than 7482 clock
                ts_gp_offset_r <= "1110100111010";
            else
                ts_gp_offset_r <= ts_gp_off_temp;
            end if;

            ts_gp_adv_temp <= ('0' &ts_adv_r) + ('0' & gp_start_offset) + ("00000" & ts_gp_offset_r);
            if ts_gp_adv_temp >= ('0' & const_ts_clk_cnt) then
                ts_gp_adv_r <= ts_gp_adv_temp - const_ts_clk_cnt;
            else
                ts_gp_adv_r <= ts_gp_adv_temp;
            end if;

            ts_gp_start_adv_temp <= ('0' &ts_adv_r) + ('0' & gp_start_offset);
            if ts_gp_start_adv_temp >= ('0' & const_ts_clk_cnt) then
                ts_gp_start_adv_r <= ts_gp_start_adv_temp - const_ts_clk_cnt;
            else
                ts_gp_start_adv_r <= ts_gp_start_adv_temp;
            end if;
        end if;
    end process;

    -- time slot sync generate. every 1 time slot
    process (RST,CLK_SYSX8)
    begin
        if (RST = '1') then
            ts_sync_r <= '0';
        elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if gsm_clk_cnt = ts_adv_r then -- every start point of time slot
                ts_sync_r <= '1';
            else
                ts_sync_r <= '0';
            end if;
        end if;
    end process;

    -- time slot gaurd time sync generate. every 1 time slot
    process (RST,CLK_SYSX8)
    begin
        if (RST = '1') then
            ts_gp_sync_r <= '0';
        elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if gsm_clk_cnt = ts_gp_adv_r(17 downto 0) then -- Guard Period sync, 134298 clock + TS_GP_OFFSET (OFFSET max : 7482 clocks)
                ts_gp_sync_r <= '1';
            else
                ts_gp_sync_r <= '0';
            end if;
        end if;
    end process;

    process (RST,CLK_SYSX8)
    begin
        if (RST = '1') then
            ts_gp_start_r <= '0';
        elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if gsm_clk_cnt = ts_gp_start_adv_r(17 downto 0) then -- start point of Guard Period, 134298 clock + TS_GP_OFFSET (OFFSET max : 7482 clocks)
                ts_gp_start_r <= '1';
            else
                ts_gp_start_r <= '0';
            end if;
        end if;
    end process;


    -- 16TS sync. every 16 time slot
    process (RST,CLK_SYSX8)
    begin
        if (RST = '1') then
            ts16_sync_r <= '0';
        elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if gsm_clk_cnt = ts_adv_r and tdma_ts_cnt = "0000" then -- every 8 Time slot start point of time slot
                ts16_sync_r <= '1';
            else
                ts16_sync_r <= '0';
            end if;
        end if;
    end process;




 end BEHAVE;








