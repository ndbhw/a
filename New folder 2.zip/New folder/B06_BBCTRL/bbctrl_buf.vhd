library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

Library UNISIM;
use UNISIM.vcomponents.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity bbctrl_buf is
generic(
    BUF_STYLE                   : string  := "BLOCK";--"DISTRIBUTED","BLOCK","ultra","M20K"
    BUFF_DEPTH                  : integer := 8192;
    WIDTH_IN                    : integer := 1
);
port(
    WCLK                        : in  std_logic;
    RCLK                        : in  std_logic;
    WE                          : in  std_logic;
    ENB                         : in  std_logic;
    WADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    RADDR                       : in  std_logic_vector(log2(BUFF_DEPTH)-1 downto 0);
    DATA_IN                     : in  std_logic_vector(WIDTH_IN-1 downto 0);
    DATA_OUT                    : out std_logic_vector(WIDTH_IN-1 downto 0)
);
end bbctrl_buf;

architecture Behavioral of bbctrl_buf is

constant RAM_DEPTH              : integer := 2**log2(BUFF_DEPTH);
type ram_type                   is array (RAM_DEPTH-1 downto 0) of std_logic_vector(WIDTH_IN-1 downto 0);
signal RAM                      : ram_type := (others => (others => '0'));
signal ram_out                  : std_logic_vector(WIDTH_IN-1 downto 0);

attribute RAM_STYLE             : string;
attribute RAM_STYLE of RAM      : signal is BUF_STYLE;

begin

    process (WCLK)
    begin
    if rising_edge(WCLK) then
        if WE = '1' then
            RAM(conv_integer(WADDR)) <= DATA_IN;
        end if;
    end if;
    end process;

    process (RCLK)
    begin
    if rising_edge(RCLK) then
        if ENB='1' then
            ram_out <= RAM(conv_integer(RADDR));
        end if;
    end if;
    end process;

    process (RCLK)
    begin
    if rising_edge(RCLK) then
        DATA_OUT <= ram_out;-- for high performance, in BRAM primitive (no fabric)
    end if;
    end process;

end Behavioral;
