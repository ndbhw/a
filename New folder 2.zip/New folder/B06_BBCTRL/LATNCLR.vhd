------------------------------------------------------------
-- Date      : 2005.08.16
-- Code Name : LATNCLR.vhd
-- Function  : Latch and Clear
-- Revision History
-- 1. Initial Coding 2005.08.16
-------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity LATNCLR is
generic(
    BIT_WIDTH      : natural                                        -- EVENT & LATCH Bit Width.
);
port(
    RST            : in  std_logic;                                  -- Active High Reset, '1': Reset
    CLK            : in  std_logic;                                  -- Clock for EVENT
    CLR_FE_IN      : in  std_logic;                                  -- Clear at falling edge
    CLR_RE_IN      : in  std_logic;                                  -- Clear at rising edge
    EVENT_IN       : in  std_logic_vector(BIT_WIDTH - 1 downto 0);   -- Event Pulse more than one clock
    LATCH_OUT      : out std_logic_vector(BIT_WIDTH - 1 downto 0)    -- LATCH Output for EVENT.
);
end LATNCLR;

architecture ARC_LATNCLR of LATNCLR is

signal LATCH_S    : std_logic_vector(BIT_WIDTH - 1 downto 0);
signal CLR_FE_D1  : std_logic;
signal CLR_FE_D2  : std_logic;
signal CLR_RE_D1  : std_logic;
signal CLR_RE_D2  : std_logic;
signal CLR_FE_PLS : std_logic;
signal CLR_RE_PLS : std_logic;

begin

CLR_DFF_GEN : process(RST, CLK)
begin
if (RST = '1') then
    CLR_FE_D1 <= '0';
    CLR_FE_D2 <= '0';
    CLR_RE_D1 <= '0';
    CLR_RE_D2 <= '0';
elsif CLK = '1' and CLK'event then
    CLR_FE_D1 <= CLR_FE_IN;
    CLR_FE_D2 <= CLR_FE_D1;
    CLR_RE_D1 <= CLR_RE_IN;
    CLR_RE_D2 <= CLR_RE_D1;
end if;
end process;

CLR_FE_PLS <= ((not CLR_FE_D1) and CLR_FE_D2); -- Falling Edge of CLR_FE_IN
CLR_RE_PLS <= (CLR_RE_D1 and (not CLR_RE_D2)); -- Rising Edge of CLR_RE_IN


-- LATCH_S Gen & Clear
LATCH_AND_CLR : for I in 0 to BIT_WIDTH - 1 generate 
process(RST, CLK)
begin
if (RST = '1') then
    LATCH_S(I) <= '0';
elsif CLK = '1' and CLK'event then
    if EVENT_IN(I) = '1' then
        LATCH_S(I) <= '1';
    elsif (CLR_FE_PLS = '1') then
        LATCH_S(I) <= '0';
    elsif (CLR_RE_PLS = '1') then
        LATCH_S(I) <= '0';
    end if;
end if;
end process;
end generate;
LATCH_OUT <= LATCH_S;

end ARC_LATNCLR;
