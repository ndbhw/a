library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.numeric_std.all;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

Library xpm;
use xpm.vcomponents.all;

--library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity bb_buf is
generic(
    STYLE                       : string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
    NPIPE                       : integer := 6;
    DEPTH                       : integer := 8192;
    WIDTH                       : integer := 72
);
port(
    WCLK                        : in  std_logic;
    RCLK                        : in  std_logic;
    WE                          : in  std_logic;
    ENB                         : in  std_logic;
    WADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
    RADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
    WDATA                       : in  std_logic_vector(WIDTH-1 downto 0);
    RDATA                       : out std_logic_vector(WIDTH-1 downto 0)
);
end bb_buf;

architecture Behavioral of bb_buf is

    signal wea                  : std_logic_vector(0 downto 0):=(others => '0');
    signal enb_d                : std_logic_vector(NPIPE-1 downto 0):=(others => '0');
    signal enb_ext              : std_logic:='0';

begin

    wea(0) <= WE;

    process(RCLK)
    begin
        if rising_edge(RCLK) then
            enb_d <= enb_d(NPIPE-2 downto 0) & ENB;
        end if;
    end process;

    enb_ext <= enb_d(NPIPE-1) or ENB;

    xpm_memory_sdpram_inst : xpm_memory_sdpram
    generic map (

    -- Common module generics
    MEMORY_SIZE             => DEPTH*WIDTH    ,  --positive integer
    MEMORY_PRIMITIVE        => STYLE          ,  --string; "auto", "distributed", "block" or "ultra" ;
    CLOCKING_MODE           => "common_clock" ,  --string; "common_clock", "independent_clock" 
    MEMORY_INIT_FILE        => "none"         ,  --string; "none" or "<filename>.mem" 
    MEMORY_INIT_PARAM       => ""             ,  --string;
    USE_MEM_INIT            => 1              ,  --integer; 0,1
    WAKEUP_TIME             => "disable_sleep",  --string; "disable_sleep" or "use_sleep_pin" 
    MESSAGE_CONTROL         => 0              ,  --integer;
    ECC_MODE                => "no_ecc"       ,  --string; "no_ecc", "encode_only", "decode_only" or "both_encode_and_decode" 
    AUTO_SLEEP_TIME         => 0              ,  --Do not Change
    USE_EMBEDDED_CONSTRAINT => 0              ,  --integer: 0,1
    MEMORY_OPTIMIZATION     => "true"         ,  --string; "true", "false" 

    -- Port A module generics
    WRITE_DATA_WIDTH_A      => WIDTH          ,  --positive integer
    BYTE_WRITE_WIDTH_A      => WIDTH          ,  --integer; 8, 9, or WRITE_DATA_WIDTH_A value
    ADDR_WIDTH_A            => log2(DEPTH)    ,  --positive integer

    -- Port B module generics
    READ_DATA_WIDTH_B       => WIDTH          ,  --positive integer
    ADDR_WIDTH_B            => log2(DEPTH)    ,  --positive integer
    READ_RESET_VALUE_B      => "0"            ,  --string
    READ_LATENCY_B          => NPIPE          ,  --non-negative integer
    WRITE_MODE_B            => "read_first"     --string; "write_first", "read_first", "no_change" 
    )
    port map (

    -- Common module ports
    sleep                   => '0',

    -- Port A module ports
    clka                    => WCLK           ,
    ena                     => WE             ,
    wea                     => wea            ,
    addra                   => WADDR          ,
    dina                    => WDATA          ,
    injectsbiterra          => '0'            ,
    injectdbiterra          => '0'            ,

    -- Port B module ports
    clkb                    => RCLK           ,
    rstb                    => '0'            ,
    enb                     => enb_ext        ,
    regceb                  => '1'            ,
    addrb                   => RADDR          ,
    doutb                   => RDATA          ,
    sbiterrb                => open           ,
    dbiterrb                => open
  );

end Behavioral;

