--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : GSM_RSSI                                                       --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2021.11.08                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

Library UNISIM;
use UNISIM.vcomponents.all;
library UNIMACRO;
use unimacro.Vcomponents.all;

entity GSM_RSSI is
    generic (
        ANT_NUM                     : natural := 8
    );
    port (
        RESET                       : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        I_TS16_SYNC                 : in  std_logic;    
        I_TS_SYNC                   : in  std_logic;    -- 1 TS = 2216 or 2208 BF

        -- input data
        I_DATA_SYNC                 : in  std_logic;   -- chip sync
        I_DATA_IQ                   : in  std_logic_vector(15 downto 0);

        O_RSSI                      : out std_logic_array32(ANT_NUM-1 downto 0)

    );
end GSM_RSSI;

architecture BEHAVE of GSM_RSSI is


    signal clk_cnt          : std_logic_vector( 7 downto 0) := (others => '0');
    signal ts16_sync_d      : std_logic_vector(2 downto 0) := (others => '0'); 
    signal ts_sync_d        : std_logic_vector(2 downto 0) := (others => '0'); 
    signal ts16_sync_rpls   : std_logic := '0'; 
    signal ts_sync_rpls     : std_logic := '0'; 

    signal ts16_cnt_start   : std_logic := '0';
    signal ts_cnt           : std_logic_vector( 3 downto 0); 
    signal ts_sync_latch    : std_logic := '0';

    signal data_sync_d      : std_logic_vector( 2 downto 0) := (others => '0'); 
    signal data_iq_d        : std_logic_array16(2 downto 0) := (others => (others => '0')); 

    signal sample_cnt       : std_logic_vector( 9 downto 0) := (others => '0');      
    signal mult_in_data     : std_logic_vector(15 downto 0) := (others => '0');
    signal data_mult_out    : std_logic_vector(31 downto 0) := (others => '0');
    signal mult_out_41b     : std_logic_vector(40 downto 0) := (others => '0');
    signal sum_pwr          : std_logic_array42(15 downto 0) := (others => (others => '0'));
    signal sum_done         : std_logic_vector( 1 downto 0);
    signal ts_pwr_accum     : std_logic_array37(15 downto 0);
    signal ts_pwr_avg_d     : std_logic_array32(15 downto 0);
    signal ts_pwr_avg_dd    : std_logic_array32(15 downto 0);

begin

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            ts16_sync_d    <= ts16_sync_d(1 downto 0)   & I_TS16_SYNC;
            ts_sync_d      <= ts_sync_d(1 downto 0)     & I_TS_SYNC; 
            ts16_sync_rpls <= I_TS16_SYNC and (not ts16_sync_d(0));
            ts_sync_rpls   <= I_TS_SYNC   and (not ts_sync_d(0)  ); 
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            data_sync_d <= data_sync_d(1 downto 0) & I_DATA_SYNC;  
            data_iq_d   <= data_iq_d  (1 downto 0) & I_DATA_IQ;   
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (ts_sync_rpls = '1') then
                ts_sync_latch <= '1';
            elsif (data_sync_d(2) = '1') then
                ts_sync_latch <= '0';
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (data_sync_d(2) = '1') then
                clk_cnt <= (others => '0');
            else
                clk_cnt <= clk_cnt + 1;
            end if;
        end if;
    end process;

    -- sample count MAX 512 
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (data_sync_d(2) = '1') then
                if (ts_sync_latch = '1') then
                    sample_cnt <= (others => '0');
                elsif (sample_cnt > 512) then
                    sample_cnt <= sample_cnt;
                else
                    sample_cnt <= sample_cnt + 1;
                end if;
            end if;
        end if;
    end process;

    -- multiplier input
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (sample_cnt(9) = '0') then
                mult_in_data <= data_iq_d(2);
            else
                mult_in_data <= (others => '0');
            end if;
        end if;
    end process;

    mult_out_41b <= "000000000" & data_mult_out;
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            for i in 0 to 15 loop
            if (ts_sync_d = "01") then
                sum_pwr(i) <= (others => '0');
            else
                if (clk_cnt(7 downto 1) = i+2) then
                    sum_pwr(i) <= sum_pwr(i) + mult_out_41b;
                else
                    sum_pwr(i) <= sum_pwr(i);
                end if;
            end if;
            end loop;
        end if;
    end process;


    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (sample_cnt(9) = '1') then
                if (sample_cnt = 512 and clk_cnt = "10000000") then
                    sum_done(0) <= '1';
                else
                    sum_done(0) <= '0';
                end if;
            else
                sum_done(0) <= '0';
            end if;
            sum_done(1) <= sum_done(0);
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            -- 16 timeslot sync generation
            if ts16_sync_rpls = '1' then
                ts16_cnt_start <= '1';
            elsif sum_done = "01" then
                ts16_cnt_start <= '0';
            end if;
            -- start timeslot count at 1st sum done point(in 16TS period)
            if sum_done = "01" then
                if ts16_cnt_start = '1' then
                    ts_cnt <= "0001";
                else
                    ts_cnt <= ts_cnt + 1;
                end if;
            end if;
        end if;
	end process;

    -- Valid TS power sum
    TS_PWR_SUM_G : for i in 0 to 15 generate
	TS_PWR_SUM_GEN : process(RESET,CLK_SYSX8)
	begin
		if RESET = '1' then
            ts_pwr_accum(i)  <= (others => '0'); -- Non-selective Power measure
		elsif CLK_SYSX8 = '1' and CLK_SYSX8'event then
            if ts16_sync_rpls = '1' then  -- init
                ts_pwr_accum(i)  <= (others => '0');
            elsif sum_done = "01" then  -- accumulate 16 Timeslot power
                ts_pwr_accum(i) <= ts_pwr_accum(i) + sum_pwr(i)(40 downto 9);
            end if;
        end if;
		end process;
	end generate;

    -- 16 TS average power update
    OUT_G : for i in 0 to 15 generate
	OUT_GEN : process(RESET,CLK_SYSX8)
	begin
		if RESET = '1' then
            ts_pwr_avg_d(i) <= (others=>'0');
		elsif CLK_SYSX8 = '1' and CLK_SYSX8'event then
            -- update every 16 TS sync
            if ts16_sync_d = "01" then -- update average power value
                ts_pwr_avg_d(i) <= ts_pwr_accum(i)(35 downto 4);
            end if;
        end if;
	end process;
	end generate;
    
    O_RSSI <= ts_pwr_avg_d;

    -- latancy : 3-clock
    mult_16x16_iq : MULT_MACRO
    generic map (
        DEVICE        => "7SERIES"       , -- Target Device: "VIRTEX5", "VIRTEX6", "SPARTAN6"
        LATENCY       => 3               , -- Desired clock cycle latency, 0-4
        WIDTH_A       => 16              , -- Multiplier A-input bus width, 1-25
        WIDTH_B       => 16                -- Multiplier B-input bus width, 1-18
        )
    port map (
        P             => data_mult_out   , -- Multiplier output bus, width determined by WIDTH_P generic
        A             => mult_in_data    , -- Multiplier input A bus, width determined by WIDTH_A generic
        B             => mult_in_data    , -- Multiplier input B bus, width determined by WIDTH_B generic
        CE            => '1'             , -- 1-bit active high input clock enable
        CLK           => CLK_SYSX8             , -- 1-bit positive edge clock input
        RST           => RESET             -- 1-bit input active high reset
        );
    

end BEHAVE;






