--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Mapper switch                                                 --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
-- Target     : Mapper Max 8-ports                                            --
--              Formatter Max 8-ports                                         --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity MAP_SWITCH is
    generic (
        NUM_MAP                     : natural := 8;
        NUM_FMT                     : natural := 8
    );
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

--------------------------------------------------------------------------------
-- S/W control
--------------------------------------------------------------------------------

        MAPPER_UL_MAP               : in  std_logic_array16(NUM_MAP-1 downto 0);
        FORMATTER_DL_MAP            : in  std_logic_array16(NUM_FMT-1 downto 0);

--------------------------------------------------------------------------------
-- Mapper
--------------------------------------------------------------------------------

        DL_MAP_10MS                 : in  std_logic_vector(NUM_MAP-1 downto 0);
        DL_MAP_BFN                  : in  std_logic_array12(NUM_MAP-1 downto 0);
        DL_MAP_TDD                  : in  std_logic_vector(NUM_MAP-1 downto 0);
        DL_MAP_SYNC                 : in  std_logic_vector(NUM_MAP-1 downto 0);
        DL_MAP_DATA                 : in  std_logic_array16(NUM_MAP-1 downto 0);

        UL_MAP_10MS                 : out std_logic_vector(NUM_MAP-1 downto 0);
        UL_MAP_TDD                  : out std_logic_vector(NUM_MAP-1 downto 0);
        UL_MAP_SYNC                 : out std_logic_vector(NUM_MAP-1 downto 0);
        UL_MAP_DATA                 : out std_logic_array16(NUM_MAP-1 downto 0);

--------------------------------------------------------------------------------
-- Formatter
--------------------------------------------------------------------------------

        DL_FMT_10MS                 : out std_logic_vector(NUM_FMT-1 downto 0);
        DL_FMT_BFN                  : out std_logic_array12(NUM_FMT-1 downto 0);
        DL_FMT_TDD                  : out std_logic_vector(NUM_FMT-1 downto 0);
        DL_FMT_SYNC                 : out std_logic_vector(NUM_FMT-1 downto 0);
        DL_FMT_DATA                 : out std_logic_array16(NUM_FMT-1 downto 0);

        UL_FMT_10MS                 : in  std_logic_vector(NUM_FMT-1 downto 0);
        UL_FMT_TDD                  : in  std_logic_vector(NUM_FMT-1 downto 0);
        UL_FMT_SYNC                 : in  std_logic_vector(NUM_FMT-1 downto 0);
        UL_FMT_DATA                 : in  std_logic_array16(NUM_FMT-1 downto 0)
    );
end MAP_SWITCH;

architecture BEHAVE of MAP_SWITCH is

    signal dl_map_10ms_buf          : std_logic_vector(7 downto 0) := (others => '0');
    signal dl_map_bfn_buf           : std_logic_array12(7 downto 0) := (others => (others => '0'));
    signal dl_map_tdd_buf           : std_logic_vector(7 downto 0) := (others => '0');
    signal dl_map_sync_buf          : std_logic_vector(7 downto 0) := (others => '0');
    signal dl_map_data_buf          : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal ul_fmt_10ms_buf          : std_logic_vector(7 downto 0) := (others => '0');
    signal ul_fmt_tdd_buf           : std_logic_vector(7 downto 0) := (others => '0');
    signal ul_fmt_sync_buf          : std_logic_vector(7 downto 0) := (others => '0');
    signal ul_fmt_data_buf          : std_logic_array16(7 downto 0) := (others => (others => '0'));

begin

    PROCESSING_DELAY_DL <= conv_std_logic_vector(2, 24);
    PROCESSING_DELAY_UL <= conv_std_logic_vector(2, 24);

    u_DL_MASK : for i in NUM_MAP-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            dl_map_10ms_buf(i) <= DL_MAP_10MS(i);
            dl_map_bfn_buf(i)  <= DL_MAP_BFN(i);
            dl_map_tdd_buf(i)  <= DL_MAP_TDD(i);
            dl_map_sync_buf(i) <= DL_MAP_SYNC(i);
            dl_map_data_buf(i) <= DL_MAP_DATA(i);
        end if;
    end process;
    end generate;

    u_DL_FMT : for i in NUM_FMT-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case FORMATTER_DL_MAP(I) is
            when x"C000" => DL_FMT_10MS(i) <= dl_map_10ms_buf(0);
                            DL_FMT_BFN(i)  <= dl_map_bfn_buf(0);
                            DL_FMT_TDD(i)  <= dl_map_tdd_buf(0);
                            DL_FMT_SYNC(i) <= dl_map_sync_buf(0);
                            DL_FMT_DATA(i) <= dl_map_data_buf(0);
            when x"C001" => DL_FMT_10MS(i) <= dl_map_10ms_buf(1);
                            DL_FMT_BFN(i)  <= dl_map_bfn_buf(1);
                            DL_FMT_TDD(i)  <= dl_map_tdd_buf(1);
                            DL_FMT_SYNC(i) <= dl_map_sync_buf(1);
                            DL_FMT_DATA(i) <= dl_map_data_buf(1);
            when x"C002" => DL_FMT_10MS(i) <= dl_map_10ms_buf(2);
                            DL_FMT_BFN(i)  <= dl_map_bfn_buf(2);
                            DL_FMT_TDD(i)  <= dl_map_tdd_buf(2);
                            DL_FMT_SYNC(i) <= dl_map_sync_buf(2);
                            DL_FMT_DATA(i) <= dl_map_data_buf(2);
            when x"C003" => DL_FMT_10MS(i) <= dl_map_10ms_buf(3);
                            DL_FMT_BFN(i)  <= dl_map_bfn_buf(3);
                            DL_FMT_TDD(i)  <= dl_map_tdd_buf(3);
                            DL_FMT_SYNC(i) <= dl_map_sync_buf(3);
                            DL_FMT_DATA(i) <= dl_map_data_buf(3);
            when x"C004" => DL_FMT_10MS(i) <= dl_map_10ms_buf(4);
                            DL_FMT_BFN(i)  <= dl_map_bfn_buf(4);
                            DL_FMT_TDD(i)  <= dl_map_tdd_buf(4);
                            DL_FMT_SYNC(i) <= dl_map_sync_buf(4);
                            DL_FMT_DATA(i) <= dl_map_data_buf(4);
            when x"C005" => DL_FMT_10MS(i) <= dl_map_10ms_buf(5);
                            DL_FMT_BFN(i)  <= dl_map_bfn_buf(5);
                            DL_FMT_TDD(i)  <= dl_map_tdd_buf(5);
                            DL_FMT_SYNC(i) <= dl_map_sync_buf(5);
                            DL_FMT_DATA(i) <= dl_map_data_buf(5);
            when x"C006" => DL_FMT_10MS(i) <= dl_map_10ms_buf(6);
                            DL_FMT_BFN(i)  <= dl_map_bfn_buf(6);
                            DL_FMT_TDD(i)  <= dl_map_tdd_buf(6);
                            DL_FMT_SYNC(i) <= dl_map_sync_buf(6);
                            DL_FMT_DATA(i) <= dl_map_data_buf(6);
            when x"C007" => DL_FMT_10MS(i) <= dl_map_10ms_buf(7);
                            DL_FMT_BFN(i)  <= dl_map_bfn_buf(7);
                            DL_FMT_TDD(i)  <= dl_map_tdd_buf(7);
                            DL_FMT_SYNC(i) <= dl_map_sync_buf(7);
                            DL_FMT_DATA(i) <= dl_map_data_buf(7);
            when others  => DL_FMT_10MS(i) <= dl_map_10ms_buf(0);
                            DL_FMT_BFN(i)  <= dl_map_bfn_buf(0);
                            DL_FMT_TDD(i)  <= dl_map_tdd_buf(0); 
                            DL_FMT_SYNC(i) <= dl_map_sync_buf(0);
                            DL_FMT_DATA(i) <= (others => '0');
            end case;
        end if;
    end process;
    end generate;

    u_UL_MASK : for i in NUM_FMT-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            ul_fmt_10ms_buf(i) <= UL_FMT_10MS(i);
            ul_fmt_tdd_buf(i)  <= UL_FMT_TDD(i);
            ul_fmt_sync_buf(i) <= UL_FMT_SYNC(i);
            ul_fmt_data_buf(i) <= UL_FMT_DATA(i);
        end if;
    end process;
    end generate;

    u_UL_MAP : for i in NUM_MAP-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case MAPPER_UL_MAP(i) is
            when x"F000" => UL_MAP_10MS(i) <= ul_fmt_10ms_buf(0);
                            UL_MAP_TDD(i)  <= ul_fmt_tdd_buf(0);
                            UL_MAP_SYNC(i) <= ul_fmt_sync_buf(0);
                            UL_MAP_DATA(i) <= ul_fmt_data_buf(0);
            when x"F001" => UL_MAP_10MS(i) <= ul_fmt_10ms_buf(1);
                            UL_MAP_TDD(i)  <= ul_fmt_tdd_buf(1);
                            UL_MAP_SYNC(i) <= ul_fmt_sync_buf(1);
                            UL_MAP_DATA(i) <= ul_fmt_data_buf(1);
            when x"F002" => UL_MAP_10MS(i) <= ul_fmt_10ms_buf(2);
                            UL_MAP_TDD(i)  <= ul_fmt_tdd_buf(2);
                            UL_MAP_SYNC(i) <= ul_fmt_sync_buf(2);
                            UL_MAP_DATA(i) <= ul_fmt_data_buf(2);
            when x"F003" => UL_MAP_10MS(i) <= ul_fmt_10ms_buf(3);
                            UL_MAP_TDD(i)  <= ul_fmt_tdd_buf(3);
                            UL_MAP_SYNC(i) <= ul_fmt_sync_buf(3);
                            UL_MAP_DATA(i) <= ul_fmt_data_buf(3);
            when x"F004" => UL_MAP_10MS(i) <= ul_fmt_10ms_buf(4);
                            UL_MAP_TDD(i)  <= ul_fmt_tdd_buf(4);
                            UL_MAP_SYNC(i) <= ul_fmt_sync_buf(4);
                            UL_MAP_DATA(i) <= ul_fmt_data_buf(4);
            when x"F005" => UL_MAP_10MS(i) <= ul_fmt_10ms_buf(5);
                            UL_MAP_TDD(i)  <= ul_fmt_tdd_buf(5);
                            UL_MAP_SYNC(i) <= ul_fmt_sync_buf(5);
                            UL_MAP_DATA(i) <= ul_fmt_data_buf(5);
            when x"F006" => UL_MAP_10MS(i) <= ul_fmt_10ms_buf(6);
                            UL_MAP_TDD(i)  <= ul_fmt_tdd_buf(6);
                            UL_MAP_SYNC(i) <= ul_fmt_sync_buf(6);
                            UL_MAP_DATA(i) <= ul_fmt_data_buf(6);
            when x"F007" => UL_MAP_10MS(i) <= ul_fmt_10ms_buf(7);
                            UL_MAP_TDD(i)  <= ul_fmt_tdd_buf(7);
                            UL_MAP_SYNC(i) <= ul_fmt_sync_buf(7);
                            UL_MAP_DATA(i) <= ul_fmt_data_buf(7);
            when others  => UL_MAP_10MS(i) <= ul_fmt_10ms_buf(0); 
                            UL_MAP_TDD(i)  <= ul_fmt_tdd_buf(0); 
                            UL_MAP_SYNC(i) <= ul_fmt_sync_buf(0); 
                            UL_MAP_DATA(i) <= (others => '0');
            end case;
        end if;
    end process;
    end generate;

end BEHAVE;