--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Pulse delay (Multi-edge)                                      --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------
-- Processing delay 6-clocks                                                  --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity DELAY_PULSE_ME is
    generic (
        DELAY_RANGE                 : natural := 32;                            -- Maximum bit width to set maximum value + 1
        TRANSITION                  : natural := 2
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;
        DELAY_VALUE                 : in  std_logic_vector(DELAY_RANGE-1 downto 0);
        SYNC_IN                     : in  std_logic;
        SYNC_OUT                    : out std_logic
    );
end DELAY_PULSE_ME;

architecture BEHAVE of DELAY_PULSE_ME is

    signal sync_in_buf              : std_logic := '0';
    signal sync_out_buf             : std_logic_vector(TRANSITION-1 downto 0);
    signal cnt_path                 : natural range 0 to TRANSITION-1;
    signal path_on                  : std_logic_vector(TRANSITION-1 downto 0) := (others => '0');

    component DELAY_PULSE_SE is
    generic (
        DELAY_RANGE                 : natural := 32
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;
        DELAY_VALUE                 : in  std_logic_vector(DELAY_RANGE-1 downto 0);
        SYNC_IN                     : in  std_logic;
        SYNC_OUT                    : out std_logic
    );
    end component;

    signal delay_sync_in            : std_logic_vector(TRANSITION-1 downto 0);
    signal delay_sync_out           : std_logic_vector(TRANSITION-1 downto 0);
    signal delay_sync               : std_logic_vector(TRANSITION-1 downto 0);

begin

    -- buffering
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            sync_in_buf  <= SYNC_IN;
            sync_out_buf <= delay_sync_out;
        end if;
    end process;

    -- select unit
    process (RESET, CLK)
    begin
        if (RESET = '1') then
            cnt_path <= 0;
            path_on  <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            if (SYNC_IN = '0') and (sync_in_buf = '1') then
                if (cnt_path = TRANSITION-1) then
                    cnt_path      <= 0;
                else
                    cnt_path      <= cnt_path + 1;
                end if;
            end if;
            for i in TRANSITION-1 downto 0 loop
            if (delay_sync_out(i) = '0') and (sync_out_buf(i) = '1') then
                path_on(i) <= '0';
            elsif (SYNC_IN = '1') and (sync_in_buf = '0') then
                if (cnt_path = i) then
                    path_on(i) <= '1';
                end if;
            end if;
            end loop;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            for i in TRANSITION-1 downto 0 loop
            if (cnt_path = i) then
                delay_sync_in(i) <= sync_in_buf;
            else
                delay_sync_in(i) <= '0';
            end if;
            end loop;
        end if;
    end process;

    delay_sync <= path_on and delay_sync_out;

    process (RESET, CLK)
    begin
        if (RESET = '1') then
            SYNC_OUT <= '0';
        elsif (CLK'event and CLK = '1') then
            if (delay_sync = 0) then
                SYNC_OUT <= '0';
            else
                SYNC_OUT <= '1';
            end if;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_UNIT : for i in TRANSITION-1 downto 0 generate
    u_DELAY_UNIT : DELAY_PULSE_SE
    generic map(
        DELAY_RANGE                 => DELAY_RANGE                              --: natural := 32
    )
    port map(
        RESET                       => RESET                                   ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;
        DELAY_VALUE                 => DELAY_VALUE                             ,--: in  std_logic_vector(DELAY_RANGE-1 downto 0);
        SYNC_IN                     => delay_sync_in(i)                        ,--: in  std_logic;
        SYNC_OUT                    => delay_sync_out(i)                        --: out std_logic
    );
    end generate;

end BEHAVE;