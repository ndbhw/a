-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2023, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2023.05.17 v1.0] Initial release
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

entity cpri_delay_compensation is
	Port ( 
		i_rst							: in std_logic;
		i_clk							: in std_logic;
		
		o_processing_delay              : out std_logic_vector(24-1 downto 0);		
		i_10ms_dly_value				: in std_logic_vector(16-1 downto 0);
		i_data_dly_value				: in std_logic_vector(16-1 downto 0);
		
		i_10ms							: in std_logic;
		i_tdd							: in std_logic;
		i_sync							: in std_logic;
		i_data_iq						: in std_logic_vector(16-1 downto 0);
		
		o_10ms							: out std_logic;
		o_tdd							: out std_logic;
		o_sync							: out std_logic;
		o_data_iq						: out std_logic_vector(16-1 downto 0)
	);
end cpri_delay_compensation;

architecture Behavioral of cpri_delay_compensation is
	
	-- MIN DLY VALUE  : 3
	-- MAX DLY VALUE  : 32767 (133 usec)
	-- MODULE LATENCY : 6 clk
	
	constant M_TYPE							: string := "ultra";
	constant M_RD_LATENCY					: integer := 2;
	constant M_D_WIDTH						: integer := 18*4;		-- 72
	constant M_ADDR_DWIDTH					: integer := 13;		-- 8k
	
	component bbctrl_pulse_delay is
		Port ( 
			i_rst							: in std_logic;
			i_clk							: in std_logic;
			
			i_10ms_dly_value				: in std_logic_vector(16-1 downto 0);
			
			i_pulse							: in std_logic;
			o_pulse							: out std_logic
		);
	end component bbctrl_pulse_delay;
	
	component ulfe_lib_sdpram_v2 is
		generic (
			memory_primitive				: string := "block";
			read_latency					: integer := 2;
			wt_mem_d_width					: integer := 30;
			rd_mem_d_width					: integer := 60;
			wt_max_addr_d_width				: integer := 12;
			rd_max_addr_d_width				: integer := 12
		);
		Port (
			i_clk	                     	: in std_logic;
			
			i_wt_enable						: in std_logic;
			i_wt_addr						: in std_logic_vector(wt_max_addr_d_width-1 downto 0);
			i_wt_data						: in std_logic_vector(wt_mem_d_width-1 downto 0);
			
			i_rd_addr						: in std_logic_vector(rd_max_addr_d_width-1 downto 0);
			o_rd_dout						: out std_logic_vector(rd_mem_d_width-1 downto 0)
		);
	end component ulfe_lib_sdpram_v2;
	
	signal  r_data_dly_value				: std_logic_vector(15-1 downto 0);
	signal  r_data							: std_logic_vector(18-1 downto 0);
	
	signal  wt_enable						: std_logic;
	signal  wt_addr_lsb						: std_logic_vector(2-1 downto 0);
	signal  wt_addr_lsb_1d					: std_logic_vector(2-1 downto 0);
	signal  wt_addr_msb						: std_logic_vector(M_ADDR_DWIDTH-1 downto 0);
	signal  wt_data							: std_logic_vector(M_D_WIDTH-1 downto 0);
	
	signal  rd_addr							: std_logic_vector(M_ADDR_DWIDTH+2-1 downto 0);
	signal  rd_addr_1d						: std_logic_vector(2-1 downto 0);
	signal  rd_addr_2d						: integer range 0 to 4-1;
	signal  rd_data							: std_logic_vector(M_D_WIDTH-1 downto 0);
	
	signal  dly_10ms_pulse					: std_logic;
	signal  dly_10ms_pulse_1d				: std_logic;
	signal  dly_10ms_pulse_2d				: std_logic;
	
begin

    o_processing_delay                      <=  conv_std_logic_vector(6,24);       
	
	--------------------------------------------------------------------------------------------
	-- receive data	
	process(i_clk)
	begin
		if (rising_edge(i_clk)) then
			if (i_data_dly_value < conv_std_logic_vector(3, 16)) then
				r_data_dly_value			<=	conv_std_logic_vector(3, 15);
			elsif (i_data_dly_value > conv_std_logic_vector(32767, 16)) then
				r_data_dly_value			<=	conv_std_logic_vector(32767, 15);
			else
				r_data_dly_value			<=	i_data_dly_value(14 downto 0);
			end if;
			
			r_data							<=	i_tdd & i_sync & i_data_iq;
		end if;
	end process;
	
	--------------------------------------------------------------------------------------------
	-- write process
	process(i_rst, i_clk)
	begin
		if (i_rst = '1') then
			wt_addr_lsb						<=	(others=>'0');
			wt_addr_msb						<=	(others=>'0');
		elsif (rising_edge(i_clk)) then
			if (wt_addr_lsb = b"11") then
				wt_enable					<=	'1';
			else
				wt_enable					<=	'0';
			end if;
			
			if (i_sync = '1') then
				wt_addr_lsb					<=	(others=>'0');
			else
				wt_addr_lsb					<=	wt_addr_lsb + '1';
			end if;
			
			if (wt_enable = '1') then
				wt_addr_msb					<=	wt_addr_msb + '1';
			else
				wt_addr_msb					<=	wt_addr_msb;
			end if;
		end if;
	end process;
	
	process(i_clk)
	begin
		if (rising_edge(i_clk)) then
			wt_data							<=	r_data & wt_data(71 downto 18);
			wt_addr_lsb_1d					<=	wt_addr_lsb;
		end if;
	end process;
	
	--------------------------------------------------------------------------------------------
	-- read process
	process(i_clk)
	begin
		if (rising_edge(i_clk)) then
			if ((wt_addr_msb = r_data_dly_value(14 downto 2)) and (wt_addr_lsb_1d = r_data_dly_value(1 downto 0))) then
				rd_addr						<=	(others=>'0');
			else
				rd_addr						<=	rd_addr + '1';
			end if;
			
			-- Read latency 2clk
			rd_addr_1d						<=	rd_addr(1 downto 0);
			rd_addr_2d						<=	conv_integer(rd_addr_1d);
		end if;
	end process;
	
	--------------------------------------------------------------------------------------------
	-- data buffer
	data_buffer : ulfe_lib_sdpram_v2 generic map(M_TYPE,M_RD_LATENCY,M_D_WIDTH,M_D_WIDTH,M_ADDR_DWIDTH,M_ADDR_DWIDTH)
		port map(
			i_clk	    					=>	i_clk,
		    
		    i_wt_enable						=>	wt_enable,
		    i_wt_addr						=>	wt_addr_msb,
		    i_wt_data						=>	wt_data,
		    
			i_rd_addr						=>	rd_addr(M_ADDR_DWIDTH+2-1 downto 2),
		    o_rd_dout						=>	rd_data
		);
	
	--------------------------------------------------------------------------------------------
	-- 10ms sig delay (latency 3clk)
	u_pulse_delay : bbctrl_pulse_delay port map(i_rst, i_clk, i_10ms_dly_value, i_10ms, dly_10ms_pulse);
	
	process(i_clk)
	begin
		if (rising_edge(i_clk)) then
			dly_10ms_pulse_1d				<=	dly_10ms_pulse;
			dly_10ms_pulse_2d				<=	dly_10ms_pulse_1d;
		end if;
	end process;
	
	--------------------------------------------------------------------------------------------
	-- output
	process(i_clk)
	begin
		if (rising_edge(i_clk)) then
			o_10ms							<=	dly_10ms_pulse_2d;
			
			o_tdd							<=	rd_data(17+(18*rd_addr_2d));
			o_sync							<=	rd_data(16+(18*rd_addr_2d));
			o_data_iq						<=	rd_data(15+(18*rd_addr_2d) downto (18*rd_addr_2d));
		end if;
	end process;
	
end Behavioral;