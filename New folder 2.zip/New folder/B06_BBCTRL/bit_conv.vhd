--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : CPRI interface                                                --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--          Not support clock domain crossing                                 --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity BIT_CONV is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        CLK_CPRI                    : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        I_RX_TDD                    : in  std_logic;

--------------------------------------------------------------------------------
-- SBIF
--------------------------------------------------------------------------------

        LINE_RCF_CLKTYPE            : in  std_logic_vector(7 downto 0);

        I_RX_BFN_STRB               : in  std_logic;
        I_RX_BFN                    : in  std_logic_vector(11 downto 0);
        I_RX_VLD                    : in  std_logic;
        I_RX_I                      : in  std_logic_vector(15 downto 0);
        I_RX_Q                      : in  std_logic_vector(15 downto 0);

        O_TX_10MS                   : out std_logic;
        O_TX_TDD                    : out std_logic;
        I_TX_ENB                    : in  std_logic;
        O_TX_I                      : out std_logic_vector(15 downto 0);
        O_TX_Q                      : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- DDUC_IF
--------------------------------------------------------------------------------

        O_RX_10MS                   : out std_logic;
        O_RX_BFN                    : out std_logic_vector(11 downto 0);
        O_RX_TDD                    : out std_logic;
        O_RX_SYNC                   : out std_logic;
        O_RX_DATA_I                 : out std_logic_vector(15 downto 0);
        O_RX_DATA_Q                 : out std_logic_vector(15 downto 0);

        I_TX_10MS                   : in  std_logic;
        I_TX_TDD                    : in  std_logic;
        O_TX_SYNC                   : out std_logic;
        I_TX_DATA_I                 : in  std_logic_vector(15 downto 0);
        I_TX_DATA_Q                 : in  std_logic_vector(15 downto 0)
    );
end BIT_CONV;

architecture BEHAVE of BIT_CONV is

    signal tx_10ms_d                : std_logic_vector(14 downto 0) := (others => '0'); 
    signal tx_tdd_d                 : std_logic_vector(14 downto 0) := (others => '0'); 

    component CONV_16TO15 is
    port (
        CLK                         : in  std_logic;

        CONV_IN_10MS                : in  std_logic;
        CONV_IN_TDD                 : in  std_logic;
        CONV_IN_SYNC                : in  std_logic;
        CONV_IN_DATA_I              : in  std_logic_vector(15 downto 0);
        CONV_IN_DATA_Q              : in  std_logic_vector(15 downto 0);

        CONV_OUT_10MS               : out std_logic;
        CONV_OUT_TDD                : out std_logic;
        CONV_OUT_SYNC               : out std_logic;
        CONV_OUT_DATA_I             : out std_logic_vector(14 downto 0);
        CONV_OUT_DATA_Q             : out std_logic_vector(14 downto 0)
    );
    end component;

    signal dl_conv_out_data_i       : std_logic_vector(14 downto 0);
    signal dl_conv_out_data_q       : std_logic_vector(14 downto 0);

    component CONV_15TO16 is
    port (
        CLK                         : in  std_logic;

        LINE_RCF_CLKTYPE            : in  std_logic_vector(7 downto 0);
    
        CONV_IN_SYNC                : in  std_logic;
        CONV_IN_DATA_I              : in  std_logic_vector(14 downto 0);
        CONV_IN_DATA_Q              : in  std_logic_vector(14 downto 0);

        CONV_OUT_SYNC               : out std_logic;
        CONV_OUT_DATA_I             : out std_logic_vector(15 downto 0);
        CONV_OUT_DATA_Q             : out std_logic_vector(15 downto 0)
    );
    end component;

    signal ul_conv_in_data_i        : std_logic_vector(14 downto 0);
    signal ul_conv_in_data_q        : std_logic_vector(14 downto 0);

begin

    process (LINE_RCF_CLKTYPE)
    begin
        case LINE_RCF_CLKTYPE is
        when x"20"  => PROCESSING_DELAY_DL <= conv_std_logic_vector( 6, 24);
                       PROCESSING_DELAY_UL <= conv_std_logic_vector(16, 24);
        when x"40"  => PROCESSING_DELAY_DL <= conv_std_logic_vector( 3, 24);
                       PROCESSING_DELAY_UL <= conv_std_logic_vector( 7, 24);
        when others => PROCESSING_DELAY_DL <= (others => '0');
                       PROCESSING_DELAY_UL <= (others => '0');
        end case;
    end process;

    -- Didn't be aligned to 10msec signal.
    O_RX_BFN <= I_RX_BFN + 1;

    O_RX_DATA_I <= dl_conv_out_data_i(14) & dl_conv_out_data_i;
    O_RX_DATA_Q <= dl_conv_out_data_q(14) & dl_conv_out_data_q;

    ul_conv_in_data_i <= I_TX_DATA_I(14 downto 0);
    ul_conv_in_data_q <= I_TX_DATA_Q(14 downto 0);

    process(CLK_CPRI)
    begin
        if (CLK_CPRI'event and CLK_CPRI = '1') then
            tx_10ms_d <= tx_10ms_d(13 downto 0) & I_TX_10MS;
            tx_tdd_d  <= tx_tdd_d(13 downto 0) & I_TX_TDD;
            if (LINE_RCF_CLKTYPE = x"20") then
                O_TX_10MS <= tx_10ms_d(14);   
                O_TX_TDD  <= tx_tdd_d (14);   
            else
                O_TX_10MS <= tx_10ms_d(5);   
                O_TX_TDD  <= tx_tdd_d (5);   
            end if;
        end if;
    end process;
            

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_DL_CONV : CONV_16TO15
    port map(
        CLK                         => CLK_CPRI                                ,--: in  std_logic;

        CONV_IN_10MS                => I_RX_BFN_STRB                           ,--: in  std_logic;
        CONV_IN_TDD                 => I_RX_TDD                                ,--: in  std_logic;
        CONV_IN_SYNC                => I_RX_VLD                                ,--: in  std_logic;
        CONV_IN_DATA_I              => I_RX_I                                  ,--: in  std_logic_vector(15 downto 0);
        CONV_IN_DATA_Q              => I_RX_Q                                  ,--: in  std_logic_vector(15 downto 0);

        CONV_OUT_10MS               => O_RX_10MS                               ,--: out std_logic;
        CONV_OUT_TDD                => O_RX_TDD                                ,--: out std_logic;
        CONV_OUT_SYNC               => O_RX_SYNC                               ,--: out std_logic;
        CONV_OUT_DATA_I             => dl_conv_out_data_i                      ,--: out std_logic_vector(14 downto 0);
        CONV_OUT_DATA_Q             => dl_conv_out_data_q                       --: out std_logic_vector(14 downto 0)
    );

    u_UL_CONV : CONV_15TO16
    port map(
        CLK                         => CLK_CPRI                                ,--: in  std_logic;

        LINE_RCF_CLKTYPE            => LINE_RCF_CLKTYPE                        ,--: in  std_logic_vector(7 downto 0);
    
        CONV_OUT_SYNC               => O_TX_SYNC                               ,--: out std_logic;
        CONV_IN_DATA_I              => ul_conv_in_data_i                       ,--: in  std_logic_vector(14 downto 0);
        CONV_IN_DATA_Q              => ul_conv_in_data_q                       ,--: in  std_logic_vector(14 downto 0);

        CONV_IN_SYNC                => I_TX_ENB                                ,--: in  std_logic;
        CONV_OUT_DATA_I             => O_TX_I                                  ,--: out std_logic_vector(15 downto 0);
        CONV_OUT_DATA_Q             => O_TX_Q                                   --: out std_logic_vector(15 downto 0)
    );

end BEHAVE;
