--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : DUC_IF                                                        --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2021.11.08                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity GSM_DUC_IF is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        RESET                       : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);

--------------------------------------------------------------------------------
-- SBIF
--------------------------------------------------------------------------------

        I_RX_120MS                  : in  std_logic;
        I_RX_10MS                   : in  std_logic;
        I_RX_BFN                    : in  std_logic_vector(11 downto 0);
        I_RX_TDD                    : in  std_logic;
        I_RX_SYNC                   : in  std_logic;
        I_RX_DATA_I                 : in  std_logic_vector(15 downto 0);
        I_RX_DATA_Q                 : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- FORMATTER
--------------------------------------------------------------------------------

        O_DL_120MS                  : out std_logic;
        O_DL_10MS                   : out std_logic;
        O_DL_BFN                    : out std_logic_vector(11 downto 0);
        O_DL_TDD                    : out std_logic;
        O_DL_SYNC                   : out std_logic;
        O_DL_DATA                   : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- DSP_TOP
--------------------------------------------------------------------------------

        O_DL_GAIN                   : out std_logic_array10(7 downto 0); 
        O_DL_ARFCN                  : out std_logic_array10(7 downto 0); 
        O_UL_ARFCN                  : out std_logic_array10(7 downto 0) 

    );
end GSM_DUC_IF;

architecture BEHAVE of GSM_DUC_IF is

    function log2 (data_value : integer)
    return integer is
        variable result      : integer := 0;
        variable cnt         : integer := 1;
    begin
        if (data_value <= 1) then
            result     := 0;
        else
            while (cnt < data_value) loop
                result := result + 1;
                cnt    := cnt *2;
            end loop;
        end if;
        return result;
    end log2;

    signal strb_120ms               : std_logic := '0';
    signal bfn_strb                 : std_logic := '0'; 
    signal tdd                      : std_logic := '0'; 
    signal i_data                   : std_logic_vector(15 downto 0) := (others => '0'); 
    signal q_data                   : std_logic_vector(15 downto 0) := (others => '0'); 
    signal cnt_sync                 : std_logic_vector( 6 downto 0) := (others => '0');
    signal cnt_sync_r                 : std_logic_vector( 6 downto 0) := (others => '0');
    signal sample_sync              : std_logic := '0';

    component bb_buf is
    generic(
        STYLE                       : string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
        NPIPE                       : integer := 6;
        DEPTH                       : integer := 8192;
        WIDTH                       : integer := 72
    );
    port(
        WCLK                        : in  std_logic;
        RCLK                        : in  std_logic;
        WE                          : in  std_logic;
        ENB                         : in  std_logic;
        WADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
        RADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
        WDATA                       : in  std_logic_vector(WIDTH-1 downto 0);
        RDATA                       : out std_logic_vector(WIDTH-1 downto 0)
    );
    end component;

    signal wr_bank                  : std_logic := '0';
    signal wr_addr_l                : std_logic_vector( 3 downto 0) := (others => '0');
    signal wr_data                  : std_logic_vector(34 downto 0) := (others => '0');  
    signal wr_addr_in               : std_logic_vector( 4 downto 0) := (others => '0'); 
    signal wr_data_in               : std_logic_vector(34 downto 0) := (others => '0'); 
    signal wr_en                    : std_logic := '0';
    signal wr_en_in                 : std_logic := '0';

    signal rd_en                    : std_logic := '0';
    signal rd_bank                  : std_logic := '0';
    signal rd_addr_l                : std_logic_vector( 3 downto 0) := (others => '0');
    signal rd_data                  : std_logic_vector(34 downto 0) := (others => '0');  
    signal rd_addr_in               : std_logic_vector( 4 downto 0) := (others => '0'); 

begin

    PROCESSING_DELAY_DL <= conv_std_logic_vector(22,24);

    O_DL_BFN <= I_RX_BFN;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            strb_120ms <= I_RX_120MS;
            bfn_strb   <= I_RX_10MS;
            tdd        <= I_RX_TDD;
            i_data     <= I_RX_DATA_I;
            q_data     <= I_RX_DATA_Q;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (I_RX_SYNC = '1') then
                cnt_sync(5 downto 0) <= (others => '1');
            elsif (cnt_sync(5 downto 0) = "111111" and I_RX_120MS = '1') then
                cnt_sync(6) <= '0';
                cnt_sync(5 downto 0) <= (others => '0');
            elsif (cnt_sync(5 downto 0) = "111111") then
                cnt_sync(6) <= not cnt_sync(6);
                cnt_sync(5 downto 0) <= (others => '0');
            else
                cnt_sync(6) <= cnt_sync(6);
                cnt_sync(5 downto 0) <= cnt_sync(5 downto 0) + 1;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            wr_bank    <= cnt_sync(4);
            wr_addr_l  <= cnt_sync(3 downto 0);
            wr_data    <= strb_120ms & bfn_strb & tdd & i_data & q_data;
            wr_addr_in <= wr_bank & wr_addr_l;
            wr_data_in <= wr_data;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_sync(6 downto 5) = "00") then
                wr_en <= '1';
            else
                wr_en <= '0';
            end if;
            wr_en_in <= wr_en;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            rd_bank <= not wr_bank;
            if (wr_addr_l(3 downto 0) = 0) then
                rd_addr_l <= (others => '0');
            else
                rd_addr_l <= rd_addr_l + 1;
            end if;
            rd_addr_in <= rd_bank & '0' & rd_addr_l(3 downto 1);
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_sync = 17) then
                cnt_sync_r <= (others => '0');
            else
                cnt_sync_r <= cnt_sync_r + 1;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_sync_r(6 downto 4) = "000") then
                rd_en <= '1';
            else
                rd_en <= '0';
            end if;
        end if;
    end process;
    
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            O_DL_120MS <= rd_data(34);
            O_DL_10MS  <= rd_data(33);
            O_DL_TDD   <= rd_data(32);

            if (rd_addr_l(0) = '1') then
                O_DL_DATA <= rd_data(31 downto 16);
            else
                O_DL_DATA <= rd_data(15 downto 0);
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_sync = 20) then
                sample_sync <= '1';
            else
                sample_sync <= '0';
            end if;
            O_DL_SYNC <= sample_sync;
        end if;
    end process;

    u_dl_map_buf : bb_buf 
    generic map(
        STYLE                       => "BLOCK"       , --: string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
        NPIPE                       => 2             , --: integer := 6;
        DEPTH                       => 32            , --: integer := 8192;
        WIDTH                       => 35              --: integer := 72
    )
    port map(
        WCLK                        => CLK_SYSX8            , --: in  std_logic;
        RCLK                        => CLK_SYSX8            , --: in  std_logic;
        WE                          => wr_en_in             , --: in  std_logic;
        ENB                         => rd_en                , --: in  std_logic;
        WADDR                       => wr_addr_in           , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        RADDR                       => rd_addr_in           , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        WDATA                       => wr_data_in           , --: in  std_logic_vector(WIDTH-1 downto 0);
        RDATA                       => rd_data              --: out std_logic_vector(WIDTH-1 downto 0)
    );

--------------------------------------------------------------------------------
-- ARFCN
--------------------------------------------------------------------------------

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            for i in 0 to 7 loop
           if (cnt_sync = 32 + i) then
                O_DL_GAIN(i)  <= i_data(14 downto 10) & q_data(14 downto 10);
                O_DL_ARFCN(i) <= i_data( 9 downto 0);
                O_UL_ARFCN(i) <= q_data( 9 downto 0);
            end if;
            end loop;
        end if;
    end process;

end BEHAVE;



