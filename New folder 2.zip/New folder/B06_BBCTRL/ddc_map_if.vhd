--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : DDC_MAP_IF                                                        --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2021.11.08                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity DDC_MAP_IF is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        ARESET                      : in  std_logic;

        CLK_AUX                     : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        BW_SEL                      : in  std_logic_array4(3 downto 0);

--------------------------------------------------------------------------------
-- BIT_CONV
--------------------------------------------------------------------------------

        O_TX_10MS                   : out std_logic;
        O_TX_TDD                    : out std_logic;
        I_TX_SYNC                   : in  std_logic;
        O_TX_DATA_I                 : out std_logic_vector(15 downto 0);
        O_TX_DATA_Q                 : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- FORMATTER
--------------------------------------------------------------------------------

        I_UL_10MS                   : in  std_logic;
        I_UL_TDD                    : in  std_logic;
        I_UL_SYNC                   : in  std_logic_vector(3 downto 0);
        I_UL_DATA                   : in  std_logic_array16(3 downto 0)

    );
end DDC_MAP_IF;

architecture BEHAVE of DDC_MAP_IF is

    component UL_MAP_IF is
    port (
        ARESET                      : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        BW_SEL                      : in  std_logic_vector(3 downto 0);    -- 5M: 0x2 / 10M: 0x3 / 15M: 0x4 / 20M: 0x5 
        CC_SEL                      : in  std_logic_vector(3 downto 0);

        O_UL_FSYNC                  : out std_logic;
        O_UL_TDD                    : out std_logic;
        O_UL_VLD                    : out std_logic_vector( 3 downto 0);    -- valid signal for valid data.   
        I_UL_TX_EN                  : in  std_logic;
        O_UL_DATA_I                 : out std_logic_vector(15 downto 0);
        O_UL_DATA_Q                 : out std_logic_vector(15 downto 0);

        I_UL_FSYNC                  : in  std_logic;
        I_UL_TDD                    : in  std_logic;
        I_UL_SYNC                   : in  std_logic;
        I_UL_DATA                   : in  std_logic_vector(15 downto 0)

    );
    end component;

    signal cc_num                   : std_logic_array4(3 downto 0) := (others => (others => '0'));
    signal proc_dly                 : std_logic_vector(23 downto 0) := (others => '0');
    signal tx_data_i                : std_logic_array16(3 downto 0) := (others => (others => '0')); 
    signal tx_data_q                : std_logic_array16(3 downto 0) := (others => (others => '0')); 

    signal tx_10ms                  : std_logic_vector(3 downto 0) := (others => '0'); 
    signal tx_tdd                   : std_logic_vector(3 downto 0) := (others => '0'); 
    
begin

    PROCESSING_DELAY_UL <= conv_std_logic_vector(140,24);    

    O_TX_10MS <= tx_10ms(0); 
    O_TX_TDD  <= tx_tdd (0);

    O_TX_DATA_I <= tx_data_i(0) or tx_data_i(1) or tx_data_i(2) or tx_data_i(3); 
    O_TX_DATA_Q <= tx_data_q(0) or tx_data_q(1) or tx_data_q(2) or tx_data_q(3);

    G_CC_NUM : for i in 3 downto 0 generate   

    cc_num(i) <= conv_std_logic_vector(i,4);

    U_UL_MAP_IF : UL_MAP_IF 
    port map(
        ARESET                      => ARESET       , --: in  std_logic;
        CLK_SYSX8                   => CLK_SYSX8    , --: in  std_logic;

        PROCESSING_DELAY_UL         => proc_dly     , --: out std_logic_vector(23 downto 0);

        BW_SEL                      => BW_SEL(i)    , --: in  std_logic_vector(3 downto 0);    -- 5M: 0x2 / 10M: 0x3 / 15M: 0x4 / 20M: 0x5 
        CC_SEL                      => cc_num(i)    , --: in  std_logic_vector(3 downto 0);

        O_UL_FSYNC                  => tx_10ms(i)       , --: out std_logic;
        O_UL_TDD                    => tx_tdd (i)       , --: out std_logic;
        O_UL_VLD                    => open            , --: out std_logic_vector( 3 downto 0);    -- valid signal for valid data.   
        I_UL_TX_EN                  => I_TX_SYNC       , --: in  std_logic;
        O_UL_DATA_I                 => tx_data_i(i)    , --: out std_logic_vector(15 downto 0);
        O_UL_DATA_Q                 => tx_data_q(i)    , --: out std_logic_vector(15 downto 0);

        I_UL_FSYNC                  => I_UL_10MS       , --: in  std_logic;
        I_UL_TDD                    => I_UL_TDD        , --: in  std_logic;
        I_UL_SYNC                   => I_UL_SYNC(i)    , --: in  std_logic;
        I_UL_DATA                   => I_UL_DATA(i)      --: in  std_logic_vector(15 downto 0)

    );

    end generate;







end BEHAVE;
