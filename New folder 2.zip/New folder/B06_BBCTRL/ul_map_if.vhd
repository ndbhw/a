--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : ul_map_if                                                     --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2021.11.08                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity UL_MAP_IF is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        ARESET                      : in  std_logic;

        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        BW_SEL                      : in  std_logic_vector(3 downto 0);    -- 5M: 0x2 / 10M: 0x3 / 15M: 0x4 / 20M: 0x5 
        CC_SEL                      : in  std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- SBIF
--------------------------------------------------------------------------------

        O_UL_FSYNC                  : out std_logic;
        O_UL_TDD                    : out std_logic;
        O_UL_VLD                    : out std_logic_vector( 3 downto 0);    -- valid signal for valid data.   
        I_UL_TX_EN                  : in  std_logic;
        O_UL_DATA_I                 : out std_logic_vector(15 downto 0);
        O_UL_DATA_Q                 : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- Formatter
--------------------------------------------------------------------------------

        I_UL_FSYNC                   : in  std_logic;
        I_UL_TDD                     : in  std_logic;
        I_UL_SYNC                    : in  std_logic;
        I_UL_DATA                    : in  std_logic_vector(15 downto 0)

    );
end UL_MAP_IF;

architecture BEHAVE of UL_MAP_IF is

    function log2 (data_value : integer)
    return integer is
        variable result      : integer := 0;
        variable cnt         : integer := 1;
    begin
        if (data_value <= 1) then
            result     := 0;
        else
            while (cnt < data_value) loop
                result := result + 1;
                cnt    := cnt *2;
            end loop;
        end if;
        return result;
    end log2;

    signal ul_fsync_r               : std_logic := '0';
    signal ul_fsync_d               : std_logic := '0';
    signal ul_fsync_rpls            : std_logic := '0';

    signal ul_sync_d                : std_logic_vector( 1 downto 0) := (others => '0');
    signal cnt_sample               : std_logic_vector( 5 downto 0) := (others => '0');
    signal buf_wbank                : std_logic_vector( 1 downto 0) := (others => '0');
    signal data_iq                  : std_logic_vector(33 downto 0) := (others => '0');
    signal ul_bfn_strb_d            : std_logic_vector( 1 downto 0) := (others => '0');
    signal ul_data_d                : std_logic_vector(15 downto 0) := (others => '0');

    signal cnt_chip                 : std_logic_vector( 5 downto 0) := (others => '0');
    signal buf_rbank                : std_logic_vector( 1 downto 0) := (others => '0');
    signal buf_raddr_l              : std_logic_vector( 4 downto 0) := (others => '0');

    component bb_buf is
    generic(
        STYLE                       : string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
        NPIPE                       : integer := 6;
        DEPTH                       : integer := 8192;
        WIDTH                       : integer := 72
    );
    port(
        WCLK                        : in  std_logic;
        RCLK                        : in  std_logic;
        WE                          : in  std_logic;
        ENB                         : in  std_logic;
        WADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
        RADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
        WDATA                       : in  std_logic_vector(WIDTH-1 downto 0);
        RDATA                       : out std_logic_vector(WIDTH-1 downto 0)
    );
    end component;

    signal buf_rd_en             : std_logic := '0';
    signal buf_wdata             : std_logic_vector(33 downto 0) := (others => '0');
    signal buf_waddr             : std_logic_vector(6 downto 0)  := (others => '0');
    signal buf_raddr             : std_logic_vector(6 downto 0)  := (others => '0');
    signal buf_rdata             : std_logic_vector(33 downto 0) := (others => '0');

    signal buf_rd_en_d           : std_logic_vector(5 downto 0) := (others => '0');
    signal buf_rd_en_in          : std_logic := '0';
    signal buf_rd_en_in_d           : std_logic_vector(5 downto 0) := (others => '0');


begin

    ------------------------------------------------------
    -- write control
    ------------------------------------------------------

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (I_UL_SYNC = '1') then
                ul_fsync_r <= I_UL_FSYNC;
            end if;
            ul_fsync_d <= ul_fsync_r;
            ul_fsync_rpls <= ul_fsync_r and (not ul_fsync_d);
        end if;
    end process;

    -- count max 63 regardless of BW / synchronized with sample sync
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            ul_sync_d <= ul_sync_d(0) & I_UL_SYNC;
            if ((ul_sync_d(1) and ul_fsync_rpls) = '1') then
                cnt_sample <= (others => '0');
            else
                if (BW_SEL = x"2") then  -- 5M
                    if (ul_sync_d(1) = '1') then
                        cnt_sample(5) <= not cnt_sample(5);                    
                        cnt_sample(4 downto 0) <= (others => '0');
                    else
                        cnt_sample(5) <= cnt_sample(5);                    
                        cnt_sample(4 downto 0) <= cnt_sample(4 downto 0) + 1;
                    end if;
                elsif (BW_SEL = x"3") then
                    if (ul_sync_d(1) = '1') then
                        cnt_sample(5 downto 4) <= cnt_sample(5 downto 4) + 1;                    
                        cnt_sample(3 downto 0) <= (others => '0');
                    else
                        cnt_sample(5 downto 4) <= cnt_sample(5 downto 4);                    
                        cnt_sample(3 downto 0) <= cnt_sample(3 downto 0) + 1;
                    end if;
                else
                    if (ul_sync_d(1) = '1') then
                        cnt_sample(5 downto 3) <= cnt_sample(5 downto 3) + 1;                    
                        cnt_sample(2 downto 0) <= (others => '0');
                    else
                        cnt_sample(5 downto 3) <= cnt_sample(5 downto 3);                    
                        cnt_sample(2 downto 0) <= cnt_sample(2 downto 0) + 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    -- write bank
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_sample = 63 ) then
                buf_wbank <= buf_wbank + 1;
            else
                buf_wbank <= buf_wbank;
            end if;
        end if;
    end process;

    -- write data
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_sample(0) = '0') then
                data_iq(33)   <= ul_bfn_strb_d(0);
                data_iq(32)   <= '0';
                data_iq(31 downto 16) <= ul_data_d;
                buf_wdata <= data_iq;
            else
                data_iq(33)   <= ul_bfn_strb_d(0);
                data_iq(32)   <= '0';
                data_iq(15 downto 0) <= ul_data_d;
                buf_wdata <= buf_wdata;
            end if;
            ul_bfn_strb_d <= ul_bfn_strb_d(0) & I_UL_FSYNC;
            ul_data_d <= I_UL_DATA;
        end if;
    end process;

    --write address
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_sample(0) = '0') then
                buf_waddr <= buf_wbank & cnt_sample(5 downto 1);
            else
                buf_waddr <= buf_waddr;
            end if;
        end if;
    end process;

    ------------------------------------------------------
    -- read control
    ------------------------------------------------------

    -- count max 63 / synchronized with tx enable signal
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (I_UL_TX_EN = '1') then
                cnt_chip <= "000100";
            else
                cnt_chip <= cnt_chip + 1;
            end if;
        end if;
    end process;

    -- buffer read bank
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_chip = 0) then
                buf_rbank <= buf_wbank + 2;
            else
                buf_rbank <= buf_rbank;
            end if;
        end if;
    end process;

    -- buffer read enable
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_chip(2) = '0') then
                buf_rd_en <= '1';
            else
                buf_rd_en <= '0';
            end if;
            buf_rd_en_d <= buf_rd_en_d(4 downto 0) & buf_rd_en;
        end if;
    end process;

    buf_rd_en_in <= buf_rd_en when CC_SEL = x"0" else buf_rd_en_d(1) when CC_SEL = x"1" else buf_rd_en_d(3) when CC_SEL = x"2" else buf_rd_en_d(5); 

    -- buffer read address
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (CC_SEL = x"0") then
                if (cnt_chip = 0) then
                    buf_raddr_l <= (others => '0');
                else
                    if (buf_rd_en_in = '1') then
                        buf_raddr_l <= buf_raddr_l + 1;
                    else
                        buf_raddr_l <= buf_raddr_l;
                    end if;
                end if;
            elsif (CC_SEL = x"1") then
                if (cnt_chip = 2) then
                    buf_raddr_l <= (others => '0');
                else
                    if (buf_rd_en_in = '1') then
                        buf_raddr_l <= buf_raddr_l + 1;
                    else
                        buf_raddr_l <= buf_raddr_l;
                    end if;
                end if;
            elsif (CC_SEL = x"2") then
                if (cnt_chip = 4) then
                    buf_raddr_l <= (others => '0');
                else
                    if (buf_rd_en_in = '1') then
                        buf_raddr_l <= buf_raddr_l + 1;
                    else
                        buf_raddr_l <= buf_raddr_l;
                    end if;
                end if;
            else
                if (cnt_chip = 6) then
                    buf_raddr_l <= (others => '0');
                else
                    if (buf_rd_en_in = '1') then
                        buf_raddr_l <= buf_raddr_l + 1;
                    else
                        buf_raddr_l <= buf_raddr_l;
                    end if;
                end if;
            end if;
        end if;
    end process;

    buf_raddr <= buf_rbank & buf_raddr_l;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            buf_rd_en_in_d <= buf_rd_en_in_d(4 downto 0) & buf_rd_en_in;
            if (buf_rd_en_in_d(1) = '1') then
                O_UL_FSYNC  <= buf_rdata(33);             
                O_UL_DATA_I <= buf_rdata(31 downto 16); 
                O_UL_DATA_Q <= buf_rdata(15 downto 0); 
            else
                O_UL_DATA_I <= (others => '0'); 
                O_UL_DATA_Q <= (others => '0'); 
            end if;
        end if;
    end process;

    u_bb_buf : bb_buf 
    generic map(
        STYLE                       => "BLOCK"     , --: string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
        NPIPE                       => 2           , --: integer := 6;
        DEPTH                       => 128         , --: integer := 8192;
        WIDTH                       => 34            --: integer := 72
    )
    port map(
        WCLK                        => CLK_SYSX8     , --: in  std_logic;
        RCLK                        => CLK_SYSX8     , --: in  std_logic;
        WE                          => '1'           , --: in  std_logic;
        ENB                         => buf_rd_en_in , --buf_rd_en     , --: in  std_logic;
        WADDR                       => buf_waddr     , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        RADDR                       => buf_raddr     , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        WDATA                       => buf_wdata     , --: in  std_logic_vector(WIDTH-1 downto 0);
        RDATA                       => buf_rdata       --: out std_logic_vector(WIDTH-1 downto 0)
    );


end BEHAVE;





