--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Rounding (Formatter component)                                --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_SIGNED.ALL;
 
entity ATT_ROD is
    generic (
        INPUT_WIDTH                 : natural := 32;
        OUTPUT_WIDTH                : natural := 20
    );
    port (
        CLK                         : in  std_logic;
        ROD_IN                      : in  std_logic_vector(INPUT_WIDTH-1 downto 0);
        ROD_OUT                     : out std_logic_vector(OUTPUT_WIDTH-1 downto 0)
    );
end ATT_ROD;
 
architecture BEHAVE of ATT_ROD is

    constant max                    : std_logic_vector(OUTPUT_WIDTH-2 downto 0) := (others => '1');
    signal p_rnd_in                 : std_logic_vector(INPUT_WIDTH-1 downto 0) := (others => '0');
    signal n_rnd_in                 : std_logic_vector(INPUT_WIDTH-1 downto 0) := (others => '0');
    signal p_rnd                    : std_logic_vector(OUTPUT_WIDTH-1 downto 0) := (others => '0');
    signal n_rnd                    : std_logic_vector(OUTPUT_WIDTH-1 downto 0) := (others => '0');
    signal sign                     : std_logic := '0';

begin

    process (CLK)
    begin 
        if (CLK'event and CLK = '1') then
            p_rnd_in <= ROD_IN;
        end if;
    end process;

    process(CLK)
    begin 
        if (CLK'event and CLK = '1') then
            if (ROD_IN(INPUT_WIDTH-2 downto 0) = 0) then
                n_rnd_in <= not (ROD_IN);
            else
                n_rnd_in <= ((not ROD_IN) + '1');
            end if;
        end if;
    end process;

    process(CLK)
    begin
        if (CLK'event and CLK = '1') then
            p_rnd <= p_rnd_in(INPUT_WIDTH-1 downto INPUT_WIDTH-OUTPUT_WIDTH) + p_rnd_in(INPUT_WIDTH-OUTPUT_WIDTH-1); 
            n_rnd <= n_rnd_in(INPUT_WIDTH-1 downto INPUT_WIDTH-OUTPUT_WIDTH) + n_rnd_in(INPUT_WIDTH-OUTPUT_WIDTH-1);
            sign  <= p_rnd_in(INPUT_WIDTH-1);
        end if;
    end process;
   
    process(CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (sign = '1') then   
                ROD_OUT <= ((NOT n_rnd) + '1');
            else
                if (p_rnd(OUTPUT_WIDTH-1) = '1') then
                    ROD_OUT <= '0' & max;
                else
                    ROD_OUT <= p_rnd;
                end if;
            end if;
        end if;
    end process;

end BEHAVE;