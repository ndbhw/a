--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Pulse delay (Single-edge)                                     --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------
-- Processing delay 3-clocks                                                  --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity DELAY_PULSE_SE is
    generic (
        DELAY_RANGE                 : natural := 32
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;
        DELAY_VALUE                 : in  std_logic_vector(DELAY_RANGE-1 downto 0);
        SYNC_IN                     : in  std_logic;
        SYNC_OUT                    : out std_logic
    );
end DELAY_PULSE_SE;

architecture BEHAVE of DELAY_PULSE_SE is

    function pwr2 (data_value : integer)
    return integer is
        variable result      : integer := 2;
        variable cnt         : integer := 1;
    begin
        if (data_value = 0) then
            result     := 1;
        else
            while (cnt < data_value) loop
                result := result * 2;
                cnt    := cnt + 1;
            end loop;
        end if;
        return result;
    end pwr2;

    signal cnt                      : std_logic_vector(DELAY_RANGE-1 downto 0) := (others => '0');
    signal delay_rising             : std_logic_vector(DELAY_RANGE-1 downto 0) := (others => '0');
    signal delay_falling            : std_logic_vector(DELAY_RANGE-1 downto 0) := (others => '0');
    signal delay_ref                : std_logic_vector(DELAY_RANGE-1 downto 0) := (others => '0');

    signal sync_buf                 : std_logic := '0';
    signal sync_active              : std_logic := '0';
    signal sync_delay               : std_logic_vector(1 downto 0) := (others => '0');

begin

    -- base counter
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            cnt <= cnt + 1;
        end if;
    end process;

    -- buffering
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            sync_buf  <= SYNC_IN;
        end if;
    end process;

    -- process 1 input
    process (RESET, CLK)
    begin
        if (RESET = '1') then
            sync_active <= '0';
        elsif (CLK'event and CLK = '1') then
            if (SYNC_IN = '1') and (sync_buf = '0') then
                sync_active <= '1';
            elsif (sync_delay = "10") then
                sync_active <= '0';
            end if;
        end if;
    end process;

    -- delay value saturation
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (DELAY_VALUE = pwr2(DELAY_RANGE) - 1) then
                delay_ref <= (others => '1');
            else
                delay_ref <= DELAY_VALUE + 1;
            end if;
        end if;
    end process;

    -- detect each edge
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (SYNC_IN = '1') and (sync_buf = '0') then
                delay_rising  <= delay_ref + cnt;
            end if;
            if (SYNC_IN = '0') and (sync_buf = '1') then
                delay_falling <= delay_ref + cnt;
            end if;
        end if;
    end process;

    -- delayed sync
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (cnt = delay_rising) then
                sync_delay(0) <= sync_active;
            elsif (cnt = delay_falling) then
                sync_delay(0) <= '0';
            end if;
            sync_delay(1) <= sync_delay(0);
        end if;
    end process;

    SYNC_OUT <= sync_delay(1);

end BEHAVE;