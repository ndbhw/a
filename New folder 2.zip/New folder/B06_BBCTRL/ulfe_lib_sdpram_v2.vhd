-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part / H/W R&D Group
-- Author      : jiwoo42.park@samsung.com
-- *****************************************************************************
-- Revision history
-- *****************************************************************************
-- [2022.04.25 v1.0] Initial release
-- [2023.05.12 v1.0] add addr d_width
-- *****************************************************************************

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;

Library xpm;
use xpm.vcomponents.all;

entity ulfe_lib_sdpram_v2 is
	generic (
		memory_primitive				: string := "block";
		read_latency					: integer := 2;
		wt_mem_d_width					: integer := 30;
		rd_mem_d_width					: integer := 60;
		wt_max_addr_d_width				: integer := 12;
		rd_max_addr_d_width				: integer := 12
	);
	Port (
		i_clk	                     	: in std_logic; 
		
		i_wt_enable						: in std_logic;
		i_wt_addr						: in std_logic_vector(wt_max_addr_d_width-1 downto 0);
		i_wt_data						: in std_logic_vector(wt_mem_d_width-1 downto 0);
		
		i_rd_addr						: in std_logic_vector(rd_max_addr_d_width-1 downto 0);
		o_rd_dout						: out std_logic_vector(rd_mem_d_width-1 downto 0)
	);
end ulfe_lib_sdpram_v2;

architecture Behavioral of ulfe_lib_sdpram_v2 is
	
	constant mem_size						: integer := 2**(wt_max_addr_d_width)*wt_mem_d_width;	

begin

	lib_sdpram : xpm_memory_sdpram
		generic map (
			addr_width_a 				=> wt_max_addr_d_width,
			addr_width_b 				=> rd_max_addr_d_width,
			auto_sleep_time 			=> 0,
			byte_write_width_a 			=> wt_mem_d_width,
			cascade_height 				=> 0,
			clocking_mode	 			=> "common_clock",
			ecc_mode 					=> "no_ecc",
			memory_init_file 			=> "none",
			memory_init_param 			=> "0",
			memory_optimization 		=> "true",
			memory_primitive 			=> memory_primitive,
			memory_size 				=> mem_size,
			message_control 			=> 0,
			read_data_width_b			=> rd_mem_d_width,
			read_latency_b 				=> read_latency,
			read_reset_value_b 			=> "0",
			rst_mode_a 					=> "sync",
			rst_mode_b 					=> "sync",
			sim_assert_chk 				=> 0,
			use_embedded_constraint 	=> 0,
			use_mem_init 				=> 1,
			wakeup_time 				=> "disable_sleep",
			write_data_width_a 			=> wt_mem_d_width,
			write_mode_b 				=> "read_first"
		)
		port map (
			dbiterrb 			=>	open,		-- indicate double bit error occurrence on the data output of port B
			doutb 				=>	o_rd_dout,
			sbiterrb 			=>	open,		-- indicate single bit error occurrence on the data output of port B
			addra 				=>	i_wt_addr,
			addrb 				=>	i_rd_addr,
			clka 				=>	i_clk,
			clkb 				=>	i_clk,
			dina 				=>	i_wt_data,
			ena 				=>	'1',
			enb 				=>	'1',
			injectdbiterra 		=>	'0',
			injectsbiterra 		=>	'0',
			regceb 				=>	'1',
			rstb 				=>	'0',
			sleep 				=>	'0',
			wea(0) 				=>	i_wt_enable
		);

end Behavioral;
