--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : gsm_ddc_if                                                    --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2021.11.08                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity GSM_DDC_IF is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        RESET                       : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

--------------------------------------------------------------------------------
-- SBIF_IF
--------------------------------------------------------------------------------

        O_UL_FSYNC                  : out std_logic;
        O_UL_TDD                    : out std_logic;
        I_UL_TX_EN                  : in  std_logic;
        O_UL_DATA_I                 : out std_logic_vector(15 downto 0);
        O_UL_DATA_Q                 : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- Formatter
--------------------------------------------------------------------------------

        I_ALC_DONE                  : in  std_logic;
        I_ALC_ATT_A                 : in  std_logic_vector(15 downto 0);
        I_ALC_ATT_B                 : in  std_logic_vector(15 downto 0);

--        I_UL_FSYNC                  : in  std_logic;
        I_UL_120MS                  : in  std_logic;
        I_UL_TS_SYNC                : in  std_logic;
        I_UL_TDD                    : in  std_logic;
        I_UL_SYNC                   : in  std_logic;         --0.96Msps
        I_UL_DATA                   : in  std_logic_vector(15 downto 0)

    );
end GSM_DDC_IF;

architecture BEHAVE of GSM_DDC_IF is

    function log2 (data_value : integer)
    return integer is
        variable result      : integer := 0;
        variable cnt         : integer := 1;
    begin
        if (data_value <= 1) then
            result     := 0;
        else
            while (cnt < data_value) loop
                result := result + 1;
                cnt    := cnt *2;
            end loop;
        end if;
        return result;
    end log2;

    signal cnt_sync                 : std_logic_vector(8 downto 0) := (others => '0');
    signal cnt_sync_d               : std_logic_vector(8 downto 0) := (others => '0');
    signal bfn_strb_d               : std_logic_vector(4 downto 0) := (others => '0'); 
    signal sync_120ms_d               : std_logic_vector(4 downto 0) := (others => '0'); 
    signal tdd_d                    : std_logic_vector(4 downto 0) := (others => '0'); 
    signal iq_data                  : std_logic_vector(31 downto 0) := (others => '0');
    signal alc_done_d               : std_logic_vector(1 downto 0) := (others => '0');
    signal alc_done_rpls            : std_logic := '0';
--    signal alc_att_a_d              : std_logic_array16(1 downto 0) := (others => (others => '0')); 
--    signal alc_att_b_d              : std_logic_array16(1 downto 0) := (others => (others => '0'));    
    signal alc_att_a_lat              : std_logic_vector(15 downto 0) := (others => '0'); 
    signal alc_att_b_lat              : std_logic_vector(15 downto 0) := (others => '0');    
    signal alc_att_a_lat_r              : std_logic_vector(15 downto 0) := (others => '0'); 
    signal alc_att_b_lat_r              : std_logic_vector(15 downto 0) := (others => '0');    
    signal ul_data_d                : std_logic_array16( 1 downto 0) := (others => (others => '0'));
    signal ul_data_lat              : std_logic_array16(31 downto 0) := (others => (others => '0'));
    signal ul_data_copy             : std_logic_vector( 15 downto 0) := (others => '0');

    signal cnt_tx_sync              : std_logic_vector(5 downto 0) := (others => '0');
    signal cnt_tx_sync_r            : std_logic_vector(5 downto 0) := (others => '0');  
    signal data_en                  : std_logic := '0';

    component bb_buf is
    generic(
        STYLE                       : string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
        NPIPE                       : integer := 6;
        DEPTH                       : integer := 8192;
        WIDTH                       : integer := 72
    );
    port(
        WCLK                        : in  std_logic;
        RCLK                        : in  std_logic;
        WE                          : in  std_logic;
        ENB                         : in  std_logic;
        WADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
        RADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
        WDATA                       : in  std_logic_vector(WIDTH-1 downto 0);
        RDATA                       : out std_logic_vector(WIDTH-1 downto 0)
    );
    end component;

    signal wr_en                    : std_logic := '0';
    signal wr_data                  : std_logic_vector(31 downto 0) := (others => '0'); 
    signal wr_data_in               : std_logic_vector(33 downto 0) := (others => '0');
    signal wr_bank                  : std_logic_vector(1 downto 0) := (others => '0');
    signal wr_addr_l                : std_logic_vector(4 downto 0) := (others => '0');            
    signal wr_addr                  : std_logic_vector(6 downto 0) := (others => '0');
    signal wr_addr_in               : std_logic_vector(6 downto 0) := (others => '0');

    signal rd_bank                  : std_logic_vector(1 downto 0) := (others => '0');
    signal rd_en                    : std_logic := '0';
    signal rd_addr                  : std_logic_vector(6 downto 0) := (others => '0');
    signal rd_data                  : std_logic_vector(33 downto 0) := (others => '0');

begin

    PROCESSING_DELAY_UL <= conv_std_logic_vector(181,24);
    
--------------------------------------------------------------------------------
-- write control
--------------------------------------------------------------------------------

    -- max count value 256
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (I_UL_SYNC = '1') then -- 0.96Msps sync//256clk@245.76MHz
                cnt_sync <= (others => '0');
            else
                cnt_sync <= cnt_sync + 1;
            end if;
            cnt_sync_d <= cnt_sync;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
--            bfn_strb_d <= bfn_strb_d(3 downto 0) & I_UL_FSYNC;
            sync_120ms_d <= sync_120ms_d(3 downto 0) & I_UL_120MS;
            tdd_d      <= tdd_d     (3 downto 0) & I_UL_TDD;  
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            alc_done_d  <= alc_done_d(0)  & I_ALC_DONE;
            alc_done_rpls <= alc_done_d(0) and (not alc_done_d(1));
--            alc_att_a_d <= alc_att_a_d(0) & I_ALC_ATT_A;
--            alc_att_b_d <= alc_att_b_d(0) & I_ALC_ATT_B;
        end if;
    end process;

    --alc atten latch
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (alc_done_rpls = '1') then
                alc_att_a_lat <= I_ALC_ATT_A;
                alc_att_b_lat <= I_ALC_ATT_B;
            else
                alc_att_a_lat <= alc_att_a_lat;
                alc_att_b_lat <= alc_att_b_lat;
            end if;
            if (I_UL_TS_SYNC = '1') then
                alc_att_a_lat_r <= alc_att_a_lat;
                alc_att_b_lat_r <= alc_att_b_lat;
            else
                alc_att_a_lat_r <= alc_att_a_lat_r;
                alc_att_b_lat_r <= alc_att_b_lat_r;
            end if;
        end if;
    end process;

    -- write data
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            ul_data_d <= ul_data_d(0) & I_UL_DATA;
            for i in 0 to 31 loop 
            if (cnt_sync(7 downto 0) = i) then
                ul_data_lat(i) <= ul_data_d(0);
            else
                ul_data_lat(i) <=  ul_data_lat(i);
            end if; 
            end loop;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_sync(7 downto 6) = "00") then
                ul_data_copy <= ul_data_d(0);
            else
                case cnt_sync(5 downto 0) is 
                    when "000000" => ul_data_copy <= ul_data_lat(0);
                    when "000001" => ul_data_copy <= ul_data_lat(1);
                    when "000010" => ul_data_copy <= ul_data_lat(2);
                    when "000011" => ul_data_copy <= ul_data_lat(3);
                    when "000100" => ul_data_copy <= ul_data_lat(4);
                    when "000101" => ul_data_copy <= ul_data_lat(5);
                    when "000110" => ul_data_copy <= ul_data_lat(6);
                    when "000111" => ul_data_copy <= ul_data_lat(7);
                    when "001000" => ul_data_copy <= ul_data_lat(8);
                    when "001001" => ul_data_copy <= ul_data_lat(9);
                    when "001010" => ul_data_copy <= ul_data_lat(10);
                    when "001011" => ul_data_copy <= ul_data_lat(11);
                    when "001100" => ul_data_copy <= ul_data_lat(12);
                    when "001101" => ul_data_copy <= ul_data_lat(13);
                    when "001110" => ul_data_copy <= ul_data_lat(14);
                    when "001111" => ul_data_copy <= ul_data_lat(15);
                    when "010000" => ul_data_copy <= ul_data_lat(16);
                    when "010001" => ul_data_copy <= ul_data_lat(17);
                    when "010010" => ul_data_copy <= ul_data_lat(18);
                    when "010011" => ul_data_copy <= ul_data_lat(19);
                    when "010100" => ul_data_copy <= ul_data_lat(20);
                    when "010101" => ul_data_copy <= ul_data_lat(21);
                    when "010110" => ul_data_copy <= ul_data_lat(22);
                    when "010111" => ul_data_copy <= ul_data_lat(23);
                    when "011000" => ul_data_copy <= ul_data_lat(24);
                    when "011001" => ul_data_copy <= ul_data_lat(25);
                    when "011010" => ul_data_copy <= ul_data_lat(26);
                    when "011011" => ul_data_copy <= ul_data_lat(27);
                    when "011100" => ul_data_copy <= ul_data_lat(28);
                    when "011101" => ul_data_copy <= ul_data_lat(29);
                    when "011110" => ul_data_copy <= ul_data_lat(30);
                    when "011111" => ul_data_copy <= ul_data_lat(31);
                 --   when "100000" => ul_data_copy <= alc_att_a_d(1);
                 --   when "100001" => ul_data_copy <= alc_att_b_d(1);
                    when others   => ul_data_copy <= (others => '0');
                end case;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_sync_d(0) = '0') then
                iq_data(31 downto 16) <= ul_data_copy;
                wr_data <= iq_data;
            else
                iq_data(15 downto 0) <= ul_data_copy;
                wr_data <= wr_data;
            end if;
            wr_data_in <= sync_120ms_d(4) & tdd_d(4) & wr_data;            
        end if;
    end process;

    -- write address
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            wr_bank    <= cnt_sync_d(7 downto 6);
            wr_addr_l  <= cnt_sync_d(5 downto 1);
            wr_addr    <= wr_bank & wr_addr_l;
            wr_addr_in <= wr_addr;
            wr_en      <= cnt_sync_d(0);
        end if;
    end process;

--------------------------------------------------------------------------------
-- read control
--------------------------------------------------------------------------------

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (I_UL_TX_EN = '1') then
                cnt_tx_sync   <= "000100";
                cnt_tx_sync_r <= "000010"; 
            else
                cnt_tx_sync   <= cnt_tx_sync + 1;
                cnt_tx_sync_r <= cnt_tx_sync_r + 1;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_tx_sync = 63) then
                rd_bank <= wr_bank + 2;
            else
                rd_bank <= rd_bank;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            rd_en   <= not cnt_tx_sync(5);
            rd_addr <= rd_bank & cnt_tx_sync(4 downto 0);
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (cnt_tx_sync_r(5) = '1') then
                data_en <= '0';
            else
                data_en <= '1';
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
--            O_UL_FSYNC  <= rd_data(33); 
--            O_UL_TDD    <= rd_data(32); 
            if (data_en = '1') then
                O_UL_DATA_I <= rd_data(31 downto 16); 
                O_UL_DATA_Q <= rd_data(15 downto 0); 
                O_UL_FSYNC  <= rd_data(33); 
                O_UL_TDD    <= rd_data(32);                 
            elsif (cnt_tx_sync_r = "100001") then
                O_UL_DATA_I <= alc_att_a_lat; 
                O_UL_DATA_Q <= (others => '0');
            elsif (cnt_tx_sync_r = "100010") then
                O_UL_DATA_I <= alc_att_b_lat; 
                O_UL_DATA_Q <= (others => '0');
            else
                O_UL_DATA_I <= (others => '0'); 
                O_UL_DATA_Q <= (others => '0');
            end if;
        end if;
    end process;

    u_ul_map_buf : bb_buf 
    generic map(
        STYLE                       => "BLOCK"        , --: string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
        NPIPE                       => 2              , --: integer := 6;
        DEPTH                       => 128            , --: integer := 8192;
        WIDTH                       => 34               --: integer := 72
    )
    port map(
        WCLK                        => CLK_SYSX8        , --: in  std_logic;
        RCLK                        => CLK_SYSX8        , --: in  std_logic;
        WE                          => wr_en            , --: in  std_logic;
        ENB                         => rd_en        , --: in  std_logic;
        WADDR                       => wr_addr_in        , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        RADDR                       => rd_addr        , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        WDATA                       => wr_data_in        , --: in  std_logic_vector(WIDTH-1 downto 0);
        RDATA                       => rd_data          --: out std_logic_vector(WIDTH-1 downto 0)
    );

    end BEHAVE;

