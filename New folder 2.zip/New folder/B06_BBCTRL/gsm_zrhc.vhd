--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Zero Replacement Hard Clipper                                 --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity GSM_ZRHC is
    generic (
        ANT_NUM                     : natural := 16
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY            : out std_logic_vector(23 downto 0);

        ZRHC_BYPASS                 : in  std_logic;
        ZRHC_THRESHOLD              : in  std_logic_vector(31 downto 0);
        ZRHC_OCCUR                  : out std_logic_vector(ANT_NUM-1 downto 0);

        ZRHC_IN_120MS_SYNC          : in  std_logic;
        ZRHC_IN_TS16_SYNC           : in  std_logic;
        ZRHC_IN_TS_SYNC             : in  std_logic;
        ZRHC_IN_TS_GP_SYNC          : in  std_logic;

        ZRHC_IN_10MS                : in  std_logic;
        ZRHC_IN_TDD                 : in  std_logic;
        ZRHC_IN_SYNC                : in  std_logic;
        ZRHC_IN_DATA                : in  std_logic_vector(15 downto 0);

        ZRHC_OUT_120MS_SYNC         : out std_logic;
        ZRHC_OUT_TS16_SYNC          : out std_logic;
        ZRHC_OUT_TS_SYNC            : out std_logic;
        ZRHC_OUT_TS_GP_SYNC         : out std_logic;

        ZRHC_OUT_10MS               : out std_logic;
        ZRHC_OUT_TDD                : out std_logic;
        ZRHC_OUT_SYNC               : out std_logic;
        ZRHC_OUT_DATA               : out std_logic_vector(15 downto 0)
  );
end GSM_ZRHC;

architecture BEHAVE of GSM_ZRHC is

    signal cnt_sync                 : std_logic_vector(4 downto 0) := (others => '0');
    signal cnt_sync_d               : std_logic_vector(4 downto 0) := (others => '0');
    signal sync_buffer              : Std_logic_vector(7 downto 0);
    type data_array is array(natural range <>) of std_logic_vector(15 downto 0);
    signal data_buffer              : data_array(6 downto 0) := (others => (others => '0'));
    signal cur_power                : std_logic_vector(31 downto 0);
    signal antenna_block            : std_logic;
    signal antenna_block_buffer     : std_logic_array4(15 downto 0) := (others => (others => '1'));

    signal zrhc_120ms_sync_d        : std_logic_vector(6 downto 0) := (others => '0'); 
    signal zrhc_ts16_sync_d         : std_logic_vector(6 downto 0) := (others => '0'); 
    signal zrhc_ts_sync_d           : std_logic_vector(6 downto 0) := (others => '0'); 
    signal zrhc_ts_gp_sync_d        : std_logic_vector(6 downto 0) := (others => '0'); 

    signal zrhc_10ms_d              : std_logic_vector(6 downto 0) := (others => '0'); 
    signal zrhc_tdd_d               : std_logic_vector(6 downto 0) := (others => '0'); 

    --signal antenna0_block_buffer    : std_logic_vector(3 downto 0) := (others => '1');
    --signal antenna1_block_buffer    : std_logic_vector(3 downto 0) := (others => '1');
    --signal antenna2_block_buffer    : std_logic_vector(3 downto 0) := (others => '1');
    --signal antenna3_block_buffer    : std_logic_vector(3 downto 0) := (others => '1');
    --signal antenna4_block_buffer    : std_logic_vector(3 downto 0) := (others => '1');
    --signal antenna5_block_buffer    : std_logic_vector(3 downto 0) := (others => '1');
    --signal antenna6_block_buffer    : std_logic_vector(3 downto 0) := (others => '1');
    --signal antenna7_block_buffer    : std_logic_vector(3 downto 0) := (others => '1');
    --signal antenna8_block_buffer    : std_logic_vector(3 downto 0) := (others => '1');
    --signal antenna9_block_buffer    : std_logic_vector(3 downto 0) := (others => '1');
    --signal antenna10_block_buffer   : std_logic_vector(3 downto 0) := (others => '1');
    --signal antenna11_block_buffer   : std_logic_vector(3 downto 0) := (others => '1');
    --signal antenna12_block_buffer   : std_logic_vector(3 downto 0) := (others => '1');
    --signal antenna13_block_buffer   : std_logic_vector(3 downto 0) := (others => '1');
    --signal antenna14_block_buffer   : std_logic_vector(3 downto 0) := (others => '1');
    --signal antenna15_block_buffer   : std_logic_vector(3 downto 0) := (others => '1');

    component MULT_16X16 is
    port (
    	CLK                        : in  std_logic;
    	A                          : in  std_logic_vector(15 downto 0);
    	B                          : in  std_logic_vector(15 downto 0);
    	P                          : out std_logic_vector(31 downto 0)
    );
    end component;

    signal a                       : std_logic_vector(15 downto 0);
    signal b                       : std_logic_vector(15 downto 0);
    signal p                       : std_logic_vector(31 downto 0);

begin

    PROCESSING_DELAY <= conv_std_logic_vector(8, 24);

    -- synchronization
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (ZRHC_IN_SYNC = '1') then
                cnt_sync <= (others => '0');
            else
                cnt_sync <= cnt_sync + 1;
            end if;
        end if;
    end process;

    -- multiplier input
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            a <= ZRHC_IN_DATA;
            b <= ZRHC_IN_DATA;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            sync_buffer <= sync_buffer(6 downto 0) & ZRHC_IN_SYNC;
            data_buffer <= data_buffer(5 downto 0) & ZRHC_IN_DATA;
        end if;
    end process;

    -- Calculate the power
    process (RESET, CLK)
    begin
        if (RESET = '1') then
            cur_power     <= (others => '0');
            antenna_block <= '1';
        elsif (CLK'event and CLK = '1') then
           -- case cnt_sync is
           -- when "0000"  => cur_power <= p;
           -- when "0001"  => cur_power <= cur_power + p;
           -- when "0010"  => cur_power <= p;
           -- when "0011"  => cur_power <= cur_power + p;
           -- when "0100"  => cur_power <= p;
           -- when "0101"  => cur_power <= cur_power + p;
           -- when "0110"  => cur_power <= p;
           -- when "0111"  => cur_power <= cur_power + p;
           -- when "1000"  => cur_power <= p;
           -- when "1001"  => cur_power <= cur_power + p;
           -- when "1010"  => cur_power <= p;
           -- when "1011"  => cur_power <= cur_power + p;
           -- when "1100"  => cur_power <= p;
           -- when "1101"  => cur_power <= cur_power + p;
           -- when "1110"  => cur_power <= p;
           -- when "1111"  => cur_power <= cur_power + p;
           -- when others => NULL;
           -- end case;
            if (cnt_sync(0) = '0') then
                cur_power <= p;
            else
                cur_power <= cur_power + p;
            end if;                
            if (cnt_sync(0) = '0') then
                if (cur_power > ZRHC_THRESHOLD) then
                    antenna_block <= '1';
                else
                    antenna_block <= '0';
                end if;
            end if;
        end if;
    end process;

    ZRHC_OUT_SYNC <= sync_buffer(7);

    -- Buffering for synchronization
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          --  if (sync_buffer(7) = '1') then
          --      ZRHC_OUT_10MS <= ZRHC_IN_10MS;
          --      ZRHC_OUT_TDD  <= ZRHC_IN_TDD;
          --  end if;
            if (antenna_block = '1' and ZRHC_BYPASS = '0') then
                ZRHC_OUT_DATA <= (others => '0');
            else
                ZRHC_OUT_DATA <= data_buffer(6);
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            zrhc_120ms_sync_d   <= zrhc_120ms_sync_d(5 downto 0) & ZRHC_IN_120MS_SYNC;  
            zrhc_ts16_sync_d    <= zrhc_ts16_sync_d (5 downto 0) & ZRHC_IN_TS16_SYNC ;  
            zrhc_ts_sync_d      <= zrhc_ts_sync_d   (5 downto 0) & ZRHC_IN_TS_SYNC   ;  
            zrhc_ts_gp_sync_d   <= zrhc_ts_gp_sync_d(5 downto 0) & ZRHC_IN_TS_GP_SYNC;  
            ZRHC_OUT_120MS_SYNC <= zrhc_120ms_sync_d(6);  
            ZRHC_OUT_TS16_SYNC  <= zrhc_ts16_sync_d (6);  
            ZRHC_OUT_TS_SYNC    <= zrhc_ts_sync_d   (6);  
            ZRHC_OUT_TS_GP_SYNC <= zrhc_ts_gp_sync_d(6);  
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            zrhc_10ms_d    <= zrhc_10ms_d (5 downto 0) & ZRHC_IN_10MS ;  
            zrhc_tdd_d     <= zrhc_tdd_d  (5 downto 0) & ZRHC_IN_TDD  ;  
            ZRHC_OUT_10MS  <= zrhc_10ms_d (6);  
            ZRHC_OUT_TDD   <= zrhc_tdd_d  (6);  
        end if;
    end process;


    -- Hold abnormal signal (4 * 1/245.76 MHz)
--    process (CLK)
--    begin
--        if (CLK'event and CLK = '1') then
--            if (antenna_block = '1') then
--                case cnt_sync is
--                when "0000"  => antenna0_block_buffer <= (others => '1');
--                when "0001"  => antenna1_block_buffer <= (others => '1');
--                when "0010"  => antenna1_block_buffer <= (others => '1');
--                when "0011"  => antenna2_block_buffer <= (others => '1');
--                when "0100"  => antenna2_block_buffer <= (others => '1');
--                when "0101"  => antenna3_block_buffer <= (others => '1');
--                when "0110"  => antenna3_block_buffer <= (others => '1');
--                when "0111"  => antenna4_block_buffer <= (others => '1');
--                when "1000"  => antenna4_block_buffer <= (others => '1');
--                when "1001"  => antenna5_block_buffer <= (others => '1');
--                when "1010"  => antenna5_block_buffer <= (others => '1');
--                when "1011"  => antenna6_block_buffer <= (others => '1');
--                when "1100"  => antenna6_block_buffer <= (others => '1');
--                when "1101"  => antenna7_block_buffer <= (others => '1');
--                when "1110"  => antenna7_block_buffer <= (others => '1');
--                when "1111"  => antenna0_block_buffer <= (others => '1');
--                when others => NULL;
--                end case;
--            else
--                antenna0_block_buffer <= antenna0_block_buffer(2 downto 0) & '0';
--                antenna1_block_buffer <= antenna1_block_buffer(2 downto 0) & '0';
--                antenna2_block_buffer <= antenna2_block_buffer(2 downto 0) & '0';
--                antenna3_block_buffer <= antenna3_block_buffer(2 downto 0) & '0';
--                antenna4_block_buffer <= antenna4_block_buffer(2 downto 0) & '0';
--                antenna5_block_buffer <= antenna5_block_buffer(2 downto 0) & '0';
--                antenna6_block_buffer <= antenna6_block_buffer(2 downto 0) & '0';
--                antenna7_block_buffer <= antenna7_block_buffer(2 downto 0) & '0';
--            end if;
--        end if;
--    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (sync_buffer(5) = '1') then
                cnt_sync_d <= (others => '0');
            else
                cnt_sync_d <= cnt_sync_d + 1;
            end if;
        end if;
    end process;
    
    G_ANT_NUM : for i in ANT_NUM-1 downto 0 generate

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (antenna_block = '1') then
                if (cnt_sync_d(4 downto 1) = i) then
                    antenna_block_buffer(i) <= (others => '1');
                end if;
            else
                antenna_block_buffer(i) <= antenna_block_buffer(i)(2 downto 0) & '0';
            end if;
        end if;
    end process;

    ZRHC_OCCUR(i) <= antenna_block_buffer(i)(3);

    end generate;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_MULT : MULT_16X16 
    port map(
        CLK                        => CLK                                      ,--: in  std_logic;
        A                          => a                                        ,--: in  std_logic_vector(15 downto 0);
        B                          => b                                        ,--: in  std_logic_vector(15 downto 0);
        P                          => p                                         --: out std_logic_vector(31 downto 0)
    );

end BEHAVE;
