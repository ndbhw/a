-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1_AR76689_AR76685_AR76630_CR1106577 (lin64) Build 3247384 Thu Jun 10 19:36:07 MDT 2021
-- Date        : Wed Dec  8 20:14:15 2021
-- Host        : DC-FPGA-IDE-08 running 64-bit CentOS Linux release 7.8.2003 (Core)
-- Command     : write_vhdl -force -mode synth_stub
--               /home/h_r.hong/Project/BBCTRL/RF2221d/proj/bb_proj/bb_proj.runs/LTE_10M_TP_BRAM_synth_1/LTE_10M_TP_BRAM_stub.vhdl
-- Design      : LTE_10M_TP_BRAM
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xcku13p-ffve900-1LV-i
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity LTE_10M_TP_BRAM is
  Port ( 
    clka : in STD_LOGIC;
    ena : in STD_LOGIC;
    wea : in STD_LOGIC_VECTOR ( 0 to 0 );
    addra : in STD_LOGIC_VECTOR ( 14 downto 0 );
    dina : in STD_LOGIC_VECTOR ( 31 downto 0 );
    clkb : in STD_LOGIC;
    enb : in STD_LOGIC;
    addrb : in STD_LOGIC_VECTOR ( 14 downto 0 );
    doutb : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );

end LTE_10M_TP_BRAM;

architecture stub of LTE_10M_TP_BRAM is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clka,ena,wea[0:0],addra[14:0],dina[31:0],clkb,enb,addrb[14:0],doutb[31:0]";
attribute x_core_info : string;
attribute x_core_info of stub : architecture is "blk_mem_gen_v8_4_4,Vivado 2021.1_AR76689_AR76685_AR76630_CR1106577";
begin
end;
