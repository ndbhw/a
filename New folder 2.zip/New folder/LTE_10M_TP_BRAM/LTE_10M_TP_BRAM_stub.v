// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1_AR76689_AR76685_AR76630_CR1106577 (lin64) Build 3247384 Thu Jun 10 19:36:07 MDT 2021
// Date        : Wed Dec  8 20:14:15 2021
// Host        : DC-FPGA-IDE-08 running 64-bit CentOS Linux release 7.8.2003 (Core)
// Command     : write_verilog -force -mode synth_stub
//               /home/h_r.hong/Project/BBCTRL/RF2221d/proj/bb_proj/bb_proj.runs/LTE_10M_TP_BRAM_synth_1/LTE_10M_TP_BRAM_stub.v
// Design      : LTE_10M_TP_BRAM
// Purpose     : Stub declaration of top-level module interface
// Device      : xcku13p-ffve900-1LV-i
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* x_core_info = "blk_mem_gen_v8_4_4,Vivado 2021.1_AR76689_AR76685_AR76630_CR1106577" *)
module LTE_10M_TP_BRAM(clka, ena, wea, addra, dina, clkb, enb, addrb, doutb)
/* synthesis syn_black_box black_box_pad_pin="clka,ena,wea[0:0],addra[14:0],dina[31:0],clkb,enb,addrb[14:0],doutb[31:0]" */;
  input clka;
  input ena;
  input [0:0]wea;
  input [14:0]addra;
  input [31:0]dina;
  input clkb;
  input enb;
  input [14:0]addrb;
  output [31:0]doutb;
endmodule
