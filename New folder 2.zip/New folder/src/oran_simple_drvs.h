#ifndef ORAN_SIMPLE_DRVS_H_
#define ORAN_SIMPLE_DRVS_H_

#include "fpga_register_config.h"

#define ORAN_DL_PATH0_LSB_DST_MAC_OFFSET		0x0000u
#define ORAN_DL_PATH0_MSB_DST_MAC_OFFSET		0x0004u
#define ORAN_DL_PATH0_LSB_SRC_MAC_OFFSET		0x0008u
#define ORAN_DL_PATH0_MSB_SRC_MAC_OFFSET		0x000Cu
#define ORAN_DL_PATH0_VLAN0_OFFSET				0x0010u
#define ORAN_DL_PATH0_VLAN1_OFFSET				0x0014u


#define ORAN_UL_PATH0_LSB_DST_MAC_OFFSET		0x0040u
#define ORAN_UL_PATH0_MSB_DST_MAC_OFFSET		0x0044u
#define ORAN_UL_PATH0_LSB_SRC_MAC_OFFSET		0x0048u
#define ORAN_UL_PATH0_MSB_SRC_MAC_OFFSET		0x004Cu
#define ORAN_UL_PATH0_VLAN0_OFFSET				0x0050u
#define ORAN_UL_PATH0_VLAN1_OFFSET				0x0054u

#define ORAN_UL_PATH0_IGNORE_FRAMEID_OFFSET		0x0060u



#define ORAN_DL_PATH0_CH0_EAXC_ID0_OFFSET		0x0080u
#define ORAN_DL_PATH0_CH0_EAXC_ID1_OFFSET		0x0084u
#define ORAN_DL_PATH0_CH0_EAXC_ID2_OFFSET		0x0088u
#define ORAN_DL_PATH0_CH0_EAXC_ID3_OFFSET		0x008Cu
#define ORAN_DL_PATH0_CH1_EAXC_ID0_OFFSET		0x0090u
#define ORAN_DL_PATH0_CH1_EAXC_ID1_OFFSET		0x0094u
#define ORAN_DL_PATH0_CH1_EAXC_ID2_OFFSET		0x0098u
#define ORAN_DL_PATH0_CH1_EAXC_ID3_OFFSET		0x009Cu
#define ORAN_DL_PATH0_CH2_EAXC_ID0_OFFSET		0x00A0u
#define ORAN_DL_PATH0_CH2_EAXC_ID1_OFFSET		0x00A4u
#define ORAN_DL_PATH0_CH2_EAXC_ID2_OFFSET		0x00A8u
#define ORAN_DL_PATH0_CH2_EAXC_ID3_OFFSET		0x00ACu
#define ORAN_DL_PATH0_CH3_EAXC_ID0_OFFSET		0x00B0u
#define ORAN_DL_PATH0_CH3_EAXC_ID1_OFFSET		0x00B4u
#define ORAN_DL_PATH0_CH3_EAXC_ID2_OFFSET		0x00B8u
#define ORAN_DL_PATH0_CH3_EAXC_ID3_OFFSET		0x00BCu
#define ORAN_DL_PATH0_CH4_EAXC_ID0_OFFSET		0x00C0u
#define ORAN_DL_PATH0_CH4_EAXC_ID1_OFFSET		0x00C4u
#define ORAN_DL_PATH0_CH4_EAXC_ID2_OFFSET		0x00C8u
#define ORAN_DL_PATH0_CH4_EAXC_ID3_OFFSET		0x00CCu
#define ORAN_DL_PATH0_CH5_EAXC_ID0_OFFSET		0x00D0u
#define ORAN_DL_PATH0_CH5_EAXC_ID1_OFFSET		0x00D4u
#define ORAN_DL_PATH0_CH5_EAXC_ID2_OFFSET		0x00D8u
#define ORAN_DL_PATH0_CH5_EAXC_ID3_OFFSET		0x00DCu
#define ORAN_DL_PATH0_CH6_EAXC_ID0_OFFSET		0x00E0u
#define ORAN_DL_PATH0_CH6_EAXC_ID1_OFFSET		0x00E4u
#define ORAN_DL_PATH0_CH6_EAXC_ID2_OFFSET		0x00E8u
#define ORAN_DL_PATH0_CH6_EAXC_ID3_OFFSET		0x00ECu
#define ORAN_DL_PATH0_CH7_EAXC_ID0_OFFSET		0x00F0u
#define ORAN_DL_PATH0_CH7_EAXC_ID1_OFFSET		0x00F4u
#define ORAN_DL_PATH0_CH7_EAXC_ID2_OFFSET		0x00F8u
#define ORAN_DL_PATH0_CH7_EAXC_ID3_OFFSET		0x00FCu


#define ORAN_DL_PATH0_COMPRESSION_MODE_OFFSET	0x0100u
#define ORAN_DL_PATH0_SCS_CONFIGURATION_OFFSET	0x0104u
#define ORAN_DL_PATH0_FFT_SIZE_OFFSET			0x0108u
#define ORAN_DL_PATH0_PRB_PER_SYM_OFFSET		0x010Cu
#define ORAN_DL_PATH0_EXP_OFFSET				0x0110u


#define ORAN_UL_PATH0_COMPRESSION_MODE_OFFSET	0x0140u
#define ORAN_UL_PATH0_SCS_CONFIGURATION_OFFSET	0x0144u
#define ORAN_UL_PATH0_FFT_SIZE_OFFSET			0x0148u
#define ORAN_UL_PATH0_PRB_PER_SYM_OFFSET		0x014Cu
#define ORAN_UL_PATH0_EXP_OFFSET				0x0150u
#define ORAN_UL_PATH0_GAIN_OFFSET				0x0154u
#define ORAN_UL_PATH0_SCALE_OFFSET				0x0158u

#define ORAN_DL_PATH1_LSB_DST_MAC_OFFSET		0x0400u
#define ORAN_DL_PATH1_MSB_DST_MAC_OFFSET		0x0404u
#define ORAN_DL_PATH1_LSB_SRC_MAC_OFFSET		0x0408u
#define ORAN_DL_PATH1_MSB_SRC_MAC_OFFSET		0x040Cu
#define ORAN_DL_PATH1_VLAN0_OFFSET				0x0410u
#define ORAN_DL_PATH1_VLAN1_OFFSET				0x0414u


#define ORAN_UL_PATH1_LSB_DST_MAC_OFFSET		0x0440u
#define ORAN_UL_PATH1_MSB_DST_MAC_OFFSET		0x0444u
#define ORAN_UL_PATH1_LSB_SRC_MAC_OFFSET		0x0448u
#define ORAN_UL_PATH1_MSB_SRC_MAC_OFFSET		0x044Cu
#define ORAN_UL_PATH1_VLAN0_OFFSET				0x0450u
#define ORAN_UL_PATH1_VLAN1_OFFSET				0x0454u


#define ORAN_DL_PATH1_CH0_EAXC_ID0_OFFSET		0x0480u
#define ORAN_DL_PATH1_CH0_EAXC_ID1_OFFSET		0x0484u
#define ORAN_DL_PATH1_CH0_EAXC_ID2_OFFSET		0x0488u
#define ORAN_DL_PATH1_CH0_EAXC_ID3_OFFSET		0x048Cu
#define ORAN_DL_PATH1_CH1_EAXC_ID0_OFFSET		0x0490u
#define ORAN_DL_PATH1_CH1_EAXC_ID1_OFFSET		0x0494u
#define ORAN_DL_PATH1_CH1_EAXC_ID2_OFFSET		0x0498u
#define ORAN_DL_PATH1_CH1_EAXC_ID3_OFFSET		0x049Cu
#define ORAN_DL_PATH1_CH2_EAXC_ID0_OFFSET		0x04A0u
#define ORAN_DL_PATH1_CH2_EAXC_ID1_OFFSET		0x04A4u
#define ORAN_DL_PATH1_CH2_EAXC_ID2_OFFSET		0x04A8u
#define ORAN_DL_PATH1_CH2_EAXC_ID3_OFFSET		0x04ACu
#define ORAN_DL_PATH1_CH3_EAXC_ID0_OFFSET		0x04B0u
#define ORAN_DL_PATH1_CH3_EAXC_ID1_OFFSET		0x04B4u
#define ORAN_DL_PATH1_CH3_EAXC_ID2_OFFSET		0x04B8u
#define ORAN_DL_PATH1_CH3_EAXC_ID3_OFFSET		0x04BCu


#define ORAN_DL_PATH1_COMPRESSION_MODE_OFFSET	0x0500u
#define ORAN_DL_PATH1_SCS_CONFIGURATION_OFFSET	0x0504u
#define ORAN_DL_PATH1_FFT_SIZE_OFFSET			0x0508u
#define ORAN_DL_PATH1_PRB_PER_SYM_OFFSET		0x050Cu
#define ORAN_DL_PATH1_EXP_OFFSET				0x0510u


#define ORAN_UL_PATH1_COMPRESSION_MODE_OFFSET	0x0540u
#define ORAN_UL_PATH1_SCS_CONFIGURATION_OFFSET	0x0544u
#define ORAN_UL_PATH1_FFT_SIZE_OFFSET			0x0548u
#define ORAN_UL_PATH1_PRB_PER_SYM_OFFSET		0x054Cu
#define ORAN_UL_PATH1_EXP_OFFSET				0x0550u
#define ORAN_UL_PATH1_GAIN_OFFSET				0x0554u
#define ORAN_UL_PATH1_SCALE_OFFSET				0x0558u


#define oran_dl_path0_DST_MAC(BaseAddr, DstMac) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_LSB_DST_MAC_OFFSET, (DstMac[2]<<24 | \
                                                                      DstMac[3]<<16 | \
                                                                      DstMac[4]<< 8 | \
                                                                      DstMac[5]));\
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_MSB_DST_MAC_OFFSET, (DstMac[0]<< 8 | \
                                                                      DstMac[1]))
#define oran_dl_path0_SRC_MAC(BaseAddr, SrcMac) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_LSB_SRC_MAC_OFFSET, (SrcMac[2]<<24 | \
                                                                      SrcMac[3]<<16 | \
                                                                      SrcMac[4]<< 8 | \
                                                                      SrcMac[5]));\
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_MSB_SRC_MAC_OFFSET, (SrcMac[0]<< 8 | \
																SrcMac[1]))

#define oran_dl_path0_VLAN0_enable(BaseAddr, VlanID) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_VLAN0_OFFSET, (0x0001   << 16| \
                                                                VlanID[1]<< 8 | \
                                                                VlanID[0]))

#define oran_dl_path0_VLAN0_disable(BaseAddr) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_VLAN0_OFFSET, 0)

#define oran_dl_path0_VLAN1_enable(BaseAddr, VlanID) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_VLAN1_OFFSET, (0x0001   << 16| \
                                                                VlanID[1]<< 8 | \
                                                                VlanID[0]))

#define oran_dl_path0_VLAN1_disable(BaseAddr) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_VLAN1_OFFSET, 0)



#define oran_ul_path0_DST_MAC(BaseAddr, DstMac) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH0_LSB_DST_MAC_OFFSET, (DstMac[2]<<24 | \
                                                                      DstMac[3]<<16 | \
                                                                      DstMac[4]<< 8 | \
                                                                      DstMac[5]));\
	fpga_write32_register(BaseAddr,ORAN_UL_PATH0_MSB_DST_MAC_OFFSET, (DstMac[0]<< 8 | \
																DstMac[1]))
#define oran_ul_path0_SRC_MAC(BaseAddr, SrcMac) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH0_LSB_SRC_MAC_OFFSET, (SrcMac[2]<<24 | \
                                                                      SrcMac[3]<<16 | \
                                                                      SrcMac[4]<< 8 | \
                                                                      SrcMac[5]));\
	fpga_write32_register(BaseAddr,ORAN_UL_PATH0_MSB_SRC_MAC_OFFSET, (SrcMac[0]<< 8 | \
                                                                      SrcMac[1]))

#define oran_ul_path0_VLAN0_enable(BaseAddr, VlanID) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH0_VLAN0_OFFSET, (0x0001   << 16| \
                                                                VlanID[1]<< 8 | \
                                                                VlanID[0]))

#define oran_ul_path0_VLAN0_disable(BaseAddr) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH0_VLAN0_OFFSET, 0)


#define oran_ul_path0_VLAN1_enable(BaseAddr, VlanID) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH0_VLAN1_OFFSET, (0x0001   << 16| \
                                                                VlanID[1]<< 8 | \
                                                                VlanID[0]))

#define oran_ul_path0_VLAN1_disable(BaseAddr) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH0_VLAN1_OFFSET, 0)



#define oran_dl_path0_ch0_id0(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH0_EAXC_ID0_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch0_id1(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH0_EAXC_ID1_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch0_id2(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH0_EAXC_ID2_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch0_id3(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH0_EAXC_ID3_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch1_id0(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH1_EAXC_ID0_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch1_id1(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH1_EAXC_ID1_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch1_id2(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH1_EAXC_ID2_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch1_id3(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH1_EAXC_ID3_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch2_id0(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH2_EAXC_ID0_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch2_id1(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH2_EAXC_ID1_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch2_id2(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH2_EAXC_ID2_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch2_id3(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH2_EAXC_ID3_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch3_id0(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH3_EAXC_ID0_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch3_id1(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH3_EAXC_ID1_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch3_id2(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH3_EAXC_ID2_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch3_id3(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH3_EAXC_ID3_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch4_id0(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH4_EAXC_ID0_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch4_id1(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH4_EAXC_ID1_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch4_id2(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH4_EAXC_ID2_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch4_id3(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH4_EAXC_ID3_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch5_id0(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH5_EAXC_ID0_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch5_id1(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH5_EAXC_ID1_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch5_id2(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH5_EAXC_ID2_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch5_id3(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH5_EAXC_ID3_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch6_id0(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH6_EAXC_ID0_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch6_id1(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH6_EAXC_ID1_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch6_id2(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH6_EAXC_ID2_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch6_id3(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH6_EAXC_ID3_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch7_id0(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH7_EAXC_ID0_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch7_id1(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH7_EAXC_ID1_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch7_id2(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH7_EAXC_ID2_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path0_ch7_id3(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_CH7_EAXC_ID3_OFFSET, (0x0001 << 16 | EAXC))


#define oran_dl_path0_compression_data_mode(BaseAddr, CompMode, BitWidth) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_COMPRESSION_MODE_OFFSET, (BitWidth << 4 | CompMode))

#define oran_dl_path0_sub_carrier_mode(BaseAddr, SCS_Max, SCS_Curr) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_SCS_CONFIGURATION_OFFSET, (SCS_Max << 4 | SCS_Curr))

#define oran_dl_path0_fft_size(BaseAddr, FFT_Size) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_FFT_SIZE_OFFSET, FFT_Size)

#define oran_dl_path0_symbol_size(BaseAddr, Symbol_Size) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_PRB_PER_SYM_OFFSET, Symbol_Size)

#define oran_dl_path0_exp_offset(BaseAddr, Exp_Offset) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH0_EXP_OFFSET, Exp_Offset)

#define oran_ul_path0_compression_data_mode(BaseAddr, CompMode, BitWidth) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH0_COMPRESSION_MODE_OFFSET, (BitWidth << 4 | CompMode))

#define oran_ul_path0_sub_carrier_mode(BaseAddr, SCS_Max, SCS_Curr) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH0_SCS_CONFIGURATION_OFFSET, (SCS_Max << 4 | SCS_Curr))

#define oran_ul_path0_fft_size(BaseAddr, FFT_Size) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH0_FFT_SIZE_OFFSET, FFT_Size)

#define oran_ul_path0_symbol_size(BaseAddr, MTU_Size, Symbol_Size) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH0_PRB_PER_SYM_OFFSET, (MTU_Size << 16 | Symbol_Size))

#define oran_ul_path0_exp_offset(BaseAddr, Exp_Offset) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH0_EXP_OFFSET, Exp_Offset)

#define oran_ul_path0_gain_offset(BaseAddr, Gain_Offset) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH0_GAIN_OFFSET, Gain_Offset)

#define oran_ul_path0_scale_offset(BaseAddr, Scale_Offset) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH0_SCALE_OFFSET, Scale_Offset)

#define oran_dl_path1_DST_MAC(BaseAddr, DstMac) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_LSB_DST_MAC_OFFSET, (DstMac[2]<<24 | \
                                                                      DstMac[3]<<16 | \
                                                                      DstMac[4]<< 8 | \
                                                                      DstMac[5]));\
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_MSB_DST_MAC_OFFSET, (DstMac[0]<< 8 | \
                                                                      DstMac[1]))
#define oran_dl_path1_SRC_MAC(BaseAddr, SrcMac) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_LSB_SRC_MAC_OFFSET, (SrcMac[2]<<24 | \
                                                                      SrcMac[3]<<16 | \
                                                                      SrcMac[4]<< 8 | \
                                                                      SrcMac[5]));\
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_MSB_SRC_MAC_OFFSET, (SrcMac[0]<< 8 | \
																SrcMac[1]))

#define oran_dl_path1_VLAN0_enable(BaseAddr, VlanID) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_VLAN0_OFFSET, (0x0001   << 16| \
                                                                VlanID[1]<< 8 | \
                                                                VlanID[0]))

#define oran_dl_path1_VLAN0_disable(BaseAddr) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_VLAN0_OFFSET, 0)

#define oran_dl_path1_VLAN1_enable(BaseAddr, VlanID) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_VLAN1_OFFSET, (0x0001   << 16| \
                                                                VlanID[1]<< 8 | \
                                                                VlanID[0]))

#define oran_dl_path1_VLAN1_disable(BaseAddr) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_VLAN1_OFFSET, 0)



#define oran_ul_path1_DST_MAC(BaseAddr, DstMac) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH1_LSB_DST_MAC_OFFSET, (DstMac[2]<<24 | \
                                                                      DstMac[3]<<16 | \
                                                                      DstMac[4]<< 8 | \
                                                                      DstMac[5]));\
	fpga_write32_register(BaseAddr,ORAN_UL_PATH1_MSB_DST_MAC_OFFSET, (DstMac[0]<< 8 | \
																DstMac[1]))
#define oran_ul_path1_SRC_MAC(BaseAddr, SrcMac) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH1_LSB_SRC_MAC_OFFSET, (SrcMac[2]<<24 | \
                                                                      SrcMac[3]<<16 | \
                                                                      SrcMac[4]<< 8 | \
                                                                      SrcMac[5]));\
	fpga_write32_register(BaseAddr,ORAN_UL_PATH1_MSB_SRC_MAC_OFFSET, (SrcMac[0]<< 8 | \
                                                                      SrcMac[1]))

#define oran_ul_path1_VLAN0_enable(BaseAddr, VlanID) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH1_VLAN0_OFFSET, (0x0001   << 16| \
                                                                VlanID[1]<< 8 | \
                                                                VlanID[0]))

#define oran_ul_path1_VLAN0_disable(BaseAddr) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH1_VLAN0_OFFSET, 0)


#define oran_ul_path1_VLAN1_enable(BaseAddr, VlanID) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH1_VLAN1_OFFSET, (0x0001   << 16| \
                                                                VlanID[1]<< 8 | \
                                                                VlanID[0]))

#define oran_ul_path1_VLAN1_disable(BaseAddr) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH1_VLAN1_OFFSET, 0)



#define oran_dl_path1_ch0_id0(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH0_EAXC_ID0_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path1_ch0_id1(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH0_EAXC_ID1_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path1_ch0_id2(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH0_EAXC_ID2_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path1_ch0_id3(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH0_EAXC_ID3_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path1_ch1_id0(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH1_EAXC_ID0_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path1_ch1_id1(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH1_EAXC_ID1_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path1_ch1_id2(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH1_EAXC_ID2_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path1_ch1_id3(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH1_EAXC_ID3_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path1_ch2_id0(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH2_EAXC_ID0_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path1_ch2_id1(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH2_EAXC_ID1_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path1_ch2_id2(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH2_EAXC_ID2_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path1_ch2_id3(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH2_EAXC_ID3_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path1_ch3_id0(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH3_EAXC_ID0_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path1_ch3_id1(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH3_EAXC_ID1_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path1_ch3_id2(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH3_EAXC_ID2_OFFSET, (0x0001 << 16 | EAXC))

#define oran_dl_path1_ch3_id3(BaseAddr, EAXC) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_CH3_EAXC_ID3_OFFSET, (0x0001 << 16 | EAXC))



#define oran_dl_path1_compression_data_mode(BaseAddr, CompMode, BitWidth) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_COMPRESSION_MODE_OFFSET, (BitWidth << 4 | CompMode))

#define oran_dl_path1_sub_carrier_mode(BaseAddr, SCS_Max, SCS_Curr) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_SCS_CONFIGURATION_OFFSET, (SCS_Max << 4 | SCS_Curr))

#define oran_dl_path1_fft_size(BaseAddr, FFT_Size) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_FFT_SIZE_OFFSET, FFT_Size)

#define oran_dl_path1_symbol_size(BaseAddr, Symbol_Size) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_PRB_PER_SYM_OFFSET, Symbol_Size)

#define oran_dl_path1_exp_offset(BaseAddr, Exp_Offset) \
	fpga_write32_register(BaseAddr,ORAN_DL_PATH1_EXP_OFFSET, Exp_Offset)

#define oran_ul_path1_compression_data_mode(BaseAddr, CompMode, BitWidth) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH1_COMPRESSION_MODE_OFFSET, (BitWidth << 4 | CompMode))

#define oran_ul_path1_sub_carrier_mode(BaseAddr, SCS_Max, SCS_Curr) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH1_SCS_CONFIGURATION_OFFSET, (SCS_Max << 4 | SCS_Curr))

#define oran_ul_path1_fft_size(BaseAddr, FFT_Size) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH1_FFT_SIZE_OFFSET, FFT_Size)

#define oran_ul_path1_symbol_size(BaseAddr, MTU_Size, Symbol_Size) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH1_PRB_PER_SYM_OFFSET, (MTU_Size << 16 | Symbol_Size))

#define oran_ul_path1_exp_offset(BaseAddr, Exp_Offset) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH1_EXP_OFFSET, Exp_Offset)

#define oran_ul_path1_gain_offset(BaseAddr, Gain_Offset) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH1_GAIN_OFFSET, Gain_Offset)

#define oran_ul_path1_scale_offset(BaseAddr, Scale_Offset) \
	fpga_write32_register(BaseAddr,ORAN_UL_PATH1_SCALE_OFFSET, Scale_Offset)

#define NONE_COMPRESSION_MODE			0x0u
#define BFP_COMPRESSION_MODE			0x1u
#define DATA_16_BIT_MODE				0x0u
#define DATA_12_BIT_MODE				0xCu
#define DATA_9_BIT_MODE					0x9u

#define ORAN_SCS_15KHZ					0x0u
#define ORAN_SCS_30KHZ					0x01u

#define ORAN_FFT_512					0x9u
#define ORAN_FFT_1024					0xAu
#define ORAN_FFT_2048					0xBu
#define ORAN_FFT_4096					0xCu

#define ORAN_15KHZ_3MHZ_PRB				15
#define ORAN_15KHZ_5MHZ_PRB				25
#define ORAN_15KHZ_10MHZ_PRB			52
#define ORAN_15KHZ_15MHZ_PRB			79
#define ORAN_15KHZ_20MHZ_PRB			106


void oran_5g_3MHz_2cc_configure(u32 BaseAddr);


#endif
