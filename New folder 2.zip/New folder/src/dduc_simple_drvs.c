

#include "dduc_simple_drvs.h"

void dduc_configure(u32 core_baseaddr) {

	fpga_write32_register(core_baseaddr, DDUC_DUC0_SEL_ANT_OFFSET, 0x0009);
//	fpga_write_register(core_baseaddr, DDUC_DUC1_SEL_ANT_OFFSET, 0x0009);//

	fpga_write32_register(core_baseaddr, DDUC_DUC0_NCO_FREQ_OFFSET , 50 );
	fpga_write32_register(core_baseaddr, DDUC_DUC1_NCO_FREQ_OFFSET , 50 );
	fpga_write32_register(core_baseaddr, DDUC_DUC2_NCO_FREQ_OFFSET , 50 );
	fpga_write32_register(core_baseaddr, DDUC_DUC3_NCO_FREQ_OFFSET , 50 );
	fpga_write32_register(core_baseaddr, DDUC_DUC4_NCO_FREQ_OFFSET , 50 );
	fpga_write32_register(core_baseaddr, DDUC_DUC5_NCO_FREQ_OFFSET , 50 );
	fpga_write32_register(core_baseaddr, DDUC_DUC6_NCO_FREQ_OFFSET , 50 );
	fpga_write32_register(core_baseaddr, DDUC_DUC7_NCO_FREQ_OFFSET , 50 );

	fpga_write32_register(core_baseaddr, DDUC_DUC_NCO_FREQ_WE_OFFSET, 0x0000);
	fpga_write32_register(core_baseaddr, DDUC_DUC_NCO_FREQ_WE_OFFSET, 0xFFFF);
	fpga_write32_register(core_baseaddr, DDUC_DUC_NCO_FREQ_WE_OFFSET, 0x0000);

    fpga_write32_register(core_baseaddr, DDUC_DDC0_NCO_FREQ_OFFSET , 0x00025780);
    fpga_write32_register(core_baseaddr, DDUC_DDC1_NCO_FREQ_OFFSET , 0x00025780);
    fpga_write32_register(core_baseaddr, DDUC_DDC2_NCO_FREQ_OFFSET , 0x00025780);
    fpga_write32_register(core_baseaddr, DDUC_DDC3_NCO_FREQ_OFFSET , 0x00025780);

    fpga_write32_register(core_baseaddr, DDUC_DDC_NCO_FREQ_WE_OFFSET, 0x0000);
    fpga_write32_register(core_baseaddr, DDUC_DDC_NCO_FREQ_WE_OFFSET, 0xFFFF);
    fpga_write32_register(core_baseaddr, DDUC_DDC_NCO_FREQ_WE_OFFSET, 0x0000);

    fpga_write32_register(core_baseaddr, DDUC_DDC0_SEL_ANT_OFFSET , 0x0001);
    fpga_write32_register(core_baseaddr, DDUC_DDC1_SEL_ANT_OFFSET , 0x0001);
    fpga_write32_register(core_baseaddr, DDUC_DDC2_SEL_ANT_OFFSET , 0x0010);
    fpga_write32_register(core_baseaddr, DDUC_DDC3_SEL_ANT_OFFSET , 0x0011);

    fpga_write32_register(core_baseaddr, DACIF_ON_OFF , 0xF);


//    u32 freq_off = 0x0000100;
//        for (int i = 0; i < 10000; i++)
//        {
//        	freq_off = freq_off + 0x100;
//
//    		fpga_write_register(core_baseaddr, DDUC_DDC0_NCO_FREQ_OFFSET , freq_off);
//    		    fpga_write_register(core_baseaddr, DDUC_DDC1_NCO_FREQ_OFFSET , freq_off);
//    		    fpga_write_register(core_baseaddr, DDUC_DDC2_NCO_FREQ_OFFSET , freq_off);
//    		    fpga_write_register(core_baseaddr, DDUC_DDC3_NCO_FREQ_OFFSET , freq_off);
//
//    		    fpga_write_register(core_baseaddr, DDUC_DDC_NCO_FREQ_WE_OFFSET, 0x0000);
//    		    fpga_write_register(core_baseaddr, DDUC_DDC_NCO_FREQ_WE_OFFSET, 0xFFFF);
//    		    fpga_write_register(core_baseaddr, DDUC_DDC_NCO_FREQ_WE_OFFSET, 0x0000);
//
//    		    fpga_write_register(core_baseaddr, DDUC_DDC0_SEL_ANT_OFFSET , 0x0010);
//    		    fpga_write_register(core_baseaddr, DDUC_DDC1_SEL_ANT_OFFSET , 0x0032);
//    		    fpga_write_register(core_baseaddr, DDUC_DDC2_SEL_ANT_OFFSET , 0x0010);
//    		    fpga_write_register(core_baseaddr, DDUC_DDC3_SEL_ANT_OFFSET , 0x0032);
//
//    //		usleep(0.1);
//        }



}
