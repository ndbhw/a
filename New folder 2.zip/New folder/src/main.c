#include "xparameters.h"
#include "stdio.h"

#include "core_baseaddr.h"

#include "sysctrl_drvs.h"
#include "oran_simple_drvs.h"

#include "lphy_simple_top_drvs.h"
#include "lphy_simple_dl_drvs.h"
#include "lphy_simple_ul_drvs.h"
#include "lphy_simple_ra_drvs.h"

#include "bbctrl_simple_drvs.h"
#include "dduc_simple_drvs.h"
#include "dcif_simple_drvs.h"

int main() {


	sysctrl_preset(SYSCTRL_BASEADDR);

	sysctrl_reset(SYSCTRL_BASEADDR);

	bbctrl_config(RU_BBCTRL_BASEADDR);

	lphy_simple_top_config(RU_LPHY_TOP_BASEADDR);

	lphy_simple_dl_config_LTE_15MHz(RU_LPHY_DL_CC0_BASEADDR);
	lphy_simple_ul_config_LTE_20MHz(RU_LPHY_UL_CC0_BASEADDR);
	lphy_simple_ra_LTE_3MHz(RU_LPHY_RA_CC0_BASEADDR);

	lphy_simple_dl_config_LTE_15MHz(RU_LPHY_DL_CC1_BASEADDR);
	lphy_simple_ul_config_LTE_20MHz(RU_LPHY_UL_CC1_BASEADDR);
	lphy_simple_ra_LTE_3MHz(RU_LPHY_RA_CC1_BASEADDR);

	// DDUC configure
	dduc_configure(RU_DDUC_BASEADDR);


	//// DCIF


	fpga_write_register(RU_DCIF_BASEADDR, DCIF_TX_TEST_PTN_SEL, 0x00);
	fpga_write_register(RU_DCIF_BASEADDR, DCIF_TX_TEST_NCO, 0x12);
	fpga_write_register(RU_DCIF_BASEADDR, DCIF_TX_IQ_SWAP_CTRL, 0x01);

	fpga_write_register(RU_DCIF_BASEADDR, DCIF_RX_IQ_SWAP_CTRL, 0x01);

	fpga_write_register(RU_DCIF_BASEADDR, DCIF_FB_IQ_SWAP_CTRL, 0x01);



	return 0;
}
