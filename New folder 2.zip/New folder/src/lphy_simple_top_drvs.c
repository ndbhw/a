#include "lphy_simple_top_drvs.h"

void lphy_simple_top_config(uint32_t BaseAddr) {
	lphy_simple_top_ul_cc0_sync_retard(BaseAddr, 1);
	lphy_simple_top_dlfe_cc0_prog_dly(BaseAddr);
	lphy_simple_top_ulfe_cc0_prog_dly(BaseAddr);
	lphy_simple_top_rafe_cc0_prog_dly(BaseAddr);
	lphy_simple_top_uldl_cc0_diff(BaseAddr);
}
