#ifndef DDUC_SIMPLE_DRVS_H
#define DDUC_SIMPLE_DRVS_H

#include "fpga_register_config.h"

#define DDUC_DUC0_SEL_ANT_OFFSET                     0x1604u
#define DDUC_DUC1_SEL_ANT_OFFSET                     0x1608u
#define DDUC_DUC2_SEL_ANT_OFFSET                     0x160Cu
#define DDUC_DUC3_SEL_ANT_OFFSET                     0x1610u
#define DDUC_DUC4_SEL_ANT_OFFSET                     0x1614u
#define DDUC_DUC5_SEL_ANT_OFFSET                     0x1618u
#define DDUC_DUC6_SEL_ANT_OFFSET                     0x161Cu
#define DDUC_DUC7_SEL_ANT_OFFSET                     0x1620u
#define DDUC_DUC8_SEL_ANT_OFFSET                     0x1624u
#define DDUC_DUC9_SEL_ANT_OFFSET                     0x1628u
#define DDUC_DUC10_SEL_ANT_OFFSET                    0x162Cu
#define DDUC_DUC11_SEL_ANT_OFFSET                    0x1630u
#define DDUC_DUC12_SEL_ANT_OFFSET                    0x1634u
#define DDUC_DUC13_SEL_ANT_OFFSET                    0x1638u
#define DDUC_DUC14_SEL_ANT_OFFSET                    0x163Cu
#define DDUC_DUC15_SEL_ANT_OFFSET                    0x1640u

#define DDUC_DUC_NCO_FREQ_WE_OFFSET                  0x1400u
#define DDUC_DUC0_NCO_FREQ_OFFSET                    0x1404u
#define DDUC_DUC1_NCO_FREQ_OFFSET                    0x1408u
#define DDUC_DUC2_NCO_FREQ_OFFSET                    0x140Cu
#define DDUC_DUC3_NCO_FREQ_OFFSET                    0x1410u
#define DDUC_DUC4_NCO_FREQ_OFFSET                    0x1414u
#define DDUC_DUC5_NCO_FREQ_OFFSET                    0x1418u
#define DDUC_DUC6_NCO_FREQ_OFFSET                    0x141Cu
#define DDUC_DUC7_NCO_FREQ_OFFSET                    0x1420u
#define DDUC_DUC8_NCO_FREQ_OFFSET                    0x1424u
#define DDUC_DUC9_NCO_FREQ_OFFSET                    0x1428u
#define DDUC_DUC10_NCO_FREQ_OFFSET                   0x142Cu
#define DDUC_DUC11_NCO_FREQ_OFFSET                   0x1430u
#define DDUC_DUC12_NCO_FREQ_OFFSET                   0x1434u
#define DDUC_DUC13_NCO_FREQ_OFFSET                   0x1438u
#define DDUC_DUC14_NCO_FREQ_OFFSET                   0x143Cu
#define DDUC_DUC15_NCO_FREQ_OFFSET                   0x1440u
#define DDUC_DUC16_NCO_FREQ_OFFSET                   0x1444u
#define DDUC_DUC17_NCO_FREQ_OFFSET                   0x1448u
#define DDUC_DUC18_NCO_FREQ_OFFSET                   0x144Cu
#define DDUC_DUC19_NCO_FREQ_OFFSET                   0x1450u
#define DDUC_DUC20_NCO_FREQ_OFFSET                   0x1454u
#define DDUC_DUC21_NCO_FREQ_OFFSET                   0x1458u
#define DDUC_DUC22_NCO_FREQ_OFFSET                   0x145Cu
#define DDUC_DUC23_NCO_FREQ_OFFSET                   0x1460u
#define DDUC_DUC24_NCO_FREQ_OFFSET                   0x1464u
#define DDUC_DUC25_NCO_FREQ_OFFSET                   0x1468u
#define DDUC_DUC26_NCO_FREQ_OFFSET                   0x146Cu
#define DDUC_DUC27_NCO_FREQ_OFFSET                   0x1470u

#define DDUC_DDC_NCO_FREQ_WE_OFFSET                  0x1800u
#define DDUC_DDC0_NCO_FREQ_OFFSET                    0x1804u
#define DDUC_DDC1_NCO_FREQ_OFFSET                    0x1808u
#define DDUC_DDC2_NCO_FREQ_OFFSET                    0x180Cu
#define DDUC_DDC3_NCO_FREQ_OFFSET                    0x1810u
#define DDUC_DDC4_NCO_FREQ_OFFSET                    0x1814u
#define DDUC_DDC5_NCO_FREQ_OFFSET                    0x1818u
#define DDUC_DDC6_NCO_FREQ_OFFSET                    0x181Cu
#define DDUC_DDC7_NCO_FREQ_OFFSET                    0x1820u
#define DDUC_DDC8_NCO_FREQ_OFFSET                    0x1824u
#define DDUC_DDC9_NCO_FREQ_OFFSET                    0x1828u
#define DDUC_DDC10_NCO_FREQ_OFFSET                   0x182Cu
#define DDUC_DDC11_NCO_FREQ_OFFSET                   0x1830u
#define DDUC_DDC12_NCO_FREQ_OFFSET                   0x1834u
#define DDUC_DDC13_NCO_FREQ_OFFSET                   0x1838u
#define DDUC_DDC14_NCO_FREQ_OFFSET                   0x183Cu
#define DDUC_DDC15_NCO_FREQ_OFFSET                   0x1840u
#define DDUC_DDC16_NCO_FREQ_OFFSET                   0x1844u
#define DDUC_DDC17_NCO_FREQ_OFFSET                   0x1848u
#define DDUC_DDC18_NCO_FREQ_OFFSET                   0x184Cu
#define DDUC_DDC19_NCO_FREQ_OFFSET                   0x1850u
#define DDUC_DDC20_NCO_FREQ_OFFSET                   0x5854u
#define DDUC_DDC21_NCO_FREQ_OFFSET                   0x1858u
#define DDUC_DDC22_NCO_FREQ_OFFSET                   0x185Cu
#define DDUC_DDC23_NCO_FREQ_OFFSET                   0x1860u
#define DDUC_DDC24_NCO_FREQ_OFFSET                   0x1864u
#define DDUC_DDC25_NCO_FREQ_OFFSET                   0x1868u
#define DDUC_DDC26_NCO_FREQ_OFFSET                   0x186Cu
#define DDUC_DDC27_NCO_FREQ_OFFSET                   0x1870u

#define DDUC_DDC0_SEL_ANT_OFFSET                     0x1A00u
#define DDUC_DDC1_SEL_ANT_OFFSET                     0x1A04u
#define DDUC_DDC2_SEL_ANT_OFFSET                     0x1A08u
#define DDUC_DDC3_SEL_ANT_OFFSET                     0x1A0Cu


#define DACIF_ON_OFF								 0x3200

void dduc_configure(u32 core_baseaddr);


#endif
