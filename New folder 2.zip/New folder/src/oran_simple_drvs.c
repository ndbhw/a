#include "oran_simple_drvs.h"

void oran_5g_3MHz_2cc_configure(u32 BaseAddr) {
	u8 DL_DST_MAC[6] = {0x80, 0x09, 0x02, 0x03, 0x04, 0x05};
	u8 DL_SRC_MAC[6] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	u8 UL_DST_MAC[6] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	u8 UL_SRC_MAC[6] = {0x80, 0x09, 0x02, 0x03, 0x04, 0x05};

	oran_dl_path0_DST_MAC(BaseAddr, DL_DST_MAC);
	oran_dl_path0_SRC_MAC(BaseAddr, DL_SRC_MAC);
	oran_dl_path0_VLAN0_disable(BaseAddr);
	oran_dl_path0_VLAN1_disable(BaseAddr);

	oran_ul_path0_DST_MAC(BaseAddr, UL_DST_MAC);
	oran_ul_path0_SRC_MAC(BaseAddr, UL_SRC_MAC);
	oran_ul_path0_VLAN0_disable(BaseAddr);
	oran_ul_path0_VLAN1_disable(BaseAddr);

//	oran_dl_path1_DST_MAC(BaseAddr, DL_DST_MAC);
//	oran_dl_path1_SRC_MAC(BaseAddr, DL_SRC_MAC);
//	oran_dl_path1_VLAN0_disable(BaseAddr);
//	oran_dl_path1_VLAN1_disable(BaseAddr);
//
//	oran_ul_path1_DST_MAC(BaseAddr, UL_DST_MAC);
//	oran_ul_path1_SRC_MAC(BaseAddr, UL_SRC_MAC);
//	oran_ul_path1_VLAN0_disable(BaseAddr);
//	oran_ul_path1_VLAN1_disable(BaseAddr);

	// 1 2 3 4 5 6 7 8 for DLFE
	oran_dl_path0_ch0_id0(BaseAddr, 0x01);
	oran_dl_path0_ch1_id0(BaseAddr, 0x02);
	oran_dl_path0_ch2_id0(BaseAddr, 0x03);
	oran_dl_path0_ch3_id0(BaseAddr, 0x04);
	oran_dl_path0_ch4_id0(BaseAddr, 0x05);
	oran_dl_path0_ch5_id0(BaseAddr, 0x06);
	oran_dl_path0_ch6_id0(BaseAddr, 0x07);
	oran_dl_path0_ch7_id0(BaseAddr, 0x08);


//	oran_dl_path1_ch0_id0(BaseAddr, 0x05);
//	oran_dl_path1_ch1_id0(BaseAddr, 0x06);

	//  1  2  3  4  5  6  7  8 for ULFE
	// 11 12 13 14 15 16 17 18 for RAFE
	oran_dl_path0_ch0_id2(BaseAddr, 0x01);
	oran_dl_path0_ch0_id3(BaseAddr, 0x41);

	oran_dl_path0_ch1_id2(BaseAddr, 0x02);
	oran_dl_path0_ch1_id3(BaseAddr, 0x42);

	oran_dl_path0_ch2_id2(BaseAddr, 0x03);
	oran_dl_path0_ch2_id3(BaseAddr, 0x43);

	oran_dl_path0_ch3_id2(BaseAddr, 0x04);
	oran_dl_path0_ch3_id3(BaseAddr, 0x44);

	oran_dl_path0_ch4_id2(BaseAddr, 0x05);
	oran_dl_path0_ch4_id3(BaseAddr, 0x45);

	oran_dl_path0_ch5_id2(BaseAddr, 0x06);
	oran_dl_path0_ch5_id3(BaseAddr, 0x46);

	oran_dl_path0_ch6_id2(BaseAddr, 0x07);
	oran_dl_path0_ch6_id3(BaseAddr, 0x47);

	oran_dl_path0_ch7_id2(BaseAddr, 0x08);
	oran_dl_path0_ch7_id3(BaseAddr, 0x48);

//	oran_dl_path1_ch0_id2(BaseAddr, 0x05);
//	oran_dl_path1_ch0_id3(BaseAddr, 0x15);
//
//	oran_dl_path1_ch1_id2(BaseAddr, 0x06);
//	oran_dl_path1_ch1_id3(BaseAddr, 0x16);
//
//	oran_dl_path1_ch2_id2(BaseAddr, 0x07);
//	oran_dl_path1_ch2_id3(BaseAddr, 0x17);
//
//	oran_dl_path1_ch3_id2(BaseAddr, 0x08);
//	oran_dl_path1_ch3_id3(BaseAddr, 0x18);


	oran_dl_path0_compression_data_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran_dl_path0_sub_carrier_mode(BaseAddr,ORAN_SCS_15KHZ, ORAN_SCS_15KHZ);
	oran_dl_path0_fft_size(BaseAddr,ORAN_FFT_1024);
	oran_dl_path0_symbol_size(BaseAddr,ORAN_15KHZ_3MHZ_PRB);
	oran_dl_path0_exp_offset(BaseAddr, 0);

	oran_ul_path0_compression_data_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
	oran_ul_path0_sub_carrier_mode(BaseAddr,ORAN_SCS_15KHZ, ORAN_SCS_15KHZ);
	oran_ul_path0_fft_size(BaseAddr,ORAN_FFT_1024);
	oran_ul_path0_symbol_size(BaseAddr,13, ORAN_15KHZ_3MHZ_PRB);
	oran_ul_path0_exp_offset(BaseAddr, 0);
	oran_ul_path0_gain_offset(BaseAddr, 0);
	oran_ul_path0_scale_offset(BaseAddr, 0);

//	oran_dl_path1_compression_data_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
//	oran_dl_path1_sub_carrier_mode(BaseAddr,ORAN_SCS_15KHZ, ORAN_SCS_15KHZ);
//	oran_dl_path1_fft_size(BaseAddr,ORAN_FFT_1024);
//	oran_dl_path1_symbol_size(BaseAddr,ORAN_15KHZ_3MHZ_PRB);
//	oran_dl_path1_exp_offset(BaseAddr, 0);
//
//	oran_ul_path1_compression_data_mode(BaseAddr, NONE_COMPRESSION_MODE, DATA_16_BIT_MODE);
//	oran_ul_path1_sub_carrier_mode(BaseAddr,ORAN_SCS_15KHZ, ORAN_SCS_15KHZ);
//	oran_ul_path1_fft_size(BaseAddr,ORAN_FFT_1024);
//	oran_ul_path1_symbol_size(BaseAddr,13, ORAN_15KHZ_3MHZ_PRB);
//	oran_ul_path1_exp_offset(BaseAddr, 0);
//	oran_ul_path1_gain_offset(BaseAddr, 0);
//	oran_ul_path1_scale_offset(BaseAddr, 0);



}
