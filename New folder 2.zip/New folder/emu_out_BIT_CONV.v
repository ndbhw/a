module emu_out_BIT_CONV (
    input clk,
    input rst,

    output reg         O_RX_10MS,
    output wire        O_RX_TDD,
    output reg         O_RX_SYNC,
    output reg  [15:0] O_RX_DATA_I,
    output reg  [15:0] O_RX_DATA_Q
);

    assign O_RX_TDD = 1'b1;

    reg [15:0] cc0_i0,cc0_i1;
    reg [15:0] cc0_q0,cc0_q1;
    reg [15:0] cc1_i0,cc1_i1;
    reg [15:0] cc1_q0,cc1_q1;

    reg        sim_start ;
    reg [31:0] cnt_start;

    reg        r_csync;
    reg [5:0]  cnt_csync;

    reg [2:0]  cnt_data;     // 0..4 : index of data sample

    always @(posedge clk) begin
        if(rst == 'b1) begin
            cnt_start <= 'd0;
        end
        else begin
            if(sim_start == 'b0) begin
                cnt_start <= cnt_start + 'd1;
            end
        end
    end

    always @(posedge clk) begin
        if(rst == 'b1) begin
            sim_start <= 'b0;
        end
        else begin
            if(sim_start == 'b0 && cnt_start == 'd27258) begin //27258
                sim_start <= 'b1;
            end
        end
    end

    always @(posedge clk) begin
        if((rst == 'b1)||(sim_start==0)) begin
            cnt_csync   <= 'd0;
        end
        else begin
            if(cnt_csync[2:0]=='d7) begin   // 15M / 20M
                cnt_csync   <= 'd0;
            end
            else begin
                cnt_csync   <= cnt_csync + 'd1;
            end
        end
    end

    always @(posedge clk) begin
        if((rst == 'b1)||(sim_start==0)) begin
            r_csync   <= 'd0;
        end
        else begin
            if(cnt_csync=='d0) begin
                r_csync   <= 'b1;
            end
            else begin
                r_csync   <= 'b0;
            end
        end
    end

    always @(posedge clk) begin
        if((rst == 'b1)||(sim_start==0)) begin
            cnt_data <= 'd0;
        end
        else begin
            if(r_csync=='d1) begin
                if(cnt_data>='d4) begin
                    cnt_data <= 'd0;
                end
                else begin
                    cnt_data <= cnt_data + 'd1;
                end
            end
        end
    end

    // cc0_i0 :   0   2   4   6   8      cc1_i0 : 100 102 104 106 108
    // cc0_i1 :  10  12  14  16  18      cc1_i1 : 110 112 114 116 118
    // cc0_q0 :   1   3   5   7   9      cc1_q0 : 101 103 105 107 109
    // cc0_q1 :  11  13  15  17  19      cc1_q1 : 111 113 115 117 119
    always @(posedge clk) begin
        if((rst == 'b1)||(sim_start==0)) begin
            cc0_i0  <= 'd0;
            cc0_i1  <= 'd0;
            cc0_q0  <= 'd0;
            cc0_q1  <= 'd0;

            cc1_i0  <= 'd0;
            cc1_i1  <= 'd0;
            cc1_q0  <= 'd0;
            cc1_q1  <= 'd0;
        end
        else begin
            if(r_csync=='d1) begin
                cc0_i0  <= {cnt_data,1'b0} +   'd0;
                cc0_i1  <= {cnt_data,1'b0} +  'd10;
                cc0_q0  <= {cnt_data,1'b0} +   'd1;
                cc0_q1  <= {cnt_data,1'b0} +  'd11;

                cc1_i0  <= {cnt_data,1'b0} + 'd100;
                cc1_i1  <= {cnt_data,1'b0} + 'd110;
                cc1_q0  <= {cnt_data,1'b0} + 'd101;
                cc1_q1  <= {cnt_data,1'b0} + 'd111;
            end
        end
    end

    // ---------------------------------------------------------------
    // Buoc 2: delay & ghep
    //   O_RX_DATA_I : cc0_i0 cc0_i1 cc1_i0 cc1_i1 0 0 0 0 (chu ky 8 clk)
    //   O_RX_DATA_Q : cc0_q0 cc0_q1 cc1_q0 cc1_q1 0 0 0 0
    //   O_RX_SYNC   : pulse 1 clk ngay truoc mau dau tien, chu ky 64 clk
    // ---------------------------------------------------------------
    reg [15:0] cc0_i1_d1;
    reg [15:0] cc1_i0_d1, cc1_i0_d2;
    reg [15:0] cc1_i1_d1, cc1_i1_d2, cc1_i1_d3;
    reg [15:0] cc0_q1_d1;
    reg [15:0] cc1_q0_d1, cc1_q0_d2;
    reg [15:0] cc1_q1_d1, cc1_q1_d2, cc1_q1_d3;

    reg [5:0]  cnt_sync;     // 0..63

    always @(posedge clk) begin
        if((rst == 'b1)||(sim_start==0)) begin
            cc0_i1_d1 <= 'd0;
            cc1_i0_d1 <= 'd0;
            cc1_i0_d2 <= 'd0;
            cc1_i1_d1 <= 'd0;
            cc1_i1_d2 <= 'd0;
            cc1_i1_d3 <= 'd0;

            cc0_q1_d1 <= 'd0;
            cc1_q0_d1 <= 'd0;
            cc1_q0_d2 <= 'd0;
            cc1_q1_d1 <= 'd0;
            cc1_q1_d2 <= 'd0;
            cc1_q1_d3 <= 'd0;
        end
        else begin
            cc0_i1_d1 <= cc0_i1;
            cc1_i0_d1 <= cc1_i0;
            cc1_i0_d2 <= cc1_i0_d1;
            cc1_i1_d1 <= cc1_i1;
            cc1_i1_d2 <= cc1_i1_d1;
            cc1_i1_d3 <= cc1_i1_d2;

            cc0_q1_d1 <= cc0_q1;
            cc1_q0_d1 <= cc1_q0;
            cc1_q0_d2 <= cc1_q0_d1;
            cc1_q1_d1 <= cc1_q1;
            cc1_q1_d2 <= cc1_q1_d1;
            cc1_q1_d3 <= cc1_q1_d2;
        end
    end

    // cc* cap nhat o cuoi chu ky cnt_csync==1 -> on dinh tu cnt_csync==2
    always @(posedge clk) begin
        if((rst == 'b1)||(sim_start==0)) begin
            O_RX_DATA_I <= 'd0;
            O_RX_DATA_Q <= 'd0;
        end
        else begin
            if(cnt_csync=='d2) begin
                O_RX_DATA_I <= cc0_i0;
                O_RX_DATA_Q <= cc0_q0;
            end
            else if(cnt_csync=='d3) begin
                O_RX_DATA_I <= cc0_i1_d1;
                O_RX_DATA_Q <= cc0_q1_d1;
            end
            else if(cnt_csync=='d4) begin
                O_RX_DATA_I <= cc1_i0_d2;
                O_RX_DATA_Q <= cc1_q0_d2;
            end
            else if(cnt_csync=='d5) begin
                O_RX_DATA_I <= cc1_i1_d3;
                O_RX_DATA_Q <= cc1_q1_d3;
            end
            else begin
                O_RX_DATA_I <= 'd0;
                O_RX_DATA_Q <= 'd0;
            end
        end
    end

    // cnt_sync[2:0] luon bang cnt_csync[2:0]
    always @(posedge clk) begin
        if((rst == 'b1)||(sim_start==0)) begin
            cnt_sync <= 'd0;
        end
        else begin
            cnt_sync <= cnt_sync + 'd1;
        end
    end

    // O_RX_SYNC = 1 trong chu ky cnt_sync==2, data ra o chu ky 3..6
    always @(posedge clk) begin
        if((rst == 'b1)||(sim_start==0)) begin
            O_RX_SYNC <= 'b0;
        end
        else begin
            if(cnt_sync=='d1) begin
                O_RX_SYNC <= 'b1;
            end
            else begin
                O_RX_SYNC <= 'b0;
            end
        end
    end

    // ---------------------------------------------------------------
    // Buoc 3: O_RX_10MS pulse 1 clk, chu ky 10ms
    //   clk = 245.76 MHz -> 10ms = 2457600 clk (= 38400 x 64)
    //   cnt_10ms[5:0] luon bang cnt_sync -> O_RX_10MS trung voi O_RX_SYNC
    // ---------------------------------------------------------------
    reg [21:0] cnt_10ms;     // 0..2457599

    always @(posedge clk) begin
        if((rst == 'b1)||(sim_start==0)) begin
            cnt_10ms <= 'd0;
        end
        else begin
            if(cnt_10ms>='d2457599) begin
                cnt_10ms <= 'd0;
            end
            else begin
                cnt_10ms <= cnt_10ms + 'd1;
            end
        end
    end

    always @(posedge clk) begin
        if((rst == 'b1)||(sim_start==0)) begin
            O_RX_10MS <= 'b0;
        end
        else begin
            if(cnt_10ms=='d1) begin
                O_RX_10MS <= 'b1;
            end
            else begin
                O_RX_10MS <= 'b0;
            end
        end
    end




endmodule
