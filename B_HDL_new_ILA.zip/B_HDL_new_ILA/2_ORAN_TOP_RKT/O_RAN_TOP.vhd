--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : O-RAN TOP (B13)                                               --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.PKG_O_RAN.ALL;
use WORK.ARRAY_TYPE.ALL;

entity O_RAN_TOP is
    generic (
        CELL_NUM_DL                 : natural :=  2;
        CELL_NUM_UL                 : natural :=  2;
        CELL_NUM_eMTC               : natural :=  1;
        CELL_NUM_NBIOT              : natural :=  3;
        PATH_NUM                    : natural :=  4
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        ARESET_RX                   : in  std_logic_vector(0 downto 0);
        ARESET_TX                   : in  std_logic_vector(0 downto 0);

        CLK_MAC_RX                  : in  std_logic;                            -- 156.25/390.625-MHz
        CLK_MAC_TX                  : in  std_logic;                            -- 156.25/390.625-MHz
        CLK_BUS                     : in  std_logic;                            -- 245.76-MHz

--------------------------------------------------------------------------------
-- Sync
--------------------------------------------------------------------------------

        FRAME_SYNC                  : in  std_logic;                            -- should be aligned with 1PPS
        BFN_NUM_IN                  : in  std_logic_vector(11 downto 0);

        DL_CC_SYNC_ADVANCE          : in  std_logic_vector(CELL_NUM_DL*22-1 downto 0);
        UL_CC_SYNC_RETARD           : in  std_logic_vector(CELL_NUM_UL*22-1 downto 0);
        N_TA_OFFSET                 : in  std_logic_vector(CELL_NUM_DL*16-1 downto 0);

--------------------------------------------------------------------------------
-- CPU interface
--------------------------------------------------------------------------------

        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        RDVAL_CPUIF_OUT             : out std_logic;

--------------------------------------------------------------------------------
-- MAC#0
--------------------------------------------------------------------------------

        MAC0_RX_VALID               : in  std_logic;
        MAC0_RX_LAST                : in  std_logic;
        MAC0_RX_KEEP                : in  std_logic_vector(7 downto 0);
        MAC0_RX_DATA                : in  std_logic_vector(63 downto 0);

        MAC0_TX_READY               : in  std_logic;
        MAC0_TX_VALID               : out std_logic;
        MAC0_TX_LAST                : out std_logic;
        MAC0_TX_KEEP                : out std_logic_vector(7 downto 0);
        MAC0_TX_DATA                : out std_logic_vector(63 downto 0);

--------------------------------------------------------------------------------
-- External port (Aurora)
--------------------------------------------------------------------------------

        EXT_RU_RX_TVALID            : out std_logic;
        EXT_RU_RX_TLAST             : out std_logic;
        EXT_RU_RX_TKEEP             : out std_logic_vector(7 downto 0);
        EXT_RU_RX_TDATA             : out std_logic_vector(63 downto 0);

        EXT_RU_TX_TREADY            : out std_logic;
        EXT_RU_TX_TVALID            : in  std_logic;
        EXT_RU_TX_TLAST             : in  std_logic;
        EXT_RU_TX_TKEEP             : in  std_logic_vector(7 downto 0);
        EXT_RU_TX_TDATA             : in  std_logic_vector(63 downto 0);

--------------------------------------------------------------------------------
-- DLFE
--------------------------------------------------------------------------------

        DLFE_CC_SYSTEM_MODE         : in  std_logic_vector(CELL_NUM_DL*1-1 downto 0);
        DLFE_CC_K0                  : in  std_logic_vector(CELL_NUM_DL*12-1 downto 0);
        DLFE_CC_nRE                 : in  std_logic_vector(CELL_NUM_DL*12-1 downto 0);
        DLFE_CC_nFFT                : in  std_logic_vector(CELL_NUM_DL*2-1 downto 0);
        DLFE_CC_BFN_NUM_OUT         : out std_logic_vector(CELL_NUM_DL*12-1 downto 0);
        DLFE_CC_FRAME_SYNC          : out std_logic_vector(CELL_NUM_DL*1-1 downto 0);
        DLFE_CC_FRAME_INDEX         : out std_logic_vector(CELL_NUM_DL*8-1 downto 0);
        DLFE_CC_FRAME_STRUCTURE     : out std_logic_vector(CELL_NUM_DL*8-1 downto 0);
        DLFE_CC_SYSTEM_MODE_DSS     : out std_logic_vector(CELL_NUM_DL*PATH_NUM*1-1 downto 0);
        DLFE_CC_VALID               : out std_logic_vector(CELL_NUM_DL*PATH_NUM*1-1 downto 0);
        DLFE_CC_RE_MASK             : out std_logic_vector(CELL_NUM_DL*PATH_NUM*1-1 downto 0);
        DLFE_CC_DATA                : out std_logic_vector(CELL_NUM_DL*PATH_NUM*32-1 downto 0);

--------------------------------------------------------------------------------
-- LTE PUxCH
--------------------------------------------------------------------------------

        ULFE_CC_FRAME_ID            : in  std_logic_vector(CELL_NUM_UL*8-1 downto 0);
        ULFE_CC_SUBFRAME_ID         : in  std_logic_vector(CELL_NUM_UL*4-1 downto 0);
        ULFE_CC_SLOT_ID             : in  std_logic_vector(CELL_NUM_UL*6-1 downto 0);
        ULFE_CC_SYMBOL_ID           : in  std_logic_vector(CELL_NUM_UL*6-1 downto 0);
        ULFE_CC_START_RE            : in  std_logic_vector(CELL_NUM_UL*PATH_NUM*16-1 downto 0);
        ULFE_CC_VALID               : in  std_logic_vector(CELL_NUM_UL*PATH_NUM*1-1 downto 0);
        ULFE_CC_START               : in  std_logic_vector(CELL_NUM_UL*PATH_NUM*1-1 downto 0);
        ULFE_CC_LAST                : in  std_logic_vector(CELL_NUM_UL*PATH_NUM*1-1 downto 0);
        ULFE_CC_DATA                : in  std_logic_vector(CELL_NUM_UL*PATH_NUM*32-1 downto 0);

--------------------------------------------------------------------------------
-- LTE PRACH
--------------------------------------------------------------------------------

        RAFE_CC_FRAME_ID            : in  std_logic_vector(CELL_NUM_UL*8-1 downto 0);
        RAFE_CC_SUBFRAME_ID         : in  std_logic_vector(CELL_NUM_UL*4-1 downto 0);
        RAFE_CC_SLOT_ID             : in  std_logic_vector(CELL_NUM_UL*6-1 downto 0);
        RAFE_CC_SYMBOL_ID           : in  std_logic_vector(CELL_NUM_UL*6-1 downto 0);
        RAFE_CC_START_RE            : in  std_logic_vector(CELL_NUM_UL*PATH_NUM*16-1 downto 0);
        RAFE_CC_VALID               : in  std_logic_vector(CELL_NUM_UL*PATH_NUM*1-1 downto 0);
        RAFE_CC_START               : in  std_logic_vector(CELL_NUM_UL*PATH_NUM*1-1 downto 0);
        RAFE_CC_LAST                : in  std_logic_vector(CELL_NUM_UL*PATH_NUM*1-1 downto 0);
        RAFE_CC_DATA                : in  std_logic_vector(CELL_NUM_UL*PATH_NUM*32-1 downto 0);

        RAFE_CC_FRAME_SYNC          : out std_logic_vector(CELL_NUM_UL*1-1 downto 0);
        RAFE_CC_FILTER_INDEX        : out std_logic_vector(CELL_NUM_UL*PATH_NUM*4-1 downto 0);
        RAFE_CC_TIME_OFFSET         : out std_logic_vector(CELL_NUM_UL*PATH_NUM*16-1 downto 0);
        RAFE_CC_FRAME_STRUCTURE     : out std_logic_vector(CELL_NUM_UL*PATH_NUM*8-1 downto 0);
        RAFE_CC_CPLENGTH            : out std_logic_vector(CELL_NUM_UL*PATH_NUM*16-1 downto 0);
        RAFE_CC_FREQ_OFFSET         : out std_logic_vector(CELL_NUM_UL*PATH_NUM*24-1 downto 0);
        RAFE_CC_START_PRBC          : out std_logic_vector(CELL_NUM_UL*PATH_NUM*10-1 downto 0);
        RAFE_CC_NUM_PRBC            : out std_logic_vector(CELL_NUM_UL*PATH_NUM*8-1 downto 0);
        RAFE_CC_NUM_PSYMBOL         : out std_logic_vector(CELL_NUM_UL*PATH_NUM*4-1 downto 0);
        RAFE_CC_NUM_RO              : out std_logic_vector(CELL_NUM_UL*PATH_NUM*3-1 downto 0);

--------------------------------------------------------------------------------
-- eMTC PRACH
--------------------------------------------------------------------------------

        eMTC_CC_FRAME_ID            : in  std_logic_vector(CELL_NUM_eMTC*8-1 downto 0);
        eMTC_CC_SUBFRAME_ID         : in  std_logic_vector(CELL_NUM_eMTC*4-1 downto 0);
        eMTC_CC_SLOT_ID             : in  std_logic_vector(CELL_NUM_eMTC*6-1 downto 0);
        eMTC_CC_SYMBOL_ID           : in  std_logic_vector(CELL_NUM_eMTC*6-1 downto 0);
        eMTC_CC_START_RE            : in  std_logic_vector(CELL_NUM_eMTC*PATH_NUM*16-1 downto 0);
        eMTC_CC_VALID               : in  std_logic_vector(CELL_NUM_eMTC*PATH_NUM*1-1 downto 0);
        eMTC_CC_START               : in  std_logic_vector(CELL_NUM_eMTC*PATH_NUM*1-1 downto 0);
        eMTC_CC_LAST                : in  std_logic_vector(CELL_NUM_eMTC*PATH_NUM*1-1 downto 0);
        eMTC_CC_DATA                : in  std_logic_vector(CELL_NUM_eMTC*PATH_NUM*32-1 downto 0);

        eMTC_CC_FRAME_SYNC          : out std_logic_vector(CELL_NUM_eMTC*1-1 downto 0);
        eMTC_CC_FILTER_INDEX        : out std_logic_vector(CELL_NUM_eMTC*PATH_NUM*4-1 downto 0);
        eMTC_CC_TIME_OFFSET         : out std_logic_vector(CELL_NUM_eMTC*PATH_NUM*16-1 downto 0);
        eMTC_CC_FRAME_STRUCTURE     : out std_logic_vector(CELL_NUM_eMTC*PATH_NUM*8-1 downto 0);
        eMTC_CC_CPLENGTH            : out std_logic_vector(CELL_NUM_eMTC*PATH_NUM*16-1 downto 0);
        eMTC_CC_FREQ_OFFSET         : out std_logic_vector(CELL_NUM_eMTC*PATH_NUM*24-1 downto 0);
        eMTC_CC_START_PRBC          : out std_logic_vector(CELL_NUM_eMTC*PATH_NUM*10-1 downto 0);
        eMTC_CC_NUM_PRBC            : out std_logic_vector(CELL_NUM_eMTC*PATH_NUM*8-1 downto 0);
        eMTC_CC_NUM_PSYMBOL         : out std_logic_vector(CELL_NUM_eMTC*PATH_NUM*4-1 downto 0);
        eMTC_CC_NUM_RO              : out std_logic_vector(CELL_NUM_eMTC*PATH_NUM*3-1 downto 0);

--------------------------------------------------------------------------------
-- NB-IoT
--------------------------------------------------------------------------------

        NBIOT_CC_FRAME_ID           : in  std_logic_vector(CELL_NUM_NBIOT*8-1 downto 0);
        NBIOT_CC_SUBFRAME_ID        : in  std_logic_vector(CELL_NUM_NBIOT*4-1 downto 0);
        NBIOT_CC_SLOT_ID            : in  std_logic_vector(CELL_NUM_NBIOT*6-1 downto 0);
        NBIOT_CC_SYMBOL_ID          : in  std_logic_vector(CELL_NUM_NBIOT*6-1 downto 0);
        NBIOT_CC_START_RE           : in  std_logic_vector(CELL_NUM_NBIOT*PATH_NUM*16-1 downto 0);
        NBIOT_CC_VALID              : in  std_logic_vector(CELL_NUM_NBIOT*PATH_NUM*1-1 downto 0);
        NBIOT_CC_START              : in  std_logic_vector(CELL_NUM_NBIOT*PATH_NUM*1-1 downto 0);
        NBIOT_CC_LAST               : in  std_logic_vector(CELL_NUM_NBIOT*PATH_NUM*1-1 downto 0);
        NBIOT_CC_DATA               : in  std_logic_vector(CELL_NUM_NBIOT*PATH_NUM*32-1 downto 0);

        NBIOT_CC_FRAME_SYNC         : out std_logic_vector(CELL_NUM_NBIOT*1-1 downto 0);
        NBIOT_CC_FILTER_INDEX       : out std_logic_vector(CELL_NUM_NBIOT*PATH_NUM*4-1 downto 0);
        NBIOT_CC_TIME_OFFSET        : out std_logic_vector(CELL_NUM_NBIOT*PATH_NUM*16-1 downto 0);
        NBIOT_CC_FRAME_STRUCTURE    : out std_logic_vector(CELL_NUM_NBIOT*PATH_NUM*8-1 downto 0);
        NBIOT_CC_CPLENGTH           : out std_logic_vector(CELL_NUM_NBIOT*PATH_NUM*16-1 downto 0);
        NBIOT_CC_FREQ_OFFSET        : out std_logic_vector(CELL_NUM_NBIOT*PATH_NUM*24-1 downto 0);
        NBIOT_CC_START_PRBC         : out std_logic_vector(CELL_NUM_NBIOT*PATH_NUM*10-1 downto 0);
        NBIOT_CC_NUM_PRBC           : out std_logic_vector(CELL_NUM_NBIOT*PATH_NUM*8-1 downto 0);
        NBIOT_CC_NUM_PSYMBOL        : out std_logic_vector(CELL_NUM_NBIOT*PATH_NUM*4-1 downto 0);
        NBIOT_CC_NUM_RO             : out std_logic_vector(CELL_NUM_NBIOT*PATH_NUM*3-1 downto 0)
    );
end O_RAN_TOP;

architecture BEHAVE of O_RAN_TOP is

--    type boolean_array              is array(natural range <>) of boolean;
--    type natural_array              is array(natural range <>) of natural range 0 to 8;
    constant MAX_CH_PER_UNIT        : natural range 0 to 8 := 8;                -- Channel muxing per unit (Max : 8)
    constant MAX_ID_PER_CH          : natural range 0 to 8 := 4;                -- eAxC ID per each channel (Max : 4)

    constant OFFSET                 : std_logic_vector(3 downto 0) := x"2";

--    constant CC                     : natural := 2;
--    constant DL_ANT                 : natural := 4;
--    constant UL_ANT                 : natural := 4;

--    constant DL_PATH                : natural := CC*DL_ANT;
--    constant UL_PATH                : natural := CC*UL_ANT;

    constant DL_UNIT                : natural := 1;
    constant UL_UNIT                : natural := 1;

    component MAC_INTERCONNECT is
    generic (
        DL_UNIT                     : natural := 2;
        UL_UNIT                     : natural := 2;
        EN_DL_INPUT_REG             : boolean := false;
        EN_DL_OUTPUT_REG            : boolean := false;
        EN_UL_INPUT_REG             : boolean := false;
        EN_UL_OUTPUT_REG            : boolean := false
    );
    port (
        CLK_MAC_RX                  : in  std_logic;
        CLK_MAC_TX                  : in  std_logic;

        RST_RX                      : in  std_logic;
        RST_TX                      : in  std_logic;

        MAC0_RX_VALID               : in  std_logic;
        MAC0_RX_LAST                : in  std_logic;
        MAC0_RX_KEEP                : in  std_logic_vector(7 downto 0);
        MAC0_RX_DATA                : in  std_logic_vector(63 downto 0);

        MAC0_TX_READY               : in  std_logic;
        MAC0_TX_VALID               : out std_logic;
        MAC0_TX_LAST                : out std_logic;
        MAC0_TX_KEEP                : out std_logic_vector(7 downto 0);
        MAC0_TX_DATA                : out std_logic_vector(63 downto 0);

        INT_RU_RX_TVALID            : out std_logic_vector(DL_UNIT-1 downto 0);
        INT_RU_RX_TLAST             : out std_logic_vector(DL_UNIT-1 downto 0);
        INT_RU_RX_TKEEP             : out std_logic_array8(DL_UNIT-1 downto 0);
        INT_RU_RX_TDATA             : out std_logic_array64(DL_UNIT-1 downto 0);

        INT_RU_TX_TREADY            : out std_logic_vector(UL_UNIT-1 downto 0);
        INT_RU_TX_TVALID            : in  std_logic_vector(UL_UNIT-1 downto 0);
        INT_RU_TX_TLAST             : in  std_logic_vector(UL_UNIT-1 downto 0);
        INT_RU_TX_TKEEP             : in  std_logic_array8(UL_UNIT-1 downto 0);
        INT_RU_TX_TDATA             : in  std_logic_array64(UL_UNIT-1 downto 0);

        EXT_RU_RX_TVALID            : out std_logic;
        EXT_RU_RX_TLAST             : out std_logic;
        EXT_RU_RX_TKEEP             : out std_logic_vector(7 downto 0);
        EXT_RU_RX_TDATA             : out std_logic_vector(63 downto 0);

        EXT_RU_TX_TREADY            : out std_logic;
        EXT_RU_TX_TVALID            : in  std_logic;
        EXT_RU_TX_TLAST             : in  std_logic;
        EXT_RU_TX_TKEEP             : in  std_logic_vector(7 downto 0);
        EXT_RU_TX_TDATA             : in  std_logic_vector(63 downto 0)
    );
    end component;

    signal mac_rx_valid             : std_logic_vector(DL_UNIT-1 downto 0);
    signal mac_rx_last              : std_logic_vector(DL_UNIT-1 downto 0);
    signal mac_rx_keep              : std_logic_array8(DL_UNIT-1 downto 0);
    signal mac_rx_data              : std_logic_array64(DL_UNIT-1 downto 0);

    signal mac_tx_ready             : std_logic_vector(0 downto 0);
    signal mac_tx_valid             : std_logic_vector(0 downto 0);
    signal mac_tx_last              : std_logic_vector(0 downto 0);
    signal mac_tx_keep              : std_logic_array8(0 downto 0);
    signal mac_tx_data              : std_logic_array64(0 downto 0);

    signal ulfe_frame_id            : std_logic_array8(UL_UNIT-1 downto 0);
    signal ulfe_subframe_id         : std_logic_array4(UL_UNIT-1 downto 0);
    signal ulfe_slot_id             : std_logic_array6(UL_UNIT-1 downto 0);
    signal ulfe_symbol_id           : std_logic_array6(UL_UNIT-1 downto 0);
    signal ulfe_start_re            : std_logic_array16(UL_UNIT-1 downto 0);
    signal ulfe_valid               : std_logic_array8(UL_UNIT-1 downto 0);
    signal ulfe_start               : std_logic_array8(UL_UNIT-1 downto 0);
    signal ulfe_last                : std_logic_array8(UL_UNIT-1 downto 0);
    signal ulfe_data_i              : std_logic_array8_array16(UL_UNIT-1 downto 0);
    signal ulfe_data_q              : std_logic_array8_array16(UL_UNIT-1 downto 0);

    signal rafe_frame_id            : std_logic_array8(UL_UNIT-1 downto 0);
    signal rafe_subframe_id         : std_logic_array4(UL_UNIT-1 downto 0);
    signal rafe_slot_id             : std_logic_array6(UL_UNIT-1 downto 0);
    signal rafe_symbol_id           : std_logic_array6(UL_UNIT-1 downto 0);
    signal rafe_start_re            : std_logic_array16(UL_UNIT-1 downto 0);
    signal rafe_valid               : std_logic_array8(UL_UNIT-1 downto 0);
    signal rafe_start               : std_logic_array8(UL_UNIT-1 downto 0);
    signal rafe_last                : std_logic_array8(UL_UNIT-1 downto 0);
    signal rafe_data_i              : std_logic_array8_array16(UL_UNIT-1 downto 0);
    signal rafe_data_q              : std_logic_array8_array16(UL_UNIT-1 downto 0);

    signal emtc_frame_id            : std_logic_array8(UL_UNIT-1 downto 0);
    signal emtc_subframe_id         : std_logic_array4(UL_UNIT-1 downto 0);
    signal emtc_slot_id             : std_logic_array6(UL_UNIT-1 downto 0);
    signal emtc_symbol_id           : std_logic_array6(UL_UNIT-1 downto 0);
    signal emtc_start_re            : std_logic_array16(UL_UNIT-1 downto 0);
    signal emtc_valid               : std_logic_array8(UL_UNIT-1 downto 0);
    signal emtc_start               : std_logic_array8(UL_UNIT-1 downto 0);
    signal emtc_last                : std_logic_array8(UL_UNIT-1 downto 0);
    signal emtc_data_i              : std_logic_array8_array16(UL_UNIT-1 downto 0);
    signal emtc_data_q              : std_logic_array8_array16(UL_UNIT-1 downto 0);

    signal nbiot0_frame_id          : std_logic_array8(UL_UNIT-1 downto 0);
    signal nbiot0_subframe_id       : std_logic_array4(UL_UNIT-1 downto 0);
    signal nbiot0_slot_id           : std_logic_array6(UL_UNIT-1 downto 0);
    signal nbiot0_symbol_id         : std_logic_array6(UL_UNIT-1 downto 0);
    signal nbiot0_start_re          : std_logic_array16(UL_UNIT-1 downto 0);
    signal nbiot0_valid             : std_logic_array8(UL_UNIT-1 downto 0);
    signal nbiot0_start             : std_logic_array8(UL_UNIT-1 downto 0);
    signal nbiot0_last              : std_logic_array8(UL_UNIT-1 downto 0);
    signal nbiot0_data_i            : std_logic_array8_array16(UL_UNIT-1 downto 0);
    signal nbiot0_data_q            : std_logic_array8_array16(UL_UNIT-1 downto 0);

    signal nbiot1_frame_id          : std_logic_array8(UL_UNIT-1 downto 0);
    signal nbiot1_subframe_id       : std_logic_array4(UL_UNIT-1 downto 0);
    signal nbiot1_slot_id           : std_logic_array6(UL_UNIT-1 downto 0);
    signal nbiot1_symbol_id         : std_logic_array6(UL_UNIT-1 downto 0);
    signal nbiot1_start_re          : std_logic_array16(UL_UNIT-1 downto 0);
    signal nbiot1_valid             : std_logic_array8(UL_UNIT-1 downto 0);
    signal nbiot1_start             : std_logic_array8(UL_UNIT-1 downto 0);
    signal nbiot1_last              : std_logic_array8(UL_UNIT-1 downto 0);
    signal nbiot1_data_i            : std_logic_array8_array16(UL_UNIT-1 downto 0);
    signal nbiot1_data_q            : std_logic_array8_array16(UL_UNIT-1 downto 0);

    signal nbiot2_frame_id          : std_logic_array8(UL_UNIT-1 downto 0);
    signal nbiot2_subframe_id       : std_logic_array4(UL_UNIT-1 downto 0);
    signal nbiot2_slot_id           : std_logic_array6(UL_UNIT-1 downto 0);
    signal nbiot2_symbol_id         : std_logic_array6(UL_UNIT-1 downto 0);
    signal nbiot2_start_re          : std_logic_array16(UL_UNIT-1 downto 0);
    signal nbiot2_valid             : std_logic_array8(UL_UNIT-1 downto 0);
    signal nbiot2_start             : std_logic_array8(UL_UNIT-1 downto 0);
    signal nbiot2_last              : std_logic_array8(UL_UNIT-1 downto 0);
    signal nbiot2_data_i            : std_logic_array8_array16(UL_UNIT-1 downto 0);
    signal nbiot2_data_q            : std_logic_array8_array16(UL_UNIT-1 downto 0);

    component O_RAN_DEFRAMER is
    generic (
        MAX_CH_PER_UNIT             : natural := 2;
        FILTER_MAC                  : boolean := true;
        FILTER_ETHERTYPE            : boolean := true;
        USAGE_C_PLANE               : boolean := true;
        USAGE_U_PLANE               : boolean := true
    );
    port (
        RST                         : in  std_logic;

        CLK_MAC                     : in  std_logic;
        CLK_BUS                     : in  std_logic;

        RX_PARAM_MAC                : in  std_logic_vector(47 downto 0);
        RX_PARAM_ETHERTYPE          : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_0_EN        : in  std_logic;
        RX_PARAM_ID_CH0_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_1_EN        : in  std_logic;
        RX_PARAM_ID_CH0_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_2_EN        : in  std_logic;
        RX_PARAM_ID_CH0_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_3_EN        : in  std_logic;
        RX_PARAM_ID_CH0_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_0_EN        : in  std_logic;
        RX_PARAM_ID_CH1_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_1_EN        : in  std_logic;
        RX_PARAM_ID_CH1_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_2_EN        : in  std_logic;
        RX_PARAM_ID_CH1_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_3_EN        : in  std_logic;
        RX_PARAM_ID_CH1_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_0_EN        : in  std_logic;
        RX_PARAM_ID_CH2_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_1_EN        : in  std_logic;
        RX_PARAM_ID_CH2_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_2_EN        : in  std_logic;
        RX_PARAM_ID_CH2_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_3_EN        : in  std_logic;
        RX_PARAM_ID_CH2_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_0_EN        : in  std_logic;
        RX_PARAM_ID_CH3_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_1_EN        : in  std_logic;
        RX_PARAM_ID_CH3_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_2_EN        : in  std_logic;
        RX_PARAM_ID_CH3_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_3_EN        : in  std_logic;
        RX_PARAM_ID_CH3_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_0_EN        : in  std_logic;
        RX_PARAM_ID_CH4_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_1_EN        : in  std_logic;
        RX_PARAM_ID_CH4_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_2_EN        : in  std_logic;
        RX_PARAM_ID_CH4_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_3_EN        : in  std_logic;
        RX_PARAM_ID_CH4_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_0_EN        : in  std_logic;
        RX_PARAM_ID_CH5_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_1_EN        : in  std_logic;
        RX_PARAM_ID_CH5_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_2_EN        : in  std_logic;
        RX_PARAM_ID_CH5_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_3_EN        : in  std_logic;
        RX_PARAM_ID_CH5_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_0_EN        : in  std_logic;
        RX_PARAM_ID_CH6_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_1_EN        : in  std_logic;
        RX_PARAM_ID_CH6_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_2_EN        : in  std_logic;
        RX_PARAM_ID_CH6_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_3_EN        : in  std_logic;
        RX_PARAM_ID_CH6_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_0_EN        : in  std_logic;
        RX_PARAM_ID_CH7_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_1_EN        : in  std_logic;
        RX_PARAM_ID_CH7_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_2_EN        : in  std_logic;
        RX_PARAM_ID_CH7_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_3_EN        : in  std_logic;
        RX_PARAM_ID_CH7_3           : in  std_logic_vector(15 downto 0);

        RX_COMP_MODE                : in  std_logic;
        RX_IQ_WIDTH                 : in  std_logic_vector(3 downto 0);
        RX_COMP_METHOD              : in  std_logic_vector(3 downto 0);
        RX_SCS_CONFIG               : in  std_logic_vector(3 downto 0);
        RX_FFT_SIZE                 : in  std_logic_vector(3 downto 0);
        RX_PRB_PER_SYMBOL           : in  std_logic_vector(9 downto 0);
        RX_COMP_EXP_OFFSET          : in  std_logic_vector(4 downto 0);

        USAGE_RX_DATA_BUFFER        : out std_logic_vector(31 downto 0);

        RX_INVALID_DST_MAC          : out std_logic_vector(31 downto 0);
        RX_INVALID_ETHERTYPE        : out std_logic_vector(31 downto 0);
        RX_INVALID_ecpriVersion     : out std_logic_vector(31 downto 0);
        RX_INVALID_ecpriC           : out std_logic_vector(31 downto 0);
        RX_INVALID_ecpriMessage     : out std_logic_vector(31 downto 0);
        RX_C_PLANE                  : out std_logic_vector(31 downto 0);
        RX_C_PLANE_DROPPED          : out std_logic_vector(31 downto 0);
        RX_U_PLANE                  : out std_logic_vector(31 downto 0);
        RX_U_PLANE_DROPPED          : out std_logic_vector(31 downto 0);
        RX_LOST                     : out std_logic_vector(31 downto 0);

        RX_LENGTH_IS_NORMAL         : out std_logic_vector(31 downto 0);
        RX_LENGTH_IS_LONG           : out std_logic_vector(31 downto 0);
        RX_LENGTH_IS_SHORT          : out std_logic_vector(31 downto 0);

        RX_C_PLANE_EXIST            : out std_logic_vector(31 downto 0);
        RX_U_PLANE_EXIST            : out std_logic_vector(31 downto 0);

        RX_FAULT_ID_31_CH0          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH1          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH2          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH3          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH4          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH5          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH6          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH7          : out std_logic_vector(3 downto 0);

        MAC_RX_READY                : out std_logic;
        MAC_RX_VALID                : in  std_logic;
        MAC_RX_LAST                 : in  std_logic;
        MAC_RX_KEEP                 : in  std_logic_vector(7 downto 0);
        MAC_RX_DATA                 : in  std_logic_vector(63 downto 0);

        PACKET_IS_CP_DL             : out std_logic;
        PACKET_IS_CP_UL             : out std_logic;
        PACKET_IS_UP_DL             : out std_logic;
        PACKET_IS_UP_UL             : out std_logic;
        PACKET_SCS                  : out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             : out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              : out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            : out std_logic_vector(5 downto 0);

        BYPASS_OUT_VALID            : out std_logic;
        BYPASS_OUT_LAST             : out std_logic;
        BYPASS_OUT_KEEP             : out std_logic_vector(7 downto 0);
        BYPASS_OUT_DATA             : out std_logic_vector(63 downto 0);

        eCPRI_RX_C_VALID            : out std_logic;
        eCPRI_RX_C_LAST             : out std_logic;
        eCPRI_RX_C_KEEP             : out std_logic_vector(3 downto 0);
        eCPRI_RX_C_DATA             : out std_logic_vector(31 downto 0);
        eCPRI_RX_C_CH               : out std_logic_vector(2 downto 0);
        eCPRI_RX_C_CH_SUB           : out std_logic_vector(3 downto 0);

        ADV_RB_CHANNEL_ID           : out std_logic_vector(2 downto 0);
        ADV_RB_FRAME_ID             : out std_logic_vector(7 downto 0);
        ADV_RB_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        ADV_RB_SLOT_ID              : out std_logic_vector(5 downto 0);
        ADV_RB_SYMBOL_ID            : out std_logic_vector(5 downto 0);
        ADV_RB_START                : out std_logic;

        RB_eAxC_ID                  : out std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              : out std_logic_vector(15 downto 0);
        RB_CHANNEL_ID               : out std_logic_vector(2 downto 0);
        RB_FRAME_ID                 : out std_logic_vector(7 downto 0);
        RB_SUBFRAME_ID              : out std_logic_vector(3 downto 0);
        RB_SLOT_ID                  : out std_logic_vector(5 downto 0);
        RB_SYMBOL_ID                : out std_logic_vector(5 downto 0);
        RB_SECTION_ID               : out std_logic_vector(11 downto 0);
        RB_NUMBER                   : out std_logic_vector(9 downto 0);
        RE_NUMBER                   : out std_logic_vector(11 downto 0);

        RB_VALID                    : out std_logic;
        RB_START                    : out std_logic;
        RB_TICK                     : out std_logic;
        RB_LAST                     : out std_logic;
        RB_DATA_I                   : out std_logic_vector(15 downto 0);
        RB_DATA_Q                   : out std_logic_vector(15 downto 0)
    );
    end component;

    signal rx_packet_is_cp_dl       : std_logic_vector(DL_UNIT-1 downto 0);
    signal rx_packet_is_cp_ul       : std_logic_vector(DL_UNIT-1 downto 0);
    signal rx_packet_is_up_dl       : std_logic_vector(DL_UNIT-1 downto 0);
    signal rx_packet_scs            : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_packet_frame_id       : std_logic_array8(DL_UNIT-1 downto 0);
    signal rx_packet_subframe_id    : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_packet_slot_id        : std_logic_array6(DL_UNIT-1 downto 0);
    signal rx_packet_symbol_id      : std_logic_array6(DL_UNIT-1 downto 0);
    signal ecpri_rx_c_valid         : std_logic_vector(DL_UNIT-1 downto 0);
    signal ecpri_rx_c_valid_split   : std_logic_vector(UL_UNIT-1 downto 0);
    signal ecpri_rx_c_last          : std_logic_vector(DL_UNIT-1 downto 0);
    signal ecpri_rx_c_keep          : std_logic_array4(DL_UNIT-1 downto 0);
    signal ecpri_rx_c_data          : std_logic_array32(DL_UNIT-1 downto 0);
    signal ecpri_rx_c_ch            : std_logic_array4(DL_UNIT-1 downto 0) := (others => (others => '0'));
    signal ecpri_rx_c_ch_split      : std_logic_array4(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal ecpri_rx_c_ch_sub        : std_logic_array4(DL_UNIT-1 downto 0);
    signal freq_offset_for_prach_0  : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_prach_1  : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_prach_2  : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_prach_3  : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_prach_4  : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_prach_5  : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_prach_6  : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_prach_7  : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_emtc_0   : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_emtc_1   : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_emtc_2   : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_emtc_3   : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_emtc_4   : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_emtc_5   : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_emtc_6   : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_emtc_7   : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_nprach_0 : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_nprach_1 : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_nprach_2 : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_nprach_3 : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_nprach_4 : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_nprach_5 : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_nprach_6 : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_nprach_7 : std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch0_0: std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch0_1: std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch0_2: std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch0_3: std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch0_4: std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch0_5: std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch0_6: std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch0_7: std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch1_0: std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch1_1: std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch1_2: std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch1_3: std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch1_4: std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch1_5: std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch1_6: std_logic_array24(UL_UNIT-1 downto 0);
    signal freq_offset_for_npusch1_7: std_logic_array24(UL_UNIT-1 downto 0);
--    signal dl_adv_rb_channel_id     : std_logic_array3(DL_UNIT-1 downto 0);
--    signal dl_adv_rb_frame_id       : std_logic_array8(DL_UNIT-1 downto 0);
--    signal dl_adv_rb_subframe_id    : std_logic_array4(DL_UNIT-1 downto 0);
--    signal dl_adv_rb_slot_id        : std_logic_array6(DL_UNIT-1 downto 0);
--    signal dl_adv_rb_symbol_id      : std_logic_array6(DL_UNIT-1 downto 0);
--    signal dl_adv_rb_start          : std_logic_vector(DL_UNIT-1 downto 0);
--    signal dl_rb_eaxc_id            : std_logic_array16(DL_UNIT-1 downto 0);
--    signal dl_rb_sequence_id        : std_logic_array16(DL_UNIT-1 downto 0);
    signal dl_rb_channel_id         : std_logic_array4(DL_UNIT-1 downto 0) := (others => (others => '0'));
    signal dl_rb_frame_id           : std_logic_array8(DL_UNIT-1 downto 0);
    signal dl_rb_subframe_id        : std_logic_array4(DL_UNIT-1 downto 0);
    signal dl_rb_slot_id            : std_logic_array6(DL_UNIT-1 downto 0);
    signal dl_rb_symbol_id          : std_logic_array6(DL_UNIT-1 downto 0);
    signal dl_rb_section_id         : std_logic_array12(DL_UNIT-1 downto 0);
--    signal dl_rb_number             : std_logic_array10(DL_UNIT-1 downto 0);
    signal dl_re_number             : std_logic_array12(DL_UNIT-1 downto 0);
    signal dl_rb_valid              : std_logic_vector(DL_UNIT-1 downto 0);
    signal dl_rb_start              : std_logic_vector(DL_UNIT-1 downto 0);
    signal dl_rb_tick               : std_logic_vector(DL_UNIT-1 downto 0);
    signal dl_rb_last               : std_logic_vector(DL_UNIT-1 downto 0);
    signal dl_rb_data_i             : std_logic_array16(DL_UNIT-1 downto 0);
    signal dl_rb_data_q             : std_logic_array16(DL_UNIT-1 downto 0);

    component CU_PE_TOP is
    generic (
    VENDOR                          : string  := "XILINX";
    Category                        : string  :=      "B";
    eCPRI_HDR                       : boolean :=     TRUE;
    iFFT_k0_SHIFT                   : boolean :=     TRUE;
    iFFT_ZERO_PADDING               : boolean :=    FALSE;
    SCS                             : natural :=       30;
    SECTION_NUM                     : natural :=      256;
    Max_RB_NUM                      : natural :=      273;
    iFFT_WIDTH                      : natural :=       12;
    SYMBOL_NUM                      : natural :=        7;
    CH_NUM                          : natural :=        2; -- Layer/Path @ module
    DL_LAYER_NUM                    : natural :=        4;
    UL_RX_NUM                       : natural :=        8;
    CELL_NUM_eMTC                   : natural :=        1;
    CELL_NUM_NBIOT                  : natural :=        3;
    PATH_NUM                        : natural :=        4; -- Layer/Path @ cell
    Opt_BF_Support                  : natural :=        1  -- Mandatory: 0, Optional: 1
    );
    port (

    CLK                             : in  std_logic;

    -- 1 clk pulse, should be aligned with 1PPS
    FRAME_SYNC                      : in  std_logic;
    DL_SYNC_ADVANCE                 : in  std_logic_vector(22*2-1 downto 0);
    UL_SYNC_RETARD                  : in  std_logic_vector(21 downto 0);

    -- FSU CPRI NR only mode
    BFN_NUM_IN                      : in  std_logic_vector(11 downto 0);
    BFN_NUM_OUT                     : out std_logic_vector(11 downto 0);

    --------------------------------------------------------------------------------
    -- ORAN_TOP
    --------------------------------------------------------------------------------

    -- DL/UL C-Plane
    ECPRI_RX_C_CH_IDX               : in  std_logic_vector( 3 downto 0);
    ECPRI_RX_C_VALID                : in  std_logic;
    ECPRI_RX_C_LAST                 : in  std_logic;
    ECPRI_RX_C_KEEP                 : in  std_logic_vector( 3 downto 0);
    ECPRI_RX_C_DATA                 : in  std_logic_vector(31 downto 0);

    -- DL U-Plane
    RB_CH_IDX                       : in  std_logic_vector( 3 downto 0);
    RB_FRAME_ID                     : in  std_logic_vector( 7 downto 0);
    RB_SUBFRAME_ID                  : in  std_logic_vector( 3 downto 0);
    RB_SLOT_ID                      : in  std_logic_vector( 5 downto 0);
    RB_SYMBOL_ID                    : in  std_logic_vector( 5 downto 0);
    RB_SECTION_ID                   : in  std_logic_vector(11 downto 0);
    RE_NUMBER                       : in  std_logic_vector(11 downto 0);

    RB_VALID                        : in  std_logic;
    RB_START                        : in  std_logic;
    RB_LAST                         : in  std_logic;
    RB_TICK                         : in  std_logic;
    RB_DATA_I                       : in  std_logic_vector(15 downto 0);
    RB_DATA_Q                       : in  std_logic_vector(15 downto 0);

    --------------------------------------------------------------------------------
    -- DLFE/ULFE/RAFE
    --------------------------------------------------------------------------------

    SYSTEM_MODE                     : in  std_logic;                     -- 0: LTE, 1: NR
    K0                              : in  std_logic_vector(11 downto 0);
    nRE                             : in  std_logic_vector(12*2-1 downto 0);
    nFFT                            : in  std_logic_vector( 2*2-1 downto 0);
    DL_FRAME_SYNC                   : out std_logic;
    DL_FRAME_INDEX                  : out std_logic_vector( 7 downto 0);
    DL_FRAME_STRUCTURE              : out std_logic_vector( 7 downto 0);
    DL_MuSu_nLayer                  : out std_logic_vector( 4 downto 0); -- just for Optional BF
    DL_VALID                        : out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);
    DL_RE_MASK                      : out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);
    DL_BEAMID                       : out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*15 - 1 downto 0);
    DL_DATA                         : out std_logic_vector(CH_NUM*32 - 1 downto 0);

    UL_FRAME_SYNC                   : out std_logic;
    UL_FILTER_INDEX                 : out std_logic_vector( 4*4-1 downto 0);
    UL_TIME_OFFSET                  : out std_logic_vector(16*4-1 downto 0);
    UL_FRAME_STRUCTURE              : out std_logic_vector( 8*4-1 downto 0);
    UL_CPLENGTH                     : out std_logic_vector(16*4-1 downto 0);
    UL_FREQ_OFFSET                  : out std_logic_vector(24*4-1 downto 0);
    UL_START_PRBC                   : out std_logic_vector(10*4-1 downto 0);
    UL_NUM_PRBC                     : out std_logic_vector( 8*4-1 downto 0);
    UL_NUM_PSYMBOL                  : out std_logic_vector( 4*4-1 downto 0);
    UL_NUM_RO                       : out std_logic_vector( 3*4-1 downto 0);

    UL_eMTC_FILTER_INDEX            : out std_logic_vector( 4*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
    UL_eMTC_TIME_OFFSET             : out std_logic_vector(16*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
    UL_eMTC_FRAME_STRUCTURE         : out std_logic_vector( 8*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
    UL_eMTC_CPLENGTH                : out std_logic_vector(16*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
    UL_eMTC_FREQ_OFFSET             : out std_logic_vector(24*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
    UL_eMTC_START_PRBC              : out std_logic_vector(10*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
    UL_eMTC_NUM_PRBC                : out std_logic_vector( 8*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
    UL_eMTC_NUM_PSYMBOL             : out std_logic_vector( 4*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
    UL_eMTC_NUM_RO                  : out std_logic_vector( 3*CELL_NUM_eMTC*PATH_NUM-1 downto 0);

    UL_NB_FILTER_INDEX              : out std_logic_vector( 4*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
    UL_NB_TIME_OFFSET               : out std_logic_vector(16*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
    UL_NB_FRAME_STRUCTURE           : out std_logic_vector( 8*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
    UL_NB_CPLENGTH                  : out std_logic_vector(16*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
    UL_NB_FREQ_OFFSET               : out std_logic_vector(24*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
    UL_NB_START_PRBC                : out std_logic_vector(10*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
    UL_NB_NUM_PRBC                  : out std_logic_vector( 8*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
    UL_NB_NUM_PSYMBOL               : out std_logic_vector( 4*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
    UL_NB_NUM_RO                    : out std_logic_vector( 3*CELL_NUM_NBIOT*PATH_NUM-1 downto 0)
    );
    end component;

    signal dl_sync_advance          : std_logic_array22(15 downto 0);
    signal ul_sync_retard           : std_logic_array22(15 downto 0);

    signal tdd_sym_sync             : std_logic_vector(15 downto 0);
    signal tdd_sym_index            : std_logic_array4(15 downto 0);
    signal tdd_dl_enable            : std_logic_array2(15 downto 0);
    signal tdd_ul_enable            : std_logic_array2(15 downto 0);

    signal dlfe_k0                  : std_logic_array12(15 downto 0);
    signal dlfe_nRE                 : std_logic_array12(15 downto 0);
    signal dlfe_nFFT                : std_logic_array2(15 downto 0);
    signal dlfe_system_mode_dss     : std_logic_vector(15 downto 0);
    signal dlfe_bfn_num_out         : std_logic_array12(15 downto 0);
    signal dlfe_frame_sync          : std_logic_vector(15 downto 0);
    signal dlfe_frame_index         : std_logic_array8(15 downto 0);
    signal dlfe_subframe_index      : std_logic_array4(15 downto 0);
    signal dlfe_slot_index          : std_logic_array6(15 downto 0);
    signal dlfe_symbol_sync         : std_logic_vector(15 downto 0);
    signal dlfe_symbol_index        : std_logic_array4(15 downto 0);
    signal dlfe_valid               : std_logic_array2(15 downto 0);
    signal dlfe_frame_structure     : std_logic_array8(15 downto 0);
    signal dlfe_re_mask             : std_logic_array2(15 downto 0);
    signal dlfe_MuSu_nLayer         : std_logic_array5(15 downto 0);
    signal dlfe_beamId              : std_logic_array60(15 downto 0);
    signal dlfe_data                : std_logic_array64(15 downto 0);
    signal rafe_frame_sync          : std_logic_vector(15 downto 0);
    signal rafe_slot_sync           : std_logic_vector(15 downto 0);
    signal rafe_subframe_index      : std_logic_array4(15 downto 0);
    signal rafe_slot_index          : std_logic_array6(15 downto 0);
    signal rafe_filter_index        : std_logic_array16(15 downto 0);
    signal rafe_time_offset         : std_logic_array64(15 downto 0);
    signal rafe_frame_structure     : std_logic_array32(15 downto 0);
    signal rafe_cplength            : std_logic_array64(15 downto 0);
    signal rafe_freq_offset         : std_logic_array96(15 downto 0);
    signal rafe_start_prbc          : std_logic_array40(15 downto 0);
    signal rafe_num_prbc            : std_logic_array32(15 downto 0);
    signal rafe_num_psymbol         : std_logic_array16(15 downto 0);
    signal rafe_num_ro              : std_logic_array12(15 downto 0);
    signal eMTC_filter_index        : std_logic_array16(15 downto 0);
    signal eMTC_time_offset         : std_logic_array64(15 downto 0);
    signal eMTC_frame_structure     : std_logic_array32(15 downto 0);
    signal eMTC_cplength            : std_logic_array64(15 downto 0);
    signal eMTC_freq_offset         : std_logic_array96(15 downto 0);
    signal eMTC_start_prbc          : std_logic_array40(15 downto 0);
    signal eMTC_num_prbc            : std_logic_array32(15 downto 0);
    signal eMTC_num_psymbol         : std_logic_array16(15 downto 0);
    signal eMTC_num_ro              : std_logic_array12(15 downto 0);
    signal nb_freq_offset           : std_logic_vector(24*3*4-1 downto 0);
    signal nb_start_prbc            : std_logic_vector(10*3*4-1 downto 0);

    component DATA_MANAGER_UL0 is
    generic (
        MAX_SECTION_PUxCH           : natural := 256;
        MAX_SECTION_PRACH           : natural := 16;
        MAX_SECTION_eMTC            : natural := 16;
        MAX_SECTION_NBIOT0          : natural := 8;
        MAX_SECTION_NBIOT1          : natural := 8;
        MAX_SECTION_NBIOT2          : natural := 8;
        LONG_PRACH                  : boolean := true
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        IGNORE_FRAME_ID             : in  std_logic;
        IGNORE_FRAME_ID_PUxCH_RX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT2_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT2_TX   : out std_logic_vector(7 downto 0);

        UL_PUxCH_EN                 : in  std_logic_vector(7 downto 0);
        UL_PUxCH_ID                 : in  std_logic_array16(7 downto 0);
        UL_PRACH_EN                 : in  std_logic_vector(7 downto 0);
        UL_PRACH_ID                 : in  std_logic_array16(7 downto 0);
        UL_NPUSCH_EN                : in  std_logic_vector(7 downto 0);
        UL_NPUSCH_ID                : in  std_logic_array16(7 downto 0);

        UL_COMP_MODE                : in  std_logic;
        UL_IQ_WIDTH                 : in  std_logic_vector(3 downto 0);
        UL_COMP_METHOD              : in  std_logic_vector(3 downto 0);
        UL_SCS_CONFIG               : in  std_logic_vector(3 downto 0);
        UL_FFT_SIZE                 : in  std_logic_vector(3 downto 0);
        UL_PRB_PER_MTU              : in  std_logic_vector(9 downto 0);
        UL_PRB_PER_SYMBOL           : in  std_logic_vector(9 downto 0);

        CNT_FIFO_FULL               : out std_logic_vector(31 downto 0);

        CNT_PUxCH_TERMINATION       : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL0   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL1   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL2   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL3   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL4   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL5   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL6   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL7   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL8   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL9   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL10  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL11  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL12  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL13  : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL0      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL1      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL2      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL3      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL4      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL5      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL6      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL7      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL8      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL9      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL10     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL11     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL12     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL13     : out std_logic_vector(31 downto 0);

        CNT_PRACH_TERMINATION       : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL0   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL1   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL2   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL3   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL4   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL5   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL6   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL7   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL8   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL9   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL10  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL11  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL12  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL13  : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL0      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL1      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL2      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL3      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL4      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL5      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL6      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL7      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL8      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL9      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL10     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL11     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL12     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL13     : out std_logic_vector(31 downto 0);

        CNT_eMTC_TERMINATION        : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL0      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL1      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL2      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL3      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL4      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL5      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL6      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL7      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL8      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL9      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL10     : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL11     : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL12     : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL13     : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL0      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL1      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL2      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL3      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL4      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL5      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL6      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL7      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL8      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL9      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL10     : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL11     : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL12     : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL13     : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL13   : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL0       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL1       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL2       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL3       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL4       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL5       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL6       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL7       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL8       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL9       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL10      : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL11      : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL12      : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL13      : out std_logic_vector(31 downto 0);

        CNT_NBIOT0_TERMINATION      : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL13   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL13   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL0  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL1  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL2  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL3  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL4  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL5  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL6  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL7  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL8  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL9  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL10 : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL11 : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL12 : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL13 : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL0     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL1     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL2     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL3     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL4     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL5     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL6     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL7     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL8     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL9     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL10    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL11    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL12    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL13    : out std_logic_vector(31 downto 0);

        CNT_NBIOT1_TERMINATION      : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL13   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL13   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL0  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL1  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL2  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL3  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL4  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL5  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL6  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL7  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL8  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL9  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL10 : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL11 : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL12 : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL13 : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL0     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL1     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL2     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL3     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL4     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL5     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL6     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL7     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL8     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL9     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL10    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL11    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL12    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL13    : out std_logic_vector(31 downto 0);

        CNT_NBIOT2_TERMINATION      : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL13   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL13   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL0  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL1  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL2  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL3  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL4  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL5  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL6  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL7  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL8  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL9  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL10 : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL11 : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL12 : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL13 : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL0     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL1     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL2     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL3     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL4     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL5     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL6     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL7     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL8     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL9     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL10    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL11    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL12    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL13    : out std_logic_vector(31 downto 0);

        C_PLANE_VALID               : in  std_logic;
        C_PLANE_LAST                : in  std_logic;
        C_PLANE_KEEP                : in  std_logic_vector(3 downto 0);
        C_PLANE_DATA                : in  std_logic_vector(31 downto 0);
        C_PLANE_CH                  : in  std_logic_vector(2 downto 0);
        C_PLANE_CH_SUB              : in  std_logic_vector(3 downto 0);

        FREQ_OFFSET_FOR_PRACH_0     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_1     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_2     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_3     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_4     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_5     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_6     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_7     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_0      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_1      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_2      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_3      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_4      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_5      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_6      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_7      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_0    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_1    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_2    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_3    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_4    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_5    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_6    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_7    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_0   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_1   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_2   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_3   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_4   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_5   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_6   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_7   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_0   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_1   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_2   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_3   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_4   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_5   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_6   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_7   : in  std_logic_vector(23 downto 0);

        ULFE_FRAME_ID               : in  std_logic_vector(7 downto 0);
        ULFE_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        ULFE_SLOT_ID                : in  std_logic_vector(5 downto 0);
        ULFE_SYMBOL_ID              : in  std_logic_vector(5 downto 0);
        ULFE_START_RE               : in  std_logic_vector(15 downto 0);

        ULFE_VALID                  : in  std_logic_vector(7 downto 0);
        ULFE_START                  : in  std_logic_vector(7 downto 0);
        ULFE_LAST                   : in  std_logic_vector(7 downto 0);
        ULFE_DATA_I                 : in  std_logic_array16(7 downto 0);
        ULFE_DATA_Q                 : in  std_logic_array16(7 downto 0);

        RAFE_FRAME_ID               : in  std_logic_vector(7 downto 0);
        RAFE_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        RAFE_SLOT_ID                : in  std_logic_vector(5 downto 0);
        RAFE_SYMBOL_ID              : in  std_logic_vector(5 downto 0);
        RAFE_START_RE               : in  std_logic_vector(15 downto 0);

        RAFE_VALID                  : in  std_logic_vector(7 downto 0);
        RAFE_START                  : in  std_logic_vector(7 downto 0);
        RAFE_LAST                   : in  std_logic_vector(7 downto 0);
        RAFE_DATA_I                 : in  std_logic_array16(7 downto 0);
        RAFE_DATA_Q                 : in  std_logic_array16(7 downto 0);

        eMTC_FRAME_ID               : in  std_logic_vector(7 downto 0);
        eMTC_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        eMTC_SLOT_ID                : in  std_logic_vector(5 downto 0);
        eMTC_SYMBOL_ID              : in  std_logic_vector(5 downto 0);
        eMTC_START_RE               : in  std_logic_vector(15 downto 0);

        eMTC_VALID                  : in  std_logic_vector(7 downto 0);
        eMTC_START                  : in  std_logic_vector(7 downto 0);
        eMTC_LAST                   : in  std_logic_vector(7 downto 0);
        eMTC_DATA_I                 : in  std_logic_array16(7 downto 0);
        eMTC_DATA_Q                 : in  std_logic_array16(7 downto 0);

        NBFE0_FRAME_ID              : in  std_logic_vector(7 downto 0);
        NBFE0_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        NBFE0_SLOT_ID               : in  std_logic_vector(5 downto 0);
        NBFE0_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        NBFE0_START_RE              : in  std_logic_vector(15 downto 0);

        NBFE0_VALID                 : in  std_logic_vector(7 downto 0);
        NBFE0_START                 : in  std_logic_vector(7 downto 0);
        NBFE0_LAST                  : in  std_logic_vector(7 downto 0);
        NBFE0_DATA_I                : in  std_logic_array16(7 downto 0);
        NBFE0_DATA_Q                : in  std_logic_array16(7 downto 0);

        NBFE1_FRAME_ID              : in  std_logic_vector(7 downto 0);
        NBFE1_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        NBFE1_SLOT_ID               : in  std_logic_vector(5 downto 0);
        NBFE1_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        NBFE1_START_RE              : in  std_logic_vector(15 downto 0);

        NBFE1_VALID                 : in  std_logic_vector(7 downto 0);
        NBFE1_START                 : in  std_logic_vector(7 downto 0);
        NBFE1_LAST                  : in  std_logic_vector(7 downto 0);
        NBFE1_DATA_I                : in  std_logic_array16(7 downto 0);
        NBFE1_DATA_Q                : in  std_logic_array16(7 downto 0);

        NBFE2_FRAME_ID              : in  std_logic_vector(7 downto 0);
        NBFE2_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        NBFE2_SLOT_ID               : in  std_logic_vector(5 downto 0);
        NBFE2_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        NBFE2_START_RE              : in  std_logic_vector(15 downto 0);

        NBFE2_VALID                 : in  std_logic_vector(7 downto 0);
        NBFE2_START                 : in  std_logic_vector(7 downto 0);
        NBFE2_LAST                  : in  std_logic_vector(7 downto 0);
        NBFE2_DATA_I                : in  std_logic_array16(7 downto 0);
        NBFE2_DATA_Q                : in  std_logic_array16(7 downto 0);

        PUxCH_RB_INIT               : out std_logic;
        PUxCH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PUxCH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PUxCH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_APP_ACK     : in  std_logic;
        PUxCH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_SEC_ACK     : in  std_logic;

        PUxCH_RB_COMP_HDR           : out std_logic_vector(7 downto 0);

        PUxCH_RB_VALID              : out std_logic;
        PUxCH_RB_TICK               : out std_logic;
        PUxCH_RB_DATA_I             : out std_logic_vector(15 downto 0);
        PUxCH_RB_DATA_Q             : out std_logic_vector(15 downto 0);
        PUxCH_RB_USER               : out std_logic_vector(15 downto 0);

        PRACH_RB_INIT               : out std_logic;
        PRACH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PRACH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PRACH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_APP_ACK     : in  std_logic;
        PRACH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_SEC_ACK     : in  std_logic;

        PRACH_RB_COMP_HDR           : out std_logic_vector(7 downto 0);

        PRACH_RB_VALID              : out std_logic;
        PRACH_RB_TICK               : out std_logic;
        PRACH_RB_DATA_I             : out std_logic_vector(15 downto 0);
        PRACH_RB_DATA_Q             : out std_logic_vector(15 downto 0);
        PRACH_RB_USER               : out std_logic_vector(15 downto 0);

        eMTC_RB_INIT                : out std_logic;
        eMTC_RB_eAxC_ID             : out std_logic_vector(15 downto 0);
        eMTC_RB_SEQUENCE_ID         : out std_logic_vector(15 downto 0);
        eMTC_RB_HEADER_APP          : out std_logic_vector(31 downto 0);
        eMTC_RB_HEADER_APP_ACK      : in  std_logic;
        eMTC_RB_HEADER_SEC          : out std_logic_vector(31 downto 0);
        eMTC_RB_HEADER_SEC_ACK      : in  std_logic;

        eMTC_RB_COMP_HDR            : out std_logic_vector(7 downto 0);

        eMTC_RB_VALID               : out std_logic;
        eMTC_RB_TICK                : out std_logic;
        eMTC_RB_DATA_I              : out std_logic_vector(15 downto 0);
        eMTC_RB_DATA_Q              : out std_logic_vector(15 downto 0);
        eMTC_RB_USER                : out std_logic_vector(15 downto 0);

        NBIOT0_RB_INIT              : out std_logic;
        NBIOT0_RB_eAxC_ID           : out std_logic_vector(15 downto 0);
        NBIOT0_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);
        NBIOT0_RB_HEADER_APP        : out std_logic_vector(31 downto 0);
        NBIOT0_RB_HEADER_APP_ACK    : in  std_logic;
        NBIOT0_RB_HEADER_SEC        : out std_logic_vector(31 downto 0);
        NBIOT0_RB_HEADER_SEC_ACK    : in  std_logic;

        NBIOT0_RB_COMP_HDR          : out std_logic_vector(7 downto 0);

        NBIOT0_RB_VALID             : out std_logic;
        NBIOT0_RB_TICK              : out std_logic;
        NBIOT0_RB_DATA_I            : out std_logic_vector(15 downto 0);
        NBIOT0_RB_DATA_Q            : out std_logic_vector(15 downto 0);
        NBIOT0_RB_USER              : out std_logic_vector(15 downto 0);

        NBIOT1_RB_INIT              : out std_logic;
        NBIOT1_RB_eAxC_ID           : out std_logic_vector(15 downto 0);
        NBIOT1_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);
        NBIOT1_RB_HEADER_APP        : out std_logic_vector(31 downto 0);
        NBIOT1_RB_HEADER_APP_ACK    : in  std_logic;
        NBIOT1_RB_HEADER_SEC        : out std_logic_vector(31 downto 0);
        NBIOT1_RB_HEADER_SEC_ACK    : in  std_logic;

        NBIOT1_RB_COMP_HDR          : out std_logic_vector(7 downto 0);

        NBIOT1_RB_VALID             : out std_logic;
        NBIOT1_RB_TICK              : out std_logic;
        NBIOT1_RB_DATA_I            : out std_logic_vector(15 downto 0);
        NBIOT1_RB_DATA_Q            : out std_logic_vector(15 downto 0);
        NBIOT1_RB_USER              : out std_logic_vector(15 downto 0);

        NBIOT2_RB_INIT              : out std_logic;
        NBIOT2_RB_eAxC_ID           : out std_logic_vector(15 downto 0);
        NBIOT2_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);
        NBIOT2_RB_HEADER_APP        : out std_logic_vector(31 downto 0);
        NBIOT2_RB_HEADER_APP_ACK    : in  std_logic;
        NBIOT2_RB_HEADER_SEC        : out std_logic_vector(31 downto 0);
        NBIOT2_RB_HEADER_SEC_ACK    : in  std_logic;

        NBIOT2_RB_COMP_HDR          : out std_logic_vector(7 downto 0);

        NBIOT2_RB_VALID             : out std_logic;
        NBIOT2_RB_TICK              : out std_logic;
        NBIOT2_RB_DATA_I            : out std_logic_vector(15 downto 0);
        NBIOT2_RB_DATA_Q            : out std_logic_vector(15 downto 0);
        NBIOT2_RB_USER              : out std_logic_vector(15 downto 0)
    );
    end component;

    signal puxch_rb_init            : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal puxch_rb_eaxc_id         : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal puxch_rb_sequence_id     : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal puxch_rb_header_app      : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal puxch_rb_header_app_ack  : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal puxch_rb_header_sec      : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal puxch_rb_header_sec_ack  : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal puxch_rb_comp_hdr        : std_logic_array8(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal puxch_rb_valid           : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal puxch_rb_tick            : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal puxch_rb_data_i          : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal puxch_rb_data_q          : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal puxch_rb_user            : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_init            : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal prach_rb_eaxc_id         : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_sequence_id     : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_header_app      : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_header_app_ack  : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal prach_rb_header_sec      : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_header_sec_ack  : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal prach_rb_comp_hdr        : std_logic_array8(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_valid           : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal prach_rb_tick            : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal prach_rb_data_i          : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_data_q          : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_user            : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal emtc_rb_init             : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal emtc_rb_eaxc_id          : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal emtc_rb_sequence_id      : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal emtc_rb_header_app       : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal emtc_rb_header_app_ack   : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal emtc_rb_header_sec       : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal emtc_rb_header_sec_ack   : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal emtc_rb_comp_hdr         : std_logic_array8(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal emtc_rb_valid            : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal emtc_rb_tick             : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal emtc_rb_data_i           : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal emtc_rb_data_q           : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal emtc_rb_user             : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot0_rb_init           : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal nbiot0_rb_eaxc_id        : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot0_rb_sequence_id    : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot0_rb_header_app     : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot0_rb_header_app_ack : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal nbiot0_rb_header_sec     : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot0_rb_header_sec_ack : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal nbiot0_rb_comp_hdr       : std_logic_array8(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot0_rb_valid          : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal nbiot0_rb_tick           : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal nbiot0_rb_data_i         : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot0_rb_data_q         : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot0_rb_user           : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot1_rb_init           : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal nbiot1_rb_eaxc_id        : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot1_rb_sequence_id    : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot1_rb_header_app     : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot1_rb_header_app_ack : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal nbiot1_rb_header_sec     : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot1_rb_header_sec_ack : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal nbiot1_rb_comp_hdr       : std_logic_array8(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot1_rb_valid          : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal nbiot1_rb_tick           : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal nbiot1_rb_data_i         : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot1_rb_data_q         : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot1_rb_user           : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot2_rb_init           : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal nbiot2_rb_eaxc_id        : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot2_rb_sequence_id    : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot2_rb_header_app     : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot2_rb_header_app_ack : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal nbiot2_rb_header_sec     : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot2_rb_header_sec_ack : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal nbiot2_rb_comp_hdr       : std_logic_array8(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot2_rb_valid          : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal nbiot2_rb_tick           : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal nbiot2_rb_data_i         : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot2_rb_data_q         : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal nbiot2_rb_user           : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));

    component O_RAN_FRAMER is
    generic (
        USAGE_C_PLANE               : boolean := true;
        USAGE_U_PLANE               : boolean := true
    );
    port (
        RST                         : in  std_logic;

        CLK_MAC                     : in  std_logic;
        CLK_BUS                     : in  std_logic;

        TX_PARAM_DST_MAC            : in  std_logic_vector(47 downto 0);
        TX_PARAM_SRC_MAC            : in  std_logic_vector(47 downto 0);
        TX_PARAM_VLAN0_MODE         : in  std_logic;
        TX_PARAM_VLAN0_TCI          : in  std_logic_vector(15 downto 0);
        TX_PARAM_VLAN1_MODE         : in  std_logic;
        TX_PARAM_VLAN1_TCI          : in  std_logic_vector(15 downto 0);

        TX_COMP_MODE                : in  std_logic;
        TX_COMP_EXP_OFFSET          : in  std_logic_vector(4 downto 0);
        TX_COMP_GAIN_OFFSET         : in  std_logic_vector(10 downto 0);
        TX_COMP_SCALE_GAIN_OFFSET   : in  std_logic_vector(3 downto 0);

        USAGE_TX_DATA_BUFFER        : out std_logic_vector(31 downto 0);
        USAGE_TX_C_PLANE_BUFFER     : out std_logic_vector(31 downto 0);
        USAGE_TX_U_PLANE_BUFFER     : out std_logic_vector(31 downto 0);

        TX_C_PLANE                  : out std_logic_vector(31 downto 0);
        TX_C_PLANE_LOST             : out std_logic_vector(31 downto 0);
        TX_U_PLANE                  : out std_logic_vector(31 downto 0);
        TX_U_PLANE_LOST             : out std_logic_vector(31 downto 0);

        MAC_TX_READY                : in  std_logic;
        MAC_TX_VALID                : out std_logic;
        MAC_TX_LAST                 : out std_logic;
        MAC_TX_KEEP                 : out std_logic_vector(7 downto 0);
        MAC_TX_DATA                 : out std_logic_vector(63 downto 0);

        RB_INIT                     : in  std_logic;
        RB_eAxC_ID                  : in  std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              : in  std_logic_vector(15 downto 0);
        RB_HEADER_APP               : in  std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           : out std_logic;
        RB_HEADER_SEC               : in  std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           : out std_logic;

        RB_COMP_HDR                 : in  std_logic_vector(7 downto 0);

        RB_VALID                    : in  std_logic;
        RB_START                    : in  std_logic;
        RB_TICK                     : in  std_logic;
        RB_LAST                     : in  std_logic;
        RB_DATA_I                   : in  std_logic_vector(15 downto 0);
        RB_DATA_Q                   : in  std_logic_vector(15 downto 0);
        RB_USER                     : in  std_logic_vector(15 downto 0)
    );
    end component;

    signal framer_tx_ready          : std_logic_vector(5 downto 0);
    signal framer_tx_valid          : std_logic_vector(5 downto 0);
    signal framer_tx_last           : std_logic_vector(5 downto 0);
    signal framer_tx_keep           : std_logic_array8(5 downto 0);
    signal framer_tx_data           : std_logic_array64(5 downto 0);

    component O_RAN_FRAMER_INTERCONNECT is
    generic (
        NUM_PORT                    : natural := 8
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        FRAMER_TX_TREADY            : out std_logic_vector(NUM_PORT-1 downto 0);
        FRAMER_TX_TVALID            : in  std_logic_vector(NUM_PORT-1 downto 0);
        FRAMER_TX_TLAST             : in  std_logic_vector(NUM_PORT-1 downto 0);
        FRAMER_TX_TKEEP             : in  std_logic_array8(NUM_PORT-1 downto 0);
        FRAMER_TX_TDATA             : in  std_logic_array64(NUM_PORT-1 downto 0);

        UL_TREADY                   : in  std_logic;
        UL_TVALID                   : out std_logic;
        UL_TLAST                    : out std_logic;
        UL_TKEEP                    : out std_logic_vector(7 downto 0);
        UL_TDATA                    : out std_logic_vector(63 downto 0)
    );
    end component;

    component MEASUREMENT is
    generic (
        NUM_TX                      : natural := 1
    );
    port (
        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK_245p76MHz               : in  std_logic;

        N_TA_OFFSET                 : in  std_logic_vector(15 downto 0);

        REF_10msec                  : in  std_logic;
        REF_SFN                     : in  std_logic_vector(7 downto 0);

        CAPTURE_PERIOD              : in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MAX_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MAX_UL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_UL_CP_RX            : in  std_logic_vector(21 downto 0);

        DL_CP_RX_CNT_CLEAR          : in  std_logic_vector(3 downto 0);
        DL_CP_RX_ON_TIME            : out std_logic_vector(63 downto 0);
        DL_CP_RX_EARLY              : out std_logic_vector(63 downto 0);
        DL_CP_RX_LATE               : out std_logic_vector(63 downto 0);
        DL_CP_RX_OUT_OF_RANGE       : out std_logic_vector(63 downto 0);

        DL_UP_RX_CNT_CLEAR          : in  std_logic_vector(3 downto 0);
        DL_UP_RX_ON_TIME            : out std_logic_vector(63 downto 0);
        DL_UP_RX_EARLY              : out std_logic_vector(63 downto 0);
        DL_UP_RX_LATE               : out std_logic_vector(63 downto 0);
        DL_UP_RX_OUT_OF_RANGE       : out std_logic_vector(63 downto 0);

        UL_CP_RX_CNT_CLEAR          : in  std_logic_vector(3 downto 0);
        UL_CP_RX_ON_TIME            : out std_logic_vector(63 downto 0);
        UL_CP_RX_EARLY              : out std_logic_vector(63 downto 0);
        UL_CP_RX_LATE               : out std_logic_vector(63 downto 0);
        UL_CP_RX_OUT_OF_RANGE       : out std_logic_vector(63 downto 0);

        UL_UP_TX_CNT_CLEAR          : in  std_logic_vector(7 downto 0);
        UL_UP_TX_TOTAL              : out std_logic_array64(7 downto 0);

        RX_PACKET_CLK               : in  std_logic;

        RX_PACKET_IS_CP_DL          : in  std_logic;
        RX_PACKET_IS_CP_UL          : in  std_logic;
        RX_PACKET_IS_UP_DL          : in  std_logic;
        RX_PACKET_SCS               : in  std_logic_vector(3 downto 0);
        RX_PACKET_FRAME_ID          : in  std_logic_vector(7 downto 0);
        RX_PACKET_SUBFRAME_ID       : in  std_logic_vector(3 downto 0);
        RX_PACKET_SLOT_ID           : in  std_logic_vector(5 downto 0);
        RX_PACKET_SYMBOL_ID         : in  std_logic_vector(5 downto 0);

        TX_PACKET_CLK               : in  std_logic;

        TX_PACKET_EXIST             : in  std_logic_vector(NUM_TX-1 downto 0)
    );
    end component;

    signal ul_up_tx_cnt_clear       : std_logic_array8(DL_UNIT-1 downto 0) := (others => (others => '0'));
    signal ul_up_tx_total           : std_logic_array8_array64(DL_UNIT-1 downto 0);
    signal pe0_transmitted          : std_logic_array6(DL_UNIT-1 downto 0) := (others => (others => '0'));

    component O_RAN_MPI is
    generic (
        OFFSET                      : std_logic_vector(3 downto 0) := x"3";
        DL_UNIT                     : natural := 6;
        UL_UNIT                     : natural := 6;
        MAX_CH_PER_UNIT             : natural := 2;
        MAX_ID_PER_CH               : natural := 1
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        CLK_MAC_RX                  : in  std_logic;
        CLK_MAC_TX                  : in  std_logic;
        CLK_BUS                     : in  std_logic;

        IGNORE_FRAME_ID             : out std_logic_vector(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PUxCH_RX    : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH0_RX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH0_TX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH1_RX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH1_TX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT0_RX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT0_TX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT1_RX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT1_TX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT2_RX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT2_TX   : in  std_logic_array8(UL_UNIT-1 downto 0);

        DL_PARAM_MAC                : out std_logic_array48(DL_UNIT-1 downto 0);
        DL_PARAM_ID0_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID0                : out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID1_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID1                : out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID2_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID2                : out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID3_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID3                : out std_logic_array8_array16(DL_UNIT-1 downto 0);

        DL_COMP_MODE                : out std_logic_vector(DL_UNIT-1 downto 0);
        DL_IQ_WIDTH                 : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_COMP_METHOD              : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_SCS_CONFIG               : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_FFT_SIZE                 : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_PRB_PER_SYMBOL           : out std_logic_array10(DL_UNIT-1 downto 0);
        DL_COMP_EXP_OFFSET          : out std_logic_array5(DL_UNIT-1 downto 0);

        UL_PARAM_DST_MAC            : out std_logic_array48(UL_UNIT-1 downto 0);
        UL_PARAM_SRC_MAC            : out std_logic_array48(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN0_MODE         : out std_logic_vector(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN0_TCI          : out std_logic_array16(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN1_MODE         : out std_logic_vector(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN1_TCI          : out std_logic_array16(UL_UNIT-1 downto 0);

        UL_COMP_MODE                : out std_logic_vector(UL_UNIT-1 downto 0);
        UL_IQ_WIDTH                 : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_COMP_METHOD              : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_SCS_CONFIG               : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_FFT_SIZE                 : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_PRB_PER_MTU              : out std_logic_array10(UL_UNIT-1 downto 0);
        UL_PRB_PER_SYMBOL           : out std_logic_array10(UL_UNIT-1 downto 0);
        UL_COMP_EXP_OFFSET          : out std_logic_array5(UL_UNIT-1 downto 0);
        UL_COMP_GAIN_OFFSET         : out std_logic_array11(UL_UNIT-1 downto 0);
        UL_COMP_SCALE_GAIN_OFFSET   : out std_logic_array4(UL_UNIT-1 downto 0);

        T2A_MAX_CP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        T2A_MIN_CP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        CP_DL_PERIOD                : out std_logic_array8(DL_UNIT-1 downto 0);

        CP_DL_CNT_CLEAR             : out std_logic_array4(DL_UNIT-1 downto 0);
        CP_DL_ON_TIME               : in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_EARLY                 : in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_LATE                  : in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_OUT_OF_RANGE          : in  std_logic_array64(DL_UNIT-1 downto 0);

        T2A_MAX_UP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        T2A_MIN_UP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        UP_DL_PERIOD                : out std_logic_array8(DL_UNIT-1 downto 0);

        UP_DL_CNT_CLEAR             : out std_logic_array4(DL_UNIT-1 downto 0);
        UP_DL_ON_TIME               : in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_EARLY                 : in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_LATE                  : in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_OUT_OF_RANGE          : in  std_logic_array64(DL_UNIT-1 downto 0);

        T2A_MAX_CP_UL               : out std_logic_array22(UL_UNIT-1 downto 0);
        T2A_MIN_CP_UL               : out std_logic_array22(UL_UNIT-1 downto 0);
        CP_UL_PERIOD                : out std_logic_array8(UL_UNIT-1 downto 0);

        CP_UL_CNT_CLEAR             : out std_logic_array4(UL_UNIT-1 downto 0);
        CP_UL_ON_TIME               : in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_EARLY                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_LATE                  : in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_OUT_OF_RANGE          : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP0_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP0_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP0_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP0_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP0_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP1_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP1_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP1_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP1_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP1_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP2_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP2_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP2_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP2_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP2_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP2_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP2_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP2_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP3_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP3_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP3_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP3_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP3_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP3_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP3_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP3_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP4_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP4_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP4_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP4_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP4_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP4_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP4_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP4_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP5_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP5_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP5_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP5_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP5_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP5_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP5_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP5_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

        DL_C_PLANE_BUFFER           : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_BUFFER           : in  std_logic_array32(DL_UNIT-1 downto 0);

        DL_INVALID_DST_MAC          : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ETHERTYPE        : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriVersion     : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriC           : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriMessage     : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_C_PLANE                  : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_C_PLANE_DROPPED          : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE                  : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_DROPPED          : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_LOST                     : in  std_logic_array32(DL_UNIT-1 downto 0);

        DL_C_PLANE_EXIST            : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_EXIST            : in  std_logic_array32(DL_UNIT-1 downto 0);

        RX_FAULT_ID_31_CH0          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH1          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH2          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH3          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH4          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH5          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH6          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH7          : in  std_logic_array4(DL_UNIT-1 downto 0);

--        UL_PUxCH_C_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PUxCH_C_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_PUxCH_C_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PRACH_C_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PRACH_C_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_PRACH_C_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_eMTC_C_PLANE_BUFFER      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_U_PLANE_BUFFER      : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_eMTC_C_PLANE             : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_eMTC_C_PLANE_LOST        : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_U_PLANE             : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_U_PLANE_LOST        : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT0_C_PLANE_BUFFER    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_U_PLANE_BUFFER    : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT0_C_PLANE           : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_NBIOT0_C_PLANE_LOST      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_U_PLANE           : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_U_PLANE_LOST      : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT1_C_PLANE_BUFFER    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_U_PLANE_BUFFER    : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT1_C_PLANE           : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_NBIOT1_C_PLANE_LOST      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_U_PLANE           : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_U_PLANE_LOST      : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT2_C_PLANE_BUFFER    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_U_PLANE_BUFFER    : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT2_C_PLANE           : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_NBIOT2_C_PLANE_LOST      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_U_PLANE           : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_U_PLANE_LOST      : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_CMD_FIFO_FULL            : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_PUxCH_TERMINATION        : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL0    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL1    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL2    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL3    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL4    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL5    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL6    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL7    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL8    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL9    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL10   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL11   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL12   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL13   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL0   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL1   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL2   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL3   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL4   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL5   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL6   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL7   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL8   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL9   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL10  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL11  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL12  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL13  : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_PRACH_TERMINATION        : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL0    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL1    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL2    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL3    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL4    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL5    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL6    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL7    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL8    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL9    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL10   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL11   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL12   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL13   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL0   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL1   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL2   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL3   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL4   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL5   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL6   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL7   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL8   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL9   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL10  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL11  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL12  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL13  : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_eMTC_TERMINATION         : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL0       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL1       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL2       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL3       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL4       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL5       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL6       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL7       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL8       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL9       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL10      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL11      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL12      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL13      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL0       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL1       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL2       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL3       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL4       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL5       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL6       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL7       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL8       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL9       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL10      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL11      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL12      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL13      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL0     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL1     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL2     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL3     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL4     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL5     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL6     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL7     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL8     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL9     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL10    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL11    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL12    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL13    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL0    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL1    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL2    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL3    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL4    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL5    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL6    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL7    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL8    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL9    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL10   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL11   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL12   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL13   : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_NBIOT0_TERMINATION       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL0     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL1     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL2     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL3     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL4     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL5     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL6     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL7     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL8     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL9     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL10    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL11    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL12    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL13    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL0     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL1     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL2     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL3     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL4     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL5     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL6     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL7     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL8     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL9     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL10    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL11    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL12    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL13    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL0   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL1   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL2   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL3   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL4   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL5   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL6   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL7   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL8   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL9   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL10  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL11  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL12  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL13  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL0  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL1  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL2  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL3  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL4  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL5  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL6  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL7  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL8  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL9  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL10 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL11 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL12 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL13 : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_NBIOT1_TERMINATION       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL0     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL1     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL2     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL3     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL4     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL5     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL6     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL7     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL8     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL9     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL10    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL11    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL12    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL13    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL0     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL1     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL2     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL3     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL4     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL5     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL6     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL7     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL8     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL9     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL10    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL11    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL12    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL13    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL0   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL1   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL2   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL3   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL4   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL5   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL6   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL7   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL8   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL9   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL10  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL11  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL12  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL13  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL0  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL1  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL2  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL3  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL4  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL5  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL6  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL7  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL8  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL9  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL10 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL11 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL12 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL13 : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_NBIOT2_TERMINATION       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL0     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL1     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL2     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL3     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL4     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL5     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL6     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL7     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL8     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL9     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL10    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL11    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL12    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL13    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL0     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL1     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL2     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL3     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL4     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL5     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL6     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL7     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL8     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL9     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL10    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL11    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL12    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL13    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL0   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL1   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL2   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL3   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL4   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL5   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL6   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL7   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL8   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL9   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL10  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL11  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL12  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL13  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL0  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL1  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL2  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL3  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL4  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL5  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL6  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL7  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL8  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL9  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL10 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL11 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL12 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL13 : in  std_logic_array32(UL_UNIT-1 downto 0);

        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             : out std_logic
    );
    end component;

    signal ignore_frame_id          : std_logic_vector(UL_UNIT-1 downto 0);
    signal ignore_frame_id_puxch_rx : std_logic_array8(UL_UNIT-1 downto 0);
    signal ignore_frame_id_puxch_tx : std_logic_array8(UL_UNIT-1 downto 0);
    signal ignore_frame_id_prach0_rx: std_logic_array8(UL_UNIT-1 downto 0);
    signal ignore_frame_id_prach0_tx: std_logic_array8(UL_UNIT-1 downto 0);
    signal ignore_frame_id_prach1_rx: std_logic_array8(UL_UNIT-1 downto 0);
    signal ignore_frame_id_prach1_tx: std_logic_array8(UL_UNIT-1 downto 0);
    signal ignore_frame_id_nbiot0_rx: std_logic_array8(UL_UNIT-1 downto 0);
    signal ignore_frame_id_nbiot0_tx: std_logic_array8(UL_UNIT-1 downto 0);
    signal ignore_frame_id_nbiot1_rx: std_logic_array8(UL_UNIT-1 downto 0);
    signal ignore_frame_id_nbiot1_tx: std_logic_array8(UL_UNIT-1 downto 0);
    signal ignore_frame_id_nbiot2_rx: std_logic_array8(UL_UNIT-1 downto 0);
    signal ignore_frame_id_nbiot2_tx: std_logic_array8(UL_UNIT-1 downto 0);
    signal dl_param_mac             : std_logic_array48(DL_UNIT-1 downto 0);
    signal dl_param_id0_en          : std_logic_array8(DL_UNIT-1 downto 0);
    signal dl_param_id0             : std_logic_array8_array16(DL_UNIT-1 downto 0);
    signal dl_param_id1_en          : std_logic_array8(DL_UNIT-1 downto 0);
    signal dl_param_id1             : std_logic_array8_array16(DL_UNIT-1 downto 0);
    signal dl_param_id2_en          : std_logic_array8(DL_UNIT-1 downto 0);
    signal dl_param_id2             : std_logic_array8_array16(DL_UNIT-1 downto 0);
    signal dl_param_id3_en          : std_logic_array8(DL_UNIT-1 downto 0);
    signal dl_param_id3             : std_logic_array8_array16(DL_UNIT-1 downto 0);
    signal dl_comp_mode             : std_logic_vector(DL_UNIT-1 downto 0);
    signal dl_iq_width              : std_logic_array4(DL_UNIT-1 downto 0);
    signal dl_comp_method           : std_logic_array4(DL_UNIT-1 downto 0);
    signal dl_scs_config            : std_logic_array4(DL_UNIT-1 downto 0);
    signal dl_fft_size              : std_logic_array4(DL_UNIT-1 downto 0);
    signal dl_prb_per_symbol        : std_logic_array10(DL_UNIT-1 downto 0);
    signal dl_comp_exp_offset       : std_logic_array5(DL_UNIT-1 downto 0);
    signal ul_param_dst_mac         : std_logic_array48(UL_UNIT-1 downto 0);
    signal ul_param_src_mac         : std_logic_array48(UL_UNIT-1 downto 0);
    signal ul_param_vlan0_mode      : std_logic_vector(UL_UNIT-1 downto 0);
    signal ul_param_vlan0_tci       : std_logic_array16(UL_UNIT-1 downto 0);
    signal ul_param_vlan1_mode      : std_logic_vector(UL_UNIT-1 downto 0);
    signal ul_param_vlan1_tci       : std_logic_array16(UL_UNIT-1 downto 0);
    signal ul_comp_mode             : std_logic_vector(UL_UNIT-1 downto 0);
    signal ul_comp_gain_offset      : std_logic_array11(UL_UNIT-1 downto 0);
    signal ul_comp_scale_gain_offset: std_logic_array4(UL_UNIT-1 downto 0);
    signal ul_comp_exp_offset       : std_logic_array5(UL_UNIT-1 downto 0);
    signal ul_iq_width              : std_logic_array4(UL_UNIT-1 downto 0);
    signal ul_comp_method           : std_logic_array4(UL_UNIT-1 downto 0);
    signal ul_scs_config            : std_logic_array4(UL_UNIT-1 downto 0);
    signal ul_fft_size              : std_logic_array4(UL_UNIT-1 downto 0);
    signal ul_prb_per_mtu           : std_logic_array10(UL_UNIT-1 downto 0);
    signal ul_prb_per_symbol        : std_logic_array10(UL_UNIT-1 downto 0);
    signal t2a_max_cp_dl            : std_logic_array22(DL_UNIT-1 downto 0);
    signal t2a_min_cp_dl            : std_logic_array22(DL_UNIT-1 downto 0);
    signal cp_dl_period             : std_logic_array8(DL_UNIT-1 downto 0);
    signal cp_dl_cnt_clear          : std_logic_array4(DL_UNIT-1 downto 0);
    signal cp_dl_on_time            : std_logic_array64(DL_UNIT-1 downto 0);
    signal cp_dl_early              : std_logic_array64(DL_UNIT-1 downto 0);
    signal cp_dl_late               : std_logic_array64(DL_UNIT-1 downto 0);
--    signal cp_dl_out_of_range       : std_logic_array64(DL_UNIT-1 downto 0);
    signal sum_cp_dl_on_time        : std_logic_array64(DL_UNIT-1 downto 0);
    signal sum_cp_dl_early          : std_logic_array64(DL_UNIT-1 downto 0);
    signal sum_cp_dl_late           : std_logic_array64(DL_UNIT-1 downto 0);
    signal t2a_max_up_dl            : std_logic_array22(DL_UNIT-1 downto 0);
    signal t2a_min_up_dl            : std_logic_array22(DL_UNIT-1 downto 0);
--    signal up_dl_period             : std_logic_array8(DL_UNIT-1 downto 0);
    signal up_dl_cnt_clear          : std_logic_array4(DL_UNIT-1 downto 0);
    signal up_dl_on_time            : std_logic_array64(DL_UNIT-1 downto 0);
    signal up_dl_early              : std_logic_array64(DL_UNIT-1 downto 0);
    signal up_dl_late               : std_logic_array64(DL_UNIT-1 downto 0);
--    signal up_dl_out_of_range       : std_logic_array64(DL_UNIT-1 downto 0);
    signal sum_up_dl_on_time        : std_logic_array64(DL_UNIT-1 downto 0);
    signal sum_up_dl_early          : std_logic_array64(DL_UNIT-1 downto 0);
    signal sum_up_dl_late           : std_logic_array64(DL_UNIT-1 downto 0);
    signal t2a_max_cp_ul            : std_logic_array22(UL_UNIT-1 downto 0);
    signal t2a_min_cp_ul            : std_logic_array22(UL_UNIT-1 downto 0);
--    signal cp_ul_period             : std_logic_array8(UL_UNIT-1 downto 0);
    signal cp_ul_cnt_clear          : std_logic_array4(UL_UNIT-1 downto 0);
    signal cp_ul_on_time            : std_logic_array64(UL_UNIT-1 downto 0);
    signal cp_ul_early              : std_logic_array64(UL_UNIT-1 downto 0);
    signal cp_ul_late               : std_logic_array64(UL_UNIT-1 downto 0);
--    signal cp_ul_out_of_range       : std_logic_array64(UL_UNIT-1 downto 0);
    signal sum_cp_ul_on_time        : std_logic_array64(UL_UNIT-1 downto 0);
    signal sum_cp_ul_early          : std_logic_array64(UL_UNIT-1 downto 0);
    signal sum_cp_ul_late           : std_logic_array64(UL_UNIT-1 downto 0);
--    signal ta3_min_up0_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal ta3_max_up0_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal up0_ul_period            : std_logic_array8(UL_UNIT-1 downto 0);
    signal up0_ul_cnt_clear         : std_logic_array4(UL_UNIT-1 downto 0);
    signal up0_ul_on_time           : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up0_ul_early             : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up0_ul_late              : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up0_ul_out_of_range      : std_logic_array64(UL_UNIT-1 downto 0);
--    signal ta3_min_up1_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal ta3_max_up1_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal up1_ul_period            : std_logic_array8(UL_UNIT-1 downto 0);
    signal up1_ul_cnt_clear         : std_logic_array4(UL_UNIT-1 downto 0);
    signal up1_ul_on_time           : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up1_ul_early             : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up1_ul_late              : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up1_ul_out_of_range      : std_logic_array64(UL_UNIT-1 downto 0);
--    signal ta3_min_up2_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal ta3_max_up2_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal up2_ul_period            : std_logic_array8(UL_UNIT-1 downto 0);
    signal up2_ul_cnt_clear         : std_logic_array4(UL_UNIT-1 downto 0);
    signal up2_ul_on_time           : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up2_ul_early             : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up2_ul_late              : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up2_ul_out_of_range      : std_logic_array64(UL_UNIT-1 downto 0);
--    signal ta3_min_up3_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal ta3_max_up3_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal up3_ul_period            : std_logic_array8(UL_UNIT-1 downto 0);
    signal up3_ul_cnt_clear         : std_logic_array4(UL_UNIT-1 downto 0);
    signal up3_ul_on_time           : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up3_ul_early             : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up3_ul_late              : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up3_ul_out_of_range      : std_logic_array64(UL_UNIT-1 downto 0);
--    signal ta3_min_up4_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal ta3_max_up4_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal up4_ul_period            : std_logic_array8(UL_UNIT-1 downto 0);
    signal up4_ul_cnt_clear         : std_logic_array4(UL_UNIT-1 downto 0);
    signal up4_ul_on_time           : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up4_ul_early             : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up4_ul_late              : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up4_ul_out_of_range      : std_logic_array64(UL_UNIT-1 downto 0);
--    signal ta3_min_up5_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal ta3_max_up5_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal up5_ul_period            : std_logic_array8(UL_UNIT-1 downto 0);
    signal up5_ul_cnt_clear         : std_logic_array4(UL_UNIT-1 downto 0);
    signal up5_ul_on_time           : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up5_ul_early             : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up5_ul_late              : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up5_ul_out_of_range      : std_logic_array64(UL_UNIT-1 downto 0);
    signal dl_data_buffer           : std_logic_array32(DL_UNIT-1 downto 0);
--    signal dl_c_plane_buffer        : std_logic_array32(DL_UNIT-1 downto 0);
--    signal dl_u_plane_buffer        : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_invalid_dst_mac       : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_invalid_ethertype     : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_invalid_ecpriversion  : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_invalid_ecpric        : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_invalid_ecprimessage  : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_c_plane               : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_c_plane_dropped       : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_u_plane               : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_u_plane_dropped       : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_lost                  : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_c_plane_exist         : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_u_plane_exist         : std_logic_array32(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch0       : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch1       : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch2       : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch3       : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch4       : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch5       : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch6       : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch7       : std_logic_array4(DL_UNIT-1 downto 0);
--    signal ul_puxch_c_plane_buffer  : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_puxch_u_plane_buffer  : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_puxch_c_plane         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_puxch_c_plane_lost    : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_puxch_u_plane         : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_puxch_u_plane_lost    : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_prach_c_plane_buffer  : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_prach_u_plane_buffer  : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_prach_c_plane         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_prach_c_plane_lost    : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_prach_u_plane         : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_prach_u_plane_lost    : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_emtc_c_plane_buffer   : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_emtc_u_plane_buffer   : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_emtc_c_plane          : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_emtc_c_plane_lost     : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_emtc_u_plane          : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_emtc_u_plane_lost     : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_nbiot0_c_plane_buffer : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_nbiot0_u_plane_buffer : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_nbiot0_c_plane        : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_nbiot0_c_plane_lost   : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_nbiot0_u_plane        : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_nbiot0_u_plane_lost   : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_nbiot1_c_plane_buffer : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_nbiot1_u_plane_buffer : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_nbiot1_c_plane        : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_nbiot1_c_plane_lost   : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_nbiot1_u_plane        : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_nbiot1_u_plane_lost   : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_nbiot2_c_plane_buffer : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_nbiot2_u_plane_buffer : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_nbiot2_c_plane        : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_nbiot2_c_plane_lost   : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_nbiot2_u_plane        : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_nbiot2_u_plane_lost   : std_logic_array32(UL_UNIT-1 downto 0);

    signal ul_cmd_fifo_full         : std_logic_array32(UL_UNIT-1 downto 0);

    signal puxch_termination        : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol0      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol1      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol2      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol3      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol4      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol5      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol6      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol7      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol8      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol9      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol10     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol11     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol12     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol13     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol0      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol1      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol2      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol3      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol4      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol5      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol6      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol7      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol8      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol9      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol10     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol11     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol12     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol13     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol0    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol1    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol2    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol3    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol4    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol5    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol6    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol7    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol8    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol9    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol10   : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol11   : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol12   : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol13   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol0   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol1   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol2   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol3   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol4   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol5   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol6   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol7   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol8   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol9   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol10  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol11  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol12  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol13  : std_logic_array32(UL_UNIT-1 downto 0);

    signal prach_termination        : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol0      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol1      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol2      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol3      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol4      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol5      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol6      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol7      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol8      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol9      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol10     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol11     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol12     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol13     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol0      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol1      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol2      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol3      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol4      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol5      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol6      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol7      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol8      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol9      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol10     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol11     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol12     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol13     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol0    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol1    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol2    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol3    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol4    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol5    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol6    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol7    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol8    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol9    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol10   : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol11   : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol12   : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol13   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol0   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol1   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol2   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol3   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol4   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol5   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol6   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol7   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol8   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol9   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol10  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol11  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol12  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol13  : std_logic_array32(UL_UNIT-1 downto 0);

    signal emtc_termination         : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cpsec_symbol0       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cpsec_symbol1       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cpsec_symbol2       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cpsec_symbol3       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cpsec_symbol4       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cpsec_symbol5       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cpsec_symbol6       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cpsec_symbol7       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cpsec_symbol8       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cpsec_symbol9       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cpsec_symbol10      : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cpsec_symbol11      : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cpsec_symbol12      : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cpsec_symbol13      : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_uppkt_symbol0       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_uppkt_symbol1       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_uppkt_symbol2       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_uppkt_symbol3       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_uppkt_symbol4       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_uppkt_symbol5       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_uppkt_symbol6       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_uppkt_symbol7       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_uppkt_symbol8       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_uppkt_symbol9       : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_uppkt_symbol10      : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_uppkt_symbol11      : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_uppkt_symbol12      : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_uppkt_symbol13      : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cq_full_symbol0     : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cq_full_symbol1     : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cq_full_symbol2     : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cq_full_symbol3     : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cq_full_symbol4     : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cq_full_symbol5     : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cq_full_symbol6     : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cq_full_symbol7     : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cq_full_symbol8     : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cq_full_symbol9     : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cq_full_symbol10    : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cq_full_symbol11    : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cq_full_symbol12    : std_logic_array32(UL_UNIT-1 downto 0);
    signal emtc_cq_full_symbol13    : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_emtc_cq_symbol0    : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_emtc_cq_symbol1    : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_emtc_cq_symbol2    : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_emtc_cq_symbol3    : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_emtc_cq_symbol4    : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_emtc_cq_symbol5    : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_emtc_cq_symbol6    : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_emtc_cq_symbol7    : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_emtc_cq_symbol8    : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_emtc_cq_symbol9    : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_emtc_cq_symbol10   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_emtc_cq_symbol11   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_emtc_cq_symbol12   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_emtc_cq_symbol13   : std_logic_array32(UL_UNIT-1 downto 0);

    signal nbiot0_termination       : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cpsec_symbol0     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cpsec_symbol1     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cpsec_symbol2     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cpsec_symbol3     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cpsec_symbol4     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cpsec_symbol5     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cpsec_symbol6     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cpsec_symbol7     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cpsec_symbol8     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cpsec_symbol9     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cpsec_symbol10    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cpsec_symbol11    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cpsec_symbol12    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cpsec_symbol13    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_uppkt_symbol0     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_uppkt_symbol1     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_uppkt_symbol2     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_uppkt_symbol3     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_uppkt_symbol4     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_uppkt_symbol5     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_uppkt_symbol6     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_uppkt_symbol7     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_uppkt_symbol8     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_uppkt_symbol9     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_uppkt_symbol10    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_uppkt_symbol11    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_uppkt_symbol12    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_uppkt_symbol13    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cq_full_symbol0   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cq_full_symbol1   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cq_full_symbol2   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cq_full_symbol3   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cq_full_symbol4   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cq_full_symbol5   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cq_full_symbol6   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cq_full_symbol7   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cq_full_symbol8   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cq_full_symbol9   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cq_full_symbol10  : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cq_full_symbol11  : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cq_full_symbol12  : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot0_cq_full_symbol13  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot0_cq_symbol0  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot0_cq_symbol1  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot0_cq_symbol2  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot0_cq_symbol3  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot0_cq_symbol4  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot0_cq_symbol5  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot0_cq_symbol6  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot0_cq_symbol7  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot0_cq_symbol8  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot0_cq_symbol9  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot0_cq_symbol10 : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot0_cq_symbol11 : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot0_cq_symbol12 : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot0_cq_symbol13 : std_logic_array32(UL_UNIT-1 downto 0);

    signal nbiot1_termination       : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cpsec_symbol0     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cpsec_symbol1     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cpsec_symbol2     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cpsec_symbol3     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cpsec_symbol4     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cpsec_symbol5     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cpsec_symbol6     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cpsec_symbol7     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cpsec_symbol8     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cpsec_symbol9     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cpsec_symbol10    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cpsec_symbol11    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cpsec_symbol12    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cpsec_symbol13    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_uppkt_symbol0     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_uppkt_symbol1     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_uppkt_symbol2     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_uppkt_symbol3     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_uppkt_symbol4     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_uppkt_symbol5     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_uppkt_symbol6     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_uppkt_symbol7     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_uppkt_symbol8     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_uppkt_symbol9     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_uppkt_symbol10    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_uppkt_symbol11    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_uppkt_symbol12    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_uppkt_symbol13    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cq_full_symbol0   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cq_full_symbol1   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cq_full_symbol2   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cq_full_symbol3   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cq_full_symbol4   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cq_full_symbol5   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cq_full_symbol6   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cq_full_symbol7   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cq_full_symbol8   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cq_full_symbol9   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cq_full_symbol10  : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cq_full_symbol11  : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cq_full_symbol12  : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot1_cq_full_symbol13  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot1_cq_symbol0  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot1_cq_symbol1  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot1_cq_symbol2  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot1_cq_symbol3  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot1_cq_symbol4  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot1_cq_symbol5  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot1_cq_symbol6  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot1_cq_symbol7  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot1_cq_symbol8  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot1_cq_symbol9  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot1_cq_symbol10 : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot1_cq_symbol11 : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot1_cq_symbol12 : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot1_cq_symbol13 : std_logic_array32(UL_UNIT-1 downto 0);

    signal nbiot2_termination       : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cpsec_symbol0     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cpsec_symbol1     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cpsec_symbol2     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cpsec_symbol3     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cpsec_symbol4     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cpsec_symbol5     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cpsec_symbol6     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cpsec_symbol7     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cpsec_symbol8     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cpsec_symbol9     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cpsec_symbol10    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cpsec_symbol11    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cpsec_symbol12    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cpsec_symbol13    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_uppkt_symbol0     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_uppkt_symbol1     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_uppkt_symbol2     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_uppkt_symbol3     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_uppkt_symbol4     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_uppkt_symbol5     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_uppkt_symbol6     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_uppkt_symbol7     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_uppkt_symbol8     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_uppkt_symbol9     : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_uppkt_symbol10    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_uppkt_symbol11    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_uppkt_symbol12    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_uppkt_symbol13    : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cq_full_symbol0   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cq_full_symbol1   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cq_full_symbol2   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cq_full_symbol3   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cq_full_symbol4   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cq_full_symbol5   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cq_full_symbol6   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cq_full_symbol7   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cq_full_symbol8   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cq_full_symbol9   : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cq_full_symbol10  : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cq_full_symbol11  : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cq_full_symbol12  : std_logic_array32(UL_UNIT-1 downto 0);
    signal nbiot2_cq_full_symbol13  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot2_cq_symbol0  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot2_cq_symbol1  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot2_cq_symbol2  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot2_cq_symbol3  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot2_cq_symbol4  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot2_cq_symbol5  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot2_cq_symbol6  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot2_cq_symbol7  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot2_cq_symbol8  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot2_cq_symbol9  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot2_cq_symbol10 : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot2_cq_symbol11 : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot2_cq_symbol12 : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_nbiot2_cq_symbol13 : std_logic_array32(UL_UNIT-1 downto 0);

    -- conversion signal 2 control <-> 1 unit
--    signal split_dl_param_id2_en    : std_logic_array8(UL_UNIT-1 downto 0) := (others => (others => '0'));
--    signal split_dl_param_id2       : std_logic_array8_array16(UL_UNIT-1 downto 0) := (others => (others => (others => '0')));
--    signal split_dl_param_id3_en    : std_logic_array8(UL_UNIT-1 downto 0) := (others => (others => '0'));
--    signal split_dl_param_id3       : std_logic_array8_array16(UL_UNIT-1 downto 0) := (others => (others => (others => '0')));
--    signal split_dl_param_id4_en    : std_logic_array8(UL_UNIT-1 downto 0) := (others => (others => '0'));
--    signal split_dl_param_id4       : std_logic_array8_array16(UL_UNIT-1 downto 0) := (others => (others => (others => '0')));

begin

--------------------------------------------------------------------------------
-- Port mapping (CU_PE_TOP <-> LPHY, DL 4-antenna, 2CC)
--------------------------------------------------------------------------------

    dlfe_system_mode_dss(1) <= DLFE_CC_SYSTEM_MODE(1);
    dlfe_system_mode_dss(0) <= DLFE_CC_SYSTEM_MODE(0);

    DLFE_CC_BFN_NUM_OUT(12*2-1 downto 12*1) <= dlfe_bfn_num_out(0);
    DLFE_CC_BFN_NUM_OUT(12*1-1 downto 12*0) <= dlfe_bfn_num_out(0);

    DLFE_CC_FRAME_SYNC(1)  <= dlfe_frame_sync(0);
    DLFE_CC_FRAME_SYNC(0)  <= dlfe_frame_sync(0);

    DLFE_CC_FRAME_INDEX(8*2-1 downto 8*1) <= dlfe_frame_index(0);
    DLFE_CC_FRAME_INDEX(8*1-1 downto 8*0) <= dlfe_frame_index(0);

    DLFE_CC_FRAME_STRUCTURE(8*2-1 downto 8*1) <= dlfe_frame_structure(0);
    DLFE_CC_FRAME_STRUCTURE(8*1-1 downto 8*0) <= dlfe_frame_structure(0);

    DLFE_CC_SYSTEM_MODE_DSS(1*4*2-1 downto 1*4*1) <= dlfe_system_mode_dss(1) & dlfe_system_mode_dss(1) & dlfe_system_mode_dss(1) & dlfe_system_mode_dss(1);
    DLFE_CC_SYSTEM_MODE_DSS(1*4*1-1 downto 1*4*0) <= dlfe_system_mode_dss(0) & dlfe_system_mode_dss(0) & dlfe_system_mode_dss(0) & dlfe_system_mode_dss(0);

    RAFE_CC_FRAME_SYNC(0) <= rafe_frame_sync(0);
    RAFE_CC_FILTER_INDEX(4*4*1-1 downto 4*4*0)    <= rafe_filter_index(0)(4*1+3 downto 4*1+0) & rafe_filter_index(0)(4*1+3 downto 4*1+0) & rafe_filter_index(0)(3 downto 0) & rafe_filter_index(0)(3 downto 0);
    RAFE_CC_TIME_OFFSET(16*4*1-1 downto 16*4*0)   <= rafe_time_offset(0)(16*1+15 downto 16*1+0) & rafe_time_offset(0)(16*1+15 downto 16*1+0) & rafe_time_offset(0)(15 downto 0) & rafe_time_offset(0)(15 downto 0);
    RAFE_CC_FRAME_STRUCTURE(8*4*1-1 downto 8*4*0) <= rafe_frame_structure(0)(8*1+7 downto 8*1+0) & rafe_frame_structure(0)(8*1+7 downto 8*1+0) & rafe_frame_structure(0)(7 downto 0) & rafe_frame_structure(0)(7 downto 0);
    RAFE_CC_CPLENGTH(16*4*1-1 downto 16*4*0)      <= rafe_cplength(0)(16*1+15 downto 16*1+0) & rafe_cplength(0)(16*1+15 downto 16*1+0) & rafe_cplength(0)(15 downto 0) & rafe_cplength(0)(15 downto 0);
    RAFE_CC_FREQ_OFFSET(24*4*1-1 downto 24*4*0)   <= rafe_freq_offset(0)(24*1+23 downto 24*1+0) & rafe_freq_offset(0)(24*1+23 downto 24*1+0) & rafe_freq_offset(0)(23 downto 0) & rafe_freq_offset(0)(23 downto 0);
    RAFE_CC_START_PRBC(10*4*1-1 downto 10*4*0)    <= rafe_start_prbc(0)(10*1+9 downto 10*1+0) & rafe_start_prbc(0)(10*1+9 downto 10*1+0) & rafe_start_prbc(0)(9 downto 0) & rafe_start_prbc(0)(9 downto 0);
    RAFE_CC_NUM_PRBC(8*4*1-1 downto 8*4*0)        <= rafe_num_prbc(0)(8*1+7 downto 8*1+0) & rafe_num_prbc(0)(8*1+7 downto 8*1+0) & rafe_num_prbc(0)(7 downto 0) & rafe_num_prbc(0)(7 downto 0);
    RAFE_CC_NUM_PSYMBOL(4*4*1-1 downto 4*4*0)     <= rafe_num_psymbol(0)(4*1+3 downto 4*1+0) & rafe_num_psymbol(0)(4*1+3 downto 4*1+0) & rafe_num_psymbol(0)(3 downto 0) & rafe_num_psymbol(0)(3 downto 0);
    RAFE_CC_NUM_RO(3*4*1-1 downto 3*4*0)          <= rafe_num_ro(0)(3*1+2 downto 3*1+0) & rafe_num_ro(0)(3*1+2 downto 3*1+0) & rafe_num_ro(0)(2 downto 0) & rafe_num_ro(0)(2 downto 0);

--    RAFE_CC_FRAME_SYNC(1) <= rafe_frame_sync(0);
--    RAFE_CC_FILTER_INDEX(4*4*2-1 downto 4*4*1)    <= rafe_filter_index(0)(4*3+3 downto 4*3+0) & rafe_filter_index(0)(4*3+3 downto 4*3+0) & rafe_filter_index(0)(4*2+3 downto 4*2+0) & rafe_filter_index(0)(4*2+3 downto 4*2+0);
--    RAFE_CC_TIME_OFFSET(16*4*2-1 downto 16*4*1)   <= rafe_time_offset(0)(16*3+15 downto 16*3+0) & rafe_time_offset(0)(16*3+15 downto 16*3+0) & rafe_time_offset(0)(16*2+15 downto 16*2+0) & rafe_time_offset(0)(16*2+15 downto 16*2+0);
--    RAFE_CC_FRAME_STRUCTURE(8*4*2-1 downto 8*4*1) <= rafe_frame_structure(0)(8*3+7 downto 8*3+0) & rafe_frame_structure(0)(8*3+7 downto 8*3+0) & rafe_frame_structure(0)(8*2+7 downto 8*2+0) & rafe_frame_structure(0)(8*2+7 downto 8*2+0);
--    RAFE_CC_CPLENGTH(16*4*2-1 downto 16*4*1)      <= rafe_cplength(0)(16*3+15 downto 16*3+0) & rafe_cplength(0)(16*3+15 downto 16*3+0) & rafe_cplength(0)(16*2+15 downto 16*2+0) & rafe_cplength(0)(16*2+15 downto 16*2+0);
--    RAFE_CC_FREQ_OFFSET(24*4*2-1 downto 24*4*1)   <= rafe_freq_offset(0)(24*3+23 downto 24*3+0) & rafe_freq_offset(0)(24*3+23 downto 24*3+0) & rafe_freq_offset(0)(24*2+23 downto 24*2+0) & rafe_freq_offset(0)(24*2+23 downto 24*2+0);
--    RAFE_CC_NUM_PSYMBOL(4*4*2-1 downto 4*4*1)     <= rafe_num_psymbol(0)(4*3+3 downto 4*3+0) & rafe_num_psymbol(0)(4*3+3 downto 4*3+0) & rafe_num_psymbol(0)(4*2+3 downto 4*2+0) & rafe_num_psymbol(0)(4*2+3 downto 4*2+0);
--    RAFE_CC_NUM_PRBC(8*4*2-1 downto 8*4*1)        <= rafe_num_prbc(0)(8*3+7 downto 8*3+0) & rafe_num_prbc(0)(8*3+7 downto 8*3+0) & rafe_num_prbc(0)(8*2+7 downto 8*2+0) & rafe_num_prbc(0)(8*2+7 downto 8*2+0);
--    RAFE_CC_NUM_RO(3*4*2-1 downto 3*4*1)          <= rafe_num_ro(0)(3*3+2 downto 3*3+0) & rafe_num_ro(0)(3*3+2 downto 3*3+0) & rafe_num_ro(0)(3*2+2 downto 3*2+0) & rafe_num_ro(0)(3*2+2 downto 3*2+0);

    eMTC_CC_FILTER_INDEX(4*4*1-1 downto 4*4*0)    <= eMTC_filter_index(0)(4*1+3 downto 4*1+0) & eMTC_filter_index(0)(4*1+3 downto 4*1+0) & eMTC_filter_index(0)(3 downto 0) & eMTC_filter_index(0)(3 downto 0);
    eMTC_CC_TIME_OFFSET(16*4*1-1 downto 16*4*0)   <= eMTC_time_offset(0)(16*1+15 downto 16*1+0) & eMTC_time_offset(0)(16*1+15 downto 16*1+0) & eMTC_time_offset(0)(15 downto 0) & eMTC_time_offset(0)(15 downto 0);
    eMTC_CC_FRAME_STRUCTURE(8*4*1-1 downto 8*4*0) <= eMTC_frame_structure(0)(8*1+7 downto 8*1+0) & eMTC_frame_structure(0)(8*1+7 downto 8*1+0) & eMTC_frame_structure(0)(7 downto 0) & eMTC_frame_structure(0)(7 downto 0);
    eMTC_CC_CPLENGTH(16*4*1-1 downto 16*4*0)      <= eMTC_cplength(0)(16*1+15 downto 16*1+0) & eMTC_cplength(0)(16*1+15 downto 16*1+0) & eMTC_cplength(0)(15 downto 0) & eMTC_cplength(0)(15 downto 0);
    eMTC_CC_FREQ_OFFSET(24*4*1-1 downto 24*4*0)   <= eMTC_freq_offset(0)(24*1+23 downto 24*1+0) & eMTC_freq_offset(0)(24*1+23 downto 24*1+0) & eMTC_freq_offset(0)(23 downto 0) & eMTC_freq_offset(0)(23 downto 0);
    eMTC_CC_START_PRBC(10*4*1-1 downto 10*4*0)    <= eMTC_start_prbc(0)(10*1+9 downto 10*1+0) & eMTC_start_prbc(0)(10*1+9 downto 10*1+0) & eMTC_start_prbc(0)(9 downto 0) & eMTC_start_prbc(0)(9 downto 0);
    eMTC_CC_NUM_PRBC(8*4*1-1 downto 8*4*0)        <= eMTC_num_prbc(0)(8*1+7 downto 8*1+0) & eMTC_num_prbc(0)(8*1+7 downto 8*1+0) & eMTC_num_prbc(0)(7 downto 0) & eMTC_num_prbc(0)(7 downto 0);
    eMTC_CC_NUM_PSYMBOL(4*4*1-1 downto 4*4*0)     <= eMTC_num_psymbol(0)(4*1+3 downto 4*1+0) & eMTC_num_psymbol(0)(4*1+3 downto 4*1+0) & eMTC_num_psymbol(0)(3 downto 0) & eMTC_num_psymbol(0)(3 downto 0);
    eMTC_CC_NUM_RO(3*4*1-1 downto 3*4*0)          <= eMTC_num_ro(0)(3*1+2 downto 3*1+0) & eMTC_num_ro(0)(3*1+2 downto 3*1+0) & eMTC_num_ro(0)(2 downto 0) & eMTC_num_ro(0)(2 downto 0);

    NBIOT_CC_FREQ_OFFSET   <= nb_freq_offset;
    NBIOT_CC_START_PRBC    <= nb_start_prbc;

    eMTC_CC_FRAME_SYNC(0)  <= rafe_frame_sync(0);
    NBIOT_CC_FRAME_SYNC(0) <= rafe_frame_sync(0);
    NBIOT_CC_FRAME_SYNC(1) <= rafe_frame_sync(0);
    NBIOT_CC_FRAME_SYNC(2) <= rafe_frame_sync(0);

    freq_offset_for_prach_0(0)      <= rafe_freq_offset(0)(24*0+23 downto 24*0+0);
    freq_offset_for_prach_1(0)      <= rafe_freq_offset(0)(24*0+23 downto 24*0+0);
    freq_offset_for_prach_2(0)      <= rafe_freq_offset(0)(24*1+23 downto 24*1+0);
    freq_offset_for_prach_3(0)      <= rafe_freq_offset(0)(24*1+23 downto 24*1+0);
    freq_offset_for_prach_4(0)      <= (others => '0');
    freq_offset_for_prach_5(0)      <= (others => '0');
    freq_offset_for_prach_6(0)      <= (others => '0');
    freq_offset_for_prach_7(0)      <= (others => '0');

    freq_offset_for_emtc_0(0)       <= eMTC_freq_offset(0)(24*0+23 downto 24*0+0);
    freq_offset_for_emtc_1(0)       <= eMTC_freq_offset(0)(24*0+23 downto 24*0+0);
    freq_offset_for_emtc_2(0)       <= eMTC_freq_offset(0)(24*1+23 downto 24*1+0);
    freq_offset_for_emtc_3(0)       <= eMTC_freq_offset(0)(24*1+23 downto 24*1+0);
    freq_offset_for_emtc_4(0)       <= (others => '0');
    freq_offset_for_emtc_5(0)       <= (others => '0');
    freq_offset_for_emtc_6(0)       <= (others => '0');
    freq_offset_for_emtc_7(0)       <= (others => '0');

    freq_offset_for_nprach_0(0)     <= nb_freq_offset(24*(4*2+0)+23 downto 24*(4*2+0)+0);
    freq_offset_for_nprach_1(0)     <= nb_freq_offset(24*(4*2+1)+23 downto 24*(4*2+1)+0);
    freq_offset_for_nprach_2(0)     <= nb_freq_offset(24*(4*2+2)+23 downto 24*(4*2+2)+0);
    freq_offset_for_nprach_3(0)     <= nb_freq_offset(24*(4*2+3)+23 downto 24*(4*2+3)+0);
    freq_offset_for_nprach_4(0)     <= (others => '0');
    freq_offset_for_nprach_5(0)     <= (others => '0');
    freq_offset_for_nprach_6(0)     <= (others => '0');
    freq_offset_for_nprach_7(0)     <= (others => '0');

    freq_offset_for_npusch0_0(0)    <= nb_freq_offset(24*(4*0+0)+23 downto 24*(4*0+0)+0);
    freq_offset_for_npusch0_1(0)    <= nb_freq_offset(24*(4*0+1)+23 downto 24*(4*0+1)+0);
    freq_offset_for_npusch0_2(0)    <= nb_freq_offset(24*(4*0+2)+23 downto 24*(4*0+2)+0);
    freq_offset_for_npusch0_3(0)    <= nb_freq_offset(24*(4*0+3)+23 downto 24*(4*0+3)+0);
    freq_offset_for_npusch0_4(0)    <= (others => '0');
    freq_offset_for_npusch0_5(0)    <= (others => '0');
    freq_offset_for_npusch0_6(0)    <= (others => '0');
    freq_offset_for_npusch0_7(0)    <= (others => '0');

    freq_offset_for_npusch1_0(0)    <= nb_freq_offset(24*(4*1+0)+23 downto 24*(4*1+0)+0);
    freq_offset_for_npusch1_1(0)    <= nb_freq_offset(24*(4*1+1)+23 downto 24*(4*1+1)+0);
    freq_offset_for_npusch1_2(0)    <= nb_freq_offset(24*(4*1+2)+23 downto 24*(4*1+2)+0);
    freq_offset_for_npusch1_3(0)    <= nb_freq_offset(24*(4*1+3)+23 downto 24*(4*1+3)+0);
    freq_offset_for_npusch1_4(0)    <= (others => '0');
    freq_offset_for_npusch1_5(0)    <= (others => '0');
    freq_offset_for_npusch1_6(0)    <= (others => '0');
    freq_offset_for_npusch1_7(0)    <= (others => '0');

--------------------------------------------------------------------------------
-- Port mapping (UL_DM <-> LPHY, UL 4-antenna, 2CC)
--------------------------------------------------------------------------------

    -- map from 1-deframer to 2-framer
    ecpri_rx_c_valid_split(0)            <= ecpri_rx_c_valid(0); -- and (not ecpri_rx_c_ch(0)(2));
--    ecpri_rx_c_valid_split(1)            <= ecpri_rx_c_valid(0) and (ecpri_rx_c_ch(0)(2));

    ecpri_rx_c_ch_split(0)               <= '0' & ecpri_rx_c_ch(0)(2 downto 0); --"00" & ecpri_rx_c_ch(0)(1 downto 0);
--    ecpri_rx_c_ch_split(1)               <= "00" & ecpri_rx_c_ch(0)(1 downto 0);

--    split_dl_param_id2_en(0)(3 downto 0) <= dl_param_id2_en(0)(3 downto 0);
--    split_dl_param_id2(0)(3 downto 0)    <= dl_param_id2(0)(3 downto 0);
--    split_dl_param_id3_en(0)(3 downto 0) <= dl_param_id3_en(0)(3 downto 0);
--    split_dl_param_id3(0)(3 downto 0)    <= dl_param_id3(0)(3 downto 0);
--    split_dl_param_id4_en(0)(3 downto 0) <= dl_param_id1_en(0)(3 downto 0);
--    split_dl_param_id4(0)(3 downto 0)    <= dl_param_id1(0)(3 downto 0);

--    split_dl_param_id2(1)(3 downto 0)    <= dl_param_id2(0)(7 downto 4);
--    split_dl_param_id3(1)(3 downto 0)    <= dl_param_id3(0)(7 downto 4);

    ulfe_frame_id(0)        <= ULFE_CC_FRAME_ID(0*8+7 downto 0*8);
    ulfe_subframe_id(0)     <= ULFE_CC_SUBFRAME_ID(0*4+3 downto 0*4);
    ulfe_slot_id(0)         <= ULFE_CC_SLOT_ID(0*6+5 downto 0*6);
    ulfe_symbol_id(0)       <= ULFE_CC_SYMBOL_ID(0*6+5 downto 0*6);
    ulfe_start_re(0)        <= ULFE_CC_START_RE(0*4*16+15 downto 0*4*16);
    ulfe_valid(0)           <= "0000" & ULFE_CC_VALID(0*4+3 downto 0*4);
    ulfe_start(0)           <= "0000" & ULFE_CC_START(0*4+3 downto 0*4);
    ulfe_last(0)            <= "0000" & ULFE_CC_LAST(0*4+3 downto 0*4);
    ulfe_data_i(0)(0)       <= ULFE_CC_DATA(0*32+31 downto 0*32+16);
    ulfe_data_q(0)(0)       <= ULFE_CC_DATA(0*32+15 downto 0*32+0);
    ulfe_data_i(0)(1)       <= ULFE_CC_DATA(1*32+31 downto 1*32+16);
    ulfe_data_q(0)(1)       <= ULFE_CC_DATA(1*32+15 downto 1*32+0);
    ulfe_data_i(0)(2)       <= ULFE_CC_DATA(2*32+31 downto 2*32+16);
    ulfe_data_q(0)(2)       <= ULFE_CC_DATA(2*32+15 downto 2*32+0);
    ulfe_data_i(0)(3)       <= ULFE_CC_DATA(3*32+31 downto 3*32+16);
    ulfe_data_q(0)(3)       <= ULFE_CC_DATA(3*32+15 downto 3*32+0);
    ulfe_data_i(0)(4)       <= (others => '0');
    ulfe_data_q(0)(4)       <= (others => '0');
    ulfe_data_i(0)(5)       <= (others => '0');
    ulfe_data_q(0)(5)       <= (others => '0');
    ulfe_data_i(0)(6)       <= (others => '0');
    ulfe_data_q(0)(6)       <= (others => '0');
    ulfe_data_i(0)(7)       <= (others => '0');
    ulfe_data_q(0)(7)       <= (others => '0');

--    ulfe_frame_id(1)        <= ULFE_CC_FRAME_ID(1*8+7 downto 1*8);
--    ulfe_subframe_id(1)     <= ULFE_CC_SUBFRAME_ID(1*4+3 downto 1*4);
--    ulfe_slot_id(1)         <= ULFE_CC_SLOT_ID(1*6+5 downto 1*6);
--    ulfe_symbol_id(1)       <= ULFE_CC_SYMBOL_ID(1*6+5 downto 1*6);
--    ulfe_start_re(1)        <= ULFE_CC_START_RE(1*4*16+15 downto 1*4*16);
--    ulfe_valid(1)           <= "0000" & ULFE_CC_VALID(1*4+3 downto 1*4);
--    ulfe_start(1)           <= "0000" & ULFE_CC_START(1*4+3 downto 1*4);
--    ulfe_last(1)            <= "0000" & ULFE_CC_LAST(1*4+3 downto 1*4);
--    ulfe_data_i(1)(0)       <= ULFE_CC_DATA(4*32+31 downto 4*32+16);
--    ulfe_data_q(1)(0)       <= ULFE_CC_DATA(4*32+15 downto 4*32+0);
--    ulfe_data_i(1)(1)       <= ULFE_CC_DATA(5*32+31 downto 5*32+16);
--    ulfe_data_q(1)(1)       <= ULFE_CC_DATA(5*32+15 downto 5*32+0);
--    ulfe_data_i(1)(2)       <= ULFE_CC_DATA(6*32+31 downto 6*32+16);
--    ulfe_data_q(1)(2)       <= ULFE_CC_DATA(6*32+15 downto 6*32+0);
--    ulfe_data_i(1)(3)       <= ULFE_CC_DATA(7*32+31 downto 7*32+16);
--    ulfe_data_q(1)(3)       <= ULFE_CC_DATA(7*32+15 downto 7*32+0);
--    ulfe_data_i(1)(4)       <= (others => '0');
--    ulfe_data_q(1)(4)       <= (others => '0');
--    ulfe_data_i(1)(5)       <= (others => '0');
--    ulfe_data_q(1)(5)       <= (others => '0');
--    ulfe_data_i(1)(6)       <= (others => '0');
--    ulfe_data_q(1)(6)       <= (others => '0');
--    ulfe_data_i(1)(7)       <= (others => '0');
--    ulfe_data_q(1)(7)       <= (others => '0');

    rafe_frame_id(0)        <= RAFE_CC_FRAME_ID(0*8+7 downto 0*8);
    rafe_subframe_id(0)     <= RAFE_CC_SUBFRAME_ID(0*4+3 downto 0*4);
    rafe_slot_id(0)         <= RAFE_CC_SLOT_ID(0*6+5 downto 0*6);
    rafe_symbol_id(0)       <= RAFE_CC_SYMBOL_ID(0*6+5 downto 0*6);
    rafe_start_re(0)        <= RAFE_CC_START_RE(0*4*16+15 downto 0*4*16);
    rafe_valid(0)           <= "0000" & RAFE_CC_VALID(0*4+3 downto 0*4);
    rafe_start(0)           <= "0000" & RAFE_CC_START(0*4+3 downto 0*4);
    rafe_last(0)            <= "0000" & RAFE_CC_LAST(0*4+3 downto 0*4);
    rafe_data_i(0)(0)       <= RAFE_CC_DATA(0*32+31 downto 0*32+16);
    rafe_data_q(0)(0)       <= RAFE_CC_DATA(0*32+15 downto 0*32+0);
    rafe_data_i(0)(1)       <= RAFE_CC_DATA(1*32+31 downto 1*32+16);
    rafe_data_q(0)(1)       <= RAFE_CC_DATA(1*32+15 downto 1*32+0);
    rafe_data_i(0)(2)       <= RAFE_CC_DATA(2*32+31 downto 2*32+16);
    rafe_data_q(0)(2)       <= RAFE_CC_DATA(2*32+15 downto 2*32+0);
    rafe_data_i(0)(3)       <= RAFE_CC_DATA(3*32+31 downto 3*32+16);
    rafe_data_q(0)(3)       <= RAFE_CC_DATA(3*32+15 downto 3*32+0);
    rafe_data_i(0)(4)       <= (others => '0');
    rafe_data_q(0)(4)       <= (others => '0');
    rafe_data_i(0)(5)       <= (others => '0');
    rafe_data_q(0)(5)       <= (others => '0');
    rafe_data_i(0)(6)       <= (others => '0');
    rafe_data_q(0)(6)       <= (others => '0');
    rafe_data_i(0)(7)       <= (others => '0');
    rafe_data_q(0)(7)       <= (others => '0');

--    rafe_frame_id(1)        <= RAFE_CC_FRAME_ID(1*8+7 downto 1*8);
--    rafe_subframe_id(1)     <= RAFE_CC_SUBFRAME_ID(1*4+3 downto 1*4);
--    rafe_slot_id(1)         <= RAFE_CC_SLOT_ID(1*6+5 downto 1*6);
--    rafe_symbol_id(1)       <= RAFE_CC_SYMBOL_ID(1*6+5 downto 1*6);
--    rafe_start_re(1)        <= RAFE_CC_START_RE(1*4*16+15 downto 1*4*16);
--    rafe_valid(1)           <= "0000" & RAFE_CC_VALID(1*4+3 downto 1*4);
--    rafe_start(1)           <= "0000" & RAFE_CC_START(1*4+3 downto 1*4);
--    rafe_last(1)            <= "0000" & RAFE_CC_LAST(1*4+3 downto 1*4);
--    rafe_data_i(1)(0)       <= RAFE_CC_DATA(4*32+31 downto 4*32+16);
--    rafe_data_q(1)(0)       <= RAFE_CC_DATA(4*32+15 downto 4*32+0);
--    rafe_data_i(1)(1)       <= RAFE_CC_DATA(5*32+31 downto 5*32+16);
--    rafe_data_q(1)(1)       <= RAFE_CC_DATA(5*32+15 downto 5*32+0);
--    rafe_data_i(1)(2)       <= RAFE_CC_DATA(6*32+31 downto 6*32+16);
--    rafe_data_q(1)(2)       <= RAFE_CC_DATA(6*32+15 downto 6*32+0);
--    rafe_data_i(1)(3)       <= RAFE_CC_DATA(7*32+31 downto 7*32+16);
--    rafe_data_q(1)(3)       <= RAFE_CC_DATA(7*32+15 downto 7*32+0);
--    rafe_data_i(1)(4)       <= (others => '0');
--    rafe_data_q(1)(4)       <= (others => '0');
--    rafe_data_i(1)(5)       <= (others => '0');
--    rafe_data_q(1)(5)       <= (others => '0');
--    rafe_data_i(1)(6)       <= (others => '0');
--    rafe_data_q(1)(6)       <= (others => '0');
--    rafe_data_i(1)(7)       <= (others => '0');
--    rafe_data_q(1)(7)       <= (others => '0');

    emtc_frame_id(0)        <= eMTC_CC_FRAME_ID(0*8+7 downto 0*8);
    emtc_subframe_id(0)     <= eMTC_CC_SUBFRAME_ID(0*4+3 downto 0*4);
    emtc_slot_id(0)         <= eMTC_CC_SLOT_ID(0*6+5 downto 0*6);
    emtc_symbol_id(0)       <= eMTC_CC_SYMBOL_ID(0*6+5 downto 0*6);
    emtc_start_re(0)        <= eMTC_CC_START_RE(0*4*16+15 downto 0*4*16);
    emtc_valid(0)           <= "0000" & eMTC_CC_VALID(0*4+3 downto 0*4);
    emtc_start(0)           <= "0000" & eMTC_CC_START(0*4+3 downto 0*4);
    emtc_last(0)            <= "0000" & eMTC_CC_LAST(0*4+3 downto 0*4);
    emtc_data_i(0)(0)       <= eMTC_CC_DATA(0*32+31 downto 0*32+16);
    emtc_data_q(0)(0)       <= eMTC_CC_DATA(0*32+15 downto 0*32+0);
    emtc_data_i(0)(1)       <= eMTC_CC_DATA(1*32+31 downto 1*32+16);
    emtc_data_q(0)(1)       <= eMTC_CC_DATA(1*32+15 downto 1*32+0);
    emtc_data_i(0)(2)       <= eMTC_CC_DATA(2*32+31 downto 2*32+16);
    emtc_data_q(0)(2)       <= eMTC_CC_DATA(2*32+15 downto 2*32+0);
    emtc_data_i(0)(3)       <= eMTC_CC_DATA(3*32+31 downto 3*32+16);
    emtc_data_q(0)(3)       <= eMTC_CC_DATA(3*32+15 downto 3*32+0);
    emtc_data_i(0)(4)       <= (others => '0');
    emtc_data_q(0)(4)       <= (others => '0');
    emtc_data_i(0)(5)       <= (others => '0');
    emtc_data_q(0)(5)       <= (others => '0');
    emtc_data_i(0)(6)       <= (others => '0');
    emtc_data_q(0)(6)       <= (others => '0');
    emtc_data_i(0)(7)       <= (others => '0');
    emtc_data_q(0)(7)       <= (others => '0');

--    emtc_frame_id(1)        <= (others => '0');
--    emtc_subframe_id(1)     <= (others => '0');
--    emtc_slot_id(1)         <= (others => '0');
--    emtc_symbol_id(1)       <= (others => '0');
--    emtc_start_re(1)        <= (others => '0');
--    emtc_valid(1)           <= (others => '0');
--    emtc_start(1)           <= (others => '0');
--    emtc_last(1)            <= (others => '0');
--    emtc_data_i(1)(0)       <= (others => '0');
--    emtc_data_q(1)(0)       <= (others => '0');
--    emtc_data_i(1)(1)       <= (others => '0');
--    emtc_data_q(1)(1)       <= (others => '0');
--    emtc_data_i(1)(2)       <= (others => '0');
--    emtc_data_q(1)(2)       <= (others => '0');
--    emtc_data_i(1)(3)       <= (others => '0');
--    emtc_data_q(1)(3)       <= (others => '0');
--    emtc_data_i(1)(4)       <= (others => '0');
--    emtc_data_q(1)(4)       <= (others => '0');
--    emtc_data_i(1)(5)       <= (others => '0');
--    emtc_data_q(1)(5)       <= (others => '0');
--    emtc_data_i(1)(6)       <= (others => '0');
--    emtc_data_q(1)(6)       <= (others => '0');
--    emtc_data_i(1)(7)       <= (others => '0');
--    emtc_data_q(1)(7)       <= (others => '0');

    nbiot0_frame_id(0)      <= NBIOT_CC_FRAME_ID(0*8+7 downto 0*8);
    nbiot0_subframe_id(0)   <= NBIOT_CC_SUBFRAME_ID(0*4+3 downto 0*4);
    nbiot0_slot_id(0)       <= NBIOT_CC_SLOT_ID(0*6+5 downto 0*6);
    nbiot0_symbol_id(0)     <= NBIOT_CC_SYMBOL_ID(0*6+5 downto 0*6);
    nbiot0_start_re(0)      <= NBIOT_CC_START_RE(0*4*16+15 downto 0*4*16);
    nbiot0_valid(0)         <= "0000" & NBIOT_CC_VALID(0*4+3 downto 0*4);
    nbiot0_start(0)         <= "0000" & NBIOT_CC_START(0*4+3 downto 0*4);
    nbiot0_last(0)          <= "0000" & NBIOT_CC_LAST(0*4+3 downto 0*4);
    nbiot0_data_i(0)(0)     <= NBIOT_CC_DATA(0*32+31 downto 0*32+16);
    nbiot0_data_q(0)(0)     <= NBIOT_CC_DATA(0*32+15 downto 0*32+0);
    nbiot0_data_i(0)(1)     <= NBIOT_CC_DATA(1*32+31 downto 1*32+16);
    nbiot0_data_q(0)(1)     <= NBIOT_CC_DATA(1*32+15 downto 1*32+0);
    nbiot0_data_i(0)(2)     <= NBIOT_CC_DATA(2*32+31 downto 2*32+16);
    nbiot0_data_q(0)(2)     <= NBIOT_CC_DATA(2*32+15 downto 2*32+0);
    nbiot0_data_i(0)(3)     <= NBIOT_CC_DATA(3*32+31 downto 3*32+16);
    nbiot0_data_q(0)(3)     <= NBIOT_CC_DATA(3*32+15 downto 3*32+0);
    nbiot0_data_i(0)(4)     <= (others => '0');
    nbiot0_data_q(0)(4)     <= (others => '0');
    nbiot0_data_i(0)(5)     <= (others => '0');
    nbiot0_data_q(0)(5)     <= (others => '0');
    nbiot0_data_i(0)(6)     <= (others => '0');
    nbiot0_data_q(0)(6)     <= (others => '0');
    nbiot0_data_i(0)(7)     <= (others => '0');
    nbiot0_data_q(0)(7)     <= (others => '0');

--    nbiot0_frame_id(1)      <= (others => '0');
--    nbiot0_subframe_id(1)   <= (others => '0');
--    nbiot0_slot_id(1)       <= (others => '0');
--    nbiot0_symbol_id(1)     <= (others => '0');
--    nbiot0_start_re(1)      <= (others => '0');
--    nbiot0_valid(1)         <= (others => '0');
--    nbiot0_start(1)         <= (others => '0');
--    nbiot0_last(1)          <= (others => '0');
--    nbiot0_data_i(1)(0)     <= (others => '0');
--    nbiot0_data_q(1)(0)     <= (others => '0');
--    nbiot0_data_i(1)(1)     <= (others => '0');
--    nbiot0_data_q(1)(1)     <= (others => '0');
--    nbiot0_data_i(1)(2)     <= (others => '0');
--    nbiot0_data_q(1)(2)     <= (others => '0');
--    nbiot0_data_i(1)(3)     <= (others => '0');
--    nbiot0_data_q(1)(3)     <= (others => '0');
--    nbiot0_data_i(1)(4)     <= (others => '0');
--    nbiot0_data_q(1)(4)     <= (others => '0');
--    nbiot0_data_i(1)(5)     <= (others => '0');
--    nbiot0_data_q(1)(5)     <= (others => '0');
--    nbiot0_data_i(1)(6)     <= (others => '0');
--    nbiot0_data_q(1)(6)     <= (others => '0');
--    nbiot0_data_i(1)(7)     <= (others => '0');
--    nbiot0_data_q(1)(7)     <= (others => '0');

    nbiot1_frame_id(0)      <= NBIOT_CC_FRAME_ID(1*8+7 downto 1*8);
    nbiot1_subframe_id(0)   <= NBIOT_CC_SUBFRAME_ID(1*4+3 downto 1*4);
    nbiot1_slot_id(0)       <= NBIOT_CC_SLOT_ID(1*6+5 downto 1*6);
    nbiot1_symbol_id(0)     <= NBIOT_CC_SYMBOL_ID(1*6+5 downto 1*6);
    nbiot1_start_re(0)      <= NBIOT_CC_START_RE(1*4*16+15 downto 1*4*16);
    nbiot1_valid(0)         <= "0000" & NBIOT_CC_VALID(1*4+3 downto 1*4);
    nbiot1_start(0)         <= "0000" & NBIOT_CC_START(1*4+3 downto 1*4);
    nbiot1_last(0)          <= "0000" & NBIOT_CC_LAST(1*4+3 downto 1*4);
    nbiot1_data_i(0)(0)     <= NBIOT_CC_DATA(4*32+31 downto 4*32+16);
    nbiot1_data_q(0)(0)     <= NBIOT_CC_DATA(4*32+15 downto 4*32+0);
    nbiot1_data_i(0)(1)     <= NBIOT_CC_DATA(5*32+31 downto 5*32+16);
    nbiot1_data_q(0)(1)     <= NBIOT_CC_DATA(5*32+15 downto 5*32+0);
    nbiot1_data_i(0)(2)     <= NBIOT_CC_DATA(6*32+31 downto 6*32+16);
    nbiot1_data_q(0)(2)     <= NBIOT_CC_DATA(6*32+15 downto 6*32+0);
    nbiot1_data_i(0)(3)     <= NBIOT_CC_DATA(7*32+31 downto 7*32+16);
    nbiot1_data_q(0)(3)     <= NBIOT_CC_DATA(7*32+15 downto 7*32+0);
    nbiot1_data_i(0)(4)     <= (others => '0');
    nbiot1_data_q(0)(4)     <= (others => '0');
    nbiot1_data_i(0)(5)     <= (others => '0');
    nbiot1_data_q(0)(5)     <= (others => '0');
    nbiot1_data_i(0)(6)     <= (others => '0');
    nbiot1_data_q(0)(6)     <= (others => '0');
    nbiot1_data_i(0)(7)     <= (others => '0');
    nbiot1_data_q(0)(7)     <= (others => '0');

--    nbiot1_frame_id(1)      <= (others => '0');
--    nbiot1_subframe_id(1)   <= (others => '0');
--    nbiot1_slot_id(1)       <= (others => '0');
--    nbiot1_symbol_id(1)     <= (others => '0');
--    nbiot1_start_re(1)      <= (others => '0');
--    nbiot1_valid(1)         <= (others => '0');
--    nbiot1_start(1)         <= (others => '0');
--    nbiot1_last(1)          <= (others => '0');
--    nbiot1_data_i(1)(0)     <= (others => '0');
--    nbiot1_data_q(1)(0)     <= (others => '0');
--    nbiot1_data_i(1)(1)     <= (others => '0');
--    nbiot1_data_q(1)(1)     <= (others => '0');
--    nbiot1_data_i(1)(2)     <= (others => '0');
--    nbiot1_data_q(1)(2)     <= (others => '0');
--    nbiot1_data_i(1)(3)     <= (others => '0');
--    nbiot1_data_q(1)(3)     <= (others => '0');
--    nbiot1_data_i(1)(4)     <= (others => '0');
--    nbiot1_data_q(1)(4)     <= (others => '0');
--    nbiot1_data_i(1)(5)     <= (others => '0');
--    nbiot1_data_q(1)(5)     <= (others => '0');
--    nbiot1_data_i(1)(6)     <= (others => '0');
--    nbiot1_data_q(1)(6)     <= (others => '0');
--    nbiot1_data_i(1)(7)     <= (others => '0');
--    nbiot1_data_q(1)(7)     <= (others => '0');

    nbiot2_frame_id(0)      <= NBIOT_CC_FRAME_ID(2*8+7 downto 2*8);
    nbiot2_subframe_id(0)   <= NBIOT_CC_SUBFRAME_ID(2*4+3 downto 2*4);
    nbiot2_slot_id(0)       <= NBIOT_CC_SLOT_ID(2*6+5 downto 2*6);
    nbiot2_symbol_id(0)     <= NBIOT_CC_SYMBOL_ID(2*6+5 downto 2*6);
    nbiot2_start_re(0)      <= NBIOT_CC_START_RE(2*4*16+15 downto 2*4*16);
    nbiot2_valid(0)         <= "0000" & NBIOT_CC_VALID(2*4+3 downto 2*4);
    nbiot2_start(0)         <= "0000" & NBIOT_CC_START(2*4+3 downto 2*4);
    nbiot2_last(0)          <= "0000" & NBIOT_CC_LAST(2*4+3 downto 2*4);
    nbiot2_data_i(0)(0)     <= NBIOT_CC_DATA(8*32+31 downto 8*32+16);
    nbiot2_data_q(0)(0)     <= NBIOT_CC_DATA(8*32+15 downto 8*32+0);
    nbiot2_data_i(0)(1)     <= NBIOT_CC_DATA(9*32+31 downto 9*32+16);
    nbiot2_data_q(0)(1)     <= NBIOT_CC_DATA(9*32+15 downto 9*32+0);
    nbiot2_data_i(0)(2)     <= NBIOT_CC_DATA(10*32+31 downto 10*32+16);
    nbiot2_data_q(0)(2)     <= NBIOT_CC_DATA(10*32+15 downto 10*32+0);
    nbiot2_data_i(0)(3)     <= NBIOT_CC_DATA(11*32+31 downto 11*32+16);
    nbiot2_data_q(0)(3)     <= NBIOT_CC_DATA(11*32+15 downto 11*32+0);
    nbiot2_data_i(0)(4)     <= (others => '0');
    nbiot2_data_q(0)(4)     <= (others => '0');
    nbiot2_data_i(0)(5)     <= (others => '0');
    nbiot2_data_q(0)(5)     <= (others => '0');
    nbiot2_data_i(0)(6)     <= (others => '0');
    nbiot2_data_q(0)(6)     <= (others => '0');
    nbiot2_data_i(0)(7)     <= (others => '0');
    nbiot2_data_q(0)(7)     <= (others => '0');

--    nbiot2_frame_id(1)      <= (others => '0');
--    nbiot2_subframe_id(1)   <= (others => '0');
--    nbiot2_slot_id(1)       <= (others => '0');
--    nbiot2_symbol_id(1)     <= (others => '0');
--    nbiot2_start_re(1)      <= (others => '0');
--    nbiot2_valid(1)         <= (others => '0');
--    nbiot2_start(1)         <= (others => '0');
--    nbiot2_last(1)          <= (others => '0');
--    nbiot2_data_i(1)(0)     <= (others => '0');
--    nbiot2_data_q(1)(0)     <= (others => '0');
--    nbiot2_data_i(1)(1)     <= (others => '0');
--    nbiot2_data_q(1)(1)     <= (others => '0');
--    nbiot2_data_i(1)(2)     <= (others => '0');
--    nbiot2_data_q(1)(2)     <= (others => '0');
--    nbiot2_data_i(1)(3)     <= (others => '0');
--    nbiot2_data_q(1)(3)     <= (others => '0');
--    nbiot2_data_i(1)(4)     <= (others => '0');
--    nbiot2_data_q(1)(4)     <= (others => '0');
--    nbiot2_data_i(1)(5)     <= (others => '0');
--    nbiot2_data_q(1)(5)     <= (others => '0');
--    nbiot2_data_i(1)(6)     <= (others => '0');
--    nbiot2_data_q(1)(6)     <= (others => '0');
--    nbiot2_data_i(1)(7)     <= (others => '0');
--    nbiot2_data_q(1)(7)     <= (others => '0');

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_MAC_INTERCONNECT : MAC_INTERCONNECT
    generic map(
        DL_UNIT                     => DL_UNIT                                 ,--: natural := 2;
        UL_UNIT                     => 1                                       ,--: natural := 2;
        EN_DL_INPUT_REG             => false                                   ,--: false;
        EN_DL_OUTPUT_REG            => false                                   ,--: false;
        EN_UL_INPUT_REG             => false                                   ,--: false;
        EN_UL_OUTPUT_REG            => false                                    --: false
    )
    port map(
        CLK_MAC_RX                  => CLK_MAC_RX                              ,--: in  std_logic;
        CLK_MAC_TX                  => CLK_MAC_TX                              ,--: in  std_logic;

        RST_RX                      => ARESET_RX(0)                            ,--: in  std_logic;
        RST_TX                      => ARESET_TX(0)                            ,--: in  std_logic;

        MAC0_RX_VALID               => MAC0_RX_VALID                           ,--: in  std_logic;
        MAC0_RX_LAST                => MAC0_RX_LAST                            ,--: in  std_logic;
        MAC0_RX_KEEP                => MAC0_RX_KEEP                            ,--: in  std_logic_vector(7 downto 0);
        MAC0_RX_DATA                => MAC0_RX_DATA                            ,--: in  std_logic_vector(63 downto 0);

        MAC0_TX_READY               => MAC0_TX_READY                           ,--: in  std_logic;
        MAC0_TX_VALID               => MAC0_TX_VALID                           ,--: out std_logic;
        MAC0_TX_LAST                => MAC0_TX_LAST                            ,--: out std_logic;
        MAC0_TX_KEEP                => MAC0_TX_KEEP                            ,--: out std_logic_vector(7 downto 0);
        MAC0_TX_DATA                => MAC0_TX_DATA                            ,--: out std_logic_vector(63 downto 0);

        INT_RU_RX_TVALID            => mac_rx_valid                            ,--: out std_logic_vector(DL_UNIT-1 downto 0);
        INT_RU_RX_TLAST             => mac_rx_last                             ,--: out std_logic_vector(DL_UNIT-1 downto 0);
        INT_RU_RX_TKEEP             => mac_rx_keep                             ,--: out std_logic_array8(DL_UNIT-1 downto 0);
        INT_RU_RX_TDATA             => mac_rx_data                             ,--: out std_logic_array64(DL_UNIT-1 downto 0);

        INT_RU_TX_TREADY            => mac_tx_ready                            ,--: out std_logic_vector(UL_UNIT-1 downto 0);
        INT_RU_TX_TVALID            => mac_tx_valid                            ,--: in  std_logic_vector(UL_UNIT-1 downto 0);
        INT_RU_TX_TLAST             => mac_tx_last                             ,--: in  std_logic_vector(UL_UNIT-1 downto 0);
        INT_RU_TX_TKEEP             => mac_tx_keep                             ,--: in  std_logic_array8(UL_UNIT-1 downto 0);
        INT_RU_TX_TDATA             => mac_tx_data                             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);

        EXT_RU_RX_TVALID            => open                                    ,--: out std_logic;
        EXT_RU_RX_TLAST             => open                                    ,--: out std_logic;
        EXT_RU_RX_TKEEP             => open                                    ,--: out std_logic_vector(7 downto 0);
        EXT_RU_RX_TDATA             => open                                    ,--: out std_logic_vector(63 downto 0);

        EXT_RU_TX_TREADY            => EXT_RU_TX_TREADY                        ,--: out std_logic;
        EXT_RU_TX_TVALID            => EXT_RU_TX_TVALID                        ,--: in  std_logic;
        EXT_RU_TX_TLAST             => EXT_RU_TX_TLAST                         ,--: in  std_logic;
        EXT_RU_TX_TKEEP             => EXT_RU_TX_TKEEP                         ,--: in  std_logic_vector(7 downto 0);
        EXT_RU_TX_TDATA             => EXT_RU_TX_TDATA                          --: in  std_logic_vector(63 downto 0)
    );

    u_DL : for i in DL_UNIT-1 downto 0 generate
    u_DEFRAMER : O_RAN_DEFRAMER
    generic map(
        MAX_CH_PER_UNIT             => MAX_CH_PER_UNIT                         ,--: natural := 2;
        FILTER_MAC                  => true                                    ,--: boolean := true;
        FILTER_ETHERTYPE            => true                                    ,--: boolean := true;
        USAGE_C_PLANE               => true                                    ,--: boolean := true;
        USAGE_U_PLANE               => true                                     --: boolean := true
    )
    port map(
        RST                         => ARESET_RX(0)                            ,--: in  std_logic;

        CLK_MAC                     => CLK_MAC_RX                              ,--: in  std_logic;
        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

        RX_PARAM_MAC                => dl_param_mac(i)                         ,--: in  std_logic_vector(47 downto 0);
        RX_PARAM_ETHERTYPE          => x"AEFE"                                 ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_0_EN        => dl_param_id0_en(i)(0)                   ,--: in  std_logic;
        RX_PARAM_ID_CH0_0           => dl_param_id0(i)(0)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_1_EN        => dl_param_id1_en(i)(0)                   ,--: in  std_logic;
        RX_PARAM_ID_CH0_1           => dl_param_id1(i)(0)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_2_EN        => dl_param_id2_en(i)(0)                   ,--: in  std_logic;
        RX_PARAM_ID_CH0_2           => dl_param_id2(i)(0)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_3_EN        => dl_param_id3_en(i)(0)                   ,--: in  std_logic;
        RX_PARAM_ID_CH0_3           => dl_param_id3(i)(0)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_0_EN        => dl_param_id0_en(i)(1)                   ,--: in  std_logic;
        RX_PARAM_ID_CH1_0           => dl_param_id0(i)(1)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_1_EN        => dl_param_id1_en(i)(1)                   ,--: in  std_logic;
        RX_PARAM_ID_CH1_1           => dl_param_id1(i)(1)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_2_EN        => dl_param_id2_en(i)(1)                   ,--: in  std_logic;
        RX_PARAM_ID_CH1_2           => dl_param_id2(i)(1)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_3_EN        => dl_param_id3_en(i)(1)                   ,--: in  std_logic;
        RX_PARAM_ID_CH1_3           => dl_param_id3(i)(1)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_0_EN        => dl_param_id0_en(i)(2)                   ,--: in  std_logic;
        RX_PARAM_ID_CH2_0           => dl_param_id0(i)(2)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_1_EN        => dl_param_id1_en(i)(2)                   ,--: in  std_logic;
        RX_PARAM_ID_CH2_1           => dl_param_id1(i)(2)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_2_EN        => dl_param_id2_en(i)(2)                   ,--: in  std_logic;
        RX_PARAM_ID_CH2_2           => dl_param_id2(i)(2)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_3_EN        => dl_param_id3_en(i)(2)                   ,--: in  std_logic;
        RX_PARAM_ID_CH2_3           => dl_param_id3(i)(2)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_0_EN        => dl_param_id0_en(i)(3)                   ,--: in  std_logic;
        RX_PARAM_ID_CH3_0           => dl_param_id0(i)(3)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_1_EN        => dl_param_id1_en(i)(3)                   ,--: in  std_logic;
        RX_PARAM_ID_CH3_1           => dl_param_id1(i)(3)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_2_EN        => dl_param_id2_en(i)(3)                   ,--: in  std_logic;
        RX_PARAM_ID_CH3_2           => dl_param_id2(i)(3)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_3_EN        => dl_param_id3_en(i)(3)                   ,--: in  std_logic;
        RX_PARAM_ID_CH3_3           => dl_param_id3(i)(3)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_0_EN        => dl_param_id0_en(i)(4)                   ,--: in  std_logic;
        RX_PARAM_ID_CH4_0           => dl_param_id0(i)(4)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_1_EN        => dl_param_id1_en(i)(4)                   ,--: in  std_logic;
        RX_PARAM_ID_CH4_1           => dl_param_id1(i)(4)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_2_EN        => dl_param_id2_en(i)(4)                   ,--: in  std_logic;
        RX_PARAM_ID_CH4_2           => dl_param_id2(i)(4)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_3_EN        => dl_param_id3_en(i)(4)                   ,--: in  std_logic;
        RX_PARAM_ID_CH4_3           => dl_param_id3(i)(4)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_0_EN        => dl_param_id0_en(i)(5)                   ,--: in  std_logic;
        RX_PARAM_ID_CH5_0           => dl_param_id0(i)(5)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_1_EN        => dl_param_id1_en(i)(5)                   ,--: in  std_logic;
        RX_PARAM_ID_CH5_1           => dl_param_id1(i)(5)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_2_EN        => dl_param_id2_en(i)(5)                   ,--: in  std_logic;
        RX_PARAM_ID_CH5_2           => dl_param_id2(i)(5)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_3_EN        => dl_param_id3_en(i)(5)                   ,--: in  std_logic;
        RX_PARAM_ID_CH5_3           => dl_param_id3(i)(5)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_0_EN        => dl_param_id0_en(i)(6)                   ,--: in  std_logic;
        RX_PARAM_ID_CH6_0           => dl_param_id0(i)(6)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_1_EN        => dl_param_id1_en(i)(6)                   ,--: in  std_logic;
        RX_PARAM_ID_CH6_1           => dl_param_id1(i)(6)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_2_EN        => dl_param_id2_en(i)(6)                   ,--: in  std_logic;
        RX_PARAM_ID_CH6_2           => dl_param_id2(i)(6)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_3_EN        => dl_param_id3_en(i)(6)                   ,--: in  std_logic;
        RX_PARAM_ID_CH6_3           => dl_param_id3(i)(6)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_0_EN        => dl_param_id0_en(i)(7)                   ,--: in  std_logic;
        RX_PARAM_ID_CH7_0           => dl_param_id0(i)(7)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_1_EN        => dl_param_id1_en(i)(7)                   ,--: in  std_logic;
        RX_PARAM_ID_CH7_1           => dl_param_id1(i)(7)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_2_EN        => dl_param_id2_en(i)(7)                   ,--: in  std_logic;
        RX_PARAM_ID_CH7_2           => dl_param_id2(i)(7)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_3_EN        => dl_param_id3_en(i)(7)                   ,--: in  std_logic;
        RX_PARAM_ID_CH7_3           => dl_param_id3(i)(7)                      ,--: in  std_logic_vector(15 downto 0);

        RX_COMP_MODE                => dl_comp_mode(i)                         ,--: in  std_logic;
        RX_IQ_WIDTH                 => dl_iq_width(i)                          ,--: in  std_logic_vector(3 downto 0);
        RX_COMP_METHOD              => dl_comp_method(i)                       ,--: in  std_logic_vector(3 downto 0);
        RX_SCS_CONFIG               => dl_scs_config(i)                        ,--: in  std_logic_vector(3 downto 0);
        RX_FFT_SIZE                 => dl_fft_size(i)                          ,--: in  std_logic_vector(3 downto 0);
        RX_PRB_PER_SYMBOL           => dl_prb_per_symbol(i)                    ,--: in  std_logic_vector(9 downto 0);
        RX_COMP_EXP_OFFSET          => dl_comp_exp_offset(i)                   ,--: in  std_logic_vector(4 downto 0);

        USAGE_RX_DATA_BUFFER        => dl_data_buffer(i)                       ,--: out std_logic_vector(31 downto 0);

        RX_INVALID_DST_MAC          => dl_invalid_dst_mac(i)                   ,--: out std_logic_vector(31 downto 0);
        RX_INVALID_ETHERTYPE        => dl_invalid_ethertype(i)                 ,--: out std_logic_vector(31 downto 0);
        RX_INVALID_ecpriVersion     => dl_invalid_ecpriversion(i)              ,--: out std_logic_vector(31 downto 0);
        RX_INVALID_ecpriC           => dl_invalid_ecpric(i)                    ,--: out std_logic_vector(31 downto 0);
        RX_INVALID_ecpriMessage     => dl_invalid_ecprimessage(i)              ,--: out std_logic_vector(31 downto 0);
        RX_C_PLANE                  => dl_c_plane(i)                           ,--: out std_logic_vector(31 downto 0);
        RX_C_PLANE_DROPPED          => dl_c_plane_dropped(i)                   ,--: out std_logic_vector(31 downto 0);
        RX_U_PLANE                  => dl_u_plane(i)                           ,--: out std_logic_vector(31 downto 0);
        RX_U_PLANE_DROPPED          => dl_u_plane_dropped(i)                   ,--: out std_logic_vector(31 downto 0);
        RX_LOST                     => dl_lost(i)                              ,--: out std_logic_vector(31 downto 0);

        RX_LENGTH_IS_NORMAL         => open                                    ,--: out std_logic_vector(31 downto 0);
        RX_LENGTH_IS_LONG           => open                                    ,--: out std_logic_vector(31 downto 0);
        RX_LENGTH_IS_SHORT          => open                                    ,--: out std_logic_vector(31 downto 0);

        RX_C_PLANE_EXIST            => dl_c_plane_exist(i)                     ,--: out std_logic_vector(31 downto 0);
        RX_U_PLANE_EXIST            => dl_u_plane_exist(i)                     ,--: out std_logic_vector(31 downto 0);

        RX_FAULT_ID_31_CH0          => rx_fault_id_31_ch0(i)                   ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH1          => rx_fault_id_31_ch1(i)                   ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH2          => rx_fault_id_31_ch2(i)                   ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH3          => rx_fault_id_31_ch3(i)                   ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH4          => rx_fault_id_31_ch4(i)                   ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH5          => rx_fault_id_31_ch5(i)                   ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH6          => rx_fault_id_31_ch6(i)                   ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH7          => rx_fault_id_31_ch7(i)                   ,--: out std_logic_vector(3 downto 0);

        MAC_RX_READY                => open                                    ,--: out std_logic;
        MAC_RX_VALID                => mac_rx_valid(i)                         ,--: in  std_logic;
        MAC_RX_LAST                 => mac_rx_last(i)                          ,--: in  std_logic;
        MAC_RX_KEEP                 => mac_rx_keep(i)                          ,--: in  std_logic_vector(7 downto 0);
        MAC_RX_DATA                 => mac_rx_data(i)                          ,--: in  std_logic_vector(63 downto 0);

        PACKET_IS_CP_DL             => rx_packet_is_cp_dl(i)                   ,--: out std_logic;
        PACKET_IS_CP_UL             => rx_packet_is_cp_ul(i)                   ,--: out std_logic;
        PACKET_IS_UP_DL             => rx_packet_is_up_dl(i)                   ,--: out std_logic;
        PACKET_IS_UP_UL             => open                                    ,--: out std_logic;
        PACKET_SCS                  => rx_packet_scs(i)                        ,--: out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => rx_packet_frame_id(i)                   ,--: out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => rx_packet_subframe_id(i)                ,--: out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => rx_packet_slot_id(i)                    ,--: out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => rx_packet_symbol_id(i)                  ,--: out std_logic_vector(5 downto 0);

        BYPASS_OUT_VALID            => EXT_RU_RX_TVALID                        ,--: out std_logic;
        BYPASS_OUT_LAST             => EXT_RU_RX_TLAST                         ,--: out std_logic;
        BYPASS_OUT_KEEP             => EXT_RU_RX_TKEEP                         ,--: out std_logic_vector(7 downto 0);
        BYPASS_OUT_DATA             => EXT_RU_RX_TDATA                         ,--: out std_logic_vector(63 downto 0);

        eCPRI_RX_C_VALID            => ecpri_rx_c_valid(i)                     ,--: out std_logic;
        eCPRI_RX_C_LAST             => ecpri_rx_c_last(i)                      ,--: out std_logic;
        eCPRI_RX_C_KEEP             => ecpri_rx_c_keep(i)                      ,--: out std_logic_vector(3 downto 0);
        eCPRI_RX_C_DATA             => ecpri_rx_c_data(i)                      ,--: out std_logic_vector(31 downto 0);
        eCPRI_RX_C_CH               => ecpri_rx_c_ch(i)(2 downto 0)            ,--: out std_logic_vector(2 downto 0);
        eCPRI_RX_C_CH_SUB           => ecpri_rx_c_ch_sub(i)                    ,--: out std_logic_vector(3 downto 0);

        ADV_RB_CHANNEL_ID           => open                                    ,--: out std_logic_vector(2 downto 0);
        ADV_RB_FRAME_ID             => open                                    ,--: out std_logic_vector(7 downto 0);
        ADV_RB_SUBFRAME_ID          => open                                    ,--: out std_logic_vector(3 downto 0);
        ADV_RB_SLOT_ID              => open                                    ,--: out std_logic_vector(5 downto 0);
        ADV_RB_SYMBOL_ID            => open                                    ,--: out std_logic_vector(5 downto 0);
        ADV_RB_START                => open                                    ,--: out std_logic;

        RB_eAxC_ID                  => open                                    ,--: out std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              => open                                    ,--: out std_logic_vector(15 downto 0);
        RB_CHANNEL_ID               => dl_rb_channel_id(i)(2 downto 0)         ,--: out std_logic_vector(2 downto 0);
        RB_FRAME_ID                 => dl_rb_frame_id(i)                       ,--: out std_logic_vector(7 downto 0);
        RB_SUBFRAME_ID              => dl_rb_subframe_id(i)                    ,--: out std_logic_vector(3 downto 0);
        RB_SLOT_ID                  => dl_rb_slot_id(i)                        ,--: out std_logic_vector(5 downto 0);
        RB_SYMBOL_ID                => dl_rb_symbol_id(i)                      ,--: out std_logic_vector(5 downto 0);
        RB_SECTION_ID               => dl_rb_section_id(i)                     ,--: out std_logic_vector(11 downto 0);
        RB_NUMBER                   => open                                    ,--: out std_logic_vector(9 downto 0);
        RE_NUMBER                   => dl_re_number(i)                         ,--: out std_logic_vector(11 downto 0);

        RB_VALID                    => dl_rb_valid(i)                          ,--: out std_logic;
        RB_START                    => dl_rb_start(i)                          ,--: out std_logic;
        RB_TICK                     => dl_rb_tick(i)                           ,--: out std_logic;
        RB_LAST                     => dl_rb_last(i)                           ,--: out std_logic;
        RB_DATA_I                   => dl_rb_data_i(i)                         ,--: out std_logic_vector(15 downto 0);
        RB_DATA_Q                   => dl_rb_data_q(i)                          --: out std_logic_vector(15 downto 0)
    );

    u_CU_PE_TOP : CU_PE_TOP
    generic map(
        VENDOR                      =>"XILINX",
        Category                    =>     "A",
        eCPRI_HDR                   =>    TRUE,
        iFFT_k0_SHIFT               =>    TRUE,
        iFFT_ZERO_PADDING           =>    TRUE,
        SCS                         =>      15,
        SECTION_NUM                 =>     128,
        Max_RB_NUM                  =>     110, -- 20M LTE 100RB + NB-IoT 10RB
        iFFT_WIDTH                  =>      11,
        SYMBOL_NUM                  =>       7,
        CH_NUM                      =>       8, -- Layer/Path @ module
        DL_LAYER_NUM                =>       8,
        UL_RX_NUM                   =>       8,
        CELL_NUM_eMTC               => CELL_NUM_eMTC,
        CELL_NUM_NBIOT              => CELL_NUM_NBIOT,
        PATH_NUM                    => PATH_NUM,-- Layer/Path @ cell
        Opt_BF_Support              =>       0  -- Mandatory: 0, Optional: 1
    )
    port map(

        CLK                         => CLK_BUS                                                               ,--: in  std_logic;

        FRAME_SYNC                  => FRAME_SYNC                                                            ,--: in std_logic; --> should be aligned with 1PPS
        BFN_NUM_IN                  => BFN_NUM_IN                                                            ,--: in std_logic_vector(11 downto 0);

        DL_SYNC_ADVANCE             => DL_CC_SYNC_ADVANCE(22*2*(i+1) - 1 downto 22*2*i)                      ,--: in std_logic_vector(22*2-1 downto 0);
        UL_SYNC_RETARD              => UL_CC_SYNC_RETARD(22*(2*i+1) - 1 downto 22*2*i)                       ,--: in std_logic_vector(21 downto 0);

        --------------------------------------------------------------------------------
        --  Input from ORAN_TOP
        --------------------------------------------------------------------------------

        -- DL/UL C-Plane (Not decoded)
        ECPRI_RX_C_CH_IDX           => ecpri_rx_c_ch(i)                                                      ,--: in  std_logic_vector( 3 downto 0);
        ECPRI_RX_C_VALID            => ecpri_rx_c_valid(i)                                                   ,--: in  std_logic;
        ECPRI_RX_C_LAST             => ecpri_rx_c_last(i)                                                    ,--: in  std_logic;
        ECPRI_RX_C_KEEP             => ecpri_rx_c_keep(i)                                                    ,--: in  std_logic_vector( 3 downto 0);
        ECPRI_RX_C_DATA             => ecpri_rx_c_data(i)                                                    ,--: in  std_logic_vector(31 downto 0);

        -- DL U-Plane
        RB_CH_IDX                   => dl_rb_channel_id(i)                                                   ,--: in  std_logic_vector( 3 downto 0);
        RB_FRAME_ID                 => dl_rb_frame_id(i)                                                     ,--: in  std_logic_vector( 7 downto 0);
        RB_SUBFRAME_ID              => dl_rb_subframe_id(i)                                                  ,--: in  std_logic_vector( 3 downto 0);
        RB_SLOT_ID                  => dl_rb_slot_id(i)                                                      ,--: in  std_logic_vector( 5 downto 0);
        RB_SYMBOL_ID                => dl_rb_symbol_id(i)                                                    ,--: in  std_logic_vector( 5 downto 0);
        RB_SECTION_ID               => dl_rb_section_id(i)                                                   ,--: in  std_logic_vector(11 downto 0);
        RE_NUMBER                   => dl_re_number(i)                                                       ,--: in  std_logic_vector(11 downto 0);

        RB_VALID                    => dl_rb_valid(i)                                                        ,--: in  std_logic;
        RB_START                    => dl_rb_start(i)                                                        ,--: in  std_logic;
        RB_LAST                     => dl_rb_last(i)                                                         ,--: in  std_logic;
        RB_TICK                     => dl_rb_tick(i)                                                         ,--: in  std_logic;
        RB_DATA_I                   => dl_rb_data_i(i)                                                       ,--: in  std_logic_vector(15 downto 0);
        RB_DATA_Q                   => dl_rb_data_q(i)                                                       ,--: in  std_logic_vector(15 downto 0);

        --------------------------------------------------------------------------------
        --  Output to DLFE/RAFE
        --------------------------------------------------------------------------------

        SYSTEM_MODE                 => dlfe_system_mode_dss(2*i)                                             ,--: in  std_logic;
        K0                          => DLFE_CC_K0(12*(2*i+1)-1 downto 12*2*i)                                ,--: in  std_logic_vector(11 downto 0);
        nRE                         => DLFE_CC_nRE(12*2*(i+1)-1 downto 12*2*i)                               ,--: in  std_logic_vector(11 downto 0);
        nFFT                        => DLFE_CC_nFFT(2*2*(i+1)-1 downto 2*2*i)                                ,--: in  std_logic_vector( 1 downto 0);

        BFN_NUM_OUT                 => dlfe_bfn_num_out(i)                                                   ,--: out std_logic_vector(11 downto 0);
        DL_FRAME_SYNC               => dlfe_frame_sync(i)                                                    ,--: out std_logic;
        DL_FRAME_INDEX              => dlfe_frame_index(i)                                                   ,--: out std_logic_vector( 7 downto 0);
        DL_FRAME_STRUCTURE          => dlfe_frame_structure(i)                                               ,--: out std_logic_vector( 7 downto 0);
        DL_MuSu_nLayer              => open                                                                  ,--: out std_logic_vector( 4 downto 0); -- just for Optional BF
        DL_VALID                    => DLFE_CC_VALID(2*4*1*(i+1)-1 downto 2*4*1*i)                           ,--: out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);
        DL_RE_MASK                  => DLFE_CC_RE_MASK(2*4*1*(i+1)-1 downto 2*4*1*i)                         ,--: out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);
        DL_BEAMID                   => open                                                                  ,--: out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*15 - 1 downto 0);
        DL_DATA                     => DLFE_CC_DATA(2*4*32*(i+1)-1 downto 2*4*32*i)                          ,--: out std_logic_vector(127 downto 0);

        UL_FRAME_SYNC               => rafe_frame_sync(i)                                                    ,--: out std_logic;
        UL_FILTER_INDEX             => rafe_filter_index(i)                                                  ,--: out std_logic_vector( 3 downto 0);
        UL_TIME_OFFSET              => rafe_time_offset(i)                                                   ,--: out std_logic_vector(15 downto 0);
        UL_FRAME_STRUCTURE          => rafe_frame_structure(i)                                               ,--: out std_logic_vector( 7 downto 0);
        UL_CPLENGTH                 => rafe_cplength(i)                                                      ,--: out std_logic_vector(15 downto 0);
        UL_FREQ_OFFSET              => rafe_freq_offset(i)                                                   ,--: out std_logic_vector(23 downto 0);
        UL_START_PRBC               => rafe_start_prbc(i)                                                    ,--: out std_logic_vector( 9 downto 0);
        UL_NUM_PRBC                 => rafe_num_prbc(i)                                                      ,--: out std_logic_vector( 7 downto 0);
        UL_NUM_PSYMBOL              => rafe_num_psymbol(i)                                                   ,--: out std_logic_vector( 3 downto 0);
        UL_NUM_RO                   => rafe_num_ro(i)                                                        ,--: out std_logic_vector( 2 downto 0)

        UL_eMTC_FILTER_INDEX        => eMTC_filter_index(i)                                                  ,--: out std_logic_vector( 4*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
        UL_eMTC_TIME_OFFSET         => eMTC_time_offset(i)                                                   ,--: out std_logic_vector(16*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
        UL_eMTC_FRAME_STRUCTURE     => eMTC_frame_structure(i)                                               ,--: out std_logic_vector( 8*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
        UL_eMTC_CPLENGTH            => eMTC_cplength(i)                                                      ,--: out std_logic_vector(16*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
        UL_eMTC_FREQ_OFFSET         => eMTC_freq_offset(i)                                                   ,--: out std_logic_vector(24*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
        UL_eMTC_START_PRBC          => eMTC_start_prbc(i)                                                    ,--: out std_logic_vector(10*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
        UL_eMTC_NUM_PRBC            => eMTC_num_prbc(i)                                                      ,--: out std_logic_vector( 8*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
        UL_eMTC_NUM_PSYMBOL         => eMTC_num_psymbol(i)                                                   ,--: out std_logic_vector( 4*CELL_NUM_eMTC*PATH_NUM-1 downto 0);
        UL_eMTC_NUM_RO              => eMTC_num_ro(i)                                                        ,--: out std_logic_vector( 3*CELL_NUM_eMTC*PATH_NUM-1 downto 0);

        UL_NB_FILTER_INDEX          => NBIOT_CC_FILTER_INDEX                                                 ,--: out std_logic_vector( 4*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
        UL_NB_TIME_OFFSET           => NBIOT_CC_TIME_OFFSET                                                  ,--: out std_logic_vector(16*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
        UL_NB_FRAME_STRUCTURE       => NBIOT_CC_FRAME_STRUCTURE                                              ,--: out std_logic_vector( 8*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
        UL_NB_CPLENGTH              => NBIOT_CC_CPLENGTH                                                     ,--: out std_logic_vector(16*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
        UL_NB_FREQ_OFFSET           => nb_freq_offset                                                        ,--: out std_logic_vector(24*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
        UL_NB_START_PRBC            => nb_start_prbc                                                         ,--: out std_logic_vector(10*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
        UL_NB_NUM_PRBC              => NBIOT_CC_NUM_PRBC                                                     ,--: out std_logic_vector( 8*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
        UL_NB_NUM_PSYMBOL           => NBIOT_CC_NUM_PSYMBOL                                                  ,--: out std_logic_vector( 4*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
        UL_NB_NUM_RO                => NBIOT_CC_NUM_RO                                                        --: out std_logic_vector( 3*CELL_NUM_NBIOT*PATH_NUM-1 downto 0);
    );
    end generate;

--------------------------------------------------------------------------------
-- UL#0
--------------------------------------------------------------------------------
--   MAX_SECTION_PUxCH  -> 60 * 4(MAX_CH_PER_UNIT) = 240 -> 256
--   MAX_SECTION_PRACH  -> 7 * 4(MAX_CH_PER_UNIT) = 28 -> 32
--   MAX_SECTION_eMTC   -> ? * 4(MAX_CH_PER_UNIT) = ?
--   MAX_SECTION_NBIOT0 -> ? * 4(MAX_CH_PER_UNIT) = ?
--   MAX_SECTION_NBIOT1 -> ? * 4(MAX_CH_PER_UNIT) = ?
--   MAX_SECTION_NBIOT2 -> ? * 4(MAX_CH_PER_UNIT) = ?
--------------------------------------------------------------------------------

    u_DATA_MANAGER0 : DATA_MANAGER_UL0
    generic map(
        MAX_SECTION_PUxCH           => 256                                     ,--: natural := 256;
        MAX_SECTION_PRACH           => 32                                      ,--: natural := 16;
        MAX_SECTION_eMTC            => 16                                      ,--: natural := 16;
        MAX_SECTION_NBIOT0          => 16                                      ,--: natural := 8;
        MAX_SECTION_NBIOT1          => 16                                      ,--: natural := 8;
        MAX_SECTION_NBIOT2          => 16                                      ,--: natural := 8;
        LONG_PRACH                  => true                                     --: boolean := true
    )
    port map(
        CLK                         => CLK_BUS                                 ,--: in  std_logic;
        RST                         => ARESET_TX(0)                            ,--: in  std_logic;

        IGNORE_FRAME_ID             => ignore_frame_id(0)                      ,--: in  std_logic;
        IGNORE_FRAME_ID_PUxCH_RX    => ignore_frame_id_puxch_rx(0)             ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    => ignore_frame_id_puxch_tx(0)             ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_RX   => ignore_frame_id_prach0_rx(0)            ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_TX   => ignore_frame_id_prach0_tx(0)            ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_RX   => ignore_frame_id_prach1_rx(0)            ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_TX   => ignore_frame_id_prach1_tx(0)            ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_RX   => ignore_frame_id_nbiot0_rx(0)            ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_TX   => ignore_frame_id_nbiot0_tx(0)            ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_RX   => ignore_frame_id_nbiot1_rx(0)            ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_TX   => ignore_frame_id_nbiot1_tx(0)            ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT2_RX   => ignore_frame_id_nbiot2_rx(0)            ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT2_TX   => ignore_frame_id_nbiot2_tx(0)            ,--: out std_logic_vector(7 downto 0);

--        UL_PUxCH_EN                 => split_dl_param_id2_en(0)                ,--: in  std_logic_vector(7 downto 0);
--        UL_PUxCH_ID                 => split_dl_param_id2(0)                   ,--: in  std_logic_array16(7 downto 0);
--        UL_PRACH_EN                 => split_dl_param_id3_en(0)                ,--: in  std_logic_vector(7 downto 0);
--        UL_PRACH_ID                 => split_dl_param_id3(0)                   ,--: in  std_logic_array16(7 downto 0);
--        UL_NPUSCH_EN                => split_dl_param_id4_en(0)                ,--: in  std_logic_vector(7 downto 0);
--        UL_NPUSCH_ID                => split_dl_param_id4(0)                   ,--: in  std_logic_array16(7 downto 0);

        UL_PUxCH_EN                 => dl_param_id2_en(0)                      ,--: in  std_logic_vector(7 downto 0);
        UL_PUxCH_ID                 => dl_param_id2(0)                         ,--: in  std_logic_array16(7 downto 0);
        UL_PRACH_EN                 => dl_param_id3_en(0)                      ,--: in  std_logic_vector(7 downto 0);
        UL_PRACH_ID                 => dl_param_id3(0)                         ,--: in  std_logic_array16(7 downto 0);
        UL_NPUSCH_EN                => dl_param_id1_en(0)                      ,--: in  std_logic_vector(7 downto 0);
        UL_NPUSCH_ID                => dl_param_id1(0)                         ,--: in  std_logic_array16(7 downto 0);

        UL_COMP_MODE                => ul_comp_mode(0)                         ,--: in  std_logic;
        UL_IQ_WIDTH                 => ul_iq_width(0)                          ,--: in  std_logic_vector(3 downto 0);
        UL_COMP_METHOD              => ul_comp_method(0)                       ,--: in  std_logic_vector(3 downto 0);
        UL_SCS_CONFIG               => ul_scs_config(0)                        ,--: in  std_logic_vector(3 downto 0);
        UL_FFT_SIZE                 => ul_fft_size(0)                          ,--: in  std_logic_vector(3 downto 0);
        UL_PRB_PER_MTU              => ul_prb_per_mtu(0)                       ,--: in  std_logic_vector(9 downto 0);
        UL_PRB_PER_SYMBOL           => ul_prb_per_symbol(0)                    ,--: in  std_logic_vector(9 downto 0);

        CNT_FIFO_FULL               => ul_cmd_fifo_full(0)                     ,--: out std_logic_vector(31 downto 0);

        CNT_PUxCH_TERMINATION       => puxch_termination(0)                    ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL0     => puxch_cpsec_symbol0(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL1     => puxch_cpsec_symbol1(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL2     => puxch_cpsec_symbol2(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL3     => puxch_cpsec_symbol3(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL4     => puxch_cpsec_symbol4(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL5     => puxch_cpsec_symbol5(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL6     => puxch_cpsec_symbol6(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL7     => puxch_cpsec_symbol7(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL8     => puxch_cpsec_symbol8(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL9     => puxch_cpsec_symbol9(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL10    => puxch_cpsec_symbol10(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL11    => puxch_cpsec_symbol11(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL12    => puxch_cpsec_symbol12(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL13    => puxch_cpsec_symbol13(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL0     => puxch_uppkt_symbol0(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL1     => puxch_uppkt_symbol1(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL2     => puxch_uppkt_symbol2(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL3     => puxch_uppkt_symbol3(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL4     => puxch_uppkt_symbol4(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL5     => puxch_uppkt_symbol5(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL6     => puxch_uppkt_symbol6(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL7     => puxch_uppkt_symbol7(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL8     => puxch_uppkt_symbol8(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL9     => puxch_uppkt_symbol9(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL10    => puxch_uppkt_symbol10(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL11    => puxch_uppkt_symbol11(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL12    => puxch_uppkt_symbol12(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL13    => puxch_uppkt_symbol13(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL0   => puxch_cq_full_symbol0(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL1   => puxch_cq_full_symbol1(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL2   => puxch_cq_full_symbol2(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL3   => puxch_cq_full_symbol3(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL4   => puxch_cq_full_symbol4(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL5   => puxch_cq_full_symbol5(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL6   => puxch_cq_full_symbol6(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL7   => puxch_cq_full_symbol7(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL8   => puxch_cq_full_symbol8(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL9   => puxch_cq_full_symbol9(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL10  => puxch_cq_full_symbol10(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL11  => puxch_cq_full_symbol11(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL12  => puxch_cq_full_symbol12(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL13  => puxch_cq_full_symbol13(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL0      => usage_puxch_cq_symbol0(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL1      => usage_puxch_cq_symbol1(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL2      => usage_puxch_cq_symbol2(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL3      => usage_puxch_cq_symbol3(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL4      => usage_puxch_cq_symbol4(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL5      => usage_puxch_cq_symbol5(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL6      => usage_puxch_cq_symbol6(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL7      => usage_puxch_cq_symbol7(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL8      => usage_puxch_cq_symbol8(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL9      => usage_puxch_cq_symbol9(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL10     => usage_puxch_cq_symbol10(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL11     => usage_puxch_cq_symbol11(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL12     => usage_puxch_cq_symbol12(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL13     => usage_puxch_cq_symbol13(0)              ,--: out std_logic_vector(31 downto 0);

        CNT_PRACH_TERMINATION       => prach_termination(0)                    ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL0     => prach_cpsec_symbol0(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL1     => prach_cpsec_symbol1(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL2     => prach_cpsec_symbol2(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL3     => prach_cpsec_symbol3(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL4     => prach_cpsec_symbol4(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL5     => prach_cpsec_symbol5(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL6     => prach_cpsec_symbol6(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL7     => prach_cpsec_symbol7(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL8     => prach_cpsec_symbol8(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL9     => prach_cpsec_symbol9(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL10    => prach_cpsec_symbol10(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL11    => prach_cpsec_symbol11(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL12    => prach_cpsec_symbol12(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL13    => prach_cpsec_symbol13(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL0     => prach_uppkt_symbol0(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL1     => prach_uppkt_symbol1(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL2     => prach_uppkt_symbol2(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL3     => prach_uppkt_symbol3(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL4     => prach_uppkt_symbol4(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL5     => prach_uppkt_symbol5(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL6     => prach_uppkt_symbol6(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL7     => prach_uppkt_symbol7(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL8     => prach_uppkt_symbol8(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL9     => prach_uppkt_symbol9(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL10    => prach_uppkt_symbol10(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL11    => prach_uppkt_symbol11(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL12    => prach_uppkt_symbol12(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL13    => prach_uppkt_symbol13(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL0   => prach_cq_full_symbol0(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL1   => prach_cq_full_symbol1(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL2   => prach_cq_full_symbol2(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL3   => prach_cq_full_symbol3(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL4   => prach_cq_full_symbol4(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL5   => prach_cq_full_symbol5(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL6   => prach_cq_full_symbol6(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL7   => prach_cq_full_symbol7(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL8   => prach_cq_full_symbol8(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL9   => prach_cq_full_symbol9(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL10  => prach_cq_full_symbol10(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL11  => prach_cq_full_symbol11(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL12  => prach_cq_full_symbol12(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL13  => prach_cq_full_symbol13(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL0      => usage_prach_cq_symbol0(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL1      => usage_prach_cq_symbol1(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL2      => usage_prach_cq_symbol2(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL3      => usage_prach_cq_symbol3(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL4      => usage_prach_cq_symbol4(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL5      => usage_prach_cq_symbol5(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL6      => usage_prach_cq_symbol6(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL7      => usage_prach_cq_symbol7(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL8      => usage_prach_cq_symbol8(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL9      => usage_prach_cq_symbol9(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL10     => usage_prach_cq_symbol10(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL11     => usage_prach_cq_symbol11(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL12     => usage_prach_cq_symbol12(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL13     => usage_prach_cq_symbol13(0)              ,--: out std_logic_vector(31 downto 0);

        CNT_eMTC_TERMINATION        => emtc_termination(0)                     ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL0      => emtc_cpsec_symbol0(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL1      => emtc_cpsec_symbol1(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL2      => emtc_cpsec_symbol2(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL3      => emtc_cpsec_symbol3(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL4      => emtc_cpsec_symbol4(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL5      => emtc_cpsec_symbol5(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL6      => emtc_cpsec_symbol6(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL7      => emtc_cpsec_symbol7(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL8      => emtc_cpsec_symbol8(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL9      => emtc_cpsec_symbol9(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL10     => emtc_cpsec_symbol10(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL11     => emtc_cpsec_symbol11(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL12     => emtc_cpsec_symbol12(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL13     => emtc_cpsec_symbol13(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL0      => emtc_uppkt_symbol0(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL1      => emtc_uppkt_symbol1(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL2      => emtc_uppkt_symbol2(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL3      => emtc_uppkt_symbol3(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL4      => emtc_uppkt_symbol4(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL5      => emtc_uppkt_symbol5(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL6      => emtc_uppkt_symbol6(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL7      => emtc_uppkt_symbol7(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL8      => emtc_uppkt_symbol8(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL9      => emtc_uppkt_symbol9(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL10     => emtc_uppkt_symbol10(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL11     => emtc_uppkt_symbol11(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL12     => emtc_uppkt_symbol12(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL13     => emtc_uppkt_symbol13(0)                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL0    => emtc_cq_full_symbol0(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL1    => emtc_cq_full_symbol1(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL2    => emtc_cq_full_symbol2(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL3    => emtc_cq_full_symbol3(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL4    => emtc_cq_full_symbol4(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL5    => emtc_cq_full_symbol5(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL6    => emtc_cq_full_symbol6(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL7    => emtc_cq_full_symbol7(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL8    => emtc_cq_full_symbol8(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL9    => emtc_cq_full_symbol9(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL10   => emtc_cq_full_symbol10(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL11   => emtc_cq_full_symbol11(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL12   => emtc_cq_full_symbol12(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL13   => emtc_cq_full_symbol13(0)                ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL0       => usage_emtc_cq_symbol0(0)                ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL1       => usage_emtc_cq_symbol1(0)                ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL2       => usage_emtc_cq_symbol2(0)                ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL3       => usage_emtc_cq_symbol3(0)                ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL4       => usage_emtc_cq_symbol4(0)                ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL5       => usage_emtc_cq_symbol5(0)                ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL6       => usage_emtc_cq_symbol6(0)                ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL7       => usage_emtc_cq_symbol7(0)                ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL8       => usage_emtc_cq_symbol8(0)                ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL9       => usage_emtc_cq_symbol9(0)                ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL10      => usage_emtc_cq_symbol10(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL11      => usage_emtc_cq_symbol11(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL12      => usage_emtc_cq_symbol12(0)               ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL13      => usage_emtc_cq_symbol13(0)               ,--: out std_logic_vector(31 downto 0);

        CNT_NBIOT0_TERMINATION      => nbiot0_termination(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL0    => nbiot0_cpsec_symbol0(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL1    => nbiot0_cpsec_symbol1(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL2    => nbiot0_cpsec_symbol2(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL3    => nbiot0_cpsec_symbol3(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL4    => nbiot0_cpsec_symbol4(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL5    => nbiot0_cpsec_symbol5(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL6    => nbiot0_cpsec_symbol6(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL7    => nbiot0_cpsec_symbol7(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL8    => nbiot0_cpsec_symbol8(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL9    => nbiot0_cpsec_symbol9(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL10   => nbiot0_cpsec_symbol10(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL11   => nbiot0_cpsec_symbol11(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL12   => nbiot0_cpsec_symbol12(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL13   => nbiot0_cpsec_symbol13(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL0    => nbiot0_uppkt_symbol0(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL1    => nbiot0_uppkt_symbol1(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL2    => nbiot0_uppkt_symbol2(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL3    => nbiot0_uppkt_symbol3(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL4    => nbiot0_uppkt_symbol4(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL5    => nbiot0_uppkt_symbol5(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL6    => nbiot0_uppkt_symbol6(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL7    => nbiot0_uppkt_symbol7(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL8    => nbiot0_uppkt_symbol8(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL9    => nbiot0_uppkt_symbol9(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL10   => nbiot0_uppkt_symbol10(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL11   => nbiot0_uppkt_symbol11(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL12   => nbiot0_uppkt_symbol12(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL13   => nbiot0_uppkt_symbol13(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL0  => nbiot0_cq_full_symbol0(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL1  => nbiot0_cq_full_symbol1(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL2  => nbiot0_cq_full_symbol2(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL3  => nbiot0_cq_full_symbol3(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL4  => nbiot0_cq_full_symbol4(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL5  => nbiot0_cq_full_symbol5(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL6  => nbiot0_cq_full_symbol6(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL7  => nbiot0_cq_full_symbol7(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL8  => nbiot0_cq_full_symbol8(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL9  => nbiot0_cq_full_symbol9(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL10 => nbiot0_cq_full_symbol10(0)              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL11 => nbiot0_cq_full_symbol11(0)              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL12 => nbiot0_cq_full_symbol12(0)              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL13 => nbiot0_cq_full_symbol13(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL0     => usage_nbiot0_cq_symbol0(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL1     => usage_nbiot0_cq_symbol1(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL2     => usage_nbiot0_cq_symbol2(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL3     => usage_nbiot0_cq_symbol3(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL4     => usage_nbiot0_cq_symbol4(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL5     => usage_nbiot0_cq_symbol5(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL6     => usage_nbiot0_cq_symbol6(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL7     => usage_nbiot0_cq_symbol7(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL8     => usage_nbiot0_cq_symbol8(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL9     => usage_nbiot0_cq_symbol9(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL10    => usage_nbiot0_cq_symbol10(0)             ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL11    => usage_nbiot0_cq_symbol11(0)             ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL12    => usage_nbiot0_cq_symbol12(0)             ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL13    => usage_nbiot0_cq_symbol13(0)             ,--: out std_logic_vector(31 downto 0);

        CNT_NBIOT1_TERMINATION      => nbiot1_termination(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL0    => nbiot1_cpsec_symbol0(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL1    => nbiot1_cpsec_symbol1(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL2    => nbiot1_cpsec_symbol2(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL3    => nbiot1_cpsec_symbol3(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL4    => nbiot1_cpsec_symbol4(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL5    => nbiot1_cpsec_symbol5(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL6    => nbiot1_cpsec_symbol6(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL7    => nbiot1_cpsec_symbol7(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL8    => nbiot1_cpsec_symbol8(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL9    => nbiot1_cpsec_symbol9(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL10   => nbiot1_cpsec_symbol10(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL11   => nbiot1_cpsec_symbol11(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL12   => nbiot1_cpsec_symbol12(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL13   => nbiot1_cpsec_symbol13(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL0    => nbiot1_uppkt_symbol0(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL1    => nbiot1_uppkt_symbol1(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL2    => nbiot1_uppkt_symbol2(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL3    => nbiot1_uppkt_symbol3(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL4    => nbiot1_uppkt_symbol4(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL5    => nbiot1_uppkt_symbol5(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL6    => nbiot1_uppkt_symbol6(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL7    => nbiot1_uppkt_symbol7(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL8    => nbiot1_uppkt_symbol8(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL9    => nbiot1_uppkt_symbol9(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL10   => nbiot1_uppkt_symbol10(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL11   => nbiot1_uppkt_symbol11(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL12   => nbiot1_uppkt_symbol12(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL13   => nbiot1_uppkt_symbol13(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL0  => nbiot1_cq_full_symbol0(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL1  => nbiot1_cq_full_symbol1(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL2  => nbiot1_cq_full_symbol2(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL3  => nbiot1_cq_full_symbol3(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL4  => nbiot1_cq_full_symbol4(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL5  => nbiot1_cq_full_symbol5(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL6  => nbiot1_cq_full_symbol6(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL7  => nbiot1_cq_full_symbol7(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL8  => nbiot1_cq_full_symbol8(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL9  => nbiot1_cq_full_symbol9(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL10 => nbiot1_cq_full_symbol10(0)              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL11 => nbiot1_cq_full_symbol11(0)              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL12 => nbiot1_cq_full_symbol12(0)              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL13 => nbiot1_cq_full_symbol13(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL0     => usage_nbiot1_cq_symbol0(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL1     => usage_nbiot1_cq_symbol1(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL2     => usage_nbiot1_cq_symbol2(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL3     => usage_nbiot1_cq_symbol3(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL4     => usage_nbiot1_cq_symbol4(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL5     => usage_nbiot1_cq_symbol5(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL6     => usage_nbiot1_cq_symbol6(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL7     => usage_nbiot1_cq_symbol7(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL8     => usage_nbiot1_cq_symbol8(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL9     => usage_nbiot1_cq_symbol9(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL10    => usage_nbiot1_cq_symbol10(0)             ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL11    => usage_nbiot1_cq_symbol11(0)             ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL12    => usage_nbiot1_cq_symbol12(0)             ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL13    => usage_nbiot1_cq_symbol13(0)             ,--: out std_logic_vector(31 downto 0);

        CNT_NBIOT2_TERMINATION      => nbiot2_termination(0)                   ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL0    => nbiot2_cpsec_symbol0(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL1    => nbiot2_cpsec_symbol1(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL2    => nbiot2_cpsec_symbol2(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL3    => nbiot2_cpsec_symbol3(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL4    => nbiot2_cpsec_symbol4(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL5    => nbiot2_cpsec_symbol5(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL6    => nbiot2_cpsec_symbol6(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL7    => nbiot2_cpsec_symbol7(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL8    => nbiot2_cpsec_symbol8(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL9    => nbiot2_cpsec_symbol9(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL10   => nbiot2_cpsec_symbol10(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL11   => nbiot2_cpsec_symbol11(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL12   => nbiot2_cpsec_symbol12(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL13   => nbiot2_cpsec_symbol13(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL0    => nbiot2_uppkt_symbol0(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL1    => nbiot2_uppkt_symbol1(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL2    => nbiot2_uppkt_symbol2(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL3    => nbiot2_uppkt_symbol3(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL4    => nbiot2_uppkt_symbol4(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL5    => nbiot2_uppkt_symbol5(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL6    => nbiot2_uppkt_symbol6(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL7    => nbiot2_uppkt_symbol7(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL8    => nbiot2_uppkt_symbol8(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL9    => nbiot2_uppkt_symbol9(0)                 ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL10   => nbiot2_uppkt_symbol10(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL11   => nbiot2_uppkt_symbol11(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL12   => nbiot2_uppkt_symbol12(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL13   => nbiot2_uppkt_symbol13(0)                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL0  => nbiot2_cq_full_symbol0(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL1  => nbiot2_cq_full_symbol1(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL2  => nbiot2_cq_full_symbol2(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL3  => nbiot2_cq_full_symbol3(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL4  => nbiot2_cq_full_symbol4(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL5  => nbiot2_cq_full_symbol5(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL6  => nbiot2_cq_full_symbol6(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL7  => nbiot2_cq_full_symbol7(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL8  => nbiot2_cq_full_symbol8(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL9  => nbiot2_cq_full_symbol9(0)               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL10 => nbiot2_cq_full_symbol10(0)              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL11 => nbiot2_cq_full_symbol11(0)              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL12 => nbiot2_cq_full_symbol12(0)              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL13 => nbiot2_cq_full_symbol13(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL0     => usage_nbiot2_cq_symbol0(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL1     => usage_nbiot2_cq_symbol1(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL2     => usage_nbiot2_cq_symbol2(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL3     => usage_nbiot2_cq_symbol3(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL4     => usage_nbiot2_cq_symbol4(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL5     => usage_nbiot2_cq_symbol5(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL6     => usage_nbiot2_cq_symbol6(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL7     => usage_nbiot2_cq_symbol7(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL8     => usage_nbiot2_cq_symbol8(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL9     => usage_nbiot2_cq_symbol9(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL10    => usage_nbiot2_cq_symbol10(0)             ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL11    => usage_nbiot2_cq_symbol11(0)             ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL12    => usage_nbiot2_cq_symbol12(0)             ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL13    => usage_nbiot2_cq_symbol13(0)             ,--: out std_logic_vector(31 downto 0);

        C_PLANE_VALID               => ecpri_rx_c_valid_split(0)               ,--: in  std_logic;
        C_PLANE_LAST                => ecpri_rx_c_last(0)                      ,--: in  std_logic;
        C_PLANE_KEEP                => ecpri_rx_c_keep(0)                      ,--: in  std_logic_vector(3 downto 0);
        C_PLANE_DATA                => ecpri_rx_c_data(0)                      ,--: in  std_logic_vector(31 downto 0);
        C_PLANE_CH                  => ecpri_rx_c_ch_split(0)(2 downto 0)      ,--: in  std_logic_vector(2 downto 0);
        C_PLANE_CH_SUB              => ecpri_rx_c_ch_sub(0)                    ,--: in  std_logic_vector(3 downto 0);

        FREQ_OFFSET_FOR_PRACH_0     => freq_offset_for_prach_0(0)              ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_1     => freq_offset_for_prach_1(0)              ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_2     => freq_offset_for_prach_2(0)              ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_3     => freq_offset_for_prach_3(0)              ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_4     => freq_offset_for_prach_4(0)              ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_5     => freq_offset_for_prach_5(0)              ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_6     => freq_offset_for_prach_6(0)              ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_7     => freq_offset_for_prach_7(0)              ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_0      => freq_offset_for_emtc_0(0)               ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_1      => freq_offset_for_emtc_1(0)               ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_2      => freq_offset_for_emtc_2(0)               ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_3      => freq_offset_for_emtc_3(0)               ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_4      => freq_offset_for_emtc_4(0)               ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_5      => freq_offset_for_emtc_5(0)               ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_6      => freq_offset_for_emtc_6(0)               ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_7      => freq_offset_for_emtc_7(0)               ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_0    => freq_offset_for_nprach_0(0)             ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_1    => freq_offset_for_nprach_1(0)             ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_2    => freq_offset_for_nprach_2(0)             ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_3    => freq_offset_for_nprach_3(0)             ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_4    => freq_offset_for_nprach_4(0)             ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_5    => freq_offset_for_nprach_5(0)             ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_6    => freq_offset_for_nprach_6(0)             ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_7    => freq_offset_for_nprach_7(0)             ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_0   => freq_offset_for_npusch0_0(0)            ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_1   => freq_offset_for_npusch0_1(0)            ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_2   => freq_offset_for_npusch0_2(0)            ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_3   => freq_offset_for_npusch0_3(0)            ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_4   => freq_offset_for_npusch0_4(0)            ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_5   => freq_offset_for_npusch0_5(0)            ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_6   => freq_offset_for_npusch0_6(0)            ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_7   => freq_offset_for_npusch0_7(0)            ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_0   => freq_offset_for_npusch1_0(0)            ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_1   => freq_offset_for_npusch1_1(0)            ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_2   => freq_offset_for_npusch1_2(0)            ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_3   => freq_offset_for_npusch1_3(0)            ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_4   => freq_offset_for_npusch1_4(0)            ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_5   => freq_offset_for_npusch1_5(0)            ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_6   => freq_offset_for_npusch1_6(0)            ,--: in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_7   => freq_offset_for_npusch1_7(0)            ,--: in  std_logic_vector(23 downto 0);

        ULFE_FRAME_ID               => ulfe_frame_id(0)                        ,--: in  std_logic_vector(7 downto 0);
        ULFE_SUBFRAME_ID            => ulfe_subframe_id(0)                     ,--: in  std_logic_vector(3 downto 0);
        ULFE_SLOT_ID                => ulfe_slot_id(0)                         ,--: in  std_logic_vector(5 downto 0);
        ULFE_SYMBOL_ID              => ulfe_symbol_id(0)                       ,--: in  std_logic_vector(5 downto 0);
        ULFE_START_RE               => ulfe_start_re(0)                        ,--: in  std_logic_vector(15 downto 0);

        ULFE_VALID                  => ulfe_valid(0)                           ,--: in  std_logic_vector(7 downto 0);
        ULFE_START                  => ulfe_start(0)                           ,--: in  std_logic_vector(7 downto 0);
        ULFE_LAST                   => ulfe_last(0)                            ,--: in  std_logic_vector(7 downto 0);
        ULFE_DATA_I                 => ulfe_data_i(0)                          ,--: in  std_logic_array16(7 downto 0);
        ULFE_DATA_Q                 => ulfe_data_q(0)                          ,--: in  std_logic_array16(7 downto 0);

        RAFE_FRAME_ID               => rafe_frame_id(0)                        ,--: in  std_logic_vector(7 downto 0);
        RAFE_SUBFRAME_ID            => rafe_subframe_id(0)                     ,--: in  std_logic_vector(3 downto 0);
        RAFE_SLOT_ID                => rafe_slot_id(0)                         ,--: in  std_logic_vector(5 downto 0);
        RAFE_SYMBOL_ID              => rafe_symbol_id(0)                       ,--: in  std_logic_vector(5 downto 0);
        RAFE_START_RE               => rafe_start_re(0)                        ,--: in  std_logic_vector(15 downto 0);

        RAFE_VALID                  => rafe_valid(0)                           ,--: in  std_logic_vector(7 downto 0);
        RAFE_START                  => rafe_start(0)                           ,--: in  std_logic_vector(7 downto 0);
        RAFE_LAST                   => rafe_last(0)                            ,--: in  std_logic_vector(7 downto 0);
        RAFE_DATA_I                 => rafe_data_i(0)                          ,--: in  std_logic_array16(7 downto 0);
        RAFE_DATA_Q                 => rafe_data_q(0)                          ,--: in  std_logic_array16(7 downto 0);

        eMTC_FRAME_ID               => emtc_frame_id(0)                        ,--: in  std_logic_vector(7 downto 0);
        eMTC_SUBFRAME_ID            => emtc_subframe_id(0)                     ,--: in  std_logic_vector(3 downto 0);
        eMTC_SLOT_ID                => emtc_slot_id(0)                         ,--: in  std_logic_vector(5 downto 0);
        eMTC_SYMBOL_ID              => emtc_symbol_id(0)                       ,--: in  std_logic_vector(5 downto 0);
        eMTC_START_RE               => emtc_start_re(0)                        ,--: in  std_logic_vector(15 downto 0);

        eMTC_VALID                  => emtc_valid(0)                           ,--: in  std_logic_vector(7 downto 0);
        eMTC_START                  => emtc_start(0)                           ,--: in  std_logic_vector(7 downto 0);
        eMTC_LAST                   => emtc_last(0)                            ,--: in  std_logic_vector(7 downto 0);
        eMTC_DATA_I                 => emtc_data_i(0)                          ,--: in  std_logic_array16(7 downto 0);
        eMTC_DATA_Q                 => emtc_data_q(0)                          ,--: in  std_logic_array16(7 downto 0);

        NBFE0_FRAME_ID              => nbiot0_frame_id(0)                      ,--: in  std_logic_vector(7 downto 0);
        NBFE0_SUBFRAME_ID           => nbiot0_subframe_id(0)                   ,--: in  std_logic_vector(3 downto 0);
        NBFE0_SLOT_ID               => nbiot0_slot_id(0)                       ,--: in  std_logic_vector(5 downto 0);
        NBFE0_SYMBOL_ID             => nbiot0_symbol_id(0)                     ,--: in  std_logic_vector(5 downto 0);
        NBFE0_START_RE              => nbiot0_start_re(0)                      ,--: in  std_logic_vector(15 downto 0);

        NBFE0_VALID                 => nbiot0_valid(0)                         ,--: in  std_logic_vector(7 downto 0);
        NBFE0_START                 => nbiot0_start(0)                         ,--: in  std_logic_vector(7 downto 0);
        NBFE0_LAST                  => nbiot0_last(0)                          ,--: in  std_logic_vector(7 downto 0);
        NBFE0_DATA_I                => nbiot0_data_i(0)                        ,--: in  std_logic_array16(7 downto 0);
        NBFE0_DATA_Q                => nbiot0_data_q(0)                        ,--: in  std_logic_array16(7 downto 0);

        NBFE1_FRAME_ID              => nbiot1_frame_id(0)                      ,--: in  std_logic_vector(7 downto 0);
        NBFE1_SUBFRAME_ID           => nbiot1_subframe_id(0)                   ,--: in  std_logic_vector(3 downto 0);
        NBFE1_SLOT_ID               => nbiot1_slot_id(0)                       ,--: in  std_logic_vector(5 downto 0);
        NBFE1_SYMBOL_ID             => nbiot1_symbol_id(0)                     ,--: in  std_logic_vector(5 downto 0);
        NBFE1_START_RE              => nbiot1_start_re(0)                      ,--: in  std_logic_vector(15 downto 0);

        NBFE1_VALID                 => nbiot1_valid(0)                         ,--: in  std_logic_vector(7 downto 0);
        NBFE1_START                 => nbiot1_start(0)                         ,--: in  std_logic_vector(7 downto 0);
        NBFE1_LAST                  => nbiot1_last(0)                          ,--: in  std_logic_vector(7 downto 0);
        NBFE1_DATA_I                => nbiot1_data_i(0)                        ,--: in  std_logic_array16(7 downto 0);
        NBFE1_DATA_Q                => nbiot1_data_q(0)                        ,--: in  std_logic_array16(7 downto 0);

        NBFE2_FRAME_ID              => nbiot2_frame_id(0)                      ,--: in  std_logic_vector(7 downto 0);
        NBFE2_SUBFRAME_ID           => nbiot2_subframe_id(0)                   ,--: in  std_logic_vector(3 downto 0);
        NBFE2_SLOT_ID               => nbiot2_slot_id(0)                       ,--: in  std_logic_vector(5 downto 0);
        NBFE2_SYMBOL_ID             => nbiot2_symbol_id(0)                     ,--: in  std_logic_vector(5 downto 0);
        NBFE2_START_RE              => nbiot2_start_re(0)                      ,--: in  std_logic_vector(15 downto 0);

        NBFE2_VALID                 => nbiot2_valid(0)                         ,--: in  std_logic_vector(7 downto 0);
        NBFE2_START                 => nbiot2_start(0)                         ,--: in  std_logic_vector(7 downto 0);
        NBFE2_LAST                  => nbiot2_last(0)                          ,--: in  std_logic_vector(7 downto 0);
        NBFE2_DATA_I                => nbiot2_data_i(0)                        ,--: in  std_logic_array16(7 downto 0);
        NBFE2_DATA_Q                => nbiot2_data_q(0)                        ,--: in  std_logic_array16(7 downto 0);

        PUxCH_RB_INIT               => puxch_rb_init(0)                        ,--: out std_logic;
        PUxCH_RB_eAxC_ID            => puxch_rb_eaxc_id(0)                     ,--: out std_logic_vector(15 downto 0);
        PUxCH_RB_SEQUENCE_ID        => puxch_rb_sequence_id(0)                 ,--: out std_logic_vector(15 downto 0);
        PUxCH_RB_HEADER_APP         => puxch_rb_header_app(0)                  ,--: out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_APP_ACK     => puxch_rb_header_app_ack(0)              ,--: in  std_logic;
        PUxCH_RB_HEADER_SEC         => puxch_rb_header_sec(0)                  ,--: out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_SEC_ACK     => puxch_rb_header_sec_ack(0)              ,--: in  std_logic;

        PUxCH_RB_COMP_HDR           => puxch_rb_comp_hdr(0)                    ,--: out std_logic_vector(7 downto 0);

        PUxCH_RB_VALID              => puxch_rb_valid(0)                       ,--: out std_logic;
        PUxCH_RB_TICK               => puxch_rb_tick(0)                        ,--: out std_logic;
        PUxCH_RB_DATA_I             => puxch_rb_data_i(0)                      ,--: out std_logic_vector(15 downto 0);
        PUxCH_RB_DATA_Q             => puxch_rb_data_q(0)                      ,--: out std_logic_vector(15 downto 0);
        PUxCH_RB_USER               => puxch_rb_user(0)                        ,--: out std_logic_vector(15 downto 0);

        PRACH_RB_INIT               => prach_rb_init(0)                        ,--: out std_logic;
        PRACH_RB_eAxC_ID            => prach_rb_eaxc_id(0)                     ,--: out std_logic_vector(15 downto 0);
        PRACH_RB_SEQUENCE_ID        => prach_rb_sequence_id(0)                 ,--: out std_logic_vector(15 downto 0);
        PRACH_RB_HEADER_APP         => prach_rb_header_app(0)                  ,--: out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_APP_ACK     => prach_rb_header_app_ack(0)              ,--: in  std_logic;
        PRACH_RB_HEADER_SEC         => prach_rb_header_sec(0)                  ,--: out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_SEC_ACK     => prach_rb_header_sec_ack(0)              ,--: in  std_logic;

        PRACH_RB_COMP_HDR           => prach_rb_comp_hdr(0)                    ,--: out std_logic_vector(7 downto 0);

        PRACH_RB_VALID              => prach_rb_valid(0)                       ,--: out std_logic;
        PRACH_RB_TICK               => prach_rb_tick(0)                        ,--: out std_logic;
        PRACH_RB_DATA_I             => prach_rb_data_i(0)                      ,--: out std_logic_vector(15 downto 0);
        PRACH_RB_DATA_Q             => prach_rb_data_q(0)                      ,--: out std_logic_vector(15 downto 0);
        PRACH_RB_USER               => prach_rb_user(0)                        ,--: out std_logic_vector(15 downto 0);

        eMTC_RB_INIT                => emtc_rb_init(0)                         ,--: out std_logic;
        eMTC_RB_eAxC_ID             => emtc_rb_eaxc_id(0)                      ,--: out std_logic_vector(15 downto 0);
        eMTC_RB_SEQUENCE_ID         => emtc_rb_sequence_id(0)                  ,--: out std_logic_vector(15 downto 0);
        eMTC_RB_HEADER_APP          => emtc_rb_header_app(0)                   ,--: out std_logic_vector(31 downto 0);
        eMTC_RB_HEADER_APP_ACK      => emtc_rb_header_app_ack(0)               ,--: in  std_logic;
        eMTC_RB_HEADER_SEC          => emtc_rb_header_sec(0)                   ,--: out std_logic_vector(31 downto 0);
        eMTC_RB_HEADER_SEC_ACK      => emtc_rb_header_sec_ack(0)               ,--: in  std_logic;

        eMTC_RB_COMP_HDR            => emtc_rb_comp_hdr(0)                     ,--: out std_logic_vector(7 downto 0);

        eMTC_RB_VALID               => emtc_rb_valid(0)                        ,--: out std_logic;
        eMTC_RB_TICK                => emtc_rb_tick(0)                         ,--: out std_logic;
        eMTC_RB_DATA_I              => emtc_rb_data_i(0)                       ,--: out std_logic_vector(15 downto 0);
        eMTC_RB_DATA_Q              => emtc_rb_data_q(0)                       ,--: out std_logic_vector(15 downto 0);
        eMTC_RB_USER                => emtc_rb_user(0)                         ,--: out std_logic_vector(15 downto 0);

        NBIOT0_RB_INIT              => nbiot0_rb_init(0)                       ,--: out std_logic;
        NBIOT0_RB_eAxC_ID           => nbiot0_rb_eaxc_id(0)                    ,--: out std_logic_vector(15 downto 0);
        NBIOT0_RB_SEQUENCE_ID       => nbiot0_rb_sequence_id(0)                ,--: out std_logic_vector(15 downto 0);
        NBIOT0_RB_HEADER_APP        => nbiot0_rb_header_app(0)                 ,--: out std_logic_vector(31 downto 0);
        NBIOT0_RB_HEADER_APP_ACK    => nbiot0_rb_header_app_ack(0)             ,--: in  std_logic;
        NBIOT0_RB_HEADER_SEC        => nbiot0_rb_header_sec(0)                 ,--: out std_logic_vector(31 downto 0);
        NBIOT0_RB_HEADER_SEC_ACK    => nbiot0_rb_header_sec_ack(0)             ,--: in  std_logic;

        NBIOT0_RB_COMP_HDR          => nbiot0_rb_comp_hdr(0)                   ,--: out std_logic_vector(7 downto 0);

        NBIOT0_RB_VALID             => nbiot0_rb_valid(0)                      ,--: out std_logic;
        NBIOT0_RB_TICK              => nbiot0_rb_tick(0)                       ,--: out std_logic;
        NBIOT0_RB_DATA_I            => nbiot0_rb_data_i(0)                     ,--: out std_logic_vector(15 downto 0);
        NBIOT0_RB_DATA_Q            => nbiot0_rb_data_q(0)                     ,--: out std_logic_vector(15 downto 0);
        NBIOT0_RB_USER              => nbiot0_rb_user(0)                       ,--: out std_logic_vector(15 downto 0);

        NBIOT1_RB_INIT              => nbiot1_rb_init(0)                       ,--: out std_logic;
        NBIOT1_RB_eAxC_ID           => nbiot1_rb_eaxc_id(0)                    ,--: out std_logic_vector(15 downto 0);
        NBIOT1_RB_SEQUENCE_ID       => nbiot1_rb_sequence_id(0)                ,--: out std_logic_vector(15 downto 0);
        NBIOT1_RB_HEADER_APP        => nbiot1_rb_header_app(0)                 ,--: out std_logic_vector(31 downto 0);
        NBIOT1_RB_HEADER_APP_ACK    => nbiot1_rb_header_app_ack(0)             ,--: in  std_logic;
        NBIOT1_RB_HEADER_SEC        => nbiot1_rb_header_sec(0)                 ,--: out std_logic_vector(31 downto 0);
        NBIOT1_RB_HEADER_SEC_ACK    => nbiot1_rb_header_sec_ack(0)             ,--: in  std_logic;

        NBIOT1_RB_COMP_HDR          => nbiot1_rb_comp_hdr(0)                   ,--: out std_logic_vector(7 downto 0);

        NBIOT1_RB_VALID             => nbiot1_rb_valid(0)                      ,--: out std_logic;
        NBIOT1_RB_TICK              => nbiot1_rb_tick(0)                       ,--: out std_logic;
        NBIOT1_RB_DATA_I            => nbiot1_rb_data_i(0)                     ,--: out std_logic_vector(15 downto 0);
        NBIOT1_RB_DATA_Q            => nbiot1_rb_data_q(0)                     ,--: out std_logic_vector(15 downto 0);
        NBIOT1_RB_USER              => nbiot1_rb_user(0)                       ,--: out std_logic_vector(15 downto 0);

        NBIOT2_RB_INIT              => nbiot2_rb_init(0)                       ,--: out std_logic;
        NBIOT2_RB_eAxC_ID           => nbiot2_rb_eaxc_id(0)                    ,--: out std_logic_vector(15 downto 0);
        NBIOT2_RB_SEQUENCE_ID       => nbiot2_rb_sequence_id(0)                ,--: out std_logic_vector(15 downto 0);
        NBIOT2_RB_HEADER_APP        => nbiot2_rb_header_app(0)                 ,--: out std_logic_vector(31 downto 0);
        NBIOT2_RB_HEADER_APP_ACK    => nbiot2_rb_header_app_ack(0)             ,--: in  std_logic;
        NBIOT2_RB_HEADER_SEC        => nbiot2_rb_header_sec(0)                 ,--: out std_logic_vector(31 downto 0);
        NBIOT2_RB_HEADER_SEC_ACK    => nbiot2_rb_header_sec_ack(0)             ,--: in  std_logic;

        NBIOT2_RB_COMP_HDR          => nbiot2_rb_comp_hdr(0)                   ,--: out std_logic_vector(7 downto 0);

        NBIOT2_RB_VALID             => nbiot2_rb_valid(0)                      ,--: out std_logic;
        NBIOT2_RB_TICK              => nbiot2_rb_tick(0)                       ,--: out std_logic;
        NBIOT2_RB_DATA_I            => nbiot2_rb_data_i(0)                     ,--: out std_logic_vector(15 downto 0);
        NBIOT2_RB_DATA_Q            => nbiot2_rb_data_q(0)                     ,--: out std_logic_vector(15 downto 0);
        NBIOT2_RB_USER              => nbiot2_rb_user(0)                        --: out std_logic_vector(15 downto 0)
    );

    u_FRAMER_PUxCH0 : O_RAN_FRAMER
    generic map(
        USAGE_C_PLANE               => false                                   ,--: boolean := true;
        USAGE_U_PLANE               => true                                     --: boolean := true
    )
    port map(
        RST                         => ARESET_TX(0)                            ,--: in  std_logic;

        CLK_MAC                     => CLK_MAC_TX                              ,--: in  std_logic;
        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

        TX_PARAM_DST_MAC            => ul_param_dst_mac(0)                     ,--: in  std_logic_vector(47 downto 0);
        TX_PARAM_SRC_MAC            => ul_param_src_mac(0)                     ,--: in  std_logic_vector(47 downto 0);
        TX_PARAM_VLAN0_MODE         => ul_param_vlan0_mode(0)                  ,--: in  std_logic;
        TX_PARAM_VLAN0_TCI          => ul_param_vlan0_tci(0)                   ,--: in  std_logic_vector(15 downto 0);
        TX_PARAM_VLAN1_MODE         => ul_param_vlan1_mode(0)                  ,--: in  std_logic;
        TX_PARAM_VLAN1_TCI          => ul_param_vlan1_tci(0)                   ,--: in  std_logic_vector(15 downto 0);

        TX_COMP_MODE                => ul_comp_mode(0)                         ,--: in  std_logic;
        TX_COMP_EXP_OFFSET          => ul_comp_exp_offset(0)                   ,--: in  std_logic_vector(4 downto 0);
        TX_COMP_GAIN_OFFSET         => ul_comp_gain_offset(0)                  ,--: in  std_logic_vector(10 downto 0);
        TX_COMP_SCALE_GAIN_OFFSET   => ul_comp_scale_gain_offset(0)            ,--: in  std_logic_vector(3 downto 0);

        USAGE_TX_DATA_BUFFER        => ul_puxch_u_plane_buffer(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_TX_C_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);
        USAGE_TX_U_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);

        TX_C_PLANE                  => open                                    ,--: out std_logic_vector(31 downto 0);
        TX_C_PLANE_LOST             => open                                    ,--: out std_logic_vector(31 downto 0);
        TX_U_PLANE                  => ul_puxch_u_plane(0)                     ,--: out std_logic_vector(31 downto 0);
        TX_U_PLANE_LOST             => ul_puxch_u_plane_lost(0)                ,--: out std_logic_vector(31 downto 0);

        MAC_TX_READY                => framer_tx_ready(0)                      ,--: in  std_logic;
        MAC_TX_VALID                => framer_tx_valid(0)                      ,--: out std_logic;
        MAC_TX_LAST                 => framer_tx_last(0)                       ,--: out std_logic;
        MAC_TX_KEEP                 => framer_tx_keep(0)                       ,--: out std_logic_vector(7 downto 0);
        MAC_TX_DATA                 => framer_tx_data(0)                       ,--: out std_logic_vector(63 downto 0);

        RB_INIT                     => puxch_rb_init(0)                        ,--: in  std_logic;
        RB_eAxC_ID                  => puxch_rb_eaxc_id(0)                     ,--: in  std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              => puxch_rb_sequence_id(0)                 ,--: in  std_logic_vector(15 downto 0);
        RB_HEADER_APP               => puxch_rb_header_app(0)                  ,--: in  std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           => puxch_rb_header_app_ack(0)              ,--: out std_logic;
        RB_HEADER_SEC               => puxch_rb_header_sec(0)                  ,--: in  std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           => puxch_rb_header_sec_ack(0)              ,--: out std_logic;

        RB_COMP_HDR                 => puxch_rb_comp_hdr(0)                    ,--: in  std_logic_vector(7 downto 0);

        RB_VALID                    => puxch_rb_valid(0)                       ,--: in  std_logic;
        RB_START                    => '0'                                     ,--: in  std_logic;
        RB_TICK                     => puxch_rb_tick(0)                        ,--: in  std_logic;
        RB_LAST                     => '0'                                     ,--: in  std_logic;
        RB_DATA_I                   => puxch_rb_data_i(0)                      ,--: in  std_logic_vector(15 downto 0);
        RB_DATA_Q                   => puxch_rb_data_q(0)                      ,--: in  std_logic_vector(15 downto 0);
        RB_USER                     => puxch_rb_user(0)                         --: in  std_logic_vector(15 downto 0)
    );

    u_FRAMER_PRACH0 : O_RAN_FRAMER
    generic map(
        USAGE_C_PLANE               => false                                   ,--: boolean := true;
        USAGE_U_PLANE               => true                                     --: boolean := true
    )
    port map(
        RST                         => ARESET_TX(0)                            ,--: in  std_logic;

        CLK_MAC                     => CLK_MAC_TX                              ,--: in  std_logic;
        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

        TX_PARAM_DST_MAC            => ul_param_dst_mac(0)                     ,--: in  std_logic_vector(47 downto 0);
        TX_PARAM_SRC_MAC            => ul_param_src_mac(0)                     ,--: in  std_logic_vector(47 downto 0);
        TX_PARAM_VLAN0_MODE         => ul_param_vlan0_mode(0)                  ,--: in  std_logic;
        TX_PARAM_VLAN0_TCI          => ul_param_vlan0_tci(0)                   ,--: in  std_logic_vector(15 downto 0);
        TX_PARAM_VLAN1_MODE         => ul_param_vlan1_mode(0)                  ,--: in  std_logic;
        TX_PARAM_VLAN1_TCI          => ul_param_vlan1_tci(0)                   ,--: in  std_logic_vector(15 downto 0);

        TX_COMP_MODE                => ul_comp_mode(0)                         ,--: in  std_logic;
        TX_COMP_EXP_OFFSET          => ul_comp_exp_offset(0)                   ,--: in  std_logic_vector(4 downto 0);
        TX_COMP_GAIN_OFFSET         => ul_comp_gain_offset(0)                  ,--: in  std_logic_vector(10 downto 0);
        TX_COMP_SCALE_GAIN_OFFSET   => ul_comp_scale_gain_offset(0)            ,--: in  std_logic_vector(3 downto 0);

        USAGE_TX_DATA_BUFFER        => ul_prach_u_plane_buffer(0)              ,--: out std_logic_vector(31 downto 0);
        USAGE_TX_C_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);
        USAGE_TX_U_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);

        TX_C_PLANE                  => open                                    ,--: out std_logic_vector(31 downto 0);
        TX_C_PLANE_LOST             => open                                    ,--: out std_logic_vector(31 downto 0);
        TX_U_PLANE                  => ul_prach_u_plane(0)                     ,--: out std_logic_vector(31 downto 0);
        TX_U_PLANE_LOST             => ul_prach_u_plane_lost(0)                ,--: out std_logic_vector(31 downto 0);

        MAC_TX_READY                => framer_tx_ready(1)                      ,--: in  std_logic;
        MAC_TX_VALID                => framer_tx_valid(1)                      ,--: out std_logic;
        MAC_TX_LAST                 => framer_tx_last(1)                       ,--: out std_logic;
        MAC_TX_KEEP                 => framer_tx_keep(1)                       ,--: out std_logic_vector(7 downto 0);
        MAC_TX_DATA                 => framer_tx_data(1)                       ,--: out std_logic_vector(63 downto 0);

        RB_INIT                     => prach_rb_init(0)                        ,--: in  std_logic;
        RB_eAxC_ID                  => prach_rb_eaxc_id(0)                     ,--: in  std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              => prach_rb_sequence_id(0)                 ,--: in  std_logic_vector(15 downto 0);
        RB_HEADER_APP               => prach_rb_header_app(0)                  ,--: in  std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           => prach_rb_header_app_ack(0)              ,--: out std_logic;
        RB_HEADER_SEC               => prach_rb_header_sec(0)                  ,--: in  std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           => prach_rb_header_sec_ack(0)              ,--: out std_logic;

        RB_COMP_HDR                 => prach_rb_comp_hdr(0)                    ,--: in  std_logic_vector(7 downto 0);

        RB_VALID                    => prach_rb_valid(0)                       ,--: in  std_logic;
        RB_START                    => '0'                                     ,--: in  std_logic;
        RB_TICK                     => prach_rb_tick(0)                        ,--: in  std_logic;
        RB_LAST                     => '0'                                     ,--: in  std_logic;
        RB_DATA_I                   => prach_rb_data_i(0)                      ,--: in  std_logic_vector(15 downto 0);
        RB_DATA_Q                   => prach_rb_data_q(0)                      ,--: in  std_logic_vector(15 downto 0);
        RB_USER                     => prach_rb_user(0)                         --: in  std_logic_vector(15 downto 0)
    );
    
        framer_tx_valid(2)  <= '0';
        framer_tx_last (2)  <= '0';
        framer_tx_keep (2)  <= (others => '0');
        framer_tx_data (2)  <= (others => '0');
        
        framer_tx_valid(3)  <= '0';
        framer_tx_last (3)  <= '0';
        framer_tx_keep (3)  <= (others => '0');
        framer_tx_data (3)  <= (others => '0');
        
        framer_tx_valid(4)  <= '0';
        framer_tx_last (4)  <= '0';
        framer_tx_keep (4)  <= (others => '0');
        framer_tx_data (4)  <= (others => '0');
        
        framer_tx_valid(5)  <= '0';
        framer_tx_last (5)  <= '0';
        framer_tx_keep (5)  <= (others => '0');
        framer_tx_data (5)  <= (others => '0');

--    u_FRAMER_eMTC : O_RAN_FRAMER
--    generic map(
--        USAGE_C_PLANE               => false                                   ,--: boolean := true;
--        USAGE_U_PLANE               => true                                     --: boolean := true
--    )
--    port map(
--        RST                         => ARESET_TX(0)                            ,--: in  std_logic;

--        CLK_MAC                     => CLK_MAC_TX                              ,--: in  std_logic;
--        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

--        TX_PARAM_DST_MAC            => ul_param_dst_mac(0)                     ,--: in  std_logic_vector(47 downto 0);
--        TX_PARAM_SRC_MAC            => ul_param_src_mac(0)                     ,--: in  std_logic_vector(47 downto 0);
--        TX_PARAM_VLAN0_MODE         => ul_param_vlan0_mode(0)                  ,--: in  std_logic;
--        TX_PARAM_VLAN0_TCI          => ul_param_vlan0_tci(0)                   ,--: in  std_logic_vector(15 downto 0);
--        TX_PARAM_VLAN1_MODE         => ul_param_vlan1_mode(0)                  ,--: in  std_logic;
--        TX_PARAM_VLAN1_TCI          => ul_param_vlan1_tci(0)                   ,--: in  std_logic_vector(15 downto 0);

--        TX_COMP_MODE                => ul_comp_mode(0)                         ,--: in  std_logic;
--        TX_COMP_EXP_OFFSET          => ul_comp_exp_offset(0)                   ,--: in  std_logic_vector(4 downto 0);
--        TX_COMP_GAIN_OFFSET         => ul_comp_gain_offset(0)                  ,--: in  std_logic_vector(10 downto 0);
--        TX_COMP_SCALE_GAIN_OFFSET   => ul_comp_scale_gain_offset(0)            ,--: in  std_logic_vector(3 downto 0);

--        USAGE_TX_DATA_BUFFER        => ul_emtc_u_plane_buffer(0)               ,--: out std_logic_vector(31 downto 0);
--        USAGE_TX_C_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);
--        USAGE_TX_U_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);

--        TX_C_PLANE                  => open                                    ,--: out std_logic_vector(31 downto 0);
--        TX_C_PLANE_LOST             => open                                    ,--: out std_logic_vector(31 downto 0);
--        TX_U_PLANE                  => ul_emtc_u_plane(0)                      ,--: out std_logic_vector(31 downto 0);
--        TX_U_PLANE_LOST             => ul_emtc_u_plane_lost(0)                 ,--: out std_logic_vector(31 downto 0);

--        MAC_TX_READY                => framer_tx_ready(2)                      ,--: in  std_logic;
--        MAC_TX_VALID                => framer_tx_valid(2)                      ,--: out std_logic;
--        MAC_TX_LAST                 => framer_tx_last(2)                       ,--: out std_logic;
--        MAC_TX_KEEP                 => framer_tx_keep(2)                       ,--: out std_logic_vector(7 downto 0);
--        MAC_TX_DATA                 => framer_tx_data(2)                       ,--: out std_logic_vector(63 downto 0);

--        RB_INIT                     => emtc_rb_init(0)                         ,--: in  std_logic;
--        RB_eAxC_ID                  => emtc_rb_eaxc_id(0)                      ,--: in  std_logic_vector(15 downto 0);
--        RB_SEQUENCE_ID              => emtc_rb_sequence_id(0)                  ,--: in  std_logic_vector(15 downto 0);
--        RB_HEADER_APP               => emtc_rb_header_app(0)                   ,--: in  std_logic_vector(31 downto 0);
--        RB_HEADER_APP_ACK           => emtc_rb_header_app_ack(0)               ,--: out std_logic;
--        RB_HEADER_SEC               => emtc_rb_header_sec(0)                   ,--: in  std_logic_vector(31 downto 0);
--        RB_HEADER_SEC_ACK           => emtc_rb_header_sec_ack(0)               ,--: out std_logic;

--        RB_COMP_HDR                 => emtc_rb_comp_hdr(0)                     ,--: in  std_logic_vector(7 downto 0);

--        RB_VALID                    => emtc_rb_valid(0)                        ,--: in  std_logic;
--        RB_START                    => '0'                                     ,--: in  std_logic;
--        RB_TICK                     => emtc_rb_tick(0)                         ,--: in  std_logic;
--        RB_LAST                     => '0'                                     ,--: in  std_logic;
--        RB_DATA_I                   => emtc_rb_data_i(0)                       ,--: in  std_logic_vector(15 downto 0);
--        RB_DATA_Q                   => emtc_rb_data_q(0)                       ,--: in  std_logic_vector(15 downto 0);
--        RB_USER                     => emtc_rb_user(0)                          --: in  std_logic_vector(15 downto 0)
--    );

--    u_FRAMER_NBIOT0 : O_RAN_FRAMER
--    generic map(
--        USAGE_C_PLANE               => false                                   ,--: boolean := true;
--        USAGE_U_PLANE               => true                                     --: boolean := true
--    )
--    port map(
--        RST                         => ARESET_TX(0)                            ,--: in  std_logic;

--        CLK_MAC                     => CLK_MAC_TX                              ,--: in  std_logic;
--        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

--        TX_PARAM_DST_MAC            => ul_param_dst_mac(0)                     ,--: in  std_logic_vector(47 downto 0);
--        TX_PARAM_SRC_MAC            => ul_param_src_mac(0)                     ,--: in  std_logic_vector(47 downto 0);
--        TX_PARAM_VLAN0_MODE         => ul_param_vlan0_mode(0)                  ,--: in  std_logic;
--        TX_PARAM_VLAN0_TCI          => ul_param_vlan0_tci(0)                   ,--: in  std_logic_vector(15 downto 0);
--        TX_PARAM_VLAN1_MODE         => ul_param_vlan1_mode(0)                  ,--: in  std_logic;
--        TX_PARAM_VLAN1_TCI          => ul_param_vlan1_tci(0)                   ,--: in  std_logic_vector(15 downto 0);

--        TX_COMP_MODE                => ul_comp_mode(0)                         ,--: in  std_logic;
--        TX_COMP_EXP_OFFSET          => ul_comp_exp_offset(0)                   ,--: in  std_logic_vector(4 downto 0);
--        TX_COMP_GAIN_OFFSET         => ul_comp_gain_offset(0)                  ,--: in  std_logic_vector(10 downto 0);
--        TX_COMP_SCALE_GAIN_OFFSET   => ul_comp_scale_gain_offset(0)            ,--: in  std_logic_vector(3 downto 0);

--        USAGE_TX_DATA_BUFFER        => ul_nbiot0_u_plane_buffer(0)             ,--: out std_logic_vector(31 downto 0);
--        USAGE_TX_C_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);
--        USAGE_TX_U_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);

--        TX_C_PLANE                  => open                                    ,--: out std_logic_vector(31 downto 0);
--        TX_C_PLANE_LOST             => open                                    ,--: out std_logic_vector(31 downto 0);
--        TX_U_PLANE                  => ul_nbiot0_u_plane(0)                    ,--: out std_logic_vector(31 downto 0);
--        TX_U_PLANE_LOST             => ul_nbiot0_u_plane_lost(0)               ,--: out std_logic_vector(31 downto 0);

--        MAC_TX_READY                => framer_tx_ready(3)                      ,--: in  std_logic;
--        MAC_TX_VALID                => framer_tx_valid(3)                      ,--: out std_logic;
--        MAC_TX_LAST                 => framer_tx_last(3)                       ,--: out std_logic;
--        MAC_TX_KEEP                 => framer_tx_keep(3)                       ,--: out std_logic_vector(7 downto 0);
--        MAC_TX_DATA                 => framer_tx_data(3)                       ,--: out std_logic_vector(63 downto 0);

--        RB_INIT                     => nbiot0_rb_init(0)                       ,--: in  std_logic;
--        RB_eAxC_ID                  => nbiot0_rb_eaxc_id(0)                    ,--: in  std_logic_vector(15 downto 0);
--        RB_SEQUENCE_ID              => nbiot0_rb_sequence_id(0)                ,--: in  std_logic_vector(15 downto 0);
--        RB_HEADER_APP               => nbiot0_rb_header_app(0)                 ,--: in  std_logic_vector(31 downto 0);
--        RB_HEADER_APP_ACK           => nbiot0_rb_header_app_ack(0)             ,--: out std_logic;
--        RB_HEADER_SEC               => nbiot0_rb_header_sec(0)                 ,--: in  std_logic_vector(31 downto 0);
--        RB_HEADER_SEC_ACK           => nbiot0_rb_header_sec_ack(0)             ,--: out std_logic;

--        RB_COMP_HDR                 => nbiot0_rb_comp_hdr(0)                   ,--: in  std_logic_vector(7 downto 0);

--        RB_VALID                    => nbiot0_rb_valid(0)                      ,--: in  std_logic;
--        RB_START                    => '0'                                     ,--: in  std_logic;
--        RB_TICK                     => nbiot0_rb_tick(0)                       ,--: in  std_logic;
--        RB_LAST                     => '0'                                     ,--: in  std_logic;
--        RB_DATA_I                   => nbiot0_rb_data_i(0)                     ,--: in  std_logic_vector(15 downto 0);
--        RB_DATA_Q                   => nbiot0_rb_data_q(0)                     ,--: in  std_logic_vector(15 downto 0);
--        RB_USER                     => nbiot0_rb_user(0)                        --: in  std_logic_vector(15 downto 0)
--    );

--    u_FRAMER_NBIOT1 : O_RAN_FRAMER
--    generic map(
--        USAGE_C_PLANE               => false                                   ,--: boolean := true;
--        USAGE_U_PLANE               => true                                     --: boolean := true
--    )
--    port map(
--        RST                         => ARESET_TX(0)                            ,--: in  std_logic;

--        CLK_MAC                     => CLK_MAC_TX                              ,--: in  std_logic;
--        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

--        TX_PARAM_DST_MAC            => ul_param_dst_mac(0)                     ,--: in  std_logic_vector(47 downto 0);
--        TX_PARAM_SRC_MAC            => ul_param_src_mac(0)                     ,--: in  std_logic_vector(47 downto 0);
--        TX_PARAM_VLAN0_MODE         => ul_param_vlan0_mode(0)                  ,--: in  std_logic;
--        TX_PARAM_VLAN0_TCI          => ul_param_vlan0_tci(0)                   ,--: in  std_logic_vector(15 downto 0);
--        TX_PARAM_VLAN1_MODE         => ul_param_vlan1_mode(0)                  ,--: in  std_logic;
--        TX_PARAM_VLAN1_TCI          => ul_param_vlan1_tci(0)                   ,--: in  std_logic_vector(15 downto 0);

--        TX_COMP_MODE                => ul_comp_mode(0)                         ,--: in  std_logic;
--        TX_COMP_EXP_OFFSET          => ul_comp_exp_offset(0)                   ,--: in  std_logic_vector(4 downto 0);
--        TX_COMP_GAIN_OFFSET         => ul_comp_gain_offset(0)                  ,--: in  std_logic_vector(10 downto 0);
--        TX_COMP_SCALE_GAIN_OFFSET   => ul_comp_scale_gain_offset(0)            ,--: in  std_logic_vector(3 downto 0);

--        USAGE_TX_DATA_BUFFER        => ul_nbiot1_u_plane_buffer(0)             ,--: out std_logic_vector(31 downto 0);
--        USAGE_TX_C_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);
--        USAGE_TX_U_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);

--        TX_C_PLANE                  => open                                    ,--: out std_logic_vector(31 downto 0);
--        TX_C_PLANE_LOST             => open                                    ,--: out std_logic_vector(31 downto 0);
--        TX_U_PLANE                  => ul_nbiot1_u_plane(0)                    ,--: out std_logic_vector(31 downto 0);
--        TX_U_PLANE_LOST             => ul_nbiot1_u_plane_lost(0)               ,--: out std_logic_vector(31 downto 0);

--        MAC_TX_READY                => framer_tx_ready(4)                      ,--: in  std_logic;
--        MAC_TX_VALID                => framer_tx_valid(4)                      ,--: out std_logic;
--        MAC_TX_LAST                 => framer_tx_last(4)                       ,--: out std_logic;
--        MAC_TX_KEEP                 => framer_tx_keep(4)                       ,--: out std_logic_vector(7 downto 0);
--        MAC_TX_DATA                 => framer_tx_data(4)                       ,--: out std_logic_vector(63 downto 0);

--        RB_INIT                     => nbiot1_rb_init(0)                       ,--: in  std_logic;
--        RB_eAxC_ID                  => nbiot1_rb_eaxc_id(0)                    ,--: in  std_logic_vector(15 downto 0);
--        RB_SEQUENCE_ID              => nbiot1_rb_sequence_id(0)                ,--: in  std_logic_vector(15 downto 0);
--        RB_HEADER_APP               => nbiot1_rb_header_app(0)                 ,--: in  std_logic_vector(31 downto 0);
--        RB_HEADER_APP_ACK           => nbiot1_rb_header_app_ack(0)             ,--: out std_logic;
--        RB_HEADER_SEC               => nbiot1_rb_header_sec(0)                 ,--: in  std_logic_vector(31 downto 0);
--        RB_HEADER_SEC_ACK           => nbiot1_rb_header_sec_ack(0)             ,--: out std_logic;

--        RB_COMP_HDR                 => nbiot1_rb_comp_hdr(0)                   ,--: in  std_logic_vector(7 downto 0);

--        RB_VALID                    => nbiot1_rb_valid(0)                      ,--: in  std_logic;
--        RB_START                    => '0'                                     ,--: in  std_logic;
--        RB_TICK                     => nbiot1_rb_tick(0)                       ,--: in  std_logic;
--        RB_LAST                     => '0'                                     ,--: in  std_logic;
--        RB_DATA_I                   => nbiot1_rb_data_i(0)                     ,--: in  std_logic_vector(15 downto 0);
--        RB_DATA_Q                   => nbiot1_rb_data_q(0)                     ,--: in  std_logic_vector(15 downto 0);
--        RB_USER                     => nbiot1_rb_user(0)                        --: in  std_logic_vector(15 downto 0)
--    );

--    u_FRAMER_NBIOT2 : O_RAN_FRAMER
--    generic map(
--        USAGE_C_PLANE               => false                                   ,--: boolean := true;
--        USAGE_U_PLANE               => true                                     --: boolean := true
--    )
--    port map(
--        RST                         => ARESET_TX(0)                            ,--: in  std_logic;

--        CLK_MAC                     => CLK_MAC_TX                              ,--: in  std_logic;
--        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

--        TX_PARAM_DST_MAC            => ul_param_dst_mac(0)                     ,--: in  std_logic_vector(47 downto 0);
--        TX_PARAM_SRC_MAC            => ul_param_src_mac(0)                     ,--: in  std_logic_vector(47 downto 0);
--        TX_PARAM_VLAN0_MODE         => ul_param_vlan0_mode(0)                  ,--: in  std_logic;
--        TX_PARAM_VLAN0_TCI          => ul_param_vlan0_tci(0)                   ,--: in  std_logic_vector(15 downto 0);
--        TX_PARAM_VLAN1_MODE         => ul_param_vlan1_mode(0)                  ,--: in  std_logic;
--        TX_PARAM_VLAN1_TCI          => ul_param_vlan1_tci(0)                   ,--: in  std_logic_vector(15 downto 0);

--        TX_COMP_MODE                => ul_comp_mode(0)                         ,--: in  std_logic;
--        TX_COMP_EXP_OFFSET          => ul_comp_exp_offset(0)                   ,--: in  std_logic_vector(4 downto 0);
--        TX_COMP_GAIN_OFFSET         => ul_comp_gain_offset(0)                  ,--: in  std_logic_vector(10 downto 0);
--        TX_COMP_SCALE_GAIN_OFFSET   => ul_comp_scale_gain_offset(0)            ,--: in  std_logic_vector(3 downto 0);

--        USAGE_TX_DATA_BUFFER        => ul_nbiot2_u_plane_buffer(0)             ,--: out std_logic_vector(31 downto 0);
--        USAGE_TX_C_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);
--        USAGE_TX_U_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);

--        TX_C_PLANE                  => open                                    ,--: out std_logic_vector(31 downto 0);
--        TX_C_PLANE_LOST             => open                                    ,--: out std_logic_vector(31 downto 0);
--        TX_U_PLANE                  => ul_nbiot2_u_plane(0)                    ,--: out std_logic_vector(31 downto 0);
--        TX_U_PLANE_LOST             => ul_nbiot2_u_plane_lost(0)               ,--: out std_logic_vector(31 downto 0);

--        MAC_TX_READY                => framer_tx_ready(5)                      ,--: in  std_logic;
--        MAC_TX_VALID                => framer_tx_valid(5)                      ,--: out std_logic;
--        MAC_TX_LAST                 => framer_tx_last(5)                       ,--: out std_logic;
--        MAC_TX_KEEP                 => framer_tx_keep(5)                       ,--: out std_logic_vector(7 downto 0);
--        MAC_TX_DATA                 => framer_tx_data(5)                       ,--: out std_logic_vector(63 downto 0);

--        RB_INIT                     => nbiot2_rb_init(0)                       ,--: in  std_logic;
--        RB_eAxC_ID                  => nbiot2_rb_eaxc_id(0)                    ,--: in  std_logic_vector(15 downto 0);
--        RB_SEQUENCE_ID              => nbiot2_rb_sequence_id(0)                ,--: in  std_logic_vector(15 downto 0);
--        RB_HEADER_APP               => nbiot2_rb_header_app(0)                 ,--: in  std_logic_vector(31 downto 0);
--        RB_HEADER_APP_ACK           => nbiot2_rb_header_app_ack(0)             ,--: out std_logic;
--        RB_HEADER_SEC               => nbiot2_rb_header_sec(0)                 ,--: in  std_logic_vector(31 downto 0);
--        RB_HEADER_SEC_ACK           => nbiot2_rb_header_sec_ack(0)             ,--: out std_logic;

--        RB_COMP_HDR                 => nbiot2_rb_comp_hdr(0)                   ,--: in  std_logic_vector(7 downto 0);

--        RB_VALID                    => nbiot2_rb_valid(0)                      ,--: in  std_logic;
--        RB_START                    => '0'                                     ,--: in  std_logic;
--        RB_TICK                     => nbiot2_rb_tick(0)                       ,--: in  std_logic;
--        RB_LAST                     => '0'                                     ,--: in  std_logic;
--        RB_DATA_I                   => nbiot2_rb_data_i(0)                     ,--: in  std_logic_vector(15 downto 0);
--        RB_DATA_Q                   => nbiot2_rb_data_q(0)                     ,--: in  std_logic_vector(15 downto 0);
--        RB_USER                     => nbiot2_rb_user(0)                        --: in  std_logic_vector(15 downto 0)
--    );

    u_MEASUREMENT : for i in DL_UNIT-1 downto 0 generate
    u_MEASUREMENT : MEASUREMENT
    generic map(
        NUM_TX                      => 6                                        --: natural := 1
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => RST_CPUIF                               ,--: in  std_logic;

        CLK_245p76MHz               => CLK_BUS                                 ,--: in  std_logic;

        N_TA_OFFSET                 => N_TA_OFFSET((i+1)*16-1 downto i*16)     ,--: in  std_logic_vector(15 downto 0);

        REF_10msec                  => FRAME_SYNC                              ,--: in  std_logic;
        REF_SFN                     => BFN_NUM_IN(7 downto 0)                  ,--: in  std_logic_vector(7 downto 0);

        CAPTURE_PERIOD              => cp_dl_period(0)                         ,--: in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            => t2a_max_cp_dl(0)                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_CP_RX            => t2a_min_cp_dl(0)                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MAX_DL_UP_RX            => t2a_max_up_dl(0)                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_UP_RX            => t2a_min_up_dl(0)                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MAX_UL_CP_RX            => t2a_max_cp_ul(0)                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MIN_UL_CP_RX            => t2a_min_cp_ul(0)                        ,--: in  std_logic_vector(21 downto 0);

        DL_CP_RX_CNT_CLEAR          => cp_dl_cnt_clear(0)                      ,--: in  std_logic_vector(3 downto 0);
        DL_CP_RX_ON_TIME            => cp_dl_on_time(i)                        ,--: out std_logic_vector(63 downto 0);
        DL_CP_RX_EARLY              => cp_dl_early(i)                          ,--: out std_logic_vector(63 downto 0);
        DL_CP_RX_LATE               => cp_dl_late(i)                           ,--: out std_logic_vector(63 downto 0);
        DL_CP_RX_OUT_OF_RANGE       => open                                    ,--: out std_logic_vector(63 downto 0);

        DL_UP_RX_CNT_CLEAR          => up_dl_cnt_clear(0)                      ,--: in  std_logic_vector(3 downto 0);
        DL_UP_RX_ON_TIME            => up_dl_on_time(i)                        ,--: out std_logic_vector(63 downto 0);
        DL_UP_RX_EARLY              => up_dl_early(i)                          ,--: out std_logic_vector(63 downto 0);
        DL_UP_RX_LATE               => up_dl_late(i)                           ,--: out std_logic_vector(63 downto 0);
        DL_UP_RX_OUT_OF_RANGE       => open                                    ,--: out std_logic_vector(63 downto 0);

        UL_CP_RX_CNT_CLEAR          => cp_ul_cnt_clear(0)                      ,--: in  std_logic_vector(3 downto 0);
        UL_CP_RX_ON_TIME            => cp_ul_on_time(i)                        ,--: out std_logic_vector(63 downto 0);
        UL_CP_RX_EARLY              => cp_ul_early(i)                          ,--: out std_logic_vector(63 downto 0);
        UL_CP_RX_LATE               => cp_ul_late(i)                           ,--: out std_logic_vector(63 downto 0);
        UL_CP_RX_OUT_OF_RANGE       => open                                    ,--: out std_logic_vector(63 downto 0);

        UL_UP_TX_CNT_CLEAR          => ul_up_tx_cnt_clear(0)                   ,--: in  std_logic_vector(7 downto 0);
        UL_UP_TX_TOTAL              => ul_up_tx_total(i)                       ,--: out std_logic_array64(7 downto 0);

        RX_PACKET_CLK               => CLK_MAC_RX                              ,--: in  std_logic;

        RX_PACKET_IS_CP_DL          => rx_packet_is_cp_dl(i)                   ,--: in  std_logic;
        RX_PACKET_IS_CP_UL          => rx_packet_is_cp_ul(i)                   ,--: in  std_logic;
        RX_PACKET_IS_UP_DL          => rx_packet_is_up_dl(i)                   ,--: in  std_logic;
        RX_PACKET_SCS               => rx_packet_scs(i)                        ,--: in  std_logic_vector(3 downto 0);
        RX_PACKET_FRAME_ID          => rx_packet_frame_id(i)                   ,--: in  std_logic_vector(7 downto 0);
        RX_PACKET_SUBFRAME_ID       => rx_packet_subframe_id(i)                ,--: in  std_logic_vector(3 downto 0);
        RX_PACKET_SLOT_ID           => rx_packet_slot_id(i)                    ,--: in  std_logic_vector(5 downto 0);
        RX_PACKET_SYMBOL_ID         => rx_packet_symbol_id(i)                  ,--: in  std_logic_vector(5 downto 0);

        TX_PACKET_CLK               => CLK_MAC_TX                              ,--: in  std_logic;

        TX_PACKET_EXIST             => pe0_transmitted(i)                       --: in  std_logic_vector(NUM_PORT_TX-1 downto 0)
    );
    end generate;

    ul_up_tx_cnt_clear(0)(0)        <= up0_ul_cnt_clear(0)(0);
    ul_up_tx_cnt_clear(0)(1)        <= up1_ul_cnt_clear(0)(0);
    ul_up_tx_cnt_clear(0)(2)        <= up2_ul_cnt_clear(0)(0);
    ul_up_tx_cnt_clear(0)(3)        <= up3_ul_cnt_clear(0)(0);
    ul_up_tx_cnt_clear(0)(4)        <= up4_ul_cnt_clear(0)(0);
    ul_up_tx_cnt_clear(0)(5)        <= up5_ul_cnt_clear(0)(0);

    up0_ul_on_time(0)               <= ul_up_tx_total(0)(0);
    up1_ul_on_time(0)               <= ul_up_tx_total(0)(1);
    up2_ul_on_time(0)               <= ul_up_tx_total(0)(2);
    up3_ul_on_time(0)               <= ul_up_tx_total(0)(3);
    up4_ul_on_time(0)               <= ul_up_tx_total(0)(4);
    up5_ul_on_time(0)               <= ul_up_tx_total(0)(5);

    process (CLK_MAC_TX)
    begin
        if (CLK_MAC_TX'event and CLK_MAC_TX = '1') then
            pe0_transmitted(0)(0) <= framer_tx_ready(0) and framer_tx_valid(0) and framer_tx_last(0);
            pe0_transmitted(0)(1) <= framer_tx_ready(1) and framer_tx_valid(1) and framer_tx_last(1);
            pe0_transmitted(0)(2) <= framer_tx_ready(2) and framer_tx_valid(2) and framer_tx_last(2);
            pe0_transmitted(0)(3) <= framer_tx_ready(3) and framer_tx_valid(3) and framer_tx_last(3);
            pe0_transmitted(0)(4) <= framer_tx_ready(4) and framer_tx_valid(4) and framer_tx_last(4);
            pe0_transmitted(0)(5) <= framer_tx_ready(5) and framer_tx_valid(5) and framer_tx_last(5);
        end if;
    end process;

    sum_cp_dl_on_time(0)            <= cp_dl_on_time(0);
    sum_cp_dl_early(0)              <= cp_dl_early(0);
    sum_cp_dl_late(0)               <= cp_dl_late(0);

    sum_up_dl_on_time(0)            <= up_dl_on_time(0);
    sum_up_dl_early(0)              <= up_dl_early(0);
    sum_up_dl_late(0)               <= up_dl_late(0);

    sum_cp_ul_on_time(0)            <= cp_ul_on_time(0);
    sum_cp_ul_early(0)              <= cp_ul_early(0);
    sum_cp_ul_late(0)               <= cp_ul_late(0);

--------------------------------------------------------------------------------
-- UL mux
--------------------------------------------------------------------------------

    u_FRAMER_INTERCONNECT : O_RAN_FRAMER_INTERCONNECT
    generic map(
        NUM_PORT                    => 6                                        --: natural := 8
    )
    port map(
        CLK                         => CLK_MAC_TX                              ,--: in  std_logic;
        RST                         => ARESET_TX(0)                            ,--: in  std_logic;

        FRAMER_TX_TREADY            => framer_tx_ready                         ,--: out std_logic_vector(NUM_PORT-1 downto 0);
        FRAMER_TX_TVALID            => framer_tx_valid                         ,--: in  std_logic_vector(NUM_PORT-1 downto 0);
        FRAMER_TX_TLAST             => framer_tx_last                          ,--: in  std_logic_vector(NUM_PORT-1 downto 0);
        FRAMER_TX_TKEEP             => framer_tx_keep                          ,--: in  std_logic_array8(NUM_PORT-1 downto 0);
        FRAMER_TX_TDATA             => framer_tx_data                          ,--: in  std_logic_array64(NUM_PORT-1 downto 0);

        UL_TREADY                   => mac_tx_ready(0)                         ,--: in  std_logic;
        UL_TVALID                   => mac_tx_valid(0)                         ,--: out std_logic;
        UL_TLAST                    => mac_tx_last(0)                          ,--: out std_logic;
        UL_TKEEP                    => mac_tx_keep(0)                          ,--: out std_logic_vector(7 downto 0);
        UL_TDATA                    => mac_tx_data(0)                           --: out std_logic_vector(63 downto 0)
    );

--------------------------------------------------------------------------------
-- MPI
--------------------------------------------------------------------------------

    u_MPI : O_RAN_MPI
    generic map(
        OFFSET                      => OFFSET                                  ,--: std_logic_vector(3 downto 0) := x"3";
        DL_UNIT                     => DL_UNIT                                 ,--: natural := 6;
        UL_UNIT                     => UL_UNIT                                 ,--: natural := 6;
        MAX_CH_PER_UNIT             => MAX_CH_PER_UNIT                         ,--: natural := 2;
        MAX_ID_PER_CH               => MAX_ID_PER_CH                            --: natural := 1
    )
    port map(
        CLK                         => CLK_CPUIF                               ,--: in  std_logic;
        RST                         => RST_CPUIF                               ,--: in  std_logic;

        CLK_MAC_RX                  => CLK_MAC_RX                              ,--: in  std_logic;
        CLK_MAC_TX                  => CLK_MAC_TX                              ,--: in  std_logic;
        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

        IGNORE_FRAME_ID             => ignore_frame_id                         ,--: out std_logic_vector(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PUxCH_RX    => ignore_frame_id_puxch_rx                ,--: in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    => ignore_frame_id_puxch_tx                ,--: in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH0_RX   => ignore_frame_id_prach0_rx               ,--: in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH0_TX   => ignore_frame_id_prach0_tx               ,--: in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH1_RX   => ignore_frame_id_prach1_rx               ,--: in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH1_TX   => ignore_frame_id_prach1_tx               ,--: in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT0_RX   => ignore_frame_id_nbiot0_rx               ,--: in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT0_TX   => ignore_frame_id_nbiot0_tx               ,--: in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT1_RX   => ignore_frame_id_nbiot1_rx               ,--: in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT1_TX   => ignore_frame_id_nbiot1_tx               ,--: in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT2_RX   => ignore_frame_id_nbiot2_rx               ,--: in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT2_TX   => ignore_frame_id_nbiot2_tx               ,--: in  std_logic_array8(UL_UNIT-1 downto 0);

        DL_PARAM_MAC                => dl_param_mac                            ,--: out std_logic_array48(DL_UNIT-1 downto 0);
        DL_PARAM_ID0_EN             => dl_param_id0_en                         ,--: out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID0                => dl_param_id0                            ,--: out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID1_EN             => dl_param_id1_en                         ,--: out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID1                => dl_param_id1                            ,--: out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID2_EN             => dl_param_id2_en                         ,--: out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID2                => dl_param_id2                            ,--: out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID3_EN             => dl_param_id3_en                         ,--: out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID3                => dl_param_id3                            ,--: out std_logic_array8_array16(DL_UNIT-1 downto 0);

        DL_COMP_MODE                => dl_comp_mode                            ,--: out std_logic_vector(DL_UNIT-1 downto 0);
        DL_IQ_WIDTH                 => dl_iq_width                             ,--: out std_logic_array4(DL_UNIT-1 downto 0);
        DL_COMP_METHOD              => dl_comp_method                          ,--: out std_logic_array4(DL_UNIT-1 downto 0);
        DL_SCS_CONFIG               => dl_scs_config                           ,--: out std_logic_array4(DL_UNIT-1 downto 0);
        DL_FFT_SIZE                 => dl_fft_size                             ,--: out std_logic_array4(DL_UNIT-1 downto 0);
        DL_PRB_PER_SYMBOL           => dl_prb_per_symbol                       ,--: out std_logic_array10(DL_UNIT-1 downto 0);
        DL_COMP_EXP_OFFSET          => dl_comp_exp_offset                      ,--: out std_logic_array5(DL_UNIT-1 downto 0);

        UL_PARAM_DST_MAC            => ul_param_dst_mac                        ,--: out std_logic_array48(UL_UNIT-1 downto 0);
        UL_PARAM_SRC_MAC            => ul_param_src_mac                        ,--: out std_logic_array48(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN0_MODE         => ul_param_vlan0_mode                     ,--: out std_logic_vector(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN0_TCI          => ul_param_vlan0_tci                      ,--: out std_logic_array16(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN1_MODE         => ul_param_vlan1_mode                     ,--: out std_logic_vector(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN1_TCI          => ul_param_vlan1_tci                      ,--: out std_logic_array16(UL_UNIT-1 downto 0);

        UL_COMP_MODE                => ul_comp_mode                            ,--: out std_logic_vector(UL_UNIT-1 downto 0);
        UL_IQ_WIDTH                 => ul_iq_width                             ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UL_COMP_METHOD              => ul_comp_method                          ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UL_SCS_CONFIG               => ul_scs_config                           ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UL_FFT_SIZE                 => ul_fft_size                             ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UL_PRB_PER_MTU              => ul_prb_per_mtu                          ,--: out std_logic_array10(UL_UNIT-1 downto 0);
        UL_PRB_PER_SYMBOL           => ul_prb_per_symbol                       ,--: out std_logic_array10(UL_UNIT-1 downto 0);
        UL_COMP_EXP_OFFSET          => ul_comp_exp_offset                      ,--: out std_logic_array5(UL_UNIT-1 downto 0);
        UL_COMP_GAIN_OFFSET         => ul_comp_gain_offset                     ,--: out std_logic_array11(UL_UNIT-1 downto 0);
        UL_COMP_SCALE_GAIN_OFFSET   => ul_comp_scale_gain_offset               ,--: out std_logic_array4(UL_UNIT-1 downto 0);

        T2A_MAX_CP_DL               => t2a_max_cp_dl                           ,--: out std_logic_array22(DL_UNIT-1 downto 0);
        T2A_MIN_CP_DL               => t2a_min_cp_dl                           ,--: out std_logic_array22(DL_UNIT-1 downto 0);
        CP_DL_PERIOD                => cp_dl_period                            ,--: out std_logic_array8(DL_UNIT-1 downto 0);

        CP_DL_CNT_CLEAR             => cp_dl_cnt_clear                         ,--: out std_logic_array4(DL_UNIT-1 downto 0);
        CP_DL_ON_TIME               => sum_cp_dl_on_time                       ,--: in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_EARLY                 => sum_cp_dl_early                         ,--: in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_LATE                  => sum_cp_dl_late                          ,--: in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_OUT_OF_RANGE          => (others => (others => '0'))             ,--: in  std_logic_array64(DL_UNIT-1 downto 0);

        T2A_MAX_UP_DL               => t2a_max_up_dl                           ,--: out std_logic_array22(DL_UNIT-1 downto 0);
        T2A_MIN_UP_DL               => t2a_min_up_dl                           ,--: out std_logic_array22(DL_UNIT-1 downto 0);
        UP_DL_PERIOD                => open                                    ,--: out std_logic_array8(DL_UNIT-1 downto 0);

        UP_DL_CNT_CLEAR             => up_dl_cnt_clear                         ,--: out std_logic_array4(DL_UNIT-1 downto 0);
        UP_DL_ON_TIME               => sum_up_dl_on_time                       ,--: in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_EARLY                 => sum_up_dl_early                         ,--: in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_LATE                  => sum_up_dl_late                          ,--: in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_OUT_OF_RANGE          => (others => (others => '0'))             ,--: in  std_logic_array64(DL_UNIT-1 downto 0);

        T2A_MAX_CP_UL               => t2a_max_cp_ul                           ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        T2A_MIN_CP_UL               => t2a_min_cp_ul                           ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        CP_UL_PERIOD                => open                                    ,--: out std_logic_array8(UL_UNIT-1 downto 0);

        CP_UL_CNT_CLEAR             => cp_ul_cnt_clear                         ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        CP_UL_ON_TIME               => sum_cp_ul_on_time                       ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_EARLY                 => sum_cp_ul_early                         ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_LATE                  => sum_cp_ul_late                          ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_OUT_OF_RANGE          => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP0_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP0_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        UP0_UL_PERIOD               => open                                    ,--: out std_logic_array8(UL_UNIT-1 downto 0);

        UP0_UL_CNT_CLEAR            => up0_ul_cnt_clear                        ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UP0_UL_ON_TIME              => up0_ul_on_time                          ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_EARLY                => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_LATE                 => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_OUT_OF_RANGE         => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP1_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP1_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        UP1_UL_PERIOD               => open                                    ,--: out std_logic_array8(UL_UNIT-1 downto 0);

        UP1_UL_CNT_CLEAR            => up1_ul_cnt_clear                        ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UP1_UL_ON_TIME              => up1_ul_on_time                          ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_EARLY                => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_LATE                 => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_OUT_OF_RANGE         => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP2_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP2_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        UP2_UL_PERIOD               => open                                    ,--: out std_logic_array8(UL_UNIT-1 downto 0);

        UP2_UL_CNT_CLEAR            => up2_ul_cnt_clear                        ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UP2_UL_ON_TIME              => up2_ul_on_time                          ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP2_UL_EARLY                => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP2_UL_LATE                 => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP2_UL_OUT_OF_RANGE         => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP3_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP3_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        UP3_UL_PERIOD               => open                                    ,--: out std_logic_array8(UL_UNIT-1 downto 0);

        UP3_UL_CNT_CLEAR            => up3_ul_cnt_clear                        ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UP3_UL_ON_TIME              => up3_ul_on_time                          ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP3_UL_EARLY                => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP3_UL_LATE                 => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP3_UL_OUT_OF_RANGE         => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP4_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP4_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        UP4_UL_PERIOD               => open                                    ,--: out std_logic_array8(UL_UNIT-1 downto 0);

        UP4_UL_CNT_CLEAR            => up4_ul_cnt_clear                        ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UP4_UL_ON_TIME              => up4_ul_on_time                          ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP4_UL_EARLY                => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP4_UL_LATE                 => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP4_UL_OUT_OF_RANGE         => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP5_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP5_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        UP5_UL_PERIOD               => open                                    ,--: out std_logic_array8(UL_UNIT-1 downto 0);

        UP5_UL_CNT_CLEAR            => up5_ul_cnt_clear                        ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UP5_UL_ON_TIME              => up5_ul_on_time                          ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP5_UL_EARLY                => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP5_UL_LATE                 => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP5_UL_OUT_OF_RANGE         => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);

        DL_C_PLANE_BUFFER           => dl_data_buffer                          ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_BUFFER           => dl_data_buffer                          ,--: in  std_logic_array32(DL_UNIT-1 downto 0);

        DL_INVALID_DST_MAC          => dl_invalid_dst_mac                      ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ETHERTYPE        => dl_invalid_ethertype                    ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriVersion     => dl_invalid_ecpriversion                 ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriC           => dl_invalid_ecpric                       ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriMessage     => dl_invalid_ecprimessage                 ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_C_PLANE                  => dl_c_plane                              ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_C_PLANE_DROPPED          => dl_c_plane_dropped                      ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE                  => dl_u_plane                              ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_DROPPED          => dl_u_plane_dropped                      ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_LOST                     => dl_lost                                 ,--: in  std_logic_array32(DL_UNIT-1 downto 0);

        DL_C_PLANE_EXIST            => dl_c_plane_exist                        ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_EXIST            => dl_u_plane_exist                        ,--: in  std_logic_array32(DL_UNIT-1 downto 0);

        RX_FAULT_ID_31_CH0          => rx_fault_id_31_ch0                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH1          => rx_fault_id_31_ch1                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH2          => rx_fault_id_31_ch2                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH3          => rx_fault_id_31_ch3                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH4          => rx_fault_id_31_ch4                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH5          => rx_fault_id_31_ch5                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH6          => rx_fault_id_31_ch6                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH7          => rx_fault_id_31_ch7                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);

--        UL_PUxCH_C_PLANE_BUFFER     => ul_puxch_c_plane_buffer                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE_BUFFER     => ul_puxch_u_plane_buffer                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PUxCH_C_PLANE            => ul_puxch_c_plane                        ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_PUxCH_C_PLANE_LOST       => ul_puxch_c_plane_lost                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE            => ul_puxch_u_plane                        ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE_LOST       => ul_puxch_u_plane_lost                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PRACH_C_PLANE_BUFFER     => ul_prach_c_plane_buffer                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE_BUFFER     => ul_prach_u_plane_buffer                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PRACH_C_PLANE            => ul_prach_c_plane                        ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_PRACH_C_PLANE_LOST       => ul_prach_c_plane_lost                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE            => ul_prach_u_plane                        ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE_LOST       => ul_prach_u_plane_lost                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_eMTC_C_PLANE_BUFFER      => ul_emtc_c_plane_buffer                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_U_PLANE_BUFFER      => ul_emtc_u_plane_buffer                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_eMTC_C_PLANE             => ul_emtc_c_plane                         ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_eMTC_C_PLANE_LOST        => ul_emtc_c_plane_lost                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_U_PLANE             => ul_emtc_u_plane                         ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_U_PLANE_LOST        => ul_emtc_u_plane_lost                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT0_C_PLANE_BUFFER    => ul_nbiot0_c_plane_buffer                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_U_PLANE_BUFFER    => ul_nbiot0_u_plane_buffer                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT0_C_PLANE           => ul_nbiot0_c_plane                       ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_NBIOT0_C_PLANE_LOST      => ul_nbiot0_c_plane_lost                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_U_PLANE           => ul_nbiot0_u_plane                       ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_U_PLANE_LOST      => ul_nbiot0_u_plane_lost                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT1_C_PLANE_BUFFER    => ul_nbiot1_c_plane_buffer                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_U_PLANE_BUFFER    => ul_nbiot1_u_plane_buffer                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT1_C_PLANE           => ul_nbiot1_c_plane                       ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_NBIOT1_C_PLANE_LOST      => ul_nbiot1_c_plane_lost                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_U_PLANE           => ul_nbiot1_u_plane                       ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_U_PLANE_LOST      => ul_nbiot1_u_plane_lost                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT2_C_PLANE_BUFFER    => ul_nbiot2_c_plane_buffer                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_U_PLANE_BUFFER    => ul_nbiot2_u_plane_buffer                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT2_C_PLANE           => ul_prach2_c_plane                       ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_NBIOT2_C_PLANE_LOST      => ul_nbiot2_c_plane_lost                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_U_PLANE           => ul_nbiot2_u_plane                       ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_U_PLANE_LOST      => ul_nbiot2_u_plane_lost                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_CMD_FIFO_FULL            => ul_cmd_fifo_full                        ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_PUxCH_TERMINATION        => puxch_termination                       ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL0      => puxch_cpsec_symbol0                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL1      => puxch_cpsec_symbol1                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL2      => puxch_cpsec_symbol2                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL3      => puxch_cpsec_symbol3                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL4      => puxch_cpsec_symbol4                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL5      => puxch_cpsec_symbol5                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL6      => puxch_cpsec_symbol6                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL7      => puxch_cpsec_symbol7                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL8      => puxch_cpsec_symbol8                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL9      => puxch_cpsec_symbol9                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL10     => puxch_cpsec_symbol10                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL11     => puxch_cpsec_symbol11                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL12     => puxch_cpsec_symbol12                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL13     => puxch_cpsec_symbol13                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL0      => puxch_uppkt_symbol0                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL1      => puxch_uppkt_symbol1                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL2      => puxch_uppkt_symbol2                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL3      => puxch_uppkt_symbol3                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL4      => puxch_uppkt_symbol4                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL5      => puxch_uppkt_symbol5                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL6      => puxch_uppkt_symbol6                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL7      => puxch_uppkt_symbol7                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL8      => puxch_uppkt_symbol8                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL9      => puxch_uppkt_symbol9                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL10     => puxch_uppkt_symbol10                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL11     => puxch_uppkt_symbol11                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL12     => puxch_uppkt_symbol12                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL13     => puxch_uppkt_symbol13                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL0    => puxch_cq_full_symbol0                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL1    => puxch_cq_full_symbol1                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL2    => puxch_cq_full_symbol2                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL3    => puxch_cq_full_symbol3                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL4    => puxch_cq_full_symbol4                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL5    => puxch_cq_full_symbol5                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL6    => puxch_cq_full_symbol6                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL7    => puxch_cq_full_symbol7                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL8    => puxch_cq_full_symbol8                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL9    => puxch_cq_full_symbol9                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL10   => puxch_cq_full_symbol10                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL11   => puxch_cq_full_symbol11                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL12   => puxch_cq_full_symbol12                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL13   => puxch_cq_full_symbol13                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL0   => usage_puxch_cq_symbol0                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL1   => usage_puxch_cq_symbol1                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL2   => usage_puxch_cq_symbol2                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL3   => usage_puxch_cq_symbol3                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL4   => usage_puxch_cq_symbol4                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL5   => usage_puxch_cq_symbol5                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL6   => usage_puxch_cq_symbol6                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL7   => usage_puxch_cq_symbol7                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL8   => usage_puxch_cq_symbol8                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL9   => usage_puxch_cq_symbol9                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL10  => usage_puxch_cq_symbol10                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL11  => usage_puxch_cq_symbol11                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL12  => usage_puxch_cq_symbol12                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL13  => usage_puxch_cq_symbol13                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_PRACH_TERMINATION        => prach_termination                       ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL0      => prach_cpsec_symbol0                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL1      => prach_cpsec_symbol1                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL2      => prach_cpsec_symbol2                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL3      => prach_cpsec_symbol3                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL4      => prach_cpsec_symbol4                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL5      => prach_cpsec_symbol5                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL6      => prach_cpsec_symbol6                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL7      => prach_cpsec_symbol7                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL8      => prach_cpsec_symbol8                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL9      => prach_cpsec_symbol9                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL10     => prach_cpsec_symbol10                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL11     => prach_cpsec_symbol11                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL12     => prach_cpsec_symbol12                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL13     => prach_cpsec_symbol13                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL0      => prach_uppkt_symbol0                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL1      => prach_uppkt_symbol1                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL2      => prach_uppkt_symbol2                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL3      => prach_uppkt_symbol3                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL4      => prach_uppkt_symbol4                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL5      => prach_uppkt_symbol5                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL6      => prach_uppkt_symbol6                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL7      => prach_uppkt_symbol7                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL8      => prach_uppkt_symbol8                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL9      => prach_uppkt_symbol9                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL10     => prach_uppkt_symbol10                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL11     => prach_uppkt_symbol11                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL12     => prach_uppkt_symbol12                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL13     => prach_uppkt_symbol13                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL0    => prach_cq_full_symbol0                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL1    => prach_cq_full_symbol1                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL2    => prach_cq_full_symbol2                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL3    => prach_cq_full_symbol3                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL4    => prach_cq_full_symbol4                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL5    => prach_cq_full_symbol5                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL6    => prach_cq_full_symbol6                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL7    => prach_cq_full_symbol7                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL8    => prach_cq_full_symbol8                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL9    => prach_cq_full_symbol9                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL10   => prach_cq_full_symbol10                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL11   => prach_cq_full_symbol11                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL12   => prach_cq_full_symbol12                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL13   => prach_cq_full_symbol13                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL0   => usage_prach_cq_symbol0                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL1   => usage_prach_cq_symbol1                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL2   => usage_prach_cq_symbol2                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL3   => usage_prach_cq_symbol3                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL4   => usage_prach_cq_symbol4                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL5   => usage_prach_cq_symbol5                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL6   => usage_prach_cq_symbol6                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL7   => usage_prach_cq_symbol7                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL8   => usage_prach_cq_symbol8                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL9   => usage_prach_cq_symbol9                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL10  => usage_prach_cq_symbol10                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL11  => usage_prach_cq_symbol11                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL12  => usage_prach_cq_symbol12                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL13  => usage_prach_cq_symbol13                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_eMTC_TERMINATION         => emtc_termination                        ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL0       => emtc_cpsec_symbol0                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL1       => emtc_cpsec_symbol1                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL2       => emtc_cpsec_symbol2                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL3       => emtc_cpsec_symbol3                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL4       => emtc_cpsec_symbol4                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL5       => emtc_cpsec_symbol5                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL6       => emtc_cpsec_symbol6                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL7       => emtc_cpsec_symbol7                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL8       => emtc_cpsec_symbol8                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL9       => emtc_cpsec_symbol9                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL10      => emtc_cpsec_symbol10                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL11      => emtc_cpsec_symbol11                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL12      => emtc_cpsec_symbol12                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL13      => emtc_cpsec_symbol13                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL0       => emtc_uppkt_symbol0                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL1       => emtc_uppkt_symbol1                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL2       => emtc_uppkt_symbol2                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL3       => emtc_uppkt_symbol3                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL4       => emtc_uppkt_symbol4                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL5       => emtc_uppkt_symbol5                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL6       => emtc_uppkt_symbol6                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL7       => emtc_uppkt_symbol7                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL8       => emtc_uppkt_symbol8                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL9       => emtc_uppkt_symbol9                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL10      => emtc_uppkt_symbol10                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL11      => emtc_uppkt_symbol11                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL12      => emtc_uppkt_symbol12                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL13      => emtc_uppkt_symbol13                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL0     => emtc_cq_full_symbol0                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL1     => emtc_cq_full_symbol1                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL2     => emtc_cq_full_symbol2                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL3     => emtc_cq_full_symbol3                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL4     => emtc_cq_full_symbol4                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL5     => emtc_cq_full_symbol5                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL6     => emtc_cq_full_symbol6                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL7     => emtc_cq_full_symbol7                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL8     => emtc_cq_full_symbol8                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL9     => emtc_cq_full_symbol9                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL10    => emtc_cq_full_symbol10                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL11    => emtc_cq_full_symbol11                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL12    => emtc_cq_full_symbol12                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL13    => emtc_cq_full_symbol13                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL0    => usage_emtc_cq_symbol0                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL1    => usage_emtc_cq_symbol1                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL2    => usage_emtc_cq_symbol2                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL3    => usage_emtc_cq_symbol3                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL4    => usage_emtc_cq_symbol4                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL5    => usage_emtc_cq_symbol5                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL6    => usage_emtc_cq_symbol6                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL7    => usage_emtc_cq_symbol7                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL8    => usage_emtc_cq_symbol8                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL9    => usage_emtc_cq_symbol9                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL10   => usage_emtc_cq_symbol10                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL11   => usage_emtc_cq_symbol11                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL12   => usage_emtc_cq_symbol12                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL13   => usage_emtc_cq_symbol13                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_NBIOT0_TERMINATION       => nbiot0_termination                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL0     => nbiot0_cpsec_symbol0                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL1     => nbiot0_cpsec_symbol1                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL2     => nbiot0_cpsec_symbol2                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL3     => nbiot0_cpsec_symbol3                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL4     => nbiot0_cpsec_symbol4                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL5     => nbiot0_cpsec_symbol5                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL6     => nbiot0_cpsec_symbol6                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL7     => nbiot0_cpsec_symbol7                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL8     => nbiot0_cpsec_symbol8                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL9     => nbiot0_cpsec_symbol9                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL10    => nbiot0_cpsec_symbol10                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL11    => nbiot0_cpsec_symbol11                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL12    => nbiot0_cpsec_symbol12                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL13    => nbiot0_cpsec_symbol13                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL0     => nbiot0_uppkt_symbol0                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL1     => nbiot0_uppkt_symbol1                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL2     => nbiot0_uppkt_symbol2                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL3     => nbiot0_uppkt_symbol3                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL4     => nbiot0_uppkt_symbol4                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL5     => nbiot0_uppkt_symbol5                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL6     => nbiot0_uppkt_symbol6                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL7     => nbiot0_uppkt_symbol7                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL8     => nbiot0_uppkt_symbol8                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL9     => nbiot0_uppkt_symbol9                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL10    => nbiot0_uppkt_symbol10                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL11    => nbiot0_uppkt_symbol11                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL12    => nbiot0_uppkt_symbol12                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL13    => nbiot0_uppkt_symbol13                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL0   => nbiot0_cq_full_symbol0                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL1   => nbiot0_cq_full_symbol1                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL2   => nbiot0_cq_full_symbol2                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL3   => nbiot0_cq_full_symbol3                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL4   => nbiot0_cq_full_symbol4                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL5   => nbiot0_cq_full_symbol5                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL6   => nbiot0_cq_full_symbol6                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL7   => nbiot0_cq_full_symbol7                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL8   => nbiot0_cq_full_symbol8                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL9   => nbiot0_cq_full_symbol9                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL10  => nbiot0_cq_full_symbol10                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL11  => nbiot0_cq_full_symbol11                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL12  => nbiot0_cq_full_symbol12                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL13  => nbiot0_cq_full_symbol13                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL0  => usage_nbiot0_cq_symbol0                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL1  => usage_nbiot0_cq_symbol1                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL2  => usage_nbiot0_cq_symbol2                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL3  => usage_nbiot0_cq_symbol3                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL4  => usage_nbiot0_cq_symbol4                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL5  => usage_nbiot0_cq_symbol5                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL6  => usage_nbiot0_cq_symbol6                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL7  => usage_nbiot0_cq_symbol7                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL8  => usage_nbiot0_cq_symbol8                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL9  => usage_nbiot0_cq_symbol9                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL10 => usage_nbiot0_cq_symbol10                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL11 => usage_nbiot0_cq_symbol11                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL12 => usage_nbiot0_cq_symbol12                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL13 => usage_nbiot0_cq_symbol13                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_NBIOT1_TERMINATION       => nbiot1_termination                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL0     => nbiot1_cpsec_symbol0                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL1     => nbiot1_cpsec_symbol1                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL2     => nbiot1_cpsec_symbol2                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL3     => nbiot1_cpsec_symbol3                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL4     => nbiot1_cpsec_symbol4                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL5     => nbiot1_cpsec_symbol5                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL6     => nbiot1_cpsec_symbol6                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL7     => nbiot1_cpsec_symbol7                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL8     => nbiot1_cpsec_symbol8                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL9     => nbiot1_cpsec_symbol9                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL10    => nbiot1_cpsec_symbol10                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL11    => nbiot1_cpsec_symbol11                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL12    => nbiot1_cpsec_symbol12                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL13    => nbiot1_cpsec_symbol13                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL0     => nbiot1_uppkt_symbol0                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL1     => nbiot1_uppkt_symbol1                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL2     => nbiot1_uppkt_symbol2                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL3     => nbiot1_uppkt_symbol3                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL4     => nbiot1_uppkt_symbol4                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL5     => nbiot1_uppkt_symbol5                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL6     => nbiot1_uppkt_symbol6                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL7     => nbiot1_uppkt_symbol7                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL8     => nbiot1_uppkt_symbol8                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL9     => nbiot1_uppkt_symbol9                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL10    => nbiot1_uppkt_symbol10                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL11    => nbiot1_uppkt_symbol11                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL12    => nbiot1_uppkt_symbol12                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL13    => nbiot1_uppkt_symbol13                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL0   => nbiot1_cq_full_symbol0                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL1   => nbiot1_cq_full_symbol1                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL2   => nbiot1_cq_full_symbol2                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL3   => nbiot1_cq_full_symbol3                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL4   => nbiot1_cq_full_symbol4                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL5   => nbiot1_cq_full_symbol5                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL6   => nbiot1_cq_full_symbol6                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL7   => nbiot1_cq_full_symbol7                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL8   => nbiot1_cq_full_symbol8                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL9   => nbiot1_cq_full_symbol9                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL10  => nbiot1_cq_full_symbol10                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL11  => nbiot1_cq_full_symbol11                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL12  => nbiot1_cq_full_symbol12                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL13  => nbiot1_cq_full_symbol13                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL0  => usage_nbiot1_cq_symbol0                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL1  => usage_nbiot1_cq_symbol1                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL2  => usage_nbiot1_cq_symbol2                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL3  => usage_nbiot1_cq_symbol3                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL4  => usage_nbiot1_cq_symbol4                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL5  => usage_nbiot1_cq_symbol5                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL6  => usage_nbiot1_cq_symbol6                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL7  => usage_nbiot1_cq_symbol7                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL8  => usage_nbiot1_cq_symbol8                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL9  => usage_nbiot1_cq_symbol9                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL10 => usage_nbiot1_cq_symbol10                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL11 => usage_nbiot1_cq_symbol11                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL12 => usage_nbiot1_cq_symbol12                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL13 => usage_nbiot1_cq_symbol13                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_NBIOT2_TERMINATION       => nbiot2_termination                      ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL0     => nbiot2_cpsec_symbol0                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL1     => nbiot2_cpsec_symbol1                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL2     => nbiot2_cpsec_symbol2                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL3     => nbiot2_cpsec_symbol3                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL4     => nbiot2_cpsec_symbol4                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL5     => nbiot2_cpsec_symbol5                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL6     => nbiot2_cpsec_symbol6                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL7     => nbiot2_cpsec_symbol7                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL8     => nbiot2_cpsec_symbol8                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL9     => nbiot2_cpsec_symbol9                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL10    => nbiot2_cpsec_symbol10                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL11    => nbiot2_cpsec_symbol11                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL12    => nbiot2_cpsec_symbol12                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL13    => nbiot2_cpsec_symbol13                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL0     => nbiot2_uppkt_symbol0                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL1     => nbiot2_uppkt_symbol1                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL2     => nbiot2_uppkt_symbol2                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL3     => nbiot2_uppkt_symbol3                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL4     => nbiot2_uppkt_symbol4                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL5     => nbiot2_uppkt_symbol5                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL6     => nbiot2_uppkt_symbol6                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL7     => nbiot2_uppkt_symbol7                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL8     => nbiot2_uppkt_symbol8                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL9     => nbiot2_uppkt_symbol9                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL10    => nbiot2_uppkt_symbol10                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL11    => nbiot2_uppkt_symbol11                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL12    => nbiot2_uppkt_symbol12                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL13    => nbiot2_uppkt_symbol13                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL0   => nbiot2_cq_full_symbol0                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL1   => nbiot2_cq_full_symbol1                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL2   => nbiot2_cq_full_symbol2                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL3   => nbiot2_cq_full_symbol3                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL4   => nbiot2_cq_full_symbol4                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL5   => nbiot2_cq_full_symbol5                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL6   => nbiot2_cq_full_symbol6                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL7   => nbiot2_cq_full_symbol7                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL8   => nbiot2_cq_full_symbol8                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL9   => nbiot2_cq_full_symbol9                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL10  => nbiot2_cq_full_symbol10                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL11  => nbiot2_cq_full_symbol11                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL12  => nbiot2_cq_full_symbol12                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL13  => nbiot2_cq_full_symbol13                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL0  => usage_nbiot2_cq_symbol0                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL1  => usage_nbiot2_cq_symbol1                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL2  => usage_nbiot2_cq_symbol2                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL3  => usage_nbiot2_cq_symbol3                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL4  => usage_nbiot2_cq_symbol4                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL5  => usage_nbiot2_cq_symbol5                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL6  => usage_nbiot2_cq_symbol6                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL7  => usage_nbiot2_cq_symbol7                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL8  => usage_nbiot2_cq_symbol8                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL9  => usage_nbiot2_cq_symbol9                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL10 => usage_nbiot2_cq_symbol10                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL11 => usage_nbiot2_cq_symbol11                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL12 => usage_nbiot2_cq_symbol12                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL13 => usage_nbiot2_cq_symbol13                ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

        WREN_CPUIF_IN               => WREN_CPUIF_IN                           ,--: in  std_logic;
        RDEN_CPUIF_IN               => RDEN_CPUIF_IN                           ,--: in  std_logic;
        ADDR_CPUIF_IN               => ADDR_CPUIF_IN                           ,--: in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN              => WDATA_CPUIF_IN                          ,--: in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             => RDATA_CPUIF_OUT                         ,--: out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             => RDVAL_CPUIF_OUT                          --: out std_logic
    );

end BEHAVE;