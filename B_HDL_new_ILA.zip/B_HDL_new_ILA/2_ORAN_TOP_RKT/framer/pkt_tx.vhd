--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Packet transmitter                                            --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity PKT_TX is
    generic (
        USAGE_C_PLANE               : boolean := true;
        USAGE_U_PLANE               : boolean := true
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;                            -- 156.25/390.625-MHz

        RST                         : in  std_logic;

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------


--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        USAGE_DATA_BUFFER           : out std_logic_vector(31 downto 0);        -- CLK
        USAGE_C_PLANE_BUFFER        : out std_logic_vector(31 downto 0);        -- CLK
        USAGE_U_PLANE_BUFFER        : out std_logic_vector(31 downto 0);        -- CLK

        CNT_C_PLANE                 : out std_logic_vector(31 downto 0);        -- CLK
        CNT_C_PLANE_LOST            : out std_logic_vector(31 downto 0);        -- CLK
        CNT_U_PLANE                 : out std_logic_vector(31 downto 0);        -- CLK
        CNT_U_PLANE_LOST            : out std_logic_vector(31 downto 0);        -- CLK

--------------------------------------------------------------------------------
-- Data bus
--------------------------------------------------------------------------------

        IN_C_VALID                  : in  std_logic;
        IN_C_LAST                   : in  std_logic;
        IN_C_KEEP                   : in  std_logic_vector(7 downto 0);
        IN_C_DATA                   : in  std_logic_vector(63 downto 0);

        IN_U_VALID                  : in  std_logic;
        IN_U_LAST                   : in  std_logic;
        IN_U_KEEP                   : in  std_logic_vector(7 downto 0);
        IN_U_DATA                   : in  std_logic_vector(63 downto 0);

        OUT_READY                   : in  std_logic;
        OUT_VALID                   : out std_logic;
        OUT_LAST                    : out std_logic;
        OUT_KEEP                    : out std_logic_vector(7 downto 0);
        OUT_DATA                    : out std_logic_vector(63 downto 0)
    );
end PKT_TX;

architecture BEHAVE of PKT_TX is

    signal areset_n                 : std_logic;

    signal c_plane_ready            : std_logic;
    signal c_plane_user             : std_logic_vector(2 downto 0);
    signal u_plane_ready            : std_logic;
    signal u_plane_user             : std_logic_vector(2 downto 0);

    component eCPRI_ST_MUX_BUFFER_CUSTOM is
    port (
        S_AXIS_ARESETN              : in  std_logic;
        S_AXIS_ACLK                 : in  std_logic;
        S_AXIS_TVALID               : in  std_logic;
        S_AXIS_TREADY               : out std_logic;
        S_AXIS_TDATA                : in  std_logic_vector(63 downto 0);
        S_AXIS_TLAST                : in  std_logic;
        S_AXIS_TUSER                : in  std_logic_vector(2 downto 0);
        M_AXIS_TVALID               : out std_logic;
        M_AXIS_TREADY               : in  std_logic;
        M_AXIS_TDATA                : out std_logic_vector(63 downto 0);
        M_AXIS_TLAST                : out std_logic;
        M_AXIS_TUSER                : out std_logic_vector(2 downto 0);
        AXIS_WR_DATA_COUNT          : out std_logic_vector(31 downto 0);
        AXIS_RD_DATA_COUNT          : out std_logic_vector(31 downto 0)
    );
    end component;

    signal framer_c_valid           : std_logic;
    signal framer_c_ready           : std_logic;
    signal framer_c_last            : std_logic;
    signal framer_c_data            : std_logic_vector(63 downto 0);
    signal framer_c_user            : std_logic_vector(2 downto 0);
    signal framer_c_wr_usage        : std_logic_vector(31 downto 0);
    signal framer_u_valid           : std_logic;
    signal framer_u_ready           : std_logic;
    signal framer_u_last            : std_logic;
    signal framer_u_data            : std_logic_vector(63 downto 0);
    signal framer_u_user            : std_logic_vector(2 downto 0);
    signal framer_u_wr_usage        : std_logic_vector(31 downto 0);

    component eCPRI_ST_MUX_2P_CUSTOM is
    port (
        ACLK                        : in  std_logic;
        ARESETN                     : in  std_logic;
        S_AXIS_TVALID               : in  std_logic_vector(1 downto 0);
        S_AXIS_TREADY               : out std_logic_vector(1 downto 0);
        S_AXIS_TDATA                : in  std_logic_vector(127 downto 0);
        S_AXIS_TLAST                : in  std_logic_vector(1 downto 0);
        S_AXIS_TUSER                : in  std_logic_vector(5 downto 0);
        M_AXIS_TVALID               : out std_logic_vector(0 downto 0);
        M_AXIS_TREADY               : in  std_logic_vector(0 downto 0);
        M_AXIS_TDATA                : out std_logic_vector(63 downto 0);
        M_AXIS_TLAST                : out std_logic_vector(0 downto 0);
        M_AXIS_TUSER                : out std_logic_vector(2 downto 0);
        S_REQ_SUPPRESS              : in  std_logic_vector(1 downto 0);
        S_DECODE_ERR                : out std_logic_vector(1 downto 0)
    );
    end component;

    signal sw_valid                 : std_logic;
    signal sw_ready                 : std_logic;
    signal sw_data                  : std_logic_vector(63 downto 0);
    signal sw_last                  : std_logic;
    signal sw_user                  : std_logic_vector(2 downto 0);

    component eCPRI_UL_BUFFER is
    port (
        S_AXIS_ARESETN              : in  std_logic;
        S_AXIS_ACLK                 : in  std_logic;
        S_AXIS_TVALID               : in  std_logic;
        S_AXIS_TREADY               : out std_logic;
        S_AXIS_TDATA                : in  std_logic_vector(63 downto 0);
        S_AXIS_TLAST                : in  std_logic;
        S_AXIS_TUSER                : in  std_logic_vector(2 downto 0);
        M_AXIS_TVALID               : out std_logic;
        M_AXIS_TREADY               : in  std_logic;
        M_AXIS_TDATA                : out std_logic_vector(63 downto 0);
        M_AXIS_TLAST                : out std_logic;
        M_AXIS_TUSER                : out std_logic_vector(2 downto 0);
        AXIS_WR_DATA_COUNT          : out std_logic_vector(31 downto 0);
        AXIS_RD_DATA_COUNT          : out std_logic_vector(31 downto 0)
    );
    end component;

    signal mac_tx_user              : std_logic_vector(2 downto 0);
    signal mac_tx_wr_usage          : std_logic_vector(31 downto 0);

    component USAGE_TO_GAUGE is
    generic (
        MAX_USAGE                   : natural := 1024
    );
    port (
        CLK                         : in  std_logic;

        USAGE                       : in  std_logic_vector(31 downto 0);
        GAUGE                       : out std_logic_vector(31 downto 0)
    );
    end component;

    signal c_tx_cnt                 : std_logic_vector(15 downto 0) := (others => '0');
    signal c_tx_lost_cnt            : std_logic_vector(15 downto 0) := (others => '0');
    signal u_tx_cnt                 : std_logic_vector(15 downto 0) := (others => '0');
    signal u_tx_lost_cnt            : std_logic_vector(15 downto 0) := (others => '0');

begin

    areset_n <= not RST;

--------------------------------------------------------------------------------
-- Convert KEEP(8-bits) to USER(3-bits)
--------------------------------------------------------------------------------

    c_plane_user <= "111" when IN_C_KEEP = x"7F" else
                    "110" when IN_C_KEEP = x"3F" else
                    "101" when IN_C_KEEP = x"1F" else
                    "100" when IN_C_KEEP = x"0F" else
                    "011" when IN_C_KEEP = x"07" else
                    "010" when IN_C_KEEP = x"03" else
                    "001" when IN_C_KEEP = x"01" else
                    "000";

    u_plane_user <= "111" when IN_U_KEEP = x"7F" else
                    "110" when IN_U_KEEP = x"3F" else
                    "101" when IN_U_KEEP = x"1F" else
                    "100" when IN_U_KEEP = x"0F" else
                    "011" when IN_U_KEEP = x"07" else
                    "010" when IN_U_KEEP = x"03" else
                    "001" when IN_U_KEEP = x"01" else
                    "000";

--------------------------------------------------------------------------------
-- Mux
--------------------------------------------------------------------------------

    u_SWITCH_USED : if USAGE_C_PLANE = true and USAGE_U_PLANE = true generate
    u_C_PLANE_BUFFER : eCPRI_ST_MUX_BUFFER_CUSTOM
    port map(
        S_AXIS_ARESETN              => areset_n                                ,--: in  std_logic;
        S_AXIS_ACLK                 => CLK                                     ,--: in  std_logic;
        S_AXIS_TVALID               => IN_C_VALID                              ,--: in  std_logic;
        S_AXIS_TREADY               => c_plane_ready                           ,--: out std_logic;
        S_AXIS_TDATA                => IN_C_DATA                               ,--: in  std_logic_vector(63 downto 0);
        S_AXIS_TLAST                => IN_C_LAST                               ,--: in  std_logic;
        S_AXIS_TUSER                => c_plane_user                            ,--: in  std_logic_vector(2 downto 0);
        M_AXIS_TVALID               => framer_c_valid                          ,--: out std_logic;
        M_AXIS_TREADY               => framer_c_ready                          ,--: in  std_logic;
        M_AXIS_TDATA                => framer_c_data                           ,--: out std_logic_vector(63 downto 0);
        M_AXIS_TLAST                => framer_c_last                           ,--: out std_logic;
        M_AXIS_TUSER                => framer_c_user                           ,--: out std_logic_vector(2 downto 0);
        AXIS_WR_DATA_COUNT          => framer_c_wr_usage                       ,--: out std_logic_vector(31 downto 0);
        AXIS_RD_DATA_COUNT          => open                                     --: out std_logic_vector(31 downto 0)
    );

    u_U_PLANE_BUFFER : eCPRI_ST_MUX_BUFFER_CUSTOM
    port map(
        S_AXIS_ARESETN              => areset_n                                ,--: in  std_logic;
        S_AXIS_ACLK                 => CLK                                     ,--: in  std_logic;
        S_AXIS_TVALID               => IN_U_VALID                              ,--: in  std_logic;
        S_AXIS_TREADY               => u_plane_ready                           ,--: out std_logic;
        S_AXIS_TDATA                => IN_U_DATA                               ,--: in  std_logic_vector(63 downto 0);
        S_AXIS_TLAST                => IN_U_LAST                               ,--: in  std_logic;
        S_AXIS_TUSER                => u_plane_user                            ,--: in  std_logic_vector(2 downto 0);
        M_AXIS_TVALID               => framer_u_valid                          ,--: out std_logic;
        M_AXIS_TREADY               => framer_u_ready                          ,--: in  std_logic;
        M_AXIS_TDATA                => framer_u_data                           ,--: out std_logic_vector(63 downto 0);
        M_AXIS_TLAST                => framer_u_last                           ,--: out std_logic;
        M_AXIS_TUSER                => framer_u_user                           ,--: out std_logic_vector(2 downto 0);
        AXIS_WR_DATA_COUNT          => framer_u_wr_usage                       ,--: out std_logic_vector(31 downto 0);
        AXIS_RD_DATA_COUNT          => open                                     --: out std_logic_vector(31 downto 0)
    );

    u_SWITCH : eCPRI_ST_MUX_2P_CUSTOM
    port map(
        ACLK                        => CLK                                     ,--: in  std_logic;
        ARESETN                     => areset_n                                ,--: in  std_logic;
        S_AXIS_TVALID(0)            => framer_c_valid                          ,--: in  std_logic_vector(1 downto 0);
        S_AXIS_TVALID(1)            => framer_u_valid                          ,--: in  std_logic_vector(1 downto 0);
        S_AXIS_TREADY(0)            => framer_c_ready                          ,--: out std_logic_vector(1 downto 0);
        S_AXIS_TREADY(1)            => framer_u_ready                          ,--: out std_logic_vector(1 downto 0);
        S_AXIS_TDATA(63 downto 0)   => framer_c_data                           ,--: in  std_logic_vector(127 downto 0);
        S_AXIS_TDATA(127 downto 64) => framer_u_data                           ,--: in  std_logic_vector(127 downto 0);
        S_AXIS_TLAST(0)             => framer_c_last                           ,--: in  std_logic_vector(1 downto 0);
        S_AXIS_TLAST(1)             => framer_u_last                           ,--: in  std_logic_vector(1 downto 0);
        S_AXIS_TUSER(2 downto 0)    => framer_c_user                           ,--: in  std_logic_vector(5 downto 0);
        S_AXIS_TUSER(5 downto 3)    => framer_u_user                           ,--: in  std_logic_vector(5 downto 0);
        M_AXIS_TVALID(0)            => sw_valid                                ,--: out std_logic_vector(0 downto 0);
        M_AXIS_TREADY(0)            => sw_ready                                ,--: in  std_logic_vector(0 downto 0);
        M_AXIS_TDATA                => sw_data                                 ,--: out std_logic_vector(63 downto 0);
        M_AXIS_TLAST(0)             => sw_last                                 ,--: out std_logic_vector(0 downto 0);
        M_AXIS_TUSER                => sw_user                                 ,--: out std_logic_vector(2 downto 0);
        S_REQ_SUPPRESS              => (others => '0')                         ,--: in  std_logic_vector(1 downto 0);
        S_DECODE_ERR                => open                                     --: out std_logic_vector(1 downto 0)
    );
    end generate;

    u_SWITCH_UNUSED : if USAGE_C_PLANE = false or USAGE_U_PLANE = false generate
    u_C_PLANE_ONLY : if USAGE_C_PLANE = true generate
    framer_c_wr_usage <= (others => '0');
    framer_u_wr_usage <= (others => '0');

    sw_valid          <= IN_C_VALID;
    c_plane_ready     <= sw_ready;
    u_plane_ready     <= '1';
    sw_data           <= IN_C_DATA;
    sw_last           <= IN_C_LAST;
    sw_user           <= c_plane_user;
    end generate;

    u_U_PLANE_ONLY : if USAGE_U_PLANE = true generate
    framer_c_wr_usage <= (others => '0');
    framer_u_wr_usage <= (others => '0');

    sw_valid          <= IN_U_VALID;
    c_plane_ready     <= '1';
    u_plane_ready     <= sw_ready;
    sw_data           <= IN_U_DATA;
    sw_last           <= IN_U_LAST;
    sw_user           <= u_plane_user;
    end generate;
    end generate;

--------------------------------------------------------------------------------
-- Data buffer (Change to packet mode)
--------------------------------------------------------------------------------

    u_DATA_BUFFER : eCPRI_UL_BUFFER
    port map(
        S_AXIS_ARESETN              => areset_n                                ,--: in  std_logic;
        S_AXIS_ACLK                 => CLK                                     ,--: in  std_logic;
        S_AXIS_TVALID               => sw_valid                                ,--: in  std_logic;
        S_AXIS_TREADY               => sw_ready                                ,--: out std_logic;
        S_AXIS_TDATA                => sw_data                                 ,--: in  std_logic_vector(63 downto 0);
        S_AXIS_TLAST                => sw_last                                 ,--: in  std_logic;
        S_AXIS_TUSER                => sw_user                                 ,--: in  std_logic_vector(2 downto 0);
        M_AXIS_TVALID               => OUT_VALID                               ,--: out std_logic;
        M_AXIS_TREADY               => OUT_READY                               ,--: in  std_logic;
        M_AXIS_TDATA                => OUT_DATA                                ,--: out std_logic_vector(63 downto 0);
        M_AXIS_TLAST                => OUT_LAST                                ,--: out std_logic;
        M_AXIS_TUSER                => mac_tx_user                             ,--: out std_logic_vector(2 downto 0);
        AXIS_WR_DATA_COUNT          => mac_tx_wr_usage                         ,--: out std_logic_vector(31 downto 0);
        AXIS_RD_DATA_COUNT          => open                                     --: out std_logic_vector(31 downto 0)
    );

    OUT_KEEP <= x"7F" when mac_tx_user = "111" else
                x"3F" when mac_tx_user = "110" else
                x"1F" when mac_tx_user = "101" else
                x"0F" when mac_tx_user = "100" else
                x"07" when mac_tx_user = "011" else
                x"03" when mac_tx_user = "010" else
                x"01" when mac_tx_user = "001" else
                x"FF";

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

    u_DATA_BUFFER_STATUS    : USAGE_TO_GAUGE generic map(4096) port map(CLK, mac_tx_wr_usage, USAGE_DATA_BUFFER);
    u_C_PLANE_BUFFER_STATUS : USAGE_TO_GAUGE generic map(512)  port map(CLK, framer_c_wr_usage, USAGE_C_PLANE_BUFFER);
    u_U_PLANE_BUFFER_STATUS : USAGE_TO_GAUGE generic map(512)  port map(CLK, framer_u_wr_usage, USAGE_U_PLANE_BUFFER);

    CNT_C_PLANE      <= x"0000" & c_tx_cnt;
    CNT_C_PLANE_LOST <= x"0000" & c_tx_lost_cnt;
    CNT_U_PLANE      <= x"0000" & u_tx_cnt;
    CNT_U_PLANE_LOST <= x"0000" & u_tx_lost_cnt;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_C_VALID = '1') and (IN_C_LAST = '1') then
                c_tx_cnt <= c_tx_cnt + 1;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_C_VALID = '1') and (c_plane_ready = '0') then
                c_tx_lost_cnt <= c_tx_lost_cnt + 1;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_U_VALID = '1') and (IN_U_LAST = '1') then
                u_tx_cnt <= u_tx_cnt + 1;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_U_VALID = '1') and (u_plane_ready = '0') then
                u_tx_lost_cnt <= u_tx_lost_cnt + 1;
            end if;
        end if;
    end process;

end BEHAVE;