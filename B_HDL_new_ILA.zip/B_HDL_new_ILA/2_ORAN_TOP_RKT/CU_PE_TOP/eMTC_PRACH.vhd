
--================================================================================
-- Filename     : eMTC_PRACH.vhd
-- Author       : Taeyoup Kim (taeyoup.kim@samsung.com)
-- Description  : O-RAN UL C-Plane Parameter Parsing for eMTC_PRACH
----------------------------------------------------------------------------------
--     Date    |     By           |  Version | Description
----------------------------------------------------------------------------------
--  11-28-2021 | Taeyoup Kim      |    1.0   | Original Version   
--================================================================================
-- Copyright (c) 2021 SAMSUNG. All rights reserved.                               
--================================================================================

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;   
use IEEE.NUMERIC_STD.ALL;
use IEEE.MATH_REAL.ALL;
use WORK.ARRAY_TYPE.ALL;

    entity eMTC_PRACH is
    generic (                            
    PATH_NUM                       : natural := 4                             
    );
    port (

    CLK                            : in std_logic;

    --------------------------------------------------------------------------------
    -- CP_PARSER
    --------------------------------------------------------------------------------

    CC_ENABLE                      : in std_logic;
    SECTOR_EN                      : in std_logic_vector(PATH_NUM*1-1 downto 0);
    CP_UPDATE                      : in std_logic; 
    DATA_DIRECTION                 : in std_logic;                      
    FILTER_INDEX                   : in std_logic_vector(  3 downto 0);                                      
    SUBFRAME_ID                    : in std_logic_vector(  3 downto 0);
    SLOT_ID 	                     : in std_logic_vector(  5 downto 0);     
    START_SYMBOL_ID                : in std_logic_vector(  5 downto 0);                                       
    SECTION_TYPE                   : in std_logic_vector(  7 downto 0); 
    TIME_OFFSET                    : in std_logic_vector( 15 downto 0); 
    FRAME_STRUCTURE                : in std_logic_vector(  7 downto 0); 
    CPLENGTH                       : in std_logic_vector( 15 downto 0);  
    FREQ_OFFSET                    : in std_logic_vector( 23 downto 0); 
    NUM_SYMBOL                     : in std_logic_vector(  3 downto 0);
    NUM_PRBC                       : in std_logic_vector(  7 downto 0);

    --------------------------------------------------------------------------------
    -- UL Sync Retard
    --------------------------------------------------------------------------------
                                                           
    UL_RTD_SBF_SYNC                : in std_logic;                                 
    UL_RTD_SBF_IDX                 : in std_logic_vector(  3 downto 0); -- 0~9
    UL_RTD_SLOT_SYNC               : in std_logic;                           
    UL_RTD_SLOT_IDX                : in std_logic_vector(  7 downto 0); -- SCS 15kHz : 0 ~ 9 (per Frame)       
    UL_RTD_SYMBOL_SYNC             : in std_logic;                                 
    UL_RTD_SYMBOL_IDX              : in std_logic_vector(  3 downto 0); -- 0~13  

    --------------------------------------------------------------------------------
    -- RAFE
    --------------------------------------------------------------------------------
                                                                                                      
    UL_FILTER_INDEX                : out std_logic_vector(PATH_NUM*4-1 downto 0);   
    UL_TIME_OFFSET                 : out std_logic_vector(PATH_NUM*16-1 downto 0);  
    UL_FRAME_STRUCTURE             : out std_logic_vector(PATH_NUM*8-1 downto 0);   
    UL_CPLENGTH                    : out std_logic_vector(PATH_NUM*16-1 downto 0);  
    UL_FREQ_OFFSET                 : out std_logic_vector(PATH_NUM*24-1 downto 0);       
    UL_NUM_PSYMBOL                 : out std_logic_vector(PATH_NUM*4-1 downto 0);       
    UL_NUM_PRBC                    : out std_logic_vector(PATH_NUM*8-1 downto 0);  
    UL_NUM_RO                      : out std_logic_vector(PATH_NUM*3-1 downto 0)       
    );
    end eMTC_PRACH;

architecture BEHAVE of eMTC_PRACH is

    signal rach_sector_en          : std_logic_vector(PATH_NUM*1-1 downto 0) := (others => '0');
    signal rach_frame_index0       : std_logic_vector(  5 downto 0) := (others => '0');
    signal rach_frame_index        : std_logic_array6(  3 downto 0) := (others => (others => '0'));
    signal rach_filter_index       : std_logic_array4(  3 downto 0) := (others => (others => '0'));
    signal rach_time_offset        : std_logic_array16( 3 downto 0) := (others => (others => '0'));
    signal rach_frame_structure    : std_logic_array8(  3 downto 0) := (others => (others => '0'));
    signal rach_cpLength           : std_logic_array16( 3 downto 0) := (others => (others => '0'));
    signal rach_freq_offset        : std_logic_array24( 3 downto 0) := (others => (others => '0'));
    signal rach_num_psymbol        : std_logic_array4(  3 downto 0) := (others => (others => '0'));
    signal rach_num_prbc           : std_logic_array8(  3 downto 0) := (others => (others => '0'));
    signal rach_num_ro             : std_logic_array3(  3 downto 0) := (others => (others => '0'));
    signal ul_rtd_symbol_sync_d    : std_logic_vector(  1 downto 0) := (others => '0');
    signal long_ro                 : std_logic_vector(  3 downto 0) := (others => '0');

   
begin


--=============================================================================================================== 
--  eMTC_PRACH                                                                                               
--=============================================================================================================== 

    rach_frame_index0 <= SUBFRAME_ID(0) & SLOT_ID(0) & START_SYMBOL_ID(3 downto 0);

    process (CLK)                        
    begin                                
        if (CLK'event and CLK = '1') then
           ul_rtd_symbol_sync_d(0) <= UL_RTD_SYMBOL_SYNC;
        end if;
    end process;

    process (CLK)                        
    begin                                
        if (CLK'event and CLK = '1') then
           if (rach_frame_index(0)(3 downto 0) = UL_RTD_SYMBOL_IDX(3 downto 0)) then
              long_ro(0) <= '1';
           else
              long_ro(0) <= '0';
           end if;           
        end if;
    end process;

    process (CLK)                        
    begin                                
        if (CLK'event and CLK = '1') then
           if (CC_ENABLE = '1' and CP_UPDATE = '1' and DATA_DIRECTION = '0' and SECTION_TYPE(1 downto 0) = 3) then
              rach_sector_en          <= SECTOR_EN;
              rach_frame_index(0)     <= rach_frame_index0;  -- should be changed according to SCS
              rach_filter_index(0)    <= FILTER_INDEX;
              rach_time_offset(0)     <= TIME_OFFSET;
              rach_frame_structure(0) <= FRAME_STRUCTURE;
              rach_cpLength(0)        <= CPLENGTH;
              rach_freq_offset(0)     <= FREQ_OFFSET;
              rach_num_psymbol(0)     <= NUM_SYMBOL;
              rach_num_prbc(0)        <= NUM_PRBC;
              rach_num_ro(0)          <= "001";
           else
              if (long_ro(0) = '1' and ul_rtd_symbol_sync_d(0) = '1') then
                 rach_sector_en          <= (others => '0');
                 rach_frame_index(0)     <= (others => '1');
                 rach_filter_index(0)    <= (others => '0');
                 rach_time_offset(0)     <= (others => '0');
                 rach_frame_structure(0) <= (others => '0');
                 rach_cpLength(0)        <= (others => '0');
                 rach_freq_offset(0)     <= (others => '0');
                 rach_num_psymbol(0)     <= (others => '0');
                 rach_num_prbc(0)        <= (others => '0');
                 rach_num_ro(0)          <= (others => '0');
              end if;
           end if;
        end if;
    end process; 

    u_eMTC_PRACH_Port_Mapping : for i in PATH_NUM - 1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
           if (ul_rtd_symbol_sync_d(0) = '1') then
              if (rach_sector_en(i) = '1' and long_ro(0) = '1') then
                 UL_FILTER_INDEX(4*(i+1)-1 downto 4*i)    <= rach_filter_index(0);   
                 UL_TIME_OFFSET(16*(i+1)-1 downto 16*i)   <= rach_time_offset(0);    
                 UL_FRAME_STRUCTURE(8*(i+1)-1 downto 8*i) <= rach_frame_structure(0);
                 UL_CPLENGTH(16*(i+1)-1 downto 16*i)      <= rach_cpLength(0);       
                 UL_FREQ_OFFSET(24*(i+1)-1 downto 24*i)   <= rach_freq_offset(0);
                 UL_NUM_PSYMBOL(4*(i+1)-1 downto 4*i)     <= rach_num_psymbol(0);
                 UL_NUM_PRBC(8*(i+1)-1 downto 8*i)        <= rach_num_prbc(0);
                 UL_NUM_RO(3*(i+1)-1 downto 3*i)          <= rach_num_ro(0);
              else
                 UL_FILTER_INDEX(4*(i+1)-1 downto 4*i)    <= (others => '0');  
                 UL_TIME_OFFSET(16*(i+1)-1 downto 16*i)   <= (others => '0');   
                 UL_FRAME_STRUCTURE(8*(i+1)-1 downto 8*i) <= (others => '0');
                 UL_CPLENGTH(16*(i+1)-1 downto 16*i)      <= (others => '0');      
                 UL_FREQ_OFFSET(24*(i+1)-1 downto 24*i)   <= (others => '0');
                 UL_NUM_PSYMBOL(4*(i+1)-1 downto 4*i)     <= (others => '0');
                 UL_NUM_PRBC(8*(i+1)-1 downto 8*i)        <= (others => '0');
                 UL_NUM_RO(3*(i+1)-1 downto 3*i)          <= (others => '0');              
              end if;
           end if;
        end if;
    end process;
    end generate;
                                                        
end BEHAVE;


