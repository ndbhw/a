--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : CPU interface                                                 --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
--   v1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity O_RAN_MPI is
    generic (
        OFFSET                      : std_logic_vector(3 downto 0) := x"3";
        DL_UNIT                     : natural := 8;
        UL_UNIT                     : natural := 8;
        MAX_CH_PER_UNIT             : natural := 2;
        MAX_ID_PER_CH               : natural := 1
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;                            -- 100-MHz
        RST                         : in  std_logic;

        CLK_MAC_RX                  : in  std_logic;                            -- 156.25/390.625-MHz
        CLK_MAC_TX                  : in  std_logic;                            -- 156.25/390.625-MHz
        CLK_BUS                     : in  std_logic;                            -- 245.76-MHz

--------------------------------------------------------------------------------
-- Debug
--------------------------------------------------------------------------------

        IGNORE_FRAME_ID             : out std_logic_vector(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PUxCH_RX    : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH0_RX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH0_TX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH1_RX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH1_TX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT0_RX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT0_TX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT1_RX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT1_TX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT2_RX   : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_NBIOT2_TX   : in  std_logic_array8(UL_UNIT-1 downto 0);

--------------------------------------------------------------------------------
-- O-RAN configuration
--------------------------------------------------------------------------------

        DL_PARAM_MAC                : out std_logic_array48(DL_UNIT-1 downto 0);
        DL_PARAM_ID0_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID0                : out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID1_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID1                : out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID2_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID2                : out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID3_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID3                : out std_logic_array8_array16(DL_UNIT-1 downto 0);

        DL_COMP_MODE                : out std_logic_vector(DL_UNIT-1 downto 0);
        DL_IQ_WIDTH                 : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_COMP_METHOD              : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_SCS_CONFIG               : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_FFT_SIZE                 : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_PRB_PER_SYMBOL           : out std_logic_array10(DL_UNIT-1 downto 0);
        DL_COMP_EXP_OFFSET          : out std_logic_array5(DL_UNIT-1 downto 0);

        UL_PARAM_DST_MAC            : out std_logic_array48(UL_UNIT-1 downto 0);
        UL_PARAM_SRC_MAC            : out std_logic_array48(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN0_MODE         : out std_logic_vector(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN0_TCI          : out std_logic_array16(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN1_MODE         : out std_logic_vector(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN1_TCI          : out std_logic_array16(UL_UNIT-1 downto 0);

        UL_COMP_MODE                : out std_logic_vector(UL_UNIT-1 downto 0);
        UL_IQ_WIDTH                 : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_COMP_METHOD              : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_SCS_CONFIG               : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_FFT_SIZE                 : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_PRB_PER_MTU              : out std_logic_array10(UL_UNIT-1 downto 0);
        UL_PRB_PER_SYMBOL           : out std_logic_array10(UL_UNIT-1 downto 0);
        UL_COMP_EXP_OFFSET          : out std_logic_array5(UL_UNIT-1 downto 0);
        UL_COMP_GAIN_OFFSET         : out std_logic_array11(UL_UNIT-1 downto 0);
        UL_COMP_SCALE_GAIN_OFFSET   : out std_logic_array4(UL_UNIT-1 downto 0);

--------------------------------------------------------------------------------
-- O-RAN Statistics
--------------------------------------------------------------------------------

        T2A_MAX_CP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        T2A_MIN_CP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        CP_DL_PERIOD                : out std_logic_array8(DL_UNIT-1 downto 0);

        CP_DL_CNT_CLEAR             : out std_logic_array4(DL_UNIT-1 downto 0);
        CP_DL_ON_TIME               : in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_EARLY                 : in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_LATE                  : in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_OUT_OF_RANGE          : in  std_logic_array64(DL_UNIT-1 downto 0);

        T2A_MAX_UP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        T2A_MIN_UP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        UP_DL_PERIOD                : out std_logic_array8(DL_UNIT-1 downto 0);

        UP_DL_CNT_CLEAR             : out std_logic_array4(DL_UNIT-1 downto 0);
        UP_DL_ON_TIME               : in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_EARLY                 : in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_LATE                  : in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_OUT_OF_RANGE          : in  std_logic_array64(DL_UNIT-1 downto 0);

        T2A_MAX_CP_UL               : out std_logic_array22(UL_UNIT-1 downto 0);
        T2A_MIN_CP_UL               : out std_logic_array22(UL_UNIT-1 downto 0);
        CP_UL_PERIOD                : out std_logic_array8(UL_UNIT-1 downto 0);

        CP_UL_CNT_CLEAR             : out std_logic_array4(UL_UNIT-1 downto 0);
        CP_UL_ON_TIME               : in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_EARLY                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_LATE                  : in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_OUT_OF_RANGE          : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP0_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP0_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP0_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP0_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP0_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP1_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP1_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP1_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP1_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP1_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP2_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP2_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP2_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP2_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP2_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP2_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP2_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP2_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP3_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP3_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP3_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP3_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP3_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP3_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP3_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP3_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP4_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP4_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP4_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP4_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP4_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP4_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP4_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP4_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP5_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP5_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP5_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP5_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP5_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP5_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP5_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP5_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

--------------------------------------------------------------------------------
-- Statistics (eCPRI, Debug)
--------------------------------------------------------------------------------

        DL_C_PLANE_BUFFER           : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_BUFFER           : in  std_logic_array32(DL_UNIT-1 downto 0);

        DL_INVALID_DST_MAC          : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ETHERTYPE        : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriVersion     : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriC           : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriMessage     : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_C_PLANE                  : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_C_PLANE_DROPPED          : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE                  : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_DROPPED          : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_LOST                     : in  std_logic_array32(DL_UNIT-1 downto 0);

        DL_C_PLANE_EXIST            : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_EXIST            : in  std_logic_array32(DL_UNIT-1 downto 0);

        RX_FAULT_ID_31_CH0          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH1          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH2          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH3          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH4          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH5          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH6          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH7          : in  std_logic_array4(DL_UNIT-1 downto 0);

--        UL_PUxCH_C_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PUxCH_C_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_PUxCH_C_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PRACH_C_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PRACH_C_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_PRACH_C_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_eMTC_C_PLANE_BUFFER      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_U_PLANE_BUFFER      : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_eMTC_C_PLANE             : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_eMTC_C_PLANE_LOST        : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_U_PLANE             : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_U_PLANE_LOST        : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT0_C_PLANE_BUFFER    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_U_PLANE_BUFFER    : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT0_C_PLANE           : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_NBIOT0_C_PLANE_LOST      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_U_PLANE           : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_U_PLANE_LOST      : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT1_C_PLANE_BUFFER    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_U_PLANE_BUFFER    : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT1_C_PLANE           : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_NBIOT1_C_PLANE_LOST      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_U_PLANE           : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_U_PLANE_LOST      : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT2_C_PLANE_BUFFER    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_U_PLANE_BUFFER    : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_NBIOT2_C_PLANE           : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_NBIOT2_C_PLANE_LOST      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_U_PLANE           : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_U_PLANE_LOST      : in  std_logic_array32(UL_UNIT-1 downto 0);

--------------------------------------------------------------------------------
-- Statistics (O-RAN, Debug)
--------------------------------------------------------------------------------

        UL_CMD_FIFO_FULL            : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_PUxCH_TERMINATION        : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL0    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL1    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL2    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL3    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL4    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL5    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL6    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL7    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL8    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL9    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL10   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL11   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL12   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL13   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL0   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL1   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL2   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL3   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL4   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL5   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL6   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL7   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL8   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL9   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL10  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL11  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL12  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL13  : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_PRACH_TERMINATION        : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL0    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL1    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL2    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL3    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL4    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL5    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL6    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL7    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL8    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL9    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL10   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL11   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL12   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL13   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL0   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL1   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL2   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL3   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL4   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL5   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL6   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL7   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL8   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL9   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL10  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL11  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL12  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL13  : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_eMTC_TERMINATION         : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL0       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL1       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL2       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL3       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL4       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL5       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL6       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL7       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL8       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL9       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL10      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL11      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL12      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CPSEC_SYMBOL13      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL0       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL1       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL2       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL3       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL4       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL5       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL6       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL7       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL8       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL9       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL10      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL11      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL12      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_UPPKT_SYMBOL13      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL0     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL1     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL2     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL3     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL4     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL5     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL6     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL7     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL8     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL9     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL10    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL11    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL12    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_FULL_SYMBOL13    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL0    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL1    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL2    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL3    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL4    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL5    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL6    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL7    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL8    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL9    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL10   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL11   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL12   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_eMTC_CQ_USAGE_SYMBOL13   : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_NBIOT0_TERMINATION       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL0     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL1     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL2     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL3     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL4     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL5     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL6     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL7     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL8     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL9     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL10    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL11    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL12    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CPSEC_SYMBOL13    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL0     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL1     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL2     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL3     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL4     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL5     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL6     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL7     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL8     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL9     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL10    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL11    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL12    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_UPPKT_SYMBOL13    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL0   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL1   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL2   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL3   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL4   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL5   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL6   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL7   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL8   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL9   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL10  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL11  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL12  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_FULL_SYMBOL13  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL0  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL1  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL2  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL3  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL4  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL5  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL6  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL7  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL8  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL9  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL10 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL11 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL12 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT0_CQ_USAGE_SYMBOL13 : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_NBIOT1_TERMINATION       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL0     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL1     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL2     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL3     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL4     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL5     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL6     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL7     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL8     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL9     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL10    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL11    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL12    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CPSEC_SYMBOL13    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL0     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL1     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL2     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL3     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL4     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL5     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL6     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL7     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL8     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL9     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL10    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL11    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL12    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_UPPKT_SYMBOL13    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL0   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL1   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL2   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL3   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL4   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL5   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL6   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL7   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL8   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL9   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL10  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL11  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL12  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_FULL_SYMBOL13  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL0  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL1  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL2  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL3  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL4  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL5  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL6  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL7  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL8  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL9  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL10 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL11 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL12 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT1_CQ_USAGE_SYMBOL13 : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_NBIOT2_TERMINATION       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL0     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL1     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL2     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL3     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL4     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL5     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL6     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL7     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL8     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL9     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL10    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL11    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL12    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CPSEC_SYMBOL13    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL0     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL1     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL2     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL3     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL4     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL5     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL6     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL7     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL8     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL9     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL10    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL11    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL12    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_UPPKT_SYMBOL13    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL0   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL1   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL2   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL3   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL4   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL5   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL6   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL7   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL8   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL9   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL10  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL11  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL12  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_FULL_SYMBOL13  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL0  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL1  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL2  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL3  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL4  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL5  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL6  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL7  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL8  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL9  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL10 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL11 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL12 : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_NBIOT2_CQ_USAGE_SYMBOL13 : in  std_logic_array32(UL_UNIT-1 downto 0);

--------------------------------------------------------------------------------
-- CPU
--------------------------------------------------------------------------------

        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);    
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             : out std_logic
    );
end O_RAN_MPI;

architecture BEHAVE of O_RAN_MPI is

    signal we_buf                   : std_logic;
    signal we                       : std_logic_vector(31 downto 0);
    signal we_long                  : std_logic_vector(31 downto 0);
    signal oe_buf                   : std_logic;
    signal oe                       : std_logic_vector(31 downto 0);
    signal oe_long                  : std_logic_vector(31 downto 0);
    signal addr                     : std_logic_vector(15 downto 0);
    signal addr_msb                 : std_logic_vector(4 downto 0);
    signal addr_lsb                 : std_logic_vector(7 downto 0);
    signal read_data                : std_logic_array32(31 downto 0) := (others => (others => '0'));
    signal read_valid               : std_logic_vector(3 downto 0);

    component MPI_REG_WO is
    generic (
        BIT_WIDTH                   : natural := 32;
        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0');
        REG_DATA                    : std_logic_vector(31 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        EN                          : in  std_logic;
        ADDR                        : in  std_logic_vector(7 downto 0);
        DATA_IN                     : in  std_logic_vector(BIT_WIDTH-1 downto 0);
        DATA_OUT                    : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
    end component;

--    component COMP_CDC is
--    generic (
--        REG_DATA                    : std_logic_vector(31 downto 0) := (others => '0')
--    );
--    port (
--        RESET                       : in  std_logic;
--        CLK_IN                      : in  std_logic;
--        CLK_OUT                     : in  std_logic;
--
--        DATA_IN                     : in  std_logic_vector(31 downto 0);
--        DATA_OUT                    : out std_logic_vector(31 downto 0)
--    );
--    end component;

    component MPI_REG_RC is
    generic (
        BIT_WIDTH                   : natural := 32;
        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        EN                          : in  std_logic;
        ADDR                        : in  std_logic_vector(7 downto 0);
        DATA_IN                     : in  std_logic_vector(BIT_WIDTH-1 downto 0);
        DATA_OUT                    : out std_logic_vector(BIT_WIDTH-1 downto 0);
        FLAG_OUT                    : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
    end component;

    component MPI_CLEAR is
    generic (
        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        EN                          : in  std_logic;
        ADDR                        : in  std_logic_vector(7 downto 0);
        DATA_OUT                    : out std_logic
    );
    end component;

--    component MPI_CLEAR_CDC is
--    generic (
--        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0')
--    );
--    port (
--        RESET                       : in  std_logic;
--        CLK                         : in  std_logic;
--        CLK_TARGET                  : in  std_logic;
--
--        EN                          : in  std_logic;
--        ADDR                        : in  std_logic_vector(7 downto 0);
--        DATA_OUT                    : out std_logic
--    );
--    end component;

    -- ..._w : write
    -- ..._r : read
    -- ..._c : CDC
    -- ..._s : status
    -- ..._f : flag

    signal rx_param_mac_w           : std_logic_array64(DL_UNIT-1 downto 0);
    signal rx_param_mac_r           : std_logic_array64(15 downto 0);

    signal tx_param_dst_mac_w       : std_logic_array64(UL_UNIT-1 downto 0);
    signal tx_param_dst_mac_r       : std_logic_array64(15 downto 0);
    signal tx_param_src_mac_w       : std_logic_array64(UL_UNIT-1 downto 0);
    signal tx_param_src_mac_r       : std_logic_array64(15 downto 0);
    signal tx_param_vlan0_w         : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_param_vlan0_r         : std_logic_array32(15 downto 0);
    signal tx_param_vlan1_w         : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_param_vlan1_r         : std_logic_array32(15 downto 0);

    signal ignore_frame_id_w        : std_logic_array32(UL_UNIT-1 downto 0);
    signal ignore_frame_id_r        : std_logic_array32(15 downto 0);
    signal ignore_frame_id_puxch_r  : std_logic_array32(15 downto 0);
    signal ignore_frame_id_prach0_r : std_logic_array32(15 downto 0);
    signal ignore_frame_id_prach1_r : std_logic_array32(15 downto 0);
    signal ignore_frame_id_nbiot0_r : std_logic_array32(15 downto 0);
    signal ignore_frame_id_nbiot1_r : std_logic_array32(15 downto 0);
    signal ignore_frame_id_nbiot2_r : std_logic_array32(15 downto 0);

    signal rx_param_id0_w           : std_logic_array8_array32(DL_UNIT-1 downto 0);
    signal rx_param_id0_r           : std_logic_array8_array32(15 downto 0);
--    signal rx_param_id1_w           : std_logic_array8_array32(1 downto 0);
--    signal rx_param_id1_r           : std_logic_array8_array32(15 downto 0) := (others => (others => (others => '0')));
    signal rx_param_id2_w           : std_logic_array8_array32(1 downto 0);
    signal rx_param_id2_r           : std_logic_array8_array32(15 downto 0) := (others => (others => (others => '0')));
    signal rx_param_id3_w           : std_logic_array8_array32(DL_UNIT-1 downto 0);
    signal rx_param_id3_r           : std_logic_array8_array32(15 downto 0);

    signal rx_comp_mode_w           : std_logic_array32(DL_UNIT-1 downto 0);
    signal rx_comp_mode_r           : std_logic_array32(15 downto 0);
    signal rx_scs_config_w          : std_logic_array32(DL_UNIT-1 downto 0);
    signal rx_scs_config_r          : std_logic_array32(15 downto 0);
    signal rx_fft_size_w            : std_logic_array32(DL_UNIT-1 downto 0);
    signal rx_fft_size_r            : std_logic_array32(15 downto 0);
    signal rx_prb_per_symbol_w      : std_logic_array32(DL_UNIT-1 downto 0);
    signal rx_prb_per_symbol_r      : std_logic_array32(15 downto 0);
    signal rx_comp_exp_offset_w     : std_logic_array32(DL_UNIT-1 downto 0);
    signal rx_comp_exp_offset_r     : std_logic_array32(15 downto 0);

    signal tx_comp_mode_w           : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_comp_mode_r           : std_logic_array32(15 downto 0);
    signal tx_fft_size_w            : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_fft_size_r            : std_logic_array32(15 downto 0);
    signal tx_scs_config_w          : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_scs_config_r          : std_logic_array32(15 downto 0);
    signal tx_prb_per_symbol_w      : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_prb_per_symbol_r      : std_logic_array32(15 downto 0);
    signal tx_comp_exp_offset_w     : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_comp_exp_offset_r     : std_logic_array32(15 downto 0);
    signal tx_comp_gain_offset_w    : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_comp_gain_offset_r    : std_logic_array32(15 downto 0);
    signal tx_comp_scale_gain_offset_w: std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_comp_scale_gain_offset_r: std_logic_array32(15 downto 0);

    signal t2a_max_cp_dl_w          : std_logic_array32(DL_UNIT-1 downto 0);
    signal t2a_max_cp_dl_r          : std_logic_array32(15 downto 0);
    signal t2a_min_cp_dl_w          : std_logic_array32(DL_UNIT-1 downto 0);
    signal t2a_min_cp_dl_r          : std_logic_array32(15 downto 0);
    signal cp_dl_period_w           : std_logic_array32(DL_UNIT-1 downto 0);
    signal cp_dl_period_r           : std_logic_array32(15 downto 0);
    signal cp_dl_on_time_r          : std_logic_array64(15 downto 0);
    signal cp_dl_early_r            : std_logic_array64(15 downto 0);
    signal cp_dl_late_r             : std_logic_array64(15 downto 0);
    signal cp_dl_out_of_range_r     : std_logic_array64(15 downto 0);
    signal t2a_max_up_dl_w          : std_logic_array32(DL_UNIT-1 downto 0);
    signal t2a_max_up_dl_r          : std_logic_array32(15 downto 0);
    signal t2a_min_up_dl_w          : std_logic_array32(DL_UNIT-1 downto 0);
    signal t2a_min_up_dl_r          : std_logic_array32(15 downto 0);
    signal up_dl_period_w           : std_logic_array32(DL_UNIT-1 downto 0);
    signal up_dl_period_r           : std_logic_array32(15 downto 0);
    signal up_dl_on_time_r          : std_logic_array64(15 downto 0);
    signal up_dl_early_r            : std_logic_array64(15 downto 0);
    signal up_dl_late_r             : std_logic_array64(15 downto 0);
    signal up_dl_out_of_range_r     : std_logic_array64(15 downto 0);
    signal t2a_max_cp_ul_w          : std_logic_array32(UL_UNIT-1 downto 0);
    signal t2a_max_cp_ul_r          : std_logic_array32(15 downto 0);
    signal t2a_min_cp_ul_w          : std_logic_array32(UL_UNIT-1 downto 0);
    signal t2a_min_cp_ul_r          : std_logic_array32(15 downto 0);
    signal cp_ul_period_w           : std_logic_array32(UL_UNIT-1 downto 0);
    signal cp_ul_period_r           : std_logic_array32(15 downto 0);
    signal cp_ul_on_time_r          : std_logic_array64(15 downto 0);
    signal cp_ul_early_r            : std_logic_array64(15 downto 0);
    signal cp_ul_late_r             : std_logic_array64(15 downto 0);
    signal cp_ul_out_of_range_r     : std_logic_array64(15 downto 0);
--    signal ta3_min_up0_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_min_up0_ul_r         : std_logic_array32(15 downto 0);
--    signal ta3_max_up0_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_max_up0_ul_r         : std_logic_array32(15 downto 0);
    signal up0_ul_period_w          : std_logic_array32(UL_UNIT-1 downto 0);
    signal up0_ul_period_r          : std_logic_array32(15 downto 0);
    signal up0_ul_on_time_r         : std_logic_array64(15 downto 0);
    signal up0_ul_early_r           : std_logic_array64(15 downto 0);
    signal up0_ul_late_r            : std_logic_array64(15 downto 0);
    signal up0_ul_out_of_range_r    : std_logic_array64(15 downto 0);
--    signal ta3_min_up1_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_min_up1_ul_r         : std_logic_array32(15 downto 0);
--    signal ta3_max_up1_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_max_up1_ul_r         : std_logic_array32(15 downto 0);
    signal up1_ul_period_w          : std_logic_array32(UL_UNIT-1 downto 0);
    signal up1_ul_period_r          : std_logic_array32(15 downto 0);
    signal up1_ul_on_time_r         : std_logic_array64(15 downto 0);
    signal up1_ul_early_r           : std_logic_array64(15 downto 0);
    signal up1_ul_late_r            : std_logic_array64(15 downto 0);
    signal up1_ul_out_of_range_r    : std_logic_array64(15 downto 0);
--    signal ta3_min_up2_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_min_up2_ul_r         : std_logic_array32(15 downto 0);
--    signal ta3_max_up2_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_max_up2_ul_r         : std_logic_array32(15 downto 0);
    signal up2_ul_period_w          : std_logic_array32(UL_UNIT-1 downto 0);
    signal up2_ul_period_r          : std_logic_array32(15 downto 0);
    signal up2_ul_on_time_r         : std_logic_array64(15 downto 0);
    signal up2_ul_early_r           : std_logic_array64(15 downto 0);
    signal up2_ul_late_r            : std_logic_array64(15 downto 0);
    signal up2_ul_out_of_range_r    : std_logic_array64(15 downto 0);
--    signal ta3_min_up3_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_min_up3_ul_r         : std_logic_array32(15 downto 0);
--    signal ta3_max_up3_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_max_up3_ul_r         : std_logic_array32(15 downto 0);
    signal up3_ul_period_w          : std_logic_array32(UL_UNIT-1 downto 0);
    signal up3_ul_period_r          : std_logic_array32(15 downto 0);
    signal up3_ul_on_time_r         : std_logic_array64(15 downto 0);
    signal up3_ul_early_r           : std_logic_array64(15 downto 0);
    signal up3_ul_late_r            : std_logic_array64(15 downto 0);
    signal up3_ul_out_of_range_r    : std_logic_array64(15 downto 0);
--    signal ta3_min_up4_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_min_up4_ul_r         : std_logic_array32(15 downto 0);
--    signal ta3_max_up4_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_max_up4_ul_r         : std_logic_array32(15 downto 0);
    signal up4_ul_period_w          : std_logic_array32(UL_UNIT-1 downto 0);
    signal up4_ul_period_r          : std_logic_array32(15 downto 0);
    signal up4_ul_on_time_r         : std_logic_array64(15 downto 0);
    signal up4_ul_early_r           : std_logic_array64(15 downto 0);
    signal up4_ul_late_r            : std_logic_array64(15 downto 0);
    signal up4_ul_out_of_range_r    : std_logic_array64(15 downto 0);
--    signal ta3_min_up5_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_min_up5_ul_r         : std_logic_array32(15 downto 0);
--    signal ta3_max_up5_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_max_up5_ul_r         : std_logic_array32(15 downto 0);
    signal up5_ul_period_w          : std_logic_array32(UL_UNIT-1 downto 0);
    signal up5_ul_period_r          : std_logic_array32(15 downto 0);
    signal up5_ul_on_time_r         : std_logic_array64(15 downto 0);
    signal up5_ul_early_r           : std_logic_array64(15 downto 0);
    signal up5_ul_late_r            : std_logic_array64(15 downto 0);
    signal up5_ul_out_of_range_r    : std_logic_array64(15 downto 0);

    signal rx_fault_id_31_ch0_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch0_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch0_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch0_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch0_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch0_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch0_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch0_3_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_3_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_3_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_3_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_3_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_3_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_3_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_3_f   : std_logic_array32(15 downto 0);

    signal rx_invalid_dst_mac_r     : std_logic_array32(15 downto 0);
    signal rx_invalid_ethertype_r   : std_logic_array32(15 downto 0);
    signal rx_invalid_ecpriver_r    : std_logic_array32(15 downto 0);
    signal rx_invalid_ecpric_r      : std_logic_array32(15 downto 0);
    signal rx_invalid_ecprimsg_r    : std_logic_array32(15 downto 0);
    signal rx_lost_r                : std_logic_array32(15 downto 0);

    signal rx_c_plane_exist_r       : std_logic_array32(15 downto 0);
    signal rx_c_plane_exist_f       : std_logic_array32(15 downto 0);
    signal rx_c_plane_r             : std_logic_array32(15 downto 0);
    signal rx_c_plane_dropped_r     : std_logic_array32(15 downto 0);
    signal rx_c_plane_buffer_r      : std_logic_array32(15 downto 0);
    signal rx_c_plane_buffer_f      : std_logic_array32(15 downto 0);
    signal rx_u_plane_exist_r       : std_logic_array32(15 downto 0);
    signal rx_u_plane_exist_f       : std_logic_array32(15 downto 0);
    signal rx_u_plane_r             : std_logic_array32(15 downto 0);
    signal rx_u_plane_dropped_r     : std_logic_array32(15 downto 0);
    signal rx_u_plane_buffer_r      : std_logic_array32(15 downto 0);
    signal rx_u_plane_buffer_f      : std_logic_array32(15 downto 0);

--    signal tx0_c_plane_r            : std_logic_array32(15 downto 0);
--    signal tx0_c_plane_lost_r       : std_logic_array32(15 downto 0);
--    signal tx0_c_plane_buffer_r     : std_logic_array32(15 downto 0);
--    signal tx0_c_plane_buffer_f     : std_logic_array32(15 downto 0);
    signal tx0_u_plane_r            : std_logic_array32(15 downto 0);
    signal tx0_u_plane_lost_r       : std_logic_array32(15 downto 0);
    signal tx0_u_plane_buffer_r     : std_logic_array32(15 downto 0);
    signal tx0_u_plane_buffer_f     : std_logic_array32(15 downto 0);

--    signal tx1_c_plane_r            : std_logic_array32(15 downto 0);
--    signal tx1_c_plane_lost_r       : std_logic_array32(15 downto 0);
--    signal tx1_c_plane_buffer_r     : std_logic_array32(15 downto 0);
--    signal tx1_c_plane_buffer_f     : std_logic_array32(15 downto 0);
    signal tx1_u_plane_r            : std_logic_array32(15 downto 0);
    signal tx1_u_plane_lost_r       : std_logic_array32(15 downto 0);
    signal tx1_u_plane_buffer_r     : std_logic_array32(15 downto 0);
    signal tx1_u_plane_buffer_f     : std_logic_array32(15 downto 0);

--    signal tx2_c_plane_r            : std_logic_array32(15 downto 0);
--    signal tx2_c_plane_lost_r       : std_logic_array32(15 downto 0);
--    signal tx2_c_plane_buffer_r     : std_logic_array32(15 downto 0);
--    signal tx2_c_plane_buffer_f     : std_logic_array32(15 downto 0);
    signal tx2_u_plane_r            : std_logic_array32(15 downto 0);
    signal tx2_u_plane_lost_r       : std_logic_array32(15 downto 0);
    signal tx2_u_plane_buffer_r     : std_logic_array32(15 downto 0);
    signal tx2_u_plane_buffer_f     : std_logic_array32(15 downto 0);

--    signal tx3_c_plane_r            : std_logic_array32(15 downto 0);
--    signal tx3_c_plane_lost_r       : std_logic_array32(15 downto 0);
--    signal tx3_c_plane_buffer_r     : std_logic_array32(15 downto 0);
--    signal tx3_c_plane_buffer_f     : std_logic_array32(15 downto 0);
    signal tx3_u_plane_r            : std_logic_array32(15 downto 0);
    signal tx3_u_plane_lost_r       : std_logic_array32(15 downto 0);
    signal tx3_u_plane_buffer_r     : std_logic_array32(15 downto 0);
    signal tx3_u_plane_buffer_f     : std_logic_array32(15 downto 0);

--    signal tx4_c_plane_r            : std_logic_array32(15 downto 0);
--    signal tx4_c_plane_lost_r       : std_logic_array32(15 downto 0);
--    signal tx4_c_plane_buffer_r     : std_logic_array32(15 downto 0);
--    signal tx4_c_plane_buffer_f     : std_logic_array32(15 downto 0);
    signal tx4_u_plane_r            : std_logic_array32(15 downto 0);
    signal tx4_u_plane_lost_r       : std_logic_array32(15 downto 0);
    signal tx4_u_plane_buffer_r     : std_logic_array32(15 downto 0);
    signal tx4_u_plane_buffer_f     : std_logic_array32(15 downto 0);

--    signal tx5_c_plane_r            : std_logic_array32(15 downto 0);
--    signal tx5_c_plane_lost_r       : std_logic_array32(15 downto 0);
--    signal tx5_c_plane_buffer_r     : std_logic_array32(15 downto 0);
--    signal tx5_c_plane_buffer_f     : std_logic_array32(15 downto 0);
    signal tx5_u_plane_r            : std_logic_array32(15 downto 0);
    signal tx5_u_plane_lost_r       : std_logic_array32(15 downto 0);
    signal tx5_u_plane_buffer_r     : std_logic_array32(15 downto 0);
    signal tx5_u_plane_buffer_f     : std_logic_array32(15 downto 0);

    signal tx_cmd_fifo_full_r       : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_termination_r        : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol0_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol1_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol2_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol3_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol4_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol5_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol6_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol7_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol8_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol9_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol10_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol11_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol12_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol13_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol0_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol0_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol1_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol1_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol2_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol2_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol3_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol3_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol4_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol4_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol5_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol5_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol6_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol6_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol7_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol7_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol8_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol8_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol9_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol9_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol10_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol10_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol11_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol11_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol12_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol12_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol13_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol13_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));

    signal tx1_termination_r        : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol0_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol1_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol2_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol3_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol4_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol5_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol6_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol7_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol8_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol9_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol10_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol11_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol12_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol13_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol0_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol0_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol1_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol1_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol2_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol2_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol3_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol3_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol4_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol4_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol5_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol5_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol6_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol6_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol7_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol7_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol8_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol8_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol9_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol9_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol10_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol10_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol11_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol11_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol12_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol12_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol13_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol13_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));

    signal tx2_termination_r        : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cpsec_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cpsec_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cpsec_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cpsec_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cpsec_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cpsec_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cpsec_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cpsec_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cpsec_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cpsec_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cpsec_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cpsec_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cpsec_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cpsec_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_uppkt_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_uppkt_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_uppkt_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_uppkt_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_uppkt_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_uppkt_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_uppkt_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_uppkt_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_uppkt_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_uppkt_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_uppkt_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_uppkt_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_uppkt_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_uppkt_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_full_symbol0_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_full_symbol1_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_full_symbol2_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_full_symbol3_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_full_symbol4_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_full_symbol5_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_full_symbol6_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_full_symbol7_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_full_symbol8_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_full_symbol9_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_full_symbol10_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_full_symbol11_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_full_symbol12_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_full_symbol13_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol0_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol0_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol1_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol1_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol2_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol2_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol3_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol3_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol4_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol4_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol5_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol5_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol6_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol6_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol7_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol7_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol8_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol8_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol9_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol9_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol10_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol10_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol11_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol11_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol12_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol12_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol13_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx2_cq_usage_symbol13_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));

    signal tx3_termination_r        : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cpsec_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cpsec_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cpsec_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cpsec_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cpsec_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cpsec_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cpsec_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cpsec_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cpsec_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cpsec_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cpsec_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cpsec_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cpsec_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cpsec_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_uppkt_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_uppkt_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_uppkt_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_uppkt_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_uppkt_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_uppkt_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_uppkt_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_uppkt_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_uppkt_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_uppkt_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_uppkt_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_uppkt_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_uppkt_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_uppkt_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_full_symbol0_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_full_symbol1_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_full_symbol2_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_full_symbol3_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_full_symbol4_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_full_symbol5_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_full_symbol6_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_full_symbol7_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_full_symbol8_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_full_symbol9_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_full_symbol10_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_full_symbol11_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_full_symbol12_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_full_symbol13_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol0_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol0_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol1_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol1_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol2_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol2_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol3_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol3_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol4_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol4_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol5_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol5_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol6_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol6_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol7_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol7_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol8_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol8_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol9_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol9_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol10_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol10_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol11_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol11_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol12_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol12_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol13_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx3_cq_usage_symbol13_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));

    signal tx4_termination_r        : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cpsec_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cpsec_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cpsec_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cpsec_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cpsec_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cpsec_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cpsec_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cpsec_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cpsec_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cpsec_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cpsec_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cpsec_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cpsec_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cpsec_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_uppkt_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_uppkt_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_uppkt_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_uppkt_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_uppkt_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_uppkt_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_uppkt_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_uppkt_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_uppkt_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_uppkt_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_uppkt_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_uppkt_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_uppkt_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_uppkt_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_full_symbol0_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_full_symbol1_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_full_symbol2_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_full_symbol3_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_full_symbol4_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_full_symbol5_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_full_symbol6_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_full_symbol7_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_full_symbol8_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_full_symbol9_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_full_symbol10_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_full_symbol11_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_full_symbol12_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_full_symbol13_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol0_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol0_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol1_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol1_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol2_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol2_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol3_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol3_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol4_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol4_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol5_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol5_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol6_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol6_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol7_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol7_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol8_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol8_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol9_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol9_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol10_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol10_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol11_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol11_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol12_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol12_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol13_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx4_cq_usage_symbol13_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));

    signal tx5_termination_r        : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cpsec_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cpsec_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cpsec_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cpsec_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cpsec_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cpsec_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cpsec_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cpsec_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cpsec_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cpsec_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cpsec_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cpsec_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cpsec_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cpsec_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_uppkt_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_uppkt_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_uppkt_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_uppkt_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_uppkt_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_uppkt_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_uppkt_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_uppkt_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_uppkt_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_uppkt_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_uppkt_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_uppkt_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_uppkt_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_uppkt_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_full_symbol0_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_full_symbol1_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_full_symbol2_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_full_symbol3_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_full_symbol4_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_full_symbol5_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_full_symbol6_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_full_symbol7_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_full_symbol8_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_full_symbol9_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_full_symbol10_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_full_symbol11_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_full_symbol12_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_full_symbol13_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol0_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol0_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol1_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol1_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol2_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol2_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol3_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol3_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol4_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol4_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol5_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol5_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol6_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol6_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol7_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol7_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol8_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol8_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol9_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol9_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol10_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol10_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol11_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol11_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol12_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol12_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol13_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx5_cq_usage_symbol13_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));

begin

--------------------------------------------------------------------------------
-- WE/OE, address decoding
--------------------------------------------------------------------------------

    addr     <= "000" & ADDR_CPUIF_IN(12 downto 0) when OFFSET(0) = '0' else
                "000" & (not ADDR_CPUIF_IN(12)) & ADDR_CPUIF_IN(11 downto 0);
    addr_msb <= addr(12 downto 8);
    addr_lsb <= addr(7 downto 0);

    process (RST, CLK)
    begin
        if (RST = '1') then
            we_buf <= '0';
            oe_buf <= '0';
        elsif (CLK'event and CLK = '1') then
            we_buf <= WREN_CPUIF_IN;
            oe_buf <= RDEN_CPUIF_IN;
        end if;
    end process;

    u_WE_OE : for i in 31 downto 0 generate
    -- read/write (short pulse)
    process (RST, CLK)
    begin
        if (RST = '1') then
            we(i) <= '0';
            oe(i) <= '0';
        elsif (CLK'event and CLK = '1') then
            if (addr_msb = i) then
                if (WREN_CPUIF_IN = '1') and (we_buf = '0') then
                    we(i) <= '1';
                else
                    we(i) <= '0';
                end if;
                if (RDEN_CPUIF_IN = '1') and (oe_buf = '0') then
                    oe(i) <= '1';
                else
                    oe(i) <= '0';
                end if;
            else
                we(i) <= '0';
                oe(i) <= '0';
            end if;
        end if;
    end process;

    -- read/write (long pulse)
    process (RST, CLK)
    begin
        if (RST = '1') then
            we_long(i) <= '0';
            oe_long(i) <= '0';
        elsif (CLK'event and CLK = '1') then
            if (addr_msb = i) then
                if (WREN_CPUIF_IN = '1') then
                    we_long(i) <= '1';
                else
                    we_long(i) <= '0';
                end if;
                if (RDEN_CPUIF_IN = '1') then
                    oe_long(i) <= '1';
                else
                    oe_long(i) <= '0';
                end if;
            else
                we_long(i) <= '0';
                oe_long(i) <= '0';
            end if;
        end if;
    end process;
    end generate;

    process (RST, CLK)
    begin
        if (RST = '1') then
            read_valid      <= (others => '0');
            RDVAL_CPUIF_OUT <= '0';
        elsif (CLK'event and CLK = '1') then
            read_valid      <= read_valid(2 downto 0) & RDEN_CPUIF_IN;
            if (read_valid(3 downto 2) = "01") then
                RDVAL_CPUIF_OUT <= '1';
            else
                RDVAL_CPUIF_OUT <= '0';
            end if;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Read Mux
--------------------------------------------------------------------------------

    process (RST, CLK)
    begin
        if (RST = '1') then
            RDATA_CPUIF_OUT <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            case addr_msb is
            when "00000" => RDATA_CPUIF_OUT <= read_data(0);
            when "00001" => RDATA_CPUIF_OUT <= read_data(1);
            when "00010" => RDATA_CPUIF_OUT <= read_data(2);
            when "00011" => RDATA_CPUIF_OUT <= read_data(3);
            when "00100" => RDATA_CPUIF_OUT <= read_data(4);
            when "00101" => RDATA_CPUIF_OUT <= read_data(5);
            when "00110" => RDATA_CPUIF_OUT <= read_data(6);
            when "00111" => RDATA_CPUIF_OUT <= read_data(7);
            when "01000" => RDATA_CPUIF_OUT <= read_data(8);
            when "01001" => RDATA_CPUIF_OUT <= read_data(9);
            when "01010" => RDATA_CPUIF_OUT <= read_data(10);
            when "01011" => RDATA_CPUIF_OUT <= read_data(11);
            when "01100" => RDATA_CPUIF_OUT <= read_data(12);
            when "01101" => RDATA_CPUIF_OUT <= read_data(13);
            when "01110" => RDATA_CPUIF_OUT <= read_data(14);
            when "01111" => RDATA_CPUIF_OUT <= read_data(15);
            when "10000" => RDATA_CPUIF_OUT <= read_data(16);
            when "10001" => RDATA_CPUIF_OUT <= read_data(17);
            when "10010" => RDATA_CPUIF_OUT <= read_data(18);
            when "10011" => RDATA_CPUIF_OUT <= read_data(19);
            when "10100" => RDATA_CPUIF_OUT <= read_data(20);
            when "10101" => RDATA_CPUIF_OUT <= read_data(21);
            when "10110" => RDATA_CPUIF_OUT <= read_data(22);
            when "10111" => RDATA_CPUIF_OUT <= read_data(23);
            when "11000" => RDATA_CPUIF_OUT <= read_data(24);
            when "11001" => RDATA_CPUIF_OUT <= read_data(25);
            when "11010" => RDATA_CPUIF_OUT <= read_data(26);
            when "11011" => RDATA_CPUIF_OUT <= read_data(27);
            when "11100" => RDATA_CPUIF_OUT <= read_data(28);
            when "11101" => RDATA_CPUIF_OUT <= read_data(29);
            when "11110" => RDATA_CPUIF_OUT <= read_data(30);
            when "11111" => RDATA_CPUIF_OUT <= read_data(31);
            when others  => RDATA_CPUIF_OUT <= (others => '0');
            end case;
        end if;
    end process;

    u_READ_0_to_7 : for i in 7 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (addr_msb = i) then
                case addr_lsb is
                when x"00"  => read_data(i) <= rx_param_mac_r(i)(31 downto 0);
                when x"01"  => read_data(i) <= rx_param_mac_r(i)(63 downto 32);

                when x"10"  => read_data(i) <= tx_param_dst_mac_r(i)(31 downto 0);
                when x"11"  => read_data(i) <= tx_param_dst_mac_r(i)(63 downto 32);
                when x"12"  => read_data(i) <= tx_param_src_mac_r(i)(31 downto 0);
                when x"13"  => read_data(i) <= tx_param_src_mac_r(i)(63 downto 32);
                when x"14"  => read_data(i) <= tx_param_vlan0_r(i);
                when x"15"  => read_data(i) <= tx_param_vlan1_r(i);

                when x"18"  => read_data(i) <= ignore_frame_id_r(i);
                when x"1A"  => read_data(i) <= ignore_frame_id_puxch_r(i);
                when x"1B"  => read_data(i) <= ignore_frame_id_prach0_r(i);
                when x"1C"  => read_data(i) <= ignore_frame_id_prach1_r(i);
                when x"1D"  => read_data(i) <= ignore_frame_id_nbiot0_r(i);
                when x"1E"  => read_data(i) <= ignore_frame_id_nbiot1_r(i);
                when x"1F"  => read_data(i) <= ignore_frame_id_nbiot2_r(i);

                when x"20"  => read_data(i) <= rx_param_id0_r(i)(0);
--                when x"21"  => read_data(i) <= rx_param_id1_r(i)(0);
                when x"22"  => read_data(i) <= rx_param_id2_r(i)(0);
                when x"23"  => read_data(i) <= rx_param_id3_r(i)(0);
                when x"24"  => read_data(i) <= rx_param_id0_r(i)(1);
--                when x"25"  => read_data(i) <= rx_param_id1_r(i)(1);
                when x"26"  => read_data(i) <= rx_param_id2_r(i)(1);
                when x"27"  => read_data(i) <= rx_param_id3_r(i)(1);
                when x"28"  => read_data(i) <= rx_param_id0_r(i)(2);
--                when x"29"  => read_data(i) <= rx_param_id1_r(i)(2);
                when x"2A"  => read_data(i) <= rx_param_id2_r(i)(2);
                when x"2B"  => read_data(i) <= rx_param_id3_r(i)(2);
                when x"2C"  => read_data(i) <= rx_param_id0_r(i)(3);
--                when x"2D"  => read_data(i) <= rx_param_id1_r(i)(3);
                when x"2E"  => read_data(i) <= rx_param_id2_r(i)(3);
                when x"2F"  => read_data(i) <= rx_param_id3_r(i)(3);
                when x"30"  => read_data(i) <= rx_param_id0_r(i)(4);
--                when x"31"  => read_data(i) <= rx_param_id1_r(i)(4);
                when x"32"  => read_data(i) <= rx_param_id2_r(i)(4);
                when x"33"  => read_data(i) <= rx_param_id3_r(i)(4);
                when x"34"  => read_data(i) <= rx_param_id0_r(i)(5);
--                when x"35"  => read_data(i) <= rx_param_id1_r(i)(5);
                when x"36"  => read_data(i) <= rx_param_id2_r(i)(5);
                when x"37"  => read_data(i) <= rx_param_id3_r(i)(5);
                when x"38"  => read_data(i) <= rx_param_id0_r(i)(6);
--                when x"39"  => read_data(i) <= rx_param_id1_r(i)(6);
                when x"3A"  => read_data(i) <= rx_param_id2_r(i)(6);
                when x"3B"  => read_data(i) <= rx_param_id3_r(i)(6);
                when x"3C"  => read_data(i) <= rx_param_id0_r(i)(7);
--                when x"3D"  => read_data(i) <= rx_param_id1_r(i)(7);
                when x"3E"  => read_data(i) <= rx_param_id2_r(i)(7);
                when x"3F"  => read_data(i) <= rx_param_id3_r(i)(7);

                when x"40"  => read_data(i) <= rx_comp_mode_r(i);
                when x"41"  => read_data(i) <= rx_scs_config_r(i);
                when x"42"  => read_data(i) <= rx_fft_size_r(i);
                when x"43"  => read_data(i) <= rx_prb_per_symbol_r(i);
                when x"44"  => read_data(i) <= rx_comp_exp_offset_r(i);

                when x"50"  => read_data(i) <= tx_comp_mode_r(i);
                when x"51"  => read_data(i) <= tx_scs_config_r(i);
                when x"52"  => read_data(i) <= tx_fft_size_r(i);
                when x"53"  => read_data(i) <= tx_prb_per_symbol_r(i);
                when x"54"  => read_data(i) <= tx_comp_exp_offset_r(i);
                when x"55"  => read_data(i) <= tx_comp_gain_offset_r(i);
                when x"56"  => read_data(i) <= tx_comp_scale_gain_offset_r(i);

                when x"60"  => read_data(i) <= t2a_max_cp_dl_r(i);
                when x"61"  => read_data(i) <= t2a_min_cp_dl_r(i);
                when x"62"  => read_data(i) <= cp_dl_period_r(i);
                when x"64"  => read_data(i) <= cp_dl_on_time_r(i)(63 downto 32);
                when x"65"  => read_data(i) <= cp_dl_on_time_r(i)(31 downto 0);
                when x"66"  => read_data(i) <= cp_dl_early_r(i)(63 downto 32);
                when x"67"  => read_data(i) <= cp_dl_early_r(i)(31 downto 0);
                when x"68"  => read_data(i) <= cp_dl_late_r(i)(63 downto 32);
                when x"69"  => read_data(i) <= cp_dl_late_r(i)(31 downto 0);
                when x"6A"  => read_data(i) <= cp_dl_out_of_range_r(i)(63 downto 32);
                when x"6B"  => read_data(i) <= cp_dl_out_of_range_r(i)(31 downto 0);

                when x"70"  => read_data(i) <= t2a_max_up_dl_r(i);
                when x"71"  => read_data(i) <= t2a_min_up_dl_r(i);
                when x"72"  => read_data(i) <= up_dl_period_r(i);
                when x"74"  => read_data(i) <= up_dl_on_time_r(i)(63 downto 32);
                when x"75"  => read_data(i) <= up_dl_on_time_r(i)(31 downto 0);
                when x"76"  => read_data(i) <= up_dl_early_r(i)(63 downto 32);
                when x"77"  => read_data(i) <= up_dl_early_r(i)(31 downto 0);
                when x"78"  => read_data(i) <= up_dl_late_r(i)(63 downto 32);
                when x"79"  => read_data(i) <= up_dl_late_r(i)(31 downto 0);
                when x"7A"  => read_data(i) <= up_dl_out_of_range_r(i)(63 downto 32);
                when x"7B"  => read_data(i) <= up_dl_out_of_range_r(i)(31 downto 0);

                when x"80"  => read_data(i) <= t2a_max_cp_ul_r(i);
                when x"81"  => read_data(i) <= t2a_min_cp_ul_r(i);
                when x"82"  => read_data(i) <= cp_ul_period_r(i);
                when x"84"  => read_data(i) <= cp_ul_on_time_r(i)(63 downto 32);
                when x"85"  => read_data(i) <= cp_ul_on_time_r(i)(31 downto 0);
                when x"86"  => read_data(i) <= cp_ul_early_r(i)(63 downto 32);
                when x"87"  => read_data(i) <= cp_ul_early_r(i)(31 downto 0);
                when x"88"  => read_data(i) <= cp_ul_late_r(i)(63 downto 32);
                when x"89"  => read_data(i) <= cp_ul_late_r(i)(31 downto 0);
                when x"8A"  => read_data(i) <= cp_ul_out_of_range_r(i)(63 downto 32);
                when x"8B"  => read_data(i) <= cp_ul_out_of_range_r(i)(31 downto 0);

--                when x"90"  => read_data(i) <= ta3_min_up0_ul_r(i);
--                when x"91"  => read_data(i) <= ta3_max_up0_ul_r(i);
                when x"92"  => read_data(i) <= up0_ul_period_r(i);
                when x"94"  => read_data(i) <= up0_ul_on_time_r(i)(63 downto 32);
                when x"95"  => read_data(i) <= up0_ul_on_time_r(i)(31 downto 0);
                when x"96"  => read_data(i) <= up0_ul_early_r(i)(63 downto 32);
                when x"97"  => read_data(i) <= up0_ul_early_r(i)(31 downto 0);
                when x"98"  => read_data(i) <= up0_ul_late_r(i)(63 downto 32);
                when x"99"  => read_data(i) <= up0_ul_late_r(i)(31 downto 0);
                when x"9A"  => read_data(i) <= up0_ul_out_of_range_r(i)(63 downto 32);
                when x"9B"  => read_data(i) <= up0_ul_out_of_range_r(i)(31 downto 0);

--                when x"A0"  => read_data(i) <= ta3_min_up1_ul_r(i);
--                when x"A1"  => read_data(i) <= ta3_max_up1_ul_r(i);
                when x"A2"  => read_data(i) <= up1_ul_period_r(i);
                when x"A4"  => read_data(i) <= up1_ul_on_time_r(i)(63 downto 32);
                when x"A5"  => read_data(i) <= up1_ul_on_time_r(i)(31 downto 0);
                when x"A6"  => read_data(i) <= up1_ul_early_r(i)(63 downto 32);
                when x"A7"  => read_data(i) <= up1_ul_early_r(i)(31 downto 0);
                when x"A8"  => read_data(i) <= up1_ul_late_r(i)(63 downto 32);
                when x"A9"  => read_data(i) <= up1_ul_late_r(i)(31 downto 0);
                when x"AA"  => read_data(i) <= up1_ul_out_of_range_r(i)(63 downto 32);
                when x"AB"  => read_data(i) <= up1_ul_out_of_range_r(i)(31 downto 0);

--                when x"B0"  => read_data(i) <= ta3_min_up2_ul_r(i);
--                when x"B1"  => read_data(i) <= ta3_max_up2_ul_r(i);
                when x"B2"  => read_data(i) <= up2_ul_period_r(i);
                when x"B4"  => read_data(i) <= up2_ul_on_time_r(i)(63 downto 32);
                when x"B5"  => read_data(i) <= up2_ul_on_time_r(i)(31 downto 0);
                when x"B6"  => read_data(i) <= up2_ul_early_r(i)(63 downto 32);
                when x"B7"  => read_data(i) <= up2_ul_early_r(i)(31 downto 0);
                when x"B8"  => read_data(i) <= up2_ul_late_r(i)(63 downto 32);
                when x"B9"  => read_data(i) <= up2_ul_late_r(i)(31 downto 0);
                when x"BA"  => read_data(i) <= up2_ul_out_of_range_r(i)(63 downto 32);
                when x"BB"  => read_data(i) <= up2_ul_out_of_range_r(i)(31 downto 0);

--                when x"C0"  => read_data(i) <= ta3_min_up3_ul_r(i);
--                when x"C1"  => read_data(i) <= ta3_max_up3_ul_r(i);
                when x"C2"  => read_data(i) <= up3_ul_period_r(i);
                when x"C4"  => read_data(i) <= up3_ul_on_time_r(i)(63 downto 32);
                when x"C5"  => read_data(i) <= up3_ul_on_time_r(i)(31 downto 0);
                when x"C6"  => read_data(i) <= up3_ul_early_r(i)(63 downto 32);
                when x"C7"  => read_data(i) <= up3_ul_early_r(i)(31 downto 0);
                when x"C8"  => read_data(i) <= up3_ul_late_r(i)(63 downto 32);
                when x"C9"  => read_data(i) <= up3_ul_late_r(i)(31 downto 0);
                when x"CA"  => read_data(i) <= up3_ul_out_of_range_r(i)(63 downto 32);
                when x"CB"  => read_data(i) <= up3_ul_out_of_range_r(i)(31 downto 0);

--                when x"D0"  => read_data(i) <= ta3_min_up4_ul_r(i);
--                when x"D1"  => read_data(i) <= ta3_max_up4_ul_r(i);
                when x"D2"  => read_data(i) <= up4_ul_period_r(i);
                when x"D4"  => read_data(i) <= up4_ul_on_time_r(i)(63 downto 32);
                when x"D5"  => read_data(i) <= up4_ul_on_time_r(i)(31 downto 0);
                when x"D6"  => read_data(i) <= up4_ul_early_r(i)(63 downto 32);
                when x"D7"  => read_data(i) <= up4_ul_early_r(i)(31 downto 0);
                when x"D8"  => read_data(i) <= up4_ul_late_r(i)(63 downto 32);
                when x"D9"  => read_data(i) <= up4_ul_late_r(i)(31 downto 0);
                when x"DA"  => read_data(i) <= up4_ul_out_of_range_r(i)(63 downto 32);
                when x"DB"  => read_data(i) <= up4_ul_out_of_range_r(i)(31 downto 0);

--                when x"E0"  => read_data(i) <= ta3_min_up5_ul_r(i);
--                when x"E1"  => read_data(i) <= ta3_max_up5_ul_r(i);
                when x"E2"  => read_data(i) <= up5_ul_period_r(i);
                when x"E4"  => read_data(i) <= up5_ul_on_time_r(i)(63 downto 32);
                when x"E5"  => read_data(i) <= up5_ul_on_time_r(i)(31 downto 0);
                when x"E6"  => read_data(i) <= up5_ul_early_r(i)(63 downto 32);
                when x"E7"  => read_data(i) <= up5_ul_early_r(i)(31 downto 0);
                when x"E8"  => read_data(i) <= up5_ul_late_r(i)(63 downto 32);
                when x"E9"  => read_data(i) <= up5_ul_late_r(i)(31 downto 0);
                when x"EA"  => read_data(i) <= up5_ul_out_of_range_r(i)(63 downto 32);
                when x"EB"  => read_data(i) <= up5_ul_out_of_range_r(i)(31 downto 0);

                when others => read_data(i) <= (others => '0');
                end case;
            end if;
        end if;
    end process;
    end generate;

    u_READ_8_to_11 : for i in 3 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (addr_msb = i+8) then
                case addr_lsb is
                when x"20"  => read_data(i+8) <= rx_fault_id_31_ch0_0_f(i);
                when x"21"  => read_data(i+8) <= rx_fault_id_31_ch0_1_f(i);
                when x"22"  => read_data(i+8) <= rx_fault_id_31_ch0_2_f(i);
                when x"23"  => read_data(i+8) <= rx_fault_id_31_ch0_3_f(i);
                when x"24"  => read_data(i+8) <= rx_fault_id_31_ch1_0_f(i);
                when x"25"  => read_data(i+8) <= rx_fault_id_31_ch1_1_f(i);
                when x"26"  => read_data(i+8) <= rx_fault_id_31_ch1_2_f(i);
                when x"27"  => read_data(i+8) <= rx_fault_id_31_ch1_3_f(i);
                when x"28"  => read_data(i+8) <= rx_fault_id_31_ch2_0_f(i);
                when x"29"  => read_data(i+8) <= rx_fault_id_31_ch2_1_f(i);
                when x"2A"  => read_data(i+8) <= rx_fault_id_31_ch2_2_f(i);
                when x"2B"  => read_data(i+8) <= rx_fault_id_31_ch2_3_f(i);
                when x"2C"  => read_data(i+8) <= rx_fault_id_31_ch3_0_f(i);
                when x"2D"  => read_data(i+8) <= rx_fault_id_31_ch3_1_f(i);
                when x"2E"  => read_data(i+8) <= rx_fault_id_31_ch3_2_f(i);
                when x"2F"  => read_data(i+8) <= rx_fault_id_31_ch3_3_f(i);
                when x"30"  => read_data(i+8) <= rx_fault_id_31_ch4_0_f(i);
                when x"31"  => read_data(i+8) <= rx_fault_id_31_ch4_1_f(i);
                when x"32"  => read_data(i+8) <= rx_fault_id_31_ch4_2_f(i);
                when x"33"  => read_data(i+8) <= rx_fault_id_31_ch4_3_f(i);
                when x"34"  => read_data(i+8) <= rx_fault_id_31_ch5_0_f(i);
                when x"35"  => read_data(i+8) <= rx_fault_id_31_ch5_1_f(i);
                when x"36"  => read_data(i+8) <= rx_fault_id_31_ch5_2_f(i);
                when x"37"  => read_data(i+8) <= rx_fault_id_31_ch5_3_f(i);
                when x"38"  => read_data(i+8) <= rx_fault_id_31_ch6_0_f(i);
                when x"39"  => read_data(i+8) <= rx_fault_id_31_ch6_1_f(i);
                when x"3A"  => read_data(i+8) <= rx_fault_id_31_ch6_2_f(i);
                when x"3B"  => read_data(i+8) <= rx_fault_id_31_ch6_3_f(i);
                when x"3C"  => read_data(i+8) <= rx_fault_id_31_ch7_0_f(i);
                when x"3D"  => read_data(i+8) <= rx_fault_id_31_ch7_1_f(i);
                when x"3E"  => read_data(i+8) <= rx_fault_id_31_ch7_2_f(i);
                when x"3F"  => read_data(i+8) <= rx_fault_id_31_ch7_3_f(i);

                when others => read_data(i+8) <= (others => '0');
                end case;
            end if;
        end if;
    end process;
    end generate;

    u_READ_12_to_15 : for i in 3 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (addr_msb = i+12) then
                case addr_lsb is
                when x"00"  => read_data(i+12) <= rx_invalid_dst_mac_r(i);
                when x"01"  => read_data(i+12) <= rx_invalid_ethertype_r(i);
                when x"02"  => read_data(i+12) <= rx_invalid_ecpriver_r(i);
                when x"03"  => read_data(i+12) <= rx_invalid_ecpric_r(i);
                when x"04"  => read_data(i+12) <= rx_invalid_ecprimsg_r(i);
                when x"05"  => read_data(i+12) <= rx_lost_r(i);

                when x"10"  => read_data(i+12) <= rx_c_plane_exist_f(i);
                when x"11"  => read_data(i+12) <= rx_c_plane_r(i);
                when x"12"  => read_data(i+12) <= rx_c_plane_dropped_r(i);
                when x"13"  => read_data(i+12) <= rx_c_plane_buffer_f(i);
                when x"14"  => read_data(i+12) <= rx_u_plane_exist_f(i);
                when x"15"  => read_data(i+12) <= rx_u_plane_r(i);
                when x"16"  => read_data(i+12) <= rx_u_plane_dropped_r(i);
                when x"17"  => read_data(i+12) <= rx_u_plane_buffer_f(i);

--                when x"21"  => read_data(i+12) <= tx0_c_plane_r(i);
--                when x"22"  => read_data(i+12) <= tx0_c_plane_lost_r(i);
--                when x"23"  => read_data(i+12) <= tx0_c_plane_buffer_f(i);
                when x"25"  => read_data(i+12) <= tx0_u_plane_r(i);
                when x"26"  => read_data(i+12) <= tx0_u_plane_lost_r(i);
                when x"27"  => read_data(i+12) <= tx0_u_plane_buffer_f(i);

--                when x"29"  => read_data(i+12) <= tx1_c_plane_r(i);
--                when x"2A"  => read_data(i+12) <= tx1_c_plane_lost_r(i);
--                when x"2B"  => read_data(i+12) <= tx1_c_plane_buffer_f(i);
                when x"2D"  => read_data(i+12) <= tx1_u_plane_r(i);
                when x"2E"  => read_data(i+12) <= tx1_u_plane_lost_r(i);
                when x"2F"  => read_data(i+12) <= tx1_u_plane_buffer_f(i);

--                when x"31"  => read_data(i+12) <= tx2_c_plane_r(i);
--                when x"32"  => read_data(i+12) <= tx2_c_plane_lost_r(i);
--                when x"33"  => read_data(i+12) <= tx2_c_plane_buffer_f(i);
                when x"35"  => read_data(i+12) <= tx2_u_plane_r(i);
                when x"36"  => read_data(i+12) <= tx2_u_plane_lost_r(i);
                when x"37"  => read_data(i+12) <= tx2_u_plane_buffer_f(i);

--                when x"39"  => read_data(i+12) <= tx3_c_plane_r(i);
--                when x"3A"  => read_data(i+12) <= tx3_c_plane_lost_r(i);
--                when x"3B"  => read_data(i+12) <= tx3_c_plane_buffer_f(i);
                when x"3D"  => read_data(i+12) <= tx3_u_plane_r(i);
                when x"3E"  => read_data(i+12) <= tx3_u_plane_lost_r(i);
                when x"3F"  => read_data(i+12) <= tx3_u_plane_buffer_f(i);

--                when x"41"  => read_data(i+12) <= tx4_c_plane_r(i);
--                when x"42"  => read_data(i+12) <= tx4_c_plane_lost_r(i);
--                when x"43"  => read_data(i+12) <= tx4_c_plane_buffer_f(i);
                when x"45"  => read_data(i+12) <= tx4_u_plane_r(i);
                when x"46"  => read_data(i+12) <= tx4_u_plane_lost_r(i);
                when x"47"  => read_data(i+12) <= tx4_u_plane_buffer_f(i);

--                when x"49"  => read_data(i+12) <= tx5_c_plane_r(i);
--                when x"4A"  => read_data(i+12) <= tx5_c_plane_lost_r(i);
--                when x"4B"  => read_data(i+12) <= tx5_c_plane_buffer_f(i);
                when x"4D"  => read_data(i+12) <= tx5_u_plane_r(i);
                when x"4E"  => read_data(i+12) <= tx5_u_plane_lost_r(i);
                when x"4F"  => read_data(i+12) <= tx5_u_plane_buffer_f(i);

                when others => read_data(i+12) <= (others => '0');
                end case;
            end if;
        end if;
    end process;
    end generate;

    u_READ_16_to_17 : for i in 1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (addr_msb = i+16) then
                case addr_lsb is
                when x"00"  => read_data(i+16) <= tx0_cpsec_symbol0_r(i);
                when x"01"  => read_data(i+16) <= tx0_cpsec_symbol1_r(i);
                when x"02"  => read_data(i+16) <= tx0_cpsec_symbol2_r(i);
                when x"03"  => read_data(i+16) <= tx0_cpsec_symbol3_r(i);
                when x"04"  => read_data(i+16) <= tx0_cpsec_symbol4_r(i);
                when x"05"  => read_data(i+16) <= tx0_cpsec_symbol5_r(i);
                when x"06"  => read_data(i+16) <= tx0_cpsec_symbol6_r(i);
                when x"07"  => read_data(i+16) <= tx0_cpsec_symbol7_r(i);
                when x"08"  => read_data(i+16) <= tx0_cpsec_symbol8_r(i);
                when x"09"  => read_data(i+16) <= tx0_cpsec_symbol9_r(i);
                when x"0A"  => read_data(i+16) <= tx0_cpsec_symbol10_r(i);
                when x"0B"  => read_data(i+16) <= tx0_cpsec_symbol11_r(i);
                when x"0C"  => read_data(i+16) <= tx0_cpsec_symbol12_r(i);
                when x"0D"  => read_data(i+16) <= tx0_cpsec_symbol13_r(i);
                when x"0E"  => read_data(i+16) <= tx_cmd_fifo_full_r(i);
                when x"0F"  => read_data(i+16) <= tx0_termination_r(i);

                when x"10"  => read_data(i+16) <= tx0_uppkt_symbol0_r(i);
                when x"11"  => read_data(i+16) <= tx0_uppkt_symbol1_r(i);
                when x"12"  => read_data(i+16) <= tx0_uppkt_symbol2_r(i);
                when x"13"  => read_data(i+16) <= tx0_uppkt_symbol3_r(i);
                when x"14"  => read_data(i+16) <= tx0_uppkt_symbol4_r(i);
                when x"15"  => read_data(i+16) <= tx0_uppkt_symbol5_r(i);
                when x"16"  => read_data(i+16) <= tx0_uppkt_symbol6_r(i);
                when x"17"  => read_data(i+16) <= tx0_uppkt_symbol7_r(i);
                when x"18"  => read_data(i+16) <= tx0_uppkt_symbol8_r(i);
                when x"19"  => read_data(i+16) <= tx0_uppkt_symbol9_r(i);
                when x"1A"  => read_data(i+16) <= tx0_uppkt_symbol10_r(i);
                when x"1B"  => read_data(i+16) <= tx0_uppkt_symbol11_r(i);
                when x"1C"  => read_data(i+16) <= tx0_uppkt_symbol12_r(i);
                when x"1D"  => read_data(i+16) <= tx0_uppkt_symbol13_r(i);

                when x"20"  => read_data(i+16) <= tx0_cq_full_symbol0_r(i);
                when x"21"  => read_data(i+16) <= tx0_cq_full_symbol1_r(i);
                when x"22"  => read_data(i+16) <= tx0_cq_full_symbol2_r(i);
                when x"23"  => read_data(i+16) <= tx0_cq_full_symbol3_r(i);
                when x"24"  => read_data(i+16) <= tx0_cq_full_symbol4_r(i);
                when x"25"  => read_data(i+16) <= tx0_cq_full_symbol5_r(i);
                when x"26"  => read_data(i+16) <= tx0_cq_full_symbol6_r(i);
                when x"27"  => read_data(i+16) <= tx0_cq_full_symbol7_r(i);
                when x"28"  => read_data(i+16) <= tx0_cq_full_symbol8_r(i);
                when x"29"  => read_data(i+16) <= tx0_cq_full_symbol9_r(i);
                when x"2A"  => read_data(i+16) <= tx0_cq_full_symbol10_r(i);
                when x"2B"  => read_data(i+16) <= tx0_cq_full_symbol11_r(i);
                when x"2C"  => read_data(i+16) <= tx0_cq_full_symbol12_r(i);
                when x"2D"  => read_data(i+16) <= tx0_cq_full_symbol13_r(i);

                when x"30"  => read_data(i+16) <= tx0_cq_usage_symbol0_f(i);
                when x"31"  => read_data(i+16) <= tx0_cq_usage_symbol1_f(i);
                when x"32"  => read_data(i+16) <= tx0_cq_usage_symbol2_f(i);
                when x"33"  => read_data(i+16) <= tx0_cq_usage_symbol3_f(i);
                when x"34"  => read_data(i+16) <= tx0_cq_usage_symbol4_f(i);
                when x"35"  => read_data(i+16) <= tx0_cq_usage_symbol5_f(i);
                when x"36"  => read_data(i+16) <= tx0_cq_usage_symbol6_f(i);
                when x"37"  => read_data(i+16) <= tx0_cq_usage_symbol7_f(i);
                when x"38"  => read_data(i+16) <= tx0_cq_usage_symbol8_f(i);
                when x"39"  => read_data(i+16) <= tx0_cq_usage_symbol9_f(i);
                when x"3A"  => read_data(i+16) <= tx0_cq_usage_symbol10_f(i);
                when x"3B"  => read_data(i+16) <= tx0_cq_usage_symbol11_f(i);
                when x"3C"  => read_data(i+16) <= tx0_cq_usage_symbol12_f(i);
                when x"3D"  => read_data(i+16) <= tx0_cq_usage_symbol13_f(i);

                when x"40"  => read_data(i+16) <= tx1_cpsec_symbol0_r(i);
                when x"41"  => read_data(i+16) <= tx1_cpsec_symbol1_r(i);
                when x"42"  => read_data(i+16) <= tx1_cpsec_symbol2_r(i);
                when x"43"  => read_data(i+16) <= tx1_cpsec_symbol3_r(i);
                when x"44"  => read_data(i+16) <= tx1_cpsec_symbol4_r(i);
                when x"45"  => read_data(i+16) <= tx1_cpsec_symbol5_r(i);
                when x"46"  => read_data(i+16) <= tx1_cpsec_symbol6_r(i);
                when x"47"  => read_data(i+16) <= tx1_cpsec_symbol7_r(i);
                when x"48"  => read_data(i+16) <= tx1_cpsec_symbol8_r(i);
                when x"49"  => read_data(i+16) <= tx1_cpsec_symbol9_r(i);
                when x"4A"  => read_data(i+16) <= tx1_cpsec_symbol10_r(i);
                when x"4B"  => read_data(i+16) <= tx1_cpsec_symbol11_r(i);
                when x"4C"  => read_data(i+16) <= tx1_cpsec_symbol12_r(i);
                when x"4D"  => read_data(i+16) <= tx1_cpsec_symbol13_r(i);
                when x"4F"  => read_data(i+16) <= tx1_termination_r(i);

                when x"50"  => read_data(i+16) <= tx1_uppkt_symbol0_r(i);
                when x"51"  => read_data(i+16) <= tx1_uppkt_symbol1_r(i);
                when x"52"  => read_data(i+16) <= tx1_uppkt_symbol2_r(i);
                when x"53"  => read_data(i+16) <= tx1_uppkt_symbol3_r(i);
                when x"54"  => read_data(i+16) <= tx1_uppkt_symbol4_r(i);
                when x"55"  => read_data(i+16) <= tx1_uppkt_symbol5_r(i);
                when x"56"  => read_data(i+16) <= tx1_uppkt_symbol6_r(i);
                when x"57"  => read_data(i+16) <= tx1_uppkt_symbol7_r(i);
                when x"58"  => read_data(i+16) <= tx1_uppkt_symbol8_r(i);
                when x"59"  => read_data(i+16) <= tx1_uppkt_symbol9_r(i);
                when x"5A"  => read_data(i+16) <= tx1_uppkt_symbol10_r(i);
                when x"5B"  => read_data(i+16) <= tx1_uppkt_symbol11_r(i);
                when x"5C"  => read_data(i+16) <= tx1_uppkt_symbol12_r(i);
                when x"5D"  => read_data(i+16) <= tx1_uppkt_symbol13_r(i);

                when x"60"  => read_data(i+16) <= tx1_cq_full_symbol0_r(i);
                when x"61"  => read_data(i+16) <= tx1_cq_full_symbol1_r(i);
                when x"62"  => read_data(i+16) <= tx1_cq_full_symbol2_r(i);
                when x"63"  => read_data(i+16) <= tx1_cq_full_symbol3_r(i);
                when x"64"  => read_data(i+16) <= tx1_cq_full_symbol4_r(i);
                when x"65"  => read_data(i+16) <= tx1_cq_full_symbol5_r(i);
                when x"66"  => read_data(i+16) <= tx1_cq_full_symbol6_r(i);
                when x"67"  => read_data(i+16) <= tx1_cq_full_symbol7_r(i);
                when x"68"  => read_data(i+16) <= tx1_cq_full_symbol8_r(i);
                when x"69"  => read_data(i+16) <= tx1_cq_full_symbol9_r(i);
                when x"6A"  => read_data(i+16) <= tx1_cq_full_symbol10_r(i);
                when x"6B"  => read_data(i+16) <= tx1_cq_full_symbol11_r(i);
                when x"6C"  => read_data(i+16) <= tx1_cq_full_symbol12_r(i);
                when x"6D"  => read_data(i+16) <= tx1_cq_full_symbol13_r(i);

                when x"70"  => read_data(i+16) <= tx1_cq_usage_symbol0_f(i);
                when x"71"  => read_data(i+16) <= tx1_cq_usage_symbol1_f(i);
                when x"72"  => read_data(i+16) <= tx1_cq_usage_symbol2_f(i);
                when x"73"  => read_data(i+16) <= tx1_cq_usage_symbol3_f(i);
                when x"74"  => read_data(i+16) <= tx1_cq_usage_symbol4_f(i);
                when x"75"  => read_data(i+16) <= tx1_cq_usage_symbol5_f(i);
                when x"76"  => read_data(i+16) <= tx1_cq_usage_symbol6_f(i);
                when x"77"  => read_data(i+16) <= tx1_cq_usage_symbol7_f(i);
                when x"78"  => read_data(i+16) <= tx1_cq_usage_symbol8_f(i);
                when x"79"  => read_data(i+16) <= tx1_cq_usage_symbol9_f(i);
                when x"7A"  => read_data(i+16) <= tx1_cq_usage_symbol10_f(i);
                when x"7B"  => read_data(i+16) <= tx1_cq_usage_symbol11_f(i);
                when x"7C"  => read_data(i+16) <= tx1_cq_usage_symbol12_f(i);
                when x"7D"  => read_data(i+16) <= tx1_cq_usage_symbol13_f(i);

                when x"80"  => read_data(i+16) <= tx2_cpsec_symbol0_r(i);
                when x"81"  => read_data(i+16) <= tx2_cpsec_symbol1_r(i);
                when x"82"  => read_data(i+16) <= tx2_cpsec_symbol2_r(i);
                when x"83"  => read_data(i+16) <= tx2_cpsec_symbol3_r(i);
                when x"84"  => read_data(i+16) <= tx2_cpsec_symbol4_r(i);
                when x"85"  => read_data(i+16) <= tx2_cpsec_symbol5_r(i);
                when x"86"  => read_data(i+16) <= tx2_cpsec_symbol6_r(i);
                when x"87"  => read_data(i+16) <= tx2_cpsec_symbol7_r(i);
                when x"88"  => read_data(i+16) <= tx2_cpsec_symbol8_r(i);
                when x"89"  => read_data(i+16) <= tx2_cpsec_symbol9_r(i);
                when x"8A"  => read_data(i+16) <= tx2_cpsec_symbol10_r(i);
                when x"8B"  => read_data(i+16) <= tx2_cpsec_symbol11_r(i);
                when x"8C"  => read_data(i+16) <= tx2_cpsec_symbol12_r(i);
                when x"8D"  => read_data(i+16) <= tx2_cpsec_symbol13_r(i);
                when x"8F"  => read_data(i+16) <= tx2_termination_r(i);

                when x"90"  => read_data(i+16) <= tx2_uppkt_symbol0_r(i);
                when x"91"  => read_data(i+16) <= tx2_uppkt_symbol1_r(i);
                when x"92"  => read_data(i+16) <= tx2_uppkt_symbol2_r(i);
                when x"93"  => read_data(i+16) <= tx2_uppkt_symbol3_r(i);
                when x"94"  => read_data(i+16) <= tx2_uppkt_symbol4_r(i);
                when x"95"  => read_data(i+16) <= tx2_uppkt_symbol5_r(i);
                when x"96"  => read_data(i+16) <= tx2_uppkt_symbol6_r(i);
                when x"97"  => read_data(i+16) <= tx2_uppkt_symbol7_r(i);
                when x"98"  => read_data(i+16) <= tx2_uppkt_symbol8_r(i);
                when x"99"  => read_data(i+16) <= tx2_uppkt_symbol9_r(i);
                when x"9A"  => read_data(i+16) <= tx2_uppkt_symbol10_r(i);
                when x"9B"  => read_data(i+16) <= tx2_uppkt_symbol11_r(i);
                when x"9C"  => read_data(i+16) <= tx2_uppkt_symbol12_r(i);
                when x"9D"  => read_data(i+16) <= tx2_uppkt_symbol13_r(i);

                when x"A0"  => read_data(i+16) <= tx2_cq_full_symbol0_r(i);
                when x"A1"  => read_data(i+16) <= tx2_cq_full_symbol1_r(i);
                when x"A2"  => read_data(i+16) <= tx2_cq_full_symbol2_r(i);
                when x"A3"  => read_data(i+16) <= tx2_cq_full_symbol3_r(i);
                when x"A4"  => read_data(i+16) <= tx2_cq_full_symbol4_r(i);
                when x"A5"  => read_data(i+16) <= tx2_cq_full_symbol5_r(i);
                when x"A6"  => read_data(i+16) <= tx2_cq_full_symbol6_r(i);
                when x"A7"  => read_data(i+16) <= tx2_cq_full_symbol7_r(i);
                when x"A8"  => read_data(i+16) <= tx2_cq_full_symbol8_r(i);
                when x"A9"  => read_data(i+16) <= tx2_cq_full_symbol9_r(i);
                when x"AA"  => read_data(i+16) <= tx2_cq_full_symbol10_r(i);
                when x"AB"  => read_data(i+16) <= tx2_cq_full_symbol11_r(i);
                when x"AC"  => read_data(i+16) <= tx2_cq_full_symbol12_r(i);
                when x"AD"  => read_data(i+16) <= tx2_cq_full_symbol13_r(i);

                when x"B0"  => read_data(i+16) <= tx2_cq_usage_symbol0_f(i);
                when x"B1"  => read_data(i+16) <= tx2_cq_usage_symbol1_f(i);
                when x"B2"  => read_data(i+16) <= tx2_cq_usage_symbol2_f(i);
                when x"B3"  => read_data(i+16) <= tx2_cq_usage_symbol3_f(i);
                when x"B4"  => read_data(i+16) <= tx2_cq_usage_symbol4_f(i);
                when x"B5"  => read_data(i+16) <= tx2_cq_usage_symbol5_f(i);
                when x"B6"  => read_data(i+16) <= tx2_cq_usage_symbol6_f(i);
                when x"B7"  => read_data(i+16) <= tx2_cq_usage_symbol7_f(i);
                when x"B8"  => read_data(i+16) <= tx2_cq_usage_symbol8_f(i);
                when x"B9"  => read_data(i+16) <= tx2_cq_usage_symbol9_f(i);
                when x"BA"  => read_data(i+16) <= tx2_cq_usage_symbol10_f(i);
                when x"BB"  => read_data(i+16) <= tx2_cq_usage_symbol11_f(i);
                when x"BC"  => read_data(i+16) <= tx2_cq_usage_symbol12_f(i);
                when x"BD"  => read_data(i+16) <= tx2_cq_usage_symbol13_f(i);

                when others => read_data(i+16) <= (others => '0');
                end case;
            end if;
        end if;
    end process;
    end generate;

    u_READ_18_to_19 : for i in 1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (addr_msb = i+18) then
                case addr_lsb is
                when x"00"  => read_data(i+18) <= tx3_cpsec_symbol0_r(i);
                when x"01"  => read_data(i+18) <= tx3_cpsec_symbol1_r(i);
                when x"02"  => read_data(i+18) <= tx3_cpsec_symbol2_r(i);
                when x"03"  => read_data(i+18) <= tx3_cpsec_symbol3_r(i);
                when x"04"  => read_data(i+18) <= tx3_cpsec_symbol4_r(i);
                when x"05"  => read_data(i+18) <= tx3_cpsec_symbol5_r(i);
                when x"06"  => read_data(i+18) <= tx3_cpsec_symbol6_r(i);
                when x"07"  => read_data(i+18) <= tx3_cpsec_symbol7_r(i);
                when x"08"  => read_data(i+18) <= tx3_cpsec_symbol8_r(i);
                when x"09"  => read_data(i+18) <= tx3_cpsec_symbol9_r(i);
                when x"0A"  => read_data(i+18) <= tx3_cpsec_symbol10_r(i);
                when x"0B"  => read_data(i+18) <= tx3_cpsec_symbol11_r(i);
                when x"0C"  => read_data(i+18) <= tx3_cpsec_symbol12_r(i);
                when x"0D"  => read_data(i+18) <= tx3_cpsec_symbol13_r(i);
                when x"0E"  => read_data(i+18) <= tx_cmd_fifo_full_r(i);
                when x"0F"  => read_data(i+18) <= tx3_termination_r(i);

                when x"10"  => read_data(i+18) <= tx3_uppkt_symbol0_r(i);
                when x"11"  => read_data(i+18) <= tx3_uppkt_symbol1_r(i);
                when x"12"  => read_data(i+18) <= tx3_uppkt_symbol2_r(i);
                when x"13"  => read_data(i+18) <= tx3_uppkt_symbol3_r(i);
                when x"14"  => read_data(i+18) <= tx3_uppkt_symbol4_r(i);
                when x"15"  => read_data(i+18) <= tx3_uppkt_symbol5_r(i);
                when x"16"  => read_data(i+18) <= tx3_uppkt_symbol6_r(i);
                when x"17"  => read_data(i+18) <= tx3_uppkt_symbol7_r(i);
                when x"18"  => read_data(i+18) <= tx3_uppkt_symbol8_r(i);
                when x"19"  => read_data(i+18) <= tx3_uppkt_symbol9_r(i);
                when x"1A"  => read_data(i+18) <= tx3_uppkt_symbol10_r(i);
                when x"1B"  => read_data(i+18) <= tx3_uppkt_symbol11_r(i);
                when x"1C"  => read_data(i+18) <= tx3_uppkt_symbol12_r(i);
                when x"1D"  => read_data(i+18) <= tx3_uppkt_symbol13_r(i);

                when x"20"  => read_data(i+18) <= tx3_cq_full_symbol0_r(i);
                when x"21"  => read_data(i+18) <= tx3_cq_full_symbol1_r(i);
                when x"22"  => read_data(i+18) <= tx3_cq_full_symbol2_r(i);
                when x"23"  => read_data(i+18) <= tx3_cq_full_symbol3_r(i);
                when x"24"  => read_data(i+18) <= tx3_cq_full_symbol4_r(i);
                when x"25"  => read_data(i+18) <= tx3_cq_full_symbol5_r(i);
                when x"26"  => read_data(i+18) <= tx3_cq_full_symbol6_r(i);
                when x"27"  => read_data(i+18) <= tx3_cq_full_symbol7_r(i);
                when x"28"  => read_data(i+18) <= tx3_cq_full_symbol8_r(i);
                when x"29"  => read_data(i+18) <= tx3_cq_full_symbol9_r(i);
                when x"2A"  => read_data(i+18) <= tx3_cq_full_symbol10_r(i);
                when x"2B"  => read_data(i+18) <= tx3_cq_full_symbol11_r(i);
                when x"2C"  => read_data(i+18) <= tx3_cq_full_symbol12_r(i);
                when x"2D"  => read_data(i+18) <= tx3_cq_full_symbol13_r(i);

                when x"30"  => read_data(i+18) <= tx3_cq_usage_symbol0_f(i);
                when x"31"  => read_data(i+18) <= tx3_cq_usage_symbol1_f(i);
                when x"32"  => read_data(i+18) <= tx3_cq_usage_symbol2_f(i);
                when x"33"  => read_data(i+18) <= tx3_cq_usage_symbol3_f(i);
                when x"34"  => read_data(i+18) <= tx3_cq_usage_symbol4_f(i);
                when x"35"  => read_data(i+18) <= tx3_cq_usage_symbol5_f(i);
                when x"36"  => read_data(i+18) <= tx3_cq_usage_symbol6_f(i);
                when x"37"  => read_data(i+18) <= tx3_cq_usage_symbol7_f(i);
                when x"38"  => read_data(i+18) <= tx3_cq_usage_symbol8_f(i);
                when x"39"  => read_data(i+18) <= tx3_cq_usage_symbol9_f(i);
                when x"3A"  => read_data(i+18) <= tx3_cq_usage_symbol10_f(i);
                when x"3B"  => read_data(i+18) <= tx3_cq_usage_symbol11_f(i);
                when x"3C"  => read_data(i+18) <= tx3_cq_usage_symbol12_f(i);
                when x"3D"  => read_data(i+18) <= tx3_cq_usage_symbol13_f(i);

                when x"40"  => read_data(i+18) <= tx4_cpsec_symbol0_r(i);
                when x"41"  => read_data(i+18) <= tx4_cpsec_symbol1_r(i);
                when x"42"  => read_data(i+18) <= tx4_cpsec_symbol2_r(i);
                when x"43"  => read_data(i+18) <= tx4_cpsec_symbol3_r(i);
                when x"44"  => read_data(i+18) <= tx4_cpsec_symbol4_r(i);
                when x"45"  => read_data(i+18) <= tx4_cpsec_symbol5_r(i);
                when x"46"  => read_data(i+18) <= tx4_cpsec_symbol6_r(i);
                when x"47"  => read_data(i+18) <= tx4_cpsec_symbol7_r(i);
                when x"48"  => read_data(i+18) <= tx4_cpsec_symbol8_r(i);
                when x"49"  => read_data(i+18) <= tx4_cpsec_symbol9_r(i);
                when x"4A"  => read_data(i+18) <= tx4_cpsec_symbol10_r(i);
                when x"4B"  => read_data(i+18) <= tx4_cpsec_symbol11_r(i);
                when x"4C"  => read_data(i+18) <= tx4_cpsec_symbol12_r(i);
                when x"4D"  => read_data(i+18) <= tx4_cpsec_symbol13_r(i);
                when x"4F"  => read_data(i+18) <= tx4_termination_r(i);

                when x"50"  => read_data(i+18) <= tx4_uppkt_symbol0_r(i);
                when x"51"  => read_data(i+18) <= tx4_uppkt_symbol1_r(i);
                when x"52"  => read_data(i+18) <= tx4_uppkt_symbol2_r(i);
                when x"53"  => read_data(i+18) <= tx4_uppkt_symbol3_r(i);
                when x"54"  => read_data(i+18) <= tx4_uppkt_symbol4_r(i);
                when x"55"  => read_data(i+18) <= tx4_uppkt_symbol5_r(i);
                when x"56"  => read_data(i+18) <= tx4_uppkt_symbol6_r(i);
                when x"57"  => read_data(i+18) <= tx4_uppkt_symbol7_r(i);
                when x"58"  => read_data(i+18) <= tx4_uppkt_symbol8_r(i);
                when x"59"  => read_data(i+18) <= tx4_uppkt_symbol9_r(i);
                when x"5A"  => read_data(i+18) <= tx4_uppkt_symbol10_r(i);
                when x"5B"  => read_data(i+18) <= tx4_uppkt_symbol11_r(i);
                when x"5C"  => read_data(i+18) <= tx4_uppkt_symbol12_r(i);
                when x"5D"  => read_data(i+18) <= tx4_uppkt_symbol13_r(i);

                when x"60"  => read_data(i+18) <= tx4_cq_full_symbol0_r(i);
                when x"61"  => read_data(i+18) <= tx4_cq_full_symbol1_r(i);
                when x"62"  => read_data(i+18) <= tx4_cq_full_symbol2_r(i);
                when x"63"  => read_data(i+18) <= tx4_cq_full_symbol3_r(i);
                when x"64"  => read_data(i+18) <= tx4_cq_full_symbol4_r(i);
                when x"65"  => read_data(i+18) <= tx4_cq_full_symbol5_r(i);
                when x"66"  => read_data(i+18) <= tx4_cq_full_symbol6_r(i);
                when x"67"  => read_data(i+18) <= tx4_cq_full_symbol7_r(i);
                when x"68"  => read_data(i+18) <= tx4_cq_full_symbol8_r(i);
                when x"69"  => read_data(i+18) <= tx4_cq_full_symbol9_r(i);
                when x"6A"  => read_data(i+18) <= tx4_cq_full_symbol10_r(i);
                when x"6B"  => read_data(i+18) <= tx4_cq_full_symbol11_r(i);
                when x"6C"  => read_data(i+18) <= tx4_cq_full_symbol12_r(i);
                when x"6D"  => read_data(i+18) <= tx4_cq_full_symbol13_r(i);

                when x"70"  => read_data(i+18) <= tx4_cq_usage_symbol0_f(i);
                when x"71"  => read_data(i+18) <= tx4_cq_usage_symbol1_f(i);
                when x"72"  => read_data(i+18) <= tx4_cq_usage_symbol2_f(i);
                when x"73"  => read_data(i+18) <= tx4_cq_usage_symbol3_f(i);
                when x"74"  => read_data(i+18) <= tx4_cq_usage_symbol4_f(i);
                when x"75"  => read_data(i+18) <= tx4_cq_usage_symbol5_f(i);
                when x"76"  => read_data(i+18) <= tx4_cq_usage_symbol6_f(i);
                when x"77"  => read_data(i+18) <= tx4_cq_usage_symbol7_f(i);
                when x"78"  => read_data(i+18) <= tx4_cq_usage_symbol8_f(i);
                when x"79"  => read_data(i+18) <= tx4_cq_usage_symbol9_f(i);
                when x"7A"  => read_data(i+18) <= tx4_cq_usage_symbol10_f(i);
                when x"7B"  => read_data(i+18) <= tx4_cq_usage_symbol11_f(i);
                when x"7C"  => read_data(i+18) <= tx4_cq_usage_symbol12_f(i);
                when x"7D"  => read_data(i+18) <= tx4_cq_usage_symbol13_f(i);

                when x"80"  => read_data(i+18) <= tx5_cpsec_symbol0_r(i);
                when x"81"  => read_data(i+18) <= tx5_cpsec_symbol1_r(i);
                when x"82"  => read_data(i+18) <= tx5_cpsec_symbol2_r(i);
                when x"83"  => read_data(i+18) <= tx5_cpsec_symbol3_r(i);
                when x"84"  => read_data(i+18) <= tx5_cpsec_symbol4_r(i);
                when x"85"  => read_data(i+18) <= tx5_cpsec_symbol5_r(i);
                when x"86"  => read_data(i+18) <= tx5_cpsec_symbol6_r(i);
                when x"87"  => read_data(i+18) <= tx5_cpsec_symbol7_r(i);
                when x"88"  => read_data(i+18) <= tx5_cpsec_symbol8_r(i);
                when x"89"  => read_data(i+18) <= tx5_cpsec_symbol9_r(i);
                when x"8A"  => read_data(i+18) <= tx5_cpsec_symbol10_r(i);
                when x"8B"  => read_data(i+18) <= tx5_cpsec_symbol11_r(i);
                when x"8C"  => read_data(i+18) <= tx5_cpsec_symbol12_r(i);
                when x"8D"  => read_data(i+18) <= tx5_cpsec_symbol13_r(i);
                when x"8F"  => read_data(i+18) <= tx5_termination_r(i);

                when x"90"  => read_data(i+18) <= tx5_uppkt_symbol0_r(i);
                when x"91"  => read_data(i+18) <= tx5_uppkt_symbol1_r(i);
                when x"92"  => read_data(i+18) <= tx5_uppkt_symbol2_r(i);
                when x"93"  => read_data(i+18) <= tx5_uppkt_symbol3_r(i);
                when x"94"  => read_data(i+18) <= tx5_uppkt_symbol4_r(i);
                when x"95"  => read_data(i+18) <= tx5_uppkt_symbol5_r(i);
                when x"96"  => read_data(i+18) <= tx5_uppkt_symbol6_r(i);
                when x"97"  => read_data(i+18) <= tx5_uppkt_symbol7_r(i);
                when x"98"  => read_data(i+18) <= tx5_uppkt_symbol8_r(i);
                when x"99"  => read_data(i+18) <= tx5_uppkt_symbol9_r(i);
                when x"9A"  => read_data(i+18) <= tx5_uppkt_symbol10_r(i);
                when x"9B"  => read_data(i+18) <= tx5_uppkt_symbol11_r(i);
                when x"9C"  => read_data(i+18) <= tx5_uppkt_symbol12_r(i);
                when x"9D"  => read_data(i+18) <= tx5_uppkt_symbol13_r(i);

                when x"A0"  => read_data(i+18) <= tx5_cq_full_symbol0_r(i);
                when x"A1"  => read_data(i+18) <= tx5_cq_full_symbol1_r(i);
                when x"A2"  => read_data(i+18) <= tx5_cq_full_symbol2_r(i);
                when x"A3"  => read_data(i+18) <= tx5_cq_full_symbol3_r(i);
                when x"A4"  => read_data(i+18) <= tx5_cq_full_symbol4_r(i);
                when x"A5"  => read_data(i+18) <= tx5_cq_full_symbol5_r(i);
                when x"A6"  => read_data(i+18) <= tx5_cq_full_symbol6_r(i);
                when x"A7"  => read_data(i+18) <= tx5_cq_full_symbol7_r(i);
                when x"A8"  => read_data(i+18) <= tx5_cq_full_symbol8_r(i);
                when x"A9"  => read_data(i+18) <= tx5_cq_full_symbol9_r(i);
                when x"AA"  => read_data(i+18) <= tx5_cq_full_symbol10_r(i);
                when x"AB"  => read_data(i+18) <= tx5_cq_full_symbol11_r(i);
                when x"AC"  => read_data(i+18) <= tx5_cq_full_symbol12_r(i);
                when x"AD"  => read_data(i+18) <= tx5_cq_full_symbol13_r(i);

                when x"B0"  => read_data(i+18) <= tx5_cq_usage_symbol0_f(i);
                when x"B1"  => read_data(i+18) <= tx5_cq_usage_symbol1_f(i);
                when x"B2"  => read_data(i+18) <= tx5_cq_usage_symbol2_f(i);
                when x"B3"  => read_data(i+18) <= tx5_cq_usage_symbol3_f(i);
                when x"B4"  => read_data(i+18) <= tx5_cq_usage_symbol4_f(i);
                when x"B5"  => read_data(i+18) <= tx5_cq_usage_symbol5_f(i);
                when x"B6"  => read_data(i+18) <= tx5_cq_usage_symbol6_f(i);
                when x"B7"  => read_data(i+18) <= tx5_cq_usage_symbol7_f(i);
                when x"B8"  => read_data(i+18) <= tx5_cq_usage_symbol8_f(i);
                when x"B9"  => read_data(i+18) <= tx5_cq_usage_symbol9_f(i);
                when x"BA"  => read_data(i+18) <= tx5_cq_usage_symbol10_f(i);
                when x"BB"  => read_data(i+18) <= tx5_cq_usage_symbol11_f(i);
                when x"BC"  => read_data(i+18) <= tx5_cq_usage_symbol12_f(i);
                when x"BD"  => read_data(i+18) <= tx5_cq_usage_symbol13_f(i);

                when others => read_data(i+18) <= (others => '0');
                end case;
            end if;
        end if;
    end process;
    end generate;

--------------------------------------------------------------------------------
-- In/output port mapping
--------------------------------------------------------------------------------

--    u_PORT_DL : for i in DL_UNIT-1 downto 0 generate
    DL_PARAM_MAC(0)                     <= rx_param_mac_w(0)(47 downto 0);

    u_PORT_DL_CH_WRITE : for j in MAX_CH_PER_UNIT-1 downto 0 generate
    DL_PARAM_ID0_EN(0)(j)               <= rx_param_id0_w(0)(j)(16);
    DL_PARAM_ID0(0)(j)                  <= rx_param_id0_w(0)(j)(15 downto 0);
    DL_PARAM_ID1_EN(0)(j)               <= rx_param_id2_w(1)(j)(16);
    DL_PARAM_ID1(0)(j)                  <= rx_param_id2_w(1)(j)(15 downto 0);
    DL_PARAM_ID2_EN(0)(j)               <= rx_param_id2_w(0)(j)(16);
    DL_PARAM_ID2(0)(j)                  <= rx_param_id2_w(0)(j)(15 downto 0);
    DL_PARAM_ID3_EN(0)(j)               <= rx_param_id3_w(0)(j)(16);
    DL_PARAM_ID3(0)(j)                  <= rx_param_id3_w(0)(j)(15 downto 0);
    end generate;

--    u_PORT_DL_CH_UNUSED_WRITE : if MAX_CH_PER_UNIT /= 8 generate
--    u_PORT_DL_CH : for j in 7 downto MAX_CH_PER_UNIT generate
--    DL_PARAM_ID0_EN(0)(j)              <= '0';
--    DL_PARAM_ID0(0)(j)                 <= (others => '0');
--    DL_PARAM_ID1_EN(0)(j)              <= '0';
--    DL_PARAM_ID1(0)(j)                 <= (others => '0');
--    DL_PARAM_ID2_EN(0)(j)              <= '0';
--    DL_PARAM_ID2(0)(j)                 <= (others => '0');
--    DL_PARAM_ID3_EN(0)(j)              <= '0';
--    DL_PARAM_ID3(0)(j)                 <= (others => '0');
--    end generate;
--    end generate;

    DL_COMP_MODE(0)                     <= rx_comp_mode_w(0)(8);
    DL_IQ_WIDTH(0)                      <= rx_comp_mode_w(0)(7 downto 4);
    DL_COMP_METHOD(0)                   <= rx_comp_mode_w(0)(3 downto 0);
    DL_SCS_CONFIG(0)                    <= rx_scs_config_w(0)(3 downto 0);
    DL_FFT_SIZE(0)                      <= rx_fft_size_w(0)(3 downto 0);
    DL_PRB_PER_SYMBOL(0)                <= rx_prb_per_symbol_w(0)(9 downto 0);
    DL_COMP_EXP_OFFSET(0)               <= rx_comp_exp_offset_w(0)(4 downto 0);

    T2A_MAX_CP_DL(0)                    <= t2a_max_cp_dl_w(0)(21 downto 0);
    T2A_MIN_CP_DL(0)                    <= t2a_min_cp_dl_w(0)(21 downto 0);
    CP_DL_PERIOD(0)                     <= cp_dl_period_w(0)(7 downto 0);

    T2A_MAX_UP_DL(0)                    <= t2a_max_up_dl_w(0)(21 downto 0);
    T2A_MIN_UP_DL(0)                    <= t2a_min_up_dl_w(0)(21 downto 0);
    UP_DL_PERIOD(0)                     <= up_dl_period_w(0)(7 downto 0);
--    end generate;

--    u_PORT_UL : for i in UL_UNIT-1 downto 0 generate
    UL_PARAM_DST_MAC(0)                 <= tx_param_dst_mac_w(0)(47 downto 0);
    UL_PARAM_SRC_MAC(0)                 <= tx_param_src_mac_w(0)(47 downto 0);
    UL_PARAM_VLAN0_MODE(0)              <= tx_param_vlan0_w(0)(16);
    UL_PARAM_VLAN0_TCI(0)               <= tx_param_vlan0_w(0)(15 downto 0);
    UL_PARAM_VLAN1_MODE(0)              <= tx_param_vlan1_w(0)(16);
    UL_PARAM_VLAN1_TCI(0)               <= tx_param_vlan1_w(0)(15 downto 0);

    IGNORE_FRAME_ID(0)                  <= ignore_frame_id_w(0)(0);

    UL_COMP_MODE(0)                     <= tx_comp_mode_w(0)(8);
    UL_IQ_WIDTH(0)                      <= tx_comp_mode_w(0)(7 downto 4);
    UL_COMP_METHOD(0)                   <= tx_comp_mode_w(0)(3 downto 0);
    UL_SCS_CONFIG(0)                    <= tx_scs_config_w(0)(3 downto 0);
    UL_FFT_SIZE(0)                      <= tx_fft_size_w(0)(3 downto 0);
    UL_PRB_PER_MTU(0)                   <= tx_prb_per_symbol_w(0)(25 downto 16);
    UL_PRB_PER_SYMBOL(0)                <= tx_prb_per_symbol_w(0)(9 downto 0);
    UL_COMP_EXP_OFFSET(0)               <= tx_comp_exp_offset_w(0)(4 downto 0);
    UL_COMP_GAIN_OFFSET(0)              <= tx_comp_gain_offset_w(0)(10 downto 0);
    UL_COMP_SCALE_GAIN_OFFSET(0)        <= tx_comp_scale_gain_offset_w(0)(3 downto 0);

    T2A_MAX_CP_UL(0)                    <= t2a_max_cp_ul_w(0)(21 downto 0);
    T2A_MIN_CP_UL(0)                    <= t2a_min_cp_ul_w(0)(21 downto 0);
    CP_UL_PERIOD(0)                     <= cp_ul_period_w(0)(7 downto 0);

    TA3_MIN_UP0_UL(0)                   <= (others => '0'); -- ta3_min_up0_ul_w(0)(21 downto 0);
    TA3_MAX_UP0_UL(0)                   <= (others => '0'); -- ta3_max_up0_ul_w(0)(21 downto 0);
    UP0_UL_PERIOD(0)                    <= up0_ul_period_w(0)(7 downto 0);

    TA3_MIN_UP1_UL(0)                   <= (others => '0'); -- ta3_min_up1_ul_w(0)(21 downto 0);
    TA3_MAX_UP1_UL(0)                   <= (others => '0'); -- ta3_max_up1_ul_w(0)(21 downto 0);
    UP1_UL_PERIOD(0)                    <= up1_ul_period_w(0)(7 downto 0);

    TA3_MIN_UP2_UL(0)                   <= (others => '0'); -- ta3_min_up2_ul_w(0)(21 downto 0);
    TA3_MAX_UP2_UL(0)                   <= (others => '0'); -- ta3_max_up2_ul_w(0)(21 downto 0);
    UP2_UL_PERIOD(0)                    <= up2_ul_period_w(0)(7 downto 0);

    TA3_MIN_UP3_UL(0)                   <= (others => '0'); -- ta3_min_up3_ul_w(0)(21 downto 0);
    TA3_MAX_UP3_UL(0)                   <= (others => '0'); -- ta3_max_up3_ul_w(0)(21 downto 0);
    UP3_UL_PERIOD(0)                    <= up3_ul_period_w(0)(7 downto 0);

    TA3_MIN_UP4_UL(0)                   <= (others => '0'); -- ta3_min_up4_ul_w(0)(21 downto 0);
    TA3_MAX_UP4_UL(0)                   <= (others => '0'); -- ta3_max_up4_ul_w(0)(21 downto 0);
    UP4_UL_PERIOD(0)                    <= up4_ul_period_w(0)(7 downto 0);

    TA3_MIN_UP5_UL(0)                   <= (others => '0'); -- ta3_min_up5_ul_w(0)(21 downto 0);
    TA3_MAX_UP5_UL(0)                   <= (others => '0'); -- ta3_max_up5_ul_w(0)(21 downto 0);
    UP5_UL_PERIOD(0)                    <= up5_ul_period_w(0)(7 downto 0);
--    end generate;

--------------------------------------------------------------------------------
-- Read register
--------------------------------------------------------------------------------

--    u_READ_DL_CC : for i in DL_UNIT-1 downto 0 generate
    rx_param_mac_r(0)                   <= conv_std_logic_vector(0, 64-48) & rx_param_mac_w(0)(47 downto 0);

    u_PORT_DL_CH_READ : for j in MAX_CH_PER_UNIT-1 downto 0 generate
    rx_param_id0_r(0)(j)                <= conv_std_logic_vector(0, 32-17) & rx_param_id0_w(0)(j)(16 downto 0);
    rx_param_id2_r(0)(j)                <= conv_std_logic_vector(0, 32-17) & rx_param_id2_w(0)(j)(16 downto 0);
    rx_param_id3_r(0)(j)                <= conv_std_logic_vector(0, 32-17) & rx_param_id3_w(0)(j)(16 downto 0);

    rx_param_id2_r(1)(j)                <= conv_std_logic_vector(0, 32-17) & rx_param_id2_w(1)(j)(16 downto 0);
    end generate;

--    u_PORT_DL_CH_UNUSED_READ : if MAX_CH_PER_UNIT /= 8 generate
--    u_PORT_DL_CH : for j in 7 downto MAX_CH_PER_UNIT generate
--    rx_param_id0_r(0)(j)                <= (others => '0');
--    rx_param_id1_r(1)(j)                <= (others => '0');
--    rx_param_id2_r(0)(j)                <= (others => '0');
--    rx_param_id3_r(0)(j)                <= (others => '0');
--    end generate;
--    end generate;

    rx_comp_mode_r(0)                   <= conv_std_logic_vector(0, 32-9) & rx_comp_mode_w(0)(8 downto 0);
    rx_scs_config_r(0)                  <= conv_std_logic_vector(0, 32-4) & rx_scs_config_w(0)(3 downto 0);
    rx_fft_size_r(0)                    <= conv_std_logic_vector(0, 32-4) & rx_fft_size_w(0)(3 downto 0);
    rx_prb_per_symbol_r(0)              <= conv_std_logic_vector(0, 32-10) & rx_prb_per_symbol_w(0)(9 downto 0);
    rx_comp_exp_offset_r(0)             <= conv_std_logic_vector(0, 32-5) & rx_comp_exp_offset_w(0)(4 downto 0);

    t2a_max_cp_dl_r(0)                  <= conv_std_logic_vector(0, 32-22) & t2a_max_cp_dl_w(0)(21 downto 0);
    t2a_min_cp_dl_r(0)                  <= conv_std_logic_vector(0, 32-22) & t2a_min_cp_dl_w(0)(21 downto 0);
    cp_dl_period_r(0)                   <= conv_std_logic_vector(0, 32-8) & cp_dl_period_w(0)(7 downto 0);
    cp_dl_on_time_r(0)                  <= CP_DL_ON_TIME(0);
    cp_dl_early_r(0)                    <= CP_DL_EARLY(0);
    cp_dl_late_r(0)                     <= CP_DL_LATE(0);
    cp_dl_out_of_range_r(0)             <= CP_DL_OUT_OF_RANGE(0);

    t2a_max_up_dl_r(0)                  <= conv_std_logic_vector(0, 32-22) & t2a_max_up_dl_w(0)(21 downto 0);
    t2a_min_up_dl_r(0)                  <= conv_std_logic_vector(0, 32-22) & t2a_min_up_dl_w(0)(21 downto 0);
    up_dl_period_r(0)                   <= conv_std_logic_vector(0, 32-8) & up_dl_period_w(0)(7 downto 0);
    up_dl_on_time_r(0)                  <= UP_DL_ON_TIME(0);
    up_dl_early_r(0)                    <= UP_DL_EARLY(0);
    up_dl_late_r(0)                     <= UP_DL_LATE(0);
    up_dl_out_of_range_r(0)             <= UP_DL_OUT_OF_RANGE(0);

    rx_invalid_dst_mac_r(0)             <= DL_INVALID_DST_MAC(0);
    rx_invalid_ethertype_r(0)           <= DL_INVALID_ETHERTYPE(0);
    rx_invalid_ecpriver_r(0)            <= DL_INVALID_ecpriVersion(0);
    rx_invalid_ecpric_r(0)              <= DL_INVALID_ecpriC(0);
    rx_invalid_ecprimsg_r(0)            <= DL_INVALID_ecpriMessage(0);
    rx_lost_r(0)                        <= DL_LOST(0);

    rx_c_plane_r(0)                     <= DL_C_PLANE(0);
    rx_c_plane_dropped_r(0)             <= DL_C_PLANE_DROPPED(0);
    rx_c_plane_buffer_r(0)              <= DL_C_PLANE_BUFFER(0);
    rx_c_plane_exist_r(0)               <= DL_C_PLANE_EXIST(0);
    rx_u_plane_r(0)                     <= DL_U_PLANE(0);
    rx_u_plane_dropped_r(0)             <= DL_U_PLANE_DROPPED(0);
    rx_u_plane_buffer_r(0)              <= DL_U_PLANE_BUFFER(0);
    rx_u_plane_exist_r(0)               <= DL_U_PLANE_EXIST(0);

    rx_fault_id_31_ch0_0_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH0(0)(0);
    rx_fault_id_31_ch0_1_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH0(0)(1);
    rx_fault_id_31_ch0_2_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH0(0)(2);
    rx_fault_id_31_ch0_3_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH0(0)(3);
    rx_fault_id_31_ch1_0_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH1(0)(0);
    rx_fault_id_31_ch1_1_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH1(0)(1);
    rx_fault_id_31_ch1_2_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH1(0)(2);
    rx_fault_id_31_ch1_3_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH1(0)(3);
    rx_fault_id_31_ch2_0_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH2(0)(0);
    rx_fault_id_31_ch2_1_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH2(0)(1);
    rx_fault_id_31_ch2_2_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH2(0)(2);
    rx_fault_id_31_ch2_3_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH2(0)(3);
    rx_fault_id_31_ch3_0_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH3(0)(0);
    rx_fault_id_31_ch3_1_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH3(0)(1);
    rx_fault_id_31_ch3_2_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH3(0)(2);
    rx_fault_id_31_ch3_3_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH3(0)(3);
    rx_fault_id_31_ch4_0_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH4(0)(0);
    rx_fault_id_31_ch4_1_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH4(0)(1);
    rx_fault_id_31_ch4_2_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH4(0)(2);
    rx_fault_id_31_ch4_3_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH4(0)(3);
    rx_fault_id_31_ch5_0_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH5(0)(0);
    rx_fault_id_31_ch5_1_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH5(0)(1);
    rx_fault_id_31_ch5_2_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH5(0)(2);
    rx_fault_id_31_ch5_3_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH5(0)(3);
    rx_fault_id_31_ch6_0_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH6(0)(0);
    rx_fault_id_31_ch6_1_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH6(0)(1);
    rx_fault_id_31_ch6_2_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH6(0)(2);
    rx_fault_id_31_ch6_3_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH6(0)(3);
    rx_fault_id_31_ch7_0_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH7(0)(0);
    rx_fault_id_31_ch7_1_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH7(0)(1);
    rx_fault_id_31_ch7_2_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH7(0)(2);
    rx_fault_id_31_ch7_3_r(0)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH7(0)(3);
--    end generate;

--    u_READ_UL_CC : for i in UL_UNIT-1 downto 0 generate
    tx_param_dst_mac_r(0)               <= conv_std_logic_vector(0, 64-48) & tx_param_dst_mac_w(0)(47 downto 0);
    tx_param_src_mac_r(0)               <= conv_std_logic_vector(0, 64-48) & tx_param_src_mac_w(0)(47 downto 0);
    tx_param_vlan0_r(0)                 <= conv_std_logic_vector(0, 32-17) & tx_param_vlan0_w(0)(16 downto 0);
    tx_param_vlan1_r(0)                 <= conv_std_logic_vector(0, 32-17) & tx_param_vlan1_w(0)(16 downto 0);

    ignore_frame_id_r(0)                <= conv_std_logic_vector(0, 32-1) & ignore_frame_id_w(0)(0);
    ignore_frame_id_puxch_r(0)          <= x"00" & IGNORE_FRAME_ID_PUxCH_TX(0) & x"00" & IGNORE_FRAME_ID_PUxCH_RX(0);
    ignore_frame_id_prach0_r(0)         <= x"00" & IGNORE_FRAME_ID_PRACH0_TX(0) & x"00" & IGNORE_FRAME_ID_PRACH0_RX(0);
    ignore_frame_id_prach1_r(0)         <= x"00" & IGNORE_FRAME_ID_PRACH1_TX(0) & x"00" & IGNORE_FRAME_ID_PRACH1_RX(0);
    ignore_frame_id_nbiot0_r(0)         <= x"00" & IGNORE_FRAME_ID_NBIOT0_TX(0) & x"00" & IGNORE_FRAME_ID_NBIOT0_RX(0);
    ignore_frame_id_nbiot1_r(0)         <= x"00" & IGNORE_FRAME_ID_NBIOT1_TX(0) & x"00" & IGNORE_FRAME_ID_NBIOT1_RX(0);
    ignore_frame_id_nbiot2_r(0)         <= x"00" & IGNORE_FRAME_ID_NBIOT2_TX(0) & x"00" & IGNORE_FRAME_ID_NBIOT2_RX(0);

    tx_comp_mode_r(0)                   <= conv_std_logic_vector(0, 32-9) & tx_comp_mode_w(0)(8 downto 0);
    tx_fft_size_r(0)                    <= conv_std_logic_vector(0, 32-4) & tx_fft_size_w(0)(3 downto 0);
    tx_scs_config_r(0)                  <= conv_std_logic_vector(0, 32-4) & tx_scs_config_w(0)(3 downto 0);
    tx_prb_per_symbol_r(0)              <= conv_std_logic_vector(0, 32-26) & tx_prb_per_symbol_w(0)(25 downto 16) & conv_std_logic_vector(0, 16-10) & tx_prb_per_symbol_w(0)(9 downto 0);
    tx_comp_exp_offset_r(0)             <= conv_std_logic_vector(0, 32-5) & tx_comp_exp_offset_w(0)(4 downto 0);
    tx_comp_gain_offset_r(0)            <= conv_std_logic_vector(0, 32-11) & tx_comp_gain_offset_w(0)(10 downto 0);
    tx_comp_scale_gain_offset_r(0)      <= conv_std_logic_vector(0, 32-4) & tx_comp_scale_gain_offset_w(0)(3 downto 0);

    t2a_max_cp_ul_r(0)                  <= conv_std_logic_vector(0, 32-22) & t2a_max_cp_ul_w(0)(21 downto 0);
    t2a_min_cp_ul_r(0)                  <= conv_std_logic_vector(0, 32-22) & t2a_min_cp_ul_w(0)(21 downto 0);
    cp_ul_period_r(0)                   <= conv_std_logic_vector(0, 32-8) & cp_ul_period_w(0)(7 downto 0);
    cp_ul_on_time_r(0)                  <= CP_UL_ON_TIME(0);
    cp_ul_early_r(0)                    <= CP_UL_EARLY(0);
    cp_ul_late_r(0)                     <= CP_UL_LATE(0);
    cp_ul_out_of_range_r(0)             <= CP_UL_OUT_OF_RANGE(0);

--    ta3_min_up0_ul_r(0)                 <= conv_std_logic_vector(0, 32-22) & ta3_min_up0_ul_w(0)(21 downto 0);
--    ta3_max_up0_ul_r(0)                 <= conv_std_logic_vector(0, 32-22) & ta3_max_up0_ul_w(0)(21 downto 0);
    up0_ul_period_r(0)                  <= conv_std_logic_vector(0, 32-8) & up0_ul_period_w(0)(7 downto 0);
    up0_ul_on_time_r(0)                 <= UP0_UL_ON_TIME(0);
    up0_ul_early_r(0)                   <= UP0_UL_EARLY(0);
    up0_ul_late_r(0)                    <= UP0_UL_LATE(0);
    up0_ul_out_of_range_r(0)            <= UP0_UL_OUT_OF_RANGE(0);

--    ta3_min_up1_ul_r(0)                 <= conv_std_logic_vector(0, 32-22) & ta3_min_up1_ul_w(0)(21 downto 0);
--    ta3_max_up1_ul_r(0)                 <= conv_std_logic_vector(0, 32-22) & ta3_max_up1_ul_w(0)(21 downto 0);
    up1_ul_period_r(0)                  <= conv_std_logic_vector(0, 32-8) & up1_ul_period_w(0)(7 downto 0);
    up1_ul_on_time_r(0)                 <= UP1_UL_ON_TIME(0);
    up1_ul_early_r(0)                   <= UP1_UL_EARLY(0);
    up1_ul_late_r(0)                    <= UP1_UL_LATE(0);
    up1_ul_out_of_range_r(0)            <= UP1_UL_OUT_OF_RANGE(0);

--    ta3_min_up2_ul_r(0)                 <= conv_std_logic_vector(0, 32-22) & ta3_min_up2_ul_w(0)(21 downto 0);
--    ta3_max_up2_ul_r(0)                 <= conv_std_logic_vector(0, 32-22) & ta3_max_up2_ul_w(0)(21 downto 0);
    up2_ul_period_r(0)                  <= conv_std_logic_vector(0, 32-8) & up2_ul_period_w(0)(7 downto 0);
    up2_ul_on_time_r(0)                 <= UP2_UL_ON_TIME(0);
    up2_ul_early_r(0)                   <= UP2_UL_EARLY(0);
    up2_ul_late_r(0)                    <= UP2_UL_LATE(0);
    up2_ul_out_of_range_r(0)            <= UP2_UL_OUT_OF_RANGE(0);

--    ta3_min_up3_ul_r(0)                 <= conv_std_logic_vector(0, 32-22) & ta3_min_up3_ul_w(0)(21 downto 0);
--    ta3_max_up3_ul_r(0)                 <= conv_std_logic_vector(0, 32-22) & ta3_max_up3_ul_w(0)(21 downto 0);
    up3_ul_period_r(0)                  <= conv_std_logic_vector(0, 32-8) & up3_ul_period_w(0)(7 downto 0);
    up3_ul_on_time_r(0)                 <= UP3_UL_ON_TIME(0);
    up3_ul_early_r(0)                   <= UP3_UL_EARLY(0);
    up3_ul_late_r(0)                    <= UP3_UL_LATE(0);
    up3_ul_out_of_range_r(0)            <= UP3_UL_OUT_OF_RANGE(0);

--    ta3_min_up4_ul_r(0)                 <= conv_std_logic_vector(0, 32-22) & ta3_min_up4_ul_w(0)(21 downto 0);
--    ta3_max_up4_ul_r(0)                 <= conv_std_logic_vector(0, 32-22) & ta3_max_up4_ul_w(0)(21 downto 0);
    up4_ul_period_r(0)                  <= conv_std_logic_vector(0, 32-8) & up4_ul_period_w(0)(7 downto 0);
    up4_ul_on_time_r(0)                 <= UP4_UL_ON_TIME(0);
    up4_ul_early_r(0)                   <= UP4_UL_EARLY(0);
    up4_ul_late_r(0)                    <= UP4_UL_LATE(0);
    up4_ul_out_of_range_r(0)            <= UP4_UL_OUT_OF_RANGE(0);

--    ta3_min_up5_ul_r(0)                 <= conv_std_logic_vector(0, 32-22) & ta3_min_up5_ul_w(0)(21 downto 0);
--    ta3_max_up5_ul_r(0)                 <= conv_std_logic_vector(0, 32-22) & ta3_max_up5_ul_w(0)(21 downto 0);
    up5_ul_period_r(0)                  <= conv_std_logic_vector(0, 32-8) & up5_ul_period_w(0)(7 downto 0);
    up5_ul_on_time_r(0)                 <= UP5_UL_ON_TIME(0);
    up5_ul_early_r(0)                   <= UP5_UL_EARLY(0);
    up5_ul_late_r(0)                    <= UP5_UL_LATE(0);
    up5_ul_out_of_range_r(0)            <= UP5_UL_OUT_OF_RANGE(0);

    u_READ_UL_CC : for i in UL_UNIT-1 downto 0 generate
--    tx0_c_plane_r(i)                    <= UL_PUxCH_C_PLANE(i);
--    tx0_c_plane_lost_r(i)               <= UL_PUxCH_C_PLANE_LOST(i);
--    tx0_c_plane_buffer_r(i)             <= UL_PUxCH_C_PLANE_BUFFER(i);
    tx0_u_plane_r(i)                    <= UL_PUxCH_U_PLANE(i);
    tx0_u_plane_lost_r(i)               <= UL_PUxCH_U_PLANE_LOST(i);
    tx0_u_plane_buffer_r(i)             <= UL_PUxCH_U_PLANE_BUFFER(i);

--    tx1_c_plane_r(i)                    <= UL_PRACH_C_PLANE(i);
--    tx1_c_plane_lost_r(i)               <= UL_PRACH_C_PLANE_LOST(i);
--    tx1_c_plane_buffer_r(i)             <= UL_PRACH_C_PLANE_BUFFER(i);
    tx1_u_plane_r(i)                    <= UL_PRACH_U_PLANE(i);
    tx1_u_plane_lost_r(i)               <= UL_PRACH_U_PLANE_LOST(i);
    tx1_u_plane_buffer_r(i)             <= UL_PRACH_U_PLANE_BUFFER(i);

--    tx2_c_plane_r(i)                    <= UL_eMTC_C_PLANE(i);
--    tx2_c_plane_lost_r(i)               <= UL_eMTC_C_PLANE_LOST(i);
--    tx2_c_plane_buffer_r(i)             <= UL_eMTC_C_PLANE_BUFFER(i);
    tx2_u_plane_r(i)                    <= UL_eMTC_U_PLANE(i);
    tx2_u_plane_lost_r(i)               <= UL_eMTC_U_PLANE_LOST(i);
    tx2_u_plane_buffer_r(i)             <= UL_eMTC_U_PLANE_BUFFER(i);

--    tx3_c_plane_r(i)                    <= UL_NBIOT0_C_PLANE(i);
--    tx3_c_plane_lost_r(i)               <= UL_NBIOT0_C_PLANE_LOST(i);
--    tx3_c_plane_buffer_r(i)             <= UL_NBIOT0_C_PLANE_BUFFER(i);
    tx3_u_plane_r(i)                    <= UL_NBIOT0_U_PLANE(i);
    tx3_u_plane_lost_r(i)               <= UL_NBIOT0_U_PLANE_LOST(i);
    tx3_u_plane_buffer_r(i)             <= UL_NBIOT0_U_PLANE_BUFFER(i);

--    tx4_c_plane_r(i)                    <= UL_NBIOT1_C_PLANE(i);
--    tx4_c_plane_lost_r(i)               <= UL_NBIOT1_C_PLANE_LOST(i);
--    tx4_c_plane_buffer_r(i)             <= UL_NBIOT1_C_PLANE_BUFFER(i);
    tx4_u_plane_r(i)                    <= UL_NBIOT1_U_PLANE(i);
    tx4_u_plane_lost_r(i)               <= UL_NBIOT1_U_PLANE_LOST(i);
    tx4_u_plane_buffer_r(i)             <= UL_NBIOT1_U_PLANE_BUFFER(i);

--    tx5_c_plane_r(i)                    <= UL_NBIOT2_C_PLANE(i);
--    tx5_c_plane_lost_r(i)               <= UL_NBIOT2_C_PLANE_LOST(i);
--    tx5_c_plane_buffer_r(i)             <= UL_NBIOT2_C_PLANE_BUFFER(i);
    tx5_u_plane_r(i)                    <= UL_NBIOT2_U_PLANE(i);
    tx5_u_plane_lost_r(i)               <= UL_NBIOT2_U_PLANE_LOST(i);
    tx5_u_plane_buffer_r(i)             <= UL_NBIOT2_U_PLANE_BUFFER(i);

    tx_cmd_fifo_full_r(i)               <= UL_CMD_FIFO_FULL(i);

    tx0_termination_r(i)                <= UL_PUxCH_TERMINATION(i);
    tx0_cpsec_symbol0_r(i)              <= UL_PUxCH_CPSEC_SYMBOL0(i);
    tx0_cpsec_symbol1_r(i)              <= UL_PUxCH_CPSEC_SYMBOL1(i);
    tx0_cpsec_symbol2_r(i)              <= UL_PUxCH_CPSEC_SYMBOL2(i);
    tx0_cpsec_symbol3_r(i)              <= UL_PUxCH_CPSEC_SYMBOL3(i);
    tx0_cpsec_symbol4_r(i)              <= UL_PUxCH_CPSEC_SYMBOL4(i);
    tx0_cpsec_symbol5_r(i)              <= UL_PUxCH_CPSEC_SYMBOL5(i);
    tx0_cpsec_symbol6_r(i)              <= UL_PUxCH_CPSEC_SYMBOL6(i);
    tx0_cpsec_symbol7_r(i)              <= UL_PUxCH_CPSEC_SYMBOL7(i);
    tx0_cpsec_symbol8_r(i)              <= UL_PUxCH_CPSEC_SYMBOL8(i);
    tx0_cpsec_symbol9_r(i)              <= UL_PUxCH_CPSEC_SYMBOL9(i);
    tx0_cpsec_symbol10_r(i)             <= UL_PUxCH_CPSEC_SYMBOL10(i);
    tx0_cpsec_symbol11_r(i)             <= UL_PUxCH_CPSEC_SYMBOL11(i);
    tx0_cpsec_symbol12_r(i)             <= UL_PUxCH_CPSEC_SYMBOL12(i);
    tx0_cpsec_symbol13_r(i)             <= UL_PUxCH_CPSEC_SYMBOL13(i);

    tx0_uppkt_symbol0_r(i)              <= UL_PUxCH_UPPKT_SYMBOL0(i);
    tx0_uppkt_symbol1_r(i)              <= UL_PUxCH_UPPKT_SYMBOL1(i);
    tx0_uppkt_symbol2_r(i)              <= UL_PUxCH_UPPKT_SYMBOL2(i);
    tx0_uppkt_symbol3_r(i)              <= UL_PUxCH_UPPKT_SYMBOL3(i);
    tx0_uppkt_symbol4_r(i)              <= UL_PUxCH_UPPKT_SYMBOL4(i);
    tx0_uppkt_symbol5_r(i)              <= UL_PUxCH_UPPKT_SYMBOL5(i);
    tx0_uppkt_symbol6_r(i)              <= UL_PUxCH_UPPKT_SYMBOL6(i);
    tx0_uppkt_symbol7_r(i)              <= UL_PUxCH_UPPKT_SYMBOL7(i);
    tx0_uppkt_symbol8_r(i)              <= UL_PUxCH_UPPKT_SYMBOL8(i);
    tx0_uppkt_symbol9_r(i)              <= UL_PUxCH_UPPKT_SYMBOL9(i);
    tx0_uppkt_symbol10_r(i)             <= UL_PUxCH_UPPKT_SYMBOL10(i);
    tx0_uppkt_symbol11_r(i)             <= UL_PUxCH_UPPKT_SYMBOL11(i);
    tx0_uppkt_symbol12_r(i)             <= UL_PUxCH_UPPKT_SYMBOL12(i);
    tx0_uppkt_symbol13_r(i)             <= UL_PUxCH_UPPKT_SYMBOL13(i);

    tx0_cq_full_symbol0_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL0(i);
    tx0_cq_full_symbol1_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL1(i);
    tx0_cq_full_symbol2_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL2(i);
    tx0_cq_full_symbol3_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL3(i);
    tx0_cq_full_symbol4_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL4(i);
    tx0_cq_full_symbol5_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL5(i);
    tx0_cq_full_symbol6_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL6(i);
    tx0_cq_full_symbol7_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL7(i);
    tx0_cq_full_symbol8_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL8(i);
    tx0_cq_full_symbol9_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL9(i);
    tx0_cq_full_symbol10_r(i)           <= UL_PUxCH_CQ_FULL_SYMBOL10(i);
    tx0_cq_full_symbol11_r(i)           <= UL_PUxCH_CQ_FULL_SYMBOL11(i);
    tx0_cq_full_symbol12_r(i)           <= UL_PUxCH_CQ_FULL_SYMBOL12(i);
    tx0_cq_full_symbol13_r(i)           <= UL_PUxCH_CQ_FULL_SYMBOL13(i);

    tx0_cq_usage_symbol0_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL0(i);
    tx0_cq_usage_symbol1_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL1(i);
    tx0_cq_usage_symbol2_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL2(i);
    tx0_cq_usage_symbol3_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL3(i);
    tx0_cq_usage_symbol4_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL4(i);
    tx0_cq_usage_symbol5_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL5(i);
    tx0_cq_usage_symbol6_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL6(i);
    tx0_cq_usage_symbol7_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL7(i);
    tx0_cq_usage_symbol8_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL8(i);
    tx0_cq_usage_symbol9_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL9(i);
    tx0_cq_usage_symbol10_r(i)          <= UL_PUxCH_CQ_USAGE_SYMBOL10(i);
    tx0_cq_usage_symbol11_r(i)          <= UL_PUxCH_CQ_USAGE_SYMBOL11(i);
    tx0_cq_usage_symbol12_r(i)          <= UL_PUxCH_CQ_USAGE_SYMBOL12(i);
    tx0_cq_usage_symbol13_r(i)          <= UL_PUxCH_CQ_USAGE_SYMBOL13(i);

    tx1_termination_r(i)                <= UL_PRACH_TERMINATION(i);
    tx1_cpsec_symbol0_r(i)              <= UL_PRACH_CPSEC_SYMBOL0(i);
    tx1_cpsec_symbol1_r(i)              <= UL_PRACH_CPSEC_SYMBOL1(i);
    tx1_cpsec_symbol2_r(i)              <= UL_PRACH_CPSEC_SYMBOL2(i);
    tx1_cpsec_symbol3_r(i)              <= UL_PRACH_CPSEC_SYMBOL3(i);
    tx1_cpsec_symbol4_r(i)              <= UL_PRACH_CPSEC_SYMBOL4(i);
    tx1_cpsec_symbol5_r(i)              <= UL_PRACH_CPSEC_SYMBOL5(i);
    tx1_cpsec_symbol6_r(i)              <= UL_PRACH_CPSEC_SYMBOL6(i);
    tx1_cpsec_symbol7_r(i)              <= UL_PRACH_CPSEC_SYMBOL7(i);
    tx1_cpsec_symbol8_r(i)              <= UL_PRACH_CPSEC_SYMBOL8(i);
    tx1_cpsec_symbol9_r(i)              <= UL_PRACH_CPSEC_SYMBOL9(i);
    tx1_cpsec_symbol10_r(i)             <= UL_PRACH_CPSEC_SYMBOL10(i);
    tx1_cpsec_symbol11_r(i)             <= UL_PRACH_CPSEC_SYMBOL11(i);
    tx1_cpsec_symbol12_r(i)             <= UL_PRACH_CPSEC_SYMBOL12(i);
    tx1_cpsec_symbol13_r(i)             <= UL_PRACH_CPSEC_SYMBOL13(i);

    tx1_uppkt_symbol0_r(i)              <= UL_PRACH_UPPKT_SYMBOL0(i);
    tx1_uppkt_symbol1_r(i)              <= UL_PRACH_UPPKT_SYMBOL1(i);
    tx1_uppkt_symbol2_r(i)              <= UL_PRACH_UPPKT_SYMBOL2(i);
    tx1_uppkt_symbol3_r(i)              <= UL_PRACH_UPPKT_SYMBOL3(i);
    tx1_uppkt_symbol4_r(i)              <= UL_PRACH_UPPKT_SYMBOL4(i);
    tx1_uppkt_symbol5_r(i)              <= UL_PRACH_UPPKT_SYMBOL5(i);
    tx1_uppkt_symbol6_r(i)              <= UL_PRACH_UPPKT_SYMBOL6(i);
    tx1_uppkt_symbol7_r(i)              <= UL_PRACH_UPPKT_SYMBOL7(i);
    tx1_uppkt_symbol8_r(i)              <= UL_PRACH_UPPKT_SYMBOL8(i);
    tx1_uppkt_symbol9_r(i)              <= UL_PRACH_UPPKT_SYMBOL9(i);
    tx1_uppkt_symbol10_r(i)             <= UL_PRACH_UPPKT_SYMBOL10(i);
    tx1_uppkt_symbol11_r(i)             <= UL_PRACH_UPPKT_SYMBOL11(i);
    tx1_uppkt_symbol12_r(i)             <= UL_PRACH_UPPKT_SYMBOL12(i);
    tx1_uppkt_symbol13_r(i)             <= UL_PRACH_UPPKT_SYMBOL13(i);

    tx1_cq_full_symbol0_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL0(i);
    tx1_cq_full_symbol1_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL1(i);
    tx1_cq_full_symbol2_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL2(i);
    tx1_cq_full_symbol3_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL3(i);
    tx1_cq_full_symbol4_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL4(i);
    tx1_cq_full_symbol5_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL5(i);
    tx1_cq_full_symbol6_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL6(i);
    tx1_cq_full_symbol7_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL7(i);
    tx1_cq_full_symbol8_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL8(i);
    tx1_cq_full_symbol9_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL9(i);
    tx1_cq_full_symbol10_r(i)           <= UL_PRACH_CQ_FULL_SYMBOL10(i);
    tx1_cq_full_symbol11_r(i)           <= UL_PRACH_CQ_FULL_SYMBOL11(i);
    tx1_cq_full_symbol12_r(i)           <= UL_PRACH_CQ_FULL_SYMBOL12(i);
    tx1_cq_full_symbol13_r(i)           <= UL_PRACH_CQ_FULL_SYMBOL13(i);

    tx1_cq_usage_symbol0_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL0(i);
    tx1_cq_usage_symbol1_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL1(i);
    tx1_cq_usage_symbol2_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL2(i);
    tx1_cq_usage_symbol3_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL3(i);
    tx1_cq_usage_symbol4_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL4(i);
    tx1_cq_usage_symbol5_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL5(i);
    tx1_cq_usage_symbol6_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL6(i);
    tx1_cq_usage_symbol7_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL7(i);
    tx1_cq_usage_symbol8_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL8(i);
    tx1_cq_usage_symbol9_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL9(i);
    tx1_cq_usage_symbol10_r(i)          <= UL_PRACH_CQ_USAGE_SYMBOL10(i);
    tx1_cq_usage_symbol11_r(i)          <= UL_PRACH_CQ_USAGE_SYMBOL11(i);
    tx1_cq_usage_symbol12_r(i)          <= UL_PRACH_CQ_USAGE_SYMBOL12(i);
    tx1_cq_usage_symbol13_r(i)          <= UL_PRACH_CQ_USAGE_SYMBOL13(i);

    tx2_termination_r(i)                <= UL_eMTC_TERMINATION(i);
    tx2_cpsec_symbol0_r(i)              <= UL_eMTC_CPSEC_SYMBOL0(i);
    tx2_cpsec_symbol1_r(i)              <= UL_eMTC_CPSEC_SYMBOL1(i);
    tx2_cpsec_symbol2_r(i)              <= UL_eMTC_CPSEC_SYMBOL2(i);
    tx2_cpsec_symbol3_r(i)              <= UL_eMTC_CPSEC_SYMBOL3(i);
    tx2_cpsec_symbol4_r(i)              <= UL_eMTC_CPSEC_SYMBOL4(i);
    tx2_cpsec_symbol5_r(i)              <= UL_eMTC_CPSEC_SYMBOL5(i);
    tx2_cpsec_symbol6_r(i)              <= UL_eMTC_CPSEC_SYMBOL6(i);
    tx2_cpsec_symbol7_r(i)              <= UL_eMTC_CPSEC_SYMBOL7(i);
    tx2_cpsec_symbol8_r(i)              <= UL_eMTC_CPSEC_SYMBOL8(i);
    tx2_cpsec_symbol9_r(i)              <= UL_eMTC_CPSEC_SYMBOL9(i);
    tx2_cpsec_symbol10_r(i)             <= UL_eMTC_CPSEC_SYMBOL10(i);
    tx2_cpsec_symbol11_r(i)             <= UL_eMTC_CPSEC_SYMBOL11(i);
    tx2_cpsec_symbol12_r(i)             <= UL_eMTC_CPSEC_SYMBOL12(i);
    tx2_cpsec_symbol13_r(i)             <= UL_eMTC_CPSEC_SYMBOL13(i);

    tx2_uppkt_symbol0_r(i)              <= UL_eMTC_UPPKT_SYMBOL0(i);
    tx2_uppkt_symbol1_r(i)              <= UL_eMTC_UPPKT_SYMBOL1(i);
    tx2_uppkt_symbol2_r(i)              <= UL_eMTC_UPPKT_SYMBOL2(i);
    tx2_uppkt_symbol3_r(i)              <= UL_eMTC_UPPKT_SYMBOL3(i);
    tx2_uppkt_symbol4_r(i)              <= UL_eMTC_UPPKT_SYMBOL4(i);
    tx2_uppkt_symbol5_r(i)              <= UL_eMTC_UPPKT_SYMBOL5(i);
    tx2_uppkt_symbol6_r(i)              <= UL_eMTC_UPPKT_SYMBOL6(i);
    tx2_uppkt_symbol7_r(i)              <= UL_eMTC_UPPKT_SYMBOL7(i);
    tx2_uppkt_symbol8_r(i)              <= UL_eMTC_UPPKT_SYMBOL8(i);
    tx2_uppkt_symbol9_r(i)              <= UL_eMTC_UPPKT_SYMBOL9(i);
    tx2_uppkt_symbol10_r(i)             <= UL_eMTC_UPPKT_SYMBOL10(i);
    tx2_uppkt_symbol11_r(i)             <= UL_eMTC_UPPKT_SYMBOL11(i);
    tx2_uppkt_symbol12_r(i)             <= UL_eMTC_UPPKT_SYMBOL12(i);
    tx2_uppkt_symbol13_r(i)             <= UL_eMTC_UPPKT_SYMBOL13(i);

    tx2_cq_full_symbol0_r(i)            <= UL_eMTC_CQ_FULL_SYMBOL0(i);
    tx2_cq_full_symbol1_r(i)            <= UL_eMTC_CQ_FULL_SYMBOL1(i);
    tx2_cq_full_symbol2_r(i)            <= UL_eMTC_CQ_FULL_SYMBOL2(i);
    tx2_cq_full_symbol3_r(i)            <= UL_eMTC_CQ_FULL_SYMBOL3(i);
    tx2_cq_full_symbol4_r(i)            <= UL_eMTC_CQ_FULL_SYMBOL4(i);
    tx2_cq_full_symbol5_r(i)            <= UL_eMTC_CQ_FULL_SYMBOL5(i);
    tx2_cq_full_symbol6_r(i)            <= UL_eMTC_CQ_FULL_SYMBOL6(i);
    tx2_cq_full_symbol7_r(i)            <= UL_eMTC_CQ_FULL_SYMBOL7(i);
    tx2_cq_full_symbol8_r(i)            <= UL_eMTC_CQ_FULL_SYMBOL8(i);
    tx2_cq_full_symbol9_r(i)            <= UL_eMTC_CQ_FULL_SYMBOL9(i);
    tx2_cq_full_symbol10_r(i)           <= UL_eMTC_CQ_FULL_SYMBOL10(i);
    tx2_cq_full_symbol11_r(i)           <= UL_eMTC_CQ_FULL_SYMBOL11(i);
    tx2_cq_full_symbol12_r(i)           <= UL_eMTC_CQ_FULL_SYMBOL12(i);
    tx2_cq_full_symbol13_r(i)           <= UL_eMTC_CQ_FULL_SYMBOL13(i);

    tx2_cq_usage_symbol0_r(i)           <= UL_eMTC_CQ_USAGE_SYMBOL0(i);
    tx2_cq_usage_symbol1_r(i)           <= UL_eMTC_CQ_USAGE_SYMBOL1(i);
    tx2_cq_usage_symbol2_r(i)           <= UL_eMTC_CQ_USAGE_SYMBOL2(i);
    tx2_cq_usage_symbol3_r(i)           <= UL_eMTC_CQ_USAGE_SYMBOL3(i);
    tx2_cq_usage_symbol4_r(i)           <= UL_eMTC_CQ_USAGE_SYMBOL4(i);
    tx2_cq_usage_symbol5_r(i)           <= UL_eMTC_CQ_USAGE_SYMBOL5(i);
    tx2_cq_usage_symbol6_r(i)           <= UL_eMTC_CQ_USAGE_SYMBOL6(i);
    tx2_cq_usage_symbol7_r(i)           <= UL_eMTC_CQ_USAGE_SYMBOL7(i);
    tx2_cq_usage_symbol8_r(i)           <= UL_eMTC_CQ_USAGE_SYMBOL8(i);
    tx2_cq_usage_symbol9_r(i)           <= UL_eMTC_CQ_USAGE_SYMBOL9(i);
    tx2_cq_usage_symbol10_r(i)          <= UL_eMTC_CQ_USAGE_SYMBOL10(i);
    tx2_cq_usage_symbol11_r(i)          <= UL_eMTC_CQ_USAGE_SYMBOL11(i);
    tx2_cq_usage_symbol12_r(i)          <= UL_eMTC_CQ_USAGE_SYMBOL12(i);
    tx2_cq_usage_symbol13_r(i)          <= UL_eMTC_CQ_USAGE_SYMBOL13(i);

    tx3_termination_r(i)                <= UL_NBIOT0_TERMINATION(i);
    tx3_cpsec_symbol0_r(i)              <= UL_NBIOT0_CPSEC_SYMBOL0(i);
    tx3_cpsec_symbol1_r(i)              <= UL_NBIOT0_CPSEC_SYMBOL1(i);
    tx3_cpsec_symbol2_r(i)              <= UL_NBIOT0_CPSEC_SYMBOL2(i);
    tx3_cpsec_symbol3_r(i)              <= UL_NBIOT0_CPSEC_SYMBOL3(i);
    tx3_cpsec_symbol4_r(i)              <= UL_NBIOT0_CPSEC_SYMBOL4(i);
    tx3_cpsec_symbol5_r(i)              <= UL_NBIOT0_CPSEC_SYMBOL5(i);
    tx3_cpsec_symbol6_r(i)              <= UL_NBIOT0_CPSEC_SYMBOL6(i);
    tx3_cpsec_symbol7_r(i)              <= UL_NBIOT0_CPSEC_SYMBOL7(i);
    tx3_cpsec_symbol8_r(i)              <= UL_NBIOT0_CPSEC_SYMBOL8(i);
    tx3_cpsec_symbol9_r(i)              <= UL_NBIOT0_CPSEC_SYMBOL9(i);
    tx3_cpsec_symbol10_r(i)             <= UL_NBIOT0_CPSEC_SYMBOL10(i);
    tx3_cpsec_symbol11_r(i)             <= UL_NBIOT0_CPSEC_SYMBOL11(i);
    tx3_cpsec_symbol12_r(i)             <= UL_NBIOT0_CPSEC_SYMBOL12(i);
    tx3_cpsec_symbol13_r(i)             <= UL_NBIOT0_CPSEC_SYMBOL13(i);

    tx3_uppkt_symbol0_r(i)              <= UL_NBIOT0_UPPKT_SYMBOL0(i);
    tx3_uppkt_symbol1_r(i)              <= UL_NBIOT0_UPPKT_SYMBOL1(i);
    tx3_uppkt_symbol2_r(i)              <= UL_NBIOT0_UPPKT_SYMBOL2(i);
    tx3_uppkt_symbol3_r(i)              <= UL_NBIOT0_UPPKT_SYMBOL3(i);
    tx3_uppkt_symbol4_r(i)              <= UL_NBIOT0_UPPKT_SYMBOL4(i);
    tx3_uppkt_symbol5_r(i)              <= UL_NBIOT0_UPPKT_SYMBOL5(i);
    tx3_uppkt_symbol6_r(i)              <= UL_NBIOT0_UPPKT_SYMBOL6(i);
    tx3_uppkt_symbol7_r(i)              <= UL_NBIOT0_UPPKT_SYMBOL7(i);
    tx3_uppkt_symbol8_r(i)              <= UL_NBIOT0_UPPKT_SYMBOL8(i);
    tx3_uppkt_symbol9_r(i)              <= UL_NBIOT0_UPPKT_SYMBOL9(i);
    tx3_uppkt_symbol10_r(i)             <= UL_NBIOT0_UPPKT_SYMBOL10(i);
    tx3_uppkt_symbol11_r(i)             <= UL_NBIOT0_UPPKT_SYMBOL11(i);
    tx3_uppkt_symbol12_r(i)             <= UL_NBIOT0_UPPKT_SYMBOL12(i);
    tx3_uppkt_symbol13_r(i)             <= UL_NBIOT0_UPPKT_SYMBOL13(i);

    tx3_cq_full_symbol0_r(i)            <= UL_NBIOT0_CQ_FULL_SYMBOL0(i);
    tx3_cq_full_symbol1_r(i)            <= UL_NBIOT0_CQ_FULL_SYMBOL1(i);
    tx3_cq_full_symbol2_r(i)            <= UL_NBIOT0_CQ_FULL_SYMBOL2(i);
    tx3_cq_full_symbol3_r(i)            <= UL_NBIOT0_CQ_FULL_SYMBOL3(i);
    tx3_cq_full_symbol4_r(i)            <= UL_NBIOT0_CQ_FULL_SYMBOL4(i);
    tx3_cq_full_symbol5_r(i)            <= UL_NBIOT0_CQ_FULL_SYMBOL5(i);
    tx3_cq_full_symbol6_r(i)            <= UL_NBIOT0_CQ_FULL_SYMBOL6(i);
    tx3_cq_full_symbol7_r(i)            <= UL_NBIOT0_CQ_FULL_SYMBOL7(i);
    tx3_cq_full_symbol8_r(i)            <= UL_NBIOT0_CQ_FULL_SYMBOL8(i);
    tx3_cq_full_symbol9_r(i)            <= UL_NBIOT0_CQ_FULL_SYMBOL9(i);
    tx3_cq_full_symbol10_r(i)           <= UL_NBIOT0_CQ_FULL_SYMBOL10(i);
    tx3_cq_full_symbol11_r(i)           <= UL_NBIOT0_CQ_FULL_SYMBOL11(i);
    tx3_cq_full_symbol12_r(i)           <= UL_NBIOT0_CQ_FULL_SYMBOL12(i);
    tx3_cq_full_symbol13_r(i)           <= UL_NBIOT0_CQ_FULL_SYMBOL13(i);

    tx3_cq_usage_symbol0_r(i)           <= UL_NBIOT0_CQ_USAGE_SYMBOL0(i);
    tx3_cq_usage_symbol1_r(i)           <= UL_NBIOT0_CQ_USAGE_SYMBOL1(i);
    tx3_cq_usage_symbol2_r(i)           <= UL_NBIOT0_CQ_USAGE_SYMBOL2(i);
    tx3_cq_usage_symbol3_r(i)           <= UL_NBIOT0_CQ_USAGE_SYMBOL3(i);
    tx3_cq_usage_symbol4_r(i)           <= UL_NBIOT0_CQ_USAGE_SYMBOL4(i);
    tx3_cq_usage_symbol5_r(i)           <= UL_NBIOT0_CQ_USAGE_SYMBOL5(i);
    tx3_cq_usage_symbol6_r(i)           <= UL_NBIOT0_CQ_USAGE_SYMBOL6(i);
    tx3_cq_usage_symbol7_r(i)           <= UL_NBIOT0_CQ_USAGE_SYMBOL7(i);
    tx3_cq_usage_symbol8_r(i)           <= UL_NBIOT0_CQ_USAGE_SYMBOL8(i);
    tx3_cq_usage_symbol9_r(i)           <= UL_NBIOT0_CQ_USAGE_SYMBOL9(i);
    tx3_cq_usage_symbol10_r(i)          <= UL_NBIOT0_CQ_USAGE_SYMBOL10(i);
    tx3_cq_usage_symbol11_r(i)          <= UL_NBIOT0_CQ_USAGE_SYMBOL11(i);
    tx3_cq_usage_symbol12_r(i)          <= UL_NBIOT0_CQ_USAGE_SYMBOL12(i);
    tx3_cq_usage_symbol13_r(i)          <= UL_NBIOT0_CQ_USAGE_SYMBOL13(i);

    tx4_termination_r(i)                <= UL_NBIOT1_TERMINATION(i);
    tx4_cpsec_symbol0_r(i)              <= UL_NBIOT1_CPSEC_SYMBOL0(i);
    tx4_cpsec_symbol1_r(i)              <= UL_NBIOT1_CPSEC_SYMBOL1(i);
    tx4_cpsec_symbol2_r(i)              <= UL_NBIOT1_CPSEC_SYMBOL2(i);
    tx4_cpsec_symbol3_r(i)              <= UL_NBIOT1_CPSEC_SYMBOL3(i);
    tx4_cpsec_symbol4_r(i)              <= UL_NBIOT1_CPSEC_SYMBOL4(i);
    tx4_cpsec_symbol5_r(i)              <= UL_NBIOT1_CPSEC_SYMBOL5(i);
    tx4_cpsec_symbol6_r(i)              <= UL_NBIOT1_CPSEC_SYMBOL6(i);
    tx4_cpsec_symbol7_r(i)              <= UL_NBIOT1_CPSEC_SYMBOL7(i);
    tx4_cpsec_symbol8_r(i)              <= UL_NBIOT1_CPSEC_SYMBOL8(i);
    tx4_cpsec_symbol9_r(i)              <= UL_NBIOT1_CPSEC_SYMBOL9(i);
    tx4_cpsec_symbol10_r(i)             <= UL_NBIOT1_CPSEC_SYMBOL10(i);
    tx4_cpsec_symbol11_r(i)             <= UL_NBIOT1_CPSEC_SYMBOL11(i);
    tx4_cpsec_symbol12_r(i)             <= UL_NBIOT1_CPSEC_SYMBOL12(i);
    tx4_cpsec_symbol13_r(i)             <= UL_NBIOT1_CPSEC_SYMBOL13(i);

    tx4_uppkt_symbol0_r(i)              <= UL_NBIOT1_UPPKT_SYMBOL0(i);
    tx4_uppkt_symbol1_r(i)              <= UL_NBIOT1_UPPKT_SYMBOL1(i);
    tx4_uppkt_symbol2_r(i)              <= UL_NBIOT1_UPPKT_SYMBOL2(i);
    tx4_uppkt_symbol3_r(i)              <= UL_NBIOT1_UPPKT_SYMBOL3(i);
    tx4_uppkt_symbol4_r(i)              <= UL_NBIOT1_UPPKT_SYMBOL4(i);
    tx4_uppkt_symbol5_r(i)              <= UL_NBIOT1_UPPKT_SYMBOL5(i);
    tx4_uppkt_symbol6_r(i)              <= UL_NBIOT1_UPPKT_SYMBOL6(i);
    tx4_uppkt_symbol7_r(i)              <= UL_NBIOT1_UPPKT_SYMBOL7(i);
    tx4_uppkt_symbol8_r(i)              <= UL_NBIOT1_UPPKT_SYMBOL8(i);
    tx4_uppkt_symbol9_r(i)              <= UL_NBIOT1_UPPKT_SYMBOL9(i);
    tx4_uppkt_symbol10_r(i)             <= UL_NBIOT1_UPPKT_SYMBOL10(i);
    tx4_uppkt_symbol11_r(i)             <= UL_NBIOT1_UPPKT_SYMBOL11(i);
    tx4_uppkt_symbol12_r(i)             <= UL_NBIOT1_UPPKT_SYMBOL12(i);
    tx4_uppkt_symbol13_r(i)             <= UL_NBIOT1_UPPKT_SYMBOL13(i);

    tx4_cq_full_symbol0_r(i)            <= UL_NBIOT1_CQ_FULL_SYMBOL0(i);
    tx4_cq_full_symbol1_r(i)            <= UL_NBIOT1_CQ_FULL_SYMBOL1(i);
    tx4_cq_full_symbol2_r(i)            <= UL_NBIOT1_CQ_FULL_SYMBOL2(i);
    tx4_cq_full_symbol3_r(i)            <= UL_NBIOT1_CQ_FULL_SYMBOL3(i);
    tx4_cq_full_symbol4_r(i)            <= UL_NBIOT1_CQ_FULL_SYMBOL4(i);
    tx4_cq_full_symbol5_r(i)            <= UL_NBIOT1_CQ_FULL_SYMBOL5(i);
    tx4_cq_full_symbol6_r(i)            <= UL_NBIOT1_CQ_FULL_SYMBOL6(i);
    tx4_cq_full_symbol7_r(i)            <= UL_NBIOT1_CQ_FULL_SYMBOL7(i);
    tx4_cq_full_symbol8_r(i)            <= UL_NBIOT1_CQ_FULL_SYMBOL8(i);
    tx4_cq_full_symbol9_r(i)            <= UL_NBIOT1_CQ_FULL_SYMBOL9(i);
    tx4_cq_full_symbol10_r(i)           <= UL_NBIOT1_CQ_FULL_SYMBOL10(i);
    tx4_cq_full_symbol11_r(i)           <= UL_NBIOT1_CQ_FULL_SYMBOL11(i);
    tx4_cq_full_symbol12_r(i)           <= UL_NBIOT1_CQ_FULL_SYMBOL12(i);
    tx4_cq_full_symbol13_r(i)           <= UL_NBIOT1_CQ_FULL_SYMBOL13(i);

    tx4_cq_usage_symbol0_r(i)           <= UL_NBIOT1_CQ_USAGE_SYMBOL0(i);
    tx4_cq_usage_symbol1_r(i)           <= UL_NBIOT1_CQ_USAGE_SYMBOL1(i);
    tx4_cq_usage_symbol2_r(i)           <= UL_NBIOT1_CQ_USAGE_SYMBOL2(i);
    tx4_cq_usage_symbol3_r(i)           <= UL_NBIOT1_CQ_USAGE_SYMBOL3(i);
    tx4_cq_usage_symbol4_r(i)           <= UL_NBIOT1_CQ_USAGE_SYMBOL4(i);
    tx4_cq_usage_symbol5_r(i)           <= UL_NBIOT1_CQ_USAGE_SYMBOL5(i);
    tx4_cq_usage_symbol6_r(i)           <= UL_NBIOT1_CQ_USAGE_SYMBOL6(i);
    tx4_cq_usage_symbol7_r(i)           <= UL_NBIOT1_CQ_USAGE_SYMBOL7(i);
    tx4_cq_usage_symbol8_r(i)           <= UL_NBIOT1_CQ_USAGE_SYMBOL8(i);
    tx4_cq_usage_symbol9_r(i)           <= UL_NBIOT1_CQ_USAGE_SYMBOL9(i);
    tx4_cq_usage_symbol10_r(i)          <= UL_NBIOT1_CQ_USAGE_SYMBOL10(i);
    tx4_cq_usage_symbol11_r(i)          <= UL_NBIOT1_CQ_USAGE_SYMBOL11(i);
    tx4_cq_usage_symbol12_r(i)          <= UL_NBIOT1_CQ_USAGE_SYMBOL12(i);
    tx4_cq_usage_symbol13_r(i)          <= UL_NBIOT1_CQ_USAGE_SYMBOL13(i);

    tx5_termination_r(i)                <= UL_NBIOT2_TERMINATION(i);
    tx5_cpsec_symbol0_r(i)              <= UL_NBIOT2_CPSEC_SYMBOL0(i);
    tx5_cpsec_symbol1_r(i)              <= UL_NBIOT2_CPSEC_SYMBOL1(i);
    tx5_cpsec_symbol2_r(i)              <= UL_NBIOT2_CPSEC_SYMBOL2(i);
    tx5_cpsec_symbol3_r(i)              <= UL_NBIOT2_CPSEC_SYMBOL3(i);
    tx5_cpsec_symbol4_r(i)              <= UL_NBIOT2_CPSEC_SYMBOL4(i);
    tx5_cpsec_symbol5_r(i)              <= UL_NBIOT2_CPSEC_SYMBOL5(i);
    tx5_cpsec_symbol6_r(i)              <= UL_NBIOT2_CPSEC_SYMBOL6(i);
    tx5_cpsec_symbol7_r(i)              <= UL_NBIOT2_CPSEC_SYMBOL7(i);
    tx5_cpsec_symbol8_r(i)              <= UL_NBIOT2_CPSEC_SYMBOL8(i);
    tx5_cpsec_symbol9_r(i)              <= UL_NBIOT2_CPSEC_SYMBOL9(i);
    tx5_cpsec_symbol10_r(i)             <= UL_NBIOT2_CPSEC_SYMBOL10(i);
    tx5_cpsec_symbol11_r(i)             <= UL_NBIOT2_CPSEC_SYMBOL11(i);
    tx5_cpsec_symbol12_r(i)             <= UL_NBIOT2_CPSEC_SYMBOL12(i);
    tx5_cpsec_symbol13_r(i)             <= UL_NBIOT2_CPSEC_SYMBOL13(i);

    tx5_uppkt_symbol0_r(i)              <= UL_NBIOT2_UPPKT_SYMBOL0(i);
    tx5_uppkt_symbol1_r(i)              <= UL_NBIOT2_UPPKT_SYMBOL1(i);
    tx5_uppkt_symbol2_r(i)              <= UL_NBIOT2_UPPKT_SYMBOL2(i);
    tx5_uppkt_symbol3_r(i)              <= UL_NBIOT2_UPPKT_SYMBOL3(i);
    tx5_uppkt_symbol4_r(i)              <= UL_NBIOT2_UPPKT_SYMBOL4(i);
    tx5_uppkt_symbol5_r(i)              <= UL_NBIOT2_UPPKT_SYMBOL5(i);
    tx5_uppkt_symbol6_r(i)              <= UL_NBIOT2_UPPKT_SYMBOL6(i);
    tx5_uppkt_symbol7_r(i)              <= UL_NBIOT2_UPPKT_SYMBOL7(i);
    tx5_uppkt_symbol8_r(i)              <= UL_NBIOT2_UPPKT_SYMBOL8(i);
    tx5_uppkt_symbol9_r(i)              <= UL_NBIOT2_UPPKT_SYMBOL9(i);
    tx5_uppkt_symbol10_r(i)             <= UL_NBIOT2_UPPKT_SYMBOL10(i);
    tx5_uppkt_symbol11_r(i)             <= UL_NBIOT2_UPPKT_SYMBOL11(i);
    tx5_uppkt_symbol12_r(i)             <= UL_NBIOT2_UPPKT_SYMBOL12(i);
    tx5_uppkt_symbol13_r(i)             <= UL_NBIOT2_UPPKT_SYMBOL13(i);

    tx5_cq_full_symbol0_r(i)            <= UL_NBIOT2_CQ_FULL_SYMBOL0(i);
    tx5_cq_full_symbol1_r(i)            <= UL_NBIOT2_CQ_FULL_SYMBOL1(i);
    tx5_cq_full_symbol2_r(i)            <= UL_NBIOT2_CQ_FULL_SYMBOL2(i);
    tx5_cq_full_symbol3_r(i)            <= UL_NBIOT2_CQ_FULL_SYMBOL3(i);
    tx5_cq_full_symbol4_r(i)            <= UL_NBIOT2_CQ_FULL_SYMBOL4(i);
    tx5_cq_full_symbol5_r(i)            <= UL_NBIOT2_CQ_FULL_SYMBOL5(i);
    tx5_cq_full_symbol6_r(i)            <= UL_NBIOT2_CQ_FULL_SYMBOL6(i);
    tx5_cq_full_symbol7_r(i)            <= UL_NBIOT2_CQ_FULL_SYMBOL7(i);
    tx5_cq_full_symbol8_r(i)            <= UL_NBIOT2_CQ_FULL_SYMBOL8(i);
    tx5_cq_full_symbol9_r(i)            <= UL_NBIOT2_CQ_FULL_SYMBOL9(i);
    tx5_cq_full_symbol10_r(i)           <= UL_NBIOT2_CQ_FULL_SYMBOL10(i);
    tx5_cq_full_symbol11_r(i)           <= UL_NBIOT2_CQ_FULL_SYMBOL11(i);
    tx5_cq_full_symbol12_r(i)           <= UL_NBIOT2_CQ_FULL_SYMBOL12(i);
    tx5_cq_full_symbol13_r(i)           <= UL_NBIOT2_CQ_FULL_SYMBOL13(i);

    tx5_cq_usage_symbol0_r(i)           <= UL_NBIOT2_CQ_USAGE_SYMBOL0(i);
    tx5_cq_usage_symbol1_r(i)           <= UL_NBIOT2_CQ_USAGE_SYMBOL1(i);
    tx5_cq_usage_symbol2_r(i)           <= UL_NBIOT2_CQ_USAGE_SYMBOL2(i);
    tx5_cq_usage_symbol3_r(i)           <= UL_NBIOT2_CQ_USAGE_SYMBOL3(i);
    tx5_cq_usage_symbol4_r(i)           <= UL_NBIOT2_CQ_USAGE_SYMBOL4(i);
    tx5_cq_usage_symbol5_r(i)           <= UL_NBIOT2_CQ_USAGE_SYMBOL5(i);
    tx5_cq_usage_symbol6_r(i)           <= UL_NBIOT2_CQ_USAGE_SYMBOL6(i);
    tx5_cq_usage_symbol7_r(i)           <= UL_NBIOT2_CQ_USAGE_SYMBOL7(i);
    tx5_cq_usage_symbol8_r(i)           <= UL_NBIOT2_CQ_USAGE_SYMBOL8(i);
    tx5_cq_usage_symbol9_r(i)           <= UL_NBIOT2_CQ_USAGE_SYMBOL9(i);
    tx5_cq_usage_symbol10_r(i)          <= UL_NBIOT2_CQ_USAGE_SYMBOL10(i);
    tx5_cq_usage_symbol11_r(i)          <= UL_NBIOT2_CQ_USAGE_SYMBOL11(i);
    tx5_cq_usage_symbol12_r(i)          <= UL_NBIOT2_CQ_USAGE_SYMBOL12(i);
    tx5_cq_usage_symbol13_r(i)          <= UL_NBIOT2_CQ_USAGE_SYMBOL13(i);
    end generate;

--------------------------------------------------------------------------------
-- Write register
--------------------------------------------------------------------------------

--    u_WRITE_DL_CC : for i in DL_UNIT-1 downto 0 generate
    u_0x0000_WRITE : MPI_REG_WO generic map(32, x"00", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_mac_w(0)(31 downto 0) );
    u_0x0001_WRITE : MPI_REG_WO generic map(32, x"01", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_mac_w(0)(63 downto 32) );

    u_0x0020_WRITE : MPI_REG_WO generic map(32, x"20", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(0)(0) );
--    u_0x0021_WRITE : MPI_REG_WO generic map(32, x"21", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(0)(0) );
    u_0x0022_WRITE : MPI_REG_WO generic map(32, x"22", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(0)(0) );
    u_0x0023_WRITE : MPI_REG_WO generic map(32, x"23", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(0)(0) );
    u_0x0024_WRITE : MPI_REG_WO generic map(32, x"24", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(0)(1) );
--    u_0x0025_WRITE : MPI_REG_WO generic map(32, x"25", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(0)(1) );
    u_0x0026_WRITE : MPI_REG_WO generic map(32, x"26", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(0)(1) );
    u_0x0027_WRITE : MPI_REG_WO generic map(32, x"27", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(0)(1) );
    u_0x0028_WRITE : MPI_REG_WO generic map(32, x"28", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(0)(2) );
--    u_0x0029_WRITE : MPI_REG_WO generic map(32, x"29", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(0)(2) );
    u_0x002A_WRITE : MPI_REG_WO generic map(32, x"2A", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(0)(2) );
    u_0x002B_WRITE : MPI_REG_WO generic map(32, x"2B", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(0)(2) );
    u_0x002C_WRITE : MPI_REG_WO generic map(32, x"2C", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(0)(3) );
--    u_0x002D_WRITE : MPI_REG_WO generic map(32, x"2D", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(0)(3) );
    u_0x002E_WRITE : MPI_REG_WO generic map(32, x"2E", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(0)(3) );
    u_0x002F_WRITE : MPI_REG_WO generic map(32, x"2F", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(0)(3) );
    u_0x0030_WRITE : MPI_REG_WO generic map(32, x"30", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(0)(4) );
--    u_0x0031_WRITE : MPI_REG_WO generic map(32, x"31", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(0)(4) );
    u_0x0032_WRITE : MPI_REG_WO generic map(32, x"32", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(0)(4) );
    u_0x0033_WRITE : MPI_REG_WO generic map(32, x"33", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(0)(4) );
    u_0x0034_WRITE : MPI_REG_WO generic map(32, x"34", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(0)(5) );
--    u_0x0035_WRITE : MPI_REG_WO generic map(32, x"35", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(0)(5) );
    u_0x0036_WRITE : MPI_REG_WO generic map(32, x"36", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(0)(5) );
    u_0x0037_WRITE : MPI_REG_WO generic map(32, x"37", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(0)(5) );
    u_0x0038_WRITE : MPI_REG_WO generic map(32, x"38", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(0)(6) );
--    u_0x0039_WRITE : MPI_REG_WO generic map(32, x"39", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(0)(6) );
    u_0x003A_WRITE : MPI_REG_WO generic map(32, x"3A", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(0)(6) );
    u_0x003B_WRITE : MPI_REG_WO generic map(32, x"3B", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(0)(6) );
    u_0x003C_WRITE : MPI_REG_WO generic map(32, x"3C", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(0)(7) );
--    u_0x003D_WRITE : MPI_REG_WO generic map(32, x"3D", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(0)(7) );
    u_0x003E_WRITE : MPI_REG_WO generic map(32, x"3E", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(0)(7) );
    u_0x003F_WRITE : MPI_REG_WO generic map(32, x"3F", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(0)(7) );

    u_0x0040_WRITE : MPI_REG_WO generic map(32, x"40", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_comp_mode_w(0) );
    u_0x0041_WRITE : MPI_REG_WO generic map(32, x"41", x"00000011") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_scs_config_w(0) );
    u_0x0042_WRITE : MPI_REG_WO generic map(32, x"42", x"0000000C") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_fft_size_w(0) );
    u_0x0043_WRITE : MPI_REG_WO generic map(32, x"43", x"00000111") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_prb_per_symbol_w(0) );
    u_0x0044_WRITE : MPI_REG_WO generic map(32, x"44", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, rx_comp_exp_offset_w(0) );

    u_0x0060_WRITE : MPI_REG_WO generic map(32, x"60", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, t2a_max_cp_dl_w(0) );
    u_0x0061_WRITE : MPI_REG_WO generic map(32, x"61", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, t2a_min_cp_dl_w(0) );
    u_0x0062_WRITE : MPI_REG_WO generic map(32, x"62", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, cp_dl_period_w(0) );

    u_0x0070_WRITE : MPI_REG_WO generic map(32, x"70", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, t2a_max_up_dl_w(0) );
    u_0x0071_WRITE : MPI_REG_WO generic map(32, x"71", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, t2a_min_up_dl_w(0) );
    u_0x0072_WRITE : MPI_REG_WO generic map(32, x"72", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, up_dl_period_w(0) );

--    u_0x0120_WRITE : MPI_REG_WO generic map(32, x"20", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(1)(0) );
--    u_0x0121_WRITE : MPI_REG_WO generic map(32, x"21", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(1)(0) );
    u_0x0122_WRITE : MPI_REG_WO generic map(32, x"22", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(1)(0) );
--    u_0x0123_WRITE : MPI_REG_WO generic map(32, x"23", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(1)(0) );
--    u_0x0124_WRITE : MPI_REG_WO generic map(32, x"24", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(1)(1) );
--    u_0x0125_WRITE : MPI_REG_WO generic map(32, x"25", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(1)(1) );
    u_0x0126_WRITE : MPI_REG_WO generic map(32, x"26", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(1)(1) );
--    u_0x0127_WRITE : MPI_REG_WO generic map(32, x"27", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(1)(1) );
--    u_0x0128_WRITE : MPI_REG_WO generic map(32, x"28", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(1)(2) );
--    u_0x0129_WRITE : MPI_REG_WO generic map(32, x"29", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(1)(2) );
    u_0x012A_WRITE : MPI_REG_WO generic map(32, x"2A", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(1)(2) );
--    u_0x012B_WRITE : MPI_REG_WO generic map(32, x"2B", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(1)(2) );
--    u_0x012C_WRITE : MPI_REG_WO generic map(32, x"2C", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(1)(3) );
--    u_0x012D_WRITE : MPI_REG_WO generic map(32, x"2D", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(1)(3) );
    u_0x012E_WRITE : MPI_REG_WO generic map(32, x"2E", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(1)(3) );
--    u_0x012F_WRITE : MPI_REG_WO generic map(32, x"2F", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(1)(3) );
--    u_0x0130_WRITE : MPI_REG_WO generic map(32, x"30", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(1)(4) );
--    u_0x0131_WRITE : MPI_REG_WO generic map(32, x"31", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(1)(4) );
    u_0x0132_WRITE : MPI_REG_WO generic map(32, x"32", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(1)(4) );
--    u_0x0133_WRITE : MPI_REG_WO generic map(32, x"33", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(1)(4) );
--    u_0x0134_WRITE : MPI_REG_WO generic map(32, x"34", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(1)(5) );
--    u_0x0135_WRITE : MPI_REG_WO generic map(32, x"35", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(1)(5) );
    u_0x0136_WRITE : MPI_REG_WO generic map(32, x"36", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(1)(5) );
--    u_0x0137_WRITE : MPI_REG_WO generic map(32, x"37", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(1)(5) );
--    u_0x0138_WRITE : MPI_REG_WO generic map(32, x"38", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(1)(6) );
--    u_0x0139_WRITE : MPI_REG_WO generic map(32, x"39", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(1)(6) );
    u_0x013A_WRITE : MPI_REG_WO generic map(32, x"3A", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(1)(6) );
--    u_0x013B_WRITE : MPI_REG_WO generic map(32, x"3B", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(1)(6) );
--    u_0x013C_WRITE : MPI_REG_WO generic map(32, x"3C", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(1)(7) );
--    u_0x013D_WRITE : MPI_REG_WO generic map(32, x"3D", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(1)(7) );
    u_0x013E_WRITE : MPI_REG_WO generic map(32, x"3E", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(1)(7) );
--    u_0x013F_WRITE : MPI_REG_WO generic map(32, x"3F", x"00000000") port map(RST, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(1)(7) );
--    end generate;

--    u_WRITE_UL_CC : for i in UL_UNIT-1 downto 0 generate
    u_0x0010_WRITE : MPI_REG_WO generic map(32, x"10", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, tx_param_dst_mac_w(0)(31 downto 0) );
    u_0x0011_WRITE : MPI_REG_WO generic map(32, x"11", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, tx_param_dst_mac_w(0)(63 downto 32) );
    u_0x0012_WRITE : MPI_REG_WO generic map(32, x"12", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, tx_param_src_mac_w(0)(31 downto 0) );
    u_0x0013_WRITE : MPI_REG_WO generic map(32, x"13", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, tx_param_src_mac_w(0)(63 downto 32) );
    u_0x0014_WRITE : MPI_REG_WO generic map(32, x"14", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, tx_param_vlan0_w(0) );
    u_0x0015_WRITE : MPI_REG_WO generic map(32, x"15", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, tx_param_vlan1_w(0) );

    u_0x0018_WRITE : MPI_REG_WO generic map(32, x"18", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, ignore_frame_id_w(0) );

    u_0x0050_WRITE : MPI_REG_WO generic map(32, x"50", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, tx_comp_mode_w(0) );
    u_0x0051_WRITE : MPI_REG_WO generic map(32, x"51", x"00000011") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, tx_scs_config_w(0) );
    u_0x0052_WRITE : MPI_REG_WO generic map(32, x"52", x"0000000C") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, tx_fft_size_w(0) );
    u_0x0053_WRITE : MPI_REG_WO generic map(32, x"53", x"00640111") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, tx_prb_per_symbol_w(0) );
    u_0x0054_WRITE : MPI_REG_WO generic map(32, x"54", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, tx_comp_exp_offset_w(0) );
    u_0x0055_WRITE : MPI_REG_WO generic map(32, x"55", x"00000001") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, tx_comp_gain_offset_w(0) );
    u_0x0056_WRITE : MPI_REG_WO generic map(32, x"56", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, tx_comp_scale_gain_offset_w(0) );

    u_0x0080_WRITE : MPI_REG_WO generic map(32, x"80", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, t2a_max_cp_ul_w(0) );
    u_0x0081_WRITE : MPI_REG_WO generic map(32, x"81", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, t2a_min_cp_ul_w(0) );
    u_0x0082_WRITE : MPI_REG_WO generic map(32, x"82", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, cp_ul_period_w(0) );

--    u_0x0090_WRITE : MPI_REG_WO generic map(32, x"90", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, ta3_min_up0_ul_w(0) );
--    u_0x0091_WRITE : MPI_REG_WO generic map(32, x"91", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, ta3_max_up0_ul_w(0) );
    u_0x0092_WRITE : MPI_REG_WO generic map(32, x"92", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, up0_ul_period_w(0) );

--    u_0x00A0_WRITE : MPI_REG_WO generic map(32, x"A0", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, ta3_min_up1_ul_w(0) );
--    u_0x00A1_WRITE : MPI_REG_WO generic map(32, x"A1", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, ta3_max_up1_ul_w(0) );
    u_0x00A2_WRITE : MPI_REG_WO generic map(32, x"A2", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, up1_ul_period_w(0) );

--    u_0x00B0_WRITE : MPI_REG_WO generic map(32, x"B0", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, ta3_min_up2_ul_w(0) );
--    u_0x00B1_WRITE : MPI_REG_WO generic map(32, x"B1", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, ta3_max_up2_ul_w(0) );
    u_0x00B2_WRITE : MPI_REG_WO generic map(32, x"B2", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, up2_ul_period_w(0) );

--    u_0x00C0_WRITE : MPI_REG_WO generic map(32, x"C0", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, ta3_min_up3_ul_w(0) );
--    u_0x00C1_WRITE : MPI_REG_WO generic map(32, x"C1", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, ta3_max_up3_ul_w(0) );
    u_0x00C2_WRITE : MPI_REG_WO generic map(32, x"C2", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, up3_ul_period_w(0) );

--    u_0x00D0_WRITE : MPI_REG_WO generic map(32, x"D0", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, ta3_min_up4_ul_w(0) );
--    u_0x00D1_WRITE : MPI_REG_WO generic map(32, x"D1", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, ta3_max_up4_ul_w(0) );
    u_0x00D2_WRITE : MPI_REG_WO generic map(32, x"D2", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, up4_ul_period_w(0) );

--    u_0x00E0_WRITE : MPI_REG_WO generic map(32, x"E0", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, ta3_min_up5_ul_w(0) );
--    u_0x00E1_WRITE : MPI_REG_WO generic map(32, x"E1", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, ta3_max_up5_ul_w(0) );
    u_0x00E2_WRITE : MPI_REG_WO generic map(32, x"E2", x"00000000") port map(RST, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, up5_ul_period_w(0) );
--    end generate;

--------------------------------------------------------------------------------
-- CDC register
--------------------------------------------------------------------------------


--------------------------------------------------------------------------------
-- Flag/status register
--------------------------------------------------------------------------------

    u_LATCH_DL_CC : for i in 0 downto 0 generate
    u_0x0820_LATCH : MPI_REG_RC generic map(32, x"20") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch0_0_r(i),  open, rx_fault_id_31_ch0_0_f(i) );
    u_0x0821_LATCH : MPI_REG_RC generic map(32, x"21") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch0_1_r(i),  open, rx_fault_id_31_ch0_1_f(i) );
    u_0x0822_LATCH : MPI_REG_RC generic map(32, x"22") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch0_2_r(i),  open, rx_fault_id_31_ch0_2_f(i) );
    u_0x0823_LATCH : MPI_REG_RC generic map(32, x"23") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch0_3_r(i),  open, rx_fault_id_31_ch0_3_f(i) );
    u_0x0824_LATCH : MPI_REG_RC generic map(32, x"24") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch1_0_r(i),  open, rx_fault_id_31_ch1_0_f(i) );
    u_0x0825_LATCH : MPI_REG_RC generic map(32, x"25") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch1_1_r(i),  open, rx_fault_id_31_ch1_1_f(i) );
    u_0x0826_LATCH : MPI_REG_RC generic map(32, x"26") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch1_2_r(i),  open, rx_fault_id_31_ch1_2_f(i) );
    u_0x0827_LATCH : MPI_REG_RC generic map(32, x"27") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch1_3_r(i),  open, rx_fault_id_31_ch1_3_f(i) );
    u_0x0828_LATCH : MPI_REG_RC generic map(32, x"28") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch2_0_r(i),  open, rx_fault_id_31_ch2_0_f(i) );
    u_0x0829_LATCH : MPI_REG_RC generic map(32, x"29") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch2_1_r(i),  open, rx_fault_id_31_ch2_1_f(i) );
    u_0x082A_LATCH : MPI_REG_RC generic map(32, x"2A") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch2_2_r(i),  open, rx_fault_id_31_ch2_2_f(i) );
    u_0x082B_LATCH : MPI_REG_RC generic map(32, x"2B") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch2_3_r(i),  open, rx_fault_id_31_ch2_3_f(i) );
    u_0x082C_LATCH : MPI_REG_RC generic map(32, x"2C") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch3_0_r(i),  open, rx_fault_id_31_ch3_0_f(i) );
    u_0x082D_LATCH : MPI_REG_RC generic map(32, x"2D") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch3_1_r(i),  open, rx_fault_id_31_ch3_1_f(i) );
    u_0x082E_LATCH : MPI_REG_RC generic map(32, x"2E") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch3_2_r(i),  open, rx_fault_id_31_ch3_2_f(i) );
    u_0x082F_LATCH : MPI_REG_RC generic map(32, x"2F") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch3_3_r(i),  open, rx_fault_id_31_ch3_3_f(i) );
    u_0x0830_LATCH : MPI_REG_RC generic map(32, x"30") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch4_0_r(i),  open, rx_fault_id_31_ch4_0_f(i) );
    u_0x0831_LATCH : MPI_REG_RC generic map(32, x"31") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch4_1_r(i),  open, rx_fault_id_31_ch4_1_f(i) );
    u_0x0832_LATCH : MPI_REG_RC generic map(32, x"32") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch4_2_r(i),  open, rx_fault_id_31_ch4_2_f(i) );
    u_0x0833_LATCH : MPI_REG_RC generic map(32, x"33") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch4_3_r(i),  open, rx_fault_id_31_ch4_3_f(i) );
    u_0x0834_LATCH : MPI_REG_RC generic map(32, x"34") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch5_0_r(i),  open, rx_fault_id_31_ch5_0_f(i) );
    u_0x0835_LATCH : MPI_REG_RC generic map(32, x"35") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch5_1_r(i),  open, rx_fault_id_31_ch5_1_f(i) );
    u_0x0836_LATCH : MPI_REG_RC generic map(32, x"36") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch5_2_r(i),  open, rx_fault_id_31_ch5_2_f(i) );
    u_0x0837_LATCH : MPI_REG_RC generic map(32, x"37") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch5_3_r(i),  open, rx_fault_id_31_ch5_3_f(i) );
    u_0x0838_LATCH : MPI_REG_RC generic map(32, x"38") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch6_0_r(i),  open, rx_fault_id_31_ch6_0_f(i) );
    u_0x0839_LATCH : MPI_REG_RC generic map(32, x"39") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch6_1_r(i),  open, rx_fault_id_31_ch6_1_f(i) );
    u_0x083A_LATCH : MPI_REG_RC generic map(32, x"3A") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch6_2_r(i),  open, rx_fault_id_31_ch6_2_f(i) );
    u_0x083B_LATCH : MPI_REG_RC generic map(32, x"3B") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch6_3_r(i),  open, rx_fault_id_31_ch6_3_f(i) );
    u_0x083C_LATCH : MPI_REG_RC generic map(32, x"3C") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch7_0_r(i),  open, rx_fault_id_31_ch7_0_f(i) );
    u_0x083D_LATCH : MPI_REG_RC generic map(32, x"3D") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch7_1_r(i),  open, rx_fault_id_31_ch7_1_f(i) );
    u_0x083E_LATCH : MPI_REG_RC generic map(32, x"3E") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch7_2_r(i),  open, rx_fault_id_31_ch7_2_f(i) );
    u_0x083F_LATCH : MPI_REG_RC generic map(32, x"3F") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch7_3_r(i),  open, rx_fault_id_31_ch7_3_f(i) );

    u_0x0C10_LATCH : MPI_REG_RC generic map(32, x"10") port map(RST, CLK, oe(i+12), addr_lsb, rx_c_plane_exist_r(i),  open, rx_c_plane_exist_f(i) );
    u_0x0C13_LATCH : MPI_REG_RC generic map(32, x"13") port map(RST, CLK, oe(i+12), addr_lsb, rx_c_plane_buffer_r(i), open, rx_c_plane_buffer_f(i) );
    u_0x0C14_LATCH : MPI_REG_RC generic map(32, x"14") port map(RST, CLK, oe(i+12), addr_lsb, rx_u_plane_exist_r(i),  open, rx_u_plane_exist_f(i) );
    u_0x0C17_LATCH : MPI_REG_RC generic map(32, x"17") port map(RST, CLK, oe(i+12), addr_lsb, rx_u_plane_buffer_r(i), open, rx_u_plane_buffer_f(i) );
    end generate;

    u_LATCH_UL_CC : for i in UL_UNIT-1 downto 0 generate
--    u_0x0C23_LATCH : MPI_REG_RC generic map(32, x"23") port map(RST, CLK, oe(i+12), addr_lsb, tx0_c_plane_buffer_r(i), open, tx0_c_plane_buffer_f(i) );
    u_0x0C27_LATCH : MPI_REG_RC generic map(32, x"27") port map(RST, CLK, oe(i+12), addr_lsb, tx0_u_plane_buffer_r(i), open, tx0_u_plane_buffer_f(i) );
--    u_0x0C2B_LATCH : MPI_REG_RC generic map(32, x"2B") port map(RST, CLK, oe(i+12), addr_lsb, tx1_c_plane_buffer_r(i), open, tx1_c_plane_buffer_f(i) );
    u_0x0C2F_LATCH : MPI_REG_RC generic map(32, x"2F") port map(RST, CLK, oe(i+12), addr_lsb, tx1_u_plane_buffer_r(i), open, tx1_u_plane_buffer_f(i) );
--    u_0x0C33_LATCH : MPI_REG_RC generic map(32, x"33") port map(RST, CLK, oe(i+12), addr_lsb, tx2_c_plane_buffer_r(i), open, tx2_c_plane_buffer_f(i) );
    u_0x0C37_LATCH : MPI_REG_RC generic map(32, x"37") port map(RST, CLK, oe(i+12), addr_lsb, tx2_u_plane_buffer_r(i), open, tx2_u_plane_buffer_f(i) );
--    u_0x0C3B_LATCH : MPI_REG_RC generic map(32, x"3B") port map(RST, CLK, oe(i+12), addr_lsb, tx3_c_plane_buffer_r(i), open, tx3_c_plane_buffer_f(i) );
    u_0x0C3F_LATCH : MPI_REG_RC generic map(32, x"3F") port map(RST, CLK, oe(i+12), addr_lsb, tx3_u_plane_buffer_r(i), open, tx3_u_plane_buffer_f(i) );
--    u_0x0C43_LATCH : MPI_REG_RC generic map(32, x"43") port map(RST, CLK, oe(i+12), addr_lsb, tx4_c_plane_buffer_r(i), open, tx4_c_plane_buffer_f(i) );
    u_0x0C47_LATCH : MPI_REG_RC generic map(32, x"47") port map(RST, CLK, oe(i+12), addr_lsb, tx4_u_plane_buffer_r(i), open, tx4_u_plane_buffer_f(i) );
--    u_0x0C4B_LATCH : MPI_REG_RC generic map(32, x"4B") port map(RST, CLK, oe(i+12), addr_lsb, tx5_c_plane_buffer_r(i), open, tx5_c_plane_buffer_f(i) );
    u_0x0C4F_LATCH : MPI_REG_RC generic map(32, x"4F") port map(RST, CLK, oe(i+12), addr_lsb, tx5_u_plane_buffer_r(i), open, tx5_u_plane_buffer_f(i) );

    u_0x1030_LATCH : MPI_REG_RC generic map(32, x"30") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol0_r(i),  open, tx0_cq_usage_symbol0_f(i) );
    u_0x1031_LATCH : MPI_REG_RC generic map(32, x"31") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol1_r(i),  open, tx0_cq_usage_symbol1_f(i) );
    u_0x1032_LATCH : MPI_REG_RC generic map(32, x"32") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol2_r(i),  open, tx0_cq_usage_symbol2_f(i) );
    u_0x1033_LATCH : MPI_REG_RC generic map(32, x"33") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol3_r(i),  open, tx0_cq_usage_symbol3_f(i) );
    u_0x1034_LATCH : MPI_REG_RC generic map(32, x"34") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol4_r(i),  open, tx0_cq_usage_symbol4_f(i) );
    u_0x1035_LATCH : MPI_REG_RC generic map(32, x"35") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol5_r(i),  open, tx0_cq_usage_symbol5_f(i) );
    u_0x1036_LATCH : MPI_REG_RC generic map(32, x"36") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol6_r(i),  open, tx0_cq_usage_symbol6_f(i) );
    u_0x1037_LATCH : MPI_REG_RC generic map(32, x"37") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol7_r(i),  open, tx0_cq_usage_symbol7_f(i) );
    u_0x1038_LATCH : MPI_REG_RC generic map(32, x"38") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol8_r(i),  open, tx0_cq_usage_symbol8_f(i) );
    u_0x1039_LATCH : MPI_REG_RC generic map(32, x"39") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol9_r(i),  open, tx0_cq_usage_symbol9_f(i) );
    u_0x103A_LATCH : MPI_REG_RC generic map(32, x"3A") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol10_r(i), open, tx0_cq_usage_symbol10_f(i) );
    u_0x103B_LATCH : MPI_REG_RC generic map(32, x"3B") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol11_r(i), open, tx0_cq_usage_symbol11_f(i) );
    u_0x103C_LATCH : MPI_REG_RC generic map(32, x"3C") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol12_r(i), open, tx0_cq_usage_symbol12_f(i) );
    u_0x103D_LATCH : MPI_REG_RC generic map(32, x"3D") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol13_r(i), open, tx0_cq_usage_symbol13_f(i) );

    u_0x1070_LATCH : MPI_REG_RC generic map(32, x"70") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol0_r(i),  open, tx1_cq_usage_symbol0_f(i) );
    u_0x1071_LATCH : MPI_REG_RC generic map(32, x"71") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol1_r(i),  open, tx1_cq_usage_symbol1_f(i) );
    u_0x1072_LATCH : MPI_REG_RC generic map(32, x"72") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol2_r(i),  open, tx1_cq_usage_symbol2_f(i) );
    u_0x1073_LATCH : MPI_REG_RC generic map(32, x"73") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol3_r(i),  open, tx1_cq_usage_symbol3_f(i) );
    u_0x1074_LATCH : MPI_REG_RC generic map(32, x"74") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol4_r(i),  open, tx1_cq_usage_symbol4_f(i) );
    u_0x1075_LATCH : MPI_REG_RC generic map(32, x"75") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol5_r(i),  open, tx1_cq_usage_symbol5_f(i) );
    u_0x1076_LATCH : MPI_REG_RC generic map(32, x"76") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol6_r(i),  open, tx1_cq_usage_symbol6_f(i) );
    u_0x1077_LATCH : MPI_REG_RC generic map(32, x"77") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol7_r(i),  open, tx1_cq_usage_symbol7_f(i) );
    u_0x1078_LATCH : MPI_REG_RC generic map(32, x"78") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol8_r(i),  open, tx1_cq_usage_symbol8_f(i) );
    u_0x1079_LATCH : MPI_REG_RC generic map(32, x"79") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol9_r(i),  open, tx1_cq_usage_symbol9_f(i) );
    u_0x107A_LATCH : MPI_REG_RC generic map(32, x"7A") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol10_r(i), open, tx1_cq_usage_symbol10_f(i) );
    u_0x107B_LATCH : MPI_REG_RC generic map(32, x"7B") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol11_r(i), open, tx1_cq_usage_symbol11_f(i) );
    u_0x107C_LATCH : MPI_REG_RC generic map(32, x"7C") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol12_r(i), open, tx1_cq_usage_symbol12_f(i) );
    u_0x107D_LATCH : MPI_REG_RC generic map(32, x"7D") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol13_r(i), open, tx1_cq_usage_symbol13_f(i) );

    u_0x10B0_LATCH : MPI_REG_RC generic map(32, x"B0") port map(RST, CLK, oe(i+16), addr_lsb, tx2_cq_usage_symbol0_r(i),  open, tx2_cq_usage_symbol0_f(i) );
    u_0x10B1_LATCH : MPI_REG_RC generic map(32, x"B1") port map(RST, CLK, oe(i+16), addr_lsb, tx2_cq_usage_symbol1_r(i),  open, tx2_cq_usage_symbol1_f(i) );
    u_0x10B2_LATCH : MPI_REG_RC generic map(32, x"B2") port map(RST, CLK, oe(i+16), addr_lsb, tx2_cq_usage_symbol2_r(i),  open, tx2_cq_usage_symbol2_f(i) );
    u_0x10B3_LATCH : MPI_REG_RC generic map(32, x"B3") port map(RST, CLK, oe(i+16), addr_lsb, tx2_cq_usage_symbol3_r(i),  open, tx2_cq_usage_symbol3_f(i) );
    u_0x10B4_LATCH : MPI_REG_RC generic map(32, x"B4") port map(RST, CLK, oe(i+16), addr_lsb, tx2_cq_usage_symbol4_r(i),  open, tx2_cq_usage_symbol4_f(i) );
    u_0x10B5_LATCH : MPI_REG_RC generic map(32, x"B5") port map(RST, CLK, oe(i+16), addr_lsb, tx2_cq_usage_symbol5_r(i),  open, tx2_cq_usage_symbol5_f(i) );
    u_0x10B6_LATCH : MPI_REG_RC generic map(32, x"B6") port map(RST, CLK, oe(i+16), addr_lsb, tx2_cq_usage_symbol6_r(i),  open, tx2_cq_usage_symbol6_f(i) );
    u_0x10B7_LATCH : MPI_REG_RC generic map(32, x"B7") port map(RST, CLK, oe(i+16), addr_lsb, tx2_cq_usage_symbol7_r(i),  open, tx2_cq_usage_symbol7_f(i) );
    u_0x10B8_LATCH : MPI_REG_RC generic map(32, x"B8") port map(RST, CLK, oe(i+16), addr_lsb, tx2_cq_usage_symbol8_r(i),  open, tx2_cq_usage_symbol8_f(i) );
    u_0x10B9_LATCH : MPI_REG_RC generic map(32, x"B9") port map(RST, CLK, oe(i+16), addr_lsb, tx2_cq_usage_symbol9_r(i),  open, tx2_cq_usage_symbol9_f(i) );
    u_0x10BA_LATCH : MPI_REG_RC generic map(32, x"BA") port map(RST, CLK, oe(i+16), addr_lsb, tx2_cq_usage_symbol10_r(i), open, tx2_cq_usage_symbol10_f(i) );
    u_0x10BB_LATCH : MPI_REG_RC generic map(32, x"BB") port map(RST, CLK, oe(i+16), addr_lsb, tx2_cq_usage_symbol11_r(i), open, tx2_cq_usage_symbol11_f(i) );
    u_0x10BC_LATCH : MPI_REG_RC generic map(32, x"BC") port map(RST, CLK, oe(i+16), addr_lsb, tx2_cq_usage_symbol12_r(i), open, tx2_cq_usage_symbol12_f(i) );
    u_0x10BD_LATCH : MPI_REG_RC generic map(32, x"BD") port map(RST, CLK, oe(i+16), addr_lsb, tx2_cq_usage_symbol13_r(i), open, tx2_cq_usage_symbol13_f(i) );

    u_0x1230_LATCH : MPI_REG_RC generic map(32, x"30") port map(RST, CLK, oe(i+18), addr_lsb, tx3_cq_usage_symbol0_r(i),  open, tx3_cq_usage_symbol0_f(i) );
    u_0x1231_LATCH : MPI_REG_RC generic map(32, x"31") port map(RST, CLK, oe(i+18), addr_lsb, tx3_cq_usage_symbol1_r(i),  open, tx3_cq_usage_symbol1_f(i) );
    u_0x1232_LATCH : MPI_REG_RC generic map(32, x"32") port map(RST, CLK, oe(i+18), addr_lsb, tx3_cq_usage_symbol2_r(i),  open, tx3_cq_usage_symbol2_f(i) );
    u_0x1233_LATCH : MPI_REG_RC generic map(32, x"33") port map(RST, CLK, oe(i+18), addr_lsb, tx3_cq_usage_symbol3_r(i),  open, tx3_cq_usage_symbol3_f(i) );
    u_0x1234_LATCH : MPI_REG_RC generic map(32, x"34") port map(RST, CLK, oe(i+18), addr_lsb, tx3_cq_usage_symbol4_r(i),  open, tx3_cq_usage_symbol4_f(i) );
    u_0x1235_LATCH : MPI_REG_RC generic map(32, x"35") port map(RST, CLK, oe(i+18), addr_lsb, tx3_cq_usage_symbol5_r(i),  open, tx3_cq_usage_symbol5_f(i) );
    u_0x1236_LATCH : MPI_REG_RC generic map(32, x"36") port map(RST, CLK, oe(i+18), addr_lsb, tx3_cq_usage_symbol6_r(i),  open, tx3_cq_usage_symbol6_f(i) );
    u_0x1237_LATCH : MPI_REG_RC generic map(32, x"37") port map(RST, CLK, oe(i+18), addr_lsb, tx3_cq_usage_symbol7_r(i),  open, tx3_cq_usage_symbol7_f(i) );
    u_0x1238_LATCH : MPI_REG_RC generic map(32, x"38") port map(RST, CLK, oe(i+18), addr_lsb, tx3_cq_usage_symbol8_r(i),  open, tx3_cq_usage_symbol8_f(i) );
    u_0x1239_LATCH : MPI_REG_RC generic map(32, x"39") port map(RST, CLK, oe(i+18), addr_lsb, tx3_cq_usage_symbol9_r(i),  open, tx3_cq_usage_symbol9_f(i) );
    u_0x123A_LATCH : MPI_REG_RC generic map(32, x"3A") port map(RST, CLK, oe(i+18), addr_lsb, tx3_cq_usage_symbol10_r(i), open, tx3_cq_usage_symbol10_f(i) );
    u_0x123B_LATCH : MPI_REG_RC generic map(32, x"3B") port map(RST, CLK, oe(i+18), addr_lsb, tx3_cq_usage_symbol11_r(i), open, tx3_cq_usage_symbol11_f(i) );
    u_0x123C_LATCH : MPI_REG_RC generic map(32, x"3C") port map(RST, CLK, oe(i+18), addr_lsb, tx3_cq_usage_symbol12_r(i), open, tx3_cq_usage_symbol12_f(i) );
    u_0x123D_LATCH : MPI_REG_RC generic map(32, x"3D") port map(RST, CLK, oe(i+18), addr_lsb, tx3_cq_usage_symbol13_r(i), open, tx3_cq_usage_symbol13_f(i) );

    u_0x1270_LATCH : MPI_REG_RC generic map(32, x"70") port map(RST, CLK, oe(i+18), addr_lsb, tx4_cq_usage_symbol0_r(i),  open, tx4_cq_usage_symbol0_f(i) );
    u_0x1271_LATCH : MPI_REG_RC generic map(32, x"71") port map(RST, CLK, oe(i+18), addr_lsb, tx4_cq_usage_symbol1_r(i),  open, tx4_cq_usage_symbol1_f(i) );
    u_0x1272_LATCH : MPI_REG_RC generic map(32, x"72") port map(RST, CLK, oe(i+18), addr_lsb, tx4_cq_usage_symbol2_r(i),  open, tx4_cq_usage_symbol2_f(i) );
    u_0x1273_LATCH : MPI_REG_RC generic map(32, x"73") port map(RST, CLK, oe(i+18), addr_lsb, tx4_cq_usage_symbol3_r(i),  open, tx4_cq_usage_symbol3_f(i) );
    u_0x1274_LATCH : MPI_REG_RC generic map(32, x"74") port map(RST, CLK, oe(i+18), addr_lsb, tx4_cq_usage_symbol4_r(i),  open, tx4_cq_usage_symbol4_f(i) );
    u_0x1275_LATCH : MPI_REG_RC generic map(32, x"75") port map(RST, CLK, oe(i+18), addr_lsb, tx4_cq_usage_symbol5_r(i),  open, tx4_cq_usage_symbol5_f(i) );
    u_0x1276_LATCH : MPI_REG_RC generic map(32, x"76") port map(RST, CLK, oe(i+18), addr_lsb, tx4_cq_usage_symbol6_r(i),  open, tx4_cq_usage_symbol6_f(i) );
    u_0x1277_LATCH : MPI_REG_RC generic map(32, x"77") port map(RST, CLK, oe(i+18), addr_lsb, tx4_cq_usage_symbol7_r(i),  open, tx4_cq_usage_symbol7_f(i) );
    u_0x1278_LATCH : MPI_REG_RC generic map(32, x"78") port map(RST, CLK, oe(i+18), addr_lsb, tx4_cq_usage_symbol8_r(i),  open, tx4_cq_usage_symbol8_f(i) );
    u_0x1279_LATCH : MPI_REG_RC generic map(32, x"79") port map(RST, CLK, oe(i+18), addr_lsb, tx4_cq_usage_symbol9_r(i),  open, tx4_cq_usage_symbol9_f(i) );
    u_0x127A_LATCH : MPI_REG_RC generic map(32, x"7A") port map(RST, CLK, oe(i+18), addr_lsb, tx4_cq_usage_symbol10_r(i), open, tx4_cq_usage_symbol10_f(i) );
    u_0x127B_LATCH : MPI_REG_RC generic map(32, x"7B") port map(RST, CLK, oe(i+18), addr_lsb, tx4_cq_usage_symbol11_r(i), open, tx4_cq_usage_symbol11_f(i) );
    u_0x127C_LATCH : MPI_REG_RC generic map(32, x"7C") port map(RST, CLK, oe(i+18), addr_lsb, tx4_cq_usage_symbol12_r(i), open, tx4_cq_usage_symbol12_f(i) );
    u_0x127D_LATCH : MPI_REG_RC generic map(32, x"7D") port map(RST, CLK, oe(i+18), addr_lsb, tx4_cq_usage_symbol13_r(i), open, tx4_cq_usage_symbol13_f(i) );

    u_0x12B0_LATCH : MPI_REG_RC generic map(32, x"B0") port map(RST, CLK, oe(i+18), addr_lsb, tx5_cq_usage_symbol0_r(i),  open, tx5_cq_usage_symbol0_f(i) );
    u_0x12B1_LATCH : MPI_REG_RC generic map(32, x"B1") port map(RST, CLK, oe(i+18), addr_lsb, tx5_cq_usage_symbol1_r(i),  open, tx5_cq_usage_symbol1_f(i) );
    u_0x12B2_LATCH : MPI_REG_RC generic map(32, x"B2") port map(RST, CLK, oe(i+18), addr_lsb, tx5_cq_usage_symbol2_r(i),  open, tx5_cq_usage_symbol2_f(i) );
    u_0x12B3_LATCH : MPI_REG_RC generic map(32, x"B3") port map(RST, CLK, oe(i+18), addr_lsb, tx5_cq_usage_symbol3_r(i),  open, tx5_cq_usage_symbol3_f(i) );
    u_0x12B4_LATCH : MPI_REG_RC generic map(32, x"B4") port map(RST, CLK, oe(i+18), addr_lsb, tx5_cq_usage_symbol4_r(i),  open, tx5_cq_usage_symbol4_f(i) );
    u_0x12B5_LATCH : MPI_REG_RC generic map(32, x"B5") port map(RST, CLK, oe(i+18), addr_lsb, tx5_cq_usage_symbol5_r(i),  open, tx5_cq_usage_symbol5_f(i) );
    u_0x12B6_LATCH : MPI_REG_RC generic map(32, x"B6") port map(RST, CLK, oe(i+18), addr_lsb, tx5_cq_usage_symbol6_r(i),  open, tx5_cq_usage_symbol6_f(i) );
    u_0x12B7_LATCH : MPI_REG_RC generic map(32, x"B7") port map(RST, CLK, oe(i+18), addr_lsb, tx5_cq_usage_symbol7_r(i),  open, tx5_cq_usage_symbol7_f(i) );
    u_0x12B8_LATCH : MPI_REG_RC generic map(32, x"B8") port map(RST, CLK, oe(i+18), addr_lsb, tx5_cq_usage_symbol8_r(i),  open, tx5_cq_usage_symbol8_f(i) );
    u_0x12B9_LATCH : MPI_REG_RC generic map(32, x"B9") port map(RST, CLK, oe(i+18), addr_lsb, tx5_cq_usage_symbol9_r(i),  open, tx5_cq_usage_symbol9_f(i) );
    u_0x12BA_LATCH : MPI_REG_RC generic map(32, x"BA") port map(RST, CLK, oe(i+18), addr_lsb, tx5_cq_usage_symbol10_r(i), open, tx5_cq_usage_symbol10_f(i) );
    u_0x12BB_LATCH : MPI_REG_RC generic map(32, x"BB") port map(RST, CLK, oe(i+18), addr_lsb, tx5_cq_usage_symbol11_r(i), open, tx5_cq_usage_symbol11_f(i) );
    u_0x12BC_LATCH : MPI_REG_RC generic map(32, x"BC") port map(RST, CLK, oe(i+18), addr_lsb, tx5_cq_usage_symbol12_r(i), open, tx5_cq_usage_symbol12_f(i) );
    u_0x12BD_LATCH : MPI_REG_RC generic map(32, x"BD") port map(RST, CLK, oe(i+18), addr_lsb, tx5_cq_usage_symbol13_r(i), open, tx5_cq_usage_symbol13_f(i) );
    end generate;

--------------------------------------------------------------------------------
-- Clear register
--------------------------------------------------------------------------------

--    u_CLEAR_DL_CC : for i in 0 downto 0 generate
    u_0x0065_CLEAR : MPI_CLEAR generic map(x"65") port map(RST, CLK, we_long(0), addr_lsb, CP_DL_CNT_CLEAR(0)(0) );
    u_0x0067_CLEAR : MPI_CLEAR generic map(x"67") port map(RST, CLK, we_long(0), addr_lsb, CP_DL_CNT_CLEAR(0)(1) );
    u_0x0069_CLEAR : MPI_CLEAR generic map(x"69") port map(RST, CLK, we_long(0), addr_lsb, CP_DL_CNT_CLEAR(0)(2) );
    u_0x006B_CLEAR : MPI_CLEAR generic map(x"6B") port map(RST, CLK, we_long(0), addr_lsb, CP_DL_CNT_CLEAR(0)(3) );

    u_0x0075_CLEAR : MPI_CLEAR generic map(x"75") port map(RST, CLK, we_long(0), addr_lsb, UP_DL_CNT_CLEAR(0)(0) );
    u_0x0077_CLEAR : MPI_CLEAR generic map(x"77") port map(RST, CLK, we_long(0), addr_lsb, UP_DL_CNT_CLEAR(0)(1) );
    u_0x0079_CLEAR : MPI_CLEAR generic map(x"79") port map(RST, CLK, we_long(0), addr_lsb, UP_DL_CNT_CLEAR(0)(2) );
    u_0x007B_CLEAR : MPI_CLEAR generic map(x"7B") port map(RST, CLK, we_long(0), addr_lsb, UP_DL_CNT_CLEAR(0)(3) );
--    end generate;

--    u_CLEAR_UL_CC : for i in UL_UNIT-1 downto 0 generate
    u_0x0085_CLEAR : MPI_CLEAR generic map(x"85") port map(RST, CLK, we_long(0), addr_lsb, CP_UL_CNT_CLEAR(0)(0) );
    u_0x0087_CLEAR : MPI_CLEAR generic map(x"87") port map(RST, CLK, we_long(0), addr_lsb, CP_UL_CNT_CLEAR(0)(1) );
    u_0x0089_CLEAR : MPI_CLEAR generic map(x"89") port map(RST, CLK, we_long(0), addr_lsb, CP_UL_CNT_CLEAR(0)(2) );
    u_0x008B_CLEAR : MPI_CLEAR generic map(x"8B") port map(RST, CLK, we_long(0), addr_lsb, CP_UL_CNT_CLEAR(0)(3) );

    u_0x0095_CLEAR : MPI_CLEAR generic map(x"95") port map(RST, CLK, we_long(0), addr_lsb, UP0_UL_CNT_CLEAR(0)(0) );
    u_0x0097_CLEAR : MPI_CLEAR generic map(x"97") port map(RST, CLK, we_long(0), addr_lsb, UP0_UL_CNT_CLEAR(0)(1) );
    u_0x0099_CLEAR : MPI_CLEAR generic map(x"99") port map(RST, CLK, we_long(0), addr_lsb, UP0_UL_CNT_CLEAR(0)(2) );
    u_0x009B_CLEAR : MPI_CLEAR generic map(x"9B") port map(RST, CLK, we_long(0), addr_lsb, UP0_UL_CNT_CLEAR(0)(3) );

    u_0x00A5_CLEAR : MPI_CLEAR generic map(x"A5") port map(RST, CLK, we_long(0), addr_lsb, UP1_UL_CNT_CLEAR(0)(0) );
    u_0x00A7_CLEAR : MPI_CLEAR generic map(x"A7") port map(RST, CLK, we_long(0), addr_lsb, UP1_UL_CNT_CLEAR(0)(1) );
    u_0x00A9_CLEAR : MPI_CLEAR generic map(x"A9") port map(RST, CLK, we_long(0), addr_lsb, UP1_UL_CNT_CLEAR(0)(2) );
    u_0x00AB_CLEAR : MPI_CLEAR generic map(x"AB") port map(RST, CLK, we_long(0), addr_lsb, UP1_UL_CNT_CLEAR(0)(3) );

    u_0x00B5_CLEAR : MPI_CLEAR generic map(x"B5") port map(RST, CLK, we_long(0), addr_lsb, UP2_UL_CNT_CLEAR(0)(0) );
    u_0x00B7_CLEAR : MPI_CLEAR generic map(x"B7") port map(RST, CLK, we_long(0), addr_lsb, UP2_UL_CNT_CLEAR(0)(1) );
    u_0x00B9_CLEAR : MPI_CLEAR generic map(x"B9") port map(RST, CLK, we_long(0), addr_lsb, UP2_UL_CNT_CLEAR(0)(2) );
    u_0x00BB_CLEAR : MPI_CLEAR generic map(x"BB") port map(RST, CLK, we_long(0), addr_lsb, UP2_UL_CNT_CLEAR(0)(3) );

    u_0x00C5_CLEAR : MPI_CLEAR generic map(x"C5") port map(RST, CLK, we_long(0), addr_lsb, UP3_UL_CNT_CLEAR(0)(0) );
    u_0x00C7_CLEAR : MPI_CLEAR generic map(x"C7") port map(RST, CLK, we_long(0), addr_lsb, UP3_UL_CNT_CLEAR(0)(1) );
    u_0x00C9_CLEAR : MPI_CLEAR generic map(x"C9") port map(RST, CLK, we_long(0), addr_lsb, UP3_UL_CNT_CLEAR(0)(2) );
    u_0x00CB_CLEAR : MPI_CLEAR generic map(x"CB") port map(RST, CLK, we_long(0), addr_lsb, UP3_UL_CNT_CLEAR(0)(3) );

    u_0x00D5_CLEAR : MPI_CLEAR generic map(x"D5") port map(RST, CLK, we_long(0), addr_lsb, UP4_UL_CNT_CLEAR(0)(0) );
    u_0x00D7_CLEAR : MPI_CLEAR generic map(x"D7") port map(RST, CLK, we_long(0), addr_lsb, UP4_UL_CNT_CLEAR(0)(1) );
    u_0x00D9_CLEAR : MPI_CLEAR generic map(x"D9") port map(RST, CLK, we_long(0), addr_lsb, UP4_UL_CNT_CLEAR(0)(2) );
    u_0x00DB_CLEAR : MPI_CLEAR generic map(x"DB") port map(RST, CLK, we_long(0), addr_lsb, UP4_UL_CNT_CLEAR(0)(3) );

    u_0x00E5_CLEAR : MPI_CLEAR generic map(x"E5") port map(RST, CLK, we_long(0), addr_lsb, UP5_UL_CNT_CLEAR(0)(0) );
    u_0x00E7_CLEAR : MPI_CLEAR generic map(x"E7") port map(RST, CLK, we_long(0), addr_lsb, UP5_UL_CNT_CLEAR(0)(1) );
    u_0x00E9_CLEAR : MPI_CLEAR generic map(x"E9") port map(RST, CLK, we_long(0), addr_lsb, UP5_UL_CNT_CLEAR(0)(2) );
    u_0x00EB_CLEAR : MPI_CLEAR generic map(x"EB") port map(RST, CLK, we_long(0), addr_lsb, UP5_UL_CNT_CLEAR(0)(3) );
--    end generate;

end BEHAVE;