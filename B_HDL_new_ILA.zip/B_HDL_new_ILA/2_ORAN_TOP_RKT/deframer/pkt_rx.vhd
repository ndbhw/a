--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Packet receiver                                               --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity PKT_RX is
    generic (
        USAGE_C_PLANE               : boolean := true;
        USAGE_U_PLANE               : boolean := true
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        RST                         : in  std_logic;

        CLK_MAC                     : in  std_logic;                            -- 156.25/390.625-MHz
        CLK_BUS                     : in  std_logic;                            -- 245.76-MHz

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        PROG_FULL                   : out std_logic;

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        USAGE_DATA_BUFFER           : out std_logic_vector(31 downto 0);        -- CLK_MAC

        CNT_LOST                    : out std_logic_vector(31 downto 0);        -- CLK_MAC

--------------------------------------------------------------------------------
-- Data bus
--------------------------------------------------------------------------------

        IN_VALID                    : in  std_logic;
        IN_LAST                     : in  std_logic;
        IN_DEST                     : in  std_logic_vector(0 downto 0);
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);
        IN_CH                       : in  std_logic_vector(2 downto 0);
        IN_CH_SUB                   : in  std_logic_vector(3 downto 0);

        OUT_C_READY                 : in  std_logic;
        OUT_C_VALID                 : out std_logic;
        OUT_C_LAST                  : out std_logic;
        OUT_C_KEEP                  : out std_logic_vector(3 downto 0);
        OUT_C_DATA                  : out std_logic_vector(31 downto 0);
        OUT_C_CH                    : out std_logic_vector(2 downto 0);
        OUT_C_CH_SUB                : out std_logic_vector(3 downto 0);

        OUT_U_READY                 : in  std_logic;
        OUT_U_VALID                 : out std_logic;
        OUT_U_LAST                  : out std_logic;
        OUT_U_KEEP                  : out std_logic_vector(3 downto 0);
        OUT_U_DATA                  : out std_logic_vector(31 downto 0);
        OUT_U_CH                    : out std_logic_vector(2 downto 0);
        OUT_U_CH_SUB                : out std_logic_vector(3 downto 0)
    );
end PKT_RX;

architecture BEHAVE of PKT_RX is

    signal sreset_n                 : std_logic;

    component eCPRI_DL_BUFFER is
    port (
        S_AXIS_ARESETN              : in  std_logic;
        S_AXIS_ACLK                 : in  std_logic;
        S_AXIS_TVALID               : in  std_logic;
        S_AXIS_TREADY               : out std_logic;
        S_AXIS_TDATA                : in  std_logic_vector(63 downto 0);
        S_AXIS_TLAST                : in  std_logic;
        S_AXIS_TDEST                : in  std_logic_vector(0 downto 0);
        S_AXIS_TUSER                : in  std_logic_vector(5 downto 0);
        M_AXIS_TVALID               : out std_logic;
        M_AXIS_TREADY               : in  std_logic;
        M_AXIS_TDATA                : out std_logic_vector(63 downto 0);
        M_AXIS_TLAST                : out std_logic;
        M_AXIS_TDEST                : out std_logic_vector(0 downto 0);
        M_AXIS_TUSER                : out std_logic_vector(5 downto 0);
        AXIS_WR_DATA_COUNT          : out std_logic_vector(31 downto 0);
        AXIS_RD_DATA_COUNT          : out std_logic_vector(31 downto 0);
        PROG_FULL                   : out std_logic
    );
    end component;

    component eCPRI_DL_BUFFER_EXT is
    port (
        S_AXIS_ARESETN              : in  std_logic;
        S_AXIS_ACLK                 : in  std_logic;
        S_AXIS_TVALID               : in  std_logic;
        S_AXIS_TREADY               : out std_logic;
        S_AXIS_TLAST                : in  std_logic;
        S_AXIS_TUSER                : in  std_logic_vector(7 downto 0);
        M_AXIS_TVALID               : out std_logic;
        M_AXIS_TREADY               : in  std_logic;
        M_AXIS_TLAST                : out std_logic;
        M_AXIS_TUSER                : out std_logic_vector(7 downto 0);
        AXIS_WR_DATA_COUNT          : out std_logic_vector(31 downto 0);
        AXIS_RD_DATA_COUNT          : out std_logic_vector(31 downto 0)
    );
    end component;

    signal in_ready                 : std_logic;
    signal in_user                  : std_logic_vector(13 downto 0);

    signal data_fifo_valid          : std_logic;
    signal data_fifo_ready          : std_logic;
    signal data_fifo_data           : std_logic_vector(63 downto 0);
    signal data_fifo_last           : std_logic;
    signal data_fifo_dest           : std_logic_vector(0 downto 0);
    signal data_fifo_user           : std_logic_vector(13 downto 0);
    signal data_fifo_wr_usage       : std_logic_vector(31 downto 0);

    component eCPRI_ST_DEMUX_2P_CUSTOM is
    port (
        ACLK                        : in  std_logic;
        ARESETN                     : in  std_logic;
        S_AXIS_TVALID               : in  std_logic_vector(0 downto 0);
        S_AXIS_TREADY               : out std_logic_vector(0 downto 0);
        S_AXIS_TDATA                : in  std_logic_vector(63 downto 0);
        S_AXIS_TLAST                : in  std_logic_vector(0 downto 0);
        S_AXIS_TDEST                : in  std_logic_vector(0 downto 0);
        S_AXIS_TUSER                : in  std_logic_vector(9 downto 0);
        M_AXIS_TVALID               : out std_logic_vector(1 downto 0);
        M_AXIS_TREADY               : in  std_logic_vector(1 downto 0);
        M_AXIS_TDATA                : out std_logic_vector(127 downto 0);
        M_AXIS_TLAST                : out std_logic_vector(1 downto 0);
        M_AXIS_TDEST                : out std_logic_vector(1 downto 0);
        M_AXIS_TUSER                : out std_logic_vector(19 downto 0);
        S_DECODE_ERR                : out std_logic_vector(0 downto 0)
    );
    end component;

    signal defram_c_valid           : std_logic;
    signal defram_c_ready           : std_logic;
    signal defram_c_keep            : std_logic_vector(7 downto 0);
    signal defram_c_data            : std_logic_vector(63 downto 0);
    signal defram_c_last            : std_logic;
    signal defram_c_user            : std_logic_vector(9 downto 0);
    signal defram_u_valid           : std_logic;
    signal defram_u_ready           : std_logic;
    signal defram_u_keep            : std_logic_vector(7 downto 0);
    signal defram_u_data            : std_logic_vector(63 downto 0);
    signal defram_u_last            : std_logic;
    signal defram_u_user            : std_logic_vector(9 downto 0);

    component FROM_64_TO_32 is
    port (
        ARESET                      : in  std_logic;

        IN_CLK                      : in  std_logic;

        IN_READY                    : out std_logic;
        IN_VALID                    : in  std_logic;
        IN_LAST                     : in  std_logic;
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);
        IN_USER                     : in  std_logic_vector(6 downto 0);

        OUT_CLK                     : in  std_logic;

        OUT_READY                   : in  std_logic;
        OUT_VALID                   : out std_logic;
        OUT_LAST                    : out std_logic;
        OUT_KEEP                    : out std_logic_vector(3 downto 0);
        OUT_DATA                    : out std_logic_vector(31 downto 0);
        OUT_USER                    : out std_logic_vector(6 downto 0)
    );
    end component;

    signal out_c_keep_rev           : std_logic_vector(3 downto 0);
    signal out_c_data_rev           : std_logic_vector(31 downto 0);
    signal out_c_user               : std_logic_vector(6 downto 0);
    signal out_u_keep_rev           : std_logic_vector(3 downto 0);
    signal out_u_data_rev           : std_logic_vector(31 downto 0);
    signal out_u_user               : std_logic_vector(6 downto 0);

    component USAGE_TO_GAUGE is
    generic (
        MAX_USAGE                   : natural := 1024
    );
    port (
        CLK                         : in  std_logic;

        USAGE                       : in  std_logic_vector(31 downto 0);
        GAUGE                       : out std_logic_vector(31 downto 0)
    );
    end component;

    signal rx_lost_cnt              : std_logic_vector(15 downto 0) := (others => '0');

begin

    sreset_n <= not RST;

--------------------------------------------------------------------------------
-- Data buffer
--------------------------------------------------------------------------------

    in_user(2 downto 0)   <= "111" when IN_KEEP = x"7F" else
                             "110" when IN_KEEP = x"3F" else
                             "101" when IN_KEEP = x"1F" else
                             "100" when IN_KEEP = x"0F" else
                             "011" when IN_KEEP = x"07" else
                             "010" when IN_KEEP = x"03" else
                             "001" when IN_KEEP = x"01" else
                             "000";
    in_user(5 downto 3)   <= IN_CH;
    in_user(9 downto 6)   <= IN_CH_SUB;
    in_user(13 downto 10) <= (others => '0');

    u_DATA_BUFFER : eCPRI_DL_BUFFER
    port map(
        S_AXIS_ARESETN              => sreset_n                                ,--: in  std_logic;
        S_AXIS_ACLK                 => CLK_MAC                                 ,--: in  std_logic;
        S_AXIS_TVALID               => IN_VALID                                ,--: in  std_logic;
        S_AXIS_TREADY               => in_ready                                ,--: out std_logic;
        S_AXIS_TDATA                => IN_DATA                                 ,--: in  std_logic_vector(63 downto 0);
        S_AXIS_TLAST                => IN_LAST                                 ,--: in  std_logic;
        S_AXIS_TDEST                => IN_DEST                                 ,--: in  std_logic_vector(0 downto 0);
        S_AXIS_TUSER                => in_user(5 downto 0)                     ,--: in  std_logic_vector(5 downto 0);
        M_AXIS_TVALID               => data_fifo_valid                         ,--: out std_logic;
        M_AXIS_TREADY               => data_fifo_ready                         ,--: in  std_logic;
        M_AXIS_TDATA                => data_fifo_data                          ,--: out std_logic_vector(63 downto 0);
        M_AXIS_TLAST                => data_fifo_last                          ,--: out std_logic;
        M_AXIS_TDEST                => data_fifo_dest                          ,--: out std_logic_vector(0 downto 0);
        M_AXIS_TUSER                => data_fifo_user(5 downto 0)              ,--: out std_logic_vector(5 downto 0);
        AXIS_WR_DATA_COUNT          => data_fifo_wr_usage                      ,--: out std_logic_vector(31 downto 0);
        AXIS_RD_DATA_COUNT          => open                                    ,--: out std_logic_vector(31 downto 0);
        PROG_FULL                   => PROG_FULL                                --: out std_logic
    );

    u_DATA_BUFFER_EXT : eCPRI_DL_BUFFER_EXT
    port map(
        S_AXIS_ARESETN              => sreset_n                                ,--: in  std_logic;
        S_AXIS_ACLK                 => CLK_MAC                                 ,--: in  std_logic;
        S_AXIS_TVALID               => IN_VALID                                ,--: in  std_logic;
        S_AXIS_TREADY               => open                                    ,--: out std_logic;
        S_AXIS_TLAST                => IN_LAST                                 ,--: in  std_logic;
        S_AXIS_TUSER                => in_user(13 downto 6)                    ,--: in  std_logic_vector(7 downto 0);
        M_AXIS_TVALID               => open                                    ,--: out std_logic;
        M_AXIS_TREADY               => data_fifo_ready                         ,--: in  std_logic;
        M_AXIS_TLAST                => open                                    ,--: out std_logic;
        M_AXIS_TUSER                => data_fifo_user(13 downto 6)             ,--: out std_logic_vector(7 downto 0);
        AXIS_WR_DATA_COUNT          => open                                    ,--: out std_logic_vector(31 downto 0);
        AXIS_RD_DATA_COUNT          => open                                     --: out std_logic_vector(31 downto 0)
    );

--------------------------------------------------------------------------------
-- C/U-Plane switch
--------------------------------------------------------------------------------

    u_SWITCH : eCPRI_ST_DEMUX_2P_CUSTOM
    port map(
        ACLK                        => CLK_MAC                                 ,--: in  std_logic;
        ARESETN                     => sreset_n                                ,--: in  std_logic;
        S_AXIS_TVALID(0)            => data_fifo_valid                         ,--: in  std_logic_vector(0 downto 0);
        S_AXIS_TREADY(0)            => data_fifo_ready                         ,--: out std_logic_vector(0 downto 0);
        S_AXIS_TDATA                => data_fifo_data                          ,--: in  std_logic_vector(63 downto 0);
        S_AXIS_TLAST(0)             => data_fifo_last                          ,--: in  std_logic_vector(0 downto 0);
        S_AXIS_TDEST                => data_fifo_dest                          ,--: in  std_logic_vector(0 downto 0);
        S_AXIS_TUSER                => data_fifo_user(9 downto 0)              ,--: in  std_logic_vector(9 downto 0);
        M_AXIS_TVALID(0)            => defram_c_valid                          ,--: out std_logic_vector(1 downto 0);
        M_AXIS_TVALID(1)            => defram_u_valid                          ,--: out std_logic_vector(1 downto 0);
        M_AXIS_TREADY(0)            => defram_c_ready                          ,--: in  std_logic_vector(1 downto 0);
        M_AXIS_TREADY(1)            => defram_u_ready                          ,--: in  std_logic_vector(1 downto 0);
        M_AXIS_TDATA(63 downto 0)   => defram_c_data                           ,--: out std_logic_vector(127 downto 0);
        M_AXIS_TDATA(127 downto 64) => defram_u_data                           ,--: out std_logic_vector(127 downto 0);
        M_AXIS_TLAST(0)             => defram_c_last                           ,--: out std_logic_vector(1 downto 0);
        M_AXIS_TLAST(1)             => defram_u_last                           ,--: out std_logic_vector(1 downto 0);
        M_AXIS_TDEST                => open                                    ,--: out std_logic_vector(1 downto 0);
        M_AXIS_TUSER(9 downto 0)    => defram_c_user                           ,--: out std_logic_vector(19 downto 0);
        M_AXIS_TUSER(19 downto 10)  => defram_u_user                           ,--: out std_logic_vector(19 downto 0);
        S_DECODE_ERR                => open                                     --: out std_logic_vector(0 downto 0)
    );

--------------------------------------------------------------------------------
-- C-Plane buffer
--------------------------------------------------------------------------------

    u_C_PLANE_USED : if USAGE_C_PLANE = true generate
    defram_c_keep     <= x"7F" when defram_c_user(2 downto 0) = "111" else
                         x"3F" when defram_c_user(2 downto 0) = "110" else
                         x"1F" when defram_c_user(2 downto 0) = "101" else
                         x"0F" when defram_c_user(2 downto 0) = "100" else
                         x"07" when defram_c_user(2 downto 0) = "011" else
                         x"03" when defram_c_user(2 downto 0) = "010" else
                         x"01" when defram_c_user(2 downto 0) = "001" else
                         x"FF";

    u_C_PLANE_CONV : FROM_64_TO_32
    port map(
        ARESET                      => RST                                     ,--: in  std_logic;

        IN_CLK                      => CLK_MAC                                 ,--: in  std_logic;

        IN_READY                    => defram_c_ready                          ,--: out std_logic;
        IN_VALID                    => defram_c_valid                          ,--: in  std_logic;
        IN_LAST                     => defram_c_last                           ,--: in  std_logic;
        IN_KEEP                     => defram_c_keep                           ,--: in  std_logic_vector(7 downto 0);
        IN_DATA                     => defram_c_data                           ,--: in  std_logic_vector(63 downto 0);
        IN_USER                     => defram_c_user(9 downto 3)               ,--: in  std_logic_vector(6 downto 0);

        OUT_CLK                     => CLK_BUS                                 ,--: in  std_logic;

        OUT_READY                   => OUT_C_READY                             ,--: in  std_logic;
        OUT_VALID                   => OUT_C_VALID                             ,--: out std_logic;
        OUT_LAST                    => OUT_C_LAST                              ,--: out std_logic;
        OUT_KEEP                    => out_c_keep_rev                          ,--: out std_logic_vector(3 downto 0);
        OUT_DATA                    => out_c_data_rev                          ,--: out std_logic_vector(31 downto 0);
        OUT_USER                    => out_c_user                               --: out std_logic_vector(6 downto 0)
    );

    OUT_C_KEEP        <= out_c_keep_rev(0) & out_c_keep_rev(1) & out_c_keep_rev(2) & out_c_keep_rev(3);
    OUT_C_DATA        <= out_c_data_rev(7 downto 0) & out_c_data_rev(15 downto 8) & out_c_data_rev(23 downto 16) & out_c_data_rev(31 downto 24);
    OUT_C_CH          <= out_c_user(2 downto 0);
    OUT_C_CH_SUB      <= out_c_user(6 downto 3);
    end generate;

    u_C_PLANE_UNUSED : if USAGE_C_PLANE = false generate
    defram_c_ready    <= '1';
    OUT_C_VALID       <= '0';
    OUT_C_LAST        <= '0';
    OUT_C_KEEP        <= (others => '0');
    OUT_C_DATA        <= (others => '0');
    OUT_C_CH          <= (others => '0');
    OUT_C_CH_SUB      <= (others => '0');
    end generate;

--------------------------------------------------------------------------------
-- U-Plane buffer
--------------------------------------------------------------------------------

    u_U_PLANE_USED : if USAGE_U_PLANE = true generate
    defram_u_keep     <= x"7F" when defram_u_user(2 downto 0) = "111" else
                         x"3F" when defram_u_user(2 downto 0) = "110" else
                         x"1F" when defram_u_user(2 downto 0) = "101" else
                         x"0F" when defram_u_user(2 downto 0) = "100" else
                         x"07" when defram_u_user(2 downto 0) = "011" else
                         x"03" when defram_u_user(2 downto 0) = "010" else
                         x"01" when defram_u_user(2 downto 0) = "001" else
                         x"FF";

    u_U_PLANE_CONV : FROM_64_TO_32
    port map(
        ARESET                      => RST                                     ,--: in  std_logic;

        IN_CLK                      => CLK_MAC                                 ,--: in  std_logic;

        IN_READY                    => defram_u_ready                          ,--: out std_logic;
        IN_VALID                    => defram_u_valid                          ,--: in  std_logic;
        IN_LAST                     => defram_u_last                           ,--: in  std_logic;
        IN_KEEP                     => defram_u_keep                           ,--: in  std_logic_vector(7 downto 0);
        IN_DATA                     => defram_u_data                           ,--: in  std_logic_vector(63 downto 0);
        IN_USER                     => defram_u_user(9 downto 3)               ,--: in  std_logic_vector(6 downto 0);

        OUT_CLK                     => CLK_BUS                                 ,--: in  std_logic;

        OUT_READY                   => OUT_U_READY                             ,--: in  std_logic;
        OUT_VALID                   => OUT_U_VALID                             ,--: out std_logic;
        OUT_LAST                    => OUT_U_LAST                              ,--: out std_logic;
        OUT_KEEP                    => out_u_keep_rev                          ,--: out std_logic_vector(3 downto 0);
        OUT_DATA                    => out_u_data_rev                          ,--: out std_logic_vector(31 downto 0);
        OUT_USER                    => out_u_user                               --: out std_logic_vector(6 downto 0)
    );

    OUT_U_KEEP        <= out_u_keep_rev(0) & out_u_keep_rev(1) & out_u_keep_rev(2) & out_u_keep_rev(3);
    OUT_U_DATA        <= out_u_data_rev(7 downto 0) & out_u_data_rev(15 downto 8) & out_u_data_rev(23 downto 16) & out_u_data_rev(31 downto 24);
    OUT_U_CH          <= out_u_user(2 downto 0);
    OUT_U_CH_SUB      <= out_u_user(6 downto 3);
    end generate;

    u_U_PLANE_UNUSED : if USAGE_U_PLANE = false generate
    defram_u_ready    <= '1';
    OUT_U_VALID       <= '0';
    OUT_U_LAST        <= '0';
    OUT_U_KEEP        <= (others => '0');
    OUT_U_DATA        <= (others => '0');
    OUT_U_CH          <= (others => '0');
    OUT_U_CH_SUB      <= (others => '0');
    end generate;

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

    u_DATA_BUFFER_STATUS : USAGE_TO_GAUGE generic map(4096) port map(CLK_MAC, data_fifo_wr_usage, USAGE_DATA_BUFFER);

    CNT_LOST <= x"0000" & rx_lost_cnt;

    process (CLK_MAC)
    begin
        if (CLK_MAC'event and CLK_MAC = '1') then
            if (IN_VALID = '1') and (in_ready = '0') then
                rx_lost_cnt <= rx_lost_cnt + 1;
            end if;
        end if;
    end process;

end BEHAVE;