--------------------------------------------------------------------------------
--
-- Copyright (C) 2023, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Author   : jaekyu.no (jaekyu.no@samsung.com)
-- Date     : 2022.02.16
--------------------------------------------------------------------------------
-- Function description
--   1. O-RAN interconnect component
--   2. Stamping according to header information
--------------------------------------------------------------------------------
-- Change log
--   Rev 1 (2022.02.16) - initial release
--   Rev 2 (2023.09.20) - Extract SCS when sectionType 3 message is received
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity ORAN_STAMPING is
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;
        RST                         : in  std_logic;

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        SCS_CONFIG                  : in  std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- Data bus
--------------------------------------------------------------------------------

        IN_VALID                    : in  std_logic;
        IN_LAST                     : in  std_logic;
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);

--------------------------------------------------------------------------------
-- Packet stamp
--------------------------------------------------------------------------------

        PACKET_IS_CP_DL             : out std_logic;
        PACKET_IS_CP_UL             : out std_logic;
        PACKET_IS_UP_DL             : out std_logic;
        PACKET_IS_UP_UL             : out std_logic;
        PACKET_SCS                  : out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             : out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              : out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            : out std_logic_vector(5 downto 0)
    );
end ORAN_STAMPING;

architecture BEHAVE of ORAN_STAMPING is

    signal valid_in_reg             : std_logic := '0';
    signal last_in_reg              : std_logic := '0';
--    signal keep_in_reg              : std_logic_vector(7 downto 0) := (others => '0');
    signal data_in_reg              : std_logic_vector(63 downto 0) := (others => '0');

    type fsm                        is (HDR0, HDR1, HDR2, DUMMY);
    signal fsm_ext                  : fsm;

    signal en                       : std_logic;
    signal c_plane                  : std_logic;
    signal u_plane                  : std_logic;
    signal dl_direction             : std_logic;
    signal ul_direction             : std_logic;
    signal frame_id                 : std_logic_vector(7 downto 0) := (others => '0');
    signal subframe_id              : std_logic_vector(3 downto 0) := (others => '0');
    signal slot_id                  : std_logic_vector(5 downto 0) := (others => '0');
    signal symbol_id                : std_logic_vector(5 downto 0) := (others => '0');
    signal section_type             : std_logic_vector(7 downto 0) := (others => '0');
    signal scs                      : std_logic_vector(3 downto 0) := (others => '0');

begin

--------------------------------------------------------------------------------
-- In/out port registering
--------------------------------------------------------------------------------

--    process (CLK)
--    begin
--        if (CLK'event and CLK = '1') then
            valid_in_reg  <= IN_VALID;
            last_in_reg   <= IN_LAST;
--            keep_in_reg   <= IN_KEEP;
            data_in_reg   <= IN_DATA;
--        end if;
--    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            PACKET_IS_CP_DL <= en and dl_direction and c_plane;
            PACKET_IS_CP_UL <= en and ul_direction and c_plane;
            PACKET_IS_UP_DL <= en and dl_direction and u_plane;
            PACKET_IS_UP_UL <= en and ul_direction and u_plane;
        end if;
    end process;

--    process (CLK)
--    begin
--        if (CLK'event and CLK = '1') then
            PACKET_SCS         <= scs;
            PACKET_FRAME_ID    <= frame_id;
            PACKET_SUBFRAME_ID <= subframe_id;
--            PACKET_SLOT_ID     <= slot_id;
--            PACKET_SYMBOL_ID   <= symbol_id;
            PACKET_SLOT_ID     <= "00" & slot_id(3 downto 0);
            PACKET_SYMBOL_ID   <= "00" & symbol_id(3 downto 0);
--        end if;
--    end process;

--------------------------------------------------------------------------------
-- Extract information
--------------------------------------------------------------------------------

    process (RST, CLK)
    begin
        if (RST = '1') then
            fsm_ext <= HDR0;
        elsif (CLK'event and CLK = '1') then
            case fsm_ext is
            when HDR0   =>
                if (valid_in_reg = '1') then
                    fsm_ext <= HDR1;
                else
                    fsm_ext <= HDR0;
                end if;
            when HDR1   =>
                fsm_ext <= HDR2;
            when HDR2   =>
                fsm_ext <= DUMMY;
            when DUMMY  =>
                if (valid_in_reg = '1') and (last_in_reg = '1') then
                    fsm_ext <= HDR0;
                else
                    fsm_ext <= DUMMY;
                end if;
            when others =>
                fsm_ext <= HDR0;
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_ext is
            when HDR1   =>
                en <= '1';
            when others =>
                en <= '0';
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_ext is
            when HDR0   =>
                if (data_in_reg(15 downto 8) = x"02") then
                    c_plane <= '1';
                else
                    c_plane <= '0';
                end if;
                if (data_in_reg(15 downto 8) = x"00") then
                    u_plane <= '1';
                else
                    u_plane <= '0';
                end if;
            when others =>
                NULL;
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_ext is
            when HDR0   =>
                dl_direction <= '0';
                ul_direction <= '0';
            when HDR1   =>
                dl_direction <= data_in_reg(7);
                ul_direction <= not (data_in_reg(7));
            when others =>
                NULL;
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_ext is
            when HDR1   =>
                frame_id     <= data_in_reg(15 downto 8);
                subframe_id  <= data_in_reg(23 downto 20);
                slot_id      <= data_in_reg(19 downto 16) & data_in_reg(31 downto 30);
                symbol_id    <= data_in_reg(29 downto 24);
                section_type <= data_in_reg(47 downto 40);
            when others =>
                NULL;
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_ext is
            when HDR2   =>
                if (section_type = x"03") then
                    if (data_in_reg(3) = '1') then
                        scs <= (others => '0');
                    else
                        scs <= data_in_reg(3 downto 0);
                    end if;
                else
                    scs <= SCS_CONFIG;
                end if;
            when others =>
                NULL;
            end case;
        end if;
    end process;

end BEHAVE;