--------------------------------------------------------------------------------
--
-- Copyright (C) 2024, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Author   : jaekyu.no (jaekyu.no@samsung.com)
-- Date     : 2024.03.11
--------------------------------------------------------------------------------
-- Function description
--   -. ORAN C-Plane processing (without sectionType 6)
--------------------------------------------------------------------------------
-- Change log
--   Rev 1 (2024.03.11) - initial release
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;

entity FAULT_ID_31 is
    generic (
        USAGE_TYPE0                 : boolean := false;
        USAGE_TYPE1                 : boolean := true;
        USAGE_TYPE3                 : boolean := true;
        USAGE_TYPE5                 : boolean := true;
        USAGE_TYPE6                 : boolean := false;
        USAGE_TYPE7                 : boolean := false
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;                            -- 245.76-MHz
        RST                         : in  std_logic;                            -- CLK

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------



--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        RX_FAULT_ID_31_CH0          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH1          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH2          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH3          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH4          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH5          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH6          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH7          : out std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- C-Plane
--------------------------------------------------------------------------------

        CP32_VALID                  : in  std_logic;
        CP32_LAST                   : in  std_logic;
        CP32_DATA                   : in  std_logic_vector(31 downto 0);
        CP32_DATA_MAP               : in  std_logic_vector(3 downto 0);
        CP32_LINK_INDEX             : in  std_logic_vector(2 downto 0)
    );
end FAULT_ID_31;

architecture BEHAVE of FAULT_ID_31 is

    component RST_SYNC is
    generic (
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port (
        RST_IN                      : in  std_logic;
        CLK                         : in  std_logic;
        RST_OUT                     : out std_logic
    );
    end component;

    signal srst                     : std_logic;

    signal buf_valid                : std_logic := '0';
    signal buf_last                 : std_logic := '0';
    signal buf_data                 : std_logic_vector(31 downto 0) := (others => '0');
    signal buf_data_map             : std_logic_vector(3 downto 0) := (others => '0');
    signal buf_link_index           : std_logic_vector(2 downto 0) := (others => '0');

    type fsm_c_plane                is (HDR0, HDR1, DEC0, DEC1, DEC2, SEC0, SEC1, SEC2, EXT0, EXT1, DUMMY);
    signal fsm_dec                  : fsm_c_plane;
    signal cnt_dec_state            : std_logic_vector(7 downto 0) := (others => '0');
    signal cnt_sec                  : std_logic_vector(7 downto 0) := (others => '0');

    signal field_data_map           : std_logic_vector(3 downto 0) := (others => '0');
    signal field_ant_id             : std_logic_vector(2 downto 0) := (others => '0');
    signal field_data_direction     : std_logic := '0';
--    signal field_filter_index       : std_logic_vector(3 downto 0) := (others => '0');
--    signal field_frame_id           : std_logic_vector(7 downto 0) := (others => '0');
--    signal field_subframe_id        : std_logic_vector(3 downto 0) := (others => '0');
--    signal field_slot_id            : std_logic_vector(5 downto 0) := (others => '0');
--    signal field_symbol_id          : std_logic_vector(5 downto 0) := (others => '0');
    signal field_num_section        : std_logic_vector(7 downto 0) := (others => '0');
    signal field_section_type       : std_logic_vector(7 downto 0) := (others => '0');
--    signal field_ud_comp_hdr        : std_logic_vector(7 downto 0) := (others => '0');
--    signal field_section_id         : std_logic_vector(11 downto 0) := (others => '0');
    signal field_rb                 : std_logic := '0';
--    signal field_syminc             : std_logic := '0';
--    signal field_start_prb          : std_logic_vector(9 downto 0) := (others => '0');
    signal field_num_prb            : std_logic_vector(7 downto 0) := (others => '0');
--    signal field_num_symbol         : std_logic_vector(3 downto 0) := (others => '0');
    signal field_ef                 : std_logic := '0';
--    signal field_beamid             : std_logic_vector(14 downto 0) := (others => '0');
--    signal field_freq_offset        : std_logic_vector(23 downto 0) := (others => '0');
    signal field_ext_ef             : std_logic := '0';
    signal field_ext_len            : std_logic_vector(7 downto 0) := (others => '0');
    signal field_ext_type           : std_logic_vector(6 downto 0) := (others => '0');
--    signal field_num_portc          : std_logic_vector(5 downto 0) := (others => '0');

    signal err_fault_id_31          : std_logic_array4(7 downto 0) := (others => (others => '0'));    
    signal err_fault_id_31_sh       : std_logic_array4(7 downto 0) := (others => (others => '0'));
	
	signal fault_id_31_section_type_incorrect 			: std_logic := '0';
	signal fault_id_31_section_extension_type_incorrect : std_logic := '0';
	signal temp_signal									: std_logic := '0';
begin

    u_RST : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => RST                                     ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;
        RST_OUT                     => srst                                     --: out std_logic
    );

--------------------------------------------------------------------------------
-- FSM for C-Plane decoding
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            buf_valid      <= CP32_VALID;
            buf_last       <= CP32_LAST;
            buf_data       <= CP32_DATA;
            buf_data_map   <= CP32_DATA_MAP;
            buf_link_index <= CP32_LINK_INDEX;
        end if;
    end process;

    -- FSM
    process (srst, CLK)
    begin
        if (srst = '1') then
            fsm_dec <= HDR0;
        elsif (CLK'event and CLK = '1') then
            case fsm_dec is
            when HDR0   =>
                if (buf_valid = '1') then
                    fsm_dec <= HDR1;
                else
                    fsm_dec <= HDR0;
                end if;
            when HDR1   =>
                fsm_dec <= DEC0;
            when DEC0   =>
                fsm_dec <= DEC1;
            when DEC1   =>
                if    (USAGE_TYPE0 = true) and (buf_data(23 downto 16) = 0) then
                    fsm_dec <= DUMMY;
                elsif (USAGE_TYPE1 = true) and (buf_data(23 downto 16) = 1) then
                    fsm_dec <= SEC0;
                elsif (USAGE_TYPE3 = true) and (buf_data(23 downto 16) = 3) then
                    fsm_dec <= DEC2;
                elsif (USAGE_TYPE5 = true) and (buf_data(23 downto 16) = 5) then
                    fsm_dec <= SEC0;
                elsif (USAGE_TYPE6 = true) and (buf_data(23 downto 16) = 6) then
                    fsm_dec <= DUMMY;
                elsif (USAGE_TYPE7 = true) and (buf_data(23 downto 16) = 7) then
                    fsm_dec <= DUMMY;
                else
                    fsm_dec <= DUMMY;
                end if;
            when DEC2   =>
                fsm_dec <= SEC0;
            when SEC0   =>
                fsm_dec <= SEC1;
            when SEC1   =>
                if    (USAGE_TYPE1 = true) and (field_section_type = 1) then
                    if (buf_data(15) = '1') then
                        fsm_dec <= EXT0;
                    else
                        if (cnt_sec = field_num_section) then
                            if (buf_last = '1') then
                                fsm_dec <= HDR0;
                            else
                                fsm_dec <= DUMMY;
                            end if;
                        else
                            fsm_dec <= SEC0;
                        end if;
                    end if;
                elsif (USAGE_TYPE3 = true) and (field_section_type = 3) then
                    fsm_dec <= SEC2;
                elsif (USAGE_TYPE5 = true) and (field_section_type = 5) then
                    if (buf_data(15) = '1') then
                        fsm_dec <= EXT0;
                    else
                        if (cnt_sec = field_num_section) then
                            if (buf_last = '1') then
                                fsm_dec <= HDR0;
                            else
                                fsm_dec <= DUMMY;
                            end if;
                        else
                            fsm_dec <= SEC0;
                        end if;
                    end if;
                else
                    fsm_dec <= DUMMY;
                end if;
            when SEC2   =>
                if (field_ef = '1') then
                    fsm_dec <= EXT0;
                else
                    if (cnt_sec = field_num_section) then
                        if (buf_last = '1') then
                            fsm_dec <= HDR0;
                        else
                            fsm_dec <= DUMMY;
                        end if;
                    else
                        fsm_dec <= SEC0;
                    end if;
                end if;
            when EXT0   =>
                if (buf_data(23 downto 16) = cnt_dec_state) then
                    if (buf_data(31) = '1') then
                        fsm_dec <= EXT0;
                    else
                        if (cnt_sec = field_num_section) then
                            if (buf_last = '1') then
                                fsm_dec <= HDR0;
                            else
                                fsm_dec <= DUMMY;
                            end if;
                        else
                            fsm_dec <= SEC0;
                        end if;
                    end if;
                else
                    fsm_dec <= EXT1;
                end if;
            when EXT1   =>
                if (field_ext_len = cnt_dec_state) then
                    if (field_ext_ef = '1') then
                        fsm_dec <= EXT0;
                    else
                        if (cnt_sec = field_num_section) then
                            if (buf_last = '1') then
                                fsm_dec <= HDR0;
                            else
                                fsm_dec <= DUMMY;
                            end if;
                        else
                            fsm_dec <= SEC0;
                        end if;
                    end if;
                else
                    fsm_dec <= EXT1;
                end if;
            when DUMMY  =>
                if (buf_last = '1') then
                    fsm_dec <= HDR0;
                else
                    fsm_dec <= DUMMY;
                end if;
            when others =>
                fsm_dec <= HDR0;
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when EXT0   =>
                if (buf_data(23 downto 16) = cnt_dec_state) then
                    cnt_dec_state <= "00000001";
                else
                    cnt_dec_state <= cnt_dec_state + 1;
                end if;
            when EXT1   =>
                if (field_ext_len = cnt_dec_state) then
                    cnt_dec_state <= "00000001";
                else
                    cnt_dec_state <= cnt_dec_state + 1;
                end if;
            when others =>
                cnt_dec_state <= "00000001";
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when DEC0   =>
                cnt_sec <= (others => '0');
            when SEC0   =>
                cnt_sec <= cnt_sec + 1;
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- 1st word (eCPRI header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when DEC0   =>
                field_data_map        <= buf_data_map;
                field_ant_id          <= buf_link_index;
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- 1st word (O-RAN header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when DEC0   =>
                field_data_direction  <= buf_data(31);
--                field_filter_index    <= buf_data(27 downto 24);
--                field_frame_id        <= buf_data(23 downto 16);
--                field_subframe_id     <= buf_data(15 downto 12);
--                field_slot_id         <= buf_data(11 downto 6);
--                field_symbol_id       <= buf_data(5 downto 0);
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- 2nd word (O-RAN header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
			when HDR1	=> 
				fault_id_31_section_type_incorrect <= '0';
            when DEC1   =>
                field_num_section     <= buf_data(31 downto 24);
                field_section_type    <= buf_data(23 downto 16);
				
				if (buf_data(23 downto 16) = 0) or (buf_data(23 downto 16) = 1) or (buf_data(23 downto 16) = 3) then
					temp_signal <= '0';
				else
					temp_signal <= '1';
					fault_id_31_section_type_incorrect <= '1';
				end if;
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- 2nd&3rd word (O-RAN header)
--    process (CLK)
--    begin
--        if (CLK'event and CLK = '1') then
--            case fsm_dec is
--            when DEC1   =>
--                field_ud_comp_hdr     <= buf_data(15 downto 8);
--            when DEC2   =>
--                field_ud_comp_hdr     <= buf_data(15 downto 8);
--            when others =>
--                NULL;
--            end case;
--        end if;
--    end process;

    -- 1st word (Section header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when SEC0   =>
--                field_section_id      <= buf_data(31 downto 20);
                field_rb              <= buf_data(19);
--                field_syminc          <= buf_data(18);
--                field_start_prb       <= buf_data(17 downto 8);
                field_num_prb         <= buf_data(7 downto 0);
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- 2nd word (Section header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when SEC1   =>
--                field_num_symbol      <= buf_data(19 downto 16);
                field_ef              <= buf_data(15);
--                field_beamid          <= buf_data(14 downto 0);
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- 3rd word (Section header)
--    process (CLK)
--    begin
--        if (CLK'event and CLK = '1') then
--            case fsm_dec is
--            when SEC0   =>
--                field_freq_offset     <= (others => '0');
--            when SEC2   =>
--                field_freq_offset     <= buf_data(31 downto 8);
--            when others =>
--                NULL;
--            end case;
--        end if;
--    end process;

    -- 1st word (Section extension header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
			when HDR1	=> 
				fault_id_31_section_extension_type_incorrect <= '0';
            when SEC0   =>
                field_ext_ef          <= '0';
                field_ext_len         <= (others => '0');
                
--                field_num_portc       <= (others => '0');
            when EXT0   =>
                field_ext_ef          <= buf_data(31);
                field_ext_type        <= buf_data(30 downto 24);
                field_ext_len         <= buf_data(23 downto 16);
				
				if (fault_id_31_section_type_incorrect = '0') then 
					if (buf_data(30 downto 24) /= 9) then 							
						fault_id_31_section_extension_type_incorrect <= '1';
					end if;
				end if;
				
				
--                if (buf_data(30 downto 24) = 10) then
--                    if (buf_data(13 downto 8) = 0) then
--                        field_num_portc       <= (others => '1');               -- exception (65R -> 64R)
--                    else
--                        field_num_portc       <= buf_data(13 downto 8);
--                    end if;
--                end if;
            when others =>
                NULL;
            end case;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Detect fault-id-31
--------------------------------------------------------------------------------

    -- detection 24B pkg
--  process (CLK)
--  begin
--      if (CLK'event and CLK = '1') then
--          case fsm_dec is
--          when HDR1   =>
--              err_fault_id_31 <= (others => (others => '0'));
--          when SEC1   =>
--              for i in 7 downto 0 loop
--                  for j in 3 downto 0 loop
--                  if (field_ant_id = i) and (field_data_map(j) = '1') then
--                      if (field_rb = '1') and (field_num_prb = 0) then
--                          err_fault_id_31(i)(j) <= '1';
--                        else
--                            err_fault_id_31(i)(j) <= '0';
--                      end if;
--                  end if;
--                  end loop;
--              end loop; 
--          when others =>
--              NULL;
--          end case;
--      end if;
--  end process;

-- detection 26A
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when HDR1   =>
                err_fault_id_31 <= (others => (others => '0'));
            when HDR0   =>
                for i in 7 downto 0 loop
                    for j in 3 downto 0 loop
                    if (field_ant_id = i) and (field_data_map(j) = '1') then
                        if (fault_id_31_section_type_incorrect = '1') or (fault_id_31_section_extension_type_incorrect = '1') then
                            err_fault_id_31(i)(j) <= '1';
--                        else
--                            err_fault_id_31(i)(j) <= '1';
                        end if;
                    end if;
                    end loop;
                end loop; 
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- shift previous result for detecting consecutive
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when HDR1   =>
                err_fault_id_31_sh <= err_fault_id_31;
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- detect alarm and clear it at the end of packet
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when HDR0   =>
                RX_FAULT_ID_31_CH0 <= (others => '0');
                RX_FAULT_ID_31_CH1 <= (others => '0');
                RX_FAULT_ID_31_CH2 <= (others => '0');
                RX_FAULT_ID_31_CH3 <= (others => '0');
                RX_FAULT_ID_31_CH4 <= (others => '0');
                RX_FAULT_ID_31_CH5 <= (others => '0');
                RX_FAULT_ID_31_CH6 <= (others => '0');
                RX_FAULT_ID_31_CH7 <= (others => '0');
            when HDR1   =>
                RX_FAULT_ID_31_CH0 <= (others => '0');
                RX_FAULT_ID_31_CH1 <= (others => '0');
                RX_FAULT_ID_31_CH2 <= (others => '0');
                RX_FAULT_ID_31_CH3 <= (others => '0');
                RX_FAULT_ID_31_CH4 <= (others => '0');
                RX_FAULT_ID_31_CH5 <= (others => '0');
                RX_FAULT_ID_31_CH6 <= (others => '0');
                RX_FAULT_ID_31_CH7 <= (others => '0');
            when others =>
                RX_FAULT_ID_31_CH0 <= err_fault_id_31(0) and err_fault_id_31_sh(0);
                RX_FAULT_ID_31_CH1 <= err_fault_id_31(1) and err_fault_id_31_sh(1);
                RX_FAULT_ID_31_CH2 <= err_fault_id_31(2) and err_fault_id_31_sh(2);
                RX_FAULT_ID_31_CH3 <= err_fault_id_31(3) and err_fault_id_31_sh(3);
                RX_FAULT_ID_31_CH4 <= err_fault_id_31(4) and err_fault_id_31_sh(4);
                RX_FAULT_ID_31_CH5 <= err_fault_id_31(5) and err_fault_id_31_sh(5);
                RX_FAULT_ID_31_CH6 <= err_fault_id_31(6) and err_fault_id_31_sh(6);
                RX_FAULT_ID_31_CH7 <= err_fault_id_31(7) and err_fault_id_31_sh(7);
            end case;
        end if;
    end process;

end BEHAVE;