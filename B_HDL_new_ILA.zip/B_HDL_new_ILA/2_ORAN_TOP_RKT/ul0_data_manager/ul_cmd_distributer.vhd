--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : UL Scheduler (O-RAN component)                                --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity UL_CMD_DISTRIBUTER is
    generic (
        MAX_CH                      : natural := 8;
        LINK_DIRECTION              : std_logic := '0'                          -- '0' : Uplink, '1' : Downlink
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;
        RST                         : in  std_logic;

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------


--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        CNT_FIFO_FULL               : out std_logic_vector(31 downto 0);

--------------------------------------------------------------------------------
-- C-Plane message
--------------------------------------------------------------------------------

        FREQ_OFFSET_FOR_PRACH       : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_eMTC        : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPRACH      : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0     : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1     : in  std_logic_array24(7 downto 0);

--------------------------------------------------------------------------------
-- Command bus
--------------------------------------------------------------------------------

        WRITE_CMD                   : in  std_logic;

        CMD_CHANNEL_ID              : in  std_logic_vector(2 downto 0);
        CMD_CHANNEL_SUB_ID          : in  std_logic_vector(3 downto 0);
        CMD_DATA_DIRECTION          : in  std_logic;
        CMD_FILTER_INDEX            : in  std_logic_vector(3 downto 0);
        CMD_FRAME_ID                : in  std_logic_vector(7 downto 0);
        CMD_SUBFRAME_ID             : in  std_logic_vector(3 downto 0);
        CMD_SLOT_ID                 : in  std_logic_vector(5 downto 0);
        CMD_SYMBOL_ID               : in  std_logic_vector(5 downto 0);
        CMD_SECTION_TYPE            : in  std_logic_vector(7 downto 0);
        CMD_UD_COMP_HDR             : in  std_logic_vector(7 downto 0);
        CMD_SECTION_ID              : in  std_logic_vector(11 downto 0);
        CMD_RB                      : in  std_logic;
        CMD_SYMINC                  : in  std_logic;
        CMD_START_PRB               : in  std_logic_vector(9 downto 0);
        CMD_NUM_PRB                 : in  std_logic_vector(7 downto 0);
        CMD_NUM_SYMBOL              : in  std_logic_vector(3 downto 0);
        CMD_FREQ_OFFSET             : in  std_logic_vector(23 downto 0);
        CMD_NUM_PORTC               : in  std_logic_vector(5 downto 0);

--------------------------------------------------------------------------------
-- Command queue
--------------------------------------------------------------------------------

        CMD_PUxCH_EN                : out std_logic_vector(13 downto 0);
        CMD_PUxCH_IN                : out std_logic_vector(71 downto 0);
        CMD_PUxCH_STOP              : in  std_logic_vector(13 downto 0);

        CMD_PRACH_EN                : out std_logic_vector(MAX_CH-1 downto 0);
        CMD_PRACH_IN                : out std_logic_array72(MAX_CH-1 downto 0);
        CMD_PRACH_STOP              : in  std_logic_vector(MAX_CH-1 downto 0);

        CMD_eMTC_EN                 : out std_logic_vector(MAX_CH-1 downto 0);
        CMD_eMTC_IN                 : out std_logic_array72(MAX_CH-1 downto 0);
        CMD_eMTC_STOP               : in  std_logic_vector(MAX_CH-1 downto 0);

        CMD_NBIOT0_EN               : out std_logic_vector(MAX_CH-1 downto 0);
        CMD_NBIOT0_IN               : out std_logic_array72(MAX_CH-1 downto 0);
        CMD_NBIOT0_STOP             : in  std_logic_vector(MAX_CH-1 downto 0);

        CMD_NBIOT1_EN               : out std_logic_vector(MAX_CH-1 downto 0);
        CMD_NBIOT1_IN               : out std_logic_array72(MAX_CH-1 downto 0);
        CMD_NBIOT1_STOP             : in  std_logic_vector(MAX_CH-1 downto 0);

        CMD_NBIOT2_EN               : out std_logic_vector(MAX_CH-1 downto 0);
        CMD_NBIOT2_IN               : out std_logic_array72(MAX_CH-1 downto 0);
        CMD_NBIOT2_STOP             : in  std_logic_vector(MAX_CH-1 downto 0)
    );
end UL_CMD_DISTRIBUTER;

architecture BEHAVE of UL_CMD_DISTRIBUTER is

    type fsm_c_plane                is (IDLE, LOAD0, LOAD1, LOAD2, PROC);
    signal fsm_write                : fsm_c_plane;
    signal cnt_dec_state            : std_logic_vector(1 downto 0) := (others => '0');

    signal do_write                 : std_logic := '0';
--    signal field_channel_id         : std_logic_vector(2 downto 0);
    signal field_channel_id_half    : std_logic_vector(2 downto 0);
    signal field_filter_index       : std_logic_vector(3 downto 0);
--    signal field_frame_id           : std_logic_vector(7 downto 0);
--    signal field_subframe_id        : std_logic_vector(3 downto 0);
--    signal field_slot_id            : std_logic_vector(5 downto 0);
    signal field_symbol_id          : std_logic_vector(5 downto 0);
    signal field_section_type       : std_logic_vector(7 downto 0);
--    signal field_ud_comp_hdr        : std_logic_vector(7 downto 0);
--    signal field_section_id         : std_logic_vector(11 downto 0);
--    signal field_rb                 : std_logic;
--    signal field_syminc             : std_logic;
--    signal field_start_prb          : std_logic_vector(9 downto 0);
--    signal field_num_prb            : std_logic_vector(7 downto 0);
    signal field_num_symbol         : std_logic_vector(3 downto 0);
    signal field_freq_offset        : std_logic_vector(23 downto 0);
    signal field_num_portc          : std_logic_vector(5 downto 0);
    signal field_channel_sub_id     : std_logic_vector(3 downto 0);

    signal puxch_cmd_en             : std_logic_vector(4 downto 0);
    signal puxch_cmd                : std_logic_vector(71 downto 0);
    signal prach_cmd_en             : std_logic_array15(MAX_CH-1 downto 0);
    signal prach_cmd                : std_logic_array72(MAX_CH-1 downto 0);
    signal emtc_cmd_en              : std_logic_array15(MAX_CH-1 downto 0);
    signal emtc_cmd                 : std_logic_array72(MAX_CH-1 downto 0);
    signal nbiot0_cmd_en            : std_logic_array15(MAX_CH-1 downto 0);
    signal nbiot0_cmd               : std_logic_array72(MAX_CH-1 downto 0);
    signal nbiot1_cmd_en            : std_logic_array15(MAX_CH-1 downto 0);
    signal nbiot1_cmd               : std_logic_array72(MAX_CH-1 downto 0);
    signal nbiot2_cmd_en            : std_logic_array15(MAX_CH-1 downto 0);
    signal nbiot2_cmd               : std_logic_array72(MAX_CH-1 downto 0);

    component PRB_SYMBOL is
    port (
        START_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        NUM_OF_SYMBOL               : in  std_logic_vector(3 downto 0);

        INDEX                       : out std_logic_vector(13 downto 0)
    );
    end component;

    signal index_symbol             : std_logic_vector(13 downto 0);

    component PRB_ANTENNA is
    port (
        CHANNEL_ID                  : in  std_logic_vector(2 downto 0);
        NUM_PORTC                   : in  std_logic_vector(5 downto 0);

        INDEX                       : out std_logic_vector(63 downto 0)
    );
    end component;

    signal index_antenna            : std_logic_vector(63 downto 0);

    component XPM_FIFO_SYNC is
    generic (
        -- Common module generics
        FIFO_MEMORY_TYPE            : string := "auto";                         -- Allowed values: auto, block, distributed. Default value = auto.
        FIFO_WRITE_DEPTH            : integer := 2048;
        WRITE_DATA_WIDTH            : integer := 32;
        READ_MODE                   : string := "std";                          -- Allowed values: std, fwft. Default value = std.
        FIFO_READ_LATENCY           : integer := 1;
        FULL_RESET_VALUE            : integer := 0;
        USE_ADV_FEATURES            : string := "0707";
        READ_DATA_WIDTH             : integer := 32;
        WR_DATA_COUNT_WIDTH         : integer := 1;
        PROG_FULL_THRESH            : integer := 10;
        RD_DATA_COUNT_WIDTH         : integer := 1;
        PROG_EMPTY_THRESH           : integer := 10;
        DOUT_RESET_VALUE            : string := "0";
        ECC_MODE                    : string := "no_ecc";
        SIM_ASSERT_CHK              : integer := 0;
        WAKEUP_TIME                 : integer := 0
    );
    port (
        SLEEP                       : in  std_logic;
        RST                         : in  std_logic;
        WR_CLK                      : in  std_logic;
        WR_EN                       : in  std_logic;
        DIN                         : in  std_logic_vector(WRITE_DATA_WIDTH-1 downto 0);
        FULL                        : out std_logic;
        PROG_FULL                   : out std_logic;
        WR_DATA_COUNT               : out std_logic_vector(WR_DATA_COUNT_WIDTH-1 downto 0);
        OVERFLOW                    : out std_logic;
        WR_RST_BUSY                 : out std_logic;
        ALMOST_FULL                 : out std_logic;
        WR_ACK                      : out std_logic;
        RD_EN                       : in  std_logic;
        DOUT                        : out std_logic_vector(READ_DATA_WIDTH-1 downto 0);
        EMPTY                       : out std_logic;
        PROG_EMPTY                  : out std_logic;
        RD_DATA_COUNT               : out std_logic_vector(RD_DATA_COUNT_WIDTH-1 downto 0);
        UNDERFLOW                   : out std_logic;
        RD_RST_BUSY                 : out std_logic;
        ALMOST_EMPTY                : out std_logic;
        DATA_VALID                  : out std_logic;
        INJECTSBITERR               : in  std_logic;
        INJECTDBITERR               : in  std_logic;
        SBITERR                     : out std_logic;
        DBITERR                     : out std_logic
    );
    end component;

    constant CMD_WIDTH              : natural := 117;

    signal wr_en                    : std_logic;
    signal din                      : std_logic_vector(CMD_WIDTH-1 downto 0);
    signal full                     : std_logic_vector(1 downto 0) := (others => '1');
    signal rd_en                    : std_logic;
    signal dout                     : std_logic_vector(CMD_WIDTH-1 downto 0);
    signal dout_optimized           : std_logic_vector(71 downto 0);
    signal empty                    : std_logic;
    signal cnt_full                 : std_logic_vector(15 downto 0) := (others => '0');

begin

--------------------------------------------------------------------------------
-- Write command
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (WRITE_CMD = '1') and (CMD_DATA_DIRECTION = LINK_DIRECTION) then
                wr_en <= not full(0);
            else
                wr_en <= '0';
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            din(02 downto 00)   <= CMD_CHANNEL_ID;
            din(06 downto 03)   <= CMD_FILTER_INDEX;
            din(14 downto 07)   <= CMD_FRAME_ID;
            din(18 downto 15)   <= CMD_SUBFRAME_ID;
            din(24 downto 19)   <= CMD_SLOT_ID;
            din(30 downto 25)   <= CMD_SYMBOL_ID;
            din(38 downto 31)   <= CMD_SECTION_TYPE;
            din(46 downto 39)   <= CMD_UD_COMP_HDR;
            din(58 downto 47)   <= CMD_SECTION_ID;
            din(59)             <= CMD_RB;
            din(60)             <= CMD_SYMINC;
            din(70 downto 61)   <= CMD_START_PRB;
            din(78 downto 71)   <= CMD_NUM_PRB;
            din(82 downto 79)   <= CMD_NUM_SYMBOL;
            din(106 downto 83)  <= CMD_FREQ_OFFSET;
            din(112 downto 107) <= CMD_NUM_PORTC;
            din(116 downto 113) <= CMD_CHANNEL_SUB_ID;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Command Queue
--------------------------------------------------------------------------------

    u_FIFO : XPM_FIFO_SYNC
    generic map(
        FIFO_MEMORY_TYPE            => "distributed"                           ,--: string := "auto";
        FIFO_WRITE_DEPTH            => 32                                      ,--: integer := 2048;
        WRITE_DATA_WIDTH            => CMD_WIDTH                               ,--: integer := 32;
        READ_MODE                   => "std"                                   ,--: string := "std";
        FIFO_READ_LATENCY           => 3                                       ,--: integer := 1;
        FULL_RESET_VALUE            => 0                                       ,--: integer := 0;
        USE_ADV_FEATURES            => "0705"                                  ,--: string := "0707";
        READ_DATA_WIDTH             => CMD_WIDTH                               ,--: integer := 32;
        WR_DATA_COUNT_WIDTH         => 4                                       ,--: integer := 1;
        PROG_FULL_THRESH            => 10                                      ,--: integer := 10;
        RD_DATA_COUNT_WIDTH         => 4                                       ,--: integer := 1;
        PROG_EMPTY_THRESH           => 10                                      ,--: integer := 10;
        DOUT_RESET_VALUE            => "0"                                     ,--: string := "0";
        ECC_MODE                    => "no_ecc"                                ,--: string := "no_ecc";
        SIM_ASSERT_CHK              => 1                                       ,--: integer := 0;
        WAKEUP_TIME                 => 0                                        --: integer := 0
    )
    port map(
        SLEEP                       => '0'                                     ,--: in  std_logic;
        RST                         => RST                                     ,--: in  std_logic;
        WR_CLK                      => CLK                                     ,--: in  std_logic;
        WR_EN                       => wr_en                                   ,--: in  std_logic;
        DIN                         => din                                     ,--: in  std_logic_vector(WRITE_DATA_WIDTH-1 downto 0);
        FULL                        => full(0)                                 ,--: out std_logic;
        PROG_FULL                   => open                                    ,--: out std_logic;
        WR_DATA_COUNT               => open                                    ,--: out std_logic_vector(WR_DATA_COUNT_WIDTH-1 downto 0);
        OVERFLOW                    => open                                    ,--: out std_logic;
        WR_RST_BUSY                 => open                                    ,--: out std_logic;
        ALMOST_FULL                 => open                                    ,--: out std_logic;
        WR_ACK                      => open                                    ,--: out std_logic;
        RD_EN                       => rd_en                                   ,--: in  std_logic;
        DOUT                        => dout                                    ,--: out std_logic_vector(READ_DATA_WIDTH-1 downto 0);
        EMPTY                       => empty                                   ,--: out std_logic;
        PROG_EMPTY                  => open                                    ,--: out std_logic;
        RD_DATA_COUNT               => open                                    ,--: out std_logic_vector(RD_DATA_COUNT_WIDTH-1 downto 0);
        UNDERFLOW                   => open                                    ,--: out std_logic;
        RD_RST_BUSY                 => open                                    ,--: out std_logic;
        ALMOST_EMPTY                => open                                    ,--: out std_logic;
        DATA_VALID                  => open                                    ,--: out std_logic;
        INJECTSBITERR               => '0'                                     ,--: in  std_logic;
        INJECTDBITERR               => '0'                                     ,--: in  std_logic;
        SBITERR                     => open                                    ,--: out std_logic;
        DBITERR                     => open                                     --: out std_logic
    );

    CNT_FIFO_FULL <= x"0000" & cnt_full;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            full(1) <= full(0);
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (full = "01") then
                cnt_full <= cnt_full + 1;
            end if;
        end if;
    end process;

--------------------------------------------------------------------------------
-- FSM
--------------------------------------------------------------------------------

    process (RST, CLK)
    begin
        if (RST = '1') then
            fsm_write <= IDLE;
        elsif (CLK'event and CLK = '1') then
            case fsm_write is
            when IDLE   =>
                if (empty = '0') then
                    fsm_write <= LOAD0;
                else
                    fsm_write <= IDLE;
                end if;
            when LOAD0  =>
                fsm_write <= LOAD1;
            when LOAD1  =>
                fsm_write <= LOAD2;
            when LOAD2  =>
                fsm_write <= PROC;
            when PROC   =>
                if (cnt_dec_state = 3) then
                    fsm_write <= IDLE;
                else
                    fsm_write <= PROC;
                end if;
            when others =>
                fsm_write <= IDLE;
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_write is
            when PROC   =>
                cnt_dec_state <= cnt_dec_state + 1;
            when others =>
                cnt_dec_state <= (others => '0');
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_write is
            when IDLE   =>
                if (empty = '0') then
                    rd_en <= '1';
                else
                    rd_en <= '0';
                end if;
            when others =>
                rd_en <= '0';
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_write is
            when LOAD2  =>
                do_write <= '1';
            when others =>
                do_write <= '0';
            end case;
        end if;
    end process;

--------------------------------------------------------------------------------
-- DOUT mapping
--------------------------------------------------------------------------------

--    field_channel_id      <= dout(02 downto 00);
    field_channel_id_half <= '0' & dout(01 downto 00);
    field_filter_index    <= dout(06 downto 03);
--    field_frame_id        <= dout(14 downto 07);
--    field_subframe_id     <= dout(18 downto 15);
--    field_slot_id         <= dout(24 downto 19);
    field_symbol_id       <= dout(30 downto 25);
    field_section_type    <= dout(38 downto 31);
--    field_ud_comp_hdr     <= dout(46 downto 39);
--    field_section_id      <= dout(58 downto 47);
--    field_rb              <= dout(59);
--    field_syminc          <= dout(60);
--    field_start_prb       <= dout(70 downto 61);
--    field_num_prb         <= dout(78 downto 71);
    field_num_symbol      <= dout(82 downto 79);
    field_freq_offset     <= dout(106 downto 83);
    field_num_portc       <= dout(112 downto 107);
    field_channel_sub_id  <= dout(116 downto 113);

--------------------------------------------------------------------------------
-- Optimization of queue width (Limited up to 72bits for BRAM implementation)
--------------------------------------------------------------------------------

    dout_optimized(02 downto 00) <= dout(02 downto 00);                         -- field_channel_id
    dout_optimized(06 downto 03) <= dout(06 downto 03);                         -- field_filter_index
    dout_optimized(14 downto 07) <= dout(14 downto 07);                         -- field_frame_id
    dout_optimized(18 downto 15) <= dout(18 downto 15);                         -- field_subframe_id
    dout_optimized(24 downto 19) <= dout(24 downto 19);                         -- field_slot_id
    dout_optimized(30 downto 25) <= dout(30 downto 25);                         -- field_symbol_id
--    dout_optimized(38 downto 31) <= dout(38 downto 31);                         -- field_section_type
    dout_optimized(38 downto 31) <= dout(46 downto 39);                         -- field_ud_comp_hdr
    dout_optimized(50 downto 39) <= dout(58 downto 47);                         -- field_section_id
    dout_optimized(51)           <= dout(59);                                   -- field_rb
--    dout_optimized(60)           <= dout(60);                                   -- field_syminc
    dout_optimized(61 downto 52) <= dout(70 downto 61);                         -- field_start_prb
    dout_optimized(69 downto 62) <= dout(78 downto 71);                         -- field_num_prb
    dout_optimized(71 downto 70) <= (others => '0');

--------------------------------------------------------------------------------
-- Write
--------------------------------------------------------------------------------

    u_SYMBOL : PRB_SYMBOL
    port map(
        START_SYMBOL_ID             => field_symbol_id                         ,--: in  std_logic_vector(5 downto 0);
        NUM_OF_SYMBOL               => field_num_symbol                        ,--: in  std_logic_vector(3 downto 0);

        INDEX                       => index_symbol                             --: out std_logic_vector(13 downto 0)
    );

    u_ANTENNA : PRB_ANTENNA
    port map(
        CHANNEL_ID                  => field_channel_id_half                   ,--: in  std_logic_vector(2 downto 0);
        NUM_PORTC                   => field_num_portc                         ,--: in  std_logic_vector(5 downto 0);

        INDEX                       => index_antenna                            --: out std_logic_vector(63 downto 0)
    );

    -- Command write - PUxCH
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
--            if (do_write = '1') and (field_section_id(11) = '0') then
            if (do_write = '1') and (field_channel_sub_id(2) = '1') and (field_section_type = 1) then
                if (field_freq_offset = 0) then
                    if    (field_num_portc = 1) then                            puxch_cmd_en <= "01100";
                    elsif (field_num_portc = 2) then                            puxch_cmd_en <= "01110";
                    elsif (field_num_portc = 3) then                            puxch_cmd_en <= "01111";
                    else                                                        puxch_cmd_en <= "01000";
                    end if;
                else
                    puxch_cmd_en <= puxch_cmd_en(3 downto 0) & '0';
                end if;
            else
                puxch_cmd_en <= puxch_cmd_en(3 downto 0) & '0';
            end if;
        end if;
    end process;

    CMD_PUxCH_IN <= puxch_cmd;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (do_write = '1') then
                puxch_cmd <= dout_optimized;
            else
                if (puxch_cmd_en(4) = '1') then
                    puxch_cmd(2 downto 0) <= puxch_cmd(2 downto 0) + 1;
                end if;
            end if;
        end if;
    end process;

    -- Command write - LTE PRACH
    u_PRACH : for i in MAX_CH-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
--            if (do_write = '1') and (field_filter_index /= 0) and (field_section_id(11 downto 10) = "10") then
            if (do_write = '1') and (field_channel_sub_id(3) = '1') and (field_section_type = 3) and (field_filter_index /= 0) then
                if    (index_antenna(i) = '1') and (field_freq_offset = FREQ_OFFSET_FOR_PRACH(i)) then
                    if    (field_num_symbol = 1) then                           prach_cmd_en(i) <= "010000000000000";
                    elsif (field_num_symbol = 2) then                           prach_cmd_en(i) <= "011000000000000";
                    elsif (field_num_symbol = 3) then                           prach_cmd_en(i) <= "011100000000000";
                    elsif (field_num_symbol = 4) then                           prach_cmd_en(i) <= "011110000000000";
                    elsif (field_num_symbol = 5) then                           prach_cmd_en(i) <= "011111000000000";
                    elsif (field_num_symbol = 6) then                           prach_cmd_en(i) <= "011111100000000";
                    elsif (field_num_symbol = 7) then                           prach_cmd_en(i) <= "011111110000000";
                    elsif (field_num_symbol = 8) then                           prach_cmd_en(i) <= "011111111000000";
                    elsif (field_num_symbol = 9) then                           prach_cmd_en(i) <= "011111111100000";
                    elsif (field_num_symbol = 10) then                          prach_cmd_en(i) <= "011111111110000";
                    elsif (field_num_symbol = 11) then                          prach_cmd_en(i) <= "011111111111000";
                    elsif (field_num_symbol = 12) then                          prach_cmd_en(i) <= "011111111111100";
                    elsif (field_num_symbol = 13) then                          prach_cmd_en(i) <= "011111111111110";
                    elsif (field_num_symbol = 14) then                          prach_cmd_en(i) <= "011111111111111";
                    else                                                        prach_cmd_en(i) <= "000000000000000";
                    end if;
                else
                    prach_cmd_en(i) <= prach_cmd_en(i)(13 downto 0) & '0';
                end if;
            else
                prach_cmd_en(i) <= prach_cmd_en(i)(13 downto 0) & '0';
            end if;
        end if;
    end process;

    CMD_PRACH_IN(i) <= prach_cmd(i);

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (do_write = '1') then
                prach_cmd(i)(1 downto 0)  <= conv_std_logic_vector(i, 2);
                prach_cmd(i)(2)           <= dout(2);
                prach_cmd(i)(71 downto 3) <= dout_optimized(71 downto 3);
            else
                if (prach_cmd_en(i)(14) = '1') then
                    prach_cmd(i)(30 downto 25) <= prach_cmd(i)(30 downto 25) + 1;
                end if;
            end if;
        end if;
    end process;
    end generate;

    -- Command write - eMTC PRACH
    u_eMTC : for i in MAX_CH-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
--            if (do_write = '1') and (field_filter_index /= 0) and (field_section_id(11 downto 7) = "11000") then
            if (do_write = '1') and (field_channel_sub_id(3) = '1') and (field_section_type = 3) and (field_filter_index /= 0) then
                if    (index_antenna(i) = '1') and (field_freq_offset = FREQ_OFFSET_FOR_eMTC(i)) then
                    if    (field_num_symbol = 1) then                           emtc_cmd_en(i) <= "010000000000000";
                    elsif (field_num_symbol = 2) then                           emtc_cmd_en(i) <= "011000000000000";
                    elsif (field_num_symbol = 3) then                           emtc_cmd_en(i) <= "011100000000000";
                    elsif (field_num_symbol = 4) then                           emtc_cmd_en(i) <= "011110000000000";
                    elsif (field_num_symbol = 5) then                           emtc_cmd_en(i) <= "011111000000000";
                    elsif (field_num_symbol = 6) then                           emtc_cmd_en(i) <= "011111100000000";
                    elsif (field_num_symbol = 7) then                           emtc_cmd_en(i) <= "011111110000000";
                    elsif (field_num_symbol = 8) then                           emtc_cmd_en(i) <= "011111111000000";
                    elsif (field_num_symbol = 9) then                           emtc_cmd_en(i) <= "011111111100000";
                    elsif (field_num_symbol = 10) then                          emtc_cmd_en(i) <= "011111111110000";
                    elsif (field_num_symbol = 11) then                          emtc_cmd_en(i) <= "011111111111000";
                    elsif (field_num_symbol = 12) then                          emtc_cmd_en(i) <= "011111111111100";
                    elsif (field_num_symbol = 13) then                          emtc_cmd_en(i) <= "011111111111110";
                    elsif (field_num_symbol = 14) then                          emtc_cmd_en(i) <= "011111111111111";
                    else                                                        emtc_cmd_en(i) <= "000000000000000";
                    end if;
                else
                    emtc_cmd_en(i) <= emtc_cmd_en(i)(13 downto 0) & '0';
                end if;
            else
                emtc_cmd_en(i) <= emtc_cmd_en(i)(13 downto 0) & '0';
            end if;
        end if;
    end process;

    CMD_eMTC_IN(i) <= emtc_cmd(i);

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (do_write = '1') then
                emtc_cmd(i)(1 downto 0)  <= conv_std_logic_vector(i, 2);
                emtc_cmd(i)(2)           <= dout(2);
                emtc_cmd(i)(71 downto 3) <= dout_optimized(71 downto 3);
            else
                if (emtc_cmd_en(i)(14) = '1') then
                    emtc_cmd(i)(30 downto 25) <= emtc_cmd(i)(30 downto 25) + 1;
                end if;
            end if;
        end if;
    end process;
    end generate;

    -- Command write - NPUSCH
    u_NBIOT0 : for i in MAX_CH-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
--            if (do_write = '1') and (field_filter_index /= 0) and (field_section_id(11 downto 7) = "11101") then
            if (do_write = '1') and (field_channel_sub_id(1) = '1') and (field_section_type = 3) then
                if    (index_antenna(i) = '1') and (field_freq_offset = FREQ_OFFSET_FOR_NPUSCH0(i)) then
                    if    (field_num_symbol = 1) then                           nbiot0_cmd_en(i) <= "010000000000000";
                    elsif (field_num_symbol = 2) then                           nbiot0_cmd_en(i) <= "011000000000000";
                    elsif (field_num_symbol = 3) then                           nbiot0_cmd_en(i) <= "011100000000000";
                    elsif (field_num_symbol = 4) then                           nbiot0_cmd_en(i) <= "011110000000000";
                    elsif (field_num_symbol = 5) then                           nbiot0_cmd_en(i) <= "011111000000000";
                    elsif (field_num_symbol = 6) then                           nbiot0_cmd_en(i) <= "011111100000000";
                    elsif (field_num_symbol = 7) then                           nbiot0_cmd_en(i) <= "011111110000000";
                    elsif (field_num_symbol = 8) then                           nbiot0_cmd_en(i) <= "011111111000000";
                    elsif (field_num_symbol = 9) then                           nbiot0_cmd_en(i) <= "011111111100000";
                    elsif (field_num_symbol = 10) then                          nbiot0_cmd_en(i) <= "011111111110000";
                    elsif (field_num_symbol = 11) then                          nbiot0_cmd_en(i) <= "011111111111000";
                    elsif (field_num_symbol = 12) then                          nbiot0_cmd_en(i) <= "011111111111100";
                    elsif (field_num_symbol = 13) then                          nbiot0_cmd_en(i) <= "011111111111110";
                    elsif (field_num_symbol = 14) then                          nbiot0_cmd_en(i) <= "011111111111111";
                    else                                                        nbiot0_cmd_en(i) <= "000000000000000";
                    end if;
                else
                    nbiot0_cmd_en(i) <= nbiot0_cmd_en(i)(13 downto 0) & '0';
                end if;
            else
                nbiot0_cmd_en(i) <= nbiot0_cmd_en(i)(13 downto 0) & '0';
            end if;
        end if;
    end process;

    CMD_NBIOT0_IN(i) <= nbiot0_cmd(i);

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (do_write = '1') then
                nbiot0_cmd(i)(1 downto 0)  <= conv_std_logic_vector(i, 2);
                nbiot0_cmd(i)(2)           <= dout(2);
                nbiot0_cmd(i)(71 downto 3) <= dout_optimized(71 downto 3);
            else
                if (nbiot0_cmd_en(i)(14) = '1') then
                    nbiot0_cmd(i)(30 downto 25) <= nbiot0_cmd(i)(30 downto 25) + 1;
                end if;
            end if;
        end if;
    end process;
    end generate;

    -- Command write - NPUSCH
    u_NBIOT1 : for i in MAX_CH-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
--            if (do_write = '1') and (field_filter_index /= 0) and ((field_section_id(11 downto 7) = "11001") or (field_section_id(11 downto 7) = "11010") or (field_section_id(11 downto 7) = "11011")) then
            if (do_write = '1') and (field_channel_sub_id(1) = '1') and (field_section_type = 3) then
                if    (index_antenna(i) = '1') and (field_freq_offset = FREQ_OFFSET_FOR_NPUSCH1(i)) then
                    if    (field_num_symbol = 1) then                           nbiot1_cmd_en(i) <= "010000000000000";
                    elsif (field_num_symbol = 2) then                           nbiot1_cmd_en(i) <= "011000000000000";
                    elsif (field_num_symbol = 3) then                           nbiot1_cmd_en(i) <= "011100000000000";
                    elsif (field_num_symbol = 4) then                           nbiot1_cmd_en(i) <= "011110000000000";
                    elsif (field_num_symbol = 5) then                           nbiot1_cmd_en(i) <= "011111000000000";
                    elsif (field_num_symbol = 6) then                           nbiot1_cmd_en(i) <= "011111100000000";
                    elsif (field_num_symbol = 7) then                           nbiot1_cmd_en(i) <= "011111110000000";
                    elsif (field_num_symbol = 8) then                           nbiot1_cmd_en(i) <= "011111111000000";
                    elsif (field_num_symbol = 9) then                           nbiot1_cmd_en(i) <= "011111111100000";
                    elsif (field_num_symbol = 10) then                          nbiot1_cmd_en(i) <= "011111111110000";
                    elsif (field_num_symbol = 11) then                          nbiot1_cmd_en(i) <= "011111111111000";
                    elsif (field_num_symbol = 12) then                          nbiot1_cmd_en(i) <= "011111111111100";
                    elsif (field_num_symbol = 13) then                          nbiot1_cmd_en(i) <= "011111111111110";
                    elsif (field_num_symbol = 14) then                          nbiot1_cmd_en(i) <= "011111111111111";
                    else                                                        nbiot1_cmd_en(i) <= "000000000000000";
                    end if;
                else
                    nbiot1_cmd_en(i) <= nbiot1_cmd_en(i)(13 downto 0) & '0';
                end if;
            else
                nbiot1_cmd_en(i) <= nbiot1_cmd_en(i)(13 downto 0) & '0';
            end if;
        end if;
    end process;

    CMD_NBIOT1_IN(i) <= nbiot1_cmd(i);

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (do_write = '1') then
                nbiot1_cmd(i)(1 downto 0)  <= conv_std_logic_vector(i, 2);
                nbiot1_cmd(i)(2)           <= dout(2);
                nbiot1_cmd(i)(71 downto 3) <= dout_optimized(71 downto 3);
            else
                if (nbiot1_cmd_en(i)(14) = '1') then
                    nbiot1_cmd(i)(30 downto 25) <= nbiot1_cmd(i)(30 downto 25) + 1;
                end if;
            end if;
        end if;
    end process;
    end generate;

    -- Command write - NPRACH
    u_NBIOT2 : for i in MAX_CH-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
--            if (do_write = '1') and (field_filter_index /= 0) and (field_section_id(11 downto 7) = "11100") then
            if (do_write = '1') and (field_channel_sub_id(3) = '1') and (field_section_type = 3) and (field_filter_index = 4) then
                if    (index_antenna(i) = '1') and (field_freq_offset = FREQ_OFFSET_FOR_NPRACH(i)) then
                    if    (field_num_symbol = 1) then                           nbiot2_cmd_en(i) <= "010000000000000";
                    elsif (field_num_symbol = 2) then                           nbiot2_cmd_en(i) <= "011000000000000";
                    elsif (field_num_symbol = 3) then                           nbiot2_cmd_en(i) <= "011100000000000";
                    elsif (field_num_symbol = 4) then                           nbiot2_cmd_en(i) <= "011110000000000";
                    elsif (field_num_symbol = 5) then                           nbiot2_cmd_en(i) <= "011111000000000";
                    elsif (field_num_symbol = 6) then                           nbiot2_cmd_en(i) <= "011111100000000";
                    elsif (field_num_symbol = 7) then                           nbiot2_cmd_en(i) <= "011111110000000";
                    elsif (field_num_symbol = 8) then                           nbiot2_cmd_en(i) <= "011111111000000";
                    elsif (field_num_symbol = 9) then                           nbiot2_cmd_en(i) <= "011111111100000";
                    elsif (field_num_symbol = 10) then                          nbiot2_cmd_en(i) <= "011111111110000";
                    elsif (field_num_symbol = 11) then                          nbiot2_cmd_en(i) <= "011111111111000";
                    elsif (field_num_symbol = 12) then                          nbiot2_cmd_en(i) <= "011111111111100";
                    elsif (field_num_symbol = 13) then                          nbiot2_cmd_en(i) <= "011111111111110";
                    elsif (field_num_symbol = 14) then                          nbiot2_cmd_en(i) <= "011111111111111";
                    else                                                        nbiot2_cmd_en(i) <= "000000000000000";
                    end if;
                else
                    nbiot2_cmd_en(i) <= nbiot2_cmd_en(i)(13 downto 0) & '0';
                end if;
            else
                nbiot2_cmd_en(i) <= nbiot2_cmd_en(i)(13 downto 0) & '0';
            end if;
        end if;
    end process;

    CMD_NBIOT2_IN(i) <= nbiot2_cmd(i);

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (do_write = '1') then
                nbiot2_cmd(i)(1 downto 0)  <= conv_std_logic_vector(i, 2);
                nbiot2_cmd(i)(2)           <= dout(2);
                nbiot2_cmd(i)(71 downto 3) <= dout_optimized(71 downto 3);
            else
                if (nbiot2_cmd_en(i)(14) = '1') then
                    nbiot2_cmd(i)(30 downto 25) <= nbiot2_cmd(i)(30 downto 25) + 1;
                end if;
            end if;
        end if;
    end process;
    end generate;

    u_EN_SYMBOL : for i in 13 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            CMD_PUxCH_EN(i) <= puxch_cmd_en(3) and index_symbol(i) and (not CMD_PUxCH_STOP(i));
        end if;
    end process;
    end generate;

    u_EN_ANTENNA : for i in MAX_CH-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            CMD_PRACH_EN(i)  <= prach_cmd_en(i)(13) and (not CMD_PRACH_STOP(i));
            CMD_eMTC_EN(i)   <= emtc_cmd_en(i)(13) and (not CMD_eMTC_STOP(i));
            CMD_NBIOT0_EN(i) <= nbiot0_cmd_en(i)(13) and (not CMD_NBIOT0_STOP(i));
            CMD_NBIOT1_EN(i) <= nbiot1_cmd_en(i)(13) and (not CMD_NBIOT1_STOP(i));
            CMD_NBIOT2_EN(i) <= nbiot2_cmd_en(i)(13) and (not CMD_NBIOT2_STOP(i));
        end if;
    end process;
    end generate;

end BEHAVE;