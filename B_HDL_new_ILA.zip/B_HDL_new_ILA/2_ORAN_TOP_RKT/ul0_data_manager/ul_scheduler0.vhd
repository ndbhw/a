--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : UL Scheduler (O-RAN component)                                --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;

entity UL_SCHEDULER0 is
    generic (
        LINK_DIRECTION              : std_logic := '0';                         -- '0' : Uplink, '1' : Downlink
        MAX_SECTION_PUxCH           : natural := 256;
        MAX_SECTION_PRACH           : natural := 16;
        MAX_SECTION_eMTC            : natural := 8;
        MAX_SECTION_NBIOT0          : natural := 8;
        MAX_SECTION_NBIOT1          : natural := 8;
        MAX_SECTION_NBIOT2          : natural := 8;
        USAGE_TYPE0                 : boolean := false;
        USAGE_TYPE1                 : boolean := true;
        USAGE_TYPE3                 : boolean := true;
        USAGE_TYPE5                 : boolean := false;
        USAGE_TYPE6                 : boolean := false;
        USAGE_TYPE7                 : boolean := false
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;
        RST                         : in  std_logic;

--------------------------------------------------------------------------------
-- Debug
--------------------------------------------------------------------------------

        IGNORE_FRAME_ID             : in  std_logic;
        IGNORE_FRAME_ID_PUxCH_RX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT2_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT2_TX   : out std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        PUxCH_ID                    : in  std_logic_array16(7 downto 0);
        PRACH_ID                    : in  std_logic_array16(7 downto 0);
        NPUSCH_ID                   : in  std_logic_array16(7 downto 0);

        COMP_MODE                   : in  std_logic;
        IQ_WIDTH                    : in  std_logic_vector(3 downto 0);
        COMP_METHOD                 : in  std_logic_vector(3 downto 0);
        PRB_PER_SYMBOL              : in  std_logic_vector(9 downto 0);
        PRB_PER_MTU                 : in  std_logic_vector(9 downto 0);

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        CNT_FIFO_FULL               : out std_logic_vector(31 downto 0);

        CNT_PUxCH_TERMINATION       : out std_logic_vector(31 downto 0);

        CNT_PUxCH_CPSEC_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL13    : out std_logic_vector(31 downto 0);

        CNT_PUxCH_CQ_FULL_SYMBOL0   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL1   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL2   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL3   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL4   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL5   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL6   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL7   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL8   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL9   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL10  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL11  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL12  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL13  : out std_logic_vector(31 downto 0);

        USAGE_PUxCH_CQ_SYMBOL0      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL1      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL2      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL3      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL4      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL5      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL6      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL7      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL8      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL9      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL10     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL11     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL12     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL13     : out std_logic_vector(31 downto 0);

        CNT_PRACH_TERMINATION       : out std_logic_vector(31 downto 0);

        CNT_PRACH_CPSEC_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL13    : out std_logic_vector(31 downto 0);

        CNT_PRACH_CQ_FULL_SYMBOL0   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL1   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL2   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL3   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL4   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL5   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL6   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL7   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL8   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL9   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL10  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL11  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL12  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL13  : out std_logic_vector(31 downto 0);

        USAGE_PRACH_CQ_SYMBOL0      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL1      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL2      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL3      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL4      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL5      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL6      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL7      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL8      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL9      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL10     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL11     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL12     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL13     : out std_logic_vector(31 downto 0);

        CNT_eMTC_TERMINATION        : out std_logic_vector(31 downto 0);

        CNT_eMTC_CPSEC_SYMBOL0      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL1      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL2      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL3      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL4      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL5      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL6      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL7      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL8      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL9      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL10     : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL11     : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL12     : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL13     : out std_logic_vector(31 downto 0);

        CNT_eMTC_CQ_FULL_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL13   : out std_logic_vector(31 downto 0);

        USAGE_eMTC_CQ_SYMBOL0       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL1       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL2       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL3       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL4       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL5       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL6       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL7       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL8       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL9       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL10      : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL11      : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL12      : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL13      : out std_logic_vector(31 downto 0);

        CNT_NBIOT0_TERMINATION      : out std_logic_vector(31 downto 0);

        CNT_NBIOT0_CPSEC_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL13   : out std_logic_vector(31 downto 0);

        CNT_NBIOT0_CQ_FULL_SYMBOL0  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL1  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL2  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL3  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL4  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL5  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL6  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL7  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL8  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL9  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL10 : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL11 : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL12 : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL13 : out std_logic_vector(31 downto 0);

        USAGE_NBIOT0_CQ_SYMBOL0     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL1     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL2     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL3     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL4     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL5     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL6     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL7     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL8     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL9     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL10    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL11    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL12    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL13    : out std_logic_vector(31 downto 0);

        CNT_NBIOT1_TERMINATION      : out std_logic_vector(31 downto 0);

        CNT_NBIOT1_CPSEC_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL13   : out std_logic_vector(31 downto 0);

        CNT_NBIOT1_CQ_FULL_SYMBOL0  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL1  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL2  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL3  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL4  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL5  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL6  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL7  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL8  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL9  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL10 : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL11 : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL12 : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL13 : out std_logic_vector(31 downto 0);

        USAGE_NBIOT1_CQ_SYMBOL0     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL1     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL2     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL3     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL4     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL5     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL6     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL7     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL8     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL9     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL10    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL11    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL12    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL13    : out std_logic_vector(31 downto 0);

        CNT_NBIOT2_TERMINATION      : out std_logic_vector(31 downto 0);

        CNT_NBIOT2_CPSEC_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL13   : out std_logic_vector(31 downto 0);

        CNT_NBIOT2_CQ_FULL_SYMBOL0  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL1  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL2  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL3  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL4  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL5  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL6  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL7  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL8  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL9  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL10 : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL11 : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL12 : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL13 : out std_logic_vector(31 downto 0);

        USAGE_NBIOT2_CQ_SYMBOL0     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL1     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL2     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL3     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL4     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL5     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL6     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL7     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL8     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL9     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL10    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL11    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL12    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL13    : out std_logic_vector(31 downto 0);

--------------------------------------------------------------------------------
-- C-Plane message
--------------------------------------------------------------------------------

        C_PLANE_VALID               : in  std_logic;
        C_PLANE_LAST                : in  std_logic;
        C_PLANE_KEEP                : in  std_logic_vector(3 downto 0);
        C_PLANE_DATA                : in  std_logic_vector(31 downto 0);
        C_PLANE_CH                  : in  std_logic_vector(2 downto 0);
        C_PLANE_CH_SUB              : in  std_logic_vector(3 downto 0);

        FREQ_OFFSET_FOR_PRACH       : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_eMTC        : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPRACH      : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0     : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1     : in  std_logic_array24(7 downto 0);

--------------------------------------------------------------------------------
-- LTE PUxCH
--------------------------------------------------------------------------------

        ULFE_UPDATE                 : in  std_logic;

        ULFE_FRAME_ID               : in  std_logic_vector(7 downto 0);
        ULFE_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        ULFE_SLOT_ID                : in  std_logic_vector(5 downto 0);
        ULFE_SYMBOL_ID              : in  std_logic_vector(5 downto 0);

        PUxCH_INIT                  : out std_logic;
        PUxCH_PACKING_TICK          : out std_logic_vector(3 downto 0);

        PUxCH_RTCPC_ID              : out std_logic_vector(15 downto 0);

        PUxCH_DATA_DIRECTION        : out std_logic;
        PUxCH_PAYLOAD_VERSION       : out std_logic_vector(2 downto 0);
        PUxCH_FILTER_INDEX          : out std_logic_vector(3 downto 0);
        PUxCH_FRAME_ID              : out std_logic_vector(7 downto 0);
        PUxCH_SUBFRAME_ID           : out std_logic_vector(3 downto 0);
        PUxCH_SLOT_ID               : out std_logic_vector(5 downto 0);
        PUxCH_SYMBOL_ID             : out std_logic_vector(5 downto 0);

        PUxCH_SECTION_TICK          : out std_logic_vector(3 downto 0);
        PUxCH_SECTION_LAST          : out std_logic_vector(3 downto 0);
        PUxCH_SECTION_DONE          : in  std_logic_vector(3 downto 0);

        PUxCH_SECTION_ID            : out std_logic_vector(11 downto 0);
        PUxCH_USE_EVERY_PRB         : out std_logic;
        PUxCH_START_OF_PRB          : out std_logic_vector(9 downto 0);
        PUxCH_OFFSET_OF_PRB         : out std_logic_vector(9 downto 0);
        PUxCH_NUMBER_OF_PRB         : out std_logic_vector(9 downto 0);
        PUxCH_UD_COMP_HDR           : out std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- LTE PRACH
--------------------------------------------------------------------------------

        RAFE0_UPDATE                : in  std_logic;

        RAFE0_FRAME_ID              : in  std_logic_vector(7 downto 0);
        RAFE0_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        RAFE0_SLOT_ID               : in  std_logic_vector(5 downto 0);
        RAFE0_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        RAFE0_CHANNEL_ID            : in  std_logic_vector(2 downto 0);

        PRACH_INIT                  : out std_logic;
        PRACH_PACKING_TICK          : out std_logic_vector(3 downto 0);

        PRACH_RTCPC_ID              : out std_logic_vector(15 downto 0);

        PRACH_DATA_DIRECTION        : out std_logic;
        PRACH_PAYLOAD_VERSION       : out std_logic_vector(2 downto 0);
        PRACH_FILTER_INDEX          : out std_logic_vector(3 downto 0);
        PRACH_FRAME_ID              : out std_logic_vector(7 downto 0);
        PRACH_SUBFRAME_ID           : out std_logic_vector(3 downto 0);
        PRACH_SLOT_ID               : out std_logic_vector(5 downto 0);
        PRACH_SYMBOL_ID             : out std_logic_vector(5 downto 0);

        PRACH_SECTION_TICK          : out std_logic_vector(3 downto 0);
        PRACH_SECTION_LAST          : out std_logic_vector(3 downto 0);
        PRACH_SECTION_DONE          : in  std_logic_vector(3 downto 0);

        PRACH_SECTION_ID            : out std_logic_vector(11 downto 0);
        PRACH_USE_EVERY_PRB         : out std_logic;
        PRACH_START_OF_PRB          : out std_logic_vector(9 downto 0);
        PRACH_OFFSET_OF_PRB         : out std_logic_vector(9 downto 0);
        PRACH_NUMBER_OF_PRB         : out std_logic_vector(9 downto 0);
        PRACH_UD_COMP_HDR           : out std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- eMTC
--------------------------------------------------------------------------------

        RAFE1_UPDATE                : in  std_logic;

        RAFE1_FRAME_ID              : in  std_logic_vector(7 downto 0);
        RAFE1_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        RAFE1_SLOT_ID               : in  std_logic_vector(5 downto 0);
        RAFE1_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        RAFE1_CHANNEL_ID            : in  std_logic_vector(2 downto 0);

        eMTC_INIT                   : out std_logic;
        eMTC_PACKING_TICK           : out std_logic_vector(3 downto 0);

        eMTC_RTCPC_ID               : out std_logic_vector(15 downto 0);

        eMTC_DATA_DIRECTION         : out std_logic;
        eMTC_PAYLOAD_VERSION        : out std_logic_vector(2 downto 0);
        eMTC_FILTER_INDEX           : out std_logic_vector(3 downto 0);
        eMTC_FRAME_ID               : out std_logic_vector(7 downto 0);
        eMTC_SUBFRAME_ID            : out std_logic_vector(3 downto 0);
        eMTC_SLOT_ID                : out std_logic_vector(5 downto 0);
        eMTC_SYMBOL_ID              : out std_logic_vector(5 downto 0);

        eMTC_SECTION_TICK           : out std_logic_vector(3 downto 0);
        eMTC_SECTION_LAST           : out std_logic_vector(3 downto 0);
        eMTC_SECTION_DONE           : in  std_logic_vector(3 downto 0);

        eMTC_SECTION_ID             : out std_logic_vector(11 downto 0);
        eMTC_USE_EVERY_PRB          : out std_logic;
        eMTC_START_OF_PRB           : out std_logic_vector(9 downto 0);
        eMTC_OFFSET_OF_PRB          : out std_logic_vector(9 downto 0);
        eMTC_NUMBER_OF_PRB          : out std_logic_vector(9 downto 0);
        eMTC_UD_COMP_HDR            : out std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- NB-IoT PUSCH anchor
--------------------------------------------------------------------------------

        NBFE0_UPDATE                : in  std_logic;

        NBFE0_FRAME_ID              : in  std_logic_vector(7 downto 0);
        NBFE0_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        NBFE0_SLOT_ID               : in  std_logic_vector(5 downto 0);
        NBFE0_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        NBFE0_CHANNEL_ID            : in  std_logic_vector(2 downto 0);

        NBIOT0_INIT                 : out std_logic;
        NBIOT0_PACKING_TICK         : out std_logic_vector(3 downto 0);

        NBIOT0_RTCPC_ID             : out std_logic_vector(15 downto 0);

        NBIOT0_DATA_DIRECTION       : out std_logic;
        NBIOT0_PAYLOAD_VERSION      : out std_logic_vector(2 downto 0);
        NBIOT0_FILTER_INDEX         : out std_logic_vector(3 downto 0);
        NBIOT0_FRAME_ID             : out std_logic_vector(7 downto 0);
        NBIOT0_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        NBIOT0_SLOT_ID              : out std_logic_vector(5 downto 0);
        NBIOT0_SYMBOL_ID            : out std_logic_vector(5 downto 0);

        NBIOT0_SECTION_TICK         : out std_logic_vector(3 downto 0);
        NBIOT0_SECTION_LAST         : out std_logic_vector(3 downto 0);
        NBIOT0_SECTION_DONE         : in  std_logic_vector(3 downto 0);

        NBIOT0_SECTION_ID           : out std_logic_vector(11 downto 0);
        NBIOT0_USE_EVERY_PRB        : out std_logic;
        NBIOT0_START_OF_PRB         : out std_logic_vector(9 downto 0);
        NBIOT0_OFFSET_OF_PRB        : out std_logic_vector(9 downto 0);
        NBIOT0_NUMBER_OF_PRB        : out std_logic_vector(9 downto 0);
        NBIOT0_UD_COMP_HDR          : out std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- NB-IoT PUSCH non-anchor
--------------------------------------------------------------------------------

        NBFE1_UPDATE                : in  std_logic;

        NBFE1_FRAME_ID              : in  std_logic_vector(7 downto 0);
        NBFE1_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        NBFE1_SLOT_ID               : in  std_logic_vector(5 downto 0);
        NBFE1_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        NBFE1_CHANNEL_ID            : in  std_logic_vector(2 downto 0);

        NBIOT1_INIT                 : out std_logic;
        NBIOT1_PACKING_TICK         : out std_logic_vector(3 downto 0);

        NBIOT1_RTCPC_ID             : out std_logic_vector(15 downto 0);

        NBIOT1_DATA_DIRECTION       : out std_logic;
        NBIOT1_PAYLOAD_VERSION      : out std_logic_vector(2 downto 0);
        NBIOT1_FILTER_INDEX         : out std_logic_vector(3 downto 0);
        NBIOT1_FRAME_ID             : out std_logic_vector(7 downto 0);
        NBIOT1_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        NBIOT1_SLOT_ID              : out std_logic_vector(5 downto 0);
        NBIOT1_SYMBOL_ID            : out std_logic_vector(5 downto 0);

        NBIOT1_SECTION_TICK         : out std_logic_vector(3 downto 0);
        NBIOT1_SECTION_LAST         : out std_logic_vector(3 downto 0);
        NBIOT1_SECTION_DONE         : in  std_logic_vector(3 downto 0);

        NBIOT1_SECTION_ID           : out std_logic_vector(11 downto 0);
        NBIOT1_USE_EVERY_PRB        : out std_logic;
        NBIOT1_START_OF_PRB         : out std_logic_vector(9 downto 0);
        NBIOT1_OFFSET_OF_PRB        : out std_logic_vector(9 downto 0);
        NBIOT1_NUMBER_OF_PRB        : out std_logic_vector(9 downto 0);
        NBIOT1_UD_COMP_HDR          : out std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- NB-IoT PRACH
--------------------------------------------------------------------------------

        NBFE2_UPDATE                : in  std_logic;

        NBFE2_FRAME_ID              : in  std_logic_vector(7 downto 0);
        NBFE2_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        NBFE2_SLOT_ID               : in  std_logic_vector(5 downto 0);
        NBFE2_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        NBFE2_CHANNEL_ID            : in  std_logic_vector(2 downto 0);

        NBIOT2_INIT                 : out std_logic;
        NBIOT2_PACKING_TICK         : out std_logic_vector(3 downto 0);

        NBIOT2_RTCPC_ID             : out std_logic_vector(15 downto 0);

        NBIOT2_DATA_DIRECTION       : out std_logic;
        NBIOT2_PAYLOAD_VERSION      : out std_logic_vector(2 downto 0);
        NBIOT2_FILTER_INDEX         : out std_logic_vector(3 downto 0);
        NBIOT2_FRAME_ID             : out std_logic_vector(7 downto 0);
        NBIOT2_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        NBIOT2_SLOT_ID              : out std_logic_vector(5 downto 0);
        NBIOT2_SYMBOL_ID            : out std_logic_vector(5 downto 0);

        NBIOT2_SECTION_TICK         : out std_logic_vector(3 downto 0);
        NBIOT2_SECTION_LAST         : out std_logic_vector(3 downto 0);
        NBIOT2_SECTION_DONE         : in  std_logic_vector(3 downto 0);

        NBIOT2_SECTION_ID           : out std_logic_vector(11 downto 0);
        NBIOT2_USE_EVERY_PRB        : out std_logic;
        NBIOT2_START_OF_PRB         : out std_logic_vector(9 downto 0);
        NBIOT2_OFFSET_OF_PRB        : out std_logic_vector(9 downto 0);
        NBIOT2_NUMBER_OF_PRB        : out std_logic_vector(9 downto 0);
        NBIOT2_UD_COMP_HDR          : out std_logic_vector(7 downto 0)
    );
end UL_SCHEDULER0;

architecture BEHAVE of UL_SCHEDULER0 is

    signal buf_valid                : std_logic := '0';
    signal buf_last                 : std_logic := '0';
--    signal buf_keep                 : std_logic_vector(3 downto 0);
    signal buf_data                 : std_logic_vector(31 downto 0) := (others => '0');
    signal buf_ch                   : std_logic_vector(2 downto 0) := (others => '0');
    signal buf_ch_sub               : std_logic_vector(3 downto 0) := (others => '0');

    type fsm_c_plane                is (HDR0, HDR1, DEC0, DEC1, DEC2, SEC0, SEC1, SEC2, EXT0, EXT1, DUMMY);
    signal fsm_dec                  : fsm_c_plane;
    signal cnt_dec_state            : std_logic_vector(7 downto 0) := (others => '0');
    signal cnt_sec                  : std_logic_vector(7 downto 0) := (others => '0');

    signal field_channel_id         : std_logic_vector(2 downto 0) := (others => '0');
    signal field_channel_sub_id     : std_logic_vector(3 downto 0) := (others => '0');
--    signal field_rtcpc_id           : std_logic_vector(15 downto 0) := (others => '0');
    signal field_data_direction     : std_logic := '0';
    signal field_filter_index       : std_logic_vector(3 downto 0) := (others => '0');
    signal field_frame_id           : std_logic_vector(7 downto 0) := (others => '0');
    signal field_subframe_id        : std_logic_vector(3 downto 0) := (others => '0');
    signal field_slot_id            : std_logic_vector(5 downto 0) := (others => '0');
    signal field_symbol_id          : std_logic_vector(5 downto 0) := (others => '0');
    signal field_num_section        : std_logic_vector(7 downto 0) := (others => '0');
    signal field_section_type       : std_logic_vector(7 downto 0) := (others => '0');
    signal field_ud_comp_hdr        : std_logic_vector(7 downto 0) := (others => '0');
    signal field_section_id         : std_logic_vector(11 downto 0) := (others => '0');
    signal field_rb                 : std_logic := '0';
    signal field_syminc             : std_logic := '0';
    signal field_start_prb          : std_logic_vector(9 downto 0) := (others => '0');
    signal field_num_prb            : std_logic_vector(7 downto 0) := (others => '0');
    signal field_num_symbol         : std_logic_vector(3 downto 0) := (others => '0');
    signal field_ef                 : std_logic := '0';
--    signal field_beamid             : std_logic_vector(14 downto 0) := (others => '0');
    signal field_freq_offset        : std_logic_vector(23 downto 0) := (others => '0');
    signal field_ext_ef             : std_logic := '0';
    signal field_ext_len            : std_logic_vector(7 downto 0) := (others => '0');
    signal field_num_portc          : std_logic_vector(5 downto 0) := (others => '0');

    signal write_cmd                : std_logic;

    component UL_CMD_DISTRIBUTER is
    generic (
        MAX_CH                      : natural := 8;
        LINK_DIRECTION              : std_logic := '0'
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        CNT_FIFO_FULL               : out std_logic_vector(31 downto 0);

        FREQ_OFFSET_FOR_PRACH       : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_eMTC        : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPRACH      : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0     : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1     : in  std_logic_array24(7 downto 0);

        WRITE_CMD                   : in  std_logic;

        CMD_CHANNEL_ID              : in  std_logic_vector(2 downto 0);
        CMD_CHANNEL_SUB_ID          : in  std_logic_vector(3 downto 0);
        CMD_DATA_DIRECTION          : in  std_logic;
        CMD_FILTER_INDEX            : in  std_logic_vector(3 downto 0);
        CMD_FRAME_ID                : in  std_logic_vector(7 downto 0);
        CMD_SUBFRAME_ID             : in  std_logic_vector(3 downto 0);
        CMD_SLOT_ID                 : in  std_logic_vector(5 downto 0);
        CMD_SYMBOL_ID               : in  std_logic_vector(5 downto 0);
        CMD_SECTION_TYPE            : in  std_logic_vector(7 downto 0);
        CMD_UD_COMP_HDR             : in  std_logic_vector(7 downto 0);
        CMD_SECTION_ID              : in  std_logic_vector(11 downto 0);
        CMD_RB                      : in  std_logic;
        CMD_SYMINC                  : in  std_logic;
        CMD_START_PRB               : in  std_logic_vector(9 downto 0);
        CMD_NUM_PRB                 : in  std_logic_vector(7 downto 0);
        CMD_NUM_SYMBOL              : in  std_logic_vector(3 downto 0);
        CMD_FREQ_OFFSET             : in  std_logic_vector(23 downto 0);
        CMD_NUM_PORTC               : in  std_logic_vector(5 downto 0);

        CMD_PUxCH_EN                : out std_logic_vector(13 downto 0);
        CMD_PUxCH_IN                : out std_logic_vector(71 downto 0);
        CMD_PUxCH_STOP              : in  std_logic_vector(13 downto 0);

        CMD_PRACH_EN                : out std_logic_vector(MAX_CH-1 downto 0);
        CMD_PRACH_IN                : out std_logic_array72(MAX_CH-1 downto 0);
        CMD_PRACH_STOP              : in  std_logic_vector(MAX_CH-1 downto 0);

        CMD_eMTC_EN                 : out std_logic_vector(MAX_CH-1 downto 0);
        CMD_eMTC_IN                 : out std_logic_array72(MAX_CH-1 downto 0);
        CMD_eMTC_STOP               : in  std_logic_vector(MAX_CH-1 downto 0);

        CMD_NBIOT0_EN               : out std_logic_vector(MAX_CH-1 downto 0);
        CMD_NBIOT0_IN               : out std_logic_array72(MAX_CH-1 downto 0);
        CMD_NBIOT0_STOP             : in  std_logic_vector(MAX_CH-1 downto 0);

        CMD_NBIOT1_EN               : out std_logic_vector(MAX_CH-1 downto 0);
        CMD_NBIOT1_IN               : out std_logic_array72(MAX_CH-1 downto 0);
        CMD_NBIOT1_STOP             : in  std_logic_vector(MAX_CH-1 downto 0);

        CMD_NBIOT2_EN               : out std_logic_vector(MAX_CH-1 downto 0);
        CMD_NBIOT2_IN               : out std_logic_array72(MAX_CH-1 downto 0);
        CMD_NBIOT2_STOP             : in  std_logic_vector(MAX_CH-1 downto 0)
    );
    end component;

    component UL_CMD_QUEUE is
    generic (
        LINK_DIRECTION              : std_logic := '0';
        CMD_QUEUE_MEMORY_TYPE       : string := "auto";
        CMD_QUEUE_DEPTH             : integer := 2048
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        IGNORE_FRAME_ID             : in  std_logic;
        IGNORE_FRAME_ID_RX          : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_TX          : out std_logic_vector(7 downto 0);

        ID                          : in  std_logic_array16(7 downto 0);

        PRB_PER_SYMBOL              : in  std_logic_vector(9 downto 0);
        PRB_PER_MTU                 : in  std_logic_vector(9 downto 0);

        CNT_ABNORMAL_TERMINATION    : out std_logic_vector(31 downto 0);

        CNT_SECTION_SYMBOL0         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL1         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL2         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL3         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL4         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL5         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL6         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL7         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL8         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL9         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL10        : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL11        : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL12        : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL13        : out std_logic_vector(31 downto 0);

        CNT_CQ_FULL_SYMBOL0         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL1         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL2         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL3         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL4         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL5         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL6         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL7         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL8         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL9         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL10        : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL11        : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL12        : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL13        : out std_logic_vector(31 downto 0);

        USAGE_CQ_SYMBOL0            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL1            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL2            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL3            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL4            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL5            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL6            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL7            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL8            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL9            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL10           : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL11           : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL12           : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL13           : out std_logic_vector(31 downto 0);

        INFO_UPDATE                 : in  std_logic;

        INFO_FRAME_ID               : in  std_logic_vector(7 downto 0);
        INFO_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        INFO_SLOT_ID                : in  std_logic_vector(5 downto 0);
        INFO_SYMBOL_ID              : in  std_logic_vector(5 downto 0);

        CMD_EN                      : in  std_logic_vector(13 downto 0);
        CMD_IN                      : in  std_logic_vector(71 downto 0);
        CMD_STOP                    : out std_logic_vector(13 downto 0);

        INIT_SESSION                : out std_logic;

        PACKING_TICK                : out std_logic_vector(3 downto 0);

        RTCPC_ID                    : out std_logic_vector(15 downto 0);

        DATA_DIRECTION              : out std_logic;
        PAYLOAD_VERSION             : out std_logic_vector(2 downto 0);
        FILTER_INDEX                : out std_logic_vector(3 downto 0);
        FRAME_ID                    : out std_logic_vector(7 downto 0);
        SUBFRAME_ID                 : out std_logic_vector(3 downto 0);
        SLOT_ID                     : out std_logic_vector(5 downto 0);
        SYMBOL_ID                   : out std_logic_vector(5 downto 0);

        SECTION_TICK                : out std_logic_vector(3 downto 0);
        SECTION_LAST                : out std_logic_vector(3 downto 0);
        SECTION_DONE                : in  std_logic_vector(3 downto 0);

        SECTION_ID                  : out std_logic_vector(11 downto 0);
        USE_EVERY_PRB               : out std_logic;
        START_OF_PRB                : out std_logic_vector(9 downto 0);
        OFFSET_OF_PRB               : out std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               : out std_logic_vector(9 downto 0);
        UD_COMP_HDR                 : out std_logic_vector(7 downto 0)
    );
    end component;

    component UL_CMD_QUEUE_RACH is
    generic (
        LINK_DIRECTION              : std_logic := '0';
        CMD_QUEUE_MEMORY_TYPE       : string := "auto";
        CMD_QUEUE_DEPTH             : integer := 2048
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        IGNORE_FRAME_ID             : in  std_logic;
        IGNORE_FRAME_ID_RX          : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_TX          : out std_logic_vector(7 downto 0);

        ID                          : in  std_logic_array16(7 downto 0);

        PRB_PER_SYMBOL              : in  std_logic_vector(9 downto 0);
        PRB_PER_MTU                 : in  std_logic_vector(9 downto 0);

        CNT_ABNORMAL_TERMINATION    : out std_logic_vector(31 downto 0);

        CNT_SECTION_SYMBOL0         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL1         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL2         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL3         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL4         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL5         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL6         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL7         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL8         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL9         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL10        : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL11        : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL12        : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL13        : out std_logic_vector(31 downto 0);

        CNT_CQ_FULL_SYMBOL0         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL1         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL2         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL3         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL4         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL5         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL6         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL7         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL8         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL9         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL10        : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL11        : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL12        : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL13        : out std_logic_vector(31 downto 0);

        USAGE_CQ_SYMBOL0            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL1            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL2            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL3            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL4            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL5            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL6            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL7            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL8            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL9            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL10           : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL11           : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL12           : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL13           : out std_logic_vector(31 downto 0);

        INFO_UPDATE                 : in  std_logic;

        INFO_FRAME_ID               : in  std_logic_vector(7 downto 0);
        INFO_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        INFO_SLOT_ID                : in  std_logic_vector(5 downto 0);
        INFO_SYMBOL_ID              : in  std_logic_vector(5 downto 0);
        INFO_CHANNEL_ID             : in  std_logic_vector(2 downto 0);

        CMD_EN                      : in  std_logic_vector(3 downto 0);
        CMD_IN                      : in  std_logic_array72(3 downto 0);
        CMD_STOP                    : out std_logic_vector(3 downto 0);

        INIT_SESSION                : out std_logic;

        PACKING_TICK                : out std_logic_vector(3 downto 0);

        RTCPC_ID                    : out std_logic_vector(15 downto 0);

        DATA_DIRECTION              : out std_logic;
        PAYLOAD_VERSION             : out std_logic_vector(2 downto 0);
        FILTER_INDEX                : out std_logic_vector(3 downto 0);
        FRAME_ID                    : out std_logic_vector(7 downto 0);
        SUBFRAME_ID                 : out std_logic_vector(3 downto 0);
        SLOT_ID                     : out std_logic_vector(5 downto 0);
        SYMBOL_ID                   : out std_logic_vector(5 downto 0);

        SECTION_TICK                : out std_logic_vector(3 downto 0);
        SECTION_LAST                : out std_logic_vector(3 downto 0);
        SECTION_DONE                : in  std_logic_vector(3 downto 0);

        SECTION_ID                  : out std_logic_vector(11 downto 0);
        USE_EVERY_PRB               : out std_logic;
        START_OF_PRB                : out std_logic_vector(9 downto 0);
        OFFSET_OF_PRB               : out std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               : out std_logic_vector(9 downto 0);
        UD_COMP_HDR                 : out std_logic_vector(7 downto 0)
    );
    end component;

    signal puxch_cmd_en_ext         : std_logic_vector(13 downto 0);
    signal puxch_cmd_ext            : std_logic_vector(71 downto 0);
    signal puxch_cmd_stop           : std_logic_vector(13 downto 0);
    signal prach_cmd_en_ext         : std_logic_vector(3 downto 0);
    signal prach_cmd_ext            : std_logic_array72(3 downto 0);
    signal prach_cmd_stop           : std_logic_vector(3 downto 0);
    signal emtc_cmd_en_ext          : std_logic_vector(3 downto 0);
    signal emtc_cmd_ext             : std_logic_array72(3 downto 0);
    signal emtc_cmd_stop            : std_logic_vector(3 downto 0);
    signal nbiot0_cmd_en_ext        : std_logic_vector(3 downto 0);
    signal nbiot0_cmd_ext           : std_logic_array72(3 downto 0);
    signal nbiot0_cmd_stop          : std_logic_vector(3 downto 0);
    signal nbiot1_cmd_en_ext        : std_logic_vector(3 downto 0);
    signal nbiot1_cmd_ext           : std_logic_array72(3 downto 0);
    signal nbiot1_cmd_stop          : std_logic_vector(3 downto 0);
    signal nbiot2_cmd_en_ext        : std_logic_vector(3 downto 0);
    signal nbiot2_cmd_ext           : std_logic_array72(3 downto 0);
    signal nbiot2_cmd_stop          : std_logic_vector(3 downto 0);

begin

--------------------------------------------------------------------------------
-- Split from multi-symbol C-plane message to single-symbol
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            buf_valid  <= C_PLANE_VALID;
            buf_last   <= C_PLANE_LAST;
--            buf_keep   <= C_PLANE_KEEP;
            buf_data   <= C_PLANE_DATA;
            buf_ch     <= C_PLANE_CH;
            buf_ch_sub <= C_PLANE_CH_SUB;
        end if;
    end process;

    -- FSM
    process (RST, CLK)
    begin
        if (RST = '1') then
            fsm_dec <= HDR0;
        elsif (CLK'event and CLK = '1') then
            case fsm_dec is
            when HDR0   =>
                if (buf_valid = '1') then
                    fsm_dec <= HDR1;
                else
                    fsm_dec <= HDR0;
                end if;
            when HDR1   =>
                fsm_dec <= DEC0;
            when DEC0   =>
                fsm_dec <= DEC1;
            when DEC1   =>
                if    (USAGE_TYPE0 = true) and (buf_data(23 downto 16) = 0) then
                    fsm_dec <= DUMMY;
                elsif (USAGE_TYPE1 = true) and (buf_data(23 downto 16) = 1) then
                    fsm_dec <= SEC0;
                elsif (USAGE_TYPE3 = true) and (buf_data(23 downto 16) = 3) then
                    fsm_dec <= DEC2;
                elsif (USAGE_TYPE5 = true) and (buf_data(23 downto 16) = 5) then
                    fsm_dec <= DUMMY;
                elsif (USAGE_TYPE6 = true) and (buf_data(23 downto 16) = 6) then
                    fsm_dec <= DUMMY;
                elsif (USAGE_TYPE7 = true) and (buf_data(23 downto 16) = 7) then
                    fsm_dec <= DUMMY;
                else
                    fsm_dec <= DUMMY;
                end if;
            when DEC2   =>
                fsm_dec <= SEC0;
            when SEC0   =>
                fsm_dec <= SEC1;
            when SEC1   =>
                if    (USAGE_TYPE1 = true) and (field_section_type = 1) then
                    if (buf_data(15) = '1') then
                        fsm_dec <= EXT0;
                    else
                        if (cnt_sec = field_num_section) then
                            if (buf_last = '1') then
                                fsm_dec <= HDR0;
                            else
                                fsm_dec <= DUMMY;
                            end if;
                        else
                            fsm_dec <= SEC0;
                        end if;
                    end if;
                elsif (USAGE_TYPE3 = true) and (field_section_type = 3) then
                    fsm_dec <= SEC2;
                else
                    fsm_dec <= DUMMY;
                end if;
            when SEC2   =>
                if (field_ef = '1') then
                    fsm_dec <= EXT0;
                else
                    if (cnt_sec = field_num_section) then
                        if (buf_last = '1') then
                            fsm_dec <= HDR0;
                        else
                            fsm_dec <= DUMMY;
                        end if;
                    else
                        fsm_dec <= SEC0;
                    end if;
                end if;
            when EXT0   =>
                if (buf_data(23 downto 16) = cnt_dec_state) then
                    if (buf_data(31) = '1') then
                        fsm_dec <= EXT0;
                    else
                        if (cnt_sec = field_num_section) then
                            if (buf_last = '1') then
                                fsm_dec <= HDR0;
                            else
                                fsm_dec <= DUMMY;
                            end if;
                        else
                            fsm_dec <= SEC0;
                        end if;
                    end if;
                else
                    fsm_dec <= EXT1;
                end if;
            when EXT1   =>
                if (field_ext_len = cnt_dec_state) then
                    if (field_ext_ef = '1') then
                        fsm_dec <= EXT0;
                    else
                        if (cnt_sec = field_num_section) then
                            if (buf_last = '1') then
                                fsm_dec <= HDR0;
                            else
                                fsm_dec <= DUMMY;
                            end if;
                        else
                            fsm_dec <= SEC0;
                        end if;
                    end if;
                else
                    fsm_dec <= EXT1;
                end if;
            when DUMMY  =>
                if (buf_last = '1') then
                    fsm_dec <= HDR0;
                else
                    fsm_dec <= DUMMY;
                end if;
            when others =>
                fsm_dec <= HDR0;
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when EXT0   =>
                if (buf_data(23 downto 16) = cnt_dec_state) then
                    cnt_dec_state <= "00000001";
                else
                    cnt_dec_state <= cnt_dec_state + 1;
                end if;
            when EXT1   =>
                if (field_ext_len = cnt_dec_state) then
                    cnt_dec_state <= "00000001";
                else
                    cnt_dec_state <= cnt_dec_state + 1;
                end if;
            when others =>
                cnt_dec_state <= "00000001";
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when DEC0   =>
                cnt_sec <= (others => '0');
            when SEC0   =>
                cnt_sec <= cnt_sec + 1;
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- 1st word (eCPRI header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when DEC0   =>
                field_channel_id      <= buf_ch;
                field_channel_sub_id  <= buf_ch_sub;
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- 2nd word (eCPRI header)
--    process (CLK)
--    begin
--        if (CLK'event and CLK = '1') then
--            case fsm_dec is
--            when HDR1   =>
--                field_rtcpc_id        <= buf_data(31 downto 16);
--            when others =>
--                NULL;
--            end case;
--        end if;
--    end process;

    -- 1st word (O-RAN header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when DEC0   =>
                field_data_direction  <= buf_data(31);
                field_filter_index    <= buf_data(27 downto 24);
                field_frame_id        <= buf_data(23 downto 16);
                field_subframe_id     <= buf_data(15 downto 12);
                field_slot_id         <= buf_data(11 downto 6);
                field_symbol_id       <= buf_data(5 downto 0);
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- 2nd word (O-RAN header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when DEC1   =>
                field_num_section     <= buf_data(31 downto 24);
                field_section_type    <= buf_data(23 downto 16);
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- 2nd&3rd word (O-RAN header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when DEC1   =>
                if (COMP_MODE = '1') then
                    field_ud_comp_hdr     <= buf_data(15 downto 8);
                else
                    field_ud_comp_hdr     <= IQ_WIDTH & COMP_METHOD;
                end if;
            when DEC2   =>
                if (COMP_MODE = '1') then
                    field_ud_comp_hdr     <= buf_data(15 downto 8);
                else
                    field_ud_comp_hdr     <= IQ_WIDTH & COMP_METHOD;
                end if;
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- 1st word (Section header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when SEC0   =>
                field_section_id      <= buf_data(31 downto 20);
                field_rb              <= buf_data(19);
                field_syminc          <= buf_data(18);
                field_start_prb       <= buf_data(17 downto 8);
                field_num_prb         <= buf_data(7 downto 0);
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- 2nd word (Section header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when SEC1   =>
                field_num_symbol      <= buf_data(19 downto 16);
                field_ef              <= buf_data(15);
--                field_beamid          <= buf_data(14 downto 0);
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- 3rd word (Section header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when SEC0   =>
                field_freq_offset     <= (others => '0');
            when SEC2   =>
                field_freq_offset     <= buf_data(31 downto 8);
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- 1st word (Section extension header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when SEC0   =>
                field_ext_ef          <= '0';
                field_ext_len         <= (others => '0');
                field_num_portc       <= (others => '0');
            when EXT0   =>
                field_ext_ef          <= buf_data(31);
                field_ext_len         <= buf_data(23 downto 16);
                if (buf_data(30 downto 24) = 10) then
                    if (buf_data(13 downto 8) = 0) then
                        field_num_portc       <= (others => '1');               -- exception (65R -> 64R)
                    else
                        field_num_portc       <= buf_data(13 downto 8);
                    end if;
                end if;
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- write pulse (end of each sectionExtension / end of each section)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when SEC1   =>
                if (field_section_type = 1) then
                    if (buf_data(15) = '0') then
                        write_cmd <= '1';
                    else
                        write_cmd <= '0';
                    end if;
                else
                    write_cmd <= '0';
                end if;
            when SEC2   =>
                if (field_section_type = 3) then
                    if (field_ef = '0') then
                        write_cmd <= '1';
                    else
                        write_cmd <= '0';
                    end if;
                else
                    write_cmd <= '0';
                end if;
            when EXT0   =>
                if (buf_data(23 downto 16) = cnt_dec_state) then
                    if (buf_data(31) = '0') then
                        write_cmd <= '1';
                    else
                        write_cmd <= '0';
                    end if;
                else
                    write_cmd <= '0';
                end if;
            when EXT1   =>
                if (field_ext_len = cnt_dec_state) then
                    if (field_ext_ef = '0') then
                        write_cmd <= '1';
                    else
                        write_cmd <= '0';
                    end if;
                else
                    write_cmd <= '0';
                end if;
            when others =>
                write_cmd <= '0';
            end case;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_CMD_DISTRIBUTE : UL_CMD_DISTRIBUTER
    generic map(
        MAX_CH                      => 4                                       ,--: natural := 8;
        LINK_DIRECTION              => LINK_DIRECTION                           --: std_logic := '0'
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => RST                                     ,--: in  std_logic;

        CNT_FIFO_FULL               => CNT_FIFO_FULL                           ,--: out std_logic_vector(31 downto 0);

        FREQ_OFFSET_FOR_PRACH       => FREQ_OFFSET_FOR_PRACH                   ,--: in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_eMTC        => FREQ_OFFSET_FOR_eMTC                    ,--: in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPRACH      => FREQ_OFFSET_FOR_NPRACH                  ,--: in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0     => FREQ_OFFSET_FOR_NPUSCH0                 ,--: in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1     => FREQ_OFFSET_FOR_NPUSCH1                 ,--: in  std_logic_array24(7 downto 0);

        WRITE_CMD                   => write_cmd                               ,--: in  std_logic;

        CMD_CHANNEL_ID              => field_channel_id                        ,--: in  std_logic_vector(2 downto 0);
        CMD_CHANNEL_SUB_ID          => field_channel_sub_id                    ,--: in  std_logic_vector(3 downto 0);
        CMD_DATA_DIRECTION          => field_data_direction                    ,--: in  std_logic;
        CMD_FILTER_INDEX            => field_filter_index                      ,--: in  std_logic_vector(3 downto 0);
        CMD_FRAME_ID                => field_frame_id                          ,--: in  std_logic_vector(7 downto 0);
        CMD_SUBFRAME_ID             => field_subframe_id                       ,--: in  std_logic_vector(3 downto 0);
        CMD_SLOT_ID                 => field_slot_id                           ,--: in  std_logic_vector(5 downto 0);
        CMD_SYMBOL_ID               => field_symbol_id                         ,--: in  std_logic_vector(5 downto 0);
        CMD_SECTION_TYPE            => field_section_type                      ,--: in  std_logic_vector(7 downto 0);
        CMD_UD_COMP_HDR             => field_ud_comp_hdr                       ,--: in  std_logic_vector(7 downto 0);
        CMD_SECTION_ID              => field_section_id                        ,--: in  std_logic_vector(11 downto 0);
        CMD_RB                      => field_rb                                ,--: in  std_logic;
        CMD_SYMINC                  => field_syminc                            ,--: in  std_logic;
        CMD_START_PRB               => field_start_prb                         ,--: in  std_logic_vector(9 downto 0);
        CMD_NUM_PRB                 => field_num_prb                           ,--: in  std_logic_vector(7 downto 0);
        CMD_NUM_SYMBOL              => field_num_symbol                        ,--: in  std_logic_vector(3 downto 0);
        CMD_FREQ_OFFSET             => field_freq_offset                       ,--: in  std_logic_vector(23 downto 0);
        CMD_NUM_PORTC               => field_num_portc                         ,--: in  std_logic_vector(5 downto 0);

        CMD_PUxCH_EN                => puxch_cmd_en_ext                        ,--: out std_logic_vector(13 downto 0);
        CMD_PUxCH_IN                => puxch_cmd_ext                           ,--: out std_logic_vector(71 downto 0);
        CMD_PUxCH_STOP              => puxch_cmd_stop                          ,--: in  std_logic_vector(13 downto 0);

        CMD_PRACH_EN                => prach_cmd_en_ext                        ,--: out std_logic_vector(MAX_CH-1 downto 0);
        CMD_PRACH_IN                => prach_cmd_ext                           ,--: out std_logic_array72(MAX_CH-1 downto 0);
        CMD_PRACH_STOP              => prach_cmd_stop                          ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        CMD_eMTC_EN                 => emtc_cmd_en_ext                         ,--: out std_logic_vector(MAX_CH-1 downto 0);
        CMD_eMTC_IN                 => emtc_cmd_ext                            ,--: out std_logic_array72(MAX_CH-1 downto 0);
        CMD_eMTC_STOP               => emtc_cmd_stop                           ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        CMD_NBIOT0_EN               => nbiot0_cmd_en_ext                       ,--: out std_logic_vector(MAX_CH-1 downto 0);
        CMD_NBIOT0_IN               => nbiot0_cmd_ext                          ,--: out std_logic_array72(MAX_CH-1 downto 0);
        CMD_NBIOT0_STOP             => nbiot0_cmd_stop                         ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        CMD_NBIOT1_EN               => nbiot1_cmd_en_ext                       ,--: out std_logic_vector(MAX_CH-1 downto 0);
        CMD_NBIOT1_IN               => nbiot1_cmd_ext                          ,--: out std_logic_array72(MAX_CH-1 downto 0);
        CMD_NBIOT1_STOP             => nbiot1_cmd_stop                         ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        CMD_NBIOT2_EN               => nbiot2_cmd_en_ext                       ,--: out std_logic_vector(MAX_CH-1 downto 0);
        CMD_NBIOT2_IN               => nbiot2_cmd_ext                          ,--: out std_logic_array72(MAX_CH-1 downto 0);
        CMD_NBIOT2_STOP             => nbiot2_cmd_stop                          --: in  std_logic_vector(MAX_CH-1 downto 0)
    );

    u_CQ_PUxCH : UL_CMD_QUEUE
    generic map(
        LINK_DIRECTION              => LINK_DIRECTION                          ,--: std_logic := '0';
        CMD_QUEUE_MEMORY_TYPE       => "block"                                 ,--: string := "auto";
        CMD_QUEUE_DEPTH             => MAX_SECTION_PUxCH*2                      --: integer := 2048
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => RST                                     ,--: in  std_logic;

        IGNORE_FRAME_ID             => IGNORE_FRAME_ID                         ,--: in  std_logic;
        IGNORE_FRAME_ID_RX          => IGNORE_FRAME_ID_PUxCH_RX                ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_TX          => IGNORE_FRAME_ID_PUxCH_TX                ,--: out std_logic_vector(7 downto 0);

        ID                          => PUxCH_ID                                ,--: in  std_logic_array16(7 downto 0);

        PRB_PER_SYMBOL              => PRB_PER_SYMBOL                          ,--: in  std_logic_vector(9 downto 0);
        PRB_PER_MTU                 => PRB_PER_MTU                             ,--: in  std_logic_vector(9 downto 0);

        CNT_ABNORMAL_TERMINATION    => CNT_PUxCH_TERMINATION                   ,--: out std_logic_vector(31 downto 0);

        CNT_SECTION_SYMBOL0         => CNT_PUxCH_CPSEC_SYMBOL0                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL1         => CNT_PUxCH_CPSEC_SYMBOL1                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL2         => CNT_PUxCH_CPSEC_SYMBOL2                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL3         => CNT_PUxCH_CPSEC_SYMBOL3                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL4         => CNT_PUxCH_CPSEC_SYMBOL4                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL5         => CNT_PUxCH_CPSEC_SYMBOL5                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL6         => CNT_PUxCH_CPSEC_SYMBOL6                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL7         => CNT_PUxCH_CPSEC_SYMBOL7                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL8         => CNT_PUxCH_CPSEC_SYMBOL8                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL9         => CNT_PUxCH_CPSEC_SYMBOL9                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL10        => CNT_PUxCH_CPSEC_SYMBOL10                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL11        => CNT_PUxCH_CPSEC_SYMBOL11                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL12        => CNT_PUxCH_CPSEC_SYMBOL12                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL13        => CNT_PUxCH_CPSEC_SYMBOL13                ,--: out std_logic_vector(31 downto 0);

        CNT_CQ_FULL_SYMBOL0         => CNT_PUxCH_CQ_FULL_SYMBOL0               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL1         => CNT_PUxCH_CQ_FULL_SYMBOL1               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL2         => CNT_PUxCH_CQ_FULL_SYMBOL2               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL3         => CNT_PUxCH_CQ_FULL_SYMBOL3               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL4         => CNT_PUxCH_CQ_FULL_SYMBOL4               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL5         => CNT_PUxCH_CQ_FULL_SYMBOL5               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL6         => CNT_PUxCH_CQ_FULL_SYMBOL6               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL7         => CNT_PUxCH_CQ_FULL_SYMBOL7               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL8         => CNT_PUxCH_CQ_FULL_SYMBOL8               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL9         => CNT_PUxCH_CQ_FULL_SYMBOL9               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL10        => CNT_PUxCH_CQ_FULL_SYMBOL10              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL11        => CNT_PUxCH_CQ_FULL_SYMBOL11              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL12        => CNT_PUxCH_CQ_FULL_SYMBOL12              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL13        => CNT_PUxCH_CQ_FULL_SYMBOL13              ,--: out std_logic_vector(31 downto 0);

        USAGE_CQ_SYMBOL0            => USAGE_PUxCH_CQ_SYMBOL0                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL1            => USAGE_PUxCH_CQ_SYMBOL1                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL2            => USAGE_PUxCH_CQ_SYMBOL2                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL3            => USAGE_PUxCH_CQ_SYMBOL3                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL4            => USAGE_PUxCH_CQ_SYMBOL4                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL5            => USAGE_PUxCH_CQ_SYMBOL5                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL6            => USAGE_PUxCH_CQ_SYMBOL6                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL7            => USAGE_PUxCH_CQ_SYMBOL7                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL8            => USAGE_PUxCH_CQ_SYMBOL8                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL9            => USAGE_PUxCH_CQ_SYMBOL9                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL10           => USAGE_PUxCH_CQ_SYMBOL10                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL11           => USAGE_PUxCH_CQ_SYMBOL11                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL12           => USAGE_PUxCH_CQ_SYMBOL12                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL13           => USAGE_PUxCH_CQ_SYMBOL13                 ,--: out std_logic_vector(31 downto 0);

        INFO_UPDATE                 => ULFE_UPDATE                             ,--: in  std_logic;

        INFO_FRAME_ID               => ULFE_FRAME_ID                           ,--: in  std_logic_vector(7 downto 0);
        INFO_SUBFRAME_ID            => ULFE_SUBFRAME_ID                        ,--: in  std_logic_vector(3 downto 0);
        INFO_SLOT_ID                => ULFE_SLOT_ID                            ,--: in  std_logic_vector(5 downto 0);
        INFO_SYMBOL_ID              => ULFE_SYMBOL_ID                          ,--: in  std_logic_vector(5 downto 0);

        CMD_EN                      => puxch_cmd_en_ext                        ,--: in  std_logic_vector(13 downto 0);
        CMD_IN                      => puxch_cmd_ext                           ,--: in  std_logic_vector(71 downto 0);
        CMD_STOP                    => puxch_cmd_stop                          ,--: out std_logic_vector(13 downto 0);

        INIT_SESSION                => PUxCH_INIT                              ,--: out std_logic;

        PACKING_TICK                => PUxCH_PACKING_TICK                      ,--: out std_logic_vector(3 downto 0);

        RTCPC_ID                    => PUxCH_RTCPC_ID                          ,--: out std_logic_vector(15 downto 0);

        DATA_DIRECTION              => PUxCH_DATA_DIRECTION                    ,--: out std_logic;
        PAYLOAD_VERSION             => PUxCH_PAYLOAD_VERSION                   ,--: out std_logic_vector(2 downto 0);
        FILTER_INDEX                => PUxCH_FILTER_INDEX                      ,--: out std_logic_vector(3 downto 0);
        FRAME_ID                    => PUxCH_FRAME_ID                          ,--: out std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => PUxCH_SUBFRAME_ID                       ,--: out std_logic_vector(3 downto 0);
        SLOT_ID                     => PUxCH_SLOT_ID                           ,--: out std_logic_vector(5 downto 0);
        SYMBOL_ID                   => PUxCH_SYMBOL_ID                         ,--: out std_logic_vector(5 downto 0);

        SECTION_TICK                => PUxCH_SECTION_TICK                      ,--: out std_logic_vector(3 downto 0);
        SECTION_LAST                => PUxCH_SECTION_LAST                      ,--: out std_logic_vector(3 downto 0);
        SECTION_DONE                => PUxCH_SECTION_DONE                      ,--: in  std_logic_vector(3 downto 0);

        SECTION_ID                  => PUxCH_SECTION_ID                        ,--: out std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => PUxCH_USE_EVERY_PRB                     ,--: out std_logic;
        START_OF_PRB                => PUxCH_START_OF_PRB                      ,--: out std_logic_vector(9 downto 0);
        OFFSET_OF_PRB               => PUxCH_OFFSET_OF_PRB                     ,--: out std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => PUxCH_NUMBER_OF_PRB                     ,--: out std_logic_vector(9 downto 0);
        UD_COMP_HDR                 => PUxCH_UD_COMP_HDR                        --: out std_logic_vector(7 downto 0)
    );

    u_CQ_PRACH : UL_CMD_QUEUE_RACH
    generic map(
        LINK_DIRECTION              => LINK_DIRECTION                          ,--: std_logic := '0';
        CMD_QUEUE_MEMORY_TYPE       => "block"                                 ,--: string := "auto";
        CMD_QUEUE_DEPTH             => MAX_SECTION_PRACH*2                      --: integer := 2048
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => RST                                     ,--: in  std_logic;

        IGNORE_FRAME_ID             => IGNORE_FRAME_ID                         ,--: in  std_logic;
        IGNORE_FRAME_ID_RX          => IGNORE_FRAME_ID_PRACH0_RX               ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_TX          => IGNORE_FRAME_ID_PRACH0_TX               ,--: out std_logic_vector(7 downto 0);

        ID                          => PRACH_ID                                ,--: in  std_logic_array16(7 downto 0);

        PRB_PER_SYMBOL              => PRB_PER_SYMBOL                          ,--: in  std_logic_vector(9 downto 0);
        PRB_PER_MTU                 => PRB_PER_MTU                             ,--: in  std_logic_vector(9 downto 0);

        CNT_ABNORMAL_TERMINATION    => CNT_PRACH_TERMINATION                   ,--: out std_logic_vector(31 downto 0);

        CNT_SECTION_SYMBOL0         => CNT_PRACH_CPSEC_SYMBOL0                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL1         => CNT_PRACH_CPSEC_SYMBOL1                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL2         => CNT_PRACH_CPSEC_SYMBOL2                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL3         => CNT_PRACH_CPSEC_SYMBOL3                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL4         => CNT_PRACH_CPSEC_SYMBOL4                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL5         => CNT_PRACH_CPSEC_SYMBOL5                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL6         => CNT_PRACH_CPSEC_SYMBOL6                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL7         => CNT_PRACH_CPSEC_SYMBOL7                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL8         => CNT_PRACH_CPSEC_SYMBOL8                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL9         => CNT_PRACH_CPSEC_SYMBOL9                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL10        => CNT_PRACH_CPSEC_SYMBOL10                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL11        => CNT_PRACH_CPSEC_SYMBOL11                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL12        => CNT_PRACH_CPSEC_SYMBOL12                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL13        => CNT_PRACH_CPSEC_SYMBOL13                ,--: out std_logic_vector(31 downto 0);

        CNT_CQ_FULL_SYMBOL0         => CNT_PRACH_CQ_FULL_SYMBOL0               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL1         => CNT_PRACH_CQ_FULL_SYMBOL1               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL2         => CNT_PRACH_CQ_FULL_SYMBOL2               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL3         => CNT_PRACH_CQ_FULL_SYMBOL3               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL4         => CNT_PRACH_CQ_FULL_SYMBOL4               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL5         => CNT_PRACH_CQ_FULL_SYMBOL5               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL6         => CNT_PRACH_CQ_FULL_SYMBOL6               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL7         => CNT_PRACH_CQ_FULL_SYMBOL7               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL8         => CNT_PRACH_CQ_FULL_SYMBOL8               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL9         => CNT_PRACH_CQ_FULL_SYMBOL9               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL10        => CNT_PRACH_CQ_FULL_SYMBOL10              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL11        => CNT_PRACH_CQ_FULL_SYMBOL11              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL12        => CNT_PRACH_CQ_FULL_SYMBOL12              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL13        => CNT_PRACH_CQ_FULL_SYMBOL13              ,--: out std_logic_vector(31 downto 0);

        USAGE_CQ_SYMBOL0            => USAGE_PRACH_CQ_SYMBOL0                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL1            => USAGE_PRACH_CQ_SYMBOL1                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL2            => USAGE_PRACH_CQ_SYMBOL2                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL3            => USAGE_PRACH_CQ_SYMBOL3                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL4            => USAGE_PRACH_CQ_SYMBOL4                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL5            => USAGE_PRACH_CQ_SYMBOL5                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL6            => USAGE_PRACH_CQ_SYMBOL6                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL7            => USAGE_PRACH_CQ_SYMBOL7                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL8            => USAGE_PRACH_CQ_SYMBOL8                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL9            => USAGE_PRACH_CQ_SYMBOL9                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL10           => USAGE_PRACH_CQ_SYMBOL10                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL11           => USAGE_PRACH_CQ_SYMBOL11                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL12           => USAGE_PRACH_CQ_SYMBOL12                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL13           => USAGE_PRACH_CQ_SYMBOL13                 ,--: out std_logic_vector(31 downto 0);

        INFO_UPDATE                 => RAFE0_UPDATE                            ,--: in  std_logic;

        INFO_FRAME_ID               => RAFE0_FRAME_ID                          ,--: in  std_logic_vector(7 downto 0);
        INFO_SUBFRAME_ID            => RAFE0_SUBFRAME_ID                       ,--: in  std_logic_vector(3 downto 0);
        INFO_SLOT_ID                => RAFE0_SLOT_ID                           ,--: in  std_logic_vector(5 downto 0);
        INFO_SYMBOL_ID              => RAFE0_SYMBOL_ID                         ,--: in  std_logic_vector(5 downto 0);
        INFO_CHANNEL_ID             => RAFE0_CHANNEL_ID                        ,--: in  std_logic_vector(2 downto 0);

        CMD_EN                      => prach_cmd_en_ext                        ,--: in  std_logic_vector(3 downto 0);
        CMD_IN                      => prach_cmd_ext                           ,--: in  std_logic_array72(3 downto 0);
        CMD_STOP                    => prach_cmd_stop                          ,--: out std_logic_vector(3 downto 0);

        INIT_SESSION                => PRACH_INIT                              ,--: out std_logic;

        PACKING_TICK                => PRACH_PACKING_TICK                      ,--: out std_logic_vector(3 downto 0);

        RTCPC_ID                    => PRACH_RTCPC_ID                          ,--: out std_logic_vector(15 downto 0);

        DATA_DIRECTION              => PRACH_DATA_DIRECTION                    ,--: out std_logic;
        PAYLOAD_VERSION             => PRACH_PAYLOAD_VERSION                   ,--: out std_logic_vector(2 downto 0);
        FILTER_INDEX                => PRACH_FILTER_INDEX                      ,--: out std_logic_vector(3 downto 0);
        FRAME_ID                    => PRACH_FRAME_ID                          ,--: out std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => PRACH_SUBFRAME_ID                       ,--: out std_logic_vector(3 downto 0);
        SLOT_ID                     => PRACH_SLOT_ID                           ,--: out std_logic_vector(5 downto 0);
        SYMBOL_ID                   => PRACH_SYMBOL_ID                         ,--: out std_logic_vector(5 downto 0);

        SECTION_TICK                => PRACH_SECTION_TICK                      ,--: out std_logic_vector(3 downto 0);
        SECTION_LAST                => PRACH_SECTION_LAST                      ,--: out std_logic_vector(3 downto 0);
        SECTION_DONE                => PRACH_SECTION_DONE                      ,--: in  std_logic_vector(3 downto 0);

        SECTION_ID                  => PRACH_SECTION_ID                        ,--: out std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => PRACH_USE_EVERY_PRB                     ,--: out std_logic;
        START_OF_PRB                => PRACH_START_OF_PRB                      ,--: out std_logic_vector(9 downto 0);
        OFFSET_OF_PRB               => PRACH_OFFSET_OF_PRB                     ,--: out std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => PRACH_NUMBER_OF_PRB                     ,--: out std_logic_vector(9 downto 0);
        UD_COMP_HDR                 => PRACH_UD_COMP_HDR                        --: out std_logic_vector(7 downto 0)
    );

    u_CQ_eMTC : UL_CMD_QUEUE_RACH
    generic map(
        LINK_DIRECTION              => LINK_DIRECTION                          ,--: std_logic := '0';
        CMD_QUEUE_MEMORY_TYPE       => "block"                                 ,--: string := "auto";
        CMD_QUEUE_DEPTH             => MAX_SECTION_eMTC*2                       --: integer := 2048
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => RST                                     ,--: in  std_logic;

        IGNORE_FRAME_ID             => IGNORE_FRAME_ID                         ,--: in  std_logic;
        IGNORE_FRAME_ID_RX          => IGNORE_FRAME_ID_PRACH1_RX               ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_TX          => IGNORE_FRAME_ID_PRACH1_TX               ,--: out std_logic_vector(7 downto 0);

        ID                          => PRACH_ID                                ,--: in  std_logic_array16(7 downto 0);

        PRB_PER_SYMBOL              => PRB_PER_SYMBOL                          ,--: in  std_logic_vector(9 downto 0);
        PRB_PER_MTU                 => PRB_PER_MTU                             ,--: in  std_logic_vector(9 downto 0);

        CNT_ABNORMAL_TERMINATION    => CNT_eMTC_TERMINATION                    ,--: out std_logic_vector(31 downto 0);

        CNT_SECTION_SYMBOL0         => CNT_eMTC_CPSEC_SYMBOL0                  ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL1         => CNT_eMTC_CPSEC_SYMBOL1                  ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL2         => CNT_eMTC_CPSEC_SYMBOL2                  ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL3         => CNT_eMTC_CPSEC_SYMBOL3                  ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL4         => CNT_eMTC_CPSEC_SYMBOL4                  ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL5         => CNT_eMTC_CPSEC_SYMBOL5                  ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL6         => CNT_eMTC_CPSEC_SYMBOL6                  ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL7         => CNT_eMTC_CPSEC_SYMBOL7                  ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL8         => CNT_eMTC_CPSEC_SYMBOL8                  ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL9         => CNT_eMTC_CPSEC_SYMBOL9                  ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL10        => CNT_eMTC_CPSEC_SYMBOL10                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL11        => CNT_eMTC_CPSEC_SYMBOL11                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL12        => CNT_eMTC_CPSEC_SYMBOL12                 ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL13        => CNT_eMTC_CPSEC_SYMBOL13                 ,--: out std_logic_vector(31 downto 0);

        CNT_CQ_FULL_SYMBOL0         => CNT_eMTC_CQ_FULL_SYMBOL0                ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL1         => CNT_eMTC_CQ_FULL_SYMBOL1                ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL2         => CNT_eMTC_CQ_FULL_SYMBOL2                ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL3         => CNT_eMTC_CQ_FULL_SYMBOL3                ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL4         => CNT_eMTC_CQ_FULL_SYMBOL4                ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL5         => CNT_eMTC_CQ_FULL_SYMBOL5                ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL6         => CNT_eMTC_CQ_FULL_SYMBOL6                ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL7         => CNT_eMTC_CQ_FULL_SYMBOL7                ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL8         => CNT_eMTC_CQ_FULL_SYMBOL8                ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL9         => CNT_eMTC_CQ_FULL_SYMBOL9                ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL10        => CNT_eMTC_CQ_FULL_SYMBOL10               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL11        => CNT_eMTC_CQ_FULL_SYMBOL11               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL12        => CNT_eMTC_CQ_FULL_SYMBOL12               ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL13        => CNT_eMTC_CQ_FULL_SYMBOL13               ,--: out std_logic_vector(31 downto 0);

        USAGE_CQ_SYMBOL0            => USAGE_eMTC_CQ_SYMBOL0                   ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL1            => USAGE_eMTC_CQ_SYMBOL1                   ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL2            => USAGE_eMTC_CQ_SYMBOL2                   ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL3            => USAGE_eMTC_CQ_SYMBOL3                   ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL4            => USAGE_eMTC_CQ_SYMBOL4                   ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL5            => USAGE_eMTC_CQ_SYMBOL5                   ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL6            => USAGE_eMTC_CQ_SYMBOL6                   ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL7            => USAGE_eMTC_CQ_SYMBOL7                   ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL8            => USAGE_eMTC_CQ_SYMBOL8                   ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL9            => USAGE_eMTC_CQ_SYMBOL9                   ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL10           => USAGE_eMTC_CQ_SYMBOL10                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL11           => USAGE_eMTC_CQ_SYMBOL11                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL12           => USAGE_eMTC_CQ_SYMBOL12                  ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL13           => USAGE_eMTC_CQ_SYMBOL13                  ,--: out std_logic_vector(31 downto 0);

        INFO_UPDATE                 => RAFE1_UPDATE                            ,--: in  std_logic;

        INFO_FRAME_ID               => RAFE1_FRAME_ID                          ,--: in  std_logic_vector(7 downto 0);
        INFO_SUBFRAME_ID            => RAFE1_SUBFRAME_ID                       ,--: in  std_logic_vector(3 downto 0);
        INFO_SLOT_ID                => RAFE1_SLOT_ID                           ,--: in  std_logic_vector(5 downto 0);
        INFO_SYMBOL_ID              => RAFE1_SYMBOL_ID                         ,--: in  std_logic_vector(5 downto 0);
        INFO_CHANNEL_ID             => RAFE1_CHANNEL_ID                        ,--: in  std_logic_vector(2 downto 0);

        CMD_EN                      => emtc_cmd_en_ext                         ,--: in  std_logic_vector(3 downto 0);
        CMD_IN                      => emtc_cmd_ext                            ,--: in  std_logic_array72(3 downto 0);
        CMD_STOP                    => emtc_cmd_stop                           ,--: out std_logic_vector(3 downto 0);

        INIT_SESSION                => eMTC_INIT                               ,--: out std_logic;

        PACKING_TICK                => eMTC_PACKING_TICK                       ,--: out std_logic_vector(3 downto 0);

        RTCPC_ID                    => eMTC_RTCPC_ID                           ,--: out std_logic_vector(15 downto 0);

        DATA_DIRECTION              => eMTC_DATA_DIRECTION                     ,--: out std_logic;
        PAYLOAD_VERSION             => eMTC_PAYLOAD_VERSION                    ,--: out std_logic_vector(2 downto 0);
        FILTER_INDEX                => eMTC_FILTER_INDEX                       ,--: out std_logic_vector(3 downto 0);
        FRAME_ID                    => eMTC_FRAME_ID                           ,--: out std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => eMTC_SUBFRAME_ID                        ,--: out std_logic_vector(3 downto 0);
        SLOT_ID                     => eMTC_SLOT_ID                            ,--: out std_logic_vector(5 downto 0);
        SYMBOL_ID                   => eMTC_SYMBOL_ID                          ,--: out std_logic_vector(5 downto 0);

        SECTION_TICK                => eMTC_SECTION_TICK                       ,--: out std_logic_vector(3 downto 0);
        SECTION_LAST                => eMTC_SECTION_LAST                       ,--: out std_logic_vector(3 downto 0);
        SECTION_DONE                => eMTC_SECTION_DONE                       ,--: in  std_logic_vector(3 downto 0);

        SECTION_ID                  => eMTC_SECTION_ID                         ,--: out std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => eMTC_USE_EVERY_PRB                      ,--: out std_logic;
        START_OF_PRB                => eMTC_START_OF_PRB                       ,--: out std_logic_vector(9 downto 0);
        OFFSET_OF_PRB               => eMTC_OFFSET_OF_PRB                      ,--: out std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => eMTC_NUMBER_OF_PRB                      ,--: out std_logic_vector(9 downto 0);
        UD_COMP_HDR                 => eMTC_UD_COMP_HDR                         --: out std_logic_vector(7 downto 0)
    );

    u_CQ_NBIOT0 : UL_CMD_QUEUE_RACH
    generic map(
        LINK_DIRECTION              => LINK_DIRECTION                          ,--: std_logic := '0';
        CMD_QUEUE_MEMORY_TYPE       => "block"                                 ,--: string := "auto";
        CMD_QUEUE_DEPTH             => MAX_SECTION_NBIOT0*2                     --: integer := 2048
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => RST                                     ,--: in  std_logic;

        IGNORE_FRAME_ID             => IGNORE_FRAME_ID                         ,--: in  std_logic;
        IGNORE_FRAME_ID_RX          => IGNORE_FRAME_ID_NBIOT0_RX               ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_TX          => IGNORE_FRAME_ID_NBIOT0_TX               ,--: out std_logic_vector(7 downto 0);

        ID                          => NPUSCH_ID                               ,--: in  std_logic_array16(7 downto 0);

        PRB_PER_SYMBOL              => PRB_PER_SYMBOL                          ,--: in  std_logic_vector(9 downto 0);
        PRB_PER_MTU                 => PRB_PER_MTU                             ,--: in  std_logic_vector(9 downto 0);

        CNT_ABNORMAL_TERMINATION    => CNT_NBIOT0_TERMINATION                  ,--: out std_logic_vector(31 downto 0);

        CNT_SECTION_SYMBOL0         => CNT_NBIOT0_CPSEC_SYMBOL0                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL1         => CNT_NBIOT0_CPSEC_SYMBOL1                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL2         => CNT_NBIOT0_CPSEC_SYMBOL2                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL3         => CNT_NBIOT0_CPSEC_SYMBOL3                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL4         => CNT_NBIOT0_CPSEC_SYMBOL4                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL5         => CNT_NBIOT0_CPSEC_SYMBOL5                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL6         => CNT_NBIOT0_CPSEC_SYMBOL6                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL7         => CNT_NBIOT0_CPSEC_SYMBOL7                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL8         => CNT_NBIOT0_CPSEC_SYMBOL8                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL9         => CNT_NBIOT0_CPSEC_SYMBOL9                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL10        => CNT_NBIOT0_CPSEC_SYMBOL10               ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL11        => CNT_NBIOT0_CPSEC_SYMBOL11               ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL12        => CNT_NBIOT0_CPSEC_SYMBOL12               ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL13        => CNT_NBIOT0_CPSEC_SYMBOL13               ,--: out std_logic_vector(31 downto 0);

        CNT_CQ_FULL_SYMBOL0         => CNT_NBIOT0_CQ_FULL_SYMBOL0              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL1         => CNT_NBIOT0_CQ_FULL_SYMBOL1              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL2         => CNT_NBIOT0_CQ_FULL_SYMBOL2              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL3         => CNT_NBIOT0_CQ_FULL_SYMBOL3              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL4         => CNT_NBIOT0_CQ_FULL_SYMBOL4              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL5         => CNT_NBIOT0_CQ_FULL_SYMBOL5              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL6         => CNT_NBIOT0_CQ_FULL_SYMBOL6              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL7         => CNT_NBIOT0_CQ_FULL_SYMBOL7              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL8         => CNT_NBIOT0_CQ_FULL_SYMBOL8              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL9         => CNT_NBIOT0_CQ_FULL_SYMBOL9              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL10        => CNT_NBIOT0_CQ_FULL_SYMBOL10             ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL11        => CNT_NBIOT0_CQ_FULL_SYMBOL11             ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL12        => CNT_NBIOT0_CQ_FULL_SYMBOL12             ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL13        => CNT_NBIOT0_CQ_FULL_SYMBOL13             ,--: out std_logic_vector(31 downto 0);

        USAGE_CQ_SYMBOL0            => USAGE_NBIOT0_CQ_SYMBOL0                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL1            => USAGE_NBIOT0_CQ_SYMBOL1                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL2            => USAGE_NBIOT0_CQ_SYMBOL2                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL3            => USAGE_NBIOT0_CQ_SYMBOL3                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL4            => USAGE_NBIOT0_CQ_SYMBOL4                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL5            => USAGE_NBIOT0_CQ_SYMBOL5                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL6            => USAGE_NBIOT0_CQ_SYMBOL6                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL7            => USAGE_NBIOT0_CQ_SYMBOL7                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL8            => USAGE_NBIOT0_CQ_SYMBOL8                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL9            => USAGE_NBIOT0_CQ_SYMBOL9                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL10           => USAGE_NBIOT0_CQ_SYMBOL10                ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL11           => USAGE_NBIOT0_CQ_SYMBOL11                ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL12           => USAGE_NBIOT0_CQ_SYMBOL12                ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL13           => USAGE_NBIOT0_CQ_SYMBOL13                ,--: out std_logic_vector(31 downto 0);

        INFO_UPDATE                 => NBFE0_UPDATE                            ,--: in  std_logic;

        INFO_FRAME_ID               => NBFE0_FRAME_ID                          ,--: in  std_logic_vector(7 downto 0);
        INFO_SUBFRAME_ID            => NBFE0_SUBFRAME_ID                       ,--: in  std_logic_vector(3 downto 0);
        INFO_SLOT_ID                => NBFE0_SLOT_ID                           ,--: in  std_logic_vector(5 downto 0);
        INFO_SYMBOL_ID              => NBFE0_SYMBOL_ID                         ,--: in  std_logic_vector(5 downto 0);
        INFO_CHANNEL_ID             => NBFE0_CHANNEL_ID                        ,--: in  std_logic_vector(2 downto 0);

        CMD_EN                      => nbiot0_cmd_en_ext                       ,--: in  std_logic_vector(3 downto 0);
        CMD_IN                      => nbiot0_cmd_ext                          ,--: in  std_logic_array72(3 downto 0);
        CMD_STOP                    => nbiot0_cmd_stop                         ,--: out std_logic_vector(3 downto 0);

        INIT_SESSION                => NBIOT0_INIT                             ,--: out std_logic;

        PACKING_TICK                => NBIOT0_PACKING_TICK                     ,--: out std_logic_vector(3 downto 0);

        RTCPC_ID                    => NBIOT0_RTCPC_ID                         ,--: out std_logic_vector(15 downto 0);

        DATA_DIRECTION              => NBIOT0_DATA_DIRECTION                   ,--: out std_logic;
        PAYLOAD_VERSION             => NBIOT0_PAYLOAD_VERSION                  ,--: out std_logic_vector(2 downto 0);
        FILTER_INDEX                => NBIOT0_FILTER_INDEX                     ,--: out std_logic_vector(3 downto 0);
        FRAME_ID                    => NBIOT0_FRAME_ID                         ,--: out std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => NBIOT0_SUBFRAME_ID                      ,--: out std_logic_vector(3 downto 0);
        SLOT_ID                     => NBIOT0_SLOT_ID                          ,--: out std_logic_vector(5 downto 0);
        SYMBOL_ID                   => NBIOT0_SYMBOL_ID                        ,--: out std_logic_vector(5 downto 0);

        SECTION_TICK                => NBIOT0_SECTION_TICK                     ,--: out std_logic_vector(3 downto 0);
        SECTION_LAST                => NBIOT0_SECTION_LAST                     ,--: out std_logic_vector(3 downto 0);
        SECTION_DONE                => NBIOT0_SECTION_DONE                     ,--: in  std_logic_vector(3 downto 0);

        SECTION_ID                  => NBIOT0_SECTION_ID                       ,--: out std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => NBIOT0_USE_EVERY_PRB                    ,--: out std_logic;
        START_OF_PRB                => NBIOT0_START_OF_PRB                     ,--: out std_logic_vector(9 downto 0);
        OFFSET_OF_PRB               => NBIOT0_OFFSET_OF_PRB                    ,--: out std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => NBIOT0_NUMBER_OF_PRB                    ,--: out std_logic_vector(9 downto 0);
        UD_COMP_HDR                 => NBIOT0_UD_COMP_HDR                       --: out std_logic_vector(7 downto 0)
    );

    u_CQ_NBIOT1 : UL_CMD_QUEUE_RACH
    generic map(
        LINK_DIRECTION              => LINK_DIRECTION                          ,--: std_logic := '0';
        CMD_QUEUE_MEMORY_TYPE       => "block"                                 ,--: string := "auto";
        CMD_QUEUE_DEPTH             => MAX_SECTION_NBIOT1*2                     --: integer := 2048
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => RST                                     ,--: in  std_logic;

        IGNORE_FRAME_ID             => IGNORE_FRAME_ID                         ,--: in  std_logic;
        IGNORE_FRAME_ID_RX          => IGNORE_FRAME_ID_NBIOT1_RX               ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_TX          => IGNORE_FRAME_ID_NBIOT1_TX               ,--: out std_logic_vector(7 downto 0);

        ID                          => NPUSCH_ID                               ,--: in  std_logic_array16(7 downto 0);

        PRB_PER_SYMBOL              => PRB_PER_SYMBOL                          ,--: in  std_logic_vector(9 downto 0);
        PRB_PER_MTU                 => PRB_PER_MTU                             ,--: in  std_logic_vector(9 downto 0);

        CNT_ABNORMAL_TERMINATION    => CNT_NBIOT1_TERMINATION                  ,--: out std_logic_vector(31 downto 0);

        CNT_SECTION_SYMBOL0         => CNT_NBIOT1_CPSEC_SYMBOL0                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL1         => CNT_NBIOT1_CPSEC_SYMBOL1                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL2         => CNT_NBIOT1_CPSEC_SYMBOL2                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL3         => CNT_NBIOT1_CPSEC_SYMBOL3                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL4         => CNT_NBIOT1_CPSEC_SYMBOL4                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL5         => CNT_NBIOT1_CPSEC_SYMBOL5                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL6         => CNT_NBIOT1_CPSEC_SYMBOL6                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL7         => CNT_NBIOT1_CPSEC_SYMBOL7                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL8         => CNT_NBIOT1_CPSEC_SYMBOL8                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL9         => CNT_NBIOT1_CPSEC_SYMBOL9                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL10        => CNT_NBIOT1_CPSEC_SYMBOL10               ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL11        => CNT_NBIOT1_CPSEC_SYMBOL11               ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL12        => CNT_NBIOT1_CPSEC_SYMBOL12               ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL13        => CNT_NBIOT1_CPSEC_SYMBOL13               ,--: out std_logic_vector(31 downto 0);

        CNT_CQ_FULL_SYMBOL0         => CNT_NBIOT1_CQ_FULL_SYMBOL0              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL1         => CNT_NBIOT1_CQ_FULL_SYMBOL1              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL2         => CNT_NBIOT1_CQ_FULL_SYMBOL2              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL3         => CNT_NBIOT1_CQ_FULL_SYMBOL3              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL4         => CNT_NBIOT1_CQ_FULL_SYMBOL4              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL5         => CNT_NBIOT1_CQ_FULL_SYMBOL5              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL6         => CNT_NBIOT1_CQ_FULL_SYMBOL6              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL7         => CNT_NBIOT1_CQ_FULL_SYMBOL7              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL8         => CNT_NBIOT1_CQ_FULL_SYMBOL8              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL9         => CNT_NBIOT1_CQ_FULL_SYMBOL9              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL10        => CNT_NBIOT1_CQ_FULL_SYMBOL10             ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL11        => CNT_NBIOT1_CQ_FULL_SYMBOL11             ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL12        => CNT_NBIOT1_CQ_FULL_SYMBOL12             ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL13        => CNT_NBIOT1_CQ_FULL_SYMBOL13             ,--: out std_logic_vector(31 downto 0);

        USAGE_CQ_SYMBOL0            => USAGE_NBIOT1_CQ_SYMBOL0                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL1            => USAGE_NBIOT1_CQ_SYMBOL1                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL2            => USAGE_NBIOT1_CQ_SYMBOL2                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL3            => USAGE_NBIOT1_CQ_SYMBOL3                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL4            => USAGE_NBIOT1_CQ_SYMBOL4                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL5            => USAGE_NBIOT1_CQ_SYMBOL5                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL6            => USAGE_NBIOT1_CQ_SYMBOL6                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL7            => USAGE_NBIOT1_CQ_SYMBOL7                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL8            => USAGE_NBIOT1_CQ_SYMBOL8                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL9            => USAGE_NBIOT1_CQ_SYMBOL9                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL10           => USAGE_NBIOT1_CQ_SYMBOL10                ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL11           => USAGE_NBIOT1_CQ_SYMBOL11                ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL12           => USAGE_NBIOT1_CQ_SYMBOL12                ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL13           => USAGE_NBIOT1_CQ_SYMBOL13                ,--: out std_logic_vector(31 downto 0);

        INFO_UPDATE                 => NBFE1_UPDATE                            ,--: in  std_logic;

        INFO_FRAME_ID               => NBFE1_FRAME_ID                          ,--: in  std_logic_vector(7 downto 0);
        INFO_SUBFRAME_ID            => NBFE1_SUBFRAME_ID                       ,--: in  std_logic_vector(3 downto 0);
        INFO_SLOT_ID                => NBFE1_SLOT_ID                           ,--: in  std_logic_vector(5 downto 0);
        INFO_SYMBOL_ID              => NBFE1_SYMBOL_ID                         ,--: in  std_logic_vector(5 downto 0);
        INFO_CHANNEL_ID             => NBFE1_CHANNEL_ID                        ,--: in  std_logic_vector(2 downto 0);

        CMD_EN                      => nbiot1_cmd_en_ext                       ,--: in  std_logic_vector(3 downto 0);
        CMD_IN                      => nbiot1_cmd_ext                          ,--: in  std_logic_array72(3 downto 0);
        CMD_STOP                    => nbiot1_cmd_stop                         ,--: out std_logic_vector(3 downto 0);

        INIT_SESSION                => NBIOT1_INIT                             ,--: out std_logic;

        PACKING_TICK                => NBIOT1_PACKING_TICK                     ,--: out std_logic_vector(3 downto 0);

        RTCPC_ID                    => NBIOT1_RTCPC_ID                         ,--: out std_logic_vector(15 downto 0);

        DATA_DIRECTION              => NBIOT1_DATA_DIRECTION                   ,--: out std_logic;
        PAYLOAD_VERSION             => NBIOT1_PAYLOAD_VERSION                  ,--: out std_logic_vector(2 downto 0);
        FILTER_INDEX                => NBIOT1_FILTER_INDEX                     ,--: out std_logic_vector(3 downto 0);
        FRAME_ID                    => NBIOT1_FRAME_ID                         ,--: out std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => NBIOT1_SUBFRAME_ID                      ,--: out std_logic_vector(3 downto 0);
        SLOT_ID                     => NBIOT1_SLOT_ID                          ,--: out std_logic_vector(5 downto 0);
        SYMBOL_ID                   => NBIOT1_SYMBOL_ID                        ,--: out std_logic_vector(5 downto 0);

        SECTION_TICK                => NBIOT1_SECTION_TICK                     ,--: out std_logic_vector(3 downto 0);
        SECTION_LAST                => NBIOT1_SECTION_LAST                     ,--: out std_logic_vector(3 downto 0);
        SECTION_DONE                => NBIOT1_SECTION_DONE                     ,--: in  std_logic_vector(3 downto 0);

        SECTION_ID                  => NBIOT1_SECTION_ID                       ,--: out std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => NBIOT1_USE_EVERY_PRB                    ,--: out std_logic;
        START_OF_PRB                => NBIOT1_START_OF_PRB                     ,--: out std_logic_vector(9 downto 0);
        OFFSET_OF_PRB               => NBIOT1_OFFSET_OF_PRB                    ,--: out std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => NBIOT1_NUMBER_OF_PRB                    ,--: out std_logic_vector(9 downto 0);
        UD_COMP_HDR                 => NBIOT1_UD_COMP_HDR                       --: out std_logic_vector(7 downto 0)
    );

    u_CQ_NBIOT2 : UL_CMD_QUEUE_RACH
    generic map(
        LINK_DIRECTION              => LINK_DIRECTION                          ,--: std_logic := '0';
        CMD_QUEUE_MEMORY_TYPE       => "block"                                 ,--: string := "auto";
        CMD_QUEUE_DEPTH             => MAX_SECTION_NBIOT2*2                     --: integer := 2048
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => RST                                     ,--: in  std_logic;

        IGNORE_FRAME_ID             => IGNORE_FRAME_ID                         ,--: in  std_logic;
        IGNORE_FRAME_ID_RX          => IGNORE_FRAME_ID_NBIOT2_RX               ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_TX          => IGNORE_FRAME_ID_NBIOT2_TX               ,--: out std_logic_vector(7 downto 0);

        ID                          => PRACH_ID                                ,--: in  std_logic_array16(7 downto 0);

        PRB_PER_SYMBOL              => PRB_PER_SYMBOL                          ,--: in  std_logic_vector(9 downto 0);
        PRB_PER_MTU                 => PRB_PER_MTU                             ,--: in  std_logic_vector(9 downto 0);

        CNT_ABNORMAL_TERMINATION    => CNT_NBIOT2_TERMINATION                  ,--: out std_logic_vector(31 downto 0);

        CNT_SECTION_SYMBOL0         => CNT_NBIOT2_CPSEC_SYMBOL0                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL1         => CNT_NBIOT2_CPSEC_SYMBOL1                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL2         => CNT_NBIOT2_CPSEC_SYMBOL2                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL3         => CNT_NBIOT2_CPSEC_SYMBOL3                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL4         => CNT_NBIOT2_CPSEC_SYMBOL4                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL5         => CNT_NBIOT2_CPSEC_SYMBOL5                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL6         => CNT_NBIOT2_CPSEC_SYMBOL6                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL7         => CNT_NBIOT2_CPSEC_SYMBOL7                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL8         => CNT_NBIOT2_CPSEC_SYMBOL8                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL9         => CNT_NBIOT2_CPSEC_SYMBOL9                ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL10        => CNT_NBIOT2_CPSEC_SYMBOL10               ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL11        => CNT_NBIOT2_CPSEC_SYMBOL11               ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL12        => CNT_NBIOT2_CPSEC_SYMBOL12               ,--: out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL13        => CNT_NBIOT2_CPSEC_SYMBOL13               ,--: out std_logic_vector(31 downto 0);

        CNT_CQ_FULL_SYMBOL0         => CNT_NBIOT2_CQ_FULL_SYMBOL0              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL1         => CNT_NBIOT2_CQ_FULL_SYMBOL1              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL2         => CNT_NBIOT2_CQ_FULL_SYMBOL2              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL3         => CNT_NBIOT2_CQ_FULL_SYMBOL3              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL4         => CNT_NBIOT2_CQ_FULL_SYMBOL4              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL5         => CNT_NBIOT2_CQ_FULL_SYMBOL5              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL6         => CNT_NBIOT2_CQ_FULL_SYMBOL6              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL7         => CNT_NBIOT2_CQ_FULL_SYMBOL7              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL8         => CNT_NBIOT2_CQ_FULL_SYMBOL8              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL9         => CNT_NBIOT2_CQ_FULL_SYMBOL9              ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL10        => CNT_NBIOT2_CQ_FULL_SYMBOL10             ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL11        => CNT_NBIOT2_CQ_FULL_SYMBOL11             ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL12        => CNT_NBIOT2_CQ_FULL_SYMBOL12             ,--: out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL13        => CNT_NBIOT2_CQ_FULL_SYMBOL13             ,--: out std_logic_vector(31 downto 0);

        USAGE_CQ_SYMBOL0            => USAGE_NBIOT2_CQ_SYMBOL0                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL1            => USAGE_NBIOT2_CQ_SYMBOL1                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL2            => USAGE_NBIOT2_CQ_SYMBOL2                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL3            => USAGE_NBIOT2_CQ_SYMBOL3                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL4            => USAGE_NBIOT2_CQ_SYMBOL4                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL5            => USAGE_NBIOT2_CQ_SYMBOL5                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL6            => USAGE_NBIOT2_CQ_SYMBOL6                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL7            => USAGE_NBIOT2_CQ_SYMBOL7                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL8            => USAGE_NBIOT2_CQ_SYMBOL8                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL9            => USAGE_NBIOT2_CQ_SYMBOL9                 ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL10           => USAGE_NBIOT2_CQ_SYMBOL10                ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL11           => USAGE_NBIOT2_CQ_SYMBOL11                ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL12           => USAGE_NBIOT2_CQ_SYMBOL12                ,--: out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL13           => USAGE_NBIOT2_CQ_SYMBOL13                ,--: out std_logic_vector(31 downto 0);

        INFO_UPDATE                 => NBFE2_UPDATE                            ,--: in  std_logic;

        INFO_FRAME_ID               => NBFE2_FRAME_ID                          ,--: in  std_logic_vector(7 downto 0);
        INFO_SUBFRAME_ID            => NBFE2_SUBFRAME_ID                       ,--: in  std_logic_vector(3 downto 0);
        INFO_SLOT_ID                => NBFE2_SLOT_ID                           ,--: in  std_logic_vector(5 downto 0);
        INFO_SYMBOL_ID              => NBFE2_SYMBOL_ID                         ,--: in  std_logic_vector(5 downto 0);
        INFO_CHANNEL_ID             => NBFE2_CHANNEL_ID                        ,--: in  std_logic_vector(2 downto 0);

        CMD_EN                      => nbiot2_cmd_en_ext                       ,--: in  std_logic_vector(3 downto 0);
        CMD_IN                      => nbiot2_cmd_ext                          ,--: in  std_logic_array72(3 downto 0);
        CMD_STOP                    => nbiot2_cmd_stop                         ,--: out std_logic_vector(3 downto 0);

        INIT_SESSION                => NBIOT2_INIT                             ,--: out std_logic;

        PACKING_TICK                => NBIOT2_PACKING_TICK                     ,--: out std_logic_vector(3 downto 0);

        RTCPC_ID                    => NBIOT2_RTCPC_ID                         ,--: out std_logic_vector(15 downto 0);

        DATA_DIRECTION              => NBIOT2_DATA_DIRECTION                   ,--: out std_logic;
        PAYLOAD_VERSION             => NBIOT2_PAYLOAD_VERSION                  ,--: out std_logic_vector(2 downto 0);
        FILTER_INDEX                => NBIOT2_FILTER_INDEX                     ,--: out std_logic_vector(3 downto 0);
        FRAME_ID                    => NBIOT2_FRAME_ID                         ,--: out std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => NBIOT2_SUBFRAME_ID                      ,--: out std_logic_vector(3 downto 0);
        SLOT_ID                     => NBIOT2_SLOT_ID                          ,--: out std_logic_vector(5 downto 0);
        SYMBOL_ID                   => NBIOT2_SYMBOL_ID                        ,--: out std_logic_vector(5 downto 0);

        SECTION_TICK                => NBIOT2_SECTION_TICK                     ,--: out std_logic_vector(3 downto 0);
        SECTION_LAST                => NBIOT2_SECTION_LAST                     ,--: out std_logic_vector(3 downto 0);
        SECTION_DONE                => NBIOT2_SECTION_DONE                     ,--: in  std_logic_vector(3 downto 0);

        SECTION_ID                  => NBIOT2_SECTION_ID                       ,--: out std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => NBIOT2_USE_EVERY_PRB                    ,--: out std_logic;
        START_OF_PRB                => NBIOT2_START_OF_PRB                     ,--: out std_logic_vector(9 downto 0);
        OFFSET_OF_PRB               => NBIOT2_OFFSET_OF_PRB                    ,--: out std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => NBIOT2_NUMBER_OF_PRB                    ,--: out std_logic_vector(9 downto 0);
        UD_COMP_HDR                 => NBIOT2_UD_COMP_HDR                       --: out std_logic_vector(7 downto 0)
    );

end BEHAVE;