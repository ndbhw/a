--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : O-RAN UL data manager                                         --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.PKG_O_RAN.ALL;
use WORK.ARRAY_TYPE.ALL;

entity DATA_MANAGER_UL0 is
    generic (
        MAX_SECTION_PUxCH           : natural := 256;
        MAX_SECTION_PRACH           : natural := 32;
        MAX_SECTION_eMTC            : natural := 8;
        MAX_SECTION_NBIOT0          : natural := 8;
        MAX_SECTION_NBIOT1          : natural := 8;
        MAX_SECTION_NBIOT2          : natural := 8;
        LONG_PRACH                  : boolean := true
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;                            -- 245.76-MHz
        RST                         : in  std_logic;                            -- ASYNC

--------------------------------------------------------------------------------
-- Debug
--------------------------------------------------------------------------------

        IGNORE_FRAME_ID             : in  std_logic;
        IGNORE_FRAME_ID_PUxCH_RX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT2_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT2_TX   : out std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        UL_PUxCH_EN                 : in  std_logic_vector(7 downto 0);
        UL_PUxCH_ID                 : in  std_logic_array16(7 downto 0);
        UL_PRACH_EN                 : in  std_logic_vector(7 downto 0);
        UL_PRACH_ID                 : in  std_logic_array16(7 downto 0);
        UL_NPUSCH_EN                : in  std_logic_vector(7 downto 0);
        UL_NPUSCH_ID                : in  std_logic_array16(7 downto 0);

        UL_COMP_MODE                : in  std_logic;
        UL_IQ_WIDTH                 : in  std_logic_vector(3 downto 0);
        UL_COMP_METHOD              : in  std_logic_vector(3 downto 0);
        UL_SCS_CONFIG               : in  std_logic_vector(3 downto 0);
        UL_FFT_SIZE                 : in  std_logic_vector(3 downto 0);
        UL_PRB_PER_MTU              : in  std_logic_vector(9 downto 0);
        UL_PRB_PER_SYMBOL           : in  std_logic_vector(9 downto 0);

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        CNT_FIFO_FULL               : out std_logic_vector(31 downto 0);

        CNT_PUxCH_TERMINATION       : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL0   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL1   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL2   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL3   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL4   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL5   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL6   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL7   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL8   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL9   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL10  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL11  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL12  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL13  : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL0      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL1      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL2      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL3      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL4      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL5      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL6      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL7      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL8      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL9      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL10     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL11     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL12     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL13     : out std_logic_vector(31 downto 0);

        CNT_PRACH_TERMINATION       : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL0   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL1   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL2   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL3   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL4   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL5   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL6   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL7   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL8   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL9   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL10  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL11  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL12  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL13  : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL0      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL1      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL2      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL3      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL4      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL5      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL6      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL7      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL8      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL9      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL10     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL11     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL12     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL13     : out std_logic_vector(31 downto 0);

        CNT_eMTC_TERMINATION        : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL0      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL1      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL2      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL3      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL4      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL5      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL6      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL7      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL8      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL9      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL10     : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL11     : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL12     : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL13     : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL0      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL1      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL2      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL3      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL4      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL5      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL6      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL7      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL8      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL9      : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL10     : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL11     : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL12     : out std_logic_vector(31 downto 0);
        CNT_eMTC_UPPKT_SYMBOL13     : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL13   : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL0       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL1       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL2       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL3       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL4       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL5       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL6       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL7       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL8       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL9       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL10      : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL11      : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL12      : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL13      : out std_logic_vector(31 downto 0);

        CNT_NBIOT0_TERMINATION      : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL13   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_UPPKT_SYMBOL13   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL0  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL1  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL2  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL3  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL4  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL5  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL6  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL7  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL8  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL9  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL10 : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL11 : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL12 : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL13 : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL0     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL1     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL2     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL3     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL4     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL5     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL6     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL7     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL8     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL9     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL10    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL11    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL12    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL13    : out std_logic_vector(31 downto 0);

        CNT_NBIOT1_TERMINATION      : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL13   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_UPPKT_SYMBOL13   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL0  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL1  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL2  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL3  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL4  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL5  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL6  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL7  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL8  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL9  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL10 : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL11 : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL12 : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL13 : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL0     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL1     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL2     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL3     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL4     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL5     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL6     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL7     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL8     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL9     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL10    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL11    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL12    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL13    : out std_logic_vector(31 downto 0);

        CNT_NBIOT2_TERMINATION      : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL13   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_UPPKT_SYMBOL13   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL0  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL1  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL2  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL3  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL4  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL5  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL6  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL7  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL8  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL9  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL10 : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL11 : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL12 : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL13 : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL0     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL1     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL2     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL3     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL4     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL5     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL6     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL7     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL8     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL9     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL10    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL11    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL12    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL13    : out std_logic_vector(31 downto 0);

--------------------------------------------------------------------------------
-- DL/UL C-Plane (Not decoded)
--------------------------------------------------------------------------------

        C_PLANE_VALID               : in  std_logic;
        C_PLANE_LAST                : in  std_logic;
        C_PLANE_KEEP                : in  std_logic_vector(3 downto 0);
        C_PLANE_DATA                : in  std_logic_vector(31 downto 0);
        C_PLANE_CH                  : in  std_logic_vector(2 downto 0);
        C_PLANE_CH_SUB              : in  std_logic_vector(3 downto 0);

        FREQ_OFFSET_FOR_PRACH_0     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_1     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_2     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_3     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_4     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_5     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_6     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_PRACH_7     : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_0      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_1      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_2      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_3      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_4      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_5      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_6      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_eMTC_7      : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_0    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_1    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_2    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_3    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_4    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_5    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_6    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPRACH_7    : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_0   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_1   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_2   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_3   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_4   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_5   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_6   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0_7   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_0   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_1   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_2   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_3   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_4   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_5   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_6   : in  std_logic_vector(23 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1_7   : in  std_logic_vector(23 downto 0);

--------------------------------------------------------------------------------
-- ULFE (LTE)
--------------------------------------------------------------------------------

        ULFE_FRAME_ID               : in  std_logic_vector(7 downto 0);
        ULFE_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        ULFE_SLOT_ID                : in  std_logic_vector(5 downto 0);
        ULFE_SYMBOL_ID              : in  std_logic_vector(5 downto 0);
        ULFE_START_RE               : in  std_logic_vector(15 downto 0);

        ULFE_VALID                  : in  std_logic_vector(7 downto 0);
        ULFE_START                  : in  std_logic_vector(7 downto 0);
        ULFE_LAST                   : in  std_logic_vector(7 downto 0);
        ULFE_DATA_I                 : in  std_logic_array16(7 downto 0);
        ULFE_DATA_Q                 : in  std_logic_array16(7 downto 0);

--------------------------------------------------------------------------------
-- RAFE (LTE)
--------------------------------------------------------------------------------

        RAFE_FRAME_ID               : in  std_logic_vector(7 downto 0);
        RAFE_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        RAFE_SLOT_ID                : in  std_logic_vector(5 downto 0);
        RAFE_SYMBOL_ID              : in  std_logic_vector(5 downto 0);
        RAFE_START_RE               : in  std_logic_vector(15 downto 0);

        RAFE_VALID                  : in  std_logic_vector(7 downto 0);
        RAFE_START                  : in  std_logic_vector(7 downto 0);
        RAFE_LAST                   : in  std_logic_vector(7 downto 0);
        RAFE_DATA_I                 : in  std_logic_array16(7 downto 0);
        RAFE_DATA_Q                 : in  std_logic_array16(7 downto 0);

--------------------------------------------------------------------------------
-- eMTC (PRACH)
--------------------------------------------------------------------------------

        eMTC_FRAME_ID               : in  std_logic_vector(7 downto 0);
        eMTC_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        eMTC_SLOT_ID                : in  std_logic_vector(5 downto 0);
        eMTC_SYMBOL_ID              : in  std_logic_vector(5 downto 0);
        eMTC_START_RE               : in  std_logic_vector(15 downto 0);

        eMTC_VALID                  : in  std_logic_vector(7 downto 0);
        eMTC_START                  : in  std_logic_vector(7 downto 0);
        eMTC_LAST                   : in  std_logic_vector(7 downto 0);
        eMTC_DATA_I                 : in  std_logic_array16(7 downto 0);
        eMTC_DATA_Q                 : in  std_logic_array16(7 downto 0);

--------------------------------------------------------------------------------
-- NBFE#0 (NPUSCH, anchor)
--------------------------------------------------------------------------------

        NBFE0_FRAME_ID              : in  std_logic_vector(7 downto 0);
        NBFE0_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        NBFE0_SLOT_ID               : in  std_logic_vector(5 downto 0);
        NBFE0_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        NBFE0_START_RE              : in  std_logic_vector(15 downto 0);

        NBFE0_VALID                 : in  std_logic_vector(7 downto 0);
        NBFE0_START                 : in  std_logic_vector(7 downto 0);
        NBFE0_LAST                  : in  std_logic_vector(7 downto 0);
        NBFE0_DATA_I                : in  std_logic_array16(7 downto 0);
        NBFE0_DATA_Q                : in  std_logic_array16(7 downto 0);

--------------------------------------------------------------------------------
-- NBFE#1 (NPUSCH, non-anchor)
--------------------------------------------------------------------------------

        NBFE1_FRAME_ID              : in  std_logic_vector(7 downto 0);
        NBFE1_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        NBFE1_SLOT_ID               : in  std_logic_vector(5 downto 0);
        NBFE1_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        NBFE1_START_RE              : in  std_logic_vector(15 downto 0);

        NBFE1_VALID                 : in  std_logic_vector(7 downto 0);
        NBFE1_START                 : in  std_logic_vector(7 downto 0);
        NBFE1_LAST                  : in  std_logic_vector(7 downto 0);
        NBFE1_DATA_I                : in  std_logic_array16(7 downto 0);
        NBFE1_DATA_Q                : in  std_logic_array16(7 downto 0);

--------------------------------------------------------------------------------
-- NBFE#2 (NPRACH)
--------------------------------------------------------------------------------

        NBFE2_FRAME_ID              : in  std_logic_vector(7 downto 0);
        NBFE2_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        NBFE2_SLOT_ID               : in  std_logic_vector(5 downto 0);
        NBFE2_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        NBFE2_START_RE              : in  std_logic_vector(15 downto 0);

        NBFE2_VALID                 : in  std_logic_vector(7 downto 0);
        NBFE2_START                 : in  std_logic_vector(7 downto 0);
        NBFE2_LAST                  : in  std_logic_vector(7 downto 0);
        NBFE2_DATA_I                : in  std_logic_array16(7 downto 0);
        NBFE2_DATA_Q                : in  std_logic_array16(7 downto 0);

--------------------------------------------------------------------------------
-- UL U-Plane (Not encoded)
--------------------------------------------------------------------------------

        PUxCH_RB_INIT               : out std_logic;
        PUxCH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PUxCH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PUxCH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_APP_ACK     : in  std_logic;
        PUxCH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_SEC_ACK     : in  std_logic;

        PUxCH_RB_COMP_HDR           : out std_logic_vector(7 downto 0);

        PUxCH_RB_VALID              : out std_logic;
        PUxCH_RB_TICK               : out std_logic;
        PUxCH_RB_DATA_I             : out std_logic_vector(15 downto 0);
        PUxCH_RB_DATA_Q             : out std_logic_vector(15 downto 0);
        PUxCH_RB_USER               : out std_logic_vector(15 downto 0);

        PRACH_RB_INIT               : out std_logic;
        PRACH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PRACH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PRACH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_APP_ACK     : in  std_logic;
        PRACH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_SEC_ACK     : in  std_logic;

        PRACH_RB_COMP_HDR           : out std_logic_vector(7 downto 0);

        PRACH_RB_VALID              : out std_logic;
        PRACH_RB_TICK               : out std_logic;
        PRACH_RB_DATA_I             : out std_logic_vector(15 downto 0);
        PRACH_RB_DATA_Q             : out std_logic_vector(15 downto 0);
        PRACH_RB_USER               : out std_logic_vector(15 downto 0);

        eMTC_RB_INIT                : out std_logic;
        eMTC_RB_eAxC_ID             : out std_logic_vector(15 downto 0);
        eMTC_RB_SEQUENCE_ID         : out std_logic_vector(15 downto 0);
        eMTC_RB_HEADER_APP          : out std_logic_vector(31 downto 0);
        eMTC_RB_HEADER_APP_ACK      : in  std_logic;
        eMTC_RB_HEADER_SEC          : out std_logic_vector(31 downto 0);
        eMTC_RB_HEADER_SEC_ACK      : in  std_logic;

        eMTC_RB_COMP_HDR            : out std_logic_vector(7 downto 0);

        eMTC_RB_VALID               : out std_logic;
        eMTC_RB_TICK                : out std_logic;
        eMTC_RB_DATA_I              : out std_logic_vector(15 downto 0);
        eMTC_RB_DATA_Q              : out std_logic_vector(15 downto 0);
        eMTC_RB_USER                : out std_logic_vector(15 downto 0);

        NBIOT0_RB_INIT              : out std_logic;
        NBIOT0_RB_eAxC_ID           : out std_logic_vector(15 downto 0);
        NBIOT0_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);
        NBIOT0_RB_HEADER_APP        : out std_logic_vector(31 downto 0);
        NBIOT0_RB_HEADER_APP_ACK    : in  std_logic;
        NBIOT0_RB_HEADER_SEC        : out std_logic_vector(31 downto 0);
        NBIOT0_RB_HEADER_SEC_ACK    : in  std_logic;

        NBIOT0_RB_COMP_HDR          : out std_logic_vector(7 downto 0);

        NBIOT0_RB_VALID             : out std_logic;
        NBIOT0_RB_TICK              : out std_logic;
        NBIOT0_RB_DATA_I            : out std_logic_vector(15 downto 0);
        NBIOT0_RB_DATA_Q            : out std_logic_vector(15 downto 0);
        NBIOT0_RB_USER              : out std_logic_vector(15 downto 0);

        NBIOT1_RB_INIT              : out std_logic;
        NBIOT1_RB_eAxC_ID           : out std_logic_vector(15 downto 0);
        NBIOT1_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);
        NBIOT1_RB_HEADER_APP        : out std_logic_vector(31 downto 0);
        NBIOT1_RB_HEADER_APP_ACK    : in  std_logic;
        NBIOT1_RB_HEADER_SEC        : out std_logic_vector(31 downto 0);
        NBIOT1_RB_HEADER_SEC_ACK    : in  std_logic;

        NBIOT1_RB_COMP_HDR          : out std_logic_vector(7 downto 0);

        NBIOT1_RB_VALID             : out std_logic;
        NBIOT1_RB_TICK              : out std_logic;
        NBIOT1_RB_DATA_I            : out std_logic_vector(15 downto 0);
        NBIOT1_RB_DATA_Q            : out std_logic_vector(15 downto 0);
        NBIOT1_RB_USER              : out std_logic_vector(15 downto 0);

        NBIOT2_RB_INIT              : out std_logic;
        NBIOT2_RB_eAxC_ID           : out std_logic_vector(15 downto 0);
        NBIOT2_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);
        NBIOT2_RB_HEADER_APP        : out std_logic_vector(31 downto 0);
        NBIOT2_RB_HEADER_APP_ACK    : in  std_logic;
        NBIOT2_RB_HEADER_SEC        : out std_logic_vector(31 downto 0);
        NBIOT2_RB_HEADER_SEC_ACK    : in  std_logic;

        NBIOT2_RB_COMP_HDR          : out std_logic_vector(7 downto 0);

        NBIOT2_RB_VALID             : out std_logic;
        NBIOT2_RB_TICK              : out std_logic;
        NBIOT2_RB_DATA_I            : out std_logic_vector(15 downto 0);
        NBIOT2_RB_DATA_Q            : out std_logic_vector(15 downto 0);
        NBIOT2_RB_USER              : out std_logic_vector(15 downto 0)
    );
end DATA_MANAGER_UL0;

architecture BEHAVE of DATA_MANAGER_UL0 is

    component RST_SYNC is
    generic (
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port (
        RST_IN                      : in  std_logic;
        CLK                         : in  std_logic;
        RST_OUT                     : out std_logic
    );
    end component;

    signal reset                    : std_logic;

    component UL_SCHEDULER0 is
    generic (
        LINK_DIRECTION              : std_logic := '0';
        MAX_SECTION_PUxCH           : natural := 256;
        MAX_SECTION_PRACH           : natural := 16;
        MAX_SECTION_eMTC            : natural := 16;
        MAX_SECTION_NBIOT0          : natural := 8;
        MAX_SECTION_NBIOT1          : natural := 8;
        MAX_SECTION_NBIOT2          : natural := 8;
        USAGE_TYPE0                 : boolean := true;
        USAGE_TYPE1                 : boolean := true;
        USAGE_TYPE3                 : boolean := true;
        USAGE_TYPE5                 : boolean := true;
        USAGE_TYPE6                 : boolean := true;
        USAGE_TYPE7                 : boolean := false
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        IGNORE_FRAME_ID             : in  std_logic;
        IGNORE_FRAME_ID_PUxCH_RX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_TX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT2_RX   : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT2_TX   : out std_logic_vector(7 downto 0);

        PUxCH_ID                    : in  std_logic_array16(7 downto 0);
        PRACH_ID                    : in  std_logic_array16(7 downto 0);
        NPUSCH_ID                   : in  std_logic_array16(7 downto 0);

        COMP_MODE                   : in  std_logic;
        IQ_WIDTH                    : in  std_logic_vector(3 downto 0);
        COMP_METHOD                 : in  std_logic_vector(3 downto 0);
        PRB_PER_SYMBOL              : in  std_logic_vector(9 downto 0);
        PRB_PER_MTU                 : in  std_logic_vector(9 downto 0);

        CNT_FIFO_FULL               : out std_logic_vector(31 downto 0);

        CNT_PUxCH_TERMINATION       : out std_logic_vector(31 downto 0);

        CNT_PUxCH_CPSEC_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL13    : out std_logic_vector(31 downto 0);

        CNT_PUxCH_CQ_FULL_SYMBOL0   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL1   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL2   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL3   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL4   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL5   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL6   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL7   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL8   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL9   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL10  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL11  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL12  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL13  : out std_logic_vector(31 downto 0);

        USAGE_PUxCH_CQ_SYMBOL0      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL1      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL2      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL3      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL4      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL5      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL6      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL7      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL8      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL9      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL10     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL11     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL12     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL13     : out std_logic_vector(31 downto 0);

        CNT_PRACH_TERMINATION       : out std_logic_vector(31 downto 0);

        CNT_PRACH_CPSEC_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL13    : out std_logic_vector(31 downto 0);

        CNT_PRACH_CQ_FULL_SYMBOL0   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL1   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL2   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL3   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL4   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL5   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL6   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL7   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL8   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL9   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL10  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL11  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL12  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL13  : out std_logic_vector(31 downto 0);

        USAGE_PRACH_CQ_SYMBOL0      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL1      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL2      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL3      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL4      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL5      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL6      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL7      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL8      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL9      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL10     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL11     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL12     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL13     : out std_logic_vector(31 downto 0);

        CNT_eMTC_TERMINATION        : out std_logic_vector(31 downto 0);

        CNT_eMTC_CPSEC_SYMBOL0      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL1      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL2      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL3      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL4      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL5      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL6      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL7      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL8      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL9      : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL10     : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL11     : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL12     : out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL13     : out std_logic_vector(31 downto 0);

        CNT_eMTC_CQ_FULL_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL13   : out std_logic_vector(31 downto 0);

        USAGE_eMTC_CQ_SYMBOL0       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL1       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL2       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL3       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL4       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL5       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL6       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL7       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL8       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL9       : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL10      : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL11      : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL12      : out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL13      : out std_logic_vector(31 downto 0);

        CNT_NBIOT0_TERMINATION      : out std_logic_vector(31 downto 0);

        CNT_NBIOT0_CPSEC_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL13   : out std_logic_vector(31 downto 0);

        CNT_NBIOT0_CQ_FULL_SYMBOL0  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL1  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL2  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL3  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL4  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL5  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL6  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL7  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL8  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL9  : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL10 : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL11 : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL12 : out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL13 : out std_logic_vector(31 downto 0);

        USAGE_NBIOT0_CQ_SYMBOL0     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL1     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL2     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL3     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL4     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL5     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL6     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL7     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL8     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL9     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL10    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL11    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL12    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL13    : out std_logic_vector(31 downto 0);

        CNT_NBIOT1_TERMINATION      : out std_logic_vector(31 downto 0);

        CNT_NBIOT1_CPSEC_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL13   : out std_logic_vector(31 downto 0);

        CNT_NBIOT1_CQ_FULL_SYMBOL0  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL1  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL2  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL3  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL4  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL5  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL6  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL7  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL8  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL9  : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL10 : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL11 : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL12 : out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL13 : out std_logic_vector(31 downto 0);

        USAGE_NBIOT1_CQ_SYMBOL0     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL1     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL2     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL3     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL4     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL5     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL6     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL7     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL8     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL9     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL10    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL11    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL12    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL13    : out std_logic_vector(31 downto 0);

        CNT_NBIOT2_TERMINATION      : out std_logic_vector(31 downto 0);

        CNT_NBIOT2_CPSEC_SYMBOL0    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL1    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL2    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL3    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL4    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL5    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL6    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL7    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL8    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL9    : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL10   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL11   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL12   : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL13   : out std_logic_vector(31 downto 0);

        CNT_NBIOT2_CQ_FULL_SYMBOL0  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL1  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL2  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL3  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL4  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL5  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL6  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL7  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL8  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL9  : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL10 : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL11 : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL12 : out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL13 : out std_logic_vector(31 downto 0);

        USAGE_NBIOT2_CQ_SYMBOL0     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL1     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL2     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL3     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL4     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL5     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL6     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL7     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL8     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL9     : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL10    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL11    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL12    : out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL13    : out std_logic_vector(31 downto 0);

        C_PLANE_VALID               : in  std_logic;
        C_PLANE_LAST                : in  std_logic;
        C_PLANE_KEEP                : in  std_logic_vector(3 downto 0);
        C_PLANE_DATA                : in  std_logic_vector(31 downto 0);
        C_PLANE_CH                  : in  std_logic_vector(2 downto 0);
        C_PLANE_CH_SUB              : in  std_logic_vector(3 downto 0);

        FREQ_OFFSET_FOR_PRACH       : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_eMTC        : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPRACH      : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0     : in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1     : in  std_logic_array24(7 downto 0);

        ULFE_UPDATE                 : in  std_logic;

        ULFE_FRAME_ID               : in  std_logic_vector(7 downto 0);
        ULFE_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        ULFE_SLOT_ID                : in  std_logic_vector(5 downto 0);
        ULFE_SYMBOL_ID              : in  std_logic_vector(5 downto 0);

        PUxCH_INIT                  : out std_logic;
        PUxCH_PACKING_TICK          : out std_logic_vector(3 downto 0);

        PUxCH_RTCPC_ID              : out std_logic_vector(15 downto 0);

        PUxCH_DATA_DIRECTION        : out std_logic;
        PUxCH_PAYLOAD_VERSION       : out std_logic_vector(2 downto 0);
        PUxCH_FILTER_INDEX          : out std_logic_vector(3 downto 0);
        PUxCH_FRAME_ID              : out std_logic_vector(7 downto 0);
        PUxCH_SUBFRAME_ID           : out std_logic_vector(3 downto 0);
        PUxCH_SLOT_ID               : out std_logic_vector(5 downto 0);
        PUxCH_SYMBOL_ID             : out std_logic_vector(5 downto 0);

        PUxCH_SECTION_TICK          : out std_logic_vector(3 downto 0);
        PUxCH_SECTION_LAST          : out std_logic_vector(3 downto 0);
        PUxCH_SECTION_DONE          : in  std_logic_vector(3 downto 0);

        PUxCH_SECTION_ID            : out std_logic_vector(11 downto 0);
        PUxCH_USE_EVERY_PRB         : out std_logic;
        PUxCH_START_OF_PRB          : out std_logic_vector(9 downto 0);
        PUxCH_OFFSET_OF_PRB         : out std_logic_vector(9 downto 0);
        PUxCH_NUMBER_OF_PRB         : out std_logic_vector(9 downto 0);
        PUxCH_UD_COMP_HDR           : out std_logic_vector(7 downto 0);

        RAFE0_UPDATE                : in  std_logic;

        RAFE0_FRAME_ID              : in  std_logic_vector(7 downto 0);
        RAFE0_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        RAFE0_SLOT_ID               : in  std_logic_vector(5 downto 0);
        RAFE0_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        RAFE0_CHANNEL_ID            : in  std_logic_vector(2 downto 0);

        PRACH_INIT                  : out std_logic;
        PRACH_PACKING_TICK          : out std_logic_vector(3 downto 0);

        PRACH_RTCPC_ID              : out std_logic_vector(15 downto 0);

        PRACH_DATA_DIRECTION        : out std_logic;
        PRACH_PAYLOAD_VERSION       : out std_logic_vector(2 downto 0);
        PRACH_FILTER_INDEX          : out std_logic_vector(3 downto 0);
        PRACH_FRAME_ID              : out std_logic_vector(7 downto 0);
        PRACH_SUBFRAME_ID           : out std_logic_vector(3 downto 0);
        PRACH_SLOT_ID               : out std_logic_vector(5 downto 0);
        PRACH_SYMBOL_ID             : out std_logic_vector(5 downto 0);

        PRACH_SECTION_TICK          : out std_logic_vector(3 downto 0);
        PRACH_SECTION_LAST          : out std_logic_vector(3 downto 0);
        PRACH_SECTION_DONE          : in  std_logic_vector(3 downto 0);

        PRACH_SECTION_ID            : out std_logic_vector(11 downto 0);
        PRACH_USE_EVERY_PRB         : out std_logic;
        PRACH_START_OF_PRB          : out std_logic_vector(9 downto 0);
        PRACH_OFFSET_OF_PRB         : out std_logic_vector(9 downto 0);
        PRACH_NUMBER_OF_PRB         : out std_logic_vector(9 downto 0);
        PRACH_UD_COMP_HDR           : out std_logic_vector(7 downto 0);

        RAFE1_UPDATE                : in  std_logic;

        RAFE1_FRAME_ID              : in  std_logic_vector(7 downto 0);
        RAFE1_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        RAFE1_SLOT_ID               : in  std_logic_vector(5 downto 0);
        RAFE1_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        RAFE1_CHANNEL_ID            : in  std_logic_vector(2 downto 0);

        eMTC_INIT                   : out std_logic;
        eMTC_PACKING_TICK           : out std_logic_vector(3 downto 0);

        eMTC_RTCPC_ID               : out std_logic_vector(15 downto 0);

        eMTC_DATA_DIRECTION         : out std_logic;
        eMTC_PAYLOAD_VERSION        : out std_logic_vector(2 downto 0);
        eMTC_FILTER_INDEX           : out std_logic_vector(3 downto 0);
        eMTC_FRAME_ID               : out std_logic_vector(7 downto 0);
        eMTC_SUBFRAME_ID            : out std_logic_vector(3 downto 0);
        eMTC_SLOT_ID                : out std_logic_vector(5 downto 0);
        eMTC_SYMBOL_ID              : out std_logic_vector(5 downto 0);

        eMTC_SECTION_TICK           : out std_logic_vector(3 downto 0);
        eMTC_SECTION_LAST           : out std_logic_vector(3 downto 0);
        eMTC_SECTION_DONE           : in  std_logic_vector(3 downto 0);

        eMTC_SECTION_ID             : out std_logic_vector(11 downto 0);
        eMTC_USE_EVERY_PRB          : out std_logic;
        eMTC_START_OF_PRB           : out std_logic_vector(9 downto 0);
        eMTC_OFFSET_OF_PRB          : out std_logic_vector(9 downto 0);
        eMTC_NUMBER_OF_PRB          : out std_logic_vector(9 downto 0);
        eMTC_UD_COMP_HDR            : out std_logic_vector(7 downto 0);

        NBFE0_UPDATE                : in  std_logic;

        NBFE0_FRAME_ID              : in  std_logic_vector(7 downto 0);
        NBFE0_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        NBFE0_SLOT_ID               : in  std_logic_vector(5 downto 0);
        NBFE0_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        NBFE0_CHANNEL_ID            : in  std_logic_vector(2 downto 0);

        NBIOT0_INIT                 : out std_logic;
        NBIOT0_PACKING_TICK         : out std_logic_vector(3 downto 0);

        NBIOT0_RTCPC_ID             : out std_logic_vector(15 downto 0);

        NBIOT0_DATA_DIRECTION       : out std_logic;
        NBIOT0_PAYLOAD_VERSION      : out std_logic_vector(2 downto 0);
        NBIOT0_FILTER_INDEX         : out std_logic_vector(3 downto 0);
        NBIOT0_FRAME_ID             : out std_logic_vector(7 downto 0);
        NBIOT0_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        NBIOT0_SLOT_ID              : out std_logic_vector(5 downto 0);
        NBIOT0_SYMBOL_ID            : out std_logic_vector(5 downto 0);

        NBIOT0_SECTION_TICK         : out std_logic_vector(3 downto 0);
        NBIOT0_SECTION_LAST         : out std_logic_vector(3 downto 0);
        NBIOT0_SECTION_DONE         : in  std_logic_vector(3 downto 0);

        NBIOT0_SECTION_ID           : out std_logic_vector(11 downto 0);
        NBIOT0_USE_EVERY_PRB        : out std_logic;
        NBIOT0_START_OF_PRB         : out std_logic_vector(9 downto 0);
        NBIOT0_OFFSET_OF_PRB        : out std_logic_vector(9 downto 0);
        NBIOT0_NUMBER_OF_PRB        : out std_logic_vector(9 downto 0);
        NBIOT0_UD_COMP_HDR          : out std_logic_vector(7 downto 0);

        NBFE1_UPDATE                : in  std_logic;

        NBFE1_FRAME_ID              : in  std_logic_vector(7 downto 0);
        NBFE1_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        NBFE1_SLOT_ID               : in  std_logic_vector(5 downto 0);
        NBFE1_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        NBFE1_CHANNEL_ID            : in  std_logic_vector(2 downto 0);

        NBIOT1_INIT                 : out std_logic;
        NBIOT1_PACKING_TICK         : out std_logic_vector(3 downto 0);

        NBIOT1_RTCPC_ID             : out std_logic_vector(15 downto 0);

        NBIOT1_DATA_DIRECTION       : out std_logic;
        NBIOT1_PAYLOAD_VERSION      : out std_logic_vector(2 downto 0);
        NBIOT1_FILTER_INDEX         : out std_logic_vector(3 downto 0);
        NBIOT1_FRAME_ID             : out std_logic_vector(7 downto 0);
        NBIOT1_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        NBIOT1_SLOT_ID              : out std_logic_vector(5 downto 0);
        NBIOT1_SYMBOL_ID            : out std_logic_vector(5 downto 0);

        NBIOT1_SECTION_TICK         : out std_logic_vector(3 downto 0);
        NBIOT1_SECTION_LAST         : out std_logic_vector(3 downto 0);
        NBIOT1_SECTION_DONE         : in  std_logic_vector(3 downto 0);

        NBIOT1_SECTION_ID           : out std_logic_vector(11 downto 0);
        NBIOT1_USE_EVERY_PRB        : out std_logic;
        NBIOT1_START_OF_PRB         : out std_logic_vector(9 downto 0);
        NBIOT1_OFFSET_OF_PRB        : out std_logic_vector(9 downto 0);
        NBIOT1_NUMBER_OF_PRB        : out std_logic_vector(9 downto 0);
        NBIOT1_UD_COMP_HDR          : out std_logic_vector(7 downto 0);

        NBFE2_UPDATE                : in  std_logic;

        NBFE2_FRAME_ID              : in  std_logic_vector(7 downto 0);
        NBFE2_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        NBFE2_SLOT_ID               : in  std_logic_vector(5 downto 0);
        NBFE2_SYMBOL_ID             : in  std_logic_vector(5 downto 0);
        NBFE2_CHANNEL_ID            : in  std_logic_vector(2 downto 0);

        NBIOT2_INIT                 : out std_logic;
        NBIOT2_PACKING_TICK         : out std_logic_vector(3 downto 0);

        NBIOT2_RTCPC_ID             : out std_logic_vector(15 downto 0);

        NBIOT2_DATA_DIRECTION       : out std_logic;
        NBIOT2_PAYLOAD_VERSION      : out std_logic_vector(2 downto 0);
        NBIOT2_FILTER_INDEX         : out std_logic_vector(3 downto 0);
        NBIOT2_FRAME_ID             : out std_logic_vector(7 downto 0);
        NBIOT2_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        NBIOT2_SLOT_ID              : out std_logic_vector(5 downto 0);
        NBIOT2_SYMBOL_ID            : out std_logic_vector(5 downto 0);

        NBIOT2_SECTION_TICK         : out std_logic_vector(3 downto 0);
        NBIOT2_SECTION_LAST         : out std_logic_vector(3 downto 0);
        NBIOT2_SECTION_DONE         : in  std_logic_vector(3 downto 0);

        NBIOT2_SECTION_ID           : out std_logic_vector(11 downto 0);
        NBIOT2_USE_EVERY_PRB        : out std_logic;
        NBIOT2_START_OF_PRB         : out std_logic_vector(9 downto 0);
        NBIOT2_OFFSET_OF_PRB        : out std_logic_vector(9 downto 0);
        NBIOT2_NUMBER_OF_PRB        : out std_logic_vector(9 downto 0);
        NBIOT2_UD_COMP_HDR          : out std_logic_vector(7 downto 0)
    );
    end component;

    signal freq_offset_for_prach    : std_logic_array24(7 downto 0);
    signal freq_offset_for_emtc     : std_logic_array24(7 downto 0);
    signal freq_offset_for_nprach   : std_logic_array24(7 downto 0);
    signal freq_offset_for_npusch0  : std_logic_array24(7 downto 0);
    signal freq_offset_for_npusch1  : std_logic_array24(7 downto 0);

    signal puxch_update             : std_logic;
    signal puxch_init               : std_logic;
    signal puxch_packing_tick       : std_logic_vector(3 downto 0);
    signal puxch_rtcpc_id           : std_logic_vector(15 downto 0);
    signal puxch_data_direction     : std_logic;
    signal puxch_payload_version    : std_logic_vector(2 downto 0);
    signal puxch_filter_index       : std_logic_vector(3 downto 0);
    signal puxch_frame_id           : std_logic_vector(7 downto 0);
    signal puxch_subframe_id        : std_logic_vector(3 downto 0);
    signal puxch_slot_id            : std_logic_vector(5 downto 0);
    signal puxch_symbol_id          : std_logic_vector(5 downto 0);
    signal puxch_section_tick       : std_logic_vector(3 downto 0);
    signal puxch_section_last       : std_logic_vector(3 downto 0);
    signal puxch_section_done       : std_logic_vector(3 downto 0);
    signal puxch_section_id         : std_logic_vector(11 downto 0);
    signal puxch_use_every_prb      : std_logic;
    signal puxch_start_of_prb       : std_logic_vector(9 downto 0);
--    signal puxch_offset_of_prb      : std_logic_vector(9 downto 0);
    signal puxch_number_of_prb      : std_logic_vector(9 downto 0);
    signal puxch_ud_comp_hdr        : std_logic_vector(7 downto 0);

    signal prach0_update            : std_logic;
    signal prach0_init              : std_logic;
    signal prach0_channel_id        : std_logic_vector(2 downto 0);
    signal prach0_packing_tick      : std_logic_vector(3 downto 0);
    signal prach0_rtcpc_id          : std_logic_vector(15 downto 0);
    signal prach0_data_direction    : std_logic;
    signal prach0_payload_version   : std_logic_vector(2 downto 0);
    signal prach0_filter_index      : std_logic_vector(3 downto 0);
    signal prach0_frame_id          : std_logic_vector(7 downto 0);
    signal prach0_subframe_id       : std_logic_vector(3 downto 0);
    signal prach0_slot_id           : std_logic_vector(5 downto 0);
    signal prach0_symbol_id         : std_logic_vector(5 downto 0);
    signal prach0_section_tick      : std_logic_vector(3 downto 0);
    signal prach0_section_last      : std_logic_vector(3 downto 0);
    signal prach0_section_done      : std_logic_vector(3 downto 0);
    signal prach0_section_id        : std_logic_vector(11 downto 0);
    signal prach0_use_every_prb     : std_logic;
    signal prach0_start_of_prb      : std_logic_vector(9 downto 0);
    signal prach0_offset_of_prb     : std_logic_vector(9 downto 0);
    signal prach0_number_of_prb     : std_logic_vector(9 downto 0);
    signal prach0_ud_comp_hdr       : std_logic_vector(7 downto 0);

    signal prach1_update            : std_logic;
    signal prach1_init              : std_logic;
    signal prach1_channel_id        : std_logic_vector(2 downto 0);
    signal prach1_packing_tick      : std_logic_vector(3 downto 0);
    signal prach1_rtcpc_id          : std_logic_vector(15 downto 0);
    signal prach1_data_direction    : std_logic;
    signal prach1_payload_version   : std_logic_vector(2 downto 0);
    signal prach1_filter_index      : std_logic_vector(3 downto 0);
    signal prach1_frame_id          : std_logic_vector(7 downto 0);
    signal prach1_subframe_id       : std_logic_vector(3 downto 0);
    signal prach1_slot_id           : std_logic_vector(5 downto 0);
    signal prach1_symbol_id         : std_logic_vector(5 downto 0);
    signal prach1_section_tick      : std_logic_vector(3 downto 0);
    signal prach1_section_last      : std_logic_vector(3 downto 0);
    signal prach1_section_done      : std_logic_vector(3 downto 0);
    signal prach1_section_id        : std_logic_vector(11 downto 0);
    signal prach1_use_every_prb     : std_logic;
    signal prach1_start_of_prb      : std_logic_vector(9 downto 0);
    signal prach1_offset_of_prb     : std_logic_vector(9 downto 0);
    signal prach1_number_of_prb     : std_logic_vector(9 downto 0);
    signal prach1_ud_comp_hdr       : std_logic_vector(7 downto 0);

    signal nbiot0_update            : std_logic;
    signal nbiot0_init              : std_logic;
    signal nbiot0_channel_id        : std_logic_vector(2 downto 0);
    signal nbiot0_packing_tick      : std_logic_vector(3 downto 0);
    signal nbiot0_rtcpc_id          : std_logic_vector(15 downto 0);
    signal nbiot0_data_direction    : std_logic;
    signal nbiot0_payload_version   : std_logic_vector(2 downto 0);
    signal nbiot0_filter_index      : std_logic_vector(3 downto 0);
    signal nbiot0_frame_id          : std_logic_vector(7 downto 0);
    signal nbiot0_subframe_id       : std_logic_vector(3 downto 0);
    signal nbiot0_slot_id           : std_logic_vector(5 downto 0);
    signal nbiot0_symbol_id         : std_logic_vector(5 downto 0);
    signal nbiot0_section_tick      : std_logic_vector(3 downto 0);
    signal nbiot0_section_last      : std_logic_vector(3 downto 0);
    signal nbiot0_section_done      : std_logic_vector(3 downto 0);
    signal nbiot0_section_id        : std_logic_vector(11 downto 0);
    signal nbiot0_use_every_prb     : std_logic;
    signal nbiot0_start_of_prb      : std_logic_vector(9 downto 0);
    signal nbiot0_offset_of_prb     : std_logic_vector(9 downto 0);
    signal nbiot0_number_of_prb     : std_logic_vector(9 downto 0);
    signal nbiot0_ud_comp_hdr       : std_logic_vector(7 downto 0);

    signal nbiot1_update            : std_logic;
    signal nbiot1_init              : std_logic;
    signal nbiot1_channel_id        : std_logic_vector(2 downto 0);
    signal nbiot1_packing_tick      : std_logic_vector(3 downto 0);
    signal nbiot1_rtcpc_id          : std_logic_vector(15 downto 0);
    signal nbiot1_data_direction    : std_logic;
    signal nbiot1_payload_version   : std_logic_vector(2 downto 0);
    signal nbiot1_filter_index      : std_logic_vector(3 downto 0);
    signal nbiot1_frame_id          : std_logic_vector(7 downto 0);
    signal nbiot1_subframe_id       : std_logic_vector(3 downto 0);
    signal nbiot1_slot_id           : std_logic_vector(5 downto 0);
    signal nbiot1_symbol_id         : std_logic_vector(5 downto 0);
    signal nbiot1_section_tick      : std_logic_vector(3 downto 0);
    signal nbiot1_section_last      : std_logic_vector(3 downto 0);
    signal nbiot1_section_done      : std_logic_vector(3 downto 0);
    signal nbiot1_section_id        : std_logic_vector(11 downto 0);
    signal nbiot1_use_every_prb     : std_logic;
    signal nbiot1_start_of_prb      : std_logic_vector(9 downto 0);
    signal nbiot1_offset_of_prb     : std_logic_vector(9 downto 0);
    signal nbiot1_number_of_prb     : std_logic_vector(9 downto 0);
    signal nbiot1_ud_comp_hdr       : std_logic_vector(7 downto 0);

    signal nbiot2_update            : std_logic;
    signal nbiot2_init              : std_logic;
    signal nbiot2_channel_id        : std_logic_vector(2 downto 0);
    signal nbiot2_packing_tick      : std_logic_vector(3 downto 0);
    signal nbiot2_rtcpc_id          : std_logic_vector(15 downto 0);
    signal nbiot2_data_direction    : std_logic;
    signal nbiot2_payload_version   : std_logic_vector(2 downto 0);
    signal nbiot2_filter_index      : std_logic_vector(3 downto 0);
    signal nbiot2_frame_id          : std_logic_vector(7 downto 0);
    signal nbiot2_subframe_id       : std_logic_vector(3 downto 0);
    signal nbiot2_slot_id           : std_logic_vector(5 downto 0);
    signal nbiot2_symbol_id         : std_logic_vector(5 downto 0);
    signal nbiot2_section_tick      : std_logic_vector(3 downto 0);
    signal nbiot2_section_last      : std_logic_vector(3 downto 0);
    signal nbiot2_section_done      : std_logic_vector(3 downto 0);
    signal nbiot2_section_id        : std_logic_vector(11 downto 0);
    signal nbiot2_use_every_prb     : std_logic;
    signal nbiot2_start_of_prb      : std_logic_vector(9 downto 0);
    signal nbiot2_offset_of_prb     : std_logic_vector(9 downto 0);
    signal nbiot2_number_of_prb     : std_logic_vector(9 downto 0);
    signal nbiot2_ud_comp_hdr       : std_logic_vector(7 downto 0);

    component UL_PARAM0 is
    generic (
        MAX_CH                      : natural := 8
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        PUxCH_INIT                  : in  std_logic;
        PUxCH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_RTCPC_ID              : in  std_logic_vector(15 downto 0);

        PUxCH_DATA_DIRECTION        : in  std_logic;
        PUxCH_PAYLOAD_VERSION       : in  std_logic_vector(2 downto 0);
        PUxCH_FILTER_INDEX          : in  std_logic_vector(3 downto 0);
        PUxCH_FRAME_ID              : in  std_logic_vector(7 downto 0);
        PUxCH_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        PUxCH_SLOT_ID               : in  std_logic_vector(5 downto 0);
        PUxCH_SYMBOL_ID             : in  std_logic_vector(5 downto 0);

        PUxCH_SECTION_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_SECTION_ID            : in  std_logic_vector(11 downto 0);
        PUxCH_USE_EVERY_PRB         : in  std_logic;
        PUxCH_START_OF_PRB          : in  std_logic_vector(9 downto 0);
        PUxCH_NUMBER_OF_PRB         : in  std_logic_vector(9 downto 0);

        PUxCH_RB_INIT               : out std_logic;
        PUxCH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PUxCH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PUxCH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_APP_ACK     : in  std_logic;
        PUxCH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_SEC_ACK     : in  std_logic;

        PRACH_INIT                  : in  std_logic;
        PRACH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PRACH_RTCPC_ID              : in  std_logic_vector(15 downto 0);

        PRACH_DATA_DIRECTION        : in  std_logic;
        PRACH_PAYLOAD_VERSION       : in  std_logic_vector(2 downto 0);
        PRACH_FILTER_INDEX          : in  std_logic_vector(3 downto 0);
        PRACH_FRAME_ID              : in  std_logic_vector(7 downto 0);
        PRACH_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        PRACH_SLOT_ID               : in  std_logic_vector(5 downto 0);
        PRACH_SYMBOL_ID             : in  std_logic_vector(5 downto 0);

        PRACH_SECTION_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PRACH_SECTION_ID            : in  std_logic_vector(11 downto 0);
        PRACH_USE_EVERY_PRB         : in  std_logic;
        PRACH_START_OF_PRB          : in  std_logic_vector(9 downto 0);
        PRACH_NUMBER_OF_PRB         : in  std_logic_vector(9 downto 0);

        PRACH_RB_INIT               : out std_logic;
        PRACH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PRACH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PRACH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_APP_ACK     : in  std_logic;
        PRACH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_SEC_ACK     : in  std_logic;

        eMTC_INIT                   : in  std_logic;
        eMTC_PACKING_TICK           : in  std_logic_vector(MAX_CH-1 downto 0);

        eMTC_RTCPC_ID               : in  std_logic_vector(15 downto 0);

        eMTC_DATA_DIRECTION         : in  std_logic;
        eMTC_PAYLOAD_VERSION        : in  std_logic_vector(2 downto 0);
        eMTC_FILTER_INDEX           : in  std_logic_vector(3 downto 0);
        eMTC_FRAME_ID               : in  std_logic_vector(7 downto 0);
        eMTC_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        eMTC_SLOT_ID                : in  std_logic_vector(5 downto 0);
        eMTC_SYMBOL_ID              : in  std_logic_vector(5 downto 0);

        eMTC_SECTION_TICK           : in  std_logic_vector(MAX_CH-1 downto 0);

        eMTC_SECTION_ID             : in  std_logic_vector(11 downto 0);
        eMTC_USE_EVERY_PRB          : in  std_logic;
        eMTC_START_OF_PRB           : in  std_logic_vector(9 downto 0);
        eMTC_NUMBER_OF_PRB          : in  std_logic_vector(9 downto 0);

        eMTC_RB_INIT                : out std_logic;
        eMTC_RB_eAxC_ID             : out std_logic_vector(15 downto 0);
        eMTC_RB_SEQUENCE_ID         : out std_logic_vector(15 downto 0);
        eMTC_RB_HEADER_APP          : out std_logic_vector(31 downto 0);
        eMTC_RB_HEADER_APP_ACK      : in  std_logic;
        eMTC_RB_HEADER_SEC          : out std_logic_vector(31 downto 0);
        eMTC_RB_HEADER_SEC_ACK      : in  std_logic;

        NBIOT0_INIT                 : in  std_logic;
        NBIOT0_PACKING_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT0_RTCPC_ID             : in  std_logic_vector(15 downto 0);

        NBIOT0_DATA_DIRECTION       : in  std_logic;
        NBIOT0_PAYLOAD_VERSION      : in  std_logic_vector(2 downto 0);
        NBIOT0_FILTER_INDEX         : in  std_logic_vector(3 downto 0);
        NBIOT0_FRAME_ID             : in  std_logic_vector(7 downto 0);
        NBIOT0_SUBFRAME_ID          : in  std_logic_vector(3 downto 0);
        NBIOT0_SLOT_ID              : in  std_logic_vector(5 downto 0);
        NBIOT0_SYMBOL_ID            : in  std_logic_vector(5 downto 0);

        NBIOT0_SECTION_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT0_SECTION_ID           : in  std_logic_vector(11 downto 0);
        NBIOT0_USE_EVERY_PRB        : in  std_logic;
        NBIOT0_START_OF_PRB         : in  std_logic_vector(9 downto 0);
        NBIOT0_NUMBER_OF_PRB        : in  std_logic_vector(9 downto 0);

        NBIOT0_RB_INIT              : out std_logic;
        NBIOT0_RB_eAxC_ID           : out std_logic_vector(15 downto 0);
        NBIOT0_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);
        NBIOT0_RB_HEADER_APP        : out std_logic_vector(31 downto 0);
        NBIOT0_RB_HEADER_APP_ACK    : in  std_logic;
        NBIOT0_RB_HEADER_SEC        : out std_logic_vector(31 downto 0);
        NBIOT0_RB_HEADER_SEC_ACK    : in  std_logic;

        NBIOT1_INIT                 : in  std_logic;
        NBIOT1_PACKING_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT1_RTCPC_ID             : in  std_logic_vector(15 downto 0);

        NBIOT1_DATA_DIRECTION       : in  std_logic;
        NBIOT1_PAYLOAD_VERSION      : in  std_logic_vector(2 downto 0);
        NBIOT1_FILTER_INDEX         : in  std_logic_vector(3 downto 0);
        NBIOT1_FRAME_ID             : in  std_logic_vector(7 downto 0);
        NBIOT1_SUBFRAME_ID          : in  std_logic_vector(3 downto 0);
        NBIOT1_SLOT_ID              : in  std_logic_vector(5 downto 0);
        NBIOT1_SYMBOL_ID            : in  std_logic_vector(5 downto 0);

        NBIOT1_SECTION_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT1_SECTION_ID           : in  std_logic_vector(11 downto 0);
        NBIOT1_USE_EVERY_PRB        : in  std_logic;
        NBIOT1_START_OF_PRB         : in  std_logic_vector(9 downto 0);
        NBIOT1_NUMBER_OF_PRB        : in  std_logic_vector(9 downto 0);

        NBIOT1_RB_INIT              : out std_logic;
        NBIOT1_RB_eAxC_ID           : out std_logic_vector(15 downto 0);
        NBIOT1_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);
        NBIOT1_RB_HEADER_APP        : out std_logic_vector(31 downto 0);
        NBIOT1_RB_HEADER_APP_ACK    : in  std_logic;
        NBIOT1_RB_HEADER_SEC        : out std_logic_vector(31 downto 0);
        NBIOT1_RB_HEADER_SEC_ACK    : in  std_logic;

        NBIOT2_INIT                 : in  std_logic;
        NBIOT2_PACKING_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT2_RTCPC_ID             : in  std_logic_vector(15 downto 0);

        NBIOT2_DATA_DIRECTION       : in  std_logic;
        NBIOT2_PAYLOAD_VERSION      : in  std_logic_vector(2 downto 0);
        NBIOT2_FILTER_INDEX         : in  std_logic_vector(3 downto 0);
        NBIOT2_FRAME_ID             : in  std_logic_vector(7 downto 0);
        NBIOT2_SUBFRAME_ID          : in  std_logic_vector(3 downto 0);
        NBIOT2_SLOT_ID              : in  std_logic_vector(5 downto 0);
        NBIOT2_SYMBOL_ID            : in  std_logic_vector(5 downto 0);

        NBIOT2_SECTION_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT2_SECTION_ID           : in  std_logic_vector(11 downto 0);
        NBIOT2_USE_EVERY_PRB        : in  std_logic;
        NBIOT2_START_OF_PRB         : in  std_logic_vector(9 downto 0);
        NBIOT2_NUMBER_OF_PRB        : in  std_logic_vector(9 downto 0);

        NBIOT2_RB_INIT              : out std_logic;
        NBIOT2_RB_eAxC_ID           : out std_logic_vector(15 downto 0);
        NBIOT2_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);
        NBIOT2_RB_HEADER_APP        : out std_logic_vector(31 downto 0);
        NBIOT2_RB_HEADER_APP_ACK    : in  std_logic;
        NBIOT2_RB_HEADER_SEC        : out std_logic_vector(31 downto 0);
        NBIOT2_RB_HEADER_SEC_ACK    : in  std_logic
    );
    end component;

    component UL_TX_WINDOW is
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        CNT_PACKET_SYMBOL0          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL1          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL2          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL3          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL4          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL5          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL6          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL7          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL8          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL9          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL10         : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL11         : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL12         : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL13         : out std_logic_vector(31 downto 0);

        PACKING_TICK                : in  std_logic;

        DATA_DIRECTION              : in  std_logic;
        PAYLOAD_VERSION             : in  std_logic_vector(2 downto 0);
        FILTER_INDEX                : in  std_logic_vector(3 downto 0);
        FRAME_ID                    : in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 : in  std_logic_vector(3 downto 0);
        SLOT_ID                     : in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   : in  std_logic_vector(5 downto 0);

        SECTION_TICK                : in  std_logic;
        SECTION_LAST                : in  std_logic;
        SECTION_DONE                : out std_logic;

        SECTION_ID                  : in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               : in  std_logic;
        START_OF_PRB                : in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               : in  std_logic_vector(9 downto 0);
        UD_COMP_HDR                 : in  std_logic_vector(7 downto 0);

        UL_FRAME_ID                 : in  std_logic_vector(7 downto 0);
        UL_SUBFRAME_ID              : in  std_logic_vector(3 downto 0);
        UL_SLOT_ID                  : in  std_logic_vector(5 downto 0);
        UL_SYMBOL_ID                : in  std_logic_vector(5 downto 0);
        UL_START_RE                 : in  std_logic_vector(15 downto 0);

        UL_VALID                    : in  std_logic;
        UL_START                    : in  std_logic;
        UL_LAST                     : in  std_logic;
        UL_DATA_I                   : in  std_logic_vector(15 downto 0);
        UL_DATA_Q                   : in  std_logic_vector(15 downto 0);

        RB_COMP_HDR                 : out std_logic_vector(7 downto 0);

        RB_VALID                    : out std_logic;
        RB_TICK                     : out std_logic;
        RB_DATA_I                   : out std_logic_vector(15 downto 0);
        RB_DATA_Q                   : out std_logic_vector(15 downto 0);
        RB_USER                     : out std_logic_vector(15 downto 0)
    );
    end component;

    component UL_TX_WINDOW_RACH is
    generic (
        LONG_PRACH                  : boolean := true
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        CNT_PACKET_SYMBOL0          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL1          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL2          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL3          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL4          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL5          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL6          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL7          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL8          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL9          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL10         : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL11         : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL12         : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL13         : out std_logic_vector(31 downto 0);

        PACKING_TICK                : in  std_logic;

        DATA_DIRECTION              : in  std_logic;
        PAYLOAD_VERSION             : in  std_logic_vector(2 downto 0);
        FILTER_INDEX                : in  std_logic_vector(3 downto 0);
        FRAME_ID                    : in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 : in  std_logic_vector(3 downto 0);
        SLOT_ID                     : in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   : in  std_logic_vector(5 downto 0);

        SECTION_TICK                : in  std_logic;
        SECTION_LAST                : in  std_logic;
        SECTION_DONE                : out std_logic;

        SECTION_ID                  : in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               : in  std_logic;
        START_OF_PRB                : in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               : in  std_logic_vector(9 downto 0);
        UD_COMP_HDR                 : in  std_logic_vector(7 downto 0);

        UL_FRAME_ID                 : in  std_logic_vector(7 downto 0);
        UL_SUBFRAME_ID              : in  std_logic_vector(3 downto 0);
        UL_SLOT_ID                  : in  std_logic_vector(5 downto 0);
        UL_SYMBOL_ID                : in  std_logic_vector(5 downto 0);
        UL_START_RE                 : in  std_logic_vector(15 downto 0);

        UL_VALID                    : in  std_logic;
        UL_START                    : in  std_logic;
        UL_LAST                     : in  std_logic;
        UL_DATA_I                   : in  std_logic_vector(15 downto 0);
        UL_DATA_Q                   : in  std_logic_vector(15 downto 0);

        RB_COMP_HDR                 : out std_logic_vector(7 downto 0);

        RB_VALID                    : out std_logic;
        RB_TICK                     : out std_logic;
        RB_DATA_I                   : out std_logic_vector(15 downto 0);
        RB_DATA_Q                   : out std_logic_vector(15 downto 0);
        RB_USER                     : out std_logic_vector(15 downto 0)
    );
    end component;

    component UL_TX_WINDOW_NBIOT is
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        CNT_PACKET_SYMBOL0          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL1          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL2          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL3          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL4          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL5          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL6          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL7          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL8          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL9          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL10         : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL11         : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL12         : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL13         : out std_logic_vector(31 downto 0);

        PACKING_TICK                : in  std_logic;

        DATA_DIRECTION              : in  std_logic;
        PAYLOAD_VERSION             : in  std_logic_vector(2 downto 0);
        FILTER_INDEX                : in  std_logic_vector(3 downto 0);
        FRAME_ID                    : in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 : in  std_logic_vector(3 downto 0);
        SLOT_ID                     : in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   : in  std_logic_vector(5 downto 0);

        SECTION_TICK                : in  std_logic;
        SECTION_LAST                : in  std_logic;
        SECTION_DONE                : out std_logic;

        SECTION_ID                  : in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               : in  std_logic;
        START_OF_PRB                : in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               : in  std_logic_vector(9 downto 0);
        UD_COMP_HDR                 : in  std_logic_vector(7 downto 0);

        UL_FRAME_ID                 : in  std_logic_vector(7 downto 0);
        UL_SUBFRAME_ID              : in  std_logic_vector(3 downto 0);
        UL_SLOT_ID                  : in  std_logic_vector(5 downto 0);
        UL_SYMBOL_ID                : in  std_logic_vector(5 downto 0);
        UL_START_RE                 : in  std_logic_vector(15 downto 0);

        UL_VALID                    : in  std_logic;
        UL_START                    : in  std_logic;
        UL_LAST                     : in  std_logic;
        UL_DATA_I                   : in  std_logic_vector(15 downto 0);
        UL_DATA_Q                   : in  std_logic_vector(15 downto 0);

        RB_COMP_HDR                 : out std_logic_vector(7 downto 0);

        RB_VALID                    : out std_logic;
        RB_TICK                     : out std_logic;
        RB_DATA_I                   : out std_logic_vector(15 downto 0);
        RB_DATA_Q                   : out std_logic_vector(15 downto 0);
        RB_USER                     : out std_logic_vector(15 downto 0)
    );
    end component;

    signal puxch_comp_hdr           : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal puxch_valid              : std_logic_vector(7 downto 0) := (others => '0');
    signal puxch_tick               : std_logic_vector(7 downto 0) := (others => '0');
    signal puxch_data_i             : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal puxch_data_q             : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal puxch_user               : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal prach0_comp_hdr          : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal prach0_valid             : std_logic_vector(7 downto 0) := (others => '0');
    signal prach0_tick              : std_logic_vector(7 downto 0) := (others => '0');
    signal prach0_data_i            : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal prach0_data_q            : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal prach0_user              : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal prach1_comp_hdr          : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal prach1_valid             : std_logic_vector(7 downto 0) := (others => '0');
    signal prach1_tick              : std_logic_vector(7 downto 0) := (others => '0');
    signal prach1_data_i            : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal prach1_data_q            : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal prach1_user              : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal nbiot0_comp_hdr          : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal nbiot0_valid             : std_logic_vector(7 downto 0) := (others => '0');
    signal nbiot0_tick              : std_logic_vector(7 downto 0) := (others => '0');
    signal nbiot0_data_i            : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal nbiot0_data_q            : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal nbiot0_user              : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal nbiot1_comp_hdr          : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal nbiot1_valid             : std_logic_vector(7 downto 0) := (others => '0');
    signal nbiot1_tick              : std_logic_vector(7 downto 0) := (others => '0');
    signal nbiot1_data_i            : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal nbiot1_data_q            : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal nbiot1_user              : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal nbiot2_comp_hdr          : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal nbiot2_valid             : std_logic_vector(7 downto 0) := (others => '0');
    signal nbiot2_tick              : std_logic_vector(7 downto 0) := (others => '0');
    signal nbiot2_data_i            : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal nbiot2_data_q            : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal nbiot2_user              : std_logic_array16(7 downto 0) := (others => (others => '0'));

    signal ulfe_mask                : std_logic_vector(7 downto 0) := (others => '0');
--    signal nbfe_mask                : std_logic_vector(7 downto 0) := (others => '0');

    signal ulfe_mask_cdc            : std_logic_vector(7 downto 0) := (others => '0');
--    signal nbfe_mask_cdc            : std_logic_vector(7 downto 0) := (others => '0');

    signal dbg_cnt_puxch_rb         : std_logic_vector(31 downto 0) := (others => '0');
    signal dbg_cnt_puxch_rpt        : std_logic_vector(3 downto 0) := (others => '0');

begin

--------------------------------------------------------------------------------
-- Interrupt masking
--------------------------------------------------------------------------------

    process (UL_PUxCH_EN)
    begin
        if    (UL_PUxCH_EN(7) = '1') then           ulfe_mask <= "00001000";
        elsif (UL_PUxCH_EN(6) = '1') then           ulfe_mask <= "00000100";
        elsif (UL_PUxCH_EN(5) = '1') then           ulfe_mask <= "00000010";
        elsif (UL_PUxCH_EN(4) = '1') then           ulfe_mask <= "00000001";
        elsif (UL_PUxCH_EN(3) = '1') then           ulfe_mask <= "00001000";
        elsif (UL_PUxCH_EN(2) = '1') then           ulfe_mask <= "00000100";
        elsif (UL_PUxCH_EN(1) = '1') then           ulfe_mask <= "00000010";
        else                                        ulfe_mask <= "00000001";
        end if;
    end process;

--    process (UL_NPUSCH_EN)
--    begin
--        if    (UL_NPUSCH_EN(7) = '1') then          nbfe_mask <= "00001000";
--        elsif (UL_NPUSCH_EN(6) = '1') then          nbfe_mask <= "00000100";
--        elsif (UL_NPUSCH_EN(5) = '1') then          nbfe_mask <= "00000010";
--        elsif (UL_NPUSCH_EN(4) = '1') then          nbfe_mask <= "00000001";
--        elsif (UL_NPUSCH_EN(3) = '1') then          nbfe_mask <= "00001000";
--        elsif (UL_NPUSCH_EN(2) = '1') then          nbfe_mask <= "00000100";
--        elsif (UL_NPUSCH_EN(1) = '1') then          nbfe_mask <= "00000010";
--        else                                        nbfe_mask <= "00000001";
--        end if;
--    end process;

    -- Metastable, but no effect because input only changes once during cell-setup
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            ulfe_mask_cdc   <= ulfe_mask;
--            nbfe_mask_cdc   <= nbfe_mask;
        end if;
    end process;

    -- Synchronous LUT
    puxch_update  <= '1' when (ulfe_mask_cdc and ULFE_VALID  and ULFE_LAST  ) /= 0 else '0';
    prach0_update <= '1' when (                  RAFE_VALID  and RAFE_LAST  ) /= 0 else '0';
    prach1_update <= '1' when (                  eMTC_VALID  and eMTC_LAST  ) /= 0 else '0';
    nbiot0_update <= '1' when (                  NBFE0_VALID and NBFE0_LAST ) /= 0 else '0';
    nbiot1_update <= '1' when (                  NBFE1_VALID and NBFE1_LAST ) /= 0 else '0';
    nbiot2_update <= '1' when (                  NBFE2_VALID and NBFE2_LAST ) /= 0 else '0';

    prach0_channel_id <= "001" when RAFE_VALID(1) = '1' else
                         "010" when RAFE_VALID(2) = '1' else
                         "011" when RAFE_VALID(3) = '1' else
                         "100" when RAFE_VALID(4) = '1' else
                         "101" when RAFE_VALID(5) = '1' else
                         "110" when RAFE_VALID(6) = '1' else
                         "111" when RAFE_VALID(7) = '1' else
                         "000";

    prach1_channel_id <= "001" when eMTC_VALID(1) = '1' else
                         "010" when eMTC_VALID(2) = '1' else
                         "011" when eMTC_VALID(3) = '1' else
                         "100" when eMTC_VALID(4) = '1' else
                         "101" when eMTC_VALID(5) = '1' else
                         "110" when eMTC_VALID(6) = '1' else
                         "111" when eMTC_VALID(7) = '1' else
                         "000";

    nbiot0_channel_id <= "001" when NBFE0_VALID(1) = '1' else
                         "010" when NBFE0_VALID(2) = '1' else
                         "011" when NBFE0_VALID(3) = '1' else
                         "100" when NBFE0_VALID(4) = '1' else
                         "101" when NBFE0_VALID(5) = '1' else
                         "110" when NBFE0_VALID(6) = '1' else
                         "111" when NBFE0_VALID(7) = '1' else
                         "000";

    nbiot1_channel_id <= "001" when NBFE1_VALID(1) = '1' else
                         "010" when NBFE1_VALID(2) = '1' else
                         "011" when NBFE1_VALID(3) = '1' else
                         "100" when NBFE1_VALID(4) = '1' else
                         "101" when NBFE1_VALID(5) = '1' else
                         "110" when NBFE1_VALID(6) = '1' else
                         "111" when NBFE1_VALID(7) = '1' else
                         "000";

    nbiot2_channel_id <= "001" when NBFE2_VALID(1) = '1' else
                         "010" when NBFE2_VALID(2) = '1' else
                         "011" when NBFE2_VALID(3) = '1' else
                         "100" when NBFE2_VALID(4) = '1' else
                         "101" when NBFE2_VALID(5) = '1' else
                         "110" when NBFE2_VALID(6) = '1' else
                         "111" when NBFE2_VALID(7) = '1' else
                         "000";

    freq_offset_for_prach(0)   <= FREQ_OFFSET_FOR_PRACH_0;
    freq_offset_for_prach(1)   <= FREQ_OFFSET_FOR_PRACH_1;
    freq_offset_for_prach(2)   <= FREQ_OFFSET_FOR_PRACH_2;
    freq_offset_for_prach(3)   <= FREQ_OFFSET_FOR_PRACH_3;
    freq_offset_for_prach(4)   <= FREQ_OFFSET_FOR_PRACH_4;
    freq_offset_for_prach(5)   <= FREQ_OFFSET_FOR_PRACH_5;
    freq_offset_for_prach(6)   <= FREQ_OFFSET_FOR_PRACH_6;
    freq_offset_for_prach(7)   <= FREQ_OFFSET_FOR_PRACH_7;
    freq_offset_for_emtc(0)    <= FREQ_OFFSET_FOR_eMTC_0;
    freq_offset_for_emtc(1)    <= FREQ_OFFSET_FOR_eMTC_1;
    freq_offset_for_emtc(2)    <= FREQ_OFFSET_FOR_eMTC_2;
    freq_offset_for_emtc(3)    <= FREQ_OFFSET_FOR_eMTC_3;
    freq_offset_for_emtc(4)    <= FREQ_OFFSET_FOR_eMTC_4;
    freq_offset_for_emtc(5)    <= FREQ_OFFSET_FOR_eMTC_5;
    freq_offset_for_emtc(6)    <= FREQ_OFFSET_FOR_eMTC_6;
    freq_offset_for_emtc(7)    <= FREQ_OFFSET_FOR_eMTC_7;
    freq_offset_for_nprach(0)  <= FREQ_OFFSET_FOR_NPRACH_0;
    freq_offset_for_nprach(1)  <= FREQ_OFFSET_FOR_NPRACH_1;
    freq_offset_for_nprach(2)  <= FREQ_OFFSET_FOR_NPRACH_2;
    freq_offset_for_nprach(3)  <= FREQ_OFFSET_FOR_NPRACH_3;
    freq_offset_for_nprach(4)  <= FREQ_OFFSET_FOR_NPRACH_4;
    freq_offset_for_nprach(5)  <= FREQ_OFFSET_FOR_NPRACH_5;
    freq_offset_for_nprach(6)  <= FREQ_OFFSET_FOR_NPRACH_6;
    freq_offset_for_nprach(7)  <= FREQ_OFFSET_FOR_NPRACH_7;
    freq_offset_for_npusch0(0) <= FREQ_OFFSET_FOR_NPUSCH0_0;
    freq_offset_for_npusch0(1) <= FREQ_OFFSET_FOR_NPUSCH0_1;
    freq_offset_for_npusch0(2) <= FREQ_OFFSET_FOR_NPUSCH0_2;
    freq_offset_for_npusch0(3) <= FREQ_OFFSET_FOR_NPUSCH0_3;
    freq_offset_for_npusch0(4) <= FREQ_OFFSET_FOR_NPUSCH0_4;
    freq_offset_for_npusch0(5) <= FREQ_OFFSET_FOR_NPUSCH0_5;
    freq_offset_for_npusch0(6) <= FREQ_OFFSET_FOR_NPUSCH0_6;
    freq_offset_for_npusch0(7) <= FREQ_OFFSET_FOR_NPUSCH0_7;
    freq_offset_for_npusch1(0) <= FREQ_OFFSET_FOR_NPUSCH1_0;
    freq_offset_for_npusch1(1) <= FREQ_OFFSET_FOR_NPUSCH1_1;
    freq_offset_for_npusch1(2) <= FREQ_OFFSET_FOR_NPUSCH1_2;
    freq_offset_for_npusch1(3) <= FREQ_OFFSET_FOR_NPUSCH1_3;
    freq_offset_for_npusch1(4) <= FREQ_OFFSET_FOR_NPUSCH1_4;
    freq_offset_for_npusch1(5) <= FREQ_OFFSET_FOR_NPUSCH1_5;
    freq_offset_for_npusch1(6) <= FREQ_OFFSET_FOR_NPUSCH1_6;
    freq_offset_for_npusch1(7) <= FREQ_OFFSET_FOR_NPUSCH1_7;

--------------------------------------------------------------------------------
-- Port/signal mapping
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            PUxCH_RB_COMP_HDR <= puxch_comp_hdr(0) or puxch_comp_hdr(1) or puxch_comp_hdr(2) or puxch_comp_hdr(3) or puxch_comp_hdr(4) or puxch_comp_hdr(5) or puxch_comp_hdr(6) or puxch_comp_hdr(7);
            PUxCH_RB_VALID    <= puxch_valid(0)    or puxch_valid(1)    or puxch_valid(2)    or puxch_valid(3)    or puxch_valid(4)    or puxch_valid(5)    or puxch_valid(6)    or puxch_valid(7);
            PUxCH_RB_TICK     <= puxch_tick(0)     or puxch_tick(1)     or puxch_tick(2)     or puxch_tick(3)     or puxch_tick(4)     or puxch_tick(5)     or puxch_tick(6)     or puxch_tick(7);
            PUxCH_RB_DATA_I   <= puxch_data_i(0)   or puxch_data_i(1)   or puxch_data_i(2)   or puxch_data_i(3)   or puxch_data_i(4)   or puxch_data_i(5)   or puxch_data_i(6)   or puxch_data_i(7);
            PUxCH_RB_DATA_Q   <= puxch_data_q(0)   or puxch_data_q(1)   or puxch_data_q(2)   or puxch_data_q(3)   or puxch_data_q(4)   or puxch_data_q(5)   or puxch_data_q(6)   or puxch_data_q(7);
            PUxCH_RB_USER     <= puxch_user(0)     or puxch_user(1)     or puxch_user(2)     or puxch_user(3)     or puxch_user(4)     or puxch_user(5)     or puxch_user(6)     or puxch_user(7);
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            PRACH_RB_COMP_HDR <= prach0_comp_hdr(0) or prach0_comp_hdr(1) or prach0_comp_hdr(2) or prach0_comp_hdr(3) or prach0_comp_hdr(4) or prach0_comp_hdr(5) or prach0_comp_hdr(6) or prach0_comp_hdr(7);
            PRACH_RB_VALID    <= prach0_valid(0)    or prach0_valid(1)    or prach0_valid(2)    or prach0_valid(3)    or prach0_valid(4)    or prach0_valid(5)    or prach0_valid(6)    or prach0_valid(7);
            PRACH_RB_TICK     <= prach0_tick(0)     or prach0_tick(1)     or prach0_tick(2)     or prach0_tick(3)     or prach0_tick(4)     or prach0_tick(5)     or prach0_tick(6)     or prach0_tick(7);
            PRACH_RB_DATA_I   <= prach0_data_i(0)   or prach0_data_i(1)   or prach0_data_i(2)   or prach0_data_i(3)   or prach0_data_i(4)   or prach0_data_i(5)   or prach0_data_i(6)   or prach0_data_i(7);
            PRACH_RB_DATA_Q   <= prach0_data_q(0)   or prach0_data_q(1)   or prach0_data_q(2)   or prach0_data_q(3)   or prach0_data_q(4)   or prach0_data_q(5)   or prach0_data_q(6)   or prach0_data_q(7);
            PRACH_RB_USER     <= prach0_user(0)     or prach0_user(1)     or prach0_user(2)     or prach0_user(3)     or prach0_user(4)     or prach0_user(5)     or prach0_user(6)     or prach0_user(7);
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            eMTC_RB_COMP_HDR <= prach1_comp_hdr(0) or prach1_comp_hdr(1) or prach1_comp_hdr(2) or prach1_comp_hdr(3) or prach1_comp_hdr(4) or prach1_comp_hdr(5) or prach1_comp_hdr(6) or prach1_comp_hdr(7);
            eMTC_RB_VALID    <= prach1_valid(0)    or prach1_valid(1)    or prach1_valid(2)    or prach1_valid(3)    or prach1_valid(4)    or prach1_valid(5)    or prach1_valid(6)    or prach1_valid(7);
            eMTC_RB_TICK     <= prach1_tick(0)     or prach1_tick(1)     or prach1_tick(2)     or prach1_tick(3)     or prach1_tick(4)     or prach1_tick(5)     or prach1_tick(6)     or prach1_tick(7);
            eMTC_RB_DATA_I   <= prach1_data_i(0)   or prach1_data_i(1)   or prach1_data_i(2)   or prach1_data_i(3)   or prach1_data_i(4)   or prach1_data_i(5)   or prach1_data_i(6)   or prach1_data_i(7);
            eMTC_RB_DATA_Q   <= prach1_data_q(0)   or prach1_data_q(1)   or prach1_data_q(2)   or prach1_data_q(3)   or prach1_data_q(4)   or prach1_data_q(5)   or prach1_data_q(6)   or prach1_data_q(7);
            eMTC_RB_USER     <= prach1_user(0)     or prach1_user(1)     or prach1_user(2)     or prach1_user(3)     or prach1_user(4)     or prach1_user(5)     or prach1_user(6)     or prach1_user(7);
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            NBIOT0_RB_COMP_HDR <= nbiot0_comp_hdr(0) or nbiot0_comp_hdr(1) or nbiot0_comp_hdr(2) or nbiot0_comp_hdr(3) or nbiot0_comp_hdr(4) or nbiot0_comp_hdr(5) or nbiot0_comp_hdr(6) or nbiot0_comp_hdr(7);
            NBIOT0_RB_VALID    <= nbiot0_valid(0)    or nbiot0_valid(1)    or nbiot0_valid(2)    or nbiot0_valid(3)    or nbiot0_valid(4)    or nbiot0_valid(5)    or nbiot0_valid(6)    or nbiot0_valid(7);
            NBIOT0_RB_TICK     <= nbiot0_tick(0)     or nbiot0_tick(1)     or nbiot0_tick(2)     or nbiot0_tick(3)     or nbiot0_tick(4)     or nbiot0_tick(5)     or nbiot0_tick(6)     or nbiot0_tick(7);
            NBIOT0_RB_DATA_I   <= nbiot0_data_i(0)   or nbiot0_data_i(1)   or nbiot0_data_i(2)   or nbiot0_data_i(3)   or nbiot0_data_i(4)   or nbiot0_data_i(5)   or nbiot0_data_i(6)   or nbiot0_data_i(7);
            NBIOT0_RB_DATA_Q   <= nbiot0_data_q(0)   or nbiot0_data_q(1)   or nbiot0_data_q(2)   or nbiot0_data_q(3)   or nbiot0_data_q(4)   or nbiot0_data_q(5)   or nbiot0_data_q(6)   or nbiot0_data_q(7);
            NBIOT0_RB_USER     <= nbiot0_user(0)     or nbiot0_user(1)     or nbiot0_user(2)     or nbiot0_user(3)     or nbiot0_user(4)     or nbiot0_user(5)     or nbiot0_user(6)     or nbiot0_user(7);
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            NBIOT1_RB_COMP_HDR <= nbiot1_comp_hdr(0) or nbiot1_comp_hdr(1) or nbiot1_comp_hdr(2) or nbiot1_comp_hdr(3) or nbiot1_comp_hdr(4) or nbiot1_comp_hdr(5) or nbiot1_comp_hdr(6) or nbiot1_comp_hdr(7);
            NBIOT1_RB_VALID    <= nbiot1_valid(0)    or nbiot1_valid(1)    or nbiot1_valid(2)    or nbiot1_valid(3)    or nbiot1_valid(4)    or nbiot1_valid(5)    or nbiot1_valid(6)    or nbiot1_valid(7);
            NBIOT1_RB_TICK     <= nbiot1_tick(0)     or nbiot1_tick(1)     or nbiot1_tick(2)     or nbiot1_tick(3)     or nbiot1_tick(4)     or nbiot1_tick(5)     or nbiot1_tick(6)     or nbiot1_tick(7);
            NBIOT1_RB_DATA_I   <= nbiot1_data_i(0)   or nbiot1_data_i(1)   or nbiot1_data_i(2)   or nbiot1_data_i(3)   or nbiot1_data_i(4)   or nbiot1_data_i(5)   or nbiot1_data_i(6)   or nbiot1_data_i(7);
            NBIOT1_RB_DATA_Q   <= nbiot1_data_q(0)   or nbiot1_data_q(1)   or nbiot1_data_q(2)   or nbiot1_data_q(3)   or nbiot1_data_q(4)   or nbiot1_data_q(5)   or nbiot1_data_q(6)   or nbiot1_data_q(7);
            NBIOT1_RB_USER     <= nbiot1_user(0)     or nbiot1_user(1)     or nbiot1_user(2)     or nbiot1_user(3)     or nbiot1_user(4)     or nbiot1_user(5)     or nbiot1_user(6)     or nbiot1_user(7);
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            NBIOT2_RB_COMP_HDR <= nbiot2_comp_hdr(0) or nbiot2_comp_hdr(1) or nbiot2_comp_hdr(2) or nbiot2_comp_hdr(3) or nbiot2_comp_hdr(4) or nbiot2_comp_hdr(5) or nbiot2_comp_hdr(6) or nbiot2_comp_hdr(7);
            NBIOT2_RB_VALID    <= nbiot2_valid(0)    or nbiot2_valid(1)    or nbiot2_valid(2)    or nbiot2_valid(3)    or nbiot2_valid(4)    or nbiot2_valid(5)    or nbiot2_valid(6)    or nbiot2_valid(7);
            NBIOT2_RB_TICK     <= nbiot2_tick(0)     or nbiot2_tick(1)     or nbiot2_tick(2)     or nbiot2_tick(3)     or nbiot2_tick(4)     or nbiot2_tick(5)     or nbiot2_tick(6)     or nbiot2_tick(7);
            NBIOT2_RB_DATA_I   <= nbiot2_data_i(0)   or nbiot2_data_i(1)   or nbiot2_data_i(2)   or nbiot2_data_i(3)   or nbiot2_data_i(4)   or nbiot2_data_i(5)   or nbiot2_data_i(6)   or nbiot2_data_i(7);
            NBIOT2_RB_DATA_Q   <= nbiot2_data_q(0)   or nbiot2_data_q(1)   or nbiot2_data_q(2)   or nbiot2_data_q(3)   or nbiot2_data_q(4)   or nbiot2_data_q(5)   or nbiot2_data_q(6)   or nbiot2_data_q(7);
            NBIOT2_RB_USER     <= nbiot2_user(0)     or nbiot2_user(1)     or nbiot2_user(2)     or nbiot2_user(3)     or nbiot2_user(4)     or nbiot2_user(5)     or nbiot2_user(6)     or nbiot2_user(7);
        end if;
    end process;

--------------------------------------------------------------------------------
-- Debug
--------------------------------------------------------------------------------

--    CNT_PUxCH_UPPKT_SYMBOL0     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL1     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL2     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL3     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL4     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL5     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL6     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL7     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL8     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL9     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL10    <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL11    <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL12    <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL13    <= (others => '0');

    CNT_PRACH_UPPKT_SYMBOL0     <= "00000000" & FREQ_OFFSET_FOR_PRACH_0;
    CNT_PRACH_UPPKT_SYMBOL1     <= "00000000" & FREQ_OFFSET_FOR_PRACH_1;
    CNT_PRACH_UPPKT_SYMBOL2     <= "00000000" & FREQ_OFFSET_FOR_PRACH_2;
    CNT_PRACH_UPPKT_SYMBOL3     <= "00000000" & FREQ_OFFSET_FOR_PRACH_3;
    CNT_PRACH_UPPKT_SYMBOL4     <= "00000000" & FREQ_OFFSET_FOR_PRACH_4;
    CNT_PRACH_UPPKT_SYMBOL5     <= "00000000" & FREQ_OFFSET_FOR_PRACH_5;
    CNT_PRACH_UPPKT_SYMBOL6     <= "00000000" & FREQ_OFFSET_FOR_PRACH_6;
    CNT_PRACH_UPPKT_SYMBOL7     <= "00000000" & FREQ_OFFSET_FOR_PRACH_7;
    CNT_PRACH_UPPKT_SYMBOL8     <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL9     <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL10    <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL11    <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL12    <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL13    <= (others => '0');

    CNT_eMTC_UPPKT_SYMBOL0      <= "00000000" & FREQ_OFFSET_FOR_eMTC_0;
    CNT_eMTC_UPPKT_SYMBOL1      <= "00000000" & FREQ_OFFSET_FOR_eMTC_1;
    CNT_eMTC_UPPKT_SYMBOL2      <= "00000000" & FREQ_OFFSET_FOR_eMTC_2;
    CNT_eMTC_UPPKT_SYMBOL3      <= "00000000" & FREQ_OFFSET_FOR_eMTC_3;
    CNT_eMTC_UPPKT_SYMBOL4      <= "00000000" & FREQ_OFFSET_FOR_eMTC_4;
    CNT_eMTC_UPPKT_SYMBOL5      <= "00000000" & FREQ_OFFSET_FOR_eMTC_5;
    CNT_eMTC_UPPKT_SYMBOL6      <= "00000000" & FREQ_OFFSET_FOR_eMTC_6;
    CNT_eMTC_UPPKT_SYMBOL7      <= "00000000" & FREQ_OFFSET_FOR_eMTC_7;
    CNT_eMTC_UPPKT_SYMBOL8      <= (others => '0');
    CNT_eMTC_UPPKT_SYMBOL9      <= (others => '0');
    CNT_eMTC_UPPKT_SYMBOL10     <= (others => '0');
    CNT_eMTC_UPPKT_SYMBOL11     <= (others => '0');
    CNT_eMTC_UPPKT_SYMBOL12     <= (others => '0');
    CNT_eMTC_UPPKT_SYMBOL13     <= (others => '0');

    CNT_NBIOT0_UPPKT_SYMBOL0    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH0_0;
    CNT_NBIOT0_UPPKT_SYMBOL1    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH0_1;
    CNT_NBIOT0_UPPKT_SYMBOL2    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH0_2;
    CNT_NBIOT0_UPPKT_SYMBOL3    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH0_3;
    CNT_NBIOT0_UPPKT_SYMBOL4    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH0_4;
    CNT_NBIOT0_UPPKT_SYMBOL5    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH0_5;
    CNT_NBIOT0_UPPKT_SYMBOL6    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH0_6;
    CNT_NBIOT0_UPPKT_SYMBOL7    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH0_7;
    CNT_NBIOT0_UPPKT_SYMBOL8    <= (others => '0');
    CNT_NBIOT0_UPPKT_SYMBOL9    <= (others => '0');
    CNT_NBIOT0_UPPKT_SYMBOL10   <= (others => '0');
    CNT_NBIOT0_UPPKT_SYMBOL11   <= (others => '0');
    CNT_NBIOT0_UPPKT_SYMBOL12   <= (others => '0');
    CNT_NBIOT0_UPPKT_SYMBOL13   <= (others => '0');

    CNT_NBIOT1_UPPKT_SYMBOL0    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH1_0;
    CNT_NBIOT1_UPPKT_SYMBOL1    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH1_1;
    CNT_NBIOT1_UPPKT_SYMBOL2    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH1_2;
    CNT_NBIOT1_UPPKT_SYMBOL3    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH1_3;
    CNT_NBIOT1_UPPKT_SYMBOL4    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH1_4;
    CNT_NBIOT1_UPPKT_SYMBOL5    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH1_5;
    CNT_NBIOT1_UPPKT_SYMBOL6    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH1_6;
    CNT_NBIOT1_UPPKT_SYMBOL7    <= "00000000" & FREQ_OFFSET_FOR_NPUSCH1_7;
    CNT_NBIOT1_UPPKT_SYMBOL8    <= (others => '0');
    CNT_NBIOT1_UPPKT_SYMBOL9    <= (others => '0');
    CNT_NBIOT1_UPPKT_SYMBOL10   <= (others => '0');
    CNT_NBIOT1_UPPKT_SYMBOL11   <= (others => '0');
    CNT_NBIOT1_UPPKT_SYMBOL12   <= (others => '0');
    CNT_NBIOT1_UPPKT_SYMBOL13   <= (others => '0');

    CNT_NBIOT2_UPPKT_SYMBOL0    <= "00000000" & FREQ_OFFSET_FOR_NPRACH_0;
    CNT_NBIOT2_UPPKT_SYMBOL1    <= "00000000" & FREQ_OFFSET_FOR_NPRACH_1;
    CNT_NBIOT2_UPPKT_SYMBOL2    <= "00000000" & FREQ_OFFSET_FOR_NPRACH_2;
    CNT_NBIOT2_UPPKT_SYMBOL3    <= "00000000" & FREQ_OFFSET_FOR_NPRACH_3;
    CNT_NBIOT2_UPPKT_SYMBOL4    <= "00000000" & FREQ_OFFSET_FOR_NPRACH_4;
    CNT_NBIOT2_UPPKT_SYMBOL5    <= "00000000" & FREQ_OFFSET_FOR_NPRACH_5;
    CNT_NBIOT2_UPPKT_SYMBOL6    <= "00000000" & FREQ_OFFSET_FOR_NPRACH_6;
    CNT_NBIOT2_UPPKT_SYMBOL7    <= "00000000" & FREQ_OFFSET_FOR_NPRACH_7;
    CNT_NBIOT2_UPPKT_SYMBOL8    <= (others => '0');
    CNT_NBIOT2_UPPKT_SYMBOL9    <= (others => '0');
    CNT_NBIOT2_UPPKT_SYMBOL10   <= (others => '0');
    CNT_NBIOT2_UPPKT_SYMBOL11   <= (others => '0');
    CNT_NBIOT2_UPPKT_SYMBOL12   <= (others => '0');
    CNT_NBIOT2_UPPKT_SYMBOL13   <= (others => '0');

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (puxch_init = '1') then
                dbg_cnt_puxch_rb <= (others => '0');
            else
                if (puxch_section_tick(0) = '1') then
                    dbg_cnt_puxch_rb <= dbg_cnt_puxch_rb + puxch_number_of_prb;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (puxch_init = '1') then
                if (dbg_cnt_puxch_rb > UL_PRB_PER_SYMBOL) then
                    if (dbg_cnt_puxch_rpt = 13) then
                        dbg_cnt_puxch_rpt <= (others => '0');
                    else
                        dbg_cnt_puxch_rpt <= dbg_cnt_puxch_rpt + 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (dbg_cnt_puxch_rpt = 0) then     CNT_PUxCH_UPPKT_SYMBOL0  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 1) then     CNT_PUxCH_UPPKT_SYMBOL1  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 2) then     CNT_PUxCH_UPPKT_SYMBOL2  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 3) then     CNT_PUxCH_UPPKT_SYMBOL3  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 4) then     CNT_PUxCH_UPPKT_SYMBOL4  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 5) then     CNT_PUxCH_UPPKT_SYMBOL5  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 6) then     CNT_PUxCH_UPPKT_SYMBOL6  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 7) then     CNT_PUxCH_UPPKT_SYMBOL7  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 8) then     CNT_PUxCH_UPPKT_SYMBOL8  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 9) then     CNT_PUxCH_UPPKT_SYMBOL9  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 10) then    CNT_PUxCH_UPPKT_SYMBOL10 <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 11) then    CNT_PUxCH_UPPKT_SYMBOL11 <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 12) then    CNT_PUxCH_UPPKT_SYMBOL12 <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 13) then    CNT_PUxCH_UPPKT_SYMBOL13 <= dbg_cnt_puxch_rb;   end if;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_RST : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => RST                                     ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;
        RST_OUT                     => reset                                    --: out std_logic
    );

    u_SCHEDULER : UL_SCHEDULER0
    generic map(
        LINK_DIRECTION              => TX_LINK_DIRECTION                       ,--: std_logic := '0';
        MAX_SECTION_PUxCH           => MAX_SECTION_PUxCH                       ,--: natural := 256;
        MAX_SECTION_PRACH           => MAX_SECTION_PRACH                       ,--: natural := 16;
        MAX_SECTION_eMTC            => MAX_SECTION_eMTC                        ,--: natural := 16;
        MAX_SECTION_NBIOT0          => MAX_SECTION_NBIOT0                      ,--: natural := 8;
        MAX_SECTION_NBIOT1          => MAX_SECTION_NBIOT1                      ,--: natural := 8;
        MAX_SECTION_NBIOT2          => MAX_SECTION_NBIOT2                      ,--: natural := 8;
        USAGE_TYPE0                 => false                                   ,--: boolean := true;
        USAGE_TYPE1                 => true                                    ,--: boolean := true;
        USAGE_TYPE3                 => true                                    ,--: boolean := true;
        USAGE_TYPE5                 => false                                   ,--: boolean := true;
        USAGE_TYPE6                 => false                                   ,--: boolean := true;
        USAGE_TYPE7                 => false                                    --: boolean := false
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => reset                                   ,--: in  std_logic;

        IGNORE_FRAME_ID             => IGNORE_FRAME_ID                         ,--: in  std_logic;
        IGNORE_FRAME_ID_PUxCH_RX    => IGNORE_FRAME_ID_PUxCH_RX                ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    => IGNORE_FRAME_ID_PUxCH_TX                ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_RX   => IGNORE_FRAME_ID_PRACH0_RX               ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH0_TX   => IGNORE_FRAME_ID_PRACH0_TX               ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_RX   => IGNORE_FRAME_ID_PRACH1_RX               ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH1_TX   => IGNORE_FRAME_ID_PRACH1_TX               ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_RX   => IGNORE_FRAME_ID_NBIOT0_RX               ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT0_TX   => IGNORE_FRAME_ID_NBIOT0_TX               ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_RX   => IGNORE_FRAME_ID_NBIOT1_RX               ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT1_TX   => IGNORE_FRAME_ID_NBIOT1_TX               ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT2_RX   => IGNORE_FRAME_ID_NBIOT2_RX               ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_NBIOT2_TX   => IGNORE_FRAME_ID_NBIOT2_TX               ,--: out std_logic_vector(7 downto 0);

        PUxCH_ID                    => UL_PUxCH_ID                             ,--: in  std_logic_array16(7 downto 0);
        PRACH_ID                    => UL_PRACH_ID                             ,--: in  std_logic_array16(7 downto 0);
        NPUSCH_ID                   => UL_NPUSCH_ID                            ,--: in  std_logic_array16(7 downto 0);

        COMP_MODE                   => UL_COMP_MODE                            ,--: in  std_logic;
        IQ_WIDTH                    => UL_IQ_WIDTH                             ,--: in  std_logic_vector(3 downto 0);
        COMP_METHOD                 => UL_COMP_METHOD                          ,--: in  std_logic_vector(3 downto 0);
        PRB_PER_SYMBOL              => UL_PRB_PER_SYMBOL                       ,--: in  std_logic_vector(9 downto 0);
        PRB_PER_MTU                 => UL_PRB_PER_MTU                          ,--: in  std_logic_vector(9 downto 0);

        CNT_FIFO_FULL               => CNT_FIFO_FULL                           ,--: out std_logic_vector(31 downto 0);

        CNT_PUxCH_TERMINATION       => CNT_PUxCH_TERMINATION                   ,--: out std_logic_vector(31 downto 0);

        CNT_PUxCH_CPSEC_SYMBOL0     => CNT_PUxCH_CPSEC_SYMBOL0                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL1     => CNT_PUxCH_CPSEC_SYMBOL1                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL2     => CNT_PUxCH_CPSEC_SYMBOL2                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL3     => CNT_PUxCH_CPSEC_SYMBOL3                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL4     => CNT_PUxCH_CPSEC_SYMBOL4                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL5     => CNT_PUxCH_CPSEC_SYMBOL5                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL6     => CNT_PUxCH_CPSEC_SYMBOL6                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL7     => CNT_PUxCH_CPSEC_SYMBOL7                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL8     => CNT_PUxCH_CPSEC_SYMBOL8                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL9     => CNT_PUxCH_CPSEC_SYMBOL9                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL10    => CNT_PUxCH_CPSEC_SYMBOL10                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL11    => CNT_PUxCH_CPSEC_SYMBOL11                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL12    => CNT_PUxCH_CPSEC_SYMBOL12                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL13    => CNT_PUxCH_CPSEC_SYMBOL13                ,--: out std_logic_vector(31 downto 0);

        CNT_PUxCH_CQ_FULL_SYMBOL0   => CNT_PUxCH_CQ_FULL_SYMBOL0               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL1   => CNT_PUxCH_CQ_FULL_SYMBOL1               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL2   => CNT_PUxCH_CQ_FULL_SYMBOL2               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL3   => CNT_PUxCH_CQ_FULL_SYMBOL3               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL4   => CNT_PUxCH_CQ_FULL_SYMBOL4               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL5   => CNT_PUxCH_CQ_FULL_SYMBOL5               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL6   => CNT_PUxCH_CQ_FULL_SYMBOL6               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL7   => CNT_PUxCH_CQ_FULL_SYMBOL7               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL8   => CNT_PUxCH_CQ_FULL_SYMBOL8               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL9   => CNT_PUxCH_CQ_FULL_SYMBOL9               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL10  => CNT_PUxCH_CQ_FULL_SYMBOL10              ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL11  => CNT_PUxCH_CQ_FULL_SYMBOL11              ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL12  => CNT_PUxCH_CQ_FULL_SYMBOL12              ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL13  => CNT_PUxCH_CQ_FULL_SYMBOL13              ,--: out std_logic_vector(31 downto 0);

        USAGE_PUxCH_CQ_SYMBOL0      => USAGE_PUxCH_CQ_SYMBOL0                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL1      => USAGE_PUxCH_CQ_SYMBOL1                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL2      => USAGE_PUxCH_CQ_SYMBOL2                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL3      => USAGE_PUxCH_CQ_SYMBOL3                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL4      => USAGE_PUxCH_CQ_SYMBOL4                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL5      => USAGE_PUxCH_CQ_SYMBOL5                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL6      => USAGE_PUxCH_CQ_SYMBOL6                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL7      => USAGE_PUxCH_CQ_SYMBOL7                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL8      => USAGE_PUxCH_CQ_SYMBOL8                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL9      => USAGE_PUxCH_CQ_SYMBOL9                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL10     => USAGE_PUxCH_CQ_SYMBOL10                 ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL11     => USAGE_PUxCH_CQ_SYMBOL11                 ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL12     => USAGE_PUxCH_CQ_SYMBOL12                 ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL13     => USAGE_PUxCH_CQ_SYMBOL13                 ,--: out std_logic_vector(31 downto 0);

        CNT_PRACH_TERMINATION       => CNT_PRACH_TERMINATION                   ,--: out std_logic_vector(31 downto 0);

        CNT_PRACH_CPSEC_SYMBOL0     => CNT_PRACH_CPSEC_SYMBOL0                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL1     => CNT_PRACH_CPSEC_SYMBOL1                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL2     => CNT_PRACH_CPSEC_SYMBOL2                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL3     => CNT_PRACH_CPSEC_SYMBOL3                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL4     => CNT_PRACH_CPSEC_SYMBOL4                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL5     => CNT_PRACH_CPSEC_SYMBOL5                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL6     => CNT_PRACH_CPSEC_SYMBOL6                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL7     => CNT_PRACH_CPSEC_SYMBOL7                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL8     => CNT_PRACH_CPSEC_SYMBOL8                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL9     => CNT_PRACH_CPSEC_SYMBOL9                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL10    => CNT_PRACH_CPSEC_SYMBOL10                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL11    => CNT_PRACH_CPSEC_SYMBOL11                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL12    => CNT_PRACH_CPSEC_SYMBOL12                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL13    => CNT_PRACH_CPSEC_SYMBOL13                ,--: out std_logic_vector(31 downto 0);

        CNT_PRACH_CQ_FULL_SYMBOL0   => CNT_PRACH_CQ_FULL_SYMBOL0               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL1   => CNT_PRACH_CQ_FULL_SYMBOL1               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL2   => CNT_PRACH_CQ_FULL_SYMBOL2               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL3   => CNT_PRACH_CQ_FULL_SYMBOL3               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL4   => CNT_PRACH_CQ_FULL_SYMBOL4               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL5   => CNT_PRACH_CQ_FULL_SYMBOL5               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL6   => CNT_PRACH_CQ_FULL_SYMBOL6               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL7   => CNT_PRACH_CQ_FULL_SYMBOL7               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL8   => CNT_PRACH_CQ_FULL_SYMBOL8               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL9   => CNT_PRACH_CQ_FULL_SYMBOL9               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL10  => CNT_PRACH_CQ_FULL_SYMBOL10              ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL11  => CNT_PRACH_CQ_FULL_SYMBOL11              ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL12  => CNT_PRACH_CQ_FULL_SYMBOL12              ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL13  => CNT_PRACH_CQ_FULL_SYMBOL13              ,--: out std_logic_vector(31 downto 0);

        USAGE_PRACH_CQ_SYMBOL0      => USAGE_PRACH_CQ_SYMBOL0                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL1      => USAGE_PRACH_CQ_SYMBOL1                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL2      => USAGE_PRACH_CQ_SYMBOL2                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL3      => USAGE_PRACH_CQ_SYMBOL3                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL4      => USAGE_PRACH_CQ_SYMBOL4                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL5      => USAGE_PRACH_CQ_SYMBOL5                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL6      => USAGE_PRACH_CQ_SYMBOL6                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL7      => USAGE_PRACH_CQ_SYMBOL7                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL8      => USAGE_PRACH_CQ_SYMBOL8                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL9      => USAGE_PRACH_CQ_SYMBOL9                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL10     => USAGE_PRACH_CQ_SYMBOL10                 ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL11     => USAGE_PRACH_CQ_SYMBOL11                 ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL12     => USAGE_PRACH_CQ_SYMBOL12                 ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL13     => USAGE_PRACH_CQ_SYMBOL13                 ,--: out std_logic_vector(31 downto 0);

        CNT_eMTC_TERMINATION        => CNT_eMTC_TERMINATION                    ,--: out std_logic_vector(31 downto 0);

        CNT_eMTC_CPSEC_SYMBOL0      => CNT_eMTC_CPSEC_SYMBOL0                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL1      => CNT_eMTC_CPSEC_SYMBOL1                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL2      => CNT_eMTC_CPSEC_SYMBOL2                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL3      => CNT_eMTC_CPSEC_SYMBOL3                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL4      => CNT_eMTC_CPSEC_SYMBOL4                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL5      => CNT_eMTC_CPSEC_SYMBOL5                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL6      => CNT_eMTC_CPSEC_SYMBOL6                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL7      => CNT_eMTC_CPSEC_SYMBOL7                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL8      => CNT_eMTC_CPSEC_SYMBOL8                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL9      => CNT_eMTC_CPSEC_SYMBOL9                  ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL10     => CNT_eMTC_CPSEC_SYMBOL10                 ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL11     => CNT_eMTC_CPSEC_SYMBOL11                 ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL12     => CNT_eMTC_CPSEC_SYMBOL12                 ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CPSEC_SYMBOL13     => CNT_eMTC_CPSEC_SYMBOL13                 ,--: out std_logic_vector(31 downto 0);

        CNT_eMTC_CQ_FULL_SYMBOL0    => CNT_eMTC_CQ_FULL_SYMBOL0                ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL1    => CNT_eMTC_CQ_FULL_SYMBOL1                ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL2    => CNT_eMTC_CQ_FULL_SYMBOL2                ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL3    => CNT_eMTC_CQ_FULL_SYMBOL3                ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL4    => CNT_eMTC_CQ_FULL_SYMBOL4                ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL5    => CNT_eMTC_CQ_FULL_SYMBOL5                ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL6    => CNT_eMTC_CQ_FULL_SYMBOL6                ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL7    => CNT_eMTC_CQ_FULL_SYMBOL7                ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL8    => CNT_eMTC_CQ_FULL_SYMBOL8                ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL9    => CNT_eMTC_CQ_FULL_SYMBOL9                ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL10   => CNT_eMTC_CQ_FULL_SYMBOL10               ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL11   => CNT_eMTC_CQ_FULL_SYMBOL11               ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL12   => CNT_eMTC_CQ_FULL_SYMBOL12               ,--: out std_logic_vector(31 downto 0);
        CNT_eMTC_CQ_FULL_SYMBOL13   => CNT_eMTC_CQ_FULL_SYMBOL13               ,--: out std_logic_vector(31 downto 0);

        USAGE_eMTC_CQ_SYMBOL0       => USAGE_eMTC_CQ_SYMBOL0                   ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL1       => USAGE_eMTC_CQ_SYMBOL1                   ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL2       => USAGE_eMTC_CQ_SYMBOL2                   ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL3       => USAGE_eMTC_CQ_SYMBOL3                   ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL4       => USAGE_eMTC_CQ_SYMBOL4                   ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL5       => USAGE_eMTC_CQ_SYMBOL5                   ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL6       => USAGE_eMTC_CQ_SYMBOL6                   ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL7       => USAGE_eMTC_CQ_SYMBOL7                   ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL8       => USAGE_eMTC_CQ_SYMBOL8                   ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL9       => USAGE_eMTC_CQ_SYMBOL9                   ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL10      => USAGE_eMTC_CQ_SYMBOL10                  ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL11      => USAGE_eMTC_CQ_SYMBOL11                  ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL12      => USAGE_eMTC_CQ_SYMBOL12                  ,--: out std_logic_vector(31 downto 0);
        USAGE_eMTC_CQ_SYMBOL13      => USAGE_eMTC_CQ_SYMBOL13                  ,--: out std_logic_vector(31 downto 0);

        CNT_NBIOT0_TERMINATION      => CNT_NBIOT0_TERMINATION                  ,--: out std_logic_vector(31 downto 0);

        CNT_NBIOT0_CPSEC_SYMBOL0    => CNT_NBIOT0_CPSEC_SYMBOL0                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL1    => CNT_NBIOT0_CPSEC_SYMBOL1                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL2    => CNT_NBIOT0_CPSEC_SYMBOL2                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL3    => CNT_NBIOT0_CPSEC_SYMBOL3                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL4    => CNT_NBIOT0_CPSEC_SYMBOL4                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL5    => CNT_NBIOT0_CPSEC_SYMBOL5                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL6    => CNT_NBIOT0_CPSEC_SYMBOL6                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL7    => CNT_NBIOT0_CPSEC_SYMBOL7                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL8    => CNT_NBIOT0_CPSEC_SYMBOL8                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL9    => CNT_NBIOT0_CPSEC_SYMBOL9                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL10   => CNT_NBIOT0_CPSEC_SYMBOL10               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL11   => CNT_NBIOT0_CPSEC_SYMBOL11               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL12   => CNT_NBIOT0_CPSEC_SYMBOL12               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CPSEC_SYMBOL13   => CNT_NBIOT0_CPSEC_SYMBOL13               ,--: out std_logic_vector(31 downto 0);

        CNT_NBIOT0_CQ_FULL_SYMBOL0  => CNT_NBIOT0_CQ_FULL_SYMBOL0              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL1  => CNT_NBIOT0_CQ_FULL_SYMBOL1              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL2  => CNT_NBIOT0_CQ_FULL_SYMBOL2              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL3  => CNT_NBIOT0_CQ_FULL_SYMBOL3              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL4  => CNT_NBIOT0_CQ_FULL_SYMBOL4              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL5  => CNT_NBIOT0_CQ_FULL_SYMBOL5              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL6  => CNT_NBIOT0_CQ_FULL_SYMBOL6              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL7  => CNT_NBIOT0_CQ_FULL_SYMBOL7              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL8  => CNT_NBIOT0_CQ_FULL_SYMBOL8              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL9  => CNT_NBIOT0_CQ_FULL_SYMBOL9              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL10 => CNT_NBIOT0_CQ_FULL_SYMBOL10             ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL11 => CNT_NBIOT0_CQ_FULL_SYMBOL11             ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL12 => CNT_NBIOT0_CQ_FULL_SYMBOL12             ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT0_CQ_FULL_SYMBOL13 => CNT_NBIOT0_CQ_FULL_SYMBOL13             ,--: out std_logic_vector(31 downto 0);

        USAGE_NBIOT0_CQ_SYMBOL0     => USAGE_NBIOT0_CQ_SYMBOL0                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL1     => USAGE_NBIOT0_CQ_SYMBOL1                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL2     => USAGE_NBIOT0_CQ_SYMBOL2                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL3     => USAGE_NBIOT0_CQ_SYMBOL3                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL4     => USAGE_NBIOT0_CQ_SYMBOL4                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL5     => USAGE_NBIOT0_CQ_SYMBOL5                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL6     => USAGE_NBIOT0_CQ_SYMBOL6                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL7     => USAGE_NBIOT0_CQ_SYMBOL7                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL8     => USAGE_NBIOT0_CQ_SYMBOL8                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL9     => USAGE_NBIOT0_CQ_SYMBOL9                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL10    => USAGE_NBIOT0_CQ_SYMBOL10                ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL11    => USAGE_NBIOT0_CQ_SYMBOL11                ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL12    => USAGE_NBIOT0_CQ_SYMBOL12                ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT0_CQ_SYMBOL13    => USAGE_NBIOT0_CQ_SYMBOL13                ,--: out std_logic_vector(31 downto 0);

        CNT_NBIOT1_TERMINATION      => CNT_NBIOT1_TERMINATION                  ,--: out std_logic_vector(31 downto 0);

        CNT_NBIOT1_CPSEC_SYMBOL0    => CNT_NBIOT1_CPSEC_SYMBOL0                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL1    => CNT_NBIOT1_CPSEC_SYMBOL1                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL2    => CNT_NBIOT1_CPSEC_SYMBOL2                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL3    => CNT_NBIOT1_CPSEC_SYMBOL3                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL4    => CNT_NBIOT1_CPSEC_SYMBOL4                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL5    => CNT_NBIOT1_CPSEC_SYMBOL5                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL6    => CNT_NBIOT1_CPSEC_SYMBOL6                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL7    => CNT_NBIOT1_CPSEC_SYMBOL7                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL8    => CNT_NBIOT1_CPSEC_SYMBOL8                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL9    => CNT_NBIOT1_CPSEC_SYMBOL9                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL10   => CNT_NBIOT1_CPSEC_SYMBOL10               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL11   => CNT_NBIOT1_CPSEC_SYMBOL11               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL12   => CNT_NBIOT1_CPSEC_SYMBOL12               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CPSEC_SYMBOL13   => CNT_NBIOT1_CPSEC_SYMBOL13               ,--: out std_logic_vector(31 downto 0);

        CNT_NBIOT1_CQ_FULL_SYMBOL0  => CNT_NBIOT1_CQ_FULL_SYMBOL0              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL1  => CNT_NBIOT1_CQ_FULL_SYMBOL1              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL2  => CNT_NBIOT1_CQ_FULL_SYMBOL2              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL3  => CNT_NBIOT1_CQ_FULL_SYMBOL3              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL4  => CNT_NBIOT1_CQ_FULL_SYMBOL4              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL5  => CNT_NBIOT1_CQ_FULL_SYMBOL5              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL6  => CNT_NBIOT1_CQ_FULL_SYMBOL6              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL7  => CNT_NBIOT1_CQ_FULL_SYMBOL7              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL8  => CNT_NBIOT1_CQ_FULL_SYMBOL8              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL9  => CNT_NBIOT1_CQ_FULL_SYMBOL9              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL10 => CNT_NBIOT1_CQ_FULL_SYMBOL10             ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL11 => CNT_NBIOT1_CQ_FULL_SYMBOL11             ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL12 => CNT_NBIOT1_CQ_FULL_SYMBOL12             ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT1_CQ_FULL_SYMBOL13 => CNT_NBIOT1_CQ_FULL_SYMBOL13             ,--: out std_logic_vector(31 downto 0);

        USAGE_NBIOT1_CQ_SYMBOL0     => USAGE_NBIOT1_CQ_SYMBOL0                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL1     => USAGE_NBIOT1_CQ_SYMBOL1                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL2     => USAGE_NBIOT1_CQ_SYMBOL2                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL3     => USAGE_NBIOT1_CQ_SYMBOL3                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL4     => USAGE_NBIOT1_CQ_SYMBOL4                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL5     => USAGE_NBIOT1_CQ_SYMBOL5                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL6     => USAGE_NBIOT1_CQ_SYMBOL6                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL7     => USAGE_NBIOT1_CQ_SYMBOL7                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL8     => USAGE_NBIOT1_CQ_SYMBOL8                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL9     => USAGE_NBIOT1_CQ_SYMBOL9                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL10    => USAGE_NBIOT1_CQ_SYMBOL10                ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL11    => USAGE_NBIOT1_CQ_SYMBOL11                ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL12    => USAGE_NBIOT1_CQ_SYMBOL12                ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT1_CQ_SYMBOL13    => USAGE_NBIOT1_CQ_SYMBOL13                ,--: out std_logic_vector(31 downto 0);

        CNT_NBIOT2_TERMINATION      => CNT_NBIOT2_TERMINATION                  ,--: out std_logic_vector(31 downto 0);

        CNT_NBIOT2_CPSEC_SYMBOL0    => CNT_NBIOT2_CPSEC_SYMBOL0                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL1    => CNT_NBIOT2_CPSEC_SYMBOL1                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL2    => CNT_NBIOT2_CPSEC_SYMBOL2                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL3    => CNT_NBIOT2_CPSEC_SYMBOL3                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL4    => CNT_NBIOT2_CPSEC_SYMBOL4                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL5    => CNT_NBIOT2_CPSEC_SYMBOL5                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL6    => CNT_NBIOT2_CPSEC_SYMBOL6                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL7    => CNT_NBIOT2_CPSEC_SYMBOL7                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL8    => CNT_NBIOT2_CPSEC_SYMBOL8                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL9    => CNT_NBIOT2_CPSEC_SYMBOL9                ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL10   => CNT_NBIOT2_CPSEC_SYMBOL10               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL11   => CNT_NBIOT2_CPSEC_SYMBOL11               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL12   => CNT_NBIOT2_CPSEC_SYMBOL12               ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CPSEC_SYMBOL13   => CNT_NBIOT2_CPSEC_SYMBOL13               ,--: out std_logic_vector(31 downto 0);

        CNT_NBIOT2_CQ_FULL_SYMBOL0  => CNT_NBIOT2_CQ_FULL_SYMBOL0              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL1  => CNT_NBIOT2_CQ_FULL_SYMBOL1              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL2  => CNT_NBIOT2_CQ_FULL_SYMBOL2              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL3  => CNT_NBIOT2_CQ_FULL_SYMBOL3              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL4  => CNT_NBIOT2_CQ_FULL_SYMBOL4              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL5  => CNT_NBIOT2_CQ_FULL_SYMBOL5              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL6  => CNT_NBIOT2_CQ_FULL_SYMBOL6              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL7  => CNT_NBIOT2_CQ_FULL_SYMBOL7              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL8  => CNT_NBIOT2_CQ_FULL_SYMBOL8              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL9  => CNT_NBIOT2_CQ_FULL_SYMBOL9              ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL10 => CNT_NBIOT2_CQ_FULL_SYMBOL10             ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL11 => CNT_NBIOT2_CQ_FULL_SYMBOL11             ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL12 => CNT_NBIOT2_CQ_FULL_SYMBOL12             ,--: out std_logic_vector(31 downto 0);
        CNT_NBIOT2_CQ_FULL_SYMBOL13 => CNT_NBIOT2_CQ_FULL_SYMBOL13             ,--: out std_logic_vector(31 downto 0);

        USAGE_NBIOT2_CQ_SYMBOL0     => USAGE_NBIOT2_CQ_SYMBOL0                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL1     => USAGE_NBIOT2_CQ_SYMBOL1                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL2     => USAGE_NBIOT2_CQ_SYMBOL2                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL3     => USAGE_NBIOT2_CQ_SYMBOL3                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL4     => USAGE_NBIOT2_CQ_SYMBOL4                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL5     => USAGE_NBIOT2_CQ_SYMBOL5                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL6     => USAGE_NBIOT2_CQ_SYMBOL6                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL7     => USAGE_NBIOT2_CQ_SYMBOL7                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL8     => USAGE_NBIOT2_CQ_SYMBOL8                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL9     => USAGE_NBIOT2_CQ_SYMBOL9                 ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL10    => USAGE_NBIOT2_CQ_SYMBOL10                ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL11    => USAGE_NBIOT2_CQ_SYMBOL11                ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL12    => USAGE_NBIOT2_CQ_SYMBOL12                ,--: out std_logic_vector(31 downto 0);
        USAGE_NBIOT2_CQ_SYMBOL13    => USAGE_NBIOT2_CQ_SYMBOL13                ,--: out std_logic_vector(31 downto 0);

        C_PLANE_VALID               => C_PLANE_VALID                           ,--: in  std_logic;
        C_PLANE_LAST                => C_PLANE_LAST                            ,--: in  std_logic;
        C_PLANE_KEEP                => C_PLANE_KEEP                            ,--: in  std_logic_vector(3 downto 0);
        C_PLANE_DATA                => C_PLANE_DATA                            ,--: in  std_logic_vector(31 downto 0);
        C_PLANE_CH                  => C_PLANE_CH                              ,--: in  std_logic_vector(2 downto 0);
        C_PLANE_CH_SUB              => C_PLANE_CH_SUB                          ,--: in  std_logic_vector(3 downto 0);

        FREQ_OFFSET_FOR_PRACH       => freq_offset_for_prach                   ,--: in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_eMTC        => freq_offset_for_emtc                    ,--: in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPRACH      => freq_offset_for_nprach                  ,--: in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPUSCH0     => freq_offset_for_npusch0                 ,--: in  std_logic_array24(7 downto 0);
        FREQ_OFFSET_FOR_NPUSCH1     => freq_offset_for_npusch1                 ,--: in  std_logic_array24(7 downto 0);

        ULFE_UPDATE                 => puxch_update                            ,--: in  std_logic;

        ULFE_FRAME_ID               => ULFE_FRAME_ID                           ,--: in  std_logic_vector(7 downto 0);
        ULFE_SUBFRAME_ID            => ULFE_SUBFRAME_ID                        ,--: in  std_logic_vector(3 downto 0);
        ULFE_SLOT_ID                => ULFE_SLOT_ID                            ,--: in  std_logic_vector(5 downto 0);
        ULFE_SYMBOL_ID              => ULFE_SYMBOL_ID                          ,--: in  std_logic_vector(5 downto 0);

        PUxCH_INIT                  => puxch_init                              ,--: out std_logic;
        PUxCH_PACKING_TICK          => puxch_packing_tick                      ,--: out std_logic_vector(3 downto 0);

        PUxCH_RTCPC_ID              => puxch_rtcpc_id                          ,--: out std_logic_vector(15 downto 0);

        PUxCH_DATA_DIRECTION        => puxch_data_direction                    ,--: out std_logic;
        PUxCH_PAYLOAD_VERSION       => puxch_payload_version                   ,--: out std_logic_vector(2 downto 0);
        PUxCH_FILTER_INDEX          => puxch_filter_index                      ,--: out std_logic_vector(3 downto 0);
        PUxCH_FRAME_ID              => puxch_frame_id                          ,--: out std_logic_vector(7 downto 0);
        PUxCH_SUBFRAME_ID           => puxch_subframe_id                       ,--: out std_logic_vector(3 downto 0);
        PUxCH_SLOT_ID               => puxch_slot_id                           ,--: out std_logic_vector(5 downto 0);
        PUxCH_SYMBOL_ID             => puxch_symbol_id                         ,--: out std_logic_vector(5 downto 0);

        PUxCH_SECTION_TICK          => puxch_section_tick                      ,--: out std_logic_vector(3 downto 0);
        PUxCH_SECTION_LAST          => puxch_section_last                      ,--: out std_logic_vector(3 downto 0);
        PUxCH_SECTION_DONE          => puxch_section_done                      ,--: in  std_logic_vector(3 downto 0);

        PUxCH_SECTION_ID            => puxch_section_id                        ,--: out std_logic_vector(11 downto 0);
        PUxCH_USE_EVERY_PRB         => puxch_use_every_prb                     ,--: out std_logic;
        PUxCH_START_OF_PRB          => puxch_start_of_prb                      ,--: out std_logic_vector(9 downto 0);
        PUxCH_OFFSET_OF_PRB         => open                                    ,--: out std_logic_vector(9 downto 0);
        PUxCH_NUMBER_OF_PRB         => puxch_number_of_prb                     ,--: out std_logic_vector(9 downto 0);
        PUxCH_UD_COMP_HDR           => puxch_ud_comp_hdr                       ,--: out std_logic_vector(7 downto 0);

        RAFE0_UPDATE                => prach0_update                           ,--: in  std_logic;

        RAFE0_FRAME_ID              => RAFE_FRAME_ID                           ,--: in  std_logic_vector(7 downto 0);
        RAFE0_SUBFRAME_ID           => RAFE_SUBFRAME_ID                        ,--: in  std_logic_vector(3 downto 0);
        RAFE0_SLOT_ID               => RAFE_SLOT_ID                            ,--: in  std_logic_vector(5 downto 0);
        RAFE0_SYMBOL_ID             => RAFE_SYMBOL_ID                          ,--: in  std_logic_vector(5 downto 0);
        RAFE0_CHANNEL_ID            => prach0_channel_id                       ,--: in  std_logic_vector(2 downto 0);

        PRACH_INIT                  => prach0_init                             ,--: out std_logic;
        PRACH_PACKING_TICK          => prach0_packing_tick                     ,--: out std_logic_vector(3 downto 0);

        PRACH_RTCPC_ID              => prach0_rtcpc_id                         ,--: out std_logic_vector(15 downto 0);

        PRACH_DATA_DIRECTION        => prach0_data_direction                   ,--: out std_logic;
        PRACH_PAYLOAD_VERSION       => prach0_payload_version                  ,--: out std_logic_vector(2 downto 0);
        PRACH_FILTER_INDEX          => prach0_filter_index                     ,--: out std_logic_vector(3 downto 0);
        PRACH_FRAME_ID              => prach0_frame_id                         ,--: out std_logic_vector(7 downto 0);
        PRACH_SUBFRAME_ID           => prach0_subframe_id                      ,--: out std_logic_vector(3 downto 0);
        PRACH_SLOT_ID               => prach0_slot_id                          ,--: out std_logic_vector(5 downto 0);
        PRACH_SYMBOL_ID             => prach0_symbol_id                        ,--: out std_logic_vector(5 downto 0);

        PRACH_SECTION_TICK          => prach0_section_tick                     ,--: out std_logic_vector(3 downto 0);
        PRACH_SECTION_LAST          => prach0_section_last                     ,--: out std_logic_vector(3 downto 0);
        PRACH_SECTION_DONE          => prach0_section_done                     ,--: in  std_logic_vector(3 downto 0);

        PRACH_SECTION_ID            => prach0_section_id                       ,--: out std_logic_vector(11 downto 0);
        PRACH_USE_EVERY_PRB         => prach0_use_every_prb                    ,--: out std_logic;
        PRACH_START_OF_PRB          => prach0_start_of_prb                     ,--: out std_logic_vector(9 downto 0);
        PRACH_OFFSET_OF_PRB         => prach0_offset_of_prb                    ,--: out std_logic_vector(9 downto 0);
        PRACH_NUMBER_OF_PRB         => prach0_number_of_prb                    ,--: out std_logic_vector(9 downto 0);
        PRACH_UD_COMP_HDR           => prach0_ud_comp_hdr                      ,--: out std_logic_vector(7 downto 0);

        RAFE1_UPDATE                => prach1_update                           ,--: in  std_logic;

        RAFE1_FRAME_ID              => eMTC_FRAME_ID                           ,--: in  std_logic_vector(7 downto 0);
        RAFE1_SUBFRAME_ID           => eMTC_SUBFRAME_ID                        ,--: in  std_logic_vector(3 downto 0);
        RAFE1_SLOT_ID               => eMTC_SLOT_ID                            ,--: in  std_logic_vector(5 downto 0);
        RAFE1_SYMBOL_ID             => eMTC_SYMBOL_ID                          ,--: in  std_logic_vector(5 downto 0);
        RAFE1_CHANNEL_ID            => prach1_channel_id                       ,--: in  std_logic_vector(2 downto 0);

        eMTC_INIT                   => prach1_init                             ,--: out std_logic;
        eMTC_PACKING_TICK           => prach1_packing_tick                     ,--: out std_logic_vector(3 downto 0);

        eMTC_RTCPC_ID               => prach1_rtcpc_id                         ,--: out std_logic_vector(15 downto 0);

        eMTC_DATA_DIRECTION         => prach1_data_direction                   ,--: out std_logic;
        eMTC_PAYLOAD_VERSION        => prach1_payload_version                  ,--: out std_logic_vector(2 downto 0);
        eMTC_FILTER_INDEX           => prach1_filter_index                     ,--: out std_logic_vector(3 downto 0);
        eMTC_FRAME_ID               => prach1_frame_id                         ,--: out std_logic_vector(7 downto 0);
        eMTC_SUBFRAME_ID            => prach1_subframe_id                      ,--: out std_logic_vector(3 downto 0);
        eMTC_SLOT_ID                => prach1_slot_id                          ,--: out std_logic_vector(5 downto 0);
        eMTC_SYMBOL_ID              => prach1_symbol_id                        ,--: out std_logic_vector(5 downto 0);

        eMTC_SECTION_TICK           => prach1_section_tick                     ,--: out std_logic_vector(3 downto 0);
        eMTC_SECTION_LAST           => prach1_section_last                     ,--: out std_logic_vector(3 downto 0);
        eMTC_SECTION_DONE           => prach1_section_done                     ,--: in  std_logic_vector(3 downto 0);

        eMTC_SECTION_ID             => prach1_section_id                       ,--: out std_logic_vector(11 downto 0);
        eMTC_USE_EVERY_PRB          => prach1_use_every_prb                    ,--: out std_logic;
        eMTC_START_OF_PRB           => prach1_start_of_prb                     ,--: out std_logic_vector(9 downto 0);
        eMTC_OFFSET_OF_PRB          => prach1_offset_of_prb                    ,--: out std_logic_vector(9 downto 0);
        eMTC_NUMBER_OF_PRB          => prach1_number_of_prb                    ,--: out std_logic_vector(9 downto 0);
        eMTC_UD_COMP_HDR            => prach1_ud_comp_hdr                      ,--: out std_logic_vector(7 downto 0);

        NBFE0_UPDATE                => nbiot0_update                           ,--: in  std_logic;

        NBFE0_FRAME_ID              => NBFE0_FRAME_ID                          ,--: in  std_logic_vector(7 downto 0);
        NBFE0_SUBFRAME_ID           => NBFE0_SUBFRAME_ID                       ,--: in  std_logic_vector(3 downto 0);
        NBFE0_SLOT_ID               => NBFE0_SLOT_ID                           ,--: in  std_logic_vector(5 downto 0);
        NBFE0_SYMBOL_ID             => NBFE0_SYMBOL_ID                         ,--: in  std_logic_vector(5 downto 0);
        NBFE0_CHANNEL_ID            => nbiot0_channel_id                       ,--: in  std_logic_vector(2 downto 0);

        NBIOT0_INIT                 => nbiot0_init                             ,--: out std_logic;
        NBIOT0_PACKING_TICK         => nbiot0_packing_tick                     ,--: out std_logic_vector(3 downto 0);

        NBIOT0_RTCPC_ID             => nbiot0_rtcpc_id                         ,--: out std_logic_vector(15 downto 0);

        NBIOT0_DATA_DIRECTION       => nbiot0_data_direction                   ,--: out std_logic;
        NBIOT0_PAYLOAD_VERSION      => nbiot0_payload_version                  ,--: out std_logic_vector(2 downto 0);
        NBIOT0_FILTER_INDEX         => nbiot0_filter_index                     ,--: out std_logic_vector(3 downto 0);
        NBIOT0_FRAME_ID             => nbiot0_frame_id                         ,--: out std_logic_vector(7 downto 0);
        NBIOT0_SUBFRAME_ID          => nbiot0_subframe_id                      ,--: out std_logic_vector(3 downto 0);
        NBIOT0_SLOT_ID              => nbiot0_slot_id                          ,--: out std_logic_vector(5 downto 0);
        NBIOT0_SYMBOL_ID            => nbiot0_symbol_id                        ,--: out std_logic_vector(5 downto 0);

        NBIOT0_SECTION_TICK         => nbiot0_section_tick                     ,--: out std_logic_vector(3 downto 0);
        NBIOT0_SECTION_LAST         => nbiot0_section_last                     ,--: out std_logic_vector(3 downto 0);
        NBIOT0_SECTION_DONE         => nbiot0_section_done                     ,--: in  std_logic_vector(3 downto 0);

        NBIOT0_SECTION_ID           => nbiot0_section_id                       ,--: out std_logic_vector(11 downto 0);
        NBIOT0_USE_EVERY_PRB        => nbiot0_use_every_prb                    ,--: out std_logic;
        NBIOT0_START_OF_PRB         => nbiot0_start_of_prb                     ,--: out std_logic_vector(9 downto 0);
        NBIOT0_OFFSET_OF_PRB        => nbiot0_offset_of_prb                    ,--: out std_logic_vector(9 downto 0);
        NBIOT0_NUMBER_OF_PRB        => nbiot0_number_of_prb                    ,--: out std_logic_vector(9 downto 0);
        NBIOT0_UD_COMP_HDR          => nbiot0_ud_comp_hdr                      ,--: out std_logic_vector(7 downto 0);

        NBFE1_UPDATE                => nbiot1_update                           ,--: in  std_logic;

        NBFE1_FRAME_ID              => NBFE1_FRAME_ID                          ,--: in  std_logic_vector(7 downto 0);
        NBFE1_SUBFRAME_ID           => NBFE1_SUBFRAME_ID                       ,--: in  std_logic_vector(3 downto 0);
        NBFE1_SLOT_ID               => NBFE1_SLOT_ID                           ,--: in  std_logic_vector(5 downto 0);
        NBFE1_SYMBOL_ID             => NBFE1_SYMBOL_ID                         ,--: in  std_logic_vector(5 downto 0);
        NBFE1_CHANNEL_ID            => nbiot1_channel_id                       ,--: in  std_logic_vector(2 downto 0);

        NBIOT1_INIT                 => nbiot1_init                             ,--: out std_logic;
        NBIOT1_PACKING_TICK         => nbiot1_packing_tick                     ,--: out std_logic_vector(3 downto 0);

        NBIOT1_RTCPC_ID             => nbiot1_rtcpc_id                         ,--: out std_logic_vector(15 downto 0);

        NBIOT1_DATA_DIRECTION       => nbiot1_data_direction                   ,--: out std_logic;
        NBIOT1_PAYLOAD_VERSION      => nbiot1_payload_version                  ,--: out std_logic_vector(2 downto 0);
        NBIOT1_FILTER_INDEX         => nbiot1_filter_index                     ,--: out std_logic_vector(3 downto 0);
        NBIOT1_FRAME_ID             => nbiot1_frame_id                         ,--: out std_logic_vector(7 downto 0);
        NBIOT1_SUBFRAME_ID          => nbiot1_subframe_id                      ,--: out std_logic_vector(3 downto 0);
        NBIOT1_SLOT_ID              => nbiot1_slot_id                          ,--: out std_logic_vector(5 downto 0);
        NBIOT1_SYMBOL_ID            => nbiot1_symbol_id                        ,--: out std_logic_vector(5 downto 0);

        NBIOT1_SECTION_TICK         => nbiot1_section_tick                     ,--: out std_logic_vector(3 downto 0);
        NBIOT1_SECTION_LAST         => nbiot1_section_last                     ,--: out std_logic_vector(3 downto 0);
        NBIOT1_SECTION_DONE         => nbiot1_section_done                     ,--: in  std_logic_vector(3 downto 0);

        NBIOT1_SECTION_ID           => nbiot1_section_id                       ,--: out std_logic_vector(11 downto 0);
        NBIOT1_USE_EVERY_PRB        => nbiot1_use_every_prb                    ,--: out std_logic;
        NBIOT1_START_OF_PRB         => nbiot1_start_of_prb                     ,--: out std_logic_vector(9 downto 0);
        NBIOT1_OFFSET_OF_PRB        => nbiot1_offset_of_prb                    ,--: out std_logic_vector(9 downto 0);
        NBIOT1_NUMBER_OF_PRB        => nbiot1_number_of_prb                    ,--: out std_logic_vector(9 downto 0);
        NBIOT1_UD_COMP_HDR          => nbiot1_ud_comp_hdr                      ,--: out std_logic_vector(7 downto 0);

        NBFE2_UPDATE                => nbiot2_update                           ,--: in  std_logic;

        NBFE2_FRAME_ID              => NBFE2_FRAME_ID                          ,--: in  std_logic_vector(7 downto 0);
        NBFE2_SUBFRAME_ID           => NBFE2_SUBFRAME_ID                       ,--: in  std_logic_vector(3 downto 0);
        NBFE2_SLOT_ID               => NBFE2_SLOT_ID                           ,--: in  std_logic_vector(5 downto 0);
        NBFE2_SYMBOL_ID             => NBFE2_SYMBOL_ID                         ,--: in  std_logic_vector(5 downto 0);
        NBFE2_CHANNEL_ID            => nbiot2_channel_id                       ,--: in  std_logic_vector(2 downto 0);

        NBIOT2_INIT                 => nbiot2_init                             ,--: out std_logic;
        NBIOT2_PACKING_TICK         => nbiot2_packing_tick                     ,--: out std_logic_vector(3 downto 0);

        NBIOT2_RTCPC_ID             => nbiot2_rtcpc_id                         ,--: out std_logic_vector(15 downto 0);

        NBIOT2_DATA_DIRECTION       => nbiot2_data_direction                   ,--: out std_logic;
        NBIOT2_PAYLOAD_VERSION      => nbiot2_payload_version                  ,--: out std_logic_vector(2 downto 0);
        NBIOT2_FILTER_INDEX         => nbiot2_filter_index                     ,--: out std_logic_vector(3 downto 0);
        NBIOT2_FRAME_ID             => nbiot2_frame_id                         ,--: out std_logic_vector(7 downto 0);
        NBIOT2_SUBFRAME_ID          => nbiot2_subframe_id                      ,--: out std_logic_vector(3 downto 0);
        NBIOT2_SLOT_ID              => nbiot2_slot_id                          ,--: out std_logic_vector(5 downto 0);
        NBIOT2_SYMBOL_ID            => nbiot2_symbol_id                        ,--: out std_logic_vector(5 downto 0);

        NBIOT2_SECTION_TICK         => nbiot2_section_tick                     ,--: out std_logic_vector(3 downto 0);
        NBIOT2_SECTION_LAST         => nbiot2_section_last                     ,--: out std_logic_vector(3 downto 0);
        NBIOT2_SECTION_DONE         => nbiot2_section_done                     ,--: in  std_logic_vector(3 downto 0);

        NBIOT2_SECTION_ID           => nbiot2_section_id                       ,--: out std_logic_vector(11 downto 0);
        NBIOT2_USE_EVERY_PRB        => nbiot2_use_every_prb                    ,--: out std_logic;
        NBIOT2_START_OF_PRB         => nbiot2_start_of_prb                     ,--: out std_logic_vector(9 downto 0);
        NBIOT2_OFFSET_OF_PRB        => nbiot2_offset_of_prb                    ,--: out std_logic_vector(9 downto 0);
        NBIOT2_NUMBER_OF_PRB        => nbiot2_number_of_prb                    ,--: out std_logic_vector(9 downto 0);
        NBIOT2_UD_COMP_HDR          => nbiot2_ud_comp_hdr                       --: out std_logic_vector(7 downto 0)
    );

    u_PARAMETER : UL_PARAM0
    generic map(
        MAX_CH                      => 4                                        --: natural := 8
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => reset                                   ,--: in  std_logic;

        PUxCH_INIT                  => puxch_init                              ,--: in  std_logic;
        PUxCH_PACKING_TICK          => puxch_packing_tick                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_RTCPC_ID              => puxch_rtcpc_id                          ,--: in  std_logic_vector(15 downto 0);

        PUxCH_DATA_DIRECTION        => puxch_data_direction                    ,--: in  std_logic;
        PUxCH_PAYLOAD_VERSION       => puxch_payload_version                   ,--: in  std_logic_vector(2 downto 0);
        PUxCH_FILTER_INDEX          => puxch_filter_index                      ,--: in  std_logic_vector(3 downto 0);
        PUxCH_FRAME_ID              => puxch_frame_id                          ,--: in  std_logic_vector(7 downto 0);
        PUxCH_SUBFRAME_ID           => puxch_subframe_id                       ,--: in  std_logic_vector(3 downto 0);
        PUxCH_SLOT_ID               => puxch_slot_id                           ,--: in  std_logic_vector(5 downto 0);
        PUxCH_SYMBOL_ID             => puxch_symbol_id                         ,--: in  std_logic_vector(5 downto 0);

        PUxCH_SECTION_TICK          => puxch_section_tick                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_SECTION_ID            => puxch_section_id                        ,--: in  std_logic_vector(11 downto 0);
        PUxCH_USE_EVERY_PRB         => puxch_use_every_prb                     ,--: in  std_logic;
        PUxCH_START_OF_PRB          => puxch_start_of_prb                      ,--: in  std_logic_vector(9 downto 0);
        PUxCH_NUMBER_OF_PRB         => puxch_number_of_prb                     ,--: in  std_logic_vector(9 downto 0);

        PUxCH_RB_INIT               => PUxCH_RB_INIT                           ,--: out std_logic;
        PUxCH_RB_eAxC_ID            => PUxCH_RB_eAxC_ID                        ,--: out std_logic_vector(15 downto 0);
        PUxCH_RB_SEQUENCE_ID        => PUxCH_RB_SEQUENCE_ID                    ,--: out std_logic_vector(15 downto 0);
        PUxCH_RB_HEADER_APP         => PUxCH_RB_HEADER_APP                     ,--: out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_APP_ACK     => PUxCH_RB_HEADER_APP_ACK                 ,--: in  std_logic;
        PUxCH_RB_HEADER_SEC         => PUxCH_RB_HEADER_SEC                     ,--: out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_SEC_ACK     => PUxCH_RB_HEADER_SEC_ACK                 ,--: in  std_logic;

        PRACH_INIT                  => prach0_init                             ,--: in  std_logic;
        PRACH_PACKING_TICK          => prach0_packing_tick                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        PRACH_RTCPC_ID              => prach0_rtcpc_id                         ,--: in  std_logic_vector(15 downto 0);

        PRACH_DATA_DIRECTION        => prach0_data_direction                   ,--: in  std_logic;
        PRACH_PAYLOAD_VERSION       => prach0_payload_version                  ,--: in  std_logic_vector(2 downto 0);
        PRACH_FILTER_INDEX          => prach0_filter_index                     ,--: in  std_logic_vector(3 downto 0);
        PRACH_FRAME_ID              => prach0_frame_id                         ,--: in  std_logic_vector(7 downto 0);
        PRACH_SUBFRAME_ID           => prach0_subframe_id                      ,--: in  std_logic_vector(3 downto 0);
        PRACH_SLOT_ID               => prach0_slot_id                          ,--: in  std_logic_vector(5 downto 0);
        PRACH_SYMBOL_ID             => prach0_symbol_id                        ,--: in  std_logic_vector(5 downto 0);

        PRACH_SECTION_TICK          => prach0_section_tick                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        PRACH_SECTION_ID            => prach0_section_id                       ,--: in  std_logic_vector(11 downto 0);
        PRACH_USE_EVERY_PRB         => prach0_use_every_prb                    ,--: in  std_logic;
        PRACH_START_OF_PRB          => prach0_start_of_prb                     ,--: in  std_logic_vector(9 downto 0);
        PRACH_NUMBER_OF_PRB         => prach0_number_of_prb                    ,--: in  std_logic_vector(9 downto 0);

        PRACH_RB_INIT               => PRACH_RB_INIT                           ,--: out std_logic;
        PRACH_RB_eAxC_ID            => PRACH_RB_eAxC_ID                        ,--: out std_logic_vector(15 downto 0);
        PRACH_RB_SEQUENCE_ID        => PRACH_RB_SEQUENCE_ID                    ,--: out std_logic_vector(15 downto 0);
        PRACH_RB_HEADER_APP         => PRACH_RB_HEADER_APP                     ,--: out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_APP_ACK     => PRACH_RB_HEADER_APP_ACK                 ,--: in  std_logic;
        PRACH_RB_HEADER_SEC         => PRACH_RB_HEADER_SEC                     ,--: out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_SEC_ACK     => PRACH_RB_HEADER_SEC_ACK                 ,--: in  std_logic;

        eMTC_INIT                   => prach1_init                             ,--: in  std_logic;
        eMTC_PACKING_TICK           => prach1_packing_tick                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        eMTC_RTCPC_ID               => prach1_rtcpc_id                         ,--: in  std_logic_vector(15 downto 0);

        eMTC_DATA_DIRECTION         => prach1_data_direction                   ,--: in  std_logic;
        eMTC_PAYLOAD_VERSION        => prach1_payload_version                  ,--: in  std_logic_vector(2 downto 0);
        eMTC_FILTER_INDEX           => prach1_filter_index                     ,--: in  std_logic_vector(3 downto 0);
        eMTC_FRAME_ID               => prach1_frame_id                         ,--: in  std_logic_vector(7 downto 0);
        eMTC_SUBFRAME_ID            => prach1_subframe_id                      ,--: in  std_logic_vector(3 downto 0);
        eMTC_SLOT_ID                => prach1_slot_id                          ,--: in  std_logic_vector(5 downto 0);
        eMTC_SYMBOL_ID              => prach1_symbol_id                        ,--: in  std_logic_vector(5 downto 0);

        eMTC_SECTION_TICK           => prach1_section_tick                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        eMTC_SECTION_ID             => prach1_section_id                       ,--: in  std_logic_vector(11 downto 0);
        eMTC_USE_EVERY_PRB          => prach1_use_every_prb                    ,--: in  std_logic;
        eMTC_START_OF_PRB           => prach1_start_of_prb                     ,--: in  std_logic_vector(9 downto 0);
        eMTC_NUMBER_OF_PRB          => prach1_number_of_prb                    ,--: in  std_logic_vector(9 downto 0);

        eMTC_RB_INIT                => eMTC_RB_INIT                            ,--: out std_logic;
        eMTC_RB_eAxC_ID             => eMTC_RB_eAxC_ID                         ,--: out std_logic_vector(15 downto 0);
        eMTC_RB_SEQUENCE_ID         => eMTC_RB_SEQUENCE_ID                     ,--: out std_logic_vector(15 downto 0);
        eMTC_RB_HEADER_APP          => eMTC_RB_HEADER_APP                      ,--: out std_logic_vector(31 downto 0);
        eMTC_RB_HEADER_APP_ACK      => eMTC_RB_HEADER_APP_ACK                  ,--: in  std_logic;
        eMTC_RB_HEADER_SEC          => eMTC_RB_HEADER_SEC                      ,--: out std_logic_vector(31 downto 0);
        eMTC_RB_HEADER_SEC_ACK      => eMTC_RB_HEADER_SEC_ACK                  ,--: in  std_logic;

        NBIOT0_INIT                 => nbiot0_init                             ,--: in  std_logic;
        NBIOT0_PACKING_TICK         => nbiot0_packing_tick                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT0_RTCPC_ID             => nbiot0_rtcpc_id                         ,--: in  std_logic_vector(15 downto 0);

        NBIOT0_DATA_DIRECTION       => nbiot0_data_direction                   ,--: in  std_logic;
        NBIOT0_PAYLOAD_VERSION      => nbiot0_payload_version                  ,--: in  std_logic_vector(2 downto 0);
        NBIOT0_FILTER_INDEX         => nbiot0_filter_index                     ,--: in  std_logic_vector(3 downto 0);
        NBIOT0_FRAME_ID             => nbiot0_frame_id                         ,--: in  std_logic_vector(7 downto 0);
        NBIOT0_SUBFRAME_ID          => nbiot0_subframe_id                      ,--: in  std_logic_vector(3 downto 0);
        NBIOT0_SLOT_ID              => nbiot0_slot_id                          ,--: in  std_logic_vector(5 downto 0);
        NBIOT0_SYMBOL_ID            => nbiot0_symbol_id                        ,--: in  std_logic_vector(5 downto 0);

        NBIOT0_SECTION_TICK         => nbiot0_section_tick                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT0_SECTION_ID           => nbiot0_section_id                       ,--: in  std_logic_vector(11 downto 0);
        NBIOT0_USE_EVERY_PRB        => nbiot0_use_every_prb                    ,--: in  std_logic;
        NBIOT0_START_OF_PRB         => nbiot0_start_of_prb                     ,--: in  std_logic_vector(9 downto 0);
        NBIOT0_NUMBER_OF_PRB        => nbiot0_number_of_prb                    ,--: in  std_logic_vector(9 downto 0);

        NBIOT0_RB_INIT              => NBIOT0_RB_INIT                          ,--: out std_logic;
        NBIOT0_RB_eAxC_ID           => NBIOT0_RB_eAxC_ID                       ,--: out std_logic_vector(15 downto 0);
        NBIOT0_RB_SEQUENCE_ID       => NBIOT0_RB_SEQUENCE_ID                   ,--: out std_logic_vector(15 downto 0);
        NBIOT0_RB_HEADER_APP        => NBIOT0_RB_HEADER_APP                    ,--: out std_logic_vector(31 downto 0);
        NBIOT0_RB_HEADER_APP_ACK    => NBIOT0_RB_HEADER_APP_ACK                ,--: in  std_logic;
        NBIOT0_RB_HEADER_SEC        => NBIOT0_RB_HEADER_SEC                    ,--: out std_logic_vector(31 downto 0);
        NBIOT0_RB_HEADER_SEC_ACK    => NBIOT0_RB_HEADER_SEC_ACK                ,--: in  std_logic;

        NBIOT1_INIT                 => nbiot1_init                             ,--: in  std_logic;
        NBIOT1_PACKING_TICK         => nbiot1_packing_tick                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT1_RTCPC_ID             => nbiot1_rtcpc_id                         ,--: in  std_logic_vector(15 downto 0);

        NBIOT1_DATA_DIRECTION       => nbiot1_data_direction                   ,--: in  std_logic;
        NBIOT1_PAYLOAD_VERSION      => nbiot1_payload_version                  ,--: in  std_logic_vector(2 downto 0);
        NBIOT1_FILTER_INDEX         => nbiot1_filter_index                     ,--: in  std_logic_vector(3 downto 0);
        NBIOT1_FRAME_ID             => nbiot1_frame_id                         ,--: in  std_logic_vector(7 downto 0);
        NBIOT1_SUBFRAME_ID          => nbiot1_subframe_id                      ,--: in  std_logic_vector(3 downto 0);
        NBIOT1_SLOT_ID              => nbiot1_slot_id                          ,--: in  std_logic_vector(5 downto 0);
        NBIOT1_SYMBOL_ID            => nbiot1_symbol_id                        ,--: in  std_logic_vector(5 downto 0);

        NBIOT1_SECTION_TICK         => nbiot1_section_tick                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT1_SECTION_ID           => nbiot1_section_id                       ,--: in  std_logic_vector(11 downto 0);
        NBIOT1_USE_EVERY_PRB        => nbiot1_use_every_prb                    ,--: in  std_logic;
        NBIOT1_START_OF_PRB         => nbiot1_start_of_prb                     ,--: in  std_logic_vector(9 downto 0);
        NBIOT1_NUMBER_OF_PRB        => nbiot1_number_of_prb                    ,--: in  std_logic_vector(9 downto 0);

        NBIOT1_RB_INIT              => NBIOT1_RB_INIT                          ,--: out std_logic;
        NBIOT1_RB_eAxC_ID           => NBIOT1_RB_eAxC_ID                       ,--: out std_logic_vector(15 downto 0);
        NBIOT1_RB_SEQUENCE_ID       => NBIOT1_RB_SEQUENCE_ID                   ,--: out std_logic_vector(15 downto 0);
        NBIOT1_RB_HEADER_APP        => NBIOT1_RB_HEADER_APP                    ,--: out std_logic_vector(31 downto 0);
        NBIOT1_RB_HEADER_APP_ACK    => NBIOT1_RB_HEADER_APP_ACK                ,--: in  std_logic;
        NBIOT1_RB_HEADER_SEC        => NBIOT1_RB_HEADER_SEC                    ,--: out std_logic_vector(31 downto 0);
        NBIOT1_RB_HEADER_SEC_ACK    => NBIOT1_RB_HEADER_SEC_ACK                ,--: in  std_logic;

        NBIOT2_INIT                 => nbiot2_init                             ,--: in  std_logic;
        NBIOT2_PACKING_TICK         => nbiot2_packing_tick                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT2_RTCPC_ID             => nbiot2_rtcpc_id                         ,--: in  std_logic_vector(15 downto 0);

        NBIOT2_DATA_DIRECTION       => nbiot2_data_direction                   ,--: in  std_logic;
        NBIOT2_PAYLOAD_VERSION      => nbiot2_payload_version                  ,--: in  std_logic_vector(2 downto 0);
        NBIOT2_FILTER_INDEX         => nbiot2_filter_index                     ,--: in  std_logic_vector(3 downto 0);
        NBIOT2_FRAME_ID             => nbiot2_frame_id                         ,--: in  std_logic_vector(7 downto 0);
        NBIOT2_SUBFRAME_ID          => nbiot2_subframe_id                      ,--: in  std_logic_vector(3 downto 0);
        NBIOT2_SLOT_ID              => nbiot2_slot_id                          ,--: in  std_logic_vector(5 downto 0);
        NBIOT2_SYMBOL_ID            => nbiot2_symbol_id                        ,--: in  std_logic_vector(5 downto 0);

        NBIOT2_SECTION_TICK         => nbiot2_section_tick                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT2_SECTION_ID           => nbiot2_section_id                       ,--: in  std_logic_vector(11 downto 0);
        NBIOT2_USE_EVERY_PRB        => nbiot2_use_every_prb                    ,--: in  std_logic;
        NBIOT2_START_OF_PRB         => nbiot2_start_of_prb                     ,--: in  std_logic_vector(9 downto 0);
        NBIOT2_NUMBER_OF_PRB        => nbiot2_number_of_prb                    ,--: in  std_logic_vector(9 downto 0);

        NBIOT2_RB_INIT              => NBIOT2_RB_INIT                          ,--: out std_logic;
        NBIOT2_RB_eAxC_ID           => NBIOT2_RB_eAxC_ID                       ,--: out std_logic_vector(15 downto 0);
        NBIOT2_RB_SEQUENCE_ID       => NBIOT2_RB_SEQUENCE_ID                   ,--: out std_logic_vector(15 downto 0);
        NBIOT2_RB_HEADER_APP        => NBIOT2_RB_HEADER_APP                    ,--: out std_logic_vector(31 downto 0);
        NBIOT2_RB_HEADER_APP_ACK    => NBIOT2_RB_HEADER_APP_ACK                ,--: in  std_logic;
        NBIOT2_RB_HEADER_SEC        => NBIOT2_RB_HEADER_SEC                    ,--: out std_logic_vector(31 downto 0);
        NBIOT2_RB_HEADER_SEC_ACK    => NBIOT2_RB_HEADER_SEC_ACK                 --: in  std_logic
    );

    u_PATH : for i in 3 downto 0 generate
    u_TX_WINDOW_PUxCH : UL_TX_WINDOW
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => puxch_init                              ,--: in  std_logic;

        CNT_PACKET_SYMBOL0          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL1          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL2          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL3          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL4          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL5          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL6          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL7          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL8          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL9          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL10         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL11         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL12         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL13         => open                                    ,--: out std_logic_vector(31 downto 0);

        PACKING_TICK                => puxch_packing_tick(i)                   ,--: in  std_logic;

        DATA_DIRECTION              => puxch_data_direction                    ,--: in  std_logic;
        PAYLOAD_VERSION             => puxch_payload_version                   ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => puxch_filter_index                      ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => puxch_frame_id                          ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => puxch_subframe_id                       ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => puxch_slot_id                           ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => puxch_symbol_id                         ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => puxch_section_tick(i)                   ,--: in  std_logic;
        SECTION_LAST                => puxch_section_last(i)                   ,--: in  std_logic;
        SECTION_DONE                => puxch_section_done(i)                   ,--: out std_logic;

        SECTION_ID                  => puxch_section_id                        ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => puxch_use_every_prb                     ,--: in  std_logic;
        START_OF_PRB                => puxch_start_of_prb                      ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => puxch_number_of_prb                     ,--: in  std_logic_vector(9 downto 0);
        UD_COMP_HDR                 => puxch_ud_comp_hdr                       ,--: in  std_logic_vector(7 downto 0);

        UL_FRAME_ID                 => ULFE_FRAME_ID                           ,--: in  std_logic_vector(7 downto 0);
        UL_SUBFRAME_ID              => ULFE_SUBFRAME_ID                        ,--: in  std_logic_vector(3 downto 0);
        UL_SLOT_ID                  => ULFE_SLOT_ID                            ,--: in  std_logic_vector(5 downto 0);
        UL_SYMBOL_ID                => ULFE_SYMBOL_ID                          ,--: in  std_logic_vector(5 downto 0);
        UL_START_RE                 => ULFE_START_RE                           ,--: in  std_logic_vector(15 downto 0);

        UL_VALID                    => ULFE_VALID(i)                           ,--: in  std_logic;
        UL_START                    => ULFE_START(i)                           ,--: in  std_logic;
        UL_LAST                     => ULFE_LAST(i)                            ,--: in  std_logic;
        UL_DATA_I                   => ULFE_DATA_I(i)                          ,--: in  std_logic_vector(15 downto 0);
        UL_DATA_Q                   => ULFE_DATA_Q(i)                          ,--: in  std_logic_vector(15 downto 0);

        RB_COMP_HDR                 => puxch_comp_hdr(i)                       ,--: out std_logic_vector(7 downto 0);

        RB_VALID                    => puxch_valid(i)                          ,--: out std_logic;
        RB_TICK                     => puxch_tick(i)                           ,--: out std_logic;
        RB_DATA_I                   => puxch_data_i(i)                         ,--: out std_logic_vector(15 downto 0);
        RB_DATA_Q                   => puxch_data_q(i)                         ,--: out std_logic_vector(15 downto 0);
        RB_USER                     => puxch_user(i)                            --: out std_logic_vector(15 downto 0)
    );

    u_TX_WINDOW_PRACH : UL_TX_WINDOW_RACH
    generic map(
        LONG_PRACH                  => LONG_PRACH                               --: boolean := true
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => prach0_init                             ,--: in  std_logic;

        CNT_PACKET_SYMBOL0          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL1          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL2          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL3          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL4          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL5          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL6          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL7          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL8          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL9          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL10         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL11         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL12         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL13         => open                                    ,--: out std_logic_vector(31 downto 0);

        PACKING_TICK                => prach0_packing_tick(i)                  ,--: in  std_logic;

        DATA_DIRECTION              => prach0_data_direction                   ,--: in  std_logic;
        PAYLOAD_VERSION             => prach0_payload_version                  ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => prach0_filter_index                     ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => prach0_frame_id                         ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => prach0_subframe_id                      ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => prach0_slot_id                          ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => prach0_symbol_id                        ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => prach0_section_tick(i)                  ,--: in  std_logic;
        SECTION_LAST                => prach0_section_last(i)                  ,--: in  std_logic;
        SECTION_DONE                => prach0_section_done(i)                  ,--: out std_logic;

        SECTION_ID                  => prach0_section_id                       ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => prach0_use_every_prb                    ,--: in  std_logic;
        START_OF_PRB                => prach0_offset_of_prb                    ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => prach0_number_of_prb                    ,--: in  std_logic_vector(9 downto 0);
        UD_COMP_HDR                 => prach0_ud_comp_hdr                      ,--: in  std_logic_vector(7 downto 0);

        UL_FRAME_ID                 => RAFE_FRAME_ID                           ,--: in  std_logic_vector(7 downto 0);
        UL_SUBFRAME_ID              => RAFE_SUBFRAME_ID                        ,--: in  std_logic_vector(3 downto 0);
        UL_SLOT_ID                  => RAFE_SLOT_ID                            ,--: in  std_logic_vector(5 downto 0);
        UL_SYMBOL_ID                => RAFE_SYMBOL_ID                          ,--: in  std_logic_vector(5 downto 0);
        UL_START_RE                 => RAFE_START_RE                           ,--: in  std_logic_vector(15 downto 0);

        UL_VALID                    => RAFE_VALID(i)                           ,--: in  std_logic;
        UL_START                    => RAFE_START(i)                           ,--: in  std_logic;
        UL_LAST                     => RAFE_LAST(i)                            ,--: in  std_logic;
        UL_DATA_I                   => RAFE_DATA_I(i)                          ,--: in  std_logic_vector(15 downto 0);
        UL_DATA_Q                   => RAFE_DATA_Q(i)                          ,--: in  std_logic_vector(15 downto 0);

        RB_COMP_HDR                 => prach0_comp_hdr(i)                      ,--: out std_logic_vector(7 downto 0);

        RB_VALID                    => prach0_valid(i)                         ,--: out std_logic;
        RB_TICK                     => prach0_tick(i)                          ,--: out std_logic;
        RB_DATA_I                   => prach0_data_i(i)                        ,--: out std_logic_vector(15 downto 0);
        RB_DATA_Q                   => prach0_data_q(i)                        ,--: out std_logic_vector(15 downto 0);
        RB_USER                     => prach0_user(i)                           --: out std_logic_vector(15 downto 0)
    );

    u_TX_WINDOW_eMTC : UL_TX_WINDOW_RACH
    generic map(
        LONG_PRACH                  => LONG_PRACH                               --: boolean := true
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => prach1_init                             ,--: in  std_logic;

        CNT_PACKET_SYMBOL0          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL1          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL2          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL3          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL4          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL5          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL6          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL7          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL8          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL9          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL10         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL11         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL12         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL13         => open                                    ,--: out std_logic_vector(31 downto 0);

        PACKING_TICK                => prach1_packing_tick(i)                  ,--: in  std_logic;

        DATA_DIRECTION              => prach1_data_direction                   ,--: in  std_logic;
        PAYLOAD_VERSION             => prach1_payload_version                  ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => prach1_filter_index                     ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => prach1_frame_id                         ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => prach1_subframe_id                      ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => prach1_slot_id                          ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => prach1_symbol_id                        ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => prach1_section_tick(i)                  ,--: in  std_logic;
        SECTION_LAST                => prach1_section_last(i)                  ,--: in  std_logic;
        SECTION_DONE                => prach1_section_done(i)                  ,--: out std_logic;

        SECTION_ID                  => prach1_section_id                       ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => prach1_use_every_prb                    ,--: in  std_logic;
        START_OF_PRB                => prach1_offset_of_prb                    ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => prach1_number_of_prb                    ,--: in  std_logic_vector(9 downto 0);
        UD_COMP_HDR                 => prach1_ud_comp_hdr                      ,--: in  std_logic_vector(7 downto 0);

        UL_FRAME_ID                 => eMTC_FRAME_ID                           ,--: in  std_logic_vector(7 downto 0);
        UL_SUBFRAME_ID              => eMTC_SUBFRAME_ID                        ,--: in  std_logic_vector(3 downto 0);
        UL_SLOT_ID                  => eMTC_SLOT_ID                            ,--: in  std_logic_vector(5 downto 0);
        UL_SYMBOL_ID                => eMTC_SYMBOL_ID                          ,--: in  std_logic_vector(5 downto 0);
        UL_START_RE                 => eMTC_START_RE                           ,--: in  std_logic_vector(15 downto 0);

        UL_VALID                    => eMTC_VALID(i)                           ,--: in  std_logic;
        UL_START                    => eMTC_START(i)                           ,--: in  std_logic;
        UL_LAST                     => eMTC_LAST(i)                            ,--: in  std_logic;
        UL_DATA_I                   => eMTC_DATA_I(i)                          ,--: in  std_logic_vector(15 downto 0);
        UL_DATA_Q                   => eMTC_DATA_Q(i)                          ,--: in  std_logic_vector(15 downto 0);

        RB_COMP_HDR                 => prach1_comp_hdr(i)                      ,--: out std_logic_vector(7 downto 0);

        RB_VALID                    => prach1_valid(i)                         ,--: out std_logic;
        RB_TICK                     => prach1_tick(i)                          ,--: out std_logic;
        RB_DATA_I                   => prach1_data_i(i)                        ,--: out std_logic_vector(15 downto 0);
        RB_DATA_Q                   => prach1_data_q(i)                        ,--: out std_logic_vector(15 downto 0);
        RB_USER                     => prach1_user(i)                           --: out std_logic_vector(15 downto 0)
    );

    u_TX_WINDOW_NBIOT0 : UL_TX_WINDOW_NBIOT
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => nbiot0_init                             ,--: in  std_logic;

        CNT_PACKET_SYMBOL0          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL1          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL2          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL3          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL4          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL5          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL6          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL7          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL8          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL9          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL10         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL11         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL12         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL13         => open                                    ,--: out std_logic_vector(31 downto 0);

        PACKING_TICK                => nbiot0_packing_tick(i)                  ,--: in  std_logic;

        DATA_DIRECTION              => nbiot0_data_direction                   ,--: in  std_logic;
        PAYLOAD_VERSION             => nbiot0_payload_version                  ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => nbiot0_filter_index                     ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => nbiot0_frame_id                         ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => nbiot0_subframe_id                      ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => nbiot0_slot_id                          ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => nbiot0_symbol_id                        ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => nbiot0_section_tick(i)                  ,--: in  std_logic;
        SECTION_LAST                => nbiot0_section_last(i)                  ,--: in  std_logic;
        SECTION_DONE                => nbiot0_section_done(i)                  ,--: out std_logic;

        SECTION_ID                  => nbiot0_section_id                       ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => nbiot0_use_every_prb                    ,--: in  std_logic;
        START_OF_PRB                => nbiot0_offset_of_prb                    ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => nbiot0_number_of_prb                    ,--: in  std_logic_vector(9 downto 0);
        UD_COMP_HDR                 => nbiot0_ud_comp_hdr                      ,--: in  std_logic_vector(7 downto 0);

        UL_FRAME_ID                 => NBFE0_FRAME_ID                          ,--: in  std_logic_vector(7 downto 0);
        UL_SUBFRAME_ID              => NBFE0_SUBFRAME_ID                       ,--: in  std_logic_vector(3 downto 0);
        UL_SLOT_ID                  => NBFE0_SLOT_ID                           ,--: in  std_logic_vector(5 downto 0);
        UL_SYMBOL_ID                => NBFE0_SYMBOL_ID                         ,--: in  std_logic_vector(5 downto 0);
        UL_START_RE                 => NBFE0_START_RE                          ,--: in  std_logic_vector(15 downto 0);

        UL_VALID                    => NBFE0_VALID(i)                          ,--: in  std_logic;
        UL_START                    => NBFE0_START(i)                          ,--: in  std_logic;
        UL_LAST                     => NBFE0_LAST(i)                           ,--: in  std_logic;
        UL_DATA_I                   => NBFE0_DATA_I(i)                         ,--: in  std_logic_vector(15 downto 0);
        UL_DATA_Q                   => NBFE0_DATA_Q(i)                         ,--: in  std_logic_vector(15 downto 0);

        RB_COMP_HDR                 => nbiot0_comp_hdr(i)                      ,--: out std_logic_vector(7 downto 0);

        RB_VALID                    => nbiot0_valid(i)                         ,--: out std_logic;
        RB_TICK                     => nbiot0_tick(i)                          ,--: out std_logic;
        RB_DATA_I                   => nbiot0_data_i(i)                        ,--: out std_logic_vector(15 downto 0);
        RB_DATA_Q                   => nbiot0_data_q(i)                        ,--: out std_logic_vector(15 downto 0);
        RB_USER                     => nbiot0_user(i)                           --: out std_logic_vector(15 downto 0)
    );

    u_TX_WINDOW_NBIOT1 : UL_TX_WINDOW_NBIOT
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => nbiot1_init                             ,--: in  std_logic;

        CNT_PACKET_SYMBOL0          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL1          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL2          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL3          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL4          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL5          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL6          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL7          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL8          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL9          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL10         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL11         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL12         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL13         => open                                    ,--: out std_logic_vector(31 downto 0);

        PACKING_TICK                => nbiot1_packing_tick(i)                  ,--: in  std_logic;

        DATA_DIRECTION              => nbiot1_data_direction                   ,--: in  std_logic;
        PAYLOAD_VERSION             => nbiot1_payload_version                  ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => nbiot1_filter_index                     ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => nbiot1_frame_id                         ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => nbiot1_subframe_id                      ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => nbiot1_slot_id                          ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => nbiot1_symbol_id                        ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => nbiot1_section_tick(i)                  ,--: in  std_logic;
        SECTION_LAST                => nbiot1_section_last(i)                  ,--: in  std_logic;
        SECTION_DONE                => nbiot1_section_done(i)                  ,--: out std_logic;

        SECTION_ID                  => nbiot1_section_id                       ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => nbiot1_use_every_prb                    ,--: in  std_logic;
        START_OF_PRB                => nbiot1_offset_of_prb                    ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => nbiot1_number_of_prb                    ,--: in  std_logic_vector(9 downto 0);
        UD_COMP_HDR                 => nbiot1_ud_comp_hdr                      ,--: in  std_logic_vector(7 downto 0);

        UL_FRAME_ID                 => NBFE1_FRAME_ID                          ,--: in  std_logic_vector(7 downto 0);
        UL_SUBFRAME_ID              => NBFE1_SUBFRAME_ID                       ,--: in  std_logic_vector(3 downto 0);
        UL_SLOT_ID                  => NBFE1_SLOT_ID                           ,--: in  std_logic_vector(5 downto 0);
        UL_SYMBOL_ID                => NBFE1_SYMBOL_ID                         ,--: in  std_logic_vector(5 downto 0);
        UL_START_RE                 => NBFE1_START_RE                          ,--: in  std_logic_vector(15 downto 0);

        UL_VALID                    => NBFE1_VALID(i)                          ,--: in  std_logic;
        UL_START                    => NBFE1_START(i)                          ,--: in  std_logic;
        UL_LAST                     => NBFE1_LAST(i)                           ,--: in  std_logic;
        UL_DATA_I                   => NBFE1_DATA_I(i)                         ,--: in  std_logic_vector(15 downto 0);
        UL_DATA_Q                   => NBFE1_DATA_Q(i)                         ,--: in  std_logic_vector(15 downto 0);

        RB_COMP_HDR                 => nbiot1_comp_hdr(i)                      ,--: out std_logic_vector(7 downto 0);

        RB_VALID                    => nbiot1_valid(i)                         ,--: out std_logic;
        RB_TICK                     => nbiot1_tick(i)                          ,--: out std_logic;
        RB_DATA_I                   => nbiot1_data_i(i)                        ,--: out std_logic_vector(15 downto 0);
        RB_DATA_Q                   => nbiot1_data_q(i)                        ,--: out std_logic_vector(15 downto 0);
        RB_USER                     => nbiot1_user(i)                           --: out std_logic_vector(15 downto 0)
    );

    u_TX_WINDOW_NBIOT2 : UL_TX_WINDOW_NBIOT
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => nbiot2_init                             ,--: in  std_logic;

        CNT_PACKET_SYMBOL0          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL1          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL2          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL3          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL4          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL5          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL6          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL7          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL8          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL9          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL10         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL11         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL12         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL13         => open                                    ,--: out std_logic_vector(31 downto 0);

        PACKING_TICK                => nbiot2_packing_tick(i)                  ,--: in  std_logic;

        DATA_DIRECTION              => nbiot2_data_direction                   ,--: in  std_logic;
        PAYLOAD_VERSION             => nbiot2_payload_version                  ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => nbiot2_filter_index                     ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => nbiot2_frame_id                         ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => nbiot2_subframe_id                      ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => nbiot2_slot_id                          ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => nbiot2_symbol_id                        ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => nbiot2_section_tick(i)                  ,--: in  std_logic;
        SECTION_LAST                => nbiot2_section_last(i)                  ,--: in  std_logic;
        SECTION_DONE                => nbiot2_section_done(i)                  ,--: out std_logic;

        SECTION_ID                  => nbiot2_section_id                       ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => nbiot2_use_every_prb                    ,--: in  std_logic;
        START_OF_PRB                => nbiot2_offset_of_prb                    ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => nbiot2_number_of_prb                    ,--: in  std_logic_vector(9 downto 0);
        UD_COMP_HDR                 => nbiot2_ud_comp_hdr                      ,--: in  std_logic_vector(7 downto 0);

        UL_FRAME_ID                 => NBFE2_FRAME_ID                          ,--: in  std_logic_vector(7 downto 0);
        UL_SUBFRAME_ID              => NBFE2_SUBFRAME_ID                       ,--: in  std_logic_vector(3 downto 0);
        UL_SLOT_ID                  => NBFE2_SLOT_ID                           ,--: in  std_logic_vector(5 downto 0);
        UL_SYMBOL_ID                => NBFE2_SYMBOL_ID                         ,--: in  std_logic_vector(5 downto 0);
        UL_START_RE                 => NBFE2_START_RE                          ,--: in  std_logic_vector(15 downto 0);

        UL_VALID                    => NBFE2_VALID(i)                          ,--: in  std_logic;
        UL_START                    => NBFE2_START(i)                          ,--: in  std_logic;
        UL_LAST                     => NBFE2_LAST(i)                           ,--: in  std_logic;
        UL_DATA_I                   => NBFE2_DATA_I(i)                         ,--: in  std_logic_vector(15 downto 0);
        UL_DATA_Q                   => NBFE2_DATA_Q(i)                         ,--: in  std_logic_vector(15 downto 0);

        RB_COMP_HDR                 => nbiot2_comp_hdr(i)                      ,--: out std_logic_vector(7 downto 0);

        RB_VALID                    => nbiot2_valid(i)                         ,--: out std_logic;
        RB_TICK                     => nbiot2_tick(i)                          ,--: out std_logic;
        RB_DATA_I                   => nbiot2_data_i(i)                        ,--: out std_logic_vector(15 downto 0);
        RB_DATA_Q                   => nbiot2_data_q(i)                        ,--: out std_logic_vector(15 downto 0);
        RB_USER                     => nbiot2_user(i)                           --: out std_logic_vector(15 downto 0)
    );
    end generate;

--    u_PATH_UNUSED : if MAX_CH /= 8 generate
--    u_PATH : for i in 7 downto MAX_CH generate
--    puxch_comp_hdr(i)               <= (others => '0');
--    puxch_valid(i)                  <= '0';
--    puxch_tick(i)                   <= '0';
--    puxch_data_i(i)                 <= (others => '0');
--    puxch_data_q(i)                 <= (others => '0');
--    puxch_user(i)                   <= (others => '0');
--    prach0_comp_hdr(i)              <= (others => '0');
--    prach0_valid(i)                 <= '0';
--    prach0_tick(i)                  <= '0';
--    prach0_data_i(i)                <= (others => '0');
--    prach0_data_q(i)                <= (others => '0');
--    prach0_user(i)                  <= (others => '0');
--    prach1_comp_hdr(i)              <= (others => '0');
--    prach1_valid(i)                 <= '0';
--    prach1_tick(i)                  <= '0';
--    prach1_data_i(i)                <= (others => '0');
--    prach1_data_q(i)                <= (others => '0');
--    prach1_user(i)                  <= (others => '0');
--    nbiot0_comp_hdr(i)              <= (others => '0');
--    nbiot0_valid(i)                 <= '0';
--    nbiot0_tick(i)                  <= '0';
--    nbiot0_data_i(i)                <= (others => '0');
--    nbiot0_data_q(i)                <= (others => '0');
--    nbiot0_user(i)                  <= (others => '0');
--    nbiot1_comp_hdr(i)              <= (others => '0');
--    nbiot1_valid(i)                 <= '0';
--    nbiot1_tick(i)                  <= '0';
--    nbiot1_data_i(i)                <= (others => '0');
--    nbiot1_data_q(i)                <= (others => '0');
--    nbiot1_user(i)                  <= (others => '0');
--    nbiot2_comp_hdr(i)              <= (others => '0');
--    nbiot2_valid(i)                 <= '0';
--    nbiot2_tick(i)                  <= '0';
--    nbiot2_data_i(i)                <= (others => '0');
--    nbiot2_data_q(i)                <= (others => '0');
--    nbiot2_user(i)                  <= (others => '0');
--    end generate;
--    end generate;

end BEHAVE;