--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : UL U-Plane parameter (O-RAN component)                        --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity UL_PARAM0 is
    generic (
        MAX_CH                      : natural := 8
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;
        RST                         : in  std_logic;

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------


--------------------------------------------------------------------------------
-- LTE PUxCH
--------------------------------------------------------------------------------

        PUxCH_INIT                  : in  std_logic;
        PUxCH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_RTCPC_ID              : in  std_logic_vector(15 downto 0);

        PUxCH_DATA_DIRECTION        : in  std_logic;
        PUxCH_PAYLOAD_VERSION       : in  std_logic_vector(2 downto 0);
        PUxCH_FILTER_INDEX          : in  std_logic_vector(3 downto 0);
        PUxCH_FRAME_ID              : in  std_logic_vector(7 downto 0);
        PUxCH_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        PUxCH_SLOT_ID               : in  std_logic_vector(5 downto 0);
        PUxCH_SYMBOL_ID             : in  std_logic_vector(5 downto 0);

        PUxCH_SECTION_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_SECTION_ID            : in  std_logic_vector(11 downto 0);
        PUxCH_USE_EVERY_PRB         : in  std_logic;
        PUxCH_START_OF_PRB          : in  std_logic_vector(9 downto 0);
        PUxCH_NUMBER_OF_PRB         : in  std_logic_vector(9 downto 0);

        PUxCH_RB_INIT               : out std_logic;
        PUxCH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PUxCH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PUxCH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_APP_ACK     : in  std_logic;
        PUxCH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_SEC_ACK     : in  std_logic;

--------------------------------------------------------------------------------
-- LTE PRACH
--------------------------------------------------------------------------------

        PRACH_INIT                  : in  std_logic;
        PRACH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PRACH_RTCPC_ID              : in  std_logic_vector(15 downto 0);

        PRACH_DATA_DIRECTION        : in  std_logic;
        PRACH_PAYLOAD_VERSION       : in  std_logic_vector(2 downto 0);
        PRACH_FILTER_INDEX          : in  std_logic_vector(3 downto 0);
        PRACH_FRAME_ID              : in  std_logic_vector(7 downto 0);
        PRACH_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        PRACH_SLOT_ID               : in  std_logic_vector(5 downto 0);
        PRACH_SYMBOL_ID             : in  std_logic_vector(5 downto 0);

        PRACH_SECTION_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PRACH_SECTION_ID            : in  std_logic_vector(11 downto 0);
        PRACH_USE_EVERY_PRB         : in  std_logic;
        PRACH_START_OF_PRB          : in  std_logic_vector(9 downto 0);
        PRACH_NUMBER_OF_PRB         : in  std_logic_vector(9 downto 0);

        PRACH_RB_INIT               : out std_logic;
        PRACH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PRACH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PRACH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_APP_ACK     : in  std_logic;
        PRACH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_SEC_ACK     : in  std_logic;

--------------------------------------------------------------------------------
-- eMTC (PRACH)
--------------------------------------------------------------------------------

        eMTC_INIT                   : in  std_logic;
        eMTC_PACKING_TICK           : in  std_logic_vector(MAX_CH-1 downto 0);

        eMTC_RTCPC_ID               : in  std_logic_vector(15 downto 0);

        eMTC_DATA_DIRECTION         : in  std_logic;
        eMTC_PAYLOAD_VERSION        : in  std_logic_vector(2 downto 0);
        eMTC_FILTER_INDEX           : in  std_logic_vector(3 downto 0);
        eMTC_FRAME_ID               : in  std_logic_vector(7 downto 0);
        eMTC_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        eMTC_SLOT_ID                : in  std_logic_vector(5 downto 0);
        eMTC_SYMBOL_ID              : in  std_logic_vector(5 downto 0);

        eMTC_SECTION_TICK           : in  std_logic_vector(MAX_CH-1 downto 0);

        eMTC_SECTION_ID             : in  std_logic_vector(11 downto 0);
        eMTC_USE_EVERY_PRB          : in  std_logic;
        eMTC_START_OF_PRB           : in  std_logic_vector(9 downto 0);
        eMTC_NUMBER_OF_PRB          : in  std_logic_vector(9 downto 0);

        eMTC_RB_INIT                : out std_logic;
        eMTC_RB_eAxC_ID             : out std_logic_vector(15 downto 0);
        eMTC_RB_SEQUENCE_ID         : out std_logic_vector(15 downto 0);
        eMTC_RB_HEADER_APP          : out std_logic_vector(31 downto 0);
        eMTC_RB_HEADER_APP_ACK      : in  std_logic;
        eMTC_RB_HEADER_SEC          : out std_logic_vector(31 downto 0);
        eMTC_RB_HEADER_SEC_ACK      : in  std_logic;

--------------------------------------------------------------------------------
-- NB-IoT #0 (NPUSCH, anchor)
--------------------------------------------------------------------------------

        NBIOT0_INIT                 : in  std_logic;
        NBIOT0_PACKING_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT0_RTCPC_ID             : in  std_logic_vector(15 downto 0);

        NBIOT0_DATA_DIRECTION       : in  std_logic;
        NBIOT0_PAYLOAD_VERSION      : in  std_logic_vector(2 downto 0);
        NBIOT0_FILTER_INDEX         : in  std_logic_vector(3 downto 0);
        NBIOT0_FRAME_ID             : in  std_logic_vector(7 downto 0);
        NBIOT0_SUBFRAME_ID          : in  std_logic_vector(3 downto 0);
        NBIOT0_SLOT_ID              : in  std_logic_vector(5 downto 0);
        NBIOT0_SYMBOL_ID            : in  std_logic_vector(5 downto 0);

        NBIOT0_SECTION_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT0_SECTION_ID           : in  std_logic_vector(11 downto 0);
        NBIOT0_USE_EVERY_PRB        : in  std_logic;
        NBIOT0_START_OF_PRB         : in  std_logic_vector(9 downto 0);
        NBIOT0_NUMBER_OF_PRB        : in  std_logic_vector(9 downto 0);

        NBIOT0_RB_INIT              : out std_logic;
        NBIOT0_RB_eAxC_ID           : out std_logic_vector(15 downto 0);
        NBIOT0_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);
        NBIOT0_RB_HEADER_APP        : out std_logic_vector(31 downto 0);
        NBIOT0_RB_HEADER_APP_ACK    : in  std_logic;
        NBIOT0_RB_HEADER_SEC        : out std_logic_vector(31 downto 0);
        NBIOT0_RB_HEADER_SEC_ACK    : in  std_logic;

--------------------------------------------------------------------------------
-- NB-IoT #1 (NPUSCH, non-anchor)
--------------------------------------------------------------------------------

        NBIOT1_INIT                 : in  std_logic;
        NBIOT1_PACKING_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT1_RTCPC_ID             : in  std_logic_vector(15 downto 0);

        NBIOT1_DATA_DIRECTION       : in  std_logic;
        NBIOT1_PAYLOAD_VERSION      : in  std_logic_vector(2 downto 0);
        NBIOT1_FILTER_INDEX         : in  std_logic_vector(3 downto 0);
        NBIOT1_FRAME_ID             : in  std_logic_vector(7 downto 0);
        NBIOT1_SUBFRAME_ID          : in  std_logic_vector(3 downto 0);
        NBIOT1_SLOT_ID              : in  std_logic_vector(5 downto 0);
        NBIOT1_SYMBOL_ID            : in  std_logic_vector(5 downto 0);

        NBIOT1_SECTION_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT1_SECTION_ID           : in  std_logic_vector(11 downto 0);
        NBIOT1_USE_EVERY_PRB        : in  std_logic;
        NBIOT1_START_OF_PRB         : in  std_logic_vector(9 downto 0);
        NBIOT1_NUMBER_OF_PRB        : in  std_logic_vector(9 downto 0);

        NBIOT1_RB_INIT              : out std_logic;
        NBIOT1_RB_eAxC_ID           : out std_logic_vector(15 downto 0);
        NBIOT1_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);
        NBIOT1_RB_HEADER_APP        : out std_logic_vector(31 downto 0);
        NBIOT1_RB_HEADER_APP_ACK    : in  std_logic;
        NBIOT1_RB_HEADER_SEC        : out std_logic_vector(31 downto 0);
        NBIOT1_RB_HEADER_SEC_ACK    : in  std_logic;

--------------------------------------------------------------------------------
-- NB-IoT #2 (NPRACH)
--------------------------------------------------------------------------------

        NBIOT2_INIT                 : in  std_logic;
        NBIOT2_PACKING_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT2_RTCPC_ID             : in  std_logic_vector(15 downto 0);

        NBIOT2_DATA_DIRECTION       : in  std_logic;
        NBIOT2_PAYLOAD_VERSION      : in  std_logic_vector(2 downto 0);
        NBIOT2_FILTER_INDEX         : in  std_logic_vector(3 downto 0);
        NBIOT2_FRAME_ID             : in  std_logic_vector(7 downto 0);
        NBIOT2_SUBFRAME_ID          : in  std_logic_vector(3 downto 0);
        NBIOT2_SLOT_ID              : in  std_logic_vector(5 downto 0);
        NBIOT2_SYMBOL_ID            : in  std_logic_vector(5 downto 0);

        NBIOT2_SECTION_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);

        NBIOT2_SECTION_ID           : in  std_logic_vector(11 downto 0);
        NBIOT2_USE_EVERY_PRB        : in  std_logic;
        NBIOT2_START_OF_PRB         : in  std_logic_vector(9 downto 0);
        NBIOT2_NUMBER_OF_PRB        : in  std_logic_vector(9 downto 0);

        NBIOT2_RB_INIT              : out std_logic;
        NBIOT2_RB_eAxC_ID           : out std_logic_vector(15 downto 0);
        NBIOT2_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);
        NBIOT2_RB_HEADER_APP        : out std_logic_vector(31 downto 0);
        NBIOT2_RB_HEADER_APP_ACK    : in  std_logic;
        NBIOT2_RB_HEADER_SEC        : out std_logic_vector(31 downto 0);
        NBIOT2_RB_HEADER_SEC_ACK    : in  std_logic
    );
end UL_PARAM0;

architecture BEHAVE of UL_PARAM0 is

    component UL_PARAM_COMMON is
    generic (
        MAX_CH                      : natural := 8
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        PACKING_TICK                : in  std_logic_vector(MAX_CH-1 downto 0);

        RTCPC_ID                    : in  std_logic_vector(15 downto 0);

        DATA_DIRECTION              : in  std_logic;
        PAYLOAD_VERSION             : in  std_logic_vector(2 downto 0);
        FILTER_INDEX                : in  std_logic_vector(3 downto 0);
        FRAME_ID                    : in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 : in  std_logic_vector(3 downto 0);
        SLOT_ID                     : in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   : in  std_logic_vector(5 downto 0);

        SECTION_TICK                : in  std_logic_vector(MAX_CH-1 downto 0);

        SECTION_ID                  : in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               : in  std_logic;
        START_OF_PRB                : in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               : in  std_logic_vector(9 downto 0);

        RB_eAxC_ID                  : out std_logic_vector(15 downto 0);
        RB_HEADER_APP               : out std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           : in  std_logic;
        RB_HEADER_SEC               : out std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           : in  std_logic
    );
    end component;

    component UL_SEQ_ID0 is
    generic (
        MAX_CH                      : natural := 8
    );
    port (
        CLK                         : in  std_logic;
        RST_PUxCH                   : in  std_logic;
        RST_PRACH                   : in  std_logic;
        RST_eMTC                    : in  std_logic;
        RST_NBIOT0                  : in  std_logic;
        RST_NBIOT1                  : in  std_logic;
        RST_NBIOT2                  : in  std_logic;

        PUxCH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);
        PUxCH_PACKING_TICK_ACK      : in  std_logic;
        PUxCH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);

        PRACH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);
        PRACH_PACKING_TICK_ACK      : in  std_logic;
        PRACH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);

        eMTC_PACKING_TICK           : in  std_logic_vector(MAX_CH-1 downto 0);
        eMTC_PACKING_TICK_ACK       : in  std_logic;
        eMTC_RB_SEQUENCE_ID         : out std_logic_vector(15 downto 0);

        NBIOT0_PACKING_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);
        NBIOT0_PACKING_TICK_ACK     : in  std_logic;
        NBIOT0_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);

        NBIOT1_PACKING_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);
        NBIOT1_PACKING_TICK_ACK     : in  std_logic;
        NBIOT1_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);

        NBIOT2_PACKING_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);
        NBIOT2_PACKING_TICK_ACK     : in  std_logic;
        NBIOT2_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0)
    );
    end component;

begin

    PUxCH_RB_INIT  <= PUxCH_INIT;
    PRACH_RB_INIT  <= PRACH_INIT;
    eMTC_RB_INIT   <= eMTC_INIT;
    NBIOT0_RB_INIT <= NBIOT0_INIT;
    NBIOT1_RB_INIT <= NBIOT1_INIT;
    NBIOT2_RB_INIT <= NBIOT2_INIT;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_PUxCH : UL_PARAM_COMMON
    generic map(
        MAX_CH                      => MAX_CH                                   --: natural := 8
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => PUxCH_INIT                              ,--: in  std_logic;

        PACKING_TICK                => PUxCH_PACKING_TICK                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        RTCPC_ID                    => PUxCH_RTCPC_ID                          ,--: in  std_logic_vector(15 downto 0);

        DATA_DIRECTION              => PUxCH_DATA_DIRECTION                    ,--: in  std_logic;
        PAYLOAD_VERSION             => PUxCH_PAYLOAD_VERSION                   ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => PUxCH_FILTER_INDEX                      ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => PUxCH_FRAME_ID                          ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => PUxCH_SUBFRAME_ID                       ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => PUxCH_SLOT_ID                           ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => PUxCH_SYMBOL_ID                         ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => PUxCH_SECTION_TICK                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        SECTION_ID                  => PUxCH_SECTION_ID                        ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => PUxCH_USE_EVERY_PRB                     ,--: in  std_logic;
        START_OF_PRB                => PUxCH_START_OF_PRB                      ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => PUxCH_NUMBER_OF_PRB                     ,--: in  std_logic_vector(9 downto 0);

        RB_eAxC_ID                  => PUxCH_RB_eAxC_ID                        ,--: out std_logic_vector(15 downto 0);
        RB_HEADER_APP               => PUxCH_RB_HEADER_APP                     ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           => PUxCH_RB_HEADER_APP_ACK                 ,--: in  std_logic;
        RB_HEADER_SEC               => PUxCH_RB_HEADER_SEC                     ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           => PUxCH_RB_HEADER_SEC_ACK                  --: in  std_logic
    );

    u_PRACH : UL_PARAM_COMMON
    generic map(
        MAX_CH                      => MAX_CH                                   --: natural := 8
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => PRACH_INIT                              ,--: in  std_logic;

        PACKING_TICK                => PRACH_PACKING_TICK                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        RTCPC_ID                    => PRACH_RTCPC_ID                          ,--: in  std_logic_vector(15 downto 0);

        DATA_DIRECTION              => PRACH_DATA_DIRECTION                    ,--: in  std_logic;
        PAYLOAD_VERSION             => PRACH_PAYLOAD_VERSION                   ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => PRACH_FILTER_INDEX                      ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => PRACH_FRAME_ID                          ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => PRACH_SUBFRAME_ID                       ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => PRACH_SLOT_ID                           ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => PRACH_SYMBOL_ID                         ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => PRACH_SECTION_TICK                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        SECTION_ID                  => PRACH_SECTION_ID                        ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => PRACH_USE_EVERY_PRB                     ,--: in  std_logic;
        START_OF_PRB                => PRACH_START_OF_PRB                      ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => PRACH_NUMBER_OF_PRB                     ,--: in  std_logic_vector(9 downto 0);

        RB_eAxC_ID                  => PRACH_RB_eAxC_ID                        ,--: out std_logic_vector(15 downto 0);
        RB_HEADER_APP               => PRACH_RB_HEADER_APP                     ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           => PRACH_RB_HEADER_APP_ACK                 ,--: in  std_logic;
        RB_HEADER_SEC               => PRACH_RB_HEADER_SEC                     ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           => PRACH_RB_HEADER_SEC_ACK                  --: in  std_logic
    );

    u_eMTC_PRACH : UL_PARAM_COMMON
    generic map(
        MAX_CH                      => MAX_CH                                   --: natural := 8
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => eMTC_INIT                               ,--: in  std_logic;

        PACKING_TICK                => eMTC_PACKING_TICK                       ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        RTCPC_ID                    => eMTC_RTCPC_ID                           ,--: in  std_logic_vector(15 downto 0);

        DATA_DIRECTION              => eMTC_DATA_DIRECTION                     ,--: in  std_logic;
        PAYLOAD_VERSION             => eMTC_PAYLOAD_VERSION                    ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => eMTC_FILTER_INDEX                       ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => eMTC_FRAME_ID                           ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => eMTC_SUBFRAME_ID                        ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => eMTC_SLOT_ID                            ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => eMTC_SYMBOL_ID                          ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => eMTC_SECTION_TICK                       ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        SECTION_ID                  => eMTC_SECTION_ID                         ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => eMTC_USE_EVERY_PRB                      ,--: in  std_logic;
        START_OF_PRB                => eMTC_START_OF_PRB                       ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => eMTC_NUMBER_OF_PRB                      ,--: in  std_logic_vector(9 downto 0);

        RB_eAxC_ID                  => eMTC_RB_eAxC_ID                         ,--: out std_logic_vector(15 downto 0);
        RB_HEADER_APP               => eMTC_RB_HEADER_APP                      ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           => eMTC_RB_HEADER_APP_ACK                  ,--: in  std_logic;
        RB_HEADER_SEC               => eMTC_RB_HEADER_SEC                      ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           => eMTC_RB_HEADER_SEC_ACK                   --: in  std_logic
    );

    u_NBIOT0 : UL_PARAM_COMMON
    generic map(
        MAX_CH                      => MAX_CH                                   --: natural := 8
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => NBIOT0_INIT                             ,--: in  std_logic;

        PACKING_TICK                => NBIOT0_PACKING_TICK                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        RTCPC_ID                    => NBIOT0_RTCPC_ID                         ,--: in  std_logic_vector(15 downto 0);

        DATA_DIRECTION              => NBIOT0_DATA_DIRECTION                   ,--: in  std_logic;
        PAYLOAD_VERSION             => NBIOT0_PAYLOAD_VERSION                  ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => NBIOT0_FILTER_INDEX                     ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => NBIOT0_FRAME_ID                         ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => NBIOT0_SUBFRAME_ID                      ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => NBIOT0_SLOT_ID                          ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => NBIOT0_SYMBOL_ID                        ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => NBIOT0_SECTION_TICK                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        SECTION_ID                  => NBIOT0_SECTION_ID                       ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => NBIOT0_USE_EVERY_PRB                    ,--: in  std_logic;
        START_OF_PRB                => NBIOT0_START_OF_PRB                     ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => NBIOT0_NUMBER_OF_PRB                    ,--: in  std_logic_vector(9 downto 0);

        RB_eAxC_ID                  => NBIOT0_RB_eAxC_ID                       ,--: out std_logic_vector(15 downto 0);
        RB_HEADER_APP               => NBIOT0_RB_HEADER_APP                    ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           => NBIOT0_RB_HEADER_APP_ACK                ,--: in  std_logic;
        RB_HEADER_SEC               => NBIOT0_RB_HEADER_SEC                    ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           => NBIOT0_RB_HEADER_SEC_ACK                 --: in  std_logic
    );

    u_NBIOT1 : UL_PARAM_COMMON
    generic map(
        MAX_CH                      => MAX_CH                                   --: natural := 8
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => NBIOT1_INIT                             ,--: in  std_logic;

        PACKING_TICK                => NBIOT1_PACKING_TICK                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        RTCPC_ID                    => NBIOT1_RTCPC_ID                         ,--: in  std_logic_vector(15 downto 0);

        DATA_DIRECTION              => NBIOT1_DATA_DIRECTION                   ,--: in  std_logic;
        PAYLOAD_VERSION             => NBIOT1_PAYLOAD_VERSION                  ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => NBIOT1_FILTER_INDEX                     ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => NBIOT1_FRAME_ID                         ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => NBIOT1_SUBFRAME_ID                      ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => NBIOT1_SLOT_ID                          ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => NBIOT1_SYMBOL_ID                        ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => NBIOT1_SECTION_TICK                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        SECTION_ID                  => NBIOT1_SECTION_ID                       ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => NBIOT1_USE_EVERY_PRB                    ,--: in  std_logic;
        START_OF_PRB                => NBIOT1_START_OF_PRB                     ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => NBIOT1_NUMBER_OF_PRB                    ,--: in  std_logic_vector(9 downto 0);

        RB_eAxC_ID                  => NBIOT1_RB_eAxC_ID                       ,--: out std_logic_vector(15 downto 0);
        RB_HEADER_APP               => NBIOT1_RB_HEADER_APP                    ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           => NBIOT1_RB_HEADER_APP_ACK                ,--: in  std_logic;
        RB_HEADER_SEC               => NBIOT1_RB_HEADER_SEC                    ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           => NBIOT1_RB_HEADER_SEC_ACK                 --: in  std_logic
    );

    u_NBIOT2 : UL_PARAM_COMMON
    generic map(
        MAX_CH                      => MAX_CH                                   --: natural := 8
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => NBIOT2_INIT                             ,--: in  std_logic;

        PACKING_TICK                => NBIOT2_PACKING_TICK                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        RTCPC_ID                    => NBIOT2_RTCPC_ID                         ,--: in  std_logic_vector(15 downto 0);

        DATA_DIRECTION              => NBIOT2_DATA_DIRECTION                   ,--: in  std_logic;
        PAYLOAD_VERSION             => NBIOT2_PAYLOAD_VERSION                  ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => NBIOT2_FILTER_INDEX                     ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => NBIOT2_FRAME_ID                         ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => NBIOT2_SUBFRAME_ID                      ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => NBIOT2_SLOT_ID                          ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => NBIOT2_SYMBOL_ID                        ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => NBIOT2_SECTION_TICK                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        SECTION_ID                  => NBIOT2_SECTION_ID                       ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => NBIOT2_USE_EVERY_PRB                    ,--: in  std_logic;
        START_OF_PRB                => NBIOT2_START_OF_PRB                     ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => NBIOT2_NUMBER_OF_PRB                    ,--: in  std_logic_vector(9 downto 0);

        RB_eAxC_ID                  => NBIOT2_RB_eAxC_ID                       ,--: out std_logic_vector(15 downto 0);
        RB_HEADER_APP               => NBIOT2_RB_HEADER_APP                    ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           => NBIOT2_RB_HEADER_APP_ACK                ,--: in  std_logic;
        RB_HEADER_SEC               => NBIOT2_RB_HEADER_SEC                    ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           => NBIOT2_RB_HEADER_SEC_ACK                 --: in  std_logic
    );

    u_SEQ_ID : UL_SEQ_ID0
    generic map(
        MAX_CH                      => MAX_CH                                   --: natural := 8
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST_PUxCH                   => PUxCH_INIT                              ,--: in  std_logic;
        RST_PRACH                   => PRACH_INIT                              ,--: in  std_logic;
        RST_eMTC                    => eMTC_INIT                               ,--: in  std_logic;
        RST_NBIOT0                  => NBIOT0_INIT                             ,--: in  std_logic;
        RST_NBIOT1                  => NBIOT1_INIT                             ,--: in  std_logic;
        RST_NBIOT2                  => NBIOT2_INIT                             ,--: in  std_logic;

        PUxCH_PACKING_TICK          => PUxCH_PACKING_TICK                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);
        PUxCH_PACKING_TICK_ACK      => PUxCH_RB_HEADER_APP_ACK                 ,--: in  std_logic;
        PUxCH_RB_SEQUENCE_ID        => PUxCH_RB_SEQUENCE_ID                    ,--: out std_logic_vector(15 downto 0);

        PRACH_PACKING_TICK          => PRACH_PACKING_TICK                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);
        PRACH_PACKING_TICK_ACK      => PRACH_RB_HEADER_APP_ACK                 ,--: in  std_logic;
        PRACH_RB_SEQUENCE_ID        => PRACH_RB_SEQUENCE_ID                    ,--: out std_logic_vector(15 downto 0);

        eMTC_PACKING_TICK           => eMTC_PACKING_TICK                       ,--: in  std_logic_vector(MAX_CH-1 downto 0);
        eMTC_PACKING_TICK_ACK       => eMTC_RB_HEADER_APP_ACK                  ,--: in  std_logic;
        eMTC_RB_SEQUENCE_ID         => eMTC_RB_SEQUENCE_ID                     ,--: out std_logic_vector(15 downto 0);

        NBIOT0_PACKING_TICK         => NBIOT0_PACKING_TICK                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);
        NBIOT0_PACKING_TICK_ACK     => NBIOT0_RB_HEADER_APP_ACK                ,--: in  std_logic;
        NBIOT0_RB_SEQUENCE_ID       => NBIOT0_RB_SEQUENCE_ID                   ,--: out std_logic_vector(15 downto 0);

        NBIOT1_PACKING_TICK         => NBIOT1_PACKING_TICK                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);
        NBIOT1_PACKING_TICK_ACK     => NBIOT1_RB_HEADER_APP_ACK                ,--: in  std_logic;
        NBIOT1_RB_SEQUENCE_ID       => NBIOT1_RB_SEQUENCE_ID                   ,--: out std_logic_vector(15 downto 0);

        NBIOT2_PACKING_TICK         => NBIOT2_PACKING_TICK                     ,--: in  std_logic_vector(MAX_CH-1 downto 0);
        NBIOT2_PACKING_TICK_ACK     => NBIOT2_RB_HEADER_APP_ACK                ,--: in  std_logic;
        NBIOT2_RB_SEQUENCE_ID       => NBIOT2_RB_SEQUENCE_ID                    --: out std_logic_vector(15 downto 0)
    );

end BEHAVE;