--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : UL ecpriSeqid generation (O-RAN component)                    --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity UL_SEQ_ID0 is
    generic (
        MAX_CH                      : natural := 8
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;
        RST_PUxCH                   : in  std_logic;
        RST_PRACH                   : in  std_logic;
        RST_eMTC                    : in  std_logic;
        RST_NBIOT0                  : in  std_logic;
        RST_NBIOT1                  : in  std_logic;
        RST_NBIOT2                  : in  std_logic;

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------


--------------------------------------------------------------------------------
-- PUxCH
--------------------------------------------------------------------------------

        PUxCH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);
        PUxCH_PACKING_TICK_ACK      : in  std_logic;
        PUxCH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- PRACH
--------------------------------------------------------------------------------

        PRACH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);
        PRACH_PACKING_TICK_ACK      : in  std_logic;
        PRACH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- eMTC (PRACH)
--------------------------------------------------------------------------------

        eMTC_PACKING_TICK           : in  std_logic_vector(MAX_CH-1 downto 0);
        eMTC_PACKING_TICK_ACK       : in  std_logic;
        eMTC_RB_SEQUENCE_ID         : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- NB-IoT #0 (NPUSCH0)
--------------------------------------------------------------------------------

        NBIOT0_PACKING_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);
        NBIOT0_PACKING_TICK_ACK     : in  std_logic;
        NBIOT0_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- NB-IoT #1 (NPUSCH1)
--------------------------------------------------------------------------------

        NBIOT1_PACKING_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);
        NBIOT1_PACKING_TICK_ACK     : in  std_logic;
        NBIOT1_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- NB-IoT #2 (NPRACH)
--------------------------------------------------------------------------------

        NBIOT2_PACKING_TICK         : in  std_logic_vector(MAX_CH-1 downto 0);
        NBIOT2_PACKING_TICK_ACK     : in  std_logic;
        NBIOT2_RB_SEQUENCE_ID       : out std_logic_vector(15 downto 0)
    );
end UL_SEQ_ID0;

architecture BEHAVE of UL_SEQ_ID0 is

    type std_logic_array8           is array(natural range <>) of std_logic_vector(7 downto 0);

    signal puxch_tick               : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');
    signal puxch_tick_sh            : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');
    signal prach_tick               : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');
    signal prach_tick_sh            : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');
    signal emtc_tick                : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');
    signal emtc_tick_sh             : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');
    signal nbiot0_tick              : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');
    signal nbiot0_tick_sh           : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');
    signal nbiot1_tick              : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');
    signal nbiot1_tick_sh           : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');
    signal nbiot2_tick              : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');
    signal nbiot2_tick_sh           : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');

    signal cnt_seed0                : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal cnt_seed1                : std_logic_array8(7 downto 0) := (others => (others => '0'));

    signal cnt_puxch                : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal puxch_id                 : std_logic_vector(7 downto 0) := (others => '0');

    signal cnt_prach                : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal prach_id                 : std_logic_vector(7 downto 0) := (others => '0');

    signal cnt_emtc                 : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal emtc_id                  : std_logic_vector(7 downto 0) := (others => '0');

    signal cnt_nbiot0               : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal nbiot0_id                : std_logic_vector(7 downto 0) := (others => '0');

    signal cnt_nbiot1               : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal nbiot1_id                : std_logic_vector(7 downto 0) := (others => '0');

    signal cnt_nbiot2               : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal nbiot2_id                : std_logic_vector(7 downto 0) := (others => '0');

    constant HDR_BUF                : natural := 2;
    signal puxch_id_buf             : std_logic_array8(HDR_BUF-1 downto 0) := (others => (others => '0'));
    signal index_puxch_wr           : natural range 0 to HDR_BUF;
    signal index_puxch_rd           : natural range 0 to HDR_BUF;
    signal prach_id_buf             : std_logic_array8(HDR_BUF-1 downto 0) := (others => (others => '0'));
    signal index_prach_wr           : natural range 0 to HDR_BUF;
    signal index_prach_rd           : natural range 0 to HDR_BUF;
    signal emtc_id_buf              : std_logic_array8(HDR_BUF-1 downto 0) := (others => (others => '0'));
    signal index_emtc_wr            : natural range 0 to HDR_BUF;
    signal index_emtc_rd            : natural range 0 to HDR_BUF;
    signal nbiot0_id_buf            : std_logic_array8(HDR_BUF-1 downto 0) := (others => (others => '0'));
    signal index_nbiot0_wr          : natural range 0 to HDR_BUF;
    signal index_nbiot0_rd          : natural range 0 to HDR_BUF;
    signal nbiot1_id_buf            : std_logic_array8(HDR_BUF-1 downto 0) := (others => (others => '0'));
    signal index_nbiot1_wr          : natural range 0 to HDR_BUF;
    signal index_nbiot1_rd          : natural range 0 to HDR_BUF;
    signal nbiot2_id_buf            : std_logic_array8(HDR_BUF-1 downto 0) := (others => (others => '0'));
    signal index_nbiot2_wr          : natural range 0 to HDR_BUF;
    signal index_nbiot2_rd          : natural range 0 to HDR_BUF;

begin

    PUxCH_RB_SEQUENCE_ID  <= puxch_id_buf(index_puxch_rd) & x"80";
    PRACH_RB_SEQUENCE_ID  <= prach_id_buf(index_prach_rd) & x"80";
    eMTC_RB_SEQUENCE_ID   <= emtc_id_buf(index_emtc_rd) & x"80";
    NBIOT0_RB_SEQUENCE_ID <= nbiot0_id_buf(index_nbiot0_rd) & x"80";
    NBIOT1_RB_SEQUENCE_ID <= nbiot1_id_buf(index_nbiot1_rd) & x"80";
    NBIOT2_RB_SEQUENCE_ID <= nbiot2_id_buf(index_nbiot2_rd) & x"80";

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            puxch_tick(MAX_CH-1 downto 0)  <= PUxCH_PACKING_TICK;
            prach_tick(MAX_CH-1 downto 0)  <= PRACH_PACKING_TICK;
            emtc_tick(MAX_CH-1 downto 0)   <= eMTC_PACKING_TICK;
            nbiot0_tick(MAX_CH-1 downto 0) <= NBIOT0_PACKING_TICK;
            nbiot1_tick(MAX_CH-1 downto 0) <= NBIOT1_PACKING_TICK;
            nbiot2_tick(MAX_CH-1 downto 0) <= NBIOT2_PACKING_TICK;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            puxch_tick_sh  <= puxch_tick;
            prach_tick_sh  <= prach_tick;
            emtc_tick_sh   <= emtc_tick;
            nbiot0_tick_sh <= nbiot0_tick;
            nbiot1_tick_sh <= nbiot1_tick;
            nbiot2_tick_sh <= nbiot2_tick;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (puxch_tick_sh /= 0) then
                puxch_id_buf <= puxch_id_buf(HDR_BUF-2 downto 0) & puxch_id;
            end if;
        end if;
    end process;

    process (RST_PUxCH, CLK)
    begin
        if (RST_PUxCH = '1') then
            index_puxch_wr <= 0;
            index_puxch_rd <= 0;
        elsif (CLK'event and CLK = '1') then
            if (puxch_tick_sh /= 0) then
                if (PUxCH_PACKING_TICK_ACK = '1') then
                    index_puxch_wr <= index_puxch_wr;
                else
                    index_puxch_wr <= index_puxch_wr + 1;
                end if;
            else
                if (PUxCH_PACKING_TICK_ACK = '1') then
                    if (index_puxch_wr = 0) then
                        index_puxch_wr <= 0;
                    else
                        index_puxch_wr <= index_puxch_wr - 1;
                    end if;
                end if;
            end if;
            if (puxch_tick_sh /= 0) then
                if (PUxCH_PACKING_TICK_ACK = '1') then
                    index_puxch_rd <= index_puxch_rd;
                else
                    index_puxch_rd <= index_puxch_wr;
                end if;
            else
                if (PUxCH_PACKING_TICK_ACK = '1') then
                    if (index_puxch_rd = 0) then
                        index_puxch_rd <= 0;
                    else
                        index_puxch_rd <= index_puxch_rd - 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (prach_tick_sh /= 0) then
                prach_id_buf <= prach_id_buf(HDR_BUF-2 downto 0) & prach_id;
            end if;
        end if;
    end process;

    process (RST_PRACH, CLK)
    begin
        if (RST_PRACH = '1') then
            index_prach_wr <= 0;
            index_prach_rd <= 0;
        elsif (CLK'event and CLK = '1') then
            if (prach_tick_sh /= 0) then
                if (PRACH_PACKING_TICK_ACK = '1') then
                    index_prach_wr <= index_prach_wr;
                else
                    index_prach_wr <= index_prach_wr + 1;
                end if;
            else
                if (PRACH_PACKING_TICK_ACK = '1') then
                    if (index_prach_wr = 0) then
                        index_prach_wr <= 0;
                    else
                        index_prach_wr <= index_prach_wr - 1;
                    end if;
                end if;
            end if;
            if (prach_tick_sh /= 0) then
                if (PRACH_PACKING_TICK_ACK = '1') then
                    index_prach_rd <= index_prach_rd;
                else
                    index_prach_rd <= index_prach_wr;
                end if;
            else
                if (PRACH_PACKING_TICK_ACK = '1') then
                    if (index_prach_rd = 0) then
                        index_prach_rd <= 0;
                    else
                        index_prach_rd <= index_prach_rd - 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (emtc_tick_sh /= 0) then
                emtc_id_buf <= emtc_id_buf(HDR_BUF-2 downto 0) & emtc_id;
            end if;
        end if;
    end process;

    process (RST_eMTC, CLK)
    begin
        if (RST_eMTC = '1') then
            index_emtc_wr <= 0;
            index_emtc_rd <= 0;
        elsif (CLK'event and CLK = '1') then
            if (emtc_tick_sh /= 0) then
                if (eMTC_PACKING_TICK_ACK = '1') then
                    index_emtc_wr <= index_emtc_wr;
                else
                    index_emtc_wr <= index_emtc_wr + 1;
                end if;
            else
                if (eMTC_PACKING_TICK_ACK = '1') then
                    if (index_emtc_wr = 0) then
                        index_emtc_wr <= 0;
                    else
                        index_emtc_wr <= index_emtc_wr - 1;
                    end if;
                end if;
            end if;
            if (emtc_tick_sh /= 0) then
                if (eMTC_PACKING_TICK_ACK = '1') then
                    index_emtc_rd <= index_emtc_rd;
                else
                    index_emtc_rd <= index_emtc_wr;
                end if;
            else
                if (eMTC_PACKING_TICK_ACK = '1') then
                    if (index_emtc_rd = 0) then
                        index_emtc_rd <= 0;
                    else
                        index_emtc_rd <= index_emtc_rd - 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (nbiot0_tick_sh /= 0) then
                nbiot0_id_buf <= nbiot0_id_buf(HDR_BUF-2 downto 0) & nbiot0_id;
            end if;
        end if;
    end process;

    process (RST_NBIOT0, CLK)
    begin
        if (RST_NBIOT0 = '1') then
            index_nbiot0_wr <= 0;
            index_nbiot0_rd <= 0;
        elsif (CLK'event and CLK = '1') then
            if (nbiot0_tick_sh /= 0) then
                if (NBIOT0_PACKING_TICK_ACK = '1') then
                    index_nbiot0_wr <= index_nbiot0_wr;
                else
                    index_nbiot0_wr <= index_nbiot0_wr + 1;
                end if;
            else
                if (NBIOT0_PACKING_TICK_ACK = '1') then
                    if (index_nbiot0_wr = 0) then
                        index_nbiot0_wr <= 0;
                    else
                        index_nbiot0_wr <= index_nbiot0_wr - 1;
                    end if;
                end if;
            end if;
            if (nbiot0_tick_sh /= 0) then
                if (NBIOT0_PACKING_TICK_ACK = '1') then
                    index_nbiot0_rd <= index_nbiot0_rd;
                else
                    index_nbiot0_rd <= index_nbiot0_wr;
                end if;
            else
                if (NBIOT0_PACKING_TICK_ACK = '1') then
                    if (index_nbiot0_rd = 0) then
                        index_nbiot0_rd <= 0;
                    else
                        index_nbiot0_rd <= index_nbiot0_rd - 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (nbiot1_tick_sh /= 0) then
                nbiot1_id_buf <= nbiot1_id_buf(HDR_BUF-2 downto 0) & nbiot1_id;
            end if;
        end if;
    end process;

    process (RST_NBIOT1, CLK)
    begin
        if (RST_NBIOT1 = '1') then
            index_nbiot1_wr <= 0;
            index_nbiot1_rd <= 0;
        elsif (CLK'event and CLK = '1') then
            if (nbiot1_tick_sh /= 0) then
                if (NBIOT1_PACKING_TICK_ACK = '1') then
                    index_nbiot1_wr <= index_nbiot1_wr;
                else
                    index_nbiot1_wr <= index_nbiot1_wr + 1;
                end if;
            else
                if (NBIOT1_PACKING_TICK_ACK = '1') then
                    if (index_nbiot1_wr = 0) then
                        index_nbiot1_wr <= 0;
                    else
                        index_nbiot1_wr <= index_nbiot1_wr - 1;
                    end if;
                end if;
            end if;
            if (nbiot1_tick_sh /= 0) then
                if (NBIOT1_PACKING_TICK_ACK = '1') then
                    index_nbiot1_rd <= index_nbiot1_rd;
                else
                    index_nbiot1_rd <= index_nbiot1_wr;
                end if;
            else
                if (NBIOT1_PACKING_TICK_ACK = '1') then
                    if (index_nbiot1_rd = 0) then
                        index_nbiot1_rd <= 0;
                    else
                        index_nbiot1_rd <= index_nbiot1_rd - 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (nbiot2_tick_sh /= 0) then
                nbiot2_id_buf <= nbiot2_id_buf(HDR_BUF-2 downto 0) & nbiot2_id;
            end if;
        end if;
    end process;

    process (RST_NBIOT2, CLK)
    begin
        if (RST_NBIOT2 = '1') then
            index_nbiot2_wr <= 0;
            index_nbiot2_rd <= 0;
        elsif (CLK'event and CLK = '1') then
            if (nbiot2_tick_sh /= 0) then
                if (NBIOT2_PACKING_TICK_ACK = '1') then
                    index_nbiot2_wr <= index_nbiot2_wr;
                else
                    index_nbiot2_wr <= index_nbiot2_wr + 1;
                end if;
            else
                if (NBIOT2_PACKING_TICK_ACK = '1') then
                    if (index_nbiot2_wr = 0) then
                        index_nbiot2_wr <= 0;
                    else
                        index_nbiot2_wr <= index_nbiot2_wr - 1;
                    end if;
                end if;
            end if;
            if (nbiot2_tick_sh /= 0) then
                if (NBIOT2_PACKING_TICK_ACK = '1') then
                    index_nbiot2_rd <= index_nbiot2_rd;
                else
                    index_nbiot2_rd <= index_nbiot2_wr;
                end if;
            else
                if (NBIOT2_PACKING_TICK_ACK = '1') then
                    if (index_nbiot2_rd = 0) then
                        index_nbiot2_rd <= 0;
                    else
                        index_nbiot2_rd <= index_nbiot2_rd - 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    u_1CHANNEL : if MAX_CH = 1 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            end if;
            if    (emtc_tick(0) = '1') then
                emtc_id <= cnt_emtc(0);
            end if;
            if    (nbiot0_tick(0) = '1') then
                nbiot0_id <= cnt_nbiot0(0);
            end if;
            if    (nbiot1_tick(0) = '1') then
                nbiot1_id <= cnt_nbiot1(0);
            end if;
            if    (nbiot2_tick(0) = '1') then
                nbiot2_id <= cnt_nbiot2(0);
            end if;
        end if;
    end process;
    end generate;

    u_2CHANNEL : if MAX_CH = 2 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            elsif (puxch_tick(1) = '1') then
                puxch_id <= cnt_puxch(1);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            elsif (prach_tick(1) = '1') then
                prach_id <= cnt_prach(1);
            end if;
            if    (emtc_tick(0) = '1') then
                emtc_id <= cnt_emtc(0);
            elsif (emtc_tick(1) = '1') then
                emtc_id <= cnt_emtc(1);
            end if;
            if    (nbiot0_tick(0) = '1') then
                nbiot0_id <= cnt_nbiot0(0);
            elsif (nbiot0_tick(1) = '1') then
                nbiot0_id <= cnt_nbiot0(1);
            end if;
            if    (nbiot1_tick(0) = '1') then
                nbiot1_id <= cnt_nbiot1(0);
            elsif (nbiot1_tick(1) = '1') then
                nbiot1_id <= cnt_nbiot1(1);
            end if;
            if    (nbiot2_tick(0) = '1') then
                nbiot2_id <= cnt_nbiot2(0);
            elsif (nbiot2_tick(1) = '1') then
                nbiot2_id <= cnt_nbiot2(1);
            end if;
        end if;
    end process;
    end generate;

    u_3CHANNEL : if MAX_CH = 3 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            elsif (puxch_tick(1) = '1') then
                puxch_id <= cnt_puxch(1);
            elsif (puxch_tick(2) = '1') then
                puxch_id <= cnt_puxch(2);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            elsif (prach_tick(1) = '1') then
                prach_id <= cnt_prach(1);
            elsif (prach_tick(2) = '1') then
                prach_id <= cnt_prach(2);
            end if;
            if    (emtc_tick(0) = '1') then
                emtc_id <= cnt_emtc(0);
            elsif (emtc_tick(1) = '1') then
                emtc_id <= cnt_emtc(1);
            elsif (emtc_tick(2) = '1') then
                emtc_id <= cnt_emtc(2);
            end if;
            if    (nbiot0_tick(0) = '1') then
                nbiot0_id <= cnt_nbiot0(0);
            elsif (nbiot0_tick(1) = '1') then
                nbiot0_id <= cnt_nbiot0(1);
            elsif (nbiot0_tick(2) = '1') then
                nbiot0_id <= cnt_nbiot0(2);
            end if;
            if    (nbiot1_tick(0) = '1') then
                nbiot1_id <= cnt_nbiot1(0);
            elsif (nbiot1_tick(1) = '1') then
                nbiot1_id <= cnt_nbiot1(1);
            elsif (nbiot1_tick(2) = '1') then
                nbiot1_id <= cnt_nbiot1(2);
            end if;
            if    (nbiot2_tick(0) = '1') then
                nbiot2_id <= cnt_nbiot2(0);
            elsif (nbiot2_tick(1) = '1') then
                nbiot2_id <= cnt_nbiot2(1);
            elsif (nbiot2_tick(2) = '1') then
                nbiot2_id <= cnt_nbiot2(2);
            end if;
        end if;
    end process;
    end generate;

    u_4CHANNEL : if MAX_CH = 4 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            elsif (puxch_tick(1) = '1') then
                puxch_id <= cnt_puxch(1);
            elsif (puxch_tick(2) = '1') then
                puxch_id <= cnt_puxch(2);
            elsif (puxch_tick(3) = '1') then
                puxch_id <= cnt_puxch(3);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            elsif (prach_tick(1) = '1') then
                prach_id <= cnt_prach(1);
            elsif (prach_tick(2) = '1') then
                prach_id <= cnt_prach(2);
            elsif (prach_tick(3) = '1') then
                prach_id <= cnt_prach(3);
            end if;
            if    (emtc_tick(0) = '1') then
                emtc_id <= cnt_emtc(0);
            elsif (emtc_tick(1) = '1') then
                emtc_id <= cnt_emtc(1);
            elsif (emtc_tick(2) = '1') then
                emtc_id <= cnt_emtc(2);
            elsif (emtc_tick(3) = '1') then
                emtc_id <= cnt_emtc(3);
            end if;
            if    (nbiot0_tick(0) = '1') then
                nbiot0_id <= cnt_nbiot0(0);
            elsif (nbiot0_tick(1) = '1') then
                nbiot0_id <= cnt_nbiot0(1);
            elsif (nbiot0_tick(2) = '1') then
                nbiot0_id <= cnt_nbiot0(2);
            elsif (nbiot0_tick(3) = '1') then
                nbiot0_id <= cnt_nbiot0(3);
            end if;
            if    (nbiot1_tick(0) = '1') then
                nbiot1_id <= cnt_nbiot1(0);
            elsif (nbiot1_tick(1) = '1') then
                nbiot1_id <= cnt_nbiot1(1);
            elsif (nbiot1_tick(2) = '1') then
                nbiot1_id <= cnt_nbiot1(2);
            elsif (nbiot1_tick(3) = '1') then
                nbiot1_id <= cnt_nbiot1(3);
            end if;
            if    (nbiot2_tick(0) = '1') then
                nbiot2_id <= cnt_nbiot2(0);
            elsif (nbiot2_tick(1) = '1') then
                nbiot2_id <= cnt_nbiot2(1);
            elsif (nbiot2_tick(2) = '1') then
                nbiot2_id <= cnt_nbiot2(2);
            elsif (nbiot2_tick(3) = '1') then
                nbiot2_id <= cnt_nbiot2(3);
            end if;
        end if;
    end process;
    end generate;

    u_5CHANNEL : if MAX_CH = 5 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            elsif (puxch_tick(1) = '1') then
                puxch_id <= cnt_puxch(1);
            elsif (puxch_tick(2) = '1') then
                puxch_id <= cnt_puxch(2);
            elsif (puxch_tick(3) = '1') then
                puxch_id <= cnt_puxch(3);
            elsif (puxch_tick(4) = '1') then
                puxch_id <= cnt_puxch(4);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            elsif (prach_tick(1) = '1') then
                prach_id <= cnt_prach(1);
            elsif (prach_tick(2) = '1') then
                prach_id <= cnt_prach(2);
            elsif (prach_tick(3) = '1') then
                prach_id <= cnt_prach(3);
            elsif (prach_tick(4) = '1') then
                prach_id <= cnt_prach(4);
            end if;
            if    (emtc_tick(0) = '1') then
                emtc_id <= cnt_emtc(0);
            elsif (emtc_tick(1) = '1') then
                emtc_id <= cnt_emtc(1);
            elsif (emtc_tick(2) = '1') then
                emtc_id <= cnt_emtc(2);
            elsif (emtc_tick(3) = '1') then
                emtc_id <= cnt_emtc(3);
            elsif (emtc_tick(4) = '1') then
                emtc_id <= cnt_emtc(4);
            end if;
            if    (nbiot0_tick(0) = '1') then
                nbiot0_id <= cnt_nbiot0(0);
            elsif (nbiot0_tick(1) = '1') then
                nbiot0_id <= cnt_nbiot0(1);
            elsif (nbiot0_tick(2) = '1') then
                nbiot0_id <= cnt_nbiot0(2);
            elsif (nbiot0_tick(3) = '1') then
                nbiot0_id <= cnt_nbiot0(3);
            elsif (nbiot0_tick(4) = '1') then
                nbiot0_id <= cnt_nbiot0(4);
            end if;
            if    (nbiot1_tick(0) = '1') then
                nbiot1_id <= cnt_nbiot1(0);
            elsif (nbiot1_tick(1) = '1') then
                nbiot1_id <= cnt_nbiot1(1);
            elsif (nbiot1_tick(2) = '1') then
                nbiot1_id <= cnt_nbiot1(2);
            elsif (nbiot1_tick(3) = '1') then
                nbiot1_id <= cnt_nbiot1(3);
            elsif (nbiot1_tick(4) = '1') then
                nbiot1_id <= cnt_nbiot1(4);
            end if;
            if    (nbiot2_tick(0) = '1') then
                nbiot2_id <= cnt_nbiot2(0);
            elsif (nbiot2_tick(1) = '1') then
                nbiot2_id <= cnt_nbiot2(1);
            elsif (nbiot2_tick(2) = '1') then
                nbiot2_id <= cnt_nbiot2(2);
            elsif (nbiot2_tick(3) = '1') then
                nbiot2_id <= cnt_nbiot2(3);
            elsif (nbiot2_tick(4) = '1') then
                nbiot2_id <= cnt_nbiot2(4);
            end if;
        end if;
    end process;
    end generate;

    u_6CHANNEL : if MAX_CH = 6 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            elsif (puxch_tick(1) = '1') then
                puxch_id <= cnt_puxch(1);
            elsif (puxch_tick(2) = '1') then
                puxch_id <= cnt_puxch(2);
            elsif (puxch_tick(3) = '1') then
                puxch_id <= cnt_puxch(3);
            elsif (puxch_tick(4) = '1') then
                puxch_id <= cnt_puxch(4);
            elsif (puxch_tick(5) = '1') then
                puxch_id <= cnt_puxch(5);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            elsif (prach_tick(1) = '1') then
                prach_id <= cnt_prach(1);
            elsif (prach_tick(2) = '1') then
                prach_id <= cnt_prach(2);
            elsif (prach_tick(3) = '1') then
                prach_id <= cnt_prach(3);
            elsif (prach_tick(4) = '1') then
                prach_id <= cnt_prach(4);
            elsif (prach_tick(5) = '1') then
                prach_id <= cnt_prach(5);
            end if;
            if    (emtc_tick(0) = '1') then
                emtc_id <= cnt_emtc(0);
            elsif (emtc_tick(1) = '1') then
                emtc_id <= cnt_emtc(1);
            elsif (emtc_tick(2) = '1') then
                emtc_id <= cnt_emtc(2);
            elsif (emtc_tick(3) = '1') then
                emtc_id <= cnt_emtc(3);
            elsif (emtc_tick(4) = '1') then
                emtc_id <= cnt_emtc(4);
            elsif (emtc_tick(5) = '1') then
                emtc_id <= cnt_emtc(5);
            end if;
            if    (nbiot0_tick(0) = '1') then
                nbiot0_id <= cnt_nbiot0(0);
            elsif (nbiot0_tick(1) = '1') then
                nbiot0_id <= cnt_nbiot0(1);
            elsif (nbiot0_tick(2) = '1') then
                nbiot0_id <= cnt_nbiot0(2);
            elsif (nbiot0_tick(3) = '1') then
                nbiot0_id <= cnt_nbiot0(3);
            elsif (nbiot0_tick(4) = '1') then
                nbiot0_id <= cnt_nbiot0(4);
            elsif (nbiot0_tick(5) = '1') then
                nbiot0_id <= cnt_nbiot0(5);
            end if;
            if    (nbiot1_tick(0) = '1') then
                nbiot1_id <= cnt_nbiot1(0);
            elsif (nbiot1_tick(1) = '1') then
                nbiot1_id <= cnt_nbiot1(1);
            elsif (nbiot1_tick(2) = '1') then
                nbiot1_id <= cnt_nbiot1(2);
            elsif (nbiot1_tick(3) = '1') then
                nbiot1_id <= cnt_nbiot1(3);
            elsif (nbiot1_tick(4) = '1') then
                nbiot1_id <= cnt_nbiot1(4);
            elsif (nbiot1_tick(5) = '1') then
                nbiot1_id <= cnt_nbiot1(5);
            end if;
            if    (nbiot2_tick(0) = '1') then
                nbiot2_id <= cnt_nbiot2(0);
            elsif (nbiot2_tick(1) = '1') then
                nbiot2_id <= cnt_nbiot2(1);
            elsif (nbiot2_tick(2) = '1') then
                nbiot2_id <= cnt_nbiot2(2);
            elsif (nbiot2_tick(3) = '1') then
                nbiot2_id <= cnt_nbiot2(3);
            elsif (nbiot2_tick(4) = '1') then
                nbiot2_id <= cnt_nbiot2(4);
            elsif (nbiot2_tick(5) = '1') then
                nbiot2_id <= cnt_nbiot2(5);
            end if;
        end if;
    end process;
    end generate;

    u_7CHANNEL : if MAX_CH = 7 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            elsif (puxch_tick(1) = '1') then
                puxch_id <= cnt_puxch(1);
            elsif (puxch_tick(2) = '1') then
                puxch_id <= cnt_puxch(2);
            elsif (puxch_tick(3) = '1') then
                puxch_id <= cnt_puxch(3);
            elsif (puxch_tick(4) = '1') then
                puxch_id <= cnt_puxch(4);
            elsif (puxch_tick(5) = '1') then
                puxch_id <= cnt_puxch(5);
            elsif (puxch_tick(6) = '1') then
                puxch_id <= cnt_puxch(6);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            elsif (prach_tick(1) = '1') then
                prach_id <= cnt_prach(1);
            elsif (prach_tick(2) = '1') then
                prach_id <= cnt_prach(2);
            elsif (prach_tick(3) = '1') then
                prach_id <= cnt_prach(3);
            elsif (prach_tick(4) = '1') then
                prach_id <= cnt_prach(4);
            elsif (prach_tick(5) = '1') then
                prach_id <= cnt_prach(5);
            elsif (prach_tick(6) = '1') then
                prach_id <= cnt_prach(6);
            end if;
            if    (emtc_tick(0) = '1') then
                emtc_id <= cnt_emtc(0);
            elsif (emtc_tick(1) = '1') then
                emtc_id <= cnt_emtc(1);
            elsif (emtc_tick(2) = '1') then
                emtc_id <= cnt_emtc(2);
            elsif (emtc_tick(3) = '1') then
                emtc_id <= cnt_emtc(3);
            elsif (emtc_tick(4) = '1') then
                emtc_id <= cnt_emtc(4);
            elsif (emtc_tick(5) = '1') then
                emtc_id <= cnt_emtc(5);
            elsif (emtc_tick(6) = '1') then
                emtc_id <= cnt_emtc(6);
            end if;
            if    (nbiot0_tick(0) = '1') then
                nbiot0_id <= cnt_nbiot0(0);
            elsif (nbiot0_tick(1) = '1') then
                nbiot0_id <= cnt_nbiot0(1);
            elsif (nbiot0_tick(2) = '1') then
                nbiot0_id <= cnt_nbiot0(2);
            elsif (nbiot0_tick(3) = '1') then
                nbiot0_id <= cnt_nbiot0(3);
            elsif (nbiot0_tick(4) = '1') then
                nbiot0_id <= cnt_nbiot0(4);
            elsif (nbiot0_tick(5) = '1') then
                nbiot0_id <= cnt_nbiot0(5);
            elsif (nbiot0_tick(6) = '1') then
                nbiot0_id <= cnt_nbiot0(6);
            end if;
            if    (nbiot1_tick(0) = '1') then
                nbiot1_id <= cnt_nbiot1(0);
            elsif (nbiot1_tick(1) = '1') then
                nbiot1_id <= cnt_nbiot1(1);
            elsif (nbiot1_tick(2) = '1') then
                nbiot1_id <= cnt_nbiot1(2);
            elsif (nbiot1_tick(3) = '1') then
                nbiot1_id <= cnt_nbiot1(3);
            elsif (nbiot1_tick(4) = '1') then
                nbiot1_id <= cnt_nbiot1(4);
            elsif (nbiot1_tick(5) = '1') then
                nbiot1_id <= cnt_nbiot1(5);
            elsif (nbiot1_tick(6) = '1') then
                nbiot1_id <= cnt_nbiot1(6);
            end if;
            if    (nbiot2_tick(0) = '1') then
                nbiot2_id <= cnt_nbiot2(0);
            elsif (nbiot2_tick(1) = '1') then
                nbiot2_id <= cnt_nbiot2(1);
            elsif (nbiot2_tick(2) = '1') then
                nbiot2_id <= cnt_nbiot2(2);
            elsif (nbiot2_tick(3) = '1') then
                nbiot2_id <= cnt_nbiot2(3);
            elsif (nbiot2_tick(4) = '1') then
                nbiot2_id <= cnt_nbiot2(4);
            elsif (nbiot2_tick(5) = '1') then
                nbiot2_id <= cnt_nbiot2(5);
            elsif (nbiot2_tick(6) = '1') then
                nbiot2_id <= cnt_nbiot2(6);
            end if;
        end if;
    end process;
    end generate;

    u_8CHANNEL : if MAX_CH = 8 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            elsif (puxch_tick(1) = '1') then
                puxch_id <= cnt_puxch(1);
            elsif (puxch_tick(2) = '1') then
                puxch_id <= cnt_puxch(2);
            elsif (puxch_tick(3) = '1') then
                puxch_id <= cnt_puxch(3);
            elsif (puxch_tick(4) = '1') then
                puxch_id <= cnt_puxch(4);
            elsif (puxch_tick(5) = '1') then
                puxch_id <= cnt_puxch(5);
            elsif (puxch_tick(6) = '1') then
                puxch_id <= cnt_puxch(6);
            elsif (puxch_tick(7) = '1') then
                puxch_id <= cnt_puxch(7);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            elsif (prach_tick(1) = '1') then
                prach_id <= cnt_prach(1);
            elsif (prach_tick(2) = '1') then
                prach_id <= cnt_prach(2);
            elsif (prach_tick(3) = '1') then
                prach_id <= cnt_prach(3);
            elsif (prach_tick(4) = '1') then
                prach_id <= cnt_prach(4);
            elsif (prach_tick(5) = '1') then
                prach_id <= cnt_prach(5);
            elsif (prach_tick(6) = '1') then
                prach_id <= cnt_prach(6);
            elsif (prach_tick(7) = '1') then
                prach_id <= cnt_prach(7);
            end if;
            if    (emtc_tick(0) = '1') then
                emtc_id <= cnt_emtc(0);
            elsif (emtc_tick(1) = '1') then
                emtc_id <= cnt_emtc(1);
            elsif (emtc_tick(2) = '1') then
                emtc_id <= cnt_emtc(2);
            elsif (emtc_tick(3) = '1') then
                emtc_id <= cnt_emtc(3);
            elsif (emtc_tick(4) = '1') then
                emtc_id <= cnt_emtc(4);
            elsif (emtc_tick(5) = '1') then
                emtc_id <= cnt_emtc(5);
            elsif (emtc_tick(6) = '1') then
                emtc_id <= cnt_emtc(6);
            elsif (emtc_tick(7) = '1') then
                emtc_id <= cnt_emtc(7);
            end if;
            if    (nbiot0_tick(0) = '1') then
                nbiot0_id <= cnt_nbiot0(0);
            elsif (nbiot0_tick(1) = '1') then
                nbiot0_id <= cnt_nbiot0(1);
            elsif (nbiot0_tick(2) = '1') then
                nbiot0_id <= cnt_nbiot0(2);
            elsif (nbiot0_tick(3) = '1') then
                nbiot0_id <= cnt_nbiot0(3);
            elsif (nbiot0_tick(4) = '1') then
                nbiot0_id <= cnt_nbiot0(4);
            elsif (nbiot0_tick(5) = '1') then
                nbiot0_id <= cnt_nbiot0(5);
            elsif (nbiot0_tick(6) = '1') then
                nbiot0_id <= cnt_nbiot0(6);
            elsif (nbiot0_tick(7) = '1') then
                nbiot0_id <= cnt_nbiot0(7);
            end if;
            if    (nbiot1_tick(0) = '1') then
                nbiot1_id <= cnt_nbiot1(0);
            elsif (nbiot1_tick(1) = '1') then
                nbiot1_id <= cnt_nbiot1(1);
            elsif (nbiot1_tick(2) = '1') then
                nbiot1_id <= cnt_nbiot1(2);
            elsif (nbiot1_tick(3) = '1') then
                nbiot1_id <= cnt_nbiot1(3);
            elsif (nbiot1_tick(4) = '1') then
                nbiot1_id <= cnt_nbiot1(4);
            elsif (nbiot1_tick(5) = '1') then
                nbiot1_id <= cnt_nbiot1(5);
            elsif (nbiot1_tick(6) = '1') then
                nbiot1_id <= cnt_nbiot1(6);
            elsif (nbiot1_tick(7) = '1') then
                nbiot1_id <= cnt_nbiot1(7);
            end if;
            if    (nbiot2_tick(0) = '1') then
                nbiot2_id <= cnt_nbiot2(0);
            elsif (nbiot2_tick(1) = '1') then
                nbiot2_id <= cnt_nbiot2(1);
            elsif (nbiot2_tick(2) = '1') then
                nbiot2_id <= cnt_nbiot2(2);
            elsif (nbiot2_tick(3) = '1') then
                nbiot2_id <= cnt_nbiot2(3);
            elsif (nbiot2_tick(4) = '1') then
                nbiot2_id <= cnt_nbiot2(4);
            elsif (nbiot2_tick(5) = '1') then
                nbiot2_id <= cnt_nbiot2(5);
            elsif (nbiot2_tick(6) = '1') then
                nbiot2_id <= cnt_nbiot2(6);
            elsif (nbiot2_tick(7) = '1') then
                nbiot2_id <= cnt_nbiot2(7);
            end if;
        end if;
    end process;
    end generate;

    u_CH : for i in MAX_CH-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (PUxCH_PACKING_TICK(i) = '1') then
                cnt_puxch(i) <= cnt_puxch(i) + 1;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (PRACH_PACKING_TICK(i) = '1') and (eMTC_PACKING_TICK(i) = '1') and (NBIOT2_PACKING_TICK(i) = '1') then
                cnt_seed0(i)  <= cnt_seed0(i) + 3;
                cnt_prach(i)  <= cnt_seed0(i) + 0;
                cnt_emtc(i)   <= cnt_seed0(i) + 1;
                cnt_nbiot2(i) <= cnt_seed0(i) + 2;
            elsif (PRACH_PACKING_TICK(i) = '1') and (eMTC_PACKING_TICK(i) = '1') and (NBIOT2_PACKING_TICK(i) = '0') then
                cnt_seed0(i)  <= cnt_seed0(i) + 2;
                cnt_prach(i)  <= cnt_seed0(i) + 0;
                cnt_emtc(i)   <= cnt_seed0(i) + 1;
            elsif (PRACH_PACKING_TICK(i) = '1') and (eMTC_PACKING_TICK(i) = '0') and (NBIOT2_PACKING_TICK(i) = '1') then
                cnt_seed0(i)  <= cnt_seed0(i) + 2;
                cnt_prach(i)  <= cnt_seed0(i) + 0;
                cnt_nbiot2(i) <= cnt_seed0(i) + 1;
            elsif (PRACH_PACKING_TICK(i) = '0') and (eMTC_PACKING_TICK(i) = '1') and (NBIOT2_PACKING_TICK(i) = '1') then
                cnt_seed0(i)  <= cnt_seed0(i) + 2;
                cnt_emtc(i)   <= cnt_seed0(i) + 0;
                cnt_nbiot2(i) <= cnt_seed0(i) + 1;
            elsif (PRACH_PACKING_TICK(i) = '1') then
                cnt_seed0(i)  <= cnt_seed0(i) + 1;
                cnt_prach(i)  <= cnt_seed0(i) + 0;
            elsif (eMTC_PACKING_TICK(i) = '1') then
                cnt_seed0(i)  <= cnt_seed0(i) + 1;
                cnt_emtc(i)   <= cnt_seed0(i) + 0;
            elsif (NBIOT0_PACKING_TICK(i) = '1') then
                cnt_seed0(i)  <= cnt_seed0(i) + 1;
                cnt_nbiot2(i) <= cnt_seed0(i) + 0;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (NBIOT0_PACKING_TICK(i) = '1') and (NBIOT1_PACKING_TICK(i) = '1') then
                cnt_seed1(i)  <= cnt_seed1(i) + 2;
                cnt_nbiot0(i) <= cnt_seed1(i) + 0;
                cnt_nbiot1(i) <= cnt_seed1(i) + 1;
            elsif (NBIOT0_PACKING_TICK(i) = '1') then
                cnt_seed1(i)  <= cnt_seed1(i) + 1;
                cnt_nbiot0(i) <= cnt_seed1(i) + 0;
            elsif (NBIOT1_PACKING_TICK(i) = '1') then
                cnt_seed1(i)  <= cnt_seed1(i) + 1;
                cnt_nbiot1(i) <= cnt_seed1(i) + 0;
            end if;
        end if;
    end process;
    end generate;

end BEHAVE;