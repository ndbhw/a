--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : O-RAN package                                                 --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.NUMERIC_STD.ALL;

package PKG_O_RAN is

    -- Ethernet feature
    constant JUMBO_FRAME            : boolean := true;

    -- O-RAN main features
    constant RX_LINK_DIRECTION      : std_logic := '1';                         -- DU : '0', RU : '1'
    constant TX_LINK_DIRECTION      : std_logic := '0';                         -- DU : '1', RU : '0'

    -- u (Subcarrier spacing) configuration
    constant SCS_CONFIG_0           : boolean := true;
    constant SCS_CONFIG_1           : boolean := false;
    constant SCS_CONFIG_2           : boolean := false;
    constant SCS_CONFIG_3           : boolean := false;
    constant SCS_CONFIG_4           : boolean := false;

    -- udIqWidth configuration (when udCompParam is not present, no-comp/MC)
    constant RX_UNCOMP_1B           : boolean := false;
    constant RX_UNCOMP_2B           : boolean := false;
    constant RX_UNCOMP_3B           : boolean := false;
    constant RX_UNCOMP_4B           : boolean := false;
    constant RX_UNCOMP_5B           : boolean := false;
    constant RX_UNCOMP_6B           : boolean := false;
    constant RX_UNCOMP_7B           : boolean := false;
    constant RX_UNCOMP_8B           : boolean := false;
    constant RX_UNCOMP_9B           : boolean := false;
    constant RX_UNCOMP_10B          : boolean := false;
    constant RX_UNCOMP_11B          : boolean := false;
    constant RX_UNCOMP_12B          : boolean := false;
    constant RX_UNCOMP_13B          : boolean := false;
    constant RX_UNCOMP_14B          : boolean := false;
    constant RX_UNCOMP_15B          : boolean := false;
    constant RX_UNCOMP_16B          : boolean := true;

    constant TX_UNCOMP_1B           : boolean := false;
    constant TX_UNCOMP_2B           : boolean := false;
    constant TX_UNCOMP_3B           : boolean := false;
    constant TX_UNCOMP_4B           : boolean := false;
    constant TX_UNCOMP_5B           : boolean := false;
    constant TX_UNCOMP_6B           : boolean := false;
    constant TX_UNCOMP_7B           : boolean := false;
    constant TX_UNCOMP_8B           : boolean := false;
    constant TX_UNCOMP_9B           : boolean := false;
    constant TX_UNCOMP_10B          : boolean := false;
    constant TX_UNCOMP_11B          : boolean := false;
    constant TX_UNCOMP_12B          : boolean := false;
    constant TX_UNCOMP_13B          : boolean := false;
    constant TX_UNCOMP_14B          : boolean := false;
    constant TX_UNCOMP_15B          : boolean := false;
    constant TX_UNCOMP_16B          : boolean := true;

    -- udIqWidth configuration (when udCompParam is present, BFP/BS/u-law)
    constant RX_COMP_1B             : boolean := false;
    constant RX_COMP_2B             : boolean := false;
    constant RX_COMP_3B             : boolean := false;
    constant RX_COMP_4B             : boolean := false;
    constant RX_COMP_5B             : boolean := false;
    constant RX_COMP_6B             : boolean := false;
    constant RX_COMP_7B             : boolean := false;
    constant RX_COMP_8B             : boolean := false;
    constant RX_COMP_9B             : boolean := true;
    constant RX_COMP_10B            : boolean := false;
    constant RX_COMP_11B            : boolean := false;
    constant RX_COMP_12B            : boolean := true;
    constant RX_COMP_13B            : boolean := false;
    constant RX_COMP_14B            : boolean := true;
    constant RX_COMP_15B            : boolean := false;
    constant RX_COMP_16B            : boolean := false;

    constant TX_COMP_1B             : boolean := false;
    constant TX_COMP_2B             : boolean := false;
    constant TX_COMP_3B             : boolean := false;
    constant TX_COMP_4B             : boolean := false;
    constant TX_COMP_5B             : boolean := false;
    constant TX_COMP_6B             : boolean := false;
    constant TX_COMP_7B             : boolean := false;
    constant TX_COMP_8B             : boolean := false;
    constant TX_COMP_9B             : boolean := true;
    constant TX_COMP_10B            : boolean := false;
    constant TX_COMP_11B            : boolean := false;
    constant TX_COMP_12B            : boolean := true;
    constant TX_COMP_13B            : boolean := false;
    constant TX_COMP_14B            : boolean := true;
    constant TX_COMP_15B            : boolean := false;
    constant TX_COMP_16B            : boolean := false;

    -- user function
    function KEEP_TO_EMPTY_LSB (DATA_VALUE : std_logic_vector(7 downto 0)) return std_logic_vector;
    function EMPTY_TO_KEEP_LSB (DATA_VALUE : std_logic_vector(3 downto 0)) return std_logic_vector;
    function KEEP_TO_EMPTY_MSB (DATA_VALUE : std_logic_vector(7 downto 0)) return std_logic_vector;
    function EMPTY_TO_KEEP_MSB (DATA_VALUE : std_logic_vector(2 downto 0)) return std_logic_vector;
    function LOG2 (DATA_VALUE : natural) return natural;

end PKG_O_RAN;

package body PKG_O_RAN is

    function KEEP_TO_EMPTY_LSB (
        DATA_VALUE                  : std_logic_vector(7 downto 0)
    )
    return std_logic_vector is
    begin
        case DATA_VALUE is
        when "00000001" => return "0001";
        when "00000011" => return "0010";
        when "00000111" => return "0011";
        when "00001111" => return "0100";
        when "00011111" => return "0101";
        when "00111111" => return "0110";
        when "01111111" => return "0111";
        when "11111111" => return "1000";
        when others     => return "1000";
        end case;
    end KEEP_TO_EMPTY_LSB;

    function EMPTY_TO_KEEP_LSB (
        DATA_VALUE                  : std_logic_vector(3 downto 0)
    )
    return std_logic_vector is
    begin
        case DATA_VALUE is
        when "0001"  => return "00000001";
        when "0010"  => return "00000011";
        when "0011"  => return "00000111";
        when "0100"  => return "00001111";
        when "0101"  => return "00011111";
        when "0110"  => return "00111111";
        when "0111"  => return "01111111";
        when "1000"  => return "11111111";
        when others  => return "11111111";
        end case;
    end EMPTY_TO_KEEP_LSB;

    function KEEP_TO_EMPTY_MSB (
        DATA_VALUE                  : std_logic_vector(7 downto 0)
    )
    return std_logic_vector is
    begin
        case DATA_VALUE is
        when "10000000" => return "111";
        when "11000000" => return "110";
        when "11100000" => return "101";
        when "11110000" => return "100";
        when "11111000" => return "011";
        when "11111100" => return "010";
        when "11111110" => return "001";
        when "11111111" => return "000";
        when others     => return "000";
        end case;
    end KEEP_TO_EMPTY_MSB;

    function EMPTY_TO_KEEP_MSB (
        DATA_VALUE                  : std_logic_vector(2 downto 0)
    )
    return std_logic_vector is
    begin
        case DATA_VALUE is
        when "111"  => return "10000000";
        when "110"  => return "11000000";
        when "101"  => return "11100000";
        when "100"  => return "11110000";
        when "011"  => return "11111000";
        when "010"  => return "11111100";
        when "001"  => return "11111110";
        when "000"  => return "11111111";
        when others => return "11111111";
        end case;
    end EMPTY_TO_KEEP_MSB;

    function LOG2 (
        DATA_VALUE                  : natural
    )
    return natural is
        variable result             : natural := 0;
        variable cnt                : natural := 1;
    begin
        if (DATA_VALUE <= 1) then
            result := 0;
        else
            while (cnt < DATA_VALUE) loop
                result := result + 1;
                cnt    := cnt *2;
            end loop;
        end if;
        return result;
    end LOG2;

end PKG_O_RAN;