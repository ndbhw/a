--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : muxing DL 4 path to 1 path                                    --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2021.06.12                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity BB_MAP_IF_8T is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

--------------------------------------------------------------------------------
-- BB_TOP
--------------------------------------------------------------------------------

        O_UL_FSYNC                  :out std_logic_vector( 1 downto 0);    -- 1 clock frame(10ms) sync   
        O_UL_TDD                    :out std_logic_vector( 1 downto 0);       
        O_UL_VLD                    :out std_logic_vector( 7 downto 0);    -- valid signal for valid data.   
        O_UL_DATA_I                 :out std_logic_array16(7 downto 0);    -- 16b idata path per one ant path.  
        O_UL_DATA_Q                 :out std_logic_array16(7 downto 0);    -- 16b qdata path per one ant path.  

--------------------------------------------------------------------------------
-- FORMATTER
--------------------------------------------------------------------------------

        I_UL_FSYNC                  : in  std_logic;
        I_UL_TDD                    : in  std_logic;
        I_UL_SYNC                   : in  std_logic;
        I_UL_DATA                   : in  std_logic_vector(15 downto 0) 
    );
end BB_MAP_IF_8T;

architecture BEHAVE of BB_MAP_IF_8T is


       signal dl_data_i_d1               : std_logic_array16(3 downto 0) := (others => (others => '0'));    -- 16b idata path per one ant path.      
       signal dl_data_q_d1               : std_logic_array16(3 downto 0) := (others => (others => '0'));    -- 16b qdata path per one ant path.  
       signal dl_data_i_d2               : std_logic_array16(3 downto 0) := (others => (others => '0'));    -- 16b idata path per one ant path.      
       signal dl_data_q_d2               : std_logic_array16(3 downto 0) := (others => (others => '0'));    -- 16b qdata path per one ant path.  
       signal dl_data_mux                : std_logic_vector(15 downto 0) := (others => '0');

       signal dl_fsync_d                 : std_logic := '0';
       signal dl_fsync_rpls              : std_logic := '0';
       signal dl_fsync_rpls_d            : std_logic := '0';
       signal dl_chip_sync               : std_logic := '0';
       signal dl_tdd_d                   : std_logic_vector(1 downto 0) := (others => '0');
       signal dl_clk_cnt                 : std_logic_vector(5 downto 0) := (others => '1');   
       signal dl_bfn_strb                : std_logic := '0';

       signal ul_clk_cnt                 : std_logic_vector(6 downto 0) := (others => '0');
       signal ul_data_mux_d              : std_logic_vector(15 downto 0) := (others => '0');
       signal ul_fsync_d                 : std_logic := '0';
       signal ul_fsync_rpls              : std_logic := '0'; 
       signal ul_fsync_rpls_d            : std_logic_vector(16 downto 0) := (others => '0');
       signal ul_data_i                  : std_logic_array16(7 downto 0) := (others => (others => '0'));    -- 16b idata path per one ant path.  
       signal ul_data_q                  : std_logic_array16(7 downto 0) := (others => (others => '0'));    -- 16b qdata path per one ant path.  
       signal ul_sync_d                  : std_logic := '0';
       signal ul_data_i_out              : std_logic_array16(7 downto 0) := (others => (others => '0'));    -- 16b idata path per one ant path.  
       signal ul_data_q_out              : std_logic_array16(7 downto 0) := (others => (others => '0'));    -- 16b qdata path per one ant path.  


begin

    PROCESSING_DELAY_UL <= conv_std_logic_vector(10, 24);

    O_UL_FSYNC(0) <= ul_fsync_rpls_d(16); 
    O_UL_FSYNC(1) <= ul_fsync_rpls_d(16); 
    O_UL_TDD(0)   <= I_UL_TDD; 
    O_UL_TDD(1)   <= I_UL_TDD; 
    O_UL_VLD      <= (others => '1');
    O_UL_DATA_I   <= ul_data_i_out;
    O_UL_DATA_Q   <= ul_data_q_out;
    
    --UL map interface (lphy -> formatter)
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            ul_data_mux_d <= I_UL_DATA;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            ul_sync_d <= I_UL_SYNC;
            if (ul_sync_d = '1') then
                ul_clk_cnt <= (others => '0');
            else
                ul_clk_cnt <= ul_clk_cnt + 1;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            case ul_clk_cnt(3 downto 0) is
                when "0000"  => ul_data_i(0) <= ul_data_mux_d;
                when "0001"  => ul_data_q(0) <= ul_data_mux_d;
                when "0010"  => ul_data_i(1) <= ul_data_mux_d;
                when "0011"  => ul_data_q(1) <= ul_data_mux_d;
                when "0100"  => ul_data_i(2) <= ul_data_mux_d;
                when "0101"  => ul_data_q(2) <= ul_data_mux_d;
                when "0110"  => ul_data_i(3) <= ul_data_mux_d;
                when "0111"  => ul_data_q(3) <= ul_data_mux_d;
                when "1000"  => ul_data_i(4) <= ul_data_mux_d;
                when "1001"  => ul_data_q(4) <= ul_data_mux_d;
                when "1010"  => ul_data_i(5) <= ul_data_mux_d;
                when "1011"  => ul_data_q(5) <= ul_data_mux_d;
                when "1100"  => ul_data_i(6) <= ul_data_mux_d;
                when "1101"  => ul_data_q(6) <= ul_data_mux_d;
                when "1110"  => ul_data_i(7) <= ul_data_mux_d;
                when "1111"  => ul_data_q(7) <= ul_data_mux_d;
                when others  => ul_data_i    <= (others => (others => '0'));
                                ul_data_q    <= (others => (others => '0'));                               
            end case;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (ul_clk_cnt(6 downto 0) ="0010000") then
                ul_data_i_out <= ul_data_i;
                ul_data_q_out <= ul_data_q;
            else
                ul_data_i_out <= ul_data_i_out;
                ul_data_q_out <= ul_data_q_out;
            end if;
        end if;
    end process;
    
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            ul_fsync_d      <= I_UL_FSYNC;
            ul_fsync_rpls   <= I_UL_FSYNC and (not ul_fsync_d);
            ul_fsync_rpls_d <= ul_fsync_rpls_d(15 downto 0) & ul_fsync_rpls;
        end if;
    end process;

end BEHAVE;







