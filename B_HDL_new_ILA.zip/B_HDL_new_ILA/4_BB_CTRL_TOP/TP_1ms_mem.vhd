library IEEE;
use IEEE.NUMERIC_STD.all;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;


entity TP_1ms_mem is
    generic (
        NUM_ANTENNA : natural := 4
    );
    port (
        RESET            : in  std_logic;
        CLK              : in  std_logic;
        BW_SEL           : in  std_logic_vector(3 downto 0);
        TP_EN            : in  std_logic;
        TP_MEM_PEN       : in  std_logic; -- A/B port enable
        TP_MEM_AWEN      : in  std_logic; -- A port write enable
        TP_MEM_WRADDR    : in  std_logic_vector(14 downto 0);
        TP_MEM_WRDATA    : in  std_logic_vector(31 downto 0); -- 31..16 : Q data, 15..0 : I data
        PROCESSING_DELAY : out std_logic_vector(23 downto 0);

        MAP_10MS : in std_logic;
        MAP_TDD  : in std_logic;
        MAP_SYNC : in std_logic;
        MAP_DATA : in std_logic_vector(15 downto 0);

        TP_OUT_10MS : out std_logic;
        TP_OUT_TDD  : out std_logic;
        TP_OUT_SYNC : out std_logic;
        TP_OUT_DATA : out std_logic_vector(15 downto 0)
    );
end TP_1ms_mem;

architecture BEHAVE of TP_1ms_mem is

    function log2 (data_value : integer)
        return integer is
        variable result : integer := 0;
        variable cnt    : integer := 1;
    begin
        if (data_value <= 1) then
            result := 0;
        else
            while (cnt < data_value) loop
                result := result + 1;
                cnt    := cnt *2;
            end loop;
        end if;
        return result;
    end log2;



    component bb_buf is
        generic(
            STYLE         : string  := "BLOCK"; --"DISTRIBUTED","BLOCK","ultra","M20K"
            NPIPE         : integer := 6;
            DEPTH         : integer := 30720;
            WIDTH         : integer := 32;
            INIT_MEM_FILE : string  := "ETM31_3MHz_4ms_30720_2_29052025.mem"
        );
        port(
            WCLK  : in  std_logic;
            RCLK  : in  std_logic;
            WE    : in  std_logic;
            ENB   : in  std_logic;
            WADDR : in  std_logic_vector(log2(DEPTH)-1 downto 0);
            RADDR : in  std_logic_vector(log2(DEPTH)-1 downto 0);
            WDATA : in  std_logic_vector(WIDTH-1 downto 0);
            RDATA : out std_logic_vector(WIDTH-1 downto 0)
        );
    end component;

    signal map_10ms_r   : std_logic;
    signal map_tdd_r    : std_logic;
    signal map_sync_r   : std_logic;
    signal map_data_r   : std_logic_vector(15 downto 0);
    signal map_10ms_pos : std_logic;

    signal tp_10ms_r   : std_logic_vector(6 downto 0);
    signal tp_tdd_r    : std_logic_vector(6 downto 0);
    signal tp_sync_r   : std_logic_vector(6 downto 0);
    signal mem_addr    : std_logic_vector(14 downto 0);
    signal mem_rdata   : std_logic_vector(31 downto 0);

    
    signal mem_rdata_10M   : std_logic_vector(31 downto 0);
    signal mem_rdata_3M   : std_logic_vector(31 downto 0);
    
    signal valid_cnt   : std_logic_vector( 7 downto 0);
    signal valid_flag  : std_logic_vector(7 downto 0);
    signal ptn_data    : std_logic_vector(15 downto 0);
    signal cnt_sync    : std_logic_vector(5 downto 0) := (others => '0');
    signal sample_sync : std_logic_vector(7 downto 0) := (others => '0');

begin

    PROCESSING_DELAY <= conv_std_logic_vector(2, 24);
    -- chip to sample
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (MAP_SYNC = '1') then
                cnt_sync <= (others => '0');
            else
                cnt_sync <= cnt_sync + 1;
            end if;
            case BW_SEL is
                when "0001" => -- 3-MHz
                    if (cnt_sync(4 downto 0) = 31) then
                        sample_sync(0) <= '1';
                    else
                        sample_sync(0) <= '0';
                    end if;
                when "0010" => -- 5-MHz
                    if (cnt_sync(4 downto 0) = 31) then
                        sample_sync(0) <= '1';
                    else
                        sample_sync(0) <= '0';
                    end if;
                when "0011" => -- 10-MHz
                    if (cnt_sync(3 downto 0) = 15) then
                        sample_sync(0) <= '1';
                    else
                        sample_sync(0) <= '0';
                    end if;
                when others => -- 15/20-MHz
                    if (cnt_sync(2 downto 0) = 7) then
                        sample_sync(0) <= '1';
                    else
                        sample_sync(0) <= '0';
                    end if;
            end case;
            sample_sync(7 downto 1) <= sample_sync(6 downto 0);
        end if;
    end process;

    -- buffering
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            map_10ms_r <= MAP_10MS;
            map_tdd_r  <= MAP_TDD;
            map_sync_r <= MAP_SYNC;
            map_data_r <= MAP_DATA;
        end if;
    end process;

    map_10ms_pos <= MAP_10MS and (not map_10ms_r);
    -- Control TP_MEM
    process(CLK) begin
        if(RESET = '1') then
            mem_addr <= (others => '0');
        elsif(CLK'event and CLK = '1') then
            if(map_10ms_pos = '1') then
                mem_addr <= (others => '0');
            elsif (sample_sync(0) = '1') then
                if(mem_addr < 30719) then
                    mem_addr <= mem_addr + 1;
                else
                    mem_addr <= (others => '0');
                end if;
            else
                mem_addr <= mem_addr;
            end if;
        end if;
    end process;

    -- generate valid signal, 8 clk valid
    process(CLK) begin
        if(RESET = '1') then
            valid_cnt <= (others => '0');
        elsif(CLK'event and CLK = '1') then
            if(sample_sync(0) = '1') then
                valid_cnt <= x"0E";
            elsif(valid_cnt > 0) then
                valid_cnt <= valid_cnt-1;
            else
                valid_cnt <= valid_cnt;
            end if;
        end if;
    end process;

    process(CLK) begin
        if(CLK'event and CLK = '1') then
            if(valid_cnt = x"9") then
                valid_flag <= x"FF";
            else
                valid_flag <= '0' & valid_flag(7 downto 1);
            end if;
        end if;
    end process;


    -- mapping
--    process(CLK) begin
--        if(RESET = '1') then
--            ptn_data <= (others => '0');
--        elsif(CLK'event and CLK = '1') then
        
--        case BW_SEL is
--                when "0001" => -- 3-MHz
--                    if(valid_flag(0) = '1') then
--                        if (valid_cnt(0) = '0') then
--                            ptn_data <= mem_rdata_3M(30) & mem_rdata_3M(30 downto 16);
--                        else
--                            ptn_data <= mem_rdata_3M(14) & mem_rdata_3M(14 downto 0);
--                        end if;
--                    else
--                        ptn_data <= (others => '0');
--                    end if; 
                     
--                when others => -- 10-MHz 
--                    if(valid_flag(0) = '1') then
--                        if (valid_cnt(0) = '0') then
--                            ptn_data <= mem_rdata_10M(30) & mem_rdata_10M(30 downto 16);
--                        else
--                            ptn_data <= mem_rdata_10M(14) & mem_rdata_10M(14 downto 0);
--                        end if;
--                    else
--                        ptn_data <= (others => '0');
--                    end if;
                 
--            end case;
--        end if;
--    end process;

    process(CLK) begin
        if(RESET = '1') then
            ptn_data <= (others => '0');
        elsif(CLK'event and CLK = '1') then
            if(valid_flag(0) = '1') then
                if (valid_cnt(0) = '0') then
                    ptn_data <= mem_rdata(30) & mem_rdata(30 downto 16);
                else
                    ptn_data <= mem_rdata(14) & mem_rdata(14 downto 0);
                end if;
            else
                ptn_data <= (others => '0');
            end if;
        end if;
    end process;

    --------------------------------------------------------------------------------
    -- Port Mapping
    --------------------------------------------------------------------------------
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if(TP_EN = '1') then
                TP_OUT_10MS <= tp_10ms_r(0);
                TP_OUT_TDD  <= tp_tdd_r(0);
                TP_OUT_SYNC <= tp_sync_r(0);
                TP_OUT_DATA <= ptn_data;
            else
                TP_OUT_10MS <= map_10ms_r;
                TP_OUT_TDD  <= map_tdd_r;
                TP_OUT_SYNC <= map_sync_r;
                TP_OUT_DATA <= map_data_r;
            end if;

            tp_10ms_r <= map_10ms_r & tp_10ms_r(6 downto 1);
            tp_tdd_r  <= map_tdd_r & tp_tdd_r(6 downto 1);
            tp_sync_r <= map_sync_r & tp_sync_r(6 downto 1);
        end if;
    end process;


    --------------------------------------------------------------------------------
    -- Component mapping
    --------------------------------------------------------------------------------

    u_TP_MEM_3M : bb_buf
        generic map (
            STYLE         => "BLOCK",
            NPIPE         => 6,
            DEPTH         => 30720,
            WIDTH         => 32,
            INIT_MEM_FILE => "ETM31_3MHz_4ms_30720_2_29052025.mem"
           
        )
        port map (
            WCLK  => CLK,
            RCLK  => CLK,
            WE    => TP_MEM_AWEN,
            ENB   => '1',
            WADDR => TP_MEM_WRADDR,
            RADDR => mem_addr,
            WDATA => TP_MEM_WRDATA,
            RDATA => mem_rdata
        );
  
--        u_TP_MEM_3M : bb_buf
--        generic map (
--            STYLE         => "BLOCK",
--            NPIPE         => 6,
--            DEPTH         => 30720,
--            WIDTH         => 32,
--            INIT_MEM_FILE => "ETM31_10MHz_1ms_30720.mem"
--        )
--        port map (
--            WCLK  => CLK,
--            RCLK  => CLK,
--            WE    => TP_MEM_AWEN,
--            ENB   => '1',
--            WADDR => TP_MEM_WRADDR,
--            RADDR => mem_addr,
--            WDATA => TP_MEM_WRDATA,
--            RDATA => mem_rdata_3M
--        );
end BEHAVE;