--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : BBCTRL CPU interface                                          --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity CPUIF_BBCTRL is
    generic (
        OFFSET                      : std_logic_vector(3 downto 0) := x"4";
        NUM_CPRI                    : natural := 8;
        NUM_MAP                     : natural := 8;
        NUM_FMT                     : natural := 8
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_AUX                     : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        RESET                       : in  std_logic;

        DL_CPRI_IF_DELAY            : in  std_logic_array24(NUM_CPRI-1 downto 0);
        DL_CPRI_SWITCH_DELAY        : in  std_logic_vector(23 downto 0);
        DL_MAPPER_DELAY             : in  std_logic_array24(NUM_MAP-1 downto 0);
        DL_MAP_SWITCH_DELAY         : in  std_logic_vector(23 downto 0);
        DL_MAP_IF_DELAY             : in  std_logic_array24(NUM_FMT-1 downto 0);
        DL_FORMATTER_DELAY          : in  std_logic_array24(NUM_FMT-1 downto 0);

        UL_CPRI_IF_DELAY            : in  std_logic_array24(NUM_CPRI-1 downto 0);
        UL_CPRI_SWITCH_DELAY        : in  std_logic_vector(23 downto 0);
        UL_MAPPER_DELAY             : in  std_logic_array24(NUM_MAP-1 downto 0);
        UL_MAP_SWITCH_DELAY         : in  std_logic_vector(23 downto 0);
        UL_MAP_IF_DELAY             : in  std_logic_array24(NUM_FMT-1 downto 0);
        UL_FORMATTER_DELAY          : in  std_logic_array24(NUM_FMT-1 downto 0);

--------------------------------------------------------------------------------
-- Dump 
--------------------------------------------------------------------------------

        DUMP_EN                     : out std_logic;
        DUMP_SEL                    : out std_logic_vector(15 downto 0);
        
        DBG_SYNC_CNT                : in  std_logic_vector(10 downto 0);
        DBG_SYNC_CHK                : in  std_logic_vector(10 downto 0);

--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        BW_SEL                      : out std_logic_array4(NUM_FMT-1 downto 0);

--------------------------------------------------------------------------------
-- Mapper control
--------------------------------------------------------------------------------

        DL_MAP_WR_EN                : out std_logic_vector(NUM_MAP-1 downto 0);
        DL_MAP_WR_ADDR              : out std_logic_vector(4 downto 0);
        DL_MAP_WR_DATA              : out std_logic_vector(6 downto 0);
        DL_MAP_RD_DATA              : in  std_logic_array7(NUM_MAP-1 downto 0);

        UL_MAP_WR_EN                : out std_logic_vector(NUM_MAP-1 downto 0);
        UL_MAP_WR_ADDR              : out std_logic_vector(5 downto 0);
        UL_MAP_WR_DATA              : out std_logic_vector(6 downto 0);
        UL_MAP_RD_DATA              : in  std_logic_array7(NUM_MAP-1 downto 0);

        MAP_CPRI                    : out std_logic_array8(NUM_MAP-1 downto 0);

--------------------------------------------------------------------------------
-- S/W control
--------------------------------------------------------------------------------

        MAPPER_UL_MAP               : out std_logic_array16(NUM_MAP-1 downto 0);
        FORMATTER_DL_MAP            : out std_logic_array16(NUM_FMT-1 downto 0);
        CASCADE_UL_SUM              : out std_logic_array16(2 downto 0);

--------------------------------------------------------------------------------
-- Formatter control
--------------------------------------------------------------------------------

        SYNC_DELAY_VALUE            : out std_logic_array32(NUM_FMT-1 downto 0);

        DL_DELAY_VALUE              : out std_logic_array32(NUM_FMT-1 downto 0);
        UL_DELAY_VALUE              : out std_logic_array32(NUM_FMT-1 downto 0);

        ZRHC_BYPASS                 : out std_logic_vector(NUM_FMT-1 downto 0);
        ZRHC_THRESHOLD              : out std_logic_array32(NUM_FMT-1 downto 0);
        ZRHC_OCCUR                  : in  std_logic_array4(NUM_FMT-1 downto 0);

        DL_ON                       : out std_logic_array4(NUM_FMT-1 downto 0);
        UL_ON                       : out std_logic_array4(NUM_FMT-1 downto 0);

        DL_ATT_0                    : out std_logic_array16(NUM_FMT-1 downto 0);
        DL_ATT_1                    : out std_logic_array16(NUM_FMT-1 downto 0);
        DL_ATT_2                    : out std_logic_array16(NUM_FMT-1 downto 0);
        DL_ATT_3                    : out std_logic_array16(NUM_FMT-1 downto 0);

        UL_ATT_0                    : out std_logic_array16(NUM_FMT-1 downto 0);
        UL_ATT_1                    : out std_logic_array16(NUM_FMT-1 downto 0);
        UL_ATT_2                    : out std_logic_array16(NUM_FMT-1 downto 0);
        UL_ATT_3                    : out std_logic_array16(NUM_FMT-1 downto 0);

        TSSI_UPDATE_MODE            : out std_logic_vector(1 downto 0);
        TSSI_UPDATE_CNT_0           : out std_logic_array5(NUM_FMT-1 downto 0);
        TSSI_UPDATE_CNT_1           : out std_logic_array5(NUM_FMT-1 downto 0);
        TSSI_UPDATE_CNT_2           : out std_logic_array5(NUM_FMT-1 downto 0);
        TSSI_UPDATE_CNT_3           : out std_logic_array5(NUM_FMT-1 downto 0);

        RSSI_UPDATE_MODE            : out std_logic_vector(1 downto 0);
        RSSI_UPDATE_CNT_0           : out std_logic_array5(NUM_FMT-1 downto 0);
        RSSI_UPDATE_CNT_1           : out std_logic_array5(NUM_FMT-1 downto 0);
        RSSI_UPDATE_CNT_2           : out std_logic_array5(NUM_FMT-1 downto 0);
        RSSI_UPDATE_CNT_3           : out std_logic_array5(NUM_FMT-1 downto 0);

        TSSI_0                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        TSSI_1                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        TSSI_2                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        TSSI_3                      : in  std_logic_array32(NUM_FMT-1 downto 0);

        RSSI_0                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        RSSI_1                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        RSSI_2                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        RSSI_3                      : in  std_logic_array32(NUM_FMT-1 downto 0);

--------------------------------------------------------------------------------
-- Cascade repeater mode scale factor
--------------------------------------------------------------------------------

        SCALE_FACTOR                : out std_logic_array3(5 downto 0);

--------------------------------------------------------------------------------
-- Test pattern
--------------------------------------------------------------------------------

        TEST_MODE                   : out std_logic_array4(NUM_FMT-1 downto 0);
        TP_EN                       : out std_logic;
	    TP_MEM_PEN                  : out std_logic; -- A/B port enable
	    TP_MEM_AWEN                 : out std_logic; -- A port write enable
	    TP_MEM_WRADDR               : out std_logic_vector(14 downto 0);
	    TP_MEM_WRDATA               : out std_logic_vector(31 downto 0); -- 31..16 : Q data, 15..0 : I data
        TEST_DC_I                   : out std_logic_vector(15 downto 0);
        TEST_DC_Q                   : out std_logic_vector(15 downto 0);
        TEST_NCO                    : out std_logic_vector(5 downto 0);

--------------------------------------------------------------------------------
-- CPUIF_TOP
--------------------------------------------------------------------------------

        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);    
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             : out std_logic
    );
end CPUIF_BBCTRL;

architecture BEHAVE of CPUIF_BBCTRL is

    constant C_MODULE_INFO          : std_logic_vector(31 downto 0) := x"00000030";  
    constant C_STRUCT_INFO_0        : std_logic_vector(31 downto 0) := x"00000000";
    constant C_MODULE_DATE          : std_logic_vector(31 downto 0) := x"20170517"; 
    constant C_STRUCT_INFO_1        : std_logic_vector(31 downto 0) := x"0000" &
                                                                       conv_std_logic_vector(NUM_CPRI, 4) &
                                                                       conv_std_logic_vector(NUM_MAP, 4) &
                                                                       x"4" &
                                                                       conv_std_Logic_vector(NUM_FMT, 4);

    signal reset_sysx8              : std_logic;

    signal we_buf                   : std_logic;
    signal we                       : std_logic_vector(15 downto 0);
    signal oe_buf                   : std_logic;
    signal oe                       : std_logic_vector(15 downto 0);
    signal addr_msb                 : std_logic_vector(3 downto 0);
    signal addr_lsb                 : std_logic_vector(7 downto 0);
    signal read_data                : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal valid                    : std_logic_vector(5 downto 0);

    signal we_buf_sysx8             : std_logic_vector(2 downto 0);
    signal we_sysx8                 : std_logic_vector(15 downto 0);
    signal oe_buf_sysx8             : std_logic_vector(2 downto 0);
    signal oe_sysx8                 : std_logic_vector(15 downto 0);

    component RST_SYNC is
    generic (
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port (
        RST_IN                      : in  std_logic;
        CLK                         : in  std_logic;
        RST_OUT                     : out std_logic
    );
    end component;
    
    component COMP_WRITE is
    generic (
        BIT_ENABLE                  : std_logic_vector(31 downto 0) := (others => '1');
        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0');
        REG_DATA                    : std_logic_vector(31 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        EN                          : in  std_logic;
        ADDR                        : in  std_logic_vector(7 downto 0);
        DATA_IN                     : in  std_logic_vector(31 downto 0);
        DATA_OUT                    : out std_logic_vector(31 downto 0)
    );
    end component;

    signal test_ctrl0_r             : std_logic_vector(31 downto 0);
    signal test_ctrl1_r             : std_logic_vector(31 downto 0);

    signal dl_proc_dly_w            : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal ul_proc_dly_w            : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal dl_cpri_if_delay_w       : std_logic_array24(7 downto 0) := (others => (others => '0'));
    signal dl_mapper_delay_w        : std_logic_array24(7 downto 0) := (others => (others => '0'));
    signal dl_formatter_delay_w     : std_logic_array24(7 downto 0) := (others => (others => '0'));
    signal dl_map_if_delay_w        : std_logic_array24(7 downto 0) := (others => (others => '0'));
    signal ul_cpri_if_delay_w       : std_logic_array24(7 downto 0) := (others => (others => '0'));
    signal ul_mapper_delay_w        : std_logic_array24(7 downto 0) := (others => (others => '0'));
    signal ul_formatter_delay_w     : std_logic_array24(7 downto 0) := (others => (others => '0'));
    signal ul_map_if_delay_w        : std_logic_array24(7 downto 0) := (others => (others => '0'));

    signal bw_sel_r                 : std_logic_vector(31 downto 0);

    signal dl_delay_value_r         : std_logic_array32(7 downto 0) := (others => (others => '0')); 
    signal ul_delay_value_r         : std_logic_array32(7 downto 0) := (others => (others => '0')); 

    signal dl_on_r                  : std_logic_vector(31 downto 0);
    signal ul_on_r                  : std_logic_vector(31 downto 0);

    signal tssi_update_mode_r       : std_logic_vector(31 downto 0);
    signal tssi_update_cnt_r        : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal rssi_update_mode_r       : std_logic_vector(31 downto 0);
    signal rssi_update_cnt_r        : std_logic_array32(7 downto 0) := (others => (others => '0'));

    signal tssi_0_w                 : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal tssi_1_w                 : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal tssi_2_w                 : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal tssi_3_w                 : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal rssi_0_w                 : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal rssi_1_w                 : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal rssi_2_w                 : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal rssi_3_w                 : std_logic_array32(7 downto 0) := (others => (others => '0'));

    signal dl_att_0_r               : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal dl_att_1_r               : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal dl_att_2_r               : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal dl_att_3_r               : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal ul_att_0_r               : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal ul_att_1_r               : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal ul_att_2_r               : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal ul_att_3_r               : std_logic_array32(7 downto 0) := (others => (others => '0'));

    signal map_buf_sel_r            : std_logic_vector(31 downto 0);
    signal map_wr_addr_r            : std_logic_vector(31 downto 0);
    signal map_wr_data_r            : std_logic_vector(31 downto 0);
    signal map_ctrl_r               : std_logic_vector(31 downto 0);
    signal map_dl_ctrl              : std_logic_vector(1 downto 0);
    signal map_ul_ctrl              : std_logic_vector(1 downto 0);
    signal map_cpri_r               : std_logic_array32(7 downto 0) := (others => (others => '0'));

    signal dl_map_rd_data_w         : std_logic_array7(7 downto 0) := (others => (others => '0'));
    signal ul_map_rd_data_w         : std_logic_array7(7 downto 0) := (others => (others => '0'));
    signal map_dl_rd_data_r         : std_logic_vector(7 downto 0);
    signal map_ul_rd_data_r         : std_logic_vector(7 downto 0);

    signal mapper_ul_map_r          : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal formatter_dl_map_r       : std_logic_array32(7 downto 0) := (others => (others => '0'));

    signal zrhc_bypass_r            : std_logic_vector(31 downto 0);
    signal zrhc_threshold_r         : std_logic_array32(7 downto 0) := (others => (others => '0'));

    signal sync_delay_value_r       : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal sync_delay_value_r_mask  : std_logic_array32(7 downto 0) := (others => (others => '0'));

    signal test_mode_r              : std_logic_vector(31 downto 0);
    signal tp_1ms_en                : std_logic_vector(31 downto 0);
    signal tp_mem_rwctrl_r          : std_logic_vector(31 downto 0);
    signal tp_mem_wraddr_r          : std_logic_vector(31 downto 0);
    signal tp_mem_wrdata_r          : std_logic_vector(31 downto 0);
    signal dl_data_sel_r            : std_logic_vector(31 downto 0);
    signal test_dc_data_r           : std_logic_vector(31 downto 0);
    signal test_nco_r               : std_logic_vector(31 downto 0);

    signal dbg_sync_cnt_w           : std_logic_vector(31 downto 0); 
    signal dbg_sync_chk_w           : std_logic_vector(31 downto 0); 

begin

    u_RESET : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => RESET                                   ,--: in  std_logic;
        CLK                         => CLK_SYSX8                               ,--: in  std_logic;
        RST_OUT                     => reset_sysx8                              --: out std_logic
    );

--------------------------------------------------------------------------------
-- WE/OE, addresss decoding
--------------------------------------------------------------------------------

    process (RESET, CLK_AUX)
    begin
        if (RESET = '1') then
            we_buf <= '0';
            oe_buf <= '0';
        elsif (CLK_AUX'event and CLK_AUX = '1') then
            we_buf <= WREN_CPUIF_IN;
            oe_buf <= RDEN_CPUIF_IN;
        end if;
    end process;

    process (RESET, CLK_AUX)
    begin
        if (RESET = '1') then
            we <= (others => '0');
            oe <= (others => '0');
        elsif (CLK_AUX'event and CLK_AUX = '1') then
            for i in 15 downto 0 loop
            if (ADDR_CPUIF_IN(15 downto 12) = OFFSET) and (addr_msb = i) then
                if (WREN_CPUIF_IN = '1') and (we_buf = '0') then        we(i) <= '1';
                else                                                    we(i) <= '0';
                end if;
                if (RDEN_CPUIF_IN = '1') and (oe_buf = '0') then        oe(i) <= '1';
                else                                                    oe(i) <= '0';
                end if;
            end if;
            end loop;
        end if;
    end process;

    addr_msb <= ADDR_CPUIF_IN(11 downto 8);
    addr_lsb <= ADDR_CPUIF_IN(7 downto 0);

    process (RESET, CLK_AUX)
    begin
        if (RESET = '1') then
            valid           <= (others => '0');
            RDVAL_CPUIF_OUT <= '0';
        elsif (CLK_AUX'event and CLK_AUX = '1') then
            valid           <= valid(4 downto 0) & RDEN_CPUIF_IN;
            if (valid(5 downto 4) = "01") then
                RDVAL_CPUIF_OUT <= '1';
            else
                RDVAL_CPUIF_OUT <= '0';
            end if;
        end if;
    end process;

    process (reset_sysx8, CLK_SYSX8)
    begin
        if (reset_sysx8 = '1') then
            we_buf_sysx8 <= (others => '0');
            oe_buf_sysx8 <= (others => '0');
        elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            we_buf_sysx8 <= we_buf_sysx8(1 downto 0) & WREN_CPUIF_IN;
            oe_buf_sysx8 <= oe_buf_sysx8(1 downto 0) & RDEN_CPUIF_IN;
        end if;
    end process;

    process (reset_sysx8, CLK_SYSX8)
    begin
        if (reset_sysx8 = '1') then
            we_sysx8 <= (others => '0');
            oe_sysx8 <= (others => '0');
        elsif (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            for i in 15 downto 0 loop
            if (ADDR_CPUIF_IN(15 downto 12) = OFFSET) and (addr_msb = i) then
                if (we_buf_sysx8(2 downto 1) = "01") then               we_sysx8(i) <= '1';
                else                                                    we_sysx8(i) <= '0';
                end if;
                if (oe_buf_sysx8(2 downto 1) = "01") then               oe_sysx8(i) <= '1';
                else                                                    oe_sysx8(i) <= '0';
                end if;
            end if;
            end loop;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Read Mux
--------------------------------------------------------------------------------

    process (RESET, CLK_AUX)
    begin
        if (RESET = '1') then
            RDATA_CPUIF_OUT <= (others => '0');
        elsif (CLK_AUX'event and CLK_AUX = '1') then
                case addr_msb is
                when x"0"   => RDATA_CPUIF_OUT <= read_data(0);
                when x"1"   => RDATA_CPUIF_OUT <= read_data(1);
                when x"2"   => RDATA_CPUIF_OUT <= read_data(2);
                when x"3"   => RDATA_CPUIF_OUT <= read_data(3);
                when x"4"   => RDATA_CPUIF_OUT <= read_data(4);
                when x"5"   => RDATA_CPUIF_OUT <= read_data(5);
                when x"6"   => RDATA_CPUIF_OUT <= read_data(6);
                when x"7"   => RDATA_CPUIF_OUT <= read_data(7);
                when x"8"   => RDATA_CPUIF_OUT <= read_data(8);
                when x"9"   => RDATA_CPUIF_OUT <= read_data(9);
                when x"A"   => RDATA_CPUIF_OUT <= read_data(10);
                when x"B"   => RDATA_CPUIF_OUT <= read_data(11);
                when x"C"   => RDATA_CPUIF_OUT <= read_data(12);
                when x"D"   => RDATA_CPUIF_OUT <= read_data(13);
                when x"E"   => RDATA_CPUIF_OUT <= read_data(14);
                when others => RDATA_CPUIF_OUT <= read_data(15);
                end case;
        end if;
    end process;

    -- 0x0000 (CLK_AUX)
    process (CLK_AUX)
    begin
        if (CLK_AUX'event and CLK_AUX = '1') then
                case addr_lsb is
                when x"00"  => read_data(0) <= C_MODULE_INFO;
                when x"01"  => read_data(0) <= C_STRUCT_INFO_0;
                when x"02"  => read_data(0) <= C_MODULE_DATE;
                when x"04"  => read_data(0) <= C_STRUCT_INFO_1;
                when x"0C"  => read_data(0) <= test_ctrl0_r;
                when x"0D"  => read_data(0) <= test_ctrl1_r;
                when x"0E"  => read_data(0) <= dbg_sync_cnt_w;
                when x"0F"  => read_data(0) <= dbg_sync_chk_w;

                when x"10"  => read_data(0) <= dl_proc_dly_w(0);
                when x"11"  => read_data(0) <= ul_proc_dly_w(0);
                when x"20"  => read_data(0) <= dl_proc_dly_w(1);
                when x"21"  => read_data(0) <= ul_proc_dly_w(1);
                when x"30"  => read_data(0) <= dl_proc_dly_w(2);
                when x"31"  => read_data(0) <= ul_proc_dly_w(2);
                when x"40"  => read_data(0) <= dl_proc_dly_w(3);
                when x"41"  => read_data(0) <= ul_proc_dly_w(3);
                when x"50"  => read_data(0) <= dl_proc_dly_w(4);
                when x"51"  => read_data(0) <= ul_proc_dly_w(4);
                when x"60"  => read_data(0) <= dl_proc_dly_w(5);
                when x"61"  => read_data(0) <= ul_proc_dly_w(5);
                when x"70"  => read_data(0) <= dl_proc_dly_w(6);
                when x"71"  => read_data(0) <= ul_proc_dly_w(6);
                when x"80"  => read_data(0) <= dl_proc_dly_w(7);
                when x"81"  => read_data(0) <= ul_proc_dly_w(7);
                when others => read_data(0) <= (others => '0');
                end case;
        end if;
    end process;

    -- 0x1000 (CLK_AUX)
    process (CLK_AUX)
    begin
        if (CLK_AUX'event and CLK_AUX = '1') then
                case addr_lsb is
                when x"00"  => read_data(1) <= bw_sel_r;
                when others => read_data(1) <= (others => '0');
                end case;
        end if;
    end process;

    -- 0x2000 (CLK_SYSX8)
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (oe_buf_sysx8(2 downto 1) = "01") then
                case addr_lsb is
                when x"00"  => read_data(2)  <= dl_delay_value_r(0);
                when x"01"  => read_data(2)  <= dl_delay_value_r(1);
                when x"02"  => read_data(2)  <= dl_delay_value_r(2);
                when x"03"  => read_data(2)  <= dl_delay_value_r(3);
                when x"04"  => read_data(2)  <= dl_delay_value_r(4);
                when x"05"  => read_data(2)  <= dl_delay_value_r(5);
                when x"06"  => read_data(2)  <= dl_delay_value_r(6);
                when x"07"  => read_data(2)  <= dl_delay_value_r(7);
                when x"80"  => read_data(2)  <= ul_delay_value_r(0);
                when x"81"  => read_data(2)  <= ul_delay_value_r(1);
                when x"82"  => read_data(2)  <= ul_delay_value_r(2);
                when x"83"  => read_data(2)  <= ul_delay_value_r(3);
                when x"84"  => read_data(2)  <= ul_delay_value_r(4);
                when x"85"  => read_data(2)  <= ul_delay_value_r(5);
                when x"86"  => read_data(2)  <= ul_delay_value_r(6);
                when x"87"  => read_data(2)  <= ul_delay_value_r(7);
                when others => read_data(2)  <= (others => '0');
                end case;
            end if;
        end if;
    end process;

    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (oe_buf_sysx8(2 downto 1) = "01") then
                case addr_lsb is
                when x"00"  => read_data(3) <= dl_on_r;
                when x"10"  => read_data(3) <= ul_on_r;
                when others => read_data(3) <= (others => '0');
                end case;
            end if;
        end if;
    end process;

    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (oe_buf_sysx8(2 downto 1) = "01") then
                case addr_lsb is
                when x"00"  => read_data(4)  <= tssi_0_w(0);
                when x"01"  => read_data(4)  <= tssi_1_w(0);
                when x"02"  => read_data(4)  <= tssi_2_w(0);
                when x"03"  => read_data(4)  <= tssi_3_w(0);
                when x"04"  => read_data(4)  <= tssi_0_w(1);
                when x"05"  => read_data(4)  <= tssi_1_w(1);
                when X"06"  => read_data(4)  <= tssi_2_w(1);
                when X"07"  => read_data(4)  <= tssi_3_w(1);
                when X"08"  => read_data(4)  <= tssi_0_w(2);
                when X"09"  => read_data(4)  <= tssi_1_w(2);
                when X"0A"  => read_data(4)  <= tssi_2_w(2);
                when X"0B"  => read_data(4)  <= tssi_3_w(2);
                when X"0C"  => read_data(4)  <= tssi_0_w(3);
                when X"0D"  => read_data(4)  <= tssi_1_w(3);
                when X"0E"  => read_data(4)  <= tssi_2_w(3);
                when X"0F"  => read_data(4)  <= tssi_3_w(3);
                when X"10"  => read_data(4)  <= tssi_0_w(4);
                when X"11"  => read_data(4)  <= tssi_1_w(4);
                when X"12"  => read_data(4)  <= tssi_2_w(4);
                when X"13"  => read_data(4)  <= tssi_3_w(4);
                when X"14"  => read_data(4)  <= tssi_0_w(5);
                when X"15"  => read_data(4)  <= tssi_1_w(5);
                when X"16"  => read_data(4)  <= tssi_2_w(5);
                when X"17"  => read_data(4)  <= tssi_3_w(5);
                when X"18"  => read_data(4)  <= tssi_0_w(6);
                when X"19"  => read_data(4)  <= tssi_1_w(6);
                when X"1A"  => read_data(4)  <= tssi_2_w(6);
                when X"1B"  => read_data(4)  <= tssi_3_w(6);
                when X"1C"  => read_data(4)  <= tssi_0_w(7);
                when X"1D"  => read_data(4)  <= tssi_1_w(7);
                when X"1E"  => read_data(4)  <= tssi_2_w(7);
                when X"1F"  => read_data(4)  <= tssi_3_w(7);
                when X"40"  => read_data(4)  <= tssi_update_mode_r;
                when X"60"  => read_data(4)  <= tssi_update_cnt_r(0);
                when X"61"  => read_data(4)  <= tssi_update_cnt_r(1);
                when X"62"  => read_data(4)  <= tssi_update_cnt_r(2);
                when X"63"  => read_data(4)  <= tssi_update_cnt_r(3);
                when X"64"  => read_data(4)  <= tssi_update_cnt_r(4);
                when X"65"  => read_data(4)  <= tssi_update_cnt_r(5);
                when X"66"  => read_data(4)  <= tssi_update_cnt_r(6);
                when X"67"  => read_data(4)  <= tssi_update_cnt_r(7);
                when X"80"  => read_data(4)  <= rssi_0_w(0);
                when X"81"  => read_data(4)  <= rssi_1_w(0);
                when X"82"  => read_data(4)  <= rssi_2_w(0);
                when X"83"  => read_data(4)  <= rssi_3_w(0);
                when X"84"  => read_data(4)  <= rssi_0_w(1);
                when X"85"  => read_data(4)  <= rssi_1_w(1);
                when X"86"  => read_data(4)  <= rssi_2_w(1);
                when X"87"  => read_data(4)  <= rssi_3_w(1);
                when X"88"  => read_data(4)  <= rssi_0_w(2);
                when X"89"  => read_data(4)  <= rssi_1_w(2);
                when X"8A"  => read_data(4)  <= rssi_2_w(2);
                when X"8B"  => read_data(4)  <= rssi_3_w(2);
                when X"8C"  => read_data(4)  <= rssi_0_w(3);
                when X"8D"  => read_data(4)  <= rssi_1_w(3);
                when X"8E"  => read_data(4)  <= rssi_2_w(3);
                when X"8F"  => read_data(4)  <= rssi_3_w(3);
                when X"90"  => read_data(4)  <= rssi_0_w(4);
                when X"91"  => read_data(4)  <= rssi_1_w(4);
                when X"92"  => read_data(4)  <= rssi_2_w(4);
                when X"93"  => read_data(4)  <= rssi_3_w(4);
                when X"94"  => read_data(4)  <= rssi_0_w(5);
                when X"95"  => read_data(4)  <= rssi_1_w(5);
                when X"96"  => read_data(4)  <= rssi_2_w(5);
                when X"97"  => read_data(4)  <= rssi_3_w(5);
                when X"98"  => read_data(4)  <= rssi_0_w(6);
                when X"99"  => read_data(4)  <= rssi_1_w(6);
                when X"9A"  => read_data(4)  <= rssi_2_w(6);
                when X"9B"  => read_data(4)  <= rssi_3_w(6);
                when X"9C"  => read_data(4)  <= rssi_0_w(7);
                when X"9D"  => read_data(4)  <= rssi_1_w(7);
                when X"9E"  => read_data(4)  <= rssi_2_w(7);
                when X"9F"  => read_data(4)  <= rssi_3_w(7);
                when X"C0"  => read_data(4)  <= rssi_update_mode_r;
                when X"E0"  => read_data(4)  <= rssi_update_cnt_r(0);
                when X"E1"  => read_data(4)  <= rssi_update_cnt_r(1);
                when X"E2"  => read_data(4)  <= rssi_update_cnt_r(2);
                when X"E3"  => read_data(4)  <= rssi_update_cnt_r(3);
                when X"E4"  => read_data(4)  <= rssi_update_cnt_r(4);
                when X"E5"  => read_data(4)  <= rssi_update_cnt_r(5);
                when X"E6"  => read_data(4)  <= rssi_update_cnt_r(6);
                when X"E7"  => read_data(4)  <= rssi_update_cnt_r(7);
                when others => read_data(4)  <= (others => '0');
                end case;
            end if;
        end if;
    end process;

    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (oe_buf_sysx8(2 downto 1) = "01") then
                case addr_lsb is
                when x"00"  => read_data(5)  <= dl_att_0_r(0);
                when x"01"  => read_data(5)  <= dl_att_1_r(0);
                when x"02"  => read_data(5)  <= dl_att_2_r(0);
                when x"03"  => read_data(5)  <= dl_att_3_r(0);
                when x"04"  => read_data(5)  <= dl_att_0_r(1);
                when x"05"  => read_data(5)  <= dl_att_1_r(1);
                when x"06"  => read_data(5)  <= dl_att_2_r(1);
                when x"07"  => read_data(5)  <= dl_att_3_r(1);
                when x"08"  => read_data(5)  <= dl_att_0_r(2);
                when x"09"  => read_data(5)  <= dl_att_1_r(2);
                when x"0A"  => read_data(5)  <= dl_att_2_r(2);
                when x"0B"  => read_data(5)  <= dl_att_3_r(2);
                when x"0C"  => read_data(5)  <= dl_att_0_r(3);
                when x"0D"  => read_data(5)  <= dl_att_1_r(3);
                when x"0E"  => read_data(5)  <= dl_att_2_r(3);
                when x"0F"  => read_data(5)  <= dl_att_3_r(3);
                when x"10"  => read_data(5)  <= dl_att_0_r(4);
                when x"11"  => read_data(5)  <= dl_att_1_r(4);
                when x"12"  => read_data(5)  <= dl_att_2_r(4);
                when x"13"  => read_data(5)  <= dl_att_3_r(4);
                when x"14"  => read_data(5)  <= dl_att_0_r(5);
                when x"15"  => read_data(5)  <= dl_att_1_r(5);
                when x"16"  => read_data(5)  <= dl_att_2_r(5);
                when x"17"  => read_data(5)  <= dl_att_3_r(5);
                when x"18"  => read_data(5)  <= dl_att_0_r(6);
                when x"19"  => read_data(5)  <= dl_att_1_r(6);
                when x"1A"  => read_data(5)  <= dl_att_2_r(6);
                when x"1B"  => read_data(5)  <= dl_att_3_r(6);
                when x"1C"  => read_data(5)  <= dl_att_0_r(7);
                when x"1D"  => read_data(5)  <= dl_att_1_r(7);
                when x"1E"  => read_data(5)  <= dl_att_2_r(7);
                when x"1F"  => read_data(5)  <= dl_att_3_r(7);
                when x"80"  => read_data(5)  <= ul_att_0_r(0);
                when x"81"  => read_data(5)  <= ul_att_1_r(0);
                when x"82"  => read_data(5)  <= ul_att_2_r(0);
                when x"83"  => read_data(5)  <= ul_att_3_r(0);
                when x"84"  => read_data(5)  <= ul_att_0_r(1);
                when x"85"  => read_data(5)  <= ul_att_1_r(1);
                when x"86"  => read_data(5)  <= ul_att_2_r(1);
                when x"87"  => read_data(5)  <= ul_att_3_r(1);
                when x"88"  => read_data(5)  <= ul_att_0_r(2);
                when x"89"  => read_data(5)  <= ul_att_1_r(2);
                when x"8A"  => read_data(5)  <= ul_att_2_r(2);
                when x"8B"  => read_data(5)  <= ul_att_3_r(2);
                when x"8C"  => read_data(5)  <= ul_att_0_r(3);
                when x"8D"  => read_data(5)  <= ul_att_1_r(3);
                when x"8E"  => read_data(5)  <= ul_att_2_r(3);
                when x"8F"  => read_data(5)  <= ul_att_3_r(3);
                when x"90"  => read_data(5)  <= ul_att_0_r(4);
                when x"91"  => read_data(5)  <= ul_att_1_r(4);
                when x"92"  => read_data(5)  <= ul_att_2_r(4);
                when x"93"  => read_data(5)  <= ul_att_3_r(4);
                when x"94"  => read_data(5)  <= ul_att_0_r(5);
                when x"95"  => read_data(5)  <= ul_att_1_r(5);
                when x"96"  => read_data(5)  <= ul_att_2_r(5);
                when x"97"  => read_data(5)  <= ul_att_3_r(5);
                when x"98"  => read_data(5)  <= ul_att_0_r(6);
                when x"99"  => read_data(5)  <= ul_att_1_r(6);
                when x"9A"  => read_data(5)  <= ul_att_2_r(6);
                when x"9B"  => read_data(5)  <= ul_att_3_r(6);
                when x"9C"  => read_data(5)  <= ul_att_0_r(7);
                when x"9D"  => read_data(5)  <= ul_att_1_r(7);
                when x"9E"  => read_data(5)  <= ul_att_2_r(7);
                when x"9F"  => read_data(5)  <= ul_att_3_r(7);
                when others => read_data(5)  <= (others => '0');
                end case;
            end if;
        end if;
    end process;

    process (CLK_AUX)
    begin
        if (CLK_AUX'event and CLK_AUX = '1') then
                case addr_lsb is
                when x"00"  => read_data(8)  <= map_buf_sel_r;
                when x"01"  => read_data(8)  <= map_wr_addr_r;
                when x"02"  => read_data(8)  <= map_ul_rd_data_r & map_wr_data_r(23 downto 16) & map_dl_rd_data_r & map_wr_data_r(7 downto 0);
                when x"03"  => read_data(8)  <= map_ctrl_r;
                when x"80"  => read_data(8)  <= map_cpri_r(0);
                when x"81"  => read_data(8)  <= map_cpri_r(1);
                when x"82"  => read_data(8)  <= map_cpri_r(2);
                when x"83"  => read_data(8)  <= map_cpri_r(3);
                when x"84"  => read_data(8)  <= map_cpri_r(4);
                when x"85"  => read_data(8)  <= map_cpri_r(5);
                when x"86"  => read_data(8)  <= map_cpri_r(6);
                when x"87"  => read_data(8)  <= map_cpri_r(7);
                when others => read_data(8)  <= (others => '0');
                end case;
        end if;
    end process;

    process (CLK_AUX)
    begin
        if (CLK_AUX'event and CLK_AUX = '1') then
                case addr_lsb is
                when x"00"  => read_data(9)  <= mapper_ul_map_r(0);
                when x"01"  => read_data(9)  <= mapper_ul_map_r(1);
                when x"02"  => read_data(9)  <= mapper_ul_map_r(2);
                when x"03"  => read_data(9)  <= mapper_ul_map_r(3);
                when x"04"  => read_data(9)  <= mapper_ul_map_r(4);
                when x"05"  => read_data(9)  <= mapper_ul_map_r(5);
                when x"06"  => read_data(9)  <= mapper_ul_map_r(6);
                when x"07"  => read_data(9)  <= mapper_ul_map_r(7);
                when x"80"  => read_data(9)  <= formatter_dl_map_r(0);
                when x"81"  => read_data(9)  <= formatter_dl_map_r(1);
                when x"82"  => read_data(9)  <= formatter_dl_map_r(2);
                when x"83"  => read_data(9)  <= formatter_dl_map_r(3);
                when x"84"  => read_data(9)  <= formatter_dl_map_r(4);
                when x"85"  => read_data(9)  <= formatter_dl_map_r(5);
                when x"86"  => read_data(9)  <= formatter_dl_map_r(6);
                when x"87"  => read_data(9)  <= formatter_dl_map_r(7);
                when others => read_data(9)  <= (others => '0');
                end case;
        end if;
    end process;

    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (oe_buf_sysx8(2 downto 1) = "01") then
                case addr_lsb is
                when x"00"  => read_data(10) <= zrhc_bypass_r;
                when x"10"  => read_data(10) <= zrhc_threshold_r(0);
                when x"11"  => read_data(10) <= zrhc_threshold_r(1);
                when x"12"  => read_data(10) <= zrhc_threshold_r(2);
                when x"13"  => read_data(10) <= zrhc_threshold_r(3);
                when x"14"  => read_data(10) <= zrhc_threshold_r(4);
                when x"15"  => read_data(10) <= zrhc_threshold_r(5);
                when x"16"  => read_data(10) <= zrhc_threshold_r(6);
                when x"17"  => read_data(10) <= zrhc_threshold_r(7);
                when others => read_data(10) <= (others => '0');
                end case;
            end if;
        end if;
    end process;

    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (oe_buf_sysx8(2 downto 1) = "01") then
                case addr_lsb is
                when x"00"  => read_data(11) <= sync_delay_value_r_mask(0);
                when x"01"  => read_data(11) <= sync_delay_value_r_mask(1);
                when x"02"  => read_data(11) <= sync_delay_value_r_mask(2);
                when x"03"  => read_data(11) <= sync_delay_value_r_mask(3);
                when x"04"  => read_data(11) <= sync_delay_value_r_mask(4);
                when x"05"  => read_data(11) <= sync_delay_value_r_mask(5);
                when x"06"  => read_data(11) <= sync_delay_value_r_mask(6);
                when x"07"  => read_data(11) <= sync_delay_value_r_mask(7);
                when x"40"  => read_data(11) <= test_mode_r;
                when x"41"  => read_data(11) <= tp_1ms_en;
		        when x"42"  => read_data(11) <= tp_mem_rwctrl_r;
		        when x"43"  => read_data(11) <= tp_mem_wraddr_r;
		        when x"44"  => read_data(11) <= tp_mem_wrdata_r;
--                when x"45"  => read_data(11) <= DL_10MS_CNT;
--                when x"46"  => read_data(11) <= DL_SYNC_CNT;
--                when x"47"  => read_data(11) <= x"0000" & DL_DATA;
                when x"60"  => read_data(11) <= test_dc_data_r;
                when x"61"  => read_data(11) <= test_nco_r;
                when others => read_data(11) <= (others => '0');
                end case;
            end if;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Register mapping
--------------------------------------------------------------------------------

    dbg_sync_cnt_w          <= X"0000_0" & '0' & DBG_SYNC_CNT;  --edited by ssm
    dbg_sync_chk_w          <= X"0000_0" & '0' & DBG_SYNC_CHK; 

    TSSI_UPDATE_MODE <= tssi_update_mode_r(1 downto 0);
    RSSI_UPDATE_MODE <= rssi_update_mode_r(1 downto 0);

    DUMP_EN  <= test_ctrl0_r(8);
    DUMP_SEL <= test_ctrl0_r(15 downto 0);

    TEST_DC_I <= test_dc_data_r(15 downto 0);
    TEST_DC_Q <= test_dc_data_r(31 downto 16);
    TEST_NCO  <= test_nco_r(5 downto 0);

    u_CPRI_GEN : for i in NUM_CPRI-1 downto 0 generate
    dl_cpri_if_delay_w(i) <= DL_CPRI_IF_DELAY(i);
    ul_cpri_if_delay_w(i) <= UL_CPRI_IF_DELAY(i);
    end generate;

    u_MAP_GEN : for i in NUM_MAP-1 downto 0 generate
--    process (map_cpri_r, dl_cpri_if_delay_w, DL_CPRI_SWITCH_DELAY, dl_mapper_delay_w, DL_MAP_SWITCH_DELAY, dl_formatter_delay_w)
--    begin
--        case map_cpri_r(i) is
--        when x"00000000" => dl_proc_dly_w(i) <= x"08" & (dl_cpri_if_delay_w(0) + DL_CPRI_SWITCH_DELAY + dl_mapper_delay_w(i) + DL_MAP_SWITCH_DELAY + dl_formatter_delay_w(i));
--                            ul_proc_dly_w(i) <= x"08" & (ul_cpri_if_delay_w(0) + UL_CPRI_SWITCH_DELAY + ul_mapper_delay_w(i) + UL_MAP_SWITCH_DELAY + ul_formatter_delay_w(i));
--        when x"00000001" => dl_proc_dly_w(i) <= x"08" & (dl_cpri_if_delay_w(1) + DL_CPRI_SWITCH_DELAY + dl_mapper_delay_w(i) + DL_MAP_SWITCH_DELAY + dl_formatter_delay_w(i));
--                            ul_proc_dly_w(i) <= x"08" & (ul_cpri_if_delay_w(1) + UL_CPRI_SWITCH_DELAY + ul_mapper_delay_w(i) + UL_MAP_SWITCH_DELAY + ul_formatter_delay_w(i));
--        when x"00000002" => dl_proc_dly_w(i) <= x"08" & (dl_cpri_if_delay_w(2) + DL_CPRI_SWITCH_DELAY + dl_mapper_delay_w(i) + DL_MAP_SWITCH_DELAY + dl_formatter_delay_w(i));
--                            ul_proc_dly_w(i) <= x"08" & (ul_cpri_if_delay_w(2) + UL_CPRI_SWITCH_DELAY + ul_mapper_delay_w(i) + UL_MAP_SWITCH_DELAY + ul_formatter_delay_w(i));
--        when x"00000003" => dl_proc_dly_w(i) <= x"08" & (dl_cpri_if_delay_w(3) + DL_CPRI_SWITCH_DELAY + dl_mapper_delay_w(i) + DL_MAP_SWITCH_DELAY + dl_formatter_delay_w(i));
--                            ul_proc_dly_w(i) <= x"08" & (ul_cpri_if_delay_w(3) + UL_CPRI_SWITCH_DELAY + ul_mapper_delay_w(i) + UL_MAP_SWITCH_DELAY + ul_formatter_delay_w(i));
--        when x"00000004" => dl_proc_dly_w(i) <= x"08" & (dl_cpri_if_delay_w(4) + DL_CPRI_SWITCH_DELAY + dl_mapper_delay_w(i) + DL_MAP_SWITCH_DELAY + dl_formatter_delay_w(i));
--                            ul_proc_dly_w(i) <= x"08" & (ul_cpri_if_delay_w(4) + UL_CPRI_SWITCH_DELAY + ul_mapper_delay_w(i) + UL_MAP_SWITCH_DELAY + ul_formatter_delay_w(i));
--        when x"00000005" => dl_proc_dly_w(i) <= x"08" & (dl_cpri_if_delay_w(5) + DL_CPRI_SWITCH_DELAY + dl_mapper_delay_w(i) + DL_MAP_SWITCH_DELAY + dl_formatter_delay_w(i));
--                            ul_proc_dly_w(i) <= x"08" & (ul_cpri_if_delay_w(5) + UL_CPRI_SWITCH_DELAY + ul_mapper_delay_w(i) + UL_MAP_SWITCH_DELAY + ul_formatter_delay_w(i));
--        when x"00000006" => dl_proc_dly_w(i) <= x"08" & (dl_cpri_if_delay_w(6) + DL_CPRI_SWITCH_DELAY + dl_mapper_delay_w(i) + DL_MAP_SWITCH_DELAY + dl_formatter_delay_w(i));
--                            ul_proc_dly_w(i) <= x"08" & (ul_cpri_if_delay_w(6) + UL_CPRI_SWITCH_DELAY + ul_mapper_delay_w(i) + UL_MAP_SWITCH_DELAY + ul_formatter_delay_w(i));
--        when x"00000007" => dl_proc_dly_w(i) <= x"08" & (dl_cpri_if_delay_w(7) + DL_CPRI_SWITCH_DELAY + dl_mapper_delay_w(i) + DL_MAP_SWITCH_DELAY + dl_formatter_delay_w(i));
--                            ul_proc_dly_w(i) <= x"08" & (ul_cpri_if_delay_w(7) + UL_CPRI_SWITCH_DELAY + ul_mapper_delay_w(i) + UL_MAP_SWITCH_DELAY + ul_formatter_delay_w(i));
--        when others      => dl_proc_dly_w(i) <= (others => '0');
--                            ul_proc_dly_w(i) <= (others => '0');
--        end case;
--    end process;

    dl_mapper_delay_w(i) <= DL_MAPPER_DELAY(i);
    ul_mapper_delay_w(i) <= UL_MAPPER_DELAY(i);
    MAP_CPRI(i)          <= map_cpri_r(i)(7 downto 0);
    MAPPER_UL_MAP(i)     <= mapper_ul_map_r(i)(15 downto 0);
    end generate;

    u_FMT_GEN : for i in NUM_FMT-1 downto 0 generate

    dl_proc_dly_w(i) <= x"08" & (dl_map_if_delay_w(i) + dl_formatter_delay_w(i));
    ul_proc_dly_w(i) <= x"08" & (ul_map_if_delay_w(i) + ul_formatter_delay_w(i));

    dl_map_if_delay_w(i)    <= DL_MAP_IF_DELAY(i);
    ul_map_if_delay_w(i)    <= UL_MAP_IF_DELAY(i);
    dl_formatter_delay_w(i) <= DL_FORMATTER_DELAY(i);
    ul_formatter_delay_w(i) <= UL_FORMATTER_DELAY(i);
    BW_SEL(i)               <= bw_sel_r(i*4+3 downto i*4);
    dl_map_rd_data_w(i)     <= DL_MAP_RD_DATA(i);
    ul_map_rd_data_w(i)     <= UL_MAP_RD_DATA(i);
    FORMATTER_DL_MAP(i)     <= formatter_dl_map_r(i)(15 downto 0);
    SYNC_DELAY_VALUE(i)     <= sync_delay_value_r_mask(i);
    DL_DELAY_VALUE(i)       <= dl_delay_value_r(i);
    UL_DELAY_VALUE(i)       <= ul_delay_value_r(i);
    ZRHC_BYPASS(i)          <= zrhc_bypass_r(i);
    ZRHC_THRESHOLD(i)       <= zrhc_threshold_r(i);
    DL_ON(i)                <= dl_on_r(i*4+3 downto i*4);
    UL_ON(i)                <= ul_on_r(i*4+3 downto i*4);
    DL_ATT_0(i)             <= dl_att_0_r(i)(15 downto 0);
    DL_ATT_1(i)             <= dl_att_1_r(i)(15 downto 0);
    DL_ATT_2(i)             <= dl_att_2_r(i)(15 downto 0);
    DL_ATT_3(i)             <= dl_att_3_r(i)(15 downto 0);
    UL_ATT_0(i)             <= ul_att_0_r(i)(15 downto 0);
    UL_ATT_1(i)             <= ul_att_1_r(i)(15 downto 0);
    UL_ATT_2(i)             <= ul_att_2_r(i)(15 downto 0);
    UL_ATT_3(i)             <= ul_att_3_r(i)(15 downto 0);
    TSSI_UPDATE_CNT_0(i)    <= tssi_update_cnt_r(i)(4 downto 0);
    TSSI_UPDATE_CNT_1(i)    <= tssi_update_cnt_r(i)(12 downto 8);
    TSSI_UPDATE_CNT_2(i)    <= tssi_update_cnt_r(i)(20 downto 16);
    TSSI_UPDATE_CNT_3(i)    <= tssi_update_cnt_r(i)(28 downto 24);
    RSSI_UPDATE_CNT_0(i)    <= rssi_update_cnt_r(i)(4 downto 0);
    RSSI_UPDATE_CNT_1(i)    <= rssi_update_cnt_r(i)(12 downto 8);
    RSSI_UPDATE_CNT_2(i)    <= rssi_update_cnt_r(i)(20 downto 16);
    RSSI_UPDATE_CNT_3(i)    <= rssi_update_cnt_r(i)(28 downto 24);
    tssi_0_w(i)             <= TSSI_0(i);
    tssi_1_w(i)             <= TSSI_1(i);
    tssi_2_w(i)             <= TSSI_2(i);
    tssi_3_w(i)             <= TSSI_3(i);
    rssi_0_w(i)             <= RSSI_0(i);
    rssi_1_w(i)             <= RSSI_1(i);
    rssi_2_w(i)             <= RSSI_2(i);
    rssi_3_w(i)             <= RSSI_3(i);
    TEST_MODE(i)            <= test_mode_r(i*4+3 downto i*4);

    TP_EN                   <= tp_1ms_en(0);
    TP_MEM_PEN              <= tp_mem_rwctrl_r(0);
    TP_MEM_AWEN             <= tp_mem_rwctrl_r(4);
    TP_MEM_WRADDR           <= tp_mem_wraddr_r(14 downto 0);
    TP_MEM_WRDATA           <= tp_mem_wrdata_r;
    --DL_DATA_SEL             <= dl_data_sel_r(1 downto 0);

    -- sync delay max value masking
    process (CLK_AUX)
    begin
        if (CLK_AUX'event and CLK_AUX = '1') then
            if (sync_delay_value_r(i) >= 2457527) then
                sync_delay_value_r_mask(i) <= conv_std_logic_vector(2457527, 32);
            else
                sync_delay_value_r_mask(i) <= sync_delay_value_r(i);
            end if;
        end if;
    end process;

    end generate;

    process (CLK_AUX)
    begin
        if (CLK_AUX'event and CLK_AUX = '1') then
            DL_MAP_WR_ADDR <= map_wr_addr_r(4 downto 0);
            DL_MAP_WR_DATA <= map_wr_data_r(6 downto 0);
            UL_MAP_WR_ADDR <= map_wr_addr_r(21 downto 16);
            UL_MAP_WR_DATA <= map_wr_data_r(22 downto 16);
        end if;
    end process;

    process (CLK_AUX)
    begin
        if (CLK_AUX'event and CLK_AUX = '1') then
            map_dl_ctrl <= map_dl_ctrl(0) & map_ctrl_r(0);
            map_ul_ctrl <= map_ul_ctrl(0) & map_ctrl_r(1);
            if (map_dl_ctrl = "01") then
                for i in NUM_MAP-1 downto 0 loop
                if (map_buf_sel_r(7 downto 0) = i) then
                    DL_MAP_WR_EN(i) <= '1';
                else
                    DL_MAP_WR_EN(i) <= '0';
                end if;
                end loop; 
            else
                DL_MAP_WR_EN <= (others => '0');
            end if;
            if (map_ul_ctrl = "01") then
                for i in NUM_MAP-1 downto 0 loop
                if (map_buf_sel_r(7 downto 0) = i) then
                    UL_MAP_WR_EN(i) <= '1';
                else
                    UL_MAP_WR_EN(i) <= '0';
                end if;
                end loop; 
            else
                UL_MAP_WR_EN <= (others => '0');
            end if;
        end if;
    end process;

    process (CLK_AUX)
    begin
        if (CLK_AUX'event and CLK_AUX = '1') then
            case map_buf_sel_r(7 downto 0) is
            when x"00"  =>
                map_dl_rd_data_r <= '0' & dl_map_rd_data_w(0);
                map_ul_rd_data_r <= '0' & ul_map_rd_data_w(0);
            when x"01"  =>
                map_dl_rd_data_r <= '0' & dl_map_rd_data_w(1);
                map_ul_rd_data_r <= '0' & ul_map_rd_data_w(1);
            when x"02"  =>
                map_dl_rd_data_r <= '0' & dl_map_rd_data_w(2);
                map_ul_rd_data_r <= '0' & ul_map_rd_data_w(2);
            when x"03"  =>
                map_dl_rd_data_r <= '0' & dl_map_rd_data_w(3);
                map_ul_rd_data_r <= '0' & ul_map_rd_data_w(3);
            when x"04"  =>
                map_dl_rd_data_r <= '0' & dl_map_rd_data_w(4);
                map_ul_rd_data_r <= '0' & ul_map_rd_data_w(4);
            when x"05"  =>
                map_dl_rd_data_r <= '0' & dl_map_rd_data_w(5);
                map_ul_rd_data_r <= '0' & ul_map_rd_data_w(5);
            when x"06"  =>
                map_dl_rd_data_r <= '0' & dl_map_rd_data_w(6);
                map_ul_rd_data_r <= '0' & ul_map_rd_data_w(6);
            when x"07"  =>
                map_dl_rd_data_r <= '0' & dl_map_rd_data_w(7);
                map_ul_rd_data_r <= '0' & ul_map_rd_data_w(7);
            when others =>
                map_dl_rd_data_r <= (others => '0');
                map_ul_rd_data_r <= (others => '0');
            end case;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Write register
--------------------------------------------------------------------------------

    U_0x00C : COMP_WRITE generic map(x"FFFFFFFF", x"0C", x"00000000") port map(RESET,       CLK_AUX,   we(0),        addr_lsb, WDATA_CPUIF_IN, test_ctrl0_r );
    U_0x00D : COMP_WRITE generic map(x"FFFFFFFF", x"0D", x"00000000") port map(RESET,       CLK_AUX,   we(0),        addr_lsb, WDATA_CPUIF_IN, test_ctrl1_r );

    u_0x100 : COMP_WRITE generic map(x"0000FFFF", x"00", x"00000000") port map(RESET,       CLK_AUX,   we(1),        addr_lsb, WDATA_CPUIF_IN, bw_sel_r );

    u_0x200 : COMP_WRITE generic map(x"FFFFFFFF", x"00", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, dl_delay_value_r(0) );
    u_0x201 : COMP_WRITE generic map(x"FFFFFFFF", x"01", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, dl_delay_value_r(1) );
    u_0x202 : COMP_WRITE generic map(x"FFFFFFFF", x"02", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, dl_delay_value_r(2) );
    u_0x203 : COMP_WRITE generic map(x"FFFFFFFF", x"03", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, dl_delay_value_r(3) );
--    u_0x204 : COMP_WRITE generic map(x"FFFFFFFF", x"04", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, dl_delay_value_r(4) );
--    u_0x205 : COMP_WRITE generic map(x"FFFFFFFF", x"05", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, dl_delay_value_r(5) );
--    u_0x206 : COMP_WRITE generic map(x"FFFFFFFF", x"06", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, dl_delay_value_r(6) );
--    u_0x207 : COMP_WRITE generic map(x"FFFFFFFF", x"07", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, dl_delay_value_r(7) );
    u_0x280 : COMP_WRITE generic map(x"FFFFFFFF", x"80", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, ul_delay_value_r(0) );
    u_0x281 : COMP_WRITE generic map(x"FFFFFFFF", x"81", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, ul_delay_value_r(1) );
    u_0x282 : COMP_WRITE generic map(x"FFFFFFFF", x"82", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, ul_delay_value_r(2) );
    u_0x283 : COMP_WRITE generic map(x"FFFFFFFF", x"83", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, ul_delay_value_r(3) );
--    u_0x284 : COMP_WRITE generic map(x"FFFFFFFF", x"84", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, ul_delay_value_r(4) );
--    u_0x285 : COMP_WRITE generic map(x"FFFFFFFF", x"85", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, ul_delay_value_r(5) );
--    u_0x286 : COMP_WRITE generic map(x"FFFFFFFF", x"86", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, ul_delay_value_r(6) );
--    u_0x287 : COMP_WRITE generic map(x"FFFFFFFF", x"87", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(2),  addr_lsb, WDATA_CPUIF_IN, ul_delay_value_r(7) );

    u_0x300 : COMP_WRITE generic map(x"0000FFFF", x"00", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(3),  addr_lsb, WDATA_CPUIF_IN, dl_on_r );
    u_0x310 : COMP_WRITE generic map(x"0000FFFF", x"10", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(3),  addr_lsb, WDATA_CPUIF_IN, ul_on_r );

    u_0x440 : COMP_WRITE generic map(x"0000000F", x"40", x"00000001") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, tssi_update_mode_r );
    u_0x460 : COMP_WRITE generic map(x"1F1F1F1F", x"60", x"16061606") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, tssi_update_cnt_r(0) );
    u_0x461 : COMP_WRITE generic map(x"1F1F1F1F", x"61", x"16061606") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, tssi_update_cnt_r(1) );
    u_0x462 : COMP_WRITE generic map(x"1F1F1F1F", x"62", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, tssi_update_cnt_r(2) );
    u_0x463 : COMP_WRITE generic map(x"1F1F1F1F", x"63", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, tssi_update_cnt_r(3) );
--    u_0x464 : COMP_WRITE generic map(x"1F1F1F1F", x"64", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, tssi_update_cnt_r(4) );
--    u_0x465 : COMP_WRITE generic map(x"1F1F1F1F", x"65", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, tssi_update_cnt_r(5) );
--    u_0x466 : COMP_WRITE generic map(x"1F1F1F1F", x"66", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, tssi_update_cnt_r(6) );
--    u_0x467 : COMP_WRITE generic map(x"1F1F1F1F", x"67", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, tssi_update_cnt_r(7) );
    u_0x4C0 : COMP_WRITE generic map(x"0000000F", x"C0", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, rssi_update_mode_r );
    u_0x4E0 : COMP_WRITE generic map(x"1F1F1F1F", x"E0", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, rssi_update_cnt_r(0) );
    u_0x4E1 : COMP_WRITE generic map(x"1F1F1F1F", x"E1", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, rssi_update_cnt_r(1) );
    u_0x4E2 : COMP_WRITE generic map(x"1F1F1F1F", x"E2", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, rssi_update_cnt_r(2) );
    u_0x4E3 : COMP_WRITE generic map(x"1F1F1F1F", x"E3", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, rssi_update_cnt_r(3) );
--    u_0x4E4 : COMP_WRITE generic map(x"1F1F1F1F", x"E4", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, rssi_update_cnt_r(4) );
--    u_0x4E5 : COMP_WRITE generic map(x"1F1F1F1F", x"E5", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, rssi_update_cnt_r(5) );
--    u_0x4E6 : COMP_WRITE generic map(x"1F1F1F1F", x"E6", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, rssi_update_cnt_r(6) );
--    u_0x4E7 : COMP_WRITE generic map(x"1F1F1F1F", x"E7", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(4),  addr_lsb, WDATA_CPUIF_IN, rssi_update_cnt_r(7) );

    u_0x500 : COMP_WRITE generic map(x"0000FFFF", x"00", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_0_r(0) );
    u_0x501 : COMP_WRITE generic map(x"0000FFFF", x"01", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_1_r(0) );
    u_0x502 : COMP_WRITE generic map(x"0000FFFF", x"02", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_2_r(0) );
    u_0x503 : COMP_WRITE generic map(x"0000FFFF", x"03", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_3_r(0) );
    u_0x504 : COMP_WRITE generic map(x"0000FFFF", x"04", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_0_r(1) );
    u_0x505 : COMP_WRITE generic map(x"0000FFFF", x"05", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_1_r(1) );
    u_0x506 : COMP_WRITE generic map(x"0000FFFF", x"06", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_2_r(1) );
    u_0x507 : COMP_WRITE generic map(x"0000FFFF", x"07", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_3_r(1) );
    u_0x508 : COMP_WRITE generic map(x"0000FFFF", x"08", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_0_r(2) );
    u_0x509 : COMP_WRITE generic map(x"0000FFFF", x"09", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_1_r(2) );
    u_0x50A : COMP_WRITE generic map(x"0000FFFF", x"0A", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_2_r(2) );
    u_0x50B : COMP_WRITE generic map(x"0000FFFF", x"0B", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_3_r(2) );
    u_0x50C : COMP_WRITE generic map(x"0000FFFF", x"0C", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_0_r(3) );
    u_0x50D : COMP_WRITE generic map(x"0000FFFF", x"0D", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_1_r(3) );
    u_0x50E : COMP_WRITE generic map(x"0000FFFF", x"0E", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_2_r(3) );
    u_0x50F : COMP_WRITE generic map(x"0000FFFF", x"0F", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_3_r(3) );
--    u_0x510 : COMP_WRITE generic map(x"0000FFFF", x"10", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_0_r(4) );
--    u_0x511 : COMP_WRITE generic map(x"0000FFFF", x"11", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_1_r(4) );
--    u_0x512 : COMP_WRITE generic map(x"0000FFFF", x"12", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_2_r(4) );
--    u_0x513 : COMP_WRITE generic map(x"0000FFFF", x"13", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_3_r(4) );
--    u_0x514 : COMP_WRITE generic map(x"0000FFFF", x"14", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_0_r(5) );
--    u_0x515 : COMP_WRITE generic map(x"0000FFFF", x"15", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_1_r(5) );
--    u_0x516 : COMP_WRITE generic map(x"0000FFFF", x"16", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_2_r(5) );
--    u_0x517 : COMP_WRITE generic map(x"0000FFFF", x"17", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_3_r(5) );
--    u_0x518 : COMP_WRITE generic map(x"0000FFFF", x"18", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_0_r(6) );
--    u_0x519 : COMP_WRITE generic map(x"0000FFFF", x"19", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_1_r(6) );
--    u_0x51A : COMP_WRITE generic map(x"0000FFFF", x"1A", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_2_r(6) );
--    u_0x51B : COMP_WRITE generic map(x"0000FFFF", x"1B", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_3_r(6) );
--    u_0x51C : COMP_WRITE generic map(x"0000FFFF", x"1C", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_0_r(7) );
--    u_0x51D : COMP_WRITE generic map(x"0000FFFF", x"1D", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_1_r(7) );
--    u_0x51E : COMP_WRITE generic map(x"0000FFFF", x"1E", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_2_r(7) );
--    u_0x51F : COMP_WRITE generic map(x"0000FFFF", x"1F", x"00008000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, dl_att_3_r(7) );

    u_0x580 : COMP_WRITE generic map(x"0000FFFF", x"80", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_0_r(0) );
    u_0x581 : COMP_WRITE generic map(x"0000FFFF", x"81", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_1_r(0) );
    u_0x582 : COMP_WRITE generic map(x"0000FFFF", x"82", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_2_r(0) );
    u_0x583 : COMP_WRITE generic map(x"0000FFFF", x"83", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_3_r(0) );
    u_0x584 : COMP_WRITE generic map(x"0000FFFF", x"84", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_0_r(1) );
    u_0x585 : COMP_WRITE generic map(x"0000FFFF", x"85", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_1_r(1) );
    u_0x586 : COMP_WRITE generic map(x"0000FFFF", x"86", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_2_r(1) );
    u_0x587 : COMP_WRITE generic map(x"0000FFFF", x"87", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_3_r(1) );
    u_0x588 : COMP_WRITE generic map(x"0000FFFF", x"88", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_0_r(2) );
    u_0x589 : COMP_WRITE generic map(x"0000FFFF", x"89", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_1_r(2) );
    u_0x58A : COMP_WRITE generic map(x"0000FFFF", x"8A", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_2_r(2) );
    u_0x58B : COMP_WRITE generic map(x"0000FFFF", x"8B", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_3_r(2) );
    u_0x58C : COMP_WRITE generic map(x"0000FFFF", x"8C", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_0_r(3) );
    u_0x58D : COMP_WRITE generic map(x"0000FFFF", x"8D", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_1_r(3) );
    u_0x58E : COMP_WRITE generic map(x"0000FFFF", x"8E", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_2_r(3) );
    u_0x58F : COMP_WRITE generic map(x"0000FFFF", x"8F", x"00000400") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_3_r(3) );
--    u_0x590 : COMP_WRITE generic map(x"0000FFFF", x"90", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_0_r(4) );
--    u_0x591 : COMP_WRITE generic map(x"0000FFFF", x"91", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_1_r(4) );
--    u_0x592 : COMP_WRITE generic map(x"0000FFFF", x"92", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_2_r(4) );
--    u_0x593 : COMP_WRITE generic map(x"0000FFFF", x"93", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_3_r(4) );
--    u_0x594 : COMP_WRITE generic map(x"0000FFFF", x"94", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_0_r(5) );
--    u_0x595 : COMP_WRITE generic map(x"0000FFFF", x"95", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_1_r(5) );
--    u_0x596 : COMP_WRITE generic map(x"0000FFFF", x"96", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_2_r(5) );
--    u_0x597 : COMP_WRITE generic map(x"0000FFFF", x"97", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_3_r(5) );
--    u_0x598 : COMP_WRITE generic map(x"0000FFFF", x"98", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_0_r(6) );
--    u_0x599 : COMP_WRITE generic map(x"0000FFFF", x"99", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_1_r(6) );
--    u_0x59A : COMP_WRITE generic map(x"0000FFFF", x"9A", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_2_r(6) );
--    u_0x59B : COMP_WRITE generic map(x"0000FFFF", x"9B", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_3_r(6) );
--    u_0x59C : COMP_WRITE generic map(x"0000FFFF", x"9C", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_0_r(7) );
--    u_0x59D : COMP_WRITE generic map(x"0000FFFF", x"9D", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_1_r(7) );
--    u_0x59E : COMP_WRITE generic map(x"0000FFFF", x"9E", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_2_r(7) );
--    u_0x59F : COMP_WRITE generic map(x"0000FFFF", x"9F", x"00001000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(5),  addr_lsb, WDATA_CPUIF_IN, ul_att_3_r(7) );

--    u_0x800 : COMP_WRITE generic map(x"000000FF", x"00", x"00000000") port map(RESET,       CLK_AUX,   we(8),        addr_lsb, WDATA_CPUIF_IN, map_buf_sel_r );
--    u_0x801 : COMP_WRITE generic map(x"003F001F", x"01", x"00000000") port map(RESET,       CLK_AUX,   we(8),        addr_lsb, WDATA_CPUIF_IN, map_wr_addr_r );
--    u_0x802 : COMP_WRITE generic map(x"007F007F", x"02", x"00000000") port map(RESET,       CLK_AUX,   we(8),        addr_lsb, WDATA_CPUIF_IN, map_wr_data_r );
--    u_0x803 : COMP_WRITE generic map(x"00000003", x"03", x"00000000") port map(RESET,       CLK_AUX,   we(8),        addr_lsb, WDATA_CPUIF_IN, map_ctrl_r );
--    u_0x880 : COMP_WRITE generic map(x"000000FF", x"80", x"00000000") port map(RESET,       CLK_AUX,   we(8),        addr_lsb, WDATA_CPUIF_IN, map_cpri_r(0) );
--    u_0x881 : COMP_WRITE generic map(x"000000FF", x"81", x"00000000") port map(RESET,       CLK_AUX,   we(8),        addr_lsb, WDATA_CPUIF_IN, map_cpri_r(1) );
--    u_0x882 : COMP_WRITE generic map(x"000000FF", x"82", x"00000000") port map(RESET,       CLK_AUX,   we(8),        addr_lsb, WDATA_CPUIF_IN, map_cpri_r(2) );
--    u_0x883 : COMP_WRITE generic map(x"000000FF", x"83", x"00000000") port map(RESET,       CLK_AUX,   we(8),        addr_lsb, WDATA_CPUIF_IN, map_cpri_r(3) );
--    u_0x884 : COMP_WRITE generic map(x"000000FF", x"84", x"00000000") port map(RESET,       CLK_AUX,   we(8),        addr_lsb, WDATA_CPUIF_IN, map_cpri_r(4) );
--    u_0x885 : COMP_WRITE generic map(x"000000FF", x"85", x"00000000") port map(RESET,       CLK_AUX,   we(8),        addr_lsb, WDATA_CPUIF_IN, map_cpri_r(5) );
--    u_0x886 : COMP_WRITE generic map(x"000000FF", x"86", x"00000000") port map(RESET,       CLK_AUX,   we(8),        addr_lsb, WDATA_CPUIF_IN, map_cpri_r(6) );
--    u_0x887 : COMP_WRITE generic map(x"000000FF", x"87", x"00000000") port map(RESET,       CLK_AUX,   we(8),        addr_lsb, WDATA_CPUIF_IN, map_cpri_r(7) );

--    u_0x900 : COMP_WRITE generic map(x"0000FFFF", x"00", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, mapper_ul_map_r(0) );
--    u_0x901 : COMP_WRITE generic map(x"0000FFFF", x"01", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, mapper_ul_map_r(1) );
--    u_0x902 : COMP_WRITE generic map(x"0000FFFF", x"02", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, mapper_ul_map_r(2) );
--    u_0x903 : COMP_WRITE generic map(x"0000FFFF", x"03", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, mapper_ul_map_r(3) );
--    u_0x904 : COMP_WRITE generic map(x"0000FFFF", x"04", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, mapper_ul_map_r(4) );
--    u_0x905 : COMP_WRITE generic map(x"0000FFFF", x"05", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, mapper_ul_map_r(5) );
--    u_0x906 : COMP_WRITE generic map(x"0000FFFF", x"06", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, mapper_ul_map_r(6) );
--    u_0x907 : COMP_WRITE generic map(x"0000FFFF", x"07", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, mapper_ul_map_r(7) );
--    u_0x980 : COMP_WRITE generic map(x"0000FFFF", x"80", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, formatter_dl_map_r(0) );
--    u_0x981 : COMP_WRITE generic map(x"0000FFFF", x"81", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, formatter_dl_map_r(1) );
--    u_0x982 : COMP_WRITE generic map(x"0000FFFF", x"82", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, formatter_dl_map_r(2) );
--    u_0x983 : COMP_WRITE generic map(x"0000FFFF", x"83", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, formatter_dl_map_r(3) );
--    u_0x984 : COMP_WRITE generic map(x"0000FFFF", x"84", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, formatter_dl_map_r(4) );
--    u_0x985 : COMP_WRITE generic map(x"0000FFFF", x"85", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, formatter_dl_map_r(5) );
--    u_0x986 : COMP_WRITE generic map(x"0000FFFF", x"86", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, formatter_dl_map_r(6) );
--    u_0x987 : COMP_WRITE generic map(x"0000FFFF", x"87", x"00000000") port map(RESET,       CLK_AUX,   we(9),        addr_lsb, WDATA_CPUIF_IN, formatter_dl_map_r(7) );

    u_0xA00 : COMP_WRITE generic map(x"0000000F", x"00", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(10), addr_lsb, WDATA_CPUIF_IN, zrhc_bypass_r );
    u_0xA10 : COMP_WRITE generic map(x"FFFFFFFF", x"10", x"FFFFFFFF") port map(reset_sysx8, CLK_SYSX8, we_sysx8(10), addr_lsb, WDATA_CPUIF_IN, zrhc_threshold_r(0) );
    u_0xA11 : COMP_WRITE generic map(x"FFFFFFFF", x"11", x"FFFFFFFF") port map(reset_sysx8, CLK_SYSX8, we_sysx8(10), addr_lsb, WDATA_CPUIF_IN, zrhc_threshold_r(1) );
    u_0xA12 : COMP_WRITE generic map(x"FFFFFFFF", x"12", x"FFFFFFFF") port map(reset_sysx8, CLK_SYSX8, we_sysx8(10), addr_lsb, WDATA_CPUIF_IN, zrhc_threshold_r(2) );
    u_0xA13 : COMP_WRITE generic map(x"FFFFFFFF", x"13", x"FFFFFFFF") port map(reset_sysx8, CLK_SYSX8, we_sysx8(10), addr_lsb, WDATA_CPUIF_IN, zrhc_threshold_r(3) );
--    u_0xA14 : COMP_WRITE generic map(x"FFFFFFFF", x"14", x"FFFFFFFF") port map(reset_sysx8, CLK_SYSX8, we_sysx8(10), addr_lsb, WDATA_CPUIF_IN, zrhc_threshold_r(4) );
--    u_0xA15 : COMP_WRITE generic map(x"FFFFFFFF", x"15", x"FFFFFFFF") port map(reset_sysx8, CLK_SYSX8, we_sysx8(10), addr_lsb, WDATA_CPUIF_IN, zrhc_threshold_r(5) );
--    u_0xA16 : COMP_WRITE generic map(x"FFFFFFFF", x"16", x"FFFFFFFF") port map(reset_sysx8, CLK_SYSX8, we_sysx8(10), addr_lsb, WDATA_CPUIF_IN, zrhc_threshold_r(6) );
--    u_0xA17 : COMP_WRITE generic map(x"FFFFFFFF", x"17", x"FFFFFFFF") port map(reset_sysx8, CLK_SYSX8, we_sysx8(10), addr_lsb, WDATA_CPUIF_IN, zrhc_threshold_r(7) );

    u_0xB00 : COMP_WRITE generic map(x"FFFFFFFF", x"00", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, sync_delay_value_r(0));
    u_0xB01 : COMP_WRITE generic map(x"FFFFFFFF", x"01", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, sync_delay_value_r(1));
    u_0xB02 : COMP_WRITE generic map(x"FFFFFFFF", x"02", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, sync_delay_value_r(2));
    u_0xB03 : COMP_WRITE generic map(x"FFFFFFFF", x"03", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, sync_delay_value_r(3));
--    u_0xB04 : COMP_WRITE generic map(x"FFFFFFFF", x"04", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, sync_delay_value_r(4));
--    u_0xB05 : COMP_WRITE generic map(x"FFFFFFFF", x"05", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, sync_delay_value_r(5));
--    u_0xB06 : COMP_WRITE generic map(x"FFFFFFFF", x"06", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, sync_delay_value_r(6));
--    u_0xB07 : COMP_WRITE generic map(x"FFFFFFFF", x"07", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, sync_delay_value_r(7));
    u_0xB40 : COMP_WRITE generic map(x"0000FFFF", x"40", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, test_mode_r );
    u_0xB41 : COMP_WRITE generic map(x"0000FFFF", x"41", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, tp_1ms_en );
    u_0xB42 : COMP_WRITE generic map(x"0000FFFF", x"42", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, tp_mem_rwctrl_r );
    u_0xB43 : COMP_WRITE generic map(x"0000FFFF", x"43", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, tp_mem_wraddr_r );
    u_0xB44 : COMP_WRITE generic map(x"FFFFFFFF", x"44", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, tp_mem_wrdata_r );
    u_0xB48 : COMP_WRITE generic map(x"FFFFFFFF", x"48", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, dl_data_sel_r );
    u_0xB60 : COMP_WRITE generic map(x"FFFFFFFF", x"60", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, test_dc_data_r );
    u_0xB61 : COMP_WRITE generic map(x"0000003F", x"61", x"00000000") port map(reset_sysx8, CLK_SYSX8, we_sysx8(11), addr_lsb, WDATA_CPUIF_IN, test_nco_r );

end BEHAVE;
