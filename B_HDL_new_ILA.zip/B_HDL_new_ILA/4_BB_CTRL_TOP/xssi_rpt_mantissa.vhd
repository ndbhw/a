--=================================================================================================
-- Designer            : seulkee.kim
-- Initial Coding Date : 
-- Revision Date       : 
-- Modification Date   : 
-- Description         : FDD LTE XSSI in 10ms, 2 C.C(Carrier Cell) = DDUC 1 unit
--=================================================================================================

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

use WORK.ARRAY_TYPE.ALL;

Library UNISIM;
use UNISIM.vcomponents.all;
library UNIMACRO;
use unimacro.Vcomponents.all;


entity XSSI_RPT_MANTISSA is
port(
    RESET                              : in  std_logic;
    CLK                                : in  std_logic; -- 245.76MHz
    
    -- input data
    RX_10M_FS                          : in  std_logic; -- CPRI BFN RX Strobe
    TDD_IN                             : in  std_logic; -- TDD signal
    D_IN_SYNC                          : in  std_logic; -- chip sync
    D_IN                               : in  std_logic_vector(15 downto 0);
    
    MEASURE_DONE                       : out std_logic;
    XSSI_0                             : out std_logic_vector(31 downto 0);
    XSSI_1                             : out std_logic_vector(31 downto 0);
    XSSI_2                             : out std_logic_vector(31 downto 0);
    XSSI_3                             : out std_logic_vector(31 downto 0)
);
end XSSI_RPT_MANTISSA;

architecture ARC_XSSI_RPT_MANTISSA of XSSI_RPT_MANTISSA is

    component MANTISSA_FRAMER is
    port(
    RST          : in  std_logic;
    CLK          : in  std_logic;

    START_IN     : in  std_logic;
    DATA_IN      : in  std_logic_vector(63 downto 0);
    
    DONE_OUT     : out std_logic;
    MANTISSA_OUT : out std_logic_vector(31 downto 0)
    );
    end component;

    signal d_in_sync_sh                : std_logic := '0';

    signal rx_10m_fs_d                 : std_logic_vector(2 downto 0);
    signal fs_10m_cnt_en               : std_logic;
    signal fs_10m_cnt                  : std_logic_vector(21 downto 0);
    
    signal tdd_in_dly                  : std_logic_vector(3 downto 0);
    signal d_in_sync_dly               : std_logic_vector(3 downto 0);
    signal d_in_sync_cnt               : std_logic_vector(4 downto 0);
    
    signal mult_out_32b                : std_logic_vector(31 downto 0);
    signal mult_out_52b                : std_logic_vector(51 downto 0);
    
    signal ca_iq_avg_en                : std_logic_vector(3 downto 0);
    
    signal ca_iq_sum                   : std_logic_array52(3 downto 0);
    signal ca_iq_avg                   : std_logic_array52(3 downto 0);

    signal i_update_done               : std_logic;
    
    signal i_conv_done                 : std_logic_vector(3 downto 0);
    signal i_pre_conv_pwr              : std_logic_array64(3 downto 0);
    

begin

    -- 10ms frame sync count
    process(RESET,CLK)
    begin
        if (RESET = '1') then
            d_in_sync_sh <= '0';
            rx_10m_fs_d <= (others => '0');
            fs_10m_cnt_en <= '0';
            fs_10m_cnt <= (others => '0');
        elsif rising_edge(CLK) then
            d_in_sync_sh <= D_IN_SYNC;
            rx_10m_fs_d <= rx_10m_fs_d(1 downto 0) & RX_10M_FS;
            if (rx_10m_fs_d(2) = '0' and rx_10m_fs_d(1) = '1')  then
                fs_10m_cnt_en <= '1';
            elsif (d_in_sync_sh = '1') then
                fs_10m_cnt_en <= '0';
            end if;

            if ((fs_10m_cnt_en = '1' and d_in_sync_sh = '1') or (fs_10m_cnt = 2457599)) then
                fs_10m_cnt <= (others => '0');
            else
                fs_10m_cnt <= fs_10m_cnt + 1;
            end if;
        end if;
    end process;

    -- TDD delay 
    process(RESET,CLK)
    begin
        if (RESET = '1') then
            tdd_in_dly <= (others => '0');
        elsif rising_edge(CLK) then
            tdd_in_dly <= tdd_in_dly(2 downto 0) & TDD_IN;
        end if;
    end process;

    -- d_in_sync delay & count
    process(RESET,CLK)
    begin
        if (RESET = '1') then
            d_in_sync_dly <= (others => '0');
            d_in_sync_cnt <= (others => '0');
        elsif rising_edge(CLK) then
            d_in_sync_dly <= d_in_sync_dly(2 downto 0) & d_in_sync_sh;
            if (d_in_sync_dly(2) = '1') then
                d_in_sync_cnt <= (others => '0');
            else
                d_in_sync_cnt <= d_in_sync_cnt + 1;
            end if;            
        end if;
    end process;

    process(RESET,CLK)
    begin
        if (RESET = '1') then
            ca_iq_avg_en <= (others => '0');
        elsif rising_edge(CLK) then
            if (fs_10m_cnt = 2457597) then
                ca_iq_avg_en(0) <= '1';
                ca_iq_avg_en(1) <= '0';
                ca_iq_avg_en(2) <= '0';
                ca_iq_avg_en(3) <= '0';
            elsif (fs_10m_cnt = 2457599) then
                ca_iq_avg_en(0) <= '0';
                ca_iq_avg_en(1) <= '1';
                ca_iq_avg_en(2) <= '0';
                ca_iq_avg_en(3) <= '0';
            elsif (fs_10m_cnt = 1) then
                ca_iq_avg_en(0) <= '0';
                ca_iq_avg_en(1) <= '0';
                ca_iq_avg_en(2) <= '1';
                ca_iq_avg_en(3) <= '0';
            elsif (fs_10m_cnt = 3) then
                ca_iq_avg_en(0) <= '0';
                ca_iq_avg_en(1) <= '0';
                ca_iq_avg_en(2) <= '0';
                ca_iq_avg_en(3) <= '1';
            else
                ca_iq_avg_en <= (others => '0');
            end if;
        end if;
    end process;

    process(RESET,CLK)
    begin
        if (RESET = '1') then
            i_update_done <= '0';
        elsif rising_edge(CLK) then
            if (fs_10m_cnt = 4) then
                i_update_done <= '1';
            else
                i_update_done <= '0';
            end if;
        end if;
    end process;

    mult_out_52b <= "00000000000000000000" & mult_out_32b;
--    process(RESET,CLK)
--    begin
--        if (RESET = '1') then
--            measure_done_i <= '0';
--            ca_iq_sum      <= (others => (others => '0'));
--            ca_iq_avg      <= (others => (others => '0'));
--        elsif rising_edge(CLK) then
--            if (ca_iq_sum_en = '1') then
--                measure_done_i <= '0';
--                ca_iq_avg <= ca_iq_avg;
--                if (d_in_sync_cnt(4 downto 1) = 0) then
--                    ca_iq_sum(0) <= ca_iq_sum(0) + mult_out_53b;
--                elsif (d_in_sync_cnt(4 downto 1) = 1) then
--                    ca_iq_sum(1) <= ca_iq_sum(1) + mult_out_53b;
--                elsif (d_in_sync_cnt(4 downto 1) = 2) then
--                    ca_iq_sum(2) <= ca_iq_sum(2) + mult_out_53b;
--                elsif (d_in_sync_cnt(4 downto 1) = 3) then
--                    ca_iq_sum(3) <= ca_iq_sum(3) + mult_out_53b;
--                end if;
--            elsif (ca_iq_avg_en = '1') then
--                measure_done_i <= '1';
--                ca_iq_sum <= ca_iq_sum;
--                ca_iq_avg <= ca_iq_sum;
--            else
--                measure_done_i <= '0';
--                ca_iq_sum <= (others => (others => '0'));
--                ca_iq_avg <= ca_iq_avg;
--            end if;
--        end if;
--    end process;
                    
    SUM_GEN : for N in 0 to 3 generate
    process(RESET,CLK)
    begin
        if (RESET = '1') then
            ca_iq_sum(N)      <= (others => '0');
            ca_iq_avg(N)      <= (others => '0');
        elsif rising_edge(CLK) then
            if (ca_iq_avg_en(N) = '1') then
                ca_iq_sum(N) <= (others => '0');
                ca_iq_avg(N) <= ca_iq_sum(N);
            elsif (tdd_in_dly(3) = '1') then
                ca_iq_avg(N) <= ca_iq_avg(N);
                if (d_in_sync_cnt(4 downto 1) = N) then
                    ca_iq_sum(N) <= ca_iq_sum(N) + mult_out_52b;
                end if;
            end if;
        end if;
    end process;

    i_pre_conv_pwr(N) <= x"000" & ca_iq_avg(N);
	end generate;

    MEASURE_DONE <= i_conv_done(0);
                    
    
    mult_16x16_i : MULT_MACRO
    generic map (
        DEVICE  => "7SERIES"   , -- Target Device: "VIRTEX5", "VIRTEX6", "SPARTAN6"
        LATENCY => 4           , -- Desired clock cycle latency, 0-4
        WIDTH_A => 16          , -- Multiplier A-input bus width, 1-25
        WIDTH_B => 16            -- Multiplier B-input bus width, 1-18
        )
    port map (
        P       => mult_out_32b, -- Multiplier output bus, width determined by WIDTH_P generic
        A       => D_IN        , -- Multiplier input A bus, width determined by WIDTH_A generic
        B       => D_IN        , -- Multiplier input B bus, width determined by WIDTH_B generic
        CE      => '1'         , -- 1-bit active high input clock enable
        CLK     => CLK         , -- 1-bit positive edge clock input
        RST     => RESET         -- 1-bit input active high reset
        );
                           

    u_pwr_conv_blk0 : MANTISSA_FRAMER 
    port map(
        RST          => RESET            , --: in  std_logic;
        CLK          => CLK              , --: in  std_logic;
    
        START_IN     => i_update_done    , --: in  std_logic;
        DATA_IN      => i_pre_conv_pwr(0), --: in  std_logic_vector(63 downto 0);
        
        DONE_OUT     => i_conv_done(0)   , --: out std_logic;
        MANTISSA_OUT => XSSI_0             --: out std_logic_vector(31 downto 0)
        );

    u_pwr_conv_blk1 : MANTISSA_FRAMER 
    port map(
        RST          => RESET            , --: in  std_logic;
        CLK          => CLK              , --: in  std_logic;
    
        START_IN     => i_update_done    , --: in  std_logic;
        DATA_IN      => i_pre_conv_pwr(1), --: in  std_logic_vector(63 downto 0);
        
        DONE_OUT     => i_conv_done(1)   , --: out std_logic;
        MANTISSA_OUT => XSSI_1             --: out std_logic_vector(31 downto 0)
        );

    u_pwr_conv_blk2 : MANTISSA_FRAMER 
    port map(
        RST          => RESET            , --: in  std_logic;
        CLK          => CLK              , --: in  std_logic;
    
        START_IN     => i_update_done    , --: in  std_logic;
        DATA_IN      => i_pre_conv_pwr(2), --: in  std_logic_vector(63 downto 0);
        
        DONE_OUT     => i_conv_done(2)   , --: out std_logic;
        MANTISSA_OUT => XSSI_2             --: out std_logic_vector(31 downto 0)
        );

    u_pwr_conv_blk3 : MANTISSA_FRAMER 
    port map(
        RST          => RESET            , --: in  std_logic;
        CLK          => CLK              , --: in  std_logic;
    
        START_IN     => i_update_done    , --: in  std_logic;
        DATA_IN      => i_pre_conv_pwr(3), --: in  std_logic_vector(63 downto 0);
        
        DONE_OUT     => i_conv_done(3)   , --: out std_logic;
        MANTISSA_OUT => XSSI_3             --: out std_logic_vector(31 downto 0)
        );

end ARC_XSSI_RPT_MANTISSA;


