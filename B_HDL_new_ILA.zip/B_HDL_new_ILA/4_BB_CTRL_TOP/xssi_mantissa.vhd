library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

library UNISIM;
use UNISIM.VCOMPONENTS.ALL;

library UNIMACRO;
use UNIMACRO.VCOMPONENTS.ALL;

entity XSSI_MANTISSA is
    generic (
        ACCUMULATION                : natural := 2457600                        -- Total clock
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        BW_SEL                      : in  std_logic_vector(3 downto 0);

        PWR_VALID                   : in  std_logic;
        RX_10M_FS                   : in  std_logic;
        TDD_IN                      : in  std_logic;
        D_IN_SYNC                   : in  std_logic;
        D_IN                        : in  std_logic_vector(15 downto 0);

        MEASURE_DONE                : out std_logic_vector(3 downto 0);
        XSSI_0                      : out std_logic_vector(31 downto 0);
        XSSI_1                      : out std_logic_vector(31 downto 0);
        XSSI_2                      : out std_logic_vector(31 downto 0);
        XSSI_3                      : out std_logic_vector(31 downto 0)
    );
end XSSI_MANTISSA;

architecture BEHAVE of XSSI_MANTISSA is

    signal buf_pwr_valid            : std_logic := '0';
    signal buf_fs_10ms              : std_logic := '0';
    signal buf_tdd                  : std_logic := '0';
    signal buf_sync                 : std_logic_vector(4 downto 0) := (others => '0');
    signal buf_data                 : std_logic_vector(15 downto 0) := (others => '0');

    signal detect_10ms              : std_logic := '0';

    signal mult_out_32b             : std_logic_vector(31 downto 0);
    signal mult_out_54b             : std_logic_vector(53 downto 0);

    signal cnt_acc                  : std_logic_vector(27 downto 0) := (others => '0');
    signal cnt_sample               : std_logic_vector(4 downto 0) := (others => '0');

    signal cnt_acc_sh               : std_logic_vector(27 downto 0) := (others => '0');
    signal cnt_sample_sh            : std_logic_vector(4 downto 0) := (others => '0');

    signal buf_clear                : std_logic_vector(3 downto 0) := (others => '0');
    signal buf_power                : std_logic_array54(3 downto 0) := (others => (others => '0'));
    signal acc_done                 : std_logic_vector(3 downto 0) := (others => '0');
    signal acc_power                : std_logic_array64(3 downto 0) := (others => (others => '0'));

    component MANTISSA_FRAMER is
    port (
        RST                         : in  std_logic;
        CLK                         : in  std_logic;

        START_IN                    : in  std_logic;
        DATA_IN                     : in  std_logic_vector(63 downto 0);

        DONE_OUT                    : out std_logic;
        MANTISSA_OUT                : out std_logic_vector(31 downto 0)
    );
    end component;

begin

    -- buffering
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (buf_sync(4) = '1') then
                buf_pwr_valid <= PWR_VALID;
                buf_tdd       <= TDD_IN;
            end if;
            buf_fs_10ms   <= RX_10M_FS;
            buf_sync      <= buf_sync(3 downto 0) & D_IN_SYNC;
            buf_data      <= D_IN;
        end if;
    end process;

    process (RESET, CLK)
    begin
        if (RESET = '1') then
            detect_10ms <= '0';
        elsif (CLK'event and CLK = '1') then
            if (RX_10M_FS = '1') and (buf_fs_10ms = '0') then
                detect_10ms <= '1';
            elsif (buf_sync(4) = '1') then
                detect_10ms <= '0';
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (detect_10ms = '1') and (buf_sync(4) = '1') then
                cnt_acc <= (others => '0');
            elsif (buf_pwr_valid = '1') then
                if (cnt_acc = ACCUMULATION-1) then
                    cnt_acc <= (others => '0');
                else
                    cnt_acc <= cnt_acc + 1;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (buf_sync(4) = '1') then
                cnt_sample <= (others => '0');
            else
                cnt_sample <= cnt_sample + 1;
            end if;
        end if;
    end process;

    mult_out_54b <= "0000000000000000000000" & mult_out_32b;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            cnt_acc_sh    <= cnt_acc;
            cnt_sample_sh <= cnt_sample;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (BW_SEL = 1) then
                if (cnt_acc(27 downto 5) = 0) then
                    if (cnt_sample = 1) then                buf_clear(0) <= '1';
                    else                                    buf_clear(0) <= '0';
                    end if;
                    if (cnt_sample = 3) then                buf_clear(1) <= '1';
                    else                                    buf_clear(1) <= '0';
                    end if;
                    if (cnt_sample = 5) then                buf_clear(2) <= '1';
                    else                                    buf_clear(2) <= '0';
                    end if;
                    if (cnt_sample = 7) then                buf_clear(3) <= '1';
                    else                                    buf_clear(3) <= '0';
                    end if;
                else
                    buf_clear <= (others => '0');
                end if;
            elsif (BW_SEL = 2) then         
                if (cnt_acc(27 downto 5) = 0) then
                    if (cnt_sample = 1) then                buf_clear(0) <= '1';
                    else                                    buf_clear(0) <= '0';
                    end if;
                    if (cnt_sample = 3) then                buf_clear(1) <= '1';
                    else                                    buf_clear(1) <= '0';
                    end if;
                    if (cnt_sample = 5) then                buf_clear(2) <= '1';
                    else                                    buf_clear(2) <= '0';
                    end if;
                    if (cnt_sample = 7) then                buf_clear(3) <= '1';
                    else                                    buf_clear(3) <= '0';
                    end if;
                else
                    buf_clear <= (others => '0');
                end if;
            elsif (BW_SEL = 3) then
                if (cnt_acc(27 downto 4) = 0) then
                    if (cnt_sample = 1) then                buf_clear(0) <= '1';
                    else                                    buf_clear(0) <= '0';
                    end if;
                    if (cnt_sample = 3) then                buf_clear(1) <= '1';
                    else                                    buf_clear(1) <= '0';
                    end if;
                    if (cnt_sample = 5) then                buf_clear(2) <= '1';
                    else                                    buf_clear(2) <= '0';
                    end if;
                    if (cnt_sample = 7) then                buf_clear(3) <= '1';
                    else                                    buf_clear(3) <= '0';
                    end if;
                else
                    buf_clear <= (others => '0');
                end if;
            else
                if (cnt_acc(27 downto 3) = 0) then
                    if (cnt_sample = 1) then                buf_clear(0) <= '1';
                    else                                    buf_clear(0) <= '0';
                    end if;
                    if (cnt_sample = 3) then                buf_clear(1) <= '1';
                    else                                    buf_clear(1) <= '0';
                    end if;
                    if (cnt_sample = 5) then                buf_clear(2) <= '1';
                    else                                    buf_clear(2) <= '0';
                    end if;
                    if (cnt_sample = 7) then                buf_clear(3) <= '1';
                    else                                    buf_clear(3) <= '0';
                    end if;
                else
                    buf_clear <= (others => '0');
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (buf_clear(0) = '1') then
                buf_power(0) <= (others => '0');
            elsif (buf_pwr_valid = '1') and (buf_tdd = '1') then
                if    (cnt_sample = 0) then         buf_power(0) <= buf_power(0) + mult_out_54b;
                elsif (cnt_sample = 1) then         buf_power(0) <= buf_power(0) + mult_out_54b;
                end if;
            end if;
            if (buf_clear(1) = '1') then
                buf_power(1) <= (others => '0');
            elsif (buf_pwr_valid = '1') and (buf_tdd = '1') then
                if    (cnt_sample = 2) then         buf_power(1) <= buf_power(1) + mult_out_54b;
                elsif (cnt_sample = 3) then         buf_power(1) <= buf_power(1) + mult_out_54b;
                end if;
            end if;
            if (buf_clear(2) = '1') then
                buf_power(2) <= (others => '0');
            elsif (buf_pwr_valid = '1') and (buf_tdd = '1') then
                if    (cnt_sample = 4) then         buf_power(2) <= buf_power(2) + mult_out_54b;
                elsif (cnt_sample = 5) then         buf_power(2) <= buf_power(2) + mult_out_54b;
                end if;
            end if;
            if (buf_clear(3) = '1') then
                buf_power(3) <= (others => '0');
            elsif (buf_pwr_valid = '1') and (buf_tdd = '1') then
                if    (cnt_sample = 6) then         buf_power(3) <= buf_power(3) + mult_out_54b;
                elsif (cnt_sample = 7) then         buf_power(3) <= buf_power(3) + mult_out_54b;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            acc_done <= buf_clear;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (BW_SEL = 1) then
                if (cnt_acc_sh(27 downto 5) = 0) then
                    if (cnt_sample_sh = 1) then             acc_power(0) <= x"00" & "00" & buf_power(0);
                    end if;
                    if (cnt_sample_sh = 3) then             acc_power(1) <= x"00" & "00" & buf_power(1);
                    end if;
                    if (cnt_sample_sh = 5) then             acc_power(2) <= x"00" & "00" & buf_power(2);
                    end if;
                    if (cnt_sample_sh = 7) then             acc_power(3) <= x"00" & "00" & buf_power(3);
                    end if;
                end if;
            elsif (BW_SEL = 2) then
                if (cnt_acc_sh(27 downto 5) = 0) then
                    if (cnt_sample_sh = 1) then             acc_power(0) <= x"00" & "00" & buf_power(0);
                    end if;
                    if (cnt_sample_sh = 3) then             acc_power(1) <= x"00" & "00" & buf_power(1);
                    end if;
                    if (cnt_sample_sh = 5) then             acc_power(2) <= x"00" & "00" & buf_power(2);
                    end if;
                    if (cnt_sample_sh = 7) then             acc_power(3) <= x"00" & "00" & buf_power(3);
                    end if;
                end if;
            elsif (BW_SEL = 3) then
                if (cnt_acc_sh(27 downto 4) = 0) then
                    if (cnt_sample_sh = 1) then             acc_power(0) <= x"00" & "00" & buf_power(0);
                    end if;
                    if (cnt_sample_sh = 3) then             acc_power(1) <= x"00" & "00" & buf_power(1);
                    end if;
                    if (cnt_sample_sh = 5) then             acc_power(2) <= x"00" & "00" & buf_power(2);
                    end if;
                    if (cnt_sample_sh = 7) then             acc_power(3) <= x"00" & "00" & buf_power(3);
                    end if;
                end if;
            else
                if (cnt_acc_sh(27 downto 3) = 0) then
                    if (cnt_sample_sh = 1) then             acc_power(0) <= x"00" & "00" & buf_power(0);
                    end if;
                    if (cnt_sample_sh = 3) then             acc_power(1) <= x"00" & "00" & buf_power(1);
                    end if;
                    if (cnt_sample_sh = 5) then             acc_power(2) <= x"00" & "00" & buf_power(2);
                    end if;
                    if (cnt_sample_sh = 7) then             acc_power(3) <= x"00" & "00" & buf_power(3);
                    end if;
                end if;
            end if;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_MULT : MULT_MACRO
    generic map(
        DEVICE                      => "7SERIES"                               ,-- Target Device: "VIRTEX5", "VIRTEX6", "SPARTAN6"
        LATENCY                     => 4                                       ,-- Desired clock cycle latency, 0-4
        WIDTH_A                     => 16                                      ,-- Multiplier A-input bus width, 1-25
        WIDTH_B                     => 16                                       -- Multiplier B-input bus width, 1-18
    )
    port map(
        P                           => mult_out_32b                            ,-- Multiplier output bus, width determined by WIDTH_P generic
        A                           => buf_data                                ,-- Multiplier input A bus, width determined by WIDTH_A generic
        B                           => buf_data                                ,-- Multiplier input B bus, width determined by WIDTH_B generic
        CE                          => '1'                                     ,-- 1-bit active high input clock enable
        CLK                         => CLK                                     ,-- 1-bit positive edge clock input
        RST                         => RESET                                    -- 1-bit input active high reset
    );

    u_PWR_CONV_BLK0 : MANTISSA_FRAMER 
    port map(
        RST                         => RESET                                   ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;

        START_IN                    => acc_done(0)                             ,--: in  std_logic;
        DATA_IN                     => acc_power(0)                            ,--: in  std_logic_vector(63 downto 0);

        DONE_OUT                    => MEASURE_DONE(0)                         ,--: out std_logic;
        MANTISSA_OUT                => XSSI_0                                   --: out std_logic_vector(31 downto 0)
    );

    u_PWR_CONV_BLK1 : MANTISSA_FRAMER 
    port map(
        RST                         => RESET                                   ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;

        START_IN                    => acc_done(1)                             ,--: in  std_logic;
        DATA_IN                     => acc_power(1)                            ,--: in  std_logic_vector(63 downto 0);

        DONE_OUT                    => MEASURE_DONE(1)                         ,--: out std_logic;
        MANTISSA_OUT                => XSSI_1                                   --: out std_logic_vector(31 downto 0)
    );

    u_PWR_CONV_BLK2 : MANTISSA_FRAMER 
    port map(
        RST                         => RESET                                   ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;

        START_IN                    => acc_done(2)                             ,--: in  std_logic;
        DATA_IN                     => acc_power(2)                            ,--: in  std_logic_vector(63 downto 0);

        DONE_OUT                    => MEASURE_DONE(2)                         ,--: out std_logic;
        MANTISSA_OUT                => XSSI_2                                   --: out std_logic_vector(31 downto 0)
    );

    u_PWR_CONV_BLK3 : MANTISSA_FRAMER 
    port map(
        RST                         => RESET                                   ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;

        START_IN                    => acc_done(3)                             ,--: in  std_logic;
        DATA_IN                     => acc_power(3)                            ,--: in  std_logic_vector(63 downto 0);

        DONE_OUT                    => MEASURE_DONE(3)                         ,--: out std_logic;
        MANTISSA_OUT                => XSSI_3                                   --: out std_logic_vector(31 downto 0)
    );

end BEHAVE;
