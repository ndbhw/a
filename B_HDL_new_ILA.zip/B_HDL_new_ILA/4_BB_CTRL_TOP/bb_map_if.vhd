--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : muxing DL 4 path to 1 path                                    --
--                                                                            --
-- Author     : h_r.hong (h_r.hong@samsung.com)                               --
-- Department : FPGA part. (Network Division)                                 --
-- Release    : 2021.06.12                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity BB_MAP_IF is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        I_BW_SEL                    : in  std_logic_vector(3 downto 0);        

--------------------------------------------------------------------------------
-- BB_TOP
--------------------------------------------------------------------------------

        I_DL_FSYNC                  :in  std_logic;    -- 1 clock frame(10ms) sync  
        I_DL_TDD                    :in  std_logic;       
        I_DL_DATA_I                 :in  std_logic_array16(3 downto 0);    -- 16b idata path per one ant path.      
        I_DL_DATA_Q                 :in  std_logic_array16(3 downto 0);    -- 16b qdata path per one ant path.  

        O_UL_FSYNC                  :out std_logic;    -- 1 clock frame(10ms) sync   
        O_UL_TDD                    :out std_logic;       
        O_UL_VLD                    :out std_logic_vector( 3 downto 0);    -- valid signal for valid data.   
        O_UL_DATA_I                 :out std_logic_array16(3 downto 0);    -- 16b idata path per one ant path.  
        O_UL_DATA_Q                 :out std_logic_array16(3 downto 0);    -- 16b qdata path per one ant path.  

--------------------------------------------------------------------------------
-- FORMATTER
--------------------------------------------------------------------------------

        O_DL_10MS                   : out std_logic;
        O_DL_TDD                    : out std_logic;
        O_DL_SYNC                   : out std_logic;
        O_DL_DATA                   : out std_logic_vector(15 downto 0);

        I_UL_FSYNC                  : in  std_logic;
        I_UL_TDD                    : in  std_logic;
        I_UL_SYNC                   : in  std_logic;
        I_UL_DATA                   : in  std_logic_vector(15 downto 0) 
    );
end BB_MAP_IF;

architecture BEHAVE of BB_MAP_IF is


       signal dl_data_i_d1               : std_logic_array16(3 downto 0) := (others => (others => '0'));    -- 16b idata path per one ant path.      
       signal dl_data_q_d1               : std_logic_array16(3 downto 0) := (others => (others => '0'));    -- 16b qdata path per one ant path.  
       signal dl_data_i_d2               : std_logic_array16(3 downto 0) := (others => (others => '0'));    -- 16b idata path per one ant path.      
       signal dl_data_q_d2               : std_logic_array16(3 downto 0) := (others => (others => '0'));    -- 16b qdata path per one ant path.  
       signal dl_data_mux                : std_logic_vector(15 downto 0) := (others => '0');

       signal dl_fsync_d                 : std_logic := '0';
       signal dl_fsync_rpls              : std_logic := '0';
       signal dl_fsync_rpls_d            : std_logic := '0';
       signal dl_chip_sync               : std_logic := '0';
       signal dl_tdd_d                   : std_logic_vector(1 downto 0) := (others => '0');
       signal dl_clk_cnt                 : std_logic_vector(5 downto 0) := (others => '0');   
       signal dl_bfn_strb                : std_logic := '0';

       signal ul_clk_cnt                 : std_logic_vector(4 downto 0) := (others => '0');
       signal ul_data_mux_d              : std_logic_vector(15 downto 0) := (others => '0');
       signal ul_fsync_d                 : std_logic := '0';
       signal ul_fsync_rpls              : std_logic := '0'; 
       signal ul_fsync_rpls_d            : std_logic_vector(8 downto 0) := (others => '0');
       signal ul_data_i                  : std_logic_array16(3 downto 0) := (others => (others => '0'));    -- 16b idata path per one ant path.  
       signal ul_data_q                  : std_logic_array16(3 downto 0) := (others => (others => '0'));    -- 16b qdata path per one ant path.  
       signal ul_sync_d                  : std_logic := '0';
       signal ul_data_i_out              : std_logic_array16(3 downto 0) := (others => (others => '0'));    -- 16b idata path per one ant path.  
       signal ul_data_q_out              : std_logic_array16(3 downto 0) := (others => (others => '0'));    -- 16b qdata path per one ant path.  


begin

    PROCESSING_DELAY_DL <= conv_std_logic_vector( 3, 24);
    PROCESSING_DELAY_UL <= conv_std_logic_vector(10, 24);

    O_DL_SYNC  <= dl_chip_sync; 
    O_DL_DATA  <= dl_data_mux; 

    O_UL_FSYNC  <= ul_fsync_rpls_d(8); 
    O_UL_TDD    <= I_UL_TDD; 
    O_UL_VLD    <= (others => '1');
    O_UL_DATA_I <= ul_data_i_out;
    O_UL_DATA_Q <= ul_data_q_out;
    

    --DL map interface (lphy -> formatter)
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            dl_data_i_d1 <= I_DL_DATA_I;  
            dl_data_q_d1 <= I_DL_DATA_Q; 
            dl_data_i_d2 <= dl_data_i_d1; 
            dl_data_q_d2 <= dl_data_q_d1;  
        end if;
    end process;
    
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            dl_fsync_d      <= I_DL_FSYNC;
            dl_fsync_rpls   <= I_DL_FSYNC and (not dl_fsync_d);
            dl_fsync_rpls_d <= dl_fsync_rpls;
            if (dl_fsync_rpls = '1') then
                dl_clk_cnt <= (others => '0');
            else
                dl_clk_cnt <= dl_clk_cnt + 1;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (dl_clk_cnt = 63) then
                if (dl_fsync_rpls = '1') then
                    dl_bfn_strb <= '1';
                else
                    dl_bfn_strb <= '0';
                end if;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (dl_chip_sync = '1') then
                O_DL_10MS <= dl_bfn_strb;
            end if;
        end if;
    end process;    

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            dl_tdd_d <= dl_tdd_d(0) & I_DL_TDD;
            O_DL_TDD <= dl_tdd_d(1);
        end if;
    end process;

--------------- origin
--    process(CLK_SYSX8)
--    begin
--        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
--            if (dl_clk_cnt(5 downto 0) = 63) then
--                dl_chip_sync <= '1';
--            else
--                dl_chip_sync <= '0';
--            end if;
--        end if;
--    end process;
--------------- origin
--------------- NEW       
    -- chip to sample
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            case I_BW_SEL is
            when x"1" =>  -- 3-MHz
                if (dl_clk_cnt(4 downto 0) = 31) then
                dl_chip_sync <= '1';
            else
                dl_chip_sync <= '0';
            end if;
            when x"2" =>  -- 5-MHz
                if (dl_clk_cnt(4 downto 0) = 31) then
                    dl_chip_sync <= '1';
                else
                    dl_chip_sync <= '0';
                end if;
            when x"3" =>  -- 10-MHz
                if (dl_clk_cnt(3 downto 0) = 15) then
                    dl_chip_sync <= '1';
                else
                    dl_chip_sync <= '0';
                end if;            
            when others =>  -- 15/20-MHz
                if (dl_clk_cnt(2 downto 0) = 7) then
                    dl_chip_sync <= '1';
                else
                    dl_chip_sync <= '0';
                end if;
            end case;
        end if;
    end process;

--------------------------------------------------------------------------------
--------------- NEW     

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (I_BW_SEL = x"2") OR (I_BW_SEL = x"1") then
                if (dl_clk_cnt(4 downto 3) = "00") then
                    case dl_clk_cnt(2 downto 0) is
                        when "000" => dl_data_mux <= dl_data_i_d2(0);
                        when "001" => dl_data_mux <= dl_data_q_d2(0);
                        when "010" => dl_data_mux <= dl_data_i_d2(1);
                        when "011" => dl_data_mux <= dl_data_q_d2(1);
                        when "100" => dl_data_mux <= dl_data_i_d2(2);
                        when "101" => dl_data_mux <= dl_data_q_d2(2);
                        when "110" => dl_data_mux <= dl_data_i_d2(3);
                        when "111" => dl_data_mux <= dl_data_q_d2(3);
                        when others => dl_data_mux <= (others => '0');
                    end case;
                else
                    dl_data_mux <= (others => '0');
                end if;
            elsif (I_BW_SEL = x"3") then
                if (dl_clk_cnt(3) = '0') then
                    case dl_clk_cnt(2 downto 0) is
                        when "000" => dl_data_mux <= dl_data_i_d2(0);
                        when "001" => dl_data_mux <= dl_data_q_d2(0);
                        when "010" => dl_data_mux <= dl_data_i_d2(1);
                        when "011" => dl_data_mux <= dl_data_q_d2(1);
                        when "100" => dl_data_mux <= dl_data_i_d2(2);
                        when "101" => dl_data_mux <= dl_data_q_d2(2);
                        when "110" => dl_data_mux <= dl_data_i_d2(3);
                        when "111" => dl_data_mux <= dl_data_q_d2(3);
                        when others => dl_data_mux <= (others => '0');
                    end case;
                else
                    dl_data_mux <= (others => '0');
                end if;
            else
                case dl_clk_cnt(2 downto 0) is
                    when "000" => dl_data_mux <= dl_data_i_d2(0);
                    when "001" => dl_data_mux <= dl_data_q_d2(0);
                    when "010" => dl_data_mux <= dl_data_i_d2(1);
                    when "011" => dl_data_mux <= dl_data_q_d2(1);
                    when "100" => dl_data_mux <= dl_data_i_d2(2);
                    when "101" => dl_data_mux <= dl_data_q_d2(2);
                    when "110" => dl_data_mux <= dl_data_i_d2(3);
                    when "111" => dl_data_mux <= dl_data_q_d2(3);
                    when others => dl_data_mux <= (others => '0');
                end case;
            end if;
        end if;
    end process;

    --UL map interface (lphy -> formatter)
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            ul_data_mux_d <= I_UL_DATA;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            ul_sync_d <= I_UL_SYNC;
            if (ul_sync_d = '1') then
                ul_clk_cnt <= (others => '0');
            else
                ul_clk_cnt <= ul_clk_cnt + 1;
            end if;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            case ul_clk_cnt(2 downto 0) is
                when "000"  => ul_data_i(0) <= ul_data_mux_d;
                when "001"  => ul_data_q(0) <= ul_data_mux_d;
                when "010"  => ul_data_i(1) <= ul_data_mux_d;
                when "011"  => ul_data_q(1) <= ul_data_mux_d;
                when "100"  => ul_data_i(2) <= ul_data_mux_d;
                when "101"  => ul_data_q(2) <= ul_data_mux_d;
                when "110"  => ul_data_i(3) <= ul_data_mux_d;
                when "111"  => ul_data_q(3) <= ul_data_mux_d;
                when others => ul_data_i    <= (others => (others => '0'));
                               ul_data_q    <= (others => (others => '0'));                               
            end case;
        end if;
    end process;

    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (I_BW_SEL = x"2") OR (I_BW_SEL = x"1") then    -- 3M/5M
                if (ul_clk_cnt(4 downto 0) ="01000") then
                    ul_data_i_out <= ul_data_i;
                    ul_data_q_out <= ul_data_q;
                else
                    ul_data_i_out <= ul_data_i_out;
                    ul_data_q_out <= ul_data_q_out;
                end if;
            elsif(I_BW_SEL = x"3") then  -- 10M
                if (ul_clk_cnt(3 downto 0) ="1000") then
                    ul_data_i_out <= ul_data_i;
                    ul_data_q_out <= ul_data_q;
                else
                    ul_data_i_out <= ul_data_i_out;
                    ul_data_q_out <= ul_data_q_out;
                end if;
            else
                if (ul_clk_cnt(2 downto 0) ="000") then
                    ul_data_i_out <= ul_data_i;
                    ul_data_q_out <= ul_data_q;
                else
                    ul_data_i_out <= ul_data_i_out;
                    ul_data_q_out <= ul_data_q_out;
                end if;
            end if;                
        end if;
    end process;
    
    process(CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            ul_fsync_d      <= I_UL_FSYNC;
            ul_fsync_rpls   <= I_UL_FSYNC and (not ul_fsync_d);
            ul_fsync_rpls_d <= ul_fsync_rpls_d(7 downto 0) & ul_fsync_rpls;
        end if;
    end process;

end BEHAVE;







