--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2017, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : BBCTRL Top (Master FPGA)                                      --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2017.05.17                                                    --
-- Target     : PFV01U-D1A/D2A                                                --
--                                                                            --
--------------------------------------------------------------------------------
-- Feature (V3.0, 2017-05-17 based)                                           --
--------------------------------------------------------------------------------
--  1. Max CPRI port : 2                                                      --
--  2. Max mapper : 2                                                         --
--  3. Max formatter : 2                                                      --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;
use WORK.RU_FPGA_CONFIG.ALL;

entity BBCTRL_TOP is
    port (
--------------------------------------------------------------------------------
-- SYSCTRL_TOP
--------------------------------------------------------------------------------

        RST_BBCTRL                  : in  std_logic;

        CLK_SYS                     : in  std_logic;
        CLK_SYSX2                   : in  std_logic;
        CLK_SYSX3                   : in  std_logic;
        CLK_SYSX4                   : in  std_logic;
        CLK_SYSX5                   : in  std_logic;
        CLK_SYSX6                   : in  std_logic;
        CLK_SYSX8                   : in  std_logic;
        CLK_SYSX10                  : in  std_logic;
        CLK_SYSX12                  : in  std_logic;
        CLK_SYSX16                  : in  std_logic;
        CLK_SYSX20                  : in  std_logic;

--------------------------------------------------------------------------------
-- CPU_TOP
--------------------------------------------------------------------------------

        RST_CPUIF                   : in  std_logic;
        CLK_CPUIF                   : in  std_logic;

        I_1PPS_CPU                  : in  std_logic;
        I_BFN_STRB_CPU              : in  std_logic;
        I_BFN_CPU                   : in  std_logic_vector(10 downto 0);

--------------------------------------------------------------------------------
-- CPUIF_TOP
--------------------------------------------------------------------------------

        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);    
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             : out std_logic;

--------------------------------------------------------------------------------
-- BB_TOP
--------------------------------------------------------------------------------

        I_DL_FSYNC                  :in  std_logic_vector(   DL_CC_NUM-1 downto 0);    -- 1 clock frame(10ms) sync  
        I_DL_TDD                    :in  std_logic_vector(   DL_CC_NUM-1 downto 0);       
        I_DL_VLD                    :in  std_logic_vector( DL_CC_NUM*4-1 downto 0);    -- valid signal for valid data.   
        I_DL_DATA_I                 :in  std_logic_array16(DL_CC_NUM*4-1 downto 0);    -- 16b idata path per one ant path.      
        I_DL_DATA_Q                 :in  std_logic_array16(DL_CC_NUM*4-1 downto 0);    -- 16b qdata path per one ant path.  

        O_UL_FSYNC                  :out std_logic_vector(   UL_CC_NUM-1 downto 0);    -- 1 clock frame(10ms) sync   
        O_UL_TDD                    :out std_logic_vector(   UL_CC_NUM-1 downto 0);       
        O_UL_VLD                    :out std_logic_vector( UL_CC_NUM*4-1 downto 0);    -- valid signal for valid data.   
        O_UL_DATA_I                 :out std_logic_array16(UL_CC_NUM*4-1 downto 0);    -- 16b idata path per one ant path.  
        O_UL_DATA_Q                 :out std_logic_array16(UL_CC_NUM*4-1 downto 0);    -- 16b qdata path per one ant path.  

--------------------------------------------------------------------------------
-- PIM_SBIF_TOP
--------------------------------------------------------------------------------

        PIM_SBIF_RX_ENB_IN          : in  std_logic_vector(PIM_SBIF_NUM-1 downto 0);
        PIM_SBIF_RX_I_IN            : in  std_logic_array16(PIM_SBIF_NUM-1 downto 0);
        PIM_SBIF_RX_Q_IN            : in  std_logic_array16(PIM_SBIF_NUM-1 downto 0);

        PIM_SBIF_TX_VLD_OUT         : out std_logic_vector(PIM_SBIF_NUM-1 downto 0);
        PIM_SBIF_TX_I_OUT           : out std_logic_array16(PIM_SBIF_NUM-1 downto 0);
        PIM_SBIF_TX_Q_OUT           : out std_logic_array16(PIM_SBIF_NUM-1 downto 0);

        PIM_SBIF_TX_SYNC            : out std_logic;
        PIM_SBIF_TX_1PPS            : out std_logic;
        PIM_SBIF_TX_BFN_STRB        : out std_logic;
        PIM_SBIF_TX_BFN             : out std_logic_vector(10 downto 0);

--------------------------------------------------------------------------------
-- DSP_TOP
--------------------------------------------------------------------------------

        DL_BFN_OK                   : out std_logic;

        DL_AIRTECH_OUT              : out std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
        DL_CHBW_OUT                 : out std_logic_array4(DL_BBIQARY_NUM-1 downto 0);
        DL_TDD_OUT                  : out std_logic;
        DL_40MS_OUT                 : out std_logic;
        DL_BFN_STRB_OUT             : out std_logic;
        DL_BFN_OUT                  : out std_logic_vector(11 downto 0);
        DL_SYNC_OUT                 : out std_logic_vector(DL_BBIQARY_NUM-1 downto 0);
        DL_IQ_OUT                   : out std_logic_array16(DL_BBIQARY_NUM-1 downto 0);

        UL_AIRTECH_OUT              : out std_logic_array4(UL_BBIQARY_NUM-1 downto 0);
        UL_CHBW_OUT                 : out std_logic_array4(UL_BBIQARY_NUM-1 downto 0);
        UL_TDD_IN                   : in  std_logic;
        UL_BFN_STRB_IN              : in  std_logic;
        UL_SYNC_IN                  : in  std_logic_vector(UL_BBIQARY_NUM-1 downto 0);
        UL_IQ_IN                    : in  std_logic_array16(UL_BBIQARY_NUM-1 downto 0);

        PIM_SYNC_IN                 : in  std_logic_vector(PIM_SBIF_NUM-1 downto 0);
        PIM_I_IN                    : in  std_logic_array15(PIM_SBIF_NUM-1 downto 0);
        PIM_Q_IN                    : in  std_logic_array15(PIM_SBIF_NUM-1 downto 0);

        PIM_SYNC_OUT                : out std_logic_vector(PIM_SBIF_NUM-1 downto 0);
        PIM_I_OUT                   : out std_logic_array15(PIM_SBIF_NUM-1 downto 0);
        PIM_Q_OUT                   : out std_logic_array15(PIM_SBIF_NUM-1 downto 0);

--------------------------------------------------------------------------------
-- MISC_TOP
--------------------------------------------------------------------------------

        DUMP_BFN_STRB_OUT           : out std_logic_vector(1 downto 0);
        DUMP_DATA_OUT               : out std_logic_array32(1 downto 0);
        DUMP_DVLD_OUT               : out std_logic_vector(1 downto 0);

     -- fb_sw_new
        FBSW_CNT                    : in  std_logic_vector(3 downto 0);
        FBSW_SSB_IND_FLAG           : in  std_logic; 
        FBSW_MEAS_UPDATE            : in  std_logic 
    );
end BBCTRL_TOP;

architecture BEHAVE of BBCTRL_TOP is

    constant NUM_CPRI               : natural := CPRI_NUM;
    constant NUM_FMT                : natural := UL_CC_NUM;
    constant NUM_MAP                : natural := TOTAL_MAP_NUM;

--    signal dl_cpri_if_delay         : std_logic_array24(NUM_CPRI-1 downto 0);
--    signal dl_cpri_switch_delay     : std_logic_vector(23 downto 0);
--    signal dl_mapper_delay          : std_logic_array24(NUM_MAP-1 downto 0);
--    signal dl_map_switch_delay      : std_logic_vector(22 downto 0);
    signal dl_map_if_delay          : std_logic_array24(NUM_FMT-1 downto 0);
    signal dl_formatter_delay       : std_logic_array24(NUM_FMT-1 downto 0);

--    signal ul_cpri_if_delay         : std_logic_array24(NUM_CPRI-1 downto 0);
--    signal ul_cpri_switch_delay     : std_logic_vector(23 downto 0);
--    signal ul_mapper_delay          : std_logic_array24(NUM_MAP-1 downto 0);
--    signal ul_map_switch_delay      : std_logic_vector(23 downto 0);
    signal ul_map_if_delay          : std_logic_array24(NUM_FMT-1 downto 0);
    signal ul_formatter_delay       : std_logic_array24(NUM_FMT-1 downto 0);

    component CPUIF_BBCTRL is
    generic (
        OFFSET                      : std_logic_vector(3 downto 0) := x"4";
        NUM_CPRI                    : natural := 8;
        NUM_MAP                     : natural := 8;
        NUM_FMT                     : natural := 8
    );
    port (
        CLK_AUX                     : in  std_logic;
        CLK_SYSX8                   : in  std_logic;

        RESET                       : in  std_logic;

        DL_CPRI_IF_DELAY            : in  std_logic_array24(NUM_CPRI-1 downto 0);
        DL_CPRI_SWITCH_DELAY        : in  std_logic_vector(23 downto 0);
        DL_MAPPER_DELAY             : in  std_logic_array24(NUM_MAP-1 downto 0);
        DL_MAP_SWITCH_DELAY         : in  std_logic_vector(23 downto 0);
        DL_MAP_IF_DELAY             : in  std_logic_array24(NUM_FMT-1 downto 0);
        DL_FORMATTER_DELAY          : in  std_logic_array24(NUM_FMT-1 downto 0);

        UL_CPRI_IF_DELAY            : in  std_logic_array24(NUM_CPRI-1 downto 0);
        UL_CPRI_SWITCH_DELAY        : in  std_logic_vector(23 downto 0);
        UL_MAPPER_DELAY             : in  std_logic_array24(NUM_MAP-1 downto 0);
        UL_MAP_SWITCH_DELAY         : in  std_logic_vector(23 downto 0);
        UL_MAP_IF_DELAY             : in  std_logic_array24(NUM_FMT-1 downto 0);
        UL_FORMATTER_DELAY          : in  std_logic_array24(NUM_FMT-1 downto 0);

        DUMP_EN                     : out std_logic;
        DUMP_SEL                    : out std_logic_vector(15 downto 0);

        DBG_SYNC_CNT                : in  std_logic_vector(10 downto 0);
        DBG_SYNC_CHK                : in  std_logic_vector(10 downto 0);

        BW_SEL                      : out std_logic_array4(NUM_FMT-1 downto 0);

        DL_MAP_WR_EN                : out std_logic_vector(NUM_MAP-1 downto 0);
        DL_MAP_WR_ADDR              : out std_logic_vector(4 downto 0);
        DL_MAP_WR_DATA              : out std_logic_vector(6 downto 0);
        DL_MAP_RD_DATA              : in  std_logic_array7(NUM_MAP-1 downto 0);

        UL_MAP_WR_EN                : out std_logic_vector(NUM_MAP-1 downto 0);
        UL_MAP_WR_ADDR              : out std_logic_vector(5 downto 0);
        UL_MAP_WR_DATA              : out std_logic_vector(6 downto 0);
        UL_MAP_RD_DATA              : in  std_logic_array7(NUM_MAP-1 downto 0);

        MAP_CPRI                    : out std_logic_array8(NUM_MAP-1 downto 0);

        MAPPER_UL_MAP               : out std_logic_array16(NUM_MAP-1 downto 0);
        FORMATTER_DL_MAP            : out std_logic_array16(NUM_FMT-1 downto 0);
        CASCADE_UL_SUM              : out std_logic_array16(2 downto 0);

        SYNC_DELAY_VALUE            : out std_logic_array32(NUM_FMT-1 downto 0);

        DL_DELAY_VALUE              : out std_logic_array32(NUM_FMT-1 downto 0);
        UL_DELAY_VALUE              : out std_logic_array32(NUM_FMT-1 downto 0);

        ZRHC_BYPASS                 : out std_logic_vector(NUM_FMT-1 downto 0);
        ZRHC_THRESHOLD              : out std_logic_array32(NUM_FMT-1 downto 0);
        ZRHC_OCCUR                  : in  std_logic_array4(NUM_FMT-1 downto 0);

        DL_ON                       : out std_logic_array4(NUM_FMT-1 downto 0);
        UL_ON                       : out std_logic_array4(NUM_FMT-1 downto 0);

        DL_ATT_0                    : out std_logic_array16(NUM_FMT-1 downto 0);
        DL_ATT_1                    : out std_logic_array16(NUM_FMT-1 downto 0);
        DL_ATT_2                    : out std_logic_array16(NUM_FMT-1 downto 0);
        DL_ATT_3                    : out std_logic_array16(NUM_FMT-1 downto 0);

        UL_ATT_0                    : out std_logic_array16(NUM_FMT-1 downto 0);
        UL_ATT_1                    : out std_logic_array16(NUM_FMT-1 downto 0);
        UL_ATT_2                    : out std_logic_array16(NUM_FMT-1 downto 0);
        UL_ATT_3                    : out std_logic_array16(NUM_FMT-1 downto 0);

        TSSI_UPDATE_MODE            : out std_logic_vector(1 downto 0);
        TSSI_UPDATE_CNT_0           : out std_logic_array5(NUM_FMT-1 downto 0);
        TSSI_UPDATE_CNT_1           : out std_logic_array5(NUM_FMT-1 downto 0);
        TSSI_UPDATE_CNT_2           : out std_logic_array5(NUM_FMT-1 downto 0);
        TSSI_UPDATE_CNT_3           : out std_logic_array5(NUM_FMT-1 downto 0);

        RSSI_UPDATE_MODE            : out std_logic_vector(1 downto 0);
        RSSI_UPDATE_CNT_0           : out std_logic_array5(NUM_FMT-1 downto 0);
        RSSI_UPDATE_CNT_1           : out std_logic_array5(NUM_FMT-1 downto 0);
        RSSI_UPDATE_CNT_2           : out std_logic_array5(NUM_FMT-1 downto 0);
        RSSI_UPDATE_CNT_3           : out std_logic_array5(NUM_FMT-1 downto 0);

        TSSI_0                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        TSSI_1                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        TSSI_2                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        TSSI_3                      : in  std_logic_array32(NUM_FMT-1 downto 0);

        RSSI_0                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        RSSI_1                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        RSSI_2                      : in  std_logic_array32(NUM_FMT-1 downto 0);
        RSSI_3                      : in  std_logic_array32(NUM_FMT-1 downto 0);

        SCALE_FACTOR                : out std_logic_array3(5 downto 0);

        TEST_MODE                   : out std_logic_array4(NUM_FMT-1 downto 0);
        TP_EN                       : out std_logic;
	    TP_MEM_PEN                  : out std_logic; -- A/B port enable
	    TP_MEM_AWEN                 : out std_logic; -- A port write enable
	    TP_MEM_WRADDR               : out std_logic_vector(14 downto 0);
	    TP_MEM_WRDATA               : out std_logic_vector(31 downto 0); -- 31..16 : Q data, 15..0 : I data

        TEST_DC_I                   : out std_logic_vector(15 downto 0);
        TEST_DC_Q                   : out std_logic_vector(15 downto 0);
        TEST_NCO                    : out std_logic_vector(5 downto 0);

        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);    
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             : out std_logic
    );
    end component;

    signal dump_en                  : std_logic;
    signal dump_sel                 : std_logic_vector(15 downto 0);
    signal bw_sel                   : std_logic_array4(NUM_FMT-1 downto 0);
    signal dl_map_wr_en             : std_logic_vector(NUM_MAP-1 downto 0);
    signal dl_map_wr_addr           : std_logic_vector(4 downto 0);
    signal dl_map_wr_data           : std_logic_vector(6 downto 0);
    signal dl_map_rd_data           : std_logic_array7(NUM_MAP-1 downto 0);
    signal ul_map_wr_en             : std_logic_vector(NUM_MAP-1 downto 0);
    signal ul_map_wr_addr           : std_logic_vector(5 downto 0);
    signal ul_map_wr_data           : std_logic_vector(6 downto 0);
    signal ul_map_rd_data           : std_logic_array7(NUM_MAP-1 downto 0);
    signal map_cpri                 : std_logic_array8(NUM_MAP-1 downto 0);
    signal mapper_ul_map            : std_logic_array16(NUM_MAP-1 downto 0);
    signal formatter_dl_map         : std_logic_array16(NUM_FMT-1 downto 0);
    signal cascade_ul_sum           : std_logic_array16(2 downto 0);
    signal sync_delay_value         : std_logic_array32(NUM_FMT-1 downto 0);
    signal dl_delay_value           : std_logic_array32(NUM_FMT-1 downto 0);
    signal ul_delay_value           : std_logic_array32(NUM_FMT-1 downto 0);
    signal zrhc_bypass              : std_logic_vector(NUM_FMT-1 downto 0);
    signal zrhc_threshold           : std_logic_array32(NUM_FMT-1 downto 0);
    signal zrhc_occur               : std_logic_array4(NUM_FMT-1 downto 0);
    signal dl_on                    : std_logic_array4(NUM_FMT-1 downto 0);
    signal dl_on_max                : std_logic_array4(7 downto 0) := (others => (others => '0'));
    signal ul_on                    : std_logic_array4(NUM_FMT-1 downto 0);
    signal dl_att_0                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal dl_att_1                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal dl_att_2                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal dl_att_3                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal ul_att_0                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal ul_att_1                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal ul_att_2                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal ul_att_3                 : std_logic_array16(NUM_FMT-1 downto 0);
    signal tssi_update_mode         : std_logic_vector(1 downto 0);
    signal tssi_update_cnt_0        : std_logic_array5(NUM_FMT-1 downto 0);
    signal tssi_update_cnt_1        : std_logic_array5(NUM_FMT-1 downto 0);
    signal tssi_update_cnt_2        : std_logic_array5(NUM_FMT-1 downto 0);
    signal tssi_update_cnt_3        : std_logic_array5(NUM_FMT-1 downto 0);
    signal rssi_update_mode         : std_logic_vector(1 downto 0);
    signal rssi_update_cnt_0        : std_logic_array5(NUM_FMT-1 downto 0);
    signal rssi_update_cnt_1        : std_logic_array5(NUM_FMT-1 downto 0);
    signal rssi_update_cnt_2        : std_logic_array5(NUM_FMT-1 downto 0);
    signal rssi_update_cnt_3        : std_logic_array5(NUM_FMT-1 downto 0);
    signal tssi_0                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal tssi_1                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal tssi_2                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal tssi_3                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal rssi_0                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal rssi_1                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal rssi_2                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal rssi_3                   : std_logic_array32(NUM_FMT-1 downto 0);
    signal scale_factor             : std_logic_array3(5 downto 0);
    signal test_mode                : std_logic_array4(NUM_FMT-1 downto 0);
    signal test_dc_i                : std_logic_vector(15 downto 0);
    signal test_dc_q                : std_logic_vector(15 downto 0);
    signal test_nco                 : std_logic_vector(5 downto 0);

    component BB_MAP_IF is
    port (
--------------------------------------------------------------------------------
-- Common
--------------------------------------------------------------------------------

        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        I_BW_SEL                    : in  std_logic_vector(3 downto 0);        

--------------------------------------------------------------------------------
-- BB_TOP
--------------------------------------------------------------------------------

        I_DL_FSYNC                  :in  std_logic;                        -- 1 clock frame(10ms) sync  
        I_DL_TDD                    :in  std_logic;       
        I_DL_DATA_I                 :in  std_logic_array16(3 downto 0);    -- 16b idata path per one ant path.      
        I_DL_DATA_Q                 :in  std_logic_array16(3 downto 0);    -- 16b qdata path per one ant path.  

        O_UL_FSYNC                  :out std_logic;                        -- 1 clock frame(10ms) sync   
        O_UL_TDD                    :out std_logic;       
        O_UL_VLD                    :out std_logic_vector( 3 downto 0);    -- valid signal for valid data.   
        O_UL_DATA_I                 :out std_logic_array16(3 downto 0);    -- 16b idata path per one ant path.  
        O_UL_DATA_Q                 :out std_logic_array16(3 downto 0);    -- 16b qdata path per one ant path.  

--------------------------------------------------------------------------------
-- FORMATTER
--------------------------------------------------------------------------------

        O_DL_10MS                   : out std_logic;
        O_DL_TDD                    : out std_logic;
        O_DL_SYNC                   : out std_logic;
        O_DL_DATA                   : out std_logic_vector(15 downto 0);

        I_UL_FSYNC                  : in  std_logic;
        I_UL_TDD                    : in  std_logic;
        I_UL_SYNC                   : in  std_logic;
        I_UL_DATA                   : in  std_logic_vector(15 downto 0) 
    
    );
    end component;
    
    signal dl_fmt_10ms              : std_logic_vector(NUM_FMT-1 downto 0);
    signal dl_fmt_bfn               : std_logic_array12(NUM_FMT-1 downto 0);
    signal dl_fmt_tdd               : std_logic_vector(NUM_FMT-1 downto 0);
    signal dl_fmt_sync              : std_logic_vector(NUM_FMT-1 downto 0);
    signal dl_fmt_data              : std_logic_array16(NUM_FMT-1 downto 0);
    signal ul_fmt_10ms              : std_logic_vector(NUM_FMT-1 downto 0);
    signal ul_fmt_tdd               : std_logic_vector(NUM_FMT-1 downto 0);
    signal ul_fmt_sync              : std_logic_vector(NUM_FMT-1 downto 0);
    signal ul_fmt_data              : std_logic_array16(NUM_FMT-1 downto 0);

    signal ul_fsync_out             : std_logic_vector(   UL_CC_NUM-1 downto 0);    -- 1 clock frame(10ms) sync   
    signal ul_tdd_out               : std_logic_vector(   UL_CC_NUM-1 downto 0);       
    signal ul_vld_out               : std_logic_vector( UL_CC_NUM*4-1 downto 0);    -- valid signal for valid data.   
    signal ul_data_i_out            : std_logic_array16(UL_CC_NUM*4-1 downto 0);    -- 16b idata path per one ant path.  
    signal ul_data_q_out            : std_logic_array16(UL_CC_NUM*4-1 downto 0);    -- 16b qdata path per one ant path. 

    signal ul_airtech               : std_logic_array4(NUM_FMT-1 downto 0);
    signal ul_chbw                  : std_logic_array4(NUM_FMT-1 downto 0);    

    signal ul_ddc_sync_in           : std_logic_vector(NUM_FMT-1 downto 0);
    signal ul_ddc_iq_in             : std_logic_array16(NUM_FMT-1 downto 0);

    signal dl_fsync                 : std_logic_vector(   NUM_FMT-1 downto 0);    -- 1 clock frame(10ms) sync  
    signal dl_tdd                   : std_logic_vector(   NUM_FMT-1 downto 0);       
    signal dl_data_i                : std_logic_array16(NUM_FMT*4-1 downto 0);    -- 16b idata path per one ant path.      
    signal dl_data_q                : std_logic_array16(NUM_FMT*4-1 downto 0);    -- 16b qdata path per one ant path.  
    
    
    component BB_MAP_IF_8T is
    port (
        CLK_SYSX8                   : in  std_logic;

        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        O_UL_FSYNC                  :out std_logic_vector( 1 downto 0);    -- 1 clock frame(10ms) sync   
        O_UL_TDD                    :out std_logic_vector( 1 downto 0);       
        O_UL_VLD                    :out std_logic_vector( 7 downto 0);    -- valid signal for valid data.   
        O_UL_DATA_I                 :out std_logic_array16(7 downto 0);    -- 16b idata path per one ant path.  
        O_UL_DATA_Q                 :out std_logic_array16(7 downto 0);    -- 16b qdata path per one ant path.  

        I_UL_FSYNC                  : in  std_logic;
        I_UL_TDD                    : in  std_logic;
        I_UL_SYNC                   : in  std_logic;
        I_UL_DATA                   : in  std_logic_vector(15 downto 0) 
    );
    end component;

    signal nb_ul_fsync_out           : std_logic_vector( 1 downto 0);    -- 1 clock frame(10ms) sync   
    signal nb_ul_tdd_out             : std_logic_vector( 1 downto 0);       
    signal nb_ul_vld_out             : std_logic_vector( 7 downto 0);    -- valid signal for valid data.   
    signal nb_ul_data_i_out          : std_logic_array16(7 downto 0);    -- 16b idata path per one ant path.  
    signal nb_ul_data_q_out          : std_logic_array16(7 downto 0);    -- 16b qdata path per one ant path.  
        
    component FORMATTER is
    generic (
        NUM_ANTENNA                 : natural := 4;
        MAX_DATA_DELAY              : natural := 11264
    );
    port (
        ARESET                      : in  std_logic;

        CLK                         : in  std_logic;

        BW_SEL                      : in  std_logic_vector(3 downto 0);

        PROCESSING_DELAY_DL         : out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        SSB_OFFSET                  : in  std_logic_vector(3 downto 0);

        DL_10MS                     : in  std_logic;
        DL_BFN                      : in  std_logic_vector(11 downto 0);
        DL_TDD                      : in  std_logic;
        DL_SYNC                     : in  std_logic;
        DL_DATA                     : in  std_logic_vector(15 downto 0);

        UL_10MS                     : out std_logic;
        UL_TDD                      : out std_logic;
        UL_SYNC                     : out std_logic;
        UL_DATA                     : out std_logic_vector(15 downto 0);

        DUC_BFN_ABNORMAL            : out std_logic;

        DUC_AIRTECH                 : out std_logic_vector(3 downto 0);
        DUC_CHBW                    : out std_logic_vector(3 downto 0);
        DUC_40MS                    : out std_logic;
        DUC_10MS                    : out std_logic;
        DUC_BFN                     : out std_logic_vector(11 downto 0);
        DUC_TDD                     : out std_logic;
        DUC_SYNC                    : out std_logic;
        DUC_DATA                    : out std_logic_vector(15 downto 0);

        DDC_AIRTECH                 : out std_logic_vector(3 downto 0);
        DDC_CHBW                    : out std_logic_vector(3 downto 0);
        DDC_10MS                    : in  std_logic;
        DDC_TDD                     : in  std_logic;
        DDC_SYNC                    : in  std_logic;
        DDC_DATA                    : in  std_logic_vector(15 downto 0);

        SYNC_DELAY_VALUE            : in  std_logic_vector(31 downto 0);

        TDD_AND_CTRL                : in  std_logic;
        TDD_OR_CTRL                 : in  std_logic;

        DL_DELAY_VALUE              : in  std_logic_vector(31 downto 0);
        UL_DELAY_VALUE              : in  std_logic_vector(31 downto 0);

        ZRHC_BYPASS                 : in  std_logic;
        ZRHC_THRESHOLD              : in  std_logic_vector(31 downto 0);
        ZRHC_OCCUR                  : out std_logic_vector(3 downto 0);

        DL_ON                       : in  std_logic_vector(3 downto 0);
        UL_ON                       : in  std_logic_vector(3 downto 0);

        DL_ATT_0                    : in  std_logic_vector(15 downto 0);
        DL_ATT_1                    : in  std_logic_vector(15 downto 0);
        DL_ATT_2                    : in  std_logic_vector(15 downto 0);
        DL_ATT_3                    : in  std_logic_vector(15 downto 0);

        UL_ATT_0                    : in  std_logic_vector(15 downto 0);
        UL_ATT_1                    : in  std_logic_vector(15 downto 0);
        UL_ATT_2                    : in  std_logic_vector(15 downto 0);
        UL_ATT_3                    : in  std_logic_vector(15 downto 0);

        FBSW_CNT                    : in  std_logic_vector(3 downto 0);
        FBSW_SSB_IND_FLAG           : in  std_logic; 
        FBSW_MEAS_UPDATE            : in  std_logic; 

        TSSI_UPDATE_MODE            : in  std_logic_vector(1 downto 0);
        TSSI_UPDATE_CNT_0           : in  std_logic_vector(4 downto 0);
        TSSI_UPDATE_CNT_1           : in  std_logic_vector(4 downto 0);
        TSSI_UPDATE_CNT_2           : in  std_logic_vector(4 downto 0);
        TSSI_UPDATE_CNT_3           : in  std_logic_vector(4 downto 0);

        RSSI_UPDATE_MODE            : in  std_logic_vector(1 downto 0);
        RSSI_UPDATE_CNT_0           : in  std_logic_vector(4 downto 0);
        RSSI_UPDATE_CNT_1           : in  std_logic_vector(4 downto 0);
        RSSI_UPDATE_CNT_2           : in  std_logic_vector(4 downto 0);
        RSSI_UPDATE_CNT_3           : in  std_logic_vector(4 downto 0);

        TSSI_0                      : out std_logic_vector(31 downto 0);
        TSSI_1                      : out std_logic_vector(31 downto 0);
        TSSI_2                      : out std_logic_vector(31 downto 0);
        TSSI_3                      : out std_logic_vector(31 downto 0);

        RSSI_0                      : out std_logic_vector(31 downto 0);
        RSSI_1                      : out std_logic_vector(31 downto 0);
        RSSI_2                      : out std_logic_vector(31 downto 0);
        RSSI_3                      : out std_logic_vector(31 downto 0);

        TEST_MODE                   : in  std_logic_vector(3 downto 0);
        TP_MEM_PEN    				: in std_logic; -- A/B port enable
        TP_MEM_AWEN   				: in std_logic; -- A port write enable
        TP_MEM_WRADDR 				: in std_logic_vector(14 downto 0);
        TP_MEM_WRDATA 				: in std_logic_vector(31 downto 0); -- 31..16 : Q data, 15..0 : I data

        TEST_DC_I                   : in  std_logic_vector(15 downto 0);
        TEST_DC_Q                   : in  std_logic_vector(15 downto 0);
        TEST_NCO                    : in  std_logic_vector(5 downto 0);

        DUMP_DL_10MS                : out std_logic;
        DUMP_DL_SYNC                : out std_logic;
        DUMP_DL_DATA                : out std_logic_vector(15 downto 0);

        DUMP_UL_10MS                : out std_logic;
        DUMP_UL_SYNC                : out std_logic;
        DUMP_UL_DATA                : out std_logic_vector(15 downto 0)
    );
    end component;

    signal duc_bfn_abnormal         : std_logic_vector(NUM_FMT-1 downto 0);
    signal duc_bfn_normal_max       : std_logic_vector(7 downto 0) := (others => '0');
    signal duc_40ms                 : std_logic_vector(NUM_FMT-1 downto 0);
    signal duc_40ms_max             : std_logic_vector(7 downto 0) := (others => '0');
    signal duc_10ms                 : std_logic_vector(NUM_FMT-1 downto 0);
    signal duc_10ms_max             : std_logic_vector(7 downto 0) := (others => '0');
    signal duc_bfn                  : std_logic_array12(NUM_FMT-1 downto 0);
    signal duc_bfn_max              : std_logic_array12(7 downto 0) := (others => (others => '0'));
    signal duc_tdd                  : std_logic_vector(NUM_FMT-1 downto 0);
    signal duc_tdd_max              : std_logic_vector(7 downto 0) := (others => '0');
    signal ddc_10ms                 : std_logic_vector(NUM_FMT-1 downto 0);
    signal ddc_tdd                  : std_logic_vector(NUM_FMT-1 downto 0);

    signal fbsw_start_trig_buf      : std_logic_vector(2 downto 0) := (others => '0');
    signal fbsw_pwr_msr_udt_buf     : std_logic_vector(2 downto 0) := (others => '0');

    signal fbsw_auto_mode_done      : std_logic := '1';
    signal fbsw_measure_done        : std_logic := '0';
    signal fbsw_cnt_buf             : std_logic_vector(6 downto 0) := (others => '0');
    signal fbsw_counter             : std_logic_vector(6 downto 0) := (others => '0');

    signal dump_dl_10ms             : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_dl_sync             : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_dl_sync_sh          : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_dl_data             : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal dump_ul_10ms             : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_ul_sync             : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_ul_data             : std_logic_array16(7 downto 0) := (others => (others => '0'));

    signal dump_sel_dl_10ms         : std_logic := '0';
    signal dump_sel_dl_sync         : std_logic_vector(7 downto 0) := (others => '0');
    signal dump_sel_dl_data_i       : std_logic_vector(15 downto 0) := (others => '0');
    signal dump_sel_dl_data_q       : std_logic_vector(15 downto 0) := (others => '0');
    signal dump_sel_ul_10ms         : std_logic := '0';
    signal dump_sel_ul_sync         : std_logic_vector(15 downto 0) := (others => '0');
    signal dump_sel_ul_data_i       : std_logic_vector(15 downto 0) := (others => '0');
    signal dump_sel_ul_data_q       : std_logic_vector(15 downto 0) := (others => '0');

    signal duc_airtech              : std_logic_array4(NUM_FMT-1 downto 0);
    signal duc_chbw                 : std_logic_array4(NUM_FMT-1 downto 0);
    signal duc_sync                 : std_logic_vector(NUM_FMT-1 downto 0);
    signal duc_data                 : std_logic_array16(NUM_FMT-1 downto 0);           

    signal in_sync_count            : std_logic_vector(10 downto 0) := (others => '0');
    signal sync_check               : std_logic_vector(10 downto 0) := (others => '0');
    signal dl_tp_10ms    : std_logic_vector(NUM_FMT-1 downto 0);
    signal dl_tp_tdd     : std_logic_vector(NUM_FMT-1 downto 0);
    signal dl_tp_sync    : std_logic_vector(NUM_FMT-1 downto 0);
    signal dl_tp_data    : std_logic_array16(NUM_FMT-1 downto 0);
    signal tp_mem_pen    : std_logic; -- A/B port enable
    signal tp_mem_awen   : std_logic; -- A port write enable
    signal tp_mem_wraddr : std_logic_vector(14 downto 0);
    signal tp_mem_wrdata : std_logic_vector(31 downto 0); -- 31..16 : Q data, 15..0 : I data
    signal tp_mem_10ms   : std_logic;
    signal tp_mem_tdd    : std_logic;
    signal tp_mem_sync   : std_logic;
    signal tp_mem_data   : std_logic_vector(15 downto 0);
    signal tp_en         : std_logic;
    component FORMATTER_8T is
    port (

        ARESET                      : in  std_logic;
        CLK                         : in  std_logic;

        PROCESSING_DELAY_UL         : out std_logic_vector(23 downto 0);

        UL_10MS                     : out std_logic;
        UL_TDD                      : out std_logic;
        UL_SYNC                     : out std_logic;
        UL_DATA                     : out std_logic_vector(15 downto 0);

        DDC_10MS                    : in  std_logic;
        DDC_TDD                     : in  std_logic;
        DDC_SYNC                    : in  std_logic;
        DDC_DATA                    : in  std_logic_vector(15 downto 0);

        UL_ON                       : in  std_logic_array4(1 downto 0);

        UL_ATT_0                    : in  std_logic_array16(1 downto 0); --vector(15 downto 0);
        UL_ATT_1                    : in  std_logic_array16(1 downto 0); --vector(15 downto 0);
        UL_ATT_2                    : in  std_logic_array16(1 downto 0); --vector(15 downto 0);
        UL_ATT_3                    : in  std_logic_array16(1 downto 0); --vector(15 downto 0);

        RSSI_0                      : out std_logic_array32(1 downto 0);
        RSSI_1                      : out std_logic_array32(1 downto 0);
        RSSI_2                      : out std_logic_array32(1 downto 0);
        RSSI_3                      : out std_logic_array32(1 downto 0);

        DUMP_UL_10MS                : out std_logic;
        DUMP_UL_SYNC                : out std_logic;
        DUMP_UL_DATA                : out std_logic_vector(15 downto 0)
    );
    end component;

    signal nb_ul_fmt_10ms            : std_logic;
    signal nb_ul_fmt_tdd             : std_logic;
    signal nb_ul_fmt_sync            : std_logic;
    signal nb_ul_fmt_data            : std_logic_vector(15 downto 0);

    signal nb_dump_ul_10ms           : std_logic;
    signal nb_dump_ul_sync           : std_logic;
    signal nb_dump_ul_data           : std_logic_vector(15 downto 0);

--    component PIM_IF is
--    generic (
--        PIM_NUM                     : natural := 2
--    );
--    port (
--        CLK_SYSX8                   : in  std_logic;

--        PIM_SBIF_RX_ENB_IN          : in  std_logic_vector(PIM_NUM-1 downto 0);
--        PIM_SBIF_RX_I_IN            : in  std_logic_array16(PIM_NUM-1 downto 0);
--        PIM_SBIF_RX_Q_IN            : in  std_logic_array16(PIM_NUM-1 downto 0);

--        PIM_SBIF_TX_VLD_OUT         : out std_logic_vector(PIM_NUM-1 downto 0);
--        PIM_SBIF_TX_I_OUT           : out std_logic_array16(PIM_NUM-1 downto 0);
--        PIM_SBIF_TX_Q_OUT           : out std_logic_array16(PIM_NUM-1 downto 0);

--        PIM_SBIF_RX_1PPS            : in  std_logic;
--        PIM_SBIF_RX_BFN_STRB        : in  std_logic;
--        PIM_SBIF_RX_BFN             : in  std_logic_vector(10 downto 0);

--        PIM_SBIF_TX_SYNC            : out std_logic;
--        PIM_SBIF_TX_1PPS            : out std_logic;
--        PIM_SBIF_TX_BFN_STRB        : out std_logic;
--        PIM_SBIF_TX_BFN             : out std_logic_vector(10 downto 0);

--        PIM_SYNC_IN                 : in  std_logic_vector(PIM_NUM-1 downto 0);
--        PIM_I_IN                    : in  std_logic_array15(PIM_NUM-1 downto 0);
--        PIM_Q_IN                    : in  std_logic_array15(PIM_NUM-1 downto 0);

--        PIM_SYNC_OUT                : out std_logic_vector(PIM_NUM-1 downto 0);
--        PIM_I_OUT                   : out std_logic_array15(PIM_NUM-1 downto 0);
--        PIM_Q_OUT                   : out std_logic_array15(PIM_NUM-1 downto 0)
--    );
--    end component;

begin

--------------------------------------------------------------------------------
-- Port mapping
--------------------------------------------------------------------------------

    u_UL_FMT : for i in NUM_FMT-1 downto 0 generate
    ddc_10ms(i) <= UL_BFN_STRB_IN;
    ddc_tdd(i)  <= UL_TDD_IN;

    dl_on_max(i)            <= dl_on(i);
    duc_bfn_normal_max(i)   <= not duc_bfn_abnormal(i);
    duc_40ms_max(i)         <= duc_40ms(i);
    duc_10ms_max(i)         <= duc_10ms(i);
    duc_bfn_max(i)          <= duc_bfn(i);
    duc_tdd_max(i)          <= duc_tdd(i);
    end generate;

    DL_BFN_OK       <= duc_bfn_normal_max(0) when dl_on_max(0) /= 0 else
                       duc_bfn_normal_max(1) when dl_on_max(1) /= 0 else
                       duc_bfn_normal_max(2) when dl_on_max(2) /= 0 else
                       duc_bfn_normal_max(3) when dl_on_max(3) /= 0 else
                       duc_bfn_normal_max(4) when dl_on_max(4) /= 0 else
                       duc_bfn_normal_max(5) when dl_on_max(5) /= 0 else
                       duc_bfn_normal_max(6) when dl_on_max(6) /= 0 else
                       duc_bfn_normal_max(7) when dl_on_max(7) /= 0 else
                       duc_bfn_normal_max(0);

    DL_TDD_OUT      <= duc_tdd_max(0) when dl_on_max(0) /= 0 else
                       duc_tdd_max(1) when dl_on_max(1) /= 0 else
                       duc_tdd_max(2) when dl_on_max(2) /= 0 else
                       duc_tdd_max(3) when dl_on_max(3) /= 0 else
                       duc_tdd_max(4) when dl_on_max(4) /= 0 else
                       duc_tdd_max(5) when dl_on_max(5) /= 0 else
                       duc_tdd_max(6) when dl_on_max(6) /= 0 else
                       duc_tdd_max(7) when dl_on_max(7) /= 0 else
                       duc_tdd_max(0);

    DL_40MS_OUT     <= duc_40ms_max(0) when dl_on_max(0) /= 0 else
                       duc_40ms_max(1) when dl_on_max(1) /= 0 else
                       duc_40ms_max(2) when dl_on_max(2) /= 0 else
                       duc_40ms_max(3) when dl_on_max(3) /= 0 else
                       duc_40ms_max(4) when dl_on_max(4) /= 0 else
                       duc_40ms_max(5) when dl_on_max(5) /= 0 else
                       duc_40ms_max(6) when dl_on_max(6) /= 0 else
                       duc_40ms_max(7) when dl_on_max(7) /= 0 else
                       duc_40ms_max(0);

    DL_BFN_STRB_OUT <= duc_10ms_max(0) when dl_on_max(0) /= 0 else
                       duc_10ms_max(1) when dl_on_max(1) /= 0 else
                       duc_10ms_max(2) when dl_on_max(2) /= 0 else
                       duc_10ms_max(3) when dl_on_max(3) /= 0 else
                       duc_10ms_max(4) when dl_on_max(4) /= 0 else
                       duc_10ms_max(5) when dl_on_max(5) /= 0 else
                       duc_10ms_max(6) when dl_on_max(6) /= 0 else
                       duc_10ms_max(7) when dl_on_max(7) /= 0 else
                       duc_10ms_max(0);

    DL_BFN_OUT      <= duc_bfn_max(0) when dl_on_max(0) /= 0 else
                       duc_bfn_max(1) when dl_on_max(1) /= 0 else
                       duc_bfn_max(2) when dl_on_max(2) /= 0 else
                       duc_bfn_max(3) when dl_on_max(3) /= 0 else
                       duc_bfn_max(4) when dl_on_max(4) /= 0 else
                       duc_bfn_max(5) when dl_on_max(5) /= 0 else
                       duc_bfn_max(6) when dl_on_max(6) /= 0 else
                       duc_bfn_max(7) when dl_on_max(7) /= 0 else
                       duc_bfn_max(0);

    O_UL_FSYNC (1 downto 0) <= ul_fsync_out (1 downto 0); 
    O_UL_TDD   (1 downto 0) <= ul_tdd_out   (1 downto 0); 
    O_UL_VLD   (7 downto 0) <= ul_vld_out   (7 downto 0); 
    O_UL_DATA_I(7 downto 0) <= ul_data_i_out(7 downto 0); 
    O_UL_DATA_Q(7 downto 0) <= ul_data_q_out(7 downto 0); 

--    -- NB_IoT 4T2CC
--    O_UL_FSYNC ( 3 downto 2) <= nb_ul_fsync_out ; 
--    O_UL_TDD   ( 3 downto 2) <= nb_ul_tdd_out   ; 
--    O_UL_VLD   (15 downto 8) <= nb_ul_vld_out   ; 
--    O_UL_DATA_I(15 downto 8) <= nb_ul_data_i_out; 
--    O_UL_DATA_Q(15 downto 8) <= nb_ul_data_q_out; 


--------------------------------------------------------------------------------
-- Dump
--------------------------------------------------------------------------------

    -- Path selection (DL)
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            dump_dl_sync_sh <= dump_dl_sync;
            for i in 7 downto 0 loop
            if (dump_sel(4 downto 2) = i) then
                dump_sel_dl_10ms   <= dump_dl_10ms(i);
                dump_sel_dl_sync   <= dump_sel_dl_sync(6 downto 0) & dump_dl_sync_sh(i);
                dump_sel_dl_data_i <= dump_sel_dl_data_q;
                dump_sel_dl_data_q <= dump_dl_data(i);
            end if;
            end loop;
        end if;
    end process;

    -- Path selection (UL)
--    process (CLK_SYSX8)
--    begin
--        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
--            for i in 7 downto 0 loop
--            if (dump_sel(4 downto 2) = i) then
--                dump_sel_ul_10ms   <= dump_ul_10ms(i);
--                dump_sel_ul_sync   <= dump_sel_ul_sync(6 downto 0) & dump_ul_sync(i);
--                dump_sel_ul_data_i <= dump_sel_ul_data_q;
--                dump_sel_ul_data_q <= dump_ul_data(i);
--            end if;
--            end loop;
--        end if;
--    end process;

    -- NB-IoT Path selection (UL)
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (dump_sel(15) = '1') then
                dump_sel_ul_10ms   <= nb_dump_ul_10ms;
                dump_sel_ul_sync   <= dump_sel_ul_sync(14 downto 0) & nb_dump_ul_sync;
                dump_sel_ul_data_i <= dump_sel_ul_data_q;
                dump_sel_ul_data_q <= nb_dump_ul_data;
            else
                for i in 7 downto 0 loop
                if (dump_sel(4 downto 2) = i) then
                    dump_sel_ul_10ms   <= dump_ul_10ms(i);
                    dump_sel_ul_sync   <= dump_sel_ul_sync(14 downto 0) & dump_ul_sync(i);
                    dump_sel_ul_data_i <= dump_sel_ul_data_q;
                    dump_sel_ul_data_q <= dump_ul_data(i);
                end if;
                end loop;
            end if;
        end if;
    end process;

    -- DL/UL selection
--    process (CLK_SYSX8)
--    begin
--        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
--            if (dump_sel(6) = '0') then
--                DUMP_BFN_STRB_OUT(0) <= dump_sel_dl_10ms;
--                DUMP_DATA_OUT(0)     <= dump_sel_dl_data_i & dump_sel_dl_data_q;
--                for i in 3 downto 0 loop
--                if (dump_sel(1 downto 0) = i) then
--                    DUMP_DVLD_OUT(0)     <= dump_sel_dl_sync(i*2+1);
--                end if;
--                end loop;
--            else
--                DUMP_BFN_STRB_OUT(0) <= dump_sel_ul_10ms;
--                DUMP_DATA_OUT(0)     <= dump_sel_ul_data_i & dump_sel_ul_data_q;
--                for i in 3 downto 0 loop
--                if (dump_sel(1 downto 0) = i) then
--                    DUMP_DVLD_OUT(0)     <= dump_sel_ul_sync(i*2+1);
--                end if;
--                end loop;
--            end if;
--        end if;
--    end process;

    -- add for nb-iot dump path 
    -- DL/UL selection
    process (CLK_SYSX8)
    begin
        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
            if (dump_sel(15) = '1') then  -- nb-iot
                DUMP_BFN_STRB_OUT(0) <= dump_sel_ul_10ms;                
                DUMP_DATA_OUT(0)     <= dump_sel_ul_data_i & dump_sel_ul_data_q;
                for i in 7 downto 0 loop 
                if (dump_sel(11 downto 8) = i) then                
                    DUMP_DVLD_OUT(0)     <= dump_sel_ul_sync(i*2+1);
                end if;
                end loop;
            else
                if (dump_sel(6) = '0') then
                    DUMP_BFN_STRB_OUT(0) <= dump_sel_dl_10ms;
                    DUMP_DATA_OUT(0)     <= dump_sel_dl_data_i & dump_sel_dl_data_q;
                    for i in 3 downto 0 loop
                    if (dump_sel(1 downto 0) = i) then
                        DUMP_DVLD_OUT(0)     <= dump_sel_dl_sync(i*2+1);
                    end if;
                    end loop;
                else
                    DUMP_BFN_STRB_OUT(0) <= dump_sel_ul_10ms;
                    DUMP_DATA_OUT(0)     <= dump_sel_ul_data_i & dump_sel_ul_data_q;
                        for i in 3 downto 0 loop
                        if (dump_sel(1 downto 0) = i) then
                            DUMP_DVLD_OUT(0)     <= dump_sel_ul_sync(i*2+1);
                        end if;
                        end loop;
                end if;
            end if;
        end if;
    end process;

    DUMP_BFN_STRB_OUT(1) <= '0';
    DUMP_DATA_OUT(1)     <= (others => '0');
    DUMP_DVLD_OUT(1)     <= '0';

    -- add sync counter for debug
--    process (CLK_SYSX8)
--    begin
--        if (CLK_SYSX8'event and CLK_SYSX8 = '1') then
--            if (UL_SYNC_IN(2) = '1') then
--                in_sync_count <= (others => '0');
--            else
--                in_sync_count <= in_sync_count + 1;
--            end if;
--            if (in_sync_count = 127) then
--                sync_check <= sync_check + 1;
--            end if;
--        end if;
--    end process;

    G_UL_PORT : for i in 0 to UL_BBIQARY_NUM-1 generate 

    UL_AIRTECH_OUT(i) <= ul_airtech(i);     
    UL_CHBW_OUT(i)    <= ul_chbw(i);    

    ul_ddc_sync_in(i) <= UL_SYNC_IN(i); 
    ul_ddc_iq_in(i)   <= UL_IQ_IN(i); 

    end generate;

    G_UL_DUMMY : for i in UL_BBIQARY_NUM to NUM_FMT - 1 generate 

        ul_ddc_sync_in(i) <= '0';
        ul_ddc_iq_in(i)   <= (others => '0');

    end generate;

    G_DL_PORT : for i in 0 to DL_CC_NUM-1 generate

       dl_fsync (i)                 <= I_DL_FSYNC (i)               ; 
       dl_tdd   (i)                 <= I_DL_TDD   (i)               ; 
       dl_data_i(i*4+3 downto i*4)  <= I_DL_DATA_I(i*4+3 downto i*4); 
       dl_data_q(i*4+3 downto i*4)  <= I_DL_DATA_Q(i*4+3 downto i*4); 

       DL_AIRTECH_OUT(i) <= duc_airtech(i);
       DL_CHBW_OUT(i)    <= duc_chbw   (i);
       DL_SYNC_OUT(i)    <= duc_sync   (i);
       DL_IQ_OUT(i)      <= duc_data   (i);       

   end generate;

   G_DL_DUMMY : for i in DL_CC_NUM to NUM_FMT-1 generate

       dl_fsync (i)                 <= '0'; 
       dl_tdd   (i)                 <= '0'; 
       dl_data_i(i*4+3 downto i*4)  <= (others => (others => '0')); 
       dl_data_q(i*4+3 downto i*4)  <= (others => (others => '0')); 

   end generate;


--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_CPUIF : CPUIF_BBCTRL
    generic map(
        OFFSET                      => x"4"                                    ,--: std_logic_vector(3 downto 0) := x"4";
        NUM_CPRI                    => NUM_CPRI                                ,--: natural := 8;
        NUM_MAP                     => NUM_MAP                                 ,--: natural := 8;
        NUM_FMT                     => NUM_FMT                                  --: natural := 8
    )
    port map(
        CLK_AUX                     => CLK_CPUIF                               ,--: in  std_logic;
        CLK_SYSX8                   => CLK_SYSX8                               ,--: in  std_logic;

        RESET                       => RST_CPUIF                               ,--: in  std_logic;

        DL_CPRI_IF_DELAY            => (others => (others => '0'))             , --dl_cpri_if_delay     ,--: in  std_logic_array24(NUM_CPRI-1 downto 0);
        DL_CPRI_SWITCH_DELAY        => (others => '0')                         , --dl_cpri_switch_delay ,--: in  std_logic_vector(23 downto 0);
        DL_MAPPER_DELAY             => (others => (others => '0'))             , --dl_mapper_delay      ,--: in  std_logic_array24(NUM_MAP-1 downto 0);
        DL_MAP_SWITCH_DELAY         => (others => '0')                         , --dl_map_switch_delay  ,--: in  std_logic_vector(23 downto 0);
        DL_MAP_IF_DELAY             => dl_map_if_delay                         ,--: in  std_logic_array24(NUM_FMT-1 downto 0);
        DL_FORMATTER_DELAY          => dl_formatter_delay                      ,--: in  std_logic_array24(NUM_FMT-1 downto 0);

        UL_CPRI_IF_DELAY            => (others => (others => '0'))             , --ul_cpri_if_delay     ,--: in  std_logic_array24(NUM_CPRI-1 downto 0);
        UL_CPRI_SWITCH_DELAY        => (others => '0')                         , --ul_cpri_switch_delay ,--: in  std_logic_vector(23 downto 0);
        UL_MAPPER_DELAY             => (others => (others => '0'))             , --ul_mapper_delay      ,--: in  std_logic_array24(NUM_MAP-1 downto 0);
        UL_MAP_SWITCH_DELAY         => (others => '0')                         , --ul_map_switch_delay  ,--: in  std_logic_vector(23 downto 0);
        UL_MAP_IF_DELAY             => ul_map_if_delay                         ,--: in  std_logic_array24(NUM_FMT-1 downto 0);
        UL_FORMATTER_DELAY          => ul_formatter_delay                      ,--: in  std_logic_array24(NUM_FMT-1 downto 0);

        DUMP_EN                     => dump_en                                 ,--: out std_logic;
        DUMP_SEL                    => dump_sel                                ,--: out std_logic_vector(7 downto 0);

        DBG_SYNC_CNT                => in_sync_count                           ,--: in  std_logic_vector(10 downto 0);
        DBG_SYNC_CHK                => sync_check                              ,--: in  std_logic_vector(10 downto 0);
 
        BW_SEL                      => bw_sel                                  ,--: out std_logic_array4(NUM_FMT-1 downto 0);

        DL_MAP_WR_EN                => dl_map_wr_en                            ,--: out std_logic_vector(NUM_MAP-1 downto 0);
        DL_MAP_WR_ADDR              => dl_map_wr_addr                          ,--: out std_logic_vector(4 downto 0);
        DL_MAP_WR_DATA              => dl_map_wr_data                          ,--: out std_logic_vector(6 downto 0);
        DL_MAP_RD_DATA              => dl_map_rd_data                          ,--: in  std_logic_array7(NUM_MAP-1 downto 0);

        UL_MAP_WR_EN                => ul_map_wr_en                            ,--: out std_logic_vector(NUM_MAP-1 downto 0);
        UL_MAP_WR_ADDR              => ul_map_wr_addr                          ,--: out std_logic_vector(5 downto 0);
        UL_MAP_WR_DATA              => ul_map_wr_data                          ,--: out std_logic_vector(6 downto 0);
        UL_MAP_RD_DATA              => ul_map_rd_data                          ,--: in  std_logic_array7(NUM_MAP-1 downto 0);

        MAP_CPRI                    => map_cpri                                ,--: out std_logic_array8(NUM_MAP-1 downto 0);

        MAPPER_UL_MAP               => mapper_ul_map                           ,--: out std_logic_array16(NUM_MAP-1 downto 0);
        FORMATTER_DL_MAP            => formatter_dl_map                        ,--: out std_logic_array16(NUM_FMT-1 downto 0);
        CASCADE_UL_SUM              => cascade_ul_sum                          ,--: out std_logic_array16(2 downto 0);

        SYNC_DELAY_VALUE            => sync_delay_value                        ,--: out std_logic_array32(NUM_FMT-1 downto 0);

        DL_DELAY_VALUE              => dl_delay_value                          ,--: out std_logic_array32(NUM_FMT-1 downto 0);
        UL_DELAY_VALUE              => ul_delay_value                          ,--: out std_logic_array32(NUM_FMT-1 downto 0);

        ZRHC_BYPASS                 => zrhc_bypass                             ,--: out std_logic_vector(NUM_FMT-1 downto 0);
        ZRHC_THRESHOLD              => zrhc_threshold                          ,--: out std_logic_array32(NUM_FMT-1 downto 0);
        ZRHC_OCCUR                  => zrhc_occur                              ,--: in  std_logic_array4(NUM_FMT-1 downto 0);

        DL_ON                       => dl_on                                   ,--: out std_logic_array4(NUM_FMT-1 downto 0);
        UL_ON                       => ul_on                                   ,--: out std_logic_array4(NUM_FMT-1 downto 0);

        DL_ATT_0                    => dl_att_0                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);
        DL_ATT_1                    => dl_att_1                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);
        DL_ATT_2                    => dl_att_2                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);
        DL_ATT_3                    => dl_att_3                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);

        UL_ATT_0                    => ul_att_0                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);
        UL_ATT_1                    => ul_att_1                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);
        UL_ATT_2                    => ul_att_2                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);
        UL_ATT_3                    => ul_att_3                                ,--: out std_logic_array16(NUM_FMT-1 downto 0);

        TSSI_UPDATE_MODE            => tssi_update_mode                        ,--: out std_logic_vector(1 downto 0);
        TSSI_UPDATE_CNT_0           => tssi_update_cnt_0                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
        TSSI_UPDATE_CNT_1           => tssi_update_cnt_1                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
        TSSI_UPDATE_CNT_2           => tssi_update_cnt_2                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
        TSSI_UPDATE_CNT_3           => tssi_update_cnt_3                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);

        RSSI_UPDATE_MODE            => rssi_update_mode                        ,--: out std_logic_vector(1 downto 0);
        RSSI_UPDATE_CNT_0           => rssi_update_cnt_0                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
        RSSI_UPDATE_CNT_1           => rssi_update_cnt_1                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
        RSSI_UPDATE_CNT_2           => rssi_update_cnt_2                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);
        RSSI_UPDATE_CNT_3           => rssi_update_cnt_3                       ,--: out std_logic_array5(NUM_FMT-1 downto 0);

        TSSI_0                      => tssi_0                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
        TSSI_1                      => tssi_1                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
        TSSI_2                      => tssi_2                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
        TSSI_3                      => tssi_3                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);

        RSSI_0                      => rssi_0                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
        RSSI_1                      => rssi_1                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
        RSSI_2                      => rssi_2                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);
        RSSI_3                      => rssi_3                                  ,--: in  std_logic_array32(NUM_FMT-1 downto 0);

        SCALE_FACTOR                => scale_factor                            ,--: out std_logic_array3(5 downto 0);

        TEST_MODE                   => test_mode                               ,--: out std_logic_array4(NUM_FMT-1 downto 0);
        TP_EN                       => tp_en                                   ,
	   TP_MEM_PEN                  => tp_mem_pen,
	   TP_MEM_AWEN                 => tp_mem_awen,
	   TP_MEM_WRADDR               => tp_mem_wraddr,
	   TP_MEM_WRDATA               => tp_mem_wrdata,

        TEST_DC_I                   => test_dc_i                               ,--: out std_logic_vector(15 downto 0);
        TEST_DC_Q                   => test_dc_q                               ,--: out std_logic_vector(15 downto 0);
        TEST_NCO                    => test_nco                                ,--: out std_logic_vector(5 downto 0);

        WREN_CPUIF_IN               => WREN_CPUIF_IN                           ,--: in  std_logic;
        RDEN_CPUIF_IN               => RDEN_CPUIF_IN                           ,--: in  std_logic;
        ADDR_CPUIF_IN               => ADDR_CPUIF_IN                           ,--: in  std_logic_vector(15 downto 0);    
        WDATA_CPUIF_IN              => WDATA_CPUIF_IN                          ,--: in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             => RDATA_CPUIF_OUT                         ,--: out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             => RDVAL_CPUIF_OUT                          --: out std_logic
    );

    u_FMT_GEN : for i in 1 downto 0 generate
        
    U_BB_MAP_IF : BB_MAP_IF
    port map(
-- Common

        CLK_SYSX8                   => CLK_SYSX8                                ,--: in  std_logic;
                                                          
        PROCESSING_DELAY_DL         => dl_map_if_delay(i)                       ,--: out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         => ul_map_if_delay(i)                       ,--: out std_logic_vector(23 downto 0);

        I_BW_SEL                    => bw_sel(i)                                ,--: in  std_logic_vector(3 downto 0);        

-- BB_TOP

        I_DL_FSYNC                  => dl_fsync  (i)                            ,--:in  std_logic;    -- 1 clock frame(10ms) sync  
        I_DL_TDD                    => dl_tdd    (i)                            ,--:in  std_logic;       
        I_DL_DATA_I                 => dl_data_i (i*4+3 downto i*4)             ,--:in  std_logic_array16(3 downto 0);    -- 16b idata path per one ant path.      
        I_DL_DATA_Q                 => dl_data_q (i*4+3 downto i*4)             ,--:in  std_logic_array16(3 downto 0);    -- 16b qdata path per one ant path.  

        O_UL_FSYNC                  => ul_fsync_out  (i)                        ,--:out std_logic;    -- 1 clock frame(10ms) sync   
        O_UL_TDD                    => ul_tdd_out    (i)                        ,--:out std_logic;       
        O_UL_VLD                    => ul_vld_out    (i*4+3 downto i*4)         ,--:out std_logic_vector( 3 downto 0);    -- valid signal for valid data.   
        O_UL_DATA_I                 => ul_data_i_out (i*4+3 downto i*4)         ,--:out std_logic_array16(3 downto 0);    -- 16b idata path per one ant path.  
        O_UL_DATA_Q                 => ul_data_q_out (i*4+3 downto i*4)         ,--:out std_logic_array16(3 downto 0);    -- 16b qdata path per one ant path.  

-- FORMATTER

        O_DL_10MS                   => dl_fmt_10ms(i)                           ,--: out std_logic;
        O_DL_TDD                    => dl_fmt_tdd(i)                            ,--: out std_logic;
        O_DL_SYNC                   => dl_fmt_sync(i)                           ,--: out std_logic;
        O_DL_DATA                   => dl_fmt_data(i)                           ,--: out std_logic_vector(15 downto 0);

        I_UL_FSYNC                  => ul_fmt_10ms(i)                           ,--: in  std_logic;
        I_UL_TDD                    => ul_fmt_tdd(i)                            ,--: in  std_logic;
        I_UL_SYNC                   => ul_fmt_sync(i)                           ,--: in  std_logic;
        I_UL_DATA                   => ul_fmt_data(i)                            --: in  std_logic_vector(15 downto 0) 
    );
    
    u_FORMATTER : FORMATTER
    generic map(
        NUM_ANTENNA                 => 4                                       ,--: natural := 4;
        MAX_DATA_DELAY              => 4096                                     --: natural := 11264
    )
    port map(
        ARESET                      => RST_BBCTRL                              ,--: in  std_logic;
        CLK                         => CLK_SYSX8                               ,--: in  std_logic;

        BW_SEL                      => bw_sel(i)                               ,--: in  std_logic_vector(3 downto 0);

        PROCESSING_DELAY_DL         => dl_formatter_delay(i)                   ,--: out std_logic_vector(23 downto 0);
        PROCESSING_DELAY_UL         => ul_formatter_delay(i)                   ,--: out std_logic_vector(23 downto 0);

        SSB_OFFSET                  => x"0" , --SSB_OFFSET                              ,--: in  std_logic_vector(3 downto 0);

        DL_10MS                     => dl_fmt_10ms(i)                          ,--: in  std_logic;
        DL_BFN                      => dl_fmt_bfn(i)                           ,--: in  std_logic_array12(NUM_FMT-1 downto 0);
        DL_TDD                      => dl_fmt_tdd(i)                           ,--: in  std_logic;
        DL_SYNC                     => dl_fmt_sync(i)                          ,--: in  std_logic;
        DL_DATA                     => dl_fmt_data(i)                          ,--: in  std_logic_vector(15 downto 0);

        UL_10MS                     => ul_fmt_10ms(i)                          ,--: out std_logic;
        UL_TDD                      => ul_fmt_tdd(i)                           ,--: out std_logic;
        UL_SYNC                     => ul_fmt_sync(i)                          ,--: out std_logic;
        UL_DATA                     => ul_fmt_data(i)                          ,--: out std_logic_vector(15 downto 0);

        DUC_BFN_ABNORMAL            => duc_bfn_abnormal(i)                     ,--: out std_logic;

        DUC_AIRTECH                 => duc_airtech(i)                          ,--: out std_logic_vector(3 downto 0);
        DUC_CHBW                    => duc_chbw(i)                             ,--: out std_logic_vector(3 downto 0);
        DUC_40MS                    => duc_40ms(i)                             ,--: out std_logic;
        DUC_10MS                    => duc_10ms(i)                             ,--: out std_logic;
        DUC_BFN                     => duc_bfn(i)                              ,--: out std_logic_vector(11 downto 0);
        DUC_TDD                     => duc_tdd(i)                              ,--: out std_logic;
        DUC_SYNC                    => duc_sync(i)                             ,--: out std_logic;
        DUC_DATA                    => duc_data(i)                             ,--: out std_logic_vector(15 downto 0);

        DDC_AIRTECH                 => ul_airtech(i)                           ,--: out std_logic_vector(3 downto 0);
        DDC_CHBW                    => ul_chbw(i)                              ,--: out std_logic_vector(3 downto 0);
        DDC_10MS                    => ddc_10ms(i)                             ,--: in  std_logic;
        DDC_TDD                     => ddc_tdd(i)                              ,--: in  std_logic;
        DDC_SYNC                    => ul_ddc_sync_in(i)                       ,--: in  std_logic;
        DDC_DATA                    => ul_ddc_iq_in(i)                         ,--: in  std_logic_vector(15 downto 0);

        SYNC_DELAY_VALUE            => sync_delay_value(i)                     ,--: in  std_logic_vector(31 downto 0);

        TDD_AND_CTRL                => '0' , --TDD_AND_CTRL_IN                         ,--: in  std_logic;
        TDD_OR_CTRL                 => '0' , --TDD_OR_CTRL_IN                          ,--: in  std_logic;

        DL_DELAY_VALUE              => dl_delay_value(i)                       ,--: in  std_logic_vector(31 downto 0);
        UL_DELAY_VALUE              => ul_delay_value(i)                       ,--: in  std_logic_vector(31 downto 0);

        ZRHC_BYPASS                 => zrhc_bypass(i)                          ,--: in  std_logic;
        ZRHC_THRESHOLD              => zrhc_threshold(i)                       ,--: in  std_logic_vector(31 downto 0);
        ZRHC_OCCUR                  => zrhc_occur(i)                           ,--: out std_logic_vector(3 downto 0);

        DL_ON                       => dl_on(i)                                ,--: in  std_logic_vector(3 downto 0);
        UL_ON                       => ul_on(i)                                ,--: in  std_logic_vector(3 downto 0);

        DL_ATT_0                    => dl_att_0(i)                             ,--: in  std_logic_vector(15 downto 0);
        DL_ATT_1                    => dl_att_1(i)                             ,--: in  std_logic_vector(15 downto 0);
        DL_ATT_2                    => dl_att_2(i)                             ,--: in  std_logic_vector(15 downto 0);
        DL_ATT_3                    => dl_att_3(i)                             ,--: in  std_logic_vector(15 downto 0);

        UL_ATT_0                    => ul_att_0(i)                             ,--: in  std_logic_vector(15 downto 0);
        UL_ATT_1                    => ul_att_1(i)                             ,--: in  std_logic_vector(15 downto 0);
        UL_ATT_2                    => ul_att_2(i)                             ,--: in  std_logic_vector(15 downto 0);
        UL_ATT_3                    => ul_att_3(i)                             ,--: in  std_logic_vector(15 downto 0);

        FBSW_CNT                    => FBSW_CNT                                ,--: in  std_logic_vector(3 downto 0);
        FBSW_SSB_IND_FLAG           => FBSW_SSB_IND_FLAG                       ,--: in  std_logic; 
        FBSW_MEAS_UPDATE            => FBSW_MEAS_UPDATE                        ,--: in  std_logic; 

        TSSI_UPDATE_MODE            => tssi_update_mode                        ,--: in  std_logic_vector(1 downto 0);
        TSSI_UPDATE_CNT_0           => tssi_update_cnt_0(i)                    ,--: in  std_logic_vector(4 downto 0);
        TSSI_UPDATE_CNT_1           => tssi_update_cnt_1(i)                    ,--: in  std_logic_vector(4 downto 0);
        TSSI_UPDATE_CNT_2           => tssi_update_cnt_2(i)                    ,--: in  std_logic_vector(4 downto 0);
        TSSI_UPDATE_CNT_3           => tssi_update_cnt_3(i)                    ,--: in  std_logic_vector(4 downto 0);

        RSSI_UPDATE_MODE            => rssi_update_mode                        ,--: in  std_logic_vector(1 downto 0);
        RSSI_UPDATE_CNT_0           => rssi_update_cnt_0(i)                    ,--: in  std_logic_vector(4 downto 0);
        RSSI_UPDATE_CNT_1           => rssi_update_cnt_1(i)                    ,--: in  std_logic_vector(4 downto 0);
        RSSI_UPDATE_CNT_2           => rssi_update_cnt_2(i)                    ,--: in  std_logic_vector(4 downto 0);
        RSSI_UPDATE_CNT_3           => rssi_update_cnt_3(i)                    ,--: in  std_logic_vector(4 downto 0);

        TSSI_0                      => tssi_0(i)                               ,--: out std_logic_vector(31 downto 0);
        TSSI_1                      => tssi_1(i)                               ,--: out std_logic_vector(31 downto 0);
        TSSI_2                      => tssi_2(i)                               ,--: out std_logic_vector(31 downto 0);
        TSSI_3                      => tssi_3(i)                               ,--: out std_logic_vector(31 downto 0);

        RSSI_0                      => rssi_0(i)                               ,--: out std_logic_vector(31 downto 0);
        RSSI_1                      => rssi_1(i)                               ,--: out std_logic_vector(31 downto 0);
        RSSI_2                      => rssi_2(i)                               ,--: out std_logic_vector(31 downto 0);
        RSSI_3                      => rssi_3(i)                               ,--: out std_logic_vector(31 downto 0);

        TEST_MODE                   => test_mode(i)                            ,--: in  std_logic_vector(3 downto 0);
        TP_MEM_PEN       => TP_MEM_PEN,
	    TP_MEM_AWEN      => TP_MEM_AWEN,
	    TP_MEM_WRADDR    => TP_MEM_WRADDR,
	    TP_MEM_WRDATA    => TP_MEM_WRDATA,

        TEST_DC_I                   => test_dc_i                               ,--: in  std_logic_vector(15 downto 0);
        TEST_DC_Q                   => test_dc_q                               ,--: in  std_logic_vector(15 downto 0);
        TEST_NCO                    => test_nco                                ,--: in  std_logic_vector(5 downto 0);

        DUMP_DL_10MS                => dump_dl_10ms(i)                         ,--: out std_logic;
        DUMP_DL_SYNC                => dump_dl_sync(i)                         ,--: out std_logic;
        DUMP_DL_DATA                => dump_dl_data(i)                         ,--: out std_logic_vector(15 downto 0);

        DUMP_UL_10MS                => dump_ul_10ms(i)                         ,--: out std_logic;
        DUMP_UL_SYNC                => dump_ul_sync(i)                         ,--: out std_logic;
        DUMP_UL_DATA                => dump_ul_data(i)                          --: out std_logic_vector(15 downto 0)
    );
    end generate;

--    U_FORMATTER_NB_IOT : FORMATTER_8T 
--    port map(

--        ARESET                      => RST_BBCTRL                ,--: in  std_logic;
--        CLK                         => CLK_SYSX8                 ,--: in  std_logic;

--        PROCESSING_DELAY_UL         => open                      ,--: out std_logic_vector(23 downto 0);

--        UL_10MS                     => nb_ul_fmt_10ms            ,--: out std_logic;
--        UL_TDD                      => nb_ul_fmt_tdd             ,--: out std_logic;
--        UL_SYNC                     => nb_ul_fmt_sync            ,--: out std_logic;
--        UL_DATA                     => nb_ul_fmt_data            ,--: out std_logic_vector(15 downto 0);

--        DDC_10MS                    => ddc_10ms(2)               ,--: in  std_logic;
--        DDC_TDD                     => ddc_tdd(2)                ,--: in  std_logic;
--        DDC_SYNC                    => UL_SYNC_IN(2)             ,--: in  std_logic;
--        DDC_DATA                    => UL_IQ_IN(2)               ,--: in  std_logic_vector(15 downto 0);

--        UL_ON(0)                    => ul_on(2)                  ,--: in  std_logic_array4(1 downto 0);
--        UL_ON(1)                    => ul_on(3)                  ,--: in  std_logic_array4(1 downto 0);

--        UL_ATT_0(0)                 => ul_att_0(2)               ,--: in  std_logic_array16(1 downto 0); --vector(15 downto 0);
--        UL_ATT_0(1)                 => ul_att_0(3)               ,--: in  std_logic_array16(1 downto 0); --vector(15 downto 0);
--        UL_ATT_1(0)                 => ul_att_1(2)               ,--: in  std_logic_array16(1 downto 0); --vector(15 downto 0);
--        UL_ATT_1(1)                 => ul_att_1(3)               ,--: in  std_logic_array16(1 downto 0); --vector(15 downto 0);
--        UL_ATT_2(0)                 => ul_att_2(2)               ,--: in  std_logic_array16(1 downto 0); --vector(15 downto 0);
--        UL_ATT_2(1)                 => ul_att_2(3)               ,--: in  std_logic_array16(1 downto 0); --vector(15 downto 0);
--        UL_ATT_3(0)                 => ul_att_3(2)               ,--: in  std_logic_array16(1 downto 0); --vector(15 downto 0);
--        UL_ATT_3(1)                 => ul_att_3(3)               ,--: in  std_logic_array16(1 downto 0); --vector(15 downto 0);

--        RSSI_0(0)                   => rssi_0(2)                 ,--: out std_logic_array32(1 downto 0);
--        RSSI_0(1)                   => rssi_0(3)                 ,--: out std_logic_array32(1 downto 0);
--        RSSI_1(0)                   => rssi_1(2)                 ,--: out std_logic_array32(1 downto 0);
--        RSSI_1(1)                   => rssi_1(3)                 ,--: out std_logic_array32(1 downto 0);
--        RSSI_2(0)                   => rssi_2(2)                 ,--: out std_logic_array32(1 downto 0);
--        RSSI_2(1)                   => rssi_2(3)                 ,--: out std_logic_array32(1 downto 0);
--        RSSI_3(0)                   => rssi_3(2)                 ,--: out std_logic_array32(1 downto 0);
--        RSSI_3(1)                   => rssi_3(3)                 ,--: out std_logic_array32(1 downto 0);

--        DUMP_UL_10MS                => nb_dump_ul_10ms           ,--: out std_logic;
--        DUMP_UL_SYNC                => nb_dump_ul_sync           ,--: out std_logic;
--        DUMP_UL_DATA                => nb_dump_ul_data            --: out std_logic_vector(15 downto 0)
--    );

--    U_MAP_IF_NB_IOT : BB_MAP_IF_8T 
--    port map(
--        CLK_SYSX8                   => CLK_SYSX8                 ,--:in  std_logic;

--        PROCESSING_DELAY_UL         => open                      ,--:out std_logic_vector(23 downto 0);

--        O_UL_FSYNC                  => nb_ul_fsync_out           ,--:out std_logic_vector( 1 downto 0);    -- 1 clock frame(10ms) sync   
--        O_UL_TDD                    => nb_ul_tdd_out             ,--:out std_logic_vector( 1 downto 0);       
--        O_UL_VLD                    => nb_ul_vld_out             ,--:out std_logic_vector( 7 downto 0);    -- valid signal for valid data.   
--        O_UL_DATA_I                 => nb_ul_data_i_out          ,--:out std_logic_array16(7 downto 0);    -- 16b idata path per one ant path.  
--        O_UL_DATA_Q                 => nb_ul_data_q_out          ,--:out std_logic_array16(7 downto 0);    -- 16b qdata path per one ant path.  

--        I_UL_FSYNC                  => nb_ul_fmt_10ms            ,--:in  std_logic;
--        I_UL_TDD                    => nb_ul_fmt_tdd             ,--:in  std_logic;
--        I_UL_SYNC                   => nb_ul_fmt_sync            ,--:in  std_logic;
--        I_UL_DATA                   => nb_ul_fmt_data             --:in  std_logic_vector(15 downto 0) 
--    );


--    u_PIM_IF : PIM_IF
--    generic map(
--        PIM_NUM                     => PIM_SBIF_NUM                             --: natural := 2
--    )
--    port map(
--        CLK_SYSX8                   => CLK_SYSX8                               ,--: in  std_logic;

--        PIM_SBIF_RX_ENB_IN          => PIM_SBIF_RX_ENB_IN                      ,--: in  std_logic_vector(PIM_NUM-1 downto 0);
--        PIM_SBIF_RX_I_IN            => PIM_SBIF_RX_I_IN                        ,--: in  std_logic_array16(PIM_NUM-1 downto 0);
--        PIM_SBIF_RX_Q_IN            => PIM_SBIF_RX_Q_IN                        ,--: in  std_logic_array16(PIM_NUM-1 downto 0);

--        PIM_SBIF_TX_VLD_OUT         => PIM_SBIF_TX_VLD_OUT                     ,--: out std_logic_vector(PIM_NUM-1 downto 0);
--        PIM_SBIF_TX_I_OUT           => PIM_SBIF_TX_I_OUT                       ,--: out std_logic_array16(PIM_NUM-1 downto 0);
--        PIM_SBIF_TX_Q_OUT           => PIM_SBIF_TX_Q_OUT                       ,--: out std_logic_array16(PIM_NUM-1 downto 0);

--        PIM_SBIF_RX_1PPS            => I_1PPS_CPU                              ,--: in  std_logic_vector(PIM_NUM-1 downto 0);
--        PIM_SBIF_RX_BFN_STRB        => I_BFN_STRB_CPU                          ,--: in  std_logic_vector(PIM_NUM-1 downto 0);
--        PIM_SBIF_RX_BFN             => I_BFN_CPU                               ,--: in  std_logic_vector(PIM_NUM-1 downto 0);

--        PIM_SBIF_TX_SYNC            => PIM_SBIF_TX_SYNC                        ,--: out std_logic_vector(PIM_NUM-1 downto 0);
--        PIM_SBIF_TX_1PPS            => PIM_SBIF_TX_1PPS                        ,--: out std_logic_vector(PIM_NUM-1 downto 0);
--        PIM_SBIF_TX_BFN_STRB        => PIM_SBIF_TX_BFN_STRB                    ,--: out std_logic_vector(PIM_NUM-1 downto 0);
--        PIM_SBIF_TX_BFN             => PIM_SBIF_TX_BFN                         ,--: out std_logic_vector(PIM_NUM-1 downto 0);

--        PIM_SYNC_IN                 => PIM_SYNC_IN                             ,--: in  std_logic_vector(PIM_NUM-1 downto 0);
--        PIM_I_IN                    => PIM_I_IN                                ,--: in  std_logic_array15(PIM_NUM-1 downto 0);
--        PIM_Q_IN                    => PIM_Q_IN                                ,--: in  std_logic_array15(PIM_NUM-1 downto 0);

--        PIM_SYNC_OUT                => PIM_SYNC_OUT                            ,--: out std_logic_vector(PIM_NUM-1 downto 0);
--        PIM_I_OUT                   => PIM_I_OUT                               ,--: out std_logic_array15(PIM_NUM-1 downto 0);
--        PIM_Q_OUT                   => PIM_Q_OUT                                --: out std_logic_array15(PIM_NUM-1 downto 0)
--    );

end BEHAVE;
