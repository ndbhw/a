--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : O-RAN TOP                                                     --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
-- Rev1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.PKG_O_RAN.ALL;
use WORK.ARRAY_TYPE.ALL;
use work.RU_FPGA_CONFIG.all;

entity O_RAN_TOP is
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        ARESET_RX                   : in  std_logic_vector(1 downto 0);
        ARESET_TX                   : in  std_logic_vector(1 downto 0);

        CLK_MAC_RX                  : in  std_logic;                            -- 156.25/390.625-MHz
        CLK_MAC_TX                  : in  std_logic;                            -- 156.25/390.625-MHz
        CLK_BUS                     : in  std_logic;                            -- 245.76-MHz

--------------------------------------------------------------------------------
-- Sync
--------------------------------------------------------------------------------

        TICK_1PPS                   : in  std_logic;                            -- 8-clocks@CLK_BUS
        FRAME_SYNC                  : in  std_logic;                            -- should be aligned with 1PPS 
        FRAME_NUM                   : in  std_logic_vector(11 downto 0);

        DL_CC0_SYNC_ADVANCE         : in  std_logic_vector(21 downto 0);
        UL_CC0_SYNC_RETARD          : in  std_logic_vector(21 downto 0);
        CC0_N_TA_OFFSET             : in  std_logic_vector(15 downto 0);
        
        DL_CC1_SYNC_ADVANCE         : in  std_logic_vector(21 downto 0);
        UL_CC1_SYNC_RETARD          : in  std_logic_vector(21 downto 0);
        CC1_N_TA_OFFSET             : in  std_logic_vector(15 downto 0);

        TDD_SYMBOL_SYNC             : out std_logic; 
        TDD_SYMBOL_INDEX            : out std_logic_vector(3 downto 0);
        TDD_DL_EN                   : out std_logic_vector(7 downto 0);
        TDD_UL_EN                   : out std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- CPU interface
--------------------------------------------------------------------------------

        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        RDVAL_CPUIF_OUT             : out std_logic;

--------------------------------------------------------------------------------
-- MAC#0 (CC#0)
--------------------------------------------------------------------------------

        MAC_CC0_RX_VALID            : in  std_logic;
        MAC_CC0_RX_LAST             : in  std_logic;
        MAC_CC0_RX_KEEP             : in  std_logic_vector(7 downto 0);
        MAC_CC0_RX_DATA             : in  std_logic_vector(63 downto 0);
                                    
        MAC_CC1_RX_VALID            : in  std_logic;
        MAC_CC1_RX_LAST             : in  std_logic;
        MAC_CC1_RX_KEEP             : in  std_logic_vector(7 downto 0);
        MAC_CC1_RX_DATA             : in  std_logic_vector(63 downto 0);

        MAC_CC_TX_READY         : in  std_logic;
        MAC_CC_TX_VALID         : out std_logic;
        MAC_CC_TX_LAST          : out std_logic;
        MAC_CC_TX_KEEP          : out std_logic_vector(7 downto 0);
        MAC_CC_TX_DATA          : out std_logic_vector(63 downto 0);

--        MAC_CC0_PUxCH_READY         : in  std_logic;
--        MAC_CC0_PUxCH_VALID         : out std_logic;
--        MAC_CC0_PUxCH_LAST          : out std_logic;
--        MAC_CC0_PUxCH_KEEP          : out std_logic_vector(7 downto 0);
--        MAC_CC0_PUxCH_DATA          : out std_logic_vector(63 downto 0);
    
--        MAC_CC1_PUxCH_READY         : in  std_logic;
--        MAC_CC1_PUxCH_VALID         : out std_logic;
--        MAC_CC1_PUxCH_LAST          : out std_logic;
--        MAC_CC1_PUxCH_KEEP          : out std_logic_vector(7 downto 0);
--        MAC_CC1_PUxCH_DATA          : out std_logic_vector(63 downto 0);
    
--        MAC_CC0_PRACH_READY         : in  std_logic;
--        MAC_CC0_PRACH_VALID         : out std_logic;
--        MAC_CC0_PRACH_LAST          : out std_logic;
--        MAC_CC0_PRACH_KEEP          : out std_logic_vector(7 downto 0);
--        MAC_CC0_PRACH_DATA          : out std_logic_vector(63 downto 0);
    
--        MAC_CC1_PRACH_READY         : in  std_logic;
--        MAC_CC1_PRACH_VALID         : out std_logic;
--        MAC_CC1_PRACH_LAST          : out std_logic;
--        MAC_CC1_PRACH_KEEP          : out std_logic_vector(7 downto 0);
--        MAC_CC1_PRACH_DATA          : out std_logic_vector(63 downto 0);

--------------------------------------------------------------------------------
-- DLFE
--------------------------------------------------------------------------------

        DLFE_CC0_SYSTEM_MODE        : in  std_logic;  
        DLFE_CC0_K0                 : in  std_logic_vector(11 downto 0);
        DLFE_CC0_nRE                : in  std_logic_vector(11 downto 0);
        DLFE_CC0_nFFT               : in  std_logic_vector(1 downto 0); 
        DLFE_CC0_FRAME_SYNC         : out std_logic;
        DLFE_CC0_FRAME_INDEX        : out std_logic_vector(7 downto 0);
        DLFE_CC0_VALID              : out std_logic_vector(DL_NUM_ANT-1 downto 0);                       
        DLFE_CC0_RE_MASK            : out std_logic_vector(DL_NUM_ANT-1 downto 0);
        DLFE_CC0_DATA               : out std_logic_vector(DL_NUM_ANT*32-1 downto 0);   
        
        
        DLFE_CC1_SYSTEM_MODE        : in  std_logic;  
        DLFE_CC1_K0                 : in  std_logic_vector(11 downto 0);
        DLFE_CC1_nRE                : in  std_logic_vector(11 downto 0);
        DLFE_CC1_nFFT               : in  std_logic_vector(1 downto 0); 
        
        DLFE_CC1_FRAME_SYNC         : out std_logic;
        DLFE_CC1_FRAME_INDEX        : out std_logic_vector(7 downto 0);
        DLFE_CC1_VALID              : out std_logic_vector(DL_NUM_ANT-1 downto 0);                       
        DLFE_CC1_RE_MASK            : out std_logic_vector(DL_NUM_ANT-1 downto 0);
        DLFE_CC1_DATA               : out std_logic_vector(DL_NUM_ANT*32-1 downto 0);   

--------------------------------------------------------------------------------
-- ULFE
--------------------------------------------------------------------------------

        ULFE_CC0_FRAME_ID           : in  std_logic_vector(7 downto 0);
        ULFE_CC0_SUBFRAME_ID        : in  std_logic_vector(3 downto 0);
        ULFE_CC0_SLOT_ID            : in  std_logic_vector(5 downto 0);
        ULFE_CC0_SYMBOL_ID          : in  std_logic_vector(5 downto 0);
        ULFE_CC0_START_RE           : in  std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        ULFE_CC0_VALID              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        ULFE_CC0_START              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        ULFE_CC0_LAST               : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        ULFE_CC0_DATA               : in  std_logic_vector(UL_NUM_ANT*32-1 downto 0);
        
        ULFE_CC1_FRAME_ID           : in  std_logic_vector(7 downto 0);
        ULFE_CC1_SUBFRAME_ID        : in  std_logic_vector(3 downto 0);
        ULFE_CC1_SLOT_ID            : in  std_logic_vector(5 downto 0);
        ULFE_CC1_SYMBOL_ID          : in  std_logic_vector(5 downto 0);
        ULFE_CC1_START_RE           : in  std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        ULFE_CC1_VALID              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        ULFE_CC1_START              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        ULFE_CC1_LAST               : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        ULFE_CC1_DATA               : in  std_logic_vector(UL_NUM_ANT*32-1 downto 0);

--------------------------------------------------------------------------------
-- RAFE
--------------------------------------------------------------------------------

        RAFE_CC0_FRAMES_SYNC        : out std_logic;
        RAFE_CC0_FILTER_INDEX       : out std_logic_vector(UL_NUM_ANT*4-1 downto 0);
        RAFE_CC0_TIME_OFFSET        : out std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        RAFE_CC0_FRAME_STRUCTURE    : out std_logic_vector(UL_NUM_ANT*8-1 downto 0);
        RAFE_CC0_CPLENGTH           : out std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        RAFE_CC0_FREQ_OFFSET        : out std_logic_vector(UL_NUM_ANT*24-1 downto 0);
        RAFE_CC0_START_PRBC         : out std_logic_vector(UL_NUM_ANT*10-1 downto 0);        
        RAFE_CC0_NUM_PRBC           : out std_logic_vector(UL_NUM_ANT*8-1 downto 0);
        RAFE_CC0_NUM_PSYMBOL        : out std_logic_vector(UL_NUM_ANT*4-1 downto 0);
        RAFE_CC0_NUM_RO             : out std_logic_vector(UL_NUM_ANT*3-1 downto 0);
        RAFE_CC0_FRAME_ID           : in  std_logic_vector(7 downto 0);
        RAFE_CC0_SUBFRAME_ID        : in  std_logic_vector(3 downto 0);
        RAFE_CC0_SLOT_ID            : in  std_logic_vector(5 downto 0);
        RAFE_CC0_SYMBOL_ID          : in  std_logic_vector(5 downto 0);
        RAFE_CC0_START_RE           : in  std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        RAFE_CC0_VALID              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        RAFE_CC0_START              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        RAFE_CC0_LAST               : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        RAFE_CC0_DATA               : in  std_logic_vector(UL_NUM_ANT*32-1 downto 0);
        
        RAFE_CC1_FRAMES_SYNC        : out std_logic;
        RAFE_CC1_FILTER_INDEX       : out std_logic_vector(UL_NUM_ANT*4-1 downto 0);
        RAFE_CC1_TIME_OFFSET        : out std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        RAFE_CC1_FRAME_STRUCTURE    : out std_logic_vector(UL_NUM_ANT*8-1 downto 0);
        RAFE_CC1_CPLENGTH           : out std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        RAFE_CC1_FREQ_OFFSET        : out std_logic_vector(UL_NUM_ANT*24-1 downto 0);
        RAFE_CC1_START_PRBC         : out std_logic_vector(UL_NUM_ANT*10-1 downto 0);
        RAFE_CC1_NUM_PSYMBOL        : out std_logic_vector(UL_NUM_ANT*4-1 downto 0);
        RAFE_CC1_NUM_PRBC           : out std_logic_vector(UL_NUM_ANT*8-1 downto 0);
        RAFE_CC1_NUM_RO             : out std_logic_vector(UL_NUM_ANT*3-1 downto 0);
        RAFE_CC1_FRAME_ID           : in  std_logic_vector(7 downto 0);
        RAFE_CC1_SUBFRAME_ID        : in  std_logic_vector(3 downto 0);
        RAFE_CC1_SLOT_ID            : in  std_logic_vector(5 downto 0);
        RAFE_CC1_SYMBOL_ID          : in  std_logic_vector(5 downto 0);
        RAFE_CC1_START_RE           : in  std_logic_vector(UL_NUM_ANT*16-1 downto 0);
        RAFE_CC1_VALID              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        RAFE_CC1_START              : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        RAFE_CC1_LAST               : in  std_logic_vector(UL_NUM_ANT-1 downto 0);
        RAFE_CC1_DATA               : in  std_logic_vector(UL_NUM_ANT*32-1 downto 0)
    );
end O_RAN_TOP;

architecture BEHAVE of O_RAN_TOP is

    type boolean_array              is array(natural range <>) of boolean;
    type ul_sync_array              is array(natural range <>) of std_logic_vector(UL_NUM_ANT-1 downto 0);
    type ul_data_array              is array(natural range <>) of std_logic_array16(UL_NUM_ANT-1 downto 0);
    constant MAX_CH_PER_UNIT        : natural range 0 to 8 := 4;                -- Channel muxing per unit (Max : 8)
    constant MAX_ID_PER_CH          : natural range 0 to 8 := 4;                -- eAxC ID per each channel (Max : 4)

    constant OFFSET                 : std_logic_vector(3 downto 0) := x"2";

    constant CC                     : natural := 2;
    constant DL_ANT                 : natural := 4;
    constant UL_ANT                 : natural := 4;

    constant DL_PATH                : natural := CC*DL_ANT;
    constant UL_PATH                : natural := CC*UL_ANT;

    constant DL_UNIT                : natural := DL_PATH/MAX_CH_PER_UNIT;
    constant UL_UNIT                : natural := UL_PATH/MAX_CH_PER_UNIT;

    signal mac_rx_valid             : std_logic_vector(DL_UNIT-1 downto 0);
    signal mac_rx_last              : std_logic_vector(DL_UNIT-1 downto 0);
    signal mac_rx_keep              : std_logic_array8(DL_UNIT-1 downto 0);
    signal mac_rx_data              : std_logic_array64(DL_UNIT-1 downto 0);

--    signal mac_tx_ready             : std_logic_vector(UL_UNIT*2-1 downto 0);
--    signal mac_tx_valid             : std_logic_vector(UL_UNIT*2-1 downto 0);
--    signal mac_tx_last              : std_logic_vector(UL_UNIT*2-1 downto 0);
--    signal mac_tx_keep              : std_logic_array8(UL_UNIT*2-1 downto 0);
--    signal mac_tx_data              : std_logic_array64(UL_UNIT*2-1 downto 0);


    signal mac_tx_ready             : std_logic_vector(6-1 downto 0);
    signal mac_tx_valid             : std_logic_vector(6-1 downto 0);
    signal mac_tx_last              : std_logic_vector(6-1 downto 0);
    signal mac_tx_keep              : std_logic_array8(6-1 downto 0);
    signal mac_tx_data              : std_logic_array64(6-1 downto 0);
    
    signal mux_mac_tx_ready             : std_logic;
    signal mux_mac_tx_valid             : std_logic;
    signal mux_mac_tx_last              : std_logic;
    signal mux_mac_tx_keep              : std_logic_vector(8-1 downto 0);
    signal mux_mac_tx_data              : std_logic_vector(64-1 downto 0);

    signal ulfe_frame_id            : std_logic_array8(UL_UNIT-1 downto 0);
    signal ulfe_subframe_id         : std_logic_array4(UL_UNIT-1 downto 0);
    signal ulfe_slot_id             : std_logic_array6(UL_UNIT-1 downto 0);
    signal ulfe_symbol_id           : std_logic_array6(UL_UNIT-1 downto 0);
    signal ulfe_start_re            : std_logic_array16(UL_UNIT-1 downto 0);
    signal ulfe_valid               : ul_sync_array(UL_UNIT-1 downto 0);
    signal ulfe_start               : ul_sync_array(UL_UNIT-1 downto 0);
    signal ulfe_last                : ul_sync_array(UL_UNIT-1 downto 0);
    signal ulfe_data_i              : ul_data_array(UL_UNIT-1 downto 0);
    signal ulfe_data_q              : ul_data_array(UL_UNIT-1 downto 0);

    signal rafe_frame_id            : std_logic_array8(UL_UNIT-1 downto 0);
    signal rafe_subframe_id         : std_logic_array4(UL_UNIT-1 downto 0);
    signal rafe_slot_id             : std_logic_array6(UL_UNIT-1 downto 0);
    signal rafe_symbol_id           : std_logic_array6(UL_UNIT-1 downto 0);
    signal rafe_start_re            : std_logic_array16(UL_UNIT-1 downto 0);
    signal rafe_valid               : ul_sync_array(UL_UNIT-1 downto 0);
    signal rafe_start               : ul_sync_array(UL_UNIT-1 downto 0);
    signal rafe_last                : ul_sync_array(UL_UNIT-1 downto 0);
    signal rafe_data_i              : ul_data_array(UL_UNIT-1 downto 0);
    signal rafe_data_q              : ul_data_array(UL_UNIT-1 downto 0);

    component O_RAN_FRAMER_INTERCONNECT is
    generic (
        NUM_PORT                    : natural := 8
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        FRAMER_TX_TREADY            : out std_logic_vector(NUM_PORT-1 downto 0);
        FRAMER_TX_TVALID            : in  std_logic_vector(NUM_PORT-1 downto 0);
        FRAMER_TX_TLAST             : in  std_logic_vector(NUM_PORT-1 downto 0);
        FRAMER_TX_TKEEP             : in  std_logic_array8(NUM_PORT-1 downto 0);
        FRAMER_TX_TDATA             : in  std_logic_array64(NUM_PORT-1 downto 0);

        UL_TREADY                   : in  std_logic;
        UL_TVALID                   : out std_logic;
        UL_TLAST                    : out std_logic;
        UL_TKEEP                    : out std_logic_vector(7 downto 0);
        UL_TDATA                    : out std_logic_vector(63 downto 0)
    );
    end component;

    component O_RAN_DEFRAMER is
    generic (
        MAX_CH_PER_UNIT             : natural := 2;
        FILTER_MAC                  : boolean := true;
        FILTER_ETHERTYPE            : boolean := true;
        USAGE_C_PLANE               : boolean := true;
        USAGE_U_PLANE               : boolean := true
    );
    port (
        RST                         : in  std_logic;

        CLK_MAC                     : in  std_logic;
        CLK_BUS                     : in  std_logic;

        RX_PARAM_MAC                : in  std_logic_vector(47 downto 0);
        RX_PARAM_ETHERTYPE          : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_0_EN        : in  std_logic;
        RX_PARAM_ID_CH0_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_1_EN        : in  std_logic;
        RX_PARAM_ID_CH0_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_2_EN        : in  std_logic;
        RX_PARAM_ID_CH0_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_3_EN        : in  std_logic;
        RX_PARAM_ID_CH0_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_0_EN        : in  std_logic;
        RX_PARAM_ID_CH1_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_1_EN        : in  std_logic;
        RX_PARAM_ID_CH1_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_2_EN        : in  std_logic;
        RX_PARAM_ID_CH1_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_3_EN        : in  std_logic;
        RX_PARAM_ID_CH1_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_0_EN        : in  std_logic;
        RX_PARAM_ID_CH2_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_1_EN        : in  std_logic;
        RX_PARAM_ID_CH2_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_2_EN        : in  std_logic;
        RX_PARAM_ID_CH2_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_3_EN        : in  std_logic;
        RX_PARAM_ID_CH2_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_0_EN        : in  std_logic;
        RX_PARAM_ID_CH3_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_1_EN        : in  std_logic;
        RX_PARAM_ID_CH3_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_2_EN        : in  std_logic;
        RX_PARAM_ID_CH3_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_3_EN        : in  std_logic;
        RX_PARAM_ID_CH3_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_0_EN        : in  std_logic;
        RX_PARAM_ID_CH4_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_1_EN        : in  std_logic;
        RX_PARAM_ID_CH4_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_2_EN        : in  std_logic;
        RX_PARAM_ID_CH4_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_3_EN        : in  std_logic;
        RX_PARAM_ID_CH4_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_0_EN        : in  std_logic;
        RX_PARAM_ID_CH5_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_1_EN        : in  std_logic;
        RX_PARAM_ID_CH5_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_2_EN        : in  std_logic;
        RX_PARAM_ID_CH5_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_3_EN        : in  std_logic;
        RX_PARAM_ID_CH5_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_0_EN        : in  std_logic;
        RX_PARAM_ID_CH6_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_1_EN        : in  std_logic;
        RX_PARAM_ID_CH6_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_2_EN        : in  std_logic;
        RX_PARAM_ID_CH6_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_3_EN        : in  std_logic;
        RX_PARAM_ID_CH6_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_0_EN        : in  std_logic;
        RX_PARAM_ID_CH7_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_1_EN        : in  std_logic;
        RX_PARAM_ID_CH7_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_2_EN        : in  std_logic;
        RX_PARAM_ID_CH7_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_3_EN        : in  std_logic;
        RX_PARAM_ID_CH7_3           : in  std_logic_vector(15 downto 0);

        RX_COMP_MODE                : in  std_logic;
        RX_IQ_WIDTH                 : in  std_logic_vector(3 downto 0);
        RX_COMP_METHOD              : in  std_logic_vector(3 downto 0);
        RX_SCS_CONFIG               : in  std_logic_vector(3 downto 0);
        RX_FFT_SIZE                 : in  std_logic_vector(3 downto 0);
        RX_PRB_PER_SYMBOL           : in  std_logic_vector(9 downto 0);
        RX_COMP_EXP_OFFSET          : in  std_logic_vector(4 downto 0);

        USAGE_RX_DATA_BUFFER        : out std_logic_vector(31 downto 0);

        RX_INVALID_DST_MAC          : out std_logic_vector(31 downto 0);
        RX_INVALID_ETHERTYPE        : out std_logic_vector(31 downto 0);
        RX_INVALID_ecpriVersion     : out std_logic_vector(31 downto 0);
        RX_INVALID_ecpriC           : out std_logic_vector(31 downto 0);
        RX_INVALID_ecpriMessage     : out std_logic_vector(31 downto 0);
        RX_C_PLANE                  : out std_logic_vector(31 downto 0);
        RX_C_PLANE_DROPPED          : out std_logic_vector(31 downto 0);
        RX_U_PLANE                  : out std_logic_vector(31 downto 0);
        RX_U_PLANE_DROPPED          : out std_logic_vector(31 downto 0);
        RX_LOST                     : out std_logic_vector(31 downto 0);

        RX_LENGTH_IS_NORMAL         : out std_logic_vector(31 downto 0);
        RX_LENGTH_IS_LONG           : out std_logic_vector(31 downto 0);
        RX_LENGTH_IS_SHORT          : out std_logic_vector(31 downto 0);

        RX_C_PLANE_EXIST            : out std_logic_vector(31 downto 0);
        RX_U_PLANE_EXIST            : out std_logic_vector(31 downto 0);

        RX_FAULT_ID_31_CH0          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH1          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH2          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH3          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH4          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH5          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH6          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH7          : out std_logic_vector(3 downto 0);

        MAC_RX_READY                : out std_logic;
        MAC_RX_VALID                : in  std_logic;
        MAC_RX_LAST                 : in  std_logic;
        MAC_RX_KEEP                 : in  std_logic_vector(7 downto 0);
        MAC_RX_DATA                 : in  std_logic_vector(63 downto 0);

        PACKET_IS_CP_DL             : out std_logic;
        PACKET_IS_CP_UL             : out std_logic;
        PACKET_IS_UP_DL             : out std_logic;
        PACKET_IS_UP_UL             : out std_logic;
        PACKET_SCS                  : out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             : out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              : out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            : out std_logic_vector(5 downto 0);

        BYPASS_OUT_VALID            : out std_logic;
        BYPASS_OUT_LAST             : out std_logic;
        BYPASS_OUT_KEEP             : out std_logic_vector(7 downto 0);
        BYPASS_OUT_DATA             : out std_logic_vector(63 downto 0);

        eCPRI_RX_C_VALID            : out std_logic;
        eCPRI_RX_C_LAST             : out std_logic;
        eCPRI_RX_C_KEEP             : out std_logic_vector(3 downto 0);
        eCPRI_RX_C_DATA             : out std_logic_vector(31 downto 0);
        eCPRI_RX_C_CH               : out std_logic_vector(2 downto 0);
        eCPRI_RX_C_CH_SUB           : out std_logic_vector(3 downto 0);

        ADV_RB_CHANNEL_ID           : out std_logic_vector(2 downto 0);
        ADV_RB_FRAME_ID             : out std_logic_vector(7 downto 0);
        ADV_RB_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        ADV_RB_SLOT_ID              : out std_logic_vector(5 downto 0);
        ADV_RB_SYMBOL_ID            : out std_logic_vector(5 downto 0);
        ADV_RB_START                : out std_logic;

        RB_eAxC_ID                  : out std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              : out std_logic_vector(15 downto 0);
        RB_CHANNEL_ID               : out std_logic_vector(2 downto 0);
        RB_FRAME_ID                 : out std_logic_vector(7 downto 0);
        RB_SUBFRAME_ID              : out std_logic_vector(3 downto 0);
        RB_SLOT_ID                  : out std_logic_vector(5 downto 0);
        RB_SYMBOL_ID                : out std_logic_vector(5 downto 0);
        RB_SECTION_ID               : out std_logic_vector(11 downto 0);
        RB_NUMBER                   : out std_logic_vector(9 downto 0);
        RE_NUMBER                   : out std_logic_vector(11 downto 0);

        RB_VALID                    : out std_logic;
        RB_START                    : out std_logic;
        RB_TICK                     : out std_logic;
        RB_LAST                     : out std_logic;
        RB_DATA_I                   : out std_logic_vector(15 downto 0);
        RB_DATA_Q                   : out std_logic_vector(15 downto 0);
        
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

--------------------------------------------------------------------------------
-- Synchronization
--------------------------------------------------------------------------------

        N_TA_OFFSET                 : in  std_logic_vector(15 downto 0);

        REF_10msec                  : in  std_logic;                            -- Longer than 1-clocks@245.76-MHz
        REF_SFN                     : in  std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        CAPTURE_PERIOD              : in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MAX_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        
        MAC_HEADER_REMOVED_OUT_VALID        : out std_logic_vector(2 downto 0);
        MAC_HEADER_REMOVED_OUT_LAST         : out std_logic;                   
        MAC_HEADER_REMOVED_OUT_KEEP         : out std_logic_vector(7 downto 0);
        MAC_HEADER_REMOVED_OUT_DATA         : out std_logic_vector(63 downto 0);
        
        RX_CORRUPT_SECTIONID        : out std_logic
            
    );
    end component;

    signal rx_corrupt_sectionid :    std_logic_vector(DL_UNIT-1 downto 0);
    signal s_rx_corrupt_ecpriversion_payloadversion_pcid: std_logic := '0';
    signal s_rx_corrupt_pcid                                : std_logic;
    signal s_rx_corrupt_ecpri_version                       : std_logic;
    signal s_rx_corrupt_payload_version                     : std_logic;       

    signal cnt_rx_corrupt                                   : std_logic_vector(63 downto 0);
    signal cnt_rx_corrupt_sectionid                         : std_logic_vector(63 downto 0);
    signal cnt_rx_corrupt_ecpriversion_payloadversion_pcid  : std_logic_vector(63 downto 0);
    signal cnt_rx_corrupt_ecpriversion                      : std_logic_vector(63 downto 0);
    signal cnt_rx_corrupt_pcid                              : std_logic_vector(63 downto 0);
    signal cnt_rx_corrupt_payloadversion                    : std_logic_vector(63 downto 0);

    signal s_mac_header_removed_out_valid        :  std_logic_array3(DL_UNIT-1 downto 0);
    signal s_mac_header_removed_out_last         :  std_logic_vector(DL_UNIT-1 downto 0);                   
    signal s_mac_header_removed_out_keep         :  std_logic_array8(DL_UNIT-1 downto 0);
    signal s_mac_header_removed_out_data         :  std_logic_array64(DL_UNIT-1 downto 0);
        
    signal rx_packet_is_cp_dl       : std_logic_vector(DL_UNIT-1 downto 0);
    signal rx_packet_is_cp_ul       : std_logic_vector(DL_UNIT-1 downto 0);
    signal rx_packet_is_up_dl       : std_logic_vector(DL_UNIT-1 downto 0);
    signal rx_packet_scs            : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_packet_frame_id       : std_logic_array8(DL_UNIT-1 downto 0);
    signal rx_packet_subframe_id    : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_packet_slot_id        : std_logic_array6(DL_UNIT-1 downto 0);
    signal rx_packet_symbol_id      : std_logic_array6(DL_UNIT-1 downto 0);
    signal ecpri_rx_c_valid         : std_logic_vector(DL_UNIT-1 downto 0);
    signal ecpri_rx_c_last          : std_logic_vector(DL_UNIT-1 downto 0);
    signal ecpri_rx_c_keep          : std_logic_array4(DL_UNIT-1 downto 0);
    signal ecpri_rx_c_data          : std_logic_array32(DL_UNIT-1 downto 0);
    signal ecpri_rx_c_ch            : std_logic_array4(DL_UNIT-1 downto 0) := (others => (others => '0'));
    signal ecpri_rx_c_ch_sub        : std_logic_array4(DL_UNIT-1 downto 0);
--    signal dl_adv_rb_channel_id     : std_logic_array3(DL_UNIT-1 downto 0);
--    signal dl_adv_rb_frame_id       : std_logic_array8(DL_UNIT-1 downto 0);
--    signal dl_adv_rb_subframe_id    : std_logic_array4(DL_UNIT-1 downto 0);
--    signal dl_adv_rb_slot_id        : std_logic_array6(DL_UNIT-1 downto 0);
--    signal dl_adv_rb_symbol_id      : std_logic_array6(DL_UNIT-1 downto 0);
--    signal dl_adv_rb_start          : std_logic_vector(DL_UNIT-1 downto 0);
--    signal dl_rb_eaxc_id            : std_logic_array16(DL_UNIT-1 downto 0);
--    signal dl_rb_sequence_id        : std_logic_array16(DL_UNIT-1 downto 0);
    signal dl_rb_channel_id         : std_logic_array4(DL_UNIT-1 downto 0) := (others => (others => '0'));
    signal dl_rb_frame_id           : std_logic_array8(DL_UNIT-1 downto 0);
    signal dl_rb_subframe_id        : std_logic_array4(DL_UNIT-1 downto 0);
    signal dl_rb_slot_id            : std_logic_array6(DL_UNIT-1 downto 0);
    signal dl_rb_symbol_id          : std_logic_array6(DL_UNIT-1 downto 0);
    signal dl_rb_section_id         : std_logic_array12(DL_UNIT-1 downto 0);
--    signal dl_rb_number             : std_logic_array10(DL_UNIT-1 downto 0);
    signal dl_re_number             : std_logic_array12(DL_UNIT-1 downto 0);
    signal dl_rb_valid              : std_logic_vector(DL_UNIT-1 downto 0);
    signal dl_rb_start              : std_logic_vector(DL_UNIT-1 downto 0);
    signal dl_rb_tick               : std_logic_vector(DL_UNIT-1 downto 0);
    signal dl_rb_last               : std_logic_vector(DL_UNIT-1 downto 0);
    signal dl_rb_data_i             : std_logic_array16(DL_UNIT-1 downto 0);
    signal dl_rb_data_q             : std_logic_array16(DL_UNIT-1 downto 0);

    component CU_PE_TOP is
    generic (
        VENDOR                      : string  := "XILINX"; 
        Category                    : string  :=      "B";
        eCPRI_HDR                   : boolean :=     TRUE; 
        iFFT_k0_SHIFT               : boolean :=     TRUE; 
        iFFT_ZERO_PADDING           : boolean :=    FALSE; 
        SCS                         : natural :=       30;
        SECTION_NUM                 : natural :=      256; 
        Max_RB_NUM                  : natural :=      273; 
        iFFT_WIDTH                  : natural :=       12;  
        SYMBOL_NUM                  : natural :=        7;
        CH_NUM                      : natural :=        2; -- Layer/Path @ module
        DL_LAYER_NUM                : natural :=        4;                              
        UL_RX_NUM                   : natural :=        8;                            
        Opt_BF_Support              : natural :=        1  -- Mandatory: 0, Optional: 1 
    );
    port (

        CLK                         : in  std_logic;
                                          
        nRE                         : in  std_logic_vector(11 downto 0);  
        nFFT                        : in  std_logic_vector( 1 downto 0);  
        -- 1 clk pulse, should be aligned with 1PPS                                  
        FRAME_SYNC                  : in  std_logic;
        DL_SYNC_ADVANCE             : in  std_logic_vector(21 downto 0);
        UL_SYNC_RETARD              : in  std_logic_vector(21 downto 0);
                                          
        -- FSU CPRI NR only mode          
        BFN_NUM_IN                  : in  std_logic_vector(11 downto 0); 
        BFN_NUM_OUT                 : out std_logic_vector(11 downto 0); 

        --------------------------------------------------------------------------------
        -- ORAN_TOP
        --------------------------------------------------------------------------------

        -- DL/UL C-Plane
        ECPRI_RX_C_CH_IDX           : in  std_logic_vector( 3 downto 0);  
        ECPRI_RX_C_VALID            : in  std_logic;
        ECPRI_RX_C_LAST             : in  std_logic;
        ECPRI_RX_C_KEEP             : in  std_logic_vector( 3 downto 0);
        ECPRI_RX_C_DATA             : in  std_logic_vector(31 downto 0);
                                          
        -- DL U-Plane                     
        RB_CH_IDX                   : in  std_logic_vector( 3 downto 0); 
        RB_FRAME_ID                 : in  std_logic_vector( 7 downto 0);
        RB_SUBFRAME_ID              : in  std_logic_vector( 3 downto 0);
        RB_SLOT_ID                  : in  std_logic_vector( 5 downto 0);
        RB_SYMBOL_ID                : in  std_logic_vector( 5 downto 0);
        RB_SECTION_ID               : in  std_logic_vector(11 downto 0);
        RE_NUMBER                   : in  std_logic_vector(11 downto 0);
                                          
        RB_VALID                    : in  std_logic;
        RB_START                    : in  std_logic;
        RB_LAST                     : in  std_logic;
        RB_TICK                     : in  std_logic;
        RB_DATA_I                   : in  std_logic_vector(15 downto 0);
        RB_DATA_Q                   : in  std_logic_vector(15 downto 0);

        --------------------------------------------------------------------------------
        -- DLFE/ULFE/RAFE
        --------------------------------------------------------------------------------

        SYSTEM_MODE                 : in  std_logic;                     -- 0: LTE, 1: NR
        K0                          : in  std_logic_vector(11 downto 0);
        DL_FRAME_SYNC               : out std_logic;
        DL_FRAME_INDEX              : out std_logic_vector( 7 downto 0);                  
        DL_FRAME_STRUCTURE          : out std_logic_vector( 7 downto 0);  
        DL_MuSu_nLayer              : out std_logic_vector( 4 downto 0); -- just for Optional BF 
        DL_VALID                    : out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);
        DL_RE_MASK                  : out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0); 
        DL_BEAMID                   : out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*15 - 1 downto 0);                                                                       
        DL_DATA                     : out std_logic_vector(CH_NUM*32 - 1 downto 0);   

        UL_FRAME_SYNC               : out std_logic;
        UL_FILTER_INDEX             : out std_logic_vector( 3 downto 0); 
        UL_TIME_OFFSET              : out std_logic_vector(15 downto 0); 
        UL_FRAME_STRUCTURE          : out std_logic_vector( 7 downto 0); 
        UL_CPLENGTH                 : out std_logic_vector(15 downto 0); 
        UL_FREQ_OFFSET              : out std_logic_vector(23 downto 0);    
    	UL_START_PRBC               : out std_logic_vector( 9 downto 0);
    	UL_NUM_PRBC                 : out std_logic_vector( 7 downto 0);
        UL_NUM_PSYMBOL              : out std_logic_vector( 3 downto 0);
        UL_NUM_RO                   : out std_logic_vector( 2 downto 0);

        --------------------------------------------------------------------------------
        --  SYSCTRL
        --------------------------------------------------------------------------------
        
        SYMBOL_SYNC                 : out std_logic; 
        SYMBOL_INDEX                : out std_logic_vector(3 downto 0);
        TDD_DL_EN                   : out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);
        TDD_UL_EN                   : out std_logic_vector((Opt_BF_Support*(UL_RX_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0)          
    );
    end component;

    signal dl_sync_advance          : std_logic_array22(15 downto 0); 
    signal ul_sync_retard           : std_logic_array22(15 downto 0); 

    signal tdd_sym_sync             : std_logic_vector(15 downto 0);  
    signal tdd_sym_index            : std_logic_array4(15 downto 0); 
    signal tdd_dl_enable            : std_logic_array4(15 downto 0); 
    signal tdd_ul_enable            : std_logic_array4(15 downto 0);  

    signal dlfe_k0                  : std_logic_array12(15 downto 0); 
    signal dlfe_nRE                 : std_logic_array12(15 downto 0); 
    signal dlfe_nFFT                : std_logic_array2(15 downto 0);  
    signal dlfe_bfn_num_out         : std_logic_array12(15 downto 0); 
    signal dlfe_frame_sync          : std_logic_vector(15 downto 0);  
    signal dlfe_frame_index         : std_logic_array8(15 downto 0);  
    signal dlfe_subframe_index      : std_logic_array4(15 downto 0);  
    signal dlfe_slot_index          : std_logic_array6(15 downto 0);  
    signal dlfe_symbol_sync         : std_logic_vector(15 downto 0);  
    signal dlfe_symbol_index        : std_logic_array4(15 downto 0);  
    signal dlfe_valid               : std_logic_array4(15 downto 0);  
    signal dlfe_frame_structure     : std_logic_array8(15 downto 0);  
    signal dlfe_re_mask             : std_logic_array4(15 downto 0);   
    signal dlfe_MuSu_nLayer         : std_logic_array5(15 downto 0);  
    signal dlfe_beamId              : std_logic_array60(15 downto 0); 
    signal dlfe_data                : std_logic_array128(15 downto 0);
    signal rafe_frame_sync          : std_logic_vector(15 downto 0);  
    signal rafe_slot_sync           : std_logic_vector(15 downto 0);  
    signal rafe_subframe_index      : std_logic_array4(15 downto 0);  
    signal rafe_slot_index          : std_logic_array6(15 downto 0);  
    signal rafe_filter_index        : std_logic_array4(15 downto 0);  
    signal rafe_time_offset         : std_logic_array16(15 downto 0); 
    signal rafe_frame_structure     : std_logic_array8(15 downto 0);  
    signal rafe_cplength            : std_logic_array16(15 downto 0); 
    signal rafe_freq_offset         : std_logic_array24(15 downto 0); 
    signal rafe_start_prbc          : std_logic_array10(15 downto 0);
    signal rafe_num_prbc            : std_logic_array8(15 downto 0);
    signal rafe_num_psymbol         : std_logic_array4(15 downto 0);  
    signal rafe_num_ro              : std_logic_array3(15 downto 0);   

    component DATA_MANAGER_UL is
    generic (
        MAX_CH                      : natural := 8;
        MAX_SECTION_PUxCH           : natural := 256;
        MAX_SECTION_PRACH           : natural := 16;
        LONG_PRACH                  : boolean := true
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        IGNORE_FRAME_ID             : in  std_logic;
        IGNORE_FRAME_ID_PUxCH_RX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH_RX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH_TX    : out std_logic_vector(7 downto 0);

        UL_PUxCH_EN                 : in  std_logic_vector(7 downto 0);
        UL_PUxCH_ID                 : in  std_logic_array16(7 downto 0);
        UL_PRACH_EN                 : in  std_logic_vector(7 downto 0);
        UL_PRACH_ID                 : in  std_logic_array16(7 downto 0);

        UL_COMP_MODE                : in  std_logic;
        UL_IQ_WIDTH                 : in  std_logic_vector(3 downto 0);
        UL_COMP_METHOD              : in  std_logic_vector(3 downto 0);
        UL_SCS_CONFIG               : in  std_logic_vector(3 downto 0);
        UL_FFT_SIZE                 : in  std_logic_vector(3 downto 0);
        UL_PRB_PER_MTU              : in  std_logic_vector(9 downto 0);
        UL_PRB_PER_SYMBOL           : in  std_logic_vector(9 downto 0);

        CNT_FIFO_FULL               : out std_logic_vector(31 downto 0);

        CNT_PUxCH_TERMINATION       : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL0   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL1   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL2   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL3   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL4   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL5   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL6   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL7   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL8   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL9   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL10  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL11  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL12  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL13  : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL0      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL1      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL2      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL3      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL4      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL5      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL6      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL7      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL8      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL9      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL10     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL11     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL12     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL13     : out std_logic_vector(31 downto 0);

        CNT_PRACH_TERMINATION       : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL0   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL1   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL2   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL3   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL4   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL5   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL6   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL7   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL8   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL9   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL10  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL11  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL12  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL13  : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL0      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL1      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL2      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL3      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL4      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL5      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL6      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL7      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL8      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL9      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL10     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL11     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL12     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL13     : out std_logic_vector(31 downto 0);

        C_PLANE_VALID               : in  std_logic;
        C_PLANE_LAST                : in  std_logic;
        C_PLANE_KEEP                : in  std_logic_vector(3 downto 0);
        C_PLANE_DATA                : in  std_logic_vector(31 downto 0);
        C_PLANE_CH                  : in  std_logic_vector(2 downto 0);
        C_PLANE_CH_SUB              : in  std_logic_vector(3 downto 0);

        ULFE_FRAME_ID               : in  std_logic_vector(7 downto 0);
        ULFE_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        ULFE_SLOT_ID                : in  std_logic_vector(5 downto 0);
        ULFE_SYMBOL_ID              : in  std_logic_vector(5 downto 0);
        ULFE_START_RE               : in  std_logic_vector(15 downto 0);

        ULFE_VALID                  : in  std_logic_vector(MAX_CH-1 downto 0);
        ULFE_START                  : in  std_logic_vector(MAX_CH-1 downto 0);
        ULFE_LAST                   : in  std_logic_vector(MAX_CH-1 downto 0);
        ULFE_DATA_I                 : in  std_logic_array16(MAX_CH-1 downto 0);
        ULFE_DATA_Q                 : in  std_logic_array16(MAX_CH-1 downto 0);

        RAFE_FRAME_ID               : in  std_logic_vector(7 downto 0);
        RAFE_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        RAFE_SLOT_ID                : in  std_logic_vector(5 downto 0);
        RAFE_SYMBOL_ID              : in  std_logic_vector(5 downto 0);
        RAFE_START_RE               : in  std_logic_vector(15 downto 0);

        RAFE_VALID                  : in  std_logic_vector(MAX_CH-1 downto 0);
        RAFE_START                  : in  std_logic_vector(MAX_CH-1 downto 0);
        RAFE_LAST                   : in  std_logic_vector(MAX_CH-1 downto 0);
        RAFE_DATA_I                 : in  std_logic_array16(MAX_CH-1 downto 0);
        RAFE_DATA_Q                 : in  std_logic_array16(MAX_CH-1 downto 0);

        PUxCH_RB_INIT               : out std_logic;
        PUxCH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PUxCH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PUxCH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_APP_ACK     : in  std_logic;
        PUxCH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_SEC_ACK     : in  std_logic;

        PUxCH_RB_COMP_HDR           : out std_logic_vector(7 downto 0);

        PUxCH_RB_VALID              : out std_logic;
        PUxCH_RB_TICK               : out std_logic;
        PUxCH_RB_DATA_I             : out std_logic_vector(15 downto 0);
        PUxCH_RB_DATA_Q             : out std_logic_vector(15 downto 0);
        PUxCH_RB_USER               : out std_logic_vector(15 downto 0);

        PRACH_RB_INIT               : out std_logic;
        PRACH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PRACH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PRACH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_APP_ACK     : in  std_logic;
        PRACH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_SEC_ACK     : in  std_logic;

        PRACH_RB_COMP_HDR           : out std_logic_vector(7 downto 0);

        PRACH_RB_VALID              : out std_logic;
        PRACH_RB_TICK               : out std_logic;
        PRACH_RB_DATA_I             : out std_logic_vector(15 downto 0);
        PRACH_RB_DATA_Q             : out std_logic_vector(15 downto 0);
        PRACH_RB_USER               : out std_logic_vector(15 downto 0)
    );
    end component;

    signal puxch_rb_init            : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal puxch_rb_eaxc_id         : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal puxch_rb_sequence_id     : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal puxch_rb_header_app      : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal puxch_rb_header_app_ack  : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal puxch_rb_header_sec      : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal puxch_rb_header_sec_ack  : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal puxch_rb_comp_hdr        : std_logic_array8(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal puxch_rb_valid           : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal puxch_rb_tick            : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal puxch_rb_data_i          : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal puxch_rb_data_q          : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal puxch_rb_user            : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_init            : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal prach_rb_eaxc_id         : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_sequence_id     : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_header_app      : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_header_app_ack  : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal prach_rb_header_sec      : std_logic_array32(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_header_sec_ack  : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal prach_rb_comp_hdr        : std_logic_array8(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_valid           : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal prach_rb_tick            : std_logic_vector(UL_UNIT-1 downto 0) := (others => '0');
    signal prach_rb_data_i          : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_data_q          : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));
    signal prach_rb_user            : std_logic_array16(UL_UNIT-1 downto 0) := (others => (others => '0'));

    component O_RAN_FRAMER is
    generic (
        USAGE_C_PLANE               : boolean := true;
        USAGE_U_PLANE               : boolean := true
    );
    port (
        RST                         : in  std_logic;

        CLK_MAC                     : in  std_logic;
        CLK_BUS                     : in  std_logic;

        TX_PARAM_DST_MAC            : in  std_logic_vector(47 downto 0);
        TX_PARAM_SRC_MAC            : in  std_logic_vector(47 downto 0);
        TX_PARAM_VLAN0_MODE         : in  std_logic;
        TX_PARAM_VLAN0_TCI          : in  std_logic_vector(15 downto 0);
        TX_PARAM_VLAN1_MODE         : in  std_logic;
        TX_PARAM_VLAN1_TCI          : in  std_logic_vector(15 downto 0);

        TX_COMP_MODE                : in  std_logic;
        TX_COMP_EXP_OFFSET          : in  std_logic_vector(4 downto 0);
        TX_COMP_GAIN_OFFSET         : in  std_logic_vector(10 downto 0);
        TX_COMP_SCALE_GAIN_OFFSET   : in  std_logic_vector(3 downto 0);

        USAGE_TX_DATA_BUFFER        : out std_logic_vector(31 downto 0);
        USAGE_TX_C_PLANE_BUFFER     : out std_logic_vector(31 downto 0);
        USAGE_TX_U_PLANE_BUFFER     : out std_logic_vector(31 downto 0);

        TX_C_PLANE                  : out std_logic_vector(31 downto 0);
        TX_C_PLANE_LOST             : out std_logic_vector(31 downto 0);
        TX_U_PLANE                  : out std_logic_vector(31 downto 0);
        TX_U_PLANE_LOST             : out std_logic_vector(31 downto 0);

        MAC_TX_READY                : in  std_logic;
        MAC_TX_VALID                : out std_logic;
        MAC_TX_LAST                 : out std_logic;
        MAC_TX_KEEP                 : out std_logic_vector(7 downto 0);
        MAC_TX_DATA                 : out std_logic_vector(63 downto 0);

        RB_INIT                     : in  std_logic;
        RB_eAxC_ID                  : in  std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              : in  std_logic_vector(15 downto 0);
        RB_HEADER_APP               : in  std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           : out std_logic;
        RB_HEADER_SEC               : in  std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           : out std_logic;

        RB_COMP_HDR                 : in  std_logic_vector(7 downto 0);

        RB_VALID                    : in  std_logic;
        RB_START                    : in  std_logic;
        RB_TICK                     : in  std_logic;
        RB_LAST                     : in  std_logic;
        RB_DATA_I                   : in  std_logic_vector(15 downto 0);
        RB_DATA_Q                   : in  std_logic_vector(15 downto 0);
        RB_USER                     : in  std_logic_vector(15 downto 0)
    );
    end component;

--    signal tx0_packet_is_cp_dl      : std_logic_vector(UL_UNIT-1 downto 0);
--    signal tx0_packet_is_cp_ul      : std_logic_vector(UL_UNIT-1 downto 0);
--    signal tx0_packet_is_up_dl      : std_logic_vector(UL_UNIT-1 downto 0);
--    signal tx0_packet_is_up_ul      : std_logic_vector(UL_UNIT-1 downto 0);
--    signal tx0_packet_ch            : std_logic_array3(UL_UNIT-1 downto 0);
--    signal tx0_packet_ch_sub        : std_logic_array4(UL_UNIT-1 downto 0);
--    signal tx0_packet_subframe      : std_logic_array4(UL_UNIT-1 downto 0);
--    signal tx0_packet_slot          : std_logic_array6(UL_UNIT-1 downto 0);
--    signal tx0_packet_symbol        : std_logic_array6(UL_UNIT-1 downto 0);
--    signal tx1_packet_is_cp_dl      : std_logic_vector(UL_UNIT-1 downto 0);
--    signal tx1_packet_is_cp_ul      : std_logic_vector(UL_UNIT-1 downto 0);
--    signal tx1_packet_is_up_dl      : std_logic_vector(UL_UNIT-1 downto 0);
--    signal tx1_packet_is_up_ul      : std_logic_vector(UL_UNIT-1 downto 0);
--    signal tx1_packet_ch            : std_logic_array3(UL_UNIT-1 downto 0);
--    signal tx1_packet_ch_sub        : std_logic_array4(UL_UNIT-1 downto 0);
--    signal tx1_packet_subframe      : std_logic_array4(UL_UNIT-1 downto 0);
--    signal tx1_packet_slot          : std_logic_array6(UL_UNIT-1 downto 0);
--    signal tx1_packet_symbol        : std_logic_array6(UL_UNIT-1 downto 0);

    component MEASUREMENT is
    generic (
        NUM_TX                      : natural := 1
    );
    port (
        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK_245p76MHz               : in  std_logic;

        N_TA_OFFSET                 : in  std_logic_vector(15 downto 0);

        REF_10msec                  : in  std_logic;
        REF_SFN                     : in  std_logic_vector(7 downto 0);

        CAPTURE_PERIOD              : in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MAX_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MAX_UL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_UL_CP_RX            : in  std_logic_vector(21 downto 0);

        DL_CP_RX_CNT_CLEAR          : in  std_logic_vector(3 downto 0);
        DL_CP_RX_ON_TIME            : out std_logic_vector(63 downto 0);
        DL_CP_RX_EARLY              : out std_logic_vector(63 downto 0);
        DL_CP_RX_LATE               : out std_logic_vector(63 downto 0);
        DL_CP_RX_OUT_OF_RANGE       : out std_logic_vector(63 downto 0);

        DL_UP_RX_CNT_CLEAR          : in  std_logic_vector(3 downto 0);
        DL_UP_RX_ON_TIME            : out std_logic_vector(63 downto 0);
        DL_UP_RX_EARLY              : out std_logic_vector(63 downto 0);
        DL_UP_RX_LATE               : out std_logic_vector(63 downto 0);
        DL_UP_RX_OUT_OF_RANGE       : out std_logic_vector(63 downto 0);

        UL_CP_RX_CNT_CLEAR          : in  std_logic_vector(3 downto 0);
        UL_CP_RX_ON_TIME            : out std_logic_vector(63 downto 0);
        UL_CP_RX_EARLY              : out std_logic_vector(63 downto 0);
        UL_CP_RX_LATE               : out std_logic_vector(63 downto 0);
        UL_CP_RX_OUT_OF_RANGE       : out std_logic_vector(63 downto 0);

        UL_UP_TX_CNT_CLEAR          : in  std_logic_vector(7 downto 0);
        UL_UP_TX_TOTAL              : out std_logic_array64(7 downto 0);

        RX_PACKET_CLK               : in  std_logic;
        UPDATE_EN_OUT               : out std_logic;

        RX_PACKET_IS_CP_DL          : in  std_logic;
        RX_PACKET_IS_CP_UL          : in  std_logic;
        RX_PACKET_IS_UP_DL          : in  std_logic;
        RX_PACKET_SCS               : in  std_logic_vector(3 downto 0);
        RX_PACKET_FRAME_ID          : in  std_logic_vector(7 downto 0);
        RX_PACKET_SUBFRAME_ID       : in  std_logic_vector(3 downto 0);
        RX_PACKET_SLOT_ID           : in  std_logic_vector(5 downto 0);
        RX_PACKET_SYMBOL_ID         : in  std_logic_vector(5 downto 0);

        TX_PACKET_CLK               : in  std_logic;

        TX_PACKET_EXIST             : in  std_logic_vector(NUM_TX-1 downto 0)
    );
    end component;

    signal ul_up_tx_cnt_clear       : std_logic_array8(DL_UNIT-1 downto 0) := (others => (others => '0'));
    signal ul_up_tx_total           : std_logic_array8_array64(DL_UNIT-1 downto 0);
    signal pe0_transmitted          : std_logic_array2(DL_UNIT-1 downto 0) := (others => (others => '0'));
    signal output_update_en         : std_logic_vector(1 downto 0);
    
    component O_RAN_MPI is
    generic (
        OFFSET                      : std_logic_vector(3 downto 0) := x"3";
        DL_UNIT                     : natural := 6;
        UL_UNIT                     : natural := 6;
        MAX_CH_PER_UNIT             : natural := 2;
        MAX_ID_PER_CH               : natural := 1
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        CLK_MAC_RX                  : in  std_logic;
        CLK_MAC_TX                  : in  std_logic;
        CLK_BUS                     : in  std_logic;

        IGNORE_FRAME_ID             : out std_logic_vector(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PUxCH_RX    : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH_RX    : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH_TX    : in  std_logic_array8(UL_UNIT-1 downto 0);

        DL_PARAM_MAC                : out std_logic_array48(DL_UNIT-1 downto 0);
        DL_PARAM_ID0_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID0                : out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID1_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID1                : out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID2_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID2                : out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID3_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID3                : out std_logic_array8_array16(DL_UNIT-1 downto 0);

        DL_COMP_MODE                : out std_logic_vector(DL_UNIT-1 downto 0);
        DL_IQ_WIDTH                 : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_COMP_METHOD              : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_SCS_CONFIG               : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_FFT_SIZE                 : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_PRB_PER_SYMBOL           : out std_logic_array10(DL_UNIT-1 downto 0);
        DL_COMP_EXP_OFFSET          : out std_logic_array5(DL_UNIT-1 downto 0);

        UL_PARAM_DST_MAC            : out std_logic_array48(UL_UNIT-1 downto 0);
        UL_PARAM_SRC_MAC            : out std_logic_array48(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN0_MODE         : out std_logic_vector(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN0_TCI          : out std_logic_array16(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN1_MODE         : out std_logic_vector(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN1_TCI          : out std_logic_array16(UL_UNIT-1 downto 0);

        UL_COMP_MODE                : out std_logic_vector(UL_UNIT-1 downto 0);
        UL_IQ_WIDTH                 : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_COMP_METHOD              : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_SCS_CONFIG               : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_FFT_SIZE                 : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_PRB_PER_MTU              : out std_logic_array10(UL_UNIT-1 downto 0);
        UL_PRB_PER_SYMBOL           : out std_logic_array10(UL_UNIT-1 downto 0);
        UL_COMP_EXP_OFFSET          : out std_logic_array5(UL_UNIT-1 downto 0);
        UL_COMP_GAIN_OFFSET         : out std_logic_array11(UL_UNIT-1 downto 0);
        UL_COMP_SCALE_GAIN_OFFSET   : out std_logic_array4(UL_UNIT-1 downto 0);

        T2A_MAX_CP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        T2A_MIN_CP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        CP_DL_PERIOD                : out std_logic_array8(DL_UNIT-1 downto 0);

        CP_DL_CNT_CLEAR             : out std_logic_array4(DL_UNIT-1 downto 0);
        CP_DL_ON_TIME               : in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_EARLY                 : in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_LATE                  : in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_OUT_OF_RANGE          : in  std_logic_array64(DL_UNIT-1 downto 0);

        T2A_MAX_UP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        T2A_MIN_UP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        UP_DL_PERIOD                : out std_logic_array8(DL_UNIT-1 downto 0);

        UP_DL_CNT_CLEAR             : out std_logic_array4(DL_UNIT-1 downto 0);
        UP_DL_ON_TIME               : in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_EARLY                 : in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_LATE                  : in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_OUT_OF_RANGE          : in  std_logic_array64(DL_UNIT-1 downto 0);

        T2A_MAX_CP_UL               : out std_logic_array22(UL_UNIT-1 downto 0);
        T2A_MIN_CP_UL               : out std_logic_array22(UL_UNIT-1 downto 0);
        CP_UL_PERIOD                : out std_logic_array8(UL_UNIT-1 downto 0);

        CP_UL_CNT_CLEAR             : out std_logic_array4(UL_UNIT-1 downto 0);
        CP_UL_ON_TIME               : in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_EARLY                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_LATE                  : in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_OUT_OF_RANGE          : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP0_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP0_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP0_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP0_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP0_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP1_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP1_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP1_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP1_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP1_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

        DL_C_PLANE_BUFFER           : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_BUFFER           : in  std_logic_array32(DL_UNIT-1 downto 0);

        DL_INVALID_DST_MAC          : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ETHERTYPE        : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriVersion     : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriC           : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriMessage     : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_C_PLANE                  : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_C_PLANE_DROPPED          : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE                  : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_DROPPED          : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_LOST                     : in  std_logic_array32(DL_UNIT-1 downto 0);

        DL_C_PLANE_EXIST            : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_EXIST            : in  std_logic_array32(DL_UNIT-1 downto 0);

        RX_FAULT_ID_31_CH0          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH1          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH2          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH3          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH4          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH5          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH6          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH7          : in  std_logic_array4(DL_UNIT-1 downto 0);

--        UL_PUxCH_C_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PUxCH_C_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_PUxCH_C_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PRACH_C_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PRACH_C_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_PRACH_C_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_CMD_FIFO_FULL            : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_PUxCH_TERMINATION        : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL0    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL1    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL2    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL3    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL4    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL5    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL6    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL7    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL8    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL9    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL10   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL11   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL12   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL13   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL0   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL1   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL2   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL3   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL4   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL5   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL6   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL7   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL8   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL9   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL10  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL11  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL12  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL13  : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_PRACH_TERMINATION        : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL0    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL1    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL2    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL3    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL4    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL5    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL6    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL7    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL8    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL9    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL10   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL11   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL12   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL13   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL0   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL1   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL2   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL3   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL4   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL5   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL6   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL7   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL8   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL9   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL10  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL11  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL12  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL13  : in  std_logic_array32(UL_UNIT-1 downto 0);

        DL_UP_CP_RX_CORRUPT         : in  std_logic_vector(63 downto 0);
        DL_UP_CP_RX_CORRUPT_ECPRIVERSION_PAYLOADVERSION_PCID             : in  std_logic_vector(63 downto 0);
        DL_UP_CP_RX_CORRUPT_SECTIONID                                    : in  std_logic_vector(63 downto 0);
        DL_UP_CP_CNT_RX_PCID                                             : in std_logic_vector(63 downto 0);
        DL_UP_CP_CNT_RX_eCPRIVERSION                                     : in std_logic_vector(63 downto 0);
        DL_UP_CP_CNT_RX_PAYLOADVERSION                                   : in std_logic_vector(63 downto 0);
        DL_UP_CP_RX_CORRUPT_MEASUREMENT_PERIOD                           : out std_logic_array8(DL_UNIT-1 downto 0);        
                          
        
        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);    
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             : out std_logic
    );
    end component;

    signal rx_corrupt_measurement_period : std_logic_array8(DL_UNIT-1 downto 0);

    signal ignore_frame_id          : std_logic_vector(UL_UNIT-1 downto 0);
    signal ignore_frame_id_puxch_rx : std_logic_array8(UL_UNIT-1 downto 0);
    signal ignore_frame_id_puxch_tx : std_logic_array8(UL_UNIT-1 downto 0);
    signal ignore_frame_id_prach_rx : std_logic_array8(UL_UNIT-1 downto 0);
    signal ignore_frame_id_prach_tx : std_logic_array8(UL_UNIT-1 downto 0);
    signal dl_param_mac             : std_logic_array48(DL_UNIT-1 downto 0);
    signal dl_param_id0_en          : std_logic_array8(DL_UNIT-1 downto 0);
    signal dl_param_id0             : std_logic_array8_array16(DL_UNIT-1 downto 0);
    signal dl_param_id1_en          : std_logic_array8(DL_UNIT-1 downto 0);
    signal dl_param_id1             : std_logic_array8_array16(DL_UNIT-1 downto 0);
    signal dl_param_id2_en          : std_logic_array8(DL_UNIT-1 downto 0);
    signal dl_param_id2             : std_logic_array8_array16(DL_UNIT-1 downto 0);
    signal dl_param_id3_en          : std_logic_array8(DL_UNIT-1 downto 0);
    signal dl_param_id3             : std_logic_array8_array16(DL_UNIT-1 downto 0);
    signal dl_comp_mode             : std_logic_vector(DL_UNIT-1 downto 0);
    signal dl_iq_width              : std_logic_array4(DL_UNIT-1 downto 0);
    signal dl_comp_method           : std_logic_array4(DL_UNIT-1 downto 0);
    signal dl_scs_config            : std_logic_array4(DL_UNIT-1 downto 0);
    signal dl_fft_size              : std_logic_array4(DL_UNIT-1 downto 0);
    signal dl_prb_per_symbol        : std_logic_array10(DL_UNIT-1 downto 0);
    signal dl_comp_exp_offset       : std_logic_array5(DL_UNIT-1 downto 0);
    signal ul_param_dst_mac         : std_logic_array48(UL_UNIT-1 downto 0);
    signal ul_param_src_mac         : std_logic_array48(UL_UNIT-1 downto 0);
    signal ul_param_vlan0_mode      : std_logic_vector(UL_UNIT-1 downto 0);
    signal ul_param_vlan0_tci       : std_logic_array16(UL_UNIT-1 downto 0);
    signal ul_param_vlan1_mode      : std_logic_vector(UL_UNIT-1 downto 0);
    signal ul_param_vlan1_tci       : std_logic_array16(UL_UNIT-1 downto 0);
    signal ul_comp_mode             : std_logic_vector(UL_UNIT-1 downto 0);
    signal ul_comp_gain_offset      : std_logic_array11(UL_UNIT-1 downto 0);
    signal ul_comp_scale_gain_offset: std_logic_array4(UL_UNIT-1 downto 0);
    signal ul_comp_exp_offset       : std_logic_array5(UL_UNIT-1 downto 0);
    signal ul_iq_width              : std_logic_array4(UL_UNIT-1 downto 0);
    signal ul_comp_method           : std_logic_array4(UL_UNIT-1 downto 0);
    signal ul_scs_config            : std_logic_array4(UL_UNIT-1 downto 0);
    signal ul_fft_size              : std_logic_array4(UL_UNIT-1 downto 0);
    signal ul_prb_per_mtu           : std_logic_array10(UL_UNIT-1 downto 0);
    signal ul_prb_per_symbol        : std_logic_array10(UL_UNIT-1 downto 0);
    signal t2a_max_cp_dl            : std_logic_array22(DL_UNIT-1 downto 0);
    signal t2a_min_cp_dl            : std_logic_array22(DL_UNIT-1 downto 0);
    signal cp_dl_period             : std_logic_array8(DL_UNIT-1 downto 0);
    signal cp_dl_cnt_clear          : std_logic_array4(DL_UNIT-1 downto 0);
    signal cp_dl_on_time            : std_logic_array64(DL_UNIT-1 downto 0);
    signal cp_dl_early              : std_logic_array64(DL_UNIT-1 downto 0);
    signal cp_dl_late               : std_logic_array64(DL_UNIT-1 downto 0);
--    signal cp_dl_out_of_range       : std_logic_array64(DL_UNIT-1 downto 0);
    signal sum_cp_dl_on_time        : std_logic_array64(DL_UNIT-1 downto 0);
    signal sum_cp_dl_early          : std_logic_array64(DL_UNIT-1 downto 0);
    signal sum_cp_dl_late           : std_logic_array64(DL_UNIT-1 downto 0);
    signal t2a_max_up_dl            : std_logic_array22(DL_UNIT-1 downto 0);
    signal t2a_min_up_dl            : std_logic_array22(DL_UNIT-1 downto 0);
--    signal up_dl_period             : std_logic_array8(DL_UNIT-1 downto 0);
    signal up_dl_cnt_clear          : std_logic_array4(DL_UNIT-1 downto 0);
    signal up_dl_on_time            : std_logic_array64(DL_UNIT-1 downto 0);
    signal up_dl_early              : std_logic_array64(DL_UNIT-1 downto 0);
    signal up_dl_late               : std_logic_array64(DL_UNIT-1 downto 0);
--    signal up_dl_out_of_range       : std_logic_array64(DL_UNIT-1 downto 0);
    signal sum_up_dl_on_time        : std_logic_array64(DL_UNIT-1 downto 0);
    signal sum_up_dl_early          : std_logic_array64(DL_UNIT-1 downto 0);
    signal sum_up_dl_late           : std_logic_array64(DL_UNIT-1 downto 0);
    signal t2a_max_cp_ul            : std_logic_array22(UL_UNIT-1 downto 0);
    signal t2a_min_cp_ul            : std_logic_array22(UL_UNIT-1 downto 0);
--    signal cp_ul_period             : std_logic_array8(UL_UNIT-1 downto 0);
    signal cp_ul_cnt_clear          : std_logic_array4(UL_UNIT-1 downto 0);
    signal cp_ul_on_time            : std_logic_array64(UL_UNIT-1 downto 0);
    signal cp_ul_early              : std_logic_array64(UL_UNIT-1 downto 0);
    signal cp_ul_late               : std_logic_array64(UL_UNIT-1 downto 0);
--    signal cp_ul_out_of_range       : std_logic_array64(UL_UNIT-1 downto 0);
    signal sum_cp_ul_on_time        : std_logic_array64(UL_UNIT-1 downto 0);
    signal sum_cp_ul_early          : std_logic_array64(UL_UNIT-1 downto 0);
    signal sum_cp_ul_late           : std_logic_array64(UL_UNIT-1 downto 0);
--    signal ta3_min_up0_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal ta3_max_up0_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal up0_ul_period            : std_logic_array8(UL_UNIT-1 downto 0);
    signal up0_ul_cnt_clear         : std_logic_array4(UL_UNIT-1 downto 0);
    signal up0_ul_on_time           : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up0_ul_early             : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up0_ul_late              : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up0_ul_out_of_range      : std_logic_array64(UL_UNIT-1 downto 0);
--    signal ta3_min_up1_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal ta3_max_up1_ul           : std_logic_array22(UL_UNIT-1 downto 0);
--    signal up1_ul_period            : std_logic_array8(UL_UNIT-1 downto 0);
    signal up1_ul_cnt_clear         : std_logic_array4(UL_UNIT-1 downto 0);
    signal up1_ul_on_time           : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up1_ul_early             : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up1_ul_late              : std_logic_array64(UL_UNIT-1 downto 0);
--    signal up1_ul_out_of_range      : std_logic_array64(UL_UNIT-1 downto 0);
    signal dl_data_buffer           : std_logic_array32(DL_UNIT-1 downto 0);
--    signal dl_c_plane_buffer        : std_logic_array32(DL_UNIT-1 downto 0);
--    signal dl_u_plane_buffer        : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_invalid_dst_mac       : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_invalid_ethertype     : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_invalid_ecpriversion  : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_invalid_ecpric        : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_invalid_ecprimessage  : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_c_plane               : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_c_plane_dropped       : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_u_plane               : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_u_plane_dropped       : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_lost                  : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_c_plane_exist         : std_logic_array32(DL_UNIT-1 downto 0);
    signal dl_u_plane_exist         : std_logic_array32(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch0       : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch1       : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch2       : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch3       : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch4       : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch5       : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch6       : std_logic_array4(DL_UNIT-1 downto 0);
    signal rx_fault_id_31_ch7       : std_logic_array4(DL_UNIT-1 downto 0);
--    signal ul_puxch_c_plane_buffer  : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_puxch_u_plane_buffer  : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_puxch_c_plane         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_puxch_c_plane_lost    : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_puxch_u_plane         : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_puxch_u_plane_lost    : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_prach_c_plane_buffer  : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_prach_u_plane_buffer  : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_prach_c_plane         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ul_prach_c_plane_lost    : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_prach_u_plane         : std_logic_array32(UL_UNIT-1 downto 0);
    signal ul_prach_u_plane_lost    : std_logic_array32(UL_UNIT-1 downto 0);

    signal ul_cmd_fifo_full         : std_logic_array32(UL_UNIT-1 downto 0);

    signal puxch_termination        : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol0      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol1      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol2      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol3      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol4      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol5      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol6      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol7      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol8      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol9      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol10     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol11     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol12     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cpsec_symbol13     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol0      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol1      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol2      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol3      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol4      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol5      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol6      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol7      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol8      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol9      : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol10     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol11     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol12     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_uppkt_symbol13     : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol0    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol1    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol2    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol3    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol4    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol5    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol6    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol7    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol8    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol9    : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol10   : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol11   : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol12   : std_logic_array32(UL_UNIT-1 downto 0);
    signal puxch_cq_full_symbol13   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol0   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol1   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol2   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol3   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol4   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol5   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol6   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol7   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol8   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol9   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol10  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol11  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol12  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_puxch_cq_symbol13  : std_logic_array32(UL_UNIT-1 downto 0);

    signal prach_termination        : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol0      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol1      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol2      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol3      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol4      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol5      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol6      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol7      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol8      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol9      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol10     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol11     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol12     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cpsec_symbol13     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol0      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol1      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol2      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol3      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol4      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol5      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol6      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol7      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol8      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol9      : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol10     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol11     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol12     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_uppkt_symbol13     : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol0    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol1    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol2    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol3    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol4    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol5    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol6    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol7    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol8    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol9    : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol10   : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol11   : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol12   : std_logic_array32(UL_UNIT-1 downto 0);
    signal prach_cq_full_symbol13   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol0   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol1   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol2   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol3   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol4   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol5   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol6   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol7   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol8   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol9   : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol10  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol11  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol12  : std_logic_array32(UL_UNIT-1 downto 0);
    signal usage_prach_cq_symbol13  : std_logic_array32(UL_UNIT-1 downto 0);
    
    signal  w_system_mode           : std_logic_vector(1 downto 0);

    component ORAN_FILTER_CORE_RXCORRUPT is
    generic (
        DIRECTION                   : string := "DL";                           -- "DL", "UL", "BOTH"
        MAX_ID                      : natural := 8;
        USAGE_ID                    : std_logic_vector(7 downto 0) := "11111111"
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;                            -- 156.25/390.625-MHz

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        PARAM_ID0_EN                : in  std_logic;
        PARAM_ID0                   : in  std_logic_vector(15 downto 0);
        PARAM_ID1_EN                : in  std_logic;
        PARAM_ID1                   : in  std_logic_vector(15 downto 0);
        PARAM_ID2_EN                : in  std_logic;
        PARAM_ID2                   : in  std_logic_vector(15 downto 0);
        PARAM_ID3_EN                : in  std_logic;
        PARAM_ID3                   : in  std_logic_vector(15 downto 0);
        PARAM_ID4_EN                : in  std_logic;
        PARAM_ID4                   : in  std_logic_vector(15 downto 0);
        PARAM_ID5_EN                : in  std_logic;
        PARAM_ID5                   : in  std_logic_vector(15 downto 0);
        PARAM_ID6_EN                : in  std_logic;
        PARAM_ID6                   : in  std_logic_vector(15 downto 0);
        PARAM_ID7_EN                : in  std_logic;
        PARAM_ID7                   : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- Data bus
--------------------------------------------------------------------------------

        IN_VALID                    : in  std_logic_vector(1 downto 0);
        IN_LAST                     : in  std_logic;
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);

        RX_CORRUPT_PCID_eCPRIVERSION_PAYLOADVERSION: out std_logic;
        RX_CORRUPT_PCID                             : out std_logic;
        RX_CORRUPT_eCPRIVERSION                     : out std_logic;
        RX_CORRUPT_PAYLOADVERSION                   : out std_logic
    );
    end component;
    
    component rx_corrupt_counter is
    generic (
		DL_UNIT	: natural := 2
	);
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK_245p76MHz               : in  std_logic;                            -- 245.76-MHz

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        WINDOW_PERIOD               : in  std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Synchronization
--------------------------------------------------------------------------------

        REF_10msec                  : in  std_logic;                            -- Longer than 1-clocks@245.76-MHz
	    UPDATE_EN_IN                   : in std_logic;

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------
		RX_CORRUPT_PCID_eCPRIVERSION_PAYLOADVERSION	: in std_logic;
        RX_CORRUPT_SECTIONID        				: in std_logic_vector(DL_UNIT-1 downto 0);
        RX_CORRUPT_PCID                             : in std_logic;
        RX_CORRUPT_eCPRIVERSION                     : in std_logic;
        RX_CORRUPT_PAYLOADVERSION                   : in std_logic;
        
        CNT_RX_CORRUPT                                          : out std_logic_vector(63 downto 0);
        CNT_RX_SECTIONID                                        : out std_logic_vector(63 downto 0);
        CNT_RX_PCID_eCPRIVERSION_PAYLOADVERSION                 : out std_logic_vector(63 downto 0);
        CNT_RX_PCID                                             : out std_logic_vector(63 downto 0);
        CNT_RX_eCPRIVERSION                                     : out std_logic_vector(63 downto 0);
        CNT_RX_PAYLOADVERSION                                   : out std_logic_vector(63 downto 0)
        
    );
    end component;


--attribute MARK_DEBUG : string;

--attribute MARK_DEBUG of dl_rb_valid: signal is "TRUE";
--attribute MARK_DEBUG of dl_rb_start: signal is "TRUE";
--attribute MARK_DEBUG of dl_rb_tick: signal is "TRUE";
--attribute MARK_DEBUG of dl_rb_last: signal is "TRUE";
--attribute MARK_DEBUG of dl_rb_data_i: signal is "TRUE";
--attribute MARK_DEBUG of dl_rb_data_q: signal is "TRUE";

--attribute MARK_DEBUG of dlfe_k0: signal is "TRUE";
--attribute MARK_DEBUG of dlfe_frame_sync: signal is "TRUE";
--attribute MARK_DEBUG of dlfe_frame_index: signal is "TRUE";
                                
--attribute MARK_DEBUG of dlfe_valid: signal is "TRUE";                                                            
--attribute MARK_DEBUG of dlfe_re_mask: signal is "TRUE";                                                                     
--attribute MARK_DEBUG of dlfe_data: signal is "TRUE";

    -- ILA : DL CC0 (unit 0)
    signal dbg_dl_rb_valid          : std_logic;
    signal dbg_dl_rb_frame_id       : std_logic_vector( 7 downto 0);
    signal dbg_dl_rb_subframe_id    : std_logic_vector( 3 downto 0);
    signal dbg_dl_rb_symbol_id      : std_logic_vector( 5 downto 0);
    signal dbg_dlfe_frame_sync      : std_logic;
    signal dbg_dlfe_frame_index     : std_logic_vector( 7 downto 0);
    signal dbg_dlfe_valid           : std_logic_vector( 3 downto 0);
    signal dbg_dlfe_data            : std_logic_vector(63 downto 0);

    attribute MARK_DEBUG : string;
    attribute MARK_DEBUG of dbg_dl_rb_valid         : signal is "TRUE";
    attribute MARK_DEBUG of dbg_dl_rb_frame_id      : signal is "TRUE";
    attribute MARK_DEBUG of dbg_dl_rb_subframe_id   : signal is "TRUE";
    attribute MARK_DEBUG of dbg_dl_rb_symbol_id     : signal is "TRUE";
    attribute MARK_DEBUG of dbg_dlfe_frame_sync     : signal is "TRUE";
    attribute MARK_DEBUG of dbg_dlfe_frame_index    : signal is "TRUE";
    attribute MARK_DEBUG of dbg_dlfe_valid          : signal is "TRUE";
    attribute MARK_DEBUG of dbg_dlfe_data           : signal is "TRUE";

begin

    dbg_dl_rb_valid         <= dl_rb_valid(0);
    dbg_dl_rb_frame_id      <= dl_rb_frame_id(0);
    dbg_dl_rb_subframe_id   <= dl_rb_subframe_id(0);
    dbg_dl_rb_symbol_id     <= dl_rb_symbol_id(0);
    dbg_dlfe_frame_sync     <= dlfe_frame_sync(0);
    dbg_dlfe_frame_index    <= dlfe_frame_index(0);
    dbg_dlfe_valid          <= dlfe_valid(0);
    dbg_dlfe_data           <= dlfe_data(0)(63 downto 0);

    w_system_mode   <= DLFE_CC1_SYSTEM_MODE & DLFE_CC0_SYSTEM_MODE;
--------------------------------------------------------------------------------
-- Port mapping (MAC <-> De-framer, DL 2-antenna, 2CC)
--------------------------------------------------------------------------------    
     
    mac_rx_valid(0) <= MAC_CC0_RX_VALID;
    mac_rx_last(0)  <= MAC_CC0_RX_LAST ;
    mac_rx_keep(0)  <= MAC_CC0_RX_KEEP ;
    mac_rx_data(0)  <= MAC_CC0_RX_DATA ;
                                       
    mac_rx_valid(1) <= MAC_CC1_RX_VALID;
    mac_rx_last(1)  <= MAC_CC1_RX_LAST ;
    mac_rx_keep(1)  <= MAC_CC1_RX_KEEP ;
    mac_rx_data(1)  <= MAC_CC1_RX_DATA ;

--------------------------------------------------------------------------------
-- Port mapping (MAC <-> Framer, UL 2-antenna, 2CC)
--------------------------------------------------------------------------------

--    mac_tx_ready(0)     <= MAC_CC0_PUxCH_READY;
--    MAC_CC0_PUxCH_VALID <= mac_tx_valid(0);
--    MAC_CC0_PUxCH_LAST  <= mac_tx_last(0);
--    MAC_CC0_PUxCH_KEEP  <= mac_tx_keep(0);
--    MAC_CC0_PUxCH_DATA  <= mac_tx_data(0);

--    mac_tx_ready(1)     <= MAC_CC0_PRACH_READY;
--    MAC_CC0_PRACH_VALID <= mac_tx_valid(1);
--    MAC_CC0_PRACH_LAST  <= mac_tx_last(1);
--    MAC_CC0_PRACH_KEEP  <= mac_tx_keep(1);
--    MAC_CC0_PRACH_DATA  <= mac_tx_data(1);

--    mac_tx_ready(2)     <= MAC_CC1_PUxCH_READY;
--    MAC_CC1_PUxCH_VALID <= mac_tx_valid(2);
--    MAC_CC1_PUxCH_LAST  <= mac_tx_last(2);
--    MAC_CC1_PUxCH_KEEP  <= mac_tx_keep(2);
--    MAC_CC1_PUxCH_DATA  <= mac_tx_data(2);

--    mac_tx_ready(3)     <= MAC_CC1_PRACH_READY;
--    MAC_CC1_PRACH_VALID <= mac_tx_valid(3);
--    MAC_CC1_PRACH_LAST  <= mac_tx_last(3);
--    MAC_CC1_PRACH_KEEP  <= mac_tx_keep(3);
--    MAC_CC1_PRACH_DATA  <= mac_tx_data(3);
    
    mux_mac_tx_ready     <= MAC_CC_TX_READY;
    MAC_CC_TX_VALID      <= mux_mac_tx_valid;
    MAC_CC_TX_LAST       <= mux_mac_tx_last;
    MAC_CC_TX_KEEP       <= mux_mac_tx_keep;
    MAC_CC_TX_DATA       <= mux_mac_tx_data;
    
    mac_tx_valid(4)  <= '0';
    mac_tx_last (4)  <= '0';
    mac_tx_keep (4)  <= (others => '0');
    mac_tx_data (4)  <= (others => '0');    
    mac_tx_valid(5)  <= '0';
    mac_tx_last (5)  <= '0';
    mac_tx_keep (5)  <= (others => '0');
    mac_tx_data (5)  <= (others => '0');

--------------------------------------------------------------------------------
-- UL mux
--------------------------------------------------------------------------------

    u_FRAMER_INTERCONNECT : O_RAN_FRAMER_INTERCONNECT
    generic map(
        NUM_PORT                    => 6                                        --: natural := 8
    )
    port map(
        CLK                         => CLK_MAC_TX                              ,--: in  std_logic;
        RST                         => ARESET_TX(0)                            ,--: in  std_logic;

        FRAMER_TX_TREADY            => mac_tx_ready                         ,--: out std_logic_vector(NUM_PORT-1 downto 0);
        FRAMER_TX_TVALID            => mac_tx_valid                         ,--: in  std_logic_vector(NUM_PORT-1 downto 0);
        FRAMER_TX_TLAST             => mac_tx_last                          ,--: in  std_logic_vector(NUM_PORT-1 downto 0);
        FRAMER_TX_TKEEP             => mac_tx_keep                          ,--: in  std_logic_array8(NUM_PORT-1 downto 0);
        FRAMER_TX_TDATA             => mac_tx_data                          ,--: in  std_logic_array64(NUM_PORT-1 downto 0);

        UL_TREADY                   => mux_mac_tx_ready                         ,--: in  std_logic;
        UL_TVALID                   => mux_mac_tx_valid                         ,--: out std_logic;
        UL_TLAST                    => mux_mac_tx_last                          ,--: out std_logic;
        UL_TKEEP                    => mux_mac_tx_keep                          ,--: out std_logic_vector(7 downto 0);
        UL_TDATA                    => mux_mac_tx_data                           --: out std_logic_vector(63 downto 0)
    );

--------------------------------------------------------------------------------
-- Port mapping (QM_TOP <-> LPHY, DL 2-antenna, 2CC)
--------------------------------------------------------------------------------

    dl_sync_advance(0)      <= DL_CC0_SYNC_ADVANCE;       
    dl_sync_advance(1)      <= DL_CC1_SYNC_ADVANCE;            
    ul_sync_retard(0)       <= UL_CC0_SYNC_RETARD;        
    ul_sync_retard(1)       <= UL_CC1_SYNC_RETARD;        

    TDD_SYMBOL_SYNC         <= tdd_sym_sync(0);     
    TDD_SYMBOL_INDEX        <= tdd_sym_index(0);    
    TDD_DL_EN               <= tdd_dl_enable(1) & tdd_dl_enable(0);
    TDD_UL_EN               <= tdd_ul_enable(1) & tdd_ul_enable(0);
       
    dlfe_k0(0)              <= DLFE_CC0_K0;                 
    dlfe_k0(1)              <= DLFE_CC1_K0;                 
    dlfe_nRE(0)             <= DLFE_CC0_nRE;               
    dlfe_nRE(1)             <= DLFE_CC1_nRE;               
    dlfe_nFFT(0)            <= DLFE_CC0_nFFT;
    dlfe_nFFT(1)            <= DLFE_CC1_nFFT;

    DLFE_CC0_FRAME_SYNC     <= dlfe_frame_sync(0);         
    DLFE_CC0_FRAME_INDEX    <= dlfe_frame_index(0);           
    DLFE_CC0_VALID          <= dlfe_valid(0);                                                                                 
    DLFE_CC0_RE_MASK        <= dlfe_re_mask(0);        
    DLFE_CC0_DATA           <= dlfe_data(0);                                              

    DLFE_CC1_FRAME_SYNC     <= dlfe_frame_sync(1);         
    DLFE_CC1_FRAME_INDEX    <= dlfe_frame_index(1);           
    DLFE_CC1_VALID          <= dlfe_valid(1);                                                                                 
    DLFE_CC1_RE_MASK        <= dlfe_re_mask(1);        
    DLFE_CC1_DATA           <= dlfe_data(1);      
    
    RAFE_CC0_FRAMES_SYNC    <= rafe_frame_sync(0);          
    RAFE_CC0_FILTER_INDEX   <= rafe_filter_index(0) & rafe_filter_index(0)          & rafe_filter_index(0) & rafe_filter_index(0);        
    RAFE_CC0_TIME_OFFSET    <= rafe_time_offset(0) & rafe_time_offset(0)            & rafe_time_offset(0) & rafe_time_offset(0);         
    RAFE_CC0_FRAME_STRUCTURE<= rafe_frame_structure(0) & rafe_frame_structure(0)    & rafe_frame_structure(0) & rafe_frame_structure(0);     
    RAFE_CC0_CPLENGTH       <= rafe_cplength(0) & rafe_cplength(0)                  & rafe_cplength(0) & rafe_cplength(0);            
    RAFE_CC0_FREQ_OFFSET    <= rafe_freq_offset(0) & rafe_freq_offset(0)            & rafe_freq_offset(0) & rafe_freq_offset(0);         
    RAFE_CC0_START_PRBC     <= rafe_start_prbc(0) & rafe_start_prbc(0)              & rafe_start_prbc(0) & rafe_start_prbc(0);
    RAFE_CC0_NUM_PSYMBOL    <= rafe_num_psymbol(0) & rafe_num_psymbol(0)            & rafe_num_psymbol(0) & rafe_num_psymbol(0);         
    RAFE_CC0_NUM_PRBC       <= rafe_num_prbc(0) & rafe_num_prbc(0)                  & rafe_num_prbc(0) & rafe_num_prbc(0); 
    RAFE_CC0_NUM_RO         <= rafe_num_ro(0) & rafe_num_ro(0)                      & rafe_num_ro(0) & rafe_num_ro(0);
    
    RAFE_CC1_FRAMES_SYNC    <= rafe_frame_sync(1);          
    RAFE_CC1_FILTER_INDEX   <= rafe_filter_index(1) & rafe_filter_index(1) & rafe_filter_index(1) & rafe_filter_index(1);        
    RAFE_CC1_TIME_OFFSET    <= rafe_time_offset(1) & rafe_time_offset(1)         & rafe_time_offset(1) & rafe_time_offset(1)            ;         
    RAFE_CC1_FRAME_STRUCTURE<= rafe_frame_structure(1) & rafe_frame_structure(1) & rafe_frame_structure(1) & rafe_frame_structure(1)    ;     
    RAFE_CC1_CPLENGTH       <= rafe_cplength(1) & rafe_cplength(1)               & rafe_cplength(1) & rafe_cplength(1)                  ;            
    RAFE_CC1_FREQ_OFFSET    <= rafe_freq_offset(1) & rafe_freq_offset(1)         & rafe_freq_offset(1) & rafe_freq_offset(1)            ;
    RAFE_CC1_START_PRBC     <= rafe_start_prbc(1) & rafe_start_prbc(1)           & rafe_start_prbc(1) & rafe_start_prbc(1)              ;         
    RAFE_CC1_NUM_PSYMBOL    <= rafe_num_psymbol(1) & rafe_num_psymbol(1)         & rafe_num_psymbol(1) & rafe_num_psymbol(1)            ;         
    RAFE_CC1_NUM_PRBC       <= rafe_num_prbc(1) & rafe_num_prbc(1)               & rafe_num_prbc(1) & rafe_num_prbc(1)                  ; 
    RAFE_CC1_NUM_RO         <= rafe_num_ro(1) & rafe_num_ro(1)                   & rafe_num_ro(1) & rafe_num_ro(1)                      ;

--------------------------------------------------------------------------------
-- Port mapping (UL_DM <-> LPHY, UL 2-antenna, 2CC)
--------------------------------------------------------------------------------

    ulfe_frame_id(0)        <= ULFE_CC0_FRAME_ID;
    ulfe_subframe_id(0)     <= ULFE_CC0_SUBFRAME_ID;
    ulfe_slot_id(0)         <= ULFE_CC0_SLOT_ID;
    ulfe_symbol_id(0)       <= ULFE_CC0_SYMBOL_ID;
    ulfe_start_re(0)        <= ULFE_CC0_START_RE(1*16-1 downto 0*16);
    ulfe_valid(0)           <= ULFE_CC0_VALID((UL_NUM_ANT-1) downto 0);
    ulfe_start(0)           <= ULFE_CC0_START((UL_NUM_ANT-1) downto 0);
    ulfe_last(0)            <= ULFE_CC0_LAST((UL_NUM_ANT-1) downto 0);
    ulfe_data_i(0)(0)       <= ULFE_CC0_DATA(0*128+31 downto 0*128+16);
    ulfe_data_q(0)(0)       <= ULFE_CC0_DATA(0*128+15 downto 0*128+0);
    ulfe_data_i(0)(1)       <= ULFE_CC0_DATA(0*128+63 downto 0*128+48);
    ulfe_data_q(0)(1)       <= ULFE_CC0_DATA(0*128+47 downto 0*128+32);
    ulfe_data_i(0)(2)       <= ULFE_CC0_DATA(0*128+95 downto 0*128+80);
    ulfe_data_q(0)(2)       <= ULFE_CC0_DATA(0*128+79 downto 0*128+64);
    ulfe_data_i(0)(3)       <= ULFE_CC0_DATA(0*128+127 downto 0*128+112);
    ulfe_data_q(0)(3)       <= ULFE_CC0_DATA(0*128+111 downto 0*128+96);

    ulfe_frame_id(1)        <= ULFE_CC1_FRAME_ID;
    ulfe_subframe_id(1)     <= ULFE_CC1_SUBFRAME_ID;
    ulfe_slot_id(1)         <= ULFE_CC1_SLOT_ID;
    ulfe_symbol_id(1)       <= ULFE_CC1_SYMBOL_ID;
    ulfe_start_re(1)        <= ULFE_CC1_START_RE(1*16-1 downto 0*16);
    ulfe_valid(1)           <= ULFE_CC1_VALID((UL_NUM_ANT-1) downto 0);
    ulfe_start(1)           <= ULFE_CC1_START((UL_NUM_ANT-1) downto 0);
    ulfe_last(1)            <= ULFE_CC1_LAST((UL_NUM_ANT-1) downto 0);
    ulfe_data_i(1)(0)       <= ULFE_CC1_DATA(0*128+31 downto 0*128+16);    
    ulfe_data_q(1)(0)       <= ULFE_CC1_DATA(0*128+15 downto 0*128+0);     
    ulfe_data_i(1)(1)       <= ULFE_CC1_DATA(0*128+63 downto 0*128+48);    
    ulfe_data_q(1)(1)       <= ULFE_CC1_DATA(0*128+47 downto 0*128+32);    
    ulfe_data_i(1)(2)       <= ULFE_CC1_DATA(0*128+95 downto 0*128+80);    
    ulfe_data_q(1)(2)       <= ULFE_CC1_DATA(0*128+79 downto 0*128+64);    
    ulfe_data_i(1)(3)       <= ULFE_CC1_DATA(0*128+127 downto 0*128+112);  
    ulfe_data_q(1)(3)       <= ULFE_CC1_DATA(0*128+111 downto 0*128+96);   

    rafe_frame_id(0)        <= RAFE_CC0_FRAME_ID;
    rafe_subframe_id(0)     <= RAFE_CC0_SUBFRAME_ID;
    rafe_slot_id(0)         <= RAFE_CC0_SLOT_ID;
    rafe_symbol_id(0)       <= RAFE_CC0_SYMBOL_ID;
    rafe_start_re(0)        <= RAFE_CC0_START_RE(1*16-1 downto 0*16);
    rafe_valid(0)           <= RAFE_CC0_VALID((UL_NUM_ANT-1) downto 0);
    rafe_start(0)           <= RAFE_CC0_START((UL_NUM_ANT-1) downto 0);
    rafe_last(0)            <= RAFE_CC0_LAST ((UL_NUM_ANT-1) downto 0);
    rafe_data_i(0)(0)       <= RAFE_CC0_DATA(0*128+31 downto 0*128+16);  
    rafe_data_q(0)(0)       <= RAFE_CC0_DATA(0*128+15 downto 0*128+0);   
    rafe_data_i(0)(1)       <= RAFE_CC0_DATA(0*128+63 downto 0*128+48);  
    rafe_data_q(0)(1)       <= RAFE_CC0_DATA(0*128+47 downto 0*128+32);  
    rafe_data_i(0)(2)       <= RAFE_CC0_DATA(0*128+95 downto 0*128+80);  
    rafe_data_q(0)(2)       <= RAFE_CC0_DATA(0*128+79 downto 0*128+64);  
    rafe_data_i(0)(3)       <= RAFE_CC0_DATA(0*128+127 downto 0*128+112);
    rafe_data_q(0)(3)       <= RAFE_CC0_DATA(0*128+111 downto 0*128+96); 

    rafe_frame_id(1)        <= RAFE_CC1_FRAME_ID;
    rafe_subframe_id(1)     <= RAFE_CC1_SUBFRAME_ID;
    rafe_slot_id(1)         <= RAFE_CC1_SLOT_ID;
    rafe_symbol_id(1)       <= RAFE_CC1_SYMBOL_ID;
    rafe_start_re(1)        <= RAFE_CC1_START_RE(1*16-1 downto 0*16);
    rafe_valid(1)           <= RAFE_CC1_VALID((UL_NUM_ANT-1) downto 0);
    rafe_start(1)           <= RAFE_CC1_START((UL_NUM_ANT-1) downto 0);
    rafe_last(1)            <= RAFE_CC1_LAST ((UL_NUM_ANT-1) downto 0);
    rafe_data_i(1)(0)       <= RAFE_CC1_DATA(0*128+31 downto 0*128+16);  
    rafe_data_q(1)(0)       <= RAFE_CC1_DATA(0*128+15 downto 0*128+0);   
    rafe_data_i(1)(1)       <= RAFE_CC1_DATA(0*128+63 downto 0*128+48);  
    rafe_data_q(1)(1)       <= RAFE_CC1_DATA(0*128+47 downto 0*128+32);  
    rafe_data_i(1)(2)       <= RAFE_CC1_DATA(0*128+95 downto 0*128+80);  
    rafe_data_q(1)(2)       <= RAFE_CC1_DATA(0*128+79 downto 0*128+64);  
    rafe_data_i(1)(3)       <= RAFE_CC1_DATA(0*128+127 downto 0*128+112);
    rafe_data_q(1)(3)       <= RAFE_CC1_DATA(0*128+111 downto 0*128+96); 

--------------------------------------------------------------------------------
-- RX_CORRUPT PCID checking: 2CC 4T4R (8eaxc, incase more eaxc is needed => need to update this component to extend the mapping)
--------------------------------------------------------------------------------

    u_FILTER_CORRUPT_PCID_2CC4T4R : ORAN_FILTER_CORE_RXCORRUPT
    generic map(
        DIRECTION                   => "DL"                                    ,--: string := "DL";
        MAX_ID                      => MAX_CH_PER_UNIT*2                                  ,--: natural := 8;
        USAGE_ID                    => (others => '1')                          --: std_logic_vector(3 downto 0) := "11111111"
    )
    port map(
        CLK                         => CLK_MAC_RX                                     ,--: in  std_logic;

        PARAM_ID0_EN                => dl_param_id0_en(0)(0)                       ,--: in  std_logic;
        PARAM_ID0                   => dl_param_id0(0)(0)                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID1_EN                => dl_param_id0_en(0)(1)                       ,--: in  std_logic;
        PARAM_ID1                   => dl_param_id0(0)(1)                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID2_EN                => dl_param_id0_en(0)(2)                       ,--: in  std_logic;
        PARAM_ID2                   => dl_param_id0(0)(2)                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID3_EN                => dl_param_id0_en(0)(3)                       ,--: in  std_logic;
        PARAM_ID3                   => dl_param_id0(0)(3)                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID4_EN                => dl_param_id0_en(1)(0)                       ,--: in  std_logic;
        PARAM_ID4                   => dl_param_id0(1)(0)                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID5_EN                => dl_param_id0_en(1)(1)                       ,--: in  std_logic;
        PARAM_ID5                   => dl_param_id0(1)(1)                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID6_EN                => dl_param_id0_en(1)(2)                       ,--: in  std_logic;
        PARAM_ID6                   => dl_param_id0(1)(2)                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID7_EN                => dl_param_id0_en(1)(3)                       ,--: in  std_logic;
        PARAM_ID7                   => dl_param_id0(1)(3)                          ,--: in  std_logic_vector(15 downto 0);

        IN_VALID                    => s_mac_header_removed_out_valid(0)(1 downto 0)            ,--: in  std_logic_vector(1 downto 0);
        IN_LAST                     => s_mac_header_removed_out_last(0)                         ,--: in  std_logic;
        IN_KEEP                     => s_mac_header_removed_out_keep(0)                         ,--: in  std_logic_vector(7 downto 0);
        IN_DATA                     => s_mac_header_removed_out_data(0)                         ,--: in  std_logic_vector(63 downto 0);

        RX_CORRUPT_PCID_eCPRIVERSION_PAYLOADVERSION => s_rx_corrupt_ecpriversion_payloadversion_pcid,
        RX_CORRUPT_PCID                             => s_rx_corrupt_pcid           , 
        RX_CORRUPT_eCPRIVERSION                     => s_rx_corrupt_ecpri_version  ,
        RX_CORRUPT_PAYLOADVERSION                   => s_rx_corrupt_payload_version
        
        
    );

    u_RX_CORRUPT_CNT: rx_corrupt_counter 
    generic map (
		DL_UNIT	  => DL_UNIT --: natural := 2
	)
    port map (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => RST_CPUIF                               ,--: in  std_logic;
    
        CLK_245p76MHz               => CLK_BUS                                 ,--: in  std_logic;                            -- 245.76-MHz
    
--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------
    
        WINDOW_PERIOD               => rx_corrupt_measurement_period(0)                               ,--: in  std_logic_vector(7 downto 0);
            
--------------------------------------------------------------------------------
-- Synchronization
--------------------------------------------------------------------------------

        REF_10msec                  => FRAME_SYNC                               ,--: in  std_logic;                            -- Longer than 1-clocks@245.76-MHz
        UPDATE_EN_IN                => output_update_en(0)                      ,--: in std_logic;
    
--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------
		RX_CORRUPT_PCID_eCPRIVERSION_PAYLOADVERSION	=> s_rx_corrupt_ecpriversion_payloadversion_pcid      ,--: in std_logic;
        RX_CORRUPT_SECTIONID        				=> rx_corrupt_sectionid                               ,--: in std_logic_vector(DL_UNIT-1 downto 0);
        RX_CORRUPT_PCID                             => s_rx_corrupt_pcid                                  ,
        RX_CORRUPT_eCPRIVERSION                     => s_rx_corrupt_ecpri_version                         ,
        RX_CORRUPT_PAYLOADVERSION                   => s_rx_corrupt_payload_version                       ,
            
        CNT_RX_CORRUPT                              => cnt_rx_corrupt                                     ,--: out std_logic_vector(63 downto 0)
        CNT_RX_SECTIONID                            => cnt_rx_corrupt_sectionid                           ,
        CNT_RX_PCID_eCPRIVERSION_PAYLOADVERSION     => cnt_rx_corrupt_ecpriversion_payloadversion_pcid    ,
        CNT_RX_PCID                                 => cnt_rx_corrupt_pcid                                ,
        CNT_RX_eCPRIVERSION                         => cnt_rx_corrupt_ecpriversion                        ,      
        CNT_RX_PAYLOADVERSION                       => cnt_rx_corrupt_payloadversion                    
    );

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_DL : for i in DL_UNIT-1 downto 0 generate
    u_DEFRAMER : O_RAN_DEFRAMER
    generic map(
        MAX_CH_PER_UNIT             => MAX_CH_PER_UNIT                         ,--: natural := 2;
        FILTER_MAC                  => true                                    ,--: boolean := true;
        FILTER_ETHERTYPE            => true                                    ,--: boolean := true;
        USAGE_C_PLANE               => true                                    ,--: boolean := true;
        USAGE_U_PLANE               => true                                     --: boolean := true
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => RST_CPUIF                               ,--: in  std_logic;

        N_TA_OFFSET                 => CC0_N_TA_OFFSET                         ,--: in  std_logic_vector(15 downto 0);

        REF_10msec                  => FRAME_SYNC                              ,--: in  std_logic;
        REF_SFN                     => FRAME_NUM(7 downto 0)                   ,--: in  std_logic_vector(7 downto 0);

        CAPTURE_PERIOD              => cp_dl_period(0)                         ,--: in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            => t2a_max_cp_dl(0)                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_CP_RX            => t2a_min_cp_dl(0)                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MAX_DL_UP_RX            => t2a_max_up_dl(0)                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_UP_RX            => t2a_min_up_dl(0)                        ,--: in  std_logic_vector(21 downto 0);               
        
        
        RST                         => ARESET_RX(i)                            ,--: in  std_logic;

        CLK_MAC                     => CLK_MAC_RX                              ,--: in  std_logic;
        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

        RX_PARAM_MAC                => dl_param_mac(i)                         ,--: in  std_logic_vector(47 downto 0);
        RX_PARAM_ETHERTYPE          => x"AEFE"                                 ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_0_EN        => dl_param_id0_en(i)(0)                   ,--: in  std_logic;
        RX_PARAM_ID_CH0_0           => dl_param_id0(i)(0)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_1_EN        => dl_param_id1_en(i)(0)                   ,--: in  std_logic;
        RX_PARAM_ID_CH0_1           => dl_param_id1(i)(0)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_2_EN        => dl_param_id2_en(i)(0)                   ,--: in  std_logic;
        RX_PARAM_ID_CH0_2           => dl_param_id2(i)(0)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_3_EN        => dl_param_id3_en(i)(0)                   ,--: in  std_logic;
        RX_PARAM_ID_CH0_3           => dl_param_id3(i)(0)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_0_EN        => dl_param_id0_en(i)(1)                   ,--: in  std_logic;
        RX_PARAM_ID_CH1_0           => dl_param_id0(i)(1)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_1_EN        => dl_param_id1_en(i)(1)                   ,--: in  std_logic;
        RX_PARAM_ID_CH1_1           => dl_param_id1(i)(1)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_2_EN        => dl_param_id2_en(i)(1)                   ,--: in  std_logic;
        RX_PARAM_ID_CH1_2           => dl_param_id2(i)(1)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_3_EN        => dl_param_id3_en(i)(1)                   ,--: in  std_logic;
        RX_PARAM_ID_CH1_3           => dl_param_id3(i)(1)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_0_EN        => dl_param_id0_en(i)(2)                   ,--: in  std_logic;
        RX_PARAM_ID_CH2_0           => dl_param_id0(i)(2)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_1_EN        => dl_param_id1_en(i)(2)                   ,--: in  std_logic;
        RX_PARAM_ID_CH2_1           => dl_param_id1(i)(2)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_2_EN        => dl_param_id2_en(i)(2)                   ,--: in  std_logic;
        RX_PARAM_ID_CH2_2           => dl_param_id2(i)(2)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_3_EN        => dl_param_id3_en(i)(2)                   ,--: in  std_logic;
        RX_PARAM_ID_CH2_3           => dl_param_id3(i)(2)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_0_EN        => dl_param_id0_en(i)(3)                   ,--: in  std_logic;
        RX_PARAM_ID_CH3_0           => dl_param_id0(i)(3)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_1_EN        => dl_param_id1_en(i)(3)                   ,--: in  std_logic;
        RX_PARAM_ID_CH3_1           => dl_param_id1(i)(3)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_2_EN        => dl_param_id2_en(i)(3)                   ,--: in  std_logic;
        RX_PARAM_ID_CH3_2           => dl_param_id2(i)(3)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_3_EN        => dl_param_id3_en(i)(3)                   ,--: in  std_logic;
        RX_PARAM_ID_CH3_3           => dl_param_id3(i)(3)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_0_EN        => dl_param_id0_en(i)(4)                   ,--: in  std_logic;
        RX_PARAM_ID_CH4_0           => dl_param_id0(i)(4)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_1_EN        => dl_param_id1_en(i)(4)                   ,--: in  std_logic;
        RX_PARAM_ID_CH4_1           => dl_param_id1(i)(4)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_2_EN        => dl_param_id2_en(i)(4)                   ,--: in  std_logic;
        RX_PARAM_ID_CH4_2           => dl_param_id2(i)(4)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_3_EN        => dl_param_id3_en(i)(4)                   ,--: in  std_logic;
        RX_PARAM_ID_CH4_3           => dl_param_id3(i)(4)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_0_EN        => dl_param_id0_en(i)(5)                   ,--: in  std_logic;
        RX_PARAM_ID_CH5_0           => dl_param_id0(i)(5)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_1_EN        => dl_param_id1_en(i)(5)                   ,--: in  std_logic;
        RX_PARAM_ID_CH5_1           => dl_param_id1(i)(5)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_2_EN        => dl_param_id2_en(i)(5)                   ,--: in  std_logic;
        RX_PARAM_ID_CH5_2           => dl_param_id2(i)(5)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_3_EN        => dl_param_id3_en(i)(5)                   ,--: in  std_logic;
        RX_PARAM_ID_CH5_3           => dl_param_id3(i)(5)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_0_EN        => dl_param_id0_en(i)(6)                   ,--: in  std_logic;
        RX_PARAM_ID_CH6_0           => dl_param_id0(i)(6)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_1_EN        => dl_param_id1_en(i)(6)                   ,--: in  std_logic;
        RX_PARAM_ID_CH6_1           => dl_param_id1(i)(6)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_2_EN        => dl_param_id2_en(i)(6)                   ,--: in  std_logic;
        RX_PARAM_ID_CH6_2           => dl_param_id2(i)(6)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_3_EN        => dl_param_id3_en(i)(6)                   ,--: in  std_logic;
        RX_PARAM_ID_CH6_3           => dl_param_id3(i)(6)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_0_EN        => dl_param_id0_en(i)(7)                   ,--: in  std_logic;
        RX_PARAM_ID_CH7_0           => dl_param_id0(i)(7)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_1_EN        => dl_param_id1_en(i)(7)                   ,--: in  std_logic;
        RX_PARAM_ID_CH7_1           => dl_param_id1(i)(7)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_2_EN        => dl_param_id2_en(i)(7)                   ,--: in  std_logic;
        RX_PARAM_ID_CH7_2           => dl_param_id2(i)(7)                      ,--: in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_3_EN        => dl_param_id3_en(i)(7)                   ,--: in  std_logic;
        RX_PARAM_ID_CH7_3           => dl_param_id3(i)(7)                      ,--: in  std_logic_vector(15 downto 0);

        RX_COMP_MODE                => dl_comp_mode(i)                         ,--: in  std_logic;
        RX_IQ_WIDTH                 => dl_iq_width(i)                          ,--: in  std_logic_vector(3 downto 0);
        RX_COMP_METHOD              => dl_comp_method(i)                       ,--: in  std_logic_vector(3 downto 0);
        RX_SCS_CONFIG               => dl_scs_config(i)                        ,--: in  std_logic_vector(3 downto 0);
        RX_FFT_SIZE                 => dl_fft_size(i)                          ,--: in  std_logic_vector(3 downto 0);
        RX_PRB_PER_SYMBOL           => dl_prb_per_symbol(i)                    ,--: in  std_logic_vector(9 downto 0);
        RX_COMP_EXP_OFFSET          => dl_comp_exp_offset(i)                   ,--: in  std_logic_vector(4 downto 0);

        USAGE_RX_DATA_BUFFER        => dl_data_buffer(i)                       ,--: out std_logic_vector(31 downto 0);

        RX_INVALID_DST_MAC          => dl_invalid_dst_mac(i)                   ,--: out std_logic_vector(31 downto 0);
        RX_INVALID_ETHERTYPE        => dl_invalid_ethertype(i)                 ,--: out std_logic_vector(31 downto 0);
        RX_INVALID_ecpriVersion     => dl_invalid_ecpriversion(i)              ,--: out std_logic_vector(31 downto 0);
        RX_INVALID_ecpriC           => dl_invalid_ecpric(i)                    ,--: out std_logic_vector(31 downto 0);
        RX_INVALID_ecpriMessage     => dl_invalid_ecprimessage(i)              ,--: out std_logic_vector(31 downto 0);
        RX_C_PLANE                  => dl_c_plane(i)                           ,--: out std_logic_vector(31 downto 0);
        RX_C_PLANE_DROPPED          => dl_c_plane_dropped(i)                   ,--: out std_logic_vector(31 downto 0);
        RX_U_PLANE                  => dl_u_plane(i)                           ,--: out std_logic_vector(31 downto 0);
        RX_U_PLANE_DROPPED          => dl_u_plane_dropped(i)                   ,--: out std_logic_vector(31 downto 0);
        RX_LOST                     => dl_lost(i)                              ,--: out std_logic_vector(31 downto 0);

        RX_LENGTH_IS_NORMAL         => open                                    ,--: out std_logic_vector(31 downto 0);
        RX_LENGTH_IS_LONG           => open                                    ,--: out std_logic_vector(31 downto 0);
        RX_LENGTH_IS_SHORT          => open                                    ,--: out std_logic_vector(31 downto 0);

        RX_C_PLANE_EXIST            => dl_c_plane_exist(i)                     ,--: out std_logic_vector(31 downto 0);
        RX_U_PLANE_EXIST            => dl_u_plane_exist(i)                     ,--: out std_logic_vector(31 downto 0);

        RX_FAULT_ID_31_CH0          => rx_fault_id_31_ch0(i)                   ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH1          => rx_fault_id_31_ch1(i)                   ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH2          => rx_fault_id_31_ch2(i)                   ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH3          => rx_fault_id_31_ch3(i)                   ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH4          => rx_fault_id_31_ch4(i)                   ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH5          => rx_fault_id_31_ch5(i)                   ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH6          => rx_fault_id_31_ch6(i)                   ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH7          => rx_fault_id_31_ch7(i)                   ,--: out std_logic_vector(3 downto 0);

        MAC_RX_READY                => open                                    ,--: out std_logic;
        MAC_RX_VALID                => mac_rx_valid(i)                         ,--: in  std_logic;
        MAC_RX_LAST                 => mac_rx_last(i)                          ,--: in  std_logic;
        MAC_RX_KEEP                 => mac_rx_keep(i)                          ,--: in  std_logic_vector(7 downto 0);
        MAC_RX_DATA                 => mac_rx_data(i)                          ,--: in  std_logic_vector(63 downto 0);

        PACKET_IS_CP_DL             => rx_packet_is_cp_dl(i)                   ,--: out std_logic;
        PACKET_IS_CP_UL             => rx_packet_is_cp_ul(i)                   ,--: out std_logic;
        PACKET_IS_UP_DL             => rx_packet_is_up_dl(i)                   ,--: out std_logic;
        PACKET_IS_UP_UL             => open                                    ,--: out std_logic;
        PACKET_SCS                  => rx_packet_scs(i)                        ,--: out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => rx_packet_frame_id(i)                   ,--: out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => rx_packet_subframe_id(i)                ,--: out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => rx_packet_slot_id(i)                    ,--: out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => rx_packet_symbol_id(i)                  ,--: out std_logic_vector(5 downto 0);

        BYPASS_OUT_VALID            => open                                    ,--: out std_logic;
        BYPASS_OUT_LAST             => open                                    ,--: out std_logic;
        BYPASS_OUT_KEEP             => open                                    ,--: out std_logic_vector(7 downto 0);
        BYPASS_OUT_DATA             => open                                    ,--: out std_logic_vector(63 downto 0);

        eCPRI_RX_C_VALID            => ecpri_rx_c_valid(i)                     ,--: out std_logic;
        eCPRI_RX_C_LAST             => ecpri_rx_c_last(i)                      ,--: out std_logic;
        eCPRI_RX_C_KEEP             => ecpri_rx_c_keep(i)                      ,--: out std_logic_vector(3 downto 0);
        eCPRI_RX_C_DATA             => ecpri_rx_c_data(i)                      ,--: out std_logic_vector(31 downto 0);
        eCPRI_RX_C_CH               => ecpri_rx_c_ch(i)(2 downto 0)            ,--: out std_logic_vector(2 downto 0);
        eCPRI_RX_C_CH_SUB           => ecpri_rx_c_ch_sub(i)                    ,--: out std_logic_vector(3 downto 0);

        ADV_RB_CHANNEL_ID           => open                                    ,--: out std_logic_vector(2 downto 0);
        ADV_RB_FRAME_ID             => open                                    ,--: out std_logic_vector(7 downto 0);
        ADV_RB_SUBFRAME_ID          => open                                    ,--: out std_logic_vector(3 downto 0);
        ADV_RB_SLOT_ID              => open                                    ,--: out std_logic_vector(5 downto 0);
        ADV_RB_SYMBOL_ID            => open                                    ,--: out std_logic_vector(5 downto 0);
        ADV_RB_START                => open                                    ,--: out std_logic;

        RB_eAxC_ID                  => open                                    ,--: out std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              => open                                    ,--: out std_logic_vector(15 downto 0);
        RB_CHANNEL_ID               => dl_rb_channel_id(i)(2 downto 0)         ,--: out std_logic_vector(2 downto 0);
        RB_FRAME_ID                 => dl_rb_frame_id(i)                       ,--: out std_logic_vector(7 downto 0);
        RB_SUBFRAME_ID              => dl_rb_subframe_id(i)                    ,--: out std_logic_vector(3 downto 0);
        RB_SLOT_ID                  => dl_rb_slot_id(i)                        ,--: out std_logic_vector(5 downto 0);
        RB_SYMBOL_ID                => dl_rb_symbol_id(i)                      ,--: out std_logic_vector(5 downto 0);
        RB_SECTION_ID               => dl_rb_section_id(i)                     ,--: out std_logic_vector(11 downto 0);
        RB_NUMBER                   => open                                    ,--: out std_logic_vector(9 downto 0);
        RE_NUMBER                   => dl_re_number(i)                         ,--: out std_logic_vector(11 downto 0);

        RB_VALID                    => dl_rb_valid(i)                          ,--: out std_logic;
        RB_START                    => dl_rb_start(i)                          ,--: out std_logic;
        RB_TICK                     => dl_rb_tick(i)                           ,--: out std_logic;
        RB_LAST                     => dl_rb_last(i)                           ,--: out std_logic;
        RB_DATA_I                   => dl_rb_data_i(i)                         ,--: out std_logic_vector(15 downto 0);
        RB_DATA_Q                   => dl_rb_data_q(i)                         ,--: out std_logic_vector(15 downto 0)
        
        MAC_HEADER_REMOVED_OUT_VALID => s_mac_header_removed_out_valid(i),
        MAC_HEADER_REMOVED_OUT_LAST  => s_mac_header_removed_out_last(i) ,
        MAC_HEADER_REMOVED_OUT_KEEP  => s_mac_header_removed_out_keep(i) ,
        MAC_HEADER_REMOVED_OUT_DATA  => s_mac_header_removed_out_data(i) ,
        
        RX_CORRUPT_SECTIONID        => rx_corrupt_sectionid(i)
        
    );

    u_CU_PE_TOP : CU_PE_TOP 
    generic map(
        VENDOR                      => "XILINX", 
        Category                    =>      "A",
        eCPRI_HDR                   =>     TRUE, 
        iFFT_k0_SHIFT               =>     TRUE, 
        iFFT_ZERO_PADDING           =>     TRUE, 
        SCS                         =>       15,
        SECTION_NUM                 =>      128, 
        Max_RB_NUM                  =>       15 ,--52, --50, -- 15: for 3MHz bandwidth 
        iFFT_WIDTH                  =>       12,                             
        SYMBOL_NUM                  =>        7,
        CH_NUM                      =>        DL_NUM_ANT, -- Layer/Path @ module 
        DL_LAYER_NUM                =>        DL_NUM_LAYER, 
        UL_RX_NUM                   =>        UL_NUM_ANT, 
        Opt_BF_Support              =>        0  -- Mandatory: 0, Optional: 1 
    )
    port map(
        CLK                         => CLK_BUS                                 ,--: in std_logic;
        nRE                         => dlfe_nRE(i)                             ,--: in std_logic_vector(11 downto 0);  
        nFFT                        => dlfe_nFFT(i)                            ,--: in std_logic_vector(1 downto 0);  
        FRAME_SYNC                  => FRAME_SYNC                              ,--: in std_logic; --> should be aligned with 1PPS
        DL_SYNC_ADVANCE             => dl_sync_advance(i)                      ,--: in std_logic_vector(21 downto 0);
        UL_SYNC_RETARD              => ul_sync_retard(i)                       ,--: in std_logic_vector(21 downto 0);
        BFN_NUM_IN                  => FRAME_NUM                               ,--: in std_logic_vector(11 downto 0); 
        ECPRI_RX_C_CH_IDX           => ecpri_rx_c_ch(i)                        ,--: in  std_logic_vector( 3 downto 0);  
        ECPRI_RX_C_VALID            => ecpri_rx_c_valid(i)                     ,--: in  std_logic;
        ECPRI_RX_C_LAST             => ecpri_rx_c_last(i)                      ,--: in  std_logic;
        ECPRI_RX_C_KEEP             => ecpri_rx_c_keep(i)                      ,--: in  std_logic_vector( 3 downto 0);
        ECPRI_RX_C_DATA             => ecpri_rx_c_data(i)                      ,--: in  std_logic_vector(31 downto 0);                
        RB_CH_IDX                   => dl_rb_channel_id(i)                     ,--: in  std_logic_vector( 3 downto 0); 
        RB_FRAME_ID                 => dl_rb_frame_id(i)                       ,--: in  std_logic_vector( 7 downto 0);
        RB_SUBFRAME_ID              => dl_rb_subframe_id(i)                    ,--: in  std_logic_vector( 3 downto 0);
        RB_SLOT_ID                  => dl_rb_slot_id(i)                        ,--: in  std_logic_vector( 5 downto 0);
        RB_SYMBOL_ID                => dl_rb_symbol_id(i)                      ,--: in  std_logic_vector( 5 downto 0);
        RB_SECTION_ID               => dl_rb_section_id(i)                     ,--: in  std_logic_vector(11 downto 0);
        RE_NUMBER                   => dl_re_number(i)                         ,--: in  std_logic_vector(11 downto 0);                                      
        RB_VALID                    => dl_rb_valid(i)                          ,--: in  std_logic;
        RB_START                    => dl_rb_start(i)                          ,--: in  std_logic;
        RB_LAST                     => dl_rb_last(i)                           ,--: in  std_logic;
        RB_TICK                     => dl_rb_tick(i)                           ,--: in  std_logic;
        RB_DATA_I                   => dl_rb_data_i(i)                         ,--: in  std_logic_vector(15 downto 0);
        RB_DATA_Q                   => dl_rb_data_q(i)                         ,--: in  std_logic_vector(15 downto 0);
        SYSTEM_MODE                 => w_system_mode(i)                        ,--: in  std_logic;                     -- 0: LTE, 1: NR
        ------ QA: Now it is hard code to support LTE only
        K0                          => dlfe_k0(i)                              ,--: in  std_logic_vector(11 downto 0);
        BFN_NUM_OUT                 => open                                    ,--: out std_logic_vector(11 downto 0); 
        DL_FRAME_SYNC               => dlfe_frame_sync(i)                      ,--: out std_logic;
        DL_FRAME_INDEX              => dlfe_frame_index(i)                     ,--: out std_logic_vector( 7 downto 0);                   
        DL_FRAME_STRUCTURE          => open                                    ,--: out std_logic_vector( 7 downto 0);
        DL_VALID                    => dlfe_valid(i)                           ,--: out std_logic_vector( 3 downto 0);                                                                                                                                              
        DL_RE_MASK                  => dlfe_re_mask(i)                         ,--: out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);                                                                                                                                            
        DL_DATA                     => dlfe_data(i)                            ,--: out std_logic_vector(CH_NUM*32 - 1 downto 0);                                                                                                                  
        UL_FRAME_SYNC               => rafe_frame_sync(i)                      ,--: out std_logic;
        UL_FILTER_INDEX             => rafe_filter_index(i)                    ,--: out std_logic_vector( 3 downto 0); 
        UL_TIME_OFFSET              => rafe_time_offset(i)                     ,--: out std_logic_vector(15 downto 0); 
        UL_FRAME_STRUCTURE          => rafe_frame_structure(i)                 ,--: out std_logic_vector( 7 downto 0); 
        UL_CPLENGTH                 => rafe_cplength(i)                        ,--: out std_logic_vector(15 downto 0); 
        UL_FREQ_OFFSET              => rafe_freq_offset(i)                     ,--: out std_logic_vector(23 downto 0);    
        UL_START_PRBC               => rafe_start_prbc(i)                      ,--: out std_logic_vector( 9 downto 0);
        UL_NUM_PRBC                 => rafe_num_prbc(i)                        ,--: out std_logic_vector( 7 downto 0);
        UL_NUM_PSYMBOL              => rafe_num_psymbol(i)                     ,--: out std_logic_vector( 3 downto 0);
        UL_NUM_RO                   => rafe_num_ro(i)                          ,--: out std_logic_vector( 2 downto 0) 
        SYMBOL_SYNC                 => tdd_sym_sync(i)                         ,--: out std_logic; 
        SYMBOL_INDEX                => tdd_sym_index(i)                        ,--: out std_logic_vector(3 downto 0);
        TDD_DL_EN                   => tdd_dl_enable(i)                        ,--: out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);
        TDD_UL_EN                   => tdd_ul_enable(i)                         --: out std_logic_vector((Opt_BF_Support*(UL_RX_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0)  
    );

    end generate;

    u_UL : for i in UL_UNIT-1 downto 0 generate
    u_DATA_MANAGER : DATA_MANAGER_UL
    generic map(
        MAX_CH                      => MAX_CH_PER_UNIT                         ,--: natural := 8;
        MAX_SECTION_PUxCH           => 512                                     ,--: natural := 256;
        MAX_SECTION_PRACH           => 32                                      ,--: natural := 16;
        LONG_PRACH                  => true                                     --: boolean := true
    )
    port map(
        CLK                         => CLK_BUS                                 ,--: in  std_logic;
        RST                         => ARESET_TX(i)                            ,--: in  std_logic;

        IGNORE_FRAME_ID             => ignore_frame_id(i)                      ,--: in  std_logic;
        IGNORE_FRAME_ID_PUxCH_RX    => ignore_frame_id_puxch_rx(i)             ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    => ignore_frame_id_puxch_tx(i)             ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH_RX    => ignore_frame_id_prach_rx(i)             ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH_TX    => ignore_frame_id_prach_tx(i)             ,--: out std_logic_vector(7 downto 0);

        UL_PUxCH_EN                 => dl_param_id2_en(i)                      ,--: in  std_logic_vector(7 downto 0);
        UL_PUxCH_ID                 => dl_param_id2(i)                         ,--: in  std_logic_array16(7 downto 0);
        UL_PRACH_EN                 => dl_param_id3_en(i)                      ,--: in  std_logic_vector(7 downto 0);
        UL_PRACH_ID                 => dl_param_id3(i)                         ,--: in  std_logic_array16(7 downto 0);

        UL_COMP_MODE                => ul_comp_mode(i)                         ,--: in  std_logic;
        UL_IQ_WIDTH                 => ul_iq_width(i)                          ,--: in  std_logic_vector(3 downto 0);
        UL_COMP_METHOD              => ul_comp_method(i)                       ,--: in  std_logic_vector(3 downto 0);
        UL_SCS_CONFIG               => ul_scs_config(i)                        ,--: in  std_logic_vector(3 downto 0);
        UL_FFT_SIZE                 => ul_fft_size(i)                          ,--: in  std_logic_vector(3 downto 0);
        UL_PRB_PER_MTU              => ul_prb_per_mtu(i)                       ,--: in  std_logic_vector(9 downto 0);
        UL_PRB_PER_SYMBOL           => ul_prb_per_symbol(i)                    ,--: in  std_logic_vector(9 downto 0);

        CNT_FIFO_FULL               => ul_cmd_fifo_full(i)                     ,--: out std_logic_vector(31 downto 0);

        CNT_PUxCH_TERMINATION       => puxch_termination(i)                    ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL0     => puxch_cpsec_symbol0(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL1     => puxch_cpsec_symbol1(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL2     => puxch_cpsec_symbol2(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL3     => puxch_cpsec_symbol3(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL4     => puxch_cpsec_symbol4(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL5     => puxch_cpsec_symbol5(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL6     => puxch_cpsec_symbol6(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL7     => puxch_cpsec_symbol7(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL8     => puxch_cpsec_symbol8(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL9     => puxch_cpsec_symbol9(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL10    => puxch_cpsec_symbol10(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL11    => puxch_cpsec_symbol11(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL12    => puxch_cpsec_symbol12(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL13    => puxch_cpsec_symbol13(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL0     => puxch_uppkt_symbol0(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL1     => puxch_uppkt_symbol1(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL2     => puxch_uppkt_symbol2(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL3     => puxch_uppkt_symbol3(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL4     => puxch_uppkt_symbol4(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL5     => puxch_uppkt_symbol5(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL6     => puxch_uppkt_symbol6(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL7     => puxch_uppkt_symbol7(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL8     => puxch_uppkt_symbol8(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL9     => puxch_uppkt_symbol9(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL10    => puxch_uppkt_symbol10(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL11    => puxch_uppkt_symbol11(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL12    => puxch_uppkt_symbol12(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL13    => puxch_uppkt_symbol13(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL0   => puxch_cq_full_symbol0(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL1   => puxch_cq_full_symbol1(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL2   => puxch_cq_full_symbol2(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL3   => puxch_cq_full_symbol3(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL4   => puxch_cq_full_symbol4(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL5   => puxch_cq_full_symbol5(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL6   => puxch_cq_full_symbol6(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL7   => puxch_cq_full_symbol7(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL8   => puxch_cq_full_symbol8(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL9   => puxch_cq_full_symbol9(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL10  => puxch_cq_full_symbol10(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL11  => puxch_cq_full_symbol11(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL12  => puxch_cq_full_symbol12(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL13  => puxch_cq_full_symbol13(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL0      => usage_puxch_cq_symbol0(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL1      => usage_puxch_cq_symbol1(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL2      => usage_puxch_cq_symbol2(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL3      => usage_puxch_cq_symbol3(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL4      => usage_puxch_cq_symbol4(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL5      => usage_puxch_cq_symbol5(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL6      => usage_puxch_cq_symbol6(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL7      => usage_puxch_cq_symbol7(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL8      => usage_puxch_cq_symbol8(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL9      => usage_puxch_cq_symbol9(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL10     => usage_puxch_cq_symbol10(i)              ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL11     => usage_puxch_cq_symbol11(i)              ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL12     => usage_puxch_cq_symbol12(i)              ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL13     => usage_puxch_cq_symbol13(i)              ,--: out std_logic_vector(31 downto 0);

        CNT_PRACH_TERMINATION       => prach_termination(i)                    ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL0     => prach_cpsec_symbol0(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL1     => prach_cpsec_symbol1(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL2     => prach_cpsec_symbol2(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL3     => prach_cpsec_symbol3(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL4     => prach_cpsec_symbol4(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL5     => prach_cpsec_symbol5(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL6     => prach_cpsec_symbol6(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL7     => prach_cpsec_symbol7(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL8     => prach_cpsec_symbol8(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL9     => prach_cpsec_symbol9(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL10    => prach_cpsec_symbol10(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL11    => prach_cpsec_symbol11(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL12    => prach_cpsec_symbol12(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL13    => prach_cpsec_symbol13(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL0     => prach_uppkt_symbol0(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL1     => prach_uppkt_symbol1(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL2     => prach_uppkt_symbol2(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL3     => prach_uppkt_symbol3(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL4     => prach_uppkt_symbol4(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL5     => prach_uppkt_symbol5(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL6     => prach_uppkt_symbol6(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL7     => prach_uppkt_symbol7(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL8     => prach_uppkt_symbol8(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL9     => prach_uppkt_symbol9(i)                  ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL10    => prach_uppkt_symbol10(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL11    => prach_uppkt_symbol11(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL12    => prach_uppkt_symbol12(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL13    => prach_uppkt_symbol13(i)                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL0   => prach_cq_full_symbol0(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL1   => prach_cq_full_symbol1(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL2   => prach_cq_full_symbol2(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL3   => prach_cq_full_symbol3(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL4   => prach_cq_full_symbol4(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL5   => prach_cq_full_symbol5(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL6   => prach_cq_full_symbol6(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL7   => prach_cq_full_symbol7(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL8   => prach_cq_full_symbol8(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL9   => prach_cq_full_symbol9(i)                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL10  => prach_cq_full_symbol10(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL11  => prach_cq_full_symbol11(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL12  => prach_cq_full_symbol12(i)               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL13  => prach_cq_full_symbol13(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL0      => usage_prach_cq_symbol0(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL1      => usage_prach_cq_symbol1(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL2      => usage_prach_cq_symbol2(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL3      => usage_prach_cq_symbol3(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL4      => usage_prach_cq_symbol4(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL5      => usage_prach_cq_symbol5(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL6      => usage_prach_cq_symbol6(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL7      => usage_prach_cq_symbol7(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL8      => usage_prach_cq_symbol8(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL9      => usage_prach_cq_symbol9(i)               ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL10     => usage_prach_cq_symbol10(i)              ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL11     => usage_prach_cq_symbol11(i)              ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL12     => usage_prach_cq_symbol12(i)              ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL13     => usage_prach_cq_symbol13(i)              ,--: out std_logic_vector(31 downto 0);

        C_PLANE_VALID               => ecpri_rx_c_valid(i)                     ,--: in  std_logic;
        C_PLANE_LAST                => ecpri_rx_c_last(i)                      ,--: in  std_logic;
        C_PLANE_KEEP                => ecpri_rx_c_keep(i)                      ,--: in  std_logic_vector(3 downto 0);
        C_PLANE_DATA                => ecpri_rx_c_data(i)                      ,--: in  std_logic_vector(31 downto 0);
        C_PLANE_CH                  => ecpri_rx_c_ch(i)(2 downto 0)            ,--: in  std_logic_vector(2 downto 0);
        C_PLANE_CH_SUB              => ecpri_rx_c_ch_sub(i)                    ,--: in  std_logic_vector(3 downto 0);

        ULFE_FRAME_ID               => ulfe_frame_id(i)                        ,--: in  std_logic_vector(7 downto 0);
        ULFE_SUBFRAME_ID            => ulfe_subframe_id(i)                     ,--: in  std_logic_vector(3 downto 0);
        ULFE_SLOT_ID                => ulfe_slot_id(i)                         ,--: in  std_logic_vector(5 downto 0);
        ULFE_SYMBOL_ID              => ulfe_symbol_id(i)                       ,--: in  std_logic_vector(5 downto 0);
        ULFE_START_RE               => ulfe_start_re(i)                        ,--: in  std_logic_vector(15 downto 0);

        ULFE_VALID                  => ulfe_valid(i)                           ,--: in  std_logic_vector(MAX_CH-1 downto 0);
        ULFE_START                  => ulfe_start(i)                           ,--: in  std_logic_vector(MAX_CH-1 downto 0);
        ULFE_LAST                   => ulfe_last(i)                            ,--: in  std_logic_vector(MAX_CH-1 downto 0);
        ULFE_DATA_I                 => ulfe_data_i(i)                          ,--: in  std_logic_array16(MAX_CH-1 downto 0);
        ULFE_DATA_Q                 => ulfe_data_q(i)                          ,--: in  std_logic_array16(MAX_CH-1 downto 0);

        RAFE_FRAME_ID               => rafe_frame_id(i)                        ,--: in  std_logic_vector(7 downto 0);
        RAFE_SUBFRAME_ID            => rafe_subframe_id(i)                     ,--: in  std_logic_vector(3 downto 0);
        RAFE_SLOT_ID                => rafe_slot_id(i)                         ,--: in  std_logic_vector(5 downto 0);
        RAFE_SYMBOL_ID              => rafe_symbol_id(i)                       ,--: in  std_logic_vector(5 downto 0);
        RAFE_START_RE               => rafe_start_re(i)                        ,--: in  std_logic_vector(15 downto 0);

        RAFE_VALID                  => rafe_valid(i)                           ,--: in  std_logic_vector(MAX_CH-1 downto 0);
        RAFE_START                  => rafe_start(i)                           ,--: in  std_logic_vector(MAX_CH-1 downto 0);
        RAFE_LAST                   => rafe_last(i)                            ,--: in  std_logic_vector(MAX_CH-1 downto 0);
        RAFE_DATA_I                 => rafe_data_i(i)                          ,--: in  std_logic_array16(MAX_CH-1 downto 0);
        RAFE_DATA_Q                 => rafe_data_q(i)                          ,--: in  std_logic_array16(MAX_CH-1 downto 0);

        PUxCH_RB_INIT               => puxch_rb_init(i)                        ,--: out std_logic;
        PUxCH_RB_eAxC_ID            => puxch_rb_eaxc_id(i)                     ,--: out std_logic_vector(15 downto 0);
        PUxCH_RB_SEQUENCE_ID        => puxch_rb_sequence_id(i)                 ,--: out std_logic_vector(15 downto 0);
        PUxCH_RB_HEADER_APP         => puxch_rb_header_app(i)                  ,--: out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_APP_ACK     => puxch_rb_header_app_ack(i)              ,--: in  std_logic;
        PUxCH_RB_HEADER_SEC         => puxch_rb_header_sec(i)                  ,--: out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_SEC_ACK     => puxch_rb_header_sec_ack(i)              ,--: in  std_logic;

        PUxCH_RB_COMP_HDR           => puxch_rb_comp_hdr(i)                    ,--: out std_logic_vector(7 downto 0);

        PUxCH_RB_VALID              => puxch_rb_valid(i)                       ,--: out std_logic;
        PUxCH_RB_TICK               => puxch_rb_tick(i)                        ,--: out std_logic;
        PUxCH_RB_DATA_I             => puxch_rb_data_i(i)                      ,--: out std_logic_vector(15 downto 0);
        PUxCH_RB_DATA_Q             => puxch_rb_data_q(i)                      ,--: out std_logic_vector(15 downto 0);
        PUxCH_RB_USER               => puxch_rb_user(i)                        ,--: out std_logic_vector(15 downto 0);

        PRACH_RB_INIT               => prach_rb_init(i)                        ,--: out std_logic;
        PRACH_RB_eAxC_ID            => prach_rb_eaxc_id(i)                     ,--: out std_logic_vector(15 downto 0);
        PRACH_RB_SEQUENCE_ID        => prach_rb_sequence_id(i)                 ,--: out std_logic_vector(15 downto 0);
        PRACH_RB_HEADER_APP         => prach_rb_header_app(i)                  ,--: out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_APP_ACK     => prach_rb_header_app_ack(i)              ,--: in  std_logic;
        PRACH_RB_HEADER_SEC         => prach_rb_header_sec(i)                  ,--: out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_SEC_ACK     => prach_rb_header_sec_ack(i)              ,--: in  std_logic;

        PRACH_RB_COMP_HDR           => prach_rb_comp_hdr(i)                    ,--: out std_logic_vector(7 downto 0);

        PRACH_RB_VALID              => prach_rb_valid(i)                       ,--: out std_logic;
        PRACH_RB_TICK               => prach_rb_tick(i)                        ,--: out std_logic;
        PRACH_RB_DATA_I             => prach_rb_data_i(i)                      ,--: out std_logic_vector(15 downto 0);
        PRACH_RB_DATA_Q             => prach_rb_data_q(i)                      ,--: out std_logic_vector(15 downto 0);
        PRACH_RB_USER               => prach_rb_user(i)                         --: out std_logic_vector(15 downto 0)
    );

    u_FRAMER_PUxCH : O_RAN_FRAMER
    generic map(
        USAGE_C_PLANE               => false                                   ,--: boolean := true;
        USAGE_U_PLANE               => true                                     --: boolean := true
    )
    port map(
        RST                         => ARESET_TX(i)                            ,--: in  std_logic;

        CLK_MAC                     => CLK_MAC_TX                              ,--: in  std_logic;
        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

        TX_PARAM_DST_MAC            => ul_param_dst_mac(i)                     ,--: in  std_logic_vector(47 downto 0);
        TX_PARAM_SRC_MAC            => ul_param_src_mac(i)                     ,--: in  std_logic_vector(47 downto 0);
        TX_PARAM_VLAN0_MODE         => ul_param_vlan0_mode(i)                  ,--: in  std_logic;
        TX_PARAM_VLAN0_TCI          => ul_param_vlan0_tci(i)                   ,--: in  std_logic_vector(15 downto 0);
        TX_PARAM_VLAN1_MODE         => ul_param_vlan1_mode(i)                  ,--: in  std_logic;
        TX_PARAM_VLAN1_TCI          => ul_param_vlan1_tci(i)                   ,--: in  std_logic_vector(15 downto 0);

        TX_COMP_MODE                => ul_comp_mode(i)                         ,--: in  std_logic;
        TX_COMP_EXP_OFFSET          => ul_comp_exp_offset(i)                   ,--: in  std_logic_vector(4 downto 0);
        TX_COMP_GAIN_OFFSET         => ul_comp_gain_offset(i)                  ,--: in  std_logic_vector(10 downto 0);
        TX_COMP_SCALE_GAIN_OFFSET   => ul_comp_scale_gain_offset(i)            ,--: in  std_logic_vector(3 downto 0);

        USAGE_TX_DATA_BUFFER        => ul_puxch_u_plane_buffer(i)              ,--: out std_logic_vector(31 downto 0);
        USAGE_TX_C_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);
        USAGE_TX_U_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);

        TX_C_PLANE                  => open                                    ,--: out std_logic_vector(31 downto 0);
        TX_C_PLANE_LOST             => open                                    ,--: out std_logic_vector(31 downto 0);
        TX_U_PLANE                  => ul_puxch_u_plane(i)                     ,--: out std_logic_vector(31 downto 0);
        TX_U_PLANE_LOST             => ul_puxch_u_plane_lost(i)                ,--: out std_logic_vector(31 downto 0);

        MAC_TX_READY                => mac_tx_ready(i*2)                       ,--: in  std_logic;
        MAC_TX_VALID                => mac_tx_valid(i*2)                       ,--: out std_logic;
        MAC_TX_LAST                 => mac_tx_last(i*2)                        ,--: out std_logic;
        MAC_TX_KEEP                 => mac_tx_keep(i*2)                        ,--: out std_logic_vector(7 downto 0);
        MAC_TX_DATA                 => mac_tx_data(i*2)                        ,--: out std_logic_vector(63 downto 0);

        RB_INIT                     => puxch_rb_init(i)                        ,--: in  std_logic;
        RB_eAxC_ID                  => puxch_rb_eaxc_id(i)                     ,--: in  std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              => puxch_rb_sequence_id(i)                 ,--: in  std_logic_vector(15 downto 0);
        RB_HEADER_APP               => puxch_rb_header_app(i)                  ,--: in  std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           => puxch_rb_header_app_ack(i)              ,--: out std_logic;
        RB_HEADER_SEC               => puxch_rb_header_sec(i)                  ,--: in  std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           => puxch_rb_header_sec_ack(i)              ,--: out std_logic;

        RB_COMP_HDR                 => puxch_rb_comp_hdr(i)                    ,--: in  std_logic_vector(7 downto 0);
                                                                                  
        RB_VALID                    => puxch_rb_valid(i)                       ,--: in  std_logic;
        RB_START                    => '0'                                     ,--: in  std_logic;
        RB_TICK                     => puxch_rb_tick(i)                        ,--: in  std_logic;
        RB_LAST                     => '0'                                     ,--: in  std_logic;
        RB_DATA_I                   => puxch_rb_data_i(i)                      ,--: in  std_logic_vector(15 downto 0);
        RB_DATA_Q                   => puxch_rb_data_q(i)                      ,--: in  std_logic_vector(15 downto 0);
        RB_USER                     => puxch_rb_user(i)                         --: in  std_logic_vector(15 downto 0)
    );

    u_FRAMER_PRACH : O_RAN_FRAMER
    generic map(
        USAGE_C_PLANE               => false                                   ,--: boolean := true;
        USAGE_U_PLANE               => true                                     --: boolean := true
    )
    port map(
        RST                         => ARESET_TX(i)                            ,--: in  std_logic;

        CLK_MAC                     => CLK_MAC_TX                              ,--: in  std_logic;
        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

        TX_PARAM_DST_MAC            => ul_param_dst_mac(i)                     ,--: in  std_logic_vector(47 downto 0);
        TX_PARAM_SRC_MAC            => ul_param_src_mac(i)                     ,--: in  std_logic_vector(47 downto 0);
        TX_PARAM_VLAN0_MODE         => ul_param_vlan0_mode(i)                  ,--: in  std_logic;
        TX_PARAM_VLAN0_TCI          => ul_param_vlan0_tci(i)                   ,--: in  std_logic_vector(15 downto 0);
        TX_PARAM_VLAN1_MODE         => ul_param_vlan1_mode(i)                  ,--: in  std_logic;
        TX_PARAM_VLAN1_TCI          => ul_param_vlan1_tci(i)                   ,--: in  std_logic_vector(15 downto 0);

        TX_COMP_MODE                => ul_comp_mode(i)                         ,--: in  std_logic;
        TX_COMP_EXP_OFFSET          => ul_comp_exp_offset(i)                   ,--: in  std_logic_vector(4 downto 0);
        TX_COMP_GAIN_OFFSET         => ul_comp_gain_offset(i)                  ,--: in  std_logic_vector(10 downto 0);
        TX_COMP_SCALE_GAIN_OFFSET   => ul_comp_scale_gain_offset(i)            ,--: in  std_logic_vector(3 downto 0);

        USAGE_TX_DATA_BUFFER        => ul_prach_u_plane_buffer(i)              ,--: out std_logic_vector(31 downto 0);
        USAGE_TX_C_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);
        USAGE_TX_U_PLANE_BUFFER     => open                                    ,--: out std_logic_vector(31 downto 0);

        TX_C_PLANE                  => open                                    ,--: out std_logic_vector(31 downto 0);
        TX_C_PLANE_LOST             => open                                    ,--: out std_logic_vector(31 downto 0);
        TX_U_PLANE                  => ul_prach_u_plane(i)                     ,--: out std_logic_vector(31 downto 0);
        TX_U_PLANE_LOST             => ul_prach_u_plane_lost(i)                ,--: out std_logic_vector(31 downto 0);

        MAC_TX_READY                => mac_tx_ready(i*2+1)                     ,--: in  std_logic;
        MAC_TX_VALID                => mac_tx_valid(i*2+1)                     ,--: out std_logic;
        MAC_TX_LAST                 => mac_tx_last(i*2+1)                      ,--: out std_logic;
        MAC_TX_KEEP                 => mac_tx_keep(i*2+1)                      ,--: out std_logic_vector(7 downto 0);
        MAC_TX_DATA                 => mac_tx_data(i*2+1)                      ,--: out std_logic_vector(63 downto 0);

        RB_INIT                     => prach_rb_init(i)                        ,--: in  std_logic;
        RB_eAxC_ID                  => prach_rb_eaxc_id(i)                     ,--: in  std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              => prach_rb_sequence_id(i)                 ,--: in  std_logic_vector(15 downto 0);
        RB_HEADER_APP               => prach_rb_header_app(i)                  ,--: in  std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           => prach_rb_header_app_ack(i)              ,--: out std_logic;
        RB_HEADER_SEC               => prach_rb_header_sec(i)                  ,--: in  std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           => prach_rb_header_sec_ack(i)              ,--: out std_logic;

        RB_COMP_HDR                 => prach_rb_comp_hdr(i)                    ,--: in  std_logic_vector(7 downto 0);

        RB_VALID                    => prach_rb_valid(i)                       ,--: in  std_logic;
        RB_START                    => '0'                                     ,--: in  std_logic;
        RB_TICK                     => prach_rb_tick(i)                        ,--: in  std_logic;
        RB_LAST                     => '0'                                     ,--: in  std_logic;
        RB_DATA_I                   => prach_rb_data_i(i)                      ,--: in  std_logic_vector(15 downto 0);
        RB_DATA_Q                   => prach_rb_data_q(i)                      ,--: in  std_logic_vector(15 downto 0);
        RB_USER                     => prach_rb_user(i)                         --: in  std_logic_vector(15 downto 0)
    );
    end generate;

    u_MEASUREMENT : for i in DL_UNIT-1 downto 0 generate
    u_MEASUREMENT : MEASUREMENT
    generic map(
        NUM_TX                      => 2                                        --: natural := 1
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => RST_CPUIF                               ,--: in  std_logic;

        CLK_245p76MHz               => CLK_BUS                                 ,--: in  std_logic;

        N_TA_OFFSET                 => CC0_N_TA_OFFSET                         ,--: in  std_logic_vector(15 downto 0);

        REF_10msec                  => FRAME_SYNC                              ,--: in  std_logic;
        REF_SFN                     => FRAME_NUM(7 downto 0)                   ,--: in  std_logic_vector(7 downto 0);

        CAPTURE_PERIOD              => cp_dl_period(0)                         ,--: in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            => t2a_max_cp_dl(0)                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_CP_RX            => t2a_min_cp_dl(0)                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MAX_DL_UP_RX            => t2a_max_up_dl(0)                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_UP_RX            => t2a_min_up_dl(0)                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MAX_UL_CP_RX            => t2a_max_cp_ul(0)                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MIN_UL_CP_RX            => t2a_min_cp_ul(0)                        ,--: in  std_logic_vector(21 downto 0);

        DL_CP_RX_CNT_CLEAR          => cp_dl_cnt_clear(0)                      ,--: in  std_logic_vector(3 downto 0);
        DL_CP_RX_ON_TIME            => cp_dl_on_time(i)                        ,--: out std_logic_vector(63 downto 0);
        DL_CP_RX_EARLY              => cp_dl_early(i)                          ,--: out std_logic_vector(63 downto 0);
        DL_CP_RX_LATE               => cp_dl_late(i)                           ,--: out std_logic_vector(63 downto 0);
        DL_CP_RX_OUT_OF_RANGE       => open                                    ,--: out std_logic_vector(63 downto 0);

        DL_UP_RX_CNT_CLEAR          => up_dl_cnt_clear(0)                      ,--: in  std_logic_vector(3 downto 0);
        DL_UP_RX_ON_TIME            => up_dl_on_time(i)                        ,--: out std_logic_vector(63 downto 0);
        DL_UP_RX_EARLY              => up_dl_early(i)                          ,--: out std_logic_vector(63 downto 0);
        DL_UP_RX_LATE               => up_dl_late(i)                           ,--: out std_logic_vector(63 downto 0);
        DL_UP_RX_OUT_OF_RANGE       => open                                    ,--: out std_logic_vector(63 downto 0);

        UL_CP_RX_CNT_CLEAR          => cp_ul_cnt_clear(0)                      ,--: in  std_logic_vector(3 downto 0);
        UL_CP_RX_ON_TIME            => cp_ul_on_time(i)                        ,--: out std_logic_vector(63 downto 0);
        UL_CP_RX_EARLY              => cp_ul_early(i)                          ,--: out std_logic_vector(63 downto 0);
        UL_CP_RX_LATE               => cp_ul_late(i)                           ,--: out std_logic_vector(63 downto 0);
        UL_CP_RX_OUT_OF_RANGE       => open                                    ,--: out std_logic_vector(63 downto 0);

        UL_UP_TX_CNT_CLEAR          => ul_up_tx_cnt_clear(0)                   ,--: in  std_logic_vector(7 downto 0);
        UL_UP_TX_TOTAL              => ul_up_tx_total(i)                       ,--: out std_logic_array64(7 downto 0);

        RX_PACKET_CLK               => CLK_MAC_RX                              ,--: in  std_logic;
        UPDATE_EN_OUT               => output_update_en(i)                        ,--: out std_logic;

        RX_PACKET_IS_CP_DL          => rx_packet_is_cp_dl(i)                   ,--: in  std_logic;
        RX_PACKET_IS_CP_UL          => rx_packet_is_cp_ul(i)                   ,--: in  std_logic;
        RX_PACKET_IS_UP_DL          => rx_packet_is_up_dl(i)                   ,--: in  std_logic;
        RX_PACKET_SCS               => rx_packet_scs(i)                        ,--: in  std_logic_vector(3 downto 0);
        RX_PACKET_FRAME_ID          => rx_packet_frame_id(i)                   ,--: in  std_logic_vector(7 downto 0);
        RX_PACKET_SUBFRAME_ID       => rx_packet_subframe_id(i)                ,--: in  std_logic_vector(3 downto 0);
        RX_PACKET_SLOT_ID           => rx_packet_slot_id(i)                    ,--: in  std_logic_vector(5 downto 0);
        RX_PACKET_SYMBOL_ID         => rx_packet_symbol_id(i)                  ,--: in  std_logic_vector(5 downto 0);

        TX_PACKET_CLK               => CLK_MAC_TX                              ,--: in  std_logic;

        TX_PACKET_EXIST             => pe0_transmitted(i)                       --: in  std_logic_vector(NUM_PORT_TX-1 downto 0)
    );
    end generate;

    ul_up_tx_cnt_clear(0)(0)        <= up0_ul_cnt_clear(0)(0);
    ul_up_tx_cnt_clear(0)(1)        <= up1_ul_cnt_clear(0)(0);

    up0_ul_on_time(0)               <= ul_up_tx_total(0)(0);
    up1_ul_on_time(0)               <= ul_up_tx_total(0)(1);

    process (CLK_MAC_TX)
    begin
        if (CLK_MAC_TX'event and CLK_MAC_TX = '1') then
            pe0_transmitted(0)(0) <= (mac_tx_ready(0) and mac_tx_valid(0) and mac_tx_last(0)) or (mac_tx_ready(2) and mac_tx_valid(2) and mac_tx_last(2));    -- PUxCH
            pe0_transmitted(0)(1) <= (mac_tx_ready(1) and mac_tx_valid(1) and mac_tx_last(1)) or (mac_tx_ready(3) and mac_tx_valid(3) and mac_tx_last(3));    -- PRACH
        end if;
    end process;

    sum_cp_dl_on_time(0)            <= cp_dl_on_time(0) + cp_dl_on_time(1);
    sum_cp_dl_early(0)              <= cp_dl_early(0)   + cp_dl_early(1);
    sum_cp_dl_late(0)               <= cp_dl_late(0)    + cp_dl_late(1);

    sum_up_dl_on_time(0)            <= up_dl_on_time(0) + up_dl_on_time(1);
    sum_up_dl_early(0)              <= up_dl_early(0)   + up_dl_early(1);
    sum_up_dl_late(0)               <= up_dl_late(0)    + up_dl_late(1);

    sum_cp_ul_on_time(0)            <= cp_ul_on_time(0) + cp_ul_on_time(1);
    sum_cp_ul_early(0)              <= cp_ul_early(0)   + cp_ul_early(1);
    sum_cp_ul_late(0)               <= cp_ul_late(0)    + cp_ul_late(1);

    u_MPI : O_RAN_MPI
    generic map(
        OFFSET                      => OFFSET                                  ,--: std_logic_vector(3 downto 0) := x"3";
        DL_UNIT                     => DL_UNIT                                 ,--: natural := 6;
        UL_UNIT                     => UL_UNIT                                 ,--: natural := 6;
        MAX_CH_PER_UNIT             => MAX_CH_PER_UNIT                         ,--: natural := 2;
        MAX_ID_PER_CH               => MAX_ID_PER_CH                            --: natural := 1
    )
    port map(
        CLK                         => CLK_CPUIF                               ,--: in  std_logic;
        RST                         => RST_CPUIF                               ,--: in  std_logic;

        CLK_MAC_RX                  => CLK_MAC_RX                              ,--: in  std_logic;
        CLK_MAC_TX                  => CLK_MAC_TX                              ,--: in  std_logic;
        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

        IGNORE_FRAME_ID             => ignore_frame_id                         ,--: out std_logic_vector(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PUxCH_RX    => ignore_frame_id_puxch_rx                ,--: in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    => ignore_frame_id_puxch_tx                ,--: in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH_RX    => ignore_frame_id_prach_rx                ,--: in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH_TX    => ignore_frame_id_prach_tx                ,--: in  std_logic_array8(UL_UNIT-1 downto 0);

        DL_PARAM_MAC                => dl_param_mac                            ,--: out std_logic_array48(DL_UNIT-1 downto 0);
        DL_PARAM_ID0_EN             => dl_param_id0_en                         ,--: out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID0                => dl_param_id0                            ,--: out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID1_EN             => dl_param_id1_en                         ,--: out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID1                => dl_param_id1                            ,--: out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID2_EN             => dl_param_id2_en                         ,--: out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID2                => dl_param_id2                            ,--: out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID3_EN             => dl_param_id3_en                         ,--: out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID3                => dl_param_id3                            ,--: out std_logic_array8_array16(DL_UNIT-1 downto 0);

        DL_COMP_MODE                => dl_comp_mode                            ,--: out std_logic_vector(DL_UNIT-1 downto 0);
        DL_IQ_WIDTH                 => dl_iq_width                             ,--: out std_logic_array4(DL_UNIT-1 downto 0);
        DL_COMP_METHOD              => dl_comp_method                          ,--: out std_logic_array4(DL_UNIT-1 downto 0);
        DL_SCS_CONFIG               => dl_scs_config                           ,--: out std_logic_array4(DL_UNIT-1 downto 0);
        DL_FFT_SIZE                 => dl_fft_size                             ,--: out std_logic_array4(DL_UNIT-1 downto 0);
        DL_PRB_PER_SYMBOL           => dl_prb_per_symbol                       ,--: out std_logic_array10(DL_UNIT-1 downto 0);
        DL_COMP_EXP_OFFSET          => dl_comp_exp_offset                      ,--: out std_logic_array5(DL_UNIT-1 downto 0);

        UL_PARAM_DST_MAC            => ul_param_dst_mac                        ,--: out std_logic_array48(UL_UNIT-1 downto 0);
        UL_PARAM_SRC_MAC            => ul_param_src_mac                        ,--: out std_logic_array48(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN0_MODE         => ul_param_vlan0_mode                     ,--: out std_logic_vector(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN0_TCI          => ul_param_vlan0_tci                      ,--: out std_logic_array16(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN1_MODE         => ul_param_vlan1_mode                     ,--: out std_logic_vector(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN1_TCI          => ul_param_vlan1_tci                      ,--: out std_logic_array16(UL_UNIT-1 downto 0);

        UL_COMP_MODE                => ul_comp_mode                            ,--: out std_logic_vector(UL_UNIT-1 downto 0);
        UL_IQ_WIDTH                 => ul_iq_width                             ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UL_COMP_METHOD              => ul_comp_method                          ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UL_SCS_CONFIG               => ul_scs_config                           ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UL_FFT_SIZE                 => ul_fft_size                             ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UL_PRB_PER_MTU              => ul_prb_per_mtu                          ,--: out std_logic_array10(UL_UNIT-1 downto 0);
        UL_PRB_PER_SYMBOL           => ul_prb_per_symbol                       ,--: out std_logic_array10(UL_UNIT-1 downto 0);
        UL_COMP_EXP_OFFSET          => ul_comp_exp_offset                      ,--: out std_logic_array5(UL_UNIT-1 downto 0);
        UL_COMP_GAIN_OFFSET         => ul_comp_gain_offset                     ,--: out std_logic_array11(UL_UNIT-1 downto 0);
        UL_COMP_SCALE_GAIN_OFFSET   => ul_comp_scale_gain_offset               ,--: out std_logic_array4(UL_UNIT-1 downto 0);

        T2A_MAX_CP_DL               => t2a_max_cp_dl                           ,--: out std_logic_array22(DL_UNIT-1 downto 0);
        T2A_MIN_CP_DL               => t2a_min_cp_dl                           ,--: out std_logic_array22(DL_UNIT-1 downto 0);
        CP_DL_PERIOD                => cp_dl_period                            ,--: out std_logic_array8(DL_UNIT-1 downto 0);

        CP_DL_CNT_CLEAR             => cp_dl_cnt_clear                         ,--: out std_logic_array4(DL_UNIT-1 downto 0);
        CP_DL_ON_TIME               => sum_cp_dl_on_time                       ,--: in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_EARLY                 => sum_cp_dl_early                         ,--: in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_LATE                  => sum_cp_dl_late                          ,--: in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_OUT_OF_RANGE          => (others => (others => '0'))             ,--: in  std_logic_array64(DL_UNIT-1 downto 0);

        T2A_MAX_UP_DL               => t2a_max_up_dl                           ,--: out std_logic_array22(DL_UNIT-1 downto 0);
        T2A_MIN_UP_DL               => t2a_min_up_dl                           ,--: out std_logic_array22(DL_UNIT-1 downto 0);
        UP_DL_PERIOD                => open                                    ,--: out std_logic_array8(DL_UNIT-1 downto 0);

        UP_DL_CNT_CLEAR             => up_dl_cnt_clear                         ,--: out std_logic_array4(DL_UNIT-1 downto 0);
        UP_DL_ON_TIME               => sum_up_dl_on_time                       ,--: in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_EARLY                 => sum_up_dl_early                         ,--: in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_LATE                  => sum_up_dl_late                          ,--: in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_OUT_OF_RANGE          => (others => (others => '0'))             ,--: in  std_logic_array64(DL_UNIT-1 downto 0);

        T2A_MAX_CP_UL               => t2a_max_cp_ul                           ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        T2A_MIN_CP_UL               => t2a_min_cp_ul                           ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        CP_UL_PERIOD                => open                                    ,--: out std_logic_array8(UL_UNIT-1 downto 0);

        CP_UL_CNT_CLEAR             => cp_ul_cnt_clear                         ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        CP_UL_ON_TIME               => sum_cp_ul_on_time                       ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_EARLY                 => sum_cp_ul_early                         ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_LATE                  => sum_cp_ul_late                          ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_OUT_OF_RANGE          => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP0_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP0_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        UP0_UL_PERIOD               => open                                    ,--: out std_logic_array8(UL_UNIT-1 downto 0);

        UP0_UL_CNT_CLEAR            => up0_ul_cnt_clear                        ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UP0_UL_ON_TIME              => up0_ul_on_time                          ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_EARLY                => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_LATE                 => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_OUT_OF_RANGE         => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP1_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP1_UL              => open                                    ,--: out std_logic_array22(UL_UNIT-1 downto 0);
        UP1_UL_PERIOD               => open                                    ,--: out std_logic_array8(UL_UNIT-1 downto 0);

        UP1_UL_CNT_CLEAR            => up1_ul_cnt_clear                        ,--: out std_logic_array4(UL_UNIT-1 downto 0);
        UP1_UL_ON_TIME              => up1_ul_on_time                          ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_EARLY                => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_LATE                 => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_OUT_OF_RANGE         => (others => (others => '0'))             ,--: in  std_logic_array64(UL_UNIT-1 downto 0);

        DL_C_PLANE_BUFFER           => dl_data_buffer                          ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_BUFFER           => dl_data_buffer                          ,--: in  std_logic_array32(DL_UNIT-1 downto 0);

        DL_INVALID_DST_MAC          => dl_invalid_dst_mac                      ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ETHERTYPE        => dl_invalid_ethertype                    ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriVersion     => dl_invalid_ecpriversion                 ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriC           => dl_invalid_ecpric                       ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriMessage     => dl_invalid_ecprimessage                 ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_C_PLANE                  => dl_c_plane                              ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_C_PLANE_DROPPED          => dl_c_plane_dropped                      ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE                  => dl_u_plane                              ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_DROPPED          => dl_u_plane_dropped                      ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_LOST                     => dl_lost                                 ,--: in  std_logic_array32(DL_UNIT-1 downto 0);

        DL_C_PLANE_EXIST            => dl_c_plane_exist                        ,--: in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_EXIST            => dl_u_plane_exist                        ,--: in  std_logic_array32(DL_UNIT-1 downto 0);

        RX_FAULT_ID_31_CH0          => rx_fault_id_31_ch0                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH1          => rx_fault_id_31_ch1                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH2          => rx_fault_id_31_ch2                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH3          => rx_fault_id_31_ch3                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH4          => rx_fault_id_31_ch4                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH5          => rx_fault_id_31_ch5                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH6          => rx_fault_id_31_ch6                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH7          => rx_fault_id_31_ch7                      ,--: in  std_logic_array4(DL_UNIT-1 downto 0);

--        UL_PUxCH_C_PLANE_BUFFER     => ul_puxch_c_plane_buffer                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE_BUFFER     => ul_puxch_u_plane_buffer                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PUxCH_C_PLANE            => ul_puxch_c_plane                        ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_PUxCH_C_PLANE_LOST       => ul_puxch_c_plane_lost                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE            => ul_puxch_u_plane                        ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE_LOST       => ul_puxch_u_plane_lost                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PRACH_C_PLANE_BUFFER     => ul_prach_c_plane_buffer                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE_BUFFER     => ul_prach_u_plane_buffer                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PRACH_C_PLANE            => ul_prach_c_plane                        ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_PRACH_C_PLANE_LOST       => ul_prach_c_plane_lost                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE            => ul_prach_u_plane                        ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE_LOST       => ul_prach_u_plane_lost                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_CMD_FIFO_FULL            => ul_cmd_fifo_full                        ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_PUxCH_TERMINATION        => puxch_termination                       ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL0      => puxch_cpsec_symbol0                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL1      => puxch_cpsec_symbol1                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL2      => puxch_cpsec_symbol2                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL3      => puxch_cpsec_symbol3                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL4      => puxch_cpsec_symbol4                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL5      => puxch_cpsec_symbol5                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL6      => puxch_cpsec_symbol6                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL7      => puxch_cpsec_symbol7                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL8      => puxch_cpsec_symbol8                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL9      => puxch_cpsec_symbol9                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL10     => puxch_cpsec_symbol10                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL11     => puxch_cpsec_symbol11                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL12     => puxch_cpsec_symbol12                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL13     => puxch_cpsec_symbol13                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL0      => puxch_uppkt_symbol0                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL1      => puxch_uppkt_symbol1                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL2      => puxch_uppkt_symbol2                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL3      => puxch_uppkt_symbol3                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL4      => puxch_uppkt_symbol4                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL5      => puxch_uppkt_symbol5                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL6      => puxch_uppkt_symbol6                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL7      => puxch_uppkt_symbol7                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL8      => puxch_uppkt_symbol8                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL9      => puxch_uppkt_symbol9                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL10     => puxch_uppkt_symbol10                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL11     => puxch_uppkt_symbol11                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL12     => puxch_uppkt_symbol12                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL13     => puxch_uppkt_symbol13                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL0    => puxch_cq_full_symbol0                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL1    => puxch_cq_full_symbol1                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL2    => puxch_cq_full_symbol2                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL3    => puxch_cq_full_symbol3                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL4    => puxch_cq_full_symbol4                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL5    => puxch_cq_full_symbol5                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL6    => puxch_cq_full_symbol6                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL7    => puxch_cq_full_symbol7                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL8    => puxch_cq_full_symbol8                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL9    => puxch_cq_full_symbol9                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL10   => puxch_cq_full_symbol10                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL11   => puxch_cq_full_symbol11                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL12   => puxch_cq_full_symbol12                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL13   => puxch_cq_full_symbol13                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL0   => usage_puxch_cq_symbol0                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL1   => usage_puxch_cq_symbol1                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL2   => usage_puxch_cq_symbol2                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL3   => usage_puxch_cq_symbol3                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL4   => usage_puxch_cq_symbol4                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL5   => usage_puxch_cq_symbol5                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL6   => usage_puxch_cq_symbol6                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL7   => usage_puxch_cq_symbol7                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL8   => usage_puxch_cq_symbol8                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL9   => usage_puxch_cq_symbol9                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL10  => usage_puxch_cq_symbol10                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL11  => usage_puxch_cq_symbol11                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL12  => usage_puxch_cq_symbol12                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL13  => usage_puxch_cq_symbol13                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_PRACH_TERMINATION        => prach_termination                       ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL0      => prach_cpsec_symbol0                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL1      => prach_cpsec_symbol1                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL2      => prach_cpsec_symbol2                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL3      => prach_cpsec_symbol3                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL4      => prach_cpsec_symbol4                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL5      => prach_cpsec_symbol5                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL6      => prach_cpsec_symbol6                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL7      => prach_cpsec_symbol7                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL8      => prach_cpsec_symbol8                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL9      => prach_cpsec_symbol9                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL10     => prach_cpsec_symbol10                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL11     => prach_cpsec_symbol11                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL12     => prach_cpsec_symbol12                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL13     => prach_cpsec_symbol13                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL0      => prach_uppkt_symbol0                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL1      => prach_uppkt_symbol1                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL2      => prach_uppkt_symbol2                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL3      => prach_uppkt_symbol3                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL4      => prach_uppkt_symbol4                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL5      => prach_uppkt_symbol5                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL6      => prach_uppkt_symbol6                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL7      => prach_uppkt_symbol7                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL8      => prach_uppkt_symbol8                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL9      => prach_uppkt_symbol9                     ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL10     => prach_uppkt_symbol10                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL11     => prach_uppkt_symbol11                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL12     => prach_uppkt_symbol12                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL13     => prach_uppkt_symbol13                    ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL0    => prach_cq_full_symbol0                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL1    => prach_cq_full_symbol1                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL2    => prach_cq_full_symbol2                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL3    => prach_cq_full_symbol3                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL4    => prach_cq_full_symbol4                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL5    => prach_cq_full_symbol5                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL6    => prach_cq_full_symbol6                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL7    => prach_cq_full_symbol7                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL8    => prach_cq_full_symbol8                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL9    => prach_cq_full_symbol9                   ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL10   => prach_cq_full_symbol10                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL11   => prach_cq_full_symbol11                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL12   => prach_cq_full_symbol12                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL13   => prach_cq_full_symbol13                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL0   => usage_prach_cq_symbol0                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL1   => usage_prach_cq_symbol1                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL2   => usage_prach_cq_symbol2                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL3   => usage_prach_cq_symbol3                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL4   => usage_prach_cq_symbol4                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL5   => usage_prach_cq_symbol5                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL6   => usage_prach_cq_symbol6                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL7   => usage_prach_cq_symbol7                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL8   => usage_prach_cq_symbol8                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL9   => usage_prach_cq_symbol9                  ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL10  => usage_prach_cq_symbol10                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL11  => usage_prach_cq_symbol11                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL12  => usage_prach_cq_symbol12                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL13  => usage_prach_cq_symbol13                 ,--: in  std_logic_array32(UL_UNIT-1 downto 0);

        DL_UP_CP_RX_CORRUPT         => cnt_rx_corrupt                          ,--: in  std_logic_vector(63 downto 0);
        DL_UP_CP_RX_CORRUPT_ECPRIVERSION_PAYLOADVERSION_PCID         => cnt_rx_corrupt_ecpriversion_payloadversion_pcid                          ,--: in  std_logic_vector(63 downto 0);
        DL_UP_CP_RX_CORRUPT_SECTIONID                                => cnt_rx_corrupt_sectionid                          ,--: in  std_logic_vector(63 downto 0);

        DL_UP_CP_CNT_RX_PCID                                         => cnt_rx_corrupt_pcid          ,
        DL_UP_CP_CNT_RX_eCPRIVERSION                                 => cnt_rx_corrupt_ecpriversion  ,
        DL_UP_CP_CNT_RX_PAYLOADVERSION                               => cnt_rx_corrupt_payloadversion,
        DL_UP_CP_RX_CORRUPT_MEASUREMENT_PERIOD                       => rx_corrupt_measurement_period,

                
        WREN_CPUIF_IN               => WREN_CPUIF_IN                           ,--: in  std_logic;
        RDEN_CPUIF_IN               => RDEN_CPUIF_IN                           ,--: in  std_logic;
        ADDR_CPUIF_IN               => ADDR_CPUIF_IN                           ,--: in  std_logic_vector(15 downto 0);    
        WDATA_CPUIF_IN              => WDATA_CPUIF_IN                          ,--: in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             => RDATA_CPUIF_OUT                         ,--: out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             => RDVAL_CPUIF_OUT                          --: out std_logic
    );

end BEHAVE;