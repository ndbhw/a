--================================================================================
-- Filename     : TDD_INFO.vhd
-- Author       : Taeyoup Kim (taeyoup.kim@samsung.com)
-- Description  : TDD Allocation Information from O-RAN C-Plane(DL/UL)
----------------------------------------------------------------------------------
--     Date    |     By           |  Version | Description
----------------------------------------------------------------------------------
--  02-17-2021 | Taeyoup Kim      |    1.0   | Original Version   
--================================================================================
-- Copyright (c) 2021 SAMSUNG. All rights reserved.                               
--================================================================================

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;   
use IEEE.NUMERIC_STD.ALL;
use IEEE.MATH_REAL.ALL;


    entity TDD_INFO is
    generic (   
    CH_NUM                         : natural :=  4;
    DL_LAYER_NUM                   : natural :=  4;                              
    UL_RX_NUM                      : natural :=  8;                              
    Opt_BF_Support                 : natural :=  1  -- Mandatory: 0, Optional: 1 
    );
    port (

    CLK                            : in std_logic;

    --------------------------------------------------------------------------------
    -- CP_PARSER
    --------------------------------------------------------------------------------

    CP_UPDATE                      : in std_logic;
    CP_CH_IDX                      : in std_logic_vector(3 downto 0); 
    CP_PARAMETER                   : in std_logic_vector(191+(15*3)+6 downto 0);  

    --------------------------------------------------------------------------------
    -- DL Sync Advance
    --------------------------------------------------------------------------------

    ADV_SBF_SYNC                   : in std_logic;                              
    ADV_SLOT_SYNC                  : in std_logic;                         
    ADV_SLOT_IDX                   : in std_logic_vector(7 downto 0);       
    ADV_SYMBOL_SYNC                : in std_logic;                                 
    ADV_SYMBOL_CH_SYNC             : in std_logic; 
    ADV_SYMBOL_IDX                 : in std_logic_vector(3 downto 0);         
                                                           
    --------------------------------------------------------------------------------
    -- Output to SYSCTRL
    --------------------------------------------------------------------------------

    SYMBOL_SYNC                    : out std_logic; 
    SYMBOL_INDEX                   : out std_logic_vector(3 downto 0);
    TDD_DL_EN                      : out std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0);
    TDD_UL_EN                      : out std_logic_vector((Opt_BF_Support*(UL_RX_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0) 

    );
    end TDD_INFO;

architecture BEHAVE of TDD_INFO is
                                                                     
    signal data_direction          : std_logic := '0';                          
    signal slot_id 	               : std_logic_vector(5 downto 0) := (others => '0');     
    signal start_symbol            : std_logic_vector(3 downto 0) := (others => '0');     
    signal end_symbol              : std_logic_vector(3 downto 0) := (others => '0');
    signal adv_symbol_sync_d       : std_logic := '0';

    signal adv_symbol_index        : natural range 0 to 13 := 0; 
    signal dl_update               : std_logic_vector((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0) := (others => '0'); 
    signal ul_update               : std_logic_vector((Opt_BF_Support*(UL_RX_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0) := (others => '0'); 
    type   std_logic_array14       is array(natural range <>) of std_logic_vector(13 downto 0);
    signal tdd_dl_slot0            : std_logic_array14((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0) := (others => (others => '0'));
    signal tdd_dl_slot1            : std_logic_array14((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0) := (others => (others => '0'));
    signal tdd_ul_slot0            : std_logic_array14((Opt_BF_Support*(UL_RX_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0) := (others => (others => '0')); 
    signal tdd_ul_slot1            : std_logic_array14((Opt_BF_Support*(UL_RX_NUM - CH_NUM) + CH_NUM)*01 - 1 downto 0) := (others => (others => '0')); 

   
begin


--=============================================================================================================== 
--  C-Plane Parameter mapping                                                                                               
--=============================================================================================================== 

    data_direction  <= CP_PARAMETER(31);  

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then 
           slot_id 	    <= CP_PARAMETER(11 downto 6);
           start_symbol <= CP_PARAMETER(3 downto 0);
           end_symbol   <= CP_PARAMETER(3 downto 0) + CP_PARAMETER(19+128 downto 16+128);
        end if;
    end process; 

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
           adv_symbol_sync_d <= ADV_SYMBOL_SYNC;

           if (adv_symbol_sync_d = '1' or ADV_SYMBOL_SYNC = '1') then
              SYMBOL_SYNC <= '1';
           else
              SYMBOL_SYNC <= '0';                        
           end if;               
        end if; 
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
           if (ADV_SYMBOL_SYNC = '1') then
              SYMBOL_INDEX <= ADV_SYMBOL_IDX;             
           end if;               
        end if; 
    end process;

    adv_symbol_index <= conv_integer(ADV_SYMBOL_IDX);          

--===============================================================================================================
--  DL processing                                                                                    
--===============================================================================================================

    u_dl_update : for i in ((Opt_BF_Support*(DL_LAYER_NUM - CH_NUM) + CH_NUM)*01 - 1) downto 0 generate

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
           if (CP_UPDATE = '1' and data_direction = '1' and CP_CH_IDX = i) then
              dl_update(i) <= '1';
           else
              dl_update(i) <= '0';           
           end if;    
        end if; 
    end process;

    -- slot0 
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
           if (ADV_SLOT_SYNC = '1' and ADV_SLOT_IDX(0) = '1') then
                 tdd_dl_slot0(i) <= (others => '0');                   
           elsif (dl_update(i) = '1' and slot_id(0) = '0') then
              for j in 13 downto 0 loop 
                 if (start_symbol <= j and j < end_symbol) then
                    tdd_dl_slot0(i)(j) <= '1';             
                 end if;
              end loop;              
           end if;      
        end if; 
    end process;

    -- slot1 
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
           if (ADV_SLOT_SYNC = '1' and ADV_SLOT_IDX(0) = '0') then
                 tdd_dl_slot1(i) <= (others => '0');                   
           elsif (dl_update(i) = '1' and slot_id(0) = '1') then
              for j in 13 downto 0 loop 
                 if (start_symbol <= j and j < end_symbol) then
                    tdd_dl_slot1(i)(j) <= '1';             
                 end if;
              end loop;              
           end if;      
        end if; 
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
           if (ADV_SYMBOL_SYNC = '1') then
              if (ADV_SLOT_IDX(0) = '0') then
                 TDD_DL_EN(i) <= tdd_dl_slot0(i)(adv_symbol_index);             
              else
                 TDD_DL_EN(i) <= tdd_dl_slot1(i)(adv_symbol_index);                         
              end if;
           end if;               
        end if; 
    end process;

    end generate; 

--===============================================================================================================
--  UL processing                                                                                    
--===============================================================================================================

    u_ul_update : for i in ((Opt_BF_Support*(UL_RX_NUM - CH_NUM) + CH_NUM)*01 - 1) downto 0 generate

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
           if (CP_UPDATE = '1' and data_direction = '0' and CP_CH_IDX = i) then
              ul_update(i) <= '1';
           else
              ul_update(i) <= '0';           
           end if;    
        end if; 
    end process;

    -- slot0 
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
           if (ADV_SLOT_SYNC = '1' and ADV_SLOT_IDX(0) = '1') then
                 tdd_ul_slot0(i) <= (others => '0');                   
           elsif (ul_update(i) = '1' and slot_id(0) = '0') then
              for j in 13 downto 0 loop 
                 if (start_symbol <= j and j < end_symbol) then
                    tdd_ul_slot0(i)(j) <= '1';             
                 end if;
              end loop;              
           end if;      
        end if; 
    end process;

    -- slot1 
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
           if (ADV_SLOT_SYNC = '1' and ADV_SLOT_IDX(0) = '0') then
                 tdd_ul_slot1(i) <= (others => '0');                   
           elsif (ul_update(i) = '1' and slot_id(0) = '1') then
              for j in 13 downto 0 loop 
                 if (start_symbol <= j and j < end_symbol) then
                    tdd_ul_slot1(i)(j) <= '1';             
                 end if;
              end loop;              
           end if;      
        end if; 
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
           if (ADV_SYMBOL_SYNC = '1') then
              if (ADV_SLOT_IDX(0) = '0') then
                 TDD_UL_EN(i) <= tdd_ul_slot0(i)(adv_symbol_index);             
              else
                 TDD_UL_EN(i) <= tdd_ul_slot1(i)(adv_symbol_index);                         
              end if;
           end if;               
        end if; 
    end process;

    end generate; 
     
                                                        
end BEHAVE;

