--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Generate pulse to clear, same-clock (MPI component)           --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity MPI_CLEAR is
    generic (
        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        EN                          : in  std_logic;                            -- long pulse
        ADDR                        : in  std_logic_vector(7 downto 0);
        DATA_OUT                    : out std_logic                             -- 1-pulse@CLK
    );
end MPI_CLEAR;

architecture BEHAVE of MPI_CLEAR is

    signal enable                   : std_logic;
    signal retiming                 : std_logic_vector(2 downto 0) := (others => '0');
    signal clear                    : std_logic := '0';

begin

    process (RESET, CLK)
    begin
        if (RESET = '1') then
            enable <= '0';
        elsif (CLK'event and CLK = '1') then
            if (ADDR = REG_ADDR) and (EN = '1') then
                enable <= '1';
            else
                enable <= '0';
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            retiming <= retiming(1 downto 0) & enable;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (retiming(2 downto 1) = "10") then
                clear <= '1';
            else
                clear <= '0';
            end if;
        end if;
    end process;

    DATA_OUT <= clear;

end BEHAVE;
