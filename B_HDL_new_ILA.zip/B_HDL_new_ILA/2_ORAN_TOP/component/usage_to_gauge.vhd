--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Convert from usage to level (O-RAN component)                 --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.20                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity USAGE_TO_GAUGE is
    generic (
        MAX_USAGE                   : natural := 1024
    );
    port (
        CLK                         : in  std_logic;

        USAGE                       : in  std_logic_vector(31 downto 0);
        GAUGE                       : out std_logic_vector(31 downto 0)
    );
end USAGE_TO_GAUGE;

architecture BEHAVE of USAGE_TO_GAUGE is

    function LOG2 (
        DATA_VALUE                  : integer
    )
    return integer is
        variable width              : integer := 0;
        variable cnt                : integer := 1;
    begin
        if (DATA_VALUE <= 1) then
            width := 0;
        else
            while (cnt < DATA_VALUE) loop
                width := width + 1;
                cnt   := cnt * 2;
            end loop;
        end if;
    return width;
    end LOG2;

    signal conv_usage               : std_logic_vector(4 downto 0);

begin

    conv_usage <= USAGE(LOG2(MAX_USAGE/32)+4 downto LOG2(MAX_USAGE/32));

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (USAGE = 0) then
                GAUGE(0) <= '0';
            else
                GAUGE(0) <= '1';
            end if;
        end if;
    end process;

    u_OTHER_BITS : for i in 31 downto 1 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (conv_usage >= i) then
                GAUGE(i)  <= '1';
            else
                GAUGE(i)  <= '0';
            end if;
        end if;
    end process;
    end generate;

end BEHAVE;