--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : CPU interface                                                 --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
--   v1.0 - initial release                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

use WORK.ARRAY_TYPE.ALL;

entity O_RAN_MPI is
    generic (
        OFFSET                      : std_logic_vector(3 downto 0) := x"3";
        DL_UNIT                     : natural := 8;
        UL_UNIT                     : natural := 8;
        MAX_CH_PER_UNIT             : natural := 2;
        MAX_ID_PER_CH               : natural := 1
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;                            -- 100-MHz
        RST                         : in  std_logic;

        CLK_MAC_RX                  : in  std_logic;                            -- 156.25/390.625-MHz
        CLK_MAC_TX                  : in  std_logic;                            -- 156.25/390.625-MHz
        CLK_BUS                     : in  std_logic;                            -- 245.76-MHz

--------------------------------------------------------------------------------
-- Debug
--------------------------------------------------------------------------------

        IGNORE_FRAME_ID             : out std_logic_vector(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PUxCH_RX    : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH_RX    : in  std_logic_array8(UL_UNIT-1 downto 0);
        IGNORE_FRAME_ID_PRACH_TX    : in  std_logic_array8(UL_UNIT-1 downto 0);

--------------------------------------------------------------------------------
-- O-RAN configuration
--------------------------------------------------------------------------------

        DL_PARAM_MAC                : out std_logic_array48(DL_UNIT-1 downto 0);
        DL_PARAM_ID0_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID0                : out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID1_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID1                : out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID2_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID2                : out std_logic_array8_array16(DL_UNIT-1 downto 0);
        DL_PARAM_ID3_EN             : out std_logic_array8(DL_UNIT-1 downto 0);
        DL_PARAM_ID3                : out std_logic_array8_array16(DL_UNIT-1 downto 0);

        DL_COMP_MODE                : out std_logic_vector(DL_UNIT-1 downto 0);
        DL_IQ_WIDTH                 : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_COMP_METHOD              : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_SCS_CONFIG               : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_FFT_SIZE                 : out std_logic_array4(DL_UNIT-1 downto 0);
        DL_PRB_PER_SYMBOL           : out std_logic_array10(DL_UNIT-1 downto 0);
        DL_COMP_EXP_OFFSET          : out std_logic_array5(DL_UNIT-1 downto 0);

        UL_PARAM_DST_MAC            : out std_logic_array48(UL_UNIT-1 downto 0);
        UL_PARAM_SRC_MAC            : out std_logic_array48(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN0_MODE         : out std_logic_vector(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN0_TCI          : out std_logic_array16(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN1_MODE         : out std_logic_vector(UL_UNIT-1 downto 0);
        UL_PARAM_VLAN1_TCI          : out std_logic_array16(UL_UNIT-1 downto 0);

        UL_COMP_MODE                : out std_logic_vector(UL_UNIT-1 downto 0);
        UL_IQ_WIDTH                 : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_COMP_METHOD              : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_SCS_CONFIG               : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_FFT_SIZE                 : out std_logic_array4(UL_UNIT-1 downto 0);
        UL_PRB_PER_MTU              : out std_logic_array10(UL_UNIT-1 downto 0);
        UL_PRB_PER_SYMBOL           : out std_logic_array10(UL_UNIT-1 downto 0);
        UL_COMP_EXP_OFFSET          : out std_logic_array5(UL_UNIT-1 downto 0);
        UL_COMP_GAIN_OFFSET         : out std_logic_array11(UL_UNIT-1 downto 0);
        UL_COMP_SCALE_GAIN_OFFSET   : out std_logic_array4(UL_UNIT-1 downto 0);

--------------------------------------------------------------------------------
-- O-RAN Statistics
--------------------------------------------------------------------------------

        T2A_MAX_CP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        T2A_MIN_CP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        CP_DL_PERIOD                : out std_logic_array8(DL_UNIT-1 downto 0);

        CP_DL_CNT_CLEAR             : out std_logic_array4(DL_UNIT-1 downto 0);
        CP_DL_ON_TIME               : in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_EARLY                 : in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_LATE                  : in  std_logic_array64(DL_UNIT-1 downto 0);
        CP_DL_OUT_OF_RANGE          : in  std_logic_array64(DL_UNIT-1 downto 0);

        T2A_MAX_UP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        T2A_MIN_UP_DL               : out std_logic_array22(DL_UNIT-1 downto 0);
        UP_DL_PERIOD                : out std_logic_array8(DL_UNIT-1 downto 0);

        UP_DL_CNT_CLEAR             : out std_logic_array4(DL_UNIT-1 downto 0);
        UP_DL_ON_TIME               : in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_EARLY                 : in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_LATE                  : in  std_logic_array64(DL_UNIT-1 downto 0);
        UP_DL_OUT_OF_RANGE          : in  std_logic_array64(DL_UNIT-1 downto 0);

        T2A_MAX_CP_UL               : out std_logic_array22(UL_UNIT-1 downto 0);
        T2A_MIN_CP_UL               : out std_logic_array22(UL_UNIT-1 downto 0);
        CP_UL_PERIOD                : out std_logic_array8(UL_UNIT-1 downto 0);

        CP_UL_CNT_CLEAR             : out std_logic_array4(UL_UNIT-1 downto 0);
        CP_UL_ON_TIME               : in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_EARLY                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_LATE                  : in  std_logic_array64(UL_UNIT-1 downto 0);
        CP_UL_OUT_OF_RANGE          : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP0_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP0_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP0_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP0_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP0_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP0_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

        TA3_MIN_UP1_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        TA3_MAX_UP1_UL              : out std_logic_array22(UL_UNIT-1 downto 0);
        UP1_UL_PERIOD               : out std_logic_array8(UL_UNIT-1 downto 0);

        UP1_UL_CNT_CLEAR            : out std_logic_array4(UL_UNIT-1 downto 0);
        UP1_UL_ON_TIME              : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_EARLY                : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_LATE                 : in  std_logic_array64(UL_UNIT-1 downto 0);
        UP1_UL_OUT_OF_RANGE         : in  std_logic_array64(UL_UNIT-1 downto 0);

--------------------------------------------------------------------------------
-- Statistics (eCPRI, Debug)
--------------------------------------------------------------------------------

        DL_C_PLANE_BUFFER           : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_BUFFER           : in  std_logic_array32(DL_UNIT-1 downto 0);

        DL_INVALID_DST_MAC          : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ETHERTYPE        : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriVersion     : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriC           : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_INVALID_ecpriMessage     : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_C_PLANE                  : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_C_PLANE_DROPPED          : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE                  : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_DROPPED          : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_LOST                     : in  std_logic_array32(DL_UNIT-1 downto 0);

        DL_C_PLANE_EXIST            : in  std_logic_array32(DL_UNIT-1 downto 0);
        DL_U_PLANE_EXIST            : in  std_logic_array32(DL_UNIT-1 downto 0);

        RX_FAULT_ID_31_CH0          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH1          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH2          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH3          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH4          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH5          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH6          : in  std_logic_array4(DL_UNIT-1 downto 0);
        RX_FAULT_ID_31_CH7          : in  std_logic_array4(DL_UNIT-1 downto 0);

--        UL_PUxCH_C_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PUxCH_C_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_PUxCH_C_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_U_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PRACH_C_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE_BUFFER     : in  std_logic_array32(UL_UNIT-1 downto 0);

--        UL_PRACH_C_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
--        UL_PRACH_C_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE            : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_U_PLANE_LOST       : in  std_logic_array32(UL_UNIT-1 downto 0);

--------------------------------------------------------------------------------
-- Statistics (O-RAN, Debug)
--------------------------------------------------------------------------------

        UL_CMD_FIFO_FULL            : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_PUxCH_TERMINATION        : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CPSEC_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_UPPKT_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL0    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL1    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL2    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL3    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL4    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL5    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL6    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL7    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL8    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL9    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL10   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL11   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL12   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_FULL_SYMBOL13   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL0   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL1   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL2   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL3   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL4   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL5   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL6   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL7   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL8   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL9   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL10  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL11  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL12  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PUxCH_CQ_USAGE_SYMBOL13  : in  std_logic_array32(UL_UNIT-1 downto 0);

        UL_PRACH_TERMINATION        : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CPSEC_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL0      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL1      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL2      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL3      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL4      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL5      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL6      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL7      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL8      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL9      : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL10     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL11     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL12     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_UPPKT_SYMBOL13     : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL0    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL1    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL2    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL3    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL4    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL5    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL6    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL7    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL8    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL9    : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL10   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL11   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL12   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_FULL_SYMBOL13   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL0   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL1   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL2   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL3   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL4   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL5   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL6   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL7   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL8   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL9   : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL10  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL11  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL12  : in  std_logic_array32(UL_UNIT-1 downto 0);
        UL_PRACH_CQ_USAGE_SYMBOL13  : in  std_logic_array32(UL_UNIT-1 downto 0);

        DL_UP_CP_RX_CORRUPT         : in  std_logic_vector(63 downto 0);
        DL_UP_CP_RX_CORRUPT_ECPRIVERSION_PAYLOADVERSION_PCID             : in  std_logic_vector(63 downto 0);
        DL_UP_CP_RX_CORRUPT_SECTIONID                                    : in  std_logic_vector(63 downto 0);
        DL_UP_CP_CNT_RX_PCID                                             : in std_logic_vector(63 downto 0);
        DL_UP_CP_CNT_RX_eCPRIVERSION                                     : in std_logic_vector(63 downto 0);
        DL_UP_CP_CNT_RX_PAYLOADVERSION                                   : in std_logic_vector(63 downto 0);
        DL_UP_CP_RX_CORRUPT_MEASUREMENT_PERIOD                           : out std_logic_array8(DL_UNIT-1 downto 0);

--------------------------------------------------------------------------------
-- CPU
--------------------------------------------------------------------------------

        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);    
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             : out std_logic
    );
end O_RAN_MPI;

architecture BEHAVE of O_RAN_MPI is

    signal we_buf                   : std_logic;
    signal we                       : std_logic_vector(31 downto 0);
    signal we_long                  : std_logic_vector(31 downto 0);
    signal oe_buf                   : std_logic;
    signal oe                       : std_logic_vector(31 downto 0);
    signal oe_long                  : std_logic_vector(31 downto 0);
    signal addr                     : std_logic_vector(15 downto 0);
    signal addr_msb                 : std_logic_vector(4 downto 0);
    signal addr_lsb                 : std_logic_vector(7 downto 0);
    signal read_data                : std_logic_array32(31 downto 0) := (others => (others => '0'));
    signal read_valid               : std_logic_vector(3 downto 0);

    component MPI_REG_WO is
    generic (
        BIT_WIDTH                   : natural := 32;
        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0');
        REG_DATA                    : std_logic_vector(31 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        EN                          : in  std_logic;
        ADDR                        : in  std_logic_vector(7 downto 0);
        DATA_IN                     : in  std_logic_vector(BIT_WIDTH-1 downto 0);
        DATA_OUT                    : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
    end component;

--    component COMP_CDC is
--    generic (
--        REG_DATA                    : std_logic_vector(31 downto 0) := (others => '0')
--    );
--    port (
--        RESET                       : in  std_logic;
--        CLK_IN                      : in  std_logic;
--        CLK_OUT                     : in  std_logic;
--
--        DATA_IN                     : in  std_logic_vector(31 downto 0);
--        DATA_OUT                    : out std_logic_vector(31 downto 0)
--    );
--    end component;

    component MPI_REG_RC is
    generic (
        BIT_WIDTH                   : natural := 32;
        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        EN                          : in  std_logic;
        ADDR                        : in  std_logic_vector(7 downto 0);
        DATA_IN                     : in  std_logic_vector(BIT_WIDTH-1 downto 0);
        DATA_OUT                    : out std_logic_vector(BIT_WIDTH-1 downto 0);
        FLAG_OUT                    : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
    end component;

    component MPI_CLEAR is
    generic (
        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        EN                          : in  std_logic;
        ADDR                        : in  std_logic_vector(7 downto 0);
        DATA_OUT                    : out std_logic
    );
    end component;

--    component MPI_CLEAR_CDC is
--    generic (
--        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0')
--    );
--    port (
--        RESET                       : in  std_logic;
--        CLK                         : in  std_logic;
--        CLK_TARGET                  : in  std_logic;
--
--        EN                          : in  std_logic;
--        ADDR                        : in  std_logic_vector(7 downto 0);
--        DATA_OUT                    : out std_logic
--    );
--    end component;

    -- ..._w : write
    -- ..._r : read
    -- ..._c : CDC
    -- ..._s : status
    -- ..._f : flag

    signal rx_param_mac_w           : std_logic_array64(DL_UNIT-1 downto 0);
    signal rx_param_mac_r           : std_logic_array64(15 downto 0);

    signal tx_param_dst_mac_w       : std_logic_array64(UL_UNIT-1 downto 0);
    signal tx_param_dst_mac_r       : std_logic_array64(15 downto 0);
    signal tx_param_src_mac_w       : std_logic_array64(UL_UNIT-1 downto 0);
    signal tx_param_src_mac_r       : std_logic_array64(15 downto 0);
    signal tx_param_vlan0_w         : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_param_vlan0_r         : std_logic_array32(15 downto 0);
    signal tx_param_vlan1_w         : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_param_vlan1_r         : std_logic_array32(15 downto 0);

    signal ignore_frame_id_w        : std_logic_array32(UL_UNIT-1 downto 0);
    signal ignore_frame_id_r        : std_logic_array32(15 downto 0);
    signal ignore_frame_id_puxch_r  : std_logic_array32(15 downto 0);
    signal ignore_frame_id_prach_r  : std_logic_array32(15 downto 0);

    signal rx_param_id0_w           : std_logic_array8_array32(DL_UNIT-1 downto 0);
    signal rx_param_id0_r           : std_logic_array8_array32(15 downto 0);
    signal rx_param_id1_w           : std_logic_array8_array32(DL_UNIT-1 downto 0);
    signal rx_param_id1_r           : std_logic_array8_array32(15 downto 0);
    signal rx_param_id2_w           : std_logic_array8_array32(DL_UNIT-1 downto 0);
    signal rx_param_id2_r           : std_logic_array8_array32(15 downto 0);
    signal rx_param_id3_w           : std_logic_array8_array32(DL_UNIT-1 downto 0);
    signal rx_param_id3_r           : std_logic_array8_array32(15 downto 0);

    signal rx_comp_mode_w           : std_logic_array32(DL_UNIT-1 downto 0);
    signal rx_comp_mode_r           : std_logic_array32(15 downto 0);
    signal rx_scs_config_w          : std_logic_array32(DL_UNIT-1 downto 0);
    signal rx_scs_config_r          : std_logic_array32(15 downto 0);
    signal rx_fft_size_w            : std_logic_array32(DL_UNIT-1 downto 0);
    signal rx_fft_size_r            : std_logic_array32(15 downto 0);
    signal rx_prb_per_symbol_w      : std_logic_array32(DL_UNIT-1 downto 0);
    signal rx_prb_per_symbol_r      : std_logic_array32(15 downto 0);
    signal rx_comp_exp_offset_w     : std_logic_array32(DL_UNIT-1 downto 0);
    signal rx_comp_exp_offset_r     : std_logic_array32(15 downto 0);

    signal tx_comp_mode_w           : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_comp_mode_r           : std_logic_array32(15 downto 0);
    signal tx_fft_size_w            : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_fft_size_r            : std_logic_array32(15 downto 0);
    signal tx_scs_config_w          : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_scs_config_r          : std_logic_array32(15 downto 0);
    signal tx_prb_per_symbol_w      : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_prb_per_symbol_r      : std_logic_array32(15 downto 0);
    signal tx_comp_exp_offset_w     : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_comp_exp_offset_r     : std_logic_array32(15 downto 0);
    signal tx_comp_gain_offset_w    : std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_comp_gain_offset_r    : std_logic_array32(15 downto 0);
    signal tx_comp_scale_gain_offset_w: std_logic_array32(UL_UNIT-1 downto 0);
    signal tx_comp_scale_gain_offset_r: std_logic_array32(15 downto 0);

    signal t2a_max_cp_dl_w          : std_logic_array32(DL_UNIT-1 downto 0);
    signal t2a_max_cp_dl_r          : std_logic_array32(15 downto 0);
    signal t2a_min_cp_dl_w          : std_logic_array32(DL_UNIT-1 downto 0);
    signal t2a_min_cp_dl_r          : std_logic_array32(15 downto 0);
    signal cp_dl_period_w           : std_logic_array32(DL_UNIT-1 downto 0);
    signal cp_dl_period_r           : std_logic_array32(15 downto 0);
    signal cp_dl_on_time_r          : std_logic_array64(15 downto 0);
    signal cp_dl_early_r            : std_logic_array64(15 downto 0);
    signal cp_dl_late_r             : std_logic_array64(15 downto 0);
    signal cp_dl_out_of_range_r     : std_logic_array64(15 downto 0);
    signal t2a_max_up_dl_w          : std_logic_array32(DL_UNIT-1 downto 0);
    signal t2a_max_up_dl_r          : std_logic_array32(15 downto 0);
    signal t2a_min_up_dl_w          : std_logic_array32(DL_UNIT-1 downto 0);
    signal t2a_min_up_dl_r          : std_logic_array32(15 downto 0);
    signal up_dl_period_w           : std_logic_array32(DL_UNIT-1 downto 0);
    signal up_dl_period_r           : std_logic_array32(15 downto 0);
    signal up_dl_on_time_r          : std_logic_array64(15 downto 0);
    signal up_dl_early_r            : std_logic_array64(15 downto 0);
    signal up_dl_late_r             : std_logic_array64(15 downto 0);
    signal up_dl_out_of_range_r     : std_logic_array64(15 downto 0);
    signal t2a_max_cp_ul_w          : std_logic_array32(UL_UNIT-1 downto 0);
    signal t2a_max_cp_ul_r          : std_logic_array32(15 downto 0);
    signal t2a_min_cp_ul_w          : std_logic_array32(UL_UNIT-1 downto 0);
    signal t2a_min_cp_ul_r          : std_logic_array32(15 downto 0);
    signal cp_ul_period_w           : std_logic_array32(UL_UNIT-1 downto 0);
    signal cp_ul_period_r           : std_logic_array32(15 downto 0);
    signal cp_ul_on_time_r          : std_logic_array64(15 downto 0);
    signal cp_ul_early_r            : std_logic_array64(15 downto 0);
    signal cp_ul_late_r             : std_logic_array64(15 downto 0);
    signal cp_ul_out_of_range_r     : std_logic_array64(15 downto 0);
--    signal ta3_min_up0_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_min_up0_ul_r         : std_logic_array32(15 downto 0);
--    signal ta3_max_up0_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_max_up0_ul_r         : std_logic_array32(15 downto 0);
    signal up0_ul_period_w          : std_logic_array32(UL_UNIT-1 downto 0);
    signal up0_ul_period_r          : std_logic_array32(15 downto 0);
    signal up0_ul_on_time_r         : std_logic_array64(15 downto 0);
    signal up0_ul_early_r           : std_logic_array64(15 downto 0);
    signal up0_ul_late_r            : std_logic_array64(15 downto 0);
    signal up0_ul_out_of_range_r    : std_logic_array64(15 downto 0);
--    signal ta3_min_up1_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_min_up1_ul_r         : std_logic_array32(15 downto 0);
--    signal ta3_max_up1_ul_w         : std_logic_array32(UL_UNIT-1 downto 0);
--    signal ta3_max_up1_ul_r         : std_logic_array32(15 downto 0);
    signal up1_ul_period_w          : std_logic_array32(UL_UNIT-1 downto 0);
    signal up1_ul_period_r          : std_logic_array32(15 downto 0);
    signal up1_ul_on_time_r         : std_logic_array64(15 downto 0);
    signal up1_ul_early_r           : std_logic_array64(15 downto 0);
    signal up1_ul_late_r            : std_logic_array64(15 downto 0);
    signal up1_ul_out_of_range_r    : std_logic_array64(15 downto 0);

    signal rx_fault_id_31_ch0_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch0_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch0_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch0_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch0_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch0_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch0_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch0_3_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch1_3_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch2_3_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch3_3_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch4_3_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch5_3_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch6_3_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_0_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_0_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_1_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_1_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_2_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_2_f   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_3_r   : std_logic_array32(15 downto 0);
    signal rx_fault_id_31_ch7_3_f   : std_logic_array32(15 downto 0);

    signal rx_invalid_dst_mac_r     : std_logic_array32(15 downto 0);
    signal rx_invalid_ethertype_r   : std_logic_array32(15 downto 0);
    signal rx_invalid_ecpriver_r    : std_logic_array32(15 downto 0);
    signal rx_invalid_ecpric_r      : std_logic_array32(15 downto 0);
    signal rx_invalid_ecprimsg_r    : std_logic_array32(15 downto 0);
    signal rx_lost_r                : std_logic_array32(15 downto 0);

    signal rx_c_plane_exist_r       : std_logic_array32(15 downto 0);
    signal rx_c_plane_exist_f       : std_logic_array32(15 downto 0);
    signal rx_c_plane_r             : std_logic_array32(15 downto 0);
    signal rx_c_plane_dropped_r     : std_logic_array32(15 downto 0);
    signal rx_c_plane_buffer_r      : std_logic_array32(15 downto 0);
    signal rx_c_plane_buffer_f      : std_logic_array32(15 downto 0);
    signal rx_u_plane_exist_r       : std_logic_array32(15 downto 0);
    signal rx_u_plane_exist_f       : std_logic_array32(15 downto 0);
    signal rx_u_plane_r             : std_logic_array32(15 downto 0);
    signal rx_u_plane_dropped_r     : std_logic_array32(15 downto 0);
    signal rx_u_plane_buffer_r      : std_logic_array32(15 downto 0);
    signal rx_u_plane_buffer_f      : std_logic_array32(15 downto 0);

--    signal tx0_c_plane_r            : std_logic_array32(15 downto 0);
--    signal tx0_c_plane_lost_r       : std_logic_array32(15 downto 0);
--    signal tx0_c_plane_buffer_r     : std_logic_array32(15 downto 0);
--    signal tx0_c_plane_buffer_f     : std_logic_array32(15 downto 0);
    signal tx0_u_plane_r            : std_logic_array32(15 downto 0);
    signal tx0_u_plane_lost_r       : std_logic_array32(15 downto 0);
    signal tx0_u_plane_buffer_r     : std_logic_array32(15 downto 0);
    signal tx0_u_plane_buffer_f     : std_logic_array32(15 downto 0);

--    signal tx1_c_plane_r            : std_logic_array32(15 downto 0);
--    signal tx1_c_plane_lost_r       : std_logic_array32(15 downto 0);
--    signal tx1_c_plane_buffer_r     : std_logic_array32(15 downto 0);
--    signal tx1_c_plane_buffer_f     : std_logic_array32(15 downto 0);
    signal tx1_u_plane_r            : std_logic_array32(15 downto 0);
    signal tx1_u_plane_lost_r       : std_logic_array32(15 downto 0);
    signal tx1_u_plane_buffer_r     : std_logic_array32(15 downto 0);
    signal tx1_u_plane_buffer_f     : std_logic_array32(15 downto 0);

    signal tx_cmd_fifo_full_r       : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_termination_r        : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cpsec_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_uppkt_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol0_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol1_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol2_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol3_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol4_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol5_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol6_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol7_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol8_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol9_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol10_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol11_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol12_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_full_symbol13_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol0_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol0_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol1_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol1_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol2_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol2_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol3_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol3_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol4_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol4_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol5_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol5_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol6_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol6_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol7_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol7_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol8_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol8_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol9_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol9_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol10_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol10_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol11_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol11_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol12_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol12_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol13_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx0_cq_usage_symbol13_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));

    signal tx1_termination_r        : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cpsec_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol0_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol1_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol2_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol3_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol4_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol5_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol6_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol7_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol8_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol9_r      : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol10_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol11_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol12_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_uppkt_symbol13_r     : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol0_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol1_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol2_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol3_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol4_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol5_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol6_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol7_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol8_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol9_r    : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol10_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol11_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol12_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_full_symbol13_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol0_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol0_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol1_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol1_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol2_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol2_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol3_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol3_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol4_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol4_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol5_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol5_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol6_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol6_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol7_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol7_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol8_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol8_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol9_r   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol9_f   : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol10_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol10_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol11_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol11_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol12_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol12_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol13_r  : std_logic_array32(15 downto 0) := (others => (others => '0'));
    signal tx1_cq_usage_symbol13_f  : std_logic_array32(15 downto 0) := (others => (others => '0'));

    signal rx_corrupt_cnt_measurement_period_w          : std_logic_array32(8-1 downto 0);
    signal rx_corrupt_cnt_measurement_period_r          : std_logic_array32(8-1 downto 0);
begin

--------------------------------------------------------------------------------
-- WE/OE, address decoding
--------------------------------------------------------------------------------

    addr     <= "000" & ADDR_CPUIF_IN(12 downto 0) when OFFSET(0) = '0' else
                "000" & (not ADDR_CPUIF_IN(12)) & ADDR_CPUIF_IN(11 downto 0);
    addr_msb <= addr(12 downto 8);
    addr_lsb <= addr(7 downto 0);

    process (RST, CLK)
    begin
        if (RST = '1') then
            we_buf <= '0';
            oe_buf <= '0';
        elsif (CLK'event and CLK = '1') then
            we_buf <= WREN_CPUIF_IN;
            oe_buf <= RDEN_CPUIF_IN;
        end if;
    end process;

    u_WE_OE : for i in 31 downto 0 generate
    -- read/write (short pulse)
    process (RST, CLK)
    begin
        if (RST = '1') then
            we(i) <= '0';
            oe(i) <= '0';
        elsif (CLK'event and CLK = '1') then
            if (addr_msb = i) then
                if (WREN_CPUIF_IN = '1') and (we_buf = '0') then
                    we(i) <= '1';
                else
                    we(i) <= '0';
                end if;
                if (RDEN_CPUIF_IN = '1') and (oe_buf = '0') then
                    oe(i) <= '1';
                else
                    oe(i) <= '0';
                end if;
            else
                we(i) <= '0';
                oe(i) <= '0';
            end if;
        end if;
    end process;

    -- read/write (long pulse)
    process (RST, CLK)
    begin
        if (RST = '1') then
            we_long(i) <= '0';
            oe_long(i) <= '0';
        elsif (CLK'event and CLK = '1') then
            if (addr_msb = i) then
                if (WREN_CPUIF_IN = '1') then
                    we_long(i) <= '1';
                else
                    we_long(i) <= '0';
                end if;
                if (RDEN_CPUIF_IN = '1') then
                    oe_long(i) <= '1';
                else
                    oe_long(i) <= '0';
                end if;
            else
                we_long(i) <= '0';
                oe_long(i) <= '0';
            end if;
        end if;
    end process;
    end generate;

    process (RST, CLK)
    begin
        if (RST = '1') then
            read_valid      <= (others => '0');
            RDVAL_CPUIF_OUT <= '0';
        elsif (CLK'event and CLK = '1') then
            read_valid      <= read_valid(2 downto 0) & RDEN_CPUIF_IN;
            if (read_valid(3 downto 2) = "01") then
                RDVAL_CPUIF_OUT <= '1';
            else
                RDVAL_CPUIF_OUT <= '0';
            end if;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Read Mux
--------------------------------------------------------------------------------

    process (RST, CLK)
    begin
        if (RST = '1') then
            RDATA_CPUIF_OUT <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            case addr_msb is
            when "00000" => RDATA_CPUIF_OUT <= read_data(0);
            when "00001" => RDATA_CPUIF_OUT <= read_data(1);
            when "00010" => RDATA_CPUIF_OUT <= read_data(2);
            when "00011" => RDATA_CPUIF_OUT <= read_data(3);
            when "00100" => RDATA_CPUIF_OUT <= read_data(4);
            when "00101" => RDATA_CPUIF_OUT <= read_data(5);
            when "00110" => RDATA_CPUIF_OUT <= read_data(6);
            when "00111" => RDATA_CPUIF_OUT <= read_data(7);
            when "01000" => RDATA_CPUIF_OUT <= read_data(8);
            when "01001" => RDATA_CPUIF_OUT <= read_data(9);
            when "01010" => RDATA_CPUIF_OUT <= read_data(10);
            when "01011" => RDATA_CPUIF_OUT <= read_data(11);
            when "01100" => RDATA_CPUIF_OUT <= read_data(12);
            when "01101" => RDATA_CPUIF_OUT <= read_data(13);
            when "01110" => RDATA_CPUIF_OUT <= read_data(14);
            when "01111" => RDATA_CPUIF_OUT <= read_data(15);
            when "10000" => RDATA_CPUIF_OUT <= read_data(16);
            when "10001" => RDATA_CPUIF_OUT <= read_data(17);
            when "10010" => RDATA_CPUIF_OUT <= read_data(18);
            when "10011" => RDATA_CPUIF_OUT <= read_data(19);
            when "10100" => RDATA_CPUIF_OUT <= read_data(20);
            when "10101" => RDATA_CPUIF_OUT <= read_data(21);
            when "10110" => RDATA_CPUIF_OUT <= read_data(22);
            when "10111" => RDATA_CPUIF_OUT <= read_data(23);
            when "11000" => RDATA_CPUIF_OUT <= read_data(24);
            when "11001" => RDATA_CPUIF_OUT <= read_data(25);
            when "11010" => RDATA_CPUIF_OUT <= read_data(26);
            when "11011" => RDATA_CPUIF_OUT <= read_data(27);
            when "11100" => RDATA_CPUIF_OUT <= read_data(28);
            when "11101" => RDATA_CPUIF_OUT <= read_data(29);
            when "11110" => RDATA_CPUIF_OUT <= read_data(30);
            when "11111" => RDATA_CPUIF_OUT <= read_data(31);
            when others  => RDATA_CPUIF_OUT <= (others => '0');
            end case;
        end if;
    end process;

    u_READ_0_to_7 : for i in 7 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (addr_msb = i) then
                case addr_lsb is
                when x"00"  => read_data(i) <= rx_param_mac_r(i)(31 downto 0);
                when x"01"  => read_data(i) <= rx_param_mac_r(i)(63 downto 32);

                when x"10"  => read_data(i) <= tx_param_dst_mac_r(i)(31 downto 0);
                when x"11"  => read_data(i) <= tx_param_dst_mac_r(i)(63 downto 32);
                when x"12"  => read_data(i) <= tx_param_src_mac_r(i)(31 downto 0);
                when x"13"  => read_data(i) <= tx_param_src_mac_r(i)(63 downto 32);
                when x"14"  => read_data(i) <= tx_param_vlan0_r(i);
                when x"15"  => read_data(i) <= tx_param_vlan1_r(i);

                when x"18"  => read_data(i) <= ignore_frame_id_r(i);
                when x"1A"  => read_data(i) <= ignore_frame_id_puxch_r(i);
                when x"1C"  => read_data(i) <= ignore_frame_id_prach_r(i);

                when x"20"  => read_data(i) <= rx_param_id0_r(i)(0);
                when x"21"  => read_data(i) <= rx_param_id1_r(i)(0);
                when x"22"  => read_data(i) <= rx_param_id2_r(i)(0);
                when x"23"  => read_data(i) <= rx_param_id3_r(i)(0);
                when x"24"  => read_data(i) <= rx_param_id0_r(i)(1);
                when x"25"  => read_data(i) <= rx_param_id1_r(i)(1);
                when x"26"  => read_data(i) <= rx_param_id2_r(i)(1);
                when x"27"  => read_data(i) <= rx_param_id3_r(i)(1);
                when x"28"  => read_data(i) <= rx_param_id0_r(i)(2);
                when x"29"  => read_data(i) <= rx_param_id1_r(i)(2);
                when x"2A"  => read_data(i) <= rx_param_id2_r(i)(2);
                when x"2B"  => read_data(i) <= rx_param_id3_r(i)(2);
                when x"2C"  => read_data(i) <= rx_param_id0_r(i)(3);
                when x"2D"  => read_data(i) <= rx_param_id1_r(i)(3);
                when x"2E"  => read_data(i) <= rx_param_id2_r(i)(3);
                when x"2F"  => read_data(i) <= rx_param_id3_r(i)(3);
                when x"30"  => read_data(i) <= rx_param_id0_r(i)(4);
                when x"31"  => read_data(i) <= rx_param_id1_r(i)(4);
                when x"32"  => read_data(i) <= rx_param_id2_r(i)(4);
                when x"33"  => read_data(i) <= rx_param_id3_r(i)(4);
                when x"34"  => read_data(i) <= rx_param_id0_r(i)(5);
                when x"35"  => read_data(i) <= rx_param_id1_r(i)(5);
                when x"36"  => read_data(i) <= rx_param_id2_r(i)(5);
                when x"37"  => read_data(i) <= rx_param_id3_r(i)(5);
                when x"38"  => read_data(i) <= rx_param_id0_r(i)(6);
                when x"39"  => read_data(i) <= rx_param_id1_r(i)(6);
                when x"3A"  => read_data(i) <= rx_param_id2_r(i)(6);
                when x"3B"  => read_data(i) <= rx_param_id3_r(i)(6);
                when x"3C"  => read_data(i) <= rx_param_id0_r(i)(7);
                when x"3D"  => read_data(i) <= rx_param_id1_r(i)(7);
                when x"3E"  => read_data(i) <= rx_param_id2_r(i)(7);
                when x"3F"  => read_data(i) <= rx_param_id3_r(i)(7);

                when x"40"  => read_data(i) <= rx_comp_mode_r(i);
                when x"41"  => read_data(i) <= rx_scs_config_r(i);
                when x"42"  => read_data(i) <= rx_fft_size_r(i);
                when x"43"  => read_data(i) <= rx_prb_per_symbol_r(i);
                when x"44"  => read_data(i) <= rx_comp_exp_offset_r(i);

                when x"50"  => read_data(i) <= tx_comp_mode_r(i);
                when x"51"  => read_data(i) <= tx_scs_config_r(i);
                when x"52"  => read_data(i) <= tx_fft_size_r(i);
                when x"53"  => read_data(i) <= tx_prb_per_symbol_r(i);
                when x"54"  => read_data(i) <= tx_comp_exp_offset_r(i);
                when x"55"  => read_data(i) <= tx_comp_gain_offset_r(i);
                when x"56"  => read_data(i) <= tx_comp_scale_gain_offset_r(i);

                when x"60"  => read_data(i) <= t2a_max_cp_dl_r(i);
                when x"61"  => read_data(i) <= t2a_min_cp_dl_r(i);
                when x"62"  => read_data(i) <= cp_dl_period_r(i);
                when x"64"  => read_data(i) <= cp_dl_on_time_r(i)(63 downto 32);
                when x"65"  => read_data(i) <= cp_dl_on_time_r(i)(31 downto 0);
                when x"66"  => read_data(i) <= cp_dl_early_r(i)(63 downto 32);
                when x"67"  => read_data(i) <= cp_dl_early_r(i)(31 downto 0);
                when x"68"  => read_data(i) <= cp_dl_late_r(i)(63 downto 32);
                when x"69"  => read_data(i) <= cp_dl_late_r(i)(31 downto 0);
                when x"6A"  => read_data(i) <= cp_dl_out_of_range_r(i)(63 downto 32);
                when x"6B"  => read_data(i) <= cp_dl_out_of_range_r(i)(31 downto 0);

                when x"70"  => read_data(i) <= t2a_max_up_dl_r(i);
                when x"71"  => read_data(i) <= t2a_min_up_dl_r(i);
                when x"72"  => read_data(i) <= up_dl_period_r(i);
                when x"74"  => read_data(i) <= up_dl_on_time_r(i)(63 downto 32);
                when x"75"  => read_data(i) <= up_dl_on_time_r(i)(31 downto 0);
                when x"76"  => read_data(i) <= up_dl_early_r(i)(63 downto 32);
                when x"77"  => read_data(i) <= up_dl_early_r(i)(31 downto 0);
                when x"78"  => read_data(i) <= up_dl_late_r(i)(63 downto 32);
                when x"79"  => read_data(i) <= up_dl_late_r(i)(31 downto 0);
                when x"7A"  => read_data(i) <= up_dl_out_of_range_r(i)(63 downto 32);
                when x"7B"  => read_data(i) <= up_dl_out_of_range_r(i)(31 downto 0);

                when x"80"  => read_data(i) <= t2a_max_cp_ul_r(i);
                when x"81"  => read_data(i) <= t2a_min_cp_ul_r(i);
                when x"82"  => read_data(i) <= cp_ul_period_r(i);
                when x"84"  => read_data(i) <= cp_ul_on_time_r(i)(63 downto 32);
                when x"85"  => read_data(i) <= cp_ul_on_time_r(i)(31 downto 0);
                when x"86"  => read_data(i) <= cp_ul_early_r(i)(63 downto 32);
                when x"87"  => read_data(i) <= cp_ul_early_r(i)(31 downto 0);
                when x"88"  => read_data(i) <= cp_ul_late_r(i)(63 downto 32);
                when x"89"  => read_data(i) <= cp_ul_late_r(i)(31 downto 0);
                when x"8A"  => read_data(i) <= cp_ul_out_of_range_r(i)(63 downto 32);
                when x"8B"  => read_data(i) <= cp_ul_out_of_range_r(i)(31 downto 0);

--                when x"90"  => read_data(i) <= ta3_min_up0_ul_r(i);
--                when x"91"  => read_data(i) <= ta3_max_up0_ul_r(i);
                when x"92"  => read_data(i) <= up0_ul_period_r(i);
                when x"94"  => read_data(i) <= up0_ul_on_time_r(i)(63 downto 32);
                when x"95"  => read_data(i) <= up0_ul_on_time_r(i)(31 downto 0);
                when x"96"  => read_data(i) <= up0_ul_early_r(i)(63 downto 32);
                when x"97"  => read_data(i) <= up0_ul_early_r(i)(31 downto 0);
                when x"98"  => read_data(i) <= up0_ul_late_r(i)(63 downto 32);
                when x"99"  => read_data(i) <= up0_ul_late_r(i)(31 downto 0);
                when x"9A"  => read_data(i) <= up0_ul_out_of_range_r(i)(63 downto 32);
                when x"9B"  => read_data(i) <= up0_ul_out_of_range_r(i)(31 downto 0);

--                when x"A0"  => read_data(i) <= ta3_min_up1_ul_r(i);
--                when x"A1"  => read_data(i) <= ta3_max_up1_ul_r(i);
                when x"A2"  => read_data(i) <= up1_ul_period_r(i);
                when x"A4"  => read_data(i) <= up1_ul_on_time_r(i)(63 downto 32);
                when x"A5"  => read_data(i) <= up1_ul_on_time_r(i)(31 downto 0);
                when x"A6"  => read_data(i) <= up1_ul_early_r(i)(63 downto 32);
                when x"A7"  => read_data(i) <= up1_ul_early_r(i)(31 downto 0);
                when x"A8"  => read_data(i) <= up1_ul_late_r(i)(63 downto 32);
                when x"A9"  => read_data(i) <= up1_ul_late_r(i)(31 downto 0);
                when x"AA"  => read_data(i) <= up1_ul_out_of_range_r(i)(63 downto 32);
                when x"AB"  => read_data(i) <= up1_ul_out_of_range_r(i)(31 downto 0);

                when x"AC"  => read_data(i) <= DL_UP_CP_RX_CORRUPT(63 downto 32);
                when x"AD"  => read_data(i) <= DL_UP_CP_RX_CORRUPT(31 downto 0);  
                
                when x"AE"  => read_data(i) <= DL_UP_CP_RX_CORRUPT_ECPRIVERSION_PAYLOADVERSION_PCID(63 downto 32);
                when x"AF"  => read_data(i) <= DL_UP_CP_RX_CORRUPT_ECPRIVERSION_PAYLOADVERSION_PCID(31 downto 0);  
                
                when x"B0"  => read_data(i) <= DL_UP_CP_CNT_RX_PCID(63 downto 32);
                when x"B1"  => read_data(i) <= DL_UP_CP_CNT_RX_PCID(31 downto 0);   
               
                when x"B2"  => read_data(i) <= DL_UP_CP_CNT_RX_eCPRIVERSION(63 downto 32);
                when x"B3"  => read_data(i) <= DL_UP_CP_CNT_RX_eCPRIVERSION(31 downto 0);   
               
                when x"B4"  => read_data(i) <= DL_UP_CP_CNT_RX_PAYLOADVERSION(63 downto 32);
                when x"B5"  => read_data(i) <= DL_UP_CP_CNT_RX_PAYLOADVERSION(31 downto 0);   
                               
                when x"B6"  => read_data(i) <= DL_UP_CP_RX_CORRUPT_SECTIONID(63 downto 32);
                when x"B7"  => read_data(i) <= DL_UP_CP_RX_CORRUPT_SECTIONID(31 downto 0);   
                
                when x"B8"  => read_data(i) <= rx_corrupt_cnt_measurement_period_r(i);
                
                when others => read_data(i) <= (others => '0');
                end case;
            end if;
        end if;
    end process;
    end generate;

    u_READ_8_to_11 : for i in 3 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (addr_msb = i+8) then
                case addr_lsb is
                when x"20"  => read_data(i+8) <= rx_fault_id_31_ch0_0_f(i);
                when x"21"  => read_data(i+8) <= rx_fault_id_31_ch0_1_f(i);
                when x"22"  => read_data(i+8) <= rx_fault_id_31_ch0_2_f(i);
                when x"23"  => read_data(i+8) <= rx_fault_id_31_ch0_3_f(i);
                when x"24"  => read_data(i+8) <= rx_fault_id_31_ch1_0_f(i);
                when x"25"  => read_data(i+8) <= rx_fault_id_31_ch1_1_f(i);
                when x"26"  => read_data(i+8) <= rx_fault_id_31_ch1_2_f(i);
                when x"27"  => read_data(i+8) <= rx_fault_id_31_ch1_3_f(i);
                when x"28"  => read_data(i+8) <= rx_fault_id_31_ch2_0_f(i);
                when x"29"  => read_data(i+8) <= rx_fault_id_31_ch2_1_f(i);
                when x"2A"  => read_data(i+8) <= rx_fault_id_31_ch2_2_f(i);
                when x"2B"  => read_data(i+8) <= rx_fault_id_31_ch2_3_f(i);
                when x"2C"  => read_data(i+8) <= rx_fault_id_31_ch3_0_f(i);
                when x"2D"  => read_data(i+8) <= rx_fault_id_31_ch3_1_f(i);
                when x"2E"  => read_data(i+8) <= rx_fault_id_31_ch3_2_f(i);
                when x"2F"  => read_data(i+8) <= rx_fault_id_31_ch3_3_f(i);
                when x"30"  => read_data(i+8) <= rx_fault_id_31_ch4_0_f(i);
                when x"31"  => read_data(i+8) <= rx_fault_id_31_ch4_1_f(i);
                when x"32"  => read_data(i+8) <= rx_fault_id_31_ch4_2_f(i);
                when x"33"  => read_data(i+8) <= rx_fault_id_31_ch4_3_f(i);
                when x"34"  => read_data(i+8) <= rx_fault_id_31_ch5_0_f(i);
                when x"35"  => read_data(i+8) <= rx_fault_id_31_ch5_1_f(i);
                when x"36"  => read_data(i+8) <= rx_fault_id_31_ch5_2_f(i);
                when x"37"  => read_data(i+8) <= rx_fault_id_31_ch5_3_f(i);
                when x"38"  => read_data(i+8) <= rx_fault_id_31_ch6_0_f(i);
                when x"39"  => read_data(i+8) <= rx_fault_id_31_ch6_1_f(i);
                when x"3A"  => read_data(i+8) <= rx_fault_id_31_ch6_2_f(i);
                when x"3B"  => read_data(i+8) <= rx_fault_id_31_ch6_3_f(i);
                when x"3C"  => read_data(i+8) <= rx_fault_id_31_ch7_0_f(i);
                when x"3D"  => read_data(i+8) <= rx_fault_id_31_ch7_1_f(i);
                when x"3E"  => read_data(i+8) <= rx_fault_id_31_ch7_2_f(i);
                when x"3F"  => read_data(i+8) <= rx_fault_id_31_ch7_3_f(i);

                when others => read_data(i+8) <= (others => '0');
                end case;
            end if;
        end if;
    end process;
    end generate;

    u_READ_12_to_15 : for i in 3 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (addr_msb = i+12) then
                case addr_lsb is
                when x"00"  => read_data(i+12) <= rx_invalid_dst_mac_r(i);
                when x"01"  => read_data(i+12) <= rx_invalid_ethertype_r(i);
                when x"02"  => read_data(i+12) <= rx_invalid_ecpriver_r(i);
                when x"03"  => read_data(i+12) <= rx_invalid_ecpric_r(i);
                when x"04"  => read_data(i+12) <= rx_invalid_ecprimsg_r(i);
                when x"05"  => read_data(i+12) <= rx_lost_r(i);

                when x"10"  => read_data(i+12) <= rx_c_plane_exist_f(i);
                when x"11"  => read_data(i+12) <= rx_c_plane_r(i);
                when x"12"  => read_data(i+12) <= rx_c_plane_dropped_r(i);
                when x"13"  => read_data(i+12) <= rx_c_plane_buffer_f(i);
                when x"14"  => read_data(i+12) <= rx_u_plane_exist_f(i);
                when x"15"  => read_data(i+12) <= rx_u_plane_r(i);
                when x"16"  => read_data(i+12) <= rx_u_plane_dropped_r(i);
                when x"17"  => read_data(i+12) <= rx_u_plane_buffer_f(i);

--                when x"21"  => read_data(i+12) <= tx0_c_plane_r(i);
--                when x"22"  => read_data(i+12) <= tx0_c_plane_lost_r(i);
--                when x"23"  => read_data(i+12) <= tx0_c_plane_buffer_f(i);
                when x"25"  => read_data(i+12) <= tx0_u_plane_r(i);
                when x"26"  => read_data(i+12) <= tx0_u_plane_lost_r(i);
                when x"27"  => read_data(i+12) <= tx0_u_plane_buffer_f(i);

--                when x"29"  => read_data(i+12) <= tx1_c_plane_r(i);
--                when x"2A"  => read_data(i+12) <= tx1_c_plane_lost_r(i);
--                when x"2B"  => read_data(i+12) <= tx1_c_plane_buffer_f(i);
                when x"2D"  => read_data(i+12) <= tx1_u_plane_r(i);
                when x"2E"  => read_data(i+12) <= tx1_u_plane_lost_r(i);
                when x"2F"  => read_data(i+12) <= tx1_u_plane_buffer_f(i);

                when others => read_data(i+12) <= (others => '0');
                end case;
            end if;
        end if;
    end process;
    end generate;

    u_READ_16_to_31 : for i in 15 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (addr_msb = i+16) then
                case addr_lsb is
                when x"00"  => read_data(i+16) <= tx0_cpsec_symbol0_r(i);
                when x"01"  => read_data(i+16) <= tx0_cpsec_symbol1_r(i);
                when x"02"  => read_data(i+16) <= tx0_cpsec_symbol2_r(i);
                when x"03"  => read_data(i+16) <= tx0_cpsec_symbol3_r(i);
                when x"04"  => read_data(i+16) <= tx0_cpsec_symbol4_r(i);
                when x"05"  => read_data(i+16) <= tx0_cpsec_symbol5_r(i);
                when x"06"  => read_data(i+16) <= tx0_cpsec_symbol6_r(i);
                when x"07"  => read_data(i+16) <= tx0_cpsec_symbol7_r(i);
                when x"08"  => read_data(i+16) <= tx0_cpsec_symbol8_r(i);
                when x"09"  => read_data(i+16) <= tx0_cpsec_symbol9_r(i);
                when x"0A"  => read_data(i+16) <= tx0_cpsec_symbol10_r(i);
                when x"0B"  => read_data(i+16) <= tx0_cpsec_symbol11_r(i);
                when x"0C"  => read_data(i+16) <= tx0_cpsec_symbol12_r(i);
                when x"0D"  => read_data(i+16) <= tx0_cpsec_symbol13_r(i);
                when x"0E"  => read_data(i+16) <= tx_cmd_fifo_full_r(i);
                when x"0F"  => read_data(i+16) <= tx0_termination_r(i);

                when x"10"  => read_data(i+16) <= tx0_uppkt_symbol0_r(i);
                when x"11"  => read_data(i+16) <= tx0_uppkt_symbol1_r(i);
                when x"12"  => read_data(i+16) <= tx0_uppkt_symbol2_r(i);
                when x"13"  => read_data(i+16) <= tx0_uppkt_symbol3_r(i);
                when x"14"  => read_data(i+16) <= tx0_uppkt_symbol4_r(i);
                when x"15"  => read_data(i+16) <= tx0_uppkt_symbol5_r(i);
                when x"16"  => read_data(i+16) <= tx0_uppkt_symbol6_r(i);
                when x"17"  => read_data(i+16) <= tx0_uppkt_symbol7_r(i);
                when x"18"  => read_data(i+16) <= tx0_uppkt_symbol8_r(i);
                when x"19"  => read_data(i+16) <= tx0_uppkt_symbol9_r(i);
                when x"1A"  => read_data(i+16) <= tx0_uppkt_symbol10_r(i);
                when x"1B"  => read_data(i+16) <= tx0_uppkt_symbol11_r(i);
                when x"1C"  => read_data(i+16) <= tx0_uppkt_symbol12_r(i);
                when x"1D"  => read_data(i+16) <= tx0_uppkt_symbol13_r(i);

                when x"20"  => read_data(i+16) <= tx0_cq_full_symbol0_r(i);
                when x"21"  => read_data(i+16) <= tx0_cq_full_symbol1_r(i);
                when x"22"  => read_data(i+16) <= tx0_cq_full_symbol2_r(i);
                when x"23"  => read_data(i+16) <= tx0_cq_full_symbol3_r(i);
                when x"24"  => read_data(i+16) <= tx0_cq_full_symbol4_r(i);
                when x"25"  => read_data(i+16) <= tx0_cq_full_symbol5_r(i);
                when x"26"  => read_data(i+16) <= tx0_cq_full_symbol6_r(i);
                when x"27"  => read_data(i+16) <= tx0_cq_full_symbol7_r(i);
                when x"28"  => read_data(i+16) <= tx0_cq_full_symbol8_r(i);
                when x"29"  => read_data(i+16) <= tx0_cq_full_symbol9_r(i);
                when x"2A"  => read_data(i+16) <= tx0_cq_full_symbol10_r(i);
                when x"2B"  => read_data(i+16) <= tx0_cq_full_symbol11_r(i);
                when x"2C"  => read_data(i+16) <= tx0_cq_full_symbol12_r(i);
                when x"2D"  => read_data(i+16) <= tx0_cq_full_symbol13_r(i);

                when x"30"  => read_data(i+16) <= tx0_cq_usage_symbol0_f(i);
                when x"31"  => read_data(i+16) <= tx0_cq_usage_symbol1_f(i);
                when x"32"  => read_data(i+16) <= tx0_cq_usage_symbol2_f(i);
                when x"33"  => read_data(i+16) <= tx0_cq_usage_symbol3_f(i);
                when x"34"  => read_data(i+16) <= tx0_cq_usage_symbol4_f(i);
                when x"35"  => read_data(i+16) <= tx0_cq_usage_symbol5_f(i);
                when x"36"  => read_data(i+16) <= tx0_cq_usage_symbol6_f(i);
                when x"37"  => read_data(i+16) <= tx0_cq_usage_symbol7_f(i);
                when x"38"  => read_data(i+16) <= tx0_cq_usage_symbol8_f(i);
                when x"39"  => read_data(i+16) <= tx0_cq_usage_symbol9_f(i);
                when x"3A"  => read_data(i+16) <= tx0_cq_usage_symbol10_f(i);
                when x"3B"  => read_data(i+16) <= tx0_cq_usage_symbol11_f(i);
                when x"3C"  => read_data(i+16) <= tx0_cq_usage_symbol12_f(i);
                when x"3D"  => read_data(i+16) <= tx0_cq_usage_symbol13_f(i);

                when x"40"  => read_data(i+16) <= tx1_cpsec_symbol0_r(i);
                when x"41"  => read_data(i+16) <= tx1_cpsec_symbol1_r(i);
                when x"42"  => read_data(i+16) <= tx1_cpsec_symbol2_r(i);
                when x"43"  => read_data(i+16) <= tx1_cpsec_symbol3_r(i);
                when x"44"  => read_data(i+16) <= tx1_cpsec_symbol4_r(i);
                when x"45"  => read_data(i+16) <= tx1_cpsec_symbol5_r(i);
                when x"46"  => read_data(i+16) <= tx1_cpsec_symbol6_r(i);
                when x"47"  => read_data(i+16) <= tx1_cpsec_symbol7_r(i);
                when x"48"  => read_data(i+16) <= tx1_cpsec_symbol8_r(i);
                when x"49"  => read_data(i+16) <= tx1_cpsec_symbol9_r(i);
                when x"4A"  => read_data(i+16) <= tx1_cpsec_symbol10_r(i);
                when x"4B"  => read_data(i+16) <= tx1_cpsec_symbol11_r(i);
                when x"4C"  => read_data(i+16) <= tx1_cpsec_symbol12_r(i);
                when x"4D"  => read_data(i+16) <= tx1_cpsec_symbol13_r(i);
                when x"4F"  => read_data(i+16) <= tx1_termination_r(i);

                when x"50"  => read_data(i+16) <= tx1_uppkt_symbol0_r(i);
                when x"51"  => read_data(i+16) <= tx1_uppkt_symbol1_r(i);
                when x"52"  => read_data(i+16) <= tx1_uppkt_symbol2_r(i);
                when x"53"  => read_data(i+16) <= tx1_uppkt_symbol3_r(i);
                when x"54"  => read_data(i+16) <= tx1_uppkt_symbol4_r(i);
                when x"55"  => read_data(i+16) <= tx1_uppkt_symbol5_r(i);
                when x"56"  => read_data(i+16) <= tx1_uppkt_symbol6_r(i);
                when x"57"  => read_data(i+16) <= tx1_uppkt_symbol7_r(i);
                when x"58"  => read_data(i+16) <= tx1_uppkt_symbol8_r(i);
                when x"59"  => read_data(i+16) <= tx1_uppkt_symbol9_r(i);
                when x"5A"  => read_data(i+16) <= tx1_uppkt_symbol10_r(i);
                when x"5B"  => read_data(i+16) <= tx1_uppkt_symbol11_r(i);
                when x"5C"  => read_data(i+16) <= tx1_uppkt_symbol12_r(i);
                when x"5D"  => read_data(i+16) <= tx1_uppkt_symbol13_r(i);

                when x"60"  => read_data(i+16) <= tx1_cq_full_symbol0_r(i);
                when x"61"  => read_data(i+16) <= tx1_cq_full_symbol1_r(i);
                when x"62"  => read_data(i+16) <= tx1_cq_full_symbol2_r(i);
                when x"63"  => read_data(i+16) <= tx1_cq_full_symbol3_r(i);
                when x"64"  => read_data(i+16) <= tx1_cq_full_symbol4_r(i);
                when x"65"  => read_data(i+16) <= tx1_cq_full_symbol5_r(i);
                when x"66"  => read_data(i+16) <= tx1_cq_full_symbol6_r(i);
                when x"67"  => read_data(i+16) <= tx1_cq_full_symbol7_r(i);
                when x"68"  => read_data(i+16) <= tx1_cq_full_symbol8_r(i);
                when x"69"  => read_data(i+16) <= tx1_cq_full_symbol9_r(i);
                when x"6A"  => read_data(i+16) <= tx1_cq_full_symbol10_r(i);
                when x"6B"  => read_data(i+16) <= tx1_cq_full_symbol11_r(i);
                when x"6C"  => read_data(i+16) <= tx1_cq_full_symbol12_r(i);
                when x"6D"  => read_data(i+16) <= tx1_cq_full_symbol13_r(i);

                when x"70"  => read_data(i+16) <= tx1_cq_usage_symbol0_f(i);
                when x"71"  => read_data(i+16) <= tx1_cq_usage_symbol1_f(i);
                when x"72"  => read_data(i+16) <= tx1_cq_usage_symbol2_f(i);
                when x"73"  => read_data(i+16) <= tx1_cq_usage_symbol3_f(i);
                when x"74"  => read_data(i+16) <= tx1_cq_usage_symbol4_f(i);
                when x"75"  => read_data(i+16) <= tx1_cq_usage_symbol5_f(i);
                when x"76"  => read_data(i+16) <= tx1_cq_usage_symbol6_f(i);
                when x"77"  => read_data(i+16) <= tx1_cq_usage_symbol7_f(i);
                when x"78"  => read_data(i+16) <= tx1_cq_usage_symbol8_f(i);
                when x"79"  => read_data(i+16) <= tx1_cq_usage_symbol9_f(i);
                when x"7A"  => read_data(i+16) <= tx1_cq_usage_symbol10_f(i);
                when x"7B"  => read_data(i+16) <= tx1_cq_usage_symbol11_f(i);
                when x"7C"  => read_data(i+16) <= tx1_cq_usage_symbol12_f(i);
                when x"7D"  => read_data(i+16) <= tx1_cq_usage_symbol13_f(i);

                when others => read_data(i+16) <= (others => '0');
                end case;
            end if;
        end if;
    end process;
    end generate;

--------------------------------------------------------------------------------
-- In/output port mapping
--------------------------------------------------------------------------------

    u_PORT_DL : for i in DL_UNIT-1 downto 0 generate
    DL_PARAM_MAC(i)                     <= rx_param_mac_w(i)(47 downto 0);

    DL_UP_CP_RX_CORRUPT_MEASUREMENT_PERIOD(i)                    <= rx_corrupt_cnt_measurement_period_w(i)(7 downto 0);

    u_PORT_DL_CH : for j in MAX_CH_PER_UNIT-1 downto 0 generate
    u_PORT_DL_ID_1EA : if MAX_ID_PER_CH = 1 generate
    DL_PARAM_ID0_EN(i)(j)               <= rx_param_id0_w(i)(j)(16);
    DL_PARAM_ID0(i)(j)                  <= rx_param_id0_w(i)(j)(15 downto 0);
    DL_PARAM_ID1_EN(i)(j)               <= '0';
    DL_PARAM_ID1(i)(j)                  <= (others => '0');
    DL_PARAM_ID2_EN(i)(j)               <= '0';
    DL_PARAM_ID2(i)(j)                  <= (others => '0');
    DL_PARAM_ID3_EN(i)(j)               <= '0';
    DL_PARAM_ID3(i)(j)                  <= (others => '0');
    end generate;

    u_PORT_DL_ID_2EA : if MAX_ID_PER_CH = 2 generate
    DL_PARAM_ID0_EN(i)(j)               <= rx_param_id0_w(i)(j)(16);
    DL_PARAM_ID0(i)(j)                  <= rx_param_id0_w(i)(j)(15 downto 0);
    DL_PARAM_ID1_EN(i)(j)               <= rx_param_id1_w(i)(j)(16);
    DL_PARAM_ID1(i)(j)                  <= rx_param_id1_w(i)(j)(15 downto 0);
    DL_PARAM_ID2_EN(i)(j)               <= '0';
    DL_PARAM_ID2(i)(j)                  <= (others => '0');
    DL_PARAM_ID3_EN(i)(j)               <= '0';
    DL_PARAM_ID3(i)(j)                  <= (others => '0');
    end generate;

    u_PORT_DL_ID_3EA : if MAX_ID_PER_CH = 3 generate
    DL_PARAM_ID0_EN(i)(j)               <= rx_param_id0_w(i)(j)(16);
    DL_PARAM_ID0(i)(j)                  <= rx_param_id0_w(i)(j)(15 downto 0);
    DL_PARAM_ID1_EN(i)(j)               <= rx_param_id1_w(i)(j)(16);
    DL_PARAM_ID1(i)(j)                  <= rx_param_id1_w(i)(j)(15 downto 0);
    DL_PARAM_ID2_EN(i)(j)               <= rx_param_id2_w(i)(j)(16);
    DL_PARAM_ID2(i)(j)                  <= rx_param_id2_w(i)(j)(15 downto 0);
    DL_PARAM_ID3_EN(i)(j)               <= '0';
    DL_PARAM_ID3(i)(j)                  <= (others => '0');
    end generate;

    u_PORT_DL_ID_4EA : if MAX_ID_PER_CH = 4 generate
    DL_PARAM_ID0_EN(i)(j)               <= rx_param_id0_w(i)(j)(16);
    DL_PARAM_ID0(i)(j)                  <= rx_param_id0_w(i)(j)(15 downto 0);
    DL_PARAM_ID1_EN(i)(j)               <= rx_param_id1_w(i)(j)(16);
    DL_PARAM_ID1(i)(j)                  <= rx_param_id1_w(i)(j)(15 downto 0);
    DL_PARAM_ID2_EN(i)(j)               <= rx_param_id2_w(i)(j)(16);
    DL_PARAM_ID2(i)(j)                  <= rx_param_id2_w(i)(j)(15 downto 0);
    DL_PARAM_ID3_EN(i)(j)               <= rx_param_id3_w(i)(j)(16);
    DL_PARAM_ID3(i)(j)                  <= rx_param_id3_w(i)(j)(15 downto 0);
    end generate;
    end generate;

    u_PORT_DL_CH_UNUSED : if MAX_CH_PER_UNIT /= 8 generate
    u_PORT_DL_CH : for j in 7 downto MAX_CH_PER_UNIT generate
    DL_PARAM_ID0_EN(i)(j)              <= '0';
    DL_PARAM_ID0(i)(j)                 <= (others => '0');
    DL_PARAM_ID1_EN(i)(j)              <= '0';
    DL_PARAM_ID1(i)(j)                 <= (others => '0');
    DL_PARAM_ID2_EN(i)(j)              <= '0';
    DL_PARAM_ID2(i)(j)                 <= (others => '0');
    DL_PARAM_ID3_EN(i)(j)              <= '0';
    DL_PARAM_ID3(i)(j)                 <= (others => '0');
    end generate;
    end generate;

    DL_COMP_MODE(i)                     <= rx_comp_mode_w(i)(8);
    DL_IQ_WIDTH(i)                      <= rx_comp_mode_w(i)(7 downto 4);
    DL_COMP_METHOD(i)                   <= rx_comp_mode_w(i)(3 downto 0);
    DL_SCS_CONFIG(i)                    <= rx_scs_config_w(i)(3 downto 0);
    DL_FFT_SIZE(i)                      <= rx_fft_size_w(i)(3 downto 0);
    DL_PRB_PER_SYMBOL(i)                <= rx_prb_per_symbol_w(i)(9 downto 0);
    DL_COMP_EXP_OFFSET(i)               <= rx_comp_exp_offset_w(i)(4 downto 0);

    T2A_MAX_CP_DL(i)                    <= t2a_max_cp_dl_w(i)(21 downto 0);
    T2A_MIN_CP_DL(i)                    <= t2a_min_cp_dl_w(i)(21 downto 0);
    CP_DL_PERIOD(i)                     <= cp_dl_period_w(i)(7 downto 0);

    T2A_MAX_UP_DL(i)                    <= t2a_max_up_dl_w(i)(21 downto 0);
    T2A_MIN_UP_DL(i)                    <= t2a_min_up_dl_w(i)(21 downto 0);
    UP_DL_PERIOD(i)                     <= up_dl_period_w(i)(7 downto 0);
    end generate;

    u_PORT_UL : for i in UL_UNIT-1 downto 0 generate
    UL_PARAM_DST_MAC(i)                 <= tx_param_dst_mac_w(i)(47 downto 0);
    UL_PARAM_SRC_MAC(i)                 <= tx_param_src_mac_w(i)(47 downto 0);
    UL_PARAM_VLAN0_MODE(i)              <= tx_param_vlan0_w(i)(16);
    UL_PARAM_VLAN0_TCI(i)               <= tx_param_vlan0_w(i)(15 downto 0);
    UL_PARAM_VLAN1_MODE(i)              <= tx_param_vlan1_w(i)(16);
    UL_PARAM_VLAN1_TCI(i)               <= tx_param_vlan1_w(i)(15 downto 0);

    IGNORE_FRAME_ID(i)                  <= ignore_frame_id_w(i)(0);

    UL_COMP_MODE(i)                     <= tx_comp_mode_w(i)(8);
    UL_IQ_WIDTH(i)                      <= tx_comp_mode_w(i)(7 downto 4);
    UL_COMP_METHOD(i)                   <= tx_comp_mode_w(i)(3 downto 0);
    UL_SCS_CONFIG(i)                    <= tx_scs_config_w(i)(3 downto 0);
    UL_FFT_SIZE(i)                      <= tx_fft_size_w(i)(3 downto 0);
    UL_PRB_PER_MTU(i)                   <= tx_prb_per_symbol_w(i)(25 downto 16);
    UL_PRB_PER_SYMBOL(i)                <= tx_prb_per_symbol_w(i)(9 downto 0);
    UL_COMP_EXP_OFFSET(i)               <= tx_comp_exp_offset_w(i)(4 downto 0);
    UL_COMP_GAIN_OFFSET(i)              <= tx_comp_gain_offset_w(i)(10 downto 0);
    UL_COMP_SCALE_GAIN_OFFSET(i)        <= tx_comp_scale_gain_offset_w(i)(3 downto 0);

    T2A_MAX_CP_UL(i)                    <= t2a_max_cp_ul_w(i)(21 downto 0);
    T2A_MIN_CP_UL(i)                    <= t2a_min_cp_ul_w(i)(21 downto 0);
    CP_UL_PERIOD(i)                     <= cp_ul_period_w(i)(7 downto 0);

    TA3_MIN_UP0_UL(i)                   <= (others => '0'); -- ta3_min_up0_ul_w(i)(21 downto 0);
    TA3_MAX_UP0_UL(i)                   <= (others => '0'); -- ta3_max_up0_ul_w(i)(21 downto 0);
    UP0_UL_PERIOD(i)                    <= up0_ul_period_w(i)(7 downto 0);

    TA3_MIN_UP1_UL(i)                   <= (others => '0'); -- ta3_min_up1_ul_w(i)(21 downto 0);
    TA3_MAX_UP1_UL(i)                   <= (others => '0'); -- ta3_max_up1_ul_w(i)(21 downto 0);
    UP1_UL_PERIOD(i)                    <= up1_ul_period_w(i)(7 downto 0);
    end generate;

--------------------------------------------------------------------------------
-- Read register
--------------------------------------------------------------------------------

    u_READ_DL_CC : for i in DL_UNIT-1 downto 0 generate
    rx_param_mac_r(i)                   <= conv_std_logic_vector(0, 64-48) & rx_param_mac_w(i)(47 downto 0);
    rx_corrupt_cnt_measurement_period_r(i)                  <= conv_std_logic_vector(0, 32-8) & rx_corrupt_cnt_measurement_period_w(i)(7 downto 0);

    u_PORT_DL_CH : for j in MAX_CH_PER_UNIT-1 downto 0 generate
    u_PORT_DL_ID_1EA : if MAX_ID_PER_CH = 1 generate
    rx_param_id0_r(i)(j)                <= conv_std_logic_vector(0, 32-17) & rx_param_id0_w(i)(j)(16 downto 0);
    rx_param_id1_r(i)(j)                <= (others => '0');
    rx_param_id2_r(i)(j)                <= (others => '0');
    rx_param_id3_r(i)(j)                <= (others => '0');
    end generate;

    u_PORT_DL_ID_2EA : if MAX_ID_PER_CH = 2 generate
    rx_param_id0_r(i)(j)                <= conv_std_logic_vector(0, 32-17) & rx_param_id0_w(i)(j)(16 downto 0);
    rx_param_id1_r(i)(j)                <= conv_std_logic_vector(0, 32-17) & rx_param_id1_w(i)(j)(16 downto 0);
    rx_param_id2_r(i)(j)                <= (others => '0');
    rx_param_id3_r(i)(j)                <= (others => '0');
    end generate;

    u_PORT_DL_ID_3EA : if MAX_ID_PER_CH = 3 generate
    rx_param_id0_r(i)(j)                <= conv_std_logic_vector(0, 32-17) & rx_param_id0_w(i)(j)(16 downto 0);
    rx_param_id1_r(i)(j)                <= conv_std_logic_vector(0, 32-17) & rx_param_id1_w(i)(j)(16 downto 0);
    rx_param_id2_r(i)(j)                <= conv_std_logic_vector(0, 32-17) & rx_param_id2_w(i)(j)(16 downto 0);
    rx_param_id3_r(i)(j)                <= (others => '0');
    end generate;

    u_PORT_DL_ID_4EA : if MAX_ID_PER_CH = 4 generate
    rx_param_id0_r(i)(j)                <= conv_std_logic_vector(0, 32-17) & rx_param_id0_w(i)(j)(16 downto 0);
    rx_param_id1_r(i)(j)                <= conv_std_logic_vector(0, 32-17) & rx_param_id1_w(i)(j)(16 downto 0);
    rx_param_id2_r(i)(j)                <= conv_std_logic_vector(0, 32-17) & rx_param_id2_w(i)(j)(16 downto 0);
    rx_param_id3_r(i)(j)                <= conv_std_logic_vector(0, 32-17) & rx_param_id3_w(i)(j)(16 downto 0);
    end generate;
    end generate;

    u_PORT_DL_CH_UNUSED : if MAX_CH_PER_UNIT /= 8 generate
    u_PORT_DL_CH : for j in 7 downto MAX_CH_PER_UNIT generate
    rx_param_id0_r(i)(j)                <= (others => '0');
    rx_param_id1_r(i)(j)                <= (others => '0');
    rx_param_id2_r(i)(j)                <= (others => '0');
    rx_param_id3_r(i)(j)                <= (others => '0');
    end generate;
    end generate;

    rx_comp_mode_r(i)                   <= conv_std_logic_vector(0, 32-9) & rx_comp_mode_w(i)(8 downto 0);
    rx_scs_config_r(i)                  <= conv_std_logic_vector(0, 32-4) & rx_scs_config_w(i)(3 downto 0);
    rx_fft_size_r(i)                    <= conv_std_logic_vector(0, 32-4) & rx_fft_size_w(i)(3 downto 0);
    rx_prb_per_symbol_r(i)              <= conv_std_logic_vector(0, 32-10) & rx_prb_per_symbol_w(i)(9 downto 0);
    rx_comp_exp_offset_r(i)             <= conv_std_logic_vector(0, 32-5) & rx_comp_exp_offset_w(i)(4 downto 0);

    t2a_max_cp_dl_r(i)                  <= conv_std_logic_vector(0, 32-22) & t2a_max_cp_dl_w(i)(21 downto 0);
    t2a_min_cp_dl_r(i)                  <= conv_std_logic_vector(0, 32-22) & t2a_min_cp_dl_w(i)(21 downto 0);
    cp_dl_period_r(i)                   <= conv_std_logic_vector(0, 32-8) & cp_dl_period_w(i)(7 downto 0);
    cp_dl_on_time_r(i)                  <= CP_DL_ON_TIME(i);
    cp_dl_early_r(i)                    <= CP_DL_EARLY(i);
    cp_dl_late_r(i)                     <= CP_DL_LATE(i);
    cp_dl_out_of_range_r(i)             <= CP_DL_OUT_OF_RANGE(i);

    t2a_max_up_dl_r(i)                  <= conv_std_logic_vector(0, 32-22) & t2a_max_up_dl_w(i)(21 downto 0);
    t2a_min_up_dl_r(i)                  <= conv_std_logic_vector(0, 32-22) & t2a_min_up_dl_w(i)(21 downto 0);
    up_dl_period_r(i)                   <= conv_std_logic_vector(0, 32-8) & up_dl_period_w(i)(7 downto 0);
    up_dl_on_time_r(i)                  <= UP_DL_ON_TIME(i);
    up_dl_early_r(i)                    <= UP_DL_EARLY(i);
    up_dl_late_r(i)                     <= UP_DL_LATE(i);
    up_dl_out_of_range_r(i)             <= UP_DL_OUT_OF_RANGE(i);

    rx_invalid_dst_mac_r(i)             <= DL_INVALID_DST_MAC(i);
    rx_invalid_ethertype_r(i)           <= DL_INVALID_ETHERTYPE(i);
    rx_invalid_ecpriver_r(i)            <= DL_INVALID_ecpriVersion(i);
    rx_invalid_ecpric_r(i)              <= DL_INVALID_ecpriC(i);
    rx_invalid_ecprimsg_r(i)            <= DL_INVALID_ecpriMessage(i);
    rx_lost_r(i)                        <= DL_LOST(i);

    rx_c_plane_r(i)                     <= DL_C_PLANE(i);
    rx_c_plane_dropped_r(i)             <= DL_C_PLANE_DROPPED(i);
    rx_c_plane_buffer_r(i)              <= DL_C_PLANE_BUFFER(i);
    rx_c_plane_exist_r(i)               <= DL_C_PLANE_EXIST(i);
    rx_u_plane_r(i)                     <= DL_U_PLANE(i);
    rx_u_plane_dropped_r(i)             <= DL_U_PLANE_DROPPED(i);
    rx_u_plane_buffer_r(i)              <= DL_U_PLANE_BUFFER(i);
    rx_u_plane_exist_r(i)               <= DL_U_PLANE_EXIST(i);

    rx_fault_id_31_ch0_0_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH0(i)(0);
    rx_fault_id_31_ch0_1_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH0(i)(1);
    rx_fault_id_31_ch0_2_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH0(i)(2);
    rx_fault_id_31_ch0_3_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH0(i)(3);
    rx_fault_id_31_ch1_0_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH1(i)(0);
    rx_fault_id_31_ch1_1_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH1(i)(1);
    rx_fault_id_31_ch1_2_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH1(i)(2);
    rx_fault_id_31_ch1_3_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH1(i)(3);
    rx_fault_id_31_ch2_0_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH2(i)(0);
    rx_fault_id_31_ch2_1_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH2(i)(1);
    rx_fault_id_31_ch2_2_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH2(i)(2);
    rx_fault_id_31_ch2_3_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH2(i)(3);
    rx_fault_id_31_ch3_0_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH3(i)(0);
    rx_fault_id_31_ch3_1_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH3(i)(1);
    rx_fault_id_31_ch3_2_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH3(i)(2);
    rx_fault_id_31_ch3_3_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH3(i)(3);
    rx_fault_id_31_ch4_0_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH4(i)(0);
    rx_fault_id_31_ch4_1_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH4(i)(1);
    rx_fault_id_31_ch4_2_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH4(i)(2);
    rx_fault_id_31_ch4_3_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH4(i)(3);
    rx_fault_id_31_ch5_0_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH5(i)(0);
    rx_fault_id_31_ch5_1_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH5(i)(1);
    rx_fault_id_31_ch5_2_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH5(i)(2);
    rx_fault_id_31_ch5_3_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH5(i)(3);
    rx_fault_id_31_ch6_0_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH6(i)(0);
    rx_fault_id_31_ch6_1_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH6(i)(1);
    rx_fault_id_31_ch6_2_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH6(i)(2);
    rx_fault_id_31_ch6_3_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH6(i)(3);
    rx_fault_id_31_ch7_0_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH7(i)(0);
    rx_fault_id_31_ch7_1_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH7(i)(1);
    rx_fault_id_31_ch7_2_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH7(i)(2);
    rx_fault_id_31_ch7_3_r(i)           <= x"0000000" & "000" & RX_FAULT_ID_31_CH7(i)(3);
    end generate;

    u_READ_UL_CC : for i in UL_UNIT-1 downto 0 generate
    tx_param_dst_mac_r(i)               <= conv_std_logic_vector(0, 64-48) & tx_param_dst_mac_w(i)(47 downto 0);
    tx_param_src_mac_r(i)               <= conv_std_logic_vector(0, 64-48) & tx_param_src_mac_w(i)(47 downto 0);
    tx_param_vlan0_r(i)                 <= conv_std_logic_vector(0, 32-17) & tx_param_vlan0_w(i)(16 downto 0);
    tx_param_vlan1_r(i)                 <= conv_std_logic_vector(0, 32-17) & tx_param_vlan1_w(i)(16 downto 0);

    ignore_frame_id_r(i)                <= conv_std_logic_vector(0, 32-1) & ignore_frame_id_w(i)(0);
    ignore_frame_id_puxch_r(i)          <= x"00" & IGNORE_FRAME_ID_PUxCH_TX(i) & x"00" & IGNORE_FRAME_ID_PUxCH_RX(i);
    ignore_frame_id_prach_r(i)          <= x"00" & IGNORE_FRAME_ID_PRACH_TX(i) & x"00" & IGNORE_FRAME_ID_PRACH_RX(i);

    tx_comp_mode_r(i)                   <= conv_std_logic_vector(0, 32-9) & tx_comp_mode_w(i)(8 downto 0);
    tx_fft_size_r(i)                    <= conv_std_logic_vector(0, 32-4) & tx_fft_size_w(i)(3 downto 0);
    tx_scs_config_r(i)                  <= conv_std_logic_vector(0, 32-4) & tx_scs_config_w(i)(3 downto 0);
    tx_prb_per_symbol_r(i)              <= conv_std_logic_vector(0, 32-26) & tx_prb_per_symbol_w(i)(25 downto 16) & conv_std_logic_vector(0, 16-10) & tx_prb_per_symbol_w(i)(9 downto 0);
    tx_comp_exp_offset_r(i)             <= conv_std_logic_vector(0, 32-5) & tx_comp_exp_offset_w(i)(4 downto 0);
    tx_comp_gain_offset_r(i)            <= conv_std_logic_vector(0, 32-11) & tx_comp_gain_offset_w(i)(10 downto 0);
    tx_comp_scale_gain_offset_r(i)      <= conv_std_logic_vector(0, 32-4) & tx_comp_scale_gain_offset_w(i)(3 downto 0);

    t2a_max_cp_ul_r(i)                  <= conv_std_logic_vector(0, 32-22) & t2a_max_cp_ul_w(i)(21 downto 0);
    t2a_min_cp_ul_r(i)                  <= conv_std_logic_vector(0, 32-22) & t2a_min_cp_ul_w(i)(21 downto 0);
    cp_ul_period_r(i)                   <= conv_std_logic_vector(0, 32-8) & cp_ul_period_w(i)(7 downto 0);
    cp_ul_on_time_r(i)                  <= CP_UL_ON_TIME(i);
    cp_ul_early_r(i)                    <= CP_UL_EARLY(i);
    cp_ul_late_r(i)                     <= CP_UL_LATE(i);
    cp_ul_out_of_range_r(i)             <= CP_UL_OUT_OF_RANGE(i);

--    ta3_min_up0_ul_r(i)                 <= conv_std_logic_vector(0, 32-22) & ta3_min_up0_ul_w(i)(21 downto 0);
--    ta3_max_up0_ul_r(i)                 <= conv_std_logic_vector(0, 32-22) & ta3_max_up0_ul_w(i)(21 downto 0);
    up0_ul_period_r(i)                  <= conv_std_logic_vector(0, 32-8) & up0_ul_period_w(i)(7 downto 0);
    up0_ul_on_time_r(i)                 <= UP0_UL_ON_TIME(i);
    up0_ul_early_r(i)                   <= UP0_UL_EARLY(i);
    up0_ul_late_r(i)                    <= UP0_UL_LATE(i);
    up0_ul_out_of_range_r(i)            <= UP0_UL_OUT_OF_RANGE(i);

--    ta3_min_up1_ul_r(i)                 <= conv_std_logic_vector(0, 32-22) & ta3_min_up1_ul_w(i)(21 downto 0);
--    ta3_max_up1_ul_r(i)                 <= conv_std_logic_vector(0, 32-22) & ta3_max_up1_ul_w(i)(21 downto 0);
    up1_ul_period_r(i)                  <= conv_std_logic_vector(0, 32-8) & up1_ul_period_w(i)(7 downto 0);
    up1_ul_on_time_r(i)                 <= UP1_UL_ON_TIME(i);
    up1_ul_early_r(i)                   <= UP1_UL_EARLY(i);
    up1_ul_late_r(i)                    <= UP1_UL_LATE(i);
    up1_ul_out_of_range_r(i)            <= UP1_UL_OUT_OF_RANGE(i);

--    tx0_c_plane_r(i)                    <= UL_PUxCH_C_PLANE(i);
--    tx0_c_plane_lost_r(i)               <= UL_PUxCH_C_PLANE_LOST(i);
--    tx0_c_plane_buffer_r(i)             <= UL_PUxCH_C_PLANE_BUFFER(i);
    tx0_u_plane_r(i)                    <= UL_PUxCH_U_PLANE(i);
    tx0_u_plane_lost_r(i)               <= UL_PUxCH_U_PLANE_LOST(i);
    tx0_u_plane_buffer_r(i)             <= UL_PUxCH_U_PLANE_BUFFER(i);

--    tx1_c_plane_r(i)                    <= UL_PRACH_C_PLANE(i);
--    tx1_c_plane_lost_r(i)               <= UL_PRACH_C_PLANE_LOST(i);
--    tx1_c_plane_buffer_r(i)             <= UL_PRACH_C_PLANE_BUFFER(i);
    tx1_u_plane_r(i)                    <= UL_PRACH_U_PLANE(i);
    tx1_u_plane_lost_r(i)               <= UL_PRACH_U_PLANE_LOST(i);
    tx1_u_plane_buffer_r(i)             <= UL_PRACH_U_PLANE_BUFFER(i);

    tx_cmd_fifo_full_r(i)               <= UL_CMD_FIFO_FULL(i);

    tx0_termination_r(i)                <= UL_PUxCH_TERMINATION(i);
    tx0_cpsec_symbol0_r(i)              <= UL_PUxCH_CPSEC_SYMBOL0(i);
    tx0_cpsec_symbol1_r(i)              <= UL_PUxCH_CPSEC_SYMBOL1(i);
    tx0_cpsec_symbol2_r(i)              <= UL_PUxCH_CPSEC_SYMBOL2(i);
    tx0_cpsec_symbol3_r(i)              <= UL_PUxCH_CPSEC_SYMBOL3(i);
    tx0_cpsec_symbol4_r(i)              <= UL_PUxCH_CPSEC_SYMBOL4(i);
    tx0_cpsec_symbol5_r(i)              <= UL_PUxCH_CPSEC_SYMBOL5(i);
    tx0_cpsec_symbol6_r(i)              <= UL_PUxCH_CPSEC_SYMBOL6(i);
    tx0_cpsec_symbol7_r(i)              <= UL_PUxCH_CPSEC_SYMBOL7(i);
    tx0_cpsec_symbol8_r(i)              <= UL_PUxCH_CPSEC_SYMBOL8(i);
    tx0_cpsec_symbol9_r(i)              <= UL_PUxCH_CPSEC_SYMBOL9(i);
    tx0_cpsec_symbol10_r(i)             <= UL_PUxCH_CPSEC_SYMBOL10(i);
    tx0_cpsec_symbol11_r(i)             <= UL_PUxCH_CPSEC_SYMBOL11(i);
    tx0_cpsec_symbol12_r(i)             <= UL_PUxCH_CPSEC_SYMBOL12(i);
    tx0_cpsec_symbol13_r(i)             <= UL_PUxCH_CPSEC_SYMBOL13(i);

    tx0_uppkt_symbol0_r(i)              <= UL_PUxCH_UPPKT_SYMBOL0(i);
    tx0_uppkt_symbol1_r(i)              <= UL_PUxCH_UPPKT_SYMBOL1(i);
    tx0_uppkt_symbol2_r(i)              <= UL_PUxCH_UPPKT_SYMBOL2(i);
    tx0_uppkt_symbol3_r(i)              <= UL_PUxCH_UPPKT_SYMBOL3(i);
    tx0_uppkt_symbol4_r(i)              <= UL_PUxCH_UPPKT_SYMBOL4(i);
    tx0_uppkt_symbol5_r(i)              <= UL_PUxCH_UPPKT_SYMBOL5(i);
    tx0_uppkt_symbol6_r(i)              <= UL_PUxCH_UPPKT_SYMBOL6(i);
    tx0_uppkt_symbol7_r(i)              <= UL_PUxCH_UPPKT_SYMBOL7(i);
    tx0_uppkt_symbol8_r(i)              <= UL_PUxCH_UPPKT_SYMBOL8(i);
    tx0_uppkt_symbol9_r(i)              <= UL_PUxCH_UPPKT_SYMBOL9(i);
    tx0_uppkt_symbol10_r(i)             <= UL_PUxCH_UPPKT_SYMBOL10(i);
    tx0_uppkt_symbol11_r(i)             <= UL_PUxCH_UPPKT_SYMBOL11(i);
    tx0_uppkt_symbol12_r(i)             <= UL_PUxCH_UPPKT_SYMBOL12(i);
    tx0_uppkt_symbol13_r(i)             <= UL_PUxCH_UPPKT_SYMBOL13(i);

    tx0_cq_full_symbol0_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL0(i);
    tx0_cq_full_symbol1_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL1(i);
    tx0_cq_full_symbol2_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL2(i);
    tx0_cq_full_symbol3_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL3(i);
    tx0_cq_full_symbol4_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL4(i);
    tx0_cq_full_symbol5_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL5(i);
    tx0_cq_full_symbol6_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL6(i);
    tx0_cq_full_symbol7_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL7(i);
    tx0_cq_full_symbol8_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL8(i);
    tx0_cq_full_symbol9_r(i)            <= UL_PUxCH_CQ_FULL_SYMBOL9(i);
    tx0_cq_full_symbol10_r(i)           <= UL_PUxCH_CQ_FULL_SYMBOL10(i);
    tx0_cq_full_symbol11_r(i)           <= UL_PUxCH_CQ_FULL_SYMBOL11(i);
    tx0_cq_full_symbol12_r(i)           <= UL_PUxCH_CQ_FULL_SYMBOL12(i);
    tx0_cq_full_symbol13_r(i)           <= UL_PUxCH_CQ_FULL_SYMBOL13(i);

    tx0_cq_usage_symbol0_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL0(i);
    tx0_cq_usage_symbol1_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL1(i);
    tx0_cq_usage_symbol2_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL2(i);
    tx0_cq_usage_symbol3_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL3(i);
    tx0_cq_usage_symbol4_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL4(i);
    tx0_cq_usage_symbol5_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL5(i);
    tx0_cq_usage_symbol6_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL6(i);
    tx0_cq_usage_symbol7_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL7(i);
    tx0_cq_usage_symbol8_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL8(i);
    tx0_cq_usage_symbol9_r(i)           <= UL_PUxCH_CQ_USAGE_SYMBOL9(i);
    tx0_cq_usage_symbol10_r(i)          <= UL_PUxCH_CQ_USAGE_SYMBOL10(i);
    tx0_cq_usage_symbol11_r(i)          <= UL_PUxCH_CQ_USAGE_SYMBOL11(i);
    tx0_cq_usage_symbol12_r(i)          <= UL_PUxCH_CQ_USAGE_SYMBOL12(i);
    tx0_cq_usage_symbol13_r(i)          <= UL_PUxCH_CQ_USAGE_SYMBOL13(i);

    tx1_termination_r(i)                <= UL_PRACH_TERMINATION(i);
    tx1_cpsec_symbol0_r(i)              <= UL_PRACH_CPSEC_SYMBOL0(i);
    tx1_cpsec_symbol1_r(i)              <= UL_PRACH_CPSEC_SYMBOL1(i);
    tx1_cpsec_symbol2_r(i)              <= UL_PRACH_CPSEC_SYMBOL2(i);
    tx1_cpsec_symbol3_r(i)              <= UL_PRACH_CPSEC_SYMBOL3(i);
    tx1_cpsec_symbol4_r(i)              <= UL_PRACH_CPSEC_SYMBOL4(i);
    tx1_cpsec_symbol5_r(i)              <= UL_PRACH_CPSEC_SYMBOL5(i);
    tx1_cpsec_symbol6_r(i)              <= UL_PRACH_CPSEC_SYMBOL6(i);
    tx1_cpsec_symbol7_r(i)              <= UL_PRACH_CPSEC_SYMBOL7(i);
    tx1_cpsec_symbol8_r(i)              <= UL_PRACH_CPSEC_SYMBOL8(i);
    tx1_cpsec_symbol9_r(i)              <= UL_PRACH_CPSEC_SYMBOL9(i);
    tx1_cpsec_symbol10_r(i)             <= UL_PRACH_CPSEC_SYMBOL10(i);
    tx1_cpsec_symbol11_r(i)             <= UL_PRACH_CPSEC_SYMBOL11(i);
    tx1_cpsec_symbol12_r(i)             <= UL_PRACH_CPSEC_SYMBOL12(i);
    tx1_cpsec_symbol13_r(i)             <= UL_PRACH_CPSEC_SYMBOL13(i);

    tx1_uppkt_symbol0_r(i)              <= UL_PRACH_UPPKT_SYMBOL0(i);
    tx1_uppkt_symbol1_r(i)              <= UL_PRACH_UPPKT_SYMBOL1(i);
    tx1_uppkt_symbol2_r(i)              <= UL_PRACH_UPPKT_SYMBOL2(i);
    tx1_uppkt_symbol3_r(i)              <= UL_PRACH_UPPKT_SYMBOL3(i);
    tx1_uppkt_symbol4_r(i)              <= UL_PRACH_UPPKT_SYMBOL4(i);
    tx1_uppkt_symbol5_r(i)              <= UL_PRACH_UPPKT_SYMBOL5(i);
    tx1_uppkt_symbol6_r(i)              <= UL_PRACH_UPPKT_SYMBOL6(i);
    tx1_uppkt_symbol7_r(i)              <= UL_PRACH_UPPKT_SYMBOL7(i);
    tx1_uppkt_symbol8_r(i)              <= UL_PRACH_UPPKT_SYMBOL8(i);
    tx1_uppkt_symbol9_r(i)              <= UL_PRACH_UPPKT_SYMBOL9(i);
    tx1_uppkt_symbol10_r(i)             <= UL_PRACH_UPPKT_SYMBOL10(i);
    tx1_uppkt_symbol11_r(i)             <= UL_PRACH_UPPKT_SYMBOL11(i);
    tx1_uppkt_symbol12_r(i)             <= UL_PRACH_UPPKT_SYMBOL12(i);
    tx1_uppkt_symbol13_r(i)             <= UL_PRACH_UPPKT_SYMBOL13(i);

    tx1_cq_full_symbol0_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL0(i);
    tx1_cq_full_symbol1_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL1(i);
    tx1_cq_full_symbol2_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL2(i);
    tx1_cq_full_symbol3_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL3(i);
    tx1_cq_full_symbol4_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL4(i);
    tx1_cq_full_symbol5_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL5(i);
    tx1_cq_full_symbol6_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL6(i);
    tx1_cq_full_symbol7_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL7(i);
    tx1_cq_full_symbol8_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL8(i);
    tx1_cq_full_symbol9_r(i)            <= UL_PRACH_CQ_FULL_SYMBOL9(i);
    tx1_cq_full_symbol10_r(i)           <= UL_PRACH_CQ_FULL_SYMBOL10(i);
    tx1_cq_full_symbol11_r(i)           <= UL_PRACH_CQ_FULL_SYMBOL11(i);
    tx1_cq_full_symbol12_r(i)           <= UL_PRACH_CQ_FULL_SYMBOL12(i);
    tx1_cq_full_symbol13_r(i)           <= UL_PRACH_CQ_FULL_SYMBOL13(i);

    tx1_cq_usage_symbol0_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL0(i);
    tx1_cq_usage_symbol1_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL1(i);
    tx1_cq_usage_symbol2_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL2(i);
    tx1_cq_usage_symbol3_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL3(i);
    tx1_cq_usage_symbol4_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL4(i);
    tx1_cq_usage_symbol5_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL5(i);
    tx1_cq_usage_symbol6_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL6(i);
    tx1_cq_usage_symbol7_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL7(i);
    tx1_cq_usage_symbol8_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL8(i);
    tx1_cq_usage_symbol9_r(i)           <= UL_PRACH_CQ_USAGE_SYMBOL9(i);
    tx1_cq_usage_symbol10_r(i)          <= UL_PRACH_CQ_USAGE_SYMBOL10(i);
    tx1_cq_usage_symbol11_r(i)          <= UL_PRACH_CQ_USAGE_SYMBOL11(i);
    tx1_cq_usage_symbol12_r(i)          <= UL_PRACH_CQ_USAGE_SYMBOL12(i);
    tx1_cq_usage_symbol13_r(i)          <= UL_PRACH_CQ_USAGE_SYMBOL13(i);
    end generate;

--------------------------------------------------------------------------------
-- Write register
--------------------------------------------------------------------------------

    u_WRITE_DL_CC : for i in DL_UNIT-1 downto 0 generate
    u_0x0x00_WRITE : MPI_REG_WO generic map(32, x"00", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_mac_w(i)(31 downto 0) );
    u_0x0x01_WRITE : MPI_REG_WO generic map(32, x"01", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_mac_w(i)(63 downto 32) );

    u_0x0x20_WRITE : MPI_REG_WO generic map(32, x"20", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(i)(0) );
    u_0x0x21_WRITE : MPI_REG_WO generic map(32, x"21", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(i)(0) );
    u_0x0x22_WRITE : MPI_REG_WO generic map(32, x"22", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(i)(0) );
    u_0x0x23_WRITE : MPI_REG_WO generic map(32, x"23", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(i)(0) );
    u_0x0x24_WRITE : MPI_REG_WO generic map(32, x"24", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(i)(1) );
    u_0x0x25_WRITE : MPI_REG_WO generic map(32, x"25", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(i)(1) );
    u_0x0x26_WRITE : MPI_REG_WO generic map(32, x"26", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(i)(1) );
    u_0x0x27_WRITE : MPI_REG_WO generic map(32, x"27", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(i)(1) );
    u_0x0x28_WRITE : MPI_REG_WO generic map(32, x"28", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(i)(2) );
    u_0x0x29_WRITE : MPI_REG_WO generic map(32, x"29", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(i)(2) );
    u_0x0x2A_WRITE : MPI_REG_WO generic map(32, x"2A", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(i)(2) );
    u_0x0x2B_WRITE : MPI_REG_WO generic map(32, x"2B", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(i)(2) );
    u_0x0x2C_WRITE : MPI_REG_WO generic map(32, x"2C", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(i)(3) );
    u_0x0x2D_WRITE : MPI_REG_WO generic map(32, x"2D", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(i)(3) );
    u_0x0x2E_WRITE : MPI_REG_WO generic map(32, x"2E", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(i)(3) );
    u_0x0x2F_WRITE : MPI_REG_WO generic map(32, x"2F", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(i)(3) );
    u_0x0x30_WRITE : MPI_REG_WO generic map(32, x"30", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(i)(4) );
    u_0x0x31_WRITE : MPI_REG_WO generic map(32, x"31", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(i)(4) );
    u_0x0x32_WRITE : MPI_REG_WO generic map(32, x"32", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(i)(4) );
    u_0x0x33_WRITE : MPI_REG_WO generic map(32, x"33", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(i)(4) );
    u_0x0x34_WRITE : MPI_REG_WO generic map(32, x"34", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(i)(5) );
    u_0x0x35_WRITE : MPI_REG_WO generic map(32, x"35", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(i)(5) );
    u_0x0x36_WRITE : MPI_REG_WO generic map(32, x"36", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(i)(5) );
    u_0x0x37_WRITE : MPI_REG_WO generic map(32, x"37", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(i)(5) );
    u_0x0x38_WRITE : MPI_REG_WO generic map(32, x"38", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(i)(6) );
    u_0x0x39_WRITE : MPI_REG_WO generic map(32, x"39", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(i)(6) );
    u_0x0x3A_WRITE : MPI_REG_WO generic map(32, x"3A", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(i)(6) );
    u_0x0x3B_WRITE : MPI_REG_WO generic map(32, x"3B", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(i)(6) );
    u_0x0x3C_WRITE : MPI_REG_WO generic map(32, x"3C", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id0_w(i)(7) );
    u_0x0x3D_WRITE : MPI_REG_WO generic map(32, x"3D", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id1_w(i)(7) );
    u_0x0x3E_WRITE : MPI_REG_WO generic map(32, x"3E", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id2_w(i)(7) );
    u_0x0x3F_WRITE : MPI_REG_WO generic map(32, x"3F", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_param_id3_w(i)(7) );

    u_0x0x40_WRITE : MPI_REG_WO generic map(32, x"40", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_comp_mode_w(i) );
    u_0x0x41_WRITE : MPI_REG_WO generic map(32, x"41", x"00000011") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_scs_config_w(i) );
    u_0x0x42_WRITE : MPI_REG_WO generic map(32, x"42", x"0000000C") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_fft_size_w(i) );
    u_0x0x43_WRITE : MPI_REG_WO generic map(32, x"43", x"00000111") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_prb_per_symbol_w(i) );
    u_0x0x44_WRITE : MPI_REG_WO generic map(32, x"44", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_comp_exp_offset_w(i) );

    u_0x0x60_WRITE : MPI_REG_WO generic map(32, x"60", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, t2a_max_cp_dl_w(i) );
    u_0x0x61_WRITE : MPI_REG_WO generic map(32, x"61", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, t2a_min_cp_dl_w(i) );
    u_0x0x62_WRITE : MPI_REG_WO generic map(32, x"62", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, cp_dl_period_w(i) );

    u_0x0x70_WRITE : MPI_REG_WO generic map(32, x"70", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, t2a_max_up_dl_w(i) );
    u_0x0x71_WRITE : MPI_REG_WO generic map(32, x"71", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, t2a_min_up_dl_w(i) );
    u_0x0x72_WRITE : MPI_REG_WO generic map(32, x"72", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, up_dl_period_w(i) );
    end generate;

    u_WRITE_UL_CC : for i in UL_UNIT-1 downto 0 generate
    u_0x0x10_WRITE : MPI_REG_WO generic map(32, x"10", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, tx_param_dst_mac_w(i)(31 downto 0) );
    u_0x0x11_WRITE : MPI_REG_WO generic map(32, x"11", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, tx_param_dst_mac_w(i)(63 downto 32) );
    u_0x0x12_WRITE : MPI_REG_WO generic map(32, x"12", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, tx_param_src_mac_w(i)(31 downto 0) );
    u_0x0x13_WRITE : MPI_REG_WO generic map(32, x"13", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, tx_param_src_mac_w(i)(63 downto 32) );
    u_0x0x14_WRITE : MPI_REG_WO generic map(32, x"14", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, tx_param_vlan0_w(i) );
    u_0x0x15_WRITE : MPI_REG_WO generic map(32, x"15", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, tx_param_vlan1_w(i) );

    u_0x0x18_WRITE : MPI_REG_WO generic map(32, x"18", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, ignore_frame_id_w(i) );

    u_0x0x50_WRITE : MPI_REG_WO generic map(32, x"50", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, tx_comp_mode_w(i) );
    u_0x0x51_WRITE : MPI_REG_WO generic map(32, x"51", x"00000011") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, tx_scs_config_w(i) );
    u_0x0x52_WRITE : MPI_REG_WO generic map(32, x"52", x"0000000C") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, tx_fft_size_w(i) );
    u_0x0x53_WRITE : MPI_REG_WO generic map(32, x"53", x"001C0111") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, tx_prb_per_symbol_w(i) );
    u_0x0x54_WRITE : MPI_REG_WO generic map(32, x"54", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, tx_comp_exp_offset_w(i) );
    u_0x0x55_WRITE : MPI_REG_WO generic map(32, x"55", x"00000001") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, tx_comp_gain_offset_w(i) );
    u_0x0x56_WRITE : MPI_REG_WO generic map(32, x"56", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, tx_comp_scale_gain_offset_w(i) );

    u_0x0x80_WRITE : MPI_REG_WO generic map(32, x"80", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, t2a_max_cp_ul_w(i) );
    u_0x0x81_WRITE : MPI_REG_WO generic map(32, x"81", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, t2a_min_cp_ul_w(i) );
    u_0x0x82_WRITE : MPI_REG_WO generic map(32, x"82", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, cp_ul_period_w(i) );

--    u_0x0x90_WRITE : MPI_REG_WO generic map(32, x"90", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, ta3_min_up0_ul_w(i) );
--    u_0x0x91_WRITE : MPI_REG_WO generic map(32, x"91", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, ta3_max_up0_ul_w(i) );
    u_0x0x92_WRITE : MPI_REG_WO generic map(32, x"92", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, up0_ul_period_w(i) );

--    u_0x0xA0_WRITE : MPI_REG_WO generic map(32, x"A0", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, ta3_min_up1_ul_w(i) );
--    u_0x0xA1_WRITE : MPI_REG_WO generic map(32, x"A1", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, ta3_max_up1_ul_w(i) );
    u_0x0xA2_WRITE : MPI_REG_WO generic map(32, x"A2", x"00000000") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, up1_ul_period_w(i) );
    u_0x0xB8_WRITE : MPI_REG_WO generic map(32, x"B8", x"00000001") port map(RST, CLK, we(i), addr_lsb, WDATA_CPUIF_IN, rx_corrupt_cnt_measurement_period_w(i) );

    end generate;

--------------------------------------------------------------------------------
-- CDC register
--------------------------------------------------------------------------------


--------------------------------------------------------------------------------
-- Flag/status register
--------------------------------------------------------------------------------

    u_LATCH_DL_CC : for i in DL_UNIT-1 downto 0 generate
    u_0x0820_LATCH : MPI_REG_RC generic map(32, x"20") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch0_0_r(i),  open, rx_fault_id_31_ch0_0_f(i) );
    u_0x0821_LATCH : MPI_REG_RC generic map(32, x"21") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch0_1_r(i),  open, rx_fault_id_31_ch0_1_f(i) );
    u_0x0822_LATCH : MPI_REG_RC generic map(32, x"22") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch0_2_r(i),  open, rx_fault_id_31_ch0_2_f(i) );
    u_0x0823_LATCH : MPI_REG_RC generic map(32, x"23") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch0_3_r(i),  open, rx_fault_id_31_ch0_3_f(i) );
    u_0x0824_LATCH : MPI_REG_RC generic map(32, x"24") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch1_0_r(i),  open, rx_fault_id_31_ch1_0_f(i) );
    u_0x0825_LATCH : MPI_REG_RC generic map(32, x"25") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch1_1_r(i),  open, rx_fault_id_31_ch1_1_f(i) );
    u_0x0826_LATCH : MPI_REG_RC generic map(32, x"26") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch1_2_r(i),  open, rx_fault_id_31_ch1_2_f(i) );
    u_0x0827_LATCH : MPI_REG_RC generic map(32, x"27") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch1_3_r(i),  open, rx_fault_id_31_ch1_3_f(i) );
    u_0x0828_LATCH : MPI_REG_RC generic map(32, x"28") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch2_0_r(i),  open, rx_fault_id_31_ch2_0_f(i) );
    u_0x0829_LATCH : MPI_REG_RC generic map(32, x"29") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch2_1_r(i),  open, rx_fault_id_31_ch2_1_f(i) );
    u_0x082A_LATCH : MPI_REG_RC generic map(32, x"2A") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch2_2_r(i),  open, rx_fault_id_31_ch2_2_f(i) );
    u_0x082B_LATCH : MPI_REG_RC generic map(32, x"2B") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch2_3_r(i),  open, rx_fault_id_31_ch2_3_f(i) );
    u_0x082C_LATCH : MPI_REG_RC generic map(32, x"2C") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch3_0_r(i),  open, rx_fault_id_31_ch3_0_f(i) );
    u_0x082D_LATCH : MPI_REG_RC generic map(32, x"2D") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch3_1_r(i),  open, rx_fault_id_31_ch3_1_f(i) );
    u_0x082E_LATCH : MPI_REG_RC generic map(32, x"2E") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch3_2_r(i),  open, rx_fault_id_31_ch3_2_f(i) );
    u_0x082F_LATCH : MPI_REG_RC generic map(32, x"2F") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch3_3_r(i),  open, rx_fault_id_31_ch3_3_f(i) );
    u_0x0830_LATCH : MPI_REG_RC generic map(32, x"30") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch4_0_r(i),  open, rx_fault_id_31_ch4_0_f(i) );
    u_0x0831_LATCH : MPI_REG_RC generic map(32, x"31") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch4_1_r(i),  open, rx_fault_id_31_ch4_1_f(i) );
    u_0x0832_LATCH : MPI_REG_RC generic map(32, x"32") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch4_2_r(i),  open, rx_fault_id_31_ch4_2_f(i) );
    u_0x0833_LATCH : MPI_REG_RC generic map(32, x"33") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch4_3_r(i),  open, rx_fault_id_31_ch4_3_f(i) );
    u_0x0834_LATCH : MPI_REG_RC generic map(32, x"34") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch5_0_r(i),  open, rx_fault_id_31_ch5_0_f(i) );
    u_0x0835_LATCH : MPI_REG_RC generic map(32, x"35") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch5_1_r(i),  open, rx_fault_id_31_ch5_1_f(i) );
    u_0x0836_LATCH : MPI_REG_RC generic map(32, x"36") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch5_2_r(i),  open, rx_fault_id_31_ch5_2_f(i) );
    u_0x0837_LATCH : MPI_REG_RC generic map(32, x"37") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch5_3_r(i),  open, rx_fault_id_31_ch5_3_f(i) );
    u_0x0838_LATCH : MPI_REG_RC generic map(32, x"38") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch6_0_r(i),  open, rx_fault_id_31_ch6_0_f(i) );
    u_0x0839_LATCH : MPI_REG_RC generic map(32, x"39") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch6_1_r(i),  open, rx_fault_id_31_ch6_1_f(i) );
    u_0x083A_LATCH : MPI_REG_RC generic map(32, x"3A") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch6_2_r(i),  open, rx_fault_id_31_ch6_2_f(i) );
    u_0x083B_LATCH : MPI_REG_RC generic map(32, x"3B") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch6_3_r(i),  open, rx_fault_id_31_ch6_3_f(i) );
    u_0x083C_LATCH : MPI_REG_RC generic map(32, x"3C") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch7_0_r(i),  open, rx_fault_id_31_ch7_0_f(i) );
    u_0x083D_LATCH : MPI_REG_RC generic map(32, x"3D") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch7_1_r(i),  open, rx_fault_id_31_ch7_1_f(i) );
    u_0x083E_LATCH : MPI_REG_RC generic map(32, x"3E") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch7_2_r(i),  open, rx_fault_id_31_ch7_2_f(i) );
    u_0x083F_LATCH : MPI_REG_RC generic map(32, x"3F") port map(RST, CLK, oe(i+8),  addr_lsb, rx_fault_id_31_ch7_3_r(i),  open, rx_fault_id_31_ch7_3_f(i) );

    u_0x0C10_LATCH : MPI_REG_RC generic map(32, x"10") port map(RST, CLK, oe(i+12),  addr_lsb, rx_c_plane_exist_r(i),  open, rx_c_plane_exist_f(i) );
    u_0x0C13_LATCH : MPI_REG_RC generic map(32, x"13") port map(RST, CLK, oe(i+12),  addr_lsb, rx_c_plane_buffer_r(i), open, rx_c_plane_buffer_f(i) );
    u_0x0C14_LATCH : MPI_REG_RC generic map(32, x"14") port map(RST, CLK, oe(i+12),  addr_lsb, rx_u_plane_exist_r(i),  open, rx_u_plane_exist_f(i) );
    u_0x0C17_LATCH : MPI_REG_RC generic map(32, x"17") port map(RST, CLK, oe(i+12),  addr_lsb, rx_u_plane_buffer_r(i), open, rx_u_plane_buffer_f(i) );
    end generate;

    u_LATCH_UL_CC : for i in UL_UNIT-1 downto 0 generate
--    u_0x0C23_LATCH : MPI_REG_RC generic map(32, x"23") port map(RST, CLK, oe(i+12),  addr_lsb, tx0_c_plane_buffer_r(i), open, tx0_c_plane_buffer_f(i) );
    u_0x0C27_LATCH : MPI_REG_RC generic map(32, x"27") port map(RST, CLK, oe(i+12),  addr_lsb, tx0_u_plane_buffer_r(i), open, tx0_u_plane_buffer_f(i) );
--    u_0x0C2B_LATCH : MPI_REG_RC generic map(32, x"2B") port map(RST, CLK, oe(i+12),  addr_lsb, tx1_c_plane_buffer_r(i), open, tx1_c_plane_buffer_f(i) );
    u_0x0C2F_LATCH : MPI_REG_RC generic map(32, x"2F") port map(RST, CLK, oe(i+12),  addr_lsb, tx1_u_plane_buffer_r(i), open, tx1_u_plane_buffer_f(i) );

    u_0x1030_LATCH : MPI_REG_RC generic map(32, x"30") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol0_r(i),  open, tx0_cq_usage_symbol0_f(i) );
    u_0x1031_LATCH : MPI_REG_RC generic map(32, x"31") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol1_r(i),  open, tx0_cq_usage_symbol1_f(i) );
    u_0x1032_LATCH : MPI_REG_RC generic map(32, x"32") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol2_r(i),  open, tx0_cq_usage_symbol2_f(i) );
    u_0x1033_LATCH : MPI_REG_RC generic map(32, x"33") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol3_r(i),  open, tx0_cq_usage_symbol3_f(i) );
    u_0x1034_LATCH : MPI_REG_RC generic map(32, x"34") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol4_r(i),  open, tx0_cq_usage_symbol4_f(i) );
    u_0x1035_LATCH : MPI_REG_RC generic map(32, x"35") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol5_r(i),  open, tx0_cq_usage_symbol5_f(i) );
    u_0x1036_LATCH : MPI_REG_RC generic map(32, x"36") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol6_r(i),  open, tx0_cq_usage_symbol6_f(i) );
    u_0x1037_LATCH : MPI_REG_RC generic map(32, x"37") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol7_r(i),  open, tx0_cq_usage_symbol7_f(i) );
    u_0x1038_LATCH : MPI_REG_RC generic map(32, x"38") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol8_r(i),  open, tx0_cq_usage_symbol8_f(i) );
    u_0x1039_LATCH : MPI_REG_RC generic map(32, x"39") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol9_r(i),  open, tx0_cq_usage_symbol9_f(i) );
    u_0x103A_LATCH : MPI_REG_RC generic map(32, x"3A") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol10_r(i), open, tx0_cq_usage_symbol10_f(i) );
    u_0x103B_LATCH : MPI_REG_RC generic map(32, x"3B") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol11_r(i), open, tx0_cq_usage_symbol11_f(i) );
    u_0x103C_LATCH : MPI_REG_RC generic map(32, x"3C") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol12_r(i), open, tx0_cq_usage_symbol12_f(i) );
    u_0x103D_LATCH : MPI_REG_RC generic map(32, x"3D") port map(RST, CLK, oe(i+16), addr_lsb, tx0_cq_usage_symbol13_r(i), open, tx0_cq_usage_symbol13_f(i) );

    u_0x1070_LATCH : MPI_REG_RC generic map(32, x"70") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol0_r(i),  open, tx1_cq_usage_symbol0_f(i) );
    u_0x1071_LATCH : MPI_REG_RC generic map(32, x"71") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol1_r(i),  open, tx1_cq_usage_symbol1_f(i) );
    u_0x1072_LATCH : MPI_REG_RC generic map(32, x"72") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol2_r(i),  open, tx1_cq_usage_symbol2_f(i) );
    u_0x1073_LATCH : MPI_REG_RC generic map(32, x"73") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol3_r(i),  open, tx1_cq_usage_symbol3_f(i) );
    u_0x1074_LATCH : MPI_REG_RC generic map(32, x"74") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol4_r(i),  open, tx1_cq_usage_symbol4_f(i) );
    u_0x1075_LATCH : MPI_REG_RC generic map(32, x"75") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol5_r(i),  open, tx1_cq_usage_symbol5_f(i) );
    u_0x1076_LATCH : MPI_REG_RC generic map(32, x"76") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol6_r(i),  open, tx1_cq_usage_symbol6_f(i) );
    u_0x1077_LATCH : MPI_REG_RC generic map(32, x"77") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol7_r(i),  open, tx1_cq_usage_symbol7_f(i) );
    u_0x1078_LATCH : MPI_REG_RC generic map(32, x"78") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol8_r(i),  open, tx1_cq_usage_symbol8_f(i) );
    u_0x1079_LATCH : MPI_REG_RC generic map(32, x"79") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol9_r(i),  open, tx1_cq_usage_symbol9_f(i) );
    u_0x107A_LATCH : MPI_REG_RC generic map(32, x"7A") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol10_r(i), open, tx1_cq_usage_symbol10_f(i) );
    u_0x107B_LATCH : MPI_REG_RC generic map(32, x"7B") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol11_r(i), open, tx1_cq_usage_symbol11_f(i) );
    u_0x107C_LATCH : MPI_REG_RC generic map(32, x"7C") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol12_r(i), open, tx1_cq_usage_symbol12_f(i) );
    u_0x107D_LATCH : MPI_REG_RC generic map(32, x"7D") port map(RST, CLK, oe(i+16), addr_lsb, tx1_cq_usage_symbol13_r(i), open, tx1_cq_usage_symbol13_f(i) );
    end generate;

--------------------------------------------------------------------------------
-- Clear register
--------------------------------------------------------------------------------

    u_CLEAR_DL_CC : for i in DL_UNIT-1 downto 0 generate
    u_0x0065_CLEAR : MPI_CLEAR generic map(x"65") port map(RST, CLK, we_long(i),    addr_lsb, CP_DL_CNT_CLEAR(i)(0) );
    u_0x0067_CLEAR : MPI_CLEAR generic map(x"67") port map(RST, CLK, we_long(i),    addr_lsb, CP_DL_CNT_CLEAR(i)(1) );
    u_0x0069_CLEAR : MPI_CLEAR generic map(x"69") port map(RST, CLK, we_long(i),    addr_lsb, CP_DL_CNT_CLEAR(i)(2) );
    u_0x006B_CLEAR : MPI_CLEAR generic map(x"6B") port map(RST, CLK, we_long(i),    addr_lsb, CP_DL_CNT_CLEAR(i)(3) );

    u_0x0075_CLEAR : MPI_CLEAR generic map(x"75") port map(RST, CLK, we_long(i),    addr_lsb, UP_DL_CNT_CLEAR(i)(0) );
    u_0x0077_CLEAR : MPI_CLEAR generic map(x"77") port map(RST, CLK, we_long(i),    addr_lsb, UP_DL_CNT_CLEAR(i)(1) );
    u_0x0079_CLEAR : MPI_CLEAR generic map(x"79") port map(RST, CLK, we_long(i),    addr_lsb, UP_DL_CNT_CLEAR(i)(2) );
    u_0x007B_CLEAR : MPI_CLEAR generic map(x"7B") port map(RST, CLK, we_long(i),    addr_lsb, UP_DL_CNT_CLEAR(i)(3) );
    end generate;

    u_CLEAR_UL_CC : for i in UL_UNIT-1 downto 0 generate
    u_0x0085_CLEAR : MPI_CLEAR generic map(x"85") port map(RST, CLK, we_long(i),    addr_lsb, CP_UL_CNT_CLEAR(i)(0) );
    u_0x0087_CLEAR : MPI_CLEAR generic map(x"87") port map(RST, CLK, we_long(i),    addr_lsb, CP_UL_CNT_CLEAR(i)(1) );
    u_0x0089_CLEAR : MPI_CLEAR generic map(x"89") port map(RST, CLK, we_long(i),    addr_lsb, CP_UL_CNT_CLEAR(i)(2) );
    u_0x008B_CLEAR : MPI_CLEAR generic map(x"8B") port map(RST, CLK, we_long(i),    addr_lsb, CP_UL_CNT_CLEAR(i)(3) );

    u_0x0095_CLEAR : MPI_CLEAR generic map(x"95") port map(RST, CLK, we_long(i),    addr_lsb, UP0_UL_CNT_CLEAR(i)(0) );
    u_0x0097_CLEAR : MPI_CLEAR generic map(x"97") port map(RST, CLK, we_long(i),    addr_lsb, UP0_UL_CNT_CLEAR(i)(1) );
    u_0x0099_CLEAR : MPI_CLEAR generic map(x"99") port map(RST, CLK, we_long(i),    addr_lsb, UP0_UL_CNT_CLEAR(i)(2) );
    u_0x009B_CLEAR : MPI_CLEAR generic map(x"9B") port map(RST, CLK, we_long(i),    addr_lsb, UP0_UL_CNT_CLEAR(i)(3) );

    u_0x00A5_CLEAR : MPI_CLEAR generic map(x"A5") port map(RST, CLK, we_long(i),    addr_lsb, UP1_UL_CNT_CLEAR(i)(0) );
    u_0x00A7_CLEAR : MPI_CLEAR generic map(x"A7") port map(RST, CLK, we_long(i),    addr_lsb, UP1_UL_CNT_CLEAR(i)(1) );
    u_0x00A9_CLEAR : MPI_CLEAR generic map(x"A9") port map(RST, CLK, we_long(i),    addr_lsb, UP1_UL_CNT_CLEAR(i)(2) );
    u_0x00AB_CLEAR : MPI_CLEAR generic map(x"AB") port map(RST, CLK, we_long(i),    addr_lsb, UP1_UL_CNT_CLEAR(i)(3) );
    end generate;

end BEHAVE;