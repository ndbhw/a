--------------------------------------------------------------------------------
--
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Author   : jaekyu.no (jaekyu.no@samsung.com)
-- Date     : 
-- Checksum : 
--------------------------------------------------------------------------------
-- Function description
--   -. Merge AXI4-stream for PUxCH, PRACH and NB-IoT
--------------------------------------------------------------------------------
-- Change log
--   Rev 1 (2021.06.19) - initial release
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

use WORK.ARRAY_TYPE.ALL;

entity O_RAN_FRAMER_INTERCONNECT is
    generic (
        NUM_PORT                    : natural := 8
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;                            -- 156.25/390.625-MHz
        RST                         : in  std_logic;

--------------------------------------------------------------------------------
-- Input
--------------------------------------------------------------------------------

        FRAMER_TX_TREADY            : out std_logic_vector(NUM_PORT-1 downto 0);
        FRAMER_TX_TVALID            : in  std_logic_vector(NUM_PORT-1 downto 0);
        FRAMER_TX_TLAST             : in  std_logic_vector(NUM_PORT-1 downto 0);
        FRAMER_TX_TKEEP             : in  std_logic_array8(NUM_PORT-1 downto 0);
        FRAMER_TX_TDATA             : in  std_logic_array64(NUM_PORT-1 downto 0);

--------------------------------------------------------------------------------
-- O-RAN
--------------------------------------------------------------------------------

        UL_TREADY                   : in  std_logic;
        UL_TVALID                   : out std_logic;
        UL_TLAST                    : out std_logic;
        UL_TKEEP                    : out std_logic_vector(7 downto 0);
        UL_TDATA                    : out std_logic_vector(63 downto 0)
    );
end O_RAN_FRAMER_INTERCONNECT;

architecture BEHAVE of O_RAN_FRAMER_INTERCONNECT is

    signal aresetn                          : std_logic;

    component eCPRI_ST_MUX_6P is
    port (
        ACLK                                : in  std_logic;
        ARESETN                             : in  std_logic;
        S_AXIS_TVALID                       : in  std_logic_vector(5 downto 0);
        S_AXIS_TREADY                       : out std_logic_vector(5 downto 0);
        S_AXIS_TDATA                        : in  std_logic_vector(383 downto 0);
        S_AXIS_TKEEP                        : in  std_logic_vector(47 downto 0);
        S_AXIS_TLAST                        : in  std_logic_vector(5 downto 0);
        M_AXIS_TVALID                       : out std_logic_vector(0 downto 0);
        M_AXIS_TREADY                       : in  std_logic_vector(0 downto 0);
        M_AXIS_TDATA                        : out std_logic_vector(63 downto 0);
        M_AXIS_TKEEP                        : out std_logic_vector(7 downto 0);
        M_AXIS_TLAST                        : out std_logic_vector(0 downto 0);
        S_REQ_SUPPRESS                      : in  std_logic_vector(5 downto 0);
        S_DECODE_ERR                        : out std_logic_vector(5 downto 0)
    );
    end component;

    signal tx_s_axis_tvalid                 : std_logic_vector(NUM_PORT*1-1 downto 0);
    signal tx_s_axis_tready                 : std_logic_vector(NUM_PORT*1-1 downto 0);
    signal tx_s_axis_tdata                  : std_logic_vector(NUM_PORT*64-1 downto 0);
    signal tx_s_axis_tkeep                  : std_logic_vector(NUM_PORT*8-1 downto 0);
    signal tx_s_axis_tlast                  : std_logic_vector(NUM_PORT*1-1 downto 0);

begin

    aresetn <= not RST;

    u_MAP : for i in 5 downto 0 generate
    FRAMER_TX_TREADY(i)                     <= tx_s_axis_tready(i);
    tx_s_axis_tvalid(i)                     <= FRAMER_TX_TVALID(i);
    tx_s_axis_tlast(i)                      <= FRAMER_TX_TLAST(i);
    tx_s_axis_tkeep(i*8+7 downto i*8)       <= FRAMER_TX_TKEEP(i);
    tx_s_axis_tdata(i*64+63 downto i*64)    <= FRAMER_TX_TDATA(i);
    end generate;

    u_TX_COMBINE : eCPRI_ST_MUX_6P
    port map(
        ACLK                                => CLK                             ,--: in  std_logic;
        ARESETN                             => aresetn                         ,--: in  std_logic;
        S_AXIS_TVALID                       => tx_s_axis_tvalid                ,--: in  std_logic_vector(5 downto 0);
        S_AXIS_TREADY                       => tx_s_axis_tready                ,--: out std_logic_vector(5 downto 0);
        S_AXIS_TDATA                        => tx_s_axis_tdata                 ,--: in  std_logic_vector(383 downto 0);
        S_AXIS_TKEEP                        => tx_s_axis_tkeep                 ,--: in  std_logic_vector(47 downto 0);
        S_AXIS_TLAST                        => tx_s_axis_tlast                 ,--: in  std_logic_vector(5 downto 0);
        M_AXIS_TVALID(0)                    => UL_TVALID                       ,--: out std_logic_vector(0 downto 0);
        M_AXIS_TREADY(0)                    => UL_TREADY                       ,--: in  std_logic_vector(0 downto 0);
        M_AXIS_TDATA                        => UL_TDATA                        ,--: out std_logic_vector(63 downto 0);
        M_AXIS_TKEEP                        => UL_TKEEP                        ,--: out std_logic_vector(7 downto 0);
        M_AXIS_TLAST(0)                     => UL_TLAST                        ,--: out std_logic_vector(0 downto 0);
        S_REQ_SUPPRESS                      => (others => '0')                 ,--: in  std_logic_vector(5 downto 0);
        S_DECODE_ERR                        => open                             --: out std_logic_vector(5 downto 0)
    );

end BEHAVE;