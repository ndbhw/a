--------------------------------------------------------------------------------
--
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Author   : jaekyu.no (jaekyu.no@samsung.com)
-- Date     : 
-- Checksum : 
--------------------------------------------------------------------------------
-- Function description
--   1. AXI4-stream connection between MAC and multiple O-RAN framer/deframer
--   2. External port for transmitting data of other FPGA 
--------------------------------------------------------------------------------
-- Change log
--   Rev 1 (2021.06.19) - initial release
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

use WORK.ARRAY_TYPE.ALL;

entity MAC_INTERCONNECT is
    generic (
        DL_UNIT                     : natural := 2;
        UL_UNIT                     : natural := 2;
        EN_DL_INPUT_REG             : boolean := false;
        EN_DL_OUTPUT_REG            : boolean := false;     
        EN_UL_INPUT_REG             : boolean := false;
        EN_UL_OUTPUT_REG            : boolean := false     
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_MAC_RX                  : in  std_logic;                            -- 156.25/390.625-MHz
        CLK_MAC_TX                  : in  std_logic;                            -- 156.25/390.625-MHz

        RST_RX                      : in  std_logic;
        RST_TX                      : in  std_logic;

--------------------------------------------------------------------------------
-- MAC#0
--------------------------------------------------------------------------------

        MAC0_RX_VALID               : in  std_logic;
        MAC0_RX_LAST                : in  std_logic;
        MAC0_RX_KEEP                : in  std_logic_vector(7 downto 0);
        MAC0_RX_DATA                : in  std_logic_vector(63 downto 0);

        MAC0_TX_READY               : in  std_logic;
        MAC0_TX_VALID               : out std_logic;
        MAC0_TX_LAST                : out std_logic;
        MAC0_TX_KEEP                : out std_logic_vector(7 downto 0);
        MAC0_TX_DATA                : out std_logic_vector(63 downto 0);

--------------------------------------------------------------------------------
-- O-RAN (Internal)
--------------------------------------------------------------------------------

        INT_RU_RX_TVALID            : out std_logic_vector(DL_UNIT-1 downto 0);
        INT_RU_RX_TLAST             : out std_logic_vector(DL_UNIT-1 downto 0);
        INT_RU_RX_TKEEP             : out std_logic_array8(DL_UNIT-1 downto 0);
        INT_RU_RX_TDATA             : out std_logic_array64(DL_UNIT-1 downto 0);

        INT_RU_TX_TREADY            : out std_logic_vector(UL_UNIT-1 downto 0);
        INT_RU_TX_TVALID            : in  std_logic_vector(UL_UNIT-1 downto 0);
        INT_RU_TX_TLAST             : in  std_logic_vector(UL_UNIT-1 downto 0);
        INT_RU_TX_TKEEP             : in  std_logic_array8(UL_UNIT-1 downto 0);
        INT_RU_TX_TDATA             : in  std_logic_array64(UL_UNIT-1 downto 0);

--------------------------------------------------------------------------------
-- O-RAN (External)
--------------------------------------------------------------------------------

        EXT_RU_RX_TVALID            : out std_logic;
        EXT_RU_RX_TLAST             : out std_logic;
        EXT_RU_RX_TKEEP             : out std_logic_vector(7 downto 0);
        EXT_RU_RX_TDATA             : out std_logic_vector(63 downto 0);

        EXT_RU_TX_TREADY            : out std_logic;
        EXT_RU_TX_TVALID            : in  std_logic;
        EXT_RU_TX_TLAST             : in  std_logic;
        EXT_RU_TX_TKEEP             : in  std_logic_vector(7 downto 0);
        EXT_RU_TX_TDATA             : in  std_logic_vector(63 downto 0)
    );
end MAC_INTERCONNECT;

architecture BEHAVE of MAC_INTERCONNECT is

--    signal rx_aresetn                       : std_logic;
    signal tx_aresetn                       : std_logic;

    component eCPRI_ST_REG is
    port (
        ACLK                                : in  std_logic;
        ARESETN                             : in  std_logic;
        S_AXIS_TVALID                       : in  std_logic;
        S_AXIS_TREADY                       : out std_logic;
        S_AXIS_TDATA                        : in  std_logic_vector(63 downto 0);
        S_AXIS_TKEEP                        : in  std_logic_vector(7 downto 0);
        S_AXIS_TLAST                        : in  std_logic;
        M_AXIS_TVALID                       : out std_logic;
        M_AXIS_TREADY                       : in  std_logic;
        M_AXIS_TDATA                        : out std_logic_vector(63 downto 0);
        M_AXIS_TKEEP                        : out std_logic_vector(7 downto 0);
        M_AXIS_TLAST                        : out std_logic
    );
    end component;

    -- eCPRI_ST_DUP_nP

    component eCPRI_ST_MUX_2P is
    port (
        ACLK                                : in  std_logic;
        ARESETN                             : in  std_logic;
        S_AXIS_TVALID                       : in  std_logic_vector(1 downto 0);
        S_AXIS_TREADY                       : out std_logic_vector(1 downto 0);
        S_AXIS_TDATA                        : in  std_logic_vector(127 downto 0);
        S_AXIS_TKEEP                        : in  std_logic_vector(15 downto 0);
        S_AXIS_TLAST                        : in  std_logic_vector(1 downto 0);
        M_AXIS_TVALID                       : out std_logic_vector(0 downto 0);
        M_AXIS_TREADY                       : in  std_logic_vector(0 downto 0);
        M_AXIS_TDATA                        : out std_logic_vector(63 downto 0);
        M_AXIS_TKEEP                        : out std_logic_vector(7 downto 0);
        M_AXIS_TLAST                        : out std_logic_vector(0 downto 0);
        S_REQ_SUPPRESS                      : in  std_logic_vector(1 downto 0);
        S_DECODE_ERR                        : out std_logic_vector(1 downto 0)
    );
    end component;

    signal ul_s_axis_tvalid                 : std_logic_vector(1 downto 0);
    signal ul_s_axis_tready                 : std_logic_vector(1 downto 0);
    signal ul_s_axis_tdata                  : std_logic_vector(127 downto 0);
    signal ul_s_axis_tkeep                  : std_logic_vector(15 downto 0);
    signal ul_s_axis_tlast                  : std_logic_vector(1 downto 0);
    signal ul_m_axis_tvalid                 : std_logic;
    signal ul_m_axis_tready                 : std_logic;
    signal ul_m_axis_tdata                  : std_logic_vector(63 downto 0);
    signal ul_m_axis_tkeep                  : std_logic_vector(7 downto 0);
    signal ul_m_axis_tlast                  : std_logic;

begin

--------------------------------------------------------------------------------
-- Asynchronous reset
--------------------------------------------------------------------------------

--    rx_aresetn <= not RST_RX;
    tx_aresetn <= not RST_TX;

--------------------------------------------------------------------------------
-- Downlink
--------------------------------------------------------------------------------

    u_DL_IOREG_USED : if EN_DL_INPUT_REG = true or EN_DL_OUTPUT_REG = true generate
    process (CLK_MAC_RX)
    begin
        if (CLK_MAC_RX'event and CLK_MAC_RX = '1') then
            INT_RU_RX_TVALID(0) <= MAC0_RX_VALID;
            INT_RU_RX_TLAST(0)  <= MAC0_RX_LAST;
            INT_RU_RX_TKEEP(0)  <= MAC0_RX_KEEP;
            INT_RU_RX_TDATA(0)  <= MAC0_RX_DATA;
        end if;
    end process;
    end generate;

    u_DL_IOREG_UNUSED : if EN_DL_INPUT_REG = false and EN_DL_OUTPUT_REG = false generate
    INT_RU_RX_TVALID(0) <= MAC0_RX_VALID;
    INT_RU_RX_TLAST(0)  <= MAC0_RX_LAST;
    INT_RU_RX_TKEEP(0)  <= MAC0_RX_KEEP;
    INT_RU_RX_TDATA(0)  <= MAC0_RX_DATA;
    end generate;

    process (CLK_MAC_RX)
    begin
        if (CLK_MAC_RX'event and CLK_MAC_RX = '1') then
            EXT_RU_RX_TVALID <= '0';
            EXT_RU_RX_TLAST  <= '0';
            EXT_RU_RX_TKEEP  <= (others => '0');
            EXT_RU_RX_TDATA  <= (others => '0');
        end if;
    end process;

--------------------------------------------------------------------------------
-- Uplink
--------------------------------------------------------------------------------

--    u_UL_IREG_USED : if EN_UL_INPUT_REG = true generate
--    u_UL_INT0_IN_REG : eCPRI_ST_REG
--    port map(
--        ACLK                                => CLK_MAC_TX                      ,--: in  std_logic;
--        ARESETN                             => tx_aresetn                      ,--: in  std_logic;
--        S_AXIS_TVALID                       => INT_RU_TX_TVALID(0)             ,--: in  std_logic;
--        S_AXIS_TREADY                       => INT_RU_TX_TREADY(0)             ,--: out std_logic;
--        S_AXIS_TDATA                        => INT_RU_TX_TDATA(0)              ,--: in  std_logic_vector(63 downto 0);
--        S_AXIS_TKEEP                        => INT_RU_TX_TKEEP(0)              ,--: in  std_logic_vector(7 downto 0);
--        S_AXIS_TLAST                        => INT_RU_TX_TLAST(0)              ,--: in  std_logic;
--        M_AXIS_TVALID                       => ul_s_axis_tvalid(0)             ,--: out std_logic;
--        M_AXIS_TREADY                       => ul_s_axis_tready(0)             ,--: in  std_logic;
--        M_AXIS_TDATA                        => ul_s_axis_tdata(63 downto 0)    ,--: out std_logic_vector(63 downto 0);
--        M_AXIS_TKEEP                        => ul_s_axis_tkeep(7 downto 0)     ,--: out std_logic_vector(7 downto 0);
--        M_AXIS_TLAST                        => ul_s_axis_tlast(0)               --: out std_logic
--    );

--    u_UL_INT1_IN_REG : eCPRI_ST_REG
--    port map(
--        ACLK                                => CLK_MAC_TX                      ,--: in  std_logic;
--        ARESETN                             => tx_aresetn                      ,--: in  std_logic;
--        S_AXIS_TVALID                       => EXT_RU_TX_TVALID                ,--: in  std_logic;
--        S_AXIS_TREADY                       => EXT_RU_TX_TREADY                ,--: out std_logic;
--        S_AXIS_TDATA                        => EXT_RU_TX_TDATA                 ,--: in  std_logic_vector(63 downto 0);
--        S_AXIS_TKEEP                        => EXT_RU_TX_TKEEP                 ,--: in  std_logic_vector(7 downto 0);
--        S_AXIS_TLAST                        => EXT_RU_TX_TLAST                 ,--: in  std_logic;
--        M_AXIS_TVALID                       => ul_s_axis_tvalid(1)             ,--: out std_logic;
--        M_AXIS_TREADY                       => ul_s_axis_tready(1)             ,--: in  std_logic;
--        M_AXIS_TDATA                        => ul_s_axis_tdata(127 downto 64)  ,--: out std_logic_vector(63 downto 0);
--        M_AXIS_TKEEP                        => ul_s_axis_tkeep(15 downto 8)    ,--: out std_logic_vector(7 downto 0);
--        M_AXIS_TLAST                        => ul_s_axis_tlast(1)               --: out std_logic
--    );
--    end generate;

    u_UL_IREG_UNUSED : if EN_UL_INPUT_REG = false generate
    INT_RU_TX_TREADY(0)                     <= MAC0_TX_READY; --ul_s_axis_tready(0);
    ul_s_axis_tvalid(0)                     <= INT_RU_TX_TVALID(0);
    ul_s_axis_tlast(0)                      <= INT_RU_TX_TLAST(0);
    ul_s_axis_tkeep(0*8+7 downto 0*8)       <= INT_RU_TX_TKEEP(0);
    ul_s_axis_tdata(0*64+63 downto 0*64)    <= INT_RU_TX_TDATA(0);

--    EXT_RU_TX_TREADY                        <= ul_s_axis_tready(1);
--    ul_s_axis_tvalid(1)                     <= EXT_RU_TX_TVALID;
--    ul_s_axis_tlast(1)                      <= EXT_RU_TX_TLAST;
--    ul_s_axis_tkeep(1*8+7 downto 1*8)       <= EXT_RU_TX_TKEEP;
--    ul_s_axis_tdata(1*64+63 downto 1*64)    <= EXT_RU_TX_TDATA;
    end generate;

--    u_TX_COMBINE : eCPRI_ST_MUX_2P
--    port map(
--        ACLK                                => CLK_MAC_TX                      ,--: in  std_logic;
--        ARESETN                             => tx_aresetn                      ,--: in  std_logic;
        
--        S_AXIS_TVALID                       => ul_s_axis_tvalid                ,--: in  std_logic_vector(1 downto 0);
--        S_AXIS_TREADY                       => ul_s_axis_tready                ,--: out std_logic_vector(1 downto 0);
--        S_AXIS_TDATA                        => ul_s_axis_tdata                 ,--: in  std_logic_vector(127 downto 0);
--        S_AXIS_TKEEP                        => ul_s_axis_tkeep                 ,--: in  std_logic_vector(15 downto 0);
--        S_AXIS_TLAST                        => ul_s_axis_tlast                 ,--: in  std_logic_vector(1 downto 0);
        
--        M_AXIS_TVALID(0)                    => ul_m_axis_tvalid                ,--: out std_logic_vector(0 downto 0);
--        M_AXIS_TREADY(0)                    => ul_m_axis_tready                ,--: in  std_logic_vector(0 downto 0);
--        M_AXIS_TDATA                        => ul_m_axis_tdata                 ,--: out std_logic_vector(63 downto 0);
--        M_AXIS_TKEEP                        => ul_m_axis_tkeep                 ,--: out std_logic_vector(7 downto 0);
--        M_AXIS_TLAST(0)                     => ul_m_axis_tlast                 ,--: out std_logic_vector(0 downto 0);
        
--        S_REQ_SUPPRESS                      => (others => '0')                 ,--: in  std_logic_vector(1 downto 0);
--        S_DECODE_ERR                        => open                             --: out std_logic_vector(1 downto 0)
--    );

--    u_UL_OREG_USED : if EN_UL_OUTPUT_REG = true generate
--    u_UL_OUT_REG : eCPRI_ST_REG
--    port map(
--        ACLK                                => CLK_MAC_TX                      ,--: in  std_logic;
--        ARESETN                             => tx_aresetn                      ,--: in  std_logic;
--        S_AXIS_TVALID                       => ul_m_axis_tvalid                ,--: in  std_logic;
--        S_AXIS_TREADY                       => ul_m_axis_tready                ,--: out std_logic;
--        S_AXIS_TDATA                        => ul_m_axis_tdata                 ,--: in  std_logic_vector(63 downto 0);
--        S_AXIS_TKEEP                        => ul_m_axis_tkeep                 ,--: in  std_logic_vector(7 downto 0);
--        S_AXIS_TLAST                        => ul_m_axis_tlast                 ,--: in  std_logic;
--        M_AXIS_TVALID                       => MAC0_TX_VALID                   ,--: out std_logic;
--        M_AXIS_TREADY                       => MAC0_TX_READY                   ,--: in  std_logic;
--        M_AXIS_TDATA                        => MAC0_TX_DATA                    ,--: out std_logic_vector(63 downto 0);
--        M_AXIS_TKEEP                        => MAC0_TX_KEEP                    ,--: out std_logic_vector(7 downto 0);
--        M_AXIS_TLAST                        => MAC0_TX_LAST                     --: out std_logic
--    );
--    end generate;

    u_UL_OREG_UNUSED : if EN_UL_OUTPUT_REG = false generate
        
--    ul_m_axis_tready                        <= MAC0_TX_READY;
--    MAC0_TX_VALID                           <= ul_m_axis_tvalid;
--    MAC0_TX_LAST                            <= ul_m_axis_tlast;
--    MAC0_TX_KEEP                            <= ul_m_axis_tkeep;
--    MAC0_TX_DATA                            <= ul_m_axis_tdata;

--    ul_m_axis_tready                        <= MAC0_TX_READY;
    MAC0_TX_VALID                           <= INT_RU_TX_TVALID(0);
    MAC0_TX_LAST                            <= INT_RU_TX_TLAST(0);
    MAC0_TX_KEEP                            <= INT_RU_TX_TKEEP(0);
    MAC0_TX_DATA                            <= INT_RU_TX_TDATA(0);
    end generate;

end BEHAVE;